<?php
namespace Titan\GodMode\Security;

use Titan\GodMode\Contracts\NonceStore;
use Titan\GodMode\Contracts\AuditSink;

final class GodModeAccessGate
{
    public function __construct(
        private readonly GodModeKeyRegistry $keys,
        private readonly NonceStore $nonces,
        private readonly AuditSink $audit,
        private readonly array $policy
    ) {}

    public function authorize(array $deviceCertificate, array $requestProof, array $sessionContext = [], ?int $now = null): array
    {
        $now ??= time();

        /*
         * Normal tenant/session administration can never satisfy this gate.
         * Any impersonation/sudo/delegated-normal-admin state is explicitly fatal.
         */
        foreach (['impersonating','sudo_mode','acting_as_other_user','tenant_admin_override'] as $flag) {
            if (($sessionContext[$flag] ?? false) === true) {
                $this->deny('impersonation-or-admin-escalation-forbidden', $sessionContext);
            }
        }

        foreach (['role_grants','permissions','inherited_roles','effective_permissions'] as $field) {
            foreach ((array) ($sessionContext[$field] ?? []) as $value) {
                if ($this->containsForbiddenMarker((string) $value)) {
                    $this->deny('normal-role-configuration-cannot-carry-god-mode', $sessionContext);
                }
            }
        }

        try {
            $device = GodModeDeviceCertificate::fromArray($deviceCertificate)->verify($this->keys, $this->policy, $now);
            $decision = GodModeRequestProof::fromArray($requestProof)->verify($device, $this->policy, $this->nonces, $now);
        } catch (GodModeException $e) {
            $this->deny($e->reason, $sessionContext);
        }

        $this->audit->record([
            'event' => 'titan.god_mode.authorized',
            'principal_id' => $decision['principal_id'],
            'device_key_id' => $decision['device_key_id'],
            'purpose' => $decision['purpose'],
            'action' => $decision['action'],
            'target' => $decision['target'],
            'nonce' => $decision['nonce'],
            'authorized_at' => $now,
        ]);

        return $decision;
    }

    private function containsForbiddenMarker(string $value): bool
    {
        $v = strtolower($value);
        foreach ((array) ($this->policy['forbidden_role_markers'] ?? []) as $marker) {
            if (str_contains($v, strtolower((string) $marker))) {
                return true;
            }
        }
        return false;
    }

    private function deny(string $reason, array $session): never
    {
        $this->audit->record([
            'event' => 'titan.god_mode.denied',
            'reason' => $reason,
            'session_actor_id' => $session['actor_id'] ?? null,
            'company_id' => $session['company_id'] ?? null,
            'denied_at' => time(),
        ]);
        throw new GodModeException($reason);
    }
}
