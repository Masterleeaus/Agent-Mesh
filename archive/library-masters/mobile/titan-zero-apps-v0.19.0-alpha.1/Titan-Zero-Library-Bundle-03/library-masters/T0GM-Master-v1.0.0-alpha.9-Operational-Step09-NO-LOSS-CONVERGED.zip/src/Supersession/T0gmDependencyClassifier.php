<?php
namespace Titan\GodMode\Supersession;

use Titan\GodMode\Event\T0gmEventKind;

final class T0gmDependencyClassifier
{
    public function classify(array $event, int $depth): T0gmDependencyAction
    {
        $kind = $event['event_kind'] ?? '';
        if (in_array($kind, [T0gmEventKind::OBSERVATION,T0gmEventKind::ANOMALY], true)) {
            return new T0gmDependencyAction($event['event_id'], DependencyDisposition::REMAIN_INTACT, ['truth_or_evidence_is_not_erased_by_supersession'], $depth);
        }
        if ($kind === T0gmEventKind::AI_DECISION) {
            return new T0gmDependencyAction($event['event_id'], DependencyDisposition::RECOMPUTE, ['dependent_decision_must_be_recomputed_under_new_sovereign_determination'], $depth);
        }
        if ($kind === T0gmEventKind::EXECUTION) {
            $state = strtolower((string)($event['execution']['state'] ?? ''));
            if (in_array($state, ['planned','queued','pending','running','in_progress'], true)) {
                return new T0gmDependencyAction($event['event_id'], DependencyDisposition::STOP, ['live_execution_depends_on_superseded_authority'], $depth);
            }
            $rev = (int)($event['attention_signals']['reversibility'] ?? 0);
            return $rev >= 50
                ? new T0gmDependencyAction($event['event_id'], DependencyDisposition::REVERSE, ['completed_effect_is_materially_reversible'], $depth)
                : new T0gmDependencyAction($event['event_id'], DependencyDisposition::RECOMPUTE, ['completed_effect_not_safely_reversible; recompute_downstream_state'], $depth);
        }
        if (in_array($kind, [T0gmEventKind::RESULT,T0gmEventKind::HUMAN_ACTION,T0gmEventKind::AUTHORITY_USE], true)) {
            $rev = (int)($event['attention_signals']['reversibility'] ?? 0);
            if ($rev >= 50) return new T0gmDependencyAction($event['event_id'], DependencyDisposition::REVERSE, ['dependent_effect_is_reversible'], $depth);
            return new T0gmDependencyAction($event['event_id'], DependencyDisposition::RECOMPUTE, ['dependent_effect_requires_state_recomputation'], $depth);
        }
        return new T0gmDependencyAction($event['event_id'], DependencyDisposition::REMAIN_INTACT, ['no_safe_automatic_mutation_inferred'], $depth);
    }
}
