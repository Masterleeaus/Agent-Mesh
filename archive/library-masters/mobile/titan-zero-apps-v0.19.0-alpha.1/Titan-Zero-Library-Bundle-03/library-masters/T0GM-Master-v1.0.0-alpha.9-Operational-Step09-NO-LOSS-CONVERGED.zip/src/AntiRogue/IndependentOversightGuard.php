<?php
namespace Titan\GodMode\AntiRogue;

final class IndependentOversightGuard
{
    public function requireIndependence(array $operationalActors,array $oversightActors,array $compromised=[]): array
    {
        $op=array_fill_keys(array_map('strval',$operationalActors),true); $bad=array_fill_keys(array_map('strval',$compromised),true); $eligible=[];
        foreach($oversightActors as $actor){$actor=(string)$actor; if(isset($op[$actor])||isset($bad[$actor])) continue; $eligible[]=$actor;}
        if($eligible===[]) throw new \RuntimeException('independent-oversight-unavailable');
        return $eligible;
    }
    public function assertNoSelfCertification(string $subjectActor,string $reviewerActor): void
    {
        if($subjectActor===$reviewerActor) throw new \RuntimeException('ai-self-certification-forbidden');
    }
}
