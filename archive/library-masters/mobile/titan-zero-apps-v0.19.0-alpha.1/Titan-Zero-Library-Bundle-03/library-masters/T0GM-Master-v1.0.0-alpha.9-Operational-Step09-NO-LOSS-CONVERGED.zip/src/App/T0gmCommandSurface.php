<?php
namespace Titan\GodMode\App;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;
final class T0gmCommandSurface
{
    public function __construct(private readonly array $allowedTypes){}
    public function createIntent(array $command,array $session,array $device):array
    {
        foreach(['command_id','command_type','company_id','target','purpose','requested_effects','submitted_at'] as $f)if(!array_key_exists($f,$command))throw new GodModeException('command-field-required:'.$f);
        foreach(['tenant_id','tenant_company_id'] as $f)if(array_key_exists($f,$command))throw new GodModeException('legacy-tenant-boundary-forbidden:'.$f);
        if(trim((string)$command['company_id'])==='')throw new GodModeException('company-id-required');
        if(!in_array((string)$command['command_type'],$this->allowedTypes,true))throw new GodModeException('unsupported-t0gm-command-type');
        if(!is_array($command['target'])||trim((string)($command['target']['target_type']??''))===''||trim((string)($command['target']['target_id']??''))==='')throw new GodModeException('command-target-required');
        $intent=[
            'schema'=>'titan.t0gm.command_intent.v1','command_id'=>(string)$command['command_id'],'command_type'=>(string)$command['command_type'],
            'company_id'=>(string)$command['company_id'],'target'=>$command['target'],'purpose'=>(string)$command['purpose'],
            'requested_effects'=>array_values(array_unique(array_map('strval',(array)$command['requested_effects']))),'submitted_at'=>(string)$command['submitted_at'],
            'sovereign_session_id'=>(string)$session['session_id'],'sovereign_identity_id'=>(string)$session['identity_id'],
            'device_binding_id'=>(string)$device['device_binding_id'],'requires_governed_execution'=>in_array((string)$command['command_type'],['execute_request','supersede_request','contain_request'],true),
            'execution_authority_granted'=>false,'company_authority_granted'=>false,'sovereignty_transferred'=>false,
        ];
        $intent['intent_digest']=hash('sha256',CanonicalJson::encode($intent)); return $intent;
    }
}
