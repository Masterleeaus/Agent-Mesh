<?php
namespace Titan\GodMode\Store;

use Titan\GodMode\Contracts\SovereignActivityStore;
use Titan\GodMode\Event\T0gmCanonicalHasher;
use Titan\GodMode\Feed\T0gmCausalLinker;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedException;
use Titan\GodMode\Feed\T0gmFeedQuery;
use Titan\GodMode\Feed\T0gmFeedVisibilityPolicy;

final class InMemorySovereignActivityStore implements SovereignActivityStore
{
    private array $records = [];
    private array $order = [];
    private array $edges = [];
    private array $evidenceIndex = [];
    private array $correlationIndex = [];

    public function __construct(
        private readonly T0gmFeedVisibilityPolicy $visibility = new T0gmFeedVisibilityPolicy(),
        private readonly T0gmCausalLinker $linker = new T0gmCausalLinker(),
        private readonly T0gmCanonicalHasher $eventHasher = new T0gmCanonicalHasher(),
        private readonly ImmutableRecordHasher $recordHasher = new ImmutableRecordHasher(),
    ) {}

    public function append(array $event): array
    {
        $eventId = (string)($event['event_id'] ?? '');
        if ($eventId === '') throw new T0gmFeedException('missing-event-id');
        if (!$this->eventHasher->verify($event)) throw new T0gmFeedException('event-integrity-invalid');

        $eventHash = $event['integrity']['canonical_hash'];
        if (isset($this->records[$eventId])) {
            $existing = $this->records[$eventId];
            if (($existing['event_hash'] ?? null) !== $eventHash) throw new T0gmFeedException('event-id-conflict');
            return $existing;
        }

        $sequence = count($this->order) + 1;
        $previousHash = $sequence === 1 ? null : $this->records[$this->order[$sequence - 2]]['record_hash'];
        $record = [
            'audit_sequence' => $sequence,
            'event_id' => $eventId,
            'event_hash' => $eventHash,
            'previous_record_hash' => $previousHash,
            'event' => $event,
        ];
        $record['record_hash'] = $this->recordHasher->hash($record);
        $this->records[$eventId] = $record;
        $this->order[] = $eventId;

        foreach ($this->linker->edges($event) as $edge) $this->edges[$edge['edge_id']] = $edge;
        foreach (($event['evidence'] ?? []) as $evidence) {
            $id = $evidence['evidence_id'] ?? null;
            if (is_string($id) && $id !== '') $this->evidenceIndex[$id][$eventId] = true;
        }
        $corr = $event['lineage']['correlation_id'] ?? null;
        if (is_string($corr) && $corr !== '') $this->correlationIndex[$corr][$eventId] = true;
        return $record;
    }

    public function get(string $eventId, T0gmFeedAccessContext $access): ?array
    {
        $record = $this->records[$eventId] ?? null;
        if ($record === null) return null;
        $this->visibility->assertCanView($record['event'], $access);
        return $record;
    }

    public function query(T0gmFeedQuery $query, T0gmFeedAccessContext $access): array
    {
        $out = [];
        foreach ($this->order as $eventId) {
            $record = $this->records[$eventId];
            if ($record['audit_sequence'] <= $query->afterSequence) continue;
            $event = $record['event'];
            if (!$this->visibility->canView($event, $access)) continue;
            if ($query->eventKinds !== null && !in_array($event['event_kind'], $query->eventKinds, true)) continue;
            if ($query->companyIds !== null) {
                $cid = $event['company_context']['company_id'] ?? null;
                if (!is_string($cid) || !in_array($cid, $query->companyIds, true)) continue;
            }
            if ($query->correlationId !== null && ($event['lineage']['correlation_id'] ?? null) !== $query->correlationId) continue;
            if ($query->traceId !== null && ($event['lineage']['trace_id'] ?? null) !== $query->traceId) continue;
            if ($query->evidenceId !== null && !$this->eventHasEvidence($event, $query->evidenceId)) continue;
            if ($query->attentionAtLeast !== null && !$this->attentionAtLeast((string)($event['oversight']['attention_tier'] ?? ''), $query->attentionAtLeast)) continue;
            $out[] = $record;
            if (count($out) >= $query->limit) break;
        }
        return $out;
    }

    public function causalEdges(string $eventId, T0gmFeedAccessContext $access): array
    {
        $subject = $this->records[$eventId]['event'] ?? null;
        if ($subject !== null) $this->visibility->assertCanView($subject, $access);
        $out = [];
        foreach ($this->edges as $edge) {
            if ($edge['from_event_id'] !== $eventId && $edge['to_event_id'] !== $eventId) continue;
            $otherId = $edge['from_event_id'] === $eventId ? $edge['to_event_id'] : $edge['from_event_id'];
            $other = $this->records[$otherId]['event'] ?? null;
            if ($other === null && !$access->isSovereign()) continue;
            if ($other !== null && !$this->visibility->canView($other, $access)) continue;
            $out[] = $edge;
        }
        return $out;
    }

    public function byEvidence(string $evidenceId, T0gmFeedAccessContext $access): array
    {
        return $this->recordsFromIndex(array_keys($this->evidenceIndex[$evidenceId] ?? []), $access);
    }

    public function byCorrelation(string $correlationId, T0gmFeedAccessContext $access): array
    {
        return $this->recordsFromIndex(array_keys($this->correlationIndex[$correlationId] ?? []), $access);
    }

    public function auditHead(): ?array
    {
        if ($this->order === []) return null;
        return $this->records[$this->order[array_key_last($this->order)]];
    }

    public function verifyAuditLineage(): bool
    {
        $previous = null;
        $sequence = 1;
        foreach ($this->order as $eventId) {
            $record = $this->records[$eventId];
            if (($record['audit_sequence'] ?? null) !== $sequence) return false;
            if (($record['previous_record_hash'] ?? null) !== $previous) return false;
            if (!$this->recordHasher->verify($record)) return false;
            if (!$this->eventHasher->verify($record['event'])) return false;
            if (($record['event_hash'] ?? null) !== ($record['event']['integrity']['canonical_hash'] ?? null)) return false;
            $previous = $record['record_hash'];
            $sequence++;
        }
        return true;
    }

    private function recordsFromIndex(array $ids, T0gmFeedAccessContext $access): array
    {
        $out = [];
        foreach ($ids as $id) {
            $record = $this->records[$id] ?? null;
            if ($record && $this->visibility->canView($record['event'], $access)) $out[] = $record;
        }
        usort($out, fn($a,$b) => $a['audit_sequence'] <=> $b['audit_sequence']);
        return $out;
    }

    private function eventHasEvidence(array $event, string $evidenceId): bool
    {
        foreach (($event['evidence'] ?? []) as $evidence) if (($evidence['evidence_id'] ?? null) === $evidenceId) return true;
        return false;
    }

    private function attentionAtLeast(string $actual, string $minimum): bool
    {
        $rank = ['routine'=>0,'watch'=>1,'important'=>2,'urgent'=>3,'critical'=>4];
        if (!isset($rank[$actual], $rank[$minimum])) throw new T0gmFeedException('invalid-attention-tier');
        return $rank[$actual] >= $rank[$minimum];
    }
}
