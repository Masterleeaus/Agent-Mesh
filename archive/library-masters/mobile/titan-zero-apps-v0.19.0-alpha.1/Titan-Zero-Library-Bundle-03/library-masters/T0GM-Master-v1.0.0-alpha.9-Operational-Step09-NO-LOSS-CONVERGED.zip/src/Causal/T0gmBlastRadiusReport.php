<?php
namespace Titan\GodMode\Causal;

final class T0gmBlastRadiusReport
{
    /**
     * @param list<string> $affectedCompanies
     * @param list<string> $affectedSystems
     * @param list<string> $affectedWorkers
     * @param list<string> $affectedDecisions
     * @param list<string> $affectedNodeIds
     * @param list<array<string,mixed>> $paths
     */
    public function __construct(
        public readonly string $phase,
        public readonly string $rootId,
        public readonly array $affectedCompanies,
        public readonly array $affectedSystems,
        public readonly array $affectedWorkers,
        public readonly array $affectedDecisions,
        public readonly array $affectedNodeIds,
        public readonly int $maxDepth,
        public readonly bool $crossCompany,
        public readonly int $highestRiskScore,
        public readonly array $paths,
        public readonly bool $authorityGranted = false,
    ) {}

    public function toArray(): array
    {
        return [
            'phase' => $this->phase,
            'root_id' => $this->rootId,
            'affected_companies' => $this->affectedCompanies,
            'affected_systems' => $this->affectedSystems,
            'affected_workers' => $this->affectedWorkers,
            'affected_decisions' => $this->affectedDecisions,
            'affected_node_ids' => $this->affectedNodeIds,
            'max_depth' => $this->maxDepth,
            'cross_company' => $this->crossCompany,
            'highest_risk_score' => $this->highestRiskScore,
            'paths' => $this->paths,
            'authority_granted' => false,
            'analysis_only' => true,
        ];
    }
}
