<?php
namespace Titan\GodMode\Ranking;

final class T0gmAttentionScore
{
    public function __construct(
        public readonly int $score,
        public readonly string $tier,
        public readonly T0gmAttentionSignals $signals,
        public readonly array $contributions,
        public readonly array $reasonCodes,
        public readonly string $modelVersion = 't0gm.attention.v1',
    ) {}

    public function toArray(): array
    {
        return [
            'model_version'=>$this->modelVersion,
            'score'=>$this->score,
            'tier'=>$this->tier,
            'signals'=>$this->signals->toArray(),
            'contributions'=>$this->contributions,
            'reason_codes'=>$this->reasonCodes,
        ];
    }
}
