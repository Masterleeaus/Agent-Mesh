<?php
namespace Titan\GodMode\Event;

use Titan\GodMode\Security\GodModeException;

final class T0gmEventProvenanceTrustStore
{
    private array $keys=[];
    public function __construct(array $keys=[]){foreach($keys as $keyId=>$descriptor)$this->register((string)$keyId,$descriptor);}
    public function register(string $keyId,array $descriptor):void
    {
        $suite=(string)($descriptor['suite']??'');$public=$descriptor['public_key']??null;$purposes=$descriptor['purposes']??[];
        if($keyId===''||$suite===''||!is_string($public)||$public===''||!is_array($purposes)||$purposes===[]) throw new GodModeException('invalid-event-provenance-trust-key');
        if(!in_array('event_provenance',$purposes,true)) throw new GodModeException('event-provenance-purpose-not-trusted:'.$keyId);
        $this->keys[$keyId]=['suite'=>$suite,'public_key'=>$public,'purposes'=>$purposes,'provider_id'=>$descriptor['provider_id']??null,
            'status'=>(string)($descriptor['status']??'active'),'trusted_from'=>isset($descriptor['trusted_from'])?(int)$descriptor['trusted_from']:null,
            'retired_at'=>isset($descriptor['retired_at'])?(int)$descriptor['retired_at']:null,'revoked_at'=>isset($descriptor['revoked_at'])?(int)$descriptor['revoked_at']:null];
    }
    public function key(string $keyId):array{if(!isset($this->keys[$keyId]))throw new GodModeException('untrusted-event-provenance-key:'.$keyId);return $this->keys[$keyId];}
    public function keyForVerification(string $keyId,int $evidenceTime):array
    {
        $k=$this->key($keyId);
        if($k['trusted_from']!==null&&$evidenceTime<$k['trusted_from'])throw new GodModeException('event-provenance-key-not-trusted-at:'.$keyId);
        if($k['revoked_at']!==null&&$evidenceTime>=$k['revoked_at'])throw new GodModeException('event-provenance-key-revoked-at:'.$keyId);
        if($k['retired_at']!==null&&$evidenceTime>=$k['retired_at'])throw new GodModeException('event-provenance-key-not-trusted-at:'.$keyId);
        return $k;
    }
}
