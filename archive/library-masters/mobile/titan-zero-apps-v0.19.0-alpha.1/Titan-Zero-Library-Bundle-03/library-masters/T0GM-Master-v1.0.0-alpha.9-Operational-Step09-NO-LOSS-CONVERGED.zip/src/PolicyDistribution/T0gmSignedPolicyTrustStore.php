<?php
namespace Titan\GodMode\PolicyDistribution;

use Titan\GodMode\Security\GodModeException;

final class T0gmSignedPolicyTrustStore
{
    private array $keys=[];
    public function __construct(array $keys=[]){foreach($keys as $keyId=>$d)$this->register((string)$keyId,$d);}
    public function register(string $keyId,array $d):void
    {
        $suite=(string)($d['suite']??'');$pub=base64_decode((string)($d['public_key']??''),true);$purposes=$d['purposes']??[];
        if($keyId===''||$suite!=='ed25519'||$pub===false||strlen($pub)!==SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES||!is_array($purposes)||$purposes===[])throw new GodModeException('invalid-signed-policy-trust-key');
        foreach($purposes as $p)if(!in_array($p,['constitution','policy','overlay','configuration'],true))throw new GodModeException('invalid-signed-policy-purpose:'.$p);
        $this->keys[$keyId]=[
            'suite'=>$suite,'public_key'=>$pub,'purposes'=>array_values(array_unique($purposes)),'status'=>(string)($d['status']??'active'),
            'trusted_from'=>isset($d['trusted_from'])?(int)$d['trusted_from']:null,'retired_at'=>isset($d['retired_at'])?(int)$d['retired_at']:null,
            'revoked_at'=>isset($d['revoked_at'])?(int)$d['revoked_at']:null,'provider_id'=>$d['provider_id']??null,
        ];
    }
    public function keyForVerification(string $keyId,string $purpose,int $evidenceTime):array
    {
        if(!isset($this->keys[$keyId]))throw new GodModeException('untrusted-signed-policy-key:'.$keyId);
        $k=$this->keys[$keyId];
        if(!in_array($purpose,$k['purposes'],true))throw new GodModeException('signed-policy-purpose-not-trusted:'.$purpose);
        if($k['trusted_from']!==null&&$evidenceTime<$k['trusted_from'])throw new GodModeException('signed-policy-key-not-trusted-at:'.$keyId);
        if($k['revoked_at']!==null&&$evidenceTime>=$k['revoked_at'])throw new GodModeException('signed-policy-key-revoked-at:'.$keyId);
        if($k['retired_at']!==null&&$evidenceTime>=$k['retired_at'])throw new GodModeException('signed-policy-key-not-trusted-at:'.$keyId);
        return $k;
    }
}
