<?php
namespace Titan\GodMode\Event;

use DateTimeImmutable;
use DateTimeZone;

final class T0gmEventFactory
{
    public function __construct(private readonly T0gmEventValidator $validator = new T0gmEventValidator()) {}

    /**
     * Creates a normalized immutable event payload. Domain-specific sections are supplied in $details.
     * Time fields record when reality/event capture occurred; they do not grant or extend authority.
     */
    public function make(
        string $kind,
        array $companyContext,
        array $actor,
        array $source,
        array $subject,
        array $lineage,
        array $risk,
        array $oversight,
        array $evidence = [],
        array $details = [],
        ?string $eventId = null,
        ?string $occurredAt = null,
        ?string $recordedAt = null,
    ): array {
        $now = (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s.u\Z');
        $event = array_merge([
            'schema' => 'titan.t0gm.event.v1',
            'event_id' => $eventId ?? self::id(),
            'event_kind' => $kind,
            'occurred_at' => $occurredAt ?? $now,
            'recorded_at' => $recordedAt ?? $now,
            'company_context' => $companyContext,
            'actor' => $actor,
            'source' => $source,
            'subject' => $subject,
            'lineage' => $lineage,
            'risk' => $risk,
            'oversight' => $oversight,
            'evidence' => $evidence,
        ], $details);
        return $this->validator->validate($event);
    }

    private static function id(): string
    {
        return 't0gm_evt_' . bin2hex(random_bytes(16));
    }
}
