<?php
namespace Titan\GodMode\Policy;

final class ClientAuthorityPolicyEngine
{
    public function __construct(private readonly ClientAuthorityProfileFactory $factory = new ClientAuthorityProfileFactory()) {}

    public function evaluate(array $profile, array $capability, array $request): ClientAuthorityPolicyDecision
    {
        $reasons=[];
        if (($profile['schema'] ?? null)!=='titan.t0gm.client-authority-profile.v1') $reasons[]='invalid_profile_schema';
        if (!$this->factory->verify($profile)) $reasons[]='profile_integrity_invalid';
        if (!in_array($profile['profile_type'] ?? null, ClientAuthorityProfileType::all(), true)) $reasons[]='unknown_profile_type';
        if (($profile['company_id'] ?? null)!==($capability['company_id'] ?? null) || ($profile['company_id'] ?? null)!==($request['company_id'] ?? null)) $reasons[]='profile_company_mismatch';
        if (($profile['authority_basis_id'] ?? null)!==($capability['authority_basis']['basis_id'] ?? null)) $reasons[]='authority_basis_profile_mismatch';

        $targetType=$request['target']['target_type'] ?? '';
        $allowedTargets=$profile['allowed_target_types'] ?? [];
        if (!in_array($targetType,$allowedTargets,true)) $reasons[]='target_not_allowed_by_client_profile';

        $operation=strtolower(trim((string)($request['operation'] ?? '')));
        if (in_array($operation,array_map('strtolower',$profile['denied_operations'] ?? []),true)) $reasons[]='operation_denied_by_client_profile';
        $allowOps=$profile['allowed_operations'] ?? [];
        if (($profile['profile_type'] ?? null)===ClientAuthorityProfileType::RESTRICTED && ($allowOps===[] || !in_array($operation,array_map('strtolower',$allowOps),true))) $reasons[]='restricted_operation_not_allowlisted';
        elseif ($allowOps!==[] && !in_array($operation,array_map('strtolower',$allowOps),true)) $reasons[]='operation_not_allowlisted';

        $actionClass=$request['action_class'] ?? 'mutation';
        if (!in_array($actionClass,$profile['allowed_action_classes'] ?? [],true)) $reasons[]='action_class_not_allowed_by_client_profile';
        if (($profile['profile_type'] ?? null)===ClientAuthorityProfileType::OBSERVATION_ONLY && !in_array($actionClass,['observe','diagnostic'],true)) $reasons[]='observation_only_state_change_forbidden';

        $approval=$profile['client_approval'] ?? ['mode'=>'none','required_for'=>[]];
        $approvalRequired=($approval['mode'] ?? 'none')==='required' || in_array($actionClass,$approval['required_for'] ?? [],true);
        if ($approvalRequired && !$this->validApproval($request['client_approval'] ?? null,$profile,$request)) $reasons[]='client_approval_required';

        $mode=(string)($profile['execution_mode'] ?? 'deny');
        if ($reasons!==[]) return new ClientAuthorityPolicyDecision(false,$mode,array_values(array_unique($reasons)));
        if ($mode==='request_until_approved') $mode='execute';
        return new ClientAuthorityPolicyDecision(true,$mode,[]);
    }

    private function validApproval(mixed $approval,array $profile,array $request): bool
    {
        if (!is_array($approval)) return false;
        return ($approval['approved'] ?? false)===true
            && ($approval['company_id'] ?? null)===($profile['company_id'] ?? null)
            && ($approval['operation'] ?? null)===($request['operation'] ?? null)
            && is_string($approval['approval_id'] ?? null) && $approval['approval_id']!=='';
    }
}
