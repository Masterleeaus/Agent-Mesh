<?php
namespace Titan\GodMode\Custody;

use Titan\GodMode\Security\GodModeException;

/**
 * Production HSM adapter using an OpenSSL store/PKCS#11 URI.
 * Authentication/session establishment belongs to the configured OpenSSL provider or HSM agent.
 * PINs and private key bytes are deliberately not accepted by this class.
 */
final class Pkcs11HsmCustodyProvider implements SovereignKeyCustodyProvider
{
    /** @param array<string,array> $keys */
    public function __construct(
        private readonly string $id,
        private readonly array $keys,
        private readonly string $openssl='openssl',
        private readonly array $providerArgs=[],
    ) {
        foreach($keys as $keyId=>$cfg){
            $uri=(string)($cfg['key_uri']??'');
            if(!str_starts_with($uri,'pkcs11:')) throw new GodModeException('hsm-key-uri-must-be-pkcs11:' . $keyId);
            if(stripos($uri,'pin-value=')!==false || stripos($uri,'pin-source=')!==false) throw new GodModeException('hsm-pin-material-forbidden-in-key-uri');
        }
    }
    public function providerId(): string { return $this->id; }
    public function describe(string $keyId): SovereignKeyHandle {
        $c=$this->config($keyId); $pub=base64_decode((string)($c['public_key']??''),true);
        if($pub===false||$pub==='') throw new GodModeException('invalid-hsm-public-key:' . $keyId);
        return new SovereignKeyHandle($keyId,(string)$c['suite'],$this->id,'hsm',(string)$c['custody_domain'],$pub,true,false,(array)($c['purposes']??[]),(string)$c['attestation_evidence_hash'],['key_uri_hash'=>hash('sha256',(string)$c['key_uri'])]);
    }
    public function sign(string $keyId,string $suite,string $message,array $context=[]): string {
        $c=$this->config($keyId); if((string)$c['suite']!==$suite) throw new GodModeException('hsm-signature-suite-mismatch');
        $this->describe($keyId); // fail closed before transport
        $dir=sys_get_temp_dir().'/t0gm-hsm-'.bin2hex(random_bytes(8)); if(!mkdir($dir,0700,true)) throw new GodModeException('hsm-tempdir-create-failed');
        $msg=$dir.'/message'; $sig=$dir.'/signature'; file_put_contents($msg,$message); chmod($msg,0600);
        $cmd=array_merge([$this->openssl,'pkeyutl','-sign','-inkey',(string)$c['key_uri'],'-in',$msg,'-out',$sig],$this->providerArgs);
        try { $this->run($cmd); $raw=@file_get_contents($sig); if($raw===false||$raw==='') throw new GodModeException('hsm-empty-signature'); return $raw; }
        finally { @unlink($msg); @unlink($sig); @rmdir($dir); }
    }
    private function config(string $id): array { if(!isset($this->keys[$id])) throw new GodModeException('unknown-hsm-key:' . $id); return (array)$this->keys[$id]; }
    private function run(array $cmd): void {
        $spec=[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']]; $p=proc_open($cmd,$spec,$pipes);
        if(!is_resource($p)) throw new GodModeException('hsm-openssl-start-failed'); fclose($pipes[0]); stream_get_contents($pipes[1]); fclose($pipes[1]); $err=stream_get_contents($pipes[2]); fclose($pipes[2]); $code=proc_close($p);
        if($code!==0) throw new GodModeException('hsm-sign-operation-failed:' . substr(hash('sha256',$err),0,16));
    }
}
