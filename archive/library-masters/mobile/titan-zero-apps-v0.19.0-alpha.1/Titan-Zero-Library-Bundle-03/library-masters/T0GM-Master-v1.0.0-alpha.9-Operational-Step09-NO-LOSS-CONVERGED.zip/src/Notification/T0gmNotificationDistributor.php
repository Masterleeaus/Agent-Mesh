<?php
namespace Titan\GodMode\Notification;

use Titan\GodMode\Ranking\T0gmAttentionScorer;

final class T0gmNotificationDistributor
{
    private array $distributed=[];
    public function __construct(
        private readonly T0gmNotificationPolicy $policy,
        private readonly T0gmNotificationTransportRegistry $transports,
        private readonly T0gmAttentionScorer $scorer=new T0gmAttentionScorer(),
    ) {}

    /** Distribution is a projection only: it never grants authority or mutates the canonical event. */
    public function distribute(array $event,array $endpoints): array
    {
        $attention=$this->scorer->score($event);
        if (!$this->policy->shouldNotify($attention->tier)) return ['state'=>'below-threshold','event_id'=>$event['event_id'],'receipts'=>[]];
        $message=$this->message($event,$attention->tier,$attention->reasonCodes);
        $receipts=[];
        foreach($endpoints as $endpoint){
            if (!$endpoint instanceof T0gmNotificationEndpoint || !$this->policy->permits($endpoint)) continue;
            $dedupe=$message->eventId.'|'.$endpoint->endpointId;
            if(isset($this->distributed[$dedupe])) { $receipts[]=$this->distributed[$dedupe]; continue; }
            $transport=$this->transports->get($endpoint->channel);
            $receipt=$transport
                ? $transport->deliver($message,$endpoint)
                : new T0gmNotificationDeliveryReceipt($message->notificationId,$endpoint->endpointId,$endpoint->channel,'failed',gmdate('Y-m-d\TH:i:s\Z'),null,'transport-unavailable');
            $this->distributed[$dedupe]=$receipt;
            $receipts[]=$receipt;
        }
        return ['state'=>'distributed','event_id'=>$event['event_id'],'notification'=>$message,'receipts'=>$receipts];
    }

    private function message(array $event,string $tier,array $reasons): T0gmNotificationMessage
    {
        $kind=(string)($event['event_kind'] ?? 'event');
        $subject=(string)($event['subject']['subject_type'] ?? 'subject').':'.(string)($event['subject']['subject_id'] ?? 'unknown');
        // Deliberately excludes evidence bodies, secrets, credentials, request proofs and raw target payloads.
        $summary=strtoupper($tier).' T0GM '.$kind.' — '.$subject;
        return new T0gmNotificationMessage(
            't0gm_note_'.hash('sha256',(string)$event['event_id'].'|'.$tier),
            (string)$event['event_id'],$tier,'T0GM '.ucfirst($tier).' Event',$summary,
            (string)($event['company_context']['scope'] ?? 'unknown'),
            isset($event['company_context']['company_id'])?(string)$event['company_context']['company_id']:null,
            array_values(array_unique($reasons)),
            (string)($event['lineage']['correlation_id'] ?? ''),gmdate('Y-m-d\TH:i:s\Z')
        );
    }
}
