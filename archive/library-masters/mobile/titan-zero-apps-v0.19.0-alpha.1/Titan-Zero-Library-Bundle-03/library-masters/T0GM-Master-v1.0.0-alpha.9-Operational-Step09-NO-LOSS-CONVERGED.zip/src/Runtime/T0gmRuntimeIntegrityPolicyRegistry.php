<?php
namespace Titan\GodMode\Runtime;

use Titan\GodMode\Security\GodModeException;

final class T0gmRuntimeIntegrityPolicyRegistry
{
    private array $policies=[];
    public function __construct(array $policies)
    {
        foreach($policies as $workloadId=>$p){
            $class=(string)($p['workload_class']??'');
            $policyId=trim((string)($p['policy_id']??''));
            $rev=(int)($p['policy_revision']??0);
            $status=(string)($p['status']??'active');
            if(!in_array($class,['server','service','container','workload'],true)||$policyId===''||$rev<1) throw new \InvalidArgumentException('invalid-runtime-integrity-policy:'.$workloadId);
            if(!in_array($status,['active','retired','revoked'],true)) throw new \InvalidArgumentException('invalid-runtime-integrity-policy-status:'.$workloadId);
            foreach(['company_id','tenant_id','tenant_company_id','capability_id','authority','permission','role_id'] as $forbidden){
                if(array_key_exists($forbidden,$p)) throw new \InvalidArgumentException('authority-bearing-runtime-policy-forbidden:'.$workloadId.':'.$forbidden);
            }
            $code=array_values(array_unique(array_map('strval',(array)($p['trusted_code_digests']??[]))));
            $config=array_values(array_unique(array_map('strval',(array)($p['trusted_config_digests']??[]))));
            $env=array_values(array_unique(array_map('strval',(array)($p['trusted_environment_digests']??[]))));
            if($code===[]||$config===[]||$env===[]) throw new \InvalidArgumentException('runtime-integrity-trusted-digests-required:'.$workloadId);
            $this->policies[(string)$workloadId]=[
                'workload_id'=>(string)$workloadId,'workload_class'=>$class,'policy_id'=>$policyId,'policy_revision'=>$rev,'status'=>$status,
                'trusted_code_digests'=>$code,'trusted_config_digests'=>$config,'trusted_environment_digests'=>$env,
                'required_claims'=>is_array($p['required_claims']??null)?$p['required_claims']:[],
            ];
        }
    }
    public function active(string $workloadId,string $class,string $policyId,int $revision):array
    {
        if(!isset($this->policies[$workloadId])) throw new GodModeException('unknown-runtime-integrity-policy');
        $p=$this->policies[$workloadId];
        if($p['status']!=='active') throw new GodModeException('runtime-integrity-policy-not-active');
        if($p['workload_class']!==$class) throw new GodModeException('runtime-workload-class-mismatch');
        if($p['policy_id']!==$policyId||$p['policy_revision']!==$revision) throw new GodModeException('runtime-integrity-policy-version-mismatch');
        return $p;
    }
}
