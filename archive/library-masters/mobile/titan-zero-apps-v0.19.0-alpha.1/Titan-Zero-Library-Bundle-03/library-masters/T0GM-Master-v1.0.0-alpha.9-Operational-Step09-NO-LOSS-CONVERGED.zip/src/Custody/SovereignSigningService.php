<?php
namespace Titan\GodMode\Custody;

use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class SovereignSigningService
{
    public function __construct(
        private readonly SovereignKeyCustodyRegistry $registry,
        private readonly SovereignKeyCustodyPolicy $policy,
    ) {}

    /**
     * @param array<int,array{provider_id:string,key_id:string}> $keyRefs
     * @return array<int,array{key_id:string,suite:string,signature:string,custody:array}>
     */
    public function signIdentityPayload(array $payload,array $keyRefs,array $requiredSuites): array
    {
        return $this->signCanonicalPayload($payload,$keyRefs,$requiredSuites,'sovereign_identity');
    }

    /**
     * Signs a canonical payload with hardware-bound keys for an explicitly allowed purpose.
     * This returns proof of provenance only; callers must not treat a signature as execution authority.
     *
     * @param array<int,array{provider_id:string,key_id:string}> $keyRefs
     * @return array<int,array{key_id:string,suite:string,signature:string,custody:array}>
     */
    public function signCanonicalPayload(array $payload,array $keyRefs,array $requiredSuites,string $purpose): array
    {
        $handles=[]; $providers=[];
        foreach($keyRefs as $ref){
            $provider=$this->registry->provider((string)($ref['provider_id']??''));
            $handle=$provider->describe((string)($ref['key_id']??''));
            if($handle->providerId!==$provider->providerId()) throw new GodModeException('custody-provider-handle-mismatch');
            $handles[]=$handle; $providers[]=$provider;
        }
        $this->policy->assertSigningSet($handles,$requiredSuites,$purpose);
        $message=CanonicalJson::encode($payload); $out=[];
        foreach($handles as $i=>$handle){
            $sig=$providers[$i]->sign($handle->keyId,$handle->suite,$message,[
                'purpose'=>$purpose,'payload_hash'=>hash('sha256',$message),
            ]);
            if($sig==='') throw new GodModeException('empty-hardware-signature:' . $handle->keyId);
            $out[]=[
                'key_id'=>$handle->keyId,'suite'=>$handle->suite,'signature'=>base64_encode($sig),
                'custody'=>array_diff_key($handle->publicDescriptor(),['public_key'=>true]),
            ];
        }
        return $out;
    }
}
