<?php
namespace Titan\GodMode\Oversight;

final class T0gmOversightDisposition
{
    public const CLEAR = 'clear';
    public const WATCH = 'watch';
    public const INVESTIGATE = 'investigate';
    public const OBJECT = 'object';
    public const CONTAIN = 'contain';
    public const UNCERTAIN = 'uncertain';
    public static function all(): array { return [self::CLEAR,self::WATCH,self::INVESTIGATE,self::OBJECT,self::CONTAIN,self::UNCERTAIN]; }
}
