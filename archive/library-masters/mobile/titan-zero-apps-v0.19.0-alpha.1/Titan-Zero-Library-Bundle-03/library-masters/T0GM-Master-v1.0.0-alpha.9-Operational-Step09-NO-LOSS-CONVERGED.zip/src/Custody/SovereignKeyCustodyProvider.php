<?php
namespace Titan\GodMode\Custody;

interface SovereignKeyCustodyProvider
{
    public function providerId(): string;
    public function describe(string $keyId): SovereignKeyHandle;
    /** Returns a detached signature. Private key bytes must never leave the provider boundary. */
    public function sign(string $keyId, string $suite, string $message, array $context = []): string;
}
