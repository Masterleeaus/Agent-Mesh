<?php
namespace Titan\GodMode\Live;

final class T0gmWorldStateDigest
{
    public function digest(array $world): string
    {
        $copy=$world;
        $this->sortRecursive($copy);
        return hash('sha256', json_encode($copy, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
    }
    private function sortRecursive(array &$value): void
    {
        if (!array_is_list($value)) ksort($value, SORT_STRING);
        foreach ($value as &$child) if (is_array($child)) $this->sortRecursive($child);
    }
}
