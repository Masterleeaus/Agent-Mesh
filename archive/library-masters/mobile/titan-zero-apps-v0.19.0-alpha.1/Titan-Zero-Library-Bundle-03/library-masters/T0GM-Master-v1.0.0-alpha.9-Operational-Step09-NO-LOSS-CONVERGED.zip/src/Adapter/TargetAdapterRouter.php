<?php
namespace Titan\GodMode\Adapter;

final class TargetAdapterRouter
{
    public function __construct(private readonly TargetAdapterRegistry $registry = new TargetAdapterRegistry()) {}

    public function prepare(array $capability, array $request): TargetAdapterResult
    {
        try {
            return $this->registry->resolve($request['target'] ?? [])->prepare($capability, $request);
        } catch (TargetAdapterException $e) {
            return new TargetAdapterResult(false, 'unresolved', [$e->getMessage()], null, [
                'capability_id' => $capability['capability_id'] ?? null,
                'company_id' => $request['company_id'] ?? null,
            ]);
        }
    }
}
