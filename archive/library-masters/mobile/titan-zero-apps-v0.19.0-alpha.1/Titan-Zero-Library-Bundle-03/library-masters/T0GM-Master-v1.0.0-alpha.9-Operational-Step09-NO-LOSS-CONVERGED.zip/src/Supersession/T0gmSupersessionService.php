<?php
namespace Titan\GodMode\Supersession;

use Titan\GodMode\Contracts\SovereignActivityStore;
use Titan\GodMode\Event\T0gmCanonicalHasher;
use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedIngestor;

/** Creates the immutable sovereign supersession and plans its causal consequences. */
final class T0gmSupersessionService
{
    public function __construct(
        private readonly SovereignActivityStore $store,
        private readonly T0gmEventFactory $events = new T0gmEventFactory(),
        private readonly T0gmCanonicalHasher $hasher = new T0gmCanonicalHasher(),
        private readonly T0gmDependencyClassifier $classifier = new T0gmDependencyClassifier(),
    ) {}

    public function supersede(string $targetEventId, T0gmFeedAccessContext $access, string $t0gmActorId, string $directive, array $evidence = []): T0gmSupersessionPlan
    {
        if (!$access->isSovereign()) throw new \RuntimeException('t0gm-sovereign-access-required');
        $targetRecord = $this->store->get($targetEventId, $access);
        if ($targetRecord === null) throw new \RuntimeException('supersession-target-not-found');
        $target = $targetRecord['event'];

        $event = $this->events->make(
            T0gmEventKind::SUPERSESSION,
            $target['company_context'],
            ['actor_type'=>'human','actor_id'=>$t0gmActorId,'authority_class'=>'titan.god_mode'],
            ['system'=>'titan.t0gm','component'=>'god-mode-supersession'],
            $target['subject'],
            ['trace_id'=>$target['lineage']['trace_id'],'correlation_id'=>$target['lineage']['correlation_id'],'causation_id'=>$targetEventId,'parent_event_ids'=>[$targetEventId]],
            $target['risk'],
            ['visibility'=>'t0gm_sovereign','attention_tier'=>'critical','review_required'=>true,'review_team'=>['governance','causal','security']],
            $evidence,
            ['supersession'=>[
                'supersession_id'=>'t0gm_sup_'.bin2hex(random_bytes(12)),
                'supersedes_event_ids'=>[$targetEventId],
                'directive'=>$directive,
                'no_prior_escalation_required'=>true,
                'truth_preservation'=>true,
            ]]
        );
        $event = $this->hasher->seal($event);
        $record = $this->store->append($event);

        $discovery = new T0gmCausalDependencyDiscovery($this->store);
        $actions = [];
        $unresolved = [];
        foreach ($discovery->descendants($targetEventId, $access) as $dep) {
            if (($dep['event_id'] ?? '') === $event['event_id']) continue;
            if (!is_array($dep['event'])) { $unresolved[] = $dep['event_id']; continue; }
            if (($dep['event']['event_kind'] ?? null) === T0gmEventKind::SUPERSESSION && in_array($targetEventId, $dep['event']['supersession']['supersedes_event_ids'] ?? [], true)) continue;
            $actions[] = $this->classifier->classify($dep['event'], $dep['depth']);
        }
        return new T0gmSupersessionPlan($record['event_id'], $targetEventId, $actions, array_values(array_unique($unresolved)));
    }
}
