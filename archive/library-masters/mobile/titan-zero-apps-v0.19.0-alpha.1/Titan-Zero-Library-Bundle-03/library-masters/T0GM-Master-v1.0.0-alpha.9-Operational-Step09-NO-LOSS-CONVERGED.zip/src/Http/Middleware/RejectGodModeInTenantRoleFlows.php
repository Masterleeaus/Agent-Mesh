<?php
namespace Titan\GodMode\Http\Middleware;

use Closure;
use Titan\GodMode\Policy\RoleConfigurationGuard;

final class RejectGodModeInTenantRoleFlows
{
    public function __construct(private readonly RoleConfigurationGuard $guard) {}

    public function handle($request, Closure $next)
    {
        $payload = method_exists($request, 'all') ? $request->all() : [];
        $this->guard->validateRoleDefinition((array) $payload);
        return $next($request);
    }
}
