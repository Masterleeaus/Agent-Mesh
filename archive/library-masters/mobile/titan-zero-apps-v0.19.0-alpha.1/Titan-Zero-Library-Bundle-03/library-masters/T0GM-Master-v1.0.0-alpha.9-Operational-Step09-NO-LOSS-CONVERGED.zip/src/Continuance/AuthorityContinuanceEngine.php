<?php
namespace Titan\GodMode\Continuance;

use Titan\GodMode\Capability\SovereignCapabilityHasher;
use Titan\GodMode\Capability\SovereignCapabilityValidator;

/** Live justification evaluator. Time may be evidence, but never mints authority by TTL. */
final class AuthorityContinuanceEngine
{
    public function __construct(
        private readonly SovereignCapabilityValidator $validator = new SovereignCapabilityValidator(),
        private readonly SovereignCapabilityHasher $hasher = new SovereignCapabilityHasher(),
    ) {}

    public function evaluate(array $capability, array $world): AuthorityContinuanceDecision
    {
        try { $this->validator->validate($capability); } catch (\Throwable $e) {
            return new AuthorityContinuanceDecision(AuthorityContinuanceOutcome::TERMINATE, ['invalid_capability']);
        }
        if (!$this->hasher->verify($capability)) return new AuthorityContinuanceDecision(AuthorityContinuanceOutcome::TERMINATE, ['capability_integrity_failed']);

        $terminate = [];
        if (($world['company_id'] ?? null) !== $capability['company_id']) $terminate[] = 'company_boundary_changed';
        if (($world['purpose_valid'] ?? null) !== true) $terminate[] = 'purpose_no_longer_valid';
        if (($world['authority_basis_valid'] ?? null) !== true) $terminate[] = 'authority_basis_no_longer_valid';
        if (($world['target_valid'] ?? null) !== true) $terminate[] = 'target_no_longer_valid';
        if (($world['explicit_termination'] ?? false) === true) $terminate[] = 'sovereign_termination';
        if (($world['extinction_condition_triggered'] ?? false) === true) $terminate[] = 'extinction_condition_triggered';
        if (($world['device_quarantined'] ?? false) === true) $terminate[] = 'originating_device_quarantined';
        if ($terminate !== []) return new AuthorityContinuanceDecision(AuthorityContinuanceOutcome::TERMINATE, $terminate);

        if (($world['transformation_required'] ?? false) === true) {
            return new AuthorityContinuanceDecision(AuthorityContinuanceOutcome::TRANSFORM, ['authority_shape_requires_fresh_capability'], [], [
                'predecessor_capability_id' => $capability['capability_id'],
                'requested_purpose' => $world['transformation_purpose'] ?? $capability['purpose']['statement'],
                'requested_effect_ids' => array_values($world['requested_effect_ids'] ?? []),
                'requires_fresh_sovereign_authorization' => true,
            ]);
        }

        $pause = [];
        foreach (['evidence_valid','risk_acceptable','safety_satisfied','contractual_scope_valid','jurisdiction_valid','execution_path_legitimate','dependencies_healthy'] as $field) {
            if (($world[$field] ?? null) !== true) $pause[] = $field . '_not_proven';
        }
        if (($world['runtime_integrity_required'] ?? false) === true && ($world['runtime_integrity_valid'] ?? null) !== true) $pause[] = 'runtime_integrity_not_proven';
        if (($world['attestation_required'] ?? false) === true && ($world['attestation_valid'] ?? null) !== true) $pause[] = 'attestation_not_proven';
        if (($world['human_presence_required'] ?? false) === true && ($world['human_present'] ?? null) !== true) $pause[] = 'required_human_presence_lost';
        if ($pause !== []) return new AuthorityContinuanceDecision(AuthorityContinuanceOutcome::PAUSE, $pause);

        if (isset($world['retained_effect_ids'])) {
            $original = array_values(array_map(fn($e) => $e['effect_id'], $capability['permitted_effects']));
            $retained = array_values(array_unique(array_filter($world['retained_effect_ids'], fn($id) => in_array($id, $original, true))));
            if (count($retained) < count($original)) return new AuthorityContinuanceDecision(AuthorityContinuanceOutcome::NARROW, ['live_state_justifies_reduced_effect_set'], $retained);
        }

        return new AuthorityContinuanceDecision(AuthorityContinuanceOutcome::CONTINUE, ['current_reality_continues_to_justify_capability']);
    }
}
