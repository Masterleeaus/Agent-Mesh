<?php
namespace Titan\GodMode\Infrastructure;

final class InfrastructureExecutionResult
{
    public function __construct(
        public readonly bool $succeeded,
        public readonly string $transport,
        public readonly array $actualState,
        public readonly array $receipt,
        public readonly array $evidence = [],
        public readonly array $errors = [],
    ) {}
}
