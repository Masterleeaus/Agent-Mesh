<?php
namespace Titan\GodMode\Ranking;

use Titan\GodMode\Feed\T0gmFeedException;

final class T0gmAttentionSignals
{
    public function __construct(
        public readonly int $risk,
        public readonly int $significance,
        public readonly int $anomaly,
        public readonly int $urgency,
        public readonly int $reversibility,
        public readonly int $financialExposure,
        public readonly int $physicalImpact,
        public readonly int $environmentalImpact,
        public readonly int $confidence,
        public readonly int $dependency,
        public readonly array $domains = [],
    ) {
        foreach ([
            'risk'=>$risk,'significance'=>$significance,'anomaly'=>$anomaly,'urgency'=>$urgency,
            'reversibility'=>$reversibility,'financial_exposure'=>$financialExposure,
            'physical_impact'=>$physicalImpact,'environmental_impact'=>$environmentalImpact,
            'confidence'=>$confidence,'dependency'=>$dependency,
        ] as $name => $value) {
            if ($value < 0 || $value > 100) throw new T0gmFeedException('invalid-attention-signal', $name);
        }
        foreach ($domains as $domain) {
            if (!is_string($domain) || trim($domain) === '') throw new T0gmFeedException('invalid-attention-domain');
        }
    }

    public function irreversibility(): int { return 100 - $this->reversibility; }

    public function toArray(): array
    {
        return [
            'risk'=>$this->risk,
            'significance'=>$this->significance,
            'anomaly'=>$this->anomaly,
            'urgency'=>$this->urgency,
            'reversibility'=>$this->reversibility,
            'irreversibility'=>$this->irreversibility(),
            'financial_exposure'=>$this->financialExposure,
            'physical_impact'=>$this->physicalImpact,
            'environmental_impact'=>$this->environmentalImpact,
            'confidence'=>$this->confidence,
            'dependency'=>$this->dependency,
            'domains'=>$this->domains,
        ];
    }

    public static function fromEvent(array $event): self
    {
        $explicit = is_array($event['attention_signals'] ?? null) ? $event['attention_signals'] : [];
        $dimensions = is_array($event['risk']['dimensions'] ?? null) ? $event['risk']['dimensions'] : [];
        $risk = self::score($event['risk']['score'] ?? 0);
        $kind = (string)($event['event_kind'] ?? '');
        $oversightTier = (string)($event['oversight']['attention_tier'] ?? 'routine');

        $domains = $explicit['domains'] ?? [];
        if (!is_array($domains)) throw new T0gmFeedException('invalid-attention-domains');
        foreach (array_keys($dimensions) as $dimension) {
            if (is_string($dimension)) $domains[] = strtolower($dimension);
        }
        $domains = array_values(array_unique(array_map(static fn($v) => strtolower(trim((string)$v)), $domains)));

        $significance = self::score($explicit['significance'] ?? max($risk, self::tierScore($oversightTier)));
        $anomaly = self::score($explicit['anomaly'] ?? ($kind === 'anomaly' ? max(70, $risk) : self::dimension($dimensions, ['anomaly','systemic'])));
        $urgency = self::score($explicit['urgency'] ?? self::tierScore($oversightTier));
        $reversibility = self::score($explicit['reversibility'] ?? self::deriveReversibility($event));
        $financial = self::score($explicit['financial_exposure'] ?? self::dimension($dimensions, ['financial','finance','money','economic']));
        $physical = self::score($explicit['physical_impact'] ?? self::dimension($dimensions, ['physical','safety','human_safety','operational_safety']));
        $environmental = self::score($explicit['environmental_impact'] ?? self::dimension($dimensions, ['environmental','environment','ecological','resource']));
        $confidence = self::score($explicit['confidence'] ?? self::deriveConfidence($event));
        $dependency = self::score($explicit['dependency'] ?? self::deriveDependency($event));

        return new self($risk,$significance,$anomaly,$urgency,$reversibility,$financial,$physical,$environmental,$confidence,$dependency,$domains);
    }

    private static function score(mixed $value): int
    {
        if (is_float($value)) $value = (int)round($value);
        if (!is_int($value)) throw new T0gmFeedException('invalid-attention-signal');
        if ($value < 0 || $value > 100) throw new T0gmFeedException('invalid-attention-signal');
        return $value;
    }

    private static function tierScore(string $tier): int
    {
        return match ($tier) {
            'critical' => 100,
            'urgent' => 82,
            'important' => 62,
            'watch' => 38,
            default => 15,
        };
    }

    private static function dimension(array $dimensions, array $names): int
    {
        $max = 0;
        foreach ($dimensions as $key => $value) {
            if (!is_string($key) || !in_array(strtolower($key), $names, true)) continue;
            if (is_int($value)) $max = max($max, min(100, max(0, $value)));
        }
        return $max;
    }

    private static function deriveReversibility(array $event): int
    {
        foreach (['execution','result','action','intervention','decision'] as $section) {
            $value = $event[$section]['reversibility'] ?? null;
            if (is_int($value)) return min(100, max(0, $value));
            if (is_string($value)) {
                return match (strtolower($value)) {
                    'fully_reversible','reversible','easy' => 90,
                    'partially_reversible','partial' => 55,
                    'difficult','hard_to_reverse' => 25,
                    'irreversible','none' => 0,
                    default => 50,
                };
            }
        }
        return match ((string)($event['event_kind'] ?? '')) {
            'observation','ai_decision' => 100,
            'authority_use' => 70,
            'execution','human_action','intervention' => 50,
            'supersession' => 80,
            default => 60,
        };
    }

    private static function deriveConfidence(array $event): int
    {
        foreach (['decision','observation','anomaly','result'] as $section) {
            $value = $event[$section]['confidence'] ?? null;
            if (is_int($value)) return min(100, max(0, $value));
        }
        return count($event['evidence'] ?? []) > 0 ? 75 : 50;
    }

    private static function deriveDependency(array $event): int
    {
        $parents = count($event['lineage']['parent_event_ids'] ?? []);
        $hasCause = !empty($event['lineage']['causation_id']);
        $targets = count($event['supersession']['supersedes_event_ids'] ?? []);
        return min(100, ($parents * 15) + ($hasCause ? 20 : 0) + ($targets * 20));
    }
}
