<?php
namespace Titan\GodMode\Notification;

final class T0gmNotificationChannel
{
    public const DESKTOP='desktop';
    public const BROWSER='browser';
    public const MOBILE='mobile';
    public const EXTERNAL='external';
    public static function all(): array { return [self::DESKTOP,self::BROWSER,self::MOBILE,self::EXTERNAL]; }
}
