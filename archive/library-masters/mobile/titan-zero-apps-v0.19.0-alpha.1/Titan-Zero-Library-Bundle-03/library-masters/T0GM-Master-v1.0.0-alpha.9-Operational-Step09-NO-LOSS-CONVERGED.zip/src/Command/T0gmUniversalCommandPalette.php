<?php
namespace Titan\GodMode\Command;
use Titan\GodMode\App\T0gmCommandSurface;
use Titan\GodMode\App\T0gmDeviceState;
use Titan\GodMode\App\T0gmSovereignSessionContext;
use Titan\GodMode\Security\GodModeException;
final class T0gmUniversalCommandPalette
{
    public function __construct(private readonly T0gmCommandTargetRegistry $registry,private readonly T0gmCommandSurface $surface,private readonly T0gmSovereignSessionContext $session,private readonly T0gmDeviceState $device){}
    public function search(string $query,int $limit=50):array{return $this->registry->search($query,$limit);}
    public function inspect(string $type,string $id,string $companyId):array
    {
        $target=$this->registry->get($type,$id,$companyId);
        return ['schema'=>'titan.t0gm.command_palette_inspection.v1','target'=>$target,'projection_only'=>true,'authority_granted'=>false,'execution_authority_granted'=>false];
    }
    public function issue(array $command):array
    {
        foreach(['tenant_id','tenant_company_id'] as $f)if(array_key_exists($f,$command))throw new GodModeException('legacy-tenant-boundary-forbidden:'.$f);
        $company=(string)($command['company_id']??''); $target=(array)($command['target']??[]); $type=(string)($target['target_type']??''); $id=(string)($target['target_id']??'');
        if($company!==''&&$type!==''&&$id!==''){
            try{$this->registry->get($type,$id,$company);}catch(GodModeException $e){ if($e->getMessage()==='palette-target-not-found'){try{$this->registry->resolveAnyCompany($type,$id);throw new GodModeException('palette-target-company-mismatch');}catch(GodModeException $x){if($x->getMessage()==='palette-target-company-mismatch')throw $x;}} throw $e; }
        }
        if(!$this->device->commandEligible())throw new GodModeException('t0gm-device-not-command-eligible');
        return $this->surface->createIntent($command,$this->session->toArray(),$this->device->toArray())+['issued_via'=>'t0gm_universal_command_palette'];
    }
}
