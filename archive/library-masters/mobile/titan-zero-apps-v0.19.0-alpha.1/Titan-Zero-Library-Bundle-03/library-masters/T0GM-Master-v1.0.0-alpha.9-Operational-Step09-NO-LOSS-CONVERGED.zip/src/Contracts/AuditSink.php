<?php
namespace Titan\GodMode\Contracts;

interface AuditSink
{
    public function record(array $event): void;
}
