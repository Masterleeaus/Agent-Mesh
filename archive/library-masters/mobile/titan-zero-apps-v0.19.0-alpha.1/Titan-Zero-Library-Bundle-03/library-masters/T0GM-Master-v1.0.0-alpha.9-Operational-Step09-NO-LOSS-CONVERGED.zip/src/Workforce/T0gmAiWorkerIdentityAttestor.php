<?php
namespace Titan\GodMode\Workforce;

use Titan\GodMode\Security\GodModeException;

final class T0gmAiWorkerIdentityAttestor
{
    public function __construct(private readonly T0gmCanonicalAiWorkforceRegistry $registry) {}

    public function attest(string $companyId,string $workerId,array $evidence): array
    {
        foreach (['tenant_id','tenant_company_id'] as $legacy) {
            if (array_key_exists($legacy,$evidence)) throw new GodModeException('legacy-tenant-boundary-forbidden:'.$legacy);
        }

        $worker=$this->registry->get($companyId,$workerId);
        if (($worker['kind']??null)!=='worker') throw new GodModeException('ai-worker-registry-kind-required');
        if (($worker['lifecycle_state']??'registered')==='retired') throw new GodModeException('ai-worker-retired');

        $workload=$evidence['workload_identity']??null;
        if(!is_array($workload)) throw new GodModeException('ai-worker-workload-identity-required');
        if(($workload['cryptographic_workload_identity']??false)!==true) throw new GodModeException('ai-worker-workload-identity-invalid');
        if(($workload['authority_granted']??false)!==false || ($workload['company_authority_granted']??false)!==false) throw new GodModeException('ai-worker-workload-evidence-authority-invalid');
        foreach(['workload_id','workload_class','binding_id'] as $f) if(trim((string)($workload[$f]??''))==='') throw new GodModeException('ai-worker-workload-field-required:'.$f);

        $runtime=$evidence['runtime_integrity']??null;
        if(!is_array($runtime)) throw new GodModeException('ai-worker-runtime-integrity-required');
        if(($runtime['runtime_integrity_valid']??false)!==true) throw new GodModeException('ai-worker-runtime-integrity-invalid');
        if(($runtime['authority_granted']??false)!==false || ($runtime['company_authority_granted']??false)!==false || ($runtime['t0gm_authority_granted']??false)!==false) {
            throw new GodModeException('ai-worker-runtime-evidence-authority-invalid');
        }
        foreach(['policy_id','policy_revision','code_digest','config_digest','environment_digest'] as $f) {
            if(!isset($runtime[$f]) || (is_string($runtime[$f]) && trim($runtime[$f])==='')) throw new GodModeException('ai-worker-runtime-field-required:'.$f);
        }

        $modelIds=(array)($worker['model_ids']??[]);
        if($modelIds===[]) throw new GodModeException('ai-worker-model-binding-required');
        $requested=trim((string)($evidence['model_id']??$modelIds[0]));
        if(!in_array($requested,$modelIds,true)) throw new GodModeException('ai-worker-model-not-authorized-by-registry');
        $model=$this->registry->get($companyId,$requested);
        if(($model['kind']??null)!=='model') throw new GodModeException('ai-worker-model-registry-kind-invalid');

        $provenance=$evidence['runtime_provenance']??[];
        if(!is_array($provenance)) throw new GodModeException('ai-worker-runtime-provenance-invalid');
        $observedAt=trim((string)($evidence['observed_at']??''));
        if($observedAt==='') throw new GodModeException('ai-worker-observed-at-required');

        $envelope=[
            'schema'=>'titan.t0gm.ai-worker-identity-attestation.v1',
            'company_id'=>$companyId,
            'worker_id'=>$workerId,
            'worker_registry_revision'=>(int)($worker['lifecycle_revision']??1),
            'worker'=>[
                'name'=>(string)$worker['name'],
                'lifecycle_state'=>(string)$worker['lifecycle_state'],
                'registry_integrity_digest'=>(string)$worker['integrity_digest'],
            ],
            'model'=>[
                'registry_id'=>$requested,
                'name'=>(string)$model['name'],
                'provider'=>$model['provider']??null,
                'model_ref'=>$model['model_ref']??null,
                'registry_integrity_digest'=>(string)$model['integrity_digest'],
            ],
            'runtime'=>[
                'workload_id'=>(string)$workload['workload_id'],
                'workload_class'=>(string)$workload['workload_class'],
                'binding_id'=>(string)$workload['binding_id'],
                'measurement'=>$workload['measurement']??null,
                'policy_id'=>(string)$runtime['policy_id'],
                'policy_revision'=>(int)$runtime['policy_revision'],
                'code_digest'=>(string)$runtime['code_digest'],
                'config_digest'=>(string)$runtime['config_digest'],
                'environment_digest'=>(string)$runtime['environment_digest'],
                'provenance'=>$provenance,
            ],
            'integrity'=>[
                'cryptographic_workload_identity'=>true,
                'runtime_integrity_valid'=>true,
                'workload_evidence_digest'=>$this->digest($workload),
                'runtime_integrity_evidence_digest'=>$this->digest($runtime),
            ],
            'workload_identity_evidence'=>$workload,
            'runtime_integrity_evidence'=>$runtime,
            'observed_at'=>$observedAt,
            'identity_evidence_only'=>true,
            'authority_granted'=>false,
            'company_authority_granted'=>false,
            'execution_authority_granted'=>false,
            't0gm_authority_granted'=>false,
            'sovereign_authority_inherited'=>false,
        ];
        $envelope['identity_digest']=$this->digest($envelope);
        return $envelope;
    }

    public function verify(array $envelope): bool
    {
        if(($envelope['schema']??null)!=='titan.t0gm.ai-worker-identity-attestation.v1') throw new GodModeException('ai-worker-identity-schema-invalid');
        $companyId=trim((string)($envelope['company_id']??''));
        $workerId=trim((string)($envelope['worker_id']??''));
        if($companyId===''||$workerId==='') throw new GodModeException('ai-worker-identity-subject-invalid');

        $supplied=(string)($envelope['identity_digest']??'');
        $copy=$envelope; unset($copy['identity_digest']);
        $expected=$this->digest($copy);
        if(!preg_match('/^[a-f0-9]{64}$/',$supplied) || !hash_equals($expected,$supplied)) throw new GodModeException('ai-worker-identity-digest-mismatch');

        $worker=$this->registry->get($companyId,$workerId);
        if(($worker['kind']??null)!=='worker') throw new GodModeException('ai-worker-registry-kind-required');
        if(!hash_equals((string)$worker['integrity_digest'],(string)($envelope['worker']['registry_integrity_digest']??''))) throw new GodModeException('ai-worker-registry-state-mismatch');

        $modelId=(string)($envelope['model']['registry_id']??'');
        if(!in_array($modelId,(array)($worker['model_ids']??[]),true)) throw new GodModeException('ai-worker-model-not-authorized-by-registry');
        $model=$this->registry->get($companyId,$modelId);
        if(!hash_equals((string)$model['integrity_digest'],(string)($envelope['model']['registry_integrity_digest']??''))) throw new GodModeException('ai-worker-model-registry-state-mismatch');

        $workload=$envelope['workload_identity_evidence']??null;
        $runtime=$envelope['runtime_integrity_evidence']??null;
        if(!is_array($workload)||!is_array($runtime)) throw new GodModeException('ai-worker-evidence-missing');
        if(!hash_equals($this->digest($workload),(string)($envelope['integrity']['workload_evidence_digest']??''))) throw new GodModeException('ai-worker-workload-evidence-digest-mismatch');
        if(!hash_equals($this->digest($runtime),(string)($envelope['integrity']['runtime_integrity_evidence_digest']??''))) throw new GodModeException('ai-worker-runtime-evidence-digest-mismatch');
        if(($workload['cryptographic_workload_identity']??false)!==true) throw new GodModeException('ai-worker-workload-identity-invalid');
        if(($runtime['runtime_integrity_valid']??false)!==true) throw new GodModeException('ai-worker-runtime-integrity-invalid');

        foreach(['authority_granted','company_authority_granted','execution_authority_granted','t0gm_authority_granted','sovereign_authority_inherited'] as $f) {
            if(($envelope[$f]??null)!==false) throw new GodModeException('ai-worker-identity-authority-semantics-invalid:'.$f);
        }
        return true;
    }

    private function digest(array $value): string
    {
        return hash('sha256',json_encode($this->canonicalise($value),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION|JSON_THROW_ON_ERROR));
    }

    private function canonicalise(mixed $value): mixed
    {
        if(!is_array($value)) return $value;
        if(array_is_list($value)) return array_map(fn($v)=>$this->canonicalise($v),$value);
        ksort($value,SORT_STRING);
        foreach($value as $k=>$v)$value[$k]=$this->canonicalise($v);
        return $value;
    }
}
