<?php
namespace Titan\GodMode\Event;

use Titan\GodMode\Custody\SovereignSigningService;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmEventProvenanceSigner
{
    public function __construct(
        private readonly SovereignSigningService $signer,
        private readonly T0gmCanonicalHasher $hasher=new T0gmCanonicalHasher(),
    ) {}

    /** @param array<int,array{provider_id:string,key_id:string}> $keyRefs */
    public function sign(array $event,array $keyRefs,array $requiredSuites): array
    {
        if(!$this->hasher->verify($event)) throw new GodModeException('event-must-be-sealed-before-provenance-signing');
        $statement=$this->statement($event);
        $signatures=$this->signer->signCanonicalPayload($statement,$keyRefs,$requiredSuites,'event_provenance');
        $event['provenance']=[
            'schema'=>'titan.t0gm.event-provenance.v1',
            'statement_hash'=>hash('sha256',CanonicalJson::encode($statement)),
            'event_hash'=>$statement['event_hash'],
            'lineage_hash'=>$statement['lineage_hash'],
            'evidence_hash'=>$statement['evidence_hash'],
            'signatures'=>$signatures,
            'semantics'=>['attests'=>'origin_and_integrity','grants_authority'=>false,'constitutes_t0gm_approval'=>false],
        ];
        return $event;
    }

    public function statement(array $event): array
    {
        return [
            'schema'=>'titan.t0gm.event-provenance-statement.v1',
            'event_id'=>(string)($event['event_id']??''),
            'event_kind'=>(string)($event['event_kind']??''),
            'event_hash'=>(string)($event['integrity']['canonical_hash']??''),
            'company_scope'=>(string)($event['company_context']['scope']??''),
            'company_id'=>$event['company_context']['company_id']??null,
            'lineage_hash'=>hash('sha256',CanonicalJson::encode($event['lineage']??[])),
            'evidence_hash'=>hash('sha256',CanonicalJson::encode($event['evidence']??[])),
            'claim'=>'event-origin-and-integrity-without-authority-grant',
        ];
    }
}
