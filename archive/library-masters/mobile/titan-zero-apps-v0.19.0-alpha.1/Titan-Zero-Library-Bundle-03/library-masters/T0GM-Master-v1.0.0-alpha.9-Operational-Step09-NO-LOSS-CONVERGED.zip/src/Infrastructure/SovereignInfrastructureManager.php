<?php
namespace Titan\GodMode\Infrastructure;

use Titan\GodMode\Adapter\TargetAdapterRouter;
use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedIngestor;
use Titan\GodMode\Recovery\InMemoryT0gmStateTransitionStore;
use Titan\GodMode\Recovery\T0gmStateTransitionFactory;

final class SovereignInfrastructureManager
{
    public function __construct(
        private readonly InfrastructureExecutorRegistry $executors,
        private readonly T0gmFeedIngestor $feed,
        private readonly InMemoryT0gmStateTransitionStore $transitions,
        private readonly TargetAdapterRouter $router=new TargetAdapterRouter(),
        private readonly T0gmEventFactory $events=new T0gmEventFactory(),
        private readonly T0gmStateTransitionFactory $transitionFactory=new T0gmStateTransitionFactory(),
    ){}

    public function execute(array $capability,array $request):array
    {
        $prepared=$this->router->prepare($capability,$request);
        if(!$prepared->allowed||$prepared->nativeOperation===null) return ['allowed'=>false,'reasons'=>$prepared->reasons,'adapter'=>$prepared->adapterType];
        $native=$prepared->nativeOperation;
        if(($native['company_id']??null)!==($capability['company_id']??null)) throw new \RuntimeException('infrastructure-company-boundary-mismatch');
        $executor=$this->executors->resolve((string)($native['transport']??''));
        $pre=$executor->observe($native);
        $result=$executor->execute($native);
        $actual=$result->actualState;
        $intended=$request['intended_state']??null;
        if(!is_array($intended)) throw new \RuntimeException('infrastructure-intended-state-required');
        $reversibility=$request['reversibility']??null;
        if(!is_array($reversibility)) throw new \RuntimeException('infrastructure-reversibility-required');
        $evidence=array_values(array_merge($request['execution_evidence']??[],$result->evidence));
        $risk=$request['risk']??['score'=>100,'band'=>'unknown','dimensions'=>[]];
        if(!isset($risk['dimensions'])) $risk['dimensions']=[];
        $event=$this->events->make(T0gmEventKind::EXECUTION,
            ['scope'=>'company','company_id'=>$request['company_id']],
            $request['actor']??['actor_type'=>'human','actor_id'=>'t0gm','authority_class'=>'titan.god_mode'],
            ['system'=>'titan.t0gm','component'=>'sovereign-infrastructure-manager'],
            $request['subject']??['subject_type'=>'infrastructure','subject_id'=>$request['target']['target_id']],
            ['trace_id'=>$request['trace_id']??('infra-'.$capability['capability_id']),'correlation_id'=>$request['correlation_id']??('infra-'.$capability['capability_id']),'causation_id'=>$request['causation_id']??null,'parent_event_ids'=>array_values(array_filter([$request['causation_id']??null]))],
            $risk,
            ['visibility'=>'t0gm_sovereign','attention_tier'=>$result->succeeded?'important':'critical','review_required'=>!$result->succeeded,'review_team'=>['security','governance','operational','causal']],
            $evidence,
            ['execution'=>['execution_id'=>'t0gm_exec_'.bin2hex(random_bytes(12)),'state'=>$result->succeeded?'completed':'failed','adapter'=>$prepared->adapterType,'capability_id'=>$capability['capability_id'],'adapter_type'=>$prepared->adapterType,'transport'=>$result->transport,'operation'=>$native['operation']??null,'succeeded'=>$result->succeeded,'receipt'=>$result->receipt,'errors'=>$result->errors]]
        );
        $stored=$this->feed->ingest($event); $storedEvent=$stored['event'];
        $transition=$this->transitionFactory->make($request['company_id'],$storedEvent['event_id'],$capability['purpose']['statement']??'infrastructure operation',$storedEvent['subject'],$pre,$intended,$actual,$request['dependencies']??[],$reversibility,$evidence);
        $this->transitions->append($transition);
        return ['allowed'=>true,'succeeded'=>$result->succeeded,'adapter'=>$prepared->adapterType,'native_operation'=>$native,'execution_event'=>$storedEvent,'transition'=>$transition,'receipt'=>$result->receipt];
    }
}
