<?php
namespace Titan\GodMode\Notification;
final class T0gmPersistentNotificationOrchestrator
{
    public function __construct(private readonly FilePersistentNotificationStateStore $store) {}
    public function register(array $notification): array { return $this->store->create($notification); }
    public function recordAttempt(string $id,string $endpointId,bool $delivered,string $observedAt,?string $nextAttemptAt=null,?string $error=null): array {
        $s=$this->store->get($id); if($this->terminal($s)) return $s;
        $s['attempts'][]=['endpoint_id'=>$endpointId,'delivered'=>$delivered,'observed_at'=>$observedAt,'error'=>$error];
        if($delivered){$s['status']='delivered'; $s['delivered_at']=$observedAt; $s['next_attempt_at']=null;} else {$s['status']='retry_pending'; $s['next_attempt_at']=$nextAttemptAt;}
        return $this->store->save($s);
    }
    public function acknowledge(string $id,array $ack): array {
        foreach(['actor_id','device_id','channel','acknowledged_at'] as $f) if(empty($ack[$f])) throw new \RuntimeException('notification-ack-field-required:'.$f);
        $s=$this->store->get($id); if(($s['status']??'')==='acknowledged') return $s;
        $s['acknowledgements'][]=$ack; $s['status']='acknowledged'; $s['acknowledged_at']=$ack['acknowledged_at']; $s['next_attempt_at']=null; return $this->store->save($s);
    }
    public function escalate(string $id,string $reason,string $observedAt,array $endpoints=[]): array {
        $s=$this->store->get($id); if($this->terminal($s)) return $s; $s['escalation_level']=(int)$s['escalation_level']+1; $s['escalations'][]=['level'=>$s['escalation_level'],'reason'=>$reason,'observed_at'=>$observedAt,'endpoints'=>$endpoints]; $s['status']='escalated'; return $this->store->save($s);
    }
    public function due(string $now): array { return array_values(array_filter($this->store->all(),fn($s)=>!$this->terminal($s)&&($s['next_attempt_at']??null)!==null&&strcmp((string)$s['next_attempt_at'],$now)<=0)); }
    private function terminal(array $s): bool { return in_array($s['status']??'',['acknowledged','cancelled'],true); }
}
