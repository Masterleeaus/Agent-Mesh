<?php
namespace Titan\GodMode\Notification;

final class T0gmNotificationPolicy
{
    private const RANK=['routine'=>0,'watch'=>1,'important'=>2,'urgent'=>3,'critical'=>4];
    public function __construct(
        public readonly string $minimumTier='critical',
        public readonly array $channels=[T0gmNotificationChannel::DESKTOP,T0gmNotificationChannel::BROWSER,T0gmNotificationChannel::MOBILE],
        public readonly bool $allowExternal=false,
    ) {
        if (!isset(self::RANK[$minimumTier])) throw new \InvalidArgumentException('invalid-notification-tier');
        foreach ($channels as $channel) if (!in_array($channel,T0gmNotificationChannel::all(),true)) throw new \InvalidArgumentException('invalid-notification-channel');
    }
    public function shouldNotify(string $tier): bool { return (self::RANK[$tier] ?? -1) >= self::RANK[$this->minimumTier]; }
    public function permits(T0gmNotificationEndpoint $endpoint): bool {
        if (!$endpoint->enabled || !in_array($endpoint->channel,$this->channels,true)) return false;
        return $endpoint->channel !== T0gmNotificationChannel::EXTERNAL || ($this->allowExternal && $endpoint->selectedExternal);
    }
}
