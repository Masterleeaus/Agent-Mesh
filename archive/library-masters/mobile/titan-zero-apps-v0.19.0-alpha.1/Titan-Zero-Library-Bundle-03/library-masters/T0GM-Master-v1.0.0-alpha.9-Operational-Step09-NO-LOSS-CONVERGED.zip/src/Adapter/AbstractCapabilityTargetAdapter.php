<?php
namespace Titan\GodMode\Adapter;

use Titan\GodMode\Capability\SovereignCapabilityEvaluator;
use Titan\GodMode\Policy\ClientAuthorityPolicyEngine;

abstract class AbstractCapabilityTargetAdapter implements TargetAdapter
{
    public function __construct(
        private readonly SovereignCapabilityEvaluator $capabilityEvaluator = new SovereignCapabilityEvaluator(),
        private readonly ClientAuthorityPolicyEngine $clientAuthorityPolicy = new ClientAuthorityPolicyEngine(),
    ) {}

    final public function prepare(array $capability, array $request): TargetAdapterResult
    {
        $reasons = [];
        if (!$this->supports($request['target'] ?? [])) $reasons[] = 'adapter_target_not_supported';
        if (($request['company_id'] ?? null) !== ($capability['company_id'] ?? null)) $reasons[] = 'adapter_company_mismatch';

        $profile = $request['client_authority_profile'] ?? null;
        if (!is_array($profile)) {
            $reasons[] = 'client_authority_profile_required';
        } else {
            $policy = $this->clientAuthorityPolicy->evaluate($profile, $capability, $request);
            if (!$policy->allowed) foreach ($policy->reasons as $reason) $reasons[] = 'client_profile_denied:' . $reason;
        }

        $decision = $this->capabilityEvaluator->evaluate($capability, [
            'company_id' => $request['company_id'] ?? null,
            'target' => $request['target'] ?? [],
            'operation' => $request['operation'] ?? null,
            'resource_id' => $request['resource_id'] ?? null,
            'risk' => $request['risk'] ?? [],
            'evidence_ids' => $request['evidence_ids'] ?? [],
            'triggered_extinction_conditions' => $request['triggered_extinction_conditions'] ?? [],
        ]);
        if (!$decision->allowed) foreach ($decision->reasons as $reason) $reasons[] = 'capability_denied:' . $reason;

        if ($reasons !== []) return $this->denied($reasons, $capability, $request, $decision->matchedEffectId);

        try {
            $native = $this->mapAuthorizedOperation($request);
            $this->assertNoAuthoritySmuggling($native, $request);
        } catch (TargetAdapterException $e) {
            return $this->denied([$e->getMessage()], $capability, $request, $decision->matchedEffectId);
        }

        return new TargetAdapterResult(true, $this->adapterType(), [], $native, $this->lineage($capability, $request, $decision->matchedEffectId));
    }

    abstract protected function mapAuthorizedOperation(array $request): array;

    protected function allowedOperation(array $request, array $allowed): string
    {
        $operation = strtolower(trim((string)($request['operation'] ?? '')));
        if (!in_array($operation, $allowed, true)) throw new TargetAdapterException('adapter_operation_not_supported');
        return $operation;
    }

    private function assertNoAuthoritySmuggling(array $native, array $request): void
    {
        $encoded = strtolower(json_encode($native, JSON_UNESCAPED_SLASHES) ?: '');
        foreach (['company_id=*','tenant_id','tenant_company_id','grant god mode','role_level=999'] as $forbidden) {
            if (str_contains($encoded, $forbidden)) throw new TargetAdapterException('adapter_authority_smuggling_detected');
        }
        if (($native['company_id'] ?? ($request['company_id'] ?? null)) !== ($request['company_id'] ?? null)) {
            throw new TargetAdapterException('adapter_native_company_mismatch');
        }
    }

    private function denied(array $reasons, array $capability, array $request, ?string $effectId): TargetAdapterResult
    {
        return new TargetAdapterResult(false, $this->adapterType(), array_values(array_unique($reasons)), null, $this->lineage($capability, $request, $effectId));
    }

    private function lineage(array $capability, array $request, ?string $effectId): array
    {
        return array_filter([
            'capability_id' => $capability['capability_id'] ?? null,
            'effect_id' => $effectId,
            'company_id' => $request['company_id'] ?? null,
            'target_id' => $request['target']['target_id'] ?? null,
            'correlation_id' => $request['correlation_id'] ?? null,
            'intent_id' => $request['intent_id'] ?? null,
            'plan_id' => $request['plan_id'] ?? null,
            'client_authority_profile_id' => $request['client_authority_profile']['profile_id'] ?? null,
            'client_authority_profile_type' => $request['client_authority_profile']['profile_type'] ?? null,
        ], static fn($v) => $v !== null);
    }
}
