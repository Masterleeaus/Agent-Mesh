<?php
namespace Titan\GodMode\Custody;

use Titan\GodMode\Security\GodModeException;

final class SovereignKeyCustodyPolicy
{
    public function __construct(
        private readonly array $allowedCustodyClasses=['hsm','secure_enclave','tpm'],
        private readonly bool $requireDistinctCustodyDomains=true,
    ) {}

    /** @param SovereignKeyHandle[] $handles */
    public function assertSigningSet(array $handles, array $requiredSuites, string $purpose): void
    {
        if($handles===[]) throw new GodModeException('sovereign-signing-key-set-empty');
        $suiteSet=[]; $domains=[];
        foreach($handles as $h){
            if(!$h instanceof SovereignKeyHandle) throw new GodModeException('invalid-sovereign-key-handle-type');
            if(!$h->hardwareBacked || $h->exportable) throw new GodModeException('invalid-sovereign-key-custody');
            if(!in_array($h->custodyClass,$this->allowedCustodyClasses,true)) throw new GodModeException('untrusted-custody-class:' . $h->custodyClass);
            if(!in_array($purpose,$h->purposes,true)) throw new GodModeException('sovereign-key-purpose-not-allowed:' . $h->keyId);
            $suiteSet[$h->suite]=true; $domains[$h->custodyDomain]=true;
        }
        foreach($requiredSuites as $suite) if(!isset($suiteSet[$suite])) throw new GodModeException('required-custody-suite-missing:' . $suite);
        if($this->requireDistinctCustodyDomains && count($handles)>1 && count($domains)<count($handles)) throw new GodModeException('sovereign-signing-keys-must-use-distinct-custody-domains');
    }
}
