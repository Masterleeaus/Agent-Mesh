<?php
namespace Titan\GodMode\Verification;

final class T0gmVerificationStatus
{
    public const PENDING='pending';
    public const INVESTIGATING='investigating';
    public const CONVERGED='converged';
    public const SUPERSEDED='superseded';
    public const ACCEPTED_VARIANCE='accepted_variance';
    public const BLOCKED='blocked';
}
