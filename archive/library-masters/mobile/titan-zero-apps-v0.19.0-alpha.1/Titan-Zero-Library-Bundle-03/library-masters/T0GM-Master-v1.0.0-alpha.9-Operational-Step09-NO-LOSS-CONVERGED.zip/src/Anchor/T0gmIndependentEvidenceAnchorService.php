<?php
namespace Titan\GodMode\Anchor;

use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmIndependentEvidenceAnchorService
{
    public function __construct(private readonly IndependentEvidenceAnchorProvider $provider,private readonly T0gmEvidenceAnchorTrustStore $trust){}

    public function anchorCheckpoint(array $checkpoint,array $context=[]):array
    {
        $commitment=$this->checkpointCommitment($checkpoint);
        $receipt=$this->provider->anchor($commitment,$context);
        $this->verifyReceiptAgainstCheckpointOrFail($receipt,$checkpoint);
        return $receipt;
    }

    public function verifyReceiptAgainstCheckpoint(array $receipt,array $checkpoint):bool
    {try{$this->verifyReceiptAgainstCheckpointOrFail($receipt,$checkpoint);return true;}catch(\Throwable){return false;}}

    public function verifyReceiptAgainstCheckpointOrFail(array $receipt,array $checkpoint):void
    {
        $commitment=$this->checkpointCommitment($checkpoint);
        if(($receipt['provider_id']??null)!==$this->provider->providerId())throw new GodModeException('independent-anchor-provider-mismatch');
        if((int)($receipt['audit_sequence']??0)!==$commitment['audit_sequence'])throw new GodModeException('anchor-checkpoint-sequence-mismatch');
        if(!hash_equals((string)($receipt['record_hash']??''),$commitment['record_hash']))throw new GodModeException('anchor-checkpoint-record-hash-mismatch');
        if(!hash_equals((string)($receipt['checkpoint_digest']??''),$commitment['checkpoint_digest']))throw new GodModeException('anchor-checkpoint-digest-mismatch');
        if(!hash_equals((string)($receipt['checkpoint_signature_digest']??''),$commitment['checkpoint_signature_digest']))throw new GodModeException('anchor-checkpoint-signature-digest-mismatch');
        if($this->provider instanceof FileIndependentEvidenceAnchorProvider){$this->provider->verifyReceipt($receipt,$this->trust);return;}
        $this->verifyGenericReceipt($receipt);
    }

    private function checkpointCommitment(array $checkpoint):array
    {
        if(($checkpoint['schema']??null)!=='titan.t0gm.sovereign-audit-checkpoint.v1')throw new GodModeException('anchor-checkpoint-schema-invalid');
        if((int)($checkpoint['audit_sequence']??0)<1)throw new GodModeException('anchor-checkpoint-sequence-invalid');
        $recordHash=(string)($checkpoint['record_hash']??'');if(!preg_match('/^[a-f0-9]{64}$/',$recordHash))throw new GodModeException('anchor-checkpoint-record-hash-invalid');
        $sig=$checkpoint['signature']??null;if(!is_array($sig))throw new GodModeException('anchor-checkpoint-signature-missing');
        return [
            'audit_sequence'=>(int)$checkpoint['audit_sequence'],'record_hash'=>$recordHash,
            'checkpoint_digest'=>hash('sha256',CanonicalJson::encode($checkpoint)),
            'checkpoint_signature_digest'=>hash('sha256',CanonicalJson::encode($sig)),
        ];
    }

    private function verifyGenericReceipt(array $receipt):void
    {
        $sig=$receipt['signature']??null;if(!is_array($sig)||($sig['suite']??null)!=='ed25519')throw new GodModeException('independent-anchor-signature-invalid');
        $time=strtotime((string)($receipt['anchored_at']??''));if($time===false)throw new GodModeException('independent-anchor-time-invalid');
        $key=$this->trust->keyForVerification((string)($sig['key_id']??''),(string)($receipt['provider_id']??''),$time);
        $raw=base64_decode((string)($sig['signature']??''),true);$copy=$receipt;unset($copy['signature']);
        if($raw===false||!sodium_crypto_sign_verify_detached($raw,CanonicalJson::encode($copy),$key['public_key']))throw new GodModeException('independent-anchor-signature-invalid');
    }
}
