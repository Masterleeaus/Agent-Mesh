<?php
namespace Titan\GodMode\AntiRogue;

use Titan\GodMode\Security\CanonicalJson;

final class AntiRogueControlPlane
{
    private const AUTHORITY_MUTATIONS=['grant_capability','increase_authority','change_authority_class','self_promote','persist_authority','delegate_hidden','transfer_authority'];
    private const PROTECTED_RECOVERY=['disable_god_mode_recovery','revoke_t0gm_identity','disable_rewind','disable_sovereign_feed','disable_audit_verification'];

    public function inspect(array $attempt, array $trustedState=[]): AntiRogueFinding
    {
        $type=(string)($attempt['type']??'unknown'); $actors=array_values(array_unique(array_map('strval',$attempt['actors']??[])));
        $reasons=[]; $actions=[]; $severity=0; $class='unknown';
        $operation=(string)($attempt['operation']??'');

        if (in_array($operation,self::AUTHORITY_MUTATIONS,true) || $type==='self_escalation') {
            $class='authority'; $severity=100; $reasons[]='AI_AUTHORITY_SELF_MUTATION_FORBIDDEN'; $actions=['deny','quarantine_actor','revoke_delegated_capabilities','emit_critical_anomaly'];
        } elseif ($type==='hidden_delegation') {
            $class='authority'; $severity=100; $reasons[]='HIDDEN_DELEGATION_FORBIDDEN'; $actions=['deny','quarantine_delegator','revoke_hidden_delegation','trace_dependents'];
        } elseif ($type==='authority_persistence') {
            $class='authority'; $severity=100; $reasons[]='AUTHORITY_PERSISTENCE_FORBIDDEN'; $actions=['deny','extinguish_persisted_authority','rotate_derived_credentials','trace_dependents'];
        } elseif ($type==='forged_evidence' || !$this->evidenceValid($attempt,$trustedState)) {
            $class='evidence'; $severity=95; $reasons[]='EVIDENCE_INTEGRITY_INVALID'; $actions=['reject_evidence','invalidate_dependent_decisions','pause_dependent_authority','emit_critical_anomaly'];
        } elseif (in_array($type,['feed_suppression','audit_deletion'],true)) {
            $class='observability'; $severity=100; $reasons[]=$type==='feed_suppression'?'SOVEREIGN_FEED_SUPPRESSION_ATTEMPT':'IMMUTABLE_AUDIT_DELETION_ATTEMPT'; $actions=['deny','contain_actor','verify_audit_lineage','enter_sovereign_recovery_mode'];
        } elseif ($type==='oversight_evasion') {
            $class='oversight'; $severity=95; $reasons[]='OVERSIGHT_EVASION_ATTEMPT'; $actions=['deny','force_independent_review','quarantine_actor','emit_critical_anomaly'];
        } elseif ($type==='collusion') {
            $class='collusion'; $severity=count($actors)>=2?100:90; $reasons[]='MULTI_AGENT_COLLUSION_DETECTED'; $actions=['isolate_actors','revoke_shared_delegations','independent_causal_review','preserve_disagreement'];
        } elseif ($type==='compromised_oversight') {
            $class='oversight'; $severity=100; $reasons[]='OVERSIGHT_AGENT_COMPROMISED'; $actions=['remove_from_quorum','quarantine_oversight_agent','require_independent_specialists','preserve_prior_assessments'];
        } elseif ($type==='disable_recovery' || in_array($operation,self::PROTECTED_RECOVERY,true)) {
            $class='recovery'; $severity=100; $reasons[]='GOD_MODE_RECOVERY_DISABLE_ATTEMPT'; $actions=['deny','quarantine_actor','verify_identity_root','verify_recovery_path','emit_critical_anomaly'];
        } else {
            $class='unknown'; $severity=50; $reasons[]='UNCLASSIFIED_PRIVILEGED_AI_BEHAVIOR'; $actions=['pause_for_review','collect_evidence'];
        }
        $refs=array_values(array_unique(array_map('strval',$attempt['evidence_refs']??[])));
        $id='rogue_'.substr(hash('sha256',CanonicalJson::encode([$type,$operation,$actors,$reasons,$refs])),0,24);
        return new AntiRogueFinding($id,$class,$severity>=90?'contain':'review',$severity,$reasons,$actors,$refs,$actions,true);
    }

    public function validateDelegation(array $delegation): void
    {
        if (($delegation['delegator_type']??'')==='ai' && (($delegation['hidden']??false) || ($delegation['increases_authority']??false) || ($delegation['authority_class']??'')==='titan.god_mode')) throw new \RuntimeException('anti-rogue-delegation-forbidden');
        if (($delegation['company_id']??'')==='' || ($delegation['company_id']??'')==='*') throw new \RuntimeException('anti-rogue-company-boundary-invalid');
    }

    public function assertRecoveryInvariant(array $change): void
    {
        $op=(string)($change['operation']??'');
        if (in_array($op,self::PROTECTED_RECOVERY,true) && ($change['actor_type']??'')==='ai') throw new \RuntimeException('god-mode-recovery-is-non-disableable-by-ai');
    }

    public function verifyObservability(bool $auditLineageValid, bool $feedObservable): void
    {
        if (!$auditLineageValid || !$feedObservable) throw new \RuntimeException('sovereign-observability-integrity-failed');
    }

    private function evidenceValid(array $attempt,array $trusted): bool
    {
        if (!isset($attempt['evidence_payload'],$attempt['evidence_digest'])) return true;
        $actual=hash('sha256',CanonicalJson::encode($attempt['evidence_payload']));
        return hash_equals((string)$attempt['evidence_digest'],$actual) && (!isset($trusted['expected_evidence_digest']) || hash_equals((string)$trusted['expected_evidence_digest'],$actual));
    }
}
