<?php
namespace Titan\GodMode\Simulation;

use Titan\GodMode\Causal\T0gmCausalBlastRadiusAnalyzer;
use Titan\GodMode\Causal\T0gmProspectiveCausalGraph;

final class T0gmPredictiveSovereignSimulator
{
    public function __construct(private readonly T0gmCausalBlastRadiusAnalyzer $blast = new T0gmCausalBlastRadiusAnalyzer()) {}

    /**
     * @param array<int,array{scenario_id:string,graph:T0gmProspectiveCausalGraph,assumptions?:array}> $scenarios
     */
    public function simulate(string $rootNodeId, string $companyId, T0gmProspectiveCausalGraph $baselineGraph, array $scenarios): array
    {
        if (trim($companyId)==='') throw new \RuntimeException('simulation-company-id-required');
        $baseline=$this->blast->forecast($rootNodeId,$baselineGraph)->toArray();
        $runs=[];
        foreach($scenarios as $scenario){
            $id=trim((string)($scenario['scenario_id']??''));
            if($id==='') throw new \RuntimeException('simulation-scenario-id-required');
            $graph=$scenario['graph']??null;
            if(!$graph instanceof T0gmProspectiveCausalGraph) throw new \RuntimeException('simulation-scenario-graph-required');
            $runs[]=[
                'scenario_id'=>$id,
                'assumptions'=>(array)($scenario['assumptions']??[]),
                'blast_radius'=>$this->blast->forecast($rootNodeId,$graph)->toArray(),
            ];
        }
        return [
            'schema'=>'titan.t0gm.predictive-sovereign-simulation.v1',
            'root_node_id'=>$rootNodeId,
            'company_id'=>$companyId,
            'baseline'=>$baseline,
            'scenarios'=>$runs,
            'simulation_only'=>true,
            'executed'=>false,
            'grants_authority'=>false,
            'requires_execution_authority_for_real_action'=>true,
        ];
    }
}
