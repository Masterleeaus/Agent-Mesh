<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Security\GodModeException;

/**
 * Binds multiple independently proven devices to one sovereign T0GM principal.
 * Device membership is identity evidence only. It never creates company,
 * application-role, capability, or execution authority.
 */
final class T0gmDeviceTrustRegistry
{
    private array $devices = [];

    public function __construct(array $entries, private readonly ?T0gmDeviceIsolationRegistry $isolation = null)
    {
        $bindingIds = [];
        foreach ($entries as $deviceKeyId => $entry) {
            $principalId = trim((string)($entry['principal_id'] ?? ''));
            $publicKeyHash = strtolower(trim((string)($entry['device_public_key_hash'] ?? '')));
            $bindingId = trim((string)($entry['binding_id'] ?? ''));
            $status = (string)($entry['status'] ?? 'active');
            if ($principalId === '' || !preg_match('/^[a-f0-9]{64}$/', $publicKeyHash) || $bindingId === '') {
                throw new \InvalidArgumentException('invalid-device-binding:' . $deviceKeyId);
            }
            if (!in_array($status, ['active','retired','revoked'], true)) {
                throw new \InvalidArgumentException('invalid-device-binding-status:' . $deviceKeyId);
            }
            if (isset($bindingIds[$bindingId])) {
                throw new \InvalidArgumentException('duplicate-device-binding-id:' . $bindingId);
            }
            $bindingIds[$bindingId] = true;
            if (array_key_exists('company_id', $entry) || array_key_exists('tenant_id', $entry) || array_key_exists('tenant_company_id', $entry)) {
                throw new \InvalidArgumentException('tenant-bound-device-binding-forbidden:' . $deviceKeyId);
            }
            $this->devices[(string)$deviceKeyId] = [
                'device_key_id'=>(string)$deviceKeyId,
                'principal_id'=>$principalId,
                'device_public_key_hash'=>$publicKeyHash,
                'binding_id'=>$bindingId,
                'status'=>$status,
                'bound_from'=>isset($entry['bound_from']) ? (int)$entry['bound_from'] : null,
                'retired_at'=>isset($entry['retired_at']) ? (int)$entry['retired_at'] : null,
                'revoked_at'=>isset($entry['revoked_at']) ? (int)$entry['revoked_at'] : null,
                'provenance'=>is_array($entry['provenance'] ?? null) ? $entry['provenance'] : [],
            ];
        }
    }

    public function bindingForCurrentUse(string $deviceKeyId, string $principalId, string $devicePublicKeyRaw, int $now): array
    {
        $binding = $this->binding($deviceKeyId, $principalId, $devicePublicKeyRaw);
        if ($binding['bound_from'] !== null && $now < $binding['bound_from']) {
            throw new GodModeException('device-binding-not-yet-active');
        }
        if ($binding['status'] === 'revoked' || ($binding['revoked_at'] !== null && $now >= $binding['revoked_at'])) {
            throw new GodModeException('device-binding-revoked');
        }
        if ($binding['status'] === 'retired' || ($binding['retired_at'] !== null && $now >= $binding['retired_at'])) {
            throw new GodModeException('device-binding-retired');
        }
        if ($binding['status'] !== 'active') {
            throw new GodModeException('device-binding-not-active');
        }
        $this->isolation?->assertCurrentUseAllowed($deviceKeyId,$principalId,$binding['binding_id'],$now);
        return $this->publicBinding($binding);
    }

    public function bindingForHistoricalVerification(string $deviceKeyId, string $principalId, string $devicePublicKeyRaw, int $evidenceTime): array
    {
        $binding = $this->binding($deviceKeyId, $principalId, $devicePublicKeyRaw);
        if ($binding['bound_from'] !== null && $evidenceTime < $binding['bound_from']) {
            throw new GodModeException('device-binding-not-trusted-at');
        }
        if ($binding['revoked_at'] !== null && $evidenceTime >= $binding['revoked_at']) {
            throw new GodModeException('device-binding-revoked-at');
        }
        if ($binding['retired_at'] !== null && $evidenceTime >= $binding['retired_at']) {
            throw new GodModeException('device-binding-not-trusted-at');
        }
        $this->isolation?->assertHistoricalUseAllowed($deviceKeyId,$principalId,$binding['binding_id'],$evidenceTime);
        return $this->publicBinding($binding);
    }

    private function binding(string $deviceKeyId, string $principalId, string $devicePublicKeyRaw): array
    {
        if (!isset($this->devices[$deviceKeyId])) {
            throw new GodModeException('unknown-device-binding');
        }
        $binding = $this->devices[$deviceKeyId];
        if (!hash_equals($binding['principal_id'], $principalId)) {
            throw new GodModeException('device-binding-principal-mismatch');
        }
        if (!hash_equals($binding['device_public_key_hash'], hash('sha256', $devicePublicKeyRaw))) {
            throw new GodModeException('device-binding-public-key-mismatch');
        }
        return $binding;
    }

    private function publicBinding(array $binding): array
    {
        return [
            'binding_id'=>$binding['binding_id'],
            'device_key_id'=>$binding['device_key_id'],
            'principal_id'=>$binding['principal_id'],
            'device_public_key_hash'=>$binding['device_public_key_hash'],
            'status'=>$binding['status'],
            'bound_from'=>$binding['bound_from'],
            'retired_at'=>$binding['retired_at'],
            'revoked_at'=>$binding['revoked_at'],
            'provenance'=>$binding['provenance'],
            'sovereign_identity_membership'=>true,
            'application_role_authority'=>false,
            'company_authority_embedded'=>false,
        ];
    }
}
