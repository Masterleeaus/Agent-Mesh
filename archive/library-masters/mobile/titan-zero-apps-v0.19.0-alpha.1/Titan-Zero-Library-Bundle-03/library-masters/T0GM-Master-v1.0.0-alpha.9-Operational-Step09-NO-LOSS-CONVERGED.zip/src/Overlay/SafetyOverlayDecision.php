<?php
namespace Titan\GodMode\Overlay;

final class SafetyOverlayDecision
{
    public function __construct(
        public readonly bool $allowed,
        public readonly array $reasons,
        public readonly array $requiredControls,
        public readonly array $appliedOverlayIds,
    ) {}
}
