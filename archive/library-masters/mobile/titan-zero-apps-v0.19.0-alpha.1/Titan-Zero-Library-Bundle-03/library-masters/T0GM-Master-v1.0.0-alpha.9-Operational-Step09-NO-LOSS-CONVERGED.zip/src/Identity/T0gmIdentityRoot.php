<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Contracts\NonceStore;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmIdentityRoot
{
    public function __construct(
        private readonly T0gmVerifierTrustStore $identityRoots,
        private readonly T0gmHardwareAttestation $hardware,
        private readonly T0gmCryptoSuiteRegistry $crypto,
        private readonly NonceStore $nonces,
        private readonly array $policy,
        private readonly ?T0gmDeviceTrustRegistry $devices = null
    ) {}

    public function verify(array $proof, ?int $now=null): array
    {
        $now??=time();
        foreach (['payload','root_key_id','signature_suite','root_signature','hardware_attestation'] as $f) {
            if (!array_key_exists($f,$proof)) throw new GodModeException("identity-root-proof-missing:$f");
        }
        $p=(array)$proof['payload'];
        foreach (['schema','authority','principal_class','principal_id','device_key_id','device_public_key','audience','challenge','issued_at','proof_expires_at','non_tenant'] as $f) {
            if (!array_key_exists($f,$p)) throw new GodModeException("identity-root-payload-missing:$f");
        }
        if ($p['schema']!=='titan.t0gm.identity_root_proof.v1') throw new GodModeException('wrong-identity-root-schema');
        foreach (['authority','principal_class','principal_id','audience'] as $f) {
            if ((string)$p[$f] !== (string)$this->policy[$f]) throw new GodModeException('wrong-' . str_replace('_','-',$f));
        }
        if ($p['non_tenant']!==true) throw new GodModeException('t0gm-identity-must-be-non-tenant');
        foreach (['company_id','tenant_id','tenant_company_id','role_id','user_id'] as $forbidden) {
            if (array_key_exists($forbidden,$p)) throw new GodModeException('application-identity-binding-forbidden:' . $forbidden);
        }
        $skew=(int)($this->policy['clock_skew_seconds']??30);
        if ($now+$skew < (int)$p['issued_at'] || $now-$skew > (int)$p['proof_expires_at']) throw new GodModeException('identity-root-proof-outside-verification-window');
        if (trim((string)$p['challenge'])==='' || trim((string)$p['device_key_id'])==='') throw new GodModeException('identity-root-binding-incomplete');
        $devicePublic=base64_decode((string)$p['device_public_key'],true);
        if ($devicePublic===false || $devicePublic==='') throw new GodModeException('invalid-identity-device-public-key');

        $root=$this->identityRoots->key((string)$proof['root_key_id']);
        if ($root['suite']!==(string)$proof['signature_suite']) throw new GodModeException('identity-root-suite-key-mismatch');
        $rootSig=base64_decode((string)$proof['root_signature'],true);
        if ($rootSig===false || !$this->crypto->verify((string)$proof['signature_suite'],$rootSig,CanonicalJson::encode($p),$root['public_key'])) throw new GodModeException('invalid-identity-root-signature');

        $att=$this->hardware->verify((array)$proof['hardware_attestation'],[
            'device_key_id'=>(string)$p['device_key_id'],
            'device_public_key_hash'=>hash('sha256',$devicePublic),
            'challenge'=>(string)$p['challenge'],
        ],$now,$skew);

        $deviceBinding=$this->devices?->bindingForCurrentUse((string)$p['device_key_id'],(string)$p['principal_id'],$devicePublic,$now);

        if (!$this->nonces->consume('t0gm-identity:' . $p['device_key_id'],(string)$p['challenge'],(int)$p['proof_expires_at'])) throw new GodModeException('identity-proof-replay-detected');

        return [
            'authority'=>(string)$p['authority'],
            'authority_class'=>'titan.god_mode',
            'principal_class'=>(string)$p['principal_class'],
            'principal_id'=>(string)$p['principal_id'],
            'device_key_id'=>(string)$p['device_key_id'],
            'device_public_key_raw'=>$devicePublic,
            'hardware_attestation'=>$att,
            'device_binding'=>$deviceBinding,
            'root_key_id'=>(string)$proof['root_key_id'],
            'signature_suite'=>(string)$proof['signature_suite'],
            'identity_schema'=>(string)$p['schema'],
            'cryptographic_identity'=>true,
            'application_role_authority'=>false,
        ];
    }
}
