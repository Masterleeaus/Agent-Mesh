<?php
namespace Titan\GodMode\Anchor;

use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

/**
 * Reference provider for an independently administered filesystem/object-store domain.
 * Production adapters may replace this with transparency logs, notary services,
 * WORM object stores, ledgers, or other externally controlled anchoring systems.
 */
final class FileIndependentEvidenceAnchorProvider implements IndependentEvidenceAnchorProvider
{
    private string $lockPath;
    public function __construct(
        private readonly string $directory,
        private readonly string $providerId,
        private readonly string $signerKeyId,
        private readonly string $signerSecretKey,
    ){
        if($providerId===''||$signerKeyId===''||strlen($signerSecretKey)!==SODIUM_CRYPTO_SIGN_SECRETKEYBYTES)throw new GodModeException('invalid-independent-anchor-provider');
        if(!is_dir($directory)&&!mkdir($directory,0700,true)&&!is_dir($directory))throw new GodModeException('independent-anchor-directory-unavailable');
        @chmod($directory,0700);$this->lockPath=$directory.'/.anchor.lock';
    }

    public function providerId():string{return $this->providerId;}

    public function anchor(array $commitment,array $context=[]):array
    {
        $this->validateCommitment($commitment);
        $anchorId='anchor-'.substr(hash('sha256',$this->providerId."\0".CanonicalJson::encode($commitment)),0,40);
        $path=$this->receiptPath($anchorId);
        $lock=fopen($this->lockPath,'c+');if($lock===false||!flock($lock,LOCK_EX))throw new GodModeException('independent-anchor-lock-failed');
        try{
            if(is_file($path)){
                $existing=json_decode((string)file_get_contents($path),true,512,JSON_THROW_ON_ERROR);
                $this->assertReceiptMatchesCommitment($existing,$commitment);
                return $existing;
            }
            $heads=$this->loadAllRaw();$previous=end($heads)?:null;
            $sequence=$previous===null?1:((int)$previous['anchor_sequence']+1);
            $receipt=[
                'schema'=>'titan.t0gm.independent-evidence-anchor-receipt.v1',
                'anchor_id'=>$anchorId,'provider_id'=>$this->providerId,'anchor_sequence'=>$sequence,
                'audit_sequence'=>(int)$commitment['audit_sequence'],'record_hash'=>(string)$commitment['record_hash'],
                'checkpoint_digest'=>(string)$commitment['checkpoint_digest'],'checkpoint_signature_digest'=>(string)$commitment['checkpoint_signature_digest'],
                'previous_anchor_hash'=>$previous['anchor_hash']??null,'anchored_at'=>gmdate('c'),
                'context'=>[
                    'criticality'=>(string)($context['criticality']??'critical'),
                    'reason'=>(string)($context['reason']??'critical-sovereign-evidence'),
                    'requested_by'=>(string)($context['requested_by']??'t0gm'),
                ],
                'semantics'=>[
                    'independent_evidence_anchor'=>true,'proves_historical_commitment'=>true,'grants_authority'=>false,
                    'constitutes_t0gm_approval'=>false,'company_authority_embedded'=>false,'execution_authority_embedded'=>false,
                ],
            ];
            $receipt['anchor_hash']=$this->receiptHash($receipt);
            $statement=CanonicalJson::encode($receipt);
            $receipt['signature']=['suite'=>'ed25519','key_id'=>$this->signerKeyId,'signature'=>base64_encode(sodium_crypto_sign_detached($statement,$this->signerSecretKey))];
            $fh=@fopen($path,'x');if($fh===false)throw new GodModeException('independent-anchor-create-failed');
            $encoded=CanonicalJson::encode($receipt);if(fwrite($fh,$encoded)!==strlen($encoded)){fclose($fh);throw new GodModeException('independent-anchor-write-failed');}
            fflush($fh);if(function_exists('fsync'))@fsync($fh);fclose($fh);@chmod($path,0400);
            return $receipt;
        }finally{flock($lock,LOCK_UN);fclose($lock);}
    }

    public function receiptPath(string $anchorId):string
    {
        if(!preg_match('/^anchor-[a-f0-9]{40}$/',$anchorId))throw new GodModeException('independent-anchor-id-invalid');
        return $this->directory.'/'.$anchorId.'.receipt.json';
    }

    public function loadAndVerify(string $anchorId,T0gmEvidenceAnchorTrustStore $trust):array
    {
        $path=$this->receiptPath($anchorId);if(!is_file($path))throw new GodModeException('independent-anchor-receipt-missing');
        try{$receipt=json_decode((string)file_get_contents($path),true,512,JSON_THROW_ON_ERROR);}catch(\Throwable){throw new GodModeException('independent-anchor-receipt-json-invalid');}
        if(!is_array($receipt))throw new GodModeException('independent-anchor-receipt-json-invalid');
        $this->verifyReceipt($receipt,$trust);
        return $receipt;
    }

    public function verifyReceipt(array $receipt,T0gmEvidenceAnchorTrustStore $trust):void
    {
        if(($receipt['schema']??null)!=='titan.t0gm.independent-evidence-anchor-receipt.v1')throw new GodModeException('independent-anchor-schema-invalid');
        if(($receipt['provider_id']??null)!==$this->providerId)throw new GodModeException('independent-anchor-provider-mismatch');
        foreach(['anchor_id','record_hash','checkpoint_digest','checkpoint_signature_digest','anchor_hash','anchored_at'] as $f)if(!is_string($receipt[$f]??null)||$receipt[$f]==='')throw new GodModeException('independent-anchor-field-invalid:'.$f);
        if(($receipt['semantics']['grants_authority']??null)!==false||($receipt['semantics']['constitutes_t0gm_approval']??null)!==false)throw new GodModeException('independent-anchor-authority-semantics-invalid');
        $expected=$this->receiptHash($receipt);if(!hash_equals((string)$receipt['anchor_hash'],$expected))throw new GodModeException('independent-anchor-hash-invalid');
        $sig=$receipt['signature']??null;if(!is_array($sig)||($sig['suite']??null)!=='ed25519')throw new GodModeException('independent-anchor-signature-invalid');
        $time=strtotime((string)$receipt['anchored_at']);if($time===false)throw new GodModeException('independent-anchor-time-invalid');
        $key=$trust->keyForVerification((string)($sig['key_id']??''),$this->providerId,$time);
        $raw=base64_decode((string)($sig['signature']??''),true);if($raw===false)throw new GodModeException('independent-anchor-signature-invalid');
        $copy=$receipt;unset($copy['signature']);
        if(!sodium_crypto_sign_verify_detached($raw,CanonicalJson::encode($copy),$key['public_key']))throw new GodModeException('independent-anchor-signature-invalid');
    }

    private function receiptHash(array $receipt):string
    {
        $copy=$receipt;unset($copy['anchor_hash'],$copy['signature']);return hash('sha256',CanonicalJson::encode($copy));
    }
    private function validateCommitment(array $c):void
    {
        if((int)($c['audit_sequence']??0)<1)throw new GodModeException('independent-anchor-audit-sequence-invalid');
        foreach(['record_hash','checkpoint_digest','checkpoint_signature_digest'] as $f)if(!is_string($c[$f]??null)||!preg_match('/^[a-f0-9]{64}$/',$c[$f]))throw new GodModeException('independent-anchor-commitment-invalid:'.$f);
    }
    private function assertReceiptMatchesCommitment(array $receipt,array $commitment):void
    {
        if((int)($receipt['audit_sequence']??0)!==(int)$commitment['audit_sequence']||!hash_equals((string)($receipt['record_hash']??''),(string)$commitment['record_hash'])||!hash_equals((string)($receipt['checkpoint_digest']??''),(string)$commitment['checkpoint_digest'])||!hash_equals((string)($receipt['checkpoint_signature_digest']??''),(string)$commitment['checkpoint_signature_digest']))throw new GodModeException('independent-anchor-id-conflict');
    }
    private function loadAllRaw():array
    {
        $files=glob($this->directory.'/anchor-*.receipt.json')?:[];sort($files,SORT_STRING);
        $records=[];foreach($files as $file){$r=json_decode((string)file_get_contents($file),true);if(is_array($r))$records[]=$r;}
        usort($records,fn($a,$b)=>(int)($a['anchor_sequence']??0)<=>(int)($b['anchor_sequence']??0));return $records;
    }
}
