<?php
namespace Titan\GodMode\Workforce;
use Titan\GodMode\Security\GodModeException;

final class T0gmAiWorkforceTeamStructure
{
    private const ROLES=['specialist','supervisor','challenger','investigator','coordinator','member'];
    private array $teams=[];
    public function __construct(private readonly T0gmCanonicalAiWorkforceRegistry $registry){}

    public function create(string $companyId,array $d):array
    {
        foreach(['tenant_id','tenant_company_id'] as $f) if(array_key_exists($f,$d)) throw new GodModeException('legacy-tenant-boundary-forbidden:'.$f);
        $id=trim((string)($d['team_id']??'')); $name=trim((string)($d['name']??'')); $type=(string)($d['team_type']??'persistent');
        if($id===''||$name==='') throw new GodModeException('ai-team-id-name-required');
        if(!in_array($type,['persistent','temporary_mission'],true)) throw new GodModeException('ai-team-type-invalid');
        if(isset($this->teams[$companyId][$id])) throw new GodModeException('ai-team-duplicate');
        $createdBy=trim((string)($d['created_by']??'')); if($createdBy==='') throw new GodModeException('ai-team-creator-required');
        $rev=(int)($d['revision']??0); if($rev<1) throw new GodModeException('ai-team-revision-required');
        $roles=[];$members=[];
        foreach((array)($d['roles']??[]) as $role=>$ids){
            if(!in_array($role,self::ROLES,true)) throw new GodModeException('ai-team-role-invalid:'.$role);
            if(!is_array($ids)) throw new GodModeException('ai-team-role-members-list-required');
            foreach($ids as $wid){
                $wid=trim((string)$wid); if($wid==='') throw new GodModeException('ai-team-member-id-required');
                try{$w=$this->registry->get($companyId,$wid);}catch(\Throwable){throw new GodModeException('team-member-not-found:'.$wid);}
                if(!in_array(($w['kind']??null),['worker','specialist','autonomous_service'],true)) throw new GodModeException('ai-team-member-kind-invalid:'.$wid);
                $roles[$role][$wid]=true; $members[$wid]=true;
            }
        }
        if(isset($members[$createdBy])) throw new GodModeException('ai-team-self-constitution-forbidden');
        $mission=is_array($d['mission']??null)?$d['mission']:[];
        if($type==='temporary_mission'){
            if(trim((string)($mission['objective']??''))==='') throw new GodModeException('ai-team-mission-objective-required');
            if(!is_array($mission['extinction_conditions']??null)||$mission['extinction_conditions']===[]) throw new GodModeException('ai-team-mission-extinction-conditions-required');
        }
        $out=['schema'=>'titan.t0gm.ai-workforce-team.v1','company_id'=>$companyId,'team_id'=>$id,'name'=>$name,'team_type'=>$type,'temporary'=>$type==='temporary_mission','status'=>'active','revision'=>$rev,'created_by'=>$createdBy,'roles'=>array_map(fn($m)=>array_keys($m),$roles),'members'=>array_keys($members),'mission'=>$mission,'team_grants_authority'=>false,'authority_aggregated'=>false,'member_authority_transferred'=>false,'member_capabilities_remain_individual'=>true,'sovereign_authority_inherited'=>false];
        $out['team_digest']=$this->digest($out); $this->teams[$companyId][$id]=$out; return $out;
    }
    public function get(string $companyId,string $teamId):array{if(!isset($this->teams[$companyId][$teamId]))throw new GodModeException('ai-team-not-found');return $this->teams[$companyId][$teamId];}
    public function membersByRole(string $companyId,string $teamId,string $role):array{if(!in_array($role,self::ROLES,true))throw new GodModeException('ai-team-role-invalid:'.$role);return $this->get($companyId,$teamId)['roles'][$role]??[];}
    public function closeMission(string $companyId,string $teamId,string $condition,string $actorId):array
    {
        $t=$this->get($companyId,$teamId); if($t['team_type']!=='temporary_mission')throw new GodModeException('ai-team-not-temporary-mission');
        if($t['status']==='closed')return $t;
        if(!in_array($condition,(array)($t['mission']['extinction_conditions']??[]),true))throw new GodModeException('ai-team-mission-extinction-condition-not-met');
        if(in_array($actorId,$t['members'],true))throw new GodModeException('ai-team-self-closure-forbidden');
        $t['status']='closed';$t['closed_by']=$actorId;$t['closure_condition']=$condition;$t['revision']++;unset($t['team_digest']);$t['team_digest']=$this->digest($t);$this->teams[$companyId][$teamId]=$t;return $t;
    }
    private function digest(array $v):string{return hash('sha256',json_encode($this->canon($v),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION|JSON_THROW_ON_ERROR));}
    private function canon(mixed $v):mixed{if(!is_array($v))return $v;if(array_is_list($v))return array_map(fn($x)=>$this->canon($x),$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=$this->canon($x);return $v;}
}
