<?php
namespace Titan\GodMode\Feed;

use RuntimeException;

final class T0gmFeedException extends RuntimeException
{
    public function __construct(public readonly string $reason, string $message = '')
    {
        parent::__construct($message !== '' ? $message : $reason);
    }
}
