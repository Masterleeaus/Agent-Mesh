<?php
namespace Titan\GodMode\Recovery;

use Titan\GodMode\Contracts\SovereignActivityStore;
use Titan\GodMode\Event\T0gmCanonicalHasher;
use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedAccessContext;

final class T0gmRewindService
{
    public function __construct(private readonly SovereignActivityStore $activity,private readonly InMemoryT0gmStateTransitionStore $transitions,private readonly T0gmRecoveryPlanner $planner=new T0gmRecoveryPlanner(),private readonly T0gmEventFactory $events=new T0gmEventFactory(),private readonly T0gmCanonicalHasher $hasher=new T0gmCanonicalHasher()){}
    public function invokeForEvent(string $sourceEventId,T0gmFeedAccessContext $access,string $actorId,array $currentState,array $dependencyStates=[],?string $supersessionEventId=null):array
    {
        if(!$access->isSovereign()) throw new \RuntimeException('t0gm-sovereign-access-required');
        $record=$this->activity->get($sourceEventId,$access); if($record===null) throw new \RuntimeException('recovery-source-event-not-found');
        $event=$record['event']; $companyId=$event['company_context']['company_id']??null;
        $out=[]; foreach($this->transitions->bySourceEvent($sourceEventId) as $t){ if($companyId===null||$t['company_id']!==$companyId) throw new \RuntimeException('recovery-company-boundary-mismatch'); $plan=$this->planner->plan($t,$currentState,$dependencyStates);
            $recoveryId='t0gm_recovery_'.bin2hex(random_bytes(12));
            $intervention=$this->events->make(T0gmEventKind::INTERVENTION,$event['company_context'],['actor_type'=>'human','actor_id'=>$actorId,'authority_class'=>'titan.god_mode'],['system'=>'titan.t0gm','component'=>'rewind-recovery'],$event['subject'],['trace_id'=>$event['lineage']['trace_id'],'correlation_id'=>$event['lineage']['correlation_id'],'causation_id'=>$supersessionEventId??$sourceEventId,'parent_event_ids'=>array_values(array_unique(array_filter([$sourceEventId,$supersessionEventId])))],$event['risk'],['visibility'=>'t0gm_sovereign','attention_tier'=>'critical','review_required'=>true,'review_team'=>['governance','causal','security','operational']],$t['evidence'],['intervention'=>['intervention_id'=>$recoveryId,'directive'=>'t0gm_rewind_recovery'],'recovery'=>['transition_id'=>$t['transition_id'],'source_event_id'=>$sourceEventId,'supersession_event_id'=>$supersessionEventId,'disposition'=>$plan->disposition,'reason_codes'=>$plan->reasonCodes,'effect'=>$plan->effect,'pre_state_hash'=>$t['pre_state']['hash'],'intended_result_hash'=>$t['intended_result']['hash'],'actual_result_hash'=>$t['actual_result']['hash'],'dependency_checks'=>$plan->dependencyChecks,'truth_preservation'=>true]]);
            $intervention=$this->hasher->seal($intervention); $stored=$this->activity->append($intervention); $out[]=['plan'=>$plan,'event'=>$stored['event']];
        } return $out;
    }
}
