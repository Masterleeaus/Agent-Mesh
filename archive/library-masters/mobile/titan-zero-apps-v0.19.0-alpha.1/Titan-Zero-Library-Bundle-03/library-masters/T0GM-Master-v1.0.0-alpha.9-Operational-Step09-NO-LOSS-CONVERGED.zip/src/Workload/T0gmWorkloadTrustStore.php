<?php
namespace Titan\GodMode\Workload;
use Titan\GodMode\Security\GodModeException;
final class T0gmWorkloadTrustStore
{
    private array $keys=[];
    public function __construct(array $keys){foreach($keys as $id=>$k){$pub=base64_decode((string)($k['public_key']??''),true);if($pub===false||$pub==='')throw new \InvalidArgumentException('invalid-workload-attestor-key:'.$id);$this->keys[(string)$id]=['suite'=>(string)($k['suite']??''),'public_key'=>$pub,'purposes'=>(array)($k['purposes']??[])];}}
    public function key(string $id,string $purpose):array{if(!isset($this->keys[$id]))throw new GodModeException('unknown-workload-attestor-key');$k=$this->keys[$id];if(!in_array($purpose,$k['purposes'],true))throw new GodModeException('workload-attestor-purpose-forbidden');return $k;}
}
