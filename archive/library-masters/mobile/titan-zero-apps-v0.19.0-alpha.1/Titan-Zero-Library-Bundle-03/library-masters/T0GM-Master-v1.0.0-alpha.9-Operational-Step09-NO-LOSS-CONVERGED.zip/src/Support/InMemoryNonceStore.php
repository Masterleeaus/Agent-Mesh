<?php
namespace Titan\GodMode\Support;

use Titan\GodMode\Contracts\NonceStore;

final class InMemoryNonceStore implements NonceStore
{
    private array $seen = [];

    public function consume(string $namespace, string $nonce, int $expiresAt): bool
    {
        $now = time();
        foreach ($this->seen as $k => $exp) {
            if ($exp < $now) {
                unset($this->seen[$k]);
            }
        }

        $key = $namespace . ':' . $nonce;
        if (isset($this->seen[$key])) {
            return false;
        }

        $this->seen[$key] = $expiresAt;
        return true;
    }
}
