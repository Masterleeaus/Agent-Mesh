<?php
namespace Titan\GodMode\Recovery;

final class T0gmRecoveryPlanner
{
    public function __construct(private readonly T0gmStateTransitionHasher $hasher=new T0gmStateTransitionHasher()){}
    public function plan(array $transition,array $currentState,array $dependencyStates):T0gmRecoveryPlan
    {
        $checks=[]; foreach($transition['dependencies'] as $d){ $actual=$dependencyStates[$d['dependency_id']]??null; $ok=$actual===$d['required_state']; $checks[]=['dependency_id'=>$d['dependency_id'],'required_state'=>$d['required_state'],'actual_state'=>$actual,'satisfied'=>$ok]; if(!$ok) return new T0gmRecoveryPlan($transition['transition_id'],T0gmRecoveryDisposition::RECOMPUTE,['DEPENDENCY_STATE_CHANGED'],null,$checks); }
        if(!hash_equals($transition['actual_result']['hash'],$this->hasher->hashState($currentState))) return new T0gmRecoveryPlan($transition['transition_id'],T0gmRecoveryDisposition::RECOMPUTE,['CURRENT_STATE_DIVERGED_FROM_RECORDED_POST_STATE'],null,$checks);
        $r=$transition['reversibility'];
        return match($r['mode']){
            'direct'=>new T0gmRecoveryPlan($transition['transition_id'],T0gmRecoveryDisposition::REVERSE,['VERIFIED_POST_STATE_MATCH','DIRECT_INVERSE_AVAILABLE'],$r['inverse_effect'],$checks),
            'compensating'=>new T0gmRecoveryPlan($transition['transition_id'],T0gmRecoveryDisposition::COMPENSATE,['VERIFIED_POST_STATE_MATCH','COMPENSATING_EFFECT_REQUIRED'],$r['compensating_effect'],$checks),
            'recompute_only'=>new T0gmRecoveryPlan($transition['transition_id'],T0gmRecoveryDisposition::RECOMPUTE,['TRANSITION_REQUIRES_RECOMPUTATION'],null,$checks),
            default=>new T0gmRecoveryPlan($transition['transition_id'],T0gmRecoveryDisposition::BLOCKED,['TRANSITION_DECLARED_IRREVERSIBLE'],null,$checks),
        };
    }
}
