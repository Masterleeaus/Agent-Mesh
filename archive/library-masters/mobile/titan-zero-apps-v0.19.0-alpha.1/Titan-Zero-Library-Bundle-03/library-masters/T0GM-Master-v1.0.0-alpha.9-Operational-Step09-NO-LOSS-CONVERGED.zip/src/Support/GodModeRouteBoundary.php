<?php
namespace Titan\GodMode\Support;

final class GodModeRouteBoundary
{
    public const PREFIX = '/_titan-control-plane/god-mode';

    public static function assertNotTenantRoute(string $route): void
    {
        $normalized = '/' . ltrim($route, '/');
        if (
            str_starts_with($normalized, '/company/') ||
            str_starts_with($normalized, '/tenant/') ||
            str_starts_with($normalized, '/admin/roles') ||
            str_starts_with($normalized, '/admin/permissions')
        ) {
            throw new \RuntimeException('god-mode-endpoint-must-not-live-in-tenant-admin-route-space');
        }
    }
}
