<?php
namespace Titan\GodMode\Feed;

use Titan\GodMode\Contracts\SovereignActivityStore;
use Titan\GodMode\Event\T0gmCanonicalHasher;
use Titan\GodMode\Event\T0gmEventValidator;
use Titan\GodMode\Event\T0gmEventProvenanceVerifier;

final class T0gmFeedIngestor
{
    public function __construct(
        private readonly SovereignActivityStore $store,
        private readonly T0gmEventValidator $validator = new T0gmEventValidator(),
        private readonly T0gmCanonicalHasher $hasher = new T0gmCanonicalHasher(),
        private readonly ?T0gmEventProvenanceVerifier $provenanceVerifier = null,
        private readonly bool $requireProvenance = false,
        private readonly array $requiredProvenanceSuites = [],
    ) {}

    /**
     * Validate and ingest one immutable canonical event. Existing valid event integrity is verified;
     * absent integrity is sealed at ingestion. The feed records authority use but never grants it.
     */
    public function ingest(array $event): array
    {
        $event = $this->validator->validate($event);
        if (isset($event['integrity']['canonical_hash'])) {
            if (!$this->hasher->verify($event)) throw new T0gmFeedException('event-integrity-invalid');
        } else {
            $event = $this->hasher->seal($event);
        }
        if (isset($event['provenance'])) {
            if ($this->provenanceVerifier === null) throw new T0gmFeedException('event-provenance-verifier-unavailable');
            try { $this->provenanceVerifier->verify($event,$this->requiredProvenanceSuites); }
            catch (\Throwable $e) { throw new T0gmFeedException('event-provenance-invalid:' . $e->getMessage()); }
        } elseif ($this->requireProvenance) {
            throw new T0gmFeedException('event-provenance-required');
        }
        return $this->store->append($event);
    }

    public function ingestMany(iterable $events): array
    {
        $records = [];
        foreach ($events as $event) {
            if (!is_array($event)) throw new T0gmFeedException('invalid-ingest-event');
            $records[] = $this->ingest($event);
        }
        return $records;
    }
}
