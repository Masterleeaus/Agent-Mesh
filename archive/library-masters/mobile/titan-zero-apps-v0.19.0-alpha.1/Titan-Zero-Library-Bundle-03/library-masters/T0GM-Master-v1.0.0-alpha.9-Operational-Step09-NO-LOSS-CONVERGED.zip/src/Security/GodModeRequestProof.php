<?php
namespace Titan\GodMode\Security;

final class GodModeRequestProof
{
    public function __construct(
        public readonly array $payload,
        public readonly string $deviceSignature
    ) {}

    public static function fromArray(array $input): self
    {
        if (!isset($input['payload'], $input['device_signature'])) {
            throw new GodModeException('request-proof-malformed');
        }
        return new self((array) $input['payload'], (string) $input['device_signature']);
    }

    public function verify(
        array $deviceIdentity,
        array $policy,
        \Titan\GodMode\Contracts\NonceStore $nonceStore,
        int $now
    ): array {
        $p = $this->payload;
        $required = [
            'schema','authority','principal_id','device_key_id','audience',
            'nonce','issued_at','expires_at','purpose','action','target'
        ];
        foreach ($required as $field) {
            if (!array_key_exists($field, $p)) {
                throw new GodModeException("request-proof-payload-missing:$field");
            }
        }

        if ($p['schema'] !== 'titan.god_mode.request_proof.v1') {
            throw new GodModeException('wrong-request-proof-schema');
        }
        if ($p['authority'] !== $policy['authority']) {
            throw new GodModeException('wrong-authority');
        }
        if ($p['principal_id'] !== $deviceIdentity['principal_id']) {
            throw new GodModeException('principal-binding-failed');
        }
        if ($p['device_key_id'] !== $deviceIdentity['device_key_id']) {
            throw new GodModeException('device-binding-failed');
        }
        if ($p['audience'] !== $policy['audience']) {
            throw new GodModeException('wrong-audience');
        }

        $skew = (int) ($policy['clock_skew_seconds'] ?? 30);
        if ((int) $p['issued_at'] > $now + $skew) {
            throw new GodModeException('request-proof-issued-in-future');
        }
        if ((int) $p['expires_at'] < $now - $skew) {
            throw new GodModeException('request-proof-expired');
        }
        if ((int) $p['expires_at'] > $deviceIdentity['certificate_expires_at']) {
            throw new GodModeException('proof-outlives-device-certificate');
        }
        if (!is_string($p['purpose']) || trim($p['purpose']) === '') {
            throw new GodModeException('purpose-required');
        }

        $target = (array) $p['target'];
        if (($target['scope'] ?? null) === 'company') {
            if (!isset($target['company_id']) || !is_string($target['company_id']) || trim($target['company_id']) === '') {
                throw new GodModeException('company-target-requires-company_id');
            }
            foreach (['tenant_id','tenant_company_id','organisation_id','organization_id'] as $legacy) {
                if (isset($target[$legacy])) {
                    throw new GodModeException('legacy-tenant-target-forbidden');
                }
            }
        } elseif (($target['scope'] ?? null) !== 'platform_global') {
            throw new GodModeException('invalid-target-scope');
        }

        $sig = base64_decode($this->deviceSignature, true);
        if ($sig === false || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) {
            throw new GodModeException('invalid-device-signature-encoding');
        }
        if (!sodium_crypto_sign_verify_detached(
            $sig,
            CanonicalJson::encode($p),
            $deviceIdentity['device_public_key_raw']
        )) {
            throw new GodModeException('invalid-device-signature');
        }

        if (!$nonceStore->consume(
            'god-mode:' . $deviceIdentity['device_key_id'],
            (string) $p['nonce'],
            (int) $p['expires_at']
        )) {
            throw new GodModeException('replay-detected');
        }

        return [
            'authority' => $policy['authority'],
            'principal_id' => $deviceIdentity['principal_id'],
            'device_key_id' => $deviceIdentity['device_key_id'],
            'purpose' => (string) $p['purpose'],
            'action' => (string) $p['action'],
            'target' => $target,
            'nonce' => (string) $p['nonce'],
        ];
    }
}
