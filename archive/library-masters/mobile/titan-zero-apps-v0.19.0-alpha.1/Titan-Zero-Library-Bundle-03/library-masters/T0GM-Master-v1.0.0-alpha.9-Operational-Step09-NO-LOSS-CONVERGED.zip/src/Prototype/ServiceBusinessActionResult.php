<?php
namespace Titan\GodMode\Prototype;
final readonly class ServiceBusinessActionResult
{
    public function __construct(public array $event,public ?array $transition,public ?array $verification,public array $record){}
}
