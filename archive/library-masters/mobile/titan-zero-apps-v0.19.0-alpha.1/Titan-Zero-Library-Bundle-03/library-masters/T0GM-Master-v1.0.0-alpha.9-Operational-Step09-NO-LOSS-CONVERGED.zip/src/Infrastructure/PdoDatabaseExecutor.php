<?php
namespace Titan\GodMode\Infrastructure;

/** Named prepared statements are configured by trusted bootstrap code, never supplied by the capability request. */
final class PdoDatabaseExecutor implements InfrastructureExecutor
{
    public function __construct(private readonly \PDO $pdo, private readonly array $statements, private readonly mixed $observer){}
    public function transport():string{return 'database_native_protocol';}
    public function observe(array $n):array{return ($this->observer)($this->pdo,$n);}
    public function execute(array $n):InfrastructureExecutionResult
    {
        $op=(string)($n['operation']??'');
        if(!isset($this->statements[$op])) return new InfrastructureExecutionResult(false,$this->transport(),$this->observe($n),[],[],['named-database-operation-not-registered']);
        if(isset(($n['parameters']??[])['sql'])) throw new \RuntimeException('raw-sql-forbidden');
        $spec=$this->statements[$op]; $sql=$spec['sql']??null; if(!is_string($sql)||$sql==='') throw new \RuntimeException('invalid-trusted-statement');
        $bindings=[]; foreach(($spec['bindings']??[]) as $param=>$source){$bindings[$param]=$n['parameters'][$source]??null;}
        $stmt=$this->pdo->prepare($sql); $ok=$stmt->execute($bindings);
        return new InfrastructureExecutionResult($ok,$this->transport(),$this->observe($n),['row_count'=>$stmt->rowCount(),'operation'=>$op],[], $ok?[]:['database-execution-failed']);
    }
}
