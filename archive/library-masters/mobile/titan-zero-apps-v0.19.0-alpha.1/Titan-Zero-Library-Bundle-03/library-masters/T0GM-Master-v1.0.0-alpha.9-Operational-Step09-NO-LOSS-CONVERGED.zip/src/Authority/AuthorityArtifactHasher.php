<?php
namespace Titan\GodMode\Authority;

use Titan\GodMode\Security\CanonicalJson;

final class AuthorityArtifactHasher
{
    public function digest(array $artifact): string
    {
        $copy = $artifact;
        unset($copy['integrity']);
        return hash('sha256', CanonicalJson::encode($copy));
    }

    public function verify(array $artifact): bool
    {
        $digest = $artifact['integrity']['digest'] ?? null;
        return is_string($digest) && hash_equals($digest, $this->digest($artifact));
    }
}
