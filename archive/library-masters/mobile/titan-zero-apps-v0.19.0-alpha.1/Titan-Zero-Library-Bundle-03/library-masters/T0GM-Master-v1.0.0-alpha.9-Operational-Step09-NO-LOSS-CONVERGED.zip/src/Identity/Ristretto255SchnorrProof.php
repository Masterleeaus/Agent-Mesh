<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class Ristretto255SchnorrProof
{
    public const FORMAT = 't0gm.zk.ristretto255-schnorr-fs.v1';
    private const DOMAIN = "TITAN-T0GM-ZK-RISTRETTO255-SCHNORR-FS-V1\0";

    /**
     * Create a Schnorr proof of knowledge over Ristretto255 using Fiat-Shamir.
     * This function belongs inside a prover/custody boundary. The Titan application
     * should normally call it only indirectly through ZeroKnowledgeProverBroker.
     */
    public static function create(string $witnessScalar, array $publicStatement, array $context = []): string
    {
        self::assertRuntime();
        if (strlen($witnessScalar) !== SODIUM_CRYPTO_CORE_RISTRETTO255_SCALARBYTES) {
            throw new GodModeException('zk-witness-scalar-malformed');
        }
        $publicKey = self::statementPublicKey($publicStatement);
        $derived = sodium_crypto_scalarmult_ristretto255_base($witnessScalar);
        if (!hash_equals($publicKey, $derived)) {
            throw new GodModeException('zk-witness-public-key-mismatch');
        }

        $nonce = sodium_crypto_core_ristretto255_scalar_random();
        $commitment = sodium_crypto_scalarmult_ristretto255_base($nonce);
        $challenge = self::challenge($publicStatement, $commitment, $publicKey, $context);
        $cx = sodium_crypto_core_ristretto255_scalar_mul($challenge, $witnessScalar);
        $response = sodium_crypto_core_ristretto255_scalar_add($nonce, $cx);

        // Best-effort overwrite of ephemeral scalar material held by this process.
        if (function_exists('sodium_memzero')) {
            sodium_memzero($nonce);
            sodium_memzero($cx);
        }

        return CanonicalJson::encode([
            'format' => self::FORMAT,
            'commitment' => base64_encode($commitment),
            'response' => base64_encode($response),
        ]);
    }

    public static function verify(string $opaqueProof, array $publicStatement, array $context = []): bool
    {
        self::assertRuntime();
        try {
            $p = json_decode($opaqueProof, true, flags: JSON_THROW_ON_ERROR);
            if (!is_array($p) || ($p['format'] ?? null) !== self::FORMAT) return false;
            $commitment = base64_decode((string)($p['commitment'] ?? ''), true);
            $response = base64_decode((string)($p['response'] ?? ''), true);
            if ($commitment === false || $response === false) return false;
            if (strlen($commitment) !== SODIUM_CRYPTO_CORE_RISTRETTO255_BYTES) return false;
            if (strlen($response) !== SODIUM_CRYPTO_CORE_RISTRETTO255_SCALARBYTES) return false;
            if (!sodium_crypto_core_ristretto255_is_valid_point($commitment)) return false;

            $publicKey = self::statementPublicKey($publicStatement);
            $challenge = self::challenge($publicStatement, $commitment, $publicKey, $context);
            $lhs = sodium_crypto_scalarmult_ristretto255_base($response);
            $cy = sodium_crypto_scalarmult_ristretto255($challenge, $publicKey);
            $rhs = sodium_crypto_core_ristretto255_add($commitment, $cy);
            return hash_equals($lhs, $rhs);
        } catch (\Throwable) {
            return false;
        }
    }

    private static function statementPublicKey(array $statement): string
    {
        $encoded = $statement['possession_public_key'] ?? null;
        if (!is_string($encoded) || $encoded === '') throw new GodModeException('zk-possession-public-key-missing');
        $key = base64_decode($encoded, true);
        if ($key === false || strlen($key) !== SODIUM_CRYPTO_CORE_RISTRETTO255_BYTES || !sodium_crypto_core_ristretto255_is_valid_point($key)) {
            throw new GodModeException('zk-possession-public-key-invalid');
        }
        return $key;
    }

    private static function challenge(array $statement, string $commitment, string $publicKey, array $context): string
    {
        $logicalSystem = (string)($context['proof_system'] ?? '');
        $material = self::DOMAIN
            . hash('sha256', CanonicalJson::encode($statement), true)
            . hash('sha256', $logicalSystem, true)
            . $commitment
            . $publicKey;
        return sodium_crypto_core_ristretto255_scalar_reduce(hash('sha512', $material, true));
    }

    private static function assertRuntime(): void
    {
        foreach ([
            'sodium_crypto_core_ristretto255_scalar_random',
            'sodium_crypto_scalarmult_ristretto255_base',
            'sodium_crypto_core_ristretto255_scalar_reduce',
        ] as $fn) {
            if (!function_exists($fn)) throw new GodModeException('ristretto255-runtime-unavailable');
        }
    }
}
