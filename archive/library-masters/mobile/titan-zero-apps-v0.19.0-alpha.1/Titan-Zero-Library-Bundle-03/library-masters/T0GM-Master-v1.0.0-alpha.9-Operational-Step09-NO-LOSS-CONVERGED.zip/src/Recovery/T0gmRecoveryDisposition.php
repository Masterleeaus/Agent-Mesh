<?php
namespace Titan\GodMode\Recovery;

final class T0gmRecoveryDisposition
{
    public const REVERSE = 'reverse';
    public const COMPENSATE = 'compensate';
    public const RECOMPUTE = 'recompute';
    public const BLOCKED = 'blocked';
    public const REMAIN_INTACT = 'remain_intact';

    public static function all(): array { return [self::REVERSE,self::COMPENSATE,self::RECOMPUTE,self::BLOCKED,self::REMAIN_INTACT]; }
}
