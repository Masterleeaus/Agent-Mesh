<?php
namespace Titan\GodMode\Store;

use PDO;
use Throwable;
use Titan\GodMode\Contracts\SovereignActivityStore;
use Titan\GodMode\Event\T0gmCanonicalHasher;
use Titan\GodMode\Feed\T0gmCausalLinker;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedException;
use Titan\GodMode\Feed\T0gmFeedQuery;
use Titan\GodMode\Feed\T0gmFeedVisibilityPolicy;
use Titan\GodMode\Security\CanonicalJson;

final class PdoSovereignActivityStore implements SovereignActivityStore
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly T0gmFeedVisibilityPolicy $visibility = new T0gmFeedVisibilityPolicy(),
        private readonly T0gmCausalLinker $linker = new T0gmCausalLinker(),
        private readonly T0gmCanonicalHasher $eventHasher = new T0gmCanonicalHasher(),
        private readonly ImmutableRecordHasher $recordHasher = new ImmutableRecordHasher(),
    ) {
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function installSchema(): void
    {
        $sql = file_get_contents(dirname(__DIR__, 2) . '/schemas/t0gm-sovereign-feed-store.sql');
        if ($sql === false) throw new T0gmFeedException('feed-schema-missing');
        $this->pdo->exec($sql);
    }

    public function append(array $event): array
    {
        if (!$this->eventHasher->verify($event)) throw new T0gmFeedException('event-integrity-invalid');
        $eventId = (string)($event['event_id'] ?? '');
        if ($eventId === '') throw new T0gmFeedException('missing-event-id');
        $eventHash = (string)$event['integrity']['canonical_hash'];

        $existing = $this->rawGet($eventId);
        if ($existing !== null) {
            if (($existing['event_hash'] ?? null) !== $eventHash) throw new T0gmFeedException('event-id-conflict');
            return $existing;
        }

        $this->pdo->beginTransaction();
        try {
            $existing = $this->rawGet($eventId);
            if ($existing !== null) {
                if (($existing['event_hash'] ?? null) !== $eventHash) throw new T0gmFeedException('event-id-conflict');
                $this->pdo->commit();
                return $existing;
            }

            $head = $this->auditHead();
            $sequence = $head === null ? 1 : ((int)$head['audit_sequence'] + 1);
            $previousHash = $head['record_hash'] ?? null;
            $record = [
                'audit_sequence' => $sequence,
                'event_id' => $eventId,
                'event_hash' => $eventHash,
                'previous_record_hash' => $previousHash,
                'event' => $event,
            ];
            $record['record_hash'] = $this->recordHasher->hash($record);

            $stmt = $this->pdo->prepare('INSERT INTO t0gm_feed_events (audit_sequence,event_id,event_hash,previous_record_hash,record_hash,company_scope,company_id,event_kind,trace_id,correlation_id,attention_tier,event_json) VALUES (:seq,:event_id,:event_hash,:prev,:record_hash,:scope,:company_id,:kind,:trace,:corr,:attention,:json)');
            $stmt->execute([
                ':seq'=>$sequence, ':event_id'=>$eventId, ':event_hash'=>$eventHash, ':prev'=>$previousHash, ':record_hash'=>$record['record_hash'],
                ':scope'=>$event['company_context']['scope'], ':company_id'=>$event['company_context']['company_id'] ?? null,
                ':kind'=>$event['event_kind'], ':trace'=>$event['lineage']['trace_id'], ':corr'=>$event['lineage']['correlation_id'],
                ':attention'=>$event['oversight']['attention_tier'], ':json'=>CanonicalJson::encode($event),
            ]);

            foreach ($this->linker->edges($event) as $edge) {
                $edgeStmt = $this->pdo->prepare('INSERT INTO t0gm_feed_causal_edges (edge_id,from_event_id,to_event_id,edge_type) VALUES (:id,:f,:t,:type)');
                $edgeStmt->execute([':id'=>$edge['edge_id'],':f'=>$edge['from_event_id'],':t'=>$edge['to_event_id'],':type'=>$edge['edge_type']]);
            }
            foreach (($event['evidence'] ?? []) as $evidence) {
                $evStmt = $this->pdo->prepare('INSERT INTO t0gm_feed_evidence_refs (event_id,evidence_id,evidence_type,source,content_hash,provenance_ref) VALUES (:event_id,:evidence_id,:evidence_type,:source,:content_hash,:provenance_ref)');
                $evStmt->execute([
                    ':event_id'=>$eventId, ':evidence_id'=>$evidence['evidence_id'], ':evidence_type'=>$evidence['evidence_type'], ':source'=>$evidence['source'],
                    ':content_hash'=>$evidence['hash'] ?? null, ':provenance_ref'=>$evidence['provenance_ref'] ?? null,
                ]);
            }

            $this->pdo->commit();
            return $record;
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            if ($e instanceof T0gmFeedException) throw $e;
            if (str_contains(strtolower($e->getMessage()), 'unique')) {
                $existing = $this->rawGet($eventId);
                if ($existing !== null && ($existing['event_hash'] ?? null) === $eventHash) return $existing;
                throw new T0gmFeedException('immutable-store-conflict', $e->getMessage());
            }
            throw $e;
        }
    }

    public function get(string $eventId, T0gmFeedAccessContext $access): ?array
    {
        $record = $this->rawGet($eventId);
        if ($record === null) return null;
        $this->visibility->assertCanView($record['event'], $access);
        return $record;
    }

    public function query(T0gmFeedQuery $query, T0gmFeedAccessContext $access): array
    {
        $where = ['e.audit_sequence > ?'];
        $params = [$query->afterSequence];

        // Apply visibility at persistence selection, then re-check after hydration as defense in depth.
        if (!$access->isSovereign()) {
            $visible = [];
            if ($access->companyIds !== []) {
                $visible[] = "(e.company_scope = 'company' AND e.company_id IN (" . implode(',', array_fill(0, count($access->companyIds), '?')) . ')';
                array_push($params, ...$access->companyIds);
            }
            if ($access->platformVisibility) $visible[] = "e.company_scope = 'platform'";
            if ($visible === []) return [];
            $where[] = '(' . implode(' OR ', $visible) . ')';
        }

        if ($query->eventKinds !== null) {
            if ($query->eventKinds === []) return [];
            $where[] = 'e.event_kind IN (' . implode(',', array_fill(0, count($query->eventKinds), '?')) . ')';
            array_push($params, ...$query->eventKinds);
        }
        if ($query->companyIds !== null) {
            if ($query->companyIds === []) return [];
            $where[] = "e.company_scope = 'company'";
            $where[] = 'e.company_id IN (' . implode(',', array_fill(0, count($query->companyIds), '?')) . ')';
            array_push($params, ...$query->companyIds);
        }
        if ($query->correlationId !== null) { $where[] = 'e.correlation_id = ?'; $params[] = $query->correlationId; }
        if ($query->traceId !== null) { $where[] = 'e.trace_id = ?'; $params[] = $query->traceId; }
        if ($query->evidenceId !== null) {
            $where[] = 'EXISTS (SELECT 1 FROM t0gm_feed_evidence_refs er WHERE er.event_id=e.event_id AND er.evidence_id=?)';
            $params[] = $query->evidenceId;
        }
        if ($query->attentionAtLeast !== null) {
            $rank = ['routine'=>0,'watch'=>1,'important'=>2,'urgent'=>3,'critical'=>4];
            if (!isset($rank[$query->attentionAtLeast])) throw new T0gmFeedException('invalid-attention-tier');
            $allowed = array_keys(array_filter($rank, fn($v) => $v >= $rank[$query->attentionAtLeast]));
            $where[] = 'e.attention_tier IN (' . implode(',', array_fill(0, count($allowed), '?')) . ')';
            array_push($params, ...$allowed);
        }

        $sql = 'SELECT e.* FROM t0gm_feed_events e WHERE ' . implode(' AND ', $where) . ' ORDER BY e.audit_sequence ASC LIMIT ?';
        $params[] = $query->limit;
        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $i => $value) {
            $stmt->bindValue($i + 1, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $stmt->execute();

        $out = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $record = $this->rowToRecord($row);
            if ($this->visibility->canView($record['event'], $access)) $out[] = $record;
        }
        return $out;
    }

    public function causalEdges(string $eventId, T0gmFeedAccessContext $access): array
    {
        $record = $this->rawGet($eventId);
        if ($record !== null) $this->visibility->assertCanView($record['event'], $access);
        $stmt = $this->pdo->prepare('SELECT * FROM t0gm_feed_causal_edges WHERE from_event_id = :id OR to_event_id = :id ORDER BY edge_id');
        $stmt->execute([':id'=>$eventId]);
        $out = [];
        while ($edge = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $otherId = $edge['from_event_id'] === $eventId ? $edge['to_event_id'] : $edge['from_event_id'];
            $other = $this->rawGet($otherId);
            if ($other === null && !$access->isSovereign()) continue;
            if ($other !== null && !$this->visibility->canView($other['event'], $access)) continue;
            $out[] = $edge;
        }
        return $out;
    }

    public function byEvidence(string $evidenceId, T0gmFeedAccessContext $access): array
    {
        $stmt = $this->pdo->prepare('SELECT e.* FROM t0gm_feed_events e JOIN t0gm_feed_evidence_refs r ON r.event_id=e.event_id WHERE r.evidence_id=:id ORDER BY e.audit_sequence');
        $stmt->execute([':id'=>$evidenceId]);
        return $this->visibleRows($stmt->fetchAll(PDO::FETCH_ASSOC), $access);
    }

    public function byCorrelation(string $correlationId, T0gmFeedAccessContext $access): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM t0gm_feed_events WHERE correlation_id=:id ORDER BY audit_sequence');
        $stmt->execute([':id'=>$correlationId]);
        return $this->visibleRows($stmt->fetchAll(PDO::FETCH_ASSOC), $access);
    }

    public function auditHead(): ?array
    {
        $row = $this->pdo->query('SELECT * FROM t0gm_feed_events ORDER BY audit_sequence DESC LIMIT 1')->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $this->rowToRecord($row);
    }

    public function verifyAuditLineage(): bool
    {
        $stmt = $this->pdo->query('SELECT * FROM t0gm_feed_events ORDER BY audit_sequence ASC');
        $previous = null; $expected = 1;
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $record = $this->rowToRecord($row);
            if ($record['audit_sequence'] !== $expected) return false;
            if ($record['previous_record_hash'] !== $previous) return false;
            if (!$this->recordHasher->verify($record)) return false;
            if (!$this->eventHasher->verify($record['event'])) return false;
            if ($record['event_hash'] !== ($record['event']['integrity']['canonical_hash'] ?? null)) return false;
            $previous = $record['record_hash']; $expected++;
        }
        return true;
    }

    private function rawGet(string $eventId): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM t0gm_feed_events WHERE event_id = :id');
        $stmt->execute([':id'=>$eventId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $this->rowToRecord($row);
    }

    private function rowToRecord(array $row): array
    {
        return [
            'audit_sequence'=>(int)$row['audit_sequence'], 'event_id'=>$row['event_id'], 'event_hash'=>$row['event_hash'],
            'previous_record_hash'=>$row['previous_record_hash'] === null ? null : $row['previous_record_hash'],
            'event'=>json_decode($row['event_json'], true, 512, JSON_THROW_ON_ERROR), 'record_hash'=>$row['record_hash'],
        ];
    }

    private function visibleRows(array $rows, T0gmFeedAccessContext $access): array
    {
        $out=[]; foreach ($rows as $row) { $r=$this->rowToRecord($row); if ($this->visibility->canView($r['event'],$access)) $out[]=$r; } return $out;
    }

    private function hasEvidence(string $eventId, string $evidenceId): bool
    {
        $stmt=$this->pdo->prepare('SELECT 1 FROM t0gm_feed_evidence_refs WHERE event_id=:e AND evidence_id=:i LIMIT 1');
        $stmt->execute([':e'=>$eventId,':i'=>$evidenceId]); return $stmt->fetchColumn() !== false;
    }

    private function attentionAtLeast(string $actual, string $minimum): bool
    {
        $rank=['routine'=>0,'watch'=>1,'important'=>2,'urgent'=>3,'critical'=>4];
        if (!isset($rank[$actual],$rank[$minimum])) throw new T0gmFeedException('invalid-attention-tier');
        return $rank[$actual] >= $rank[$minimum];
    }
}
