<?php
namespace Titan\GodMode\PolicyDistribution;

use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmPolicyBundleSigner
{
    public function sign(array $bundle,string $keyId,string $secretKey):array
    {
        if(strlen($secretKey)!==SODIUM_CRYPTO_SIGN_SECRETKEYBYTES)throw new GodModeException('invalid-signed-policy-secret-key');
        $bundle=$this->seal($bundle);
        return [
            'schema'=>'titan.t0gm.signed-policy-envelope.v1','bundle'=>$bundle,'signer_key_id'=>$keyId,'signature_suite'=>'ed25519',
            'signature'=>base64_encode(sodium_crypto_sign_detached(CanonicalJson::encode($bundle),$secretKey)),
            'semantics'=>['attests'=>'policy_origin_and_integrity','signature_grants_authority'=>false],
        ];
    }
    private function seal(array $b):array
    {
        foreach(['schema','policy_class','policy_id','scope','revision','issued_at','effective_from','content','semantics'] as $f)if(!array_key_exists($f,$b))throw new GodModeException('signed-policy-missing-field:'.$f);
        if($b['schema']!=='titan.t0gm.signed-policy-bundle.v1')throw new GodModeException('signed-policy-schema-invalid');
        if(!in_array($b['policy_class'],['constitution','policy','overlay','configuration'],true))throw new GodModeException('signed-policy-class-invalid');
        if(!is_array($b['content'])||!is_array($b['scope']))throw new GodModeException('signed-policy-structure-invalid');
        $b['content_digest']='sha256:'.hash('sha256',CanonicalJson::encode($b['content']));
        return $b;
    }
}
