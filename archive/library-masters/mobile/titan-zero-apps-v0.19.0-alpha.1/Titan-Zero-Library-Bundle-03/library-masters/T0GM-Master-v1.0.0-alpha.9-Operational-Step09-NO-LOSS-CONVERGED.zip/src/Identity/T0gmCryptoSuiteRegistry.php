<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Security\GodModeException;

final class T0gmCryptoSuiteRegistry
{
    public const ED25519 = 'ed25519';
    public const ML_DSA_44 = 'ml-dsa-44';
    public const ML_DSA_65 = 'ml-dsa-65';
    public const ML_DSA_87 = 'ml-dsa-87';
    public const SLH_DSA_SHA2_128S = 'slh-dsa-sha2-128s';

    public function __construct(private readonly ?OpenSslPqcSignatureVerifier $pqc = null) {}

    public function verify(string $suite, string $signature, string $message, string $publicKey): bool
    {
        return match ($suite) {
            self::ED25519 => $this->verifyEd25519($signature, $message, $publicKey),
            self::ML_DSA_44, self::ML_DSA_65, self::ML_DSA_87, self::SLH_DSA_SHA2_128S => ($this->pqc ?? new OpenSslPqcSignatureVerifier())->verify($suite,$signature,$message,$publicKey),
            default => throw new GodModeException('unsupported-crypto-suite:' . $suite),
        };
    }

    public function supportedSuites(): array
    {
        $out=[self::ED25519];
        $pqc=$this->pqc ?? new OpenSslPqcSignatureVerifier();
        foreach ([self::ML_DSA_44,self::ML_DSA_65,self::ML_DSA_87,self::SLH_DSA_SHA2_128S] as $suite) if ($pqc->supports($suite)) $out[]=$suite;
        return $out;
    }

    private function verifyEd25519(string $signature, string $message, string $publicKey): bool
    {
        if (strlen($signature) !== SODIUM_CRYPTO_SIGN_BYTES || strlen($publicKey) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) return false;
        return sodium_crypto_sign_verify_detached($signature, $message, $publicKey);
    }
}
