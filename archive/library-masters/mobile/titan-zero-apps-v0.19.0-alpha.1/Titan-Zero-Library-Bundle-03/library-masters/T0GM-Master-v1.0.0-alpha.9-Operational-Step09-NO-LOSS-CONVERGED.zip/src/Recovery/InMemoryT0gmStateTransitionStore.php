<?php
namespace Titan\GodMode\Recovery;

final class InMemoryT0gmStateTransitionStore
{
    private array $byId=[]; private array $byEvent=[];
    public function __construct(private readonly T0gmStateTransitionValidator $validator=new T0gmStateTransitionValidator(),private readonly T0gmStateTransitionHasher $hasher=new T0gmStateTransitionHasher()){}
    public function append(array $t):array { $this->validator->validate($t); if(!$this->hasher->verify($t)) throw new T0gmStateTransitionException('transition-integrity-invalid'); $id=$t['transition_id']; if(isset($this->byId[$id])){ if($this->byId[$id]['integrity']['canonical_hash']!==$t['integrity']['canonical_hash']) throw new T0gmStateTransitionException('transition-id-conflict'); return $this->byId[$id]; } $this->byId[$id]=$t; $this->byEvent[$t['source_event_id']][]=$id; return $t; }
    public function get(string $id):?array { return $this->byId[$id]??null; }
    public function bySourceEvent(string $eventId):array { return array_values(array_map(fn($id)=>$this->byId[$id],$this->byEvent[$eventId]??[])); }
}
