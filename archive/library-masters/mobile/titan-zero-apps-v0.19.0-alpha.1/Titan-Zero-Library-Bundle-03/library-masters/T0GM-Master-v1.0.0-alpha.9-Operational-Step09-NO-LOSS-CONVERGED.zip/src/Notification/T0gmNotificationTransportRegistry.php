<?php
namespace Titan\GodMode\Notification;

final class T0gmNotificationTransportRegistry
{
    /** @var array<string,T0gmNotificationTransport> */ private array $transports=[];
    public function __construct(T0gmNotificationTransport ...$transports) { foreach($transports as $t) $this->transports[$t->channel()]=$t; }
    public function get(string $channel): ?T0gmNotificationTransport { return $this->transports[$channel] ?? null; }
}
