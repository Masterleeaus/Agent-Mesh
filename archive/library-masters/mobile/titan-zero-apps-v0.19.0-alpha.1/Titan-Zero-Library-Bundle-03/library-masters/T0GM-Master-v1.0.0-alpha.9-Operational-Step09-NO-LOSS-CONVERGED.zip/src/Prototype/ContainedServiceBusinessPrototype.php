<?php
namespace Titan\GodMode\Prototype;

use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedIngestor;
use Titan\GodMode\Recovery\T0gmStateTransitionFactory;
use Titan\GodMode\Verification\T0gmContinuousVerificationEngine;

final class ContainedServiceBusinessPrototype
{
    public function __construct(
        private readonly InMemoryServiceBusinessState $state,
        private readonly T0gmFeedIngestor $feed,
        private readonly T0gmContinuousVerificationEngine $verification,
        private readonly T0gmEventFactory $events=new T0gmEventFactory(),
        private readonly T0gmStateTransitionFactory $transitions=new T0gmStateTransitionFactory(),
    ){}

    public function companyId(): string { return $this->state->companyId; }
    public function snapshot(): array { return $this->state->snapshot(); }

    public function act(string $companyId,string $action,string $recordId,array $input,string $actorId='service-ops',string $actorType='human'): ServiceBusinessActionResult
    {
        if($companyId!==$this->state->companyId) throw new \RuntimeException('company-id-boundary-violation');
        $domain=ContainedServiceBusinessProfile::domainFor($action);
        if(trim($recordId)==='') throw new \InvalidArgumentException('record-id-required');
        $pre=$this->state->get($domain,$recordId) ?? [];
        $next=$this->reduce($action,$recordId,$pre,$input);
        $kind=$action==='ai.recommendation.record'?T0gmEventKind::AI_DECISION:T0gmEventKind::EXECUTION;
        $eventId='svc_evt_'.bin2hex(random_bytes(10));
        $event=$this->events->make(
            $kind,
            ['scope'=>'company','company_id'=>$companyId],
            ['actor_type'=>$actorType,'actor_id'=>$actorId,'authority_class'=>$actorType==='advanced_intelligence'?'delegated_ai':'company_operator'],
            ['system'=>'titan.service-business.prototype','component'=>$domain],
            ['subject_type'=>$domain,'subject_id'=>$recordId],
            ['trace_id'=>'svc_tr_'.bin2hex(random_bytes(8)),'correlation_id'=>$input['correlation_id']??('svc_corr_'.$recordId),'causation_id'=>$input['causation_id']??null,'parent_event_ids'=>$input['parent_event_ids']??[]],
            $this->riskFor($action,$input),
            ['visibility'=>'t0gm_sovereign','attention_tier'=>$this->attentionFor($action,$input),'review_required'=>$actorType==='advanced_intelligence','review_team'=>$actorType==='advanced_intelligence'?['operational','governance']:[]],
            $input['evidence']??[],
            $kind===T0gmEventKind::AI_DECISION
                ? ['decision'=>['decision_id'=>'svc_ai_'.$recordId,'determination'=>(string)($next['recommendation']??'recommendation recorded'),'reason_codes'=>['contained-service-business-recommendation'],'confidence'=>$input['confidence']??0.75,'autonomous'=>false,'execution_authority'=>false]]
                : ['execution'=>['execution_id'=>'svc_exec_'.$recordId,'state'=>'completed','adapter'=>'contained-service-business','action'=>$action]],
            $eventId
        );
        $this->feed->ingest($event);

        if($kind===T0gmEventKind::AI_DECISION){
            $this->state->put($domain,$recordId,$next);
            return new ServiceBusinessActionResult($event,null,null,$next);
        }

        $this->state->put($domain,$recordId,$next);
        $transition=$this->transitions->make(
            $companyId,$eventId,$action,
            ['subject_type'=>$domain,'subject_id'=>$recordId],
            $pre,$next,$next,
            $input['dependencies']??[],
            ['score'=>$this->reversibilityFor($action),'mode'=>'direct','inverse_effect'=>'prototype.restore_pre_state'],
            $input['evidence']??[]
        );
        $verification=$this->verification->observe($transition,$this->state->get($domain,$recordId)??[], $this->dependencyState($input['dependencies']??[]));
        return new ServiceBusinessActionResult($event,$transition,$verification,$next);
    }

    private function reduce(string $action,string $id,array $pre,array $in): array
    {
        return match($action){
            'crm.lead.create'=>array_merge($pre,['lead_id'=>$id,'name'=>$in['name']??'Unknown','status'=>'new','source'=>$in['source']??'manual']),
            'crm.customer.update'=>array_merge($pre,$in,['customer_id'=>$id]),
            'booking.create'=>array_merge($pre,['booking_id'=>$id,'customer_id'=>$in['customer_id']??null,'scheduled_at'=>$in['scheduled_at']??null,'status'=>'booked']),
            'job.status.set'=>array_merge($pre,['job_id'=>$id,'status'=>$in['status']??'scheduled']),
            'finance.invoice.issue'=>array_merge($pre,['invoice_id'=>$id,'customer_id'=>$in['customer_id']??null,'amount'=>$in['amount']??0,'currency'=>$in['currency']??'AUD','status'=>'issued']),
            'finance.payment.record'=>array_merge($pre,['payment_id'=>$id,'invoice_id'=>$in['invoice_id']??null,'amount'=>$in['amount']??0,'currency'=>$in['currency']??'AUD','status'=>'recorded']),
            'staff.assign'=>array_merge($pre,['assignment_id'=>$id,'worker_id'=>$in['worker_id']??null,'booking_id'=>$in['booking_id']??null,'status'=>'assigned']),
            'communication.send'=>array_merge($pre,['message_id'=>$id,'channel'=>$in['channel']??'email','recipient_ref'=>$in['recipient_ref']??null,'status'=>'sent']),
            'ai.recommendation.record'=>['recommendation_id'=>$id,'recommendation'=>$in['recommendation']??'','confidence'=>$in['confidence']??0.75,'execution_authority'=>false],
            default=>throw new \InvalidArgumentException('unsupported-contained-service-action')
        };
    }

    private function riskFor(string $action,array $input): array
    {
        $score=(int)($input['risk_score']??match(true){str_starts_with($action,'finance.')=>45,$action==='staff.assign'=>30,$action==='communication.send'=>25,default=>20});
        $band=$score>=80?'extreme':($score>=60?'high':($score>=40?'medium':($score>=20?'low':'minimal')));
        return ['score'=>$score,'band'=>$band,'dimensions'=>[$this->riskDimension($action)=>$score]];
    }
    private function riskDimension(string $action): string { return str_starts_with($action,'finance.')?'financial':($action==='communication.send'?'privacy':'operational'); }
    private function attentionFor(string $action,array $input): string { $s=(int)($input['risk_score']??20); return $s>=80?'critical':($s>=60?'urgent':($s>=40?'important':($s>=20?'watch':'routine'))); }
    private function reversibilityFor(string $action): int { return match($action){'finance.payment.record'=>65,'communication.send'=>20,default=>85}; }
    private function dependencyState(array $deps): array { $out=[]; foreach($deps as $d){if(isset($d['dependency_id']))$out[$d['dependency_id']]=$d['required_state']??null;} return $out; }
}
