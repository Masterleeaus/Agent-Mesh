<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Security\GodModeException;

/**
 * Thin verifier adapter around OpenSSL's native PQC implementation.
 * It never generates or stores sovereign private keys.
 */
final class OpenSslPqcSignatureVerifier
{
    private const SUITES = [
        'ml-dsa-44' => 'ML-DSA-44',
        'ml-dsa-65' => 'ML-DSA-65',
        'ml-dsa-87' => 'ML-DSA-87',
        'slh-dsa-sha2-128s' => 'SLH-DSA-SHA2-128s',
    ];

    public function __construct(private readonly string $opensslBinary = 'openssl') {}

    public function supports(string $suite): bool
    {
        return isset(self::SUITES[$suite]) && $this->binaryAvailable();
    }

    public function verify(string $suite, string $signature, string $message, string $publicKeyPem): bool
    {
        if (!isset(self::SUITES[$suite])) throw new GodModeException('unsupported-pqc-signature-suite:' . $suite);
        if (!$this->binaryAvailable()) throw new GodModeException('pqc-verifier-unavailable');
        if (!str_contains($publicKeyPem, 'BEGIN PUBLIC KEY')) throw new GodModeException('pqc-public-key-must-be-pem');

        $dir = sys_get_temp_dir() . '/t0gm-pqc-' . bin2hex(random_bytes(10));
        if (!mkdir($dir, 0700, true) && !is_dir($dir)) throw new GodModeException('pqc-verifier-tempdir-failed');
        $pub = $dir . '/public.pem'; $msg = $dir . '/message.bin'; $sig = $dir . '/signature.bin';
        try {
            if (file_put_contents($pub, $publicKeyPem, LOCK_EX) === false ||
                file_put_contents($msg, $message, LOCK_EX) === false ||
                file_put_contents($sig, $signature, LOCK_EX) === false) {
                throw new GodModeException('pqc-verifier-tempfile-failed');
            }
            @chmod($pub,0600); @chmod($msg,0600); @chmod($sig,0600);
            $cmd = [$this->opensslBinary, 'pkeyutl', '-verify', '-pubin', '-inkey', $pub, '-in', $msg, '-sigfile', $sig];
            $spec = [0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']];
            $proc = proc_open($cmd,$spec,$pipes,null,['LC_ALL'=>'C']);
            if (!is_resource($proc)) throw new GodModeException('pqc-verifier-process-failed');
            fclose($pipes[0]); stream_get_contents($pipes[1]); fclose($pipes[1]); stream_get_contents($pipes[2]); fclose($pipes[2]);
            return proc_close($proc) === 0;
        } finally {
            @unlink($pub); @unlink($msg); @unlink($sig); @rmdir($dir);
        }
    }

    private function binaryAvailable(): bool
    {
        $cmd = [$this->opensslBinary, 'version'];
        $spec = [0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']];
        $proc = @proc_open($cmd,$spec,$pipes);
        if (!is_resource($proc)) return false;
        fclose($pipes[0]); stream_get_contents($pipes[1]); fclose($pipes[1]); stream_get_contents($pipes[2]); fclose($pipes[2]);
        return proc_close($proc) === 0;
    }
}
