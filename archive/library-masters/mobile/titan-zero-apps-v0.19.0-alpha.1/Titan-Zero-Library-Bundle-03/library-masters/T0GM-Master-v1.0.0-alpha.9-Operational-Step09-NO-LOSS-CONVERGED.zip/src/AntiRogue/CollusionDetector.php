<?php
namespace Titan\GodMode\AntiRogue;

final class CollusionDetector
{
    public function detect(array $events): array
    {
        $groups=[];
        foreach($events as $e){$key=(string)($e['shared_objective']??'').'|'.(string)($e['company_id']??'').'|'.(string)($e['target_id']??''); if($key==='||')continue; $groups[$key][]=$e;}
        $findings=[];
        foreach($groups as $key=>$group){$actors=array_values(array_unique(array_map(fn($e)=>(string)($e['actor_id']??''),$group))); $signals=array_values(array_unique(array_map(fn($e)=>(string)($e['signal']??''),$group))); if(count(array_filter($actors))>=2 && count(array_intersect($signals,['hide_delegation','suppress_feed','forge_evidence','persist_authority','disable_recovery']))>=2){$findings[]=['key'=>$key,'actors'=>$actors,'signals'=>$signals,'collusion'=>true];}}
        return $findings;
    }
}
