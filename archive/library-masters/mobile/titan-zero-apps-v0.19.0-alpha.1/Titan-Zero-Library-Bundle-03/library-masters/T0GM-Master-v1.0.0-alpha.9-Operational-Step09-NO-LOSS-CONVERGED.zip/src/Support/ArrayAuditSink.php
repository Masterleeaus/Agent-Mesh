<?php
namespace Titan\GodMode\Support;

use Titan\GodMode\Contracts\AuditSink;

final class ArrayAuditSink implements AuditSink
{
    public array $events = [];

    public function record(array $event): void
    {
        $this->events[] = $event;
    }
}
