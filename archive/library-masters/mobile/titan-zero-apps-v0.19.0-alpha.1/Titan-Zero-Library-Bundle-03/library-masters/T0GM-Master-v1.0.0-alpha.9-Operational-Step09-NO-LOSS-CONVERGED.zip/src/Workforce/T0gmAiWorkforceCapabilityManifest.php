<?php
namespace Titan\GodMode\Workforce;

use Titan\GodMode\Security\GodModeException;

final class T0gmAiWorkforceCapabilityManifest
{
    private const CLASSES=['observe','reason','recommend','request','execute'];
    private array $manifests=[];

    public function __construct(private readonly T0gmCanonicalAiWorkforceRegistry $registry) {}

    public function define(string $companyId,string $workerId,array $definition):array
    {
        foreach(['tenant_id','tenant_company_id'] as $legacy) {
            if(array_key_exists($legacy,$definition)) throw new GodModeException('legacy-tenant-boundary-forbidden:'.$legacy);
        }

        $worker=$this->registry->get($companyId,$workerId);
        if(($worker['kind']??null)!=='worker') throw new GodModeException('ai-capability-manifest-worker-required');

        $issuedBy=trim((string)($definition['issued_by']??''));
        if($issuedBy==='') throw new GodModeException('ai-capability-manifest-issuer-required');
        if($issuedBy===$workerId) throw new GodModeException('ai-capability-manifest-self-issuance-forbidden');

        $revision=(int)($definition['revision']??0);
        if($revision<1) throw new GodModeException('ai-capability-manifest-revision-required');
        $current=$this->manifests[$companyId][$workerId]??null;
        if($current!==null && $revision<=(int)$current['revision']) throw new GodModeException('ai-capability-manifest-revision-not-monotonic');

        $caps=[];
        foreach(self::CLASSES as $class) $caps[$class]=$this->normaliseCapabilities($definition[$class]??[]);
        $constraints=is_array($definition['constraints']??null)?$definition['constraints']:[];
        $manifest=[
            'schema'=>'titan.t0gm.ai-workforce-capability-manifest.v1',
            'company_id'=>$companyId,
            'worker_id'=>$workerId,
            'worker_registry_integrity_digest'=>(string)$worker['integrity_digest'],
            'revision'=>$revision,
            'issued_by'=>$issuedBy,
            'capabilities'=>$caps,
            'constraints'=>$constraints,
            'self_modifiable'=>false,
            'authority_self_escalation_allowed'=>false,
            'execution_requires_governed_authorization'=>true,
            'manifest_is_declarative'=>true,
            'grants_t0gm_authority'=>false,
            'sovereign_authority_inherited'=>false,
        ];
        $manifest['manifest_digest']=$this->digest($manifest);
        $this->manifests[$companyId][$workerId]=$manifest;
        return $manifest;
    }

    public function get(string $companyId,string $workerId):array
    {
        if(!isset($this->manifests[$companyId][$workerId])) throw new GodModeException('ai-capability-manifest-not-found');
        $m=$this->manifests[$companyId][$workerId];
        $worker=$this->registry->get($companyId,$workerId);
        if(!hash_equals((string)$worker['integrity_digest'],(string)$m['worker_registry_integrity_digest'])) throw new GodModeException('ai-capability-manifest-worker-state-mismatch');
        return $m;
    }

    public function allows(string $companyId,string $workerId,string $class,string $capability):bool
    {
        if(!in_array($class,self::CLASSES,true)) throw new GodModeException('unsupported-ai-capability-class:'.$class);
        return in_array($capability,$this->get($companyId,$workerId)['capabilities'][$class],true);
    }

    public function verify(array $manifest):bool
    {
        if(($manifest['schema']??null)!=='titan.t0gm.ai-workforce-capability-manifest.v1') throw new GodModeException('ai-capability-manifest-schema-invalid');
        $supplied=(string)($manifest['manifest_digest']??'');
        $copy=$manifest; unset($copy['manifest_digest']);
        if(!preg_match('/^[a-f0-9]{64}$/',$supplied)||!hash_equals($this->digest($copy),$supplied)) throw new GodModeException('ai-capability-manifest-digest-mismatch');
        if(($manifest['self_modifiable']??null)!==false || ($manifest['authority_self_escalation_allowed']??null)!==false) throw new GodModeException('ai-capability-manifest-self-escalation-semantics-invalid');
        if(($manifest['execution_requires_governed_authorization']??null)!==true) throw new GodModeException('ai-capability-manifest-execution-semantics-invalid');
        $worker=$this->registry->get((string)$manifest['company_id'],(string)$manifest['worker_id']);
        if(($worker['kind']??null)!=='worker') throw new GodModeException('ai-capability-manifest-worker-required');
        if(!hash_equals((string)$worker['integrity_digest'],(string)$manifest['worker_registry_integrity_digest'])) throw new GodModeException('ai-capability-manifest-worker-state-mismatch');
        return true;
    }

    public static function classes():array{return self::CLASSES;}

    private function normaliseCapabilities(mixed $value):array
    {
        if(!is_array($value)) throw new GodModeException('ai-capability-list-required');
        $out=[];
        foreach($value as $cap){
            $cap=trim((string)$cap);
            if($cap==='') throw new GodModeException('ai-capability-id-required');
            if(!preg_match('/^[a-z0-9][a-z0-9._:-]*$/',$cap)) throw new GodModeException('ai-capability-id-invalid:'.$cap);
            $out[$cap]=true;
        }
        return array_keys($out);
    }

    private function digest(array $value):string
    {
        return hash('sha256',json_encode($this->canonicalise($value),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION|JSON_THROW_ON_ERROR));
    }

    private function canonicalise(mixed $value):mixed
    {
        if(!is_array($value)) return $value;
        if(array_is_list($value)) return array_map(fn($v)=>$this->canonicalise($v),$value);
        ksort($value,SORT_STRING);
        foreach($value as $k=>$v)$value[$k]=$this->canonicalise($v);
        return $value;
    }
}
