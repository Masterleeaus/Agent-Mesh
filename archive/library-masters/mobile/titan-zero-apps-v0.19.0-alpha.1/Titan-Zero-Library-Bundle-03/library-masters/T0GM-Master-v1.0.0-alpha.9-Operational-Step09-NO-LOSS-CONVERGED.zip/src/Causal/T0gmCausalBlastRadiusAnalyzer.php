<?php
namespace Titan\GodMode\Causal;

use InvalidArgumentException;
use Titan\GodMode\Contracts\SovereignActivityStore;
use Titan\GodMode\Feed\T0gmFeedAccessContext;

final class T0gmCausalBlastRadiusAnalyzer
{
    public function forecast(string $rootId, T0gmProspectiveCausalGraph $graph, int $maxDepth = 32): T0gmBlastRadiusReport
    {
        if ($graph->node($rootId) === null) throw new InvalidArgumentException('blast-radius-root-not-found');
        $maxDepth = max(0, min(256, $maxDepth));
        $visited = [];
        $paths = [];
        $queue = [[$rootId, 0, [$rootId], 1.0]];
        while ($queue !== []) {
            [$current,$depth,$path,$confidence] = array_shift($queue);
            if (isset($visited[$current]) && $visited[$current]['depth'] <= $depth) continue;
            $visited[$current] = ['depth'=>$depth,'confidence'=>$confidence];
            $paths[] = ['node_id'=>$current,'depth'=>$depth,'path'=>$path,'confidence'=>$confidence];
            if ($depth >= $maxDepth) continue;
            foreach ($graph->outgoingCausal($current) as $edge) {
                $nextPath = $path; $nextPath[] = $edge['to'];
                $queue[] = [$edge['to'],$depth+1,$nextPath,$confidence*$edge['confidence']];
            }
        }
        $nodes = [];
        foreach (array_keys($visited) as $id) $nodes[$id] = $graph->node($id);
        return $this->report('forecast',$rootId,$nodes,$visited,$paths);
    }

    public function observe(string $rootEventId, SovereignActivityStore $store, T0gmFeedAccessContext $access, int $maxDepth = 32): T0gmBlastRadiusReport
    {
        $rootRecord = $store->get($rootEventId,$access);
        if ($rootRecord === null) throw new InvalidArgumentException('blast-radius-root-event-not-found');
        $maxDepth = max(0, min(256, $maxDepth));
        $visited = [];
        $nodes = [];
        $paths = [];
        $queue = [[$rootEventId,0,[$rootEventId]]];
        while ($queue !== []) {
            [$current,$depth,$path] = array_shift($queue);
            if (isset($visited[$current]) && $visited[$current]['depth'] <= $depth) continue;
            $record = $store->get($current,$access);
            if ($record === null) continue;
            $event = $record['event'] ?? [];
            $visited[$current] = ['depth'=>$depth,'confidence'=>1.0];
            $nodes[$current] = $this->eventToNode($current,$event);
            $paths[] = ['node_id'=>$current,'depth'=>$depth,'path'=>$path,'confidence'=>1.0];
            if ($depth >= $maxDepth) continue;
            foreach ($store->causalEdges($current,$access) as $edge) {
                if (!in_array($edge['edge_type'] ?? null,['causes','parent_of'],true)) continue;
                if (($edge['from_event_id'] ?? null) !== $current) continue;
                $next = (string)($edge['to_event_id'] ?? '');
                if ($next === '') continue;
                $nextPath = $path; $nextPath[] = $next;
                $queue[] = [$next,$depth+1,$nextPath];
            }
        }
        return $this->report('observed',$rootEventId,$nodes,$visited,$paths);
    }

    /**
     * Compare immutable forecast to later observation without mutating either.
     * @param array<string,string> $forecastToObservedIdMap
     */
    public function compare(T0gmBlastRadiusReport $forecast, T0gmBlastRadiusReport $observed, array $forecastToObservedIdMap = []): array
    {
        $observedSet = array_fill_keys($observed->affectedNodeIds,true);
        $expectedObserved = [];
        $notObservedForecast = [];
        foreach ($forecast->affectedNodeIds as $forecastId) {
            $mapped = $forecastToObservedIdMap[$forecastId] ?? null;
            if ($mapped !== null) {
                $expectedObserved[$mapped] = true;
                if (!isset($observedSet[$mapped])) $notObservedForecast[] = $forecastId;
            }
        }
        $unexpected = [];
        foreach ($observed->affectedNodeIds as $observedId) {
            if (!isset($expectedObserved[$observedId])) $unexpected[] = $observedId;
        }
        sort($unexpected); sort($notObservedForecast);

        return [
            'forecast_root_id'=>$forecast->rootId,
            'observed_root_id'=>$observed->rootId,
            'unexpected_observed_ids'=>$unexpected,
            'forecast_ids_not_observed'=>$notObservedForecast,
            'new_companies'=>array_values(array_diff($observed->affectedCompanies,$forecast->affectedCompanies)),
            'new_systems'=>array_values(array_diff($observed->affectedSystems,$forecast->affectedSystems)),
            'new_workers'=>array_values(array_diff($observed->affectedWorkers,$forecast->affectedWorkers)),
            'new_decisions'=>array_values(array_diff($observed->affectedDecisions,$forecast->affectedDecisions)),
            'forecast_rewritten'=>false,
            'authority_granted'=>false,
            'analysis_only'=>true,
        ];
    }

    /** @param array<string,array<string,mixed>|null> $nodes */
    private function report(string $phase,string $rootId,array $nodes,array $visited,array $paths): T0gmBlastRadiusReport
    {
        $companies=[]; $systems=[]; $workers=[]; $decisions=[]; $highestRisk=0; $depth=0;
        foreach ($nodes as $id=>$node) {
            if (!is_array($node)) continue;
            $this->add($companies,$node['company_id'] ?? null);
            $this->add($systems,$node['system'] ?? null);
            $this->add($workers,$node['worker_id'] ?? null);
            $this->add($decisions,$node['decision_id'] ?? null);
            $highestRisk=max($highestRisk,(int)($node['risk_score'] ?? 0));
            $depth=max($depth,(int)($visited[$id]['depth'] ?? 0));
        }
        sort($companies); sort($systems); sort($workers); sort($decisions);
        $ids=array_keys($visited); sort($ids);
        usort($paths,fn(array $a,array $b): int => [$a['depth'],$a['node_id']] <=> [$b['depth'],$b['node_id']]);
        return new T0gmBlastRadiusReport($phase,$rootId,$companies,$systems,$workers,$decisions,$ids,$depth,count($companies)>1,$highestRisk,$paths,false);
    }

    private function eventToNode(string $id,array $event): array
    {
        $actor = $event['actor'] ?? [];
        $workerId = null;
        if (is_string($actor['worker_id'] ?? null) && $actor['worker_id'] !== '') $workerId = $actor['worker_id'];
        return [
            'node_id'=>$id,
            'node_type'=>(string)($event['event_kind'] ?? 'event'),
            'company_id'=>$event['company_context']['company_id'] ?? null,
            'system'=>$event['source']['system'] ?? null,
            'worker_id'=>$workerId,
            'decision_id'=>$event['decision']['decision_id'] ?? null,
            'risk_score'=>(int)($event['risk']['score'] ?? 0),
        ];
    }

    private function add(array &$set,mixed $value): void
    {
        if (is_string($value) && $value !== '') $set[$value]=$value;
    }
}
