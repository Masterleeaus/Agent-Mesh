<?php
namespace Titan\GodMode\Authority;

final class ExecutionAuthorityDecision
{
    public function __construct(
        public readonly bool $allowed,
        public readonly array $reasons,
        public readonly ?string $matchedEffectId = null,
        public readonly array $lineage = [],
    ) {}
}
