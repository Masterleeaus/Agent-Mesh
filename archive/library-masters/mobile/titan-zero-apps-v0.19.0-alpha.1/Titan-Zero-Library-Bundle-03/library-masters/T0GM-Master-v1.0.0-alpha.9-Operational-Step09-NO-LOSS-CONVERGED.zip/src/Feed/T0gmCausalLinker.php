<?php
namespace Titan\GodMode\Feed;

final class T0gmCausalLinker
{
    /** Produce deterministic outgoing relationships contained in a canonical event. */
    public function edges(array $event): array
    {
        $eventId = (string)($event['event_id'] ?? '');
        $edges = [];
        $lineage = $event['lineage'] ?? [];

        $cause = $lineage['causation_id'] ?? null;
        if (is_string($cause) && $cause !== '') $edges[] = $this->edge($cause, $eventId, 'causes');

        foreach (($lineage['parent_event_ids'] ?? []) as $parent) {
            if (is_string($parent) && $parent !== '') $edges[] = $this->edge($parent, $eventId, 'parent_of');
        }

        foreach (($event['supersession']['supersedes_event_ids'] ?? []) as $target) {
            if (is_string($target) && $target !== '') $edges[] = $this->edge($eventId, $target, 'supersedes');
        }

        $unique = [];
        foreach ($edges as $edge) $unique[$edge['edge_id']] = $edge;
        return array_values($unique);
    }

    private function edge(string $from, string $to, string $type): array
    {
        return [
            'edge_id' => hash('sha256', $type . "\0" . $from . "\0" . $to),
            'from_event_id' => $from,
            'to_event_id' => $to,
            'edge_type' => $type,
        ];
    }
}
