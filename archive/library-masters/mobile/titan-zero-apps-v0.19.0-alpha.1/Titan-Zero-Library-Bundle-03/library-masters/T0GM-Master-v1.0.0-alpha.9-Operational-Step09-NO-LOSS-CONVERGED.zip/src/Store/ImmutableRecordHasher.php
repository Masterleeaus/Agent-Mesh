<?php
namespace Titan\GodMode\Store;

use Titan\GodMode\Security\CanonicalJson;

final class ImmutableRecordHasher
{
    public function hash(array $record): string
    {
        $copy = $record;
        unset($copy['record_hash']);
        return hash('sha256', CanonicalJson::encode($copy));
    }

    public function verify(array $record): bool
    {
        $hash = $record['record_hash'] ?? null;
        return is_string($hash) && hash_equals($hash, $this->hash($record));
    }
}
