<?php
namespace Titan\GodMode\Contracts;

interface ZeroKnowledgeProverBroker
{
    /**
     * Execute proving outside the Titan application trust boundary. Titan passes a
     * stable witness reference, never secret witness bytes.
     */
    public function prove(string $providerId, string $witnessRef, array $publicStatement, array $context = []): string;
}
