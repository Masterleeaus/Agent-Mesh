<?php
namespace Titan\GodMode\App;
use Titan\GodMode\Security\GodModeException;
final class T0gmDeviceState
{
    private function __construct(private readonly array $data){}
    public static function fromEvidence(array $e):self
    {
        foreach(['device_binding_id','trust_state','integrity_state','isolation_state','connectivity','observed_at','evidence_digest'] as $f){if(trim((string)($e[$f]??''))==='')throw new GodModeException('device-state-field-required:'.$f);}
        if(!in_array($e['trust_state'],['active','retired','revoked'],true))throw new GodModeException('invalid-device-trust-state');
        if(!in_array($e['integrity_state'],['verified','unverified','failed'],true))throw new GodModeException('invalid-device-integrity-state');
        if(!in_array($e['isolation_state'],['clear','quarantined','isolated'],true))throw new GodModeException('invalid-device-isolation-state');
        if(!in_array($e['connectivity'],['online','degraded','offline'],true))throw new GodModeException('invalid-device-connectivity-state');
        if(!preg_match('/^[a-f0-9]{64}$/',(string)$e['evidence_digest']))throw new GodModeException('invalid-device-state-evidence-digest');
        return new self([
            'schema'=>'titan.t0gm.device_state.v1','device_binding_id'=>(string)$e['device_binding_id'],'trust_state'=>$e['trust_state'],
            'integrity_state'=>$e['integrity_state'],'isolation_state'=>$e['isolation_state'],'connectivity'=>$e['connectivity'],
            'observed_at'=>(string)$e['observed_at'],'evidence_digest'=>(string)$e['evidence_digest'],'evidence_only'=>true,
        ]);
    }
    public function commandEligible():bool{return $this->data['trust_state']==='active'&&$this->data['integrity_state']==='verified'&&$this->data['isolation_state']==='clear';}
    public function toArray():array{return $this->data+['command_eligible'=>$this->commandEligible(),'authority_granted'=>false];}
}
