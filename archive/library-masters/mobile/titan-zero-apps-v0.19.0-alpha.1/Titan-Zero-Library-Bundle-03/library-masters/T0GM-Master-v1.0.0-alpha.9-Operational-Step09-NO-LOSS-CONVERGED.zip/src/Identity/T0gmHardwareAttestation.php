<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmHardwareAttestation
{
    public function __construct(
        private readonly T0gmVerifierTrustStore $trust,
        private readonly T0gmCryptoSuiteRegistry $crypto
    ) {}

    public function verify(array $attestation, array $expected, int $now, int $skew = 30): array
    {
        foreach (['payload','attestation_key_id','signature_suite','signature'] as $f) {
            if (!array_key_exists($f,$attestation)) throw new GodModeException("hardware-attestation-missing:$f");
        }
        $p=(array)$attestation['payload'];
        foreach (['schema','device_key_id','device_public_key_hash','hardware_backed','hardware_class','challenge','measurement','issued_at','evidence_hash'] as $f) {
            if (!array_key_exists($f,$p)) throw new GodModeException("hardware-attestation-payload-missing:$f");
        }
        if ($p['schema']!=='titan.t0gm.hardware_attestation.v1') throw new GodModeException('wrong-hardware-attestation-schema');
        if ($p['hardware_backed']!==true) throw new GodModeException('hardware-backed-proof-required');
        if (!hash_equals((string)$expected['device_key_id'],(string)$p['device_key_id'])) throw new GodModeException('attested-device-key-mismatch');
        if (!hash_equals((string)$expected['device_public_key_hash'],(string)$p['device_public_key_hash'])) throw new GodModeException('attested-device-public-key-mismatch');
        if (!hash_equals((string)$expected['challenge'],(string)$p['challenge'])) throw new GodModeException('attestation-challenge-mismatch');
        if (abs($now-(int)$p['issued_at'])>$skew) throw new GodModeException('hardware-attestation-stale');
        if (trim((string)$p['hardware_class'])==='' || trim((string)$p['measurement'])==='' || trim((string)$p['evidence_hash'])==='') throw new GodModeException('hardware-attestation-evidence-incomplete');

        $trusted=$this->trust->key((string)$attestation['attestation_key_id']);
        if ($trusted['suite']!==(string)$attestation['signature_suite']) throw new GodModeException('attestation-suite-key-mismatch');
        $sig=base64_decode((string)$attestation['signature'],true);
        if ($sig===false || !$this->crypto->verify((string)$attestation['signature_suite'],$sig,CanonicalJson::encode($p),$trusted['public_key'])) {
            throw new GodModeException('invalid-hardware-attestation-signature');
        }
        return [
            'hardware_backed'=>true,
            'hardware_class'=>(string)$p['hardware_class'],
            'measurement'=>(string)$p['measurement'],
            'evidence_hash'=>(string)$p['evidence_hash'],
            'attestation_key_id'=>(string)$attestation['attestation_key_id'],
            'signature_suite'=>(string)$attestation['signature_suite'],
        ];
    }
}
