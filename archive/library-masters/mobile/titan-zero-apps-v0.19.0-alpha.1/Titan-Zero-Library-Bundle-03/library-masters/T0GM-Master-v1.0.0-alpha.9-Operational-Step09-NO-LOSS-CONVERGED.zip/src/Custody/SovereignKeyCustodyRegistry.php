<?php
namespace Titan\GodMode\Custody;

use Titan\GodMode\Security\GodModeException;

final class SovereignKeyCustodyRegistry
{
    private array $providers=[];
    public function __construct(array $providers=[]){ foreach($providers as $p)$this->register($p); }
    public function register(SovereignKeyCustodyProvider $provider): void {
        $id=$provider->providerId(); if(trim($id)==='') throw new GodModeException('custody-provider-id-required');
        if(isset($this->providers[$id])) throw new GodModeException('duplicate-custody-provider:' . $id);
        $this->providers[$id]=$provider;
    }
    public function provider(string $id): SovereignKeyCustodyProvider {
        if(!isset($this->providers[$id])) throw new GodModeException('unknown-custody-provider:' . $id);
        return $this->providers[$id];
    }
}
