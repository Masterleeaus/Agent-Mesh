<?php
namespace Titan\GodMode\Oversight;

use Titan\GodMode\Security\CanonicalJson;

final class DeterministicSpecialistReviewer implements T0gmOversightReviewer
{
    public function __construct(private readonly string $specialist)
    {
        if (!in_array($specialist,T0gmOversightSpecialist::all(),true)) throw new \InvalidArgumentException('invalid-specialist');
    }
    public function specialist(): string { return $this->specialist; }

    public function review(array $event, array $attentionProjection): T0gmOversightAssessment
    {
        $signals = $attentionProjection['signals'] ?? [];
        $domains = array_map('strtolower',$signals['domains'] ?? []);
        $dimensions = array_change_key_case($event['risk']['dimensions'] ?? [], CASE_LOWER);
        $reasons=[]; $actions=[]; $limitations=[]; $severity=0;
        $factor = function(string $name) use ($signals): int { return max(0,min(100,(int)($signals[$name] ?? 0))); };
        $risk = max(0,min(100,(int)($signals['risk'] ?? 0)));

        switch ($this->specialist) {
            case T0gmOversightSpecialist::SECURITY:
                $severity=max((int)($dimensions['security'] ?? 0),(int)($dimensions['cyber'] ?? 0));
                if ($this->has($domains,['security','cyber','identity','credential','access'])) $severity=max($severity,55);
                if ($severity>=70){$reasons[]='SECURITY_MATERIAL';$actions[]='verify_security_controls';}
                break;
            case T0gmOversightSpecialist::GOVERNANCE:
                $severity=max((int)($dimensions['authority'] ?? 0),(int)($dimensions['governance'] ?? 0));
                if (empty($event['authority']['basis'] ?? null) && in_array($event['event_kind'] ?? '',['authority_use','execution','intervention','supersession'],true)) {$severity=max($severity,80);$reasons[]='AUTHORITY_BASIS_MISSING';}
                if ($severity>=70) $actions[]='verify_authority_and_policy';
                break;
            case T0gmOversightSpecialist::FINANCIAL:
                $severity=max($factor('financial_exposure'),(int)($dimensions['financial'] ?? 0));
                if ($severity>=60){$reasons[]='FINANCIAL_EXPOSURE';$actions[]='review_financial_blast_radius';}
                break;
            case T0gmOversightSpecialist::OPERATIONAL:
                $severity=max($factor('dependency'),$factor('urgency'),(int)($dimensions['operational'] ?? 0));
                if ($severity>=65){$reasons[]='OPERATIONAL_CONTINUITY_RISK';$actions[]='check_dependencies_and_recovery';}
                break;
            case T0gmOversightSpecialist::PRIVACY_LEGAL:
                $severity=max((int)($dimensions['privacy'] ?? 0),(int)($dimensions['legal'] ?? 0),(int)($dimensions['jurisdiction'] ?? 0));
                if ($this->has($domains,['privacy','legal','jurisdiction','personal_data'])) $severity=max($severity,55);
                if ($severity>=65){$reasons[]='PRIVACY_LEGAL_CONCERN';$actions[]='verify_scope_consent_and_jurisdiction';}
                break;
            case T0gmOversightSpecialist::ENVIRONMENTAL:
                $severity=max($factor('environmental_impact'),(int)($dimensions['environmental'] ?? 0));
                if ($severity>=55){$reasons[]='ENVIRONMENTAL_IMPACT';$actions[]='assess_environmental_controls';}
                break;
            case T0gmOversightSpecialist::PHYSICAL_SAFETY:
                $severity=max($factor('physical_impact'),(int)($dimensions['physical'] ?? 0),(int)($dimensions['safety'] ?? 0));
                if ($severity>=70){$reasons[]='PHYSICAL_SAFETY_RISK';$actions[]='verify_safe_state_before_continuation';}
                break;
            case T0gmOversightSpecialist::ANOMALY:
                $severity=max($factor('anomaly'),100-$factor('confidence'));
                if ($severity>=60){$reasons[]='ANOMALOUS_OR_UNCERTAIN';$actions[]='investigate_pattern_and_provenance';}
                break;
            case T0gmOversightSpecialist::CAUSAL:
                $parents=count($event['lineage']['causation_event_ids'] ?? []);
                $severity=max($factor('dependency'),$factor('irreversibility'),$parents>2 ? 65 : 0);
                if ($severity>=60){$reasons[]='CAUSAL_PROPAGATION_RISK';$actions[]='trace_downstream_dependencies';}
                break;
        }

        if (!$reasons) $reasons[]='NO_MATERIAL_SPECIALIST_CONCERN';
        $disposition = $this->disposition($severity,$factor('confidence'));
        if ($factor('confidence') < 35) $limitations[]='LOW_EVENT_CONFIDENCE';
        $evidence = array_values(array_filter(array_map(static fn($r)=>is_array($r)?($r['evidence_id']??$r['ref']??null):$r,$event['evidence'] ?? []),'is_string'));
        $id='oa_'.substr(hash('sha256',$this->specialist.'|'.($event['event_id']??'').'|'.CanonicalJson::encode([$disposition,$reasons,$actions,$severity])),0,24);
        return new T0gmOversightAssessment($id,(string)($event['event_id']??''),$this->specialist,$disposition,max(0,min(100,$factor('confidence'))),$reasons,$evidence,$actions,$limitations);
    }

    private function disposition(int $severity, int $confidence): string
    {
        if ($confidence < 20 && $severity < 85) return T0gmOversightDisposition::UNCERTAIN;
        if ($severity >= 90) return T0gmOversightDisposition::CONTAIN;
        if ($severity >= 75) return T0gmOversightDisposition::OBJECT;
        if ($severity >= 60) return T0gmOversightDisposition::INVESTIGATE;
        if ($severity >= 35) return T0gmOversightDisposition::WATCH;
        return T0gmOversightDisposition::CLEAR;
    }
    private function has(array $haystack,array $needles): bool { foreach($needles as $n) if(in_array($n,$haystack,true)) return true; return false; }
}
