<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Contracts\AuditSink;
use Titan\GodMode\Contracts\NonceStore;
use Titan\GodMode\Security\GodModeException;
use Titan\GodMode\Security\GodModeRequestProof;

final class T0gmIdentityAccessGate
{
    public function __construct(
        private readonly T0gmIdentityRoot $identityRoot,
        private readonly NonceStore $requestNonces,
        private readonly AuditSink $audit,
        private readonly array $policy
    ) {}

    public function authorize(array $identityProof, array $requestProof, array $sessionContext=[], ?int $now=null): array
    {
        $now??=time();
        foreach (['impersonating','sudo_mode','acting_as_other_user','tenant_admin_override'] as $flag) {
            if (($sessionContext[$flag]??false)===true) $this->deny('impersonation-or-admin-escalation-forbidden',$sessionContext,$now);
        }
        try {
            $identity=$this->identityRoot->verify($identityProof,$now);
            // Request-proof expiry is cryptographic replay hygiene, not sovereign authority lifetime.
            $identity['certificate_expires_at']=(int)$identityProof['payload']['proof_expires_at'];
            $decision=GodModeRequestProof::fromArray($requestProof)->verify($identity,$this->policy,$this->requestNonces,$now);
        } catch (GodModeException $e) {
            $this->deny($e->reason,$sessionContext,$now);
        }
        $decision['identity_root']=[
            'authority_class'=>$identity['authority_class'],
            'principal_class'=>$identity['principal_class'],
            'root_key_id'=>$identity['root_key_id'],
            'signature_suite'=>$identity['signature_suite'],
            'hardware_backed'=>$identity['hardware_attestation']['hardware_backed'],
            'hardware_class'=>$identity['hardware_attestation']['hardware_class'],
            'attestation_key_id'=>$identity['hardware_attestation']['attestation_key_id'],
            'device_binding_id'=>$identity['device_binding']['binding_id']??null,
            'device_binding_provenance'=>$identity['device_binding']['provenance']??null,
            'application_role_authority'=>false,
        ];
        $this->audit->record([
            'event'=>'titan.god_mode.identity_root.authorized',
            'principal_id'=>$decision['principal_id'],
            'device_key_id'=>$decision['device_key_id'],
            'root_key_id'=>$identity['root_key_id'],
            'signature_suite'=>$identity['signature_suite'],
            'hardware_class'=>$identity['hardware_attestation']['hardware_class'],
            'device_binding_id'=>$identity['device_binding']['binding_id']??null,
            'purpose'=>$decision['purpose'],
            'target'=>$decision['target'],
            'authorized_at'=>$now,
        ]);
        return $decision;
    }

    private function deny(string $reason,array $session,int $now):never
    {
        $this->audit->record(['event'=>'titan.god_mode.identity_root.denied','reason'=>$reason,'session_actor_id'=>$session['actor_id']??null,'company_id'=>$session['company_id']??null,'denied_at'=>$now]);
        throw new GodModeException($reason);
    }
}
