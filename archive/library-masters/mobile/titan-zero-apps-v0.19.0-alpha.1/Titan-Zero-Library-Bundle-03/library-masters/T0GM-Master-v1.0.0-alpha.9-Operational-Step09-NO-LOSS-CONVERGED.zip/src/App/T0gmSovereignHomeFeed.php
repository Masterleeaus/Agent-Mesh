<?php
namespace Titan\GodMode\App;

use Titan\GodMode\Contracts\SovereignActivityStore;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedException;
use Titan\GodMode\Feed\T0gmFeedQuery;
use Titan\GodMode\Ranking\T0gmHomeFeedRanker;

/** Dedicated T0GM application Home Feed projection over immutable governed activity. */
final class T0gmSovereignHomeFeed
{
    public function __construct(
        private readonly SovereignActivityStore $store,
        private readonly T0gmHomeFeedRanker $ranker = new T0gmHomeFeedRanker(),
    ) {}

    public function snapshot(T0gmFeedAccessContext $access, int $limit = 100, int $afterSequence = 0): array
    {
        if (!$access->isSovereign()) throw new T0gmFeedException('sovereign-home-feed-required');
        if ($limit < 1 || $limit > 1000) throw new T0gmFeedException('invalid-home-feed-limit');
        if ($afterSequence < 0) throw new T0gmFeedException('invalid-home-feed-sequence');

        $records = $this->visibleRecords($access, $afterSequence);
        $items = [];
        $nextSequence = $afterSequence;

        foreach ($records as $record) {
            $event = $record['event'] ?? [];
            $sequence = (int)($record['audit_sequence'] ?? 0);
            $nextSequence = max($nextSequence, $sequence);
            $items[] = $this->project($event, $record, $this->ranker->rank($event));
        }

        usort($items, static function(array $a, array $b): int {
            $rank = $b['rank']['score'] <=> $a['rank']['score'];
            if ($rank !== 0) return $rank;
            $urgency = $b['rank']['factors']['urgency'] <=> $a['rank']['factors']['urgency'];
            if ($urgency !== 0) return $urgency;
            return $b['audit_sequence'] <=> $a['audit_sequence'];
        });

        $head = $this->store->auditHead();
        return [
            'schema' => 'titan.t0gm.sovereign_home_feed.v1',
            'sovereign_scope' => true,
            'actor_id' => $access->actorId,
            'rank_contract' => ['risk','consequence','anomaly','confidence','urgency'],
            'after_sequence' => $afterSequence,
            'next_sequence' => $nextSequence,
            'audit_head' => $head === null ? null : [
                'audit_sequence' => (int)($head['audit_sequence'] ?? 0),
                'record_hash' => $head['record_hash'] ?? null,
            ],
            'items' => array_slice($items, 0, $limit),
            'execution_authority_granted' => false,
            'projection_only' => true,
        ];
    }

    private function visibleRecords(T0gmFeedAccessContext $access, int $afterSequence): array
    {
        $records = [];
        $cursor = $afterSequence;
        do {
            $page = $this->store->query(new T0gmFeedQuery(limit: 1000, afterSequence: $cursor), $access);
            foreach ($page as $record) {
                $sequence = (int)($record['audit_sequence'] ?? 0);
                if ($sequence <= $afterSequence) continue;
                $records[] = $record;
                $cursor = max($cursor, $sequence);
            }
        } while (count($page) === 1000);
        return $records;
    }

    private function project(array $event, array $record, array $rank): array
    {
        $company = $event['company_context'] ?? [];
        return [
            'event_id' => (string)($event['event_id'] ?? ''),
            'audit_sequence' => (int)($record['audit_sequence'] ?? 0),
            'event_kind' => (string)($event['event_kind'] ?? ''),
            'company_scope' => (string)($company['scope'] ?? ''),
            'company_id' => $company['company_id'] ?? null,
            'actor' => $event['actor'] ?? [],
            'source' => $event['source'] ?? [],
            'subject' => $event['subject'] ?? [],
            'lineage' => $event['lineage'] ?? [],
            'summary' => $this->summary($event),
            'classification' => $this->classification($event),
            'rank' => $rank,
            'evidence' => array_values($event['evidence'] ?? []),
            'occurred_at' => $event['occurred_at'] ?? null,
            'observed_at' => $event['observed_at'] ?? null,
            'record_hash' => $record['record_hash'] ?? null,
            'authority_granted' => false,
        ];
    }

    private function classification(array $event): array
    {
        $domains = array_values(array_filter($event['attention_signals']['domains'] ?? [], 'is_string'));
        $dimensions = array_values(array_filter(array_keys($event['risk']['dimensions'] ?? []), 'is_string'));
        $tokens = array_values(array_unique(array_map('strtolower', array_merge($domains,$dimensions))));
        return [
            'domains' => array_values(array_map('strtolower',$domains)),
            'risk_dimensions' => array_values(array_map('strtolower',$dimensions)),
            'tokens' => $tokens,
            'attention_tier' => $event['oversight']['attention_tier'] ?? null,
        ];
    }

    private function summary(array $event): string
    {
        foreach (['observation','anomaly','decision','execution','result','supersession','intervention'] as $section) {
            foreach (['summary','determination','directive','outcome'] as $field) {
                $value = $event[$section][$field] ?? null;
                if (is_string($value) && trim($value) !== '') return trim($value);
            }
        }
        return (string)($event['event_kind'] ?? 'governed_activity');
    }
}
