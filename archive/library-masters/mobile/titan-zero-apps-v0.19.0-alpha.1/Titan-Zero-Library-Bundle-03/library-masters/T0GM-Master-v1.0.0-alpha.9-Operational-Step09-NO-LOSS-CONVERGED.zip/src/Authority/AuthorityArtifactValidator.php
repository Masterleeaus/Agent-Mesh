<?php
namespace Titan\GodMode\Authority;

final class AuthorityArtifactValidator
{
    private const LEGACY_TENANT_KEYS = ['tenant_id', 'tenant_company_id', 'tenantId', 'tenantCompanyId'];

    public function __construct(private readonly AuthorityArtifactHasher $hasher = new AuthorityArtifactHasher()) {}

    public function validate(array $artifact): array
    {
        $this->rejectLegacyTenantKeys($artifact);
        $this->requireExact($artifact, 'schema', 'titan.t0gm.authority-artifact.v1');
        $this->requireString($artifact, 'artifact_id');
        $this->requireString($artifact, 'stage');
        if (!in_array($artifact['stage'], [AuthorityStage::INTENT, AuthorityStage::PLANNING], true)) {
            throw new AuthoritySeparationException('artifact-stage-cannot-grant-execution', 'stage');
        }
        $this->requireString($artifact, 'created_at');
        $this->requireString($artifact, 'company_id');
        if ($artifact['company_id'] === '*' || strtolower($artifact['company_id']) === 'all') {
            throw new AuthoritySeparationException('wildcard-company-scope-forbidden', 'company_id');
        }
        $this->requireArray($artifact, 'actor');
        $this->requireString($artifact['actor'], 'actor_id', 'actor.actor_id');
        $this->requireString($artifact['actor'], 'actor_type', 'actor.actor_type');
        if (!in_array($artifact['actor']['actor_type'], ['human', 'advanced_intelligence'], true)) {
            throw new AuthoritySeparationException('invalid-actor-type', 'actor.actor_type');
        }
        $this->requireArray($artifact, 'target');
        foreach (['target_type','target_id','system','environment'] as $field) {
            $this->requireString($artifact['target'], $field, 'target.' . $field);
        }
        $this->requireString($artifact, 'purpose');

        if ($artifact['stage'] === AuthorityStage::INTENT) {
            $this->requireString($artifact, 'requested_operation');
        } else {
            $this->requireString($artifact, 'intent_id');
            $steps = $artifact['steps'] ?? null;
            if (!is_array($steps) || $steps === []) throw new AuthoritySeparationException('planning-steps-required', 'steps');
            foreach ($steps as $i => $step) {
                if (!is_array($step)) throw new AuthoritySeparationException('invalid-plan-step', 'steps.' . $i);
                $this->requireString($step, 'step_id', 'steps.' . $i . '.step_id');
                $this->requireString($step, 'operation', 'steps.' . $i . '.operation');
            }
        }

        $this->requireArray($artifact, 'integrity');
        if (($artifact['integrity']['algorithm'] ?? null) !== 'sha256') throw new AuthoritySeparationException('unsupported-integrity-algorithm');
        if (!$this->hasher->verify($artifact)) throw new AuthoritySeparationException('artifact-integrity-failed');
        return $artifact;
    }

    private function rejectLegacyTenantKeys(array $value, string $path = ''): void
    {
        foreach ($value as $key => $child) {
            $childPath = $path === '' ? (string)$key : $path . '.' . $key;
            if (in_array((string)$key, self::LEGACY_TENANT_KEYS, true)) throw new AuthoritySeparationException('legacy-tenant-boundary-forbidden', $childPath);
            if (is_array($child)) $this->rejectLegacyTenantKeys($child, $childPath);
        }
    }

    private function requireString(array $a, string $key, ?string $path = null): void
    {
        if (!isset($a[$key]) || !is_string($a[$key]) || trim($a[$key]) === '') throw new AuthoritySeparationException('missing-or-invalid-field', $path ?? $key);
    }
    private function requireArray(array $a, string $key, ?string $path = null): void
    {
        if (!array_key_exists($key, $a) || !is_array($a[$key])) throw new AuthoritySeparationException('missing-or-invalid-field', $path ?? $key);
    }
    private function requireExact(array $a, string $key, string $expected, ?string $path = null): void
    {
        if (($a[$key] ?? null) !== $expected) throw new AuthoritySeparationException('invalid-fixed-field', $path ?? $key);
    }
}
