<?php
namespace Titan\GodMode\Replay;

use PDO;
use PDOException;
use RuntimeException;
use Titan\GodMode\Contracts\AtomicNonceBackend;

/**
 * SQL-backed atomic replay claims. The PRIMARY KEY/UNIQUE constraint on
 * nonce_key is the concurrency primitive; application-level read-before-write
 * checks are deliberately avoided.
 */
final class PdoAtomicNonceBackend implements AtomicNonceBackend
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly string $domainId,
        private readonly bool $distributed = true,
        private readonly string $table = 't0gm_nonce_claims',
    ) {
        if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $this->table)) {
            throw new RuntimeException('invalid-nonce-table-name');
        }
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function claim(string $nonceKey, int $expiresAt, int $claimedAt, array $metadata = []): bool
    {
        $started = !$this->pdo->inTransaction();
        if ($started) {
            $this->pdo->beginTransaction();
        }

        try {
            // An expired proof cannot be accepted by the verifier, so an expired
            // claim may be removed before inserting the same digest again.
            $delete = $this->pdo->prepare("DELETE FROM {$this->table} WHERE nonce_key = :key AND expires_at <= :now");
            $delete->execute([':key' => $nonceKey, ':now' => $claimedAt]);

            $insert = $this->pdo->prepare(
                "INSERT INTO {$this->table} (nonce_key, expires_at, claimed_at, metadata_json) VALUES (:key, :expires, :claimed, :metadata)"
            );
            $insert->execute([
                ':key' => $nonceKey,
                ':expires' => $expiresAt,
                ':claimed' => $claimedAt,
                ':metadata' => json_encode($metadata, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
            ]);

            if ($started) {
                $this->pdo->commit();
            }
            return true;
        } catch (PDOException $e) {
            if ($started && $this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            if ($this->isUniqueViolation($e)) {
                return false;
            }
            throw $e;
        } catch (\Throwable $e) {
            if ($started && $this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $e;
        }
    }

    public function purgeExpired(int $now, int $limit = 1000): int
    {
        $limit = max(1, min($limit, 10000));
        // Portable bounded purge: fetch keys first, then delete by primary key.
        $query = $this->pdo->prepare("SELECT nonce_key FROM {$this->table} WHERE expires_at <= :now ORDER BY expires_at ASC");
        $query->execute([':now' => $now]);
        $keys = array_slice($query->fetchAll(PDO::FETCH_COLUMN), 0, $limit);
        if ($keys === []) {
            return 0;
        }
        $delete = $this->pdo->prepare("DELETE FROM {$this->table} WHERE nonce_key = :key AND expires_at <= :now");
        $count = 0;
        foreach ($keys as $key) {
            $delete->execute([':key' => $key, ':now' => $now]);
            $count += $delete->rowCount();
        }
        return $count;
    }

    public function consistencyDomain(): string
    {
        return $this->domainId;
    }

    public function distributedCapable(): bool
    {
        return $this->distributed;
    }

    private function isUniqueViolation(PDOException $e): bool
    {
        $sqlState = (string) $e->getCode();
        return in_array($sqlState, ['23000', '23505'], true)
            || str_contains(strtolower($e->getMessage()), 'unique')
            || str_contains(strtolower($e->getMessage()), 'duplicate');
    }
}
