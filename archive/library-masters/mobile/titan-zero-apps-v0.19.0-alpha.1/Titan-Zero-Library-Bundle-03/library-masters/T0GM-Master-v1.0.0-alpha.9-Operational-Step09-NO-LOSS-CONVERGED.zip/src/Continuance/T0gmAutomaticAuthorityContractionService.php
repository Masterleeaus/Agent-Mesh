<?php
namespace Titan\GodMode\Continuance;

use Titan\GodMode\Capability\SovereignCapabilityHasher;

final class T0gmAutomaticAuthorityContractionService
{
    public function __construct(
        private readonly AuthorityContinuanceEngine $engine = new AuthorityContinuanceEngine(),
        private readonly SovereignCapabilityHasher $hasher = new SovereignCapabilityHasher(),
    ) {}

    public function reevaluateAndContract(array $capability,array $world): array
    {
        $decision=$this->engine->evaluate($capability,$world);
        $out=[
            'schema'=>'titan.t0gm.automatic-authority-contraction.v1',
            'outcome'=>$decision->outcome,
            'reason_codes'=>$decision->reasons,
            'original_capability_id'=>$capability['capability_id']??null,
            'authority_expanded'=>false,
            'contracted_capability'=>null,
        ];
        if($decision->outcome!==AuthorityContinuanceOutcome::NARROW) return $out;
        $keep=array_flip($decision->retainedEffectIds);
        $n=$capability;
        $n['permitted_effects']=array_values(array_filter($capability['permitted_effects'],fn($e)=>isset($keep[$e['effect_id']??''])));
        if(count($n['permitted_effects'])>=count($capability['permitted_effects'])) throw new \RuntimeException('contraction-must-reduce-authority');
        $n['predecessor_capability_id']=$capability['capability_id'];
        $n['contraction_reason_codes']=$decision->reasons;
        $n['capability_id']=$capability['capability_id'].':contracted:'.substr(hash('sha256',json_encode(array_keys($keep))),0,12);
        unset($n['integrity']);
        $n['integrity']=['algorithm'=>'sha256','digest'=>$this->hasher->digest($n)];
        $out['contracted_capability']=$n;
        return $out;
    }
}
