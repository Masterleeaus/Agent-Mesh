<?php
namespace Titan\GodMode\Adapter;

interface TargetAdapter
{
    public function adapterType(): string;
    public function supports(array $target): bool;
    public function prepare(array $capability, array $request): TargetAdapterResult;
}
