<?php
namespace Titan\GodMode\Http\Middleware;

use Closure;
use Titan\GodMode\Security\GodModeAccessGate;

final class RequireGodModeProof
{
    public function __construct(private readonly GodModeAccessGate $gate) {}

    public function handle($request, Closure $next)
    {
        $certificate = json_decode((string) $request->header('X-Titan-God-Mode-Certificate'), true, flags: JSON_THROW_ON_ERROR);
        $proof = json_decode((string) $request->header('X-Titan-God-Mode-Proof'), true, flags: JSON_THROW_ON_ERROR);

        $sessionContext = [
            'actor_id' => optional($request->user())->id,
            'company_id' => $request->attributes->get('company_id'),
            'impersonating' => (bool) $request->session()->get('impersonating', false),
            'sudo_mode' => (bool) $request->session()->get('sudo_mode', false),
            'acting_as_other_user' => (bool) $request->session()->get('acting_as_other_user', false),
            'tenant_admin_override' => (bool) $request->session()->get('tenant_admin_override', false),
            'role_grants' => optional($request->user())->roles?->pluck('name')->all() ?? [],
            'permissions' => method_exists($request->user(), 'getAllPermissions')
                ? $request->user()->getAllPermissions()->pluck('name')->all()
                : [],
        ];

        $decision = $this->gate->authorize($certificate, $proof, $sessionContext);
        $request->attributes->set('titan_god_mode_decision', $decision);

        return $next($request);
    }
}
