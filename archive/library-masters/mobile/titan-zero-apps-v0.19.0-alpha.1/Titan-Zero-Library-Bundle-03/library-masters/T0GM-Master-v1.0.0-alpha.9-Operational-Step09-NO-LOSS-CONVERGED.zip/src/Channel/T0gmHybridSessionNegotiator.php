<?php
namespace Titan\GodMode\Channel;

use Titan\GodMode\Identity\T0gmCryptoProfileRegistry;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmHybridSessionNegotiator
{
    public function __construct(private ?T0gmCryptoProfileRegistry $profiles=null)
    { $this->profiles ??= new T0gmCryptoProfileRegistry(); }

    public function negotiate(array $offer, array $policy=[]): array
    {
        foreach(['crypto_profile_id','classical_kex','pq_kem'] as $field){
            if(!isset($offer[$field])) throw new GodModeException('hybrid-negotiation-missing:'.$field);
        }
        $profile=$this->profiles->profile((string)$offer['crypto_profile_id']);
        $requiredClassical=(string)($policy['required_classical_kex'] ?? 'x25519');
        $requiredPq=(string)($policy['required_pq_kem'] ?? 'ml-kem-768');
        if((string)$offer['classical_kex']!==$requiredClassical) throw new GodModeException('hybrid-classical-downgrade-detected');
        if((string)$offer['pq_kem']!==$requiredPq) throw new GodModeException('hybrid-pqc-downgrade-detected');
        if(!in_array($requiredPq,$profile['kem_preferences'] ?? [],true)) throw new GodModeException('hybrid-pqc-not-allowed-by-profile');
        if(($profile['classical_only_allowed'] ?? true)===true) throw new GodModeException('hybrid-profile-allows-classical-only');
        if(($offer['allow_classical_only'] ?? false)===true || ($offer['allow_pq_only'] ?? false)===true) throw new GodModeException('hybrid-degraded-mode-forbidden');
        $selection=[
            'schema'=>'titan.t0gm.hybrid_session_negotiation.v1',
            'crypto_profile_id'=>(string)$offer['crypto_profile_id'],
            'classical_kex'=>$requiredClassical,
            'pq_kem'=>$requiredPq,
            'combiner'=>'hkdf-sha256-transcript-bound-v1',
            'fail_closed'=>true,
            'classical_only_allowed'=>false,
            'pq_only_allowed'=>false,
        ];
        return $selection+['negotiation_hash'=>hash('sha256',CanonicalJson::encode($selection))];
    }
}
