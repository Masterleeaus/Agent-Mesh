<?php
namespace Titan\GodMode\Recovery;

final class T0gmRecoveryPlan
{
    public function __construct(public readonly string $transitionId,public readonly string $disposition,public readonly array $reasonCodes,public readonly ?string $effect=null,public readonly array $dependencyChecks=[]){ if(!in_array($disposition,T0gmRecoveryDisposition::all(),true)) throw new \InvalidArgumentException('invalid-recovery-disposition'); }
    public function toArray():array { return ['transition_id'=>$this->transitionId,'disposition'=>$this->disposition,'reason_codes'=>$this->reasonCodes,'effect'=>$this->effect,'dependency_checks'=>$this->dependencyChecks]; }
}
