<?php
namespace Titan\GodMode\Live;

interface T0gmWorldStateProvider
{
    /** Return fresh evidence about the current world for this exact capability. */
    public function currentFor(array $capability): array;
}
