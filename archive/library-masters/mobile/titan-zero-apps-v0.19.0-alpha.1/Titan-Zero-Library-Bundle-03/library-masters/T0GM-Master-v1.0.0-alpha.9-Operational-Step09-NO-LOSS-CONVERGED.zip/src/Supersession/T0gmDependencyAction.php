<?php
namespace Titan\GodMode\Supersession;

final class T0gmDependencyAction
{
    public function __construct(
        public readonly string $eventId,
        public readonly string $disposition,
        public readonly array $reasons,
        public readonly int $depth,
    ) {
        if (!in_array($disposition, DependencyDisposition::all(), true)) throw new \InvalidArgumentException('invalid-dependency-disposition');
    }

    public function toArray(): array { return ['event_id'=>$this->eventId,'disposition'=>$this->disposition,'reasons'=>$this->reasons,'depth'=>$this->depth]; }
}
