<?php
namespace Titan\GodMode\Oversight;

final class T0gmOversightSpecialist
{
    public const SECURITY = 'security';
    public const GOVERNANCE = 'governance';
    public const FINANCIAL = 'financial';
    public const OPERATIONAL = 'operational';
    public const PRIVACY_LEGAL = 'privacy_legal';
    public const ENVIRONMENTAL = 'environmental';
    public const PHYSICAL_SAFETY = 'physical_safety';
    public const ANOMALY = 'anomaly';
    public const CAUSAL = 'causal';

    public static function all(): array
    {
        return [self::SECURITY,self::GOVERNANCE,self::FINANCIAL,self::OPERATIONAL,self::PRIVACY_LEGAL,self::ENVIRONMENTAL,self::PHYSICAL_SAFETY,self::ANOMALY,self::CAUSAL];
    }
}
