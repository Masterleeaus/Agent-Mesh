<?php
namespace Titan\GodMode\Continuance;

final class AuthorityContinuanceDecision
{
    public function __construct(
        public readonly string $outcome,
        public readonly array $reasons,
        public readonly array $retainedEffectIds = [],
        public readonly ?array $transformationRequest = null,
    ) {
        if (!in_array($outcome, AuthorityContinuanceOutcome::all(), true)) throw new \InvalidArgumentException('invalid-continuance-outcome');
        if ($outcome === AuthorityContinuanceOutcome::TRANSFORM && $transformationRequest === null) throw new \InvalidArgumentException('transform-requires-new-capability-request');
    }
}
