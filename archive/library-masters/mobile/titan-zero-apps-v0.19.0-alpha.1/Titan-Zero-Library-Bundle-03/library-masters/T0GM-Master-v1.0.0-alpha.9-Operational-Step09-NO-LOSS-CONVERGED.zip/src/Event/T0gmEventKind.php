<?php
namespace Titan\GodMode\Event;

final class T0gmEventKind
{
    public const OBSERVATION = 'observation';
    public const AI_DECISION = 'ai_decision';
    public const HUMAN_ACTION = 'human_action';
    public const AUTHORITY_USE = 'authority_use';
    public const EXECUTION = 'execution';
    public const RESULT = 'result';
    public const ANOMALY = 'anomaly';
    public const INTERVENTION = 'intervention';
    public const SUPERSESSION = 'supersession';

    public static function all(): array
    {
        return [
            self::OBSERVATION,
            self::AI_DECISION,
            self::HUMAN_ACTION,
            self::AUTHORITY_USE,
            self::EXECUTION,
            self::RESULT,
            self::ANOMALY,
            self::INTERVENTION,
            self::SUPERSESSION,
        ];
    }
}
