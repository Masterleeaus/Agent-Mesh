<?php
namespace Titan\GodMode\Oversight;

interface T0gmOversightReviewer
{
    public function specialist(): string;
    public function review(array $event, array $attentionProjection): T0gmOversightAssessment;
}
