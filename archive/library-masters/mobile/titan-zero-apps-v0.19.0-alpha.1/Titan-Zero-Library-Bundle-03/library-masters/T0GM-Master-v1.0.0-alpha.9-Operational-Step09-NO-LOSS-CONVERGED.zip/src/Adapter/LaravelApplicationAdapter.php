<?php
namespace Titan\GodMode\Adapter;

final class LaravelApplicationAdapter extends AbstractCapabilityTargetAdapter
{
    public function adapterType(): string { return 'laravel_application'; }
    public function supports(array $target): bool { return in_array($target['target_type'] ?? '', ['laravel_application','application'], true); }

    protected function mapAuthorizedOperation(array $request): array
    {
        $op = $this->allowedOperation($request, [
            'read_configuration','clear_cache','run_health_check','restart_queue_worker',
            'enable_maintenance_mode','disable_maintenance_mode','run_named_command','apply_named_remediation'
        ]);
        $native = [
            'transport' => 'laravel_control_plane',
            'company_id' => $request['company_id'],
            'application' => $request['target']['target_id'],
            'environment' => $request['target']['environment'],
            'operation' => $op,
            'parameters' => $request['parameters'] ?? [],
        ];
        if ($op === 'run_named_command') {
            $name = trim((string)($native['parameters']['command_name'] ?? ''));
            if ($name === '' || preg_match('/[;&|`$<>]/', $name)) throw new TargetAdapterException('unsafe_or_missing_named_command');
        }
        return $native;
    }
}
