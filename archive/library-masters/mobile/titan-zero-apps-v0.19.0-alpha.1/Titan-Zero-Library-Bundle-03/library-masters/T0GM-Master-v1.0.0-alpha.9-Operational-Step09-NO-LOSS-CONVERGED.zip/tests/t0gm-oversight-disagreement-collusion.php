<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\Oversight\T0gmOversightAssessment; use Titan\GodMode\Oversight\T0gmOversightDisagreementAnalyzer; use Titan\GodMode\Oversight\T0gmOversightReviewSet; use Titan\GodMode\Oversight\T0gmOversightSpecialist;
function n19($c,$m){if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);} 
$mk=function($id,$spec,$disp,$reason){return new T0gmOversightAssessment($id,'evt-19',$spec,$disp,80,[$reason],['ev'],[],[]);};
$a=[
$mk('a1',T0gmOversightSpecialist::SECURITY,'object','SAME'),
$mk('a2',T0gmOversightSpecialist::GOVERNANCE,'object','SAME'),
$mk('a3',T0gmOversightSpecialist::FINANCIAL,'object','SAME'),
$mk('a4',T0gmOversightSpecialist::ENVIRONMENTAL,'clear','DIFFERENT')];
$x=(new T0gmOversightDisagreementAnalyzer())->analyze(new T0gmOversightReviewSet('evt-19',$a,[],[]));
n19($x['material_disagreement']===true,'disagreement preserved'); n19(count($x['collusion_signals'])===1,'suspicious identical independent outputs surfaced'); n19($x['consensus_does_not_create_authority']===true,'consensus non-authoritative');
echo "PASS T0GM Step19 oversight disagreement and collusion resistance\n";
