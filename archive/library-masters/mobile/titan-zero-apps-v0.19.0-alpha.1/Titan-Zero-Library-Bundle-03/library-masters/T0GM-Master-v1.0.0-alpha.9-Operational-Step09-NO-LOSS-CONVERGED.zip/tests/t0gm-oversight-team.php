<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmLineageFactory;
use Titan\GodMode\Oversight\T0gmOversightDisposition;
use Titan\GodMode\Oversight\T0gmOversightSpecialist;
use Titan\GodMode\Oversight\T0gmOversightTeam;

function oAssert($condition,string $message): void { if(!$condition) throw new RuntimeException('ASSERTION FAILED: '.$message); }

$factory=new T0gmEventFactory(); $lineage=new T0gmLineageFactory();
$event=$factory->make(
    T0gmEventKind::AI_DECISION,
    ['scope'=>'company','company_id'=>'company_a'],
    ['actor_type'=>'advanced_intelligence','actor_id'=>'finance-ai','authority_class'=>'delegated_ai'],
    ['system'=>'titan-workforce','component'=>'financial-intelligence'],
    ['subject_type'=>'payment','subject_id'=>'pay-44'],
    $lineage->create('trace-oversight','corr-oversight',null,[]),
    ['score'=>95,'band'=>'extreme','dimensions'=>['financial'=>96,'privacy'=>78,'environmental'=>5,'physical'=>0,'security'=>10]],
    ['visibility'=>'t0gm_sovereign','attention_tier'=>'important','review_required'=>true,'review_team'=>['t0gm-oversight']],
    [['evidence_id'=>'bank-receipt-44','evidence_type'=>'financial_receipt','source'=>'ledger']],
    [
        'attention_signals'=>[
            'significance'=>90,'anomaly'=>45,'urgency'=>88,'reversibility'=>20,
            'financial_exposure'=>98,'physical_impact'=>0,'environmental_impact'=>5,
            'confidence'=>82,'dependency'=>72,'domains'=>['finance','payment','privacy']
        ],
        'decision'=>['decision_id'=>'decision-44','determination'=>'release-high-value-payment','reason_codes'=>['SETTLEMENT_DUE']]
    ],
    'evt-oversight-44','2026-09-02T10:30:00Z','2026-09-02T10:30:01Z'
);

$team=new T0gmOversightTeam();
$review=$team->review($event)->toArray();
oAssert(count($review['assessments'])===9,'exactly nine independent specialist assessments emitted');
oAssert($review['consensus_score']===null,'no consensus/average score is emitted');
oAssert($review['sovereign_authority_inherited']===false,'oversight team never inherits T0GM authority');
$by=[]; foreach($review['assessments'] as $a) $by[$a['specialist']]=$a;
foreach(T0gmOversightSpecialist::all() as $s) oAssert(isset($by[$s]),'specialist present: '.$s);
oAssert(in_array($by[T0gmOversightSpecialist::FINANCIAL]['disposition'],[T0gmOversightDisposition::OBJECT,T0gmOversightDisposition::CONTAIN],true),'financial specialist independently objects/contains');
oAssert(in_array($by[T0gmOversightSpecialist::SECURITY]['disposition'],[T0gmOversightDisposition::CLEAR,T0gmOversightDisposition::WATCH],true),'security specialist can clear/watch while financial objects');
oAssert(in_array($by[T0gmOversightSpecialist::PRIVACY_LEGAL]['disposition'],[T0gmOversightDisposition::OBJECT,T0gmOversightDisposition::INVESTIGATE],true),'privacy/legal independently flags privacy risk');
oAssert(count($review['disagreements'])>=2,'materially different dispositions are preserved as disagreement groups');
oAssert(count($review['material_objections'])>=1,'material objections preserved explicitly');
oAssert(in_array('bank-receipt-44',$by[T0gmOversightSpecialist::FINANCIAL]['evidence_refs'],true),'specialist preserves immutable evidence reference');

// Low-confidence anomaly must remain uncertain/investigative rather than being converted to false safety.
$uncertain=$event;
$uncertain['event_id']='evt-low-confidence';
$uncertain['risk']=['score'=>20,'band'=>'low','dimensions'=>['operational'=>15]];
$uncertain['attention_signals']['financial_exposure']=0;
$uncertain['attention_signals']['anomaly']=70;
$uncertain['attention_signals']['confidence']=15;
$uncertain['attention_signals']['domains']=['operations'];
$uncertainReview=$team->review($uncertain)->toArray();
$u=[]; foreach($uncertainReview['assessments'] as $a) $u[$a['specialist']]=$a;
oAssert(in_array($u[T0gmOversightSpecialist::ANOMALY]['disposition'],[T0gmOversightDisposition::INVESTIGATE,T0gmOversightDisposition::OBJECT,T0gmOversightDisposition::UNCERTAIN],true),'anomaly specialist does not treat low confidence as safe');
oAssert(in_array('LOW_EVENT_CONFIDENCE',$u[T0gmOversightSpecialist::ANOMALY]['limitations'],true),'low confidence limitation preserved');

echo "PASS nine independent oversight specialists\n";
echo "PASS disagreements preserved without consensus score\n";
echo "PASS material objections survive majority clearance\n";
echo "PASS oversight AI does not inherit sovereign authority\n";
echo "PASS evidence references and uncertainty preserved\n";
