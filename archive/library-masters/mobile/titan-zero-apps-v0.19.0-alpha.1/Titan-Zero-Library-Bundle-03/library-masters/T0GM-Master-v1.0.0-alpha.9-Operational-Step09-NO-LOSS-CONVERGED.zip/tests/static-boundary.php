<?php
$root = dirname(__DIR__);
$runtimeFiles = [];
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/src'));
foreach ($it as $file) {
    if ($file->isFile() && $file->getExtension() === 'php') $runtimeFiles[] = $file->getPathname();
}
$runtime = implode("\n", array_map(fn($p)=>file_get_contents($p), $runtimeFiles));

$forbiddenPrivateKeyPatterns = [
    'sodium_crypto_sign_secretkey(',
    'sodium_crypto_sign_keypair(',
    'BEGIN PRIVATE KEY',
    'TITAN_GOD_MODE_PRIVATE_KEY',
    'god_mode_private_key'
];
foreach ($forbiddenPrivateKeyPatterns as $pattern) {
    if (stripos($runtime, $pattern) !== false) {
        throw new RuntimeException("runtime contains private-key capability:$pattern");
    }
}

$config = file_get_contents($root . '/config/god-mode.php');
if (str_contains($config, "'super_admin' => true")) {
    throw new RuntimeException('God Mode modeled as super_admin');
}

echo "PASS runtime has no God Mode signer/private-key generation\n";
echo "PASS normal config does not model God Mode as super_admin\n";
