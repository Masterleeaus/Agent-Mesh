<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedIngestor;
use Titan\GodMode\Recovery\InMemoryT0gmStateTransitionStore;
use Titan\GodMode\Recovery\T0gmRecoveryDisposition;
use Titan\GodMode\Recovery\T0gmRewindService;
use Titan\GodMode\Recovery\T0gmStateTransitionFactory;
use Titan\GodMode\Store\InMemorySovereignActivityStore;

function rAssert($c,string $m):void{if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);} function rThrows(callable $f,string $m):void{try{$f();}catch(Throwable $e){return;}throw new RuntimeException('ASSERTION FAILED: '.$m);}

$activity=new InMemorySovereignActivityStore(); $ingest=new T0gmFeedIngestor($activity); $events=new T0gmEventFactory();
$sovereign=T0gmFeedAccessContext::sovereign('jason'); $delegated=new T0gmFeedAccessContext('oversight','t0gm.oversight_ai',['company-a'],false);
$exec=$events->make(T0gmEventKind::EXECUTION,['scope'=>'company','company_id'=>'company-a'],['actor_type'=>'advanced_intelligence','actor_id'=>'ops-ai','authority_class'=>'delegated_ai'],['system'=>'titan.ops','component'=>'supplier-api'],['subject_type'=>'supplier','subject_id'=>'sup-17'],['trace_id'=>'trace-r','correlation_id'=>'corr-r','causation_id'=>'evt-root','parent_event_ids'=>['evt-root']],['score'=>70,'band'=>'high','dimensions'=>['financial'=>70]],['visibility'=>'t0gm_sovereign','attention_tier'=>'important','review_required'=>true,'review_team'=>['causal','operational']],[],['execution'=>['execution_id'=>'x-r','state'=>'completed','adapter'=>'supplier-api'],'attention_signals'=>['reversibility'=>90]],'evt-recoverable');
$ingest->ingest($exec);

$tf=new T0gmStateTransitionFactory(); $ts=new InMemoryT0gmStateTransitionStore();
$t=$tf->make('company-a','evt-recoverable','suspend supplier',['subject_type'=>'supplier','subject_id'=>'sup-17'],['status'=>'active'],['status'=>'suspended'],['status'=>'suspended'],[['dependency_id'=>'ledger-1','required_state'=>'unchanged']],['score'=>95,'mode'=>'direct','inverse_effect'=>'supplier.unsuspend'],[['evidence_id'=>'ev-result','evidence_type'=>'result_receipt','source'=>'supplier-api']]);
$ts->append($t);
$service=new T0gmRewindService($activity,$ts);
$out=$service->invokeForEvent('evt-recoverable',$sovereign,'jason',['status'=>'suspended'],['ledger-1'=>'unchanged'],'evt-supersession');
rAssert(count($out)===1,'one recovery planned'); $plan=$out[0]['plan'];
rAssert($plan->disposition===T0gmRecoveryDisposition::REVERSE,'verified unchanged post-state can reverse');
rAssert($plan->effect==='supplier.unsuspend','inverse effect retained');
rAssert(($out[0]['event']['recovery']['actual_result_hash']??'')===$t['actual_result']['hash'],'actual result fingerprint retained');
rAssert(($out[0]['event']['recovery']['supersession_event_id']??null)==='evt-supersession','recovery causally links to supersession');
rAssert($activity->verifyAuditLineage(),'recovery invocation preserves immutable audit lineage');

$diverged=$service->invokeForEvent('evt-recoverable',$sovereign,'jason',['status'=>'active','owner_note'=>'later legitimate change'],['ledger-1'=>'unchanged']);
rAssert($diverged[0]['plan']->disposition===T0gmRecoveryDisposition::RECOMPUTE,'diverged current state cannot be blindly overwritten');
rAssert(in_array('CURRENT_STATE_DIVERGED_FROM_RECORDED_POST_STATE',$diverged[0]['plan']->reasonCodes,true),'divergence reason explicit');

$depChanged=$service->invokeForEvent('evt-recoverable',$sovereign,'jason',['status'=>'suspended'],['ledger-1'=>'changed']);
rAssert($depChanged[0]['plan']->disposition===T0gmRecoveryDisposition::RECOMPUTE,'changed dependency forces recomputation');

$exec2=$events->make(T0gmEventKind::EXECUTION,['scope'=>'company','company_id'=>'company-a'],['actor_type'=>'advanced_intelligence','actor_id'=>'ops-ai','authority_class'=>'delegated_ai'],['system'=>'titan.ops','component'=>'physical-controller'],['subject_type'=>'physical_process','subject_id'=>'mix-1'],['trace_id'=>'trace-i','correlation_id'=>'corr-i','causation_id'=>null,'parent_event_ids'=>[]],['score'=>90,'band'=>'extreme','dimensions'=>['physical_safety'=>90]],['visibility'=>'t0gm_sovereign','attention_tier'=>'critical','review_required'=>true,'review_team'=>['physical_safety']],[],['execution'=>['execution_id'=>'x-i','state'=>'completed','adapter'=>'machine-controller']],'evt-irreversible');
$ingest->ingest($exec2);
$ti=$tf->make('company-a','evt-irreversible','complete irreversible physical transformation',['subject_type'=>'physical_process','subject_id'=>'mix-1'],['phase'=>'separate'],['phase'=>'combined'],['phase'=>'combined'],[],['score'=>0,'mode'=>'irreversible'],[['evidence_id'=>'ev-physical','evidence_type'=>'sensor_receipt','source'=>'machine-controller']]); $ts->append($ti);
$blocked=$service->invokeForEvent('evt-irreversible',$sovereign,'jason',['phase'=>'combined']);
rAssert($blocked[0]['plan']->disposition===T0gmRecoveryDisposition::BLOCKED,'irreversible truth cannot be overridden by God Mode');
rThrows(fn()=>$service->invokeForEvent('evt-recoverable',$delegated,'oversight',['status'=>'suspended'],['ledger-1'=>'unchanged']),'delegated oversight cannot invoke sovereign rewind');

echo "PASS state transitions preserve pre/intended/actual/dependency/reversibility evidence\n";
echo "PASS Rewind verifies current post-state before direct reversal\n";
echo "PASS changed dependencies or world state force recomputation\n";
echo "PASS irreversible transitions remain blocked even for T0GM\n";
echo "PASS God Mode recovery emits immutable causal intervention evidence\n";
