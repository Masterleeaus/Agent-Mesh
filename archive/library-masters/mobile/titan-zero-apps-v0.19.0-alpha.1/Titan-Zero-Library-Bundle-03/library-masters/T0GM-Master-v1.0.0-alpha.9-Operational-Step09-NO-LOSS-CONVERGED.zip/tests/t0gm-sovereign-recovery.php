<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Identity\T0gmCryptoSuiteRegistry;
use Titan\GodMode\Identity\T0gmDeviceTrustRegistry;
use Titan\GodMode\Identity\T0gmDeviceIsolationRegistry;
use Titan\GodMode\Recovery\T0gmSovereignRecoveryService;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Support\InMemoryNonceStore;

function srAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function srExpect(string $contains,callable $fn):void{try{$fn();}catch(Throwable $e){srAssert(str_contains($e->getMessage(),$contains),"expected $contains got {$e->getMessage()}");return;}throw new RuntimeException("expected failure:$contains");}
function srSign(array $payload,string $secret):string{return base64_encode(sodium_crypto_sign_detached(CanonicalJson::encode($payload),$secret));}

$now=time();
$principal='OWNER_CONTROL_PLANE_PRINCIPAL';
$crypto=new T0gmCryptoSuiteRegistry();
$nonceStore=new InMemoryNonceStore();

$recoveryRoot=sodium_crypto_sign_keypair();
$recoverySecret=sodium_crypto_sign_secretkey($recoveryRoot);
$recoveryPublic=sodium_crypto_sign_publickey($recoveryRoot);
$w1=sodium_crypto_sign_keypair();$w1s=sodium_crypto_sign_secretkey($w1);$w1p=sodium_crypto_sign_publickey($w1);
$w2=sodium_crypto_sign_keypair();$w2s=sodium_crypto_sign_secretkey($w2);$w2p=sodium_crypto_sign_publickey($w2);
$w3=sodium_crypto_sign_keypair();$w3s=sodium_crypto_sign_secretkey($w3);$w3p=sodium_crypto_sign_publickey($w3);
$newDevice=sodium_crypto_sign_keypair();$newDevicePublic=sodium_crypto_sign_publickey($newDevice);
$healthyDevice=sodium_crypto_sign_keypair();$healthyDevicePublic=sodium_crypto_sign_publickey($healthyDevice);
$lostDevice=sodium_crypto_sign_keypair();$lostDevicePublic=sodium_crypto_sign_publickey($lostDevice);

$policy=[
 'authority'=>'titan.god_mode',
 'principal_id'=>$principal,
 'quorum'=>2,
 'clock_skew_seconds'=>30,
];
$service=new T0gmSovereignRecoveryService(
 $crypto,
 $nonceStore,
 $policy,
 ['recovery-root-01'=>['suite'=>'ed25519','public_key'=>base64_encode($recoveryPublic),'principal_id'=>$principal,'purpose'=>'sovereign_recovery_only','status'=>'active']],
 [
  'witness-key-1'=>['suite'=>'ed25519','public_key'=>base64_encode($w1p),'participant_id'=>'witness-1','actor_type'=>'human','role'=>'recovery_witness','status'=>'active'],
  'witness-key-2'=>['suite'=>'ed25519','public_key'=>base64_encode($w2p),'participant_id'=>'witness-2','actor_type'=>'institution','role'=>'recovery_witness','status'=>'active'],
  'witness-key-3'=>['suite'=>'ed25519','public_key'=>base64_encode($w3p),'participant_id'=>'witness-3','actor_type'=>'hardware_custodian','role'=>'recovery_witness','status'=>'active'],
 ]
);

$payload=[
 'schema'=>'titan.t0gm.sovereign_recovery_request.v1',
 'recovery_id'=>'recovery-'.bin2hex(random_bytes(8)),
 'authority'=>'titan.god_mode',
 'principal_id'=>$principal,
 'new_device_key_id'=>'device-recovered-01',
 'new_device_public_key'=>base64_encode($newDevicePublic),
 'new_device_binding_id'=>'binding-recovered-01',
 'challenge'=>bin2hex(random_bytes(24)),
 'requested_at'=>$now,
 'recovery_expires_at'=>$now+300,
 'purpose'=>'restore-device-access-to-existing-sovereign-identity',
 'non_tenant'=>true,
];
$payloadHash=hash('sha256',CanonicalJson::encode($payload));
$witness=function(string $participant,string $keyId,string $secret)use($payloadHash):array{
 $statement=['schema'=>'titan.t0gm.sovereign_recovery_witness.v1','payload_hash'=>$payloadHash,'participant_id'=>$participant,'claim'=>'recovery-witness-only-no-sovereignty'];
 return ['participant_id'=>$participant,'key_id'=>$keyId,'suite'=>'ed25519','statement'=>$statement,'signature'=>srSign($statement,$secret)];
};
$rootStatement=['schema'=>'titan.t0gm.sovereign_recovery_continuity.v1','payload_hash'=>$payloadHash,'principal_id'=>$principal,'claim'=>'same-sovereign-principal-recovery-continuity'];
$request=['payload'=>$payload,'participant_approvals'=>[$witness('witness-1','witness-key-1',$w1s),$witness('witness-2','witness-key-2',$w2s)],'sovereign_recovery_proof'=>['key_id'=>'recovery-root-01','suite'=>'ed25519','statement'=>$rootStatement,'signature'=>srSign($rootStatement,$recoverySecret)]];

$authorization=$service->authorizeDeviceRecovery($request,$now);
srAssert($authorization['principal_id']===$principal,'recovery preserves same sovereign principal');
srAssert($authorization['device_binding_entry']['principal_id']===$principal,'recovered binding belongs to same principal');
srAssert($authorization['device_binding_entry']['binding_id']==='binding-recovered-01','replacement binding is explicit');
srAssert($authorization['quorum']['verified_participants']===2,'independent recovery quorum verified');
srAssert($authorization['sovereign_recovery_continuity_verified']===true,'user-controlled recovery root continuity required');
srAssert($authorization['grants_t0gm_sovereignty']===false,'recovery authorization does not transfer sovereignty');
srAssert($authorization['execution_authority_granted']===false,'recovery authorization grants no execution authority');
srAssert($authorization['company_authority_embedded']===false,'recovery authorization embeds no company authority');
srAssert($authorization['requires_normal_identity_proof_after_enrollment']===true,'recovered device must still perform normal sovereign identity proof');

$isolation=new T0gmDeviceIsolationRegistry([
 'device-lost'=>['principal_id'=>$principal,'binding_id'=>'binding-lost','status'=>'quarantined','quarantined_at'=>$now-30,'reason'=>'device-lost-or-compromised','evidence_ref'=>'incident-11'],
]);
$registry=new T0gmDeviceTrustRegistry([
 'device-healthy'=>['principal_id'=>$principal,'device_public_key_hash'=>hash('sha256',$healthyDevicePublic),'binding_id'=>'binding-healthy','status'=>'active','bound_from'=>$now-1000],
 'device-lost'=>['principal_id'=>$principal,'device_public_key_hash'=>hash('sha256',$lostDevicePublic),'binding_id'=>'binding-lost','status'=>'active','bound_from'=>$now-1000],
 'device-recovered-01'=>$authorization['device_binding_entry'],
],$isolation);
$healthy=$registry->bindingForCurrentUse('device-healthy',$principal,$healthyDevicePublic,$now);
$recovered=$registry->bindingForCurrentUse('device-recovered-01',$principal,$newDevicePublic,$now);
srAssert($healthy['binding_id']==='binding-healthy','healthy sibling remains independently valid after recovery');
srAssert($recovered['binding_id']==='binding-recovered-01','recovered device becomes a normal independent binding');
srExpect('device-binding-quarantined',fn()=>$registry->bindingForCurrentUse('device-lost',$principal,$lostDevicePublic,$now));

$missingQuorum=$request;$missingQuorum['participant_approvals']=[$request['participant_approvals'][0]];
srExpect('recovery-quorum-not-satisfied',fn()=>$service->authorizeDeviceRecovery($missingQuorum,$now));
$duplicateQuorum=$request;$duplicateQuorum['payload']['challenge']=bin2hex(random_bytes(24));$duplicateQuorum['payload']['recovery_id']='recovery-'.bin2hex(random_bytes(8));
$dupHash=hash('sha256',CanonicalJson::encode($duplicateQuorum['payload']));
$dupStatement=['schema'=>'titan.t0gm.sovereign_recovery_witness.v1','payload_hash'=>$dupHash,'participant_id'=>'witness-1','claim'=>'recovery-witness-only-no-sovereignty'];
$duplicateQuorum['participant_approvals']=[['participant_id'=>'witness-1','key_id'=>'witness-key-1','suite'=>'ed25519','statement'=>$dupStatement,'signature'=>srSign($dupStatement,$w1s)],['participant_id'=>'witness-1','key_id'=>'witness-key-1','suite'=>'ed25519','statement'=>$dupStatement,'signature'=>srSign($dupStatement,$w1s)]];
$dupRoot=['schema'=>'titan.t0gm.sovereign_recovery_continuity.v1','payload_hash'=>$dupHash,'principal_id'=>$principal,'claim'=>'same-sovereign-principal-recovery-continuity'];
$duplicateQuorum['sovereign_recovery_proof']=['key_id'=>'recovery-root-01','suite'=>'ed25519','statement'=>$dupRoot,'signature'=>srSign($dupRoot,$recoverySecret)];
srExpect('duplicate-recovery-participant',fn()=>$service->authorizeDeviceRecovery($duplicateQuorum,$now));

$noRoot=$request;$noRoot['payload']['challenge']=bin2hex(random_bytes(24));$noRoot['payload']['recovery_id']='recovery-'.bin2hex(random_bytes(8));unset($noRoot['sovereign_recovery_proof']);
srExpect('sovereign-recovery-proof-missing',fn()=>$service->authorizeDeviceRecovery($noRoot,$now));

$rootOnly=$request;$rootOnly['payload']['challenge']=bin2hex(random_bytes(24));$rootOnly['payload']['recovery_id']='recovery-'.bin2hex(random_bytes(8));$rootOnly['participant_approvals']=[];
srExpect('recovery-quorum-not-satisfied',fn()=>$service->authorizeDeviceRecovery($rootOnly,$now));

srExpect('sovereign-recovery-replay-detected',fn()=>$service->authorizeDeviceRecovery($request,$now));

srExpect('recovery-ai-participant-forbidden',fn()=>new T0gmSovereignRecoveryService($crypto,new InMemoryNonceStore(),$policy,['recovery-root-01'=>['suite'=>'ed25519','public_key'=>base64_encode($recoveryPublic),'principal_id'=>$principal,'purpose'=>'sovereign_recovery_only','status'=>'active']],['ai-key'=>['suite'=>'ed25519','public_key'=>base64_encode($w1p),'participant_id'=>'oversight-ai','actor_type'=>'advanced_intelligence','role'=>'recovery_witness','status'=>'active']]));

$tenantBound=$payload;$tenantBound['company_id']='company-a';$tenantBound['challenge']=bin2hex(random_bytes(24));$tenantBound['recovery_id']='recovery-'.bin2hex(random_bytes(8));
srExpect('application-authority-binding-forbidden:company_id',fn()=>$service->authorizeDeviceRecovery(['payload'=>$tenantBound,'participant_approvals'=>[],'sovereign_recovery_proof'=>[]],$now));

echo "PASS recovery quorum can restore access only to the existing T0GM sovereign principal\n";
echo "PASS witnesses and AI cannot inherit or independently exercise T0GM sovereignty\n";
echo "PASS recovered access creates only a new device binding and no company or execution authority\n";
echo "PASS recovery replay and duplicate-participant paths fail closed\n";
echo "PASS healthy sibling devices remain independently valid and quarantined devices stay isolated after recovery\n";
