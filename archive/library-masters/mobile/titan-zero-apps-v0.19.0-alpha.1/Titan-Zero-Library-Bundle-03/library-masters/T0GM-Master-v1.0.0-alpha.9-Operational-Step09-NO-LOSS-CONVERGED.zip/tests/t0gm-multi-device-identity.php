<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Identity\T0gmCryptoSuiteRegistry;
use Titan\GodMode\Identity\T0gmDeviceTrustRegistry;
use Titan\GodMode\Identity\T0gmHardwareAttestation;
use Titan\GodMode\Identity\T0gmIdentityRoot;
use Titan\GodMode\Identity\T0gmVerifierTrustStore;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Support\InMemoryNonceStore;

function mdAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function mdExpect(string $contains,callable $fn):void{try{$fn();}catch(Throwable $e){mdAssert(str_contains($e->getMessage(),$contains),"expected $contains got {$e->getMessage()}");return;}throw new RuntimeException("expected failure:$contains");}
function mdSign(array $payload,string $secret):string{return base64_encode(sodium_crypto_sign_detached(CanonicalJson::encode($payload),$secret));}

$now=time();
$root=sodium_crypto_sign_keypair();$rootSecret=sodium_crypto_sign_secretkey($root);$rootPublic=sodium_crypto_sign_publickey($root);
$att=sodium_crypto_sign_keypair();$attSecret=sodium_crypto_sign_secretkey($att);$attPublic=sodium_crypto_sign_publickey($att);
$deviceA=sodium_crypto_sign_keypair();$deviceAPub=sodium_crypto_sign_publickey($deviceA);
$deviceB=sodium_crypto_sign_keypair();$deviceBPub=sodium_crypto_sign_publickey($deviceB);

$principal='OWNER_CONTROL_PLANE_PRINCIPAL';
$policy=['authority'=>'titan.god_mode','principal_class'=>'builder_control_plane_principal','principal_id'=>$principal,'audience'=>'titan-builder-control-plane','clock_skew_seconds'=>30];
$crypto=new T0gmCryptoSuiteRegistry();
$idStore=new T0gmVerifierTrustStore(['identity-root-01'=>['suite'=>'ed25519','public_key'=>base64_encode($rootPublic)]]);
$attStore=new T0gmVerifierTrustStore(['att-root-01'=>['suite'=>'ed25519','public_key'=>base64_encode($attPublic)]]);
$devices=new T0gmDeviceTrustRegistry([
 'device-a'=>['principal_id'=>$principal,'device_public_key_hash'=>hash('sha256',$deviceAPub),'binding_id'=>'bind-a','status'=>'active','bound_from'=>$now-3600,'provenance'=>['enrollment'=>'hardware-assisted','record_id'=>'enroll-a']],
 'device-b'=>['principal_id'=>$principal,'device_public_key_hash'=>hash('sha256',$deviceBPub),'binding_id'=>'bind-b','status'=>'active','bound_from'=>$now-3600,'provenance'=>['enrollment'=>'hardware-assisted','record_id'=>'enroll-b']],
]);
$identity=new T0gmIdentityRoot($idStore,new T0gmHardwareAttestation($attStore,$crypto),$crypto,new InMemoryNonceStore(),$policy,$devices);

$makeProof=function(string $deviceId,string $devicePublic,string $challenge)use($now,$principal,$rootSecret,$attSecret):array{
 $payload=['schema'=>'titan.t0gm.identity_root_proof.v1','authority'=>'titan.god_mode','principal_class'=>'builder_control_plane_principal','principal_id'=>$principal,'device_key_id'=>$deviceId,'device_public_key'=>base64_encode($devicePublic),'audience'=>'titan-builder-control-plane','challenge'=>$challenge,'issued_at'=>$now,'proof_expires_at'=>$now+60,'non_tenant'=>true];
 $attPayload=['schema'=>'titan.t0gm.hardware_attestation.v1','device_key_id'=>$deviceId,'device_public_key_hash'=>hash('sha256',$devicePublic),'hardware_backed'=>true,'hardware_class'=>'test-secure-hardware','challenge'=>$challenge,'measurement'=>'boot-state:verified','issued_at'=>$now,'evidence_hash'=>hash('sha256','attestation-'.$deviceId)];
 return ['payload'=>$payload,'root_key_id'=>'identity-root-01','signature_suite'=>'ed25519','root_signature'=>mdSign($payload,$rootSecret),'hardware_attestation'=>['payload'=>$attPayload,'attestation_key_id'=>'att-root-01','signature_suite'=>'ed25519','signature'=>mdSign($attPayload,$attSecret)]];
};

$a=$identity->verify($makeProof('device-a',$deviceAPub,bin2hex(random_bytes(24))),$now);
$b=$identity->verify($makeProof('device-b',$deviceBPub,bin2hex(random_bytes(24))),$now);
mdAssert($a['principal_id']===$b['principal_id'],'multiple devices bind to same sovereign principal');
mdAssert($a['device_binding']['binding_id']==='bind-a','device A provenance retained');
mdAssert($b['device_binding']['binding_id']==='bind-b','device B provenance retained');
mdAssert($a['device_binding']['binding_id']!==$b['device_binding']['binding_id'],'device provenance stays independent');

// Even with a freshly root-signed and hardware-attested envelope, Device A cannot be re-labelled with Device B key material.
mdExpect('device-binding-public-key-mismatch',fn()=>$identity->verify($makeProof('device-a',$deviceBPub,bin2hex(random_bytes(24))),$now));

$isolated=new T0gmDeviceTrustRegistry([
 'device-a'=>['principal_id'=>$principal,'device_public_key_hash'=>hash('sha256',$deviceAPub),'binding_id'=>'bind-a','status'=>'active','bound_from'=>$now-3600],
 'device-b'=>['principal_id'=>$principal,'device_public_key_hash'=>hash('sha256',$deviceBPub),'binding_id'=>'bind-b','status'=>'revoked','bound_from'=>$now-3600,'revoked_at'=>$now-5],
]);
$identity2=new T0gmIdentityRoot($idStore,new T0gmHardwareAttestation($attStore,$crypto),$crypto,new InMemoryNonceStore(),$policy,$isolated);
$a2=$identity2->verify($makeProof('device-a',$deviceAPub,bin2hex(random_bytes(24))),$now);
mdAssert($a2['device_binding']['binding_id']==='bind-a','revoking one device does not revoke healthy sibling device');
mdExpect('device-binding-revoked',fn()=>$identity2->verify($makeProof('device-b',$deviceBPub,bin2hex(random_bytes(24))),$now));

$history=$isolated->bindingForHistoricalVerification('device-b',$principal,$deviceBPub,$now-30);
mdAssert($history['binding_id']==='bind-b','pre-revocation device provenance remains historically inspectable');
mdExpect('device-binding-revoked-at',fn()=>$isolated->bindingForHistoricalVerification('device-b',$principal,$deviceBPub,$now));

mdAssert(!array_key_exists('company_id',$a['device_binding']),'device binding does not create company authority');
mdAssert(($a['application_role_authority']??null)===false,'device membership does not create application-role authority');

mdExpect('duplicate-device-binding-id',fn()=>new T0gmDeviceTrustRegistry([
 'device-x'=>['principal_id'=>$principal,'device_public_key_hash'=>hash('sha256',$deviceAPub),'binding_id'=>'same-binding','status'=>'active'],
 'device-y'=>['principal_id'=>$principal,'device_public_key_hash'=>hash('sha256',$deviceBPub),'binding_id'=>'same-binding','status'=>'active'],
]));

echo "PASS multiple independently proven devices bind to one T0GM sovereign principal\n";
echo "PASS device public keys and provenance cannot be relabelled across sibling devices\n";
echo "PASS one device lifecycle change does not silently alter sibling-device trust\n";
echo "PASS device binding remains identity evidence, not company or execution authority\n";
