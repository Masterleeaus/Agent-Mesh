<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\Workforce\T0gmCanonicalAiWorkforceRegistry;
use Titan\GodMode\Security\GodModeException;
function wrAssert($c,$m){if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);}

$registry=new T0gmCanonicalAiWorkforceRegistry();
$model=$registry->register([
 'registry_id'=>'model-risk-v1','company_id'=>'company_a','kind'=>'model','name'=>'Risk Model',
 'provider'=>'provider-a','model_ref'=>'risk-model-v1','provenance'=>['source'=>'configured']
]);
$worker=$registry->register([
 'registry_id'=>'worker-risk-01','company_id'=>'company_a','kind'=>'worker','name'=>'Risk Worker',
 'model_ids'=>['model-risk-v1'],'specialist_ids'=>[],'service_ids'=>[],'provenance'=>['source'=>'provisioned']
]);
$specialist=$registry->register([
 'registry_id'=>'specialist-security','company_id'=>'company_a','kind'=>'specialist','name'=>'Security Specialist',
 'specialty'=>'security','model_ids'=>['model-risk-v1'],'provenance'=>['source'=>'oversight']
]);
$service=$registry->register([
 'registry_id'=>'service-monitor-01','company_id'=>'company_a','kind'=>'autonomous_service','name'=>'Monitoring Service',
 'model_ids'=>['model-risk-v1'],'provenance'=>['source'=>'managed-service']
]);
$team=$registry->register([
 'registry_id'=>'team-oversight','company_id'=>'company_a','kind'=>'team','name'=>'Oversight Team',
 'member_ids'=>['worker-risk-01','specialist-security','service-monitor-01'],'provenance'=>['source'=>'t0gm']
]);

wrAssert($registry->count('company_a')===5,'five authoritative entries');
wrAssert(count($registry->byKind('company_a','model'))===1,'model indexed');
wrAssert(count($registry->byKind('company_a','worker'))===1,'worker indexed');
wrAssert(count($registry->byKind('company_a','specialist'))===1,'specialist indexed');
wrAssert(count($registry->byKind('company_a','team'))===1,'team indexed');
wrAssert(count($registry->byKind('company_a','autonomous_service'))===1,'service indexed');
wrAssert($team['member_ids']===['worker-risk-01','specialist-security','service-monitor-01'],'team membership');
wrAssert($registry->get('company_a','worker-risk-01')['authority_granted']===false,'registry grants no authority');
wrAssert($registry->get('company_a','worker-risk-01')['canonical_registry']===true,'canonical marker');
wrAssert($registry->search('company_a','risk')[0]['company_id']==='company_a','company-scoped search');
$state=$registry->transition('company_a','worker-risk-01','active',['reason'=>'attested']);
wrAssert($state['lifecycle_state']==='active' && $state['lifecycle_revision']===2,'lifecycle transition');
try{$registry->register(['registry_id'=>'bad','company_id'=>'company_a','tenant_id'=>'legacy','kind'=>'worker','name'=>'bad']);throw new RuntimeException('legacy accepted');}catch(GodModeException $e){wrAssert(str_starts_with($e->getMessage(),'legacy-tenant-boundary-forbidden:'),'legacy rejected');}
try{$registry->register(['registry_id'=>'bad2','company_id'=>'company_a','kind'=>'worker','name'=>'bad','authority'=>'root']);throw new RuntimeException('authority accepted');}catch(GodModeException $e){wrAssert(str_starts_with($e->getMessage(),'authority-bearing-workforce-registry-field-forbidden:'),'authority rejected');}
try{$registry->register(['registry_id'=>'bad3','company_id'=>'company_b','kind'=>'team','name'=>'bad','member_ids'=>['worker-risk-01']]);throw new RuntimeException('cross-company member accepted');}catch(GodModeException $e){wrAssert($e->getMessage()==='workforce-registry-reference-not-found:worker-risk-01','cross-company reference rejected');}
echo "PASS canonical AI workforce registry covers worker/specialist/team/model/autonomous-service identities\nPASS registry is company-scoped, lifecycle-aware, provenance-retaining and authority-neutral\nPASS registry fails closed on legacy tenant boundaries, authority-bearing fields and cross-company references\n";
