<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Audit\FileAppendOnlySovereignAuditStore;
use Titan\GodMode\Audit\T0gmSovereignAuditTrustStore;
use Titan\GodMode\Anchor\FileIndependentEvidenceAnchorProvider;
use Titan\GodMode\Anchor\T0gmEvidenceAnchorTrustStore;
use Titan\GodMode\Anchor\T0gmIndependentEvidenceAnchorService;
use Titan\GodMode\Security\CanonicalJson;

function iaAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function iaExpect(string $contains,callable $fn):void{try{$fn();}catch(Throwable $e){iaAssert(str_contains($e->getMessage(),$contains),"expected $contains got {$e->getMessage()}");return;}throw new RuntimeException("expected failure:$contains");}

$root=sys_get_temp_dir().'/t0gm-anchor-'.bin2hex(random_bytes(5));
$auditDir=$root.'/titan-audit';$externalDir=$root.'/independent-anchor-domain';
mkdir($auditDir,0700,true);mkdir($externalDir,0700,true);

// Titan audit signer is distinct from the independent anchor signer.
$auditKp=sodium_crypto_sign_keypair();$auditSk=sodium_crypto_sign_secretkey($auditKp);$auditPk=sodium_crypto_sign_publickey($auditKp);
$anchorKp=sodium_crypto_sign_keypair();$anchorSk=sodium_crypto_sign_secretkey($anchorKp);$anchorPk=sodium_crypto_sign_publickey($anchorKp);
iaAssert(!hash_equals($auditPk,$anchorPk),'anchor trust domain uses independent signing material');

$auditTrust=new T0gmSovereignAuditTrustStore(['audit-root-01'=>[
 'suite'=>'ed25519','public_key'=>base64_encode($auditPk),'trusted_from'=>time()-100,'purposes'=>['sovereign_audit_record'],
]]);
$audit=new FileAppendOnlySovereignAuditStore($auditDir,$auditTrust,'audit-root-01',$auditSk);
$r1=$audit->append(['evidence_id'=>'critical-001','evidence_type'=>'t0gm.sovereign_decision','occurred_at'=>gmdate('c'),'source'=>'t0gm','company_id'=>'co-1','payload'=>['decision'=>'contain-compromise']]);
$r2=$audit->append(['evidence_id'=>'critical-002','evidence_type'=>'t0gm.execution_receipt','occurred_at'=>gmdate('c'),'source'=>'gateway','company_id'=>'co-1','payload'=>['result'=>'contained']]);

$anchorTrust=new T0gmEvidenceAnchorTrustStore(['external-anchor-01'=>[
 'suite'=>'ed25519','public_key'=>base64_encode($anchorPk),'trusted_from'=>time()-100,
 'purposes'=>['independent_evidence_anchor'], 'provider_id'=>'independent-file-anchor-test',
]]);
$provider=new FileIndependentEvidenceAnchorProvider($externalDir,'independent-file-anchor-test','external-anchor-01',$anchorSk);
$service=new T0gmIndependentEvidenceAnchorService($provider,$anchorTrust);

$checkpointFiles=glob($auditDir.'/checkpoints/*.checkpoint.json');sort($checkpointFiles,SORT_STRING);
$checkpoint=json_decode((string)file_get_contents(end($checkpointFiles)),true,512,JSON_THROW_ON_ERROR);
$receipt=$service->anchorCheckpoint($checkpoint,[
 'criticality'=>'critical','reason'=>'sovereign containment completed','requested_by'=>'t0gm-audit-anchor-worker',
]);

iaAssert(($receipt['audit_sequence']??0)===2,'receipt binds audit sequence');
iaAssert(($receipt['record_hash']??'')===$r2['record_hash'],'receipt binds sovereign audit head');
iaAssert(($receipt['provider_id']??'')==='independent-file-anchor-test','receipt names independent provider');
iaAssert(($receipt['semantics']['grants_authority']??null)===false,'anchor receipt is non-authoritative');
iaAssert($service->verifyReceiptAgainstCheckpoint($receipt,$checkpoint)===true,'external receipt verifies against original checkpoint');

// Titan local history rewritten after anchoring must not match the independent receipt.
$forged=$checkpoint;$forged['record_hash']=str_repeat('a',64);
iaExpect('anchor-checkpoint-record-hash-mismatch',fn()=>$service->verifyReceiptAgainstCheckpointOrFail($receipt,$forged));

// An attacker controlling Titan cannot forge an external receipt with Titan audit signing material.
$forgedReceipt=$receipt;$copy=$forgedReceipt;unset($copy['signature']);
$forgedReceipt['signature']['signature']=base64_encode(sodium_crypto_sign_detached(CanonicalJson::encode($copy),$auditSk));
iaExpect('independent-anchor-signature-invalid',fn()=>$service->verifyReceiptAgainstCheckpointOrFail($forgedReceipt,$checkpoint));

// Tampering with the provider's durable receipt is detected independently of Titan state.
$receiptPath=$provider->receiptPath((string)$receipt['anchor_id']);
$external=json_decode((string)file_get_contents($receiptPath),true,512,JSON_THROW_ON_ERROR);
// Test fixture: production receipts are read-only; temporarily make this fixture writable to simulate external-domain tampering under non-root runners.
@chmod($receiptPath,0600);
$external['record_hash']=str_repeat('b',64);file_put_contents($receiptPath,CanonicalJson::encode($external));
iaExpect('independent-anchor-',fn()=>$provider->loadAndVerify((string)$receipt['anchor_id'],$anchorTrust));
file_put_contents($receiptPath,CanonicalJson::encode($receipt));@chmod($receiptPath,0400);

// Re-anchoring the same checkpoint is idempotent, but the same anchor id cannot be rebound to different evidence.
$receipt2=$service->anchorCheckpoint($checkpoint,['criticality'=>'critical','reason'=>'sovereign containment completed','requested_by'=>'t0gm-audit-anchor-worker']);
iaAssert($receipt2['anchor_id']===$receipt['anchor_id'],'same commitment anchors idempotently');
$changed=$checkpoint;$changed['record_hash']=str_repeat('c',64);
iaExpect('anchor-checkpoint-record-hash-mismatch',fn()=>$service->verifyReceiptAgainstCheckpointOrFail($receipt,$changed));

// Local deletion cannot erase the externally retained receipt.
foreach(glob($auditDir.'/checkpoints/*.checkpoint.json')?:[] as $f)unlink($f);
@unlink($auditDir.'/sovereign-audit.jsonl');
$loaded=$provider->loadAndVerify((string)$receipt['anchor_id'],$anchorTrust);
iaAssert($loaded['record_hash']===$r2['record_hash'],'independent receipt survives Titan audit-store deletion');

// Anchor evidence never creates company/T0GM/execution authority.
iaAssert(($loaded['semantics']['company_authority_embedded']??null)===false,'no company authority in anchor');
iaAssert(($loaded['semantics']['constitutes_t0gm_approval']??null)===false,'no T0GM approval in anchor');
iaAssert(($loaded['semantics']['execution_authority_embedded']??null)===false,'no execution authority in anchor');

echo "PASS independent anchor uses a separate trust domain and binds exact audit checkpoint state\n";
echo "PASS rewritten Titan history and forged/tampered external receipts fail closed\n";
echo "PASS external receipt survives local audit-store/application compromise\n";
echo "PASS evidence anchoring proves history but never grants sovereign company or execution authority\n";
