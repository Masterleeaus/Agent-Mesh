<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedIngestor;
use Titan\GodMode\Feed\T0gmLineageFactory;
use Titan\GodMode\Ranking\T0gmAttentionScorer;
use Titan\GodMode\Store\InMemorySovereignActivityStore;
use Titan\GodMode\View\T0gmFeedView;
use Titan\GodMode\View\T0gmFeedViewService;

function vAssert($condition, string $message): void { if (!$condition) throw new RuntimeException('ASSERTION FAILED: '.$message); }

$factory = new T0gmEventFactory();
$lineage = new T0gmLineageFactory();
$store = new InMemorySovereignActivityStore();
$ingest = new T0gmFeedIngestor($store);
$views = new T0gmFeedViewService($store);
$scorer = new T0gmAttentionScorer();
$sovereign = T0gmFeedAccessContext::sovereign();
$companyA = new T0gmFeedAccessContext('oversight-a','t0gm.oversight_ai',['company_a'],false);

$event = function(string $id,string $company,string $kind,string $corr,array $dimensions,array $signals,array $details,array $actor=null) use ($factory,$lineage) {
    $risk = max(array_values($dimensions) ?: [10]);
    $band = $risk >= 90 ? 'extreme' : ($risk >= 70 ? 'high' : ($risk >= 40 ? 'medium' : 'low'));
    return $factory->make(
        $kind,
        ['scope'=>'company','company_id'=>$company],
        $actor ?? ['actor_type'=>'advanced_intelligence','actor_id'=>'ai-'.$company,'authority_class'=>'delegated_ai'],
        ['system'=>'titan-signal','component'=>'intelligent-feed-fixture'],
        ['subject_type'=>'operation','subject_id'=>'subject-'.$id],
        $lineage->create('trace-'.$id,$corr,null,[]),
        ['score'=>$risk,'band'=>$band,'dimensions'=>$dimensions],
        ['visibility'=>'t0gm_sovereign','attention_tier'=>'important','review_required'=>true,'review_team'=>['t0gm-oversight']],
        [['evidence_id'=>'evidence-'.$id,'evidence_type'=>'fixture','source'=>'test']],
        array_merge(['attention_signals'=>$signals],$details),
        $id,
        '2026-09-02T10:20:00Z','2026-09-02T10:20:01Z'
    );
};

$security = $event('evt-security','company_a',T0gmEventKind::ANOMALY,'corr-security',['cyber'=>95],[
    'significance'=>75,'anomaly'=>96,'urgency'=>85,'reversibility'=>60,'financial_exposure'=>5,'physical_impact'=>10,'environmental_impact'=>0,'confidence'=>70,'dependency'=>45,'domains'=>['security','identity']
],['anomaly'=>['anomaly_type'=>'credential-abuse','summary'=>'Privileged credential anomaly']]);
$money = $event('evt-money','company_a',T0gmEventKind::AI_DECISION,'corr-money',['financial'=>92],[
    'significance'=>85,'anomaly'=>35,'urgency'=>80,'reversibility'=>20,'financial_exposure'=>97,'physical_impact'=>0,'environmental_impact'=>0,'confidence'=>82,'dependency'=>70,'domains'=>['finance','ledger']
],['decision'=>['decision_id'=>'decision-money','determination'=>'hold-transfer','reason_codes'=>['FINANCIAL_EXPOSURE']]]);
$environment = $event('evt-env','company_a',T0gmEventKind::OBSERVATION,'corr-env',['environmental'=>91],[
    'significance'=>88,'anomaly'=>75,'urgency'=>82,'reversibility'=>35,'financial_exposure'=>15,'physical_impact'=>35,'environmental_impact'=>94,'confidence'=>65,'dependency'=>60,'domains'=>['environment','water']
],['observation'=>['summary'=>'Potential contaminant discharge']]);
$physical = $event('evt-physical','company_a',T0gmEventKind::OBSERVATION,'corr-physical',['physical'=>97],[
    'significance'=>50,'anomaly'=>20,'urgency'=>40,'reversibility'=>90,'financial_exposure'=>0,'physical_impact'=>97,'environmental_impact'=>0,'confidence'=>95,'dependency'=>10,'domains'=>['physical','safety']
],['observation'=>['summary'=>'Physical safety interlock triggered']]);
$crossA = $event('evt-cross-a','company_a',T0gmEventKind::OBSERVATION,'corr-cross',['operational'=>25],[
    'significance'=>40,'anomaly'=>25,'urgency'=>30,'reversibility'=>100,'financial_exposure'=>0,'physical_impact'=>0,'environmental_impact'=>0,'confidence'=>80,'dependency'=>20,'domains'=>['operations']
],['observation'=>['summary'=>'Shared pattern A']]);
$crossB = $event('evt-cross-b','company_b',T0gmEventKind::OBSERVATION,'corr-cross',['operational'=>25],[
    'significance'=>40,'anomaly'=>25,'urgency'=>30,'reversibility'=>100,'financial_exposure'=>0,'physical_impact'=>0,'environmental_impact'=>0,'confidence'=>80,'dependency'=>20,'domains'=>['operations']
],['observation'=>['summary'=>'Shared pattern B']]);
$target = $event('evt-target','company_a',T0gmEventKind::AI_DECISION,'corr-super',['financial'=>35],[
    'significance'=>45,'anomaly'=>10,'urgency'=>35,'reversibility'=>70,'financial_exposure'=>20,'physical_impact'=>0,'environmental_impact'=>0,'confidence'=>90,'dependency'=>30,'domains'=>['finance']
],['decision'=>['decision_id'=>'decision-target','determination'=>'suspend-supplier','reason_codes'=>['POLICY_MATCH']]]);
$supersession = $event('evt-super','company_a',T0gmEventKind::SUPERSESSION,'corr-super',['governance'=>50],[
    'significance'=>90,'anomaly'=>0,'urgency'=>90,'reversibility'=>85,'financial_exposure'=>25,'physical_impact'=>0,'environmental_impact'=>0,'confidence'=>100,'dependency'=>75,'domains'=>['governance']
],['supersession'=>['supersession_id'=>'super-1','supersedes_event_ids'=>['evt-target'],'directive'=>'do-not-suspend']],['actor_type'=>'human','actor_id'=>'T0GM_OWNER','authority_class'=>'titan.god_mode']);

foreach ([$security,$money,$environment,$physical,$crossA,$crossB,$target,$supersession] as $e) $ingest->ingest($e);

$physicalScore = $scorer->score($physical);
vAssert($physicalScore->score >= 95 && $physicalScore->tier === 'critical','extreme physical safety cannot be averaged away');
vAssert(in_array('PHYSICAL_SAFETY_CRITICAL',$physicalScore->reasonCodes,true),'physical floor is explainable');
$moneyScore = $scorer->score($money);
vAssert($moneyScore->signals->reversibility === 20 && $moneyScore->signals->irreversibility() === 80,'reversibility and irreversibility are complementary');
vAssert($moneyScore->score >= 85,'extreme financial exposure has urgent floor');

$critical = $views->view(T0gmFeedView::CRITICAL_NOW,$sovereign);
vAssert(in_array('evt-physical',array_column(array_column($critical,'record'),'event_id'),true),'Critical Now includes physical critical event');
$ai = $views->view(T0gmFeedView::AI_DECISIONS,$sovereign);
vAssert(count($ai) === 2,'AI Decisions includes decision events including superseded target');
$securityView = $views->view(T0gmFeedView::SECURITY,$sovereign);
vAssert(in_array('evt-security',array_column(array_column($securityView,'record'),'event_id'),true),'Security view includes security event');
$moneyView = $views->view(T0gmFeedView::MONEY,$sovereign);
vAssert(in_array('evt-money',array_column(array_column($moneyView,'record'),'event_id'),true),'Money view includes financial event');
$envView = $views->view(T0gmFeedView::ENVIRONMENT,$sovereign);
vAssert(in_array('evt-env',array_column(array_column($envView,'record'),'event_id'),true),'Environment view includes environmental event');
$cross = $views->view(T0gmFeedView::CROSS_COMPANY,$sovereign);
$crossIds = array_column(array_column($cross,'record'),'event_id');
vAssert(in_array('evt-cross-a',$crossIds,true) && in_array('evt-cross-b',$crossIds,true),'Cross-Company detects shared correlation across companies');
vAssert(count($views->view(T0gmFeedView::CROSS_COMPANY,$companyA)) === 0,'delegated company reader cannot infer hidden cross-company correlation');
$sup = $views->view(T0gmFeedView::SUPERSEDED,$sovereign);
$supIds = array_column(array_column($sup,'record'),'event_id');
vAssert(in_array('evt-target',$supIds,true) && in_array('evt-super',$supIds,true),'Superseded view includes target and supersession event');
$targetProjection = current(array_filter($sup,fn($i)=>$i['record']['event_id']==='evt-target'));
vAssert($targetProjection['superseded'] === true && $targetProjection['superseded_by'] === ['evt-super'],'supersession projection identifies governing supersession');
$irreversible = $views->view(T0gmFeedView::IRREVERSIBLE,$sovereign);
vAssert(in_array('evt-money',array_column(array_column($irreversible,'record'),'event_id'),true),'Irreversible view includes low-reversibility money decision');
$everything = $views->view(T0gmFeedView::EVERYTHING,$sovereign);
vAssert(count($everything) === 8,'Everything includes every visible event');
vAssert($everything[0]['attention']['score'] >= $everything[1]['attention']['score'],'Everything is sorted by attention score');

// Ranking is projection-only: immutable stored event remains byte/hash-identical and audit lineage still verifies.
$storedMoney = $store->get('evt-money',$sovereign);
vAssert(!isset($storedMoney['event']['attention_projection']),'ranking does not mutate immutable event');
vAssert($store->verifyAuditLineage(),'view/ranking projection does not disturb immutable audit lineage');

echo "PASS deterministic multi-factor attention scoring\n";
echo "PASS critical-domain non-averaging floors\n";
echo "PASS explainable reversibility/confidence/dependency projections\n";
echo "PASS Critical Now, AI Decisions, Security, Money, Environment views\n";
echo "PASS Cross-Company inference without delegated leakage\n";
echo "PASS Superseded and Irreversible views\n";
echo "PASS Everything ranking and immutable source events\n";
