<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\Capability\SovereignCapabilityFactory;
use Titan\GodMode\Policy\ClientAuthorityPolicyEngine;
use Titan\GodMode\Policy\ClientAuthorityProfileFactory;
use Titan\GodMode\Policy\ClientAuthorityProfileType;

function p13(bool $ok,string $message): void { if(!$ok) throw new RuntimeException($message); echo "PASS $message\n"; }

$factory=new SovereignCapabilityFactory();
$profiles=new ClientAuthorityProfileFactory();
$engine=new ClientAuthorityPolicyEngine();
$extinction=[];
foreach(['purpose_invalid','authority_revoked','company_changed','target_changed','risk_constraint_breached','safety_interlock','superseded','t0gm_extinguish'] as $ext){$extinction[]=['condition_id'=>'ext-'.$ext,'condition_type'=>$ext,'description'=>'Extinguish when '.$ext];}
$cap=$factory->create([
 'authority_holder'=>['authority_class'=>'titan.god_mode','identity_id'=>'t0gm-human','actor_type'=>'human'],
 'authority_basis'=>['basis_type'=>'contract','basis_id'=>'agreement-13','description'=>'Executable client authority agreement'],
 'company_id'=>'company-13',
 'purpose'=>['purpose_id'=>'p13','statement'=>'Restore one verified record','intended_outcome'=>'Verified recovery'],
 'target'=>['target_type'=>'database','target_id'=>'db-13','system'=>'postgresql','environment'=>'production','resource_ids'=>['r13']],
 'permitted_effects'=>[['effect_id'=>'e13','operation'=>'restore_record','resource_type'=>'record','resource_ids'=>['r13']]],
 'prohibited_effects'=>[['operation'=>'delete_everything','reason'=>'unbounded destructive effect']],
 'evidence'=>[['evidence_id'=>'ev13','evidence_type'=>'incident','source'=>'t0gm-feed','integrity_ref'=>'sha256:test']],
 'risk_constraints'=>['max_risk_score'=>60,'max_financial_exposure'=>60,'max_physical_impact'=>20,'max_environmental_impact'=>20,'prohibited_risk_bands'=>['extreme']],
 'extinction_conditions'=>$extinction,
]);
$baseReq=['company_id'=>'company-13','target'=>$cap['target'],'operation'=>'restore_record','action_class'=>'recovery'];

$managed=$profiles->create(ClientAuthorityProfileType::TITAN_MANAGED,'company-13','agreement-13');
p13($engine->evaluate($managed,$cap,$baseReq)->allowed,'Titan Managed permits bounded execution without routine client approval');

$co=$profiles->create(ClientAuthorityProfileType::CO_MANAGED,'company-13','agreement-13');
$d=$engine->evaluate($co,$cap,$baseReq);
p13(!$d->allowed && in_array('client_approval_required',$d->reasons,true),'Co-Managed requires client approval for recovery/mutation');
$approved=$baseReq+['client_approval'=>['approved'=>true,'approval_id'=>'approval-1','company_id'=>'company-13','operation'=>'restore_record']];
p13($engine->evaluate($co,$cap,$approved)->allowed,'Co-Managed executes after matching explicit approval');

$controlled=$profiles->create(ClientAuthorityProfileType::CLIENT_CONTROLLED,'company-13','agreement-13');
p13(!$engine->evaluate($controlled,$cap,$baseReq)->allowed,'Client Controlled blocks execution without client approval');
p13($engine->evaluate($controlled,$cap,$approved)->allowed,'Client Controlled allows explicitly approved execution');

$restricted=$profiles->create(ClientAuthorityProfileType::RESTRICTED,'company-13','agreement-13',[
 'allowed_target_types'=>['database'],'allowed_operations'=>['restore_record'],'allowed_action_classes'=>['recovery']
]);
p13($engine->evaluate($restricted,$cap,$baseReq)->allowed,'Restricted permits only explicitly allowlisted target/effect/action class');
$badOp=$baseReq; $badOp['operation']='verify_integrity';
p13(!$engine->evaluate($restricted,$cap,$badOp)->allowed,'Restricted rejects non-allowlisted operation');

$observe=$profiles->create(ClientAuthorityProfileType::OBSERVATION_ONLY,'company-13','agreement-13');
p13(!$engine->evaluate($observe,$cap,$baseReq)->allowed,'Observation Only structurally blocks recovery/mutation');
$obsReq=$baseReq; $obsReq['operation']='verify_integrity'; $obsReq['action_class']='diagnostic';
p13($engine->evaluate($observe,$cap,$obsReq)->allowed,'Observation Only permits diagnostic observation');

$cross=$profiles->create(ClientAuthorityProfileType::TITAN_MANAGED,'company-999','agreement-13');
p13(!$engine->evaluate($cross,$cap,$baseReq)->allowed,'client profile cannot cross company_id boundary');

$wrongBasis=$profiles->create(ClientAuthorityProfileType::TITAN_MANAGED,'company-13','different-agreement');
p13(!$engine->evaluate($wrongBasis,$cap,$baseReq)->allowed,'profile authority basis must match capability authority basis');

$tampered=$managed; $tampered['profile_type']=ClientAuthorityProfileType::OBSERVATION_ONLY;
p13(!$engine->evaluate($tampered,$cap,$baseReq)->allowed,'tampered client authority profile fails integrity verification');

echo "T0GM client authority profile tests: PASS\n";
