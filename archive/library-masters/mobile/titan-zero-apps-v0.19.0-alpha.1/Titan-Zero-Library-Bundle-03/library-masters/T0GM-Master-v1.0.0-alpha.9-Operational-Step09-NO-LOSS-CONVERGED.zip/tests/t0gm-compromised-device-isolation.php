<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Identity\T0gmDeviceIsolationRegistry;
use Titan\GodMode\Identity\T0gmDeviceTrustRegistry;
use Titan\GodMode\Continuance\AuthorityContinuanceEngine;
use Titan\GodMode\Continuance\AuthorityContinuanceOutcome;

function isoAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function isoExpect(string $contains,callable $fn):void{try{$fn();}catch(Throwable $e){isoAssert(str_contains($e->getMessage(),$contains),"expected $contains got {$e->getMessage()}");return;}throw new RuntimeException("expected failure:$contains");}

$now=time();
$principal='OWNER_CONTROL_PLANE_PRINCIPAL';
$a=random_bytes(32); $b=random_bytes(32);
$isolation=new T0gmDeviceIsolationRegistry([
 'device-b'=>['principal_id'=>$principal,'binding_id'=>'bind-b','status'=>'quarantined','quarantined_at'=>$now-5,'reason'=>'suspected-key-compromise','evidence_ref'=>'incident-77'],
]);
$devices=new T0gmDeviceTrustRegistry([
 'device-a'=>['principal_id'=>$principal,'device_public_key_hash'=>hash('sha256',$a),'binding_id'=>'bind-a','status'=>'active','bound_from'=>$now-3600],
 'device-b'=>['principal_id'=>$principal,'device_public_key_hash'=>hash('sha256',$b),'binding_id'=>'bind-b','status'=>'active','bound_from'=>$now-3600],
],$isolation);

$healthy=$devices->bindingForCurrentUse('device-a',$principal,$a,$now);
isoAssert($healthy['binding_id']==='bind-a','healthy sibling remains available');
isoExpect('device-binding-quarantined',fn()=>$devices->bindingForCurrentUse('device-b',$principal,$b,$now));
$history=$devices->bindingForHistoricalVerification('device-b',$principal,$b,$now-30);
isoAssert($history['binding_id']==='bind-b','pre-quarantine evidence remains verifiable');
isoExpect('device-binding-quarantined-at',fn()=>$devices->bindingForHistoricalVerification('device-b',$principal,$b,$now));

$q=$isolation->quarantineFor('device-b',$principal,'bind-b',$now);
isoAssert($q['status']==='quarantined','quarantine state is visible');
isoAssert($q['reason']==='suspected-key-compromise','quarantine reason retained');
isoAssert(($q['destroys_sovereign_identity']??true)===false,'quarantine cannot destroy sovereign identity');
isoAssert(($q['company_authority_embedded']??true)===false,'quarantine does not create company authority');
isoAssert(($q['blocks_current_device_use']??false)===true,'quarantine blocks current device use');
isoAssert($isolation->quarantineFor('device-a',$principal,'bind-a',$now)===null,'healthy sibling has no inherited quarantine');

$facts=$isolation->continuanceFactsFor('device-b',$principal,'bind-b',$now);
isoAssert($facts['device_quarantined']===true,'quarantine exports a continuance termination fact');
$engine=new AuthorityContinuanceEngine();
// The isolation fact is consumed by the live continuance layer before any device-originated authority can continue.
$reflection=new ReflectionClass($engine);
isoAssert($facts['device_isolation_evidence_ref']==='incident-77','continuance fact keeps incident evidence reference');


isoExpect('device-isolation-binding-mismatch',fn()=>new T0gmDeviceIsolationRegistry([
 'device-b'=>['principal_id'=>$principal,'binding_id'=>'wrong-bind','status'=>'quarantined','quarantined_at'=>$now-5],
])->quarantineFor('device-b',$principal,'bind-b',$now));

echo "PASS compromised device is immediately quarantined without destroying T0GM identity\n";
echo "PASS healthy sibling devices do not inherit compromised-device isolation\n";
echo "PASS pre-quarantine device evidence remains historically verifiable\n";
echo "PASS quarantine remains isolation evidence, not company or execution authority\n";
