<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\Adapter\TargetAdapterRegistry;
use Titan\GodMode\Adapter\TargetAdapterRouter;
use Titan\GodMode\Capability\SovereignCapabilityFactory;
use Titan\GodMode\Policy\ClientAuthorityProfileFactory;
use Titan\GodMode\Policy\ClientAuthorityProfileType;

function a12(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); echo "PASS $message\n"; }

$factory = new SovereignCapabilityFactory();
$router = new TargetAdapterRouter();
$registry = new TargetAdapterRegistry();

$baseRisk = ['score'=>20,'financial_exposure'=>10,'physical_impact'=>5,'environmental_impact'=>5,'band'=>'low'];
function capFor(SovereignCapabilityFactory $factory, string $type, string $id, string $system, string $operation, string $resource='r1'): array {
    $extinction = [];
    foreach (['purpose_invalid','authority_revoked','company_changed','target_changed','risk_constraint_breached','safety_interlock','superseded','t0gm_extinguish'] as $ext) {
        $extinction[] = ['condition_id'=>'ext-'.$ext,'condition_type'=>$ext,'description'=>'Extinguish when '.$ext];
    }
    return $factory->create([
        'authority_holder' => ['authority_class'=>'titan.god_mode','identity_id'=>'t0gm_jason','actor_type'=>'human'],
        'authority_basis' => ['basis_type'=>'platform_owner','basis_id'=>'basis-1','description'=>'Titan-managed bounded adapter authority'],
        'company_id' => 'company-1',
        'purpose' => ['purpose_id'=>'purpose-1','statement'=>'bounded recovery','intended_outcome'=>'target restored or inspected safely'],
        'target' => ['target_type'=>$type,'target_id'=>$id,'system'=>$system,'environment'=>'production','resource_ids'=>[$resource]],
        'permitted_effects' => [['effect_id'=>'effect-1','operation'=>$operation,'resource_type'=>'bounded_resource','resource_ids'=>[$resource]]],
        'prohibited_effects' => [['operation'=>'delete_everything','reason'=>'unbounded destructive effect forbidden']],
        'evidence' => [['evidence_id'=>'ev-1','evidence_type'=>'incident','source'=>'t0gm-feed','integrity_ref'=>'sha256:adapter-test']],
        'risk_constraints' => ['max_risk_score'=>60,'max_financial_exposure'=>60,'max_physical_impact'=>60,'max_environmental_impact'=>60,'prohibited_risk_bands'=>['extreme']],
        'extinction_conditions' => $extinction,
    ]);
}
function req(array $cap, string $operation, string $resource='r1', array $parameters=[]): array {
    $profile=(new ClientAuthorityProfileFactory())->create(ClientAuthorityProfileType::TITAN_MANAGED,'company-1','basis-1');
    return [
        'company_id'=>'company-1','target'=>$cap['target'],'operation'=>$operation,'resource_id'=>$resource,
        'risk'=>['score'=>20,'financial_exposure'=>10,'physical_impact'=>5,'environmental_impact'=>5,'band'=>'low'],
        'evidence_ids'=>['ev-1'],'triggered_extinction_conditions'=>[], 'parameters'=>$parameters,
        'action_class'=>'mutation','client_authority_profile'=>$profile,
        'correlation_id'=>'corr-12'
    ];
}

a12($registry->types() === ['laravel_application','database','linux_server','browser_pwa','cloud_api','ai_worker_control'], 'initial six adapter types registered');

$cases = [
    ['laravel_application','app-1','laravel','clear_cache','laravel_control_plane',[]],
    ['database','db-1','postgresql','verify_integrity','database_native_protocol',[]],
    ['linux_server','host-1','linux','read_logs','linux_native_management',[]],
    ['browser_extension','ext-1','chrome','collect_diagnostics','titan_browser_bridge',[]],
    ['cloud_api','vm-1','aws','read_health','cloud_provider_api',[]],
    ['ai_worker','worker-1','titan-ai','pause_worker','titan_ai_worker_control_plane',[]],
];
foreach ($cases as [$type,$id,$system,$op,$transport,$params]) {
    $cap = capFor($factory,$type,$id,$system,$op);
    $result = $router->prepare($cap, req($cap,$op,'r1',$params));
    a12($result->allowed, "$type capability translated");
    a12(($result->nativeOperation['transport'] ?? null) === $transport, "$type native transport selected");
    a12(($result->authorityLineage['capability_id'] ?? null) === $cap['capability_id'], "$type retains capability lineage");
}

$db = capFor($factory,'database','db-1','postgresql','restore_record');
$r = $router->prepare($db, req($db,'restore_record','r1',['sql'=>'UPDATE users SET role=\'admin\'']));
a12(!$r->allowed && in_array('raw_sql_not_accepted_by_sovereign_adapter',$r->reasons,true), 'database adapter rejects raw SQL');

$linux = capFor($factory,'linux_server','host-1','linux','apply_named_remediation');
$r = $router->prepare($linux, req($linux,'apply_named_remediation','r1',['command'=>'rm -rf /']));
a12(!$r->allowed && in_array('arbitrary_shell_not_accepted_by_sovereign_adapter',$r->reasons,true), 'linux adapter rejects arbitrary shell');

$cloud = capFor($factory,'cloud_api','vm-1','aws','read_health');
$r = $router->prepare($cloud, req($cloud,'read_health','r1',['secret'=>'x']));
a12(!$r->allowed && in_array('embedded_cloud_credentials_forbidden',$r->reasons,true), 'cloud adapter rejects embedded credentials');

$worker = capFor($factory,'ai_worker','worker-1','titan-ai','replace_worker_policy');
$r = $router->prepare($worker, req($worker,'replace_worker_policy','r1',['increase_authority'=>true]));
a12(!$r->allowed && in_array('ai_worker_authority_mutation_forbidden',$r->reasons,true), 'AI adapter cannot increase worker authority');

$cross = capFor($factory,'database','db-1','postgresql','verify_integrity');
$bad = req($cross,'verify_integrity'); $bad['company_id'] = 'company-2';
$r = $router->prepare($cross,$bad);
a12(!$r->allowed, 'cross-company adapter execution denied');

$unsupported = capFor($factory,'windows_server','win-1','windows','read_health');
$r = $router->prepare($unsupported, req($unsupported,'read_health'));
a12(!$r->allowed && in_array('no_target_adapter',$r->reasons,true), 'future target types fail closed until adapter exists');

echo "Target adapter tests complete\n";
