<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Identity\T0gmCryptoSuiteRegistry;
use Titan\GodMode\Runtime\T0gmRuntimeIntegrityPolicyRegistry;
use Titan\GodMode\Runtime\T0gmRuntimeIntegrityTrustStore;
use Titan\GodMode\Runtime\T0gmRuntimeIntegrityVerifier;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Support\InMemoryNonceStore;

function riaAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function riaExpect(string $contains,callable $fn):void{try{$fn();}catch(Throwable $e){riaAssert(str_contains($e->getMessage(),$contains),"expected $contains got {$e->getMessage()}");return;}throw new RuntimeException("expected failure:$contains");}
function riaSign(array $payload,string $secret):string{return base64_encode(sodium_crypto_sign_detached(CanonicalJson::encode($payload),$secret));}

$now=time();
$issuer=sodium_crypto_sign_keypair();$issuerSecret=sodium_crypto_sign_secretkey($issuer);$issuerPublic=sodium_crypto_sign_publickey($issuer);
$policy=new T0gmRuntimeIntegrityPolicyRegistry([
 'titan://service/prod/billing'=>[
   'policy_id'=>'runtime-policy-billing-v3','workload_class'=>'service','policy_revision'=>3,'status'=>'active',
   'trusted_code_digests'=>['sha256:code-release-17'],
   'trusted_config_digests'=>['sha256:config-prod-09'],
   'trusted_environment_digests'=>['sha256:php8.4-linux-hardened'],
   'required_claims'=>['debug_disabled'=>true,'unsigned_modules'=>false],
 ]
]);
$trust=new T0gmRuntimeIntegrityTrustStore(['runtime-attestor-01'=>['suite'=>'ed25519','public_key'=>base64_encode($issuerPublic),'purposes'=>['runtime_integrity_attestation']]]);
$verifier=new T0gmRuntimeIntegrityVerifier($policy,$trust,new T0gmCryptoSuiteRegistry(),new InMemoryNonceStore());

$make=function(string $code,string $config,string $env,string $nonce,array $claims=['debug_disabled'=>true,'unsigned_modules'=>false])use($now,$issuerSecret):array{
 $payload=[
  'schema'=>'titan.t0gm.runtime_integrity_attestation.v1','workload_id'=>'titan://service/prod/billing','workload_class'=>'service',
  'workload_binding_id'=>'wbind-service','policy_id'=>'runtime-policy-billing-v3','policy_revision'=>3,
  'code_digest'=>$code,'config_digest'=>$config,'environment_digest'=>$env,'runtime_claims'=>$claims,
  'nonce'=>$nonce,'issued_at'=>$now,'evidence_expires_at'=>$now+90,
  'network_observation'=>['hostname'=>'billing-1','ip'=>'10.20.0.44'],'non_authority_evidence'=>true,
 ];
 return ['payload'=>$payload,'attestor_key_id'=>'runtime-attestor-01','signature_suite'=>'ed25519','signature'=>riaSign($payload,$issuerSecret)];
};

$receipt=$verifier->verify($make('sha256:code-release-17','sha256:config-prod-09','sha256:php8.4-linux-hardened',bin2hex(random_bytes(24))),[
 'workload_id'=>'titan://service/prod/billing','workload_class'=>'service','binding_id'=>'wbind-service','cryptographic_workload_identity'=>true
],$now);
riaAssert($receipt['runtime_integrity_valid']===true,'trusted runtime accepted');
riaAssert($receipt['policy_id']==='runtime-policy-billing-v3' && $receipt['policy_revision']===3,'policy revision bound');
riaAssert($receipt['network_location_trusted']===false,'network remains observation only');
riaAssert($receipt['authority_granted']===false && $receipt['company_authority_granted']===false && $receipt['t0gm_authority_granted']===false,'integrity evidence grants no authority');

riaExpect('runtime-code-digest-untrusted',fn()=>$verifier->verify($make('sha256:tampered-code','sha256:config-prod-09','sha256:php8.4-linux-hardened',bin2hex(random_bytes(24))),['workload_id'=>'titan://service/prod/billing','workload_class'=>'service','binding_id'=>'wbind-service','cryptographic_workload_identity'=>true],$now));
riaExpect('runtime-config-digest-untrusted',fn()=>$verifier->verify($make('sha256:code-release-17','sha256:tampered-config','sha256:php8.4-linux-hardened',bin2hex(random_bytes(24))),['workload_id'=>'titan://service/prod/billing','workload_class'=>'service','binding_id'=>'wbind-service','cryptographic_workload_identity'=>true],$now));
riaExpect('runtime-environment-digest-untrusted',fn()=>$verifier->verify($make('sha256:code-release-17','sha256:config-prod-09','sha256:unknown-runtime',bin2hex(random_bytes(24))),['workload_id'=>'titan://service/prod/billing','workload_class'=>'service','binding_id'=>'wbind-service','cryptographic_workload_identity'=>true],$now));
riaExpect('runtime-required-claim-mismatch:debug_disabled',fn()=>$verifier->verify($make('sha256:code-release-17','sha256:config-prod-09','sha256:php8.4-linux-hardened',bin2hex(random_bytes(24)),['debug_disabled'=>false,'unsigned_modules'=>false]),['workload_id'=>'titan://service/prod/billing','workload_class'=>'service','binding_id'=>'wbind-service','cryptographic_workload_identity'=>true],$now));
riaExpect('runtime-workload-binding-mismatch',fn()=>$verifier->verify($make('sha256:code-release-17','sha256:config-prod-09','sha256:php8.4-linux-hardened',bin2hex(random_bytes(24))),['workload_id'=>'titan://service/prod/billing','workload_class'=>'service','binding_id'=>'different-binding','cryptographic_workload_identity'=>true],$now));

$replay=$make('sha256:code-release-17','sha256:config-prod-09','sha256:php8.4-linux-hardened',bin2hex(random_bytes(24)));
$verifier->verify($replay,['workload_id'=>'titan://service/prod/billing','workload_class'=>'service','binding_id'=>'wbind-service','cryptographic_workload_identity'=>true],$now);
riaExpect('runtime-integrity-replay-detected',fn()=>$verifier->verify($replay,['workload_id'=>'titan://service/prod/billing','workload_class'=>'service','binding_id'=>'wbind-service','cryptographic_workload_identity'=>true],$now));

echo "PASS runtime code configuration and execution environment require trusted attested state\n";
echo "PASS runtime integrity binds cryptographic workload identity and policy revision\n";
echo "PASS code config environment claim drift and replay fail closed\n";
echo "PASS runtime integrity evidence grants no sovereign or company authority\n";
