<?php
spl_autoload_register(function (string $class): void {
    $prefix = 'Titan\\GodMode\\';
    if (!str_starts_with($class, $prefix)) return;
    $rel = substr($class, strlen($prefix));
    $path = dirname(__DIR__) . '/src/' . str_replace('\\','/',$rel) . '.php';
    if (is_file($path)) require $path;
});
