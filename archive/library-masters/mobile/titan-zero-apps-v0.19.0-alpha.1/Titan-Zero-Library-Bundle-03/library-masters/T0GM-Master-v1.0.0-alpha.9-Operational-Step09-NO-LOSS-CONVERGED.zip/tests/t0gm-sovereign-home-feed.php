<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\App\T0gmSovereignHomeFeed;
use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedException;
use Titan\GodMode\Feed\T0gmFeedIngestor;
use Titan\GodMode\Feed\T0gmLineageFactory;
use Titan\GodMode\Ranking\T0gmHomeFeedRanker;
use Titan\GodMode\Store\InMemorySovereignActivityStore;

function hfAssert($condition, string $message): void { if (!$condition) throw new RuntimeException('ASSERTION FAILED: '.$message); }
function hfExpect(string $reason, callable $fn): void {
    try { $fn(); } catch (T0gmFeedException $e) { hfAssert($e->reason === $reason, "expected $reason got {$e->reason}"); return; }
    throw new RuntimeException('expected feed failure: '.$reason);
}

$store = new InMemorySovereignActivityStore();
$ingest = new T0gmFeedIngestor($store);
$factory = new T0gmEventFactory();
$lineage = new T0gmLineageFactory();
$feed = new T0gmSovereignHomeFeed($store, new T0gmHomeFeedRanker());
$sovereign = T0gmFeedAccessContext::sovereign('T0GM_OWNER');
$delegated = new T0gmFeedAccessContext('oversight-ai','t0gm.oversight_ai',['company_a'],false);

$make = function(string $id,string $company,string $kind,int $risk,int $consequence,int $anomaly,int $confidence,int $urgency,string $summary) use ($factory,$lineage) {
    return $factory->make(
        $kind,
        ['scope'=>'company','company_id'=>$company],
        ['actor_type'=>'advanced_intelligence','actor_id'=>'ai-'.$company,'authority_class'=>'delegated_ai'],
        ['system'=>'titan','component'=>'home-feed-fixture'],
        ['subject_type'=>'operation','subject_id'=>'subject-'.$id],
        $lineage->create('trace-'.$id,'corr-'.$id,null,[]),
        ['score'=>$risk,'band'=>$risk >= 90 ? 'extreme' : ($risk >= 70 ? 'high' : ($risk >= 40 ? 'medium' : 'low')),'dimensions'=>['operational'=>$risk]],
        ['visibility'=>'t0gm_sovereign','attention_tier'=>$urgency >= 90 ? 'critical' : ($urgency >= 70 ? 'urgent' : 'important'),'review_required'=>$risk >= 60,'review_team'=>['t0gm-oversight']],
        [['evidence_id'=>'evidence-'.$id,'evidence_type'=>'fixture','source'=>'test']],
        array_merge(
            [
                'attention_signals'=>[
                    'significance'=>$consequence,
                    'consequence'=>$consequence,
                    'anomaly'=>$anomaly,
                    'confidence'=>$confidence,
                    'urgency'=>$urgency,
                    'reversibility'=>60,
                    'financial_exposure'=>0,
                    'physical_impact'=>0,
                    'environmental_impact'=>0,
                    'dependency'=>20,
                    'domains'=>['operations'],
                ],
            ],
            $kind === T0gmEventKind::AI_DECISION
                ? ['decision'=>['decision_id'=>'decision-'.$id,'determination'=>$summary,'reason_codes'=>['FIXTURE']]]
                : ($kind === T0gmEventKind::ANOMALY
                    ? ['anomaly'=>['anomaly_type'=>'fixture-anomaly','summary'=>$summary,'confidence'=>$confidence]]
                    : ['observation'=>['summary'=>$summary,'confidence'=>$confidence]])
        ),
        $id,
        '2026-09-04T07:08:00Z',
        '2026-09-04T07:08:01Z'
    );
};

$ingest->ingest($make('evt-routine','company_a',T0gmEventKind::OBSERVATION,20,20,5,95,20,'Routine activity'));
$ingest->ingest($make('evt-material','company_b',T0gmEventKind::AI_DECISION,70,95,35,90,80,'Material consequence decision'));
$ingest->ingest($make('evt-anomaly','company_a',T0gmEventKind::ANOMALY,55,65,98,45,85,'Severe anomaly with uncertainty'));

$snapshot = $feed->snapshot($sovereign, 50, 0);
hfAssert($snapshot['schema'] === 'titan.t0gm.sovereign_home_feed.v1','home feed schema');
hfAssert($snapshot['sovereign_scope'] === true,'home feed is sovereign scoped');
hfAssert($snapshot['execution_authority_granted'] === false,'feed projection grants no execution authority');
hfAssert(count($snapshot['items']) === 3,'sovereign home feed sees all governed company activity');
hfAssert($snapshot['items'][0]['rank']['score'] >= $snapshot['items'][1]['rank']['score'],'feed sorted descending by rank');
hfAssert(array_keys($snapshot['items'][0]['rank']['factors']) === ['risk','consequence','anomaly','confidence','urgency'],'explicit five-factor rank contract');
hfAssert(in_array('evt-material',array_column($snapshot['items'],'event_id'),true),'material event included');
hfAssert(in_array('evt-anomaly',array_column($snapshot['items'],'event_id'),true),'anomaly event included');
hfAssert($snapshot['next_sequence'] === 3,'cursor advances to latest visible sequence');
hfAssert(($snapshot['audit_head']['audit_sequence'] ?? null) === 3,'snapshot exposes audit head evidence');

$material = current(array_filter($snapshot['items'], fn($i) => $i['event_id'] === 'evt-material'));
hfAssert($material['rank']['factors']['consequence'] === 95,'consequence is explicit, not hidden as significance');
hfAssert($material['company_id'] === 'company_b','company context retained');
hfAssert(count($material['evidence']) === 1,'evidence references retained');

$anomaly = current(array_filter($snapshot['items'], fn($i) => $i['event_id'] === 'evt-anomaly'));
hfAssert($anomaly['rank']['factors']['anomaly'] === 98,'anomaly factor retained');
hfAssert($anomaly['rank']['factors']['confidence'] === 45,'confidence factor retained');
hfAssert($anomaly['rank']['confidence_concern'] === 55,'confidence concern is explainable');

$delta = $feed->snapshot($sovereign, 50, $snapshot['next_sequence']);
hfAssert($delta['items'] === [],'live cursor returns no already-seen items');
$ingest->ingest($make('evt-new','company_a',T0gmEventKind::OBSERVATION,80,85,40,88,92,'New urgent activity'));
$live = $feed->snapshot($sovereign, 50, $snapshot['next_sequence']);
hfAssert(count($live['items']) === 1 && $live['items'][0]['event_id'] === 'evt-new','live cursor returns only newly appended governed activity');
hfAssert($live['next_sequence'] === 4,'live cursor advances after new activity');

hfExpect('sovereign-home-feed-required', fn() => $feed->snapshot($delegated, 10, 0));
hfAssert($store->verifyAuditLineage(),'home feed projection never mutates sovereign activity store');

foreach ($snapshot['items'] as $item) {
    hfAssert(!isset($item['authority_granted']) || $item['authority_granted'] === false,'feed item cannot grant authority');
}

echo "PASS sovereign all-activity home feed projection\n";
echo "PASS explicit risk/consequence/anomaly/confidence/urgency ranking\n";
echo "PASS live sequence cursor without replay\n";
echo "PASS evidence/company context retention\n";
echo "PASS delegated readers denied sovereign home feed\n";
echo "PASS projection-only authority and immutable audit lineage\n";
