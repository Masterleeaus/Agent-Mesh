<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Identity\T0gmCryptoAgilityRegistry;
use Titan\GodMode\Identity\T0gmCryptoProfileRegistry;
use Titan\GodMode\Identity\T0gmVerifierTrustStore;
use Titan\GodMode\Event\T0gmEventProvenanceTrustStore;
use Titan\GodMode\Security\GodModeException;

function krAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function krExpect(string $contains,callable $fn):void{try{$fn();}catch(Throwable $e){krAssert(str_contains($e->getMessage(),$contains),"expected $contains got {$e->getMessage()}");return;}throw new RuntimeException("expected failure:$contains");}

$old=sodium_crypto_sign_keypair();$new=sodium_crypto_sign_keypair();
$oldPub=base64_encode(sodium_crypto_sign_publickey($old));$newPub=base64_encode(sodium_crypto_sign_publickey($new));
$trust=new T0gmVerifierTrustStore([
 'old'=>['suite'=>'ed25519','public_key'=>$oldPub,'status'=>'retired','trusted_from'=>100,'retired_at'=>200],
 'new'=>['suite'=>'ed25519','public_key'=>$newPub,'status'=>'active','trusted_from'=>200],
]);
krAssert($trust->keyForVerification('old',150)['suite']==='ed25519','retired key verifies historical evidence from trusted interval');
krExpect('verifier-key-not-trusted-at',fn()=>$trust->keyForVerification('old',250));
krAssert($trust->keyForVerification('new',250)['suite']==='ed25519','new key verifies after activation');

$revoked=new T0gmVerifierTrustStore(['bad'=>['suite'=>'ed25519','public_key'=>$oldPub,'status'=>'revoked','trusted_from'=>100,'revoked_at'=>175]]);
krAssert($revoked->keyForVerification('bad',150)['suite']==='ed25519','pre-revocation historical evidence remains verifiable');
krExpect('verifier-key-revoked-at',fn()=>$revoked->keyForVerification('bad',180));

$eventTrust=new T0gmEventProvenanceTrustStore([
 'evt-old'=>['suite'=>'ed25519','public_key'=>sodium_crypto_sign_publickey($old),'purposes'=>['event_provenance'],'status'=>'retired','trusted_from'=>100,'retired_at'=>200],
]);
krAssert($eventTrust->keyForVerification('evt-old',150)['suite']==='ed25519','event evidence keeps historical verification after key retirement');
krExpect('event-provenance-key-not-trusted-at',fn()=>$eventTrust->keyForVerification('evt-old',250));

$profiles=new T0gmCryptoProfileRegistry();
$agility=new T0gmCryptoAgilityRegistry($profiles,T0gmCryptoProfileRegistry::HYBRID_PQC_ZK_MIN_V3,[
 T0gmCryptoProfileRegistry::HYBRID_PQC_V1=>'verify-only',
 T0gmCryptoProfileRegistry::HYBRID_PQC_ZK_V2=>'verify-only',
 T0gmCryptoProfileRegistry::HYBRID_PQC_ZK_MIN_V3=>'active',
]);
krAssert($agility->activeProfile()['profile_id']===T0gmCryptoProfileRegistry::HYBRID_PQC_ZK_MIN_V3,'one active issuance profile selected');
krAssert($agility->verificationProfile(T0gmCryptoProfileRegistry::HYBRID_PQC_V1)['profile_id']===T0gmCryptoProfileRegistry::HYBRID_PQC_V1,'legacy profile remains historical-verification capable');
krExpect('crypto-profile-not-active-for-issuance',fn()=>$agility->issuanceProfile(T0gmCryptoProfileRegistry::HYBRID_PQC_V1));

$authorityBefore=['authority_class'=>'titan.god_mode','company_authority_embedded'=>false,'application_role_authority'=>false];
$authorityAfter=$authorityBefore;
krAssert($authorityAfter===$authorityBefore,'crypto rotation does not change authority semantics');

 echo "PASS retired and rotated keys preserve bounded historical verification\n";
 echo "PASS revoked keys fail from revocation boundary while prior evidence remains inspectable\n";
 echo "PASS crypto profiles can rotate issuance while retaining verify-only historical profiles\n";
 echo "PASS crypto agility does not alter T0GM authority semantics\n";
