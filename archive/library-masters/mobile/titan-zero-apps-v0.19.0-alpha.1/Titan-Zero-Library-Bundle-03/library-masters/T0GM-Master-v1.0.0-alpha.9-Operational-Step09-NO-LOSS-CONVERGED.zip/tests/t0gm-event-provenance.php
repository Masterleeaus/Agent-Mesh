<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Contracts\SovereignActivityStore;
use Titan\GodMode\Custody\SovereignKeyCustodyPolicy;
use Titan\GodMode\Custody\SovereignKeyCustodyProvider;
use Titan\GodMode\Custody\SovereignKeyCustodyRegistry;
use Titan\GodMode\Custody\SovereignKeyHandle;
use Titan\GodMode\Custody\SovereignSigningService;
use Titan\GodMode\Event\T0gmCanonicalHasher;
use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Event\T0gmEventProvenanceSigner;
use Titan\GodMode\Event\T0gmEventProvenanceTrustStore;
use Titan\GodMode\Event\T0gmEventProvenanceVerifier;
use Titan\GodMode\Feed\T0gmFeedException;
use Titan\GodMode\Feed\T0gmFeedIngestor;
use Titan\GodMode\Identity\T0gmCryptoSuiteRegistry;
use Titan\GodMode\Security\GodModeException;
use Titan\GodMode\Store\InMemorySovereignActivityStore;

function epAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function epExpect(string $contains,callable $fn):void{try{$fn();}catch(Throwable $e){epAssert(str_contains($e->getMessage(),$contains),"expected $contains got {$e->getMessage()}");return;}throw new RuntimeException("expected failure:$contains");}

final class EventHardwareProvider implements SovereignKeyCustodyProvider {
    public function __construct(private string $id,private string $pub,private string $sec){}
    public function providerId(): string{return $this->id;}
    public function describe(string $keyId): SovereignKeyHandle{return new SovereignKeyHandle($keyId,'ed25519',$this->id,'hsm','event-signing-hsm',$this->pub,true,false,['event_provenance'],hash('sha256','event-signing-attestation'));}
    public function sign(string $keyId,string $suite,string $message,array $context=[]): string { if(($context['purpose']??null)!=='event_provenance')throw new GodModeException('wrong-event-signing-purpose'); return sodium_crypto_sign_detached($message,$this->sec); }
}

$kp=sodium_crypto_sign_keypair();$pub=sodium_crypto_sign_publickey($kp);$sec=sodium_crypto_sign_secretkey($kp);
$provider=new EventHardwareProvider('event-hsm',$pub,$sec);
$signing=new SovereignSigningService(new SovereignKeyCustodyRegistry([$provider]),new SovereignKeyCustodyPolicy(requireDistinctCustodyDomains:false));
$hasher=new T0gmCanonicalHasher();
$provSigner=new T0gmEventProvenanceSigner($signing,$hasher);
$trust=new T0gmEventProvenanceTrustStore(['evt-key-1'=>['suite'=>'ed25519','public_key'=>$pub,'purposes'=>['event_provenance'],'provider_id'=>'event-hsm']]);
$verifier=new T0gmEventProvenanceVerifier($trust,new T0gmCryptoSuiteRegistry(),$provSigner);

$factory=new T0gmEventFactory();
$event=$factory->make(
    T0gmEventKind::AI_DECISION,
    ['scope'=>'company','company_id'=>'company-alpha'],
    ['actor_type'=>'advanced_intelligence','actor_id'=>'finance-ai','authority_class'=>'delegated_ai'],
    ['system'=>'titan.ai-workforce','component'=>'finance-reviewer'],
    ['subject_type'=>'invoice','subject_id'=>'inv-7'],
    ['trace_id'=>'trace-7','correlation_id'=>'corr-7','causation_id'=>'evt-parent','parent_event_ids'=>['evt-parent']],
    ['score'=>78,'band'=>'high','dimensions'=>['financial'=>78]],
    ['visibility'=>'t0gm_sovereign','attention_tier'=>'important','review_required'=>true,'review_state'=>'independent-review'],
    [['evidence_id'=>'evidence-7','evidence_type'=>'ledger_snapshot','source'=>'finance-ledger','hash'=>hash('sha256','snapshot')]],
    ['decision'=>['decision_id'=>'decision-7','determination'=>'hold-payment','reason_codes'=>['anomaly']]],
    'evt-signed-7'
);
$sealed=$hasher->seal($event);
$signed=$provSigner->sign($sealed,[['provider_id'=>'event-hsm','key_id'=>'evt-key-1']],['ed25519']);
epAssert($verifier->verify($signed,['ed25519']),'valid provenance verifies');
epAssert($signed['provenance']['semantics']['grants_authority']===false,'signature grants no authority');
epAssert(!isset($signed['authority']),'signing does not invent authority section');

$store=new InMemorySovereignActivityStore();
$ingestor=new T0gmFeedIngestor($store,new \Titan\GodMode\Event\T0gmEventValidator(),$hasher,$verifier,true,['ed25519']);
$record=$ingestor->ingest($signed);
epAssert($record['event_id']==='evt-signed-7','signed event ingested');

epExpect('event-provenance-required',fn()=>$ingestor->ingest($sealed));

$tampered=$signed;$tampered['decision']['determination']='release-payment';$tampered=$hasher->seal($tampered);
epExpect('event-provenance-invalid',fn()=>$ingestor->ingest($tampered));

$fakeLineage=$signed;$fakeLineage['lineage']['parent_event_ids'][]='fabricated-parent';$fakeLineage=$hasher->seal($fakeLineage);
epExpect('event-provenance-invalid',fn()=>$ingestor->ingest($fakeLineage));

$fakeEvidence=$signed;$fakeEvidence['evidence'][0]['evidence_id']='fabricated-evidence';$fakeEvidence=$hasher->seal($fakeEvidence);
epExpect('event-provenance-invalid',fn()=>$ingestor->ingest($fakeEvidence));

$other=sodium_crypto_sign_keypair();
$untrusted=new T0gmEventProvenanceTrustStore(['other-key'=>['suite'=>'ed25519','public_key'=>sodium_crypto_sign_publickey($other),'purposes'=>['event_provenance']]]);
$badVerifier=new T0gmEventProvenanceVerifier($untrusted,new T0gmCryptoSuiteRegistry(),$provSigner);
epExpect('untrusted-event-provenance-key',fn()=>$badVerifier->verify($signed,['ed25519']));

echo "PASS signed event provenance verifies against deployment trust store\n";
echo "PASS recomputed hashes cannot hide decision, lineage or evidence tampering\n";
echo "PASS production ingestion can fail closed on unsigned sovereign events\n";
echo "PASS provenance signatures attest integrity without creating execution authority\n";
