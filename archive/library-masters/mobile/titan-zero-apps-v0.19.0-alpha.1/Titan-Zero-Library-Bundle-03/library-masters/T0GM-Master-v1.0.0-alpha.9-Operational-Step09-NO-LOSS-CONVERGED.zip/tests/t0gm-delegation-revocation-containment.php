<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\Delegation\T0gmDelegatedCapabilityRegistry;
use Titan\GodMode\Delegation\T0gmDelegationRevocationContainmentService;

function drA($c,$m){if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);} function drT($f,$contains,$m){try{$f();}catch(Throwable $e){if($contains===''||str_contains($e->getMessage(),$contains))return;throw $e;}throw new RuntimeException('ASSERTION FAILED: '.$m);}

$registry=new T0gmDelegatedCapabilityRegistry();
$delegated=$registry->register([
 'delegation_id'=>'del-1','issuer_authority_class'=>'titan.god_mode','issuer_identity_id'=>'t0gm-human-1',
 'recipient'=>['recipient_type'=>'advanced_intelligence','recipient_id'=>'ai-finance-7'],
 'company_id'=>'company-a','target'=>['target_type'=>'database','target_id'=>'ledger-prod'],
 'purpose'=>['purpose_id'=>'p-1','statement'=>'Reconcile duplicate invoice'],
 'permitted_effects'=>[['effect_id'=>'read-invoice','operation'=>'invoice.read'],['effect_id'=>'mark-duplicate','operation'=>'invoice.mark_duplicate']],
 'prohibited_effects'=>[['operation'=>'invoice.delete','reason'=>'destructive action excluded']],
 'conditions'=>['risk_acceptable'=>true,'runtime_integrity_required'=>true],
 'evidence_requirements'=>['execution_receipt','post_state'],
 'sovereignty_transferred'=>false,'recipient_may_delegate'=>false,'recipient_may_expand_authority'=>false,
]);
drA($delegated['status']==='active','delegation starts active');
drA($delegated['sovereignty_transferred']===false,'delegation never transfers sovereignty');
$registry->recordDependentAction('del-1',['action_id'=>'act-running','company_id'=>'company-a','kind'=>'execution','state'=>'running','reversibility'=>80]);
$registry->recordDependentAction('del-1',['action_id'=>'act-queued','company_id'=>'company-a','kind'=>'execution','state'=>'queued','reversibility'=>70]);
$registry->recordDependentAction('del-1',['action_id'=>'act-done','company_id'=>'company-a','kind'=>'execution','state'=>'completed','reversibility'=>90]);
$registry->recordDependentAction('del-1',['action_id'=>'decision-1','company_id'=>'company-a','kind'=>'decision','state'=>'committed','reversibility'=>10]);
$registry->recordDependentAction('del-1',['action_id'=>'evidence-1','company_id'=>'company-a','kind'=>'evidence','state'=>'recorded','reversibility'=>0]);
$service=new T0gmDelegationRevocationContainmentService($registry);
$receipt=$service->revoke('del-1',[
 'revocation_id'=>'rev-1','revoked_by'=>'t0gm-human-1','reason'=>'recipient trust degraded','world_revision'=>'world-77','observed_at'=>'2026-09-03T02:55:00+10:00'
]);
drA($receipt['revoked']===true,'delegation revoked immediately');
drA($registry->state('del-1')['status']==='revoked','registry records revoked status');
drA($registry->state('del-1')['retained_effect_ids']===[],'no delegated effects survive revocation');
$plan=$receipt['containment'];
drA($plan['act-running']['disposition']==='stop','running dependent execution stopped');
drA($plan['act-queued']['disposition']==='cancel','queued execution cancelled');
drA($plan['act-done']['disposition']==='reverse','completed reversible effect reversed');
drA($plan['decision-1']['disposition']==='recompute','dependent decision recomputed rather than erased');
drA($plan['evidence-1']['disposition']==='preserve','evidence preserved');
drA(($receipt['authority_granted']??true)===false,'revocation receipt grants no authority');
drA(($receipt['t0gm_authority_transferred']??true)===false,'revocation never transfers T0GM sovereignty');
drA(($receipt['containment_complete']??false)===true,'all known dependents get containment disposition');

$again=$service->revoke('del-1',['revocation_id'=>'rev-1','revoked_by'=>'t0gm-human-1','reason'=>'recipient trust degraded','world_revision'=>'world-77','observed_at'=>'2026-09-03T02:55:00+10:00']);
drA($again['revocation_id']==='rev-1','same revocation is idempotent');
drT(fn()=>$service->revoke('del-1',['revocation_id'=>'rev-2','revoked_by'=>'other','reason'=>'different','world_revision'=>'world-78','observed_at'=>'2026-09-03T02:56:00+10:00']),'delegation-already-revoked','conflicting second revocation rejected');
drT(fn()=>$registry->recordDependentAction('del-1',['action_id'=>'late','company_id'=>'company-a','kind'=>'execution','state'=>'queued','reversibility'=>10]),'delegation-revoked','revoked delegation cannot gain new dependent actions');
drT(fn()=>$registry->register(['delegation_id'=>'bad','issuer_authority_class'=>'titan.god_mode','issuer_identity_id'=>'t0gm-human-1','recipient'=>['recipient_type'=>'service','recipient_id'=>'svc'], 'company_id'=>'company-a','target'=>['target_type'=>'api','target_id'=>'x'],'purpose'=>['purpose_id'=>'p','statement'=>'x'],'permitted_effects'=>[['effect_id'=>'x','operation'=>'x']], 'prohibited_effects'=>[],'conditions'=>[],'evidence_requirements'=>[],'sovereignty_transferred'=>true,'recipient_may_delegate'=>false,'recipient_may_expand_authority'=>false]),'delegation-sovereignty-transfer-forbidden','sovereignty transfer forbidden');
drT(fn()=>$registry->register(['delegation_id'=>'bad2','issuer_authority_class'=>'titan.god_mode','issuer_identity_id'=>'t0gm-human-1','recipient'=>['recipient_type'=>'service','recipient_id'=>'svc'], 'company_id'=>'company-a','tenant_id'=>'legacy','target'=>['target_type'=>'api','target_id'=>'x'],'purpose'=>['purpose_id'=>'p','statement'=>'x'],'permitted_effects'=>[['effect_id'=>'x','operation'=>'x']], 'prohibited_effects'=>[],'conditions'=>[],'evidence_requirements'=>[],'sovereignty_transferred'=>false,'recipient_may_delegate'=>false,'recipient_may_expand_authority'=>false]),'legacy-tenant-boundary-forbidden','legacy tenant boundary forbidden');

echo "PASS delegation revocation instantly removes delegated effects\nPASS dependent running/queued/completed actions receive causal containment dispositions\nPASS decisions are recomputed, evidence preserved, and authority is never transferred\nPASS revocation is idempotent and revoked delegations cannot silently reactivate\n";
