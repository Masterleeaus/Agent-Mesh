<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\Workforce\T0gmCanonicalAiWorkforceRegistry;
use Titan\GodMode\Workforce\T0gmAiWorkforceCapabilityManifest;
use Titan\GodMode\Security\GodModeException;
function cmAssert($c,$m){if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);}
$registry=new T0gmCanonicalAiWorkforceRegistry();
$registry->register(['registry_id'=>'model-1','company_id'=>'co1','kind'=>'model','name'=>'M','provider'=>'p','model_ref'=>'m']);
$registry->register(['registry_id'=>'worker-1','company_id'=>'co1','kind'=>'worker','name'=>'W','model_ids'=>['model-1']]);
$m=new T0gmAiWorkforceCapabilityManifest($registry);
$r=$m->define('co1','worker-1',[
 'observe'=>['crm.customer.read','finance.invoice.read'],
 'reason'=>['revenue.analyse'],
 'recommend'=>['revenue.recommend_followup'],
 'request'=>['workflow.request_start'],
 'execute'=>['notification.send'],
 'constraints'=>['max_risk'=>40,'requires_attestation'=>true],
 'issued_by'=>'t0gm-policy',
 'revision'=>1
]);
cmAssert($r['capabilities']['observe']===['crm.customer.read','finance.invoice.read'],'observe');
cmAssert($m->allows('co1','worker-1','observe','crm.customer.read')===true,'allow observe');
cmAssert($m->allows('co1','worker-1','execute','workflow.request_start')===false,'request not execute');
cmAssert($r['self_modifiable']===false && $r['authority_self_escalation_allowed']===false,'no self escalation');
cmAssert($r['execution_requires_governed_authorization']===true,'execute still governed');
try{$m->define('co1','worker-1',['observe'=>[],'reason'=>[],'recommend'=>[],'request'=>[],'execute'=>[],'issued_by'=>'worker-1','revision'=>2]);throw new RuntimeException('self-issued accepted');}catch(GodModeException $e){cmAssert($e->getMessage()==='ai-capability-manifest-self-issuance-forbidden','self issuance');}
try{$m->define('co1','worker-1',['tenant_id'=>'legacy','observe'=>[],'reason'=>[],'recommend'=>[],'request'=>[],'execute'=>[],'issued_by'=>'t0gm','revision'=>2]);throw new RuntimeException('legacy accepted');}catch(GodModeException $e){cmAssert(str_contains($e->getMessage(),'legacy-tenant-boundary-forbidden'),'legacy');}
try{$m->define('co1','model-1',['observe'=>[],'reason'=>[],'recommend'=>[],'request'=>[],'execute'=>[],'issued_by'=>'t0gm','revision'=>1]);throw new RuntimeException('model accepted');}catch(GodModeException $e){cmAssert($e->getMessage()==='ai-capability-manifest-worker-required','worker only');}
echo "PASS AI workforce capability manifest separates observe/reason/recommend/request/execute\n";
echo "PASS execute declarations remain subject to governed authorization rather than self-authorizing execution\n";
echo "PASS worker cannot issue or escalate its own manifest and legacy tenant boundaries fail closed\n";
