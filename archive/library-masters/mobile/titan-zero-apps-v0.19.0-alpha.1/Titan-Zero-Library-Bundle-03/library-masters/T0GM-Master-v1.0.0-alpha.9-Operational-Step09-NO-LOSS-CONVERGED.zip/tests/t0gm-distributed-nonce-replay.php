<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Contracts\AtomicNonceBackend;
use Titan\GodMode\Replay\DurableNonceStore;
use Titan\GodMode\Replay\FileAtomicNonceBackend;

function nrAssert(bool $ok,string $message): void { if(!$ok){ throw new RuntimeException('FAIL '.$message); } }
function nrExpect(string $needle, callable $fn): void { try{$fn();}catch(Throwable $e){nrAssert(str_contains($e->getMessage(),$needle),$needle.' got '.$e->getMessage());return;}throw new RuntimeException('FAIL expected '.$needle); }

final class SharedAtomicNonceBackend implements AtomicNonceBackend {
    /** Shared state simulates one strongly-consistent backend observed by regions. */
    public static array $claims=[];
    public function __construct(private string $domain='test-global'){}
    public function claim(string $nonceKey,int $expiresAt,int $claimedAt,array $metadata=[]): bool {
        foreach(self::$claims as $k=>$r){ if($r['expires_at'] <= $claimedAt) unset(self::$claims[$k]); }
        if(isset(self::$claims[$nonceKey])) return false;
        self::$claims[$nonceKey]=['expires_at'=>$expiresAt,'claimed_at'=>$claimedAt,'metadata'=>$metadata];
        return true;
    }
    public function purgeExpired(int $now,int $limit=1000): int { $n=0; foreach(array_keys(self::$claims) as $k){if($n >= $limit)break;if(self::$claims[$k]['expires_at'] <= $now){unset(self::$claims[$k]);$n++;}}return $n; }
    public function consistencyDomain(): string{return $this->domain;}
    public function distributedCapable(): bool{return true;}
}

$now=1788360373;
$clock=static fn(): int=>$now;
$pepper=str_repeat('p',32);
SharedAtomicNonceBackend::$claims=[];
$regionA=new DurableNonceStore(new SharedAtomicNonceBackend('global-store'),'t0gm-global',$pepper,$clock,true);
$regionB=new DurableNonceStore(new SharedAtomicNonceBackend('global-store'),'t0gm-global',$pepper,$clock,true);
$nonce=bin2hex(random_bytes(24));

nrAssert($regionA->consume('device-A:region-au',$nonce,$now+60),'first regional claim succeeds');
nrAssert(!$regionB->consume('device-B:region-us',$nonce,$now+60),'same nonce rejected across device and region namespace');
echo "PASS cross-device/server/region replay rejection\n";

// New DurableNonceStore instance simulates process/server restart and retains backend state.
$restarted=new DurableNonceStore(new SharedAtomicNonceBackend('global-store'),'t0gm-global',$pepper,$clock,true);
nrAssert(!$restarted->consume('fresh-process',$nonce,$now+60),'replay rejected after restart');
echo "PASS restart replay rejection\n";

// Changing the replay domain deliberately creates a separate security domain.
$otherDomain=new DurableNonceStore(new SharedAtomicNonceBackend('global-store'),'separate-test-domain',$pepper,$clock,true);
nrAssert($otherDomain->consume('device-C',$nonce,$now+60),'separate configured replay domain is independent');
echo "PASS replay-domain binding\n";

nrAssert(!$regionA->consume('device-A',bin2hex(random_bytes(24)),$now),'expired proof cannot claim nonce');
nrAssert(!$regionA->consume('',bin2hex(random_bytes(24)),$now+60),'empty namespace rejected');
nrAssert(!$regionA->consume('device-A','tiny',$now+60),'undersized nonce rejected');
echo "PASS invalid replay inputs fail closed\n";

$tmp=sys_get_temp_dir().'/t0gm-nonce-'.bin2hex(random_bytes(6)).'.json';
$fileBackend=new FileAtomicNonceBackend($tmp);
nrExpect('distributed-nonce-backend-required',fn()=>new DurableNonceStore($fileBackend,'t0gm-global',$pepper,$clock,true));
$singleHost1=new DurableNonceStore($fileBackend,'t0gm-global',$pepper,$clock,false);
$fileNonce=bin2hex(random_bytes(24));
nrAssert($singleHost1->consume('local',$fileNonce,$now+60),'file claim succeeds');
$singleHost2=new DurableNonceStore(new FileAtomicNonceBackend($tmp),'t0gm-global',$pepper,$clock,false);
nrAssert(!$singleHost2->consume('local-after-restart',$fileNonce,$now+60),'file backend survives restart');
nrAssert(!str_contains((string)file_get_contents($tmp),$fileNonce),'raw nonce is not persisted');
@unlink($tmp);
echo "PASS contained restart-durable backend and raw-nonce minimization\n";

nrExpect('nonce-digest-pepper-too-short',fn()=>new DurableNonceStore(new SharedAtomicNonceBackend(),'x','short',$clock,true));
echo "PASS replay digest key policy\n";
