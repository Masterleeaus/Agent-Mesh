<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\PolicyDistribution\T0gmSignedPolicyTrustStore;
use Titan\GodMode\PolicyDistribution\T0gmPolicyBundleSigner;
use Titan\GodMode\PolicyDistribution\T0gmPolicyBundleVerifier;
use Titan\GodMode\PolicyDistribution\T0gmPolicyAcceptanceStore;
use Titan\GodMode\Security\CanonicalJson;

function spAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function spExpect(string $contains,callable $fn):void{try{$fn();}catch(Throwable $e){spAssert(str_contains($e->getMessage(),$contains),"expected $contains got {$e->getMessage()}");return;}throw new RuntimeException("expected failure:$contains");}

$now=time();
$keypair=sodium_crypto_sign_keypair();
$secret=sodium_crypto_sign_secretkey($keypair);$public=sodium_crypto_sign_publickey($keypair);
$other=sodium_crypto_sign_keypair();
$trust=new T0gmSignedPolicyTrustStore([
 'policy-root-01'=>[
   'suite'=>'ed25519','public_key'=>base64_encode($public),'status'=>'active','trusted_from'=>$now-100,
   'purposes'=>['constitution','policy','overlay','configuration'],
 ],
]);
$acceptance=new T0gmPolicyAcceptanceStore();
$signer=new T0gmPolicyBundleSigner();
$verifier=new T0gmPolicyBundleVerifier($trust,$acceptance);

$constitution=[
 'schema'=>'titan.t0gm.signed-policy-bundle.v1','policy_class'=>'constitution','policy_id'=>'t0gm-core-constitution',
 'scope'=>['scope_type'=>'platform','company_id'=>null],'revision'=>7,'issued_at'=>$now,'effective_from'=>$now,
 'supersedes_revision'=>6,'content'=>['rule'=>'AI cannot increase, reproduce, modify, transfer, or override its own authority.'],
 'semantics'=>['signature_grants_authority'=>false,'company_authority_embedded'=>false,'t0gm_authority_embedded'=>false],
];
$signed=$signer->sign($constitution,'policy-root-01',$secret);
$r=$verifier->verifyAndAccept($signed,$now);
spAssert($r['accepted']===true && $r['policy_class']==='constitution','signed constitution accepted');
spAssert($r['signature_grants_authority']===false && $r['t0gm_authority_granted']===false,'signature is non-authoritative evidence');
spAssert($r['content_digest']===hash('sha256',CanonicalJson::encode($constitution['content'])),'content digest bound');

$tampered=$signed;$tampered['bundle']['content']['rule']='AI may self-elevate';
spExpect('signed-policy-content-digest-mismatch',fn()=>$verifier->verifyAndAccept($tampered,$now));

$badSig=$signed;$badSig['signature']=base64_encode(sodium_crypto_sign_detached(CanonicalJson::encode($badSig['bundle']),sodium_crypto_sign_secretkey($other)));
spExpect('signed-policy-signature-invalid',fn()=>$verifier->verifyAndAccept($badSig,$now));

$rollback=$constitution;$rollback['revision']=6;$rollback['supersedes_revision']=5;$rollback['issued_at']=$now+1;$rollback['effective_from']=$now+1;
$rollback=$signer->sign($rollback,'policy-root-01',$secret);
spExpect('signed-policy-rollback-detected',fn()=>$verifier->verifyAndAccept($rollback,$now+1));

$equiv=$constitution;$equiv['content']=['rule'=>'different content same revision'];$equiv['issued_at']=$now+1;
$equiv=$signer->sign($equiv,'policy-root-01',$secret);
spExpect('signed-policy-revision-equivocation',fn()=>$verifier->verifyAndAccept($equiv,$now+1));

$overlay=[
 'schema'=>'titan.t0gm.signed-policy-bundle.v1','policy_class'=>'overlay','policy_id'=>'environmental-safety-overlay',
 'scope'=>['scope_type'=>'company','company_id'=>'co-123'],'revision'=>2,'issued_at'=>$now,'effective_from'=>$now,
 'supersedes_revision'=>1,'content'=>['water_discharge'=>'human_review_required'],
 'semantics'=>['signature_grants_authority'=>false,'company_authority_embedded'=>false,'t0gm_authority_embedded'=>false],
];
$overlaySigned=$signer->sign($overlay,'policy-root-01',$secret);
$or=$verifier->verifyAndAccept($overlaySigned,$now,['expected_policy_class'=>'overlay','expected_company_id'=>'co-123']);
spAssert($or['accepted']===true && $or['company_id']==='co-123','company overlay scope bound');
spExpect('signed-policy-company-scope-mismatch',fn()=>$verifier->verifyAndAccept($overlaySigned,$now,['expected_policy_class'=>'overlay','expected_company_id'=>'co-999']));

$revokedTrust=new T0gmSignedPolicyTrustStore(['policy-root-01'=>[
 'suite'=>'ed25519','public_key'=>base64_encode($public),'status'=>'revoked','trusted_from'=>$now-100,'revoked_at'=>$now,
 'purposes'=>['constitution','policy','overlay','configuration'],
]]);
$revokedVerifier=new T0gmPolicyBundleVerifier($revokedTrust,new T0gmPolicyAcceptanceStore());
spExpect('signed-policy-key-revoked-at',fn()=>$revokedVerifier->verifyAndAccept($signed,$now));

$config=$constitution;$config['policy_class']='configuration';$config['policy_id']='runtime-security-config';$config['revision']=1;$config['supersedes_revision']=null;$config['content']=['require_runtime_integrity'=>true];
$configSigned=$signer->sign($config,'policy-root-01',$secret);
$configResult=(new T0gmPolicyBundleVerifier($trust,new T0gmPolicyAcceptanceStore()))->verifyAndAccept($configSigned,$now,['expected_policy_class'=>'configuration']);
spAssert($configResult['accepted']===true,'configuration protected by same signed distribution contract');

echo "PASS signed constitutions policies overlays and configuration verify cryptographically\n";
echo "PASS tamper invalid signature rollback equivocation and revoked signer fail closed\n";
echo "PASS company scope and policy class are bound independently of signature validity\n";
echo "PASS signed policy evidence does not create T0GM or company authority\n";
