<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\Capability\SovereignCapabilityFactory;
use Titan\GodMode\Continuance\AuthorityContinuanceOutcome;
use Titan\GodMode\Live\T0gmActiveCapabilityRegistry;
use Titan\GodMode\Live\T0gmLiveCapabilityReevaluationEngine;
use Titan\GodMode\Live\T0gmWorldStateProvider;

function lrA($c,$m){if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);} function lrT($f,$m){try{$f();}catch(Throwable $e){return;}throw new RuntimeException('ASSERTION FAILED: '.$m);}

$factory=new SovereignCapabilityFactory();
$make=function(string $id,string $company,array $effects=['read','restore']) use($factory){
  $permitted=[]; foreach($effects as $e)$permitted[]=['effect_id'=>$e,'operation'=>'customer.'.$e,'resource_type'=>'customer','resource_ids'=>['customer-9'],'constraints'=>[]];
  return $factory->create([
    'capability_id'=>$id,
    'authority_holder'=>['identity_id'=>'t0gm-human-1','authority_class'=>'titan.god_mode','actor_type'=>'human'],
    'authority_basis'=>['basis_type'=>'titan_managed','basis_id'=>'agreement-7','description'=>'Managed authority'],
    'company_id'=>$company,
    'purpose'=>['purpose_id'=>'recover-1','statement'=>'Recover verified state','intended_outcome'=>'Verified recovery'],
    'target'=>['target_type'=>'database','target_id'=>'crm-prod','system'=>'titan.crm','environment'=>'production','resource_ids'=>['customer-9']],
    'permitted_effects'=>$permitted,
    'prohibited_effects'=>[['operation'=>'customer.delete','reason'=>'outside purpose']],
    'evidence'=>[['evidence_id'=>'ev-1','evidence_type'=>'incident','source'=>'t0gm.feed','integrity_ref'=>'sha256:abc']],
    'risk_constraints'=>['max_risk_score'=>70,'max_financial_exposure'=>20,'max_physical_impact'=>0,'max_environmental_impact'=>0,'prohibited_risk_bands'=>['extreme']],
    'extinction_conditions'=>array_map(fn($t)=>['condition_id'=>'ext-'.$t,'condition_type'=>$t,'description'=>'Extinguish when '.$t],['purpose_invalid','authority_revoked','company_changed','target_changed','risk_constraint_breached','safety_interlock','superseded','t0gm_extinguish']),
  ]);
};

$healthy=function(string $company='company-a'){return [
 'company_id'=>$company,'purpose_valid'=>true,'authority_basis_valid'=>true,'target_valid'=>true,
 'evidence_valid'=>true,'risk_acceptable'=>true,'safety_satisfied'=>true,'contractual_scope_valid'=>true,
 'jurisdiction_valid'=>true,'execution_path_legitimate'=>true,'dependencies_healthy'=>true,
 'runtime_integrity_required'=>true,'runtime_integrity_valid'=>true,'attestation_required'=>true,'attestation_valid'=>true,
 'world_revision'=>'world-1','observed_at'=>'2026-09-03T02:00:00+10:00'
];};

$registry=new T0gmActiveCapabilityRegistry();
$registry->activate($make('cap-a','company-a'));
$registry->activate($make('cap-b','company-b',['read']));
$worlds=['cap-a'=>$healthy('company-a'),'cap-b'=>$healthy('company-b')];
$provider=new class($worlds) implements T0gmWorldStateProvider {
 public function __construct(public array $worlds){}
 public function currentFor(array $capability): array {return $this->worlds[$capability['capability_id']] ?? [];}
};
$engine=new T0gmLiveCapabilityReevaluationEngine($registry,$provider);
$r1=$engine->reevaluateAll(); lrA(count($r1)===2,'all active capabilities reevaluated'); lrA($r1['cap-a']['outcome']===AuthorityContinuanceOutcome::CONTINUE,'healthy capability continues');
$provider->worlds['cap-a']=array_merge($healthy('company-a'),['risk_acceptable'=>false,'world_revision'=>'world-2']);
$r2=$engine->reevaluate('cap-a'); lrA($r2['outcome']===AuthorityContinuanceOutcome::PAUSE,'risk no longer proven pauses capability'); lrA($registry->state('cap-a')['status']==='paused','registry reflects paused state');
$provider->worlds['cap-a']=array_merge($healthy('company-a'),['retained_effect_ids'=>['read'],'world_revision'=>'world-3']);
$r3=$engine->reevaluate('cap-a'); lrA($r3['outcome']===AuthorityContinuanceOutcome::NARROW,'live reality can narrow effect set'); lrA($registry->state('cap-a')['retained_effect_ids']===['read'],'narrowing persisted');
$provider->worlds['cap-a']=array_merge($healthy('company-a'),['transformation_required'=>true,'requested_effect_ids'=>['restore'],'world_revision'=>'world-4']);
$r4=$engine->reevaluate('cap-a'); lrA($r4['outcome']===AuthorityContinuanceOutcome::TRANSFORM,'changed authority shape requires transform'); lrA(($r4['transformation_request']['requires_fresh_sovereign_authorization']??false)===true,'transformation cannot self-authorize');
$provider->worlds['cap-a']=array_merge($healthy('company-a'),['purpose_valid'=>false,'world_revision'=>'world-5']);
$r5=$engine->reevaluate('cap-a'); lrA($r5['outcome']===AuthorityContinuanceOutcome::TERMINATE,'lost purpose terminates capability'); lrA($registry->state('cap-a')['status']==='terminated','termination persisted');
lrT(fn()=>$engine->reevaluate('cap-a'),'terminated capability cannot silently reactivate');
$history=$registry->history('cap-a'); lrA(count($history)>=5,'each live evaluation is retained as evidence'); lrA($history[0]['world_state_digest']!==$history[1]['world_state_digest'],'world-state changes are cryptographically distinguishable');
lrA(($history[0]['authority_granted']??true)===false,'reevaluation record does not grant authority');
$provider->worlds['cap-b']=array_merge($healthy('company-x'),['world_revision'=>'world-x']);
$r6=$engine->reevaluate('cap-b'); lrA($r6['outcome']===AuthorityContinuanceOutcome::TERMINATE,'company boundary change terminates'); lrA($registry->state('cap-b')['capability']['company_id']==='company-b','world input cannot rewrite canonical company scope');

echo "PASS live capability re-evaluation continuously applies current world state\nPASS active capabilities continue, pause, narrow, transform, or terminate from fresh evidence\nPASS transformation requires fresh sovereign authorization and cannot self-escalate\nPASS reevaluation history is evidence-only and preserves canonical company scope\n";
