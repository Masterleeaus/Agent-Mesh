<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedIngestor;
use Titan\GodMode\Store\InMemorySovereignActivityStore;
use Titan\GodMode\Supersession\DependencyDisposition;
use Titan\GodMode\Supersession\T0gmSupersessionService;

function sAssert($condition,string $message): void { if(!$condition) throw new RuntimeException('ASSERTION FAILED: '.$message); }
function sThrows(callable $fn,string $message): void { try { $fn(); } catch (Throwable $e) { return; } throw new RuntimeException('ASSERTION FAILED: '.$message); }

$store = new InMemorySovereignActivityStore();
$ingest = new T0gmFeedIngestor($store);
$factory = new T0gmEventFactory();
$sovereign = T0gmFeedAccessContext::sovereign('jason');
$delegated = new T0gmFeedAccessContext('oversight','t0gm.oversight_ai',['company-a'],false);

$make = function(string $id,string $kind,?string $cause,array $details,array $signals=[]) use ($factory) {
    $parents = $cause ? [$cause] : [];
    return $factory->make(
        $kind,
        ['scope'=>'company','company_id'=>'company-a'],
        ['actor_type'=>'advanced_intelligence','actor_id'=>'ops-ai','authority_class'=>'delegated_ai'],
        ['system'=>'titan.ops','component'=>'decision-chain'],
        ['subject_type'=>'job','subject_id'=>'job-77'],
        ['trace_id'=>'trace-77','correlation_id'=>'corr-77','causation_id'=>$cause,'parent_event_ids'=>$parents],
        ['score'=>60,'band'=>'high','dimensions'=>['operational'=>60]],
        ['visibility'=>'t0gm_sovereign','attention_tier'=>'important','review_required'=>true,'review_team'=>['governance','causal']],
        [],
        array_merge($details,['attention_signals'=>array_merge(['reversibility'=>0],$signals)]),
        $id,
        '2026-09-02T10:00:00Z','2026-09-02T10:00:01Z'
    );
};

$root = $make('evt-decision',T0gmEventKind::AI_DECISION,null,['decision'=>['decision_id'=>'d-1','determination'=>'suspend supplier','reason_codes'=>['FRAUD_RISK']]]);
$queued = $make('evt-exec-running',T0gmEventKind::EXECUTION,'evt-decision',['execution'=>['execution_id'=>'x-1','state'=>'running','adapter'=>'supplier-api']],['reversibility'=>80]);
$childDecision = $make('evt-child-decision',T0gmEventKind::AI_DECISION,'evt-decision',['decision'=>['decision_id'=>'d-2','determination'=>'notify finance','reason_codes'=>['DEPENDENCY']]]);
$completed = $make('evt-completed',T0gmEventKind::EXECUTION,'evt-child-decision',['execution'=>['execution_id'=>'x-2','state'=>'completed','adapter'=>'message-api']],['reversibility'=>90]);
$observation = $make('evt-observation',T0gmEventKind::OBSERVATION,'evt-decision',['observation'=>['summary'=>'Supplier API returned suspension accepted']],['reversibility'=>0]);
$unrelated = $factory->make(
    T0gmEventKind::OBSERVATION,
    ['scope'=>'company','company_id'=>'company-a'],
    ['actor_type'=>'system','actor_id'=>'sensor'],
    ['system'=>'titan.ops','component'=>'unrelated'],
    ['subject_type'=>'job','subject_id'=>'job-99'],
    ['trace_id'=>'other','correlation_id'=>'corr-77','causation_id'=>null,'parent_event_ids'=>[]],
    ['score'=>10,'band'=>'low','dimensions'=>[]],
    ['visibility'=>'t0gm_sovereign','attention_tier'=>'routine','review_required'=>false,'review_team'=>[]],
    [],['observation'=>['summary'=>'Same correlation but no causal edge']], 'evt-unrelated'
);
foreach ([$root,$queued,$childDecision,$completed,$observation,$unrelated] as $e) $ingest->ingest($e);

$service = new T0gmSupersessionService($store);
$plan = $service->supersede('evt-decision',$sovereign,'jason','Do not suspend supplier; acquisition negotiation is known context',[[
    'evidence_id'=>'ev-human-context','evidence_type'=>'human_context','source'=>'t0gm-owner'
]]);

sAssert($store->verifyAuditLineage(),'supersession preserves immutable audit lineage');
$super = $store->get($plan->supersessionEventId,$sovereign)['event'];
sAssert($super['event_kind'] === T0gmEventKind::SUPERSESSION,'new immutable supersession event created');
sAssert(($super['actor']['authority_class'] ?? null) === 'titan.god_mode','supersession requires T0GM authority');
sAssert(($super['supersession']['no_prior_escalation_required'] ?? false) === true,'intervention does not require prior escalation');
sAssert(($super['supersession']['truth_preservation'] ?? false) === true,'truth preservation encoded');
sAssert($store->get('evt-decision',$sovereign)['event']['decision']['determination'] === 'suspend supplier','original AI decision preserved');

$byId=[]; foreach($plan->actions as $a) $byId[$a->eventId]=$a;
sAssert(($byId['evt-exec-running']->disposition ?? null) === DependencyDisposition::STOP,'live dependent execution stops');
sAssert(($byId['evt-child-decision']->disposition ?? null) === DependencyDisposition::RECOMPUTE,'dependent AI decision recomputes');
sAssert(($byId['evt-completed']->disposition ?? null) === DependencyDisposition::REVERSE,'reversible completed dependent effect reverses');
sAssert(($byId['evt-observation']->disposition ?? null) === DependencyDisposition::REMAIN_INTACT,'truth-bearing observation remains intact');
sAssert(!isset($byId['evt-unrelated']),'correlation alone is not treated as dependency');

sThrows(fn() => $service->supersede('evt-decision',$delegated,'oversight','attempted sovereign override'),'delegated oversight AI cannot supersede');

echo "PASS T0GM immediate sovereign supersession\n";
echo "PASS causal dependency discovery distinguishes causation from correlation\n";
echo "PASS stop/reverse/recompute/remain-intact consequence classification\n";
echo "PASS original decisions and truth-bearing evidence remain immutable\n";
