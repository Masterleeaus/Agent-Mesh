<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeKeyRegistry;
use Titan\GodMode\Security\GodModeAccessGate;
use Titan\GodMode\Security\GodModeException;
use Titan\GodMode\Support\InMemoryNonceStore;
use Titan\GodMode\Support\ArrayAuditSink;
use Titan\GodMode\Policy\RoleConfigurationGuard;

function assertTrue($condition, string $message): void {
    if (!$condition) throw new RuntimeException("ASSERTION FAILED: $message");
}
function expectReason(string $reason, callable $fn): void {
    try { $fn(); }
    catch (GodModeException $e) {
        assertTrue($e->reason === $reason, "expected $reason got {$e->reason}");
        return;
    }
    throw new RuntimeException("expected failure:$reason");
}
function signPayload(array $payload, string $secret): string {
    return base64_encode(sodium_crypto_sign_detached(CanonicalJson::encode($payload), $secret));
}

$now = time();
$root = sodium_crypto_sign_keypair();
$rootSecret = sodium_crypto_sign_secretkey($root);
$rootPublic = sodium_crypto_sign_publickey($root);

$device = sodium_crypto_sign_keypair();
$deviceSecret = sodium_crypto_sign_secretkey($device);
$devicePublic = sodium_crypto_sign_publickey($device);

$policy = [
    'authority' => 'titan.god_mode',
    'principal_class' => 'builder_control_plane_principal',
    'principal_id' => 'OWNER_CONTROL_PLANE_PRINCIPAL',
    'audience' => 'titan-builder-control-plane',
    'clock_skew_seconds' => 0,
    'root_public_keys' => ['root-test' => base64_encode($rootPublic)],
    'allowed_device_key_ids' => ['device-test-01'],
    'forbidden_role_markers' => ['titan.god_mode','god_mode','god-mode','godmode','builder_control_plane','builder-control-plane']
];

$certificatePayload = [
    'schema' => 'titan.god_mode.device_certificate.v1',
    'authority' => 'titan.god_mode',
    'principal_class' => 'builder_control_plane_principal',
    'principal_id' => 'OWNER_CONTROL_PLANE_PRINCIPAL',
    'device_key_id' => 'device-test-01',
    'device_public_key' => base64_encode($devicePublic),
    'issued_at' => $now - 5,
    'not_before' => $now - 5,
    'expires_at' => $now + 3600,
    'audience' => 'titan-builder-control-plane',
    'non_tenant' => true
];

$certificate = [
    'payload' => $certificatePayload,
    'root_key_id' => 'root-test',
    'signature' => signPayload($certificatePayload, $rootSecret)
];

$requestPayload = [
    'schema' => 'titan.god_mode.request_proof.v1',
    'authority' => 'titan.god_mode',
    'principal_id' => 'OWNER_CONTROL_PLANE_PRINCIPAL',
    'device_key_id' => 'device-test-01',
    'audience' => 'titan-builder-control-plane',
    'nonce' => bin2hex(random_bytes(24)),
    'issued_at' => $now,
    'expires_at' => $now + 120,
    'purpose' => 'Emergency recovery validation',
    'action' => 'platform.recovery.inspect',
    'target' => ['scope' => 'company', 'company_id' => 'company_123']
];

$requestProof = [
    'payload' => $requestPayload,
    'device_signature' => signPayload($requestPayload, $deviceSecret)
];

$nonces = new InMemoryNonceStore();
$audit = new ArrayAuditSink();
$gate = new GodModeAccessGate(
    new GodModeKeyRegistry($policy['root_public_keys']),
    $nonces,
    $audit,
    $policy
);

$decision = $gate->authorize($certificate, $requestProof, [
    'actor_id' => 'normal-session-actor',
    'company_id' => 'company_123',
    'role_grants' => ['business_owner'],
    'permissions' => ['company.manage']
], $now);
assertTrue($decision['authority'] === 'titan.god_mode', 'valid proof authorized');
assertTrue($decision['target']['company_id'] === 'company_123', 'company target retained');

expectReason('replay-detected', fn() => $gate->authorize($certificate, $requestProof, [], $now));

$badRoleGuard = new RoleConfigurationGuard($policy['forbidden_role_markers']);
expectReason('god-mode-role-recreation-forbidden', fn() => $badRoleGuard->validateRoleDefinition([
    'name' => 'Tenant Super Admin',
    'permissions' => ['crm.all','titan.god_mode']
]));

$badProof = $requestProof;
$badProof['payload']['target'] = ['scope'=>'company','tenant_id'=>'legacy'];
$badProof['payload']['nonce'] = bin2hex(random_bytes(24));
$badProof['device_signature'] = signPayload($badProof['payload'], $deviceSecret);
expectReason('company-target-requires-company_id', fn() => $gate->authorize($certificate, $badProof, [], $now));

$legacyTarget = $requestProof;
$legacyTarget['payload']['target'] = ['scope'=>'company','company_id'=>'company_123','tenant_id'=>'legacy'];
$legacyTarget['payload']['nonce'] = bin2hex(random_bytes(24));
$legacyTarget['device_signature'] = signPayload($legacyTarget['payload'], $deviceSecret);
expectReason('legacy-tenant-target-forbidden', fn() => $gate->authorize($certificate, $legacyTarget, [], $now));

$wrongPrincipal = $certificate;
$wrongPrincipal['payload']['principal_id'] = 'ANOTHER_ADMIN';
$wrongPrincipal['signature'] = signPayload($wrongPrincipal['payload'], $rootSecret);
expectReason('wrong-principal-id', fn() => $gate->authorize($wrongPrincipal, $requestProof, [], $now));

$tenantBound = $certificate;
$tenantBound['payload']['company_id'] = 'company_123';
$tenantBound['signature'] = signPayload($tenantBound['payload'], $rootSecret);
expectReason('tenant-bound-credential-forbidden', fn() => $gate->authorize($tenantBound, $requestProof, [], $now));

$forged = $requestProof;
$forged['payload']['nonce'] = bin2hex(random_bytes(24));
$forged['device_signature'] = base64_encode(random_bytes(SODIUM_CRYPTO_SIGN_BYTES));
expectReason('invalid-device-signature', fn() => $gate->authorize($certificate, $forged, [], $now));

$impersonation = $requestProof;
$impersonation['payload']['nonce'] = bin2hex(random_bytes(24));
$impersonation['device_signature'] = signPayload($impersonation['payload'], $deviceSecret);
expectReason('impersonation-or-admin-escalation-forbidden', fn() => $gate->authorize(
    $certificate, $impersonation, ['impersonating'=>true], $now
));

$roleSmuggle = $requestProof;
$roleSmuggle['payload']['nonce'] = bin2hex(random_bytes(24));
$roleSmuggle['device_signature'] = signPayload($roleSmuggle['payload'], $deviceSecret);
expectReason('normal-role-configuration-cannot-carry-god-mode', fn() => $gate->authorize(
    $certificate, $roleSmuggle, ['permissions'=>['crm.manage','builder_control_plane']], $now
));

assertTrue(count($audit->events) >= 8, 'audit events emitted');
echo "PASS valid verifier-only God Mode proof\n";
echo "PASS replay protection\n";
echo "PASS role recreation rejection\n";
echo "PASS legacy tenant target rejection\n";
echo "PASS wrong principal rejection\n";
echo "PASS tenant-bound credential rejection\n";
echo "PASS forged device signature rejection\n";
echo "PASS impersonation rejection\n";
echo "PASS permission smuggling rejection\n";
echo "PASS audit evidence\n";
