<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\Event\T0gmCanonicalHasher;
use Titan\GodMode\Event\T0gmEventException;
use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Event\T0gmEventValidator;

function tAssert($condition, string $message): void {
    if (!$condition) throw new RuntimeException('ASSERTION FAILED: ' . $message);
}
function tExpect(string $reason, callable $fn): void {
    try { $fn(); } catch (T0gmEventException $e) { tAssert($e->reason === $reason, "expected $reason got {$e->reason}"); return; }
    throw new RuntimeException('expected event validation failure: ' . $reason);
}

$factory = new T0gmEventFactory();
$base = [
    'companyContext' => ['scope'=>'company','company_id'=>'company_123'],
    'actor' => ['actor_type'=>'advanced_intelligence','actor_id'=>'ai.security.7','authority_class'=>'delegated_ai'],
    'source' => ['system'=>'titan-shield','component'=>'oversight-adapter','version'=>'1.0.0-alpha.1'],
    'subject' => ['subject_type'=>'privileged_change','subject_id'=>'chg_22'],
    'lineage' => ['trace_id'=>'trace_1','correlation_id'=>'corr_1','causation_id'=>'evt_seed','parent_event_ids'=>['evt_seed']],
    'risk' => ['score'=>92,'band'=>'extreme','dimensions'=>['cyber'=>92,'financial'=>40,'reversibility'=>70]],
    'oversight' => ['visibility'=>'t0gm_sovereign','attention_tier'=>'critical','review_required'=>true,'review_team'=>['security','governance']],
    'evidence' => [['evidence_id'=>'ev_1','evidence_type'=>'policy_snapshot','source'=>'titan-risk','hash'=>'abc']]
];

$decision = $factory->make(
    T0gmEventKind::AI_DECISION,
    $base['companyContext'],$base['actor'],$base['source'],$base['subject'],$base['lineage'],$base['risk'],$base['oversight'],$base['evidence'],
    ['decision'=>[
        'decision_id'=>'dec_1',
        'determination'=>'constrain-capability',
        'reason_codes'=>['UNUSUAL_PRIVILEGE_PATH','EXTREME_CYBER_RISK'],
        'confidence'=>0.91,
        'explanation'=>'Evidence indicates an unusual privileged transition.',
        'assumptions'=>['target state snapshot is current']
    ]],
    'evt_dec_1','2026-09-02T09:00:00Z','2026-09-02T09:00:01Z'
);
tAssert($decision['event_kind'] === 'ai_decision', 'AI decision accepted');
tAssert($decision['company_context']['company_id'] === 'company_123', 'company_id retained');
tAssert(!isset($decision['expires_at']), 'event envelope has no authority TTL');

$supersessionActor = ['actor_type'=>'human','actor_id'=>'T0GM_OWNER','authority_class'=>'titan.god_mode'];
$supersession = $factory->make(
    T0gmEventKind::SUPERSESSION,
    $base['companyContext'],$supersessionActor,['system'=>'t0gm','component'=>'sovereign-command'],['subject_type'=>'decision','subject_id'=>'dec_1'],
    ['trace_id'=>'trace_1','correlation_id'=>'corr_1','causation_id'=>'evt_dec_1','parent_event_ids'=>['evt_dec_1']],
    ['score'=>92,'band'=>'extreme','dimensions'=>['cyber'=>92]],
    ['visibility'=>'t0gm_sovereign','attention_tier'=>'critical','review_required'=>true],
    [['evidence_id'=>'ev_user_1','evidence_type'=>'sovereign_determination','source'=>'t0gm']],
    ['supersession'=>['supersession_id'=>'sup_1','supersedes_event_ids'=>['evt_dec_1'],'directive'=>'proceed-with-constrained-alternative','reason'=>'Known strategic context absent from operational AI']],
    'evt_sup_1'
);
tAssert($supersession['supersession']['supersedes_event_ids'][0] === 'evt_dec_1', 'supersession causal target retained');

$badTenant = $decision;
$badTenant['company_context']['tenant_id'] = 'legacy';
tExpect('legacy-tenant-boundary-forbidden', fn() => (new T0gmEventValidator())->validate($badTenant));

$badVisibility = $decision;
$badVisibility['oversight']['visibility'] = 'hidden';
tExpect('invalid-fixed-field', fn() => (new T0gmEventValidator())->validate($badVisibility));

$badRisk = $decision;
$badRisk['risk']['score'] = 101;
tExpect('invalid-risk-score', fn() => (new T0gmEventValidator())->validate($badRisk));

$badSup = $supersession;
$badSup['actor']['authority_class'] = 'delegated_ai';
tExpect('sovereign-supersession-requires-t0gm', fn() => (new T0gmEventValidator())->validate($badSup));


$kindCases = [
    T0gmEventKind::OBSERVATION => ['observation'=>['summary'=>'Observed configuration drift']],
    T0gmEventKind::HUMAN_ACTION => ['action'=>['action'=>'review-risk-feed']],
    T0gmEventKind::AUTHORITY_USE => ['authority'=>['authority_class'=>'delegated_ai','authority_basis'=>'capability:cap_1']],
    T0gmEventKind::EXECUTION => ['execution'=>['execution_id'=>'exec_1','state'=>'started','adapter'=>'kubernetes-api']],
    T0gmEventKind::RESULT => ['result'=>['result_state'=>'completed','verification_state'=>'verified']],
    T0gmEventKind::ANOMALY => ['anomaly'=>['anomaly_type'=>'cross-system-pattern','summary'=>'Correlated unusual changes']],
    T0gmEventKind::INTERVENTION => ['intervention'=>['intervention_id'=>'int_1','directive'=>'constrain-capability']],
];
foreach ($kindCases as $kind => $details) {
    $actor = $base['actor'];
    if ($kind === T0gmEventKind::HUMAN_ACTION) $actor = ['actor_type'=>'human','actor_id'=>'operator_1','authority_class'=>'company_owner'];
    $event = $factory->make(
        $kind,$base['companyContext'],$actor,$base['source'],$base['subject'],
        ['trace_id'=>'trace_'.$kind,'correlation_id'=>'corr_1','parent_event_ids'=>[]],
        ['score'=>20,'band'=>'low','dimensions'=>[]],
        ['visibility'=>'t0gm_sovereign','attention_tier'=>'routine','review_required'=>false],
        [],$details,'evt_'.$kind
    );
    tAssert($event['event_kind'] === $kind, "kind $kind accepted");
}

$hasher = new T0gmCanonicalHasher();
$sealed = $hasher->seal($decision, 'previous_hash');
tAssert($hasher->verify($sealed), 'sealed event verifies');
$tampered = $sealed;
$tampered['risk']['score'] = 3;
tAssert(!$hasher->verify($tampered), 'tampering detected');

echo "PASS all nine canonical event kinds\n";
echo "PASS canonical AI decision envelope\n";
echo "PASS sovereign supersession envelope\n";
echo "PASS company_id-only tenant boundary\n";
echo "PASS sovereign visibility invariant\n";
echo "PASS risk bounds\n";
echo "PASS T0GM-only sovereign supersession\n";
echo "PASS canonical event integrity hash\n";
echo "PASS timestamps do not mint event authority TTL\n";
