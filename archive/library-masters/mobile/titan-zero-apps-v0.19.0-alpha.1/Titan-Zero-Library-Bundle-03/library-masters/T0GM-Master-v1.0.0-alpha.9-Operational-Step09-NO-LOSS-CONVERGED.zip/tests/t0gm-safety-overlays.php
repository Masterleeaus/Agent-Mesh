<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Capability\SovereignCapabilityFactory;
use Titan\GodMode\Overlay\BuiltinSafetyOverlays;
use Titan\GodMode\Overlay\SafetyOverlayEngine;

function p24(bool $ok,string $m):void{if(!$ok)throw new RuntimeException($m);echo "PASS $m\n";}
$cap=(new SovereignCapabilityFactory())->create([
 'authority_holder'=>['authority_class'=>'titan.god_mode','identity_id'=>'t0gm-human','actor_type'=>'human'],
 'authority_basis'=>['basis_type'=>'contract','basis_id'=>'agreement-24','description'=>'Step24'],
 'company_id'=>'company-24','purpose'=>['purpose_id'=>'p24','statement'=>'Governed vertical operation','intended_outcome'=>'safe result'],
 'target'=>['target_type'=>'application','target_id'=>'app-24','system'=>'titan','environment'=>'production','resource_ids'=>['r24']],
 'permitted_effects'=>[['effect_id'=>'e24','operation'=>'funds_transfer','resource_type'=>'record','resource_ids'=>['r24']]],
 'prohibited_effects'=>[['operation'=>'delete_everything','reason'=>'unbounded']],
 'evidence'=>[['evidence_id'=>'ev24','evidence_type'=>'authorization','source'=>'t0gm','integrity_ref'=>'sha256:test']],
 'risk_constraints'=>['max_risk_score'=>90,'max_financial_exposure'=>90,'max_physical_impact'=>90,'max_environmental_impact'=>90,'prohibited_risk_bands'=>['extreme']],
 'extinction_conditions'=>[['condition_id'=>'x1','condition_type'=>'t0gm_extinguish','description'=>'explicit extinction']],
]);
$built=new BuiltinSafetyOverlays();$engine=new SafetyOverlayEngine();
$finance=$built->industry('finance','company-24');
$base=['company_id'=>'company-24','operation'=>'funds_transfer','action_class'=>'money_movement','risk'=>['financial_exposure'=>50,'physical_impact'=>0,'environmental_impact'=>0],
 'execution_evidence'=>[['evidence_type'=>'purpose'],['evidence_type'=>'identity'],['evidence_type'=>'authorization']]];
$d=$engine->evaluate([$finance],$cap,$base);
p24(!$d->allowed && in_array('human_approval_required_by_overlay',$d->reasons,true),'finance overlay requires human approval for funds transfer');
$one=$base+['human_approval'=>['approved'=>true,'actor_type'=>'human','actor_id'=>'client-1','approval_id'=>'a1']];
p24(!$engine->evaluate([$finance],$cap,$one)->allowed,'finance transfer still requires independent dual control');
$two=$one+['dual_control_approvals'=>[['approved'=>true,'actor_type'=>'human','actor_id'=>'client-1'],['approved'=>true,'actor_type'=>'human','actor_id'=>'client-2']]];
p24($engine->evaluate([$finance],$cap,$two)->allowed,'finance overlay permits bounded transfer after required controls');
$tooMuch=$two;$tooMuch['risk']['financial_exposure']=80;
p24(!$engine->evaluate([$finance],$cap,$tooMuch)->allowed,'financial exposure ceiling cannot be averaged away');
$health=$built->industry('healthcare','company-24');
$clinical=$base;$clinical['operation']='clinical_action';$clinical['action_class']='physical_clinical_control';$clinical['risk']['physical_impact']=10;
p24(!$engine->evaluate([$health],$cap,$clinical)->allowed,'healthcare overlay structurally prohibits physical clinical control');
$env=$built->industry('environmental_operations','company-24');
$envReq=$base;$envReq['operation']='discharge';$envReq['risk']['environmental_impact']=10;$envReq['execution_evidence'][]=['evidence_type'=>'environmental'];$envReq['human_approval']=['approved'=>true,'actor_type'=>'human','actor_id'=>'operator','approval_id'=>'env1'];
p24(!$engine->evaluate([$env],$cap,$envReq)->allowed,'environmental operation requires verified environmental control');
$envReq['controls']['environmental_state_verified']=true;
p24($engine->evaluate([$env],$cap,$envReq)->allowed,'environmental operation passes when evidence and control are satisfied');
$man=$built->industry('manufacturing','company-24');
$m=$base;$m['action_class']='physical_control';
p24(!$engine->evaluate([$man],$cap,$m)->allowed,'manufacturing physical control requires safety controls and human approval');
$jur=$built->jurisdiction('AU','company-24',['allowed_data_regions'=>['AU']]);
$j=$base;$j['data_region']='US';$j['data_company_ids']=['company-24'];
p24(!$engine->evaluate([$jur],$cap,$j)->allowed,'jurisdiction overlay enforces configured data-region constraint');
$j['data_region']='AU';p24($engine->evaluate([$jur],$cap,$j)->allowed,'jurisdiction overlay permits configured data region');
$j['data_company_ids']=['company-24','company-other'];p24(!$engine->evaluate([$jur],$cap,$j)->allowed,'jurisdiction overlay cannot leak cross-company data');
$wrong=$built->industry('finance','company-other');p24(!$engine->evaluate([$wrong],$cap,$two)->allowed,'overlay is company_id-bound');
$tampered=$finance;$tampered['constraints']['max_financial_exposure']=100;p24(!$engine->evaluate([$tampered],$cap,$two)->allowed,'tampered overlay fails integrity verification');
$custom=(new \Titan\GodMode\Overlay\SafetyOverlayFactory())->create(['company_id'=>'company-24','kind'=>'custom','code'=>'future-vertical','constraints'=>['prohibited_operations'=>['funds_transfer']]]);
p24(!$engine->evaluate([$custom],$cap,$two)->allowed,'future vertical constraints use same overlay contract');
echo "T0GM jurisdiction/industry safety overlay tests: PASS\n";
