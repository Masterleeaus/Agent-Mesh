<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\Investigation\T0gmSovereignInvestigationWorkspace;
use Titan\GodMode\Security\GodModeException;
function iwAssert($c,$m){if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);} 
$workspace=new T0gmSovereignInvestigationWorkspace();
$case=$workspace->compose([
 'investigation_id'=>'inv-001','company_id'=>'company_a','title'=>'Unexpected invoice workflow activity','opened_at'=>'2026-09-04T07:31:00Z',
 'timeline'=>[
  ['sequence'=>1,'event_id'=>'evt-1','occurred_at'=>'2026-09-04T07:30:00Z','kind'=>'decision','summary'=>'AI selected follow-up workflow'],
  ['sequence'=>2,'event_id'=>'evt-2','occurred_at'=>'2026-09-04T07:30:05Z','kind'=>'action','summary'=>'Workflow requested execution'],
 ],
 'evidence'=>[['evidence_id'=>'ev-1','type'=>'audit_record','digest'=>str_repeat('a',64),'verified'=>true,'source'=>'sovereign-audit']],
 'causal_graph'=>['nodes'=>[['node_id'=>'evt-1','node_type'=>'decision'],['node_id'=>'evt-2','node_type'=>'action']],'edges'=>[['from'=>'evt-1','to'=>'evt-2','type'=>'causes','confidence'=>0.94]]],
 'decisions'=>[['decision_id'=>'dec-1','actor_id'=>'ai-revenue','disposition'=>'recommend','confidence'=>0.71,'superseded'=>false]],
 'identities'=>[['identity_id'=>'ai-revenue','identity_type'=>'advanced_intelligence','attestation_state'=>'verified']],
 'capabilities'=>[['capability_id'=>'cap-1','holder_id'=>'ai-revenue','status'=>'active','permitted_effect_ids'=>['workflow.start']]],
 'current_state'=>['workflow'=>'pending_authority','device_integrity'=>'verified','risk_score'=>63],
]);
iwAssert($case['schema']==='titan.t0gm.sovereign-investigation-workspace.v1','schema');
iwAssert($case['company_id']==='company_a' && $case['projection_only']===true,'company/projection');
foreach(['timeline','evidence','causal_graph','decisions','identities','capabilities','current_state'] as $section) iwAssert(array_key_exists($section,$case),'section '.$section);
iwAssert($case['summary']['timeline_events']===2 && $case['summary']['evidence_items']===1,'summary counts');
iwAssert($case['summary']['verified_evidence_items']===1 && $case['summary']['active_capabilities']===1,'summary verified/capabilities');
iwAssert($case['authority']['grants_authority']===false && $case['authority']['execution_authority_granted']===false,'no authority');
try{$workspace->compose(['investigation_id'=>'bad','company_id'=>'company_a','tenant_id'=>'legacy','title'=>'bad','opened_at'=>'2026-09-04T07:31:00Z']);throw new RuntimeException('legacy boundary accepted');}catch(GodModeException $e){iwAssert($e->getMessage()==='legacy-tenant-boundary-forbidden:tenant_id','legacy boundary rejected');}
try{$workspace->compose(['investigation_id'=>'bad2','company_id'=>'','title'=>'bad','opened_at'=>'2026-09-04T07:31:00Z']);throw new RuntimeException('empty company accepted');}catch(GodModeException $e){iwAssert($e->getMessage()==='investigation-company-id-required','company required');}
echo "PASS sovereign investigation workspace combines timeline/evidence/causal/decision/identity/capability/current-state projections\nPASS investigation summaries retain verified evidence and active capability state\nPASS investigation surface grants no authority and fails closed on tenant boundary violations\n";
