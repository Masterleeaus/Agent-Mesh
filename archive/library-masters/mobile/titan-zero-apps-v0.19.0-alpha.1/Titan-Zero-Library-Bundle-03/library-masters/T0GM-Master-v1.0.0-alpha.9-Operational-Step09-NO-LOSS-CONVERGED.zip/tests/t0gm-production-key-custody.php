<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Custody\BrokeredSecureEnclaveCustodyProvider;
use Titan\GodMode\Custody\Pkcs11HsmCustodyProvider;
use Titan\GodMode\Custody\SecureEnclaveBroker;
use Titan\GodMode\Custody\SovereignKeyCustodyPolicy;
use Titan\GodMode\Custody\SovereignKeyCustodyProvider;
use Titan\GodMode\Custody\SovereignKeyCustodyRegistry;
use Titan\GodMode\Custody\SovereignKeyHandle;
use Titan\GodMode\Custody\SovereignSigningService;
use Titan\GodMode\Identity\OpenSslPqcSignatureVerifier;
use Titan\GodMode\Identity\T0gmCryptoSuiteRegistry;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

function kcAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function kcExpect(string $reason, callable $fn):void{try{$fn();}catch(GodModeException $e){kcAssert($e->reason===$reason,"expected $reason got {$e->reason}");return;}throw new RuntimeException("expected failure:$reason");}
function kcRun(array $cmd): string { $spec=[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']];$p=proc_open($cmd,$spec,$pipes);if(!is_resource($p))throw new RuntimeException('proc-open-failed');fclose($pipes[0]);$out=stream_get_contents($pipes[1]);fclose($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[2]);$c=proc_close($p);if($c!==0)throw new RuntimeException("command-failed:$err");return $out; }

final class TestHardwareProvider implements SovereignKeyCustodyProvider {
    public function __construct(private string $id,private array $keys){}
    public function providerId(): string{return $this->id;}
    public function describe(string $keyId): SovereignKeyHandle { if(!isset($this->keys[$keyId]))throw new GodModeException('unknown-test-hardware-key');$k=$this->keys[$keyId];return new SovereignKeyHandle($keyId,$k['suite'],$this->id,$k['class'],$k['domain'],$k['public'],true,false,['sovereign_identity'],hash('sha256','attest:'.$keyId)); }
    public function sign(string $keyId,string $suite,string $message,array $context=[]): string { $k=$this->keys[$keyId];if($suite!==$k['suite'])throw new GodModeException('test-suite-mismatch');if($suite==='ed25519')return sodium_crypto_sign_detached($message,$k['secret']);$d=$k['dir'];$m="$d/msg";$s="$d/sig";file_put_contents($m,$message);kcRun(['openssl','pkeyutl','-sign','-inkey',$k['priv'],'-in',$m,'-out',$s]);$raw=file_get_contents($s);@unlink($m);@unlink($s);return $raw; }
}

$ed=sodium_crypto_sign_keypair();
$pqDir=sys_get_temp_dir().'/t0gm-kc-'.bin2hex(random_bytes(8));mkdir($pqDir,0700,true);$pqPriv="$pqDir/private.pem";$pqPub="$pqDir/public.pem";kcRun(['openssl','genpkey','-algorithm','ML-DSA-65','-out',$pqPriv]);kcRun(['openssl','pkey','-in',$pqPriv,'-pubout','-out',$pqPub]);
$providerA=new TestHardwareProvider('hsm-a',['ed-root'=>['suite'=>'ed25519','class'=>'hsm','domain'=>'dc-hsm-a','public'=>sodium_crypto_sign_publickey($ed),'secret'=>sodium_crypto_sign_secretkey($ed)]]);
$providerB=new TestHardwareProvider('enclave-b',['pq-root'=>['suite'=>'ml-dsa-65','class'=>'secure_enclave','domain'=>'device-enclave-b','public'=>file_get_contents($pqPub),'priv'=>$pqPriv,'dir'=>$pqDir]]);
$registry=new SovereignKeyCustodyRegistry([$providerA,$providerB]);
$signer=new SovereignSigningService($registry,new SovereignKeyCustodyPolicy());
$payload=['schema'=>'titan.t0gm.sovereign_identity_proof.v2','authority'=>'titan.god_mode','challenge'=>bin2hex(random_bytes(16)),'non_tenant'=>true];
$sigs=$signer->signIdentityPayload($payload,[['provider_id'=>'hsm-a','key_id'=>'ed-root'],['provider_id'=>'enclave-b','key_id'=>'pq-root']],['ed25519','ml-dsa-65']);

kcAssert(count($sigs)===2,'two hardware signatures emitted');
foreach($sigs as $s){kcAssert(!isset($s['custody']['public_key']),'signature custody metadata does not duplicate key bytes');kcAssert($s['custody']['exportable']===false,'non-exportable custody preserved');}
$crypto=new T0gmCryptoSuiteRegistry(new OpenSslPqcSignatureVerifier());
$msg=CanonicalJson::encode($payload);
$edSig=base64_decode($sigs[0]['signature'],true);$pqSig=base64_decode($sigs[1]['signature'],true);
kcAssert($crypto->verify('ed25519',$edSig,$msg,sodium_crypto_sign_publickey($ed)),'HSM-class signature verifies');
kcAssert($crypto->verify('ml-dsa-65',$pqSig,$msg,file_get_contents($pqPub)),'secure-enclave-class PQ signature verifies');

kcExpect('private-key-material-forbidden-in-handle:private_key',fn()=>new SovereignKeyHandle('x','ed25519','p','hsm','d','pub',true,false,['sovereign_identity'],'hash',['private_key'=>'forbidden']));
kcExpect('sovereign-private-key-must-be-non-exportable',fn()=>new SovereignKeyHandle('x','ed25519','p','hsm','d','pub',true,true,['sovereign_identity'],'hash'));
kcExpect('hsm-pin-material-forbidden-in-key-uri',fn()=>new Pkcs11HsmCustodyProvider('bad',['k'=>['key_uri'=>'pkcs11:object=k;pin-value=1234']]));

$sameDomainA=new TestHardwareProvider('same-a',['a'=>['suite'=>'ed25519','class'=>'hsm','domain'=>'same-domain','public'=>sodium_crypto_sign_publickey($ed),'secret'=>sodium_crypto_sign_secretkey($ed)]]);
$sameDomainB=new TestHardwareProvider('same-b',['b'=>['suite'=>'ml-dsa-65','class'=>'hsm','domain'=>'same-domain','public'=>file_get_contents($pqPub),'priv'=>$pqPriv,'dir'=>$pqDir]]);
$badSigner=new SovereignSigningService(new SovereignKeyCustodyRegistry([$sameDomainA,$sameDomainB]),new SovereignKeyCustodyPolicy());
kcExpect('sovereign-signing-keys-must-use-distinct-custody-domains',fn()=>$badSigner->signIdentityPayload($payload,[['provider_id'=>'same-a','key_id'=>'a'],['provider_id'=>'same-b','key_id'=>'b']],['ed25519','ml-dsa-65']));

final class EmptyBroker implements SecureEnclaveBroker { public function sign(string $providerId,string $keyId,string $suite,string $message,array $context=[]): string{return '';} }
$brokered=new BrokeredSecureEnclaveCustodyProvider('brokered',['e'=>['suite'=>'ed25519','custody_domain'=>'secure-enclave-device-1','public_key'=>base64_encode(sodium_crypto_sign_publickey($ed)),'purposes'=>['sovereign_identity'],'attestation_evidence_hash'=>hash('sha256','evidence'),'broker_key_reference'=>'opaque-handle']],new EmptyBroker());
kcExpect('secure-enclave-empty-signature',fn()=>$brokered->sign('e','ed25519',$msg,['purpose'=>'sovereign_identity']));

@unlink($pqPriv);@unlink($pqPub);@rmdir($pqDir);
echo "PASS sovereign private keys remain hardware-bound and non-exportable\n";
echo "PASS hybrid signing requires distinct custody domains and purpose binding\n";
echo "PASS PKCS#11 configuration rejects embedded PIN material\n";
echo "PASS secure-enclave broker boundary returns signatures without private key export\n";
