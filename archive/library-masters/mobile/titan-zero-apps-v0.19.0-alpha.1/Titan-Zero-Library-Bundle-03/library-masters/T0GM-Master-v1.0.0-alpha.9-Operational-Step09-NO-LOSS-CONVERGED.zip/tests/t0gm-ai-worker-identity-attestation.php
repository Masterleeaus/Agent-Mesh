<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Workforce\T0gmCanonicalAiWorkforceRegistry;
use Titan\GodMode\Workforce\T0gmAiWorkerIdentityAttestor;
use Titan\GodMode\Security\GodModeException;

function waAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function waExpect(string $contains,callable $fn):void{try{$fn();}catch(Throwable $e){waAssert(str_contains($e->getMessage(),$contains),"expected $contains got {$e->getMessage()}");return;}throw new RuntimeException("expected failure:$contains");}

$registry=new T0gmCanonicalAiWorkforceRegistry();
$registry->register([
 'registry_id'=>'model-risk-v1','company_id'=>'company_a','kind'=>'model','name'=>'Risk Model',
 'provider'=>'openai-compatible','model_ref'=>'risk-model-v1','provenance'=>['source'=>'configured']
]);
$registry->register([
 'registry_id'=>'worker-risk-01','company_id'=>'company_a','kind'=>'worker','name'=>'Risk Worker',
 'model_ids'=>['model-risk-v1'],'provenance'=>['source'=>'provisioned']
]);

$attestor=new T0gmAiWorkerIdentityAttestor($registry);
$envelope=$attestor->attest('company_a','worker-risk-01',[
 'workload_identity'=>[
  'workload_id'=>'titan://service/prod/risk-worker-01','workload_class'=>'service','binding_id'=>'wbind-risk-01',
  'cryptographic_workload_identity'=>true,'identity_evidence_only'=>true,'authority_granted'=>false,
  'company_authority_granted'=>false,'measurement'=>'sha256:worker-image-17'
 ],
 'runtime_integrity'=>[
  'runtime_integrity_valid'=>true,'policy_id'=>'runtime-risk-v4','policy_revision'=>4,
  'code_digest'=>'sha256:code-risk-17','config_digest'=>'sha256:config-risk-09',
  'environment_digest'=>'sha256:linux-hardened-v3','authority_granted'=>false,
  'company_authority_granted'=>false,'t0gm_authority_granted'=>false
 ],
 'runtime_provenance'=>[
  'deployment_id'=>'deploy-risk-20260904','instance_id'=>'risk-01-a','region'=>'au-southeast',
  'started_at'=>'2026-09-04T07:55:00Z','orchestrator'=>'titan-runtime'
 ],
 'observed_at'=>'2026-09-04T08:00:00Z',
]);

waAssert($envelope['schema']==='titan.t0gm.ai-worker-identity-attestation.v1','schema');
waAssert($envelope['worker_id']==='worker-risk-01' && $envelope['company_id']==='company_a','canonical worker identity');
waAssert($envelope['model']['registry_id']==='model-risk-v1','canonical model bound');
waAssert($envelope['model']['provider']==='openai-compatible' && $envelope['model']['model_ref']==='risk-model-v1','provider/model info');
waAssert($envelope['runtime']['workload_id']==='titan://service/prod/risk-worker-01','runtime provenance');
waAssert($envelope['integrity']['runtime_integrity_valid']===true,'integrity valid');
waAssert(strlen($envelope['identity_digest'])===64,'identity digest');
waAssert($envelope['authority_granted']===false && $envelope['execution_authority_granted']===false,'attestation grants no authority');
waAssert($attestor->verify($envelope)===true,'envelope verifiable');

$tampered=$envelope;$tampered['model']['model_ref']='different';
waExpect('ai-worker-identity-digest-mismatch',fn()=>$attestor->verify($tampered));

waExpect('ai-worker-runtime-integrity-invalid',fn()=>$attestor->attest('company_a','worker-risk-01',[
 'workload_identity'=>$envelope['workload_identity_evidence'],
 'runtime_integrity'=>array_merge($envelope['runtime_integrity_evidence'],['runtime_integrity_valid'=>false]),
 'runtime_provenance'=>$envelope['runtime']['provenance'],
 'observed_at'=>'2026-09-04T08:01:00Z',
]));

waExpect('ai-worker-model-not-authorized-by-registry',fn()=>$attestor->attest('company_a','worker-risk-01',[
 'model_id'=>'model-other',
 'workload_identity'=>$envelope['workload_identity_evidence'],
 'runtime_integrity'=>$envelope['runtime_integrity_evidence'],
 'runtime_provenance'=>$envelope['runtime']['provenance'],
 'observed_at'=>'2026-09-04T08:01:00Z',
]));

waExpect('ai-worker-workload-identity-invalid',fn()=>$attestor->attest('company_a','worker-risk-01',[
 'workload_identity'=>array_merge($envelope['workload_identity_evidence'],['cryptographic_workload_identity'=>false]),
 'runtime_integrity'=>$envelope['runtime_integrity_evidence'],
 'runtime_provenance'=>$envelope['runtime']['provenance'],
 'observed_at'=>'2026-09-04T08:01:00Z',
]));

echo "PASS AI worker identity binds canonical registry identity to workload/runtime provenance\n";
echo "PASS worker attestation exposes canonical model/provider information and integrity evidence\n";
echo "PASS tamper, invalid integrity, unregistered model and invalid workload identity fail closed\n";
echo "PASS AI worker identity attestation is evidence-only and grants no authority\n";
