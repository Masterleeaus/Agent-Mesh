<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\App\T0gmSovereignHomeFeed;
use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedException;
use Titan\GodMode\Feed\T0gmFeedIngestor;
use Titan\GodMode\Feed\T0gmLineageFactory;
use Titan\GodMode\Store\InMemorySovereignActivityStore;
use Titan\GodMode\View\FileDynamicIntelligenceViewStore;
use Titan\GodMode\View\T0gmDynamicIntelligenceViewGenerator;

function dvAssert($condition, string $message): void { if (!$condition) throw new RuntimeException('ASSERTION FAILED: '.$message); }
function dvExpect(string $reason, callable $fn): void {
    try { $fn(); } catch (T0gmFeedException $e) { dvAssert($e->reason === $reason, "expected $reason got {$e->reason}"); return; }
    throw new RuntimeException('expected feed failure: '.$reason);
}

$tmp = sys_get_temp_dir().'/t0gm-dynamic-views-'.bin2hex(random_bytes(6)).'.json';
$activity = new InMemorySovereignActivityStore();
$ingest = new T0gmFeedIngestor($activity);
$factory = new T0gmEventFactory();
$lineage = new T0gmLineageFactory();
$home = new T0gmSovereignHomeFeed($activity);
$store = new FileDynamicIntelligenceViewStore($tmp);
$views = new T0gmDynamicIntelligenceViewGenerator($home,$store);
$sovereign = T0gmFeedAccessContext::sovereign('T0GM_OWNER');

$make = function(string $id,string $company,string $domain,string $summary,int $risk,int $consequence,int $anomaly,int $confidence,int $urgency,string $subjectType='operation') use ($factory,$lineage) {
    return $factory->make(
        T0gmEventKind::OBSERVATION,
        ['scope'=>'company','company_id'=>$company],
        ['actor_type'=>'advanced_intelligence','actor_id'=>'ai-'.$domain,'authority_class'=>'delegated_ai'],
        ['system'=>'titan','component'=>$domain.'-service'],
        ['subject_type'=>$subjectType,'subject_id'=>$domain.'-'.$id],
        $lineage->create('trace-'.$id,'corr-'.$id,null,[]),
        ['score'=>$risk,'band'=>$risk >= 90 ? 'extreme' : ($risk >= 70 ? 'high' : 'medium'),'dimensions'=>[$domain=>$risk]],
        ['visibility'=>'t0gm_sovereign','attention_tier'=>$urgency >= 90 ? 'critical' : 'important','review_required'=>false,'review_team'=>[]],
        [['evidence_id'=>'e-'.$id,'evidence_type'=>'fixture','source'=>'test']],
        [
            'attention_signals'=>[
                'significance'=>$consequence,'consequence'=>$consequence,'anomaly'=>$anomaly,'confidence'=>$confidence,'urgency'=>$urgency,
                'reversibility'=>70,'financial_exposure'=>$domain==='financial' ? $consequence : 0,'physical_impact'=>0,
                'environmental_impact'=>$domain==='environmental' ? $consequence : 0,'dependency'=>30,'domains'=>[$domain],
            ],
            'observation'=>['summary'=>$summary,'confidence'=>$confidence],
        ],
        $id,'2026-09-04T07:15:00Z','2026-09-04T07:15:01Z'
    );
};

$ingest->ingest($make('sec','company_a','security','Suspicious credential use',85,80,90,70,95,'identity'));
$ingest->ingest($make('money','company_a','financial','Large overdue invoice exposure',60,88,30,90,75,'invoice'));
$ingest->ingest($make('work','company_a','workforce','Worker scheduling conflict',45,55,40,92,60,'worker'));
$ingest->ingest($make('env','company_b','environmental','Unexpected water consumption',55,78,82,65,80,'resource'));
$ingest->ingest($make('cust','company_b','customer','Customer complaint escalation',50,72,70,88,85,'customer'));
$ingest->ingest($make('infra','company_a','infrastructure','Database replica unhealthy',75,86,75,80,90,'server'));

$seeded = $views->ensureCanonicalPersistentViews('T0GM_OWNER','2026-09-04T07:16:00Z');
dvAssert(count($seeded) === 7,'seven canonical persistent intelligence views');
dvAssert(array_values(array_unique(array_column($seeded,'lifecycle'))) === ['persistent'],'canonical views are persistent');
dvAssert(array_column($seeded,'category') === ['security','money','workforce','environment','customers','infrastructure','critical'],'canonical categories exact');

afterSeed:
$reopened = new FileDynamicIntelligenceViewStore($tmp);
dvAssert(count($reopened->all()) === 7,'persistent views survive store reconstruction');

$security = $views->render('security',$sovereign,50,0);
dvAssert($security['view']['category'] === 'security','security view resolved');
dvAssert(array_column($security['items'],'event_id') === ['sec'],'security filters governed feed');
dvAssert($security['projection_only'] === true && $security['execution_authority_granted'] === false,'views do not grant authority');

$money = $views->render('money',$sovereign,50,0);
dvAssert(in_array('money',array_column($money['items'],'event_id'),true),'money view generated');
$work = $views->render('workforce',$sovereign,50,0);
dvAssert(in_array('work',array_column($work['items'],'event_id'),true),'workforce view generated');
$env = $views->render('environment',$sovereign,50,0);
dvAssert(in_array('env',array_column($env['items'],'event_id'),true),'environment view generated');
$cust = $views->render('customers',$sovereign,50,0);
dvAssert(in_array('cust',array_column($cust['items'],'event_id'),true),'customers view generated');
$infra = $views->render('infrastructure',$sovereign,50,0);
dvAssert(in_array('infra',array_column($infra['items'],'event_id'),true),'infrastructure view generated');
$critical = $views->render('critical',$sovereign,50,0);
dvAssert(in_array('sec',array_column($critical['items'],'event_id'),true),'critical view includes materially critical event');
dvAssert(in_array('infra',array_column($critical['items'],'event_id'),true),'critical view includes urgent infrastructure event');

$temp = $views->createTemporaryView([
    'view_id'=>'temp-company-b-anomalies',
    'name'=>'Company B anomalies',
    'category'=>'environment',
    'filters'=>['company_ids'=>['company_b'],'min_anomaly'=>75],
    'extinction_conditions'=>['incident_resolved','t0gm_dismissed'],
    'reason'=>'Investigate current Company B anomaly cluster',
], 'oversight-ai-security', '2026-09-04T07:16:10Z');
dvAssert($temp['lifecycle'] === 'temporary','temporary intelligence view lifecycle');
dvAssert($temp['authority_granted'] === false,'temporary view creation grants no authority');
$tempRendered = $views->render('temp-company-b-anomalies',$sovereign,50,0);
dvAssert(array_column($tempRendered['items'],'event_id') === ['env'],'temporary filters compose over home feed');

$views->extinguishTemporaryView('temp-company-b-anomalies','incident_resolved','T0GM_OWNER','2026-09-04T07:17:00Z');
dvExpect('dynamic-view-inactive', fn() => $views->render('temp-company-b-anomalies',$sovereign,50,0));

dvExpect('legacy-tenant-boundary-forbidden', fn() => $views->createTemporaryView([
    'view_id'=>'bad','name'=>'bad','category'=>'security','filters'=>['tenant_id'=>'legacy'],'extinction_conditions'=>['dismissed']
], 'oversight-ai', '2026-09-04T07:18:00Z'));

dvExpect('temporary-view-extinction-required', fn() => $views->createTemporaryView([
    'view_id'=>'no-extinction','name'=>'No extinction','category'=>'security','filters'=>[],'extinction_conditions'=>[]
], 'oversight-ai', '2026-09-04T07:18:00Z'));

@unlink($tmp);
echo "PASS seven canonical persistent intelligence views\n";
echo "PASS durable view definitions across store reconstruction\n";
echo "PASS security/money/workforce/environment/customers/infrastructure/critical projections\n";
echo "PASS temporary intelligence views with explicit extinction conditions\n";
echo "PASS company_id-only filtering and legacy tenant rejection\n";
echo "PASS projection-only views grant no execution authority\n";
