<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\Oversight\ModelBackedOversightReviewer; use Titan\GodMode\Oversight\T0gmOversightDisposition; use Titan\GodMode\Oversight\T0gmOversightSpecialist;
function n18($c,$m){if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);} 
$model=function(array $input){return ['disposition'=>'investigate','confidence'=>81,'reason_codes'=>['MODEL_SECURITY_CONCERN'],'evidence_refs'=>['ev-1'],'recommended_actions'=>['inspect'],'limitations'=>['uncertain-external-state']];};
$r=new ModelBackedOversightReviewer(T0gmOversightSpecialist::SECURITY,$model,'model.security.v1'); $a=$r->review(['event_id'=>'evt-18'],['signals'=>[]]);
n18($a->disposition===T0gmOversightDisposition::INVESTIGATE,'model disposition retained'); n18($a->reviewModelVersion==='model.security.v1','model provenance retained'); n18(in_array('MODEL_OUTPUT_IS_ADVISORY_AND_NON_AUTHORITATIVE',$a->limitations,true),'non-authority boundary explicit');
echo "PASS T0GM Step18 model-backed oversight team\n";
