<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\Identity\T0gmCryptoSuiteRegistry;
use Titan\GodMode\Identity\T0gmVerifierTrustStore;
use Titan\GodMode\Identity\T0gmHardwareAttestation;
use Titan\GodMode\Identity\T0gmIdentityRoot;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;
use Titan\GodMode\Support\InMemoryNonceStore;

function irAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function irExpect(string $reason, callable $fn):void{try{$fn();}catch(GodModeException $e){irAssert($e->reason===$reason,"expected $reason got {$e->reason}");return;}throw new RuntimeException("expected failure:$reason");}
function irSign(array $payload,string $secret):string{return base64_encode(sodium_crypto_sign_detached(CanonicalJson::encode($payload),$secret));}

$now=time();
$root=sodium_crypto_sign_keypair(); $rootSecret=sodium_crypto_sign_secretkey($root); $rootPublic=sodium_crypto_sign_publickey($root);
$att=sodium_crypto_sign_keypair(); $attSecret=sodium_crypto_sign_secretkey($att); $attPublic=sodium_crypto_sign_publickey($att);
$device=sodium_crypto_sign_keypair(); $devicePublic=sodium_crypto_sign_publickey($device);
$challenge=bin2hex(random_bytes(24));
$policy=['authority'=>'titan.god_mode','principal_class'=>'builder_control_plane_principal','principal_id'=>'OWNER_CONTROL_PLANE_PRINCIPAL','audience'=>'titan-builder-control-plane','clock_skew_seconds'=>30];
$payload=['schema'=>'titan.t0gm.identity_root_proof.v1','authority'=>'titan.god_mode','principal_class'=>'builder_control_plane_principal','principal_id'=>'OWNER_CONTROL_PLANE_PRINCIPAL','device_key_id'=>'hw-device-01','device_public_key'=>base64_encode($devicePublic),'audience'=>'titan-builder-control-plane','challenge'=>$challenge,'issued_at'=>$now,'proof_expires_at'=>$now+60,'non_tenant'=>true];
$attPayload=['schema'=>'titan.t0gm.hardware_attestation.v1','device_key_id'=>'hw-device-01','device_public_key_hash'=>hash('sha256',$devicePublic),'hardware_backed'=>true,'hardware_class'=>'test-secure-hardware','challenge'=>$challenge,'measurement'=>'boot-state:verified','issued_at'=>$now,'evidence_hash'=>hash('sha256','attestation-evidence')];
$proof=['payload'=>$payload,'root_key_id'=>'identity-root-01','signature_suite'=>'ed25519','root_signature'=>irSign($payload,$rootSecret),'hardware_attestation'=>['payload'=>$attPayload,'attestation_key_id'=>'att-root-01','signature_suite'=>'ed25519','signature'=>irSign($attPayload,$attSecret)]];
$crypto=new T0gmCryptoSuiteRegistry();
$idStore=new T0gmVerifierTrustStore(['identity-root-01'=>['suite'=>'ed25519','public_key'=>base64_encode($rootPublic)]]);
$attStore=new T0gmVerifierTrustStore(['att-root-01'=>['suite'=>'ed25519','public_key'=>base64_encode($attPublic)]]);
$identity=new T0gmIdentityRoot($idStore,new T0gmHardwareAttestation($attStore,$crypto),$crypto,new InMemoryNonceStore(),$policy);
$d=$identity->verify($proof,$now);
irAssert($d['authority_class']==='titan.god_mode','cryptographic authority class');
irAssert($d['hardware_attestation']['hardware_backed']===true,'hardware proof required');
irAssert($d['application_role_authority']===false,'not role authority');
irAssert($d['signature_suite']==='ed25519','suite recorded');

irExpect('identity-proof-replay-detected',fn()=>$identity->verify($proof,$now));
$bad=$proof; $bad['payload']['role_id']='super_admin'; $bad['root_signature']=irSign($bad['payload'],$rootSecret); $bad['payload']['challenge']=bin2hex(random_bytes(24));
irExpect('application-identity-binding-forbidden:role_id',fn()=>$identity->verify($bad,$now));
$badHw=$proof; $badHw['payload']['challenge']=bin2hex(random_bytes(24)); $badHw['root_signature']=irSign($badHw['payload'],$rootSecret); $badHw['hardware_attestation']['payload']['challenge']=$badHw['payload']['challenge']; $badHw['hardware_attestation']['payload']['hardware_backed']=false; $badHw['hardware_attestation']['signature']=irSign($badHw['hardware_attestation']['payload'],$attSecret);
irExpect('hardware-backed-proof-required',fn()=>$identity->verify($badHw,$now));
$wrongDevice=$proof; $wrongDevice['payload']['challenge']=bin2hex(random_bytes(24)); $wrongDevice['root_signature']=irSign($wrongDevice['payload'],$rootSecret); $wrongDevice['hardware_attestation']['payload']['challenge']=$wrongDevice['payload']['challenge']; $wrongDevice['hardware_attestation']['payload']['device_key_id']='other-device'; $wrongDevice['hardware_attestation']['signature']=irSign($wrongDevice['hardware_attestation']['payload'],$attSecret);
irExpect('attested-device-key-mismatch',fn()=>$identity->verify($wrongDevice,$now));
$unknownSuite=$proof; $unknownSuite['payload']['challenge']=bin2hex(random_bytes(24)); $unknownSuite['root_signature']=irSign($unknownSuite['payload'],$rootSecret); $unknownSuite['signature_suite']='future-pqc-suite';
irExpect('identity-root-suite-key-mismatch',fn()=>$identity->verify($unknownSuite,$now));


// Integrated identity-root -> request-proof gate. Use a fresh challenge because identity proofs are one-use.
use Titan\GodMode\Identity\T0gmIdentityAccessGate;
use Titan\GodMode\Support\ArrayAuditSink;
$freshChallenge=bin2hex(random_bytes(24));
$freshPayload=$payload; $freshPayload['challenge']=$freshChallenge;
$freshAtt=$attPayload; $freshAtt['challenge']=$freshChallenge;
$freshProof=['payload'=>$freshPayload,'root_key_id'=>'identity-root-01','signature_suite'=>'ed25519','root_signature'=>irSign($freshPayload,$rootSecret),'hardware_attestation'=>['payload'=>$freshAtt,'attestation_key_id'=>'att-root-01','signature_suite'=>'ed25519','signature'=>irSign($freshAtt,$attSecret)]];
$requestPayload=['schema'=>'titan.god_mode.request_proof.v1','authority'=>'titan.god_mode','principal_id'=>'OWNER_CONTROL_PLANE_PRINCIPAL','device_key_id'=>'hw-device-01','audience'=>'titan-builder-control-plane','nonce'=>bin2hex(random_bytes(24)),'issued_at'=>$now,'expires_at'=>$now+30,'purpose'=>'Verify identity-root access chain','action'=>'platform.recovery.inspect','target'=>['scope'=>'company','company_id'=>'company_123']];
$deviceSecret=sodium_crypto_sign_secretkey($device);
$request=['payload'=>$requestPayload,'device_signature'=>irSign($requestPayload,$deviceSecret)];
$idNonces=new InMemoryNonceStore();
$rootForGate=new T0gmIdentityRoot($idStore,new T0gmHardwareAttestation($attStore,$crypto),$crypto,$idNonces,$policy);
$audit=new ArrayAuditSink();
$gate=new T0gmIdentityAccessGate($rootForGate,new InMemoryNonceStore(),$audit,$policy);
$authorized=$gate->authorize($freshProof,$request,['role_grants'=>['super_admin'],'permissions'=>['company.manage']],$now);
irAssert($authorized['identity_root']['hardware_backed']===true,'integrated gate retains hardware proof');
irAssert($authorized['target']['company_id']==='company_123','company authority remains request/capability target not identity root');
irAssert(count($audit->events)===1,'identity-root authorization audited');

echo "PASS T0GM cryptographic identity root distinct from application roles\n";
echo "PASS hardware-backed device attestation binding\n";
echo "PASS identity proof replay rejection\n";
echo "PASS crypto-suite metadata and fail-closed verifier selection\n";
