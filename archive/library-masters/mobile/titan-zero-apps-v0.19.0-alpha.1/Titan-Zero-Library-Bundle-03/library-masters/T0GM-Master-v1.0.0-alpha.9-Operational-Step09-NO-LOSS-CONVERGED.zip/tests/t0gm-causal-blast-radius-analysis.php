<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\Causal\T0gmCausalBlastRadiusAnalyzer;
use Titan\GodMode\Causal\T0gmProspectiveCausalGraph;
use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedIngestor;
use Titan\GodMode\Store\InMemorySovereignActivityStore;

function brAssert($condition,string $message): void { if(!$condition) throw new RuntimeException('ASSERTION FAILED: '.$message); }
function brThrows(callable $fn,string $message): void { try { $fn(); } catch (Throwable $e) { return; } throw new RuntimeException('ASSERTION FAILED: '.$message); }

$graph = new T0gmProspectiveCausalGraph();
$graph->addNode(['node_id'=>'action.deploy','node_type'=>'action','company_id'=>'company-a','system'=>'titan.deploy','worker_id'=>null,'decision_id'=>'decision-deploy','risk_score'=>72]);
$graph->addNode(['node_id'=>'service.crm','node_type'=>'system','company_id'=>'company-a','system'=>'crm','worker_id'=>null,'decision_id'=>null,'risk_score'=>40]);
$graph->addNode(['node_id'=>'decision.invoice','node_type'=>'decision','company_id'=>'company-b','system'=>'billing','worker_id'=>null,'decision_id'=>'decision-invoice','risk_score'=>65]);
$graph->addNode(['node_id'=>'worker.field-7','node_type'=>'worker','company_id'=>'company-b','system'=>'workforce','worker_id'=>'field-7','decision_id'=>null,'risk_score'=>55]);
$graph->addNode(['node_id'=>'system.customer','node_type'=>'system','company_id'=>'company-b','system'=>'customer-portal','worker_id'=>null,'decision_id'=>null,'risk_score'=>30]);
$graph->addEdge('action.deploy','service.crm','causes',0.98);
$graph->addEdge('service.crm','decision.invoice','depends_on',0.85);
$graph->addEdge('decision.invoice','worker.field-7','triggers',0.72);
$graph->addEdge('worker.field-7','system.customer','causes',0.90);
$graph->addEdge('system.customer','service.crm','correlates_with',1.0); // must not create causal cycle

$analyzer = new T0gmCausalBlastRadiusAnalyzer();
$forecast = $analyzer->forecast('action.deploy',$graph,6);
brAssert($forecast->phase === 'forecast','forecast phase recorded');
brAssert($forecast->rootId === 'action.deploy','forecast root retained');
brAssert($forecast->maxDepth === 4,'deepest causal path measured');
brAssert($forecast->affectedCompanies === ['company-a','company-b'],'cross-company impact identified deterministically');
brAssert(in_array('billing',$forecast->affectedSystems,true) && in_array('workforce',$forecast->affectedSystems,true),'downstream systems identified');
brAssert($forecast->affectedWorkers === ['field-7'],'downstream worker identified');
brAssert($forecast->affectedDecisions === ['decision-deploy','decision-invoice'],'root and downstream decisions identified');
brAssert($forecast->crossCompany === true,'cross-company blast radius surfaced');
brAssert($forecast->authorityGranted === false,'analysis does not grant authority');
brAssert($forecast->paths !== [],'causal paths retained as evidence');

$store = new InMemorySovereignActivityStore();
$ingest = new T0gmFeedIngestor($store);
$factory = new T0gmEventFactory();
$access = T0gmFeedAccessContext::sovereign('jason');
$make = function(string $id,string $kind,?string $cause,string $company,string $system,array $details,array $actor=[]) use ($factory) {
    return $factory->make(
        $kind,
        ['scope'=>'company','company_id'=>$company],
        array_merge(['actor_type'=>'system','actor_id'=>'runtime','authority_class'=>'system'], $actor),
        ['system'=>$system,'component'=>'blast-radius-test'],
        ['subject_type'=>'deployment','subject_id'=>'deploy-1'],
        ['trace_id'=>'trace-br','correlation_id'=>'corr-br','causation_id'=>$cause,'parent_event_ids'=>$cause ? [$cause] : []],
        ['score'=>50,'band'=>'medium','dimensions'=>['operational'=>50]],
        ['visibility'=>'t0gm_sovereign','attention_tier'=>'important','review_required'=>false,'review_team'=>[]],
        [],
        $details,
        $id,
        '2026-09-03T00:00:00Z','2026-09-03T00:00:01Z'
    );
};
$events = [
    $make('evt-root',T0gmEventKind::EXECUTION,null,'company-a','titan.deploy',['execution'=>['execution_id'=>'x-root','state'=>'completed','adapter'=>'deploy-adapter']]),
    $make('evt-crm',T0gmEventKind::EXECUTION,'evt-root','company-a','crm',['execution'=>['execution_id'=>'x-crm','state'=>'completed','adapter'=>'crm-adapter']]),
    $make('evt-invoice',T0gmEventKind::AI_DECISION,'evt-crm','company-b','billing',['decision'=>['decision_id'=>'decision-invoice','determination'=>'recalculate invoice','reason_codes'=>['UPSTREAM_CHANGE']]]),
    $make('evt-worker',T0gmEventKind::EXECUTION,'evt-invoice','company-b','workforce',['execution'=>['execution_id'=>'x-worker','state'=>'running','adapter'=>'workforce-adapter']],['actor_type'=>'advanced_intelligence','actor_id'=>'field-ai-7','worker_id'=>'field-7','authority_class'=>'staff']),
    $make('evt-unexpected',T0gmEventKind::OBSERVATION,'evt-worker','company-b','inventory',['observation'=>['summary'=>'inventory reservation changed unexpectedly']]),
];
foreach($events as $event) $ingest->ingest($event);
$observed = $analyzer->observe('evt-root',$store,$access,6);
brAssert($observed->phase === 'observed','observed phase recorded');
brAssert($observed->crossCompany === true,'observed cross-company impact surfaced');
brAssert(in_array('inventory',$observed->affectedSystems,true),'unexpected actual system included');
brAssert(in_array('field-7',$observed->affectedWorkers,true),'actual worker consequence included');

$comparison = $analyzer->compare($forecast,$observed,[
    'action.deploy'=>'evt-root',
    'service.crm'=>'evt-crm',
    'decision.invoice'=>'evt-invoice',
    'worker.field-7'=>'evt-worker',
]);
brAssert(in_array('evt-unexpected',$comparison['unexpected_observed_ids'],true),'unforecast consequence preserved and surfaced');
brAssert($comparison['forecast_rewritten'] === false,'forecast history is not rewritten after the fact');
brAssert($comparison['authority_granted'] === false,'comparison does not grant authority');

brThrows(function() use ($graph) { $graph->addEdge('system.customer','action.deploy','causes',0.8); }, 'causal cycle rejected rather than recursively amplifying blast radius');

echo "PASS T0GM Step20 causal blast-radius analysis\n";
echo "PASS forecast and observed consequence graphs remain distinct and comparable\n";
echo "PASS cross-system, cross-company, worker and decision impacts traced\n";
echo "PASS correlation excluded from causal propagation and causal cycles fail closed\n";
echo "PASS blast-radius analysis is evidence, not an authority source\n";
