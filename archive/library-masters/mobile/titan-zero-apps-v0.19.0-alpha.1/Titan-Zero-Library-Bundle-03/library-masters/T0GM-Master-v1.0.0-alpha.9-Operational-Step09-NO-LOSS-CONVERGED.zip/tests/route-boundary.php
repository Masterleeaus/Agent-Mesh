<?php
require __DIR__ . '/bootstrap.php';
use Titan\GodMode\Support\GodModeRouteBoundary;

GodModeRouteBoundary::assertNotTenantRoute('/_titan-control-plane/god-mode/recovery');
foreach (['/company/12/god-mode','/tenant/12/god-mode','/admin/roles/god-mode','/admin/permissions/god-mode'] as $bad) {
    try {
        GodModeRouteBoundary::assertNotTenantRoute($bad);
        throw new RuntimeException("expected reject:$bad");
    } catch (RuntimeException $e) {
        if ($e->getMessage() === "expected reject:$bad") throw $e;
    }
}
echo "PASS dedicated control-plane route boundary\n";
