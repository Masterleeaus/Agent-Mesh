<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Contracts\ZeroKnowledgeProverBroker;
use Titan\GodMode\Identity\BrokeredRistretto255SchnorrProver;
use Titan\GodMode\Identity\Ristretto255SchnorrProof;
use Titan\GodMode\Identity\Ristretto255SchnorrVerifier;
use Titan\GodMode\Identity\T0gmZeroKnowledgeProofGate;
use Titan\GodMode\Identity\T0gmZeroKnowledgeProviderRegistry;
use Titan\GodMode\Identity\T0gmCryptoProfileRegistry;
use Titan\GodMode\Security\GodModeException;

function zkAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function zkExpect(string $reason, callable $fn):void{try{$fn();}catch(GodModeException $e){zkAssert($e->reason===$reason,"expected $reason got {$e->reason}");return;}throw new RuntimeException("expected failure:$reason");}

final class TestZkBroker implements ZeroKnowledgeProverBroker {
    public array $lastRequest=[];
    public function __construct(private readonly array $witnesses) {}
    public function prove(string $providerId,string $witnessRef,array $publicStatement,array $context=[]): string {
        $this->lastRequest=['provider_id'=>$providerId,'witness_ref'=>$witnessRef,'public_statement'=>$publicStatement,'context'=>$context];
        if(!isset($this->witnesses[$witnessRef])) throw new RuntimeException('test-witness-not-found');
        return Ristretto255SchnorrProof::create($this->witnesses[$witnessRef],$publicStatement,$context);
    }
}

$secret=sodium_crypto_core_ristretto255_scalar_reduce(random_bytes(64));
$public=sodium_crypto_scalarmult_ristretto255_base($secret);
$statement=[
    'authority'=>'titan.god_mode',
    'principal_id'=>'OWNER_CONTROL_PLANE_PRINCIPAL',
    'device_key_id'=>'hw-device-zk-01',
    'audience'=>'titan-builder-control-plane',
    'challenge'=>bin2hex(random_bytes(24)),
    'claim'=>'sovereign-secret-possession-without-secret-disclosure',
    'possession_public_key'=>base64_encode($public),
];

$broker=new TestZkBroker(['t0gm-witness://device/hw-device-zk-01'=>$secret]);
$prover=new BrokeredRistretto255SchnorrProver($broker,'libsodium-ristretto255-schnorr-v1','t0gm-witness://device/hw-device-zk-01');
$verifier=new Ristretto255SchnorrVerifier('libsodium-ristretto255-schnorr-v1');
$registry=new T0gmZeroKnowledgeProviderRegistry(['t0gm-zk-sovereign-possession-v1'=>$verifier]);
$gate=new T0gmZeroKnowledgeProofGate($registry->verifiers());
$profiles=new T0gmCryptoProfileRegistry();
$productionProfile=$profiles->profile(T0gmCryptoProfileRegistry::HYBRID_PQC_ZK_V2);
zkAssert($productionProfile['allowed_zk_systems']===['t0gm-zk-ristretto255-schnorr-v1'],'production profile selects real Ristretto255 proof system');
zkAssert(($productionProfile['zk_public_key_payload_field']??'')==='zk_possession_public_key','production profile requires signed ZK public-key binding');

$opaque=$prover->prove($statement,['proof_system'=>'t0gm-zk-sovereign-possession-v1']);
zkAssert(!str_contains($opaque,base64_encode($secret)),'proof must not contain witness bytes');
zkAssert(($broker->lastRequest['witness_ref']??'')==='t0gm-witness://device/hw-device-zk-01','application passes only witness reference to prover broker');
zkAssert(!array_key_exists('witness',$broker->lastRequest),'broker request does not transport witness through Titan application');

$envelope=['proof_system'=>'t0gm-zk-sovereign-possession-v1','proof'=>base64_encode($opaque),'public_statement'=>$statement];
$result=$gate->verify($envelope,$statement,['t0gm-zk-sovereign-possession-v1']);
zkAssert($result['verified']===true,'real Ristretto255 Schnorr proof verifies');
zkAssert($result['verifier_id']==='libsodium-ristretto255-schnorr-v1','production verifier identity retained');
zkAssert($result['proof_system']==='t0gm-zk-sovereign-possession-v1','logical proof-system binding retained');
zkAssert(!isset($result['company_id'])&&($result['authority_granted']??null)===false,'ZK result explicitly does not create company or execution authority');

$tampered=$statement; $tampered['challenge']=bin2hex(random_bytes(24));
zkExpect('zk-public-statement-mismatch',fn()=>$gate->verify($envelope,$tampered,['t0gm-zk-sovereign-possession-v1']));

$bad=$envelope; $raw=base64_decode($bad['proof'],true); $raw[10]=chr(ord($raw[10])^1); $bad['proof']=base64_encode($raw);
zkExpect('zero-knowledge-proof-invalid',fn()=>$gate->verify($bad,$statement,['t0gm-zk-sovereign-possession-v1']));

$wrongSecret=sodium_crypto_core_ristretto255_scalar_reduce(random_bytes(64));
$wrongBroker=new TestZkBroker(['t0gm-witness://wrong'=>$wrongSecret]);
$wrongProver=new BrokeredRistretto255SchnorrProver($wrongBroker,'libsodium-ristretto255-schnorr-v1','t0gm-witness://wrong');
try { $wrongProver->prove($statement,['proof_system'=>'t0gm-zk-sovereign-possession-v1']); throw new RuntimeException('expected witness/public-key mismatch'); }
catch (GodModeException $e) { zkAssert($e->reason==='zk-witness-public-key-mismatch','wrong witness rejected before proof issuance'); }

echo "PASS real Ristretto255 Schnorr zero-knowledge proof verification\n";
echo "PASS brokered prover keeps sovereign witness out of Titan application proof flow\n";
echo "PASS replaceable provider remains behind ZeroKnowledgeVerifier abstraction\n";
echo "PASS ZK proof cannot create company or execution authority\n";
