<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\Notification\FilePersistentNotificationStateStore;
use Titan\GodMode\Notification\T0gmPersistentNotificationOrchestrator;
function n17($c,$m){if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);} 
$dir=sys_get_temp_dir().'/t0gm-notify-'.bin2hex(random_bytes(4));
$s=new FilePersistentNotificationStateStore($dir); $o=new T0gmPersistentNotificationOrchestrator($s);
$base=['notification_id'=>'n-1','event_id'=>'evt-1','company_id'=>'company-a','severity'=>'critical','endpoints'=>[['endpoint_id'=>'device-1','channel'=>'push'],['endpoint_id'=>'sms-1','channel'=>'sms']],'created_at'=>'2026-09-03T00:00:00Z'];
$a=$o->register($base); n17($a['status']==='pending','registered pending');
$a=$o->recordAttempt('n-1','device-1',false,'2026-09-03T00:00:01Z','2026-09-03T00:01:00Z','offline'); n17($a['status']==='retry_pending','failure persisted for retry');
unset($o,$s); $s2=new FilePersistentNotificationStateStore($dir); $o2=new T0gmPersistentNotificationOrchestrator($s2); n17(count($o2->due('2026-09-03T00:01:01Z'))===1,'retry survives orchestrator recreation');
$a=$o2->escalate('n-1','critical-unacknowledged','2026-09-03T00:01:02Z',[['endpoint_id'=>'sms-1']]); n17($a['escalation_level']===1,'escalation durable');
$a=$o2->acknowledge('n-1',['actor_id'=>'jason','device_id'=>'device-2','channel'=>'push','acknowledged_at'=>'2026-09-03T00:01:03Z']); n17($a['status']==='acknowledged','ack persisted'); n17(count($o2->due('2026-09-03T01:00:00Z'))===0,'ack stops retry');
$b=$o2->register($base); n17($b['notification_id']==='n-1','duplicate registration idempotent');
echo "PASS T0GM Step17 persistent notification state\n";
