<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\Capability\SovereignCapabilityFactory;
use Titan\GodMode\Continuance\AuthorityContinuanceEngine;
use Titan\GodMode\Continuance\AuthorityContinuanceOutcome;

function acAssert($condition,string $message): void { if(!$condition) throw new RuntimeException('ASSERTION FAILED: '.$message); }

$factory = new SovereignCapabilityFactory();
$cap = $factory->create([
    'authority_holder'=>['identity_id'=>'t0gm-human-1','authority_class'=>'titan.god_mode','actor_type'=>'human'],
    'authority_basis'=>['basis_type'=>'titan_managed','basis_id'=>'agreement-7','description'=>'Managed recovery authority'],
    'company_id'=>'company-123',
    'purpose'=>['purpose_id'=>'recover-1','statement'=>'Recover verified state','intended_outcome'=>'Verified recovery'],
    'target'=>['target_type'=>'database','target_id'=>'crm-prod','system'=>'titan.crm','environment'=>'production','resource_ids'=>['customer-9']],
    'permitted_effects'=>[
        ['effect_id'=>'read','operation'=>'customer.read','resource_type'=>'customer','resource_ids'=>['customer-9'],'constraints'=>[]],
        ['effect_id'=>'restore','operation'=>'customer.restore','resource_type'=>'customer','resource_ids'=>['customer-9'],'constraints'=>[]],
    ],
    'prohibited_effects'=>[['operation'=>'customer.delete','reason'=>'outside purpose']],
    'evidence'=>[['evidence_id'=>'ev-1','evidence_type'=>'incident','source'=>'t0gm.feed','integrity_ref'=>'sha256:abc']],
    'risk_constraints'=>['max_risk_score'=>70,'max_financial_exposure'=>20,'max_physical_impact'=>0,'max_environmental_impact'=>0,'prohibited_risk_bands'=>['extreme']],
    'extinction_conditions'=>array_map(fn($t)=>['condition_id'=>'ext-'.$t,'condition_type'=>$t,'description'=>'Extinguish when '.$t], ['purpose_invalid','authority_revoked','company_changed','target_changed','risk_constraint_breached','safety_interlock','superseded','t0gm_extinguish']),
]);
$engine = new AuthorityContinuanceEngine();
$healthy = [
    'company_id'=>'company-123','purpose_valid'=>true,'authority_basis_valid'=>true,'target_valid'=>true,
    'evidence_valid'=>true,'risk_acceptable'=>true,'safety_satisfied'=>true,'contractual_scope_valid'=>true,
    'jurisdiction_valid'=>true,'execution_path_legitimate'=>true,'dependencies_healthy'=>true,
];
acAssert($engine->evaluate($cap,$healthy)->outcome === AuthorityContinuanceOutcome::CONTINUE,'healthy live state continues');

$runtimeMissing=$healthy; $runtimeMissing['runtime_integrity_required']=true; $runtimeMissing['runtime_integrity_valid']=false;
acAssert($engine->evaluate($cap,$runtimeMissing)->outcome === AuthorityContinuanceOutcome::PAUSE,'runtime integrity uncertainty pauses live authority');
$runtimeValid=$healthy; $runtimeValid['runtime_integrity_required']=true; $runtimeValid['runtime_integrity_valid']=true;
acAssert($engine->evaluate($cap,$runtimeValid)->outcome === AuthorityContinuanceOutcome::CONTINUE,'verified runtime integrity permits continuance');
$narrow = $healthy; $narrow['retained_effect_ids']=['read'];
$d = $engine->evaluate($cap,$narrow);
acAssert($d->outcome === AuthorityContinuanceOutcome::NARROW && $d->retainedEffectIds === ['read'],'narrow only retains subset');
$pause = $healthy; $pause['safety_satisfied']=false;
acAssert($engine->evaluate($cap,$pause)->outcome === AuthorityContinuanceOutcome::PAUSE,'safety uncertainty pauses');
$transform = $healthy; $transform['transformation_required']=true; $transform['requested_effect_ids']=['restore'];
$d = $engine->evaluate($cap,$transform);
acAssert($d->outcome === AuthorityContinuanceOutcome::TRANSFORM,'changed authority shape transforms');
acAssert(($d->transformationRequest['requires_fresh_sovereign_authorization'] ?? false) === true,'transform requires fresh authority');
$terminate = $healthy; $terminate['purpose_valid']=false;
acAssert($engine->evaluate($cap,$terminate)->outcome === AuthorityContinuanceOutcome::TERMINATE,'invalid purpose terminates');
$wrongCompany = $healthy; $wrongCompany['company_id']='company-999';
acAssert($engine->evaluate($cap,$wrongCompany)->outcome === AuthorityContinuanceOutcome::TERMINATE,'company boundary change terminates');

echo "PASS Authority Continuance continue/narrow/pause/transform/terminate semantics\n";
