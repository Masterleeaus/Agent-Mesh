<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Channel\OpenSslMlKemEngine;
use Titan\GodMode\Channel\SodiumX25519Engine;
use Titan\GodMode\Channel\T0gmHybridSessionEstablisher;
use Titan\GodMode\Identity\T0gmCryptoProfileRegistry;
use Titan\GodMode\Security\GodModeException;

function hsAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function hsExpect(string $reason,callable $fn):void{try{$fn();}catch(GodModeException $e){hsAssert(str_starts_with($e->reason,$reason),"expected $reason got {$e->reason}");return;}throw new RuntimeException("expected failure:$reason");}
function hsRun(array $cmd):void{$s=[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']];$p=proc_open($cmd,$s,$pipes);if(!is_resource($p))throw new RuntimeException('proc-open-failed');fclose($pipes[0]);stream_get_contents($pipes[1]);fclose($pipes[1]);$e=stream_get_contents($pipes[2]);fclose($pipes[2]);$c=proc_close($p);if($c!==0)throw new RuntimeException("command-failed:$e");}

$dir=sys_get_temp_dir().'/t0gm-hybrid-test-'.bin2hex(random_bytes(8));mkdir($dir,0700,true);
$priv="$dir/mlkem-private.pem";$pub="$dir/mlkem-public.pem";
hsRun(['openssl','genpkey','-algorithm','ML-KEM-768','-out',$priv]);
hsRun(['openssl','pkey','-in',$priv,'-pubout','-out',$pub]);
$svc=new T0gmHybridSessionEstablisher(new SodiumX25519Engine(),new OpenSslMlKemEngine());
$ctx=['session_id'=>'sess_'.bin2hex(random_bytes(16)),'initiator'=>'t0gm-device-01','responder'=>'t0gm-control-plane-01','purpose'=>'sovereign-control-plane'];
$offer=['crypto_profile_id'=>T0gmCryptoProfileRegistry::HYBRID_PQC_V1,'classical_kex'=>'x25519','pq_kem'=>'ml-kem-768','allow_classical_only'=>false,'allow_pq_only'=>false];
$init=$svc->initiate($ctx,$offer,file_get_contents($pub));
$accept=$svc->accept($ctx,$offer,$priv,$init['initiator_classical_public'],$init['pq_ciphertext']);
$final=$svc->finalizeInitiator($init,$accept['responder_classical_public']);
hsAssert(hash_equals($accept['session_key'],$final['session_key']),'both peers derive same hybrid session key');
hsAssert($accept['classical_component_hash']===$final['classical_component_hash'],'classical components match');
hsAssert($accept['pq_component_hash']===$final['pq_component_hash'],'PQC components match');
hsAssert($final['authority_granted']===false && $final['company_authority_granted']===false,'session crypto creates no authority');

$bad=$offer;$bad['pq_kem']='ml-kem-512';hsExpect('hybrid-pqc-downgrade-detected',fn()=>$svc->initiate($ctx,$bad,file_get_contents($pub)));
$bad=$offer;$bad['classical_kex']='p-256';hsExpect('hybrid-classical-downgrade-detected',fn()=>$svc->initiate($ctx,$bad,file_get_contents($pub)));
$bad=$offer;$bad['allow_classical_only']=true;hsExpect('hybrid-degraded-mode-forbidden',fn()=>$svc->initiate($ctx,$bad,file_get_contents($pub)));
$badCtx=$ctx;$badCtx['company_id']='company_123';hsExpect('hybrid-session-must-not-embed-authority:company_id',fn()=>$svc->initiate($badCtx,$offer,file_get_contents($pub)));
$mut=$init;$mut['negotiation']['negotiation_hash']=str_repeat('0',64);$changed=$svc->finalizeInitiator($mut,$accept['responder_classical_public']);
hsAssert(!hash_equals($changed['session_key'],$accept['session_key']),'negotiation transcript substitution changes session key');

@unlink($priv);@unlink($pub);@rmdir($dir);
echo "PASS X25519 + ML-KEM-768 hybrid session agreement\n";
echo "PASS hybrid transcript and negotiation are bound into key derivation\n";
echo "PASS classical/PQC downgrade and degraded modes fail closed\n";
echo "PASS hybrid session crypto does not create sovereign or company authority\n";
