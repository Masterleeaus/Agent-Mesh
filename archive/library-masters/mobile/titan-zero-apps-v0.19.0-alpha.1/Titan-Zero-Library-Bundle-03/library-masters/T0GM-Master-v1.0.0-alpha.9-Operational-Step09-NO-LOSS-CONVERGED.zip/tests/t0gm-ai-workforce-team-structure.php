<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\Workforce\T0gmCanonicalAiWorkforceRegistry;
use Titan\GodMode\Workforce\T0gmAiWorkforceTeamStructure;
use Titan\GodMode\Security\GodModeException;
function tsAssert($c,$m){if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);}
$r=new T0gmCanonicalAiWorkforceRegistry();
$r->register(['registry_id'=>'m','company_id'=>'co','kind'=>'model','name'=>'M']);
foreach(['sup','chall','inv','coord','spec'] as $id)$r->register(['registry_id'=>$id,'company_id'=>'co','kind'=>'worker','name'=>$id,'model_ids'=>['m']]);
$t=new T0gmAiWorkforceTeamStructure($r);
$team=$t->create('co',['team_id'=>'team-1','name'=>'Ops Review','team_type'=>'persistent','roles'=>['supervisor'=>['sup'],'challenger'=>['chall'],'investigator'=>['inv'],'coordinator'=>['coord'],'specialist'=>['spec']],'created_by'=>'t0gm-policy','revision'=>1]);
tsAssert(count($team['members'])===5,'members');
tsAssert($team['authority_aggregated']===false && $team['team_grants_authority']===false,'no authority aggregation');
tsAssert($t->membersByRole('co','team-1','challenger')===['chall'],'role lookup');
$mission=$t->create('co',['team_id'=>'mission-1','name'=>'Incident mission','team_type'=>'temporary_mission','mission'=>['objective'=>'investigate anomaly','extinction_conditions'=>['resolved','cancelled']],'roles'=>['supervisor'=>['sup'],'investigator'=>['inv'],'challenger'=>['chall']],'created_by'=>'t0gm-policy','revision'=>1]);
tsAssert($mission['temporary']===true && $mission['mission']['objective']==='investigate anomaly','mission team');
$closed=$t->closeMission('co','mission-1','resolved','t0gm-policy');
tsAssert($closed['status']==='closed' && $closed['authority_aggregated']===false,'mission close');
try{$t->create('co',['team_id'=>'bad','name'=>'bad','team_type'=>'persistent','roles'=>['supervisor'=>['missing']],'created_by'=>'t0gm','revision'=>1]);throw new RuntimeException('missing accepted');}catch(GodModeException $e){tsAssert(str_contains($e->getMessage(),'team-member-not-found'),'missing');}
try{$t->create('co',['team_id'=>'bad2','name'=>'bad','team_type'=>'persistent','roles'=>['supervisor'=>['sup']],'created_by'=>'sup','revision'=>1]);throw new RuntimeException('self team authority accepted');}catch(GodModeException $e){tsAssert($e->getMessage()==='ai-team-self-constitution-forbidden','self constitution');}
echo "PASS AI workforce teams support specialist/supervisor/challenger/investigator/coordinator roles\n";
echo "PASS temporary mission teams carry objectives and extinction conditions and can close cleanly\n";
echo "PASS team membership never aggregates, transfers or creates member authority\n";
