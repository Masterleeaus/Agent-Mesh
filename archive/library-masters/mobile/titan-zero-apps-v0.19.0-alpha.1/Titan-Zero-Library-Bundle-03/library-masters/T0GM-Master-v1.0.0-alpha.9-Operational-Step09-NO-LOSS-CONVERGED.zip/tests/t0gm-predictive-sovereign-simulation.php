<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\Causal\T0gmProspectiveCausalGraph; use Titan\GodMode\Simulation\T0gmPredictiveSovereignSimulator;
function n21($c,$m){if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);} 
$g=new T0gmProspectiveCausalGraph(); foreach([['root','action',20],['crm','system',30]] as [$id,$type,$risk])$g->addNode(['node_id'=>$id,'node_type'=>$type,'company_id'=>'company-a','system'=>$id,'risk_score'=>$risk]); $g->addEdge('root','crm','causes',.9);
$g2=new T0gmProspectiveCausalGraph(); foreach([['root','action',20],['crm','system',30],['billing','system',80]] as [$id,$type,$risk])$g2->addNode(['node_id'=>$id,'node_type'=>$type,'company_id'=>'company-a','system'=>$id,'risk_score'=>$risk]); $g2->addEdge('root','crm','causes',.9); $g2->addEdge('crm','billing','triggers',.7);
$r=(new T0gmPredictiveSovereignSimulator())->simulate('root','company-a',$g,[['scenario_id'=>'degraded-billing','graph'=>$g2,'assumptions'=>['billing_degraded'=>true]]]);
n21($r['executed']===false && $r['simulation_only']===true,'simulation never executes'); n21(count($r['scenarios'][0]['blast_radius']['affected_node_ids'])===3,'scenario expands predicted blast radius'); n21($r['grants_authority']===false,'simulation grants no authority');
echo "PASS T0GM Step21 predictive sovereign simulation\n";
