<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Identity\T0gmZkStatementMinimizer;
use Titan\GodMode\Identity\Ristretto255SchnorrProof;
use Titan\GodMode\Identity\Ristretto255SchnorrVerifier;
use Titan\GodMode\Identity\T0gmZeroKnowledgeProofGate;
use Titan\GodMode\Identity\T0gmCryptoProfileRegistry;

function zkmAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}

$secret=sodium_crypto_core_ristretto255_scalar_reduce(random_bytes(64));
$public=sodium_crypto_scalarmult_ristretto255_base($secret);
$payload=[
    'authority'=>'titan.god_mode',
    'principal_class'=>'builder_control_plane_principal',
    'principal_id'=>'OWNER_CONTROL_PLANE_PRINCIPAL',
    'device_key_id'=>'hw-device-sensitive-01',
    'device_public_key_hash'=>hash('sha256','device-public-key'),
    'audience'=>'titan-builder-control-plane',
    'challenge'=>bin2hex(random_bytes(24)),
    'crypto_profile_id'=>'t0gm-hybrid-pqc-zk-v2',
    'zk_possession_public_key'=>base64_encode($public),
];

$profiles=new T0gmCryptoProfileRegistry();
$profile=$profiles->profile(T0gmCryptoProfileRegistry::HYBRID_PQC_ZK_MIN_V3);
zkmAssert(($profile['zk_statement_policy']??'')==='minimal-authorization-v1','Step07 profile selects minimized statement policy');
$minimizer=new T0gmZkStatementMinimizer();
$statement=$minimizer->fromSovereignIdentity($payload,'zk_possession_public_key');

$forbidden=['authority','principal_class','principal_id','device_key_id','device_public_key_hash','audience','challenge','crypto_profile_id'];
foreach($forbidden as $field) zkmAssert(!array_key_exists($field,$statement),"minimal statement must not disclose $field");
zkmAssert(($statement['schema']??'')==='titan.t0gm.zk.minimal_authorization_statement.v1','minimal statement schema');
zkmAssert(($statement['claim']??'')==='sovereign-secret-possession-without-secret-disclosure','claim retained');
zkmAssert(isset($statement['authorization_context_digest'])&&strlen($statement['authorization_context_digest'])===64,'opaque authorization context digest retained');
zkmAssert(isset($statement['freshness_digest'])&&strlen($statement['freshness_digest'])===64,'freshness represented only as digest');
zkmAssert(($statement['possession_public_key']??'')===base64_encode($public),'verification key retained because current Schnorr proof requires it');

$json=json_encode($statement,JSON_THROW_ON_ERROR);
foreach(['OWNER_CONTROL_PLANE_PRINCIPAL','hw-device-sensitive-01','titan-builder-control-plane',$payload['challenge']] as $secretish) {
    zkmAssert(!str_contains($json,$secretish),'statement must not contain raw identity/device/context material');
}

$changed=$payload; $changed['device_key_id']='other-device';
zkmAssert($minimizer->fromSovereignIdentity($changed,'zk_possession_public_key')['authorization_context_digest']!==$statement['authorization_context_digest'],'hidden device binding must still affect opaque digest');
$changed=$payload; $changed['challenge']=bin2hex(random_bytes(24));
zkmAssert($minimizer->fromSovereignIdentity($changed,'zk_possession_public_key')['freshness_digest']!==$statement['freshness_digest'],'fresh challenge must still affect freshness digest');

$proof=Ristretto255SchnorrProof::create($secret,$statement,['proof_system'=>'t0gm-zk-ristretto255-schnorr-v1']);
$gate=new T0gmZeroKnowledgeProofGate(['t0gm-zk-ristretto255-schnorr-v1'=>new Ristretto255SchnorrVerifier()]);
$result=$gate->verify([
    'proof_system'=>'t0gm-zk-ristretto255-schnorr-v1',
    'proof'=>base64_encode($proof),
    'public_statement'=>$statement,
],$statement,['t0gm-zk-ristretto255-schnorr-v1']);
zkmAssert(($result['verified']??false)===true,'minimal statement remains cryptographically provable');
zkmAssert(($result['authority_granted']??null)===false,'minimal proof remains non-authoritative');

echo "PASS ZK statement reveals only proof-essential public facts and opaque bindings\n";
echo "PASS hidden identity/device/context changes remain cryptographically bound\n";
echo "PASS minimized statement remains verifiable and does not grant authority\n";
