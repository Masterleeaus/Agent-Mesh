<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedException;
use Titan\GodMode\Feed\T0gmFeedIngestor;
use Titan\GodMode\Feed\T0gmFeedQuery;
use Titan\GodMode\Feed\T0gmLineageFactory;
use Titan\GodMode\Store\InMemorySovereignActivityStore;
use Titan\GodMode\Store\PdoSovereignActivityStore;

function fAssert($condition, string $message): void {
    if (!$condition) throw new RuntimeException('ASSERTION FAILED: ' . $message);
}
function fExpect(string $reason, callable $fn): void {
    try { $fn(); } catch (T0gmFeedException $e) { fAssert($e->reason === $reason, "expected $reason got {$e->reason}"); return; }
    throw new RuntimeException('expected feed failure: ' . $reason);
}

$factory = new T0gmEventFactory();
$lineages = new T0gmLineageFactory();
$store = new InMemorySovereignActivityStore();
$ingest = new T0gmFeedIngestor($store);
$sovereign = T0gmFeedAccessContext::sovereign();
$companyA = new T0gmFeedAccessContext('oversight_a','t0gm.oversight_ai',['company_a'],false);
$companyB = new T0gmFeedAccessContext('oversight_b','t0gm.oversight_ai',['company_b'],false);
$platformAI = new T0gmFeedAccessContext('oversight_platform','t0gm.oversight_ai',[],true);

$make = function(string $eventId, string $companyId, string $kind, array $lineage, int $riskScore, string $attention, array $details, array $evidence = []) use ($factory) {
    return $factory->make(
        $kind,
        ['scope'=>'company','company_id'=>$companyId],
        ['actor_type'=>'advanced_intelligence','actor_id'=>'ai.'.$companyId,'authority_class'=>'delegated_ai'],
        ['system'=>'titan-signal','component'=>'t0gm-feed-adapter','version'=>'1.0.0-alpha.1'],
        ['subject_type'=>'operation','subject_id'=>'subject_'.$eventId],
        $lineage,
        ['score'=>$riskScore,'band'=>$riskScore >= 80 ? 'extreme' : ($riskScore >= 50 ? 'high' : 'low'),'dimensions'=>['cyber'=>$riskScore]],
        ['visibility'=>'t0gm_sovereign','attention_tier'=>$attention,'review_required'=>$riskScore >= 50,'review_team'=>['security']],
        $evidence,
        $details,
        $eventId,
        '2026-09-02T10:10:00Z',
        '2026-09-02T10:10:01Z'
    );
};

$l1 = $lineages->create('trace_a','corr_shared',null,[]);
$e1 = $make('evt_a1','company_a',T0gmEventKind::OBSERVATION,$l1,20,'routine',['observation'=>['summary'=>'Routine observation']],[[
    'evidence_id'=>'evidence_shared','evidence_type'=>'sensor_snapshot','source'=>'titan-shield','hash'=>'hash-a'
]]);
$r1 = $ingest->ingest($e1);
fAssert($r1['audit_sequence'] === 1, 'first sequence is one');
fAssert($r1['previous_record_hash'] === null, 'first record has no predecessor');
fAssert(isset($r1['record_hash']), 'record hash exists');

$l2 = $lineages->create('trace_a','corr_shared','evt_a1',['evt_a1']);
$e2 = $make('evt_a2','company_a',T0gmEventKind::AI_DECISION,$l2,88,'critical',['decision'=>[
    'decision_id'=>'decision_a2','determination'=>'constrain','reason_codes'=>['RISK_SPIKE']
]],[[
    'evidence_id'=>'evidence_shared','evidence_type'=>'risk_assessment','source'=>'titan-risk','hash'=>'hash-b'
]]);
$r2 = $ingest->ingest($e2);
fAssert($r2['audit_sequence'] === 2, 'second sequence increments');
fAssert($r2['previous_record_hash'] === $r1['record_hash'], 'audit chain links records');

$l3 = $lineages->create('trace_b','corr_b',null,[]);
$e3 = $make('evt_b1','company_b',T0gmEventKind::OBSERVATION,$l3,30,'watch',['observation'=>['summary'=>'Other company observation']]);
$ingest->ingest($e3);

$platformEvent = $factory->make(
    T0gmEventKind::ANOMALY,
    ['scope'=>'platform'],
    ['actor_type'=>'system','actor_id'=>'t0gm-platform-watch','authority_class'=>'oversight_system'],
    ['system'=>'t0gm','component'=>'cross-company-anomaly'],
    ['subject_type'=>'platform_pattern','subject_id'=>'pattern_1'],
    $lineages->create('trace_platform','corr_platform',null,[]),
    ['score'=>95,'band'=>'extreme','dimensions'=>['systemic'=>95]],
    ['visibility'=>'t0gm_sovereign','attention_tier'=>'critical','review_required'=>true,'review_team'=>['security','governance']],
    [],
    ['anomaly'=>['anomaly_type'=>'cross-company-pattern','summary'=>'Platform-wide pattern']],
    'evt_platform_1'
);
$ingest->ingest($platformEvent);

fAssert($store->verifyAuditLineage(), 'immutable audit lineage verifies');
fAssert(count($store->byCorrelation('corr_shared',$sovereign)) === 2, 'correlation index returns both related events');
fAssert(count($store->byEvidence('evidence_shared',$sovereign)) === 2, 'evidence index returns both references');
$edges = $store->causalEdges('evt_a2',$sovereign);
fAssert(count($edges) >= 1, 'causal edges indexed');
fAssert(count(array_filter($edges, fn($e) => $e['edge_type'] === 'causes')) === 1, 'causation edge retained');

fAssert(count($store->query(new T0gmFeedQuery(limit:100), $sovereign)) === 4, 'T0GM sovereign sees all company and platform events');
fAssert(count($store->query(new T0gmFeedQuery(limit:100), $companyA)) === 2, 'delegated oversight sees only explicitly granted company');
fAssert(count($store->query(new T0gmFeedQuery(limit:100), $companyB)) === 1, 'company B cannot see company A or platform event');
fAssert(count($store->query(new T0gmFeedQuery(limit:100), $platformAI)) === 1, 'platform visibility grant sees platform event but not companies');
fExpect('feed-visibility-denied', fn() => $store->get('evt_b1',$companyA));
fExpect('feed-visibility-denied', fn() => $store->get('evt_platform_1',$companyA));
fAssert($store->get('evt_b1',$sovereign)['event_id'] === 'evt_b1', 'sovereign direct read is permitted');

$criticalA = $store->query(new T0gmFeedQuery(companyIds:['company_a'], attentionAtLeast:'urgent', limit:100),$sovereign);
fAssert(count($criticalA) === 1 && $criticalA[0]['event_id'] === 'evt_a2','attention and company query work together');

$idempotent = $ingest->ingest($e1);
fAssert($idempotent['record_hash'] === $r1['record_hash'], 'same event is idempotent');
fAssert($store->auditHead()['audit_sequence'] === 4, 'idempotent replay does not append');

$conflict = $e1;
$conflict['observation']['summary'] = 'Conflicting replay';
unset($conflict['integrity']);
fExpect('event-id-conflict', fn() => $ingest->ingest($conflict));

$badIntegrity = $r2['event'];
$badIntegrity['risk']['score'] = 1;
fExpect('event-integrity-invalid', fn() => $ingest->ingest($badIntegrity));

$generated = $lineages->create();
fAssert(str_starts_with($generated['trace_id'],'t0gm_trace_'),'trace ID generated');
fAssert(str_starts_with($generated['correlation_id'],'t0gm_corr_'),'correlation ID generated');

// Durable reference store verification when PDO SQLite is present.
if (in_array('sqlite', PDO::getAvailableDrivers(), true)) {
    $pdo = new PDO('sqlite::memory:');
    $pdoStore = new PdoSovereignActivityStore($pdo);
    $pdoStore->installSchema();
    $pdoIngest = new T0gmFeedIngestor($pdoStore);
    $pdoIngest->ingest($e1);
    $pdoIngest->ingest($e2);
    $pdoIngest->ingest($e3);
    fAssert($pdoStore->verifyAuditLineage(), 'PDO audit lineage verifies');
    fAssert(count($pdoStore->byCorrelation('corr_shared',$companyA)) === 2, 'PDO correlation + visibility works');
    fAssert(count($pdoStore->byCorrelation('corr_shared',$companyB)) === 0, 'PDO cross-company filtering works');
    fAssert(count($pdoStore->byEvidence('evidence_shared',$companyA)) === 2, 'PDO evidence index works');
    fExpect('feed-visibility-denied', fn() => $pdoStore->get('evt_a1',$companyB));

    // Simulate out-of-band database tampering: verification must fail.
    $pdo->exec("UPDATE t0gm_feed_events SET event_json = REPLACE(event_json, 'Routine observation', 'Tampered observation') WHERE event_id='evt_a1'");
    fAssert(!$pdoStore->verifyAuditLineage(), 'out-of-band persistence tampering is detected');
    echo "PASS durable PDO event store and tamper detection\n";
} else {
    echo "SKIP PDO SQLite durable store test (driver unavailable)\n";
}

echo "PASS sovereign feed ingestion and idempotency\n";
echo "PASS immutable chained audit lineage\n";
echo "PASS causal links and correlation IDs\n";
echo "PASS evidence reference index\n";
echo "PASS fail-closed cross-company visibility\n";
echo "PASS sovereign all-company/platform visibility\n";
echo "PASS attention/company feed queries\n";
echo "PASS event integrity validation\n";
