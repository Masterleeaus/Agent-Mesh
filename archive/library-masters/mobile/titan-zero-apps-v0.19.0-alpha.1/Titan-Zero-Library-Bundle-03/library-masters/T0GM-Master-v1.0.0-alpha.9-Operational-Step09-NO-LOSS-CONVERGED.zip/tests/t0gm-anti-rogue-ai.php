<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\AntiRogue\{AntiRogueControlPlane,IndependentOversightGuard,CollusionDetector};

function ok15($v,$m){if(!$v){fwrite(STDERR,"FAIL $m\n");exit(1);}echo "PASS $m\n";}
function throws15($f,$m){try{$f();}catch(Throwable $e){echo "PASS $m\n";return;}fwrite(STDERR,"FAIL $m\n");exit(1);}
$c=new AntiRogueControlPlane();
$f=$c->inspect(['type'=>'self_escalation','actors'=>['ai-1'],'operation'=>'increase_authority']); ok15($f->severity===100 && in_array('AI_AUTHORITY_SELF_MUTATION_FORBIDDEN',$f->reasonCodes,true),'AI self-escalation contained');
throws15(fn()=> $c->validateDelegation(['delegator_type'=>'ai','hidden'=>true,'company_id'=>'c1']),'hidden AI delegation rejected');
$f=$c->inspect(['type'=>'authority_persistence','actors'=>['ai-1']]); ok15(in_array('extinguish_persisted_authority',$f->requiredActions,true),'authority persistence extinguished');
$f=$c->inspect(['type'=>'forged_evidence','actors'=>['ai-2'],'evidence_payload'=>['x'=>1],'evidence_digest'=>str_repeat('0',64)]); ok15($f->attackClass==='evidence' && $f->severity>=95,'forged evidence rejected');
$f=$c->inspect(['type'=>'feed_suppression','actors'=>['ai-3']]); ok15(in_array('enter_sovereign_recovery_mode',$f->requiredActions,true),'feed suppression triggers sovereign recovery');
$f=$c->inspect(['type'=>'audit_deletion','actors'=>['ai-3']]); ok15(in_array('verify_audit_lineage',$f->requiredActions,true),'audit deletion blocked');
$f=$c->inspect(['type'=>'oversight_evasion','actors'=>['ai-4']]); ok15(in_array('force_independent_review',$f->requiredActions,true),'oversight evasion forces independent review');
$d=new CollusionDetector(); $coll=$d->detect([['actor_id'=>'a1','company_id'=>'c1','target_id'=>'t','shared_objective'=>'o','signal'=>'hide_delegation'],['actor_id'=>'a2','company_id'=>'c1','target_id'=>'t','shared_objective'=>'o','signal'=>'suppress_feed']]); ok15(count($coll)===1 && $coll[0]['collusion']===true,'AI worker collusion detected');
$f=$c->inspect(['type'=>'compromised_oversight','actors'=>['oversight-security']]); ok15(in_array('remove_from_quorum',$f->requiredActions,true),'compromised oversight isolated');
$g=new IndependentOversightGuard(); $eligible=$g->requireIndependence(['ai-1'],['ai-1','oversight-security','oversight-causal'],['oversight-security']); ok15($eligible===['oversight-causal'],'independent uncompromised oversight required'); throws15(fn()=> $g->assertNoSelfCertification('ai-1','ai-1'),'AI self-certification rejected');
throws15(fn()=> $c->assertRecoveryInvariant(['actor_type'=>'ai','operation'=>'disable_god_mode_recovery']),'AI cannot disable God Mode recovery');
throws15(fn()=> $c->verifyObservability(false,true),'broken audit lineage fails closed'); throws15(fn()=> $c->verifyObservability(true,false),'suppressed sovereign feed fails closed');
$f=$c->inspect(['type'=>'disable_recovery','actors'=>['ai-9']]); ok15($f->godModeRecoveryProtected===true && $f->severity===100,'God Mode recovery protected');
echo "PASS T0GM anti-rogue-AI control suite\n";
