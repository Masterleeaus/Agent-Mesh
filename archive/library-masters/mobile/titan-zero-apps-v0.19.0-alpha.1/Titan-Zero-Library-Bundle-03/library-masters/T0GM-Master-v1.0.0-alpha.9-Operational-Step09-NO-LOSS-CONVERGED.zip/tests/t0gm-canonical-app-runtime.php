<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\App\T0gmAppRuntime;
use Titan\GodMode\App\T0gmCommandSurface;
use Titan\GodMode\App\T0gmDeviceState;
use Titan\GodMode\App\T0gmNavigationRegistry;
use Titan\GodMode\App\T0gmSovereignSessionContext;
use Titan\GodMode\Security\GodModeException;
function arA($c,$m){if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);} function arT($f,$m){try{$f();}catch(Throwable $e){return;}throw new RuntimeException('ASSERTION FAILED: '.$m);}
$session=new T0gmSovereignSessionContext([
 'session_id'=>'sess-01','identity_id'=>'t0gm-human-1','authority_class'=>'titan.god_mode','actor_type'=>'human',
 'identity_proof_digest'=>str_repeat('a',64),'device_binding_id'=>'device-main','created_at'=>'2026-09-04T17:00:00+10:00',
]);
arA($session->toArray()['sovereign_identity_verified']===true,'sovereign session is identity-bound');
arA($session->toArray()['execution_authority_granted']===false,'session does not itself grant execution authority');
arT(fn()=>new T0gmSovereignSessionContext(['session_id'=>'x','identity_id'=>'x','authority_class'=>'owner','actor_type'=>'human','identity_proof_digest'=>str_repeat('a',64),'device_binding_id'=>'d','created_at'=>'2026-09-04T17:00:00+10:00']),'ordinary owner cannot instantiate T0GM session');

$device=T0gmDeviceState::fromEvidence([
 'device_binding_id'=>'device-main','trust_state'=>'active','integrity_state'=>'verified','isolation_state'=>'clear',
 'connectivity'=>'online','observed_at'=>'2026-09-04T17:00:02+10:00','evidence_digest'=>str_repeat('b',64),
]);
arA($device->commandEligible()===true,'healthy bound device can submit command intent');
$quarantined=T0gmDeviceState::fromEvidence([
 'device_binding_id'=>'device-main','trust_state'=>'active','integrity_state'=>'verified','isolation_state'=>'quarantined',
 'connectivity'=>'online','observed_at'=>'2026-09-04T17:00:03+10:00','evidence_digest'=>str_repeat('c',64),
]);
arA($quarantined->commandEligible()===false,'quarantined device cannot submit command intent');

$nav=new T0gmNavigationRegistry([
 ['route_id'=>'home','label'=>'Home','path'=>'/','requires'=>[]],
 ['route_id'=>'activity','label'=>'Activity','path'=>'/activity','requires'=>['feed.read']],
 ['route_id'=>'investigate','label'=>'Investigate','path'=>'/investigate','requires'=>['investigation.read']],
]);
arA(count($nav->visibleRoutes(['feed.read']))===2,'navigation is capability-aware');
arT(fn()=>new T0gmNavigationRegistry([['route_id'=>'x','label'=>'X','path'=>'/x','requires'=>[],'company_id'=>'company-a']]),'navigation cannot embed company authority');

$commands=new T0gmCommandSurface(['inspect','propose','execute_request','supersede_request','contain_request']);
$runtime=new T0gmAppRuntime($session,$device,$nav,$commands);
$boot=$runtime->boot(['feed.read']);
arA($boot['app_id']==='t0gm','dedicated runtime app id');
arA($boot['session']['authority_class']==='titan.god_mode','runtime preserves T0GM authority class');
arA(count($boot['navigation'])===2,'boot projects authorized navigation');
arA($boot['device']['command_eligible']===true,'boot exposes current device state');

$intent=$runtime->submitCommand([
 'command_id'=>'cmd-01','command_type'=>'execute_request','company_id'=>'company-a','target'=>['target_type'=>'service','target_id'=>'crm-prod'],
 'purpose'=>'Inspect and repair verified CRM state','requested_effects'=>['customer.restore'],'submitted_at'=>'2026-09-04T17:01:00+10:00'
]);
arA($intent['schema']==='titan.t0gm.command_intent.v1','command becomes canonical intent envelope');
arA($intent['company_id']==='company-a','company_id remains canonical tenant boundary');
arA($intent['requires_governed_execution']===true,'execution request must pass governance');
arA($intent['execution_authority_granted']===false,'command surface cannot mint authority');
arA($intent['sovereign_session_id']==='sess-01','intent causally bound to sovereign session');
arA($intent['device_binding_id']==='device-main','intent bound to active device');
arA(strlen($intent['intent_digest'])===64,'intent is content-addressed');

arT(fn()=>$runtime->submitCommand(['command_id'=>'cmd-02','command_type'=>'execute_request','tenant_id'=>'legacy','company_id'=>'company-a','target'=>['target_type'=>'service','target_id'=>'x'],'purpose'=>'x','requested_effects'=>['x'],'submitted_at'=>'2026-09-04T17:01:00+10:00']),'legacy tenant boundary rejected');
$blocked=new T0gmAppRuntime($session,$quarantined,$nav,$commands);
arT(fn()=>$blocked->submitCommand(['command_id'=>'cmd-03','command_type'=>'inspect','company_id'=>'company-a','target'=>['target_type'=>'service','target_id'=>'x'],'purpose'=>'inspect','requested_effects'=>[],'submitted_at'=>'2026-09-04T17:01:00+10:00']),'quarantined device blocks commands');

echo "PASS canonical T0GM app runtime boots a dedicated sovereign application surface\nPASS sovereign session, navigation, device state and command surface remain separated\nPASS command intents are company-scoped, device/session-bound and do not mint execution authority\nPASS quarantined devices and legacy tenant boundaries fail closed\n";
