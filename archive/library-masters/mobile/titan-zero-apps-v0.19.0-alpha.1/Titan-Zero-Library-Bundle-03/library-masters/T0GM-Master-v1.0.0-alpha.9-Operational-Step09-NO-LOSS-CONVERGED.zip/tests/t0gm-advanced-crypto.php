<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Contracts\ZeroKnowledgeVerifier;
use Titan\GodMode\Identity\OpenSslPqcSignatureVerifier;
use Titan\GodMode\Identity\T0gmCryptoProfileRegistry;
use Titan\GodMode\Identity\T0gmCryptoSuiteRegistry;
use Titan\GodMode\Identity\T0gmHardwareAttestation;
use Titan\GodMode\Identity\T0gmSovereignIdentityRoot;
use Titan\GodMode\Identity\T0gmVerifierTrustStore;
use Titan\GodMode\Identity\T0gmZeroKnowledgeProofGate;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;
use Titan\GodMode\Support\InMemoryNonceStore;

function acAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function acExpect(string $reason, callable $fn):void{try{$fn();}catch(GodModeException $e){acAssert($e->reason===$reason,"expected $reason got {$e->reason}");return;}throw new RuntimeException("expected failure:$reason");}
function acEdSign(array $payload,string $secret):string{return base64_encode(sodium_crypto_sign_detached(CanonicalJson::encode($payload),$secret));}
function acRun(array $cmd): string {
    $spec=[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']];
    $p=proc_open($cmd,$spec,$pipes); if(!is_resource($p)) throw new RuntimeException('proc-open-failed');
    fclose($pipes[0]); $out=stream_get_contents($pipes[1]); fclose($pipes[1]); $err=stream_get_contents($pipes[2]); fclose($pipes[2]);
    $code=proc_close($p); if($code!==0) throw new RuntimeException('command-failed:'.implode(' ',$cmd)."\n$err"); return $out;
}
function acPqcKeypair(): array {
    $dir=sys_get_temp_dir().'/t0gm-test-pqc-'.bin2hex(random_bytes(8)); mkdir($dir,0700,true);
    $priv="$dir/private.pem"; $pub="$dir/public.pem";
    acRun(['openssl','genpkey','-algorithm','ML-DSA-65','-out',$priv]);
    acRun(['openssl','pkey','-in',$priv,'-pubout','-out',$pub]);
    return ['dir'=>$dir,'priv'=>$priv,'pub'=>file_get_contents($pub)];
}
function acPqcSign(array $payload,string $priv): string {
    $dir=dirname($priv); $msg="$dir/msg-".bin2hex(random_bytes(4)); $sig="$dir/sig-".bin2hex(random_bytes(4));
    file_put_contents($msg,CanonicalJson::encode($payload)); acRun(['openssl','pkeyutl','-sign','-inkey',$priv,'-in',$msg,'-out',$sig]);
    $raw=file_get_contents($sig); @unlink($msg); @unlink($sig); return base64_encode($raw);
}

final class TestOnlyZkVerifier implements ZeroKnowledgeVerifier {
    public function __construct(private string $verificationKeyId, private string $testSecret) {}
    public function verify(string $proof,array $publicStatement,array $context=[]): array {
        $statementHash=hash('sha256',CanonicalJson::encode($publicStatement));
        $expected=hash_hmac('sha256',$statementHash,$this->testSecret,true);
        return [
            'verified'=>hash_equals($expected,$proof),
            'verifier_id'=>'test-only-zk-verifier',
            'verification_key_id'=>$this->verificationKeyId,
            'proof_system'=>(string)($context['proof_system']??''),
            'statement_hash'=>$statementHash,
        ];
    }
}

$now=time();
$ed=sodium_crypto_sign_keypair(); $edSecret=sodium_crypto_sign_secretkey($ed); $edPublic=sodium_crypto_sign_publickey($ed);
$att=sodium_crypto_sign_keypair(); $attSecret=sodium_crypto_sign_secretkey($att); $attPublic=sodium_crypto_sign_publickey($att);
$device=sodium_crypto_sign_keypair(); $devicePublic=sodium_crypto_sign_publickey($device);
$pqc=acPqcKeypair();
$challenge=bin2hex(random_bytes(24));
$policy=['authority'=>'titan.god_mode','principal_class'=>'builder_control_plane_principal','principal_id'=>'OWNER_CONTROL_PLANE_PRINCIPAL','audience'=>'titan-builder-control-plane','clock_skew_seconds'=>30];
$payload=[
    'schema'=>'titan.t0gm.sovereign_identity_proof.v2','authority'=>'titan.god_mode','principal_class'=>'builder_control_plane_principal',
    'principal_id'=>'OWNER_CONTROL_PLANE_PRINCIPAL','device_key_id'=>'hw-device-pqc-01','device_public_key'=>base64_encode($devicePublic),
    'audience'=>'titan-builder-control-plane','challenge'=>$challenge,'issued_at'=>$now,'proof_expires_at'=>$now+60,'non_tenant'=>true,
    'crypto_profile_id'=>T0gmCryptoProfileRegistry::HYBRID_PQC_V1,
];
$attPayload=['schema'=>'titan.t0gm.hardware_attestation.v1','device_key_id'=>'hw-device-pqc-01','device_public_key_hash'=>hash('sha256',$devicePublic),'hardware_backed'=>true,'hardware_class'=>'test-secure-hardware','challenge'=>$challenge,'measurement'=>'boot-state:verified','issued_at'=>$now,'evidence_hash'=>hash('sha256','attestation-evidence-pqc')];
$statement=[
    'authority'=>'titan.god_mode','principal_class'=>'builder_control_plane_principal','principal_id'=>'OWNER_CONTROL_PLANE_PRINCIPAL',
    'device_key_id'=>'hw-device-pqc-01','device_public_key_hash'=>hash('sha256',$devicePublic),'audience'=>'titan-builder-control-plane',
    'challenge'=>$challenge,'crypto_profile_id'=>T0gmCryptoProfileRegistry::HYBRID_PQC_V1,'claim'=>'sovereign-secret-possession-without-secret-disclosure',
];
$zkSecret='TEST-ONLY-NOT-A-PRODUCTION-ZK-SECRET';
$statementHash=hash('sha256',CanonicalJson::encode($statement));
$zkProof=hash_hmac('sha256',$statementHash,$zkSecret,true);
$proof=[
    'payload'=>$payload,
    'signatures'=>[
        ['key_id'=>'identity-ed-01','suite'=>'ed25519','signature'=>acEdSign($payload,$edSecret)],
        ['key_id'=>'identity-pqc-01','suite'=>'ml-dsa-65','signature'=>acPqcSign($payload,$pqc['priv'])],
    ],
    'hardware_attestation'=>['payload'=>$attPayload,'attestation_key_id'=>'att-root-01','signature_suite'=>'ed25519','signature'=>acEdSign($attPayload,$attSecret)],
    'zero_knowledge_proof'=>['proof_system'=>'t0gm-zk-sovereign-possession-v1','proof'=>base64_encode($zkProof),'public_statement'=>$statement],
];

$crypto=new T0gmCryptoSuiteRegistry(new OpenSslPqcSignatureVerifier());
acAssert(in_array('ml-dsa-65',$crypto->supportedSuites(),true),'runtime exposes ML-DSA verifier');
$idStore=new T0gmVerifierTrustStore([
    'identity-ed-01'=>['suite'=>'ed25519','public_key'=>base64_encode($edPublic)],
    'identity-pqc-01'=>['suite'=>'ml-dsa-65','public_key'=>base64_encode($pqc['pub'])],
]);
$attStore=new T0gmVerifierTrustStore(['att-root-01'=>['suite'=>'ed25519','public_key'=>base64_encode($attPublic)]]);
$zkGate=new T0gmZeroKnowledgeProofGate(['t0gm-zk-sovereign-possession-v1'=>new TestOnlyZkVerifier('test-zk-vk-01',$zkSecret)]);
$root=new T0gmSovereignIdentityRoot($idStore,new T0gmHardwareAttestation($attStore,$crypto),$crypto,new T0gmCryptoProfileRegistry(),$zkGate,new InMemoryNonceStore(),$policy);
$result=$root->verify($proof,$now);
acAssert($result['authority_class']==='titan.god_mode','sovereign authority class');
acAssert($result['post_quantum_identity']===true,'ML-DSA participates in identity verification');
acAssert(in_array('ed25519',$result['verified_signature_suites'],true),'classical signature verified');
acAssert(in_array('ml-dsa-65',$result['verified_signature_suites'],true),'PQC signature verified');
acAssert($result['zero_knowledge']['verified']===true,'ZK verifier result retained');
acAssert($result['company_authority_embedded']===false,'identity root remains non-tenant and non-company-authorizing');
acAssert($result['kem_preferences']===['ml-kem-768'],'PQC KEM preference is crypto policy metadata, not authority');

acExpect('sovereign-identity-proof-replay-detected',fn()=>$root->verify($proof,$now));

// Missing PQC signature must fail even with valid classical signature and hardware/ZK proof.
$fresh=$proof; $fresh['payload']['challenge']=bin2hex(random_bytes(24)); $fresh['signatures']=[['key_id'=>'identity-ed-01','suite'=>'ed25519','signature'=>acEdSign($fresh['payload'],$edSecret)]];
$fresh['hardware_attestation']['payload']['challenge']=$fresh['payload']['challenge']; $fresh['hardware_attestation']['signature']=acEdSign($fresh['hardware_attestation']['payload'],$attSecret);
$freshStatement=$statement; $freshStatement['challenge']=$fresh['payload']['challenge'];
$fresh['zero_knowledge_proof']['public_statement']=$freshStatement; $fresh['zero_knowledge_proof']['proof']=base64_encode(hash_hmac('sha256',hash('sha256',CanonicalJson::encode($freshStatement)),$zkSecret,true));
acExpect('required-sovereign-signature-missing:ml-dsa-65',fn()=>$root->verify($fresh,$now));

// A valid hybrid signature set cannot rescue a forged/mismatched ZK public statement.
$fresh2=$proof; $fresh2['payload']['challenge']=bin2hex(random_bytes(24));
$fresh2['signatures'][0]['signature']=acEdSign($fresh2['payload'],$edSecret); $fresh2['signatures'][1]['signature']=acPqcSign($fresh2['payload'],$pqc['priv']);
$fresh2['hardware_attestation']['payload']['challenge']=$fresh2['payload']['challenge']; $fresh2['hardware_attestation']['signature']=acEdSign($fresh2['hardware_attestation']['payload'],$attSecret);
$fresh2['zero_knowledge_proof']['public_statement']=$statement; // old challenge deliberately retained
acExpect('zk-public-statement-mismatch',fn()=>$root->verify($fresh2,$now));

// Company/role binding remains forbidden at identity root even under PQC.
$fresh3=$proof; $fresh3['payload']['challenge']=bin2hex(random_bytes(24)); $fresh3['payload']['company_id']='company_123';
$fresh3['signatures'][0]['signature']=acEdSign($fresh3['payload'],$edSecret); $fresh3['signatures'][1]['signature']=acPqcSign($fresh3['payload'],$pqc['priv']);
acExpect('application-identity-binding-forbidden:company_id',fn()=>$root->verify($fresh3,$now));

@unlink($pqc['priv']); @unlink($pqc['dir'].'/public.pem'); @rmdir($pqc['dir']);
echo "PASS hybrid classical + ML-DSA sovereign identity verification\n";
echo "PASS provider-bound zero-knowledge public-statement verification\n";
echo "PASS PQC/ZK layers do not create company or execution authority\n";
echo "PASS crypto profile is versioned independently from authority semantics\n";
