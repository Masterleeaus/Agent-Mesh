<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Channel\OpenSslMlKemEngine;
use Titan\GodMode\Channel\T0gmMlKemChannelEstablisher;
use Titan\GodMode\Identity\T0gmCryptoProfileRegistry;
use Titan\GodMode\Security\GodModeException;

function mkAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function mkExpect(string $reason,callable $fn):void{try{$fn();}catch(GodModeException $e){mkAssert(str_starts_with($e->reason,$reason),"expected $reason got {$e->reason}");return;}throw new RuntimeException("expected failure:$reason");}
function mkRun(array $cmd):void{$s=[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']];$p=proc_open($cmd,$s,$pipes);if(!is_resource($p))throw new RuntimeException('proc-open-failed');fclose($pipes[0]);stream_get_contents($pipes[1]);fclose($pipes[1]);$e=stream_get_contents($pipes[2]);fclose($pipes[2]);$c=proc_close($p);if($c!==0)throw new RuntimeException("command-failed:$e");}

$dir=sys_get_temp_dir().'/t0gm-mlkem-test-'.bin2hex(random_bytes(8));mkdir($dir,0700,true);
$priv="$dir/private.pem";$pub="$dir/public.pem";
mkRun(['openssl','genpkey','-algorithm','ML-KEM-768','-out',$priv]);
mkRun(['openssl','pkey','-in',$priv,'-pubout','-out',$pub]);
$ctx=[
 'channel_id'=>'ch_'.bin2hex(random_bytes(16)),
 'crypto_profile_id'=>T0gmCryptoProfileRegistry::HYBRID_PQC_V1,
 'kem_algorithm'=>'ml-kem-768',
 'initiator'=>'t0gm-control-device-01','responder'=>'t0gm-control-plane-01','purpose'=>'sovereign-control-plane-key-establishment',
];
$svc=new T0gmMlKemChannelEstablisher(new OpenSslMlKemEngine());
$init=$svc->initiate($ctx,file_get_contents($pub));
$accept=$svc->accept($ctx,$priv,$init['ciphertext']);
mkAssert(hash_equals($init['shared_secret'],$accept['shared_secret']),'encapsulation and decapsulation agree');
mkAssert($init['shared_secret_hash']===$accept['shared_secret_hash'],'shared secret evidence agrees');
mkAssert($init['authority_granted']===false && $accept['authority_granted']===false,'KEM does not grant sovereign authority');
mkAssert($init['company_authority_granted']===false,'KEM does not create company authority');
mkAssert($init['transcript']['transcript_hash']===$accept['transcript']['transcript_hash'],'transcript binding stable');

$bad=$ctx;$bad['kem_algorithm']='ml-kem-512';
mkExpect('ml-kem-not-allowed-by-crypto-profile:',fn()=>$svc->initiate($bad,file_get_contents($pub)));
$bad2=$ctx;$bad2['company_id']='company_123';
mkExpect('channel-crypto-must-not-embed-company-authority',fn()=>$svc->initiate($bad2,file_get_contents($pub)));
$bad3=$ctx;$bad3['crypto_profile_id']='unknown-profile';
mkExpect('unknown-crypto-profile:',fn()=>$svc->initiate($bad3,file_get_contents($pub)));
mkExpect('ml-kem-ciphertext-invalid',fn()=>$svc->accept($ctx,$priv,'%%%'));

@unlink($priv);@unlink($pub);@rmdir($dir);
echo "PASS ML-KEM-768 encapsulation and decapsulation agree\n";
echo "PASS channel transcript binds profile, endpoints, purpose and KEM suite\n";
echo "PASS KEM downgrade and company-authority confusion fail closed\n";
echo "PASS ML-KEM creates channel material, not sovereign authority\n";
