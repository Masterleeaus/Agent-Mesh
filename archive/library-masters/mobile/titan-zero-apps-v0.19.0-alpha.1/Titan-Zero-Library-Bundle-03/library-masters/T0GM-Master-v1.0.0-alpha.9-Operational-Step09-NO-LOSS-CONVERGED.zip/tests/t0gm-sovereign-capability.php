<?php
require __DIR__ . '/bootstrap.php';
function cAssert($condition,string $message): void { if(!$condition) throw new RuntimeException('ASSERTION FAILED: '.$message); }
function cThrows(callable $fn,string $class,string $message): void { try { $fn(); } catch (Throwable $e) { if ($e instanceof $class) return; throw $e; } throw new RuntimeException('ASSERTION FAILED: '.$message); }

use Titan\GodMode\Capability\SovereignCapabilityEvaluator;
use Titan\GodMode\Capability\SovereignCapabilityFactory;
use Titan\GodMode\Capability\SovereignCapabilityValidator;
use Titan\GodMode\Capability\SovereignCapabilityException;

$factory = new SovereignCapabilityFactory();
$validator = new SovereignCapabilityValidator();
$evaluator = new SovereignCapabilityEvaluator();

$extinction = [];
foreach (['purpose_invalid','authority_revoked','company_changed','target_changed','risk_constraint_breached','safety_interlock','superseded','t0gm_extinguish'] as $type) {
    $extinction[] = ['condition_id' => 'ext-' . $type, 'condition_type' => $type, 'description' => 'Extinguish when ' . $type];
}

$cap = $factory->create([
    'authority_holder' => ['identity_id'=>'t0gm-human-1','authority_class'=>'titan.god_mode','actor_type'=>'human'],
    'authority_basis' => ['basis_type'=>'titan_managed','basis_id'=>'agreement-7','description'=>'Contractually managed recovery authority'],
    'company_id' => 'company-123',
    'purpose' => ['purpose_id'=>'recover-customer-9','statement'=>'Recover verified customer state','intended_outcome'=>'Customer record restored to verified state'],
    'target' => ['target_type'=>'database','target_id'=>'crm-prod','system'=>'titan.crm','environment'=>'production','resource_ids'=>['customer-9']],
    'permitted_effects' => [[
        'effect_id'=>'effect-restore','operation'=>'customer.restore_verified_snapshot','resource_type'=>'customer','resource_ids'=>['customer-9'],
        'constraints'=>['snapshot_must_be_verified'=>true]
    ]],
    'prohibited_effects' => [
        ['operation'=>'customer.delete','reason'=>'Deletion is outside recovery purpose'],
        ['operation'=>'ledger.mutate','reason'=>'Financial ledger is outside recovery target']
    ],
    'evidence' => [['evidence_id'=>'ev-incident-1','evidence_type'=>'incident','source'=>'t0gm.feed','integrity_ref'=>'sha256:abc']],
    'risk_constraints' => ['max_risk_score'=>70,'max_financial_exposure'=>20,'max_physical_impact'=>0,'max_environmental_impact'=>0,'prohibited_risk_bands'=>['extreme']],
    'extinction_conditions' => $extinction,
]);

$validator->validate($cap);
cAssert($cap['company_id'] === 'company-123', 'capability is bound to company_id');
cAssert(!isset($cap['expires_at']), 'capability has no canonical expiry authority duration');

$decision = $evaluator->evaluate($cap, [
    'company_id'=>'company-123',
    'target'=>['target_type'=>'database','target_id'=>'crm-prod','system'=>'titan.crm','environment'=>'production'],
    'operation'=>'customer.restore_verified_snapshot','resource_id'=>'customer-9',
    'risk'=>['score'=>45,'band'=>'medium','financial_exposure'=>10,'physical_impact'=>0,'environmental_impact'=>0],
    'evidence_ids'=>['ev-incident-1'],
    'triggered_extinction_conditions'=>[],
]);
cAssert($decision->allowed, 'exact bounded capability permits exact requested effect');

$crossCompany = $evaluator->evaluate($cap, [
    'company_id'=>'company-999','target'=>['target_type'=>'database','target_id'=>'crm-prod','system'=>'titan.crm','environment'=>'production'],
    'operation'=>'customer.restore_verified_snapshot','resource_id'=>'customer-9',
    'risk'=>['score'=>45,'band'=>'medium','financial_exposure'=>10,'physical_impact'=>0,'environmental_impact'=>0],
    'evidence_ids'=>['ev-incident-1'], 'triggered_extinction_conditions'=>[],
]);
cAssert(!$crossCompany->allowed && in_array('company_mismatch', $crossCompany->reasons, true), 'cross-company use fails closed');

$prohibited = $evaluator->evaluate($cap, [
    'company_id'=>'company-123','target'=>['target_type'=>'database','target_id'=>'crm-prod','system'=>'titan.crm','environment'=>'production'],
    'operation'=>'customer.delete','resource_id'=>'customer-9',
    'risk'=>['score'=>20,'band'=>'low','financial_exposure'=>0,'physical_impact'=>0,'environmental_impact'=>0],
    'evidence_ids'=>['ev-incident-1'], 'triggered_extinction_conditions'=>[],
]);
cAssert(!$prohibited->allowed && in_array('effect_explicitly_prohibited', $prohibited->reasons, true), 'explicit prohibited effect cannot inherit nearby authority');

$tooRisky = $evaluator->evaluate($cap, [
    'company_id'=>'company-123','target'=>['target_type'=>'database','target_id'=>'crm-prod','system'=>'titan.crm','environment'=>'production'],
    'operation'=>'customer.restore_verified_snapshot','resource_id'=>'customer-9',
    'risk'=>['score'=>90,'band'=>'extreme','financial_exposure'=>10,'physical_impact'=>0,'environmental_impact'=>0],
    'evidence_ids'=>['ev-incident-1'], 'triggered_extinction_conditions'=>[],
]);
cAssert(!$tooRisky->allowed, 'authority does not override capability risk constraints');

$extinguished = $evaluator->evaluate($cap, [
    'company_id'=>'company-123','target'=>['target_type'=>'database','target_id'=>'crm-prod','system'=>'titan.crm','environment'=>'production'],
    'operation'=>'customer.restore_verified_snapshot','resource_id'=>'customer-9',
    'risk'=>['score'=>45,'band'=>'medium','financial_exposure'=>10,'physical_impact'=>0,'environmental_impact'=>0],
    'evidence_ids'=>['ev-incident-1'], 'triggered_extinction_conditions'=>['purpose_invalid'],
]);
cAssert(!$extinguished->allowed && in_array('extinction_condition_triggered:purpose_invalid', $extinguished->reasons, true), 'triggered extinction condition blocks effect');

$wildcard = $cap;
$wildcard['company_id'] = '*';
$wildcard['integrity'] = ['algorithm'=>'sha256','digest'=>str_repeat('0',64)];
cThrows(fn() => $validator->validate($wildcard), SovereignCapabilityException::class, 'wildcard company scope rejected');

$admin = $cap;
$admin['permitted_effects'][0]['operation'] = 'admin';
$admin['integrity'] = ['algorithm'=>'sha256','digest'=>str_repeat('0',64)];
cThrows(fn() => $validator->validate($admin), SovereignCapabilityException::class, 'unbounded admin abstraction rejected');

$ttl = $cap;
$ttl['expires_at'] = gmdate('c', time() + 300);
$ttl['integrity'] = ['algorithm'=>'sha256','digest'=>str_repeat('0',64)];
cThrows(fn() => $validator->validate($ttl), SovereignCapabilityException::class, 'time expiry rejected as canonical authority duration');

$ai = $cap;
$ai['authority_holder']['actor_type'] = 'advanced_intelligence';
$ai['integrity'] = ['algorithm'=>'sha256','digest'=>str_repeat('0',64)];
cThrows(fn() => $validator->validate($ai), SovereignCapabilityException::class, 'Advanced Intelligence cannot possess sovereign capability');

$tampered = $cap;
$tampered['purpose']['statement'] = 'Different purpose';
$denyTampered = $evaluator->evaluate($tampered, []);
cAssert(!$denyTampered->allowed && in_array('integrity_verification_failed', $denyTampered->reasons, true), 'tampered capability fails integrity verification');

echo "T0GM sovereign capability tests: PASS\n";
