<?php
require __DIR__ . '/bootstrap.php';

use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmLineageFactory;
use Titan\GodMode\Notification\InMemoryNotificationTransport;
use Titan\GodMode\Notification\T0gmNotificationChannel;
use Titan\GodMode\Notification\T0gmNotificationDistributor;
use Titan\GodMode\Notification\T0gmNotificationEndpoint;
use Titan\GodMode\Notification\T0gmNotificationPolicy;
use Titan\GodMode\Notification\T0gmNotificationTransportRegistry;

function nAssert($condition,string $message): void { if(!$condition) throw new RuntimeException('ASSERTION FAILED: '.$message); }

$factory=new T0gmEventFactory();
$lineage=(new T0gmLineageFactory())->create('trace-notify','corr-notify',null,[]);
$critical=$factory->make(
    T0gmEventKind::ANOMALY,
    ['scope'=>'company','company_id'=>'company_a'],
    ['actor_type'=>'system','actor_id'=>'t0gm-risk-engine'],
    ['system'=>'titan-signal','component'=>'notification-test'],
    ['subject_type'=>'infrastructure','subject_id'=>'prod-db-1'],
    $lineage,
    ['score'=>98,'band'=>'extreme','dimensions'=>['security'=>98,'physical'=>95]],
    ['visibility'=>'t0gm_sovereign','attention_tier'=>'critical','review_required'=>true,'review_team'=>['security','physical_safety']],
    [['evidence_id'=>'ev-secret','evidence_type'=>'attestation','source'=>'secure-evidence-store','provenance_ref'=>'vault://secret-do-not-notify']],
    ['attention_signals'=>['significance'=>95,'anomaly'=>99,'urgency'=>98,'reversibility'=>30,'financial_exposure'=>80,'physical_impact'=>95,'environmental_impact'=>10,'confidence'=>82,'dependency'=>90,'domains'=>['security','physical']],'anomaly'=>['anomaly_type'=>'privileged-control-path','summary'=>'Critical privileged anomaly']],
    'evt-notify-critical','2026-09-02T11:20:00Z','2026-09-02T11:20:01Z'
);
$routine=$factory->make(
    T0gmEventKind::OBSERVATION,
    ['scope'=>'company','company_id'=>'company_a'],
    ['actor_type'=>'system','actor_id'=>'routine-worker'],
    ['system'=>'titan-signal','component'=>'notification-test'],
    ['subject_type'=>'job','subject_id'=>'job-1'],
    (new T0gmLineageFactory())->create('trace-routine','corr-routine',null,[]),
    ['score'=>5,'band'=>'minimal','dimensions'=>['operational'=>5]],
    ['visibility'=>'t0gm_sovereign','attention_tier'=>'routine','review_required'=>false,'review_team'=>[]],
    [],
    ['attention_signals'=>['significance'=>10,'anomaly'=>0,'urgency'=>0,'reversibility'=>100,'financial_exposure'=>0,'physical_impact'=>0,'environmental_impact'=>0,'confidence'=>95,'dependency'=>5,'domains'=>['operations']],'observation'=>['summary'=>'Routine completion']],
    'evt-notify-routine','2026-09-02T11:21:00Z','2026-09-02T11:21:01Z'
);

$desktop=new InMemoryNotificationTransport(T0gmNotificationChannel::DESKTOP);
$browser=new InMemoryNotificationTransport(T0gmNotificationChannel::BROWSER);
$mobile=new InMemoryNotificationTransport(T0gmNotificationChannel::MOBILE);
$external=new InMemoryNotificationTransport(T0gmNotificationChannel::EXTERNAL);
$registry=new T0gmNotificationTransportRegistry($desktop,$browser,$mobile,$external);
$policy=new T0gmNotificationPolicy('critical',[T0gmNotificationChannel::DESKTOP,T0gmNotificationChannel::BROWSER,T0gmNotificationChannel::MOBILE]);
$dist=new T0gmNotificationDistributor($policy,$registry);
$endpoints=[
    new T0gmNotificationEndpoint('desk-owner','desktop','T0GM_OWNER'),
    new T0gmNotificationEndpoint('browser-owner','browser','T0GM_OWNER'),
    new T0gmNotificationEndpoint('mobile-owner','mobile','T0GM_OWNER'),
];
$result=$dist->distribute($critical,$endpoints);
nAssert($result['state']==='distributed','critical event distributes');
nAssert(count($result['receipts'])===3,'critical event reaches desktop browser and mobile');
foreach($result['receipts'] as $r) nAssert($r->state==='delivered','enabled native channel delivered');
$msg=$result['notification']->toArray();
nAssert($msg['companyId']==='company_a' && $msg['eventId']==='evt-notify-critical','notification retains company/event correlation');
nAssert(!str_contains(json_encode($msg),'vault://') && !str_contains(json_encode($msg),'secret-do-not-notify'),'notification projection does not leak evidence provenance/secrets');

$again=$dist->distribute($critical,$endpoints);
nAssert(count($again['receipts'])===3 && count($desktop->deliveries)===1 && count($browser->deliveries)===1 && count($mobile->deliveries)===1,'delivery is idempotent per event and endpoint');
$routineResult=$dist->distribute($routine,$endpoints);
nAssert($routineResult['state']==='below-threshold' && $routineResult['receipts']===[],'routine event is not pushed under critical-only policy');

$externalRejected=false;
try { new T0gmNotificationEndpoint('ext-bad','external','T0GM_OWNER',true,false); } catch(InvalidArgumentException $e) { $externalRejected=$e->getMessage()==='external-channel-must-be-explicitly-selected'; }
nAssert($externalRejected,'external endpoint requires explicit selection');
$externalEndpoint=new T0gmNotificationEndpoint('ext-owner','external','T0GM_OWNER',true,true);
$notAllowed=$dist->distribute(array_merge($critical,['event_id'=>'evt-notify-critical-external-blocked']),[$externalEndpoint]);
nAssert(count($notAllowed['receipts'])===0,'external delivery blocked unless policy explicitly enables it');

$extPolicy=new T0gmNotificationPolicy('critical',[T0gmNotificationChannel::EXTERNAL],true);
$extDist=new T0gmNotificationDistributor($extPolicy,$registry);
$extResult=$extDist->distribute(array_merge($critical,['event_id'=>'evt-notify-critical-external']),[$externalEndpoint]);
nAssert(count($extResult['receipts'])===1 && $extResult['receipts'][0]->state==='delivered','explicitly selected external channel can be enabled later through policy');

$failReg=new T0gmNotificationTransportRegistry(new InMemoryNotificationTransport(T0gmNotificationChannel::MOBILE,true));
$failDist=new T0gmNotificationDistributor(new T0gmNotificationPolicy('critical',[T0gmNotificationChannel::MOBILE]),$failReg);
$failed=$failDist->distribute(array_merge($critical,['event_id'=>'evt-notify-fail']),[new T0gmNotificationEndpoint('mobile-fail','mobile','T0GM_OWNER')]);
nAssert($failed['receipts'][0]->state==='failed','transport failure is explicit and does not fake delivery');

nAssert($critical['oversight']['visibility']==='t0gm_sovereign' && $critical['event_id']==='evt-notify-critical','distribution does not mutate canonical event');

echo "PASS critical desktop/browser/mobile distribution\n";
echo "PASS notification projection redacts evidence bodies and sensitive provenance\n";
echo "PASS per-event/per-endpoint idempotency\n";
echo "PASS critical-only threshold and explicit external-channel opt-in\n";
echo "PASS transport failure remains explicit without altering source event\n";
