<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Identity\T0gmCryptoSuiteRegistry;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Workload\T0gmWorkloadIdentityRegistry;
use Titan\GodMode\Workload\T0gmWorkloadIdentityVerifier;
use Titan\GodMode\Workload\T0gmWorkloadTrustStore;
use Titan\GodMode\Support\InMemoryNonceStore;

function wiAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function wiExpect(string $contains,callable $fn):void{try{$fn();}catch(Throwable $e){wiAssert(str_contains($e->getMessage(),$contains),"expected $contains got {$e->getMessage()}");return;}throw new RuntimeException("expected failure:$contains");}
function wiSign(array $payload,string $secret):string{return base64_encode(sodium_crypto_sign_detached(CanonicalJson::encode($payload),$secret));}

$now=time();
$issuer=sodium_crypto_sign_keypair(); $issuerSecret=sodium_crypto_sign_secretkey($issuer); $issuerPublic=sodium_crypto_sign_publickey($issuer);
$server=sodium_crypto_sign_keypair(); $serverSecret=sodium_crypto_sign_secretkey($server); $serverPublic=sodium_crypto_sign_publickey($server);
$service=sodium_crypto_sign_keypair(); $serviceSecret=sodium_crypto_sign_secretkey($service); $servicePublic=sodium_crypto_sign_publickey($service);
$container=sodium_crypto_sign_keypair(); $containerSecret=sodium_crypto_sign_secretkey($container); $containerPublic=sodium_crypto_sign_publickey($container);
$job=sodium_crypto_sign_keypair(); $jobSecret=sodium_crypto_sign_secretkey($job); $jobPublic=sodium_crypto_sign_publickey($job);

$registry=new T0gmWorkloadIdentityRegistry([
 'titan://server/prod/api-01'=>['class'=>'server','public_key_hash'=>hash('sha256',$serverPublic),'binding_id'=>'wbind-server','status'=>'active','provenance'=>['source'=>'bare-metal-enrollment']],
 'titan://service/prod/billing'=>['class'=>'service','public_key_hash'=>hash('sha256',$servicePublic),'binding_id'=>'wbind-service','status'=>'active','provenance'=>['source'=>'service-control-plane']],
 'titan://container/prod/api/sha256:abc'=>['class'=>'container','public_key_hash'=>hash('sha256',$containerPublic),'binding_id'=>'wbind-container','status'=>'active','expected_measurement'=>'sha256:container-image-001'],
 'titan://workload/prod/reconcile/42'=>['class'=>'workload','public_key_hash'=>hash('sha256',$jobPublic),'binding_id'=>'wbind-job','status'=>'active','expected_measurement'=>'sha256:job-bundle-042'],
]);
$trust=new T0gmWorkloadTrustStore(['workload-attestor-01'=>['suite'=>'ed25519','public_key'=>base64_encode($issuerPublic),'purposes'=>['workload_attestation']]]);
$verifier=new T0gmWorkloadIdentityVerifier($registry,$trust,new T0gmCryptoSuiteRegistry(),new InMemoryNonceStore());

$make=function(string $id,string $class,string $pub,string $secret,string $measurement,string $nonce,array $network=[])use($now,$issuerSecret):array{
 $claim=['schema'=>'titan.t0gm.workload_identity.v1','workload_id'=>$id,'workload_class'=>$class,'public_key'=>base64_encode($pub),'measurement'=>$measurement,'nonce'=>$nonce,'issued_at'=>$now,'evidence_expires_at'=>$now+120,'network_observation'=>$network,'non_authority_identity'=>true];
 $att=['schema'=>'titan.t0gm.workload_attestation.v1','workload_id'=>$id,'workload_class'=>$class,'public_key_hash'=>hash('sha256',$pub),'measurement'=>$measurement,'nonce'=>$nonce,'issued_at'=>$now,'evidence_hash'=>hash('sha256',$id.'|'.$measurement.'|'.$nonce)];
 return ['claim'=>$claim,'workload_signature'=>wiSign($claim,$secret),'workload_signature_suite'=>'ed25519','attestation'=>['payload'=>$att,'attestor_key_id'=>'workload-attestor-01','signature_suite'=>'ed25519','signature'=>wiSign($att,$issuerSecret)]];
};

$serverProof=$make('titan://server/prod/api-01','server',$serverPublic,$serverSecret,'sha256:boot-measurement-a',bin2hex(random_bytes(24)),['hostname'=>'api-01','ip'=>'10.20.0.10']);
$s=$verifier->verify($serverProof,$now);
wiAssert($s['workload_id']==='titan://server/prod/api-01','server identity verified independently');
wiAssert($s['network_location_trusted']===false,'network location is observation only');
wiAssert($s['authority_granted']===false && $s['company_authority_granted']===false,'workload identity grants no authority');

foreach ([
 ['titan://service/prod/billing','service',$servicePublic,$serviceSecret,'sha256:svc-release-7'],
 ['titan://container/prod/api/sha256:abc','container',$containerPublic,$containerSecret,'sha256:container-image-001'],
 ['titan://workload/prod/reconcile/42','workload',$jobPublic,$jobSecret,'sha256:job-bundle-042'],
] as [$id,$class,$pub,$secret,$measurement]) {
 $r=$verifier->verify($make($id,$class,$pub,$secret,$measurement,bin2hex(random_bytes(24))),$now);
 wiAssert($r['workload_class']===$class,"$class identity verifies");
}

// Same IP/hostname cannot impersonate a registered workload when its cryptographic key differs.
$evil=sodium_crypto_sign_keypair();$evilSecret=sodium_crypto_sign_secretkey($evil);$evilPublic=sodium_crypto_sign_publickey($evil);
wiExpect('workload-public-key-mismatch',fn()=>$verifier->verify($make('titan://server/prod/api-01','server',$evilPublic,$evilSecret,'sha256:boot-measurement-a',bin2hex(random_bytes(24)),['hostname'=>'api-01','ip'=>'10.20.0.10']),$now));

// Measurement is independently attested and registry-constrained where expected.
wiExpect('workload-measurement-mismatch',fn()=>$verifier->verify($make('titan://container/prod/api/sha256:abc','container',$containerPublic,$containerSecret,'sha256:tampered-image',bin2hex(random_bytes(24))),$now));

// Workload class cannot be relabelled without failing the registry binding.
wiExpect('workload-class-mismatch',fn()=>$verifier->verify($make('titan://service/prod/billing','server',$servicePublic,$serviceSecret,'sha256:svc-release-7',bin2hex(random_bytes(24))),$now));

// Replay of already consumed workload evidence fails closed.
$replay=$make('titan://workload/prod/reconcile/42','workload',$jobPublic,$jobSecret,'sha256:job-bundle-042',bin2hex(random_bytes(24)));
$verifier->verify($replay,$now);
wiExpect('workload-identity-replay-detected',fn()=>$verifier->verify($replay,$now));

// Authority-bearing fields are forbidden in workload identity registrations.
wiExpect('authority-bearing-workload-binding-forbidden',fn()=>new T0gmWorkloadIdentityRegistry([
 'titan://service/x'=>['class'=>'service','public_key_hash'=>hash('sha256',$servicePublic),'binding_id'=>'bad','company_id'=>'company-1']
]));

echo "PASS servers services containers and workloads have independently attestable identities\n";
echo "PASS network location cannot substitute for cryptographic workload identity\n";
echo "PASS workload key class measurement and replay boundaries fail closed\n";
echo "PASS workload identity remains evidence and grants no T0GM or company authority\n";
