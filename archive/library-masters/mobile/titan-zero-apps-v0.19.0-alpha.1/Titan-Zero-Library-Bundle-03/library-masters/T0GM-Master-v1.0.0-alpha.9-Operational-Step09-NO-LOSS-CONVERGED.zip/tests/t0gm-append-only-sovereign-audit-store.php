<?php
require __DIR__.'/bootstrap.php';

use Titan\GodMode\Audit\FileAppendOnlySovereignAuditStore;
use Titan\GodMode\Audit\T0gmSovereignAuditTrustStore;
use Titan\GodMode\Security\CanonicalJson;

function aoAssert(bool $v,string $m):void{if(!$v)throw new RuntimeException("ASSERTION FAILED: $m");}
function aoExpect(string $contains,callable $fn):void{try{$fn();}catch(Throwable $e){aoAssert(str_contains($e->getMessage(),$contains),"expected $contains got {$e->getMessage()}");return;}throw new RuntimeException("expected failure:$contains");}

$dir=sys_get_temp_dir().'/t0gm-audit-'.bin2hex(random_bytes(5));
mkdir($dir,0700,true);
$keypair=sodium_crypto_sign_keypair();
$secret=sodium_crypto_sign_secretkey($keypair);$public=sodium_crypto_sign_publickey($keypair);
$trust=new T0gmSovereignAuditTrustStore(['audit-root-01'=>[
 'suite'=>'ed25519','public_key'=>base64_encode($public),'status'=>'active','trusted_from'=>time()-100,
 'purposes'=>['sovereign_audit_record'],
]]);
$store=new FileAppendOnlySovereignAuditStore($dir,$trust,'audit-root-01',$secret);

$r1=$store->append([
 'evidence_id'=>'ev-001','evidence_type'=>'t0gm.event','occurred_at'=>gmdate('c'),'source'=>'t0gm-control-plane',
 'company_id'=>'co-123','payload'=>['event_id'=>'evt-001','decision'=>'contain-device'],
]);
$r2=$store->append([
 'evidence_id'=>'ev-002','evidence_type'=>'t0gm.execution_receipt','occurred_at'=>gmdate('c'),'source'=>'execution-gateway',
 'company_id'=>'co-123','payload'=>['receipt_id'=>'rcpt-001','result'=>'contained'],
]);
aoAssert($r1['audit_sequence']===1 && $r2['audit_sequence']===2,'store owns monotonic sequence');
aoAssert($r2['previous_record_hash']===$r1['record_hash'],'hash chain binds order');
aoAssert($store->verify()===true,'fresh audit chain verifies');
aoAssert(($r1['semantics']['grants_authority']??null)===false,'audit evidence is non-authoritative');

// The app DB is not the audit authority: evidence can be deleted from an unrelated DB without affecting audit verification.
$appDb=$dir.'/application-db.json';
file_put_contents($appDb,CanonicalJson::encode(['evt-001'=>['x'=>1]]));
file_put_contents($appDb,CanonicalJson::encode([]));
aoAssert($store->verify()===true,'application database compromise does not erase sovereign audit evidence');

// Tamper with one durable log line: chain/signature verification must fail closed.
$log=$dir.'/sovereign-audit.jsonl';
$lines=file($log,FILE_IGNORE_NEW_LINES);$tampered=json_decode($lines[0],true,512,JSON_THROW_ON_ERROR);
$tampered['payload']['decision']='forged-clean-history';
$lines[0]=CanonicalJson::encode($tampered);
file_put_contents($log,implode("\n",$lines)."\n");
aoExpect('sovereign-audit-',fn()=>$store->verifyOrFail());

// Restore, then truncate the tail. Independent create-only checkpoint state must expose the deletion.
file_put_contents($log,CanonicalJson::encode($r1)."\n".CanonicalJson::encode($r2)."\n");
aoAssert($store->verify()===true,'restored chain verifies');
file_put_contents($log,CanonicalJson::encode($r1)."\n");
aoExpect('sovereign-audit-checkpoint-head-mismatch',fn()=>$store->verifyOrFail());

// A record cannot be appended with a duplicate evidence id or a signer not trusted for sovereign audit records.
aoExpect('sovereign-audit-checkpoint-head-mismatch',fn()=>$store->append([
 'evidence_id'=>'ev-003','evidence_type'=>'t0gm.event','occurred_at'=>gmdate('c'),'source'=>'t0gm-control-plane','company_id'=>null,'payload'=>[],
]));

// Verify a clean store rejects duplicate evidence IDs without creating a second sequence entry.
$dir2=$dir.'-dup';mkdir($dir2,0700,true);$store2=new FileAppendOnlySovereignAuditStore($dir2,$trust,'audit-root-01',$secret);
$store2->append(['evidence_id'=>'same','evidence_type'=>'x','occurred_at'=>gmdate('c'),'source'=>'x','company_id'=>null,'payload'=>['n'=>1]]);
aoExpect('sovereign-audit-evidence-id-conflict',fn()=>$store2->append(['evidence_id'=>'same','evidence_type'=>'x','occurred_at'=>gmdate('c'),'source'=>'x','company_id'=>null,'payload'=>['n'=>2]]));

echo "PASS append-only sovereign audit owns immutable sequence hash chain and signatures\n";
echo "PASS application database deletion cannot rewrite the independent audit store\n";
echo "PASS record tamper and tail truncation are detected using chain plus durable checkpoints\n";
echo "PASS audit evidence never creates T0GM company or execution authority\n";
