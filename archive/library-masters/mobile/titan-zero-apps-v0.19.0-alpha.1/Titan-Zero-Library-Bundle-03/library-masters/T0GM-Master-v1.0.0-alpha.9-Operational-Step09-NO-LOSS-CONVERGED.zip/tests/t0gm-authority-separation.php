<?php
require __DIR__ . '/bootstrap.php';
function aAssert($condition,string $message): void { if(!$condition) throw new RuntimeException('ASSERTION FAILED: '.$message); }

use Titan\GodMode\Authority\AuthorityArtifactFactory;
use Titan\GodMode\Authority\ExecutionAuthorityGate;
use Titan\GodMode\Capability\SovereignCapabilityFactory;

$artifacts = new AuthorityArtifactFactory();
$capFactory = new SovereignCapabilityFactory();
$gate = new ExecutionAuthorityGate();

$target = ['target_type'=>'database','target_id'=>'crm-prod','system'=>'titan.crm','environment'=>'production'];
$intent = $artifacts->intent([
    'company_id'=>'company-123',
    'actor'=>['actor_id'=>'ai-recovery-1','actor_type'=>'advanced_intelligence'],
    'target'=>$target,
    'purpose'=>'Recover customer 9 from verified snapshot',
    'requested_operation'=>'customer.restore_verified_snapshot',
]);
$plan = $artifacts->plan([
    'company_id'=>'company-123',
    'actor'=>['actor_id'=>'ai-recovery-1','actor_type'=>'advanced_intelligence'],
    'target'=>$target,
    'purpose'=>'Recover customer 9 from verified snapshot',
    'intent_id'=>$intent['artifact_id'],
    'steps'=>[
        ['step_id'=>'verify','operation'=>'customer.verify_snapshot'],
        ['step_id'=>'restore','operation'=>'customer.restore_verified_snapshot'],
    ],
]);

$extinction=[];
foreach(['purpose_invalid','authority_revoked','company_changed','target_changed','risk_constraint_breached','safety_interlock','superseded','t0gm_extinguish'] as $type){
    $extinction[]=['condition_id'=>'ext-'.$type,'condition_type'=>$type,'description'=>'Extinguish when '.$type];
}
$cap = $capFactory->create([
    'authority_holder'=>['identity_id'=>'t0gm-human-1','authority_class'=>'titan.god_mode','actor_type'=>'human'],
    'authority_basis'=>['basis_type'=>'titan_managed','basis_id'=>'agreement-7','description'=>'Managed recovery authority'],
    'company_id'=>'company-123',
    'purpose'=>['purpose_id'=>'recover-customer-9','statement'=>'Recover verified customer state','intended_outcome'=>'Customer restored'],
    'target'=>$target + ['resource_ids'=>['customer-9']],
    'permitted_effects'=>[[
        'effect_id'=>'effect-restore','operation'=>'customer.restore_verified_snapshot','resource_type'=>'customer','resource_ids'=>['customer-9'],
        'constraints'=>['snapshot_must_be_verified'=>true]
    ]],
    'prohibited_effects'=>[['operation'=>'customer.delete','reason'=>'Outside recovery purpose']],
    'evidence'=>[['evidence_id'=>'ev-incident-1','evidence_type'=>'incident','source'=>'t0gm.feed','integrity_ref'=>'sha256:abc']],
    'risk_constraints'=>['max_risk_score'=>70,'max_financial_exposure'=>20,'max_physical_impact'=>0,'max_environmental_impact'=>0,'prohibited_risk_bands'=>['extreme']],
    'extinction_conditions'=>$extinction,
]);

$request = [
    'company_id'=>'company-123','target'=>$target,'operation'=>'customer.restore_verified_snapshot','resource_id'=>'customer-9',
    'actor'=>['actor_id'=>'t0gm-human-1','actor_type'=>'human'],
    'risk'=>['score'=>30,'band'=>'medium','financial_exposure'=>5,'physical_impact'=>0,'environmental_impact'=>0],
    'evidence_ids'=>['ev-incident-1'],'triggered_extinction_conditions'=>[],
    'execution_authority'=>['authority_type'=>'sovereign_capability','capability'=>$cap],
];

$allowed = $gate->evaluate($intent,$plan,$request);
aAssert($allowed->allowed,'independent sovereign execution authority permits causally bound effect');
aAssert($allowed->matchedEffectId==='effect-restore','execution effect is independently matched');
aAssert(($allowed->lineage['intent_id']??null)===$intent['artifact_id'],'execution lineage retains intent');
aAssert(($allowed->lineage['plan_id']??null)===$plan['artifact_id'],'execution lineage retains plan');


$integrityRequired=$request;
$integrityRequired['runtime_integrity_required']=true;
$integrityRequired['workload_identity']=['workload_id'=>'titan://service/prod/billing','binding_id'=>'wbind-service'];
$deniedNoIntegrity=$gate->evaluate($intent,$plan,$integrityRequired);
aAssert(!$deniedNoIntegrity->allowed && in_array('runtime_integrity_evidence_required',$deniedNoIntegrity->reasons,true),'privileged execution fails closed without required runtime integrity evidence');
$integrityRequired['runtime_integrity_receipt']=['runtime_integrity_valid'=>true,'workload_id'=>'titan://service/prod/billing','workload_binding_id'=>'wbind-service','evidence_only'=>true,'authority_granted'=>false];
$allowedIntegrity=$gate->evaluate($intent,$plan,$integrityRequired);
aAssert($allowedIntegrity->allowed,'privileged execution proceeds when required runtime integrity is verified and bound');
$wrongIntegrity=$integrityRequired;
$wrongIntegrity['runtime_integrity_receipt']['workload_binding_id']='other-binding';
$deniedWrongIntegrity=$gate->evaluate($intent,$plan,$wrongIntegrity);
aAssert(!$deniedWrongIntegrity->allowed && in_array('runtime_integrity_workload_binding_mismatch',$deniedWrongIntegrity->reasons,true),'runtime integrity receipt cannot be substituted across workload bindings');

$aiExec=$request;
$aiExec['actor']=['actor_id'=>'ai-recovery-1','actor_type'=>'advanced_intelligence'];
$deniedAi=$gate->evaluate($intent,$plan,$aiExec);
aAssert(!$deniedAi->allowed && in_array('advanced_intelligence_cannot_inherit_t0gm_execution_authority',$deniedAi->reasons,true),'AI plan author cannot inherit T0GM execution authority');

$decisionAsAuthority=$request;
$decisionAsAuthority['execution_authority']=['authority_type'=>'decision','decision_id'=>'d-1','confidence'=>0.99];
$deniedDecision=$gate->evaluate($intent,$plan,$decisionAsAuthority);
aAssert(!$deniedDecision->allowed && in_array('reasoning_or_decision_is_not_execution_authority',$deniedDecision->reasons,true),'AI decision is not execution authority');

$discoveryAsAuthority=$request;
$discoveryAsAuthority['execution_authority']=['authority_type'=>'discovery','method'=>'restore snapshot'];
$deniedDiscovery=$gate->evaluate($intent,$plan,$discoveryAsAuthority);
aAssert(!$deniedDiscovery->allowed && in_array('reasoning_or_decision_is_not_execution_authority',$deniedDiscovery->reasons,true),'discovered solution is not execution authority');

$wrongPlan=$plan;
$wrongPlan['intent_id']='intent_unrelated';
$wrongPlan['integrity']=['algorithm'=>'sha256','digest'=>str_repeat('0',64)];
$deniedWrongPlan=$gate->evaluate($intent,$wrongPlan,$request);
aAssert(!$deniedWrongPlan->allowed,'unrelated/tampered plan cannot authorize execution');

$unplanned=$request;
$unplanned['operation']='customer.delete';
$deniedUnplanned=$gate->evaluate($intent,$plan,$unplanned);
aAssert(!$deniedUnplanned->allowed && in_array('execution_not_requested_by_intent',$deniedUnplanned->reasons,true),'capability cannot be stretched to an operation outside intent');

$crossCompany=$request;
$crossCompany['company_id']='company-999';
$deniedCompany=$gate->evaluate($intent,$plan,$crossCompany);
aAssert(!$deniedCompany->allowed && in_array('execution_company_mismatch',$deniedCompany->reasons,true),'company boundary remains causally bound across stages');

$missingAuthority=$request;
unset($missingAuthority['execution_authority']);
$deniedMissing=$gate->evaluate($intent,$plan,$missingAuthority);
aAssert(!$deniedMissing->allowed && in_array('independent_execution_authority_required',$deniedMissing->reasons,true),'intent plus plan alone never become execution authority');

echo "T0GM intent/planning/execution authority separation tests: PASS\n";
