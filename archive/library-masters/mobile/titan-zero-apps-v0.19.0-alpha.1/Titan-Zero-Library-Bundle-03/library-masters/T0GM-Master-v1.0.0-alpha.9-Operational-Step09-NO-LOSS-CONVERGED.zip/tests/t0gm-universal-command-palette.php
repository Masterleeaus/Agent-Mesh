<?php
require __DIR__.'/bootstrap.php';
use Titan\GodMode\App\T0gmCommandSurface;
use Titan\GodMode\App\T0gmDeviceState;
use Titan\GodMode\App\T0gmSovereignSessionContext;
use Titan\GodMode\Command\T0gmUniversalCommandPalette;
use Titan\GodMode\Command\T0gmCommandTargetRegistry;
use Titan\GodMode\Security\GodModeException;
function cpAssert($c,$m){if(!$c)throw new RuntimeException('ASSERTION FAILED: '.$m);} function cpExpect($r,$f){try{$f();}catch(GodModeException $e){cpAssert($e->getMessage()===$r,"expected $r got {$e->getMessage()}");return;}throw new RuntimeException('expected '.$r);}
$session=new T0gmSovereignSessionContext(['session_id'=>'s1','identity_id'=>'T0GM_OWNER','authority_class'=>'titan.god_mode','actor_type'=>'human','identity_proof_digest'=>str_repeat('a',64),'device_binding_id'=>'d1','created_at'=>'2026-09-04T07:24:00Z']);
$device=T0gmDeviceState::fromEvidence(['device_binding_id'=>'d1','trust_state'=>'active','integrity_state'=>'verified','isolation_state'=>'clear','connectivity'=>'online','observed_at'=>'2026-09-04T07:24:01Z','evidence_digest'=>str_repeat('b',64)]);
$registry=new T0gmCommandTargetRegistry([
 ['target_type'=>'company','target_id'=>'company_a','company_id'=>'company_a','label'=>'Acme Services','keywords'=>['acme','melbourne']],
 ['target_type'=>'system','target_id'=>'crm','company_id'=>'company_a','label'=>'CRM','keywords'=>['customer','revenue']],
 ['target_type'=>'agent','target_id'=>'ai-revenue','company_id'=>'company_a','label'=>'Revenue AI','keywords'=>['agent','overdue']],
 ['target_type'=>'workflow','target_id'=>'invoice-followup','company_id'=>'company_a','label'=>'Invoice Follow-up','keywords'=>['workflow','invoice']],
 ['target_type'=>'infrastructure','target_id'=>'db-primary','company_id'=>'company_b','label'=>'Primary Database','keywords'=>['postgres','database']],
]);
$surface=new T0gmCommandSurface(['inspect_request','execute_request','supersede_request','contain_request']);
$palette=new T0gmUniversalCommandPalette($registry,$surface,$session,$device);
$r=$palette->search('invoice'); cpAssert(count($r)===1 && $r[0]['target_id']==='invoice-followup','search across workflow metadata');
$r=$palette->search('database'); cpAssert($r[0]['company_id']==='company_b' && $r[0]['target_type']==='infrastructure','cross-company search exposes scoped target');
$i=$palette->inspect('system','crm','company_a'); cpAssert($i['projection_only']===true && $i['authority_granted']===false,'inspect grants no authority');
$intent=$palette->issue(['command_id'=>'cmd-1','command_type'=>'execute_request','company_id'=>'company_a','target'=>['target_type'=>'workflow','target_id'=>'invoice-followup'],'purpose'=>'Run governed overdue invoice follow-up','requested_effects'=>['workflow.start'],'submitted_at'=>'2026-09-04T07:25:00Z']);
cpAssert($intent['requires_governed_execution']===true && $intent['execution_authority_granted']===false,'issue creates governed intent only'); cpAssert($intent['sovereign_session_id']==='s1' && $intent['device_binding_id']==='d1','session/device bound');
cpExpect('palette-target-company-mismatch',fn()=>$palette->issue(['command_id'=>'cmd-2','command_type'=>'execute_request','company_id'=>'company_b','target'=>['target_type'=>'workflow','target_id'=>'invoice-followup'],'purpose'=>'bad','requested_effects'=>['workflow.start'],'submitted_at'=>'2026-09-04T07:25:01Z']));
cpExpect('legacy-tenant-boundary-forbidden:tenant_id',fn()=>$palette->issue(['command_id'=>'cmd-3','command_type'=>'inspect_request','company_id'=>'company_a','tenant_id'=>'legacy','target'=>['target_type'=>'system','target_id'=>'crm'],'purpose'=>'bad','requested_effects'=>[],'submitted_at'=>'2026-09-04T07:25:02Z']));
echo "PASS universal search across companies/systems/agents/workflows/infrastructure\nPASS projection-only inspection\nPASS governed command intent issuance with company/session/device binding\nPASS target-company mismatch and legacy tenant fail closed\n";
