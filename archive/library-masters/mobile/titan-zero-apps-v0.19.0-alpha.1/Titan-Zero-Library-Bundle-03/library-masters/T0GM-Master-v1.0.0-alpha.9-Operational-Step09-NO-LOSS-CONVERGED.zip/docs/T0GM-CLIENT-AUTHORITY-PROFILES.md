# T0GM Client Authority Profiles — Step 13

Client authority profiles are executable policy inputs. They do not grant T0GM identity and do not replace Sovereign Capabilities. They constrain whether an otherwise-valid capability may be exercised for a specific company and contract authority basis.

## Profiles

- **Titan Managed** — bounded capability execution may proceed under the encoded management authority basis without routine client approval.
- **Co-Managed** — observation/diagnostic work may proceed, while mutation, recovery and destructive classes require matching client approval.
- **Client Controlled** — state-changing execution remains blocked until explicit client approval matching company and operation is supplied.
- **Restricted** — fail-closed allowlist model. Target types, operations and action classes must be explicitly encoded.
- **Observation Only** — only observation/diagnostic classes can proceed. State mutation/recovery is structurally denied.

## Invariants

1. `company_id` is the sole canonical tenant/company boundary.
2. Profile `company_id`, capability `company_id` and execution request `company_id` must match exactly.
3. The profile's `authority_basis_id` must match the Sovereign Capability authority basis.
4. Profile integrity is verified before policy evaluation.
5. A client profile constrains authority; it cannot manufacture or expand a Sovereign Capability.
6. Target adapters consume the profile as an independent policy gate before translating an operation.
7. Observation Only cannot be reinterpreted as an admin/read-write session.
8. Restricted means explicit allowlist, not “mostly restricted.”
9. Client approval is operation- and company-bound evidence, not a reusable global consent flag.
10. T0GM sovereign identity remains cryptographically separate from Laravel roles, DB users and client profiles.
