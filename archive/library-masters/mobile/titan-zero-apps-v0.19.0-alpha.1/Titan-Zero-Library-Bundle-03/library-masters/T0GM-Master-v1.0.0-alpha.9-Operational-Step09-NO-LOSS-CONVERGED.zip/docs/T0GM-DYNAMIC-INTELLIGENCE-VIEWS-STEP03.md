# T0GM Operational App — Step 03 Dynamic Intelligence Views

Step 03 turns the Step 02 Sovereign Home Feed into generated T0GM views without creating a parallel activity authority.

Canonical persistent views are Security, Money, Workforce, Environment, Customers, Infrastructure and Critical Activity. Definitions are stored durably through `FileDynamicIntelligenceViewStore` and can be reconstructed across process restarts.

Temporary views may be created by T0GM intelligence using bounded filters over the sovereign feed. They require explicit extinction conditions and can be extinguished when those conditions are met. They never create, transfer or expand execution authority.

`company_id` remains the only canonical company boundary. Legacy tenant keys are rejected recursively.
