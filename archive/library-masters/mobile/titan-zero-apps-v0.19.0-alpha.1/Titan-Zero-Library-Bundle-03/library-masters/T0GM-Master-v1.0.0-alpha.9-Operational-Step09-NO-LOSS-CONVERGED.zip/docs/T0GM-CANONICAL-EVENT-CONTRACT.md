# T0GM Canonical Event Contract — v1

## Purpose

Every meaningful T0GM-observable fact uses one immutable envelope so sovereign oversight can consistently reconstruct what was observed, decided, authorized, executed, changed, challenged, intervened upon, or superseded.

This contract is an **oversight projection contract**, not a new business authority provider. Titan Signal remains the canonical event fabric. Domain systems remain authoritative for their own business state. T0GM events carry references and evidence; they do not become the underlying CRM, finance, workforce, safety, or infrastructure truth.

## Canonical kinds

- `observation`
- `ai_decision`
- `human_action`
- `authority_use`
- `execution`
- `result`
- `anomaly`
- `intervention`
- `supersession`

## Common spine

Every event binds:

- globally unique `event_id` and schema version;
- `occurred_at` and `recorded_at` as evidence/order timestamps only;
- `company_context` using **only canonical `company_id`** for company-scoped activity;
- typed actor identity and optional authority class;
- source system/component/version;
- typed subject;
- trace/correlation/causation/parent lineage;
- multi-dimensional risk projection and 0–100 sorting score;
- sovereign T0GM visibility and attention tier;
- evidence references/provenance rather than hidden reasoning;
- event-kind-specific payload;
- optional canonical integrity hash / hash-chain linkage.

## Company boundary

`company_id` is the sole canonical company/tenant boundary. `tenant_id`, `tenant_company_id` and equivalent legacy keys are rejected anywhere in the envelope. Platform-scope T0GM events use `company_context.scope=platform`; events affecting one company use `scope=company` plus an explicit `company_id`.

Cross-company analysis is represented by multiple source/related event references and explicit company-scoped facts; it does not create a second tenant boundary.

## Causality and immutability

Events are append-only facts. Corrective action never overwrites prior evidence.

A supersession emits a new `supersession` event containing `supersedes_event_ids[]`. The original AI decision/action remains preserved. Downstream causal processing can then determine which dependent effects should stop, reverse, recompute, remain, or require investigation.

## Advanced Intelligence decisions

AI decision events store structured determination data, reason codes, assumptions, confidence/uncertainty, evidence references, policy/authority references and alternatives where available. They do **not** require or expose private chain-of-thought. The objective is reconstructable decision evidence, not hidden reasoning disclosure.

## T0GM oversight

`oversight.visibility` is always `t0gm_sovereign`. Risk controls attention and routing, not whether T0GM is allowed to observe a governed event.

The envelope can be distributed to independent T0GM Advanced Intelligence reviewers. Their reviews should themselves be emitted as observations/decisions and preserve specialist disagreement rather than averaging it away.

## Time semantics

`occurred_at`, `recorded_at`, source timestamps, and duration measurements describe reality. They do not create or continue authority.

Capability duration/continuance belongs to the authority/capability system and is evaluated from current justification. Legacy transport credential expiry may remain as replay/cryptographic hygiene, but is not the T0GM authority semantic.

## Risk semantics

`risk.score` supports feed ranking. `risk.dimensions` preserves individual dimensions such as cyber, financial, privacy, legal, environmental, operational, physical safety, reversibility, blast radius, uncertainty and anomaly strength. High/Extreme dimensions must not disappear merely because an aggregate score is lower.

## Integrity

`T0gmCanonicalHasher` can attach a SHA-256 canonical hash and optional previous-event hash. This supplies tamper-evidence for prototype/alpha pipelines. Signing, hardware roots, post-quantum cryptography and zero-knowledge proofs remain crypto-agile future layers and must not change the event semantics.
