# T0GM Contained Service-Business Prototype — Step 21

This step exercises the cumulative T0GM control plane against one deliberately ordinary service-business vertical before any hazardous physical-control integration.

## Included business domains

- CRM: lead creation and customer state
- Bookings/jobs: booking creation and job status
- Money: invoice issuance and payment recording
- Staff: worker assignment
- Communications: outbound message state
- Advanced Intelligence activity: recommendations recorded as AI decisions with `execution_authority=false`

`company_id` remains the only canonical company boundary. The prototype is intentionally in-memory and synthetic; it is a reference integration harness, not production storage or a live business connector.

## State-transition discipline

Every state-changing prototype action produces:

1. a canonical T0GM execution event,
2. pre-state,
3. intended state,
4. actual state,
5. dependency metadata,
6. reversibility metadata,
7. a continuous-verification observation proving whether intended and observed state converge.

AI recommendations are different: they are emitted as `ai_decision` evidence and deliberately do not create execution authority or a state-changing transition.

## Safety boundary

The contained vertical rejects OT, IoT, robotics, vehicle and generic physical-control action prefixes. It also rejects unknown privileged operations rather than falling back to a generic shell/SQL/admin channel. Later physical-system adapters must enter through the existing Sovereign Capability contract and their own safety-certified controls.

## Purpose of the prototype

The point is not to build another CRM. It is to prove that T0GM event lineage, state transitions, continuous verification, AI/non-AI separation and company isolation work coherently in a realistic business journey before expanding into higher-consequence infrastructure or physical systems.
