# T0GM Intelligent Feed Ranking & Views — Step 04

## Purpose

Step 04 turns the immutable Sovereign Activity Feed into an explainable attention surface without changing event truth or creating new authority. Ranking is a versioned projection over canonical `titan.t0gm.event.v1` records.

## Canonical factors

Every event receives a deterministic `t0gm.attention.v1` projection containing 0–100 scores for:

- risk;
- significance;
- anomaly;
- urgency;
- reversibility and derived irreversibility (`100 - reversibility`);
- financial exposure;
- physical impact;
- environmental impact;
- confidence;
- dependency/blast-radius pressure.

Producer-supplied `attention_signals` are optional for backward compatibility. Missing values are conservatively derived from canonical event risk, oversight tier, evidence, event kind and lineage. Derived values are projections, never reconstructed domain truth.

## Deterministic attention model

Weighted base ranking:

- risk 24%;
- significance 14%;
- anomaly 12%;
- urgency 12%;
- irreversibility 10%;
- financial exposure 8%;
- physical impact 8%;
- environmental impact 6%;
- dependency 6%.

Confidence is not used to make an event safer. Material uncertainty can add investigative attention when risk/significance/anomaly are already meaningful.

### Non-averaging safety floors

The composite score is only an attention-ranking mechanism. It cannot dilute a severe individual hazard. Step 04 therefore applies deterministic floors for extreme overall risk, critical physical safety, extreme financial exposure, extreme environmental impact, severe anomaly, immediate urgency, and material irreversible effects.

This preserves the Titan invariant that HIGH/EXTREME consequences cannot be averaged away.

## Named sovereign views

- `critical_now` — critical attention projections, including safety floors.
- `ai_decisions` — canonical Advanced Intelligence decision events.
- `security` — security/cyber/identity/authority/privacy/fraud/access related events.
- `money` — events with financial exposure or finance/money/payment/ledger domain signals.
- `environment` — events with environmental impact or environment/resource/water/energy/waste/emissions signals.
- `cross_company` — platform-scope events plus correlations proven to span more than one visible `company_id`.
- `superseded` — both sovereign supersession events and the events they supersede.
- `irreversible` — events whose derived irreversibility is at least 70.
- `everything` — every event visible to the caller, ranked by attention.

## Cross-company privacy rule

Cross-company intelligence is computed only from records already visible to the calling access context. T0GM sovereign authority can correlate all governed companies. A company-scoped oversight intelligence cannot infer hidden participation by another company because invisible records are excluded before correlation analysis.

## Supersession rule

Ranking and views never alter the superseded event. A view projection may annotate an event with `superseded=true` and `superseded_by[]`, but the source record remains immutable and its prior determination/evidence remains historically truthful.

## Authority boundary

Neither attention score, view membership, confidence nor critical status creates execution authority. The feed ranks what deserves attention; capability/authority systems remain responsible for what may actually be caused.

## Versioning

The ranking contract is `t0gm.attention.v1`. Future models may re-rank historical immutable events using a new version without rewriting the event store or audit lineage.
