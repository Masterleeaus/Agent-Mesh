# T0GM Step 06 — Production Zero-Knowledge Provider

Step 06 replaces the test-only HMAC ZK stand-in as the production profile with a real proof-of-knowledge provider based on Schnorr proofs over libsodium Ristretto255 using Fiat–Shamir domain separation.

## Production boundary

Titan's existing `ZeroKnowledgeVerifier` abstraction remains the verifier boundary. `Ristretto255SchnorrVerifier` implements it, while `T0gmZeroKnowledgeProviderRegistry` makes the logical proof system explicitly replaceable. Proving is separated through `ZeroKnowledgeProverBroker`: the Titan application sends a witness reference and public statement, never sovereign witness bytes.

The concrete proof demonstrates knowledge of the scalar corresponding to the Ristretto255 `possession_public_key`. The proof contains only a commitment and response. The public statement, logical proof-system identifier, commitment, and public key are domain-bound into the Fiat–Shamir challenge.

## Signed public-key binding

The production crypto profile is `t0gm-hybrid-pqc-zk-v2`. It requires the payload field `zk_possession_public_key`. Because the sovereign identity signatures cover the entire payload, the ZK public key cannot be swapped independently of the classical/PQC identity signatures. Historical `t0gm-hybrid-pqc-v1` proofs remain verifiable and retain their prior provider semantics.

## Constitutional invariant

A valid zero-knowledge proof establishes only that the prover knows the witness corresponding to the signed public key for the exact public statement. It does **not** create `company_id` scope, business permission, Sovereign Capability authority, or execution authority.

## Operational requirements

Production proving must be brokered to a custody boundary that resolves `witness_ref` internally. The application must not place `witness`, `secret`, or `private_key` values in ZK context. Unknown providers and malformed/tampered proofs fail closed.
