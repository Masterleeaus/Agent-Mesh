# T0GM Notification Distribution — Step 17

Step 17 projects critical sovereign activity outside the Titan interface so Titan 0 God Mode does not need to remain inside the application continuously.

## Canonical rule

Notifications are **derived distribution projections**. The canonical T0GM event, sovereign feed, evidence system and immutable audit lineage remain authoritative. Delivery success/failure never changes the truth or authority of the underlying event.

## Initial channels

- desktop
- browser
- mobile
- explicitly selected external channels through the same transport contract

External endpoints are fail-closed: they must be selected on the endpoint **and** enabled by policy. This prevents an integration from silently forwarding sovereign activity to a third party.

## Routing

`T0gmNotificationPolicy` sets a minimum attention tier and enabled channels. The default implementation is critical-only and native-channel-first. `T0gmAttentionScorer` provides the same deterministic ranking used by the sovereign feed, including non-averaging critical-domain floors.

## Privacy and minimization

Notification payloads contain only routing/attention context: event ID, tier, safe subject summary, `company_id`, reason codes and correlation ID. Evidence bodies, credentials, identity proofs, raw target payloads and sensitive provenance references are deliberately excluded.

## Delivery semantics

Distribution is idempotent for each `(event_id, endpoint_id)` in one dispatcher lifecycle. Each attempt returns an explicit delivery receipt. A transport failure remains `failed`; Titan must never report delivery success merely because the canonical event exists.

Future durable delivery stores may persist dedupe keys, retries, acknowledgements, escalation windows and provider receipts without modifying the sovereign event.

## Authority boundary

Notification transports cannot grant authority, execute a capability, change `company_id`, acknowledge on behalf of T0GM, suppress the sovereign feed, or mutate audit history. They receive a minimized projection only.
