# Step 9 — Advanced Intelligence Workforce Team Structure

T0GM can compose persistent and temporary Advanced Intelligence teams from canonical workforce identities.

Supported roles are specialist, supervisor, challenger, investigator, coordinator and ordinary member. A worker may hold multiple organizational roles, but a role never grants capabilities. Each member continues to operate only under its own Step 8 capability manifest and the governed execution chain.

Temporary mission teams require an objective plus explicit extinction conditions. They can be closed when one of those conditions becomes true. Formation and closure cannot be self-authorized by a team member.

Team structure never aggregates member permissions, transfers authority between workers, or creates T0GM/sovereign authority.
