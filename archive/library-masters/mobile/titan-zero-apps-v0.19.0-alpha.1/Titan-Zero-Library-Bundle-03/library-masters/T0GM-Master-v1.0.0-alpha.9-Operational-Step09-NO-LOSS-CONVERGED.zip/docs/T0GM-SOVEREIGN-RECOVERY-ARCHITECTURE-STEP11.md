# T0GM Sovereign Recovery Architecture — Step 11

## Purpose

Restore access to the **same** Titan 0 God Mode sovereign principal after device loss or compromise without transferring T0GM sovereignty to a recovery witness, custodian, institution, Advanced Intelligence worker, application administrator, or tenant role.

## Constitutional boundary

Recovery does not create a replacement sovereign person. It authorizes enrollment of a replacement device into the existing sovereign identity graph.

`recovery witnesses + sovereign recovery continuity proof -> replacement device binding -> normal T0GM identity proof`

It does **not** produce:

`recovery witnesses -> T0GM authority`

or:

`recovery root -> company capability`

## Two independent requirements

1. **Recovery quorum.** A configured threshold of independent recovery witnesses signs the exact recovery request hash. Witnesses can attest only to recovery and cannot exercise T0GM authority.
2. **Sovereign recovery continuity proof.** A separately registered user-controlled recovery root, purpose-bound to `sovereign_recovery_only`, proves continuity of the existing T0GM principal.

Neither side can complete recovery alone.

## Recovery result

Successful verification yields `titan.t0gm.recovery_enrollment_authorization.v1`. The authorization contains a normal device-binding entry for the replacement device and explicitly states:

- `grants_t0gm_sovereignty = false`
- `transfers_sovereignty = false`
- `execution_authority_granted = false`
- `company_authority_embedded = false`
- `capability_granted = false`
- `requires_normal_identity_proof_after_enrollment = true`

The new device therefore still has to pass the ordinary cryptographic T0GM identity root before any downstream capability can be considered.

## Anti-transfer rules

- Advanced Intelligence cannot count as a sovereign recovery witness.
- Recovery witness records cannot contain company, capability, permission, or authority-class bindings.
- The recovery root is a separate purpose-bound key class and is not a day-to-day T0GM execution credential.
- The recovery request is non-tenant and cannot contain `company_id`, legacy tenant IDs, role IDs, permission IDs, capability IDs, or execution IDs.
- Duplicate witness identities never increase quorum.
- Recovery challenges are replay protected.

## Device-loss behavior

Recovery does not delete or rewrite previous device history. Healthy devices remain independently valid. A lost or compromised device that was quarantined by Step 10 remains quarantined after recovery. Historical evidence remains inspectable under its original provenance and time boundaries.

## Threat-model note

This architecture deliberately prefers fail-closed loss of access over silently transferring sovereignty. If both the user-controlled sovereign recovery root and all valid recovery paths are lost, Titan must not manufacture a new T0GM authority from administrator privilege, AI inference, database state, or witness consensus alone.
