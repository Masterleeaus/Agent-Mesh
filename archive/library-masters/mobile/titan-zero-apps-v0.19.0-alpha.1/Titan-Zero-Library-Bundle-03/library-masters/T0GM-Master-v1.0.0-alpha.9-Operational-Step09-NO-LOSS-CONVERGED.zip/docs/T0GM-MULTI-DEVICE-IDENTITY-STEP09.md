# T0GM Step 09 — Multi-Device Sovereign Identity

Step 09 allows several independently proven user devices to belong to the same `titan.god_mode` sovereign principal without turning a device into the sovereign identity itself.

## Constitutional boundary

A device binding proves **which registered device participated** in a sovereign identity proof. It does not create `company_id` authority, application-role authority, a Sovereign Capability, permission, entitlement, or execution authority.

## Binding model

Each device has its own:

- `device_key_id`
- hardware-backed public-key fingerprint
- stable `binding_id`
- lifecycle (`active`, `retired`, `revoked`)
- independent `bound_from`, `retired_at`, and `revoked_at` boundaries
- provenance metadata describing enrollment/binding evidence

Several bindings may name the same T0GM `principal_id`. They remain independent records.

## Verification rules

For current use, the identity root verifies the existing sovereign root signature and hardware attestation, then independently checks the presented device against the device binding registry. A device ID cannot be paired with another registered device's public key. Retired and revoked bindings cannot be used for a new live proof.

Historical inspection is separate from current authorization. Evidence from before a retirement/revocation boundary can retain its original device provenance; evidence at or after a revocation boundary fails verification against that binding.

## Isolation property

Changing one binding does not change sibling bindings. Revoking Device B does not revoke Device A merely because both belong to the same sovereign principal.

## Provenance

`T0gmIdentityAccessGate` projects the verified `device_binding_id` into authorization/audit evidence so downstream sovereign events can retain which physical device participated without mistaking the device for the authority source.
