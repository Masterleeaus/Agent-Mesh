# T0GM Step 1 — Production HSM and Secure-Enclave Key Custody

This pass makes sovereign signing keys non-exportable hardware assets. Titan handles only public descriptors and opaque key references; no API exists to export a sovereign private key.

## Boundaries

- **HSM:** `Pkcs11HsmCustodyProvider` invokes a configured OpenSSL PKCS#11/store provider using an opaque `pkcs11:` URI. PIN values/sources are rejected from Titan configuration; HSM authentication/session establishment remains outside application code.
- **Secure enclave:** `BrokeredSecureEnclaveCustodyProvider` delegates signing to an out-of-process `SecureEnclaveBroker`. The PHP runtime receives only the detached signature.
- **Policy:** sovereign keys must be hardware-backed, non-exportable, purpose-bound, attested, use approved custody classes, and hybrid signing keys must reside in distinct custody domains.
- **Authority separation:** custody proves control of a sovereign key. It does not carry `company_id`, permission, client authority, execution authority, or capability scope.

## Fail-closed rules

Exportable/software keys, private material in descriptors, embedded HSM PINs, wrong signing purpose, suite mismatch, unknown providers, duplicate custody domains, or missing required suites are rejected before a sovereign proof is emitted.
