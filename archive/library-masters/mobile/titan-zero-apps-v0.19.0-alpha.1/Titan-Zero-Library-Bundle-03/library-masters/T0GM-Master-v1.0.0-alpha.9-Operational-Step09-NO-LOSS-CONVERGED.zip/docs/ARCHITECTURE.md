# Titan God Mode Isolation — Step 22

## Canonical authority

`titan.god_mode` is not a tenant role, permission, capability bundle, team membership, plan, entitlement or super-admin flag.

It is a separate **non-tenant builder control-plane principal class**.

Normal business owners remain the highest normal authority inside their own `company_id`.

## Cryptographic chain

1. An isolated God Mode root signs a device certificate.
2. The certificate binds:
   - `titan.god_mode`;
   - the one configured control-plane principal;
   - one device public key;
   - a key id;
   - audience;
   - validity policy;
   - `non_tenant=true`.
3. The root private key is not present in the normal Laravel/tenant runtime.
4. Each God Mode request is separately signed by the certified device key.
5. The request proof binds purpose, action, target, nonce and expiry.
6. Replay nonces are consumed once.
7. Company-affecting requests require an explicit canonical `company_id`.

The application is **verifier-only**. Ordinary administrators cannot mint the credential required to pass the gate.

## Architectural isolation

God Mode endpoints live under a dedicated control-plane route space:

`/_titan-control-plane/god-mode/*`

They must not live under tenant/company role or permission administration.

Normal role creation, permission creation, role inheritance, promotion, impersonation, sudo, delegated administration and tenant owner workflows are rejected if they attempt to carry God Mode markers.

## Fail-closed rules

Reject when:
- root signature is invalid;
- device signature is invalid;
- root key id is unknown;
- principal id differs from the configured owner control-plane principal;
- credential is tenant-bound;
- target uses a legacy tenant boundary;
- request is replayed;
- proof is expired or outside its device certificate;
- purpose is missing;
- impersonation/sudo/delegated normal-admin state is active;
- role/permission data contains a God Mode marker.

## Cryptographic maturity

This implementation uses standard Ed25519 signatures through libsodium because they are available and auditable today.

It deliberately does **not** claim:
- post-quantum signatures;
- zero-knowledge authentication;
- hardware-backed key storage;
- HSM enforcement;
- remote attestation.

The interfaces are designed so the root signer and device signer can later move behind HSM/secure-enclave/post-quantum providers without changing tenant role semantics.

## Step 02 compatibility clarification — T0GM event contract

The request-proof `expires_at` field above is retained as a cryptographic transport/replay bound for the inherited verifier. It is **not** the canonical duration of T0GM authority. Sovereign authority continuance is state/purpose/evidence justified and will be modeled by the capability/continuance layer. The canonical event envelope records time as evidence/order metadata only.

All meaningful T0GM observations, decisions, actions, authority uses, executions, results, anomalies, interventions and supersessions use `titan.t0gm.event.v1` for sovereign oversight projection. Titan Signal remains the event-fabric owner; this package defines the envelope and validation boundary, not a competing event bus.


## Step 04 — Intelligent Feed Ranking and Views

The immutable Sovereign Activity Feed is projected through `t0gm.attention.v1`. Ranking is deterministic, explainable and versioned; it does not mutate canonical events or confer authority. Named sovereign views are implemented by `T0gmFeedViewService`, with cross-company correlation computed only from events already visible to the caller.

## Step 05 — T0GM Advanced Intelligence Oversight Team
The sovereign feed now supports an independent nine-specialist T0GM oversight team. Security, Governance, Financial, Operational, Privacy/Legal, Environmental, Physical Safety, Anomaly and Causal Intelligence review the same immutable event independently. Each produces its own disposition, confidence, reason codes, evidence references, recommended actions and limitations. Review sets deliberately contain no consensus score; disagreement and material objections are first-class output. The oversight team is not an authority provider and cannot inherit Titan 0 God Mode sovereign authority.

## Step 06 — Sovereign Capability authority primitive

T0GM authority is now represented canonically by `titan.t0gm.sovereign-capability.v1`, not by an application role or standing administrator session. Capabilities bind one sovereign human authority holder to one `company_id`, purpose, exact target context, explicit permitted effects, explicit prohibited effects, evidence references, risk ceilings and extinction conditions. Wildcard company grants and unbounded `admin/root/all/*` effects are invalid. Time remains evidence rather than authority duration. Execution adapters may use native privileged mechanisms only as implementation details beneath this contract.

## Step 12 — Target Adapter Fabric

T0GM now has an initial target-adapter layer for Laravel/application administration, databases, Linux/server management, browser extension/PWA runtime, cloud APIs and AI-worker control. Adapters are translators below the authority boundary: they consume an already-valid purpose/effect/target/company-bound Sovereign Capability and prepare the narrowest target-native operation. They cannot mint authority, widen `company_id`, accept generic admin/root semantics, or promote protocol credentials into sovereign authority. Windows, Kubernetes, SaaS, OT/ICS, IoT and robotics remain future adapters behind the same contract.
