# Step 10 — Compromised-Device Isolation

A compromised T0GM device is quarantined as a device-specific state change. Quarantine does **not** revoke or recreate the sovereign T0GM principal, and it does not affect healthy sibling devices.

## Invariants

- Current identity proof from a quarantined device fails closed.
- The same isolation state is available to the Authority Continuance Engine as `device_quarantined`, so authority originating from that device must terminate and be freshly established from a healthy trusted device.
- Pre-quarantine evidence remains historically verifiable; post-quarantine evidence from the isolated device is rejected.
- Quarantine preserves binding ID, reason, incident/evidence reference and provenance for investigation.
- Quarantine never creates `company_id`, tenant, application-role, capability or execution authority.
- Quarantining one device does not quarantine sibling devices and does not destroy the T0GM sovereign identity.

The design deliberately separates **identity membership**, **device trust**, and **dynamic isolation**. A device can remain an historical member of the sovereign identity while being forbidden from current use.
