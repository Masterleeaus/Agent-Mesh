# T0GM Step 12 — Server & Workload Identity

Step 12 gives servers, services, containers and workloads independently attestable identities rather than inheriting trust from IP address, hostname, subnet, cluster membership or network location.

The verification chain is:

`registered workload binding → workload self-signature → independent attestor signature → measurement binding → replay protection → identity evidence`

A workload identity contains a stable workload identifier, workload class, cryptographic public key, measurement, nonce and evidence window. Network information may be included only as an observation and is explicitly marked non-authoritative.

The workload registry rejects `company_id`, tenant aliases, role, permission, capability and authority fields. Successful workload verification therefore proves which workload is speaking and what measured state was attested; it does **not** grant T0GM authority, company authority, permission or execution capability.

Container/workload identities can additionally bind an expected measurement such as an image or workload digest. A copied IP/hostname with a different key cannot impersonate the workload, and replayed identity evidence fails closed.
