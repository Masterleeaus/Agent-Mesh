# T0GM God Mode Supersession

T0GM may intervene in a live decision chain without prior escalation. Supersession creates a new immutable `supersession` event and preserves the superseded decision, its evidence and historical effects.

Causal dependency discovery follows only forward `causes` and `parent_of` edges. Correlation is not treated as dependency. Each discovered downstream event receives one consequence classification:

- `stop` — live execution must cease.
- `reverse` — completed dependent effect is materially reversible.
- `recompute` — downstream decision/state must be recalculated under the new sovereign determination.
- `remain_intact` — truth-bearing observations/evidence or effects with no safe inferred mutation remain historical facts.

Delegated oversight AI cannot create sovereign supersession. T0GM can supersede decisions, not truth.
