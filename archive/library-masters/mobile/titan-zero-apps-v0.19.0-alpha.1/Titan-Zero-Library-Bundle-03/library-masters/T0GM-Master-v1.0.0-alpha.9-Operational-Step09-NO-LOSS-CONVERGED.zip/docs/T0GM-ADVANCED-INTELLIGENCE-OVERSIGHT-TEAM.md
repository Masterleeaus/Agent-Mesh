# T0GM Advanced Intelligence Oversight Team — Step 05

## Canonical role
The T0GM oversight team independently reviews governed activity already represented by the canonical T0GM event contract. It is an oversight intelligence layer, not an authority provider and not a replacement for Titan Signal, Risk, Governance, Shield, Assurance, Autonomy, Rewind or domain owners.

## Nine independent specialists
- Security — identity, credentials, access, cyber and control integrity.
- Governance — authority basis, policy, scope and constitutional compliance.
- Financial — financial exposure, loss, ledger/revenue/payment implications.
- Operational — continuity, dependencies, service/process disruption and recoverability.
- Privacy/Legal — privacy, consent, jurisdiction, legal and regulated-data concerns.
- Environmental — environmental/resource impact, water, energy, waste, emissions and ecological consequence.
- Physical Safety — human/animal/physical-system safety and unsafe-state risk.
- Anomaly — unusual patterns, confidence gaps, provenance and adversarial indicators.
- Causal — causation, downstream dependency, propagation, irreversibility and supersession consequences.

## Constitutional properties
1. Each specialist emits its own assessment. No specialist can edit another specialist's opinion.
2. Disagreement is explicit data. It is never collapsed into a consensus or averaged score.
3. `consensus_score` is deliberately null in the canonical review-set projection.
4. A material objection remains visible even if all other specialists clear the event.
5. The team does not inherit Titan 0 God Mode sovereign authority. `sovereign_authority_inherited` is always false.
6. Oversight recommendations are recommendations unless a separate explicitly delegated capability authorizes an action.
7. T0GM may supersede an oversight determination just as it may supersede other Advanced Intelligence determinations; history and evidence remain immutable.
8. Low confidence is surfaced as uncertainty and can increase investigative attention; it does not make dangerous activity safe.
9. Specialist evidence references point back to immutable event evidence and provenance.

## Initial implementation
Step 05 ships deterministic reference reviewers so the contract is executable and testable without binding Titan to one model/provider. These reviewers are replaceable behind `T0gmOversightReviewer`; future model-backed specialists must preserve the same independent assessment contract and authority boundary.
