# Step 8 — Advanced Intelligence Workforce Capability Manifest

Each Advanced Intelligence worker now has a declarative capability manifest split into five independent classes: observe, reason, recommend, request and execute.

The manifest is bound to the canonical worker registry record by `company_id`, worker id and registry integrity digest. Revisions must increase monotonically and a worker cannot issue its own replacement manifest.

An `execute` declaration is not execution authority. It means only that the worker may be considered for that effect after the existing governed execution chain evaluates capability, permission, entitlement, autonomy, risk, cost, privacy, safety and current world state.

The manifest cannot grant T0GM authority, sovereign authority or self-escalation. Discovery of a method does not create authority to use it.
