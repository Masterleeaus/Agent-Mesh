# T0GM Step 02 — Distributed Nonce & Replay Protection

## Purpose

Replace process-local replay tracking with a durable atomic claim system that prevents a valid T0GM challenge/nonce from being accepted more than once across devices, processes, servers, regions and restarts.

## Security model

`DurableNonceStore` computes an HMAC-SHA-256 digest from the replay domain and nonce. The raw nonce is never persisted by the production store. Namespace/device information is retained only as one-way audit hashes and **does not partition uniqueness**. A nonce consumed on one device or region is therefore consumed everywhere in the same sovereign replay domain.

Production deployments must use an `AtomicNonceBackend` whose claim operation is linearizable. `PdoAtomicNonceBackend` relies on the database PRIMARY KEY/UNIQUE constraint as the atomic concurrency boundary. All accepting regions must point at one logically shared strongly consistent claim store (or an equivalent backend implementing the same contract).

A file-backed backend is supplied only for restart-durable contained/offline single-host operation. It advertises `distributedCapable() = false`; production construction fails closed when distributed capability is required.

## Invariants

- Replay uniqueness is global inside the configured T0GM replay domain, not per device/server/region.
- No read-before-write authorization race is used; the persistence uniqueness constraint decides the winning claimant.
- An already-expired proof can never create a successful nonce claim.
- Backend failure must propagate/fail closed; it must never degrade to in-memory acceptance.
- Production digest pepper is at least 32 bytes and must be identical across all verifier nodes in the replay domain.
- Raw sovereign nonce/challenge values are not stored by `DurableNonceStore`.
- Time remains replay hygiene only; nonce expiry does not create or extend sovereign authority.
- This layer proves freshness/one-time use only. It does not grant T0GM identity, company authority or execution authority.

## Regional deployment rule

Do not deploy independent per-region nonce databases behind active-active verification unless a single linearizable uniqueness mechanism spans them. Availability must not be purchased by permitting replay divergence. If the shared claim boundary is unavailable, sovereign proof verification fails closed.
