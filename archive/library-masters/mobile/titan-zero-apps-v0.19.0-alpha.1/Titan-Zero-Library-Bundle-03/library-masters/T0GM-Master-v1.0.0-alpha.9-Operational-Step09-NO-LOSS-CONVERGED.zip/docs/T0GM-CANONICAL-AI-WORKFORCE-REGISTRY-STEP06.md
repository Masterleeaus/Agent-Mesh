# Step 6 — Canonical Advanced Intelligence Workforce Registry

`Titan\GodMode\Workforce\T0gmCanonicalAiWorkforceRegistry` is the single authoritative catalog for Advanced Intelligence workforce identities.

## Canonical entity kinds
- `worker`
- `specialist`
- `team`
- `model`
- `autonomous_service`

Every registry entry is explicitly scoped by `company_id`. Legacy tenant identifiers are rejected rather than treated as authority boundaries.

The registry owns durable workforce identity/catalog metadata, provenance, relationships and lifecycle state. References between models, workers, specialists, services and teams resolve only inside the same `company_id`.

Existing registries remain narrow supporting sources: workload identity remains cryptographic workload evidence; oversight specialist constants remain a specialist taxonomy; command targets remain discovery projections. None is an alternate Advanced Intelligence workforce authority.

The registry is deliberately authority-neutral. It cannot contain permissions, capabilities, execution authority or sovereign authority, and registration does not authorize execution. Step 8's capability manifest and the governed execution chain remain the places where action authority is evaluated.

Lifecycle states are `registered`, `active`, `restricted`, `quarantined`, `suspended`, and terminal `retired`. Every material transition increments a revision and may retain actor/reason/time provenance.

Core invariants:
- one canonical workforce registry;
- `company_id` is the sole company boundary;
- no cross-company relationship resolution;
- immutable `registry_id` inside a company;
- provenance and integrity digest retained;
- no authority inheritance from T0GM;
- no AI entity can alter its own authority through registry metadata.
