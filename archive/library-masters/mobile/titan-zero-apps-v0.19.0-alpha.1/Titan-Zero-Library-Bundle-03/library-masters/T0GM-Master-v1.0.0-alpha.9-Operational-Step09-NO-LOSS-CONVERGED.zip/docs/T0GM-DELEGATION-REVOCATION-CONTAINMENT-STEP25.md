# T0GM Step 25 — Delegation Revocation & Containment

Step 25 adds immediate revocation and causal containment for bounded delegated execution authority. It is applied to the verified Step 22 cumulative baseline. Steps 17–19, 21, 23 and the Step 24 completion contract are **not asserted complete** by this package.

## Constitutional boundary

Revocation removes delegated authority; it does not erase historical truth. A recipient never inherits T0GM sovereignty, may not re-delegate, and may not expand its authority. `company_id` remains the sole canonical company boundary.

## Revocation semantics

A revocation atomically changes a known delegation to `revoked`, empties `retained_effect_ids`, prevents new dependent actions, and emits an evidence-only receipt. Replaying the same `revocation_id` is idempotent; a conflicting second revocation is rejected.

## Causal containment

Known dependents are classified from their actual lifecycle state:

- queued/planned/pending execution → cancel
- running/in-progress execution → stop
- completed reversible effect → reverse
- completed non-reversible effect → recompute downstream state
- dependent decision → recompute
- evidence/observation → preserve

Every disposition requires fresh authority before any new execution. Containment never manufactures replacement authority.

## Step 24 dependency handling

Because the shared Library did not contain a verified Step 24 artifact when Step 25 began, this package includes only the minimum delegated-capability registry needed to make revocation testable and enforceable. That substrate does **not** claim completion of the Step 24 issuance lifecycle, identity proofing, cryptographic delegation signing, distributed issuance, or execution integration.
