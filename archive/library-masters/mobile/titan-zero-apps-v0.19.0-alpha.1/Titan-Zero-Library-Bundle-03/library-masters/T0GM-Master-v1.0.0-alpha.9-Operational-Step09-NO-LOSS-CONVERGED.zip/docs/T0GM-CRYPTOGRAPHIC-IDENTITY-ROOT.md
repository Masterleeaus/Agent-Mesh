# T0GM Cryptographic Identity Root — Step 11

Titan 0 God Mode is a cryptographic authority class, not a Laravel role, database user, permission row, tenant membership, impersonation mode, or ordinary administrator account.

## Proof chain

`T0GM root verifier → root-signed identity proof → hardware-attested device key → purpose-bound request proof → Sovereign Capability → governed execution`

The ordinary application runtime contains **verification material only**. It must not generate or retain T0GM root or device private keys. Test fixtures generate ephemeral keys solely inside the test process.

## Hardware-backed proof

`titan.t0gm.hardware_attestation.v1` binds an independently trusted hardware attestation to:
- the exact T0GM device key identifier;
- a SHA-256 fingerprint of the device public key;
- a fresh challenge;
- hardware class and measured/verified state;
- attestation evidence provenance.

The reference verifier intentionally treats the hardware statement as an adapter contract. Production adapters may map verified platform mechanisms (for example hardware authenticators, TPM-class attestation, secure-enclave-class device proof, or future device roots) into this contract. A software claim that merely says `hardware_backed=true` is insufficient unless signed by an independently configured attestation trust root.

## Crypto agility

Cryptographic algorithms are selected through explicit `signature_suite` identifiers and verifier trust entries. Step 11 implements Ed25519 verification as the current reference suite; unknown suites fail closed. The authority, capability, event, and identity semantics do not depend on Ed25519. Later hybrid/post-quantum or zero-knowledge proof verifiers can be introduced as new suites/adapters without turning those algorithms into new sources of authority.

Cryptographic proof validity windows are replay/verification hygiene. They are **not** the lifetime of sovereign authority. Authority duration remains governed by the Authority Continuance Engine and live justification.

## Application separation invariants

- T0GM identity proof is `non_tenant=true`.
- Identity-root proofs reject `company_id`, legacy tenant identifiers, `role_id`, and `user_id` bindings.
- Company authority belongs in a purpose/target-bound Sovereign Capability, never in the identity root.
- Laravel/database compromise cannot create T0GM by writing a role or permission.
- Advanced Intelligence cannot inherit the T0GM root merely because it operates in the oversight team.
