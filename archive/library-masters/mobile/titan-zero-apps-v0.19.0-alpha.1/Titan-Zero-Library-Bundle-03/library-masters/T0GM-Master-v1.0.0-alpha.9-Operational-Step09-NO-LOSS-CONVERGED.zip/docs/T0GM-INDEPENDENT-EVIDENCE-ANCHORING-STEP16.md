# T0GM Step 16 — Independent Evidence Anchoring

## Objective
Anchor critical sovereign audit checkpoints outside Titan's application/database/audit authority domain so later verification can prove that a specific historical audit state existed and has not been silently rewritten.

## Trust model
Step 16 separates three things that must not collapse into one another:

1. **Titan sovereign audit store** — owns append sequence, audit hash chain, local checkpoint and audit signature.
2. **Independent anchor provider** — receives a cryptographic commitment to a checkpoint and returns a receipt signed under an independently trusted anchor key.
3. **T0GM authority** — remains governed by sovereign identity/capability/continuance rules and is never created by an audit or anchor receipt.

A valid anchor proves that the committed audit state existed in that exact form at or before the anchor receipt. It does not prove that every event before it was truthful, does not authorize an action, and does not constitute T0GM approval.

## Commitment
The external receipt binds:
- audit sequence
- sovereign audit record hash
- digest of the complete local checkpoint
- digest of the local checkpoint signature
- independent provider identity
- independent anchor sequence and previous-anchor hash
- anchor timestamp

This means an attacker who later rewrites Titan's audit log/checkpoint cannot make the rewritten checkpoint match a pre-existing independent receipt without breaking the cryptographic commitment.

## Provider boundary
`IndependentEvidenceAnchorProvider` is the stable provider contract. `FileIndependentEvidenceAnchorProvider` is a reference implementation intended to model an independently administered filesystem/object-store trust domain in tests and contained deployments. Production should place the provider in a genuinely separate administrative/storage domain such as an independent WORM store, transparency/notary service, timestamp authority, external ledger, or equivalent.

Co-locating the Titan audit mutation authority and the external-anchor mutation authority defeats the purpose of Step 16.

## Security properties
- Anchor key trust is independent from the Titan audit signer.
- Provider/key mismatch fails closed.
- Revoked/retired anchor keys fail according to evidence time.
- Local checkpoint mutation after anchoring fails receipt comparison.
- Receipt mutation/signature forgery fails verification.
- Deleting Titan's local app/audit data does not delete the independently retained receipt.
- Identical checkpoint commitments anchor idempotently.
- Anchor receipts explicitly carry non-authority semantics.

## Constitutional invariant
**Independent evidence anchoring strengthens proof of history; it does not create, transfer, expand, or supersede T0GM sovereignty or company/execution authority.**
