# Production God Mode Key Ceremony

The package contains no production private keys.

Recommended production process:

1. Generate the God Mode root signing key outside the tenant application.
2. Prefer an HSM, secure enclave, offline signing station or equivalent isolated control-plane signer.
3. Import only the root public key + key id into the verifier registry.
4. Generate a dedicated control-plane device signing key outside ordinary tenant account flows.
5. Root-sign a device certificate binding that device to the configured God Mode principal.
6. Record the public-key fingerprints and custody evidence.
7. Require explicit revocation and replacement ceremonies.
8. Never recover God Mode by promoting a tenant user.
9. Never expose a “make God Mode” UI or API.
10. Future post-quantum migration should add a versioned verifier/signer suite rather than silently changing this contract.
