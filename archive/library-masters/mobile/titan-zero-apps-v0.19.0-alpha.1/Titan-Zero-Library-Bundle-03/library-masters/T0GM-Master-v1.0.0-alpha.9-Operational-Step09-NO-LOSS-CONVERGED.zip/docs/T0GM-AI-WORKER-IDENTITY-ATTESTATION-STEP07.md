# Step 7 — Advanced Intelligence Worker Identity & Attestation

Each canonical Advanced Intelligence worker can now be projected as a verifiable identity envelope using `T0gmAiWorkerIdentityAttestor`.

The attestation composes four independently meaningful facts:

1. **Canonical workforce identity** — the worker exists in the Step 6 canonical registry under one `company_id`.
2. **Model/provider lineage** — the worker may only attest a model already bound to its canonical registry record. Provider and model reference are resolved from the canonical model entry.
3. **Cryptographic workload identity** — the envelope consumes already-verified workload identity evidence, including workload id/class, key binding and measurement.
4. **Runtime integrity** — the envelope consumes already-verified runtime integrity evidence, including policy revision and code/config/environment digests.

Runtime provenance can retain deployment, instance, region, orchestrator and other non-authority facts. Underlying workload and runtime evidence are retained with SHA-256 evidence digests and the complete worker envelope has a canonical identity digest for tamper detection.

`verify()` rebinds the envelope to the live canonical worker/model registry state and recomputes every evidence digest. A modified model, worker record, workload proof or runtime receipt fails closed.

This layer is identity evidence only. It grants no company, execution, T0GM or sovereign authority. Step 8 remains responsible for the separate AI Workforce Capability Manifest.
