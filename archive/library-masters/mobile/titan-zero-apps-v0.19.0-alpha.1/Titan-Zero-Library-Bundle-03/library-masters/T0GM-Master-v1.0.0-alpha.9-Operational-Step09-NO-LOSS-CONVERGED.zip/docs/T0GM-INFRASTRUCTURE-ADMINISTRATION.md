# T0GM Infrastructure Administration — Step 23

Step 23 connects bounded Sovereign Capabilities to executable infrastructure transports without introducing a second admin authority model.

## Execution chain

`T0GM identity proof → client authority profile → Sovereign Capability → target adapter → registered infrastructure executor → provider receipt → observed state → immutable execution event → Rewind state transition → continuous verification`

The adapter decides only how an already-authorized effect maps to a native transport. The executor is separately registered and cannot mint, widen or transfer authority.

Initial executable transports are Linux/server management, database native protocols, Laravel/application/deployment control planes and cloud provider APIs. Each uses trusted bootstrap configuration or injected provider clients. Raw shell/script input, raw SQL supplied by a request, and embedded cloud credentials remain forbidden.

Every state-changing execution requires an explicit intended state and reversibility description. Titan captures pre-state and post-execution observed state and records both in the existing Rewind transition format, preserving the ability to verify, investigate and safely recover.

`company_id` remains the sole canonical tenant/company boundary. No infrastructure transport accepts legacy tenant boundaries or wildcard company authority.

Windows, Kubernetes, SaaS, OT/IoT and robotics remain future adapters and must use the same Sovereign Capability and execution-manager contracts rather than introducing native super-admin authority.
