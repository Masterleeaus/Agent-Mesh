# Step 20 — Causal Blast-Radius Analysis

This pass adds causal consequence analysis on top of the newest completed shared-library baseline, Step 16. Steps 17–19 are **not asserted complete by this package**.

## Model

Before action, `T0gmProspectiveCausalGraph` records explicit causal/dependency links and produces an immutable forecast. After action, `T0gmCausalBlastRadiusAnalyzer::observe()` traverses canonical sovereign activity edges to construct an observed consequence graph. `compare()` preserves both and exposes unexpected or missing consequences.

The report aggregates affected `company_id` values, systems, workers, decisions, path depth, and highest risk. Correlation is deliberately excluded from propagation. Causal cycles fail closed.

## Authority boundary

Blast-radius analysis is evidence and decision support. It grants no T0GM, company, permission, entitlement, capability, delegation, or execution authority. Cross-company visibility under sovereign access does not itself authorize cross-company effects.
