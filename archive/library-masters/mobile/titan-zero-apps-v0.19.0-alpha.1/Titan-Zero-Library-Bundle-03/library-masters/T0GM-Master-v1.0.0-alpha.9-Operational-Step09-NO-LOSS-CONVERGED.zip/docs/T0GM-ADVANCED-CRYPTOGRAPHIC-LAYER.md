# T0GM Advanced Cryptographic Layer — Step 25

## Constitutional boundary

Cryptography protects the T0GM authority model; it does not redefine it. The identity root remains non-tenant and carries no `company_id`, Laravel role, database user, permission or execution authority. `company_id`, purpose, target, effects, prohibited effects, evidence, risk and extinction remain governed by the Sovereign Capability Fabric built in earlier steps.

## Hybrid sovereign identity

`titan.t0gm.sovereign_identity_proof.v2` supports a versioned crypto profile. The initial profile `t0gm-hybrid-pqc-v1` requires:

- independent classical Ed25519 signature;
- independent ML-DSA-65 post-quantum signature;
- independently trusted hardware-backed device attestation;
- an opaque zero-knowledge proof verified against a canonical public statement;
- replay-resistant challenge consumption;
- distinct verifier key identities.

A successful proof establishes T0GM cryptographic identity only. It does not grant company or execution authority.

## Zero-knowledge architecture

Titan does not embed a proprietary proving system. `ZeroKnowledgeVerifier` is a provider boundary. A proof envelope names a proof system and supplies an opaque proof plus the exact public statement. Titan canonicalizes the expected public statement and rejects mismatches before invoking the provider.

This permits later use of an audited proving system, hardware/HSM-backed verifier, remote verifier or new proof construction without changing T0GM capability semantics.

The public statement intentionally proves sovereign-secret possession against identity/device context without disclosing the sovereign secret. Company targets and business permissions are deliberately excluded from the identity proof.

## Post-quantum architecture

Step 25 adds actual ML-DSA verification through the runtime OpenSSL provider where available. Titan application code remains verifier-only and does not generate/store sovereign private signing keys.

Crypto policy is separate from authority policy:

- ML-DSA protects sovereign signatures.
- ML-KEM is the preferred post-quantum key-establishment family for future protected channels/envelopes.
- SLH-DSA is supported as a crypto-agility verifier option.
- HQC is recorded only as a selected future backup KEM candidate until it becomes a finalized standard; it is not treated as a production standard by this package.

## Fail-closed properties

- required PQC signature absent -> deny;
- wrong/untrusted key -> deny;
- unknown crypto profile -> deny;
- unregistered ZK proof system -> deny;
- ZK public statement mismatch -> deny;
- ZK verification failure -> deny;
- hardware attestation failure -> deny;
- replayed challenge -> deny;
- role/user/company binding in identity root -> deny.

## Crypto agility

Crypto profile IDs, signature-suite IDs, ZK proof-system IDs and KEM preferences are versioned independently. Migrating algorithms therefore changes cryptographic protection without redefining T0GM identity, Sovereign Capability, continuance, supersession, Rewind or client/jurisdiction policy semantics.

## Non-goals

Step 25 does not claim that every deployment already has production HSMs or a production ZK proving backend. Those are provider/deployment concerns. The core enforces the contracts required to introduce them without weakening the authority model or silently falling back to an unverified proof.
