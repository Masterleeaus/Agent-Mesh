# T0GM Step 03 — Cryptographic Event Signing & Provenance

Step 03 adds cryptographic provenance to canonical T0GM events without conflating signatures with authorization.

## Invariants

- Event signatures attest origin and integrity only. They do **not** grant execution authority and do **not** mean T0GM approved an AI decision.
- The signed statement binds `event_id`, event kind, canonical event hash, company scope, `company_id`, causal lineage hash and evidence-reference hash.
- The canonical event hash excludes the provenance envelope, preventing circular hashing; changing event content changes the canonical hash and invalidates the signature.
- Recomputing a SHA-256 event hash after tampering is insufficient: the attacker must also produce a valid signature from a trusted provenance key.
- Verification keys come from a deployment-managed trust store. Public keys embedded in an event are never accepted as trust roots.
- Production ingestion can require provenance and one or more cryptographic suites. Legacy/contained flows remain compatible unless that fail-closed mode is enabled.
- Hardware custody purpose `event_provenance` is distinct from `sovereign_identity` and from execution authority.

## Fabric

`event → canonical hash → lineage/evidence binding statement → hardware-backed signature → provenance envelope → trust-store verification → append-only feed`

The existing append-only record-hash chain remains complementary evidence. The event signature protects against a compromised store recomputing hashes after fabricating event content or lineage.
