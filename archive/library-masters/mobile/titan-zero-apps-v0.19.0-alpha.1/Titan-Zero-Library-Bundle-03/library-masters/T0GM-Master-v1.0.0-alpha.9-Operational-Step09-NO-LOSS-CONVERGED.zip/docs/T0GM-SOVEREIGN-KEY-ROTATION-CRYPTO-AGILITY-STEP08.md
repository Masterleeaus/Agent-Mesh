# T0GM Step 08 — Sovereign Key Rotation & Crypto Agility

Step 08 separates cryptographic lifecycle from authority semantics. Signing keys and verification profiles may rotate without turning cryptography into permission or changing the T0GM authority model.

## Key lifecycle

Trust records support bounded `trusted_from`, `retired_at`, and `revoked_at` evidence times. Retirement stops a key being trusted for evidence created after retirement while preserving verification for evidence created during the key's trusted interval. Revocation fails verification from the revocation boundary onward while keeping pre-revocation historical evidence inspectable.

## Profile agility

`T0gmCryptoAgilityRegistry` selects one active issuance profile and permits older profiles to remain `verify-only`. Disabled profiles fail closed. This lets algorithms, proof systems, key material and providers evolve without invalidating historical records merely because a newer profile is active.

## Constitutional invariant

A key, algorithm, proof system or provider change proves cryptographic facts only. It cannot create `company_id` authority, application-role authority, a Sovereign Capability, or execution permission. T0GM authority semantics remain outside the crypto lifecycle.
