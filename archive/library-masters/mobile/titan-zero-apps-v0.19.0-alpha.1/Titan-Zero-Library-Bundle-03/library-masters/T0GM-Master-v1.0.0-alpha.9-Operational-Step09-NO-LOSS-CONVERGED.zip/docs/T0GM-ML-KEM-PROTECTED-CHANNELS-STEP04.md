# T0GM Step 04 — ML-KEM Protected Channels

Step 04 adds post-quantum key establishment for sensitive T0GM control-plane communications using ML-KEM behind a provider boundary.

## Invariants

- ML-KEM establishes channel secret material; it does **not** authenticate sovereign authority or grant execution authority.
- The current `t0gm-hybrid-pqc-v1` profile permits `ml-kem-768` and forbids classical-only downgrade.
- Channel transcripts bind channel ID, crypto profile, KEM algorithm, endpoints and purpose.
- `company_id` and legacy tenant identifiers are forbidden from the cryptographic channel transcript so transport cryptography cannot create company authority.
- Receiver private KEM material is passed to the OpenSSL adapter by reference; Titan does not parse private KEM key bytes.
- Production deployments should place the referenced KEM key behind HSM, OS key broker, or equivalent non-exportable custody.
- Step 05 is responsible for deriving/using session protection from the established secret; Step 04 does not invent an application encryption protocol.

## OpenSSL adapter

OpenSSL 3.5+ `pkeyutl -encap/-decap` is used for the reference adapter. Unsupported suites and provider failures fail closed.
