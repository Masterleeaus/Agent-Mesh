# T0GM Sovereign Capability Contract — Step 06

## Canonical change

Titan no longer treats **admin access** as the constitutional unit of T0GM authority. The canonical unit is a **Sovereign Capability**: a cryptographically integrity-bound statement of the smallest effects that T0GM may legitimately cause for one purpose, one target context and exactly one `company_id`.

An adapter may internally use an administrator API, database role, SSH certificate, cloud role or other native mechanism. Those are transport/execution details. They do not define Titan authority.

## Mandatory bindings

Every capability names:

- sovereign human authority holder (`titan.god_mode`);
- explicit authority basis;
- exactly one `company_id` — no wildcard company grant;
- purpose and intended outcome;
- exact target system/environment/resource context;
- enumerated permitted effects;
- explicit prohibited effects;
- evidence and integrity references;
- risk ceilings;
- extinction conditions;
- immutable integrity digest.

Cross-company work requires separately attributable capabilities per company. It must not be represented as `company_id=*`.

## No time-derived authority

`created_at` is evidence. The canonical contract deliberately rejects `expires_at`, TTL and `valid_for_seconds` as authority-duration semantics. A transport credential may expire for replay/operational safety, but the sovereign capability persists only while its justification remains true. Step 07 evaluates that continuance in live state.

## Effects, not roles

Permitted effects are explicit operations such as:

- `customer.restore_verified_snapshot`
- `workload.pause`
- `deployment.stop`
- `database.read_recovery_scope`

The contract rejects unbounded operations such as `*`, `all`, `admin`, `root` and `super_admin`.

## Prohibited effects

Every capability must state effects it does **not** authorize. This prevents a capability from becoming a vague permission bucket and gives adapters a fail-closed boundary.

## Risk constraints

The capability carries maximum accepted contextual risk, financial exposure, physical impact and environmental impact. Evaluation cannot convert an authority grant into proof of safety: a request outside those constraints is denied and must be reassessed/re-authorized rather than silently stretched.

## Extinction conditions

The contract must include at least these constitutional extinction conditions:

- purpose invalid;
- authority revoked;
- company changed;
- target changed;
- risk constraint breached;
- safety interlock;
- superseded;
- direct T0GM extinguish.

Additional conditions include evidence invalidation, execution completion, execution-path deviation and anomaly detection.

## Evaluation contract

`SovereignCapabilityEvaluator` verifies:

1. schema and constitutional structure;
2. capability integrity digest;
3. exact `company_id` match;
4. exact target match;
5. requested effect is explicitly permitted and not prohibited;
6. resource scope is permitted;
7. risk evidence exists and stays within ceilings;
8. required evidence references are present;
9. no declared extinction condition is currently triggered.

The evaluator produces an explainable allow/deny decision. It never executes the underlying mutation.

## Relationship to the T0GM event/feed system

Capability use must be emitted through the canonical T0GM event contract as an `authority_use` event and retain the `capability_id` in authority provenance. The Sovereign Activity Feed observes the capability; it does not mint it. T0GM oversight AI may inspect, challenge or recommend constraining a capability but cannot inherit sovereign authority or self-create one.

## Constitutional invariants

1. `company_id` is the sole canonical company boundary.
2. T0GM sovereign authority cannot be derived from tenant/app roles.
3. Advanced Intelligence cannot manufacture, expand or persist its own authority.
4. Discovery of a method does not grant execution authority.
5. A capability is purpose-, target-, effect- and evidence-bound.
6. Prohibited effects remain prohibited even when adjacent effects are permitted.
7. A capability does not prove an operation is safe; risk/safety remain separate dimensions.
8. Time is evidence, not authority.
9. Cross-company reach is explicit and attributable, never wildcard.
10. T0GM may supersede decisions, but neither capability nor supersession may rewrite historical evidence or truth.
