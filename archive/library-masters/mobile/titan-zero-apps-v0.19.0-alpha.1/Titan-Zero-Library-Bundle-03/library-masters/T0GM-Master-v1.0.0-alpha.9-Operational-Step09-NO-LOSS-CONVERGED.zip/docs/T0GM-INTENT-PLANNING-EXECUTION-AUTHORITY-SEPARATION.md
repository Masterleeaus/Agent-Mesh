# T0GM Intent, Planning and Execution Authority Separation — Step 10

## Constitutional invariant

Discovery, reasoning, recommendation, confidence, planning and decision are not execution authority.

Titan separates three stages:

1. **Intent authority** — permission to formulate or accept a purpose/request.
2. **Planning authority** — permission to analyze, simulate and propose a way to satisfy that intent.
3. **Execution authority** — a separately validated capability that may cause the specified real-world/system effect.

An Advanced Intelligence worker may generate intent or planning artifacts when otherwise permitted. Neither artifact is a credential and neither can be presented to the execution gate as authority.

## Causal binding

A planning artifact references the exact `intent_id` it answers. An execution request must match the same `company_id`, target and requested operation and must show that the operation exists in the plan. The execution authorization is then evaluated independently.

For the current T0GM sovereign control plane, execution authority is a valid `titan.t0gm.sovereign-capability.v1` held by the human T0GM identity. Advanced Intelligence cannot inherit or impersonate that capability merely because it generated the intent, plan, recommendation or decision.

## Fail-closed rules

- `company_id` is the only canonical company boundary.
- intent/planning artifacts reject legacy tenant-boundary fields recursively.
- `intent`, `plan`, `recommendation`, `decision`, `discovery`, `analysis`, `reasoning`, `proposal`, confidence or score objects are rejected as execution authority types.
- execution actor must be the sovereign capability holder for sovereign execution.
- the requested effect must independently pass the Sovereign Capability evaluator, including target, resource, risk, evidence and extinction checks.
- an operation absent from the originating intent or plan is denied even if a nearby capability exists.
- artifact tampering invalidates causal proof.

## Why this matters

This prevents the dangerous collapse:

`I found a method → I think it is best → therefore I may execute it.`

Titan requires instead:

`intent → plan → independent execution authority → governed effect`.

A future delegated-execution capability can be added as a separate authority type, but must preserve this separation and may never be self-issued, self-expanded or inferred from reasoning quality.
