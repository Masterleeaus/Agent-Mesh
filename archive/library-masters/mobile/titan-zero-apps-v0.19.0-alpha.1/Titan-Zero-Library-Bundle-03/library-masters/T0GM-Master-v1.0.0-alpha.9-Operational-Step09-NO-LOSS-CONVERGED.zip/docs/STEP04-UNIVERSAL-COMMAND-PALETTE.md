# Step 4 — Universal Command Palette
Adds sovereign search and inspection across companies, systems, agents, workflows and infrastructure, plus governed command-intent issuance. `company_id` is the sole company boundary. Inspection is projection-only. Palette issuance never grants execution authority; execution remains subject to the existing governed execution chain.
