# T0GM Hybrid Classical/PQC Sessions — Step 05

Sensitive T0GM control-plane sessions require **both** X25519 classical ECDH and ML-KEM-768 post-quantum KEM material. The two independent shared secrets are transcript-bound and combined with HKDF-SHA-256. Neither component may be silently omitted, substituted, or downgraded.

## Invariants

- Production negotiation is fail-closed.
- X25519 and ML-KEM-768 are both mandatory for the current `t0gm-hybrid-pqc-v1` profile.
- Classical-only and PQ-only degraded modes are forbidden.
- Negotiated algorithms, endpoints, purpose, session ID and combiner are bound into a canonical transcript.
- A negotiation hash is bound into the transcript and HKDF salt so algorithm substitution changes the derived session key.
- Session cryptography provides confidentiality/key material only. It does not authenticate sovereign authority, grant a capability, select a company, or authorize an action.
- `company_id`, tenant aliases and authority/capability identifiers are forbidden from the cryptographic session transcript.
- The ML-KEM receiver private key remains an opaque reference suitable for HSM/OS-brokered custody.
- Ephemeral X25519 private material is scoped to session establishment and must be destroyed by the host after finalization.

## Downgrade handling

Negotiation aborts when either mandatory component is missing or substituted, including ML-KEM-512/1024 in place of the profile-selected ML-KEM-768, a classical KEX other than X25519, or an offer that advertises classical-only/PQ-only fallback.
