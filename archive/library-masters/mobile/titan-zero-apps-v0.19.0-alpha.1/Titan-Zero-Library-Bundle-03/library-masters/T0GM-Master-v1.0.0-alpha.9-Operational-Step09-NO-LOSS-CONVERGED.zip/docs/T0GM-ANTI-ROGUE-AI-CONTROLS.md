# T0GM Independent Anti-Rogue-AI Controls — Step 15

This control plane is independent of operational Advanced Intelligence. An AI worker may propose or plan, but may never increase, reproduce, persist, transfer or hide its own authority; self-certification is forbidden.

## Protected attack classes

- self-escalation and hidden delegation
- persistence or transfer of authority outside its governed capability
- forged or tampered evidence
- Sovereign Activity Feed suppression
- immutable audit deletion/tampering
- oversight evasion
- multi-worker collusion
- compromised oversight specialists
- attempts to disable T0GM identity, Rewind, sovereign feed or recovery

## Constitutional behavior

Failures are fail-closed and produce containment/recovery requirements. Compromised oversight agents are removed from the eligible independent review set without deleting prior assessments. The operational actor cannot be its own final reviewer. God Mode recovery is non-disableable by AI. `company_id` remains the sole canonical company boundary.

The anti-rogue layer does not grant business authority and does not create a second authority model. It guards the existing identity, capability, event, audit, oversight, adapter and recovery boundaries.
