# Step 5 — Sovereign Investigation Workspace

The T0GM investigation workspace is a projection-only composition surface that correlates existing authoritative T0GM records into one investigation context.

It combines seven dimensions: timeline, evidence, causal graph, decisions, identities, capabilities and current state. Each dimension retains its existing source owner; the workspace does not become a replacement audit store, evidence authority, identity provider, decision authority, capability issuer or world-state owner.

`company_id` is the sole canonical company boundary. Legacy tenant identifiers are rejected. The workspace cannot approve, execute, grant authority or mutate source state.

The output includes deterministic timeline ordering, source-ownership metadata and summary counts for verified evidence, causal structure, decisions, identities, active capabilities and current state.
