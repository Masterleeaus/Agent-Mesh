# T0GM Canonical App Runtime — Step 1

This step creates the dedicated T0GM application runtime above the existing sovereign security/control-plane foundation.

The runtime owns application session context, device-state projection, navigation projection and command-intent construction. It does not replace sovereign identity, capabilities, continuance, execution governance, audit, recovery or delegation.

## Invariants

- T0GM is a dedicated app/control plane, separate from Titan Zero owner, Titan Go worker and Titan Hub customer surfaces.
- A T0GM session proves a verified sovereign human session context but does not itself grant company or execution authority.
- `company_id` is the only canonical company boundary in command intents; legacy tenant identifiers fail closed.
- Device trust, integrity and isolation state are evaluated before command submission.
- A quarantined, isolated, revoked or integrity-failed device cannot submit command intents.
- Navigation may project already-held view grants but cannot embed company authority.
- The command surface emits canonical intent envelopes only. Any requested execution must enter the existing governed execution/capability path.
- T0GM sovereignty is never transferred by an app command.
