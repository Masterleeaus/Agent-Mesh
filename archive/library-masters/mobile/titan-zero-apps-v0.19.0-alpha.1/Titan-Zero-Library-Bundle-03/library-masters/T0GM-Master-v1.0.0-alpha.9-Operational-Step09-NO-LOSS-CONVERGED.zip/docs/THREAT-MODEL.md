# Threat Model

Defended paths:

- Tenant owner creates a new role called God Mode → rejected.
- Platform admin assigns all permissions → still cannot pass cryptographic gate.
- Role inheritance tries to include `titan.god_mode` → rejected.
- Impersonation of the configured user → rejected because cryptographic device proof remains absent.
- Database edit sets `super_admin=true` → irrelevant to the God Mode verifier.
- Session sudo/act-as → explicitly rejected.
- Stolen ordinary admin session → cannot mint root-signed device certificate.
- Replayed signed God Mode request → nonce consumption rejects second use.
- Cross-company action omits company target → rejected.
- Legacy `tenant_id` target → rejected.
- Device certificate copied to another device without its private key → request signature fails.

Residual risks requiring operational controls:

- compromise of the God Mode root private key;
- compromise of an authorised God Mode device private key;
- malicious verifier/public-key registry mutation;
- host compromise below the PHP application;
- weak production nonce-store durability;
- insecure key ceremony or backups.

Those risks should be addressed by HSM/secure-enclave custody, attested deployments, immutable configuration, multi-party recovery and hardened production operations.
