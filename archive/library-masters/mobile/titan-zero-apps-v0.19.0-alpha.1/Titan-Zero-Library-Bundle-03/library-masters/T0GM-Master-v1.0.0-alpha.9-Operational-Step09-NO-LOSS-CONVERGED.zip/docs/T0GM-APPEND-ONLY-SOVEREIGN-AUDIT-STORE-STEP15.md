# T0GM Step 15 — Append-Only Sovereign Audit Store

## Purpose

Move sovereign evidence out of ordinary application/database authority into an independently verifiable append-only storage boundary. Application components may submit evidence, but they do not own audit sequence, prior-record linkage, checkpoint state, or historical rewrite semantics.

## Record model

Every record receives a store-owned monotonic `audit_sequence`, the previous record hash, a canonical evidence digest, a canonical record hash, and an Ed25519 provenance signature. Records explicitly state that they do not grant T0GM, company, permission, or execution authority.

## Tamper evidence

The store verifies the complete sequence and SHA-256 hash chain. Every appended record also creates a separate signed create-only checkpoint file. This means editing a historical record breaks its hash/signature, deleting a middle record creates a sequence/chain gap, and truncating the tail leaves a checkpoint whose head no longer matches the log.

## Compromise boundary

The reference backend is deliberately independent of the application database. Compromise or deletion of an application-side copy does not alter the sovereign audit log. Production deployment should place the audit backend under separate credentials, storage permissions, retention policy, and infrastructure ownership from the application database. Step 16 can add independent external anchoring beyond this storage boundary.

## Constitutional invariant

Audit evidence establishes durable historical evidence. It never creates sovereign authority. An audit signer or storage service cannot become T0GM, assign `company_id` authority, mint a Sovereign Capability, or authorize execution merely because it can append or verify evidence.
