# T0GM Operational App — Step 2 Sovereign Home Feed

Step 2 turns the pre-existing canonical sovereign activity/event fabric into the dedicated T0GM application Home Feed. It does not create a parallel event store and does not create a new authority provider.

The Home Feed projects every governed event visible to the sovereign T0GM authority and ranks attention using five explicit factors: risk, consequence, anomaly, confidence and urgency. `consequence` is accepted as an explicit feed signal and falls back to the existing significance signal for backward compatibility.

The ranker applies non-averaging floors for critical risk, consequence, anomaly and urgency. Low confidence is retained as a factor and also produces a separate confidence-concern/uncertainty signal so uncertainty cannot make material danger disappear from attention.

Live behavior uses the immutable sovereign audit sequence as a cursor. `after_sequence` requests only records appended after the caller's last observed sequence; `next_sequence` advances monotonically with observed governed activity. Ranking and projection do not mutate source events, audit hashes, evidence, lineage, company context or authority state.

Constitutional invariants:
- T0GM Home Feed is sovereign-scoped.
- `company_id` remains the sole canonical company boundary.
- Every projected item retains evidence and lineage references.
- Ranking is explainable and projection-only.
- A feed item never grants execution authority.
- Low confidence cannot suppress material risk, consequence or anomaly.
