# T0GM Sovereign Activity Feed Backbone — Step 3

## Status
Implemented as the runtime backbone layered on the Step 2 canonical `titan.t0gm.event.v1` envelope.

## Ownership
Titan Signal remains the canonical event fabric. This package does not create a competing event authority and does not grant business authority. It validates, persists, indexes, links, filters and verifies T0GM oversight events.

## Pipeline

`producer -> Titan Signal/adapter -> T0gmFeedIngestor -> canonical validation -> event integrity verification/seal -> SovereignActivityStore -> causal/evidence/correlation indexes -> sovereign feed query`

Events that already contain a canonical hash must verify before persistence. Events without an integrity block are sealed during ingestion. Reusing an `event_id` with the same event hash is idempotent; reusing it for different content fails closed.

## Immutable audit lineage
Every accepted event is wrapped in an append-only feed record containing:

- `audit_sequence`
- `event_id`
- canonical `event_hash`
- `previous_record_hash`
- complete canonical event
- `record_hash`

The record hash covers its sequence, predecessor, event hash and event body. `verifyAuditLineage()` walks the complete chain and independently verifies the canonical event hash, making out-of-band mutation detectable. The public store contract exposes no update/delete mutation API.

## Causal relationships
The backbone deterministically derives typed edges from the event envelope:

- `lineage.causation_id -> event_id` as `causes`
- `lineage.parent_event_ids[] -> event_id` as `parent_of`
- supersession event -> each `supersedes_event_ids[]` as `supersedes`

Correlation and trace identifiers remain separate: correlation groups related business/incident activity; trace follows an execution/reasoning path. `T0gmLineageFactory` generates cryptographically random IDs when an adapter does not already possess canonical lineage.

## Evidence references
Each canonical `evidence[]` reference is indexed by `evidence_id` without copying the evidence body into the feed store. The feed retains type, source, optional content hash and provenance reference. Evidence systems remain authoritative for their evidence content.

## Cross-company visibility
`company_id` remains the sole canonical company boundary.

- `titan.god_mode` sovereign access may observe all governed company and platform events.
- A T0GM oversight AI does **not** inherit sovereign reach by being on the T0GM team.
- Non-sovereign readers must have explicit `companyIds[]` grants for company-scoped events.
- Platform events require explicit `platformVisibility` unless the caller is sovereign T0GM.
- Direct ID fetches, queries, evidence lookup, correlation lookup and causal traversal all apply visibility rules.
- Unknown/unresolved causal neighbours are hidden from non-sovereign callers to avoid identifier leakage.

This creates cross-company visibility for T0GM without weakening ordinary company isolation.

## Stores
Two store implementations are supplied:

1. `InMemorySovereignActivityStore` — deterministic reference/test implementation.
2. `PdoSovereignActivityStore` — durable relational adapter using the portable schema in `schemas/t0gm-sovereign-feed-store.sql`.

The durable schema indexes company scope, company ID, event kind, trace, correlation, attention tier, causal edges and evidence references. Production hosts should run the database at an isolation level/append path appropriate for their expected concurrent writer count and add database-native append-only protections where available.

## Query surface
`T0gmFeedQuery` supports bounded reads by:

- event kind
- company IDs
- correlation ID
- trace ID
- evidence ID
- minimum attention tier
- audit sequence cursor
- limit

Step 3 deliberately does not implement the later intelligent view/ranking layer. It provides the correct immutable substrate for it.

## Constitutional invariants preserved

- Events report authority; they do not grant it.
- Risk controls attention, not T0GM sovereign observability.
- T0GM AI oversight access remains delegated and scoped unless explicitly granted otherwise.
- Supersession creates causal lineage; it does not rewrite historical events.
- `company_id` is the only canonical company/tenant boundary.
- Timestamps remain evidence/order metadata and do not mint authority lifetime.
