# Step 13 — Runtime Integrity Attestation

Step 13 separates **workload identity** from **runtime integrity**. Step 12 proves which server, service, container or workload is speaking. Step 13 proves whether that identified workload is currently running a trusted combination of deployed code, configuration and execution environment before a privileged T0GM operation is allowed to rely on it.

## Trusted-state policy

Each workload identity has a versioned runtime-integrity policy containing approved code digests, configuration digests, environment digests and required runtime claims. Policies are deployment-managed evidence; they must not contain `company_id`, tenant aliases, roles, permissions or capabilities and therefore cannot create authority.

A signed runtime attestation binds the policy revision to the Step 12 workload binding ID, code digest, configuration digest, environment digest, runtime claims, freshness nonce and evidence window. Network names and addresses are observation only and never satisfy identity or integrity.

## Privileged execution

When `runtime_integrity_required=true`, `ExecutionAuthorityGate` fails closed unless the execution request carries a verified integrity receipt bound to the same workload identity/binding. A valid receipt is evidence only and cannot replace the sovereign capability.

The Authority Continuance Engine also pauses live capability use when runtime integrity is required but cannot currently be proven. This means a runtime that drifts after initial authorization cannot keep privileged authority merely until an arbitrary credential timeout.

## Failure boundaries

Step 13 rejects unknown or inactive policy revisions, code drift, configuration drift, environment drift, missing required runtime claims, invalid attestor signatures, cross-workload receipt substitution, replayed evidence and authority-bearing integrity claims.

**Invariant:** trusted runtime state is a precondition for privileged execution where required; it is not itself T0GM identity, company authority, permission, capability or approval.
