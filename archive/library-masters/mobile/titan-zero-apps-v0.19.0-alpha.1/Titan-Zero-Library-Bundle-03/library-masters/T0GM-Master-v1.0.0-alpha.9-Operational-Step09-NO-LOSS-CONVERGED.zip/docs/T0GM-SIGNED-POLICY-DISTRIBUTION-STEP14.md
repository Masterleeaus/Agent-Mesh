# Step 14 — Signed Policy Distribution

Step 14 cryptographically protects Titan constitutions, policies, safety/jurisdiction/industry overlays, and configuration against unauthorized modification during distribution.

## Constitutional boundary

A valid policy signature proves **origin and integrity**. It does **not** create Titan 0 God Mode authority, `company_id` authority, a Sovereign Capability, permission, entitlement, autonomy, or execution authority.

A policy artifact becomes eligible to govern only after all relevant independent checks succeed: trusted signer and purpose, evidence-time key validity, content digest, signature, policy class, scope, revision continuity, anti-rollback/equivocation checks, and any higher-order constitutional/policy-resolution rules.

## Signed bundle

`titan.t0gm.signed-policy-bundle.v1` binds:

- policy class: constitution, policy, overlay, or configuration
- stable policy ID
- explicit scope and canonical `company_id` where company-scoped
- monotonic revision and optional superseded revision
- issue/effective evidence times
- canonical content digest
- exact policy content
- non-authority semantics

The surrounding signed envelope binds the signer key ID and Ed25519 signature over canonical JSON.

## Anti-rollback and equivocation

For each policy stream (`policy_class + policy_id + scope`):

- lower revisions than the accepted revision are rejected;
- a different content digest at an already accepted revision is rejected as equivocation;
- exact same-revision/same-digest delivery is idempotent.

Time does not itself create policy authority. Evidence time is used to determine whether the signing key was trusted, retired, or revoked for that historical statement.

## Scope

`company_id` remains the sole canonical company boundary. A cryptographically valid company overlay for one company cannot be relabelled as another company without failing scope validation/signature integrity.

## Historical verification

Signer trust records support trusted-from, retirement, and revocation boundaries. Historical artifacts can remain inspectable when their signature was valid inside the trusted interval; retired/revoked keys cannot silently authorize later distributions.
