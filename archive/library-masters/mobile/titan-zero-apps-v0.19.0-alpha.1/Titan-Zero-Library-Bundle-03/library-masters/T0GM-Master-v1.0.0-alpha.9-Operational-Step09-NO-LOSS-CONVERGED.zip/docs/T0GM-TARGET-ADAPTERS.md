# T0GM Target Adapters — Step 12

Target adapters translate an already-valid Sovereign Capability into the smallest target-native operation. They do not grant authority, infer authority from administrator roles, widen resource scope, or create credentials.

## Initial adapter set

- Laravel/application administration — `laravel_control_plane`
- Databases — `database_native_protocol`
- Linux/server management — `linux_native_management`
- Browser extension/PWA — `titan_browser_bridge`
- Cloud APIs — `cloud_provider_api`
- AI-worker control — `titan_ai_worker_control_plane`

Windows, Kubernetes, SaaS, OT/ICS, IoT, robotics and vehicle adapters are intentionally deferred. They must implement the same `TargetAdapter` contract and consume the same Sovereign Capability model.

## Invariants

1. `company_id` remains the sole canonical company boundary.
2. An adapter only prepares an operation after the existing Sovereign Capability evaluator allows the exact company, target, operation, resource, risk, evidence and extinction state.
3. No adapter accepts wildcard company authority.
4. Database adapters reject raw SQL in sovereign requests; use named, bounded operations.
5. Linux adapters reject arbitrary shell/script execution; use named, bounded operations.
6. Cloud adapters do not accept embedded long-lived provider credentials; credentials are supplied externally by a scoped provider.
7. AI-worker control cannot grant or increase AI authority.
8. Adapter output carries capability/effect/company/target lineage for receipts, audit and Rewind.
9. Transport/protocol is an implementation detail. SSH, SQL, cloud APIs and browser bridges are not sovereign authority primitives.
