# T0GM Step 07 — ZK Statement Minimisation

Step 07 reduces the public statement presented to the production zero-knowledge verifier. The sovereign identity payload and its classical/PQC signatures remain authoritative evidence of identity binding; the ZK statement no longer repeats raw identity, device, or contextual identifiers simply because they are available.

## Minimal statement

`t0gm-hybrid-pqc-zk-min-v3` uses `titan.t0gm.zk.minimal_authorization_statement.v1` with only:

- `claim` — the fact being proven: sovereign secret possession without secret disclosure.
- `authorization_context_digest` — an opaque digest binding authority, principal class/ID, device key ID/hash, audience and crypto profile without revealing those values in the ZK statement.
- `freshness_digest` — an opaque digest of the fresh sovereign challenge rather than the raw challenge value.
- `possession_public_key` — the Ristretto255 verification key required by the current Schnorr proof system.

Raw `principal_id`, `device_key_id`, device public-key hash, audience, challenge, authority class and crypto-profile ID are not disclosed in the proof statement.

## Security boundaries

- Changing a hidden identity/device/context value changes the expected authorization-context digest, so a proof cannot be transplanted to a different identity context merely because the raw fields are absent.
- Changing the fresh challenge changes the freshness digest, preserving replay binding without disclosing the challenge itself in the ZK statement.
- ZK verification remains proof of a cryptographic fact only. It does not grant `company_id`, capability, permission, execution or T0GM authority.
- Historical `t0gm-hybrid-pqc-zk-v2` and earlier profiles remain verifiable under their original statement rules. Step 07 activates the new `t0gm-hybrid-pqc-zk-min-v3` profile rather than silently changing historical semantics.

## Privacy limitation

The current Ristretto255 Schnorr proof requires a stable possession public key to verify the proof. Step 07 therefore minimizes unnecessary disclosure but does **not** claim cryptographic unlinkability between proofs that reuse the same possession public key. A future unlinkable-credential or selective-disclosure proof system can replace this provider behind Titan's existing ZK abstraction without changing T0GM authority semantics.
