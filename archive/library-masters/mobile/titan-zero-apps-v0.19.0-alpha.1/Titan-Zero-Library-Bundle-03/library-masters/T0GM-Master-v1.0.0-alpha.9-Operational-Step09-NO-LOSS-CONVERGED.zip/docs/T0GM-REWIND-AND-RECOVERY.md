# T0GM Rewind and Recovery — Step 09

Rewind is a verified state-transition recovery mechanism, not a generic undo command.

Every registered meaningful transition records `company_id`, source event, purpose, subject, pre-state, intended result, actual observed result, dependencies, evidence, and reversibility semantics. Each state receives a canonical SHA-256 fingerprint and the complete transition is integrity sealed.

## Recovery invariant

A direct reverse is eligible only when the current observed state still matches the recorded actual post-state and all declared dependency states remain satisfied. If current reality has diverged, Titan returns `RECOMPUTE` rather than overwriting newer state.

Recovery dispositions are `reverse`, `compensate`, `recompute`, `blocked`, or `remain_intact`. Irreversible transitions are blocked. Compensating actions are distinct from true reversal.

## God Mode integration

Only sovereign T0GM access may invoke `T0gmRewindService`. Recovery remains bound to the source event's exact `company_id`. A supersession may causally trigger recovery, but supersession itself never proves reversal is safe.

Each invocation creates an immutable T0GM intervention event containing transition lineage, state hashes, dependency checks, selected disposition, reason codes, and any proposed inverse/compensating effect. Historical observations and prior effects remain preserved.

T0GM can supersede decisions; it cannot supersede truth. Rewind therefore refuses a blind rollback when evidence says the world has changed.
