# Step 22 — Live Capability Re-Evaluation

Step 22 applies fresh world-state evidence to every active T0GM Sovereign Capability. It operationalises the constitutional rule that authority persists only while current reality continues to justify it.

## Constitutional model

A capability is not valid merely because it was valid when created. Each evaluation names a fresh `world_revision`, observation time and SHA-256 world-state digest, then delegates the actual justification decision to `AuthorityContinuanceEngine`.

Possible outcomes are `continue`, `narrow`, `pause`, `transform`, and `terminate`.

- **continue**: current reality still justifies the existing shape.
- **narrow**: only a strict subset of already permitted effects remains justified.
- **pause**: required proof such as risk, safety, jurisdiction, evidence, attestation or runtime integrity is not currently established.
- **transform**: the required authority shape changed. The reevaluator cannot create that new authority; it emits a transformation request requiring fresh sovereign authorization.
- **terminate**: a foundational condition such as company boundary, purpose, authority basis or target validity no longer holds.

Time is evidence, not the authority source. The capability contract continues to forbid TTL/expiry fields as authority-duration primitives.

## Authority boundary

The reevaluator can reduce or extinguish existing authority. It cannot increase it, transfer it, change `company_id`, grant T0GM authority, or mint a replacement capability. Every re-evaluation record explicitly states those non-authority properties.

## Company isolation

`company_id` remains the only canonical company boundary. Legacy tenant fields are rejected from live world-state evidence. A current-world company mismatch terminates the capability; it never silently retargets authority to another company.

## History

Every evaluation is retained in the active capability registry as evidence with the world-state digest and decision. A terminated capability cannot silently reactivate through later re-evaluation.
