# T0GM Jurisdiction and Industry Safety Overlays — Step 24

Safety overlays are executable constraints layered around the Sovereign Capability Fabric. They do not redefine Titan 0 God Mode, mint authority, change the canonical `company_id` boundary, or replace Risk/Assurance/Shield evidence.

## Constitutional rule

`EXECUTABLE = sovereign capability AND client authority profile AND all applicable safety overlays AND target adapter constraints AND live continuance`

An overlay can only preserve or reduce executable authority. It may require evidence, human approval, dual control, safety interlocks, data-region rules, impact ceilings, or prohibit an operation/action class. It can never add an effect, target, company or risk allowance that the underlying capability did not already possess.

## Built-in industry reference overlays

- Healthcare: constrains clinical/health-data actions, requires human approval for sensitive mutations, and places a physical-impact ceiling.
- Finance: requires explicit human approval and dual control for high-consequence money movement, with a financial-exposure ceiling.
- Manufacturing: requires verified safety interlocks/equipment state for physical or safety-critical control.
- Environmental operations: requires environmental-state evidence/control for discharge, emission, waste-release and environmental override effects.
- Other verticals: use the same `titan.t0gm.safety-overlay.v1` contract through custom overlays.

These are reference technical safety constraints, not assertions that one static rule set fully represents law or regulation in a jurisdiction.

## Jurisdiction overlays

Jurisdiction overlays are machine-readable policy inputs populated from current legal/regulatory authority. They can define evidence requirements, permitted data regions, prohibited operations/action classes, approval requirements and risk/impact ceilings without changing the T0GM constitutional core.

## Independence and disagreements

Multiple overlays are evaluated independently and combined restrictively. A permissive overlay cannot cancel a prohibition or missing control from another applicable overlay. Reasons remain explicit rather than collapsed into an averaged score.
