<?php

return [
    'assurance' => [
        'policy_version' => 'titan-assurance-v2.1',
        'analytics' => [
            'max_records' => 1000,
        ],
        'default_expiry_minutes' => 1440,
        'retention_days' => 365,
        'selection_rate_limit' => 30,
        'queue' => env('TITAN_ASSURANCE_QUEUE', 'assurance'),
        'api_prefix' => env('TITAN_ASSURANCE_API_PREFIX', 'api/titan/assurance'),
        'api_middleware' => ['web', 'auth', 'throttle:60,1'],
        'retry_backoff_seconds' => [10, 30, 90],
        'redacted_keys' => [
            'api_key',
            'apikey',
            'authorization',
            'password',
            'secret',
            'token',
            'access_token',
            'refresh_token',
        ],
        'providers' => [
            'timeout_seconds' => 90,
            'connect_timeout_seconds' => 20,
            'max_output_tokens' => 2048,
        ],
        'compliance_sources' => [
            // Host integrations register source adapters under the
            // titan.assurance.compliance_rule_sources tag. Signature policy is
            // configured per source key rather than accepted from callers.
        ],
        'intelligence' => [
            'recent_window' => 50,
            'minimum_cohort' => 5,
        ],
        'integration' => [
            'autonomy' => [
                'enabled' => true,
                // Prevent a previously GREEN assessment from being treated as
                // indefinitely current by Titan Autonomy.
                'max_assessment_age_minutes' => 60,
            ],
            'signal' => [
                'enabled' => true,
                'emitter_service_id' => 'titan-assurance:runtime',
                'registry_service_id' => 'titan-assurance:registry',
            ],
        ],
        'evidence_core' => [
            'green_threshold' => 80,
            'amber_threshold' => 60,
            'stale_threshold' => 0.40,
            'calibration_window' => 200,
            'minimum_green_calibration_samples' => 5,
            'green_rejection_threshold' => 0.30,
            'minimum_calibration_factor' => 0.50,
        ],
        'pricing' => [
            'version' => 'host-configured-v1',
            'currency' => 'USD',
            // Prices intentionally ship empty. Unknown pricing must remain explicit
            // rather than relying on stale provider prices embedded in the extension.
            'models' => [],
            'provider_defaults' => [],
        ],
        'vertical_rule_packs' => [
            'field_home_services' => 'field_home_services.v1',
            'ecommerce' => 'ecommerce.v1',
            'property_hospitality' => 'property_hospitality.v1',
            'fitness_wellness' => 'fitness_wellness.v1',
            'salon_beauty' => 'salon_beauty.v1',
            'automotive' => 'automotive.v1',
            'facilities' => 'facilities.v1',
            'booking_hire' => 'booking_hire.v1',
        ],
        // Legacy v1 compatibility fallback only. Canonical v2 risk comes from Titan Risk Engine context.
        'risk' => [
            'amber_financial_threshold' => 1000,
            'red_financial_threshold' => 10000,
            'critical_financial_threshold' => 50000,
        ],
        'scoring_weights' => [
            'agreement' => 0.15,
            'independence' => 0.20,
            'evidence' => 0.30,
            'deterministic' => 0.20,
            'challenge' => 0.15,
        ],
        'modes' => [
            'standard' => [
                'minimum_candidates' => 2,
                'minimum_model_families' => 1,
                'minimum_providers' => 1,
                'human_approval_required' => false,
                'adversarial_challenge_required' => false,
                'minimum_score' => 70,
            ],
            'high' => [
                'minimum_candidates' => 3,
                'minimum_model_families' => 2,
                'minimum_providers' => 1,
                'human_approval_required' => true,
                'adversarial_challenge_required' => true,
                'minimum_score' => 80,
            ],
            'critical' => [
                'minimum_candidates' => 3,
                'minimum_model_families' => 2,
                'minimum_providers' => 2,
                'cross_provider_preferred' => true,
                'human_approval_required' => true,
                'named_approver_required' => true,
                'automatic_external_execution' => false,
                'adversarial_challenge_required' => true,
                'minimum_score' => 85,
            ],
        ],
    ],
];
