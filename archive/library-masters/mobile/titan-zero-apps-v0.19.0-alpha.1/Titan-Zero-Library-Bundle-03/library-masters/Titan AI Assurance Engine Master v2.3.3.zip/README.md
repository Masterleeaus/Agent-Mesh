# Titan Assurance Engine

**Technical extension identity:** `ModelCouncil`  
**Version:** 2.3.0  
**Canonical role:** Evidence-backed decision assurance for Titan Zero.

Titan Assurance Engine v2 answers:

> **How strongly does the available evidence justify this proposed decision or action?**

It does not own operational risk, autonomous authority, multi-model deliberation, authoritative CRM mutation, or current regulatory knowledge.

- **Titan Risk Engine** owns danger/exposure.
- **Titan Autonomy Engine** owns independent execution authority.
- **Titan Model Council** owns selective multi-model deliberation.
- **Titan Command Bus + domain owner** own governed mutations.
- **Titan Knowledge Authority** owns current/versioned knowledge.

The extension keeps the `ModelCouncil` folder, namespace, provider, registration key, legacy tables/routes and AIChatPro compatibility paths so existing installations can upgrade in place.


## v2.3.0 — Live Titan Signal Integration

- Live receiver adapter certified against **Titan Signal Engine v0.20.0-rc.3**.
- Registers least-privilege emitter `titan-assurance:runtime` and registry actor `titan-assurance:registry`.
- Owns only the `assurance.*` Signal event family.
- Registers and emits `assurance.assessment.completed`, `assurance.evidence.recollection.requested`, `assurance.feedback.recorded`, and `assurance.miscalibration.detected`.
- Every emission uses tenant-scoped Signal context and a stable idempotency key.
- Signal receipts/failures are persisted into Assurance assessment or feedback metadata rather than being reported as success implicitly.
- Titan Knowledge Authority v0.2.0-alpha.1 and Titan Wisdom v0.1.2 remain receiver-limited; this release does not claim query/outcome ingestion methods they do not expose.

See `docs/LIVE-INTEGRATION-V2.3.md`.

## v2.2.0 — Blueprint v4.2 Governed-Engine Rebase

Adds canonical `titan-extension-v1` Installer 1.7.8 packaging, Manifest v2.2 governance/ownership/capability contracts, production schemas/docs, bounded query guards, and flat-root packaging while preserving the `ModelCouncil` technical namespace/folder for upgrade compatibility. The evidence scoring policy remains `titan-assurance-v2.1` because this rebase does not change scoring semantics.

## v2.1.0 — Live Governed Integration Alignment

This pass connects the evidence-native Assurance core to the current Titan Autonomy v1.10 bridge contracts without restoring legacy ownership boundaries. It adds workflow-key precision, bounded assessment age for autonomy consumption, explicit cross-engine integration status, and keeps unsupported scaffold receivers fail-explicit rather than pretending writes succeeded.

Key rule: a projected `decision=approved` is only the compatibility signal consumed by Titan Autonomy. `authority_granted` is always `false`; Titan Autonomy remains the sole owner of execution authority.

## v2.0.0 — Evidence-Native Assurance Core

v2 adds a new canonical Assurance path beside the preserved v1.x compatibility shell:

- canonical `assurance_assessments` persistence using `company_id`
- structured `assurance_evidence_records`
- downstream `assurance_feedback` for calibration
- multiplicative evidence weighting:
  - authority
  - relevance
  - freshness
  - applicability
  - provenance confidence
  - contradiction adjustment
- GREEN / AMBER / RED result contract
- evidence used, missing, stale and contradictory evidence reporting
- exact Knowledge Authority guide/version/hash/section references
- trace, correlation and causation IDs
- Interaction Engine evidence-recollection request boundary
- calibration against downstream manager/team/Shield/CRM/customer/Wisdom outcomes
- miscalibration detection that lowers future cohort calibration without self-modifying policy
- optional integration sinks for Signal, Rewind, Autonomy, AI Core and Wisdom
- capability declarations in `titan-capabilities.json`

The canonical v2 path contains **no** `RiskClassificationService`, `PermissionGateService`, panel selection or provider execution.

## Canonical v2 service contract

Resolve:

`App\Extensions\TitanAssurance\System\Contracts\EvidenceAssuranceEngine`

```php
$assessment = $engine->assess([
    'idempotency_key' => 'job-123-completion-v1',
    'subject' => ['type' => 'job', 'id' => 'JOB-123'],
    'decision_type' => 'job.complete',
    'capability' => 'job.complete',
    'vertical' => 'field_home_services',
    'jurisdiction' => 'AU-VIC',
    'requirements' => [
        ['key' => 'completion_photo', 'evidence_type' => 'completion_photo'],
    ],
    'evidence' => [
        [
            'evidence_type' => 'completion_photo',
            'subject' => ['type' => 'job', 'id' => 'JOB-123'],
            'source' => 'titan_vision',
            'authority' => 0.8,
            'relevance' => 1.0,
            'freshness' => 1.0,
            'applicability' => 1.0,
            'provenance_confidence' => 0.95,
            'verification_state' => 'verified',
        ],
    ],
]);
```

The assessment returns evidence strength only. A GREEN result is not permission to execute and is not a Risk decision.

## Canonical v2 HTTP routes

Default prefix: `api/titan/assurance`

- `POST /assessments`
- `GET /assessments/{assessmentId}`
- `POST /assessments/{assessmentId}/feedback`

See `docs/EVIDENCE-CONTRACT-V2.md`.

## Evidence Registry

Each normalized evidence record includes:

- evidence ID/type
- subject/source
- provenance
- capture/effective/expiry times
- freshness/confidence/authority
- jurisdiction/vertical/scope
- hash
- verification state
- optional contradiction references
- optional exact Knowledge Authority reference

Evidence hashes are generated canonically when not supplied.

## Calibration

Supported feedback types:

- `manager_decision`
- `receiving_team_decision`
- `titan_shield`
- `crm_outcome`
- `customer_outcome`
- `titan_wisdom`

Repeated downstream rejection of GREEN assessments reduces the calibration factor applied to future assessments for the same tenant/decision/vertical cohort. This is a deterministic calibration adjustment, **not automatic policy mutation**.

## Integration sinks

Host engines may register `AssuranceIntegrationSink` implementations under:

`titan.assurance.integration_sinks`

Expected destination keys include:

- `titan_signal`
- `titan_rewind`
- `titan_autonomy`
- `titan_ai_core`
- `titan_wisdom`

Every integration envelope carries a stable idempotency key. Missing sinks are recorded as unavailable rather than falsely reported as dispatched.

## Evidence recollection

If evidence is missing or stale and the result is not GREEN, the engine issues a structured `assurance.evidence.collect` request through `EvidenceCollectionRequester`. The default implementation emits `AssuranceEvidenceCollectionRequested`, allowing Titan Interaction Engine to bind without creating a hard dependency.

## Legacy v1.x compatibility

The original v1.9 ModelCouncil-based verification path remains available:

- run creation/evidence lock
- provider/candidate execution
- panel independence
- deterministic validation
- challenge passes
- legacy permission gate
- external compliance-rule source support
- outcome intelligence
- AIChatPro streaming compatibility

These are retained for installed-system compatibility. New Titan architecture integrations should use the v2 evidence-native assessment path.

The legacy run API can accept external `risk_context` from Titan Risk. Internal risk classification is marked `legacy_assurance_fallback`.

## Tenant boundary

New v2 persistence uses `company_id`. Tenant identity is resolved internally. The resolver still accepts older `company_id/current_company_id/active_company_id` host attributes for upgrade compatibility.

## Trace/Rewind boundary

Every v2 assessment records:

- `trace_id`
- `correlation_id`
- `causation_id`
- evidence IDs/hashes
- policy version
- structured reason codes

No unrestricted chain-of-thought or hidden scratchpad field is stored.

## Verification included in this source build

- pure PHP regression tests
- static PHP lint
- JSON manifest validation
- architecture-boundary scans
- installer-preserving additive migrations

This package does **not** certify live production migrations, real connected Titan engine sinks, live provider credentials, jurisdiction-specific legal correctness or production queue/RBAC configuration.
