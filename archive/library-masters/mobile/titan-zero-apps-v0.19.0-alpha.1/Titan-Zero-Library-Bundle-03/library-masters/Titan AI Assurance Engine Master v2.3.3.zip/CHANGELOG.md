## Workforce convergence Pass 6
- Pass 6: isolated Assurance install/runtime namespace from Titan Model Council.

# Changelog

## 2.3.0

- Added live Titan Signal Engine v0.20 receiver integration using trusted emitter and registry identities.
- Registers the canonical Assurance Signal event family with least-privilege `assurance.*` ownership.
- Emits and persists receipts for assessment completion, evidence recollection requests, downstream feedback, and miscalibration detection.
- Signal integration is load-order resilient and fails explicitly when receiver contracts or authority configuration are unavailable.
- Knowledge Authority and Wisdom remain receiver-limited; no unsupported write/query integration is claimed.

## 2.2.0
- Rebased Titan Assurance onto Titan Extension Blueprint v4.2 Manifest v2.2 and Installer 1.7.8 contracts.
- Added canonical `titan-assurance` identity while preserving `ModelCouncil` technical compatibility.
- Added production capability/event schemas, ownership/governance boundaries and universal production declarations.
- Bounded Blueprint-detected queries and removed prohibited test eval usage.
- Flat-root installer packaging is now required.

## Workforce Runtime Integration Pass 2 — 2026-08-22
- Added deterministic runtime discovery/provider fingerprint contract.
- Added fail-closed request/decision/response envelopes, idempotency, audit and health semantics.
- Added executable runtime descriptor regression coverage without granting authority on registration.
