<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Intelligence\AssuranceRecommendationService;

$service = new AssuranceRecommendationService();
$result = $service->recommend([
    'policy_mutation' => false,
    'provider_metrics' => [
        'openai' => ['sample_count' => 10, 'candidate_failure_rate' => 0.4, 'outcome_success_rate' => 0.5],
        'anthropic' => ['sample_count' => 10, 'candidate_failure_rate' => 0.1, 'outcome_success_rate' => 0.8],
    ],
    'rule_pack_metrics' => [
        'field-home' => ['sample_count' => 8, 'outcome_success_rate' => 0.5],
    ],
    'mean_evidence_sufficiency' => 0.45,
    'incomplete_cost_accounting_rate' => 0.2,
    'drift' => ['insufficient_data' => false, 'material_disagreement_rate_delta' => 0.25],
]);

expect_same(false, $result['policy_mutation'], 'Recommendations cannot mutate policy.');
expect_true(count($result['recommendations']) >= 4, 'Multiple evidence-backed advisories are surfaced.');
foreach ($result['recommendations'] as $recommendation) {
    expect_same(false, $recommendation['policy_mutation'], 'Every recommendation is advisory only.');
    expect_true(($recommendation['evidence_count'] ?? 0) >= 0, 'Every recommendation carries evidence count.');
}
$codes = array_column($result['recommendations'], 'code');
expect_true(in_array('provider_failure_rate_elevated', $codes, true), 'Provider failure advisory is emitted.');
expect_true(in_array('rule_pack_outcomes_weak', $codes, true), 'Weak rule-pack outcome advisory is emitted.');
expect_true(! array_key_exists('recommended_minimum_score', $result), 'Recommendations cannot silently propose weaker score thresholds.');
