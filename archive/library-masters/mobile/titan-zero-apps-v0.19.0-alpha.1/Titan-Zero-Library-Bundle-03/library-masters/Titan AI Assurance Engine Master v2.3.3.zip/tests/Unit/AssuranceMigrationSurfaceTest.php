<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$migration = $root . '/database/migrations/2026_08_09_000012_extend_assurance_accounting_and_policy_metadata.php';
expect_true(is_file($migration), 'v1.8 additive assurance migration must exist.');
$source = is_file($migration) ? (file_get_contents($migration) ?: '') : '';
foreach ([
    'normalized_usage', 'pricing_version', 'effective_cost',
    'rule_pack_key', 'rule_pack_version', 'evidence_source_summary', 'calibration_metadata',
] as $column) {
    expect_true(str_contains($source, $column), "v1.8 migration must add {$column}.");
}
expect_true(str_contains($source, 'Schema::hasColumn'), 'v1.8 migration must be additive/idempotent.');

$runModel = file_get_contents($root . '/System/Models/AssuranceRun.php') ?: '';
expect_true(str_contains($runModel, "'evidence_source_summary' => 'array'"), 'Run model must cast evidence source summary.');
expect_true(str_contains($runModel, "'calibration_metadata' => 'array'"), 'Run model must cast calibration metadata.');

$candidateModel = file_get_contents($root . '/System/Models/AssuranceCandidate.php') ?: '';
expect_true(str_contains($candidateModel, "'normalized_usage' => 'array'"), 'Candidate model must cast normalized usage.');
