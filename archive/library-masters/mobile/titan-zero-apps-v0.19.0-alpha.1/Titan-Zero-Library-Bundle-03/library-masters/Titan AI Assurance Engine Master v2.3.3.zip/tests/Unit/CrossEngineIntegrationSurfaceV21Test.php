<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$provider = file_get_contents($root . '/System/ModelCouncilServiceProvider.php') ?: '';
$engine = file_get_contents($root . '/System/Services/Assurance/EvidenceAssuranceEngineService.php') ?: '';
$manifest = json_decode(file_get_contents($root . '/extension.json') ?: '{}', true);
$capabilities = json_decode(file_get_contents($root . '/titan-capabilities.json') ?: '{}', true);

$autonomyBridge = $root . '/System/Services/Assurance/Integration/TitanAutonomyAssuranceBridge.php';
$tenantBridge = $root . '/System/Services/Assurance/Integration/TitanAutonomyTenantAssuranceBridge.php';
$resolver = $root . '/System/Services/Assurance/Integration/LatestEvidenceAssessmentResolver.php';
$integrationStatus = $root . '/System/Services/Assurance/Integration/CrossEngineIntegrationStatus.php';
$migration = $root . '/database/migrations/2026_08_11_000016_add_assurance_live_integration_surface.php';

foreach ([$autonomyBridge, $tenantBridge, $resolver, $integrationStatus, $migration] as $path) {
    expect_true(is_file($path), 'v2.1 live integration file missing: ' . basename($path));
}
expect_true(str_contains($provider, 'AssuranceBridgeContract'), 'Provider must optionally bind Titan Autonomy AssuranceBridgeContract.');
expect_true(str_contains($provider, 'TenantAssuranceBridgeContract'), 'Provider must optionally bind Titan Autonomy TenantAssuranceBridgeContract.');
expect_true(str_contains($provider, 'model-council.assurance.integration.autonomy.enabled'), 'Autonomy binding must be feature-toggleable and explicit.');
expect_true(str_contains(file_get_contents($migration) ?: '', 'workflow_key'), 'Assessment persistence must add workflow_key for autonomy-key precision.');
expect_true(str_contains($engine, '$assessment->workflow_key'), 'Evidence assessments must persist workflow_key.');
expect_true(str_contains($engine, "'workflow_key' =>"), 'Receipts/snapshots must expose workflow_key.');
expect_same('2.3.0', $manifest['version'] ?? null, 'Extension version must advance to 2.2.0.');
expect_true(isset($capabilities['integrations']), 'Capability manifest must declare integration status/consumption metadata.');
