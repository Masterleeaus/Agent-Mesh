<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\EvidenceWeightingService;

$service = new EvidenceWeightingService();
$result = $service->weight([
    'authority' => 1.0,
    'relevance' => 0.8,
    'freshness' => 0.5,
    'applicability' => 1.0,
    'provenance_confidence' => 0.9,
    'contradiction_adjustment' => 1.0,
]);
expect_near(0.36, $result['value'], 0.000001, 'Evidence weighting must be multiplicative.');
expect_near(36.0, $result['score'], 0.000001, 'Evidence score must be value x 100.');
