<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\UsageNormalizer;

$normalizer = new UsageNormalizer();

$openai = $normalizer->normalize('openai', [
    'prompt_tokens' => 100,
    'completion_tokens' => 40,
    'total_tokens' => 140,
    'prompt_tokens_details' => ['cached_tokens' => 12],
    'completion_tokens_details' => ['reasoning_tokens' => 7],
]);
expect_same(100, $openai['input_tokens'], 'OpenAI prompt tokens normalize to input tokens.');
expect_same(40, $openai['output_tokens'], 'OpenAI completion tokens normalize to output tokens.');
expect_same(140, $openai['total_tokens'], 'OpenAI total tokens are preserved.');
expect_same(12, $openai['cached_input_tokens'], 'OpenAI cached tokens normalize.');
expect_same(7, $openai['reasoning_tokens'], 'OpenAI reasoning tokens normalize.');

$anthropic = $normalizer->normalize('anthropic', ['input_tokens' => 22, 'output_tokens' => 11]);
expect_same(22, $anthropic['input_tokens'], 'Anthropic input tokens normalize.');
expect_same(11, $anthropic['output_tokens'], 'Anthropic output tokens normalize.');
expect_same(33, $anthropic['total_tokens'], 'Anthropic total is derived when omitted.');

$gemini = $normalizer->normalize('gemini', [
    'promptTokenCount' => 7,
    'candidatesTokenCount' => 5,
    'totalTokenCount' => 12,
    'cachedContentTokenCount' => 2,
    'thoughtsTokenCount' => 1,
]);
expect_same(7, $gemini['input_tokens'], 'Gemini promptTokenCount normalizes.');
expect_same(5, $gemini['output_tokens'], 'Gemini candidatesTokenCount normalizes.');
expect_same(12, $gemini['total_tokens'], 'Gemini totalTokenCount normalizes.');
expect_same(2, $gemini['cached_input_tokens'], 'Gemini cached token count normalizes.');
expect_same(1, $gemini['reasoning_tokens'], 'Gemini thought token count normalizes.');

$reported = $normalizer->normalize('openrouter', ['prompt_tokens' => 3, 'completion_tokens' => 2, 'cost' => 0.0042]);
expect_near(0.0042, (float) $reported['reported_cost'], 0.000001, 'Provider reported cost is retained.');
