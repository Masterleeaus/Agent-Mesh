<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$provider = file_get_contents($root . '/System/ModelCouncilServiceProvider.php') ?: '';
$controller = file_get_contents($root . '/System/Http/Controllers/AssuranceController.php') ?: '';
$contract = file_get_contents($root . '/System/Contracts/AssuranceEngine.php') ?: '';
$engine = file_get_contents($root . '/System/Services/Assurance/AssuranceEngineService.php') ?: '';
$evaluator = file_get_contents($root . '/System/Services/Assurance/AssuranceRunEvaluator.php') ?: '';

expect_true(str_contains($provider, "'/intelligence'"), 'v1.9 intelligence endpoint must be registered.');
expect_true(str_contains($provider, "'/intelligence/recommendations'"), 'v1.9 recommendation endpoint must be registered.');
expect_true(str_contains($controller, 'function intelligence('), 'Assurance controller must expose intelligence action.');
expect_true(str_contains($controller, 'function intelligenceRecommendations('), 'Assurance controller must expose recommendation action.');
expect_true(str_contains($contract, 'function intelligence('), 'AssuranceEngine contract must expose company-scoped intelligence.');
expect_true(str_contains($contract, 'function recommendations('), 'AssuranceEngine contract must expose advisory recommendations.');
expect_true(str_contains($engine, "->where('company_id', \$companyId)"), 'Intelligence queries must preserve company tenant boundary.');
expect_true(str_contains($engine, 'ComplianceRulePackResolver'), 'Run creation must support validated external compliance sources.');
expect_true(str_contains($engine, 'compliance_rule_snapshot'), 'Run creation must persist immutable compliance rule snapshot.');
expect_true(str_contains($evaluator, 'ExternalComplianceRulePack'), 'Evaluator must use stored external compliance snapshot rather than refetching mutable rules.');
expect_true(! str_contains($provider, '/intelligence/policy'), 'v1.9 must not expose an intelligence policy-mutation endpoint.');
