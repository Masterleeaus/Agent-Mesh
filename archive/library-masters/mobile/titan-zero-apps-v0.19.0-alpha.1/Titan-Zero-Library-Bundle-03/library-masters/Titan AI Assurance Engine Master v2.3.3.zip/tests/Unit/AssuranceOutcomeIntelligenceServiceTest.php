<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Intelligence\AssuranceOutcomeIntelligenceService;

$records = [
    ['occurred_at' => '2026-08-01T00:00:00Z', 'provider' => 'openai', 'model_family' => 'gpt-4.1', 'candidate_status' => 'completed', 'assurance_score' => 90, 'success' => true,  'material_disagreement' => false, 'deterministic_failed' => false, 'evidence_sufficiency' => 0.9, 'rule_pack_key' => 'field-home', 'cost_complete' => true],
    ['occurred_at' => '2026-08-02T00:00:00Z', 'provider' => 'anthropic', 'model_family' => 'claude-4', 'candidate_status' => 'completed', 'assurance_score' => 85, 'success' => true, 'material_disagreement' => false, 'deterministic_failed' => false, 'evidence_sufficiency' => 0.8, 'rule_pack_key' => 'field-home', 'cost_complete' => true],
    ['occurred_at' => '2026-08-03T00:00:00Z', 'provider' => 'openai', 'model_family' => 'gpt-4.1', 'candidate_status' => 'failed', 'assurance_score' => 80, 'success' => false, 'material_disagreement' => true, 'deterministic_failed' => true, 'evidence_sufficiency' => 0.6, 'rule_pack_key' => 'field-home', 'cost_complete' => false],
    ['occurred_at' => '2026-08-04T00:00:00Z', 'provider' => 'openai', 'model_family' => 'gpt-4.1', 'candidate_status' => 'failed', 'assurance_score' => 88, 'success' => false, 'material_disagreement' => true, 'deterministic_failed' => false, 'evidence_sufficiency' => 0.5, 'rule_pack_key' => 'field-home', 'cost_complete' => false],
    ['occurred_at' => '2026-08-05T00:00:00Z', 'provider' => 'anthropic', 'model_family' => 'claude-4', 'candidate_status' => 'completed', 'assurance_score' => 82, 'success' => false, 'material_disagreement' => true, 'deterministic_failed' => true, 'evidence_sufficiency' => 0.4, 'rule_pack_key' => 'field-home', 'cost_complete' => true],
    ['occurred_at' => '2026-08-06T00:00:00Z', 'provider' => 'openai', 'model_family' => 'gpt-4.1', 'candidate_status' => 'completed', 'assurance_score' => 75, 'success' => true, 'material_disagreement' => false, 'deterministic_failed' => false, 'evidence_sufficiency' => 0.7, 'rule_pack_key' => 'ecommerce', 'cost_complete' => true],
];

$service = new AssuranceOutcomeIntelligenceService();
$result = $service->summarize($records, recentWindow: 3, minimumCohort: 2);

expect_same(6, $result['sample_count'], 'Outcome intelligence counts valid records.');
expect_same(false, $result['policy_mutation'], 'Outcome intelligence cannot mutate policy.');
expect_same(4, $result['provider_metrics']['openai']['sample_count'], 'Provider metrics aggregate by provider.');
expect_near(0.5, $result['provider_metrics']['openai']['candidate_failure_rate'], 0.000001, 'Provider candidate failure rate is measured.');
expect_same(4, $result['model_family_metrics']['gpt-4.1']['sample_count'], 'Model-family metrics aggregate independently of provider.');
expect_near(0.5, $result['material_disagreement_rate'], 0.000001, 'Material disagreement frequency is measured.');
expect_near(2 / 6, $result['deterministic_failure_rate'], 0.000001, 'Deterministic failure frequency is measured.');
expect_near(2 / 6, $result['incomplete_cost_accounting_rate'], 0.000001, 'Incomplete cost accounting frequency is measured.');
expect_same(5, $result['rule_pack_metrics']['field-home']['sample_count'], 'Rule-pack metrics aggregate across runs.');
expect_same(false, $result['drift']['insufficient_data'], 'Drift is computed when both windows meet minimum cohort.');
expect_near(-1 / 3, $result['drift']['success_rate_delta'], 0.000001, 'Recent success-rate drift is measured against prior window.');
expect_true(is_float($result['drift']['calibration_gap_delta']), 'Calibration drift is measured from observed-versus-predicted gaps.');

$small = $service->summarize(array_slice($records, 0, 2), recentWindow: 1, minimumCohort: 2);
expect_same(true, $small['drift']['insufficient_data'], 'Small cohorts do not invent drift confidence.');
expect_same(null, $small['drift']['success_rate_delta'], 'Insufficient drift data returns null deltas.');

$multiCandidate = [
    ['run_id' => 10, 'occurred_at' => '2026-08-01', 'provider' => 'openai', 'model_family' => 'gpt', 'candidate_status' => 'completed', 'assurance_score' => 90, 'success' => true, 'material_disagreement' => false, 'deterministic_failed' => false, 'evidence_sufficiency' => 0.9, 'rule_pack_key' => 'field-home', 'cost_complete' => true],
    ['run_id' => 10, 'occurred_at' => '2026-08-01', 'provider' => 'anthropic', 'model_family' => 'claude', 'candidate_status' => 'completed', 'assurance_score' => 90, 'success' => true, 'material_disagreement' => false, 'deterministic_failed' => false, 'evidence_sufficiency' => 0.9, 'rule_pack_key' => 'field-home', 'cost_complete' => true],
    ['run_id' => 11, 'occurred_at' => '2026-08-02', 'provider' => 'openai', 'model_family' => 'gpt', 'candidate_status' => 'failed', 'assurance_score' => 70, 'success' => false, 'material_disagreement' => true, 'deterministic_failed' => true, 'evidence_sufficiency' => 0.4, 'rule_pack_key' => 'field-home', 'cost_complete' => false],
];
$deduped = $service->summarize($multiCandidate, recentWindow: 1, minimumCohort: 1);
expect_same(3, $deduped['sample_count'], 'Candidate observation count remains visible.');
expect_same(2, $deduped['run_sample_count'], 'Run-level metrics deduplicate multi-candidate runs.');
expect_near(0.5, $deduped['material_disagreement_rate'], 0.000001, 'Run-level disagreement is not multiplied by candidate count.');
expect_same(2, $deduped['rule_pack_metrics']['field-home']['sample_count'], 'Rule-pack outcomes count runs rather than candidates.');
expect_same(2, $deduped['provider_metrics']['openai']['sample_count'], 'Provider metrics remain candidate-level.');
