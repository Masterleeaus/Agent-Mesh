<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$migration = $root . '/database/migrations/2026_08_09_000013_extend_assurance_streaming_compliance_intelligence.php';
$snapshotMigration = $root . '/database/migrations/2026_08_09_000014_create_assurance_intelligence_snapshots_table.php';
expect_true(is_file($migration), 'v1.9 additive streaming/compliance migration must exist.');
expect_true(is_file($snapshotMigration), 'v1.9 intelligence snapshot migration must exist.');
$source = is_file($migration) ? (file_get_contents($migration) ?: '') : '';
foreach (['streamed', 'stream_chunk_count', 'stream_completed_at', 'compliance_source_key', 'compliance_jurisdiction', 'compliance_rule_version', 'compliance_rule_hash', 'compliance_rule_snapshot'] as $column) {
    expect_true(str_contains($source, $column), "v1.9 migration must add {$column}.");
}
expect_true(str_contains($source, 'Schema::hasColumn'), 'v1.9 migration must use additive column guards.');
$snapshotSource = is_file($snapshotMigration) ? (file_get_contents($snapshotMigration) ?: '') : '';
foreach (['assurance_intelligence_snapshots', 'company_id', 'metrics', 'recommendations', 'generated_at'] as $surface) {
    expect_true(str_contains($snapshotSource, $surface), "v1.9 snapshot migration must contain {$surface}.");
}

$runModel = file_get_contents($root . '/System/Models/AssuranceRun.php') ?: '';
expect_true(str_contains($runModel, "'compliance_rule_snapshot' => 'array'"), 'Run model must cast immutable compliance snapshot.');
$candidateModel = file_get_contents($root . '/System/Models/AssuranceCandidate.php') ?: '';
expect_true(str_contains($candidateModel, "'streamed' => 'boolean'"), 'Candidate model must cast streamed flag.');
expect_true(str_contains($candidateModel, "'stream_completed_at' => 'datetime'"), 'Candidate model must cast streaming completion timestamp.');
expect_true(is_file($root . '/System/Models/AssuranceIntelligenceSnapshot.php'), 'Intelligence snapshot model must exist.');
