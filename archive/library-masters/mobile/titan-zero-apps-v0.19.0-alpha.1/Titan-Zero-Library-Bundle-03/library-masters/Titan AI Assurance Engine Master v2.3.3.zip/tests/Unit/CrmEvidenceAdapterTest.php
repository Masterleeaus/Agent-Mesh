<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\CrmEvidenceAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\EvidenceSourceRegistry;

$seenCompany = null;
$seenRefs = null;
$adapter = new CrmEvidenceAdapter(function (string $companyId, array $refs) use (&$seenCompany, &$seenRefs): array {
    $seenCompany = $companyId;
    $seenRefs = $refs;
    return [[
        'id' => 'job-1',
        'type' => 'job',
        'updated_at' => '2026-08-09T00:00:00Z',
        'data' => ['status' => 'completed', 'total' => 120],
        'metadata' => ['source_system' => 'crm'],
    ]];
});

$records = $adapter->resolve('company-7', [[
    'type' => 'job',
    'id' => 'job-1',
    'company_id' => 'attacker-company',
]]);
expect_same('company-7', $seenCompany, 'CRM reader receives secured company context.');
expect_true(! isset($seenRefs[0]['company_id']), 'Caller-supplied company id is stripped before CRM lookup.');
expect_same('crm', $records[0]['source'], 'CRM evidence provenance is canonical.');
expect_same('job', $records[0]['source_type'], 'CRM source type is preserved.');
expect_same('job-1', $records[0]['source_id'], 'CRM source id is preserved.');
expect_same('2026-08-09T00:00:00Z', $records[0]['observed_at'], 'CRM observation time is preserved.');
expect_true(strlen($records[0]['content_hash']) === 64, 'Canonical CRM evidence is SHA-256 hashed.');

$registry = new EvidenceSourceRegistry([$adapter]);
expect_same($adapter, $registry->for('crm'), 'Evidence source registry resolves CRM adapter.');
expect_true(in_array('crm', $registry->keys(), true), 'Evidence source registry exposes source keys.');
