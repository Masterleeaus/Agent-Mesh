<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

if (! interface_exists(SignalEmitterAuthorityContract::class)) {
    interface SignalEmitterAuthorityContract { public function issue(string $serviceId): mixed; }
}
if (! interface_exists(SignalRegistryAuthorityContract::class)) {
    interface SignalRegistryAuthorityContract { public function issue(string $serviceId): mixed; }
}
if (! interface_exists(EventTypeRegistryContract::class)) {
    interface EventTypeRegistryContract {
        public function find(string $eventType): mixed;
        public function register(mixed $definition, mixed $registrar, ?string $ownerServiceId = null): void;
    }
}
if (! interface_exists(SignalManagerContract::class)) {
    interface SignalManagerContract { public function emit(array $signal, mixed $context): array; }
}

namespace App\Extensions\TitanSignalEngine\System\Data;

if (! class_exists(SignalActor::class)) {
    final class SignalActor {
        public function __construct(
            public string $id,
            public string $type,
            public ?int $companyId = null,
            public ?string $identityProvider = null,
            public ?string $sessionId = null,
        ) {}
    }
}

if (! class_exists(SignalContext::class)) {
    final class SignalContext {
        public function __construct(
            public string $scope,
            public ?int $companyId,
            public SignalActor $actor,
            public array $permissions = [],
            public mixed $emitter = null,
        ) {}
    }
}

if (! class_exists(EventTypeDefinition::class)) {
    final class EventTypeDefinition {
        public function __construct(public array $data) {}
        public static function fromArray(array $data): self { return new self($data); }
    }
}
