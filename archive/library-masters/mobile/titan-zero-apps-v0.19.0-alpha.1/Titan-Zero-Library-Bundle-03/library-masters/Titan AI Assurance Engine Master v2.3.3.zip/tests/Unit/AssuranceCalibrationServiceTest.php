<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\AssuranceCalibrationService;
use App\Extensions\TitanAssurance\System\Services\Assurance\OutcomeRecorder;

$recorder = new OutcomeRecorder();
$normalized = $recorder->normalize([
    'outcome_type' => 'job_result',
    'success' => true,
    'impact' => ['revenue' => 100],
    'correction' => [],
]);
expect_same('job_result', $normalized['outcome_type'], 'Outcome type is normalized.');
expect_same(true, $normalized['success'], 'Boolean success is preserved.');

$service = new AssuranceCalibrationService();
$result = $service->summarize([
    ['assurance_score' => 90, 'success' => true],
    ['assurance_score' => 80, 'success' => false],
]);
expect_same(2, $result['sample_count'], 'Calibration counts samples.');
expect_near(0.5, $result['success_rate'], 0.000001, 'Calibration computes observed success rate.');
expect_near(85.0, $result['mean_assurance_score'], 0.000001, 'Calibration computes mean score.');
expect_near(0.325, $result['brier_score'], 0.000001, 'Calibration computes Brier score.');
expect_near(-0.35, $result['calibration_gap'], 0.000001, 'Calibration gap is observed minus predicted success.');
expect_true(isset($result['score_buckets']), 'Calibration exposes score buckets.');
expect_true(! array_key_exists('recommended_minimum_score', $result), 'v1.8 calibration must not auto-propose weaker policy thresholds.');

$empty = $service->summarize([]);
expect_same(0, $empty['sample_count'], 'Empty calibration has zero samples.');
expect_same(null, $empty['brier_score'], 'Empty calibration has no Brier score.');
