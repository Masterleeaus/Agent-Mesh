<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Compliance\ComplianceRuleDocumentValidator;
use App\Extensions\TitanAssurance\System\Services\Assurance\Compliance\ExternalComplianceRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\DeterministicValidationPipeline;
use App\Extensions\TitanAssurance\System\Services\Assurance\StructuredResponseValidator;

$validator = new ComplianceRuleDocumentValidator();
$document = [
    'source_key' => 'authoritative-feed',
    'rule_pack_key' => 'field-home',
    'jurisdiction' => 'AU-VIC',
    'version' => '2026.08.09.2',
    'effective_from' => '2026-08-01',
    'rules' => [
        ['id' => 'customer-required', 'operator' => 'required', 'field' => 'customer.id', 'message' => 'Customer id required.'],
        ['id' => 'discount-range', 'operator' => 'range', 'field' => 'discount_percent', 'min' => 0, 'max' => 100],
        ['id' => 'schedule-order', 'operator' => 'date_order', 'start' => 'schedule.start', 'end' => 'schedule.end'],
        ['id' => 'status-known', 'operator' => 'in', 'field' => 'status', 'values' => ['draft', 'approved']],
    ],
    'provenance' => ['publisher' => 'Example source'],
];
$document['content_hash'] = $validator->contentHash($document);
$validated = $validator->validate($document, 'AU-VIC', '2026-08-09');
$pack = new ExternalComplianceRulePack($validated);

$pipeline = new DeterministicValidationPipeline(new StructuredResponseValidator());
$structured = [
    'answer' => 'Review',
    'confidence' => 0.7,
    'claims' => [],
    'evidence' => [],
    'risks' => [],
    'assumptions' => [],
];
$result = $pipeline->validateCandidateWithPack($structured, $pack, [
    'customer' => ['id' => ''],
    'discount_percent' => 125,
    'schedule' => ['start' => '2026-08-10', 'end' => '2026-08-09'],
    'status' => 'unknown',
]);

expect_same('failed', $result['status'], 'External deterministic rule failures block candidate validation.');
expect_same('field-home', $result['rule_pack_key'], 'External pack retains declared rule-pack key.');
expect_same('2026.08.09.2', $result['rule_pack_version'], 'External pack retains source version.');
$codes = array_map(static fn (array $finding): string => (string) ($finding['code'] ?? ''), $result['findings']);
foreach (['external_required', 'external_range', 'external_date_order', 'external_in'] as $code) {
    expect_true(in_array($code, $codes, true), "External rule finding {$code} must be emitted.");
}
$external = array_values(array_filter($result['findings'], static fn (array $finding): bool => str_starts_with((string) ($finding['code'] ?? ''), 'external_')));
expect_same('authoritative-feed', $external[0]['metadata']['source_key'] ?? null, 'External findings retain source provenance.');
expect_same('AU-VIC', $external[0]['metadata']['jurisdiction'] ?? null, 'External findings retain jurisdiction provenance.');

$invalidOperator = $validated;
$invalidOperator['rules'][] = ['id' => 'danger', 'operator' => 'eval', 'field' => 'x'];
$thrown = false;
try {
    new ExternalComplianceRulePack($invalidOperator);
} catch (InvalidArgumentException $e) {
    $thrown = str_contains($e->getMessage(), 'operator');
}
expect_true($thrown, 'Unknown external rule operators are rejected rather than executed.');
