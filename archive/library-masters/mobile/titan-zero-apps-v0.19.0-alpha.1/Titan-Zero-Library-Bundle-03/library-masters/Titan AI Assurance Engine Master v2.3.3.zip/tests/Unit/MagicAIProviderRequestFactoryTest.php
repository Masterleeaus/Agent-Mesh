<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\MagicAIProviderRequestFactory;

$factory = new MagicAIProviderRequestFactory(
    fn (string $provider): string => 'key-' . $provider,
    fn (string $key, mixed $default = null): mixed => match ($key) {
        'open_router_api' => 'router-key',
        default => $default,
    },
    fn (string $key, mixed $default = null): mixed => match ($key) {
        'app.url' => 'https://titan.test',
        'app.name' => 'Titan',
        default => $default,
    },
);

$openai = $factory->build('openai', 'gpt-test', ['model' => 'gpt-test']);
expect_same('https://api.openai.com/v1/chat/completions', $openai['url'], 'OpenAI endpoint is centralized.');
expect_same('Bearer key-openai', $openai['headers']['Authorization'], 'OpenAI credential is centralized.');

$anthropic = $factory->build('anthropic', 'claude-test', ['model' => 'claude-test']);
expect_same('key-anthropic', $anthropic['headers']['x-api-key'], 'Anthropic credential is centralized.');
expect_same('2023-06-01', $anthropic['headers']['anthropic-version'], 'Anthropic API version is centralized.');

$gemini = $factory->build('gemini', 'gemini/test', ['contents' => []]);
expect_true(str_contains($gemini['url'], 'gemini%2Ftest:generateContent?key=key-gemini'), 'Gemini model/key are encoded in endpoint.');

$router = $factory->build('openrouter', 'openai/gpt-test', ['model' => 'openai/gpt-test']);
expect_same('Bearer router-key', $router['headers']['Authorization'], 'OpenRouter setting is centralized.');
expect_same('https://titan.test', $router['headers']['HTTP-Referer'], 'OpenRouter referer is centralized.');
