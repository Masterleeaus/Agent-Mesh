<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\AutonomyAssuranceProjectionService;

expect_true(class_exists(AutonomyAssuranceProjectionService::class), 'v2.1 must provide an Autonomy projection service for evidence-native assessments.');
$service = new AutonomyAssuranceProjectionService();

$green = $service->project([
    'status' => 'GREEN',
    'score' => 92.5,
    'uuid' => 'assessment-green',
    'reason_codes' => ['EVIDENCE_SUPPORTS_ACTION'],
    'policy_version' => 'titan-assurance-v2.1',
    'calibration_metadata' => ['detected' => false, 'calibration_factor' => 1.0],
]);
expect_same('GREEN', $green['status'] ?? null, 'GREEN assessment must project GREEN.');
expect_same('approved', $green['decision'] ?? null, 'GREEN must project the compatibility approval signal Autonomy v1.10 consumes.');
expect_near(0.925, (float) ($green['confidence'] ?? 0.0), 0.0001, 'Score must normalize to 0..1 confidence.');
expect_same('assessment-green', $green['evaluation_ref'] ?? null, 'Assessment UUID must become evaluation_ref.');
expect_true(($green['available'] ?? false) === true, 'Resolved evidence-native assessment must be available.');
expect_true(($green['authority_granted'] ?? true) === false, 'Assurance projection must explicitly state that it grants no execution authority.');

$amber = $service->project([
    'status' => 'AMBER',
    'score' => 71,
    'uuid' => 'assessment-amber',
    'reason_codes' => ['STALE_EVIDENCE'],
    'calibration_metadata' => ['detected' => false],
]);
expect_same('denied', $amber['decision'] ?? null, 'AMBER must not project an Autonomy approval signal.');

$drift = $service->project([
    'status' => 'GREEN',
    'score' => 88,
    'uuid' => 'assessment-drift',
    'reason_codes' => ['CALIBRATION_DOWNWEIGHTED'],
    'calibration_metadata' => ['detected' => true, 'calibration_factor' => 0.7],
]);
expect_true(($drift['calibrated'] ?? true) === false, 'Detected miscalibration must project calibrated=false.');
expect_true(in_array('ASSURANCE_MISCALIBRATION_ACTIVE', $drift['reason_codes'] ?? [], true), 'Miscalibration must be explicit in projected reason codes.');
