<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$provider = file_get_contents($root . '/System/ModelCouncilServiceProvider.php') ?: '';
$config = file_get_contents($root . '/config/model-council.php') ?: '';
$engine = file_get_contents($root . '/System/Services/Assurance/EvidenceAssuranceEngineService.php') ?: '';
$status = file_get_contents($root . '/System/Services/Assurance/Integration/CrossEngineIntegrationStatus.php') ?: '';
$manifest = json_decode(file_get_contents($root . '/extension.json') ?: '{}', true);

expect_true(str_contains($provider, 'TitanSignalIntegrationProfile'), 'Provider must register the Signal integration profile.');
expect_true(str_contains($provider, 'TitanSignalAssuranceSink'), 'Provider must register the live Titan Signal Assurance sink.');
expect_true(str_contains($provider, "titan.assurance.integration_sinks"), 'Signal sink must be tagged into the canonical Assurance integration registry.');
expect_true(str_contains($provider, 'trusted_emitters'), 'Provider must contribute a least-privilege Signal trusted emitter definition.');
expect_true(str_contains($provider, 'registry_actors'), 'Provider must contribute a least-privilege Signal registry actor definition.');
expect_true(str_contains($config, "'signal' =>"), 'Assurance integration config must expose a Titan Signal feature toggle.');
expect_true(str_contains($engine, "'assurance.evidence.recollection.requested'"), 'Evidence recollection must emit a canonical Signal lifecycle event.');
expect_true(str_contains($engine, "'assurance.feedback.recorded'"), 'Feedback persistence must emit a canonical Signal lifecycle event.');
expect_true(str_contains($status, "'titan_signal' => \$this->contractStatus('App\\\\Extensions\\\\TitanSignalEngine\\\\System\\\\Contracts\\\\SignalManagerContract', true)"), 'Integration status must recognize Signal as a real Assurance write receiver.');
expect_same('2.3.0', $manifest['version'] ?? null, 'Extension version must advance to 2.3.0 for the live Signal pass.');

$requiredSignal = array_values(array_filter((array) ($manifest['dependencies'] ?? []), static fn (array $dep): bool => ($dep['slug'] ?? null) === 'titan-signal-engine'));
expect_same(1, count($requiredSignal), 'Installer must depend on the canonical Titan Signal Engine slug exactly once.');
expect_same('>=0.20.0-rc.3', $requiredSignal[0]['version'] ?? null, 'Installer must require the receiver contract version verified by this pass.');
$optionalSignal = array_values(array_filter((array) ($manifest['optional_dependencies'] ?? []), static fn (array $dep): bool => in_array(($dep['slug'] ?? null), ['titan-signal', 'titan-signal-engine'], true)));
expect_same(0, count($optionalSignal), 'Required Titan Signal must not also be declared optional.');
$capabilities = json_decode(file_get_contents($root . '/titan-capabilities.json') ?: '{}', true);
expect_same('live_receiver_adapter', $capabilities['integrations']['titan_signal']['mode'] ?? null, 'Capability inventory must report the Signal receiver adapter as live.');
expect_same('0.20.0-rc.3', $capabilities['integrations']['titan_signal']['certified_receiver_version'] ?? null, 'Capability inventory must record the exact Signal receiver contract verified in this pass.');

$governanceManifest = json_decode(file_get_contents($root . '/extension.manifest.json') ?: '{}', true);
$governanceSignal = array_values(array_filter((array) ($governanceManifest['dependencies']['required'] ?? []), static fn (array $dep): bool => ($dep['key'] ?? null) === 'titan-signal'));
expect_same(1, count($governanceSignal), 'Canonical Blueprint sidecar must use the titan-signal engine key.');
expect_same('>=0.20.0-rc.3', $governanceSignal[0]['version'] ?? null, 'Canonical Signal governance dependency must match the verified receiver contract floor.');
