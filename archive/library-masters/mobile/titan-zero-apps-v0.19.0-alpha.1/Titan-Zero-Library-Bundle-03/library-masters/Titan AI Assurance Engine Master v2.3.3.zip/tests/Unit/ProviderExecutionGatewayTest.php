<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Contracts\AssuranceProviderTransport;
use App\Extensions\TitanAssurance\System\Exceptions\AssuranceProviderException;
use App\Extensions\TitanAssurance\System\Services\Assurance\Capabilities\ModelCapabilityRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\OpenAIAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\ProviderAdapterRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\ProviderExecutionGateway;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\UsageNormalizer;

$registry = new ProviderAdapterRegistry([new OpenAIAdapter(new ModelCapabilityRegistry())]);
$transport = new class implements AssuranceProviderTransport {
    public int $status = 200;
    public array $lastRequest = [];

    public function send(string $providerKey, string $modelId, array $request): array
    {
        $this->lastRequest = $request;
        return [
            'status' => $this->status,
            'body' => [
                'choices' => [['message' => ['content' => 'ok']]],
                'usage' => ['prompt_tokens' => 3, 'completion_tokens' => 2, 'total_tokens' => 5],
            ],
            'response_time_ms' => 9,
        ];
    }
};

$gateway = new ProviderExecutionGateway($registry, $transport, new UsageNormalizer());
$result = $gateway->execute('openai', 'gpt-4.1', [['role' => 'user', 'content' => 'x']], ['temperature' => 0]);
expect_same('ok', $result['text'], 'Gateway parses provider response.');
expect_same(5, $result['usage']['total_tokens'], 'Gateway normalizes usage.');
expect_same('gpt-4.1', $transport->lastRequest['model'], 'Gateway builds request through provider adapter.');
expect_same(9, $result['response_time_ms'], 'Gateway preserves transport latency.');

$transport->status = 429;
$thrown = false;
try {
    $gateway->execute('openai', 'gpt-4.1', [['role' => 'user', 'content' => 'x']]);
} catch (AssuranceProviderException $e) {
    $thrown = $e->errorClass === 'retryable' && $e->statusCode === 429;
}
expect_true($thrown, 'Gateway classifies non-2xx responses through provider adapter.');
