<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\CostEstimator;
use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\CostReservationService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\CostReconciler;

$estimator = new CostEstimator();
$estimate = $estimator->estimate([
    ['estimated_cost' => 0.25], ['estimated_cost' => 0.40], ['estimated_cost' => 0.35],
], ['challenge_estimated_cost' => 0.20, 'synthesis_estimated_cost' => 0.10]);
expect_near(1.30, $estimate['estimated_cost'], 0.00001, 'Panel/challenge/synthesis estimate should sum.');

$reservation = new CostReservationService();
$blocked = $reservation->decision(1.30, 1.00);
expect_true(! $blocked['reserved'], 'Insufficient budget ceiling must block reservation.');

$reconciler = new CostReconciler();
$actual = $reconciler->actual([['cost' => 0.3], ['cost' => -2], ['cost' => 0.4]]);
expect_near(0.70, $actual, 0.00001, 'Negative candidate cost must never reduce actual cost.');
