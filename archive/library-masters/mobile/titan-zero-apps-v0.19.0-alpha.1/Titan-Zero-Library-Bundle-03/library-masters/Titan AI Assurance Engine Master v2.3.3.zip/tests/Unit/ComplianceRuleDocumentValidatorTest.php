<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Contracts\ComplianceSignatureVerifier;
use App\Extensions\TitanAssurance\System\Services\Assurance\Compliance\ComplianceRuleDocumentValidator;

$verifier = new class implements ComplianceSignatureVerifier {
    public int $calls = 0;

    public function verify(string $canonicalPayload, string $signature, ?string $keyId = null): bool
    {
        $this->calls++;
        return $signature === 'valid-signature' && $keyId === 'key-1' && str_contains($canonicalPayload, 'field-home');
    }
};

$validator = new ComplianceRuleDocumentValidator($verifier);
$document = [
    'source_key' => 'victoria-compliance-feed',
    'rule_pack_key' => 'field-home',
    'jurisdiction' => 'AU-VIC',
    'version' => '2026.08.09.1',
    'effective_from' => '2026-08-01',
    'effective_to' => '2026-12-31',
    'rules' => [
        ['id' => 'discount-range', 'operator' => 'range', 'field' => 'discount_percent', 'min' => 0, 'max' => 100],
    ],
    'provenance' => ['publisher' => 'Example authoritative feed', 'retrieved_at' => '2026-08-09T08:00:00Z'],
    'signature' => 'valid-signature',
    'signature_key_id' => 'key-1',
];
$document['content_hash'] = $validator->contentHash($document);

$validated = $validator->validate($document, 'AU-VIC', '2026-08-09', true);
expect_same('2026.08.09.1', $validated['version'], 'Valid compliance document passes validation.');
expect_same(1, $verifier->calls, 'Signature verifier is invoked for signed required document.');

$tampered = $document;
$tampered['rules'][0]['max'] = 90;
$thrown = false;
try {
    $validator->validate($tampered, 'AU-VIC', '2026-08-09', true);
} catch (InvalidArgumentException $e) {
    $thrown = str_contains($e->getMessage(), 'hash');
}
expect_true($thrown, 'Tampered content hash fails closed.');

$future = $document;
$future['effective_from'] = '2026-09-01';
$future['content_hash'] = $validator->contentHash($future);
$thrown = false;
try {
    $validator->validate($future, 'AU-VIC', '2026-08-09', true);
} catch (InvalidArgumentException $e) {
    $thrown = str_contains($e->getMessage(), 'effective');
}
expect_true($thrown, 'Not-yet-effective document fails closed.');

$expired = $document;
$expired['effective_to'] = '2026-08-08';
$expired['content_hash'] = $validator->contentHash($expired);
$thrown = false;
try {
    $validator->validate($expired, 'AU-VIC', '2026-08-09', true);
} catch (InvalidArgumentException $e) {
    $thrown = str_contains($e->getMessage(), 'expired');
}
expect_true($thrown, 'Expired document fails closed.');

$thrown = false;
try {
    $validator->validate($document, 'AU-NSW', '2026-08-09', true);
} catch (InvalidArgumentException $e) {
    $thrown = str_contains($e->getMessage(), 'jurisdiction');
}
expect_true($thrown, 'Jurisdiction mismatch fails closed.');

$unsigned = $document;
unset($unsigned['signature'], $unsigned['signature_key_id']);
$unsigned['content_hash'] = $validator->contentHash($unsigned);
$thrown = false;
try {
    $validator->validate($unsigned, 'AU-VIC', '2026-08-09', true);
} catch (InvalidArgumentException $e) {
    $thrown = str_contains($e->getMessage(), 'signature');
}
expect_true($thrown, 'Required signature cannot be omitted.');
