<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\IndependenceScoringService;
use App\Extensions\TitanAssurance\System\Services\Assurance\PanelSelectionService;

$service = new PanelSelectionService(new IndependenceScoringService());

$highInvalid = $service->validate([
    ['provider' => 'openai', 'model_id' => 'gpt-4.1', 'family' => 'gpt-4'],
    ['provider' => 'openai', 'model_id' => 'gpt-4o', 'family' => 'gpt-4'],
    ['provider' => 'openai', 'model_id' => 'gpt-4-turbo', 'family' => 'gpt-4'],
], 'high');
expect_true(! $highInvalid['valid'], 'High mode cannot pass with one model family.');
expect_true(in_array('minimum_model_families', $highInvalid['violations'], true), 'Family diversity violation expected.');

$critical = $service->validate([
    ['provider' => 'openai', 'model_id' => 'gpt-4.1', 'family' => 'gpt-4'],
    ['provider' => 'anthropic', 'model_id' => 'claude-sonnet-4', 'family' => 'claude-sonnet'],
    ['provider' => 'gemini', 'model_id' => 'gemini-2.5-pro', 'family' => 'gemini-pro'],
], 'critical');
expect_true($critical['valid'], 'Critical diverse panel should pass.');
expect_true($critical['independence']['score'] >= 90.0, 'Three-provider/family panel should score high independence.');
