<?php
require_once __DIR__ . '/../Support/bootstrap.php';
require_once __DIR__ . '/../Fixtures/TitanSignalContracts.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\TitanSignalAssuranceSink;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\TitanSignalIntegrationProfile;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\TitanSignalIntegrationRegistrar;
use App\Extensions\TitanSignalEngine\System\Contracts\EventTypeRegistryContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterAuthorityContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalManagerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalRegistryAuthorityContract;

final class V23FakeContainer {
    public function __construct(private array $bindings) {}
    public function bound(string $id): bool { return array_key_exists($id, $this->bindings); }
    public function make(string $id): mixed { return $this->bindings[$id] ?? throw new RuntimeException('Missing binding ' . $id); }
}

final class V23EmitterAuthority implements SignalEmitterAuthorityContract {
    public function issue(string $serviceId): mixed { return (object) ['serviceId' => $serviceId, 'source' => 'titan-assurance']; }
}
final class V23RegistryAuthority implements SignalRegistryAuthorityContract {
    public function issue(string $serviceId): mixed { return (object) ['serviceId' => $serviceId]; }
}
final class V23Registry implements EventTypeRegistryContract {
    public array $definitions = [];
    public function find(string $eventType): mixed { return $this->definitions[$eventType] ?? null; }
    public function register(mixed $definition, mixed $registrar, ?string $ownerServiceId = null): void {
        $this->definitions[$definition->data['event_type']] = $definition;
    }
}
final class V23SignalManager implements SignalManagerContract {
    public array $emitted = [];
    public function emit(array $signal, mixed $context): array {
        $this->emitted[] = [$signal, $context];
        return ['event_id' => '11111111-1111-4111-8111-111111111111', 'recorded_at' => '2026-08-19T00:00:00+10:00', 'duplicate' => false, 'original_event_id' => null];
    }
}

$profile = new TitanSignalIntegrationProfile();
expect_same('titan-assurance:runtime', $profile->emitterServiceId(), 'Signal emitter service id must be stable.');
expect_same(['assurance.*'], $profile->trustedEmitterDefinition()['event_type_patterns'] ?? null, 'Signal emitter must be limited to Assurance event family.');
expect_same(['signal.registry.event.manage'], $profile->registryActorDefinition()['permissions'] ?? null, 'Assurance registry actor must only receive event-registry authority.');
expect_same([
    'assurance.assessment.completed',
    'assurance.evidence.recollection.requested',
    'assurance.feedback.recorded',
    'assurance.miscalibration.detected',
], array_keys($profile->eventDefinitions()), 'Canonical Assurance Signal event set must be complete.');

$registry = new V23Registry();
$manager = new V23SignalManager();
$container = new V23FakeContainer([
    SignalEmitterAuthorityContract::class => new V23EmitterAuthority(),
    SignalRegistryAuthorityContract::class => new V23RegistryAuthority(),
    EventTypeRegistryContract::class => $registry,
    SignalManagerContract::class => $manager,
]);
$registrar = new TitanSignalIntegrationRegistrar($container, $profile);
$status = $registrar->ensureRegistered();
expect_true(($status['ready'] ?? false) === true, 'Signal registrar must become ready when the receiver contracts are available.');
expect_same(4, count($registry->definitions), 'Signal registrar must register all four Assurance event types.');

$sink = new TitanSignalAssuranceSink($container, $registrar, $profile);
$receipt = $sink->publish([
    'event_type' => 'assurance.assessment.completed',
    'destination' => 'titan_signal',
    'idempotency_key' => 'assurance-assessment:abc',
    'payload' => [
        'company_id' => 42,
        'assessment_uuid' => '22222222-2222-4222-8222-222222222222',
        'trace_id' => '33333333-3333-4333-8333-333333333333',
        'correlation_id' => '44444444-4444-4444-8444-444444444444',
        'causation_id' => '55555555-5555-4555-8555-555555555555',
        'status' => 'GREEN',
        'score' => 91.5,
        'policy_version' => 'titan-assurance-v2.1',
    ],
]);
expect_true(($receipt['dispatched'] ?? false) === true, 'Live Signal sink must confirm dispatch.');
expect_same('11111111-1111-4111-8111-111111111111', $receipt['event_id'] ?? null, 'Signal receipt event id must be preserved.');
expect_same(1, count($manager->emitted), 'Signal manager must receive exactly one event.');
[$signalInput, $context] = $manager->emitted[0];
expect_same('assurance.assessment.completed', $signalInput['event_type'] ?? null, 'Signal event type must be preserved.');
expect_same(42, $signalInput['company_id'] ?? null, 'Signal emission must preserve tenant boundary.');
expect_same('assurance-assessment:abc', $signalInput['idempotency_key'] ?? null, 'Signal emission must preserve stable idempotency key.');
expect_same('governance', $signalInput['category'] ?? null, 'Assurance events must enter Signal as governance events.');
expect_same('tenant', $context->scope ?? null, 'Assurance Signal context must be tenant scoped.');
expect_same('titan-assurance', $context->actor->id ?? null, 'Assurance must emit as a system service actor, not impersonate the initiating human.');
