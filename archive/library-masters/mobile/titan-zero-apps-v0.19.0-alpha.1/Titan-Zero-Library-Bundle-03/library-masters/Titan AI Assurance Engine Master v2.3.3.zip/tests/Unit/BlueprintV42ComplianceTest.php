<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$installerPath = $root . '/extension.json';
$governancePath = $root . '/extension.manifest.json';

expect_true(is_file($governancePath), 'Blueprint v4.2 requires root extension.manifest.json.');
$installer = json_decode((string) file_get_contents($installerPath), true, 512, JSON_THROW_ON_ERROR);
expect_same('titan-extension-v1', $installer['schema'] ?? null, 'Installer manifest must target Titan Installer 1.7.8.');
expect_same('titan-assurance', $installer['slug'] ?? null, 'Installer slug must use canonical Titan Assurance identity.');
expect_same('ModelCouncil', $installer['folder'] ?? null, 'Legacy technical folder must remain ModelCouncil for upgrade compatibility.');

$manifest = json_decode((string) file_get_contents($governancePath), true, 512, JSON_THROW_ON_ERROR);
expect_same('2.2', $manifest['schema_version'] ?? null, 'Blueprint sidecar must use canonical Manifest v2.2.');
expect_same('titan-assurance', $manifest['key'] ?? null, 'Blueprint key must match canonical Assurance engine ownership registry.');
expect_same('governance-engine', $manifest['architecture']['profile'] ?? null, 'Assurance must use the governance-engine profile.');
expect_true(in_array('assurance', $manifest['authority']['owns'] ?? [], true), 'Assurance must explicitly own the assurance domain.');
expect_true(!in_array('risk', $manifest['authority']['owns'] ?? [], true), 'Assurance must not own Titan Risk.');
expect_true(!in_array('autonomy', $manifest['authority']['owns'] ?? [], true), 'Assurance must not own Titan Autonomy.');
expect_same('not-applicable', $manifest['governance']['assurance'] ?? null, 'Canonical Assurance engine must not depend on a second Assurance engine.');
expect_same('titan-autonomy', $manifest['governance']['effective_authority_source'] ?? null, 'Titan Autonomy remains effective authority source.');
expect_same(false, $manifest['offline']['can_increase_authority'] ?? null, 'Offline mode must never increase authority.');
