<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Contracts\AssuranceStreamingProviderTransport;
use App\Extensions\TitanAssurance\System\Exceptions\AssuranceProviderException;
use App\Extensions\TitanAssurance\System\Services\Assurance\Capabilities\ModelCapabilityRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\OpenAIAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\ProviderAdapterRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\StreamingProviderExecutionGateway;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\UsageNormalizer;

$registry = new ProviderAdapterRegistry([new OpenAIAdapter(new ModelCapabilityRegistry())]);
$transport = new class implements AssuranceStreamingProviderTransport {
    public int $status = 200;
    public array $lastRequest = [];

    public function stream(string $providerKey, string $modelId, array $request, callable $onChunk): array
    {
        $this->lastRequest = $request;
        $onChunk('hel');
        $onChunk('lo');

        return [
            'status' => $this->status,
            'body' => [
                'choices' => [['message' => ['content' => 'hello']]],
                'usage' => ['prompt_tokens' => 1, 'completion_tokens' => 1, 'total_tokens' => 2],
            ],
            'response_time_ms' => 5,
            'chunk_count' => 2,
        ];
    }

    public function streamMany(array $requests, callable $onChunk): array
    {
        $out = [];
        foreach ($requests as $key => $item) {
            $onChunk((string) $key, 'chunk-' . $key);
            $out[(string) $key] = [
                'status' => 200,
                'body' => ['choices' => [['message' => ['content' => 'text-' . $key]]]],
                'response_time_ms' => 7,
                'chunk_count' => 1,
            ];
        }
        return $out;
    }
};

$gateway = new StreamingProviderExecutionGateway($registry, $transport, new UsageNormalizer());
$chunks = [];
$result = $gateway->execute(
    'openai',
    'gpt-4.1',
    [['role' => 'user', 'content' => 'x']],
    ['temperature' => 0],
    function (string $chunk) use (&$chunks): void {
        $chunks[] = $chunk;
    }
);

expect_same('hello', $result['text'], 'Streaming gateway returns adapter-parsed final text.');
expect_same(['hel', 'lo'], $chunks, 'Streaming gateway forwards chunks.');
expect_same(2, $result['usage']['total_tokens'], 'Streaming gateway normalizes usage.');
expect_same(2, $result['chunk_count'], 'Streaming gateway preserves chunk count.');
expect_same('gpt-4.1', $transport->lastRequest['model'], 'Streaming gateway builds request through provider adapter.');

$transport->status = 429;
$thrown = false;
try {
    $gateway->execute('openai', 'gpt-4.1', [['role' => 'user', 'content' => 'x']], [], static function (): void {});
} catch (AssuranceProviderException $e) {
    $thrown = $e->errorClass === 'retryable' && $e->statusCode === 429;
}
expect_true($thrown, 'Streaming gateway classifies non-2xx responses through provider adapter.');


$batchChunks = [];
$batch = $gateway->executeMany([
    'a' => ['provider_key' => 'openai', 'model_id' => 'gpt-4.1', 'messages' => [['role' => 'user', 'content' => 'a']], 'options' => []],
    'b' => ['provider_key' => 'openai', 'model_id' => 'gpt-4.1-mini', 'messages' => [['role' => 'user', 'content' => 'b']], 'options' => []],
], function (string $key, string $chunk) use (&$batchChunks): void {
    $batchChunks[$key][] = $chunk;
});
expect_same('text-a', $batch['a']['text'], 'Batch streaming gateway parses first response.');
expect_same('text-b', $batch['b']['text'], 'Batch streaming gateway parses second response.');
expect_same(['chunk-a'], $batchChunks['a'], 'Batch streaming gateway keeps chunks keyed by request.');

$fallbackTransport = new class implements AssuranceStreamingProviderTransport {
    public function stream(string $providerKey, string $modelId, array $request, callable $onChunk): array
    {
        return [
            'status' => 200,
            'body' => ['choices' => [['message' => ['content' => 'fallback text']]]],
            'response_time_ms' => 3,
            'chunk_count' => 0,
        ];
    }

    public function streamMany(array $requests, callable $onChunk): array
    {
        $out = [];
        foreach ($requests as $key => $request) {
            $out[$key] = $this->stream($request['provider_key'], $request['model_id'], $request['request'], static function (): void {});
        }
        return $out;
    }
};
$fallbackGateway = new StreamingProviderExecutionGateway($registry, $fallbackTransport, new UsageNormalizer());
$fallbackChunks = [];
$fallbackGateway->execute('openai', 'gpt-4.1', [['role' => 'user', 'content' => 'x']], [], function (string $chunk) use (&$fallbackChunks): void {
    $fallbackChunks[] = $chunk;
});
expect_same(['fallback text'], $fallbackChunks, 'Gateway emits canonical text as one fallback chunk when transport supplies no chunks.');
