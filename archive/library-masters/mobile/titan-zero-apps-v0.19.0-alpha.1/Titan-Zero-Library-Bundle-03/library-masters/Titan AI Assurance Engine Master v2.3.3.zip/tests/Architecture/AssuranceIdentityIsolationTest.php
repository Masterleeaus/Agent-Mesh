<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$extension = json_decode((string) file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);
foreach ([$manifest, $extension] as $doc) {
    if (($doc['folder'] ?? null) !== 'TitanAssurance') throw new RuntimeException('Assurance folder identity is not isolated.');
    if (($doc['provider'] ?? null) !== 'App\\Extensions\\TitanAssurance\\System\\TitanAssuranceServiceProvider') throw new RuntimeException('Assurance provider identity is not isolated.');
}
$php = '';
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($it as $file) {
    if ($file->isFile() && $file->getExtension() === 'php') $php .= file_get_contents($file->getPathname());
}
if (str_contains($php, 'namespace App\\Extensions\\ModelCouncil') || str_contains($php, 'use App\\Extensions\\ModelCouncil')) {
    throw new RuntimeException('Legacy ModelCouncil runtime namespace remains in Assurance.');
}
if (! class_exists('stdClass')) throw new RuntimeException('sanity');
echo "Assurance identity isolation: PASS\n";
