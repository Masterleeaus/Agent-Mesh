<?php
require_once __DIR__ . '/../Support/bootstrap.php';

require_once __DIR__ . '/../Fixtures/TitanAutonomyContracts.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\TitanAutonomyAssuranceBridge;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\TitanAutonomyTenantAssuranceBridge;

expect_true(class_exists(TitanAutonomyAssuranceBridge::class), 'Autonomy live bridge must load against the v1.10 AssuranceBridge contract.');
expect_true(class_exists(TitanAutonomyTenantAssuranceBridge::class), 'Tenant Autonomy live bridge must load against the v1.10 tenant contract.');

$live = new ReflectionClass(TitanAutonomyAssuranceBridge::class);
$tenant = new ReflectionClass(TitanAutonomyTenantAssuranceBridge::class);
expect_true($live->implementsInterface('App\\Extensions\\TitanAutonomy\\System\\Contracts\\AssuranceBridgeContract'), 'Live bridge must implement the exact Autonomy AssuranceBridge contract.');
expect_true($tenant->implementsInterface('App\\Extensions\\TitanAutonomy\\System\\Contracts\\TenantAssuranceBridgeContract'), 'Tenant bridge must implement the exact Autonomy TenantAssuranceBridge contract.');
expect_same(3, $live->getMethod('evaluate')->getNumberOfParameters(), 'Autonomy evaluate signature must stay v1.10-compatible.');
expect_same(4, $tenant->getMethod('evaluateForTenant')->getNumberOfParameters(), 'Tenant evaluate signature must stay v1.10-compatible.');
