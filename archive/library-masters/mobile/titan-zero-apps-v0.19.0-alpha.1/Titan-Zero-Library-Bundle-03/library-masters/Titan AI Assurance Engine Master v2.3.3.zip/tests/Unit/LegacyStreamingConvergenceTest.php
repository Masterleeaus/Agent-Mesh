<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$source = file_get_contents($root . '/System/Services/ModelCouncilService.php') ?: '';
$provider = file_get_contents($root . '/System/ModelCouncilServiceProvider.php') ?: '';

expect_true(str_contains($source, 'StreamingProviderExecutionGateway'), 'ModelCouncil must use shared streaming gateway.');
expect_true(! str_contains($source, 'compatibility streaming: the legacy SSE/Guzzle path remains direct'), 'Legacy direct-stream compatibility marker must be removed.');
expect_true(! preg_match('/\busleep\s*\(/', $source), 'ModelCouncil web path must not sleep-poll.');
expect_true(! preg_match('/\bsleep\s*\(/', $source), 'ModelCouncil web path must not sleep-poll.');
expect_true(! str_contains($source, 'waitForSharedModelMessages'), 'Shared-message compatibility path must use one snapshot read rather than polling.');
expect_true(str_contains($source, 'loadSharedModelMessagesSnapshot'), 'Shared-message compatibility path must expose a snapshot loader.');
expect_true(str_contains($provider, 'AssuranceStreamingProviderTransport'), 'Service provider must bind streaming transport contract.');
expect_true(str_contains($provider, 'StreamingProviderExecutionGateway'), 'Service provider must register streaming gateway.');
expect_true(is_file($root . '/System/Services/Assurance/Providers/MagicAIHttpStreamingProviderTransport.php'), 'MagicAI streaming transport must exist.');
