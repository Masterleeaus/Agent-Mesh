<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\PermissionGateService;

$gate = new PermissionGateService();
$standard = $gate->evaluate([
    'mode' => 'standard', 'panel_valid' => true, 'evidence_locked' => true,
    'deterministic_passed' => true, 'material_disagreement' => false,
    'challenge_complete' => true, 'score' => 88,
]);
expect_same('permitted', $standard['permission_state'], 'Standard may permit only when all required checks pass.');

$high = $gate->evaluate([
    'mode' => 'high', 'panel_valid' => true, 'evidence_locked' => true,
    'deterministic_passed' => true, 'material_disagreement' => false,
    'challenge_complete' => true, 'score' => 95, 'human_approved' => false,
]);
expect_same('blocked', $high['permission_state'], 'High mode must stay blocked before human approval.');
expect_true($high['human_approval_required'], 'High mode must require human approval.');

$critical = $gate->evaluate([
    'mode' => 'critical', 'panel_valid' => true, 'evidence_locked' => true,
    'deterministic_passed' => true, 'material_disagreement' => false,
    'challenge_complete' => true, 'score' => 99, 'human_approved' => true,
]);
expect_same('permitted', $critical['permission_state'], 'Critical can permit only after human approval and all controls pass.');


$customGate = new PermissionGateService(['standard' => 90, 'high' => 92, 'critical' => 97]);
$custom = $customGate->evaluate([
    'mode' => 'standard', 'panel_valid' => true, 'evidence_locked' => true,
    'deterministic_passed' => true, 'material_disagreement' => false,
    'challenge_complete' => true, 'score' => 88,
]);
expect_same('blocked', $custom['permission_state'], 'Configured minimum assurance scores must be enforced.');
