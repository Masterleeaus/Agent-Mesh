<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$manifest = json_decode((string) file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);

expect_same('Titan Assurance Engine', $manifest['name'] ?? null, 'Installer 1.7.6 requires a non-empty host-facing name.');
expect_same('extension', $manifest['type'] ?? null, 'Installer 1.7.6 compatibility requires legacy type=extension.');
expect_true(is_string($manifest['description'] ?? null) && trim($manifest['description']) !== '', 'Installer 1.7.6 compatibility requires a non-empty description.');
expect_true(is_string($manifest['support_telegram'] ?? null) && trim($manifest['support_telegram']) !== '', 'Installer 1.7.6 compatibility requires a non-empty support_telegram value.');

expect_same('titan-extension-v1', $manifest['schema'] ?? null, 'Titan manifest schema must remain intact.');
expect_same('titan-assurance', $manifest['slug'] ?? null, 'Canonical Titan Assurance slug must remain intact.');
expect_same('ModelCouncil', $manifest['folder'] ?? null, 'Compatibility folder must remain ModelCouncil.');
