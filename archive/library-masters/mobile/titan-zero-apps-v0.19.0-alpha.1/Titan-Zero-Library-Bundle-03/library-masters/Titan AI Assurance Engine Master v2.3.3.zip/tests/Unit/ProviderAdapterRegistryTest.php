<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Capabilities\ModelCapabilityRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\AnthropicAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\DeepSeekAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\GeminiAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\OpenAIAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\OpenRouterAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\ProviderAdapterRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\XAIAdapter;

$capabilities = new ModelCapabilityRegistry();
$registry = new ProviderAdapterRegistry([
    new OpenAIAdapter($capabilities), new AnthropicAdapter($capabilities), new GeminiAdapter($capabilities),
    new DeepSeekAdapter($capabilities), new XAIAdapter($capabilities), new OpenRouterAdapter($capabilities),
]);

$adapter = $registry->for('openai', 'gpt-4.1');
expect_same('openai', $adapter->providerKey(), 'OpenAI adapter must resolve.');
$request = $adapter->buildRequest('gpt-4.1', [['role' => 'user', 'content' => 'Verify this']], ['temperature' => 0]);
expect_same('gpt-4.1', $request['model'], 'Request preserves model id.');
expect_same('retryable', $adapter->classifyRetry(['status' => 429]), '429 should be retryable.');
expect_same('authentication', $adapter->classifyRetry(['status' => 401]), '401 should be authentication failure.');
