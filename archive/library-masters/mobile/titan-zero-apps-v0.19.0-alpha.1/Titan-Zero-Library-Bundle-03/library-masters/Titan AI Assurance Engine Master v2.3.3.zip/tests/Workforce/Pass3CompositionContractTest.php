<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
require $root.'/System/Workforce/GuardrailDecisionComposer.php';
require $root.'/System/Workforce/EvidenceReceipt.php';
$desc=file_get_contents($root.'/System/Workforce/WorkforceIntegrationDescriptor.php');
preg_match('/namespace\s+([^;]+);/', $desc, $m);
$composerClass=$m[1].'\\GuardrailDecisionComposer';
$receiptClass=$m[1].'\\EvidenceReceipt';
$c=new $composerClass();
$stages=['authorization','governance','risk','assurance','autonomy'];
$d=[]; foreach($stages as $s){$d[$s]=['company_id'=>'c1','correlation_id'=>'x1','provider'=>$s,'provider_version'=>'1','decision'=>'allow'];}
if(($c->compose($d,'c1','x1')['decision']??null)!=='allow'){fwrite(STDERR,"compose allow failed\n");exit(1);}
unset($d['risk']); if(($c->compose($d,'c1','x1')['decision']??null)!=='deny'){fwrite(STDERR,"missing stage not denied\n");exit(1);}
$r=(new $receiptClass())->issue('r1','x1','c1','provider','1','cap','allow',[],['ev:1'],'2026-08-22T08:23:00+10:00');
if(!preg_match('/^[a-f0-9]{64}$/',$r['integrity_sha256']??'')){fwrite(STDERR,"receipt hash invalid\n");exit(1);}
$m=json_decode(file_get_contents($root.'/workforce-integration.json'),true,512,JSON_THROW_ON_ERROR);
if(($m['schema_version']??null)!=='1.2'||($m['cross_extension_composition']['missing_stage_behavior']??null)!=='deny'||($m['evidence_receipts']['raw_credentials_forbidden']??null)!==true){fwrite(STDERR,"manifest pass3 contract invalid\n");exit(1);}
echo "PASS3_WORKFORCE_COMPOSITION: PASS\n";
