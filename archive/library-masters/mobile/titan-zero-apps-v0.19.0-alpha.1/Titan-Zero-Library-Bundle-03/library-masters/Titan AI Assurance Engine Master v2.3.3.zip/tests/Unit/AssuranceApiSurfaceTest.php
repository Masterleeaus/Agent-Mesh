<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$controller = $root . '/System/Http/Controllers/AssuranceController.php';
expect_true(is_file($controller), 'AssuranceController must exist for the stable Titan assurance HTTP contract.');
$controllerSource = file_get_contents($controller) ?: '';
foreach (['createRun', 'lockEvidence', 'start', 'show', 'decision', 'cancel', 'recordOutcome', 'calibration'] as $method) {
    expect_true(str_contains($controllerSource, 'function ' . $method . '('), "AssuranceController missing {$method} endpoint method.");
}
$providerSource = file_get_contents($root . '/System/ModelCouncilServiceProvider.php') ?: '';
expect_true(str_contains($providerSource, 'registerAssuranceRoutes'), 'Service provider must register assurance routes independently of AIChatPro.');
expect_true(str_contains($providerSource, 'AssuranceController::class'), 'Service provider must route to AssuranceController.');

expect_true(str_contains($providerSource, "/runs/{runId}/outcomes"), 'Service provider must register outcome recording route.');
expect_true(str_contains($providerSource, "/calibration"), 'Service provider must register calibration route.');
