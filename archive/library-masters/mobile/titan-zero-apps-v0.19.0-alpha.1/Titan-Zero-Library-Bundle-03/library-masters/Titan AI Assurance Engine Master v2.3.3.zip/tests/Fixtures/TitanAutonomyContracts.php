<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

if (! interface_exists(AssuranceBridgeContract::class)) {
    interface AssuranceBridgeContract
    {
        public function evaluate(string $capability, ?string $workflowKey, array $context): array;
    }
}

if (! interface_exists(TenantAssuranceBridgeContract::class)) {
    interface TenantAssuranceBridgeContract
    {
        public function evaluateForTenant(int $companyId, string $capability, ?string $workflowKey, array $context): array;
    }
}
