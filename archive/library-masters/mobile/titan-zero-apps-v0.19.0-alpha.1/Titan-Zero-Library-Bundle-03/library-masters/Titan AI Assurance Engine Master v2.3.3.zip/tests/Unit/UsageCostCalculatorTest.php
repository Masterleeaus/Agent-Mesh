<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\ProviderPricingCatalogue;
use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\UsageCostCalculator;
use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\CostReconciler;

$catalogue = new ProviderPricingCatalogue([
    'version' => 'test-v1',
    'currency' => 'USD',
    'models' => [
        'openai:gpt-test' => [
            'input_per_million' => 2.0,
            'output_per_million' => 8.0,
            'cached_input_per_million' => 1.0,
        ],
    ],
    'provider_defaults' => [],
]);
$calculator = new UsageCostCalculator($catalogue);

$calc = $calculator->calculate('openai', 'gpt-test', [
    'input_tokens' => 1000000,
    'output_tokens' => 500000,
    'cached_input_tokens' => 0,
    'reported_cost' => null,
]);
expect_near(6.0, (float) $calc['calculated_cost'], 0.000001, 'Catalogue pricing calculates token cost.');
expect_near(6.0, (float) $calc['effective_cost'], 0.000001, 'Calculated cost is effective when provider does not report cost.');
expect_same('calculated', $calc['pricing_status'], 'Calculated cost reports its source.');
expect_same('test-v1', $calc['pricing_version'], 'Pricing version is attached.');

$reported = $calculator->calculate('openai', 'gpt-test', [
    'input_tokens' => 1,
    'output_tokens' => 1,
    'reported_cost' => 0.123,
]);
expect_near(0.123, (float) $reported['effective_cost'], 0.000001, 'Provider-reported cost takes precedence.');
expect_same('provider_reported', $reported['pricing_status'], 'Reported cost source is explicit.');

$unknown = $calculator->calculate('openai', 'unknown', [
    'input_tokens' => 10,
    'output_tokens' => 5,
    'reported_cost' => null,
]);
expect_same(null, $unknown['effective_cost'], 'Unknown pricing must not fabricate cost.');
expect_same('pricing_unknown', $unknown['pricing_status'], 'Unknown pricing is explicit.');

$reconciler = new CostReconciler();
$summary = $reconciler->reconcile([
    ['cost' => 0.2],
    ['cost' => null],
    ['cost' => 0.3],
]);
expect_near(0.5, $summary['actual_cost'], 0.000001, 'Known candidate cost is summed.');
expect_same(2, $summary['known_cost_count'], 'Known cost count is reported.');
expect_same(1, $summary['unknown_cost_count'], 'Unknown cost count is reported.');
expect_true(! $summary['complete'], 'Accounting is incomplete when any candidate cost is unknown.');
