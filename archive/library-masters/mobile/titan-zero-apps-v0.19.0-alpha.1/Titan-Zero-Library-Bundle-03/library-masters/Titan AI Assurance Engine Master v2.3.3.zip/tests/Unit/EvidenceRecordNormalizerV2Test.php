<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\EvidenceRecordNormalizer;

$service = new EvidenceRecordNormalizer();
$now = new DateTimeImmutable('2026-08-11T08:00:00+00:00');
$record = $service->normalize([
    'evidence_type' => 'crm_record',
    'subject' => ['type' => 'job', 'id' => 'J-1'],
    'source' => 'crm',
    'captured_at' => '2026-08-11T07:00:00+00:00',
    'max_age_seconds' => 7200,
    'confidence' => 90,
    'authority' => 'authoritative',
    'relevance' => 80,
    'applicability' => 1,
    'provenance' => ['confidence' => 95],
    'verification_state' => 'verified',
], $now);

expect_same('crm_record', $record['evidence_type'], 'Evidence type must be preserved.');
expect_near(0.5, $record['freshness'], 0.000001, 'Freshness must decay deterministically from max age.');
expect_near(1.0, $record['authority'], 0.000001, 'Authoritative evidence must receive full authority factor.');
expect_near(0.95, $record['provenance_confidence'], 0.000001, 'Provenance confidence must normalize percentage values.');
expect_true(strlen($record['hash']) === 64, 'Evidence hash must be canonical SHA-256.');

$contradictory = $service->normalize([
    'evidence_type' => 'photo',
    'subject' => 'job:J-1',
    'source' => 'titan_vision',
    'contradicts' => ['11111111-1111-4111-8111-111111111111'],
], $now);
expect_near(0.5, $contradictory['contradiction_adjustment'], 0.000001, 'Contradictory evidence must be downweighted by default.');
