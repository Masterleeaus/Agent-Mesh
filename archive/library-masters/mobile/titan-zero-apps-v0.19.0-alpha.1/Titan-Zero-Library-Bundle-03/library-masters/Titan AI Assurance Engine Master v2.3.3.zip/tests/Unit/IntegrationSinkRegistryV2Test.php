<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Contracts\AssuranceIntegrationSink;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\IntegrationSinkRegistry;

$sink = new class implements AssuranceIntegrationSink {
    public array $received = [];
    public function destinationKey(): string { return 'titan_signal'; }
    public function publish(array $envelope): array { $this->received[] = $envelope; return ['receipt_id' => 'r-1']; }
};
$registry = new IntegrationSinkRegistry([$sink]);
$receipts = $registry->dispatch(['titan_signal', 'titan_rewind'], 'assurance.assessment.completed', ['trace_id' => 't'], 'idem-1');
expect_true(($receipts['titan_signal']['dispatched'] ?? false) === true, 'Registered integration sink must dispatch.');
expect_same('r-1', $receipts['titan_signal']['receipt_id'] ?? null, 'Sink receipt must be preserved.');
expect_true(($receipts['titan_rewind']['available'] ?? true) === false, 'Unavailable integrations must be explicit rather than silently claimed.');
expect_same('idem-1', $sink->received[0]['idempotency_key'] ?? null, 'Integration envelope must carry idempotency key.');
