<?php

declare(strict_types=1);

$tests = glob(__DIR__ . '/Unit/*Test.php') ?: [];
sort($tests);
$failures = 0;
foreach ($tests as $test) {
    $name = basename($test);
    $command = escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($test) . ' 2>&1';
    exec($command, $output, $code);
    if ($code === 0) {
        echo "PASS {$name}\n";
    } else {
        $failures++;
        echo "FAIL {$name}\n" . implode("\n", $output) . "\n";
    }
    $output = [];
}
exit($failures === 0 ? 0 : 1);
