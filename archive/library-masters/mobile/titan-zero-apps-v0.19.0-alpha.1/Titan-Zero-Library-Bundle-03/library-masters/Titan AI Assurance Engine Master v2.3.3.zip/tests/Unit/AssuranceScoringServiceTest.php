<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\AssuranceScoringService;
use App\Extensions\TitanAssurance\System\Services\Assurance\DisagreementAnalyzer;

$scoring = new AssuranceScoringService();
$weakEvidence = $scoring->score([
    'agreement' => 95, 'independence' => 95, 'evidence' => 20,
    'deterministic' => 100, 'challenge' => 80, 'disagreement_penalty' => 0,
]);
expect_true($weakEvidence['score'] < 80, 'Poor evidence must prevent a fully assured score despite model agreement.');

$analyzer = new DisagreementAnalyzer();
$disagreement = $analyzer->analyze([
    ['structured_response' => ['answer' => 'approve', 'risks' => ['low']]],
    ['structured_response' => ['answer' => 'reject', 'risks' => ['high']]],
]);
expect_true($disagreement['material'], 'Opposite recommendations must be material disagreement.');
expect_true($disagreement['score'] >= 50, 'Material answer disagreement must have meaningful severity.');
