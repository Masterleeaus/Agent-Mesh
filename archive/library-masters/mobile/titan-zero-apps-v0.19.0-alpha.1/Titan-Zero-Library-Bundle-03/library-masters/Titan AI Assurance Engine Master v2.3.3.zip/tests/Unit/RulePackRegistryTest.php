<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\DeterministicValidationPipeline;
use App\Extensions\TitanAssurance\System\Services\Assurance\StructuredResponseValidator;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\RulePackRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\FieldHomeServicesRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\EcommerceRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\PropertyHospitalityRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\FitnessWellnessRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\SalonBeautyRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\AutomotiveRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\FacilitiesRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\BookingHireRulePack;

$registry = new RulePackRegistry([
    new FieldHomeServicesRulePack(),
    new EcommerceRulePack(),
    new PropertyHospitalityRulePack(),
    new FitnessWellnessRulePack(),
    new SalonBeautyRulePack(),
    new AutomotiveRulePack(),
    new FacilitiesRulePack(),
    new BookingHireRulePack(),
]);

$expected = [
    'field_home_services.v1', 'ecommerce.v1', 'property_hospitality.v1',
    'fitness_wellness.v1', 'salon_beauty.v1', 'automotive.v1',
    'facilities.v1', 'booking_hire.v1',
];
foreach ($expected as $key) {
    expect_true(in_array($key, $registry->keys(), true), "Rule pack {$key} is registered.");
    expect_same('1.0.0', $registry->resolve($key)->version(), "Rule pack {$key} version is explicit.");
}

$rules = $registry->resolve('field_home_services.v1')->rules();
expect_true(isset($rules['numeric_thresholds']), 'Rule pack exposes response numeric constraints.');
expect_true(isset($rules['context_numeric_thresholds']['quote_amount']), 'Field/home services pack validates quote amounts when supplied.');
expect_true(isset($rules['context_date_orderings']), 'Field/home services pack exposes date ordering rules.');

$pipeline = new DeterministicValidationPipeline(new StructuredResponseValidator());
$response = [
    'answer' => 'Proceed',
    'confidence' => 0.9,
    'claims' => [['claim' => 'Job is viable', 'evidence_ids' => ['e1']]],
    'evidence' => [['id' => 'e1', 'source' => 'crm']],
    'risks' => [],
    'assumptions' => [],
];
$valid = $pipeline->validateCandidateWithPack($response, $registry->resolve('field_home_services.v1'), [
    'quote_amount' => 120,
    'scheduled_start_at' => '2026-08-10T09:00:00+10:00',
    'scheduled_end_at' => '2026-08-10T11:00:00+10:00',
]);
expect_same('passed', $valid['status'], 'Valid field-service context passes pack validation.');
expect_same('field_home_services.v1', $valid['rule_pack_key'], 'Validation result records rule pack key.');

$invalid = $pipeline->validateCandidateWithPack($response, $registry->resolve('field_home_services.v1'), [
    'quote_amount' => -1,
    'scheduled_start_at' => '2026-08-10T12:00:00+10:00',
    'scheduled_end_at' => '2026-08-10T11:00:00+10:00',
]);
expect_true($invalid['hard_failures'] >= 2, 'Negative money and reversed dates fail deterministically.');
