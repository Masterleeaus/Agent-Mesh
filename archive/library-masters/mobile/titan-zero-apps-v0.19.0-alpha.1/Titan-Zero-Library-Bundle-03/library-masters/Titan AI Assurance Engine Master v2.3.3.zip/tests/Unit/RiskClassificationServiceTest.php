<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\RiskClassificationService;

$service = new RiskClassificationService();
$risk = $service->classify([], [
    'safety_critical' => true,
    'named_approver_ids' => [7, '9', 9],
]);
expect_same('critical', $risk['risk_level'], 'Safety-critical decision must classify as critical.');
expect_same([7, 9], $risk['named_approver_ids'], 'Named approver ids must survive risk classification in normalized form.');
