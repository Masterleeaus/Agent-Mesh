<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\KnowledgeReferenceValidator;

$validator = new KnowledgeReferenceValidator();
$ref = $validator->normalize([
    'guide_id' => 'worksafe-vic-electrical',
    'version' => '2026-08-01',
    'hash' => str_repeat('b', 64),
    'section' => '4.2',
    'jurisdiction' => 'au-vic',
    'authority' => 'WorkSafe Victoria',
    'applicable_exception' => 'none',
]);
expect_same('AU-VIC', $ref['jurisdiction'], 'Jurisdiction must normalize for exact Knowledge Authority reference matching.');
expect_same(str_repeat('b', 64), $ref['hash'], 'Exact knowledge hash must be preserved.');

$failed = false;
try {
    $validator->normalize(['guide_id' => 'x']);
} catch (DomainException) {
    $failed = true;
}
expect_true($failed, 'Incomplete knowledge references must fail closed.');
