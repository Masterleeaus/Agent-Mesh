<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Contracts\ComplianceRuleSource;
use App\Extensions\TitanAssurance\System\Services\Assurance\Compliance\ComplianceRuleDocumentValidator;
use App\Extensions\TitanAssurance\System\Services\Assurance\Compliance\ComplianceRulePackResolver;
use App\Extensions\TitanAssurance\System\Services\Assurance\Compliance\ComplianceRuleSourceRegistry;

$validator = new ComplianceRuleDocumentValidator();
$source = new class($validator) implements ComplianceRuleSource {
    public string|int|null $lastCompanyId = null;
    public function __construct(private ComplianceRuleDocumentValidator $validator) {}
    public function sourceKey(): string { return 'feed'; }
    public function fetch(string|int $companyId, string $rulePackKey, string $jurisdiction, array $context = []): array
    {
        $this->lastCompanyId = $companyId;
        $doc = [
            'source_key' => 'feed',
            'rule_pack_key' => $rulePackKey,
            'jurisdiction' => $jurisdiction,
            'version' => '1.0.0',
            'effective_from' => '2026-01-01',
            'rules' => [['id' => 'amount', 'operator' => 'non_negative', 'field' => 'amount']],
            'provenance' => ['publisher' => 'source'],
        ];
        $doc['content_hash'] = $this->validator->contentHash($doc);
        return $doc;
    }
};

$resolver = new ComplianceRulePackResolver(new ComplianceRuleSourceRegistry([$source]), $validator);
$pack = $resolver->resolve(77, 'feed', 'field-home', 'AU-VIC', '2026-08-09');
expect_same(77, $source->lastCompanyId, 'Resolver passes trusted company context to source.');
expect_same('field-home', $pack->key(), 'Resolver returns requested validated rule pack.');
expect_same('1.0.0', $pack->version(), 'Resolver preserves source version.');

$badSource = new class($validator) implements ComplianceRuleSource {
    public function __construct(private ComplianceRuleDocumentValidator $validator) {}
    public function sourceKey(): string { return 'bad'; }
    public function fetch(string|int $companyId, string $rulePackKey, string $jurisdiction, array $context = []): array
    {
        $doc = [
            'source_key' => 'different-source',
            'rule_pack_key' => $rulePackKey,
            'jurisdiction' => $jurisdiction,
            'version' => '1',
            'effective_from' => '2026-01-01',
            'rules' => [],
        ];
        $doc['content_hash'] = $this->validator->contentHash($doc);
        return $doc;
    }
};
$badResolver = new ComplianceRulePackResolver(new ComplianceRuleSourceRegistry([$badSource]), $validator);
$thrown = false;
try {
    $badResolver->resolve(77, 'bad', 'field-home', 'AU-VIC', '2026-08-09');
} catch (DomainException $e) {
    $thrown = str_contains($e->getMessage(), 'source');
}
expect_true($thrown, 'Resolver rejects source identity mismatch.');
