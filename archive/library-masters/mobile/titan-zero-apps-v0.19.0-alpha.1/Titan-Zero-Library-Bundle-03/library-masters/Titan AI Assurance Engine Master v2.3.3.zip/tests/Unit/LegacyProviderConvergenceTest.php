<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$source = file_get_contents($root . '/System/Services/ModelCouncilService.php') ?: '';
expect_true(str_contains($source, 'ProviderExecutionGateway'), 'Legacy ModelCouncil must reference the shared provider execution gateway.');
expect_true(str_contains($source, 'ProviderAdapterRegistry'), 'Legacy ModelCouncil parallel path must reuse assurance provider adapters.');
expect_true(str_contains($source, 'MagicAIProviderRequestFactory'), 'Legacy ModelCouncil parallel path must reuse the shared endpoint/credential request factory.');
expect_true(str_contains($source, 'providerKeyForModel'), 'Legacy ModelCouncil must map MagicAI model engines to assurance provider keys.');
expect_true(str_contains($source, 'StreamingProviderExecutionGateway'), 'Legacy ModelCouncil SSE path must reuse the shared streaming gateway.');
expect_true(str_contains($source, '$this->providerGateway->execute'), 'Legacy non-streaming calls must execute through the shared gateway when available.');
expect_true(str_contains($source, '$this->streamingProviderGateway->executeMany'), 'Legacy streaming calls must execute through the shared streaming gateway when available.');
