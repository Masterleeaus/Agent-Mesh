<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\ModelCouncil\\';
    if (! str_starts_with($class, $prefix)) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) {
        require_once $path;
    }
});

function expect_true(bool $condition, string $message): void
{
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

function expect_same(mixed $expected, mixed $actual, string $message): void
{
    if ($expected !== $actual) {
        throw new RuntimeException($message . ' expected=' . var_export($expected, true) . ' actual=' . var_export($actual, true));
    }
}

function expect_near(float $expected, float $actual, float $epsilon, string $message): void
{
    if (abs($expected - $actual) > $epsilon) {
        throw new RuntimeException($message . " expected={$expected} actual={$actual}");
    }
}


if (! function_exists('config')) {
    function config(string $key, mixed $default = null): mixed
    {
        return $default;
    }
}
