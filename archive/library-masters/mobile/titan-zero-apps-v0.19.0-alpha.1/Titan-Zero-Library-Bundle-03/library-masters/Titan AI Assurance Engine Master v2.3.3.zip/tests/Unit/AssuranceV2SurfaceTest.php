<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$provider = file_get_contents($root . '/System/ModelCouncilServiceProvider.php') ?: '';
$v2Engine = file_get_contents($root . '/System/Services/Assurance/EvidenceAssuranceEngineService.php') ?: '';
$migration = file_get_contents($root . '/database/migrations/2026_08_11_000015_create_assurance_evidence_core_tables.php') ?: '';
$capabilities = json_decode(file_get_contents($root . '/titan-capabilities.json') ?: '{}', true);
$legacyEngine = file_get_contents($root . '/System/Services/Assurance/AssuranceEngineService.php') ?: '';

expect_true(str_contains($provider, "'/assessments'"), 'v2 evidence assessment endpoint must be registered.');
expect_true(str_contains($provider, "'/assessments/{assessmentId}/feedback'"), 'v2 feedback endpoint must be registered.');
expect_true(str_contains($provider, 'EvidenceAssuranceEngine::class'), 'v2 evidence engine contract must be bound.');
expect_true(str_contains($migration, 'assurance_assessments'), 'v2 assessment table must be created.');
expect_true(str_contains($migration, 'assurance_evidence_records'), 'v2 evidence registry table must be created.');
expect_true(str_contains($migration, 'assurance_feedback'), 'v2 calibration feedback table must be created.');
foreach (['trace_id', 'correlation_id', 'causation_id', 'company_id'] as $field) {
    expect_true(str_contains($migration, $field), "v2 trace surface must include {$field}.");
}
expect_true(! str_contains($v2Engine, 'RiskClassificationService'), 'Canonical v2 assurance must not classify risk.');
expect_true(! str_contains($v2Engine, 'PermissionGateService'), 'Canonical v2 assurance must not grant execution permission.');
expect_true(! str_contains($v2Engine, 'ProviderExecutionGateway'), 'Canonical v2 assurance must not own Model Council provider execution.');
expect_true(str_contains($v2Engine, "'authority_decision' => null"), 'v2 result must explicitly avoid autonomy authority decisions.');
expect_true(str_contains($legacyEngine, "'source' => 'titan_risk_engine'"), 'Legacy path must accept Titan Risk context.');
expect_true(str_contains($legacyEngine, "legacy_assurance_fallback"), 'Legacy risk classification must be marked as compatibility fallback.');
expect_true(count($capabilities['capabilities'] ?? []) >= 3, 'Every v2 capability must be declared in the capability manifest.');
