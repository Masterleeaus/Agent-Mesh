<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$manifest = json_decode(file_get_contents($root . '/extension.json') ?: '{}', true);
expect_same('2.3.0', $manifest['version'] ?? null, 'Extension version must be v2.3.0.');
$config = file_get_contents($root . '/config/model-council.php') ?: '';
expect_true(str_contains($config, "'policy_version' => 'titan-assurance-v2.1'"), 'Policy version must advance to v2.1.');
expect_true(str_contains($config, "'vertical_rule_packs'"), 'v1.9 config must retain vertical rule-pack mapping.');
expect_true(str_contains($config, "'pricing'"), 'v1.9 config must retain pricing catalogue configuration.');
