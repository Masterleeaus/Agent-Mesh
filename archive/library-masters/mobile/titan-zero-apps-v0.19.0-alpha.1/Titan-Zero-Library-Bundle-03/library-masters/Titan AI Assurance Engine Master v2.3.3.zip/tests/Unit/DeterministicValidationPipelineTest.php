<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\DeterministicValidationPipeline;
use App\Extensions\TitanAssurance\System\Services\Assurance\StructuredResponseValidator;

$pipeline = new DeterministicValidationPipeline(new StructuredResponseValidator());

$result = $pipeline->validateCandidate([
    'answer' => 'Proceed',
    'confidence' => 0.8,
    'claims' => [['claim' => 'Safe', 'evidence_ids' => []]],
    'evidence' => [],
    'risks' => [],
    'assumptions' => [],
], ['require_evidence_for_claims' => true]);
expect_same('failed', $result['status'], 'Evidence-less claims must fail when evidence is required.');
expect_true($result['hard_failures'] >= 1, 'Hard validation failure expected.');

$valid = $pipeline->validateCandidate([
    'answer' => 'Proceed', 'confidence' => 0.8,
    'claims' => [['claim' => 'Safe', 'evidence_ids' => ['ev-1']]],
    'evidence' => [['id' => 'ev-1', 'source' => 'crm:inspection:4']],
    'risks' => [], 'assumptions' => [],
], ['require_evidence_for_claims' => true]);
expect_same('passed', $valid['status'], 'Referenced evidence should pass structural validation.');


$malformed = $pipeline->validateCandidate([
    'answer' => 'not-json', 'confidence' => null,
    'claims' => [], 'evidence' => [], 'risks' => [], 'assumptions' => [],
    '_parse_error' => 'provider_response_was_not_valid_json',
], []);
expect_same('failed', $malformed['status'], 'Malformed provider JSON must fail deterministic validation.');
