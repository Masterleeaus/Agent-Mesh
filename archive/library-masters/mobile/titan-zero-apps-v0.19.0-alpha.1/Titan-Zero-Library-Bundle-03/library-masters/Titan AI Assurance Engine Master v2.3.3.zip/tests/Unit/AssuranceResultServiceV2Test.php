<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\AssuranceResultService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\EvidenceWeightingService;

$service = new AssuranceResultService(new EvidenceWeightingService(), 80, 60, 0.4);
$strong = [[
    'evidence_id' => '11111111-1111-4111-8111-111111111111',
    'evidence_type' => 'crm_record',
    'source' => 'crm',
    'authority' => 1.0,
    'relevance' => 1.0,
    'freshness' => 1.0,
    'applicability' => 1.0,
    'provenance_confidence' => 0.95,
    'contradiction_adjustment' => 1.0,
    'hash' => str_repeat('a', 64),
    'verification_state' => 'verified',
    'subject' => 'job:1',
    'contradicts' => [],
]];
$result = $service->evaluate($strong, [['key' => 'job_record', 'evidence_type' => 'crm_record']], 1.0, 'test-policy');
expect_same('GREEN', $result['status'], 'Strong complete evidence must be GREEN.');
expect_near(95.0, $result['score'], 0.000001, 'Strong evidence score must reflect evidence weight.');

$missing = $service->evaluate($strong, [['key' => 'safety_certificate', 'evidence_type' => 'certificate', 'critical' => true]], 1.0, 'test-policy');
expect_same('RED', $missing['status'], 'Missing critical required evidence must force RED.');
expect_true(in_array('MISSING_REQUIRED_EVIDENCE', $missing['reason_codes'], true), 'Missing evidence reason code must be explicit.');

$calibrated = $service->evaluate($strong, [], 0.7, 'test-policy');
expect_same('AMBER', $calibrated['status'], 'Calibration downweighting must reduce overconfident GREEN results.');
expect_true(in_array('CALIBRATION_DOWNWEIGHTED', $calibrated['reason_codes'], true), 'Calibration reason code must be explicit.');
