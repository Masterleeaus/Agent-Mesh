<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Calibration\MiscalibrationDetector;

$detector = new MiscalibrationDetector(5, 0.30, 0.50);
$samples = [
    ['status' => 'GREEN', 'accepted' => false],
    ['status' => 'GREEN', 'accepted' => false],
    ['status' => 'GREEN', 'accepted' => true],
    ['status' => 'GREEN', 'accepted' => true],
    ['status' => 'GREEN', 'accepted' => true],
];
$result = $detector->detect($samples);
expect_true($result['detected'] === true, 'Repeated downstream rejection of GREEN must trigger miscalibration.');
expect_near(0.4, $result['green_rejection_rate'], 0.000001, 'Miscalibration rejection rate must be measured.');
expect_true($result['calibration_factor'] < 1.0, 'Detected miscalibration must lower future calibration factor.');
expect_true($result['policy_mutation'] === false, 'Miscalibration must not directly mutate policy.');
