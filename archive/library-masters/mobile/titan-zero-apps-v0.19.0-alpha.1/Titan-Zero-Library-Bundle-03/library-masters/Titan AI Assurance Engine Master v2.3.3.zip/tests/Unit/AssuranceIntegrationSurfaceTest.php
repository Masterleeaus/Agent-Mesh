<?php
require_once __DIR__ . '/../Support/bootstrap.php';

$root = dirname(__DIR__, 2);
$candidate = file_get_contents($root . '/System/Services/Assurance/CandidateExecutionService.php') ?: '';
foreach (['normalized_usage', 'pricing_version', 'effective_cost'] as $needle) {
    expect_true(str_contains($candidate, $needle), "Candidate execution must persist {$needle}.");
}

$engine = file_get_contents($root . '/System/Services/Assurance/AssuranceEngineService.php') ?: '';
expect_true(str_contains($engine, 'EvidenceSourceRegistry'), 'Assurance engine must resolve registered evidence sources.');
expect_true(str_contains($engine, 'rule_pack_key'), 'Assurance engine must persist selected rule pack.');
expect_true(str_contains($engine, 'evidence_source_summary'), 'Assurance engine must persist evidence source summary.');

$evaluator = file_get_contents($root . '/System/Services/Assurance/AssuranceRunEvaluator.php') ?: '';
expect_true(str_contains($evaluator, 'RulePackRegistry'), 'Evaluator must resolve the run rule pack.');
expect_true(str_contains($evaluator, 'validateCandidateWithPack'), 'Evaluator must execute deterministic rule packs.');
expect_true(str_contains($evaluator, "'effective_cost' => \$candidate->effective_cost"), 'Evaluator cost reconciliation must retain effective candidate cost.');

$provider = file_get_contents($root . '/System/ModelCouncilServiceProvider.php') ?: '';
expect_true(str_contains($provider, "tagged('titan.assurance.evidence_sources')"), 'Host evidence adapters must be discoverable through a container tag.');
