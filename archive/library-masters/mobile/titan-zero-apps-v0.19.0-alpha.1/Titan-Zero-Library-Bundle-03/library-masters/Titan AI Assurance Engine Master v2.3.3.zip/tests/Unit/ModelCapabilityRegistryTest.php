<?php
require_once __DIR__ . '/../Support/bootstrap.php';

use App\Extensions\TitanAssurance\System\Services\Assurance\Capabilities\ModelCapabilityRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Capabilities\ModelIdentityResolver;

$registry = new ModelCapabilityRegistry();
$resolver = new ModelIdentityResolver($registry);

$openai = $resolver->resolve('openai', 'gpt-4.1');
expect_same('openai', $openai['provider'], 'OpenAI provider must normalize.');
expect_same('gpt-4', $openai['family'], 'GPT-4.1 must map to gpt-4 family.');
expect_true($openai['capabilities']['structured_output'], 'OpenAI structured output capability expected.');

$anthropic = $resolver->resolve('anthropic', 'claude-sonnet-4-20250514');
expect_same('claude-sonnet', $anthropic['family'], 'Claude Sonnet family must normalize.');

$unknown = $resolver->resolve('custom-provider', 'mystery-model-v9');
expect_same('custom-provider:mystery-model-v9', $unknown['family'], 'Unknown models need conservative unique fallback family.');


$proxied = $resolver->resolve('openrouter', 'anthropic/claude-3.7-sonnet');
expect_same('claude-sonnet', $proxied['family'], 'OpenRouter proxy must preserve underlying model family for independence scoring.');
$proxiedOpenAI = $resolver->resolve('openrouter', 'openai/gpt-4.1');
expect_same('gpt-4', $proxiedOpenAI['family'], 'OpenRouter OpenAI proxy must not count as an independent model family.');


expect_same('deepseek', $registry->normalizeProvider('deep_seek'), 'MagicAI DEEP_SEEK provider key must normalize.');
expect_same('xai', $registry->normalizeProvider('x_ai'), 'MagicAI X_AI provider key must normalize.');
expect_same('openrouter', $registry->normalizeProvider('open_router'), 'MagicAI OPEN_ROUTER provider key must normalize.');
