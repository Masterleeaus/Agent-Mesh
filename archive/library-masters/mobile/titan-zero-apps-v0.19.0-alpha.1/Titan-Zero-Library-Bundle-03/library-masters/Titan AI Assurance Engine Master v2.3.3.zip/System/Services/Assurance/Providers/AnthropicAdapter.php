<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Providers;

final class AnthropicAdapter extends AbstractProviderAdapter
{
    public function providerKey(): string
    {
        return 'anthropic';
    }

    public function buildRequest(string $modelId, array $messages, array $options = []): array
    {
        $system = null;
        $normalized = [];
        foreach ($messages as $message) {
            $role = (string) ($message['role'] ?? 'user');
            $content = $this->stringContent($message['content'] ?? '');
            if ($role === 'system') {
                $system = trim(($system ? $system . "\n\n" : '') . $content);
                continue;
            }
            $normalized[] = ['role' => $role === 'assistant' ? 'assistant' : 'user', 'content' => $content];
        }

        $request = [
            'model' => $modelId,
            'max_tokens' => max(256, (int) ($options['max_tokens'] ?? 2048)),
            'messages' => $normalized,
        ];
        if ($system !== null && $system !== '') {
            $request['system'] = $system;
        }
        if (array_key_exists('temperature', $options)) {
            $request['temperature'] = $options['temperature'];
        }
        return $request;
    }

    public function parseResponse(mixed $response): array
    {
        $body = is_array($response) ? $response : [];
        return [
            'text' => (string) ($body['content'][0]['text'] ?? ''),
            'usage' => (array) ($body['usage'] ?? []),
            'raw' => $response,
        ];
    }

    private function stringContent(mixed $content): string
    {
        return is_string($content) ? $content : (json_encode($content, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '');
    }
}
