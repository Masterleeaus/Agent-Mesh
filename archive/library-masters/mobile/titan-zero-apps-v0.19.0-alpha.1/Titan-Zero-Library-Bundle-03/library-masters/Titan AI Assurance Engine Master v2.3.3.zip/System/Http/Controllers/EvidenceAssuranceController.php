<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Http\Controllers;

use App\Extensions\TitanAssurance\System\Contracts\EvidenceAssuranceEngine;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class EvidenceAssuranceController extends Controller
{
    public function __construct(private readonly EvidenceAssuranceEngine $engine)
    {
    }

    public function assess(Request $request): JsonResponse
    {
        try {
            return response()->json($this->engine->assess($request->all())->toArray(), 201);
        } catch (DomainException $exception) {
            return response()->json(['message' => $exception->getMessage()], 422);
        }
    }

    public function show(int $assessmentId): JsonResponse
    {
        return response()->json($this->engine->findAssessment($assessmentId)->toArray());
    }

    public function feedback(Request $request, int $assessmentId): JsonResponse
    {
        try {
            return response()->json($this->engine->recordFeedback($assessmentId, $request->all())->toArray(), 201);
        } catch (DomainException $exception) {
            return response()->json(['message' => $exception->getMessage()], 422);
        }
    }
}
