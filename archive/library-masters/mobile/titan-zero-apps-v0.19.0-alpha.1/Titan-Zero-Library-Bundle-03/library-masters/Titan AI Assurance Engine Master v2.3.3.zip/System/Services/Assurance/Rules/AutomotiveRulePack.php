<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Rules;

final class AutomotiveRulePack extends CoreRulePack
{
    public function key(): string { return 'automotive.v1'; }

    protected function contextNumericThresholds(): array
    {
        return [
            'estimate_amount' => ['min' => 0],
            'odometer_km' => ['min' => 0],
            'labour_hours' => ['min' => 0],
            'parts_quantity' => ['min' => 0],
        ];
    }
}
