<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AssuranceOutcome extends Model
{
    protected $table = 'assurance_outcomes';

    protected $guarded = ['id', 'company_id', 'assurance_run_id', 'recorded_by', 'created_at', 'updated_at'];

    protected $casts = [
        'success' => 'boolean',
        'impact' => 'array',
        'correction' => 'array',
    ];

    public function run(): BelongsTo
    {
        return $this->belongsTo(AssuranceRun::class, 'assurance_run_id');
    }
}
