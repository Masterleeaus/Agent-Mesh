<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

final class AssuranceScoringService
{
    private const WEIGHTS = [
        'agreement' => 0.15,
        'independence' => 0.20,
        'evidence' => 0.30,
        'deterministic' => 0.20,
        'challenge' => 0.15,
    ];

    public function __construct(private readonly array $weights = self::WEIGHTS)
    {
    }

    public function score(array $components): array
    {
        $weighted = 0.0;
        $normalized = [];
        foreach ($this->weights as $key => $weight) {
            $value = $this->clamp((float) ($components[$key] ?? 0));
            $normalized[$key] = $value;
            $weighted += $value * (float) $weight;
        }

        $penalty = $this->clamp((float) ($components['disagreement_penalty'] ?? 0));
        $score = max(0.0, $weighted - ($penalty * 0.35));

        // Evidence is a hard quality ceiling: consensus without evidence cannot masquerade as assurance.
        $evidenceCeiling = 60.0 + ($normalized['evidence'] * 0.40);
        $score = min($score, $evidenceCeiling);

        return [
            'score' => round($score, 2),
            'components' => $normalized + ['disagreement_penalty' => $penalty],
            'evidence_ceiling' => round($evidenceCeiling, 2),
        ];
    }

    private function clamp(float $value): float
    {
        return max(0.0, min(100.0, $value));
    }
}
