<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Jobs;

use App\Extensions\TitanAssurance\System\Models\AssuranceCandidate;
use App\Extensions\TitanAssurance\System\Services\Assurance\CandidateExecutionService;
use App\Extensions\TitanAssurance\System\Support\AssuranceCandidateStatus;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Throwable;

class ExecuteAssuranceCandidate implements ShouldQueue
{
    public bool $afterCommit = true;

    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;

    public function __construct(
        public readonly int $candidateId,
        public readonly string $companyId,
    ) {
    }

    public function backoff(): array
    {
        return (array) config('model-council.assurance.retry_backoff_seconds', [10, 30, 90]);
    }

    public function handle(CandidateExecutionService $execution): void
    {
        $candidate = $execution->execute($this->candidateId, $this->companyId);
        EvaluateAssuranceRun::dispatch((int) $candidate->assurance_run_id, $this->companyId)
            ->onQueue((string) config('model-council.assurance.queue', 'assurance'));
    }

    public function failed(?Throwable $exception): void
    {
        /** @var AssuranceCandidate|null $candidate */
        $candidate = AssuranceCandidate::query()
            ->where('company_id', $this->companyId)
            ->whereKey($this->candidateId)
            ->first();
        if (! $candidate || in_array((string) $candidate->status, AssuranceCandidateStatus::terminal(), true)) {
            return;
        }

        $candidate->status = AssuranceCandidateStatus::FAILED;
        $candidate->failed = true;
        $candidate->error_class = 'retry_exhausted';
        $candidate->failure_reason = mb_substr((string) ($exception?->getMessage() ?? 'Provider retries exhausted.'), 0, 4000);
        $candidate->completed_at = now();
        $candidate->save();

        EvaluateAssuranceRun::dispatch((int) $candidate->assurance_run_id, $this->companyId)
            ->onQueue((string) config('model-council.assurance.queue', 'assurance'));
    }
}
