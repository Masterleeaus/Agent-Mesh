<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

use App\Extensions\TitanAssurance\System\Events\AssuranceHumanApprovalRequired;
use App\Extensions\TitanAssurance\System\Events\AssuranceMaterialDisagreementDetected;
use App\Extensions\TitanAssurance\System\Events\AssuranceRunBlocked;
use App\Extensions\TitanAssurance\System\Events\AssuranceRunCompleted;
use App\Extensions\TitanAssurance\System\Models\AssuranceCandidate;
use App\Extensions\TitanAssurance\System\Models\AssuranceFinding;
use App\Extensions\TitanAssurance\System\Models\AssuranceRun;
use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\CostReconciler;
use App\Extensions\TitanAssurance\System\Services\Assurance\Compliance\ExternalComplianceRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\RulePackRegistry;
use App\Extensions\TitanAssurance\System\Support\AssuranceCandidateStatus;
use App\Extensions\TitanAssurance\System\Support\AssuranceMode;
use App\Extensions\TitanAssurance\System\Support\AssuranceStatus;

final class AssuranceRunEvaluator
{
    public function __construct(
        private readonly PanelSelectionService $panelSelection,
        private readonly DeterministicValidationPipeline $deterministic,
        private readonly DisagreementAnalyzer $disagreements,
        private readonly AssuranceScoringService $scoring,
        private readonly PermissionGateService $permissionGate,
        private readonly CostReconciler $costReconciler,
        private readonly AssuranceAuditService $audit,
        private readonly RulePackRegistry $rulePacks,
    ) {
    }

    public function evaluate(int $runId, string $companyId): array
    {
        /** @var AssuranceRun $run */
        $run = AssuranceRun::query()
            ->with(['candidates', 'approvals'])
            ->where('company_id', $companyId)
            ->whereKey($runId)
            ->firstOrFail();
        if ($this->isTerminal($run)) {
            return ['state' => 'terminal', 'run' => $run];
        }

        $baseCandidates = $run->candidates->where('assigned_role', '!=', 'adversarial_challenger')->values();
        if ($baseCandidates->contains(fn (AssuranceCandidate $candidate) => ! in_array((string) $candidate->status, AssuranceCandidateStatus::terminal(), true))) {
            return ['state' => 'waiting', 'run' => $run];
        }

        $successfulBase = $baseCandidates->where('status', AssuranceCandidateStatus::COMPLETED)->values();
        if ($successfulBase->isEmpty()) {
            return $this->block($run, 'all_candidates_failed', AssuranceStatus::FAILED);
        }

        $run->status = AssuranceStatus::EVALUATING;
        $run->evaluation_started_at ??= now();
        $run->started_at ??= now();
        $run->save();

        $panel = $successfulBase->map(fn (AssuranceCandidate $candidate) => [
            'provider' => $candidate->provider_key,
            'model_id' => $candidate->model_id,
            'family' => $candidate->model_family,
        ])->all();
        $panelResult = $this->panelSelection->validate($panel, (string) $run->assurance_mode);
        $run->independence_score = (float) $panelResult['independence']['score'];
        $run->provider_count = (int) $panelResult['provider_count'];
        $run->family_count = (int) $panelResult['family_count'];

        if (! $panelResult['valid']) {
            $run->scoring_components = ['panel' => $panelResult];
            $run->save();
            return $this->block($run, 'panel_policy_failed_after_execution', AssuranceStatus::POLICY_BLOCKED, ['panel' => $panelResult]);
        }

        $challengeRequired = (bool) $run->challenge_required || in_array((string) $run->assurance_mode, [AssuranceMode::HIGH, AssuranceMode::CRITICAL], true);
        $challengeCandidates = $run->candidates->where('assigned_role', 'adversarial_challenger')->values();
        if ($challengeRequired && $challengeCandidates->isEmpty()) {
            $run->status = AssuranceStatus::CHALLENGING;
            $run->save();
            $this->audit->record($run, 'AssuranceChallengeRequired');
            return ['state' => 'challenge_required', 'run' => $run];
        }
        if ($challengeRequired && $challengeCandidates->contains(fn (AssuranceCandidate $candidate) => ! in_array((string) $candidate->status, AssuranceCandidateStatus::terminal(), true))) {
            return ['state' => 'waiting', 'run' => $run];
        }

        $allForValidation = $successfulBase;
        if ($challengeRequired) {
            $allForValidation = $allForValidation->concat($challengeCandidates->where('status', AssuranceCandidateStatus::COMPLETED))->values();
        }

        $hardFailures = 0;
        $rulePackMetadata = null;
        $rulePackKey = trim((string) ($run->rule_pack_key ?? ''));
        $validationContext = (array) (((array) $run->decision_packet)['validation_context'] ?? []);
        foreach ($allForValidation as $candidate) {
            if ($rulePackKey !== '') {
                $snapshot = (array) ($run->compliance_rule_snapshot ?? []);
                $pack = $snapshot !== []
                    ? new ExternalComplianceRulePack($snapshot)
                    : $this->rulePacks->resolve($rulePackKey);
                $validation = $this->deterministic->validateCandidateWithPack((array) $candidate->structured_response, $pack, $validationContext);
                $rulePackMetadata = [
                    'key' => $pack->key(),
                    'version' => $pack->version(),
                    'source_key' => $run->compliance_source_key,
                    'jurisdiction' => $run->compliance_jurisdiction,
                    'content_hash' => $run->compliance_rule_hash,
                ];
            } else {
                $validation = $this->deterministic->validateCandidate((array) $candidate->structured_response, [
                    'require_evidence_for_claims' => true,
                ]);
            }
            $hardFailures += (int) $validation['hard_failures'];
            $this->persistFindings($run, $candidate, $validation['findings']);
        }

        $disagreement = $this->disagreements->analyze($successfulBase->map(fn (AssuranceCandidate $candidate) => [
            'structured_response' => (array) $candidate->structured_response,
        ])->all());
        $evidenceScore = $this->evidenceScore($successfulBase->all());
        $deterministicScore = max(0.0, 100.0 - ($hardFailures * 25.0));
        $challengeComplete = ! $challengeRequired || $challengeCandidates->where('status', AssuranceCandidateStatus::COMPLETED)->isNotEmpty();
        if ($challengeRequired && $challengeComplete) {
            $run->challenge_completed_at ??= now();
        }
        $challengeScore = $challengeComplete ? 100.0 : 0.0;

        $score = $this->scoring->score([
            'agreement' => max(0, 100 - (int) $disagreement['score']),
            'independence' => (float) $panelResult['independence']['score'],
            'evidence' => $evidenceScore,
            'deterministic' => $deterministicScore,
            'challenge' => $challengeScore,
            'disagreement_penalty' => (float) $disagreement['score'],
        ]);

        $humanApproved = $run->approvals->where('decision', 'approve')->isNotEmpty();
        $gateContext = [
            'mode' => (string) $run->assurance_mode,
            'panel_valid' => true,
            'evidence_locked' => ! empty($run->evidence_hash),
            'deterministic_passed' => $hardFailures === 0,
            'material_disagreement' => (bool) $disagreement['material'],
            'challenge_complete' => $challengeComplete,
            'score' => (float) $score['score'],
            'human_approved' => $humanApproved,
        ];
        $gate = $this->permissionGate->evaluate($gateContext);

        $run->confidence_score = (float) $score['score'];
        $run->evidence_score = $evidenceScore;
        $run->deterministic_score = $deterministicScore;
        $run->deterministic_status = $hardFailures === 0 ? 'passed' : 'failed';
        $run->disagreement_score = (float) $disagreement['score'];
        $run->challenge_score = $challengeScore;
        $costAccounting = $this->costReconciler->reconcile($run->candidates->map(fn (AssuranceCandidate $candidate) => ['cost' => $candidate->cost, 'effective_cost' => $candidate->effective_cost])->all());
        $run->actual_cost = $costAccounting['actual_cost'];
        $run->scoring_components = [
            'score' => $score,
            'panel' => $panelResult,
            'disagreement' => $disagreement,
            'hard_failures' => $hardFailures,
            'rule_pack' => $rulePackMetadata,
            'cost_accounting' => $costAccounting,
            'gate_context' => $gateContext,
            'gate' => $gate,
        ];
        $run->final_recommendation = $this->consensusAnswer($successfulBase->all());
        $run->residual_risk = json_encode($this->combinedRisks($successfulBase->all()), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        if ($disagreement['material']) {
            $run->status = AssuranceStatus::MATERIAL_DISAGREEMENT;
            $run->permission_state = 'blocked';
            $run->failure_code = 'material_disagreement';
            $run->save();
            $this->audit->record($run, 'AssuranceMaterialDisagreementDetected', $disagreement);
            event(new AssuranceMaterialDisagreementDetected($run));
            return ['state' => 'blocked', 'run' => $run->fresh()];
        }

        if ($gate['permission_state'] === 'permitted') {
            $run->status = AssuranceStatus::ASSURED;
            $run->permission_state = 'permitted';
            $run->failure_code = null;
            $run->completed_at = now();
            $run->save();
            $this->audit->record($run, 'AssuranceRunCompleted', ['score' => $score['score']]);
            event(new AssuranceRunCompleted($run));
            return ['state' => 'completed', 'run' => $run->fresh()];
        }

        if ((bool) $gate['human_approval_required'] && $this->onlyHumanGateOutstanding($gate['violations'])) {
            $run->status = AssuranceStatus::AWAITING_HUMAN_REVIEW;
            $run->permission_state = 'blocked';
            $run->failure_code = null;
            $run->save();
            $this->audit->record($run, 'AssuranceHumanApprovalRequired', ['score' => $score['score']]);
            event(new AssuranceHumanApprovalRequired($run));
            return ['state' => 'awaiting_human_review', 'run' => $run->fresh()];
        }

        $run->scoring_components = array_merge((array) $run->scoring_components, ['gate' => $gate]);
        $run->save();
        return $this->block($run, 'assurance_gate_failed', AssuranceStatus::POLICY_BLOCKED, ['gate' => $gate]);
    }

    private function persistFindings(AssuranceRun $run, AssuranceCandidate $candidate, array $findings): void
    {
        foreach ($findings as $finding) {
            $message = (string) ($finding['message'] ?? $finding['code'] ?? 'Assurance finding');
            AssuranceFinding::query()->firstOrCreate([
                'company_id' => $run->company_id,
                'assurance_run_id' => $run->id,
                'candidate_id' => $candidate->id,
                'type' => (string) ($finding['code'] ?? 'deterministic'),
                'claim' => $message,
            ], [
                'severity' => (string) ($finding['severity'] ?? 'soft'),
                'evidence_reference' => json_encode($finding['metadata'] ?? [], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                'resolution_status' => (bool) ($finding['passed'] ?? false) ? 'resolved' : 'unresolved',
            ]);
        }
    }

    /** @param array<int, AssuranceCandidate> $candidates */
    private function evidenceScore(array $candidates): float
    {
        $claims = 0;
        $supported = 0;
        foreach ($candidates as $candidate) {
            $response = (array) $candidate->structured_response;
            $evidenceIds = [];
            foreach ((array) ($response['evidence'] ?? []) as $evidence) {
                if (is_array($evidence) && isset($evidence['id'])) {
                    $evidenceIds[(string) $evidence['id']] = true;
                }
            }
            foreach ((array) ($response['claims'] ?? []) as $claim) {
                $claims++;
                $ids = is_array($claim) ? (array) ($claim['evidence_ids'] ?? []) : [];
                if (array_filter($ids, static fn ($id) => isset($evidenceIds[(string) $id])) !== []) {
                    $supported++;
                }
            }
        }
        return $claims === 0 ? 0.0 : round(($supported / $claims) * 100, 2);
    }

    /** @param array<int, AssuranceCandidate> $candidates */
    private function consensusAnswer(array $candidates): ?string
    {
        $answers = array_values(array_filter(array_map(
            static fn (AssuranceCandidate $candidate) => trim((string) ((array) $candidate->structured_response)['answer'] ?? ''),
            $candidates
        )));
        if ($answers === []) {
            return null;
        }
        $normalized = array_unique(array_map(static fn (string $answer) => strtolower(preg_replace('/\s+/', ' ', $answer) ?: ''), $answers));
        return count($normalized) === 1 ? $answers[0] : null;
    }

    /** @param array<int, AssuranceCandidate> $candidates */
    private function combinedRisks(array $candidates): array
    {
        $risks = [];
        foreach ($candidates as $candidate) {
            foreach ((array) (((array) $candidate->structured_response)['risks'] ?? []) as $risk) {
                $encoded = is_string($risk) ? $risk : (json_encode($risk, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '');
                if ($encoded !== '') {
                    $risks[$encoded] = $risk;
                }
            }
        }
        return array_values($risks);
    }

    private function onlyHumanGateOutstanding(array $violations): bool
    {
        return $violations === ['human_approval_required'];
    }

    private function block(AssuranceRun $run, string $code, string $status, array $payload = []): array
    {
        $run->status = $status;
        $run->permission_state = 'blocked';
        $run->failure_code = $code;
        $run->completed_at = now();
        $run->save();
        $this->audit->record($run, 'AssuranceRunBlocked', ['failure_code' => $code] + $payload);
        event(new AssuranceRunBlocked($run));
        return ['state' => 'blocked', 'run' => $run->fresh()];
    }

    private function isTerminal(AssuranceRun $run): bool
    {
        return in_array((string) $run->status, [
            AssuranceStatus::ASSURED,
            AssuranceStatus::ASSURED_WITH_CONDITIONS,
            AssuranceStatus::FAILED,
            AssuranceStatus::POLICY_BLOCKED,
            AssuranceStatus::MATERIAL_DISAGREEMENT,
            AssuranceStatus::INSUFFICIENT_EVIDENCE,
            AssuranceStatus::EXPIRED,
            AssuranceStatus::SUPERSEDED,
            AssuranceStatus::CANCELLED,
        ], true);
    }
}
