<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AssuranceApproval extends Model
{
    protected $table = 'assurance_approvals';

    protected $guarded = ['id', 'company_id', 'assurance_run_id', 'approver_id', 'created_at', 'updated_at'];

    protected $casts = [
        'conditions' => 'array',
        'approved_at' => 'datetime',
    ];

    public function run(): BelongsTo
    {
        return $this->belongsTo(AssuranceRun::class, 'assurance_run_id');
    }
}
