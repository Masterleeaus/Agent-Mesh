<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Compliance;

use DateTimeInterface;
use DomainException;

final class ComplianceRulePackResolver
{
    public function __construct(
        private readonly ComplianceRuleSourceRegistry $sources,
        private readonly ComplianceRuleDocumentValidator $validator,
    ) {
    }

    public function resolve(
        string|int $companyId,
        string $sourceKey,
        string $rulePackKey,
        string $jurisdiction,
        DateTimeInterface|string $asOf,
        array $context = [],
        bool $signatureRequired = false,
    ): ExternalComplianceRulePack {
        $sourceKey = strtolower(trim($sourceKey));
        $rulePackKey = strtolower(trim($rulePackKey));
        $source = $this->sources->for($sourceKey);
        $document = $source->fetch($companyId, $rulePackKey, $jurisdiction, $context);
        $validated = $this->validator->validate($document, $jurisdiction, $asOf, $signatureRequired);

        if (strtolower(trim((string) ($validated['source_key'] ?? ''))) !== $sourceKey) {
            throw new DomainException('Compliance rule source identity mismatch.');
        }
        if (strtolower(trim((string) ($validated['rule_pack_key'] ?? ''))) !== $rulePackKey) {
            throw new DomainException('Compliance rule-pack identity mismatch.');
        }

        return new ExternalComplianceRulePack($validated);
    }
}
