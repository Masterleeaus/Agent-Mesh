<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Integration;

use App\Extensions\TitanAssurance\System\Contracts\AssuranceIntegrationSink;
use DomainException;

final class IntegrationSinkRegistry
{
    /** @var array<string, AssuranceIntegrationSink> */
    private array $sinks = [];

    /** @param iterable<AssuranceIntegrationSink> $sinks */
    public function __construct(iterable $sinks = [])
    {
        foreach ($sinks as $sink) {
            $this->register($sink);
        }
    }

    public function register(AssuranceIntegrationSink $sink): void
    {
        $key = strtolower(trim($sink->destinationKey()));
        if ($key === '') {
            throw new DomainException('Assurance integration sink requires a destination key.');
        }
        $this->sinks[$key] = $sink;
    }

    public function dispatch(array $destinations, string $eventType, array $payload, string $idempotencyKey): array
    {
        $receipts = [];
        foreach (array_values(array_unique(array_map(static fn ($value) => strtolower(trim((string) $value)), $destinations))) as $destination) {
            if ($destination === '') {
                continue;
            }
            $sink = $this->sinks[$destination] ?? null;
            if (! $sink) {
                $receipts[$destination] = [
                    'destination' => $destination,
                    'available' => false,
                    'dispatched' => false,
                    'idempotency_key' => $idempotencyKey,
                ];
                continue;
            }

            $envelope = [
                'event_type' => $eventType,
                'destination' => $destination,
                'idempotency_key' => $idempotencyKey,
                'payload' => $payload,
            ];
            $receipt = $sink->publish($envelope);
            $receipts[$destination] = array_merge([
                'destination' => $destination,
                'available' => true,
                'dispatched' => true,
                'idempotency_key' => $idempotencyKey,
            ], is_array($receipt) ? $receipt : []);
        }

        return $receipts;
    }

    public function keys(): array
    {
        return array_keys($this->sinks);
    }
}
