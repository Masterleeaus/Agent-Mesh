<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Rules;

use App\Extensions\TitanAssurance\System\Contracts\DeterministicRulePack;
use DomainException;

final class RulePackRegistry
{
    /** @var array<string, DeterministicRulePack> */
    private array $packs = [];

    /** @param iterable<DeterministicRulePack> $packs */
    public function __construct(iterable $packs = [])
    {
        foreach ($packs as $pack) {
            $this->packs[strtolower(trim($pack->key()))] = $pack;
        }
    }

    public function resolve(string $key): DeterministicRulePack
    {
        $key = strtolower(trim($key));
        $pack = $this->packs[$key] ?? null;
        if (! $pack) {
            throw new DomainException("Unknown deterministic rule pack: {$key}");
        }
        return $pack;
    }

    public function keys(): array
    {
        return array_keys($this->packs);
    }
}
