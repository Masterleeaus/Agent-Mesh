<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System;

use App\Extensions\TitanAssurance\System\Commands\CertifyExtensionCommand;
use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanAssurance\System\Contracts\AssuranceEngine;
use App\Extensions\TitanAssurance\System\Contracts\EvidenceAssuranceEngine;
use App\Extensions\TitanAssurance\System\Contracts\EvidenceCollectionRequester;
use App\Extensions\TitanAssurance\System\Contracts\AssuranceProviderTransport;
use App\Extensions\TitanAssurance\System\Contracts\AssuranceStreamingProviderTransport;
use App\Extensions\TitanAssurance\System\Contracts\ComplianceSignatureVerifier;
use App\Extensions\TitanAssurance\System\Http\Controllers\AssuranceController;
use App\Extensions\TitanAssurance\System\Http\Controllers\EvidenceAssuranceController;
use App\Extensions\TitanAssurance\System\Http\Controllers\ModelCouncilController;
use App\Extensions\TitanAssurance\System\Services\Assurance\AssuranceEngineService;
use App\Extensions\TitanAssurance\System\Services\Assurance\EvidenceAssuranceEngineService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\EvidenceRecordNormalizer;
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\EvidenceWeightingService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\AssuranceResultService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\KnowledgeReferenceValidator;
use App\Extensions\TitanAssurance\System\Services\Assurance\Calibration\MiscalibrationDetector;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\LaravelEventEvidenceCollectionRequester;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\IntegrationSinkRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\AutonomyAssuranceProjectionService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\LatestEvidenceAssessmentResolver;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\TitanAutonomyAssuranceBridge;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\TitanAutonomyTenantAssuranceBridge;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\CrossEngineIntegrationStatus;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\TitanSignalAssuranceSink;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\TitanSignalIntegrationProfile;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\TitanSignalIntegrationRegistrar;
use App\Extensions\TitanAssurance\System\Services\Assurance\CompanyContextResolver;
use App\Extensions\TitanAssurance\System\Services\Assurance\Compliance\ComplianceRuleDocumentValidator;
use App\Extensions\TitanAssurance\System\Services\Assurance\Compliance\ComplianceRulePackResolver;
use App\Extensions\TitanAssurance\System\Services\Assurance\Compliance\ComplianceRuleSourceRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Compliance\NullComplianceSignatureVerifier;
use App\Extensions\TitanAssurance\System\Services\Assurance\Intelligence\AssuranceOutcomeIntelligenceService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Intelligence\AssuranceRecommendationService;
use App\Extensions\TitanAssurance\System\Services\Assurance\AssuranceCalibrationService;
use App\Extensions\TitanAssurance\System\Services\Assurance\OutcomeRecorder;
use App\Extensions\TitanAssurance\System\Services\Assurance\AssuranceScoringService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\ProviderPricingCatalogue;
use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\UsageCostCalculator;
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\EvidenceSourceRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\RulePackRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\FieldHomeServicesRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\EcommerceRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\PropertyHospitalityRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\FitnessWellnessRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\SalonBeautyRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\AutomotiveRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\FacilitiesRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\BookingHireRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Capabilities\ModelCapabilityRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\IndependenceScoringService;
use App\Extensions\TitanAssurance\System\Services\Assurance\PanelSelectionService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\AnthropicAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\DeepSeekAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\GeminiAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\MagicAIHttpProviderTransport;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\MagicAIHttpStreamingProviderTransport;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\MagicAIProviderRequestFactory;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\OpenAIAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\OpenRouterAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\ProviderAdapterRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\ProviderExecutionGateway;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\StreamingProviderExecutionGateway;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\UsageNormalizer;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\XAIAdapter;
use App\Helpers\Classes\MarketplaceHelper;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

class TitanAssuranceServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->commands([CertifyExtensionCommand::class]);
        $this->registerConfig();
        $this->registerOptionalSignalIntegration();

        $this->app->singleton(ModelCapabilityRegistry::class, fn () => new ModelCapabilityRegistry());
        $this->app->singleton(IndependenceScoringService::class, fn () => new IndependenceScoringService());
        $this->app->singleton(PanelSelectionService::class, function ($app) {
            $policies = [];
            foreach ((array) config('model-council.assurance.modes', []) as $mode => $policy) {
                $policies[$mode] = [
                    'minimum_candidates' => (int) ($policy['minimum_candidates'] ?? 1),
                    'minimum_model_families' => (int) ($policy['minimum_model_families'] ?? 1),
                    'minimum_providers' => (int) ($policy['minimum_providers'] ?? 1),
                ];
            }
            return new PanelSelectionService($app->make(IndependenceScoringService::class), $policies ?: [
                'standard' => ['minimum_candidates' => 2, 'minimum_model_families' => 1, 'minimum_providers' => 1],
                'high' => ['minimum_candidates' => 3, 'minimum_model_families' => 2, 'minimum_providers' => 1],
                'critical' => ['minimum_candidates' => 3, 'minimum_model_families' => 2, 'minimum_providers' => 2],
            ]);
        });
        $this->app->singleton(AssuranceScoringService::class, fn () => new AssuranceScoringService((array) config('model-council.assurance.scoring_weights', [])));
        $this->app->singleton(OutcomeRecorder::class, fn () => new OutcomeRecorder());
        $this->app->singleton(AssuranceCalibrationService::class, fn () => new AssuranceCalibrationService());
        $this->app->singleton(EvidenceSourceRegistry::class, fn ($app) => new EvidenceSourceRegistry($app->tagged('titan.assurance.evidence_sources')));
        if (! $this->app->bound(ComplianceSignatureVerifier::class)) {
            $this->app->singleton(ComplianceSignatureVerifier::class, NullComplianceSignatureVerifier::class);
        }
        $this->app->singleton(ComplianceRuleSourceRegistry::class, fn ($app) => new ComplianceRuleSourceRegistry($app->tagged('titan.assurance.compliance_rule_sources')));
        $this->app->singleton(ComplianceRuleDocumentValidator::class, fn ($app) => new ComplianceRuleDocumentValidator($app->make(ComplianceSignatureVerifier::class)));
        $this->app->singleton(ComplianceRulePackResolver::class, fn ($app) => new ComplianceRulePackResolver(
            $app->make(ComplianceRuleSourceRegistry::class),
            $app->make(ComplianceRuleDocumentValidator::class),
        ));
        $this->app->singleton(AssuranceOutcomeIntelligenceService::class, fn () => new AssuranceOutcomeIntelligenceService());
        $this->app->singleton(AssuranceRecommendationService::class, fn () => new AssuranceRecommendationService());
        $this->app->singleton(RulePackRegistry::class, fn () => new RulePackRegistry([
            new FieldHomeServicesRulePack(),
            new EcommerceRulePack(),
            new PropertyHospitalityRulePack(),
            new FitnessWellnessRulePack(),
            new SalonBeautyRulePack(),
            new AutomotiveRulePack(),
            new FacilitiesRulePack(),
            new BookingHireRulePack(),
        ]));
        $this->app->singleton(\App\Extensions\TitanAssurance\System\Services\Assurance\PermissionGateService::class, fn () => new \App\Extensions\TitanAssurance\System\Services\Assurance\PermissionGateService([
            'standard' => (float) config('model-council.assurance.modes.standard.minimum_score', 70),
            'high' => (float) config('model-council.assurance.modes.high.minimum_score', 80),
            'critical' => (float) config('model-council.assurance.modes.critical.minimum_score', 85),
        ]));

        $this->app->singleton(ProviderAdapterRegistry::class, function ($app) {
            $capabilities = $app->make(ModelCapabilityRegistry::class);
            return new ProviderAdapterRegistry([
                new OpenAIAdapter($capabilities),
                new AnthropicAdapter($capabilities),
                new GeminiAdapter($capabilities),
                new DeepSeekAdapter($capabilities),
                new XAIAdapter($capabilities),
                new OpenRouterAdapter($capabilities),
            ]);
        });

        $this->app->singleton(MagicAIProviderRequestFactory::class, fn () => new MagicAIProviderRequestFactory());
        $this->app->singleton(AssuranceProviderTransport::class, MagicAIHttpProviderTransport::class);
        $this->app->singleton(AssuranceStreamingProviderTransport::class, MagicAIHttpStreamingProviderTransport::class);
        $this->app->singleton(UsageNormalizer::class, fn () => new UsageNormalizer());
        $this->app->singleton(ProviderPricingCatalogue::class, fn () => new ProviderPricingCatalogue());
        $this->app->singleton(UsageCostCalculator::class, fn ($app) => new UsageCostCalculator($app->make(ProviderPricingCatalogue::class)));
        $this->app->singleton(ProviderExecutionGateway::class, fn ($app) => new ProviderExecutionGateway(
            $app->make(ProviderAdapterRegistry::class),
            $app->make(AssuranceProviderTransport::class),
            $app->make(UsageNormalizer::class),
        ));
        $this->app->singleton(StreamingProviderExecutionGateway::class, fn ($app) => new StreamingProviderExecutionGateway(
            $app->make(ProviderAdapterRegistry::class),
            $app->make(AssuranceStreamingProviderTransport::class),
            $app->make(UsageNormalizer::class),
        ));
        $this->app->singleton(EvidenceRecordNormalizer::class, fn () => new EvidenceRecordNormalizer());
        $this->app->singleton(EvidenceWeightingService::class, fn () => new EvidenceWeightingService());
        $this->app->singleton(KnowledgeReferenceValidator::class, fn () => new KnowledgeReferenceValidator());
        $this->app->singleton(AssuranceResultService::class, fn ($app) => new AssuranceResultService(
            $app->make(EvidenceWeightingService::class),
            (float) config('model-council.assurance.evidence_core.green_threshold', 80),
            (float) config('model-council.assurance.evidence_core.amber_threshold', 60),
            (float) config('model-council.assurance.evidence_core.stale_threshold', 0.40),
        ));
        $this->app->singleton(MiscalibrationDetector::class, fn () => new MiscalibrationDetector(
            (int) config('model-council.assurance.evidence_core.minimum_green_calibration_samples', 5),
            (float) config('model-council.assurance.evidence_core.green_rejection_threshold', 0.30),
            (float) config('model-council.assurance.evidence_core.minimum_calibration_factor', 0.50),
        ));
        if (! $this->app->bound(EvidenceCollectionRequester::class)) {
            $this->app->singleton(EvidenceCollectionRequester::class, LaravelEventEvidenceCollectionRequester::class);
        }
        $this->app->singleton(IntegrationSinkRegistry::class, fn ($app) => new IntegrationSinkRegistry($app->tagged('titan.assurance.integration_sinks')));
        $this->app->singleton(AutonomyAssuranceProjectionService::class);
        $this->app->singleton(LatestEvidenceAssessmentResolver::class, fn () => new LatestEvidenceAssessmentResolver(
            (int) config('model-council.assurance.integration.autonomy.max_assessment_age_minutes', 60),
        ));
        $this->app->singleton(CrossEngineIntegrationStatus::class);
        $this->registerOptionalAutonomyBridge();
        $this->app->singleton(EvidenceAssuranceEngine::class, EvidenceAssuranceEngineService::class);
        $this->app->singleton(AssuranceEngine::class, AssuranceEngineService::class);
    }

    private function registerOptionalSignalIntegration(): void
    {
        if (! (bool) config('model-council.assurance.integration.signal.enabled', true)) {
            return;
        }

        $this->app->singleton(TitanSignalIntegrationProfile::class);
        $this->app->singleton(TitanSignalIntegrationRegistrar::class, fn ($app) => new TitanSignalIntegrationRegistrar(
            $app,
            $app->make(TitanSignalIntegrationProfile::class),
        ));
        $this->app->singleton(TitanSignalAssuranceSink::class, fn ($app) => new TitanSignalAssuranceSink(
            $app,
            $app->make(TitanSignalIntegrationRegistrar::class),
            $app->make(TitanSignalIntegrationProfile::class),
        ));
        $this->app->tag([TitanSignalAssuranceSink::class], 'titan.assurance.integration_sinks');

        // Signal authorities snapshot their trusted definitions when first
        // resolved. Contribute the least-privilege Assurance identities before
        // that resolution, independent of extension provider load order.
        foreach ([
            'App\\Extensions\\TitanSignalEngine\\System\\Contracts\\SignalEmitterAuthorityContract',
            'App\\Extensions\\TitanSignalEngine\\System\\Contracts\\SignalRegistryAuthorityContract',
        ] as $contract) {
            if (method_exists($this->app, 'beforeResolving')) {
                $this->app->beforeResolving($contract, function (): void {
                    $this->contributeSignalAuthorityConfig();
                });
            }
        }

        // If Signal registered before Assurance, its config already exists and
        // can be extended immediately. Otherwise boot() repeats this after every
        // provider has completed register().
        if (config('titan-signal-engine.enabled', null) !== null) {
            $this->contributeSignalAuthorityConfig();
        }
    }

    private function contributeSignalAuthorityConfig(): void
    {
        if (! (bool) config('model-council.assurance.integration.signal.enabled', true)) {
            return;
        }

        /** @var TitanSignalIntegrationProfile $profile */
        $profile = $this->app->make(TitanSignalIntegrationProfile::class);
        $emitters = (array) config('titan-signal-engine.trusted_emitters', []);
        $registrars = (array) config('titan-signal-engine.registry_actors', []);

        $emitters[$profile->emitterServiceId()] = $profile->trustedEmitterDefinition();
        $registrars[$profile->registryServiceId()] = $profile->registryActorDefinition();

        config([
            'titan-signal-engine.trusted_emitters' => $emitters,
            'titan-signal-engine.registry_actors' => $registrars,
        ]);
    }

    private function registerOptionalAutonomyBridge(): void
    {
        if (! (bool) config('model-council.assurance.integration.autonomy.enabled', true)) {
            return;
        }

        $contract = 'App\\Extensions\\TitanAutonomy\\System\\Contracts\\AssuranceBridgeContract';
        if (interface_exists($contract)) {
            // Deliberately bind the evidence-native bridge over Autonomy's legacy
            // ModelCouncil fallback. Autonomy remains the authority owner.
            $this->app->singleton($contract, fn ($app) => new TitanAutonomyAssuranceBridge(
                $app->make(CompanyContextResolver::class),
                $app->make(LatestEvidenceAssessmentResolver::class),
                $app->make(AutonomyAssuranceProjectionService::class),
            ));
        }

        $tenantContract = 'App\\Extensions\\TitanAutonomy\\System\\Contracts\\TenantAssuranceBridgeContract';
        if (interface_exists($tenantContract)) {
            $this->app->singleton($tenantContract, fn ($app) => new TitanAutonomyTenantAssuranceBridge(
                $app->make(LatestEvidenceAssessmentResolver::class),
                $app->make(AutonomyAssuranceProjectionService::class),
            ));
        }
    }

    public function boot(Kernel $kernel): void
    {
        // Re-run optional bridge registration after all providers have completed
        // their register phase so extension load order cannot strand Autonomy on
        // the legacy assurance_runs compatibility bridge.
        $this->registerOptionalAutonomyBridge();
        $this->contributeSignalAuthorityConfig();

        // Assurance persistence/core must boot even when AIChatPro is absent.
        $this->registerMigrations();
        $this->registerAssuranceRoutes();

        if (! MarketplaceHelper::isRegistered('ai-chat-pro')) {
            return;
        }

        $this->registerTranslations()
            ->registerViews()
            ->registerRoutes()
            ->publishAssets();
    }

    public function publishAssets(): static
    {
        $this->publishes([], 'titan-assurance-assets');

        return $this;
    }

    public function registerConfig(): static
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/model-council.php', 'model-council');

        return $this;
    }

    protected function registerTranslations(): static
    {
        $this->loadTranslationsFrom(__DIR__ . '/../resources/lang', 'model-council');

        return $this;
    }

    public function registerViews(): static
    {
        $this->loadViewsFrom([__DIR__ . '/../resources/views'], 'model-council');

        return $this;
    }

    public function registerMigrations(): static
    {
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');

        return $this;
    }


    private function registerAssuranceRoutes(): static
    {
        $this->router()->group([
            'middleware' => (array) config('model-council.assurance.api_middleware', ['web', 'auth', 'throttle:60,1']),
            'prefix' => trim((string) config('model-council.assurance.api_prefix', 'api/titan/assurance'), '/'),
            'controller' => AssuranceController::class,
            'as' => 'titan.assurance.',
        ], function (Router $router) {
            // v1.x compatibility surface. Risk classification, council execution and permission gating remain
            // available for existing installations but are not the canonical v2 Assurance ownership model.
            $router->post('/runs', 'createRun')->name('runs.create');
            $router->get('/runs/{runId}', 'show')->whereNumber('runId')->name('runs.show');
            $router->put('/runs/{runId}/evidence', 'lockEvidence')->whereNumber('runId')->name('runs.evidence');
            $router->post('/runs/{runId}/start', 'start')->whereNumber('runId')->name('runs.start');
            $router->post('/runs/{runId}/decision', 'decision')->whereNumber('runId')->name('runs.decision');
            $router->post('/runs/{runId}/cancel', 'cancel')->whereNumber('runId')->name('runs.cancel');
            $router->post('/runs/{runId}/outcomes', 'recordOutcome')->whereNumber('runId')->name('runs.outcomes.create');
            $router->get('/calibration', 'calibration')->name('calibration');
            $router->get('/intelligence', 'intelligence')->name('intelligence');
            $router->get('/intelligence/recommendations', 'intelligenceRecommendations')->name('intelligence.recommendations');
        });

        $this->router()->group([
            'middleware' => (array) config('model-council.assurance.api_middleware', ['web', 'auth', 'throttle:60,1']),
            'prefix' => trim((string) config('model-council.assurance.api_prefix', 'api/titan/assurance'), '/'),
            'controller' => EvidenceAssuranceController::class,
            'as' => 'titan.assurance.',
        ], function (Router $router) {
            $router->post('/assessments', 'assess')->name('assessments.create');
            $router->get('/assessments/{assessmentId}', 'show')->whereNumber('assessmentId')->name('assessments.show');
            $router->post('/assessments/{assessmentId}/feedback', 'feedback')->whereNumber('assessmentId')->name('assessments.feedback');
        });

        return $this;
    }

    private function registerRoutes(): static
    {
        if (! MarketplaceHelper::isRegistered('multi-model')) {
            $this->router()->group([
                'middleware' => ['web', 'auth', 'throttle:' . (int) config('model-council.assurance.selection_rate_limit', 30) . ',1'],
                'prefix'     => 'dashboard/user/multimodel',
                'controller' => ModelCouncilController::class,
            ], function (Router $router) {
                $router->post('/accept-response', 'acceptResponse')->name('prefer');
            });
        }

        return $this;
    }

    private function router(): Router|Route
    {
        return $this->app['router'];
    }

    public static function uninstall(): void
    {
        // Assurance history is deliberately retained. Destructive uninstall must be explicit at platform level.
    }

    public function registerKey(): string
    {
        return 'model-council';
    }
}
