<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Support;

final class RiskLevel
{
    public const GREEN = 'green';
    public const AMBER = 'amber';
    public const RED = 'red';
    public const CRITICAL = 'critical';

    public static function all(): array
    {
        return [self::GREEN, self::AMBER, self::RED, self::CRITICAL];
    }
}
