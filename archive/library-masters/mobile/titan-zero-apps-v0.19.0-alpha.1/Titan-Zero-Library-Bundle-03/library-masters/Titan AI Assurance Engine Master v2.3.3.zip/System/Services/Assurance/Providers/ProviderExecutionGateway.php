<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Providers;

use App\Extensions\TitanAssurance\System\Contracts\AssuranceProviderTransport;
use App\Extensions\TitanAssurance\System\Exceptions\AssuranceProviderException;

final class ProviderExecutionGateway
{
    public function __construct(
        private readonly ProviderAdapterRegistry $adapters,
        private readonly AssuranceProviderTransport $transport,
        private readonly UsageNormalizer $usageNormalizer,
    ) {
    }

    public function execute(string $providerKey, string $modelId, array $messages, array $options = []): array
    {
        $adapter = $this->adapters->for($providerKey, $modelId);
        $request = $adapter->buildRequest($modelId, $messages, $options);
        $transport = $this->transport->send($providerKey, $modelId, $request);
        $status = (int) ($transport['status'] ?? 0);

        if ($status < 200 || $status >= 300) {
            $errorClass = $adapter->classifyRetry(['status' => $status]);
            throw new AssuranceProviderException('Provider returned HTTP ' . $status, $errorClass, $status);
        }

        $body = $transport['body'] ?? [];
        $parsed = $adapter->parseResponse($body);
        $usage = $this->usageNormalizer->normalize(
            $providerKey,
            is_array($parsed['usage'] ?? null) ? $parsed['usage'] : [],
            is_array($body) ? $body : [],
        );

        return [
            'provider' => strtolower(trim($providerKey)),
            'model_id' => $modelId,
            'text' => trim((string) ($parsed['text'] ?? '')),
            'usage' => $usage,
            'raw' => $parsed['raw'] ?? $body,
            'response_time_ms' => (int) ($transport['response_time_ms'] ?? 0),
            'status' => $status,
            'request' => $request,
        ];
    }
}
