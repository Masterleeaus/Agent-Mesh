<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Cost;

final class CostEstimator
{
    public function estimate(array $panel, array $options = []): array
    {
        $candidateCost = 0.0;
        foreach ($panel as $candidate) {
            $candidateCost += max(0.0, (float) ($candidate['estimated_cost'] ?? 0));
        }
        $challenge = max(0.0, (float) ($options['challenge_estimated_cost'] ?? 0));
        $synthesis = max(0.0, (float) ($options['synthesis_estimated_cost'] ?? 0));

        return [
            'candidate_cost' => round($candidateCost, 6),
            'challenge_cost' => round($challenge, 6),
            'synthesis_cost' => round($synthesis, 6),
            'estimated_cost' => round($candidateCost + $challenge + $synthesis, 6),
            'currency' => strtoupper((string) ($options['currency'] ?? 'USD')),
        ];
    }
}
