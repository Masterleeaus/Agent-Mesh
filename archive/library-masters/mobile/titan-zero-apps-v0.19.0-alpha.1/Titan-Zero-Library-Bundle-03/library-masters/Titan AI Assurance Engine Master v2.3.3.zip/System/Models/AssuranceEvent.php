<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Models;

use Illuminate\Database\Eloquent\Model;

class AssuranceEvent extends Model
{
    protected $table = 'assurance_events';

    public $timestamps = false;

    protected $guarded = ['id', 'company_id', 'assurance_run_id', 'actor_id', 'created_at'];

    protected $casts = [
        'payload' => 'array',
        'created_at' => 'datetime',
    ];
}
