<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Compliance;

use App\Extensions\TitanAssurance\System\Contracts\ComplianceRuleSource;
use DomainException;

final class ComplianceRuleSourceRegistry
{
    /** @var array<string,ComplianceRuleSource> */
    private array $sources = [];

    /** @param iterable<ComplianceRuleSource> $sources */
    public function __construct(iterable $sources = [])
    {
        foreach ($sources as $source) {
            $this->register($source);
        }
    }

    public function register(ComplianceRuleSource $source): void
    {
        $this->sources[strtolower(trim($source->sourceKey()))] = $source;
    }

    public function for(string $sourceKey): ComplianceRuleSource
    {
        $key = strtolower(trim($sourceKey));
        $source = $this->sources[$key] ?? null;
        if (! $source) {
            throw new DomainException("Compliance rule source unavailable: {$key}");
        }

        return $source;
    }

    public function keys(): array
    {
        return array_keys($this->sources);
    }
}
