<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

final class StructuredResponseValidator
{
    private const REQUIRED_KEYS = ['answer', 'confidence', 'claims', 'evidence', 'risks', 'assumptions'];

    public function validate(array $response, array $rules = []): array
    {
        $findings = [];
        if (isset($response['_parse_error']) && $response['_parse_error'] !== '') {
            $findings[] = $this->finding('provider_response_parse_error', 'hard', false, 'Provider response was not valid structured JSON.');
        }
        foreach (self::REQUIRED_KEYS as $key) {
            if (! array_key_exists($key, $response)) {
                $findings[] = $this->finding('schema_missing_key', 'hard', false, "Missing response key: {$key}", ['key' => $key]);
            }
        }

        if (isset($response['confidence']) && (! is_numeric($response['confidence']) || (float) $response['confidence'] < 0 || (float) $response['confidence'] > 1)) {
            $findings[] = $this->finding('confidence_out_of_range', 'hard', false, 'Confidence must be between 0 and 1.');
        }

        foreach (['claims', 'evidence', 'risks', 'assumptions'] as $arrayKey) {
            if (array_key_exists($arrayKey, $response) && ! is_array($response[$arrayKey])) {
                $findings[] = $this->finding('schema_invalid_type', 'hard', false, "{$arrayKey} must be an array.", ['key' => $arrayKey]);
            }
        }

        if ((bool) ($rules['require_evidence_for_claims'] ?? false)) {
            $evidenceIds = [];
            foreach ((array) ($response['evidence'] ?? []) as $item) {
                if (is_array($item) && isset($item['id'])) {
                    $evidenceIds[(string) $item['id']] = true;
                }
            }

            foreach ((array) ($response['claims'] ?? []) as $index => $claim) {
                $ids = is_array($claim) ? (array) ($claim['evidence_ids'] ?? []) : [];
                $validIds = array_filter($ids, static fn ($id) => isset($evidenceIds[(string) $id]));
                if ($validIds === []) {
                    $findings[] = $this->finding('claim_without_evidence', 'hard', false, 'Claim has no valid evidence reference.', ['claim_index' => $index]);
                }
            }
        }

        return $this->result($findings);
    }

    private function finding(string $code, string $severity, bool $passed, string $message, array $metadata = []): array
    {
        return compact('code', 'severity', 'passed', 'message', 'metadata');
    }

    private function result(array $findings): array
    {
        $hardFailures = count(array_filter($findings, static fn (array $finding) => $finding['severity'] === 'hard' && ! $finding['passed']));

        return [
            'status' => $hardFailures > 0 ? 'failed' : 'passed',
            'hard_failures' => $hardFailures,
            'findings' => $findings,
        ];
    }
}
