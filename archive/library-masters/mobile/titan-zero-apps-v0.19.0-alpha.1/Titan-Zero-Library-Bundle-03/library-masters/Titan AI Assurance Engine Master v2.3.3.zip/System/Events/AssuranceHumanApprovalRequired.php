<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Events;

use App\Extensions\TitanAssurance\System\Models\AssuranceRun;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class AssuranceHumanApprovalRequired
{
    use Dispatchable, SerializesModels;

    public function __construct(public readonly AssuranceRun $run)
    {
    }
}
