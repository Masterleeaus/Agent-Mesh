<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Cost;

final class UsageCostCalculator
{
    public function __construct(private readonly ProviderPricingCatalogue $catalogue)
    {
    }

    public function calculate(string $providerKey, string $modelId, array $normalizedUsage): array
    {
        $reported = isset($normalizedUsage['reported_cost']) && is_numeric($normalizedUsage['reported_cost'])
            ? max(0.0, (float) $normalizedUsage['reported_cost'])
            : null;
        $pricing = $this->catalogue->resolve($providerKey, $modelId);

        $calculated = $pricing === null ? null : $this->calculateFromPricing($normalizedUsage, $pricing);
        $effective = $reported ?? $calculated;
        $status = $reported !== null
            ? 'provider_reported'
            : ($calculated !== null ? 'calculated' : 'pricing_unknown');

        return [
            'reported_cost' => $reported,
            'calculated_cost' => $calculated,
            'effective_cost' => $effective,
            'currency' => (string) ($pricing['currency'] ?? $this->catalogue->currency()),
            'pricing_version' => (string) ($pricing['pricing_version'] ?? $this->catalogue->version()),
            'pricing_status' => $status,
        ];
    }

    private function calculateFromPricing(array $usage, array $pricing): ?float
    {
        $inputTokens = $this->tokens($usage['input_tokens'] ?? null);
        $outputTokens = $this->tokens($usage['output_tokens'] ?? null);
        $cachedTokens = $this->tokens($usage['cached_input_tokens'] ?? null);
        $reasoningTokens = $this->tokens($usage['reasoning_tokens'] ?? null);

        $hasKnownTokens = $inputTokens !== null || $outputTokens !== null || $cachedTokens !== null || $reasoningTokens !== null;
        if (! $hasKnownTokens) {
            return null;
        }

        $total = 0.0;
        $priced = false;

        foreach ([
            [$inputTokens, $pricing['input_per_million'] ?? null],
            [$outputTokens, $pricing['output_per_million'] ?? null],
            [$cachedTokens, $pricing['cached_input_per_million'] ?? null],
            [$reasoningTokens, $pricing['reasoning_per_million'] ?? null],
        ] as [$tokens, $rate]) {
            if ($tokens === null || ! is_numeric($rate)) {
                continue;
            }
            $total += ($tokens / 1_000_000) * max(0.0, (float) $rate);
            $priced = true;
        }

        return $priced ? round($total, 8) : null;
    }

    private function tokens(mixed $value): ?int
    {
        return is_numeric($value) ? max(0, (int) $value) : null;
    }
}
