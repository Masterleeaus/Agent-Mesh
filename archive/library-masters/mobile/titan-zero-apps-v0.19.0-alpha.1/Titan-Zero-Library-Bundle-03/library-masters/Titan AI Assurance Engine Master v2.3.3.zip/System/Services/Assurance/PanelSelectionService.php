<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

final class PanelSelectionService
{
    private const DEFAULT_POLICIES = [
        'standard' => ['minimum_candidates' => 2, 'minimum_model_families' => 1, 'minimum_providers' => 1],
        'high' => ['minimum_candidates' => 3, 'minimum_model_families' => 2, 'minimum_providers' => 1],
        'critical' => ['minimum_candidates' => 3, 'minimum_model_families' => 2, 'minimum_providers' => 2],
    ];

    public function __construct(
        private readonly IndependenceScoringService $independence,
        private readonly array $policies = self::DEFAULT_POLICIES,
    ) {
    }

    public function validate(array $panel, string $mode): array
    {
        $mode = strtolower(trim($mode));
        $policy = $this->policies[$mode] ?? self::DEFAULT_POLICIES['standard'];
        $independence = $this->independence->score($panel);
        $violations = [];

        if ($independence['candidate_count'] < (int) ($policy['minimum_candidates'] ?? 1)) {
            $violations[] = 'minimum_candidates';
        }
        if ($independence['family_count'] < (int) ($policy['minimum_model_families'] ?? 1)) {
            $violations[] = 'minimum_model_families';
        }
        if ($independence['provider_count'] < (int) ($policy['minimum_providers'] ?? 1)) {
            $violations[] = 'minimum_providers';
        }

        return [
            'valid' => $violations === [],
            'violations' => $violations,
            'provider_count' => $independence['provider_count'],
            'family_count' => $independence['family_count'],
            'candidate_count' => $independence['candidate_count'],
            'independence' => $independence,
        ];
    }
}
