<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Support;

final class AssuranceStatus
{
    public const PENDING = 'pending';
    public const QUEUED = 'queued';
    public const RUNNING = 'running';
    public const EVALUATING = 'evaluating';
    public const COLLECTING_EVIDENCE = 'collecting_evidence';
    public const ANALYSING = 'analysing';
    public const CHALLENGING = 'challenging';
    public const AWAITING_HUMAN_REVIEW = 'awaiting_human_review';
    public const ASSURED = 'assured';
    public const ASSURED_WITH_CONDITIONS = 'assured_with_conditions';
    public const INSUFFICIENT_EVIDENCE = 'insufficient_evidence';
    public const MATERIAL_DISAGREEMENT = 'material_disagreement';
    public const POLICY_BLOCKED = 'policy_blocked';
    public const FAILED = 'failed';
    public const EXPIRED = 'expired';
    public const SUPERSEDED = 'superseded';
    public const CANCELLED = 'cancelled';

    public static function all(): array
    {
        return [
            self::PENDING,
            self::QUEUED,
            self::RUNNING,
            self::EVALUATING,
            self::COLLECTING_EVIDENCE,
            self::ANALYSING,
            self::CHALLENGING,
            self::AWAITING_HUMAN_REVIEW,
            self::ASSURED,
            self::ASSURED_WITH_CONDITIONS,
            self::INSUFFICIENT_EVIDENCE,
            self::MATERIAL_DISAGREEMENT,
            self::POLICY_BLOCKED,
            self::FAILED,
            self::EXPIRED,
            self::SUPERSEDED,
            self::CANCELLED,
        ];
    }
}
