<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Providers;

use App\Extensions\TitanAssurance\System\Exceptions\AssuranceProviderException;
use App\Helpers\Classes\ApiHelper;
use App\Models\Setting;
use Closure;

final class MagicAIProviderRequestFactory
{
    private Closure $credentialResolver;
    private Closure $settingResolver;
    private Closure $configResolver;

    public function __construct(
        ?callable $credentialResolver = null,
        ?callable $settingResolver = null,
        ?callable $configResolver = null,
    ) {
        $this->credentialResolver = Closure::fromCallable($credentialResolver ?? function (string $provider): string {
            $settings = Setting::getCache();
            return match ($provider) {
                'openai' => (string) ApiHelper::setOpenAiKey($settings),
                'anthropic' => (string) ApiHelper::setAnthropicKey($settings),
                'gemini' => (string) ApiHelper::setGeminiKey($settings),
                'deepseek' => (string) ApiHelper::setDeepseekKey($settings),
                'xai' => (string) ApiHelper::setXAiKey($settings),
                default => '',
            };
        });
        $this->settingResolver = Closure::fromCallable($settingResolver ?? static fn (string $key, mixed $default = null): mixed => setting($key, $default));
        $this->configResolver = Closure::fromCallable($configResolver ?? static fn (string $key, mixed $default = null): mixed => config($key, $default));
    }

    /** @return array{url:string,headers:array<string,string>,body:array} */
    public function build(string $providerKey, string $modelId, array $request): array
    {
        $provider = strtolower(trim($providerKey));
        $credential = fn (string $key): string => (string) ($this->credentialResolver)($key);

        return match ($provider) {
            'openai' => [
                'url' => 'https://api.openai.com/v1/chat/completions',
                'headers' => ['Authorization' => 'Bearer ' . $credential('openai')],
                'body' => $request,
            ],
            'anthropic' => [
                'url' => 'https://api.anthropic.com/v1/messages',
                'headers' => [
                    'x-api-key' => $credential('anthropic'),
                    'anthropic-version' => '2023-06-01',
                ],
                'body' => $request,
            ],
            'gemini' => [
                'url' => sprintf(
                    'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s',
                    rawurlencode($modelId),
                    rawurlencode($credential('gemini')),
                ),
                'headers' => [],
                'body' => $request,
            ],
            'deepseek' => [
                'url' => 'https://api.deepseek.com/chat/completions',
                'headers' => ['Authorization' => 'Bearer ' . $credential('deepseek')],
                'body' => $request,
            ],
            'xai' => [
                'url' => 'https://api.x.ai/v1/chat/completions',
                'headers' => ['Authorization' => 'Bearer ' . $credential('xai')],
                'body' => $request,
            ],
            'openrouter' => [
                'url' => 'https://openrouter.ai/api/v1/chat/completions',
                'headers' => [
                    'Authorization' => 'Bearer ' . (string) ($this->settingResolver)('open_router_api', ''),
                    'HTTP-Referer' => (string) ($this->configResolver)('app.url', ''),
                    'X-Title' => (string) ($this->configResolver)('app.name', 'MagicAI'),
                ],
                'body' => $request,
            ],
            default => throw new AssuranceProviderException("Unsupported provider transport: {$provider}", 'terminal'),
        };
    }
}
