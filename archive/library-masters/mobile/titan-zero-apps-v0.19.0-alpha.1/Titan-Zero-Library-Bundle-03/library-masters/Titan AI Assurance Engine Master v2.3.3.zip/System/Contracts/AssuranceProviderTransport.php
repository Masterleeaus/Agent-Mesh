<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Contracts;

interface AssuranceProviderTransport
{
    /**
     * @return array{status:int, body:mixed, response_time_ms:int}
     */
    public function send(string $providerKey, string $modelId, array $request): array;
}
