<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Rules;

final class FieldHomeServicesRulePack extends CoreRulePack
{
    public function key(): string { return 'field_home_services.v1'; }

    protected function contextNumericThresholds(): array
    {
        return [
            'quote_amount' => ['min' => 0],
            'invoice_amount' => ['min' => 0],
            'quantity' => ['min' => 0],
            'discount_percent' => ['min' => 0, 'max' => 100],
        ];
    }

    protected function contextDateOrderings(): array
    {
        return [['start' => 'scheduled_start_at', 'end' => 'scheduled_end_at']];
    }
}
