<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Events;

final class AssuranceAssessmentCompleted
{
    public function __construct(public readonly array $receipt)
    {
    }
}
