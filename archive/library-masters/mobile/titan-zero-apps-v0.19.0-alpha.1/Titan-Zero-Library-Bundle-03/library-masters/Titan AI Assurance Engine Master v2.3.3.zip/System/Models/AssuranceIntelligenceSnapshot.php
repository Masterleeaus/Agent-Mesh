<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class AssuranceIntelligenceSnapshot extends Model
{
    protected $table = 'assurance_intelligence_snapshots';

    protected $guarded = ['id', 'company_id', 'created_at', 'updated_at'];

    protected $casts = [
        'filters' => 'array',
        'metrics' => 'array',
        'recommendations' => 'array',
        'generated_at' => 'datetime',
    ];

    public function scopeForCompany(Builder $query, string $companyId): Builder
    {
        return $query->where($this->qualifyColumn('company_id'), $companyId);
    }
}
