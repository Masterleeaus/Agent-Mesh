<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Providers;

use App\Extensions\TitanAssurance\System\Contracts\AssuranceProviderAdapter;
use DomainException;

final class ProviderAdapterRegistry
{
    /** @var array<string, AssuranceProviderAdapter> */
    private array $adapters = [];

    /** @param iterable<AssuranceProviderAdapter> $adapters */
    public function __construct(iterable $adapters)
    {
        foreach ($adapters as $adapter) {
            $this->adapters[strtolower($adapter->providerKey())] = $adapter;
        }
    }

    public function for(string $provider, string $modelId): AssuranceProviderAdapter
    {
        $provider = strtolower(trim($provider));
        $adapter = $this->adapters[$provider] ?? null;

        if (! $adapter || ! $adapter->supports($modelId)) {
            throw new DomainException(sprintf('No assurance provider adapter supports %s/%s.', $provider, $modelId));
        }

        return $adapter;
    }

    public function keys(): array
    {
        return array_keys($this->adapters);
    }
}
