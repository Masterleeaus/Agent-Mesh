<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

final class DisagreementAnalyzer
{
    public function analyze(array $candidates): array
    {
        $answers = [];
        $riskFingerprints = [];
        $evidenceFingerprints = [];

        foreach ($candidates as $candidate) {
            $response = (array) ($candidate['structured_response'] ?? $candidate);
            if (isset($response['answer'])) {
                $answers[] = $this->normalize((string) $response['answer']);
            }
            $riskFingerprints[] = $this->fingerprint((array) ($response['risks'] ?? []));
            $evidenceFingerprints[] = $this->fingerprint((array) ($response['evidence'] ?? []));
        }

        $answerVariety = count(array_unique(array_filter($answers)));
        $riskVariety = count(array_unique(array_filter($riskFingerprints)));
        $evidenceVariety = count(array_unique(array_filter($evidenceFingerprints)));

        $score = min(100, max(0,
            ($answerVariety > 1 ? 60 : 0)
            + ($riskVariety > 1 ? 25 : 0)
            + ($evidenceVariety > 1 ? 15 : 0)
        ));

        return [
            'material' => $score >= 50,
            'score' => $score,
            'answer_disagreement' => $answerVariety > 1,
            'risk_disagreement' => $riskVariety > 1,
            'evidence_disagreement' => $evidenceVariety > 1,
        ];
    }

    private function normalize(string $value): string
    {
        return preg_replace('/\s+/', ' ', strtolower(trim($value))) ?: '';
    }

    private function fingerprint(array $value): string
    {
        $encoded = json_encode($this->sortRecursive($value), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        return hash('sha256', $encoded ?: '[]');
    }

    private function sortRecursive(array $value): array
    {
        foreach ($value as &$item) {
            if (is_array($item)) {
                $item = $this->sortRecursive($item);
            }
        }
        unset($item);
        if (! array_is_list($value)) {
            ksort($value);
        }
        return $value;
    }
}
