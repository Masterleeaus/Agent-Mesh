<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Http\Controllers;

use App\Extensions\TitanAssurance\System\Services\Assurance\CompanyContextResolver;
use App\Http\Controllers\Controller;
use App\Models\UserOpenaiChatMessage;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

class ModelCouncilController extends Controller
{
    public function __construct(private readonly CompanyContextResolver $companyContext)
    {
    }

    public function acceptResponse(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'messageId' => ['required', 'integer'],
        ]);

        $user = $request->user();
        if (! $user) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }

        $companyId = $this->companyContext->resolve($user);
        $hasCompanyColumn = Schema::hasColumn('user_openai_chat_messages', 'company_id');

        $query = UserOpenaiChatMessage::query()
            ->whereKey((int) $validated['messageId'])
            ->where('user_id', $user->getAuthIdentifier());

        if ($hasCompanyColumn && $companyId !== null) {
            $query->where(function (Builder $builder) use ($companyId) {
                $builder->where('company_id', $companyId)
                    ->orWhereNull('company_id'); // legacy rows are still user-scoped
            });
        }

        /** @var UserOpenaiChatMessage|null $message */
        $message = $query->first();
        if (! $message) {
            // Do not disclose whether an unowned record exists.
            return response()->json(['error' => 'Message not found'], 404);
        }

        if ($hasCompanyColumn && $message->getAttribute('company_id') !== null) {
            if ($companyId === null || (string) $message->getAttribute('company_id') !== (string) $companyId) {
                return response()->json(['error' => 'Message not found'], 404);
            }
        }

        $groupColumn = null;
        $groupValue = null;

        if (Schema::hasColumn('user_openai_chat_messages', 'assurance_run_uuid')) {
            $runUuid = trim((string) $message->getAttribute('assurance_run_uuid'));
            if ($runUuid !== '') {
                $groupColumn = 'assurance_run_uuid';
                $groupValue = $runUuid;
            }
        }

        if ($groupColumn === null) {
            $sharedUuid = trim((string) $message->getAttribute('shared_uuid'));
            if ($sharedUuid !== '') {
                $groupColumn = 'shared_uuid';
                $groupValue = $sharedUuid;
            }
        }

        if ($groupColumn === null || $groupValue === null) {
            return response()->json([
                'error' => 'A non-null council group or assurance run identifier is required.',
            ], 422);
        }

        DB::transaction(function () use ($message, $user, $companyId, $hasCompanyColumn, $groupColumn, $groupValue): void {
            $group = UserOpenaiChatMessage::query()
                ->where('user_id', $user->getAuthIdentifier())
                ->where($groupColumn, $groupValue);

            if ($hasCompanyColumn) {
                $messageCompanyId = $message->getAttribute('company_id');
                if ($messageCompanyId === null) {
                    $group->whereNull('company_id');
                } else {
                    $group->where('company_id', (string) $messageCompanyId);
                }
            }

            if (Schema::hasColumn('user_openai_chat_messages', 'is_council_selected')) {
                $group->update([
                    'is_council_selected' => false,
                    'council_selected_at' => null,
                    'council_selected_by' => null,
                ]);

                $message->forceFill([
                    'is_council_selected' => true,
                    'council_selected_at' => now(),
                    'council_selected_by' => $user->getAuthIdentifier(),
                ]);
            }
            $message->save();
        });

        Log::notice('Titan Assurance Engine candidate accepted', [
            'message_id' => $message->getKey(),
            'user_id' => $user->getAuthIdentifier(),
            'company_id' => $companyId,
            'group_type' => $groupColumn,
            'group_hash' => hash('sha256', (string) $groupValue),
        ]);

        return response()->json([
            'success' => true,
            'selected_message_id' => $message->getKey(),
            'alternatives_preserved' => true,
        ]);
    }
}
