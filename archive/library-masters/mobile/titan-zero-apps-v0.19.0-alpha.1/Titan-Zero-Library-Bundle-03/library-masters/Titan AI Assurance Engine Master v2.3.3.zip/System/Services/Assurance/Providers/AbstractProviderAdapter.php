<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Providers;

use App\Extensions\TitanAssurance\System\Contracts\AssuranceProviderAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Capabilities\ModelCapabilityRegistry;

abstract class AbstractProviderAdapter implements AssuranceProviderAdapter
{
    public function __construct(protected readonly ModelCapabilityRegistry $capabilityRegistry)
    {
    }

    public function supports(string $modelId): bool
    {
        return trim($modelId) !== '';
    }

    public function capabilities(string $modelId): array
    {
        return $this->capabilityRegistry->resolve($this->providerKey(), $modelId)['capabilities'];
    }

    public function buildRequest(string $modelId, array $messages, array $options = []): array
    {
        $request = [
            'model' => $modelId,
            'messages' => array_values($messages),
        ];

        foreach (['temperature', 'max_tokens', 'max_completion_tokens', 'response_format', 'tools', 'tool_choice'] as $key) {
            if (array_key_exists($key, $options)) {
                $request[$key] = $options[$key];
            }
        }

        return $request;
    }

    public function parseResponse(mixed $response): array
    {
        if (! is_array($response)) {
            return ['text' => (string) $response, 'usage' => [], 'raw' => $response];
        }

        $text = $response['text']
            ?? $response['output_text']
            ?? $response['choices'][0]['message']['content']
            ?? $response['content'][0]['text']
            ?? '';

        return [
            'text' => is_string($text) ? $text : json_encode($text, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'usage' => is_array($response['usage'] ?? null) ? $response['usage'] : [],
            'raw' => $response,
        ];
    }

    public function classifyRetry(mixed $error): string
    {
        $status = is_array($error) ? (int) ($error['status'] ?? $error['status_code'] ?? 0) : 0;

        return match (true) {
            in_array($status, [408, 409, 425, 429], true), $status >= 500 => 'retryable',
            in_array($status, [401, 403], true) => 'authentication',
            $status === 400 || $status === 422 => 'malformed_request',
            default => 'terminal',
        };
    }
}
