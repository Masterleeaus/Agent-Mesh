<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Rules;

final class SalonBeautyRulePack extends CoreRulePack
{
    public function key(): string { return 'salon_beauty.v1'; }

    protected function contextNumericThresholds(): array
    {
        return [
            'service_price' => ['min' => 0],
            'duration_minutes' => ['min' => 0],
            'quantity' => ['min' => 0],
            'discount_percent' => ['min' => 0, 'max' => 100],
        ];
    }

    protected function contextDateOrderings(): array
    {
        return [['start' => 'appointment_start_at', 'end' => 'appointment_end_at']];
    }
}
