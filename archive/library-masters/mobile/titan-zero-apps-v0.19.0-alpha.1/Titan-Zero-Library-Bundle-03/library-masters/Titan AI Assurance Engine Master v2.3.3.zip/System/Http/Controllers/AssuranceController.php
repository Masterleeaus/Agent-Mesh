<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Http\Controllers;

use App\Extensions\TitanAssurance\System\Contracts\AssuranceEngine;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Throwable;

final class AssuranceController extends Controller
{
    public function __construct(private readonly AssuranceEngine $engine)
    {
    }

    public function createRun(Request $request): JsonResponse
    {
        $decisionPacket = $request->input('decision_packet');
        if (! is_array($decisionPacket)) {
            return response()->json(['message' => 'decision_packet must be an object.'], 422);
        }

        try {
            $run = $this->engine->createRun($decisionPacket, (array) $request->input('options', []));
            return response()->json($this->resource($run), 201);
        } catch (DomainException $exception) {
            return $this->domainError($exception);
        }
    }

    public function lockEvidence(Request $request, int $runId): JsonResponse
    {
        $evidence = $request->input('evidence_packet');
        if (! is_array($evidence)) {
            return response()->json(['message' => 'evidence_packet must be an object.'], 422);
        }

        try {
            return response()->json($this->resource($this->engine->lockEvidence($runId, $evidence)));
        } catch (DomainException $exception) {
            return $this->domainError($exception);
        }
    }

    public function start(Request $request, int $runId): JsonResponse
    {
        $panel = $request->input('panel');
        if (! is_array($panel) || $panel === []) {
            return response()->json(['message' => 'panel must contain at least one provider/model candidate.'], 422);
        }

        try {
            return response()->json($this->resource($this->engine->start($runId, $panel, (array) $request->input('options', []))), 202);
        } catch (DomainException $exception) {
            return $this->domainError($exception);
        }
    }

    public function show(int $runId): JsonResponse
    {
        $run = $this->engine->findRun($runId);
        return response()->json($this->resource($run, true));
    }

    public function decision(Request $request, int $runId): JsonResponse
    {
        $decision = trim((string) $request->input('decision', ''));
        $reason = trim((string) $request->input('reason', ''));

        try {
            return response()->json($this->resource($this->engine->approve(
                $runId,
                $decision,
                $reason,
                (array) $request->input('conditions', []),
            )));
        } catch (DomainException $exception) {
            return $this->domainError($exception);
        }
    }

    public function cancel(Request $request, int $runId): JsonResponse
    {
        try {
            return response()->json($this->resource($this->engine->cancel(
                $runId,
                $request->filled('reason') ? (string) $request->input('reason') : null,
            )));
        } catch (DomainException $exception) {
            return $this->domainError($exception);
        }
    }

    public function recordOutcome(Request $request, int $runId): JsonResponse
    {
        try {
            $outcome = $this->engine->recordOutcome($runId, $request->only([
                'outcome_type', 'success', 'impact', 'correction',
            ]));
            return response()->json(method_exists($outcome, 'toArray') ? $outcome->toArray() : (array) $outcome, 201);
        } catch (DomainException $exception) {
            return $this->domainError($exception);
        }
    }

    public function calibration(Request $request): JsonResponse
    {
        try {
            return response()->json($this->engine->calibration($request->only([
                'policy_version', 'risk_level', 'assurance_mode', 'vertical', 'decision_type',
            ])));
        } catch (DomainException $exception) {
            return $this->domainError($exception);
        }
    }

    public function intelligence(Request $request): JsonResponse
    {
        try {
            return response()->json($this->engine->intelligence($request->only([
                'policy_version', 'risk_level', 'assurance_mode', 'vertical', 'decision_type', 'rule_pack_key',
                'recent_window', 'minimum_cohort',
            ])));
        } catch (DomainException $exception) {
            return $this->domainError($exception);
        }
    }

    public function intelligenceRecommendations(Request $request): JsonResponse
    {
        try {
            return response()->json($this->engine->recommendations($request->only([
                'policy_version', 'risk_level', 'assurance_mode', 'vertical', 'decision_type', 'rule_pack_key',
                'recent_window', 'minimum_cohort',
            ])));
        } catch (DomainException $exception) {
            return $this->domainError($exception);
        }
    }

    private function resource(mixed $run, bool $withRelations = false): array
    {
        if ($withRelations && method_exists($run, 'loadMissing')) {
            $run->loadMissing(['candidates', 'findings', 'approvals', 'outcomes']);
        }

        return method_exists($run, 'toArray') ? $run->toArray() : (array) $run;
    }

    private function domainError(DomainException $exception): JsonResponse
    {
        return response()->json(['message' => $exception->getMessage()], 422);
    }
}
