<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Integration;

use Throwable;

final class TitanSignalIntegrationRegistrar
{
    private const REGISTRY_AUTHORITY = 'App\\Extensions\\TitanSignalEngine\\System\\Contracts\\SignalRegistryAuthorityContract';
    private const EVENT_REGISTRY = 'App\\Extensions\\TitanSignalEngine\\System\\Contracts\\EventTypeRegistryContract';
    private const EVENT_DEFINITION = 'App\\Extensions\\TitanSignalEngine\\System\\Data\\EventTypeDefinition';

    public function __construct(
        private readonly object $container,
        private readonly TitanSignalIntegrationProfile $profile,
    ) {
    }

    /** @return array<string,mixed> */
    public function ensureRegistered(): array
    {
        foreach ([self::REGISTRY_AUTHORITY, self::EVENT_REGISTRY] as $contract) {
            if (! interface_exists($contract)) {
                return $this->unavailable('SIGNAL_CONTRACT_NOT_INSTALLED', $contract);
            }
            if (! $this->bound($contract)) {
                return $this->unavailable('SIGNAL_CONTRACT_NOT_BOUND', $contract);
            }
        }
        if (! class_exists(self::EVENT_DEFINITION)) {
            return $this->unavailable('SIGNAL_EVENT_DEFINITION_CLASS_NOT_INSTALLED', self::EVENT_DEFINITION);
        }

        try {
            $authority = $this->make(self::REGISTRY_AUTHORITY);
            $registry = $this->make(self::EVENT_REGISTRY);
            $identity = $authority->issue($this->profile->registryServiceId());
            $registered = [];
            $existing = [];

            foreach ($this->profile->eventDefinitions() as $eventType => $definitionData) {
                $current = $registry->find($eventType);
                if ($current !== null) {
                    if (! $this->compatibleOwner($current)) {
                        return [
                            'ready' => false,
                            'reason_code' => 'SIGNAL_EVENT_OWNERSHIP_CONFLICT',
                            'event_type' => $eventType,
                        ];
                    }
                    $existing[] = $eventType;
                    continue;
                }

                $definitionClass = self::EVENT_DEFINITION;
                $definition = $definitionClass::fromArray(['event_type' => $eventType, ...$definitionData]);
                $registry->register($definition, $identity, $this->profile->registryServiceId());
                $registered[] = $eventType;
            }

            return [
                'ready' => true,
                'reason_code' => 'SIGNAL_EVENT_TYPES_READY',
                'registered' => $registered,
                'existing' => $existing,
            ];
        } catch (Throwable $exception) {
            return [
                'ready' => false,
                'reason_code' => 'SIGNAL_EVENT_REGISTRATION_FAILED',
                'error_class' => $exception::class,
            ];
        }
    }

    private function compatibleOwner(object $definition): bool
    {
        $owner = null;
        if (property_exists($definition, 'ownerSource')) {
            $owner = $definition->ownerSource;
        } elseif (property_exists($definition, 'data') && is_array($definition->data ?? null)) {
            $owner = $definition->data['owner_source'] ?? null;
        } elseif (method_exists($definition, 'toArray')) {
            $owner = $definition->toArray()['owner_source'] ?? null;
        }

        return $owner === null || trim((string) $owner) === TitanSignalIntegrationProfile::OWNER_SOURCE;
    }

    private function bound(string $contract): bool
    {
        return method_exists($this->container, 'bound') && (bool) $this->container->bound($contract);
    }

    private function make(string $contract): mixed
    {
        if (! method_exists($this->container, 'make')) {
            throw new \RuntimeException('Container does not support make().');
        }

        return $this->container->make($contract);
    }

    /** @return array<string,mixed> */
    private function unavailable(string $reasonCode, string $contract): array
    {
        return [
            'ready' => false,
            'reason_code' => $reasonCode,
            'contract' => $contract,
        ];
    }
}
