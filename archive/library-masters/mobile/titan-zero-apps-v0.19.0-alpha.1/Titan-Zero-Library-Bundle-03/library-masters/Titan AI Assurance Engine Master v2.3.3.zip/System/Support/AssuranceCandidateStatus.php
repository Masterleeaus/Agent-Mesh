<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Support;

final class AssuranceCandidateStatus
{
    public const PENDING = 'pending';
    public const QUEUED = 'queued';
    public const RUNNING = 'running';
    public const COMPLETED = 'completed';
    public const RETRYABLE_FAILED = 'retryable_failed';
    public const FAILED = 'failed';
    public const CANCELLED = 'cancelled';

    public static function terminal(): array
    {
        return [self::COMPLETED, self::FAILED, self::CANCELLED];
    }
}
