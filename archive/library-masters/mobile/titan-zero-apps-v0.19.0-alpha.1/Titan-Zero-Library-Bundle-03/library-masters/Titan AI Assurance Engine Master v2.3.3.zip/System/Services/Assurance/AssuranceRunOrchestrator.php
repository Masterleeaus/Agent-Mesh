<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

use App\Extensions\TitanAssurance\System\Jobs\ExecuteAssuranceCandidate;
use App\Extensions\TitanAssurance\System\Models\AssuranceCandidate;
use App\Extensions\TitanAssurance\System\Models\AssuranceRun;
use App\Extensions\TitanAssurance\System\Services\Assurance\Capabilities\ModelIdentityResolver;
use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\CostEstimator;
use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\CostReservationService;
use App\Extensions\TitanAssurance\System\Support\AssuranceCandidateStatus;
use App\Extensions\TitanAssurance\System\Support\AssuranceMode;
use App\Extensions\TitanAssurance\System\Support\AssuranceStatus;
use DomainException;
use Illuminate\Support\Facades\DB;

final class AssuranceRunOrchestrator
{
    public function __construct(
        private readonly ModelIdentityResolver $identityResolver,
        private readonly PanelSelectionService $panelSelection,
        private readonly CostEstimator $costEstimator,
        private readonly CostReservationService $costReservation,
        private readonly AssuranceAuditService $audit,
    ) {
    }

    public function start(AssuranceRun $run, array $panel, array $options = []): AssuranceRun
    {
        if (empty($run->evidence_hash)) {
            throw new DomainException('Evidence must be locked before an assurance run can start.');
        }
        if ($run->candidates()->where('assigned_role', '!=', 'adversarial_challenger')->exists()) {
            return $run->fresh();
        }

        $normalized = [];
        foreach (array_values($panel) as $index => $candidate) {
            $provider = (string) ($candidate['provider'] ?? $candidate['provider_key'] ?? '');
            $modelId = (string) ($candidate['model_id'] ?? $candidate['model'] ?? '');
            if ($provider === '' || $modelId === '') {
                throw new DomainException('Each assurance panel candidate requires provider and model_id.');
            }
            $identity = $this->identityResolver->resolve($provider, $modelId, isset($candidate['snapshot']) ? (string) $candidate['snapshot'] : null);
            $normalized[] = $identity + [
                'assigned_role' => (string) ($candidate['assigned_role'] ?? 'independent_reviewer_' . ($index + 1)),
                'estimated_cost' => max(0.0, (float) ($candidate['estimated_cost'] ?? 0)),
            ];
        }

        $panelResult = $this->panelSelection->validate($normalized, (string) $run->assurance_mode);
        if (! $panelResult['valid']) {
            $run->status = AssuranceStatus::POLICY_BLOCKED;
            $run->permission_state = 'blocked';
            $run->failure_code = 'panel_policy_failed';
            $run->panel_spec = ['candidates' => $normalized, 'validation' => $panelResult];
            $run->independence_score = (float) $panelResult['independence']['score'];
            $run->provider_count = (int) $panelResult['provider_count'];
            $run->family_count = (int) $panelResult['family_count'];
            $run->completed_at = now();
            $run->save();
            $this->audit->record($run, 'AssurancePanelRejected', $panelResult);
            return $run->fresh();
        }

        $challengeRequired = in_array((string) $run->assurance_mode, [AssuranceMode::HIGH, AssuranceMode::CRITICAL], true)
            || (bool) ($options['challenge_required'] ?? false);
        $cost = $this->costEstimator->estimate($normalized, [
            'challenge_estimated_cost' => $challengeRequired ? (float) ($options['challenge_estimated_cost'] ?? 0) : 0,
            'synthesis_estimated_cost' => (float) ($options['synthesis_estimated_cost'] ?? 0),
            'currency' => (string) ($options['currency'] ?? 'USD'),
        ]);
        $reservation = $this->costReservation->decision((float) $cost['estimated_cost'], isset($options['budget_ceiling']) ? (float) $options['budget_ceiling'] : null);
        if (! $reservation['reserved']) {
            $run->status = AssuranceStatus::POLICY_BLOCKED;
            $run->permission_state = 'blocked';
            $run->failure_code = 'budget_ceiling_exceeded';
            $run->estimated_cost = (float) $cost['estimated_cost'];
            $run->reserved_cost = 0;
            $run->currency = $cost['currency'];
            $run->completed_at = now();
            $run->save();
            $this->audit->record($run, 'AssuranceCostReservationRejected', ['cost' => $cost, 'budget_ceiling' => $options['budget_ceiling'] ?? null]);
            return $run->fresh();
        }

        $candidateIds = DB::transaction(function () use ($run, $normalized, $panelResult, $challengeRequired, $cost, $reservation, $options): array {
            /** @var AssuranceRun $lockedRun */
            $lockedRun = AssuranceRun::query()
                ->where('company_id', (string) $run->company_id)
                ->whereKey($run->id)
                ->lockForUpdate()
                ->firstOrFail();
            if ($lockedRun->candidates()->where('assigned_role', '!=', 'adversarial_challenger')->exists()) {
                return [];
            }
            $run = $lockedRun;
            $run->panel_spec = [
                'candidates' => $normalized,
                'challenge_model' => $options['challenge_model'] ?? null,
            ];
            $run->independence_score = (float) $panelResult['independence']['score'];
            $run->provider_count = (int) $panelResult['provider_count'];
            $run->family_count = (int) $panelResult['family_count'];
            $run->challenge_required = $challengeRequired;
            $run->estimated_cost = (float) $cost['estimated_cost'];
            $run->reserved_cost = (float) $reservation['reserved_cost'];
            $run->currency = $cost['currency'];
            $run->status = AssuranceStatus::QUEUED;
            $run->permission_state = 'blocked';
            $run->queued_at = now();
            $run->save();

            $ids = [];
            foreach ($normalized as $candidateSpec) {
                $candidate = new AssuranceCandidate();
                $candidate->company_id = $run->company_id;
                $candidate->assurance_run_id = $run->id;
                $candidate->provider_key = $candidateSpec['provider'];
                $candidate->model_id = $candidateSpec['model_id'];
                $candidate->model_snapshot = $candidateSpec['snapshot'];
                $candidate->model_family = $candidateSpec['family'];
                $candidate->candidate_identity = $candidateSpec['identity'];
                $candidate->assigned_role = $candidateSpec['assigned_role'];
                $candidate->prompt_version = 'titan-assurance-candidate-v1';
                $candidate->capabilities = $candidateSpec['capabilities'];
                $candidate->status = AssuranceCandidateStatus::QUEUED;
                $candidate->queued_at = now();
                $candidate->save();
                $ids[] = $candidate->id;
            }
            return $ids;
        });

        if ($candidateIds === []) {
            return $run->fresh();
        }

        $this->audit->record($run->fresh(), 'AssuranceRunQueued', [
            'candidate_count' => count($candidateIds),
            'estimated_cost' => $cost['estimated_cost'],
            'currency' => $cost['currency'],
        ]);

        foreach ($candidateIds as $candidateId) {
            ExecuteAssuranceCandidate::dispatch($candidateId, (string) $run->company_id)->onQueue((string) config('model-council.assurance.queue', 'assurance'));
        }

        return $run->fresh();
    }

    public function dispatchChallenge(int $runId, string $companyId): ?AssuranceCandidate
    {
        /** @var AssuranceRun $run */
        $run = AssuranceRun::query()
            ->with('candidates')
            ->where('company_id', $companyId)
            ->whereKey($runId)
            ->firstOrFail();
        if (! $run->challenge_required) {
            return null;
        }
        $existing = $run->candidates->firstWhere('assigned_role', 'adversarial_challenger');
        if ($existing instanceof AssuranceCandidate) {
            return $existing;
        }

        $spec = (array) (($run->panel_spec['challenge_model'] ?? null) ?: $this->fallbackChallengeModel((array) ($run->panel_spec['candidates'] ?? [])));
        if ($spec === [] || empty($spec['provider']) || empty($spec['model_id'])) {
            $run->status = AssuranceStatus::POLICY_BLOCKED;
            $run->failure_code = 'challenge_model_unavailable';
            $run->permission_state = 'blocked';
            $run->completed_at = now();
            $run->save();
            $this->audit->record($run, 'AssuranceChallengeUnavailable');
            return null;
        }

        $identity = $this->identityResolver->resolve((string) $spec['provider'], (string) $spec['model_id'], isset($spec['snapshot']) ? (string) $spec['snapshot'] : null);
        $candidate = new AssuranceCandidate();
        $candidate->company_id = $run->company_id;
        $candidate->assurance_run_id = $run->id;
        $candidate->provider_key = $identity['provider'];
        $candidate->model_id = $identity['model_id'];
        $candidate->model_snapshot = $identity['snapshot'];
        $candidate->model_family = $identity['family'];
        $candidate->candidate_identity = $identity['identity'] . ':challenge';
        $candidate->assigned_role = 'adversarial_challenger';
        $candidate->prompt_version = 'titan-assurance-challenge-v1';
        $candidate->capabilities = $identity['capabilities'];
        $candidate->status = AssuranceCandidateStatus::QUEUED;
        $candidate->queued_at = now();
        $candidate->save();

        $run->status = AssuranceStatus::CHALLENGING;
        $run->save();
        $this->audit->record($run, 'AssuranceChallengeQueued', ['candidate_id' => $candidate->id, 'model' => $candidate->candidate_identity]);

        ExecuteAssuranceCandidate::dispatch($candidate->id, (string) $run->company_id)->onQueue((string) config('model-council.assurance.queue', 'assurance'));
        return $candidate;
    }

    private function fallbackChallengeModel(array $panel): array
    {
        if ($panel === []) {
            return [];
        }
        $first = $panel[0];
        foreach (array_reverse($panel) as $candidate) {
            if (($candidate['family'] ?? null) !== ($first['family'] ?? null) || ($candidate['provider'] ?? null) !== ($first['provider'] ?? null)) {
                return $candidate;
            }
        }
        return $first;
    }
}
