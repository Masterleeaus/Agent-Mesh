<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Commands;

use Illuminate\Console\Command;

final class CertifyExtensionCommand extends Command
{
    protected $signature = 'titan:titan-assurance:certify';

    protected $description = 'Verify Titan Assurance local package/runtime prerequisites without claiming host certification.';

    public function handle(): int
    {
        $root = dirname(__DIR__, 3);
        $required = [
            $root . '/extension.json',
            $root . '/extension.manifest.json',
            $root . '/titan-capabilities.json',
            $root . '/config/model-council.php',
        ];

        $missing = array_values(array_filter($required, static fn (string $path): bool => ! is_file($path)));
        if ($missing !== []) {
            foreach ($missing as $path) {
                $this->error('Missing required Assurance artifact: ' . $path);
            }
            return self::FAILURE;
        }

        $installer = json_decode((string) file_get_contents($root . '/extension.json'), true);
        $blueprint = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true);
        if (($installer['schema'] ?? null) !== 'titan-extension-v1' || ($blueprint['schema_version'] ?? null) !== '2.2') {
            $this->error('Titan Assurance manifest contracts are not aligned to Installer 1.7.8 / Blueprint Manifest v2.2.');
            return self::FAILURE;
        }

        $this->info('Titan Assurance source/runtime prerequisites verified. Live host certification remains a separate stage.');
        return self::SUCCESS;
    }
}
