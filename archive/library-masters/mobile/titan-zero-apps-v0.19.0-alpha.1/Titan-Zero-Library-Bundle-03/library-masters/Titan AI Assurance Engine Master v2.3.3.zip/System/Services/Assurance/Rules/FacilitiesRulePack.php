<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Rules;

final class FacilitiesRulePack extends CoreRulePack
{
    public function key(): string { return 'facilities.v1'; }

    protected function contextNumericThresholds(): array
    {
        return [
            'contract_value' => ['min' => 0],
            'quantity' => ['min' => 0],
            'compliance_percent' => ['min' => 0, 'max' => 100],
        ];
    }

    protected function contextDateOrderings(): array
    {
        return [['start' => 'service_start_at', 'end' => 'service_end_at']];
    }
}
