<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AssuranceEvidenceRecord extends Model
{
    protected $table = 'assurance_evidence_records';

    protected $guarded = ['id', 'company_id', 'assurance_assessment_id', 'created_at', 'updated_at'];

    protected $casts = [
        'subject' => 'array',
        'provenance' => 'array',
        'scope' => 'array',
        'content' => 'array',
        'contradicts' => 'array',
        'knowledge_reference' => 'array',
        'freshness' => 'float',
        'confidence' => 'float',
        'authority' => 'float',
        'relevance' => 'float',
        'applicability' => 'float',
        'provenance_confidence' => 'float',
        'contradiction_adjustment' => 'float',
        'weight_score' => 'float',
        'captured_at' => 'datetime',
        'effective_at' => 'datetime',
        'expires_at' => 'datetime',
    ];

    public function assessment(): BelongsTo
    {
        return $this->belongsTo(AssuranceAssessment::class, 'assurance_assessment_id');
    }
}
