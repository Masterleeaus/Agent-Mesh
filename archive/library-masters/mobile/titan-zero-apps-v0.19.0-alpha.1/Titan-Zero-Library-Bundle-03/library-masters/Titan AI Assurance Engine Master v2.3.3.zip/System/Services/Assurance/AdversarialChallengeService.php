<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

final class AdversarialChallengeService
{
    public function buildPacket(array $decisionPacket, array $candidates, array $findings = []): array
    {
        return [
            'instruction' => 'Act as an adversarial assurance reviewer. Identify unsupported claims, hidden assumptions, contradictory evidence, safety/compliance risks, and reasons the leading recommendation could fail. Do not optimize for agreement.',
            'decision_packet' => $decisionPacket,
            'candidate_claims' => array_map(static fn (array $candidate) => (array) (($candidate['structured_response']['claims'] ?? $candidate['claims'] ?? [])), $candidates),
            'existing_findings' => $findings,
            'required_output' => ['challenges', 'counter_evidence', 'residual_risks', 'recommendation'],
        ];
    }
}
