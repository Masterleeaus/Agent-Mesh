<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Contracts;

use App\Extensions\TitanAssurance\System\Models\AssuranceAssessment;
use App\Extensions\TitanAssurance\System\Models\AssuranceFeedback;

interface EvidenceAssuranceEngine
{
    public function assess(array $request): AssuranceAssessment;

    public function findAssessment(int $assessmentId): AssuranceAssessment;

    public function recordFeedback(int $assessmentId, array $payload): AssuranceFeedback;
}
