<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Contracts;

interface DeterministicRulePack
{
    public function key(): string;

    public function version(): string;

    public function rules(array $context = []): array;
}
