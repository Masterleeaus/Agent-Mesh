<?php
declare(strict_types=1);
namespace App\Extensions\TitanAssurance\System\Workforce;
final class ProviderHealthGate { public function evaluate(array $health): array { foreach(['provider_present','version_match','contract_parseable','dependencies_ready'] as $k) { if(($health[$k]??false)!==true) return ['availability'=>'unavailable','decision'=>'deny','reason_codes'=>['health.'.$k.'.failed']]; } return ['availability'=>'available','decision'=>'not_applicable','reason_codes'=>[]]; } }
