<?php
declare(strict_types=1);
namespace App\Extensions\TitanAssurance\System\Workforce;
final class CallbackDurableIdempotencyRegistry implements DurableIdempotencyRegistry {
 public function __construct(private \Closure $claimFn,private \Closure $completeFn,private \Closure $failFn) {}
 public function claim(string $companyId,string $key,string $fingerprint): array { return ($this->claimFn)($companyId,$key,$fingerprint); }
 public function complete(string $companyId,string $key,array $receipt): void { ($this->completeFn)($companyId,$key,$receipt); }
 public function fail(string $companyId,string $key,string $reason): void { ($this->failFn)($companyId,$key,$reason); }
}
