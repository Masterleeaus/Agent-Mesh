<?php
declare(strict_types=1);
namespace App\Extensions\TitanAssurance\System\Workforce;
interface GuardrailDecisionAdapter { public function stage(): string; public function evaluate(array $request): array; }
