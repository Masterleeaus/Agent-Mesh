<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

use App\Extensions\TitanAssurance\System\Support\AssuranceMode;
use App\Extensions\TitanAssurance\System\Support\RiskLevel;

class RiskClassificationService
{
    public function classify(array $decisionPacket, array $overrides = []): array
    {
        $severity = $this->score($overrides['severity'] ?? $decisionPacket['severity'] ?? 1);
        $likelihood = $this->score($overrides['likelihood'] ?? $decisionPacket['likelihood'] ?? 1);
        $reversibility = $this->score($overrides['reversibility'] ?? $decisionPacket['reversibility'] ?? 1);
        $legalSensitivity = $this->score($overrides['legal_compliance_sensitivity'] ?? $decisionPacket['legal_compliance_sensitivity'] ?? 0);
        $financialExposure = max(0.0, (float) ($overrides['financial_exposure'] ?? $decisionPacket['financial_exposure'] ?? 0));
        $irreversible = (bool) ($overrides['irreversible'] ?? $decisionPacket['irreversible'] ?? false);
        $safetyCritical = (bool) ($overrides['safety_critical'] ?? $decisionPacket['safety_critical'] ?? false);

        $weighted = ($severity * 2) + $likelihood + $reversibility + ($legalSensitivity * 2);

        if ($safetyCritical || $irreversible || $weighted >= 16 || $financialExposure >= (float) config('model-council.assurance.risk.critical_financial_threshold', 50000)) {
            $level = RiskLevel::CRITICAL;
            $mode = AssuranceMode::CRITICAL;
        } elseif ($weighted >= 11 || $financialExposure >= (float) config('model-council.assurance.risk.red_financial_threshold', 10000)) {
            $level = RiskLevel::RED;
            $mode = AssuranceMode::HIGH;
        } elseif ($weighted >= 6 || $financialExposure >= (float) config('model-council.assurance.risk.amber_financial_threshold', 1000)) {
            $level = RiskLevel::AMBER;
            $mode = AssuranceMode::STANDARD;
        } else {
            $level = RiskLevel::GREEN;
            $mode = AssuranceMode::STANDARD;
        }

        $namedApproverIds = array_values(array_unique(array_filter(array_map(
            static fn ($id) => (int) $id,
            (array) ($overrides['named_approver_ids'] ?? $decisionPacket['named_approver_ids'] ?? [])
        ), static fn (int $id) => $id > 0)));

        return [
            'risk_level' => $level,
            'required_assurance_mode' => $mode,
            'severity' => $severity,
            'likelihood' => $likelihood,
            'reversibility' => $reversibility,
            'legal_compliance_sensitivity' => $legalSensitivity,
            'financial_exposure' => $financialExposure,
            'automation_permission' => in_array($level, [RiskLevel::GREEN, RiskLevel::AMBER], true) ? 'conditional' : 'blocked',
            'required_human_role' => $level === RiskLevel::CRITICAL ? 'named_approver' : ($level === RiskLevel::RED ? 'authorised_reviewer' : null),
            'named_approver_ids' => $namedApproverIds,
        ];
    }

    private function score(mixed $value): int
    {
        return max(0, min(5, (int) $value));
    }
}
