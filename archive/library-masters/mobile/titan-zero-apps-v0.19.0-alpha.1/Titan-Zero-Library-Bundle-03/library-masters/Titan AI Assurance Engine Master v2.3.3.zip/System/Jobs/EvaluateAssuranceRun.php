<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Jobs;

use App\Extensions\TitanAssurance\System\Services\Assurance\AssuranceRunEvaluator;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class EvaluateAssuranceRun implements ShouldQueue, ShouldBeUnique
{
    public bool $afterCommit = true;

    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $uniqueFor = 30;

    public function __construct(
        public readonly int $runId,
        public readonly string $companyId,
    ) {
    }

    public function uniqueId(): string
    {
        return 'assurance-evaluate:' . $this->companyId . ':' . $this->runId;
    }

    public function handle(AssuranceRunEvaluator $evaluator): void
    {
        $result = $evaluator->evaluate($this->runId, $this->companyId);
        if (($result['state'] ?? null) === 'challenge_required') {
            ChallengeAssuranceRun::dispatch($this->runId, $this->companyId)
                ->onQueue((string) config('model-council.assurance.queue', 'assurance'));
        }
    }
}
