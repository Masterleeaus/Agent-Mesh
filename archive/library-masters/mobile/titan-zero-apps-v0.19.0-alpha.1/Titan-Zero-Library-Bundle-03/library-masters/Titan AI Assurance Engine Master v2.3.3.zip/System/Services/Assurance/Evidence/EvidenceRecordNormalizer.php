<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Evidence;

use DateTimeImmutable;
use DomainException;

final class EvidenceRecordNormalizer
{
    public function normalize(array $evidence, ?DateTimeImmutable $now = null): array
    {
        $now ??= new DateTimeImmutable('now');

        $type = trim((string) ($evidence['evidence_type'] ?? $evidence['type'] ?? ''));
        $subject = $evidence['subject'] ?? null;
        $source = trim((string) ($evidence['source'] ?? ''));
        if ($type === '' || $subject === null || $subject === '' || $source === '') {
            throw new DomainException('Evidence requires evidence_type, subject and source.');
        }

        $provenance = is_array($evidence['provenance'] ?? null) ? $evidence['provenance'] : [];
        $capturedAt = $this->date($evidence['captured_at'] ?? null, 'captured_at');
        $effectiveAt = $this->date($evidence['effective_at'] ?? null, 'effective_at');
        $expiresAt = $this->date($evidence['expires_at'] ?? null, 'expires_at');
        if ($effectiveAt && $expiresAt && $expiresAt < $effectiveAt) {
            throw new DomainException('Evidence expires_at cannot be before effective_at.');
        }

        $confidence = $this->factor($evidence['confidence'] ?? 1.0, 1.0);
        $authority = $this->authority($evidence['authority'] ?? 0.5);
        $relevance = $this->factor($evidence['relevance'] ?? 1.0, 1.0);
        $applicability = $this->factor($evidence['applicability'] ?? 1.0, 1.0);
        $provenanceConfidence = $this->factor(
            $evidence['provenance_confidence'] ?? $provenance['confidence'] ?? $confidence,
            $confidence,
        );
        $freshness = array_key_exists('freshness', $evidence)
            ? $this->factor($evidence['freshness'], 1.0)
            : $this->freshness($capturedAt, $effectiveAt, $expiresAt, $evidence, $now);

        $verification = strtolower(trim((string) ($evidence['verification_state'] ?? 'unverified')));
        $contradicts = array_values(array_unique(array_filter(array_map('strval', (array) ($evidence['contradicts'] ?? [])))));
        $defaultContradictionAdjustment = $contradicts !== [] ? 0.5 : 1.0;
        $contradictionAdjustment = $this->factor($evidence['contradiction_adjustment'] ?? $defaultContradictionAdjustment, $defaultContradictionAdjustment);
        if (in_array($verification, ['rejected', 'invalid', 'tampered'], true)) {
            $contradictionAdjustment = 0.0;
        }

        $canonicalForHash = [
            'evidence_type' => $type,
            'subject' => $subject,
            'source' => $source,
            'provenance' => $provenance,
            'captured_at' => $capturedAt?->format(DATE_ATOM),
            'effective_at' => $effectiveAt?->format(DATE_ATOM),
            'expires_at' => $expiresAt?->format(DATE_ATOM),
            'confidence' => $confidence,
            'authority' => $authority,
            'jurisdiction' => $this->nullableString($evidence['jurisdiction'] ?? null),
            'vertical' => $this->nullableString($evidence['vertical'] ?? null),
            'scope' => is_array($evidence['scope'] ?? null) ? $evidence['scope'] : ($evidence['scope'] ?? null),
            'verification_state' => $verification,
            'content' => $evidence['content'] ?? $evidence['value'] ?? null,
        ];
        $hash = strtolower(trim((string) ($evidence['hash'] ?? '')));
        if ($hash === '') {
            $hash = hash('sha256', json_encode($this->canonicalize($canonicalForHash), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
        }

        return [
            'evidence_id' => trim((string) ($evidence['evidence_id'] ?? '')),
            'evidence_type' => $type,
            'subject' => $subject,
            'source' => $source,
            'provenance' => $provenance,
            'captured_at' => $capturedAt?->format(DATE_ATOM),
            'effective_at' => $effectiveAt?->format(DATE_ATOM),
            'expires_at' => $expiresAt?->format(DATE_ATOM),
            'freshness' => $freshness,
            'confidence' => $confidence,
            'authority' => $authority,
            'relevance' => $relevance,
            'applicability' => $applicability,
            'provenance_confidence' => $provenanceConfidence,
            'contradiction_adjustment' => $contradictionAdjustment,
            'jurisdiction' => $this->nullableString($evidence['jurisdiction'] ?? null),
            'vertical' => $this->nullableString($evidence['vertical'] ?? null),
            'scope' => is_array($evidence['scope'] ?? null) ? $evidence['scope'] : ($evidence['scope'] ?? null),
            'hash' => $hash,
            'verification_state' => $verification,
            'content' => $evidence['content'] ?? $evidence['value'] ?? null,
            'contradicts' => $contradicts,
            'knowledge_reference' => is_array($evidence['knowledge_reference'] ?? null) ? $evidence['knowledge_reference'] : null,
        ];
    }

    private function freshness(?DateTimeImmutable $capturedAt, ?DateTimeImmutable $effectiveAt, ?DateTimeImmutable $expiresAt, array $evidence, DateTimeImmutable $now): float
    {
        if ($effectiveAt && $effectiveAt > $now) {
            return 0.0;
        }
        if ($expiresAt && $expiresAt <= $now) {
            return 0.0;
        }

        $maxAge = max(0, (int) ($evidence['max_age_seconds'] ?? 0));
        if ($capturedAt && $maxAge > 0) {
            $age = max(0, $now->getTimestamp() - $capturedAt->getTimestamp());
            return max(0.0, min(1.0, 1.0 - ($age / $maxAge)));
        }

        return 1.0;
    }

    private function authority(mixed $value): float
    {
        if (is_numeric($value)) {
            return $this->factor($value, 0.5);
        }

        return match (strtolower(trim((string) $value))) {
            'authoritative' => 1.0,
            'official' => 0.95,
            'primary' => 0.90,
            'trusted' => 0.80,
            'secondary' => 0.65,
            'user' => 0.60,
            'model' => 0.45,
            default => 0.30,
        };
    }

    private function factor(mixed $value, float $default): float
    {
        if (! is_numeric($value)) {
            return $default;
        }
        $number = (float) $value;
        if ($number > 1.0 && $number <= 100.0) {
            $number /= 100.0;
        }
        return max(0.0, min(1.0, $number));
    }

    private function date(mixed $value, string $field): ?DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }
        try {
            return new DateTimeImmutable((string) $value);
        } catch (\Throwable) {
            throw new DomainException("Invalid {$field} timestamp.");
        }
    }

    private function nullableString(mixed $value): ?string
    {
        $value = trim((string) ($value ?? ''));
        return $value !== '' ? $value : null;
    }

    private function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }
        if (array_is_list($value)) {
            return array_map(fn (mixed $item) => $this->canonicalize($item), $value);
        }
        ksort($value);
        foreach ($value as $key => $item) {
            $value[$key] = $this->canonicalize($item);
        }
        return $value;
    }
}
