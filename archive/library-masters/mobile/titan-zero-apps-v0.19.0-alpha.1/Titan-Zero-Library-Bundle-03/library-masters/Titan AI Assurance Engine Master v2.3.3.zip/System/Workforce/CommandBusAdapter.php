<?php
declare(strict_types=1);
namespace App\Extensions\TitanAssurance\System\Workforce;
interface CommandBusAdapter { public function ready(): bool; public function execute(array $commandEnvelope): array; }
