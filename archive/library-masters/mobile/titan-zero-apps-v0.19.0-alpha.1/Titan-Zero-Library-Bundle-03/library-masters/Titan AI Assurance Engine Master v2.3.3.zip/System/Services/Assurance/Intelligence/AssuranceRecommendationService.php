<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Intelligence;

final class AssuranceRecommendationService
{
    public function recommend(array $intelligence): array
    {
        $recommendations = [];

        foreach ((array) ($intelligence['provider_metrics'] ?? []) as $provider => $metrics) {
            $count = (int) ($metrics['sample_count'] ?? 0);
            $failureRate = is_numeric($metrics['candidate_failure_rate'] ?? null) ? (float) $metrics['candidate_failure_rate'] : null;
            if ($count >= 3 && $failureRate !== null && $failureRate >= 0.30) {
                $recommendations[] = $this->item(
                    'provider_failure_rate_elevated',
                    'warning',
                    "Provider {$provider} has an elevated candidate failure rate of " . round($failureRate * 100, 1) . '%.',
                    $count,
                    ['provider' => (string) $provider, 'failure_rate' => $failureRate],
                );
            }
        }

        foreach ((array) ($intelligence['rule_pack_metrics'] ?? []) as $rulePack => $metrics) {
            $count = (int) ($metrics['sample_count'] ?? 0);
            $successRate = is_numeric($metrics['outcome_success_rate'] ?? null) ? (float) $metrics['outcome_success_rate'] : null;
            if ($count >= 3 && $successRate !== null && $successRate < 0.70) {
                $recommendations[] = $this->item(
                    'rule_pack_outcomes_weak',
                    'warning',
                    "Rule pack {$rulePack} has an observed outcome success rate of " . round($successRate * 100, 1) . '%.',
                    $count,
                    ['rule_pack_key' => (string) $rulePack, 'success_rate' => $successRate],
                );
            }
        }

        $evidence = is_numeric($intelligence['mean_evidence_sufficiency'] ?? null) ? (float) $intelligence['mean_evidence_sufficiency'] : null;
        if ($evidence !== null && $evidence < 0.60) {
            $recommendations[] = $this->item(
                'evidence_sufficiency_low',
                'warning',
                'Mean evidence sufficiency is below the advisory 0.60 review threshold.',
                (int) ($intelligence['sample_count'] ?? 0),
                ['mean_evidence_sufficiency' => $evidence],
            );
        }

        $incompleteCost = is_numeric($intelligence['incomplete_cost_accounting_rate'] ?? null)
            ? (float) $intelligence['incomplete_cost_accounting_rate']
            : null;
        if ($incompleteCost !== null && $incompleteCost > 0.10) {
            $recommendations[] = $this->item(
                'cost_accounting_incomplete',
                'info',
                'More than 10% of sampled runs have incomplete cost accounting.',
                (int) ($intelligence['sample_count'] ?? 0),
                ['incomplete_cost_accounting_rate' => $incompleteCost],
            );
        }

        $drift = (array) ($intelligence['drift'] ?? []);
        $disagreementDelta = is_numeric($drift['material_disagreement_rate_delta'] ?? null)
            ? (float) $drift['material_disagreement_rate_delta']
            : null;
        if (! ($drift['insufficient_data'] ?? true) && $disagreementDelta !== null && $disagreementDelta >= 0.15) {
            $recommendations[] = $this->item(
                'material_disagreement_drift',
                'warning',
                'Recent material disagreement frequency is materially higher than the prior comparison window.',
                (int) (($drift['recent_count'] ?? 0) + ($drift['prior_count'] ?? 0)),
                ['material_disagreement_rate_delta' => $disagreementDelta],
            );
        }

        return [
            'recommendations' => $recommendations,
            'policy_mutation' => false,
        ];
    }

    private function item(string $code, string $severity, string $reason, int $evidenceCount, array $metadata = []): array
    {
        return [
            'code' => $code,
            'severity' => $severity,
            'reason' => $reason,
            'evidence_count' => max(0, $evidenceCount),
            'metadata' => $metadata,
            'policy_mutation' => false,
        ];
    }
}
