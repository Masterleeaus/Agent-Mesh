<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Providers;

final class UsageNormalizer
{
    public function normalize(string $providerKey, array $usage, array $body = []): array
    {
        $providerKey = strtolower(trim($providerKey));

        $input = $this->integer($usage, ['input_tokens', 'prompt_tokens', 'promptTokenCount']);
        $output = $this->integer($usage, ['output_tokens', 'completion_tokens', 'candidatesTokenCount']);
        $total = $this->integer($usage, ['total_tokens', 'totalTokenCount']);
        if ($total === null && $input !== null && $output !== null) {
            $total = $input + $output;
        }

        $cached = $this->integer($usage, ['cached_input_tokens', 'cachedContentTokenCount']);
        if ($cached === null) {
            $cached = $this->nestedInteger($usage, ['prompt_tokens_details', 'cached_tokens']);
        }

        $reasoning = $this->integer($usage, ['reasoning_tokens', 'thoughtsTokenCount']);
        if ($reasoning === null) {
            $reasoning = $this->nestedInteger($usage, ['completion_tokens_details', 'reasoning_tokens']);
        }

        $reportedCost = $this->number($usage, ['cost', 'total_cost', 'reported_cost']);
        if ($reportedCost === null) {
            $reportedCost = $this->number($body, ['cost', 'total_cost']);
        }

        return [
            'provider' => $providerKey,
            'input_tokens' => $input,
            'output_tokens' => $output,
            'total_tokens' => $total,
            'cached_input_tokens' => $cached,
            'reasoning_tokens' => $reasoning,
            'reported_cost' => $reportedCost,
            'raw' => $usage,
        ];
    }

    private function integer(array $data, array $keys): ?int
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $data) && is_numeric($data[$key])) {
                return max(0, (int) $data[$key]);
            }
        }

        return null;
    }

    private function nestedInteger(array $data, array $path): ?int
    {
        $value = $data;
        foreach ($path as $segment) {
            if (! is_array($value) || ! array_key_exists($segment, $value)) {
                return null;
            }
            $value = $value[$segment];
        }

        return is_numeric($value) ? max(0, (int) $value) : null;
    }

    private function number(array $data, array $keys): ?float
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $data) && is_numeric($data[$key])) {
                return max(0.0, (float) $data[$key]);
            }
        }

        return null;
    }
}
