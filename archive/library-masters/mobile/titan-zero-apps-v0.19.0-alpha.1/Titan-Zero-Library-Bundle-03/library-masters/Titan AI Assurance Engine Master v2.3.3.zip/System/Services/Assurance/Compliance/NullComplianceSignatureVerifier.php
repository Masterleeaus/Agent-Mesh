<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Compliance;

use App\Extensions\TitanAssurance\System\Contracts\ComplianceSignatureVerifier;

final class NullComplianceSignatureVerifier implements ComplianceSignatureVerifier
{
    public function verify(string $canonicalPayload, string $signature, ?string $keyId = null): bool
    {
        return false;
    }
}
