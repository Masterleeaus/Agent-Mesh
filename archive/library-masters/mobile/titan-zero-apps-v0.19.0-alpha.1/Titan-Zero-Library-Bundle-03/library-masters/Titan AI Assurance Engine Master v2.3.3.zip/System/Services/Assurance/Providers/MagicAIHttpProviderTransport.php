<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Providers;

use App\Extensions\TitanAssurance\System\Contracts\AssuranceProviderTransport;
use App\Extensions\TitanAssurance\System\Exceptions\AssuranceProviderException;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Http;
use Throwable;

final class MagicAIHttpProviderTransport implements AssuranceProviderTransport
{
    public function __construct(private readonly MagicAIProviderRequestFactory $requestFactory)
    {
    }

    public function send(string $providerKey, string $modelId, array $request): array
    {
        $timeout = max(5, (int) config('model-council.assurance.providers.timeout_seconds', 90));
        $started = microtime(true);

        try {
            $spec = $this->requestFactory->build($providerKey, $modelId, $request);
            $response = Http::acceptJson()
                ->asJson()
                ->withHeaders($spec['headers'])
                ->timeout($timeout)
                ->post($spec['url'], $spec['body']);

            return [
                'status' => $response->status(),
                'body' => $response->json() ?? $response->body(),
                'response_time_ms' => (int) round((microtime(true) - $started) * 1000),
            ];
        } catch (ConnectionException $exception) {
            throw new AssuranceProviderException($exception->getMessage(), 'retryable', null);
        } catch (AssuranceProviderException $exception) {
            throw $exception;
        } catch (Throwable $exception) {
            throw new AssuranceProviderException($exception->getMessage(), 'terminal', null);
        }
    }
}
