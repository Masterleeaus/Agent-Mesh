<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Contracts;

interface AssuranceIntegrationSink
{
    public function destinationKey(): string;

    /**
     * Publish one structured, idempotent Assurance integration envelope.
     * Implementations must deduplicate by envelope.idempotency_key.
     */
    public function publish(array $envelope): array;
}
