<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AssuranceAssessment extends Model
{
    protected $table = 'assurance_assessments';

    protected $guarded = ['id', 'company_id', 'created_by', 'created_at', 'updated_at'];

    protected $casts = [
        'subject' => 'array',
        'evidence_used' => 'array',
        'missing_evidence' => 'array',
        'stale_evidence' => 'array',
        'contradictory_evidence' => 'array',
        'reason_codes' => 'array',
        'knowledge_references' => 'array',
        'calibration_metadata' => 'array',
        'evidence_collection_receipt' => 'array',
        'integration_receipts' => 'array',
        'result_snapshot' => 'array',
        'score' => 'float',
        'evaluated_at' => 'datetime',
    ];

    public function evidenceRecords(): HasMany
    {
        return $this->hasMany(AssuranceEvidenceRecord::class, 'assurance_assessment_id');
    }

    public function feedback(): HasMany
    {
        return $this->hasMany(AssuranceFeedback::class, 'assurance_assessment_id');
    }

    public function scopeForTenant(Builder $query, string $companyId): Builder
    {
        return $query->where($this->qualifyColumn('company_id'), $companyId);
    }
}
