<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Integration;

use Illuminate\Contracts\Container\Container;

final class CrossEngineIntegrationStatus
{
    public function __construct(private readonly Container $container)
    {
    }

    /** @return array<string,array<string,mixed>> */
    public function snapshot(): array
    {
        return [
            'titan_autonomy' => $this->contractStatus('App\\Extensions\\TitanAutonomy\\System\\Contracts\\AssuranceBridgeContract', true),
            'titan_signal' => $this->contractStatus('App\\Extensions\\TitanSignalEngine\\System\\Contracts\\SignalManagerContract', true),
            'titan_rewind' => $this->contractStatus('App\\Extensions\\TitanRewind\\System\\Contracts\\RewindManagerContract', false),
            'titan_wisdom' => $this->contractStatus('App\\Extensions\\TitanWisdomEngine\\System\\Contracts\\WisdomManagerContract', false),
            'titan_knowledge_authority' => $this->contractStatus('App\\Extensions\\TitanKnowledgeAuthority\\System\\Contracts\\KnowledgeAuthorityContract', false),
            'titan_ai_core' => $this->contractStatus('App\\Extensions\\TitanAICore\\System\\Contracts\\OrchestratorContract', false),
            'interaction_engine' => $this->contractStatus('App\\Extensions\\InteractionEngine\\System\\Contracts\\InteractionEngineManagerContract', false),
        ];
    }

    /** @return array<string,mixed> */
    private function contractStatus(string $contract, bool $assuranceWriteSupported): array
    {
        $installed = interface_exists($contract);
        $bound = $installed && $this->container->bound($contract);
        return [
            'contract' => $contract,
            'installed' => $installed,
            'bound' => $bound,
            'assurance_integration_supported' => $assuranceWriteSupported && $bound,
            'reason_code' => ! $installed
                ? 'ENGINE_CONTRACT_NOT_INSTALLED'
                : (! $bound ? 'ENGINE_CONTRACT_NOT_BOUND' : ($assuranceWriteSupported ? 'LIVE' : 'RECEIVER_CONTRACT_HAS_NO_ASSURANCE_INGEST_METHOD')),
        ];
    }
}
