<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Integration;

final class AutonomyAssuranceProjectionService
{
    /**
     * Project an evidence-native Assurance assessment into the compatibility
     * shape consumed by Titan Autonomy v1.10. `decision=approved` is only an
     * evidence-support signal for Autonomy. It is not execution authority.
     *
     * @param array<string,mixed> $assessment
     * @return array<string,mixed>
     */
    public function project(array $assessment): array
    {
        $status = strtoupper(trim((string) ($assessment['status'] ?? 'RED')));
        if (! in_array($status, ['GREEN', 'AMBER', 'RED'], true)) {
            $status = 'RED';
        }

        $score = max(0.0, min(100.0, (float) ($assessment['score'] ?? 0.0)));
        $expired = (bool) ($assessment['expired'] ?? false);
        $calibration = is_array($assessment['calibration_metadata'] ?? null)
            ? $assessment['calibration_metadata']
            : [];
        $miscalibrated = (bool) ($calibration['detected'] ?? false);
        $reasonCodes = array_values(array_unique(array_values(array_filter(
            (array) ($assessment['reason_codes'] ?? []),
            'is_string'
        ))));

        if ($expired) {
            $status = 'AMBER';
            $score = 0.0;
            $reasonCodes[] = 'ASSURANCE_ASSESSMENT_EXPIRED';
        }
        if ($miscalibrated) {
            $reasonCodes[] = 'ASSURANCE_MISCALIBRATION_ACTIVE';
        }

        return [
            'status' => $status,
            'decision' => $status === 'GREEN' && ! $expired ? 'approved' : 'denied',
            'confidence' => round($score / 100.0, 6),
            'reason_codes' => array_values(array_unique($reasonCodes)),
            'evaluation_ref' => $this->nullableString($assessment['uuid'] ?? $assessment['evaluation_ref'] ?? null),
            'available' => true,
            'calibrated' => ! $miscalibrated,
            'calibration_ref' => $this->nullableString($assessment['calibration_ref'] ?? null),
            'policy_version' => $this->nullableString($assessment['policy_version'] ?? null),
            'authority_granted' => false,
            'authority_owner' => 'titan_autonomy',
            'assurance_semantics' => 'evidence_support_only',
        ];
    }

    /** @return array<string,mixed> */
    public function unavailable(string $reasonCode): array
    {
        return [
            'status' => 'AMBER',
            'decision' => 'denied',
            'confidence' => 0.0,
            'reason_codes' => [$reasonCode],
            'evaluation_ref' => null,
            'available' => false,
            'calibrated' => false,
            'calibration_ref' => null,
            'authority_granted' => false,
            'authority_owner' => 'titan_autonomy',
            'assurance_semantics' => 'evidence_support_only',
        ];
    }

    private function nullableString(mixed $value): ?string
    {
        $value = trim((string) ($value ?? ''));
        return $value !== '' ? $value : null;
    }
}
