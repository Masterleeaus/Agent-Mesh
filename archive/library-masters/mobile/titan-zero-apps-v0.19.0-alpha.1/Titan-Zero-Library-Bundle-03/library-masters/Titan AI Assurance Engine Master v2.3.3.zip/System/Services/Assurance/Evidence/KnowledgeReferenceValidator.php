<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Evidence;

use DomainException;

final class KnowledgeReferenceValidator
{
    public function normalize(array $reference): array
    {
        $normalized = [
            'guide_id' => trim((string) ($reference['guide_id'] ?? '')),
            'version' => trim((string) ($reference['version'] ?? $reference['guide_version'] ?? '')),
            'hash' => strtolower(trim((string) ($reference['hash'] ?? $reference['version_hash'] ?? ''))),
            'section' => trim((string) ($reference['section'] ?? '')),
            'jurisdiction' => strtoupper(trim((string) ($reference['jurisdiction'] ?? ''))),
            'authority' => trim((string) ($reference['authority'] ?? '')),
            'applicable_exception' => $reference['applicable_exception'] ?? null,
        ];

        foreach (['guide_id', 'version', 'hash', 'section', 'jurisdiction', 'authority'] as $field) {
            if ($normalized[$field] === '') {
                throw new DomainException("Knowledge Authority reference requires {$field}.");
            }
        }

        if (strlen($normalized['hash']) < 16) {
            throw new DomainException('Knowledge Authority reference hash is too short to identify an exact version.');
        }

        return $normalized;
    }
}
