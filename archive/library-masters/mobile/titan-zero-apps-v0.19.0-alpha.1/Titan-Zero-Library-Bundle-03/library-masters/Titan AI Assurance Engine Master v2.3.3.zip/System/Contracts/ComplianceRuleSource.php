<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Contracts;

interface ComplianceRuleSource
{
    public function sourceKey(): string;

    public function fetch(string|int $companyId, string $rulePackKey, string $jurisdiction, array $context = []): array;
}
