<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Intelligence;

final class AssuranceOutcomeIntelligenceService
{
    public function summarize(array $records, int $recentWindow = 50, int $minimumCohort = 5): array
    {
        $normalized = [];
        foreach ($records as $index => $record) {
            if (! is_array($record)) {
                continue;
            }
            $record['_sequence'] = $index;
            $record['_run_key'] = isset($record['run_id']) && $record['run_id'] !== '' ? (string) $record['run_id'] : 'sequence:' . $index;
            $normalized[] = $record;
        }

        usort($normalized, static function (array $left, array $right): int {
            $leftTime = isset($left['occurred_at']) ? strtotime((string) $left['occurred_at']) : false;
            $rightTime = isset($right['occurred_at']) ? strtotime((string) $right['occurred_at']) : false;
            if ($leftTime !== false && $rightTime !== false && $leftTime !== $rightTime) {
                return $leftTime <=> $rightTime;
            }
            return (int) ($left['_sequence'] ?? 0) <=> (int) ($right['_sequence'] ?? 0);
        });

        $count = count($normalized);
        $runsByKey = [];
        foreach ($normalized as $record) {
            $runsByKey[(string) $record['_run_key']] ??= $record;
        }
        $runRecords = array_values($runsByKey);
        $runCount = count($runRecords);

        $providerMetrics = $this->groupMetrics($normalized, 'provider');
        $familyMetrics = $this->groupMetrics($normalized, 'model_family');
        $rulePackMetrics = $this->groupMetrics($runRecords, 'rule_pack_key');

        $disagreements = $this->countTrue($runRecords, 'material_disagreement');
        $deterministicFailures = $this->countTrue($runRecords, 'deterministic_failed');
        $incompleteCost = count(array_filter($runRecords, static fn (array $row): bool => ($row['cost_complete'] ?? null) !== true));
        $evidenceValues = array_values(array_filter(array_map(
            static fn (array $row): ?float => is_numeric($row['evidence_sufficiency'] ?? null)
                ? max(0.0, min(1.0, (float) $row['evidence_sufficiency']))
                : null,
            $runRecords,
        ), static fn (?float $value): bool => $value !== null));

        return [
            'sample_count' => $count,
            'run_sample_count' => $runCount,
            'provider_metrics' => $providerMetrics,
            'model_family_metrics' => $familyMetrics,
            'rule_pack_metrics' => $rulePackMetrics,
            'material_disagreement_rate' => $runCount > 0 ? $disagreements / $runCount : null,
            'deterministic_failure_rate' => $runCount > 0 ? $deterministicFailures / $runCount : null,
            'mean_evidence_sufficiency' => $evidenceValues !== [] ? array_sum($evidenceValues) / count($evidenceValues) : null,
            'incomplete_cost_accounting_rate' => $runCount > 0 ? $incompleteCost / $runCount : null,
            'assurance_score_by_outcome' => $this->scoreByOutcome($runRecords),
            'drift' => $this->drift($runRecords, max(1, $recentWindow), max(1, $minimumCohort)),
            'policy_mutation' => false,
        ];
    }

    private function groupMetrics(array $records, string $key): array
    {
        $groups = [];
        foreach ($records as $record) {
            $value = strtolower(trim((string) ($record[$key] ?? '')));
            if ($value === '') {
                continue;
            }
            $groups[$value][] = $record;
        }

        $metrics = [];
        foreach ($groups as $value => $rows) {
            $count = count($rows);
            $failed = count(array_filter($rows, static fn (array $row): bool => strtolower((string) ($row['candidate_status'] ?? '')) === 'failed'));
            $outcomes = array_values(array_filter($rows, static fn (array $row): bool => is_bool($row['success'] ?? null)));
            $successes = $this->countTrue($outcomes, 'success');
            $scores = array_values(array_filter(array_map(
                static fn (array $row): ?float => is_numeric($row['assurance_score'] ?? null) ? (float) $row['assurance_score'] : null,
                $rows,
            ), static fn (?float $value): bool => $value !== null));

            $metrics[$value] = [
                'sample_count' => $count,
                'candidate_failure_rate' => $count > 0 ? $failed / $count : null,
                'outcome_sample_count' => count($outcomes),
                'outcome_success_rate' => $outcomes !== [] ? $successes / count($outcomes) : null,
                'mean_assurance_score' => $scores !== [] ? array_sum($scores) / count($scores) : null,
            ];
        }

        ksort($metrics, SORT_STRING);
        return $metrics;
    }

    private function scoreByOutcome(array $records): array
    {
        $successScores = [];
        $failureScores = [];
        foreach ($records as $record) {
            if (! is_bool($record['success'] ?? null) || ! is_numeric($record['assurance_score'] ?? null)) {
                continue;
            }
            if ($record['success']) {
                $successScores[] = (float) $record['assurance_score'];
            } else {
                $failureScores[] = (float) $record['assurance_score'];
            }
        }

        return [
            'successful' => [
                'sample_count' => count($successScores),
                'mean_assurance_score' => $successScores !== [] ? array_sum($successScores) / count($successScores) : null,
            ],
            'failed' => [
                'sample_count' => count($failureScores),
                'mean_assurance_score' => $failureScores !== [] ? array_sum($failureScores) / count($failureScores) : null,
            ],
        ];
    }

    private function drift(array $records, int $recentWindow, int $minimumCohort): array
    {
        $count = count($records);
        $recent = array_slice($records, max(0, $count - $recentWindow));
        $prior = array_slice($records, max(0, $count - ($recentWindow * 2)), max(0, min($recentWindow, $count - count($recent))));

        if (count($recent) < $minimumCohort || count($prior) < $minimumCohort) {
            return [
                'recent_count' => count($recent),
                'prior_count' => count($prior),
                'insufficient_data' => true,
                'success_rate_delta' => null,
                'material_disagreement_rate_delta' => null,
                'calibration_gap_delta' => null,
            ];
        }

        $recentStats = $this->windowStats($recent);
        $priorStats = $this->windowStats($prior);
        if ($recentStats['success_rate'] === null || $priorStats['success_rate'] === null) {
            return [
                'recent_count' => count($recent),
                'prior_count' => count($prior),
                'insufficient_data' => true,
                'success_rate_delta' => null,
                'material_disagreement_rate_delta' => null,
                'calibration_gap_delta' => null,
            ];
        }

        return [
            'recent_count' => count($recent),
            'prior_count' => count($prior),
            'insufficient_data' => false,
            'recent_success_rate' => $recentStats['success_rate'],
            'prior_success_rate' => $priorStats['success_rate'],
            'success_rate_delta' => $recentStats['success_rate'] - $priorStats['success_rate'],
            'recent_material_disagreement_rate' => $recentStats['material_disagreement_rate'],
            'prior_material_disagreement_rate' => $priorStats['material_disagreement_rate'],
            'material_disagreement_rate_delta' => $recentStats['material_disagreement_rate'] - $priorStats['material_disagreement_rate'],
            'recent_calibration_gap' => $recentStats['calibration_gap'],
            'prior_calibration_gap' => $priorStats['calibration_gap'],
            'calibration_gap_delta' => $recentStats['calibration_gap'] - $priorStats['calibration_gap'],
        ];
    }

    private function windowStats(array $records): array
    {
        $outcomeRows = array_values(array_filter($records, static fn (array $row): bool => is_bool($row['success'] ?? null)));
        $successRate = $outcomeRows !== [] ? $this->countTrue($outcomeRows, 'success') / count($outcomeRows) : null;
        $disagreementRate = $records !== [] ? $this->countTrue($records, 'material_disagreement') / count($records) : 0.0;
        $scores = array_values(array_filter(array_map(
            static fn (array $row): ?float => is_numeric($row['assurance_score'] ?? null) ? max(0.0, min(100.0, (float) $row['assurance_score'])) : null,
            $outcomeRows,
        ), static fn (?float $value): bool => $value !== null));
        $predictedRate = $scores !== [] ? (array_sum($scores) / count($scores)) / 100 : null;
        $calibrationGap = $successRate !== null && $predictedRate !== null ? $successRate - $predictedRate : 0.0;

        return [
            'success_rate' => $successRate,
            'material_disagreement_rate' => $disagreementRate,
            'calibration_gap' => $calibrationGap,
        ];
    }

    private function countTrue(array $records, string $key): int
    {
        return count(array_filter($records, static fn (array $row): bool => ($row[$key] ?? null) === true));
    }
}
