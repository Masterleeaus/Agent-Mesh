<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Compliance;

use App\Extensions\TitanAssurance\System\Contracts\DeterministicRulePack;
use InvalidArgumentException;

final class ExternalComplianceRulePack implements DeterministicRulePack
{
    private const ALLOWED_OPERATORS = ['required', 'non_negative', 'range', 'date_order', 'equals', 'in'];

    public function __construct(private readonly array $document)
    {
        foreach ((array) ($document['rules'] ?? []) as $index => $rule) {
            if (! is_array($rule)) {
                throw new InvalidArgumentException("External compliance rule {$index} must be an object.");
            }
            $operator = strtolower(trim((string) ($rule['operator'] ?? '')));
            if (! in_array($operator, self::ALLOWED_OPERATORS, true)) {
                throw new InvalidArgumentException("Unsupported external compliance rule operator: {$operator}");
            }
        }
    }

    public function key(): string
    {
        return strtolower(trim((string) ($this->document['rule_pack_key'] ?? 'external')));
    }

    public function version(): string
    {
        return trim((string) ($this->document['version'] ?? 'unknown'));
    }

    public function rules(array $context = []): array
    {
        return [
            'require_evidence_for_claims' => false,
            'external_declarative_rules' => array_values((array) ($this->document['rules'] ?? [])),
            'external_rule_source' => [
                'source_key' => strtolower(trim((string) ($this->document['source_key'] ?? ''))),
                'jurisdiction' => strtoupper(trim((string) ($this->document['jurisdiction'] ?? ''))),
                'version' => $this->version(),
                'content_hash' => strtolower(trim((string) ($this->document['content_hash'] ?? ''))),
                'provenance' => is_array($this->document['provenance'] ?? null) ? $this->document['provenance'] : [],
            ],
        ];
    }

    public function document(): array
    {
        return $this->document;
    }
}
