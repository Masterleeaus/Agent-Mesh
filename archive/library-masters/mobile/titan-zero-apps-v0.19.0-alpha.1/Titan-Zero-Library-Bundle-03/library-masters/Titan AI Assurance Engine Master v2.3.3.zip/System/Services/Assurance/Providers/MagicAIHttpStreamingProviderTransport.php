<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Providers;

use App\Extensions\TitanAssurance\System\Contracts\AssuranceStreamingProviderTransport;
use App\Extensions\TitanAssurance\System\Exceptions\AssuranceProviderException;
use GuzzleHttp\Client;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Promise\Utils as PromiseUtils;
use Throwable;

final class MagicAIHttpStreamingProviderTransport implements AssuranceStreamingProviderTransport
{
    private ClientInterface $client;

    public function __construct(
        private readonly MagicAIProviderRequestFactory $requestFactory,
        ?ClientInterface $client = null,
    ) {
        $this->client = $client ?? new Client([
            'timeout' => max(5, (int) config('model-council.assurance.providers.timeout_seconds', 90)),
            'connect_timeout' => max(1, (int) config('model-council.assurance.providers.connect_timeout_seconds', 20)),
        ]);
    }

    public function stream(string $providerKey, string $modelId, array $request, callable $onChunk): array
    {
        $results = $this->streamMany([
            'single' => [
                'provider_key' => $providerKey,
                'model_id' => $modelId,
                'request' => $request,
            ],
        ], static function (string $key, string $chunk) use ($onChunk): void {
            $onChunk($chunk);
        });

        return $results['single'] ?? [
            'status' => 0,
            'body' => ['error' => 'Missing streaming transport result.'],
            'response_time_ms' => 0,
            'chunk_count' => 0,
        ];
    }

    public function streamMany(array $requests, callable $onChunk): array
    {
        $promises = [];
        $responseTimes = [];
        $results = [];

        foreach ($requests as $key => $item) {
            $key = (string) $key;
            try {
                $providerKey = (string) ($item['provider_key'] ?? '');
                $modelId = (string) ($item['model_id'] ?? '');
                $request = is_array($item['request'] ?? null) ? $item['request'] : [];
                $spec = $this->requestFactory->build($providerKey, $modelId, $request);
                $started = microtime(true);
                $responseTimes[$key] = 0;

                $promises[$key] = $this->client->requestAsync('POST', $spec['url'], [
                    'headers' => $spec['headers'],
                    'json' => $spec['body'],
                    'http_errors' => false,
                    'on_stats' => function ($stats) use ($key, $started, &$responseTimes): void {
                        $transfer = (float) $stats->getTransferTime();
                        $responseTimes[$key] = $transfer > 0
                            ? (int) round($transfer * 1000)
                            : (int) round((microtime(true) - $started) * 1000);
                    },
                ]);
            } catch (AssuranceProviderException $exception) {
                throw $exception;
            } catch (Throwable $exception) {
                $results[$key] = [
                    'status' => 0,
                    'body' => ['error' => $exception->getMessage()],
                    'response_time_ms' => 0,
                    'chunk_count' => 0,
                ];
            }
        }

        if ($promises !== []) {
            $settled = PromiseUtils::settle($promises)->wait();
            foreach ($settled as $key => $state) {
                $key = (string) $key;
                if (($state['state'] ?? null) !== 'fulfilled' || ! isset($state['value'])) {
                    $reason = $state['reason'] ?? null;
                    $results[$key] = [
                        'status' => 0,
                        'body' => ['error' => $reason instanceof Throwable ? $reason->getMessage() : 'Provider connection failed.'],
                        'response_time_ms' => (int) ($responseTimes[$key] ?? 0),
                        'chunk_count' => 0,
                    ];
                    continue;
                }

                $response = $state['value'];
                $rawBody = (string) $response->getBody();
                $decoded = json_decode($rawBody, true);
                $results[$key] = [
                    'status' => (int) $response->getStatusCode(),
                    'body' => is_array($decoded) ? $decoded : $rawBody,
                    'response_time_ms' => (int) ($responseTimes[$key] ?? 0),
                    // Provider-native token streaming is optional; gateway emits canonical text when transport provides no chunks.
                    'chunk_count' => 0,
                ];
            }
        }

        return $results;
    }
}
