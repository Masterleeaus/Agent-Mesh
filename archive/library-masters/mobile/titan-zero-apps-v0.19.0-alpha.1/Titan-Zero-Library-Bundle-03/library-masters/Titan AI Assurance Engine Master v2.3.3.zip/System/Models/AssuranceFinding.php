<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AssuranceFinding extends Model
{
    protected $table = 'assurance_findings';

    protected $guarded = ['id', 'company_id', 'assurance_run_id', 'candidate_id', 'created_at', 'updated_at'];

    public function run(): BelongsTo
    {
        return $this->belongsTo(AssuranceRun::class, 'assurance_run_id');
    }
}
