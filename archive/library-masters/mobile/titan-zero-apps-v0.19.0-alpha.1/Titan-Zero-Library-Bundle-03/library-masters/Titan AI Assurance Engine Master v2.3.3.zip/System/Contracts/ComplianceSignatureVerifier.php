<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Contracts;

interface ComplianceSignatureVerifier
{
    public function verify(string $canonicalPayload, string $signature, ?string $keyId = null): bool;
}
