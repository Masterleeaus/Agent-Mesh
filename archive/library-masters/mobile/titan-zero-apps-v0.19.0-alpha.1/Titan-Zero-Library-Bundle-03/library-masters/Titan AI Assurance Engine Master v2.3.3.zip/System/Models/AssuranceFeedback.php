<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AssuranceFeedback extends Model
{
    protected $table = 'assurance_feedback';

    protected $guarded = ['id', 'company_id', 'assurance_assessment_id', 'recorded_by', 'created_at', 'updated_at'];

    protected $casts = [
        'accepted' => 'boolean',
        'metadata' => 'array',
        'recorded_at' => 'datetime',
    ];

    public function assessment(): BelongsTo
    {
        return $this->belongsTo(AssuranceAssessment::class, 'assurance_assessment_id');
    }
}
