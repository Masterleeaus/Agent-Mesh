<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Integration;

use App\Extensions\TitanAssurance\System\Contracts\EvidenceCollectionRequester;
use App\Extensions\TitanAssurance\System\Events\AssuranceEvidenceCollectionRequested;

final class LaravelEventEvidenceCollectionRequester implements EvidenceCollectionRequester
{
    public function request(array $request): array
    {
        $requestId = (string) ($request['request_id'] ?? hash('sha256', json_encode($request, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: ''));
        $request['request_id'] = $requestId;
        $request['workflow_key'] = (string) ($request['workflow_key'] ?? 'assurance.evidence.collect');
        event(new AssuranceEvidenceCollectionRequested($request));

        return [
            'requested' => true,
            'request_id' => $requestId,
            'workflow_key' => $request['workflow_key'],
            'transport' => 'laravel_event',
        ];
    }
}
