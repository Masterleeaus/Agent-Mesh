<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Cost;

final class ProviderPricingCatalogue
{
    private array $pricing;

    public function __construct(?array $pricing = null)
    {
        $this->pricing = $pricing ?? (array) config('model-council.assurance.pricing', []);
    }

    public function resolve(string $providerKey, string $modelId): ?array
    {
        $provider = strtolower(trim($providerKey));
        $model = strtolower(trim($modelId));
        $models = (array) ($this->pricing['models'] ?? []);
        $defaults = (array) ($this->pricing['provider_defaults'] ?? []);

        $entry = $models[$provider . ':' . $model] ?? $models[$provider . ':' . $modelId] ?? $defaults[$provider] ?? null;
        if (! is_array($entry)) {
            return null;
        }

        return [
            'input_per_million' => $this->nonNegativeNumber($entry['input_per_million'] ?? null),
            'output_per_million' => $this->nonNegativeNumber($entry['output_per_million'] ?? null),
            'cached_input_per_million' => $this->nonNegativeNumber($entry['cached_input_per_million'] ?? null),
            'reasoning_per_million' => $this->nonNegativeNumber($entry['reasoning_per_million'] ?? null),
            'currency' => strtoupper((string) ($entry['currency'] ?? $this->pricing['currency'] ?? 'USD')),
            'pricing_version' => (string) ($entry['version'] ?? $this->pricing['version'] ?? 'unversioned'),
        ];
    }

    public function version(): string
    {
        return (string) ($this->pricing['version'] ?? 'unversioned');
    }

    public function currency(): string
    {
        return strtoupper((string) ($this->pricing['currency'] ?? 'USD'));
    }

    private function nonNegativeNumber(mixed $value): ?float
    {
        return is_numeric($value) ? max(0.0, (float) $value) : null;
    }
}
