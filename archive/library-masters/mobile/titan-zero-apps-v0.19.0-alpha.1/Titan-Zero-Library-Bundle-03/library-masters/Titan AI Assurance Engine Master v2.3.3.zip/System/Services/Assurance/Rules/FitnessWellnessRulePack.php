<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Rules;

final class FitnessWellnessRulePack extends CoreRulePack
{
    public function key(): string { return 'fitness_wellness.v1'; }

    protected function contextNumericThresholds(): array
    {
        return [
            'session_price' => ['min' => 0],
            'duration_minutes' => ['min' => 0],
            'capacity' => ['min' => 0],
            'discount_percent' => ['min' => 0, 'max' => 100],
        ];
    }

    protected function contextDateOrderings(): array
    {
        return [['start' => 'session_start_at', 'end' => 'session_end_at']];
    }
}
