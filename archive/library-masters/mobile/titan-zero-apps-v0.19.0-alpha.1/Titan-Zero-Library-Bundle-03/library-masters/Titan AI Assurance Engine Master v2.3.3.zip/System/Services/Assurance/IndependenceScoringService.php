<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

final class IndependenceScoringService
{
    public function score(array $panel): array
    {
        $candidateCount = count($panel);
        if ($candidateCount === 0) {
            return ['score' => 0.0, 'provider_count' => 0, 'family_count' => 0, 'candidate_count' => 0];
        }

        $providers = array_values(array_unique(array_filter(array_map(
            static fn (array $candidate) => strtolower((string) ($candidate['provider'] ?? $candidate['provider_key'] ?? '')),
            $panel
        ))));
        $families = array_values(array_unique(array_filter(array_map(
            static fn (array $candidate) => strtolower((string) ($candidate['family'] ?? $candidate['model_family'] ?? '')),
            $panel
        ))));

        $providerRatio = count($providers) / $candidateCount;
        $familyRatio = count($families) / $candidateCount;
        $score = min(100.0, (($providerRatio * 45.0) + ($familyRatio * 55.0)) * 100.0 / 100.0);

        return [
            'score' => round($score, 2),
            'provider_count' => count($providers),
            'family_count' => count($families),
            'candidate_count' => $candidateCount,
        ];
    }
}
