<?php
declare(strict_types=1);
namespace App\Extensions\TitanAssurance\System\Workforce;
interface ReceiptRegistry { public function put(array $receipt): void; public function get(string $receiptId): ?array; public function findByIdempotency(string $companyId,string $key): ?array; }
