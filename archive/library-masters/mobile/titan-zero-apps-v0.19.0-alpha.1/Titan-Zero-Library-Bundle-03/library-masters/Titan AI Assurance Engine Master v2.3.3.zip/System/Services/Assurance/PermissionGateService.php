<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

final class PermissionGateService
{
    private const DEFAULT_THRESHOLDS = ['standard' => 70.0, 'high' => 80.0, 'critical' => 85.0];

    public function __construct(private readonly array $thresholds = self::DEFAULT_THRESHOLDS)
    {
    }

    public function evaluate(array $context): array
    {
        $mode = strtolower((string) ($context['mode'] ?? 'standard'));
        $humanRequired = in_array($mode, ['high', 'critical'], true);
        $violations = [];

        foreach ([
            'panel_valid' => 'panel_policy_failed',
            'evidence_locked' => 'evidence_not_locked',
            'deterministic_passed' => 'deterministic_validation_failed',
        ] as $key => $violation) {
            if (! (bool) ($context[$key] ?? false)) {
                $violations[] = $violation;
            }
        }

        if ((bool) ($context['material_disagreement'] ?? false)) {
            $violations[] = 'material_disagreement';
        }

        if (in_array($mode, ['high', 'critical'], true) && ! (bool) ($context['challenge_complete'] ?? false)) {
            $violations[] = 'challenge_incomplete';
        }

        $minimumScore = (float) ($this->thresholds[$mode] ?? self::DEFAULT_THRESHOLDS[$mode] ?? self::DEFAULT_THRESHOLDS['standard']);
        if ((float) ($context['score'] ?? 0) < $minimumScore) {
            $violations[] = 'assurance_score_below_threshold';
        }

        if ($humanRequired && ! (bool) ($context['human_approved'] ?? false)) {
            $violations[] = 'human_approval_required';
        }

        $permitted = $violations === [];

        return [
            'permission_state' => $permitted ? 'permitted' : 'blocked',
            'status' => $permitted ? 'assured' : ($humanRequired && $violations === ['human_approval_required'] ? 'awaiting_human_review' : 'policy_blocked'),
            'human_approval_required' => $humanRequired,
            'violations' => $violations,
            'minimum_score' => $minimumScore,
        ];
    }
}
