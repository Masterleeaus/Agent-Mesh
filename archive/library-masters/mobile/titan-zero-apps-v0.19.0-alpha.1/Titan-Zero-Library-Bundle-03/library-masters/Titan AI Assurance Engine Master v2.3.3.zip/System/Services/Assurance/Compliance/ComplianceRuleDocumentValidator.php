<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Compliance;

use App\Extensions\TitanAssurance\System\Contracts\ComplianceSignatureVerifier;
use DateTimeImmutable;
use DateTimeInterface;
use InvalidArgumentException;
use JsonException;

final class ComplianceRuleDocumentValidator
{
    public function __construct(
        private readonly ComplianceSignatureVerifier $signatureVerifier = new NullComplianceSignatureVerifier(),
    ) {
    }

    public function validate(
        array $document,
        string $requestedJurisdiction,
        DateTimeInterface|string $asOf,
        bool $signatureRequired = false,
    ): array {
        foreach (['source_key', 'rule_pack_key', 'jurisdiction', 'version', 'effective_from', 'rules', 'content_hash'] as $field) {
            if (! array_key_exists($field, $document) || $document[$field] === '' || $document[$field] === null) {
                throw new InvalidArgumentException("Compliance document missing required field: {$field}");
            }
        }

        if (! is_array($document['rules'])) {
            throw new InvalidArgumentException('Compliance document rules must be an array.');
        }

        $requested = strtoupper(trim($requestedJurisdiction));
        $actual = strtoupper(trim((string) $document['jurisdiction']));
        if ($requested === '' || $actual !== $requested) {
            throw new InvalidArgumentException('Compliance document jurisdiction mismatch.');
        }

        $expectedHash = strtolower(trim((string) $document['content_hash']));
        $actualHash = $this->contentHash($document);
        if ($expectedHash === '' || ! hash_equals($expectedHash, $actualHash)) {
            throw new InvalidArgumentException('Compliance document content hash mismatch.');
        }

        $at = $asOf instanceof DateTimeInterface
            ? DateTimeImmutable::createFromInterface($asOf)
            : $this->parseDate((string) $asOf, 'as-of date');
        $effectiveFrom = $this->parseDate((string) $document['effective_from'], 'effective_from')->setTime(0, 0, 0);
        if ($at < $effectiveFrom) {
            throw new InvalidArgumentException('Compliance document is not yet effective.');
        }

        if (isset($document['effective_to']) && trim((string) $document['effective_to']) !== '') {
            $effectiveTo = $this->parseDate((string) $document['effective_to'], 'effective_to')->setTime(23, 59, 59);
            if ($at > $effectiveTo) {
                throw new InvalidArgumentException('Compliance document is expired.');
            }
        }

        $signature = trim((string) ($document['signature'] ?? ''));
        $keyId = isset($document['signature_key_id']) ? trim((string) $document['signature_key_id']) : null;
        if ($signatureRequired && $signature === '') {
            throw new InvalidArgumentException('Compliance document signature is required.');
        }
        if ($signature !== '' && ! $this->signatureVerifier->verify($this->canonicalPayload($document), $signature, $keyId ?: null)) {
            throw new InvalidArgumentException('Compliance document signature is invalid.');
        }

        $validated = $document;
        $validated['source_key'] = strtolower(trim((string) $document['source_key']));
        $validated['rule_pack_key'] = strtolower(trim((string) $document['rule_pack_key']));
        $validated['jurisdiction'] = $actual;
        $validated['content_hash'] = $actualHash;
        $validated['validated_at'] = $at->format(DateTimeInterface::ATOM);

        return $validated;
    }

    public function contentHash(array $document): string
    {
        return hash('sha256', $this->canonicalPayload($document));
    }

    public function canonicalPayload(array $document): string
    {
        unset($document['content_hash'], $document['signature'], $document['signature_key_id'], $document['validated_at']);

        try {
            return json_encode(
                $this->canonicalize($document),
                JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE,
            );
        } catch (JsonException $exception) {
            throw new InvalidArgumentException('Compliance document cannot be canonicalized: ' . $exception->getMessage(), 0, $exception);
        }
    }

    private function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }

        if (array_is_list($value)) {
            return array_map(fn (mixed $item): mixed => $this->canonicalize($item), $value);
        }

        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) {
            $value[$key] = $this->canonicalize($item);
        }

        return $value;
    }

    private function parseDate(string $value, string $field): DateTimeImmutable
    {
        $value = trim($value);
        if ($value === '') {
            throw new InvalidArgumentException("Compliance document {$field} is invalid.");
        }

        try {
            return new DateTimeImmutable($value);
        } catch (\Throwable $exception) {
            throw new InvalidArgumentException("Compliance document {$field} is invalid.", 0, $exception);
        }
    }
}
