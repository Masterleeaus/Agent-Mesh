<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Integration;

use App\Extensions\TitanAssurance\System\Services\Assurance\CompanyContextResolver;
use App\Extensions\TitanAutonomy\System\Contracts\AssuranceBridgeContract;

final class TitanAutonomyAssuranceBridge implements AssuranceBridgeContract
{
    public function __construct(
        private readonly CompanyContextResolver $companyContext,
        private readonly LatestEvidenceAssessmentResolver $resolver,
        private readonly AutonomyAssuranceProjectionService $projection,
    ) {
    }

    public function evaluate(string $capability, ?string $workflowKey, array $context): array
    {
        $companyId = $this->companyContext->resolve();
        if ($companyId === null || trim((string) $companyId) === '') {
            return $this->projection->unavailable('ASSURANCE_TENANT_CONTEXT_REQUIRED');
        }

        $assessment = $this->resolver->resolve((string) $companyId, $capability, $workflowKey, $context);
        if ($assessment === null) {
            return $this->projection->unavailable('EVIDENCE_ASSURANCE_ASSESSMENT_REQUIRED');
        }

        return $this->projection->project($this->resolver->toProjectionInput($assessment));
    }
}
