<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Rules;

use App\Extensions\TitanAssurance\System\Contracts\DeterministicRulePack;

class CoreRulePack implements DeterministicRulePack
{
    public function key(): string
    {
        return 'core.v1';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    public function rules(array $context = []): array
    {
        return [
            'require_evidence_for_claims' => true,
            'numeric_thresholds' => [
                'confidence' => ['min' => 0, 'max' => 1],
            ],
            'context_numeric_thresholds' => $this->contextNumericThresholds(),
            'context_date_orderings' => $this->contextDateOrderings(),
        ];
    }

    protected function contextNumericThresholds(): array
    {
        return [];
    }

    protected function contextDateOrderings(): array
    {
        return [];
    }
}
