<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Cost;

final class CostReconciler
{
    public function actual(array $candidateUsage, float $challengeCost = 0.0, float $synthesisCost = 0.0): float
    {
        return $this->reconcile($candidateUsage, $challengeCost, $synthesisCost)['actual_cost'];
    }

    public function reconcile(array $candidateUsage, float $challengeCost = 0.0, float $synthesisCost = 0.0): array
    {
        $actual = max(0.0, $challengeCost) + max(0.0, $synthesisCost);
        $known = 0;
        $unknown = 0;

        foreach ($candidateUsage as $usage) {
            $cost = $usage['cost'] ?? $usage['effective_cost'] ?? null;
            if ($cost === null || ! is_numeric($cost)) {
                $unknown++;
                continue;
            }
            $actual += max(0.0, (float) $cost);
            $known++;
        }

        return [
            'actual_cost' => round($actual, 6),
            'known_cost_count' => $known,
            'unknown_cost_count' => $unknown,
            'complete' => $unknown === 0,
        ];
    }
}
