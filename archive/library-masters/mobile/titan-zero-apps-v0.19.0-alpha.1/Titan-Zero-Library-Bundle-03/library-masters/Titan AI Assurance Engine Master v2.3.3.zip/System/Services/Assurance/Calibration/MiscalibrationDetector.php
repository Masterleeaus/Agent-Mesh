<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Calibration;

final class MiscalibrationDetector
{
    public function __construct(
        private readonly int $minimumGreenSamples = 5,
        private readonly float $greenRejectionThreshold = 0.30,
        private readonly float $minimumCalibrationFactor = 0.50,
    ) {
    }

    public function detect(array $samples): array
    {
        $green = 0;
        $rejected = 0;
        foreach ($samples as $sample) {
            if (! is_array($sample) || strtoupper((string) ($sample['status'] ?? '')) !== 'GREEN') {
                continue;
            }
            $accepted = $sample['accepted'] ?? $sample['success'] ?? null;
            if (! is_bool($accepted)) {
                continue;
            }
            $green++;
            if (! $accepted) {
                $rejected++;
            }
        }

        $rate = $green > 0 ? $rejected / $green : 0.0;
        $detected = $green >= $this->minimumGreenSamples && $rate >= $this->greenRejectionThreshold;
        $factor = $detected
            ? max($this->minimumCalibrationFactor, 1.0 - min(0.5, $rate * 0.5))
            : 1.0;

        return [
            'detected' => $detected,
            'green_sample_count' => $green,
            'green_rejection_count' => $rejected,
            'green_rejection_rate' => round($rate, 6),
            'calibration_factor' => round($factor, 6),
            'reason_codes' => $detected ? ['GREEN_DOWNSTREAM_REJECTION_DRIFT'] : [],
            'policy_mutation' => false,
        ];
    }
}
