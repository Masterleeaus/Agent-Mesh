<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

use App\Extensions\TitanAssurance\System\Contracts\DeterministicRulePack;

final class DeterministicValidationPipeline
{
    public function __construct(private readonly StructuredResponseValidator $structured)
    {
    }

    public function validateCandidate(array $structuredResponse, array $rules = []): array
    {
        $schema = $this->structured->validate($structuredResponse, $rules);
        $findings = $schema['findings'];

        foreach ((array) ($rules['numeric_thresholds'] ?? []) as $path => $constraint) {
            $value = $this->get($structuredResponse, (string) $path);
            if ($value === null || ! is_numeric($value)) {
                continue;
            }
            if (isset($constraint['min']) && (float) $value < (float) $constraint['min']) {
                $findings[] = $this->finding('numeric_minimum', 'hard', false, (string) $path, ['actual' => (float) $value, 'minimum' => (float) $constraint['min']]);
            }
            if (isset($constraint['max']) && (float) $value > (float) $constraint['max']) {
                $findings[] = $this->finding('numeric_maximum', 'hard', false, (string) $path, ['actual' => (float) $value, 'maximum' => (float) $constraint['max']]);
            }
        }

        $hardFailures = count(array_filter($findings, static fn (array $finding) => ($finding['severity'] ?? '') === 'hard' && ! ($finding['passed'] ?? false)));

        return ['status' => $hardFailures > 0 ? 'failed' : 'passed', 'hard_failures' => $hardFailures, 'findings' => $findings];
    }


    public function validateCandidateWithPack(array $structuredResponse, DeterministicRulePack $pack, array $context = []): array
    {
        $rules = $pack->rules($context);
        $result = $this->validateCandidate($structuredResponse, $rules);
        $findings = $result['findings'];

        foreach ((array) ($rules['context_numeric_thresholds'] ?? []) as $path => $constraint) {
            $value = $this->get($context, (string) $path);
            if ($value === null) {
                continue;
            }
            if (! is_numeric($value)) {
                $findings[] = $this->finding('context_numeric_invalid', 'hard', false, (string) $path, ['actual' => $value]);
                continue;
            }
            if (isset($constraint['min']) && (float) $value < (float) $constraint['min']) {
                $findings[] = $this->finding('context_numeric_minimum', 'hard', false, (string) $path, ['actual' => (float) $value, 'minimum' => (float) $constraint['min']]);
            }
            if (isset($constraint['max']) && (float) $value > (float) $constraint['max']) {
                $findings[] = $this->finding('context_numeric_maximum', 'hard', false, (string) $path, ['actual' => (float) $value, 'maximum' => (float) $constraint['max']]);
            }
        }

        foreach ((array) ($rules['context_date_orderings'] ?? []) as $ordering) {
            if (! is_array($ordering)) {
                continue;
            }
            $startPath = (string) ($ordering['start'] ?? '');
            $endPath = (string) ($ordering['end'] ?? '');
            if ($startPath === '' || $endPath === '') {
                continue;
            }
            $start = $this->get($context, $startPath);
            $end = $this->get($context, $endPath);
            if ($start === null || $end === null) {
                continue;
            }
            $startTs = is_numeric($start) ? (int) $start : strtotime((string) $start);
            $endTs = is_numeric($end) ? (int) $end : strtotime((string) $end);
            if ($startTs === false || $endTs === false) {
                $findings[] = $this->finding('context_date_invalid', 'hard', false, $startPath . ' -> ' . $endPath);
                continue;
            }
            if ($startTs > $endTs) {
                $findings[] = $this->finding('context_date_order_invalid', 'hard', false, $startPath . ' must not be after ' . $endPath, [
                    'start' => $start,
                    'end' => $end,
                ]);
            }
        }

        foreach ((array) ($rules['external_declarative_rules'] ?? []) as $rule) {
            if (! is_array($rule)) {
                continue;
            }
            $finding = $this->evaluateExternalRule($rule, $context, (array) ($rules['external_rule_source'] ?? []));
            if ($finding !== null) {
                $findings[] = $finding;
            }
        }

        $hardFailures = count(array_filter($findings, static fn (array $finding) => ($finding['severity'] ?? '') === 'hard' && ! ($finding['passed'] ?? false)));

        return [
            'status' => $hardFailures > 0 ? 'failed' : 'passed',
            'hard_failures' => $hardFailures,
            'findings' => $findings,
            'rule_pack_key' => $pack->key(),
            'rule_pack_version' => $pack->version(),
        ];
    }

    private function evaluateExternalRule(array $rule, array $context, array $source): ?array
    {
        $operator = strtolower(trim((string) ($rule['operator'] ?? '')));
        $severity = strtolower(trim((string) ($rule['severity'] ?? 'hard'))) ?: 'hard';
        $ruleId = trim((string) ($rule['id'] ?? $operator));
        $field = trim((string) ($rule['field'] ?? ''));
        $metadata = [
            'rule_id' => $ruleId,
            'operator' => $operator,
            'source_key' => $source['source_key'] ?? null,
            'jurisdiction' => $source['jurisdiction'] ?? null,
            'version' => $source['version'] ?? null,
            'content_hash' => $source['content_hash'] ?? null,
        ];

        $fail = function (string $code, string $message, array $extra = []) use ($severity, $metadata): array {
            return $this->finding($code, $severity, false, $message, array_merge($metadata, $extra));
        };

        if ($operator === 'date_order') {
            $startPath = trim((string) ($rule['start'] ?? ''));
            $endPath = trim((string) ($rule['end'] ?? ''));
            $start = $this->get($context, $startPath);
            $end = $this->get($context, $endPath);
            if ($start === null || $end === null) {
                return null;
            }
            $startTs = is_numeric($start) ? (int) $start : strtotime((string) $start);
            $endTs = is_numeric($end) ? (int) $end : strtotime((string) $end);
            if ($startTs === false || $endTs === false || $startTs > $endTs) {
                return $fail('external_date_order', (string) ($rule['message'] ?? "{$startPath} must not be after {$endPath}."), [
                    'start' => $start,
                    'end' => $end,
                ]);
            }
            return null;
        }

        $value = $field !== '' ? $this->get($context, $field) : null;
        if ($operator === 'required') {
            if ($value === null || $value === '' || $value === []) {
                return $fail('external_required', (string) ($rule['message'] ?? "{$field} is required."));
            }
            return null;
        }

        if ($value === null) {
            return null;
        }

        return match ($operator) {
            'non_negative' => (! is_numeric($value) || (float) $value < 0)
                ? $fail('external_non_negative', (string) ($rule['message'] ?? "{$field} must be non-negative."), ['actual' => $value])
                : null,
            'range' => (! is_numeric($value)
                    || (isset($rule['min']) && (float) $value < (float) $rule['min'])
                    || (isset($rule['max']) && (float) $value > (float) $rule['max']))
                ? $fail('external_range', (string) ($rule['message'] ?? "{$field} is outside the allowed range."), [
                    'actual' => $value,
                    'min' => $rule['min'] ?? null,
                    'max' => $rule['max'] ?? null,
                ])
                : null,
            'equals' => $value !== ($rule['value'] ?? null)
                ? $fail('external_equals', (string) ($rule['message'] ?? "{$field} does not equal the required value."), ['actual' => $value])
                : null,
            'in' => ! in_array($value, (array) ($rule['values'] ?? []), true)
                ? $fail('external_in', (string) ($rule['message'] ?? "{$field} is not an allowed value."), ['actual' => $value, 'allowed' => array_values((array) ($rule['values'] ?? []))])
                : null,
            default => $fail('external_unknown_operator', 'Unsupported external deterministic operator.'),
        };
    }

    private function get(array $data, string $path): mixed
    {
        $value = $data;
        foreach (explode('.', $path) as $segment) {
            if (! is_array($value) || ! array_key_exists($segment, $value)) {
                return null;
            }
            $value = $value[$segment];
        }
        return $value;
    }

    private function finding(string $code, string $severity, bool $passed, string $message, array $metadata = []): array
    {
        return compact('code', 'severity', 'passed', 'message', 'metadata');
    }
}
