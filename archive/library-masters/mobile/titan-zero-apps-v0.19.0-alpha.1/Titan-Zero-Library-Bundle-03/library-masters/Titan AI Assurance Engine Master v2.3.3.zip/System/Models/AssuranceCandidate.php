<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AssuranceCandidate extends Model
{
    protected $table = 'assurance_candidates';

    protected $guarded = ['id', 'company_id', 'assurance_run_id', 'created_at', 'updated_at'];

    protected $casts = [
        'structured_response' => 'array',
        'evidence_references' => 'array',
        'usage' => 'array',
        'normalized_usage' => 'array',
        'capabilities' => 'array',
        'failed' => 'boolean',
        'selected' => 'boolean',
        'selected_at' => 'datetime',
        'streamed' => 'boolean',
        'stream_completed_at' => 'datetime',
        'cost' => 'float',
        'effective_cost' => 'float',
        'queued_at' => 'datetime',
        'started_at' => 'datetime',
        'completed_at' => 'datetime',
    ];

    public function run(): BelongsTo
    {
        return $this->belongsTo(AssuranceRun::class, 'assurance_run_id');
    }
}
