<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Evidence;

use App\Extensions\TitanAssurance\System\Support\AssuranceBand;

final class AssuranceResultService
{
    public function __construct(
        private readonly EvidenceWeightingService $weighting,
        private readonly float $greenThreshold = 80.0,
        private readonly float $amberThreshold = 60.0,
        private readonly float $staleThreshold = 0.40,
    ) {
    }

    public function evaluate(array $evidence, array $requirements = [], float $calibrationFactor = 1.0, string $policyVersion = 'titan-assurance-v2.1'): array
    {
        $used = [];
        $stale = [];
        $contradictory = [];
        $ids = [];
        $weightedSum = 0.0;

        foreach ($evidence as $record) {
            if (! is_array($record)) {
                continue;
            }
            $weight = $this->weighting->weight($record);
            $id = (string) ($record['evidence_id'] ?? '');
            if ($id !== '') {
                $ids[$id] = true;
            }
            $weightedSum += $weight['score'];
            $used[] = [
                'evidence_id' => $id,
                'evidence_type' => $record['evidence_type'] ?? null,
                'source' => $record['source'] ?? null,
                'weight_score' => $weight['score'],
                'factors' => $weight['factors'],
                'hash' => $record['hash'] ?? null,
                'verification_state' => $record['verification_state'] ?? null,
            ];
            if ((float) ($record['freshness'] ?? 0) <= $this->staleThreshold) {
                $stale[] = $id !== '' ? $id : ($record['hash'] ?? null);
            }
            foreach ((array) ($record['contradicts'] ?? []) as $other) {
                $other = (string) $other;
                if ($other !== '') {
                    $pair = [$id, $other];
                    sort($pair);
                    $contradictory[implode(':', $pair)] = $pair;
                }
            }
        }

        $missing = [];
        $requiredCount = 0;
        $fulfilledCount = 0;
        foreach ($requirements as $requirement) {
            if (! is_array($requirement) || (($requirement['required'] ?? true) === false)) {
                continue;
            }
            $requiredCount++;
            $key = trim((string) ($requirement['key'] ?? $requirement['evidence_id'] ?? $requirement['evidence_type'] ?? 'required_evidence'));
            $matches = false;
            foreach ($evidence as $record) {
                if (! is_array($record)) {
                    continue;
                }
                if (isset($requirement['evidence_id']) && (string) ($record['evidence_id'] ?? '') !== (string) $requirement['evidence_id']) {
                    continue;
                }
                if (isset($requirement['evidence_type']) && (string) ($record['evidence_type'] ?? '') !== (string) $requirement['evidence_type']) {
                    continue;
                }
                if (isset($requirement['subject']) && $record['subject'] != $requirement['subject']) {
                    continue;
                }
                if ((float) ($record['freshness'] ?? 0) <= 0.0) {
                    continue;
                }
                $matches = true;
                break;
            }
            if ($matches) {
                $fulfilledCount++;
            } else {
                $missing[] = [
                    'key' => $key,
                    'evidence_id' => $requirement['evidence_id'] ?? null,
                    'evidence_type' => $requirement['evidence_type'] ?? null,
                    'subject' => $requirement['subject'] ?? null,
                    'critical' => (bool) ($requirement['critical'] ?? false),
                ];
            }
        }

        $base = count($used) > 0 ? $weightedSum / count($used) : 0.0;
        $coverage = $requiredCount > 0 ? $fulfilledCount / $requiredCount : 1.0;
        $calibrationFactor = max(0.0, min(1.0, $calibrationFactor));
        $score = round(max(0.0, min(100.0, $base * $coverage * $calibrationFactor)), 2);

        $band = match (true) {
            $score >= $this->greenThreshold => AssuranceBand::GREEN,
            $score >= $this->amberThreshold => AssuranceBand::AMBER,
            default => AssuranceBand::RED,
        };

        $reasonCodes = [];
        if ($used === []) {
            $reasonCodes[] = 'NO_EVIDENCE';
        }
        if ($missing !== []) {
            $reasonCodes[] = 'MISSING_REQUIRED_EVIDENCE';
            if (array_filter($missing, static fn (array $item) => $item['critical'])) {
                $band = AssuranceBand::RED;
            } elseif ($band === AssuranceBand::GREEN) {
                $band = AssuranceBand::AMBER;
            }
        }
        if ($stale !== []) {
            $reasonCodes[] = 'STALE_EVIDENCE';
            if ($band === AssuranceBand::GREEN) {
                $band = AssuranceBand::AMBER;
            }
        }
        if ($contradictory !== []) {
            $reasonCodes[] = 'CONTRADICTORY_EVIDENCE';
            if ($band === AssuranceBand::GREEN) {
                $band = AssuranceBand::AMBER;
            }
        }
        if ($calibrationFactor < 1.0) {
            $reasonCodes[] = 'CALIBRATION_DOWNWEIGHTED';
        }
        if ($reasonCodes === []) {
            $reasonCodes[] = 'EVIDENCE_SUPPORTS_ACTION';
        }

        return [
            'status' => $band,
            'score' => $score,
            'evidence_used' => $used,
            'missing_evidence' => $missing,
            'stale_evidence' => array_values(array_filter($stale, static fn ($value) => $value !== null && $value !== '')),
            'contradictory_evidence' => array_values($contradictory),
            'reason_codes' => array_values(array_unique($reasonCodes)),
            'policy_version' => $policyVersion,
            'coverage' => round($coverage, 6),
            'calibration_factor' => round($calibrationFactor, 6),
        ];
    }
}
