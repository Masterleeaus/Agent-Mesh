<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Integration;

final class TitanSignalIntegrationProfile
{
    public const EMITTER_SERVICE_ID = 'titan-assurance:runtime';
    public const REGISTRY_SERVICE_ID = 'titan-assurance:registry';
    public const OWNER_SOURCE = 'titan-assurance';

    public function emitterServiceId(): string
    {
        return self::EMITTER_SERVICE_ID;
    }

    public function registryServiceId(): string
    {
        return self::REGISTRY_SERVICE_ID;
    }

    /** @return array<string,mixed> */
    public function trustedEmitterDefinition(): array
    {
        return [
            'source' => self::OWNER_SOURCE,
            'source_component' => 'evidence-engine',
            'permissions' => ['signal.emit'],
            'event_type_patterns' => ['assurance.*'],
        ];
    }

    /** @return array<string,mixed> */
    public function registryActorDefinition(): array
    {
        return [
            'owner_source' => self::OWNER_SOURCE,
            'permissions' => ['signal.registry.event.manage'],
            'event_type_patterns' => ['assurance.*'],
            'subscriber_key_patterns' => [],
        ];
    }

    /** @return array<string,array<string,mixed>> */
    public function eventDefinitions(): array
    {
        return [
            'assurance.assessment.completed' => $this->definition(
                ['assessment_uuid', 'status', 'score', 'policy_version'],
                ['assessment_id', 'company_id', 'trace_id', 'correlation_id', 'causation_id', 'workflow_key', 'reason_codes', 'rewind', 'authority_decision', 'risk_decision'],
                ['info'],
            ),
            'assurance.evidence.recollection.requested' => $this->definition(
                ['assessment_uuid', 'request_id', 'reason_codes'],
                ['company_id', 'workflow_key', 'trace_id', 'correlation_id', 'causation_id', 'missing_evidence', 'stale_evidence'],
                ['info', 'warn'],
            ),
            'assurance.feedback.recorded' => $this->definition(
                ['assessment_uuid', 'feedback_id', 'feedback_type', 'accepted'],
                ['company_id', 'trace_id', 'correlation_id', 'causation_id', 'decision', 'source_ref', 'policy_version'],
                ['info'],
            ),
            'assurance.miscalibration.detected' => $this->definition(
                ['assessment_uuid', 'calibration'],
                ['assessment_id', 'company_id', 'trace_id', 'correlation_id', 'causation_id', 'notify', 'rationale'],
                ['warn', 'error'],
            ),
        ];
    }

    public function severityFor(string $eventType): string
    {
        return $eventType === 'assurance.miscalibration.detected' ? 'warn' : 'info';
    }

    /** @param list<string> $required @param list<string> $optional @param list<string> $severities @return array<string,mixed> */
    private function definition(array $required, array $optional, array $severities): array
    {
        return [
            'current_schema_version' => 1,
            'supported_schema_versions' => [1],
            'category' => 'governance',
            'allowed_scopes' => ['tenant'],
            'required_payload_fields' => $required,
            'optional_payload_fields' => $optional,
            'allow_additional_payload_fields' => false,
            'owner_source' => self::OWNER_SOURCE,
            'allowed_severities' => $severities,
            'status' => 'active',
        ];
    }
}
