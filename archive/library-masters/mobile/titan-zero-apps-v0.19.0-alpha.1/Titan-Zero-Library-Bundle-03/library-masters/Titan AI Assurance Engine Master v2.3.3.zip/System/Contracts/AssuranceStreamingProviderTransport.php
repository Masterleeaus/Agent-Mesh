<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Contracts;

interface AssuranceStreamingProviderTransport
{
    /**
     * @return array{status:int,body:mixed,response_time_ms:int,chunk_count:int}
     */
    public function stream(string $providerKey, string $modelId, array $request, callable $onChunk): array;

    /**
     * @param array<string,array{provider_key:string,model_id:string,request:array}> $requests
     * @return array<string,array{status:int,body:mixed,response_time_ms:int,chunk_count:int}>
     */
    public function streamMany(array $requests, callable $onChunk): array;
}
