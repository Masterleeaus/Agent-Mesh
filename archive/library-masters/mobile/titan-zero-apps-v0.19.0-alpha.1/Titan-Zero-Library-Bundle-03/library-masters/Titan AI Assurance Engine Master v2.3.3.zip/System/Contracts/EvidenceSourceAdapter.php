<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Contracts;

interface EvidenceSourceAdapter
{
    public function sourceKey(): string;

    /**
     * @return array<int, array<string, mixed>>
     */
    public function resolve(string $companyId, array $references): array;
}
