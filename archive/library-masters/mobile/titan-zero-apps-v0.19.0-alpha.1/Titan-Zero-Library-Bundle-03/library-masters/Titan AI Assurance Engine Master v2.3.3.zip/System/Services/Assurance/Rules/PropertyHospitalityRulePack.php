<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Rules;

final class PropertyHospitalityRulePack extends CoreRulePack
{
    public function key(): string { return 'property_hospitality.v1'; }

    protected function contextNumericThresholds(): array
    {
        return [
            'nightly_rate' => ['min' => 0],
            'deposit_amount' => ['min' => 0],
            'guest_count' => ['min' => 0],
            'occupancy_percent' => ['min' => 0, 'max' => 100],
        ];
    }

    protected function contextDateOrderings(): array
    {
        return [['start' => 'check_in_at', 'end' => 'check_out_at']];
    }
}
