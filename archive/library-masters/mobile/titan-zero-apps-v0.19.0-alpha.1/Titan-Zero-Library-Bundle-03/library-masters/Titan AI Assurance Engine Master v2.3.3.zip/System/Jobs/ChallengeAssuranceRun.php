<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Jobs;

use App\Extensions\TitanAssurance\System\Services\Assurance\AssuranceRunOrchestrator;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ChallengeAssuranceRun implements ShouldQueue, ShouldBeUnique
{
    public bool $afterCommit = true;

    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $uniqueFor = 60;

    public function __construct(
        public readonly int $runId,
        public readonly string $companyId,
    ) {
    }

    public function uniqueId(): string
    {
        return 'assurance-challenge:' . $this->companyId . ':' . $this->runId;
    }

    public function handle(AssuranceRunOrchestrator $orchestrator): void
    {
        $orchestrator->dispatchChallenge($this->runId, $this->companyId);
    }
}
