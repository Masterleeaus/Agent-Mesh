<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Integration;

use App\Extensions\TitanAssurance\System\Contracts\AssuranceIntegrationSink;
use DomainException;
use Throwable;

final class TitanSignalAssuranceSink implements AssuranceIntegrationSink
{
    private const EMITTER_AUTHORITY = 'App\\Extensions\\TitanSignalEngine\\System\\Contracts\\SignalEmitterAuthorityContract';
    private const SIGNAL_MANAGER = 'App\\Extensions\\TitanSignalEngine\\System\\Contracts\\SignalManagerContract';
    private const SIGNAL_ACTOR = 'App\\Extensions\\TitanSignalEngine\\System\\Data\\SignalActor';
    private const SIGNAL_CONTEXT = 'App\\Extensions\\TitanSignalEngine\\System\\Data\\SignalContext';

    public function __construct(
        private readonly object $container,
        private readonly TitanSignalIntegrationRegistrar $registrar,
        private readonly TitanSignalIntegrationProfile $profile,
    ) {
    }

    public function destinationKey(): string
    {
        return 'titan_signal';
    }

    /** @return array<string,mixed> */
    public function publish(array $envelope): array
    {
        $eventType = trim((string) ($envelope['event_type'] ?? ''));
        if (! array_key_exists($eventType, $this->profile->eventDefinitions())) {
            return $this->unavailable('SIGNAL_EVENT_TYPE_NOT_OWNED');
        }

        $registration = $this->registrar->ensureRegistered();
        if (($registration['ready'] ?? false) !== true) {
            return [
                'available' => false,
                'dispatched' => false,
                'reason_code' => $registration['reason_code'] ?? 'SIGNAL_REGISTRY_NOT_READY',
                'registration' => $registration,
            ];
        }

        foreach ([self::EMITTER_AUTHORITY, self::SIGNAL_MANAGER] as $contract) {
            if (! interface_exists($contract) || ! $this->bound($contract)) {
                return $this->unavailable(! interface_exists($contract) ? 'SIGNAL_RUNTIME_CONTRACT_NOT_INSTALLED' : 'SIGNAL_RUNTIME_CONTRACT_NOT_BOUND', $contract);
            }
        }
        foreach ([self::SIGNAL_ACTOR, self::SIGNAL_CONTEXT] as $class) {
            if (! class_exists($class)) {
                return $this->unavailable('SIGNAL_RUNTIME_DATA_CLASS_NOT_INSTALLED', $class);
            }
        }

        $payload = is_array($envelope['payload'] ?? null) ? $envelope['payload'] : [];
        $companyId = $this->positiveTenant($payload['company_id'] ?? null);
        $idempotencyKey = trim((string) ($envelope['idempotency_key'] ?? ''));
        if ($idempotencyKey === '') {
            throw new DomainException('Titan Signal Assurance emission requires idempotency_key.');
        }

        try {
            $emitterAuthority = $this->make(self::EMITTER_AUTHORITY);
            $manager = $this->make(self::SIGNAL_MANAGER);
            $emitter = $emitterAuthority->issue($this->profile->emitterServiceId());
            $actorClass = self::SIGNAL_ACTOR;
            $contextClass = self::SIGNAL_CONTEXT;
            $actor = new $actorClass('titan-assurance', 'system', $companyId, 'titan-assurance', null);
            $context = new $contextClass('tenant', $companyId, $actor, [], $emitter);

            $signal = [
                'event_type' => $eventType,
                'scope' => 'tenant',
                'company_id' => $companyId,
                'trace_id' => $this->nullableString($payload['trace_id'] ?? null),
                'correlation_id' => $this->nullableString($payload['correlation_id'] ?? null),
                'causation_id' => $this->nullableString($payload['causation_id'] ?? null),
                'root_causation_id' => $this->nullableString($payload['root_causation_id'] ?? null),
                'schema_version' => 1,
                'payload' => $payload,
                'metadata' => [
                    'origin_extension' => 'titan-assurance',
                    'assurance_policy_version' => $this->nullableString($payload['policy_version'] ?? null),
                ],
                'severity' => $this->profile->severityFor($eventType),
                'category' => 'governance',
                'idempotency_key' => $idempotencyKey,
                'vertical_key' => $this->nullableString($payload['vertical'] ?? null),
            ];
            $signal = array_filter($signal, static fn (mixed $value): bool => $value !== null);
            $receipt = $manager->emit($signal, $context);
            $receipt = is_array($receipt) ? $receipt : (method_exists($receipt, 'toArray') ? $receipt->toArray() : []);

            return [
                'available' => true,
                'dispatched' => true,
                'transport' => 'titan_signal_engine',
                'event_type' => $eventType,
                'registration' => $registration,
                ...$receipt,
            ];
        } catch (Throwable $exception) {
            return [
                'available' => true,
                'dispatched' => false,
                'reason_code' => 'SIGNAL_EMISSION_FAILED',
                'error_class' => $exception::class,
                'registration' => $registration,
            ];
        }
    }

    private function positiveTenant(mixed $value): int
    {
        if (! is_numeric($value) || (int) $value < 1) {
            throw new DomainException('Titan Signal requires a positive integer company_id.');
        }

        return (int) $value;
    }

    private function bound(string $contract): bool
    {
        return method_exists($this->container, 'bound') && (bool) $this->container->bound($contract);
    }

    private function make(string $contract): mixed
    {
        if (! method_exists($this->container, 'make')) {
            throw new \RuntimeException('Container does not support make().');
        }

        return $this->container->make($contract);
    }

    private function nullableString(mixed $value): ?string
    {
        $value = trim((string) ($value ?? ''));
        return $value !== '' ? $value : null;
    }

    /** @return array<string,mixed> */
    private function unavailable(string $reasonCode, ?string $contract = null): array
    {
        return array_filter([
            'available' => false,
            'dispatched' => false,
            'reason_code' => $reasonCode,
            'contract' => $contract,
        ], static fn (mixed $value): bool => $value !== null);
    }
}
