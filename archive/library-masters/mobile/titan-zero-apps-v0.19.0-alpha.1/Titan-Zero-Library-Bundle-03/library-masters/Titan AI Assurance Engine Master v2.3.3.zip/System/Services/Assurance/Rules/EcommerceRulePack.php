<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Rules;

final class EcommerceRulePack extends CoreRulePack
{
    public function key(): string { return 'ecommerce.v1'; }

    protected function contextNumericThresholds(): array
    {
        return [
            'price' => ['min' => 0],
            'quantity' => ['min' => 0],
            'shipping_amount' => ['min' => 0],
            'discount_percent' => ['min' => 0, 'max' => 100],
            'tax_percent' => ['min' => 0, 'max' => 100],
        ];
    }
}
