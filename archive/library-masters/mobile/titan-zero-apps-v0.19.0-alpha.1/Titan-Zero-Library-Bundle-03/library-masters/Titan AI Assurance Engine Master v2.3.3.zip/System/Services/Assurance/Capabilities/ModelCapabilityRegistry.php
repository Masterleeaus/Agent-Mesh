<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Capabilities;

final class ModelCapabilityRegistry
{
    /** @var array<string, array<string, mixed>> */
    private array $providerDefaults;

    /** @var array<string, string> */
    private array $familyPatterns;

    public function __construct(?array $providerDefaults = null, ?array $familyPatterns = null)
    {
        $this->providerDefaults = $providerDefaults ?? [
            'openai' => ['structured_output' => true, 'tool_use' => true, 'vision' => true],
            'anthropic' => ['structured_output' => true, 'tool_use' => true, 'vision' => true],
            'gemini' => ['structured_output' => true, 'tool_use' => true, 'vision' => true],
            'deepseek' => ['structured_output' => true, 'tool_use' => true, 'vision' => false],
            'xai' => ['structured_output' => true, 'tool_use' => true, 'vision' => true],
            'openrouter' => ['structured_output' => true, 'tool_use' => true, 'vision' => true],
        ];

        $this->familyPatterns = $familyPatterns ?? [
            '/(?:^|\/)gpt-5(?:[.\-]|$)/i' => 'gpt-5',
            '/(?:^|\/)gpt-4(?:[.o\-]|$)/i' => 'gpt-4',
            '/(?:^|\/)o[134](?:[.\-]|$)/i' => 'openai-o-series',
            '/claude.*opus/i' => 'claude-opus',
            '/claude.*sonnet/i' => 'claude-sonnet',
            '/claude.*haiku/i' => 'claude-haiku',
            '/gemini.*flash/i' => 'gemini-flash',
            '/gemini.*pro/i' => 'gemini-pro',
            '/deepseek.*reason/i' => 'deepseek-reasoner',
            '/deepseek/i' => 'deepseek-chat',
            '/grok/i' => 'grok',
        ];
    }

    public function resolve(string $provider, string $modelId): array
    {
        $provider = $this->normalizeProvider($provider);
        $modelId = trim($modelId);

        return [
            'provider' => $provider,
            'model_id' => $modelId,
            'family' => $this->family($provider, $modelId),
            'capabilities' => $this->providerDefaults[$provider] ?? [
                'structured_output' => false,
                'tool_use' => false,
                'vision' => false,
            ],
        ];
    }

    public function family(string $provider, string $modelId): string
    {
        foreach ($this->familyPatterns as $pattern => $family) {
            if (preg_match($pattern, $modelId) === 1) {
                return $family;
            }
        }

        return $this->normalizeProvider($provider) . ':' . strtolower(trim($modelId));
    }

    public function normalizeProvider(string $provider): string
    {
        $provider = strtolower(trim($provider));

        return match ($provider) {
            'open_ai', 'open-ai', 'open ai' => 'openai',
            'google', 'google-gemini' => 'gemini',
            'x-ai', 'x.ai', 'x_ai' => 'xai',
            'open_router', 'open-router' => 'openrouter',
            'deep_seek', 'deep-seek' => 'deepseek',
            default => $provider,
        };
    }
}
