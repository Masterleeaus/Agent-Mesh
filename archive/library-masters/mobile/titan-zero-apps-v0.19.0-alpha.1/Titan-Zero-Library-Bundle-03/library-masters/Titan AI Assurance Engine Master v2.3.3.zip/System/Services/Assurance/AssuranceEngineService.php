<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

use App\Extensions\TitanAssurance\System\Contracts\AssuranceEngine;
use App\Extensions\TitanAssurance\System\Events\AssuranceEvidenceLocked;
use App\Extensions\TitanAssurance\System\Events\AssuranceOutcomeRecorded;
use App\Extensions\TitanAssurance\System\Events\AssuranceRunBlocked;
use App\Extensions\TitanAssurance\System\Events\AssuranceRunCreated;
use App\Extensions\TitanAssurance\System\Models\AssuranceApproval;
use App\Extensions\TitanAssurance\System\Models\AssuranceEvent;
use App\Extensions\TitanAssurance\System\Models\AssuranceOutcome;
use App\Extensions\TitanAssurance\System\Models\AssuranceRun;
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\EvidenceSourceRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Compliance\ComplianceRulePackResolver;
use App\Extensions\TitanAssurance\System\Services\Assurance\Intelligence\AssuranceOutcomeIntelligenceService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Intelligence\AssuranceRecommendationService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\RulePackRegistry;
use App\Extensions\TitanAssurance\System\Support\AssuranceMode;
use App\Extensions\TitanAssurance\System\Support\AssuranceStatus;
use DomainException;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class AssuranceEngineService implements AssuranceEngine
{
    public function __construct(
        private readonly CompanyContextResolver $companyContext,
        private readonly RiskClassificationService $riskClassifier,
        private readonly EvidencePacketService $evidencePackets,
        private readonly AssuranceRunOrchestrator $orchestrator,
        private readonly PermissionGateService $permissionGate,
        private readonly OutcomeRecorder $outcomeRecorder,
        private readonly AssuranceCalibrationService $calibrationService,
        private readonly EvidenceSourceRegistry $evidenceSources,
        private readonly RulePackRegistry $rulePacks,
        private readonly ComplianceRulePackResolver $complianceRules,
        private readonly AssuranceOutcomeIntelligenceService $outcomeIntelligence,
        private readonly AssuranceRecommendationService $recommendationService,
    ) {
    }

    public function createRun(array $decisionPacket, array $options = []): AssuranceRun
    {
        $companyId = $this->requireCompanyId();
        $userId = Auth::id();
        $idempotencyKey = isset($options['idempotency_key']) ? trim((string) $options['idempotency_key']) : null;
        $traceContext = $this->normalizeTraceContext((array) ($options['trace'] ?? []));

        if ($idempotencyKey !== null && $idempotencyKey !== '') {
            $existing = AssuranceRun::query()
                ->where('company_id', $companyId)
                ->where('idempotency_key', $idempotencyKey)
                ->first();

            if ($existing) {
                return $existing;
            }
        }

        $externalRisk = is_array($options['risk_context'] ?? null) ? (array) $options['risk_context'] : [];
        if ($externalRisk !== [] && trim((string) ($externalRisk['risk_level'] ?? '')) !== '') {
            $risk = $externalRisk + [
                'required_assurance_mode' => AssuranceMode::STANDARD,
                'required_human_role' => null,
                'source' => 'titan_risk_engine',
            ];
        } else {
            // Backwards-compatible fallback only. Canonical v2 callers should supply Titan Risk context.
            $risk = $this->riskClassifier->classify($decisionPacket, (array) ($options['risk_overrides'] ?? []));
            $risk['source'] = 'legacy_assurance_fallback';
        }
        $mode = (string) ($options['assurance_mode'] ?? $risk['required_assurance_mode']);
        if (! in_array($mode, AssuranceMode::all(), true)) {
            throw new DomainException('Invalid assurance mode.');
        }

        $vertical = trim((string) ($options['vertical'] ?? ''));
        $rulePackKey = trim((string) ($options['rule_pack_key'] ?? ($vertical !== '' ? config('model-council.assurance.vertical_rule_packs.' . $vertical, '') : '')));
        $rulePackVersion = null;
        $complianceSourceKey = strtolower(trim((string) ($options['compliance_source_key'] ?? '')));
        $complianceJurisdiction = strtoupper(trim((string) ($options['compliance_jurisdiction'] ?? '')));
        $complianceRuleVersion = null;
        $complianceRuleHash = null;
        $complianceRuleSnapshot = null;

        if ($complianceSourceKey !== '') {
            if ($rulePackKey === '') {
                throw new DomainException('An external compliance source requires a rule_pack_key.');
            }
            if ($complianceJurisdiction === '') {
                throw new DomainException('An external compliance source requires a compliance_jurisdiction.');
            }
            $signatureRequired = (bool) config('model-council.assurance.compliance_sources.' . $complianceSourceKey . '.signature_required', false)
                || (bool) ($options['compliance_signature_required'] ?? false);
            $externalPack = $this->complianceRules->resolve(
                $companyId,
                $complianceSourceKey,
                $rulePackKey,
                $complianceJurisdiction,
                now(),
                (array) ($decisionPacket['validation_context'] ?? []),
                $signatureRequired,
            );
            $complianceRuleSnapshot = $externalPack->document();
            $rulePackVersion = $externalPack->version();
            $complianceRuleVersion = $externalPack->version();
            $complianceRuleHash = (string) ($complianceRuleSnapshot['content_hash'] ?? '');
        } elseif ($rulePackKey !== '') {
            $rulePackVersion = $this->rulePacks->resolve($rulePackKey)->version();
        }

        $redactedPacket = $this->evidencePackets->redactSecrets($decisionPacket);

        try {
            return DB::transaction(function () use ($companyId, $userId, $idempotencyKey, $traceContext, $options, $risk, $mode, $redactedPacket, $rulePackKey, $rulePackVersion, $complianceSourceKey, $complianceJurisdiction, $complianceRuleVersion, $complianceRuleHash, $complianceRuleSnapshot): AssuranceRun {
            $run = new AssuranceRun();
            $run->uuid = (string) Str::uuid();
            $run->company_id = $companyId;
            $run->company_id = $companyId;
            $run->trace_id = $traceContext['trace_id'];
            $run->correlation_id = $traceContext['correlation_id'];
            $run->causation_id = $traceContext['causation_id'];
            $run->user_id = $userId;
            $run->idempotency_key = $idempotencyKey ?: null;
            $run->source_type = $options['source_type'] ?? null;
            $run->source_id = isset($options['source_id']) ? (string) $options['source_id'] : null;
            $run->decision_type = $options['decision_type'] ?? null;
            $run->vertical = $options['vertical'] ?? null;
            $run->rule_pack_key = $rulePackKey !== '' ? $rulePackKey : null;
            $run->rule_pack_version = $rulePackVersion;
            $run->compliance_source_key = $complianceSourceKey !== '' ? $complianceSourceKey : null;
            $run->compliance_jurisdiction = $complianceJurisdiction !== '' ? $complianceJurisdiction : null;
            $run->compliance_rule_version = $complianceRuleVersion;
            $run->compliance_rule_hash = $complianceRuleHash !== '' ? $complianceRuleHash : null;
            $run->compliance_rule_snapshot = $complianceRuleSnapshot;
            $run->risk_level = $risk['risk_level'];
            $run->assurance_mode = $mode;
            $run->status = AssuranceStatus::COLLECTING_EVIDENCE;
            $run->decision_packet = $redactedPacket;
            $run->risk_context = $risk;
            $run->policy_version = (string) ($options['policy_version'] ?? config('model-council.assurance.policy_version', 'titan-assurance-v1'));
            $run->required_human_role = $risk['required_human_role'];
            $run->permission_state = 'blocked';
            $run->expires_at = now()->addMinutes((int) config('model-council.assurance.default_expiry_minutes', 1440));
            $run->save();

            $this->audit($run, 'AssuranceRunCreated', [
                'risk_level' => $run->risk_level,
                'assurance_mode' => $run->assurance_mode,
            ]);

            event(new AssuranceRunCreated($run));

            return $run->fresh();
            });
        } catch (QueryException $exception) {
            if ($idempotencyKey !== null && $idempotencyKey !== '') {
                $existing = AssuranceRun::query()
                    ->where('company_id', $companyId)
                    ->where('idempotency_key', $idempotencyKey)
                    ->first();
                if ($existing) {
                    return $existing;
                }
            }
            throw $exception;
        }
    }

    public function lockEvidence(int $runId, array $evidencePacket): AssuranceRun
    {
        $companyId = $this->requireCompanyId();
        [$resolvedPacket, $sourceSummary] = $this->resolveEvidenceSources($companyId, $evidencePacket);
        $redactedPacket = $this->evidencePackets->redactSecrets($resolvedPacket);
        $hash = $this->evidencePackets->hash($redactedPacket);

        return DB::transaction(function () use ($companyId, $runId, $redactedPacket, $hash, $sourceSummary): AssuranceRun {
            /** @var AssuranceRun $run */
            $run = AssuranceRun::query()
                ->where('company_id', $companyId)
                ->whereKey($runId)
                ->lockForUpdate()
                ->firstOrFail();

            if ($run->evidence_hash !== null) {
                if (hash_equals((string) $run->evidence_hash, $hash)) {
                    return $run;
                }

                throw new DomainException('Evidence is immutable once locked. Create a new assurance run to change the evidence packet.');
            }

            $run->decision_packet = $redactedPacket;
            $run->evidence_hash = $hash;
            $run->evidence_source_summary = $sourceSummary !== [] ? $sourceSummary : null;
            $run->status = AssuranceStatus::PENDING;
            $run->save();

            $this->audit($run, 'AssuranceEvidenceLocked', ['evidence_hash' => $hash]);
            event(new AssuranceEvidenceLocked($run));

            return $run->fresh();
        });
    }

    public function start(int $runId, array $panel, array $options = []): AssuranceRun
    {
        return $this->orchestrator->start($this->findRun($runId), $panel, $options);
    }

    public function findRun(int $runId): AssuranceRun
    {
        $companyId = $this->requireCompanyId();

        return AssuranceRun::query()
            ->where('company_id', $companyId)
            ->findOrFail($runId);
    }

    public function approve(int $runId, string $decision, string $reason, array $conditions = []): AssuranceRun
    {
        $decision = strtolower(trim($decision));
        if (! in_array($decision, ['approve', 'reject', 'request_more_evidence', 'rerun'], true)) {
            throw new DomainException('Invalid approval decision.');
        }
        if (trim($reason) === '') {
            throw new DomainException('Approval reason is required.');
        }

        $run = $this->findRun($runId);
        $userId = Auth::id();
        if (! $userId) {
            throw new DomainException('An authenticated approver is required.');
        }
        if ($run->expires_at !== null && $run->expires_at->isPast()) {
            $run->status = AssuranceStatus::EXPIRED;
            $run->permission_state = 'blocked';
            $run->completed_at = now();
            $run->save();
            throw new DomainException('This assurance run has expired and cannot be approved.');
        }

        if ($decision === 'approve') {
            if ($run->status !== AssuranceStatus::AWAITING_HUMAN_REVIEW) {
                throw new DomainException('Only an assurance run awaiting human review can be approved.');
            }

            $namedApprovers = array_values(array_map('intval', (array) (($run->risk_context['named_approver_ids'] ?? []))));
            if ($run->required_human_role === 'named_approver' && $namedApprovers !== [] && ! in_array((int) $userId, $namedApprovers, true)) {
                throw new DomainException('This critical assurance run requires a named approver.');
            }

            $gateContext = (array) (($run->scoring_components['gate_context'] ?? []));
            if ($gateContext === []) {
                throw new DomainException('Assurance controls have not been evaluated for this run.');
            }
            $gateContext['human_approved'] = true;
            $gate = $this->permissionGate->evaluate($gateContext);
            if (($gate['permission_state'] ?? 'blocked') !== 'permitted') {
                throw new DomainException('Human approval cannot override unresolved assurance control failures.');
            }
        }

        return DB::transaction(function () use ($run, $userId, $decision, $reason, $conditions): AssuranceRun {
            $approval = new AssuranceApproval();
            $approval->company_id = $run->company_id;
            $approval->assurance_run_id = $run->id;
            $approval->approver_id = $userId;
            $approval->decision = $decision;
            $approval->reason = $reason;
            $approval->conditions = $conditions;
            $approval->approved_at = now();
            $approval->save();

            if ($decision === 'approve') {
                $run->status = empty($conditions) ? AssuranceStatus::ASSURED : AssuranceStatus::ASSURED_WITH_CONDITIONS;
                $run->permission_state = 'permitted';
                $run->approved_at = now();
                $run->completed_at ??= now();
                $run->failure_code = null;
            } elseif ($decision === 'reject') {
                $run->status = AssuranceStatus::POLICY_BLOCKED;
                $run->permission_state = 'blocked';
                $run->failure_code = 'human_rejected';
                $run->completed_at = now();
                event(new AssuranceRunBlocked($run));
            } elseif ($decision === 'request_more_evidence') {
                $run->status = AssuranceStatus::INSUFFICIENT_EVIDENCE;
                $run->permission_state = 'blocked';
                $run->failure_code = 'more_evidence_requested';
                $run->completed_at = now();
            } else {
                $run->status = AssuranceStatus::SUPERSEDED;
                $run->permission_state = 'blocked';
                $run->failure_code = 'rerun_requested';
                $run->completed_at = now();
            }
            $run->save();

            $this->audit($run, 'AssuranceHumanDecisionRecorded', [
                'decision' => $decision,
                'reason' => $reason,
                'conditions' => $conditions,
            ]);

            return $run->fresh();
        });
    }

    public function cancel(int $runId, ?string $reason = null): AssuranceRun
    {
        $run = $this->findRun($runId);
        $run->status = AssuranceStatus::CANCELLED;
        $run->permission_state = 'blocked';
        $run->completed_at = now();
        $run->save();

        $this->audit($run, 'AssuranceRunCancelled', ['reason' => $reason]);

        return $run->fresh();
    }

    public function recordOutcome(int $runId, array $payload): AssuranceOutcome
    {
        $run = $this->findRun($runId);
        $actorId = Auth::id();
        if (! $actorId) {
            throw new DomainException('An authenticated actor is required to record an assurance outcome.');
        }

        $normalized = $this->outcomeRecorder->normalize($payload);

        return DB::transaction(function () use ($run, $actorId, $normalized): AssuranceOutcome {
            $outcome = new AssuranceOutcome();
            $outcome->company_id = $run->company_id;
            $outcome->assurance_run_id = $run->id;
            $outcome->outcome_type = $normalized['outcome_type'];
            $outcome->success = $normalized['success'];
            $outcome->impact = $normalized['impact'];
            $outcome->correction = $normalized['correction'];
            $outcome->recorded_by = $actorId;
            $outcome->save();

            $this->audit($run, 'AssuranceOutcomeRecorded', [
                'outcome_id' => $outcome->id,
                'outcome_type' => $outcome->outcome_type,
                'success' => $outcome->success,
            ]);
            event(new AssuranceOutcomeRecorded($run));

            return $outcome->fresh();
        });
    }

    public function calibration(array $filters = []): array
    {
        $companyId = $this->requireCompanyId();
        $query = AssuranceOutcome::query()
            ->where('company_id', $companyId)
            ->whereNotNull('success')
            ->with('run');

        $runFilters = array_intersect_key($filters, array_flip([
            'policy_version', 'risk_level', 'assurance_mode', 'vertical', 'decision_type',
        ]));
        if ($runFilters !== []) {
            $query->whereHas('run', function ($runQuery) use ($runFilters): void {
                foreach ($runFilters as $column => $value) {
                    if ($value !== null && $value !== '') {
                        $runQuery->where($column, $value);
                    }
                }
            });
        }

        $samples = $query->orderByDesc('id')->limit((int) config('model-council.assurance.analytics.max_records', 1000))->get()->map(function (AssuranceOutcome $outcome): array {
            return [
                'assurance_score' => $outcome->run?->confidence_score,
                'success' => $outcome->success,
            ];
        })->filter(fn (array $sample) => is_numeric($sample['assurance_score']) && is_bool($sample['success']))->values()->all();

        return array_merge([
            'filters' => $runFilters,
            'policy_mutation' => false,
        ], $this->calibrationService->summarize($samples));
    }

    public function intelligence(array $filters = []): array
    {
        $companyId = $this->requireCompanyId();
        $runFilters = array_intersect_key($filters, array_flip([
            'policy_version', 'risk_level', 'assurance_mode', 'vertical', 'decision_type', 'rule_pack_key',
        ]));
        $query = AssuranceRun::query()
            ->where('company_id', $companyId)
            ->with(['candidates', 'outcomes']);
        foreach ($runFilters as $column => $value) {
            if ($value !== null && $value !== '') {
                $query->where($column, $value);
            }
        }

        $records = [];
        foreach ($query->orderByDesc('id')->limit((int) config('model-council.assurance.analytics.max_records', 1000))->get() as $run) {
            $outcome = $run->outcomes->sortByDesc('id')->first();
            $components = (array) $run->scoring_components;
            $base = [
                'run_id' => $run->id,
                'occurred_at' => (string) ($run->completed_at ?? $run->updated_at ?? $run->created_at ?? ''),
                'assurance_score' => is_numeric($run->confidence_score) ? (float) $run->confidence_score : null,
                'success' => $outcome && is_bool($outcome->success) ? $outcome->success : ($outcome?->success !== null ? (bool) $outcome->success : null),
                'material_disagreement' => (string) $run->status === AssuranceStatus::MATERIAL_DISAGREEMENT
                    || (bool) (($components['disagreement']['material'] ?? false)),
                'deterministic_failed' => (string) ($run->deterministic_status ?? '') === 'failed',
                'evidence_sufficiency' => is_numeric($run->evidence_score) ? max(0.0, min(1.0, (float) $run->evidence_score / 100)) : null,
                'rule_pack_key' => (string) ($run->rule_pack_key ?? ''),
                'cost_complete' => (bool) (($components['cost_accounting']['complete'] ?? false)),
            ];

            if ($run->candidates->isEmpty()) {
                $records[] = $base + ['provider' => '', 'model_family' => '', 'candidate_status' => 'missing'];
                continue;
            }
            foreach ($run->candidates as $candidate) {
                $records[] = $base + [
                    'provider' => (string) ($candidate->provider_key ?? ''),
                    'model_family' => (string) ($candidate->model_family ?? ''),
                    'candidate_status' => (string) ($candidate->status ?? ((bool) $candidate->failed ? 'failed' : 'completed')),
                ];
            }
        }

        $recentWindow = max(1, min(1000, (int) ($filters['recent_window'] ?? config('model-council.assurance.intelligence.recent_window', 50))));
        $minimumCohort = max(1, min(100, (int) ($filters['minimum_cohort'] ?? config('model-council.assurance.intelligence.minimum_cohort', 5))));
        return array_merge([
            'filters' => $runFilters,
            'recent_window' => $recentWindow,
            'minimum_cohort' => $minimumCohort,
        ], $this->outcomeIntelligence->summarize($records, $recentWindow, $minimumCohort));
    }

    public function recommendations(array $filters = []): array
    {
        $intelligence = $this->intelligence($filters);
        return array_merge([
            'filters' => $intelligence['filters'] ?? [],
            'recent_window' => $intelligence['recent_window'] ?? null,
            'minimum_cohort' => $intelligence['minimum_cohort'] ?? null,
        ], $this->recommendationService->recommend($intelligence));
    }

    private function resolveEvidenceSources(string $companyId, array $packet): array
    {
        $requests = (array) ($packet['evidence_sources'] ?? []);
        if ($requests === []) {
            return [$packet, []];
        }

        $resolved = (array) ($packet['resolved_evidence'] ?? []);
        $summary = [];
        foreach ($requests as $request) {
            if (! is_array($request)) {
                continue;
            }
            $source = strtolower(trim((string) ($request['source'] ?? '')));
            if ($source === '') {
                throw new DomainException('Each evidence source request requires a source key.');
            }
            $records = $this->evidenceSources->for($source)->resolve($companyId, (array) ($request['references'] ?? []));
            foreach ($records as $record) {
                $resolved[] = $record;
            }
            $summary[$source] = [
                'count' => count($records),
                'hashes' => array_values(array_filter(array_map(
                    static fn (array $record) => isset($record['content_hash']) ? (string) $record['content_hash'] : null,
                    array_filter($records, 'is_array')
                ))),
            ];
        }

        $packet['resolved_evidence'] = $resolved;
        return [$packet, $summary];
    }

    private function normalizeTraceContext(array $trace): array
    {
        $traceId = trim((string) ($trace['trace_id'] ?? ''));
        if ($traceId === '') {
            $traceId = (string) Str::uuid();
        } elseif (! Str::isUuid($traceId)) {
            throw new DomainException('trace_id must be a UUID when supplied.');
        }

        $correlationId = trim((string) ($trace['correlation_id'] ?? $traceId));
        if (! Str::isUuid($correlationId)) {
            throw new DomainException('correlation_id must be a UUID when supplied.');
        }

        $causationId = trim((string) ($trace['causation_id'] ?? ''));
        if ($causationId !== '' && ! Str::isUuid($causationId)) {
            throw new DomainException('causation_id must be a UUID when supplied.');
        }

        return [
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId !== '' ? $causationId : null,
        ];
    }

    private function requireCompanyId(): string
    {
        $companyId = $this->companyContext->resolve();
        if ($companyId === null || $companyId === '') {
            throw new DomainException('A company context is required for Titan Assurance Engine operations.');
        }

        return $companyId;
    }

    private function audit(AssuranceRun $run, string $eventType, array $payload = []): void
    {
        $event = new AssuranceEvent();
        $event->company_id = $run->company_id;
        $event->company_id = $run->company_id ?: $run->company_id;
        $event->trace_id = $run->trace_id;
        $event->correlation_id = $run->correlation_id;
        $event->causation_id = $run->causation_id;
        $event->assurance_run_id = $run->id;
        $event->event_type = $eventType;
        $event->actor_id = Auth::id();
        $event->source_ip = app()->bound('request') ? request()->ip() : null;
        $event->payload = $payload;
        $event->created_at = now();
        $event->save();
    }
}
