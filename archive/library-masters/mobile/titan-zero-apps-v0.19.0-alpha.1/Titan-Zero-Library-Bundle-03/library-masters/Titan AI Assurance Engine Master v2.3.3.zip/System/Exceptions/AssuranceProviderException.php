<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Exceptions;

use RuntimeException;

class AssuranceProviderException extends RuntimeException
{
    public function __construct(
        string $message,
        public readonly string $errorClass = 'terminal',
        public readonly ?int $statusCode = null,
    ) {
        parent::__construct($message, $statusCode ?? 0);
    }
}
