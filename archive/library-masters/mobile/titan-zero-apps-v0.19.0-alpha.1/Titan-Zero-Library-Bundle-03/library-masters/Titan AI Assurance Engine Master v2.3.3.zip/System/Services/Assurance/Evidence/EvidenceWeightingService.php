<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Evidence;

final class EvidenceWeightingService
{
    public function weight(array $evidence): array
    {
        $factors = [
            'authority' => $this->factor($evidence['authority'] ?? 0),
            'relevance' => $this->factor($evidence['relevance'] ?? 0),
            'freshness' => $this->factor($evidence['freshness'] ?? 0),
            'applicability' => $this->factor($evidence['applicability'] ?? 0),
            'provenance_confidence' => $this->factor($evidence['provenance_confidence'] ?? 0),
            'contradiction_adjustment' => $this->factor($evidence['contradiction_adjustment'] ?? 0),
        ];

        $value = 1.0;
        foreach ($factors as $factor) {
            $value *= $factor;
        }

        return [
            'value' => round($value, 6),
            'score' => round($value * 100, 2),
            'factors' => $factors,
        ];
    }

    private function factor(mixed $value): float
    {
        if (! is_numeric($value)) {
            return 0.0;
        }
        return max(0.0, min(1.0, (float) $value));
    }
}
