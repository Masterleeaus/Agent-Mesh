<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

use App\Extensions\TitanAssurance\System\Contracts\EvidenceAssuranceEngine;
use App\Extensions\TitanAssurance\System\Contracts\EvidenceCollectionRequester;
use App\Extensions\TitanAssurance\System\Events\AssuranceAssessmentCompleted;
use App\Extensions\TitanAssurance\System\Events\AssuranceMiscalibrationDetected;
use App\Extensions\TitanAssurance\System\Models\AssuranceAssessment;
use App\Extensions\TitanAssurance\System\Models\AssuranceEvidenceRecord;
use App\Extensions\TitanAssurance\System\Models\AssuranceFeedback;
use App\Extensions\TitanAssurance\System\Services\Assurance\Calibration\MiscalibrationDetector;
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\AssuranceResultService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\EvidenceRecordNormalizer;
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\EvidenceWeightingService;
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\KnowledgeReferenceValidator;
use App\Extensions\TitanAssurance\System\Services\Assurance\Integration\IntegrationSinkRegistry;
use App\Extensions\TitanAssurance\System\Support\AssuranceBand;
use DomainException;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class EvidenceAssuranceEngineService implements EvidenceAssuranceEngine
{
    private const FEEDBACK_TYPES = [
        'manager_decision',
        'receiving_team_decision',
        'titan_shield',
        'crm_outcome',
        'customer_outcome',
        'titan_wisdom',
    ];

    public function __construct(
        private readonly CompanyContextResolver $companyContext,
        private readonly EvidenceRecordNormalizer $normalizer,
        private readonly EvidenceWeightingService $weighting,
        private readonly AssuranceResultService $results,
        private readonly KnowledgeReferenceValidator $knowledgeReferences,
        private readonly MiscalibrationDetector $miscalibration,
        private readonly EvidenceCollectionRequester $evidenceCollection,
        private readonly IntegrationSinkRegistry $integrationSinks,
    ) {
    }

    public function assess(array $request): AssuranceAssessment
    {
        $companyId = $this->requireCompanyId();
        $idempotencyKey = trim((string) ($request['idempotency_key'] ?? ''));
        if ($idempotencyKey !== '') {
            $existing = AssuranceAssessment::query()
                ->forTenant($companyId)
                ->where('idempotency_key', $idempotencyKey)
                ->first();
            if ($existing) {
                return $existing;
            }
        }

        $subject = $this->normalizeSubject($request['subject'] ?? null);
        $evidenceInput = (array) ($request['evidence'] ?? []);
        $normalizedEvidence = [];
        foreach ($evidenceInput as $item) {
            if (! is_array($item)) {
                throw new DomainException('Each evidence item must be an object.');
            }
            $record = $this->normalizer->normalize($item);
            if ($record['evidence_id'] === '') {
                $record['evidence_id'] = (string) Str::uuid();
            } elseif (! Str::isUuid($record['evidence_id'])) {
                throw new DomainException('evidence_id must be a UUID when supplied.');
            }
            if ($record['knowledge_reference'] !== null) {
                $record['knowledge_reference'] = $this->knowledgeReferences->normalize($record['knowledge_reference']);
            }
            $normalizedEvidence[] = $record;
        }

        $knowledgeRefs = [];
        foreach ((array) ($request['knowledge_references'] ?? []) as $reference) {
            if (! is_array($reference)) {
                throw new DomainException('Each Knowledge Authority reference must be an object.');
            }
            $knowledgeRefs[] = $this->knowledgeReferences->normalize($reference);
        }
        foreach ($normalizedEvidence as $record) {
            if (is_array($record['knowledge_reference'] ?? null)) {
                $knowledgeRefs[] = $record['knowledge_reference'];
            }
        }
        $knowledgeRefs = $this->deduplicateKnowledgeReferences($knowledgeRefs);

        $calibration = $this->currentCalibration($companyId, (string) ($request['decision_type'] ?? ''), (string) ($request['vertical'] ?? ''));
        $policyVersion = (string) ($request['policy_version'] ?? config('model-council.assurance.policy_version', 'titan-assurance-v2.1'));
        $result = $this->results->evaluate(
            $normalizedEvidence,
            (array) ($request['requirements'] ?? []),
            (float) ($calibration['calibration_factor'] ?? 1.0),
            $policyVersion,
        );

        $trace = $this->traceContext((array) ($request['trace'] ?? []));
        $uuid = (string) Str::uuid();
        $evidenceCollectionReceipt = null;
        if ($result['status'] !== AssuranceBand::GREEN && ($result['missing_evidence'] !== [] || $result['stale_evidence'] !== [])) {
            $evidenceCollectionReceipt = $this->evidenceCollection->request([
                'request_id' => hash('sha256', $companyId . ':' . ($idempotencyKey !== '' ? 'idempotency:' . $idempotencyKey : 'assessment:' . $uuid) . ':' . json_encode([$result['missing_evidence'], $result['stale_evidence']])),
                'workflow_key' => 'assurance.evidence.collect',
                'company_id' => $companyId,
                'assessment_uuid' => $uuid,
                'subject' => $subject,
                'missing_evidence' => $result['missing_evidence'],
                'stale_evidence' => $result['stale_evidence'],
                'trace_id' => $trace['trace_id'],
                'correlation_id' => $trace['correlation_id'],
                'causation_id' => $trace['causation_id'],
                'reason_codes' => $result['reason_codes'],
            ]);
        }

        $snapshot = $result + [
            'subject' => $subject,
            'decision_type' => $this->nullableString($request['decision_type'] ?? null),
            'capability' => $this->nullableString($request['capability'] ?? null),
            'capability_variant' => $this->nullableString($request['capability_variant'] ?? null),
            'workflow_key' => $this->nullableString($request['workflow_key'] ?? null),
            'vertical' => $this->nullableString($request['vertical'] ?? null),
            'jurisdiction' => $this->nullableString($request['jurisdiction'] ?? null),
            'knowledge_references' => $knowledgeRefs,
            'trace' => $trace,
            'evidence_collection' => $evidenceCollectionReceipt,
            'authority_decision' => null,
            'risk_decision' => null,
        ];

        try {
            $assessment = DB::transaction(function () use ($companyId, $idempotencyKey, $uuid, $trace, $subject, $request, $result, $knowledgeRefs, $calibration, $evidenceCollectionReceipt, $snapshot, $policyVersion, $normalizedEvidence): AssuranceAssessment {
                $assessment = new AssuranceAssessment();
                $assessment->uuid = $uuid;
                $assessment->company_id = $companyId;
                $assessment->idempotency_key = $idempotencyKey !== '' ? $idempotencyKey : null;
                $assessment->trace_id = $trace['trace_id'];
                $assessment->correlation_id = $trace['correlation_id'];
                $assessment->causation_id = $trace['causation_id'];
                $assessment->subject = $subject;
                $assessment->decision_type = $this->nullableString($request['decision_type'] ?? null);
                $assessment->capability = $this->nullableString($request['capability'] ?? null);
                $assessment->capability_variant = $this->nullableString($request['capability_variant'] ?? null);
                $assessment->workflow_key = $this->nullableString($request['workflow_key'] ?? null);
                $assessment->vertical = $this->nullableString($request['vertical'] ?? null);
                $assessment->jurisdiction = $this->nullableString($request['jurisdiction'] ?? null);
                $assessment->status = $result['status'];
                $assessment->score = $result['score'];
                $assessment->evidence_used = $result['evidence_used'];
                $assessment->missing_evidence = $result['missing_evidence'];
                $assessment->stale_evidence = $result['stale_evidence'];
                $assessment->contradictory_evidence = $result['contradictory_evidence'];
                $assessment->reason_codes = $result['reason_codes'];
                $assessment->knowledge_references = $knowledgeRefs !== [] ? $knowledgeRefs : null;
                $assessment->calibration_metadata = $calibration;
                $assessment->evidence_collection_receipt = $evidenceCollectionReceipt;
                $assessment->result_snapshot = $snapshot;
                $assessment->policy_version = $policyVersion;
                $assessment->created_by = Auth::id();
                $assessment->evaluated_at = now();
                $assessment->save();

                foreach ($normalizedEvidence as $record) {
                    $weight = $this->weighting->weight($record);
                    $model = new AssuranceEvidenceRecord();
                    $model->company_id = $companyId;
                    $model->assurance_assessment_id = $assessment->id;
                    $model->evidence_id = $record['evidence_id'];
                    $model->evidence_type = $record['evidence_type'];
                    $model->subject = is_array($record['subject']) ? $record['subject'] : ['value' => $record['subject']];
                    $model->source = $record['source'];
                    $model->provenance = $record['provenance'];
                    $model->captured_at = $record['captured_at'];
                    $model->effective_at = $record['effective_at'];
                    $model->expires_at = $record['expires_at'];
                    $model->freshness = $record['freshness'];
                    $model->confidence = $record['confidence'];
                    $model->authority = $record['authority'];
                    $model->relevance = $record['relevance'];
                    $model->applicability = $record['applicability'];
                    $model->provenance_confidence = $record['provenance_confidence'];
                    $model->contradiction_adjustment = $record['contradiction_adjustment'];
                    $model->weight_score = $weight['score'];
                    $model->jurisdiction = $record['jurisdiction'];
                    $model->vertical = $record['vertical'];
                    $model->scope = is_array($record['scope']) ? $record['scope'] : ($record['scope'] !== null ? ['value' => $record['scope']] : null);
                    $model->hash = $record['hash'];
                    $model->verification_state = $record['verification_state'];
                    $model->content = is_array($record['content']) ? $record['content'] : ($record['content'] !== null ? ['value' => $record['content']] : null);
                    $model->contradicts = $record['contradicts'];
                    $model->knowledge_reference = $record['knowledge_reference'];
                    $model->save();
                }

                return $assessment;
            });
        } catch (QueryException $exception) {
            if ($idempotencyKey !== '') {
                $existing = AssuranceAssessment::query()->forTenant($companyId)->where('idempotency_key', $idempotencyKey)->first();
                if ($existing) {
                    return $existing;
                }
            }
            throw $exception;
        }

        $resultSnapshot = (array) $assessment->result_snapshot;
        if (is_array($assessment->evidence_collection_receipt)) {
            $collectionReceipt = (array) $assessment->evidence_collection_receipt;
            $collectionPayload = [
                'company_id' => $assessment->company_id,
                'assessment_uuid' => $assessment->uuid,
                'request_id' => (string) ($collectionReceipt['request_id'] ?? ''),
                'workflow_key' => (string) ($collectionReceipt['workflow_key'] ?? 'assurance.evidence.collect'),
                'trace_id' => $assessment->trace_id,
                'correlation_id' => $assessment->correlation_id,
                'causation_id' => $assessment->causation_id,
                'missing_evidence' => (array) $assessment->missing_evidence,
                'stale_evidence' => (array) $assessment->stale_evidence,
                'reason_codes' => (array) $assessment->reason_codes,
            ];
            $collectionReceipts = $this->integrationSinks->dispatch(
                ['titan_signal'],
                'assurance.evidence.recollection.requested',
                $collectionPayload,
                'assurance-recollection:' . $collectionPayload['request_id'],
            );
            $collectionReceipt['integration_receipts'] = $collectionReceipts;
            $assessment->evidence_collection_receipt = $collectionReceipt;
            $resultSnapshot['evidence_collection'] = $collectionReceipt;
        }

        $receipt = $this->receipt($assessment);
        $integrationReceipts = $this->integrationSinks->dispatch(
            ['titan_signal', 'titan_rewind'],
            'assurance.assessment.completed',
            $receipt,
            'assurance-assessment:' . $assessment->uuid,
        );
        $assessment->integration_receipts = $integrationReceipts;
        $resultSnapshot['integration_receipts'] = $integrationReceipts;
        $assessment->result_snapshot = $resultSnapshot;
        $assessment->save();

        event(new AssuranceAssessmentCompleted($receipt + ['integration_receipts' => $integrationReceipts]));
        return $assessment->fresh(['evidenceRecords']);
    }

    public function findAssessment(int $assessmentId): AssuranceAssessment
    {
        return AssuranceAssessment::query()
            ->forTenant($this->requireCompanyId())
            ->with(['evidenceRecords', 'feedback'])
            ->findOrFail($assessmentId);
    }

    public function recordFeedback(int $assessmentId, array $payload): AssuranceFeedback
    {
        $assessment = $this->findAssessment($assessmentId);
        $type = strtolower(trim((string) ($payload['feedback_type'] ?? '')));
        if (! in_array($type, self::FEEDBACK_TYPES, true)) {
            throw new DomainException('Invalid assurance feedback_type.');
        }
        $sourceRef = $this->nullableString($payload['source_ref'] ?? null);
        $idempotencyKey = trim((string) ($payload['idempotency_key'] ?? ''));
        if ($idempotencyKey === '' && $sourceRef !== null) {
            $idempotencyKey = hash('sha256', $assessment->company_id . ':' . $assessment->id . ':' . $type . ':' . $sourceRef);
        }
        if ($idempotencyKey !== '') {
            $existing = AssuranceFeedback::query()
                ->where('company_id', $assessment->company_id)
                ->where('idempotency_key', $idempotencyKey)
                ->first();
            if ($existing) {
                return $existing;
            }
        }
        $accepted = $payload['accepted'] ?? null;
        if (! is_bool($accepted)) {
            if ($accepted === 1 || $accepted === 0 || $accepted === '1' || $accepted === '0') {
                $accepted = (bool) $accepted;
            } else {
                throw new DomainException('accepted must be boolean.');
            }
        }

        $actorId = Auth::id();
        if (! $actorId) {
            throw new DomainException('An authenticated actor is required to record assurance feedback.');
        }

        $feedback = new AssuranceFeedback();
        $feedback->company_id = $assessment->company_id;
        $feedback->assurance_assessment_id = $assessment->id;
        $feedback->feedback_type = $type;
        $feedback->idempotency_key = $idempotencyKey !== '' ? $idempotencyKey : null;
        $feedback->source_ref = $sourceRef;
        $feedback->accepted = $accepted;
        $feedback->decision = $this->nullableString($payload['decision'] ?? null);
        $feedback->metadata = is_array($payload['metadata'] ?? null) ? $payload['metadata'] : [];
        $feedback->recorded_by = $actorId;
        $feedback->recorded_at = now();
        $feedback->save();

        $feedbackReceipt = [
            'company_id' => $assessment->company_id,
            'assessment_uuid' => $assessment->uuid,
            'feedback_id' => $feedback->id,
            'feedback_type' => $feedback->feedback_type,
            'accepted' => (bool) $feedback->accepted,
            'decision' => $feedback->decision,
            'source_ref' => $feedback->source_ref,
            'trace_id' => $assessment->trace_id,
            'correlation_id' => $assessment->correlation_id,
            'causation_id' => $assessment->causation_id,
            'policy_version' => $assessment->policy_version,
        ];
        $feedbackSignalReceipts = $this->integrationSinks->dispatch(
            ['titan_signal'],
            'assurance.feedback.recorded',
            $feedbackReceipt,
            'assurance-feedback:' . $assessment->uuid . ':' . $feedback->id,
        );
        $feedbackMetadata = (array) $feedback->metadata;
        $feedbackMetadata['integration_receipts']['feedback_recorded'] = $feedbackSignalReceipts;
        $feedback->metadata = $feedbackMetadata;
        $feedback->save();

        $calibration = $this->currentCalibration(
            (string) $assessment->company_id,
            (string) ($assessment->decision_type ?? ''),
            (string) ($assessment->vertical ?? ''),
        );
        if (($calibration['detected'] ?? false) === true) {
            $miscalibrationReceipt = [
                'company_id' => $assessment->company_id,
                'assessment_id' => $assessment->id,
                'assessment_uuid' => $assessment->uuid,
                'trace_id' => $assessment->trace_id,
                'correlation_id' => $assessment->correlation_id,
                'causation_id' => $assessment->causation_id,
                'calibration' => $calibration,
                'notify' => ['titan_autonomy', 'titan_ai_core', 'titan_signal', 'titan_wisdom'],
                'rationale' => ['reason_codes' => $calibration['reason_codes'] ?? []],
            ];
            $miscalibrationReceipt['integration_receipts'] = $this->integrationSinks->dispatch(
                $miscalibrationReceipt['notify'],
                'assurance.miscalibration.detected',
                $miscalibrationReceipt,
                'assurance-miscalibration:' . $assessment->uuid . ':' . $feedback->id,
            );
            $feedbackMetadata = (array) $feedback->metadata;
            $feedbackMetadata['miscalibration'] = $calibration;
            $feedbackMetadata['integration_receipts']['miscalibration'] = $miscalibrationReceipt['integration_receipts'];
            $feedback->metadata = $feedbackMetadata;
            $feedback->save();
            event(new AssuranceMiscalibrationDetected($miscalibrationReceipt));
        }

        return $feedback->fresh();
    }

    private function currentCalibration(string $companyId, string $decisionType, string $vertical): array
    {
        $query = AssuranceFeedback::query()
            ->where('company_id', $companyId)
            ->whereNotNull('accepted')
            ->with('assessment');

        $feedback = $query->orderByDesc('id')->limit((int) config('model-council.assurance.evidence_core.calibration_window', 200))->get();
        $grouped = [];
        foreach ($feedback as $item) {
            $assessment = $item->assessment;
            if (! $assessment) {
                continue;
            }
            if ($decisionType !== '' && (string) $assessment->decision_type !== $decisionType) {
                continue;
            }
            if ($vertical !== '' && (string) $assessment->vertical !== $vertical) {
                continue;
            }
            $key = (string) $assessment->id;
            $grouped[$key] ??= ['status' => (string) $assessment->status, 'accepted' => true];
            if ((bool) $item->accepted === false) {
                $grouped[$key]['accepted'] = false;
            }
        }

        return $this->miscalibration->detect(array_values($grouped));
    }

    private function receipt(AssuranceAssessment $assessment): array
    {
        return [
            'assessment_id' => $assessment->id,
            'assessment_uuid' => $assessment->uuid,
            'company_id' => $assessment->company_id,
            'trace_id' => $assessment->trace_id,
            'correlation_id' => $assessment->correlation_id,
            'causation_id' => $assessment->causation_id,
            'status' => $assessment->status,
            'score' => $assessment->score,
            'workflow_key' => $assessment->workflow_key,
            'reason_codes' => $assessment->reason_codes,
            'policy_version' => $assessment->policy_version,
            'rewind' => [
                'decision_type' => $assessment->decision_type,
                'capability' => $assessment->capability,
                'workflow_key' => $assessment->workflow_key,
                'evidence_ids' => array_values(array_filter(array_map(static fn (array $item) => $item['evidence_id'] ?? null, (array) $assessment->evidence_used))),
            ],
            'authority_decision' => null,
            'risk_decision' => null,
        ];
    }

    private function traceContext(array $trace): array
    {
        $traceId = $this->uuidOrNew($trace['trace_id'] ?? null);
        $correlationId = $this->uuidOrNew($trace['correlation_id'] ?? $traceId);
        $causationId = $this->uuidOrNull($trace['causation_id'] ?? null);
        return ['trace_id' => $traceId, 'correlation_id' => $correlationId, 'causation_id' => $causationId];
    }

    private function uuidOrNew(mixed $value): string
    {
        $value = trim((string) ($value ?? ''));
        if ($value === '') {
            return (string) Str::uuid();
        }
        if (! Str::isUuid($value)) {
            throw new DomainException('trace_id and correlation_id must be UUIDs when supplied.');
        }
        return $value;
    }

    private function uuidOrNull(mixed $value): ?string
    {
        $value = trim((string) ($value ?? ''));
        if ($value === '') {
            return null;
        }
        if (! Str::isUuid($value)) {
            throw new DomainException('causation_id must be a UUID when supplied.');
        }
        return $value;
    }

    private function normalizeSubject(mixed $subject): array
    {
        if (is_array($subject) && $subject !== []) {
            return $subject;
        }
        $value = trim((string) ($subject ?? ''));
        if ($value === '') {
            throw new DomainException('subject is required for an assurance assessment.');
        }
        return ['value' => $value];
    }

    private function deduplicateKnowledgeReferences(array $references): array
    {
        $deduped = [];
        foreach ($references as $reference) {
            $key = hash('sha256', json_encode($reference, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '');
            $deduped[$key] = $reference;
        }
        return array_values($deduped);
    }

    private function nullableString(mixed $value): ?string
    {
        $value = trim((string) ($value ?? ''));
        return $value !== '' ? $value : null;
    }

    private function requireCompanyId(): string
    {
        $companyId = $this->companyContext->resolve();
        if ($companyId === null || $companyId === '') {
            throw new DomainException('A tenant company context is required for Titan Assurance Engine operations.');
        }
        return $companyId;
    }
}
