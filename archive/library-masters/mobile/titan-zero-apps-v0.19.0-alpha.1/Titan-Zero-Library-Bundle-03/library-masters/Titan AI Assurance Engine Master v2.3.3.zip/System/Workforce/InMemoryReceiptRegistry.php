<?php
declare(strict_types=1);
namespace App\Extensions\TitanAssurance\System\Workforce;
final class InMemoryReceiptRegistry implements ReceiptRegistry { private array $receipts=[]; private array $idem=[]; public function put(array $r): void { $id=(string)($r['receipt_id']??''); if($id==='') throw new \InvalidArgumentException('receipt_id required'); $this->receipts[$id]=$r; if(isset($r['company_id'],$r['idempotency_key'])) $this->idem[$r['company_id'].'|'.$r['idempotency_key']]=$r; } public function get(string $id): ?array { return $this->receipts[$id]??null; } public function findByIdempotency(string $companyId,string $key): ?array { return $this->idem[$companyId.'|'.$key]??null; } }
