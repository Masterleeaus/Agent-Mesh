<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Integration;

use App\Extensions\TitanAssurance\System\Models\AssuranceAssessment;
use Carbon\CarbonInterface;

final class LatestEvidenceAssessmentResolver
{
    public function __construct(private readonly int $maxAgeMinutes = 60)
    {
    }

    public function resolve(
        string $companyId,
        string $capability,
        ?string $workflowKey,
        array $context = [],
    ): ?AssuranceAssessment {
        $companyId = trim($companyId);
        $capability = trim($capability);
        if ($companyId === '' || $capability === '') {
            return null;
        }

        $query = AssuranceAssessment::query()->forTenant($companyId);
        $assessmentUuid = trim((string) ($context['assessment_uuid'] ?? ''));
        if ($assessmentUuid !== '') {
            return $query->where('uuid', $assessmentUuid)->first();
        }
        $assessmentId = (int) ($context['assessment_id'] ?? 0);
        if ($assessmentId > 0) {
            return $query->whereKey($assessmentId)->first();
        }

        $query->where('capability', $capability);
        $workflowKey = trim((string) ($workflowKey ?? ''));
        if ($workflowKey !== '') {
            $query->where(function ($inner) use ($workflowKey): void {
                $inner->where('workflow_key', $workflowKey)->orWhereNull('workflow_key');
            });
        }

        return $query->latest('evaluated_at')->latest('id')->first();
    }

    public function toProjectionInput(AssuranceAssessment $assessment): array
    {
        $evaluatedAt = $assessment->evaluated_at;
        $expired = false;
        if ($this->maxAgeMinutes > 0 && $evaluatedAt instanceof CarbonInterface) {
            $expired = $evaluatedAt->copy()->addMinutes($this->maxAgeMinutes)->isPast();
        } elseif ($this->maxAgeMinutes > 0 && $evaluatedAt !== null) {
            $timestamp = strtotime((string) $evaluatedAt);
            $expired = $timestamp !== false && ($timestamp + ($this->maxAgeMinutes * 60)) < time();
        }

        return [
            'status' => (string) $assessment->status,
            'score' => (float) $assessment->score,
            'uuid' => (string) $assessment->uuid,
            'reason_codes' => (array) $assessment->reason_codes,
            'policy_version' => (string) $assessment->policy_version,
            'calibration_metadata' => (array) $assessment->calibration_metadata,
            'calibration_ref' => 'assurance-assessment:' . (string) $assessment->uuid,
            'expired' => $expired,
        ];
    }
}
