<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

use App\Extensions\TitanAssurance\System\Events\AssuranceCandidateCompleted;
use App\Extensions\TitanAssurance\System\Exceptions\AssuranceProviderException;
use App\Extensions\TitanAssurance\System\Models\AssuranceCandidate;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\ProviderExecutionGateway;
use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\UsageCostCalculator;
use App\Extensions\TitanAssurance\System\Support\AssuranceCandidateStatus;
use App\Extensions\TitanAssurance\System\Support\AssuranceStatus;
use RuntimeException;
use Throwable;

final class CandidateExecutionService
{
    public function __construct(
        private readonly ProviderExecutionGateway $gateway,
        private readonly UsageCostCalculator $costCalculator,
        private readonly AdversarialChallengeService $challenge,
    ) {
    }

    public function execute(int $candidateId, string $companyId): AssuranceCandidate
    {
        /** @var AssuranceCandidate $candidate */
        $candidate = AssuranceCandidate::query()
            ->with(['run', 'run.candidates'])
            ->where('company_id', $companyId)
            ->whereKey($candidateId)
            ->firstOrFail();
        if (in_array((string) $candidate->status, AssuranceCandidateStatus::terminal(), true)) {
            return $candidate;
        }
        if (in_array((string) $candidate->run->status, [AssuranceStatus::CANCELLED, AssuranceStatus::EXPIRED, AssuranceStatus::SUPERSEDED], true)) {
            $candidate->status = AssuranceCandidateStatus::CANCELLED;
            $candidate->failed = false;
            $candidate->failure_reason = 'Assurance run is no longer executable.';
            $candidate->completed_at = now();
            $candidate->save();
            return $candidate->fresh();
        }

        $candidate->status = AssuranceCandidateStatus::RUNNING;
        if ((string) $candidate->assigned_role !== 'adversarial_challenger' && in_array((string) $candidate->run->status, [AssuranceStatus::QUEUED, AssuranceStatus::PENDING], true)) {
            $candidate->run->status = AssuranceStatus::RUNNING;
            $candidate->run->started_at ??= now();
            $candidate->run->save();
        }
        $candidate->started_at ??= now();
        $candidate->attempt_count = ((int) $candidate->attempt_count) + 1;
        $candidate->failed = false;
        $candidate->save();

        $messages = $this->messages($candidate);
        $options = [
            'temperature' => 0.1,
            'max_tokens' => (int) config('model-council.assurance.providers.max_output_tokens', 2048),
        ];
        $candidate->request_hash = hash('sha256', json_encode([
            'provider' => (string) $candidate->provider_key,
            'model' => (string) $candidate->model_id,
            'messages' => $messages,
            'options' => $options,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '');
        $candidate->save();

        try {
            $result = $this->gateway->execute(
                (string) $candidate->provider_key,
                (string) $candidate->model_id,
                $messages,
                $options,
            );
            $text = trim((string) ($result['text'] ?? ''));
            $structured = $this->decodeStructured($text);

            $candidate->response_text = $text;
            $candidate->structured_response = $structured;
            $candidate->evidence_references = (array) ($structured['evidence'] ?? []);
            $usage = (array) ($result['usage'] ?? []);
            $cost = $this->costCalculator->calculate((string) $candidate->provider_key, (string) $candidate->model_id, $usage);
            $candidate->usage = array_merge($usage, $cost);
            $candidate->normalized_usage = $usage;
            $candidate->pricing_version = (string) ($cost['pricing_version'] ?? '');
            $candidate->effective_cost = $cost['effective_cost'];
            $candidate->response_time_ms = (int) ($result['response_time_ms'] ?? 0);
            $candidate->response_hash = hash('sha256', $text);
            $candidate->candidate_confidence = isset($structured['confidence']) && is_numeric($structured['confidence'])
                ? max(0, min(100, (float) $structured['confidence'] * 100))
                : null;
            $candidate->cost = $cost['effective_cost'];
            $candidate->status = AssuranceCandidateStatus::COMPLETED;
            $candidate->failed = false;
            $candidate->error_class = null;
            $candidate->failure_reason = null;
            $candidate->completed_at = now();
            $candidate->save();
            event(new AssuranceCandidateCompleted($candidate->run));

            return $candidate->fresh();
        } catch (AssuranceProviderException $exception) {
            if ($exception->errorClass !== 'retryable') {
                $this->markFailure($candidate, $exception->errorClass, $exception->getMessage(), false);
                return $candidate->fresh();
            }
            throw $exception;
        } catch (Throwable $exception) {
            $this->markFailure($candidate, 'retryable', $exception->getMessage(), true);
            throw new RuntimeException($exception->getMessage(), 0, $exception);
        }
    }

    private function messages(AssuranceCandidate $candidate): array
    {
        $run = $candidate->run;
        $payload = (array) $run->decision_packet;
        if ((string) $candidate->assigned_role === 'adversarial_challenger') {
            $payload = $this->challenge->buildPacket(
                (array) $run->decision_packet,
                $run->candidates
                    ->where('assigned_role', '!=', 'adversarial_challenger')
                    ->map(fn (AssuranceCandidate $item) => ['structured_response' => (array) $item->structured_response])
                    ->values()->all(),
            );
        }

        $role = trim((string) $candidate->assigned_role) ?: 'independent_assurance_reviewer';
        return [
            [
                'role' => 'system',
                'content' => "You are {$role}. Evaluate only the supplied decision packet and evidence. Be explicit about uncertainty and unsupported claims. Return JSON only with exactly these top-level keys: answer, confidence, claims, evidence, risks, assumptions. confidence must be 0..1. claims must contain claim and evidence_ids fields. evidence items must contain id and source.",
            ],
            [
                'role' => 'user',
                'content' => json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '{}',
            ],
        ];
    }

    private function decodeStructured(string $text): array
    {
        $candidate = trim($text);
        $candidate = preg_replace('/^```(?:json)?\s*/i', '', $candidate) ?? $candidate;
        $candidate = preg_replace('/\s*```$/', '', $candidate) ?? $candidate;
        $decoded = json_decode($candidate, true);
        if (is_array($decoded)) {
            return $decoded;
        }

        $start = strpos($candidate, '{');
        $end = strrpos($candidate, '}');
        if ($start !== false && $end !== false && $end > $start) {
            $decoded = json_decode(substr($candidate, $start, $end - $start + 1), true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }

        return [
            'answer' => $text,
            'confidence' => null,
            'claims' => [],
            'evidence' => [],
            'risks' => [],
            'assumptions' => [],
            '_parse_error' => 'provider_response_was_not_valid_json',
        ];
    }

    private function markFailure(AssuranceCandidate $candidate, string $errorClass, string $message, bool $retryable): void
    {
        $candidate->status = $retryable ? AssuranceCandidateStatus::RETRYABLE_FAILED : AssuranceCandidateStatus::FAILED;
        $candidate->failed = ! $retryable;
        $candidate->error_class = $errorClass;
        $candidate->failure_reason = mb_substr($message, 0, 4000);
        if (! $retryable) {
            $candidate->completed_at = now();
        }
        $candidate->save();
    }
}
