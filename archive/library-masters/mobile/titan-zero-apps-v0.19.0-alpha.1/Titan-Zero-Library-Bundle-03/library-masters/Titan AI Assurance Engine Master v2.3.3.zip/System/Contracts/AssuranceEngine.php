<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Contracts;

use App\Extensions\TitanAssurance\System\Models\AssuranceRun;
use App\Extensions\TitanAssurance\System\Models\AssuranceOutcome;

interface AssuranceEngine
{
    public function createRun(array $decisionPacket, array $options = []): AssuranceRun;

    public function lockEvidence(int $runId, array $evidencePacket): AssuranceRun;

    public function start(int $runId, array $panel, array $options = []): AssuranceRun;

    public function findRun(int $runId): AssuranceRun;

    public function approve(int $runId, string $decision, string $reason, array $conditions = []): AssuranceRun;

    public function cancel(int $runId, ?string $reason = null): AssuranceRun;

    public function recordOutcome(int $runId, array $payload): AssuranceOutcome;

    public function calibration(array $filters = []): array;

    public function intelligence(array $filters = []): array;

    public function recommendations(array $filters = []): array;
}
