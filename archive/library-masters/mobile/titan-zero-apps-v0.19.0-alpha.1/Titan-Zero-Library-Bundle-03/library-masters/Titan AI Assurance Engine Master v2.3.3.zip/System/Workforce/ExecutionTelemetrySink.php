<?php
declare(strict_types=1);
namespace App\Extensions\TitanAssurance\System\Workforce;
interface ExecutionTelemetrySink { public function record(array $event): void; }
