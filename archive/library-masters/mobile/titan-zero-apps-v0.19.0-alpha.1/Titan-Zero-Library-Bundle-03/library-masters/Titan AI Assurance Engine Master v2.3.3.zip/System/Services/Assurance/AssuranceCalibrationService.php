<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

final class AssuranceCalibrationService
{
    public function summarize(array $samples): array
    {
        $normalized = [];
        foreach ($samples as $sample) {
            if (! is_array($sample) || ! is_numeric($sample['assurance_score'] ?? null) || ! is_bool($sample['success'] ?? null)) {
                continue;
            }
            $score = max(0.0, min(100.0, (float) $sample['assurance_score']));
            $normalized[] = ['score' => $score, 'success' => (bool) $sample['success']];
        }

        $count = count($normalized);
        if ($count === 0) {
            return [
                'sample_count' => 0,
                'success_rate' => null,
                'mean_assurance_score' => null,
                'predicted_success_rate' => null,
                'calibration_gap' => null,
                'brier_score' => null,
                'score_buckets' => $this->emptyBuckets(),
            ];
        }

        $successes = 0;
        $scoreSum = 0.0;
        $brier = 0.0;
        $buckets = $this->emptyBuckets();

        foreach ($normalized as $sample) {
            $score = $sample['score'];
            $success = $sample['success'];
            $probability = $score / 100;
            $outcome = $success ? 1.0 : 0.0;
            $successes += $success ? 1 : 0;
            $scoreSum += $score;
            $brier += ($probability - $outcome) ** 2;

            $bucketKey = $this->bucketKey($score);
            $buckets[$bucketKey]['sample_count']++;
            $buckets[$bucketKey]['success_count'] += $success ? 1 : 0;
            $buckets[$bucketKey]['score_sum'] += $score;
        }

        foreach ($buckets as $key => $bucket) {
            $bucketCount = $bucket['sample_count'];
            $buckets[$key] = [
                'sample_count' => $bucketCount,
                'success_rate' => $bucketCount > 0 ? round($bucket['success_count'] / $bucketCount, 6) : null,
                'mean_assurance_score' => $bucketCount > 0 ? round($bucket['score_sum'] / $bucketCount, 4) : null,
            ];
        }

        $successRate = $successes / $count;
        $meanScore = $scoreSum / $count;
        $predicted = $meanScore / 100;

        return [
            'sample_count' => $count,
            'success_rate' => round($successRate, 6),
            'mean_assurance_score' => round($meanScore, 4),
            'predicted_success_rate' => round($predicted, 6),
            'calibration_gap' => round($successRate - $predicted, 6),
            'brier_score' => round($brier / $count, 6),
            'score_buckets' => $buckets,
        ];
    }

    private function emptyBuckets(): array
    {
        return [
            '0-59' => ['sample_count' => 0, 'success_count' => 0, 'score_sum' => 0.0],
            '60-69' => ['sample_count' => 0, 'success_count' => 0, 'score_sum' => 0.0],
            '70-79' => ['sample_count' => 0, 'success_count' => 0, 'score_sum' => 0.0],
            '80-89' => ['sample_count' => 0, 'success_count' => 0, 'score_sum' => 0.0],
            '90-100' => ['sample_count' => 0, 'success_count' => 0, 'score_sum' => 0.0],
        ];
    }

    private function bucketKey(float $score): string
    {
        return match (true) {
            $score >= 90 => '90-100',
            $score >= 80 => '80-89',
            $score >= 70 => '70-79',
            $score >= 60 => '60-69',
            default => '0-59',
        };
    }
}
