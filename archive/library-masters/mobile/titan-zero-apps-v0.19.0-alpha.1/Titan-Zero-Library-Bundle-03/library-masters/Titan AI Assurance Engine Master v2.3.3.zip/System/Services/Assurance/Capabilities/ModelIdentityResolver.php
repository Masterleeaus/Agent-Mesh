<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Capabilities;

final class ModelIdentityResolver
{
    public function __construct(private readonly ModelCapabilityRegistry $capabilities)
    {
    }

    public function resolve(string $provider, string $modelId, ?string $snapshot = null): array
    {
        $resolved = $this->capabilities->resolve($provider, $modelId);
        $resolved['snapshot'] = $snapshot !== null && trim($snapshot) !== '' ? trim($snapshot) : null;
        $resolved['identity'] = implode(':', array_filter([
            $resolved['provider'],
            $resolved['model_id'],
            $resolved['snapshot'],
        ], static fn ($value) => $value !== null && $value !== ''));

        return $resolved;
    }
}
