<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Contracts;

interface EvidenceCollectionRequester
{
    public function request(array $request): array;
}
