<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Providers;

final class XAIAdapter extends AbstractProviderAdapter
{
    public function providerKey(): string
    {
        return 'xai';
    }
}
