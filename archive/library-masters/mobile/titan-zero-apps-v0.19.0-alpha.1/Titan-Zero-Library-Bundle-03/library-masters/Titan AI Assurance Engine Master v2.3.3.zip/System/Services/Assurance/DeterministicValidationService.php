<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

class DeterministicValidationService
{
    public function validate(array $decisionPacket, array $rules = []): array
    {
        $findings = [];

        foreach ((array) ($rules['required_fields'] ?? []) as $field) {
            if (! data_get($decisionPacket, (string) $field)) {
                $findings[] = [
                    'type' => 'required_field',
                    'severity' => 'hard',
                    'claim' => sprintf('Required field missing: %s', $field),
                    'resolution_status' => 'unresolved',
                ];
            }
        }

        foreach ((array) ($rules['numeric_thresholds'] ?? []) as $field => $constraint) {
            $value = data_get($decisionPacket, (string) $field);
            if ($value === null || ! is_numeric($value)) {
                continue;
            }

            if (isset($constraint['min']) && (float) $value < (float) $constraint['min']) {
                $findings[] = $this->thresholdFinding((string) $field, 'minimum', (float) $constraint['min'], (float) $value);
            }
            if (isset($constraint['max']) && (float) $value > (float) $constraint['max']) {
                $findings[] = $this->thresholdFinding((string) $field, 'maximum', (float) $constraint['max'], (float) $value);
            }
        }

        $hardFailures = count(array_filter($findings, fn (array $finding) => ($finding['severity'] ?? '') === 'hard'));

        return [
            'status' => $hardFailures > 0 ? 'failed' : 'passed',
            'hard_failures' => $hardFailures,
            'findings' => $findings,
        ];
    }

    private function thresholdFinding(string $field, string $kind, float $threshold, float $actual): array
    {
        return [
            'type' => 'threshold',
            'severity' => 'hard',
            'claim' => sprintf('%s violates %s threshold %.4F (actual %.4F)', $field, $kind, $threshold, $actual),
            'resolution_status' => 'unresolved',
        ];
    }
}
