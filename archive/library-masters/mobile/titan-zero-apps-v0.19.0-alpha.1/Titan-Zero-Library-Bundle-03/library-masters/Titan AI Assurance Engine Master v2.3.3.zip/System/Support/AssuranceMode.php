<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Support;

final class AssuranceMode
{
    public const STANDARD = 'standard';
    public const HIGH = 'high';
    public const CRITICAL = 'critical';

    public static function all(): array
    {
        return [self::STANDARD, self::HIGH, self::CRITICAL];
    }
}
