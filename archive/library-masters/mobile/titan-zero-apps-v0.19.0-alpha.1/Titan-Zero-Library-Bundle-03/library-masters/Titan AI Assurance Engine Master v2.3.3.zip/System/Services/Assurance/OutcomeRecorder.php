<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

use DomainException;

final class OutcomeRecorder
{
    public function normalize(array $payload): array
    {
        $type = trim((string) ($payload['outcome_type'] ?? ''));
        if ($type === '') {
            throw new DomainException('outcome_type is required.');
        }

        $success = $payload['success'] ?? null;
        if ($success !== null && ! is_bool($success)) {
            if ($success === 1 || $success === 0 || $success === '1' || $success === '0') {
                $success = (bool) $success;
            } else {
                throw new DomainException('success must be boolean or null.');
            }
        }

        return [
            'outcome_type' => substr($type, 0, 96),
            'success' => $success,
            'impact' => is_array($payload['impact'] ?? null) ? $payload['impact'] : [],
            'correction' => is_array($payload['correction'] ?? null) ? $payload['correction'] : [],
        ];
    }
}
