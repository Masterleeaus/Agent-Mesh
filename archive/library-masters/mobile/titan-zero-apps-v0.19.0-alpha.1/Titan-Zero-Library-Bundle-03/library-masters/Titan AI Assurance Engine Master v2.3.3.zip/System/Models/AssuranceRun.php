<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AssuranceRun extends Model
{
    protected $table = 'assurance_runs';

    protected $guarded = ['id', 'company_id', 'user_id', 'created_at', 'updated_at'];

    protected $casts = [
        'decision_packet' => 'array',
        'risk_context' => 'array',
        'scoring_components' => 'array',
        'panel_spec' => 'array',
        'evidence_source_summary' => 'array',
        'calibration_metadata' => 'array',
        'compliance_rule_snapshot' => 'array',
        'challenge_required' => 'boolean',
        'confidence_score' => 'float',
        'independence_score' => 'float',
        'evidence_score' => 'float',
        'deterministic_score' => 'float',
        'disagreement_score' => 'float',
        'challenge_score' => 'float',
        'estimated_cost' => 'float',
        'reserved_cost' => 'float',
        'actual_cost' => 'float',
        'queued_at' => 'datetime',
        'started_at' => 'datetime',
        'evaluation_started_at' => 'datetime',
        'challenge_completed_at' => 'datetime',
        'expires_at' => 'datetime',
        'completed_at' => 'datetime',
        'approved_at' => 'datetime',
    ];

    public function candidates(): HasMany
    {
        return $this->hasMany(AssuranceCandidate::class, 'assurance_run_id');
    }

    public function findings(): HasMany
    {
        return $this->hasMany(AssuranceFinding::class, 'assurance_run_id');
    }

    public function approvals(): HasMany
    {
        return $this->hasMany(AssuranceApproval::class, 'assurance_run_id');
    }

    public function outcomes(): HasMany
    {
        return $this->hasMany(AssuranceOutcome::class, 'assurance_run_id');
    }

    public function scopeForCompany(Builder $query, string $companyId): Builder
    {
        return $query->where($this->qualifyColumn('company_id'), $companyId);
    }
}
