<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Cost;

use DomainException;

final class CostReservationService
{
    public function decision(float $estimatedCost, ?float $budgetCeiling): array
    {
        $estimatedCost = max(0.0, $estimatedCost);
        if ($budgetCeiling !== null && $estimatedCost > max(0.0, $budgetCeiling)) {
            return [
                'reserved' => false,
                'reserved_cost' => 0.0,
                'reason' => 'budget_ceiling_exceeded',
            ];
        }

        return ['reserved' => true, 'reserved_cost' => $estimatedCost, 'reason' => null];
    }

    public function requireReservation(float $estimatedCost, ?float $budgetCeiling): array
    {
        $decision = $this->decision($estimatedCost, $budgetCeiling);
        if (! $decision['reserved']) {
            throw new DomainException('Assurance cost reservation exceeds the supplied company budget ceiling.');
        }
        return $decision;
    }
}
