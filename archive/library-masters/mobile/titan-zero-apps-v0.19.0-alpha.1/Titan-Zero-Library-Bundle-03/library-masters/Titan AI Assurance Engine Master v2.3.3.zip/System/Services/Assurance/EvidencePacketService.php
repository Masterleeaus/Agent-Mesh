<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

use Illuminate\Support\Arr;

class EvidencePacketService
{
    public function normalize(array $packet): array
    {
        return $this->sortRecursively($packet);
    }

    public function hash(array $packet): string
    {
        $normalized = $this->normalize($packet);
        $json = json_encode($normalized, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);

        return hash('sha256', $json);
    }

    public function redactSecrets(array $packet): array
    {
        $blockedKeys = array_map('strtolower', (array) config('model-council.assurance.redacted_keys', [
            'api_key', 'apikey', 'authorization', 'password', 'secret', 'token', 'access_token', 'refresh_token',
        ]));

        return $this->redactRecursive($packet, $blockedKeys);
    }

    private function redactRecursive(array $value, array $blockedKeys): array
    {
        foreach ($value as $key => $item) {
            if (in_array(strtolower((string) $key), $blockedKeys, true)) {
                $value[$key] = '[REDACTED]';
                continue;
            }

            if (is_array($item)) {
                $value[$key] = $this->redactRecursive($item, $blockedKeys);
            }
        }

        return $value;
    }

    private function sortRecursively(array $value): array
    {
        foreach ($value as $key => $item) {
            if (is_array($item)) {
                $value[$key] = $this->sortRecursively($item);
            }
        }

        if (! Arr::isList($value)) {
            ksort($value);
        }

        return $value;
    }
}
