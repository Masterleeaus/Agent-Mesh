<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\Auth;

class CompanyContextResolver
{
    public function resolve(?Authenticatable $user = null): ?string
    {
        $user ??= Auth::user();

        if (! $user) {
            return null;
        }

        foreach (['company_id', 'current_company_id', 'active_company_id'] as $attribute) {
            $value = $this->readAttribute($user, $attribute);
            if ($value !== null && $value !== '') {
                return (string) $value;
            }
        }

        if (app()->bound('session')) {
            foreach (['company_id', 'current_company_id', 'active_company_id'] as $key) {
                $value = session($key);
                if ($value !== null && $value !== '') {
                    return (string) $value;
                }
            }
        }

        return null;
    }

    private function readAttribute(Authenticatable $user, string $attribute): mixed
    {
        if (method_exists($user, 'getAttribute')) {
            return $user->getAttribute($attribute);
        }

        return $user->{$attribute} ?? null;
    }
}
