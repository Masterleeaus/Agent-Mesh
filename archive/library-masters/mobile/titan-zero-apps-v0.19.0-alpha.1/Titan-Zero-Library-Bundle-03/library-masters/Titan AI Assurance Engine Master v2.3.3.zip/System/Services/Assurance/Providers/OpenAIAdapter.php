<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Providers;

final class OpenAIAdapter extends AbstractProviderAdapter
{
    public function providerKey(): string
    {
        return 'openai';
    }
}
