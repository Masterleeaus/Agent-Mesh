<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Providers;

use App\Extensions\TitanAssurance\System\Contracts\AssuranceStreamingProviderTransport;
use App\Extensions\TitanAssurance\System\Exceptions\AssuranceProviderException;

final class StreamingProviderExecutionGateway
{
    public function __construct(
        private readonly ProviderAdapterRegistry $adapters,
        private readonly AssuranceStreamingProviderTransport $transport,
        private readonly UsageNormalizer $usageNormalizer,
    ) {
    }

    public function execute(
        string $providerKey,
        string $modelId,
        array $messages,
        array $options,
        callable $onChunk,
    ): array {
        $adapter = $this->adapters->for($providerKey, $modelId);
        $request = $adapter->buildRequest($modelId, $messages, $options);
        $observedChunks = 0;
        $transport = $this->transport->stream($providerKey, $modelId, $request, function (string $chunk) use ($onChunk, &$observedChunks): void {
            $observedChunks++;
            $onChunk($chunk);
        });
        $status = (int) ($transport['status'] ?? 0);

        if ($status < 200 || $status >= 300) {
            $errorClass = $adapter->classifyRetry(['status' => $status]);
            throw new AssuranceProviderException('Provider returned HTTP ' . $status, $errorClass, $status);
        }

        $body = $transport['body'] ?? [];
        $parsed = $adapter->parseResponse($body);
        $usage = $this->usageNormalizer->normalize(
            $providerKey,
            is_array($parsed['usage'] ?? null) ? $parsed['usage'] : [],
            is_array($body) ? $body : [],
        );

        $text = trim((string) ($parsed['text'] ?? ''));
        $chunkCount = max($observedChunks, (int) ($transport['chunk_count'] ?? 0));
        if ($chunkCount === 0 && $text !== '') {
            $onChunk($text);
            $chunkCount = 1;
        }

        return [
            'provider' => strtolower(trim($providerKey)),
            'model_id' => $modelId,
            'text' => $text,
            'usage' => $usage,
            'raw' => $parsed['raw'] ?? $body,
            'response_time_ms' => (int) ($transport['response_time_ms'] ?? 0),
            'status' => $status,
            'request' => $request,
            'chunk_count' => $chunkCount,
        ];
    }

    /**
     * @param array<string,array{provider_key:string,model_id:string,messages:array,options?:array}> $items
     * @return array<string,array>
     */
    public function executeMany(array $items, callable $onChunk): array
    {
        $prepared = [];
        $adapters = [];

        foreach ($items as $key => $item) {
            $providerKey = (string) ($item['provider_key'] ?? '');
            $modelId = (string) ($item['model_id'] ?? '');
            $adapter = $this->adapters->for($providerKey, $modelId);
            $adapters[(string) $key] = $adapter;
            $prepared[(string) $key] = [
                'provider_key' => $providerKey,
                'model_id' => $modelId,
                'request' => $adapter->buildRequest(
                    $modelId,
                    is_array($item['messages'] ?? null) ? $item['messages'] : [],
                    is_array($item['options'] ?? null) ? $item['options'] : [],
                ),
            ];
        }

        $observedChunks = [];
        $transportResults = $this->transport->streamMany($prepared, function (string $key, string $chunk) use ($onChunk, &$observedChunks): void {
            $observedChunks[$key] = ($observedChunks[$key] ?? 0) + 1;
            $onChunk($key, $chunk);
        });
        $results = [];

        foreach ($prepared as $key => $item) {
            $adapter = $adapters[$key];
            $transport = is_array($transportResults[$key] ?? null) ? $transportResults[$key] : [];
            $status = (int) ($transport['status'] ?? 0);
            if ($status < 200 || $status >= 300) {
                $errorClass = $adapter->classifyRetry(['status' => $status]);
                $results[$key] = [
                    'provider' => strtolower(trim($item['provider_key'])),
                    'model_id' => $item['model_id'],
                    'text' => '',
                    'usage' => $this->usageNormalizer->normalize($item['provider_key'], [], []),
                    'raw' => $transport['body'] ?? null,
                    'response_time_ms' => (int) ($transport['response_time_ms'] ?? 0),
                    'status' => $status,
                    'request' => $item['request'],
                    'chunk_count' => (int) ($transport['chunk_count'] ?? 0),
                    'failed' => true,
                    'error_class' => $errorClass,
                ];
                continue;
            }

            $body = $transport['body'] ?? [];
            $parsed = $adapter->parseResponse($body);
            $usage = $this->usageNormalizer->normalize(
                $item['provider_key'],
                is_array($parsed['usage'] ?? null) ? $parsed['usage'] : [],
                is_array($body) ? $body : [],
            );
            $text = trim((string) ($parsed['text'] ?? ''));
            $chunkCount = max((int) ($observedChunks[$key] ?? 0), (int) ($transport['chunk_count'] ?? 0));
            if ($chunkCount === 0 && $text !== '') {
                $onChunk($key, $text);
                $chunkCount = 1;
            }
            $results[$key] = [
                'provider' => strtolower(trim($item['provider_key'])),
                'model_id' => $item['model_id'],
                'text' => $text,
                'usage' => $usage,
                'raw' => $parsed['raw'] ?? $body,
                'response_time_ms' => (int) ($transport['response_time_ms'] ?? 0),
                'status' => $status,
                'request' => $item['request'],
                'chunk_count' => $chunkCount,
                'failed' => $text === '',
                'error_class' => null,
            ];
        }

        return $results;
    }

}
