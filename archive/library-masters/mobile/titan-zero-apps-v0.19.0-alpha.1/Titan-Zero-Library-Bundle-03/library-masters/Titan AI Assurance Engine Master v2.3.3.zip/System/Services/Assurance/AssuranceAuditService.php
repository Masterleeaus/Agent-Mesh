<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance;

use App\Extensions\TitanAssurance\System\Models\AssuranceEvent;
use App\Extensions\TitanAssurance\System\Models\AssuranceRun;
use Illuminate\Support\Facades\Auth;

final class AssuranceAuditService
{
    public function record(AssuranceRun $run, string $eventType, array $payload = [], ?int $actorId = null): AssuranceEvent
    {
        $event = new AssuranceEvent();
        $event->company_id = $run->company_id;
        $event->company_id = $run->company_id ?: $run->company_id;
        $event->trace_id = $run->trace_id;
        $event->correlation_id = $run->correlation_id;
        $event->causation_id = $run->causation_id;
        $event->assurance_run_id = $run->id;
        $event->event_type = $eventType;
        $event->actor_id = $actorId ?? Auth::id();
        $event->source_ip = app()->bound('request') ? request()->ip() : null;
        $event->payload = $payload;
        $event->created_at = now();
        $event->save();

        return $event;
    }
}
