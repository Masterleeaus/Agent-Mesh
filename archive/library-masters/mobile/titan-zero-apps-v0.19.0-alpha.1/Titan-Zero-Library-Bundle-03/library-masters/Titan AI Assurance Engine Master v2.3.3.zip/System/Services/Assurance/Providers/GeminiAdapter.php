<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Providers;

final class GeminiAdapter extends AbstractProviderAdapter
{
    public function providerKey(): string
    {
        return 'gemini';
    }

    public function buildRequest(string $modelId, array $messages, array $options = []): array
    {
        $system = [];
        $contents = [];
        foreach ($messages as $message) {
            $role = (string) ($message['role'] ?? 'user');
            $text = is_string($message['content'] ?? null)
                ? (string) $message['content']
                : (json_encode($message['content'] ?? '', JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '');
            if ($role === 'system') {
                $system[] = ['text' => $text];
                continue;
            }
            $contents[] = [
                'role' => $role === 'assistant' ? 'model' : 'user',
                'parts' => [['text' => $text]],
            ];
        }

        $request = ['contents' => $contents];
        if ($system !== []) {
            $request['systemInstruction'] = ['parts' => $system];
        }
        $generation = [];
        if (array_key_exists('temperature', $options)) {
            $generation['temperature'] = $options['temperature'];
        }
        if (isset($options['max_tokens'])) {
            $generation['maxOutputTokens'] = (int) $options['max_tokens'];
        }
        if ($generation !== []) {
            $request['generationConfig'] = $generation;
        }
        return $request;
    }

    public function parseResponse(mixed $response): array
    {
        $body = is_array($response) ? $response : [];
        return [
            'text' => (string) ($body['candidates'][0]['content']['parts'][0]['text'] ?? ''),
            'usage' => (array) ($body['usageMetadata'] ?? []),
            'raw' => $response,
        ];
    }
}
