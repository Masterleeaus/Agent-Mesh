<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Rules;

final class BookingHireRulePack extends CoreRulePack
{
    public function key(): string { return 'booking_hire.v1'; }

    protected function contextNumericThresholds(): array
    {
        return [
            'rate' => ['min' => 0],
            'quantity' => ['min' => 0],
            'deposit_amount' => ['min' => 0],
            'discount_percent' => ['min' => 0, 'max' => 100],
        ];
    }

    protected function contextDateOrderings(): array
    {
        return [['start' => 'hire_start_at', 'end' => 'hire_end_at']];
    }
}
