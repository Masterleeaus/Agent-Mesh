<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Contracts;

interface AssuranceProviderAdapter
{
    public function providerKey(): string;

    public function supports(string $modelId): bool;

    public function capabilities(string $modelId): array;

    public function buildRequest(string $modelId, array $messages, array $options = []): array;

    public function parseResponse(mixed $response): array;

    public function classifyRetry(mixed $error): string;
}
