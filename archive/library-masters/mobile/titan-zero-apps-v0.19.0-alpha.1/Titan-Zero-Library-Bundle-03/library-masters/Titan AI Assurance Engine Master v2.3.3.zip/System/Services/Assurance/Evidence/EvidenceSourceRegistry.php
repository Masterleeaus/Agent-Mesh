<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Evidence;

use App\Extensions\TitanAssurance\System\Contracts\EvidenceSourceAdapter;
use DomainException;

final class EvidenceSourceRegistry
{
    /** @var array<string, EvidenceSourceAdapter> */
    private array $adapters = [];

    /** @param iterable<EvidenceSourceAdapter> $adapters */
    public function __construct(iterable $adapters = [])
    {
        foreach ($adapters as $adapter) {
            $this->register($adapter);
        }
    }

    public function register(EvidenceSourceAdapter $adapter): void
    {
        $this->adapters[strtolower(trim($adapter->sourceKey()))] = $adapter;
    }

    public function for(string $sourceKey): EvidenceSourceAdapter
    {
        $key = strtolower(trim($sourceKey));
        $adapter = $this->adapters[$key] ?? null;
        if (! $adapter) {
            throw new DomainException("Evidence source unavailable: {$key}");
        }

        return $adapter;
    }

    public function keys(): array
    {
        return array_keys($this->adapters);
    }
}
