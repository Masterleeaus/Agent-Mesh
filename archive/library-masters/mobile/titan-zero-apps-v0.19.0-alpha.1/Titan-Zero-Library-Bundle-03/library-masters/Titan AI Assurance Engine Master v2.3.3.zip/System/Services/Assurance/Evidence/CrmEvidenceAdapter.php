<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Evidence;

use App\Extensions\TitanAssurance\System\Contracts\EvidenceSourceAdapter;
use Closure;
use DomainException;

final class CrmEvidenceAdapter implements EvidenceSourceAdapter
{
    private Closure $reader;

    public function __construct(callable $reader)
    {
        $this->reader = Closure::fromCallable($reader);
    }

    public function sourceKey(): string
    {
        return 'crm';
    }

    public function resolve(string $companyId, array $references): array
    {
        $companyId = trim($companyId);
        if ($companyId === '') {
            throw new DomainException('CRM evidence resolution requires company context.');
        }

        $safeReferences = array_values(array_map(function (mixed $reference): array {
            if (! is_array($reference)) {
                return [];
            }
            unset($reference['company_id'], $reference['tenant_id'], $reference['user_id']);
            return $reference;
        }, $references));
        $safeReferences = array_values(array_filter($safeReferences, static fn (array $reference) => $reference !== []));

        $rows = ($this->reader)($companyId, $safeReferences);
        if (! is_array($rows)) {
            throw new DomainException('CRM evidence reader must return an array.');
        }

        $canonical = [];
        foreach ($rows as $row) {
            if (! is_array($row)) {
                continue;
            }
            $sourceId = trim((string) ($row['id'] ?? $row['source_id'] ?? ''));
            $sourceType = trim((string) ($row['type'] ?? $row['source_type'] ?? 'record'));
            if ($sourceId === '') {
                continue;
            }

            $content = $row['data'] ?? $row['content'] ?? [];
            $metadata = is_array($row['metadata'] ?? null) ? $row['metadata'] : [];
            unset($metadata['company_id'], $metadata['tenant_id']);
            $observedAt = $row['updated_at'] ?? $row['observed_at'] ?? null;
            $version = $row['version'] ?? $observedAt ?? null;
            $hashPayload = [
                'source' => 'crm',
                'source_type' => $sourceType,
                'source_id' => $sourceId,
                'version' => $version,
                'observed_at' => $observedAt,
                'content' => $content,
                'metadata' => $metadata,
            ];

            $canonical[] = array_merge($hashPayload, [
                'content_hash' => hash('sha256', json_encode($this->canonicalize($hashPayload), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: ''),
            ]);
        }

        return $canonical;
    }

    private function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }

        if (array_is_list($value)) {
            return array_map(fn (mixed $item) => $this->canonicalize($item), $value);
        }

        ksort($value);
        foreach ($value as $key => $item) {
            $value[$key] = $this->canonicalize($item);
        }
        return $value;
    }
}
