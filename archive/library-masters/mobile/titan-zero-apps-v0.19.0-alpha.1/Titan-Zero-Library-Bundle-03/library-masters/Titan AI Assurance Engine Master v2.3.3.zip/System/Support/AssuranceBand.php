<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Support;

final class AssuranceBand
{
    public const GREEN = 'GREEN';
    public const AMBER = 'AMBER';
    public const RED = 'RED';

    public static function all(): array
    {
        return [self::GREEN, self::AMBER, self::RED];
    }
}
