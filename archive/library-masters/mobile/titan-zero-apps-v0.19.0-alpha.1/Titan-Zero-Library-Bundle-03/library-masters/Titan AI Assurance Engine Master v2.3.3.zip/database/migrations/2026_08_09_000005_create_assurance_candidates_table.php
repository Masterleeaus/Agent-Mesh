<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('assurance_candidates')) {
            return;
        }

        Schema::create('assurance_candidates', function (Blueprint $table) {
            $table->id();
            $table->string('company_id', 64)->index();
            $table->foreignId('assurance_run_id')->constrained('assurance_runs')->cascadeOnDelete();
            $table->string('provider_key')->index();
            $table->string('model_id')->index();
            $table->string('model_snapshot')->nullable()->index();
            $table->string('model_family')->nullable()->index();
            $table->string('candidate_identity', 255)->index();
            $table->string('assigned_role')->index();
            $table->string('prompt_version')->nullable();
            $table->longText('response_text')->nullable();
            $table->json('structured_response')->nullable();
            $table->json('evidence_references')->nullable();
            $table->json('usage')->nullable();
            $table->json('capabilities')->nullable();
            $table->unsignedInteger('response_time_ms')->nullable();
            $table->decimal('cost', 14, 6)->nullable();
            $table->boolean('failed')->default(false)->index();
            $table->text('failure_reason')->nullable();
            $table->decimal('candidate_confidence', 5, 2)->nullable();
            $table->boolean('selected')->default(false)->index();
            $table->timestamp('selected_at')->nullable();
            $table->unsignedBigInteger('selected_by')->nullable()->index();
            $table->timestamps();

            $table->index(['company_id', 'assurance_run_id'], 'assurance_candidates_company_run_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('assurance_candidates');
    }
};
