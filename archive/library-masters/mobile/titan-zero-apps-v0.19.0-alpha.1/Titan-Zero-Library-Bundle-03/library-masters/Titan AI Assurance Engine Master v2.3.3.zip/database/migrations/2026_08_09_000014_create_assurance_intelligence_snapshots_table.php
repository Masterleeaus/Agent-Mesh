<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('assurance_intelligence_snapshots')) {
            return;
        }

        Schema::create('assurance_intelligence_snapshots', function (Blueprint $table) {
            $table->id();
            $table->string('company_id', 64)->index();
            $table->char('filter_hash', 64)->index();
            $table->unsignedInteger('recent_window')->default(50);
            $table->unsignedInteger('minimum_cohort')->default(5);
            $table->json('filters')->nullable();
            $table->json('metrics');
            $table->json('recommendations')->nullable();
            $table->timestamp('generated_at')->index();
            $table->timestamps();

            $table->index(['company_id', 'generated_at'], 'assurance_intelligence_company_generated_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('assurance_intelligence_snapshots');
    }
};
