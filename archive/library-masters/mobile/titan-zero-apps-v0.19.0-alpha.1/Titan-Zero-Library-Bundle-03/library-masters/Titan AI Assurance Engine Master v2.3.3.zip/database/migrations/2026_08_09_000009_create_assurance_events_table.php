<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('assurance_events')) {
            return;
        }

        Schema::create('assurance_events', function (Blueprint $table) {
            $table->id();
            $table->string('company_id', 64)->index();
            $table->foreignId('assurance_run_id')->nullable()->constrained('assurance_runs')->nullOnDelete();
            $table->string('event_type')->index();
            $table->unsignedBigInteger('actor_id')->nullable()->index();
            $table->string('source_ip', 64)->nullable();
            $table->json('payload')->nullable();
            $table->timestamp('created_at')->useCurrent();

            $table->index(['company_id', 'assurance_run_id', 'event_type'], 'assurance_events_company_run_type_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('assurance_events');
    }
};
