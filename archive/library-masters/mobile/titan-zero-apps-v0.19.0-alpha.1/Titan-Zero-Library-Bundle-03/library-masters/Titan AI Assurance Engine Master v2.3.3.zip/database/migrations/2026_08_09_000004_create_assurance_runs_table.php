<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('assurance_runs')) {
            return;
        }

        Schema::create('assurance_runs', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->string('company_id', 64)->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('idempotency_key', 191)->nullable();
            $table->string('source_type')->nullable()->index();
            $table->string('source_id', 191)->nullable()->index();
            $table->string('decision_type')->nullable()->index();
            $table->string('vertical')->nullable()->index();
            $table->string('risk_level', 32)->index();
            $table->string('assurance_mode', 32)->index();
            $table->string('status', 64)->index();
            $table->json('decision_packet')->nullable();
            $table->json('risk_context')->nullable();
            $table->char('evidence_hash', 64)->nullable()->index();
            $table->string('policy_version')->nullable();
            $table->decimal('confidence_score', 5, 2)->nullable();
            $table->decimal('independence_score', 5, 2)->nullable();
            $table->decimal('evidence_score', 5, 2)->nullable();
            $table->string('deterministic_status', 32)->nullable();
            $table->json('scoring_components')->nullable();
            $table->longText('final_recommendation')->nullable();
            $table->longText('residual_risk')->nullable();
            $table->string('required_human_role')->nullable();
            $table->string('permission_state', 32)->default('blocked')->index();
            $table->timestamp('approved_at')->nullable();
            $table->timestamp('expires_at')->nullable()->index();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();

            $table->unique(['company_id', 'idempotency_key'], 'assurance_runs_company_idempotency_uq');
            $table->index(['company_id', 'status'], 'assurance_runs_company_status_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('assurance_runs');
    }
};
