<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('assurance_approvals')) {
            return;
        }

        Schema::create('assurance_approvals', function (Blueprint $table) {
            $table->id();
            $table->string('company_id', 64)->index();
            $table->foreignId('assurance_run_id')->constrained('assurance_runs')->cascadeOnDelete();
            $table->unsignedBigInteger('approver_id')->index();
            $table->string('decision', 32)->index();
            $table->text('reason');
            $table->json('conditions')->nullable();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();

            $table->index(['company_id', 'assurance_run_id'], 'assurance_approvals_company_run_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('assurance_approvals');
    }
};
