<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('assurance_assessments')) {
            return;
        }
        if (! Schema::hasColumn('assurance_assessments', 'workflow_key')) {
            Schema::table('assurance_assessments', function (Blueprint $table): void {
                $table->string('workflow_key', 191)->nullable()->after('capability_variant')->index();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('assurance_assessments') && Schema::hasColumn('assurance_assessments', 'workflow_key')) {
            Schema::table('assurance_assessments', fn (Blueprint $table) => $table->dropColumn('workflow_key'));
        }
    }
};
