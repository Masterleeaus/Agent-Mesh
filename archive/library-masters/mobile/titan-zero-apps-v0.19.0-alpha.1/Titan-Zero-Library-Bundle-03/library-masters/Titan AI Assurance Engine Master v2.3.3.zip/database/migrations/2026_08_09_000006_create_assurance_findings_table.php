<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('assurance_findings')) {
            return;
        }

        Schema::create('assurance_findings', function (Blueprint $table) {
            $table->id();
            $table->string('company_id', 64)->index();
            $table->foreignId('assurance_run_id')->constrained('assurance_runs')->cascadeOnDelete();
            $table->foreignId('candidate_id')->nullable()->constrained('assurance_candidates')->nullOnDelete();
            $table->string('type')->index();
            $table->string('severity', 32)->index();
            $table->longText('claim');
            $table->text('evidence_reference')->nullable();
            $table->string('resolution_status', 32)->default('unresolved')->index();
            $table->timestamps();

            $table->index(['company_id', 'assurance_run_id'], 'assurance_findings_company_run_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('assurance_findings');
    }
};
