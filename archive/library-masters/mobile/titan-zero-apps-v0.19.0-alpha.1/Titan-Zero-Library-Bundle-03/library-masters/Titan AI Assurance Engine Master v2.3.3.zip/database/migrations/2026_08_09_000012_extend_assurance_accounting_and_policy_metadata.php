<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('assurance_candidates')) {
            $candidateColumns = [
                'normalized_usage' => fn (Blueprint $table) => $table->json('normalized_usage')->nullable(),
                'pricing_version' => fn (Blueprint $table) => $table->string('pricing_version', 96)->nullable()->index(),
                'effective_cost' => fn (Blueprint $table) => $table->decimal('effective_cost', 14, 6)->nullable(),
            ];

            foreach ($candidateColumns as $name => $definition) {
                if (! Schema::hasColumn('assurance_candidates', $name)) {
                    Schema::table('assurance_candidates', $definition);
                }
            }
        }

        if (Schema::hasTable('assurance_runs')) {
            $runColumns = [
                'rule_pack_key' => fn (Blueprint $table) => $table->string('rule_pack_key', 128)->nullable()->index(),
                'rule_pack_version' => fn (Blueprint $table) => $table->string('rule_pack_version', 64)->nullable(),
                'evidence_source_summary' => fn (Blueprint $table) => $table->json('evidence_source_summary')->nullable(),
                'calibration_metadata' => fn (Blueprint $table) => $table->json('calibration_metadata')->nullable(),
            ];

            foreach ($runColumns as $name => $definition) {
                if (! Schema::hasColumn('assurance_runs', $name)) {
                    Schema::table('assurance_runs', $definition);
                }
            }
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('assurance_candidates')) {
            foreach (['normalized_usage', 'pricing_version', 'effective_cost'] as $column) {
                if (Schema::hasColumn('assurance_candidates', $column)) {
                    Schema::table('assurance_candidates', fn (Blueprint $table) => $table->dropColumn($column));
                }
            }
        }

        if (Schema::hasTable('assurance_runs')) {
            foreach (['rule_pack_key', 'rule_pack_version', 'evidence_source_summary', 'calibration_metadata'] as $column) {
                if (Schema::hasColumn('assurance_runs', $column)) {
                    Schema::table('assurance_runs', fn (Blueprint $table) => $table->dropColumn($column));
                }
            }
        }
    }
};
