<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('assurance_assessments')) {
            Schema::create('assurance_assessments', function (Blueprint $table) {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->string('company_id', 64)->index();
                $table->string('idempotency_key', 191)->nullable();
                $table->uuid('trace_id')->index();
                $table->uuid('correlation_id')->index();
                $table->uuid('causation_id')->nullable()->index();
                $table->json('subject');
                $table->string('decision_type', 128)->nullable()->index();
                $table->string('capability', 191)->nullable()->index();
                $table->string('capability_variant', 191)->nullable();
                $table->string('vertical', 96)->nullable()->index();
                $table->string('jurisdiction', 96)->nullable()->index();
                $table->string('status', 16)->index();
                $table->decimal('score', 5, 2);
                $table->json('evidence_used')->nullable();
                $table->json('missing_evidence')->nullable();
                $table->json('stale_evidence')->nullable();
                $table->json('contradictory_evidence')->nullable();
                $table->json('reason_codes')->nullable();
                $table->json('knowledge_references')->nullable();
                $table->json('calibration_metadata')->nullable();
                $table->json('evidence_collection_receipt')->nullable();
                $table->json('integration_receipts')->nullable();
                $table->json('result_snapshot');
                $table->string('policy_version', 96)->index();
                $table->unsignedBigInteger('created_by')->nullable()->index();
                $table->timestamp('evaluated_at');
                $table->timestamps();

                $table->unique(['company_id', 'idempotency_key'], 'assurance_assessments_tenant_idem_uq');
                $table->index(['company_id', 'status', 'decision_type'], 'assurance_assessments_tenant_status_decision_idx');
            });
        }

        if (! Schema::hasTable('assurance_evidence_records')) {
            Schema::create('assurance_evidence_records', function (Blueprint $table) {
                $table->id();
                $table->string('company_id', 64)->index();
                $table->foreignId('assurance_assessment_id')->constrained('assurance_assessments')->restrictOnDelete();
                $table->uuid('evidence_id');
                $table->string('evidence_type', 128)->index();
                $table->json('subject');
                $table->string('source', 191)->index();
                $table->json('provenance')->nullable();
                $table->timestamp('captured_at')->nullable();
                $table->timestamp('effective_at')->nullable();
                $table->timestamp('expires_at')->nullable()->index();
                $table->decimal('freshness', 8, 6);
                $table->decimal('confidence', 8, 6);
                $table->decimal('authority', 8, 6);
                $table->decimal('relevance', 8, 6);
                $table->decimal('applicability', 8, 6);
                $table->decimal('provenance_confidence', 8, 6);
                $table->decimal('contradiction_adjustment', 8, 6);
                $table->decimal('weight_score', 7, 2);
                $table->string('jurisdiction', 96)->nullable()->index();
                $table->string('vertical', 96)->nullable()->index();
                $table->json('scope')->nullable();
                $table->char('hash', 64)->index();
                $table->string('verification_state', 64)->index();
                $table->json('content')->nullable();
                $table->json('contradicts')->nullable();
                $table->json('knowledge_reference')->nullable();
                $table->timestamps();

                $table->unique(['company_id', 'assurance_assessment_id', 'evidence_id'], 'assurance_evidence_tenant_assessment_evidence_uq');
                $table->index(['company_id', 'assurance_assessment_id'], 'assurance_evidence_tenant_assessment_idx');
            });
        }

        if (! Schema::hasTable('assurance_feedback')) {
            Schema::create('assurance_feedback', function (Blueprint $table) {
                $table->id();
                $table->string('company_id', 64)->index();
                $table->foreignId('assurance_assessment_id')->constrained('assurance_assessments')->restrictOnDelete();
                $table->string('feedback_type', 64)->index();
                $table->string('idempotency_key', 191)->nullable();
                $table->string('source_ref', 191)->nullable()->index();
                $table->boolean('accepted')->nullable()->index();
                $table->string('decision', 64)->nullable();
                $table->json('metadata')->nullable();
                $table->unsignedBigInteger('recorded_by')->nullable()->index();
                $table->timestamp('recorded_at');
                $table->timestamps();

                $table->unique(['company_id', 'idempotency_key'], 'assurance_feedback_tenant_idem_uq');
                $table->index(['company_id', 'feedback_type', 'accepted'], 'assurance_feedback_tenant_type_accepted_idx');
            });
        }

        $this->extendLegacyTraceSurface();
    }

    private function extendLegacyTraceSurface(): void
    {
        if (Schema::hasTable('assurance_runs')) {
            foreach ([
                'company_id' => fn (Blueprint $table) => $table->string('company_id', 64)->nullable()->index(),
                'trace_id' => fn (Blueprint $table) => $table->uuid('trace_id')->nullable()->index(),
                'correlation_id' => fn (Blueprint $table) => $table->uuid('correlation_id')->nullable()->index(),
                'causation_id' => fn (Blueprint $table) => $table->uuid('causation_id')->nullable()->index(),
            ] as $name => $definition) {
                if (! Schema::hasColumn('assurance_runs', $name)) {
                    Schema::table('assurance_runs', $definition);
                }
            }
            if (Schema::hasColumn('assurance_runs', 'company_id') && Schema::hasColumn('assurance_runs', 'company_id')) {
                DB::table('assurance_runs')->whereNull('company_id')->update(['company_id' => DB::raw('company_id')]);
            }
        }

        if (Schema::hasTable('assurance_events')) {
            foreach ([
                'company_id' => fn (Blueprint $table) => $table->string('company_id', 64)->nullable()->index(),
                'trace_id' => fn (Blueprint $table) => $table->uuid('trace_id')->nullable()->index(),
                'correlation_id' => fn (Blueprint $table) => $table->uuid('correlation_id')->nullable()->index(),
                'causation_id' => fn (Blueprint $table) => $table->uuid('causation_id')->nullable()->index(),
            ] as $name => $definition) {
                if (! Schema::hasColumn('assurance_events', $name)) {
                    Schema::table('assurance_events', $definition);
                }
            }
            if (Schema::hasColumn('assurance_events', 'company_id') && Schema::hasColumn('assurance_events', 'company_id')) {
                DB::table('assurance_events')->whereNull('company_id')->update(['company_id' => DB::raw('company_id')]);
            }
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('assurance_feedback');
        Schema::dropIfExists('assurance_evidence_records');
        Schema::dropIfExists('assurance_assessments');

        foreach (['assurance_events', 'assurance_runs'] as $tableName) {
            if (! Schema::hasTable($tableName)) {
                continue;
            }
            foreach (['company_id', 'trace_id', 'correlation_id', 'causation_id'] as $column) {
                if (Schema::hasColumn($tableName, $column)) {
                    Schema::table($tableName, fn (Blueprint $table) => $table->dropColumn($column));
                }
            }
        }
    }
};
