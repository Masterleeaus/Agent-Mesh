<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('assurance_outcomes')) {
            return;
        }

        Schema::create('assurance_outcomes', function (Blueprint $table) {
            $table->id();
            $table->string('company_id', 64)->index();
            $table->foreignId('assurance_run_id')->constrained('assurance_runs')->cascadeOnDelete();
            $table->string('outcome_type')->index();
            $table->boolean('success')->nullable()->index();
            $table->json('impact')->nullable();
            $table->json('correction')->nullable();
            $table->unsignedBigInteger('recorded_by')->nullable()->index();
            $table->timestamps();

            $table->index(['company_id', 'assurance_run_id'], 'assurance_outcomes_company_run_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('assurance_outcomes');
    }
};
