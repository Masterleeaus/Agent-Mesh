<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('assurance_runs')) {
            return;
        }

        $columns = [
            'panel_spec' => fn (Blueprint $table) => $table->json('panel_spec')->nullable(),
            'provider_count' => fn (Blueprint $table) => $table->unsignedSmallInteger('provider_count')->nullable(),
            'family_count' => fn (Blueprint $table) => $table->unsignedSmallInteger('family_count')->nullable(),
            'deterministic_score' => fn (Blueprint $table) => $table->decimal('deterministic_score', 5, 2)->nullable(),
            'disagreement_score' => fn (Blueprint $table) => $table->decimal('disagreement_score', 5, 2)->nullable(),
            'challenge_score' => fn (Blueprint $table) => $table->decimal('challenge_score', 5, 2)->nullable(),
            'estimated_cost' => fn (Blueprint $table) => $table->decimal('estimated_cost', 14, 6)->nullable(),
            'reserved_cost' => fn (Blueprint $table) => $table->decimal('reserved_cost', 14, 6)->nullable(),
            'actual_cost' => fn (Blueprint $table) => $table->decimal('actual_cost', 14, 6)->nullable(),
            'currency' => fn (Blueprint $table) => $table->string('currency', 3)->default('USD'),
            'failure_code' => fn (Blueprint $table) => $table->string('failure_code', 96)->nullable()->index(),
            'challenge_required' => fn (Blueprint $table) => $table->boolean('challenge_required')->default(false),
            'queued_at' => fn (Blueprint $table) => $table->timestamp('queued_at')->nullable(),
            'started_at' => fn (Blueprint $table) => $table->timestamp('started_at')->nullable(),
            'evaluation_started_at' => fn (Blueprint $table) => $table->timestamp('evaluation_started_at')->nullable(),
            'challenge_completed_at' => fn (Blueprint $table) => $table->timestamp('challenge_completed_at')->nullable(),
        ];

        foreach ($columns as $name => $definition) {
            if (! Schema::hasColumn('assurance_runs', $name)) {
                Schema::table('assurance_runs', $definition);
            }
        }
    }

    public function down(): void
    {
        if (! Schema::hasTable('assurance_runs')) {
            return;
        }
        foreach (['panel_spec','provider_count','family_count','deterministic_score','disagreement_score','challenge_score','estimated_cost','reserved_cost','actual_cost','currency','failure_code','challenge_required','queued_at','started_at','evaluation_started_at','challenge_completed_at'] as $column) {
            if (Schema::hasColumn('assurance_runs', $column)) {
                Schema::table('assurance_runs', fn (Blueprint $table) => $table->dropColumn($column));
            }
        }
    }
};
