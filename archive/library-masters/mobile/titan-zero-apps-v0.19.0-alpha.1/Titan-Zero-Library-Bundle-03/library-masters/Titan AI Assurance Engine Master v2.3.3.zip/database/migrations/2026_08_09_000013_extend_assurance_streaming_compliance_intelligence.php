<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('assurance_candidates')) {
            $columns = [
                'streamed' => fn (Blueprint $table) => $table->boolean('streamed')->default(false),
                'stream_chunk_count' => fn (Blueprint $table) => $table->unsignedInteger('stream_chunk_count')->default(0),
                'stream_completed_at' => fn (Blueprint $table) => $table->timestamp('stream_completed_at')->nullable(),
            ];
            foreach ($columns as $name => $definition) {
                if (! Schema::hasColumn('assurance_candidates', $name)) {
                    Schema::table('assurance_candidates', $definition);
                }
            }
        }

        if (Schema::hasTable('assurance_runs')) {
            $columns = [
                'compliance_source_key' => fn (Blueprint $table) => $table->string('compliance_source_key', 128)->nullable()->index(),
                'compliance_jurisdiction' => fn (Blueprint $table) => $table->string('compliance_jurisdiction', 64)->nullable()->index(),
                'compliance_rule_version' => fn (Blueprint $table) => $table->string('compliance_rule_version', 128)->nullable(),
                'compliance_rule_hash' => fn (Blueprint $table) => $table->char('compliance_rule_hash', 64)->nullable()->index(),
                'compliance_rule_snapshot' => fn (Blueprint $table) => $table->json('compliance_rule_snapshot')->nullable(),
            ];
            foreach ($columns as $name => $definition) {
                if (! Schema::hasColumn('assurance_runs', $name)) {
                    Schema::table('assurance_runs', $definition);
                }
            }
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('assurance_candidates')) {
            foreach (['streamed', 'stream_chunk_count', 'stream_completed_at'] as $column) {
                if (Schema::hasColumn('assurance_candidates', $column)) {
                    Schema::table('assurance_candidates', fn (Blueprint $table) => $table->dropColumn($column));
                }
            }
        }

        if (Schema::hasTable('assurance_runs')) {
            foreach (['compliance_source_key', 'compliance_jurisdiction', 'compliance_rule_version', 'compliance_rule_hash', 'compliance_rule_snapshot'] as $column) {
                if (Schema::hasColumn('assurance_runs', $column)) {
                    Schema::table('assurance_runs', fn (Blueprint $table) => $table->dropColumn($column));
                }
            }
        }
    }
};
