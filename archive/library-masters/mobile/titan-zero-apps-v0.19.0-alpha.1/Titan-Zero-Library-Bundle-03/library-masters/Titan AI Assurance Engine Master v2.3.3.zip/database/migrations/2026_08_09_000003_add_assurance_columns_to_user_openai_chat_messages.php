<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('user_openai_chat_messages', function (Blueprint $table) {
            if (! Schema::hasColumn('user_openai_chat_messages', 'company_id')) {
                $table->string('company_id', 64)->nullable()->index('uocm_company_idx');
            }
            if (! Schema::hasColumn('user_openai_chat_messages', 'assurance_run_uuid')) {
                $table->uuid('assurance_run_uuid')->nullable()->index('uocm_assurance_run_uuid_idx');
            }
            if (! Schema::hasColumn('user_openai_chat_messages', 'is_council_selected')) {
                $table->boolean('is_council_selected')->default(false)->index('uocm_council_selected_idx');
            }
            if (! Schema::hasColumn('user_openai_chat_messages', 'council_selected_at')) {
                $table->timestamp('council_selected_at')->nullable();
            }
            if (! Schema::hasColumn('user_openai_chat_messages', 'council_selected_by')) {
                $table->unsignedBigInteger('council_selected_by')->nullable()->index('uocm_council_selected_by_idx');
            }
        });
    }

    public function down(): void
    {
        Schema::table('user_openai_chat_messages', function (Blueprint $table) {
            foreach ([
                'council_selected_by',
                'council_selected_at',
                'is_council_selected',
                'assurance_run_uuid',
                'company_id',
            ] as $column) {
                if (Schema::hasColumn('user_openai_chat_messages', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
