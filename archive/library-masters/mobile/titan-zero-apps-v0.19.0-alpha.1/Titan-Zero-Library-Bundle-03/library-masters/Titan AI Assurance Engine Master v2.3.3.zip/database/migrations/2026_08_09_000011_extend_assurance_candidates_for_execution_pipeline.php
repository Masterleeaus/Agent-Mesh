<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('assurance_candidates')) {
            return;
        }

        $columns = [
            'status' => fn (Blueprint $table) => $table->string('status', 32)->default('pending')->index(),
            'attempt_count' => fn (Blueprint $table) => $table->unsignedSmallInteger('attempt_count')->default(0),
            'error_class' => fn (Blueprint $table) => $table->string('error_class', 64)->nullable()->index(),
            'request_hash' => fn (Blueprint $table) => $table->char('request_hash', 64)->nullable()->index(),
            'response_hash' => fn (Blueprint $table) => $table->char('response_hash', 64)->nullable()->index(),
            'queued_at' => fn (Blueprint $table) => $table->timestamp('queued_at')->nullable(),
            'started_at' => fn (Blueprint $table) => $table->timestamp('started_at')->nullable(),
            'completed_at' => fn (Blueprint $table) => $table->timestamp('completed_at')->nullable(),
        ];

        foreach ($columns as $name => $definition) {
            if (! Schema::hasColumn('assurance_candidates', $name)) {
                Schema::table('assurance_candidates', $definition);
            }
        }
    }

    public function down(): void
    {
        if (! Schema::hasTable('assurance_candidates')) {
            return;
        }
        foreach (['status','attempt_count','error_class','request_hash','response_hash','queued_at','started_at','completed_at'] as $column) {
            if (Schema::hasColumn('assurance_candidates', $column)) {
                Schema::table('assurance_candidates', fn (Blueprint $table) => $table->dropColumn($column));
            }
        }
    }
};
