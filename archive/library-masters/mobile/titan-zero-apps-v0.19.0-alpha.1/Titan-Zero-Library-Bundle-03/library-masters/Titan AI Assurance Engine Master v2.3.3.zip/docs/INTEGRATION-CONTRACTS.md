# Integration Contracts

## Titan Signal — live required receiver

Titan Assurance v2.3 has a live receiver-aware adapter certified against Titan Signal Engine `0.20.0-rc.3`. The installer dependency uses the receiver's actual marketplace slug `titan-signal-engine`; the Blueprint governance sidecar retains the canonical engine key `titan-signal`. See `LIVE-INTEGRATION-V2.3.md`.

Assurance registers only its own `assurance.*` event family and emits with tenant-scoped system-service identity, trace/correlation/causation lineage and stable idempotency keys. Receiver receipts are retained on the originating assessment/feedback records.

## Titan Autonomy — live optional bridge

Titan Autonomy receives evidence-native Assurance projection through its Assurance bridge contracts. Assurance always projects `authority_granted=false`; Titan Autonomy remains the authority owner.

## Titan Rewind — structured sink contract

Structured Rewind-compatible receipts/rationale are retained, but this build does not claim a live Rewind ingest adapter until the concrete receiver API is verified and bound.

## Titan Wisdom — receiver limited

The inspected Titan Wisdom Engine v0.1.2 contract exposes health/readiness/capability declaration only and explicitly reports the outcome-learning domain as not implemented. Assurance therefore does not claim live outcome ingestion.

## Titan Knowledge Authority — receiver limited

The inspected Titan Knowledge Authority v0.2.0-alpha.1 contract exposes health only; Assurance validates exact version/hash/section references locally but does not claim live knowledge query/resolve integration.

## Titan AI Core — notification contract pending

Miscalibration notifications remain structured and sink-ready, but no verified AI Core miscalibration-ingest contract is claimed in this release.

## Titan Interaction Engine

Evidence recollection continues to use the verified `assurance.evidence.collect` workflow request contract. Signal now records each recollection request as a governed lifecycle event. No separate direct Interaction API is invented where a receiver contract has not been verified.

## Titan Risk

Titan Risk may supply contextual exposure inputs. Assurance never becomes the canonical risk classifier and never grants execution authority.
