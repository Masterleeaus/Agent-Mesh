# Upgrade Phase 2 — v1.7.0

## Completed

- extracted provider adapter boundary for OpenAI, Anthropic, Gemini, DeepSeek, xAI and OpenRouter
- added MagicAI credential-aware provider transport
- added normalized provider/model/family/snapshot identity
- prevented proxy routing from faking model-family independence
- added panel policy and independence scoring
- extended run/candidate persistence additively
- added structured output validation and malformed-output hard failure
- added evidence-linked claim validation
- added material disagreement analysis
- added adversarial challenge stage
- added component-based assurance scoring and evidence ceiling
- added cost estimate/reservation/reconciliation hooks
- added fail-closed permission gates
- hardened human approval so it cannot override unresolved automated controls
- added bounded retry queue jobs and eliminated assurance request-worker polling
- added cancellation short-circuit before additional provider calls
- added company-scoped REST-style endpoints
- decoupled assurance core boot from AIChatPro
- added pure policy/contract regression tests

## Host integration checklist

Before production enablement inside the MagicAI application:

1. Back up the database.
2. Install/upgrade the extension and run Laravel migrations.
3. Confirm `assurance_runs` and `assurance_candidates` receive the v1.7 additive columns.
4. Confirm the authenticated user/company implementation exposes a trustworthy `current_company_id`, `company_id`, or `active_company_id` (or the platform's secured company session context).
5. Start a queue worker listening to the configured assurance queue.
6. Confirm provider credentials are configured using the same MagicAI settings used by the existing ModelCouncil service.
7. Run one sandbox request per configured provider.
8. Configure the API middleware for Titan PWAs/services if they use token authentication rather than the default web session auth.
9. Wrap Critical approval with host RBAC. For workflows that already know the exact approvers, include `named_approver_ids` in the risk context/override.
10. Run cross-company authorization tests in the host app: company A must receive 404/denial for company B run ids.
11. Run queue retry tests for HTTP 429/5xx and confirm non-retry for 401/403/400/422.
12. Test cancellation while candidates are still queued.
13. Test High/Critical challenge and human-review transitions.
14. Verify no external Titan action consumes a recommendation unless `permission_state === "permitted"`.

## Build verification performed outside host app

- pure assurance tests execute without the Laravel runtime
- complete PHP syntax lint
- manifest JSON validation and BOM check
- destructive-delete scan
- assurance polling-loop scan
- archive integrity and SHA-256 verification

## Deferred to the next layer

The following are intentionally not claimed as complete in v1.7:

- live MagicAI database migration certification
- live provider credential/API certification
- provider-specific token pricing catalogue for independent cost calculation when APIs do not return cost
- host RBAC policy implementation for named organisational roles
- calibration from recorded outcomes
- automatic policy learning / threshold calibration
- full CRM evidence adapters and vertical-specific deterministic rule packs
- external action/execution adapter beyond the fail-closed `permission_state`
