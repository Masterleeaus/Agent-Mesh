# Titan Assurance Engine v1.8 Integration & Calibration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Converge legacy ModelCouncil non-streaming provider execution onto the Titan Assurance adapter boundary, make token/cost accounting authoritative, add advisory outcome calibration, add CRM evidence adapters, and add versioned deterministic rule packs.

**Architecture:** Preserve the existing `ModelCouncilService` and streaming UX as a compatibility shell while introducing a shared `ProviderExecutionGateway` for non-streaming execution. Usage, cost, evidence-source and rule-pack concerns remain isolated behind focused services/contracts; calibration is descriptive only and cannot mutate assurance policy.

**Tech Stack:** PHP 8+, Laravel/MagicAI extension conventions, Eloquent, Laravel HTTP client/DI/routes, existing pure-PHP regression runner.

## Global Constraints

- Technical extension identity remains `ModelCouncil`.
- Existing v1.7 routes/contracts/tables remain valid.
- `company_id` remains the tenant boundary; `user_id` is actor identity only.
- AIChatPro remains optional for assurance core boot.
- No automatic external action is permitted unless existing permission gates pass.
- No calibration process may auto-relax policy or approval requirements in v1.8.
- Existing streaming ModelCouncil behavior remains compatibility-owned in v1.8.
- New schema changes are additive migrations only; never rewrite v1.7 migrations.
- Unknown provider pricing must never be fabricated.

---

### Task 1: Shared provider execution and usage normalization

**Files:**
- Create: `System/Services/Assurance/Providers/UsageNormalizer.php`
- Create: `System/Services/Assurance/Providers/ProviderExecutionGateway.php`
- Modify: `System/Services/Assurance/CandidateExecutionService.php`
- Modify: `System/ModelCouncilServiceProvider.php`
- Test: `tests/Unit/UsageNormalizerTest.php`
- Test: `tests/Unit/ProviderExecutionGatewayTest.php`

**Interfaces:**
- Consumes: `ProviderAdapterRegistry::for(string $provider, string $modelId): AssuranceProviderAdapter`, `AssuranceProviderTransport::send(string $providerKey, string $modelId, array $request): array`.
- Produces: `UsageNormalizer::normalize(string $providerKey, array $usage, array $body = []): array`; `ProviderExecutionGateway::execute(string $providerKey, string $modelId, array $messages, array $options = []): array` returning `provider`, `model_id`, `text`, `usage`, `raw`, `response_time_ms`, `status`.

- [x] **Step 1: Write failing usage normalization tests**

```php
<?php
require_once __DIR__ . '/../Support/bootstrap.php';
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\UsageNormalizer;

$normalizer = new UsageNormalizer();
$openai = $normalizer->normalize('openai', ['prompt_tokens' => 100, 'completion_tokens' => 40, 'total_tokens' => 140]);
expect_same(100, $openai['input_tokens'], 'OpenAI prompt tokens normalize to input tokens.');
expect_same(40, $openai['output_tokens'], 'OpenAI completion tokens normalize to output tokens.');
$anthropic = $normalizer->normalize('anthropic', ['input_tokens' => 22, 'output_tokens' => 11]);
expect_same(33, $anthropic['total_tokens'], 'Anthropic total is derived when omitted.');
$gemini = $normalizer->normalize('gemini', ['promptTokenCount' => 7, 'candidatesTokenCount' => 5, 'totalTokenCount' => 12]);
expect_same(7, $gemini['input_tokens'], 'Gemini promptTokenCount normalizes.');
expect_same(12, $gemini['total_tokens'], 'Gemini totalTokenCount normalizes.');
```

- [x] **Step 2: Run the test and verify RED**

Run: `php tests/Unit/UsageNormalizerTest.php`
Expected: non-zero exit because `UsageNormalizer` does not exist.

- [x] **Step 3: Implement `UsageNormalizer`**

Implement numeric-safe extraction for OpenAI-compatible, Anthropic and Gemini token field names. Preserve the raw usage payload under `raw`, return null for unavailable token classes, and derive total only when both input/output are known.

- [x] **Step 4: Write failing gateway tests with a fake transport**

```php
<?php
require_once __DIR__ . '/../Support/bootstrap.php';
use App\Extensions\TitanAssurance\System\Contracts\AssuranceProviderTransport;
use App\Extensions\TitanAssurance\System\Services\Assurance\Capabilities\ModelCapabilityRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\OpenAIAdapter;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\ProviderAdapterRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\ProviderExecutionGateway;
use App\Extensions\TitanAssurance\System\Services\Assurance\Providers\UsageNormalizer;
use App\Extensions\TitanAssurance\System\Exceptions\AssuranceProviderException;

$registry = new ProviderAdapterRegistry([new OpenAIAdapter(new ModelCapabilityRegistry())]);
$transport = new class implements AssuranceProviderTransport {
    public int $status = 200;
    public function send(string $providerKey, string $modelId, array $request): array {
        return ['status' => $this->status, 'body' => ['choices' => [['message' => ['content' => 'ok']]], 'usage' => ['prompt_tokens' => 3, 'completion_tokens' => 2]], 'response_time_ms' => 9];
    }
};
$gateway = new ProviderExecutionGateway($registry, $transport, new UsageNormalizer());
$result = $gateway->execute('openai', 'gpt-4.1', [['role' => 'user', 'content' => 'x']]);
expect_same('ok', $result['text'], 'Gateway parses provider response.');
expect_same(5, $result['usage']['total_tokens'], 'Gateway normalizes usage.');
$transport->status = 429;
$thrown = false;
try { $gateway->execute('openai', 'gpt-4.1', [['role' => 'user', 'content' => 'x']]); } catch (AssuranceProviderException $e) { $thrown = $e->errorClass === 'retryable'; }
expect_true($thrown, 'Gateway classifies non-2xx responses through provider adapter.');
```

- [x] **Step 5: Run gateway test and verify RED**

Run: `php tests/Unit/ProviderExecutionGatewayTest.php`
Expected: non-zero exit because `ProviderExecutionGateway` does not exist.

- [x] **Step 6: Implement gateway and route CandidateExecutionService through it**

`ProviderExecutionGateway` must build the request through the adapter, call the transport, throw `AssuranceProviderException` for non-2xx statuses using `classifyRetry()`, parse provider output, and normalize usage. Replace the duplicated adapter/build/send/parse block in `CandidateExecutionService` with this gateway while preserving candidate retry/error behavior.

- [x] **Step 7: Register gateway/normalizer in the service provider and run tests**

Run: `php tests/run-pure-tests.php`
Expected: all existing tests plus the new tests pass.

---

### Task 2: Versioned pricing catalogue and effective cost accounting

**Files:**
- Create: `System/Services/Assurance/Cost/ProviderPricingCatalogue.php`
- Create: `System/Services/Assurance/Cost/UsageCostCalculator.php`
- Modify: `System/Services/Assurance/Cost/CostReconciler.php`
- Modify: `System/Services/Assurance/CandidateExecutionService.php`
- Modify: `config/model-council.php`
- Test: `tests/Unit/UsageCostCalculatorTest.php`

**Interfaces:**
- Produces: `ProviderPricingCatalogue::resolve(string $providerKey, string $modelId): ?array`; `UsageCostCalculator::calculate(string $providerKey, string $modelId, array $normalizedUsage): array` returning `reported_cost`, `calculated_cost`, `effective_cost`, `currency`, `pricing_version`, `pricing_status`.

- [x] **Step 1: Write failing pricing tests**

```php
<?php
require_once __DIR__ . '/../Support/bootstrap.php';
use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\ProviderPricingCatalogue;
use App\Extensions\TitanAssurance\System\Services\Assurance\Cost\UsageCostCalculator;

$catalogue = new ProviderPricingCatalogue([
    'version' => 'test-v1',
    'currency' => 'USD',
    'models' => ['openai:gpt-test' => ['input_per_million' => 2.0, 'output_per_million' => 8.0]],
]);
$calculator = new UsageCostCalculator($catalogue);
$calc = $calculator->calculate('openai', 'gpt-test', ['input_tokens' => 1000000, 'output_tokens' => 500000, 'reported_cost' => null]);
expect_near(6.0, $calc['calculated_cost'], 0.000001, 'Catalogue pricing calculates token cost.');
expect_near(6.0, $calc['effective_cost'], 0.000001, 'Calculated cost is effective when provider does not report cost.');
$reported = $calculator->calculate('openai', 'gpt-test', ['input_tokens' => 1, 'output_tokens' => 1, 'reported_cost' => 0.123]);
expect_near(0.123, $reported['effective_cost'], 0.000001, 'Provider-reported cost takes precedence.');
$unknown = $calculator->calculate('openai', 'unknown', ['input_tokens' => 10, 'output_tokens' => 5, 'reported_cost' => null]);
expect_same(null, $unknown['effective_cost'], 'Unknown pricing must not fabricate cost.');
expect_same('pricing_unknown', $unknown['pricing_status'], 'Unknown pricing is explicit.');
```

- [x] **Step 2: Verify RED**

Run: `php tests/Unit/UsageCostCalculatorTest.php`
Expected: missing pricing classes.

- [x] **Step 3: Implement catalogue and calculator**

Configuration shape under `model-council.assurance.pricing`: `version`, `currency`, `models`, `provider_defaults`. Exact `provider:model` entry wins over provider default. Input/output/cached-input prices are per one million tokens. `reported_cost` from normalized usage wins over calculated cost.

- [x] **Step 4: Extend candidate persistence usage envelope in memory**

`CandidateExecutionService` persists normalized usage plus `reported_cost`, `calculated_cost`, `effective_cost`, `pricing_version`, and `pricing_status` inside `usage`; `candidate.cost` becomes the effective cost when known and remains null when pricing is unknown rather than zero.

- [x] **Step 5: Update reconciler to ignore unknown costs instead of coercing null to zero silently**

Return an accounting envelope with `actual_cost`, `known_cost_count`, `unknown_cost_count`, and `complete`. Existing callers that require a float will read `actual_cost`.

- [x] **Step 6: Run full pure suite**

Run: `php tests/run-pure-tests.php`
Expected: all tests pass.

---

### Task 3: Outcome recording and advisory calibration

**Files:**
- Create: `System/Services/Assurance/OutcomeRecorder.php`
- Create: `System/Services/Assurance/AssuranceCalibrationService.php`
- Modify: `System/Contracts/AssuranceEngine.php`
- Modify: `System/Services/Assurance/AssuranceEngineService.php`
- Modify: `System/Http/Controllers/AssuranceController.php`
- Modify: `System/ModelCouncilServiceProvider.php`
- Test: `tests/Unit/AssuranceCalibrationServiceTest.php`
- Test: `tests/Unit/AssuranceApiSurfaceTest.php`

**Interfaces:**
- Produces: `OutcomeRecorder::normalize(array $payload): array`; `AssuranceCalibrationService::summarize(array $samples): array`.
- Adds assurance engine methods: `recordOutcome(int $runId, array $payload): AssuranceOutcome`; `calibration(array $filters = []): array`.

- [x] **Step 1: Write failing calibration test**

```php
<?php
require_once __DIR__ . '/../Support/bootstrap.php';
use App\Extensions\TitanAssurance\System\Services\Assurance\AssuranceCalibrationService;

$service = new AssuranceCalibrationService();
$result = $service->summarize([
    ['assurance_score' => 90, 'success' => true],
    ['assurance_score' => 80, 'success' => false],
]);
expect_same(2, $result['sample_count'], 'Calibration counts samples.');
expect_near(0.5, $result['success_rate'], 0.000001, 'Calibration computes observed success rate.');
expect_near(85.0, $result['mean_assurance_score'], 0.000001, 'Calibration computes mean score.');
expect_true(isset($result['brier_score']), 'Calibration exposes Brier score.');
expect_true(! array_key_exists('recommended_minimum_score', $result), 'v1.8 calibration must not auto-propose weaker policy thresholds.');
```

- [x] **Step 2: Verify RED and implement pure services**

Run the test before implementation, then implement normalization and descriptive metrics only. Brier score uses probability `assurance_score / 100` versus binary success outcome.

- [x] **Step 3: Add company-scoped engine/controller wiring**

`recordOutcome()` resolves the run through existing `findRun()` company scoping, requires authenticated actor, creates `AssuranceOutcome`, emits/audits `AssuranceOutcomeRecorded`, and never updates the original decision packet/score. `calibration()` queries only current-company outcomes joined to runs and returns grouped descriptive metrics.

- [x] **Step 4: Extend API surface test first, then add routes**

Add expected controller methods `recordOutcome` and `calibration`; add POST `/runs/{run}/outcomes` and GET `/calibration` under the existing assurance route group.

- [x] **Step 5: Run full suite**

Run: `php tests/run-pure-tests.php`
Expected: all tests pass.

---

### Task 4: CRM evidence adapter boundary

**Files:**
- Create: `System/Contracts/EvidenceSourceAdapter.php`
- Create: `System/Services/Assurance/Evidence/EvidenceSourceRegistry.php`
- Create: `System/Services/Assurance/Evidence/CrmEvidenceAdapter.php`
- Test: `tests/Unit/CrmEvidenceAdapterTest.php`

**Interfaces:**
- `EvidenceSourceAdapter::sourceKey(): string`
- `EvidenceSourceAdapter::resolve(string $companyId, array $references): array`
- `CrmEvidenceAdapter::__construct(callable $reader)` where reader signature is `(string $companyId, array $references): array`.

- [x] **Step 1: Write failing CRM adapter test**

```php
<?php
require_once __DIR__ . '/../Support/bootstrap.php';
use App\Extensions\TitanAssurance\System\Services\Assurance\Evidence\CrmEvidenceAdapter;

$seenCompany = null;
$adapter = new CrmEvidenceAdapter(function (string $companyId, array $refs) use (&$seenCompany): array {
    $seenCompany = $companyId;
    return [['id' => 'job-1', 'type' => 'job', 'updated_at' => '2026-08-09T00:00:00Z', 'data' => ['status' => 'completed']]];
});
$records = $adapter->resolve('company-7', [['type' => 'job', 'id' => 'job-1']]);
expect_same('company-7', $seenCompany, 'CRM reader receives secured company context.');
expect_same('crm', $records[0]['source'], 'CRM evidence provenance is canonical.');
expect_same('job-1', $records[0]['source_id'], 'CRM source id is preserved.');
expect_true(isset($records[0]['content_hash']), 'Canonical CRM evidence is hashed.');
```

- [x] **Step 2: Verify RED**

Run: `php tests/Unit/CrmEvidenceAdapterTest.php`
Expected: adapter class missing.

- [x] **Step 3: Implement contract, registry, adapter**

Canonical record fields: `source`, `source_type`, `source_id`, `version`, `observed_at`, `content`, `metadata`, `content_hash`. Adapter receives company ID only from its method argument; it must never accept or trust a company ID inside individual references.

- [x] **Step 4: Run tests**

Run: `php tests/run-pure-tests.php`
Expected: all tests pass.

---

### Task 5: Versioned vertical deterministic rule packs

**Files:**
- Create: `System/Contracts/DeterministicRulePack.php`
- Create: `System/Services/Assurance/Rules/RulePackRegistry.php`
- Create: `System/Services/Assurance/Rules/CoreRulePack.php`
- Create: `System/Services/Assurance/Rules/FieldHomeServicesRulePack.php`
- Create: `System/Services/Assurance/Rules/EcommerceRulePack.php`
- Create: `System/Services/Assurance/Rules/PropertyHospitalityRulePack.php`
- Create: `System/Services/Assurance/Rules/FitnessWellnessRulePack.php`
- Create: `System/Services/Assurance/Rules/SalonBeautyRulePack.php`
- Create: `System/Services/Assurance/Rules/AutomotiveRulePack.php`
- Create: `System/Services/Assurance/Rules/FacilitiesRulePack.php`
- Create: `System/Services/Assurance/Rules/BookingHireRulePack.php`
- Modify: `System/Services/Assurance/DeterministicValidationPipeline.php`
- Test: `tests/Unit/RulePackRegistryTest.php`

**Interfaces:**
- `DeterministicRulePack::key(): string`
- `DeterministicRulePack::version(): string`
- `DeterministicRulePack::rules(array $context = []): array`
- `RulePackRegistry::resolve(string $key): DeterministicRulePack`
- `RulePackRegistry::keys(): array`

- [x] **Step 1: Write failing registry/version test**

```php
<?php
require_once __DIR__ . '/../Support/bootstrap.php';
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\RulePackRegistry;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\FieldHomeServicesRulePack;
use App\Extensions\TitanAssurance\System\Services\Assurance\Rules\EcommerceRulePack;

$registry = new RulePackRegistry([new FieldHomeServicesRulePack(), new EcommerceRulePack()]);
expect_true(in_array('field_home_services.v1', $registry->keys(), true), 'Field/home services v1 pack is registered.');
expect_same('1.0.0', $registry->resolve('ecommerce.v1')->version(), 'Rule pack version is explicit.');
$rules = $registry->resolve('field_home_services.v1')->rules();
expect_true(isset($rules['numeric_thresholds']), 'Rule pack exposes deterministic numeric constraints.');
```

- [x] **Step 2: Verify RED and implement contract/registry/packs**

Each vertical pack composes `CoreRulePack` and adds only universal deterministic constraints. Do not encode jurisdiction-specific legal requirements.

- [x] **Step 3: Extend validation pipeline with optional pack merge**

Add `validateCandidateWithPack(array $structuredResponse, DeterministicRulePack $pack, array $context = []): array` that merges pack rules with caller rules and returns `rule_pack_key` and `rule_pack_version` alongside existing findings/status.

- [x] **Step 4: Run full suite**

Run: `php tests/run-pure-tests.php`
Expected: all tests pass.

---

### Task 6: Legacy ModelCouncil convergence, schema additions, version/docs/package

**Files:**
- Modify: `System/Services/ModelCouncilService.php`
- Modify: `System/ModelCouncilServiceProvider.php`
- Create: `database/migrations/2026_08_09_000012_extend_assurance_accounting_and_policy_metadata.php`
- Modify: `System/Models/AssuranceRun.php`
- Modify: `System/Models/AssuranceCandidate.php`
- Modify: `extension.json`
- Modify: `README.md`
- Create: `docs/UPGRADE-PHASE-3.md`
- Test: `tests/Unit/LegacyProviderConvergenceTest.php`
- Test: `tests/Unit/AssuranceMigrationSurfaceTest.php`

**Interfaces:**
- Legacy non-streaming provider execution receives `ProviderExecutionGateway` through constructor injection or container resolution and routes compatible calls through it.
- New additive columns: candidate `normalized_usage`, `pricing_version`, `effective_cost`; run `rule_pack_key`, `rule_pack_version`, `evidence_source_summary`, `calibration_metadata`.

- [x] **Step 1: Write failing static convergence test**

```php
<?php
require_once __DIR__ . '/../Support/bootstrap.php';
$root = dirname(__DIR__, 2);
$source = file_get_contents($root . '/System/Services/ModelCouncilService.php') ?: '';
expect_true(str_contains($source, 'ProviderExecutionGateway'), 'Legacy ModelCouncil must reference the shared provider execution gateway.');
expect_true(str_contains($source, 'compatibility streaming'), 'Remaining direct streaming provider path must be explicitly documented as compatibility-only.');
```

- [x] **Step 2: Verify RED, then converge compatible legacy non-streaming calls**

Replace the reusable direct HTTP non-streaming provider helper(s) with gateway execution. Do not force SSE/pool streaming paths through a non-streaming contract. Add explicit source comments around remaining compatibility streaming HTTP blocks.

- [x] **Step 3: Write failing migration-surface test**

Check a new migration exists and contains `normalized_usage`, `pricing_version`, `effective_cost`, `rule_pack_key`, `rule_pack_version`, `evidence_source_summary`, and `calibration_metadata` without modifying prior migration filenames.

- [x] **Step 4: Implement additive migration/model casts**

Use `Schema::hasTable`/`Schema::hasColumn` guards matching v1.7 migration style; make down migration remove only v1.8 columns.

- [x] **Step 5: Update version/config/docs**

Set extension to `1.8.0`, policy version to `titan-assurance-v1.8`, document what is implemented and the live-host verification still required. Pricing entries in shipped config must be conservative placeholders only if authoritative values are already supplied by the host; otherwise ship an empty model catalogue/provider defaults so unknown pricing remains explicit rather than stale.

- [x] **Step 6: Run complete verification**

Run:

```bash
php tests/run-pure-tests.php
find . -name '*.php' -print0 | xargs -0 -n1 php -l
php -r '$j=json_decode(file_get_contents("extension.json"), true, 512, JSON_THROW_ON_ERROR); if (($j["version"]??"")!=="1.8.0") exit(1);'
grep -RInE '->delete\(|::destroy\(|truncate\(' System || true
grep -RInE 'usleep\(|sleep\(|while[[:space:]]*\(' System/Services/Assurance System/Jobs || true
```

Expected: all tests pass, all PHP files lint, manifest reports 1.8.0, no destructive runtime deletion, no assurance polling loops.

- [x] **Step 7: Build clean installer and development bundle**

Production installer includes extension runtime/docs but excludes `tests/` and `docs/superpowers/`. Development bundle includes source, tests, design, plan, prompt, upgrade report, source manifest and SHA-256 checksums. Verify both archives with `unzip -t` and verify every development checksum with `sha256sum -c`.

---

## Self-review

- Spec coverage: provider convergence, usage normalization, pricing/reconciliation, calibration, CRM evidence boundary, vertical rule packs, additive persistence, API additions, compatibility and packaging are each mapped to a task.
- Placeholder scan: no unresolved placeholders or unspecified code steps remain.
- Type consistency: gateway, pricing, calibration, evidence and rule-pack method names are stable across consuming tasks.
- Scope: streaming provider convergence and jurisdiction-specific compliance logic are explicitly deferred because they require separate contracts/current authoritative rule sources.
