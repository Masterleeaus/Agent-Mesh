# Failure Modes

Missing/stale evidence lowers assurance or triggers recollection. Contradictions remain explicit. Missing optional engines produces degraded integration state, not fabricated success. Database/tenant-resolution failures fail closed. Old assessments expire for Autonomy projection and must not become permanent authority evidence.
