# Capabilities

- `assurance.evaluate`: read/evaluate evidence and return GREEN/AMBER/RED plus score, evidence references, gaps, contradictions, reason codes and policy version. Never grants authority.
- `assurance.feedback.record`: append downstream acceptance/outcome feedback and update calibration/miscalibration state.
- `assurance.evidence.collect.request`: prepare/request the `assurance.evidence.collect` Interaction workflow for missing or stale evidence.
