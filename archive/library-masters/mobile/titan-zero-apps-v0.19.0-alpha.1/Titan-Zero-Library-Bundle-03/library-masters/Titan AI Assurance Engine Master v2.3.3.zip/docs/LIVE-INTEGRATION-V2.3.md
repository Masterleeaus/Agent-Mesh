# Titan Assurance v2.3 — Live Titan Signal Integration

## Scope

This release converts Titan Signal from a generic Assurance sink placeholder into a receiver-aware integration using the contracts shipped by Titan Signal Engine `0.20.0-rc.3`. It does not broaden Assurance ownership into Risk, Autonomy, Rewind, Wisdom, Knowledge Authority, AI Core or Interaction Engine.

## Receiver contract

Assurance consumes the Signal contracts for trusted emitter authority, registry authority, event-type registration and event emission. The installer therefore requires `titan-signal-engine >=0.20.0-rc.3`.

Assurance contributes two least-privilege identities at runtime:

- `titan-assurance:runtime`: `signal.emit`, limited to `assurance.*`.
- `titan-assurance:registry`: `signal.registry.event.manage`, limited to `assurance.*`, with no subscription-management authority.

Configuration contribution is load-order resilient: definitions are merged without replacing existing Signal identities and are contributed before Signal authority resolution.

## Canonical event family

The extension registers and emits:

1. `assurance.assessment.completed`
2. `assurance.evidence.recollection.requested`
3. `assurance.feedback.recorded`
4. `assurance.miscalibration.detected`

All events are tenant scoped, use Signal governance category, preserve trace/correlation/causation identifiers, and carry stable idempotency keys. Miscalibration is emitted at warning severity; the other lifecycle events are informational.

## Receipts and failure semantics

The Signal adapter returns the receiver receipt, including event ID, recorded time and duplicate/original-event information. Assurance persists integration receipts on the originating assessment/evidence-collection receipt/feedback metadata. Receiver absence, authority failure, registration failure or emission failure is recorded explicitly with a reason code and is never converted into a false successful dispatch.

This pass is synchronous receiver integration. A durable transactional integration outbox/recovery worker is a separate future hardening concern and is not claimed here.

## Receiver-limited engines

The source packages inspected for this pass expose these limits:

- **Titan Knowledge Authority v0.2.0-alpha.1**: health contract only; no live knowledge query/resolve contract available to Assurance.
- **Titan Wisdom Engine v0.1.2**: health/readiness/declaration surface only; outcome-learning domain explicitly not implemented.

Assurance retains structured compatibility contracts for these engines but does not report them as live integrations.

## Verification boundary

The adapter was contract-tested with the real Signal v0.20.0-rc.3 data classes and authority implementations. This does not constitute live Titan host/database deployment certification. Host installation, migrations, Laravel boot and real Signal persistence remain host certification items.
