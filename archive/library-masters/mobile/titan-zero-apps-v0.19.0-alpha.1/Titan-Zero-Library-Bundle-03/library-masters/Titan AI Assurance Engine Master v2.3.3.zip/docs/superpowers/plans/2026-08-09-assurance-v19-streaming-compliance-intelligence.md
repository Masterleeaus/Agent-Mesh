# Titan Assurance Engine v1.9 Streaming, Compliance Sources & Outcome Intelligence Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Converge the remaining ModelCouncil streaming provider path onto shared Assurance adapters, add integrity-checked external compliance rule sources, and expose company-scoped cross-run outcome intelligence without policy self-modification.

**Architecture:** Preserve `ModelCouncilService` as the AIChatPro compatibility façade while moving streaming network/provider mechanics behind new Assurance contracts and gateways. External compliance documents are immutable/versioned inputs converted into existing deterministic rule packs only after provenance/integrity validation. Cross-run intelligence is descriptive/advisory and cannot mutate permission or policy state.

**Tech Stack:** PHP 8.2+, Laravel/MagicAI host integration, Eloquent migrations/models, Guzzle/HTTP transport, existing pure-PHP unit harness.

## Global Constraints

- Preserve extension technical identity `ModelCouncil`, existing namespace layout, and AIChatPro SSE event names/payload shapes.
- Preserve all v1.8 Assurance HTTP endpoints; only additive endpoints/migrations are allowed.
- No web-worker sleep/poll loop in the v1.9 streaming/shared-message path.
- Do not bundle current jurisdiction-specific law claims; only provide source contracts, validators, and declarative deterministic execution.
- External compliance documents must fail closed on invalid hash, effective dates, jurisdiction, or required signature.
- Cross-run intelligence must remain company-scoped and advisory with `policy_mutation=false`.
- No destructive candidate/message deletion may be reintroduced.

---

### Task 1: Shared streaming execution gateway

**Files:**
- Create: `System/Contracts/AssuranceStreamingProviderTransport.php`
- Create: `System/Services/Assurance/Providers/StreamingProviderExecutionGateway.php`
- Test: `tests/Unit/StreamingProviderExecutionGatewayTest.php`

**Interfaces:**
- Consumes: `ProviderAdapterRegistry`, `UsageNormalizer`, existing `AssuranceProviderAdapter::buildRequest()` / `parseResponse()`.
- Produces: `AssuranceStreamingProviderTransport::stream(string $providerKey, string $modelId, array $request, callable $onChunk): array` and `StreamingProviderExecutionGateway::execute(...)` canonical envelope.

- [ ] **Step 1: Write the failing test**

```php
$transport = new class implements AssuranceStreamingProviderTransport {
    public function stream(string $providerKey, string $modelId, array $request, callable $onChunk): array {
        $onChunk('hel'); $onChunk('lo');
        return ['status'=>200,'body'=>['choices'=>[['message'=>['content'=>'hello']]],'usage'=>['total_tokens'=>2]],'response_time_ms'=>5,'chunk_count'=>2];
    }
};
$result = $gateway->execute('openai','gpt-4.1',[['role'=>'user','content'=>'x']],[],fn($c)=>$chunks[]=$c);
expect_same('hello',$result['text'],'Streaming gateway returns adapter-parsed final text.');
expect_same(['hel','lo'],$chunks,'Streaming gateway forwards chunks.');
```

- [ ] **Step 2: Run the test and verify RED**

Run: `php tests/Unit/StreamingProviderExecutionGatewayTest.php`
Expected: failure because streaming contract/gateway classes do not exist.

- [ ] **Step 3: Implement minimal streaming contract and gateway**

Gateway must build request via the registered adapter, invoke streaming transport, classify non-2xx through adapter retry classification, parse final body through the same adapter, normalize usage, and return `provider`, `model_id`, `text`, `usage`, `raw`, `response_time_ms`, `status`, `request`, `chunk_count`.

- [ ] **Step 4: Run test and full pure suite**

Run: `php tests/Unit/StreamingProviderExecutionGatewayTest.php && php tests/run-pure-tests.php`
Expected: PASS.

### Task 2: MagicAI streaming transport and ModelCouncil convergence

**Files:**
- Create: `System/Services/Assurance/Providers/MagicAIHttpStreamingProviderTransport.php`
- Modify: `System/Services/ModelCouncilService.php`
- Modify: `System/ModelCouncilServiceProvider.php`
- Test: `tests/Unit/LegacyStreamingConvergenceTest.php`

**Interfaces:**
- Consumes: `MagicAIProviderRequestFactory`, `StreamingProviderExecutionGateway`.
- Produces: streaming provider transport registered in container; ModelCouncil compatibility path delegates provider execution to streaming gateway while continuing to emit existing `model_stream_start`, `model_stream_delta`, `model_stream_end` events.

- [ ] **Step 1: Write the failing structural regression test**

```php
$source = file_get_contents($root.'/System/Services/ModelCouncilService.php');
expect_true(str_contains($source,'StreamingProviderExecutionGateway'),'ModelCouncil must use shared streaming gateway.');
expect_true(!str_contains($source,'compatibility streaming: the legacy SSE/Guzzle path remains direct'),'Legacy direct-stream marker must be gone.');
expect_true(!preg_match('/usleep\s*\(/',$source),'ModelCouncil web path must not sleep-poll.');
```

- [ ] **Step 2: Run RED**

Run: `php tests/Unit/LegacyStreamingConvergenceTest.php`
Expected: FAIL on missing gateway reference/direct streaming marker/usleep.

- [ ] **Step 3: Implement transport and compatibility façade**

`MagicAIHttpStreamingProviderTransport` uses the shared request factory for URL/headers and Guzzle streaming/response handling. `ModelCouncilService::streamParallelModelResponses()` resolves provider/model and calls `StreamingProviderExecutionGateway`, translating chunk callbacks to existing SSE deltas. Replace `waitForSharedModelMessages()` with one snapshot method that loads available source messages once and returns missing models as unavailable without polling.

- [ ] **Step 4: Register services and run tests**

Run: `php tests/Unit/LegacyStreamingConvergenceTest.php && php tests/run-pure-tests.php`
Expected: PASS and zero `usleep(` / `sleep(` in `ModelCouncilService.php`.

### Task 3: Compliance source contracts and integrity validation

**Files:**
- Create: `System/Contracts/ComplianceRuleSource.php`
- Create: `System/Contracts/ComplianceSignatureVerifier.php`
- Create: `System/Services/Assurance/Compliance/ComplianceRuleSourceRegistry.php`
- Create: `System/Services/Assurance/Compliance/ComplianceRuleDocumentValidator.php`
- Create: `System/Services/Assurance/Compliance/NullComplianceSignatureVerifier.php`
- Test: `tests/Unit/ComplianceRuleDocumentValidatorTest.php`

**Interfaces:**
- `ComplianceRuleSource::sourceKey(): string`
- `ComplianceRuleSource::fetch(string|int $companyId, string $rulePackKey, string $jurisdiction, array $context=[]): array`
- `ComplianceSignatureVerifier::verify(string $canonicalPayload, string $signature, ?string $keyId=null): bool`
- Validator returns canonical validated document or throws `InvalidArgumentException`.

- [ ] **Step 1: Write failing tests for hash, dates, jurisdiction, and signature-required behavior**

Use a fixed clock date parameter (`2026-08-09`) rather than wall-clock time. Compute content hash from canonical document excluding `content_hash`, `signature`, and `signature_key_id`. Assert valid document passes; tampered hash, future `effective_from`, expired `effective_to`, jurisdiction mismatch, and missing required signature fail.

- [ ] **Step 2: Run RED**

Run: `php tests/Unit/ComplianceRuleDocumentValidatorTest.php`
Expected: FAIL because contracts/validator do not exist.

- [ ] **Step 3: Implement canonicalizer/validator and registry**

Canonicalization recursively sorts associative keys and preserves list order before `json_encode(JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)`. Signature verification delegates only when the source policy requires it.

- [ ] **Step 4: Run tests**

Run: `php tests/Unit/ComplianceRuleDocumentValidatorTest.php && php tests/run-pure-tests.php`
Expected: PASS.

### Task 4: Declarative external compliance rule pack

**Files:**
- Create: `System/Services/Assurance/Compliance/ExternalComplianceRulePack.php`
- Create: `System/Services/Assurance/Compliance/ComplianceRulePackResolver.php`
- Modify: `System/Services/Assurance/DeterministicValidationPipeline.php`
- Test: `tests/Unit/ExternalComplianceRulePackTest.php`

**Interfaces:**
- Consumes validated document from Task 3.
- Supports deterministic declarative operations only: `required`, `non_negative`, `range`, `date_order`, `equals`, `in`.
- Produces existing deterministic findings shape with `rule_id`, `passed`, `severity`, `message`, `source`.

- [ ] **Step 1: Write failing rule execution tests**

Create a validated document containing a `required` customer identifier, `range` discount 0..100, and `date_order` start/end. Assert invalid context returns deterministic failures with source/version provenance.

- [ ] **Step 2: Run RED**

Run: `php tests/Unit/ExternalComplianceRulePackTest.php`
Expected: FAIL because external pack/resolver do not exist.

- [ ] **Step 3: Implement allow-listed declarative executor**

Reject unknown operators. Never evaluate arbitrary PHP, expressions, closures, SQL, or shell content from external documents.

- [ ] **Step 4: Run tests**

Run: `php tests/Unit/ExternalComplianceRulePackTest.php && php tests/run-pure-tests.php`
Expected: PASS.

### Task 5: Cross-run outcome intelligence and recommendations

**Files:**
- Create: `System/Services/Assurance/Intelligence/AssuranceOutcomeIntelligenceService.php`
- Create: `System/Services/Assurance/Intelligence/AssuranceRecommendationService.php`
- Test: `tests/Unit/AssuranceOutcomeIntelligenceServiceTest.php`
- Test: `tests/Unit/AssuranceRecommendationServiceTest.php`

**Interfaces:**
- `AssuranceOutcomeIntelligenceService::summarize(array $records, int $recentWindow=50): array`
- `AssuranceRecommendationService::recommend(array $intelligence): array`
- All outputs include `policy_mutation => false`.

- [ ] **Step 1: Write RED analytics test**

Feed canonical records with provider/model family, completed/failed state, assurance score, outcome success, disagreement, deterministic failure, evidence sufficiency, rule pack and cost-complete flags. Assert provider rates, model-family rates, disagreement/failure frequencies, rule-pack success, incomplete cost rate, and recent-vs-prior calibration drift.

- [ ] **Step 2: Run RED**

Run: `php tests/Unit/AssuranceOutcomeIntelligenceServiceTest.php`
Expected: FAIL because service does not exist.

- [ ] **Step 3: Implement pure aggregation with insufficient-data semantics**

No confidence interval or trend claim is emitted when the relevant cohort count is below configured minimum; return `insufficient_data=true` instead.

- [ ] **Step 4: Write RED recommendation test and implement advisory rules**

Recommendations may flag elevated provider failure, material disagreement drift, evidence sufficiency decline, incomplete accounting, or weak rule-pack outcomes. Every recommendation includes evidence count/reason and `policy_mutation=false`.

- [ ] **Step 5: Run tests**

Run: `php tests/Unit/AssuranceOutcomeIntelligenceServiceTest.php && php tests/Unit/AssuranceRecommendationServiceTest.php && php tests/run-pure-tests.php`
Expected: PASS.

### Task 6: Persistence/API integration

**Files:**
- Create: `database/migrations/2026_08_09_000013_extend_assurance_streaming_compliance_intelligence.php`
- Create: `database/migrations/2026_08_09_000014_create_assurance_intelligence_snapshots_table.php`
- Create: `System/Models/AssuranceIntelligenceSnapshot.php`
- Modify: `System/Models/AssuranceCandidate.php`
- Modify: `System/Models/AssuranceRun.php`
- Modify: `System/Http/Controllers/AssuranceController.php`
- Modify: `routes/api.php`
- Test: `tests/Unit/AssuranceV19MigrationSurfaceTest.php`
- Test: `tests/Unit/AssuranceV19ApiSurfaceTest.php`

**Interfaces:**
- Candidate columns: `streamed`, `stream_chunk_count`, `stream_completed_at`.
- Run columns: `compliance_source_key`, `compliance_jurisdiction`, `compliance_rule_version`, `compliance_rule_hash`.
- Snapshot columns include company id, window metadata, metrics JSON, recommendations JSON, generated timestamp.
- API: `GET /api/titan/assurance/intelligence`, `GET /api/titan/assurance/intelligence/recommendations`.

- [ ] **Step 1: Write failing migration/API surface tests**

Tests assert additive `Schema::hasColumn` guards, model casts/fillables, route strings and controller methods, and no policy-mutation route.

- [ ] **Step 2: Run RED**

Run: `php tests/Unit/AssuranceV19MigrationSurfaceTest.php && php tests/Unit/AssuranceV19ApiSurfaceTest.php`
Expected: FAIL because files/surfaces do not exist.

- [ ] **Step 3: Implement additive schema/model/API wiring**

Controller resolves authenticated company via existing company context, builds records only from that company, and returns intelligence/recommendations. No caller `company_id` parameter is accepted as authority.

- [ ] **Step 4: Run tests**

Run: `php tests/Unit/AssuranceV19MigrationSurfaceTest.php && php tests/Unit/AssuranceV19ApiSurfaceTest.php && php tests/run-pure-tests.php`
Expected: PASS.

### Task 7: Versioning, documentation, packaging, verification

**Files:**
- Modify: `extension.json` to `1.9.0`.
- Modify: `README.md`
- Modify: `docs/ARCHITECTURE.md`
- Modify: `docs/ASSURANCE-PIPELINE.md`
- Create: `docs/UPGRADE-PHASE-4.md`
- Modify/create: `SOURCE_MANIFEST.md`, `UPGRADE_REPORT.md`, development bundle checksum manifest.
- Test: `tests/Unit/VersionSurfaceTest.php`

**Interfaces:**
- Production installer root remains `extension.json`.
- Development-only tests/specs/plans are excluded from installer and retained in development bundle.

- [ ] **Step 1: Update version test first and verify RED**

Change expected version to `1.9.0`; run `php tests/Unit/VersionSurfaceTest.php` and confirm failure on `1.8.0`.

- [ ] **Step 2: Update version/docs and run complete source verification**

Run:

```bash
php tests/run-pure-tests.php
find . -name '*.php' -not -path './tests/*' -print0 | xargs -0 -n1 php -l
php -r '$j=json_decode(file_get_contents("extension.json"),true,512,JSON_THROW_ON_ERROR); if(($j["version"]??"")!=="1.9.0") exit(1);'
! grep -RniE '\b(delete|forceDelete)\s*\(' System
! grep -RniE '\b(usleep|sleep)\s*\(' System/Services/ModelCouncilService.php System/Services/Assurance System/Jobs
```

Expected: zero failures.

- [ ] **Step 3: Build installer and development bundle**

Installer contains runtime/config/migrations/docs only. Development bundle contains source plus tests, spec, plan, source manifest, report and SHA-256 checksums.

- [ ] **Step 4: Re-extract and verify packaged artifacts**

Run pure tests from development bundle ModelCouncil source, lint all installer PHP, validate manifest JSON/no BOM, verify checksums, `unzip -t` both archives, and confirm installer root contains `extension.json`.

Expected: all checks pass with explicit counts recorded in `UPGRADE_REPORT.md`.


## Implementation clarification — immutable compliance snapshot

Validated external compliance documents are persisted on the assurance run as `compliance_rule_snapshot` together with source, jurisdiction, version and content hash. Evaluation uses the stored snapshot rather than re-fetching mutable source content.
