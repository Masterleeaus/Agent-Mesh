# Disaster Recovery

Back up extension-owned Assurance tables and configuration. Target RPO 60 minutes and RTO 240 minutes for production deployments. After restore, reconcile assessment/feedback idempotency keys, optional bridge delivery status and calibration continuity before re-enabling autonomous consumers.
