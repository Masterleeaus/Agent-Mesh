# Upgrade Phase 3 — v1.8.0 Integration & Calibration

## Completed

- converged queued assurance provider execution on `ProviderExecutionGateway`
- centralized MagicAI provider endpoints and credentials in `MagicAIProviderRequestFactory`
- legacy ModelCouncil non-streaming parallel calls now reuse Assurance provider adapters and the centralized request factory
- legacy ModelCouncil synthesis uses the shared gateway when resolved through Laravel's container
- legacy SSE streaming remains an explicitly isolated compatibility transport pending a streaming-adapter contract
- normalized OpenAI-compatible, Anthropic and Gemini token usage into a stable usage envelope
- retained provider-reported monetary cost when available
- added versioned host-configurable provider/model pricing catalogue and calculated fallback cost
- unknown provider/model pricing remains `pricing_unknown`; the extension does not fabricate a zero or stale price
- added candidate-level normalized usage, pricing version and effective cost persistence
- added outcome recording and descriptive calibration metrics (success rate, score buckets, Brier score and calibration gap)
- calibration is advisory only and cannot lower thresholds, bypass approval, or mutate assurance policy
- added `EvidenceSourceAdapter`, registry and CRM adapter boundary without direct CRM table/model coupling
- caller-supplied tenant/company ids are stripped before CRM evidence resolution
- evidence source adapters receive the secured company context and resolved records become part of the immutable evidence packet
- added eight versioned deterministic vertical rule packs
- added automatic vertical-to-rule-pack mapping and persisted rule pack key/version
- evaluator executes selected rule packs and records their metadata in scoring components
- cost reconciliation now reports incomplete accounting when candidate cost is unknown rather than silently coercing it to zero
- added additive v1.8 schema only; no v1.7 migrations were rewritten

## Built-in rule packs

- `field_home_services.v1`
- `ecommerce.v1`
- `property_hospitality.v1`
- `fitness_wellness.v1`
- `salon_beauty.v1`
- `automotive.v1`
- `facilities.v1`
- `booking_hire.v1`

The built-in packs intentionally contain universal deterministic data-integrity rules only: non-negative monetary/quantity values, bounded percentages, chronological date ordering, response confidence bounds and evidence references for consequential claims. They do **not** hard-code jurisdiction-specific legal or regulatory requirements.

## CRM evidence host binding

The Assurance core does not require CRM to boot. A CRM/Titan integration can register an implementation of `EvidenceSourceAdapter` under the Laravel container tag:

```php
$this->app->tag(CrmEvidenceAdapter::class, 'titan.assurance.evidence_sources');
```

The concrete `CrmEvidenceAdapter` accepts a host-supplied reader callable and passes that reader the secured `company_id` plus sanitized evidence references. No CRM table name or model class is embedded in the Assurance extension.

## New API surface

In addition to the v1.7 run lifecycle:

- `POST /api/titan/assurance/runs/{runId}/outcomes`
- `GET /api/titan/assurance/calibration`

Both remain inside the configured authenticated Assurance middleware group and company context.

## Important production checks

Before production enablement:

1. Run the v1.8 additive migration against a database backup/staging copy.
2. Confirm Laravel can resolve `MagicAIProviderRequestFactory` and the six configured provider adapters.
3. Execute one sandbox call per provider and inspect normalized usage payloads.
4. Populate the pricing catalogue from an authoritative host source if calculated fallback cost is required; shipped model pricing is intentionally empty.
5. Register the CRM evidence adapter from the CRM integration and verify company A cannot resolve company B evidence references.
6. Test each enabled vertical rule pack against real decision-packet `validation_context` fields.
7. Record representative real outcomes and inspect calibration only after a meaningful sample exists.
8. Do not automate policy threshold changes from calibration output in v1.8.
9. Verify the legacy SSE ModelCouncil path in AIChatPro because streaming remains compatibility code.
10. Verify all action consumers still require `permission_state === "permitted"`.

## Still intentionally deferred

- live MagicAI database migration certification in the user's production environment
- live API-provider credential/cost certification
- automatic live provider price discovery
- automatic threshold/policy learning
- jurisdiction-specific compliance rule packs without authoritative current rule sources
- shared streaming provider adapter contract for the legacy AIChatPro SSE path
- external business action adapter beyond the existing fail-closed permission state
