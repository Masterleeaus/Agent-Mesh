# Titan Assurance Engine v2 — Evidence Contract

## POST `/api/titan/assurance/assessments`

Canonical request shape:

```json
{
  "idempotency_key": "stable-caller-key",
  "subject": {"type": "job", "id": "JOB-123"},
  "decision_type": "job.complete",
  "capability": "job.complete",
  "capability_variant": "standard",
  "vertical": "field_home_services",
  "jurisdiction": "AU-VIC",
  "trace": {
    "trace_id": "uuid",
    "correlation_id": "uuid",
    "causation_id": "uuid-or-null"
  },
  "requirements": [
    {
      "key": "completion_photo",
      "evidence_type": "completion_photo",
      "required": true,
      "critical": false
    }
  ],
  "knowledge_references": [
    {
      "guide_id": "knowledge-guide-id",
      "version": "exact-version",
      "hash": "exact-version-hash",
      "section": "section-id",
      "jurisdiction": "AU-VIC",
      "authority": "authority-name",
      "applicable_exception": null
    }
  ],
  "evidence": [
    {
      "evidence_id": "uuid-optional",
      "evidence_type": "completion_photo",
      "subject": {"type": "job", "id": "JOB-123"},
      "source": "titan_vision",
      "provenance": {"capture_device": "device-ref", "confidence": 0.95},
      "captured_at": "ISO-8601",
      "effective_at": "ISO-8601-or-null",
      "expires_at": "ISO-8601-or-null",
      "freshness": 0.95,
      "confidence": 0.93,
      "authority": 0.80,
      "relevance": 1.0,
      "applicability": 1.0,
      "provenance_confidence": 0.95,
      "jurisdiction": "AU-VIC",
      "vertical": "field_home_services",
      "scope": {"job_id": "JOB-123"},
      "hash": "sha256-or-generated",
      "verification_state": "verified",
      "contradicts": []
    }
  ]
}
```

## Result fields

The persisted assessment returns:

- `status`
- `score`
- `evidence_used`
- `missing_evidence`
- `stale_evidence`
- `contradictory_evidence`
- `reason_codes`
- `policy_version`
- `calibration_metadata`
- `knowledge_references`
- `evidence_collection_receipt`
- `integration_receipts`
- trace fields

This response is **not permission to execute** and is **not a Risk decision**.

## POST `/api/titan/assurance/assessments/{id}/feedback`

```json
{
  "feedback_type": "manager_decision",
  "source_ref": "manager-review-123",
  "idempotency_key": "optional-stable-key",
  "accepted": false,
  "decision": "rejected",
  "metadata": {"reason_code": "insufficient_site_evidence"}
}
```

Feedback is append-only calibration evidence. It cannot directly grant/revoke Autonomy or mutate Titan policy.
