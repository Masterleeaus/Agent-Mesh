# Assurance Pipeline Contract

## Run lifecycle

Typical states:

`collecting_evidence -> pending -> queued -> running -> evaluating -> challenging -> awaiting_human_review -> assured`

Fail-closed terminal alternatives include `policy_blocked`, `material_disagreement`, `insufficient_evidence`, `failed`, `expired`, `superseded`, and `cancelled`.

## Candidate lifecycle

`pending -> queued -> running -> completed`

Failure path:

`running -> retryable_failed -> running ... -> failed`

or `queued/running -> cancelled`.

Candidate records may also persist streaming metadata: `streamed`, `stream_chunk_count`, and `stream_completed_at`.

## Start panel schema

```json
[
  {
    "provider": "openai",
    "model_id": "gpt-4.1",
    "snapshot": null,
    "assigned_role": "primary_reviewer",
    "estimated_cost": 0.20
  },
  {
    "provider": "anthropic",
    "model_id": "claude-sonnet-example",
    "assigned_role": "risk_reviewer",
    "estimated_cost": 0.25
  }
]
```

For High/Critical modes, `challenge_model` may be supplied in start options. If omitted, orchestration selects a differing provider/family from the validated panel where possible.

## Candidate output contract

Providers are instructed to return JSON with these top-level keys:

```json
{
  "answer": "...",
  "confidence": 0.83,
  "claims": [{"claim": "...", "evidence_ids": ["crm-job-123"]}],
  "evidence": [{"id": "crm-job-123", "source": "crm:job:123"}],
  "risks": [],
  "assumptions": []
}
```

Invalid JSON is retained as raw response text but receives a deterministic parse failure.

## Shared provider execution

Synchronous and streaming paths use the same `ProviderAdapterRegistry` and request factory. `StreamingProviderExecutionGateway` accepts a chunk callback. If the transport returns no provider-native chunks, it emits the canonical parsed answer as a fallback chunk. This means the architecture is streaming-compatible without pretending every configured provider emits native token deltas.

Legacy ModelCouncil converts canonical chunks back to its existing AIChatPro SSE event schema. There is no direct provider/Guzzle streaming implementation in `ModelCouncilService` and no shared-message sleep/query polling loop.

## Assurance HTTP API

Default prefix: `/api/titan/assurance`.

### Create

`POST /runs`

```json
{
  "decision_packet": {
    "validation_context": {}
  },
  "options": {
    "idempotency_key": "crm:quote:902:approval:1",
    "source_type": "crm_quote",
    "source_id": "902",
    "decision_type": "approve_discount",
    "rule_pack_key": "field_home_services"
  }
}
```

### Create with an external compliance source

A host-registered source can be selected through options:

```json
{
  "decision_packet": {
    "validation_context": {"amount": 125.00}
  },
  "options": {
    "rule_pack_key": "example_compliance_pack",
    "compliance_source_key": "host_compliance_catalogue",
    "compliance_jurisdiction": "AU-VIC",
    "compliance_signature_required": true
  }
}
```

The caller does not provide a trusted company id. Assurance supplies the authenticated company context to the compliance source. The validated document is persisted as an immutable `compliance_rule_snapshot` with source, jurisdiction, version and content hash, and evaluation uses that snapshot rather than re-fetching mutable content.

### Lock evidence

`PUT /runs/{runId}/evidence`

```json
{"evidence_packet": {}}
```

Evidence is immutable after locking. A different packet requires a new run.

### Start

`POST /runs/{runId}/start`

```json
{
  "panel": [],
  "options": {
    "budget_ceiling": 2.50,
    "currency": "USD"
  }
}
```

### Human decision

`POST /runs/{runId}/decision`

```json
{
  "decision": "approve",
  "reason": "Evidence and controls reviewed",
  "conditions": []
}
```

Recorded alternatives include `reject`, `request_more_evidence`, and `rerun`.

## Evidence-source input

`PUT /runs/{runId}/evidence` may include host-resolved evidence-source requests:

```json
{
  "evidence_packet": {
    "evidence_sources": [
      {
        "source": "crm",
        "references": {"source_type": "job", "source_id": "902"}
      }
    ]
  }
}
```

Assurance supplies the authenticated company context to the registered adapter, canonicalizes the returned record and locks its hash into the evidence packet.

## Deterministic rule operators for external packs

External compliance documents may use only:

- `required`
- `non_negative`
- `range`
- `date_order`
- `equals`
- `in`

Unknown operators fail pack construction. The extension does not evaluate arbitrary code or expressions from compliance documents.

## Outcome, calibration and intelligence API

- `POST /runs/{runId}/outcomes` appends an observed result for the current company.
- `GET /calibration` returns descriptive calibration metrics.
- `GET /intelligence` returns cross-run company-scoped outcome/provider/rule-pack evidence.
- `GET /intelligence/recommendations` returns advisory recommendations.

Run-level intelligence deduplicates by `run_id`; provider/model metrics remain candidate-level. Intelligence outputs cannot mutate assurance policy.

## Provider/accounting envelope

Each completed candidate may persist `normalized_usage`, `pricing_version`, `cost`, and `effective_cost`. If provider cost is unavailable and no matching host price exists, `effective_cost` remains null and accounting is marked incomplete. Run reconciliation considers `effective_cost` when raw cost is absent.
