# Titan Assurance Engine v1.7 Execution Pipeline Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Add a company-scoped, queued assurance execution pipeline with model/provider independence, deterministic validation, adversarial challenge, transparent scoring, fail-closed permission gates and cost reservation while preserving ModelCouncil compatibility.

**Architecture:** Keep `ModelCouncilService` as the compatibility facade and build new behavior as focused services, adapters and jobs under `System`. Persist execution state in the v1.6 assurance tables extended with explicit lifecycle, identity, scoring and cost fields. Queue jobs operate idempotently from persisted records instead of polling in web requests.

**Tech Stack:** PHP 8.1+, Laravel/Eloquent/Queues/Events, MagicAI extension conventions, SHA-256 evidence hashes.

## Global Constraints

- `company_id` is the authoritative tenant boundary.
- Do not introduce a duplicate assurance/business operating system outside this extension.
- Do not delete candidate/model evidence or minority opinions.
- Preserve `ModelCouncil` technical identity and existing AIChatPro compatibility.
- Confidence never grants execution permission by itself.
- High/Critical modes require independent model families; Critical prefers cross-provider diversity.
- High/Critical require adversarial challenge and human approval.
- External cost must be reserved before provider dispatch when a budget ceiling is supplied.
- Queue execution must be idempotent and retry-safe.

---

### Task 1: Capability registry and model identity

**Files:**
- Create: `System/Services/Assurance/Capabilities/ModelCapabilityRegistry.php`
- Create: `System/Services/Assurance/Capabilities/ModelIdentityResolver.php`
- Create: `tests/Unit/ModelCapabilityRegistryTest.php`

**Interfaces:**
- Produces: `ModelCapabilityRegistry::resolve(string $provider, string $modelId): array`
- Produces: `ModelIdentityResolver::resolve(string $provider, string $modelId, ?string $snapshot = null): array`

- [x] Write a failing pure-PHP test proving known OpenAI/Anthropic/Gemini/DeepSeek/xAI/OpenRouter models resolve to normalized provider, family and capability fields and unknown models receive a conservative fallback family.
- [x] Run the test and verify failure because classes do not exist.
- [x] Implement the registry and resolver with config-extensible defaults.
- [x] Run the test and verify pass.

### Task 2: Provider adapter boundaries and registry

**Files:**
- Create: `System/Services/Assurance/Providers/AbstractProviderAdapter.php`
- Create: `System/Services/Assurance/Providers/OpenAIAdapter.php`
- Create: `System/Services/Assurance/Providers/AnthropicAdapter.php`
- Create: `System/Services/Assurance/Providers/GeminiAdapter.php`
- Create: `System/Services/Assurance/Providers/DeepSeekAdapter.php`
- Create: `System/Services/Assurance/Providers/XAIAdapter.php`
- Create: `System/Services/Assurance/Providers/OpenRouterAdapter.php`
- Create: `System/Services/Assurance/Providers/ProviderAdapterRegistry.php`
- Create: `tests/Unit/ProviderAdapterRegistryTest.php`

**Interfaces:**
- Consumes: `AssuranceProviderAdapter`.
- Produces: `ProviderAdapterRegistry::for(string $provider, string $modelId): AssuranceProviderAdapter`.

- [x] Write tests for adapter selection, normalized request envelopes and retry classification.
- [x] Verify tests fail.
- [x] Implement adapters without performing network I/O; keep transport outside adapter boundaries.
- [x] Verify tests pass.

### Task 3: Panel policy and independence

**Files:**
- Create: `System/Services/Assurance/PanelSelectionService.php`
- Create: `System/Services/Assurance/IndependenceScoringService.php`
- Create: `tests/Unit/PanelSelectionServiceTest.php`

**Interfaces:**
- Consumes: normalized model identities.
- Produces: `PanelSelectionService::validate(array $panel, string $mode): array` with `valid`, `violations`, `provider_count`, `family_count`.
- Produces: `IndependenceScoringService::score(array $panel): array`.

- [x] Test Standard/High/Critical minimum candidate and family requirements and Critical cross-provider preference.
- [x] Verify tests fail.
- [x] Implement policy validation and score components.
- [x] Verify tests pass.

### Task 4: Extend persistence for execution lifecycle and cost

**Files:**
- Create: `database/migrations/2026_08_09_000010_extend_assurance_runs_for_execution_pipeline.php`
- Create: `database/migrations/2026_08_09_000011_extend_assurance_candidates_for_execution_pipeline.php`
- Modify: `System/Models/AssuranceRun.php`
- Modify: `System/Models/AssuranceCandidate.php`

**Interfaces:**
- Run fields include lifecycle timestamps, panel spec, independence score, deterministic score, disagreement score, challenge score, estimated/reserved/actual cost, currency and failure code.
- Candidate fields include status, provider/model/family/snapshot, attempt count, error class, response hash, latency and cost.

- [x] Add additive nullable/defaulted columns only; do not rewrite v1.6 migrations.
- [x] Update model casts/relations-safe fields.
- [x] Run PHP syntax checks.

### Task 5: Structured candidate response and deterministic validation

**Files:**
- Create: `System/Services/Assurance/StructuredResponseValidator.php`
- Modify: `System/Services/Assurance/DeterministicValidationService.php`
- Create: `System/Services/Assurance/DeterministicValidationPipeline.php`
- Create: `tests/Unit/DeterministicValidationPipelineTest.php`

**Interfaces:**
- Candidate response schema: `answer`, `confidence`, `claims[]`, `evidence[]`, `risks[]`, `assumptions[]`.
- Produces normalized findings with `code`, `severity`, `passed`, `message`, `metadata`.

- [x] Write tests for malformed response, missing evidence, numeric/range rules and required-key rules.
- [x] Verify fail.
- [x] Implement validators and finding normalization.
- [x] Verify pass.

### Task 6: Disagreement, adversarial challenge and scoring

**Files:**
- Create: `System/Services/Assurance/DisagreementAnalyzer.php`
- Create: `System/Services/Assurance/AdversarialChallengeService.php`
- Create: `System/Services/Assurance/AssuranceScoringService.php`
- Create: `tests/Unit/AssuranceScoringServiceTest.php`

**Interfaces:**
- Produces disagreement metadata separating answer disagreement, evidence disagreement and risk disagreement.
- Produces challenge prompt packet from immutable evidence + candidate claims.
- Produces transparent 0-100 assurance score and component map; no component alone grants permission.

- [x] Write tests showing strong agreement with poor evidence cannot score as fully assured and material disagreement depresses score.
- [x] Verify fail.
- [x] Implement deterministic scoring weights from config.
- [x] Verify pass.

### Task 7: Cost estimation, reservation and reconciliation

**Files:**
- Create: `System/Services/Assurance/Cost/CostEstimator.php`
- Create: `System/Services/Assurance/Cost/CostReservationService.php`
- Create: `System/Services/Assurance/Cost/CostReconciler.php`
- Create: `tests/Unit/CostControlTest.php`

**Interfaces:**
- `CostEstimator::estimate(array $panel, array $options): array`.
- `CostReservationService::reserve(AssuranceRun $run, float $estimated, ?float $budgetCeiling): AssuranceRun`.
- `CostReconciler::reconcile(AssuranceRun $run, array $candidateUsage): AssuranceRun`.

- [x] Test insufficient explicit budget ceiling blocks before dispatch and reconciliation never returns negative cost.
- [x] Verify fail.
- [x] Implement deterministic accounting hooks without coupling to an unknown billing API.
- [x] Verify pass.

### Task 8: Permission gates and approval policy

**Files:**
- Create: `System/Services/Assurance/PermissionGateService.php`
- Modify: `System/Services/Assurance/AssuranceEngineService.php`
- Create: `tests/Unit/PermissionGateServiceTest.php`

**Interfaces:**
- `PermissionGateService::evaluate(array $context): array` returns `permission_state`, `status`, `human_approval_required`, `violations`.

- [x] Test fail-closed behavior, Standard automatic permission only when all required checks pass, and mandatory High/Critical human gates.
- [x] Verify fail.
- [x] Implement gates and harden `approve()` so Critical approval can transition to permitted only when required evidence/checks/challenge are complete.
- [x] Verify pass.

### Task 9: Idempotent queue jobs and orchestrator

**Files:**
- Create: `System/Jobs/ExecuteAssuranceCandidate.php`
- Create: `System/Jobs/EvaluateAssuranceRun.php`
- Create: `System/Jobs/ChallengeAssuranceRun.php`
- Create: `System/Services/Assurance/CandidateExecutionService.php`
- Create: `System/Services/Assurance/AssuranceRunOrchestrator.php`
- Modify: `System/Contracts/AssuranceEngine.php`
- Modify: `System/Services/Assurance/AssuranceEngineService.php`

**Interfaces:**
- `AssuranceEngine::start(int $runId, array $panel, array $options = []): AssuranceRun`.
- Jobs short-circuit terminal records and use persisted attempt state.

- [x] Add start/orchestration contract and candidate creation flow.
- [x] Dispatch one candidate job per persisted candidate, then evaluation through a queue batch/chain-compatible approach without request-worker polling.
- [x] Add bounded retry/backoff based on normalized error class.
- [x] Run syntax checks.

### Task 10: Service provider, config and compatibility bridge

**Files:**
- Modify: `System/ModelCouncilServiceProvider.php`
- Modify: `config/model-council.php`
- Modify: `System/Services/ModelCouncilService.php` only at a narrow integration seam if available.

**Interfaces:**
- Assurance core services register regardless of AIChatPro registration.
- AIChatPro-specific routes/views remain conditional.

- [x] Register adapters/registries/services in the container.
- [x] Add scoring, retry, cost and capability config.
- [x] Remove the early-return that prevents core assurance migrations/services booting without AIChatPro, while preserving conditional UI/routes.
- [x] Review the compatibility bridge seam. No safe public seam exists because the legacy ModelCouncil provider request/parse methods are private; leave the AIChatPro streaming path untouched in v1.7 and document the later unification refactor.
- [x] Run syntax checks.

### Task 11: Documentation, structural tests and packaging

**Files:**
- Create: `docs/UPGRADE-PHASE-2.md`
- Create: `docs/ASSURANCE-PIPELINE.md`
- Modify: `README.md`
- Modify: `extension.json`
- Create: `tests/run-pure-tests.php`

**Interfaces:**
- Package version becomes `1.7.0`.

- [x] Document lifecycle, policy modes, tenant rules, queue requirements and host-integration tests.
- [x] Run all pure tests.
- [x] Run `php -l` across every PHP file.
- [x] Verify `extension.json` parses without BOM.
- [x] Build install ZIP with `extension.json` at archive root and a development bundle containing prompt/spec/plan/report/checksums.
- [x] Run `unzip -t` and checksum validation on final archives.
