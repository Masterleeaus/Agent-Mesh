# Titan Assurance Engine v1.8 Integration & Calibration Design

## Goal

Unify legacy ModelCouncil provider execution with the v1.7 assurance provider boundary, make usage/cost accounting authoritative, add read-only outcome calibration metrics, introduce CRM evidence adapters without CRM schema coupling, and add versioned deterministic rule packs for Titan verticals.

## Chosen approach

### Option A — compatibility-shell convergence (selected)

Keep the public `ModelCouncilService`/AIChatPro surface stable but route non-streaming provider execution through a shared provider gateway backed by `ProviderAdapterRegistry` and `AssuranceProviderTransport`. Streaming remains compatibility-owned until a later streaming adapter contract exists. This removes duplicate request construction for normal calls without rewriting the entire chat feature.

### Option B — rewrite ModelCouncil onto Assurance jobs

Move all legacy chat flows, including SSE streaming, into the assurance job pipeline immediately. This produces maximum convergence but risks breaking interactive AIChatPro behavior and mixes chat UX concerns with decision assurance.

### Option C — keep dual stacks and share only accounting

Leave legacy provider HTTP logic untouched and normalize only usage/cost. This is lowest risk short-term but preserves duplicated credential, request, retry, and provider behavior indefinitely.

Option A is selected because it converges the reusable execution path while preserving legacy streaming compatibility.

## Architecture

### 1. Shared provider execution gateway

Add `ProviderExecutionGateway` as the single non-streaming call boundary used by both assurance candidates and legacy ModelCouncil. It resolves the provider adapter, builds a provider-specific request, sends it through `AssuranceProviderTransport`, rejects non-2xx responses using adapter retry classification, parses the response, normalizes usage, and returns a stable result envelope.

Legacy ModelCouncil will call this gateway for compatible non-streaming paths. Existing streaming-specific code remains in `ModelCouncilService` and is explicitly marked compatibility-only.

### 2. Usage normalization and pricing

Add `UsageNormalizer`, `ProviderPricingCatalogue`, and `UsageCostCalculator`.

Normalized usage shape:

- `input_tokens`
- `output_tokens`
- `total_tokens`
- `cached_input_tokens`
- `reasoning_tokens`
- `reported_cost`
- `calculated_cost`
- `effective_cost`
- `currency`
- `pricing_version`

Provider-reported cost wins when present. Otherwise cost is calculated from a versioned configured pricing catalogue. Unknown pricing never guesses: calculated cost remains null and reconciliation records `pricing_unknown`.

The pricing catalogue is configuration-driven, supports exact model entries plus provider defaults, and never requires a code fork for price changes.

### 3. Outcome recording and calibration

Add `OutcomeRecorder` and `AssuranceCalibrationService`.

Outcomes are company-scoped, actor-attributed, append-only observations of whether an assured decision succeeded, its impact, and any correction. Calibration computes descriptive metrics by policy version/risk/mode, including sample count, success rate, mean assurance score, score buckets, Brier score where binary outcomes are available, and calibration gap.

Calibration is advisory only in v1.8. It must not automatically lower assurance thresholds, bypass approvals, or mutate policy configuration.

### 4. CRM evidence boundary

Add `EvidenceSourceAdapter` contract, `EvidenceSourceRegistry`, and a `CrmEvidenceAdapter` that depends on an injected CRM reader callback/service rather than direct CRM models/tables.

The adapter accepts company ID plus explicit evidence references and emits canonical evidence records with source type, source ID, version/timestamp, content/metadata, and provenance. Company ID is always supplied by secured assurance context, not caller payload.

If CRM is absent, the assurance core still boots. The CRM adapter can be registered conditionally by a host integration provider later.

### 5. Versioned deterministic rule packs

Add `DeterministicRulePack` contract, `RulePackRegistry`, and built-in initial packs:

- `field_home_services.v1`
- `ecommerce.v1`
- `property_hospitality.v1`
- `fitness_wellness.v1`
- `salon_beauty.v1`
- `automotive.v1`
- `facilities.v1`
- `booking_hire.v1`

Rule packs return deterministic validation rules only. They do not encode business data and do not query CRM directly. Initial rules focus on universal safety/data-integrity checks that are reliable without jurisdiction-specific assumptions: required evidence references for consequential claims, non-negative money/quantity constraints, bounded percentages, date ordering, and explicit risk/assumption fields.

Jurisdiction-specific legal/compliance rules are intentionally not hard-coded in this release.

### 6. Persistence

Add additive columns to assurance candidates/runs for normalized usage, pricing version, effective actual cost, calibration metadata, rule-pack key/version, and evidence source summary. Do not rewrite prior migrations.

### 7. API additions

Add company-scoped endpoints to record an outcome and retrieve calibration summary for a run/policy slice. Calibration access is read-only. Existing v1.7 endpoint behavior remains unchanged.

## Data flow

1. Caller creates and locks an assurance run.
2. Evidence may be supplied directly or resolved through registered evidence source adapters.
3. Rule-pack selection resolves deterministic rules and records pack key/version on the run.
4. Candidate execution calls `ProviderExecutionGateway`.
5. Gateway returns parsed text plus normalized usage and effective cost.
6. Candidate persists usage/cost before completion event.
7. Run reconciliation sums candidate/challenge/synthesis effective costs.
8. After a real-world result is known, an authorized actor records an outcome.
9. Calibration service computes descriptive reliability metrics without changing policy thresholds.

## Failure behavior

- Unknown provider/model adapter: terminal failure.
- Non-2xx provider response: retry/terminal classification comes from provider adapter.
- Unknown pricing: execution may proceed if budget policy allows unknown-cost calls; otherwise policy blocks before dispatch. No fabricated price.
- Malformed usage: normalize known numeric fields and retain raw usage metadata; never throw solely for optional token counters.
- Missing CRM adapter: explicit evidence-source request fails closed with `evidence_source_unavailable`; assurance core still boots.
- Missing rule pack: fail closed if explicitly requested; default policy may use the core deterministic pipeline with no vertical pack.
- Outcome recording cannot alter the original run decision packet.

## Testing

Use the existing pure-PHP runner for deterministic components and API-surface/static contract checks. Add tests for:

- provider execution gateway success/non-2xx classification
- OpenAI/Anthropic/Gemini-style usage normalization
- provider-reported vs calculated cost precedence
- unknown pricing behavior
- calibration metrics and no threshold mutation
- CRM evidence company scoping/provenance
- rule-pack versioning and vertical registry
- legacy ModelCouncil source references the shared gateway for non-streaming execution
- additive migration/API surface

Host-app integration remains required for live Laravel DB migrations, credentials, queue workers, CRM service binding, and real provider usage payloads.

## Compatibility constraints

- Technical extension identity remains `ModelCouncil`.
- Existing v1.7 routes/contracts/tables remain valid.
- `company_id` remains the tenant boundary; `user_id` is actor identity only.
- AIChatPro remains optional for assurance core boot.
- No automatic external action is permitted unless existing permission gates pass.
- No calibration process may auto-relax policy or approval requirements in v1.8.
