# Titan Assurance Engine v2 — Evidence-Native Architecture

## Canonical ownership

Titan Assurance Engine v2 owns **evidence support**, not authority.

```text
Proposal / planned action
    |
    +--> Titan Risk --------------------> danger / exposure
    |
    +--> Titan Assurance v2 ------------> evidence support: GREEN / AMBER / RED
    |         |
    |         +--> Knowledge Authority exact references
    |         +--> Interaction Engine evidence recollection request
    |         +--> downstream outcome calibration
    |
    +--> Titan Autonomy ----------------> may the AI act independently?
    |
    +--> Command Bus -------------------> governed execution
```

The v2 evidence path contains no provider execution, no panel selection, no Risk classifier and no permission gate.

## Compatibility shell

The technical extension identity remains `ModelCouncil`. v1.x run/panel/provider/permission code is retained so installed AIChatPro and historical assurance data do not break. It is a compatibility path, not the canonical ownership model for new Titan integrations.

The legacy run API can now accept externally supplied `risk_context` from Titan Risk. Its internal risk classifier is explicitly marked as a compatibility fallback.

## Canonical assessment flow

```text
resolve tenant internally
  -> validate subject
  -> normalize evidence records
  -> validate exact Knowledge Authority references
  -> calculate evidence weights
  -> load downstream calibration cohort
  -> apply calibration factor
  -> calculate GREEN / AMBER / RED result
  -> identify missing / stale / contradictory evidence
  -> request Interaction evidence collection if required
  -> persist assessment + evidence snapshots
  -> publish structured Signal/Rewind integration envelopes
  -> return assessment receipt
```

## Evidence weighting

Evidence value is calculated as:

```text
authority
× relevance
× freshness
× applicability
× provenance_confidence
× contradiction_adjustment
```

All factors are normalized to `[0,1]`. Percentage inputs are accepted and normalized. Expired/not-yet-effective evidence receives zero freshness. Evidence explicitly contradicting another record receives a default contradiction adjustment of `0.5` unless policy supplies a stricter value.

## Assurance result

The stored result includes:

- status: GREEN / AMBER / RED
- score
- evidence used and component weights
- missing evidence
- stale evidence
- contradictory evidence pairs
- reason codes
- policy version
- calibration factor
- Knowledge Authority references
- evidence collection receipt
- trace/correlation/causation IDs

`authority_decision` and `risk_decision` are explicitly `null` in the canonical result snapshot. Consumers must obtain those decisions from their owning Titan engines.

## Calibration and miscalibration

Supported feedback types are:

- `manager_decision`
- `receiving_team_decision`
- `titan_shield`
- `crm_outcome`
- `customer_outcome`
- `titan_wisdom`

Calibration is cohort-aware by tenant, decision type and vertical. Multiple feedback records for one assessment are consolidated so one assessment cannot manufacture a large sample size.

If enough GREEN assessments are rejected downstream, `MiscalibrationDetector` reduces the calibration factor applied to future assessments in the same cohort. This does not mutate policy thresholds. A structured miscalibration envelope is offered to registered integration sinks for:

- Titan Autonomy
- Titan AI Core
- Titan Signal
- Titan Wisdom

## Integration boundary

Host extensions may register `AssuranceIntegrationSink` implementations under the Laravel tag:

`titan.assurance.integration_sinks`

Each sink declares its destination key and must deduplicate by the supplied `idempotency_key`. Missing sinks are reported as unavailable rather than silently claimed as dispatched.

Expected destination keys include:

- `titan_signal`
- `titan_rewind`
- `titan_autonomy`
- `titan_ai_core`
- `titan_wisdom`

Interaction Engine recollection is exposed separately through `EvidenceCollectionRequester`; the default implementation emits a structured Laravel event with an idempotent request ID.

## Tenant and trace rules

New v2 persistence uses `company_id`. `CompanyContextResolver` checks that canonical attribute first and retains older `company_id/current_company_id/active_company_id` fallbacks for installed systems.

Every assessment carries:

- `trace_id`
- `correlation_id`
- `causation_id`

Legacy run/event tables receive additive trace columns and `company_id` backfill; existing `company_id` columns remain intact.

## Knowledge boundary

v2 does not execute embedded current regulatory knowledge. It stores exact Knowledge Authority references with guide ID, version, hash, section, jurisdiction and authority. The v1.x external compliance rule machinery remains only for backwards compatibility.

## Hidden reasoning boundary

No chain-of-thought, scratchpad or unrestricted model reasoning field is introduced. Rewind/Signal payloads use structured factors, evidence IDs/hashes, reason codes and policy references.
