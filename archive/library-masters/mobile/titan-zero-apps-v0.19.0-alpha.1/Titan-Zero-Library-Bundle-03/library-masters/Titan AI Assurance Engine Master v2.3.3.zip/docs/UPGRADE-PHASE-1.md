# Titan Assurance Engine v1.6.0 — Upgrade Phase 1

## Purpose

Phase 1 establishes the security, tenancy, persistence, evidence-integrity and service-contract foundation required before moving ModelCouncil execution into the full assurance pipeline.

## Security changes

The legacy accept-response controller previously deleted sibling messages by `shared_uuid`. It now:

1. requires authentication;
2. scopes the target to the authenticated user;
3. enforces company ownership when the record has company provenance;
4. requires a non-null `assurance_run_uuid` or `shared_uuid`;
5. never deletes alternative candidates;
6. marks the accepted candidate explicitly;
7. records actor and timestamp;
8. logs a security-relevant selection event;
9. uses web CSRF protection plus request throttling.

Legacy rows with no company provenance remain user-scoped for backwards compatibility. They are not silently assigned to a company during selection.

## Audit preservation

The ModelCouncil service no longer deletes:

- failed council placeholder messages;
- persisted council candidate rows before saving;
- shared source messages after synthesis.

Source message IDs are retained in council audit metadata.

## New assurance data model

- `assurance_runs`
- `assurance_candidates`
- `assurance_findings`
- `assurance_approvals`
- `assurance_outcomes`
- `assurance_events`

New ownership fields are guarded from mass assignment.

## Evidence integrity

`EvidencePacketService` recursively normalizes evidence and hashes the canonical packet with SHA-256. Once an assurance run has an evidence hash, a different packet cannot replace it; callers must create a new run.

Secrets are redacted before a packet is persisted through the new assurance service.

## Risk foundation

`RiskClassificationService` supplies a deterministic initial mapping to:

- Green / Amber / Red / Critical
- Standard / High / Critical assurance mode
- automation permission
- required human role

Thresholds are configurable under `model-council.assurance.risk`.

## Next implementation phase

1. extract provider adapters from `ModelCouncilService`;
2. add `ModelCapabilityRegistry`;
3. queue candidate execution and remove DB polling from web workers;
4. enforce panel/model-family/provider independence rules;
5. persist exact provider/model/snapshot identity for every candidate;
6. introduce structured output validation and deterministic policy checks;
7. add disagreement classification and adversarial challenge;
8. implement transparent assurance scoring and fail-closed action permissions;
9. add cost estimation/reservation/reconciliation and budgets;
10. expose run/status/approval/outcome API contracts;
11. add complete feature, security, migration and adapter contract tests.
