# Titan Assurance Engine v1.7 Execution & Assurance Pipeline Design

## Goal

Extend ModelCouncil v1.6.0 into a queued, company-scoped assurance execution pipeline while preserving the existing `ModelCouncil` technical identity and AIChatPro compatibility surface.

## Architecture

`ModelCouncilService` remains the compatibility facade. New assurance behavior lives in focused services under `System/Services/Assurance`, with provider-specific request/response logic isolated behind `AssuranceProviderAdapter`. HTTP-facing creation remains short-lived: create/lock a run, reserve budget, persist candidate work, dispatch queue jobs, and return. Evaluation operates from persisted state rather than tight request-worker polling.

## Core invariants

- `company_id` is the tenant boundary for all new operational assurance records.
- `user_id` is actor identity, never tenant identity.
- Candidate evidence and minority opinions are retained; assurance does not delete alternatives.
- Locked evidence is immutable and identified by SHA-256.
- Confidence alone never authorizes an external action.
- High and Critical assurance require model-family independence; Critical prefers cross-provider diversity.
- High and Critical modes require adversarial challenge and human approval.
- Cost is estimated/reserved before external provider execution and reconciled from recorded usage.
- The queue path is idempotent and safe to retry.
- Existing ModelCouncil routes/settings/history remain compatible.

## Components

### Capability and identity
`ModelCapabilityRegistry` stores normalized provider/model capabilities and model-family metadata. `ModelIdentityResolver` resolves provider, model, family, snapshot and capability metadata for every candidate.

### Provider adapters
Six adapters support OpenAI, Anthropic, Gemini, DeepSeek, xAI and OpenRouter. A registry selects an adapter by provider/model. Adapters expose normalized request construction, response parsing and retry classification. Network dispatch is injected through a provider transport contract so orchestration can be tested without live calls.

### Pipeline
`PanelSelectionService` selects/validates a policy-compliant panel. `AssuranceRunOrchestrator` creates candidate records, reserves estimated budget and dispatches candidate jobs. `CandidateExecutionService` performs one candidate attempt and persists normalized output/usage/error state. `StructuredResponseValidator` and `DeterministicValidationPipeline` produce findings. `DisagreementAnalyzer` identifies material conflicts. `AdversarialChallengeService` creates challenge work where policy requires it. `AssuranceScoringService` computes transparent component scores. `PermissionGateService` derives a fail-closed permission state and human-review requirements.

### Queue lifecycle
- Run status: pending -> queued -> running -> evaluating -> awaiting_human_approval / assured / assured_with_conditions / failed / policy_blocked.
- Candidate status: pending -> queued -> running -> completed / failed / retryable_failed / cancelled.
- Candidate jobs are unique per candidate id and short-circuit completed/cancelled work.
- Evaluation runs only after terminal candidate state has been persisted.

### Cost controls
`CostEstimator`, `CostReservationService` and `CostReconciler` persist estimated/reserved/actual cost on the assurance run. The initial implementation provides deterministic internal accounting hooks and blocks when an explicitly supplied company budget ceiling is insufficient. It does not invent a dependency on an unknown MagicAI billing API.

## Error handling

Provider errors are normalized into retryable, rate-limited, authentication, policy, malformed-response and terminal categories. Jobs use bounded retry/backoff only for retryable classes. Partial panel failure can continue only when the mode's minimum candidate and diversity policy remains satisfiable; otherwise the run fails closed.

## Testing

Because this extension has no standalone Composer/PHPUnit harness, v1.7 adds self-contained PHP unit-style tests for pure services and structural contract tests that can run without booting the host application, plus syntax validation for every PHP file. Host-integrated Laravel tests are documented for execution in the MagicAI application repository.

## Compatibility

No existing ModelCouncil tables are removed. Existing `ModelCouncilService` public methods remain available. New pipeline code is additive. The service provider registers assurance-core services even when AIChatPro is absent, while AIChatPro-specific views/routes remain conditionally booted.
