# Governance

Assurance answers evidence justification only. It never grants independent authority and never executes business mutations. Cross-domain writes are forbidden. Offline operation may collect/prepare evidence but cannot increase authority. Calibration and reason codes are auditable, versioned and outcome-grounded.
