# Titan Assurance Architecture

Titan Assurance is the canonical owner of evidence-backed assurance state. It evaluates how strongly evidence supports a proposed decision or action. Titan Risk owns danger/exposure, Titan Autonomy owns independent authority, Titan Command Bus owns governed mutation execution, and domain systems own business truth. The legacy ModelCouncil technical folder and legacy council/risk/permission paths are retained only for compatibility and are non-canonical.

Canonical path: evidence -> normalization -> weighting -> contradiction/freshness analysis -> GREEN/AMBER/RED assessment -> optional Autonomy projection -> downstream outcome feedback -> calibration. No unrestricted hidden chain-of-thought is persisted.
