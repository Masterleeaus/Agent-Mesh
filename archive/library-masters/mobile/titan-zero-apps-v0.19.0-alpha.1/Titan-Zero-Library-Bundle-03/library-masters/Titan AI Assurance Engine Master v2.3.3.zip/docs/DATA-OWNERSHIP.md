# Data Ownership

Titan Assurance owns assurance evidence records, assessments, feedback/calibration and legacy compatibility audit records. It does not own CRM/domain truth, Risk, Autonomy, Model Council deliberation, Shield verification, Knowledge Authority source truth or Command Bus execution. `user_openai_chat_messages` is shared legacy host state and must not become Assurance-owned domain truth.
