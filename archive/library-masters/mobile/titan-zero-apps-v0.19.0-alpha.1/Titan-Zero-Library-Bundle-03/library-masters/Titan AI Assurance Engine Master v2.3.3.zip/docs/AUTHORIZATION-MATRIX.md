# Authorization Matrix

`assurance.evaluate`: authenticated tenant actor/service with `titan.assurance.evaluate`. `assurance.feedback.record`: authorized outcome/calibration producer with `titan.assurance.feedback`. `assurance.evidence.collect.request`: authorized workflow initiator with `titan.assurance.evidence.request`. Super Admin bypass follows host policy; tenant boundaries remain enforced.
