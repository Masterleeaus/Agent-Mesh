# Titan Assurance Engine v2.1 — Live Integration Contract

## Canonical responsibility

Titan Assurance measures evidence support. It never grants execution authority.

## Titan Autonomy bridge

When Titan Autonomy v1.10 is installed and `model-council.assurance.integration.autonomy.enabled` is true, Titan Assurance binds the external contracts:

- `App\Extensions\TitanAutonomy\System\Contracts\AssuranceBridgeContract`
- `App\Extensions\TitanAutonomy\System\Contracts\TenantAssuranceBridgeContract`

Both bridges resolve canonical records from `assurance_assessments`.

### Projection semantics

A current, calibrated GREEN assessment is projected as the compatibility decision `approved`. This is evidence eligibility only.

Every projection declares:

```text
authority_granted = false
authority_owner = Titan Autonomy
assurance_semantics = evidence_support_only
```

Titan Autonomy must still apply its own lifecycle, eligibility, human-grant, risk, recency, model-transition and offline rules.

## Resolution key

Where available, selection is scoped by:

```text
company_id
+ capability
+ workflow_key
```

An explicit assessment/evaluation reference may be used to resolve a known assessment.

## Freshness

`assurance.integration.autonomy.max_assessment_age_minutes` limits how long a stored assessment is valid for an Autonomy decision. Default: 60 minutes.

Expired evidence support is not projected as approved.

## Miscalibration

When the assessment/cohort reports active miscalibration:

- `calibrated=false`
- reason code `ASSURANCE_MISCALIBRATION_ACTIVE`

Assurance reports the state but does not mutate Autonomy policy.

## Receiver capability status

Titan Signal, Rewind, Wisdom and Knowledge Authority packages available during this build expose health/readiness manager contracts only. AI Core v0.2 exposes orchestration/plan validation but no Assurance-miscalibration receiver.

Therefore the v2 generic outbound sink/reference boundaries remain in place, but no direct receiver write is claimed for those engines.

## Interaction Engine

Evidence gaps continue to emit/request the structured workflow key:

`assurance.evidence.collect`

A direct Interaction Engine adapter is intentionally not implemented until its concrete runtime source/API is available to verify against.
