# Titan Assurance Engine v1.9 Streaming, Compliance Sources & Outcome Intelligence Design

## Goal

Complete provider-path convergence by moving legacy ModelCouncil streaming onto the shared Assurance provider architecture, add a secure contract for externally maintained compliance rule sources, and add company-scoped cross-run outcome intelligence without allowing analytics to weaken fail-closed policy.

## Compatibility constraints

- Preserve extension technical identity `ModelCouncil` and existing namespaces.
- Preserve existing AIChatPro SSE event names and payload shapes.
- Preserve v1.8 Assurance HTTP endpoints and additive database migration history.
- Preserve fail-closed `permission_state`; analytics and external rule sources cannot directly grant permission.
- Preserve company isolation. Caller-supplied tenant/company identifiers are never trusted.
- Do not bundle jurisdiction-specific legal/compliance rules whose currency cannot be verified in the host environment.

## Architecture

### 1. Streaming provider convergence

Introduce a provider-neutral streaming boundary beside the existing non-streaming gateway:

- `AssuranceStreamingProviderTransport` accepts the provider key, model id, built request and a chunk callback.
- `StreamingProviderExecutionGateway` resolves the existing `AssuranceProviderAdapter`, builds requests through the adapter, delegates transport, normalizes final usage, and returns the same canonical provider envelope as `ProviderExecutionGateway`.
- `MagicAIHttpStreamingProviderTransport` owns network streaming and provider stream-frame decoding. It uses `MagicAIProviderRequestFactory` for endpoint and credential resolution.
- `ModelCouncilService::streamParallelModelResponses()` becomes a compatibility façade that emits existing AIChatPro SSE events while delegating provider execution to `StreamingProviderExecutionGateway`.

A provider that cannot stream may return a complete response through the streaming contract as a single chunk. This keeps compatibility without restoring a second request stack.

The legacy shared-message wait loop must be removed. `streamCouncilSummaryFromShared()` performs one bounded database snapshot/read of available source messages. Missing source messages are represented as missing candidates; the web worker does not sleep/poll waiting for them.

### 2. Authoritative compliance rule-source contract

Add a source layer above deterministic rule packs:

- `ComplianceRuleSource` returns immutable versioned rule-source documents.
- `ComplianceRuleSourceRegistry` resolves source keys.
- `ComplianceRuleDocumentValidator` verifies required provenance and integrity.
- `ExternalComplianceRulePack` converts a validated document's deterministic declarative rules into the existing `DeterministicRulePack` contract.

Every external document contains:

- `source_key`
- `rule_pack_key`
- `jurisdiction`
- `version`
- `effective_from`
- optional `effective_to`
- `rules`
- `content_hash`
- optional `signature`
- optional `signature_key_id`
- provenance metadata

Validation rules:

- canonical SHA-256 must match `content_hash`;
- expired/not-yet-effective packs fail closed when selected;
- requested jurisdiction must match;
- if a source is configured as signature-required, unsigned documents fail;
- signatures are verified through a pluggable `ComplianceSignatureVerifier` contract;
- no rule-source call may accept caller-controlled company id as authority.

v1.9 does not ship current legal/regulatory claims. It ships the verified ingestion mechanism and keeps v1.8 generic deterministic packs as fallback.

### 3. Cross-run outcome intelligence

Add `AssuranceOutcomeIntelligenceService` for company-scoped descriptive analytics across persisted runs, candidates, findings and outcomes.

Metrics include:

- provider success/failure rate;
- model-family success rate;
- median/mean assurance score by outcome;
- material disagreement frequency;
- deterministic-failure frequency;
- evidence sufficiency distribution;
- rule-pack success rate;
- calibration drift over a configurable recent window versus prior window;
- incomplete-cost-accounting rate.

`AssuranceRecommendationService` may produce advisory recommendations such as "provider X has elevated failure rate" or "rule pack Y shows increased disagreement". Recommendations contain evidence counts and reasons.

Hard boundary: intelligence output has `policy_mutation=false` and is not consumed by `PermissionGateService` as an authority. Human/admin policy changes remain separate explicit actions.

### 4. Persistence and API

Add an additive v1.9 migration for:

- candidate streaming metadata (`streamed`, `stream_chunk_count`, `stream_completed_at`);
- run compliance source metadata (`compliance_source_key`, `compliance_jurisdiction`, `compliance_rule_version`, `compliance_rule_hash`);
- optional outcome-intelligence snapshots table for reproducible historical analytics.

Add company-scoped read-only endpoints:

- `GET /api/titan/assurance/intelligence`
- `GET /api/titan/assurance/intelligence/recommendations`

No endpoint mutates assurance policy in v1.9.

## Error handling

- Streaming HTTP/provider failures retain partial text only as diagnostic evidence; incomplete streams are marked failed and cannot satisfy a candidate requirement.
- Invalid stream frames are ignored only when non-semantic transport noise; malformed provider content that prevents a final canonical response fails the candidate.
- Invalid or expired compliance documents block use of that external rule pack and record a finding/event.
- Intelligence queries return empty metrics for insufficient data rather than invented confidence.

## Testing

Pure PHP tests cover:

- streaming gateway adapter reuse and chunk forwarding;
- streaming fallback single-chunk behavior;
- compliance canonical hashing/effective-date/jurisdiction validation;
- required-signature rejection and verifier delegation;
- declarative external-rule execution;
- outcome intelligence aggregation and drift detection;
- recommendation policy-mutation hard boundary;
- no shared-message polling primitives in the new compatibility path.

Host/Laravel integration remains separately required for live DB migrations, provider credentials/network streams, and CRM/compliance source implementations.


## Implementation clarification — immutable compliance snapshot

Validated external compliance documents are persisted on the assurance run as `compliance_rule_snapshot` together with source, jurisdiction, version and content hash. Evaluation uses the stored snapshot rather than re-fetching mutable source content.
