# Security

All authoritative Assurance records are tenant-scoped by `company_id`. Caller identity and tenant context must be resolved from authenticated context; caller-supplied tenant identifiers are not authority by themselves. Evidence hashes/provenance are retained, secrets are excluded from Signal/Rewind payloads, and unrestricted hidden chain-of-thought is never stored.
