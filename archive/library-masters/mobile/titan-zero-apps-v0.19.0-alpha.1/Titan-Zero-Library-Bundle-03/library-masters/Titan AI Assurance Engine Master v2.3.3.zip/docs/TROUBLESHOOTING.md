# Troubleshooting

If assessments fail, verify migrations, tenant resolution and evidence schema first. If Autonomy projection is unavailable, verify Titan Autonomy contracts are loaded; Assurance evaluation should continue but integration health must degrade. If Signal/Rewind/Wisdom/Knowledge Authority are scaffold-only, treat their sinks as unavailable rather than claiming successful delivery.
