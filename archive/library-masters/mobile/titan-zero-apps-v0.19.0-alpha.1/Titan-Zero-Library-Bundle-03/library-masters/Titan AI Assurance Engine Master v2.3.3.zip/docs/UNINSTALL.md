# Uninstall

Default uninstall policy is preserve-data. Disable new work first, detach optional engine bridges, preserve evidence/assessment/calibration history and never delete shared `user_openai_chat_messages`. Destructive retention actions require an explicit platform-authorized workflow.
