# Upgrade Phase 4 — v1.9 Streaming, Compliance Sources & Intelligence

## Purpose

v1.9 removes the remaining duplicate provider streaming logic from the ModelCouncil compatibility layer, introduces an integrity-checked external compliance-rule boundary, and adds company-scoped cross-run outcome intelligence.

## Staging sequence

1. Back up the MagicAI database and the existing `app/Extensions/ModelCouncil` directory.
2. Install/replace the extension in a staging copy and run normal Laravel extension migrations.
3. Confirm the v1.9 additive migrations add streaming/compliance columns and the intelligence snapshot table without changing v1.6-v1.8 migration files.
4. Start the configured `assurance` Laravel queue worker.
5. Exercise one ModelCouncil AIChatPro request per configured provider and confirm the existing `model_stream_start`, `model_stream_delta`, and `model_stream_end` frontend events still render correctly.
6. Confirm no request worker performs repeated shared-message sleep/query polling.
7. Exercise a Standard assurance run with built-in deterministic rules and verify `permission_state` remains blocked until all required controls pass.
8. If using an external compliance source, bind a `ComplianceRuleSource`, tag it `titan.assurance.compliance_rule_sources`, and validate source/jurisdiction/version/hash provenance in the stored run snapshot.
9. If signed compliance documents are required, bind a real `ComplianceSignatureVerifier`; do not rely on the default null verifier, which rejects signatures.
10. Submit an observed outcome, then call `/calibration`, `/intelligence`, and `/intelligence/recommendations`; verify all data is scoped to the active company.
11. Verify recommendations are advisory only and expose no policy-write endpoint.
12. Confirm provider usage/cost fields and run-level reconciliation correctly retain fallback `effective_cost` where provider-reported cost is absent.

## Compliance source registration

The host owns current legal/regulatory content. A source implementation returns a declarative document containing source identity, rule-pack identity, jurisdiction, version, active dates, rules and canonical SHA-256 hash. Optional signatures are verified through the host-bound verifier.

Never permit a compliance source to return executable PHP, SQL, shell commands or free-form expressions. v1.9 accepts only the built-in deterministic operator allow-list.

## Streaming caveat

The provider architecture is now converged. The bundled MagicAI streaming transport may deliver a complete provider response rather than native token deltas; the gateway then emits a canonical fallback chunk and the compatibility façade emits the legacy SSE events. Validate the actual UX with each live provider before production rollout.

## Rollback

Disable assurance traffic and queue workers, restore the v1.8 extension directory, and roll back only the v1.9 migrations if database rollback is required. Do not delete historical assurance outcomes/evidence outside the migration rollback process.

## Production sign-off

Do not call the release live-certified until you have verified:

- migrations on the real database engine/version
- every configured provider credential/endpoint
- AIChatPro SSE rendering
- queue/retry behavior
- company isolation
- any CRM evidence adapter
- any external compliance source and signature verifier
- cost/pricing configuration
- approval RBAC for High/Critical runs
