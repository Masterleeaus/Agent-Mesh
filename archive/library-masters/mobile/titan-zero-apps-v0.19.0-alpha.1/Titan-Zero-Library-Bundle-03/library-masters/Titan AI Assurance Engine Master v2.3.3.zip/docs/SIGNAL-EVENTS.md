# Signal Events

Titan Assurance v2.3 integrates directly with Titan Signal Engine `0.20.0-rc.3` through its trusted emitter, registry authority, event registry and manager contracts.

## Runtime identity

- Emitter service: `titan-assurance:runtime`
- Registry service: `titan-assurance:registry`
- Owner/source: `titan-assurance`
- Allowed event pattern: `assurance.*`
- Scope: tenant only
- Category: `governance`

The runtime emitter only receives `signal.emit`; the registry identity only receives `signal.registry.event.manage`. Assurance does not receive Signal subscription-management or wildcard event authority.

## Registered event family

- `assurance.assessment.completed`
- `assurance.feedback.recorded`
- `assurance.evidence.recollection.requested`
- `assurance.miscalibration.detected`

All consequential events carry tenant and causal trace context, use stable idempotency keys, and exclude secrets and unrestricted hidden reasoning. Miscalibration uses warning severity; the other lifecycle events are informational.

Signal receipts are persisted into the originating Assurance record. A receiver/configuration failure is recorded as a failed integration receipt and is never represented as successful dispatch.
