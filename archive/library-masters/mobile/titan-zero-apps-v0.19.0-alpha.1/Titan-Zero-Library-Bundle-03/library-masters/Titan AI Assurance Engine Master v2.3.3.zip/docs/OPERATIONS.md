# Operations

Assurance remains operational when optional receiving engines are unavailable, but integration status must report degradation explicitly. Evaluation never silently promotes authority. Queue work is bounded and tenant context is mandatory. Operators should monitor assessment error rate, calibration drift, stale evidence rates and optional bridge health.
