# Upgrade

The v2.2 Blueprint rebase is additive: preserve existing ModelCouncil folder/namespace, migrations, routes, UI and data. New canonical identity is `titan-assurance` in the Installer/Blueprint manifests. Existing v1.9-v2.1 policy/calibration history remains valid; scoring policy version remains `titan-assurance-v2.1` until scoring semantics change.
