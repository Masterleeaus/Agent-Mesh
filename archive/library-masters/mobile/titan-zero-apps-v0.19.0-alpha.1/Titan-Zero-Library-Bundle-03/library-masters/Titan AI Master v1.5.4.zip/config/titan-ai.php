<?php

declare(strict_types=1);

return [
    'enabled' => env('TITAN_AI_ENABLED', true),
    'default_provider' => env('TITAN_AI_PROVIDER', 'magicai-host'),
    'default_model' => env('TITAN_AI_MODEL', null),
    'default_system_prompt' => 'You are Titan Zero, a privacy-aware business operating assistant. Use the same assistant identity, governance and authorised tools across every interface.',
    'memory_message_limit' => 30,
    'temperature' => 0.7,

    // Provider endpoints and credentials are trusted configuration only. Runtime request payloads
    // are never allowed to supply provider endpoints or provider secrets.
    'providers' => [
        'openai' => [
            'driver' => 'openai-compatible',
            'endpoint' => env('TITAN_AI_OPENAI_ENDPOINT', 'https://api.openai.com/v1/chat/completions'),
            'api_key' => env('TITAN_AI_OPENAI_KEY', env('OPENAI_API_KEY')),
            'allowed_hosts' => ['api.openai.com'],
            'timeout' => 120,
        ],
    ],

    // Optional host-owned completion services. A configured service failure is surfaced rather
    // than silently skipped so provider outages cannot masquerade as a different response path.
    'compatible_completion_services' => [],

    'default_capabilities' => ['chat','skills','files','web','research','memory','knowledge','generative-ui'],
    'channel_capabilities' => [
        'aichatpro' => ['chat','skills','files','web','research','memory','knowledge','generative-ui'],
        'chatbot' => ['chat','skills','files','memory','knowledge','generative-ui'],
        'ai-agent' => ['chat','memory','knowledge','web'],
        'ai-agent-copilot' => ['chat'],
        'web' => ['chat','files','memory','knowledge','generative-ui'],
        'mobile' => ['chat','skills','files','memory','knowledge','generative-ui'],
    ],
    'capabilities' => [
        'chat' => ['label' => 'Chat'],
        'skills' => ['label' => 'Skills'],
        'files' => ['label' => 'File context'],
        'web' => ['label' => 'Web research'],
        'research' => ['label' => 'Deep research'],
        'memory' => ['label' => 'Memory'],
        'knowledge' => ['label' => 'Knowledge'],
        'generative-ui' => ['label' => 'Generative UI'],
        'image' => ['label' => 'Image generation'],
    ],

    'workcore' => [
        'enabled' => env('TITAN_AI_WORKCORE_ENABLED', true),
        // Canonical WorkCore (or a thin WorkCore extension adapter) should bind an object implementing
        // read(domain, operation, payload) and execute(domain, operation, payload) to this key.
        'gateway_binding' => env('TITAN_AI_WORKCORE_GATEWAY_BINDING', 'titan.workcore.ai.gateway'),
        'operation_tool_map' => [
            'invoicing.create_invoice' => 'workcore.invoices.create',
            'invoicing.send_invoice' => 'workcore.invoices.send',
            'invoicing.apply_payment' => 'workcore.payments.record',
            'invoicing.create_quote' => 'workcore.quotes.create',
            'jobs.create_job_order' => 'workcore.jobs.book',
            'scheduling.reschedule_appointment' => 'workcore.jobs.reschedule',
            'jobs.cancel_job' => 'workcore.jobs.cancel',
            'jobs.assign_to_technician' => 'workcore.dispatch.assign_worker',
            'field_ops.optimize_route' => 'workcore.routes.optimise',
            'jobs.complete_job' => 'workcore.jobs.complete',
            'crm.create_contact' => 'workcore.customers.create',
            'crm.update_contact' => 'workcore.customers.update',
            'inventory.adjust_stock' => 'workcore.inventory.adjust',
            'field_ops.record_incident' => 'workcore.incidents.record',
        ],

        // Rollback is fail-closed. Add a source operation only when canonical WorkCore has
        // a verified compensating operation. Targets may be `domain.operation` strings or
        // ['domain' => '...', 'operation' => '...'] definitions and must also exist above.
        'rollback_operation_map' => [],
    ],

    // Kernel intents are vertical-neutral. Product/vertical extensions can contribute additional
    // definitions at runtime through IntentDefinitionRegistry::register().
    'intents' => [
        'create_invoice' => ['patterns'=>['create invoice','create an invoice','make invoice','generate invoice'],'manager'=>'finance-manager','assistant'=>'invoicing-assistant','agent'=>'create-invoice-agent','domain'=>'invoicing','operation'=>'create_invoice','risk'=>'amber','permissions'=>['jobs.read','invoices.create']],
        'send_invoice' => ['patterns'=>['send invoice','email invoice'],'manager'=>'finance-manager','assistant'=>'invoicing-assistant','agent'=>'send-invoice-agent','domain'=>'invoicing','operation'=>'send_invoice','risk'=>'red','permissions'=>['invoices.read','invoices.send']],
        'record_payment' => ['patterns'=>['record payment','mark paid','cash payment'],'manager'=>'finance-manager','assistant'=>'payments-assistant','agent'=>'record-payment-agent','domain'=>'invoicing','operation'=>'apply_payment','risk'=>'critical','permissions'=>['invoices.read','payments.create']],
        'create_quote' => ['patterns'=>['create quote','make quote','prepare quote'],'manager'=>'sales-manager','assistant'=>'quoting-assistant','agent'=>'create-quote-agent','domain'=>'invoicing','operation'=>'create_quote','risk'=>'amber','permissions'=>['customers.read','quotes.create']],
        'book_job' => ['patterns'=>['book job','book a job','create booking','create a booking','schedule job','schedule a job'],'manager'=>'operations-manager','assistant'=>'scheduling-assistant','agent'=>'book-job-agent','domain'=>'jobs','operation'=>'create_job_order','risk'=>'amber','permissions'=>['customers.read','jobs.create']],
        'reschedule_job' => ['patterns'=>['reschedule job','move booking','change appointment'],'manager'=>'operations-manager','assistant'=>'scheduling-assistant','agent'=>'reschedule-job-agent','domain'=>'scheduling','operation'=>'reschedule_appointment','risk'=>'amber','permissions'=>['jobs.read','schedules.update']],
        'cancel_job' => ['patterns'=>['cancel job','cancel booking','cancel appointment'],'manager'=>'operations-manager','assistant'=>'scheduling-assistant','agent'=>'cancel-job-agent','domain'=>'jobs','operation'=>'cancel_job','risk'=>'red','permissions'=>['jobs.read','jobs.cancel']],
        'assign_worker' => ['patterns'=>['assign worker','assign a worker','assign technician','dispatch worker'],'manager'=>'field-staff-manager','assistant'=>'dispatch-assistant','agent'=>'assign-worker-agent','domain'=>'jobs','operation'=>'assign_to_technician','risk'=>'amber','permissions'=>['jobs.read','workers.read','jobs.assign']],
        'optimise_route' => ['patterns'=>['optimise route','optimize route','plan route'],'manager'=>'operations-manager','assistant'=>'route-planning-assistant','agent'=>'optimise-route-agent','domain'=>'field_ops','operation'=>'optimize_route','risk'=>'green','permissions'=>['jobs.read','routes.update']],
        'complete_job' => ['patterns'=>['complete job','mark job complete','finish job'],'manager'=>'operations-manager','assistant'=>'quality-inspection-assistant','agent'=>'mark-job-complete-agent','domain'=>'jobs','operation'=>'complete_job','risk'=>'amber','permissions'=>['jobs.read','jobs.complete']],
        'create_customer' => ['patterns'=>['create customer','add customer','new customer'],'manager'=>'customer-manager','assistant'=>'customer-service-assistant','agent'=>'create-customer-agent','domain'=>'crm','operation'=>'create_contact','risk'=>'green','permissions'=>['customers.create']],
        'update_customer' => ['patterns'=>['update customer','edit customer'],'manager'=>'customer-manager','assistant'=>'customer-service-assistant','agent'=>'update-customer-agent','domain'=>'crm','operation'=>'update_contact','risk'=>'green','permissions'=>['customers.read','customers.update']],
        'update_stock' => ['patterns'=>['update stock','adjust stock','change inventory'],'manager'=>'supplies-equipment-manager','assistant'=>'inventory-assistant','agent'=>'update-stock-agent','domain'=>'inventory','operation'=>'adjust_stock','risk'=>'amber','permissions'=>['inventory.read','inventory.update']],
        'record_incident' => ['patterns'=>['record incident','report incident','safety incident'],'manager'=>'quality-safety-manager','assistant'=>'safety-compliance-assistant','agent'=>'record-incident-agent','domain'=>'field_ops','operation'=>'record_incident','risk'=>'red','permissions'=>['jobs.read','incidents.create']],
    ],
    'legacy_field_service_intent_aliases' => [
        'book_job' => ['schedule cleaning','schedule a cleaning','book cleaning','book a cleaning'],
        'assign_worker' => ['assign cleaner','assign a cleaner','dispatch cleaner','dispatch a cleaner'],
    ],
];
