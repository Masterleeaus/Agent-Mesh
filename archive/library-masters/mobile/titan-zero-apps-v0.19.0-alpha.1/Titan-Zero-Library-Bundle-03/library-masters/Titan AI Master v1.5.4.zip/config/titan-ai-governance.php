<?php

declare(strict_types=1);

return [
    'enabled' => env('TITAN_AI_GOVERNANCE_ENABLED', true),
    'workcore_authoritative' => true,
    'minimum_confidence' => 70,
    'reviewers' => [
        ['model' => env('TITAN_COUNCIL_PRIMARY_REVIEWER', env('TITAN_AI_MODEL', 'gpt-4o-mini')), 'role' => 'fact_verifier'],
        ['model' => env('TITAN_COUNCIL_SECONDARY_REVIEWER', env('TITAN_AI_MODEL', 'gpt-4o-mini')), 'role' => 'risk_auditor'],
    ],
    'risk' => [
        'green' => ['reviewers' => 0, 'human_approval' => false],
        'amber' => ['reviewers' => 1, 'human_approval' => false],
        'red' => ['reviewers' => 2, 'human_approval' => false],
        'critical' => ['reviewers' => 2, 'human_approval' => true],
    ],
    'provider' => env('TITAN_COUNCIL_PROVIDER', 'openai'),
    'max_cost_per_review' => 0.25,
    'model_pricing' => [],
    'memory' => [
        'reflection_is_authoritative' => false,
        'default_ttl_seconds' => 2592000,
        // Current governed-memory JSON persistence is not application-layer encrypted.
        // Keep sensitive personal memory disabled at product level unless a vault/encrypted repository is supplied.
        'personal_data_encrypted' => false,
    ],
];
