<?php

declare(strict_types=1);

use App\Extensions\TitanAI\System\Governance\Http\Controllers\GovernanceApprovalController;
use App\Extensions\TitanAI\System\Governance\Http\Controllers\GovernanceConfigurationController;
use App\Extensions\TitanAI\System\Governance\Http\Controllers\GovernanceRollbackController;
use Illuminate\Support\Facades\Route;

Route::prefix('governance')->name('governance.')->group(function(): void {
    Route::get('/configuration',[GovernanceConfigurationController::class,'index'])->name('configuration.index');
    Route::get('/approvals',[GovernanceApprovalController::class,'index'])->name('approvals.index');
    Route::post('/approvals/{approvalId}/approve',[GovernanceApprovalController::class,'approve'])->name('approvals.approve');
    Route::post('/approvals/{approvalId}/reject',[GovernanceApprovalController::class,'reject'])->name('approvals.reject');
    Route::post('/receipts/{receiptId}/rollback',[GovernanceRollbackController::class,'store'])->name('receipts.rollback');
});
