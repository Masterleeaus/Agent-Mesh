<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(): void { if(Schema::hasTable('titan_ai_approval_requests')&&!Schema::hasColumn('titan_ai_approval_requests','idempotency_key')) Schema::table('titan_ai_approval_requests',fn(Blueprint $t)=>$t->string('idempotency_key')->nullable()->index()); } public function down(): void {} };
