<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(): void {
if(Schema::hasTable('titan_ai_approval_requests')) { if(!Schema::hasColumn('titan_ai_approval_requests','execution_attempts'))Schema::table('titan_ai_approval_requests',fn(Blueprint $t)=>$t->unsignedInteger('execution_attempts')->default(0)); if(!Schema::hasColumn('titan_ai_approval_requests','execution_started_at'))Schema::table('titan_ai_approval_requests',fn(Blueprint $t)=>$t->timestamp('execution_started_at')->nullable()); if(!Schema::hasColumn('titan_ai_approval_requests','last_execution_error'))Schema::table('titan_ai_approval_requests',fn(Blueprint $t)=>$t->text('last_execution_error')->nullable()); }
if(Schema::hasTable('titan_ai_action_receipts')&&!Schema::hasColumn('titan_ai_action_receipts','failure_reason'))Schema::table('titan_ai_action_receipts',fn(Blueprint $t)=>$t->text('failure_reason')->nullable()); }
public function down(): void {} };
