<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(): void { if(!Schema::hasTable('titan_ai_action_receipts'))return; $cols=['device_id','manager_id','assistant_id','agent_id','conversation_id','workflow_id','channel','idempotency_key']; foreach($cols as $c) if(!Schema::hasColumn('titan_ai_action_receipts',$c)) Schema::table('titan_ai_action_receipts',fn(Blueprint $t)=>$t->string($c)->nullable()->index()); } public function down(): void {} };
