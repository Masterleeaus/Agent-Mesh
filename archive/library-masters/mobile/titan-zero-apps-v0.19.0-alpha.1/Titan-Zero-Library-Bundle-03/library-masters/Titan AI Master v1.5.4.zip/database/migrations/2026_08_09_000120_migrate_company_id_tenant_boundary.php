<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /** @var list<string> */
    private array $tables = [
        'titan_ai_approval_requests',
        'titan_ai_action_receipts',
        'titan_ai_governed_memories',
        'titan_ai_persona_assignments',
        'titan_ai_governed_skills',
        'titan_ai_tool_permissions',
        'titan_ai_skill_evaluations',
    ];

    public function up(): void
    {
        foreach ($this->tables as $table) {
            if (! Schema::hasTable($table)) {
                continue;
            }

            $hasLegacyBoundary = Schema::hasColumn($table, 'tenant_id');
            $hasCompanyBoundary = Schema::hasColumn($table, 'company_id');

            if ($hasLegacyBoundary && $hasCompanyBoundary) {
                throw new \RuntimeException("TitanAI company-boundary migration found both tenant_id and company_id on [{$table}]. Resolve the ambiguous schema before continuing.");
            }

            if ($hasCompanyBoundary) {
                continue;
            }

            if (! $hasLegacyBoundary) {
                throw new \RuntimeException("TitanAI table [{$table}] has no company_id boundary column.");
            }

            $this->assertLegacyValuesAreValidCompanyIds($table);

            Schema::table($table, static function (Blueprint $blueprint): void {
                $blueprint->unsignedBigInteger('company_id')->nullable()->index();
            });

            $this->copyLegacyValuesToCompanyId($table);

            if (DB::table($table)->whereNull('company_id')->exists()) {
                throw new \RuntimeException("TitanAI table [{$table}] still contains records without company_id after conversion.");
            }

            Schema::table($table, static function (Blueprint $blueprint): void {
                $blueprint->dropColumn('tenant_id');
            });

            Schema::table($table, static function (Blueprint $blueprint): void {
                $blueprint->unsignedBigInteger('company_id')->nullable(false)->change();
            });
        }
    }

    public function down(): void
    {
        // Forward-only migration. Reintroducing tenant_id would weaken the canonical company boundary.
    }

    private function assertLegacyValuesAreValidCompanyIds(string $table): void
    {
        $this->eachLegacyBoundaryValue($table, static function (mixed $value) use ($table): void {
            $normalised = is_scalar($value) ? trim((string) $value) : '';
            if ($normalised === '' || ! ctype_digit($normalised) || (int) $normalised < 1) {
                throw new \RuntimeException("TitanAI table [{$table}] contains a tenant_id value that cannot be converted to a positive company_id.");
            }
        });
    }

    private function copyLegacyValuesToCompanyId(string $table): void
    {
        $this->eachLegacyBoundaryValue($table, static function (mixed $value) use ($table): void {
            $normalised = trim((string) $value);
            DB::table($table)
                ->where('tenant_id', $value)
                ->update(['company_id' => (int) $normalised]);
        });
    }

    /** @param callable(mixed):void $callback */
    private function eachLegacyBoundaryValue(string $table, callable $callback): void
    {
        DB::table($table)
            ->select('tenant_id')
            ->distinct()
            ->orderBy('tenant_id')
            ->chunk(500, function ($rows) use ($callback): void {
                foreach ($rows as $row) {
                    $callback($row->tenant_id ?? null);
                }
            });
    }
};
