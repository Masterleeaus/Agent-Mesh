<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(): void {
if(Schema::hasTable('titan_ai_approval_requests')) { foreach(['domain','tool_definition','execution_context'] as $c) if(!Schema::hasColumn('titan_ai_approval_requests',$c)) Schema::table('titan_ai_approval_requests',function(Blueprint $t) use($c){ if($c==='domain')$t->string('domain')->default('')->index(); else $t->json($c)->nullable(); }); }
if(Schema::hasTable('titan_ai_action_receipts')) { foreach(['rollback_result','rolled_back_by','rolled_back_at'] as $c) if(!Schema::hasColumn('titan_ai_action_receipts',$c)) Schema::table('titan_ai_action_receipts',function(Blueprint $t) use($c){ if($c==='rollback_result')$t->json($c)->nullable(); elseif($c==='rolled_back_at')$t->timestamp($c)->nullable(); else $t->string($c)->nullable()->index(); }); } }
public function down(): void {} };
