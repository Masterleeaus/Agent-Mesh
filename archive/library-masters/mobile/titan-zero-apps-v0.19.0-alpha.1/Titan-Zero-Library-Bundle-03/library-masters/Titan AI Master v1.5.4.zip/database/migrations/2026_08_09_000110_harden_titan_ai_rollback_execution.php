<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('titan_ai_action_receipts')) return;
        if (! Schema::hasColumn('titan_ai_action_receipts', 'rollback_attempts')) {
            Schema::table('titan_ai_action_receipts', fn (Blueprint $table) => $table->unsignedInteger('rollback_attempts')->default(0));
        }
        if (! Schema::hasColumn('titan_ai_action_receipts', 'rollback_started_at')) {
            Schema::table('titan_ai_action_receipts', fn (Blueprint $table) => $table->timestamp('rollback_started_at')->nullable());
        }
        if (! Schema::hasColumn('titan_ai_action_receipts', 'rollback_failure_reason')) {
            Schema::table('titan_ai_action_receipts', fn (Blueprint $table) => $table->text('rollback_failure_reason')->nullable());
        }
    }

    public function down(): void {}
};
