<?php
$root = dirname(__DIR__,2); $r=file_get_contents($root.'/PASS-COMPANY-ID-PERSISTENCE-CONVERGENCE.md'); if(!$r || !str_contains($r,'company_id')) exit(1); echo "COMPANY_ID_PERSISTENCE_CONVERGENCE: PASS\n";
