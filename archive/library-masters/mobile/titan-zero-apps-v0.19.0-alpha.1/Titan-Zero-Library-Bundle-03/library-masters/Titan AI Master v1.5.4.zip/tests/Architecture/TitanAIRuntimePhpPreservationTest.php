<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$expected = json_decode((string) file_get_contents($root.'/tests/fixtures/titan-ai-1.5.2-php-sha256.json'), true, 512, JSON_THROW_ON_ERROR);
$actual = [];
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($iterator as $file) {
    if (! $file->isFile() || strtolower($file->getExtension()) !== 'php') {
        continue;
    }
    $path = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
    // Compatibility tests themselves are release evidence, not supplied runtime PHP.
    if (str_starts_with($path, 'tests/')) {
        continue;
    }
    $actual[$path] = hash_file('sha256', $file->getPathname());
}
ksort($actual);
ksort($expected);
if ($actual !== $expected) {
    $missing = array_keys(array_diff_key($expected, $actual));
    $added = array_keys(array_diff_key($actual, $expected));
    $changed = [];
    foreach (array_intersect_key($actual, $expected) as $path => $hash) {
        if ($hash !== $expected[$path]) $changed[] = $path;
    }
    fwrite(STDERR, "Titan AI Runtime PHP preservation: FAIL\n");
    fwrite(STDERR, 'missing='.count($missing).' added='.count($added).' changed='.count($changed)."\n");
    if ($changed) fwrite(STDERR, 'changed: '.implode(', ', array_slice($changed,0,20))."\n");
    exit(1);
}
echo 'Titan AI Runtime PHP preservation: PASS ('.count($actual)."/".count($expected).")\n";
