<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$extension = json_decode((string) file_get_contents($root.'/extension.json'), true, 512, JSON_THROW_ON_ERROR);
$manifest = json_decode((string) file_get_contents($root.'/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);

$failures = [];
$expect = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) {
        $failures[] = $message;
    }
};

$expect(($extension['slug'] ?? null) === 'titan-ai', 'extension.json slug must remain titan-ai');
$expect(($extension['version'] ?? null) === '1.5.4', 'extension.json must declare Titan AI Runtime 1.5.4');
$expect(($manifest['key'] ?? null) === 'titan-ai', 'extension.manifest.json key must remain titan-ai');
$expect(($manifest['version'] ?? null) === '1.5.4', 'extension.manifest.json must declare Titan AI Runtime 1.5.4');

$runtimeContract = (string) file_get_contents($root.'/System/TitanAI/Contracts/TitanAIRuntimeContract.php');
$requestDto = (string) file_get_contents($root.'/System/TitanAI/DTO/TitanAIRequest.php');
$responseDto = (string) file_get_contents($root.'/System/TitanAI/DTO/TitanAIResponse.php');
$runtime = (string) file_get_contents($root.'/System/TitanAI/Runtime/UnifiedTitanAIRuntime.php');
$providerRegistry = (string) file_get_contents($root.'/System/Providers/ProviderExecutionRegistry.php');
$deploymentResolver = (string) file_get_contents($root.'/System/TitanAI/Deployments/AssistantDeploymentResolver.php');
$runtimeProvider = (string) file_get_contents($root.'/System/TitanAI/Runtime/TitanAIRuntimeServiceProvider.php');

$expect(str_contains($runtimeContract, 'function execute(TitanAIRequest $request): TitanAIResponse'), 'runtime contract execute() seam missing');
$expect(str_contains($runtimeContract, 'function stream(TitanAIRequest $request, callable $emit): TitanAIResponse'), 'runtime contract stream() seam missing');
foreach (['companyId', 'workflowId', 'idempotencyKey', 'responseMode', 'toolPermissions', 'actorType', 'actorId'] as $field) {
    $expect(str_contains($requestDto, '$'.$field), 'request DTO missing '.$field);
}
$expect(str_contains($responseDto, "'run_uuid' => \$this->runUuid"), 'response DTO must expose run_uuid through toArray()');
$expect(str_contains($runtime, 'implements TitanAIRuntimeContract'), 'UnifiedTitanAIRuntime must implement TitanAIRuntimeContract');
$expect(str_contains($providerRegistry, 'function resolve(?string $providerId): ProviderExecutionGatewayContract'), 'provider execution registry resolve() contract missing');
$expect(str_contains($deploymentResolver, "'provider' =>"), 'deployment resolver provider contract missing');
$expect(str_contains($deploymentResolver, "'model' =>"), 'deployment resolver model contract missing');
$expect(str_contains($runtimeProvider, 'TitanAIRuntimeContract::class'), 'runtime service provider must bind TitanAIRuntimeContract');

if ($failures !== []) {
    fwrite(STDERR, "Titan AI Runtime 1.5.4 compatibility contract: FAIL\n - ".implode("\n - ", $failures)."\n");
    exit(1);
}

echo "Titan AI Runtime 1.5.4 compatibility contract: PASS\n";
