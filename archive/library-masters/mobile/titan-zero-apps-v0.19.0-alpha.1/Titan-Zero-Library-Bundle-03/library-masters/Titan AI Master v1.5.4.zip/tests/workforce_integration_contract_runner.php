<?php
declare(strict_types=1);
function assert_true(bool $v, string $m): void { if (!$v) { fwrite(STDERR, $m . PHP_EOL); exit(1); } }
$root = dirname(__DIR__);
$path = $root . '/workforce-integration.json';
$data = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
assert_true(($data['schema'] ?? null) === 'titan.workforce.integration.v1', 'Bad Workforce integration schema.');
assert_true(($data['tenant_boundary']['canonical_key'] ?? null) === 'company_id', 'company_id must be canonical.');
assert_true(($data['ownership']['active_extension_employee_identity'] ?? true) === false, 'Extension employee identity must be inactive.');
assert_true(($data['governance']['installed_implies_available'] ?? true) === false, 'Install must not imply availability.');
assert_true(($data['governance']['available_implies_authorized'] ?? true) === false, 'Availability must not imply authority.');
assert_true(($data['governance']['fail_closed'] ?? false) === true, 'Availability must fail closed.');
$states = $data['availability']['states'] ?? [];
foreach (["available", "degraded", "unavailable", "missing_provider", "blocked", "policy_disabled"] as $state) assert_true(in_array($state, $states, true), 'Missing availability state: ' . $state);
assert_true(($data['provenance']['provider_version_required'] ?? false) === true, 'Provider version provenance required.');
assert_true(($data['provenance']['ambiguous_unpinned_execution_allowed'] ?? true) === false, 'Unpinned executable work must be forbidden.');

$registry = $root . '/System/AI/Registry/TitanAIWorkerRegistry.php';
require_once $registry;
$tiers = \App\Extensions\TitanAI\System\AI\Registry\TitanAIWorkerRegistry::byTier();
assert_true(!isset($tiers[1]) && !isset($tiers[2]), 'Organisational manager/specialist tiers must not be active runtime identity.');
assert_true(isset($tiers[3]) && count($tiers[3]) > 0, 'Atomic runtime executors must remain published.');

fwrite(STDOUT, 'WORKFORCE_INTEGRATION_CONTRACT: PASS' . PHP_EOL);
