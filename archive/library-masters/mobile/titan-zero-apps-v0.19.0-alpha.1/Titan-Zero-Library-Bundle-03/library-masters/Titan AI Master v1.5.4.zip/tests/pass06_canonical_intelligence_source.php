<?php
declare(strict_types=1);
$root=dirname(__DIR__); require_once $root.'/System/Providers/CostSovereigntyInferenceGuard.php';
use App\Extensions\TitanAI\System\Providers\CostSovereigntyInferenceGuard;
$r=new ReflectionClass(CostSovereigntyInferenceGuard::class);
$m=$r->getMethod('canonicalExternalRoute');$m->setAccessible(true);$o=$r->newInstanceWithoutConstructor();
$checks=['byo_cloud'=>'byo_api','BYO'=>'byo_api','titan_private_ai'=>'titan_entitled','TITAN_SYSTEM_AI'=>'titan_entitled'];$f=0;
foreach($checks as$in=>$want){try{$got=$m->invoke($o,$in,false);if($got!==$want){$f++;fwrite(STDERR,"FAIL $in\n");}}catch(Throwable$e){$f++;fwrite(STDERR,"FAIL $in {$e->getMessage()}\n");}}
try{$m->invoke($o,'browser_ai',false);$f++;fwrite(STDERR,"FAIL browser must not use external gateway\n");}catch(Throwable $e){}
if($f)exit(1);echo "PASS Titan AI canonical intelligence source\n";
