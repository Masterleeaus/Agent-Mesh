<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$path = $root.'/resources/runtime-compatibility.json';
if (! is_file($path)) {
    fwrite(STDERR, "Titan AI runtime compatibility registry: FAIL\n - resources/runtime-compatibility.json is missing\n");
    exit(1);
}

$data = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
$expectedSchema = 'titan-ai-runtime-compatibility-v1';
$expected = [
    'package' => ['slug' => 'titan-ai', 'version' => '1.5.4'],
    'workforce' => ['minimum_version' => '1.5.4', 'agent_runtime_protocol' => 'titan.agent-runtime/1'],
    'runtime' => [
        'contract' => 'App\\Extensions\\TitanAI\\System\\TitanAI\\Contracts\\TitanAIRuntimeContract',
        'request' => 'App\\Extensions\\TitanAI\\System\\TitanAI\\DTO\\TitanAIRequest',
        'response' => 'App\\Extensions\\TitanAI\\System\\TitanAI\\DTO\\TitanAIResponse',
    ],
    'provider' => [
        'profiles' => 'App\\Extensions\\TitanAI\\System\\Providers\\ProviderRegistry',
        'execution' => 'App\\Extensions\\TitanAI\\System\\Providers\\ProviderExecutionRegistry',
    ],
    'model' => [
        'resolver_contract' => 'App\\Extensions\\TitanAI\\System\\TitanAI\\Contracts\\AssistantDeploymentResolverContract',
        'resolver' => 'App\\Extensions\\TitanAI\\System\\TitanAI\\Deployments\\AssistantDeploymentResolver',
    ],
];

$failures = [];
if (($data['schema'] ?? null) !== $expectedSchema) {
    $failures[] = 'schema mismatch';
}
foreach ($expected as $section => $requirements) {
    if (! isset($data[$section]) || ! is_array($data[$section])) {
        $failures[] = "missing section {$section}";
        continue;
    }
    foreach ($requirements as $key => $value) {
        if (($data[$section][$key] ?? null) !== $value) {
            $failures[] = "{$section}.{$key} mismatch";
        }
    }
}

if (($data['compatibility']['runtime_php_changed'] ?? null) !== false) {
    $failures[] = 'compatibility.runtime_php_changed must be false';
}
if (($data['compatibility']['authority_weakened'] ?? null) !== false) {
    $failures[] = 'compatibility.authority_weakened must be false';
}
if (($data['compatibility']['provider_model_contract_changed'] ?? null) !== false) {
    $failures[] = 'compatibility.provider_model_contract_changed must be false';
}

if ($failures !== []) {
    fwrite(STDERR, "Titan AI runtime compatibility registry: FAIL\n - ".implode("\n - ", $failures)."\n");
    exit(1);
}

echo "Titan AI runtime compatibility registry: PASS\n";
