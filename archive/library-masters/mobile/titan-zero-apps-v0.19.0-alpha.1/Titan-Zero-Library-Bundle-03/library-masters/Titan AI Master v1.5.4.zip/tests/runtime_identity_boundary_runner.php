<?php

declare(strict_types=1);
$root=dirname(__DIR__);
$registry=file_get_contents($root.'/System/AI/Registry/TitanAIWorkerRegistry.php');
if(!str_contains($registry,'return [3 => $legacy[3] ?? []];')) throw new RuntimeException('Active registry is not Tier-3-only.');
if(!str_contains($registry,'legacyByTier')) throw new RuntimeException('Legacy tiers are not explicitly quarantined.');
$m=json_decode(file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
if(($m['workforce']['enabled']??true)!==false) throw new RuntimeException('Titan AI Runtime must not publish Workforce identity.');
if(($m['workforce']['source_of_truth']??'')!=='none') throw new RuntimeException('Runtime claims a Workforce source of truth.');
$w=json_decode(file_get_contents($root.'/workforce-integration.json'),true,512,JSON_THROW_ON_ERROR);
if(($w['ownership']['active_extension_employee_identity']??true)!==false) throw new RuntimeException('Runtime claims active employee identity.');
echo "Titan AI Runtime identity boundary: PASS\n";
