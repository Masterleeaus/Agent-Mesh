<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Providers;

use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;
use RuntimeException;

final class CostSovereigntyInferenceGuard
{
    /** @return array<string,mixed> */
    public function authorize(TitanAIRequest $request, array $runtimeContext, string $providerId, bool $hostManaged): array
    {
        if (! app()->bound('titan.workforce.cost-sovereignty')) {
            throw new RuntimeException('Titan Cost Sovereignty router is required before external AI inference.');
        }
        $source=(string)($runtimeContext['intelligence_source']??($hostManaged?'titan_private_ai':''));
        if (trim($source)==='') throw new RuntimeException('AI intelligence_source must be explicit for external inference.');
        $routeKind=$this->canonicalExternalRoute($source,$hostManaged);
        if (in_array($routeKind,['device','local'],true)) throw new RuntimeException('Device/local AI must execute through its local runtime, not an external provider gateway.');
        $owner=$routeKind==='byo_api'?'customer':'titan';
        $candidate=[
            'provider'=>$providerId,
            'route_kind'=>$routeKind,
            'resource_type'=>'ai',
            'execution_location'=>$routeKind==='byo_api'?'byo_provider':'titan_cloud',
            'cost_owner'=>$owner,
            'cost_type'=>$owner==='customer'?'passthrough':'metered',
            'available'=>true,
            'requires_entitlement'=>$owner==='titan'?'titan.system_ai.standard':null,
            'estimated_cost'=>max(0.0,(float)($runtimeContext['estimated_cost']??0.0)),
            'privacy_ok'=>(bool)($runtimeContext['privacy_ok']??true),
            'security_ok'=>(bool)($runtimeContext['security_ok']??true),
            'quality_ok'=>(bool)($runtimeContext['quality_ok']??true),
            'capability_ok'=>true,
            'data_residency_ok'=>(bool)($runtimeContext['data_residency_ok']??true),
            'policy_ok'=>(bool)($runtimeContext['policy_ok']??true),
        ];
        $ctx=[
            'business_capability_tier'=>(string)($runtimeContext['business_capability_tier']??'legacy_existing'),
            'autonomy_level'=>(string)($runtimeContext['autonomy_level']??'assist'),
            'explicit_titan_managed_opt_in'=>(bool)($runtimeContext['explicit_titan_managed_opt_in']??false),
            'explicit_cost_approval'=>(bool)($runtimeContext['explicit_cost_approval']??false),
        ];
        $decision=app('titan.workforce.cost-sovereignty')->select($request->companyId,'ai',[$candidate],$ctx);
        if (($decision['status']??null)!=='selected') throw new RuntimeException('AI Cost Sovereignty route denied: '.(string)($decision['reason']??'denied'));
        return $decision;
    }

    private function canonicalExternalRoute(string $source, bool $hostManaged): string
    {
        $normalized=strtolower(trim($source));
        return match($normalized){
            'byo','byo_api','byo_cloud','customer_ai' => 'byo_api',
            'titan_system_ai','titan_entitled','titan_private_ai' => 'titan_entitled',
            'local','deterministic','browser_ai','device','device_ai','native_ai' => throw new RuntimeException('Device/local AI must execute through its local runtime, not an external provider gateway.'),
            'model_council' => throw new RuntimeException('Model Council is an orchestration/escalation route, not a direct external provider gateway.'),
            default => throw new RuntimeException('Unsupported external AI intelligence_source ['.$source.'].'),
        };
    }

    /** @param array<string,mixed> $selection @param array<string,mixed> $usage */
    public function commit(TitanAIRequest $request, array $selection, array $usage, string $providerId, string $model): array
    {
        if (! app()->bound('titan.workforce.cost-sovereignty')) throw new RuntimeException('Titan Cost Sovereignty router unavailable during AI usage accounting.');
        $input=(float)($usage['prompt_tokens']??$usage['input_tokens']??0);
        $output=(float)($usage['completion_tokens']??$usage['output_tokens']??0);
        $units=max(1.0,$input+$output);
        return app('titan.workforce.cost-sovereignty')->commitUsage($request->companyId,'titan-ai.inference',$selection,[
            'correlation_id'=>$request->idempotencyKey,
            'actor'=>$request->actorId?:$request->userId,
            'billing_units'=>$units,
            'billing_unit'=>'token',
            'actual_cost'=>0.0,
            'currency'=>'USD',
            'model'=>$model,
            'usage'=>$usage,
            'autonomy_level'=>(string)($request->payload['autonomy_level']??'assist'),
            'outcome'=>['status'=>'completed'],
            'metadata'=>['provider_id'=>$providerId,'intelligence_source'=>'governed'],
        ]);
    }
}
