<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions;

use App\Extensions\TitanAI\System\AI\Contracts\AbstractAIWorker;

final class FieldServiceDocumentationAgent extends AbstractAIWorker
{
    public static function id(): string { return 'field-service-documentation-agent'; }
    public static function name(): string { return 'Field Service Documentation Agent'; }
    public static function tier(): int { return 3; }
    public static function role(): string { return 'agent'; }
    public static function capabilities(): array { return [
            'Generate work-order and service reports',
            'Assemble evidence and signatures',
            'Prepare compliant customer documents',
    ]; }
    public static function permissions(): array { return [
            'documents.generate',
            'evidence.read',
            'jobs.read',
    ]; }
    public static function definition(): array
    {
        return parent::definition() + [
            'system_chat' => 'system-ai-chat',
            'runtime' => 'workcore-native-ai-runtime',
            'delegates_to' => 'tier_4_tools',
            'operational_authority' => 'workcore_api_only',
            'execution_mode' => 'governed_delegation',
            'requires_confirmation_for_mutation' => true,
        ];
    }
}
