<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Providers;

use InvalidArgumentException;
use RuntimeException;

final class ProviderRegistry
{
    public function resolve(string $providerId): ProviderProfile
    {
        $providerId = trim($providerId);
        $definition = (array) config('titan-ai.providers.'.$providerId, []);
        if ($providerId === '' || $definition === []) throw new RuntimeException("Titan AI provider [{$providerId}] is not registered.");
        $endpoint = (string)($definition['endpoint'] ?? '');
        $this->assertSafeEndpoint($endpoint, (array)($definition['allowed_hosts'] ?? []));
        return new ProviderProfile(
            id: $providerId,
            driver: (string)($definition['driver'] ?? 'openai-compatible'),
            endpoint: $endpoint,
            allowedHosts: array_values((array)($definition['allowed_hosts'] ?? [])),
            timeout: max(1,(int)($definition['timeout'] ?? 120)),
        );
    }

    public function configured(string $providerId): bool
    {
        try { $this->resolve($providerId); return true; } catch (RuntimeException|InvalidArgumentException) { return false; }
    }

    private function assertSafeEndpoint(string $endpoint, array $allowedHosts): void
    {
        $parts = parse_url($endpoint);
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        $host = strtolower((string)($parts['host'] ?? ''));
        if ($scheme !== 'https' || $host === '') throw new InvalidArgumentException('Titan AI provider endpoint must be an absolute HTTPS URL.');
        if ($host === 'localhost' || str_ends_with($host, '.localhost')) throw new InvalidArgumentException('Local provider endpoints are not allowed by the shared runtime.');
        if (filter_var($host, FILTER_VALIDATE_IP) && !filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)) {
            throw new InvalidArgumentException('Private or reserved provider IP addresses are not allowed.');
        }
        $allowedHosts=array_values(array_filter(array_map(static fn($h)=>strtolower(trim((string)$h)), $allowedHosts)));
        if ($allowedHosts !== [] && !in_array($host, $allowedHosts, true)) throw new InvalidArgumentException("Provider host [{$host}] is not allow-listed.");
    }
}
