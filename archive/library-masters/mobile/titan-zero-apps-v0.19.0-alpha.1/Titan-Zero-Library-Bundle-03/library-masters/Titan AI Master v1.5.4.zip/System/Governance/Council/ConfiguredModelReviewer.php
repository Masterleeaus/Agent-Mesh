<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Council;

use App\Extensions\TitanAI\System\Governance\Contracts\ModelInferenceClient;
use App\Extensions\TitanAI\System\Governance\Contracts\ModelReviewer;

final readonly class ConfiguredModelReviewer implements ModelReviewer
{
    public function __construct(public string $model,public string $role,private ModelInferenceClient $inference) {}
    public function review(array $case): array
    {
        $schema=['type'=>'object','additionalProperties'=>false,'required'=>['decision','confidence','findings','evidence'],'properties'=>[
            'decision'=>['type'=>'string','enum'=>['approve','reject','human_review','insufficient_evidence']],
            'confidence'=>['type'=>'integer','minimum'=>0,'maximum'=>100], 'findings'=>['type'=>'array','items'=>['type'=>'string']], 'evidence'=>['type'=>'array','items'=>['type'=>'string']],
        ]];
        $result=$this->inference->structured($this->model,[
            'instruction'=>'Independently verify the proposed operational action. Do not assume the planner is correct. Check only supplied facts, constraints and evidence.',
            'role'=>$this->role,'case'=>$case,
        ],$schema,['temperature'=>0]);
        $decoded=(array)($result['data'] ?? []);
        return ['decision'=>(string)($decoded['decision'] ?? 'insufficient_evidence'),'confidence'=>max(0,min(100,(int)($decoded['confidence'] ?? 0))),
            'findings'=>array_values((array)($decoded['findings'] ?? [])),'evidence'=>array_values((array)($decoded['evidence'] ?? [])),'model'=>$this->model,'role'=>$this->role,
            'provider_meta'=>(array)($result['meta'] ?? [])];
    }
}
