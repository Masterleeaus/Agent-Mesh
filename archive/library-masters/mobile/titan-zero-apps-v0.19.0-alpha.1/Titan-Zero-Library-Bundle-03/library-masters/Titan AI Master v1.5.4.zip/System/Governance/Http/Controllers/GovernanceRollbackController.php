<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Http\Controllers;

use App\Extensions\TitanAI\System\Governance\Rollback\RollbackExecutionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class GovernanceRollbackController extends Controller
{
    public function store(Request $request, string $receiptId, RollbackExecutionService $service): JsonResponse
    {
        $request->validate(['reason' => ['nullable', 'string', 'max:2000']]);
        $user = $request->user();
        $companyId = (int) ($user?->company_id ?? 0);
        abort_if(! $user || $companyId < 1 || ! method_exists($user, 'can') || ! $user->can('rollback-ai-actions'), 403);
        return response()->json($service->execute($receiptId, (string) $user->getAuthIdentifier(), $companyId, $request->string('reason')->toString() ?: null));
    }
}
