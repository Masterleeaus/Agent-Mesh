<?php
namespace App\Extensions\TitanAI\System\AI\Tier2\Car;
class CarCrewDispatchSpecialist {
    public function process(array $c): array { return ['specialist' => 'CarCrewDispatchSpecialist', 'vertical' => 'car', 'status' => 'processing', 'intent' => $c['intent'] ?? '']; }
}
