<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Personas;

use App\Extensions\TitanAI\System\Governance\Models\PersonaAssignment;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class PersonaAssignmentService
{
    public function assign(int $companyId, ?int $userId, string $contextType, ?string $contextId, array $definition, int $actorId): PersonaAssignment
    {
        $this->assertCompanyId($companyId);
        PersonaAssignment::query()
            ->where('company_id', $companyId)
            ->where('user_id', $userId)
            ->where('context_type', $contextType)
            ->where('context_id', $contextId)
            ->update(['active' => false]);

        return PersonaAssignment::query()->create([
            'uuid' => (string) Str::uuid(),
            'company_id' => $companyId,
            'user_id' => $userId,
            'context_type' => $contextType,
            'context_id' => $contextId,
            'name' => (string) $definition['name'],
            'definition' => $definition,
            'active' => true,
            'assigned_by' => $actorId,
        ]);
    }

    public function resolve(int $companyId, ?int $userId, string $contextType, ?string $contextId): ?PersonaAssignment
    {
        $this->assertCompanyId($companyId);
        return PersonaAssignment::query()
            ->where('company_id', $companyId)
            ->where('active', true)
            ->where(fn ($query) => $query->whereNull('user_id')->orWhere('user_id', $userId))
            ->where('context_type', $contextType)
            ->where(fn ($query) => $query->whereNull('context_id')->orWhere('context_id', $contextId))
            ->latest('id')
            ->first();
    }

    private function assertCompanyId(int $companyId): void
    {
        if ($companyId < 1) throw new InvalidArgumentException('A positive company_id is required.');
    }
}
