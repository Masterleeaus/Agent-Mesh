<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Contracts;

use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;

interface MemoryContextProviderContract
{
    /** @return array<int,array<string,mixed>> */
    public function context(TitanAIRequest $request): array;
}
