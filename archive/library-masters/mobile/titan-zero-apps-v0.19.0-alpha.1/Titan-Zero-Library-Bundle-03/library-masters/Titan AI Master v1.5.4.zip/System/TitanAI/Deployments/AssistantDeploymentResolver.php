<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Deployments;

use App\Extensions\TitanAI\System\TitanAI\Contracts\AssistantDeploymentResolverContract;
use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;
use App\Extensions\TitanAI\System\TitanAI\Integration\ConversationSourceRegistry;
use InvalidArgumentException;

final class AssistantDeploymentResolver implements AssistantDeploymentResolverContract
{
    public function __construct(private readonly ConversationSourceRegistry $sources) {}

    public function resolve(TitanAIRequest $request): array
    {
        if (array_key_exists('assistant_deployment', $request->payload)) {
            throw new InvalidArgumentException('Runtime payload field [assistant_deployment] is not permitted. Assistant deployments must be resolved from trusted host configuration.');
        }

        $adapter = $this->sources->get($request->conversationSource);
        $resolved = $adapter?->deployment($request);
        if (is_array($resolved) && $resolved !== []) {
            return $this->normalise($resolved, $request);
        }

        // Compatibility hook for older presentation products. New integrations must use ConversationSourceRegistry.
        if (app()->bound('titan.ai.assistant_deployment_source')) {
            $source = app('titan.ai.assistant_deployment_source');
            $resolved = is_callable($source) ? $source($request) : $source->resolve($request);
            if (is_array($resolved) && $resolved !== []) return $this->normalise($resolved, $request);
        }

        return $this->normalise([
            'id' => $request->assistantDeploymentId ?: 'titan-zero-default',
            'name' => 'Titan Zero',
            'system_prompt' => (string) config('titan-ai.default_system_prompt'),
            'provider' => (string) config('titan-ai.default_provider', 'magicai-host'),
            'model' => (string) config('titan-ai.default_model'),
            'capabilities' => (array) config('titan-ai.default_capabilities', []),
            'source' => 'default',
        ], $request);
    }

    private function normalise(array $deployment, TitanAIRequest $request): array
    {
        $channelCapabilities = (array) config('titan-ai.channel_capabilities.'.$request->channel, []);
        $declaredCapabilities = array_key_exists('capabilities', $deployment)
            ? (array) $deployment['capabilities']
            : (array) config('titan-ai.default_capabilities', []);
        $requested = array_values(array_unique(array_filter([
            ...$declaredCapabilities,
            ...$channelCapabilities,
        ], 'is_string')));

        return [
            'id' => (string) ($deployment['id'] ?? $request->assistantDeploymentId ?? 'titan-zero-default'),
            'name' => (string) ($deployment['name'] ?? 'Titan Zero'),
            'system_prompt' => $this->nullable($deployment['system_prompt'] ?? null),
            'provider' => $this->nullable($deployment['provider'] ?? null),
            'model' => $this->nullable($deployment['model'] ?? null),
            'capabilities' => $requested,
            'metadata' => array_diff_key($deployment, array_flip(['id','name','system_prompt','provider','model','capabilities'])),
        ];
    }

    private function nullable(mixed $value): ?string
    {
        if (! is_scalar($value)) return null;
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}
