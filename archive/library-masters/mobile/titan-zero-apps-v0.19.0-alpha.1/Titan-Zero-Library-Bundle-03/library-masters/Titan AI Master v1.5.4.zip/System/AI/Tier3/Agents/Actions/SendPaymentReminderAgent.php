<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions;

use App\Extensions\TitanAI\System\AI\Contracts\AbstractAIWorker;

final class SendPaymentReminderAgent extends AbstractAIWorker
{
    public static function id(): string { return 'send-payment-reminder-agent'; }
    public static function name(): string { return 'Send Payment Reminder Agent'; }
    public static function tier(): int { return 3; }
    public static function role(): string { return 'agent'; }

    public static function capabilities(): array
    {
        return [
            'Send one approved overdue payment reminder'
        ];
    }

    public static function permissions(): array
    {
        return [
            'invoices.read',
            'communications.send'
        ];
    }

    public static function definition(): array
    {
        return parent::definition() + [
            'system_chat' => 'system-ai-chat',
            'runtime' => 'workcore-native-ai-runtime',
            'delegates_to' => 'tier_4_tools',
            'operational_authority' => 'workcore_api_only',
        ];
    }
}
