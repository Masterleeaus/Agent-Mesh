<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier2\Traits;

use Illuminate\Support\Facades\Log;

trait SelfLearningCapability
{
    protected array $learningHistory = [];
    protected array $performanceMetrics = [];

    public function learnFromOutcome(array $input, array $outcome): void
    {
        // Update predictive models
        $this->updatePredictiveModels($input, $outcome);
        
        // Adjust optimization parameters
        $this->adjustOptimizationParameters($input, $outcome);
        
        // Update decision rules
        $this->updateDecisionRules($input, $outcome);
        
        // Track learning outcome
        $this->trackLearningOutcome($input, $outcome);
        
        Log::info('Learning update recorded', [
            'assistant' => static::class,
            'input_hash' => md5(json_encode($input)),
            'outcome_hash' => md5(json_encode($outcome))
        ]);
    }

    protected function updatePredictiveModels(array $input, array $outcome): void
    {
        $this->learningHistory[] = [
            'input' => $input,
            'actual_outcome' => $outcome,
            'timestamp' => now(),
            'model_version' => $this->getCurrentModelVersion()
        ];

        if (count($this->learningHistory) > 1000) {
            array_shift($this->learningHistory);
        }
    }

    protected function adjustOptimizationParameters(array $input, array $outcome): void
    {
        $success = $outcome['success'] ?? false;
        $confidence = $outcome['confidence'] ?? 0.5;
        
        // Dynamically adjust parameters based on outcomes
        if ($success && $confidence > 0.8) {
            $this->increaseConfidenceThreshold();
        } elseif (!$success && $confidence > 0.6) {
            $this->decreaseConfidenceThreshold();
        }
    }

    protected function updateDecisionRules(array $input, array $outcome): void
    {
        // Update rules based on performance
        $this->performanceMetrics[] = [
            'rule_applied' => $input['rule'] ?? null,
            'outcome' => $outcome['success'] ?? false,
            'timestamp' => now()
        ];
    }

    protected function trackLearningOutcome(array $input, array $outcome): void
    {
        $this->performanceMetrics[] = [
            'input_type' => $input['type'] ?? 'unknown',
            'success' => $outcome['success'] ?? false,
            'improvement_delta' => $outcome['improvement_delta'] ?? 0
        ];
    }

    protected function getCurrentModelVersion(): string
    {
        return '1.0.0';
    }

    protected function increaseConfidenceThreshold(): void
    {
        // Increase confidence in decisions
    }

    protected function decreaseConfidenceThreshold(): void
    {
        // Be more cautious with decisions
    }
}
