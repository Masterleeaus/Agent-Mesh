<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier3\Agents\Contracts;

use App\Extensions\TitanAI\System\AI\Integration\WorkCore\DTO\WorkerExecutionContext;

interface ExecutableAgent
{
    public function execute(object $input, WorkerExecutionContext $context): object;
}
