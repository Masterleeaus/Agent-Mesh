<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Tools;

use App\Extensions\TitanAI\System\Governance\Models\ToolPermission;
use InvalidArgumentException;

final class ToolPermissionService
{
    public function set(int $companyId, string $subjectType, string $subjectId, string $tool, bool $allowed, array $constraints, int $actorId): ToolPermission
    {
        $this->assertCompanyId($companyId);
        return ToolPermission::query()->updateOrCreate(
            ['company_id' => $companyId, 'subject_type' => $subjectType, 'subject_id' => $subjectId, 'tool_name' => $tool],
            ['allowed' => $allowed, 'constraints' => $constraints, 'updated_by' => $actorId],
        );
    }

    public function allows(int $companyId, string $subjectType, string $subjectId, string $tool): bool
    {
        $this->assertCompanyId($companyId);
        $permission = ToolPermission::query()
            ->where('company_id', $companyId)
            ->where('subject_type', $subjectType)
            ->where('subject_id', $subjectId)
            ->where('tool_name', $tool)
            ->first();
        return $permission ? (bool) $permission->allowed : false;
    }

    private function assertCompanyId(int $companyId): void
    {
        if ($companyId < 1) throw new InvalidArgumentException('A positive company_id is required.');
    }
}
