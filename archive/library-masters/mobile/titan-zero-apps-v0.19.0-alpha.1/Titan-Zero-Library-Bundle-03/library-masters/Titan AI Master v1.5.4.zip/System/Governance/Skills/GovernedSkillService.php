<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Skills;

use App\Extensions\TitanAI\System\Governance\Models\GovernedSkill;
use App\Extensions\TitanAI\System\Governance\Models\SkillEvaluation;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class GovernedSkillService
{
    public function save(int $companyId, array $definition, int $actorId): GovernedSkill
    {
        $this->assertCompanyId($companyId);
        foreach (['name', 'tools', 'maximum_risk', 'success_criteria', 'metrics'] as $key) {
            if (! array_key_exists($key, $definition)) throw new InvalidArgumentException("Missing skill field: {$key}");
        }

        return GovernedSkill::query()->updateOrCreate(
            ['company_id' => $companyId, 'slug' => $definition['slug'] ?? Str::slug($definition['name'])],
            [
                'uuid' => (string) Str::uuid(),
                'name' => $definition['name'],
                'definition' => $definition,
                'active' => (bool) ($definition['active'] ?? true),
                'updated_by' => $actorId,
            ],
        );
    }

    public function evaluate(GovernedSkill $skill, string $executionId, array $observed): SkillEvaluation
    {
        $companyId = (int) $skill->company_id;
        $this->assertCompanyId($companyId);
        $definition = $skill->definition;
        $criteria = (array) ($definition['success_criteria'] ?? []);
        $passed = true;
        foreach ($criteria as $key => $expected) {
            if (($observed[$key] ?? null) !== $expected) {
                $passed = false;
                break;
            }
        }

        return SkillEvaluation::query()->create([
            'company_id' => $companyId,
            'skill_id' => $skill->id,
            'execution_id' => $executionId,
            'passed' => $passed,
            'metrics' => $observed,
            'evaluated_at' => now(),
        ]);
    }

    private function assertCompanyId(int $companyId): void
    {
        if ($companyId < 1) throw new InvalidArgumentException('A positive company_id is required.');
    }
}
