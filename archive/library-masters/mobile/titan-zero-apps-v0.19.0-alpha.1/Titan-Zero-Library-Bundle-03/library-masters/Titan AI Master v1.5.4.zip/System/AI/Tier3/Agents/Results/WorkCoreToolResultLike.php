<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier3\Agents\Results;

/**
 * Neutral result shape accepted by AgentActionResult. Canonical WorkCore adapters
 * may map their native result DTO into this value object without TitanAI owning WorkCore classes.
 */
final readonly class WorkCoreToolResultLike
{
    public function __construct(
        public array $data,
        public ?string $auditId = null,
        public array $eventIds = [],
        public bool $replayed = false,
    ) {}
}
