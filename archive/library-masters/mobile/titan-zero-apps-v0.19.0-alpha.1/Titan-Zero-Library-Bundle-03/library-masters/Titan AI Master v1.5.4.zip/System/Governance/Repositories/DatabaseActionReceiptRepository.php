<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Repositories;

use App\Extensions\TitanAI\System\Governance\Council\CouncilCase;
use App\Extensions\TitanAI\System\Governance\Models\ActionReceiptRecord;
use App\Extensions\TitanAI\System\Governance\Receipts\ActionReceipt;

final class DatabaseActionReceiptRepository implements ActionReceiptRepository
{
    public function persist(ActionReceipt $receipt, CouncilCase $case, array $context): void
    {
        ActionReceiptRecord::query()->create([
            'id' => $receipt->receiptId,
            'company_id' => $case->companyId,
            'user_id' => $case->userId,
            'device_id' => $case->deviceId,
            'action' => $receipt->action,
            'manager_id' => $context['manager'] ?? null,
            'assistant_id' => $context['assistant'] ?? null,
            'agent_id' => $context['agent'] ?? null,
            'conversation_id' => $context['conversation_id'] ?? null,
            'workflow_id' => $context['workflow_id'] ?? null,
            'channel' => $context['channel'] ?? null,
            'idempotency_key' => $case->idempotencyKey,
            'status' => $receipt->status,
            'risk_level' => $receipt->riskLevel,
            'approval_id' => $receipt->approvalId,
            'council_result' => json_encode($receipt->council, JSON_THROW_ON_ERROR),
            'workcore_result' => $receipt->workCoreResult === null ? null : json_encode($receipt->workCoreResult, JSON_THROW_ON_ERROR),
            'rollback_contract' => $receipt->rollback === null ? null : json_encode($receipt->rollback, JSON_THROW_ON_ERROR),
        ]);
    }

    public function findExecutedByIdempotency(int $companyId, string $action, string $idempotencyKey): ?array
    {
        $row = ActionReceiptRecord::query()
            ->where('company_id', $companyId)
            ->where('action', $action)
            ->where('idempotency_key', $idempotencyKey)
            ->whereIn('status', ['executed', 'executed_after_approval'])
            ->latest('created_at')
            ->first();

        if (! $row) return null;
        $result = json_decode((string) ($row->workcore_result ?? '{}'), true);
        return ['receipt_id' => (string) $row->id, 'result' => is_array($result) ? $result : [], 'status' => (string) $row->status];
    }

    public function updateForApproval(string $approvalId, int $companyId, string $status, ?array $result, ?string $failure): void
    {
        ActionReceiptRecord::query()
            ->where('approval_id', $approvalId)
            ->where('company_id', $companyId)
            ->update([
                'status' => $status,
                'workcore_result' => $result === null ? null : json_encode($result, JSON_THROW_ON_ERROR),
                'failure_reason' => $failure === null ? null : mb_substr($failure, 0, 2000),
                'updated_at' => now(),
            ]);
    }
}
