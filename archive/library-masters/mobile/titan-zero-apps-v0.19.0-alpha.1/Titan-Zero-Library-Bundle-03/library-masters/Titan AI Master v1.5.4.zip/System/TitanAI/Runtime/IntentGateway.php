<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Runtime;

final class IntentGateway
{
    public function __construct(private readonly IntentDefinitionRegistry $definitions) {}

    /** @return array<string,array<string,mixed>> */
    public function actionDefinitions(): array
    {
        return $this->definitions->all();
    }

    public function classify(string $message): IntentDecision
    {
        $normalised = strtolower(trim($message));
        foreach ($this->definitions->all() as $intent => $definition) {
            foreach ((array)$definition['patterns'] as $pattern) {
                if ($this->containsPhrase($normalised, (string)$pattern)) {
                    $coverage = min(1.0, max(0.0, strlen((string)$pattern) / max(1, strlen($normalised))));
                    $confidence = round(0.78 + (0.14 * $coverage), 3);
                    return new IntentDecision(
                        lane: 'business_action', intent: $intent, confidence: $confidence,
                        manager: (string)$definition['manager'], assistant: (string)$definition['assistant'], agent: (string)$definition['agent'],
                        domain: (string)$definition['domain'], operation: (string)$definition['operation'], riskLevel: (string)($definition['risk'] ?? 'green'),
                        permissions: array_values((array)($definition['permissions'] ?? [])),
                        evidence: ['method'=>'deterministic_phrase','pattern'=>$pattern,'coverage'=>$coverage],
                    );
                }
            }
        }

        if (preg_match('/\b(how|what|why|where|when|help|procedure|policy|instructions?)\b/i', $message) === 1) {
            return new IntentDecision('knowledge', 'knowledge_query', 0.72, evidence: ['method'=>'question_heuristic']);
        }

        return new IntentDecision('conversation', 'general_conversation', 0.55, evidence: ['method'=>'default_lane']);
    }

    private function containsPhrase(string $message, string $pattern): bool
    {
        $pattern = strtolower(trim($pattern));
        if ($pattern === '') return false;
        return preg_match('/(?<![a-z0-9])'.preg_quote($pattern, '/').'(?![a-z0-9])/i', $message) === 1;
    }
}
