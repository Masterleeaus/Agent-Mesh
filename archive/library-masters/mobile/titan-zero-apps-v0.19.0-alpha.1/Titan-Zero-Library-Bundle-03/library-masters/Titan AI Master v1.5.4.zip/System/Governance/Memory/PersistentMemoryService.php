<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Memory;

use App\Extensions\TitanAI\System\Governance\Models\GovernedMemory;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class PersistentMemoryService
{
    public function __construct(private readonly MemoryGovernanceService $governance) {}

    public function store(int $companyId, ?int $userId, MemoryPolicy $policy, array $record, string $role, bool $approved = false): GovernedMemory
    {
        $this->assertCompanyId($companyId);
        $data = $this->governance->validateWrite($policy, $record, $role, $approved);
        return GovernedMemory::query()->create([
            'uuid' => (string) Str::uuid(),
            'company_id' => $companyId,
            'user_id' => $userId,
            'scope' => $data['scope'],
            'subject_type' => $record['subject_type'] ?? null,
            'subject_id' => $record['subject_id'] ?? null,
            'payload' => $record['payload'] ?? $record,
            'importance' => $data['importance'],
            'status' => $data['status'] ?? ($approved ? 'approved' : 'active'),
            'authoritative' => $data['authoritative'] ?? $approved,
            'reinforcement_count' => 1,
            'last_reinforced_at' => now(),
            'approved_at' => $approved ? now() : null,
            'expires_at' => $data['expires_at'],
            'metadata' => $record['metadata'] ?? [],
        ]);
    }

    public function approve(int $companyId, string $uuid, int $approverId): GovernedMemory
    {
        $this->assertCompanyId($companyId);
        $memory = GovernedMemory::query()->where('company_id', $companyId)->where('uuid', $uuid)->firstOrFail();
        if ($memory->status !== 'suggested') throw new InvalidArgumentException('Only suggested memory can be approved.');
        $memory->update(['status' => 'approved', 'authoritative' => true, 'approved_by' => $approverId, 'approved_at' => now()]);
        return $memory->refresh();
    }

    public function reinforce(int $companyId, string $uuid): GovernedMemory
    {
        $this->assertCompanyId($companyId);
        $memory = GovernedMemory::query()->where('company_id', $companyId)->where('uuid', $uuid)->firstOrFail();
        $memory->increment('reinforcement_count');
        $memory->update(['last_reinforced_at' => now()]);
        return $memory->refresh();
    }

    private function assertCompanyId(int $companyId): void
    {
        if ($companyId < 1) throw new InvalidArgumentException('A positive company_id is required.');
    }
}
