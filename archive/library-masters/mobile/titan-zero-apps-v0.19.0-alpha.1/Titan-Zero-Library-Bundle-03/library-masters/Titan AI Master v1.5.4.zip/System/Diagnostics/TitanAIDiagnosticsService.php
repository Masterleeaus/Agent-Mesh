<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Diagnostics;

use App\Extensions\TitanAI\System\Providers\CredentialResolverContract;
use App\Extensions\TitanAI\System\Providers\ProviderRegistry;
use App\Extensions\TitanAI\System\Providers\ProviderExecutionRegistry;
use App\Extensions\TitanAI\System\TitanAI\Contracts\WorkCoreRuntimeBridgeContract;
use App\Extensions\TitanAI\System\TitanAI\Runtime\AgentExecutionPathResolver;
use App\Extensions\TitanAI\System\TitanAI\Runtime\AssistantDelegationGraph;
use App\Extensions\TitanAI\System\TitanAI\Runtime\WorkerRouteRegistry;
use App\Extensions\TitanAI\System\TitanAI\Runtime\WorkCoreToolMappingRegistry;
use Throwable;

final class TitanAIDiagnosticsService
{
    public function __construct(
        private WorkerRouteRegistry $workers,
        private AgentExecutionPathResolver $paths,
        private AssistantDelegationGraph $delegations,
        private ProviderRegistry $providers,
        private ProviderExecutionRegistry $executionProviders,
        private CredentialResolverContract $credentials,
        private WorkCoreRuntimeBridgeContract $workCore,
        private WorkCoreToolMappingRegistry $toolMappings,
    ) {}

    public function report(): array
    {
        try {
            $worker = $this->workers->diagnostics($this->paths, $this->delegations);
        } catch (Throwable $exception) {
            $worker = ['healthy' => false, 'error' => $exception->getMessage()];
        }

        $runtimeEnabled = (bool) config('titan-ai.enabled', true);
        $governanceEnabled = (bool) config('titan-ai-governance.enabled', true);
        $provider = (string) config('titan-ai.default_provider', 'magicai-host');
        $hostGateway = $provider === 'magicai-host';
        $providerConfigured = $hostGateway
            ? $this->executionProviders->has('magicai-host')
            : $this->providers->configured($provider);
        $credentialAvailable = $hostGateway ? null : $this->credentials->resolve($provider) !== null;
        $providerReady = $providerConfigured && $credentialAvailable !== false;
        $workCoreAvailable = $this->workCore->available();
        $rollbackMappings = $this->toolMappings->rollbackCount();

        $state = ! $runtimeEnabled
            ? 'disabled'
            : (($worker['healthy'] ?? false) && $providerReady ? 'healthy' : 'degraded');

        $workforceState = ! $runtimeEnabled
            ? 'policy_disabled'
            : (! $providerConfigured
                ? 'missing_provider'
                : (! $providerReady
                    ? 'unavailable'
                    : (($worker['healthy'] ?? false) ? 'available' : 'degraded')));

        return [
            'extension' => 'titan-ai',
            'version' => '1.5.4',
            'state' => $state,
            'workforce_state' => $workforceState,
            'runtime' => ['engine' => 'five-tier', 'enabled' => $runtimeEnabled],
            'workers' => $worker,
            'provider' => [
                'id' => $provider,
                'configured' => $providerConfigured,
                'credential_available' => $credentialAvailable,
                'model' => config('titan-ai.default_model'),
                'version' => null,
                'version_known' => false,
                'pinned' => trim($provider) !== '',
            ],
            'workcore' => ['available' => $workCoreAvailable, 'mapped_operations' => $this->toolMappings->diagnostics()['mapped'], 'rollback_mappings' => $rollbackMappings],
            'governance' => ['enabled' => $governanceEnabled, 'fail_closed' => true],
        ];
    }
}
