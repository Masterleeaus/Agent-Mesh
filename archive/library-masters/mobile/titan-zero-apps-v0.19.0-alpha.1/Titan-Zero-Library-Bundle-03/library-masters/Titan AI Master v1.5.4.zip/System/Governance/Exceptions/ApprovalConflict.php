<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Exceptions;

use RuntimeException;

final class ApprovalConflict extends RuntimeException {}
