<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Integration;

use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;

interface ConversationSourceAdapterContract
{
    public function source(): string;

    /** @return array<string,mixed>|null */
    public function deployment(TitanAIRequest $request): ?array;

    /** @return array<int,array<string,mixed>> */
    public function context(TitanAIRequest $request): array;

    /** @return array<string,mixed>|null */
    public function complete(TitanAIRequest $request, array $runtimeContext = []): ?array;

    /**
     * Return null when the source does not provide native streaming. Otherwise return
     * the same normalised result shape accepted by complete().
     *
     * @param callable(array<string,mixed>):void $emit
     * @return array<string,mixed>|null
     */
    public function stream(TitanAIRequest $request, array $runtimeContext, callable $emit): ?array;
}
