<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Integration\WorkCore\DTO;

use InvalidArgumentException;

final readonly class WorkerExecutionContext
{
    public function __construct(
        public int $companyId,
        public int $actorId,
        public string $workerId,
        public string $workerType,
        public int $tier,
        public ?string $delegatedByWorkerId = null,
        public ?string $conversationId = null,
        public ?string $workflowId = null,
        public string $vertical = 'general',
        public ?string $serviceType = null,
        public string $channel = 'internal',
    ) {
        if ($companyId < 1 || $actorId < 1) {
            throw new InvalidArgumentException('Company and actor are required.');
        }
        if (trim($workerId) === '' || ! in_array($tier, [0, 1, 2, 3, 4], true)) {
            throw new InvalidArgumentException('A valid worker ID and tier are required.');
        }
        if (trim($vertical) === '') {
            throw new InvalidArgumentException('Vertical must be non-empty.');
        }
    }

    /** @return array<string,mixed> */
    public function metadata(): array
    {
        return array_filter([
            'source' => 'titan_ai',
            'company_id' => $this->companyId,
            'actor_id' => $this->actorId,
            'worker_id' => $this->workerId,
            'worker_type' => $this->workerType,
            'tier' => $this->tier,
            'delegated_by_worker_id' => $this->delegatedByWorkerId,
            'conversation_id' => $this->conversationId,
            'workflow_id' => $this->workflowId,
            'vertical' => $this->vertical,
            'service_type' => $this->serviceType,
            'channel' => $this->channel,
        ], static fn (mixed $value): bool => $value !== null && $value !== '');
    }
}
