<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier2\Traits;

use Illuminate\Support\Facades\Log;

trait PerformanceMonitoring
{
    protected array $kpis = [];
    protected array $anomalies = [];

    public function monitorPerformance(array $metrics): array
    {
        // Track KPIs
        $tracked = $this->trackKPIs($metrics);

        // Detect anomalies
        $anomalies = $this->detectAnomalies($tracked);

        // Generate recommendations
        $recommendations = $this->generateOptimizations($anomalies);

        // Implement improvements
        $this->implementImprovements($recommendations);

        return [
            'metrics' => $tracked,
            'anomalies' => $anomalies,
            'recommendations' => $recommendations,
            'timestamp' => now()
        ];
    }

    protected function trackKPIs(array $metrics): array
    {
        $this->kpis[] = array_merge($metrics, ['timestamp' => now()]);

        if (count($this->kpis) > 1000) {
            array_shift($this->kpis);
        }

        return end($this->kpis);
    }

    protected function detectAnomalies(array $metrics): array
    {
        $anomalies = [];

        foreach ($metrics as $key => $value) {
            if ($this->isAnomalous($key, $value)) {
                $anomalies[$key] = [
                    'value' => $value,
                    'expected_range' => $this->getExpectedRange($key),
                    'severity' => $this->calculateAnomalySeverity($key, $value)
                ];
            }
        }

        return $anomalies;
    }

    protected function generateOptimizations(array $anomalies): array
    {
        return array_map(function($key, $anomaly) {
            return [
                'metric' => $key,
                'current' => $anomaly['value'],
                'target' => $anomaly['expected_range']['max'] ?? 100,
                'action' => $this->generateOptimizationAction($key, $anomaly)
            ];
        }, array_keys($anomalies), $anomalies);
    }

    protected function implementImprovements(array $recommendations): void
    {
        foreach ($recommendations as $recommendation) {
            // Execute improvement action
            Log::info('Implementing optimization', ['recommendation' => $recommendation]);
        }
    }

    protected function isAnomalous(string $key, mixed $value): bool
    {
        $expected = $this->getExpectedRange($key);
        return $value < $expected['min'] || $value > $expected['max'];
    }

    protected function getExpectedRange(string $key): array
    {
        return ['min' => 0, 'max' => 100];
    }

    protected function calculateAnomalySeverity(string $key, mixed $value): string
    {
        $expected = $this->getExpectedRange($key);
        $deviation = abs($value - $expected['max']) / $expected['max'];

        if ($deviation > 0.3) {
            return 'critical';
        } elseif ($deviation > 0.15) {
            return 'high';
        } else {
            return 'normal';
        }
    }

    protected function generateOptimizationAction(string $key, array $anomaly): string
    {
        return 'Optimize ' . $key . ' to reach target';
    }
}
