<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier2\Assistants;

use App\Extensions\TitanAI\System\AI\Contracts\AbstractAIWorker;

final class RecurringServicesAssistant extends AbstractAIWorker
{
    public static function id(): string { return 'recurring-services-assistant'; }
    public static function name(): string { return 'Recurring Services Assistant'; }
    public static function tier(): int { return 2; }
    public static function role(): string { return 'assistant'; }

    public static function capabilities(): array
    {
        return [
            'Design recurring service schedules',
            'Coordinate renewals and exceptions',
            'Prepare recurrence actions'
        ];
    }

    public static function permissions(): array
    {
        return [
            'recurrence.read',
            'jobs.read',
            'customers.read'
        ];
    }

    public static function definition(): array
    {
        return parent::definition() + [
            'system_chat' => 'system-ai-chat',
            'runtime' => 'workcore-native-ai-runtime',
            'delegates_to' => 'tier_3_agents',
            'operational_authority' => 'workcore_api_only',
        ];
    }
}
