<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Contracts;

abstract class AbstractAIWorker implements AIWorker
{
    /** @return array<string,mixed> */
    public static function definition(): array
    {
        return [
            'id' => static::id(),
            'name' => static::name(),
            'tier' => static::tier(),
            'role' => static::role(),
            'industry' => 'multi-vertical',
            'verticals' => ['*'],
            'capabilities' => static::capabilities(),
            'permissions' => static::permissions(),
            'operational_authority' => 'canonical_workcore_gateway_only',
        ];
    }
}
