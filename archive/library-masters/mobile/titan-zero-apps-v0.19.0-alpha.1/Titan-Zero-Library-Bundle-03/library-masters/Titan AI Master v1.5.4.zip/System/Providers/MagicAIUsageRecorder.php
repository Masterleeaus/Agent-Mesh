<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Providers;

use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;
use Throwable;

/**
 * Best-effort bridge into MagicAI's native credit/usage ledger for requests that
 * TitanAI sends directly through its trusted OpenAI-compatible provider path.
 * Source adapters that already account for usage must not call this recorder.
 */
final class MagicAIUsageRecorder
{
    public function record(TitanAIRequest $request, string $model, string $output): void
    {
        if ($output === '' || ! class_exists(\App\Domains\Entity\Enums\EntityEnum::class)
            || ! class_exists(\App\Domains\Entity\Facades\Entity::class)
            || ! class_exists(\App\Models\User::class)) {
            return;
        }

        try {
            $entity = \App\Domains\Entity\Enums\EntityEnum::tryFrom($model);
            $user = \App\Models\User::query()->find((int) $request->userId);
            if ($entity === null || $user === null || (int) ($user->company_id ?? 0) !== $request->companyId) {
                return;
            }

            $driver = \App\Domains\Entity\Facades\Entity::driver($entity)->forUser($user);
            $driver->input($output)->calculateCredit()->decreaseCredit();

            if (class_exists(\App\Models\Usage::class)) {
                \App\Models\Usage::getSingle()->updateWordCounts($driver->calculate());
            }
        } catch (Throwable $exception) {
            // Provider completion already succeeded. Do not turn an accounting integration
            // mismatch into a user-visible provider failure, but make it observable.
            report($exception);
        }
    }
}
