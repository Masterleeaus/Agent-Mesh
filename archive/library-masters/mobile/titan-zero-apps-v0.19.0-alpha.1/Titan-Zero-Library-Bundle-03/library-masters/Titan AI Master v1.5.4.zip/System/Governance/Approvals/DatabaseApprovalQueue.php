<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Approvals;

use App\Extensions\TitanAI\System\Governance\Exceptions\ApprovalConflict;
use App\Extensions\TitanAI\System\Governance\Models\ApprovalRequestRecord;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class DatabaseApprovalQueue implements ApprovalQueue
{
    public function enqueue(array $request): string
    {
        $companyId = (int) ($request['company_id'] ?? 0);
        $action = trim((string) ($request['action'] ?? ''));
        $idempotencyKey = $this->nullable($request['idempotency_key'] ?? null);
        if ($companyId < 1 || $action === '') throw new InvalidArgumentException('Approval requests require a positive company_id and action.');

        if ($idempotencyKey !== null) {
            $existing = ApprovalRequestRecord::query()->where('company_id', $companyId)->where('action', $action)
                ->where('idempotency_key', $idempotencyKey)->whereIn('status', ['pending', 'approved', 'executing', 'executed'])->first();
            if ($existing) return (string) $existing->id;
        }

        $id = (string) Str::uuid();
        ApprovalRequestRecord::query()->create([
            'id' => $id, 'company_id' => $companyId, 'user_id' => (string) ($request['user_id'] ?? ''),
            'device_id' => $this->nullable($request['device_id'] ?? null), 'action' => $action,
            'domain' => (string) ($request['domain'] ?? ''), 'risk_level' => (string) ($request['risk_level'] ?? 'red'),
            'payload' => json_encode((array) ($request['payload'] ?? []), JSON_THROW_ON_ERROR),
            'tool_definition' => json_encode((array) ($request['tool_definition'] ?? []), JSON_THROW_ON_ERROR),
            'execution_context' => json_encode((array) ($request['execution_context'] ?? []), JSON_THROW_ON_ERROR),
            'council_result' => json_encode((array) ($request['council_result'] ?? []), JSON_THROW_ON_ERROR),
            'idempotency_key' => $idempotencyKey, 'status' => 'pending',
            'expires_at' => $request['expires_at'] ?? now()->addHours(24),
        ]);
        return $id;
    }

    public function resolve(string $approvalId, string $decision, string $actorId, int $companyId, ?string $note = null): void
    {
        if ($companyId < 1) throw new InvalidArgumentException('A positive company_id is required.');
        if (! in_array($decision, ['approved', 'rejected'], true)) throw new InvalidArgumentException('Approval decision must be approved or rejected.');
        $updated = ApprovalRequestRecord::query()->whereKey($approvalId)->where('company_id', $companyId)->where('status', 'pending')->update([
            'status' => $decision, 'resolved_by' => $actorId, 'resolution_note' => $note, 'resolved_at' => now(), 'updated_at' => now(),
        ]);
        if ($updated !== 1) throw new ApprovalConflict('Approval is missing, belongs to another company, or is no longer pending.');
    }

    public function find(string $approvalId, int $companyId): ?array
    {
        $row = ApprovalRequestRecord::query()->whereKey($approvalId)->where('company_id', $companyId)->first();
        return $row ? $row->getAttributes() : null;
    }

    public function pending(int $companyId): array
    {
        return ApprovalRequestRecord::query()->where('company_id', $companyId)->where('status', 'pending')
            ->orderBy('created_at')->limit(500)->get()->map(fn (ApprovalRequestRecord $row) => $row->getAttributes())->all();
    }

    public function expirePending(?int $companyId = null): int
    {
        $query = ApprovalRequestRecord::query()->where('status', 'pending')->whereNotNull('expires_at')->where('expires_at', '<', now());
        if ($companyId !== null) { if ($companyId < 1) throw new InvalidArgumentException('A positive company_id is required.'); $query->where('company_id', $companyId); }
        return $query->update(['status' => 'expired', 'updated_at' => now()]);
    }

    public function claimForExecution(string $approvalId, string $actorId, int $companyId, ?string $note = null): array
    {
        if ($companyId < 1) throw new InvalidArgumentException('A positive company_id is required.');
        $connection = (new ApprovalRequestRecord())->getConnection();
        return $connection->transaction(function () use ($approvalId, $actorId, $companyId, $note): array {
            $row = ApprovalRequestRecord::query()->whereKey($approvalId)->where('company_id', $companyId)->lockForUpdate()->first();
            if (! $row) throw new ApprovalConflict('Approval was not found for this company.');
            if ($row->status === 'executed') return $row->getAttributes();
            if (! in_array($row->status, ['pending', 'approved', 'execution_failed'], true)) throw new ApprovalConflict('Approval is not executable in its current state.');
            if ($row->status === 'pending') { $row->resolved_by = $actorId; $row->resolution_note = $note; $row->resolved_at = now(); }
            $row->status = 'executing';
            $row->execution_attempts = ((int) $row->execution_attempts) + 1;
            $row->execution_started_at = now(); $row->last_execution_error = null; $row->save();
            return $row->fresh()?->getAttributes() ?? $row->getAttributes();
        });
    }

    public function completeExecution(string $approvalId, int $companyId): void
    {
        $updated = ApprovalRequestRecord::query()->whereKey($approvalId)->where('company_id', $companyId)->where('status', 'executing')->update(['status' => 'executed', 'updated_at' => now()]);
        if ($updated !== 1) throw new ApprovalConflict('Approval execution completion conflicted with another process.');
    }

    public function failExecution(string $approvalId, int $companyId, string $error): void
    {
        ApprovalRequestRecord::query()->whereKey($approvalId)->where('company_id', $companyId)->where('status', 'executing')->update([
            'status' => 'execution_failed', 'last_execution_error' => mb_substr($error, 0, 2000), 'updated_at' => now(),
        ]);
    }

    private function nullable(mixed $value): ?string
    {
        if (! is_scalar($value)) return null;
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}
