<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Memory;

use App\Extensions\TitanAI\System\Governance\Models\GovernedMemory;
use InvalidArgumentException;

final class MemoryDecayService
{
    public function run(?int $companyId = null): array
    {
        if ($companyId !== null && $companyId < 1) throw new InvalidArgumentException('A positive company_id is required.');

        $query = GovernedMemory::query();
        if ($companyId !== null) $query->where('company_id', $companyId);

        $expired = (clone $query)
            ->whereNotNull('expires_at')
            ->where('expires_at', '<=', now())
            ->update(['status' => 'expired', 'authoritative' => false]);

        $cutoff = now()->subDays((int) config('titan-ai-governance.memory.decay_after_days', 90));
        $decayed = (clone $query)
            ->whereIn('status', ['active', 'approved'])
            ->where('importance', '<=', 2)
            ->where('last_reinforced_at', '<', $cutoff)
            ->update(['status' => 'decayed', 'authoritative' => false]);

        return compact('expired', 'decayed');
    }
}
