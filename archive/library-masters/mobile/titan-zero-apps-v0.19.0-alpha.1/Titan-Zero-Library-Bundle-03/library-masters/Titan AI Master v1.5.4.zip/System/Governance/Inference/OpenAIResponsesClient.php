<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Inference;

use App\Extensions\TitanAI\System\Governance\Contracts\ModelInferenceClient;
use App\Extensions\TitanAI\System\Providers\CredentialResolverContract;
use App\Extensions\TitanAI\System\Providers\ProviderRegistry;
use Illuminate\Support\Facades\Http;
use RuntimeException;

final readonly class OpenAIResponsesClient implements ModelInferenceClient
{
    public function __construct(private ModelBudgetGuard $budget,private ProviderRegistry $providers,private CredentialResolverContract $credentials) {}
    public function structured(string $model,array $input,array $schema,array $options=[]): array
    {
        $providerId=(string)($options['provider'] ?? config('titan-ai-governance.provider','openai'));
        $profile=$this->providers->resolve($providerId); $apiKey=$this->credentials->resolve($providerId);
        if ($apiKey===null) throw new RuntimeException("No credential configured for governance provider [{$providerId}].");
        $parts=parse_url($profile->endpoint); $base=($parts['scheme'] ?? 'https').'://'.($parts['host'] ?? 'api.openai.com');
        if (isset($parts['port'])) $base.=':'.$parts['port'];
        $path=(string)($parts['path'] ?? '/v1/chat/completions');
        $v1pos=strpos($path,'/v1/'); $prefix=$v1pos===false?'/v1':substr($path,0,$v1pos+3);
        $endpoint=rtrim($base.$prefix,'/').'/responses';
        $payload=['model'=>$model,'store'=>false,'input'=>[['role'=>'user','content'=>[['type'=>'input_text','text'=>json_encode($input,JSON_THROW_ON_ERROR)]]]],
            'text'=>['format'=>['type'=>'json_schema','name'=>'titan_council_review','strict'=>true,'schema'=>$schema],'verbosity'=>'low']];
        $response=Http::withToken($apiKey)->acceptJson()->asJson()->timeout(max(1,(int)($options['timeout_seconds'] ?? 30)))->post($endpoint,$payload);
        if(!$response->successful()) throw new RuntimeException('Governance model review failed with HTTP '.$response->status().'.');
        $body=$response->json(); if(!is_array($body) || ($body['status'] ?? 'completed')!=='completed') throw new RuntimeException('Governance model review did not complete.');
        $text=$this->extractOutputText($body); $data=json_decode($text,true,512,JSON_THROW_ON_ERROR); if(!is_array($data)) throw new RuntimeException('Governance model review returned invalid structured data.');
        $inputTokens=(int)($body['usage']['input_tokens'] ?? 0); $outputTokens=(int)($body['usage']['output_tokens'] ?? 0); $cost=$this->budget->assertAllowed($model,$inputTokens,$outputTokens);
        return ['data'=>$data,'meta'=>['provider'=>$providerId,'model'=>(string)($body['model'] ?? $model),'response_id'=>(string)($body['id'] ?? ''),'input_tokens'=>$inputTokens,'output_tokens'=>$outputTokens,'total_tokens'=>$inputTokens+$outputTokens,'cost'=>$cost]];
    }
    private function extractOutputText(array $body): string
    {
        if(isset($body['output_text']) && is_string($body['output_text'])) return $body['output_text'];
        foreach((array)($body['output'] ?? []) as $item) foreach((array)($item['content'] ?? []) as $content) {
            if(($content['type'] ?? '')==='output_text' && is_string($content['text'] ?? null)) return $content['text'];
            if(($content['type'] ?? '')==='refusal') throw new RuntimeException('Governance reviewer refused the request.');
        }
        throw new RuntimeException('Governance response contained no structured output text.');
    }
}
