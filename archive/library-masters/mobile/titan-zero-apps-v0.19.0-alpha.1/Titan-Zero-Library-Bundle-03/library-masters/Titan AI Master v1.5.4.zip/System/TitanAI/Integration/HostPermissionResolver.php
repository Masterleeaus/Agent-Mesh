<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Integration;

use Illuminate\Support\Facades\Gate;
use Throwable;

final class HostPermissionResolver
{
    /** @return array<int,string> */
    public function forUser(object $user, array $additional = []): array
    {
        $catalogue = $additional;
        foreach ((array) config('titan-ai.intents', []) as $intent) {
            if (! is_array($intent)) continue;
            foreach ((array) ($intent['permissions'] ?? []) as $permission) {
                if (is_string($permission) && $permission !== '') $catalogue[] = $permission;
            }
        }
        $catalogue = array_values(array_unique(array_filter($catalogue, 'is_string')));

        if (method_exists($user, 'isAdmin') && (bool) $user->isAdmin()) return $catalogue;

        $allowed = [];
        foreach ($catalogue as $permission) {
            try {
                if (method_exists($user, 'can') && $user->can($permission)) {
                    $allowed[] = $permission;
                    continue;
                }
                if (Gate::forUser($user)->allows($permission)) $allowed[] = $permission;
            } catch (Throwable) {
                // Missing host permission definitions are treated as denied.
            }
        }
        return array_values(array_unique($allowed));
    }
}
