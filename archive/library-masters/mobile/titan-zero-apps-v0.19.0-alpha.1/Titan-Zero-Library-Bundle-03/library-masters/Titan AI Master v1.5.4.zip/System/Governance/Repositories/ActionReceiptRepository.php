<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Repositories;

use App\Extensions\TitanAI\System\Governance\Council\CouncilCase;
use App\Extensions\TitanAI\System\Governance\Receipts\ActionReceipt;

interface ActionReceiptRepository
{
    public function persist(ActionReceipt $receipt, CouncilCase $case, array $context): void;
    public function findExecutedByIdempotency(int $companyId,string $action,string $idempotencyKey): ?array;
    public function updateForApproval(string $approvalId,int $companyId,string $status,?array $result,?string $failure): void;
}
