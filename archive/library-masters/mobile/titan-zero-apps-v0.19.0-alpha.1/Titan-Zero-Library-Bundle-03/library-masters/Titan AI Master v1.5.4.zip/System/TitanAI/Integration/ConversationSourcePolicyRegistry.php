<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Integration;

use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;
use InvalidArgumentException;
use RuntimeException;

final class ConversationSourcePolicyRegistry
{
    /** @var array<string,callable|object> */
    private array $policies = [];

    public function register(string $source, callable|object $policy): void
    {
        $source = trim(strtolower($source));
        if ($source === '') throw new InvalidArgumentException('Titan AI source policy key cannot be empty.');
        if (isset($this->policies[$source])) throw new InvalidArgumentException("Titan AI source policy [{$source}] is already registered.");
        $this->policies[$source] = $policy;
    }

    public function has(string $source): bool
    {
        return isset($this->policies[strtolower(trim($source))]);
    }

    /** @param array<int,string> $capabilities @return array<int,string> */
    public function filterCapabilities(TitanAIRequest $request, array $capabilities): array
    {
        $source = trim(strtolower($request->conversationSource));
        $policy = $this->policies[$source] ?? null;

        if ($policy === null) {
            $configured = (array) config('titan-ai.source_policies.'.$source.'.capabilities', []);
            if ($configured === []) {
                if ((bool) config('titan-ai.require_registered_source_policy', false)) {
                    throw new RuntimeException("No Titan AI source policy is registered for [{$source}].");
                }
                return array_values(array_unique(array_filter($capabilities, 'is_string')));
            }
            return array_values(array_intersect($capabilities, $configured));
        }

        $filtered = is_callable($policy)
            ? $policy($request, $capabilities)
            : (method_exists($policy, 'filterCapabilities') ? $policy->filterCapabilities($request, $capabilities) : $capabilities);

        if (! is_array($filtered)) throw new RuntimeException("Titan AI source policy [{$source}] returned an invalid capability set.");

        return array_values(array_unique(array_filter($filtered, 'is_string')));
    }

    public function allowsBusinessActions(TitanAIRequest $request): bool
    {
        $source = trim(strtolower($request->conversationSource));
        $policy = $this->policies[$source] ?? null;
        if (is_object($policy) && method_exists($policy, 'allowsBusinessActions')) {
            return (bool) $policy->allowsBusinessActions($request);
        }
        return (bool) config('titan-ai.source_policies.'.$source.'.business_actions', false);
    }

    public function allowsTool(TitanAIRequest $request, string $toolId): bool
    {
        $source = trim(strtolower($request->conversationSource));
        $policy = $this->policies[$source] ?? null;
        if (is_object($policy) && method_exists($policy, 'allowsTool')) {
            return (bool) $policy->allowsTool($request, $toolId);
        }
        $allowed = (array) config('titan-ai.source_policies.'.$source.'.tools', []);
        return $allowed === ['*'] || in_array($toolId, $allowed, true);
    }
}
