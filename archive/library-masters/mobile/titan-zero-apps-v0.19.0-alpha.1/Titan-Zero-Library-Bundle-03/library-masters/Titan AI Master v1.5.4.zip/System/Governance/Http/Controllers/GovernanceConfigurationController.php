<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Http\Controllers;

use App\Extensions\TitanAI\System\Governance\Models\{GovernedMemory, GovernedSkill, PersonaAssignment, SkillEvaluation, ToolPermission};
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class GovernanceConfigurationController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        $companyId = (int) ($user?->company_id ?? 0);
        abort_if(! $user || $companyId < 1 || ! method_exists($user, 'can') || ! $user->can('govern-ai-actions'), 403);

        return view('titan-ai::governance.configuration.index', [
            'memories' => GovernedMemory::where('company_id', $companyId)->latest()->limit(25)->get(),
            'personas' => PersonaAssignment::where('company_id', $companyId)->where('active', true)->limit(250)->get(),
            'skills' => GovernedSkill::where('company_id', $companyId)->limit(250)->get(),
            'permissions' => ToolPermission::where('company_id', $companyId)->limit(500)->get(),
            'evaluations' => SkillEvaluation::where('company_id', $companyId)->latest()->limit(25)->get(),
        ]);
    }
}
