<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Commands;

use Illuminate\Console\Command;

final class CertifyExtensionCommand extends Command
{
    protected $signature = 'titan:titan-ai:certify';
    protected $description = 'Run local Titan AI release-candidate contract checks.';

    public function handle(): int
    {
        $manifest = dirname(__DIR__, 2).'/extension.manifest.json';
        if (! is_file($manifest)) {
            $this->error('extension.manifest.json is missing.');
            return self::FAILURE;
        }

        $decoded = json_decode((string) file_get_contents($manifest), true);
        if (! is_array($decoded) || ($decoded['schema_version'] ?? null) !== '2.2') {
            $this->error('Canonical Manifest v2.2 is required.');
            return self::FAILURE;
        }
        if (($decoded['key'] ?? null) !== 'titan-ai' || ($decoded['folder'] ?? null) !== 'TitanAI') {
            $this->error('Titan AI package identity is inconsistent.');
            return self::FAILURE;
        }

        $this->info('Titan AI local certification contract checks passed.');
        return self::SUCCESS;
    }
}
