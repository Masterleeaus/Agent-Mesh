<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Providers;

use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;
use App\Extensions\TitanAI\System\TitanAI\Integration\ConversationSourcePolicyRegistry;
use App\Extensions\TitanAI\System\TitanAI\Integration\TrustedToolContributionRegistry;
use Illuminate\Support\Facades\Http;
use RuntimeException;

final class OpenAICompatibleProviderGateway implements ProviderExecutionGatewayContract
{
    public function __construct(
        private readonly ProviderRegistry $providers,
        private readonly CredentialResolverContract $credentials,
        private readonly TrustedToolContributionRegistry $trustedTools,
        private readonly ConversationSourcePolicyRegistry $sourcePolicies,
        private readonly MagicAIUsageRecorder $usageRecorder,
        private readonly CostSovereigntyInferenceGuard $costGuard,
    ) {}

    public function key(): string { return 'openai-compatible'; }

    public function complete(TitanAIRequest $request, array $runtimeContext = []): array
    {
        $deployment = (array) ($runtimeContext['deployment'] ?? []);
        $providerId = (string) ($deployment['provider'] ?? config('titan-ai.default_provider', 'openai'));
        $profile = $this->providers->resolve($providerId);
        $hostManaged = strtolower((string)($runtimeContext['provider_cost_owner'] ?? 'customer')) === 'titan';
        $costSelection = $this->costGuard->authorize($request, $runtimeContext, $providerId, $hostManaged);
        $key = $this->credentials->resolve($providerId);
        if ($key === null) throw new RuntimeException("No credential is configured for Titan AI provider [{$providerId}].");

        $model = (string) ($deployment['model'] ?? config('titan-ai.default_model', 'gpt-4o-mini'));
        $messages = $this->messages($request, $runtimeContext);
        $tools = $this->toolSchemas((array) ($runtimeContext['trusted_tools'] ?? []));
        $usage = [];
        $toolCalls = [];

        for ($iteration = 0; $iteration < 5; $iteration++) {
            $payload = ['model'=>$model, 'messages'=>$messages, 'temperature'=>$this->temperature($request)];
            if ($tools !== []) { $payload['tools']=$tools; $payload['tool_choice']='auto'; }
            $response = Http::withToken($key)->acceptJson()->timeout($profile->timeout)->post($profile->endpoint, $payload);
            if (! $response->successful()) throw new RuntimeException('Shared AI provider request failed with HTTP '.$response->status().'.');
            $usage = $this->mergeUsage($usage, (array) $response->json('usage', []));
            $message = (array) $response->json('choices.0.message', []);
            $calls = (array) ($message['tool_calls'] ?? []);
            if ($calls === []) {
                $output = (string) ($message['content'] ?? '');
                $this->usageRecorder->record($request, $model, $output);
                $costReceipt=$this->costGuard->commit($request,$costSelection,$usage,$providerId,$model);
                return ['message'=>$output,'provider'=>$providerId,'model'=>$model,'usage'=>$usage,'tool_calls'=>$toolCalls,'resource_cost_receipt'=>$costReceipt];
            }

            $messages[] = ['role'=>'assistant','content'=>$message['content'] ?? null,'tool_calls'=>$calls];
            foreach ($calls as $call) {
                if (! is_array($call)) continue;
                $function=(array)($call['function']??[]); $name=(string)($function['name']??'');
                if ($name==='') continue;
                $arguments=json_decode((string)($function['arguments']??'{}'),true); if(!is_array($arguments))$arguments=[];
                $mode=$this->trustedTools->executionMode($request,$name,$this->sourcePolicies);
                $entry=['id'=>$call['id']??null,'name'=>$name,'arguments'=>$arguments,'execution'=>$mode];
                if ($mode==='client') {
                    $toolCalls[]=$entry+['status'=>'pending_client'];
                    return ['message'=>(string)($message['content']??''),'provider'=>$providerId,'model'=>$model,'usage'=>$usage,'tool_calls'=>$toolCalls,'finish_reason'=>'client_tool'];
                }
                $result=$this->trustedTools->execute($request,$name,$arguments,$this->sourcePolicies);
                $toolCalls[]=$entry+['result'=>$result,'status'=>'completed'];
                $messages[]=['role'=>'tool','tool_call_id'=>(string)($call['id']??$name),'content'=>json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)];
            }
        }
        throw new RuntimeException('Titan AI tool loop exceeded the maximum of 5 provider turns.');
    }

    public function stream(TitanAIRequest $request, array $runtimeContext, callable $emit): array
    {
        $result=$this->complete($request,$runtimeContext);
        if (($result['message']??'')!=='') $emit(['type'=>'content.delta','delta'=>(string)$result['message']]);
        foreach ((array)($result['tool_calls']??[]) as $call) {
            if (!is_array($call)) continue;
            $emit(['type'=>'tool.call.completed','tool'=>$call]);
        }
        return $result;
    }

    private function messages(TitanAIRequest $request,array $runtimeContext): array
    {
        $deployment=(array)($runtimeContext['deployment']??[]); $messages=[];
        if (($deployment['system_prompt']??null)!==null) $messages[]=['role'=>'system','content'=>(string)$deployment['system_prompt']];
        foreach((array)($runtimeContext['messages']??[]) as $m) if(is_array($m)&&isset($m['role'],$m['content'])) $messages[]=$m;
        $messages[]=['role'=>'user','content'=>$request->message];
        return $messages;
    }

    private function temperature(TitanAIRequest $request): float
    { return max(0.0,min(2.0,(float)($request->payload['temperature']??config('titan-ai.temperature',0.7)))); }

    private function toolSchemas(array $tools): array
    {
        $schemas=[];
        foreach($tools as $entry){ if(!is_array($entry))continue; $id=(string)($entry['id']??''); $schema=(array)($entry['schema']??[]); if($id===''||$schema===[])continue;
            if(($schema['type']??null)==='function'&&isset($schema['function'])){ $f=(array)$schema['function'];$f['name']=$id;$schemas[]=['type'=>'function','function'=>$f]; }
            else $schemas[]=['type'=>'function','function'=>['name'=>$id,'description'=>(string)($schema['description']??$id),'parameters'=>(array)($schema['parameters']??['type'=>'object','properties'=>[]])]];
        }
        return $schemas;
    }

    private function mergeUsage(array $total,array $current): array
    { foreach($current as $k=>$v){ if(is_numeric($v))$total[$k]=(int)($total[$k]??0)+(int)$v; elseif(!array_key_exists($k,$total))$total[$k]=$v; } return $total; }
}
