<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier4\Tools;

use App\Extensions\TitanAI\System\AI\Tier4\Tools\Contracts\AbstractTool;

final class PushNotificationTool extends AbstractTool
{
    public static function id(): string { return 'push-notification'; }
    public static function name(): string { return 'Push Notification Tool'; }
    public static function operation(): string { return 'Deliver one push notification'; }
    public static function requiresApproval(): bool { return true; }
    public static function permissions(): array { return ['communications.push.send']; }
}
