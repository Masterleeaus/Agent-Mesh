<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Providers;

interface CredentialResolverContract
{
    public function resolve(string $providerId): ?string;
}
