<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Runtime;

final class RuntimeAvailabilityGuard
{
    public function enabled(): bool
    {
        return (bool) config('titan-ai.enabled', true);
    }

    public function assertEnabled(): void
    {
        if (! $this->enabled()) {
            throw new \RuntimeException('Titan AI Runtime is disabled.');
        }
    }
}
