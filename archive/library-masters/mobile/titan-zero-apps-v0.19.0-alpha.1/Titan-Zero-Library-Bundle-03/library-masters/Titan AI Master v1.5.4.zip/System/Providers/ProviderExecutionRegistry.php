<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Providers;

use InvalidArgumentException;
use RuntimeException;

final class ProviderExecutionRegistry
{
    /** @var array<string,ProviderExecutionGatewayContract> */
    private array $gateways = [];

    public function __construct(private readonly ProviderRegistry $profiles) {}

    public function register(ProviderExecutionGatewayContract $gateway): void
    {
        $key = strtolower(trim($gateway->key()));
        if ($key === '') throw new InvalidArgumentException('Titan AI provider gateway key cannot be empty.');
        if (isset($this->gateways[$key]) && $this->gateways[$key] !== $gateway) {
            throw new InvalidArgumentException("Titan AI provider gateway [{$key}] is already registered.");
        }
        $this->gateways[$key] = $gateway;
    }

    public function resolve(?string $providerId): ProviderExecutionGatewayContract
    {
        $providerId = strtolower(trim((string) $providerId));
        if ($providerId === '' || $providerId === 'magicai-host') {
            return $this->gateway('magicai-host');
        }

        if (isset($this->gateways[$providerId])) return $this->gateways[$providerId];

        $profile = $this->profiles->resolve($providerId);
        return $this->gateway($profile->driver);
    }

    public function has(string $key): bool
    {
        return isset($this->gateways[strtolower(trim($key))]);
    }

    private function gateway(string $key): ProviderExecutionGatewayContract
    {
        $key = strtolower(trim($key));
        if (! isset($this->gateways[$key])) throw new RuntimeException("Titan AI provider gateway [{$key}] is not registered.");
        return $this->gateways[$key];
    }
}
