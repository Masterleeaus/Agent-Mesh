<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Http\Controllers;

use App\Extensions\TitanAI\System\Governance\Approvals\ApprovalExecutionService;
use App\Extensions\TitanAI\System\Governance\Approvals\ApprovalQueue;
use App\Extensions\TitanAI\System\Governance\Exceptions\ApprovalConflict;
use App\Extensions\TitanAI\System\Governance\Exceptions\WorkCoreExecutionFailed;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class GovernanceApprovalController extends Controller
{
    public function index(Request $request, ApprovalQueue $queue)
    {
        [$user, $companyId] = $this->authorisedActor($request);
        $queue->expirePending($companyId);
        $approvals = $queue->pending($companyId);
        return $request->expectsJson() ? response()->json(['data' => $approvals]) : view('titan-ai::governance.approvals.index', compact('approvals'));
    }

    public function approve(Request $request, string $approvalId, ApprovalExecutionService $service): JsonResponse
    {
        return $this->decide($request, $approvalId, 'approved', $service);
    }

    public function reject(Request $request, string $approvalId, ApprovalExecutionService $service): JsonResponse
    {
        return $this->decide($request, $approvalId, 'rejected', $service);
    }

    private function decide(Request $request, string $approvalId, string $decision, ApprovalExecutionService $service): JsonResponse
    {
        $request->validate(['note' => ['nullable', 'string', 'max:2000']]);
        [$user, $companyId] = $this->authorisedActor($request);
        try {
            $result = $service->decide($approvalId, $decision, (string) $user->getAuthIdentifier(), $companyId, $request->string('note')->toString() ?: null);
            return response()->json($result);
        } catch (ApprovalConflict $e) {
            return response()->json(['message' => $e->getMessage(), 'code' => 'approval_conflict'], 409);
        } catch (WorkCoreExecutionFailed $e) {
            return response()->json(['message' => $e->getMessage(), 'code' => 'workcore_execution_failed', 'retryable' => true], 502);
        }
    }

    /** @return array{0:object,1:int} */
    private function authorisedActor(Request $request): array
    {
        $user = $request->user();
        $companyId = (int) ($user?->company_id ?? 0);
        abort_if(! $user || $companyId < 1 || ! method_exists($user, 'can') || ! $user->can('govern-ai-actions'), 403);
        return [$user, $companyId];
    }
}
