<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Runtime;

use InvalidArgumentException;

final class IntentDefinitionRegistry
{
    /** @var array<string,array<string,mixed>> */
    private array $definitions = [];

    public function __construct()
    {
        foreach ((array) config('titan-ai.intents', []) as $id => $definition) {
            if (is_string($id) && is_array($definition)) {
                $this->register($id, $definition);
            }
        }
        foreach ((array) config('titan-ai.legacy_field_service_intent_aliases', []) as $id => $patterns) {
            if (!isset($this->definitions[$id])) continue;
            $this->definitions[$id]['patterns'] = array_values(array_unique([
                ...(array) $this->definitions[$id]['patterns'],
                ...array_values(array_filter((array) $patterns, 'is_string')),
            ]));
        }
    }

    public function register(string $id, array $definition): void
    {
        $id = trim($id);
        if ($id === '') throw new InvalidArgumentException('Intent id cannot be empty.');
        foreach (['manager','assistant','agent','domain','operation'] as $required) {
            if (!isset($definition[$required]) || trim((string)$definition[$required]) === '') {
                throw new InvalidArgumentException("Intent [{$id}] is missing [{$required}].");
            }
        }
        $definition['patterns'] = array_values(array_unique(array_filter(array_map(
            static fn($value): string => strtolower(trim((string)$value)),
            (array)($definition['patterns'] ?? []),
        ))));
        if ($definition['patterns'] === []) throw new InvalidArgumentException("Intent [{$id}] has no patterns.");
        $this->definitions[$id] = $definition;
    }

    /** @return array<string,array<string,mixed>> */
    public function all(): array
    {
        return $this->definitions;
    }
}
