<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Integration\WorkCore;

use App\Extensions\TitanAI\System\AI\Integration\WorkCore\DTO\WorkerExecutionContext;
use App\Extensions\TitanAI\System\AI\Tier3\Agents\Results\WorkCoreToolResultLike;
use App\Extensions\TitanAI\System\TitanAI\Contracts\WorkCoreRuntimeBridgeContract;
use InvalidArgumentException;

/**
 * Compatibility facade for retained Tier-3 workers.
 *
 * It deliberately contains no WorkCore implementation. Every state-changing
 * call is delegated to the canonical host WorkCore gateway through
 * WorkCoreRuntimeBridgeContract.
 */
final readonly class WorkCoreRuntimeClient
{
    public function __construct(private WorkCoreRuntimeBridgeContract $bridge) {}

    /** @param array<string,mixed> $input */
    public function executeTool(
        string $toolName,
        array $input,
        WorkerExecutionContext $context,
        ?string $aiRunPublicId = null,
        ?string $confirmationId = null,
        ?string $idempotencyKey = null,
    ): WorkCoreToolResultLike {
        [$domain, $operation] = $this->splitToolName($toolName);
        $payload = $input;
        $metadata = $context->metadata() + array_filter([
            'ai_run_public_id' => $aiRunPublicId,
            'confirmation_id' => $confirmationId,
            'idempotency_key' => $idempotencyKey,
        ], static fn (mixed $value): bool => $value !== null && $value !== '');

        $payload['_titan_ai'] = $metadata;
        $payload['_governance'] = [
            'company_id' => $context->companyId,
            'user_id' => (string) $context->actorId,
            'idempotency_key' => $idempotencyKey,
            'worker_id' => $context->workerId,
            'worker_type' => $context->workerType,
            'tier' => $context->tier,
        ];

        $result = $this->bridge->execute($domain, $operation, $payload);
        $data = isset($result['data']) && is_array($result['data']) ? $result['data'] : $result;

        return new WorkCoreToolResultLike(
            data: $data,
            auditId: $this->nullableString($result['audit_id'] ?? $result['auditId'] ?? null),
            eventIds: $this->stringList($result['event_ids'] ?? $result['eventIds'] ?? []),
            replayed: (bool) ($result['replayed'] ?? false),
        );
    }

    /** @return array{0:string,1:string} */
    private function splitToolName(string $toolName): array
    {
        $parts = array_values(array_filter(explode('.', trim($toolName)), static fn (string $part): bool => $part !== ''));
        if (count($parts) < 2) {
            throw new InvalidArgumentException('WorkCore tool names must contain a domain and operation.');
        }
        // `cleaning.*` was the extraction's vertical prefix, not WorkCore ownership.
        if ($parts[0] === 'cleaning' && count($parts) >= 3) {
            array_shift($parts);
        }
        $domain = array_shift($parts);
        $operation = implode('.', $parts);
        if ($domain === null || $domain === '' || $operation === '') {
            throw new InvalidArgumentException('WorkCore tool names must resolve to a non-empty domain and operation.');
        }
        return [$domain, $operation];
    }

    private function nullableString(mixed $value): ?string
    {
        return is_string($value) && $value !== '' ? $value : null;
    }

    /** @return list<string> */
    private function stringList(mixed $value): array
    {
        if (! is_array($value)) return [];
        return array_values(array_filter($value, static fn (mixed $item): bool => is_string($item) && $item !== ''));
    }
}
