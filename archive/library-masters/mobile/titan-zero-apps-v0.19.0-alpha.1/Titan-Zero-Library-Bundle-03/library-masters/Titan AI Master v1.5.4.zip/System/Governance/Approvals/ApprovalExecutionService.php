<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Approvals;

use App\Extensions\TitanAI\System\Governance\Contracts\WorkCoreGateway;
use App\Extensions\TitanAI\System\Governance\Exceptions\WorkCoreExecutionFailed;
use App\Extensions\TitanAI\System\Governance\Repositories\ActionReceiptRepository;
use App\Extensions\TitanAI\System\TitanAI\Runtime\RuntimeAvailabilityGuard;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

final class ApprovalExecutionService
{
    public function __construct(private ApprovalQueue $queue,private WorkCoreGateway $workCore,private ActionReceiptRepository $receipts,private RuntimeAvailabilityGuard $availability) {}

    public function decide(string $approvalId,string $decision,string $actorId,int $companyId,?string $note=null): array
    {
        if ($companyId < 1) {
            throw new InvalidArgumentException('A positive company_id is required.');
        }

        if ($decision==='rejected') {
            $this->queue->resolve($approvalId,'rejected',$actorId,$companyId,$note);
            $this->receipts->updateForApproval($approvalId,$companyId,'rejected',null,null);
            return ['approval_id'=>$approvalId,'status'=>'rejected'];
        }
        if ($decision!=='approved') throw new RuntimeException('Unsupported approval decision.');
        $this->availability->assertEnabled();
        $stored=$this->queue->claimForExecution($approvalId,$actorId,$companyId,$note);
        if (($stored['status'] ?? null)==='executed') return ['approval_id'=>$approvalId,'status'=>'executed','replayed'=>true];
        $payload=$this->decode($stored['payload'] ?? '{}'); $tool=$this->decode($stored['tool_definition'] ?? '{}'); $context=$this->decode($stored['execution_context'] ?? '{}');
        $domain=(string)($stored['domain'] ?? $tool['domain'] ?? ''); $operation=(string)($stored['action'] ?? $tool['operation'] ?? '');
        if ($domain==='' || $operation==='') { $this->queue->failExecution($approvalId,$companyId,'Approval lacks an executable WorkCore domain or operation.'); throw new WorkCoreExecutionFailed('Approval lacks an executable WorkCore domain or operation.'); }
        try {
            $result=$this->workCore->execute($domain,$operation,[...$payload,'_governance'=>[
                'approval_id'=>$approvalId,'approved_by'=>$actorId,'company_id'=>$companyId,'user_id'=>(string)($stored['user_id'] ?? ''),'device_id'=>(string)($stored['device_id'] ?? ''),
                'idempotency_key'=>$context['idempotency_key'] ?? ($stored['idempotency_key'] ?? ('approval:'.$approvalId)),
            ]]);
            $this->queue->completeExecution($approvalId,$companyId); $this->receipts->updateForApproval($approvalId,$companyId,'executed_after_approval',$result,null);
            return ['approval_id'=>$approvalId,'status'=>'executed','result'=>$result];
        } catch(Throwable $e) {
            $this->queue->failExecution($approvalId,$companyId,$e->getMessage()); $this->receipts->updateForApproval($approvalId,$companyId,'execution_failed',null,$e->getMessage());
            throw new WorkCoreExecutionFailed('WorkCore execution failed; the approval remains retryable.',0,$e);
        }
    }
    private function decode(mixed $value): array { if(is_array($value))return $value; $d=json_decode((string)$value,true); return is_array($d)?$d:[]; }
}
