<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Contracts;

use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;

interface GeneralConversationEngineContract
{
    /** @return array<string,mixed> */
    public function complete(TitanAIRequest $request, array $runtimeContext = []): array;

    /** @param callable(array<string,mixed>):void $emit @return array<string,mixed> */
    public function stream(TitanAIRequest $request, array $runtimeContext, callable $emit): array;
}
