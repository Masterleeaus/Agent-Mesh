<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Adapters\WorkCore;

use App\Extensions\TitanAI\System\TitanAI\Contracts\WorkCoreRuntimeBridgeContract;
use Illuminate\Contracts\Container\Container;
use RuntimeException;

final class HostWorkCoreRuntimeBridge implements WorkCoreRuntimeBridgeContract
{
    public function __construct(private readonly Container $container) {}

    public function available(): bool
    {
        $binding=(string)config('titan-ai.workcore.gateway_binding','titan.workcore.ai.gateway');
        return (bool)config('titan-ai.workcore.enabled',true) && $binding !== '' && $this->container->bound($binding);
    }

    public function read(string $domain,string $operation,array $payload): array
    {
        return $this->call('read',$domain,$operation,$payload);
    }

    public function execute(string $domain,string $operation,array $payload): array
    {
        return $this->call('execute',$domain,$operation,$payload);
    }

    private function call(string $method,string $domain,string $operation,array $payload): array
    {
        if (!$this->available()) throw new RuntimeException('Canonical WorkCore AI gateway is not installed or bound. TitanAI remains available for non-operational requests.');
        $binding=(string)config('titan-ai.workcore.gateway_binding');
        $gateway=$this->container->make($binding);
        if (!is_object($gateway) || !method_exists($gateway,$method)) throw new RuntimeException("Canonical WorkCore AI gateway does not implement [{$method}].");
        $result=$gateway->{$method}($domain,$operation,$payload);
        if (is_object($result) && method_exists($result,'toArray')) $result=$result->toArray();
        if (!is_array($result)) throw new RuntimeException('Canonical WorkCore AI gateway returned an unsupported result.');
        return $result;
    }
}
