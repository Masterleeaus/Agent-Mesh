<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier1\Managers;

use App\Extensions\TitanAI\System\AI\Contracts\AbstractAIWorker;

final class StrategicSalesManager extends AbstractAIWorker
{
    public static function id(): string { return 'strategic-sales-manager'; }
    public static function name(): string { return 'Strategic Sales Manager'; }
    public static function tier(): int { return 1; }
    public static function role(): string { return 'manager'; }

    public static function capabilities(): array
    {
        return [
            'Pipeline scenario analysis',
            'Quote conversion optimisation',
            'Revenue-growth planning',
        ];
    }

    public static function permissions(): array
    {
        return [
            'leads.read',
            'quotes.read',
            'analytics.sales',
        ];
    }

    public static function definition(): array
    {
        return parent::definition() + [
            'system_chat' => 'system-ai-chat',
            'runtime' => 'workcore-native-ai-runtime',
            'delegates_to' => 'tier_2_assistants',
            'operational_authority' => 'workcore_api_only',
            'planning_only' => true,
            'requires_governed_execution' => true,
        ];
    }
}
