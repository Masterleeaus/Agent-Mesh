<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance;

use App\Extensions\TitanAI\System\Governance\Exceptions\GovernanceBlocked;

final class GovernanceAvailabilityGuard
{
    public function enabled(): bool
    {
        return (bool) config('titan-ai-governance.enabled', true);
    }

    public function assertEnabled(): void
    {
        if (! $this->enabled()) {
            throw new GovernanceBlocked(
                decision: 'governance_disabled',
                approvalId: null,
                message: 'Titan AI governance is disabled; state-changing AI actions are unavailable.',
            );
        }
    }
}
