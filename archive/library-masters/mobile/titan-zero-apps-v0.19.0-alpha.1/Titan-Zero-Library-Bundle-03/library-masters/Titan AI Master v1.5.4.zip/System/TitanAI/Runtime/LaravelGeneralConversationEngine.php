<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Runtime;

use App\Extensions\TitanAI\System\Providers\ProviderExecutionRegistry;
use App\Extensions\TitanAI\System\TitanAI\Contracts\GeneralConversationEngineContract;
use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;
use App\Extensions\TitanAI\System\TitanAI\Integration\ConversationSourceRegistry;
use RuntimeException;
use Throwable;

final class LaravelGeneralConversationEngine implements GeneralConversationEngineContract
{
    private const FORBIDDEN_PAYLOAD_KEYS = ['provider_endpoint','provider_key','api_key','authorization','endpoint','tools','assistant_deployment'];

    public function __construct(
        private readonly ConversationSourceRegistry $sources,
        private readonly ProviderExecutionRegistry $providers,
    ) {}

    public function complete(TitanAIRequest $request, array $runtimeContext = []): array
    {
        $this->assertNoCredentialInjection($request);
        $source=$this->sources->get($request->conversationSource);
        if($source!==null){$result=$source->complete($request,$runtimeContext);if($result!==null)return $this->normalise($result,$runtimeContext);}

        if(app()->bound('titan.ai.general_conversation')){
            $engine=app('titan.ai.general_conversation');
            $result=is_callable($engine)?$engine($request,$runtimeContext):$engine->complete($request,$runtimeContext);
            return $this->normalise($result,$runtimeContext);
        }

        foreach((array)config('titan-ai.compatible_completion_services',[]) as $class){
            if(!is_string($class)||!class_exists($class))continue;$service=app($class);
            foreach(['complete','chat','generate'] as $method){if(!method_exists($service,$method))continue;try{return $this->normalise($service->{$method}($request,$runtimeContext),$runtimeContext);}catch(Throwable $e){throw new RuntimeException("Configured Titan AI completion service [{$class}] failed.",0,$e);}}
        }

        $provider=(string)($runtimeContext['deployment']['provider']??config('titan-ai.default_provider','magicai-host'));
        return $this->normalise($this->providers->resolve($provider)->complete($request,$runtimeContext),$runtimeContext);
    }

    public function stream(TitanAIRequest $request, array $runtimeContext, callable $emit): array
    {
        $this->assertNoCredentialInjection($request);
        $source=$this->sources->get($request->conversationSource);
        if($source!==null){
            $native=$source->stream($request,$runtimeContext,$emit);
            if($native!==null)return $this->normalise($native,$runtimeContext);
            $complete=$source->complete($request,$runtimeContext);
            if($complete!==null){$result=$this->normalise($complete,$runtimeContext);if($result['message']!=='')$emit(['type'=>'content.delta','delta'=>$result['message']]);return $result;}
        }
        $provider=(string)($runtimeContext['deployment']['provider']??config('titan-ai.default_provider','magicai-host'));
        return $this->normalise($this->providers->resolve($provider)->stream($request,$runtimeContext,$emit),$runtimeContext);
    }

    private function assertNoCredentialInjection(TitanAIRequest $request): void
    {
        foreach(self::FORBIDDEN_PAYLOAD_KEYS as $key) if(array_key_exists($key,$request->payload)) throw new RuntimeException("Runtime payload field [{$key}] is not permitted. Provider endpoints, credentials, deployments and tools are server-controlled.");
    }

    private function normalise(mixed $result,array $runtimeContext): array
    {
        if(is_string($result))$result=['message'=>$result];if(is_object($result)&&method_exists($result,'toArray'))$result=$result->toArray();if(!is_array($result))throw new RuntimeException('The configured general-conversation engine returned an unsupported response.');
        return [
            'message'=>(string)($result['message']??$result['text']??$result['content']??''),
            'provider'=>$result['provider']??($runtimeContext['deployment']['provider']??null),
            'engine'=>$result['engine']??null,
            'model'=>$result['model']??($runtimeContext['deployment']['model']??null),
            'finish_reason'=>$result['finish_reason']??null,
            'usage'=>(array)($result['usage']??[]),
            'citations'=>(array)($result['citations']??[]),
            'generative_ui'=>$result['generative_ui']??null,
            'tool_calls'=>(array)($result['tool_calls']??[]),
        ];
    }
}
