<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Providers;

use App\Domains\Engine\Enums\EngineEnum;
use App\Domains\Engine\Services\AnthropicService;
use App\Domains\Engine\Services\GeminiService;
use App\Domains\Entity\Enums\EntityEnum;
use App\Domains\Entity\Facades\Entity;
use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;
use App\Extensions\TitanAI\System\TitanAI\Integration\ConversationSourcePolicyRegistry;
use App\Extensions\TitanAI\System\TitanAI\Integration\TrustedToolContributionRegistry;
use App\Helpers\Classes\ApiHelper;
use App\Helpers\Classes\Helper;
use App\Models\Usage;
use App\Models\User;
use Exception;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;
use OpenAI as OpenAIMain;
use OpenAI\Contracts\ClientContract;
use RuntimeException;
use Throwable;

/**
 * Production bridge into MagicAI's host-owned provider, model and credit stack.
 * TitanAI owns orchestration/tool authorization; the host remains authoritative
 * for provider credentials, plan models and credit charging.
 */
final class MagicAIHostProviderGateway implements ProviderExecutionGatewayContract
{
    private const MAX_TOOL_TURNS = 6;

    public function __construct(
        private readonly TrustedToolContributionRegistry $trustedTools,
        private readonly ConversationSourcePolicyRegistry $sourcePolicies,
        private readonly CostSovereigntyInferenceGuard $costGuard,
    ) {}

    public function key(): string { return 'magicai-host'; }

    public function complete(TitanAIRequest $request, array $runtimeContext = []): array
    {
        $runtimeContext['intelligence_source']=$runtimeContext['intelligence_source']??'TITAN_SYSTEM_AI';
        $costSelection=$this->costGuard->authorize($request,$runtimeContext,'magicai-host',true);
        [$user,$model,$engine] = $this->identityAndModel($request,$runtimeContext);
        $messages = $this->messages($request,$runtimeContext);
        $system = (string) (($runtimeContext['deployment']['system_prompt'] ?? '') ?: '');
        $tools = (array) ($runtimeContext['trusted_tools'] ?? []);
        $toolCalls=[];
        $final='';

        for($turn=0;$turn<self::MAX_TOOL_TURNS;$turn++){
            $providerTurn=$this->providerTurn($engine,$model,$system,$messages,$tools,$this->webSearch($runtimeContext));
            $content=(string)($providerTurn['content']??'');
            $calls=(array)($providerTurn['calls']??[]);
            if($content!=='') { $final=$content; $messages[]=['role'=>'assistant','content'=>$content]; }
            if($calls===[]) {
                $this->charge($user,$model,$final);
                $costReceipt=$this->costGuard->commit($request,$costSelection,[],'magicai-host',$model->value);
                return ['message'=>$final,'provider'=>'magicai-host','engine'=>$engine->value,'model'=>$model->value,'usage'=>[],'tool_calls'=>$toolCalls,'finish_reason'=>'stop','resource_cost_receipt'=>$costReceipt];
            }

            foreach($calls as $call){
                if(!is_array($call))continue;
                $name=(string)($call['name']??''); if($name==='')continue;
                $args=(array)($call['arguments']??[]); $id=(string)($call['id']??$name);
                $mode=$this->trustedTools->executionMode($request,$name,$this->sourcePolicies);
                $record=['id'=>$id,'name'=>$name,'arguments'=>$args,'execution'=>$mode];
                if($mode==='client'){
                    $toolCalls[]=$record+['status'=>'pending_client'];
                    $this->charge($user,$model,$final);
                    return ['message'=>$final,'provider'=>'magicai-host','engine'=>$engine->value,'model'=>$model->value,'usage'=>[],'tool_calls'=>$toolCalls,'finish_reason'=>'client_tool'];
                }
                $result=$this->trustedTools->execute($request,$name,$args,$this->sourcePolicies);
                $toolCalls[]=$record+['result'=>$result,'status'=>'completed'];
                $messages[]=['role'=>'user','content'=>$this->toolResultMessage($name,$id,$result)];
            }
        }

        throw new RuntimeException('Titan AI MagicAI provider tool loop exceeded '.self::MAX_TOOL_TURNS.' turns.');
    }

    public function stream(TitanAIRequest $request, array $runtimeContext, callable $emit): array
    {
        $runtimeContext['intelligence_source']=$runtimeContext['intelligence_source']??'TITAN_SYSTEM_AI';
        $costSelection=$this->costGuard->authorize($request,$runtimeContext,'magicai-host',true);
        [$user,$model,$engine] = $this->identityAndModel($request,$runtimeContext);
        if($engine !== EngineEnum::OPEN_AI){
            // Host services in the supplied base extensions expose reliable non-streaming
            // Anthropic/Gemini calls. Keep event semantics stable and fail no functionality:
            // execute through the same shared gateway, then emit the normalized result.
            $result=$this->complete($request,$runtimeContext);
            if(($result['message']??'')!=='') $emit(['type'=>'content.delta','delta'=>(string)$result['message']]);
            foreach((array)($result['tool_calls']??[]) as $tool) if(is_array($tool)) $emit(['type'=>'tool.call.completed','tool'=>$tool]);
            return $result;
        }

        $system=(string)(($runtimeContext['deployment']['system_prompt']??'')?:'');
        $messages=$this->messages($request,$runtimeContext);
        if($system!=='') array_unshift($messages,['role'=>'system','content'=>$system]);
        $tools=(array)($runtimeContext['trusted_tools']??[]);
        $openAiTools=$this->openAiTools($tools);
        $toolCalls=[]; $final='';
        ApiHelper::setOpenAiKey();
        /** @var ClientContract $client */
        $client=app(ClientContract::class);

        for($turn=0;$turn<self::MAX_TOOL_TURNS;$turn++){
            $payload=['model'=>$model->value,'messages'=>$this->normalizeTextMessages($messages)];
            if($openAiTools!==[]){$payload['tools']=$openAiTools;$payload['tool_choice']='auto';}
            $stream=$client->chat()->createStreamed($payload);
            $content=''; $acc=[];
            foreach($stream as $chunk){
                $delta=$chunk->choices[0]->delta;
                $text=$delta->content??null;
                if(is_string($text)&&$text!==''){ $content.=$text; $final.=$text; $emit(['type'=>'content.delta','delta'=>$text]); }
                foreach($delta->toolCalls??[] as $tc){
                    $idx=(int)($tc->index??0); $acc[$idx]??=['id'=>'','name'=>'','arguments'=>''];
                    if(!empty($tc->id))$acc[$idx]['id']=$tc->id;
                    if(!empty($tc->function->name))$acc[$idx]['name']=$tc->function->name;
                    if(!empty($tc->function->arguments))$acc[$idx]['arguments'].=$tc->function->arguments;
                }
            }
            if($acc===[]){ $this->charge($user,$model,$final); $costReceipt=$this->costGuard->commit($request,$costSelection,[],'magicai-host',$model->value); return ['message'=>$final,'provider'=>'magicai-host','engine'=>$engine->value,'model'=>$model->value,'usage'=>[],'tool_calls'=>$toolCalls,'finish_reason'=>'stop','resource_cost_receipt'=>$costReceipt]; }

            $assistantCalls=[]; $toolResultMessages=[];
            foreach($acc as $tc){
                $name=(string)$tc['name']; if($name==='')continue; $id=(string)($tc['id']?:$name);
                $args=json_decode((string)$tc['arguments'],true); if(!is_array($args))$args=[];
                $mode=$this->trustedTools->executionMode($request,$name,$this->sourcePolicies);
                $emit(['type'=>'tool.call.started','tool'=>['id'=>$id,'name'=>$name,'arguments'=>$args,'execution'=>$mode]]);
                $record=['id'=>$id,'name'=>$name,'arguments'=>$args,'execution'=>$mode];
                $assistantCalls[]=['id'=>$id,'type'=>'function','function'=>['name'=>$name,'arguments'=>json_encode($args,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]];
                if($mode==='client'){
                    $record['status']='pending_client'; $toolCalls[]=$record;
                    $emit(['type'=>'tool.call.completed','tool'=>$record]);
                    $this->charge($user,$model,$final);
                    return ['message'=>$final,'provider'=>'magicai-host','engine'=>$engine->value,'model'=>$model->value,'usage'=>[],'tool_calls'=>$toolCalls,'finish_reason'=>'client_tool'];
                }
                $result=$this->trustedTools->execute($request,$name,$args,$this->sourcePolicies);
                $record+=['result'=>$result,'status'=>'completed']; $toolCalls[]=$record;
                $emit(['type'=>'tool.call.completed','tool'=>$record]);
                $toolResultMessages[]=['role'=>'tool','tool_call_id'=>$id,'content'=>json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)];
            }
            $messages[]=['role'=>'assistant','content'=>$content!==''?$content:null,'tool_calls'=>$assistantCalls];
            foreach($toolResultMessages as $toolMessage) $messages[]=$toolMessage;
        }
        throw new RuntimeException('Titan AI MagicAI streaming tool loop exceeded '.self::MAX_TOOL_TURNS.' turns.');
    }

    /** @return array{0:User,1:EntityEnum,2:EngineEnum} */
    private function identityAndModel(TitanAIRequest $request,array $runtimeContext): array
    {
        $user=User::query()->find((int)$request->userId);
        if(!$user || (int)($user->company_id??0)!==$request->companyId) throw new RuntimeException('Titan AI principal user does not belong to the requested company.');
        $requested=trim((string)($runtimeContext['deployment']['model']??''));
        $model=$requested!==''?EntityEnum::tryFrom($requested):null;
        if($requested!==''&&$model===null) throw new RuntimeException("Titan AI MagicAI model [{$requested}] is not registered by the host.");
        $engine=$model?->engine()??Helper::defaultEngine();
        $model??=$engine->getDefaultWordModel(null);
        if(!$model instanceof EntityEnum) throw new RuntimeException('MagicAI did not resolve a default word model.');
        $creditDriver=Entity::driver($model)->forUser($user);
        if(!$creditDriver->hasCreditBalance()) throw new RuntimeException('MagicAI principal user has insufficient credits for the selected model.');
        return [$user,$model,$engine];
    }

    private function messages(TitanAIRequest $request,array $runtimeContext): array
    {
        $messages=[];
        foreach((array)($runtimeContext['messages']??[]) as $m){ if(is_array($m)&&isset($m['role'],$m['content']))$messages[]=$m; }
        $last=end($messages); $lastText=is_array($last)?$this->contentText($last['content']??''):'';
        if(trim($lastText)!==trim($request->message)) $messages[]=['role'=>'user','content'=>$request->message];
        return $messages;
    }

    private function providerTurn(EngineEnum $engine,EntityEnum $model,string $system,array $messages,array $tools,bool $webSearch): array
    {
        return match($engine){
            EngineEnum::ANTHROPIC=>$this->anthropicTurn($model,$system,$messages,$tools),
            EngineEnum::GEMINI=>$this->geminiTurn($model,$system,$messages,$tools,$webSearch),
            EngineEnum::DEEP_SEEK=>$this->deepSeekTurn($model,$system,$messages,$tools),
            EngineEnum::X_AI=>$this->xAiTurn($model,$system,$messages,$tools),
            default=>$this->openAiTurn($model,$system,$messages,$tools,$webSearch),
        };
    }

    private function openAiTurn(EntityEnum $model,string $system,array $messages,array $tools,bool $webSearch): array
    {
        $apiKey=ApiHelper::setOpenAiKey();
        if($webSearch&&$tools===[]){
            $response=Http::withToken($apiKey)->acceptJson()->timeout(120)->post('https://api.openai.com/v1/responses',['model'=>$model->value,'tools'=>[['type'=>'web_search_preview']],'input'=>array_merge($system!==''?[['role'=>'system','content'=>$system]]:[],$this->normalizeTextMessages($messages))]);
            if($response->failed()) throw new RuntimeException('MagicAI OpenAI web-search request failed with HTTP '.$response->status().'.');
            $text=collect($response->json('output')??[])->where('type','message')->pluck('content')->flatten(1)->where('type','output_text')->pluck('text')->implode('');
            return ['content'=>$text,'calls'=>[]];
        }
        $payload=['model'=>$model->value,'messages'=>array_merge($system!==''?[['role'=>'system','content'=>$system]]:[],$this->normalizeTextMessages($messages))];
        $schemas=$this->openAiTools($tools); if($schemas!==[]){$payload['tools']=$schemas;$payload['tool_choice']='auto';}
        $response=Http::withToken($apiKey)->acceptJson()->timeout(120)->post('https://api.openai.com/v1/chat/completions',$payload);
        if($response->failed()) throw new RuntimeException('MagicAI OpenAI request failed with HTTP '.$response->status().'.');
        return $this->parseOpenAi((array)$response->json('choices.0.message',[]));
    }

    private function anthropicTurn(EntityEnum $model,string $system,array $messages,array $tools): array
    {
        $service=app(AnthropicService::class)->setSystem($system)->setMessages($this->normalizeForAnthropic($messages))->setStream(false);
        if(method_exists($service,'setModel'))$service->setModel($model->value);
        $schemas=$this->anthropicTools($tools); if($schemas!==[]&&method_exists($service,'setTools'))$service->setTools($schemas);
        $response=$service->stream(); if($response->failed()) throw new RuntimeException('MagicAI Anthropic request failed with HTTP '.$response->status().'.');
        $content=(array)($response->json('content')??[]); $text='';$calls=[];
        foreach($content as $block){ if(!is_array($block))continue; if(($block['type']??'')==='text')$text.=(string)($block['text']??''); if(($block['type']??'')==='tool_use')$calls[]=['id'=>(string)($block['id']??$block['name']??''),'name'=>(string)($block['name']??''),'arguments'=>(array)($block['input']??[])]; }
        return ['content'=>$text,'calls'=>$calls];
    }

    private function geminiTurn(EntityEnum $model,string $system,array $messages,array $tools,bool $webSearch): array
    {
        $history=$this->normalizeForGemini($messages,$system); $service=app(GeminiService::class)->setHistory($history);
        $geminiTools=$this->geminiTools($tools); if($webSearch)$geminiTools[]=['google_search'=>(object)[]]; if($geminiTools!==[]&&method_exists($service,'setTools'))$service->setTools($geminiTools);
        $response=$service->generateContent($model->value); if($response->failed())throw new RuntimeException('MagicAI Gemini request failed with HTTP '.$response->status().'.');
        $parts=(array)($response->json('candidates.0.content.parts')??[]);$text='';$calls=[];
        foreach($parts as $part){if(!is_array($part))continue;if(isset($part['text']))$text.=(string)$part['text'];if(isset($part['functionCall'])&&is_array($part['functionCall'])){$fc=$part['functionCall'];$calls[]=['id'=>(string)($fc['id']??$fc['name']??''),'name'=>(string)($fc['name']??''),'arguments'=>(array)($fc['args']??[])];}}
        return ['content'=>$text,'calls'=>$calls];
    }

    private function deepSeekTurn(EntityEnum $model,string $system,array $messages,array $tools): array
    {
        ApiHelper::setDeepseekKey(); $apiKey=(string)config('deepseek.api_key'); $payload=['model'=>$model->value,'messages'=>array_merge($system!==''?[['role'=>'system','content'=>$system]]:[],$this->normalizeTextMessages($messages)),'stream'=>false];
        $schemas=$this->openAiTools($tools);if($schemas!==[]){$payload['tools']=$schemas;$payload['tool_choice']='auto';}
        $response=(new Client)->post('https://api.deepseek.com/chat/completions',['timeout'=>120,'headers'=>['Content-Type'=>'application/json','Accept'=>'application/json','Authorization'=>"Bearer {$apiKey}"],'json'=>$payload]);
        $body=json_decode($response->getBody()->getContents(),true);if($response->getStatusCode()>=400)throw new RuntimeException('MagicAI DeepSeek request failed with HTTP '.$response->getStatusCode().'.');
        return $this->parseOpenAi((array)($body['choices'][0]['message']??[]));
    }

    private function xAiTurn(EntityEnum $model,string $system,array $messages,array $tools): array
    {
        $apiKey=ApiHelper::setXAiKey(); $payload=['model'=>$model->value,'messages'=>array_merge($system!==''?[['role'=>'system','content'=>$system]]:[],$this->normalizeTextMessages($messages))];$schemas=$this->openAiTools($tools);if($schemas!==[]){$payload['tools']=$schemas;$payload['tool_choice']='auto';}
        $result=OpenAIMain::factory()->withApiKey($apiKey)->withBaseUri('https://api.x.ai/v1')->make()->chat()->create($payload);$message=$result->choices[0]->message;$calls=[];
        foreach($message->toolCalls??[] as $call)$calls[]=['id'=>(string)($call->id??$call->function->name??''),'name'=>(string)($call->function->name??''),'arguments'=>json_decode((string)($call->function->arguments??'{}'),true)??[]];
        return ['content'=>(string)($message->content??''),'calls'=>$calls];
    }

    private function parseOpenAi(array $message): array
    { $calls=[];foreach((array)($message['tool_calls']??[]) as $call){if(!is_array($call))continue;$f=(array)($call['function']??[]);$args=json_decode((string)($f['arguments']??'{}'),true);$calls[]=['id'=>(string)($call['id']??$f['name']??''),'name'=>(string)($f['name']??''),'arguments'=>is_array($args)?$args:[]];}return ['content'=>(string)($message['content']??''),'calls'=>$calls]; }

    private function openAiTools(array $tools): array
    { $out=[];foreach($tools as $entry){if(!is_array($entry))continue;$id=(string)($entry['id']??'');$schema=(array)($entry['schema']??[]);if($id===''||$schema===[])continue;if(($schema['type']??null)==='function'&&isset($schema['function'])){$f=(array)$schema['function'];$f['name']=$id;$out[]=['type'=>'function','function'=>$f];}else{$out[]=['type'=>'function','function'=>['name'=>$id,'description'=>(string)($schema['description']??$id),'parameters'=>(array)($schema['parameters']??['type'=>'object','properties'=>[]])]];}}return $out; }
    private function anthropicTools(array $tools): array
    { $out=[];foreach($this->openAiTools($tools) as $tool){$f=(array)$tool['function'];$out[]=['name'=>$f['name'],'description'=>$f['description']??$f['name'],'input_schema'=>$f['parameters']??['type'=>'object','properties'=>[]]];}return $out; }
    private function geminiTools(array $tools): array
    { $defs=[];foreach($this->openAiTools($tools) as $tool){$f=(array)$tool['function'];$defs[]=['name'=>$f['name'],'description'=>$f['description']??$f['name'],'parameters'=>$f['parameters']??['type'=>'object','properties'=>[]]];}return $defs!==[]?[['functionDeclarations'=>$defs]]:[]; }

    private function normalizeTextMessages(array $messages): array
    {
        $out=[];
        foreach($messages as $m){
            if(!is_array($m)||!isset($m['role']))continue;
            $item=['role'=>(string)$m['role'],'content'=>$this->contentText($m['content']??'')];
            if(isset($m['tool_calls'])&&is_array($m['tool_calls']))$item['tool_calls']=$m['tool_calls'];
            if(isset($m['tool_call_id'])&&is_scalar($m['tool_call_id']))$item['tool_call_id']=(string)$m['tool_call_id'];
            $out[]=$item;
        }
        return $out;
    }
    private function normalizeForAnthropic(array $messages): array
    { return array_values(array_filter(array_map(function($m){if(!is_array($m)||!isset($m['role']))return null;$role=(string)$m['role'];if($role==='system')$role='user';if($role==='tool')$role='user';return ['role'=>$role,'content'=>$this->contentText($m['content']??'')];},$messages))); }
    private function normalizeForGemini(array $messages,string $system): array
    { $out=[];if($system!=='')$out[]=['role'=>'user','parts'=>[['text'=>$system]]];foreach($messages as $m){if(!is_array($m)||!isset($m['role']))continue;$out[]=['role'=>((string)$m['role']==='assistant'?'model':'user'),'parts'=>[['text'=>$this->contentText($m['content']??'')]]];}return $out; }
    private function contentText(mixed $content): string
    { if(is_scalar($content))return trim((string)$content);if(!is_array($content))return ''; $text='';foreach($content as $part){if(is_array($part)&&isset($part['text']))$text.=(string)$part['text'];elseif(is_scalar($part))$text.=(string)$part;}return trim($text); }
    private function webSearch(array $runtimeContext): bool
    { return (bool)($runtimeContext['deployment']['metadata']['web_search']??false); }
    private function toolResultMessage(string $name,string $id,array $result): string
    { return 'Trusted tool result for '.$name.' ['.$id.']: '.json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\nContinue the task using this result. Do not invent additional tool results."; }

    private function charge(User $user,EntityEnum $model,string $output): void
    {
        if($output==='')return;
        try{$driver=Entity::driver($model)->forUser($user);$driver->input($output)->calculateCredit()->decreaseCredit();Usage::getSingle()->updateWordCounts($driver->calculate());}
        catch(Throwable $e){throw new RuntimeException('MagicAI provider completed but credit accounting failed; refusing an unaccounted AI result.',0,$e);}
    }
}
