<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions;

use App\Extensions\TitanAI\System\AI\Contracts\AbstractAIWorker;

final class ServiceChecklistAgent extends AbstractAIWorker
{
    public static function id(): string { return 'service-checklist-agent'; }
    public static function name(): string { return 'Service Checklist Agent'; }
    public static function tier(): int { return 3; }
    public static function role(): string { return 'agent'; }
    public static function capabilities(): array { return [
            'Generate service-specific checklists',
            'Track offline checklist completion',
            'Flag missing safety and quality evidence',
    ]; }
    public static function permissions(): array { return [
            'checklists.create',
            'jobs.read',
            'quality.assurance',
    ]; }
    public static function definition(): array
    {
        return parent::definition() + [
            'system_chat' => 'system-ai-chat',
            'runtime' => 'workcore-native-ai-runtime',
            'delegates_to' => 'tier_4_tools',
            'operational_authority' => 'workcore_api_only',
            'execution_mode' => 'governed_delegation',
            'requires_confirmation_for_mutation' => true,
        ];
    }
}
