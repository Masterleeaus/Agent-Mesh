<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Runtime;

use App\Extensions\TitanAI\System\TitanAI\Capabilities\SharedCapabilityRegistry;
use App\Extensions\TitanAI\System\TitanAI\Context\KnowledgeContextProvider;
use App\Extensions\TitanAI\System\TitanAI\Context\MemoryContextProvider;
use App\Extensions\TitanAI\System\TitanAI\Contracts\AssistantDeploymentResolverContract;
use App\Extensions\TitanAI\System\TitanAI\Contracts\GeneralConversationEngineContract;
use App\Extensions\TitanAI\System\TitanAI\Contracts\KnowledgeContextProviderContract;
use App\Extensions\TitanAI\System\TitanAI\Contracts\MemoryContextProviderContract;
use App\Extensions\TitanAI\System\TitanAI\Contracts\TitanAIRuntimeContract;
use App\Extensions\TitanAI\System\TitanAI\Deployments\AssistantDeploymentResolver;
use App\Extensions\TitanAI\System\TitanAI\Integration\ConversationSourcePolicyRegistry;
use App\Extensions\TitanAI\System\TitanAI\Integration\ConversationSourceRegistry;
use App\Extensions\TitanAI\System\TitanAI\Integration\HostPermissionResolver;
use App\Extensions\TitanAI\System\TitanAI\Integration\SourceContextRegistry;
use App\Extensions\TitanAI\System\TitanAI\Integration\TrustedToolContributionRegistry;
use App\Extensions\TitanAI\System\TitanAI\Runtime\Skills\FieldServiceSkillContextProvider;
use App\Extensions\TitanAI\System\TitanAI\Runtime\Skills\FieldServiceSkillRegistry;
use App\Extensions\TitanAI\System\TitanAI\Runtime\Tools\FieldServiceToolContextProvider;
use App\Extensions\TitanAI\System\TitanAI\Runtime\Tools\FieldServiceToolRegistry;
use Illuminate\Support\ServiceProvider;

final class TitanAIRuntimeServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(RuntimeAvailabilityGuard::class);
        $this->app->singleton(IntentDefinitionRegistry::class);
        $this->app->singleton(IntentGateway::class);
        $this->app->singleton(FieldServiceSkillRegistry::class);
        $this->app->singleton(FieldServiceSkillContextProvider::class);
        $this->app->singleton(FieldServiceToolRegistry::class);
        $this->app->singleton(FieldServiceToolContextProvider::class);
        $this->app->singleton(Tier3AgentCapabilityCatalog::class);
        $this->app->singleton(WorkCoreToolMappingRegistry::class);
        $this->app->singleton(WorkerRouteRegistry::class);
        $this->app->singleton(WorkerPermissionGuard::class);
        $this->app->singleton(DynamicWorkerSelector::class);
        $this->app->singleton(AgentExecutionPathResolver::class);
        $this->app->singleton(AssistantDelegationGraph::class);
        $this->app->singleton(ConfidenceFallbackPolicy::class);
        $this->app->singleton(AssistantChainPlanner::class);
        $this->app->singleton(FiveTierOrchestrator::class);

        // Cross-extension integration registries. Surface extensions register themselves in boot().
        $this->app->singleton(ConversationSourceRegistry::class);
        $this->app->singleton(ConversationSourcePolicyRegistry::class);
        $this->app->singleton(TrustedToolContributionRegistry::class);
        $this->app->singleton(SourceContextRegistry::class);
        $this->app->singleton(HostPermissionResolver::class);

        $this->app->singleton(AssistantDeploymentResolver::class);
        $this->app->alias(AssistantDeploymentResolver::class, AssistantDeploymentResolverContract::class);
        $this->app->singleton(MemoryContextProvider::class);
        $this->app->alias(MemoryContextProvider::class, MemoryContextProviderContract::class);
        $this->app->singleton(KnowledgeContextProvider::class);
        $this->app->alias(KnowledgeContextProvider::class, KnowledgeContextProviderContract::class);
        $this->app->singleton(SharedCapabilityRegistry::class);
        $this->app->singleton(LaravelGeneralConversationEngine::class);
        $this->app->alias(LaravelGeneralConversationEngine::class, GeneralConversationEngineContract::class);
        $this->app->singleton(UnifiedTitanAIRuntime::class);
        $this->app->alias(UnifiedTitanAIRuntime::class, TitanAIRuntimeContract::class);
    }
}
