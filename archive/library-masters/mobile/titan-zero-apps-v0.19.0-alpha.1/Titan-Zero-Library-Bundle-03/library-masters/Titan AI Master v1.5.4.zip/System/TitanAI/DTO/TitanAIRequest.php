<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\DTO;

use InvalidArgumentException;

final class TitanAIRequest
{
    /** @param array<int,array<string,mixed>> $messages @param array<string,mixed> $payload @param array<int,array<string,mixed>> $attachments @param array<int,string> $toolPermissions */
    public function __construct(
        public readonly string $message,
        public readonly int $companyId,
        public readonly string $userId,
        public readonly string $deviceId,
        public readonly string $channel,
        public readonly string $conversationSource,
        public readonly ?string $conversationId = null,
        public readonly ?string $assistantDeploymentId = null,
        public readonly ?string $template = null,
        public readonly ?string $workflowId = null,
        public readonly ?string $idempotencyKey = null,
        public readonly string $responseMode = 'json',
        public readonly array $messages = [],
        public readonly array $payload = [],
        public readonly array $attachments = [],
        public readonly array $toolPermissions = [],
        public readonly array $availablePermissions = [],
        public readonly string $actorType = 'user',
        public readonly ?string $actorId = null,
    ) {
        if ($companyId < 1) {
            throw new InvalidArgumentException('Titan AI request field [companyId] must be a positive company ID.');
        }

        foreach (['message' => $message, 'userId' => $userId, 'deviceId' => $deviceId, 'channel' => $channel, 'conversationSource' => $conversationSource, 'actorType' => $actorType] as $field => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException("Titan AI request field [{$field}] is required.");
            }
        }
    }

    /** @return array<string,mixed> */
    public function context(): array
    {
        return [
            'company_id' => $this->companyId,
            'user_id' => $this->userId,
            'principal_user_id' => $this->userId,
            'actor_type' => $this->actorType,
            'actor_id' => $this->actorId ?: $this->userId,
            'device_id' => $this->deviceId,
            'conversation_id' => $this->conversationId,
            'conversation_source' => $this->conversationSource,
            'assistant_deployment_id' => $this->assistantDeploymentId,
            'channel' => $this->channel,
            'template' => $this->template,
            'workflow_id' => $this->workflowId,
            'idempotency_key' => $this->idempotencyKey,
            'tool_permissions' => $this->toolPermissions,
            'available_permissions' => $this->availablePermissions,
            'response_mode' => $this->responseMode,
        ];
    }
}
