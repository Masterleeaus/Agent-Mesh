<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Console;

use App\Extensions\TitanAI\System\Governance\Memory\MemoryDecayService;
use Illuminate\Console\Command;

final class DecayGovernedMemory extends Command
{
    protected $signature = 'titan-ai:memory-decay {--company= : Restrict maintenance to one company ID}';
    protected $description = 'Expire and decay governed AI memory.';

    public function handle(MemoryDecayService $service): int
    {
        $raw = $this->option('company');
        $companyId = $raw === null ? null : (int) $raw;
        if ($companyId !== null && $companyId < 1) {
            $this->error('The --company option must be a positive company ID.');
            return self::INVALID;
        }

        $result = $service->run($companyId);
        $this->info(json_encode($result, JSON_THROW_ON_ERROR));
        return self::SUCCESS;
    }
}
