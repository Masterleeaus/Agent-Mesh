<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance;

use App\Extensions\TitanAI\System\Governance\Contracts\WorkCoreGateway;
use App\Extensions\TitanAI\System\TitanAI\Contracts\WorkCoreRuntimeBridgeContract;
use App\Extensions\TitanAI\System\TitanAI\Runtime\WorkCoreToolMappingRegistry;
use RuntimeException;

final class WorkCoreAccessGateway implements WorkCoreGateway
{
    public function __construct(
        private readonly WorkCoreRuntimeBridgeContract $runtime,
        private readonly WorkCoreToolMappingRegistry $toolMappings,
    ) {}

    public function read(string $domain, string $operation, array $payload): array
    {
        return $this->call('read', $domain, $operation, $payload);
    }

    public function execute(string $domain, string $operation, array $payload): array
    {
        return $this->call('execute', $domain, $operation, $payload);
    }

    private function call(string $mode, string $domain, string $operation, array $payload): array
    {
        $governance = (array) ($payload['_governance'] ?? []);
        $companyId = (int) ($governance['company_id'] ?? 0);
        $actorId = trim((string) ($governance['user_id'] ?? ''));

        if ($companyId < 1 || $actorId === '') {
            throw new RuntimeException('WorkCore execution requires validated company_id and actor context from TitanAI governance.');
        }

        // State-changing operations must be explicitly declared in the canonical WorkCore map.
        if ($mode === 'execute') {
            $this->toolMappings->toolFor($domain, $operation);
        }

        $payload['_governance']['company_id'] = $companyId;
        $payload['_governance']['user_id'] = $actorId;

        return $mode === 'read'
            ? $this->runtime->read($domain, $operation, $payload)
            : $this->runtime->execute($domain, $operation, $payload);
    }
}
