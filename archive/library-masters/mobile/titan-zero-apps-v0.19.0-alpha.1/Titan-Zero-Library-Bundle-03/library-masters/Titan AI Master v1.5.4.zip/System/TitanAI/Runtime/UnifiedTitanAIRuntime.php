<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Runtime;

use App\Extensions\TitanAI\System\TitanAI\Capabilities\SharedCapabilityRegistry;
use App\Extensions\TitanAI\System\TitanAI\Contracts\AssistantDeploymentResolverContract;
use App\Extensions\TitanAI\System\TitanAI\Contracts\GeneralConversationEngineContract;
use App\Extensions\TitanAI\System\TitanAI\Contracts\KnowledgeContextProviderContract;
use App\Extensions\TitanAI\System\TitanAI\Contracts\MemoryContextProviderContract;
use App\Extensions\TitanAI\System\TitanAI\Contracts\TitanAIRuntimeContract;
use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;
use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIResponse;
use App\Extensions\TitanAI\System\TitanAI\Integration\ConversationSourcePolicyRegistry;
use App\Extensions\TitanAI\System\TitanAI\Integration\ConversationSourceRegistry;
use App\Extensions\TitanAI\System\TitanAI\Integration\SourceContextRegistry;
use App\Extensions\TitanAI\System\TitanAI\Integration\TrustedToolContributionRegistry;
use App\Extensions\TitanAI\System\TitanAI\Runtime\Tools\FieldServiceToolContextProvider;
use Illuminate\Support\Str;
use Throwable;

final class UnifiedTitanAIRuntime implements TitanAIRuntimeContract
{
    public function __construct(
        private readonly FiveTierOrchestrator $orchestrator,
        private readonly GeneralConversationEngineContract $conversationEngine,
        private readonly AssistantDeploymentResolverContract $deployments,
        private readonly MemoryContextProviderContract $memory,
        private readonly KnowledgeContextProviderContract $knowledge,
        private readonly SharedCapabilityRegistry $capabilities,
        private readonly RuntimeAvailabilityGuard $availability,
        private readonly FieldServiceToolContextProvider $toolContext,
        private readonly ConversationSourceRegistry $sources,
        private readonly ConversationSourcePolicyRegistry $sourcePolicies,
        private readonly SourceContextRegistry $sourceContext,
        private readonly TrustedToolContributionRegistry $trustedTools,
    ) {}

    public function execute(TitanAIRequest $request): TitanAIResponse
    {
        $runUuid = (string) Str::uuid();
        if (! $this->availability->enabled()) return $this->disabledResponse($request, $runUuid);

        try {
            [$deployment, $capabilities, $messages, $trustedTools] = $this->prepare($request);
            $result = $this->orchestrate($request, $runUuid, $deployment, $capabilities, $messages, $trustedTools);
            if ((bool) ($result['handled'] ?? false)) {
                return $this->businessActionResponse($request, $runUuid, $deployment, $capabilities, $result);
            }

            $general = $this->conversationEngine->complete($request, [
                'run_uuid' => $runUuid,
                'deployment' => $deployment,
                'capabilities' => $capabilities,
                'messages' => $messages,
                'trusted_tools' => $trustedTools,
            ]);

            return $this->conversationResponse($request, $runUuid, $deployment, $capabilities, $general);
        } catch (Throwable $exception) {
            report($exception);
            return $this->failedResponse($request, $runUuid, $exception);
        }
    }

    public function stream(TitanAIRequest $request, callable $emit): TitanAIResponse
    {
        $runUuid = (string) Str::uuid();
        $emit(['type' => 'run.started', 'run_uuid' => $runUuid, 'channel' => $request->channel, 'source' => $request->conversationSource]);

        if (! $this->availability->enabled()) {
            $response = $this->disabledResponse($request, $runUuid);
            $this->emitFinal($response, $emit);
            return $response;
        }

        try {
            [$deployment, $capabilities, $messages, $trustedTools] = $this->prepare($request);
            $result = $this->orchestrate($request, $runUuid, $deployment, $capabilities, $messages, $trustedTools);
            if ((bool) ($result['handled'] ?? false)) {
                $response = $this->businessActionResponse($request, $runUuid, $deployment, $capabilities, $result);
                $this->emitFinal($response, $emit);
                return $response;
            }

            $runtimeContext = [
                'run_uuid' => $runUuid,
                'deployment' => $deployment,
                'capabilities' => $capabilities,
                'messages' => $messages,
                'trusted_tools' => $trustedTools,
            ];

            $general = $this->conversationEngine->stream($request, $runtimeContext, $emit);
            $response = $this->conversationResponse($request, $runUuid, $deployment, $capabilities, $general);
            $this->emitFinal($response, $emit, emitContent: false);
            return $response;
        } catch (Throwable $exception) {
            report($exception);
            $response = $this->failedResponse($request, $runUuid, $exception);
            $this->emitFailureFinal($response, $emit);
            return $response;
        }
    }

    /** @return array{0:array<string,mixed>,1:array<int,array<string,mixed>>,2:array<int,array<string,mixed>>,3:array<int,array<string,mixed>>} */
    private function prepare(TitanAIRequest $request): array
    {
        $deployment = $this->deployments->resolve($request);
        $declaredIds = array_values(array_filter((array) ($deployment['capabilities'] ?? []), 'is_string'));
        $allowedIds = $this->sourcePolicies->filterCapabilities($request, $declaredIds);
        $capabilities = $this->capabilities->all($allowedIds);

        $adapterContext = $this->sources->get($request->conversationSource)?->context($request) ?? [];
        $messages = [
            ...$adapterContext,
            ...$this->sourceContext->context($request),
            ...$this->knowledge->context($request),
            ...$this->memory->context($request),
            ...$this->toolContext->context($request),
            ...$request->messages,
        ];
        $trustedTools = $this->trustedTools->schemasFor($request, $this->sourcePolicies);

        return [$deployment, $capabilities, $messages, $trustedTools];
    }

    /** @param array<string,mixed> $deployment @param array<int,array<string,mixed>> $capabilities @param array<int,array<string,mixed>> $messages @param array<int,array<string,mixed>> $trustedTools */
    private function orchestrate(TitanAIRequest $request, string $runUuid, array $deployment, array $capabilities, array $messages, array $trustedTools): array
    {
        return $this->orchestrator->handle(
            $request->message,
            [
                ...$request->payload,
                'messages' => $messages,
                'attachments' => $request->attachments,
                'assistant_deployment' => $deployment,
                'capabilities' => $capabilities,
                'trusted_tools' => $trustedTools,
            ],
            [...$request->context(), 'ai_run_uuid' => $runUuid, 'business_actions_allowed' => $this->sourcePolicies->allowsBusinessActions($request)],
        );
    }

    /** @param array<string,mixed> $deployment @param array<int,array<string,mixed>> $capabilities @param array<string,mixed> $general */
    private function conversationResponse(TitanAIRequest $request, string $runUuid, array $deployment, array $capabilities, array $general): TitanAIResponse
    {
        return new TitanAIResponse(
            runUuid: $runUuid,
            status: (string) ($general['status'] ?? 'completed'),
            handled: true,
            message: $this->scalar($general['message'] ?? $general['text'] ?? $general['content'] ?? null),
            data: [
                'execution_mode' => 'conversation',
                'conversation_source' => $request->conversationSource,
                'conversation_id' => $request->conversationId,
                'assistant_deployment_id' => $deployment['id'] ?? null,
                'assistant' => $deployment,
                'channel' => $request->channel,
                'principal_user_id' => $request->userId,
                'actor_type' => $request->actorType,
                'actor_id' => $request->actorId ?: $request->userId,
                'provider' => $general['provider'] ?? ($deployment['provider'] ?? null),
                'model' => $general['model'] ?? ($deployment['model'] ?? null),
                'capabilities' => $capabilities,
                'tool_calls' => $general['tool_calls'] ?? [],
                'citations' => $general['citations'] ?? [],
                'generative_ui' => $general['generative_ui'] ?? null,
                'usage' => $general['usage'] ?? [],
                'requires_legacy_fallback' => false,
            ],
        );
    }

    private function disabledResponse(TitanAIRequest $request, string $runUuid): TitanAIResponse
    {
        return new TitanAIResponse(
            runUuid: $runUuid,
            status: 'disabled',
            handled: true,
            message: 'Titan AI Runtime is disabled.',
            data: [
                'execution_mode'=>'disabled',
                'conversation_source'=>$request->conversationSource,
                'conversation_id'=>$request->conversationId,
                'channel'=>$request->channel,
                'error_code'=>'titan_ai_disabled',
                'requires_legacy_fallback'=>false,
            ],
        );
    }

    private function failedResponse(TitanAIRequest $request, string $runUuid, Throwable $exception): TitanAIResponse
    {
        return new TitanAIResponse(
            runUuid: $runUuid,
            status: 'failed',
            handled: false,
            message: 'Titan AI could not complete this request because the configured source/provider path failed.',
            data: [
                'execution_mode'=>'conversation',
                'conversation_source'=>$request->conversationSource,
                'conversation_id'=>$request->conversationId,
                'channel'=>$request->channel,
                'error_code'=>'shared_provider_unavailable',
                'exception_class'=>$exception::class,
                'requires_legacy_fallback'=>false,
            ],
        );
    }

    /** @param array<string,mixed> $deployment @param array<int,array<string,mixed>> $capabilities @param array<string,mixed> $result */
    private function businessActionResponse(TitanAIRequest $request, string $runUuid, array $deployment, array $capabilities, array $result): TitanAIResponse
    {
        return new TitanAIResponse(
            runUuid: $runUuid,
            status: (string) ($result['status'] ?? 'completed'),
            handled: true,
            message: $this->extractMessage($result),
            data: [
                'execution_mode'=>'business_action',
                'conversation_source'=>$request->conversationSource,
                'conversation_id'=>$request->conversationId,
                'assistant_deployment_id'=>$deployment['id'] ?? null,
                'assistant'=>$deployment,
                'channel'=>$request->channel,
                'principal_user_id'=>$request->userId,
                'actor_type'=>$request->actorType,
                'actor_id'=>$request->actorId ?: $request->userId,
                'route'=>$result['route'] ?? null,
                'result'=>$result['result'] ?? null,
                'approval_id'=>$result['approval_id'] ?? null,
                'reason'=>$result['reason'] ?? null,
                'capabilities'=>$capabilities,
                'requires_legacy_fallback'=>false,
            ],
        );
    }

    /** @param callable(array<string,mixed>):void $emit */
    private function emitFinal(TitanAIResponse $response, callable $emit, bool $emitContent = true): void
    {
        if ($emitContent && $response->message) $emit(['type'=>'content.delta','delta'=>$response->message]);
        if (($response->data['generative_ui'] ?? null) !== null) $emit(['type'=>'generative_ui','data'=>$response->data['generative_ui']]);
        $emit(['type'=>'run.result','data'=>$response->toArray()]);
        $emit(['type'=>'run.completed','run_uuid'=>$response->runUuid,'status'=>$response->status]);
    }

    /** @param callable(array<string,mixed>):void $emit */
    private function emitFailureFinal(TitanAIResponse $response, callable $emit): void
    {
        $emit(['type'=>'run.result','data'=>$response->toArray()]);
        $emit([
            'type'=>'run.failed',
            'run_uuid'=>$response->runUuid,
            'status'=>$response->status,
            'error_code'=>$response->data['error_code'] ?? 'runtime_failure',
        ]);
    }

    private function extractMessage(array $result): ?string
    {
        $value = $result['result']['message'] ?? $result['result']['text'] ?? $result['message'] ?? null;
        if (($message = $this->scalar($value)) !== null) return $message;
        if (($result['status'] ?? null) === 'needs_review') return (string) ($result['reason'] ?? 'This action requires approval.');
        return 'Titan AI completed the requested operation.';
    }

    private function scalar(mixed $value): ?string
    {
        if (! is_scalar($value)) return null;
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}
