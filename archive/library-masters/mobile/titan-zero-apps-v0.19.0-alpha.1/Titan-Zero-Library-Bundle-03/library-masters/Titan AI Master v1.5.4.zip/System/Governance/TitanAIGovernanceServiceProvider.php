<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance;

use App\Extensions\TitanAI\System\Governance\Approvals\ApprovalQueue;
use App\Extensions\TitanAI\System\Governance\Approvals\DatabaseApprovalQueue;
use App\Extensions\TitanAI\System\Governance\Booking\WorkCoreBookingCoordinator;
use App\Extensions\TitanAI\System\Governance\Contracts\ModelInferenceClient;
use App\Extensions\TitanAI\System\Governance\Contracts\WorkCoreGateway;
use App\Extensions\TitanAI\System\Governance\Council\ConfiguredModelReviewer;
use App\Extensions\TitanAI\System\Governance\Council\OperationalCouncil;
use App\Extensions\TitanAI\System\Governance\Council\RiskClassifier;
use App\Extensions\TitanAI\System\Governance\Inference\OpenAIResponsesClient;
use App\Extensions\TitanAI\System\Governance\Repositories\ActionReceiptRepository;
use App\Extensions\TitanAI\System\Governance\Repositories\DatabaseActionReceiptRepository;
use App\Extensions\TitanAI\System\Governance\Tools\GovernedToolExecutor;
use Illuminate\Support\ServiceProvider;

final class TitanAIGovernanceServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(GovernanceAvailabilityGuard::class);
        $this->app->singleton(WorkCoreGateway::class,WorkCoreAccessGateway::class);
        $this->app->singleton(ApprovalQueue::class,DatabaseApprovalQueue::class);
        $this->app->singleton(ActionReceiptRepository::class,DatabaseActionReceiptRepository::class);
        $this->app->singleton(ModelInferenceClient::class,OpenAIResponsesClient::class);
        $this->app->singleton(RiskClassifier::class);
        $this->app->singleton(OperationalCouncil::class,function($app){
            $reviewers=[];
            foreach((array)config('titan-ai-governance.reviewers',[]) as $reviewer) {
                if(is_array($reviewer) && isset($reviewer['model'])) $reviewers[]=new ConfiguredModelReviewer((string)$reviewer['model'],(string)($reviewer['role'] ?? 'verifier'),$app->make(ModelInferenceClient::class));
                elseif(is_string($reviewer) && $app->bound($reviewer)) $reviewers[]=$app->make($reviewer);
            }
            return new OperationalCouncil($reviewers);
        });
        $this->app->singleton(GovernedToolExecutor::class);
        $this->app->singleton(WorkCoreBookingCoordinator::class);
    }
}
