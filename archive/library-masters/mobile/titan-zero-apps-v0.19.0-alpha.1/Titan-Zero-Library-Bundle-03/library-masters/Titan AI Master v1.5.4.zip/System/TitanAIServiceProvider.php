<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanAI\System\Adapters\WorkCore\HostWorkCoreRuntimeBridge;
use App\Extensions\TitanAI\System\Commands\CertifyExtensionCommand;
use App\Extensions\TitanAI\System\AI\Integration\WorkCore\WorkCoreRuntimeClient;
use App\Extensions\TitanAI\System\Diagnostics\TitanAIDiagnosticsService;
use App\Extensions\TitanAI\System\Governance\TitanAIGovernanceServiceProvider;
use App\Extensions\TitanAI\System\Providers\ConfigCredentialResolver;
use App\Extensions\TitanAI\System\Providers\CredentialResolverContract;
use App\Extensions\TitanAI\System\Providers\MagicAIHostProviderGateway;
use App\Extensions\TitanAI\System\Providers\MagicAIUsageRecorder;
use App\Extensions\TitanAI\System\Providers\OpenAICompatibleProviderGateway;
use App\Extensions\TitanAI\System\Providers\ProviderExecutionRegistry;
use App\Extensions\TitanAI\System\Providers\ProviderRegistry;
use App\Extensions\TitanAI\System\TitanAI\Contracts\WorkCoreRuntimeBridgeContract;
use App\Extensions\TitanAI\System\TitanAI\Runtime\TitanAIRuntimeServiceProvider;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\ServiceProvider;
use Throwable;

final class TitanAIServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface,UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__.'/../config/titan-ai.php','titan-ai');
        $this->mergeConfigFrom(__DIR__.'/../config/titan-ai-governance.php','titan-ai-governance');
        $this->app->singleton(ProviderRegistry::class);
        $this->app->singleton(CredentialResolverContract::class,ConfigCredentialResolver::class);
        $this->app->singleton(MagicAIUsageRecorder::class);
        $this->app->singleton(OpenAICompatibleProviderGateway::class);
        $this->app->singleton(MagicAIHostProviderGateway::class);
        $this->app->singleton(ProviderExecutionRegistry::class, function ($app): ProviderExecutionRegistry {
            $registry = new ProviderExecutionRegistry($app->make(ProviderRegistry::class));
            $registry->register($app->make(MagicAIHostProviderGateway::class));
            $registry->register($app->make(OpenAICompatibleProviderGateway::class));
            return $registry;
        });
        $this->app->singleton(WorkCoreRuntimeBridgeContract::class,HostWorkCoreRuntimeBridge::class);
        $this->app->singleton(WorkCoreRuntimeClient::class);
        $this->app->register(TitanAIGovernanceServiceProvider::class);
        $this->app->register(TitanAIRuntimeServiceProvider::class);
        $this->app->singleton(TitanAIDiagnosticsService::class);
    }

    public function boot(): void
    {
        if ($this->app->runningInConsole()) {
            $this->commands([CertifyExtensionCommand::class]);
        }
        $this->loadMigrationsFrom(__DIR__.'/../database/migrations');
        $this->loadViewsFrom(__DIR__.'/../resources/views','titan-ai');
        if (is_dir(__DIR__.'/../resources/lang')) $this->loadTranslationsFrom(__DIR__.'/../resources/lang','titan-ai');
        $this->publishes([
            __DIR__.'/../config/titan-ai.php'=>config_path('titan-ai.php'),
            __DIR__.'/../config/titan-ai-governance.php'=>config_path('titan-ai-governance.php'),
        ],'titan-ai-config');
        $this->registerRoutes();
    }

    public function registerKey(): string { return 'titan-ai'; }

    public static function uninstall(): void
    {
        // Operational cleanup only. Company-scoped TitanAI data is retained by default and WorkCore data is never touched.
        try { Cache::forget('titan-ai:diagnostics'); } catch(Throwable) {}
    }

    private function registerRoutes(): void
    {
        /** @var Router $router */ $router=$this->app['router'];
        $router->group(['middleware'=>['web','auth'],'prefix'=>'dashboard/user/titan-ai','as'=>'dashboard.user.titan-ai.'], static function(Router $router): void {
            require __DIR__.'/../routes/user.php';
        });
    }
}
