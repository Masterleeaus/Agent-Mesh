<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Providers;

final readonly class ProviderProfile
{
    public function __construct(
        public string $id,
        public string $driver,
        public string $endpoint,
        public array $allowedHosts,
        public int $timeout,
    ) {}
}
