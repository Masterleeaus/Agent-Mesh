<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Council;

use App\Extensions\TitanAI\System\Governance\Enums\RiskLevel;
use InvalidArgumentException;

final readonly class CouncilCase
{
    public function __construct(
        public string $action,
        public array $proposedPayload,
        public array $facts,
        public array $constraints,
        public RiskLevel $risk,
        public int $companyId,
        public string $userId,
        public string $deviceId,
        public ?string $idempotencyKey = null,
    ) {
        if ($companyId < 1) {
            throw new InvalidArgumentException('Titan AI governance requires a positive company_id.');
        }
        if (trim($userId) === '' || trim($deviceId) === '') {
            throw new InvalidArgumentException('Titan AI governance requires user_id and device_id.');
        }
    }

    public function toArray(): array
    {
        return [
            'action' => $this->action,
            'proposed_payload' => $this->proposedPayload,
            'facts' => $this->facts,
            'constraints' => $this->constraints,
            'risk_level' => $this->risk->value,
            'company_id' => $this->companyId,
            'user_id' => $this->userId,
            'device_id' => $this->deviceId,
            'idempotency_key' => $this->idempotencyKey,
        ];
    }
}
