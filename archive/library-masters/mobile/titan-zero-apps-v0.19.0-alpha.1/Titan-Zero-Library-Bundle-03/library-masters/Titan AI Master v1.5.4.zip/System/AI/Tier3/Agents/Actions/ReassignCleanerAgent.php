<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions;

use App\Extensions\TitanAI\System\AI\Contracts\AbstractAIWorker;

final class ReassignCleanerAgent extends AbstractAIWorker
{
    public static function id(): string { return 'reassign-worker-agent'; }
    public static function name(): string { return 'Reassign Cleaner Agent'; }
    public static function tier(): int { return 3; }
    public static function role(): string { return 'agent'; }

    public static function capabilities(): array
    {
        return [
            'Replace the cleaner assigned to one job'
        ];
    }

    public static function permissions(): array
    {
        return [
            'jobs.read',
            'workers.read',
            'assignments.update'
        ];
    }

    public static function definition(): array
    {
        return parent::definition() + [
            'system_chat' => 'system-ai-chat',
            'runtime' => 'workcore-native-ai-runtime',
            'delegates_to' => 'tier_4_tools',
            'operational_authority' => 'workcore_api_only',
        ];
    }
}
