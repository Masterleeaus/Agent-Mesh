<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Integration;

use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;
use InvalidArgumentException;

final class SourceContextRegistry
{
    /** @var array<string,array<int,callable|object>> */
    private array $contributors = [];

    public function register(string $source, callable|object $contributor): void
    {
        $source = strtolower(trim($source));
        if ($source === '') throw new InvalidArgumentException('Titan AI source context key cannot be empty.');
        $this->contributors[$source][] = $contributor;
    }

    /** @return array<int,array<string,mixed>> */
    public function context(TitanAIRequest $request): array
    {
        $messages = [];
        foreach ($this->contributors[strtolower(trim($request->conversationSource))] ?? [] as $contributor) {
            $value = is_callable($contributor)
                ? $contributor($request)
                : (method_exists($contributor, 'context') ? $contributor->context($request) : []);
            if (! is_array($value)) continue;
            foreach ($value as $message) if (is_array($message) && isset($message['role'])) $messages[] = $message;
        }
        return $messages;
    }
}
