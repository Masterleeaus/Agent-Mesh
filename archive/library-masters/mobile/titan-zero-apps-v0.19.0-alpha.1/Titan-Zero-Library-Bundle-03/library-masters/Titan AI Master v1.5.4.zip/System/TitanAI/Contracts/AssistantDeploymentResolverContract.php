<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Contracts;

use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;

interface AssistantDeploymentResolverContract
{
    /** @return array<string,mixed> */
    public function resolve(TitanAIRequest $request): array;
}
