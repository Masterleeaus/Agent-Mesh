<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions;

use App\Extensions\TitanAI\System\AI\Contracts\AbstractAIWorker;

final class RescheduleJobAgent extends AbstractAIWorker
{
    public static function id(): string { return 'reschedule-job-agent'; }
    public static function name(): string { return 'Reschedule Job Agent'; }
    public static function tier(): int { return 3; }
    public static function role(): string { return 'agent'; }

    public static function capabilities(): array
    {
        return [
            'Change one existing job appointment'
        ];
    }

    public static function permissions(): array
    {
        return [
            'jobs.read',
            'jobs.reschedule'
        ];
    }

    public static function definition(): array
    {
        return parent::definition() + [
            'system_chat' => 'system-ai-chat',
            'runtime' => 'workcore-native-ai-runtime',
            'delegates_to' => 'tier_4_tools',
            'operational_authority' => 'workcore_api_only',
        ];
    }
}
