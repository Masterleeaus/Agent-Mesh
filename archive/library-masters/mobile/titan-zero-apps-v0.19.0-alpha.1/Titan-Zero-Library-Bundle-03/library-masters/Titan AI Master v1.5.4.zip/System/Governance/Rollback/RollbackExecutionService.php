<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Rollback;

use App\Extensions\TitanAI\System\Governance\Contracts\WorkCoreGateway;
use App\Extensions\TitanAI\System\Governance\Models\ActionReceiptRecord;
use App\Extensions\TitanAI\System\TitanAI\Runtime\RuntimeAvailabilityGuard;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

final class RollbackExecutionService
{
    public function __construct(private WorkCoreGateway $workCore, private RuntimeAvailabilityGuard $availability) {}

    public function execute(string $receiptId, string $actorId, int $companyId, ?string $reason = null): array
    {
        if ($companyId < 1) throw new InvalidArgumentException('A positive company_id is required.');
        $this->availability->assertEnabled();
        $claim = $this->claim($receiptId, $companyId);
        if (($claim['replayed'] ?? false) === true) return ['receipt_id' => $receiptId, 'status' => 'rolled_back', 'replayed' => true, 'result' => (array) ($claim['result'] ?? [])];

        $contract = (array) ($claim['contract'] ?? []);
        try {
            $result = $this->workCore->execute((string) $contract['domain'], (string) $contract['operation'], [
                'authoritative_id' => $contract['authoritative_id'], 'original_receipt_id' => $receiptId,
                '_governance' => ['rollback' => true, 'approved_by' => $actorId, 'user_id' => $actorId, 'company_id' => $companyId, 'reason' => $reason, 'idempotency_key' => 'rollback:'.$receiptId],
            ]);
        } catch (Throwable $exception) {
            ActionReceiptRecord::query()->whereKey($receiptId)->where('company_id', $companyId)->where('status', 'rollback_pending')->update([
                'status' => 'rollback_failed', 'rollback_failure_reason' => mb_substr($exception->getMessage(), 0, 2000), 'updated_at' => now(),
            ]);
            throw $exception;
        }

        $updated = ActionReceiptRecord::query()->whereKey($receiptId)->where('company_id', $companyId)->where('status', 'rollback_pending')->update([
            'status' => 'rolled_back', 'rollback_result' => json_encode($result, JSON_THROW_ON_ERROR), 'rollback_failure_reason' => null,
            'rolled_back_by' => $actorId, 'rolled_back_at' => now(), 'updated_at' => now(),
        ]);
        if ($updated !== 1) {
            $current = ActionReceiptRecord::query()->whereKey($receiptId)->where('company_id', $companyId)->first();
            if ($current && $current->status === 'rolled_back') {
                $stored = json_decode((string) ($current->rollback_result ?? '{}'), true);
                return ['receipt_id' => $receiptId, 'status' => 'rolled_back', 'replayed' => true, 'result' => is_array($stored) ? $stored : []];
            }
            throw new RuntimeException('Rollback completion conflicted with another process.');
        }
        return ['receipt_id' => $receiptId, 'status' => 'rolled_back', 'replayed' => false, 'result' => $result];
    }

    private function claim(string $receiptId, int $companyId): array
    {
        $connection = (new ActionReceiptRecord())->getConnection();
        return $connection->transaction(function () use ($receiptId, $companyId): array {
            $receipt = ActionReceiptRecord::query()->whereKey($receiptId)->where('company_id', $companyId)->lockForUpdate()->first();
            if (! $receipt) throw new RuntimeException('Action receipt was not found.');
            if ($receipt->status === 'rolled_back') {
                $stored = json_decode((string) ($receipt->rollback_result ?? '{}'), true);
                return ['replayed' => true, 'result' => is_array($stored) ? $stored : []];
            }
            if (! in_array($receipt->status, ['executed', 'executed_after_approval', 'rollback_failed', 'rollback_pending'], true)) throw new RuntimeException('Only successfully executed or retryable rollback actions can be rolled back.');
            $contract = json_decode((string) ($receipt->rollback_contract ?? ''), true);
            if (! is_array($contract) || ($contract['supported'] ?? false) !== true) throw new RuntimeException('This action does not support rollback.');
            foreach (['domain', 'operation', 'authoritative_id'] as $key) if (! isset($contract[$key]) || (string) $contract[$key] === '') throw new RuntimeException('Rollback contract is incomplete.');
            $receipt->status = 'rollback_pending'; $receipt->rollback_attempts = ((int) $receipt->rollback_attempts) + 1;
            $receipt->rollback_started_at = now(); $receipt->rollback_failure_reason = null; $receipt->save();
            return ['replayed' => false, 'contract' => $contract];
        });
    }
}
