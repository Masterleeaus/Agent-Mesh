<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Approvals;

interface ApprovalQueue
{
    public function enqueue(array $request): string;
    public function resolve(string $approvalId,string $decision,string $actorId,int $companyId,?string $note=null): void;
    public function find(string $approvalId,int $companyId): ?array;
    public function pending(int $companyId): array;
    public function expirePending(?int $companyId=null): int;
    public function claimForExecution(string $approvalId,string $actorId,int $companyId,?string $note=null): array;
    public function completeExecution(string $approvalId,int $companyId): void;
    public function failExecution(string $approvalId,int $companyId,string $error): void;
}
