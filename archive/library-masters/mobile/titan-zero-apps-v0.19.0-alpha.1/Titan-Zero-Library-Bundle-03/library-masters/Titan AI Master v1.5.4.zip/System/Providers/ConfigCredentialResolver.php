<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Providers;

use Throwable;

final class ConfigCredentialResolver implements CredentialResolverContract
{
    public function resolve(string $providerId): ?string
    {
        $value = config('titan-ai.providers.'.$providerId.'.api_key');
        if (is_scalar($value) && trim((string) $value) !== '') {
            return trim((string) $value);
        }

        // No host-owned credential fallback: managed System AI is routed explicitly through MagicAIHostProviderGateway.

        return null;
    }
}
