<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Tools;

use App\Extensions\TitanAI\System\Governance\Approvals\ApprovalQueue;
use App\Extensions\TitanAI\System\Governance\Contracts\WorkCoreGateway;
use App\Extensions\TitanAI\System\Governance\Council\CouncilCase;
use App\Extensions\TitanAI\System\Governance\Council\OperationalCouncil;
use App\Extensions\TitanAI\System\Governance\Council\RiskClassifier;
use App\Extensions\TitanAI\System\Governance\Exceptions\GovernanceBlocked;
use App\Extensions\TitanAI\System\Governance\GovernanceAvailabilityGuard;
use App\Extensions\TitanAI\System\TitanAI\Runtime\RuntimeAvailabilityGuard;
use App\Extensions\TitanAI\System\TitanAI\Runtime\WorkCoreToolMappingRegistry;
use App\Extensions\TitanAI\System\Governance\Receipts\ActionReceipt;
use App\Extensions\TitanAI\System\Governance\Repositories\ActionReceiptRepository;
use Illuminate\Support\Str;

final class GovernedToolExecutor
{
    public function __construct(
        private WorkCoreGateway $workCore,
        private OperationalCouncil $council,
        private RiskClassifier $classifier,
        private ApprovalQueue $approvals,
        private ActionReceiptRepository $receipts,
        private GovernanceAvailabilityGuard $availability,
        private RuntimeAvailabilityGuard $runtimeAvailability,
        private WorkCoreToolMappingRegistry $toolMappings,
    ) {}

    public function execute(GovernedToolDefinition $tool,array $payload,array $context): array
    {
        $this->runtimeAvailability->assertEnabled();
        $this->availability->assertEnabled();
        $risk=$this->classifier->classify($tool->operation,['risk_level'=>$tool->riskLevel]);
        $case=new CouncilCase($tool->operation,$payload,(array)($context['facts'] ?? []),(array)($context['constraints'] ?? []),$risk,
            (int)($context['company_id'] ?? 0),(string)($context['user_id'] ?? ''),(string)($context['device_id'] ?? ''),$context['idempotency_key'] ?? null);
        if ($case->idempotencyKey) {
            $replay=$this->receipts->findExecutedByIdempotency($case->companyId,$tool->operation,$case->idempotencyKey);
            if ($replay) return [...$replay['result'],'_idempotent_replay'=>true,'_action_receipt'=>['receipt_id'=>$replay['receipt_id'],'status'=>$replay['status']]];
        }
        $decision=$this->council->deliberate($case);
        if (($decision['approval_required'] ?? false)===true || ($decision['decision'] ?? null)==='human_review') {
            $approvalId=$this->approvals->enqueue([
                'company_id'=>$case->companyId,'user_id'=>$case->userId,'device_id'=>$case->deviceId,'action'=>$tool->operation,'domain'=>$tool->domain,
                'risk_level'=>$risk->value,'payload'=>$payload,'tool_definition'=>get_object_vars($tool),'execution_context'=>$context,
                'council_result'=>$decision,'idempotency_key'=>$case->idempotencyKey,
            ]);
            $this->receipts->persist(new ActionReceipt((string)Str::uuid(),$tool->operation,'approval_required',$risk->value,$decision,$approvalId,null,null),$case,$context);
            throw new GovernanceBlocked('human_review',$approvalId,'Governed action requires human approval.');
        }
        if (($decision['decision'] ?? null)!=='approve') {
            $this->receipts->persist(new ActionReceipt((string)Str::uuid(),$tool->operation,'blocked',$risk->value,$decision,null,null,null),$case,$context);
            throw new GovernanceBlocked((string)($decision['decision'] ?? 'unknown'));
        }
        $result=$this->workCore->execute($tool->domain,$tool->operation,[...$payload,'_governance'=>[
            'risk_level'=>$risk->value,'council'=>$decision,'company_id'=>$case->companyId,'user_id'=>$case->userId,'device_id'=>$case->deviceId,
            'idempotency_key'=>$case->idempotencyKey,'manager'=>$context['manager'] ?? null,'assistant'=>$context['assistant'] ?? null,'agent'=>$context['agent'] ?? null,
            'conversation_id'=>$context['conversation_id'] ?? null,'workflow_id'=>$context['workflow_id'] ?? null,'channel'=>$context['channel'] ?? null,
            'agent_execution_path'=>$context['agent_execution_path'] ?? null,
        ]]);
        $rollback=null;
        if ($tool->rollbackSupported) {
            $target=$this->toolMappings->rollbackFor($tool->domain,$tool->operation);
            $authoritativeId=$result['id'] ?? $result['job_id'] ?? null;
            if ($target !== null && $authoritativeId !== null && (string)$authoritativeId !== '') {
                $rollback=['supported'=>true,'domain'=>$target['domain'],'operation'=>$target['operation'],'authoritative_id'=>$authoritativeId];
            }
        }
        $receipt=new ActionReceipt((string)Str::uuid(),$tool->operation,'executed',$risk->value,$decision,null,$result,$rollback);
        $this->receipts->persist($receipt,$case,$context);
        return [...$result,'_action_receipt'=>$receipt->toArray()];
    }
}
