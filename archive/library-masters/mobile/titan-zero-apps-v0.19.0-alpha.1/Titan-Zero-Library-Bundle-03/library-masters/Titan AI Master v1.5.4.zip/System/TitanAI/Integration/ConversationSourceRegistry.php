<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Integration;

use InvalidArgumentException;

final class ConversationSourceRegistry
{
    /** @var array<string,ConversationSourceAdapterContract> */
    private array $sources = [];

    public function register(ConversationSourceAdapterContract $adapter): void
    {
        $this->registerAs($adapter->source(), $adapter);
    }

    public function registerAs(string $source, ConversationSourceAdapterContract $adapter): void
    {
        $key = trim(strtolower($source));
        if ($key === '') {
            throw new InvalidArgumentException('Titan AI conversation source key cannot be empty.');
        }
        if (isset($this->sources[$key]) && $this->sources[$key] !== $adapter) {
            throw new InvalidArgumentException("Titan AI conversation source [{$key}] is already registered.");
        }
        $this->sources[$key] = $adapter;
    }

    public function has(string $source): bool
    {
        return isset($this->sources[trim(strtolower($source))]);
    }

    public function get(string $source): ?ConversationSourceAdapterContract
    {
        return $this->sources[trim(strtolower($source))] ?? null;
    }

    /** @return array<int,string> */
    public function keys(): array
    {
        return array_keys($this->sources);
    }
}
