<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Registry;

final class TitanAIWorkerRegistry
{
    /** @return array<int,list<class-string>> */
    public static function legacyByTier(): array
    {
        return [
            1 => [
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\AIConsciousnessOrchestrator::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\BiologicalBusinessEvolutionManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\BusinessSingularityManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\CollectiveIntelligenceManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\CustomerManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\FieldStaffManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\FinanceManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\FractalBusinessGrowthManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\InfiniteLearningLoopManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\MarketingManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\OperationsManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\QualitySafetyManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\QuantumBusinessOrchestrator::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\QuantumTimeTravelManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\RealityManipulationManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\SalesManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicBusinessGrowthManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicCustomerExperienceManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicCustomerManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicFieldStaffManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicFinanceManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicMarketingManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicOperationsManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicPerformanceAnalyticsManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicQualitySafetyManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicRiskComplianceManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicSalesManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicSupplyChainManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\StrategicTechnologyInnovationManager::class,
                \App\Extensions\TitanAI\System\AI\Tier1\Managers\SuppliesEquipmentManager::class,
            ],
            2 => [
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\AutonomousDispatchAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\AutonomousPricingAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\CleaningVerticalAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\CustomerAnalyticsAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\CustomerServiceAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\DispatchAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\ElectricalVerticalAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\FieldServiceAnalyticsAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\FleetManagementAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\HVACVerticalAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\HandymenVerticalAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentCustomerSuccessAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentEmergencyResponseAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentFleetAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentInventoryAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentInvoicingAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentLeadScoringAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentMarketingAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentPaymentsAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentQualityAssuranceAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentQuotingAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentRecurringServicesAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentReportingAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentRoutePlanningAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentSafetyAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentStaffCoordinationAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\IntelligentTrainingAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\InventoryAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\InvoicingAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\LandscapingVerticalAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\LeadManagementAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\MarketingAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\PaymentsAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\PlumbingVerticalAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\PoolServiceVerticalAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\PredictiveMaintenanceAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\PredictiveMaintenanceOptimizationAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\PressureWashingVerticalAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\QualityInspectionAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\QuotingAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\RecurringServicesAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\ReportingAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\RoutePlanningAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\SafetyComplianceAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\SchedulingAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\StaffCoordinationAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\TechnicianPerformanceAssistant::class,
                \App\Extensions\TitanAI\System\AI\Tier2\Assistants\TrainingAndOnboardingAssistant::class,
            ],
            3 => [
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\AcceptQuoteAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\AllocateEquipmentAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\ApplyCustomerTagAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\ArchiveConversationAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\AssignCleanerAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\AutomatedRescheduleAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\BookJobAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\BulkOperationsAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\CancelJobAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\ComplianceAuditAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\ConversationSummaryAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\CostAnalysisAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\CreateCustomerAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\CreateFollowUpAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\CreateInvoiceAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\CreateLeadAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\CreatePurchaseOrderAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\CreateQuoteAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\CreateRecurringJobAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\CustomerLoyaltyAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\CustomerNotificationAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\DispatchOptimizationAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\EmergencyServiceAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\FeedbackAnalysisAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\FieldServiceDocumentationAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\IntelligentLeadScoringAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\JobEstimationAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\MaintenanceSchedulerAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\MarkJobCompleteAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\NotifyCleanerAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\OptimiseRouteAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\PauseRecurringServiceAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\PerformanceMetricsAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\PredictiveMaintenanceAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\PricingOptimizationAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\ReassignCleanerAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\RecordIncidentAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\RecordInspectionAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\RecordPaymentAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\RequestReviewAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\RescheduleJobAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\ResourceAllocationAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\SendCustomerMessageAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\SendInvoiceAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\SendPaymentReminderAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\SendQuoteAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\ServiceChecklistAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\ServiceQualityPredictorAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\TechnicianCertificationAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\TechnicianPayrollAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\UpdateCustomerAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\UpdateStockAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\UploadJobEvidenceAgent::class,
                \App\Extensions\TitanAI\System\AI\Tier3\Agents\Actions\WorkforceAvailabilityAgent::class,
            ],
        ];
    }

    /**
     * Active runtime executors only. Organisational manager/specialist identity is owned by Titan AI Workforce.
     * Legacy Tier 1/2 classes remain available through legacyByTier() solely for migration/reference compatibility.
     *
     * @return array<int,list<class-string>>
     */
    public static function byTier(): array
    {
        $legacy = self::legacyByTier();

        return [3 => $legacy[3] ?? []];
    }

    /** Compatibility aliases do not increase canonical worker counts. */
    public static function aliases(): array
    {
        return [
            'assign-cleaner-agent' => 'assign-worker-agent',
            'assign-technician-agent' => 'assign-worker-agent',
            'intelligent-scheduler-agent' => 'automated-reschedule-agent',
            'route-optimization-agent' => 'optimise-route-agent',
            'technician-availability-agent' => 'workforce-availability-agent',
            'job-completion-verification-agent' => 'mark-job-complete-agent',
            'service-inventory-agent' => 'update-stock-agent',
            'equipment-reservation-agent' => 'allocate-equipment-agent',
            'customer-communication-agent' => 'send-customer-message-agent',
            'service-reminder-agent' => 'send-payment-reminder-agent',
            'safety-incident-reporting-agent' => 'record-incident-agent',
            'service-performance-analytics-agent' => 'performance-metrics-agent',
        ];
    }
}
