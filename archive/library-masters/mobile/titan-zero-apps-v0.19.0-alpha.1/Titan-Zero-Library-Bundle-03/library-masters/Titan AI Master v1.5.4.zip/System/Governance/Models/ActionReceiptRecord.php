<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Models;

use Illuminate\Database\Eloquent\Model;

final class ActionReceiptRecord extends Model
{
    protected $table = 'titan_ai_action_receipts';
    protected $guarded = [];
    public $incrementing = false;
    protected $keyType = 'string';
}
