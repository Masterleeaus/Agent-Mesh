<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier2\Assistants;

use App\Extensions\TitanAI\System\AI\Contracts\AbstractAIWorker;

final class ReportingAssistant extends AbstractAIWorker
{
    public static function id(): string { return 'reporting-assistant'; }
    public static function name(): string { return 'Reporting Assistant'; }
    public static function tier(): int { return 2; }
    public static function role(): string { return 'assistant'; }

    public static function capabilities(): array
    {
        return [
            'Assemble operational summaries',
            'Prepare finance and workforce reports',
            'Explain performance indicators'
        ];
    }

    public static function permissions(): array
    {
        return [
            'reports.read',
            'analytics.read'
        ];
    }

    public static function definition(): array
    {
        return parent::definition() + [
            'system_chat' => 'system-ai-chat',
            'runtime' => 'workcore-native-ai-runtime',
            'delegates_to' => 'tier_3_agents',
            'operational_authority' => 'workcore_api_only',
        ];
    }
}
