<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\TitanAI\Integration;

use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;
use InvalidArgumentException;
use RuntimeException;

final class TrustedToolContributionRegistry
{
    /** @var array<string,array{id:string,owner:string,sources:array<int,string>,schema:array<string,mixed>,executor:callable|object|null,permission:?string,execution:string}> */
    private array $tools = [];

    /** @var array<string,array<int,callable|object>> */
    private array $dynamicProviders = [];

    /** @param array<int,string> $sources @param array<string,mixed> $schema */
    public function register(
        string $id,
        string $owner,
        array $sources,
        array $schema,
        callable|object|null $executor = null,
        ?string $permission = null,
        string $execution = 'server',
    ): void {
        $id = trim($id);
        $owner = trim($owner);
        if ($id === '' || $owner === '') throw new InvalidArgumentException('Trusted Titan AI tools require non-empty id and owner.');
        if (isset($this->tools[$id])) throw new InvalidArgumentException("Trusted Titan AI tool [{$id}] is already registered.");
        $this->tools[$id] = [
            'id'=>$id,
            'owner'=>$owner,
            'sources'=>array_values(array_unique(array_map(static fn ($v): string => strtolower(trim((string) $v)), $sources))),
            'schema'=>$schema,
            'executor'=>$executor,
            'permission'=>$permission,
            'execution'=>$this->normaliseExecution($execution),
        ];
    }

    /**
     * Dynamic providers are trusted extension-owned resolvers for user/company-specific tools.
     * Provider must expose definitions(TitanAIRequest): array and execute(TitanAIRequest,string,array): mixed
     * for server tools. Client tools declare execution=client and are emitted to the source UI instead.
     */
    public function registerDynamicProvider(string $source, callable|object $provider): void
    {
        $source = strtolower(trim($source));
        if ($source === '') throw new InvalidArgumentException('Dynamic Titan AI tool providers require a source key.');
        $this->dynamicProviders[$source][] = $provider;
    }

    /** @return array<int,array<string,mixed>> */
    public function schemasFor(TitanAIRequest $request, ConversationSourcePolicyRegistry $policies): array
    {
        $definitions = $this->visibleDefinitions($request, $policies);
        return array_map(static fn (array $tool): array => [
            'id'=>(string) $tool['id'],
            'owner'=>(string) ($tool['owner'] ?? 'unknown'),
            'schema'=>(array) ($tool['schema'] ?? []),
            'execution'=>(string) ($tool['execution'] ?? 'server'),
        ], $definitions);
    }

    public function executionMode(TitanAIRequest $request, string $id, ConversationSourcePolicyRegistry $policies): string
    {
        foreach ($this->visibleDefinitions($request, $policies) as $tool) {
            if ((string) ($tool['id'] ?? '') === $id) return (string) ($tool['execution'] ?? 'server');
        }
        throw new RuntimeException("Trusted Titan AI tool [{$id}] is not authorized for this source/request.");
    }

    /** @return array<string,mixed> */
    public function execute(TitanAIRequest $request, string $id, array $arguments, ConversationSourcePolicyRegistry $policies): array
    {
        if ($this->executionMode($request, $id, $policies) !== 'server') {
            throw new RuntimeException("Trusted Titan AI tool [{$id}] is a client action and cannot execute on the server.");
        }

        if (isset($this->tools[$id])) {
            $executor = $this->tools[$id]['executor'];
            if ($executor === null) throw new RuntimeException("Trusted Titan AI tool [{$id}] does not have an executor.");
            return $this->normaliseResult(is_callable($executor) ? $executor($request, $arguments) : $executor->execute($request, $arguments));
        }

        $source = strtolower(trim($request->conversationSource));
        foreach ($this->dynamicProviders[$source] ?? [] as $provider) {
            $definitions = $this->definitionsFrom($provider, $request);
            foreach ($definitions as $definition) {
                if ((string) ($definition['id'] ?? '') !== $id) continue;
                if (($definition['execution'] ?? 'server') !== 'server') {
                    throw new RuntimeException("Dynamic Titan AI tool [{$id}] is a client action and cannot execute on the server.");
                }
                if (! is_object($provider) || ! method_exists($provider, 'execute')) {
                    throw new RuntimeException("Dynamic Titan AI tool provider for [{$id}] cannot execute tools.");
                }
                return $this->normaliseResult($provider->execute($request, $id, $arguments));
            }
        }

        throw new RuntimeException("Trusted Titan AI tool [{$id}] is not registered.");
    }

    /** @return array<int,array<string,mixed>> */
    private function visibleDefinitions(TitanAIRequest $request, ConversationSourcePolicyRegistry $policies): array
    {
        $definitions = $this->staticDefinitions($request);
        foreach ($this->dynamicDefinitions($request) as $definition) $definitions[] = $definition;

        $available = array_flip($request->availablePermissions);
        $requested = $request->toolPermissions === [] ? null : array_flip($request->toolPermissions);
        $visible = [];
        foreach ($definitions as $tool) {
            $id = (string) ($tool['id'] ?? '');
            if ($id === '') continue;
            if ($requested !== null && ! isset($requested[$id])) continue;
            $permission = isset($tool['permission']) && is_string($tool['permission']) ? $tool['permission'] : null;
            if ($permission !== null && ! isset($available[$permission])) continue;
            if (! $policies->allowsTool($request, $id)) continue;
            $visible[] = $tool;
        }
        return $visible;
    }

    /** @return array<int,array<string,mixed>> */
    private function staticDefinitions(TitanAIRequest $request): array
    {
        $source = strtolower(trim($request->conversationSource));
        return array_values(array_filter($this->tools, static function (array $tool) use ($source): bool {
            return $tool['sources'] === [] || in_array('*', $tool['sources'], true) || in_array($source, $tool['sources'], true);
        }));
    }

    /** @return array<int,array<string,mixed>> */
    private function dynamicDefinitions(TitanAIRequest $request): array
    {
        $source = strtolower(trim($request->conversationSource));
        $definitions = [];
        foreach ($this->dynamicProviders[$source] ?? [] as $provider) {
            foreach ($this->definitionsFrom($provider, $request) as $definition) {
                if (! is_array($definition) || empty($definition['id']) || empty($definition['schema'])) continue;
                $definitions[] = [
                    'id'=>(string) $definition['id'],
                    'owner'=>(string) ($definition['owner'] ?? $source),
                    'schema'=>(array) $definition['schema'],
                    'permission'=>isset($definition['permission']) ? (string) $definition['permission'] : null,
                    'execution'=>$this->normaliseExecution((string) ($definition['execution'] ?? 'server')),
                ];
            }
        }
        return $definitions;
    }

    /** @return array<int,array<string,mixed>> */
    private function definitionsFrom(callable|object $provider, TitanAIRequest $request): array
    {
        $value = is_callable($provider)
            ? $provider($request)
            : (method_exists($provider, 'definitions') ? $provider->definitions($request) : []);
        return is_array($value) ? array_values($value) : [];
    }

    private function normaliseExecution(string $execution): string
    {
        $execution = strtolower(trim($execution));
        if (! in_array($execution, ['server','client'], true)) {
            throw new InvalidArgumentException("Trusted Titan AI tool execution mode [{$execution}] is invalid.");
        }
        return $execution;
    }

    /** @return array<string,mixed> */
    private function normaliseResult(mixed $result): array
    {
        if (is_object($result) && method_exists($result, 'toArray')) $result = $result->toArray();
        return is_array($result) ? $result : ['result'=>$result];
    }
}
