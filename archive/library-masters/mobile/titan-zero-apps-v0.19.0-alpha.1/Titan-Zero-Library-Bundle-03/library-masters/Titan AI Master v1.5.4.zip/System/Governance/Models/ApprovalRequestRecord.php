<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Governance\Models;

use Illuminate\Database\Eloquent\Model;

final class ApprovalRequestRecord extends Model
{
    protected $table = 'titan_ai_approval_requests';
    protected $guarded = [];
    public $incrementing = false;
    protected $keyType = 'string';
}
