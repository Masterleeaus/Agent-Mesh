# Step 23 — Confidence Engine
TypeScript confidence calibration layer. Confidence is calibrated from append-only observed-outcome profiles and is always separate from execution authority. Missing calibration evidence falls back to the original confidence rather than fabricating certainty.
