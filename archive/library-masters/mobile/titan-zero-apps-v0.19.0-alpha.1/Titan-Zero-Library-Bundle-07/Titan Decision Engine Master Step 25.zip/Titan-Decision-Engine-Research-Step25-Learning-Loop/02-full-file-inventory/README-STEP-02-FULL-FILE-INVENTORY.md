# Titan Decision Engine Research — Step 02 Full File Inventory

## Scope

Complete evidence inventory of the untouched donor implementation extracted in Step 01. No donor source files were rewritten, deleted, or merged. All Step 02 artifacts live outside the donor tree.

- Extension version: `1.10.37`
- Files: **67**
- Directories below donor root: **14**
- Total extracted donor bytes: **13,515,508**
- Literal HTTP(S) paths found in JS bundles: **102**
- API/GraphQL operation candidates: **73**
- Event type symbols: **216**
- Module type symbols: **70**

## Manifest runtime wiring

- Manifest V3 service worker: `static/js/background.js`
- Document-start content injection on `<all_urls>`: `static/js/injectEarly.js`, then `static/js/content.js`.
- Permissions: `storage`, `cookies`, `webRequest`, `webNavigation`, `scripting`, `offscreen`.
- Host permission: `<all_urls>`.
- Web-accessible resources include `static/js/injected.js`, `static/media/*`, `rive/*`, and `*`.

## Runtime surfaces

### Scripts / bundles
- `evaluate-tab-permissions.js`
- `mockServiceWorker.js`
- `static/js/668.js`
- `static/js/975.js`
- `static/js/background.js`
- `static/js/content.js`
- `static/js/injectEarly.js`
- `static/js/injected.js`
- `static/js/offscreen.js`
- `static/js/popup.js`
- `static/js/triggerPermissions.js`

### Workers / background processes
- `static/js/background.js`
- `static/js/offscreen.js`
- `mockServiceWorker.js`

### Injected components
- `static/js/injectEarly.js`
- `static/js/content.js`
- `static/js/injected.js`

### UI surfaces
- `popup.html`
- `triggerPermissions.html`
- `offscreen.html`

### UI runtime bundles
- `static/js/popup.js`
- `static/js/triggerPermissions.js`
- `static/css/popup.css`
- `static/css/triggerPermissions.css`
- `static/css/content.css`

### Assets
- `fonts/GT-Super-Display-Light-Italic.ttf`
- `fonts/GT-Super-Display-Light-Italic.woff`
- `fonts/GT-Super-Display-Light-Italic.woff2`
- `fonts/GT-Super-Display-Light.ttf`
- `fonts/GT-Super-Display-Light.woff`
- `fonts/GT-Super-Display-Light.woff2`
- `fonts/GT-Super-Display-Regular.ttf`
- `fonts/GT-Super-Display-Regular.woff`
- `fonts/GT-Super-Display-Regular.woff2`
- `fonts/PPNeueMontreal-Medium.otf`
- `fonts/PPNeueMontreal-Medium.woff`
- `fonts/PPNeueMontreal-Medium.woff2`
- `fonts/PPNeueMontreal-Regular.otf`
- `fonts/PPNeueMontreal-Regular.woff`
- `fonts/PPNeueMontreal-Regular.woff2`
- `fonts/RobotoMono-Italic.ttf`
- `fonts/RobotoMono.ttf`
- `icons/icon_development_128.png`
- `icons/icon_development_16.png`
- `icons/icon_development_32.png`
- `icons/icon_development_48.png`
- `icons/icon_production_128.png`
- `icons/icon_production_16.png`
- `icons/icon_production_32.png`
- `icons/icon_production_48.png`
- `icons/select-an-item.jpg`
- `images/closet/confetti.png`
- `images/closet/shopping_bag.png`
- `images/force-updates/gift_box.png`
- `images/force-updates/sparkle.png`
- `images/price-drop/toast_check_icon.png`
- `images/price-drop/toast_icon.svg`
- `images/rewards/activate_points_frame.png`
- `images/rewards/brand_cards.png`
- `images/rewards/reactivate_points_frame.png`
- `images/rewards/toast_p_icon.png`
- `images/rewards/track_points_frame.png`
- `rive/confetti_floating.riv`
- `rive/magnifying_glass_floating.riv`
- `rive/money_floating.riv`
- `rive/trophy_floating.riv`
- `rive.wasm`
- `static/images/phia-banner.jpg`
- `static/images/phia-search-logo.svg`

### Metadata / integrity
- `manifest.json`
- `buildId.txt`
- `_metadata/computed_hashes.json`
- `_metadata/verified_contents.json`

### Embedded build artifact
- `artifacts/extension.zip`

## Storage and state mechanisms

Evidence in bundles shows use of `chrome.storage`, `localStorage`, and `sessionStorage`; candidates are separately catalogued in `STORAGE-KEY-CANDIDATES.txt`. Apollo cache persistence code is also present in bundled dependencies. Exact schema semantics remain a later deobfuscation task.

## Network/API surfaces

The bundles contain first-party API, iframe-scraper, whitelist, analytics/feature-flag, affiliate-network, merchant-specific and CDN endpoints. Every literal HTTP(S) path found is preserved in `NETWORK-URL-LITERALS.txt`; candidate GraphQL/API operation symbols are in `API-OPERATION-CANDIDATES.txt`.

## Parsers, detectors, classifiers, trackers and decision primitives

- Product/page recognition and product schema handling (`schema.org/Product`, product-page state and whitelist state).
- Scrape runtime with raw scrape configuration, iframe scraper, configurable selectors and scrape lifecycle events.
- Cart/checkout/confirmation detection, merchant-specific network-response recognition, cart-total selectors and checkout activity.
- Offer/deal/coupon handling including coupon auto-apply paths.
- Similar-product/style and similar-brand search with similarity fields.
- Resale insight/value computation and resale-related modules.
- Price-drop alert creation/update/removal and persistent tracking workflows.
- Collections/favorites/closet/recently-viewed state and link/history surfaces.
- Sustainability/climate-focused labels and ingredient breakdown/highlight/risk data.
- Rewards/points, affiliate-cookie detection, link normalization and merchant/affiliate recognition.
- Telemetry/event tracking, heartbeats, debug events, page views and scrape performance/error events.
- Mutation/Intersection observers plus DOM selectors for continuous page-state interpretation.

## Background processes

- `static/js/background.js`: MV3 service worker; central message routing, tabs, scripting, cookies, webRequest, storage, offscreen orchestration, network work and timers.
- `static/js/offscreen.js`: offscreen document messaging/network helper.
- `mockServiceWorker.js`: mock-service-worker runtime artifact, apparently development/testing support rather than the manifest service worker.
- `static/js/injectEarly.js`: document-start early bridge/state setup.
- `static/js/content.js`: main page observer/scraper/UI/content runtime.
- `static/js/injected.js`: web-accessible page-context injection bridge.

## Inventory artifacts

- `FILE-INVENTORY.csv` — every extracted donor file, byte size, SHA-256 and category.
- `FULL-INVENTORY.json` — machine-readable aggregate inventory.
- `MANIFEST-CATALOG.json` — complete manifest copy for wiring inspection.
- `NETWORK-URL-LITERALS.txt` — all literal HTTP(S) paths found in JS.
- `API-OPERATION-CANDIDATES.txt` — query/mutation and API-operation candidates.
- `EVENT-TYPE-CATALOG.txt` / `MODULE-TYPE-CATALOG.txt` — bundled symbolic catalogs.
- `STORAGE-KEY-CANDIDATES.txt` — storage-adjacent string candidates.
- `RUNTIME-PATTERN-COUNTS.json` — API/runtime mechanism usage by bundle.
- `SEMANTIC-TERM-HITS.json` — evidence map for major behavioral families.

## Preservation rule

The donor tree under `01-extracted-donor/` remains untouched from Step 01. Step 02 adds inventory evidence only. Any interpretation of bundled/minified symbols is explicitly a candidate until later dependency/deobfuscation passes confirm exact semantics.
