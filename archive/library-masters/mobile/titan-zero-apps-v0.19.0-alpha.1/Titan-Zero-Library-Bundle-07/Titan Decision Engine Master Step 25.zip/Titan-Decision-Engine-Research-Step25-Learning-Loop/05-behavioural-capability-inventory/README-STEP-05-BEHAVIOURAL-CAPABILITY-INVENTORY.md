# Step 05 — Behavioural Capability Inventory

Canonical capabilities: **44**

## Category coverage

- **Observe** — 6
- **Recognise** — 5
- **Extract** — 5
- **Compare** — 3
- **Remember** — 6
- **Predict** — 2
- **Rank** — 2
- **Recommend** — 3
- **Monitor** — 4
- **Trigger** — 8

## Canonical inventory

### Observe

- **OBSERVE-01 — Observe current page context** (high): Establish the URL/hostname/page state being evaluated.  
  Evidence contracts: `page_validation, network_response_interception`
- **OBSERVE-02 — Observe DOM evidence** (high): Capture configured DOM values and structured page signals.  
  Evidence contracts: `page_scraping, commercial_object_detection`
- **OBSERVE-03 — Observe page network responses** (high): Capture selected fetch/XHR response bodies and request bodies for downstream interpretation.  
  Evidence contracts: `network_response_interception`
- **OBSERVE-04 — Observe transactional page state** (high): Determine whether a page is cart, checkout, confirmation, or another transaction state.  
  Evidence contracts: `cart_checkout_detection`
- **OBSERVE-05 — Observe financial totals** (high): Extract subtotal, tax, shipping and total values where configured.  
  Evidence contracts: `cart_checkout_detection`
- **OBSERVE-06 — Observe interaction/activity signals** (high): Capture activity/history events relevant to later personalization or analysis.  
  Evidence contracts: `purchase_and_order_observation, telemetry_experimentation`

### Recognise

- **RECOGNISE-01 — Recognise relevant/eligible pages** (high): Classify whether the current page should activate extraction or UI.  
  Evidence contracts: `page_validation`
- **RECOGNISE-02 — Recognise a structured object** (high): Identify a product-like/commercial entity from schema and page signals.  
  Evidence contracts: `commercial_object_detection`
- **RECOGNISE-03 — Recognise seller/brand context** (high): Associate observed objects/pages with seller or brand context for enrichment.  
  Evidence contracts: `seller_brand_enrichment`
- **RECOGNISE-04 — Recognise offer/coupon surfaces** (high): Detect where offer codes can be entered/applied/removed.  
  Evidence contracts: `coupon_offer_application_support`
- **RECOGNISE-05 — Recognise completed purchase/order state** (high): Detect confirmation state suitable for purchase/order observation.  
  Evidence contracts: `cart_checkout_detection, purchase_and_order_observation`

### Extract

- **EXTRACT-01 — Extract configured fields** (high): Apply site-specific selectors/strategies to turn page data into normalized fields.  
  Evidence contracts: `page_scraping, site_configuration`
- **EXTRACT-02 — Extract structured metadata** (high): Parse schema/structured markup into normalized entity attributes.  
  Evidence contracts: `commercial_object_detection`
- **EXTRACT-03 — Extract data from intercepted responses** (medium): Transform intercepted response/request payloads into usable downstream evidence.  
  Evidence contracts: `network_response_interception`
- **EXTRACT-04 — Extract transaction values** (high): Read configured cart/checkout totals and related transaction fields.  
  Evidence contracts: `cart_checkout_detection`
- **EXTRACT-05 — Extract/enrich ingredient and sustainability attributes** (high): Attach canonical ingredient metadata and configured sustainability/beauty flags.  
  Evidence contracts: `sustainability_ingredient_enrichment`

### Compare

- **COMPARE-01 — Construct comparable alternatives** (high): Retrieve similar products/brands/editorials/seller inventory that can be compared against the current object.  
  Evidence contracts: `alternative_discovery, curation_editorial_discovery`
- **COMPARE-02 — Compare seller/offer context** (high): Retrieve offers, on-sale and trending context across seller/brand surfaces.  
  Evidence contracts: `seller_brand_enrichment`
- **COMPARE-03 — Compare current value with resale/value context** (high): Obtain value/resale insight suitable for comparing hold/buy/sell alternatives.  
  Evidence contracts: `value_and_resale_intelligence`

### Remember

- **REMEMBER-01 — Remember recently viewed entities** (high): Persist and retrieve recently viewed objects for longitudinal context.  
  Evidence contracts: `collections_and_memory`
- **REMEMBER-02 — Remember user-curated collections** (high): Create/list collections and add/remove entities.  
  Evidence contracts: `collections_and_memory`
- **REMEMBER-03 — Remember watch conditions** (high): Persist price/value watch conditions until changed or removed.  
  Evidence contracts: `price_drop_watch`
- **REMEMBER-04 — Remember purchase activity** (high): Record purchase activity for later context/history.  
  Evidence contracts: `purchase_and_order_observation`
- **REMEMBER-05 — Remember tracked orders** (high): Persist order tracking requests/results across confirmation flow.  
  Evidence contracts: `purchase_and_order_observation`
- **REMEMBER-06 — Remember runtime configuration/preferences** (medium): Retain extension state, permissions, onboarding/config identifiers and related local runtime state.  
  Evidence contracts: `telemetry_experimentation, site_configuration`

### Predict

- **PREDICT-01 — Produce forward-looking value/resale insight** (medium): Return estimated resale/value information used to reason about future value.  
  Evidence contracts: `value_and_resale_intelligence`
- **PREDICT-02 — Predict whether UI/extraction should activate** (medium): Use remote page validation/config to determine expected activation behavior.  
  Evidence contracts: `page_validation`

### Rank

- **RANK-01 — Receive/order rankable alternatives** (medium): Return alternative/search/editorial sets in an order usable for presentation or selection.  
  Evidence contracts: `alternative_discovery, curation_editorial_discovery`
- **RANK-02 — Receive ordered seller offers/trending/on-sale context** (medium): Provide seller/brand results in an order suitable for prioritization.  
  Evidence contracts: `seller_brand_enrichment`

### Recommend

- **RECOMMEND-01 — Assemble recommendation-ready context** (high): Combine entity evidence, alternatives, value, seller offers, sustainability and memory into context suitable for recommendation.  
  Evidence contracts: `alternative_discovery, value_and_resale_intelligence, seller_brand_enrichment, sustainability_ingredient_enrichment, collections_and_memory`
- **RECOMMEND-02 — Surface curated/editorial suggestions** (high): Present curated products/editorials/outfits as suggested alternatives or inspiration.  
  Evidence contracts: `curation_editorial_discovery`
- **RECOMMEND-03 — Surface deal/offer opportunities** (high): Expose seller offers, deals, on-sale and coupon opportunities relevant to the current context.  
  Evidence contracts: `seller_brand_enrichment, coupon_offer_application_support`

### Monitor

- **MONITOR-01 — Monitor price/value changes** (high): Maintain persistent alerts and react when tracked value conditions change.  
  Evidence contracts: `price_drop_watch`
- **MONITOR-02 — Monitor post-purchase order state** (high): Track an order after confirmation.  
  Evidence contracts: `purchase_and_order_observation`
- **MONITOR-03 — Monitor runtime behavior and failures** (high): Capture analytics, errors, experiments and session behavior.  
  Evidence contracts: `telemetry_experimentation`
- **MONITOR-04 — Monitor page/navigation lifecycle** (high): Observe navigations and page readiness to decide when extraction/validation should rerun.  
  Evidence contracts: `page_validation, page_scraping, network_response_interception`

### Trigger

- **TRIGGER-01 — Trigger extraction** (high): Start configurable page scraping when page/context conditions are met.  
  Evidence contracts: `page_validation, page_scraping`
- **TRIGGER-02 — Trigger contextual UI** (high): Show/hide page UI based on page validation and top-of-page decisions.  
  Evidence contracts: `page_validation, site_configuration`
- **TRIGGER-03 — Trigger offer-code interaction support** (high): Drive configured coupon entry/apply/remove interactions.  
  Evidence contracts: `coupon_offer_application_support`
- **TRIGGER-04 — Trigger persistent watch creation/update/removal** (high): Create or mutate alert/watch state from user/system action.  
  Evidence contracts: `price_drop_watch`
- **TRIGGER-05 — Trigger purchase activity recording** (high): Create purchase activity when confirmation conditions are satisfied.  
  Evidence contracts: `purchase_and_order_observation`
- **TRIGGER-06 — Trigger order tracking** (high): Submit order data into post-purchase tracking workflow.  
  Evidence contracts: `purchase_and_order_observation`
- **TRIGGER-07 — Trigger transformed navigation** (high): Generate transformed merchant URL that can be opened for downstream navigation.  
  Evidence contracts: `affiliate_link_transformation`
- **TRIGGER-08 — Trigger hidden scrape runtime** (high): Launch/communicate with the offscreen iframe scrape runtime when needed.  
  Evidence contracts: `offscreen_scrape_runtime`

## Interpretation guardrails

- This inventory names capabilities by **outcome**, not by the donor product or its original shopping vocabulary.
- `high` means the behavior is directly evidenced in local runtime contracts or explicit operations.
- `medium` means the output is evidenced but important transformation/ranking/prediction logic appears remote, bundled, or otherwise not fully proven locally.
- A capability being recommendation-ready does **not** mean the extension owns authority to execute a Titan business decision.
- Step 05 does not modify donor files; it adds research artifacts only.
