# Step 04 — Capability Deobfuscation

## Purpose
Trace bundled/minified runtime paths far enough to identify concrete behavior, inputs, transformations, outputs, persistent state, and external dependencies without modifying the donor implementation.

## Preservation rule
`00-source-archive/` and `01-extracted-donor/` are inherited unchanged from Step 03. All new analysis lives in `04-capability-deobfuscation/`.

## Key deobfuscated runtime model
The donor is a multi-stage browser decision-support runtime: page-world interception and early injection feed a content bridge; the content bridge detects and scrapes page state; a privileged background worker coordinates validation, per-site configuration, persistence, API calls, alerts, collections, order/activity tracking, enrichment and remote scrape support; popup/permissions/offscreen surfaces act as user and auxiliary runtime satellites.

## Concrete behavior families
### page_validation
Determine whether current page is whitelisted/product-like and whether UI/scraping should activate.
- Inputs: URL/hostname, framework/version, page context
- Transformations: GraphQL ValidatePage
- Outputs: isWhitelistedPage, isProductPage, shouldFirePageView, shouldShowTopOfPage, numImagesToScrape
- Persistent state: none proven / transient
- External dependencies: remote API

### site_configuration
Fetch per-site selectors, anchors, detectors and strategy configuration.
- Inputs: hostname, version, framework
- Transformations: GraphQL SiteConfig
- Outputs: resaleConfig, checkoutConfig, checkoutDetector, confirmationDetector, couponConfig, cartConfig, beautyConfig, strategies
- Persistent state: cached/per-session site configuration likely; exact cache ownership to refine
- External dependencies: remote API, runtime config cache

### page_scraping
Execute configurable extraction against page DOM and/or iframe scrape runtime.
- Inputs: DOM, site scrape definitions, page URL, images
- Transformations: selector/attribute extraction, config-driven scrape strategies, iframe/offscreen bridge
- Outputs: normalized scrape result, SCRAPE_SUCCESS/SCRAPE_ERROR
- Persistent state: transient scrape state/events
- External dependencies: offscreen iframe, remote scrape runtime

### network_response_interception
Observe selected page network responses in page world and forward relevant payloads.
- Inputs: fetch/XHR/network response
- Transformations: injected page hook, window message bridge
- Outputs: phia-intercepted-response
- Persistent state: none proven / transient
- External dependencies: page world, content bridge

### commercial_object_detection
Recognize product/commercial page state using schema, site config and extracted signals.
- Inputs: DOM, schema.org Product, page validation, site config
- Transformations: detectors, structured data parsing, heuristics/config
- Outputs: product-page state, commercial object fields
- Persistent state: none proven / transient
- External dependencies: site config, content runtime

### alternative_discovery
Search related products/brands/editorials and seller inventories.
- Inputs: product identity, brand, seller, query
- Transformations: GraphQL search operations, similar-brand/product-brand operations
- Outputs: rankable alternatives/content
- Persistent state: none proven / transient
- External dependencies: remote GraphQL

### value_and_resale_intelligence
Obtain resale/value insights and create deep links for value exploration.
- Inputs: product/entity identity, market context
- Transformations: ResaleInsights query, CreateResaleInsightsUrl mutation
- Outputs: resale insights, valuation URL
- Persistent state: none proven / transient
- External dependencies: remote GraphQL

### cart_checkout_detection
Identify cart/checkout/confirmation state and extract totals with site-specific selectors.
- Inputs: URL, DOM, site detector config
- Transformations: urlRegexes/selectors, cart total selectors, checkout/confirmation detector
- Outputs: page state: CART/CHECKOUT/CONFIRMATION, cart totals
- Persistent state: none proven / transient
- External dependencies: site config, content/offscreen runtime

### coupon_offer_application_support
Detect coupon surfaces and configure code entry/apply/remove actions.
- Inputs: DOM, site coupon config, available deals
- Transformations: detector regex/selectors, codeBoxSelectors, submitButtonSelectors, preApplyActionSelectors, removeCodeSelectors
- Outputs: coupon candidates/application UI state
- Persistent state: none proven / transient
- External dependencies: site config, offers/deals API

### price_drop_watch
Create, list, update and remove persistent price-drop alerts.
- Inputs: product identity, target/current price, user/session
- Transformations: GraphQL mutations/queries
- Outputs: persistent alert records, notification eligibility
- Persistent state: remote alert records, extension notification state
- External dependencies: remote GraphQL, local notification state

### collections_and_memory
Persist collections and recently viewed items; add/remove products.
- Inputs: product object, collection id, recent-view event
- Transformations: collection GraphQL operations, local recentlyViewedItems mutation
- Outputs: saved collections, recent history
- Persistent state: recentlyViewedItems in extension storage, remote collection records
- External dependencies: remote GraphQL, extension storage

### purchase_and_order_observation
Record purchase activity and track orders after confirmation.
- Inputs: purchaseData, user/device identity, order context
- Transformations: CreateUserActivity/PurchaseActivity, TrackOrder
- Outputs: purchase activity record, order tracking state
- Persistent state: remote user activity/order records
- External dependencies: remote GraphQL, page checkout/confirmation state

### seller_brand_enrichment
Fetch seller configurations, offers, editorials, on-sale and trending data.
- Inputs: seller/brand identity
- Transformations: SellersConfig, SellersOffers, SellersEditorials, SellersOnSale, SellersTrending
- Outputs: enriched seller/brand context
- Persistent state: none proven / transient
- External dependencies: remote GraphQL

### sustainability_ingredient_enrichment
Attach beauty/sustainability flags and ingredient metadata to decision context.
- Inputs: site/product context, ingredient names/selectors
- Transformations: beautyConfig flags, Ingredients query
- Outputs: sustainable/climateFocused/vegan/crueltyFree/dermFounded flags, canonical ingredient metadata
- Persistent state: none proven / transient
- External dependencies: remote GraphQL, site config

### curation_editorial_discovery
Search curated products, editorials and outfits and retrieve curated product details.
- Inputs: product id, search criteria
- Transformations: GetCuratedProductByProductId, SearchEditorials, SearchOutfits
- Outputs: curated context, editorial/outfit alternatives
- Persistent state: none proven / transient
- External dependencies: remote GraphQL

### affiliate_link_transformation
Transform merchant/product URLs into monetized/partner links.
- Inputs: merchant URL, affiliate configuration
- Transformations: CreateMerchantUrl, affiliate-network routing
- Outputs: merchant/affiliate URL
- Persistent state: none proven / transient
- External dependencies: remote GraphQL, affiliate networks

### telemetry_experimentation
Capture analytics, errors, feature flags and session behavior.
- Inputs: events, session/device/browser context
- Transformations: Mixpanel/PostHog/Statsig/Sentry clients, session replay/rrweb
- Outputs: analytics events, feature decisions, error reports
- Persistent state: analytics/session identifiers and vendor-managed telemetry
- External dependencies: Mixpanel, PostHog, Statsig, Sentry

### offscreen_scrape_runtime
Host an invisible remote scrape runtime in an iframe and relay messages to extension background.
- Inputs: remote runtime URL, runtime messages
- Transformations: offscreen iframe, origin validation, chrome.runtime.sendMessage
- Outputs: scrape runtime responses
- Persistent state: none proven / transient
- External dependencies: storage.googleapis.com/phia-scrape-runtime

## Important interpretation boundary
This pass identifies runtime contracts from literal operations, config fields, event names, endpoints, and nearby minified execution paths. It does **not** claim every minified function has been assigned a semantic name. Later passes can refine ownership and algorithms while preserving these evidence records.

## Notable generalized capability insight
The implementation is best understood as an early specialized **decision-support engine**: observe context → recognize subject/state → acquire/enrich evidence → discover alternatives → evaluate value/conditions → remember/watch → surface or trigger a next action. Shopping-specific labels are donor-domain vocabulary, not the architectural boundary Titan should inherit.
