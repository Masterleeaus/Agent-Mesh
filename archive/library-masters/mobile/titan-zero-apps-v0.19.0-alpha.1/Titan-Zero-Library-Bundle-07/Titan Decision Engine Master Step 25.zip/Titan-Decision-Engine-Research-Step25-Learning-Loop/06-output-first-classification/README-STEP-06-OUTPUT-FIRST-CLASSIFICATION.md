# Step 06 — Output-First Classification

This pass reclassifies all 44 Step 05 canonical behaviours by the **outcome they produce**, not by the donor implementation domain. No donor source, prior research artifact, or historical evidence was rewritten.

## Outcome taxonomy

- **Understanding** — 10 primary capabilities.
- **Alternatives** — 3 primary capabilities.
- **Evidence** — 9 primary capabilities.
- **Prediction** — 3 primary capabilities.
- **Ranking** — 2 primary capabilities.
- **Recommendation** — 3 primary capabilities.
- **Best Action** — 0 primary capabilities.
- **Monitoring** — 6 primary capabilities.
- **Execution Preparation** — 8 primary capabilities.

## Critical finding

The donor contains strong evidence acquisition, alternative discovery, prediction, ranking, recommendation-support, monitoring, and action-preparation machinery, but **no capability is classified as a proven complete “best action” selector**. This is deliberate: Step 04/05 evidence does not yet prove a local objective + constraints + trade-off + ranked action-selection policy. Titan should build that layer explicitly rather than infer it from ordered API results.

## Titan conversion boundary

Capabilities classified as **execution preparation** may initiate or prepare browser/runtime actions, but they do not own Titan authority. In Titan Zero, any consequential execution must remain downstream of `company_id` scoping and governed actor/capability/permission/entitlement/autonomy/risk/cost/privacy checks.

## Artifacts

- `OUTPUT-FIRST-CAPABILITY-CLASSIFICATION.json` — canonical outcome-first inventory with evidence retained.
- `OUTPUT-FIRST-CAPABILITY-CLASSIFICATION.csv` — flat review form.
- `OUTCOME-CAPABILITY-MATRIX.csv` — primary/secondary outcome matrix.
- `DOMAIN-NEUTRAL-OUTCOME-MAP.json` — portable Titan expression for each capability.
- `OUTCOME-FIRST-SUMMARY.json` — counts and completion checks.
