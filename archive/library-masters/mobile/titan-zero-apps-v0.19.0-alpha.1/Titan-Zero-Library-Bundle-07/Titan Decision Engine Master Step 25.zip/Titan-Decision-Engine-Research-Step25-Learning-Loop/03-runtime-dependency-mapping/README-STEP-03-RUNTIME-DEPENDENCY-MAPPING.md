# Step 03 — Runtime Dependency Mapping

## Purpose
Map how meaningful runtime subsystems load, call, communicate with, or depend on each other while preserving the Step 02 donor tree unchanged.

## Preservation contract
- `00-source-archive/` and `01-extracted-donor/` are copied unchanged from Step 02.
- Step 03 adds only `03-runtime-dependency-mapping/` and preservation metadata.
- No donor source was rewritten, deleted, merged, formatted, or deminified.

## Central runtime topology
1. `manifest.json` boots the privileged `background.js` service worker.
2. `injectEarly.js` and `content.js` enter every matching page at `document_start`.
3. `injected.js` is a web-accessible page-world runtime and is connected to the content-side bridge by page messaging/event patterns.
4. `content.js` bridges page context to Chrome extension messaging.
5. `background.js` is the privileged orchestration point for Chrome APIs, persistent state, navigation/request observation, injection and external network access.
6. Popup, offscreen, and permission-request surfaces are satellite extension contexts connected through runtime messaging/shared state.
7. Shared/lazy webpack chunks (`668.js`, `975.js`) contain additional reusable runtime logic consumed from principal bundles.

## Graph evidence
- Nodes: 45
- Dependency edges: 141
- High-confidence edges: 81
- Medium-confidence/inferred edges: 60
- External URL domains observed: 70

## Deliverables
- `RUNTIME-DEPENDENCY-GRAPH.json` — canonical machine-readable nodes and edges.
- `RUNTIME-DEPENDENCY-EDGES.csv` — flat edge table.
- `RUNTIME-DEPENDENCY-GRAPH.mmd` — Mermaid topology for inspection/rendering.
- `RUNTIME-PATTERN-MATRIX.json` — per-bundle Chrome/message/network/storage pattern counts.
- `MESSAGE-EVENT-LITERALS.json` — candidate runtime message/event/action names by bundle.
- `NETWORK-DEPENDENCY-DOMAINS.json` — domains and representative literal URLs.
- `SUBSYSTEM-OWNERSHIP-CANDIDATES.json` — behavioral subsystem → candidate runtime owner mapping.

## Confidence rule
`high` means a direct declaration or literal API/message mechanism was found. `medium` means the relationship is strongly suggested by co-occurring runtime mechanisms or semantic ownership but exact call sites remain bundled/minified. Those medium edges are intentionally retained for Step 04 deobfuscation instead of being promoted to facts.

## Confirmed protocol-level flows
- `injected.js` patches page `fetch`/`XMLHttpRequest` and publishes `phia-intercepted-response`; `injectEarly.js` consumes those payloads for network-response processing.
- `injectEarly.js` can request scrape execution through the literal `__phia_scrape_runtime_content__` protocol.
- `background.js` owns the privileged scrape runtime, creates `offscreen.html`, and uses `chrome.scripting.executeScript` for tab-scoped page execution.
- `offscreen.js` is a bidirectional relay between Chrome runtime messages and a sandbox iframe/window channel.
- `background.js` contains explicit network interception logic using `chrome.webRequest` listeners and URL-specific matching.
- `phia-cached-reviews` / `phia-content-ready` form a cached-review handshake between extension and page context.
- `__phia_dev_*` channels are localhost-only development bridge paths, not production feature authority.

See `COMMUNICATION-PROTOCOL-CATALOG.md` for the literal channel inventory.
