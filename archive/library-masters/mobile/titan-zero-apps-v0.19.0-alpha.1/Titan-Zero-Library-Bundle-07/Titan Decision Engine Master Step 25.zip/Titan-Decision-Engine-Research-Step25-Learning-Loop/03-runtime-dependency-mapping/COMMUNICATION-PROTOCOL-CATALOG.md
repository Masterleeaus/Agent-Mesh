# Runtime Communication Protocols

These are literal channel/event names recovered from the bundled runtime. They are stronger evidence than semantic subsystem inference.

## `__phia_scrape_runtime__`
- Participants: background (1 refs), offscreen (1 refs)
- Role: privileged scrape/sandbox runtime protocol between background and offscreen/iframe execution contexts.

## `__phia_scrape_runtime_content__`
- Participants: background (1 refs), injectEarly (1 refs)
- Role: content-side request path for scrape-runtime execution.

## `__phia_net_entry__`
- Participants: background (3 refs)
- Role: intercepted network-entry relay from page/window context into extension runtime messaging.

## `__phia_net_nav__`
- Participants: background (3 refs)
- Role: page navigation-change relay into extension runtime.

## `phia-intercepted-response`
- Participants: injectEarly (1 refs), injected (2 refs)
- Role: page-world fetch/XHR interception → early/content-side network-response processing.

## `phia-cached-reviews`
- Participants: content (1 refs), injectEarly (2 refs)
- Role: cached parsed-review delivery from extension runtime into page context.

## `phia-content-ready`
- Participants: content (1 refs), injectEarly (1 refs)
- Role: page/content handshake used before replaying cached review payloads.

## `phia-revalidate-pagestate`
- Participants: content (3 refs)

## `phia-message-handler-ready`
- Participants: content (1 refs)

## `__phia_dev_ping__`
- Participants: injectEarly (1 refs)
- Role: localhost-only development bridge/control path.

## `__phia_dev_bridge_ready__`
- Participants: injectEarly (1 refs)
- Role: localhost-only development bridge/control path.

## `__phia_dev_execute__`
- Participants: injectEarly (1 refs)
- Role: localhost-only development bridge/control path.

## `__phia_dev_result__`
- Participants: injectEarly (1 refs)
- Role: localhost-only development bridge/control path.

## `SET_PHIA_VT`
- Participants: content (4 refs), injected (1 refs)
- Role: page-world configuration message controlling a runtime page flag used by injected behavior.
