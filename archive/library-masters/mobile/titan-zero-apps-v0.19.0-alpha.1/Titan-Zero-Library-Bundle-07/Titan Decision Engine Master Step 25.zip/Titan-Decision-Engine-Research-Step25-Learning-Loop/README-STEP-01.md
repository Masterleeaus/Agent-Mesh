# Titan Decision Engine Research — Step 01 Source Extraction

This workspace preserves the complete donor implementation for research and later Titan Zero conversion.

## Preservation rules

- `00-source-archive/donor-original.zip` is an untouched copy of the donor archive used for this step.
- `01-extracted-donor/` is the complete archive extraction. No donor files were rewritten, merged, renamed, normalized, or deleted.
- `99-research-metadata/` contains only Titan research metadata generated after extraction: integrity output, checksums, and the extraction record.
- No donor runtime code is wired into Titan Zero in this step.

The purpose of this package is to establish a reproducible, immutable baseline before capability extraction and architectural conversion begin.
