declare module "node:crypto" { export function createHash(name:string): any; }
declare module "node:assert/strict" { const assert:any; export default assert; }
