# Step 17 — Preference Model

Implemented as prerequisite for Step 18.
