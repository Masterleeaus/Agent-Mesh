# Step 22 — Explanation Engine

TypeScript reference implementation for user-facing decision explanations. It renders explanations from structured ranking factors, evidence references, assumptions, confidence, exclusions and sensitivity scenarios. It does **not** expose or persist hidden chain-of-thought. Explanations are audit-friendly summaries of explicit inputs and calculations only.

`company_id` remains the sole canonical company boundary. The engine has no permission, entitlement, approval or execution authority.
