# Step 24 — Decision History
TypeScript append-only decision history. New information creates a new revision linked by `supersedes_history_id`; prior snapshots are hash-verifiable and never edited in place.
