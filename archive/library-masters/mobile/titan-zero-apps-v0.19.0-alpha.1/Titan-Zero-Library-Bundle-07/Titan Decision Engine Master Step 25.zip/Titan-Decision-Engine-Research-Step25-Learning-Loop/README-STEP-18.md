# Step 18 — Comparison Engine

Implemented on cumulative Step 16 plus the Step 17 Preference Model prerequisite.
