declare module "node:assert/strict" { const assert: any; export default assert; }
declare module "node:crypto" { export function createHash(name: string): any; }
