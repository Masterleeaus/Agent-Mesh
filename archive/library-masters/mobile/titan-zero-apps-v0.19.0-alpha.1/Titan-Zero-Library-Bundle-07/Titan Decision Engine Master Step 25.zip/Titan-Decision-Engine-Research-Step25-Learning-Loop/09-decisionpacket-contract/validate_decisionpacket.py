#!/usr/bin/env python3
import json, sys, pathlib
DOMAINS={"operations","finance","workforce","environment","crm","assets","procurement","marketing","scheduling","other"}
REC_TYPES={"best_action","investigate","defer","escalate","request_approval","no_safe_action","insufficient_evidence"}
REQ=["packet_id","contract_version","company_id","domain","subject","objectives","options","evidence","constraints","preferences","predicted_outcomes","trade_offs","ranking","recommendation","confidence","authority_requirements","provenance","lifecycle"]
def validate(p):
 e=[]
 for k in REQ:
  if k not in p:e.append(f"missing:{k}")
 if p.get('contract_version')!='1.0.0':e.append('contract_version')
 if not p.get('company_id'):e.append('company_id required')
 if p.get('domain') not in DOMAINS:e.append('domain')
 if p.get('domain')=='other' and not p.get('domain_extension'):e.append('other requires domain_extension')
 opts={x.get('option_id') for x in p.get('options',[]) if isinstance(x,dict)}
 evs={x.get('evidence_id') for x in p.get('evidence',[]) if isinstance(x,dict)}
 rec=p.get('recommendation') or {}; typ=rec.get('recommendation_type'); rid=rec.get('recommended_option_id')
 if typ not in REC_TYPES:e.append('recommendation_type')
 if typ=='best_action' and rid not in opts:e.append('best_action must reference option')
 rank=p.get('ranking')
 if rank:
  for x in rank.get('rank_order',[]):
   if x not in opts:e.append('ranking references missing option:'+str(x))
  for x in rank.get('option_scores',[]):
   if x.get('option_id') not in opts:e.append('score references missing option:'+str(x.get('option_id')))
 for x in p.get('predicted_outcomes',[]):
  if x.get('option_id') not in opts:e.append('outcome references missing option:'+str(x.get('option_id')))
  for r in x.get('evidence_refs',[]):
   if r not in evs:e.append('outcome references missing evidence:'+str(r))
 a=p.get('authority_requirements') or {}
 if a.get('governed_execution_required') and not a.get('required'):e.append('governed execution implies authority required')
 forbidden={'tenant_id','tenant_company_id'}
 def walk(x,path=''):
  if isinstance(x,dict):
   for k,v in x.items():
    if k in forbidden:e.append('legacy tenant boundary field:'+path+k)
    walk(v,path+k+'.')
  elif isinstance(x,list):
   for v in x:walk(v,path)
 walk(p)
 return sorted(set(e))
if __name__=='__main__':
 rc=0
 for f in sys.argv[1:]:
  p=json.load(open(f)); e=validate(p)
  print(f, 'PASS' if not e else 'FAIL')
  for x in e:print(' -',x)
  rc|=bool(e)
 sys.exit(rc)
