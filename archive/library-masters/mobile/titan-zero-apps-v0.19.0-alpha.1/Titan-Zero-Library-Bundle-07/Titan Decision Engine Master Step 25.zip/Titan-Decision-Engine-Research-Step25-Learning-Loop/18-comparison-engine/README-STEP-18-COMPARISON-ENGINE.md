# Step 18 — Comparison Engine

A domain-neutral comparison layer for unlike alternatives. It compares options across cost, time, quality, risk, benefit, sustainability, reversibility, confidence, reliability, and strategic value while preserving raw measurements, units, assumptions, evidence and uncertainty.

## Boundary
This engine **does not rank or recommend**. It produces normalized profiles, coverage/confidence, pairwise trade-offs, and descriptive Pareto dominance. Ranking is Step 20; recommendation/best action is Step 21.

Hard constraint eligibility is carried through unchanged. Preferences can adjust advisory weights only; they cannot make an ineligible option eligible or grant authority.


## TypeScript convergence
Runtime, tests, and validation for this layer are now TypeScript-first. Superseded Python runtime/test/validator files were removed during the Step 25 TypeScript convergence pass.
