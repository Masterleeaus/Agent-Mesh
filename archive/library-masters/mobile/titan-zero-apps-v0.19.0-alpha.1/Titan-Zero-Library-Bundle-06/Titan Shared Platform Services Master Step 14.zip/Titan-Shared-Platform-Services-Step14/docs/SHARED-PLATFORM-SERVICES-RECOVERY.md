# Shared Platform Services Recovery — Step 14

This is a code-bearing convergence bundle.

Included:
- 31 actual provider source ZIPs from the strongest recovered converged platform;
- the converged AI Workforce orchestrator;
- a newer Bookings/Quotes lifecycle implementation;
- preserved Quality/Compliance/reporting donor source;
- canonical owner and contribution contracts.

Rules:
- `company_id` is the sole canonical company boundary.
- CRM owns customer/revenue authority.
- Field owns operational job/work-order execution.
- Connect owns communications execution.
- Financial Engine calculates; Ledger owns accounting consequences.
- AI Workforce owns the digital organisation but not domain truth.
- Governance/Risk/Assurance/Autonomy/Command Bus/Rewind remain distinct control-plane contributors.
- Reporting is projection-only.
- Donors do not become parallel authorities merely because their code is preserved.

Environmental systems:
No distinct environmental runtime/provider archive was present in the strongest recovered source set. A dedicated `Titan Environmental Intelligence` owner is reserved as `UNRESOLVED_SOURCE_REQUIRED`; no fake implementation was created.
