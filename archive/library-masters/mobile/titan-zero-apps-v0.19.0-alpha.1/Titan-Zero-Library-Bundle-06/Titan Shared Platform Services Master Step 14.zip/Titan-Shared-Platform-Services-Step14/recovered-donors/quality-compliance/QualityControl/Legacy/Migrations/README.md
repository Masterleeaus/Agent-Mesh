# Quarantined migration donors

These pre-convergence migration files are preserved for reference only and are intentionally renamed with `.disabled` so Laravel's migration loader cannot execute them. The matching `*_qc_*` migration files in `Database/Migrations` are the canonical guarded versions.
