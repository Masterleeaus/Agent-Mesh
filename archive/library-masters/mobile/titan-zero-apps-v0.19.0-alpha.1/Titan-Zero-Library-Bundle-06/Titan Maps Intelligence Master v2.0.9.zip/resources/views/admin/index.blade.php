@extends('panel.layout.app')

@section('content')
<div class="container-fluid py-6" data-titan-maps-admin-dashboard>
    <h1>Titan Maps Intelligence Administration</h1>
    <p class="text-muted">Provider, usage, security and diagnostics controls.</p>
</div>
@endsection
