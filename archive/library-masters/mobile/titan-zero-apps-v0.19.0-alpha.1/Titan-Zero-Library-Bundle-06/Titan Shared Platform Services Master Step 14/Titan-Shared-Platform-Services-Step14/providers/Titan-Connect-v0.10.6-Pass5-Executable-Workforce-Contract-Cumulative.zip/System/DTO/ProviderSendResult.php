<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\DTO;

final class ProviderSendResult
{
    public function __construct(
        public readonly string $status,
        public readonly ?string $providerMessageId = null,
        public readonly array $response = [],
    ) {
    }

    public function toArray(): array
    {
        return ['status' => $this->status, 'provider_message_id' => $this->providerMessageId, 'response' => $this->response];
    }
}
