<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\DTO;

final readonly class ApprovalState
{
    public function __construct(
        public string $approvalId,
        public string $planId,
        public string $stepId,
        public string $status,
        public string $reasonCode,
        public ?string $decidedByActorId = null,
        public ?string $decisionReason = null,
        public ?string $decidedAt = null,
    ) {}

    public static function pending(string $approvalId, string $planId, string $stepId, string $reasonCode): self
    {
        return new self($approvalId, $planId, $stepId, 'PENDING', $reasonCode);
    }

    public function approve(string $actorId, string $reason, string $decidedAt): self
    {
        return new self($this->approvalId, $this->planId, $this->stepId, 'APPROVED', $this->reasonCode, $actorId, $reason, $decidedAt);
    }

    public function deny(string $actorId, string $reason, string $decidedAt): self
    {
        return new self($this->approvalId, $this->planId, $this->stepId, 'DENIED', $this->reasonCode, $actorId, $reason, $decidedAt);
    }

    public function allowsExecution(): bool
    {
        return $this->status === 'APPROVED';
    }
}
