<?php
namespace App\Extensions\Crm\System\Contracts;
interface ContactRepositoryContract { public function search(int $userId, array $filters = []): array; public function create(int $userId, array $data): array; public function update(int $userId, string $publicId, array $data): array; }
