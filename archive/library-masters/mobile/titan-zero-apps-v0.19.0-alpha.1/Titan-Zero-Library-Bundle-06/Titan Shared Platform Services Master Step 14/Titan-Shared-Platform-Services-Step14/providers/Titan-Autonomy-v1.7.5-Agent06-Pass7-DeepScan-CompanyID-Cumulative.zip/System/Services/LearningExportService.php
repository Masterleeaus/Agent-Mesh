<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;

final class LearningExportService
{
    public function __construct(private readonly AutonomyQueryContract $query) {}

    public function exportTenant(int $tenantCompanyId): array
    {
        return [
            'schema' => 'titan-learning-export-v1',
            'tenant_company_id' => $tenantCompanyId,
            'exported_at' => gmdate(DATE_ATOM),
            'capability_states' => $this->query->capabilityStates($tenantCompanyId),
            'learning_settings' => $this->query->learningSettings($tenantCompanyId),
            'learning_preferences' => $this->query->learningPreferences($tenantCompanyId),
            'learning_events' => $this->query->learningEvents($tenantCompanyId, limit: 5000),
            'handshakes' => $this->query->handshakes($tenantCompanyId, limit: 1000),
            'regressions' => $this->query->regressions($tenantCompanyId, limit: 1000),
        ];
    }
}
