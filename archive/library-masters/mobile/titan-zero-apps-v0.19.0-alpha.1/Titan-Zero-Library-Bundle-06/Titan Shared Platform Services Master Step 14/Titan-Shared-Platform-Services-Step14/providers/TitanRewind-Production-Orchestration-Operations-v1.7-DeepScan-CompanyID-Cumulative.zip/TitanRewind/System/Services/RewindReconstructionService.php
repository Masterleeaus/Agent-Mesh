<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Reconstruction\RewindSourceAdapterRegistry;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTimelineAssembler;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Sources\RewindHostSourceDiscovery;
use App\Extensions\TitanRewind\System\Streaming\RewindStreamWindow;
use App\Extensions\TitanRewind\System\Streaming\RewindTraceStream;

final class RewindReconstructionService
{
    public function __construct(
        private RewindSourceAdapterRegistry $sources,
        private RewindEventStore $events,
        private RewindTimelineAssembler $assembler,
        private RewindTimelineService $timeline,
        private RewindDependencyService $dependencies,
        private RewindForensicsService $forensics,
        private RewindSnapshotComparisonService $snapshotComparisons,
        private RewindSourceWatermarkService $watermarks,
        private RewindHostSourceDiscovery $discovery,
        private ?RewindTraceStream $stream = null,
    ) {}

    public function refreshFromSources(RewindTraceQuery $query): int
    {
        $this->discovery->discover();
        $stored = 0;
        foreach ($this->sources->records($query) as $record) {
            $this->events->store($record);
            ++$stored;
        }
        $this->watermarks->refresh($query);
        return $stored;
    }

    public function reconstruct(RewindTraceQuery $query, bool $refreshSources = true): array
    {
        if ($refreshSources) $this->refreshFromSources($query);
        $this->timeline->materializeTrace($query);

        $stream = $this->stream ?? new RewindTraceStream();
        $window = (new RewindStreamWindow(5000))->consume($stream->arrays($query));
        $ordered = $this->assembler->order($window['items']);
        $causation = $this->assembler->causation($ordered);
        $dependencies = $this->dependencies->forTrace($query);
        $forensics = $this->forensics->diagnose($query, $ordered, $causation, $dependencies);

        $sources = []; $decisions = [];
        foreach ($ordered as $event) {
            if (($event['source_engine'] ?? '') !== '') $sources[(string)$event['source_engine']] = true;
            if (($event['decision_id'] ?? '') !== '') $decisions[(string)$event['decision_id']] = true;
        }
        $sourceList=array_keys($sources);sort($sourceList,SORT_STRING);
        $decisionList=array_keys($decisions);sort($decisionList,SORT_STRING);

        return [
            'tenant_company_id' => $query->tenantCompanyId(),
            'trace_id' => $query->traceId(),
            'correlation_id' => $query->correlationId(),
            'event_count' => (int)$window['observed_count'],
            'events_returned' => count($ordered),
            'events_truncated' => (bool)$window['truncated'],
            'analysis_scope' => $window['truncated'] ? 'BOUNDED_WINDOW' : 'COMPLETE_TRACE',
            'max_events_in_memory' => 5000,
            'source_engines' => $sourceList,
            'decision_ids' => $decisionList,
            'events' => $ordered,
            'causation' => $causation,
            'dependencies' => $dependencies,
            'forensics' => $forensics,
            'root_cause' => $forensics['root_cause'],
            'snapshot_comparisons' => $this->snapshotComparisons->forTrace($query),
            'source_completeness' => $this->watermarks->forTrace($query),
            'deterministic_order' => ['sequence','occurred_at','event_id'],
            'mutation_allowed' => false,
            'reconstruction_version' => 5,
        ];
    }
}
