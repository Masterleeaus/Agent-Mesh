<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Contracts;

use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecord;

interface OutcomeRecordRepositoryContract
{
    public function findByOperationId(int $tenantCompanyId, string $operationId): ?OutcomeRecord;

    public function insert(OutcomeRecord $record): void;
}
