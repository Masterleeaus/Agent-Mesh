<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Contracts\NexusCompilerContract;
use App\Extensions\TitanNexus\System\Contracts\VerticalDefinitionSourceContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompilationStatus;
use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Services\DeterministicNexusCompiler;
use App\Extensions\TitanNexus\System\Services\NexusManager;
use App\Extensions\TitanNexus\System\Services\SemanticNexusValidator;
use App\Extensions\TitanNexus\System\Adapters\Platform\PlatformReadinessAdapter;

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
$files = [
    '/System/Support/CanonicalJson.php',
    '/System/Support/DeterministicMerge.php',
    '/System/Domain/CompilationStatus.php',
    '/System/Domain/CompilationLifecycleStage.php',
    '/System/Domain/RuntimeReadinessReport.php',
    '/System/Domain/ValueObjects/TraceContext.php',
    '/System/Domain/BusinessProfile.php',
    '/System/Domain/CompiledTitanConfig.php',
    '/System/Domain/SemanticChangeKind.php',
    '/System/Domain/SemanticChangeDisposition.php',
    '/System/Domain/SemanticDiffEntry.php',
    '/System/Domain/ConfigurationDiff.php',
    '/System/Domain/VerticalDefinition.php',
    '/System/Domain/ValidationSeverity.php',
    '/System/Domain/ValidationFinding.php',
    '/System/Domain/ValidationResult.php',
    '/System/Domain/NexusCompilation.php',
    '/System/Contracts/NexusCompilerContract.php',
    '/System/Contracts/ConfigurationDifferContract.php',
    '/System/Contracts/VerticalDefinitionSourceContract.php',
    '/System/Contracts/PlatformReadinessSourceContract.php',
    '/System/Contracts/NexusValidatorContract.php',
    '/System/Contracts/NexusManagerContract.php',
    '/System/Adapters/Platform/PlatformReadinessAdapter.php',
    '/System/Services/DeterministicNexusCompiler.php',
    '/System/Services/SemanticConfigurationDiffer.php',
    '/System/Services/SemanticNexusValidator.php',
    '/System/Services/NexusManager.php',
];
foreach ($files as $file) {
    require_once $root . $file;
}

function managerCheck(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

$profile = BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '2.0.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
    'timezone' => 'Australia/Melbourne',
    'sections' => ['billing' => ['currency' => 'AUD']],
]);
$trace = TraceContext::fromArray([
    'tenant_company_id' => 42,
    'trace_id' => '11111111-1111-4111-8111-111111111111',
    'correlation_id' => '22222222-2222-4222-8222-222222222222',
    'causation_id' => '33333333-3333-4333-8333-333333333333',
]);
$compiler = new DeterministicNexusCompiler('0.5.0');
$source = new class implements VerticalDefinitionSourceContract {
    public int $calls = 0;
    public function resolve(BusinessProfile $profile): VerticalDefinition
    {
        $this->calls++;
        return VerticalDefinition::fromArray([
            'vertical_id' => $profile->verticalId(),
            'vertical_version' => $profile->verticalVersion(),
            'knowledge_snapshot_version' => 'au-vic-2026.08',
            'sections' => ['billing' => ['currency' => 'USD', 'tax_mode' => 'exclusive']],
        ]);
    }
};

$manager = new NexusManager($compiler, $source, new SemanticNexusValidator(new PlatformReadinessAdapter()));
$draft = $manager->newDraft($profile, $trace, '44444444-4444-4444-8444-444444444444');
managerCheck($draft->compilerVersion() === '0.5.0', 'new draft uses injected compiler version');
managerCheck($draft->status() === CompilationStatus::Draft, 'new draft remains side-effect-free draft');

$compiled = $manager->compileDraft($draft, '1');
managerCheck($compiled->status() === CompilationStatus::Compiled, 'compileDraft advances immutable aggregate');
managerCheck($source->calls === 1, 'compileDraft resolves vertical definition exactly once');
managerCheck($compiled->compiledConfiguration()?->sections()['billing']['currency'] === 'AUD', 'manager output uses compiler merge rules');
managerCheck($draft->status() === CompilationStatus::Draft, 'compileDraft does not mutate original draft');
managerCheck(($manager->health()['status'] ?? null) === 'UNAVAILABLE', 'health reports truthful unavailable status without runtime dependencies');

fwrite(STDOUT, "PASS: Titan Nexus standalone manager checks\n");
