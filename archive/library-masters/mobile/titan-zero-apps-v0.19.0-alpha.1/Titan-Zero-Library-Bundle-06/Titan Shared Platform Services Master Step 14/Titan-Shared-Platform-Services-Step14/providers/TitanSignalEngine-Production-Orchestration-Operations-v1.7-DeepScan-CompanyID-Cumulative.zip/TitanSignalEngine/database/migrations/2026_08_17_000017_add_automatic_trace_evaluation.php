<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_signal_trace_profiles') && ! Schema::hasColumn('titan_signal_trace_profiles', 'match_event_types')) {
            Schema::table('titan_signal_trace_profiles', function (Blueprint $table): void {
                $table->json('match_event_types')->nullable()->after('terminal_event_types');
            });

            DB::table('titan_signal_trace_profiles')
                ->orderBy('id')
                ->chunkById(250, function ($rows): void {
                    foreach ($rows as $row) {
                        $required = $this->jsonList($row->required_event_types ?? null);
                        $terminal = $this->jsonList($row->terminal_event_types ?? null);
                        $ordering = $this->jsonArray($row->ordering_rules ?? null);
                        $match = $required;
                        foreach ($ordering as $rule) {
                            if (! is_array($rule)) continue;
                            foreach (['before', 'after'] as $key) {
                                $value = trim((string) ($rule[$key] ?? ''));
                                if ($value !== '') $match[] = $value;
                            }
                        }
                        array_push($match, ...$terminal);
                        $match = array_values(array_unique($match));
                        DB::table('titan_signal_trace_profiles')->where('id', $row->id)->update([
                            'match_event_types' => json_encode($match, JSON_THROW_ON_ERROR),
                        ]);
                    }
                });
        }

        if (! Schema::hasTable('titan_signal_trace_assignments')) {
            Schema::create('titan_signal_trace_assignments', function (Blueprint $table): void {
                $table->id();
                $table->uuid('trace_id');
                $table->uuid('correlation_id')->nullable();
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->string('profile_key', 160);
                $table->unsignedInteger('profile_version');
                $table->string('status', 24)->default('open');
                $table->dateTime('first_event_at');
                $table->dateTime('last_event_at');
                $table->uuid('last_event_id');
                $table->string('last_event_type', 160);
                $table->boolean('terminal_seen')->default(false);
                $table->timestamp('last_evaluated_at')->nullable();
                $table->timestamp('next_evaluation_at')->nullable();
                $table->timestamp('fresh_until')->nullable();
                $table->string('last_analysis_status', 24)->nullable();
                $table->unsignedInteger('evaluation_generation')->default(0);
                $table->char('last_fingerprint', 64)->nullable();
                $table->unsignedInteger('last_event_count')->default(0);
                $table->unsignedInteger('last_sequence_violation_count')->default(0);
                $table->unsignedInteger('last_missing_event_count')->default(0);
                $table->unsignedInteger('last_profile_violation_count')->default(0);
                $table->unsignedInteger('failure_count')->default(0);
                $table->char('last_error_hash', 64)->nullable();
                $table->timestamps();
                $table->unique(['trace_id', 'scope', 'tenant_key', 'profile_key', 'profile_version'], 'tsta_trace_profile_uq');
                $table->index(['status', 'next_evaluation_at', 'id'], 'tsta_due_idx');
                $table->index(['scope', 'tenant_key', 'status', 'last_event_at'], 'tsta_scope_status_idx');
                $table->index(['correlation_id', 'scope', 'tenant_key'], 'tsta_correlation_idx');
            });
        }

        if (Schema::hasTable('titan_signal_trace_evaluations')) {
            Schema::table('titan_signal_trace_evaluations', function (Blueprint $table): void {
                if (! Schema::hasColumn('titan_signal_trace_evaluations', 'terminal_seen')) $table->boolean('terminal_seen')->default(false)->after('profile_violation_count');
                if (! Schema::hasColumn('titan_signal_trace_evaluations', 'history_complete')) $table->boolean('history_complete')->default(true)->after('terminal_seen');
                if (! Schema::hasColumn('titan_signal_trace_evaluations', 'cold_history_complete')) $table->boolean('cold_history_complete')->default(true)->after('history_complete');
                if (! Schema::hasColumn('titan_signal_trace_evaluations', 'evaluation_source')) $table->string('evaluation_source', 32)->default('manual')->after('cold_history_complete');
                if (! Schema::hasColumn('titan_signal_trace_evaluations', 'evaluation_fingerprint')) $table->char('evaluation_fingerprint', 64)->nullable()->after('evaluation_source');
                if (! Schema::hasColumn('titan_signal_trace_evaluations', 'fresh_until')) $table->timestamp('fresh_until')->nullable()->after('evaluated_at');
                if (! Schema::hasColumn('titan_signal_trace_evaluations', 'last_event_id')) $table->uuid('last_event_id')->nullable()->after('fresh_until');
                if (! Schema::hasColumn('titan_signal_trace_evaluations', 'last_event_at')) $table->timestamp('last_event_at')->nullable()->after('last_event_id');
                if (! Schema::hasColumn('titan_signal_trace_evaluations', 'evaluation_generation')) $table->unsignedInteger('evaluation_generation')->default(0)->after('last_event_at');
            });

            try { Schema::table('titan_signal_trace_evaluations', fn (Blueprint $table): mixed => $table->index(['scope', 'tenant_key', 'fresh_until', 'sequence_violation_count'], 'tste_fresh_sequence_idx')); } catch (\Throwable) {}
            try { Schema::table('titan_signal_trace_evaluations', fn (Blueprint $table): mixed => $table->index(['scope', 'tenant_key', 'terminal_seen', 'fresh_until', 'missing_event_count'], 'tste_fresh_missing_idx')); } catch (\Throwable) {}
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_trace_assignments');
        // Additive Titan migrations intentionally do not remove columns from long-lived historical tables.
    }

    /** @return list<string> */
    private function jsonList(mixed $value): array
    {
        $decoded = $this->jsonArray($value);
        $result = [];
        foreach ($decoded as $item) {
            $item = trim((string) $item);
            if ($item !== '') $result[] = $item;
        }
        return $result;
    }

    /** @return array<int,mixed> */
    private function jsonArray(mixed $value): array
    {
        if (is_array($value)) return $value;
        if ($value === null || $value === '') return [];
        $decoded = json_decode((string) $value, true);
        return is_array($decoded) ? array_values($decoded) : [];
    }
};
