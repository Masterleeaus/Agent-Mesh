<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Host\TitanFreshInstallPreflight;

$arguments = [];
foreach (array_slice($argv, 1) as $argument) {
    if (str_starts_with($argument, '--') && str_contains($argument, '=')) {
        [$key, $value] = explode('=', substr($argument, 2), 2);
        $arguments[$key] = $value;
    }
}

$root = $arguments['root'] ?? dirname(__DIR__);
require_once $root . '/System/Host/TitanInstallerManifestContract.php';
require_once $root . '/System/Host/TitanPackageIntegrityBuilder.php';
require_once $root . '/System/Host/TitanMySqlMigrationCompatibility.php';
require_once $root . '/System/Host/TitanFreshInstallPreflight.php';

$result = TitanFreshInstallPreflight::verifyDirectory($root);
$hostFactsPath = $arguments['host-facts'] ?? null;
if (is_string($hostFactsPath) && $hostFactsPath !== '') {
    if (!is_file($hostFactsPath)) {
        $result['host_compatibility'] = ['compatible' => false, 'reasons' => ['host_facts_file_missing']];
        $result['status'] = 'FAIL';
    } else {
        $facts = json_decode((string) file_get_contents($hostFactsPath), true, 512, JSON_THROW_ON_ERROR);
        $result['host_compatibility'] = TitanFreshInstallPreflight::evaluateHostFacts(is_array($facts) ? $facts : []);
    }
} else {
    $result['host_compatibility'] = [
        'compatible' => null,
        'reasons' => ['host_facts_not_supplied'],
        'note' => 'Directory/package preflight does not grant live INSTALLER_CERTIFIED.',
    ];
}

echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . PHP_EOL;
exit(($result['status'] ?? 'FAIL') === 'PASS' ? 0 : 1);
