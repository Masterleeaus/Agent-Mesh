# Signal Subscriptions & Distribution Implementation Plan

**Goal:** Add durable at-least-once, per-subscriber Signal distribution without coupling consumers or weakening immutable event storage.

**Architecture:** Persist code-registered subscription definitions and project one delivery-ledger row per matching subscriber for each immutable Signal event. Laravel Queue transports delivery jobs, while the ledger owns retry/DLQ state and allows recovery of pending work after queue/worker failures.

**Tech Stack:** PHP 8.2+, Laravel 10 Eloquent/Queue, MySQL-compatible migrations.

## Constraints
- Subscriber failure must never prevent another subscriber from receiving the same event.
- Delivery semantics are at-least-once; consumers must use event_id/delivery_id for idempotency.
- Do not build a custom queue transport.
- Do not mutate Signal events to track delivery state.
- Subscription definitions must declare accepted schema versions.
- Tenant/system boundaries remain enforced by the stored Signal event and delivery row.
- Failed deliveries move to subscriber-specific dead-letter state after bounded retries.
