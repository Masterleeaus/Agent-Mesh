<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$provider = file_get_contents($root . '/System/TitanAICoreServiceProvider.php');
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$orchestration = json_decode((string) file_get_contents($root . '/contracts/orchestration-planning.json'), true, flags: JSON_THROW_ON_ERROR);
$navigation = file_get_contents($root . '/System/Navigation/TitanAICoreNavigation.php');
$authDoc = file_get_contents($root . '/docs/AUTHORIZATION-MATRIX.md');
$healthCheck = file_get_contents($root . '/System/Services/HealthCheck.php');
$planSchema = json_decode((string) file_get_contents($root . '/schemas/plan-envelope.v1.schema.json'), true, flags: JSON_THROW_ON_ERROR);

$requiredFiles = [
    'System/Http/Middleware/ResolveTrustedCoreContext.php',
    'System/Http/Middleware/RequireCoreCapability.php',
    'System/Contracts/TrustedPrincipalResolverContract.php',
    'System/Contracts/PlanRepositoryContract.php',
    'System/Contracts/ModelProfileRepositoryContract.php',
    'System/Repositories/DatabasePlanRepository.php',
    'System/Repositories/DatabaseModelProfileRepository.php',
    'System/Queue/RestoresTrustedTenantContext.php',
    'database/migrations/2026_08_19_000005_add_trusted_actor_context_to_titan_ai_core_plans.php',
];
foreach ($requiredFiles as $relative) {
    if (!is_file($root . '/' . $relative)) {
        fwrite(STDERR, "Missing Pass 3 runtime file: {$relative}\n"); exit(1);
    }
}

foreach (['titan-ai-core.context', 'titan-ai-core.capability'] as $alias) {
    if (!str_contains($provider, $alias)) { fwrite(STDERR, "Missing middleware alias {$alias}\n"); exit(1); }
}
foreach (['ai.core.read','ai.core.health.read','ai.core.admin','ai.core.plan.create'] as $permission) {
    if (!in_array($permission, $manifest['permissions'] ?? [], true)) { fwrite(STDERR, "Missing manifest permission {$permission}\n"); exit(1); }
}
if (($orchestration['trusted_tenant_context'] ?? false) !== true || ($orchestration['trusted_actor_context'] ?? false) !== true) { fwrite(STDERR, "trusted orchestration context not declared\n"); exit(1); }
if (($manifest['authorization']['tenant_object_scope'] ?? false) !== true) { fwrite(STDERR, "tenant object scoping not declared\n"); exit(1); }
if (!str_contains($navigation, "'permission' => 'ai.core.read'") || !str_contains($navigation, "'permission' => 'ai.core.admin'")) {
    fwrite(STDERR, "navigation permission gating missing\n"); exit(1);
}
if (!str_contains($authDoc, 'trusted authenticated principal')) { fwrite(STDERR, "authorization matrix not updated\n"); exit(1); }




foreach (['trusted_principal_resolver_bound','plan_repository_bound','model_profile_repository_bound'] as $healthKey) {
    if (!str_contains($healthCheck, $healthKey)) { fwrite(STDERR, "security health check missing {$healthKey}\n"); exit(1); }
}

$runtimeSchema = $planSchema['properties']['runtime_context'] ?? [];
$actorSchema = $runtimeSchema['properties']['actor'] ?? [];
if (($runtimeSchema['additionalProperties'] ?? null) !== false) { fwrite(STDERR, "runtime context schema remains open-ended\n"); exit(1); }
if (($actorSchema['properties']['trusted']['const'] ?? null) !== true) { fwrite(STDERR, "plan schema does not require trusted actor context\n"); exit(1); }
if (!in_array('authority', $actorSchema['required'] ?? [], true) || !in_array('tenant_company_id', $actorSchema['required'] ?? [], true)) { fwrite(STDERR, "actor authority/tenant schema is incomplete\n"); exit(1); }

$planRepository = file_get_contents($root . '/System/Repositories/DatabasePlanRepository.php');
$modelRepository = file_get_contents($root . '/System/Repositories/DatabaseModelProfileRepository.php');
if (!str_contains($planRepository, "where('company_id', \$tenantCompanyId)") || !str_contains($planRepository, "orWhere('tenant_company_id', \$tenantCompanyId)")) { fwrite(STDERR, "plan repository lookup is not canonical-company scoped with legacy fallback\n"); exit(1); }
if (!str_contains($planRepository, '\'tenant_company_id\' => $runtimeContext->tenantCompanyId')) { fwrite(STDERR, "plan repository write does not force trusted tenant\n"); exit(1); }
if (!str_contains($planRepository, '\'actor_id\' => $runtimeContext->actor->actorId') || !str_contains($planRepository, '\'actor_type\' => $runtimeContext->actor->actorType')) { fwrite(STDERR, "trusted actor audit fields are not persisted\n"); exit(1); }
if (!str_contains($modelRepository, "where('company_id', \$tenantCompanyId)") || !str_contains($modelRepository, "orWhere('tenant_company_id', \$tenantCompanyId)") || !str_contains($modelRepository, "whereNull('company_id')")) { fwrite(STDERR, "model profile repository canonical scope/global fallback is not explicit\n"); exit(1); }
if (!str_contains($modelRepository, '->limit($limit)') || !str_contains($modelRepository, 'max(1, min(1000, $limit))')) { fwrite(STDERR, "model profile repository query is not explicitly bounded\n"); exit(1); }

fwrite(STDOUT, "Pass 3 runtime wiring contract test: PASS\n");
