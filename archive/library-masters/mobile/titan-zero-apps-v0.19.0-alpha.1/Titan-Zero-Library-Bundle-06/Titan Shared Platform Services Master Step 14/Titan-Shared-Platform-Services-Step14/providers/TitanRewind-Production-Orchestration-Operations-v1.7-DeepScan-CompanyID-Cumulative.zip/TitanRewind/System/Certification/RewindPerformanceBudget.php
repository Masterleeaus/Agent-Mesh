<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Certification;
final class RewindPerformanceBudget
{
    public function __construct(private int $memoryMb=256,private int $maxEventsInMemory=5000,private int $reconstructionP95Ms=5000){}
    public function evaluate(array $measurement): array
    {
        $checks=[
            'memory'=>(float)($measurement['peak_memory_mb']??INF)<=$this->memoryMb,
            'event_window'=>(int)($measurement['max_events_in_memory']??PHP_INT_MAX)<=$this->maxEventsInMemory,
            'reconstruction'=>(float)($measurement['reconstruction_p95_ms']??INF)<=$this->reconstructionP95Ms,
        ];
        return ['passed'=>!in_array(false,$checks,true),'checks'=>$checks,'budgets'=>['memory_mb'=>$this->memoryMb,'max_events_in_memory'=>$this->maxEventsInMemory,'reconstruction_p95_ms'=>$this->reconstructionP95Ms]];
    }
}
