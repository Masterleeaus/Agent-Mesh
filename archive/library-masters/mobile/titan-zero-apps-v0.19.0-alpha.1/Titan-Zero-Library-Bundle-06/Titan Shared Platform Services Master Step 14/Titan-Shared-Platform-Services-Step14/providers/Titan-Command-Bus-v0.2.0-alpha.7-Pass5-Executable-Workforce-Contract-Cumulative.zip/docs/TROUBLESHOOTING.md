# Troubleshooting

DEGRADED readiness is expected until database migrations are applied and trusted Governance and Signal bridges are bound. CAPABILITY_UNAVAILABLE means no adapter registered. IDEMPOTENCY_KEY_PAYLOAD_MISMATCH means the same key was reused for a different normalized request.
