# Titan Forge v0.8.0-alpha.1 — Pass 18 Release Notes

This cumulative development release completes formal Forge Pass 18: selective governed Model Council review.

Key additions:

- Titan Model Council v0.7 governed-deliberation adapter;
- high/critical selective invocation only;
- bounded release-review packet with no generated source/content;
- host-policy four-role model assignments with minimum three distinct models;
- sanitized Council review normalization and fingerprint;
- durable Forge `council.deliberation` receipt using existing receipt storage;
- fail-closed escalation/rejection/failure/configuration handling;
- explicit rejection of Council authority beyond `advisory_only`;
- optional Council compatibility floor raised to `>=0.7.0`;
- capability `forge.council.deliberate`.

No production deployment authority is added. No new database migration is required.
