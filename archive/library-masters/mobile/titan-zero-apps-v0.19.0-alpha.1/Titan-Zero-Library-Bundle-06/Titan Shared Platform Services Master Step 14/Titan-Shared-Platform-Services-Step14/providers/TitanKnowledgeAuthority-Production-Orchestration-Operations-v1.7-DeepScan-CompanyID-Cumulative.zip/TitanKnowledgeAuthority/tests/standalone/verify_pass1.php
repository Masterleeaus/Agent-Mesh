<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$check = static function (bool $ok, string $message) use (&$errors): void {
    if (! $ok) $errors[] = $message;
};

$manifestPath = $root . '/extension.json';
$manifest = json_decode((string) @file_get_contents($manifestPath), true);
$check(is_array($manifest), 'extension.json invalid JSON');
if (is_array($manifest)) {
    $requiredCore = ['schema', 'slug', 'folder', 'provider', 'version', 'integrity'];
    foreach ($requiredCore as $key) { $check(array_key_exists($key, $manifest), 'Titan root field missing: ' . $key); }
    $check(($manifest['schema'] ?? null) === 'titan-extension-v1', 'installer schema mismatch');
    $check(($manifest['slug'] ?? null) === 'titan-knowledge-authority', 'installer slug mismatch');
    $check(($manifest['folder'] ?? null) === 'TitanKnowledgeAuthority', 'installer folder mismatch');
    $check(($manifest['provider'] ?? null) === 'App\\Extensions\\TitanKnowledgeAuthority\\System\\TitanKnowledgeAuthorityServiceProvider', 'installer provider mismatch');
    $check(is_string($manifest['version'] ?? null) && preg_match('/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $manifest['version']) === 1, 'installer version mismatch');
    $integrity = $manifest['integrity']['files'] ?? null;
    $check(is_array($integrity), 'integrity.files missing');
    if (is_array($integrity)) {
        $expectedFiles = [];
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $file) {
            if (! $file->isFile()) continue;
            $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
            if ($relative === 'extension.json') continue;
            $expectedFiles[$relative] = hash_file('sha256', $file->getPathname());
        }
        ksort($expectedFiles); ksort($integrity);
        $check($integrity === $expectedFiles, 'integrity.files does not exactly match package files');
    }
}

$sidecar = json_decode((string) @file_get_contents($root . '/extension.manifest.json'), true);
$check(is_array($sidecar), 'extension.manifest.json invalid');
if (is_array($sidecar)) {
    $check(($sidecar['schema_version'] ?? null) === '2.2', 'sidecar schema mismatch');
    $check(($sidecar['version'] ?? null) === ($manifest['version'] ?? null), 'sidecar version mismatch');
    $check(($sidecar['architecture']['profile'] ?? null) === 'intelligence-engine', 'architecture profile mismatch');
    $check(in_array('knowledge-authority', $sidecar['architecture']['modifiers'] ?? [], true), 'knowledge-authority modifier missing');
    $check(($sidecar['authority']['cross_domain_write_policy'] ?? null) === 'forbidden', 'cross-domain write policy mismatch');
    $check(($sidecar['governance']['knowledge_authority'] ?? null) === 'self', 'knowledge authority self-governance mismatch');
    $check(($sidecar['queues']['used'] ?? null) === false, 'queues must remain disabled in rebase pass');
    $check(($sidecar['queues']['queue_names'] ?? null) === [], 'queue_names must be empty in rebase pass');
    $caps = $sidecar['capabilities'] ?? [];
    foreach (['knowledge.resolve', 'knowledge.refresh', 'knowledge.version', 'knowledge.applicability'] as $unimplemented) {
        $check(! in_array($unimplemented, $caps, true), "unimplemented capability advertised: {$unimplemented}");
    }
}

$provider = (string) @file_get_contents($root . '/System/TitanKnowledgeAuthorityServiceProvider.php');
$check(! str_contains($provider, "'extension'"), 'generic extension publish tag remains');
$check(str_contains($provider, "'titan-knowledge-authority-config'"), 'scoped publish tag missing');
$check(! str_contains($provider, 'Illuminate\\Contracts\\Http\\Kernel'), 'unused Kernel boot injection remains');

$causationMigrations = glob($root . '/database/migrations/*causation*') ?: [];
$check(count($causationMigrations) === 1, 'forward causation_id migration missing');
if ($causationMigrations !== []) {
    $migration = (string) file_get_contents($causationMigrations[0]);
    $check(str_contains($migration, "'causation_id'"), 'causation migration does not add causation_id');
}

$check(is_file($root . '/docs/reference/legacy-magicai-extension.json'), 'legacy manifest provenance missing');
$check(is_file($root . '/System/Support/TitanKnowledgeAuthorityNavigation.php'), 'navigation definition missing');
$check(is_file($root . '/System/Support/HostNavigationRegistrar.php'), 'host navigation registrar missing');

foreach (glob($root . '/tests/*/*Test.php') ?: [] as $testFile) {
    $source = (string) file_get_contents($testFile);
    $check(! str_contains($source, 'assertTrue(true)'), basename($testFile) . ' still contains placeholder assertion');
}
foreach ([$root . '/resources/views/index.blade.php', $root . '/resources/views/admin.blade.php'] as $viewFile) {
    $source = (string) @file_get_contents($viewFile);
    $check(! str_contains($source, '<x-layouts.app>'), basename($viewFile) . ' depends on unverified x-layouts.app component');
}

if ($errors !== []) {
    fwrite(STDERR, implode(PHP_EOL, $errors) . PHP_EOL);
    exit(1);
}

echo "Titan Knowledge Authority cumulative foundation verification: PASS\n";
