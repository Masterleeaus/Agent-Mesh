<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Runtime;

use InvalidArgumentException;
use LogicException;
use Throwable;

final class RewindFailureClassifier
{
    public function classify(Throwable $e): string
    {
        $message = strtoupper($e->getMessage());
        if ($e instanceof InvalidArgumentException || $e instanceof LogicException) return 'PERMANENT';
        foreach (['REPLAY_BOUNDARY_VIOLATION','AUTHORIZATION','PERMISSION','SIGNATURE MISMATCH','HASH MISMATCH'] as $needle) if (str_contains($message,$needle)) return 'PERMANENT';
        if (str_contains($message,'CANCEL')) return 'CANCELLED';
        return 'RETRYABLE';
    }
}
