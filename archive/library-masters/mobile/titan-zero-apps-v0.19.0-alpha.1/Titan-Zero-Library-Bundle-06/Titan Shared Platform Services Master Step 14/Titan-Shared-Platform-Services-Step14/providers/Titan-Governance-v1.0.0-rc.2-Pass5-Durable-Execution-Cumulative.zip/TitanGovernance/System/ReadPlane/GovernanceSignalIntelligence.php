<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ReadPlane;

use DateTimeImmutable;
use Throwable;

final class GovernanceSignalIntelligence
{
    public function __construct(
        private readonly GovernanceReadSourceRegistry $sources,
        private readonly SignalHeatmapProjector $heatmap,
        private readonly OperationalPressureDetector $pressure,
        private readonly CircuitBreakerProjector $breakers,
    ) {}

    /** @return array<string,mixed> */
    public function snapshot(int $tenantCompanyId, array $context=[]): array
    {
        $source=$this->sources->get('titan-signal');
        if($source===null) return $this->unavailable('UNAVAILABLE');

        try {
            $snapshot=$source->snapshot($tenantCompanyId,$context);
        } catch (Throwable) {
            return $this->unavailable('UNAVAILABLE','SOURCE_READ_FAILED');
        }

        $status=strtoupper((string)($snapshot['status'] ?? 'UNAVAILABLE'));
        if($status==='HEALTHY' && $this->isStale($snapshot['observed_at'] ?? null,$context)) $status='STALE';
        $snapshot['status']=$status;
        $pressure=is_array($snapshot['operational_pressure'] ?? null) ? $snapshot['operational_pressure'] : [];

        return [
            'schema_version'=>'1.0',
            'source'=>'titan-signal',
            'source_status'=>$status,
            'observed_at'=>$snapshot['observed_at'] ?? null,
            'reason'=>$snapshot['reason'] ?? null,
            'heatmap'=>$this->heatmap->project($snapshot),
            'operational_pressure'=>$this->pressure->detect($pressure),
            'circuit_breakers'=>$this->breakers->project($snapshot),
        ];
    }

    /** @return array<string,mixed> */
    private function unavailable(string $status, ?string $reason=null): array
    {
        $snapshot=['source'=>'titan-signal','status'=>$status,'observed_at'=>null,'signals'=>[],'circuit_breakers'=>[]];
        return [
            'schema_version'=>'1.0','source'=>'titan-signal','source_status'=>$status,'observed_at'=>null,'reason'=>$reason,
            'heatmap'=>$this->heatmap->project($snapshot),
            'operational_pressure'=>$this->pressure->detect([]),
            'circuit_breakers'=>$this->breakers->project($snapshot),
        ];
    }

    private function isStale(mixed $observedAt, array $context): bool
    {
        if(!is_string($observedAt) || trim($observedAt)==='') return false;
        try{$observed=new DateTimeImmutable($observedAt);}catch(Throwable){return true;}
        $now=$this->now($context);
        $staleAfter=max(1,(int)($context['stale_after_seconds'] ?? 300));
        return ($now->getTimestamp()-$observed->getTimestamp())>$staleAfter;
    }

    private function now(array $context): DateTimeImmutable
    {
        $value=$context['now'] ?? null;
        if(is_string($value) && trim($value)!==''){try{return new DateTimeImmutable($value);}catch(Throwable){}}
        return new DateTimeImmutable('now');
    }
}
