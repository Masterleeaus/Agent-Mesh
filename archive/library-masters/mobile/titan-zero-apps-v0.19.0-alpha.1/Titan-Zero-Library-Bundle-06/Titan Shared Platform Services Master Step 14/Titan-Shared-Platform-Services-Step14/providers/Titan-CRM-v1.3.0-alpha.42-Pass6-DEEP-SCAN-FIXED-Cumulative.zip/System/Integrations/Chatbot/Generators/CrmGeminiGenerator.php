<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\Chatbot\Generators;

use App\Domains\Entity\Enums\EntityEnum;
use App\Extensions\Chatbot\System\Generators\GeminiGenerator;
use App\Extensions\Chatbot\System\Tools\KnowledgeBase;
use App\Extensions\ChatbotEcommerce\System\Services\EcommerceToolService;
use App\Extensions\Crm\System\Integrations\Chatbot\CrmChatbotToolService;
use App\Helpers\Classes\ApiHelper;
use App\Helpers\Classes\MarketplaceHelper;

final class CrmGeminiGenerator extends GeminiGenerator
{
    public function tools(): array
    {
        $base=parent::tools();$crm=app(CrmChatbotToolService::class);if(!$crm->enabledForChatbot($this->chatbot))return $base;
        $existing=$base[0]['functionDeclarations']??[];$base[0]['functionDeclarations']=array_merge($existing,$crm->definitionsForGemini($this->chatbot));return $base;
    }

    public function generate(): string
    {
        $crm=app(CrmChatbotToolService::class);if(!$crm->enabledForChatbot($this->chatbot))return parent::generate();
        $apiKey=ApiHelper::setGeminiKey();$histories=array_values($this->modifyMessages());$build=$this->buildHistories($histories);$system=$this->extractSystemInstruction($build);$contents=$this->formatContentsForGemini($build);
        $body=['contents'=>$contents,'tools'=>$this->tools()];if($system)$body['systemInstruction']=['parts'=>[['text'=>$system]]];$result=$this->chat($body,$apiKey);$calls=$this->extractFunctionCalls($result);if($calls===[])return $this->extractText($result)?:'Sorry, I can\'t answer that.';
        $contents[]=['role'=>'model','parts'=>$calls];$ecommerceUi=null;$hasKnowledge=false;$hasCrm=false;$handled=false;
        foreach($calls as $call){if(!isset($call['functionCall']))continue;$name=(string)$call['functionCall']['name'];$args=(array)($call['functionCall']['args']??[]);
            if(MarketplaceHelper::isRegistered('chatbot-ecommerce')){$data=app(EcommerceToolService::class)->handleGeminiToolCallWithUi($this->chatbot,$name,$args);if($data!==null){$ecommerceUi=$data['ui'];$handled=true;$contents[]=$this->response($name,$data['ai_content']);continue;}}
            if(str_starts_with($name,'crm_')){try{$data=$crm->execute($this->chatbot,$this->conversation,$name,$args);if($data!==null){$hasCrm=true;$handled=true;$contents[]=$this->response($name,$data['ai_content']);continue;}}catch(\Throwable $e){$hasCrm=true;$handled=true;$contents[]=$this->response($name,json_encode(['ok'=>false,'error'=>$e->getMessage()]));continue;}}
            if($name==='knowledge_base'&&isset($this->embeddings)&&$this->embeddings->isNotEmpty()){$hasKnowledge=true;$handled=true;$content=app(KnowledgeBase::class)->setChatbot($this->chatbot)->call(EntityEnum::from($this->chatbot->getAttribute('ai_embedding_model')),(string)($args['query']??''),$this->embeddings);$contents[]=$this->response($name,$content);}
        }
        if(!$handled)return $this->extractText($result)?:'Sorry, I can\'t answer that.';
        if($ecommerceUi!==null&&!$hasKnowledge&&!$hasCrm)return $ecommerceUi;
        $body['contents']=$contents;unset($body['tools']);$final=$this->chat($body,$apiKey);$answer=$this->extractText($final)?:'Sorry, I can\'t answer that.';return $ecommerceUi!==null?'<p>'.e($answer).'</p>'.$ecommerceUi:$answer;
    }

    private function response(string $name,string $content): array
    { return ['role'=>'function','parts'=>[['functionResponse'=>['name'=>$name,'response'=>['content'=>$content]]]]]; }
}
