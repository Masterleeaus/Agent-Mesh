<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\AI;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
final class CrmRecordReferenceResolver
{
    private const TABLES=['company'=>'crm_companies','contact'=>'crm_contacts','lead'=>'crm_leads','deal'=>'crm_deals','project'=>'crm_projects','task'=>'crm_tasks','invoice'=>'crm_invoices','estimate'=>'crm_estimates','proposal'=>'crm_proposals'];
    public function __construct(private ConnectionInterface $db){}
    public function resolve(int $userId,?string $type,?string $publicId): ?array
    { if(!$type||!$publicId||!isset(self::TABLES[$type]))return null;$row=$this->db->table(self::TABLES[$type])->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->first();return $row?(array)$row:null; }
}
