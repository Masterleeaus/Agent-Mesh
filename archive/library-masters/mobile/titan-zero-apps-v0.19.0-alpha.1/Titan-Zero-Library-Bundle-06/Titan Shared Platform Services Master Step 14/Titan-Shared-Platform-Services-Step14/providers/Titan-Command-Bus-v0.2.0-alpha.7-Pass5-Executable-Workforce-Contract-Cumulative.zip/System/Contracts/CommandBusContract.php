<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Contracts;

use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandReceipt;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;

interface CommandBusContract
{
    public function dispatch(CommandContext $context, CommandRequest $request): CommandReceipt;
    public function health(): array;
}
