<?php

declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Models;
use Illuminate\Database\Eloquent\Model;
final class RewindRuntimeState extends Model
{
    protected $table='titan_rewind_runtime_state';
    protected $fillable=['scope_key','state','reason','updated_by_id'];
    protected $casts=['updated_by_id'=>'integer'];
}
