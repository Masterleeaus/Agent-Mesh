# Security

Prime mission persistence is tenant-scoped by construction and gateway requests preserve the same tenant plus full causal context.

`EngineGatewayRequest` recursively rejects exact payload keys named `password`, `token`, `secret`, `authorization`, or `signature`. Gateway response mismatches are rejected, and raw downstream exception messages are not returned through the gateway result.

The default external-engine bridge is fail-closed and carries no credentials. A concrete host adapter must use the target engine's trusted public contract/service identity and must not widen Prime's authority.

Cross-domain state remains outside Prime ownership and may only be mutated through a future governed Command Bus capability.
