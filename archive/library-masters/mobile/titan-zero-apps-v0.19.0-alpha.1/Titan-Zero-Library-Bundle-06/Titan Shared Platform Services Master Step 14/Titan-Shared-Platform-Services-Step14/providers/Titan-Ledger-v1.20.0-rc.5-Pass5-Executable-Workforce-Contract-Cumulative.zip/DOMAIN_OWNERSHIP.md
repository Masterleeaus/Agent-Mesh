# Titan Ledger Domain Ownership — Pass 6

Titan Ledger is the single authoritative writer for its accounting domain: Chart of Accounts, journal headers/lines, fiscal periods/locks, Ledger command receipts and the Ledger-owned financial event outbox.

## Boundaries

- `company_id` is the canonical Ledger tenant boundary.
- CRM may remain authoritative for CRM invoice/customer records; Ledger receives governed facts/adapters rather than becoming a CRM table writer.
- Titan Command Bus owns governed command dispatch/idempotency/governance execution state; Ledger owns the authoritative accounting adapter and domain receipt proving the financial write.
- Titan Signal owns the platform append-only Signal/event runtime. Ledger owns only its durable delivery outbox and event contract preparation; Signal never writes Ledger accounting state.
- Titan Rewind, Risk, Assurance and Autonomy remain external peer engines.

## Pass 6 Signal ownership

`titan_ledger_signal_outbox` is Ledger-owned delivery evidence, not a competing Signal database. It exists so authoritative financial state and the fact-to-be-published cannot diverge during failures. Successful delivery may append a transport receipt but cannot rewrite financial event identity/payload.

External extensions must not write any Titan Ledger table directly. Consequential financial mutation continues through Titan Command Bus and Ledger's authoritative adapter.

## Pass 7 governance and forensic boundary

Titan Ledger remains the only writer of Ledger-owned financial state. Titan Risk owns risk decisions; Titan Assurance owns evidentiary assurance decisions; Titan Rewind owns forensic reconstruction/read models. Ledger stores only durable external decision references/evidence metadata and exposes a read-only Rewind source. None of these integrations may write accounting truth.

## CRM invoice accounting boundary
- Titan CRM owns invoice documents, numbering, customer-facing lifecycle and invoice facts.
- Titan Ledger owns accounting interpretation and journal posting.
- CRM calls the public `titan.ledger.crm-invoice-accounting.v1` port; the port submits through Titan Command Bus.
- `titan_ledger_crm_invoice_postings` is immutable Ledger evidence, not a second invoice database.
- No Ledger service reads CRM invoice, payment allocation, payment or refund tables directly.

## Pass 9 — payment settlement ownership

Titan Pay owns payment-session, rail/provider, settlement confirmation and refund facts. Titan Ledger does not read or mutate Titan Pay / ZeroPay internal tables. Ledger owns only the accounting consequence and immutable evidence table `titan_ledger_payment_settlements`.

Canonical accounting ingress is `titan.ledger.payment-settlement.v1`; `titan.ledger.zeropay-settlement.v1` is a compatibility alias. Consequential posting still enters through Titan Command Bus and remains Risk/Assurance gated. Payment settlements never become a second invoice/revenue authority.

## Pass 10 — Receivables and collections

- `titan_ledger_receivables` is a Titan Ledger-owned **read model**, not a new invoice/payment authority.
- Its source truth is only `titan_ledger_crm_invoice_postings` plus `titan_ledger_payment_settlements`.
- `titan_ledger_collection_events` is Ledger-owned append-only workflow evidence for collection state/follow-up facts.
- CRM still owns invoice lifecycle/customer document facts; Titan Pay still owns settlement facts.
- Titan Ledger owns accounting consequences, AR projection, aging and Ledger-local collection state.
- Outbound communications are explicitly outside Ledger authority.

### Pass 11 AP / spend boundary
- External Budgeting/purchasing systems own spend approval, supplier-document lifecycle and operational procurement facts.
- Titan Ledger owns financial posting, AP control-account consequences, GST accounting, immutable spend evidence and payables projections.
- External extensions must use `titan.ledger.spend-accounting.v1`; they must not write Ledger tables.
- Titan Ledger must not import or query private Budgeting/purchasing tables.

### Pass 12 banking / reconciliation boundary
- External bank-feed/open-banking providers own connectivity and source statement facts.
- Titan Pay and other payment systems remain payment execution/settlement authorities.
- Titan Ledger owns bank statement evidence, reconciliation matching evidence and account-level balance proof only.
- Bank statement import is evidence-only and must never create or infer a financial journal.
- Reconciliation links only to existing posted Ledger bank-account journal lines; it cannot mutate those journals.
- Raw bank narrative is not retained by the normalized fact; bounded SHA-256 reference hashes may be used for deterministic matching.


### Pass 13 Australian GST / BAS boundary

Titan Ledger owns GST accounting evidence derived from its immutable CRM invoice and spend postings, plus versioned GST tax snapshots. It may calculate and freeze Simpler BAS labels G1, 1A and 1B. Titan Ledger does not own ATO identity, SBR credentials, BAS lodgement, tax-agent authority or ATO submission transport. Finalized tax snapshots are evidence and are never rewritten; later corrections create a superseding snapshot.


### Pass 14 financial reporting boundary

Titan Ledger owns financial statement calculation because the statements are projections of its authoritative posted double-entry journals. The read-only public boundary is `titan.ledger.financial-reporting.v1`. Financial statements must not read CRM, Titan Pay, bank-feed or spend-provider private tables directly. `titan_ledger_financial_report_snapshots` is immutable Ledger evidence, not a second journal or reporting authority. Snapshot preparation/finalization/supersession are governed Command Bus mutations; external consumers may read reports but must not write snapshot or journal tables.


### Pass 15 forecasting / profitability boundary

Titan Ledger owns read-only financial projections of its own posted journals and Ledger-owned AR/AP projections. Forecasting is advisory evidence only and has no journal, payment, procurement, collection-message or other business mutation authority. `titan_ledger_forecast_snapshots` stores immutable forecast evidence, not accounting truth. Confidence means evidence coverage and must not be presented as payment probability. Customer/job profitability remains incomplete until an authoritative external dimension mapping is supplied; Ledger must not infer those dimensions from unrelated source IDs.

## Production certification and rollback ownership — v1.16.0-rc.1
Titan Ledger financial, governance, Signal, reconciliation, tax, reporting and forecast evidence is retained on rollback/uninstall. Historical migration `down()` paths are intentionally non-destructive. Upgrade hardening marks Ledger-owned schema registry rows with `retain_*` ownership modes and replays idempotent trigger-bearing migration `up()` paths to self-heal missing MySQL guards. Canonical tenancy remains `company_id`; legacy tenant resolver names are compatibility-only and cannot become a persistence/query boundary.


## New-plan Step 2 fiscal close ownership

Titan Ledger owns fiscal-year close calculation, prepared/closed close evidence, year-end close/reopen journals and Retained Earnings transfer because these are consequences of Ledger-owned posted accounting truth. The read-only public binding is `titan.ledger.financial-year-close.v1`; mutation remains Titan Command Bus only. `titan_ledger_financial_year_closes` is immutable once closed and `titan_ledger_financial_year_close_events` is append-only. Reopening never deletes a close journal or financial-year evidence; it creates a governed linked reopen journal and restores periods to the established soft-lock state. Historical P&L excludes close/reopen mechanics so year-over-year economics are not distorted.

## New Plan Step 3 — advanced GST ownership

- Titan Ledger owns immutable GST adjustment, review and BAS snapshot-detail evidence.
- Financial-impact GST adjustments must reference an existing posted Ledger journal; the adjustment workflow never creates accounting entries directly.
- Accountants/reviewers approve or reject adjustment evidence through governed Command Bus commands; review history is append-only.
- Full-BAS classification is financial reporting evidence, not a second sales/purchasing system.
- ATO/SBR submission, tax-agent authority and credentials remain outside Titan Ledger.
- `company_id` remains the sole canonical tenant boundary.


## Step 4 multi-account banking ownership

Titan Ledger owns financial classification and accounting evidence for registered bank, credit-card and clearing accounts. The registry points to existing Ledger Chart of Accounts records; it does not duplicate account balances. External banking/payment systems remain authorities for bank connectivity, payment initiation, provider settlement execution, card authorization and credentials. Titan Pay remains settlement-fact authority.

`titan_ledger_financial_accounts` and `titan_ledger_banking_movements` are Ledger-owned retained evidence with canonical `company_id` tenancy and immutable MySQL guards. `titan_ledger_payment_settlements.funds_account_public_id` records where a provider settlement was financially recognized. Clearing is not treated as cash; a separately governed `ledger.banking.clearing.settle` fact is required before funds move from clearing to a registered bank account. Credit-card accounts remain liability accounts and reconcile using signed debit-minus-credit Ledger balance convention.


## Step 5 advanced reconciliation ownership

Titan Ledger owns reconciliation evidence linking imported bank-statement facts to existing posted Ledger account movements. External bank-feed providers remain source-data/connectivity authorities and payment systems remain payment execution authorities. Reconciliation suggestions and groups never create payment facts.

`titan_ledger_reconciliation_groups`, group events and group-member rows are retained immutable evidence under canonical `company_id`. `titan_ledger_reconciliation_active_members` is a derived mutable uniqueness index only; rejecting a group releases active membership without deleting forensic history. Bank fee/interest adjustments may create new governed Ledger journals, but only for the bounded adjustment catalogue and only through the established Command Bus/Risk/Assurance path. Raw bank narrative is not retained.
