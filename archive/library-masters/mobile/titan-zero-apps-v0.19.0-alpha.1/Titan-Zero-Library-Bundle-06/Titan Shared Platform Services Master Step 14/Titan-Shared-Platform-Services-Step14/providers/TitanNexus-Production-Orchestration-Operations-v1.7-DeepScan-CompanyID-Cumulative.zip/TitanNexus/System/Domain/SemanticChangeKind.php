<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

enum SemanticChangeKind: string
{
    case Unchanged = 'unchanged';
    case Add = 'add';
    case Modify = 'modify';
    case Deprecate = 'deprecate';
}
