@extends($layout)
@section('title', 'Autonomy Learning')
@section('content')
<div class="ta-card">
    <h1 style="margin-top:0">Titan Autonomy Learning</h1>
    <p class="ta-muted">Capability-specific authority, gate evidence, learning and integration health.</p>
    @if(session('titan_autonomy_status'))<div class="ta-ok">{{ session('titan_autonomy_status') }}</div>@endif
    @if(session('titan_autonomy_error'))<div class="ta-error">{{ session('titan_autonomy_error') }}</div>@endif
</div>
<div class="ta-grid">
    <div class="ta-card"><strong>{{ $overview['totals']['capabilities'] ?? 0 }}</strong><div class="ta-muted">Governed capabilities</div></div>
    <div class="ta-card"><strong>{{ $overview['totals']['eligible'] ?? 0 }}</strong><div class="ta-muted">Next gates eligible</div></div>
    <div class="ta-card"><strong>{{ $overview['totals']['trusted_auto'] ?? 0 }}</strong><div class="ta-muted">Trusted Auto scopes</div></div>
    <div class="ta-card"><strong>{{ $overview['totals']['regressions'] ?? 0 }}</strong><div class="ta-muted">Recorded regressions</div></div>
</div>
<div class="ta-card">
    <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap"><h2>Capabilities</h2><div><a class="ta-btn secondary" href="{{ route('titan-autonomy.operations.index') }}">Operations & Exceptions</a> <a class="ta-btn secondary" href="{{ route('titan-autonomy.learning') }}">Learning Settings</a></div></div>
    <table class="ta-table"><thead><tr><th>Capability</th><th>Workflow</th><th>Risk</th><th>Current</th><th>Next</th><th>Streak</th><th>Eligibility</th><th></th></tr></thead><tbody>
    @forelse($overview['states'] as $state)
        <tr>
            <td>{{ $state['capability'] }}</td><td>{{ $state['workflow_key'] ?: 'default' }}</td><td><span class="ta-pill">{{ strtoupper($state['risk']) }}</span></td>
            <td>{{ $state['current_level'] }}</td><td>{{ $state['next_level'] ?? '—' }}</td><td>{{ $state['current_success_streak'] }} / {{ $state['required_success_streak'] }}</td>
            <td>{{ $state['platform_gate_eligible'] ? 'Eligible' : 'Locked' }}</td>
            <td><a class="ta-btn secondary" href="{{ route('titan-autonomy.capability', ['capability'=>$state['capability'],'workflowKey'=>$state['workflow_key'] ?: null]) }}">Review</a></td>
        </tr>
    @empty<tr><td colspan="8" class="ta-muted">No governed capability state has been recorded yet.</td></tr>@endforelse
    </tbody></table>
</div>
<div class="ta-card"><h2>Host Bridges</h2><div class="ta-grid">
@foreach($overview['bridges'] as $name => $bridge)<div><strong>{{ str_replace('_',' ',ucwords($name,'_')) }}</strong><div>{{ $bridge['available'] ? 'Available' : 'Unavailable / fail-closed' }}</div><small class="ta-muted">{{ $bridge['class'] }}</small></div>@endforeach
</div></div>
@endsection
