# Upgrade 10.2 → 10.3

1. Back up extension-owned Interaction tables and deployed extension files.
2. Install v10.3.0 over the existing `InteractionEngine` folder; preserve all `company_id` data and run normal forward migrations in the real host.
3. Clear Laravel caches after installation.
4. Remove host bindings that target the retired WorkCore adapter/dispatcher. Bind the appropriate Phase 6 provider gateways instead.
5. Migrate callers to canonical capabilities such as `crm.work_order.create`, `crm.work_order.complete`, `crm.quote.create`, `crm.invoice.create` and `crm.payment.record`. Deprecated aliases remain temporarily for request migration only.
6. Do not reuse approval signatures created for legacy capability aliases. Re-authorize against the canonical capability because approval evidence is intentionally capability-bound.
7. Update field-services onboarding clients: `approved_action_ids` is no longer accepted by `/execute`; call the dedicated `/approve` endpoint and then execute using server-stored signed approval evidence.
8. Bind optional CRM/Builder/Chatbot/Connect/Mobile/TitanAI gateways only when the owning extension exposes a verified company-scoped public contract. Missing gateways are expected to report unavailable rather than simulated success.
9. Verify provider readiness and company-scoped health before activation.
10. In the real host run `php artisan optimize:clear`, `php artisan route:list`, `php artisan migrate --pretend` and the host test suite before deployment.

## Rollback

Phase 6 removes active WorkCore runtime classes and changes canonical capability names. Rolling application files back to v10.2 requires restoring the matching v10.2 extension package and its integration bindings. Phase 6 migrations are forward-oriented and should not be destructively rolled back merely to restore application files. Preserve extension-owned data and prefer an application rollback plus compatibility bindings.
