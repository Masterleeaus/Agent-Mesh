<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$required = [
    'System/DTO/TrustedPrincipal.php',
    'System/DTO/AuthorityContext.php',
    'System/DTO/ActorContext.php',
    'System/DTO/RuntimeContext.php',
    'System/DTO/TenantModelAccessPolicy.php',
    'System/DTO/ModelCapabilityProfile.php',
    'System/Exceptions/SecurityContextException.php',
    'System/Security/TrustedContextFactory.php',
    'System/Security/TenantRuntimeGuard.php',
    'System/Security/CapabilityAuthorizer.php',
    'System/Security/ModelAccessGuard.php',
    'System/Security/TenantScopeKey.php',
];
foreach ($required as $relative) {
    if (!is_file($root . '/' . $relative)) {
        fwrite(STDERR, "Missing Pass 3 security file: {$relative}\n");
        exit(1);
    }
    require_once $root . '/' . $relative;
}

use App\Extensions\TitanAICore\System\DTO\ModelCapabilityProfile;
use App\Extensions\TitanAICore\System\DTO\TenantModelAccessPolicy;
use App\Extensions\TitanAICore\System\DTO\TrustedPrincipal;
use App\Extensions\TitanAICore\System\Exceptions\SecurityContextException;
use App\Extensions\TitanAICore\System\Security\CapabilityAuthorizer;
use App\Extensions\TitanAICore\System\Security\ModelAccessGuard;
use App\Extensions\TitanAICore\System\Security\TenantRuntimeGuard;
use App\Extensions\TitanAICore\System\Security\TenantScopeKey;
use App\Extensions\TitanAICore\System\Security\TrustedContextFactory;

$principal = new TrustedPrincipal(
    actorId: 'user-7',
    actorType: 'human',
    tenantCompanyId: 'company-7',
    permissions: ['ai.core.read', 'ai.core.plan.create'],
    authorityLevel: 3,
    authenticationSource: 'host-session',
);

$factory = new TrustedContextFactory();
$runtime = $factory->create(
    principal: $principal,
    traceId: 'trace-7',
    correlationId: 'corr-7',
    causationId: 'cause-7',
    rootCausationId: 'root-7',
    operationId: 'op-7',
    idempotencyKey: 'idem-7',
    claimedTenantCompanyId: 'company-7',
    claimedActorId: 'user-7',
    claimedActorType: 'human',
);

if (!$runtime->actor->trusted || $runtime->actor->actorId !== 'user-7' || $runtime->tenantCompanyId !== 'company-7') {
    fwrite(STDERR, "trusted runtime context was not derived from principal\n"); exit(1);
}
if ($runtime->actor->authority->level !== 3 || !$runtime->actor->authority->allows('ai.core.plan.create')) {
    fwrite(STDERR, "authority context missing or incorrect\n"); exit(1);
}

foreach ([
    ['tenant' => 'company-8', 'actor' => 'user-7', 'type' => 'human', 'code' => 'TENANT_SPOOFING_DETECTED'],
    ['tenant' => 'company-7', 'actor' => 'user-8', 'type' => 'human', 'code' => 'ACTOR_SPOOFING_DETECTED'],
    ['tenant' => 'company-7', 'actor' => 'user-7', 'type' => 'ai_agent', 'code' => 'ACTOR_TYPE_SPOOFING_DETECTED'],
] as $case) {
    try {
        $factory->create($principal, 't', 'c', 'cause', 'root', 'op', 'idem', $case['tenant'], $case['actor'], $case['type']);
        fwrite(STDERR, "spoofing case unexpectedly accepted: {$case['code']}\n"); exit(1);
    } catch (SecurityContextException $e) {
        if ($e->securityCode !== $case['code']) {
            fwrite(STDERR, "wrong spoofing code: {$e->securityCode}\n"); exit(1);
        }
    }
}

$guard = new TenantRuntimeGuard();
$guard->assertTenant('company-7', $runtime);
try {
    $guard->assertTenant('company-8', $runtime);
    fwrite(STDERR, "cross-tenant access unexpectedly accepted\n"); exit(1);
} catch (SecurityContextException $e) {
    if ($e->securityCode !== 'CROSS_TENANT_ACCESS_DENIED') { fwrite(STDERR, "wrong cross-tenant code\n"); exit(1); }
}

$authorizer = new CapabilityAuthorizer();
$authorizer->assertAllowed($runtime->actor, 'ai.core.read', 1);
try {
    $authorizer->assertAllowed($runtime->actor, 'ai.core.admin', 4);
    fwrite(STDERR, "authority escalation unexpectedly accepted\n"); exit(1);
} catch (SecurityContextException $e) {
    if (!in_array($e->securityCode, ['CAPABILITY_DENIED','AUTHORITY_LEVEL_INSUFFICIENT'], true)) { fwrite(STDERR, "wrong authority code\n"); exit(1); }
}

$tenantProfile = new ModelCapabilityProfile('openai', 'model-x', '1', [], 'low', 'summarize', 'company-7');
$globalProfile = new ModelCapabilityProfile('openai', 'model-y', '1', [], 'low', 'summarize', null);
$otherTenantProfile = new ModelCapabilityProfile('openai', 'model-z', '1', [], 'low', 'summarize', 'company-8');
$policy = new TenantModelAccessPolicy('company-7', ['openai'], [], [], [], false);
$modelGuard = new ModelAccessGuard();
if (!$modelGuard->allows($policy, $tenantProfile)) { fwrite(STDERR, "tenant model unexpectedly denied\n"); exit(1); }
if ($modelGuard->allows($policy, $globalProfile)) { fwrite(STDERR, "global fallback unexpectedly allowed\n"); exit(1); }
if ($modelGuard->allows($policy, $otherTenantProfile)) { fwrite(STDERR, "foreign tenant model unexpectedly allowed\n"); exit(1); }
$globalAllowed = new TenantModelAccessPolicy('company-7', ['openai'], [], [], [], true);
if (!$modelGuard->allows($globalAllowed, $globalProfile)) { fwrite(STDERR, "explicit global fallback unexpectedly denied\n"); exit(1); }

if (TenantScopeKey::forTenant('company-7') === TenantScopeKey::global()) {
    fwrite(STDERR, "tenant and global scope keys collide\n"); exit(1);
}

fwrite(STDOUT, "Pass 3 tenant/actor/authority security test: PASS\n");
