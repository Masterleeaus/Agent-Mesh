# Capabilities

## Implemented in v0.5.0

- `titan-ai-core` — extension/runtime identity
- `ai.runtime.status` — fail-closed runtime status
- `ai.plan.contract.typed` — typed non-executable plan contract
- `ai.security.trusted-context` — authenticated-principal derived actor/tenant context
- `ai.security.tenant-scope` — tenant-scoped Core persistence boundary
- `ai.security.authority-context` — trusted capability/authority context
- `ai.governance.preflight` — fail-closed Risk/Assurance/Autonomy preflight boundary
- `ai.command-bus.boundary` — Command Bus-only mutation delegation boundary
- `ai.approval.state` — typed pending/approved/denied human review state

## Authorization permissions

- `ai.core.read`
- `ai.core.health.read`
- `ai.core.admin`
- `ai.core.plan.create`

These capabilities do not make plan execution operational. DAG execution and consequential Command Bus dispatch remain disabled by the orchestration/runtime configuration.
