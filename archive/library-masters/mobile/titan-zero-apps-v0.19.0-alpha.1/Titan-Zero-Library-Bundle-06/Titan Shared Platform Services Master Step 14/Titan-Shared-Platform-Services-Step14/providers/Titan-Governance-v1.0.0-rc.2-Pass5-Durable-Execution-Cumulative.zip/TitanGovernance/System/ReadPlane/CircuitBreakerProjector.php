<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ReadPlane;

final class CircuitBreakerProjector
{
    /** @return array<string,mixed> */
    public function project(array $sourceSnapshot): array
    {
        $items=[];
        foreach (($sourceSnapshot['circuit_breakers'] ?? []) as $breaker) {
            if (!is_array($breaker)) continue;
            $state=strtoupper(trim((string)($breaker['state'] ?? 'UNKNOWN')));
            if (!in_array($state,['OPEN','HALF_OPEN','CLOSED','DISABLED'],true)) $state='UNKNOWN';
            $row=[
                'breaker_key'=>(string)($breaker['breaker_key'] ?? $breaker['key'] ?? 'unknown'),
                'source_component'=>(string)($breaker['source_component'] ?? $breaker['source_engine'] ?? 'unknown'),
                'state'=>$state,
                'reason_code'=>$breaker['reason_code'] ?? null,
                'opened_at'=>$breaker['opened_at'] ?? null,
                'retry_after'=>$breaker['retry_after'] ?? null,
                'observed_at'=>$breaker['observed_at'] ?? $sourceSnapshot['observed_at'] ?? null,
            ];
            foreach(['trace_id','correlation_id','causation_id','root_causation_id'] as $field) if(array_key_exists($field,$breaker)) $row[$field]=$breaker[$field];
            $items[]=$row;
        }
        $rank=['OPEN'=>0,'HALF_OPEN'=>1,'UNKNOWN'=>2,'DISABLED'=>3,'CLOSED'=>4];
        usort($items,static fn(array $a,array $b):int=>($rank[$a['state']] <=> $rank[$b['state']]) ?: strcmp($a['breaker_key'],$b['breaker_key']));
        return [
            'schema_version'=>'1.0',
            'source'=>(string)($sourceSnapshot['source'] ?? 'titan-signal'),
            'source_status'=>strtoupper((string)($sourceSnapshot['status'] ?? 'UNAVAILABLE')),
            'observed_at'=>$sourceSnapshot['observed_at'] ?? null,
            'open_count'=>count(array_filter($items,static fn(array $row):bool=>$row['state']==='OPEN')),
            'half_open_count'=>count(array_filter($items,static fn(array $row):bool=>$row['state']==='HALF_OPEN')),
            'items'=>$items,
        ];
    }
}
