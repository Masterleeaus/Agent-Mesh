<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalAnomalyContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalConsoleContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalCorrelationContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalLifecycleContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalManagerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalPulseContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalConsoleRequest;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Models\SignalArchiveBatch;
use App\Extensions\TitanSignalEngine\System\Models\SignalDelivery;
use App\Extensions\TitanSignalEngine\System\Models\SignalEventLifecycle;
use App\Extensions\TitanSignalEngine\System\Models\SignalLifecycleAudit;
use App\Extensions\TitanSignalEngine\System\Models\SignalSubscriptionRuntime;
use App\Extensions\TitanSignalEngine\System\Models\SignalSubscriptionVersion;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Schema;

final class SignalConsoleService implements SignalConsoleContract
{
    public function __construct(
        private readonly SignalManagerContract $manager,
        private readonly SignalPulseContract $pulse,
        private readonly SignalAnomalyContract $anomalies,
        private readonly SignalCorrelationContract $correlation,
        private readonly SignalLifecycleContract $lifecycle,
    ) {
    }

    public function surface(SignalConsoleRequest $request, SignalContext $context): array
    {
        $pulse = $this->pulse->surface($context, $request->tenantCompanyId, $request->scope, $request->window);
        $anomalies = array_slice($this->anomalies->feed($context, $request->tenantCompanyId, $request->scope, 10), 0, 5);

        return [
            'surface' => 'titan.signal.console',
            'scope' => $request->scope,
            'tenant_company_id' => $request->tenantCompanyId,
            'headline' => $pulse['headline'] ?? 'Titan Signal operational status',
            'attention' => $pulse['attention'] ?? ['score' => 0, 'band' => 'low', 'reasons' => []],
            'window' => $request->window,
            'pulse' => [
                'signal_count' => (int) ($pulse['signal_count'] ?? 0),
                'critical_count' => (int) ($pulse['critical_count'] ?? 0),
                'error_count' => (int) ($pulse['error_count'] ?? 0),
                'stalled_trace_count' => (int) ($pulse['stalled_trace_count'] ?? 0),
                'missing_receipt_count' => (int) ($pulse['missing_receipt_count'] ?? 0),
                'dead_letter_count' => (int) ($pulse['dead_letter_count'] ?? 0),
            ],
            'anomalies' => array_map(static fn (array $row): array => [
                'anomaly_id' => $row['anomaly_id'],
                'type' => $row['type'],
                'severity' => $row['severity'],
                'score' => $row['score'],
                'subject_type' => $row['subject_type'],
                'subject_id' => $row['subject_id'],
                'status' => $row['status'],
            ], $anomalies),
            'generated_at' => $pulse['generated_at'] ?? null,
        ];
    }

    public function dashboard(SignalConsoleRequest $request, SignalContext $context, bool $administrative = false): array
    {
        $snapshot = $this->pulse->snapshot($context, $request->tenantCompanyId, $request->scope, $request->window);

        return [
            'request' => $request->toArray(),
            'health' => $administrative ? $this->manager->health($context) : [
                'engine' => 'titan-signal-engine',
                'version' => '0.20.0-rc.8.1',
                'status' => in_array($snapshot->attention->band, ['critical', 'high'], true) ? 'degraded' : 'healthy',
                'pulse' => $snapshot->health,
            ],
            'pulse' => $snapshot->toArray(),
            'surface' => $this->pulse->surface($context, $request->tenantCompanyId, $request->scope, $request->window),
            'anomalies' => $this->anomalies->feed($context, $request->tenantCompanyId, $request->scope, min($request->limit, 50)),
            'subscriber_health' => $administrative ? $this->subscriberHealth($request) : [],
            'dead_letters' => $administrative ? $this->deadLetters($request, min($request->limit, 50)) : [],
            'lifecycle' => $administrative ? $this->lifecycleSummary($request) : [],
            'archives' => $administrative ? $this->recentArchives($request, 10) : [],
            'lifecycle_audit' => $administrative ? $this->recentLifecycleAudit($request, 10) : [],
        ];
    }

    public function trace(string $traceId, SignalConsoleRequest $request, SignalContext $context, ?string $profileKey = null, ?int $profileVersion = null): array
    {
        return $this->correlation->trace(
            $traceId,
            $context,
            $request->tenantCompanyId,
            $request->scope,
            $profileKey,
            $profileVersion,
            min($request->limit, 250),
        );
    }

    public function workflow(string $correlationId, SignalConsoleRequest $request, SignalContext $context): array
    {
        return $this->correlation->workflow(
            $correlationId,
            $context,
            $request->tenantCompanyId,
            $request->scope,
            min($request->limit, 250),
        );
    }

    public function event(string $eventId, SignalConsoleRequest $request, SignalContext $context): ?array
    {
        return $this->lifecycle->view($eventId, $context, $request->tenantCompanyId, $request->scope);
    }

    /** @return list<array<string,mixed>> */
    private function subscriberHealth(SignalConsoleRequest $request): array
    {
        if (! Schema::hasTable('titan_signal_subscription_runtime') || ! Schema::hasTable('titan_signal_subscription_versions')) {
            return [];
        }

        $runtimeLimit = max(1, min($request->limit, 100));
        $runtimes = [];
        $subscriberKeys = [];
        foreach (SignalSubscriptionRuntime::query()->orderBy('subscriber_key')->limit($runtimeLimit)->cursor() as $runtime) {
            $runtimes[] = $runtime;
            $subscriberKeys[] = (string) $runtime->subscriber_key;
        }

        $deliveryCounts = [];
        if ($subscriberKeys !== [] && Schema::hasTable('titan_signal_deliveries')) {
            $query = SignalDelivery::query()->where('scope', $request->scope)->whereIn('subscriber_key', $subscriberKeys);
            $request->scope === SignalEnvelope::SCOPE_TENANT
                ? $query->where('tenant_company_id', $request->tenantCompanyId)
                : $query->whereNull('tenant_company_id');
            foreach ($query->selectRaw('subscriber_key, status, COUNT(*) as aggregate')->groupBy('subscriber_key', 'status')->limit($runtimeLimit * 8)->cursor() as $row) {
                $deliveryCounts[(string) $row->subscriber_key][(string) $row->status] = (int) $row->aggregate;
            }
        }

        $result = [];
        foreach ($runtimes as $runtime) {
            /** @var SignalSubscriptionVersion|null $definition */
            $definition = SignalSubscriptionVersion::query()
                ->where('subscriber_key', $runtime->subscriber_key)
                ->where('definition_version', $runtime->active_definition_version)
                ->first();
            if ($definition === null) continue;

            $key = (string) $runtime->subscriber_key;
            $result[] = [
                'subscriber_key' => $key,
                'definition_version' => (int) $runtime->active_definition_version,
                'owner_service_id' => (string) $definition->owner_service_id,
                'status' => (string) $runtime->runtime_status,
                'lifecycle_status' => (string) $runtime->lifecycle_status,
                'quarantine_reason_code' => $runtime->quarantine_reason_code === null ? null : (string) $runtime->quarantine_reason_code,
                'queue' => (string) $definition->queue,
                'event_patterns' => (array) ($definition->event_patterns ?? []),
                'deliveries' => $deliveryCounts[$key] ?? [],
            ];
        }
        return $result;
    }

    /** @return list<array<string,mixed>> */
    private function deadLetters(SignalConsoleRequest $request, int $limit): array
    {
        if (! Schema::hasTable('titan_signal_deliveries')) return [];
        $query = SignalDelivery::query()->where('status', 'dead_letter')->where('scope', $request->scope);
        $request->scope === SignalEnvelope::SCOPE_TENANT
            ? $query->where('tenant_company_id', $request->tenantCompanyId)
            : $query->whereNull('tenant_company_id');

        return $query->orderByDesc('dead_lettered_at')->limit(max(1, min($limit, 50)))->cursor()->map(static fn (SignalDelivery $row): array => [
            'delivery_id' => (string) $row->delivery_id,
            'event_id' => (string) $row->event_id,
            'subscriber_key' => (string) $row->subscriber_key,
            'event_type' => (string) $row->event_type,
            'source' => $row->source === null ? null : (string) $row->source,
            'source_component' => $row->source_component === null ? null : (string) $row->source_component,
            'attempt_count' => (int) $row->attempt_count,
            'redrive_count' => (int) ($row->redrive_count ?? 0),
            'dead_lettered_at' => $row->dead_lettered_at?->format(DATE_ATOM),
            'error_class' => $row->last_error_class === null ? null : (string) $row->last_error_class,
            'error_reference' => $row->last_error === null ? null : (string) $row->last_error,
        ])->all();
    }

    /** @return array<string,int> */
    private function lifecycleSummary(SignalConsoleRequest $request): array
    {
        if (! Schema::hasTable('titan_signal_event_lifecycle')) {
            return ['active' => 0, 'legal_holds' => 0, 'prune_candidates' => 0, 'archived' => 0, 'pruned' => 0];
        }
        $base = fn (): Builder => $this->scopeQuery(SignalEventLifecycle::query(), $request);

        return [
            'active' => $base()->whereNull('pruned_at')->count(),
            'legal_holds' => $base()->where('legal_hold', true)->whereNull('pruned_at')->count(),
            'prune_candidates' => $base()->where('legal_hold', false)->whereNull('pruned_at')->whereNotNull('retain_until')->where('retain_until', '<=', now())->count(),
            'archived' => $base()->whereNotNull('archived_at')->count(),
            'pruned' => $base()->whereNotNull('pruned_at')->count(),
        ];
    }

    /** @return list<array<string,mixed>> */
    private function recentArchives(SignalConsoleRequest $request, int $limit): array
    {
        if (! Schema::hasTable('titan_signal_archive_batches')) return [];
        return $this->scopeQuery(SignalArchiveBatch::query(), $request)
            ->orderByDesc('created_at')->limit($limit)->cursor()->map(static fn (SignalArchiveBatch $row): array => [
                'batch_id' => (string) $row->batch_id,
                'status' => (string) $row->status,
                'event_count' => (int) $row->event_count,
                'archive_driver' => (string) $row->archive_driver,
                'archive_checksum' => $row->archive_checksum === null ? null : (string) $row->archive_checksum,
                'archived_at' => $row->archived_at?->format(DATE_ATOM),
                'verified_at' => $row->verified_at?->format(DATE_ATOM),
            ])->all();
    }

    /** @return list<array<string,mixed>> */
    private function recentLifecycleAudit(SignalConsoleRequest $request, int $limit): array
    {
        if (! Schema::hasTable('titan_signal_lifecycle_audit')) return [];
        return $this->scopeQuery(SignalLifecycleAudit::query(), $request)
            ->orderByDesc('occurred_at')->limit($limit)->cursor()->map(static fn (SignalLifecycleAudit $row): array => [
                'action_id' => (string) $row->action_id,
                'action' => (string) $row->action,
                'target_event_id' => $row->target_event_id === null ? null : (string) $row->target_event_id,
                'batch_id' => $row->batch_id === null ? null : (string) $row->batch_id,
                'actor_id' => (string) $row->actor_id,
                'reason' => (string) $row->reason,
                'occurred_at' => $row->occurred_at?->format(DATE_ATOM),
            ])->all();
    }

    private function scopeQuery(Builder $query, SignalConsoleRequest $request): Builder
    {
        $query->where('scope', $request->scope);
        return $request->scope === SignalEnvelope::SCOPE_TENANT
            ? $query->where('tenant_company_id', $request->tenantCompanyId)
            : $query->whereNull('tenant_company_id');
    }
}
