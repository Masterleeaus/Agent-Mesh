<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

final class CrmActivityResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'public_id' => $this->public_id,
            'subject_type' => $this->subject_type,
            'subject_public_id' => $this->subject_public_id,
            'type' => $this->type,
            'title' => $this->title,
            'body' => $this->body,
            'direction' => $this->direction,
            'scheduled_at' => $this->scheduled_at,
            'completed_at' => $this->completed_at,
            'actor_user_id' => $this->actor_user_id,
            'occurred_at' => $this->occurred_at,
            'created_at' => $this->created_at,
        ];
    }
}
