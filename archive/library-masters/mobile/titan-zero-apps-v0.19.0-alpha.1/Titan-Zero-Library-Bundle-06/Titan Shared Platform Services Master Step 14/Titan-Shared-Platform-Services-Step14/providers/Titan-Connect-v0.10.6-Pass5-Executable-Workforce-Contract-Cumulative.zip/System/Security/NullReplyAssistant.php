<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use App\Extensions\TitanConnect\System\Contracts\ReplyAssistant;
use RuntimeException;

final class NullReplyAssistant implements ReplyAssistant
{
    public function rewrite(int $companyId, int $actorId, string $message, string $variant): string
    {
        throw new RuntimeException('Reply assistant integration is not configured.');
    }
}
