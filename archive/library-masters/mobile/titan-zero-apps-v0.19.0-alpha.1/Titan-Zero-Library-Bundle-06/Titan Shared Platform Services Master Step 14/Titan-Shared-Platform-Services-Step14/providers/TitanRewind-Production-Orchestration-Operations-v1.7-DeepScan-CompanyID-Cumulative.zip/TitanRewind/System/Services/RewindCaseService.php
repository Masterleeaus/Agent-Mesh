<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Models\RewindCase;
use App\Extensions\TitanRewind\System\Models\RewindCaseTrace;
use App\Extensions\TitanRewind\System\Models\RewindTimelineEntry;
use App\Extensions\TitanRewind\System\Models\RewindTraceIndex;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class RewindCaseService
{
    public function openCase(array $data): RewindCase
    {
        $tenant = (int) ($data['tenant_company_id'] ?? 0);
        if ($tenant < 1) throw new InvalidArgumentException('tenant_company_id is required to open a Rewind case.');

        $traceId = $this->nullableString($data['trace_id'] ?? null);
        $caseKey = trim((string) ($data['case_key'] ?? ''));
        if ($caseKey === '') {
            $caseKey = $traceId ? 'trace:' . $traceId : sprintf('%s:%s', $data['entity_type'] ?? 'entity', $data['entity_id'] ?? 'unknown');
        }

        $case = RewindCase::query()->create([
            'case_uuid' => (string) Str::uuid(),
            'tenant_company_id' => $tenant,
            'case_key' => $caseKey,
            'title' => trim((string) ($data['title'] ?? 'Rewind investigation')) ?: 'Rewind investigation',
            'status' => $this->status($data['status'] ?? 'open'),
            'severity' => $this->severity($data['severity'] ?? 'medium'),
            'source_type' => $this->nullableString($data['source_type'] ?? 'trace'),
            'source_id' => $this->nullableString($data['source_id'] ?? null),
            'primary_trace_id' => $traceId,
            'entity_type' => $this->nullableString($data['entity_type'] ?? null),
            'entity_id' => $this->nullableString($data['entity_id'] ?? null),
            'detected_at' => $data['detected_at'] ?? now(),
            'metadata' => is_array($data['metadata'] ?? null) ? $data['metadata'] : [],
        ]);

        if ($traceId) $this->attachTrace($case, $traceId, 'primary');
        return $case->refresh();
    }

    public function findOrOpenCase(array $data): RewindCase
    {
        $tenant = (int) ($data['tenant_company_id'] ?? 0);
        if ($tenant < 1) throw new InvalidArgumentException('tenant_company_id is required to find a Rewind case.');
        $traceId = $this->nullableString($data['trace_id'] ?? null);
        $caseKey = trim((string) ($data['case_key'] ?? '')) ?: ($traceId ? 'trace:' . $traceId : sprintf('%s:%s', $data['entity_type'] ?? 'entity', $data['entity_id'] ?? 'unknown'));

        $existing = RewindCase::query()->where('tenant_company_id', $tenant)->where('case_key', $caseKey)->where('status', 'open')->first();
        if ($existing) {
            if ($traceId) $this->attachTrace($existing, $traceId, 'related');
            return $existing;
        }
        $data['case_key'] = $caseKey;
        return $this->openCase($data);
    }

    public function attachTrace(RewindCase $case, string $traceId, string $relationship = 'related'): RewindCaseTrace
    {
        $traceExists = RewindTraceIndex::query()
            ->where('tenant_company_id', $case->tenant_company_id)
            ->where('trace_id', $traceId)
            ->exists();
        if (!$traceExists) {
            throw new InvalidArgumentException('The trace does not exist inside the Rewind case tenant boundary.');
        }

        $link = RewindCaseTrace::query()->firstOrCreate(
            ['case_id' => $case->id, 'trace_id' => $traceId],
            ['tenant_company_id' => $case->tenant_company_id, 'relationship_type' => $relationship, 'added_at' => now()]
        );

        RewindTimelineEntry::query()
            ->where('tenant_company_id', $case->tenant_company_id)
            ->where('trace_id', $traceId)
            ->whereNull('case_id')
            ->update(['case_id' => $case->id]);

        return $link;
    }

    public function closeCase(RewindCase $case, array $actor = []): RewindCase
    {
        $case->forceFill([
            'status' => 'closed',
            'resolved_at' => now(),
            'resolved_by_type' => $this->nullableString($actor['type'] ?? 'user'),
            'resolved_by_id' => isset($actor['id']) && is_numeric($actor['id']) ? (int) $actor['id'] : null,
        ])->save();
        return $case->refresh();
    }

    private function status(mixed $value): string
    {
        $value = strtolower(trim((string) $value));
        return in_array($value, ['open','investigating','resolved','closed'], true) ? $value : 'open';
    }

    private function severity(mixed $value): string
    {
        $value = strtolower(trim((string) $value));
        return in_array($value, ['low','medium','high','critical'], true) ? $value : 'medium';
    }

    private function nullableString(mixed $value): ?string
    {
        if ($value === null) return null;
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}
