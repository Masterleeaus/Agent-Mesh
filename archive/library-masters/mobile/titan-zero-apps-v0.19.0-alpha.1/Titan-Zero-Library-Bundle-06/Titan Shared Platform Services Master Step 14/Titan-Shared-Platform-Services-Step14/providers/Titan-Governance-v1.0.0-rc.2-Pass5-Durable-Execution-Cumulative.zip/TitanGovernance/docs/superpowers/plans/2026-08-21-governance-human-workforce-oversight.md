# Governance Human Oversight + Workforce Operating View Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a read-only Human Oversight and Workforce Operating View to Titan Governance v0.8.0.

**Architecture:** Normalize only the `titan-ai-workforce` read-source Control Room overlay, derive deterministic human-oversight metrics, feed bounded Workforce items into the existing Needs Attention ranker, and expose the result through Governance's manager/controller/view. No foreign writes or authority calculation.

**Tech Stack:** PHP 8.3 strict types, Laravel 10.50.x, Blade, Titan Extension Manifest 2.2, Installer 1.7.8.

**Spec:** `docs/superpowers/specs/2026-08-21-governance-human-workforce-oversight-design.md`

## Global Constraints
- `tenant_company_id` is canonical inside Governance contracts; host `company_id` is resolver input only.
- Titan AI Workforce owns Workforce state; Governance is read-only.
- Titan Autonomy owns authority; Workforce maturity/hierarchy/performance cannot raise it.
- Missing peers fail visibly; no fabricated data.
- Blueprint v4.2.2 and Installer 1.7.8 release gates remain mandatory.

---

### Task 1: Workforce oversight projector
**Files:** Create `System/ControlCentre/WorkforceOversightProjector.php`; Test `tests/Contract/workforce_oversight_contract.php`.
**Interfaces:** Consumes `array $sourceSnapshots`; produces `project(array $sources,array $context=[]): array`.
- [ ] Write a failing contract covering source absence, canonical Control Room normalization and `can_raise_authority=false`.
- [ ] Run it and confirm missing-class RED.
- [ ] Implement minimal projector with bounded lists and source-preserved identifiers/statuses.
- [ ] Run test to GREEN.

### Task 2: Human oversight projector
**Files:** Create `System/ControlCentre/HumanOversightProjector.php`; Test `tests/Contract/human_oversight_contract.php`.
**Interfaces:** Consumes normalized Workforce oversight + recent Governance decisions; produces approval ageing, workload, handoff/review ageing and intervention history.
- [ ] Write failing tests for CURRENT/AGING/OVERDUE approvals, workload grouping and intervention filtering.
- [ ] Run RED.
- [ ] Implement deterministic thresholds and bounded history.
- [ ] Run GREEN.

### Task 3: Needs Attention convergence
**Files:** Modify `System/ControlCentre/GovernanceAttentionRanker.php`, `System/ControlCentre/GovernanceControlCentre.php`; Test `tests/Contract/workforce_attention_contract.php`.
**Interfaces:** Extend `rank(..., array $workforce=[], array $human=[]): array` without breaking existing callers.
- [ ] Write failing test for overdue approval, escalated handoff and queue pressure with structured drill-down.
- [ ] Run RED.
- [ ] Implement minimal optional Workforce/Human ranking.
- [ ] Run current Pass 6 and new tests GREEN.

### Task 4: Manager/controller/view wiring
**Files:** Modify provider, manager contract/service, user routes and dashboard; Create `WorkforceOversightController.php`, `resources/views/workforce.blade.php`; Test `tests/Contract/pass7_wiring_static.php`.
**Interfaces:** Add `workforceOversight(int $tenantCompanyId,array $context=[]): array`.
- [ ] Write failing static wiring test.
- [ ] Run RED.
- [ ] Register projectors, route and read-only controller/view.
- [ ] Run GREEN.

### Task 5: Release contracts and metadata
**Files:** Modify `extension.json`, `extension.manifest.json`, config, schemas, README, changelog, pass report and `bin/verify.php`; Create `tests/Contract/pass7_release_contract.php`.
**Interfaces:** Add capabilities `governance.workforce-oversight.read` and `governance.human-oversight.read`.
- [ ] Write failing release test for v0.8.0, capabilities, authority neutrality and package docs.
- [ ] Run RED.
- [ ] Update metadata/schemas/self-verifier.
- [ ] Run GREEN plus cumulative contracts.

### Task 6: Exact ZIP certification
- [ ] Regenerate package inventory, Installer integrity, SBOM and provenance.
- [ ] Run all standalone contracts, PHP lint and JSON parse.
- [ ] Run Blueprint v4.2.2 manifest/package/architecture/MySQL/migration gates.
- [ ] Build flat cumulative ZIP.
- [ ] Fresh-extract exact ZIP and repeat all gates.
- [ ] Produce SHA-256 and machine-readable certification evidence.
