<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Enums;

enum RuntimeState: string
{
    case Planned = 'planned';
    case Validating = 'validating';
    case Rejected = 'rejected';
    case Validated = 'validated';
    case Simulating = 'simulating';
    case ReadyForDelegation = 'ready_for_delegation';
    case Delegated = 'delegated';
    case Failed = 'failed';
}
