# Agent-01 Ecosystem Interoperability Pass

Version: `1.3.0-alpha.39`

This pass makes cross-extension handoffs explicit while preserving domain ownership. Titan AI Workforce coordinates responsibilities and provider selection; Titan Autonomy owns effective authority; each target extension remains the only owner of its domain mutations.

## Peers

- `titan-field`
- `titan-time-attendance`
- `titan-assets`

## Handoffs

- `crm-to-field-service-context` — outbound with `titan-field`.
- `crm-to-assets-customer-context` — outbound with `titan-assets`.
- `operations-to-crm-history` — inbound with `titan-field`.

## Safety invariants

- `company_id` is the canonical tenant boundary.
- Missing peers/providers degrade capability availability; they never create fake context or authority.
- Signals are observations, never mutation authority.
- Cross-extension writes enter the target domain through its governed command gateway and produce receipts.
- Offline operation never increases authority.
- Workforce identities survive provider removal; work is reassigned or escalated rather than silently orphaned.
