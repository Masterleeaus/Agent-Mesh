# Pass 6 — Production Hardening / v1.0.0-rc.1

## Scope completed

1. **Signal v0.20 convergence** — Council issues the `titan-model-council` emitter identity, constructs a trusted tenant Signal context, and emits causal lifecycle events with tenant/trace/correlation/causation/root-causation identifiers. Runtime event/emitter definitions are registered without modifying Signal-owned tables.
2. **Shield v0.5 convergence** — Council prefers Shield's current manager/evaluation contract and retains a compatibility fallback for older inspection engines.
3. **Assurance v2.2 boundary** — governed deliberation can submit hash-addressed evidence to Assurance. When Risk requires Assurance, missing/failed/non-GREEN Assurance escalates rather than silently permitting downstream authority.
4. **Rewind-ready receipts** — Council owns an immutable-style decision receipt containing authority/risk/Shield/Assurance/billing summaries and participant output SHA-256 hashes. It does not store hidden chain-of-thought in the receipt.
5. **Host UI compatibility** — native user/admin views extend MagicAI's `panel.layout.app`; no `<x-layouts.app>` dependency remains.
6. **Operational health/certification** — decisions, participants, billing reservations, receipts and required Signal availability are checked by the extension health/certification surfaces.
7. **Provider resilience** — bounded timeout, circuit breaker, partial-provider failure handling, synthesis fallback, and conservative adaptive quorum remain active. Cancellation of already in-flight provider calls stays disabled until provider dispatch is owned by AI Core.
8. **Financial integrity** — Council preserves reservation-before-dispatch and settlement/release after actual successful role usage. The legacy host credit driver still lacks an account-authoritative hard-hold primitive; Council does not fabricate one.

## Explicit external convergence gates

- **Titan Signal identity:** Blueprint v4.2 names canonical dependency `titan-signal`; the current Signal RC package still uses `titan-signal-engine`. Runtime is compatible with v0.20, but package identity needs ecosystem convergence before canonical production promotion.
- **Titan AI Core execution:** no executable current AI Core package contract was available to inspect in this pass, so direct provider ownership was not falsely claimed. The existing runtime boundary remains ready for a published contract.
- **Titan Rewind write API:** the latest executable Rewind package was not available to inspect; therefore Council emits/retains a hash-addressed Rewind-ready receipt instead of inventing a Rewind method.
- **Host certification/signing:** this ZIP is locally package-verified only. Production promotion requires the exact package to pass the actual MagicAI/Titan host checks and approved signing workflow.

## Authority invariant

`Council consensus != execution authority.`

Council outputs remain advisory. Risk/Governance/Command Bus retain the authority to approve, reduce, block, or execute consequential actions.
