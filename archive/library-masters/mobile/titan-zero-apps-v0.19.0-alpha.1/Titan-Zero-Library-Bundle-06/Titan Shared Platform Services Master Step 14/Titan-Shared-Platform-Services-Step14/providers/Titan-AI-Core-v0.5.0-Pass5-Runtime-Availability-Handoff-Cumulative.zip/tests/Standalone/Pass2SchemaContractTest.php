<?php
declare(strict_types=1);
$root=dirname(__DIR__,2); $files=['schemas/plan-envelope.v1.schema.json','schemas/plan-step.v1.schema.json','schemas/validation-report.v1.schema.json'];
foreach($files as $rel){ if(!is_file($root.'/'.$rel)){fwrite(STDERR,"Missing schema: $rel\n");exit(1);} $d=json_decode((string)file_get_contents($root.'/'.$rel),true); if(!is_array($d)){fwrite(STDERR,"Invalid JSON schema: $rel\n");exit(1);} }
$plan=json_decode((string)file_get_contents($root.'/schemas/plan-envelope.v1.schema.json'),true);
foreach(['plan_id','runtime_context','intent','steps','constraints','schema_version','plan_schema_version','runtime_version'] as $key){if(!in_array($key,$plan['required']??[],true)){fwrite(STDERR,"Plan schema missing required $key\n");exit(1);}}
$step=json_decode((string)file_get_contents($root.'/schemas/plan-step.v1.schema.json'),true);
foreach(['step_id','action','depends_on','required_inputs','optional_inputs','outputs','timeout_seconds','retry_policy'] as $key){if(!in_array($key,$step['required']??[],true)){fwrite(STDERR,"Step schema missing required $key\n");exit(1);}}
$report=json_decode((string)file_get_contents($root.'/schemas/validation-report.v1.schema.json'),true);
foreach(['valid','executable','errors','warnings','suggestions','validator_version'] as $key){if(!in_array($key,$report['required']??[],true)){fwrite(STDERR,"Validation schema missing required $key\n");exit(1);}}
fwrite(STDOUT,"Pass 2 schema contract test: PASS\n");
