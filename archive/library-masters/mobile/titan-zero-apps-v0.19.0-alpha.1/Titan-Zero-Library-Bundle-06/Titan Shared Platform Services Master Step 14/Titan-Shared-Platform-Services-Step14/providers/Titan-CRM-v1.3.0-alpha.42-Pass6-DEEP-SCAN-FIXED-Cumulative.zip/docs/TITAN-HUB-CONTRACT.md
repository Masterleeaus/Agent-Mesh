# Titan Hub / Customer Hub — CRM Core Contract

## Status

CRM Core provides a **commercial/customer decorator** for Titan Hub. It does not own Titan Field customer operations.

`CrmCustomerOperationsGateway` contributes CRM-owned operations including customer/profile context, quotes, invoices and commercial documents. Methods for services, service requests, work orders, bookings, support and service locations delegate to the inner Titan Hub/Titan Field implementation.

## Identity and tenancy

Every private CRM query is scoped by trusted `tenant_company_id` plus verified CRM contact/customer identity. A customer-company relationship alone does not grant access to a sibling customer's private CRM records.

Trusted Titan Hub context is required. CRM does not accept browser-selected tenant identity as authority.

## Cross-domain behavior

A Titan Field work order may be referenced when creating a CRM quote or invoice. That reference is commercial lineage only; CRM Core does not gain authority to update, assign, schedule or complete the work order.
