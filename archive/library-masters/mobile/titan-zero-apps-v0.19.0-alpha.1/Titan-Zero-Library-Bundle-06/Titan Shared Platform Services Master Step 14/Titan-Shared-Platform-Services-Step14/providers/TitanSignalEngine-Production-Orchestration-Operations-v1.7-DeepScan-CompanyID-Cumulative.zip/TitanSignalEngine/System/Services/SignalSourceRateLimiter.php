<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalSourceRateLimiterContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Exceptions\SignalRateLimitException;
use Illuminate\Cache\RateLimiter;
use Illuminate\Support\Facades\Log;

final class SignalSourceRateLimiter implements SignalSourceRateLimiterContract
{
    public function __construct(
        private readonly RateLimiter $limiter,
        private readonly SignalBackpressureMonitor $backpressure,
        private readonly SourceRateLimitPolicy $policy,
    ) {
    }

    public function assertAllowed(SignalEnvelope $signal): void
    {
        if (! (bool) config('titan-signal-engine.rate_limit_enabled', true)) {
            return;
        }
        $key = implode(':', [
            'titan-signal-source',
            $signal->scope,
            (string) ($signal->tenantCompanyId ?? 0),
            hash('sha256', $signal->source . '|' . ($signal->sourceComponent ?? '')),
            gmdate('YmdHi'),
        ]);
        $snapshot = $this->backpressure->snapshot(
            $signal->scope,
            $signal->tenantCompanyId,
            null,
            $signal->source,
            $signal->sourceComponent,
        );
        $global = $this->backpressure->snapshot();
        $emergencyMultiplier = max(2.0, (float) config('titan-signal-engine.backpressure_global_emergency_multiplier', 5.0));
        $globalEmergency = (int) ($global['total_pressure'] ?? 0) >= (int) ceil(((int) ($global['threshold'] ?? 1)) * $emergencyMultiplier);
        $backpressured = (bool) ($snapshot['backpressured'] ?? false) || $globalEmergency;
        $count = $this->limiter->attempts($key);
        $decision = $this->policy->decide($signal->scope, $count, $backpressured);
        if (! $decision->allowed) {
            $retryAfter = max(1, $this->limiter->availableIn($key));
            Log::warning('signal.source_rate_limited', [
                'scope' => $signal->scope,
                'tenant_company_id' => $signal->tenantCompanyId,
                'source' => $signal->source,
                'source_component' => $signal->sourceComponent,
                'effective_limit' => $decision->effectiveLimit,
                'observed_count' => $decision->observedCount,
                'backpressure' => $decision->backpressureApplied,
                'scoped_pressure' => (int) ($snapshot['total_pressure'] ?? 0),
                'global_emergency' => $globalEmergency,
            ]);
            throw new SignalRateLimitException('Signal source rate limit exceeded.', $retryAfter);
        }
        $this->limiter->hit($key, 60);
    }
}
