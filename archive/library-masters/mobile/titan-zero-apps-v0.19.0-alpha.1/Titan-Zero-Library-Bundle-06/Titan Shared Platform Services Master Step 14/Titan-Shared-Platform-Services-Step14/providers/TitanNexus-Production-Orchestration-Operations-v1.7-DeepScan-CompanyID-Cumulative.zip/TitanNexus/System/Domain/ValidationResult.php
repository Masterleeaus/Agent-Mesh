<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\CanonicalJson;
use InvalidArgumentException;

final class ValidationResult
{
    /** @var list<ValidationFinding> */
    private readonly array $findings;

    /** @param list<ValidationFinding> $findings */
    private function __construct(array $findings)
    {
        foreach ($findings as $finding) {
            if (!$finding instanceof ValidationFinding) {
                throw new InvalidArgumentException('findings must contain only ValidationFinding values.');
            }
        }

        usort($findings, static fn (ValidationFinding $a, ValidationFinding $b): int => strcmp($a->sortKey(), $b->sortKey()));
        $this->findings = array_values($findings);
    }

    /** @param list<ValidationFinding> $findings */
    public static function fromFindings(array $findings): self
    {
        return new self($findings);
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $raw = $data['findings'] ?? [];
        if (!is_array($raw) || !array_is_list($raw)) {
            throw new InvalidArgumentException('findings must be a list.');
        }

        $findings = [];
        foreach ($raw as $item) {
            if (!is_array($item)) {
                throw new InvalidArgumentException('Each finding must be an object-like array.');
            }
            $findings[] = ValidationFinding::fromArray($item);
        }

        $instance = new self($findings);
        $providedFingerprint = $data['fingerprint'] ?? null;
        if ($providedFingerprint !== null) {
            if (!is_string($providedFingerprint) || !hash_equals(strtolower($providedFingerprint), $instance->fingerprint())) {
                throw new InvalidArgumentException('validation fingerprint does not match findings.');
            }
        }

        return $instance;
    }

    /** @return list<ValidationFinding> */
    public function findings(): array
    {
        return $this->findings;
    }

    /** @return list<ValidationFinding> */
    public function errors(): array
    {
        return array_values(array_filter($this->findings, static fn (ValidationFinding $finding): bool => $finding->severity() === ValidationSeverity::Error));
    }

    /** @return list<ValidationFinding> */
    public function warnings(): array
    {
        return array_values(array_filter($this->findings, static fn (ValidationFinding $finding): bool => $finding->severity() === ValidationSeverity::Warning));
    }

    /** @return list<ValidationFinding> */
    public function info(): array
    {
        return array_values(array_filter($this->findings, static fn (ValidationFinding $finding): bool => $finding->severity() === ValidationSeverity::Info));
    }

    public function hasErrors(): bool
    {
        return $this->errors() !== [];
    }

    public function isValid(): bool
    {
        return !$this->hasErrors();
    }

    public function fingerprint(): string
    {
        return hash('sha256', CanonicalJson::encode(['findings' => $this->findingArrays()]));
    }

    /** @return array<string,mixed> */
    public function toContractArray(): array
    {
        $status = $this->hasErrors() ? 'blocked' : ($this->warnings() !== [] ? 'warning' : 'ready');
        return [
            'status' => $status,
            'fingerprint' => $this->fingerprint(),
            'findings' => array_map(static fn (ValidationFinding $finding): array => $finding->toContractArray(), $this->findings),
        ];
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'valid' => $this->isValid(),
            'counts' => [
                'error' => count($this->errors()),
                'warning' => count($this->warnings()),
                'info' => count($this->info()),
            ],
            'findings' => $this->findingArrays(),
            'fingerprint' => $this->fingerprint(),
        ];
    }

    /** @return list<array<string, string>> */
    private function findingArrays(): array
    {
        return array_map(static fn (ValidationFinding $finding): array => $finding->toArray(), $this->findings);
    }
}
