<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Enums;

enum KnowledgeSourceStatus: string
{
    case LegacyScaffold = 'scaffold';
    case Active = 'active';
    case Suspended = 'suspended';
    case Retired = 'retired';
}
