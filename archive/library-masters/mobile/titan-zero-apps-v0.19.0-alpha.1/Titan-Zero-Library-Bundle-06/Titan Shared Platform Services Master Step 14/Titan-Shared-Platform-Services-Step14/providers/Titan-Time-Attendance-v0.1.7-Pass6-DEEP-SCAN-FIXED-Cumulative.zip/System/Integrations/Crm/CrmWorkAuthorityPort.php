<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Integrations\Crm;

interface CrmWorkAuthorityPort
{
    public function available(): bool;
    public function assertWorkOrderAccessible(int $tenantCompanyId,int $actorUserId,string $workOrderPublicId): void;
    public function assertServiceLocationAccessible(int $tenantCompanyId,int $actorUserId,string $serviceLocationPublicId): void;
}
