<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Import;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;

/** Tenant-scoped relationship validation for staged imports. */
final class CrmImportRelationshipValidator
{
    private const MAP=['company_public_id'=>'crm_companies','contact_public_id'=>'crm_contacts','customer_public_id'=>'crm_contacts'];
    public function __construct(private readonly ConnectionInterface $db) {}

    /** @return list<string> */
    public function validate(int $userId,array $row): array
    {
        $tenant=CrmCompanyScope::companyId($userId);$errors=[];
        foreach(self::MAP as $field=>$table){
            $value=trim((string)($row[$field]??''));if($value==='')continue;
            try{$ready=$this->db->getSchemaBuilder()->hasTable($table)&&$this->db->getSchemaBuilder()->hasColumn($table,'company_id')&&$this->db->getSchemaBuilder()->hasColumn($table,'public_id');}catch(\Throwable){$ready=false;}
            if(!$ready)continue;
            if(!$this->db->table($table)->where('company_id',$tenant)->where('public_id',$value)->exists())$errors[]="{$field} reference not found.";
        }
        return $errors;
    }
}
