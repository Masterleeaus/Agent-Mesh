# Delegated Autonomy Authority Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Titan Autonomy a first-class delegated authority source for Interaction Engine without weakening human approval, tenancy, scope, policy, or audit boundaries.

**Architecture:** Interaction Engine owns the authority decision and accepts a delegation only through an optional verifier contract that fails closed by default. Titan Autonomy issues short-lived signed delegation envelopes only after runtime authority checks pass and supplies the verifier implementation, which revalidates the persisted capability state, policy version, scope, and Trusted Auto handshake before Interaction allows execution.

**Tech Stack:** PHP 8.3, Laravel 10, Titan extension contracts, HMAC-SHA256 using an APP_KEY-derived purpose key, existing Autonomy state/handshake tables, Interaction CommandBus/PolicyEngine.

## Global Constraints

- No client-supplied tenant ID establishes tenancy.
- No client-supplied delegation, scopes, approvals, or autonomy level establishes authority.
- UserOnly remains directly executable by authorised humans.
- ApprovalRequired remains executable through valid human approval; delegation is an additional governed path only where explicitly enabled.
- Auto and Trusted Auto may satisfy delegated authority; Semi-Auto may not replace final human approval.
- Fresh-authentication-only capabilities remain non-delegable by default.
- Every delegation is capability-, workflow-, tenant-, scope-, policy-version-, session-, correlation-, and expiry-bound.
- Trusted Auto delegation requires a persisted fully approved three-way handshake.
- Missing Titan Autonomy verifier fails closed.

---

### Task 1: Interaction delegated authority contract
- [ ] Add verifier/decision contract and unavailable fail-closed implementation.
- [ ] Extend CapabilityPolicy with explicit delegated-authority opt-in.
- [ ] Add failing authority tests for forged context, valid delegation, human fallback, UserOnly delegation, and fresh-auth denial.
- [ ] Update PolicyEngine to use the verifier and expose the authority satisfaction source.

### Task 2: Interaction audit and provider wiring
- [ ] Inject verifier into PolicyEngine through the service provider only if available.
- [ ] Record delegated authority satisfaction in command audit/cognitive metadata without storing raw grant secrets.
- [ ] Opt in verified operational CRM capabilities only.

### Task 3: Titan Autonomy delegation issuer/verifier
- [ ] Add short-lived signed delegation envelope service.
- [ ] Add Interaction verifier adapter that revalidates state, scope, policy version, workflow, tenant, expiry, and Trusted Auto handshake.
- [ ] Bind the Interaction verifier contract conditionally when Interaction is installed.
- [ ] Add failing then passing smoke tests.

### Task 4: Governed execution integration
- [ ] Issue delegation only after ExecutionAuthorityGuard + current Assurance + completed Interaction session pass.
- [ ] Inject delegation server-side in CommandBus bridge and strip caller delegation evidence.
- [ ] Ensure mapped Interaction payload is authoritative.

### Task 5: CRM compatibility
- [ ] Update CRM Interaction authority registration so eligible operational capabilities opt into delegated authority when Interaction 10.4 supports it.
- [ ] Keep payment/money movement and fresh-auth actions non-delegable.

### Task 6: Release verification
- [ ] Run standalone Interaction authority tests.
- [ ] Run Autonomy smoke/unit tests.
- [ ] Run cross-extension integration test.
- [ ] PHP lint all changed packages.
- [ ] Regenerate integrity manifests and package installer-ready ZIPs.
