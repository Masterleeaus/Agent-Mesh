# Titan Rewind v1.0.6 — Blueprint v4.1 Production Profile / MagicAI Host UI Hotfix

Titan Rewind is the governed forensic reconstruction, replay, evidence and recovery-proposal extension for Titan Zero. It remains read-model/forensic only and never directly mutates authoritative business state.

## v1.0.6 host compatibility

This release preserves the successful Installer 1.7.8 package/migration fixes, v1.0.4 menu self-heal and v1.0.5 host authorization bridge. It then fixes the live MagicAI Blade error caused by unavailable `<x-layouts.app>` and expands the sidebar into a complete Rewind hierarchy.

User navigation:

1. Overview
2. Traces
3. Cases
4. Replay Runs
5. Evidence Vault
6. Recovery Plans
7. Forensic Assistant

Contextual trace/replay/evidence/recovery detail pages are linked from those catalogues because they require an ID.

All Rewind views now use the verified MagicAI `panel.layout.app` layout. See `docs/HOST-VIEW-NAVIGATION-v1.0.6.md` and `docs/PRODUCTION-CERTIFICATION-v1.0.6.md`.

## Runtime boundaries

- canonical tenant key: `tenant_company_id`;
- replay mutation policy: deny;
- authoritative recovery execution: external Governance + Command Bus/domain writer only;
- evidence signing keys: externally supplied; private release/evidence keys are not persisted by Rewind;
- schema-v2 Blueprint profile: `titan-rewind`.
