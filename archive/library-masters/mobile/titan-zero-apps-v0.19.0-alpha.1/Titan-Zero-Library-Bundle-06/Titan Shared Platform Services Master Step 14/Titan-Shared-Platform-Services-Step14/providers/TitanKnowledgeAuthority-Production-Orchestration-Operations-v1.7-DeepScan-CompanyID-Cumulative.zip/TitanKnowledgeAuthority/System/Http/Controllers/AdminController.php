<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Http\Controllers;

use Illuminate\Contracts\View\View;

final class AdminController
{
    public function __invoke(): View
    {
        return view('titan-knowledge-authority::admin');
    }
}
