<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
$refreshPath=$root.'/System/Commands/RefreshGovernanceProjectionsCommand.php';
if(!is_file($refreshPath)){fwrite(STDERR,"FAIL: missing projection refresh command\n");exit(1);}
$refresh=(string)file_get_contents($refreshPath);
$provider=(string)file_get_contents($root.'/System/TitanGovernanceServiceProvider.php');
$managerContract=(string)file_get_contents($root.'/System/Contracts/GovernanceManagerContract.php');
$manager=(string)file_get_contents($root.'/System/Services/GovernanceManager.php');
$controller=(string)file_get_contents($root.'/System/Http/Controllers/IndexController.php');
$routes=(string)file_get_contents($root.'/routes/user.php');
$view=(string)file_get_contents($root.'/resources/views/index.blade.php');
$manifest=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
$errors=[];
if(!str_contains($refresh,'titan:titan-governance:refresh-projections'))$errors[]='projection refresh command signature missing';
foreach(['GovernanceSignalIntelligence','RefreshGovernanceProjectionsCommand','GovernanceProjectionService','GovernanceProjectionSinkContract'] as $needle) if(!str_contains($provider,$needle))$errors[]='provider missing '.$needle;
foreach(['dashboardSnapshot','signalHeatmap','operationalPressure','circuitBreakers','projectionHistory'] as $needle) if(!str_contains($managerContract,$needle))$errors[]='manager contract missing '.$needle;
if(!str_contains($manager,'GovernanceProjectionService'))$errors[]='manager not wired to projection service';
if(!str_contains($controller,'dashboardSnapshot'))$errors[]='index controller does not use coherent dashboard snapshot';
foreach(['signal-heatmap','operational-pressure','circuit-breakers','projection-history'] as $needle) if(!str_contains($routes,$needle))$errors[]='user route missing '.$needle;
foreach(['Signal Heatmap','Operational pressure','Circuit breakers','Source health history'] as $needle) if(!str_contains($view,$needle))$errors[]='UI missing '.$needle;
foreach(['governance.signal-heatmap.read','governance.operational-pressure.read','governance.circuit-breaker.read','governance.projection-history.read'] as $cap) if(!in_array($cap,$manifest['capabilities']??[],true))$errors[]='manifest missing '.$cap;
if($errors){fwrite(STDERR,"FAIL: ".implode(', ',$errors)."\n");exit(1);}echo "PASS: Governance Pass 3 wiring\n";
