# Governance Read Plane

Governance reads external Titan state only through `GovernanceReadSourceContract`; adapters must be tenant-scoped and read-only.

## Titan Autonomy

Governance projects desired, earned and effective 0–100 authority and structured evidence. Invalid source ordering/ranges are flagged, never repaired. Titan Autonomy remains authoritative.

## Titan Signal

The Signal adapter may expose:

- `signals[]`: `event_type`, `source_component`, `category`, `severity`, status/time and causal/evidence references.
- `operational_pressure[]`: `source_component`, queue depth, oldest-item age, failure-rate percentage, blocked count, saturation percentage and optional observation time.
- `circuit_breakers[]`: breaker key, component, state, reason, opened/retry timestamps and causal IDs.

Arbitrary payload fields do not cross the Governance projector boundary.

## Operational pressure

Governance computes a transparent management-pressure score from queue depth, oldest-item age, failure rate, blocked work and saturation. Bands are NORMAL, ELEVATED, HIGH and CRITICAL. This is an operational bottleneck indicator and must not be interpreted as Titan Risk.

## Durable projections

Normalized snapshots are stored only in `titan_governance_views`, which remains a Governance-owned cache/history table. Identical snapshots are deduplicated by `projection_fingerprint`. Projection storage failure cannot change or grant authority and does not make an external source healthy.

Current operational health and retained history are separate. The dashboard's recent incident rate is computed from persisted source-health observations and does not alter current source status.

## Human Oversight / Workforce read projection

Pass 7 adds `WorkforceOversightProjector` and `HumanOversightProjector` on top of the optional `titan-ai-workforce` read source. Approval/handoff ageing and operator workload are deterministic derived views. Missing or invalid Workforce evidence stays visibly unavailable; Governance never fabricates worker/task state and never mutates Workforce from this read surface.
