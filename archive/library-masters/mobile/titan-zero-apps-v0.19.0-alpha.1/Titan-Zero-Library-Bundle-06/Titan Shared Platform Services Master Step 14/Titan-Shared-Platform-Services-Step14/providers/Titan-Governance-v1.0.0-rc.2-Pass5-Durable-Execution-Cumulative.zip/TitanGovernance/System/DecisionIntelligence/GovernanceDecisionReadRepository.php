<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\DecisionIntelligence;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceDecisionReadStoreContract;
use App\Extensions\TitanGovernance\System\Models\GovernancePolicyDecision;

final class GovernanceDecisionReadRepository implements GovernanceDecisionReadStoreContract
{
    public function find(int $tenantCompanyId,string $decisionId):?array
    {
        $row=GovernancePolicyDecision::query()->where('tenant_company_id',$tenantCompanyId)->where('decision_id',$decisionId)->first();
        return $row instanceof GovernancePolicyDecision ? $this->normalize($row) : null;
    }

    public function recent(int $tenantCompanyId,int $limit=50):array
    {
        $limit=max(1,min(100,$limit));
        return GovernancePolicyDecision::query()->where('tenant_company_id',$tenantCompanyId)->orderByDesc('decided_at')->orderByDesc('id')->limit($limit)->get()->map(fn(GovernancePolicyDecision $row):array=>$this->normalize($row))->all();
    }

    /** @return array<string,mixed> */
    private function normalize(GovernancePolicyDecision $row):array
    {
        return [
            'decision_id'=>(string)$row->decision_id,'tenant_company_id'=>(int)$row->tenant_company_id,
            'policy_key'=>(string)($row->policy_key??''),'policy_version'=>(string)($row->policy_version??''),
            'disposition'=>(string)($row->disposition??''),'action'=>(string)($row->action??$row->disposition??''),
            'reason_codes'=>is_array($row->reason_codes)?array_values($row->reason_codes):[],
            'evidence_refs'=>is_array($row->evidence_refs)?array_values($row->evidence_refs):[],
            'actor_id'=>$row->actor_id===null?null:(string)$row->actor_id,
            'trace_id'=>$row->trace_id===null?null:(string)$row->trace_id,'correlation_id'=>$row->correlation_id===null?null:(string)$row->correlation_id,
            'causation_id'=>$row->causation_id===null?null:(string)$row->causation_id,'root_causation_id'=>$row->root_causation_id===null?null:(string)$row->root_causation_id,
            'subject_type'=>$row->subject_type===null?null:(string)$row->subject_type,'subject_id'=>$row->subject_id===null?null:(string)$row->subject_id,
            'operation_id'=>$row->operation_id===null?null:(string)$row->operation_id,'command_status'=>$row->command_status===null?null:(string)$row->command_status,
            'command_receipt_ref'=>$row->command_receipt_ref===null?null:(string)$row->command_receipt_ref,
            'authoritative_receipt_ref'=>$row->authoritative_receipt_ref===null?null:(string)$row->authoritative_receipt_ref,
            'write_verified'=>(bool)($row->write_verified??false),
            'decided_at'=>$row->decided_at?->format(DATE_ATOM),
            'result_payload'=>is_array($row->result_payload)?$row->result_payload:[],
        ];
    }
}
