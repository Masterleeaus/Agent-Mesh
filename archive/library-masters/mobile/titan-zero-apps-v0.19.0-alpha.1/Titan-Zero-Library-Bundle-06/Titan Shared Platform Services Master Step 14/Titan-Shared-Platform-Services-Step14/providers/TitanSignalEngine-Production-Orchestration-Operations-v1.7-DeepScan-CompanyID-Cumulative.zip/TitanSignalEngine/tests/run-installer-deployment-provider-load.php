<?php

declare(strict_types=1);

namespace App\Domains\Marketplace\Contracts {
    interface ExtensionRegisterKeyProviderInterface
    {
        public function registerKey(): string;
    }

    interface UninstallExtensionServiceProviderInterface
    {
        public static function uninstall(): void;
    }
}

namespace Illuminate\Support {
    class ServiceProvider {}
}

namespace {
    $provider = __DIR__ . '/../System/TitanSignalEngineServiceProvider.php';
    require_once $provider;

    $class = \App\Extensions\TitanSignalEngine\System\TitanSignalEngineServiceProvider::class;
    if (!class_exists($class, false)) {
        fwrite(STDERR, "FAIL: provider class did not load.\n");
        exit(1);
    }

    $implements = class_implements($class) ?: [];
    $required = [
        \App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface::class,
        \App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface::class,
    ];

    foreach ($required as $interface) {
        if (!in_array($interface, $implements, true)) {
            fwrite(STDERR, "FAIL: provider does not implement {$interface}.\n");
            exit(1);
        }
    }

    echo "PASS: Installer 1.7.8 deployment-stage provider load uses Marketplace contracts.\n";
}
