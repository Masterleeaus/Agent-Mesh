<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

enum RecompilePlanStatus: string
{
    case Ready = 'ready';
    case RequiresApproval = 'requires_approval';
    case Blocked = 'blocked';
}
