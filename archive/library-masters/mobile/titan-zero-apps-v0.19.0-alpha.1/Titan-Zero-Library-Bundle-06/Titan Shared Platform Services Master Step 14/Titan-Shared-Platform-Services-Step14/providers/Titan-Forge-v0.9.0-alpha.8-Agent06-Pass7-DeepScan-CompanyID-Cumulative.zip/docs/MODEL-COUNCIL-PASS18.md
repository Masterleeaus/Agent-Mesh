# Titan Forge Pass 18 — Selective Governed Model Council Review

## Purpose

Pass 18 upgrades Forge from Council activation assessment to actual governed deliberation using Titan Model Council v0.7.0 for high/critical-risk generated release candidates.

## Trigger

Council is not invoked for low/medium-risk candidates. Forge invokes governed deliberation only when Titan Risk returns `high` or `critical` after local Forge validation and Shield processing.

## Disclosure boundary

Forge sends a bounded `titan.forge.council-review-packet.v1` containing only:

- target type;
- BuildSpec fingerprint;
- ArtifactSet digest and artifact count;
- at most 50 artifact paths plus SHA-256/type/size;
- validation fingerprint/pass state/error and warning counts;
- Risk level/provider/directive and at most 10 bounded Risk reasons;
- `deployment_authority: none`.

Forge does **not** send build instructions, request inputs, artifact bytes/content, credentials, arbitrary artifact metadata or unrestricted reasoning.

## Model assignment authority

Forge does not dynamically route models. The host may configure the four required Council roles through `TITAN_FORGE_COUNCIL_PROPOSER_MODEL`, `...CRITIC_MODEL`, `...VERIFIER_MODEL`, and `...ARBITER_MODEL`. All four or none must be configured, and at least three distinct models are required. Model Council performs its own entitlement/preflight checks before provider execution.

## Receipt boundary

Forge persists only sanitized Council evidence:

- Council decision ID;
- strategy/status;
- escalation state;
- confidence percentage;
- actual participant count;
- `execution_authority`;
- SHA-256 of the Council final answer;
- SHA-256 of trusted role-model assignments;
- postflight Risk level.

Participant `response_text`, raw final answers and Council billing internals are not copied into Forge. The complete deliberation remains owned by Titan Model Council and can be reconstructed later through the Council decision ID plus causal lineage.

## Release semantics

A `deliberated` Council review satisfies only the Council portion of the release gate. `escalated`, `rejected`, `failed`, `configuration_required`, unavailable governed deliberation, or any result claiming authority other than `advisory_only` keeps the candidate blocked. Titan Governance still approves policy/release decisions and Titan Command Bus still owns consequential execution.
