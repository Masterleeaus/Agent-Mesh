<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Support\SecretFieldGuard;
use App\Extensions\TitanNexus\System\Support\StrictBoolean;
use InvalidArgumentException;

final class ProvisioningReceipt
{
    /** @param array<string,mixed> $metadata */
    public function __construct(
        private readonly string $operationId,
        private readonly string $idempotencyKey,
        private readonly ProvisioningReceiptStatus $status,
        private readonly ?string $backupReference = null,
        private readonly bool $backupVerified = false,
        private readonly bool $writeVerified = false,
        private readonly ?string $auditReference = null,
        private readonly ?string $rollbackReference = null,
        private readonly ?string $durableIdempotencyReference = null,
        private readonly array $metadata = [],
        private readonly ?string $message = null,
    ) {
        self::assertHash($this->operationId, 'operation_id');
        self::assertHash($this->idempotencyKey, 'idempotency_key');
        if ($this->status === ProvisioningReceiptStatus::Applied) {
            if (!$this->backupVerified || !$this->writeVerified
                || self::blank($this->backupReference) || self::blank($this->auditReference) || self::blank($this->rollbackReference)) {
                throw new InvalidArgumentException('Applied provisioning receipt requires verified backup/write plus backup, audit, and rollback references.');
            }
        }
        if ($this->status === ProvisioningReceiptStatus::AlreadyApplied && self::blank($this->durableIdempotencyReference)) {
            throw new InvalidArgumentException('Already-applied provisioning receipt requires durable_idempotency_reference.');
        }
        foreach ([
            'backup_reference' => $this->backupReference,
            'audit_reference' => $this->auditReference,
            'rollback_reference' => $this->rollbackReference,
            'durable_idempotency_reference' => $this->durableIdempotencyReference,
            'message' => $this->message,
        ] as $field => $value) {
            if ($value !== null && (trim($value) === '' || strlen($value) > 1000)) {
                throw new InvalidArgumentException("{$field} must be null or between 1 and 1000 characters.");
            }
        }
        self::assertMetadata($this->metadata);
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $status = ProvisioningReceiptStatus::tryFrom(self::requiredString($data['status'] ?? null, 'status'));
        if ($status === null) {
            throw new InvalidArgumentException('Provisioning receipt status is invalid.');
        }
        $metadata = $data['metadata'] ?? [];
        if (!is_array($metadata)) {
            throw new InvalidArgumentException('Provisioning receipt metadata must be an object-like array.');
        }
        return new self(
            self::requiredString($data['operation_id'] ?? null, 'operation_id'),
            self::requiredString($data['idempotency_key'] ?? null, 'idempotency_key'),
            $status,
            self::nullableString($data['backup_reference'] ?? null),
            StrictBoolean::parse($data['backup_verified'] ?? false, 'backup_verified'),
            StrictBoolean::parse($data['write_verified'] ?? false, 'write_verified'),
            self::nullableString($data['audit_reference'] ?? null),
            self::nullableString($data['rollback_reference'] ?? null),
            self::nullableString($data['durable_idempotency_reference'] ?? null),
            $metadata,
            self::nullableString($data['message'] ?? null),
        );
    }

    public static function failed(ProvisioningOperation $operation, string $message): self
    {
        return new self($operation->operationId(), $operation->idempotencyKey(), ProvisioningReceiptStatus::Failed, message: $message);
    }

    public static function skippedDependency(ProvisioningOperation $operation, string $message): self
    {
        return new self($operation->operationId(), $operation->idempotencyKey(), ProvisioningReceiptStatus::SkippedDependency, message: $message);
    }

    public function operationId(): string { return strtolower($this->operationId); }
    public function idempotencyKey(): string { return strtolower($this->idempotencyKey); }
    public function status(): ProvisioningReceiptStatus { return $this->status; }
    public function successful(): bool { return $this->status->successful(); }
    /** @return array<string,mixed> */ public function metadata(): array { return $this->metadata; }
    public function durableIdempotencyReference(): ?string { return $this->durableIdempotencyReference; }

    /** @param array<string,mixed> $metadata */
    public function withMetadata(array $metadata): self
    {
        self::assertMetadata($metadata);
        return new self(
            $this->operationId,
            $this->idempotencyKey,
            $this->status,
            $this->backupReference,
            $this->backupVerified,
            $this->writeVerified,
            $this->auditReference,
            $this->rollbackReference,
            $this->durableIdempotencyReference,
            $metadata,
            $this->message,
        );
    }

    /** @return array<string,mixed> */
    public function toContractArray(ProvisioningOperation $operation, TraceContext $traceContext): array
    {
        if (!hash_equals($operation->operationId(), $this->operationId()) || !hash_equals($operation->idempotencyKey(), $this->idempotencyKey())) {
            throw new InvalidArgumentException('Receipt does not belong to the supplied provisioning operation.');
        }
        if ($operation->tenantCompanyId() !== $traceContext->tenantCompanyId()) {
            throw new InvalidArgumentException('Operation and trace context tenant mismatch.');
        }
        $status = match ($this->status) {
            ProvisioningReceiptStatus::SkippedDependency => 'skipped',
            default => $this->status->value,
        };
        $data = [
            'operation_id' => $this->operationId(),
            'idempotency_key' => $this->idempotencyKey(),
            'tenant_company_id' => $operation->tenantCompanyId(),
            'capability' => $operation->capability(),
            'status' => $status,
            'trace_id' => $traceContext->traceId(),
            'correlation_id' => $traceContext->correlationId(),
            'causation_id' => $traceContext->causationId(),
            'backup_reference' => $this->backupReference,
            'backup_verified' => $this->backupVerified,
            'write_verified' => $this->writeVerified,
            'audit_reference' => $this->auditReference,
            'rollback_reference' => $this->rollbackReference,
            'durable_idempotency_reference' => $this->durableIdempotencyReference,
            'error_code' => $this->successful() ? null : ($this->status === ProvisioningReceiptStatus::SkippedDependency ? 'dependency_failed' : 'provisioning_failed'),
            'metadata' => $this->metadata,
        ];
        return $data;
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        $data = [
            'operation_id' => $this->operationId(),
            'idempotency_key' => $this->idempotencyKey(),
            'status' => $this->status->value,
            'backup_reference' => $this->backupReference,
            'backup_verified' => $this->backupVerified,
            'write_verified' => $this->writeVerified,
            'audit_reference' => $this->auditReference,
            'rollback_reference' => $this->rollbackReference,
            'message' => $this->message,
        ];
        if ($this->durableIdempotencyReference !== null) {
            $data['durable_idempotency_reference'] = $this->durableIdempotencyReference;
        }
        if ($this->metadata !== []) {
            $data['metadata'] = $this->metadata;
        }
        return $data;
    }

    private static function assertMetadata(array $metadata): void
    {
        foreach ($metadata as $key => $value) {
            if (!is_string($key) || trim($key) === '') {
                throw new InvalidArgumentException('Provisioning receipt metadata keys must be non-empty strings.');
            }
            if (SecretFieldGuard::isSecretLike($key)) {
                throw new InvalidArgumentException('Provisioning receipt metadata cannot contain secret-like fields.');
            }
            if (is_resource($value)) {
                throw new InvalidArgumentException('Provisioning receipt metadata cannot contain resources.');
            }
            if (is_array($value)) {
                self::assertMetadata($value);
            }
        }
    }
    private static function blank(?string $value): bool { return $value === null || trim($value) === ''; }
    private static function assertHash(string $value, string $field): void
    {
        if (preg_match('/^[0-9a-f]{64}$/i', $value) !== 1) {
            throw new InvalidArgumentException("{$field} must be a SHA-256 hex digest.");
        }
    }
    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') {
            throw new InvalidArgumentException("{$field} is required.");
        }
        return trim($value);
    }
    private static function nullableString(mixed $value): ?string
    {
        if ($value === null) { return null; }
        if (!is_string($value)) { throw new InvalidArgumentException('Receipt text fields must be strings or null.'); }
        return trim($value);
    }
}
