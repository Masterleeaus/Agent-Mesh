<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Governance\CrmDomainSignalPublisher;
use App\Extensions\Crm\System\Integrations\TitanConnect\CrmCommunicationExecutionPort;
use Throwable;

/** Post-commit worker for durable CRM communication intents. */
final class CrmNotificationDeliveryService
{
    public function __construct(
        private readonly CrmNotificationOutboxService $outbox,
        private readonly CrmCommunicationExecutionPort $communications,
        private readonly CrmDomainSignalPublisher $signals,
    ) {}

    /** @return array<string,int> */
    public function deliverPending(int $userId,int $limit=25):array
    {
        $rows=$this->outbox->claimDue($userId,$limit);
        $result=['processed'=>0,'delivered'=>0,'failed'=>0,'deferred'=>0,'skipped'=>0];
        foreach($rows as $row){
            $result['processed']++;
            $publicId=(string)($row['public_id']??'');
            if($publicId===''){$result['skipped']++;continue;}
            try{
                if((string)($row['channel']??'')==='in_app'){
                    $provider=['status'=>'delivered','provider'=>'crm_in_app','provider_status'=>'delivered','retryable'=>false];
                    $updated=$this->outbox->markDelivered($userId,$publicId,$provider);
                    $this->safeSignal($updated,'delivered',$provider);
                    $result['delivered']++;
                    continue;
                }
                $provider=$this->communications->deliver($row);
                $status=strtolower((string)($provider['status']??$provider['provider_status']??'failed'));
                if(in_array($status,['sent','delivered','success','ok'],true)){
                    $updated=$this->outbox->markDelivered($userId,$publicId,$provider);
                    $this->safeSignal($updated,'delivered',$provider);
                    $result['delivered']++;
                    continue;
                }
                if(in_array($status,['deferred','queued','pending','unavailable'],true)){
                    $updated=$this->outbox->markDeferred($userId,$publicId,$provider);
                    $this->safeSignal($updated,'deferred',$provider);
                    $result['deferred']++;
                    continue;
                }
                $reason=(string)($provider['reason']??$provider['error']??'Communication provider returned a failed outcome.');
                $updated=$this->outbox->markFailed($userId,$publicId,$reason,$provider);
                $this->safeSignal($updated,'failed',$provider);
                $result['failed']++;
            }catch(Throwable $e){
                $updated=$this->outbox->markFailed($userId,$publicId,$e->getMessage(),['provider_status'=>'exception']);
                $this->safeSignal($updated,'failed',['provider_status'=>'exception','error_class'=>$e::class]);
                $result['failed']++;
            }
        }
        return $result;
    }
    /** Delivery truth must not be reversed because Signal persistence has a separate failure. */
    private function safeSignal(array $intent,string $state,array $provider):void
    {
        try{$this->signals->recordExternalEffectLifecycle($intent,$state,$provider);}catch(Throwable){}
    }

}
