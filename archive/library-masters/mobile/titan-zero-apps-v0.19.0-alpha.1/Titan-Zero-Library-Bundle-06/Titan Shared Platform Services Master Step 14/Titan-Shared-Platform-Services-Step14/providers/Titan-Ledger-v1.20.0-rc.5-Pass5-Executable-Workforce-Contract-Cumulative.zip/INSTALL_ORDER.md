# Titan Ledger Installation / Upgrade Order — v1.18.0-rc.3

1. Ensure the compatible CRM host extension is installed (`crm >= 1.3.0-alpha.24`).
2. Ensure Titan Command Bus is installed and exposes the governed Ledger domain-adapter discovery path required by Pass 5+.
3. Upgrade/install Titan Ledger and run its migrations, including the retained command-receipt and durable Signal-outbox tables/triggers.
4. Run `php artisan titan-ledger:host-sync --force` to repair navigation when the host uses MagicAI menu persistence.
5. If Titan Signal is installed, bind its canonical publisher adapter to `titan.signal.publisher.v1` and verify it accepts the Ledger Financial Event v1 envelope.
6. Run `php artisan titan-ledger:signal-drain --limit=100` to deliver any queued financial events after the Signal bridge is available.

Titan Signal remains optional for accounting availability: missing transport leaves durable events pending. Titan Command Bus remains required for steady-state Ledger mutations.

## Pass 7 runtime dependencies

Install/enable Titan Command Bus before financial mutation. Titan Risk and Titan Assurance must be bound to their Ledger-facing gateway contracts before mutations can execute; otherwise Ledger fails closed. Titan Rewind is optional for Ledger execution and may discover/use `titan-ledger.rewind-source` when installed.

## Pass 8 CRM handoff
CRM invoice accounting integrations should resolve `titan.ledger.crm-invoice-accounting.v1` and submit invoice/credit-note facts through that port. Do not write `titan_ledger_crm_invoice_postings` or journal tables directly.

## Pass 9 integration

Titan Pay / legacy ZeroPay may be installed before or after Ledger. No hard provider/runtime dependency is required for Ledger boot. When present, payment producers should resolve `titan.ledger.payment-settlement.v1` (or the legacy alias) and submit settlement facts; the port fails closed through the existing Command Bus/Risk/Assurance path if authority dependencies are unavailable.

## Pass 10 runtime order

After Pass 9 migrations, run `2026_08_20_000010_create_titan_ledger_receivables.php`. It adds optional invoice number/due-date projection fields to Ledger-owned CRM posting evidence, then creates the Ledger receivables projection and immutable collection-event table. CRM invoice/credit and Titan Pay payment/refund posting will refresh the projection inside their existing governed transactions.

## Pass 11 integration
External spend producers may bind only after Titan Ledger, Titan Command Bus, Risk and Assurance are available. Use `titan.ledger.spend-accounting.v1`; no direct Ledger table writes are supported. The spend producer is not a hard install dependency because Ledger remains useful without procurement/Budgeting installed.

## Pass 12 integration
After Pass 11 migrations, run `2026_08_20_000012_create_titan_ledger_bank_reconciliation.php`. Bank-feed/open-banking integrations may then resolve `titan.ledger.bank-reconciliation.v1` and submit complete statement facts. The producer is optional for Ledger boot. Do not write reconciliation tables directly, and do not treat statement import as a payment or journal creation path.


## Pass 13 integration

After migrations, verify `titan_ledger_gst_tax_snapshots` exists and the `titan.ledger.gst-tax-ledger.v1` read port resolves. GST snapshot mutation must enter via Titan Command Bus. Do not bind ATO/SBR submission credentials to Titan Ledger; lodgement remains an external authority. Existing finalized snapshots must be retained during extension upgrades/uninstall policy handling.


## Pass 14 integration

After migrations, verify `titan_ledger_financial_report_snapshots` exists and the read-only `titan.ledger.financial-reporting.v1` binding resolves. Report reads require no external finance connector: they derive from posted Ledger journals and the canonical Chart of Accounts. Prepare/finalize/supersede snapshot operations must still enter through Titan Command Bus. Do not treat a report marked `complete=false` as consolidated evidence; foreign-currency journals require an explicit FX normalization layer before finalization.


## Pass 15 dependency note

Cashflow/forecasting requires the Pass 10 receivables and Pass 11 payables projections plus canonical posted journals. The `titan.ledger.cashflow-forecasting.v1` port is read-only. Forecast snapshot commands still require Titan Command Bus, Risk and Assurance through the established Ledger governed-mutation path. No forecasting dependency is permitted to gain accounting write authority.

## Production certification gate — v1.16.0-rc.1
After migrations on the real Laravel/MySQL host, run:

`php artisan titan-ledger:production-certify --repair --json=storage/app/titan-ledger-production-certification.json`

Deployment is host-certified only when the generated report returns `status=PASS` and `host_certified=true`. Titan Command Bus, Titan Risk and Titan Assurance are required live mutation gates. Titan Signal transport may be unavailable without blocking financial commit because the durable Signal outbox remains authoritative for delivery retry. Rollback/uninstall must retain Ledger financial and forensic evidence.


## Step 2 fiscal-close upgrade order — v1.17.0-rc.2

After the Step 1 production hardening migration, run `2026_08_21_000017_create_titan_ledger_financial_year_closes.php`. It creates/adopts retained fiscal-close evidence, installs four new immutability triggers and refreshes the accounting-period post guard so `year_end_close` / `year_end_reopen` journals are valid in soft-locked periods only when the existing prior-period override evidence is present. Migration `down()` is intentionally non-destructive.

After all migrations complete on the real host, rerun `php artisan titan-ledger:production-certify --repair --json=storage/app/titan-ledger-production-certification.json`; the production trigger requirement is now **45**.

## Step 3 Installer 1.7.6 compatibility

The root manifest now uses dependency entries of the form `{ "slug": "...", "version": "..." }`, which satisfies Installer 1.7.6 validation. Required slugs remain `crm` and `titan-command-bus`. After installing/upgrading, run `php artisan titan-ledger:production-certify --repair --json=storage/app/titan-ledger-production-certification.json`; Step 3 increases required MySQL trigger coverage to 51.


## Step 4 multi-account banking upgrade order — v1.19.0-rc.4

Installer 1.7.6 must first accept the root manifest dependency objects (`slug` + `version`). Run migration `2026_08_21_000019_create_titan_ledger_multi_account_banking.php` after Step 3 migrations. It creates/adopts the retained financial-account registry and banking-movement evidence tables, adds `funds_account_public_id` to payment settlements, and installs four immutable evidence triggers. Migration `down()` is deliberately non-destructive.

After all migrations complete on the real host, run `php artisan titan-ledger:production-certify --repair --json=storage/app/titan-ledger-production-certification.json`. Step 4 requires **55** production MySQL triggers and the `titan_ledger_payment_settlements.funds_account_public_id` column. The host gate remains failed/not-certified until that live report passes.


## Step 5 advanced reconciliation upgrade order — v1.20.0-rc.5

Run `2026_08_21_000020_create_titan_ledger_advanced_reconciliation.php` after the Step 4 multi-account migration. The migration adds statement fingerprints and bounded classification hints, creates retained reconciliation group/event/member evidence plus the derived active-member index, rejects duplicate historical statement evidence fail-closed, and installs eight new immutable-evidence triggers. Migration `down()` is deliberately non-destructive.

After migrations complete on the real MySQL host, run `php artisan titan-ledger:production-certify --repair --json=storage/app/titan-ledger-production-certification.json`. Step 5 requires **63** production triggers and both `statement_fingerprint` and `classification_hint` schema columns.
