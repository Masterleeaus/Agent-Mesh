<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_knowledge_sources') || Schema::hasColumn('titan_knowledge_sources', 'causation_id')) {
            return;
        }

        Schema::table('titan_knowledge_sources', function (Blueprint $table): void {
            $table->uuid('causation_id')->nullable()->after('correlation_id')->index();
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('titan_knowledge_sources') || ! Schema::hasColumn('titan_knowledge_sources', 'causation_id')) {
            return;
        }

        Schema::table('titan_knowledge_sources', function (Blueprint $table): void {
            $table->dropIndex(['causation_id']);
            $table->dropColumn('causation_id');
        });
    }
};
