<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class ChannelConnectionMember extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    protected $table = 'ext_titan_connect_channel_members';

    protected $fillable = ['channel_connection_id', 'company_id', 'user_id', 'role', 'joined_at', 'left_at'];
    protected $casts = ['joined_at' => 'datetime', 'left_at' => 'datetime'];

    public function connection(): BelongsTo
    {
        return $this->belongsTo(ChannelConnection::class, 'channel_connection_id');
    }
}
