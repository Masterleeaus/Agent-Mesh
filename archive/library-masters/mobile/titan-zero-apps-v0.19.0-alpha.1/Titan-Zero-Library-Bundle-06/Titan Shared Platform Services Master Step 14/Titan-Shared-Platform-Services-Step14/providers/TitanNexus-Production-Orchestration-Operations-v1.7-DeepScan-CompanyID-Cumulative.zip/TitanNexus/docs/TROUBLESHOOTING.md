# Troubleshooting

If provisioning fails before Command Bus, verify Risk/Governance/Assurance/Signal/Rewind public contract bindings and configured method names. For autonomous callers also verify Autonomy binding and grant evidence. For already-applied responses verify a durable idempotency reference is returned.


## Readiness failures

Inspect Admin Diagnostics → Runtime health. `not_configured` means no public contract is configured, `not_bound` means the configured contract is absent from the Laravel container, `resolution_failed` means container resolution threw, and `method_not_callable` means the bound service does not expose the configured Nexus method. Knowledge Authority and Interface Runtime are conditional/optional and may be unavailable without degrading human provisioning health.
