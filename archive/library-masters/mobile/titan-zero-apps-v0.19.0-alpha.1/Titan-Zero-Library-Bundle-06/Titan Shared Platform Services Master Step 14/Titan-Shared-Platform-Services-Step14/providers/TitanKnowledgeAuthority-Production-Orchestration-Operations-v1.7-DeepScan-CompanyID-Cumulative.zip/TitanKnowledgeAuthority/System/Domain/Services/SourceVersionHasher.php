<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Services;

final class SourceVersionHasher
{
    public function hash(string $content): string
    {
        return hash('sha256', $this->normalize($content));
    }

    public function rawHash(string $bytes): string
    {
        return hash('sha256', $bytes);
    }

    public function sameContent(string $left, string $right): bool
    {
        return hash_equals($this->hash($left), $this->hash($right));
    }

    private function normalize(string $content): string
    {
        return str_replace(["\r\n", "\r"], "\n", $content);
    }
}
