# Transactional Pruning & Streaming Archives

Titan Signal Engine v0.14.0 binds every destructive prune to a persisted, tamper-evident preview manifest.

## Prune flow

1. `previewPrune()` resolves eligible lifecycle rows and persists:
   - `preview_id`
   - exact `event_ids`
   - SHA-256 `candidate_hash`
   - tenant/scope boundary
   - retention-class counts
   - preview expiry
   - one-time confirmation token hash
2. The plaintext preview token is returned once to the authorized operator.
3. `prune(preview_token, reason, context)` locks the preview and verifies the token, scope, tenant, expiry, candidate hash and exact candidate set.
4. The exact lifecycle rows are atomically claimed with a stable prune-claim token.
5. A separate short-lived preview execution lease prevents two workers from executing the same preview concurrently.
6. Archive-required candidates are written with bounded-memory gzip streaming and SHA-256 verification. No-archive classes remain eligible for direct governed pruning.
7. A verified archive batch enters `verified_unpruned`; if the final database transaction fails, the same preview may safely resume without rewriting immutable Signal history.
8. The final transaction verifies the claim and execution lease, records archive catalog entries, removes derived hot projections, deletes exactly the approved immutable hot rows, and marks the preview/batch complete.

## Fail-closed conditions

A new preview is required when the approved set changes before it is claimed, including:

- legal hold added;
- retention deadline moved into the future;
- retention class becomes non-prunable;
- event/lifecycle metadata disappears;
- another prune holds an active claim;
- candidate manifest/hash mismatch.

The engine never substitutes a newly-calculated candidate set at confirmation time.

## Recovery

- `failed_retryable`: archive/pre-prune failure before a verified archive exists; claims are released and the preview TTL is refreshed.
- `verified_unpruned`: archive exists and verifies, but hot deletion has not completed. Reusing the same preview token resumes at finalization.
- expired execution leases allow a new worker to continue the same preview.
- housekeeping clears expired lifecycle claims and stale preview execution leases.

## Streaming archive guarantees

`LocalSignalArchiveStore` no longer builds `manifest + all event lines + gzip copy` in PHP memory.

Writes:

- stream each JSONL event into a temporary gzip file;
- verify actual event count against expected count;
- calculate SHA-256 from the compressed temporary file;
- upload using a Laravel storage stream.

Reads:

- read the storage object as a stream;
- calculate SHA-256 incrementally while materializing a bounded temporary compressed file;
- decode gzip line-by-line;
- enforce compressed and uncompressed byte ceilings.

This is bounded-memory operation. Temporary disk capacity remains an operational dependency and should be monitored.

## Retention classes without required archive

`RetentionPolicy::archiveRequired` is authoritative. For example, `debug` events may be pruned after expiry without creating a cold archive/catalog record. Their lifecycle row retains the prune audit but does not falsely claim an archive location.
