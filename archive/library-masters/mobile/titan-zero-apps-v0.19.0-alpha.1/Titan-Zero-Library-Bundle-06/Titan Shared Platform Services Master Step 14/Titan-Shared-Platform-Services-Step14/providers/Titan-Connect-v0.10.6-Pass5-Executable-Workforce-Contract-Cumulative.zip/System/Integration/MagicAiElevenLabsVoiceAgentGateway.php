<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Integration;

use App\Extensions\TitanConnect\System\Contracts\VoiceAgentGateway;
use RuntimeException;

final class MagicAiElevenLabsVoiceAgentGateway implements VoiceAgentGateway
{
    private function service(): object
    {
        $class='App\\Services\\Ai\\ElevenLabsService'; if (! class_exists($class)) throw new RuntimeException('MagicAI ElevenLabs service is unavailable.'); return app($class);
    }
    public function create(array $config): array { return $this->data($this->service()->createAgent(conversation_config:$config['conversation_config'] ?? [], name:(string)($config['name'] ?? 'Titan Connect Voice'))); }
    public function update(string $agentId, array $config): array { return $this->data($this->service()->updateAgent(agent_id:$agentId, conversation_config:$config['conversation_config'] ?? [], name:$config['name'] ?? null)); }
    public function delete(string $agentId): void { $this->service()->deleteAgent($agentId); }
    public function voices(): array { $data=$this->data($this->service()->getListOfVoices(page_size:100)); return is_array($data['voices'] ?? null)?$data['voices']:[]; }
    public function addKnowledge(string $type, mixed $content, ?string $name = null): array
    {
        $service=$this->service(); $response=match($type){'text'=>$service->createKnowledgebaseDocFromText(text:$content,name:$name),'url'=>$service->createKnowledgebaseDocFromUrl(url:$content,name:$name),'file'=>$service->createKnowledgebaseDocFromFile(file:$content,name:$name),default=>throw new RuntimeException('Unsupported voice knowledge type.')}; return $this->data($response);
    }
    public function removeKnowledge(string $documentId): void { $this->service()->deleteKnowledgebaseDocument($documentId); }
    private function data(mixed $response): array { if (is_array($response)) return $response; if (is_object($response) && method_exists($response,'getData')) { $data=$response->getData(true); if (is_array($data)) return is_array($data['resData'] ?? null)?$data['resData']:$data; } return []; }
}
