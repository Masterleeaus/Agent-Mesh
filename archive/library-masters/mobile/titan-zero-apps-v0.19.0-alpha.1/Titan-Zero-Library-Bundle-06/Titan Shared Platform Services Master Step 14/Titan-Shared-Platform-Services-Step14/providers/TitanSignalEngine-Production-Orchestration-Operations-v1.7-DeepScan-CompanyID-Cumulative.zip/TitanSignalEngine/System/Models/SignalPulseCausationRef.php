<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalPulseCausationRef extends Model
{
    protected $table = 'titan_signal_pulse_causation_refs';
    protected $guarded = [];
    protected $casts = [
        'tenant_company_id' => 'integer',
        'tenant_key' => 'integer',
        'resolved' => 'boolean',
        'occurred_at' => 'immutable_datetime',
        'resolved_at' => 'immutable_datetime',
    ];
}
