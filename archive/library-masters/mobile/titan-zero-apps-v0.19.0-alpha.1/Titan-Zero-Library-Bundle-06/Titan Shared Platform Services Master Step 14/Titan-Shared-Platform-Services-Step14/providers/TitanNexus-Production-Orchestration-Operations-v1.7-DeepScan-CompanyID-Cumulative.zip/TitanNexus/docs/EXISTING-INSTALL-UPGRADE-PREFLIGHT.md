# Existing-Install Upgrade Preflight

This package includes a package-side upgrade preflight for the future live Pass 6 upgrade certification.

It verifies that the target package retains the fresh-install contract, uses a strictly ordered migration chain, has unique full route names, unique Nexus menu identities/fallback routes, and no duplicate provider singleton declarations.

When supplied with installed-host facts, it additionally blocks upgrade when the installed version is newer than the target, the compilation table is missing, the applied migration list is not an exact prefix of the packaged migration chain, unknown migrations are present, duplicate compilation identities exist, duplicate menu/route/service registrations are reported, or lifecycle-table state disagrees with migration `000005`.

For the RC1 → RC2 path, the expected pending migrations are:

1. `2026_08_21_000004_add_nexus_compilation_concurrency_guards`
2. `2026_08_21_000005_create_titan_nexus_compilation_events_table`

Run package-only preflight:

```bash
php tools/existing_install_upgrade_preflight.php --root=/path/to/TitanNexus
```

Run with installed-host facts:

```bash
php tools/existing_install_upgrade_preflight.php \
  --root=/path/to/TitanNexus \
  --installed-facts=certification/upgrade-host-facts.example.json
```

A PASS from this tool is **not** `UPGRADE_CERTIFIED`. Live certification still requires a backup, deployment of the exact target ZIP, execution of pending migrations on the real MySQL host, provider boot, duplicate-registration checks, existing-data verification, Control Centre verification, idempotent second boot, and a bound host certification report.
