<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Http\Controllers;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalConsoleContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalConsoleRequest;
use App\Extensions\TitanSignalEngine\System\Services\SignalConsoleContextFactory;
use App\Extensions\TitanSignalEngine\System\Services\SignalConsoleErrorReporter;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use InvalidArgumentException;

final class IndexController
{
    public function __construct(
        private readonly SignalConsoleContract $console,
        private readonly SignalConsoleContextFactory $contexts,
        private readonly SignalConsoleErrorReporter $errors,
    ) {
    }

    public function __invoke(Request $request): View
    {
        $consoleError = null;
        $context = null;
        try {
            $context = $this->contexts->forTenant($request);
            $spec = SignalConsoleRequest::fromArray([
                'scope' => 'tenant',
                'tenant_company_id' => $context->tenantCompanyId,
                'window' => $request->query('window', '5m'),
                'limit' => $request->query('limit', 50),
            ]);
            $dashboard = $this->console->dashboard($spec, $context, false);
        } catch (\Throwable $exception) {
            $consoleError = $this->errors->report($exception, 'tenant.dashboard', $context);
            if ($context === null) {
                abort(403, $consoleError);
            }
            $spec = SignalConsoleRequest::fromArray(['scope' => 'tenant', 'tenant_company_id' => $context->tenantCompanyId, 'window' => '5m', 'limit' => 50]);
            $dashboard = $this->fallbackDashboard($spec);
        }

        $detail = null;
        if ($context !== null) {
            try {
                $traceId = trim((string) $request->query('trace_id', ''));
                if ($traceId !== '') {
                    $this->assertUuid($traceId, 'trace_id');
                    $detail = ['kind' => 'trace', 'id' => $traceId, 'data' => $this->console->trace($traceId, $spec, $context)];
                } else {
                    $correlationId = trim((string) $request->query('correlation_id', ''));
                    if ($correlationId !== '') {
                        $this->assertUuid($correlationId, 'correlation_id');
                        $detail = ['kind' => 'workflow', 'id' => $correlationId, 'data' => $this->console->workflow($correlationId, $spec, $context)];
                    } else {
                        $eventId = trim((string) $request->query('event_id', ''));
                        if ($eventId !== '') {
                            $this->assertUuid($eventId, 'event_id');
                            $detail = ['kind' => 'event', 'id' => $eventId, 'data' => $this->console->event($eventId, $spec, $context)];
                        }
                    }
                }
            } catch (\Throwable $exception) {
                $consoleError = $this->errors->report($exception, 'tenant.detail', $context);
            }
        }

        return view('titan-signal-engine::index-rc7', compact('dashboard', 'detail', 'consoleError'));
    }

    /** @return array<string,mixed> */
    private function fallbackDashboard(SignalConsoleRequest $spec): array
    {
        return [
            'request' => $spec->toArray(),
            'surface' => [
                'headline' => 'Signal Console unavailable',
                'attention' => ['band' => 'unknown', 'score' => 0],
                'signal_count' => 0, 'error_count' => 0, 'stalled_trace_count' => 0,
                'missing_receipt_count' => 0, 'event_rate_per_second' => 0.0,
            ],
            'anomalies' => [],
        ];
    }

    private function assertUuid(string $value, string $field): void
    {
        if (! preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value)) {
            throw new InvalidArgumentException("Invalid {$field}.");
        }
    }
}
