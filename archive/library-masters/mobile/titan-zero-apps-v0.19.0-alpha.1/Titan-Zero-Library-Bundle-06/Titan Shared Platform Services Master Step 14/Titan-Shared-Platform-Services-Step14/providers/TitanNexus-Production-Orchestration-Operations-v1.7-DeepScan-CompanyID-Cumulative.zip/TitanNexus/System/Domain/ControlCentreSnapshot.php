<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use InvalidArgumentException;

final class ControlCentreSnapshot
{
    /**
     * @param array<string,mixed> $summary
     * @param list<array<string,mixed>> $compilations
     * @param array<string,mixed>|null $selected
     * @param list<array<string,mixed>> $lineage
     */
    public function __construct(
        private readonly int $tenantCompanyId,
        private readonly array $summary,
        private readonly array $compilations,
        private readonly ?array $selected,
        private readonly array $lineage,
    ) {
        if ($this->tenantCompanyId <= 0) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'tenant_company_id' => $this->tenantCompanyId,
            'summary' => $this->summary,
            'compilations' => array_values($this->compilations),
            'selected' => $this->selected,
            'lineage' => array_values($this->lineage),
        ];
    }
}
