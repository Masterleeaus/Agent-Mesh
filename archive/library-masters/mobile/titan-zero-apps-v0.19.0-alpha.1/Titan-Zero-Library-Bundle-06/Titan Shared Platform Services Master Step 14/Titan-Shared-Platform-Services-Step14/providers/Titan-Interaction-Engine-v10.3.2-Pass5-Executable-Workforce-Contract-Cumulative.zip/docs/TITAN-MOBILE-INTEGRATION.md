# Titan Mobile Integration

Mobile Core owns shared mobile identity, devices, notifications, approvals and mobile installation infrastructure. Interaction Engine owns wizard/journey state and surface filtering; it does not manage devices directly.

Phase 6 declares `mobile.*` capability descriptors, including `mobile.application.readiness`, worker/owner/customer activation, notification configuration, device status and installation links. These are **fail-closed** unless the host binds `MobileCapabilityGatewayInterface` to a verified company-scoped Mobile Core gateway.

The supplied Mobile Core 0.14 archive exposes `MobileCapabilityRegistry`, but that contract is a global installed-capability registry and does not accept `company_id`. Phase 6 therefore does **not** misrepresent it as company-specific application readiness. A future/current host adapter must preserve trusted `company_id`, actor and correlation context before these capabilities become AVAILABLE.
