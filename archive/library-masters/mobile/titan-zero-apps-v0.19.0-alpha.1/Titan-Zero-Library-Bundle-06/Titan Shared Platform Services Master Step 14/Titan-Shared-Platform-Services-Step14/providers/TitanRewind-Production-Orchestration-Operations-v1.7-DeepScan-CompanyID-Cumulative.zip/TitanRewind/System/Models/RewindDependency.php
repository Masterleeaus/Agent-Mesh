<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindDependency extends Model
{
    protected $table = 'titan_rewind_dependencies';
    protected $fillable = [
        'dependency_key','tenant_company_id','case_id','event_id','trace_id','source_entity_type','source_entity_id','target_entity_type','target_entity_id',
        'relationship_type','risk_level','metadata',
    ];
    protected $casts = ['tenant_company_id'=>'integer','case_id'=>'integer','metadata'=>'array'];
}
