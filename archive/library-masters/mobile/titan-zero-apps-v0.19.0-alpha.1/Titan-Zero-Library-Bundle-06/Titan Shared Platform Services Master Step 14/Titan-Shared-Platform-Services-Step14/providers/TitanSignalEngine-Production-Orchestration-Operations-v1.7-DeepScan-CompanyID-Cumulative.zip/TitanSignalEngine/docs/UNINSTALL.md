# Uninstall

Default policy is **retain**.

Uninstall removes only package-owned published operational configuration by default. Signal event history, archive objects and audit/lifecycle data are retained unless a separately governed tenant/data-retention process explicitly exports/anonymizes/prunes them.

Never delete another extension's tables or authoritative domain data.
