# Post-Production Deep Scan Hotfix 1.0.1

This hotfix follows the 16/16 production-candidate build and a second independent static, runtime, migration and privacy scan.

## Confirmed defects fixed

1. **CRM extraction floor restored to alpha.24.** CRM alpha.17-alpha.23 still own the Field Services domain, so accepting those versions could create dual authoritative writers.
2. **Offline receipt reservation is atomic.** Concurrent Titan Go reconnects use `insertOrIgnore`, deterministic replay states, and a bounded abandoned-processing lease rather than check-then-insert races.
3. **Failed offline receipts retry in place.** The unique receipt row is retained instead of deleted, preserving audit/idempotency history.
4. **Fallback live-location privacy is current-state checked.** Retained Field GPS is visible only for active workers with current consent and an active current-day route/shift.
5. **Fallback GPS retention is enforced.** `titan-field:prune-worker-location` is registered and scheduled hourly.
6. **Offline fallback replay preserves live/historical classification.** Duplicate offline samples no longer become falsely historical.
7. **Navigation label encoding hardened.** `Routes and Live Position` avoids host `&amp;` rendering.
8. **Host DB migration adoption rechecked.** Existing CRM-era tables remain restartable/guarded; no destructive `up()` migrations were introduced.

## Supplied host DB warning

The supplied 2026-08-18 dump registers CRM **1.3.0-alpha.17**. Titan Field 1.0.1 deliberately requires **CRM >=1.3.0-alpha.24**, the Field extraction boundary. Do not install Titan Field 1.0.1 on that snapshot until CRM is upgraded to alpha.24 or newer.

Package verification is not a claim that a live Laravel/MySQL installation was executed.
