<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);function fail_dv(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function same_dv(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_dv($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}function ok_dv(bool $c,string $m):void{if(!$c)fail_dv($m);}
$f=$root.'/System/DecisionIntelligence/GovernanceDeltaViewer.php';if(!is_file($f))fail_dv('missing production file');require_once $f;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceDeltaViewer;
$v=new GovernanceDeltaViewer(maxDepth:5,maxFields:20,maxStringLength:12);
$out=$v->compare(
 ['decision_id'=>'a','status'=>'HOLD','observed_at'=>'old','meta'=>['score'=>10,'note'=>'abcdefghijklmnop'],'removed'=>'x'],
 ['decision_id'=>'b','status'=>'APPROVE','observed_at'=>'new','meta'=>['score'=>20,'note'=>'abcdefghijklZZ'],'added'=>'y']
);
same_dv(['added'],$out['added_paths'],'added path');same_dv(['removed'],$out['removed_paths'],'removed path');
$changed=array_column($out['changed'],'path');same_dv(['decision_id','meta.note','meta.score','status'],$changed,'changed paths deterministic');
ok_dv(!in_array('observed_at',$changed,true),'volatile observed_at ignored');same_dv('abcdefghijkl',$out['changed'][1]['old'],'values must be bounded');same_dv(0,$out['unchanged_count'],'unchanged count');same_dv(false,$out['truncated'],'small comparison not truncated');
$limited=(new GovernanceDeltaViewer(maxFields:2))->compare(['a'=>1,'b'=>2,'c'=>3],['a'=>9,'b'=>8,'c'=>7]);same_dv(true,$limited['truncated'],'field limit must mark truncation');
echo "PASS: Governance delta viewer\n";
