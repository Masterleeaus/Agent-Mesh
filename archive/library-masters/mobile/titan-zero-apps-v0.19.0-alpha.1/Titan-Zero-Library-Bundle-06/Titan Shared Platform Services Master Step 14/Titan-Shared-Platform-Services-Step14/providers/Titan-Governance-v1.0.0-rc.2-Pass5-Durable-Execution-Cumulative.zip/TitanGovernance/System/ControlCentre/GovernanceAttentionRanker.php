<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ControlCentre;

use DateTimeImmutable;
use Throwable;

final class GovernanceAttentionRanker
{
    /**
     * @param array<string,mixed> $modelHealth
     * @param array<string,mixed> $policyCompliance
     * @param array<string,mixed> $engineHealth
     * @param array<string,mixed> $authorityContractions
     * @param array<string,mixed> $freshness
     * @param array<string,mixed> $signal
     * @param list<array<string,mixed>> $escalations
     * @return array<string,mixed>
     */
    public function rank(array $modelHealth,array $policyCompliance,array $engineHealth,array $authorityContractions,array $freshness,array $signal,array $escalations,array $workforce=[],array $human=[]):array
    {
        $items=[];
        foreach($modelHealth['models']??[] as $row){
            if(!is_array($row))continue;$health=strtoupper((string)($row['health']??'UNKNOWN'));
            $severity=match($health){'FAILED'=>'CRITICAL','DEGRADED'=>'HIGH','STALE'=>'MEDIUM',default=>null};
            if($severity!==null)$items[]=$this->item('model',$severity,'MODEL_'.$health,(string)($row['source']??'model'),$row['reference']??null,$row['observed_at']??null,null,'Model '.$row['model_id'].' is '.$health.'.');
        }
        $council=is_array($modelHealth['council']??null)?$modelHealth['council']:[];
        $level=strtoupper((string)($council['disagreement_level']??'UNKNOWN'));
        if((bool)($council['material_disagreement']??false)||in_array($level,['HIGH','CRITICAL'],true)){
            $severity=$level==='CRITICAL'?'CRITICAL':'HIGH';
            $items[]=$this->item('model_council',$severity,'MODEL_COUNCIL_DISAGREEMENT',(string)($council['source']??'titan-model-council'),$council['reference']??null,$council['observed_at']??null,null,'Model Council disagreement requires review.');
        }
        foreach($policyCompliance['policies']??[] as $row){
            if(is_array($row)&&($row['drift_status']??null)==='DRIFT')$items[]=$this->item('policy','HIGH','POLICY_VERSION_DRIFT',(string)($row['source']??'unknown'),$row['reference']??$row['policy_key']??null,$row['observed_at']??null,null,'Policy version drift: '.($row['policy_key']??'unknown').'.');
        }
        foreach($policyCompliance['controls']??[] as $row){
            if(!is_array($row))continue;$status=strtoupper((string)($row['status']??'UNKNOWN'));
            if(in_array($status,['NON_COMPLIANT','FAILED','BLOCKED','VIOLATION'],true))$items[]=$this->item('control','CRITICAL','CONTROL_'.$status,(string)($row['source']??'unknown'),$row['reference']??$row['control_key']??null,$row['observed_at']??null,$row['expires_at']??null,'Compliance control '.($row['control_key']??'unknown').' is '.$status.'.');
        }
        foreach($policyCompliance['exceptions']??[] as $row){
            if(!is_array($row))continue;$status=strtoupper((string)($row['expiry_status']??'UNKNOWN'));
            $severity=match($status){'EXPIRED'=>'CRITICAL','EXPIRING','INVALID'=>'HIGH',default=>null};
            if($severity!==null)$items[]=$this->item('exception',$severity,'EXCEPTION_'.$status,'titan-governance',$row['decision_id']??null,$row['decided_at']??null,$row['expires_at']??null,'Governance exception is '.$status.'.');
        }
        foreach($engineHealth['items']??[] as $row){
            if(!is_array($row))continue;$status=strtoupper((string)($row['status']??'UNKNOWN'));$required=(bool)($row['required']??false);
            $severity=null;
            if($required&&in_array($status,['UNAVAILABLE','ERROR','NOT_INSTALLED','INVALID'],true))$severity='CRITICAL';
            elseif($required&&in_array($status,['STALE','DEGRADED','UNKNOWN'],true))$severity='HIGH';
            elseif(!$required&&in_array($status,['UNAVAILABLE','ERROR','INVALID'],true))$severity='MEDIUM';
            elseif(!$required&&in_array($status,['STALE','DEGRADED','UNKNOWN'],true))$severity='LOW';
            if($severity!==null)$items[]=$this->item('engine',$severity,'ENGINE_'.$status,(string)($row['source']??'unknown'),$row['source']??null,$row['observed_at']??null,null,'Engine source '.($row['source']??'unknown').' is '.$status.'.');
        }
        foreach($authorityContractions['items']??[] as $row){
            if(!is_array($row))continue;$status=(string)($row['status']??'');$disposition=strtoupper((string)($row['disposition']??''));
            if($status==='INVALID_SOURCE_AUTHORITY_ORDER')$items[]=$this->item('authority','HIGH','AUTHORITY_SOURCE_ORDER_INVALID',(string)($row['source']??'titan-autonomy'),$row['reference']??null,$row['observed_at']??null,$row['expires_at']??null,'Authority evidence has an invalid source ordering.');
            elseif($status==='CONTRACTED'&&in_array($disposition,['DENY','HOLD','REQUIRE_APPROVAL'],true))$items[]=$this->item('authority',$disposition==='REQUIRE_APPROVAL'?'MEDIUM':'HIGH','AUTHORITY_CONTRACTED',(string)($row['source']??'titan-autonomy'),$row['reference']??null,$row['observed_at']??null,$row['expires_at']??null,'Effective authority is constrained by policy.');
        }
        foreach($freshness['items']??[] as $row){
            if(!is_array($row))continue;$fresh=strtoupper((string)($row['freshness']??'UNKNOWN'));$required=(bool)($row['required']??false);
            if($required&&in_array($fresh,['STALE','INVALID'],true))$items[]=$this->item('freshness','HIGH','EVIDENCE_'.$fresh,(string)($row['source']??'unknown'),$row['source']??null,$row['observed_at']??null,null,'Required governance evidence is '.$fresh.'.');
        }
        foreach($signal['operational_pressure']['items']??[] as $row){
            if(!is_array($row))continue;$band=strtoupper((string)($row['pressure_band']??'NORMAL'));
            $severity=match($band){'CRITICAL'=>'CRITICAL','HIGH'=>'HIGH','ELEVATED'=>'MEDIUM',default=>null};
            if($severity!==null)$items[]=$this->item('pressure',$severity,'OPERATIONAL_PRESSURE_'.$band,'titan-signal',$row['source_component']??null,$row['observed_at']??null,null,'Operational pressure is '.$band.' for '.($row['source_component']??'unknown').'.');
        }
        foreach($signal['circuit_breakers']['items']??[] as $row){
            if(!is_array($row))continue;$state=strtoupper((string)($row['state']??'UNKNOWN'));
            $severity=match($state){'OPEN'=>'HIGH','HALF_OPEN'=>'MEDIUM',default=>null};
            if($severity!==null)$items[]=$this->item('circuit',$severity,'CIRCUIT_'.$state,'titan-signal',$row['breaker_key']??null,$row['opened_at']??$row['observed_at']??null,$row['retry_after']??null,'Circuit '.($row['breaker_key']??'unknown').' is '.$state.'.');
        }
        foreach(array_slice($escalations,0,200) as $row){
            if(!is_array($row))continue;$risk=is_numeric($row['risk_score']??null)?(float)$row['risk_score']:0.0;$urgency=(int)($row['urgency']??0);
            $severity=$risk>=90?'CRITICAL':($risk>=70||$urgency>=80?'HIGH':'MEDIUM');
            $subjectType=strtolower((string)($row['subject_type']??''));$subjectId=(string)($row['subject_id']??'');$drill=[];
            if(str_contains($subjectType,'workforce')||str_contains($subjectType,'task'))$drill=['surface'=>'workforce','focus_type'=>'task','focus_id'=>$subjectId];
            elseif(str_contains($subjectType,'handoff'))$drill=['surface'=>'workforce','focus_type'=>'handoff','focus_id'=>$subjectId];
            $items[]=$this->item('escalation',$severity,'GOVERNANCE_ESCALATION_OPEN','titan-governance',$row['escalation_id']??null,$row['opened_at']??null,null,'Governance escalation requires review.',['risk_score'=>$risk,'urgency'=>$urgency],$drill);
        }
        foreach(array_slice(is_array($human['approvals']??null)?$human['approvals']:[],0,200) as $row){
            if(!is_array($row))continue;$age=strtoupper((string)($row['age_status']??'UNKNOWN'));$severity=match($age){'OVERDUE'=>'CRITICAL','AGING'=>'HIGH',default=>null};if($severity===null)continue;
            $task=(string)($row['task_id']??'');$items[]=$this->item('workforce_approval',$severity,'WORKFORCE_APPROVAL_'.$age,'titan-ai-workforce',$task,$row['observed_at']??$row['updated_at']??null,null,'Workforce task approval is '.$age.'.',['manager_id'=>$row['manager_id']??null,'manager'=>$row['manager']??null],['surface'=>'workforce','focus_type'=>'task','focus_id'=>$task]);
        }
        foreach(array_slice(is_array($human['handoffs']??null)?$human['handoffs']:[],0,200) as $row){
            if(!is_array($row))continue;$status=strtoupper((string)($row['status']??'UNKNOWN'));$age=strtoupper((string)($row['age_status']??'UNKNOWN'));$severity=$status==='ESCALATED'?'HIGH':($age==='OVERDUE'?'HIGH':($age==='AGING'?'MEDIUM':null));if($severity===null)continue;
            $id=(string)($row['handoff_id']??'');$reason=$status==='ESCALATED'?'WORKFORCE_HANDOFF_ESCALATED':'WORKFORCE_HANDOFF_'.$age;$items[]=$this->item('workforce_handoff',$severity,$reason,'titan-ai-workforce',$id,$row['observed_at']??$row['updated_at']??null,null,'Workforce handoff requires human oversight.',['task_id'=>$row['task_id']??null],['surface'=>'workforce','focus_type'=>'handoff','focus_id'=>$id]);
        }
        foreach(array_slice(is_array($workforce['queues']??null)?$workforce['queues']:[],0,200) as $row){
            if(!is_array($row))continue;$health=is_array($row['health']??null)?$row['health']:[];$pressure=strtoupper((string)($health['pressure']??'UNKNOWN'));$severity=match($pressure){'CRITICAL'=>'CRITICAL','HIGH'=>'HIGH','ELEVATED','MEDIUM'=>'MEDIUM',default=>null};if($severity===null)continue;
            $manager=(string)($row['manager_id']??'');$items[]=$this->item('workforce_queue',$severity,'WORKFORCE_QUEUE_PRESSURE_'.$pressure,'titan-ai-workforce',$manager,$row['observed_at']??null,null,'Workforce queue pressure is '.$pressure.' for '.($row['manager']??$row['division']??'manager').'.',['queue_depth'=>$health['queue_depth']??0,'overdue_count'=>$health['overdue_count']??0],['surface'=>'workforce','focus_type'=>'queue','focus_id'=>$manager]);
        }
        $rank=['CRITICAL'=>4,'HIGH'=>3,'MEDIUM'=>2,'LOW'=>1];
        usort($items,function(array $a,array $b)use($rank):int{return ($rank[$b['severity']]<=>$rank[$a['severity']]) ?: ($this->time($a['observed_at']??null)<=>$this->time($b['observed_at']??null)) ?: strcmp((string)$a['reason_code'],(string)$b['reason_code']) ?: strcmp((string)($a['reference']??''),(string)($b['reference']??''));});
        foreach($items as &$row)$row['score']=($rank[$row['severity']]??0)*100;unset($row);
        return ['total'=>count($items),'critical_count'=>count(array_filter($items,static fn(array $r):bool=>$r['severity']==='CRITICAL')),'high_count'=>count(array_filter($items,static fn(array $r):bool=>$r['severity']==='HIGH')),'medium_count'=>count(array_filter($items,static fn(array $r):bool=>$r['severity']==='MEDIUM')),'low_count'=>count(array_filter($items,static fn(array $r):bool=>$r['severity']==='LOW')),'items'=>array_slice($items,0,200)];
    }

    /** @param array<string,mixed> $metadata @return array<string,mixed> */
    private function item(string $type,string $severity,string $reason,string $source,mixed $reference,mixed $observedAt,mixed $expiresAt,string $summary,array $metadata=[],array $drillDown=[]):array
    {
        $ref=is_scalar($reference)&&trim((string)$reference)!==''?(string)$reference:null;
        return ['type'=>$type,'severity'=>$severity,'reason_code'=>$reason,'source'=>$source,'reference'=>$ref,'observed_at'=>is_scalar($observedAt)?(string)$observedAt:null,'expires_at'=>is_scalar($expiresAt)?(string)$expiresAt:null,'summary'=>$summary,'metadata'=>$metadata,'drill_down'=>$drillDown];
    }
    private function time(mixed $value):int{if(!is_string($value)||trim($value)==='')return PHP_INT_MAX;try{return (new DateTimeImmutable($value))->getTimestamp();}catch(Throwable){return PHP_INT_MAX;}}
}
