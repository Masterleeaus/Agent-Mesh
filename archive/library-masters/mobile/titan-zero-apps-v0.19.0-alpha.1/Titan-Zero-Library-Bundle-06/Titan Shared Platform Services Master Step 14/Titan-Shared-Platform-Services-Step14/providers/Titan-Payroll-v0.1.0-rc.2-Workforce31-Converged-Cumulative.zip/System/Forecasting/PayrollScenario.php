<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Forecasting;
final class PayrollScenario
{
    public function __construct(public readonly int $tenantCompanyId,public readonly float $baseMonthlyPayroll,public readonly float $growthRate,public readonly int $months,public readonly array $assumptions,public readonly array $projection){}
    public function toArray():array{return ['tenant_company_id'=>$this->tenantCompanyId,'scenario_id'=>hash('sha256',json_encode([$this->tenantCompanyId,$this->baseMonthlyPayroll,$this->growthRate,$this->months,$this->assumptions],JSON_PRESERVE_ZERO_FRACTION)),'assumptions'=>['base_monthly_payroll'=>$this->baseMonthlyPayroll,'growth_rate'=>$this->growthRate,'months'=>$this->months]+$this->assumptions,'projection'=>$this->projection,'uncertainty'=>'scenario_only','promise'=>false];}
}
