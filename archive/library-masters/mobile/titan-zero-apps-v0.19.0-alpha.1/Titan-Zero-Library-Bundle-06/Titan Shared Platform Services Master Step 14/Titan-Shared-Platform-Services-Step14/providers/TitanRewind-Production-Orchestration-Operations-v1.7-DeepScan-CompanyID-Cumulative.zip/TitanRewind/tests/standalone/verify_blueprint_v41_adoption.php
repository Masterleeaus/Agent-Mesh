<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$checks = 0;
$failures = [];
$assert = static function (bool $condition, string $message) use (&$checks, &$failures): void {
    ++$checks;
    if (!$condition) { $failures[] = $message; fwrite(STDERR, "FAIL: {$message}\n"); }
};

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$assert(($manifest['version'] ?? null) === '1.0.6', 'manifest version is 1.0.6');
$assert(in_array(($manifest['schema_version'] ?? null), ['2.0','2.1','2.2'], true), 'manifest activates Blueprint schema v2.x in final certification pass');
$assert(($manifest['runtime_profile'] ?? null) === 'titan-rewind', 'final titan-rewind production profile is active');
$assert(in_array('rewind.evidence.signed',$manifest['capabilities'] ?? [],true), 'signed evidence capability is declared');
$assert(in_array('rewind.custody',$manifest['capabilities'] ?? [],true), 'custody capability is declared');
$assert(in_array('rewind.legal-hold',$manifest['capabilities'] ?? [],true), 'legal hold capability is declared');
$assert(in_array('rewind.source-watermarks',$manifest['capabilities'] ?? [],true), 'source watermark capability is declared');
$assert(in_array('rewind.replay.current-state',$manifest['capabilities'] ?? [],true), 'current-state replay capability is declared');

$permissions = $manifest['permissions'] ?? [];
foreach ([
    'rewind.trace.view','rewind.forensics.view','rewind.integrity.verify','rewind.replay.run',
    'rewind.evidence.generate','rewind.evidence.export','rewind.recovery.propose',
    'rewind.recovery.request-approval','rewind.legal-hold.manage','rewind.admin',
] as $permission) $assert(in_array($permission, $permissions, true), "permission declared: {$permission}");

$assert(!in_array('standalone', $manifest['tests'] ?? [], true), 'production manifest does not declare standalone test type');
$assert(is_file($root . '/docs/BLUEPRINT-V4.1-ADOPTION.md'), 'Blueprint v4.1 adoption status is documented');

$required = [
    'System/Security/RewindPermissions.php',
    'System/Security/RewindAuthorization.php',
    'System/Http/Middleware/RequireRewindPermission.php',
    'System/Contracts/RewindEvidenceSignerContract.php',
    'System/Evidence/OpenSslRewindEvidenceSigner.php',
    'System/Sources/RewindSourceCompleteness.php',
    'System/Contracts/RewindSourceWatermarkProviderContract.php',
    'System/Models/RewindSourceWatermark.php',
    'System/Services/RewindSourceWatermarkService.php',
    'System/Models/RewindCustodyEvent.php',
    'System/Models/RewindLegalHold.php',
    'System/Services/RewindCustodyService.php',
    'System/Services/RewindLegalHoldService.php',
    'System/Retention/RewindLegalHoldGuard.php',
    'System/Http/Controllers/LegalHoldController.php',
    'database/migrations/2026_08_16_000007_adopt_blueprint_v41_runtime.php',
    'docs/AUTHORIZATION-MATRIX.md','docs/ARCHITECTURE.md','docs/CAPABILITIES.md','docs/SECURITY.md',
    'docs/REWIND-CONTRACTS.md','docs/EVIDENCE-CUSTODY.md','docs/LEGAL-HOLD.md','docs/OPERATIONS.md',
];
foreach ($required as $file) $assert(is_file($root . '/' . $file), "Pass 5 file exists: {$file}");

$pure = [
    'System/Security/RewindPermissions.php',
    'System/Security/RewindAuthorization.php',
    'System/Contracts/RewindEvidenceSignerContract.php',
    'System/Evidence/OpenSslRewindEvidenceSigner.php',
    'System/Sources/RewindSourceCompleteness.php',
];
if (!array_filter($pure, static fn (string $f): bool => !is_file($root . '/' . $f))) {
    foreach ($pure as $file) require_once $root . '/' . $file;

    $all = App\Extensions\TitanRewind\System\Security\RewindPermissions::all();
    $assert(count($all) === 10, 'permission catalogue contains exactly ten production permissions');
    $assert(count($all) === count(array_unique($all)), 'permission catalogue contains no duplicates');

    $auth = new App\Extensions\TitanRewind\System\Security\RewindAuthorization();
    $auth->assertTenantMatch(7, 7);
    $denied = false;
    try { $auth->assertTenantMatch(7, 8); } catch (RuntimeException) { $denied = true; }
    $assert($denied, 'object authorization rejects cross-tenant object access');

    $completeness = new App\Extensions\TitanRewind\System\Sources\RewindSourceCompleteness();
    $state = $completeness->evaluate([
        ['source'=>'signal','state'=>'COMPLETE','observed_through'=>'2026-08-16T09:00:00+00:00'],
        ['source'=>'governance','state'=>'STALE','observed_through'=>'2026-08-16T08:00:00+00:00'],
    ]);
    $assert(($state['state'] ?? null) === 'STALE', 'source completeness returns worst source state');
    $assert(($state['complete_for_audit'] ?? true) === false, 'stale source set cannot claim complete audit');

    $signer = new App\Extensions\TitanRewind\System\Evidence\OpenSslRewindEvidenceSigner(null, null, 'test-key');
    $unavailable = false;
    try { $signer->sign(str_repeat('a', 64)); } catch (RuntimeException) { $unavailable = true; }
    $assert($unavailable, 'evidence signer fails closed when signing key is unavailable');

    if (extension_loaded('openssl')) {
        $key = openssl_pkey_new(['private_key_bits'=>2048,'private_key_type'=>OPENSSL_KEYTYPE_RSA]);
        $privatePem = ''; openssl_pkey_export($key,$privatePem);
        $details = openssl_pkey_get_details($key); $publicPem = is_array($details) ? (string)($details['key'] ?? '') : '';
        $privatePath = tempnam(sys_get_temp_dir(),'trw-private-'); $publicPath = tempnam(sys_get_temp_dir(),'trw-public-');
        file_put_contents($privatePath,$privatePem); file_put_contents($publicPath,$publicPem);
        $rsa = new App\Extensions\TitanRewind\System\Evidence\OpenSslRewindEvidenceSigner($privatePath,$publicPath,'ephemeral-test-key');
        $signed = $rsa->sign(str_repeat('b',64));
        $assert(($signed['algorithm'] ?? null) === 'openssl-rsa-sha256', 'evidence signer uses RSA-SHA256');
        $assert($rsa->verify(str_repeat('b',64),(string)$signed['signature'],'ephemeral-test-key'), 'evidence signer verifies its signature');
        $assert(!$rsa->verify(str_repeat('c',64),(string)$signed['signature'],'ephemeral-test-key'), 'evidence signer rejects a tampered content hash');
        @unlink($privatePath); @unlink($publicPath);
    }
}

$routes = (string) file_get_contents($root . '/routes/user.php');
foreach ([
    'rewind.trace.view','rewind.integrity.verify','rewind.replay.run','rewind.evidence.generate',
    'rewind.evidence.export','rewind.recovery.propose','rewind.recovery.request-approval','rewind.legal-hold.manage',
] as $permission) $assert(str_contains($routes, "titan-rewind.permission:{$permission}"), "user routes enforce {$permission}");

$adminRoutes = (string) file_get_contents($root . '/routes/admin.php');
$assert(str_contains($adminRoutes, 'titan-rewind.permission:rewind.admin'), 'admin route enforces rewind.admin');

if ($failures !== []) {
    fwrite(STDERR, sprintf("\n%d/%d checks failed.\n", count($failures), $checks));
    exit(1);
}
printf("PASS: %d/%d Blueprint v4.1 adoption checks passed.\n", $checks, $checks);
