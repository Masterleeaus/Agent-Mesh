<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Tenancy;

use Illuminate\Database\Eloquent\Builder;

trait CrmCompanyScoped
{
    protected static function bootCrmCompanyScoped(): void
    {
        static::addGlobalScope('crm_company', static function (Builder $builder): void {
            $builder->where($builder->getModel()->qualifyColumn('company_id'), CrmCompanyScope::companyId());
        });
        static::creating(static function ($model): void {
            $model->setAttribute('company_id', CrmCompanyScope::companyId());
            if ($model->getAttribute('user_id') === null && ($actor = CrmCompanyScope::actorUserId()) !== null) {
                $model->setAttribute('user_id', $actor);
            }
        });
    }
}
