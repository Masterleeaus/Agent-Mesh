# Titan Nexus Versioned Diff & Recompile Planning Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Add deterministic semantic diffing, explicit recompile policy classification, compilation lineage, and side-effect-free recompile planning.

**Architecture:** Compare immutable compiled snapshots using a pure differ and explicit policy metadata from the VerticalDefinition. Recompile planning creates a child dry-run compilation, validates/compiles it in memory, attaches a deterministic diff, and never provisions external state.

**Tech Stack:** PHP 8.2+, Laravel 10 extension conventions, immutable domain objects, SHA-256 canonical JSON fingerprints.

## Global Constraints

- Preserve every existing migration unchanged.
- Do not provision or mutate another Titan engine.
- No direct implementation imports from sibling Titan extensions.
- Every repository lookup remains tenant-scoped.
- Diff and plan fingerprints must be deterministic.
- Existing VerticalDefinition fingerprints remain unchanged when no recompile policy exists.

---

### Task 1: Semantic diff domain

**Files:**
- Create: `System/Domain/SemanticChangeKind.php`
- Create: `System/Domain/SemanticChangeDisposition.php`
- Create: `System/Domain/SemanticDiffEntry.php`
- Create: `System/Domain/ConfigurationDiff.php`
- Test: `tests/standalone-diff-check.php`

- [x] Write failing tests for add/modify/deprecate/unchanged, deterministic ordering, and round-trip fingerprints.
- [x] Run the test and confirm failure because diff classes are missing.
- [x] Implement immutable canonical domain objects.
- [x] Run the test and confirm green.

### Task 2: Recompile policy and pure differ

**Files:**
- Modify: `System/Domain/VerticalDefinition.php`
- Create: `System/Contracts/ConfigurationDifferContract.php`
- Create: `System/Services/SemanticConfigurationDiffer.php`
- Test: `tests/standalone-diff-check.php`

- [x] Add failing tests for atomic list changes, approval/blocked path rules, blocked precedence, and old fingerprint compatibility.
- [x] Run and confirm expected failure.
- [x] Add normalized optional `recompile_policy` metadata and pure differ implementation.
- [x] Run and confirm green.

### Task 3: Compilation diff persistence and lineage

**Files:**
- Modify: `System/Domain/NexusCompilation.php`
- Modify: `System/Contracts/CompilationRepositoryContract.php`
- Modify: `System/Repositories/EloquentCompilationRepository.php`
- Test: `tests/standalone-domain-check.php`
- Test: `tests/standalone-package-check.php`

- [x] Write failing tests/static checks for immutable `withConfigurationDiff()`, persistence round-trip, and tenant-scoped lineage.
- [x] Run and confirm expected failure.
- [x] Implement diff persistence and bounded loop-safe lineage traversal.
- [x] Run and confirm green.

### Task 4: Recompile plan orchestration

**Files:**
- Create: `System/Domain/RecompilePlanStatus.php`
- Create: `System/Domain/RecompilePlan.php`
- Modify: `System/Contracts/NexusManagerContract.php`
- Modify: `System/Services/NexusManager.php`
- Modify: `System/TitanNexusServiceProvider.php`
- Test: `tests/standalone-recompile-check.php`

- [x] Write failing tests for ready, approval, blocked-policy, blocked-validation, parent linkage, same-tenant enforcement, and immutability.
- [x] Run and confirm expected failure.
- [x] Bind the differ and implement `planRecompile()`.
- [x] Run and confirm green.

### Task 5: Package truth and hardening

**Files:**
- Modify: `extension.json`
- Modify: `extension.manifest.json`
- Modify: `README.md`
- Modify: `resources/views/index.blade.php`
- Modify: `resources/views/admin.blade.php`
- Modify: `tests/standalone-package-check.php`
- Add PHPUnit unit coverage for diff/recompile.

- [x] Update version to `0.5.0` and advertise only implemented capabilities: `nexus.compile.diff`, `nexus.recompile.plan`, `nexus.history.lineage`.
- [x] Run every standalone test, PHP lint, JSON validation, static cross-extension/provisioning scan, and migration hash comparison against the v0.4.0 parent.
- [x] Build cumulative ZIP, re-extract it, and repeat verification from the archive.
