# Live DB Menu Reconciliation

The supplied production SQL dump was inspected directly before packaging.

## Existing navigation used as anchors

- `ext_crm_gear` — id 371 — `Gear`
- `crm_tools` — id 495
- `crm_equipment` — id 496
- `crm_fleet` — id 497
- `crm_maintenance` — id 498
- `crm_customer_assets` — id 377

The `menus.key` column is unique and the table's next AUTO_INCREMENT value is 540.

## Option A reconciliation

Titan Assets creates/adopts the stable `titan_assets` parent and updates the five existing asset rows in place, preserving their existing ids. `ext_crm_gear` is retained but renamed **Inventory & Supplies**. Existing inventory, stock-location, stock-control, reservation, reorder and supplier child rows remain under that parent.

The boot-time healer validates named routes, repairs stale parent/route/label/icon/order/extension/active state, and regenerates `App\Services\Common\MenuService` when required. The install migration also invalidates/regenerates menu caches. Both paths fail open so navigation repair cannot take down application boot.

A separate DB simulation report accompanies the deployment bundle and confirms no duplicate stable menu keys are introduced.
