<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\DTO;

final readonly class GovernancePreflightReport
{
    /** @param array<int,GovernanceDecision> $decisions */
    public function __construct(
        public string $state,
        public bool $executable,
        public bool $requiresHumanReview,
        public array $decisions,
    ) {}

    public function decisionFor(string $engine): ?GovernanceDecision
    {
        foreach ($this->decisions as $decision) {
            if ($decision->engine === $engine) {
                return $decision;
            }
        }

        return null;
    }

    /** @return array<int,string> */
    public function reasonCodes(): array
    {
        return array_values(array_map(static fn (GovernanceDecision $decision): string => $decision->reasonCode, $this->decisions));
    }

    public function toArray(): array
    {
        return [
            'state' => $this->state,
            'executable' => $this->executable,
            'requires_human_review' => $this->requiresHumanReview,
            'decisions' => array_map(static fn (GovernanceDecision $decision): array => $decision->toArray(), $this->decisions),
        ];
    }
}
