<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\GateEvaluation;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\RiskClass;
use RuntimeException;

final class GateReviewService
{
    private const LEVELS = ['suggest' => 0, 'assist' => 1, 'semi_auto' => 2, 'auto' => 3, 'trusted_auto' => 4];
    private const DEFAULT_MINS = ['low' => 1, 'medium' => 2, 'high' => 3, 'critical' => 3];
    private const DEFAULT_CEILINGS = ['low' => 'trusted_auto', 'medium' => 'trusted_auto', 'high' => 'auto', 'critical' => 'semi_auto'];

    public function __construct(
        private readonly AutonomyQueryContract $query,
        private readonly PolicyMergeService $policyMerge = new PolicyMergeService(),
    ) {}

    /** @return array{state:CapabilityState,gate:GateEvaluation,row:array,effective_policy:array} */
    public function review(int $tenantCompanyId, string $capability, string $workflowKey): array
    {
        $row = $this->query->capabilityState($tenantCompanyId, $capability, $workflowKey);
        if ($row === null) throw new RuntimeException('CAPABILITY_STATE_NOT_FOUND');

        $state = $this->hydrate($row);
        $next = $state->currentLevel->next();
        $effectivePolicy = $this->effectivePolicy($tenantCompanyId);
        $required = (int) ($effectivePolicy['gate_minimums'][$state->risk->value] ?? self::DEFAULT_MINS[$state->risk->value]);
        $ceilingKey = (string) ($effectivePolicy['maximum_level_by_risk'][$state->risk->value] ?? self::DEFAULT_CEILINGS[$state->risk->value]);
        $ceilingValue = self::LEVELS[$ceilingKey] ?? self::LEVELS['assist'];

        $reasons = [];
        if ($next === null) $reasons[] = 'NO_NEXT_LEVEL';
        if (!(bool) ($row['platform_gate_eligible'] ?? false)) $reasons[] = 'PLATFORM_GATE_NOT_ELIGIBLE';
        if ($state->currentSuccessStreak < $required) $reasons[] = 'SUCCESS_STREAK_INSUFFICIENT_CURRENT_POLICY';
        if ($state->currentLevel->value > $ceilingValue) $reasons[] = 'CURRENT_LEVEL_ABOVE_POLICY_CEILING';
        if ($next !== null && $next->value > $ceilingValue) $reasons[] = 'RISK_CEILING';

        return [
            'state' => $state,
            'gate' => new GateEvaluation(
                eligible: $reasons === [],
                requiredSuccessStreak: $required,
                reasonCodes: array_values(array_unique($reasons)),
            ),
            'row' => $row,
            'effective_policy' => $effectivePolicy,
        ];
    }

    public function effectivePolicyForTenant(int $tenantCompanyId): array
    {
        return $this->effectivePolicy($tenantCompanyId);
    }

    private function effectivePolicy(int $tenantCompanyId): array
    {
        $platform = $this->query->platformPolicy() ?? [
            'gate_minimums' => self::DEFAULT_MINS,
            'maximum_level_by_risk' => self::DEFAULT_CEILINGS,
            'system_wide_learning_permitted' => false,
            'limits' => [],
        ];
        $platform['gate_minimums'] = array_merge(self::DEFAULT_MINS, (array) ($platform['gate_minimums'] ?? []));
        foreach (self::DEFAULT_MINS as $risk => $floor) {
            $platform['gate_minimums'][$risk] = max($floor, (int) $platform['gate_minimums'][$risk]);
        }
        $platform['maximum_level_by_risk'] = array_merge(self::DEFAULT_CEILINGS, (array) ($platform['maximum_level_by_risk'] ?? []));
        $limits = (array) ($platform['limits'] ?? []);
        if (!(bool) ($limits['high_trusted_auto_exception'] ?? false)
            && (self::LEVELS[$platform['maximum_level_by_risk']['high']] ?? 0) > self::LEVELS['auto']) {
            $platform['maximum_level_by_risk']['high'] = 'auto';
        }
        if (!(bool) ($limits['critical_autonomy_exception'] ?? false)
            && (self::LEVELS[$platform['maximum_level_by_risk']['critical']] ?? 0) > self::LEVELS['semi_auto']) {
            $platform['maximum_level_by_risk']['critical'] = 'semi_auto';
        }

        $tenant = $this->query->tenantPolicy($tenantCompanyId) ?? [];
        return $this->policyMerge->merge($platform, $tenant);
    }

    private function hydrate(array $row): CapabilityState
    {
        return new CapabilityState(
            tenantCompanyId: (int) $row['tenant_company_id'],
            capability: (string) $row['capability'],
            workflowKey: (string) ($row['workflow_key'] ?? ''),
            risk: RiskClass::from((string) $row['risk']),
            currentLevel: $this->level((string) ($row['current_level'] ?? 'suggest')),
            requiredSuccessStreak: (int) ($row['required_success_streak'] ?? 0),
            currentSuccessStreak: (int) ($row['current_success_streak'] ?? 0),
            highestSuccessStreak: (int) ($row['highest_success_streak'] ?? 0),
            totalSuccesses: (int) ($row['total_successes'] ?? 0),
            totalFailures: (int) ($row['total_failures'] ?? 0),
            totalEdits: (int) ($row['total_edits'] ?? 0),
            totalRejections: (int) ($row['total_rejections'] ?? 0),
            totalReversals: (int) ($row['total_reversals'] ?? 0),
            platformGateEligible: (bool) ($row['platform_gate_eligible'] ?? false),
            scope: is_array($row['scope'] ?? null) ? $row['scope'] : [],
            lastSuccessAt: isset($row['last_success_at']) && $row['last_success_at'] !== null ? (string) $row['last_success_at'] : null,
            lastFailureAt: isset($row['last_failure_at']) && $row['last_failure_at'] !== null ? (string) $row['last_failure_at'] : null,
        );
    }

    private function level(string $value): AutonomyLevel
    {
        return match ($value) {
            'suggest' => AutonomyLevel::Suggest,
            'assist' => AutonomyLevel::Assist,
            'semi_auto' => AutonomyLevel::SemiAuto,
            'auto' => AutonomyLevel::Auto,
            'trusted_auto' => AutonomyLevel::TrustedAuto,
            default => throw new RuntimeException('UNKNOWN_AUTONOMY_LEVEL'),
        };
    }
}
