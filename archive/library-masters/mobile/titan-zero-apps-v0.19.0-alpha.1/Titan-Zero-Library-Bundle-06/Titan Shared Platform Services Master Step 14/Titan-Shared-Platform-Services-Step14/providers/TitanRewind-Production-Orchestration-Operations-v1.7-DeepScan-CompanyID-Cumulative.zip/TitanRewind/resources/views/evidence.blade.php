@extends('panel.layout.app')
@section('title', 'Titan Rewind — Evidence')

@section('content')
    <a href="#titan-rewind-content" class="sr-only focus:not-sr-only">{{ __('titan-rewind::rewind.accessibility_skip') }}</a>
    <main id="titan-rewind-content" role="main" class="container py-8 space-y-6">
        <div>
            <h1 class="text-2xl font-semibold">Rewind Evidence Package</h1>
            <code>{{ $package->package_uuid }}</code>
            <p class="text-sm opacity-70">{{ strtoupper($package->package_type) }} · {{ $package->status }} · {{ $package->scope_type }} {{ $package->scope_id }}</p>
        </div>
        <div class="grid gap-4 md:grid-cols-6">
            <div class="rounded border p-3"><strong>{{ $decoded['hash_verified'] ? 'verified' : 'failed' }}</strong><div>Content hash</div></div>
            <div class="rounded border p-3"><strong>{{ $decoded['signature_verified'] ? 'verified' : 'failed' }}</strong><div>RSA signature</div></div>
            <div class="rounded border p-3"><strong>{{ $decoded['source_completeness'] ?? 'PARTIAL' }}</strong><div>Source completeness</div></div>
            <div class="rounded border p-3"><strong>{{ $package->manifest['event_count'] ?? 0 }}</strong><div>Events</div></div>
            <div class="rounded border p-3"><strong>{{ $package->manifest['snapshot_count'] ?? 0 }}</strong><div>Snapshots</div></div>
            <div class="rounded border p-3"><strong>{{ $package->manifest['integrity_state'] ?? 'unknown' }}</strong><div>Trace integrity</div></div>
        </div>
        <div><strong>SHA-256</strong><div class="break-all"><code>{{ $package->content_hash }}</code></div></div>
        <div><strong>Signing key</strong><div><code>{{ $package->signature_key_id ?: 'unavailable' }}</code> · {{ $package->signature_algorithm ?: 'unsigned legacy package' }}</div></div>
        <a class="inline-block rounded border px-4 py-2" href="{{ route('dashboard.user.titan.rewind.evidence.download',['packageUuid'=>$package->package_uuid]) }}">Download verified JSON bundle</a>
        @can('rewind.legal-hold.manage')
            <details class="rounded border p-4">
                <summary class="cursor-pointer font-medium">Apply legal hold to this evidence package</summary>
                <form class="mt-3 space-y-3" method="POST" action="{{ route('dashboard.user.titan.rewind.legal-holds.store') }}">
                    @csrf
                    <input type="hidden" name="scope_type" value="evidence-package" aria-label="scope type">
                    <input type="hidden" name="scope_id" value="{{ $package- aria-label="scope id">package_uuid }}">
                    <input class="w-full rounded border px-3 py-2" name="authority" placeholder="Authority" required aria-label="authority">
                    <textarea class="w-full rounded border px-3 py-2" name="reason" placeholder="Reason for hold" required aria-label="reason"></textarea>
                    <button class="rounded border px-4 py-2">Apply legal hold</button>
                </form>
            </details>
        @endcan
        <section class="rounded border p-4">
            <h2 class="text-lg font-semibold mb-2">Manifest</h2>
            <pre class="overflow-x-auto text-xs">{{ json_encode($package->manifest, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre>
        </section>
        <section class="rounded border p-4">
            <h2 class="text-lg font-semibold mb-2">Audit boundary</h2>
            <p>Rewind evidence records reconstruction and authorization evidence only. It contains no hidden chain-of-thought and grants no authority to mutate business state.</p>
        </section>
    </main>
@endsection
