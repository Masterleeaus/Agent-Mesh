# Titan Nexus Domain Core Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the versioned, tenant-safe Titan Nexus domain and persistence foundation while preserving installer compatibility.

**Architecture:** Keep business-compilation concepts framework-independent and immutable. Put Laravel/Eloquent behind repository contracts, require tenant identity on every public lookup, and evolve the existing table only through a new forward migration.

**Tech Stack:** PHP 8.2+, Laravel 10+, Eloquent, PHPUnit-compatible tests, standalone PHP verification.

## Global Constraints

- Preserve existing code, routes, views, provider key, table name, and installer compatibility.
- Do not implement provisioning or direct cross-extension authoritative mutations in Pass 1.
- Require `trace_id`, `correlation_id`, `causation_id`, and `tenant_company_id` in new compilation domain state.
- Never store unrestricted hidden chain-of-thought.
- Keep tenant isolation explicit in repository interfaces.
- Use forward-only migrations.

---

### Task 1: Domain contracts and validation

**Files:**
- Create `System/Domain/ValueObjects/TraceContext.php`
- Create `System/Domain/BusinessProfile.php`
- Create `System/Domain/CompiledTitanConfig.php`
- Create `System/Domain/CompilationStatus.php`
- Create `System/Domain/NexusCompilation.php`
- Test `tests/Unit/DomainCoreTest.php`
- Test `tests/standalone-domain-check.php`

**Interfaces:**
- Produces immutable domain values with `fromArray()` and `toArray()` boundaries.
- `NexusCompilation::draft(BusinessProfile, TraceContext, string $compilationUuid, string $compilerVersion)` creates a tenant-matched draft.

- [ ] Write tests that reject tenant mismatches, malformed UUIDs, missing vertical/profile fields, and unstable hashes.
- [ ] Run standalone harness and verify RED because production classes do not exist.
- [ ] Implement minimal domain classes.
- [ ] Run standalone harness and verify GREEN.

### Task 2: Tenant-scoped persistence boundary

**Files:**
- Create `System/Contracts/CompilationRepositoryContract.php`
- Create `System/Models/NexusCompilationRecord.php`
- Create `System/Repositories/EloquentCompilationRepository.php`
- Modify `System/TitanNexusServiceProvider.php`
- Test `tests/Architecture/BoundaryTest.php`

**Interfaces:**
- `save(NexusCompilation $compilation): NexusCompilation`
- `findForTenant(int $tenantCompanyId, string $compilationUuid): ?NexusCompilation`
- `latestForTenant(int $tenantCompanyId, int $limit = 25): array`

- [ ] Write architecture tests that require tenant-scoped repository methods and forbid direct cross-extension model/database imports.
- [ ] Implement Eloquent adapter and provider singleton binding.
- [ ] Run PHP syntax checks.

### Task 3: Forward-only database evolution

**Files:**
- Create `database/migrations/2026_08_11_000002_upgrade_titan_nexus_compilations_for_domain_core.php`

**Interfaces:**
- Adds compilation UUID, parent identity, causation, versions, hashes, snapshots, dry-run flag, and requester metadata without modifying the original migration.

- [ ] Add migration source assertions to architecture tests.
- [ ] Implement idempotent column additions and reversible down operations for the second migration only.
- [ ] Run PHP syntax checks.

### Task 4: Public manager and truthful package metadata

**Files:**
- Modify `System/Contracts/NexusManagerContract.php`
- Modify `System/Services/NexusManager.php`
- Modify `extension.json`
- Modify `extension.manifest.json`
- Modify `README.md`

**Interfaces:**
- `health(): array` reports `domain-core` and version `0.2.0`.
- `newDraft(BusinessProfile, TraceContext, string $compilationUuid): NexusCompilation` constructs domain state only; it does not provision or call other engines.

- [ ] Add unit assertions for manager draft construction.
- [ ] Implement manager method and metadata changes.
- [ ] Remove unimplemented provisioning capability claims; retain only capabilities actually backed by Pass 1.
- [ ] Run standalone tests, JSON validation, and PHP syntax checks.

### Task 5: Package verification

**Files:**
- Update `README.md` verification notes.
- Package entire `TitanNexus/` directory.

- [ ] Run standalone domain harness.
- [ ] Lint every PHP file.
- [ ] Parse all JSON manifests.
- [ ] Scan archive for duplicate entries, path traversal, unexpected binaries, and forbidden executable calls.
- [ ] Create versioned ZIP and calculate SHA-256.
