<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('interaction_runs') || Schema::hasColumn('interaction_runs', 'tenant_id')) {
            return;
        }

        Schema::table('interaction_runs', function (Blueprint $table): void {
            // Nullable for the compatibility transition. New authenticated HTTP runs always set it.
            $table->string('tenant_id', 191)->nullable()->after('id');
            $table->index(['tenant_id', 'user_id', 'interaction_id'], 'interaction_runs_tenant_user_interaction_idx');
        });
    }

    public function down(): void
    {
        // Forward-only: tenant ownership metadata is never removed automatically.
    }
};
