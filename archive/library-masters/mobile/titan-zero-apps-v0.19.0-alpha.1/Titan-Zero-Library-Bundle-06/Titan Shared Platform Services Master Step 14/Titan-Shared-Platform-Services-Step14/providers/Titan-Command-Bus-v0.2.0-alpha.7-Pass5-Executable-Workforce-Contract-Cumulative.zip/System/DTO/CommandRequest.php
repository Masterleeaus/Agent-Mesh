<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\DTO;

final readonly class CommandRequest
{
    public function __construct(
        public string $capability,
        public array $payload,
        public string $idempotencyKey,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $rootCausationId,
        public int|string|null $expectedEntityVersion = null,
        public bool $preparedOffline = false,
    ) {
        foreach (['capability' => $capability, 'idempotency_key' => $idempotencyKey, 'trace_id' => $traceId, 'correlation_id' => $correlationId, 'causation_id' => $causationId, 'root_causation_id' => $rootCausationId] as $field => $value) {
            if ($value === '') {
                throw new \InvalidArgumentException($field . ' is required.');
            }
        }
        if (preg_match('/^[a-z0-9]+(?:[._-][a-z0-9]+)*$/', $capability) !== 1) {
            throw new \InvalidArgumentException('capability must use the canonical lowercase Titan capability key format.');
        }
        if (strlen($idempotencyKey) > 191) {
            throw new \InvalidArgumentException('idempotency_key exceeds the 191-byte persistence limit.');
        }
        foreach (['trace_id' => $traceId, 'correlation_id' => $correlationId, 'causation_id' => $causationId, 'root_causation_id' => $rootCausationId] as $field => $value) {
            if (strlen($value) > 191) {
                throw new \InvalidArgumentException($field . ' exceeds the 191-byte persistence limit.');
            }
        }
    }

    public function toArray(): array
    {
        return [
            'capability' => $this->capability,
            'payload' => $this->payload,
            'idempotency_key' => $this->idempotencyKey,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
            'expected_entity_version' => $this->expectedEntityVersion,
            'prepared_offline' => $this->preparedOffline,
        ];
    }

    public function requestHash(): string
    {
        $data = $this->toArray();
        unset($data['trace_id'], $data['correlation_id'], $data['causation_id'], $data['root_causation_id']);
        return hash('sha256', json_encode(self::canonicalize($data), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }

    private static function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }
        if (array_is_list($value)) {
            return array_map(self::canonicalize(...), $value);
        }
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) {
            $value[$key] = self::canonicalize($item);
        }
        return $value;
    }
}
