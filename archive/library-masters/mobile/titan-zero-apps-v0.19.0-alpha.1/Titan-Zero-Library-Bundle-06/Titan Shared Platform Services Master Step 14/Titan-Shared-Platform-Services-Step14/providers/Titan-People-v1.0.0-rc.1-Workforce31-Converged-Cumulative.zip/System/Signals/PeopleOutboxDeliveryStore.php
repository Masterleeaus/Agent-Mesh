<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Signals;

interface PeopleOutboxDeliveryStore
{
    /** @return list<PeopleOutboxEvent> */
    public function pending(int $limit): array;
    public function markPublished(int $tenantCompanyId, string $eventId, string $receiptId): void;
    public function markFailed(int $tenantCompanyId, string $eventId, string $error): void;
}
