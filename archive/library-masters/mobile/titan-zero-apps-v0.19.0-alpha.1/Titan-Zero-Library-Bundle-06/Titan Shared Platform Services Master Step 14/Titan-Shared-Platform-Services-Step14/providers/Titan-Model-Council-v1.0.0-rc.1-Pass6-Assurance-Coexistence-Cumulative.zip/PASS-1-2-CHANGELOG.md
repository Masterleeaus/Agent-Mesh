# Titan Model Council v0.3.0 — Pass 1 + Pass 2

## Pass 1 — safety and compatibility hardening

- Replaced the unsafe legacy response-acceptance path with a hardened Titan controller.
- Message lookup is scoped to the authenticated user before any mutation occurs.
- Foreign-owned message IDs return the same 404 as missing IDs to avoid object disclosure.
- `shared_uuid = null` or blank now results in zero sibling deletions.
- Sibling deletion is constrained by `user_id`, `user_openai_chat_id`, and `shared_uuid`.
- Acceptance runs in a database transaction and locks the selected row.
- Repeated acceptance is idempotent once the accepted message has no shared UUID.
- Legacy `/dashboard/user/multimodel/accept-response` compatibility is only registered when AI Chat Pro is present and neither the original Model Council nor Multi-Model already owns that surface.

## Pass 2 — active legacy engine absorption

- The complete working legacy `ModelCouncilService` is now active under the Titan namespace at `System/Compatibility/Legacy/Services/ModelCouncilService.php`.
- The legacy response model is namespaced under Titan and backed by the preserved `model_council_responses` table.
- Old `App\\Extensions\\ModelCouncil` service/model/controller names are provided by safe runtime aliases when the original extension is not registered.
- Legacy views/translations are loaded under the historical `model-council` namespace for compatibility.
- The legacy engine recognizes both `titan-model-council` and the historical `model-council` registration key during staged migration.
- `CouncilGateway` now reports `compatibility-ready` and truthfully exposes only the currently active `parallel_consensus` strategy.
- The manifest now declares the active compatibility table, shared chat-message table, and current provider hosts.
- Queue usage is no longer advertised until governed queued deliberation is actually implemented.
- A forward migration adds `causation_id` to Titan Council decision records.

## Still intentionally deferred

- Direct provider execution remains inside the compatibility engine until Titan AI Core runtime contracts are wired.
- Governed proposer/critic/verifier/arbiter mode is not yet advertised as active.
- Risk, Assurance, Signal, Shield, Rewind, Knowledge Authority and Governance adapters are the next integration pass.
- Legacy credit authorization remains post-execution and should move to reservation/settlement semantics later.
