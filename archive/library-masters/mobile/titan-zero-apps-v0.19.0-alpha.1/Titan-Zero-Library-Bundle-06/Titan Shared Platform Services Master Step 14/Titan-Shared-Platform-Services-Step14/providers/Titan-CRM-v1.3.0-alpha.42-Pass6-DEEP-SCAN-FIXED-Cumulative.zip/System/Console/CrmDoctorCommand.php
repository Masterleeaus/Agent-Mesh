<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\Services\{CrmOperationalMetricsService,CrmProductionHealthService};
use Illuminate\Console\Command;

final class CrmDoctorCommand extends Command
{
    protected $signature='crm:doctor {--tenant= : Optional company_id for metric scoping} {--json : Emit machine-readable diagnostics}';
    protected $description='Diagnose Titan CRM reliability problems and print remediation/runbook guidance.';

    public function handle(CrmProductionHealthService $health,CrmOperationalMetricsService $metrics): int
    {
        $result=$health->inspect();$tenant=$this->option('tenant');$tenant=$tenant!==null&&$tenant!==''?(int)$tenant:null;
        $diagnostic=['severity'=>$result['severity']??'WARN','status'=>$result['status'],'blockers'=>$result['blockers'],'warnings'=>$result['warnings'],'metrics'=>$metrics->collect($tenant),'remediation'=>$this->remediation($result),'runbook'=>'docs/CRM-OPERATIONS-RUNBOOK.md'];
        if($this->option('json')){$this->line((string)json_encode($diagnostic,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));}
        else{
            $severity=(string)$diagnostic['severity'];$line='Titan CRM doctor: '.$severity;if($severity==='BLOCK')$this->error($line);elseif($severity==='WARN')$this->warn($line);else$this->info($line);
            foreach($diagnostic['remediation'] as $item)$this->line(' - '.$item);
            $this->line('Runbook: '.$diagnostic['runbook']);
        }
        return ($result['status']??'blocked')==='blocked'?self::FAILURE:self::SUCCESS;
    }

    /** @return list<string> */
    private function remediation(array $health): array
    {
        $items=[];$messages=array_merge((array)($health['blockers']??[]),(array)($health['warnings']??[]));
        foreach($messages as $message){$m=strtolower((string)$message);$hint=match(true){
            str_contains($m,'signal')=>'Inspect crm_domain_signal_outbox; run crm:signals:deliver after restoring Titan Signal.',
            str_contains($m,'projection')=>'Inspect projection state/dead letters; run crm:projections:dead-letters and crm:projections:rebuild.',
            str_contains($m,'webhook')=>'Inspect webhook dead letters; retry only after endpoint/signing issues are corrected.',
            str_contains($m,'scanner')||str_contains($m,'quarant')=>'Restore the malware scanner; keep files quarantined until a clean scan releases them.',
            str_contains($m,'command bus')=>'Restore Titan Command Bus binding; do not enable legacy local mutation fallback.',
            str_contains($m,'connect')||str_contains($m,'communication')=>'Restore Titan Connect and then drain the outbound-effect queue.',
            str_contains($m,'import')=>'Review staged/failed import impact reports and rollback journal before retrying or rolling back.',
            str_contains($m,'render')=>'Inspect crm_sales_document_render_jobs and run crm:documents:render after fixing renderer/storage.',
            default=>'Review crm:production-check --json and the operations runbook for the failing check.',
        };if(!in_array($hint,$items,true))$items[]=$hint;}
        if($items===[])$items[]='PASS: no remediation required. Continue normal monitoring.';
        return $items;
    }
}
