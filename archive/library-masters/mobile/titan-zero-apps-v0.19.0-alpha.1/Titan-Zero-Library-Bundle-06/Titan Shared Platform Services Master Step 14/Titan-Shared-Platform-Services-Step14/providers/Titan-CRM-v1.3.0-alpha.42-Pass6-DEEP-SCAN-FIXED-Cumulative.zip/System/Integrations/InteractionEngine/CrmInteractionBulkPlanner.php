<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\InteractionEngine;

use App\Extensions\Crm\System\Services\CrmBulkActionService;
use App\Extensions\Crm\System\Tenancy\CrmCompanyContext;
use Illuminate\Validation\ValidationException;

/** Preview-first conversational bulk actions; database mutation stays in CrmBulkActionService. */
final class CrmInteractionBulkPlanner
{
    public function __construct(private CrmBulkActionService $bulk) {}

    /** @return array<string,mixed> */
    public function preview(CrmCompanyContext $context, string $resource, string $action, array $ids, array $arguments = []): array
    {
        $preview = $this->bulk->preview($context->companyId, $resource, $action, $ids, $arguments);
        return $preview + [
            'status' => 'preview',
            'requires_confirmation' => true,
            'authority' => 'human_confirmation',
        ];
    }

    /** @return array<string,mixed> */
    public function execute(CrmCompanyContext $context, string $resource, string $action, array $ids, array $arguments = [], bool $confirmed = false): array
    {
        if (! $confirmed) {
            throw ValidationException::withMessages(['confirmed' => ['Bulk execution requires an explicit confirmed selection.']]);
        }
        if ($context->actorUserId === null) {
            throw ValidationException::withMessages(['actor' => ['Bulk execution requires an authenticated CRM actor.']]);
        }

        // Re-validate the exact selection immediately before mutation to prevent
        // a stale preview from expanding or crossing the tenant boundary.
        $preview = $this->bulk->preview($context->companyId, $resource, $action, $ids, $arguments);
        $result = $this->bulk->execute($context->companyId, $context->actorUserId, $resource, $action, $preview['public_ids'], $arguments);

        return ['status' => 'completed', 'preview' => $preview, 'result' => $result];
    }
}
