# Failure Modes

| Failure | Behaviour |
|---|---|
| Required Signal unavailable | readiness/certification fail; no false healthy state |
| Provider timeout/rate limit | bounded retry/fallback; circuit breaker records failure |
| Quorum unavailable | fail/escalate; never fabricate consensus |
| Strong contradiction | confidence constrained and escalation required for consequential work |
| Proposer/Critic/Verifier failure | governed arbitration stops |
| Shield pre-validation fail | Arbiter is not called |
| Arbiter empty/fails | final decision blocked |
| Risk BLOCK/REDUCE_AUTHORITY | preserved regardless of model agreement |
| Billing reservation failure | fail closed before provider execution |
| Persistence failure | reservation released where possible and terminal audit failure recorded |
