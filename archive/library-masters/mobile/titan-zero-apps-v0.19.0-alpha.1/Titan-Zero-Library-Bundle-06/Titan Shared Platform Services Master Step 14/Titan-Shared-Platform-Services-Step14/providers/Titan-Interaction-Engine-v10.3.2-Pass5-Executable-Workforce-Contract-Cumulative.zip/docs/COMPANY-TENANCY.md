# Company Tenancy

`company_id` is the sole Titan business tenant boundary. `actor_id` identifies the actor. `team_id`/`user_id` do not establish tenancy. Legacy `tenant_id` may mirror `company_id` temporarily for migration compatibility but mismatches are rejected.

Wizard sessions, plans, approvals, memory, caches, offline outboxes and provider execution all derive company scope from trusted server context.
