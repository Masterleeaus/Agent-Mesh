<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Persistence\Models\Concerns;

trait HasCanonicalCompanyIdCompatibility
{
    protected static function bootHasCanonicalCompanyIdCompatibility(): void
    {
        static::saving(function ($model): void {
            $companyId = $model->getAttribute('company_id') ?? $model->getAttribute('tenant_company_id');
            if ($companyId !== null) {
                $model->setAttribute('company_id', $companyId);
                $model->setAttribute('tenant_company_id', $companyId);
            }
        });
    }
}
