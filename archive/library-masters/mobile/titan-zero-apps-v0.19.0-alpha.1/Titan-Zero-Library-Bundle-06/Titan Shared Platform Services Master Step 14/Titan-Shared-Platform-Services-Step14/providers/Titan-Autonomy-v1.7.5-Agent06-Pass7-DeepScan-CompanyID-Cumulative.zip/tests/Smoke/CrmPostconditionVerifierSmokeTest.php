<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\Contracts\TenantRecordLookupContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\GovernedCapabilityCommand;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\RiskClass;
use App\Extensions\TitanAutonomy\System\Services\CrmExecutionPostconditionVerifier;

$lookup = new class implements TenantRecordLookupContract {
    public array $rows = [];
    public function find(string $table, int $tenantCompanyId, string $publicId): ?array {
        return $this->rows[$table . ':' . $tenantCompanyId . ':' . $publicId] ?? null;
    }
};
$lookup->rows['crm_invoices:42:INV1'] = ['public_id'=>'INV1','tenant_company_id'=>42,'status'=>'issued','total_minor'=>50000,'contact_public_id'=>'C1'];
$verifier = new CrmExecutionPostconditionVerifier($lookup);
$state = new CapabilityState(42,'crm.invoice.issue','completed_job_invoice',RiskClass::Medium,AutonomyLevel::Auto,2);
$command = new GovernedCapabilityCommand('crm.invoice.issue',['total_minor'=>50000,'contact_public_id'=>'C1'],'completed_job_invoice','corr-1',null,'sess-1','idem-1',true);
$result = ['status'=>'executed','data'=>['status'=>'ok','result'=>['public_id'=>'INV1','status'=>'issued','total_minor'=>50000,'contact_public_id'=>'C1']]];
$ok = $verifier->verify($state,$command,$result,[]);
if (($ok['status'] ?? null) !== 'verified') throw new RuntimeException('Matching persisted invoice postcondition must verify.');

$lookup->rows['crm_invoices:42:INV1']['total_minor'] = 72000;
$bad = $verifier->verify($state,$command,$result,[]);
if (($bad['status'] ?? null) !== 'failed' || !in_array('MATERIAL_FIELD_MISMATCH:total_minor',(array)($bad['reason_codes']??[]),true)) {
    throw new RuntimeException('Material persisted-field mismatch must fail deterministic postcondition verification.');
}

echo "OK: CrmPostconditionVerifierSmokeTest\n";
