@extends('panel.layout.app')

@section('content')
<div class="container-fluid py-4">
    <div class="mb-4">
        <h1 class="h3 mb-1">Titan Command Bus</h1>
        <p class="text-muted mb-0">Governed execution spine and deterministic mutation boundary.</p>
    </div>
    <div class="row g-3">
        <div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Operational status</div><div class="h4 mb-0">{{ $health['operational_status'] ?? 'UNKNOWN' }}</div></div></div></div>
        <div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Readiness</div><div class="h4 mb-0">{{ !empty($health['readiness']) ? 'Ready' : 'Blocked' }}</div></div></div></div>
        <div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Registered adapters</div><div class="h4 mb-0">{{ $health['registered_adapters'] ?? 0 }}</div></div></div></div>
        <div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Kill switch</div><div class="h4 mb-0">{{ !empty($health['kill_switch']) ? 'ON' : 'OFF' }}</div></div></div></div>
    </div>
    <div class="card mt-4"><div class="card-body"><h2 class="h5">Dependencies</h2><pre class="mb-0">{{ json_encode($health['dependencies'] ?? [], JSON_PRETTY_PRINT) }}</pre></div></div>
</div>
@endsection
