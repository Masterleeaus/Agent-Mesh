<?php
declare(strict_types=1);

$GLOBALS['tcb_test_config'] = [
    'titan-command-bus.enabled' => true,
    'titan-command-bus.kill_switch' => false,
    'titan-command-bus.max_payload_bytes' => 65536,
    'titan-command-bus.allow_offline_revalidation' => true,
    'titan-command-bus.require_signal' => true,
    'titan-command-bus.require_risk' => true,
    'titan-command-bus.require_assurance' => true,
    'titan-command-bus.require_autonomy' => false,
    'titan-command-bus.require_lifecycle' => true,
];
if (!function_exists('config')) {
    function config(string $key, mixed $default = null): mixed { return $GLOBALS['tcb_test_config'][$key] ?? $default; }
}

$root=dirname(__DIR__,2);
foreach ([
    'System/DTO/CommandContext.php','System/DTO/CommandRequest.php','System/DTO/RiskDecision.php','System/DTO/AssuranceDecision.php','System/DTO/GovernanceDecision.php','System/DTO/CommandExecutionResult.php','System/DTO/CommandReceipt.php',
    'System/Contracts/CommandAdapterContract.php','System/Contracts/CommandAdapterRegistryContract.php','System/Contracts/CommandRiskGateContract.php','System/Contracts/CommandAssuranceGateContract.php','System/Contracts/CommandGovernanceGateContract.php','System/Contracts/CommandReceiptStoreContract.php','System/Contracts/CommandSignalEmitterContract.php','System/Contracts/CommandBusContract.php',
    'System/Contracts/CommandLifecycleStoreContract.php','System/Services/CommandLifecycleState.php','System/Services/CommandBus.php',
] as $rel) require_once $root.'/'.$rel;

use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterRegistryContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAssuranceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandGovernanceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandLifecycleStoreContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandReceiptStoreContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandRiskGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandSignalEmitterContract;
use App\Extensions\TitanCommandBus\System\DTO\AssuranceDecision;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandExecutionResult;
use App\Extensions\TitanCommandBus\System\DTO\CommandReceipt;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use App\Extensions\TitanCommandBus\System\DTO\GovernanceDecision;
use App\Extensions\TitanCommandBus\System\DTO\RiskDecision;
use App\Extensions\TitanCommandBus\System\Services\CommandBus;
use App\Extensions\TitanCommandBus\System\Services\CommandLifecycleState;

final class LifecycleAdapter implements CommandAdapterContract {
    public int $calls=0;
    public bool $throw=false;
    public function capability(): string { return 'crm.invoice.create'; }
    public function execute(CommandContext $context, CommandRequest $request, string $operationId): CommandExecutionResult {
        $this->calls++;
        if ($this->throw) throw new RuntimeException('provider secret should never be persisted');
        return new CommandExecutionResult('crm:invoice:88', true, 88, 'invoice', 2);
    }
}
final class LifecycleRegistry implements CommandAdapterRegistryContract {
    public function __construct(public LifecycleAdapter $adapter) {}
    public function register(CommandAdapterContract $adapter): void {}
    public function has(string $capability): bool { return $capability===$this->adapter->capability(); }
    public function forCapability(string $capability): ?CommandAdapterContract { return $this->has($capability)?$this->adapter:null; }
    public function count(): int { return 1; }
}
final class LifecycleRisk implements CommandRiskGateContract {
    public function available(): bool { return true; }
    public function assess(CommandContext $context, CommandRequest $request): RiskDecision { return new RiskDecision(true,'risk:lifecycle','LOW',0.1); }
}
final class LifecycleAssurance implements CommandAssuranceGateContract {
    public function available(): bool { return true; }
    public function assess(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null): AssuranceDecision { return new AssuranceDecision(true,'assurance:lifecycle','POLICY',['evidence:lifecycle']); }
}
final class LifecycleGovernance implements CommandGovernanceGateContract {
    public function available(): bool { return true; }
    public function evaluate(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null, ?AssuranceDecision $assurance = null, ?\App\Extensions\TitanCommandBus\System\DTO\AutonomyDecision $autonomy = null): GovernanceDecision { return new GovernanceDecision(true,'gov:lifecycle','LOW',null,false); }
}
final class LifecycleReceiptStore implements CommandReceiptStoreContract {
    public array $claims=[];
    private function key(CommandContext $c, CommandRequest $r): string { return $c->tenantCompanyId.'|'.$r->idempotencyKey; }
    public function existing(CommandContext $context, CommandRequest $request): ?array { return $this->claims[$this->key($context,$request)] ?? null; }
    public function claim(CommandContext $context, CommandRequest $request, string $operationId, string $requestHash): bool {
        $k=$this->key($context,$request); if(isset($this->claims[$k])) return false;
        $this->claims[$k]=['request_hash'=>$requestHash,'operation_id'=>$operationId,'status'=>'processing','receipt'=>null]; return true;
    }
    public function complete(CommandReceipt $receipt): void {
        $k=$receipt->tenantCompanyId.'|'.$receipt->idempotencyKey;
        $this->claims[$k]['status']=$receipt->status; $this->claims[$k]['receipt']=$receipt->toArray();
    }
    public function health(): array { return ['receipts_table'=>true,'idempotency_table'=>true]; }
}
final class LifecycleSignals implements CommandSignalEmitterContract {
    public function available(): bool { return true; }
    public function emit(string $type, array $payload): void {}
}
final class MemoryLifecycle implements CommandLifecycleStoreContract {
    public array $events=[];
    public bool $isAvailable=true;
    public function available(): bool { return $this->isAvailable; }
    public function begin(CommandContext $context, CommandRequest $request, string $operationId, string $requestHash): void { $this->events[]=['state'=>CommandLifecycleState::RECEIVED,'mutates'=>true]; }
    public function transition(CommandContext $context, CommandRequest $request, string $operationId, string $state, ?string $reasonCode = null, array $evidence = []): void { $this->events[]=['state'=>$state,'reason'=>$reasonCode,'mutates'=>true,'evidence'=>$evidence]; }
    public function observe(CommandContext $context, CommandRequest $request, string $operationId, string $state, ?string $reasonCode = null, array $evidence = []): void { $this->events[]=['state'=>$state,'reason'=>$reasonCode,'mutates'=>false,'evidence'=>$evidence]; }
    public function health(): array { return ['commands_table'=>true,'attempts_table'=>true]; }
}

$ctx=new CommandContext(42,'human',7,'titan-command');
$req=new CommandRequest('crm.invoice.create',['amount'=>100],'idem-life','trace','corr','cause','root');
$adapter=new LifecycleAdapter(); $registry=new LifecycleRegistry($adapter); $store=new LifecycleReceiptStore(); $lifecycle=new MemoryLifecycle();
$bus=new CommandBus($registry,new LifecycleRisk(),new LifecycleAssurance(),new LifecycleGovernance(),$store,new LifecycleSignals(),null,null,$lifecycle);
$r=$bus->dispatch($ctx,$req);
if($r->status!=='applied') throw new RuntimeException('expected applied command');
$states=array_column($lifecycle->events,'state');
$expected=[CommandLifecycleState::RECEIVED,CommandLifecycleState::PREFLIGHT,CommandLifecycleState::GOVERNED,CommandLifecycleState::AUTHORIZED,CommandLifecycleState::EXECUTING,CommandLifecycleState::COMPLETED];
if($states!==$expected) throw new RuntimeException('unexpected lifecycle: '.json_encode($states));

$replay=$bus->dispatch($ctx,$req);
if($replay->status!=='already_applied') throw new RuntimeException('expected replay');
$last=$lifecycle->events[array_key_last($lifecycle->events)];
if($last['state']!==CommandLifecycleState::REPLAYED || $last['mutates']!==false) throw new RuntimeException('replay must be an observation');
if($adapter->calls!==1) throw new RuntimeException('replay executed adapter twice');

$failReq=new CommandRequest('crm.invoice.create',['amount'=>200],'idem-fail','trace-f','corr-f','cause-f','root-f');
$adapter->throw=true; $lifecycle2=new MemoryLifecycle(); $store2=new LifecycleReceiptStore();
$bus2=new CommandBus($registry,new LifecycleRisk(),new LifecycleAssurance(),new LifecycleGovernance(),$store2,new LifecycleSignals(),null,null,$lifecycle2);
$failed=$bus2->dispatch($ctx,$failReq);
if($failed->status!=='failed') throw new RuntimeException('expected failed command');
$failedStates=array_column($lifecycle2->events,'state');
if(end($failedStates)!==CommandLifecycleState::FAILED) throw new RuntimeException('failed command must terminate FAILED');
$failedEvent=$lifecycle2->events[array_key_last($lifecycle2->events)];
if(isset($failedEvent['evidence']['exception']) || str_contains(json_encode($failedEvent), 'provider secret')) throw new RuntimeException('exception detail leaked to lifecycle');

$lifecycle3=new MemoryLifecycle(); $lifecycle3->isAvailable=false; $store3=new LifecycleReceiptStore(); $adapter->throw=false;
$unavailableReq=new CommandRequest('crm.invoice.create',['amount'=>300],'idem-unavailable','trace-u','corr-u','cause-u','root-u');
$bus3=new CommandBus($registry,new LifecycleRisk(),new LifecycleAssurance(),new LifecycleGovernance(),$store3,new LifecycleSignals(),null,null,$lifecycle3);
$blocked=$bus3->dispatch($ctx,$unavailableReq);
if($blocked->status!=='blocked'||$blocked->reasonCode!=='LIFECYCLE_UNAVAILABLE'||$adapter->calls!==2) throw new RuntimeException('lifecycle must fail closed before new adapter execution');
$blockedReplay=$bus3->dispatch($ctx,$unavailableReq);
if($blockedReplay->status!=='blocked'||$blockedReplay->reasonCode!=='LIFECYCLE_UNAVAILABLE'||!$blockedReplay->replayed||$adapter->calls!==2) throw new RuntimeException('blocked command replay must not masquerade as applied');

echo "PASS DurableLifecycleTest\n";
