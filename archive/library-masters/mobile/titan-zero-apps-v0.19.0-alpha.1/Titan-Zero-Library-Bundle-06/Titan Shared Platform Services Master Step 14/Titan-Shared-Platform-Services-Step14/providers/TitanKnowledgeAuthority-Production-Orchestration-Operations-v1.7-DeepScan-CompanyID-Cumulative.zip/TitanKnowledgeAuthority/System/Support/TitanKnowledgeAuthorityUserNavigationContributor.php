<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Support;

final class TitanKnowledgeAuthorityUserNavigationContributor
{
    /** @return array<int, array<string, mixed>> */
    public function __invoke(): array
    {
        return TitanKnowledgeAuthorityNavigation::user();
    }

    /** @return array<int, array<string, mixed>> */
    public function items(): array
    {
        return TitanKnowledgeAuthorityNavigation::user();
    }

    /** @return array<int, array<string, mixed>> */
    public function definitions(): array
    {
        return TitanKnowledgeAuthorityNavigation::user();
    }
}
