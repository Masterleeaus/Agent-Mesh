@extends('panel.layout.app')
@section('title', __('CRM · Chatbot Integration'))
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Chatbot Integration','subtitle'=>'Connect CRM context and actions to Titan conversational surfaces.','surface'=>'automate'] )
<div class="container-xl py-6">
    <div class="mb-6">
        
        <p class="text-muted">{{ __('Expose customer-safe CRM tools to selected MagicAI chatbots without modifying the Chatbot extension.') }}</p>
    </div>

    @if(!$installed)
        <div class="alert alert-warning">{{ __('The Chatbot extension is not installed. CRM continues to work normally.') }}</div>
    @elseif(!$supported)
        <div class="alert alert-warning">{{ __('Chatbot version :version is not certified for this CRM bridge. Tool injection is disabled until compatibility is reviewed.', ['version'=>$version]) }}</div>
    @endif

    @forelse($chatbots as $chatbot)
        @php($s=$chatbot['settings'])
        @php($selectedTools=(array)($s['allowed_tools'] ?? $tools))
        <form method="POST" action="{{ route('dashboard.user.crm.chatbot-integration.update') }}" class="card mb-4 p-5">
            @csrf
            <input type="hidden" name="chatbot_id" value="{{ $chatbot['id'] }}">

            <div class="flex items-center justify-between gap-4">
                <div>
                    <strong>{{ $chatbot['name'] }}</strong>
                    <div class="text-xs text-muted">{{ $chatbot['uuid'] }}</div>
                </div>
                <label><input type="checkbox" name="enabled" value="1" @checked($s['enabled']??false)> {{ __('Enable CRM tools') }}</label>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
                @foreach([
                    'capture_contacts'=>'Capture contacts',
                    'create_lead_on_capture'=>'Create lead on capture',
                    'record_activity'=>'Record CRM activity',
                    'allow_financial_reads'=>'Allow customer financial reads',
                    'require_verified_financial_identity'=>'Require current verified Titan Customer session for financial reads',
                ] as $key=>$label)
                    <label><input type="checkbox" name="{{ $key }}" value="1" @checked($s[$key]??false)> {{ __($label) }}</label>
                @endforeach
            </div>

            <div class="mt-5">
                <h3 class="font-medium">{{ __('Available customer-safe CRM tools') }}</h3>
                <p class="text-sm text-muted mb-3">{{ __('Uncheck every tool to disable tool exposure while leaving contact/activity capture enabled.') }}</p>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                    @foreach($tools as $tool)
                        <label class="rounded border p-3">
                            <input type="checkbox" name="allowed_tools[]" value="{{ $tool }}" @checked(in_array($tool,$selectedTools,true))>
                            <code>{{ $tool }}</code>
                        </label>
                    @endforeach
                </div>
            </div>

            <div class="mt-5 rounded border p-4 text-sm text-muted">
                {{ __('Private CRM reads and profile changes require a short-lived verification grant issued from a currently authenticated Titan Customer session. A matched email or phone number alone never grants private CRM access.') }}
            </div>

            <button class="btn btn-primary mt-5" type="submit">{{ __('Save CRM integration') }}</button>
        </form>
    @empty
        @if($installed)<div class="alert alert-info">{{ __('No chatbots were found for this account.') }}</div>@endif
    @endforelse
</div>
@endcomponent
@endsection
