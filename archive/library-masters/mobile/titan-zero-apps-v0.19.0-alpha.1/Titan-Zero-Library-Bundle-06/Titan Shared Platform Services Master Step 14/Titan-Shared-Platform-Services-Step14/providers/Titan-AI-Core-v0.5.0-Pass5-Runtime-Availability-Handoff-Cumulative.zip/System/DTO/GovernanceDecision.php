<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\DTO;

final readonly class GovernanceDecision
{
    public function __construct(
        public string $engine,
        public string $outcome,
        public string $reasonCode,
        public string $message,
        public array $evidenceRefs = [],
    ) {}

    public static function allow(string $engine, string $reasonCode, string $message, array $evidenceRefs = []): self
    {
        return new self($engine, 'ALLOW', $reasonCode, $message, $evidenceRefs);
    }

    public static function deny(string $engine, string $reasonCode, string $message, array $evidenceRefs = []): self
    {
        return new self($engine, 'DENY', $reasonCode, $message, $evidenceRefs);
    }

    public static function requireApproval(string $engine, string $reasonCode, string $message, array $evidenceRefs = []): self
    {
        return new self($engine, 'REQUIRE_APPROVAL', $reasonCode, $message, $evidenceRefs);
    }

    public static function requireEvidence(string $engine, string $reasonCode, string $message, array $evidenceRefs = []): self
    {
        return new self($engine, 'REQUIRE_EVIDENCE', $reasonCode, $message, $evidenceRefs);
    }

    public static function defer(string $engine, string $reasonCode, string $message, array $evidenceRefs = []): self
    {
        return new self($engine, 'DEFER', $reasonCode, $message, $evidenceRefs);
    }

    public function allowsExecution(): bool
    {
        return $this->outcome === 'ALLOW';
    }

    public function requiresHumanReview(): bool
    {
        return in_array($this->outcome, ['DENY', 'REQUIRE_APPROVAL', 'REQUIRE_EVIDENCE', 'DEFER'], true);
    }

    public function toArray(): array
    {
        return [
            'engine' => $this->engine,
            'outcome' => $this->outcome,
            'reason_code' => $this->reasonCode,
            'message' => $this->message,
            'evidence_refs' => $this->evidenceRefs,
        ];
    }
}
