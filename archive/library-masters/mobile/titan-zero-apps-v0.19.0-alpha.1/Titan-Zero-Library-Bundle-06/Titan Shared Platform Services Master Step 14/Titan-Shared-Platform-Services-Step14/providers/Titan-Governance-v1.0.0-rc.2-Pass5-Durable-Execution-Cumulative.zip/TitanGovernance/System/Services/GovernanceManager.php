<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Services;

use App\Extensions\TitanGovernance\System\Actions\GovernanceActionRequest;
use App\Extensions\TitanGovernance\System\Actions\GovernanceActionService;
use App\Extensions\TitanGovernance\System\Contracts\ExtensionHealth;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceEscalationStoreContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceManagerContract;
use App\Extensions\TitanGovernance\System\ControlCentre\GovernanceControlCentre;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceDecisionIntelligence;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceDeltaViewer;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernancePolicyComplianceProjector;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceRewindTheater;
use App\Extensions\TitanGovernance\System\Projection\GovernanceProjectionService;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceReadPlane;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceSignalIntelligence;

final class GovernanceManager implements GovernanceManagerContract
{
    public function __construct(
        private readonly ExtensionHealth $health,
        private readonly GovernanceAuthorityConstraintFactory $constraints,
        private readonly GovernanceReadPlane $readPlane,
        private readonly GovernanceSignalIntelligence $signalIntelligence,
        private readonly GovernanceProjectionService $projections,
        private readonly GovernanceEscalationStoreContract $escalations,
        private readonly GovernanceActionService $actions,
        private readonly GovernanceDecisionIntelligence $decisionIntelligence,
        private readonly GovernanceDeltaViewer $deltaViewer,
        private readonly GovernancePolicyComplianceProjector $policyCompliance,
        private readonly GovernanceRewindTheater $rewind,
        private readonly GovernanceControlCentre $controlCentre,
    ) {}

    public function health(): array { return $this->health->snapshot(); }

    public function dashboardSnapshot(int $tenantCompanyId, array $context = []): array
    {
        $trustMap=$this->readPlane->trustMap($tenantCompanyId,$context);
        $sourceHealth=$this->readPlane->sourceHealth($tenantCompanyId,$context);
        $autonomyEvidence=$this->readPlane->autonomyEvidence($tenantCompanyId,$context);
        $signal=$this->signalIntelligence->snapshot($tenantCompanyId,$context);
        $projection=$this->projections->persist($tenantCompanyId,$trustMap,$autonomyEvidence,$sourceHealth,$signal);

        return [
            'schema_version'=>'1.1','tenant_company_id'=>$tenantCompanyId,'trust_map'=>$trustMap,'source_health'=>$sourceHealth,
            'autonomy_evidence'=>$autonomyEvidence,'signal_intelligence'=>$signal,'projection'=>$projection,
            'escalation_queue'=>$this->escalationQueue($tenantCompanyId,50),'recent_decisions'=>$this->recentDecisions($tenantCompanyId,25),
            'control_centre'=>$this->controlCentre($tenantCompanyId,$context),
        ];
    }

    public function trustMap(int $tenantCompanyId, array $context = []): array { return $this->readPlane->trustMap($tenantCompanyId, $context); }
    public function sourceHealth(int $tenantCompanyId, array $context = []): array { return $this->readPlane->sourceHealth($tenantCompanyId, $context); }
    public function autonomyEvidence(int $tenantCompanyId, array $context = []): array { return $this->readPlane->autonomyEvidence($tenantCompanyId, $context); }
    public function signalHeatmap(int $tenantCompanyId, array $context = []): array { return $this->signalIntelligence->snapshot($tenantCompanyId,$context)['heatmap']; }
    public function operationalPressure(int $tenantCompanyId, array $context = []): array { return $this->signalIntelligence->snapshot($tenantCompanyId,$context)['operational_pressure']; }
    public function circuitBreakers(int $tenantCompanyId, array $context = []): array { return $this->signalIntelligence->snapshot($tenantCompanyId,$context)['circuit_breakers']; }
    public function projectionHistory(int $tenantCompanyId, string $type, int $limit = 50): array { return $this->projections->history($tenantCompanyId,$type,$limit); }
    public function escalationQueue(int $tenantCompanyId, int $limit = 50): array { return $this->escalations->queue($tenantCompanyId,$limit); }
    public function performEscalationAction(GovernanceActionRequest $request): array { return $this->actions->execute($request); }
    public function recentDecisions(int $tenantCompanyId,int $limit=25):array{return $this->decisionIntelligence->recent($tenantCompanyId,$limit);}
    public function decisionTimeline(int $tenantCompanyId,string $decisionId,array $context=[]):array{return $this->decisionIntelligence->inspect($tenantCompanyId,$decisionId,$context);}

    public function decisionDetail(int $tenantCompanyId,string $decisionId,array $context=[]):array
    {
        $inspection=$this->decisionIntelligence->inspect($tenantCompanyId,$decisionId,$context);
        return [
            'schema_version'=>'1.0','status'=>$inspection['status']??'UNAVAILABLE','inspection'=>$inspection,
            'compliance'=>$this->policyCompliance->project($inspection,$context),'rewind'=>$this->rewind->project($inspection),
        ];
    }

    public function decisionDelta(int $tenantCompanyId,string $leftDecisionId,string $rightDecisionId,array $context=[]):array
    {
        $left=$this->decisionIntelligence->inspect($tenantCompanyId,$leftDecisionId,$context);$right=$this->decisionIntelligence->inspect($tenantCompanyId,$rightDecisionId,$context);
        if(($left['status']??null)==='NOT_FOUND'||($right['status']??null)==='NOT_FOUND') return ['schema_version'=>'1.0','status'=>'NOT_FOUND','left_decision_id'=>$leftDecisionId,'right_decision_id'=>$rightDecisionId,'delta'=>null];
        return ['schema_version'=>'1.0','status'=>'HEALTHY','left_decision_id'=>$leftDecisionId,'right_decision_id'=>$rightDecisionId,'delta'=>$this->deltaViewer->compare((array)$left['decision'],(array)$right['decision'])];
    }

    public function decisionCompliance(int $tenantCompanyId,string $decisionId,array $context=[]):array{return $this->policyCompliance->project($this->decisionIntelligence->inspect($tenantCompanyId,$decisionId,$context),$context);}
    public function rewindTheater(int $tenantCompanyId,string $decisionId,array $context=[]):array{return $this->rewind->project($this->decisionIntelligence->inspect($tenantCompanyId,$decisionId,$context));}
    public function controlCentre(int $tenantCompanyId,array $context=[]):array
    {
        $context += [
            'fresh_after_seconds'=>(int)config('titan-governance.control_centre_fresh_after_seconds',300),
            'exception_expiring_seconds'=>(int)config('titan-governance.control_centre_exception_expiring_seconds',86400),
            'approval_warning_seconds'=>(int)config('titan-governance.workforce_approval_warning_seconds',3600),
            'approval_critical_seconds'=>(int)config('titan-governance.workforce_approval_critical_seconds',14400),
        ];
        return $this->controlCentre->snapshot($tenantCompanyId,$context);
    }

    public function workforceOversight(int $tenantCompanyId,array $context=[]):array
    {
        $snapshot=$this->controlCentre($tenantCompanyId,$context);
        $items=array_values(array_filter($snapshot['needs_attention']['items']??[],static fn(array $row):bool=>str_starts_with((string)($row['type']??''),'workforce_')));
        return ['schema_version'=>'1.0','status'=>$snapshot['workforce_oversight']['status']??'NOT_INSTALLED','tenant_company_id'=>$tenantCompanyId,'workforce'=>$snapshot['workforce_oversight']??[],'human'=>$snapshot['human_oversight']??[],'needs_attention'=>$items,'observed_at'=>$snapshot['observed_at']??null];
    }

    public function humanOversight(int $tenantCompanyId,array $context=[]):array
    {
        return $this->workforceOversight($tenantCompanyId,$context)['human'];
    }

    public function authorityConstraint(array $autonomyKey, string $disposition, ?float $ceilingScore, array $reasonCodes, array $evidenceRefs, string $policyVersion, string $traceId): array
    {
        return $this->constraints->make($autonomyKey, $disposition, $ceilingScore, $reasonCodes, $evidenceRefs, $policyVersion, $traceId);
    }
}
