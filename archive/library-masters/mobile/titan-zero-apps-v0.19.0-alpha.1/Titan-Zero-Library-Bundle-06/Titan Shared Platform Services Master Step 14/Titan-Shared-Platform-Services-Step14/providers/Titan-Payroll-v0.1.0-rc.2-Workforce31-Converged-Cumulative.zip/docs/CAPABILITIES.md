# Capabilities

Titan Payroll provides tenant-scoped deterministic payroll reads, reconciliation, configured compliance-rule explanation and forecast scenarios. AI Workforce roles can inspect these services directly through scoped read tools.

Payroll mutations—including run preparation/submission/approval/finalization and reconciliation resolution proposals—use the governed Payroll Command Bus gateway. AI/Workforce state writes never use the local-human fallback. High/critical financial actions require the configured Risk and Assurance decisions and remain subject to external Titan Autonomy effective authority.

Payroll does not execute payments, own a generic accounting ledger, capture attendance, or execute communications providers.
