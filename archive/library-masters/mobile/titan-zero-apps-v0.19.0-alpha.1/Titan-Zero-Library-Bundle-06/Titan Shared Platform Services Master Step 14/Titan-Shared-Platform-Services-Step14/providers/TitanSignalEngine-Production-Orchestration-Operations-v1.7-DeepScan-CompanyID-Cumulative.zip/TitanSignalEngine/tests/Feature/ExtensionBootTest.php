<?php

declare(strict_types=1);

namespace Tests\Feature;

use PHPUnit\Framework\TestCase;

final class ExtensionBootTest extends TestCase
{
    public function test_provider_registers_foundation_contracts(): void
    {
        $provider = (string) file_get_contents(dirname(__DIR__, 2) . '/System/TitanSignalEngineServiceProvider.php');

        self::assertStringContainsString('EventTypeRegistryContract::class', $provider);
        self::assertStringContainsString('SignalRegistryAuthorityContract::class', $provider);
        self::assertStringContainsString('RegistryOwnershipPolicy::class', $provider);
        self::assertStringContainsString('SignalEventStoreContract::class', $provider);
        self::assertStringContainsString('SignalEmitterContract::class', $provider);
        self::assertStringContainsString('SignalQueryContract::class', $provider);
        self::assertStringContainsString('SignalManagerContract::class', $provider);
        self::assertStringContainsString('TraceProfileRegistryContract::class', $provider);
        self::assertStringContainsString('SignalCorrelationContract::class', $provider);
        self::assertStringContainsString('SignalSubscriptionRegistryContract::class', $provider);
        self::assertStringContainsString('SignalDeliverySchedulerContract::class', $provider);
        self::assertStringContainsString('SignalDeliveryDispatcherContract::class', $provider);
        self::assertStringContainsString('SignalConsoleContract::class', $provider);
        self::assertStringContainsString('SignalConsoleContextFactory::class', $provider);
    }
}
