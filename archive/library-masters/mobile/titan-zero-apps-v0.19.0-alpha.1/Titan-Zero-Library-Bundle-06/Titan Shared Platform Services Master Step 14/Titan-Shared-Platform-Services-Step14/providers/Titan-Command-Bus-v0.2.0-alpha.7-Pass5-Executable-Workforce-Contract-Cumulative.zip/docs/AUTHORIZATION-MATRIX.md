# Authorization Matrix

Super Admin UI requires the host admin middleware. Programmatic dispatch must be invoked by trusted server-side callers that construct CommandContext. Callers may not choose tenant authority, actor permissions, or governance results from payload data.
