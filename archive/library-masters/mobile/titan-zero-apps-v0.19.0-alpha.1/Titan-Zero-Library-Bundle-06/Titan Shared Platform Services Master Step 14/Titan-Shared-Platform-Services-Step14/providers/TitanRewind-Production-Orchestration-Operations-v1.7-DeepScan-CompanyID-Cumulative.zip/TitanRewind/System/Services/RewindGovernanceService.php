<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Contracts\RewindGovernanceGatewayContract;
use App\Extensions\TitanRewind\System\Models\RewindGovernanceReceipt;
use App\Extensions\TitanRewind\System\Models\RewindRecoveryPlan;
use App\Extensions\TitanRewind\System\Support\CanonicalJson;
use App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer;
use App\Extensions\TitanRewind\System\Observability\RewindTraceContext;
use Throwable;
use Illuminate\Support\Str;
use InvalidArgumentException;
use LogicException;

final class RewindGovernanceService
{
    public function __construct(
        private RewindGovernanceGatewayContract $gateway,
        private RewindPayloadSanitizer $sanitizer,
        private CanonicalJson $canonicalJson,
        private RewindEvidencePackageService $evidence,
        private RewindCircuitBreakerService $breakers,
        private RewindTelemetryService $telemetry,
        private RewindSignalOutboxService $signals,
    ) {}

    public function available(): bool { return $this->gateway->available(); }

    public function requestApproval(RewindRecoveryPlan $plan, ?int $actorId = null): RewindGovernanceReceipt
    {
        if ($plan->governance_request_id) {
            $existing = RewindGovernanceReceipt::query()
                ->where('tenant_company_id',$plan->tenant_company_id)
                ->where('recovery_plan_id',$plan->id)
                ->where('external_request_id',$plan->governance_request_id)
                ->latest('id')->first();
            if ($existing) return $existing;
        }

        $definition = is_array($plan->plan) ? $plan->plan : [];
        if (!($definition['submission_ready'] ?? false) || $plan->status === 'blocked') {
            throw new InvalidArgumentException('This recovery plan is not eligible for Governance submission. Resolve its blockers first.');
        }
        if (!$this->gateway->available()) {
            throw new LogicException('Titan Governance gateway is not bound; Rewind cannot authorize its own recovery plan.');
        }

        $evidence = $this->evidence->forTrace(
            \App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery::fromArray([
                'tenant_company_id'=>(int) $plan->tenant_company_id,
                'trace_id'=>(string) $plan->trace_id,
            ]),
            'audit',
            $plan->case_id ? (int) $plan->case_id : null,
            $actorId,
        );
        if (($evidence->manifest['integrity_state'] ?? null) !== 'passed' || $evidence->status !== 'ready' || !$this->evidence->verify($evidence)) {
            throw new LogicException('Governance handoff blocked because the fresh Rewind evidence package is not fully verified.');
        }

        $request = $this->sanitizer->sanitize([
            'request_type'=>'titan-rewind.recovery-approval',
            'tenant_company_id'=>(int) $plan->tenant_company_id,
            'trace_id'=>(string) $plan->trace_id,
            'case_id'=>$plan->case_id,
            'recovery_plan_uuid'=>(string) $plan->plan_uuid,
            'plan_hash'=>(string) $plan->plan_hash,
            'evidence_package_uuid'=>(string) $evidence->package_uuid,
            'evidence_content_hash'=>(string) $evidence->content_hash,
            'evidence_manifest'=>$evidence->manifest,
            'risk_level'=>(string) $plan->risk_level,
            'proposed_capability'=>$plan->proposed_capability,
            'command_input'=>$plan->command_input ?? [],
            'requested_by_id'=>$actorId,
            'authoritative_mutation_requested_from_rewind'=>false,
            'execution_owner'=>'titan-command-bus',
        ]);
        $requestHash = hash('sha256', $this->canonicalJson->encode($request));
        $ctx=RewindTraceContext::fromArray(['tenant_company_id'=>$plan->tenant_company_id,'trace_id'=>$plan->trace_id,'correlation_id'=>$plan->trace_id,'causation_id'=>null]);
        $this->breakers->assertAvailable('titan-governance');
        $started=microtime(true);
        try {
            $external = $this->gateway->requestApproval($request);
            $this->breakers->success('titan-governance');
            $this->telemetry->span('rewind.governance.request',(microtime(true)-$started)*1000,'OK',$ctx,['plan_uuid'=>$plan->plan_uuid]);
        } catch (Throwable $e) {
            $this->breakers->failure('titan-governance',$e);
            $this->telemetry->log('rewind.governance.request.failed','ERROR',$ctx,['plan_uuid'=>$plan->plan_uuid,'exception'=>$e::class]);
            throw $e;
        }
        $receipt = $this->persistExternalReceipt($plan, $requestHash, $external, null, (string) $evidence->package_uuid);
        $this->applyStatusToPlan($plan, $receipt);
        $this->signals->emit('rewind.governance.receipt.observed.v1',$ctx,['receipt_uuid'=>$receipt->receipt_uuid,'external_request_id'=>$receipt->external_request_id,'status'=>$receipt->status]);
        return $receipt;
    }

    public function refresh(RewindGovernanceReceipt $receipt): RewindGovernanceReceipt
    {
        if (!$this->gateway->available()) throw new LogicException('Titan Governance gateway is not bound; Rewind cannot refresh authorization.');
        /** @var RewindRecoveryPlan $plan */
        $plan = RewindRecoveryPlan::query()->where('tenant_company_id',$receipt->tenant_company_id)->whereKey($receipt->recovery_plan_id)->firstOrFail();
        $ctx=RewindTraceContext::fromArray(['tenant_company_id'=>$plan->tenant_company_id,'trace_id'=>$plan->trace_id,'correlation_id'=>$plan->trace_id,'causation_id'=>null]);
        $this->breakers->assertAvailable('titan-governance');
        try { $external = $this->gateway->refresh((string) $receipt->external_request_id, (int) $receipt->tenant_company_id); $this->breakers->success('titan-governance'); } catch (Throwable $e) { $this->breakers->failure('titan-governance',$e); $this->telemetry->log('rewind.governance.refresh.failed','ERROR',$ctx,['receipt_uuid'=>$receipt->receipt_uuid,'exception'=>$e::class]); throw $e; }
        $updated = $this->persistExternalReceipt($plan, (string) $receipt->request_payload_hash, $external, $receipt, $receipt->evidence_package_uuid ? (string) $receipt->evidence_package_uuid : null);
        $this->applyStatusToPlan($plan, $updated);
        $this->signals->emit('rewind.governance.receipt.observed.v1',$ctx,['receipt_uuid'=>$updated->receipt_uuid,'external_request_id'=>$updated->external_request_id,'status'=>$updated->status]);
        return $updated;
    }

    private function persistExternalReceipt(RewindRecoveryPlan $plan, string $requestHash, array $external, ?RewindGovernanceReceipt $existing = null, ?string $evidencePackageUuid = null): RewindGovernanceReceipt
    {
        $requestId = trim((string) ($external['request_id'] ?? ''));
        $status = strtolower(trim((string) ($external['status'] ?? '')));
        $allowed = ['pending','approved','rejected','cancelled','expired'];
        if ($requestId === '' || !in_array($status, $allowed, true)) {
            throw new InvalidArgumentException('Titan Governance returned an invalid Rewind approval response.');
        }

        if (in_array($status, ['approved','rejected','cancelled','expired'], true) && !$this->gateway->verifyReceipt($external)) {
            throw new LogicException('Titan Rewind rejected an unverifiable final Governance receipt.');
        }

        $clean = $this->sanitizer->sanitize($external);
        $attributes = [
            'authority'=>trim((string) ($clean['authority'] ?? $this->gateway->key())) ?: 'titan-governance',
            'status'=>$status,
            'request_payload_hash'=>$requestHash,
            'evidence_package_uuid'=>$evidencePackageUuid,
            'decision'=>is_array($clean['decision'] ?? null) ? $clean['decision'] : null,
            'receipt'=>$clean,
            'requested_at'=>$clean['requested_at'] ?? now(),
            'decided_at'=>$clean['decided_at'] ?? (in_array($status,['approved','rejected','cancelled','expired'],true) ? now() : null),
        ];

        if ($existing) {
            if ((string) $existing->external_request_id !== $requestId) {
                throw new LogicException('Governance refresh returned a different request identifier than the original request.');
            }
            if ((int) $existing->tenant_company_id !== (int) $plan->tenant_company_id || (int) $existing->recovery_plan_id !== (int) $plan->id) {
                throw new LogicException('A Governance receipt crossed the Rewind recovery-plan tenant boundary.');
            }
            $existing->forceFill($attributes)->save();
            return $existing->refresh();
        }

        $receipt = RewindGovernanceReceipt::query()->firstOrNew([
            'tenant_company_id'=>$plan->tenant_company_id,
            'external_request_id'=>$requestId,
        ]);
        if ($receipt->exists && (int) $receipt->recovery_plan_id !== (int) $plan->id) {
            throw new LogicException('This Governance request ID already belongs to another Rewind recovery plan.');
        }
        if (!$receipt->exists) $receipt->receipt_uuid = (string) Str::uuid();
        $receipt->recovery_plan_id = $plan->id;
        $receipt->forceFill($attributes)->save();
        return $receipt->refresh();
    }

    private function applyStatusToPlan(RewindRecoveryPlan $plan, RewindGovernanceReceipt $receipt): void
    {
        $status = match ((string) $receipt->status) {
            'pending' => 'approval_pending',
            'approved' => 'approved',
            'rejected','cancelled','expired' => 'rejected',
            default => 'draft',
        };
        $plan->forceFill([
            'status'=>$status,
            'governance_request_id'=>$receipt->external_request_id,
            'governance_status'=>$receipt->status,
            'approved_at'=>$receipt->status === 'approved' ? ($receipt->decided_at ?? now()) : null,
        ])->save();
    }
}
