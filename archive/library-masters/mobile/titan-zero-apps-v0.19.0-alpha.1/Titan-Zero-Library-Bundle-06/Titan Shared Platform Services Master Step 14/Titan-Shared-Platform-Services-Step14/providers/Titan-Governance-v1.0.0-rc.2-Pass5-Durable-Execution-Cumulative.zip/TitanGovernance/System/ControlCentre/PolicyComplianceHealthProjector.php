<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ControlCentre;

use DateTimeImmutable;
use Throwable;

final class PolicyComplianceHealthProjector
{
    /** @param array<string,array<string,mixed>> $sourceSnapshots @param list<array<string,mixed>> $recentDecisions @return array<string,mixed> */
    public function project(array $sourceSnapshots,array $recentDecisions,array $context=[]):array
    {
        $policies=[];$controls=[];$exceptions=[];$driftCount=0;$visibilityDegraded=0;$requiredUnavailable=0;$explicitNonCompliance=false;
        foreach($sourceSnapshots as $sourceKey=>$source){
            if(!is_array($source))continue;
            $status=strtoupper(trim((string)($source['status']??'UNAVAILABLE')));
            if(!in_array($status,['HEALTHY','DISABLED'],true)){
                $visibilityDegraded++;
                if((bool)($source['required']??false) && in_array($status,['UNAVAILABLE','ERROR','NOT_INSTALLED','INVALID'],true))$requiredUnavailable++;
            }
            $cc=is_array($source['control_centre']??null)?$source['control_centre']:[];
            foreach(array_slice(is_array($cc['policies']??null)?$cc['policies']:[],0,300) as $raw){
                if(!is_array($raw))continue;$key=trim((string)($raw['policy_key']??$raw['id']??''));if($key==='')continue;
                $expected=$this->scalar($raw['expected_version']??null);$current=$this->scalar($raw['current_version']??$raw['version']??null);
                $sourceStatus=strtoupper(trim((string)($raw['status']??'UNKNOWN')));
                $drift=($expected!==null&&$current!==null&&$expected!==$current)?'DRIFT':(in_array($sourceStatus,['OUTDATED','DRIFT','MISMATCH'],true)?'DRIFT':'CURRENT');
                if($drift==='DRIFT')$driftCount++;
                $policies[]=['source'=>(string)$sourceKey,'policy_key'=>$key,'expected_version'=>$expected,'current_version'=>$current,'status'=>$sourceStatus,'drift_status'=>$drift,'observed_at'=>$raw['observed_at']??$source['observed_at']??null,'reference'=>$this->scalar($raw['reference']??null)];
            }
            foreach(array_slice(is_array($cc['controls']??null)?$cc['controls']:[],0,500) as $raw){
                if(!is_array($raw))continue;$key=trim((string)($raw['control_key']??$raw['id']??''));if($key==='')continue;
                $controlStatus=strtoupper(trim((string)($raw['status']??'UNKNOWN')));$evidenceStatus=strtoupper(trim((string)($raw['evidence_status']??'UNKNOWN')));
                if(in_array($controlStatus,['NON_COMPLIANT','FAILED','BLOCKED','VIOLATION'],true))$explicitNonCompliance=true;
                $controls[]=['source'=>(string)$sourceKey,'control_key'=>$key,'obligation_key'=>$this->scalar($raw['obligation_key']??null),'status'=>$controlStatus,'evidence_status'=>$evidenceStatus,'expires_at'=>$raw['expires_at']??null,'observed_at'=>$raw['observed_at']??$source['observed_at']??null,'reference'=>$this->scalar($raw['reference']??null)];
            }
        }

        $now=$this->now($context);$expiringWindow=max(1,(int)($context['exception_expiring_seconds']??86400));
        foreach(array_slice($recentDecisions,0,200) as $decision){
            if(!is_array($decision))continue;$action=strtoupper(trim((string)($decision['action']??$decision['disposition']??'')));if($action!=='EXCEPTION'&&$action!=='EXCEPTION_GRANTED')continue;
            $payload=is_array($decision['result_payload']??null)?$decision['result_payload']:[];$expires=$payload['expires_at']??$decision['expires_at']??null;
            $expiry='UNKNOWN';$secondsRemaining=null;
            if(is_string($expires)&&trim($expires)!==''){
                try{$at=new DateTimeImmutable($expires);$secondsRemaining=$at->getTimestamp()-$now->getTimestamp();$expiry=$secondsRemaining<=0?'EXPIRED':($secondsRemaining<=$expiringWindow?'EXPIRING':'ACTIVE');}
                catch(Throwable){$expiry='INVALID';}
            }
            $exceptions[]=['decision_id'=>(string)($decision['decision_id']??''),'expiry_status'=>$expiry,'expires_at'=>$expires,'seconds_remaining'=>$secondsRemaining,'reason_codes'=>array_values(array_slice(is_array($decision['reason_codes']??null)?$decision['reason_codes']:[],0,50)),'decided_at'=>$decision['decided_at']??null];
        }

        usort($policies,static fn(array $a,array $b):int=>strcmp((string)$a['policy_key'],(string)$b['policy_key']));
        usort($controls,static fn(array $a,array $b):int=>strcmp((string)$a['control_key'],(string)$b['control_key']));
        usort($exceptions,static fn(array $a,array $b):int=>strcmp((string)$a['decision_id'],(string)$b['decision_id']));
        $expiredOrExpiring=count(array_filter($exceptions,static fn(array $r):bool=>in_array($r['expiry_status'],['EXPIRED','EXPIRING','INVALID'],true)))>0;
        if($explicitNonCompliance)$status='NON_COMPLIANT';
        elseif($requiredUnavailable>0)$status='UNAVAILABLE';
        elseif($driftCount>0||$expiredOrExpiring||$visibilityDegraded>0)$status='DEGRADED';
        elseif($policies===[]&&$controls===[]&&$exceptions===[])$status='UNAVAILABLE';
        else $status='HEALTHY';
        return ['status'=>$status,'policy_drift_count'=>$driftCount,'visibility_degraded_sources'=>$visibilityDegraded,'required_unavailable_sources'=>$requiredUnavailable,'policies'=>$policies,'controls'=>$controls,'exceptions'=>$exceptions,'observed_at'=>$now->format(DATE_ATOM)];
    }

    private function now(array $context):DateTimeImmutable{if(is_string($context['now']??null)){try{return new DateTimeImmutable($context['now']);}catch(Throwable){}}return new DateTimeImmutable('now');}
    private function scalar(mixed $v):?string{return is_scalar($v)&&trim((string)$v)!==''?(string)$v:null;}
}
