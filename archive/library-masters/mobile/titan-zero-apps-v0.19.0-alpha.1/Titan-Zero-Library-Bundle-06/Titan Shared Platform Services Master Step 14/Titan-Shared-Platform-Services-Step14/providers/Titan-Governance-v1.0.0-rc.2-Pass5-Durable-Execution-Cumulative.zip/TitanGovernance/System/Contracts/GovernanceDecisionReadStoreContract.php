<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Contracts;

interface GovernanceDecisionReadStoreContract
{
    /** @return array<string,mixed>|null */
    public function find(int $tenantCompanyId, string $decisionId): ?array;
    /** @return list<array<string,mixed>> */
    public function recent(int $tenantCompanyId, int $limit = 50): array;
}
