<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Navigation;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class LegacyMenuStore
{
    public function available(): bool { return Schema::hasTable('menus'); }
    /** @return array<string,bool> */
    public function columns(): array { return array_fill_keys(Schema::getColumnListing('menus'), true); }
    public function deleteByKey(string $key): int { return DB::table('menus')->where('key',$key)->delete(); }
    public function firstByKey(string $key): ?object { return DB::table('menus')->where('key',$key)->orderBy('id')->first(); }
    public function countByKey(string $key): int { return (int) DB::table('menus')->where('key',$key)->count(); }
    public function idByKey(string $key): ?int { $id=DB::table('menus')->where('key',$key)->orderBy('id')->value('id'); return $id===null?null:(int)$id; }
    /** @param array<string,mixed> $payload */
    public function updateById(int $id,array $payload): int { return DB::table('menus')->where('id',$id)->update($payload); }
    /** @param array<string,mixed> $payload */
    public function insert(array $payload): bool { return DB::table('menus')->insert($payload); }
}
