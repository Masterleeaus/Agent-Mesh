# Security

Evidence is tenant/user scoped. Original evidence is immutable from the annotation layer. Secrets remain host-managed. Provider responses are treated as untrusted inference and parsed into bounded structured findings.
