<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;

final class CrmDashboardService
{
    public function __construct(private ConnectionInterface $db){}
    public function summary(int $userId): array
    {
        $tenant=CrmCompanyScope::companyId($userId);$today=now()->startOfDay();$companies=(int)$this->db->table(config('crm.tables.companies'))->where('company_id',$tenant)->whereNull('deleted_at')->count();$contacts=(int)$this->db->table(config('crm.tables.contacts'))->where('company_id',$tenant)->whereNull('deleted_at')->count();
        $deal=$this->db->table(config('crm.tables.deals'))->where('company_id',$tenant)->whereNull('deleted_at')->selectRaw("SUM(CASE WHEN status='open' THEN 1 ELSE 0 END) AS open_deals, SUM(CASE WHEN status='open' AND expected_close_date IS NOT NULL AND expected_close_date < ? THEN 1 ELSE 0 END) AS overdue, COALESCE(SUM(CASE WHEN status='open' THEN value_minor ELSE 0 END),0) AS pipeline, COALESCE(SUM(CASE WHEN status='open' THEN value_minor * probability / 100 ELSE 0 END),0) AS weighted",[$today->toDateString()])->first();
        $followUps=(int)$this->db->table(config('crm.tables.leads'))->where('company_id',$tenant)->whereNull('deleted_at')->whereNotNull('follow_up_at')->where('follow_up_at','<=',now())->whereNotIn('status',['converted','lost'])->count();
        return ['companies'=>$companies,'contacts'=>$contacts,'openDeals'=>(int)($deal->open_deals??0),'overdue'=>(int)($deal->overdue??0),'pipeline'=>(int)($deal->pipeline??0),'weighted'=>(int)round((float)($deal->weighted??0)),'followUps'=>$followUps];
    }
}
