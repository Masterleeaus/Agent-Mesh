<?php

declare(strict_types=1);

$root = dirname(__DIR__);
function rc2check(bool $ok,string $message): void { if(!$ok){fwrite(STDERR,"FAIL: {$message}\n"); exit(1);} }
foreach ([
'/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php','/System/Domain/RiskDecision.php','/System/Domain/GovernanceDecision.php','/System/Domain/AssuranceDecision.php','/System/Domain/AutonomyDecision.php','/System/Domain/ProvisioningReceiptStatus.php','/System/Domain/ProvisioningReceipt.php','/System/Domain/ProvisioningExecutionContext.php','/System/Domain/VerticalDefinition.php','/System/Domain/CompiledTitanConfig.php','/System/Domain/ValidationFinding.php','/System/Domain/ValidationResult.php','/System/Support/CanonicalJson.php'
] as $file) { if(!is_file($root.$file)){fwrite(STDERR,"FAIL: missing {$file}\n");exit(1);} require_once $root.$file; }

use App\Extensions\TitanNexus\System\Domain\RiskDecision;
use App\Extensions\TitanNexus\System\Domain\GovernanceDecision;
use App\Extensions\TitanNexus\System\Domain\AssuranceDecision;
use App\Extensions\TitanNexus\System\Domain\AutonomyDecision;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\ProvisioningReceipt;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\CompiledTitanConfig;
use App\Extensions\TitanNexus\System\Domain\ValidationResult;

foreach ([RiskDecision::class,GovernanceDecision::class,AssuranceDecision::class,AutonomyDecision::class] as $class) {
    $data = match($class) {
        RiskDecision::class => ['allowed'=>'false','decision_reference'=>'risk:1','risk_class'=>'MEDIUM','required_assurance'=>'AMBER'],
        GovernanceDecision::class => ['allowed'=>'false','decision_reference'=>'gov:1','approval_required'=>'false'],
        AssuranceDecision::class => ['allowed'=>'false','evidence_reference'=>'assurance:1','assurance_level'=>'AMBER'],
        default => ['allowed'=>'false','decision_reference'=>'autonomy:1','authority_level'=>'bounded'],
    };
    $decision = $class::fromArray($data);
    rc2check($decision->allowed() === false, basename(str_replace('\\','/',$class)).' parses string false fail-closed');
}
$gov = GovernanceDecision::fromArray(['allowed'=>true,'decision_reference'=>'gov:2','approval_required'=>'false']);
rc2check($gov->approvalRequired() === false,'approval_required string false stays false');

$threw=false;
try { ProvisioningReceipt::fromArray(['operation_id'=>str_repeat('a',64),'idempotency_key'=>str_repeat('b',64),'status'=>'applied','backup_reference'=>'b','backup_verified'=>'false','write_verified'=>'false','audit_reference'=>'a','rollback_reference'=>'r']); } catch(InvalidArgumentException){$threw=true;}
rc2check($threw,'string false cannot satisfy applied receipt evidence');

$system = ProvisioningExecutionContext::system(42,'system:nexus','grant:system');
rc2check($system->autonomous(),'system execution is autonomy-governed');
$threw=false; try { ProvisioningExecutionContext::system(42,'system:nexus'); } catch(InvalidArgumentException){$threw=true;}
rc2check($threw,'system execution requires autonomy grant evidence');

$internal = VerticalDefinition::fromArray([
 'vertical_id'=>'cleaning','vertical_version'=>'1','knowledge_snapshot_version'=>'ks:1','sections'=>['crm'=>['enabled'=>true]],
 'validation'=>['required_profile_paths'=>['sections.business.name'],'required_platform_capabilities'=>['crm.core'],'require_knowledge_snapshot'=>true],
 'recompile_policy'=>['requires_approval_paths'=>['sections.crm'],'blocked_paths'=>['sections.finance']],
 'provisioning'=>['routes'=>['sections.crm'=>['capability'=>'crm.configuration.apply','depends_on'=>[]]]],
]);
$canonical=$internal->toContractArray();
$round=VerticalDefinition::fromArray($canonical);
rc2check($round->fingerprint()===$internal->fingerprint(),'canonical VerticalDefinition round-trips');

$config=CompiledTitanConfig::fromArray(['tenant_company_id'=>42,'configuration_version'=>'1','compiler_version'=>'0.5.0','vertical_id'=>'cleaning','vertical_version'=>'1','knowledge_snapshot_version'=>'ks:1','source_profile_hash'=>str_repeat('a',64),'source_vertical_hash'=>$internal->fingerprint(),'sections'=>['crm'=>['enabled'=>true]]]);
$configRound=CompiledTitanConfig::fromArray($config->toContractArray());
rc2check($configRound->outputHash()===$config->outputHash(),'canonical CompiledTitanConfig round-trips');

$validation=ValidationResult::fromFindings([]);
$validationRound=ValidationResult::fromArray($validation->toContractArray());
rc2check($validationRound->fingerprint()===$validation->fingerprint(),'canonical ValidationResult round-trips');

$receiptRejected=false;
try { new ProvisioningReceipt(str_repeat('a',64),str_repeat('b',64),\App\Extensions\TitanNexus\System\Domain\ProvisioningReceiptStatus::Failed,metadata:['refresh_token'=>'secret']); } catch(InvalidArgumentException){$receiptRejected=true;}
rc2check($receiptRejected,'receipt metadata rejects secret-like keys');

require_once $root.'/System/Host/NexusMenuRegistrar.php';
$defs=\App\Extensions\TitanNexus\System\Host\NexusMenuRegistrar::definitions();
rc2check(($defs[0]['legacy_identity']['key']??null)==='titan-nexus','parent legacy identity uses key');
rc2check(($defs[1]['legacy_identity']['key']??null)==='titan-nexus.overview','overview legacy identity is unique');
rc2check(($defs[0]['legacy_fallback_identity']['route']??null)!==($defs[1]['legacy_fallback_identity']['route']??null),'fallback route identities are unique');

$provider=(string)file_get_contents($root.'/System/TitanNexusServiceProvider.php');
rc2check(str_contains($provider,'TitanNexusAuthorizationMiddleware'),'authorization middleware is wired');
rc2check(str_contains($provider,'try {') && str_contains($provider,'registerNavigation'),'navigation registration is boot-isolated');

$repo=(string)file_get_contents($root.'/System/Repositories/EloquentCompilationRepository.php');
rc2check(str_contains($repo,'entity_version'),'repository uses entity_version');
rc2check(str_contains($repo,'where(\'entity_version\''),'repository uses optimistic compare-and-swap');
$manager=(string)file_get_contents($root.'/System/Services/NexusManager.php');
rc2check(str_contains($manager,'persist('),'manager persists lifecycle state');
rc2check(str_contains($manager,'RuntimeReadinessReport::fromDependencies('),'health delegates status/capability readiness to the shared runtime report');

$manifest=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
rc2check(($manifest['version']??null)==='1.0.0-rc.2','manifest is rc.2');
rc2check(in_array('titan-nexus.view',$manifest['permissions']??[],true),'manifest declares titan-nexus.view');

require_once $root.'/System/Host/TitanZipPackageVerifier.php';
$fake=sys_get_temp_dir().'/nexus-not-a-package-'.bin2hex(random_bytes(4)).'.zip'; file_put_contents($fake,'not a zip');
$zipResult=App\Extensions\TitanNexus\System\Host\TitanZipPackageVerifier::verify($fake); @unlink($fake);
rc2check($zipResult['valid']===false,'non-ZIP cannot receive PACKAGE_CERTIFIED PASS');

fwrite(STDOUT,"PASS: Titan Nexus RC2 audit remediation checks\n");
