<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Sharing;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

final class CrmRecordShareService
{
    public const PERMISSIONS = ['view','comment','edit'];
    public const SUPPORTED_SUBJECTS = ['company','contact','lead','deal','project','task'];

    private const TABLES = [
        'company'=>'crm_companies','contact'=>'crm_contacts','lead'=>'crm_leads','deal'=>'crm_deals','project'=>'crm_projects','task'=>'crm_tasks',
    ];

    public function __construct(private ConnectionInterface $db) {}

    public function grant(int $userId, string $subject_type, string $subject_public_id, int $grantee_user_id, array $permissions=['view'], ?string $expires_at=null): array
    {
        if (! in_array($subject_type, self::SUPPORTED_SUBJECTS, true)) throw new \InvalidArgumentException('Unsupported shared CRM subject type.');
        if ($grantee_user_id === $userId) throw new \InvalidArgumentException('A CRM record does not need to be shared with its owner.');
        $permissions = array_values(array_unique(array_map('strval',$permissions)));
        if ($permissions === [] || array_diff($permissions,self::PERMISSIONS)) throw new \InvalidArgumentException('Unsupported record-share permission.');
        if (! in_array('view', $permissions, true)) $permissions[] = 'view';

        $exists = $this->db->table(self::TABLES[$subject_type])->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$subject_public_id)->whereNull('deleted_at')->exists();
        if (! $exists) throw new NotFoundHttpException();

        $id = (string) Str::ulid();
        $this->db->table('crm_record_shares')->updateOrInsert(
            ['company_id' => CrmCompanyScope::companyId($userId), 'subject_type'=>$subject_type,'subject_public_id'=>$subject_public_id,'grantee_user_id'=>$grantee_user_id],
            ['public_id'=>$id,'user_id'=>CrmCompanyScope::actorUserId($userId),'permissions'=>json_encode($permissions),'expires_at'=>$expires_at,'revoked_at'=>null,'created_at'=>now(),'updated_at'=>now()]
        );
        return (array)$this->db->table('crm_record_shares')->where('company_id', CrmCompanyScope::companyId($userId))->where('subject_type',$subject_type)
            ->where('subject_public_id',$subject_public_id)->where('grantee_user_id',$grantee_user_id)->first();
    }

    public function allows(int|array $ownerOrGrant, int|string $granteeOrPermission, ?string $subjectType=null, ?string $subjectPublicId=null, string $permission='view'): bool
    {
        if (is_array($ownerOrGrant)) {
            $grant = $ownerOrGrant;
            $wanted = (string)$granteeOrPermission;
            if (! empty($grant['revoked_at'])) return false;
            if (! empty($grant['expires_at']) && now()->greaterThan($grant['expires_at'])) return false;
            $permissions = is_array($grant['permissions'] ?? null) ? $grant['permissions'] : (json_decode((string)($grant['permissions'] ?? '[]'), true) ?: []);
            return in_array($wanted, $permissions, true);
        }

        $row = $this->db->table('crm_record_shares')->where('company_id', CrmCompanyScope::companyId((int)$ownerOrGrant))->where('grantee_user_id',(int)$granteeOrPermission)
            ->where('subject_type',$subjectType)->where('subject_public_id',$subjectPublicId)->whereNull('revoked_at')->first();
        if (! $row) return false;
        return $this->allows((array)$row, $permission);
    }

    public function resolveGrant(int $granteeUserId, string $subjectType, string $subjectPublicId, string $permission='view'): array
    {
        if (! in_array($subjectType, self::SUPPORTED_SUBJECTS, true)) throw new NotFoundHttpException();
        $rows = $this->db->table('crm_record_shares')->where('grantee_user_id',$granteeUserId)->where('subject_type',$subjectType)
            ->where('subject_public_id',$subjectPublicId)->whereNull('revoked_at')->orderByDesc('id')->get();
        foreach ($rows as $row) {
            $grant = (array)$row;
            if ($this->allows($grant, $permission)) return $grant;
        }
        throw new AccessDeniedHttpException('This CRM record has not been shared with the requested permission.');
    }

    public function received(int $granteeUserId): array
    {
        return $this->db->table('crm_record_shares')->where('grantee_user_id',$granteeUserId)->whereNull('revoked_at')->orderByDesc('id')->limit(250)->get()
            ->map(function ($row): array {
                $grant=(array)$row;
                $grant['permissions']=json_decode((string)$row->permissions,true)?:[];
                $grant['active']=!$row->expires_at || now()->lessThanOrEqualTo($row->expires_at);
                return $grant;
            })->filter(fn(array $grant): bool => (bool)$grant['active'])->values()->all();
    }

    public function revoke(int $userId,string $publicId): void
    {
        $n=$this->db->table('crm_record_shares')->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->whereNull('revoked_at')
            ->update(['revoked_at'=>now(),'updated_at'=>now()]);
        if(!$n) throw new NotFoundHttpException();
    }

    public function list(int $userId): array
    {
        return $this->db->table('crm_record_shares')->where('company_id', CrmCompanyScope::companyId($userId))->orderByDesc('id')->get()->map(fn($r)=>(array)$r)->all();
    }
}
