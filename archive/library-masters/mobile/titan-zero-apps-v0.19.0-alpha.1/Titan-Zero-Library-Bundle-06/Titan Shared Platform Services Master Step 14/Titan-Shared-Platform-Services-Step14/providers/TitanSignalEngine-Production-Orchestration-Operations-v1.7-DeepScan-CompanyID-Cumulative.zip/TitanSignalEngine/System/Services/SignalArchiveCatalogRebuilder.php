<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalArchiveCatalogContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalArchiveStoreContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalArchiveEntry;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Exceptions\SignalIntegrityException;
use App\Extensions\TitanSignalEngine\System\Models\SignalArchiveBatch;
use App\Extensions\TitanSignalEngine\System\Models\SignalArchiveCatalogRow;

final class SignalArchiveCatalogRebuilder
{
    public function __construct(
        private readonly SignalArchiveStoreContract $archiveStore,
        private readonly SignalArchiveCatalogContract $catalog,
    ) {
    }

    /** @return array{scanned:int,catalogued_batches:int,catalogued_events:int,skipped:int} */
    public function rebuild(int $limit = 100): array
    {
        $limit = max(1, min($limit, 1000));
        $batches = SignalArchiveBatch::query()
            ->whereIn('status', ['verified', 'pruned'])
            ->whereNotNull('archive_locator')
            ->whereNotNull('archive_checksum')
            ->orderBy('id')
            ->limit($limit)
            ->cursor();

        $result = ['scanned' => 0, 'catalogued_batches' => 0, 'catalogued_events' => 0, 'skipped' => 0];
        foreach ($batches as $batch) {
            $result['scanned']++;
            $existing = SignalArchiveCatalogRow::query()->where('batch_id', $batch->batch_id)->count();
            if ($existing >= (int) $batch->event_count && (int) $batch->event_count > 0) {
                $result['skipped']++;
                continue;
            }
            $driver = (string) $batch->archive_driver;
            $locator = (string) $batch->archive_locator;
            $checksum = (string) $batch->archive_checksum;
            $metadata = $this->archiveStore->metadata($locator, $checksum, $driver);
            if ((string) $metadata['batch_id'] !== (string) $batch->batch_id || (int) $metadata['event_count'] !== (int) $batch->event_count) {
                throw new SignalIntegrityException('Signal archive manifest does not match its archive batch ledger.');
            }
            $events = $this->archiveStore->readBatch($locator, $checksum, max(1, (int) $batch->event_count), $driver);
            if (count($events) !== (int) $batch->event_count) {
                throw new SignalIntegrityException('Signal archive event count does not match its verified batch ledger.');
            }
            $entries = [];
            foreach ($events as $index => $event) {
                $scope = (string) ($event['scope'] ?? '');
                $tenant = isset($event['tenant_company_id']) && $event['tenant_company_id'] !== null ? (int) $event['tenant_company_id'] : null;
                if ($scope !== (string) $batch->scope || (int) ($tenant ?? 0) !== (int) ($batch->tenant_company_id ?? 0)) {
                    throw new SignalIntegrityException('Signal archive event crossed its batch tenant/scope boundary.');
                }
                $checksumRef = (string) ($event['checksum'] ?? '');
                $privacyProjected = true;
                try {
                    $privacyProjected = ! SignalEnvelope::fromPersistenceArray($event)->verifyChecksum();
                } catch (\Throwable) {
                    $privacyProjected = true;
                }
                $entries[] = new SignalArchiveEntry(
                    eventId: (string) ($event['event_id'] ?? ''),
                    batchId: (string) $batch->batch_id,
                    scope: $scope,
                    tenantCompanyId: $tenant,
                    eventType: (string) ($event['event_type'] ?? ''),
                    traceId: (string) ($event['trace_id'] ?? ''),
                    correlationId: (string) ($event['correlation_id'] ?? ''),
                    causationId: ($event['causation_id'] ?? null) === null ? null : (string) $event['causation_id'],
                    rootCausationId: (string) ($event['root_causation_id'] ?? ''),
                    occurredAt: (string) ($event['occurred_at'] ?? ''),
                    recordedAt: (string) ($event['recorded_at'] ?? ''),
                    archiveDriver: $driver,
                    archiveLocator: $locator,
                    archiveChecksum: $checksum,
                    archiveSequence: $index + 1,
                    privacyProjected: $privacyProjected,
                    originalChecksum: $checksumRef,
                );
            }
            $this->catalog->record($entries);
            $result['catalogued_batches']++;
            $result['catalogued_events'] += count($entries);
        }
        return $result;
    }
}
