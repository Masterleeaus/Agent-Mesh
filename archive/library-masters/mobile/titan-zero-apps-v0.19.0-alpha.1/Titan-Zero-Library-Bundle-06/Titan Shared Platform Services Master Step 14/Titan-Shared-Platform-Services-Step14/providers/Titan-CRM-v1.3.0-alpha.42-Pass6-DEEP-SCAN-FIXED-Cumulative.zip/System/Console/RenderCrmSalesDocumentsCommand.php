<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\Services\SalesDocumentRenderQueueService;
use Illuminate\Console\Command;

final class RenderCrmSalesDocumentsCommand extends Command
{
    protected $signature='crm:documents:render {--limit=25 : Maximum jobs to process}';
    protected $description='Render queued CRM commercial documents asynchronously.';

    public function handle(SalesDocumentRenderQueueService $queue): int
    {
        $result=$queue->processPending((int)$this->option('limit'));
        $this->info(sprintf('Processed %d render jobs: %d ready, %d failed.',$result['processed'],$result['ready'],$result['failed']));
        return $result['failed']>0?self::FAILURE:self::SUCCESS;
    }
}
