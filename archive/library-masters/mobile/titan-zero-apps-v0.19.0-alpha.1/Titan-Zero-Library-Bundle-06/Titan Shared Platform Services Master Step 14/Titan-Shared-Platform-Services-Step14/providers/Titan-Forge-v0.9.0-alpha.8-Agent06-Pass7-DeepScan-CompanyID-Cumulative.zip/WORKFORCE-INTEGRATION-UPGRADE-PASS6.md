# Agent-06 Upgrade Pass 6 — Provider Health Execution

Version: 0.9.0-alpha.8

This pass adds executable provider health refresh and operational status reporting.

- provider-specific non-mutating dependency probes;
- secret-safe health evaluation;
- five-minute refresh/freshness contract;
- persisted health observations;
- health-observed and availability-transition event emission;
- Workforce-facing operational status DTO/service;
- stale state fails closed to unavailable;
- all health scope remains `company_id`.
