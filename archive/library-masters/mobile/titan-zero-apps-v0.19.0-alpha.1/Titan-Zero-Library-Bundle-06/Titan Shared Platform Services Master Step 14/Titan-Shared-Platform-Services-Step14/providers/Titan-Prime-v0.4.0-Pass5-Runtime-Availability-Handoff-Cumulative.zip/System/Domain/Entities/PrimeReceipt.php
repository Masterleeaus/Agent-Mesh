<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Entities;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use InvalidArgumentException;

final readonly class PrimeReceipt
{
    /**
     * @param list<string> $reasonCodes
     * @param list<string> $evidenceReferences
     * @param array<string,mixed> $metadata
     */
    public function __construct(
        public string $receiptId,
        public string $missionId,
        public TraceContext $trace,
        public string $decision,
        public array $reasonCodes = [],
        public array $evidenceReferences = [],
        public ?string $commandReceiptId = null,
        public ?string $outcomeCode = null,
        public array $metadata = [],
        public ?string $recordedAt = null,
    ) {
        if (trim($receiptId) === '' || trim($missionId) === '' || trim($decision) === '') {
            throw new InvalidArgumentException('Receipt id, mission id and decision are required.');
        }
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'receipt_id' => $this->receiptId,
            'mission_id' => $this->missionId,
            ...$this->trace->toArray(),
            'decision' => $this->decision,
            'reason_codes' => array_values($this->reasonCodes),
            'evidence_references' => array_values($this->evidenceReferences),
            'command_receipt_id' => $this->commandReceiptId,
            'outcome_code' => $this->outcomeCode,
            'metadata' => $this->metadata,
            'recorded_at' => $this->recordedAt,
        ];
    }
}
