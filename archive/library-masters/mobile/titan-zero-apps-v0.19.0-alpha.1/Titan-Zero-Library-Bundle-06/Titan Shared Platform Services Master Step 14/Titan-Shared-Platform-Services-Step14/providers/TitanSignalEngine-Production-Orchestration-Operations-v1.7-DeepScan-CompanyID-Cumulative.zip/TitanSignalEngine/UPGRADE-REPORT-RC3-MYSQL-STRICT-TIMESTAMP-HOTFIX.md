# Titan Signal Engine v0.20.0-rc.3 — MySQL Strict Timestamp Migration Compatibility Hotfix

## Live failure evidence

Installer 1.7.8 install `01M0ABSS6EK24CDQVSW79HBJB0` passed validation and deployment, then recorded six extension migrations before migration 7 failed while creating `titan_signal_pulse_projected_events`. The generated DDL contained two required `TIMESTAMP` columns (`recorded_at`, `projected_at`) with no explicit database defaults; the host rejected `projected_at` with `SQLSTATE[42000] / 1067 Invalid default value`.

## Root cause

Required application-managed timestamps were expressed as Laravel `timestamp()` columns without nullable/default modifiers. On MySQL/MariaDB configurations where implicit TIMESTAMP defaults interact with strict/no-zero-date behavior, a later required TIMESTAMP can receive an invalid implicit default. Migration 7 was the first failing table, but the same pattern existed in later migrations.

## Fix

- Converted all 25 required application-managed `timestamp()` declarations without explicit defaults to `dateTime()` across migrations 7–18.
- Preserved nullable timestamp fields and Laravel `timestamps()` metadata unchanged.
- Added `tests/run-mysql-strict-migration-compatibility.php` to reject any future required implicit-default TIMESTAMP declaration in extension migrations.
- No runtime event semantics, queue behavior, capability contracts, retention policy, or API behavior changed.

## Host truth boundary

rc.2 proved Installer validation and provider deployment compatibility on the live host and reached the migration stage. rc.3 has local migration-contract verification, but full host certification remains pending until Installer 1.7.8 successfully applies all 19 migrations and `php artisan titan:signal:certify --strict --probe-writes` passes on the real host.
