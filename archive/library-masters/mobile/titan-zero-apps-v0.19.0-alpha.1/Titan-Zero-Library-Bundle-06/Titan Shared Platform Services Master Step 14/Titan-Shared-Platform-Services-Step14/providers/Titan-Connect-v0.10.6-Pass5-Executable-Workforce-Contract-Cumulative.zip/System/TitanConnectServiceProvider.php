<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System;

use App\Extensions\TitanConnect\System\Console\DiagnoseTitanConnectCommand;
use App\Extensions\TitanConnect\System\Console\CertifyTitanConnectCommand;
use App\Extensions\TitanConnect\System\Console\ImportLegacyTeamChatCommand;
use App\Extensions\TitanConnect\System\Console\RetryDueDeliveriesCommand;
use App\Extensions\TitanConnect\System\Console\SyncTitanConnectHostCommand;
use App\Extensions\TitanConnect\System\Contracts\AttachmentSecurityScanner;
use App\Extensions\TitanConnect\System\Contracts\ChatbotMessagingBridge;
use App\Extensions\TitanConnect\System\Contracts\CredentialVault;
use App\Extensions\TitanConnect\System\Contracts\MessagingToolGateway;
use App\Extensions\TitanConnect\System\Contracts\MobilePushGateway;
use App\Extensions\TitanConnect\System\Contracts\ProviderHttpClient;
use App\Extensions\TitanConnect\System\Contracts\VoiceAgentGateway;
use App\Extensions\TitanConnect\System\Contracts\VoiceSessionGateway;
use App\Extensions\TitanConnect\System\Contracts\ReplyAssistant;
use App\Extensions\TitanConnect\System\Contracts\MessagingPrivacyHook;
use App\Extensions\TitanConnect\System\Contracts\RetentionPolicy;
use App\Extensions\TitanConnect\System\Contracts\CompanyActorDirectory;
use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Events\InboundMessageReceived;
use App\Extensions\TitanConnect\System\Events\TeamChat\TeamMessageCreated;
use App\Extensions\TitanConnect\System\Listeners\ForwardInboundToChatbot;
use App\Extensions\TitanConnect\System\Listeners\PushTeamMessage;
use App\Extensions\TitanConnect\System\Providers\ProviderRegistry;
use App\Extensions\TitanConnect\System\Integration\ConfiguredIntegrationBinder;
use App\Extensions\TitanConnect\System\Host\HostMenuLifecycle;
use App\Extensions\TitanConnect\System\Host\TitanConnectFeatureCatalogue;
use App\Extensions\TitanConnect\System\Host\TitanConnectHostManifest;
use App\Extensions\TitanConnect\System\Host\TitanConnectPermissionCatalogue;
use App\Extensions\TitanConnect\System\Navigation\HostNavigationRegistrar;
use App\Extensions\TitanConnect\System\Navigation\MagicAiMenuSynchronizer;
use App\Extensions\TitanConnect\System\Navigation\TitanConnectNavigation;
use App\Extensions\TitanConnect\System\Security\AuthenticatedCompanyContext;
use App\Extensions\TitanConnect\System\View\MagicAiDashboardRenderer;
use App\Extensions\TitanConnect\System\Security\ConfigCredentialVault;
use App\Extensions\TitanConnect\System\Security\ConfigRetentionPolicy;
use App\Extensions\TitanConnect\System\Security\DatabaseCompanyActorDirectory;
use App\Extensions\TitanConnect\System\Services\DefaultMessagingToolGateway;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\ServiceProvider;

final class TitanConnectServiceProvider extends ServiceProvider
{
    public static function registerKey(): string
    {
        return 'titan-connect';
    }

    public static function uninstall(): void
    {
        try {
            if (function_exists('app')) {
                app(MagicAiMenuSynchronizer::class)->remove(true);
            }
        } catch (\Throwable $exception) {
            if (function_exists('report')) {
                report($exception);
            }
        }

        if (! function_exists('public_path')) {
            return;
        }

        $path = public_path('vendor/titan-connect');
        if (! is_dir($path)) {
            return;
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST,
        );
        foreach ($iterator as $item) {
            if ($item->isDir()) {
                @rmdir($item->getPathname());
            } else {
                @unlink($item->getPathname());
            }
        }
        @rmdir($path);
    }

    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__.'/../config/titan-connect.php', 'titan-connect');

        $binder = new ConfiguredIntegrationBinder();
        $binder->bind($this->app, ProviderHttpClient::class, 'titan-connect.integrations.provider_http_client', \App\Extensions\TitanConnect\System\Http\LaravelProviderHttpClient::class);
        $binder->bind($this->app, MobilePushGateway::class, 'titan-connect.integrations.mobile_push_gateway', \App\Extensions\TitanConnect\System\Integration\EventMobilePushGateway::class);

        $this->app->singleton(ConfigCredentialVault::class);
        $binder->bind($this->app, CredentialVault::class, 'titan-connect.integrations.credential_vault', \App\Extensions\TitanConnect\System\Security\EncryptedCredentialVault::class);
        $binder->bind($this->app, WorkCoreAuthorizationGateway::class, 'titan-connect.integrations.workcore_authorization_gateway', \App\Extensions\TitanConnect\System\Integration\EventWorkCoreAuthorizationGateway::class);
        $binder->bind($this->app, AttachmentSecurityScanner::class, 'titan-connect.integrations.attachment_security_scanner', \App\Extensions\TitanConnect\System\Security\PendingAttachmentSecurityScanner::class);
        $binder->bind($this->app, ChatbotMessagingBridge::class, 'titan-connect.integrations.chatbot_messaging_bridge', \App\Extensions\TitanConnect\System\Integration\EventChatbotMessagingBridge::class);
        $binder->bind($this->app, MessagingPrivacyHook::class, 'titan-connect.integrations.messaging_privacy_hook', \App\Extensions\TitanConnect\System\Security\NullMessagingPrivacyHook::class);
        $binder->bind($this->app, ReplyAssistant::class, 'titan-connect.integrations.reply_assistant', \App\Extensions\TitanConnect\System\Integration\MagicAiReplyAssistant::class);
        $binder->bind($this->app, VoiceSessionGateway::class, 'titan-connect.integrations.voice_session_gateway', \App\Extensions\TitanConnect\System\Voice\DefaultVoiceSessionGateway::class);
        $binder->bind($this->app, VoiceAgentGateway::class, 'titan-connect.integrations.voice_agent_gateway', \App\Extensions\TitanConnect\System\Security\NullVoiceAgentGateway::class);

        $this->app->singleton(ProviderRegistry::class, static fn ($app): ProviderRegistry => new ProviderRegistry(
            $app->make(ProviderHttpClient::class),
            $app->make(MobilePushGateway::class),
        ));
        $this->app->bind(CompanyContext::class, AuthenticatedCompanyContext::class);
        $this->app->bind(CompanyActorDirectory::class, DatabaseCompanyActorDirectory::class);
        $this->app->bind(RetentionPolicy::class, ConfigRetentionPolicy::class);
        $this->app->bind(MessagingToolGateway::class, DefaultMessagingToolGateway::class);
        $this->app->singleton(TitanConnectNavigation::class);
        $this->app->singleton(TitanConnectPermissionCatalogue::class);
        $this->app->singleton(TitanConnectFeatureCatalogue::class);
        $this->app->singleton(TitanConnectHostManifest::class);
        $this->app->singleton(HostMenuLifecycle::class);
        $this->app->singleton(HostNavigationRegistrar::class);
        $this->app->singleton(MagicAiMenuSynchronizer::class);
        $this->app->singleton(MagicAiDashboardRenderer::class);
    }

    public function boot(): void
    {
        $this->loadViewsFrom(__DIR__.'/../resources/views', 'titan-connect');
        $this->loadMigrationsFrom(__DIR__.'/../database/migrations');
        $this->loadRoutesFrom(__DIR__.'/../routes/web.php');
        $this->loadRoutesFrom(__DIR__.'/../routes/api.php');
        $this->loadRoutesFrom(__DIR__.'/../routes/channels.php');

        // Blueprint-v3 hosts discover extension navigation through contribution registries.
        // Registration is structural only: no authenticated/company state is evaluated here.
        $this->app->make(HostNavigationRegistrar::class)->register();

        Event::listen(InboundMessageReceived::class, ForwardInboundToChatbot::class);
        Event::listen(TeamMessageCreated::class, PushTeamMessage::class);

        // Titan Extension Manager installs extensions from an HTTP request and loads the
        // provider specifically to discover publishable assets. Register publish paths on
        // every boot; only console commands/scheduling remain console-only.
        $configPublish = [
            __DIR__.'/../config/titan-connect.php' => config_path('titan-connect.php'),
        ];
        $this->publishes($configPublish, 'titan-connect-config');
        $this->publishes($configPublish, 'extension');
        $assetPublish = [
            __DIR__.'/../resources/assets' => public_path('vendor/titan-connect'),
        ];
        $this->publishes($assetPublish, 'titan-connect-assets');
        $this->publishes($assetPublish, 'extension');

        if ($this->app->runningInConsole()) {
            $this->commands([DiagnoseTitanConnectCommand::class, CertifyTitanConnectCommand::class, ImportLegacyTeamChatCommand::class, RetryDueDeliveriesCommand::class, SyncTitanConnectHostCommand::class]);
            $this->callAfterResolving(Schedule::class, static function (Schedule $schedule): void {
                $schedule->command('titan-connect:retry-deliveries')->everyMinute()->withoutOverlapping();
            });
        }
    }
}
