<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Contracts;

use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;

interface VerticalDefinitionSourceContract
{
    public function resolve(BusinessProfile $profile): VerticalDefinition;
}
