<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanSignalEngine\System\Data\PulsePercentiles;
use App\Extensions\TitanSignalEngine\System\Data\PulseWindow;
use App\Extensions\TitanSignalEngine\System\Services\PulseAttentionScorer;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;

final class PulseDataTest extends TestCase
{
    public function test_windows_select_intentional_rollup_granularity(): void
    {
        $now = new DateTimeImmutable('2026-08-15T19:58:47+10:00');
        self::assertSame('minute', PulseWindow::fromKey('5m', $now)->granularity);
        self::assertSame('minute', PulseWindow::fromKey('1h', $now)->granularity);
        self::assertSame('hour', PulseWindow::fromKey('24h', $now)->granularity);
        self::assertSame('day', PulseWindow::fromKey('7d', $now)->granularity);
    }

    public function test_percentiles_are_deterministic_nearest_rank(): void
    {
        $stats = PulsePercentiles::summarize([10,20,30,40,50,60,70,80,90,100]);
        self::assertSame(50.0, $stats['p50']);
        self::assertSame(100.0, $stats['p95']);
        self::assertSame(100.0, $stats['p99']);
    }

    public function test_attention_score_exposes_reason_codes(): void
    {
        $score = (new PulseAttentionScorer())->score([
            'critical_count' => 1,
            'dead_letter_count' => 1,
            'missing_receipt_count' => 1,
        ]);
        self::assertContains('critical_signals', $score->reasons);
        self::assertContains('dead_letters', $score->reasons);
        self::assertContains('missing_receipts', $score->reasons);
    }
}
