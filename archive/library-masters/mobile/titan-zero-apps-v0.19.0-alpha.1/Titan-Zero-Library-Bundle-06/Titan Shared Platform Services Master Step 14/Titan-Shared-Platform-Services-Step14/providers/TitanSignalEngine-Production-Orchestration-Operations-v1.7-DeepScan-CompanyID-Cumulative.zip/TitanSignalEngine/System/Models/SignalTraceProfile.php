<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalTraceProfile extends Model
{
    protected $table = 'titan_signal_trace_profiles';
    protected $guarded = [];

    protected $casts = [
        'version' => 'integer',
        'required_event_types' => 'array',
        'ordering_rules' => 'array',
        'terminal_event_types' => 'array',
        'match_event_types' => 'array',
    ];
}
