<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Contracts;

use InvalidArgumentException;

final readonly class WorkerIdentity
{
    public function __construct(
        public int $workerId,
        public int $tenantCompanyId,
        public string $subject,
        public string $publicId,
    ) {
        if ($workerId <= 0 || $tenantCompanyId <= 0 || $subject === '' || $publicId === '') {
            throw new InvalidArgumentException('Worker identity requires positive IDs and non-empty subject/public ID.');
        }
    }
}
