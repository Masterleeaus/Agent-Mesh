# TITAN AI CORE — FULL UPGRADE PROMPT

Use the latest supplied Titan Zero source and this installed scaffold as the source of truth.

## Mission

Upgrade Titan AI Core from scaffold into the foundational governed AI execution kernel for the Titan platform.

Titan AI Core combines the earlier Core Contracts + AI Runtime concepts into one foundational extension while keeping other Titan engines independently owned.

It owns Tier 0 orchestration and the runtime contracts required to safely coordinate the rest of Titan.

It MUST NOT absorb the responsibilities of Titan Signal Engine, Titan Command Bus, Titan Risk Engine, Titan Model Council, Titan Wisdom Engine, Titan Knowledge Authority, Titan Rewind, Titan Governance, Titan AI Workforce, Titan Interaction Engine or domain systems.

## Five-tier boundary

Tier 0 — Titan Orchestrator: Titan AI Core
Tier 1 — Managers: Titan AI Workforce
Tier 2 — Specialists: Titan AI Workforce
Tier 3 — Action Workers: Titan AI Workforce
Tier 4 — Governed capabilities/tools: Titan Command Bus + owning domain extensions

Autonomy, Assurance and Risk are cross-cutting governance dimensions; they are not agent tiers.

## Mandatory architecture

Intent
→ Tier 0 Orchestrator
→ Plan
→ Deterministic Plan Validator
→ State/DAG Simulation
→ AI Workforce delegation
→ Interaction Engine/Wizard
→ Risk/Assurance/Autonomy decisions
→ approvals/handoffs where required
→ Command Bus
→ authoritative domain system
→ receipt
→ Signal
→ Rewind
→ Outcome/Wisdom learning

## Implement

### 1. Shared runtime contracts

Create stable DTO/interfaces/enums for:
- AgentIdentity reference
- CapabilityDefinition reference
- CapabilityRequest reference
- Plan
- PlanStep
- PlanConstraint
- PlanValidationResult
- SimulationResult
- RuntimeContext
- ModelCapabilityProfile
- ModelRouteDecision
- ProviderRouteDecision
- ExecutionIntent
- RuntimeReceipt
- trace_id / correlation_id / causation_id / tenant_company_id

Keep contracts serialization-safe, queue-safe, versioned and forward compatible.

### 2. Tier 0 Orchestrator

The Orchestrator receives intent/context and creates objectives and plans.

It must not directly mutate CRM/domain state.
It must not self-authorize.
It must not bypass Workforce, Risk, Assurance, Autonomy or Command Bus.

Outputs must be structured plans rather than free-form action text.

### 3. Plan Validator + DAG Engine

Implement deterministic validation before any plan can be delegated for execution.

Use:
- generic workflow DAGs
- Vertical Engine constraints
- domain invariants
- capability preconditions
- dependency ordering
- forbidden transitions

Reject plans that would create invalid business states.

Return structured violations such as:
- INVOICE_BEFORE_COMPLETION
- DISPATCH_CANCELLED_JOB
- DUPLICATE_BOOKING
- MISSING_DEPENDENCY
- CAPABILITY_SEQUENCE_INVALID
- JURISDICTION_REQUIREMENT_UNRESOLVED

Fail closed if validation infrastructure is unavailable.

### 4. Plan simulation

Before execution, simulate proposed transitions against current state/read models.

Detect:
- double booking
- conflicting mutations
- duplicate commands
- orphaned records
- impossible end states
- missing technician/asset/service dependencies
- stale entity versions
- invalid cross-division sequencing

Simulation must never mutate production state.

### 5. Model/provider routing

Route models by:
- task capability
- privacy
- local/on-device availability
- BYO provider preference
- latency
- cost
- context length
- risk ceiling
- Assurance requirements
- observed calibration

Prefer local/private routes where capable and policy permits.

### 6. Model governance

Track provider/model/version/capability profiles.

Support:
- candidate
- shadow
- low-risk rollout
- medium-risk rollout
- approved
- degraded
- rolled-back

Store calibration and risk ceilings by capability.

Model transitions must not blindly preserve earned authority.
Coordinate affected capability profiles with Autonomy/Assurance.

### 7. Model transition continuity

Implement shadow evaluation and divergence measurement before replacing production models.

Rollback triggers must be policy driven, including:
- Assurance calibration degradation
- rejection rate increase
- policy violation increase
- abnormal divergence
- runtime error increase

### 8. Capability resolution

Titan AI Core may resolve which capability is required but MUST delegate actual domain mutation to Titan Command Bus.

Never become a second mutation path.

### 9. Runtime resilience

Implement:
- idempotency keys
- bounded retry
- exponential backoff
- provider Retry-After support
- timeout classification
- deterministic failure categories
- dead-letter handoff to Workforce/attention systems
- cancellation
- tenant restoration for queues

### 10. Latency optimization

Cache only safely cacheable material:
- workflow/plan schemas
- static capability definitions
- model profiles
- validator definitions

Never cache authorization in a way that bypasses fresh governance when context changes.

Parallelize independent checks where safe.

### 11. Signal integration

Emit structured Signal events for:
- intent accepted
- plan created
- plan validation started
- plan rejected
- plan validated
- simulation started
- simulation failed
- model selected
- model fallback
- delegation requested
- runtime failure

Signal owns ingestion/observability. AI Core only emits.

### 12. Security and tenancy

Use canonical tenant_company_id.

Queued work must carry immutable tenant/company ID, initiating user where relevant, operation ID, trace/correlation/idempotency IDs.

Never serialize API keys, tokens, service clients or full Eloquent graphs into queues.

No unrestricted hidden chain-of-thought storage. Store structured rationale/reason codes only.

## Hard boundaries

DO NOT implement:
- Signal event store/dashboard here
- Command execution/domain mutations here
- Risk scoring here
- Model Council deliberation engine here (integrate via contract)
- Knowledge scraping here
- Rewind UI here
- Workforce manager/specialist/worker records here
- Vertical content here

## Acceptance tests

1. Invalid plan cannot progress.
2. Validator fails closed when unavailable.
3. Simulation cannot mutate production data.
4. Tier 0 cannot directly execute domain mutation.
5. Duplicate plan/execution requests are idempotent.
6. Tenant A cannot access Tenant B runtime state.
7. Model change produces capability transition telemetry.
8. Runtime can fall back between allowed providers without bypassing policy.
9. Every plan has trace/correlation identifiers.
10. Every runtime transition emits structured, versioned events.

## Installer rules

Preserve the hardened MagicAI extension blueprint conventions:
- legacy extension.json remains exactly five fields
- extension.manifest.json remains authoritative sidecar
- provider register() performs container composition only
- boot() loads views/routes/migrations/contributions
- migrations are forward safe
- uninstall is idempotent
- routes retain explicit authenticated/admin security profiles
- queues restore tenant context

## Done when

Titan AI Core can safely turn intent into a validated, simulated, traceable Tier 0 plan and delegate it to the rest of the Titan constitutional architecture without directly becoming Workforce, Governance, Risk, Signal or Command Bus.
