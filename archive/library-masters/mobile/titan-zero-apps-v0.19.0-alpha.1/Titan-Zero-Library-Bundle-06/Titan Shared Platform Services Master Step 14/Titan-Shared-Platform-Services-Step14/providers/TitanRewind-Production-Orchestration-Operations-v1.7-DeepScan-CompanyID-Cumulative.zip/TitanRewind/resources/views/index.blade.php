@extends('panel.layout.app')
@section('title', 'Titan Rewind')

@section('content')
    @php
        $surface = $surface ?? 'overview';
        $surfaceTitles = [
            'overview' => 'Titan Rewind',
            'traces' => 'Trace Explorer',
            'cases' => 'Investigation Cases',
            'replays' => 'Replay Runs',
            'evidence' => 'Evidence Vault',
            'recovery' => 'Recovery Plans',
        ];
    @endphp
    <a href="#titan-rewind-content" class="sr-only focus:not-sr-only">{{ __('titan-rewind::rewind.accessibility_skip') }}</a>
    <main id="titan-rewind-content" role="main" class="container py-8 space-y-8">
        <div>
            <h1 class="text-2xl font-semibold">{{ $surfaceTitles[$surface] ?? 'Titan Rewind' }}</h1>
            <p class="text-sm opacity-70">Decision reconstruction, forensic integrity, drift detection, snapshot comparison, dependency mapping and mutation-free historical replay.</p>
        </div>

        @if($tenant === null)
            <div class="rounded border p-4">
                Titan Rewind is installed, but this account does not expose an explicit <code>tenant_company_id</code> (or semantic tenant-company method). The UI fails closed rather than guessing a tenant boundary; engine adapters can still use the explicit Rewind contracts.
            </div>
        @else
            @if($surface === 'overview' && $analytics)
                <div class="grid gap-3 md:grid-cols-6">
                    <div class="rounded border p-3"><strong>{{ $analytics['events'] }}</strong><div>Events</div></div>
                    <div class="rounded border p-3"><strong>{{ $analytics['traces'] }}</strong><div>Traces</div></div>
                    <div class="rounded border p-3"><strong>{{ $analytics['open_cases'] }}</strong><div>Open cases</div></div>
                    <div class="rounded border p-3"><strong>{{ $analytics['open_drift'] }}</strong><div>Open drift</div></div>
                    <div class="rounded border p-3"><strong>{{ $analytics['comparison_runs'] }}</strong><div>Comparisons</div></div>
                    <div class="rounded border p-3"><strong>{{ $analytics['evidence_packages'] }}</strong><div>Evidence packages</div></div>
                </div>
                <div><a class="underline" href="{{ route('dashboard.user.titan.rewind.assistant.index') }}">Open Rewind guided assistant</a></div>
                <div class="grid gap-4 md:grid-cols-3">
                    <div class="rounded border p-4"><strong>{{ $traces->count() }}</strong><div>Recent traces</div></div>
                    <div class="rounded border p-4"><strong>{{ $cases->count() }}</strong><div>Recent cases</div></div>
                    <div class="rounded border p-4"><strong>{{ $replays->count() }}</strong><div>Recent replay runs</div></div>
                </div>
            @endif

            @if(in_array($surface, ['overview','traces'], true))
                <section>
                    <h2 class="text-lg font-semibold mb-3">Trace catalogue</h2>
                    <div class="overflow-x-auto"><table class="w-full text-sm"><caption class="sr-only">{{ __('titan-rewind::rewind.table_caption') }}</caption><thead><tr><th class="text-left">Trace</th><th>Events</th><th>Sources</th><th>Integrity</th><th>Forensics</th><th>Drift</th><th>Last event</th></tr></thead><tbody>
                    @forelse($traces as $trace)
                        <tr class="border-t"><td class="py-2"><a href="{{ route('dashboard.user.titan.rewind.traces.show', ['traceId'=>$trace->trace_id]) }}">{{ $trace->trace_id }}</a></td><td class="text-center">{{ $trace->event_count }}</td><td class="text-center">{{ $trace->source_count }}</td><td class="text-center">{{ $trace->integrity_state }}</td><td class="text-center">{{ $trace->forensic_state }}</td><td class="text-center">{{ $trace->open_drift_count }}</td><td class="text-center">{{ optional($trace->last_event_at)->toDateTimeString() }}</td></tr>
                    @empty
                        <tr><td colspan="7" class="py-4 opacity-70">No Rewind traces have been ingested for this tenant yet.</td></tr>
                    @endforelse
                    </tbody></table></div>
                </section>
            @endif

            @if(in_array($surface, ['overview','replays'], true))
                <section>
                    <h2 class="text-lg font-semibold mb-3">Recent replay runs</h2>
                    @forelse($replays as $run)
                        <div class="rounded border p-3 mb-2"><a href="{{ route('dashboard.user.titan.rewind.replay.show',['runUuid'=>$run->run_uuid]) }}"><strong>{{ strtoupper($run->mode) }}</strong> · {{ $run->status }}</a> · trace {{ $run->trace_id }}</div>
                    @empty
                        <p class="opacity-70">No replay or comparison runs yet.</p>
                    @endforelse
                </section>
            @endif

            @if(in_array($surface, ['overview','evidence'], true))
                <section>
                    <h2 class="text-lg font-semibold mb-3">Recent evidence packages</h2>
                    @forelse($evidencePackages as $package)
                        <div class="rounded border p-3 mb-2"><a href="{{ route('dashboard.user.titan.rewind.evidence.show',['packageUuid'=>$package->package_uuid]) }}"><strong>{{ strtoupper($package->package_type) }}</strong> · {{ $package->status }}</a> · trace {{ $package->trace_id }}</div>
                    @empty
                        <p class="opacity-70">No audit or compliance evidence packages yet.</p>
                    @endforelse
                </section>
            @endif

            @if(in_array($surface, ['overview','recovery'], true))
                <section>
                    <h2 class="text-lg font-semibold mb-3">Recent recovery plans</h2>
                    @forelse($recoveryPlans as $plan)
                        <div class="rounded border p-3 mb-2"><a href="{{ route('dashboard.user.titan.rewind.recovery.show',['planUuid'=>$plan->plan_uuid]) }}"><strong>{{ $plan->risk_level }}</strong> · {{ $plan->status }}</a> · {{ $plan->proposed_capability ?: 'compensating capability not defined' }}</div>
                    @empty
                        <p class="opacity-70">No governed recovery plans yet.</p>
                    @endforelse
                </section>
            @endif

            @if(in_array($surface, ['overview','cases'], true))
                <section>
                    <h2 class="text-lg font-semibold mb-3">Investigation cases</h2>
                    @forelse($cases as $case)
                        <div class="rounded border p-3 mb-2 space-y-2">
                            <div><strong>{{ $case->title }}</strong> · {{ $case->severity }} · {{ $case->status }} @if($case->primary_trace_id) · trace {{ $case->primary_trace_id }} @endif</div>
                            <form method="POST" action="{{ route('dashboard.user.titan.rewind.case.evidence.store',['caseUuid'=>$case->case_uuid]) }}" class="flex gap-2 items-center">
                                @csrf
                                <select name="package_type" class="rounded border px-2 py-1 text-sm" aria-label="Evidence package type"><option value="audit">Audit</option><option value="compliance">Compliance</option><option value="forensic">Forensic</option><option value="incident">Incident</option><option value="dispute">Dispute</option></select>
                                <button type="submit" class="rounded border px-3 py-1 text-sm">Generate case evidence</button>
                            </form>
                        </div>
                    @empty
                        <p class="opacity-70">No investigation cases yet.</p>
                    @endforelse
                </section>
            @endif
        @endif
    </main>
@endsection
