<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use App\Extensions\TitanSignalEngine\System\Exceptions\ImmutableRegistryDefinitionException;
use Illuminate\Database\Eloquent\Model;

final class SignalTypeVersion extends Model
{
    protected $table = 'titan_signal_type_versions';
    protected $guarded = [];

    protected $casts = [
        'definition_version' => 'integer',
        'current_schema_version' => 'integer',
        'supported_schema_versions' => 'array',
        'allowed_scopes' => 'array',
        'required_payload_fields' => 'array',
        'optional_payload_fields' => 'array',
        'allow_additional_payload_fields' => 'boolean',
        'allowed_severities' => 'array',
        'registered_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::updating(static function (): never {
            throw new ImmutableRegistryDefinitionException('Signal event type versions are immutable; register a new definition version.');
        });
        static::deleting(static function (): never {
            throw new ImmutableRegistryDefinitionException('Signal event type versions cannot be deleted through the application model.');
        });
    }
}
