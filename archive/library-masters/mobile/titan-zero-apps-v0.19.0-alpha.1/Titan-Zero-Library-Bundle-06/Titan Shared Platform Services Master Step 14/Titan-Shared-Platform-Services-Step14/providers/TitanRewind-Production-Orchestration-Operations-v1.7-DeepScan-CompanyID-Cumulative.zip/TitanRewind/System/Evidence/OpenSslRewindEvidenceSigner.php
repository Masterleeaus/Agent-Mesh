<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Evidence;

use App\Extensions\TitanRewind\System\Contracts\RewindEvidenceSignerContract;
use RuntimeException;

final class OpenSslRewindEvidenceSigner implements RewindEvidenceSignerContract
{
    public function __construct(
        private ?string $privateKeyPath,
        private ?string $publicKeyPath,
        private string $keyId,
    ) {}

    public function available(): bool
    {
        return extension_loaded('openssl')
            && is_string($this->privateKeyPath) && $this->privateKeyPath !== '' && is_readable($this->privateKeyPath)
            && is_string($this->publicKeyPath) && $this->publicKeyPath !== '' && is_readable($this->publicKeyPath)
            && trim($this->keyId) !== '';
    }

    public function sign(string $contentHash): array
    {
        $this->assertHash($contentHash);
        if (!$this->available()) throw new RuntimeException('Titan Rewind evidence signing key is unavailable.');
        $private = openssl_pkey_get_private((string) file_get_contents((string) $this->privateKeyPath));
        if ($private === false) throw new RuntimeException('Titan Rewind evidence private key is invalid.');
        $signature = '';
        if (!openssl_sign($contentHash, $signature, $private, OPENSSL_ALGO_SHA256)) {
            throw new RuntimeException('Titan Rewind evidence signing failed.');
        }
        return ['algorithm'=>'openssl-rsa-sha256','key_id'=>$this->keyId,'signature'=>base64_encode($signature)];
    }

    public function verify(string $contentHash, string $signature, string $keyId): bool
    {
        $this->assertHash($contentHash);
        if ($keyId !== $this->keyId || !is_string($this->publicKeyPath) || !is_readable($this->publicKeyPath)) return false;
        $decoded = base64_decode($signature, true);
        if ($decoded === false) return false;
        $public = openssl_pkey_get_public((string) file_get_contents($this->publicKeyPath));
        return $public !== false && openssl_verify($contentHash, $decoded, $public, OPENSSL_ALGO_SHA256) === 1;
    }

    private function assertHash(string $contentHash): void
    {
        if (preg_match('/^[a-f0-9]{64}$/', $contentHash) !== 1) throw new RuntimeException('Titan Rewind evidence content hash is invalid.');
    }
}
