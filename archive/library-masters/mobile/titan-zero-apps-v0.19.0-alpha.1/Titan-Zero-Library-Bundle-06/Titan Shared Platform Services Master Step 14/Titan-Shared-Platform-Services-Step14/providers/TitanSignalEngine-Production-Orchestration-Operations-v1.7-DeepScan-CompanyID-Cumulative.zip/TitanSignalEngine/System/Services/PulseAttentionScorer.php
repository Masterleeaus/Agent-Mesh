<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Data\PulseAttentionScore;

final class PulseAttentionScorer
{
    /** @param array<string,int|float> $metrics */
    public function score(array $metrics): PulseAttentionScore
    {
        $critical = max(0, (int) ($metrics['critical_count'] ?? 0));
        $errors = max(0, (int) ($metrics['error_count'] ?? 0));
        $deadLetters = max(0, (int) ($metrics['dead_letter_count'] ?? 0));
        $stalled = max(0, (int) ($metrics['stalled_trace_count'] ?? 0));
        $missingReceipts = max(0, (int) ($metrics['missing_receipt_count'] ?? 0));
        $subscriptionFailures = max(0, (int) ($metrics['subscription_failure_count'] ?? 0));

        $score = min(100,
            min(30, $critical * 15)
            + min(25, $errors * 5)
            + min(30, $deadLetters * 15)
            + min(30, $stalled * 10)
            + min(24, $missingReceipts * 12)
            + min(16, $subscriptionFailures * 8)
        );

        $reasons = array_values(array_filter([
            $critical > 0 ? 'critical_signals' : null,
            $errors > 0 ? 'error_signals' : null,
            $deadLetters > 0 ? 'dead_letters' : null,
            $stalled > 0 ? 'stalled_traces' : null,
            $missingReceipts > 0 ? 'missing_receipts' : null,
            $subscriptionFailures > 0 ? 'subscription_failures' : null,
        ]));

        $band = $score >= 85 ? 'critical' : ($score >= 65 ? 'high' : ($score >= 40 ? 'medium' : 'low'));

        return new PulseAttentionScore($score, $band, $reasons);
    }
}
