# Uninstall

Document disable/drain/uninstall flow, data retention/export, remote cleanup, active-job reconciliation and repeat safety.
