<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\Chatbot;

use Illuminate\Support\Facades\Log;

final class CrmChatbotCompatibility
{
    public function installed(): bool
    {
        return class_exists(\App\Extensions\Chatbot\System\ChatbotServiceProvider::class);
    }

    public function version(): ?string
    {
        $path = app_path('Extensions/Chatbot/extension.json');
        if (! is_file($path)) return null;
        $json = json_decode((string) file_get_contents($path), true);
        return is_array($json) ? (string) ($json['version'] ?? '') : null;
    }

    public function supported(): bool
    {
        if (! $this->installed()) return false;
        $version = $this->version();
        if ($version === null || trim($version) === '') return false;

        // CRM 1.2 source-contract certification covers Chatbot 6.4.x and 6.5.x.
        // Keep this semver gate bounded to major 6 rather than accepting an untested 7.x API.
        $normalised = preg_match('/^\d+\.\d+$/', $version) ? $version.'.0' : $version;
        $ok = version_compare($normalised, '6.4.0', '>=') && version_compare($normalised, '7.0.0', '<');
        if (! $ok) Log::warning('CRM Chatbot integration disabled: unsupported Chatbot version.', [
            'version'=>$version,
            'constraint'=>(string) config('crm.chatbot.version_constraint','>=6.4 <7.0'),
        ]);
        return $ok;
    }

}
