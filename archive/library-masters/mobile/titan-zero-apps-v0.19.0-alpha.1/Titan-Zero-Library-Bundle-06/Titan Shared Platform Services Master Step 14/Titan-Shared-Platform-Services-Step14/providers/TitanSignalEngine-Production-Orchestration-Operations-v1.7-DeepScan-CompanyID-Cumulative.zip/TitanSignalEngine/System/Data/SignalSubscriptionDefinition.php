<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalSubscriptionDefinition
{
    /**
     * @param list<string> $eventPatterns
     * @param list<int> $acceptedSchemaVersions
     * @param list<string> $scopes
     * @param list<string> $categories
     * @param list<string> $verticals
     * @param list<int> $backoffSeconds
     */
    public function __construct(
        public string $subscriberKey,
        public string $handlerClass,
        public array $eventPatterns,
        public array $acceptedSchemaVersions,
        public array $scopes = ['tenant', 'system'],
        public array $categories = [],
        public array $verticals = [],
        public string $queue = 'titan-signal-engine',
        public int $maxAttempts = 5,
        public array $backoffSeconds = [1, 5, 30, 120],
        public int $timeoutSeconds = 30,
        public string $status = 'active',
        public int $definitionVersion = 1,
        public ?string $ownerSource = null,
        public ?string $ownerServiceId = null,
        public ?string $registrarServiceId = null,
        public ?string $registeredAt = null,
    ) {
        if (! preg_match('/^[a-z0-9][a-z0-9._-]{1,159}$/', $this->subscriberKey)) {
            throw new InvalidArgumentException('subscriber_key must be a stable lowercase identifier.');
        }
        if ($this->handlerClass === '') {
            throw new InvalidArgumentException('handler_class is required.');
        }
        if ($this->eventPatterns === [] || in_array('*', $this->eventPatterns, true)) {
            throw new InvalidArgumentException('Subscriptions must declare one or more bounded event patterns; unrestricted * is forbidden.');
        }
        foreach ($this->eventPatterns as $pattern) {
            if (! is_string($pattern) || ! preg_match('/^[a-z0-9][a-z0-9._-]*(?:\.\*)?$/', $pattern)) {
                throw new InvalidArgumentException('event_patterns entries must be exact event types or a suffix wildcard such as command.*.');
            }
        }
        if ($this->acceptedSchemaVersions === []) {
            throw new InvalidArgumentException('accepted_schema_versions cannot be empty.');
        }
        foreach ($this->acceptedSchemaVersions as $version) {
            if (! is_int($version) || $version < 1) {
                throw new InvalidArgumentException('accepted_schema_versions must contain positive integers.');
            }
        }
        foreach ($this->scopes as $scope) {
            if (! in_array($scope, ['tenant', 'system'], true)) {
                throw new InvalidArgumentException('Subscription scopes must be tenant or system.');
            }
        }
        if ($this->queue === '') {
            throw new InvalidArgumentException('queue is required.');
        }
        if ($this->timeoutSeconds < 1 || $this->timeoutSeconds > 3600) {
            throw new InvalidArgumentException('timeout_seconds must be between 1 and 3600.');
        }
        if (! in_array($this->status, ['active', 'paused', 'disabled'], true)) {
            throw new InvalidArgumentException('Subscription status must be active, paused, or disabled.');
        }
        if ($this->definitionVersion < 1) {
            throw new InvalidArgumentException('Subscription definition_version must be positive.');
        }
        new SignalRetryPolicy($this->maxAttempts, $this->backoffSeconds);
    }

    /** @param array<string,mixed> $input */
    public static function fromArray(array $input): self
    {
        return new self(
            subscriberKey: trim((string) ($input['subscriber_key'] ?? '')),
            handlerClass: trim((string) ($input['handler_class'] ?? '')),
            eventPatterns: array_values((array) ($input['event_patterns'] ?? [])),
            acceptedSchemaVersions: array_values(array_map('intval', (array) ($input['accepted_schema_versions'] ?? []))),
            scopes: array_values((array) ($input['scopes'] ?? ['tenant', 'system'])),
            categories: array_values((array) ($input['categories'] ?? [])),
            verticals: array_values((array) ($input['verticals'] ?? [])),
            queue: trim((string) ($input['queue'] ?? (function_exists('config') ? config('titan-signal-engine.queue', 'titan-signal-engine') : 'titan-signal-engine'))),
            maxAttempts: (int) ($input['max_attempts'] ?? 5),
            backoffSeconds: array_values(array_map('intval', (array) ($input['backoff_seconds'] ?? [1, 5, 30, 120]))),
            timeoutSeconds: (int) ($input['timeout_seconds'] ?? 30),
            status: trim((string) ($input['status'] ?? 'active')),
            definitionVersion: max(1, (int) ($input['definition_version'] ?? 1)),
            ownerSource: self::nullableString($input['owner_source'] ?? null),
            ownerServiceId: self::nullableString($input['owner_service_id'] ?? null),
            registrarServiceId: self::nullableString($input['registrar_service_id'] ?? null),
            registeredAt: self::nullableString($input['registered_at'] ?? null),
        );
    }

    public function matches(string $eventType, int $schemaVersion, string $scope, ?string $category, ?string $vertical): bool
    {
        if ($this->status !== 'active' || ! in_array($schemaVersion, $this->acceptedSchemaVersions, true)) {
            return false;
        }
        if (! in_array($scope, $this->scopes, true)) {
            return false;
        }
        if ($this->categories !== [] && ($category === null || ! in_array($category, $this->categories, true))) {
            return false;
        }
        if ($this->verticals !== [] && ($vertical === null || ! in_array($vertical, $this->verticals, true))) {
            return false;
        }

        foreach ($this->eventPatterns as $pattern) {
            if ($pattern === $eventType) {
                return true;
            }
            // Internal delivery-failure telemetry requires an explicit subscription.
            // Prefix wildcards cannot consume it, preventing recursive failure storms.
            if ($eventType === 'signal.subscription.failed') {
                continue;
            }
            if (str_ends_with($pattern, '.*') && str_starts_with($eventType, substr($pattern, 0, -1))) {
                return true;
            }
        }
        return false;
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'subscriber_key' => $this->subscriberKey,
            'handler_class' => $this->handlerClass,
            'event_patterns' => $this->eventPatterns,
            'accepted_schema_versions' => $this->acceptedSchemaVersions,
            'scopes' => $this->scopes,
            'categories' => $this->categories,
            'verticals' => $this->verticals,
            'queue' => $this->queue,
            'max_attempts' => $this->maxAttempts,
            'backoff_seconds' => $this->backoffSeconds,
            'timeout_seconds' => $this->timeoutSeconds,
            'status' => $this->status,
            'definition_version' => $this->definitionVersion,
            'owner_source' => $this->ownerSource,
            'owner_service_id' => $this->ownerServiceId,
            'registrar_service_id' => $this->registrarServiceId,
            'registered_at' => $this->registeredAt,
        ];
    }

    private static function nullableString(mixed $value): ?string
    {
        if ($value === null || $value === '') return null;
        return trim((string) $value);
    }
}

