<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_governance_policy_decisions')) {
            Schema::table('titan_governance_policy_decisions', function (Blueprint $table): void {
                if (!Schema::hasColumn('titan_governance_policy_decisions', 'operation_id')) $table->string('operation_id', 80)->nullable();
                if (!Schema::hasColumn('titan_governance_policy_decisions', 'subject_type')) $table->string('subject_type', 120)->nullable();
                if (!Schema::hasColumn('titan_governance_policy_decisions', 'subject_id')) $table->string('subject_id', 191)->nullable();
                if (!Schema::hasColumn('titan_governance_policy_decisions', 'action')) $table->string('action', 40)->nullable();
                if (!Schema::hasColumn('titan_governance_policy_decisions', 'payload_hash')) $table->char('payload_hash', 64)->nullable();
                if (!Schema::hasColumn('titan_governance_policy_decisions', 'command_status')) $table->string('command_status', 40)->nullable();
                if (!Schema::hasColumn('titan_governance_policy_decisions', 'command_receipt_ref')) $table->string('command_receipt_ref', 191)->nullable();
                if (!Schema::hasColumn('titan_governance_policy_decisions', 'authoritative_receipt_ref')) $table->string('authoritative_receipt_ref', 191)->nullable();
                if (!Schema::hasColumn('titan_governance_policy_decisions', 'write_verified')) $table->boolean('write_verified')->default(false);
                if (!Schema::hasColumn('titan_governance_policy_decisions', 'result_payload')) $table->json('result_payload')->nullable();
            });

            if (!Schema::hasIndex('titan_governance_policy_decisions',['subject_type'])) Schema::table('titan_governance_policy_decisions', fn (Blueprint $table) => $table->index('subject_type', 'tgov_policy_subject_type_idx'));
            if (!Schema::hasIndex('titan_governance_policy_decisions',['subject_id'])) Schema::table('titan_governance_policy_decisions', fn (Blueprint $table) => $table->index('subject_id', 'tgov_policy_subject_id_idx'));
            if (!Schema::hasIndex('titan_governance_policy_decisions',['action'])) Schema::table('titan_governance_policy_decisions', fn (Blueprint $table) => $table->index('action', 'tgov_policy_action_idx'));
            if (!Schema::hasIndex('titan_governance_policy_decisions',['payload_hash'])) Schema::table('titan_governance_policy_decisions', fn (Blueprint $table) => $table->index('payload_hash', 'tgov_policy_payload_hash_idx'));
            if (!Schema::hasIndex('titan_governance_policy_decisions',['command_status'])) Schema::table('titan_governance_policy_decisions', fn (Blueprint $table) => $table->index('command_status', 'tgov_policy_command_status_idx'));
            if (!Schema::hasIndex('titan_governance_policy_decisions',['command_receipt_ref'])) Schema::table('titan_governance_policy_decisions', fn (Blueprint $table) => $table->index('command_receipt_ref', 'tgov_policy_command_receipt_idx'));
            if (!Schema::hasIndex('titan_governance_policy_decisions',['authoritative_receipt_ref'])) Schema::table('titan_governance_policy_decisions', fn (Blueprint $table) => $table->index('authoritative_receipt_ref', 'tgov_policy_auth_receipt_idx'));
            if (!Schema::hasIndex('titan_governance_policy_decisions',['write_verified'])) Schema::table('titan_governance_policy_decisions', fn (Blueprint $table) => $table->index('write_verified', 'tgov_policy_write_verified_idx'));
            if (!Schema::hasIndex('titan_governance_policy_decisions',['tenant_company_id','operation_id'],'unique')) Schema::table('titan_governance_policy_decisions', fn (Blueprint $table) => $table->unique(['tenant_company_id', 'operation_id'], 'tgov_policy_tenant_operation_uq'));
        }

        if (Schema::hasTable('titan_governance_escalations')) {
            Schema::table('titan_governance_escalations', function (Blueprint $table): void {
                if (!Schema::hasColumn('titan_governance_escalations', 'version')) $table->unsignedBigInteger('version')->default(1);
                if (!Schema::hasColumn('titan_governance_escalations', 'resolution_action')) $table->string('resolution_action', 40)->nullable();
                if (!Schema::hasColumn('titan_governance_escalations', 'last_decision_id')) $table->string('last_decision_id', 80)->nullable();
                if (!Schema::hasColumn('titan_governance_escalations', 'last_command_receipt_ref')) $table->string('last_command_receipt_ref', 191)->nullable();
            });

            if (!Schema::hasIndex('titan_governance_escalations',['version'])) Schema::table('titan_governance_escalations', fn (Blueprint $table) => $table->index('version', 'tgov_esc_version_idx'));
            if (!Schema::hasIndex('titan_governance_escalations',['resolution_action'])) Schema::table('titan_governance_escalations', fn (Blueprint $table) => $table->index('resolution_action', 'tgov_esc_resolution_action_idx'));
            if (!Schema::hasIndex('titan_governance_escalations',['last_decision_id'])) Schema::table('titan_governance_escalations', fn (Blueprint $table) => $table->index('last_decision_id', 'tgov_esc_last_decision_idx'));
            if (!Schema::hasIndex('titan_governance_escalations',['last_command_receipt_ref'])) Schema::table('titan_governance_escalations', fn (Blueprint $table) => $table->index('last_command_receipt_ref', 'tgov_esc_last_command_receipt_idx'));
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('titan_governance_policy_decisions')) {
            if (Schema::hasIndex('titan_governance_policy_decisions',['tenant_company_id','operation_id'],'unique')) {
                Schema::table('titan_governance_policy_decisions', fn (Blueprint $table) => $table->dropUnique('tgov_policy_tenant_operation_uq'));
            }
            $policyColumns = array_values(array_filter([
                'operation_id', 'subject_type', 'subject_id', 'action', 'payload_hash', 'command_status',
                'command_receipt_ref', 'authoritative_receipt_ref', 'write_verified', 'result_payload',
            ], fn (string $column): bool => Schema::hasColumn('titan_governance_policy_decisions', $column)));
            if ($policyColumns !== []) Schema::table('titan_governance_policy_decisions', fn (Blueprint $table) => $table->dropColumn($policyColumns));
        }

        if (Schema::hasTable('titan_governance_escalations')) {
            $escalationColumns = array_values(array_filter([
                'version', 'resolution_action', 'last_decision_id', 'last_command_receipt_ref',
            ], fn (string $column): bool => Schema::hasColumn('titan_governance_escalations', $column)));
            if ($escalationColumns !== []) Schema::table('titan_governance_escalations', fn (Blueprint $table) => $table->dropColumn($escalationColumns));
        }
    }
};
