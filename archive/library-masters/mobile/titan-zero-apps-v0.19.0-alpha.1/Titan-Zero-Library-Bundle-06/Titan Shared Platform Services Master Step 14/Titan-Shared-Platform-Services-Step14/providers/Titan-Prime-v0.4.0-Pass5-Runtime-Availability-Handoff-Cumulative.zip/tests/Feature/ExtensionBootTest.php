<?php

declare(strict_types=1);

namespace Tests\Feature;

use PHPUnit\Framework\TestCase;

final class ExtensionBootTest extends TestCase
{
    public function test_manifest_matches_domain_core_release(): void
    {
        $manifest = json_decode(
            (string) file_get_contents(__DIR__ . '/../../extension.manifest.json'),
            true,
            flags: JSON_THROW_ON_ERROR
        );

        self::assertSame('titan-prime', $manifest['key']);
        self::assertSame('0.4.0', $manifest['version']);
        self::assertSame('2.2', $manifest['schema_version']);
        self::assertSame('strategic-orchestrator', $manifest['architecture']['profile']);
        self::assertContains('signal-aware', $manifest['architecture']['modifiers']);
        self::assertContains('ai-enabled', $manifest['architecture']['modifiers']);
        self::assertContains('autonomy-aware', $manifest['architecture']['modifiers']);
        self::assertSame('titan.production.core.v1', $manifest['architecture']['production_core']);
        self::assertContains('prime.domain', $manifest['capabilities']);
        self::assertContains('prime.mission.lifecycle', $manifest['capabilities']);
        self::assertContains('prime.mission.persistence', $manifest['capabilities']);
        self::assertContains('prime.mission.idempotency', $manifest['capabilities']);
        self::assertContains('prime.mission.optimistic-locking', $manifest['capabilities']);
        self::assertContains('prime.engine-gateway', $manifest['capabilities']);
        self::assertContains('prime.engine-gateway.fail-closed', $manifest['capabilities']);
        self::assertContains('prime.gateway.risk', $manifest['capabilities']);
        self::assertContains('prime.gateway.governance', $manifest['capabilities']);
        self::assertContains('titan_prime_mission_operations', $manifest['database']['owned_tables']);
        self::assertFalse($manifest['queues']['used']);
    }

    public function test_required_domain_files_are_packaged(): void
    {
        foreach ([
            'System/Domain/Entities/PrimeMission.php',
            'System/Domain/Entities/PrimeObjective.php',
            'System/Domain/Entities/PrimeProposal.php',
            'System/Domain/Entities/PrimeCheckpoint.php',
            'System/Domain/ValueObjects/PrimeBudget.php',
            'System/Domain/Entities/PrimeApproval.php',
            'System/Domain/Entities/PrimeDelegation.php',
            'System/Domain/Entities/PrimeDecision.php',
            'System/Domain/Entities/PrimeObservation.php',
            'System/Domain/Entities/PrimeOutcome.php',
            'System/Domain/Entities/PrimeReceipt.php',
            'System/Domain/State/PrimeMissionStateMachine.php',
            'System/Persistence/Contracts/PrimeMissionRepositoryContract.php',
            'System/Persistence/Repositories/DatabasePrimeMissionRepository.php',
            'System/Persistence/Data/PrimeMissionSnapshot.php',
            'System/Persistence/Data/PrimeMissionWriteReceipt.php',
            'System/Gateways/Contracts/EngineBridgeContract.php',
            'System/Gateways/Bridges/FailClosedEngineBridge.php',
            'System/Gateways/Services/AiCoreGateway.php',
            'System/Gateways/Services/RiskGateway.php',
            'System/Gateways/Services/GovernanceGateway.php',
            'System/Gateways/Services/RewindGateway.php',
        ] as $relativePath) {
            self::assertFileExists(__DIR__ . '/../../' . $relativePath);
        }
    }
}
