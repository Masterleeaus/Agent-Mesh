# Operational Health and Outcome Assurance

Version: 0.1.7

This extension participates in the Agent-01 shared operational-health contract.

Provider states are `active`, `degraded`, `missing`, and `quarantined`. Fallback is never implied:
it requires both declared fallback eligibility and policy approval. Quarantined providers always
require attention.

Work ageing is evaluated against an explicit SLA. Breaches surface to the central Workforce
exception queue with severity and priority; customer blocking and safety/compliance risk increase
priority without bypassing authority.

A work item is outcome-assured only when its execution receipt, resulting domain state, evidence,
and current authority are all verified. Recovery completion alone is not sufficient.
