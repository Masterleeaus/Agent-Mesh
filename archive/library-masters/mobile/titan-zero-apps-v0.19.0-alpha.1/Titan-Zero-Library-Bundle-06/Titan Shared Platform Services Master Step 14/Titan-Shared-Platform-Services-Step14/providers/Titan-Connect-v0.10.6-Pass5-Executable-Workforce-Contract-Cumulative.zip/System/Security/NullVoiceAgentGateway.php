<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use App\Extensions\TitanConnect\System\Contracts\VoiceAgentGateway;
use RuntimeException;

final class NullVoiceAgentGateway implements VoiceAgentGateway
{
    private function unavailable(): never { throw new RuntimeException('Voice agent integration is not configured.'); }
    public function create(array $config): array { $this->unavailable(); }
    public function update(string $agentId, array $config): array { $this->unavailable(); }
    public function delete(string $agentId): void { $this->unavailable(); }
    public function voices(): array { $this->unavailable(); }
    public function addKnowledge(string $type, mixed $content, ?string $name = null): array { $this->unavailable(); }
    public function removeKnowledge(string $documentId): void { $this->unavailable(); }
}
