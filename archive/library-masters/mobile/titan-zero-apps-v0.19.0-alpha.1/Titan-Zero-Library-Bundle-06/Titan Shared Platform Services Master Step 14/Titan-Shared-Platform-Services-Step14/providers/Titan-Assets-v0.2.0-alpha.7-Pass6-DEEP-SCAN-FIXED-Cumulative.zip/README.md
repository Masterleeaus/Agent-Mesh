# Titan Assets 0.2.0-alpha.2

Titan Assets is the authoritative Titan Zero domain for **individually tracked physical assets**. This release is the full donor-convergence build created from the supplied Asset/Premises team package and the existing Titan Locker asset surface.

## Included asset functionality

- Overview/dashboard and unified Asset Register for tools, equipment and vehicles.
- Create, read, edit and remove asset records; image upload/removal; documents; types and categories.
- Asset tag/reference generation, QR token identity and company-configurable prefixes.
- Tool/equipment lending, issue, return and complete history.
- Quantity allocations with partial/full revocation and generated allocation/revocation references.
- QR/scan operations: issue, return, report damage/status, send to maintenance, complete maintenance, allocate and revoke.
- Maintenance scheduling, reference numbers, priority, assignment, notes, next-due state and configurable assignment/sent-for-maintenance notifications.
- Repair orders with stages, assignment, supplier/location/work-order references, root cause, parts, parts/labour/total costs, warranty state and repair count.
- Repair templates and downtime aggregation/reporting.
- Equipment warranties, claims/costs, warranty profiles and computed expiry dates.
- Fleet register/status/service alerts plus mileage logs.
- Location equipment register and equipment check-in/check-out events.
- Customer-asset projection and asset-to-premises links.
- Lifecycle history, retirement, sale, write-off, valuation and depreciation support.
- Self-healing Assets navigation which adopts existing CRM/Locker asset menu keys instead of duplicating them.

## Domain boundary

Titan Assets does **not** take ownership of stock/SKUs/consumables/WMS/purchasing; those stay in Titan Locker. It also does not become the premises/property authority. From ManagedPremises it imports only the property-to-asset relationship needed to link an asset to a site/premise. Property rooms, keys, hazards, visits, inspections, service plans, contacts, photos and documents remain a premises-domain concern.

## Donor conversion rule

The old donor framework is deliberately not copied wholesale. Duplicated routes, overlapping repair/warranty schemas, `Modules\\*` namespaces, Worksuite helpers, `module_path()`, `FSMCore`/`SystemCore` coupling and legacy menu seeders are rejected. Their useful asset **behaviour** is converged into one Titan-native authority.

## Tenancy

New Titan Assets persistence uses `company_id` as the canonical company boundary. Existing installed `crm_locker_*` asset tables using `tenant_company_id` are preserved and reconciled non-destructively for upgrade compatibility.

## Installation

Install through Titan Extension Manager 1.7.8. Required dependency: CRM `>=1.3.0-alpha.17`. Install Titan Assets before the matching Titan Locker authority-convergence package.

Static/package certification cannot prove live Laravel/MySQL/browser behaviour. The live Extension Manager install remains the host-runtime gate.
