# Authorization Matrix

Pass 3 resolves identity from the **trusted authenticated principal** supplied by the MagicAI/Titan host. Tenant, actor ID, actor type, permissions and authority are never trusted from plan/request payload fields.

| Surface / operation | Required capability | Tenant rule | Notes |
|---|---|---|---|
| User AI Core overview | `ai.core.read` | Authenticated principal tenant only | Request identity overrides are rejected. |
| Super Admin AI Core | `ai.core.admin` | Platform-admin middleware + trusted principal | Menu visibility does not replace route authorization. |
| Super Admin health | `ai.core.health.read` | Platform-admin middleware + trusted principal | Read-only operational health. |
| Future plan creation | `ai.core.plan.create` | Runtime tenant must equal trusted principal tenant | No executable plan endpoint exists in Pass 3. |

## Security invariants

- `tenant_company_id` comes from approved attributes on the authenticated host principal, not the request or generated plan.
- `actor_id` and `actor_type` come from the authenticated principal. Any conflicting payload claim is rejected.
- All Core-owned plan reads/writes are tenant scoped.
- Tenant model profiles do not fall back to global profiles unless the caller explicitly permits global fallback.
- A model profile owned by another tenant is never eligible.
- Capability checks fail closed when the host principal does not expose/allow the requested capability.
- Queue work remains disabled, but Pass 3 provides a restoration guard that future queued jobs must invoke before touching tenant state.
