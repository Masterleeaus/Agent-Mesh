<?php
namespace App\Extensions\Crm\System\AI;
use App\Extensions\Crm\System\Contracts\CrmAssistantChatServiceContract;
final class CrmAssistantChatService implements CrmAssistantChatServiceContract {
 public function templateType(): string { return 'crmAssistant'; }
 public function systemPrompt(array $context=[]): string { return 'You are the CRM Assistant. Use authorised CRM context only. Never claim a record was changed unless an approved CRM action succeeded.'; }
}
