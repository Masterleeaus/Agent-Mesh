# Titan Rewind Runtime States

Titan Rewind stores its operator-selected runtime state in `titan_rewind_runtime_state`. The global state is durable across web and queue worker restarts.

| State | New work | In-flight work | Health meaning |
|---|---|---|---|
| `ACTIVE` | accepted | completes | healthy unless a dependency degrades |
| `DEGRADED` | accepted subject to backpressure | completes | degraded |
| `MAINTENANCE` | rejected | may complete only where already running | maintenance |
| `DRAINING` | rejected | explicitly allowed to complete | draining |
| `DISABLED` | rejected | rejected | disabled |
| `UNAVAILABLE` | rejected | rejected | unavailable |
| `UNINSTALLING` | rejected | rejected | disabled/uninstall transition |

The Super Admin Rewind surface can change runtime state and records the acting user and reason. `DRAINING` is the normal pre-maintenance state: it stops new replay work while allowing existing jobs to reach a terminal state.

Backpressure is evaluated in addition to runtime state. A runtime state never increases authority or permits production mutation.
