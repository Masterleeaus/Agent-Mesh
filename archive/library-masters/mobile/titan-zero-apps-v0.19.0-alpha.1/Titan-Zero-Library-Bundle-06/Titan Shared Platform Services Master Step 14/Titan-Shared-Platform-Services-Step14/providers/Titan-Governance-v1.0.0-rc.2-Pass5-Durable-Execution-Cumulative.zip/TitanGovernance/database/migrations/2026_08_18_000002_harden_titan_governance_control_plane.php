<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_governance_views')) {
            Schema::table('titan_governance_views', function (Blueprint $table): void {
                if (!Schema::hasColumn('titan_governance_views','causation_id')) $table->string('causation_id',64)->nullable()->index();
                if (!Schema::hasColumn('titan_governance_views','root_causation_id')) $table->string('root_causation_id',64)->nullable()->index();
                if (!Schema::hasColumn('titan_governance_views','source_engine')) $table->string('source_engine',120)->nullable()->index();
                if (!Schema::hasColumn('titan_governance_views','source_type')) $table->string('source_type',120)->nullable()->index();
                if (!Schema::hasColumn('titan_governance_views','source_id')) $table->string('source_id',191)->nullable()->index();
                if (!Schema::hasColumn('titan_governance_views','schema_version')) $table->string('schema_version',32)->default('1.0');
                if (!Schema::hasColumn('titan_governance_views','severity')) $table->string('severity',24)->nullable()->index();
                if (!Schema::hasColumn('titan_governance_views','observed_at')) $table->timestamp('observed_at')->nullable()->index();
                if (!Schema::hasColumn('titan_governance_views','expires_at')) $table->timestamp('expires_at')->nullable()->index();
                if (!Schema::hasColumn('titan_governance_views','payload_hash')) $table->char('payload_hash',64)->nullable()->index();
            });
        }

        if (!Schema::hasTable('titan_governance_policy_decisions')) Schema::create('titan_governance_policy_decisions', function (Blueprint $table): void {
            $table->id(); $table->string('decision_id',80)->unique(); $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
            $table->string('policy_key',160)->index(); $table->string('policy_version',80); $table->string('disposition',40)->index();
            $table->json('reason_codes'); $table->json('evidence_refs')->nullable(); $table->string('actor_id',80)->nullable()->index();
            $table->string('trace_id',64)->index(); $table->string('correlation_id',64)->index(); $table->string('causation_id',64)->nullable()->index(); $table->string('root_causation_id',64)->index();
            $table->timestamp('decided_at')->index(); $table->char('record_hash',64)->index(); $table->timestamps();
        });

        if (!Schema::hasTable('titan_governance_authority_constraints')) Schema::create('titan_governance_authority_constraints', function (Blueprint $table): void {
            $table->id(); $table->string('constraint_id',80)->unique(); $table->unsignedBigInteger('tenant_company_id')->index();
            $table->string('agent_id',120)->index(); $table->string('capability',191)->index(); $table->string('capability_variant',120)->nullable();
            $table->string('vertical',120)->nullable()->index(); $table->string('workflow',160)->nullable()->index(); $table->string('context_key',160)->nullable();
            $table->string('disposition',40)->index(); $table->decimal('ceiling_score',5,2)->nullable(); $table->json('reason_codes'); $table->json('evidence_refs')->nullable();
            $table->string('policy_version',80); $table->timestamp('evaluated_at')->index(); $table->timestamp('expires_at')->nullable()->index(); $table->string('trace_id',64)->index(); $table->timestamps();
        });

        if (!Schema::hasTable('titan_governance_escalations')) Schema::create('titan_governance_escalations', function (Blueprint $table): void {
            $table->id(); $table->string('escalation_id',80)->unique(); $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
            $table->string('subject_type',120)->index(); $table->string('subject_id',191)->index(); $table->decimal('risk_score',5,2)->nullable()->index(); $table->unsignedTinyInteger('urgency')->default(50)->index();
            $table->string('status',40)->default('OPEN')->index(); $table->json('reason_codes'); $table->json('evidence_refs')->nullable();
            $table->string('trace_id',64)->index(); $table->string('correlation_id',64)->index(); $table->string('causation_id',64)->nullable()->index(); $table->string('root_causation_id',64)->index();
            $table->timestamp('opened_at')->index(); $table->timestamp('resolved_at')->nullable()->index(); $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_governance_escalations');
        Schema::dropIfExists('titan_governance_authority_constraints');
        Schema::dropIfExists('titan_governance_policy_decisions');
        if (Schema::hasTable('titan_governance_views')) Schema::table('titan_governance_views', function (Blueprint $table): void {
            foreach (['causation_id','root_causation_id','source_engine','source_type','source_id','schema_version','severity','observed_at','expires_at','payload_hash'] as $column) if (Schema::hasColumn('titan_governance_views',$column)) $table->dropColumn($column);
        });
    }
};
