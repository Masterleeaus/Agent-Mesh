<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Persistence\Support;

use App\Extensions\TitanPrime\System\Domain\Entities\PrimeMission;
use App\Extensions\TitanPrime\System\Domain\Enums\PrimeMissionStatus;

final class MissionOperationFingerprint
{
    public static function create(PrimeMission $mission): string
    {
        return self::hash([
            'operation' => 'create',
            'mission' => $mission->toArray(),
        ]);
    }

    public static function transition(
        string $missionId,
        PrimeMissionStatus $expected,
        PrimeMissionStatus $next,
        int $expectedVersion,
    ): string {
        return self::hash([
            'operation' => 'transition',
            'mission_id' => $missionId,
            'expected_status' => $expected->value,
            'next_status' => $next->value,
            'expected_version' => $expectedVersion,
        ]);
    }

    /** @param array<string,mixed> $payload */
    private static function hash(array $payload): string
    {
        return hash('sha256', json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }
}
