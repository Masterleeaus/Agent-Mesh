<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

final class CrmDeferredSignalDeliveryPort implements CrmSignalDeliveryPort
{
    public function available(): bool { return false; }
    public function deliver(array $event): array { return ['status'=>'deferred','reason'=>'titan_signal_unavailable']; }
}
