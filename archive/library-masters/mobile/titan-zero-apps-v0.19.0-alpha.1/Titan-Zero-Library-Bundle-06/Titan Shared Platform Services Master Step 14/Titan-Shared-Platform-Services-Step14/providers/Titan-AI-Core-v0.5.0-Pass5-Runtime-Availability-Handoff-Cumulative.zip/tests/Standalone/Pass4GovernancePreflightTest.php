<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$required = [
    'System/DTO/GovernanceDecision.php',
    'System/DTO/GovernancePreflightRequest.php',
    'System/DTO/GovernancePreflightReport.php',
    'System/Contracts/RiskGatewayContract.php',
    'System/Contracts/AssuranceGatewayContract.php',
    'System/Contracts/AutonomyGatewayContract.php',
    'System/Contracts/GovernancePreflightContract.php',
    'System/Services/GovernancePreflightCoordinator.php',
];
foreach ($required as $relative) {
    if (!is_file($root . '/' . $relative)) {
        fwrite(STDERR, "Missing Pass 4 governance file: {$relative}\n");
        exit(1);
    }
    require_once $root . '/' . $relative;
}

use App\Extensions\TitanAICore\System\Contracts\AssuranceGatewayContract;
use App\Extensions\TitanAICore\System\Contracts\AutonomyGatewayContract;
use App\Extensions\TitanAICore\System\Contracts\RiskGatewayContract;
use App\Extensions\TitanAICore\System\DTO\GovernanceDecision;
use App\Extensions\TitanAICore\System\DTO\GovernancePreflightRequest;
use App\Extensions\TitanAICore\System\Services\GovernancePreflightCoordinator;

final class Pass4RiskGateway implements RiskGatewayContract {
    public function evaluate(GovernancePreflightRequest $request): GovernanceDecision { return GovernanceDecision::allow('risk', 'RISK_ALLOWED', 'Risk accepted the step.'); }
}
final class Pass4AssuranceGateway implements AssuranceGatewayContract {
    public function evaluate(GovernancePreflightRequest $request): GovernanceDecision { return GovernanceDecision::requireEvidence('assurance', 'EVIDENCE_REQUIRED', 'Additional evidence is required.'); }
}
final class Pass4AutonomyGateway implements AutonomyGatewayContract {
    public function evaluate(GovernancePreflightRequest $request): GovernanceDecision { return GovernanceDecision::allow('autonomy', 'AUTHORITY_ALLOWED', 'Autonomy accepted the step.'); }
}

$request = new GovernancePreflightRequest(
    planId: 'plan-1',
    stepId: 'step-1',
    tenantCompanyId: 'company-1',
    actorId: 'actor-1',
    actorType: 'ai_agent',
    authorityLevel: 2,
    capability: 'crm.customer.update',
    traceId: 'trace-1',
    correlationId: 'corr-1',
    causationId: 'cause-1',
    rootCausationId: 'root-1',
    evidenceRefs: [],
);
$report = (new GovernancePreflightCoordinator(new Pass4RiskGateway(), new Pass4AssuranceGateway(), new Pass4AutonomyGateway()))->evaluate($request);
if ($report->state !== 'PENDING_REVIEW' || $report->executable || !$report->requiresHumanReview) {
    fwrite(STDERR, "governance preflight did not convert evidence requirement into pending review\n"); exit(1);
}
if (count($report->decisions) !== 3 || $report->decisionFor('assurance')?->outcome !== 'REQUIRE_EVIDENCE') {
    fwrite(STDERR, "governance preflight did not preserve all engine decisions\n"); exit(1);
}

final class Pass4DenyRiskGateway implements RiskGatewayContract {
    public function evaluate(GovernancePreflightRequest $request): GovernanceDecision { return GovernanceDecision::deny('risk', 'RISK_REJECTED', 'Risk rejected the step.'); }
}
$denied = (new GovernancePreflightCoordinator(new Pass4DenyRiskGateway(), new Pass4AssuranceGateway(), new Pass4AutonomyGateway()))->evaluate($request);
if ($denied->state !== 'PENDING_REVIEW' || $denied->executable || !in_array('RISK_REJECTED', $denied->reasonCodes(), true)) {
    fwrite(STDERR, "risk denial did not fail closed into pending review\n"); exit(1);
}

fwrite(STDOUT, "Pass 4 governance preflight test: PASS\n");
