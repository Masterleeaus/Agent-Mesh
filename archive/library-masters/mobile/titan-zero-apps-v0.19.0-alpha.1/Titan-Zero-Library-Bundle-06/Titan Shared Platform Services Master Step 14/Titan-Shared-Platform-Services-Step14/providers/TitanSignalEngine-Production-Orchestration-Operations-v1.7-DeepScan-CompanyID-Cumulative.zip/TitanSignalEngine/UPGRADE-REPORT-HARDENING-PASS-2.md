# Titan Signal Engine v0.10.0 — Production Hardening Pass 2

## Scope

Registry Governance & Control-Plane Ownership.

## Implemented

- host-attested `SignalRegistryIdentity`
- `SignalRegistryAuthorityContract`
- registry ownership policy
- immutable/versioned event-type definitions
- immutable/versioned subscription definitions
- explicit `register()` versus `evolve()` semantics
- event/subscriber ownership enforcement
- registrar provenance
- registration checksums
- version history APIs
- subscription runtime/quarantine projection
- safe handler quarantine instead of ingestion failure
- subscriber revalidation and uninstall lifecycle
- additive legacy backfill migration
- Blueprint manifest/database ownership updates
- standalone registry-governance test runner
- host-Laravel registry governance integration tests

## Deferred to later hardening passes

- atomic delivery leases/CAS — Pass 3
- registry revision/cache coherence — Pass 4
- archive read path — Pass 5
- transactional prune claims — Pass 6

## Compatibility

This is a pre-1.0 public-contract hardening release. Registry writers must now obtain a trusted registry identity and pass it to `register()`/`evolve()`. Event emission/query contracts are unchanged from v0.9.1.
