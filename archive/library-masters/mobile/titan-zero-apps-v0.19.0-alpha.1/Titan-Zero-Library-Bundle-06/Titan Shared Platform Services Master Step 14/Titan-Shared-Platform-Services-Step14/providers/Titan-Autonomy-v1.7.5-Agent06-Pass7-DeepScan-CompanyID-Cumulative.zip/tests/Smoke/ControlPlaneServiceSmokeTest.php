<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyControlStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;
use App\Extensions\TitanAutonomy\System\Services\LearningExportService;
use App\Extensions\TitanAutonomy\System\Services\LearningResetService;
use App\Extensions\TitanAutonomy\System\Services\LearningSettingsService;
use App\Extensions\TitanAutonomy\System\Services\ManualRegressionService;

function verify2(bool $condition, string $message): void { if (!$condition) throw new RuntimeException($message); }

$query = new class implements AutonomyQueryContract {
    public array $tenants = [];
    public function capabilityStates(int $tenantCompanyId): array { $this->tenants[]=$tenantCompanyId; return [['tenant_company_id'=>$tenantCompanyId,'capability'=>'crm.invoice.issue','workflow_key'=>'completed_job_invoice','current_level'=>'assist']]; }
    public function capabilityState(int $tenantCompanyId, string $capability, string $workflowKey): ?array { $this->tenants[]=$tenantCompanyId; return ['tenant_company_id'=>$tenantCompanyId,'capability'=>$capability,'workflow_key'=>$workflowKey,'current_level'=>'assist']; }
    public function learningEvents(int $tenantCompanyId, ?string $capability=null, ?string $workflowKey=null, int $limit=1000): array { $this->tenants[]=$tenantCompanyId; return [['tenant_company_id'=>$tenantCompanyId,'learning_label'=>'correct']]; }
    public function learningPreferences(int $tenantCompanyId, ?int $userId=null): array { $this->tenants[]=$tenantCompanyId; return []; }
    public function learningSettings(int $tenantCompanyId): array { $this->tenants[]=$tenantCompanyId; return ['user_learning'=>true,'business_learning'=>true,'system_wide_learning'=>false]; }
    public function tenantPolicy(int $tenantCompanyId): ?array { $this->tenants[]=$tenantCompanyId; return null; }
    public function platformPolicy(): ?array { return ['system_wide_learning_permitted'=>false]; }
    public function handshakes(int $tenantCompanyId, ?string $capability=null, ?string $workflowKey=null, int $limit=100): array { $this->tenants[]=$tenantCompanyId; return []; }
    public function regressions(int $tenantCompanyId, ?string $capability=null, ?string $workflowKey=null, int $limit=100): array { $this->tenants[]=$tenantCompanyId; return []; }
};
$store = new class implements AutonomyControlStoreContract {
    public array $ops=[];
    public function saveLearningSettings(int $tenantCompanyId, array $settings, string $policyVersion): void { $this->ops[]=['settings',$tenantCompanyId,$settings]; }
    public function resetCapabilityLearning(int $tenantCompanyId, string $capability, string $workflowKey, string $targetLevel, string $policyVersion): void { $this->ops[]=['reset',$tenantCompanyId,$capability,$workflowKey,$targetLevel]; }
    public function clearPreferences(int $tenantCompanyId, ?int $userId=null): int { $this->ops[]=['clear',$tenantCompanyId,$userId]; return 1; }
    public function lowerCapabilityLevel(int $tenantCompanyId, string $capability, string $workflowKey, string $targetLevel, string $cause, string $policyVersion): void { $this->ops[]=['lower',$tenantCompanyId,$capability,$workflowKey,$targetLevel,$cause]; }
    public function savePlatformPolicy(array $policy, string $policyVersion): void { $this->ops[]=['platform-policy',$policy]; }
    public function saveTenantPolicy(int $tenantCompanyId, array $policy, string $policyVersion): void { $this->ops[]=['tenant-policy',$tenantCompanyId,$policy]; }
};

$export = (new LearningExportService($query))->exportTenant(7);
verify2(($export['tenant_company_id'] ?? null) === 7, 'export must stay inside resolved tenant');
verify2(count($export['learning_events'] ?? []) === 1, 'export must include tenant learning events');
verify2(!in_array(99, $query->tenants, true), 'export must never switch tenant context');

$settings = (new LearningSettingsService($store, 'v1.3'))->save(7, ['user'=>true,'business'=>true,'system'=>true], ['system_wide_learning_permitted'=>false]);
verify2($settings['system'] === false, 'tenant cannot enable system learning when platform disallows it');

(new LearningResetService($store, 'v1.3'))->resetCapability(7, 'crm.invoice.issue', 'completed_job_invoice');
verify2($store->ops[array_key_last($store->ops)][0] === 'reset', 'reset must call scoped control store');
verify2($store->ops[array_key_last($store->ops)][1] === 7, 'reset must use server-resolved tenant');

$regression = new ManualRegressionService($store, 'v1.3');
$denied = $regression->lower(7, 'crm.invoice.issue', 'completed_job_invoice', 'assist', 'auto', 'user_requested');
verify2($denied === false, 'manual control must never increase authority');
$allowed = $regression->lower(7, 'crm.invoice.issue', 'completed_job_invoice', 'auto', 'assist', 'user_requested');
verify2($allowed === true, 'manual control may lower authority');

echo "OK: ControlPlaneServiceSmokeTest\n";
