# Donor Classification

> **v0.6 note:** This document describes the original v0.1/v0.2 embedded donor tree. The seven official Chatbot communications extensions extracted in v0.6 are documented separately in [`DONOR_EXTRACTION_V060.md`](DONOR_EXTRACTION_V060.md). Raw official donor archives are not shipped in the production extension.

The extracted source contained 70 donor files. Every donor file is classified below. **No file under `donor/` is booted by Titan Connect, and the production ZIP excludes the entire donor tree.** The full source/provenance ZIP retains it for traceability.

| Donor file | Classification | Disposition |
|---|---|---|
| `donor/channel-runtime/contracts/AbstractChannel.php` | **MIGRATED** | Channel contract/push/internal transport ideas were consolidated into Titan Connect contracts/providers. |
| `donor/channel-runtime/contracts/ChannelContract.php` | **MIGRATED** | Channel contract/push/internal transport ideas were consolidated into Titan Connect contracts/providers. |
| `donor/channel-runtime/internal-chat/InternalChatChannel.php` | **MIGRATED** | Channel contract/push/internal transport ideas were consolidated into Titan Connect contracts/providers. |
| `donor/channel-runtime/internal-chat/channel.json` | **MIGRATED** | Channel contract/push/internal transport ideas were consolidated into Titan Connect contracts/providers. |
| `donor/channel-runtime/push/PushChannel.php` | **MIGRATED** | Channel contract/push/internal transport ideas were consolidated into Titan Connect contracts/providers. |
| `donor/channel-runtime/push/channel.json` | **MIGRATED** | Channel contract/push/internal transport ideas were consolidated into Titan Connect contracts/providers. |
| `donor/channel-runtime/web-chat/WebChatChannel.php` | **RETAINED-REFERENCE** | Chatbot web conversation ownership stays outside Connect; retained only to understand the old channel abstraction. |
| `donor/channel-runtime/web-chat/channel.json` | **RETAINED-REFERENCE** | Chatbot web conversation ownership stays outside Connect; retained only to understand the old channel abstraction. |
| `donor/chatbot-integration/System/ChatbotServiceProvider.php` | **RETAINED-REFERENCE** | Used to reconstruct inbox/handoff integration; Chatbot-specific controller/view/provider code is not booted. |
| `donor/chatbot-integration/System/Http/Controllers/StaffInbox/StaffInboxController.php` | **RETAINED-REFERENCE** | Used to reconstruct inbox/handoff integration; Chatbot-specific controller/view/provider code is not booted. |
| `donor/chatbot-integration/resources/views/staff-inbox/index.blade.php` | **RETAINED-REFERENCE** | Used to reconstruct inbox/handoff integration; Chatbot-specific controller/view/provider code is not booted. |
| `donor/chatbot-integration/resources/views/staff-inbox/setting.blade.php` | **RETAINED-REFERENCE** | Used to reconstruct inbox/handoff integration; Chatbot-specific controller/view/provider code is not booted. |
| `donor/messaging-core-runtime/System/ChatbotInstagramServiceProvider.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/ChatbotMessengerServiceProvider.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/ChatbotTelegramServiceProvider.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/ChatbotWhatsappServiceProvider.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Contracts/MessagingProviderInterface.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Events/ExtensionEvent.php` | **DEPRECATED** | No active Titan Connect runtime dependency; retained only in the development/provenance source archive. |
| `donor/messaging-core-runtime/System/Helpers/Contracts/BaseMetaHelper.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Helpers/Instagram.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Helpers/SimpleMessengerBot.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Controllers/ChatbotInstagramController.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Controllers/ChatbotInstagramSettingController.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Controllers/ChatbotMessengerController.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Controllers/ChatbotTelegramController.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Controllers/ChatbotWhatsappController.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Controllers/MessagingRuntimeController.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Controllers/Oauth/InstagramController.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Controllers/Webhook/ChatbotInstagramWebhookController.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Controllers/Webhook/ChatbotMessengerWebhookController.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Controllers/Webhook/ChatbotTelegramWebhookController.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Controllers/Webhook/ChatbotTwilioController.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Requests/InstagramChannelStoreRequest.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Requests/MessengerChannelStoreRequest.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Requests/TelegramChannelStoreRequest.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Http/Requests/WhatsappChannelStoreRequest.php` | **RETAINED-REFERENCE** | Chatbot/provider UI/OAuth assumptions were inspected but not promoted as canonical runtime. |
| `donor/messaging-core-runtime/System/Models/OutboundMessage.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Policies/ExtensionAccessPolicy.php` | **DEPRECATED** | No active Titan Connect runtime dependency; retained only in the development/provenance source archive. |
| `donor/messaging-core-runtime/System/Providers/AbstractHttpMessagingProvider.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Providers/InstagramChannelProvider.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Providers/MessageBirdProvider.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Providers/MessengerChannelProvider.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Providers/TelegramChannelProvider.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Providers/TwilioProvider.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Providers/VonageProvider.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/SMSHandler.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Services/ChannelHealthService.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Services/ExtensionHealthService.php` | **DEPRECATED** | No active Titan Connect runtime dependency; retained only in the development/provenance source archive. |
| `donor/messaging-core-runtime/System/Services/InstagramConversationService.php` | **RETAINED-REFERENCE** | Provider-specific Chatbot conversation logic remains reference material; Connect owns transport, not Chatbot AI history. |
| `donor/messaging-core-runtime/System/Services/InstagramService.php` | **RETAINED-REFERENCE** | Provider-specific Chatbot conversation logic remains reference material; Connect owns transport, not Chatbot AI history. |
| `donor/messaging-core-runtime/System/Services/MessagingProviderRegistry.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Services/MessagingRuntime.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Services/MessengerConversationService.php` | **RETAINED-REFERENCE** | Provider-specific Chatbot conversation logic remains reference material; Connect owns transport, not Chatbot AI history. |
| `donor/messaging-core-runtime/System/Services/MessengerService.php` | **RETAINED-REFERENCE** | Provider-specific Chatbot conversation logic remains reference material; Connect owns transport, not Chatbot AI history. |
| `donor/messaging-core-runtime/System/Services/Telegram/TelegramConversationService.php` | **RETAINED-REFERENCE** | Provider-specific Chatbot conversation logic remains reference material; Connect owns transport, not Chatbot AI history. |
| `donor/messaging-core-runtime/System/Services/Telegram/TelegramService.php` | **RETAINED-REFERENCE** | Provider-specific Chatbot conversation logic remains reference material; Connect owns transport, not Chatbot AI history. |
| `donor/messaging-core-runtime/System/Services/Twillio/TwilioConversationService.php` | **RETAINED-REFERENCE** | Provider-specific Chatbot conversation logic remains reference material; Connect owns transport, not Chatbot AI history. |
| `donor/messaging-core-runtime/System/Services/Twillio/TwilioWhatsappService.php` | **RETAINED-REFERENCE** | Provider-specific Chatbot conversation logic remains reference material; Connect owns transport, not Chatbot AI history. |
| `donor/messaging-core-runtime/System/Services/WebhookDispatcher.php` | **MIGRATED** | Reusable transport/registry/delivery/webhook capability was consolidated behind Titan Connect contracts. |
| `donor/messaging-core-runtime/System/Support/ExtensionLogger.php` | **DEPRECATED** | No active Titan Connect runtime dependency; retained only in the development/provenance source archive. |
| `donor/messaging-core-runtime/System/Support/FeatureFlags.php` | **DEPRECATED** | No active Titan Connect runtime dependency; retained only in the development/provenance source archive. |
| `donor/messaging-core-runtime/System/Support/Metrics.php` | **DEPRECATED** | No active Titan Connect runtime dependency; retained only in the development/provenance source archive. |
| `donor/messaging-core-runtime/config/platform-quality.php` | **RETAINED-REFERENCE** | Donor presentation/config is reference-only and excluded from the production package. |
| `donor/messaging-core-runtime/config/whatsapp-channel.php` | **RETAINED-REFERENCE** | Donor presentation/config is reference-only and excluded from the production package. |
| `donor/messaging-core-runtime/database/migrations/2026_07_21_010001_create_chatbot_messaging_runtime_tables.php` | **DEPRECATED** | Donor messaging table ownership is replaced by canonical ext_titan_connect_* persistence. |
| `donor/messaging-core-runtime/extension.json` | **REMOVED** | Donor extension bootstrap metadata is not shipped in the production Titan Connect package. |
| `donor/messaging-core-runtime/resources/assets/icons/whatsapp.svg` | **RETAINED-REFERENCE** | Donor presentation/config is reference-only and excluded from the production package. |
| `donor/messaging-core-runtime/resources/views/channel-card.blade.php` | **RETAINED-REFERENCE** | Donor presentation/config is reference-only and excluded from the production package. |
| `donor/messaging-core-runtime/resources/views/partials/plan-channel-toggle.blade.php` | **RETAINED-REFERENCE** | Donor presentation/config is reference-only and excluded from the production package. |
| `donor/messaging-core-runtime/upgrade.php` | **REMOVED** | Donor extension bootstrap metadata is not shipped in the production Titan Connect package. |

## Legacy Team Chat migrations

The five files under `database/legacy-migrations/` are **DEPRECATED / RETAINED-PROVENANCE**. They are intentionally not auto-loaded. Existing data is handled by `LegacyTeamChatImporter`; new installs use only the canonical Titan Connect migration.

## Production packaging rule

The production archive excludes `donor/`, `tests/donor/`, `database/legacy-migrations/`, extraction inventories, and Superpowers working documents. This makes donor code provenance visible in the source archive without creating a hidden runtime dependency.
