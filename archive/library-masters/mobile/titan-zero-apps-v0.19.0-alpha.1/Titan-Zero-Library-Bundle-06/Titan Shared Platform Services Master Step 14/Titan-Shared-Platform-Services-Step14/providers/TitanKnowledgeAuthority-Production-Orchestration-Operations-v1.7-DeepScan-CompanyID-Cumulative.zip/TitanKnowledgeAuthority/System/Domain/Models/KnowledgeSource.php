<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Models;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Enums\AuthorityClass;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Enums\KnowledgeSourceStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

final class KnowledgeSource extends Model
{
    protected $table = 'titan_knowledge_sources';

    protected $guarded = ['id'];

    protected $casts = [
        'authority_class' => AuthorityClass::class,
        'status' => KnowledgeSourceStatus::class,
        'official_source' => 'boolean',
        'access_policy' => 'array',
        'provenance' => 'array',
        'published_at' => 'immutable_datetime',
        'last_checked_at' => 'immutable_datetime',
        'last_changed_at' => 'immutable_datetime',
        'next_refresh_at' => 'immutable_datetime',
        'stale_after' => 'immutable_datetime',
    ];

    public function jurisdiction(): BelongsTo
    {
        return $this->belongsTo(KnowledgeJurisdiction::class, 'jurisdiction_id');
    }

    public function versions(): HasMany
    {
        return $this->hasMany(KnowledgeSourceVersion::class, 'source_id');
    }
}
