<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use InvalidArgumentException;

/**
 * Immutable runtime dependency/capability readiness projection.
 *
 * Manifest capabilities describe code shipped by the package. This report
 * describes which of those capabilities are actually usable in the current
 * host/container state.
 */
final class RuntimeReadinessReport
{
    /** @var array<string,array{requirement:string,tier:string,configured:bool,bound:bool,callable:bool,available:bool,reason:?string}> */
    private array $dependencies;

    /** @var list<string> */
    private array $declaredCapabilities;

    /** @var array<string,list<string>> */
    private const CAPABILITY_REQUIREMENTS = [
        'nexus.compile' => ['database', 'vertical_engine'],
        'nexus.vertical-engine-adapter' => ['vertical_engine'],
        'nexus.validate' => ['database', 'vertical_engine'],
        'nexus.preview' => ['database', 'vertical_engine'],
        'nexus.compile.diff' => ['database', 'vertical_engine'],
        'nexus.recompile.plan' => ['database', 'vertical_engine'],
        'nexus.provision.plan' => ['database', 'vertical_engine'],
        'nexus.history.lineage' => ['database'],
        'nexus.lifecycle.journal' => ['database'],
        'nexus.lifecycle.traceable-history' => ['database'],
        'nexus.control-centre' => ['database'],
        'nexus.command-bus-adapter' => ['command_bus'],
        'nexus.risk.evaluate' => ['risk'],
        'nexus.governance.authorize' => ['governance'],
        'nexus.assurance.verify' => ['assurance'],
        'nexus.autonomy.authorize' => ['autonomy'],
        'nexus.signal.emit' => ['signal'],
        'nexus.rewind.evidence' => ['rewind'],
        'nexus.provision.execute' => ['database', 'command_bus', 'risk', 'governance', 'assurance', 'signal', 'rewind'],
        'nexus.provision.idempotency' => ['database', 'command_bus'],
        'nexus.provision.receipts' => ['database', 'command_bus', 'risk', 'governance', 'assurance'],
        'nexus.interface.read-model' => ['database', 'interface_runtime'],
    ];

    /** @var array<string,array{requirement:string,tier:string}> */
    private const DEPENDENCY_POLICY = [
        'database' => ['requirement' => 'required', 'tier' => 'core'],
        'vertical_engine' => ['requirement' => 'required', 'tier' => 'core'],
        'command_bus' => ['requirement' => 'required', 'tier' => 'execution'],
        'risk' => ['requirement' => 'required', 'tier' => 'execution'],
        'governance' => ['requirement' => 'required', 'tier' => 'execution'],
        'assurance' => ['requirement' => 'required', 'tier' => 'execution'],
        'signal' => ['requirement' => 'required', 'tier' => 'execution'],
        'rewind' => ['requirement' => 'required', 'tier' => 'execution'],
        'autonomy' => ['requirement' => 'conditional', 'tier' => 'conditional'],
        'knowledge_authority' => ['requirement' => 'conditional', 'tier' => 'conditional'],
        'interface_runtime' => ['requirement' => 'optional', 'tier' => 'optional'],
    ];

    /**
     * @param array<string,bool|array<string,mixed>> $dependencies
     * @param list<string> $declaredCapabilities
     */
    private function __construct(
        array $dependencies,
        private readonly bool $enabled,
        array $declaredCapabilities,
    ) {
        $normalized = [];
        foreach (self::DEPENDENCY_POLICY as $name => $policy) {
            $value = $dependencies[$name] ?? false;
            $normalized[$name] = self::normalizeDependency($name, $policy, $value);
        }
        $this->dependencies = $normalized;

        $caps = [];
        foreach ($declaredCapabilities as $capability) {
            if (!is_string($capability) || trim($capability) === '') {
                throw new InvalidArgumentException('Declared runtime capabilities must be non-empty strings.');
            }
            $caps[] = trim($capability);
        }
        $caps = array_values(array_unique($caps));
        sort($caps, SORT_STRING);
        $this->declaredCapabilities = $caps;
    }

    /**
     * @param array<string,bool|array<string,mixed>> $dependencies
     * @param list<string> $declaredCapabilities
     */
    public static function fromDependencies(array $dependencies, bool $enabled = true, array $declaredCapabilities = []): self
    {
        return new self($dependencies, $enabled, $declaredCapabilities);
    }

    public function status(): string
    {
        if (!$this->enabled) {
            return 'DISABLED';
        }
        foreach ($this->dependencies as $dependency) {
            if ($dependency['tier'] === 'core' && !$dependency['available']) {
                return 'UNAVAILABLE';
            }
        }
        foreach ($this->dependencies as $dependency) {
            if ($dependency['tier'] === 'execution' && !$dependency['available']) {
                return 'DEGRADED';
            }
        }
        return 'HEALTHY';
    }

    public function capabilityAvailable(string $capability): bool
    {
        if (!$this->enabled) {
            return false;
        }
        foreach (self::CAPABILITY_REQUIREMENTS[$capability] ?? [] as $dependency) {
            if (($this->dependencies[$dependency]['available'] ?? false) !== true) {
                return false;
            }
        }
        return true;
    }

    /** @return list<string> */
    public function availableCapabilities(): array
    {
        if (!$this->enabled) {
            return [];
        }
        return array_values(array_filter(
            $this->declaredCapabilities,
            fn (string $capability): bool => $this->capabilityAvailable($capability),
        ));
    }

    /** @return array<string,list<string>> */
    public function unavailableCapabilities(): array
    {
        $result = [];
        foreach ($this->declaredCapabilities as $capability) {
            if ($this->capabilityAvailable($capability)) {
                continue;
            }
            $missing = [];
            foreach (self::CAPABILITY_REQUIREMENTS[$capability] ?? [] as $dependency) {
                if (($this->dependencies[$dependency]['available'] ?? false) !== true) {
                    $missing[] = $dependency;
                }
            }
            if (!$this->enabled && $missing === []) {
                $missing[] = 'extension_disabled';
            }
            $result[$capability] = $missing;
        }
        ksort($result, SORT_STRING);
        return $result;
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        $capabilityReadiness = [];
        foreach ($this->declaredCapabilities as $capability) {
            $missing = [];
            foreach (self::CAPABILITY_REQUIREMENTS[$capability] ?? [] as $dependency) {
                if (($this->dependencies[$dependency]['available'] ?? false) !== true) {
                    $missing[] = $dependency;
                }
            }
            if (!$this->enabled && $missing === []) {
                $missing[] = 'extension_disabled';
            }
            $capabilityReadiness[$capability] = [
                'available' => $this->capabilityAvailable($capability),
                'requires' => self::CAPABILITY_REQUIREMENTS[$capability] ?? [],
                'missing' => $missing,
            ];
        }
        ksort($capabilityReadiness, SORT_STRING);

        $unavailableDependencies = [];
        $missingRequiredDependencies = [];
        foreach ($this->dependencies as $name => $dependency) {
            if (!$dependency['available']) {
                $unavailableDependencies[] = $name;
                if ($dependency['requirement'] === 'required') {
                    $missingRequiredDependencies[] = $name;
                }
            }
        }

        $human = $this->modeAvailable(['database', 'command_bus', 'risk', 'governance', 'assurance', 'signal', 'rewind']);

        return [
            'status' => $this->status(),
            'dependencies' => $this->dependencies,
            'missing_required_dependencies' => $missingRequiredDependencies,
            'unavailable_dependencies' => $unavailableDependencies,
            'available_capabilities' => $this->availableCapabilities(),
            'unavailable_capabilities' => $this->unavailableCapabilities(),
            'capability_readiness' => $capabilityReadiness,
            'execution_modes' => [
                'compile' => $this->modeAvailable(['database', 'vertical_engine']),
                'history' => $this->modeAvailable(['database']),
                'human' => $human,
                'autonomous' => $human && $this->modeAvailable(['autonomy']),
                'knowledge_gated' => $this->modeAvailable(['database', 'vertical_engine', 'knowledge_authority']),
                'interface_runtime' => $this->modeAvailable(['database', 'interface_runtime']),
            ],
        ];
    }

    /** @param list<string> $dependencies */
    private function modeAvailable(array $dependencies): bool
    {
        if (!$this->enabled) {
            return false;
        }
        foreach ($dependencies as $dependency) {
            if (($this->dependencies[$dependency]['available'] ?? false) !== true) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param array{requirement:string,tier:string} $policy
     * @param bool|array<string,mixed> $value
     * @return array{requirement:string,tier:string,configured:bool,bound:bool,callable:bool,available:bool,reason:?string}
     */
    private static function normalizeDependency(string $name, array $policy, bool|array $value): array
    {
        if (is_bool($value)) {
            return [
                'requirement' => $policy['requirement'],
                'tier' => $policy['tier'],
                'configured' => $value,
                'bound' => $value,
                'callable' => $value,
                'available' => $value,
                'reason' => $value ? null : 'unavailable',
            ];
        }

        $configured = ($value['configured'] ?? false) === true;
        $bound = ($value['bound'] ?? false) === true;
        $callable = ($value['callable'] ?? false) === true;
        $available = ($value['available'] ?? ($configured && $bound && $callable)) === true;
        $reason = $value['reason'] ?? null;
        if ($reason !== null && !is_string($reason)) {
            $reason = 'invalid readiness reason';
        }
        if (!$available && ($reason === null || trim($reason) === '')) {
            $reason = match (true) {
                !$configured => 'not_configured',
                !$bound => 'not_bound',
                !$callable => 'not_callable',
                default => 'unavailable',
            };
        }

        return [
            'requirement' => $policy['requirement'],
            'tier' => $policy['tier'],
            'configured' => $configured,
            'bound' => $bound,
            'callable' => $callable,
            'available' => $available,
            'reason' => $available ? null : $reason,
        ];
    }
}
