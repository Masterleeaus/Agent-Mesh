<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalCorrelationContract;
use App\Extensions\TitanSignalEngine\System\Contracts\TraceProfileRegistryContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\TraceEvaluationPolicy;
use App\Extensions\TitanSignalEngine\System\Data\TraceProfile;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use App\Extensions\TitanSignalEngine\System\Models\SignalTraceAssignment;
use App\Extensions\TitanSignalEngine\System\Models\SignalTraceEvaluation;
use DateTimeImmutable;
use DateTimeInterface;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class AutomaticTraceEvaluationService
{
    public function __construct(
        private readonly TraceProfileRegistryContract $profiles,
        private readonly SignalCorrelationContract $correlation,
        private readonly TraceEvaluationPolicy $policy,
    ) {
    }

    public function observe(SignalEvent $event): void
    {
        if (! $this->enabled() || ! Schema::hasTable('titan_signal_trace_assignments')) return;

        $profiles = $this->profiles->matchingEventType((string) $event->event_type, $this->profileLimit());
        foreach ($profiles as $profile) {
            try {
                $assignment = $this->recordObservation($event, $profile);
                $this->evaluateAssignment($assignment);
            } catch (Throwable $exception) {
                Log::error('signal.trace_auto_evaluation_failed', [
                    'trace_id' => (string) $event->trace_id,
                    'profile_key' => $profile->profileKey,
                    'profile_version' => $profile->version,
                    'error_class' => $exception::class,
                ]);
            }
        }
    }

    /** @return array{processed:int,failed:int,closed:int,partial:int} */
    public function evaluateDue(int $limit = 250): array
    {
        if (! $this->enabled() || ! Schema::hasTable('titan_signal_trace_assignments')) {
            return ['processed' => 0, 'failed' => 0, 'closed' => 0, 'partial' => 0];
        }

        $limit = max(1, min($limit, (int) config('titan-signal-engine.trace_evaluation_batch_limit', 250), 2000));
        $rows = SignalTraceAssignment::query()
            ->whereIn('status', ['open', 'partial', 'invalid'])
            ->whereNotNull('next_evaluation_at')
            ->where('next_evaluation_at', '<=', now())
            ->orderBy('next_evaluation_at')
            ->orderBy('id')
            ->limit($limit)
            ->cursor();

        $processed = $failed = $closed = $partial = 0;
        foreach ($rows as $row) {
            try {
                $updated = $this->evaluateAssignment($row);
                $processed++;
                if ($updated->status === 'closed') $closed++;
                if ($updated->status === 'partial') $partial++;
            } catch (Throwable $exception) {
                $failed++;
                $this->recordFailure($row, $exception);
            }
        }

        return compact('processed', 'failed', 'closed', 'partial');
    }

    private function recordObservation(SignalEvent $event, TraceProfile $profile): SignalTraceAssignment
    {
        return DB::transaction(function () use ($event, $profile): SignalTraceAssignment {
            $tenantCompanyId = $event->tenant_company_id === null ? null : (int) $event->tenant_company_id;
            $tenantKey = (int) ($tenantCompanyId ?? 0);
            /** @var SignalTraceAssignment|null $row */
            $row = SignalTraceAssignment::query()
                ->where('trace_id', (string) $event->trace_id)
                ->where('scope', (string) $event->scope)
                ->where('tenant_key', $tenantKey)
                ->where('profile_key', $profile->profileKey)
                ->where('profile_version', $profile->version)
                ->lockForUpdate()
                ->first();

            $occurredAt = $this->date($event->occurred_at);
            $terminalSeen = $profile->isTerminalEventType((string) $event->event_type);
            if ($row === null) {
                return SignalTraceAssignment::query()->create([
                    'trace_id' => (string) $event->trace_id,
                    'correlation_id' => (string) $event->correlation_id,
                    'scope' => (string) $event->scope,
                    'tenant_company_id' => $tenantCompanyId,
                    'tenant_key' => $tenantKey,
                    'profile_key' => $profile->profileKey,
                    'profile_version' => $profile->version,
                    'status' => 'open',
                    'first_event_at' => $occurredAt,
                    'last_event_at' => $occurredAt,
                    'last_event_id' => (string) $event->event_id,
                    'last_event_type' => (string) $event->event_type,
                    'terminal_seen' => $terminalSeen,
                    'next_evaluation_at' => now(),
                    'evaluation_generation' => 0,
                    'failure_count' => 0,
                ]);
            }

            $row->correlation_id = (string) $event->correlation_id;
            if ($row->first_event_at === null || $occurredAt < $this->date($row->first_event_at)) {
                $row->first_event_at = $occurredAt;
            }
            if ($row->last_event_at === null || $occurredAt >= $this->date($row->last_event_at)) {
                $row->last_event_at = $occurredAt;
                $row->last_event_id = (string) $event->event_id;
                $row->last_event_type = (string) $event->event_type;
            }
            $row->terminal_seen = (bool) $row->terminal_seen || $terminalSeen;
            // Any relevant late/offline event reopens a previously closed assignment for re-evaluation.
            if ($row->status === 'closed') $row->status = 'open';
            $row->next_evaluation_at = now();
            $row->save();
            return $row;
        });
    }

    private function evaluateAssignment(SignalTraceAssignment $assignment): SignalTraceAssignment
    {
        $profile = $this->profiles->find((string) $assignment->profile_key, (int) $assignment->profile_version);
        if ($profile === null) {
            $assignment->status = 'disabled';
            $assignment->next_evaluation_at = null;
            $assignment->save();
            return $assignment;
        }

        $context = SignalContext::system('titan-signal-trace-evaluator', 'system', ['signal.system.read', 'signal.tenant.read']);
        $result = $this->correlation->trace(
            (string) $assignment->trace_id,
            $context,
            $assignment->tenant_company_id === null ? null : (int) $assignment->tenant_company_id,
            (string) $assignment->scope,
            $profile->profileKey,
            $profile->version,
            (int) config('titan-signal-engine.trace_evaluation_event_limit', 5000),
        );

        $analysis = (array) ($result['analysis'] ?? []);
        $status = (string) ($analysis['status'] ?? 'partial');
        $historyPartial = ! (bool) ($analysis['history_complete'] ?? false) || ! (bool) ($analysis['cold_history_complete'] ?? true);
        if ($historyPartial && $status !== 'invalid') $status = 'partial';
        $terminalSeen = (bool) $assignment->terminal_seen;
        $delay = $this->policy->delaySeconds($status, $terminalSeen, $historyPartial);
        $fingerprint = hash('sha256', json_encode([
            'profile' => [$profile->profileKey, $profile->version],
            'status' => $status,
            'event_count' => (int) ($analysis['event_count'] ?? 0),
            'missing' => (array) ($analysis['missing_event_types'] ?? []),
            'sequence' => (array) ($analysis['sequence_violations'] ?? []),
            'profile_violations' => (array) ($analysis['profile_violations'] ?? []),
            'history_complete' => ! $historyPartial,
        ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));

        return DB::transaction(function () use ($assignment, $status, $historyPartial, $terminalSeen, $delay, $fingerprint, $analysis, $result): SignalTraceAssignment {
            /** @var SignalTraceAssignment $row */
            $row = SignalTraceAssignment::query()->whereKey($assignment->getKey())->lockForUpdate()->firstOrFail();
            $row->status = $this->policy->isTerminalClosed($status, $terminalSeen, $historyPartial) ? 'closed' : $status;
            $row->last_analysis_status = $status;
            $row->last_evaluated_at = now();
            $row->fresh_until = now()->addSeconds(max(60, (int) config('titan-signal-engine.trace_evaluation_fresh_seconds', 600)));
            $row->next_evaluation_at = $delay === 0 ? null : now()->addSeconds($delay);
            $row->evaluation_generation = (int) $row->evaluation_generation + 1;
            $row->last_fingerprint = $fingerprint;
            $row->last_event_count = (int) ($analysis['event_count'] ?? 0);
            $row->last_sequence_violation_count = count((array) ($analysis['sequence_violations'] ?? []));
            $row->last_missing_event_count = count((array) ($analysis['missing_event_types'] ?? []));
            $row->last_profile_violation_count = count((array) ($analysis['profile_violations'] ?? []));
            $row->failure_count = 0;
            $row->last_error_hash = null;
            $row->save();

            if (! $historyPartial && Schema::hasTable('titan_signal_trace_evaluations')) {
                SignalTraceEvaluation::query()
                    ->where('trace_id', (string) $row->trace_id)
                    ->where('scope', (string) $row->scope)
                    ->where('tenant_key', (int) $row->tenant_key)
                    ->where('profile_key', (string) $row->profile_key)
                    ->where('profile_version', (int) $row->profile_version)
                    ->update([
                        'terminal_seen' => $terminalSeen,
                        'history_complete' => true,
                        'cold_history_complete' => (bool) ($analysis['cold_history_complete'] ?? true),
                        'evaluation_source' => 'automatic',
                        'evaluation_fingerprint' => $fingerprint,
                        'fresh_until' => $row->fresh_until,
                        'last_event_id' => $row->last_event_id,
                        'last_event_at' => $row->last_event_at,
                        'evaluation_generation' => (int) $row->evaluation_generation,
                        'updated_at' => now(),
                    ]);
            }
            return $row;
        });
    }

    private function recordFailure(SignalTraceAssignment $row, Throwable $exception): void
    {
        try {
            $row->failure_count = (int) $row->failure_count + 1;
            $row->last_error_hash = hash('sha256', $exception::class . '|' . $exception->getCode());
            $row->next_evaluation_at = now()->addSeconds(max(60, (int) config('titan-signal-engine.trace_evaluation_failure_retry_seconds', 300)));
            $row->save();
        } catch (Throwable) {
            // Keep evaluation recovery best-effort; immutable Signal ingestion must never depend on this projection.
        }
    }

    private function enabled(): bool
    {
        return (bool) config('titan-signal-engine.trace_evaluation_enabled', true);
    }

    private function profileLimit(): int
    {
        return max(1, min((int) config('titan-signal-engine.trace_profile_match_limit', 64), 256));
    }

    private function date(mixed $value): DateTimeImmutable
    {
        if ($value instanceof DateTimeInterface) return new DateTimeImmutable($value->format(DATE_ATOM));
        return new DateTimeImmutable((string) $value);
    }
}
