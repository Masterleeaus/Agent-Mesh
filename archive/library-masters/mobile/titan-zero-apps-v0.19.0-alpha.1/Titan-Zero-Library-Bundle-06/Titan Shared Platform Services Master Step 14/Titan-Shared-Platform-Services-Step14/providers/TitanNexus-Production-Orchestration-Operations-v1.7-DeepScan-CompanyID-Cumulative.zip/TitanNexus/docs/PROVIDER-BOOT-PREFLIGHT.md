# Provider Boot & Container Wiring Preflight

Pass 7 adds a deterministic package-side preflight for the Titan Nexus Laravel service provider. It is a release gate before live MagicAI/Titan boot certification, not a substitute for that live certification.

The preflight verifies:

- canonical `register()`, zero-argument `boot()`, `registerKey()` and `uninstall()` entrypoints;
- every constructor-injected Nexus `*Contract` discovered in packaged System code has an explicit provider singleton binding;
- config, routes, views, migrations and Interface Runtime contribution are wired from provider boot;
- navigation registration is isolated so menu failures cannot make provider boot fatal;
- route registration is app-scoped and idempotent within a running Laravel application;
- optional/conditional Risk, Governance, Assurance, Signal, Rewind, Autonomy, Knowledge Authority and Interface Runtime configuration paths exist;
- Interface Contribution v1.1 remains packaged and non-empty.

The provider no longer requests an unused HTTP Kernel argument in `boot()`. This removes an unnecessary install/console boot dependency while preserving Laravel service-provider semantics.

Run:

```bash
php tools/provider_boot_preflight.php /path/to/TitanNexus /tmp/provider-boot-preflight.json
```

A `PASS` means the packaged provider/container contract is internally consistent. `live_boot_certified` intentionally remains `false` until the exact ZIP is registered and booted by the target MagicAI/Laravel host.
