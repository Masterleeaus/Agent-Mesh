# Titan Governance Pass 5 — Governance Decision Intelligence Design

## Goal

Add a read-only evidence intelligence layer that reconstructs a Governance decision across its own immutable decision record plus bounded read evidence from Titan Risk, Assurance, Autonomy, Signal, Rewind, Command Bus receipt references, and policy/compliance sources without duplicating those engines or creating a second source of truth.

## Scope

Pass 5 delivers four connected read surfaces:

1. **Decision Timeline** — chronological, tenant-scoped evidence chain anchored on a Governance decision ID.
2. **Delta Viewer** — deterministic field-level comparison between two Governance decision snapshots or two timeline states. It identifies changed values but never invents causality.
3. **Rewind Theater Bridge** — a stable, read-only Governance contract that asks the configured Rewind evidence source for a trace/correlation reconstruction and returns `UNAVAILABLE` when no trusted bridge is bound.
4. **Policy & Compliance Aggregation** — normalized policy/compliance observations from registered decision-evidence sources with freshness, source ownership, policy/version, status, reason codes, evidence references, and expiry.

## Architecture

### Canonical ownership

- Titan Governance owns Governance policy decisions, authority constraints, escalations, and Governance-derived read projections.
- Titan Risk owns risk decisions and risk evidence.
- Titan Assurance owns assurance findings and confidence/evidence decisions.
- Titan Autonomy owns desired/earned/effective authority.
- Titan Signal owns telemetry/events.
- Titan Rewind owns deterministic reconstruction and replay evidence.
- Titan Command Bus owns governed execution receipts/idempotency.
- Source engines remain authoritative; Governance stores only its own decision record and bounded projections.

### Decision evidence adapter boundary

Introduce `GovernanceDecisionEvidenceSourceContract`:

- `key(): string`
- `required(): bool`
- `decisionEvidence(int $tenantCompanyId, string $decisionId, array $context = []): array`

A deterministic registry loads configured source adapters. Default unavailable adapters are explicit and fail closed. Adapters may return only normalized metadata needed for governance inspection; hidden chain-of-thought and unrestricted provider payloads are prohibited.

### Decision timeline

`GovernanceDecisionIntelligence` loads the local tenant-scoped Governance decision, normalizes the immutable decision facts, obtains bounded evidence from registered sources, validates tenant/decision identity when supplied, removes unsafe fields, marks stale/invalid/unavailable sources, and emits a single sorted timeline.

The timeline uses explicit event families such as:

- `governance.decision.recorded`
- `risk.decision.observed`
- `assurance.finding.observed`
- `autonomy.state.observed`
- `signal.event.observed`
- `command.receipt.observed`
- `rewind.trace.observed`
- `policy.control.observed`

No missing event is fabricated.

### Delta Viewer

`GovernanceDeltaViewer` compares two normalized snapshots. It:

- recursively flattens bounded JSON-compatible data;
- ignores volatile transport fields such as `observed_at` by default;
- returns `added`, `removed`, `changed`, and `unchanged_count`;
- includes old/new values for changed paths;
- imposes depth/field/value-length limits;
- never labels a change as cause/effect unless the source explicitly supplies such a relation.

### Policy & compliance aggregation

`GovernancePolicyComplianceProjector` accepts normalized observations from evidence sources and returns:

- overall `HEALTHY`, `DEGRADED`, `NON_COMPLIANT`, or `UNAVAILABLE`;
- policy/control rows with source, policy ID/version, status, severity, reason codes, evidence references, observed/expiry times;
- stale/expired counts;
- deterministic priority ordering.

An unavailable optional compliance source degrades visibility but does not invent non-compliance. Explicit blocking/failed/violated source states produce `NON_COMPLIANT`.

### Rewind Theater

Rewind Theater is a read bridge, not embedded Rewind ownership. It requests reconstruction from the `titan-rewind` decision-evidence source using decision/trace/correlation context. If the source is unavailable, the response is explicit `UNAVAILABLE`. Governance never reconstructs Rewind internals locally.

## Data safety

- Every read is scoped by trusted `tenant_company_id`.
- `decision_id` is resolved against Governance-owned data before cross-engine reads.
- Source-provided tenant/decision IDs that disagree are rejected as `IDENTITY_MISMATCH`.
- Only structured reason codes, evidence references, policy/version metadata, statuses, timestamps, IDs, and bounded summaries are retained/rendered.
- Keys such as `chain_of_thought`, `reasoning`, `prompt`, `raw_prompt`, `raw_response`, `secret`, `token`, `api_key`, `authorization`, and credential-like values are stripped recursively.
- Read surfaces do not execute or mutate business state.

## HTTP/UI

Authenticated tenant routes:

- `GET /decisions/{decisionId}/timeline`
- `GET /decisions/{decisionId}/rewind`
- `GET /decisions/{decisionId}/compliance`
- `POST /decisions/delta` with CSRF and read-rate limiting; payload accepts two decision IDs owned by the same tenant.

The main Governance dashboard gains a recent decisions panel and links into decision intelligence. The detailed decision page shows timeline, policy/compliance, Rewind status, and a bounded delta comparison form.

## Failure handling

- Missing local decision → `NOT_FOUND`.
- Source exception → that source becomes `UNAVAILABLE`; other evidence remains visible.
- Source identity mismatch → source marked `INVALID` and excluded from trusted events.
- Stale/expired observations remain visible with status markers; they are not treated as current evidence.
- Rewind absent → Rewind Theater returns `UNAVAILABLE`, not a fabricated reconstruction.
- No read failure can increase Autonomy or trigger Command Bus.

## Verification

Pass acceptance requires:

- TDD red/green tests for source normalization, timeline ordering, identity mismatch, secret/hidden-reasoning stripping, delta semantics, policy/compliance status, and Rewind fail-closed behavior;
- static wiring tests proving read-only routes and service bindings;
- canonical Manifest 2.2 validation;
- Blueprint architecture scan with zero critical/warning findings;
- MySQL/migration stability scans;
- secret/filesystem scan;
- PHP lint and JSON parse;
- exact Installer 1.7.8 integrity map and fresh-ZIP re-extraction verification.
