# Failure modes

Missing or ambiguous tenant context fails closed. Worker identity ambiguity fails closed. Menu host compatibility failures do not break extension boot and are repairable with host sync. External governance absence blocks governed mutations once those mutations are introduced.
