<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Http\Controllers;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Services\PlatformPolicyService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\View\View as ViewContract;

final class AutonomyAdminController
{
    public function __construct(
        private readonly HostContextBridgeContract $context,
        private readonly AutonomyQueryContract $query,
        private readonly PlatformPolicyService $policies,
    ) {}

    public function index(): ViewContract
    {
        $this->authorise('titan.autonomy.policy.view');
        return view('titan-autonomy::autonomy.admin', [
            'layout' => $this->layout(),
            'policy' => $this->query->platformPolicy() ?? [],
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        $this->authorise('titan.autonomy.policy.manage');
        $this->policies->save([
            'gate_minimums' => [
                'low' => $request->integer('gate_low', 1),
                'medium' => $request->integer('gate_medium', 2),
                'high' => $request->integer('gate_high', 3),
                'critical' => $request->integer('gate_critical', 3),
            ],
            'maximum_level_by_risk' => [
                'low' => $request->string('ceiling_low')->toString(),
                'medium' => $request->string('ceiling_medium')->toString(),
                'high' => $request->string('ceiling_high')->toString(),
                'critical' => $request->string('ceiling_critical')->toString(),
            ],
            'high_trusted_auto_exception' => $request->boolean('high_trusted_auto_exception'),
            'critical_autonomy_exception' => $request->boolean('critical_autonomy_exception'),
            'system_wide_learning_permitted' => $request->boolean('system_wide_learning_permitted'),
        ], $this->context->userId(), $request->header('X-Correlation-ID'));
        return back()->with('titan_autonomy_status', 'Platform autonomy policy updated.');
    }

    private function authorise(string $permission): void
    {
        abort_unless($this->context->isSuperAdmin() && $this->context->can($permission), 403);
    }

    private function layout(): string
    {
        $configured = (string) config('titan-autonomy.view_layout', 'panel.layout.app');
        return View::exists($configured) ? $configured : 'titan-autonomy::autonomy.layout';
    }
}
