# Titan Signal Engine v0.4.0 — Pass 4 Upgrade Report

## Scope

Pass 4 implements Signal Subscriptions & Distribution on top of the cumulative v0.3.0 correlation build.

## Implemented

1. `SignalSubscriberContract` consumer boundary.
2. Persisted subscription registry with event-family, schema-version, scope, category and vertical matching.
3. Rejection of unrestricted wildcard subscriptions.
4. Durable one-row-per-event-per-subscriber delivery ledger.
5. Transaction-coupled event append + delivery projection, with queue dispatch deferred until commit.
6. Laravel Queue transport using at-least-once semantics.
7. Per-subscriber timeout, retry/backoff and dead-letter behavior.
8. Subscriber isolation: one consumer failure cannot change another consumer's delivery state.
9. Queue/worker stale-delivery recovery command and one-minute scheduler hook.
10. Safe error references that avoid storing arbitrary exception messages.
11. Immutable `signal.subscription.failed` telemetry when a delivery reaches terminal dead-letter state.
12. Failure recursion safeguards: failure telemetry cannot recursively produce failure telemetry, and prefix subscriptions cannot implicitly consume it.
13. Duplicate ingestion cannot duplicate delivery rows because `(event_id, subscriber_key)` is unique.
14. Distribution health counts added to `SignalManager`.
15. Host-Laravel integration tests packaged for projection, isolation, retry/DLQ, schema compatibility and duplicate delivery suppression.

## Semantics

Delivery is **at-least-once**. A handler can be invoked again if it completed its external side effect but the worker died before the delivery ledger was marked delivered. Subscribers must therefore make handling idempotent using `event_id`, `delivery_id`, or their own durable idempotency boundary.

## Donor extraction

The donor `SignalDispatcher` and `tz_signal_queue` concepts were mined only for fan-out isolation and delivery-state ideas. The legacy custom queue, whole-event retry semantics, mutable donor events, unauthenticated APIs and shared subscriber failure state were not imported.
