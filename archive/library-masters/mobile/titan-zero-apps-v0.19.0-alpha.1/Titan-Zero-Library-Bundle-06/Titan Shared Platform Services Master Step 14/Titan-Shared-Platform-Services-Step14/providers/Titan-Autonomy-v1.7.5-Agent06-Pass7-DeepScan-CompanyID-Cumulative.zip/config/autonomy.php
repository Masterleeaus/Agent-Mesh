<?php

declare(strict_types=1);

return [
    'policy_version' => 'titan-autonomy-1.6.0-2026-08-11',

    'gate_minimums' => [
        'low' => 1,
        'medium' => 2,
        'high' => 3,
        'critical' => 3,
    ],

    'maximum_level_by_risk' => [
        'low' => 'trusted_auto',
        'medium' => 'trusted_auto',
        'high' => 'auto',
        'critical' => 'semi_auto',
    ],

    'learning' => [
        'user_default' => true,
        'business_default' => true,
        'system_wide_default' => false,
        'system_wide_permitted' => false,
        'learning_event_retention_days' => null,
        'autonomy_evidence_retention_days' => null,
    ],



    'route_prefix' => 'dashboard/titan-autonomy',
    'route_middleware' => ['web', 'auth'],
    'view_layout' => 'panel.layout.app',

    'minor_edit_counts_as_success' => false,

    'delegated_authority' => [
        // Short-lived, server-issued authority envelope. Hard maximum is 300 seconds.
        'ttl_seconds' => 90,
    ],

    'execution' => [
        'interaction_engine_required' => true,
        'command_bus_required' => true,
        'assurance_red_blocks_auto' => true,
        'assurance_amber_requires_review_at_auto' => true,
    ],

    'outcome_reconciliation' => [
        'schedule_enabled' => true,
        'batch_size' => 100,
        // Successful autonomous dispatch is observation only. Positive evidence
        // matures after this window and still requires a deterministic persisted
        // postcondition plus a fresh GREEN Assurance result.
        'window_minutes_by_risk' => [
            'low' => 15,
            'medium' => 60,
            'high' => 240,
            'critical' => null,
        ],
    ],

    'regression' => [
        'reversal' => 'severe',
        'assurance_red' => 'severe',
        'wrong_autonomous_action' => 'severe',
        'authority_breach' => 'severe',
        'material_correction' => 'one_level',
    ],
];
