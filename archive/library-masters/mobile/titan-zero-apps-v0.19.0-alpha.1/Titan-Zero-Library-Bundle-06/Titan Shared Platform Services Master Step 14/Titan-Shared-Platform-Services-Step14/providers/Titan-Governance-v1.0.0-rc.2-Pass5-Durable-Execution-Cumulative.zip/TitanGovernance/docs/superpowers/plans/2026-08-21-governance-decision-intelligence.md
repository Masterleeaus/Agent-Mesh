# Governance Decision Intelligence Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build tenant-scoped Decision Timeline, Delta Viewer, Rewind Theater bridge, and policy/compliance aggregation without duplicating authoritative Titan engine state.

**Architecture:** Add a separate decision-evidence adapter registry alongside the existing live read-source registry. Normalize all cross-engine evidence through one safety service, anchor every view to a Governance-owned tenant-scoped decision, and keep Delta/Rewind/Compliance as read-only derived surfaces.

**Tech Stack:** PHP 8.2+, Laravel 10/MagicAI host contracts, Eloquent, Blade, JSON schemas, standalone PHP contract tests, Titan Extension Blueprint v4.2 Manifest 2.2 / Installer 1.7.8.

**Spec:** `docs/superpowers/specs/2026-08-21-governance-decision-intelligence-design.md`

## Global Constraints

- Preserve `tenant_company_id` as the trusted tenant boundary.
- Preserve Governance as control-plane owner only; do not duplicate Risk/Assurance/Autonomy/Signal/Rewind/Command Bus ownership.
- No direct business-state mutation; all Pass 5 routes are read-only except the CSRF-protected delta comparison request, which performs no persistent mutation.
- Never store or expose unrestricted hidden chain-of-thought, raw prompts, secrets, tokens, credentials, or provider raw responses.
- Cross-engine adapters fail closed and may degrade independently.
- Keep Installer 1.7.8 flat-root packaging and Manifest 2.2 valid.

---

### Task 1: Decision evidence contract and normalization

**Files:**
- Create: `System/Contracts/GovernanceDecisionEvidenceSourceContract.php`
- Create: `System/DecisionIntelligence/GovernanceDecisionEvidenceRegistry.php`
- Create: `System/DecisionIntelligence/UnavailableDecisionEvidenceSource.php`
- Create: `System/DecisionIntelligence/GovernanceEvidenceSanitizer.php`
- Test: `tests/Contract/decision_evidence_contract.php`

**Interfaces:**
- Consumes trusted tenant + Governance decision identifiers.
- Produces deterministic registered evidence sources and recursively sanitized structured evidence.

- [ ] Write a failing standalone test proving duplicate source keys fail, unavailable sources return explicit status, and sensitive/hidden-reasoning keys are removed recursively.
- [ ] Run the test and confirm failure because Pass 5 classes do not exist.
- [ ] Implement the minimal contract, registry, unavailable source, and sanitizer.
- [ ] Run the test and confirm PASS.

### Task 2: Decision timeline and local decision lookup

**Files:**
- Create: `System/Contracts/GovernanceDecisionReadStoreContract.php`
- Create: `System/DecisionIntelligence/GovernanceDecisionReadRepository.php`
- Create: `System/DecisionIntelligence/GovernanceDecisionIntelligence.php`
- Modify: `System/Models/GovernancePolicyDecision.php`
- Test: `tests/Contract/decision_timeline_contract.php`

**Interfaces:**
- Consumes local Governance decision + decision evidence registry.
- Produces `decisionTimeline(int $tenantCompanyId, string $decisionId, array $context=[]): array`.

- [ ] Write failing tests for tenant-scoped decision lookup, chronological ordering, source identity mismatch rejection, source failure isolation, and no fabricated events.
- [ ] Run and confirm RED.
- [ ] Implement repository and timeline service with bounded event normalization.
- [ ] Run and confirm GREEN.

### Task 3: Delta Viewer

**Files:**
- Create: `System/DecisionIntelligence/GovernanceDeltaViewer.php`
- Test: `tests/Contract/delta_viewer_contract.php`

**Interfaces:**
- Consumes two normalized decision/timeline snapshots.
- Produces bounded `added`, `removed`, `changed`, `unchanged_count` output.

- [ ] Write failing tests for recursive field changes, volatile field exclusion, deterministic path ordering, and field/value limits.
- [ ] Run and confirm RED.
- [ ] Implement minimal bounded recursive flatten/compare behavior.
- [ ] Run and confirm GREEN.

### Task 4: Policy/compliance and Rewind Theater

**Files:**
- Create: `System/DecisionIntelligence/GovernancePolicyComplianceProjector.php`
- Create: `System/DecisionIntelligence/GovernanceRewindTheater.php`
- Test: `tests/Contract/policy_compliance_contract.php`
- Test: `tests/Contract/rewind_theater_contract.php`

**Interfaces:**
- Consumes normalized evidence sources.
- Produces policy/compliance status and Rewind reconstruction status.

- [ ] Write failing tests for non-compliance priority, stale/expired observations, optional unavailable sources, and Rewind unavailable/identity-mismatch behavior.
- [ ] Run and confirm RED.
- [ ] Implement projectors with explicit fail-closed statuses.
- [ ] Run and confirm GREEN.

### Task 5: Manager, provider, routes and controllers

**Files:**
- Modify: `System/Contracts/GovernanceManagerContract.php`
- Modify: `System/Services/GovernanceManager.php`
- Modify: `System/TitanGovernanceServiceProvider.php`
- Create: `System/Http/Controllers/DecisionIntelligenceController.php`
- Modify: `routes/user.php`
- Test: `tests/Contract/pass5_wiring_static.php`

**Interfaces:**
- Produces manager methods `decisionTimeline`, `decisionDelta`, `decisionCompliance`, `rewindTheater`, and `recentDecisions`.

- [ ] Write a failing static wiring test asserting provider bindings, manager methods, authenticated routes, POST-only delta, and absence of direct DB/business-mutation calls in controller code.
- [ ] Run and confirm RED.
- [ ] Wire services/controllers/routes.
- [ ] Run and confirm GREEN.

### Task 6: UI and manifest/docs/release gates

**Files:**
- Create: `resources/views/decision.blade.php`
- Modify: `resources/views/index.blade.php`
- Modify: `extension.manifest.json`
- Modify: `extension.json`
- Modify: `config/titan-governance.php`
- Modify: `README.md`, `CHANGELOG.md`, `BLUEPRINT-v4.2-ALIGNMENT-REPORT.md`
- Create: `PASS5-DECISION-INTELLIGENCE-REPORT.md`
- Test: `tests/Contract/pass5_release_contract.php`

**Interfaces:**
- Adds read capabilities `governance.decision-timeline.read`, `governance.decision-delta.read`, `governance.compliance.read`, `governance.rewind-theater.read`.

- [ ] Write failing release-contract assertions for version/capabilities/routes/docs and decision UI safety.
- [ ] Run and confirm RED.
- [ ] Implement UI and metadata changes.
- [ ] Run all standalone tests, PHP lint, JSON parse, Blueprint validators/scanners and package integrity checks.
- [ ] Rebuild SBOM/provenance/inventory/integrity, create cumulative ZIP, fresh-extract it, and rerun the entire gate against packaged bytes.
