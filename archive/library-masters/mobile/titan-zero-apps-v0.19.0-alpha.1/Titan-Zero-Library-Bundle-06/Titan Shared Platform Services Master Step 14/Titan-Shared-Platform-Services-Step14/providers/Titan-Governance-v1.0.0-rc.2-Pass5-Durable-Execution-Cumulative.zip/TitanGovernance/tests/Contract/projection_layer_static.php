<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
$required=[
 '/System/Models/GovernanceProjection.php',
 '/System/Projection/GovernanceProjectionStore.php',
 '/System/Projection/GovernanceProjectionService.php',
 '/database/migrations/2026_08_20_000003_add_governance_projection_fingerprint.php',
];
foreach($required as $file){if(!is_file($root.$file)){fwrite(STDERR,"FAIL: missing {$file}\n");exit(1);}}
$store=(string)file_get_contents($root.'/System/Projection/GovernanceProjectionStore.php');
$migration=(string)file_get_contents($root.'/database/migrations/2026_08_20_000003_add_governance_projection_fingerprint.php');
if(!str_contains($store,'projection_fingerprint')){fwrite(STDERR,"FAIL: projection fingerprint dedupe missing\n");exit(1);}
if(!str_contains($migration,'projection_fingerprint')){fwrite(STDERR,"FAIL: projection fingerprint migration missing\n");exit(1);}
if(str_contains($store,'DB'.'::table')){fwrite(STDERR,"FAIL: projection store bypasses model boundary\n");exit(1);}
echo "PASS: Governance durable projection static contract\n";
