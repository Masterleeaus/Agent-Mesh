# Governance

Pass 4 establishes the Core-side governance boundary without absorbing ownership from Titan Risk, Titan Assurance or Titan Autonomy.

For a consequential step Core constructs a typed `GovernancePreflightRequest` and asks the three gateway contracts independently. Decisions are preserved as structured evidence with one of:

- `ALLOW`
- `DENY`
- `REQUIRE_APPROVAL`
- `REQUIRE_EVIDENCE`
- `DEFER`

Any non-`ALLOW` result produces a non-executable `PENDING_REVIEW` report. A missing/unconnected engine uses an unavailable adapter that returns `DEFER`; Core never substitutes its own risk, assurance or autonomy judgement.

`ApprovalState` represents pending/approved/denied human review state, but Pass 4 does not yet implement the full approval persistence/UI workflow.

Consequential mutation is Command Bus-only. `CommandBusMutationBoundary` refuses dispatch while execution is disabled and also refuses dispatch when governance has not produced an executable `ALLOW` report.
