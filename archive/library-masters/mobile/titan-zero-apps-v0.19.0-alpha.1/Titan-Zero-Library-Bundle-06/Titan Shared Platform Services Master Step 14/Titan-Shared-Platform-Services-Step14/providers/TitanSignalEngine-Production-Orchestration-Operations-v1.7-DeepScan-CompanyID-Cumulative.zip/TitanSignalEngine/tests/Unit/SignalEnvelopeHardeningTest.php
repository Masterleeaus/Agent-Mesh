<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEmitterIdentity;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalSeverity;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

final class SignalEnvelopeHardeningTest extends TestCase
{
    public function test_generated_identifiers_use_uuid_v7_and_root_is_self(): void
    {
        $event = SignalEnvelope::fromArray([
            'event_type' => 'job.started',
            'tenant_company_id' => 10,
            'source' => 'titan-crm',
        ]);

        self::assertSame('7', substr($event->eventId, 14, 1));
        self::assertSame($event->eventId, $event->rootCausationId);
        self::assertSame('1.0', $event->envelopeVersion);
        self::assertSame('sha256', $event->checksumAlgorithm);
    }

    public function test_child_inherits_root_but_can_raise_severity(): void
    {
        $root = SignalEnvelope::fromArray([
            'event_type' => 'command.requested',
            'tenant_company_id' => 10,
            'source' => 'titan-command-bus',
        ]);

        $child = $root->child('risk.assessed', 'titan-risk-engine', [], ['severity' => 'error']);

        self::assertSame($root->eventId, $child->causationId);
        self::assertSame($root->eventId, $child->rootCausationId);
        self::assertSame('error', $child->severity);
    }

    public function test_checksum_verification_detects_tampered_persistence_payload(): void
    {
        $event = SignalEnvelope::fromArray([
            'event_type' => 'job.started',
            'tenant_company_id' => 10,
            'source' => 'titan-crm',
            'payload' => ['job_id' => 5],
        ]);

        $tampered = SignalEnvelope::fromPersistenceArray([
            ...$event->toArray(),
            'payload' => ['job_id' => 999],
            'checksum' => $event->checksum,
        ]);

        self::assertFalse($tampered->verifyChecksum());
    }

    public function test_unknown_severity_is_rejected(): void
    {
        $this->expectException(InvalidArgumentException::class);
        SignalSeverity::fromName('unknown');
    }

    public function test_actor_claim_cannot_spoof_authenticated_context(): void
    {
        $authority = new SignalEmitterAuthority('unit-test-secret', [
            'test-ui' => [
                'source' => 'ui',
                'source_component' => null,
                'permissions' => ['signal.emit'],
                'event_type_patterns' => ['ui.*'],
            ],
        ]);
        $validator = new SignalContextValidator($authority);
        $context = SignalContext::tenantHuman(10, 'usr_1', 'session_1', 'titan-auth', $authority->issue('test-ui'));

        $this->expectException(InvalidArgumentException::class);
        $validator->applyToInput([
            'event_type' => 'ui.action',
            'tenant_company_id' => 10,
            'source' => 'titan-command',
            'actor_id' => 'usr_2',
        ], $context);
    }
}
