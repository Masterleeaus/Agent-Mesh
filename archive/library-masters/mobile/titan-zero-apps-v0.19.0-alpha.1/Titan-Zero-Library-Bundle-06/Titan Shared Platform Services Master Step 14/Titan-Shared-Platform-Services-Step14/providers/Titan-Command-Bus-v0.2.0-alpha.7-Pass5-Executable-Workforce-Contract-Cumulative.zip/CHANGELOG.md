# Changelog

## 0.2.0-alpha.6 — Pass 11: Titan Autonomy Integration

- Added fail-closed `CommandAutonomyGateContract` and `AutonomyDecision`.
- Enforced Risk → Assurance → Autonomy → Governance → adapter ordering.
- Added capability/workflow-specific autonomy evidence to Governance, receipts, persistence and Signal telemetry.
- Added additive autonomy evidence migration and readiness dependency.
- Default autonomy bridge remains unavailable until the trusted Titan Autonomy runtime is bound.

## 0.2.0-alpha.2
- Added Pass 9 authoritative Titan Risk integration port.
- Added fail-closed Risk unavailable/denied/malformed handling before Governance.
- Separated Risk and Governance evidence in receipts and persistence.
- Passed accepted Risk decision into Governance evaluation.
- Added Risk evidence to Signal outcome telemetry and runtime readiness.
- Added additive audit-preserving Risk evidence migration and schema updates.

## 0.2.0-alpha.1
- Rebased from Blueprint-era scaffold to Titan Extension Blueprint v4.2.0.
- Converted installer to flat-root `titan-extension-v1` with integrity map.
- Added `command-bus-core` execution semantics and Blueprint v2.2 sidecar.
- Added trusted CommandContext separate from untrusted command payload.
- Added deterministic command envelope hashing and durable idempotency claims.
- Added fail-closed governance and Signal ports.
- Added domain adapter registry; direct foreign-domain writes remain forbidden.
- Added command execution receipt schema and causal Signal event schemas.
- Added Super Admin operations/health surface using host-safe Blade layout.
- Added host certification command and real standalone regression tests.


## 0.2.0-alpha.3 — Pass 10
- Added fail-closed Titan Assurance / Shield gate.
- Enforced Risk -> Assurance -> Governance -> adapter ordering.
- Added durable Assurance receipt and Signal evidence.
- Added additive Assurance evidence migration and readiness dependency.

## 0.2.0-alpha.6 — Pass 12
- Added fail-closed approval verification boundary after Governance and before mutation.
- Added tenant/capability/request-hash scope binding and expiry enforcement.
- Added approval evidence migration and package regression coverage.

## 0.2.0-alpha.6 — Pass 13 Durable Command Persistence
- Added durable `titan_commands` current-state records and append-only `titan_command_attempts` lifecycle journal.
- Added `CommandLifecycleStoreContract`, `DatabaseCommandLifecycleStore`, and canonical lifecycle states.
- Dispatch now records RECEIVED → PREFLIGHT → GOVERNED → AUTHORIZED → EXECUTING → terminal state.
- Refusals terminate as REFUSED; adapter failures terminate as FAILED.
- Idempotent replays are append-only REPLAYED observations and do not rewrite the original terminal command state.
- Lifecycle persistence is required by default and fails closed before domain execution when unavailable.
- Lifecycle evidence is allowlisted and never persists raw command payloads or exception messages.
- Existing receipts and idempotency evidence remain intact and non-destructive.

## 0.2.0-alpha.7 — Pass 4 Canonical Company Tenancy
- Canonicalized Command Bus runtime tenancy on `company_id`.
- Added non-destructive company tenancy convergence/backfill migration.
- Added canonical company indexes while retaining legacy tenant indexes for compatibility.
- Canonicalized signal/receipt schemas and audit context; legacy fields remain explicit aliases only.
- Added executable canonical tenancy regression coverage.
