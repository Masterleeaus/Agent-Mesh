# Agent-06 Upgrade Pass 4 — Executable Workforce Runtime Adapter

Version: 1.12.6

This pass adds an extension-local executable provider runtime adapter. It does not create Workforce employee identity or authority.

## Runtime components
- package-backed provider adapter;
- company-scoped in-memory health registry with expiry;
- fail-closed capability resolver;
- deterministic provider selector requiring an explicit pin when multiple providers are eligible;
- immutable health and capability availability DTOs;
- executable standalone runtime test.

Authority remains external to these extensions. The resolver accepts an authority decision as input and can only preserve or reduce access; it cannot raise authority.
