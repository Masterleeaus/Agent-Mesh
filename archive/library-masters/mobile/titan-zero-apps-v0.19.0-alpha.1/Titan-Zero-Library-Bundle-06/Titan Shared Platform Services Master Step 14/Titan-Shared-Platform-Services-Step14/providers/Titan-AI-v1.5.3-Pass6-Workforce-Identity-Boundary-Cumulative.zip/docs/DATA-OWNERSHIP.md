# Data ownership

`company_id` is the canonical tenant boundary. Titan AI owns only its runtime governance, approval, receipt, memory, persona, skill and tool-permission tables.
