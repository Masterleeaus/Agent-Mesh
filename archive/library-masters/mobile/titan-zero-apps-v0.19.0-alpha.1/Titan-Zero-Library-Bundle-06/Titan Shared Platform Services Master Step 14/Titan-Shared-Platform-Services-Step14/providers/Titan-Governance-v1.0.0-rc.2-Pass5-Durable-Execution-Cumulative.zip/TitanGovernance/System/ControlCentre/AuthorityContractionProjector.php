<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ControlCentre;

final class AuthorityContractionProjector
{
    /** @param array<string,array<string,mixed>> $sourceSnapshots @return array<string,mixed> */
    public function project(array $sourceSnapshots):array
    {
        $items=[];$invalid=0;$contracted=0;
        foreach($sourceSnapshots as $sourceKey=>$source){
            if(!is_array($source))continue;$cc=is_array($source['control_centre']??null)?$source['control_centre']:[];
            foreach(array_slice(is_array($cc['authority_constraints']??null)?$cc['authority_constraints']:[],0,500) as $raw){
                if(!is_array($raw))continue;
                $agent=trim((string)($raw['agent_id']??''));$capability=trim((string)($raw['capability']??''));if($agent===''&&$capability==='')continue;
                $desired=$this->number($raw['desired_score']??$raw['desired_authority_score']??null);
                $earned=$this->number($raw['earned_score']??$raw['earned_authority_score']??null);
                $effective=$this->number($raw['effective_score']??$raw['effective_authority_score']??null);
                $ceiling=$this->number($raw['ceiling_score']??null);
                $status='OBSERVED';
                if(($desired!==null&&$earned!==null&&$earned>$desired)||($earned!==null&&$effective!==null&&$effective>$earned)){$status='INVALID_SOURCE_AUTHORITY_ORDER';$invalid++;}
                elseif($earned!==null&&$effective!==null&&$effective<$earned){$status='CONTRACTED';$contracted++;}
                elseif($ceiling!==null&&$earned!==null&&$ceiling<$earned){$status='CONTRACTED';$contracted++;}
                $amount=($earned!==null&&$effective!==null)?max(0.0,$earned-$effective):null;
                $items[]=[
                    'source'=>$this->scalar($raw['source']??$sourceKey)??(string)$sourceKey,'agent_id'=>$agent,'capability'=>$capability,
                    'desired_score'=>$desired,'earned_score'=>$earned,'effective_score'=>$effective,'ceiling_score'=>$ceiling,
                    'contraction_amount'=>$amount,'disposition'=>strtoupper(trim((string)($raw['disposition']??'UNKNOWN'))),'status'=>$status,
                    'reason_codes'=>$this->stringList($raw['reason_codes']??[]),'observed_at'=>$raw['observed_at']??$source['observed_at']??null,
                    'expires_at'=>$raw['expires_at']??null,'reference'=>$this->scalar($raw['reference']??null),'can_raise_authority'=>false,
                ];
            }
        }
        usort($items,static fn(array $a,array $b):int=>($b['contraction_amount']??-1)<=>($a['contraction_amount']??-1) ?: strcmp((string)$a['agent_id'],(string)$b['agent_id']) ?: strcmp((string)$a['capability'],(string)$b['capability']));
        return ['status'=>$items===[]?'UNAVAILABLE':($invalid>0?'DEGRADED':'HEALTHY'),'contracted_count'=>$contracted,'invalid_count'=>$invalid,'items'=>$items,'can_raise_authority'=>false];
    }

    private function number(mixed $v):?float{return is_numeric($v)?(float)$v:null;}
    private function scalar(mixed $v):?string{return is_scalar($v)&&trim((string)$v)!==''?(string)$v:null;}
    /** @return list<string> */
    private function stringList(mixed $v):array{$out=[];if(!is_array($v))return $out;foreach(array_slice($v,0,50) as $x)if(is_scalar($x)&&trim((string)$x)!=='')$out[]=(string)$x;return array_values(array_unique($out));}
}
