<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

final class SalesDocumentPdfService
{
    public function __construct(private CrmViewDataService $views) {}

    public function render(int $userId,string $type,string $publicId): string
    {
        $data=$this->renderData($userId,$type,$publicId);
        return app('dompdf.wrapper')->loadView('crm::sales.pdf',['type'=>$type]+$data)->output();
    }

    /** @return array<string,mixed> */
    public function renderData(int $userId,string $type,string $publicId): array
    {
        $data=$this->views->salesDocument($userId,$type,$publicId);
        if(in_array($type,['proposals','estimates','invoices'],true)){
            $doc=(array)($data['document']??[]);
            $issued=$this->decode($doc['issued_snapshot']??null);
            if(is_array($issued)&&$issued!==[]){
                $contractDoc=$doc;
                foreach(['number','title','company_public_id','contact_public_id','currency','subtotal_minor','tax_minor','total_minor','expires_at','due_at','pricing_rules_version','pricing_rule_snapshot','tax_rule_snapshot','terms_snapshot','service_definition_snapshot','discount_snapshot','currency_snapshot','revision_root_public_id','revision_number','source_quote_public_id','source_quote_snapshot_hash','source_quote_revision_root_public_id','source_work_order_public_id'] as $key){
                    if(array_key_exists($key,$issued))$contractDoc[$key]=$issued[$key];
                }
                $contractDoc['issued_snapshot_hash']=$doc['issued_snapshot_hash']??null;
                $contractDoc['status']=$doc['status']??null;
                $contractDoc['accepted_at']=$doc['accepted_at']??null;
                $contractDoc['acceptance_hash']=$doc['acceptance_hash']??null;
                $data['document']=$contractDoc;
                if(isset($issued['lines'])&&is_array($issued['lines']))$data['lines']=$issued['lines'];
            }
        }
        return $data;
    }

    public function filename(string $type,array $document): string
    {
        $number=preg_replace('/[^A-Za-z0-9._-]+/','-',(string)($document['number']??$document['public_id']??'document'));
        $revision=(int)($document['revision_number']??1);
        $suffix=in_array($type,['proposals','estimates'],true)&&$revision>1?'-r'.$revision:'';
        return rtrim($type,'s').'-'.trim((string)$number,'-').$suffix.'.pdf';
    }

    /** Legacy/internal synchronous path; public endpoints use SalesDocumentRenderQueueService. */
    public function download(int $userId,string $type,string $publicId)
    {
        $data=$this->renderData($userId,$type,$publicId);$bytes=app('dompdf.wrapper')->loadView('crm::sales.pdf',['type'=>$type]+$data)->output();
        return response($bytes,200,['Content-Type'=>'application/pdf','Content-Disposition'=>'attachment; filename="'.$this->filename($type,(array)$data['document']).'"']);
    }

    private function decode(mixed $v): mixed
    {
        if(is_array($v)||$v===null)return $v;
        if(is_string($v)&&$v!==''){$d=json_decode($v,true);if(json_last_error()===JSON_ERROR_NONE)return $d;}
        return $v;
    }
}
