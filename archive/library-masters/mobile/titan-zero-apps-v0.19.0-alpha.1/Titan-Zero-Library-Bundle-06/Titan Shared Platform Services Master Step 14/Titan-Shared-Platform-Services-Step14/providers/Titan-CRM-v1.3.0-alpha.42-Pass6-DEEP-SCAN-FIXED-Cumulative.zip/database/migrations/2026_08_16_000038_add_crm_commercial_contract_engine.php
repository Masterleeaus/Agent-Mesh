<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\{DB,Schema};

return new class extends Migration {
    public function up(): void
    {
        foreach (['crm_proposals','crm_estimates'] as $table) {
            if (!Schema::hasTable($table)) continue;
            Schema::table($table, function (Blueprint $t) use ($table): void {
                if (!Schema::hasColumn($table,'revision_number')) $t->unsignedInteger('revision_number')->default(1)->index($table.'_rev_no_idx');
                if (!Schema::hasColumn($table,'revision_root_public_id')) $t->char('revision_root_public_id',26)->nullable()->index($table.'_rev_root_idx');
                if (!Schema::hasColumn($table,'supersedes_public_id')) $t->char('supersedes_public_id',26)->nullable()->index($table.'_supersedes_idx');
                if (!Schema::hasColumn($table,'superseded_by_public_id')) $t->char('superseded_by_public_id',26)->nullable()->index($table.'_superseded_by_idx');
                if (!Schema::hasColumn($table,'withdrawn_at')) $t->dateTime('withdrawn_at')->nullable()->index($table.'_withdrawn_idx');
                if (!Schema::hasColumn($table,'rejected_at')) $t->dateTime('rejected_at')->nullable();
                if (!Schema::hasColumn($table,'superseded_at')) $t->dateTime('superseded_at')->nullable();
                if (!Schema::hasColumn($table,'pricing_rules_version')) $t->string('pricing_rules_version',80)->nullable();
                if (!Schema::hasColumn($table,'service_definition_snapshot')) $t->json('service_definition_snapshot')->nullable();
                if (!Schema::hasColumn($table,'line_item_snapshot')) $t->json('line_item_snapshot')->nullable();
                if (!Schema::hasColumn($table,'discount_snapshot')) $t->json('discount_snapshot')->nullable();
                if (!Schema::hasColumn($table,'currency_snapshot')) $t->json('currency_snapshot')->nullable();
                if (!Schema::hasColumn($table,'issued_snapshot')) $t->json('issued_snapshot')->nullable();
                if (!Schema::hasColumn($table,'issued_snapshot_hash')) $t->char('issued_snapshot_hash',64)->nullable()->index($table.'_issued_hash_idx');
                if (!Schema::hasColumn($table,'accepted_by_actor_id')) $t->unsignedBigInteger('accepted_by_actor_id')->nullable()->index($table.'_accepted_actor_idx');
                if (!Schema::hasColumn($table,'accepted_via')) $t->string('accepted_via',60)->nullable();
                if (!Schema::hasColumn($table,'accepted_actor_type')) $t->string('accepted_actor_type',40)->nullable();
                if (!Schema::hasColumn($table,'accepted_actor_reference')) $t->string('accepted_actor_reference',190)->nullable()->index($table.'_accepted_ref_idx');
                if (!Schema::hasColumn($table,'acceptance_session_id')) $t->char('acceptance_session_id',64)->nullable()->index($table.'_accept_session_idx');
                if (!Schema::hasColumn($table,'acceptance_evidence')) $t->json('acceptance_evidence')->nullable();
                if (!Schema::hasColumn($table,'acceptance_hash')) $t->char('acceptance_hash',64)->nullable()->index($table.'_accept_hash_idx');
                if (!Schema::hasColumn($table,'renderer_version')) $t->string('renderer_version',60)->nullable();
                if (!Schema::hasColumn($table,'template_version')) $t->string('template_version',60)->nullable();
                if (!Schema::hasColumn($table,'document_hash')) $t->char('document_hash',64)->nullable()->index($table.'_document_hash_idx');
                if (!Schema::hasColumn($table,'document_generated_at')) $t->dateTime('document_generated_at')->nullable();
                if (!Schema::hasColumn($table,'document_generation_status')) $t->string('document_generation_status',24)->default('none')->index($table.'_render_status_idx');
                if (!Schema::hasColumn($table,'document_generation_error')) $t->text('document_generation_error')->nullable();
            });
            $this->backfillLegacyContracts($table);
        }


        if (Schema::hasTable('crm_invoices')) {
            Schema::table('crm_invoices', function (Blueprint $t): void {
                if (!Schema::hasColumn('crm_invoices','renderer_version')) $t->string('renderer_version',60)->nullable();
                if (!Schema::hasColumn('crm_invoices','template_version')) $t->string('template_version',60)->nullable();
                if (!Schema::hasColumn('crm_invoices','document_hash')) $t->char('document_hash',64)->nullable()->index('crm_invoices_document_hash_idx');
                if (!Schema::hasColumn('crm_invoices','document_generated_at')) $t->dateTime('document_generated_at')->nullable();
                if (!Schema::hasColumn('crm_invoices','document_generation_status')) $t->string('document_generation_status',24)->default('none')->index('crm_invoices_render_status_idx');
                if (!Schema::hasColumn('crm_invoices','document_generation_error')) $t->text('document_generation_error')->nullable();
            });
        }

        if (!Schema::hasTable('crm_sales_document_render_jobs')) {
            Schema::create('crm_sales_document_render_jobs', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id',26)->unique();
                $t->unsignedBigInteger('tenant_company_id')->index();
                $t->unsignedBigInteger('user_id')->index();
                $t->string('document_type',30)->index();
                $t->char('document_public_id',26)->index();
                $t->char('idempotency_key',64)->index();
                $t->string('status',24)->default('requested')->index();
                $t->char('source_snapshot_hash',64)->index();
                $t->string('renderer_version',60);
                $t->string('template_version',60);
                $t->string('storage_disk',80);
                $t->string('storage_path',500)->nullable();
                $t->char('output_hash',64)->nullable()->index();
                $t->unsignedInteger('attempts')->default(0);
                $t->dateTime('requested_at')->index();
                $t->dateTime('available_at')->nullable()->index();
                $t->dateTime('started_at')->nullable();
                $t->dateTime('completed_at')->nullable();
                $t->dateTime('failed_at')->nullable();
                $t->text('last_error')->nullable();
                $t->timestamps();
                $t->unique(['tenant_company_id','idempotency_key'],'crm_doc_render_tenant_idem_uq');
                $t->index(['tenant_company_id','document_type','document_public_id','status'],'crm_doc_render_doc_status_idx');
            });
        }
    }

    private function backfillLegacyContracts(string $table): void
    {
        $type=str_replace('crm_','',$table);
        DB::table($table)->whereNull('revision_root_public_id')->orderBy('id')->chunkById(200,function($rows)use($table):void{
            foreach($rows as $row)DB::table($table)->where('id',$row->id)->update(['revision_root_public_id'=>$row->public_id]);
        });
        DB::table($table)->whereNull('issued_snapshot_hash')->where(function($q):void{
            $q->whereNotNull('issued_at')->orWhereIn('status',['sent','accepted','rejected','expired','superseded']);
        })->orderBy('id')->chunkById(100,function($rows)use($table,$type):void{
            foreach($rows as $row){
                $lines=DB::table('crm_sales_document_lines')->where('tenant_company_id',$row->tenant_company_id)->where('document_type',$type)->where('document_public_id',$row->public_id)->orderBy('sequence')->get()->map(function($line):array{
                    return $this->canonicalize(['sequence'=>(int)$line->sequence,'description'=>(string)$line->description,'quantity_milli'=>(int)$line->quantity_milli,'unit_price_minor'=>(int)$line->unit_price_minor,'tax_rate_bps'=>(int)$line->tax_rate_bps,'line_subtotal_minor'=>(int)$line->line_subtotal_minor,'line_tax_minor'=>(int)$line->line_tax_minor,'line_total_minor'=>(int)$line->line_total_minor,'meta'=>$this->decode($line->meta??null)]);
                })->all();
                $snapshot=$this->canonicalize(['schema'=>'crm.commercial-contract.v1','document_type'=>$type,'document_public_id'=>(string)$row->public_id,'revision_root_public_id'=>(string)($row->revision_root_public_id?:$row->public_id),'revision_number'=>(int)($row->revision_number??1),'number'=>$row->number??null,'title'=>$row->title??null,'company_public_id'=>$row->company_public_id??null,'contact_public_id'=>$row->contact_public_id??null,'currency'=>strtoupper((string)($row->currency??'AUD')),'subtotal_minor'=>(int)($row->subtotal_minor??0),'tax_minor'=>(int)($row->tax_minor??0),'total_minor'=>(int)($row->total_minor??0),'expires_at'=>$row->expires_at??null,'pricing_rules_version'=>$row->pricing_rules_version??null,'pricing_rule_snapshot'=>$this->decode($row->pricing_rule_snapshot??null),'tax_rule_snapshot'=>$this->decode($row->tax_rule_snapshot??null),'terms_snapshot'=>$this->decode($row->terms_snapshot??null),'service_definition_snapshot'=>$this->decode($row->service_definition_snapshot??null),'discount_snapshot'=>$this->decode($row->discount_snapshot??null),'currency_snapshot'=>$this->decode($row->currency_snapshot??null)?:['currency'=>strtoupper((string)($row->currency??'AUD'))],'lines'=>$lines]);
                $encoded=$this->encode($snapshot);$issuedHash=hash('sha256',$encoded);
                $update=['issued_snapshot'=>$encoded,'issued_snapshot_hash'=>$issuedHash,'line_item_snapshot'=>$this->encode($lines),'snapshot_version'=>'2.0'];
                if((string)$row->status==='accepted'&&empty($row->acceptance_hash)){
                    $evidence=$this->canonicalize(['schema'=>'crm.quote-acceptance.v1','document_public_id'=>(string)$row->public_id,'issued_snapshot_hash'=>$issuedHash,'accepted_at'=>$row->accepted_at?:(string)($row->updated_at??$row->issued_at??''),'actor_user_id'=>(int)($row->user_id??0),'source'=>'legacy_crm_pre_alpha29','actor_type'=>'unknown','actor_reference'=>null,'session_hash'=>null,'portal_grant_public_id'=>null,'customer_identity_reference'=>null]);
                    $e=$this->encode($evidence);$update['acceptance_evidence']=$e;$update['acceptance_hash']=hash('sha256',$e);$update['accepted_via']='legacy_crm_pre_alpha29';
                }
                DB::table($table)->where('id',$row->id)->update($update);
            }
        });
    }

    private function decode(mixed $value): mixed
    {
        if(is_array($value)||$value===null)return $value;if(is_string($value)&&$value!==''){$decoded=json_decode($value,true);if(json_last_error()===JSON_ERROR_NONE)return $decoded;}return $value;
    }

    private function canonicalize(mixed $value): mixed
    {
        if(!is_array($value))return $value;if(array_is_list($value))return array_map(fn($v)=>$this->canonicalize($v),$value);ksort($value,SORT_STRING);foreach($value as $k=>$v)$value[$k]=$this->canonicalize($v);return $value;
    }

    private function encode(array $value): string
    {
        return (string)json_encode($value,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION|JSON_THROW_ON_ERROR);
    }

    public function down(): void
    {
        Schema::dropIfExists('crm_sales_document_render_jobs');
        // Contract evidence columns are deliberately retained on rollback to avoid destroying issued/accepted records.
    }
};
