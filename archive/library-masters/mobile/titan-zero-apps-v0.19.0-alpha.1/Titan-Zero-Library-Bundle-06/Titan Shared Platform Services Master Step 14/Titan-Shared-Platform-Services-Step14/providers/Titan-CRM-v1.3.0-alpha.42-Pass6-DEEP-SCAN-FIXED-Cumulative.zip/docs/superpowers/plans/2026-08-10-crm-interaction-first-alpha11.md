# CRM 1.3.0-alpha.11 Interaction-First Business OS Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Titan Interaction Engine the primary create/edit/action UX across CRM, with a universal Titan AI command bar, standard New actions, conversational wizard execution, and legacy forms retained only as advanced fallback.

**Architecture:** CRM remains the authoritative system of record and capability executor. Interaction Engine v10.3.1 owns wizard/session/validation/authority/execution flow, while TitanAI provides natural-language intent extraction, context gathering, suggestions, and conversational completion. CRM supplies a reusable interaction-first page shell and a CRM journey catalogue that maps page actions to Interaction Engine wizard IDs and CRM capability aliases.

**Tech Stack:** PHP 8.2+, Laravel 10/MagicAI 11, Blade, Titan Interaction Engine 10.3.1, TitanAI capability bridge, CRM capability registry/executor, JSON wizard definitions.

## Global Constraints

- Build from certified CRM `1.3.0-alpha.10`.
- Interaction Engine compatibility target: `>=10.3.1 <11.0`.
- CRM tenancy remains `tenant_company_id`; CRM `company_id` remains customer/account relationship.
- No WorkCore runtime dependency.
- No direct AI financial arithmetic; deterministic Financial Assistants remain authoritative.
- Interaction Engine is primary UX; legacy forms remain available as `Advanced form` until parity is proven.
- All operational list pages use one standard shell: title/context, AI bar, New action, toolbar, content.
- AI may execute only through governed CRM capabilities and Interaction Engine authority/approval policy.
- Existing alpha.9 route-cache and alpha.8 icon-safety fixes must remain intact.

---

### Task 1: Interaction-first foundation and compatibility contract

**Files:**
- Create: `System/Integrations/InteractionEngine/CrmInteractionJourneyRegistry.php`
- Create: `System/Integrations/InteractionEngine/CrmInteractionSurfaceService.php`
- Modify: `System/Integrations/InteractionEngine/CrmInteractionIntegrationRegistrar.php`
- Modify: `System/Capabilities/CrmCapabilityRegistry.php`
- Modify: `System/Capabilities/CrmCapabilityExecutor.php`
- Modify: `System/Providers/CrmTitanIntegrationServiceProvider.php`
- Test: `bin/verify-v130-alpha11-interaction-contract.php`

**Interfaces:**
- Produces `CrmInteractionJourneyRegistry::definitions(): array<string,array>`.
- Produces capability aliases `crm.quote.create` and `crm.invoice.create` mapped to existing CRM quote/invoice services.
- Produces `CrmInteractionSurfaceService::page(string $surface, array $context=[]): array` for Blade/UI use.

- [ ] Write failing contract test requiring Interaction Engine version floor, journey registry, capability aliases, and no direct Interaction Engine database access from CRM.
- [ ] Run test and confirm RED.
- [ ] Implement registry/service/aliases with lazy optional dependency resolution.
- [ ] Run test and confirm GREEN.

### Task 2: Universal CRM Interaction page shell

**Files:**
- Create: `resources/views/components/interaction-page-shell.blade.php`
- Create: `resources/views/components/interaction-ai-bar.blade.php`
- Create: `resources/views/components/interaction-primary-action.blade.php`
- Create: `resources/views/components/interaction-launcher.blade.php`
- Create: `resources/views/interaction/session.blade.php`
- Create: `System/Http/Controllers/InteractionWorkspaceController.php`
- Modify: `routes/web.php`
- Test: `bin/verify-v130-alpha11-ui-shell.php`

**Interfaces:**
- Route `dashboard.user.crm.interactions.start` starts a CRM journey by key.
- Route `dashboard.user.crm.interactions.session` renders/resumes a session.
- Route `dashboard.user.crm.interactions.chat` accepts contextual conversational instructions and returns a prepared action/session response.

- [ ] Write failing UI-shell test requiring all four reusable components and interaction workspace routes.
- [ ] Run RED.
- [ ] Implement shared shell and controller with optional Interaction Engine availability handling.
- [ ] Run GREEN.

### Task 3: TitanAI conversational orchestration

**Files:**
- Create: `System/Integrations/TitanAI/CrmInteractionAIToolProvider.php`
- Create: `System/Integrations/InteractionEngine/CrmConversationalInteractionService.php`
- Modify: `System/Providers/CrmTitanIntegrationServiceProvider.php`
- Modify: `System/Integrations/TitanAI/CrmTitanAIIntegrationRegistrar.php`
- Test: `bin/verify-v130-alpha11-conversational-ai.php`

**Interfaces:**
- AI tool `crm.interaction.start` resolves a user request to a registered CRM journey.
- AI tool `crm.interaction.answer` fills wizard answers but never bypasses Interaction Engine validation.
- AI tool `crm.interaction.execute` delegates execution to Interaction Engine authority/approval flow.

- [ ] Write RED test proving AI cannot call CRM repositories directly from conversational service.
- [ ] Implement context/intention orchestration and governed tool registration.
- [ ] Run GREEN.

### Task 4: Core journey catalogue and New actions

**Files:**
- Create: `resources/interactions/crm/*.json` journey metadata as needed.
- Modify: `System/Integrations/InteractionEngine/CrmInteractionJourneyRegistry.php`
- Modify major list views: companies, contacts, leads, work orders, service requests, sales, pay, locker/gear, projects, tasks, automation.
- Test: `bin/verify-v130-alpha11-new-actions.php`

**Interfaces:**
- Every create-capable list page exposes a `New …` action that starts a journey.
- Advanced fallback route is retained when a legacy create form exists.

- [ ] Write RED test enumerating required New actions and journey keys.
- [ ] Add journey catalogue for customer/contact/lead/job/service request/quote/estimate/invoice/payment/supplier/PO/goods receipt/stock count/stock transfer/inventory/tool/equipment/vehicle/maintenance/project/task/automation.
- [ ] Convert list pages to standard shell and New actions.
- [ ] Run GREEN.

### Task 5: Gear, Work and Money capability bridges

**Files:**
- Modify: `System/Capabilities/CrmCapabilityRegistry.php`
- Modify: `System/Capabilities/CrmCapabilityExecutor.php`
- Modify relevant Locker/Pay/field-service providers/services only through existing public service APIs.
- Test: `bin/verify-v130-alpha11-domain-capabilities.php`

**Interfaces:**
- Add stable CRM capabilities for inventory adjustment, stock transfer, receiving, supplier/PO creation, maintenance request, material request, timesheet/time entry, draft payment and other journey-required actions.

- [ ] Write RED test mapping every Interaction Engine CRM-oriented wizard capability to a registered CRM capability or explicit alias.
- [ ] Add missing governed adapters.
- [ ] Run GREEN.

### Task 6: Interaction renderer and advanced-form fallback

**Files:**
- Modify: `resources/views/interaction/session.blade.php`
- Create: `System/Integrations/InteractionEngine/CrmInteractionPresentationAdapter.php`
- Modify legacy create routes/views only to expose `Advanced form` fallback and prefill support.
- Test: `bin/verify-v130-alpha11-renderer-fallback.php`

**Interfaces:**
- Session UI supports Chat, Wizard, Review and Advanced form views against one shared context/session identifier.

- [ ] Write RED test for mode-switch controls and fallback links.
- [ ] Implement renderer adapter and fallback prefill contract.
- [ ] Run GREEN.

### Task 7: Authority, audit and autonomous execution

**Files:**
- Create: `System/Integrations/InteractionEngine/CrmInteractionAuthorityPolicy.php`
- Modify: `config/crm.php`
- Modify: `System/Integrations/InteractionEngine/CrmConversationalInteractionService.php`
- Test: `bin/verify-v130-alpha11-authority.php`

**Interfaces:**
- Modes: `assist`, `approval`, `autonomous`.
- Consequential financial/destructive actions remain approval-gated by default.

- [ ] Write RED policy tests for safe/default action classes and high-risk denial.
- [ ] Implement configuration-backed authority mapping layered under Interaction Engine authority controls.
- [ ] Run GREEN.

### Task 8: Release hardening and packaging

**Files:**
- Add alpha.11 changelog/report.
- Modify `extension.json`, `extension.manifest.json`, `README.md`, `bin/verify.php`, integrity inventories.

- [ ] Run every inherited alpha.1-alpha.10 verifier.
- [ ] Run new alpha.11 gates.
- [ ] Lint every PHP file and parse every JSON file.
- [ ] Confirm every migration has reversible `down()`.
- [ ] Regenerate integrity hashes.
- [ ] Build flat Titan installer ZIP.
- [ ] Fresh-extract exact ZIP and rerun master verifier/lint/path-safety checks.
