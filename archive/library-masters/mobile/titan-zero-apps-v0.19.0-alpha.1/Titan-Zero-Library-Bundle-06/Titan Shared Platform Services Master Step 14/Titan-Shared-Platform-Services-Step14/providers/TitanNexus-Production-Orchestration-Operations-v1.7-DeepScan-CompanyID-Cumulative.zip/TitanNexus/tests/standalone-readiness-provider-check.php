<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$provider = (string) file_get_contents($root . '/System/TitanNexusServiceProvider.php');
$config = (string) file_get_contents($root . '/config/titan-nexus.php');
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$admin = (string) file_get_contents($root . '/resources/views/admin.blade.php');

function rpCheck(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

foreach (['vertical_engine','command_bus','risk','governance','assurance','signal','rewind','autonomy','knowledge_authority','interface_runtime'] as $dependency) {
    rpCheck(str_contains($provider, "'{$dependency}'"), "provider probes {$dependency} readiness");
}
rpCheck(str_contains($provider, 'dependencyState('), 'provider uses callable-aware dependency readiness probe');
rpCheck(str_contains($provider, 'declaredCapabilities('), 'provider passes manifest capabilities into runtime health');
rpCheck(str_contains($config, "'knowledge_authority' => ["), 'config exposes Knowledge Authority readiness contract');
rpCheck(str_contains($config, "'interface_runtime' => ["), 'config exposes Interface Runtime readiness contract');
foreach (['database','vertical_engine','command_bus','risk','governance','assurance','signal','rewind','autonomy','knowledge_authority','interface_runtime'] as $dependency) {
    rpCheck(in_array($dependency, $manifest['health']['dependency_checks'] ?? [], true), "manifest health declares {$dependency}");
}
rpCheck(in_array('nexus.runtime-readiness', $manifest['capabilities'] ?? [], true), 'manifest advertises runtime-readiness projection capability');
rpCheck(str_contains($admin, 'available_capabilities'), 'admin diagnostics surface runtime capability availability');
rpCheck(str_contains($admin, 'execution_modes'), 'admin diagnostics surface execution mode readiness');

fwrite(STDOUT, "PASS: Titan Nexus provider readiness wiring checks\n");
