# Titan Nexus Exact-Host Certification

Titan Nexus is packaged against host profile `titan.host.magicai.installer-1.7.6.v1`: PHP 8.3, Laravel 10.50.x, MySQL strict mode, Titan Extension Installer 1.7.6, `MenuContributionRegistry` when present, and `App\Services\Common\MenuService` legacy navigation regeneration.

## Certification ladder

1. PACKAGE_CERTIFIED
2. INSTALLER_CERTIFIED
3. MIGRATION_CERTIFIED
4. BOOT_CERTIFIED
5. NAVIGATION_CERTIFIED
6. AUTHORIZATION_CERTIFIED
7. RUNTIME_CERTIFIED
8. UPGRADE_CERTIFIED
9. UNINSTALL_CERTIFIED

The isolated extension build can prove only PACKAGE_CERTIFIED. The remaining stages require the exact live MagicAI host and must remain `NOT_RUN` until executed there.

Step 5 also provides a package-side **fresh-install preflight** (`tools/fresh_install_preflight.php`) that validates the install tree, provider identity, migration sequence, routes/views, config publishing, Interface Runtime contribution and navigation wiring. This preflight is evidence that the package is ready to attempt installation; it does not set `INSTALLER_CERTIFIED`. See `docs/FRESH-INSTALL-PREFLIGHT.md`.

## Live acceptance sequence

`upload → validate_manifest → verify_integrity → backup → deploy → migrate → boot_provider → enumerate_routes → render_user_menu → render_admin_menu → click_primary_route → test_super_admin → test_delegated_admin → test_ordinary_user_denial → test_tenant_isolation → queue_scheduler_health → upgrade → disable → uninstall_retain_data`

Generate the sealed-package report after the final ZIP is created:

```bash
php tools/exact_host_certification.php \
  --package=/path/to/Titan-Nexus.zip \
  --host-root=/home/admin/domains/titanzero.io/public_html \
  --output=/path/to/host-certification-report.json
```

The generated report intentionally marks live stages `NOT_RUN`; they must only be changed when the corresponding host operation has actually been executed and evidence captured.
