<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Enums;

enum PrimeApprovalStatus: string
{
    case NotRequired = 'not_required';
    case Pending = 'pending';
    case Approved = 'approved';
    case Rejected = 'rejected';
}
