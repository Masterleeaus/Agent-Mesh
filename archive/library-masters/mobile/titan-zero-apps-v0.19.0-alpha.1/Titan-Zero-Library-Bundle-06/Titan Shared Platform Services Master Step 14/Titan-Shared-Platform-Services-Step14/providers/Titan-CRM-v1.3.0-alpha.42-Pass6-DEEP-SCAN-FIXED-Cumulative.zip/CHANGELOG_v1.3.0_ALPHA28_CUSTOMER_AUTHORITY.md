# Titan CRM Core v1.3.0-alpha.28 — Customer & Organisation Authority v2

## Added
- Stable `customer_unification_id` roots for companies, contacts, and leads.
- Tenant-scoped normalized email/phone identity ledger.
- External identity ledger for Chatbot, Titan Hub/Mobile, email and other configured channels.
- Blocking duplicate-review workflow with operator resolution and evidence fingerprints.
- Duplicate decisions automatically reopen when material identity evidence changes.
- Non-mutating merge preview and immutable merge evidence with Rewind rollback references.
- Governed identity resolve/link, duplicate review search/resolve and merge-preview capabilities.
- `organization_summary` CQRS projection and root identifiers in bounded customer projections.
- Production health checks for missing identity roots and unresolved blocking duplicate reviews.

## Lead conversion hardening
- Strong identity matches are reviewed before conversion instead of silently creating duplicate customers.
- Resolved `use_existing` decisions reuse the authoritative customer root.
- Lead notes and tags are preserved.
- Custom fields are mapped by semantic field key into target-specific company/contact definitions.
- `conversion_map` records exact source/target field lineage, customer root, reuse decision and copied metadata.

## Fixed
- Missing email/phone values no longer count as duplicate-score matches.
- Ambiguous Chatbot/email identity matches fail closed instead of selecting the first row.
- Contacts pointing at deleted organisations are repaired during governed lead conversion.
