# Agent-01 Ecosystem Interoperability Pass

Version: `0.1.4`

This pass makes cross-extension handoffs explicit while preserving domain ownership. Titan AI Workforce coordinates responsibilities and provider selection; Titan Autonomy owns effective authority; each target extension remains the only owner of its domain mutations.

## Peers

- `titan-field`
- `titan-maps-intelligence`
- `crm`

## Handoffs

- `field-work-to-time` — inbound with `titan-field`.
- `maps-presence-evidence` — inbound with `titan-maps-intelligence`.
- `time-exception-to-field` — outbound with `titan-field`.

## Safety invariants

- `company_id` is the canonical tenant boundary.
- Missing peers/providers degrade capability availability; they never create fake context or authority.
- Signals are observations, never mutation authority.
- Cross-extension writes enter the target domain through its governed command gateway and produce receipts.
- Offline operation never increases authority.
- Workforce identities survive provider removal; work is reassigned or escalated rather than silently orphaned.
