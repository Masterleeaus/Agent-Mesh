<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Actions;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceActionDecisionStoreContract;
use App\Extensions\TitanGovernance\System\Models\GovernancePolicyDecision;
use Illuminate\Database\QueryException;
use RuntimeException;

final class GovernanceActionRepository implements GovernanceActionDecisionStoreContract
{
    public function claim(GovernanceActionRequest $request): array
    {
        $existing=$this->findByOperation($request->tenantCompanyId,$request->operationId);
        if($existing instanceof GovernancePolicyDecision) return $this->replayOrConflict($existing,$request);

        $decisionId='gdec_'.hash('sha256',$request->tenantCompanyId.'|'.$request->operationId);
        $attributes=[
            'decision_id'=>$decisionId,
            'tenant_company_id'=>$request->tenantCompanyId,
            'policy_key'=>'titan-governance.escalation-action',
            'policy_version'=>'1.0',
            'disposition'=>$request->action,
            'reason_codes'=>$request->reasonCodes,
            'evidence_refs'=>$request->evidenceRefs,
            'actor_id'=>$request->actorId,
            'trace_id'=>$request->traceId,
            'correlation_id'=>$request->correlationId,
            'causation_id'=>$request->causationId,
            'root_causation_id'=>$request->rootCausationId,
            'decided_at'=>now(),
            'record_hash'=>$this->decisionHash($request,$decisionId),
            'operation_id'=>$request->operationId,
            'subject_type'=>'governance_escalation',
            'subject_id'=>$request->escalationId,
            'action'=>$request->action,
            'payload_hash'=>$request->payloadHash(),
            'command_status'=>'PENDING_DISPATCH',
            'write_verified'=>false,
        ];

        try {
            GovernancePolicyDecision::query()->create($attributes);
            return ['status'=>'CLAIMED','decision_id'=>$decisionId,'command_status'=>'PENDING_DISPATCH'];
        } catch(QueryException $e) {
            $existing=$this->findByOperation($request->tenantCompanyId,$request->operationId);
            if($existing instanceof GovernancePolicyDecision) return $this->replayOrConflict($existing,$request);
            throw $e;
        }
    }

    public function finalize(string $decisionId, array $result): array
    {
        $row=GovernancePolicyDecision::query()->where('decision_id',$decisionId)->first();
        if(!$row instanceof GovernancePolicyDecision) throw new RuntimeException('Governance decision not found');

        $row->fill([
            'command_status'=>(string)($result['status']??'FAILED'),
            'command_receipt_ref'=>$this->nullableString($result['command_receipt_ref']??null,191),
            'authoritative_receipt_ref'=>$this->nullableString($result['authoritative_domain_receipt_ref']??null,191),
            'write_verified'=>(bool)($result['write_verified']??false),
            'result_payload'=>$this->safeResult($result),
        ])->save();

        return $this->toArray($row->fresh() ?? $row);
    }

    public function findDecision(string $decisionId): ?array
    {
        $row=GovernancePolicyDecision::query()->where('decision_id',$decisionId)->first();
        return $row instanceof GovernancePolicyDecision ? $this->toArray($row) : null;
    }

    private function findByOperation(int $tenantCompanyId,string $operationId): ?GovernancePolicyDecision
    {
        $row=GovernancePolicyDecision::query()->where('tenant_company_id',$tenantCompanyId)->where('operation_id',$operationId)->first();
        return $row instanceof GovernancePolicyDecision ? $row : null;
    }

    private function replayOrConflict(GovernancePolicyDecision $row,GovernanceActionRequest $request): array
    {
        if(!hash_equals((string)$row->payload_hash,$request->payloadHash())) return [
            'status'=>'IDEMPOTENCY_CONFLICT',
            'decision_id'=>(string)$row->decision_id,
            'command_status'=>(string)$row->command_status,
            'reason_code'=>'OPERATION_ID_PAYLOAD_CONFLICT',
        ];
        return [
            'status'=>'REPLAYED',
            'decision_id'=>(string)$row->decision_id,
            'command_status'=>(string)$row->command_status,
            'result'=>is_array($row->result_payload)?$row->result_payload:[],
        ];
    }

    private function decisionHash(GovernanceActionRequest $request,string $decisionId): string
    {
        return hash('sha256',implode('|',[$decisionId,(string)$request->tenantCompanyId,$request->actorId,$request->action,$request->escalationId,$request->payloadHash(),$request->traceId,$request->correlationId,$request->rootCausationId]));
    }

    /** @param array<string,mixed> $result @return array<string,mixed> */
    private function safeResult(array $result): array
    {
        $allowed=['schema_version','status','reason_code','operation_id','command_receipt_ref','authoritative_domain_receipt_ref','write_verified','adapter','governance_decision_ref','replayed'];
        return array_intersect_key($result,array_flip($allowed));
    }

    private function nullableString(mixed $value,int $max): ?string
    {
        if($value===null)return null; $s=trim((string)$value); return $s===''?null:substr($s,0,$max);
    }

    /** @return array<string,mixed> */
    private function toArray(GovernancePolicyDecision $row): array
    {
        return [
            'decision_id'=>(string)$row->decision_id,
            'tenant_company_id'=>(int)$row->tenant_company_id,
            'operation_id'=>(string)$row->operation_id,
            'subject_type'=>(string)$row->subject_type,
            'subject_id'=>(string)$row->subject_id,
            'action'=>(string)$row->action,
            'payload_hash'=>(string)$row->payload_hash,
            'command_status'=>(string)$row->command_status,
            'command_receipt_ref'=>$row->command_receipt_ref,
            'authoritative_receipt_ref'=>$row->authoritative_receipt_ref,
            'write_verified'=>(bool)$row->write_verified,
            'result_payload'=>is_array($row->result_payload)?$row->result_payload:[],
        ];
    }
}
