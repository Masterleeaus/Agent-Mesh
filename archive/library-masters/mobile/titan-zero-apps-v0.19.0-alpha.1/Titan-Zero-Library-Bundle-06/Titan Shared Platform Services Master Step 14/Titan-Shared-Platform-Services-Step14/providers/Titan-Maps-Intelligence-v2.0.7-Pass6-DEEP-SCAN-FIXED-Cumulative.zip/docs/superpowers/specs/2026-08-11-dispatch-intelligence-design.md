# Titan Maps Intelligence — Pass 13 Dispatch Intelligence Design

## Goal
Recommend the best field worker for a job using explainable, tenant-safe evidence without making Maps the authority for jobs, worker qualifications, or dispatch assignment.

## Boundary
Maps owns recommendation snapshots, score evidence, geographic/travel calculations, and human decisions. CRM/operations remains authoritative for work orders, schedules, service requirements, worker assignment, customer history, and any host-provided qualifications/certifications.

## Inputs
A recommendation starts from a company-scoped job/work-order public reference and target coordinate. Candidate workers must already be on duty, tracking-enabled, and have an accepted current MapLocation. CRM evidence is consumed when the CRM tenant matches the Maps company boundary; missing CRM or qualification evidence is reported as unknown rather than invented.

## Scoring
Deterministic weighted score, default 100 points:
- travel/ETA: 30
- skill/experience fit: 25
- schedule availability: 15
- workload: 10
- territory/branch affinity: 8
- customer continuity: 7
- urgency response: 5

Hard blockers exclude a worker from recommendation: off duty, tracking disabled, no usable current location, explicit schedule overlap, or explicit mandatory qualification/certification failure. Unknown certification evidence never becomes a positive certification claim.

## Evidence sources
- Maps: live worker position, travel matrix, branch affinity.
- CRM when available: job priority/schedule/customer/service, service required skills, same-service completion history, active dispatch/appointment conflicts, daily dispatch workload, previous customer continuity.
- Optional host qualification resolver: explicit skills/certifications. If absent, experience history may support skill fit, but certification remains unknown.

## Persistence
- `maps_dispatch_recommendations`: request/job snapshot, scoring version/weights, state, selected worker and decision summary.
- `maps_dispatch_candidates`: immutable candidate score/evidence breakdown and blocker/explanation data.
- `maps_dispatch_decisions`: append-only approve/reject decision records and optional authoritative assignment outcome.

## Human control
Recommendations are never assignments by themselves. A user with `dispatch.manage` explicitly approves a candidate. Approval can request CRM assignment only through a tenant-verified assignment gateway; if unavailable, Maps records approval and emits an event without mutating CRM.

## UI
Field Operations gains **Dispatch Intelligence**. The screen accepts a work-order/job public ID, shows the job pin plus ranked worker pins, a score table with per-dimension evidence, warnings/blockers, and Approve/Reject actions.

## AI
Add governed capabilities:
- `titan-maps-intelligence.dispatch.recommend`
- `titan-maps-intelligence.dispatch.read`
- `titan-maps-intelligence.dispatch.decide`
AI may recommend/read. `dispatch.decide` is confirmation-gated and requires the manage permission; it cannot silently assign.

## Failure behaviour
Missing CRM, qualification adapter, provider ETA, or assignment adapter degrades explicitly. Travel falls back using the existing matrix provenance rules. No missing evidence is converted into false certainty.
