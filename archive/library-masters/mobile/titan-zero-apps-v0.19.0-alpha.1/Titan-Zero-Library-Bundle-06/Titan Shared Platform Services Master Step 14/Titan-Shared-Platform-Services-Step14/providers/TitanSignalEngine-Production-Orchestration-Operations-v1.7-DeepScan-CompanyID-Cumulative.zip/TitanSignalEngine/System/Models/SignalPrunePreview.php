<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalPrunePreview extends Model
{
    protected $table = 'titan_signal_prune_previews';
    protected $guarded = [];
    protected $casts = [
        'tenant_company_id' => 'integer',
        'tenant_key' => 'integer',
        'candidate_count' => 'integer',
        'event_ids' => 'array',
        'by_retention_class' => 'array',
        'expires_at' => 'immutable_datetime',
        'claimed_at' => 'immutable_datetime',
        'execution_started_at' => 'immutable_datetime',
        'execution_expires_at' => 'immutable_datetime',
        'completed_at' => 'immutable_datetime',
        'invalidated_at' => 'immutable_datetime',
    ];
}
