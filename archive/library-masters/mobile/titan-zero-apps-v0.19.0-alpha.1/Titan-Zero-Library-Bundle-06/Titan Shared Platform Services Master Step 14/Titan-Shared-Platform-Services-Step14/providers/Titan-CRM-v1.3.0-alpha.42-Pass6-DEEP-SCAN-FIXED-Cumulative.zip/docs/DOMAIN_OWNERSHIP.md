# Titan CRM Core Ownership — alpha.27

**CRM Core owns customer and commercial truth.**

## Owns

- customers, organisations and contacts
- leads, deals and pipelines
- CRM activities, notes, tags and custom fields
- CRM projects/tasks/calendar for commercial coordination
- commercial service/catalogue definitions
- quotes, estimates and invoices
- receivables business state
- customer/commercial history
- CRM portal/import/integration metadata
- CRM governance/read-model infrastructure
- six commercial calculation capabilities

## Does not own

- field execution — **Titan Field**
- inventory/fleet/purchasing — **Titan Locker**
- accounting journals/reporting — **Titan Ledger**
- payment-provider execution/collections — **Titan Pay**
- autonomous authority — **Titan Autonomy**
- cross-domain planning — **Titan AI Core**
- proactive AI operations — **Titan AI Workforce**
- learning/outcome patterns — **Titan Wisdom**

## Compatibility

CRM Core retains only centralized compatibility through `CrmCapabilityOwnershipMap` and `CrmExternalDomainCapabilityBridge`, plus guarded migration/reference mappings needed by upgraded installations. Per-class external-domain aliases are removed.

At alpha.27 there are 106 CRM-owned governed capabilities and 120 compatibility-visible names owned by extracted domains. The latter are routing contracts, not CRM writers.
