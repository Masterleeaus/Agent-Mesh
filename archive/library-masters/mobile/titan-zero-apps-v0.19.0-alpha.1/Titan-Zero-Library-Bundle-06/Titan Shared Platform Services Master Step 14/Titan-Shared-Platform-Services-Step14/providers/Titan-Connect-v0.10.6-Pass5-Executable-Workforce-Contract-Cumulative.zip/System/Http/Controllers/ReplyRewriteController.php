<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Contracts\ReplyAssistant;
use App\Extensions\TitanConnect\System\Services\MessagingAuditService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use RuntimeException;

final class ReplyRewriteController extends Controller
{
    public function __construct(private readonly CompanyContext $context, private readonly ReplyAssistant $assistant, private readonly MessagingAuditService $audit) {}

    public function store(Request $request): JsonResponse
    {
        $companyId = $this->context->companyId($request); $actorId = $this->context->actorId($request);
        $data = $request->validate(['message' => ['required','string','max:20000'], 'variant' => ['required', Rule::in(['improve','lengthen','fix_grammar'])]]);
        try { $result = $this->assistant->rewrite($companyId, $actorId, $data['message'], $data['variant']); }
        catch (RuntimeException $e) { return response()->json(['status' => 'error', 'message' => $e->getMessage()], 503); }
        $this->audit->record($companyId, $actorId, 'reply.rewritten', 'reply-assistant', null, null, ['variant' => $data['variant']]);
        return response()->json(['status' => 'success', 'result' => $result]);
    }
}
