<?php
namespace App\Extensions\Crm\System\Plans;
final class CrmPlanFeatures { public const CRM='ext_crm_dropdown'; public const SALES='ext_sales_dropdown'; public static function all(): array { return [self::CRM,self::SALES]; } }
