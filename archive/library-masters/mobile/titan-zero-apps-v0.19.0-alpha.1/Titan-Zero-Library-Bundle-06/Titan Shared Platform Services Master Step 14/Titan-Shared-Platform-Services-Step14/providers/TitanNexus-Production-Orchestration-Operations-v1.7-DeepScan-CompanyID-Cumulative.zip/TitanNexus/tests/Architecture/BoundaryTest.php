<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanNexus\Architecture;

use PHPUnit\Framework\TestCase;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

final class BoundaryTest extends TestCase
{
    public function test_system_does_not_import_other_extension_implementations(): void
    {
        $system = dirname(__DIR__, 2) . '/System';
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($system));

        foreach ($iterator as $file) {
            if (!$file->isFile() || $file->getExtension() !== 'php') {
                continue;
            }

            $contents = (string) file_get_contents($file->getPathname());
            self::assertDoesNotMatchRegularExpression(
                '/App\\\\Extensions\\\\(?!TitanNexus)/',
                $contents,
                'Cross-extension implementation import found in ' . $file->getPathname(),
            );
        }
    }

    public function test_repository_contract_exposes_only_tenant_scoped_reads(): void
    {
        $contract = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Contracts/CompilationRepositoryContract.php');

        self::assertStringContainsString('findForTenant(int $tenantCompanyId, string $compilationUuid)', $contract);
        self::assertStringContainsString('latestForTenant(int $tenantCompanyId, int $limit = 25)', $contract);
        self::assertStringNotContainsString('function find(string $compilationUuid)', $contract);
    }

    public function test_pass_six_governed_provisioning_boundary_avoids_direct_database_mutation(): void
    {
        $system = dirname(__DIR__, 2) . '/System';
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($system));

        foreach ($iterator as $file) {
            if (!$file->isFile() || $file->getExtension() !== 'php') {
                continue;
            }
            $contents = (string) file_get_contents($file->getPathname());
            self::assertDoesNotMatchRegularExpression(
                '/Illuminate\\\\Support\\\\Facades\\\\DB|\bDB::|Schema::table\s*\(/',
                $contents,
                'Direct database mutation found in System boundary: ' . $file->getPathname(),
            );
        }
    }

    public function test_command_bus_adapter_requires_backup_write_audit_and_rollback_evidence(): void
    {
        $adapter = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Adapters/CommandBus/CommandBusProvisioningAdapter.php');
        foreach ([
            "'capture_backup_before_write' => true",
            "'verify_backup_before_write' => true",
            "'verify_write_after' => true",
            "'audit_operation' => true",
            "'preserve_rollback_metadata' => true",
        ] as $token) {
            self::assertStringContainsString($token, $adapter);
        }
    }


    public function test_manifest_uses_configuration_orchestrator_v22_profile(): void
    {
        $manifest = json_decode((string) file_get_contents(dirname(__DIR__, 2) . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
        self::assertSame('2.2', $manifest['schema_version']);
        self::assertSame('configuration-orchestrator', $manifest['architecture']['profile']);
        self::assertContains('configuration-compiler', $manifest['architecture']['modifiers']);
        self::assertSame('required', $manifest['governance']['command_bus']);
        self::assertSame('required', $manifest['governance']['risk']);
        self::assertSame('required', $manifest['governance']['assurance']);
        self::assertSame('required', $manifest['governance']['signal']);
        self::assertSame('required', $manifest['governance']['rewind']);
    }

    public function test_domain_core_is_added_with_a_forward_migration(): void
    {
        $root = dirname(__DIR__, 2);
        self::assertFileExists($root . '/database/migrations/2026_08_11_000001_create_titan_nexus_compilations_table.php');
        self::assertFileExists($root . '/database/migrations/2026_08_11_000002_upgrade_titan_nexus_compilations_for_domain_core.php');
        self::assertFileExists($root . '/database/migrations/2026_08_17_000003_add_vertical_definition_hash_to_titan_nexus_compilations.php');
    }
}
