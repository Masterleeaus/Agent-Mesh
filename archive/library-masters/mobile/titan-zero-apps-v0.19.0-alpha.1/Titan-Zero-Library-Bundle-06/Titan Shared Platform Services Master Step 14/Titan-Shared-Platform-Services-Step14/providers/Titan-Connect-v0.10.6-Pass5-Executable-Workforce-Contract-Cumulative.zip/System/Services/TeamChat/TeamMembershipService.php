<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services\TeamChat;

use App\Extensions\TitanConnect\System\Contracts\CompanyActorDirectory;
use App\Extensions\TitanConnect\System\Events\TeamChat\TeamConversationUpdated;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversationParticipant;
use App\Extensions\TitanConnect\System\Policies\TeamChat\TeamConversationPolicy;
use App\Extensions\TitanConnect\System\Realtime\SafeRealtimeDispatcher;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

final class TeamMembershipService
{
    public function __construct(
        private readonly TeamConversationPolicy $policy,
        private readonly CompanyActorDirectory $actors,
        private readonly SafeRealtimeDispatcher $realtime,
    ) {
    }

    public function add(TeamConversation $conversation, int $actorId, int $userId, string $role = 'member'): TeamConversationParticipant
    {
        abort_unless($conversation->type === 'group' && $this->policy->canManage($conversation, $actorId), 403);
        $this->actors->assertUsersBelongToCompany((int) $conversation->company_id, [$actorId, $userId]);
        if (! in_array($role, ['admin', 'moderator', 'member'], true)) {
            throw ValidationException::withMessages(['role' => 'Unsupported participant role.']);
        }

        $participant = DB::transaction(function () use ($conversation, $userId, $role): TeamConversationParticipant {
            $participant = TeamConversationParticipant::withTrashed()->firstOrNew([
                'conversation_id' => $conversation->id,
                'company_id' => $conversation->company_id,
                'user_id' => $userId,
            ]);
            $participant->fill(['role' => $role, 'joined_at' => now(), 'left_at' => null, 'archived_at' => null]);
            $participant->deleted_at = null;
            $participant->save();
            $conversation->increment('version');
            $conversation->touch();
            return $participant;
        });

        $this->realtime->dispatch(new TeamConversationUpdated($conversation->fresh(), 'participant-added', $actorId));
        return $participant;
    }

    public function remove(TeamConversation $conversation, int $actorId, TeamConversationParticipant $target): void
    {
        abort_unless((int) $target->company_id === (int) $conversation->company_id, 403);
        abort_unless($this->policy->canRemove($conversation, $actorId, $target), 403);
        DB::transaction(function () use ($conversation, $target): void {
            $target->update(['left_at' => now(), 'archived_at' => now()]);
            $conversation->increment('version');
            $conversation->touch();
        });
        $this->realtime->dispatch(new TeamConversationUpdated($conversation->fresh(), 'participant-removed', $actorId));
    }

    public function changeRole(TeamConversation $conversation, int $actorId, TeamConversationParticipant $target, string $role): TeamConversationParticipant
    {
        abort_unless((int) $target->company_id === (int) $conversation->company_id, 403);
        abort_unless($this->policy->canManage($conversation, $actorId), 403);
        abort_if($target->conversation_id !== $conversation->id || $target->role === 'owner', 403);
        if (! in_array($role, ['admin', 'moderator', 'member'], true)) {
            throw ValidationException::withMessages(['role' => 'Unsupported participant role.']);
        }
        $target->update(['role' => $role]);
        $conversation->increment('version');
        $this->realtime->dispatch(new TeamConversationUpdated($conversation->fresh(), 'participant-role-changed', $actorId));
        return $target->fresh();
    }
}
