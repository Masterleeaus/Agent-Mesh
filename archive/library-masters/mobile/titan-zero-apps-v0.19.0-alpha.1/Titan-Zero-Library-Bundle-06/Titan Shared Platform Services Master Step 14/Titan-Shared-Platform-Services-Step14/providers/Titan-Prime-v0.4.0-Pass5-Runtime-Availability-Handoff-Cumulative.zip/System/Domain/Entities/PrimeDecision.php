<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Entities;

use InvalidArgumentException;

final readonly class PrimeDecision
{
    /**
     * @param list<string> $alternatives
     * @param list<string> $reasonCodes
     * @param list<string> $evidenceReferences
     */
    public function __construct(
        public string $decisionId,
        public string $missionId,
        public string $decision,
        public array $alternatives = [],
        public array $reasonCodes = [],
        public array $evidenceReferences = [],
        public float $confidence = 0.0,
        public ?string $recordedAt = null,
    ) {
        if (trim($decisionId) === '' || trim($missionId) === '' || trim($decision) === '') {
            throw new InvalidArgumentException('Decision id, mission id and decision are required.');
        }
        if ($confidence < 0.0 || $confidence > 1.0) {
            throw new InvalidArgumentException('Decision confidence must be between 0.0 and 1.0.');
        }
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'decision_id' => $this->decisionId,
            'mission_id' => $this->missionId,
            'decision' => $this->decision,
            'alternatives' => array_values($this->alternatives),
            'reason_codes' => array_values($this->reasonCodes),
            'evidence_references' => array_values($this->evidenceReferences),
            'confidence' => $this->confidence,
            'recorded_at' => $this->recordedAt,
        ];
    }
}
