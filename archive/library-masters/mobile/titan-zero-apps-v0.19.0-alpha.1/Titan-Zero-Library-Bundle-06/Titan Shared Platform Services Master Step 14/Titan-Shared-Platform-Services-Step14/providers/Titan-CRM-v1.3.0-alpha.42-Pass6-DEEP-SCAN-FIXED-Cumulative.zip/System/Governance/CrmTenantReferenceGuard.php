<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

use App\Extensions\Crm\System\Tenancy\{CrmCompanyContextResolver,CrmCompanyScope};
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

/** Fail-closed validation for public-id relationships supplied to governed CRM writes. */
final class CrmTenantReferenceGuard
{
    /** @var array<string,string> */
    private const REFERENCES=[
        'company_public_id'=>'crm_companies','contact_public_id'=>'crm_contacts','customer_public_id'=>'crm_contacts',
        'lead_public_id'=>'crm_leads','deal_public_id'=>'crm_deals','project_public_id'=>'crm_projects',
        'service_public_id'=>'crm_services','service_request_public_id'=>'crm_service_requests','service_location_public_id'=>'crm_service_locations',
        'work_order_public_id'=>'crm_work_orders','appointment_public_id'=>'crm_appointments','invoice_public_id'=>'crm_invoices',
        'estimate_public_id'=>'crm_estimates','proposal_public_id'=>'crm_proposals','credit_note_public_id'=>'crm_credit_notes',
    ];

    public function __construct(
        private readonly ConnectionInterface $db,
        private readonly CrmCompanyScope $scope,
        private readonly CrmCompanyContextResolver $contexts,
    ) {}

    public function assertInput(string $capability,array $input): void
    {
        $tenant=$this->scope->current()->companyId;
        foreach(self::REFERENCES as $field=>$table)$this->assertPublicId($tenant,$table,$field,$this->stringValue($input,$field));

        $task=$this->stringValue($input,'task_public_id');
        if($task!=='')$this->assertPublicId($tenant,str_starts_with($capability,'crm.work_order.task.')?'crm_work_order_tasks':'crm_tasks','task_public_id',$task);
        foreach(['submission_public_id','form_submission_public_id'] as $field){
            $value=$this->stringValue($input,$field);if($value!=='')$this->assertPublicId($tenant,'crm_form_submissions',$field,$value);
        }
        $formField=$this->stringValue($input,'field_public_id');
        if($formField!=='')$this->assertPublicId($tenant,'crm_form_fields','field_public_id',$formField);
        $dispatch=$this->stringValue($input,'dispatch_public_id');
        if($dispatch!=='')$this->assertPublicId($tenant,'crm_dispatch_assignments','dispatch_public_id',$dispatch);

        // Same field names may legitimately belong to different Titan subdomains.
        $location=$this->stringValue($input,'location_public_id');
        if($location!=='')$this->assertPublicId($tenant,str_starts_with($capability,'crm.locker.')?'crm_locker_stock_locations':'crm_service_locations','location_public_id',$location);
        $asset=$this->stringValue($input,'asset_public_id');
        if($asset!=='')$this->assertPublicId($tenant,str_starts_with($capability,'crm.locker.')?'crm_locker_assets':'crm_customer_assets','asset_public_id',$asset);

        foreach(['assigned_user_id','worker_user_id','owner_user_id','grantee_user_id'] as $field){
            $value=$this->intValue($input,$field);
            if($value<1)continue;
            if(!$this->contexts->actorBelongsToCompany($value,$tenant))throw new InvalidArgumentException("{$field} reference not found.");
        }
    }

    private function assertPublicId(int $tenant,string $table,string $field,string $value): void
    {
        if($value===''||!$this->tableReady($table))return;
        $exists=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$value)
            ->when($this->hasColumn($table,'deleted_at'),fn($q)=>$q->whereNull('deleted_at'))->exists();
        if(!$exists)throw new InvalidArgumentException("{$field} reference not found.");
    }
    private function stringValue(array $input,string $field): string
    { $v=$input[$field]??($input['attributes'][$field]??null);return is_scalar($v)?trim((string)$v):''; }
    private function intValue(array $input,string $field): int
    { $v=$input[$field]??($input['attributes'][$field]??0);return is_numeric($v)?(int)$v:0; }
    private function tableReady(string $table): bool
    { try{return $this->db->getSchemaBuilder()->hasTable($table)&&$this->hasColumn($table,'company_id')&&$this->hasColumn($table,'public_id');}catch(\Throwable){return false;} }
    private function hasColumn(string $table,string $column): bool
    { try{return $this->db->getSchemaBuilder()->hasColumn($table,$column);}catch(\Throwable){return false;} }
}
