<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Services;

use App\Extensions\TitanPrime\System\Contracts\PrimeManagerContract;
use App\Extensions\TitanPrime\System\Gateways\Bridges\FailClosedEngineBridge;
use App\Extensions\TitanPrime\System\Gateways\Contracts\EngineGatewayCatalogContract;
use App\Extensions\TitanPrime\System\Gateways\Services\EngineGatewayCatalog;
use InvalidArgumentException;

final class PrimeManager implements PrimeManagerContract
{
    public function __construct(private readonly ?EngineGatewayCatalogContract $gatewayCatalog = null) {}

    public function health(?int $tenantCompanyId = null, ?string $sourceComponent = null): array
    {
        if ($tenantCompanyId !== null && $tenantCompanyId < 1) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer when supplied.');
        }

        if ($sourceComponent !== null && trim($sourceComponent) === '') {
            throw new InvalidArgumentException('source_component must be null or non-empty.');
        }

        $enabled = (bool) config('titan-prime.enabled', true);
        $scope = $sourceComponent !== null ? 'source_component' : ($tenantCompanyId !== null ? 'tenant' : 'platform');
        $catalog = $this->gatewayCatalog ?? new EngineGatewayCatalog(new FailClosedEngineBridge());
        $gateways = $catalog->snapshot();

        return [
            'engine' => 'titan-prime',
            'status' => $enabled ? 'HEALTHY' : 'DISABLED',
            'version' => '0.4.0',
            'scope' => $scope,
            'tenant_company_id' => $tenantCompanyId,
            'source_component' => $sourceComponent,
            'liveness' => true,
            'readiness' => $enabled,
            'orchestration_enabled' => false,
            'engine_gateway_ready' => $catalog->allRequiredForExecutionAvailable(),
            'execution_ready' => false,
            'engine_gateways' => $gateways,
            'current_pressure' => 'nominal',
            'historical_incidents_affect_current_status' => false,
        ];
    }
}
