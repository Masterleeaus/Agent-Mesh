# Data Ownership

Owned: governance policy decisions, Governance-authored authority constraints, escalations and cached/read projections.

Not owned: business records, Risk scores, Assurance state, Autonomy earned/effective authority, Signal canonical events, Workforce tasks, Knowledge truth, Rewind evidence, model deliberation or Command Bus execution receipts.

`titan_governance_views` is a projection/cache table and must never become the canonical source for another engine's state.
