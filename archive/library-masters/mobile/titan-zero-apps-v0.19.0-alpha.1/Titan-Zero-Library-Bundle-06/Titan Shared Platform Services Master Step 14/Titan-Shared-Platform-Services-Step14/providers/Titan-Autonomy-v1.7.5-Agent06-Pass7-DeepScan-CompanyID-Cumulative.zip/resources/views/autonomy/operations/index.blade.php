@extends($layout)
@section('title', 'Autonomy Operations')
@section('content')
<div class="ta-card">
    <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap">
        <div><h1 style="margin:0">Autonomy Operations</h1><p class="ta-muted">Execution observation, exceptions, verification and trust-change queue.</p></div>
        <a class="ta-btn secondary" href="{{ route('titan-autonomy.index') }}">Autonomy Learning</a>
    </div>
    @if(session('titan_autonomy_status'))<div class="ta-ok">{{ session('titan_autonomy_status') }}</div>@endif
    @if(session('titan_autonomy_error'))<div class="ta-error">{{ session('titan_autonomy_error') }}</div>@endif
</div>
<div class="ta-grid">
@foreach(['attention'=>'Needs attention','due'=>'Due to verify','human_review'=>'Human verification','exceptions'=>'Exceptions','regressions'=>'Regressions','observing'=>'Observing','verified'=>'Verified'] as $key=>$label)
<div class="ta-card"><strong>{{ $queue['summary'][$key] ?? 0 }}</strong><div class="ta-muted">{{ $label }}</div></div>
@endforeach
</div>
<div class="ta-card">
<form method="get" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end">
<div><label>Status</label><select class="ta-input" name="status"><option value="attention" @selected(($queue['filters']['status']??'')==='attention')>Needs attention</option><option value="pending" @selected(($queue['filters']['status']??'')==='pending')>Pending verification</option><option value="all" @selected(($queue['filters']['status']??'')==='all')>All</option><option value="assurance_red" @selected(($queue['filters']['status']??'')==='assurance_red')>Assurance RED</option><option value="verification_failed" @selected(($queue['filters']['status']??'')==='verification_failed')>Verification failed</option><option value="reversed" @selected(($queue['filters']['status']??'')==='reversed')>Reversed</option></select></div>
<div style="min-width:280px"><label>Capability</label><input class="ta-input" name="capability" value="{{ $queue['filters']['capability'] ?? '' }}" placeholder="crm.invoice.issue"></div>
<button class="ta-btn secondary">Filter</button>
</form>
</div>
<div class="ta-card"><table class="ta-table"><thead><tr><th>Priority</th><th>Execution</th><th>Status</th><th>Risk / Level</th><th>Matures</th><th>Outcome</th><th></th></tr></thead><tbody>
@forelse($queue['items'] as $item)
<tr>
<td>{{ $item['operations']['priority'] }}</td>
<td><strong>{{ $item['capability'] }}</strong><br><small class="ta-muted">{{ $item['workflow_key'] ?: 'default' }} · {{ $item['correlation_id'] }}</small></td>
<td><span class="ta-pill">{{ str_replace('_',' ',strtoupper($item['operations']['status'])) }}</span>@if(in_array('regression',$item['operations']['flags']??[],true)) <span class="ta-pill">REGRESSION</span>@endif</td>
<td>{{ strtoupper($item['risk']) }}<br><small>{{ $item['autonomy_level'] }}</small></td>
<td>{{ $item['matures_at'] ?? '—' }}</td>
<td>{{ $item['final_label'] ?? $item['command_status'] ?? '—' }}</td>
<td><a class="ta-btn secondary" href="{{ route('titan-autonomy.operations.show',['correlationId'=>$item['correlation_id']]) }}">Inspect</a></td>
</tr>
@empty<tr><td colspan="7" class="ta-muted">No execution receipts match this queue.</td></tr>@endforelse
</tbody></table></div>
@endsection
