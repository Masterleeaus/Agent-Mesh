# Runtime Plumbing Pass v1.3

This cumulative pass adds fail-closed container provider discovery, execution-purpose availability resolution, canonical Installer 1.7.8 root-manifest convergence, a deterministic Installer 1.7.6 compatibility-manifest template, and explicit provider/binding provenance. Signal Engine and Knowledge Authority additionally quarantine legacy host-menu database access behind dedicated compatibility adapters.

The canonical tenant boundary remains `company_id`. Legacy `tenant_company_id` is compatibility-only and is not a new authority source. Workforce remains owner of employee identity, roles, and executable work items.
