<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Extensions\TitanSignalEngine\System\Data\EventTypeDefinition;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Exceptions\ImmutableSignalEventException;
use App\Extensions\TitanSignalEngine\System\Exceptions\SignalIntegrityException;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use App\Extensions\TitanSignalEngine\System\Persistence\SignalEventStore;
use App\Extensions\TitanSignalEngine\System\Services\EventTypeRegistry;
use App\Extensions\TitanSignalEngine\System\Services\SignalRegistryAuthority;
use App\Extensions\TitanSignalEngine\System\Services\RegistryOwnershipPolicy;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitter;
use App\Extensions\TitanSignalEngine\System\Services\SignalPayloadGuard;
use App\Extensions\TitanSignalEngine\System\Services\SignalQueryService;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

final class FoundationRuntimeIntegrationTest extends TestCase
{
    private SignalEmitter $emitter;
    private \App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority $emitterAuthority;
    private SignalQueryService $query;
    private EventTypeRegistry $registry;

    protected function setUp(): void
    {
        parent::setUp();

        foreach (glob(dirname(__DIR__, 2) . '/database/migrations/*.php') ?: [] as $migrationFile) {
            $migration = require $migrationFile;
            $migration->up();
        }

        config()->set('titan-signal-engine.idempotency_ttl_seconds', 86400);
        config()->set('titan-signal-engine.max_query_limit', 1000);

        $store = new SignalEventStore();
        $registryAuthority = new SignalRegistryAuthority('feature-registry-secret', [
            'test-registry' => [
                'owner_source' => 'test-suite',
                'permissions' => ['signal.registry.event.manage'],
                'event_type_patterns' => ['test.*'],
                'subscriber_key_patterns' => [],
            ],
        ]);
        $registryIdentity = $registryAuthority->issue('test-registry');
        $this->emitterAuthority = new \App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority('feature-test-secret', [
            'test-service:test-suite:root' => [
                'source' => 'test-suite',
                'source_component' => null,
                'permissions' => ['signal.emit'],
                'event_type_patterns' => ['*'],
            ],
        ]);
        $validator = new SignalContextValidator($this->emitterAuthority);
        $this->registry = new EventTypeRegistry(new RegistryOwnershipPolicy($registryAuthority));
        $this->emitter = new SignalEmitter(
            $store,
            $this->registry,
            $validator,
            new SignalPayloadGuard(65536, 8192, ['chain_of_thought', 'hidden_reasoning', 'scratchpad']),
        );
        $this->query = new SignalQueryService($store, $validator);

        $this->registry->register(EventTypeDefinition::fromArray([
            'event_type' => 'test.signal',
            'current_schema_version' => 1,
            'supported_schema_versions' => [1],
            'category' => 'test',
            'allowed_scopes' => ['tenant'],
            'required_payload_fields' => ['value'],
            'optional_payload_fields' => [],
            'allow_additional_payload_fields' => false,
            'owner_source' => 'test-suite',
            'allowed_severities' => ['info', 'error'],
        ]), $registryIdentity);
    }


    private function emitTrusted(
        \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope|array $signal,
        ?\App\Extensions\TitanSignalEngine\System\Data\SignalContext $context = null,
    ): \App\Extensions\TitanSignalEngine\System\Data\SignalReceipt {
        $source = is_array($signal) ? (string) ($signal['source'] ?? 'test-suite') : $signal->source;
        $component = is_array($signal) ? ($signal['source_component'] ?? null) : $signal->sourceComponent;
        $scope = is_array($signal) ? (string) ($signal['scope'] ?? 'tenant') : $signal->scope;
        $tenant = is_array($signal) ? ($signal['tenant_company_id'] ?? null) : $signal->tenantCompanyId;
        $serviceId = 'test-service:' . $source . ':' . ($component ?? 'root');
        $identity = $this->emitterAuthority->issue($serviceId);
        if ($context === null) {
            $context = $scope === 'system'
                ? \App\Extensions\TitanSignalEngine\System\Data\SignalContext::system('test-system', 'test', ['signal.tenant.emit'], $identity)
                : \App\Extensions\TitanSignalEngine\System\Data\SignalContext::tenantHuman((int) $tenant, 'test-user', 'test-session', 'test', $identity);
        } else {
            $context = new \App\Extensions\TitanSignalEngine\System\Data\SignalContext(
                $context->scope,
                $context->tenantCompanyId,
                $context->actor,
                $context->permissions,
                $identity,
            );
        }

        return $this->emitter->emit($signal, $context);
    }

    public function test_existing_signal_event_cannot_be_updated_or_deleted(): void
    {
        $receipt = $this->emitTrusted([
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'payload' => ['value' => 1],
        ]);

        $event = SignalEvent::query()->where('event_id', $receipt->eventId)->firstOrFail();
        try {
            $event->event_type = 'changed.illegally';
            $event->save();
            self::fail('Signal update should have thrown ImmutableSignalEventException.');
        } catch (ImmutableSignalEventException) {
            self::assertSame('test.signal', SignalEvent::query()->where('event_id', $receipt->eventId)->value('event_type'));
        }

        $event = SignalEvent::query()->where('event_id', $receipt->eventId)->firstOrFail();
        $this->expectException(ImmutableSignalEventException::class);
        $event->delete();
    }

    public function test_idempotent_ingestion_stores_one_event_and_returns_original_id(): void
    {
        $input = [
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'idempotency_key' => 'same-request',
            'payload' => ['value' => 1],
        ];

        $first = $this->emitTrusted($input);
        $second = $this->emitTrusted($input);

        self::assertFalse($first->duplicate);
        self::assertTrue($second->duplicate);
        self::assertSame($first->eventId, $second->eventId);
        self::assertSame($first->eventId, $second->originalEventId);
        self::assertSame(1, SignalEvent::query()->where('tenant_company_id', 1)->where('idempotency_key', 'same-request')->count());
    }

    public function test_persisted_causation_cannot_be_read_across_tenants(): void
    {
        $root = \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope::fromArray([
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'payload' => ['value' => 1],
        ]);
        $child = $root->child('test.signal', 'test-suite', ['value' => 2]);
        $this->emitTrusted($root);
        $this->emitTrusted($child);

        self::assertCount(2, $this->query->byRootCausation($root->eventId, SignalContext::tenantHuman(1, 'reader-1', 'sess-1', 'test'), 1));
        self::assertCount(0, $this->query->byRootCausation($root->eventId, SignalContext::tenantHuman(2, 'reader-2', 'sess-2', 'test'), 2));
    }

    public function test_checksum_tampering_is_rejected_on_query(): void
    {
        $receipt = $this->emitTrusted([
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'payload' => ['value' => 1],
        ]);

        DB::table('titan_signal_events')->where('event_id', $receipt->eventId)->update([
            'payload' => json_encode(['value' => 999], JSON_THROW_ON_ERROR),
        ]);

        $this->expectException(SignalIntegrityException::class);
        $this->query->find($receipt->eventId, SignalContext::tenantHuman(1, 'reader-1', 'sess-1', 'test'), 1);
    }

    public function test_actor_spoofing_is_rejected_against_authenticated_context(): void
    {
        $context = SignalContext::tenantHuman(1, 'usr_1', 'session_1', 'titan-auth');

        $this->expectException(\InvalidArgumentException::class);
        $this->emitTrusted([
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'actor_id' => 'usr_2',
            'payload' => ['value' => 1],
        ], $context);
    }

    public function test_authenticated_tenant_context_cannot_query_another_tenant(): void
    {
        $context = SignalContext::tenantHuman(1, 'usr_1', 'session_1', 'titan-auth');

        $this->expectException(\InvalidArgumentException::class);
        $this->query->byTrace('018f6b6a-7b10-7abc-8def-1234567890ab', $context, 2, \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope::SCOPE_TENANT, 10);
    }

    public function test_system_query_requires_explicit_system_read_permission(): void
    {
        $context = SignalContext::system('signal-service');

        $this->expectException(\InvalidArgumentException::class);
        $this->query->byTrace('018f6b6a-7b10-7abc-8def-1234567890ab', $context, null, \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope::SCOPE_SYSTEM, 10);
    }

    public function test_unregistered_event_type_is_rejected(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        $this->emitTrusted([
            'event_type' => 'typo.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'payload' => ['value' => 1],
        ]);
    }

    public function test_idempotency_key_reuse_with_different_content_is_rejected(): void
    {
        $base = [
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'idempotency_key' => 'collision-key',
        ];
        $this->emitTrusted([...$base, 'payload' => ['value' => 1]]);

        $this->expectException(\RuntimeException::class);
        $this->emitTrusted([...$base, 'payload' => ['value' => 2]]);
    }

    public function test_manual_causation_cannot_cross_tenant_boundary(): void
    {
        $parent = \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope::fromArray([
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'payload' => ['value' => 1],
        ]);
        $this->emitTrusted($parent);

        $forgedChild = \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope::fromArray([
            'event_type' => 'test.signal',
            'tenant_company_id' => 2,
            'source' => 'test-suite',
            'trace_id' => $parent->traceId,
            'correlation_id' => $parent->correlationId,
            'causation_id' => $parent->eventId,
            'root_causation_id' => $parent->eventId,
            'payload' => ['value' => 2],
        ]);

        $this->expectException(\RuntimeException::class);
        $this->emitTrusted($forgedChild);
    }

    public function test_manual_causation_cannot_cross_trace_boundary(): void
    {
        $parent = \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope::fromArray([
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'payload' => ['value' => 1],
        ]);
        $this->emitTrusted($parent);

        $forgedChild = \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope::fromArray([
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'correlation_id' => $parent->correlationId,
            'causation_id' => $parent->eventId,
            'root_causation_id' => $parent->eventId,
            'payload' => ['value' => 2],
        ]);

        $this->expectException(\RuntimeException::class);
        $this->emitTrusted($forgedChild);
    }
}
