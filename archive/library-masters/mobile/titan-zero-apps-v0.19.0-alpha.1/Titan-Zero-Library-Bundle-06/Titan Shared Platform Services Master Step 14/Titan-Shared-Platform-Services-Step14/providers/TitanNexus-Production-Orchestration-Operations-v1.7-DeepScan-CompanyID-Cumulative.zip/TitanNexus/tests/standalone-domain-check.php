<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompiledTitanConfig;
use App\Extensions\TitanNexus\System\Domain\ConfigurationDiff;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeDisposition;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeKind;
use App\Extensions\TitanNexus\System\Domain\SemanticDiffEntry;
use App\Extensions\TitanNexus\System\Domain\CompilationStatus;
use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Domain\ValidationFinding;
use App\Extensions\TitanNexus\System\Domain\ValidationResult;
use App\Extensions\TitanNexus\System\Domain\ValidationSeverity;

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
$files = [
    '/System/Support/CanonicalJson.php',
    '/System/Domain/CompilationStatus.php',
    '/System/Domain/ValidationSeverity.php',
    '/System/Domain/ValidationFinding.php',
    '/System/Domain/ValidationResult.php',
    '/System/Domain/ValueObjects/TraceContext.php',
    '/System/Domain/BusinessProfile.php',
    '/System/Domain/CompiledTitanConfig.php',
    '/System/Domain/SemanticChangeKind.php',
    '/System/Domain/SemanticChangeDisposition.php',
    '/System/Domain/SemanticDiffEntry.php',
    '/System/Domain/ConfigurationDiff.php',
    '/System/Domain/NexusCompilation.php',
];

foreach ($files as $file) {
    $path = $root . $file;
    if (!is_file($path)) {
        fwrite(STDERR, "FAIL: missing production class file {$file}\n");
        exit(1);
    }
    require_once $path;
}

function check(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

function expectInvalid(callable $callback, string $message): void
{
    try {
        $callback();
    } catch (InvalidArgumentException) {
        return;
    }

    fwrite(STDERR, "FAIL: expected InvalidArgumentException: {$message}\n");
    exit(1);
}

$trace = TraceContext::fromArray([
    'tenant_company_id' => 42,
    'trace_id' => '11111111-1111-4111-8111-111111111111',
    'correlation_id' => '22222222-2222-4222-8222-222222222222',
    'causation_id' => '33333333-3333-4333-8333-333333333333',
]);
check($trace->tenantCompanyId() === 42, 'trace context keeps tenant identity');
check($trace->toArray()['causation_id'] === '33333333-3333-4333-8333-333333333333', 'trace context exposes causation id');
expectInvalid(static fn () => TraceContext::fromArray([
    'tenant_company_id' => 0,
    'trace_id' => '11111111-1111-4111-8111-111111111111',
    'correlation_id' => '22222222-2222-4222-8222-222222222222',
    'causation_id' => '33333333-3333-4333-8333-333333333333',
]), 'non-positive tenant must be rejected');
expectInvalid(static fn () => TraceContext::fromArray([
    'tenant_company_id' => 42,
    'trace_id' => 'not-a-uuid',
    'correlation_id' => '22222222-2222-4222-8222-222222222222',
    'causation_id' => '33333333-3333-4333-8333-333333333333',
]), 'malformed trace UUID must be rejected');

$profileA = BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '1.0.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['region' => 'VIC', 'country_code' => 'AU'],
    'timezone' => 'Australia/Melbourne',
    'sections' => ['workforce' => ['roles' => ['cleaner', 'supervisor']], 'billing' => ['currency' => 'AUD']],
]);
$profileB = BusinessProfile::fromArray([
    'sections' => ['billing' => ['currency' => 'AUD'], 'workforce' => ['roles' => ['cleaner', 'supervisor']]],
    'timezone' => 'Australia/Melbourne',
    'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
    'vertical_version' => '2026.08',
    'vertical_id' => 'cleaning',
    'profile_version' => '1.0.0',
    'tenant_company_id' => 42,
]);
check($profileA->fingerprint() === $profileB->fingerprint(), 'profile hash is deterministic across associative key order');
expectInvalid(static fn () => BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['country_code' => 'AU'],
    'timezone' => 'Australia/Melbourne',
]), 'profile version is mandatory');

$configA = CompiledTitanConfig::fromArray([
    'tenant_company_id' => 42,
    'configuration_version' => '1',
    'compiler_version' => '0.2.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => null,
    'source_profile_hash' => $profileA->fingerprint(),
    'sections' => ['operations' => ['job_statuses' => ['scheduled', 'in_progress', 'complete']]],
]);
$configB = CompiledTitanConfig::fromArray([
    'sections' => ['operations' => ['job_statuses' => ['scheduled', 'in_progress', 'complete']]],
    'source_profile_hash' => $profileA->fingerprint(),
    'knowledge_snapshot_version' => null,
    'vertical_version' => '2026.08',
    'vertical_id' => 'cleaning',
    'compiler_version' => '0.2.0',
    'configuration_version' => '1',
    'tenant_company_id' => 42,
]);
check($configA->outputHash() === $configB->outputHash(), 'compiled config hash is deterministic');

$draft = NexusCompilation::draft(
    $profileA,
    $trace,
    '44444444-4444-4444-8444-444444444444',
    '0.2.0'
);
check($draft->status() === CompilationStatus::Draft, 'new compilation starts as draft');
check($draft->compiledConfiguration() === null, 'draft has no compiled output');
$validation = ValidationResult::fromFindings([
    new ValidationFinding('profile.recommended', ValidationSeverity::Warning, 'sections.operations.area', 'Recommended business profile value is missing.', 'nexus.semantic'),
]);
$validatedDraft = $draft->withValidationResult($validation);
check($draft->validationResult() === null, 'adding validation does not mutate original draft');
check($validatedDraft->validationResult()?->fingerprint() === $validation->fingerprint(), 'validation result is retained immutably');
check(($validatedDraft->toPersistenceArray()['validation_result']['fingerprint'] ?? null) === $validation->fingerprint(), 'validation result is persisted');
$restoredValidated = NexusCompilation::fromPersistence($validatedDraft->toPersistenceArray());
check($restoredValidated->validationResult()?->fingerprint() === $validation->fingerprint(), 'validation result restores from persistence');
$compiled = $validatedDraft->withCompiledConfiguration($configA);
check($compiled->status() === CompilationStatus::Compiled, 'compiled output advances lifecycle');
check($compiled->compiledConfiguration()?->outputHash() === $configA->outputHash(), 'compiled output is retained');
check($compiled->validationResult()?->fingerprint() === $validation->fingerprint(), 'validation survives compiled transition');

$diff = new ConfigurationDiff(
    str_repeat('a', 64),
    $configA->outputHash(),
    [new SemanticDiffEntry('sections.billing.currency', SemanticChangeKind::Modify, SemanticChangeDisposition::RequiresApproval, 'USD', 'AUD', 'approval required')],
);
$withDiff = $compiled->withConfigurationDiff($diff);
check($compiled->configurationDiff() === null, 'adding diff does not mutate compiled source');
check($withDiff->configurationDiff()?->fingerprint() === $diff->fingerprint(), 'configuration diff is retained immutably');
check(($withDiff->toPersistenceArray()['diff_summary']['fingerprint'] ?? null) === $diff->fingerprint(), 'configuration diff persists to diff_summary');
$restoredWithDiff = NexusCompilation::fromPersistence($withDiff->toPersistenceArray());
check($restoredWithDiff->configurationDiff()?->fingerprint() === $diff->fingerprint(), 'configuration diff restores from persistence');

$otherTenantTrace = TraceContext::fromArray([
    'tenant_company_id' => 99,
    'trace_id' => '55555555-5555-4555-8555-555555555555',
    'correlation_id' => '66666666-6666-4666-8666-666666666666',
    'causation_id' => '77777777-7777-4777-8777-777777777777',
]);
expectInvalid(static fn () => NexusCompilation::draft(
    $profileA,
    $otherTenantTrace,
    '88888888-8888-4888-8888-888888888888',
    '0.2.0'
), 'profile and trace tenant mismatch must be rejected');

fwrite(STDOUT, "PASS: Titan Nexus standalone domain checks\n");
