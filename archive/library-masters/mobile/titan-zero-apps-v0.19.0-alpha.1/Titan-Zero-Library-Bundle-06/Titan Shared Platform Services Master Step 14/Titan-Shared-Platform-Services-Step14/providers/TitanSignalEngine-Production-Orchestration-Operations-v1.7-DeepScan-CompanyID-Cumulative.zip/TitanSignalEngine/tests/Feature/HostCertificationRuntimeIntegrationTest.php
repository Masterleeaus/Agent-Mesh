<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Extensions\TitanSignalEngine\System\Services\SignalHostCertificationService;
use Tests\TestCase;

final class HostCertificationRuntimeIntegrationTest extends TestCase
{
    public function test_host_certification_has_no_failed_checks_in_test_mode(): void
    {
        $report = app(SignalHostCertificationService::class)->certify(false, false)->toArray();
        self::assertNotSame('FAIL', $report['overall'], json_encode($report, JSON_PRETTY_PRINT));
        self::assertSame(0, $report['summary']['FAIL']);
    }
}
