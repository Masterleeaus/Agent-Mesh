<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Integrations\CommandBus;

use App\Extensions\TitanAICore\System\Contracts\CommandBusGatewayContract;
use App\Extensions\TitanAICore\System\DTO\CommandDispatchReceipt;
use App\Extensions\TitanAICore\System\DTO\CommandDispatchRequest;

final class UnavailableCommandBusGateway implements CommandBusGatewayContract
{
    public function dispatch(CommandDispatchRequest $request): CommandDispatchReceipt
    {
        return CommandDispatchReceipt::unavailable($request->planId, $request->stepId);
    }
}
