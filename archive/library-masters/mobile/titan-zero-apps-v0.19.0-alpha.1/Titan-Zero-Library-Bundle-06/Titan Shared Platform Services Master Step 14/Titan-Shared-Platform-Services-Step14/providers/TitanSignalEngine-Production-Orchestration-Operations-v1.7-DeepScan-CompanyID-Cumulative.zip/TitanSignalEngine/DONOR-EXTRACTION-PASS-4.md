# Donor Extraction — Pass 4

## Rewritten concepts

- `SignalSubscriberInterface` → `SignalSubscriberContract`
- `SignalDispatcher` fan-out loop → independent durable subscriber deliveries
- `tz_signal_queue.broadcast_status` → per-subscriber `titan_signal_deliveries.status`
- donor retry counter → bounded subscriber-specific retry policy
- donor failure logging → safe delivery error reference + immutable failure signal

## Explicitly rejected donor behavior

- custom database table as queue transport
- one failed subscriber marking the whole event failed
- replaying already-successful subscribers when another subscriber fails
- unauthenticated dispatch endpoints
- arbitrary caller-controlled subscriber identity
- mutable Signal persistence
- direct coupling to Zero/Pulse/Rewind concrete classes

Laravel Queue remains the transport. Signal owns only subscription definitions, durable delivery state and recovery semantics.
