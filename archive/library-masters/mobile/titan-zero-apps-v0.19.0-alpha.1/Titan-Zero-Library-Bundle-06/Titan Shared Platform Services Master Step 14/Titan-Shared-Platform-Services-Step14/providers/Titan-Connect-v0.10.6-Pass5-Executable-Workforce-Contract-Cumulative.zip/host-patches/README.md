# Titan Connect host compatibility

Titan Connect does **not** directly edit MagicAI's central `App\Services\Common\MenuService`.

Current Titan/Blueprint-v3 hosts should expose:

- `App\Support\Extensions\MenuContributionRegistry`
- `App\Support\Extensions\ContributionRegistry`

Titan Connect discovers these classes at boot and contributes structural navigation automatically.

## User navigation

Channel: `navigation.user`

Titan Connect contributes two top-level groups:

- **Channels** with WhatsApp, Messenger, Instagram, Telegram, SMS, Voice and Push / Mobile.
- **Inbox** with Unified, Team/Internal, External/Omnichannel, Assigned to Me, Unassigned, Needs Human and Closed/Archived.

Dynamic Inbox/Needs Human badges are fetched from Titan Connect's authenticated badge endpoint. Never persist user/company badge values in MagicAI's structural menu cache.

## Super Admin navigation and permissions

Channel: `navigation.admin`

Titan Connect contributes `admin_titan_connect_channels` and its provider children. MagicAI's administrator authorization is menu-key coupled, so the following keys must be admitted as administrator permissions or covered by the root permission and `titan-connect.admin.channels.*` route family:

- `admin_titan_connect_channels`
- `admin_titan_connect_channels_overview`
- `admin_titan_connect_channel_whatsapp`
- `admin_titan_connect_channel_messenger`
- `admin_titan_connect_channel_instagram`
- `admin_titan_connect_channel_telegram`
- `admin_titan_connect_channel_sms`
- `admin_titan_connect_channel_voice`
- `admin_titan_connect_channel_push`

Canonical permission metadata is in `System/Host/TitanConnectPermissionCatalogue.php` and `extension.manifest.json`.

## Plan entitlements

Plan entitlements answer whether the subscriber purchased a Titan Connect capability; they do **not** authorize a user inside a company. Titan Connect's company/member/connection/WorkCore checks remain mandatory after plan access is granted.

Suggested host plan keys are:

- `ext_titan_connect_core`
- `ext_titan_connect_channels`
- `ext_titan_connect_voice`

Canonical feature metadata is in `System/Host/TitanConnectFeatureCatalogue.php` and `extension.manifest.json`.

## Older MagicAI hosts

If the Blueprint-v3 registries are absent, install the same **single central contribution bridge** used by Titan Mobile Core rather than patching `MenuService` separately for Titan Connect. The bridge should:

1. expose a registry for `navigation.user` menu definitions;
2. expose a generic contribution registry with a `navigation.admin` channel;
3. merge contributed definitions into `MenuService::data()` before database/visibility rendering;
4. preserve `parent_key`, `key`, `route`, `params`, `active_condition`, `badge`, `class`, `data-name`, `extension`, `is_admin`, `permission_key` and `feature_key` fields;
5. surface the permission catalogue to MagicAI administrator-role configuration or map the root permission to `titan-connect.admin.channels.*`;
6. surface the plan entitlement catalogue to the host plan-feature registry without treating it as actor/company authorization;
7. regenerate MagicAI menu caches after extension install/update;
8. keep user/company-specific badge values out of the structural cache.

Titan Connect's semantic definitions are in `System/Navigation/TitanConnectNavigation.php`.

Do not duplicate those definitions manually in several host files. One host registry patch is the intended compatibility boundary.

## Post-install / post-upgrade sync

After the extension is installed or upgraded, run:

```bash
php artisan titan-connect:host-sync
```

The command re-registers contributions and calls `MenuService::regenerate()` only when that host service/method exists. A missing older-host menu service is treated as an integration condition, not as permission to modify arbitrary host files.
