# Troubleshooting

If analysis is unavailable, verify host provider binding or OpenAI provider configuration. If workflow routing is unavailable, evidence remains saved and the proposal stays reviewable.
