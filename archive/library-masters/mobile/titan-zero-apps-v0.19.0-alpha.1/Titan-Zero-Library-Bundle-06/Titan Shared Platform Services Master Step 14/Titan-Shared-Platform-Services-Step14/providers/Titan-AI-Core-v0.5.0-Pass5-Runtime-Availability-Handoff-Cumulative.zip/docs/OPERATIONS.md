# Operations

Use:

```bash
php artisan titan-ai-core:diagnose
php artisan titan-ai-core:host-sync
php artisan titan:titan-ai-core:certify --json
```

Pass 4 health verifies that the Risk, Assurance, Autonomy and Command Bus gateway contracts, governance coordinator and Command Bus mutation boundary are registered.

The default governance adapters intentionally defer when external engines are unavailable. This is safe while execution is disabled and provides a clear integration signal rather than silently bypassing governance.

`execution.execution_enabled` remains `false` in v0.5.0. The extension does not start queue workers, perform governed plan execution or dispatch consequential Command Bus mutations.
