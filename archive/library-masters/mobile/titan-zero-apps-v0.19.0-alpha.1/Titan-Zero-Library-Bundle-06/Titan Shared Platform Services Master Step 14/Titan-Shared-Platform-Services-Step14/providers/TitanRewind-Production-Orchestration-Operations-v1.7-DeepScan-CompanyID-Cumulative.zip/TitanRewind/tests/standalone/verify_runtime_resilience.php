<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$checks = 0; $failures = [];
$assert = static function (bool $condition, string $message) use (&$checks,&$failures): void {
    ++$checks; if (!$condition) { $failures[]=$message; fwrite(STDERR,"FAIL: {$message}\n"); }
};

$manifest = json_decode((string) file_get_contents($root.'/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$assert(($manifest['version'] ?? null) === '1.0.6','manifest version is 1.0.6');
foreach (['rewind.observability','rewind.signal','rewind.dead-letter','rewind.runtime-state','rewind.backpressure','rewind.circuit-breaker'] as $cap) {
    $assert(in_array($cap,$manifest['capabilities'] ?? [],true),"capability declared: {$cap}");
}
foreach (['titan-rewind-replay','titan-rewind-signal'] as $queue) $assert(in_array($queue,$manifest['queues']['queue_names'] ?? [],true),"queue declared: {$queue}");

$files = [
    'System/Runtime/RewindOperationalState.php','System/Runtime/RewindQueueAdmission.php','System/Runtime/RewindFailureClassifier.php',
    'System/Resilience/RewindCircuitBreaker.php','System/Observability/RewindTraceContext.php','System/Observability/RewindTelemetryRecord.php',
    'System/Contracts/RewindSignalTransportContract.php','System/Signal/UnavailableRewindSignalTransport.php','System/Signal/RewindSignalEnvelope.php',
    'System/Health/RewindHealthSnapshot.php','System/Health/RewindHealthCheck.php','System/Services/RewindRuntimeStateService.php',
    'System/Services/RewindTelemetryService.php','System/Services/RewindDeadLetterService.php','System/Services/RewindCircuitBreakerService.php',
    'System/Services/RewindSignalOutboxService.php','System/Services/RewindQueueAdmissionService.php','System/Jobs/PublishRewindSignalJob.php',
    'System/Models/RewindRuntimeState.php','System/Models/RewindDeadLetter.php','System/Models/RewindCircuitBreakerState.php',
    'System/Models/RewindObservabilityEvent.php','System/Models/RewindSignalOutbox.php','database/migrations/2026_08_16_000008_add_runtime_resilience_observability.php',
    'docs/OBSERVABILITY.md','docs/RESILIENCE.md','docs/RUNTIME-STATES.md',
];
foreach ($files as $file) $assert(is_file($root.'/'.$file),"Pass 6 file exists: {$file}");

$pure = [
    'System/Runtime/RewindOperationalState.php','System/Runtime/RewindQueueAdmission.php','System/Runtime/RewindFailureClassifier.php',
    'System/Observability/RewindTraceContext.php','System/Observability/RewindTelemetryRecord.php','System/Signal/RewindSignalEnvelope.php',
    'System/Health/RewindHealthSnapshot.php',
];
if (!array_filter($pure, static fn(string $f): bool => !is_file($root.'/'.$f))) {
    foreach ($pure as $f) require_once $root.'/'.$f;
    $state = App\Extensions\TitanRewind\System\Runtime\RewindOperationalState::from('DRAINING');
    $assert($state->acceptsNewWork() === false,'DRAINING rejects new work');
    $assert($state->allowsInFlightCompletion() === true,'DRAINING permits in-flight completion');
    $assert(App\Extensions\TitanRewind\System\Runtime\RewindOperationalState::from('ACTIVE')->acceptsNewWork(),'ACTIVE accepts new work');
    $assert(App\Extensions\TitanRewind\System\Runtime\RewindOperationalState::from('MAINTENANCE')->healthStatus() === 'MAINTENANCE','maintenance maps to health state');

    $admission = new App\Extensions\TitanRewind\System\Runtime\RewindQueueAdmission(10,20);
    $assert(($admission->evaluate('ACTIVE',2)['allowed'] ?? false) === true,'low backlog admits work');
    $assert(($admission->evaluate('ACTIVE',12)['state'] ?? null) === 'DEGRADED','soft backlog degrades admission state');
    $assert(($admission->evaluate('ACTIVE',21)['allowed'] ?? true) === false,'hard backlog rejects work');
    $assert(($admission->evaluate('DRAINING',0)['reason'] ?? null) === 'runtime_draining','draining rejects with explicit reason');

    require_once $root . '/System/Resilience/RewindCircuitBreaker.php';
    $breaker = new App\Extensions\TitanRewind\System\Resilience\RewindCircuitBreaker(3,60);
    $opened = $breaker->afterFailure('HALF_OPEN',3,1000);
    $assert(($opened['state'] ?? null) === 'OPEN' && ($opened['next_probe_at'] ?? null) === 1060,'failed half-open probe schedules a future retry window');
    $assert(($breaker->canAttempt('OPEN',1060,1059)['allowed'] ?? true) === false,'open circuit rejects requests before reset window');
    $assert(($breaker->canAttempt('OPEN',1060,1060)['state'] ?? null) === 'HALF_OPEN','open circuit transitions to half-open at reset window');

    $classifier = new App\Extensions\TitanRewind\System\Runtime\RewindFailureClassifier();
    $assert($classifier->classify(new InvalidArgumentException('bad')) === 'PERMANENT','validation failure is permanent');
    $assert($classifier->classify(new RuntimeException('REPLAY_BOUNDARY_VIOLATION')) === 'PERMANENT','replay boundary violation is permanent');
    $assert($classifier->classify(new RuntimeException('temporary timeout')) === 'RETRYABLE','generic runtime timeout is retryable');

    $ctx = App\Extensions\TitanRewind\System\Observability\RewindTraceContext::fromArray([
        'tenant_company_id'=>7,'trace_id'=>'11111111-1111-4111-8111-111111111111','correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>null,
    ]);
    $assert($ctx->tenantCompanyId() === 7,'trace context carries tenant');
    $assert($ctx->extensionKey() === 'titan-rewind','trace context carries extension key');

    $telemetry = App\Extensions\TitanRewind\System\Observability\RewindTelemetryRecord::metric('rewind.replay.queue_depth',12,'count',$ctx,['password'=>'secret','safe'=>'yes']);
    $assert(($telemetry['kind'] ?? null) === 'metric','telemetry builds metric record');
    $assert(!isset($telemetry['attributes']['password']),'telemetry strips sensitive attribute keys');
    $assert(($telemetry['attributes']['safe'] ?? null) === 'yes','telemetry retains safe attributes');

    $signal = App\Extensions\TitanRewind\System\Signal\RewindSignalEnvelope::make('rewind.replay.completed.v1',$ctx,['status'=>'completed']);
    $assert(($signal['event_type'] ?? null) === 'rewind.replay.completed.v1','Signal envelope carries versioned event type');
    $assert(($signal['tenant_company_id'] ?? null) === 7,'Signal envelope carries tenant');
    $assert(($signal['extension_key'] ?? null) === 'titan-rewind','Signal envelope carries extension key');
    $assert(isset($signal['event_id'],$signal['occurred_at'],$signal['payload']),'Signal envelope has canonical envelope fields');

    $health = new App\Extensions\TitanRewind\System\Health\RewindHealthSnapshot('DEGRADED',['database'=>'HEALTHY','signal'=>'DEGRADED'],'2026-08-16T10:00:00+00:00');
    $assert(($health->toArray()['status'] ?? null) === 'DEGRADED','health snapshot exposes aggregate state');
}

$config = (string) file_get_contents($root.'/config/titan-rewind.php');
foreach (['soft_backlog','hard_backlog','draining','dead_letter','circuit_breaker','observability','signal'] as $needle) $assert(str_contains($config,$needle),"config contains {$needle}");
$provider = (string) file_get_contents($root.'/System/TitanRewindServiceProvider.php');
foreach (['RewindHealthCheck','RewindTelemetryService','RewindDeadLetterService','RewindCircuitBreakerService','RewindSignalOutboxService','RewindQueueAdmissionService'] as $needle) $assert(str_contains($provider,$needle),"provider wires {$needle}");
$job = (string) file_get_contents($root.'/System/Jobs/RunReplaySimulationJob.php');
$assert(str_contains($job,'function backoff'),'replay job defines bounded backoff');
$assert(str_contains($job,'RewindDeadLetterService'),'replay job records terminal dead-letter state');
$assert(str_contains($job,'RewindTelemetryService'),'replay job emits operational telemetry');
$assert(is_file($root . '/schemas/health.schema.json'),'Blueprint health schema is shipped');
$assert(is_file($root . '/schemas/signal-event.schema.json'),'Blueprint Signal envelope schema is shipped');
$contract=(string)file_get_contents($root . '/System/Contracts/RewindManagerContract.php');
$assert(str_contains($contract,'function liveness'),'manager exposes independent liveness');
$assert(str_contains($contract,'function readiness'),'manager exposes independent readiness');

if ($failures !== []) { fwrite(STDERR,sprintf("\n%d/%d checks failed.\n",count($failures),$checks)); exit(1); }
printf("PASS: %d/%d runtime resilience and observability checks passed.\n",$checks,$checks);
