<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Http\Controllers;

use App\Extensions\TitanRewind\System\Models\RewindReplayRun;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Services\RewindReplayService;
use App\Extensions\TitanRewind\System\Services\RewindTenantContextResolver;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use InvalidArgumentException;

final class ReplayController
{
    public function __construct(private RewindTenantContextResolver $tenants, private RewindReplayService $replay) {}

    public function store(Request $request, string $traceId): RedirectResponse
    {
        $query = $this->query($request, $traceId);
        $run = $this->replay->queueDryRun($query, $this->actorId($request), ['requested_from'=>'user_trace']);
        return redirect()->route('dashboard.user.titan.rewind.replay.show', ['runUuid'=>$run->run_uuid]);
    }

    public function compare(Request $request, string $traceId): RedirectResponse
    {
        $query = $this->query($request, $traceId);
        $mode = (string)$request->input('mode', '');
        $input = ['requested_from'=>'user_trace','network_policy'=>'deny-all'];

        if ($mode === 'current-state') {
            $eventId = trim((string)$request->input('current_state_event_id',''));
            $decoded = json_decode((string)$request->input('current_state_override_json','{}'), true);
            if ($eventId === '' || !is_array($decoded) || $decoded === []) {
                throw new InvalidArgumentException('Current-state comparison requires an event ID and non-empty override JSON object.');
            }
            $input['current_state_overrides'] = ['events'=>[$eventId=>$decoded]];
        } elseif ($mode === 'model-compare') {
            $input['target_model'] = [
                'provider'=>(string)$request->input('target_model_provider',''),
                'model'=>(string)$request->input('target_model_name',''),
                'version'=>(string)$request->input('target_model_version',''),
            ];
        } elseif ($mode === 'policy-compare') {
            $input['target_policy'] = ['version'=>(string)$request->input('target_policy_version','')];
        } elseif ($mode === 'knowledge-compare') {
            $input['target_knowledge'] = ['version'=>(string)$request->input('target_knowledge_version','')];
        } elseif ($mode === 'counterfactual') {
            $eventId = trim((string)$request->input('counterfactual_event_id',''));
            $decoded = json_decode((string)$request->input('counterfactual_override_json','{}'), true);
            if ($eventId === '' || !is_array($decoded) || $decoded === []) {
                throw new InvalidArgumentException('Counterfactual comparison requires an event ID and non-empty override JSON object.');
            }
            $input['counterfactual_overrides'] = ['events'=>[$eventId=>$decoded]];
        }

        $run = $this->replay->queueComparison($query, $mode, $this->actorId($request), $input);
        return redirect()->route('dashboard.user.titan.rewind.replay.show', ['runUuid'=>$run->run_uuid]);
    }

    public function show(Request $request, string $runUuid): View
    {
        $tenant = $this->tenants->forUser($request->user());
        abort_if($tenant === null, 403, 'Titan Rewind could not resolve an explicit tenant company for this account.');
        $run = RewindReplayRun::query()->where('tenant_company_id',$tenant)->where('run_uuid',$runUuid)->firstOrFail();
        return view('titan-rewind::replay', ['run'=>$run]);
    }

    private function query(Request $request, string $traceId): RewindTraceQuery
    {
        $tenant = $this->tenants->forUser($request->user());
        abort_if($tenant === null, 403, 'Titan Rewind could not resolve an explicit tenant company for this account.');
        return RewindTraceQuery::fromArray(['tenant_company_id'=>$tenant,'trace_id'=>$traceId]);
    }

    private function actorId(Request $request): ?int
    {
        $id = $request->user()?->getAuthIdentifier();
        return is_numeric($id) ? (int)$id : null;
    }
}
