<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\TitanAiRuntimeBridgeContract;

final class TitanAiRuntimeLiveBridge implements TitanAiRuntimeBridgeContract
{
    public function __construct(private readonly object $runtime) {}

    public function status(): array
    {
        return [
            'available' => true,
            'reason_codes' => [],
            'class' => $this->runtime::class,
            'approval_authority' => false,
        ];
    }
}
