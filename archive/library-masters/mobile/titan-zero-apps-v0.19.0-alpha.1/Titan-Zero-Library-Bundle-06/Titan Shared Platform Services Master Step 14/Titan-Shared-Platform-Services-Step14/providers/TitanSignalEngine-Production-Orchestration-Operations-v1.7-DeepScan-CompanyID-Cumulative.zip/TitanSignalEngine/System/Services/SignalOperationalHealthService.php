<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Data\OperationalHealthClassifier;
use App\Extensions\TitanSignalEngine\System\Data\PulseProjectionFreshness;
use App\Extensions\TitanSignalEngine\System\Models\SignalAnomaly;
use App\Extensions\TitanSignalEngine\System\Models\SignalArchiveBatch;
use App\Extensions\TitanSignalEngine\System\Models\SignalEventLifecycle;
use App\Extensions\TitanSignalEngine\System\Models\SignalOperationalHealthSnapshot;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseProjectionFreshness;
use App\Extensions\TitanSignalEngine\System\Models\SignalTraceAssignment;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Support\Facades\Schema;

final class SignalOperationalHealthService
{
    public function __construct(private readonly SignalBackpressureMonitor $backpressure) {}

    /** @return array<string,mixed> */
    public function snapshot(bool $refreshIfStale = true): array
    {
        $ttl = max(10, min((int) config('titan-signal-engine.health_snapshot_ttl_seconds', 60), 300));
        if (Schema::hasTable('titan_signal_operational_health_snapshots')) {
            $row = SignalOperationalHealthSnapshot::query()->where('snapshot_key', 'platform')->first();
            if ($row !== null && (! $refreshIfStale || $row->captured_at?->gt(now()->subSeconds($ttl)))) {
                return $this->rowArray($row);
            }
        }
        return $this->refresh();
    }

    /** @return array<string,mixed> */
    public function refresh(): array
    {
        $backpressure = $this->backpressure->snapshot();
        $freshness = $this->platformFreshness();
        $current = [
            'backpressured' => (bool) ($backpressure['backpressured'] ?? false),
            'recent_dead_letter' => (int) ($backpressure['recent_dead_letter'] ?? 0),
            'unresolved_dead_letter' => (int) ($backpressure['unresolved_dead_letter'] ?? 0),
            'pending' => (int) ($backpressure['pending'] ?? 0),
            'retry_wait' => (int) ($backpressure['retry_wait'] ?? 0),
            'processing' => (int) ($backpressure['processing'] ?? 0),
            'stale_processing' => (int) ($backpressure['stale_processing'] ?? 0),
            'critical_open' => $this->criticalOpen(),
            'pulse_projection_status' => (string) ($freshness['status'] ?? 'idle'),
            'pulse_projection' => $freshness,
            'trace_evaluation' => $this->traceEvaluationCurrent(),
            'lifecycle' => $this->lifecycleCurrent(),
        ];
        $historical = [
            'resolved_dead_letter_30d' => $this->resolvedDeadLetters30d(),
            'resolved_critical_anomaly_30d' => $this->resolvedCriticalAnomalies30d(),
            'verified_archive_batches' => $this->verifiedArchiveBatches(),
        ];
        $classified = OperationalHealthClassifier::classify($current, $historical);
        $payload = [
            'status' => $classified['status'],
            'current' => $current,
            'historical_incidents' => $historical,
            'captured_at' => now()->toIso8601String(),
        ];
        if (Schema::hasTable('titan_signal_operational_health_snapshots')) {
            SignalOperationalHealthSnapshot::query()->updateOrCreate(['snapshot_key' => 'platform'], [
                'status' => $payload['status'],
                'current_state' => $current,
                'historical_incidents' => $historical,
                'captured_at' => now(),
            ]);
        }
        return $payload;
    }

    /** @return array<string,mixed> */
    private function platformFreshness(): array
    {
        if (! Schema::hasTable('titan_signal_pulse_projection_freshness')) return ['status' => 'not_initialized'];
        $row = SignalPulseProjectionFreshness::query()->where('scope', 'platform')->where('tenant_key', 0)->where('dimension', 'all')->where('dimension_value', '__all__')->first();
        if ($row === null) return ['status' => 'idle'];
        $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $projected = $row->last_projected_at ? new DateTimeImmutable($row->last_projected_at->format(DATE_ATOM)) : null;
        $recorded = $row->last_recorded_at ? new DateTimeImmutable($row->last_recorded_at->format(DATE_ATOM)) : null;
        $ingested = $row->last_ingested_recorded_at ? new DateTimeImmutable($row->last_ingested_recorded_at->format(DATE_ATOM)) : null;
        return PulseProjectionFreshness::evaluate($projected, $recorded, $ingested, $now, (int) config('titan-signal-engine.pulse_projection_degraded_after_seconds', 300));
    }

    private function criticalOpen(): int
    {
        if (! Schema::hasTable('titan_signal_anomalies')) return 0;
        return SignalAnomaly::query()->whereIn('status', ['open', 'acknowledged'])->where('severity', 'critical')->count();
    }

    /** @return array<string,int|string|null> */
    private function traceEvaluationCurrent(): array
    {
        if (! Schema::hasTable('titan_signal_trace_assignments')) return ['open' => 0, 'partial' => 0, 'invalid' => 0, 'due' => 0, 'stale' => 0, 'last_evaluated_at' => null];
        $counts = ['open' => 0, 'partial' => 0, 'invalid' => 0];
        foreach (SignalTraceAssignment::query()->whereIn('status', array_keys($counts))->selectRaw('status, COUNT(*) aggregate')->groupBy('status')->cursor() as $row) $counts[(string) $row->status] = (int) $row->aggregate;
        return [...$counts,
            'due' => SignalTraceAssignment::query()->whereNotNull('next_evaluation_at')->where('next_evaluation_at', '<=', now())->count(),
            'stale' => SignalTraceAssignment::query()->whereIn('status', ['open','partial','invalid'])->where(fn ($q) => $q->whereNull('fresh_until')->orWhere('fresh_until', '<', now()))->count(),
            'last_evaluated_at' => (($v = SignalTraceAssignment::query()->max('last_evaluated_at')) === null ? null : (string) $v),
        ];
    }

    /** @return array<string,int> */
    private function lifecycleCurrent(): array
    {
        if (! Schema::hasTable('titan_signal_event_lifecycle')) return ['legal_holds' => 0, 'prune_candidates' => 0];
        return [
            'legal_holds' => SignalEventLifecycle::query()->where('legal_hold', true)->whereNull('pruned_at')->count(),
            'prune_candidates' => SignalEventLifecycle::query()->where('legal_hold', false)->whereNull('pruned_at')->whereNotNull('retain_until')->where('retain_until', '<=', now())->count(),
        ];
    }

    private function resolvedDeadLetters30d(): int
    {
        if (! Schema::hasTable('titan_signal_deliveries')) return 0;
        return \App\Extensions\TitanSignalEngine\System\Models\SignalDelivery::query()->whereNotNull('dead_letter_resolved_at')->where('dead_letter_resolved_at', '>=', now()->subDays(30))->count();
    }

    private function resolvedCriticalAnomalies30d(): int
    {
        if (! Schema::hasTable('titan_signal_anomalies')) return 0;
        return SignalAnomaly::query()->where('status', 'resolved')->where('severity', 'critical')->whereNotNull('resolved_at')->where('resolved_at', '>=', now()->subDays(30))->count();
    }

    private function verifiedArchiveBatches(): int
    {
        if (! Schema::hasTable('titan_signal_archive_batches')) return 0;
        return SignalArchiveBatch::query()->whereNotNull('verified_at')->where('archive_driver', '!=', 'none')->count();
    }

    /** @return array<string,mixed> */
    private function rowArray(SignalOperationalHealthSnapshot $row): array
    {
        return ['status' => (string) $row->status, 'current' => (array) $row->current_state, 'historical_incidents' => (array) $row->historical_incidents, 'captured_at' => $row->captured_at?->toIso8601String()];
    }
}
