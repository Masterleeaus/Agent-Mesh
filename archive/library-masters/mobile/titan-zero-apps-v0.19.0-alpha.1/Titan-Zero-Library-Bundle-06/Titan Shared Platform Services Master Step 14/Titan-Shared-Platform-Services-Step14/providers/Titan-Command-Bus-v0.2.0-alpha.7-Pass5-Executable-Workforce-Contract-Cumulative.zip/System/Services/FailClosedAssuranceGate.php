<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Services;

use App\Extensions\TitanCommandBus\System\Contracts\CommandAssuranceGateContract;
use App\Extensions\TitanCommandBus\System\DTO\AssuranceDecision;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use App\Extensions\TitanCommandBus\System\DTO\RiskDecision;

final class FailClosedAssuranceGate implements CommandAssuranceGateContract
{
    public function available(): bool { return false; }

    public function assess(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null): AssuranceDecision
    {
        return new AssuranceDecision(false, null, null, [], 'ASSURANCE_UNAVAILABLE');
    }
}
