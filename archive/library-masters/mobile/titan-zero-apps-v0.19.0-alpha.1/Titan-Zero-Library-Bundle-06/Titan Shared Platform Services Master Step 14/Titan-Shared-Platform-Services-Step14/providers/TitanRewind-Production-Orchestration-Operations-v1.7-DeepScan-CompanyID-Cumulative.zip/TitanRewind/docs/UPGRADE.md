# Upgrade

Titan Rewind upgrades use additive/forward-compatible migrations in the current cumulative build. Existing historical records and hashes are preserved rather than rewritten in place.

Blueprint v4.1 final certification requires migration locking, chunked backfills, old/new worker compatibility and interrupted-migration recovery proof. Those operational certification gates remain scheduled for the final production-hardening pass.
