# Authorization matrix

| Permission | Purpose | Default |
|---|---|---|
| `titan-people.view` | View authenticated People browser/API surfaces and use actor-derived self-service | deny |
| `titan-people.manage` | Edit allowlisted People-owned worker identity/profile facts | deny |
| `titan-people.import` | Run explicitly mapped HRCore import | deny |
| `titan-people.lifecycle.manage` | Submit authorized employment lifecycle management commands | deny |
| `titan-people.documents.manage` | Manage private People-owned HR documents | deny |
| `titan-people.leave.manage` | Decide/manage leave through governed People boundaries | deny |
| `titan-people.holidays.manage` | Manage People holiday facts | deny |
| `titan-people.profile.sensitive` | View/manage sensitive profile fields beyond self-service | deny |

Super Admin is the only unconditional platform bypass. Delegated admin permissions remain explicit; the default compatibility configuration delegates only `titan-people.view` to host admins. Tenant/company authority is always resolved separately from permission checks.
