# Titan Signal Engine v0.15.0 — Production Hardening Pass 7

## Goal

Preserve causal reconstruction and Rewind continuity across the hot/cold retention boundary without rehydrating archived events into the hot event store.

## Implemented

- `SignalHistoryTraversalContract` with detailed trace/correlation windows.
- `SignalHistoryWindow` completeness, storage-tier and cold-failure semantics.
- Archive-catalog causation lookup/counts plus indexed `causation_id` traversal.
- Hot-store causation lookup independent of ephemeral causal-edge projections.
- `HistoryCorrelationAssembler` for mixed-tier analyzer envelopes, storage metadata and causal edges.
- Correlation ancestors/descendants/trace/workflow rewritten over governed history rather than hot-only storage.
- Rewind receipts enriched with hot/cold/mixed tier and cold-history completeness.
- Corrupt/unavailable cold history yields explicit partial projections and blocks trace-evaluation projection.
- Host and pure-PHP regression coverage.

## Deliberate boundary

No-archive retention classes remain intentionally unrecoverable; Signal reports missing causal history rather than fabricating tombstones that imply archived event availability.
