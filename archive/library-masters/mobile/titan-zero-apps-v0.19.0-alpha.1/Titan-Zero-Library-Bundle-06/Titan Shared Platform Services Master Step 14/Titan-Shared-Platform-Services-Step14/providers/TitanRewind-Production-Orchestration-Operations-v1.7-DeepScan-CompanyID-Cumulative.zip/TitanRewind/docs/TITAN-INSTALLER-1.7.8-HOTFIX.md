# Titan Rewind v1.0.2 — Installer 1.7.8 Integrity Hotfix (retained in v1.0.4)

## Root cause

Titan Rewind v1.0.1 passed manifest/dependency/conflict validation on Titan Extension Manager 1.7.8, then failed package integrity validation with:

`Package integrity file list does not match the archive contents.`

The v1.0.1 archive contained `FILE-SHA256.json`, but the root `extension.json` intentionally omitted both itself and `FILE-SHA256.json` from `integrity.files`. Installer 1.7.8 permits the self-referential `extension.json` omission but requires every other packaged regular file to be represented in `integrity.files`.

## v1.0.2 correction

- keep the flat-root `titan-extension-v1` installer manifest;
- remove redundant `FILE-SHA256.json` from the installable archive;
- make root `extension.json.integrity.files` exactly equal to every packaged regular file except `extension.json`;
- preserve the independent non-installer internal inventory at `docs/FILE-INTEGRITY.json`;
- preserve Blueprint v4.1 schema-v2 `runtime_profile: titan-rewind` in `extension.manifest.json`;
- rerun every Rewind verifier against the exact packaged bytes.

No Rewind forensic, replay, governance or authoritative-state behavior is changed by this hotfix.
