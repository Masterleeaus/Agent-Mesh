<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Data\RetentionClass;
use App\Extensions\TitanSignalEngine\System\Data\RetentionPolicy;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;

final class RetentionPolicyResolver
{
    public function resolve(SignalEvent $event): RetentionPolicy
    {
        $eventType = (string) $event->event_type;
        $category = strtolower((string) ($event->category ?? ''));
        $severity = strtolower((string) ($event->severity ?? 'info'));
        $overrides = (array) config('titan-signal-engine.retention_event_overrides', []);
        if (isset($overrides[$eventType])) {
            return RetentionPolicy::for(RetentionClass::from((string) $overrides[$eventType]));
        }
        if (in_array($eventType, (array) config('titan-signal-engine.retention_critical_event_types', []), true)) {
            return RetentionPolicy::for(RetentionClass::CriticalAudit);
        }
        if ($severity === 'debug') {
            return RetentionPolicy::for(RetentionClass::Debug);
        }
        if (in_array($category, ['governance', 'security', 'compliance', 'risk', 'audit'], true) || in_array($severity, ['critical', 'fatal'], true)) {
            return RetentionPolicy::for(RetentionClass::Audit);
        }
        if (in_array($category, ['telemetry', 'metrics', 'diagnostics'], true)) {
            return RetentionPolicy::for(RetentionClass::Telemetry);
        }
        return RetentionPolicy::for(RetentionClass::Operational);
    }
}
