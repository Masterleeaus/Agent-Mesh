<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

final class DenyAllWorkCoreAuthorizationGateway implements WorkCoreAuthorizationGateway
{
    public function assertCanAccess(int $companyId, int $actorId, string $entityType, string $entityId): void
    {
        throw new AccessDeniedHttpException('WorkCore authorization adapter is required for linked rooms.');
    }
}
