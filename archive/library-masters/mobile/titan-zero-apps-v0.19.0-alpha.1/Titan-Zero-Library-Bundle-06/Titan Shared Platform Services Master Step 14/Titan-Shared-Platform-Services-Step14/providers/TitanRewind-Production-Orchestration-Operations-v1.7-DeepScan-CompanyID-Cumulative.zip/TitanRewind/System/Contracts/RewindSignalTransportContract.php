<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Contracts;

interface RewindSignalTransportContract
{
    public function available(): bool;
    /** @param array<string,mixed> $event */
    public function publish(array $event): void;
}
