# Operations

Rollout starts INTERNAL. Kill switch disables readiness. Host menu sync is idempotent and preserves administrator order/enabled state.
