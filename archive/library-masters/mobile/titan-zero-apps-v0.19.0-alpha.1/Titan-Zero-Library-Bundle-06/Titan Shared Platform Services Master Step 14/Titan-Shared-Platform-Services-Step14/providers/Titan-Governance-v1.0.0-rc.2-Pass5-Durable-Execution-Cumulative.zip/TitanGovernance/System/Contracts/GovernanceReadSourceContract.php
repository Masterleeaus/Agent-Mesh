<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Contracts;

interface GovernanceReadSourceContract
{
    public function key(): string;

    public function required(): bool;

    /**
     * Return a tenant-scoped, read-only governance snapshot.
     * Implementations must not mutate the source engine or business state.
     *
     * @return array<string,mixed>
     */
    public function snapshot(int $tenantCompanyId, array $context = []): array;
}
