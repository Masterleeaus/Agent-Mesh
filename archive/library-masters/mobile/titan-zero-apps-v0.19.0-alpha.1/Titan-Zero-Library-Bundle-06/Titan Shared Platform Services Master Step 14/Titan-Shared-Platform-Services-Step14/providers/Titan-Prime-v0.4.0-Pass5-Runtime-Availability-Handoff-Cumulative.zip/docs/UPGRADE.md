# Upgrade

Upgrades remain forward-only. Historical migrations are retained unchanged.

v0.3.0 adds two additive migrations:

1. extend `titan_prime_missions` with durable mission identity, objective/budget state, initiator identity, `lock_version` and `record_format`;
2. create `titan_prime_mission_operations` for tenant-scoped idempotency receipts.

Existing scaffold rows remain present and are tagged by the migration default as `legacy-v1`. The authoritative repository only reads/writes `mission-v2`, so unscoped legacy records cannot accidentally enter governed mission execution. No destructive legacy backfill is performed in this pass because the original scaffold did not contain enough tenant/mission evidence to infer safe ownership.
