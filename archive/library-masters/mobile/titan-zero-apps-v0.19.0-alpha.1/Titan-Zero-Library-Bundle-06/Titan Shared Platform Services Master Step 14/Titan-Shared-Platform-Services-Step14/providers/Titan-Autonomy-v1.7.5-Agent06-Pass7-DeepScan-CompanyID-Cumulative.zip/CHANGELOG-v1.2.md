# Titan Autonomy Engine v1.2.0

## Control plane and host integration

- Added tenant-facing **Autonomy Learning** dashboard and capability review screens.
- Added explicit next-gate activation; the browser cannot supply or skip the promoted autonomy level.
- Added manual authority reduction, capability training reset, learned-preference clearing and tenant learning export.
- Added tenant learning settings with system-wide learning constrained by platform permission.
- Added Super Admin autonomy policy UI with immutable platform safety floors and governed High/Critical exceptions.
- Added server-derived `tenant_company_id`/user context bridge; request data never establishes tenancy.
- Added fail-closed Assurance, Interaction Engine and CommandBus adapters, plus optional Rewind bridge.
- Added structured Trusted Auto review using fresh Assurance output and existing three-way handshake persistence.
- Added control-plane audit events and Rewind correlation for activations, regressions, resets, policy/settings changes and learning outcomes.
- Added user/admin navigation contributions with safe fallback icon metadata.
- Added configurable dashboard route prefix, middleware and host layout with local Blade fallback.

## Safety invariants retained

- capability/workflow isolation;
- one-gate-at-a-time promotion;
- no silent escalation;
- bounded scope from Semi-Auto upward;
- Platform + User + TitanAI/Assurance for Trusted Auto;
- tenant policy can only be stricter;
- system-wide learning remains opt-in and de-identified;
- missing host integrations deny rather than bypass governance.
