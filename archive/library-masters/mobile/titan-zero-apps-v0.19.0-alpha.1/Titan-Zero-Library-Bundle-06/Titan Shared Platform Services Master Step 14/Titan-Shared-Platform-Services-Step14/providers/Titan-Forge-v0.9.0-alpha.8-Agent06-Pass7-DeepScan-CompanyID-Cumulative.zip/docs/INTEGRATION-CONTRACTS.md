# Titan Forge Integration Contracts

Forge integrates through public contracts/adapters and never imports peer persistence.

- **Titan AI Core (`titan-ai-core`)** — optional AI planning/runtime authority. Forge consumes its typed orchestrator and plan-validator contracts. Current v0.3.0 planning remains fail-closed pending DAG validation, and no artifact-generation contract exists yet; Forge never bypasses this boundary with direct provider calls.

- **Titan Signal (`titan-signal`)** — required canonical dependency. Emits Forge lifecycle facts using `titan.signal.integration.v1` and complete causal lineage.
- **Titan Risk (`titan-risk`)** — release-candidate risk gate. `DENY` rejects; hold/approval directives block progression.
- **Titan Shield (`titan-shield`)** — consumes Forge validation findings as governance evidence and may block progression.
- **Titan Model Council (`titan-model-council >=0.7.0`)** — selective high/critical-risk governed deliberation through `CouncilGatewayContract::runGoverned(...)`. Forge sends a bounded metadata packet and host-policy role-model assignments, then stores only a sanitized decision receipt. Council remains advisory and never becomes deployment authority.
- **Titan Governance (`titan-governance`)** — final policy/approval authority. The verified current public contract is health-only, so Forge fails closed.
- **Titan Command Bus (`titan-command-bus`)** — production mutation/execution boundary. The verified current public contract is health-only, so Forge does not dispatch or self-deploy.
- **Titan Rewind (`titan-rewind >=1.0.0`)** — optional forensic consumer. Forge owns and exports `titan-forge.rewind-source` through Blueprint v4.2.1's host-level `App\Support\Extensions\RewindSourceAdapter`. The source is tenant/trace scoped, read-only and authority-neutral; Forge imports no Rewind internals and writes no Rewind tables. Current `supports_as_of=false`, so exact historical point-in-time replay remains unavailable.

Forge's root installer uses canonical Blueprint slugs. Runtime adapters resolve verified PHP public contract interfaces and do not depend on another extension's database models.
