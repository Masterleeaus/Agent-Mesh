<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\DTOs\ScopeEvaluation;

final class ScopeEvaluator
{
    public function evaluate(array $scope, array $context): ScopeEvaluation
    {
        $reasons = [];

        if (isset($scope['workflow']) && ($context['workflow'] ?? null) !== $scope['workflow']) {
            $reasons[] = 'WORKFLOW_OUT_OF_SCOPE';
        }
        if (isset($scope['vertical']) && ($context['vertical'] ?? null) !== $scope['vertical']) {
            $reasons[] = 'VERTICAL_OUT_OF_SCOPE';
        }
        if (isset($scope['max_total']) && (!isset($context['total']) || (float) $context['total'] > (float) $scope['max_total'])) {
            $reasons[] = 'MAX_TOTAL_EXCEEDED';
        }
        if (isset($scope['max_discount']) && (!isset($context['discount']) || (float) $context['discount'] > (float) $scope['max_discount'])) {
            $reasons[] = 'MAX_DISCOUNT_EXCEEDED';
        }
        if (isset($scope['max_stock_quantity']) && (!isset($context['stock_quantity']) || (int) $context['stock_quantity'] > (int) $scope['max_stock_quantity'])) {
            $reasons[] = 'MAX_STOCK_QUANTITY_EXCEEDED';
        }
        if (($scope['requires_no_dispute'] ?? false) && (($context['has_dispute'] ?? true) !== false)) {
            $reasons[] = 'DISPUTE_PRESENT_OR_UNKNOWN';
        }
        if (($scope['requires_no_unapproved_variation'] ?? false) && (($context['has_unapproved_variation'] ?? true) !== false)) {
            $reasons[] = 'UNAPPROVED_VARIATION_PRESENT_OR_UNKNOWN';
        }
        if (($scope['requires_job_completed'] ?? false) && (($context['job_completed'] ?? false) !== true)) {
            $reasons[] = 'JOB_NOT_CONFIRMED_COMPLETED';
        }
        if (isset($scope['allowed_regions']) && !in_array($context['region'] ?? null, (array) $scope['allowed_regions'], true)) {
            $reasons[] = 'REGION_OUT_OF_SCOPE';
        }
        if (isset($scope['allowed_services']) && !in_array($context['service'] ?? null, (array) $scope['allowed_services'], true)) {
            $reasons[] = 'SERVICE_OUT_OF_SCOPE';
        }
        if (isset($scope['minimum_confidence']) && (float) ($context['confidence'] ?? 0.0) < (float) $scope['minimum_confidence']) {
            $reasons[] = 'CONFIDENCE_BELOW_SCOPE_THRESHOLD';
        }

        return new ScopeEvaluation($reasons === [], array_values(array_unique($reasons)));
    }
}
