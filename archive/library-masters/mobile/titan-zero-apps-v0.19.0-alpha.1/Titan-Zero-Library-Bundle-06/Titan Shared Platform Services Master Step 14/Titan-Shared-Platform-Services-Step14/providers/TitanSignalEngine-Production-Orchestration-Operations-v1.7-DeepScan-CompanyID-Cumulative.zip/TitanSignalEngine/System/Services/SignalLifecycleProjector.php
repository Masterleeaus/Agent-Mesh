<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalLifecycleProjectorContract;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use App\Extensions\TitanSignalEngine\System\Models\SignalEventLifecycle;
use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;
use Illuminate\Support\Facades\Schema;

final class SignalLifecycleProjector implements SignalLifecycleProjectorContract
{
    public function __construct(private readonly RetentionPolicyResolver $resolver)
    {
    }

    public function project(SignalEvent $event): void
    {
        if (! Schema::hasTable('titan_signal_event_lifecycle')) {
            return;
        }
        if (SignalEventLifecycle::query()->where('event_id', $event->event_id)->exists()) {
            return;
        }
        $policy = $this->resolver->resolve($event);
        $recordedAt = $event->recorded_at instanceof DateTimeInterface
            ? new DateTimeImmutable($event->recorded_at->format(DATE_ATOM))
            : new DateTimeImmutable((string) $event->recorded_at, new DateTimeZone('UTC'));
        $retainUntil = $policy->retentionDays === null ? null : $recordedAt->modify('+' . $policy->retentionDays . ' days');
        SignalEventLifecycle::query()->create([
            'event_id' => (string) $event->event_id,
            'scope' => (string) $event->scope,
            'tenant_company_id' => $event->tenant_company_id,
            'tenant_key' => (int) ($event->tenant_company_id ?? 0),
            'retention_class' => $policy->class->value,
            'retain_until' => $retainUntil,
            'legal_hold' => false,
        ]);
    }
}
