<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$inv=(string)file_get_contents($root.'/docs/DONOR-INVENTORY.md');
foreach(['BookingModule','Quoting wizard','Quotes','QuoteEngine','FSMSales','FSMServiceAgreement','FSMSaleAgreement','FSMSaleRecurring','FSMSaleRecurringAgreement'] as $d)$t->assert(str_contains($inv,$d),'donor inventory missing '.$d);
$own=(string)file_get_contents($root.'/docs/OWNERSHIP.md');
foreach(['CRM customers','schedules','invoices','payment ledgers','payroll'] as $x)$t->assert(str_contains($own,$x),'ownership boundary missing '.$x);
$t->finish('Pass1 donor boundary');
