# Titan Forge — Upgrade Prompt

# Titan Zero Global Architecture Rules

This extension is part of the governed Titan Zero architecture. Preserve these boundaries:

- AI intelligence never directly mutates authoritative business state when a governed capability/Command Bus path exists.
- Intelligence, risk, assurance, autonomy, approval and execution remain separate concerns.
- Every significant action emits structured Signal telemetry and a traceable receipt.
- Use tenant_company_id, trace_id, correlation_id, causation_id and root_causation_id on durable cross-extension records/events.
- Do not store unrestricted hidden model reasoning; store structured decision rationale, reason codes, policy/evidence references and outcomes.
- Offline operation may reduce authority but must never increase it.
- External side effects must be idempotent.
- Preserve installer compatibility and existing working host UI conventions.
- Prefer shared contracts/adapters over importing another extension's internal implementation classes.

## Extension Mission

MISSION: Build Titan Forge as the governed system-generation layer that builds Titan inside Titan.

OWN: generation jobs for extensions, PWAs, workflows, Wizards, UI, capability scaffolds, integrations and Vertical Engine assets.

## Preserved foundation through v0.9.0-alpha.1

- typed build/artifact/validation/release domain contracts
- normalized persistence and tenant/idempotency boundary
- deterministic Workforce scaffold profile
- active queued generation
- filesystem-isolated sandbox workspace
- validator registry and persisted validation runs/findings
- verified Titan Signal lifecycle adapter
- verified Titan Risk release-gate adapter
- verified Titan Shield governance-response adapter
- selective Model Council activation assessment for high/critical risk
- persisted governed release candidates
- fail-closed Governance and Command Bus boundaries because their verified v0.1.0 public contracts are health-only
- no direct production deployment authority
- Manifest v2.2 / builder-generator / signal-aware production inheritance
- complete causal lineage including root_causation_id

## Current completed build — formal roadmap Pass 19

1. Forge exports `titan-forge.rewind-source` through Blueprint v4.2.1's host-owned read-only Rewind source contract.
2. Rewind evidence covers build, plan, artifact, validation, Shield, Risk, Council, Governance, release-candidate and receipt phases using bounded state and hashes only.
3. Source projection is tenant/trace scoped, cursor-backed, streaming, deterministically sequenced and SHA-256 integrity chained.
4. Forge never copies build instructions, artifact contents, Council transcripts/final-answer text or hidden reasoning into the forensic feed.
5. `supports_as_of=false` is deliberate; mutable build rows mean exact historical point-in-time reconstruction is not yet truthful, so reproducibility remains partial.
6. Rewind remains a read-only forensic consumer and gains no approval, mutation or deployment authority.

## NEXT BUILD — formal roadmap Pass 20

1. Build the Titan-native deterministic extension package builder from validated Forge ArtifactSets.
2. Produce canonical Installer 1.7.8 manifests, Manifest v2.2 sidecars, SBOM/provenance and exact file inventories from the package candidate.
3. Enforce flat archive layout, safe paths, deterministic package contents, clean extraction and exact-ZIP integrity verification.
4. Package building must not install or deploy the package; release authority remains governed and external to Forge.

## Later roadmap

- Titan-native package builder and immutable release lifecycle
- rollback receipts
- Knowledge Authority generation standards
- Wisdom outcome feedback
- queue resilience and operational UI hardening
- final static and live host certification

## Universal Acceptance

- Installer/manifest validation passes.
- PHP syntax checks pass.
- Tenant boundaries are explicit.
- Cross-engine calls use verified public contracts/adapters.
- Significant states are traceable.
- No high-risk or authoritative mutation bypass is introduced.


## Cumulative status — v0.9.0-alpha.1

Forge roadmap Pass 19 exports deterministic, hashed, read-only Forge evidence through the Blueprint v4.2.1 Rewind source contract. Current source reads can be complete, but exact historical `as_of` replay remains unsupported and reconstruction is only partially reproducible. Next formal pass: Pass 20 Titan-native package builder.
