<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

interface MessagingToolGateway
{
    public function messagesRead(int $companyId, int $actorId, string $conversationUuid, int $limit = 50): array;
    public function messagesSend(int $companyId, int $actorId, string $conversationUuid, string $body, ?string $idempotencyUuid = null): array;
    public function conversationCreate(int $companyId, int $actorId, string $type, ?string $name, array $userIds): array;
    public function conversationReply(int $companyId, int $actorId, string $conversationUuid, string $body, ?string $idempotencyUuid = null): array;
    public function externalSend(int $companyId, int $actorId, string $connectionUuid, string $threadUuid, string $recipient, string $body, string $idempotencyKey): array;
}
