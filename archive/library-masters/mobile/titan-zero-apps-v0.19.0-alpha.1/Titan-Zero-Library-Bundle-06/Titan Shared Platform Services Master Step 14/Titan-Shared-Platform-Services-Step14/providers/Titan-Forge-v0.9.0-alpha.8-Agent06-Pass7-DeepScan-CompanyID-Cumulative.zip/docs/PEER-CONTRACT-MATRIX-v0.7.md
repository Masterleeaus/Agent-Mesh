# Titan Forge v0.7 — Verified Peer Contract Matrix

This matrix records the peer contracts verified for the v0.7 AI consumer pass in addition to the existing governance bridge.

| Engine | Verified package | Public contract used by Forge | Forge v0.7 treatment |
|---|---|---|---|
| Titan AI Core | v0.3.0 Pass 2 Typed Core Domain, Blueprint v4.2 | `OrchestratorContract::createPlan(...)` + `PlanValidatorContract::validate(...)` | Typed planning consumer implemented. Current peer returns an empty typed envelope and `DAG_VALIDATOR_NOT_IMPLEMENTED`, therefore Forge fails closed as `planning_blocked`. AI Core exposes no artifact-generation contract yet, so live AI artifact generation is `generation_blocked`. |
| Titan Signal Engine | v0.2.0 Pass 1 Foundation | `SignalEmitterContract::emit(...)` | Lifecycle adapter; complete tenant and causal lineage. |
| Titan Risk Engine | v0.2.1 Pass 2A | `RiskGateContract::evaluate(...)` | Release-risk adapter. Deny rejects; hold/approval blocks. |
| Titan Shield | v0.3.0 Inspection Foundation | `ShieldManagerContract::determineGovernanceResponse(...)` | Governs Forge validation findings; does not replace Forge static validation. |
| Titan Model Council | v0.5.0 Pass 4 | Council health/activation contract | Selective activation only; not final governed approval. |
| Titan Governance | v0.1.0 Scaffold | health only | Fail-closed release-decision boundary. |
| Titan Command Bus | v0.1.0 Scaffold | health only | Fail-closed production mutation boundary. |

## AI ownership rule

Titan AI Core owns model/runtime orchestration. Forge owns build planning consumption, isolated generation workspaces, artifact validation and release candidates. Forge never bypasses AI Core to call a model provider directly.
