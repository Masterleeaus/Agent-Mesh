<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix='App\\Extensions\\TitanAutonomy\\';
    if(!str_starts_with($class,$prefix))return;
    $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($prefix))).'.php';
    if(is_file($path))require_once $path;
});

use App\Extensions\TitanAutonomy\System\Services\OperationsStatusClassifier;

$svc=new OperationsStatusClassifier();
$future=gmdate('Y-m-d H:i:s',time()+3600);
$past=gmdate('Y-m-d H:i:s',time()-60);

$observing=$svc->classify(['observation_status'=>'observing','matures_at'=>$future,'final_label'=>null]);
if(($observing['status']??null)!=='observing'||($observing['can_recheck']??true)!==false)throw new RuntimeException('Unmatured receipt must remain observing and cannot be manually reconciled early.');

$due=$svc->classify(['observation_status'=>'observing','matures_at'=>$past,'final_label'=>null]);
if(($due['status']??null)!=='due_for_reconciliation'||($due['can_recheck']??false)!==true)throw new RuntimeException('Matured observing receipt must become due and allow safe recheck.');

$human=$svc->classify(['observation_status'=>'awaiting_human_verification','matures_at'=>null,'risk'=>'critical']);
if(($human['status']??null)!=='awaiting_human_verification'||($human['attention']??false)!==true)throw new RuntimeException('Critical non-maturing receipt must stay in human verification queue.');

$red=$svc->classify(['observation_status'=>'finalized','final_label'=>'exception','assurance_at_reconciliation'=>['status'=>'RED'],'regression_ref'=>'R1']);
if(($red['status']??null)!=='assurance_red'||($red['priority']??0)<90||!in_array('regression',$red['flags']??[],true))throw new RuntimeException('Assurance RED with regression must be high-priority operational attention.');

$correct=$svc->classify(['observation_status'=>'finalized','final_label'=>'correct','assurance_at_reconciliation'=>['status'=>'GREEN']]);
if(($correct['status']??null)!=='verified_correct'||($correct['attention']??true)!==false)throw new RuntimeException('Verified correct receipt must not remain in exception attention queue.');

echo "OK: OperationsStatusClassifierSmokeTest\n";
