<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Domains\BusinessConfiguration;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

/** Conversational onboarding writes drafts here; only approved drafts materialise through governed CRM business actions. */
final class ConfigurationDraftService
{
    public function __construct(private readonly ConnectionInterface $db,private readonly BusinessConfigurationService $business) {}

    public function create(int $actor,array $answers,array $proposed,string $source='onboarding',?string $correlationId=null):array
    {
        $errors=$this->validate($proposed);$id=(string)Str::ulid();$preview=$this->previewData($proposed,$errors);
        $this->db->table('crm_business_configuration_drafts')->insert(['public_id'=>$id,'company_id'=>CrmCompanyScope::companyId($actor),'created_by_user_id'=>CrmCompanyScope::actorUserId($actor),'source_surface'=>$source,'status'=>$errors===[]?'validated':'draft','answers'=>json_encode($answers),'proposed_configuration'=>json_encode($proposed),'validation_errors'=>$errors===[]?null:json_encode($errors),'preview'=>json_encode($preview),'correlation_id'=>$correlationId,'created_at'=>now(),'updated_at'=>now()]);
        return $this->read($actor,$id);
    }
    public function read(int $actor,string $id):array{$row=$this->query($actor,$id)->first();if(!$row)throw new InvalidArgumentException('Configuration draft not found.');return $this->decode((array)$row);}
    public function preview(int $actor,string $id):array{$d=$this->read($actor,$id);return ['draft'=>$id,'status'=>$d['status'],'validation_errors'=>$d['validation_errors']??[],'preview'=>$d['preview']??[]];}
    public function approve(int $actor,string $id):array
    {
        $draft=$this->read($actor,$id);if(($draft['validation_errors']??[])!==[])throw new InvalidArgumentException('Configuration draft has validation errors.');if(!in_array($draft['status'],['validated','approved'],true))throw new InvalidArgumentException('Configuration draft is not ready for approval.');
        $this->query($actor,$id)->update(['status'=>'approved','approved_by_user_id'=>CrmCompanyScope::actorUserId($actor),'approved_at'=>now(),'updated_at'=>now()]);return $this->read($actor,$id);
    }
    public function materialise(int $actor,string $id):array
    {
        $draft=$this->read($actor,$id);if($draft['status']!=='approved')throw new InvalidArgumentException('Configuration must be approved before materialisation.');
        $result=$this->db->transaction(function()use($actor,$draft):array{$cfg=(array)$draft['proposed_configuration'];$out=[];
            if(isset($cfg['profile']))$out['profile']=$this->business->updateProfile($actor,(array)$cfg['profile']);
            if(isset($cfg['hours']))$out['hours']=$this->business->updateHours($actor,(array)$cfg['hours']);
            foreach((array)($cfg['services']??[]) as $service)$out['services'][]=empty($service['public_id'])?$this->business->createService($actor,(array)$service):$this->business->updateService($actor,(string)$service['public_id'],(array)$service);
            foreach((array)($cfg['locations']??[]) as $location)$out['locations'][]=empty($location['public_id'])?$this->business->createLocation($actor,(array)$location):$this->business->updateLocation($actor,(string)$location['public_id'],(array)$location);
            foreach(['booking_rules','pricing','field_rules','notification_defaults','invoice_settings'] as $k)if(isset($cfg[$k]))$out[$k]=$this->business->updateSetting($actor,'business.'.$k,(array)$cfg[$k]);
            return $out;});
        $this->query($actor,$id)->update(['status'=>'materialised','materialised_at'=>now(),'updated_at'=>now()]);return ['draft'=>$this->read($actor,$id),'result'=>$result];
    }
    private function validate(array $cfg):array{$errors=[];$tz=$cfg['profile']['timezone']??$cfg['hours']['timezone']??null;if($tz!==null&&!in_array((string)$tz,\DateTimeZone::listIdentifiers(),true))$errors['timezone']='Invalid IANA timezone.';foreach((array)($cfg['services']??[]) as $i=>$s)if(trim((string)($s['name']??''))==='')$errors["services.{$i}.name"]='Service name is required.';return $errors;}
    private function previewData(array $cfg,array $errors):array{return ['valid'=>$errors===[],'sections'=>array_keys($cfg),'service_count'=>count((array)($cfg['services']??[])),'location_count'=>count((array)($cfg['locations']??[]))];}
    private function query(int $actor,string $id){return $this->db->table('crm_business_configuration_drafts')->where('company_id',CrmCompanyScope::companyId($actor))->where('public_id',$id);}
    private function decode(array $row):array{foreach(['answers','proposed_configuration','validation_errors','preview'] as $k)if(isset($row[$k])&&is_string($row[$k]))$row[$k]=json_decode($row[$k],true)??[];return $row;}
}
