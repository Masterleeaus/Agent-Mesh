<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Contracts;

use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;

interface CommandLifecycleStoreContract
{
    public function available(): bool;

    public function begin(CommandContext $context, CommandRequest $request, string $operationId, string $requestHash): void;

    public function transition(
        CommandContext $context,
        CommandRequest $request,
        string $operationId,
        string $state,
        ?string $reasonCode = null,
        array $evidence = [],
    ): void;

    public function observe(
        CommandContext $context,
        CommandRequest $request,
        string $operationId,
        string $state,
        ?string $reasonCode = null,
        array $evidence = [],
    ): void;

    public function health(): array;
}
