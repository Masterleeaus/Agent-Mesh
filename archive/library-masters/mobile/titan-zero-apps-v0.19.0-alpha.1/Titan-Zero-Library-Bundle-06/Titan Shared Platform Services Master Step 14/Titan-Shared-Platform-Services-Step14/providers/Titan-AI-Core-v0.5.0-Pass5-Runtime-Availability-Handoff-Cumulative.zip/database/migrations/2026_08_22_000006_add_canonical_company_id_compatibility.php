<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        foreach (['titan_ai_core_plans', 'titan_ai_core_model_profiles'] as $tableName) {
            if (! Schema::hasTable($tableName) || Schema::hasColumn($tableName, 'company_id')) {
                continue;
            }
            Schema::table($tableName, function (Blueprint $table): void {
                $table->string('company_id', 191)->nullable()->index();
            });
            DB::table($tableName)->whereNull('company_id')->whereNotNull('tenant_company_id')
                ->update(['company_id' => DB::raw('tenant_company_id')]);
        }
    }

    public function down(): void
    {
        foreach (['titan_ai_core_plans', 'titan_ai_core_model_profiles'] as $tableName) {
            if (Schema::hasTable($tableName) && Schema::hasColumn($tableName, 'company_id')) {
                Schema::table($tableName, function (Blueprint $table): void { $table->dropColumn('company_id'); });
            }
        }
    }
};
