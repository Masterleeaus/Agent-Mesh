# Titan Forge Data Ownership

## Source of truth

Forge is authoritative only for the `build-generation` domain and its own build evidence.

Owned durable records include Forge builds, specs, plans, artifacts, validation runs/findings, release candidates, approvals, releases and receipts. The canonical tenant key is `tenant_company_id`.

Forge does not become the source of truth for Workforce definitions or any generated business-domain data. Generated artifacts are candidates until installed by the proper platform authority.

## Retention

Build/validation/release evidence is retained according to tenant policy. Workspace artifacts may be purged after durable hashes/provenance/receipts are preserved. Release evidence is audit-class and is not destructively pruned by normal workspace cleanup.
