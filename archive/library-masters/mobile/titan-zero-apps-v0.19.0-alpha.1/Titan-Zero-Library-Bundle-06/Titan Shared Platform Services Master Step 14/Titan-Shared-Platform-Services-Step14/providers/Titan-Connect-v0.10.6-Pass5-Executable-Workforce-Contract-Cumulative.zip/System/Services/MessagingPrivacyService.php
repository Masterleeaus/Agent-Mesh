<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Contracts\MessagingPrivacyHook;
use App\Extensions\TitanConnect\System\Contracts\RetentionPolicy;
use App\Extensions\TitanConnect\System\Models\ChannelConnectionMember;
use App\Extensions\TitanConnect\System\Models\ExternalMessage;
use App\Extensions\TitanConnect\System\Models\ExternalThreadRead;
use App\Extensions\TitanConnect\System\Models\MessagingAudit;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversationParticipant;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamMessage;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamMessageRead;

final class MessagingPrivacyService
{
    public function __construct(
        private readonly MessagingPrivacyHook $hook,
        private readonly RetentionPolicy $retention,
        private readonly MessagingAuditService $audit,
    ) {
    }

    /** @return array<string, mixed> */
    public function exportActor(int $companyId, int $actorId): array
    {
        $this->hook->beforeExport($companyId, $actorId);
        $payload = [
            'company_id' => $companyId,
            'actor_id' => $actorId,
            'retention_days' => $this->retention->daysForCompany($companyId),
            'internal_participation' => TeamConversationParticipant::query()->where('company_id', $companyId)->where('user_id', $actorId)->limit(5000)->get()->toArray(),
            'internal_messages_authored' => TeamMessage::query()->where('company_id', $companyId)->where('user_id', $actorId)->limit(5000)->get()->toArray(),
            'internal_read_receipts' => TeamMessageRead::query()->where('company_id', $companyId)->where('user_id', $actorId)->limit(5000)->get()->toArray(),
            'channel_memberships' => ChannelConnectionMember::query()->where('company_id', $companyId)->where('user_id', $actorId)->limit(5000)->get()->toArray(),
            'external_messages_attributed' => ExternalMessage::query()->where('company_id', $companyId)->where('metadata->actor_id', $actorId)->limit(5000)->get()->toArray(),
            'external_read_state' => ExternalThreadRead::query()->where('company_id', $companyId)->where('user_id', $actorId)->limit(5000)->get()->toArray(),
            'audit_entries' => MessagingAudit::query()->where('company_id', $companyId)->where('actor_id', $actorId)->limit(5000)->get()->toArray(),
        ];

        $this->audit->record($companyId, $actorId, 'privacy.export', 'actor', $actorId, null, ['record_groups' => array_keys($payload)]);
        return $payload;
    }

    /** @return array<string, mixed> */
    public function requestActorDeletion(int $companyId, int $actorId, array $context = []): array
    {
        $result = $this->hook->requestDeletion($companyId, $actorId, $context);
        $this->audit->record($companyId, $actorId, 'privacy.deletion-requested', 'actor', $actorId, null, ['result' => $result]);
        return $result;
    }
}
