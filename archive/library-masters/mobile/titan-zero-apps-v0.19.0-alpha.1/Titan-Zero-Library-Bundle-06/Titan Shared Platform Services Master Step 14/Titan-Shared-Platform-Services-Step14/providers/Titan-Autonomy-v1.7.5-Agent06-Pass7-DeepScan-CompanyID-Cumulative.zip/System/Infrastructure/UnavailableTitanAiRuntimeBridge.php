<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\TitanAiRuntimeBridgeContract;

final class UnavailableTitanAiRuntimeBridge implements TitanAiRuntimeBridgeContract
{
    public function status(): array
    {
        return ['available' => false, 'reason_codes' => ['TITAN_AI_RUNTIME_UNAVAILABLE'], 'class' => null];
    }
}
