# Installation Guide — v2 Pass 3 Security Baseline

## Requirements

- PHP 8.2 or 8.3
- Laravel 10.x MagicAI/Titan host
- MagicAI extension lifecycle interfaces used by Blueprint v3.1
- configured queue backend and worker
- authenticated `company_id` context and permissions
- authenticated company context (Maps supplies `titan.maps.company`; no host-global `titan.company` alias is required)
- Sanctum for API authentication
- host `admin` middleware and a Gate ability named `titan-maps-intelligence.admin.access`
- Titan Vault-compatible secret resolver
- audit and capability registries
- private export storage
- WorkCore lookup/promotion adapters for governed promotion workflows

## Package placement

Install the extension at:

```text
app/Extensions/TitanMapsIntelligence/
```

Canonical provider:

```text
App\Extensions\TitanMapsIntelligence\System\TitanMapsIntelligenceServiceProvider
```

A root provider compatibility alias remains for older pre-v2 host mappings.

## Host integration contracts

The extension defines the following integration contracts:

```text
AuthorisedCompanyContext
PermissionAuthorizer
SecretResolver
AuditRecorder
CapabilityRegistrar
WorkCoreCandidateGateway
WorkCoreCandidateLookup
PrivateExportStore
```

As of alpha.6.2, these contracts do not have to be supplied by `App\Titan\Maps\*` classes for installation to succeed. Compatible host adapters are preferred automatically; extension-local fallbacks are bound otherwise. WorkCore operations remain fail-closed until a compatible WorkCore adapter exists. `SecretResolver` fallback accepts only `env://VARIABLE_NAME` references.

`AdminPermissionAuthorizer` is implemented by the extension through Laravel Gate. The host must define/allow the `titan-maps-intelligence.admin.access` Gate ability for authorised platform administrators.

`InternalRequestAuthorizer` is intentionally not default-bound. Internal routes therefore fail closed until the host provides authenticated service-identity verification.

## Route profiles

```text
/dashboard/user/titan-maps-intelligence
/dashboard/admin/titan-maps-intelligence
/api/titan/maps-intelligence
/internal/titan/maps-intelligence
```

The internal route file intentionally contains no endpoint in Pass 3.

Every current API action has explicit Maps permission middleware in addition to Sanctum and company context.

## Database state

Pass 2/3 ship 13 forward-only migrations for the 13 persistent Maps tables. Every owned table has a `company_id` tenant key. Pass 3 makes that key immutable after record creation.

For a clean install:

```bash
php artisan migrate --force
```

## Queue

Discovery queue jobs carry `companyId` and execute inside `QueueTenantContext`. The queue implementation does not derive tenant identity from request/session state. All database lookups remain explicitly company-scoped.

## Verification

```bash
php scripts/verify.php
php scripts/verify_migrations.php
php scripts/verify_security.php
```

Then run the Blueprint v3.1 manifest validator/package scanner and the host Laravel test suite.

## Existing/manual Maps tables

If a Maps table predates these package migrations, back up the database and compare it with `database/schema-contract.json`. Forward-safe migrations do not drop or recreate pre-existing tables. Reconcile missing columns/keys before child-table constraints are applied. Never rename or coerce `company_id` across tenants.
