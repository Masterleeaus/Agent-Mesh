<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyAuditSinkContract;
use App\Extensions\TitanAutonomy\System\Contracts\CapabilityStateStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\ControlPlaneAuditSinkContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\GateEvaluation;
use App\Extensions\TitanAutonomy\System\DTOs\LevelActivationResult;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\HandshakeDecision;

final class AutonomyGrantService
{
    public function __construct(
        private readonly CapabilityStateStoreContract $stateStore,
        private readonly AutonomyAuditSinkContract $auditSink,
        private readonly string $policyVersion,
        private readonly LevelActivationService $activation = new LevelActivationService(),
        private readonly ?ControlPlaneAuditSinkContract $controlAudit = null,
    ) {}

    public function grantNextLevel(
        CapabilityState $state,
        AutonomyLevel $requestedLevel,
        GateEvaluation $gate,
        int $actorUserId,
        bool $actorCanGrant,
        HandshakeDecision $userDecision,
        HandshakeDecision $aiAssuranceDecision,
        float $aiConfidence,
        array $platformReasonCodes,
        array $aiReasonCodes,
        ?string $assuranceEvaluationRef,
        array $scope,
        ?string $correlationId = null,
    ): LevelActivationResult {
        $result = $this->activation->activate(
            state: $state,
            requestedLevel: $requestedLevel,
            gate: $gate,
            actorCanGrant: $actorCanGrant,
            userDecision: $userDecision,
            aiAssuranceDecision: $aiAssuranceDecision,
            scope: $scope,
        );

        if ($requestedLevel === AutonomyLevel::TrustedAuto) {
            $this->auditSink->recordHandshake([
                'tenant_company_id' => $state->tenantCompanyId,
                'user_id' => $actorUserId,
                'capability' => $state->capability,
                'workflow_key' => $state->workflowKey,
                'requested_level' => $requestedLevel->key(),
                'requested_scope' => $scope,
                'platform_decision' => $gate->eligible ? 'approved' : 'denied',
                'platform_reason_codes' => array_values(array_unique(array_merge($platformReasonCodes, $gate->reasonCodes))),
                'user_decision' => $userDecision->value,
                'ai_decision' => $aiAssuranceDecision->value,
                'ai_confidence' => max(0.0, min(1.0, $aiConfidence)),
                'ai_reason_codes' => $aiReasonCodes,
                'final_decision' => $result->approved ? 'approved' : 'denied',
                'policy_version' => $this->policyVersion,
                'assurance_evaluation_ref' => $assuranceEvaluationRef,
                'correlation_id' => $correlationId,
            ]);
        }

        if ($result->approved) {
            $this->stateStore->save($result->state);
            $this->controlAudit?->record([
                'tenant_company_id' => $state->tenantCompanyId,
                'user_id' => $actorUserId,
                'event_type' => 'autonomy.level_activated',
                'capability' => $state->capability,
                'workflow_key' => $state->workflowKey,
                'payload' => [
                    'prior_level' => $state->currentLevel->key(),
                    'new_level' => $requestedLevel->key(),
                    'scope' => $scope,
                    'trusted_auto_handshake_required' => $requestedLevel === AutonomyLevel::TrustedAuto,
                ],
                'policy_version' => $this->policyVersion,
                'correlation_id' => $correlationId,
            ]);
        }

        return $result;
    }
}
