# Pass 6 donor extraction provenance

Titan Field remains the sole authoritative recurrence and scheduling writer.

## Donor material reviewed
- `Titan Operations Team/FSMRecurring`: recurrence frequency/rule semantics and occurrence-preview concepts.
- `Titan Operations Team/FSMAvailability`: normalized recurring worker availability plus dated exceptions.
- `Titan Operations Team/FSMRouteAvailability`: blackout-day/group validation concepts.

## Extraction decision
No donor database tables, Eloquent models, controllers, providers, routes, or writers were copied into runtime. Pass 6 uses clean Titan-owned implementations behind existing Titan Field services. Historical `crm_*` operational tables and named routes remain unchanged.

## Adopted semantics
- interval daily/weekly/monthly/yearly recurrence
- weekday sets, day-of-month, nth/last weekday
- inclusion and exclusion dates
- normalized worker availability windows and dated exceptions
- generalized business/service/service-area/postcode/worker blackout windows

## Deliberately rejected
- parallel FSM order generation/writers
- donor route/controller/menu ownership
- donor-specific `fsm_*` tables
- route-only blackout ownership
