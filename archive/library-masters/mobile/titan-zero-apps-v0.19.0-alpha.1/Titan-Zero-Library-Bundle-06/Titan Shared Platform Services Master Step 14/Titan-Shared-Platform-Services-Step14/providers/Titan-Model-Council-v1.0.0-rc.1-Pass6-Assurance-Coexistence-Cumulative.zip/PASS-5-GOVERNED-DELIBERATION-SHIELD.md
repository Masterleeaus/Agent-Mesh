# Titan Model Council v0.6.0 — Pass 5

## Governed deliberation

Adds the executable role sequence:

`Proposer → Critic → Verifier → pre-arbiter validation → Arbiter → final validation`

The roles are deliberately asymmetric. The Critic must challenge the proposal. The Verifier may only verify against evidence/context actually supplied and must not claim external fact-checking it did not perform. The Arbiter must preserve material uncertainty and may recommend escalation rather than force false consensus.

## Risk authority

When governed deliberation is enabled, high/extreme risk and Risk decisions such as `REQUIRE_APPROVAL`, `REDUCE_AUTHORITY`, and `BLOCK` increase Council depth to governed mode. Council deliberation never converts `BLOCK` into permission to execute; the activation metadata preserves blocked/reduced execution authority.

## Validation / Titan Shield boundary

The latest Titan Shield v0.2.0 publishes an `InspectionEngineContract` and inspection state machine, but it does not itself generate a Council factual/semantic verdict. Model Council therefore uses its conservative structural observation as the verdict input, then records that observation through Shield's real inspection lifecycle when the peer is available. Pass 5 adds:

- an explicit Shield runtime probe;
- a Council Shield gate contract;
- conservative local structural validation before and after arbitration;
- a real `InspectionEngineContract` bridge for Shield inspection lifecycle/trace evidence;
- metadata recording that semantic/factual validation remains unavailable until Shield publishes that capability.

Pre-arbiter validation blocks arbitration if Proposer, Critic, or Verifier output is missing/failed. Final validation blocks release of an empty/failed Arbiter output.

## Provider execution

AI Core still does not publish a provider execution contract in the available v0.2.0 package. Governed participants therefore execute through the preserved legacy provider compatibility runtime, behind `GovernedProviderRuntimeContract`. Every model is entitlement/credit preflighted before reservation and rechecked before execution.

## Billing

Governed reservations are role-aware, preventing under-reservation when a model is assigned to more than one role. Actual successful participant usage is charged and settled before later postflight risk/audit persistence.

## Audit

Adds `titan_model_council_participants` with tenant, decision, trace, role, model, status, confidence, latency, credits, failure reason, response, output hash, and metadata. Decision records gain pre-arbiter/final validation statuses and validation source.

No unrestricted hidden chain-of-thought is requested or stored. Stored participant text is the explicit role output used to construct the governed decision.
