<?php
$root = dirname(__DIR__, 2);
$errors = [];
$manifest = json_decode((string) file_get_contents($root . '/workforce-integration.json'), true);
$states = $manifest['runtime_contract']['availability_states'] ?? [];
$expected = ['available','degraded','unavailable','missing_provider','blocked','policy_disabled'];
if ($states !== $expected) { $errors[] = 'availability states mismatch'; }
if (($manifest['runtime_contract']['ambiguous_unpinned_execution_allowed'] ?? true) !== false) { $errors[] = 'unpinned execution not fail-closed'; }
$src8 = (string) file_get_contents($root . '/config/titan-prime.php');
if (! str_contains($src8, '\'tenant_key\' => \'company_id\'')) { $errors[] = 'config/titan-prime.php: missing contract marker'; }
if (! str_contains($src8, '\'legacy_tenant_key\' => \'tenant_company_id\'')) { $errors[] = 'config/titan-prime.php: missing contract marker'; }
$src11 = (string) file_get_contents($root . '/System/Gateways/Data/EngineAvailability.php');
if (! str_contains($src11, 'public function workforceState(): string')) { $errors[] = 'System/Gateways/Data/EngineAvailability.php: missing contract marker'; }
if (! str_contains($src11, '\'missing_provider\'')) { $errors[] = 'System/Gateways/Data/EngineAvailability.php: missing contract marker'; }
if (! str_contains($src11, '\'workforce_state\' => $this->workforceState()')) { $errors[] = 'System/Gateways/Data/EngineAvailability.php: missing contract marker'; }
if ($errors !== []) { fwrite(STDERR, implode("\n", $errors) . "\n"); exit(1); }
echo "RUNTIME_AVAILABILITY_COMPATIBILITY: PASS\n";
