<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindSourceWatermark extends Model
{
    protected $table = 'titan_rewind_source_watermarks';
    protected $fillable = ['tenant_company_id','trace_id','source_key','state','observed_through','source_lag_seconds','metadata','checked_at'];
    protected $casts = ['tenant_company_id'=>'integer','source_lag_seconds'=>'integer','metadata'=>'array','observed_through'=>'datetime','checked_at'=>'datetime'];
}
