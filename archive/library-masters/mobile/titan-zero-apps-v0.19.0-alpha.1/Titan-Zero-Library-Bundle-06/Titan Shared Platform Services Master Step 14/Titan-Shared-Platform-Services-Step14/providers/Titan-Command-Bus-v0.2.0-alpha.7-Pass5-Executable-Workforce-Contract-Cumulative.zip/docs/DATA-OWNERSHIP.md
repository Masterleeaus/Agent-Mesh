# Data Ownership

Owns titan_command_receipts, titan_command_idempotency, titan_commands, and titan_command_attempts only. Does not own CRM, finance, workforce, communications, payments, maps, or other domain records. Audit receipts are retained by default.
