# Titan Installer Package Contract

This package is built for the Titan custom-extension installer contract `titan-extension-v1`.

Install target:

`app/Extensions/InteractionEngine/`

The ZIP itself is flat at archive root. It contains `extension.json`, `System/`, `routes/`, `resources/`, `database/`, and the remaining extension-owned files directly; it does not contain an outer `InteractionEngine/` directory.

Provider identity:

`App\\Extensions\\InteractionEngine\\System\\InteractionEngineServiceProvider`

Provider file:

`System/InteractionEngineServiceProvider.php`

Tenant boundary remains `company_id`.

The package uses an extension-specific publish tag, `interaction-engine-config`, rather than the generic MagicAI `extension` tag.

`extension.json` is the installer-facing manifest. `extension.manifest.json` remains the richer Titan/MagicAI lifecycle sidecar.

Production integrity hashes are embedded in `extension.json`. The manifest does not hash itself or `files.sha256.json` in order to avoid circular integrity dependencies. `files.sha256.json` separately hashes the finalized package contents except itself.
