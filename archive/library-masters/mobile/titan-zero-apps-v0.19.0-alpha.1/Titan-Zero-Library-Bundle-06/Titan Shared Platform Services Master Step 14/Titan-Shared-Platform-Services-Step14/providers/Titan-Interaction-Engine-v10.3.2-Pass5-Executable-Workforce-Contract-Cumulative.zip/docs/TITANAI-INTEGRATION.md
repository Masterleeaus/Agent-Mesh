# TitanAI Integration

TitanAI supplies natural-language understanding and AI orchestration. Interaction Engine remains authoritative for deterministic wizard state, validation, authority and capability execution.

Phase 6 declares governed AI authority/model-policy/business-preference/persona/readiness capabilities. No provider secrets are handled by Interaction Engine. The supplied TitanAI runtime does not provide a verified company-scoped configuration gateway for these operations, so live configuration remains unavailable until bound.
