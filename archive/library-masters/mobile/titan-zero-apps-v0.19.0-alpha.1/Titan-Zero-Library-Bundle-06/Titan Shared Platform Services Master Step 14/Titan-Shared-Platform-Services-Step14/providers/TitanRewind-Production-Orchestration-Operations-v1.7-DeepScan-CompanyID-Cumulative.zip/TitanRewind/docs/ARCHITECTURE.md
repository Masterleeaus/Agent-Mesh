# Titan Rewind Architecture

Titan Rewind reconstructs tenant-scoped decision history from read-only source adapters into normalized trace events, deterministic timelines, causation/dependency graphs, snapshots and forensic projections. It adds integrity/drift/root-cause analysis, historical and structural comparative replay, signed audit evidence, recovery proposals and external Titan Governance handoff.

Authoritative mutation is prohibited. Replay uses a rejecting command gateway. Recovery execution remains owned by Titan Command Bus/domain authorities.

Version 0.7 adds RBAC, source completeness/watermarks, RSA-signed evidence, custody and legal holds. See `BLUEPRINT-V4.1-ADOPTION.md` for the exact remaining production-profile gates.
