<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Models\MessagingAudit;

final class MessagingAuditService
{
    private const SENSITIVE = ['secret', 'token', 'password', 'authorization', 'credential', 'api_key', 'apikey'];

    public function record(int $companyId, ?int $actorId, string $action, ?string $subjectType = null, string|int|null $subjectId = null, ?string $correlationId = null, array $metadata = []): MessagingAudit
    {
        return MessagingAudit::query()->create([
            'company_id' => $companyId,
            'actor_id' => $actorId,
            'action' => $action,
            'subject_type' => $subjectType,
            'subject_id' => $subjectId === null ? null : (string) $subjectId,
            'correlation_id' => $correlationId,
            'metadata' => $this->redact($metadata),
            'created_at' => now(),
        ]);
    }

    private function redact(array $metadata): array
    {
        foreach ($metadata as $key => $value) {
            $normalized = strtolower((string) $key);
            if ($this->isSensitiveKey($normalized)) {
                $metadata[$key] = '[redacted]';
                continue;
            }
            if (is_array($value)) {
                $metadata[$key] = $this->redact($value);
            }
        }
        return $metadata;
    }

    private function isSensitiveKey(string $key): bool
    {
        foreach (self::SENSITIVE as $needle) {
            if (str_contains($key, $needle)) {
                return true;
            }
        }
        return false;
    }
}
