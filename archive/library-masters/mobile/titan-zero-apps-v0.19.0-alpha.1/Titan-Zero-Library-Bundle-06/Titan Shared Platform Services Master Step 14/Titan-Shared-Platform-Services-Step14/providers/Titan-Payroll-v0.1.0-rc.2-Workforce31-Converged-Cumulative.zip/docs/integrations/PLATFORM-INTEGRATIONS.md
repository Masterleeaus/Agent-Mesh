# Platform Integrations

- **Time Attendance:** typed approved-input consumer; no direct table queries; required hourly inputs fail closed when unavailable.
- **Command Bus:** authoritative path for AI/Workforce mutations and preferred path for governed writes. Local fallback is limited to explicitly configured human web/API sources.
- **Risk + Assurance:** both required for HIGH/CRITICAL financial commands.
- **Autonomy:** external decision/context dependency; never a substitute for authorization/governance.
- **Communications:** Payroll is a consumer. Payslip resend/delivery creates a provider request/receipt; Payroll does not directly send mail/notifications.
- **Rewind:** Payroll is a source contributor. It exposes privacy-minimized status/version/hash/governance facts and source-sequence watermarks only.
- **Signals:** idempotent privacy-minimized lifecycle outbox; retries are bounded and can enter `attention_required`.
- **Accounting/payment outputs:** ports distinguish prepared/exported/transmitted/paid. No `paid=true` or transmission success is asserted without provider confirmation.
- **Navigation:** host contribution registry first; `menus` self-heal fallback and MenuService regeneration second.
