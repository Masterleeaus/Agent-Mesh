<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key')) return;
        $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
        if (! isset($columns['id'])) return;

        DB::table('menus')->where('key', 'titan_signal_pulse')->delete();

        $root = [
            'key' => 'titan_signal_engine_admin', 'parent_id' => null,
            'route' => 'dashboard.admin.titan.signal.engine.index', 'route_slug' => null,
            'label' => 'Signal Engine', 'icon' => 'tabler-heart-rate-monitor', 'svg' => null,
            'order' => 995, 'is_active' => 1, 'is_admin' => 1, 'params' => '[]',
            'type' => 'item', 'badge' => null, 'extension' => '1',
            'custom_menu' => 0, 'bolt_menu' => 0, 'bolt_background' => null,
            'bolt_foreground' => null, 'letter_icon' => 0, 'letter_icon_bg' => null,
        ];
        $rootId = $this->upsert($root, $columns, null);
        if ($rootId === null) return;

        $children = [
            ['titan_signal_engine_overview', 'Overview', 'dashboard.admin.titan.signal.engine.overview', 'tabler-layout-dashboard'],
            ['titan_signal_engine_pulse_health', 'Pulse and Health', 'dashboard.admin.titan.signal.engine.pulse-health', 'tabler-activity-heartbeat'],
            ['titan_signal_engine_events_traces', 'Events and Traces', 'dashboard.admin.titan.signal.engine.events-traces', 'tabler-route'],
            ['titan_signal_engine_anomalies', 'Anomalies', 'dashboard.admin.titan.signal.engine.anomalies', 'tabler-alert-triangle'],
            ['titan_signal_engine_deliveries_dlq', 'Deliveries and DLQ', 'dashboard.admin.titan.signal.engine.deliveries-dlq', 'tabler-package-export'],
            ['titan_signal_engine_lifecycle_archives', 'Lifecycle and Archives', 'dashboard.admin.titan.signal.engine.lifecycle-archives', 'tabler-archive'],
            ['titan_signal_engine_registries', 'Registries', 'dashboard.admin.titan.signal.engine.registries', 'tabler-list-details'],
            ['titan_signal_engine_diagnostics', 'Diagnostics', 'dashboard.admin.titan.signal.engine.diagnostics', 'tabler-stethoscope'],
        ];

        foreach ($children as $index => [$key, $label, $route, $icon]) {
            $this->upsert([
                'key' => $key, 'parent_id' => $rootId, 'route' => $route, 'route_slug' => null,
                'label' => $label, 'icon' => $icon, 'svg' => null, 'order' => 996 + $index,
                'is_active' => 1, 'is_admin' => 1, 'params' => '[]', 'type' => 'item',
                'badge' => null, 'extension' => '1', 'custom_menu' => 0, 'bolt_menu' => 0,
                'bolt_background' => null, 'bolt_foreground' => null, 'letter_icon' => 0,
                'letter_icon_bg' => null,
            ], $columns, $rootId);
        }

        if (class_exists(\App\Services\Common\MenuService::class)) {
            try {
                $service = app(\App\Services\Common\MenuService::class);
                if (method_exists($service, 'regenerate')) $service->regenerate();
            } catch (\Throwable) {
                try { \App\Services\Common\MenuService::regenerate(); } catch (\Throwable) {}
            }
        }
    }

    /** @param array<string,mixed> $row @param array<string,bool> $columns */
    private function upsert(array $row, array $columns, ?int $parentId): ?int
    {
        $existing = DB::table('menus')->where('key', $row['key'])->orderBy('id')->first();
        $row['parent_id'] = $parentId;
        $payload = array_intersect_key($row, $columns);
        if ($existing !== null) {
            unset($payload['is_active']);
            if (isset($columns['updated_at'])) $payload['updated_at'] = now();
            DB::table('menus')->where('id', (int) $existing->id)->update($payload);
            return (int) $existing->id;
        }
        if (isset($columns['created_at'])) $payload['created_at'] = now();
        if (isset($columns['updated_at'])) $payload['updated_at'] = now();
        DB::table('menus')->insert($payload);
        $id = DB::table('menus')->where('key', $row['key'])->orderBy('id')->value('id');
        return $id === null ? null : (int) $id;
    }

    public function down(): void
    {
        if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key')) return;
        DB::table('menus')->whereIn('key', [
            'titan_signal_engine_overview', 'titan_signal_engine_pulse_health',
            'titan_signal_engine_events_traces', 'titan_signal_engine_anomalies',
            'titan_signal_engine_deliveries_dlq', 'titan_signal_engine_lifecycle_archives',
            'titan_signal_engine_registries', 'titan_signal_engine_diagnostics',
        ])->delete();
    }
};
