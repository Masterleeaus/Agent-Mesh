<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_signal_deliveries')) {
            Schema::table('titan_signal_deliveries', function (Blueprint $table): void {
                if (! Schema::hasColumn('titan_signal_deliveries', 'source')) {
                    $table->string('source', 191)->nullable()->after('schema_version');
                }
                if (! Schema::hasColumn('titan_signal_deliveries', 'source_component')) {
                    $table->string('source_component', 191)->nullable()->after('source');
                }
                if (! Schema::hasColumn('titan_signal_deliveries', 'dead_letter_resolved_at')) {
                    $table->timestamp('dead_letter_resolved_at')->nullable()->after('dead_lettered_at');
                }
                if (! Schema::hasColumn('titan_signal_deliveries', 'redrive_count')) {
                    $table->unsignedInteger('redrive_count')->default(0)->after('dead_letter_resolved_at');
                }
                if (! Schema::hasColumn('titan_signal_deliveries', 'last_redriven_at')) {
                    $table->timestamp('last_redriven_at')->nullable()->after('redrive_count');
                }
                if (! Schema::hasColumn('titan_signal_deliveries', 'last_redriven_by')) {
                    $table->string('last_redriven_by', 191)->nullable()->after('last_redriven_at');
                }
                if (! Schema::hasColumn('titan_signal_deliveries', 'last_redrive_reason_hash')) {
                    $table->char('last_redrive_reason_hash', 64)->nullable()->after('last_redriven_by');
                }
            });

            DB::table('titan_signal_deliveries')
                ->whereNull('source')
                ->orderBy('id')
                ->chunkById(250, function ($rows): void {
                    foreach ($rows as $row) {
                        $event = DB::table('titan_signal_events')
                            ->where('event_id', $row->event_id)
                            ->first(['source', 'source_component']);
                        if ($event === null) continue;
                        DB::table('titan_signal_deliveries')->where('id', $row->id)->update([
                            'source' => $event->source,
                            'source_component' => $event->source_component,
                        ]);
                    }
                });

            Schema::table('titan_signal_deliveries', function (Blueprint $table): void {
                $table->index(['status', 'dead_lettered_at'], 'tsd_status_dead_lettered_idx');
                $table->index(['scope', 'tenant_company_id', 'status'], 'tsd_scope_tenant_status_idx');
                $table->index(['source', 'source_component', 'status'], 'tsd_source_component_status_idx');
                $table->index(['dead_letter_resolved_at', 'dead_lettered_at'], 'tsd_dlq_resolution_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_subscription_registry_state')) {
            Schema::create('titan_signal_subscription_registry_state', function (Blueprint $table): void {
                $table->string('registry_key', 64)->primary();
                $table->unsignedBigInteger('revision')->default(1);
                $table->timestamps();
            });
            DB::table('titan_signal_subscription_registry_state')->insert([
                'registry_key' => 'subscriptions',
                'revision' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        if (! Schema::hasTable('titan_signal_delivery_redrives')) {
            Schema::create('titan_signal_delivery_redrives', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->uuid('redrive_id')->unique();
                $table->uuid('delivery_id')->index();
                $table->uuid('event_id')->index();
                $table->string('subscriber_key', 191)->index();
                $table->string('scope', 16)->index();
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
                $table->unsignedInteger('redrive_count');
                $table->unsignedInteger('failed_attempt_count')->default(0);
                $table->timestamp('dead_lettered_at')->nullable();
                $table->string('error_class', 255)->nullable();
                $table->string('error_reference', 2000)->nullable();
                $table->string('actor_id', 191);
                $table->string('actor_type', 32);
                $table->string('reason', 500);
                $table->char('reason_hash', 64);
                $table->dateTime('requested_at')->index();
                $table->timestamps();
                $table->unique(['delivery_id', 'redrive_count'], 'tsdr_delivery_count_unique');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_delivery_redrives');
        Schema::dropIfExists('titan_signal_subscription_registry_state');

        if (Schema::hasTable('titan_signal_deliveries')) {
            Schema::table('titan_signal_deliveries', function (Blueprint $table): void {
                $table->dropIndex('tsd_status_dead_lettered_idx');
                $table->dropIndex('tsd_scope_tenant_status_idx');
                $table->dropIndex('tsd_source_component_status_idx');
                $table->dropIndex('tsd_dlq_resolution_idx');
                $table->dropColumn([
                    'source', 'source_component', 'dead_letter_resolved_at', 'redrive_count',
                    'last_redriven_at', 'last_redriven_by', 'last_redrive_reason_hash',
                ]);
            });
        }
    }
};
