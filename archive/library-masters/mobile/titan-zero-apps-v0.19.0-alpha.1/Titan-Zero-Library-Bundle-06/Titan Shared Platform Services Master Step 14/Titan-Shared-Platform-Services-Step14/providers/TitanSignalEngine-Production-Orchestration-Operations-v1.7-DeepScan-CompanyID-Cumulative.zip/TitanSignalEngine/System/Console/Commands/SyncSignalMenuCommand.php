<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Console\Commands;

use App\Extensions\TitanSignalEngine\System\Navigation\HostNavigationRegistrar;
use Illuminate\Console\Command;

final class SyncSignalMenuCommand extends Command
{
    protected $signature = 'titan:signal:host-sync';
    protected $description = 'Synchronise Titan Signal Super Admin navigation with the Titan/MagicAI host and refresh menu caches.';

    public function handle(HostNavigationRegistrar $registrar): int
    {
        $registrar->registerContributions();
        $result = $registrar->syncHostMenus(true);

        if (! ($result['available'] ?? false)) {
            $this->warn('Titan/MagicAI menu hierarchy is unavailable; contribution-registry registration was still attempted.');
            if (($result['reason'] ?? null) !== null) {
                $this->line('Reason: ' . (string) $result['reason']);
            }
            return self::SUCCESS;
        }

        $this->info(($result['changed'] ?? false)
            ? 'Titan Signal Super Admin menu synchronised.'
            : 'Titan Signal Super Admin menu already current.');
        $this->line('Super Admin menu row ID: ' . (string) (($result['admin_id'] ?? null) ?: 'unresolved'));
        $this->line(($result['regenerated'] ?? false)
            ? 'MagicAI menu cache regenerated.'
            : 'MenuService regeneration was unavailable or unnecessary.');

        return self::SUCCESS;
    }
}
