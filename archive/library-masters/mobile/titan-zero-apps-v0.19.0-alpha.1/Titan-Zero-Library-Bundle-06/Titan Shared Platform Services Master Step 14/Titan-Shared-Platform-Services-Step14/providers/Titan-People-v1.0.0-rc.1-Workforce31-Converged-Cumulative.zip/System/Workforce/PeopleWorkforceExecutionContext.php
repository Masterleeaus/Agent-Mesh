<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Workforce;

use App\Extensions\TitanPeople\System\Context\PeopleExecutionContext;

final readonly class PeopleWorkforceExecutionContext
{
    public function __construct(private PeopleExecutionContext $context) {}
    public function companyId(): int { return $this->context->tenantCompanyId; }
    /** @deprecated Internal legacy-storage alias; Workforce boundary is company_id. */
    public function tenantCompanyId(): int { return $this->companyId(); }
    public function actorSubject(): string|int { return $this->context->actorSubject; }
    public function traceId(): string { return $this->context->traceId; }
    public function correlationId(): string { return $this->context->correlationId; }
}
