<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalEmitterIdentity
{
    /**
     * @param list<string> $permissions
     * @param list<string> $eventTypePatterns
     */
    public function __construct(
        public string $serviceId,
        public string $source,
        public ?string $sourceComponent,
        public array $permissions,
        public array $eventTypePatterns,
        public string $attestation,
    ) {
        if (trim($this->serviceId) === '' || trim($this->source) === '') {
            throw new InvalidArgumentException('Signal emitter identity requires service_id and source.');
        }
        if ($this->sourceComponent !== null && trim($this->sourceComponent) === '') {
            throw new InvalidArgumentException('Signal emitter source_component must be null or non-empty.');
        }
        if (! in_array('signal.emit', $this->permissions, true)) {
            throw new InvalidArgumentException('Signal emitter identity requires signal.emit permission.');
        }
        if ($this->eventTypePatterns === []) {
            throw new InvalidArgumentException('Signal emitter identity requires at least one allowed event type pattern.');
        }
        if ($this->attestation === '') {
            throw new InvalidArgumentException('Signal emitter identity requires host attestation.');
        }
        foreach ($this->eventTypePatterns as $pattern) {
            if (trim($pattern) === '' || ($pattern !== '*' && str_contains(substr($pattern, 0, -1), '*'))) {
                throw new InvalidArgumentException('Signal emitter event type patterns support exact values, prefix.* or *.');
            }
        }
    }

    public function hasPermission(string $permission): bool
    {
        return in_array($permission, $this->permissions, true);
    }

    public function allowsEventType(string $eventType): bool
    {
        foreach ($this->eventTypePatterns as $pattern) {
            if ($pattern === '*' || $pattern === $eventType) return true;
            if (str_ends_with($pattern, '.*') && str_starts_with($eventType, substr($pattern, 0, -1))) return true;
        }
        return false;
    }

    /** @return array<string,mixed> */
    public function attestationPayload(): array
    {
        return [
            'service_id' => $this->serviceId,
            'source' => $this->source,
            'source_component' => $this->sourceComponent,
            'permissions' => array_values($this->permissions),
            'event_type_patterns' => array_values($this->eventTypePatterns),
        ];
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [...$this->attestationPayload(), 'attestation' => $this->attestation];
    }
}
