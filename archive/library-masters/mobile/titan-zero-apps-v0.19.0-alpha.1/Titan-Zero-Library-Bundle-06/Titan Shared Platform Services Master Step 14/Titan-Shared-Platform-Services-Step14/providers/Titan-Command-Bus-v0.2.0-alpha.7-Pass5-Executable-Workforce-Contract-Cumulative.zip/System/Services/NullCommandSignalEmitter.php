<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Services;

use App\Extensions\TitanCommandBus\System\Contracts\CommandSignalEmitterContract;

final class NullCommandSignalEmitter implements CommandSignalEmitterContract
{
    public function available(): bool { return false; }
    public function emit(string $type, array $payload): void {}
}
