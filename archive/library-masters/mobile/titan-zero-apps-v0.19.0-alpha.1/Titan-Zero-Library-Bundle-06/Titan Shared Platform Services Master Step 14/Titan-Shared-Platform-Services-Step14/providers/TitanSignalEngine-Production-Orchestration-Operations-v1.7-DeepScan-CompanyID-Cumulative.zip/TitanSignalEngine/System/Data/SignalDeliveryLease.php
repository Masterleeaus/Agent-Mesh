<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use DateTimeImmutable;

final readonly class SignalDeliveryLease
{
    public function __construct(
        public string $deliveryId,
        public string $token,
        public string $workerId,
        public int $claimVersion,
        public DateTimeImmutable $claimedAt,
        public DateTimeImmutable $expiresAt,
    ) {
    }
}
