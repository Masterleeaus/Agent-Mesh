# Titan CRM Core — Chatbot & Mobile Integration Boundary

Titan CRM Core **v1.3.0-alpha.27** contributes customer, sales and commercial context to Titan surfaces without owning Field, Locker, Ledger or Pay runtime state.

## Authority and tenancy

- CRM Core owns customers, organisations, contacts, leads, deals, CRM coordination records, quotes, estimates, invoices and commercial/customer history.
- `company_id` is the canonical CRM tenant boundary.
- Browser/client `company_id` values never become tenant authority.
- Extracted domains are routed through their own extensions. CRM Core does not recreate their providers, tables or UI actions.

## Chatbot

CRM Chatbot tools expose only CRM-owned customer/sales/commercial capabilities. Field service requests, work orders, appointments, assets, support/reviews and other extracted-domain tools are not advertised by CRM Core.

Writes continue through the governed Command Bus boundary; the Chatbot never gets raw Eloquent/database access.

## Titan Hub

`CrmCustomerOperationsGateway` contributes CRM-owned information such as profile/customer context, quotes, invoices and commercial documents. Operational methods such as services, service requests, work orders, bookings, support and locations are delegated to the inner Titan Hub/Titan Field surface rather than queried from Field tables by CRM Core.

Private CRM reads require trusted tenant context plus the verified CRM customer/contact identity.

## Titan Command / owner surface

`CrmOwnerDashboardGateway` contributes CRM customer, lead/deal, quote and invoice decision data. It does not construct Dispatch, Workforce, recurring-work, Field service-request or review/recovery sections from Field tables.

`CrmOwnerActionGateway` exposes CRM-owned governed actions such as quote approval, invoice issue and customer updates. Field scheduling/assignment/service mutations are not registered as CRM owner actions.

## Titan Go

Titan Field owns Titan Go field/offline bootstrap, mutation reconciliation, sync tokens and mobile change feeds. CRM Core does not implement a Field offline source gateway and does not require a mobile sync secret.

A Field/job record may be supplied to CRM as cross-domain context for a commercial action such as preparing a quote or invoice. CRM does not mutate the Field record through that reference.

## TitanAI and Interaction Engine

`CrmTitanAIToolProvider` and CRM Interaction registries advertise Core-owned CRM capabilities only. Legacy external `crm.*` capability names may remain available through the centralized ownership-aware compatibility bridge, but active CRM UI/AI surfaces do not present them as CRM actions.

## Titan Connect

CRM owns the commercial intent and notification outbox record. Titan Connect owns provider execution and provider delivery truth. CRM command acceptance never implies successful customer delivery.
