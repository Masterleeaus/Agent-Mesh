<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyAuditSinkContract;
use App\Extensions\TitanAutonomy\System\Contracts\CapabilityStateStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\LearningSinkContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\EvidenceSnapshot;
use App\Extensions\TitanAutonomy\System\DTOs\OutcomeObservation;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\RiskClass;
use App\Extensions\TitanAutonomy\System\Enums\UserResponseClass;
use App\Extensions\TitanAutonomy\System\Services\AutonomyRuntimeService;
use App\Extensions\TitanAutonomy\System\Services\GateEvaluator;

function verify(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}

$store = new class implements CapabilityStateStoreContract {
    public array $saved = [];
    public function save(CapabilityState $state): void { $this->saved[$state->capability.'|'.$state->workflowKey] = $state; }
};
$learning = new class implements LearningSinkContract {
    public array $events = [];
    public function record(array $event): string { $this->events[] = $event; return 'learn-'.count($this->events); }
};
$audit = new class implements AutonomyAuditSinkContract {
    public array $gates = [];
    public array $regressions = [];
    public function recordGateDecision(array $event): string { $this->gates[] = $event; return 'gate-'.count($this->gates); }
    public function recordHandshake(array $event): string { return 'handshake-1'; }
    public function recordRegression(array $event): string { $this->regressions[] = $event; return 'reg-'.count($this->regressions); }
};

$runtime = new AutonomyRuntimeService(
    stateStore: $store,
    learningSink: $learning,
    auditSink: $audit,
    gateEvaluator: new GateEvaluator(
        ['low' => 1, 'medium' => 2, 'high' => 3, 'critical' => 3],
        ['low' => 'trusted_auto', 'medium' => 'trusted_auto', 'high' => 'auto', 'critical' => 'semi_auto'],
    ),
    policyVersion: '2026-08-10.v1',
);

$state = new CapabilityState(7, 'crm.invoice.issue', 'completed_job_invoice', RiskClass::Medium, AutonomyLevel::Assist, 2, 1, 4, 8);
$result = $runtime->recordOutcome(
    $state,
    new OutcomeObservation(UserResponseClass::ApprovedUnchanged),
    new EvidenceSnapshot(currentSuccessStreak: 1),
    userId: 42,
    context: ['vertical' => 'plumbing'],
    proposal: ['action' => 'send_invoice', 'invoice_total' => 485],
    finalAction: ['action' => 'send_invoice', 'invoice_total' => 485],
    outcome: ['status' => 'success'],
    confidence: 0.95,
);
verify($result->state->currentSuccessStreak === 2, 'runtime must persist updated streak');
verify($result->state->platformGateEligible, 'runtime must set platform eligibility after full gate evaluation');
verify($result->state->currentLevel === AutonomyLevel::Assist, 'runtime must not auto-promote eligible capability');
verify(count($learning->events) === 1, 'runtime must emit learning event');
verify(($learning->events[0]['learning_label'] ?? null) === 'correct', 'learning label must reflect qualifying outcome');
verify(count($audit->gates) === 1 && ($audit->gates[0]['eligible'] ?? false) === true, 'runtime must audit gate decision');

$trusted = new CapabilityState(7, 'crm.invoice.issue', 'completed_job_invoice', RiskClass::Medium, AutonomyLevel::TrustedAuto, 2, 5, 8, 20, scope: ['workflow' => 'completed_job_invoice']);
$reversed = $runtime->recordOutcome(
    $trusted,
    new OutcomeObservation(UserResponseClass::Reversed, executionSucceeded: true, reversed: true),
    new EvidenceSnapshot(currentSuccessStreak: 5),
    userId: 42,
    context: ['vertical' => 'plumbing'],
    proposal: ['action' => 'send_invoice'],
    finalAction: ['action' => 'send_invoice'],
    outcome: ['status' => 'reversed'],
    confidence: 0.7,
);
verify($reversed->state->currentLevel === AutonomyLevel::SemiAuto, 'reversal at Trusted Auto must trigger severe regression');
verify($reversed->state->currentSuccessStreak === 0, 'regression must reset current streak');
verify(count($audit->regressions) === 1, 'regression must be audited');

echo "OK: RuntimeOrchestratorSmokeTest\n";
