<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

final class ChannelConnection extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use HasUuids;
    use SoftDeletes;

    protected $table = 'ext_titan_connect_channel_connections';

    protected $fillable = [
        'uuid', 'company_id', 'provider', 'display_name', 'external_account_id',
        'credential_reference', 'status', 'settings', 'last_health_checked_at',
        'last_inbound_at', 'last_outbound_at',
    ];

    protected $hidden = ['credential_reference'];

    protected $casts = [
        'settings' => 'array',
        'last_health_checked_at' => 'datetime',
        'last_inbound_at' => 'datetime',
        'last_outbound_at' => 'datetime',
    ];

    public function uniqueIds(): array
    {
        return ['uuid'];
    }

    public function getRouteKeyName(): string
    {
        return 'uuid';
    }


    public function members(): HasMany
    {
        return $this->hasMany(ChannelConnectionMember::class, 'channel_connection_id');
    }

    public function memberFor(int $userId): ?ChannelConnectionMember
    {
        return $this->members()->where('company_id', $this->company_id)->where('user_id', $userId)->whereNull('left_at')->first();
    }

    public function threads(): HasMany
    {
        return $this->hasMany(ExternalThread::class, 'channel_connection_id');
    }
}
