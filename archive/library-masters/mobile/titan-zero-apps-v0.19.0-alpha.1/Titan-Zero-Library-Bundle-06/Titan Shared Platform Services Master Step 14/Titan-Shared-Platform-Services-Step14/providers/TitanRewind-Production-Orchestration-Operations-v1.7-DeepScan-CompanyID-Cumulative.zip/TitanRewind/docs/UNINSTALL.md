# Uninstall

Current default policy is **retain**. The extension uninstall hook removes the published Rewind configuration file and does not delete Rewind forensic/evidence tables or source-engine data.

Because v0.7 introduces legal holds, any future selectable purge-on-uninstall workflow must be resumable, tenant-scoped and guarded by `RewindLegalHoldGuard`. Queue draining/cancellation and purge receipts are later production-hardening requirements, not current uninstall behavior.
