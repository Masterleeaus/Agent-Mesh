<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Entities;

use App\Extensions\TitanPrime\System\Domain\Enums\PrimeCheckpointStatus;
use InvalidArgumentException;

final readonly class PrimeCheckpoint
{
    /** @param list<string> $evidenceReferences */
    public function __construct(
        public string $checkpointId,
        public string $missionId,
        public string $name,
        public PrimeCheckpointStatus $status = PrimeCheckpointStatus::Pending,
        public array $evidenceReferences = [],
    ) {
        if (trim($checkpointId) === '' || trim($missionId) === '' || trim($name) === '') {
            throw new InvalidArgumentException('Checkpoint id, mission id and name are required.');
        }
    }
}
