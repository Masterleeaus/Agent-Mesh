<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contributions;

final class AutonomyAdminNavigationContribution
{
    public function __invoke(): array { return $this->items(); }

    public function items(): array
    {
        return [[
            'key' => 'titan-autonomy-admin',
            'label' => 'Titan Autonomy',
            'route' => 'titan-autonomy.admin',
            'permission' => 'titan.autonomy.policy.view',
            'icon' => 'tabler-folders',
            'priority' => 85,
        ]];
    }
}
