<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Security;

use App\Extensions\TitanAICore\System\DTO\RuntimeContext;
use App\Extensions\TitanAICore\System\Exceptions\SecurityContextException;

final class TenantRuntimeGuard
{
    public function assertTenant(string $resourceTenantCompanyId, RuntimeContext $runtimeContext): void
    {
        if ($resourceTenantCompanyId !== '' && hash_equals($runtimeContext->tenantCompanyId, $resourceTenantCompanyId)) {
            return;
        }

        throw new SecurityContextException(
            'CROSS_TENANT_ACCESS_DENIED',
            'The requested resource is outside the authenticated tenant boundary.'
        );
    }
}
