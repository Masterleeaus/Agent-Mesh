# Titan Rewind Legal Hold

Legal holds target `trace`, `case`, `evidence-package`, or `tenant-investigation` scopes. Application requires a real tenant-scoped object, authority and reason. Optional review/expiry dates are supported; expiry must be future-dated and cannot precede review.

Retention checks cascade across linked scopes. A case hold protects its primary and explicitly linked traces. An evidence-package hold protects the corresponding trace; trace/case holds protect evidence linked to the trace. Tenant-investigation holds dominate all child scopes.

Release requires an explicit reason and records release actor/time. Evidence-package hold application/release is recorded in the evidence custody journal.
