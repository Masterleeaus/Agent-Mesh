<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;
use InvalidArgumentException;
use JsonException;

final readonly class SignalEnvelope
{
    public const SCOPE_TENANT = 'tenant';
    public const SCOPE_SYSTEM = 'system';
    public const ENVELOPE_VERSION = '1.0';
    public const CHECKSUM_ALGORITHM = 'sha256';

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $metadata
     */
    private function __construct(
        public string $eventId,
        public string $eventType,
        public DateTimeImmutable $occurredAt,
        public DateTimeImmutable $recordedAt,
        public string $envelopeVersion,
        public string $scope,
        public ?int $tenantCompanyId,
        public ?SignalActor $actor,
        public ?string $actorType,
        public ?string $actorId,
        public ?string $actorIdentityProvider,
        public ?string $actorSessionId,
        public string $traceId,
        public string $correlationId,
        public ?string $causationId,
        public string $rootCausationId,
        public string $source,
        public ?string $sourceComponent,
        public ?string $emitterId,
        public int $schemaVersion,
        public array $payload,
        public array $metadata,
        public string $severity,
        public ?string $category,
        public ?string $idempotencyKey,
        public ?string $verticalKey,
        public string $checksumAlgorithm,
        public string $checksum,
    ) {
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        return self::build($data, false);
    }

    /** @param array<string, mixed> $data */
    public static function fromPersistenceArray(array $data): self
    {
        return self::build([
            ...$data,
            'event_type' => $data['event_type'] ?? $data['type'] ?? null,
            'source' => $data['source'] ?? 'legacy:titan-signal-engine',
            'scope' => $data['scope'] ?? (($data['tenant_company_id'] ?? null) === null ? self::SCOPE_SYSTEM : self::SCOPE_TENANT),
        ], true);
    }

    /**
     * Create a causally-linked child signal while preserving protected execution context.
     * Only explicitly whitelisted descriptive/context fields can be overridden.
     *
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $overrides
     */
    public function child(string $eventType, string $source, array $payload = [], array $overrides = []): self
    {
        $allowedOverrides = [
            'occurred_at',
            'actor', 'actor_type', 'actor_id', 'actor_identity_provider', 'actor_session_id',
            'source_component', 'schema_version', 'metadata', 'severity', 'category',
            'idempotency_key', 'vertical_key',
        ];
        foreach (array_keys($overrides) as $key) {
            if (! in_array($key, $allowedOverrides, true)) {
                throw new InvalidArgumentException("{$key} cannot be overridden on a child signal.");
            }
        }

        return self::fromArray(array_replace([
            'event_type' => $eventType,
            'envelope_version' => $this->envelopeVersion,
            'scope' => $this->scope,
            'tenant_company_id' => $this->tenantCompanyId,
            'actor' => $this->actor?->toArray(),
            'actor_type' => $this->actorType,
            'actor_id' => $this->actorId,
            'actor_identity_provider' => $this->actorIdentityProvider,
            'actor_session_id' => $this->actorSessionId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->eventId,
            'root_causation_id' => $this->rootCausationId,
            'source' => $source,
            'schema_version' => $this->schemaVersion,
            'payload' => $payload,
            'metadata' => $this->metadata,
            'severity' => 'info',
            'category' => $this->category,
            'vertical_key' => $this->verticalKey,
            'checksum_alg' => $this->checksumAlgorithm,
        ], $overrides));
    }

    public function verifyChecksum(): bool
    {
        if ($this->checksumAlgorithm !== self::CHECKSUM_ALGORITHM) {
            return false;
        }

        return hash_equals($this->checksum, self::checksum($this->canonicalChecksumData(), $this->checksumAlgorithm));
    }

    public function idempotencyFingerprint(): string
    {
        return self::checksum([
            'event_type' => $this->eventType,
            'scope' => $this->scope,
            'tenant_company_id' => $this->tenantCompanyId,
            'source' => $this->source,
            'emitter_id' => $this->emitterId,
            'schema_version' => $this->schemaVersion,
            'payload' => $this->payload,
            'vertical_key' => $this->verticalKey,
        ], self::CHECKSUM_ALGORITHM);
    }

    /** @return array<string, mixed> */
    public function toPersistenceArray(): array
    {
        return [
            'event_id' => $this->eventId,
            'event_type' => $this->eventType,
            'type' => $this->eventType,
            'status' => 'recorded',
            'occurred_at' => $this->occurredAt,
            'recorded_at' => $this->recordedAt,
            'envelope_version' => $this->envelopeVersion,
            'scope' => $this->scope,
            'tenant_company_id' => $this->tenantCompanyId,
            'actor_type' => $this->actorType,
            'actor_id' => $this->actorId,
            'actor_identity_provider' => $this->actorIdentityProvider,
            'actor_session_id' => $this->actorSessionId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
            'source' => $this->source,
            'source_component' => $this->sourceComponent,
            'emitter_id' => $this->emitterId,
            'schema_version' => $this->schemaVersion,
            'payload' => $this->payload,
            'metadata' => $this->metadata,
            'severity' => $this->severity,
            'category' => $this->category,
            'idempotency_key' => $this->idempotencyKey,
            'vertical_key' => $this->verticalKey,
            'checksum_alg' => $this->checksumAlgorithm,
            'checksum' => $this->checksum,
        ];
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        $data = $this->toPersistenceArray();
        unset($data['type'], $data['status']);
        $data['occurred_at'] = $this->occurredAt->format(DATE_ATOM);
        $data['recorded_at'] = $this->recordedAt->format(DATE_ATOM);
        $data['actor'] = $this->actor?->toArray();

        return $data;
    }

    /** @param array<string,mixed> $data */
    private static function build(array $data, bool $persistence): self
    {
        $eventType = self::requiredString($data, 'event_type', 160);
        $source = self::requiredString($data, 'source', 120);
        $scope = strtolower(trim((string) ($data['scope'] ?? self::SCOPE_TENANT)));
        if (! in_array($scope, [self::SCOPE_TENANT, self::SCOPE_SYSTEM], true)) {
            throw new InvalidArgumentException('Signal scope must be tenant or system.');
        }

        $tenantCompanyId = self::nullablePositiveInt($data['tenant_company_id'] ?? null, 'tenant_company_id');
        if ($scope === self::SCOPE_TENANT && $tenantCompanyId === null) {
            throw new InvalidArgumentException('tenant_company_id is required for tenant-scoped signals.');
        }
        if ($scope === self::SCOPE_SYSTEM && $tenantCompanyId !== null) {
            throw new InvalidArgumentException('System-scoped signals must not carry tenant_company_id.');
        }

        $eventId = self::uuidOrGenerated($data['event_id'] ?? null, 'event_id');
        $traceId = self::uuidOrGenerated($data['trace_id'] ?? null, 'trace_id');
        $correlationId = self::uuidOrGenerated($data['correlation_id'] ?? null, 'correlation_id');
        $causationId = self::nullableUuid($data['causation_id'] ?? null, 'causation_id');
        $rootCausationId = self::nullableUuid($data['root_causation_id'] ?? null, 'root_causation_id') ?? ($causationId ?? $eventId);

        $occurredAt = self::dateTime($data['occurred_at'] ?? null) ?? self::nowUtc();
        $recordedAt = $persistence
            ? (self::dateTime($data['recorded_at'] ?? $data['created_at'] ?? null) ?? self::nowUtc())
            : self::nowUtc();
        $envelopeVersion = self::boundedString((string) ($data['envelope_version'] ?? self::ENVELOPE_VERSION), 'envelope_version', 10);
        if ($envelopeVersion !== self::ENVELOPE_VERSION) {
            throw new InvalidArgumentException("Unsupported signal envelope version {$envelopeVersion}.");
        }

        $schemaVersion = self::positiveInt($data['schema_version'] ?? 1, 'schema_version');
        $payload = self::arrayValue($data['payload'] ?? [], 'payload');
        $metadata = self::arrayValue($data['metadata'] ?? [], 'metadata');
        $severity = SignalSeverity::fromName((string) ($data['severity'] ?? 'info'))->value;
        $sourceComponent = self::nullableString($data['source_component'] ?? null, 'source_component', 120);
        $emitterId = self::nullableString($data['emitter_id'] ?? null, 'emitter_id', 160);
        $category = self::nullableString($data['category'] ?? null, 'category', 80);
        $idempotencyKey = self::nullableString($data['idempotency_key'] ?? null, 'idempotency_key', 191);
        $verticalKey = self::nullableString($data['vertical_key'] ?? null, 'vertical_key', 80);
        $checksumAlgorithm = strtolower(self::boundedString((string) ($data['checksum_alg'] ?? self::CHECKSUM_ALGORITHM), 'checksum_alg', 20));
        if ($checksumAlgorithm !== self::CHECKSUM_ALGORITHM) {
            throw new InvalidArgumentException("Unsupported checksum algorithm {$checksumAlgorithm}.");
        }

        $actor = self::actor($data, $tenantCompanyId, $scope);
        $actorType = $actor?->type;
        $actorId = $actor?->id;
        $actorIdentityProvider = $actor?->identityProvider;
        $actorSessionId = $actor?->sessionId;

        $checksumData = [
            'event_id' => $eventId,
            'event_type' => $eventType,
            'occurred_at' => $occurredAt->format(DATE_ATOM),
            'recorded_at' => $recordedAt->format(DATE_ATOM),
            'envelope_version' => $envelopeVersion,
            'scope' => $scope,
            'tenant_company_id' => $tenantCompanyId,
            'actor' => $actor?->toArray(),
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId,
            'root_causation_id' => $rootCausationId,
            'source' => $source,
            'source_component' => $sourceComponent,
            'schema_version' => $schemaVersion,
            'payload' => $payload,
            'metadata' => $metadata,
            'severity' => $severity,
            'category' => $category,
            'idempotency_key' => $idempotencyKey,
            'vertical_key' => $verticalKey,
            'checksum_alg' => $checksumAlgorithm,
        ];
        if ($emitterId !== null) {
            $checksumData['emitter_id'] = $emitterId;
        }
        $computedChecksum = self::checksum($checksumData, $checksumAlgorithm);
        $storedChecksum = $persistence
            ? (self::nullableString($data['checksum'] ?? null, 'checksum', 64) ?? $computedChecksum)
            : $computedChecksum;

        return new self(
            $eventId,
            $eventType,
            $occurredAt,
            $recordedAt,
            $envelopeVersion,
            $scope,
            $tenantCompanyId,
            $actor,
            $actorType,
            $actorId,
            $actorIdentityProvider,
            $actorSessionId,
            $traceId,
            $correlationId,
            $causationId,
            $rootCausationId,
            $source,
            $sourceComponent,
            $emitterId,
            $schemaVersion,
            $payload,
            $metadata,
            $severity,
            $category,
            $idempotencyKey,
            $verticalKey,
            $checksumAlgorithm,
            $storedChecksum,
        );
    }

    /** @param array<string,mixed> $data */
    private static function actor(array $data, ?int $tenantCompanyId, string $scope): ?SignalActor
    {
        $actorData = $data['actor'] ?? null;
        if ($actorData !== null && ! is_array($actorData)) {
            throw new InvalidArgumentException('actor must be an object/array when provided.');
        }

        if ($actorData === null && (($data['actor_id'] ?? null) !== null || ($data['actor_type'] ?? null) !== null)) {
            $actorData = [
                'id' => $data['actor_id'] ?? '',
                'type' => $data['actor_type'] ?? '',
                'tenant_company_id' => $data['actor_tenant_company_id'] ?? ($scope === self::SCOPE_TENANT ? $tenantCompanyId : null),
                'identity_provider' => $data['actor_identity_provider'] ?? null,
                'session_id' => $data['actor_session_id'] ?? null,
            ];
        }

        if ($actorData === null) {
            return null;
        }

        $actor = SignalActor::fromArray($actorData);
        if ($scope === self::SCOPE_TENANT && $actor->tenantCompanyId !== null && $actor->tenantCompanyId !== $tenantCompanyId) {
            throw new InvalidArgumentException('Signal actor tenant does not match signal tenant boundary.');
        }
        if ($scope === self::SCOPE_SYSTEM && $actor->tenantCompanyId !== null) {
            throw new InvalidArgumentException('System-scoped signal actor must not carry tenant_company_id.');
        }

        return $actor;
    }

    /** @return array<string,mixed> */
    private function canonicalChecksumData(): array
    {
        $data = [
            'event_id' => $this->eventId,
            'event_type' => $this->eventType,
            'occurred_at' => $this->occurredAt->format(DATE_ATOM),
            'recorded_at' => $this->recordedAt->format(DATE_ATOM),
            'envelope_version' => $this->envelopeVersion,
            'scope' => $this->scope,
            'tenant_company_id' => $this->tenantCompanyId,
            'actor' => $this->actor?->toArray(),
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
            'source' => $this->source,
            'source_component' => $this->sourceComponent,
            'schema_version' => $this->schemaVersion,
            'payload' => $this->payload,
            'metadata' => $this->metadata,
            'severity' => $this->severity,
            'category' => $this->category,
            'idempotency_key' => $this->idempotencyKey,
            'vertical_key' => $this->verticalKey,
            'checksum_alg' => $this->checksumAlgorithm,
        ];
        if ($this->emitterId !== null) {
            $data['emitter_id'] = $this->emitterId;
        }

        return $data;
    }

    /** @param array<string, mixed> $data */
    private static function requiredString(array $data, string $key, int $max): string
    {
        if (! array_key_exists($key, $data)) {
            throw new InvalidArgumentException("{$key} is required.");
        }

        return self::boundedString((string) $data[$key], $key, $max);
    }

    private static function boundedString(string $value, string $key, int $max): string
    {
        $value = trim($value);
        if ($value === '') {
            throw new InvalidArgumentException("{$key} must not be empty.");
        }
        if (strlen($value) > $max) {
            throw new InvalidArgumentException("{$key} exceeds {$max} characters.");
        }

        return $value;
    }

    private static function nullableString(mixed $value, string $key, int $max): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        return self::boundedString((string) $value, $key, $max);
    }

    private static function nullablePositiveInt(mixed $value, string $key): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }

        return self::positiveInt($value, $key);
    }

    private static function positiveInt(mixed $value, string $key): int
    {
        if (! is_numeric($value) || (int) $value < 1) {
            throw new InvalidArgumentException("{$key} must be a positive integer.");
        }

        return (int) $value;
    }

    /** @return array<string, mixed> */
    private static function arrayValue(mixed $value, string $key): array
    {
        if (! is_array($value)) {
            throw new InvalidArgumentException("{$key} must be an array.");
        }

        return $value;
    }

    private static function uuidOrGenerated(mixed $value, string $key): string
    {
        if ($value === null || $value === '') {
            return self::uuid7();
        }

        return self::validatedUuid((string) $value, $key);
    }

    private static function nullableUuid(mixed $value, string $key): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        return self::validatedUuid((string) $value, $key);
    }

    private static function validatedUuid(string $value, string $key): string
    {
        $value = strtolower(trim($value));
        if (! preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/', $value)) {
            throw new InvalidArgumentException("{$key} must be a valid UUID.");
        }

        return $value;
    }

    private static function dateTime(mixed $value): ?DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }
        if ($value instanceof DateTimeImmutable) {
            return $value->setTimezone(new DateTimeZone('UTC'));
        }
        if ($value instanceof DateTimeInterface) {
            return (new DateTimeImmutable($value->format(DATE_ATOM)))->setTimezone(new DateTimeZone('UTC'));
        }

        try {
            return (new DateTimeImmutable((string) $value))->setTimezone(new DateTimeZone('UTC'));
        } catch (\Throwable $exception) {
            throw new InvalidArgumentException('Invalid signal timestamp.', previous: $exception);
        }
    }

    private static function nowUtc(): DateTimeImmutable
    {
        return new DateTimeImmutable('now', new DateTimeZone('UTC'));
    }

    private static function uuid7(): string
    {
        $milliseconds = (int) floor(microtime(true) * 1000);
        $bytes = random_bytes(16);
        for ($i = 5; $i >= 0; --$i) {
            $bytes[$i] = chr($milliseconds & 0xff);
            $milliseconds >>= 8;
        }
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x70);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        $hex = bin2hex($bytes);

        return sprintf('%s-%s-%s-%s-%s', substr($hex, 0, 8), substr($hex, 8, 4), substr($hex, 12, 4), substr($hex, 16, 4), substr($hex, 20, 12));
    }

    /** @param array<string, mixed> $data */
    private static function checksum(array $data, string $algorithm): string
    {
        self::ksortRecursive($data);
        try {
            $json = json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION);
        } catch (JsonException $exception) {
            throw new InvalidArgumentException('Signal payload or metadata cannot be encoded as JSON.', previous: $exception);
        }

        return hash($algorithm, $json);
    }

    /** @param array<mixed> $value */
    private static function ksortRecursive(array &$value): void
    {
        foreach ($value as &$item) {
            if (is_array($item)) {
                self::ksortRecursive($item);
            }
        }
        unset($item);
        ksort($value);
    }
}
