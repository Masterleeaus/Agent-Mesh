<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

final readonly class PulseAttentionScore
{
    /** @param list<string> $reasons */
    public function __construct(
        public int $score,
        public string $band,
        public array $reasons,
    ) {
    }

    /** @return array{score:int,band:string,reasons:list<string>} */
    public function toArray(): array
    {
        return ['score' => $this->score, 'band' => $this->band, 'reasons' => $this->reasons];
    }
}
