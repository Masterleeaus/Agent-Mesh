<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Integrations;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Throwable;
final class CrmWebhookDispatcher
{
    public function __construct(private ConnectionInterface $db,private CrmOutboundUrlPolicy $urls){}
    public function dispatch(int $userId,string $eventKey,array $payload):array
    {
        $eventId=(string)Str::ulid();$results=[];$tenant=CrmCompanyScope::companyId($userId);$hooks=$this->db->table('crm_webhooks')->where('company_id',$tenant)->where('enabled',true)->get();
        foreach($hooks as $hook){$events=json_decode((string)$hook->events,true)?:[];if(!in_array('*',$events,true)&&!in_array($eventKey,$events,true))continue;$deliveryId=(string)Str::ulid();$idempotencyKey=hash('sha256',$tenant.'|'.$hook->public_id.'|'.$eventId);$nonce=bin2hex(random_bytes(16));$envelope=['id'=>$eventId,'event'=>$eventKey,'occurred_at'=>now()->toIso8601String(),'idempotency_key'=>$idempotencyKey,'nonce'=>$nonce,'data'=>$payload];$body=json_encode($envelope,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);$secretVersion=(int)($hook->secret_version??1);
            $this->db->table('crm_webhook_deliveries')->insert(['public_id'=>$deliveryId,'company_id'=>$tenant,'user_id'=>CrmCompanyScope::actorUserId($userId),'webhook_public_id'=>$hook->public_id,'event_key'=>$eventKey,'event_id'=>$eventId,'idempotency_key'=>$idempotencyKey,'nonce'=>$nonce,'secret_version'=>$secretVersion,'signature_version'=>(string)config('crm.webhooks.signature_version','v3'),'payload'=>$body,'status'=>'sending','attempt_count'=>1,'created_at'=>now(),'updated_at'=>now()]);
            $results[]=$this->deliver($hook,$deliveryId,$eventKey,$body,1,$idempotencyKey,$nonce,$secretVersion);
        }return $results;
    }
    public function retryDue(?int $userId=null,int $limit=100):array
    {
        $limit=min(max(1,$limit),500);$max=max(1,(int)config('crm.webhooks.max_attempts',5));$q=$this->db->table('crm_webhook_deliveries')->whereIn('status',['failed','pending'])->where('attempt_count','<',$max)->where(function($q):void{$q->whereNull('available_at')->orWhere('available_at','<=',now());})->orderBy('id');if($userId!==null)$q->where('company_id',CrmCompanyScope::companyId($userId));$results=[];
        foreach($q->limit($limit)->get() as $d){$claimed=$this->db->table('crm_webhook_deliveries')->where('id',$d->id)->whereIn('status',['failed','pending'])->update(['status'=>'sending','updated_at'=>now()]);if(!$claimed)continue;$hook=$this->db->table('crm_webhooks')->where('company_id',(int)$d->company_id)->where('public_id',$d->webhook_public_id)->where('enabled',true)->first();if(!$hook){$this->deadLetter((int)$d->id,'Webhook is missing or disabled.');$results[]=['delivery_id'=>$d->public_id,'ok'=>false,'dead_letter'=>true];continue;}$attempt=(int)$d->attempt_count+1;$this->db->table('crm_webhook_deliveries')->where('id',$d->id)->update(['attempt_count'=>$attempt,'available_at'=>null,'updated_at'=>now()]);$nonce=(string)($d->nonce??'');if($nonce===''){$nonce=substr(hash('sha256',(string)$d->public_id.'|'.(string)$d->idempotency_key),0,32);$this->db->table('crm_webhook_deliveries')->where('id',$d->id)->update(['nonce'=>$nonce,'updated_at'=>now()]);}$results[]=$this->deliver($hook,(string)$d->public_id,(string)$d->event_key,(string)$d->payload,$attempt,(string)$d->idempotency_key,$nonce,(int)($d->secret_version??$hook->secret_version??1));}
        return $results;
    }
    public function deadLetters(?int $userId=null,int $limit=100):array
    {
        $q=$this->db->table('crm_webhook_deliveries')->where('status','dead_letter')->orderByDesc('dead_lettered_at')->orderByDesc('id');
        if($userId!==null)$q->where('company_id',CrmCompanyScope::companyId($userId));
        return $q->limit(min(max(1,$limit),500))->get()->map(fn($r)=>(array)$r)->all();
    }
    public function requeueDeadLetter(string $deliveryPublicId,?int $userId=null):void
    {
        $q=$this->db->table('crm_webhook_deliveries')->where('public_id',$deliveryPublicId)->where('status','dead_letter');
        if($userId!==null)$q->where('company_id',CrmCompanyScope::companyId($userId));
        $row=$q->first();if(!$row)throw new \InvalidArgumentException('CRM webhook dead-letter delivery not found.');
        $this->db->table('crm_webhook_deliveries')->where('id',$row->id)->update(['status'=>'pending','attempt_count'=>0,'manual_retry_count'=>((int)($row->manual_retry_count??0))+1,'dead_lettered_at'=>null,'available_at'=>now(),'updated_at'=>now()]);
    }
    private function deliver(object $hook,string $deliveryId,string $eventKey,string $body,int $attempt,string $idempotencyKey,string $nonce,int $secretVersion):array
    {
        $max=max(1,(int)config('crm.webhooks.max_attempts',5));try{$this->urls->assertAllowed((string)$hook->url);$secret=Crypt::decryptString((string)$hook->secret_ciphertext);$currentVersion=(int)($hook->secret_version??1);if($secretVersion!==$currentVersion){if($hook->previous_secret_ciphertext&&$hook->previous_secret_version==$secretVersion&&$hook->previous_secret_expires_at&&now()->lte($hook->previous_secret_expires_at)){$secret=Crypt::decryptString((string)$hook->previous_secret_ciphertext);}else{$secretVersion=$currentVersion;}}$timestamp=(string)time();$sigVersion=(string)config('crm.webhooks.signature_version','v3');$signature=hash_hmac('sha256',$timestamp.'.'.$nonce.'.'.$deliveryId.'.'.$body,$secret);$this->db->table('crm_webhook_deliveries')->where('public_id',$deliveryId)->update(['signed_at'=>now(),'signature_version'=>$sigVersion,'updated_at'=>now()]);$response=Http::timeout((int)config('crm.webhooks.timeout_seconds',10))->connectTimeout(5)->withOptions(['allow_redirects'=>false])->withHeaders(['Content-Type'=>'application/json','X-CRM-Event'=>$eventKey,'X-CRM-Delivery'=>$deliveryId,'X-CRM-Timestamp'=>$timestamp,'X-CRM-Nonce'=>$nonce,'X-CRM-Idempotency-Key'=>$idempotencyKey,'X-CRM-Signature-Version'=>$sigVersion,'X-CRM-Secret-Version'=>(string)$secretVersion,'X-CRM-Signature'=>$sigVersion.'='.$signature])->withBody($body,'application/json')->post((string)$hook->url);$ok=$response->successful();if($ok){$this->db->table('crm_webhook_deliveries')->where('public_id',$deliveryId)->update(['status'=>'delivered','http_status'=>$response->status(),'response_hash'=>hash('sha256',(string)$response->body()),'last_error'=>null,'available_at'=>null,'delivered_at'=>now(),'updated_at'=>now()]);$this->db->table('crm_webhooks')->where('id',$hook->id)->update(['last_success_at'=>now(),'updated_at'=>now()]);}else{$this->recordFailure($hook,$deliveryId,$attempt,'HTTP '.$response->status().': '.mb_substr($response->body(),0,1800));}return ['delivery_id'=>$deliveryId,'ok'=>$ok,'status'=>$response->status(),'attempt'=>$attempt];}catch(Throwable $e){$this->recordFailure($hook,$deliveryId,$attempt,$e->getMessage());return ['delivery_id'=>$deliveryId,'ok'=>false,'error'=>$e->getMessage(),'attempt'=>$attempt,'dead_letter'=>$attempt>=$max];}
    }
    private function recordFailure(object $hook,string $deliveryId,int $attempt,string $error):void{$max=max(1,(int)config('crm.webhooks.max_attempts',5));$base=max(10,(int)config('crm.webhooks.retry_base_seconds',60));$dead=$attempt>=$max;$delay=min(3600,$base*(2**max(0,$attempt-1)));$this->db->table('crm_webhook_deliveries')->where('public_id',$deliveryId)->update(['status'=>$dead?'dead_letter':'failed','dead_lettered_at'=>$dead?now():null,'last_error'=>mb_substr($error,0,2000),'available_at'=>$dead?null:now()->addSeconds($delay),'updated_at'=>now()]);$this->db->table('crm_webhooks')->where('id',$hook->id)->update(['last_failure_at'=>now(),'failure_count'=>((int)$hook->failure_count)+1,'updated_at'=>now()]);}
    private function deadLetter(int $id,string $error):void{$this->db->table('crm_webhook_deliveries')->where('id',$id)->update(['status'=>'dead_letter','dead_lettered_at'=>now(),'last_error'=>$error,'available_at'=>null,'updated_at'=>now()]);}
}
