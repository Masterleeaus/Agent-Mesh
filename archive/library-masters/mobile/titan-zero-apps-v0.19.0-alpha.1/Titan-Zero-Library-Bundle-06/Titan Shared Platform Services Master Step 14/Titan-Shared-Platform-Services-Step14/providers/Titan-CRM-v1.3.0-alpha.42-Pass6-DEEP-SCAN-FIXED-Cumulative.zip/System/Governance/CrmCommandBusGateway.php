<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

use App\Extensions\Crm\System\Capabilities\{CrmCapabilityExecutor,CrmCapabilityRegistry};
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

/**
 * Boundary used by AI/Interaction callers. Reads stay local. Writes are presented
 * to Titan Command Bus; absent an external bus they are deferred rather than executed.
 */
final class CrmCommandBusGateway
{
    public function __construct(
        private readonly CrmCommandBusPort $port,
        private readonly CrmCapabilityRegistry $registry,
        private readonly CrmCapabilityExecutor $executor,
        private readonly CrmCompanyScope $scope,
        private readonly CrmCapabilityRateLimiter $rateLimiter,
        private readonly CrmExpectedVersionResolver $expectedVersions,
    ) {}

    /** @return array<string,mixed> */
    public function request(string $capability,array $input=[],string $source='external'): array
    {
        unset($input['company_id'],$input['tenant_id']);
        $definition=$this->registry->definition($capability);
        if(($definition['mode']??'read')==='read')return $this->executor->execute($capability,$input);

        $current=$this->scope->current();
        $this->rateLimiter->assertAllowed($source,$capability,$current->actorUserId);
        $expectedVersion=$this->expectedVersions->resolve($capability,$input);
        $input['_context']=array_merge((array)($input['_context']??[]),[
            'command_contract_version'=>CrmCommandContract::VERSION,
            'expected_entity_version'=>$expectedVersion,
        ]);
        if($expectedVersion!==null)$input['expected_entity_version']=$expectedVersion;
        $request=CrmCommandRequest::fromContext($capability,$input,$current,$source);
        if($this->port->available())return $this->port->dispatch($request);

        // Preserve trusted human/admin compatibility only when explicitly enabled.
        $humanSources=(array)config('crm.governance.local_human_sources',['crm_web','admin']);
        if((bool)config('crm.governance.allow_legacy_local_human_mutations',false) && in_array($source,$humanSources,true)){
            return $this->executor->execute($capability,$request->input+['_context'=>[
                'command_id'=>$request->commandId,
                'trace_id'=>$request->traceId,
                'correlation_id'=>$request->correlationId,
                'causation_id'=>$request->causationId,
                'source'=>$source,
            ]]);
        }

        return $this->port->dispatch($request);
    }
}
