<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\TenantAssuranceBridgeContract;

final class UnavailableTenantAssuranceBridge implements TenantAssuranceBridgeContract
{
    public function evaluateForTenant(
        int $tenantCompanyId,
        string $capability,
        ?string $workflowKey,
        array $context,
    ): array {
        return [
            'status' => 'RED',
            'decision' => 'denied',
            'confidence' => 0.0,
            'reason_codes' => ['TENANT_ASSURANCE_BRIDGE_UNAVAILABLE'],
            'evaluation_ref' => null,
            'available' => false,
        ];
    }
}
