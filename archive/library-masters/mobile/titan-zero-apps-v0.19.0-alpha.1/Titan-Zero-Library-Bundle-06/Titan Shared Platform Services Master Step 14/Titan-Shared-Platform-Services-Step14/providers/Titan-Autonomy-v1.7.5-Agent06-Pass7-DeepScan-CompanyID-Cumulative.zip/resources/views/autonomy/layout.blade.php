<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Titan Autonomy')</title>
    <style>
        body{font-family:Inter,system-ui,sans-serif;margin:0;background:#f6f7fb;color:#171923}.ta-wrap{max-width:1320px;margin:0 auto;padding:28px}.ta-card{background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:18px;margin-bottom:16px}.ta-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px}.ta-table{width:100%;border-collapse:collapse}.ta-table th,.ta-table td{padding:11px;border-bottom:1px solid #eceff3;text-align:left;vertical-align:top}.ta-btn{display:inline-block;border:0;border-radius:9px;padding:9px 13px;background:#171923;color:white;text-decoration:none;cursor:pointer}.ta-btn.secondary{background:#e7e9ee;color:#171923}.ta-btn.danger{background:#9b1c1c}.ta-muted{color:#68707d}.ta-ok{background:#eaf8ef;padding:10px 12px;border-radius:9px;margin-bottom:14px}.ta-error{background:#fdecec;padding:10px 12px;border-radius:9px;margin-bottom:14px}.ta-pill{display:inline-block;padding:4px 8px;border-radius:999px;background:#eef0f4;font-size:12px}.ta-input{width:100%;box-sizing:border-box;padding:9px;border:1px solid #d6dae1;border-radius:8px}textarea.ta-input{min-height:110px}form.inline{display:inline-block;margin:3px 6px 3px 0}@media(max-width:720px){.ta-wrap{padding:14px}.ta-table{font-size:13px;display:block;overflow-x:auto}}
    </style>
</head>
<body><main class="ta-wrap">@yield('content')</main></body>
</html>
