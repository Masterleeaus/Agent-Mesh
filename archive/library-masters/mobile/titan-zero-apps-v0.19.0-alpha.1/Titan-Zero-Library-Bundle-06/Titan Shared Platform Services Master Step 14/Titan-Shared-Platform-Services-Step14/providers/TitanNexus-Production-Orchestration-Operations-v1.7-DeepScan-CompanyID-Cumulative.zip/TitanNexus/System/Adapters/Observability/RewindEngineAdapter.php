<?php

declare(strict_types=1);
namespace App\Extensions\TitanNexus\System\Adapters\Observability;
use App\Extensions\TitanNexus\System\Contracts\RewindGatewayContract;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use Closure; use InvalidArgumentException; use RuntimeException;
final class RewindEngineAdapter implements RewindGatewayContract
{
    private readonly ?Closure $gateway; public function __construct(?callable $gateway=null){$this->gateway=$gateway===null?null:Closure::fromCallable($gateway);}
    public function record(string $event,ProvisioningOperation $operation,TraceContext $traceContext,ProvisioningExecutionContext $executionContext,array $evidence=[]):string
    {
        if(preg_match('/^[a-z0-9]+(?:[._:-][a-z0-9]+)*$/',$event)!==1)throw new InvalidArgumentException('Rewind evidence event name is invalid.');
        if($this->gateway===null)throw new RuntimeException('Titan Nexus Rewind public gateway is not configured.');
        $result=($this->gateway)($event,['source'=>'titan-nexus','source_schema_version'=>'1.0','operation'=>$operation->toContractArray(),'trace_context'=>$traceContext->toArray(),'execution_context'=>$executionContext->toArray(),'evidence'=>$evidence]);
        if(!is_array($result)||!is_string($result['rewind_reference']??null)||trim($result['rewind_reference'])==='')throw new RuntimeException('Titan Rewind public gateway must return rewind_reference.');
        return trim($result['rewind_reference']);
    }
}
