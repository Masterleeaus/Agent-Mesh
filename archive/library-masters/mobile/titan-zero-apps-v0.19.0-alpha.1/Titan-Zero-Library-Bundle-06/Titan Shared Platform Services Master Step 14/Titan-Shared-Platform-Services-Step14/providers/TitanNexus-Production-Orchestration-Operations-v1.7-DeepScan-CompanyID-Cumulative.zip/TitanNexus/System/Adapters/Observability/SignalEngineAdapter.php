<?php

declare(strict_types=1);
namespace App\Extensions\TitanNexus\System\Adapters\Observability;
use App\Extensions\TitanNexus\System\Contracts\SignalGatewayContract;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use Closure; use InvalidArgumentException; use RuntimeException;
final class SignalEngineAdapter implements SignalGatewayContract
{
    private readonly ?Closure $gateway; public function __construct(?callable $gateway=null){$this->gateway=$gateway===null?null:Closure::fromCallable($gateway);}
    public function emit(string $event,ProvisioningOperation $operation,TraceContext $traceContext,ProvisioningExecutionContext $executionContext,array $evidence=[]):string
    {
        if(preg_match('/^[a-z0-9]+(?:[._:-][a-z0-9]+)*$/',$event)!==1)throw new InvalidArgumentException('Signal event name is invalid.');
        if($this->gateway===null)throw new RuntimeException('Titan Nexus Signal public gateway is not configured.');
        $result=($this->gateway)($event,['operation'=>$operation->toContractArray(),'trace_context'=>$traceContext->toArray(),'execution_context'=>$executionContext->toArray(),'evidence'=>$evidence]);
        if(!is_array($result)||!is_string($result['signal_reference']??null)||trim($result['signal_reference'])==='')throw new RuntimeException('Titan Signal public gateway must return signal_reference.');
        return trim($result['signal_reference']);
    }
}
