<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\Governance\CrmDomainSignalDispatcher;
use Illuminate\Console\Command;

final class DeliverCrmDomainSignalsCommand extends Command
{
    protected $signature='crm:signals:deliver {--limit=100}';
    protected $description='Deliver committed CRM domain Signal outbox events through the Titan Signal port.';
    public function handle(CrmDomainSignalDispatcher $dispatcher): int
    {
        $summary=$dispatcher->deliverDue((int)$this->option('limit'));
        $this->line(json_encode($summary,JSON_UNESCAPED_SLASHES));
        return self::SUCCESS;
    }
}
