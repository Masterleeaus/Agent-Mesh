<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Support;

final class CrmNormalizer
{
    public static function email(?string $value): ?string
    {
        $value = trim((string) $value);
        if ($value === '') return null;
        $value = function_exists('mb_strtolower') ? mb_strtolower($value) : strtolower($value);
        if (str_contains($value,'@')) {
            [$local,$domain]=explode('@',$value,2);
            if(function_exists('idn_to_ascii')){
                $ascii=@idn_to_ascii($domain,IDNA_DEFAULT,INTL_IDNA_VARIANT_UTS46);
                if(is_string($ascii)&&$ascii!=='')$domain=function_exists('mb_strtolower')?mb_strtolower($ascii):strtolower($ascii);
            }
            $value=$local.'@'.$domain;
        }
        return $value;
    }

    public static function phone(?string $value): ?string
    {
        $value=trim((string)$value);if($value==='')return null;
        $value=preg_replace('/\s*(?:ext\.?|extension|x)\s*\d+$/i','',$value)??$value;
        $international=str_starts_with($value,'+')||str_starts_with($value,'00');
        $digits=preg_replace('/\D+/','',$value)??'';if($digits==='')return null;
        if(str_starts_with($value,'00'))$digits=substr($digits,2);
        return $international?'+'.$digits:$digits;
    }
}
