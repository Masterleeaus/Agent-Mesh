<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Contracts\SalesDocumentRepositoryContract;
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use App\Extensions\Crm\System\Services\{SalesDocumentRenderQueueService};
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class SalesDocumentController extends Controller
{
    public function __construct(
        private readonly SalesDocumentRepositoryContract $sales,
        private readonly SalesDocumentRenderQueueService $renders,
        private readonly CrmHumanMutationGateway $mutations,
    ) {}

    public function index(Request $request,string $type)
    {
        $records=$this->sales->search((int)$request->user()->id,$type,$request->only(['status','limit','revision_root_public_id']));
        return $request->expectsJson()?response()->json(['data'=>$records]):view('crm::sales.index',['type'=>$type,'documents'=>$records]);
    }

    public function store(Request $request,string $type)
    {
        $data=$request->validate([
            'company_public_id'=>'nullable|string|size:26','contact_public_id'=>'nullable|string|size:26','source_quote_public_id'=>'nullable|string|size:26','source_work_order_public_id'=>'nullable|string|size:26','number'=>'nullable|string|max:80','title'=>'nullable|string|max:255',
            'status'=>'nullable|string|max:40','currency'=>'nullable|string|size:3','subtotal_minor'=>'nullable|integer|min:0','tax_minor'=>'nullable|integer|min:0','total_minor'=>'nullable|integer|min:0',
            'due_at'=>'nullable|date','expires_at'=>'nullable|date','pricing_rules_version'=>'nullable|string|max:80','pricing_rule_snapshot'=>'nullable|array','tax_rule_snapshot'=>'nullable|array',
            'terms_snapshot'=>'nullable|array','service_definition_snapshot'=>'nullable|array','discount_snapshot'=>'nullable|array','currency_snapshot'=>'nullable|array','meta'=>'nullable|array',
            'lines'=>'nullable|array|min:1','lines.*.description'=>'nullable|string|max:255','lines.*.quantity_milli'=>'nullable|integer|min:1','lines.*.unit_price_minor'=>'nullable|integer|min:0',
            'lines.*.tax_rate_bps'=>'nullable|integer|between:0,10000','lines.*.meta'=>'nullable|array',
        ]);
        if(in_array($type,['proposals','estimates'],true))$record=$this->mutations->execute($request,'crm.quote.create',$data+['type'=>$type]);
        elseif($type==='invoices')$record=$this->mutations->execute($request,'crm.invoice.create',$data);
        else throw new DomainException('Generic payment creation is disabled; use the governed payment recording capability.');
        return $request->expectsJson()?response()->json($record,201):redirect()->route('dashboard.user.sales.documents.show',[$type,$record['public_id']])->with('status','Sales document created.');
    }


    public function transition(Request $request,string $type,string $document)
    {
        $data=$request->validate(['status'=>'required|string|max:40']);
        $context=['type'=>$type,'public_id'=>$document,'status'=>$data['status'],'accepted_via'=>'crm_web'];
        if($data['status']==='accepted'&&$request->hasSession())$context['acceptance_session_id']=$request->session()->getId();
        try{
            if(in_array($type,['proposals','estimates'],true))$record=$this->mutations->execute($request,'crm.quote.transition',$context);
            elseif($type==='invoices')$record=$this->mutations->execute($request,'crm.invoice.transition',['public_id'=>$document,'status'=>$data['status']]);
            else throw new DomainException('Generic payment transitions are disabled.');
            return $request->expectsJson()?response()->json($record):back()->with('status','Sales document status updated.');
        }catch(DomainException $e){return $request->expectsJson()?response()->json(['message'=>$e->getMessage()],422):back()->withErrors(['status'=>$e->getMessage()]);}
    }

    public function revise(Request $request,string $type,string $document)
    {
        abort_unless(in_array($type,['proposals','estimates'],true),422);
        $data=$request->validate(['reason'=>'nullable|string|max:1000','expires_at'=>'nullable|date','number'=>'nullable|string|max:80','title'=>'nullable|string|max:255']);
        $revision=$this->mutations->execute($request,'crm.quote.revise',$data+['type'=>$type,'public_id'=>$document]);
        return $request->expectsJson()?response()->json($revision,201):redirect()->route('dashboard.user.sales.documents.show',[$type,$revision['public_id']])->with('status','New draft revision created.');
    }

    public function requestPdf(Request $request,string $type,string $document)
    {
        $job=$this->mutations->execute($request,'crm.document.render.request',['type'=>$type,'document_public_id'=>$document]);
        return $request->expectsJson()?response()->json(['data'=>$job],202):back()->with('status','PDF rendering queued.');
    }

    public function pdf(Request $request,string $type,string $document)
    {
        try{return $this->renders->download((int)$request->user()->id,$type,$document);}
        catch(DomainException $e){return $request->expectsJson()?response()->json(['message'=>$e->getMessage()],409):back()->withErrors(['pdf'=>$e->getMessage()]);}
    }

    public function email(Request $request,string $type,string $document)
    {
        $data=$request->validate(['email'=>'required|email|max:190']);
        try{$capability=$type==='invoices'?'crm.invoice.send':'crm.quote.send';$this->mutations->execute($request,$capability,['type'=>$type,'public_id'=>$document,'email'=>$data['email']]);return back()->with('status','Document rendering and governed delivery queued.');}
        catch(\Throwable $e){return back()->withErrors(['email'=>$e->getMessage()]);}
    }
}
