#!/usr/bin/env python3
import sqlite3

conn = sqlite3.connect(':memory:')
conn.execute('''
CREATE TABLE titan_prime_missions (
    tenant_company_id INTEGER NOT NULL,
    mission_id TEXT NOT NULL,
    status TEXT NOT NULL,
    lock_version INTEGER NOT NULL,
    UNIQUE (tenant_company_id, mission_id)
)
''')
conn.execute('''
CREATE TABLE titan_prime_mission_operations (
    tenant_company_id INTEGER NOT NULL,
    operation_id TEXT NOT NULL,
    mission_id TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    receipt_json TEXT NOT NULL,
    UNIQUE (tenant_company_id, operation_id)
)
''')
conn.execute("INSERT INTO titan_prime_missions VALUES (7, 'mission-001', 'draft', 1)")

# Two writers both believe version=1/status=draft. Only the first CAS may commit.
writer_a = conn.execute(
    "UPDATE titan_prime_missions SET status='assessing', lock_version=2 "
    "WHERE tenant_company_id=7 AND mission_id='mission-001' AND status='draft' AND lock_version=1"
).rowcount
writer_b = conn.execute(
    "UPDATE titan_prime_missions SET status='assessing', lock_version=2 "
    "WHERE tenant_company_id=7 AND mission_id='mission-001' AND status='draft' AND lock_version=1"
).rowcount
assert writer_a == 1, writer_a
assert writer_b == 0, writer_b

# Tenant + mission identity is unique.
try:
    conn.execute("INSERT INTO titan_prime_missions VALUES (7, 'mission-001', 'draft', 1)")
except sqlite3.IntegrityError:
    pass
else:
    raise AssertionError('duplicate tenant+mission identity was accepted')

# Same mission ID remains valid in another tenant.
conn.execute("INSERT INTO titan_prime_missions VALUES (8, 'mission-001', 'draft', 1)")

# Tenant + operation identity is unique, enabling original-receipt replay/collision handling.
conn.execute("INSERT INTO titan_prime_mission_operations VALUES (7, 'op-1', 'mission-001', 'hash-a', '{}')")
try:
    conn.execute("INSERT INTO titan_prime_mission_operations VALUES (7, 'op-1', 'mission-001', 'hash-b', '{}')")
except sqlite3.IntegrityError:
    pass
else:
    raise AssertionError('duplicate tenant+operation identity was accepted')

print('PASS durable mission store CAS race semantics')
