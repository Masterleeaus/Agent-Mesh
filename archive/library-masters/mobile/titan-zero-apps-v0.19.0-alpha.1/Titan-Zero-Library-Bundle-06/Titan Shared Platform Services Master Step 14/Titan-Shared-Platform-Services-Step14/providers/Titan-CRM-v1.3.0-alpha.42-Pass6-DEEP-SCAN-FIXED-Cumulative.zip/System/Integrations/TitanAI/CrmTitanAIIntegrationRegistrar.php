<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Integrations\TitanAI;
use Illuminate\Contracts\Foundation\Application;

/** Best-effort bridge: CRM provider remains independently usable when TitanAI is absent. */
final class CrmTitanAIIntegrationRegistrar
{
    public function __construct(private Application $app){}
    public function register(): void
    {
        $provider=$this->app->make(CrmTitanAIToolProvider::class);
        $interactionProvider=$this->app->make(CrmInteractionAIToolProvider::class);
        if(method_exists($this->app,'tag')) $this->app->tag([CrmTitanAIToolProvider::class,CrmInteractionAIToolProvider::class],['titan-ai.tool-providers']);
        // TitanAI v1.2 reads its SharedCapabilityRegistry from server config. Add CRM definitions without accepting caller tool schemas.
        if(class_exists(\App\Extensions\TitanAI\System\TitanAI\Capabilities\SharedCapabilityRegistry::class)){
            $catalogue=(array)config('titan-ai.capabilities',[]);
            foreach(($provider->all()+$interactionProvider->all()) as $id=>$definition)$catalogue[$id]=[
                'name'=>$id,'description'=>$definition['description'],'permissions'=>$definition['permissions'],
                'requires_approval'=>$definition['requires_approval'],'provider'=>'crm','operation'=>$id,
            ];
            config(['titan-ai.capabilities'=>$catalogue]);
        }
    }
}
