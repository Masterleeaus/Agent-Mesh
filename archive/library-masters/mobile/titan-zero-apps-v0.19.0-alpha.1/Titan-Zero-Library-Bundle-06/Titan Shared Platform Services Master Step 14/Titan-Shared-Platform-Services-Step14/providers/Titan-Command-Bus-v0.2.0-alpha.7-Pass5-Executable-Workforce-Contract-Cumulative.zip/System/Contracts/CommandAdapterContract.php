<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Contracts;

use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandExecutionResult;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;

interface CommandAdapterContract
{
    public function capability(): string;
    public function execute(CommandContext $context, CommandRequest $request, string $operationId): CommandExecutionResult;
}
