<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Host;

final class TitanExactHostCertification
{
    public function report(string $packageSha256, array $liveEvidence = []): array
    {
        $stages=[
            'PACKAGE_CERTIFIED'=>['status'=>'PASS','evidence'=>['static/fresh-package evidence supplied by release certification']],
        ];
        foreach (['INSTALLER_CERTIFIED','MIGRATION_CERTIFIED','BOOT_CERTIFIED','NAVIGATION_CERTIFIED','AUTHORIZATION_CERTIFIED','RUNTIME_CERTIFIED','UPGRADE_CERTIFIED','UNINSTALL_CERTIFIED'] as $stage) {
            $evidence=$liveEvidence[$stage]??null;
            $stages[$stage]=is_array($evidence)&&($evidence['status']??null)==='PASS'
                ? ['status'=>'PASS','evidence'=>(array)($evidence['evidence']??[])]
                : ['status'=>'NOT_RUN','evidence'=>['requires exact live Titan Zero / MagicAI host evidence']];
        }
        return [
            'schema_version'=>'1.0',
            'host_profile'=>'titan.host.magicai.installer-1.7.6-or-1.7.8.v1',
            'package_sha256'=>$packageSha256,
            'overall_status'=>count(array_filter($stages,static fn(array $s):bool=>$s['status']==='NOT_RUN'))===0?'PASS':'PARTIAL',
            'stages'=>$stages,
        ];
    }
}
