<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Persistence\Exceptions;

use RuntimeException;

final class MissionNotFound extends RuntimeException
{
    public static function forTenant(int $tenantCompanyId, string $missionId): self
    {
        return new self(sprintf('Prime mission [%s] was not found for tenant [%d].', $missionId, $tenantCompanyId));
    }
}
