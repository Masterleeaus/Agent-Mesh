# Signal Events

Emits command.requested, command.completed, command.refused and command.failed with tenant_company_id plus trace_id, correlation_id, causation_id and root_causation_id. Secret-bearing fields are forbidden.
