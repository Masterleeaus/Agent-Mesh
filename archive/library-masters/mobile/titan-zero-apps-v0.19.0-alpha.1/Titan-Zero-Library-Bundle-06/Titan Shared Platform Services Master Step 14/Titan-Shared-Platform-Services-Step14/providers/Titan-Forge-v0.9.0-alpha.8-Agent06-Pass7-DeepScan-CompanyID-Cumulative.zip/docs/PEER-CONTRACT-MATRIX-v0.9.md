# Titan Forge v0.9 Peer Contract Matrix

| Peer | Verified/public boundary used by Forge | Forge behavior |
|---|---|---|
| Titan Signal | Signal emitter contract | Emits causal lifecycle facts; required dependency. |
| Titan AI Core | Typed orchestrator + plan validator | Consumes typed planning only; current DAG validation remains upstream-blocked and no direct provider bypass exists. |
| Titan Shield | Governance-response contract | Submits bounded validation findings; may block release progression. |
| Titan Risk | Risk gate | Assesses release candidate; deny/hold directives block progression. |
| Titan Model Council >=0.7 | `runGoverned()` | Selective high/critical advisory deliberation; sanitized receipt only. |
| Titan Governance | Current verified health/read boundary | Release approval fails closed until a callable decision contract is available. |
| Titan Command Bus | Current verified health/read boundary | No production dispatch/self-deploy until a callable governed dispatch contract is available. |
| Titan Rewind >=1.0 | Blueprint v4.2.1 host `RewindSourceAdapter` | Rewind consumes Forge-owned read-only forensic evidence. No direct Rewind internal imports. `supports_as_of=false`. |

All integrations preserve tenant and causal context. Missing or weaker peer authority never increases Forge authority.
