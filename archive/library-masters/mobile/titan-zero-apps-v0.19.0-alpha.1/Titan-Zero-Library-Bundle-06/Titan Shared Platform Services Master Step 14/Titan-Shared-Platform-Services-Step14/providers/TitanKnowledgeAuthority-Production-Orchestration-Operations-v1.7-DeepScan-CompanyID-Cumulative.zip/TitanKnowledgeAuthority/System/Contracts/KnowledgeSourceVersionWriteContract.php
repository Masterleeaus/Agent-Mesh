<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Contracts;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeSourceVersionAppendRequest;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeSourceVersionAppendResult;

interface KnowledgeSourceVersionWriteContract
{
    public function append(KnowledgeSourceVersionAppendRequest $request): KnowledgeSourceVersionAppendResult;
}
