<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

final class MessageAttachment extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use HasUuids;

    protected $table = 'ext_titan_connect_attachments';

    protected $fillable = [
        'uuid', 'company_id', 'message_id', 'external_message_id', 'storage_disk', 'storage_path',
        'original_name', 'mime_type', 'size_bytes', 'sha256', 'scan_status', 'provider_media', 'expires_at',
    ];

    protected $casts = ['size_bytes' => 'integer', 'provider_media' => 'array', 'expires_at' => 'datetime'];

    public function uniqueIds(): array
    {
        return ['uuid'];
    }

    public function getRouteKeyName(): string
    {
        return 'uuid';
    }
}
