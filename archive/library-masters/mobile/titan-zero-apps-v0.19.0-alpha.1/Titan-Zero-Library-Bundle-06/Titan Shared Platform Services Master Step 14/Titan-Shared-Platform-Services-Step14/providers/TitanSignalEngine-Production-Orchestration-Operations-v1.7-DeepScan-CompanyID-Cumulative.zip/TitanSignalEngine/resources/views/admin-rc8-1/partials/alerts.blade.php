@if(session('status')) <div class="tse-alert">{{ session('status') }}</div> @endif
@if(session('error')) <div class="tse-alert tse-danger">{{ session('error') }}</div> @endif
@if(!empty($consoleError)) <div class="tse-alert tse-danger">{{ $consoleError }}</div> @endif
