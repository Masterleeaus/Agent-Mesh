# Capabilities

## Advertised extension capabilities
- `titan-knowledge-authority`
- `knowledge.health`

## Internal scoped catalog contract
`KnowledgeCatalogReadContract` provides context-safe source/version metadata reads for host integration, but it is not yet advertised as a public extension capability. Access context is resolved internally through `KnowledgeAccessContextResolverContract`.

## Internal immutable-version write contract
`KnowledgeSourceVersionWriteContract` provides the only canonical extension-owned source-version append seam in Pass 4. It accepts content/evidence hashes, timestamps, provenance and an optional expected predecessor precondition. It does not accept tenant ownership, sequence, version key or an arbitrary supersession pointer. Existing lineage is checked before append and duplicate content returns idempotently.

No source retrieval, recurring refresh, claim extraction, citation API, authority precedence, jurisdiction inheritance, applicability evaluation, contradiction resolution, `knowledge.resolve`, Signal emission or business-state mutation capability is advertised in Pass 4.
