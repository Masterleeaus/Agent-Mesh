<style>.titan-connect-header-inbox{position:relative;display:inline-flex;align-items:center}.tc-nav-badge{display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;padding:0 5px;border-radius:999px;font-size:11px;font-weight:700;background:var(--color-primary,#ef4444);color:#fff}.titan-connect-header-inbox>.tc-nav-badge{position:absolute;right:-8px;top:-8px}</style>
<a
    href="{{ route('dashboard.user.titan-connect.inbox.unified') }}"
    class="titan-connect-header-inbox"
    data-titan-connect-inbox-header
    data-badge-endpoint="{{ route('titan-connect.api.navigation.badges') }}"
    aria-label="{{ __('Titan Connect Inbox') }}"
>
    <span aria-hidden="true">✉</span>
    <span class="tc-nav-badge" data-titan-connect-inbox-badge hidden>0</span>
</a>
<script>window.TitanConnectNavigationBadgeUrl = @json(route('titan-connect.api.navigation.badges'));</script>
<script src="{{ asset('vendor/titan-connect/js/navigation-badges.js') }}" defer></script>
