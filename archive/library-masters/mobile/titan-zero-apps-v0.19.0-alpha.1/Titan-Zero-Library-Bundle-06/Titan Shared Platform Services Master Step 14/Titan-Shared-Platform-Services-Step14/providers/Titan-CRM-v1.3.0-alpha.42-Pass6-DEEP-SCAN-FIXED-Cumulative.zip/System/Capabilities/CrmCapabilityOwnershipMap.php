<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Capabilities;

final class CrmCapabilityOwnershipMap
{
    private const FIELD_PREFIXES = [
        'crm.service.', 'crm.service_request.', 'crm.work_order.', 'crm.appointment.', 'crm.dispatch.',
        'crm.location.', 'crm.asset.', 'crm.time.', 'crm.material.', 'crm.form.', 'crm.form_submission.',
        'crm.evidence.', 'crm.review.', 'crm.recurring.', 'crm.service_area.', 'crm.support.',
    ];

    public function owner(string $capability): string
    {
        if (str_starts_with($capability, 'crm.locker.')) return 'titan-locker';
        if (str_starts_with($capability, 'crm.bookkeeping.')) return 'titan-ledger';
        if (str_starts_with($capability, 'crm.pay.') || str_starts_with($capability, 'crm.payment.')) return 'titan-pay';
        if ($capability === 'crm.staff.schedule') return 'titan-field';
        foreach (self::FIELD_PREFIXES as $prefix) if (str_starts_with($capability, $prefix)) return 'titan-field';
        return 'crm';
    }

    public function isExternal(string $capability): bool { return $this->owner($capability) !== 'crm'; }

    public function providerClass(string $owner): ?string
    {
        return match ($owner) {
            'titan-field' => 'App\\Extensions\\TitanField\\System\\TitanFieldServiceProvider',
            'titan-locker' => 'App\\Extensions\\TitanLocker\\System\\TitanLockerServiceProvider',
            'titan-ledger' => 'App\\Extensions\\TitanLedger\\System\\TitanLedgerServiceProvider',
            'titan-pay' => 'App\\Extensions\\TitanPay\\System\\TitanPayServiceProvider',
            default => null,
        };
    }
}
