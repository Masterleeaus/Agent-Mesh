<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class ValidationReport {
    /** @param array<int,ValidationIssue> $errors @param array<int,ValidationIssue> $warnings @param array<int,ValidationIssue> $suggestions */
    public function __construct(public bool $valid, public bool $executable, public array $errors = [], public array $warnings = [], public array $suggestions = [], public string $validatorVersion = '0.5.0') {}
    public function toArray(): array { return ['valid'=>$this->valid,'executable'=>$this->executable,'errors'=>array_map(fn(ValidationIssue $v)=>$v->toArray(),$this->errors),'warnings'=>array_map(fn(ValidationIssue $v)=>$v->toArray(),$this->warnings),'suggestions'=>array_map(fn(ValidationIssue $v)=>$v->toArray(),$this->suggestions),'validator_version'=>$this->validatorVersion]; }
}
