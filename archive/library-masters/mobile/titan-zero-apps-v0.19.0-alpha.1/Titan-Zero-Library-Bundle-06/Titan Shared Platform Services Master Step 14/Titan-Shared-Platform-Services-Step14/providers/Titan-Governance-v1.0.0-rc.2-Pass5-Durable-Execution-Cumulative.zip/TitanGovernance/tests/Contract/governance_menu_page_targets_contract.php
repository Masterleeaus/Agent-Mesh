<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);$errors=[];
$routes=(string)file_get_contents($root.'/routes/user.php');
if(!str_contains($routes,"->get('/overview', IndexController::class)->name('overview')"))$errors[]='overview alias route missing';
$cc=(string)file_get_contents($root.'/System/Http/Controllers/ControlCentreController.php');
foreach(["expectsJson()","view('titan-governance::control-centre'"] as $n) if(!str_contains($cc,$n))$errors[]='control centre browser/API dual response missing '.$n;
$rp=(string)file_get_contents($root.'/System/Http/Controllers/ReadPlaneController.php');
foreach(["expectsJson()","view('titan-governance::read-plane'","Signal Heatmap","Operational Pressure","Circuit Breakers"] as $n) if(!str_contains($rp,$n))$errors[]='read plane browser/API dual response missing '.$n;
$ga=(string)file_get_contents($root.'/System/Http/Controllers/GovernanceActionController.php');
foreach(["expectsJson()","view('titan-governance::escalations'"] as $n) if(!str_contains($ga,$n))$errors[]='escalation queue browser/API dual response missing '.$n;
foreach(['resources/views/control-centre.blade.php','resources/views/read-plane.blade.php','resources/views/escalations.blade.php'] as $f) if(!is_file($root.'/'.$f))$errors[]='browser menu target view missing '.$f;
if($errors){fwrite(STDERR,'FAIL: '.implode('; ',$errors)."\n");exit(1);}echo "PASS: Governance menu browser page targets\n";
