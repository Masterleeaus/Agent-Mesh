# Governance

Titan Wisdom is an evidence-producing retrospective intelligence engine. It does not own policy, autonomy, risk, assurance, Command Bus execution or authoritative knowledge promotion.

Every Wisdom mutation requires a fresh decision scoped to the same `tenant_company_id` and exact governed operation. Only `ALLOW` proceeds. Missing, stale, expired, future-dated, cross-tenant, operation-mismatched, `REQUIRE_APPROVAL`, `HOLD`, and `DENY` decisions fail closed.

Active governed operations are:

- `wisdom.outcome.record`
- `wisdom.evidence.attach`
- `wisdom.outcome.resolve`
- `wisdom.outcome.revise`

Queued observation-due work is deliberately non-mutating and does not manufacture a governance decision. Any resulting evidence or resolution returns through the governed mutation capabilities.

Permanent local hard-denies remain: Wisdom cannot promote its own learning candidate into authoritative knowledge, grant autonomy, or perform cross-domain writes.
