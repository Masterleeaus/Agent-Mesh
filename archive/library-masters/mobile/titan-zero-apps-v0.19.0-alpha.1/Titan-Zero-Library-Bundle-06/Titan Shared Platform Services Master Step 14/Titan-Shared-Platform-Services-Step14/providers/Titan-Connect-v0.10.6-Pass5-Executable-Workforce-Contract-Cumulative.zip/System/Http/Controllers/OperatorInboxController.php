<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Extensions\TitanConnect\System\Services\OperatorInboxService;
use App\Extensions\TitanConnect\System\View\MagicAiDashboardRenderer;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

final class OperatorInboxController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly ChannelAccessPolicy $policy,
        private readonly WorkCoreAuthorizationGateway $workCore,
        private readonly MagicAiDashboardRenderer $dashboard,
    ) {}

    public function view(Request $request): View
    {
        $this->context->companyId($request);
        return $this->dashboard->render('titan-connect::inbox.index', [], __('Inbox'));
    }

    public function index(Request $request, OperatorInboxService $service): JsonResponse
    {
        $companyId = $this->context->companyId($request); $actorId = $this->context->actorId($request);
        $filters = $request->only(['provider','status','assigned_user_id','unassigned','priority','search','tag_id','from','to','sort','unread','handoff_state','limit']);
        return response()->json(['data' => $service->search($companyId, $actorId, $filters)]);
    }

    public function notification(Request $request, OperatorInboxService $service): JsonResponse
    {
        $companyId = $this->context->companyId($request); $actorId = $this->context->actorId($request);
        return response()->json(['count' => $service->unreadCount($companyId, $actorId)]);
    }

    public function messages(Request $request, ExternalThread $thread): JsonResponse
    {
        $companyId = $this->context->companyId($request); $actorId = $this->context->actorId($request);
        $this->assertAccess($companyId, $actorId, $thread);
        $limit = min(100, max(1, (int) $request->integer('limit', 50)));
        $messages = $thread->messages()->where('company_id', $companyId)->with('attachments')->latest('created_at')->limit($limit)->get()->reverse()->values();
        return response()->json(['data' => $messages]);
    }

    private function assertAccess(int $companyId, int $actorId, ExternalThread $thread): void
    {
        abort_unless((int) $thread->company_id === $companyId, 404);
        abort_unless($this->policy->canView($thread->connection, $actorId), 403);
        if ($thread->linked_entity_type !== null && $thread->linked_entity_id !== null) {
            $this->workCore->assertCanAccess($companyId, $actorId, (string) $thread->linked_entity_type, (string) $thread->linked_entity_id);
        }
    }
}
