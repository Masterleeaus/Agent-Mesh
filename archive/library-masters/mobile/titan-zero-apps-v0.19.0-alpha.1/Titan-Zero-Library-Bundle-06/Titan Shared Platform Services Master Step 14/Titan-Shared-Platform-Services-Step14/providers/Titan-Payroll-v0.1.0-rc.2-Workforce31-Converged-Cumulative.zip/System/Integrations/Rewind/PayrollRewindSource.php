<?php
namespace App\Extensions\TitanPayroll\System\Integrations\Rewind;
interface PayrollRewindSource { /** Privacy-minimized versioned facts only; never payslip/bank/tax payloads. */ public function watermark(int $tenantCompanyId): array; public function factsSince(int $tenantCompanyId,string $watermark): iterable; }
