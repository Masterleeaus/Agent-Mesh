<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Models\ExternalThread;
use RuntimeException;

final class ConversationExportService
{
    /** @return array{content:string,mime:string,extension:string} */
    public function export(int $companyId, ExternalThread $thread, string $format): array
    {
        if ((int) $thread->company_id !== $companyId) throw new RuntimeException('External thread company mismatch.');
        $thread->loadMissing(['messages' => fn ($q) => $q->where('company_id', $companyId)->orderBy('created_at'), 'tags', 'contact']);
        $rows = $thread->messages->map(fn ($m) => [
            'timestamp' => $m->created_at?->toIso8601String(), 'direction' => $m->direction,
            'sender' => $m->sender_ref, 'message_type' => $m->message_type, 'message' => $m->body,
        ])->all();
        $format = strtolower(trim($format));
        return match ($format) {
            'json' => ['content' => json_encode(['thread' => $thread->only(['uuid','provider','display_name','status','external_contact_ref']), 'messages' => $rows], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR), 'mime' => 'application/json', 'extension' => 'json'],
            'csv' => ['content' => $this->csv($rows), 'mime' => 'text/csv; charset=UTF-8', 'extension' => 'csv'],
            'txt', 'text' => ['content' => $this->text($thread, $rows), 'mime' => 'text/plain; charset=UTF-8', 'extension' => 'txt'],
            'pdf' => $this->pdf($thread, $rows),
            default => throw new RuntimeException('Unsupported conversation export format.'),
        };
    }

    private function csv(array $rows): string
    {
        $stream = fopen('php://temp', 'w+');
        if ($stream === false) throw new RuntimeException('Unable to create conversation export.');
        fputcsv($stream, ['timestamp','direction','sender','message_type','message']);
        foreach ($rows as $row) fputcsv($stream, $row);
        rewind($stream); $content = stream_get_contents($stream); fclose($stream);
        return is_string($content) ? $content : '';
    }

    private function text(ExternalThread $thread, array $rows): string
    {
        $lines = ['Titan Connect Conversation '.$thread->uuid, 'Provider: '.$thread->provider, 'Contact: '.($thread->display_name ?: $thread->external_contact_ref), ''];
        foreach ($rows as $row) $lines[] = sprintf('[%s] %s: %s', (string) $row['timestamp'], (string) $row['direction'], (string) $row['message']);
        return implode("\n", $lines)."\n";
    }

    private function pdf(ExternalThread $thread, array $rows): array
    {
        if (! class_exists('Barryvdh\\DomPDF\\Facade\\Pdf')) throw new RuntimeException('PDF export requires the host DomPDF integration.');
        $html = '<h1>Titan Connect Conversation</h1><p>'.htmlspecialchars((string) ($thread->display_name ?: $thread->external_contact_ref)).'</p>';
        foreach ($rows as $row) $html .= '<p><strong>'.htmlspecialchars((string) $row['direction']).'</strong> '.htmlspecialchars((string) $row['message']).'</p>';
        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadHTML($html)->output();
        return ['content' => $pdf, 'mime' => 'application/pdf', 'extension' => 'pdf'];
    }
}
