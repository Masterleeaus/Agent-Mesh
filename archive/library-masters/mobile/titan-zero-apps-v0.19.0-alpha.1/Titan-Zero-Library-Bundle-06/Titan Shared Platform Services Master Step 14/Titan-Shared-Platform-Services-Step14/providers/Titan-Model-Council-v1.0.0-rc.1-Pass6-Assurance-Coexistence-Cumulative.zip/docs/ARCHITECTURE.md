# Titan Model Council Architecture

Titan Model Council is the canonical Titan **model-deliberation** governance engine. It is advisory: it plans deliberation depth, coordinates multiple model perspectives, detects contradiction, verifies supplied evidence, and returns a governed decision artifact. It never grants execution authority and does not own business records, Risk, Assurance, Autonomy, Command Bus execution, or the Signal nervous system.

## Runtime paths

- `council.plan`: deterministic selective-activation planning under trusted tenant context.
- `council.deliberate`: single/lightweight/parallel/governed deliberation. Governed mode uses Proposer → Critic → Verifier → Shield pre-validation → Arbiter → Shield final validation.
- Provider execution remains behind a runtime boundary. Until Titan AI Core publishes an executable provider contract, the retained compatibility runtime performs provider calls.
- Titan Risk can raise minimum Council depth and can reduce/block downstream authority; Council consensus cannot override Risk.
- Titan Signal is required by Blueprint v4.2 and carries trace/correlation/causation/root-causation context.

## Storage

Owned tables: decisions, participants, billing reservations, and legacy Council response records. `user_openai_chat_messages` is a shared compatibility surface only and is accessed through an explicit versioned compatibility contract.
