<?php

declare(strict_types=1);

return [
    'retention_days' => (int) env('TITAN_CONNECT_RETENTION_DAYS', 365), // backwards-compatible alias

    'credentials' => [
        // Disabled by default so company channel owners cannot select platform-level provider secrets.
        // Enable only for controlled self-hosted/bootstrap migration scenarios.
        'allow_config_fallback' => (bool) env('TITAN_CONNECT_ALLOW_CONFIG_CREDENTIALS', false),
    ],

    'retention' => [
        'default_days' => (int) env('TITAN_CONNECT_RETENTION_DAYS', 365),
        // Host applications may override per company: retention.companies.{companyId}.days
        'companies' => [],
    ],

    'http' => [
        'timeout_seconds' => (int) env('TITAN_CONNECT_HTTP_TIMEOUT', 15),
        'connect_timeout_seconds' => (int) env('TITAN_CONNECT_HTTP_CONNECT_TIMEOUT', 5),
        'user_agent' => env('TITAN_CONNECT_HTTP_USER_AGENT', 'TitanConnect/0.10'),
    ],

    'attachments' => [
        'storage_disk' => env('TITAN_CONNECT_ATTACHMENT_DISK', env('FILESYSTEM_DISK', 'local')),
        'provider_url_ttl_seconds' => (int) env('TITAN_CONNECT_ATTACHMENT_PROVIDER_URL_TTL', 600),
        'allow_external_public_urls' => (bool) env('TITAN_CONNECT_ALLOW_EXTERNAL_ATTACHMENT_URLS', false),
        'max_bytes' => (int) env('TITAN_CONNECT_ATTACHMENT_MAX_BYTES', 25 * 1024 * 1024),
        'allowed_mime_types' => [
            'image/jpeg', 'image/png', 'image/webp', 'application/pdf',
            'text/plain', 'audio/mpeg', 'audio/mp4', 'audio/ogg', 'video/mp4',
        ],
    ],


    'integrations' => [
        // Set these to host classes implementing the named Titan Connect contracts.
        // Invalid configured classes fail fast during extension registration.
        'provider_http_client' => env('TITAN_CONNECT_HTTP_CLIENT_CLASS', App\Extensions\TitanConnect\System\Http\LaravelProviderHttpClient::class),
        'credential_vault' => env('TITAN_CONNECT_CREDENTIAL_VAULT_CLASS', App\Extensions\TitanConnect\System\Security\EncryptedCredentialVault::class),
        'workcore_authorization_gateway' => env('TITAN_CONNECT_WORKCORE_GATEWAY_CLASS', App\Extensions\TitanConnect\System\Integration\EventWorkCoreAuthorizationGateway::class),
        'chatbot_messaging_bridge' => env('TITAN_CONNECT_CHATBOT_BRIDGE_CLASS', App\Extensions\TitanConnect\System\Integration\EventChatbotMessagingBridge::class),
        'mobile_push_gateway' => env('TITAN_CONNECT_MOBILE_PUSH_CLASS', App\Extensions\TitanConnect\System\Integration\EventMobilePushGateway::class),
        'attachment_security_scanner' => env('TITAN_CONNECT_ATTACHMENT_SCANNER_CLASS', App\Extensions\TitanConnect\System\Security\PendingAttachmentSecurityScanner::class),
        'messaging_privacy_hook' => env('TITAN_CONNECT_PRIVACY_HOOK_CLASS', App\Extensions\TitanConnect\System\Security\NullMessagingPrivacyHook::class),
        'reply_assistant' => env('TITAN_CONNECT_REPLY_ASSISTANT_CLASS', App\Extensions\TitanConnect\System\Integration\MagicAiReplyAssistant::class),
        'voice_session_gateway' => env('TITAN_CONNECT_VOICE_SESSION_GATEWAY_CLASS', App\Extensions\TitanConnect\System\Voice\DefaultVoiceSessionGateway::class),
        // Voice-agent authoring is opt-in because host-level ElevenLabs credentials may be platform-owned.
        'voice_agent_gateway' => env('TITAN_CONNECT_VOICE_AGENT_GATEWAY_CLASS', App\Extensions\TitanConnect\System\Security\NullVoiceAgentGateway::class),
    ],

    'voice' => [
        'openai' => [
            'model' => env('TITAN_CONNECT_OPENAI_REALTIME_MODEL', 'gpt-realtime'),
            'voice' => env('TITAN_CONNECT_OPENAI_REALTIME_VOICE', 'verse'),
            'client_secret_endpoint' => env('TITAN_CONNECT_OPENAI_REALTIME_CLIENT_SECRET_ENDPOINT', 'https://api.openai.com/v1/realtime/client_secrets'),
            'websocket_url' => env('TITAN_CONNECT_OPENAI_REALTIME_WEBSOCKET_URL', 'wss://api.openai.com/v1/realtime'),
        ],
        'elevenlabs' => [
            'signed_url_endpoint' => env('TITAN_CONNECT_ELEVENLABS_SIGNED_URL_ENDPOINT', 'https://api.elevenlabs.io/v1/convai/conversation/get-signed-url'),
            'sdk_url' => env('TITAN_CONNECT_ELEVENLABS_SDK_URL', 'https://cdn.jsdelivr.net/npm/@elevenlabs/client@latest/dist/umd/elevenlabs-client.umd.js'),
        ],
    ],

    'rate_limits' => [
        'send' => ['attempts' => (int) env('TITAN_CONNECT_RATE_SEND_ATTEMPTS', 60), 'decay_seconds' => (int) env('TITAN_CONNECT_RATE_SEND_DECAY', 60)],
        'admin' => ['attempts' => (int) env('TITAN_CONNECT_RATE_ADMIN_ATTEMPTS', 30), 'decay_seconds' => (int) env('TITAN_CONNECT_RATE_ADMIN_DECAY', 60)],
        'upload' => ['attempts' => (int) env('TITAN_CONNECT_RATE_UPLOAD_ATTEMPTS', 20), 'decay_seconds' => (int) env('TITAN_CONNECT_RATE_UPLOAD_DECAY', 60)],
        'ai' => ['attempts' => (int) env('TITAN_CONNECT_RATE_AI_ATTEMPTS', 30), 'decay_seconds' => (int) env('TITAN_CONNECT_RATE_AI_DECAY', 60)],
        'voice' => ['attempts' => (int) env('TITAN_CONNECT_RATE_VOICE_ATTEMPTS', 180), 'decay_seconds' => (int) env('TITAN_CONNECT_RATE_VOICE_DECAY', 60)],
    ],

    'certification' => [
        'probe_timeout_seconds' => (int) env('TITAN_CONNECT_CERTIFICATION_TIMEOUT', 10),
        'queue' => env('TITAN_CONNECT_CERTIFICATION_QUEUE', env('TITAN_CONNECT_WEBHOOK_QUEUE', 'default')),
    ],

    'delivery' => [
        'attempt_lease_seconds' => (int) env('TITAN_CONNECT_DELIVERY_ATTEMPT_LEASE', 300),
    ],

    'webhooks' => [
        'async_after_response' => (bool) env('TITAN_CONNECT_WEBHOOK_ASYNC_AFTER_RESPONSE', true),
        'queue' => env('TITAN_CONNECT_WEBHOOK_QUEUE', 'default'),
    ],

    'providers' => [
        'meta' => [
            'app_id' => env('TITAN_CONNECT_META_APP_ID', ''),
            'app_secret' => env('TITAN_CONNECT_META_APP_SECRET', ''),
            'dialog_base_url' => env('TITAN_CONNECT_META_DIALOG_BASE_URL', 'https://www.facebook.com'),
            'oauth_version' => env('TITAN_CONNECT_META_OAUTH_VERSION', env('TITAN_CONNECT_META_GRAPH_VERSION', 'v25.0')),
            'graph_base_url' => env('TITAN_CONNECT_META_GRAPH_BASE_URL', 'https://graph.facebook.com'),
            'graph_version' => env('TITAN_CONNECT_META_GRAPH_VERSION', 'v25.0'),
        ],

        'whatsapp' => [
            'graph_base_url' => env('TITAN_CONNECT_META_GRAPH_BASE_URL', 'https://graph.facebook.com'),
            'graph_version' => env('TITAN_CONNECT_META_GRAPH_VERSION', 'v25.0'),
            'twilio' => [
                'api_base_url' => env('TITAN_CONNECT_TWILIO_API_BASE_URL', 'https://api.twilio.com/2010-04-01'),
            ],
            'credentials' => [
                'default' => [
                    'app_secret' => env('TITAN_CONNECT_WHATSAPP_APP_SECRET', ''),
                    'verify_token' => env('TITAN_CONNECT_WHATSAPP_VERIFY_TOKEN', ''),
                    'access_token' => env('TITAN_CONNECT_WHATSAPP_ACCESS_TOKEN', ''),
                    'phone_number_id' => env('TITAN_CONNECT_WHATSAPP_PHONE_NUMBER_ID', ''),
                ],
            ],
        ],

        'messenger' => [
            'graph_base_url' => env('TITAN_CONNECT_META_GRAPH_BASE_URL', 'https://graph.facebook.com'),
            'graph_version' => env('TITAN_CONNECT_META_GRAPH_VERSION', 'v25.0'),
            'credentials' => [
                'default' => [
                    'app_secret' => env('TITAN_CONNECT_MESSENGER_APP_SECRET', ''),
                    'verify_token' => env('TITAN_CONNECT_MESSENGER_VERIFY_TOKEN', ''),
                    'access_token' => env('TITAN_CONNECT_MESSENGER_ACCESS_TOKEN', ''),
                    'page_id' => env('TITAN_CONNECT_MESSENGER_PAGE_ID', ''),
                ],
            ],
        ],

        'instagram' => [
            'graph_base_url' => env('TITAN_CONNECT_INSTAGRAM_GRAPH_BASE_URL', env('TITAN_CONNECT_META_GRAPH_BASE_URL', 'https://graph.facebook.com')),
            'graph_version' => env('TITAN_CONNECT_META_GRAPH_VERSION', 'v25.0'),
            'credentials' => [
                'default' => [
                    'app_secret' => env('TITAN_CONNECT_INSTAGRAM_APP_SECRET', ''),
                    'verify_token' => env('TITAN_CONNECT_INSTAGRAM_VERIFY_TOKEN', ''),
                    'access_token' => env('TITAN_CONNECT_INSTAGRAM_ACCESS_TOKEN', ''),
                    'instagram_account_id' => env('TITAN_CONNECT_INSTAGRAM_ACCOUNT_ID', ''),
                ],
            ],
        ],

        'telegram' => [
            'api_base_url' => env('TITAN_CONNECT_TELEGRAM_API_BASE_URL', 'https://api.telegram.org'),
            'credentials' => [
                'default' => [
                    'webhook_secret' => env('TITAN_CONNECT_TELEGRAM_WEBHOOK_SECRET', ''),
                    'bot_token' => env('TITAN_CONNECT_TELEGRAM_BOT_TOKEN', ''),
                ],
            ],
        ],

        'sms' => [
            'driver' => env('TITAN_CONNECT_SMS_DRIVER', 'twilio'),
            'twilio' => [
                'api_base_url' => env('TITAN_CONNECT_TWILIO_API_BASE_URL', 'https://api.twilio.com/2010-04-01'),
            ],
            'credentials' => [
                'default' => [
                    'driver' => env('TITAN_CONNECT_SMS_DRIVER', 'twilio'),
                    'account_sid' => env('TITAN_CONNECT_TWILIO_ACCOUNT_SID', ''),
                    'auth_token' => env('TITAN_CONNECT_TWILIO_AUTH_TOKEN', ''),
                    'api_key_sid' => env('TITAN_CONNECT_TWILIO_API_KEY_SID', ''),
                    'api_key_secret' => env('TITAN_CONNECT_TWILIO_API_KEY_SECRET', ''),
                    'from' => env('TITAN_CONNECT_SMS_FROM', ''),
                    'status_callback' => env('TITAN_CONNECT_SMS_STATUS_CALLBACK', ''),
                    'webhook_url' => env('TITAN_CONNECT_SMS_WEBHOOK_URL', ''),
                    // Generic fallback for non-Twilio gateways that sign the raw body with HMAC-SHA256.
                    'webhook_secret' => env('TITAN_CONNECT_SMS_WEBHOOK_SECRET', ''),
                    'signature_header' => env('TITAN_CONNECT_SMS_SIGNATURE_HEADER', 'x-titan-connect-signature'),
                ],
            ],
        ],

        'voice' => [
            'credentials' => ['default' => []],
        ],

        // Push delivery is delegated to TitanMobileCore through MobilePushGateway.
        'push' => ['credentials' => ['default' => []]],
    ],
];
