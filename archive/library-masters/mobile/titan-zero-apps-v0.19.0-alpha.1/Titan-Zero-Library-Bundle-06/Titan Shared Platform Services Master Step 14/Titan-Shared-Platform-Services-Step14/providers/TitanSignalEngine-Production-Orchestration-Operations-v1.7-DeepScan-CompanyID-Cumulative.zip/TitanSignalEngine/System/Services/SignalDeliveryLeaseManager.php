<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryLeaseManagerContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryLease;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryLeasePolicy;
use App\Extensions\TitanSignalEngine\System\Models\SignalDelivery;
use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;
use Illuminate\Support\Facades\DB;

final class SignalDeliveryLeaseManager implements SignalDeliveryLeaseManagerContract
{
    public function __construct(private readonly SignalDeliveryLeasePolicy $policy)
    {
    }

    public function newExecutionToken(): string
    {
        return $this->policy->newToken();
    }

    public function claim(string $deliveryId, string $executionToken, string $workerId, int $ttlSeconds): ?SignalDeliveryLease
    {
        $ttlSeconds = max(30, min($ttlSeconds, 7200));
        $now = now();
        $expiresAt = $now->copy()->addSeconds($ttlSeconds);

        $updated = SignalDelivery::query()
            ->where('delivery_id', $deliveryId)
            ->whereNotIn('status', ['delivered', 'dead_letter'])
            ->where(function ($query) use ($now): void {
                $query->where(function ($query) use ($now): void {
                    $query->whereIn('status', ['pending', 'queued', 'retry_wait'])
                        ->where(function ($query) use ($now): void {
                            $query->whereNull('available_at')->orWhere('available_at', '<=', $now);
                        });
                })->orWhere(function ($query) use ($now): void {
                    $query->where('status', 'processing')
                        ->where(function ($query) use ($now): void {
                            $query->whereNull('lease_expires_at')->orWhere('lease_expires_at', '<=', $now);
                        });
                });
            })
            ->where(function ($query) use ($now): void {
                $query->whereNull('lease_token')->orWhere('lease_expires_at', '<=', $now);
            })
            ->update([
                'status' => 'processing',
                'lease_token' => $executionToken,
                'lease_owner' => substr($workerId, 0, 191),
                'lease_expires_at' => $expiresAt,
                'processing_started_at' => $now,
                'reserved_at' => $now,
                'attempt_count' => DB::raw('attempt_count + 1'),
                'claim_version' => DB::raw('claim_version + 1'),
                'updated_at' => $now,
            ]);

        if ($updated !== 1) {
            return null;
        }

        /** @var SignalDelivery|null $delivery */
        $delivery = SignalDelivery::query()->where('delivery_id', $deliveryId)->first();
        if ($delivery === null || ! hash_equals((string) $delivery->lease_token, $executionToken)) {
            return null;
        }

        return new SignalDeliveryLease(
            $deliveryId,
            $executionToken,
            (string) $delivery->lease_owner,
            (int) $delivery->claim_version,
            $this->toImmutable($delivery->processing_started_at),
            $this->toImmutable($delivery->lease_expires_at),
        );
    }

    public function markDelivered(SignalDeliveryLease $lease): bool
    {
        $now = now();
        return $this->ownedUpdate($lease, [
            'status' => 'delivered',
            'delivered_at' => $now,
            'available_at' => null,
            'lease_token' => null,
            'lease_owner' => null,
            'lease_expires_at' => null,
            'reserved_at' => null,
            'last_error_class' => null,
            'last_error' => null,
            'updated_at' => $now,
        ], true);
    }

    public function markRetry(
        SignalDeliveryLease $lease,
        DateTimeInterface $availableAt,
        ?string $errorClass = null,
        ?string $errorReference = null,
    ): bool {
        $now = now();
        return $this->ownedUpdate($lease, [
            'status' => 'retry_wait',
            'available_at' => $availableAt,
            'lease_token' => null,
            'lease_owner' => null,
            'lease_expires_at' => null,
            'reserved_at' => null,
            'last_error_class' => $errorClass,
            'last_error' => $errorReference === null ? null : substr($errorReference, 0, 2000),
            'updated_at' => $now,
        ], true);
    }

    public function markDeadLetter(SignalDeliveryLease $lease, string $errorClass, string $errorReference): bool
    {
        $now = now();
        return $this->ownedUpdate($lease, [
            'status' => 'dead_letter',
            'dead_lettered_at' => $now,
            'dead_letter_resolved_at' => null,
            'available_at' => null,
            'lease_token' => null,
            'lease_owner' => null,
            'lease_expires_at' => null,
            'reserved_at' => null,
            'last_error_class' => substr($errorClass, 0, 255),
            'last_error' => substr($errorReference, 0, 2000),
            'updated_at' => $now,
        ], true);
    }

    public function releaseExpired(string $deliveryId): bool
    {
        $now = now();
        return SignalDelivery::query()
            ->where('delivery_id', $deliveryId)
            ->where('status', 'processing')
            ->where(function ($query) use ($now): void {
                $query->whereNull('lease_expires_at')->orWhere('lease_expires_at', '<=', $now);
            })
            ->update([
                'status' => 'retry_wait',
                'available_at' => $now,
                'lease_token' => null,
                'lease_owner' => null,
                'lease_expires_at' => null,
                'reserved_at' => null,
                'updated_at' => $now,
            ]) === 1;
    }

    /** @param array<string,mixed> $attributes */
    private function ownedUpdate(SignalDeliveryLease $lease, array $attributes, bool $mustBeUnexpired): bool
    {
        $query = SignalDelivery::query()
            ->where('delivery_id', $lease->deliveryId)
            ->where('status', 'processing')
            ->where('lease_token', $lease->token)
            ->where('lease_owner', $lease->workerId)
            ->where('claim_version', $lease->claimVersion);

        if ($mustBeUnexpired) {
            $query->where('lease_expires_at', '>', now());
        }

        return $query->update($attributes) === 1;
    }

    private function toImmutable(mixed $value): DateTimeImmutable
    {
        if ($value instanceof DateTimeInterface) {
            return new DateTimeImmutable($value->format(DATE_ATOM));
        }
        return new DateTimeImmutable((string) $value, new DateTimeZone('UTC'));
    }
}
