<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface TitanAiRuntimeBridgeContract
{
    /** Deterministic runtime availability/identity only. This bridge never mints autonomy approval. */
    public function status(): array;
}
