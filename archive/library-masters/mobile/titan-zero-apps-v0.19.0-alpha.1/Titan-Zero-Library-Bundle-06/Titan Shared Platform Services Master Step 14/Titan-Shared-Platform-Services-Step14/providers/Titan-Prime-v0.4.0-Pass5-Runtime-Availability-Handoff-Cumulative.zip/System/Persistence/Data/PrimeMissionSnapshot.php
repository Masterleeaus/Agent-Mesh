<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Persistence\Data;

use App\Extensions\TitanPrime\System\Domain\Entities\PrimeMission;
use InvalidArgumentException;

final readonly class PrimeMissionSnapshot
{
    public function __construct(
        public PrimeMission $mission,
        public int $version,
    ) {
        if ($version < 1) {
            throw new InvalidArgumentException('Mission persistence version must be at least 1.');
        }
    }
}
