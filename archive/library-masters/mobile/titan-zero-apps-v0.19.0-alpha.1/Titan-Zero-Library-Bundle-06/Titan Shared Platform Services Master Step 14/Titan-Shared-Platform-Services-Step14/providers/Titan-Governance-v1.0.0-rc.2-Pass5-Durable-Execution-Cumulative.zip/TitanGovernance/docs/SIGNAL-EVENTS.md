# Signal Events

Governance is `signal-aware` and propagates trace_id, correlation_id, causation_id and root_causation_id. Current declared event: `titan-governance.read.completed` v1.0. Sensitive authentication/token/secret/signature fields are forbidden from Signal payloads.
