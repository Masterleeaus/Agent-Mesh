# MagicAI CRM v0.9.0 — Huge Pre-Install Pass

## Status

v0.9.0 remains a clean-room, standalone recreation of the MagicAI `crm` extension contract. WorkCore continues to be donor/reference material only; the runtime contains no `App\Domains\WorkCore` namespace dependency and no `tz_*` table dependency.

This pass concentrated on integrations, privacy, record sharing, customer file exchange, outbound security and release engineering that can be completed before any installation into a live MagicAI database.

## Added or deepened

### Customer portal file exchange
- Private Laravel filesystem storage; no public-path storage.
- SHA-256 file journal.
- server-derived MIME policy and size limit.
- random opaque storage names.
- grant-scoped listing/download access.
- pluggable `CrmPortalFileScanner` contract.
- optional fail-closed scanner requirement through `CRM_PORTAL_REQUIRE_SCANNER`.

### External CRM API
- random API keys returned only once.
- SHA-256 hash stored at rest.
- explicit scopes, expiry, revocation and last-used timestamp.
- management responses redact the stored key hash.
- public integration API remains read-only in v0.9.

### Webhooks
- encrypted webhook secrets.
- SHA-256 HMAC signatures.
- HTTPS-only target policy.
- embedded credentials, localhost, private/reserved IPs and disallowed ports rejected.
- DNS A/AAAA resolution is revalidated at delivery time.
- redirects are disabled.
- delivery journal, bounded exponential retries and dead-letter state.
- `crm:webhooks:retry` maintenance command.

### Email sync foundation
- connection records store only opaque credential references.
- external message IDs are deduplicated per connection.
- inbound/outbound address normalisation.
- messages can link to contacts, companies and leads.
- linked email messages are included in CRM timelines.

No Gmail/Outlook OAuth transport is claimed here; v0.9 defines the safe CRM-side persistence and linking contract for those future host adapters.

### Record sharing
- owner-created, expiring, revocable shares.
- scoped `view`, `comment`, `edit` metadata.
- restricted supported CRM subject types.
- shared-record receiver list and record view.
- comments are written into the record owner's CRM note stream only when `comment` was explicitly granted.

`edit` remains reserved for a later, carefully scoped mutation layer; v0.9 does not expose arbitrary shared-record editing.

### Privacy and retention
- privacy requests support export, anonymize and soft-delete planning.
- dry-run remains the default.
- sensitive plan/result journals are encrypted at rest.
- management lists redact encrypted plan/result material.
- retention policies support contacts, leads, activities and email messages.
- destructive retention execution requires explicit confirmation and is capped to 500 records per call.
- `crm:retention:run` defaults to safe review behaviour unless `--confirm-destructive` is supplied.

### Import safety
- CSV parsing and mapping registry.
- bounded imports.
- UTF-8 handling.
- spreadsheet formula prefix neutralisation for `=`, `+`, `-` and `@` cells.
- transform catalogue for trim/case/email/phone/boolean/date/static mapping.

### Permissions
Browser and authenticated internal API routes now carry granular gates for leads, pipelines, deals, timeline, projects, tasks, calendar, import/export/rollback, duplicates, bulk actions, metadata, automations, portal administration, integrations, privacy, sharing, reports and Sales mutations.

### Analytics and AI
Advanced CRM analytics now include source conversion, pipeline staleness, stage velocity and average won-deal sales-cycle days. The AI Agent companion gains safe read tools for follow-ups, forecast, duplicates, source conversion and stale pipeline while security/privacy/integration administration remains unavailable to generic agents.

## Release engineering
- `crm` and `ai-agent-tool-crm` remain separate MagicAI Marketplace extensions.
- both retain exact provider/slug identities expected by MagicAI 11.
- migration verifier confirms 43 owned CRM tables have matching drop paths and no duplicate create declarations.
- per-extension SHA-256 file manifests are regenerated for v0.9.
- each extension's `bin/verify.php` verifies its compatibility contract and file hashes.
- Marketplace archives are built with extension contents at ZIP root, matching MagicAI's real extraction behaviour.

## Security decisions intentionally retained
- no arbitrary AI deletes, merges, privacy actions, API-key creation or webhook creation.
- public API remains read-only.
- webhook redirects are prohibited.
- customer portal tokens and API keys remain hash-only at rest.
- webhook secrets and privacy journals are encrypted.
- portal storage remains private.
- retention delete remains soft delete.

## Still deliberately awaiting runtime installation
The following cannot be honestly certified until a runnable MagicAI installation with Composer dependencies and a test database is available:
- Laravel service-container boot.
- actual migration execution/rollback against MySQL/PostgreSQL.
- route enumeration through `artisan route:list`.
- browser CSRF/session behaviour.
- Passport request execution.
- real PDF rendering and mail transport.
- real Google/Gmail/Outlook connector transport.
- outbound webhook network behaviour.
- actual malware-scanner adapter.
- end-to-end CRM Assistant and AI Agent execution inside MagicAI.

These are runtime-certification items, not missing source scaffolding.
