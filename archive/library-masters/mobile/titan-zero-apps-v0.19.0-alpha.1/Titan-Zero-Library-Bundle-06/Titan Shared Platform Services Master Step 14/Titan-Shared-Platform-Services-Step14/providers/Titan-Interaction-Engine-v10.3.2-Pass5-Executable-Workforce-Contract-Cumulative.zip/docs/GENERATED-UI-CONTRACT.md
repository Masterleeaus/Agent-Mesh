# Generated UI Contract

The canonical presentation envelope exposes interaction_id, wizard_id, session_id, step_id, title, prompt, description, input_type, options, validation, ui_hint, help_text, progress, actions, requires_online, offline_mode, authority_state and surface. Voice, chat and form inputs normalize into the same WizardSession; presentation components remain surface-owned.
