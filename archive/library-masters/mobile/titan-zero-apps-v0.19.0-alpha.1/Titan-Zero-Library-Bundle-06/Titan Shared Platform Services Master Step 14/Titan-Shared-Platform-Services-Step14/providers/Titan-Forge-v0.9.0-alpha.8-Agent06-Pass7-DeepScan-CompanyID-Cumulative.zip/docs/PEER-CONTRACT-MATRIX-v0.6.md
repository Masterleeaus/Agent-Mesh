# Titan Forge v0.6 — Verified Peer Contract Matrix

This matrix records the public contracts verified before Forge binds optional Titan engine adapters. Forge uses peer contracts through lazy adapters; it does not import peer persistence or internal services.

| Engine | Verified package | Public contract used by Forge | Forge v0.6 treatment |
|---|---|---|---|
| Titan Signal Engine | v0.2.0 Pass 1 Foundation | `SignalEmitterContract::emit(SignalEnvelope|array): SignalReceipt` | Active optional lifecycle adapter. Emits tenant-scoped Forge lifecycle facts with full trace lineage and event-specific idempotency. |
| Titan Risk Engine | v0.2.1 Pass 2A | `RiskGateContract::evaluate(RiskContextInput): RiskGateResult` | Active optional release-risk adapter. `DENY` rejects; hold directives block progression; levels normalize into Forge low/medium/high/critical. |
| Titan Shield | v0.3.0 Inspection Foundation | `ShieldManagerContract::health()` and `determineGovernanceResponse(...)` | Active optional governance-response adapter. Forge remains owner of code/static validation; Shield governs the resulting Forge findings. |
| Titan Model Council | v0.5.0 Pass 4 AI Core/Risk | `CouncilGatewayContract::health()` and `decideActivation(CouncilRequest)` | High/critical risk activation assessment only. Current peer health reports `governed_deliberation=false`, so activation cannot clear a high-risk release. |
| Titan Governance | v0.1.0 Scaffold | `GovernanceManagerContract::health()` only | No release-decision API exists. Forge fails closed with `health_only_contract`. |
| Titan Command Bus | v0.1.0 Scaffold | `CommandBusContract::health()` only | No dispatch/execute API exists. Forge fails closed with `health_only_contract`; no production release command is fabricated. |

## Ownership rules

- Forge creates and validates **release candidates**; it does not install or deploy them.
- Local Forge validators remain authoritative for generated-artifact syntax, archive and static-security checks.
- Shield may govern findings, but Forge does not claim Shield performs source-code validation it does not expose.
- Risk is evaluated before any candidate could become executable.
- Council activation metadata is advisory until Council exposes governed deliberation completion.
- Governance must provide an explicit decision contract before a candidate may advance past its governance hold.
- Command Bus must provide a governed dispatch contract before Forge can submit a production release intent.
