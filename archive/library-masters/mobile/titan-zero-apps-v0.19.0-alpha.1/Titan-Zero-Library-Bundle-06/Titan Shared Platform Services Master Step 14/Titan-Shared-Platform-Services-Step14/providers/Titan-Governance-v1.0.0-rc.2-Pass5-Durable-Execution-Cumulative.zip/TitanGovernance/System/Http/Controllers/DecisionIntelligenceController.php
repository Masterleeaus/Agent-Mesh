<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Http\Controllers;

use App\Extensions\TitanGovernance\System\Context\TenantCompanyResolver;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceManagerContract;
use App\Extensions\TitanGovernance\System\Host\TitanHostAuthorizationAdapter;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

final class DecisionIntelligenceController
{
    public function __construct(private readonly GovernanceManagerContract $governance,private readonly TenantCompanyResolver $tenants,private readonly TitanHostAuthorizationAdapter $authorization){}

    public function show(Request $request,string $decisionId):View
    {
        $tenant=$this->tenant($request);$detail=$this->governance->decisionDetail($tenant,$this->decisionId($decisionId));
        abort_if(($detail['status']??null)==='NOT_FOUND',404);
        return view('titan-governance::decision',['tenantCompanyId'=>$tenant,'detail'=>$detail,'recentDecisions'=>$this->governance->recentDecisions($tenant,50),'deltaResult'=>session('governance_delta_result')]);
    }
    public function timeline(Request $request,string $decisionId):JsonResponse{return response()->json($this->governance->decisionTimeline($this->tenant($request),$this->decisionId($decisionId)));}
    public function rewind(Request $request,string $decisionId):JsonResponse{return response()->json($this->governance->rewindTheater($this->tenant($request),$this->decisionId($decisionId)));}
    public function compliance(Request $request,string $decisionId):JsonResponse{return response()->json($this->governance->decisionCompliance($this->tenant($request),$this->decisionId($decisionId)));}

    public function delta(Request $request):JsonResponse|RedirectResponse
    {
        $tenant=$this->tenant($request);$left=$this->decisionId((string)$request->input('left_decision_id',''));$right=$this->decisionId((string)$request->input('right_decision_id',''));
        $result=$this->governance->decisionDelta($tenant,$left,$right);
        if($request->expectsJson()) return response()->json($result,($result['status']??null)==='NOT_FOUND'?404:200);
        return redirect()->back()->with('governance_delta_result',$result);
    }

    private function tenant(Request $request):int
    {
        $user=$request->user();abort_unless($user&&$this->authorization->allows($user,'titan-governance.view',['titan-governance.view']),403);return $this->tenants->resolve($user);
    }
    private function decisionId(string $value):string
    {
        $value=trim($value);abort_unless($value!==''&&strlen($value)<=80&&preg_match('/^[A-Za-z0-9_.:-]+$/',$value)===1,422);return $value;
    }
}
