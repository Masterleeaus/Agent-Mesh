<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Http\Middleware;

use App\Extensions\TitanAICore\System\Contracts\TrustedPrincipalResolverContract;
use App\Extensions\TitanAICore\System\DTO\TrustedPrincipal;
use App\Extensions\TitanAICore\System\Exceptions\SecurityContextException;
use App\Extensions\TitanAICore\System\Security\CapabilityAuthorizer;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class RequireCoreCapability
{
    public function __construct(
        private readonly CapabilityAuthorizer $authorizer,
        private readonly TrustedPrincipalResolverContract $resolver,
    ) {}

    public function handle(Request $request, Closure $next, string $capability): Response
    {
        $principal = $request->attributes->get('titan_ai_core.principal');
        if (!$principal instanceof TrustedPrincipal) {
            $user = $request->user();
            if (!is_object($user)) {
                abort(401, 'Authentication required.');
            }
            $principal = $this->resolver->resolve($user);
        }

        try {
            $this->authorizer->assertAllowed($principal->toActorContext(), $capability);
        } catch (SecurityContextException $exception) {
            abort(403, $exception->securityCode);
        }

        return $next($request);
    }
}
