<?php
namespace App\Extensions\Crm\System\AI;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
final class CrmContextProvider { public function forUser(int $userId): array { return ['company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'source'=>'crm','trust'=>'authoritative_application_data']; } }
