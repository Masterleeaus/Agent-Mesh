<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanSignalEngine\System\Data\SignalSubscriptionDefinition;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

final class SignalSubscriptionDefinitionTest extends TestCase
{
    public function test_subscription_filters_event_schema_scope_category_and_vertical(): void
    {
        $definition = SignalSubscriptionDefinition::fromArray([
            'subscriber_key' => 'titan-risk',
            'handler_class' => self::class,
            'event_patterns' => ['command.*', 'job.completed'],
            'accepted_schema_versions' => [1, 2],
            'scopes' => ['tenant'],
            'categories' => ['risk'],
            'verticals' => ['cleaning'],
        ]);

        self::assertTrue($definition->matches('command.executed', 1, 'tenant', 'risk', 'cleaning'));
        self::assertFalse($definition->matches('command.executed', 3, 'tenant', 'risk', 'cleaning'));
        self::assertFalse($definition->matches('command.executed', 1, 'system', 'risk', 'cleaning'));
        self::assertFalse($definition->matches('command.executed', 1, 'tenant', 'finance', 'cleaning'));
    }

    public function test_unrestricted_wildcard_is_forbidden(): void
    {
        $this->expectException(InvalidArgumentException::class);
        SignalSubscriptionDefinition::fromArray([
            'subscriber_key' => 'unsafe',
            'handler_class' => self::class,
            'event_patterns' => ['*'],
            'accepted_schema_versions' => [1],
        ]);
    }
}
