# Titan Rewind Retention

Titan Rewind uses bounded, resumable, legal-hold-aware retention. It never performs an unrestricted table truncate.

## Default classes

| Class | Default | Typical data |
|---|---:|---|
| ephemeral | 30 days | replay runs, telemetry, delivered Signal outbox, resolved dead letters |
| operational | 90 days | timeline projections, integrity checks, resolved drift findings |
| forensic | 365 days | snapshots and dependency projections |
| evidence | 2555 days | signed evidence packages and encrypted historical artifacts |
| preserve | indefinite | trace event ledger, custody, legal holds, signing-key metadata, Governance/recovery authority records, purge runs/receipts |

All day counts are configurable using `TITAN_REWIND_RETENTION_*_DAYS` environment variables.

## Execution

The command `php artisan titan-rewind:retention` runs one bounded batch per discovered tenant and retention class. Optional `--tenant`, `--class`, and `--batch` arguments narrow the run. The extension schedules the command daily at the configured `TITAN_REWIND_RETENTION_SCHEDULE_AT` time using one-server and overlap protection.

Every run is resumable through an active-run key and cursor. Every batch is atomic: custody action, deletion, purge receipt and cursor advancement either commit together or roll back together.

## Holds and references

Active non-expired legal holds override retention. Case and evidence-package holds cascade to their linked traces. Evidence packages referenced by Governance receipts are reference-protected from automated deletion.
