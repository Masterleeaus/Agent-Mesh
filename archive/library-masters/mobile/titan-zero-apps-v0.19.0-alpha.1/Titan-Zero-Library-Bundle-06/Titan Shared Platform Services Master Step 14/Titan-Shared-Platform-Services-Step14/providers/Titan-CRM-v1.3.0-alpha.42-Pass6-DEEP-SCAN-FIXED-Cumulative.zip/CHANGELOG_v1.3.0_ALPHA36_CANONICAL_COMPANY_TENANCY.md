# Titan CRM Core v1.3.0-alpha.36 — Canonical Company Tenancy

## Purpose

Correct CRM Core's tenant boundary to the Titan host convention: **`company_id` is the canonical CRM tenant key**. `tenant_company_id` is retained only inside historical migrations long enough to upgrade existing installations safely.

## Changed

- Converted authoritative CRM runtime scopes, contexts, repositories, services, read models, commands, resources and contracts to `company_id`.
- Added forward migration `2026_08_18_000045_canonical_company_tenancy.php` rather than rewriting already-applied migration history.
- Renamed the CRM customer/organisation relationship on contacts and deals from the conflicting `company_id` field to `customer_company_id` before the tenant column conversion.
- Removed direct request control of contact tenant identity; customer-company association resolves through the CRM company public identifier.
- Backfills deterministic company IDs from the Titan `users.company_id` context and pipeline-stage parent ownership, then fails closed if a CRM Core row cannot be assigned a company.
- Makes canonical CRM Core `company_id` columns non-null after successful backfill.
- Restricts the conversion map to CRM Core-owned tables; extracted Titan Field, Locker, Ledger, Pay and historical Autonomy tables are not renamed by CRM Core.
- External-owned write capabilities no longer run CRM Core table-level reference, invariant or optimistic-concurrency guards before delegation; those storage checks remain the responsibility of the owning extension while CRM preserves authorization, idempotency, receipts and audit evidence.
- Legacy compatibility reads now fail closed with a clear owner-boundary error unless the destination table exposes canonical `company_id`, avoiding accidental queries against stale extracted schemas.

## Multi-user correctness

Company-level unique records no longer include actor `user_id` in `updateOrInsert()` identity keys. Settings, email connections, custom-field values, tag attachments, record shares and retention policies now use company-level identity while retaining actor provenance separately.

## Pipeline integrity

- Default and custom pipeline-stage writes stamp `company_id`.
- Pipeline-stage reads are explicitly company scoped.
- Existing stage ownership can be repaired from the parent pipeline during migration.

## Installer and navigation hardening

- Historical sales-lifecycle migration now guards tables extracted from CRM Core, including the removed local `crm_payments` table, so fresh installation does not fail when those domains are absent.
- CRM menu installation now has an explicit retired-key registry and deactivates 40 known historical CRM navigation rows from Field, Crew, Gear/Locker, Pay, bookkeeping/collections and Autonomy while preserving the current CRM admin settings route.
- Current CRM menu icons are explicitly host-safe instead of silently falling back to the generic icon.

## Production permission gate

Runtime compatibility remains non-strict by default because existing Titan hosts may not yet register CRM Laravel Gates. `crm:production-check` now treats disabled strict host permission gates as a **BLOCK**, preventing the host from being certified production-ready until CRM permissions are registered and strict enforcement is enabled.

## Verification

`bin/verify-v130-alpha36-company-tenancy.php` covers canonical tenancy, relationship separation, pipeline ownership, multi-user company uniqueness, menu retirement, fresh-install guards and the production permission gate. The master verifier includes this alpha.36 gate.

## Installer 1.7.8 manifest hotfix

- Corrected root `extension.json` `optional_dependencies` from an associative slug/version map to the Installer 1.7.8 dependency-array contract: each entry is an object containing `slug` and `version`.
- Normalized empty root `dependencies` to a JSON array.
- Added `tests/InstallerManifestContractTest.php` so future CRM packages fail verification if either dependency collection regresses to the rejected shape.
- No CRM runtime, migration, tenancy, route, menu, or database behavior changed in this packaging hotfix.
