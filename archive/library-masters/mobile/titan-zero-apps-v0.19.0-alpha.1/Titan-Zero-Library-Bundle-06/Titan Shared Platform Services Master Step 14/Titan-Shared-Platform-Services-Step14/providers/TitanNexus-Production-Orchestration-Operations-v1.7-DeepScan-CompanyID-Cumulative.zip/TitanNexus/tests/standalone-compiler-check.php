<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Adapters\VerticalEngine\VerticalEngineAdapter;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Services\DeterministicNexusCompiler;

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
$files = [
    '/System/Support/CanonicalJson.php',
    '/System/Support/DeterministicMerge.php',
    '/System/Domain/BusinessProfile.php',
    '/System/Domain/CompiledTitanConfig.php',
    '/System/Domain/VerticalDefinition.php',
    '/System/Contracts/NexusCompilerContract.php',
    '/System/Contracts/VerticalDefinitionSourceContract.php',
    '/System/Services/DeterministicNexusCompiler.php',
    '/System/Adapters/VerticalEngine/VerticalEngineAdapter.php',
];

foreach ($files as $file) {
    $path = $root . $file;
    if (!is_file($path)) {
        fwrite(STDERR, "FAIL: missing compiler production class file {$file}\n");
        exit(1);
    }
    require_once $path;
}

function compilerCheck(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

function compilerInvalid(callable $callback, string $message): void
{
    try {
        $callback();
    } catch (InvalidArgumentException|RuntimeException) {
        return;
    }
    fwrite(STDERR, "FAIL: expected fail-closed exception: {$message}\n");
    exit(1);
}

$profile = BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '2.0.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
    'timezone' => 'Australia/Melbourne',
    'sections' => [
        'operations' => [
            'evidence' => ['photos'],
            'job_statuses' => ['booked', 'active', 'complete'],
        ],
        'billing' => ['currency' => 'AUD'],
    ],
]);

$definitionA = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => [
        'billing' => ['currency' => 'USD', 'tax_mode' => 'exclusive'],
        'operations' => [
            'evidence' => ['photos', 'signature'],
            'job_statuses' => ['scheduled', 'in_progress', 'complete'],
            'recurring' => true,
        ],
    ],
]);
$definitionB = VerticalDefinition::fromArray([
    'sections' => [
        'operations' => [
            'recurring' => true,
            'job_statuses' => ['scheduled', 'in_progress', 'complete'],
            'evidence' => ['photos', 'signature'],
        ],
        'billing' => ['tax_mode' => 'exclusive', 'currency' => 'USD'],
    ],
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'vertical_version' => '2026.08',
    'vertical_id' => 'cleaning',
]);
compilerCheck($definitionA->fingerprint() === $definitionB->fingerprint(), 'vertical definition hash is canonical');

$compiler = new DeterministicNexusCompiler('0.3.0');
$configA = $compiler->compile($profile, $definitionA, '1');
$configB = $compiler->compile($profile, $definitionB, '1');
compilerCheck($configA->outputHash() === $configB->outputHash(), 'same semantic inputs produce same compiled output');
compilerCheck($configA->sections()['billing']['currency'] === 'AUD', 'business scalar override wins');
compilerCheck($configA->sections()['billing']['tax_mode'] === 'exclusive', 'vertical default survives when not overridden');
compilerCheck($configA->sections()['operations']['recurring'] === true, 'nested vertical default survives');
compilerCheck($configA->sections()['operations']['evidence'] === ['photos'], 'business list replaces vertical list atomically');
compilerCheck($configA->knowledgeSnapshotVersion() === 'au-vic-2026.08', 'knowledge snapshot provenance is preserved');
compilerCheck($configA->sourceProfileHash() === $profile->fingerprint(), 'profile provenance hash is preserved');
compilerCheck($configA->sourceVerticalHash() === $definitionA->fingerprint(), 'vertical definition provenance hash is preserved');

$emptyOverrideProfile = BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '2.0.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
    'timezone' => 'Australia/Melbourne',
    'sections' => [],
]);
$emptyOverrideConfig = $compiler->compile($emptyOverrideProfile, $definitionA, '1');
compilerCheck(isset($emptyOverrideConfig->sections()['operations']['recurring']), 'empty business sections preserve vertical defaults');

$wrongVertical = VerticalDefinition::fromArray([
    'vertical_id' => 'plumbing',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => null,
    'sections' => [],
]);
compilerInvalid(static fn () => $compiler->compile($profile, $wrongVertical, '1'), 'compiler must reject a different vertical id');

$wrongVersion = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.09',
    'knowledge_snapshot_version' => null,
    'sections' => [],
]);
compilerInvalid(static fn () => $compiler->compile($profile, $wrongVersion, '1'), 'compiler must reject a different vertical version');

$adapter = new VerticalEngineAdapter(static fn (array $input): array => [
    'vertical_id' => $input['vertical_id'],
    'vertical_version' => $input['vertical_version'],
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => ['operations' => ['recurring' => true]],
]);
$resolved = $adapter->resolve($profile);
compilerCheck($resolved->verticalId() === 'cleaning', 'adapter resolves the requested vertical');
compilerCheck($resolved->verticalVersion() === '2026.08', 'adapter resolves the exact requested version');

$driftAdapter = new VerticalEngineAdapter(static fn (array $input): array => [
    'vertical_id' => 'plumbing',
    'vertical_version' => $input['vertical_version'],
    'knowledge_snapshot_version' => null,
    'sections' => [],
]);
compilerInvalid(static fn () => $driftAdapter->resolve($profile), 'adapter must reject vertical identity drift');

$malformedAdapter = new VerticalEngineAdapter(static fn (array $input): string => 'bad');
compilerInvalid(static fn () => $malformedAdapter->resolve($profile), 'adapter must reject malformed upstream definition');

fwrite(STDOUT, "PASS: Titan Nexus standalone compiler checks\n");
