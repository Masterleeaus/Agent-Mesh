<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Contracts\RewindEvidenceSignerContract;
use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use InvalidArgumentException;

final class RewindEvidenceStreamService
{
    public function __construct(private RewindEvidenceSignerContract $signer) {}

    /** @return iterable<string> */
    public function chunks(RewindEvidencePackage $package, bool $compliance = false, int $chunkSize = 65536): iterable
    {
        if ($chunkSize < 1024 || $chunkSize > 1048576) {
            throw new InvalidArgumentException('Titan Rewind evidence stream chunk size must be between 1024 and 1048576 bytes.');
        }

        $payload = (string) $package->payload_json;
        $manifest = is_array($package->manifest) ? $package->manifest : [];
        $schemaVersion = (int) ($manifest['schema_version'] ?? 0);
        if ($schemaVersion < 2) {
            throw new InvalidArgumentException('Titan Rewind streamed evidence export requires evidence schema version 2 or newer.');
        }
        if (!hash_equals((string) $package->content_hash, hash('sha256', $payload))) {
            throw new InvalidArgumentException('Titan Rewind evidence package content hash verification failed.');
        }
        if (!hash_equals((string) ($manifest['content_hash'] ?? ''), (string) $package->content_hash)) {
            throw new InvalidArgumentException('Titan Rewind evidence manifest hash does not match the stored package hash.');
        }
        if (!$this->signer->verify((string) $package->content_hash, (string) $package->signature, (string) $package->signature_key_id)) {
            throw new InvalidArgumentException('Titan Rewind evidence package signature verification failed.');
        }

        $head = [
            'format' => $compliance ? 'titan-rewind-compliance-evidence-v2' : 'titan-rewind-evidence-v2',
            'package_uuid' => (string) $package->package_uuid,
            'scope' => ['type' => (string) $package->scope_type, 'id' => (string) $package->scope_id],
            'content_hash' => (string) $package->content_hash,
            'verified' => true,
            'signature_verified' => true,
            'signature' => [
                'algorithm' => (string) $package->signature_algorithm,
                'key_id' => (string) $package->signature_key_id,
            ],
            'manifest' => $manifest,
        ];
        $encoded = json_encode($head, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        yield substr($encoded, 0, -1) . ',"payload":';
        $length = strlen($payload);
        for ($offset = 0; $offset < $length; $offset += $chunkSize) {
            yield substr($payload, $offset, $chunkSize);
        }
        yield '}';
    }
}
