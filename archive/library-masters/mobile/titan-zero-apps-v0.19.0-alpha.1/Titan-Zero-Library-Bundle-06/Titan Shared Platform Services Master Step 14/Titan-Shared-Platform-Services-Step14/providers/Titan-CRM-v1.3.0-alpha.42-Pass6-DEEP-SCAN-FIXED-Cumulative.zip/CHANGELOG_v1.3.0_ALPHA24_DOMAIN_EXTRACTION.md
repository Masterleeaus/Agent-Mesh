# CRM v1.3.0-alpha.24 — Domain Extraction

Extracts Field, Locker, Ledger and Pay implementation ownership into dedicated Titan extensions while preserving `crm.*` compatibility contracts and historical data/table names.
