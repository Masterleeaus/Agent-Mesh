<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

use RuntimeException;

final class CrmConcurrencyException extends RuntimeException
{
    public function __construct(
        public readonly ?int $expectedVersion,
        public readonly int $currentVersion,
        public readonly ?string $currentStateHash,
        public readonly bool $retryable=true,
        public readonly string $remediationSuggestion='Fetch the latest CRM state and retry using its entity_version.',
    ) {
        parent::__construct('Stale CRM mutation rejected: expected_version='.(string)($expectedVersion??'none')." current_version={$currentVersion}.");
    }

    /** @return array<string,mixed> */
    public function context(): array
    {
        return [
            'expected_version'=>$this->expectedVersion,
            'current_version'=>$this->currentVersion,
            'current_state_hash'=>$this->currentStateHash,
            'retryable'=>$this->retryable,
            'remediation_suggestion'=>$this->remediationSuggestion,
        ];
    }
}
