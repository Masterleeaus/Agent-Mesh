<?php

declare(strict_types=1);

$servicePath = __DIR__ . '/../System/Compatibility/Legacy/Services/ModelCouncilService.php';
$adapterPath = __DIR__ . '/../System/Compatibility/Legacy/LegacyCouncilAdapter.php';
$modelPath = __DIR__ . '/../System/Compatibility/Legacy/Models/ModelCouncilResponse.php';

foreach ([$servicePath, $adapterPath, $modelPath] as $path) {
    if (! is_file($path)) {
        fwrite(STDERR, "FAIL: missing active legacy compatibility file: {$path}\n");
        exit(1);
    }
}

$service = file_get_contents($servicePath);
if (! str_contains($service, 'namespace App\\Extensions\\TitanModelCouncil\\System\\Compatibility\\Legacy\\Services;')) {
    fwrite(STDERR, "FAIL: legacy service was not moved behind Titan namespace\n");
    exit(1);
}
if (str_contains($service, 'App\\Extensions\\ModelCouncil\\')) {
    fwrite(STDERR, "FAIL: active legacy service still imports old extension namespace\n");
    exit(1);
}
if (! str_contains($service, "MarketplaceHelper::isRegistered('titan-model-council')")) {
    fwrite(STDERR, "FAIL: active legacy service does not recognize Titan extension identity\n");
    exit(1);
}

$adapter = file_get_contents($adapterPath);
foreach (['generateCouncilResponse', 'streamCouncilResponse', 'streamCouncilSummaryFromShared'] as $method) {
    if (! str_contains($adapter, "function {$method}")) {
        fwrite(STDERR, "FAIL: compatibility adapter missing {$method}\n");
        exit(1);
    }
}

echo "pass2 legacy adapter checks passed\n";
