<?php

declare(strict_types=1);

use App\Extensions\Crm\System\Tenancy\CrmTenantTableMap;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('crm_tenancy_migration_reviews')) {
            Schema::create('crm_tenancy_migration_reviews', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->string('source_table', 120)->index();
                $t->unsignedBigInteger('source_record_id')->nullable()->index();
                $t->unsignedBigInteger('legacy_user_id')->nullable()->index();
                $t->string('reason', 80)->index();
                $t->json('candidate_company_ids')->nullable();
                $t->string('status', 30)->default('unresolved')->index();
                $t->text('notes')->nullable();
                $t->timestamps();
                $t->unique(['source_table','source_record_id','reason'], 'crm_tenancy_review_unique');
            });
        }

        // Key tenant-owned records include crm_companies, crm_contacts, crm_work_orders and crm_invoices.
        // CrmTenantTableMap contains the complete classified set; CRM account `company_id` is never repurposed.
        foreach (CrmTenantTableMap::TABLES as $table) {
            if (! Schema::hasTable($table) || Schema::hasColumn($table, 'tenant_company_id')) continue;
            Schema::table($table, function (Blueprint $t): void {
                // Additive + nullable so ambiguous 1.1 rows are never silently assigned.
                $t->unsignedBigInteger('tenant_company_id')->nullable()->index();
            });
        }

        $this->backfillDeterministicLegacyRows();
        $this->backfillPipelineStages();

        if (! Schema::hasTable('crm_capability_operations')) {
            Schema::create('crm_capability_operations', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('tenant_company_id')->index();
                $t->unsignedBigInteger('actor_user_id')->nullable()->index(); $t->string('actor_type',40)->default('user');
                $t->string('capability',160)->index(); $t->string('idempotency_key',190); $t->string('resource_type',80)->nullable()->index();
                $t->string('resource_id',190)->nullable()->index(); $t->string('source_surface',40)->default('api')->index();
                $t->string('status',30)->index(); $t->json('request_fingerprint')->nullable(); $t->json('result')->nullable();
                $t->string('correlation_id',80)->nullable()->index(); $t->timestamp('completed_at')->nullable(); $t->timestamps();
                $t->unique(['tenant_company_id','capability','idempotency_key'], 'crm_capability_company_idem_unique');
            });
        }

        $this->extendServiceCatalogueContract();
        $this->extendInvoiceAuthorityContract();

        if (! Schema::hasTable('crm_business_hours')) {
            Schema::create('crm_business_hours', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('tenant_company_id')->index();
                $t->unsignedTinyInteger('day_of_week')->index(); $t->unsignedTinyInteger('window_index')->default(0);
                $t->time('opens_at')->nullable(); $t->time('closes_at')->nullable(); $t->boolean('closed')->default(false);
                $t->string('timezone',80); $t->string('holiday_behavior',40)->default('closed');
                $t->boolean('after_hours_available')->default(false); $t->boolean('emergency_available')->default(false);
                $t->json('metadata')->nullable(); $t->timestamps();
                $t->unique(['tenant_company_id','day_of_week','window_index'], 'crm_business_hours_company_window_unique');
            });
        }

        if (! Schema::hasTable('crm_business_locations')) {
            Schema::create('crm_business_locations', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('tenant_company_id')->index();
                $t->string('name',180); $t->string('location_type',60)->default('operating_site')->index();
                $t->string('address_line_1',255)->nullable(); $t->string('address_line_2',255)->nullable();
                $t->string('suburb',120)->nullable(); $t->string('state',120)->nullable(); $t->string('postcode',30)->nullable();
                $t->string('country',2)->nullable(); $t->string('timezone',80); $t->boolean('primary')->default(false)->index();
                $t->boolean('active')->default(true)->index(); $t->json('metadata')->nullable(); $t->timestamps();
            });
        }

        if (! Schema::hasTable('crm_business_configuration_drafts')) {
            Schema::create('crm_business_configuration_drafts', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('tenant_company_id')->index();
                $t->unsignedBigInteger('created_by_user_id')->nullable()->index(); $t->string('source_surface',40)->default('onboarding');
                $t->string('status',30)->default('draft')->index(); $t->json('answers')->nullable(); $t->json('proposed_configuration');
                $t->json('validation_errors')->nullable(); $t->json('preview')->nullable(); $t->unsignedBigInteger('approved_by_user_id')->nullable();
                $t->timestamp('approved_at')->nullable(); $t->timestamp('materialised_at')->nullable(); $t->string('correlation_id',80)->nullable()->index();
                $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        // Contract tables are reversible. Existing 1.1 records are never destroyed.
        Schema::dropIfExists('crm_business_configuration_drafts');
        Schema::dropIfExists('crm_business_locations');
        Schema::dropIfExists('crm_business_hours');
        Schema::dropIfExists('crm_capability_operations');
        $this->rollbackInvoiceAuthorityContract();
        $this->rollbackServiceCatalogueContract();
        foreach (array_reverse(CrmTenantTableMap::TABLES) as $table) {
            if (Schema::hasTable($table) && Schema::hasColumn($table, 'tenant_company_id')) {
                Schema::table($table, function (Blueprint $t): void { $t->dropColumn('tenant_company_id'); });
            }
        }
        Schema::dropIfExists('crm_tenancy_migration_reviews');
    }

    private function extendServiceCatalogueContract(): void
    {
        if (! Schema::hasTable('crm_services')) return;
        Schema::table('crm_services', function (Blueprint $t): void {
            if (! Schema::hasColumn('crm_services','tax_behavior')) $t->string('tax_behavior',40)->default('default');
            if (! Schema::hasColumn('crm_services','booking_available')) $t->boolean('booking_available')->default(true)->index();
            if (! Schema::hasColumn('crm_services','required_skills')) $t->json('required_skills')->nullable();
            if (! Schema::hasColumn('crm_services','field_requirements')) $t->json('field_requirements')->nullable();
            if (! Schema::hasColumn('crm_services','evidence_requirements')) $t->json('evidence_requirements')->nullable();
            if (! Schema::hasColumn('crm_services','form_template_public_ids')) $t->json('form_template_public_ids')->nullable();
            if (! Schema::hasColumn('crm_services','recurring_eligible')) $t->boolean('recurring_eligible')->default(false)->index();
        });
    }

    private function extendInvoiceAuthorityContract(): void
    {
        if (! Schema::hasTable('crm_invoices')) return;
        Schema::table('crm_invoices', function (Blueprint $t): void {
            if (! Schema::hasColumn('crm_invoices','paid_minor')) $t->bigInteger('paid_minor')->default(0);
            if (! Schema::hasColumn('crm_invoices','payment_state')) $t->string('payment_state',40)->default('unpaid')->index();
            if (! Schema::hasColumn('crm_invoices','reconciliation_status')) $t->string('reconciliation_status',40)->default('unreconciled')->index();
            if (! Schema::hasColumn('crm_invoices','payment_references')) $t->json('payment_references')->nullable();
        });
        if (Schema::hasTable('crm_payments')) {
            Schema::table('crm_payments', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_payments','provider')) $t->string('provider',80)->nullable()->index();
                if (! Schema::hasColumn('crm_payments','provider_reference')) $t->string('provider_reference',190)->nullable()->index();
                if (! Schema::hasColumn('crm_payments','reconciliation_status')) $t->string('reconciliation_status',40)->default('unreconciled')->index();
                // Webhook/provider retries are idempotent per company + provider reference.
                $t->unique(['tenant_company_id','provider','provider_reference'], 'crm_payments_company_provider_ref_unique');
            });
        }
    }

    private function rollbackServiceCatalogueContract(): void
    {
        if (! Schema::hasTable('crm_services')) return;
        $columns=['tax_behavior','booking_available','required_skills','field_requirements','evidence_requirements','form_template_public_ids','recurring_eligible'];
        foreach ($columns as $column) if (Schema::hasColumn('crm_services',$column)) Schema::table('crm_services', fn(Blueprint $t) => $t->dropColumn($column));
    }

    private function rollbackInvoiceAuthorityContract(): void
    {
        if (Schema::hasTable('crm_invoices')) {
            foreach (['paid_minor','payment_state','reconciliation_status','payment_references'] as $column) if (Schema::hasColumn('crm_invoices',$column)) Schema::table('crm_invoices', fn(Blueprint $t) => $t->dropColumn($column));
        }
        if (Schema::hasTable('crm_payments')) {
            try { Schema::table('crm_payments', fn(Blueprint $t) => $t->dropUnique('crm_payments_company_provider_ref_unique')); } catch (\Throwable) {}
            foreach (['provider','provider_reference','reconciliation_status'] as $column) if (Schema::hasColumn('crm_payments',$column)) Schema::table('crm_payments', fn(Blueprint $t) => $t->dropColumn($column));
        }
    }

    /** Deterministic only: legacy user -> exactly one authenticated platform company. */
    private function backfillDeterministicLegacyRows(): void
    {
        $legacyUsers = collect();
        foreach (CrmTenantTableMap::TABLES as $table) {
            if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'user_id')) continue;
            DB::table($table)->whereNull('tenant_company_id')->whereNotNull('user_id')->distinct()->pluck('user_id')->each(fn($id) => $legacyUsers->push((int)$id));
        }
        foreach ($legacyUsers->filter(fn($id)=>$id>0)->unique()->values() as $legacyUserId) {
            $companyIds = $this->companyCandidatesForUser((int)$legacyUserId);
            if (count($companyIds) === 1) {
                $companyId = $companyIds[0];
                foreach (CrmTenantTableMap::TABLES as $table) {
                    if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'user_id')) continue;
                    DB::table($table)->whereNull('tenant_company_id')->where('user_id', $legacyUserId)->update(['tenant_company_id'=>$companyId]);
                }
                continue;
            }
            $reason = $companyIds === [] ? 'missing_company_membership' : 'conflicting_company_membership';
            foreach (CrmTenantTableMap::TABLES as $table) {
                if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'user_id')) continue;
                DB::table($table)->whereNull('tenant_company_id')->where('user_id', $legacyUserId)->orderBy('id')->select('id')->chunkById(250, function ($rows) use ($table,$legacyUserId,$reason,$companyIds): void {
                    foreach ($rows as $row) {
                        DB::table('crm_tenancy_migration_reviews')->updateOrInsert(
                            ['source_table'=>$table,'source_record_id'=>$row->id,'reason'=>$reason],
                            ['public_id'=>(string)Str::ulid(),'legacy_user_id'=>$legacyUserId,'candidate_company_ids'=>json_encode($companyIds),'status'=>'unresolved','updated_at'=>now(),'created_at'=>now()]
                        );
                    }
                });
            }
        }
    }

    private function backfillPipelineStages(): void
    {
        if (! Schema::hasTable('crm_pipeline_stages') || ! Schema::hasTable('crm_pipelines')) return;
        DB::table('crm_pipeline_stages as s')->join('crm_pipelines as p','p.id','=','s.pipeline_id')
            ->whereNull('s.tenant_company_id')->whereNotNull('p.tenant_company_id')
            ->select('s.id','p.tenant_company_id')->orderBy('s.id')->chunk(250, function ($rows): void {
                foreach ($rows as $row) DB::table('crm_pipeline_stages')->where('id',$row->id)->update(['tenant_company_id'=>$row->tenant_company_id]);
            });
    }

    /** @return list<int> */
    private function companyCandidatesForUser(int $userId): array
    {
        $ids = [];
        $membership = trim((string) config('crm.tenancy.membership_table', ''));
        if ($membership !== '' && Schema::hasTable($membership)) {
            $u = (string) config('crm.tenancy.membership_user_column','user_id');
            $c = (string) config('crm.tenancy.membership_company_column','company_id');
            $ids = DB::table($membership)->where($u,$userId)->pluck($c)->filter(fn($v)=>is_numeric($v)&&(int)$v>0)->map(fn($v)=>(int)$v)->unique()->values()->all();
        }
        if ($ids === [] && Schema::hasTable((string)config('crm.tenancy.users_table','users'))) {
            $users = (string) config('crm.tenancy.users_table','users');
            foreach ((array) config('crm.tenancy.user_company_columns',['active_company_id','current_company_id','company_id']) as $column) {
                if (! Schema::hasColumn($users,(string)$column)) continue;
                $value = DB::table($users)->where('id',$userId)->value((string)$column);
                if (is_numeric($value) && (int)$value>0) $ids[]=(int)$value;
            }
        }
        $ids=array_values(array_unique($ids)); sort($ids); return $ids;
    }
};
