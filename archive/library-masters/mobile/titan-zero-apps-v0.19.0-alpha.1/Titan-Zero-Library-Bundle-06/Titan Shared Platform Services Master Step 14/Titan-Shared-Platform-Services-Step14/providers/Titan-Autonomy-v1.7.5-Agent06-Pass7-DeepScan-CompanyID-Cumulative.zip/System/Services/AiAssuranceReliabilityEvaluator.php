<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Enums\HandshakeDecision;

final class AiAssuranceReliabilityEvaluator
{
    /**
     * Inputs are deterministic/structured evidence prepared by platform services.
     * The LLM may contribute bounded signals, but it cannot mint approval by itself.
     *
     * @return array{decision:HandshakeDecision,confidence:float,reason_codes:array<int,string>}
     */
    public function evaluate(array $evidence): array
    {
        $reasons = [];
        foreach ([
            'sufficient_history' => 'INSUFFICIENT_HISTORY',
            'recent_reliability_ok' => 'RECENT_RELIABILITY_LOW',
            'correction_rate_ok' => 'RECENT_MATERIAL_CORRECTIONS',
            'failure_rate_ok' => 'FAILURE_RATE_TOO_HIGH',
            'reversal_rate_ok' => 'REVERSAL_RATE_TOO_HIGH',
            'context_stable' => 'UNSTABLE_CONTEXT',
            'data_complete' => 'INCOMPLETE_DATA',
            'integrations_healthy' => 'INTEGRATIONS_UNHEALTHY',
            'tool_model_reliable' => 'TOOL_MODEL_RELIABILITY_LOW',
            'in_distribution' => 'OUT_OF_DISTRIBUTION',
            'ambiguity_acceptable' => 'AMBIGUITY_TOO_HIGH',
        ] as $flag => $code) {
            if (($evidence[$flag] ?? false) !== true) {
                $reasons[] = $code;
            }
        }

        $assurance = strtoupper((string) ($evidence['assurance_status'] ?? 'RED'));
        if ($assurance === 'RED') $reasons[] = 'ASSURANCE_RED';
        if ($assurance === 'AMBER' && (($evidence['amber_mitigated'] ?? false) !== true)) {
            $reasons[] = 'ASSURANCE_AMBER_UNMITIGATED';
        }

        $confidence = max(0.0, min(1.0, (float) ($evidence['confidence'] ?? 0.0)));
        if (($evidence['confidence_threshold_met'] ?? false) !== true) {
            $reasons[] = 'CONFIDENCE_THRESHOLD_NOT_MET';
        }

        return [
            'decision' => $reasons === [] ? HandshakeDecision::Approved : HandshakeDecision::Denied,
            'confidence' => $confidence,
            'reason_codes' => array_values(array_unique($reasons)),
        ];
    }
}
