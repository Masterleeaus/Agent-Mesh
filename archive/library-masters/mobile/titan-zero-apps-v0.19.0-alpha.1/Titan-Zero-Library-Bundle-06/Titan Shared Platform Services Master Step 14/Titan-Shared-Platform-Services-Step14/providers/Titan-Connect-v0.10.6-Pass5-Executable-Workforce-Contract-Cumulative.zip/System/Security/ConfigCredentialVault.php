<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use App\Extensions\TitanConnect\System\Contracts\CredentialVault;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use RuntimeException;

final class ConfigCredentialVault implements CredentialVault
{
    public function credentials(int $companyId, ChannelConnection $connection): array
    {
        if ((int) $connection->company_id !== $companyId) {
            throw new RuntimeException('Channel connection company mismatch.');
        }

        $reference = trim((string) ($connection->credential_reference ?? ''));
        $base = "titan-connect.providers.{$connection->provider}";
        $credentials = $reference !== ''
            ? config("{$base}.credentials.{$reference}", [])
            : config("{$base}.credentials.default", []);

        if (! is_array($credentials)) {
            throw new RuntimeException('Messaging credentials could not be resolved.');
        }

        return $credentials;
    }
}
