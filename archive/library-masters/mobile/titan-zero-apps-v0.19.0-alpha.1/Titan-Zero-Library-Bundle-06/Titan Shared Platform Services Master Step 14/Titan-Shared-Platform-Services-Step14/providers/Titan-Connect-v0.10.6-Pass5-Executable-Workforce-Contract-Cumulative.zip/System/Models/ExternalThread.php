<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

final class ExternalThread extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use HasUuids;
    use SoftDeletes;

    protected $table = 'ext_titan_connect_external_threads';

    protected $fillable = [
        'uuid', 'company_id', 'channel_connection_id', 'provider', 'provider_thread_id',
        'external_contact_ref', 'external_contact_id', 'display_name', 'linked_entity_type', 'linked_entity_id',
        'status', 'assigned_user_id', 'pinned_rank', 'color', 'priority', 'metadata', 'last_message_at', 'closed_at',
    ];

    protected $casts = ['metadata' => 'array', 'last_message_at' => 'datetime', 'closed_at' => 'datetime'];

    public function uniqueIds(): array
    {
        return ['uuid'];
    }

    public function getRouteKeyName(): string
    {
        return 'uuid';
    }

    public function connection(): BelongsTo
    {
        return $this->belongsTo(ChannelConnection::class, 'channel_connection_id');
    }

    public function readStates(): HasMany
    {
        return $this->hasMany(ExternalThreadRead::class, 'external_thread_id');
    }

    public function latestMessage(): HasOne
    {
        return $this->hasOne(ExternalMessage::class, 'external_thread_id')->latestOfMany();
    }

    public function messages(): HasMany
    {
        return $this->hasMany(ExternalMessage::class, 'external_thread_id');
    }
    public function contact(): BelongsTo
    {
        return $this->belongsTo(ExternalContact::class, 'external_contact_id');
    }

    public function tags(): \Illuminate\Database\Eloquent\Relations\BelongsToMany
    {
        return $this->belongsToMany(ContactTag::class, 'ext_titan_connect_external_thread_tags', 'external_thread_id', 'contact_tag_id')
            ->withPivot('company_id')->withTimestamps();
    }

    public function voiceCalls(): HasMany
    {
        return $this->hasMany(VoiceCall::class, 'external_thread_id');
    }

}
