<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Domain\RuntimeReadinessReport;

$root = dirname(__DIR__);
require_once $root . '/System/Domain/RuntimeReadinessReport.php';

function readyCheck(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

$declared = [
    'titan-nexus',
    'nexus.domain-core',
    'nexus.compile',
    'nexus.validate',
    'nexus.preview',
    'nexus.history.lineage',
    'nexus.provision.plan',
    'nexus.provision.execute',
    'nexus.risk.evaluate',
    'nexus.governance.authorize',
    'nexus.assurance.verify',
    'nexus.autonomy.authorize',
    'nexus.signal.emit',
    'nexus.rewind.evidence',
    'nexus.control-centre',
    'nexus.interface.read-model',
];

$unavailable = RuntimeReadinessReport::fromDependencies([
    'database' => false,
    'vertical_engine' => false,
], true, $declared);
readyCheck($unavailable->status() === 'UNAVAILABLE', 'missing database/Vertical Engine makes core unavailable');
readyCheck($unavailable->capabilityAvailable('nexus.compile') === false, 'compile is unavailable without core dependencies');
readyCheck($unavailable->capabilityAvailable('nexus.domain-core') === true, 'intrinsic domain capability remains packaged while runtime core is unavailable');

$degraded = RuntimeReadinessReport::fromDependencies([
    'database' => true,
    'vertical_engine' => true,
    'command_bus' => false,
    'risk' => false,
    'governance' => false,
    'assurance' => false,
    'signal' => false,
    'rewind' => false,
    'autonomy' => false,
    'knowledge_authority' => false,
    'interface_runtime' => false,
], true, $declared);
readyCheck($degraded->status() === 'DEGRADED', 'missing governed execution stack degrades but does not remove compile/read');
readyCheck($degraded->capabilityAvailable('nexus.compile') === true, 'compile remains available in degraded mode');
readyCheck($degraded->capabilityAvailable('nexus.provision.execute') === false, 'provision execute is unavailable without governed execution dependencies');
readyCheck($degraded->capabilityAvailable('nexus.interface.read-model') === false, 'Interface Runtime contribution is unavailable when Interface Runtime is absent');
readyCheck(($degraded->toArray()['dependencies']['knowledge_authority']['requirement'] ?? null) === 'conditional', 'Knowledge Authority is explicitly conditional');
readyCheck(($degraded->toArray()['dependencies']['autonomy']['requirement'] ?? null) === 'conditional', 'Autonomy is explicitly conditional');
readyCheck(($degraded->toArray()['dependencies']['interface_runtime']['requirement'] ?? null) === 'optional', 'Interface Runtime is explicitly optional');

$required = [
    'database' => true,
    'vertical_engine' => true,
    'command_bus' => true,
    'risk' => true,
    'governance' => true,
    'assurance' => true,
    'signal' => true,
    'rewind' => true,
    'autonomy' => false,
    'knowledge_authority' => false,
    'interface_runtime' => false,
];
$healthy = RuntimeReadinessReport::fromDependencies($required, true, $declared);
readyCheck($healthy->status() === 'HEALTHY', 'all core and human-execution dependencies yield healthy status');
readyCheck($healthy->capabilityAvailable('nexus.provision.execute') === true, 'human governed provisioning is advertised when required stack is ready');
readyCheck($healthy->capabilityAvailable('nexus.autonomy.authorize') === false, 'Autonomy capability remains unavailable when conditional dependency is missing');
readyCheck($healthy->capabilityAvailable('nexus.interface.read-model') === false, 'Interface Runtime capability remains unavailable when optional dependency is absent');
readyCheck(($healthy->toArray()['execution_modes']['human'] ?? false) === true, 'human execution mode is ready');
readyCheck(($healthy->toArray()['execution_modes']['autonomous'] ?? true) === false, 'autonomous execution mode is unavailable without Autonomy');
readyCheck(($healthy->toArray()['execution_modes']['knowledge_gated'] ?? true) === false, 'knowledge-gated mode is unavailable without Knowledge Authority');
readyCheck(($healthy->toArray()['missing_required_dependencies'] ?? ['unexpected']) === [], 'healthy state has no missing required dependencies even when optional/conditional integrations are absent');
readyCheck(in_array('autonomy', $healthy->toArray()['unavailable_dependencies'] ?? [], true), 'conditional Autonomy absence remains visible without degrading health');
readyCheck(in_array('interface_runtime', $healthy->toArray()['unavailable_dependencies'] ?? [], true), 'optional Interface Runtime absence remains visible without degrading health');

$full = RuntimeReadinessReport::fromDependencies(array_merge($required, [
    'autonomy' => true,
    'knowledge_authority' => true,
    'interface_runtime' => true,
]), true, $declared);
readyCheck(($full->toArray()['execution_modes']['autonomous'] ?? false) === true, 'autonomous execution is ready when Autonomy is available');
readyCheck(($full->toArray()['execution_modes']['knowledge_gated'] ?? false) === true, 'knowledge-gated mode is ready when Knowledge Authority is available');
readyCheck($full->capabilityAvailable('nexus.interface.read-model') === true, 'Interface Runtime capability becomes available when optional dependency is present');

$disabled = RuntimeReadinessReport::fromDependencies($required, false, $declared);
readyCheck($disabled->status() === 'DISABLED', 'disabled configuration overrides dependency readiness');
readyCheck($disabled->availableCapabilities() === [], 'disabled Nexus advertises no runtime-available capabilities');

fwrite(STDOUT, "PASS: Titan Nexus runtime readiness checks\n");
