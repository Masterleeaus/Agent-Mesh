<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Tenancy;

use App\Extensions\Crm\System\Security\CrmPermissionService;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\ConnectionInterface;

final class CrmCompanyAuthorizationGateway
{
    public function __construct(
        private readonly CrmCompanyScope $scope,
        private readonly CrmPermissionService $permissions,
        private readonly ConnectionInterface $db,
    ) {}

    public function authorize(string $permission, ?string $resourceTable = null, string|int|null $resourceId = null, string $idColumn = 'public_id'): CrmCompanyContext
    {
        $context = $this->scope->current();
        if ($context->actorType === 'user') {
            if (! $context->actorUserId) throw new AuthorizationException('CRM actor is missing.');
            $authenticatedActorId = auth()->id();
            if ($authenticatedActorId !== null && (int) $authenticatedActorId === $context->actorUserId) {
                $this->permissions->authorize($context->actorUserId, $permission);
            } elseif (! in_array($permission, $context->permissions, true)) {
                throw new AuthorizationException('Trusted platform user context does not carry the required CRM capability.');
            }
        } elseif (! in_array($permission, $context->permissions, true)) {
            throw new AuthorizationException("CRM capability denied for {$context->actorType} actor.");
        }

        if ($resourceTable !== null && $resourceId !== null) {
            $exists = $this->db->table($resourceTable)
                ->where('company_id', $context->companyId)
                ->where($idColumn, $resourceId)
                ->exists();
            if (! $exists) throw new AuthorizationException('CRM resource does not belong to the active company.');
        }
        return $context;
    }
}
