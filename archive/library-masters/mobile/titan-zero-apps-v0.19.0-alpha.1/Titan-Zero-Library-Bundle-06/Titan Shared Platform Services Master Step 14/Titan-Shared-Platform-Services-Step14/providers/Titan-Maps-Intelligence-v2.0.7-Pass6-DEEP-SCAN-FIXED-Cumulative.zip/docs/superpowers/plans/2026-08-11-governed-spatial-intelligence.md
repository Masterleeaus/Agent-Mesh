# Governed Spatial Intelligence Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Add the canonical Titan spatial capability and governance integration layer to the existing alpha.16 Maps extension without breaking existing functionality.

**Architecture:** Preserve all extension-local services/capabilities and add canonical aliases plus an extension-owned governed executor. Optional host engine adapters are preferred; conservative local fallbacks never claim unavailable platform decisions or perform cross-extension writes.

**Tech Stack:** PHP 8.3, Laravel 10, existing Titan extension provider/capability registrar, JSON sidecar metadata, standalone PHP verification scripts.

## Global Constraints

- Preserve `titan-extension-v1` root installer manifest.
- Preserve all 31 alpha.16 capability IDs.
- Add exactly 8 canonical spatial capability IDs.
- Authorised company context is always server-derived.
- No direct AI mutation of CRM authoritative state.
- No unrestricted hidden chain-of-thought storage.
- Offline execution may reduce authority but never increase it.
- Host engine integrations are optional adapters and must not break provider boot when absent.

---

### Task 1: Governance contract and metadata gate

**Files:**
- Create: `Contracts/SpatialRiskGateway.php`
- Create: `Contracts/SpatialAssuranceGateway.php`
- Create: `Contracts/SpatialAutonomyGateway.php`
- Create: `Contracts/SpatialCommandBusGateway.php`
- Create: `Contracts/SpatialSignalPublisher.php`
- Create: `Contracts/SpatialRewindRecorder.php`
- Create: `Contracts/SpatialKnowledgeGateway.php`
- Create: `DTO/SpatialExecutionContext.php`
- Create: `DTO/SpatialDecisionReceipt.php`
- Create: `Services/SpatialCapabilityPolicyCatalog.php`
- Test: `scripts/verify_governed_spatial_architecture.php`

**Interfaces:**
- Produces `SpatialCapabilityPolicyCatalog::policy(string $capabilityId): array`.
- Produces immutable execution context and receipt DTOs.

- [x] Write the architecture verifier requiring the seven gateway contracts, two DTOs and policy catalog; require all policies to contain risk/autonomy/evidence/offline/reversibility/idempotency/mutation fields.
- [x] Run `php scripts/verify_governed_spatial_architecture.php`; expect failure because production files are absent.
- [x] Implement the contracts/DTOs/policy catalog with explicit policies for all legacy and canonical capability families.
- [x] Rerun the verifier; expect PASS.

### Task 2: Conservative host-portable adapters

**Files:**
- Create: `Services/UnavailableSpatialRiskGateway.php`
- Create: `Services/UnavailableSpatialAssuranceGateway.php`
- Create: `Services/UnavailableSpatialAutonomyGateway.php`
- Create: `Services/UnavailableSpatialCommandBusGateway.php`
- Create: `Services/LocalSpatialSignalPublisher.php`
- Create: `Services/LocalSpatialRewindRecorder.php`
- Create: `Services/UnavailableSpatialKnowledgeGateway.php`
- Modify: `System/TitanMapsIntelligenceServiceProvider.php`
- Test: `scripts/test_spatial_governance_runtime.php`

**Interfaces:**
- Read-only/preparatory fallbacks return explicit `available=false` references without inventing external engine decisions.
- Command Bus fallback rejects authoritative cross-extension execution.

- [x] Write runtime tests proving unavailable adapters do not fabricate engine approval and Command Bus fallback rejects authoritative mutation.
- [x] Run test; expect failure on missing classes/bindings.
- [x] Implement adapters and provider `bindPreferred()` bindings to expected host adapter class names.
- [x] Run runtime and host-portability tests; expect PASS.

### Task 3: Governed executor, trace propagation and canonical signals

**Files:**
- Create: `Services/SpatialExecutionContextFactory.php`
- Create: `Services/GovernedSpatialCapabilityExecutor.php`
- Create: `Events/SpatialCapabilityExecuted.php`
- Create: `Events/SpatialCapabilityDenied.php`
- Create: `Events/RouteFallbackUsed.php`
- Modify: `Events/MapsDomainEvent.php`
- Test: `scripts/test_governed_spatial_execution_runtime.php`

**Interfaces:**
- `SpatialExecutionContextFactory::fromInput(string $capabilityId, array $input): SpatialExecutionContext` derives company ID from `AuthorisedCompanyContext`.
- `GovernedSpatialCapabilityExecutor::execute(string $capabilityId, array $input, callable $operation): array` returns data plus structured governance receipt.

- [x] Write tests proving client `tenant_company_id` is ignored/rejected and trace IDs propagate into receipts and signal payloads.
- [x] Run test; expect failure.
- [x] Implement context factory and governed executor; use risk/assurance/autonomy gateways based on policy, emit canonical signal/audit receipt, and deny AI/system consequential execution when required governance is unavailable/denied.
- [x] Rerun tests; expect PASS.

### Task 4: Eight canonical spatial tools

**Files:**
- Create: `Tools/GeocodeLocationTool.php`
- Create: `Tools/LookupTerritoryTool.php`
- Create: `Tools/ValidateTerritoryTool.php`
- Create: `Tools/EstimateRouteTool.php`
- Create: `Tools/CompareRoutesTool.php`
- Create: `Tools/GetJobTravelContextTool.php`
- Create: `Tools/CheckServiceAreaTool.php`
- Create: `Tools/NearbySearchTool.php`
- Create: `Services/JobTravelContextService.php`
- Modify: `Services/MapsCapabilityService.php`
- Test: `scripts/test_canonical_spatial_capabilities_runtime.php`

**Interfaces:**
- Canonical tools return the existing Maps data plus `governance_receipt`.
- Job travel context resolves the job through `FieldReferenceGateway`, `MapLocationService`/canonical location projection, territory evaluation and optional Knowledge Authority references.

- [x] Write tests requiring the eight IDs and real handlers and proving `job.travel_context` does not copy CRM authoritative records.
- [x] Run test; expect failure.
- [x] Implement tools/service and add exactly eight canonical definitions.
- [x] Rerun canonical and legacy capability parity tests; expect 39 total definitions with all 31 legacy IDs retained.

### Task 5: Full capability metadata and offline manifest

**Files:**
- Modify: `Services/MapsCapabilityService.php`
- Create: `Services/OfflineSpatialCapabilityManifest.php`
- Create: `Http/Controllers/OfflineCapabilityManifestController.php`
- Modify: `routes/api.php`
- Test: `scripts/test_spatial_offline_policy_runtime.php`

**Interfaces:**
- Every definition receives `owner`, `risk_profile`, `autonomy_requirement`, `evidence_requirements`, `offline_policy`, `reversibility`, `idempotency_strategy`, `mutation_class`, and optional `canonical_alias`.
- Offline API returns capability ID and policy only; it does not leak provider secrets.

- [x] Write tests requiring full metadata on all 39 capabilities and ensuring no offline policy exceeds online authority.
- [x] Run test; expect failure.
- [x] Enrich definitions from `SpatialCapabilityPolicyCatalog`; implement offline manifest endpoint.
- [x] Rerun tests; expect PASS.

### Task 6: Canonical geospatial anomaly/territory/route events

**Files:**
- Create: `Events/TerritoryConflictDetected.php`
- Create: `Events/ServiceAreaExcluded.php`
- Create: `Events/GeospatialAnomalyDetected.php`
- Modify: `Services/RouteCalculationService.php`
- Modify: `Services/ServiceTerritoryService.php`
- Modify: `Services/WorkerTrackingService.php`
- Test: `scripts/verify_spatial_signal_integration.php`

**Interfaces:**
- Existing Laravel events remain.
- Canonical events include tenant, trace/correlation/causation where supplied, reason codes and structured evidence only.

- [x] Write verifier requiring canonical event classes and integration points for route fallback/failure, exclusion/conflict and GPS anomaly.
- [x] Run verifier; expect failure.
- [x] Implement additive event dispatch calls without removing legacy events.
- [x] Rerun verifier and existing runtime tests; expect PASS.

### Task 7: Manifest/docs/release certification

**Files:**
- Modify: `extension.json`
- Modify: `extension.manifest.json`
- Modify: `README.md`
- Modify: `CHANGELOG.md`
- Modify: `BUILD_REPORT.md`
- Modify: `SECURITY.md`
- Modify: `docs/superpowers/plans/2026-08-09-titan-maps-intelligence-v2.md`
- Modify: package inventories/hashes

**Interfaces:**
- Release version becomes `2.0.0-alpha.17`.
- Sidecar declares required/optional governed-engine integration metadata without changing root installer schema.

- [x] Update release metadata and mark governed Pass 17 complete; move advanced operational UI work to the next numbered pass.
- [x] Run all standalone verification/runtime scripts.
- [x] Run PHP lint, JavaScript syntax, JSON parse and package hash verification.
- [x] Run hardened sidecar schema validation and secret/filesystem scan.
- [x] Package a flat-root ZIP, verify unsafe paths/case collisions/required root files.
- [x] Freshly extract the final ZIP into `TitanMapsIntelligence/` and rerun all verifiers against packaged bytes.
