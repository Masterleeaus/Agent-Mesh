<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

final class CrmApiKeyService
{
    public const SCOPES=['crm.read','crm.read.contacts','crm.read.companies','crm.read.deals','crm.write.contacts','crm.write.companies','crm.write.leads','crm.write.deals'];

    public function __construct(private ConnectionInterface $db) {}

    public function issue(int $userId,string $label,array $scopes=['crm.read'],?string $expires_at=null,?string $rotated_from_public_id=null,array $allowed_ip_cidrs=[],?string $rotation_family_public_id=null): array
    {
        $scopes=array_values(array_unique(array_map('strval',$scopes))); $bad=array_diff($scopes,self::SCOPES);
        if($bad) throw new \InvalidArgumentException('Unsupported CRM API scope: '.implode(', ',$bad));
        if($scopes===[]) throw new \InvalidArgumentException('CRM API keys require at least one scope.');
        $allowed_ip_cidrs=$this->normalizeCidrs($allowed_ip_cidrs);
        $requireExpiry=(bool)config('crm.api_keys.require_expiry',true);
        if(($expires_at===null||trim($expires_at)==='')&&$requireExpiry)$expires_at=now()->addDays(max(1,(int)config('crm.api_keys.default_ttl_days',90)))->toDateTimeString();
        if($expires_at!==null && Carbon::parse($expires_at)->lessThanOrEqualTo(now())) throw new \InvalidArgumentException('CRM API key expiry must be in the future.');
        $maxDays=max(1,(int)config('crm.api_keys.max_ttl_days',365));
        if($expires_at!==null && Carbon::parse($expires_at)->greaterThan(now()->addDays($maxDays))) throw new \InvalidArgumentException("CRM API keys cannot exceed {$maxDays} days.");

        $secret='crm_'.rtrim(strtr(base64_encode(random_bytes(32)),'+/','-_'),'='); $publicId=(string)Str::ulid();
        $rotationFamily=$rotation_family_public_id?:($rotated_from_public_id?:$publicId);
        $this->db->table('crm_api_keys')->insert([
            'public_id'=>$publicId,'company_id'=>CrmCompanyScope::companyId($userId),'user_id'=>CrmCompanyScope::actorUserId($userId),
            'label'=>mb_substr(trim($label),0,120),'key_hash'=>hash('sha256',$secret),'key_hint'=>substr($secret,-10),'scopes'=>json_encode($scopes),
            'allowed_ip_cidrs'=>$allowed_ip_cidrs?json_encode($allowed_ip_cidrs):null,'not_before_at'=>now(),'expires_at'=>$expires_at,
            'rotated_from_public_id'=>$rotated_from_public_id,'rotation_family_public_id'=>$rotationFamily,'created_at'=>now(),'updated_at'=>now(),
        ]);
        $row=(array)$this->db->table('crm_api_keys')->where('public_id',$publicId)->first();
        return ['api_key'=>$this->sanitizeRow($row),'secret'=>$secret];
    }

    public function resolve(string $secret,?string $requiredScope=null,?string $requestIp=null): array
    {
        $row=$this->db->table('crm_api_keys')->where('key_hash',hash('sha256',trim($secret)))->first();
        if(!$row) throw new NotFoundHttpException();
        if($row->revoked_at || ($row->not_before_at && now()->lessThan($row->not_before_at)) || ($row->expires_at && now()->greaterThan($row->expires_at))) throw new NotFoundHttpException();
        $scopes=json_decode((string)$row->scopes,true)?:[];
        if($requiredScope && !$this->scopeMatches($scopes,$requiredScope)) throw new AccessDeniedHttpException('CRM API key scope denied.');
        $allowed=json_decode((string)($row->allowed_ip_cidrs??'[]'),true)?:[];
        $this->assertIpAllowed($allowed,$requestIp);
        $this->db->table('crm_api_keys')->where('id',$row->id)->update(['last_used_at'=>now(),'updated_at'=>now()]);
        return array_merge((array)$row,['scopes'=>$scopes,'allowed_ip_cidrs'=>$allowed]);
    }

    public function revoke(int $userId,string $publicId,string $revocation_reason='manual'): void
    {
        $n=$this->db->table('crm_api_keys')->where('company_id',CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->whereNull('revoked_at')
            ->update(['revoked_at'=>now(),'revocation_reason'=>mb_substr(trim($revocation_reason),0,120),'updated_at'=>now()]);
        if(!$n) throw new NotFoundHttpException();
    }

    public function rotate(int $userId,string $publicId,?string $label=null): array
    {
        $row=$this->db->table('crm_api_keys')->where('company_id',CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->whereNull('revoked_at')->first();
        if(!$row) throw new NotFoundHttpException();
        $scopes=json_decode((string)$row->scopes,true)?:['crm.read']; $allowed=json_decode((string)($row->allowed_ip_cidrs??'[]'),true)?:[];
        $issued=$this->issue($userId,$label?:((string)$row->label.' (rotated)'),$scopes,$row->expires_at?:null,$publicId,$allowed,(string)($row->rotation_family_public_id?:$publicId));
        $this->revoke($userId,$publicId,'rotation'); return $issued;
    }

    public function list(int $userId): array
    {
        return $this->db->table('crm_api_keys')->where('company_id',CrmCompanyScope::companyId($userId))->orderByDesc('id')->get()->map(fn($r)=>$this->sanitizeRow((array)$r))->all();
    }

    public function scopeMatches(array $granted,string $requiredScope): bool
    {
        foreach($granted as $scope){$scope=(string)$scope;if($scope==='*'||$scope===$requiredScope)return true;if(str_ends_with($scope,'.*')&&str_starts_with($requiredScope,substr($scope,0,-1)))return true;if($scope==='crm.read'&&str_starts_with($requiredScope,'crm.read.'))return true;}
        return false;
    }

    public function assertIpAllowed(array $allowed_ip_cidrs,?string $requestIp): void
    {
        if($allowed_ip_cidrs===[]) return;
        if(!$requestIp) throw new AccessDeniedHttpException('CRM API key IP policy requires a client IP address.');
        foreach($allowed_ip_cidrs as $cidr) if($this->ipMatchesCidr($requestIp,(string)$cidr)) return;
        throw new AccessDeniedHttpException('CRM API key is not authorized from this IP address.');
    }

    private function normalizeCidrs(array $values): array
    {
        $out=[];foreach($values as $value){$value=trim((string)$value);if($value==='')continue;$ip=str_contains($value,'/')?strtok($value,'/'):$value;if(filter_var($ip,FILTER_VALIDATE_IP)===false)throw new \InvalidArgumentException('Invalid API-key IP/CIDR policy entry: '.$value);$out[]=$value;}
        return array_values(array_unique($out));
    }

    private function ipMatchesCidr(string $ip,string $cidr): bool
    {
        if(!str_contains($cidr,'/')) return hash_equals($cidr,$ip);
        [$network,$prefix]=explode('/',$cidr,2);$ipBin=@inet_pton($ip);$netBin=@inet_pton($network);if($ipBin===false||$netBin===false||strlen($ipBin)!==strlen($netBin))return false;
        $bits=(int)$prefix;$max=strlen($ipBin)*8;if($bits<0||$bits>$max)return false;$bytes=intdiv($bits,8);$rem=$bits%8;
        if($bytes>0&&substr($ipBin,0,$bytes)!==substr($netBin,0,$bytes))return false;if($rem===0)return true;$mask=(0xFF << (8-$rem)) & 0xFF;return (ord($ipBin[$bytes])&$mask)===(ord($netBin[$bytes])&$mask);
    }

    private function sanitizeRow(array $row): array
    {
        unset($row['key_hash']);
        foreach(['scopes','allowed_ip_cidrs'] as $key)if(isset($row[$key])&&is_string($row[$key]))$row[$key]=json_decode($row[$key],true)?:[];
        return $row;
    }
}
