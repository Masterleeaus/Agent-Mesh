# Titan Rewind Integration Contracts

## Host source registry

Blueprint v4.1 owns `App\Support\Extensions\RewindSourceRegistry` and `RewindSourceAdapter`. Producing extensions register with the host registry. Rewind discovers the shared registry lazily on reconstruction/watermark operations and wraps each source without importing producer internals.

A host source must provide `sourceKey()`, `watermark(tenantCompanyId, traceId)`, and `records(tenantCompanyId, traceId, asOf)`. Records are normalized into `RewindEventRecord` and are rejected if their tenant or trace differs from the query boundary.

## Historical artifact resolvers

Direct Rewind integrations may implement `RewindHistoricalArtifactResolverContract`. Host-neutral integrations may register resolver objects under container tag `titan.rewind.artifact-resolvers`; the object must expose `artifactKind()` or `kind()` and `resolve(version, context)`.

## Authority boundary

Source and artifact integrations are read-only. Recovery approval remains Titan Governance authority; authoritative execution remains Titan Command Bus/domain authority.
