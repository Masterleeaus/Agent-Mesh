<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_rewind_cases')) {
            Schema::create('titan_rewind_cases', function (Blueprint $table): void {
                $table->id();
                $table->uuid('case_uuid')->unique();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->string('case_key',191);
                $table->string('title',191);
                $table->string('status',30)->default('open')->index();
                $table->string('severity',30)->default('medium')->index();
                $table->string('source_type',80)->nullable();
                $table->string('source_id',191)->nullable();
                $table->uuid('primary_trace_id')->nullable()->index();
                $table->string('entity_type',160)->nullable();
                $table->string('entity_id',191)->nullable();
                $table->dateTime('detected_at',6)->nullable()->index();
                $table->json('metadata')->nullable();
                $table->dateTime('resolved_at',6)->nullable();
                $table->string('resolved_by_type',60)->nullable();
                $table->unsignedBigInteger('resolved_by_id')->nullable();
                $table->timestamps();
                $table->index(['tenant_company_id','status','severity'],'trw_case_tenant_status_sev');
                $table->index(['tenant_company_id','case_key'],'trw_case_tenant_key');
                $table->index(['tenant_company_id','entity_type','entity_id'],'trw_case_tenant_entity');
            });
        }

        if (!Schema::hasTable('titan_rewind_case_traces')) {
            Schema::create('titan_rewind_case_traces', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('case_id')->index();
                $table->uuid('trace_id')->index();
                $table->string('relationship_type',40)->default('related');
                $table->dateTime('added_at',6)->nullable();
                $table->unique(['case_id','trace_id'],'trw_case_trace_unique');
                $table->index(['tenant_company_id','trace_id'],'trw_case_trace_tenant_trace');
            });
        }

        if (!Schema::hasTable('titan_rewind_timeline_entries')) {
            Schema::create('titan_rewind_timeline_entries', function (Blueprint $table): void {
                $table->id();
                $table->uuid('entry_uuid')->unique();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('case_id')->nullable()->index();
                $table->uuid('event_id');
                $table->uuid('trace_id')->index();
                $table->uuid('correlation_id')->nullable()->index();
                $table->uuid('causation_id')->nullable()->index();
                $table->string('source_engine',80)->index();
                $table->string('event_type',120)->index();
                $table->unsignedBigInteger('sequence')->default(0)->index();
                $table->unsignedTinyInteger('tier')->nullable()->index();
                $table->string('lane',80)->nullable()->index();
                $table->string('title',255);
                $table->text('summary')->nullable();
                $table->string('risk_level',30)->default('unknown')->index();
                $table->json('metadata')->nullable();
                $table->dateTime('occurred_at',6)->index();
                $table->timestamps();
                $table->unique(['tenant_company_id','event_id'],'trw_timeline_tenant_event');
                $table->index(['tenant_company_id','trace_id','sequence'],'trw_timeline_tenant_trace_seq');
            });
        }

        if (!Schema::hasTable('titan_rewind_dependencies')) {
            Schema::create('titan_rewind_dependencies', function (Blueprint $table): void {
                $table->id();
                $table->char('dependency_key',64)->unique();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('case_id')->nullable()->index();
                $table->uuid('event_id')->nullable()->index();
                $table->uuid('trace_id')->index();
                $table->string('source_entity_type',160);
                $table->string('source_entity_id',191)->nullable();
                $table->string('target_entity_type',160);
                $table->string('target_entity_id',191)->nullable();
                $table->string('relationship_type',80)->default('related');
                $table->string('risk_level',30)->default('unknown')->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->index(['tenant_company_id','source_entity_type','source_entity_id'],'trw_dep_source');
                $table->index(['tenant_company_id','target_entity_type','target_entity_id'],'trw_dep_target');
            });
        }

        if (!Schema::hasTable('titan_rewind_replay_runs')) {
            Schema::create('titan_rewind_replay_runs', function (Blueprint $table): void {
                $table->id();
                $table->uuid('run_uuid')->unique();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('case_id')->nullable()->index();
                $table->uuid('trace_id')->index();
                $table->uuid('correlation_id')->nullable()->index();
                $table->string('mode',40)->default('historical_dry_run');
                $table->string('status',40)->default('queued')->index();
                $table->string('target_environment',80)->default('simulation');
                $table->unsignedBigInteger('requested_by_id')->nullable()->index();
                $table->json('input')->nullable();
                $table->json('result')->nullable();
                $table->text('error_text')->nullable();
                $table->dateTime('started_at',6)->nullable();
                $table->dateTime('finished_at',6)->nullable();
                $table->timestamps();
                $table->index(['tenant_company_id','status','created_at'],'trw_replay_tenant_status');
            });
        }

        if (Schema::hasTable('titan_rewind_snapshots')) {
            Schema::table('titan_rewind_snapshots', function (Blueprint $table): void {
                if (!Schema::hasColumn('titan_rewind_snapshots','snapshot_key')) $table->char('snapshot_key',64)->nullable()->unique();
                if (!Schema::hasColumn('titan_rewind_snapshots','entity_type')) $table->string('entity_type',160)->nullable()->index();
                if (!Schema::hasColumn('titan_rewind_snapshots','entity_id')) $table->string('entity_id',191)->nullable()->index();
                if (!Schema::hasColumn('titan_rewind_snapshots','snapshot_type')) $table->string('snapshot_type',80)->nullable()->index();
                if (!Schema::hasColumn('titan_rewind_snapshots','event_id')) $table->uuid('event_id')->nullable()->index();
                if (!Schema::hasColumn('titan_rewind_snapshots','state_hash')) $table->char('state_hash',64)->nullable()->index();
                if (!Schema::hasColumn('titan_rewind_snapshots','size_bytes')) $table->unsignedBigInteger('size_bytes')->nullable();
                if (!Schema::hasColumn('titan_rewind_snapshots','captured_at')) $table->dateTime('captured_at',6)->nullable()->index();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_rewind_replay_runs');
        Schema::dropIfExists('titan_rewind_dependencies');
        Schema::dropIfExists('titan_rewind_timeline_entries');
        Schema::dropIfExists('titan_rewind_case_traces');
        Schema::dropIfExists('titan_rewind_cases');
        if (Schema::hasTable('titan_rewind_snapshots')) {
            $columns = array_values(array_filter(['snapshot_key','entity_type','entity_id','snapshot_type','event_id','state_hash','size_bytes','captured_at'], static fn(string $c): bool => Schema::hasColumn('titan_rewind_snapshots',$c)));
            if ($columns !== []) Schema::table('titan_rewind_snapshots', static function(Blueprint $table) use ($columns): void { $table->dropColumn($columns); });
        }
    }
};
