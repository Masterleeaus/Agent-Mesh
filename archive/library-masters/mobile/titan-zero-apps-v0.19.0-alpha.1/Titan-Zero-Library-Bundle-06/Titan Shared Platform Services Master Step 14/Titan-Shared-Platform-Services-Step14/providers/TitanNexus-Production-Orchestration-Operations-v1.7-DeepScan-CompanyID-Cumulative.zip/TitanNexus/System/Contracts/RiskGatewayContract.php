<?php

declare(strict_types=1);
namespace App\Extensions\TitanNexus\System\Contracts;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\RiskDecision;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
interface RiskGatewayContract { public function evaluate(ProvisioningOperation $operation, TraceContext $traceContext, ProvisioningExecutionContext $executionContext): RiskDecision; }
