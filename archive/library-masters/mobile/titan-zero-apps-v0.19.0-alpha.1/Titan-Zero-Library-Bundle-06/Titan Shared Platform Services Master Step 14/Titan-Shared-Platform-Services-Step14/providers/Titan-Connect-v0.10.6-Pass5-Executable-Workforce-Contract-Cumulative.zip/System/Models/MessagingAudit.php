<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use Illuminate\Database\Eloquent\Model;

final class MessagingAudit extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    public $timestamps = false;

    protected $table = 'ext_titan_connect_audit_logs';

    protected $fillable = [
        'company_id', 'actor_id', 'action', 'subject_type', 'subject_id',
        'correlation_id', 'metadata', 'created_at',
    ];

    protected $casts = ['metadata' => 'array', 'created_at' => 'datetime'];
}
