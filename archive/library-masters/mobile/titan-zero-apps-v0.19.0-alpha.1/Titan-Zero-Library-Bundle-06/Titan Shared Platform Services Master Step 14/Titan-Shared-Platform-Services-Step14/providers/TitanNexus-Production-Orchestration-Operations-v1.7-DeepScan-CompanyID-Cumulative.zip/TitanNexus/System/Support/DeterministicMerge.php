<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Support;

final class DeterministicMerge
{
    /**
     * Business overrides win. Associative maps merge recursively; lists are replaced atomically.
     * Empty override maps mean "no override" when the default is a map.
     *
     * @param array<string|int, mixed> $defaults
     * @param array<string|int, mixed> $overrides
     * @return array<string|int, mixed>
     */
    public static function override(array $defaults, array $overrides): array
    {
        $defaultsIsList = $defaults !== [] && array_is_list($defaults);
        $overridesIsList = $overrides !== [] && array_is_list($overrides);

        if ($defaultsIsList || $overridesIsList) {
            return $overrides;
        }

        if ($overrides === []) {
            return $defaults;
        }

        $merged = $defaults;

        foreach ($overrides as $key => $overrideValue) {
            if (array_key_exists($key, $defaults)
                && is_array($defaults[$key])
                && is_array($overrideValue)) {
                $defaultNestedIsList = $defaults[$key] !== [] && array_is_list($defaults[$key]);
                $overrideNestedIsList = $overrideValue !== [] && array_is_list($overrideValue);

                if (!$defaultNestedIsList && !$overrideNestedIsList) {
                    $merged[$key] = self::override($defaults[$key], $overrideValue);
                    continue;
                }
            }

            $merged[$key] = $overrideValue;
        }

        return $merged;
    }
}
