<?php
namespace App\Extensions\Crm\System\Contracts;
interface CrmAssistantChatServiceContract { public function templateType(): string; public function systemPrompt(array $context = []): string; }
