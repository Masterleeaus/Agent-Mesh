# Titan Governance v0.7.0 — Pass 6 Control Centre & Model/Compliance Health

## Scope
Pass 6 adds the daily human Governance oversight cockpit on top of the Pass 5 forensic foundation. It is a read-side projection layer and remains aligned to **Titan Extension Blueprint v4.2.2**.

## Added capabilities
- Governance **Needs Attention** ranking from explicit source evidence.
- Cross-engine health scorecard with required/optional dependency visibility.
- Model transition health (`HEALTHY`, `TRANSITIONING`, `DEGRADED`, `FAILED`, `STALE`, `UNKNOWN`).
- Model Council disagreement visibility with independent disagreement bands and `changes_authority=false`.
- Policy-version drift and explicit compliance-control state.
- Governance exception expiry/expiring visibility.
- Evidence freshness classification using explicit `observed_at` timestamps only.
- Authority-contraction explanations preserving desired/earned/effective source values and reason codes.
- Authenticated read-only `governance.control-centre.read` capability and `/control-centre` endpoint.

## Authority boundary
Titan Autonomy remains the sole owner of earned and effective authority. The Control Centre explains constraints and **never raises authority**. Model disagreement, control failures, operational pressure and attention ranking do not mint authority and do not directly mutate any peer engine.

## Source boundary
Control Centre data is obtained only through `GovernanceReadSourceContract`. No Risk, Assurance, Autonomy, Signal, Shield, Model Council, Workforce or domain table is directly queried. Source exceptions and identity mismatches are isolated and surfaced visibly.

## Attention semantics
Attention ranking is deterministic. It uses explicit severity and evidence states rather than generated causal narratives. CRITICAL outranks HIGH, then MEDIUM, then LOW; equal-severity items are oldest first.

## Runtime boundary
Package/static certification cannot prove live MagicAI provider boot, production MySQL state, browser rendering or real peer-engine adapter payloads. Those remain `NOT_RUN` until installed on the target host.
