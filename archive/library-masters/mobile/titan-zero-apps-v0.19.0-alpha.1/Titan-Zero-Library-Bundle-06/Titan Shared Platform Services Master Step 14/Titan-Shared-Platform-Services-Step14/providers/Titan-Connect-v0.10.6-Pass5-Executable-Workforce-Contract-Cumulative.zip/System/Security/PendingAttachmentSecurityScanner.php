<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use App\Extensions\TitanConnect\System\Contracts\AttachmentSecurityScanner;

final class PendingAttachmentSecurityScanner implements AttachmentSecurityScanner
{
    public function scanMetadata(int $companyId, array $metadata): string
    {
        return 'pending';
    }
}
