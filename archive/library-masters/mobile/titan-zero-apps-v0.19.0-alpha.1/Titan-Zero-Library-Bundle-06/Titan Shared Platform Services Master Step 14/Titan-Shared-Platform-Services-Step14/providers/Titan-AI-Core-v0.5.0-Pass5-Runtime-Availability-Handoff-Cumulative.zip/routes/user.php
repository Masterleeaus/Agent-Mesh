<?php

use App\Extensions\TitanAICore\System\Http\Controllers\IndexController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', IndexController::class)
    ->middleware('titan-ai-core.capability:ai.core.read')
    ->name('index');
