<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('crm_leads')) Schema::table('crm_leads', function(Blueprint $t): void {
            if (!Schema::hasColumn('crm_leads','conversion_map')) $t->json('conversion_map')->nullable();
            if (!Schema::hasColumn('crm_leads','converted_company_public_id')) $t->char('converted_company_public_id',26)->nullable()->index('crm_lead_conv_company_pub_idx');
            if (!Schema::hasColumn('crm_leads','converted_contact_public_id')) $t->char('converted_contact_public_id',26)->nullable()->index('crm_lead_conv_contact_pub_idx');
        });
        foreach (['crm_proposals','crm_estimates'] as $table) if (Schema::hasTable($table)) Schema::table($table, function(Blueprint $t) use ($table): void {
            if (!Schema::hasColumn($table,'expires_at')) $t->dateTime('expires_at')->nullable()->index($table.'_expires_idx');
            if (!Schema::hasColumn($table,'snapshot_version')) $t->string('snapshot_version',40)->nullable();
            if (!Schema::hasColumn($table,'pricing_rule_snapshot')) $t->json('pricing_rule_snapshot')->nullable();
            if (!Schema::hasColumn($table,'tax_rule_snapshot')) $t->json('tax_rule_snapshot')->nullable();
            if (!Schema::hasColumn($table,'terms_snapshot')) $t->json('terms_snapshot')->nullable();
        });
        if (Schema::hasTable('crm_api_keys')) Schema::table('crm_api_keys', function(Blueprint $t): void {
            if (!Schema::hasColumn('crm_api_keys','revocation_reason')) $t->string('revocation_reason',120)->nullable();
            if (!Schema::hasColumn('crm_api_keys','rotated_from_public_id')) $t->char('rotated_from_public_id',26)->nullable()->index('crm_api_key_rotation_idx');
        });
        if (Schema::hasTable('crm_webhook_deliveries')) Schema::table('crm_webhook_deliveries', function(Blueprint $t): void {
            if (!Schema::hasColumn('crm_webhook_deliveries','idempotency_key')) $t->char('idempotency_key',64)->nullable()->index('crm_webhook_idem_idx');
            if (!Schema::hasColumn('crm_webhook_deliveries','signature_version')) $t->string('signature_version',12)->default('v2');
            if (!Schema::hasColumn('crm_webhook_deliveries','signed_at')) $t->dateTime('signed_at')->nullable();
        });
    }

    public function down(): void { /* Production hardening columns are intentionally retained on rollback. */ }
};
