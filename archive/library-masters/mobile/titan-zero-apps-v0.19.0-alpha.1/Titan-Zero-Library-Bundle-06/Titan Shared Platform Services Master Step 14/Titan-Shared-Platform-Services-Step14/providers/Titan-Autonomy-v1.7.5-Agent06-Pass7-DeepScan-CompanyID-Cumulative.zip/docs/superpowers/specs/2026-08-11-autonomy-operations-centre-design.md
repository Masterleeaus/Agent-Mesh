# Titan Autonomy Operations / Exception Centre Design

## Goal
Expose the closed-loop autonomy runtime as a tenant-safe operational queue so authorised managers can understand pending verification, exceptions, Assurance findings, regressions, and human-verification requirements without weakening any autonomy gate.

## Architecture
The Operations Centre is a read-first projection over canonical autonomy execution receipts, feedback, regressions, and capability state. A dedicated classifier derives an operational status from persisted evidence; it does not mutate trust. Manager interventions are deliberately narrow: recheck a receipt only after its existing maturation time, record negative outcome feedback through the existing negative-only policy, and record a review note/acknowledgement in a separate review table. No operations action may grant autonomy, shorten evidence windows, bypass Assurance, override postconditions, or mint a positive learning label.

## Components
1. **Operations query projection** — tenant-scoped receipt/feed/review queries with bounded pagination and filters.
2. **Operations classifier** — deterministic labels: observing, due_for_reconciliation, awaiting_human_verification, verification_failed, assurance_red, assurance_amber, incorrect, reversed, exception, insufficient_information, verified_correct.
3. **Operations service** — summary counts, priority ordering, allowed-action calculation, receipt detail.
4. **Review store** — append-only manager acknowledgement/note records separate from learning evidence.
5. **Due-only recheck service** — reconcile one tenant-owned receipt only if it is still observing and `matures_at <= now`; otherwise deny.
6. **Tenant UI** — Operations queue + detail page with evidence, scope, execution/postcondition/Assurance summaries, regressions, and safe interventions.
7. **Audit** — manager review and manual recheck actions flow to control-plane audit/Rewind correlation where available.

## Security invariants
- `tenant_company_id` comes only from `HostContextBridgeContract`.
- Client filters/correlation IDs never establish tenancy or authority.
- Positive evidence cannot be submitted from the UI/API.
- Recheck cannot bypass `matures_at`, current capability state, postcondition verification, or tenant-explicit Assurance.
- Acknowledgement is operational metadata only; it cannot alter `final_label`, streaks, gates, handshakes, scope, or current autonomy level.
- Critical receipts that require human verification remain non-auto-maturing.
- Queue/detail payloads display sanitized persisted receipt content only.

## Version
Target release: Titan Autonomy Engine v1.6.0.
