# Titan Rewind Signal Events

Titan Rewind uses a durable local outbox and `RewindSignalTransportContract`. Producing a Signal event never grants Rewind authority over the observed domain state.

Current versioned events:

- `rewind.replay.queued.v1`
- `rewind.replay.completed.v1`
- `rewind.replay.failed.v1`
- `rewind.integrity.verified.v1`
- `rewind.integrity.failed.v1`
- `rewind.drift.detected.v1`
- `rewind.evidence.generated.v1`
- `rewind.recovery.proposed.v1`
- `rewind.governance.receipt.observed.v1`
- `rewind.legal_hold.applied.v1`

Every envelope includes event ID, event type, schema version, occurred time, extension key, tenant, trace, correlation, optional causation, severity and structured payload. Delivery uses bounded retry and persistent circuit-breaker/dead-letter state.
