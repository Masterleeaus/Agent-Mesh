# Failure Modes

Provider unavailable → DEGRADED; malformed provider output → review_required; missing domain integration → proposal retained; missing context → analysis proceeds only on supplied evidence with uncertainty.
