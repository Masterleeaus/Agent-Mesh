# Titan Wisdom Engine — Upgrade Prompt

# Titan Zero Global Architecture Rules

This extension is part of the governed Titan Zero architecture. Preserve these boundaries:

- AI intelligence never directly mutates authoritative business state when a governed capability/Command Bus path exists.
- Intelligence, risk, assurance, autonomy, approval and execution remain separate concerns.
- Every significant action emits structured Signal telemetry and a traceable receipt.
- Use tenant_company_id, trace_id, correlation_id and causation_id on durable cross-extension records/events.
- Do not store unrestricted hidden model reasoning; store structured decision rationale, reason codes, policy/evidence references and outcomes.
- Offline operation may reduce authority but must never increase it.
- External side effects must be idempotent.
- Preserve installer compatibility and existing working host UI conventions.
- Prefer shared contracts/adapters over importing another extension's internal implementation classes.

## Extension Mission

MISSION: Build Titan Wisdom Engine as the Outcome + Learning Engine.

OWN: intended-vs-actual outcome records, attribution to agent/capability/model/workflow/vertical, delayed outcome resolution, success/partial/failure classification, learning signals and calibration feedback.

DO NOT let agent self-reported success become final truth without appropriate validation.

NEXT BUILD:
1. OutcomeRecord and attribution contracts.
2. Link outcomes to trace_id, workforce task, capability receipt, model profile and policy versions.
3. Delayed outcome jobs and validation sources.
4. Produce calibration feedback for Assurance and eligibility evidence for Autonomy.
5. Detect repeated failure/success patterns and emit Signal events.
6. Preserve raw evidence refs separately from synthesized lessons.
7. Tests for delayed, contradictory and partially successful outcomes.

## Universal Acceptance

- Installer/manifest validation passes.
- PHP syntax checks pass.
- Tenant boundaries are explicit.
- Cross-engine calls use public contracts/adapters.
- Significant states are traceable.
- No high-risk or authoritative mutation bypass is introduced.
