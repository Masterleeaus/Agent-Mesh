<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Extensions\TitanConnect\System\Services\ExternalHandoffService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class ExternalHandoffController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly WorkCoreAuthorizationGateway $workCore,
        private readonly ChannelAccessPolicy $policy,
        private readonly ExternalHandoffService $handoff,
    ) {
    }

    public function update(Request $request, ExternalThread $thread): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        abort_unless((int) $thread->company_id === $companyId, 404);
        $connection = $thread->connection;
        abort_unless($connection && (int) $connection->company_id === $companyId, 404);
        abort_unless($this->policy->canSend($connection, $actorId), 403);

        if ($thread->linked_entity_type !== null && $thread->linked_entity_id !== null) {
            $this->workCore->assertCanAccess($companyId, $actorId, (string) $thread->linked_entity_type, (string) $thread->linked_entity_id);
        }

        $data = $request->validate(['state' => ['required', 'in:ai,pending_human,human,resolved']]);
        return response()->json($this->handoff->setState($companyId, $actorId, $thread, (string) $data['state']));
    }
}
