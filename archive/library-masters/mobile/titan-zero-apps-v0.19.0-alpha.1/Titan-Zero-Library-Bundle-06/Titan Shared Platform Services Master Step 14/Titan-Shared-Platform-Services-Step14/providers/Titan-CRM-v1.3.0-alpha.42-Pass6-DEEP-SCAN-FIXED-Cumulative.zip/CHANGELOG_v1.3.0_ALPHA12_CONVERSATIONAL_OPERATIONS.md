# CRM 1.3.0-alpha.12 — Conversational Operations

Alpha.12 extends the Interaction-first CRM from record creation into ongoing business operations.

## Existing-record actions

Titan Zero now exposes typed Interaction Engine actions for customers, contacts, leads, opportunities, jobs, quotes, invoices, purchase orders, stock transfers, tools, fleet and maintenance. Record pages carry their current public ID into the action catalogue so conversational requests such as “reschedule this job” or “mark this vehicle serviced” resolve against the record the user is actually viewing.

## Governed action capabilities

CRM now exposes governed update/transition capabilities for contacts, leads, lead conversion, opportunities, quote lifecycle and invoice lifecycle by reusing the existing CRM repositories/services. No parallel mutation layer was introduced.

## Real autonomous execution

Allowlisted autonomous Interaction Engine sessions can now execute through the Interaction Engine `CommandMapper` and `CommandBus` after full validation. The trusted `_context`/idempotency metadata required by CommandBus is attached at the CRM boundary.

Approval-required actions remain approval-required. The conversational AI service and chain service do not use or mint `ApprovalSigner` approvals.

## Explicit multi-step chains

Only five predefined CRM chain templates are available:

- Customer → Job
- Job → Quote
- Complete Job → Invoice
- Purchase Order → Goods Receipt
- Maintenance → Fleet Status

The chain service is not an open-ended planner. It passes only approved public IDs and whitelisted workflow context into the next registered Interaction Engine journey.

## Preview-first bulk actions

Conversational bulk operations are limited to the existing tenant-scoped CRM bulk service and its supported resource/action matrix. AI can preview an explicit 1–100 record selection without mutation. Execution revalidates the exact selection and requires explicit `confirmed=true`.

The Interaction bulk planner contains no direct database-write path.
