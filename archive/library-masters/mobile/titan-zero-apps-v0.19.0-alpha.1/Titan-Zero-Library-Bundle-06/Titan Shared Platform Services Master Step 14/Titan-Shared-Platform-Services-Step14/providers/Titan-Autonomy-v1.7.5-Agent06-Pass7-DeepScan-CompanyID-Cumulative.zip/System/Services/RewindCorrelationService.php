<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\RewindBridgeContract;
use Throwable;

final class RewindCorrelationService
{
    public function __construct(private readonly RewindBridgeContract $rewind) {}

    public function record(string $eventType, array $payload): ?string
    {
        if (!$this->rewind->available()) return null;
        try {
            return $this->rewind->record($eventType, $payload);
        } catch (Throwable) {
            // Rewind correlation is additive. Canonical autonomy audit persistence
            // must not be lost when an optional timeline bridge is unhealthy.
            return null;
        }
    }
}
