<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Models;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScoped;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;

final class CrmCompany extends Model
{
    use CrmCompanyScoped, SoftDeletes;

    protected $table = 'crm_companies';
    protected $guarded = ['id'];
    protected $casts = ['meta' => 'array'];

    public function contacts(): HasMany { return $this->hasMany(CrmContact::class, 'customer_company_id'); }
    public function deals(): HasMany { return $this->hasMany(CrmDeal::class, 'customer_company_id'); }
}
