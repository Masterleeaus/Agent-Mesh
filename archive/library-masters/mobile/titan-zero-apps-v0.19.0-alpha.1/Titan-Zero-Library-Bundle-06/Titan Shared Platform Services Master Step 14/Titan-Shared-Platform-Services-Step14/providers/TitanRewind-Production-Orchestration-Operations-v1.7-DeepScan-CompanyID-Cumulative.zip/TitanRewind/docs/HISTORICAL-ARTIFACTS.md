# Titan Rewind Historical Artifacts

Rewind historical replay must refer to exact historical policy/model/knowledge/capability state rather than today's content under an old version label.

`RewindHistoricalArtifactArchive` resolves an exact artifact version, sanitizes the payload, verifies or creates a canonical SHA-256 content hash and stores the payload using Laravel's encrypted array cast. Archived artifacts are tenant/trace contextual where supplied.

Resolvers can be registered directly through `RewindManagerContract::registerHistoricalArtifactResolver()` or supplied by the host through the `titan.rewind.artifact-resolvers` container tag. Host-tagged resolvers need only expose `artifactKind()` (or `kind()`) plus `resolve(version, context)` and do not need to import Rewind internals.

A missing artifact returns `ARTIFACT_UNAVAILABLE`. A resolver-provided hash mismatch fails closed. Rewind never substitutes a newer artifact silently.
