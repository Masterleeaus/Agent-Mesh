<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Enums;

enum PrimeMissionStatus: string
{
    case Draft = 'draft';
    case Assessing = 'assessing';
    case Planned = 'planned';
    case AwaitingApproval = 'awaiting_approval';
    case Approved = 'approved';
    case Delegating = 'delegating';
    case Running = 'running';
    case Observing = 'observing';
    case Evaluating = 'evaluating';
    case Completed = 'completed';
    case Paused = 'paused';
    case Blocked = 'blocked';
    case Rejected = 'rejected';
    case Cancelled = 'cancelled';
    case Failed = 'failed';
    case Superseded = 'superseded';

    public function isTerminal(): bool
    {
        return in_array($this, [
            self::Completed,
            self::Rejected,
            self::Cancelled,
            self::Failed,
            self::Superseded,
        ], true);
    }
}
