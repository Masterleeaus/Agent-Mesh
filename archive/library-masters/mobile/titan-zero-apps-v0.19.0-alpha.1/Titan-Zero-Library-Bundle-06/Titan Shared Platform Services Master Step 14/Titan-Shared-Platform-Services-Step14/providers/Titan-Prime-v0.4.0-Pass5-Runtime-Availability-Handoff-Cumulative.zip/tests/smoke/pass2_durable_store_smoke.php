<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$files = [
    'System/Domain/Enums/PrimeMissionStatus.php',
    'System/Domain/Exceptions/InvalidMissionTransition.php',
    'System/Domain/State/PrimeMissionStateMachine.php',
    'System/Domain/ValueObjects/PrimeBudget.php',
    'System/Domain/ValueObjects/TraceContext.php',
    'System/Domain/Entities/PrimeObjective.php',
    'System/Domain/Entities/PrimeMission.php',
    'System/Persistence/Data/PrimeMissionSnapshot.php',
    'System/Persistence/Data/PrimeMissionWriteReceipt.php',
    'System/Persistence/Support/MissionOperationFingerprint.php',
];
foreach ($files as $file) {
    require_once $root . '/' . $file;
}

use App\Extensions\TitanPrime\System\Domain\Entities\PrimeMission;
use App\Extensions\TitanPrime\System\Domain\Entities\PrimeObjective;
use App\Extensions\TitanPrime\System\Domain\Enums\PrimeMissionStatus;
use App\Extensions\TitanPrime\System\Domain\ValueObjects\PrimeBudget;
use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Persistence\Data\PrimeMissionSnapshot;
use App\Extensions\TitanPrime\System\Persistence\Data\PrimeMissionWriteReceipt;
use App\Extensions\TitanPrime\System\Persistence\Support\MissionOperationFingerprint;

$mission = PrimeMission::reconstitute(
    missionId: 'mission-001',
    trace: new TraceContext(7, 'trace-1', 'corr-1', null, 'trace-1'),
    objective: new PrimeObjective('growth', 'Increase pipeline', 'More qualified opportunities', ['pipeline +10%']),
    budget: new PrimeBudget(maxCostMinor: 25000, maxRiskScore: 0.4),
    initiatedByType: 'user',
    initiatedById: '11',
    status: PrimeMissionStatus::Planned,
);

$snapshot = new PrimeMissionSnapshot($mission, 4);
if ($snapshot->version !== 4 || $snapshot->mission->status() !== PrimeMissionStatus::Planned) {
    throw new RuntimeException('Snapshot did not preserve persisted mission state.');
}

$createA = MissionOperationFingerprint::create($mission);
$createB = MissionOperationFingerprint::create($mission);
if ($createA !== $createB || strlen($createA) !== 64) {
    throw new RuntimeException('Create fingerprint must be deterministic SHA-256.');
}

$transition = MissionOperationFingerprint::transition('mission-001', PrimeMissionStatus::Planned, PrimeMissionStatus::AwaitingApproval, 4);
if ($transition === $createA || strlen($transition) !== 64) {
    throw new RuntimeException('Transition fingerprint must identify a different operation payload.');
}

$receipt = new PrimeMissionWriteReceipt(7, 'op-1', 'mission-001', 'transition', 5, 'awaiting_approval', $transition, false);
if (!$receipt->asReplay()->replayed || $receipt->replayed) {
    throw new RuntimeException('Replay receipts must be explicit and immutable.');
}

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
if (!in_array('prime.mission.persistence', $manifest['capabilities'] ?? [], true)) {
    throw new RuntimeException('Manifest must declare prime.mission.persistence.');
}
if (!in_array('titan_prime_mission_operations', $manifest['database']['owned_tables'] ?? [], true)) {
    throw new RuntimeException('Manifest must own titan_prime_mission_operations.');
}

$repository = (string) file_get_contents($root . '/System/Persistence/Repositories/DatabasePrimeMissionRepository.php');
foreach (['tenant_company_id', 'lock_version', 'operation_id', 'payload_hash'] as $needle) {
    if (!str_contains($repository, $needle)) {
        throw new RuntimeException('Repository missing durable-store invariant: ' . $needle);
    }
}

fwrite(STDOUT, "PASS durable mission store smoke\n");
