<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Forensics\RewindIntegrityHasher;
use App\Extensions\TitanRewind\System\Models\RewindIntegrityCheck;
use App\Extensions\TitanRewind\System\Models\RewindTraceEvent;
use App\Extensions\TitanRewind\System\Models\RewindTraceIndex;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Observability\RewindTraceContext;
use Illuminate\Support\Str;

final class RewindIntegrityService
{
    public function __construct(private RewindIntegrityHasher $hasher, private RewindTelemetryService $telemetry, private RewindSignalOutboxService $signals) {}

    public function inspectTrace(RewindTraceQuery $query): array
    {
        $events = RewindTraceEvent::query()
            ->where('tenant_company_id', $query->tenantCompanyId())
            ->where('trace_id', $query->traceId())
            ->orderByRaw('CASE WHEN chain_position IS NULL THEN 1 ELSE 0 END')
            ->orderBy('chain_position')->orderBy('id')
            ->cursor();

        return $this->inspectEvents($events);
    }

    public function inspectEvents(iterable $events): array
    {
        $count=0;$unsealed=0;$sealedCount=0;$failureCount=0;$failures=[];
        $expectedPosition=1;$previousChainHash=null;
        foreach($events as $event){
            ++$count;$data=$event instanceof RewindTraceEvent?$event->toArray():(array)$event;
            $canonicalHash=trim((string)($data['canonical_hash']??''));$chainHash=trim((string)($data['chain_hash']??''));$position=(int)($data['chain_position']??0);
            if($canonicalHash===''||$chainHash===''||$position<1){++$unsealed;continue;}
            ++$sealedCount;$eventId=(string)($data['event_id']??'');$computedCanonical=$this->hasher->contentHash($data);
            $contentOk=hash_equals(strtolower($canonicalHash),strtolower($computedCanonical));$positionOk=$position===$expectedPosition;
            $storedPrevious=($data['chain_previous_hash']??null)===null?null:trim((string)$data['chain_previous_hash']);$previousOk=$storedPrevious===$previousChainHash;
            $computedChain=$this->hasher->chainHash($previousChainHash,$computedCanonical,$eventId,$position);$chainOk=hash_equals(strtolower($chainHash),strtolower($computedChain));
            if(!$contentOk||!$positionOk||!$previousOk||!$chainOk){++$failureCount;if(count($failures)<100)$failures[]=['event_id'=>$eventId,'chain_position'=>$position,'content_hash_ok'=>$contentOk,'position_ok'=>$positionOk,'previous_chain_hash_ok'=>$previousOk,'chain_hash_ok'=>$chainOk];}
            $previousChainHash=$chainHash;$expectedPosition=$position+1;
        }
        $status=$failureCount>0?'failed':($unsealed>0?'partial':($count>0?'passed':'empty'));
        return ['status'=>$status,'events_checked'=>$count,'sealed_count'=>$sealedCount,'unsealed_count'=>$unsealed,'failures_count'=>$failureCount,'failures'=>$failures,'chain_scope'=>'tenant_trace_ingestion_order','content_hash_algorithm'=>'sha256_canonical_json','chain_hash_algorithm'=>'sha256_canonical_json','streaming'=>true];
    }

    public function verifyTrace(RewindTraceQuery $query, ?int $checkedById = null): RewindIntegrityCheck
    {
        $started = now();
        $result = $this->inspectTrace($query);

        $check = RewindIntegrityCheck::query()->create([
            'check_uuid'=>(string) Str::uuid(),
            'tenant_company_id'=>$query->tenantCompanyId(),
            'trace_id'=>$query->traceId(),
            'check_type'=>'event_chain',
            'status'=>$result['status'],
            'checked_by_id'=>$checkedById,
            'events_checked'=>$result['events_checked'],
            'failures_count'=>$result['failures_count'],
            'unsealed_count'=>$result['unsealed_count'],
            'result'=>$result,
            'started_at'=>$started,
            'finished_at'=>now(),
        ]);

        RewindTraceEvent::query()
            ->where('tenant_company_id',$query->tenantCompanyId())
            ->where('trace_id',$query->traceId())
            ->whereNotNull('canonical_hash')
            ->update(['integrity_checked_at'=>now()]);

        $index = RewindTraceIndex::query()
            ->where('tenant_company_id',$query->tenantCompanyId())
            ->where('trace_id',$query->traceId())
            ->first();
        if ($index !== null) {
            $forensicState = $result['status'] === 'failed'
                ? 'critical'
                : ($result['status'] === 'partial' || (int) $index->open_drift_count > 0 ? 'review' : 'clear');
            $index->forceFill([
                'integrity_state'=>$result['status'],
                'forensic_state'=>$forensicState,
                'last_integrity_check_at'=>now(),
            ])->save();
        }

        $fresh=$check->refresh();
        $ctx=RewindTraceContext::fromArray(['tenant_company_id'=>$query->tenantCompanyId(),'trace_id'=>$query->traceId(),'correlation_id'=>$query->correlationId() ?: $query->traceId(),'causation_id'=>null]);
        $this->telemetry->metric('rewind.integrity.failures',(int)$result['failures_count'],'count',$ctx,['status'=>$result['status'],'events_checked'=>$result['events_checked']]);
        $eventType=$result['status']==='failed'?'rewind.integrity.failed.v1':'rewind.integrity.verified.v1';
        $this->signals->emit($eventType,$ctx,['check_uuid'=>$fresh->check_uuid,'status'=>$fresh->status,'events_checked'=>(int)$fresh->events_checked,'failures_count'=>(int)$fresh->failures_count],$result['status']==='failed'?'ERROR':'INFO');
        return $fresh;
    }

    public function latest(RewindTraceQuery $query): ?RewindIntegrityCheck
    {
        return RewindIntegrityCheck::query()
            ->where('tenant_company_id',$query->tenantCompanyId())
            ->where('trace_id',$query->traceId())
            ->latest('id')
            ->first();
    }
}
