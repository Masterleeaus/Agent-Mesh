<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Http\Middleware;

use App\Extensions\TitanNexus\System\Host\TitanHostAuthorizationAdapter;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class TitanNexusAuthorizationMiddleware
{
    public function __construct(private readonly TitanHostAuthorizationAdapter $authorization) {}

    public function handle(Request $request, Closure $next, string $permission = 'titan-nexus.view'): Response
    {
        $user = $request->user();
        $delegated = config('titan-nexus.authorization.delegated_admin_permissions', []);
        $delegated = is_array($delegated) ? array_values(array_filter($delegated, 'is_string')) : [];
        if (!is_object($user) || !$this->authorization->allows($user, $permission, $delegated)) {
            abort(403, 'Titan Nexus access denied.');
        }
        return $next($request);
    }
}
