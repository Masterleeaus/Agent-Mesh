# Uninstall

Default policy retains Nexus-owned durable state. The uninstall hook removes published configuration only. Destructive tenant-data removal must follow host retention/legal-hold policy rather than being performed implicitly by extension uninstall.
