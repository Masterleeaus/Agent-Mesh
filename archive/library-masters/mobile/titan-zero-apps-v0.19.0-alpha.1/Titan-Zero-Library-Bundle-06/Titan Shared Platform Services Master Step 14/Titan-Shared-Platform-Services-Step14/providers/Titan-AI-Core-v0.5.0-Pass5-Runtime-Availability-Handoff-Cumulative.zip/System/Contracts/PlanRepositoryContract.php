<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Contracts;

use App\Extensions\TitanAICore\System\DTO\PlanEnvelope;
use App\Extensions\TitanAICore\System\DTO\RuntimeContext;

interface PlanRepositoryContract
{
    /** @return array<string,mixed>|null */
    public function findForTenant(string $tenantCompanyId, string $planId): ?array;

    public function storeForTenant(RuntimeContext $runtimeContext, PlanEnvelope $plan, string $status = 'draft'): void;
}
