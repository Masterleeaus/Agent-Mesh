<?php

declare(strict_types=1);

use App\Domains\Marketplace\Http\Middleware\NewExtensionInstalled;
use App\Http\Middleware\ViewSharedMiddleware;
use App\Extensions\TitanConnect\System\Http\Controllers\AdminChannelSettingsController;
use App\Extensions\TitanConnect\System\Http\Controllers\ChannelSettingsController;
use App\Extensions\TitanConnect\System\Http\Controllers\InboxNavigationController;
use App\Extensions\TitanConnect\System\Http\Controllers\ProviderOnboardingController;
use App\Extensions\TitanConnect\System\Http\Controllers\TitanConnectSettingsController;
use App\Extensions\TitanConnect\System\Http\Controllers\TeamChat\BusinessChannelController;
use App\Extensions\TitanConnect\System\Http\Controllers\TeamChat\TeamConversationController;
use App\Extensions\TitanConnect\System\Http\Controllers\TeamChat\TeamMembershipController;
use App\Extensions\TitanConnect\System\Http\Controllers\TeamChat\TeamMessageController;
use App\Extensions\TitanConnect\System\Http\Controllers\TeamChat\TeamRealtimeController;
use App\Extensions\TitanConnect\System\Http\Controllers\VoiceCallController;
use App\Extensions\TitanConnect\System\Http\Middleware\EnsureCompanyRouteBindings;
use Illuminate\Support\Facades\Route;

// Canonical MagicAI/Titan user-dashboard routes. These are the only routes persisted into
// the user navigation catalogue so Inbox and Channels render in the normal dashboard shell.
Route::middleware(['web', ViewSharedMiddleware::class, NewExtensionInstalled::class, 'auth', 'updateUserActivity', EnsureCompanyRouteBindings::class])
    ->prefix('dashboard/user/titan-connect')
    ->as('dashboard.user.titan-connect.')
    ->group(function (): void {
        Route::get('inbox', [InboxNavigationController::class, 'root'])->name('inbox.index');
        foreach (['unified', 'team', 'external', 'mine', 'unassigned', 'needs_human', 'closed'] as $mode) {
            Route::get('inbox/'.$mode, [InboxNavigationController::class, 'show'])->defaults('mode', $mode)->name('inbox.'.$mode);
        }
        Route::get('inbox/{mode}', [InboxNavigationController::class, 'show'])->name('inbox.mode');

        Route::get('channels', [ChannelSettingsController::class, 'index'])->name('channels.index');
        foreach (['whatsapp', 'messenger', 'instagram', 'telegram', 'sms', 'voice', 'push'] as $provider) {
            Route::get('channels/'.$provider, [ChannelSettingsController::class, 'show'])->defaults('provider', $provider)->name('channels.'.$provider);
        }
        Route::get('channels/{provider}', [ChannelSettingsController::class, 'show'])->name('channels.show');

        Route::get('settings', [TitanConnectSettingsController::class, 'index'])->name('settings.index');
        Route::get('onboarding/meta/{provider}', [ProviderOnboardingController::class, 'metaStart'])->name('onboarding.meta.start');
        Route::get('onboarding/meta/{provider}/callback', [ProviderOnboardingController::class, 'metaCallback'])->name('onboarding.meta.callback');
        Route::get('voice/{call}', [VoiceCallController::class, 'show'])->name('voice.show');
    });

// Backward-compatible routes retained for existing bookmarks, OAuth callback configuration,
// older JS and third-party callers. They render the same dashboard-wrapped views but are never
// materialized as the canonical sidebar destinations.
Route::middleware(['web', ViewSharedMiddleware::class, NewExtensionInstalled::class, 'auth', 'updateUserActivity', EnsureCompanyRouteBindings::class])
    ->prefix('dashboard/titan-connect')
    ->group(function (): void {
        Route::get('inbox', [InboxNavigationController::class, 'root'])->name('titan-connect.inbox');
        foreach (['unified', 'team', 'external', 'mine', 'unassigned', 'needs_human', 'closed'] as $mode) {
            Route::get('inbox/'.$mode, [InboxNavigationController::class, 'show'])->defaults('mode', $mode)->name('titan-connect.inbox.'.$mode);
        }
        Route::get('inbox/{mode}', [InboxNavigationController::class, 'show'])->name('titan-connect.inbox.mode');
        Route::get('channels', [ChannelSettingsController::class, 'index'])->name('titan-connect.channels.index');
        foreach (['whatsapp', 'messenger', 'instagram', 'telegram', 'sms', 'voice', 'push'] as $provider) {
            Route::get('channels/'.$provider, [ChannelSettingsController::class, 'show'])->defaults('provider', $provider)->name('titan-connect.channels.'.$provider);
        }
        Route::get('channels/{provider}', [ChannelSettingsController::class, 'show'])->name('titan-connect.channels.show');
        Route::get('settings', [TitanConnectSettingsController::class, 'index'])->name('titan-connect.settings');
        Route::get('onboarding/meta/{provider}', [ProviderOnboardingController::class, 'metaStart'])->name('titan-connect.onboarding.meta.start');
        Route::get('onboarding/meta/{provider}/callback', [ProviderOnboardingController::class, 'metaCallback'])->name('titan-connect.onboarding.meta.callback');
        Route::get('voice/{call}', [VoiceCallController::class, 'show'])->name('titan-connect.voice.show');
    });

Route::middleware(['web', ViewSharedMiddleware::class, NewExtensionInstalled::class, 'auth', 'updateUserActivity', EnsureCompanyRouteBindings::class])
    ->prefix('dashboard/titan-connect/team')
    ->as('titan-connect.team.')
    ->group(function (): void {
        Route::get('conversations', [TeamConversationController::class, 'index'])->name('conversations.index');
        Route::post('conversations', [TeamConversationController::class, 'store'])->name('conversations.store');
        Route::get('conversations/{conversation}', [TeamConversationController::class, 'show'])->name('conversations.show');
        Route::patch('conversations/{conversation}', [TeamConversationController::class, 'update'])->name('conversations.update');
        Route::post('conversations/{conversation}/leave', [TeamConversationController::class, 'leave'])->name('conversations.leave');
        Route::patch('conversations/{conversation}/archive', [TeamConversationController::class, 'archive'])->name('conversations.archive');
        Route::get('conversations/{conversation}/messages', [TeamMessageController::class, 'index'])->name('messages.index');
        Route::post('conversations/{conversation}/messages', [TeamMessageController::class, 'store'])->name('messages.store');
        Route::post('messages/{message}/read', [TeamMessageController::class, 'read'])->name('messages.read');
        Route::post('conversations/{conversation}/typing', [TeamRealtimeController::class, 'typing'])->name('typing');
        Route::post('conversations/{conversation}/participants', [TeamMembershipController::class, 'store'])->name('participants.store');
        Route::patch('conversations/{conversation}/participants/{participant}', [TeamMembershipController::class, 'update'])->name('participants.update');
        Route::delete('conversations/{conversation}/participants/{participant}', [TeamMembershipController::class, 'destroy'])->name('participants.destroy');
        Route::get('channels', [BusinessChannelController::class, 'index'])->name('channels.index');
        Route::post('channels', [BusinessChannelController::class, 'store'])->name('channels.store');
        Route::patch('channels/{conversation}', [BusinessChannelController::class, 'update'])->name('channels.update');
        Route::post('channels/{conversation}/join', [BusinessChannelController::class, 'join'])->name('channels.join');
        Route::patch('channels/{conversation}/archive', [BusinessChannelController::class, 'archive'])->name('channels.archive');
    });

Route::middleware(['web', ViewSharedMiddleware::class, NewExtensionInstalled::class, 'auth', 'updateUserActivity', 'admin'])
    ->prefix('dashboard/admin/titan-connect/channels')
    ->group(function (): void {
        Route::get('/', [AdminChannelSettingsController::class, 'index'])->name('titan-connect.admin.channels.index');
        foreach (['whatsapp', 'messenger', 'instagram', 'telegram', 'sms', 'voice', 'push'] as $provider) {
            Route::get($provider, [AdminChannelSettingsController::class, 'show'])->defaults('provider', $provider)->name('titan-connect.admin.channels.'.$provider);
        }
        Route::get('{provider}', [AdminChannelSettingsController::class, 'show'])->name('titan-connect.admin.channels.show');
    });

// Older database-backed MagicAI hosts authorize administrator routes through the existing
// Settings menu/permission family. Only one Settings entry is materialized on those hosts.
Route::middleware(['web', ViewSharedMiddleware::class, NewExtensionInstalled::class, 'auth', 'updateUserActivity', 'admin'])
    ->prefix('dashboard/admin/settings/titan-connect/channels')
    ->group(function (): void {
        Route::get('/', [AdminChannelSettingsController::class, 'index'])->name('dashboard.admin.settings.titan-connect.channels.index');
        foreach (['whatsapp', 'messenger', 'instagram', 'telegram', 'sms', 'voice', 'push'] as $provider) {
            Route::get($provider, [AdminChannelSettingsController::class, 'show'])
                ->defaults('provider', $provider)
                ->name('dashboard.admin.settings.titan-connect.channels.'.$provider);
        }
        Route::get('{provider}', [AdminChannelSettingsController::class, 'show'])->name('dashboard.admin.settings.titan-connect.channels.show');
    });
