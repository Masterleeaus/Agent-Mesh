<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Sources;

use InvalidArgumentException;

final class RewindSourceCompleteness
{
    private const RANK = ['COMPLETE'=>0,'PARTIAL'=>1,'STALE'=>2,'UNAVAILABLE'=>3];
    public function __construct(private int $maxAgeSeconds = 900) { $this->maxAgeSeconds=max(1,$this->maxAgeSeconds); }

    /** @param list<array<string,mixed>> $sources */
    public function evaluate(array $sources): array
    {
        if ($sources === []) return ['state'=>'PARTIAL','complete_for_audit'=>false,'sources'=>[],'reason'=>'no-source-watermarks'];
        $worst = 'COMPLETE';
        $authenticityComplete = true;
        foreach ($sources as $source) {
            $state = strtoupper((string) ($source['state'] ?? 'UNAVAILABLE'));
            if (!array_key_exists($state, self::RANK)) throw new InvalidArgumentException("Invalid Rewind source completeness state: {$state}");
            $observed=$source['observed_through'] ?? null;
            if ($state === 'COMPLETE') {
                if (!is_string($observed) || trim($observed)==='') { $state='PARTIAL'; }
                else { try { $age=time()-(new \DateTimeImmutable($observed))->getTimestamp(); if ($age > $this->maxAgeSeconds) $state='STALE'; } catch (\Throwable) { $state='PARTIAL'; } }
            }
            if (self::RANK[$state] > self::RANK[$worst]) $worst = $state;
            $auth = strtoupper((string) (($source['metadata']['authenticity_state'] ?? '') ?: 'UNKNOWN'));
            if ($auth !== '' && !in_array($auth, ['VERIFIED','AUTHENTIC'], true)) $authenticityComplete = false;
        }
        return ['state'=>$worst,'complete_for_audit'=>$worst === 'COMPLETE' && $authenticityComplete,'authenticity_complete'=>$authenticityComplete,'sources'=>$sources];
    }
}
