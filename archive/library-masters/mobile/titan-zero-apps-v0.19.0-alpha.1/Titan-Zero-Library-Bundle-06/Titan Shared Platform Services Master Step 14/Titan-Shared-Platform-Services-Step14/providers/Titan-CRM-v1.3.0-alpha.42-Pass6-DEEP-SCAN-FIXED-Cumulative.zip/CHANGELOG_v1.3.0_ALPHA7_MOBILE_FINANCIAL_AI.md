# CRM 1.3.0-alpha.7 — Mobile Suite & AI Financial Assistants

## Titan Mobile clean identities

CRM now targets the clean mobile-suite technical contracts:

- `TitanHub` — customer app / Customer Hub
- `TitanGo` — field/worker app
- `TitanBOS` — owner/business app

Legacy runtime contract references to `TitanCustomer`, `TitanFieldOffline` and `TitanOwnerPWA` were removed from the active Titan Mobile integration layer. Titan Mobile compatibility is now `>=0.20 <1.0`.

## CRM-native Financial Assistants

The deterministic Titan Financial Engine has been absorbed into CRM. CRM does not depend on the standalone Financial Engine extension at runtime.

Seventeen deterministic calculators are available:

1. Formula Rules
2. Labour Rate
3. Procurement / Landed Cost
4. Inventory / Materials Cost
5. Asset / Fleet / Equipment Cost
6. Job Costing
7. Pricing
8. Quote & Estimate
9. Discount / Promotion
10. Margin & Profitability
11. Tax / GST
12. Recurring Pricing
13. Payment / Settlement Cost
14. Commission / Incentive
15. Finance / Instalment
16. Cash Flow Forecast
17. Break-Even Scenario

All authoritative financial arithmetic stays in deterministic CRM calculators using the donor engine's fixed-point/decimal rules.

## AI guidance boundary

MagicAI/TitanAI is the guidance and orchestration layer. It may:

- interpret plain-English intent
- inspect permitted CRM context
- gather known customer/job/material/time facts
- identify missing inputs
- ask follow-up questions
- compare scenarios
- explain margin, tax and cost drivers
- recommend values

AI must not invent authoritative financial results. Tax/GST, price, margin, labour, material, landed-cost, instalment, cash-flow and break-even numbers are produced by the deterministic calculators.

Read-only calculations can be returned directly. Applying recommendations to CRM records remains a governed write and follows the existing approval flow.

## Embedded Quote / Estimate Assistant

Quote and estimate creation now includes an embedded **Financial AI Assistant**. It can use known CRM/Gear job-material context, recorded job time, labour/material/equipment/travel/other cost inputs, target margin and GST rate to produce:

- cost base
- suggested pre-tax sell price
- margin check
- GST/tax amount
- customer total

The result can be applied to the first unsaved quote line only; the normal CRM form must still be reviewed and saved by the user.

The same panel links into the CRM Assistant with a finance-specific scope so AI can help gather missing facts and explain the result.

## Contextual assistants

Financial AI entry points now appear contextually rather than as 17 permanent menu items:

- **Leads / Quotes:** Quote, Pricing, Margin, Discount, GST, Labour, Materials
- **Work:** Job Costing, Profitability, Labour, Materials, Asset/Fleet/Equipment
- **Money:** GST, Payment Fees, Instalments, Cash Flow, Break-Even
- **Crew:** Labour Rate, Commission/Incentive
- **Gear:** Materials Cost, Landed Cost, Asset/Fleet/Equipment Cost

## Field & home service terminology

Current user-facing navigation now uses:

- Sales → **Leads**
- Deals → **Opportunities**
- Proposals → **Quotes**
- Work Orders → **Jobs**
- Customer Portal → **Customer Hub**

Stable route/table identifiers are intentionally retained where renaming them would create migration risk. Migration `000022` refreshes existing host menu rows during upgrade.

## Safety / compatibility

- Tenant boundary remains `tenant_company_id`.
- CRM `company_id` remains the customer/account company relationship.
- AI financial calculation capabilities are read-only.
- No `TitanFinancialEngine` runtime dependency remains.
- No legacy Titan Mobile technical namespace remains in active Titan Mobile integration code.
- Existing alpha.3 provider-stage protection and alpha.4/alpha.5/alpha.6 MySQL/restartability protections are preserved.
