<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Enums;

enum AuthorityClass: string
{
    case Legislation = 'legislation';
    case Regulation = 'regulation';
    case RegulatorDirection = 'regulator-direction';
    case MandatoryStandard = 'mandatory-standard';
    case OfficialGuidance = 'official-guidance';
    case ContractualRequirement = 'contractual-requirement';
    case ManufacturerRequirement = 'manufacturer-requirement';
    case ApprovedInternalPolicy = 'approved-internal-policy';
    case LicensedReference = 'licensed-reference';
    case IndustryGuidance = 'industry-guidance';
    case InformationalReference = 'informational-reference';
    case Unknown = 'unknown';
}
