<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

final readonly class TraceEvaluationPolicy
{
    public function __construct(
        public int $partialRetrySeconds = 60,
        public int $openRetrySeconds = 300,
        public int $terminalDelaySeconds = 5,
        public int $invalidRetrySeconds = 900,
    ) {
    }

    public function delaySeconds(string $status, bool $terminalSeen, bool $historyPartial): int
    {
        if ($historyPartial || $status === 'partial') {
            return max(1, $this->partialRetrySeconds);
        }
        if ($status === 'invalid') {
            return max(1, $this->invalidRetrySeconds);
        }
        if ($status === 'complete' && $terminalSeen) {
            return 0;
        }
        if ($terminalSeen) {
            return max(1, $this->terminalDelaySeconds);
        }
        return max(1, $this->openRetrySeconds);
    }

    public function isTerminalClosed(string $status, bool $terminalSeen, bool $historyPartial): bool
    {
        return $status === 'complete' && $terminalSeen && ! $historyPartial;
    }
}
