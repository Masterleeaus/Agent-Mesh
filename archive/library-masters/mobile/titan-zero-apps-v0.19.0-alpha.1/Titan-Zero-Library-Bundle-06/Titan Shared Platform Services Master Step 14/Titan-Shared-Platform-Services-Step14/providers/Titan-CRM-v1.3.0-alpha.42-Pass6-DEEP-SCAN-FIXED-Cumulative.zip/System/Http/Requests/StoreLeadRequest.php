<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
final class StoreLeadRequest extends FormRequest {
 public function authorize(): bool { return true; }
 public function rules(): array { return ['name'=>['required','string','max:190'],'email'=>['nullable','email','max:190','required_without:phone'],'phone'=>['nullable','string','max:60','required_without:email'],'company_name'=>['nullable','string','max:190'],'notes'=>['nullable','string','max:5000'],'status'=>['nullable','string','max:40'],'source'=>['nullable','string','max:80'],'owner_user_id'=>['nullable','integer','min:1'],'priority'=>['nullable','integer','between:0,100'],'follow_up_at'=>['nullable','date']]; }
}
