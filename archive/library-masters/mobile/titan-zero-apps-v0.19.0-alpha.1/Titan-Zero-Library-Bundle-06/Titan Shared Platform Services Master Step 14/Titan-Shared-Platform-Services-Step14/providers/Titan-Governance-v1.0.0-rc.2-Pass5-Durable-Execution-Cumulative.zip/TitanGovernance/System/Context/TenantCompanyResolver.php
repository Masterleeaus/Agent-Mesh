<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Context;

use RuntimeException;

final class TenantCompanyResolver
{
    public function resolve(object $user): int
    {
        foreach([$user->tenant_company_id??null,$user->company_id??null,$user->currentTeam->tenant_company_id??null,$user->currentTeam->company_id??null] as $candidate){
            if(is_numeric($candidate) && (int)$candidate>0) return (int)$candidate;
        }
        throw new RuntimeException('Unable to resolve explicit tenant_company_id for Titan Governance.');
    }
}
