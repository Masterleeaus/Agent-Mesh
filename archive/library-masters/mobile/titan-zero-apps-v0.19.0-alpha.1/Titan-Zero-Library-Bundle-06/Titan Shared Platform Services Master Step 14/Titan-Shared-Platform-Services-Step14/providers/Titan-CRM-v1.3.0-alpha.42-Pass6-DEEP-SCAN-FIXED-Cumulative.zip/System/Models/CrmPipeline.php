<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Models;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScoped;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;

final class CrmPipeline extends Model
{
    use CrmCompanyScoped, SoftDeletes;

    protected $table = 'crm_pipelines';
    protected $guarded = ['id'];
    protected $casts = ['is_default' => 'boolean', 'is_active' => 'boolean'];

    public function stages(): HasMany { return $this->hasMany(CrmPipelineStage::class, 'pipeline_id')->orderBy('position'); }
    public function deals(): HasMany { return $this->hasMany(CrmDeal::class, 'pipeline_id'); }
}
