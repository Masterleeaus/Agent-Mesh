# Titan Connect v0.10.6 Host Certification

Standalone verification cannot prove the real Titan Zero/MagicAI MySQL schema, auth guard, queue workers, scheduler, asset publishing, browser environment, broadcast stack, cache topology or live provider credentials. Run this suite in a non-production clone of the actual host.

## Prerequisites

1. Back up the host database/files.
2. Use production-equivalent PHP/Laravel/MySQL versions.
3. Confirm every Titan Connect staff user has a positive `users.company_id`.
4. Run all Titan Connect migrations, including migrations `000004` and `000005`.
5. Publish Titan Connect assets/config and run `php artisan titan-connect:host-sync`.
6. Use provider sandbox/test credentials only.
7. In multi-node deployments use a shared cache store because authenticated rate limit counters must be consistent across nodes.

## Host readiness diagnostic

Run this before the feature suite:

```bash
php artisan titan-connect:diagnose
```

For automation:

```bash
php artisan titan-connect:diagnose --json
```

The command checks MySQL, `users.company_id`, all company-scoped Titan Connect tables, queue/cache/broadcast configuration, attachment storage and attachment-scanner binding. Hard blockers return a non-zero exit code; warnings identify development-style settings such as `sync` queue, non-shared cache or null/log broadcasting.

## Company-boundary suite

```bash
TITAN_CONNECT_HOST_CERTIFICATION=1 php artisan test App/Extensions/TitanConnect/tests/Feature/HostCertification/CompanyBoundaryTest.php
```

The suite verifies `users.company_id`, canonical table company scope, `forCompany()` isolation, immutable ownership, cross-company route binding denial, company/UUID/provider queue identity, company-namespaced attachment storage, company/actor rate limit isolation, the voice transcript idempotency column, stable provider registration key, user/admin route registration, diagnose/certify commands and `titan-connect:host-sync` registration.

## Runtime smoke checks

```bash
php artisan migrate:status
php artisan titan-connect:host-sync
php artisan route:list --name=titan-connect
php artisan schedule:list
php artisan queue:work --once
php artisan titan-connect:diagnose
```

Then validate two companies in parallel:

- internal/team messages and realtime events;
- operator inbox search/filter/assignment/tags/internal notes/canned replies/exports;
- Settings and connection diagnostics, including health checks and pause/activate actions;
- authenticated send/admin/upload/AI/voice rate limit responses and `Retry-After` headers;
- Meta OAuth Messenger/Instagram onboarding with separate company accounts;
- Telegram `setWebhook` registration;
- Meta WhatsApp and Twilio WhatsApp send/receive/receipts;
- SMS, Messenger, Instagram and Telegram webhooks;
- inbound/outbound media and signed downloads;
- OpenAI Realtime and ElevenLabs voice calls/transcripts;
- duplicate voice transcript events using the same `client_event_id` do not create duplicate rows;
- ended voice calls reject new transcript/session work;
- WorkCore authorization and Chatbot/MobileCore bridge events;
- retry/scheduler behaviour.

No inbox item, contact, tag, credential, rate-limit key, diagnostic record, webhook, delivery, attachment, voice call/transcript, audit record or realtime channel may cross company boundaries.

## Production gate

Do not mark Titan Connect production-certified until the MySQL suite plus queue/scheduler/realtime/provider sandbox and voice smoke tests have been recorded on the real host build.

## Executable certification

Titan Connect includes one credential-free host certification command:

```bash
php artisan titan-connect:certify
```

The default command is read-only and reports database/schema, queue/cache/broadcast configuration, attachment storage/scanner status, and host integration bindings. It does not send provider traffic.

Run explicit runtime probes in staging:

```bash
php artisan titan-connect:certify \
  --queue-probe \
  --broadcast-probe \
  --two-company-probe \
  --timeout=15 \
  --output=storage/logs/titan-connect-certification.json
```

- `--queue-probe` dispatches a cache-only job and waits for an asynchronous worker acknowledgement.
- `--broadcast-probe` publishes an isolated `titan-connect.certification.*` event through the configured broadcast driver. Client subscription receipt still needs an end-to-end browser/mobile smoke test.
- `--two-company-probe` creates representative Titan Connect rows inside one database transaction, verifies `forCompany()` isolation in both directions, and always rolls the transaction back.
- `--strict` treats warnings (for example a missing optional bridge or a sync queue) as certification failures.
- `--json` prints the report as JSON. `--output=` persists the same credential-free JSON report for release evidence.

For production-equivalent certification, use both the existing PHPUnit host suite and the executable runtime command:

```bash
TITAN_CONNECT_HOST_CERTIFICATION=1 php artisan test App/Extensions/TitanConnect/tests/Feature/HostCertification/CompanyBoundaryTest.php
php artisan titan-connect:certify --queue-probe --broadcast-probe --two-company-probe --strict
```
