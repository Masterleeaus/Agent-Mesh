<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Security;

final class CrmPermissionCatalog
{
    public const ALL = [
        'crm.contacts.view','crm.contacts.create','crm.contacts.update','crm.contacts.delete',
        'crm.companies.view','crm.companies.create','crm.companies.update','crm.companies.delete',
        'crm.leads.view','crm.leads.create','crm.leads.update','crm.leads.convert',
        'crm.deals.view','crm.deals.create','crm.deals.update','crm.deals.move','crm.deals.close',
        'crm.activities.view','crm.activities.create','crm.projects.manage','crm.tasks.manage','crm.calendar.manage',
        'crm.sales.view','crm.sales.manage','crm.import','crm.export','crm.settings','crm.automations.manage','crm.portal.manage',
        'crm.audit.view','crm.notifications.manage','crm.metadata.manage','crm.duplicates.merge','crm.bulk.manage',
        'crm.integrations.manage','crm.webhooks.manage','crm.api_keys.manage','crm.privacy.manage','crm.sharing.manage',
        'crm.services.view','crm.services.manage','crm.invoices.view','crm.invoices.manage',
        'crm.business.configure','crm.staff.manage','crm.owner.actions','crm.finance_assistants.use',
    ];

    public const TOOL_MAP = [
        'crm_search_contacts'=>'crm.contacts.view','crm_search_companies'=>'crm.companies.view','crm_search_leads'=>'crm.leads.view',
        'crm_list_pipelines'=>'crm.deals.view','crm_view_pipeline_board'=>'crm.deals.view','crm_search_deals'=>'crm.deals.view',
        'crm_list_activities'=>'crm.activities.view','crm_get_dashboard'=>'crm.deals.view','crm_get_analytics'=>'crm.deals.view',
        'crm_get_timeline'=>'crm.activities.view','crm_search_projects'=>'crm.projects.manage','crm_search_tasks'=>'crm.tasks.manage',
        'crm_search_calendar'=>'crm.calendar.manage','crm_search_sales_documents'=>'crm.sales.view','crm_get_follow_ups'=>'crm.leads.view','crm_get_forecast'=>'crm.deals.view','crm_find_duplicates'=>'crm.contacts.view','crm_get_source_conversion'=>'crm.deals.view','crm_get_stale_pipeline'=>'crm.deals.view','crm_create_company'=>'crm.companies.create',
        'crm_create_contact'=>'crm.contacts.create','crm_create_lead'=>'crm.leads.create','crm_create_deal'=>'crm.deals.create',
        'crm_move_deal'=>'crm.deals.move','crm_record_activity'=>'crm.activities.create','crm_create_note'=>'crm.activities.create',
        'crm_create_project'=>'crm.projects.manage','crm_create_task'=>'crm.tasks.manage','crm_create_calendar_event'=>'crm.calendar.manage',
        'crm_finance_formula_rules_calculate'=>'crm.finance_assistants.use',
        'crm_finance_pricing_calculate'=>'crm.finance_assistants.use',
        'crm_finance_quote_estimate_calculate'=>'crm.finance_assistants.use',
        'crm_finance_discount_promotion_calculate'=>'crm.finance_assistants.use',
        'crm_finance_margin_profitability_calculate'=>'crm.finance_assistants.use',
        'crm_finance_tax_calculate'=>'crm.finance_assistants.use',
    ];
}
