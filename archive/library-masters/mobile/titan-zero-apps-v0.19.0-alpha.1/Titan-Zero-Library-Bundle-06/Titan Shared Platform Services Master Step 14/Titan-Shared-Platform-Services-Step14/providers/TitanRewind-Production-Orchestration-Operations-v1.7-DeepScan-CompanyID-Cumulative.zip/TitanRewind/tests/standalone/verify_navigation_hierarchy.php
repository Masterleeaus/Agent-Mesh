<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
require_once $root . '/System/Navigation/TitanRewindNavigation.php';

use App\Extensions\TitanRewind\System\Navigation\TitanRewindNavigation;

$failures = [];
$checks = 0;
$check = static function (bool $condition, string $message) use (&$failures, &$checks): void {
    ++$checks;
    if (! $condition) $failures[] = $message;
};

$user = TitanRewindNavigation::user();
$check(count($user) === 8, 'user navigation contains one parent plus seven child links');
$byKey = [];
foreach ($user as $item) $byKey[(string)($item['key'] ?? '')] = $item;

$expected = [
    'titan_rewind_overview' => 'dashboard.user.titan.rewind.index',
    'titan_rewind_traces' => 'dashboard.user.titan.rewind.traces.index',
    'titan_rewind_cases' => 'dashboard.user.titan.rewind.cases.index',
    'titan_rewind_replays' => 'dashboard.user.titan.rewind.replay.index',
    'titan_rewind_evidence' => 'dashboard.user.titan.rewind.evidence.index',
    'titan_rewind_recovery' => 'dashboard.user.titan.rewind.recovery.index',
    'titan_rewind_assistant' => 'dashboard.user.titan.rewind.assistant.index',
];

$check(isset($byKey['titan_rewind']), 'Titan Rewind parent exists');
foreach ($expected as $key => $route) {
    $check(isset($byKey[$key]), "child {$key} exists");
    $item = $byKey[$key] ?? [];
    $check(($item['parent_key'] ?? null) === 'titan_rewind', "{$key} belongs to Titan Rewind parent");
    $check(($item['route'] ?? null) === $route, "{$key} targets {$route}");
}

$routes = (string) file_get_contents($root . '/routes/user.php');
foreach (['traces.index','cases.index','replay.index','evidence.index','recovery.index'] as $name) {
    $check(str_contains($routes, "name('{$name}')"), "catalogue route {$name} exists");
}

$sync = (string) file_get_contents($root . '/System/Navigation/MagicAiMenuSynchronizer.php');
$check(str_contains($sync, "parent_key"), 'legacy MagicAI menu synchronizer resolves parent_key hierarchy');
$check(str_contains($sync, "where('key', \$parentKey)"), 'legacy synchronizer resolves parent menu ID from its key');
$check(! str_contains($sync, "'parent_id' => null,\n            'route' => \$route"), 'legacy synchronizer does not force every menu row to root level');

if ($failures !== []) {
    fwrite(STDERR, "Navigation hierarchy verification failed ({$checks} checks):\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

printf("Navigation hierarchy PASS (%d/%d)\n", $checks, $checks);
