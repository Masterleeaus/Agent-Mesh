# Governance

Vision inference is never authoritative truth. Human confirmation and/or Titan Assurance may constrain decisions. Cross-domain business writes are never performed by the Vision inference service.

## Assurance readiness gate
`vision.assurance-readiness` may declare an evidence package eligible to be submitted to Titan Assurance only after deterministic capture/review/comparison rules pass. Eligibility is not approval and never calls `crm.job.complete`.
