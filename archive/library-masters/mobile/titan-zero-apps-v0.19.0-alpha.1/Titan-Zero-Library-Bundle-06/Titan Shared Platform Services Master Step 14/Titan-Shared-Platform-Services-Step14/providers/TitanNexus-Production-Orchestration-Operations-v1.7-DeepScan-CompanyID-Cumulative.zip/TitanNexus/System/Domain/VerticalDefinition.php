<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\CanonicalJson;
use InvalidArgumentException;

final class VerticalDefinition
{
    /** @var array<string, mixed> */
    private readonly array $validation;

    /** @var array<string, list<string>> */
    private readonly array $recompilePolicy;

    /** @var array<string, mixed> */
    private readonly array $provisioning;

    /**
     * @param array<string, mixed> $sections
     * @param array<string, mixed> $validation
     * @param array<string, mixed> $recompilePolicy
     * @param array<string, mixed> $provisioning
     */
    public function __construct(
        private readonly string $verticalId,
        private readonly string $verticalVersion,
        private readonly ?string $knowledgeSnapshotVersion,
        private readonly array $sections,
        array $validation = [],
        array $recompilePolicy = [],
        array $provisioning = [],
        private readonly ?string $definitionHash = null,
    ) {
        self::assertRequired($this->verticalId, 'vertical_id', 120);
        self::assertRequired($this->verticalVersion, 'vertical_version', 80);

        if ($this->knowledgeSnapshotVersion !== null) {
            self::assertRequired($this->knowledgeSnapshotVersion, 'knowledge_snapshot_version', 120);
        }
        if ($this->definitionHash !== null && preg_match('/^[0-9a-f]{64}$/i', $this->definitionHash) !== 1) {
            throw new InvalidArgumentException('definition_hash must be a SHA-256 hex digest.');
        }

        $this->validation = self::normalizeRules($validation);
        $this->recompilePolicy = self::normalizeRecompilePolicy($recompilePolicy);
        $this->provisioning = self::normalizeProvisioning($provisioning);
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $canonical = array_key_exists('defaults', $data) || array_key_exists('definition_hash', $data);
        $sections = $canonical ? ($data['defaults'] ?? []) : ($data['sections'] ?? []);
        if (!is_array($sections)) {
            throw new InvalidArgumentException(($canonical ? 'defaults' : 'sections') . ' must be an object-like array.');
        }

        $validation = $data['validation'] ?? [];
        if (!is_array($validation)) {
            throw new InvalidArgumentException('validation must be an object-like array.');
        }
        if ($canonical) {
            $validation = [
                'required_profile_paths' => $validation['required_profile_paths'] ?? [],
                'recommended_profile_paths' => $validation['recommended_profile_paths'] ?? [],
                'required_platform_capabilities' => $validation['required_capabilities'] ?? [],
                'require_knowledge_snapshot' => $validation['knowledge_snapshot_required'] ?? false,
            ];
        }

        $recompilePolicy = $data['recompile_policy'] ?? [];
        if (!is_array($recompilePolicy)) {
            throw new InvalidArgumentException('recompile_policy must be an object-like array.');
        }
        if ($canonical) {
            $approval = [];
            $blocked = [];
            foreach ($recompilePolicy as $path => $disposition) {
                if (!is_string($path) || !is_string($disposition)) {
                    throw new InvalidArgumentException('Canonical recompile_policy entries must map paths to dispositions.');
                }
                if ($disposition === 'requires_approval') { $approval[] = $path; }
                elseif ($disposition === 'blocked') { $blocked[] = $path; }
                elseif ($disposition !== 'apply') { throw new InvalidArgumentException('Canonical recompile_policy disposition is invalid.'); }
            }
            $recompilePolicy = ['requires_approval_paths' => $approval, 'blocked_paths' => $blocked];
        }

        $provisioning = $data['provisioning'] ?? [];
        if (!is_array($provisioning)) {
            throw new InvalidArgumentException('provisioning must be an object-like array.');
        }
        if ($canonical) {
            $routes = $provisioning['routes'] ?? [];
            $dependencies = $provisioning['dependencies'] ?? [];
            if (!is_array($routes) || !is_array($dependencies)) {
                throw new InvalidArgumentException('Canonical provisioning routes/dependencies must be object-like arrays.');
            }
            $internalRoutes = [];
            foreach ($routes as $path => $capability) {
                if (!is_string($path) || !is_string($capability)) {
                    throw new InvalidArgumentException('Canonical provisioning routes must map paths to capabilities.');
                }
                $dependsOn = $dependencies[$path] ?? [];
                if (!is_array($dependsOn) || !array_is_list($dependsOn)) {
                    throw new InvalidArgumentException('Canonical provisioning dependencies must be lists.');
                }
                $internalRoutes[$path] = ['capability' => $capability, 'depends_on' => $dependsOn];
            }
            $provisioning = ['routes' => $internalRoutes];
        }

        $knowledgeSnapshotVersion = $data['knowledge_snapshot_version'] ?? null;
        if ($knowledgeSnapshotVersion !== null && !is_string($knowledgeSnapshotVersion)) {
            throw new InvalidArgumentException('knowledge_snapshot_version must be null or a string.');
        }

        $verticalId = self::requiredString($data['vertical_id'] ?? null, 'vertical_id');
        $verticalVersion = self::requiredString($data['vertical_version'] ?? null, 'vertical_version');
        $providedDefinitionHash = isset($data['definition_hash'])
            ? self::requiredString($data['definition_hash'], 'definition_hash')
            : null;

        $instance = new self(
            $verticalId,
            $verticalVersion,
            $knowledgeSnapshotVersion === null ? null : trim($knowledgeSnapshotVersion),
            $sections,
            $validation,
            $recompilePolicy,
            $provisioning,
            null,
        );

        if ($providedDefinitionHash !== null) {
            if (preg_match('/^[0-9a-f]{64}$/i', $providedDefinitionHash) !== 1
                || !hash_equals(strtolower($providedDefinitionHash), $instance->fingerprint())) {
                throw new InvalidArgumentException('definition_hash does not match the canonical VerticalDefinition content.');
            }
            return new self(
                $verticalId,
                $verticalVersion,
                $knowledgeSnapshotVersion === null ? null : trim($knowledgeSnapshotVersion),
                $sections,
                $validation,
                $recompilePolicy,
                $provisioning,
                strtolower($providedDefinitionHash),
            );
        }

        return $instance;
    }

    public function verticalId(): string { return $this->verticalId; }
    public function verticalVersion(): string { return $this->verticalVersion; }
    public function knowledgeSnapshotVersion(): ?string { return $this->knowledgeSnapshotVersion; }

    /** @return array<string, mixed> */
    public function sections(): array { return $this->sections; }

    /** @return array<string, mixed> */
    public function validationRules(): array { return $this->validation; }

    /** @return array<string, list<string>> */
    public function recompilePolicy(): array { return $this->recompilePolicy; }

    /** @return array<string, mixed> */
    public function provisioningPolicy(): array { return $this->provisioning; }

    public function fingerprint(): string
    {
        return $this->definitionHash === null ? hash('sha256', CanonicalJson::encode($this->toArray())) : strtolower($this->definitionHash);
    }

    /** @return array<string,mixed> */
    public function toContractArray(): array
    {
        $validation = [
            'required_profile_paths' => array_values($this->validation['required_profile_paths'] ?? []),
            'recommended_profile_paths' => array_values($this->validation['recommended_profile_paths'] ?? []),
            'required_capabilities' => array_values($this->validation['required_platform_capabilities'] ?? []),
            'knowledge_snapshot_required' => (bool)($this->validation['require_knowledge_snapshot'] ?? false),
        ];
        $policy = [];
        foreach ($this->recompilePolicy['requires_approval_paths'] ?? [] as $path) { $policy[$path] = 'requires_approval'; }
        foreach ($this->recompilePolicy['blocked_paths'] ?? [] as $path) { $policy[$path] = 'blocked'; }
        ksort($policy, SORT_STRING);
        $routes = [];
        $dependencies = [];
        foreach (($this->provisioning['routes'] ?? []) as $path => $route) {
            $routes[$path] = $route['capability'];
            $dependencies[$path] = array_values($route['depends_on']);
        }
        ksort($routes, SORT_STRING); ksort($dependencies, SORT_STRING);
        return [
            'vertical_id' => $this->verticalId,
            'vertical_version' => $this->verticalVersion,
            'definition_hash' => $this->fingerprint(),
            'knowledge_snapshot_version' => $this->knowledgeSnapshotVersion,
            'defaults' => $this->sections,
            'validation' => $validation,
            'recompile_policy' => $policy,
            'provisioning' => ['routes' => $routes, 'dependencies' => $dependencies],
        ];
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        $data = [
            'vertical_id' => $this->verticalId,
            'vertical_version' => $this->verticalVersion,
            'knowledge_snapshot_version' => $this->knowledgeSnapshotVersion,
            'sections' => $this->sections,
        ];

        if ($this->validation !== []) {
            $data['validation'] = $this->validation;
        }
        if ($this->recompilePolicy !== []) {
            $data['recompile_policy'] = $this->recompilePolicy;
        }
        if ($this->provisioning !== []) {
            $data['provisioning'] = $this->provisioning;
        }

        return $data;
    }

    /** @param array<string, mixed> $validation @return array<string, mixed> */
    private static function normalizeRules(array $validation): array
    {
        $allowed = [
            'required_profile_paths',
            'recommended_profile_paths',
            'required_platform_capabilities',
            'require_knowledge_snapshot',
        ];

        foreach (array_keys($validation) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                throw new InvalidArgumentException('Unsupported vertical validation rule: ' . (string) $key);
            }
        }

        $normalized = [];
        foreach (['required_profile_paths', 'recommended_profile_paths', 'required_platform_capabilities'] as $key) {
            if (!array_key_exists($key, $validation)) {
                continue;
            }
            $values = $validation[$key];
            if (!is_array($values) || !array_is_list($values)) {
                throw new InvalidArgumentException("validation.{$key} must be a list of strings.");
            }
            $items = self::normalizeStringSet($values, "validation.{$key}");
            if ($items !== []) {
                $normalized[$key] = $items;
            }
        }

        if (array_key_exists('require_knowledge_snapshot', $validation)) {
            if (!is_bool($validation['require_knowledge_snapshot'])) {
                throw new InvalidArgumentException('validation.require_knowledge_snapshot must be boolean.');
            }
            if ($validation['require_knowledge_snapshot'] === true) {
                $normalized['require_knowledge_snapshot'] = true;
            }
        }

        return $normalized;
    }

    /** @param array<string, mixed> $policy @return array<string, list<string>> */
    private static function normalizeRecompilePolicy(array $policy): array
    {
        $allowed = ['requires_approval_paths', 'blocked_paths'];
        foreach (array_keys($policy) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                throw new InvalidArgumentException('Unsupported vertical recompile policy rule: ' . (string) $key);
            }
        }

        $normalized = [];
        foreach ($allowed as $key) {
            if (!array_key_exists($key, $policy)) {
                continue;
            }
            $values = $policy[$key];
            if (!is_array($values) || !array_is_list($values)) {
                throw new InvalidArgumentException("recompile_policy.{$key} must be a list of paths.");
            }
            $items = self::normalizeStringSet($values, "recompile_policy.{$key}");
            foreach ($items as $path) {
                if (preg_match('/^[A-Za-z0-9_.-]+$/', $path) !== 1) {
                    throw new InvalidArgumentException("recompile_policy.{$key} contains an invalid path.");
                }
            }
            if ($items !== []) {
                $normalized[$key] = $items;
            }
        }

        return $normalized;
    }


    /** @param array<string, mixed> $provisioning @return array<string, mixed> */
    private static function normalizeProvisioning(array $provisioning): array
    {
        if ($provisioning === []) {
            return [];
        }
        foreach (array_keys($provisioning) as $key) {
            if ($key !== 'routes') {
                throw new InvalidArgumentException('Unsupported vertical provisioning rule: ' . (string) $key);
            }
        }
        $routesRaw = $provisioning['routes'] ?? [];
        if (!is_array($routesRaw) || array_is_list($routesRaw)) {
            throw new InvalidArgumentException('provisioning.routes must be an object keyed by configuration path.');
        }
        $routes = [];
        foreach ($routesRaw as $path => $rule) {
            if (!is_string($path) || preg_match('/^[A-Za-z0-9_.-]{1,512}$/', $path) !== 1) {
                throw new InvalidArgumentException('provisioning.routes contains an invalid path.');
            }
            if (!is_array($rule) || array_is_list($rule)) {
                throw new InvalidArgumentException("provisioning.routes.{$path} must be an object-like array.");
            }
            foreach (array_keys($rule) as $ruleKey) {
                if (!in_array($ruleKey, ['capability', 'depends_on'], true)) {
                    throw new InvalidArgumentException("Unsupported provisioning route field {$path}.{$ruleKey}.");
                }
            }
            $capability = $rule['capability'] ?? null;
            if (!is_string($capability) || preg_match('/^[A-Za-z0-9_.:-]{1,180}$/', trim($capability)) !== 1) {
                throw new InvalidArgumentException("provisioning.routes.{$path}.capability is invalid.");
            }
            $depends = $rule['depends_on'] ?? [];
            if (!is_array($depends) || !array_is_list($depends)) {
                throw new InvalidArgumentException("provisioning.routes.{$path}.depends_on must be a list of route paths.");
            }
            $depends = self::normalizeStringSet($depends, "provisioning.routes.{$path}.depends_on");
            foreach ($depends as $dependency) {
                if (preg_match('/^[A-Za-z0-9_.-]{1,512}$/', $dependency) !== 1) {
                    throw new InvalidArgumentException("provisioning.routes.{$path}.depends_on contains an invalid path.");
                }
            }
            $routes[$path] = ['capability' => trim($capability), 'depends_on' => $depends];
        }
        ksort($routes, SORT_STRING);
        foreach ($routes as $path => $rule) {
            foreach ($rule['depends_on'] as $dependency) {
                if (!array_key_exists($dependency, $routes)) {
                    throw new InvalidArgumentException("Provisioning route {$path} depends on unknown route {$dependency}.");
                }
                if ($dependency === $path) {
                    throw new InvalidArgumentException("Provisioning route {$path} cannot depend on itself.");
                }
            }
        }
        self::assertAcyclicProvisioningRoutes($routes);
        return $routes === [] ? [] : ['routes' => $routes];
    }

    /** @param array<string, array{capability:string,depends_on:list<string>}> $routes */
    private static function assertAcyclicProvisioningRoutes(array $routes): void
    {
        $visiting = [];
        $visited = [];
        $visit = function (string $path) use (&$visit, &$visiting, &$visited, $routes): void {
            if (isset($visited[$path])) {
                return;
            }
            if (isset($visiting[$path])) {
                throw new InvalidArgumentException('Provisioning route dependencies contain a cycle.');
            }
            $visiting[$path] = true;
            foreach ($routes[$path]['depends_on'] as $dependency) {
                $visit($dependency);
            }
            unset($visiting[$path]);
            $visited[$path] = true;
        };
        foreach (array_keys($routes) as $path) {
            $visit($path);
        }
    }

    /** @param list<mixed> $values @return list<string> */
    private static function normalizeStringSet(array $values, string $field): array
    {
        $items = [];
        foreach ($values as $value) {
            if (!is_string($value) || trim($value) === '' || strlen(trim($value)) > 512) {
                throw new InvalidArgumentException("{$field} contains an invalid value.");
            }
            $items[] = trim($value);
        }
        $items = array_values(array_unique($items));
        sort($items, SORT_STRING);
        return $items;
    }

    private static function assertRequired(string $value, string $field, int $maxLength): void
    {
        if ($value === '' || strlen($value) > $maxLength) {
            throw new InvalidArgumentException("{$field} must be between 1 and {$maxLength} characters.");
        }
    }

    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') {
            throw new InvalidArgumentException("{$field} is required.");
        }
        return trim($value);
    }
}
