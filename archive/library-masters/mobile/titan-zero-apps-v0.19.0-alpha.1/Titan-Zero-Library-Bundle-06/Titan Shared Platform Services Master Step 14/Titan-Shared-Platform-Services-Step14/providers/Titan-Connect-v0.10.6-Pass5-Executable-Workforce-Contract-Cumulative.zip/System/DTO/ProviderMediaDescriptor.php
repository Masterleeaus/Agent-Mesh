<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\DTO;

final class ProviderMediaDescriptor
{
    /**
     * @param array<string,mixed> $requestOptions
     * @param array<string,mixed> $providerMedia
     */
    public function __construct(
        public readonly string $downloadUrl,
        public readonly array $requestOptions = [],
        public readonly ?string $originalName = null,
        public readonly ?string $mimeType = null,
        public readonly ?int $sizeBytes = null,
        public readonly ?string $sha256 = null,
        public readonly array $providerMedia = [],
    ) {
    }
}
