<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('user_openai_chat_messages') && ! Schema::hasColumn('user_openai_chat_messages', 'tenant_company_id')) {
            Schema::table('user_openai_chat_messages', function (Blueprint $table): void {
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
            });
        }
        if (Schema::hasTable('model_council_responses') && ! Schema::hasColumn('model_council_responses', 'tenant_company_id')) {
            Schema::table('model_council_responses', function (Blueprint $table): void {
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
            });
        }
    }

    public function down(): void
    {
        // Shared/compatibility columns are intentionally retained for forward safety.
    }
};
