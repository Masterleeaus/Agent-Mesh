# Runtime Orchestration Pass v1.4

TitanSignalEngine now participates in the typed Agent-05 cross-extension loop.

- canonical tenant boundary: `company_id`
- typed handoff envelope: `titan.cross-extension-handoff.v1`
- deterministic idempotency keys and payload hashes
- causal lineage across every hop
- Workforce retains work-item and authorization ownership
- provider degradation propagates fail-closed
- failover may never increase authority or bypass authorization
- execution receipts preserve outcome-to-origin traceability
