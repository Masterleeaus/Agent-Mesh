<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use InvalidArgumentException;

final class SignalArchiveCatalogRow extends Model
{
    protected $table = 'titan_signal_archive_catalog';
    protected $guarded = [];
    protected $casts = [
        'tenant_company_id' => 'integer',
        'tenant_key' => 'integer',
        'archive_sequence' => 'integer',
        'privacy_projected' => 'boolean',
        'occurred_at' => 'immutable_datetime',
        'recorded_at' => 'immutable_datetime',
    ];

    /** @param Builder<SignalArchiveCatalogRow> $query */
    public function scopeInScope(Builder $query, string $scope, ?int $tenantCompanyId): Builder
    {
        if (! in_array($scope, ['tenant', 'system'], true)) {
            throw new InvalidArgumentException('Signal archive catalog scope must be tenant or system.');
        }
        $query->where('scope', $scope);
        if ($scope === 'tenant') {
            if ($tenantCompanyId === null || $tenantCompanyId < 1) {
                throw new InvalidArgumentException('tenant_company_id is required for tenant archive queries.');
            }
            return $query->where('tenant_company_id', $tenantCompanyId);
        }
        return $query->whereNull('tenant_company_id');
    }
}
