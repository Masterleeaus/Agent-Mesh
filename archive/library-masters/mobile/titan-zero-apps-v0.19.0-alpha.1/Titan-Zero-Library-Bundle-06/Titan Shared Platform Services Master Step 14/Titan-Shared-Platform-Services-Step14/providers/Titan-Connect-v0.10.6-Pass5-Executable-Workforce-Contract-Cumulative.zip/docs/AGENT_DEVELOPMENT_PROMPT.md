# TITAN CONNECT — EXTRACTION, CONSOLIDATION & FULL DEVELOPMENT PROMPT

## Mission

Develop the supplied `TitanConnect` extracted extension into Titan Zero's canonical communications layer for internal team messaging and external business messaging channels.

This package was extracted from the modified Chatbot donor. **Do not rebuild it from scratch.** Deep-scan the package, retain the mature Team Chat code and useful messaging-runtime/provider code, then consolidate them behind clean Titan Connect contracts.

Chatbot remains an AI/customer-conversation application. Titan Connect owns reusable communications infrastructure. WorkCore remains the authoritative CRM/business system. TitanAI and the Interaction Engine consume Connect through tools/contracts; they do not own transports or conversation persistence.

## Source provenance

The extraction contains:
- Team Chat models/services/policies/events/controllers promoted into the `App\\Extensions\\TitanConnect` namespace;
- team-chat browser assets and views;
- legacy Team Chat migrations preserved under `database/legacy-migrations/` and intentionally not auto-loaded;
- the complete donor `messaging-core` runtime under `donor/messaging-core-runtime/`;
- donor channel contracts plus web/internal/push channel implementations;
- the original Chatbot provider/inbox context required to reconstruct routes and integration points;
- donor tests.

The messaging-core donor has mixed legacy namespaces (for example `ChatbotWhatsapp`) and provider-specific assumptions. Treat it as source material to consolidate, not as a second runtime to boot unchanged.

## Locked architecture

```text
                       TITAN CONNECT
 internal/team chat | inbox | channel registry | delivery | webhooks
       |                  |                  |
   Chatbot            Mobile Suite        TitanAI / Interaction
       |                  |                  |
 customer AI       Customer/Go/Owner     governed messaging tools
       +------------------+------------------+
                          |
                       WorkCore
             authoritative customers/jobs/users
```

## Required ownership boundary

Titan Connect owns:
- internal direct/group/channel conversations;
- memberships/participants/read state;
- business messaging channel registry;
- outbound message queue and delivery receipts;
- inbound webhook normalization;
- provider adapters;
- unified inbox contracts/read models;
- attachments metadata/transport contracts;
- typing/presence/realtime event contracts;
- channel health;
- messaging audit/correlation IDs.

Titan Connect does NOT own:
- customers or CRM records;
- jobs/bookings/invoices;
- AI reasoning/model routing;
- the Chatbot builder;
- Titan Mobile device registry;
- payment processing.

## Required work

1. **Deep scan before editing.** Inventory promoted Team Chat code, legacy migrations, messaging-core donor and Chatbot integration context. Produce a migration/ownership map.
2. **Preserve extension identity:** folder `TitanConnect`, namespace `App\\Extensions\\TitanConnect`, provider `TitanConnectServiceProvider`, slug `titan-connect`.
3. **Create one canonical conversation model architecture** capable of direct, group, business-channel and linked operational rooms without forcing external WhatsApp/SMS threads into exactly the same persistence shape if that causes data loss. Use stable conversation/thread abstractions and adapters.
4. **Migration strategy:** do not blindly load the legacy `ext_chatbot_team_*` migrations beside Chatbot. Design additive `ext_titan_connect_*` tables or a deliberate compatibility migration. Import existing Chatbot Team Chat data idempotently and preserve IDs/relationships where possible.
5. **Company/actor security:** every conversation, participant, message, channel, delivery record and webhook result must be company scoped. Resolve tenant from authenticated platform context; never trust free-form company IDs from clients.
6. **Authorization:** fail closed. Enforce membership and role for internal rooms. Channel admins/owners/moderators must have explicit capabilities. Linked job/customer rooms must re-check WorkCore authorization.
7. **Provider registry:** consolidate WhatsApp, Messenger, Instagram, Telegram, SMS and push transports behind a canonical `MessagingProvider` contract. Keep provider credentials in encrypted host vault/config, never in public API resources or conversation records.
8. **Webhooks:** verify signatures where supported, normalize inbound events, make processing idempotent, store provider event IDs, reject replay/duplicate events and acknowledge within provider time limits.
9. **Outbound delivery:** model queued/sending/sent/delivered/read/failed/cancelled states, retry with bounded backoff, preserve provider message IDs, and make client retries idempotent.
10. **Unified inbox:** create compact read models for staff/owner surfaces that can combine internal messages and external channel threads while preserving source/channel identity.
11. **Chatbot integration:** Chatbot consumes Titan Connect for external channel transport and human handoff/inbox bridging. Do not move Chatbot's AI web-conversation history wholesale into Connect unless a deliberate adapter is required.
12. **Mobile integration:** expose contracts/events suitable for Titan Customer, Titan Go and Titan Owner. TitanMobileCore owns mobile device/push subscription identity; Connect may request push delivery through MobileCore rather than duplicating device registries.
13. **TitanAI/Interaction tools:** expose governed tools such as `messages.read`, `messages.send`, `conversation.create`, `conversation.reply`, subject to actor/capability/recipient policy. AI must never obtain raw transport credentials.
14. **WorkCore links:** conversations may reference customer/job/site/worker/team IDs, but authoritative records stay in WorkCore. Use references and DTOs rather than copied business models.
15. **Attachments:** define upload/attachment contracts, malware/type/size validation hooks, provider media adapters and retention policy. Do not embed large binaries in message JSON.
16. **Realtime:** preserve useful Team Chat events and formalize typing/read/conversation-updated events. Gracefully fall back when realtime infrastructure is unavailable.
17. **Privacy/retention:** tenant-configurable retention, export/delete hooks where legally applicable, auditable staff access, no secrets in logs.
18. **Field/Home Services MVP:** remain vertical-agnostic but support linked customer/job/team rooms needed by Cleaning, Plumbing, Electrical, HVAC, Handyman, Landscaping, Pest Control, Locksmith, Roofing and Appliance Repair without ten separate messaging implementations.
19. **Testing:** add unit/feature tests for tenant isolation, membership, role permissions, cross-company denial, webhook verification/idempotency, outbound idempotency/retry, read receipts, group ownership transfer, channel joins, provider health and Chatbot/Mobile adapter boundaries.
20. **Packaging:** produce a normal MagicAI extension ZIP with manifest at root, migration/upgrade notes and no hidden dependency on the modified Chatbot donor.

## Suggested structure

```text
TitanConnect/
  System/
    Actions/
    Attachments/
    Channels/
    Contracts/
    Delivery/
    Events/
    Http/Controllers/
    Http/Requests/
    Inbox/
    Models/
    Policies/
    Presence/
    Providers/
    Realtime/
    Repositories/
    Security/
    Services/TeamChat/
    Webhooks/
  database/migrations/
  resources/assets/
  resources/views/
  routes/
  tests/
  donor/messaging-core-runtime/
  donor/channel-runtime/
  donor/chatbot-integration/
```

Do not create empty meaningless scaffolds.

## Critical migration rule

The extracted legacy Team Chat models still reference `ext_chatbot_team_*` tables for source compatibility. Do not ship a new installation that silently competes with Chatbot for those tables. Choose and document one migration strategy, implement import compatibility, then update the canonical Titan Connect models accordingly.

## Definition of done for the next development pass

- extension boots without modified Chatbot/TitanAI donor trees;
- one canonical provider registry exists;
- team messaging works with company/membership authorization;
- external inbound/outbound messaging uses normalized contracts;
- webhook and outbound processing are idempotent;
- Chatbot, TitanAI and Mobile Suite integrate through interfaces;
- WorkCore records remain authoritative;
- legacy donor data has an explicit import/compatibility path;
- tests are executed and exact results reported;
- donor files are classified as migrated, retained-reference, deprecated or removed.

## Final report

Report IMPLEMENTED / SCAFFOLDED / PARTIAL / NOT IMPLEMENTED / UNVERIFIED for every subsystem. List migrations, provider adapters, routes, tests/results, security decisions, compatibility impact and recommended next development phase. Never claim production readiness solely from syntax lint.
