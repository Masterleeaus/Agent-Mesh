<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Providers;

use App\Extensions\TitanConnect\System\DTO\NormalizedDeliveryReceipt;
use App\Extensions\TitanConnect\System\DTO\NormalizedInboundMessage;
use App\Extensions\TitanConnect\System\DTO\ProviderSendResult;
use App\Extensions\TitanConnect\System\DTO\ProviderMediaDescriptor;
use Illuminate\Support\Arr;

final class WhatsAppProvider extends AbstractMessagingProvider
{
    public function key(): string { return 'whatsapp'; }
    public function capabilities(): array { return ['messages', 'attachments', 'templates', 'delivery_receipts', 'transport:meta', 'transport:twilio']; }

    public function verifyWebhook(array $headers, string $body, array $credentials): bool
    {
        if ($this->transport($credentials) === 'twilio') {
            $signature = $this->header($headers, 'x-twilio-signature');
            $token = trim((string) ($credentials['auth_token'] ?? ''));
            $url = trim((string) ($credentials['webhook_url'] ?? ''));
            if ($url === '' && ! empty($credentials['_connection_uuid'])) {
                $url = route('titan-connect.api.webhooks.handle', ['provider' => 'whatsapp', 'connection' => $credentials['_connection_uuid']]);
            }
            if ($signature === null || $token === '' || $url === '') return false;
            parse_str($body, $params); if (! is_array($params)) return false; ksort($params, SORT_STRING);
            $data = $url; foreach ($params as $key => $value) { if (is_array($value)) { foreach ($value as $item) $data .= (string) $key.(string) $item; } else { $data .= (string) $key.(string) $value; } }
            return hash_equals(base64_encode(hash_hmac('sha1', $data, $token, true)), trim($signature));
        }
        return $this->verifyHmac($headers, $body, (string) ($credentials['app_secret'] ?? ''), 'x-hub-signature-256', 'sha256=');
    }

    public function verifyWebhookChallenge(array $query, array $credentials): ?string
    {
        $mode = (string) ($query['hub.mode'] ?? $query['hub_mode'] ?? '');
        $token = (string) ($query['hub.verify_token'] ?? $query['hub_verify_token'] ?? '');
        $challenge = $query['hub.challenge'] ?? $query['hub_challenge'] ?? null;
        $expected = trim((string) ($credentials['verify_token'] ?? ''));
        if ($mode !== 'subscribe' || $expected === '' || ! hash_equals($expected, $token) || ! is_scalar($challenge)) {
            return null;
        }
        return (string) $challenge;
    }

    public function splitWebhookPayload(array $payload): array
    {
        if (isset($payload['MessageSid']) || isset($payload['SmsSid'])) return [$payload];
        $events = [];
        $entries = is_array($payload['entry'] ?? null) ? $payload['entry'] : [];
        foreach ($entries as $entry) {
            if (! is_array($entry)) {
                continue;
            }
            $changes = is_array($entry['changes'] ?? null) ? $entry['changes'] : [];
            foreach ($changes as $change) {
                if (! is_array($change)) {
                    continue;
                }
                $value = is_array($change['value'] ?? null) ? $change['value'] : [];
                $messages = is_array($value['messages'] ?? null) ? $value['messages'] : [];
                $statuses = is_array($value['statuses'] ?? null) ? $value['statuses'] : [];
                foreach ($messages as $message) {
                    if (! is_array($message)) continue;
                    $eventValue = $value;
                    $eventValue['messages'] = [$message];
                    unset($eventValue['statuses']);
                    $events[] = ['object' => $payload['object'] ?? null, 'entry' => [[
                        'id' => $entry['id'] ?? null,
                        'changes' => [['field' => $change['field'] ?? null, 'value' => $eventValue]],
                    ]]];
                }
                foreach ($statuses as $status) {
                    if (! is_array($status)) continue;
                    $eventValue = $value;
                    $eventValue['statuses'] = [$status];
                    unset($eventValue['messages']);
                    $events[] = ['object' => $payload['object'] ?? null, 'entry' => [[
                        'id' => $entry['id'] ?? null,
                        'changes' => [['field' => $change['field'] ?? null, 'value' => $eventValue]],
                    ]]];
                }
            }
        }
        return $events;
    }

    public function send(array $message, array $credentials): ProviderSendResult
    {
        if ($this->transport($credentials) === 'twilio') return (new WhatsAppTwilioTransport($this->http))->send($message, $credentials);
        $token = $this->credential($credentials, 'access_token');
        $phoneNumberId = $this->accountIdentity($credentials, 'phone_number_id', $message);

        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type' => 'individual',
            'to' => (string) ($message['to'] ?? ''),
        ];

        $template = data_get($message, 'metadata.template');
        if (is_array($template) && $template !== []) {
            $payload['type'] = 'template';
            $payload['template'] = $template;
        } elseif (($attachment = $this->firstAttachment($message)) !== null) {
            $type = strtolower((string) ($attachment['type'] ?? 'document'));
            if (! in_array($type, ['image', 'video', 'audio', 'document'], true)) {
                $type = 'document';
            }
            $media = [];
            if (! empty($attachment['provider_media_id'])) {
                $media['id'] = (string) $attachment['provider_media_id'];
            } elseif (! empty($attachment['public_url'])) {
                $media['link'] = (string) $attachment['public_url'];
            }
            if (! empty($message['body']) && in_array($type, ['image', 'video', 'document'], true)) {
                $media['caption'] = (string) $message['body'];
            }
            if ($media === []) {
                throw new \RuntimeException('WhatsApp attachment requires provider_media_id or public_url.');
            }
            $payload['type'] = $type;
            $payload[$type] = $media;
        } else {
            $payload['type'] = 'text';
            $payload['text'] = ['preview_url' => false, 'body' => (string) ($message['body'] ?? '')];
        }

        $url = $this->graphBase($this->key(), $credentials).'/'.$this->graphVersion($this->key(), $credentials).'/'.$phoneNumberId.'/messages';
        $response = $this->requireSuccess($this->http->request('POST', $url, [
            'bearer' => $token,
            'json' => $payload,
        ]), 'send');

        $providerId = data_get($response->json, 'messages.0.id');
        return new ProviderSendResult('sent', is_scalar($providerId) ? (string) $providerId : null, $response->json);
    }

    public function health(array $credentials): array
    {
        if ($this->transport($credentials) === 'twilio') return (new WhatsAppTwilioTransport($this->http))->health($credentials);
        $token = $this->credential($credentials, 'access_token');
        $phoneNumberId = $this->accountIdentity($credentials, 'phone_number_id');
        $url = $this->graphBase($this->key(), $credentials).'/'.$this->graphVersion($this->key(), $credentials).'/'.$phoneNumberId;
        $response = $this->http->request('GET', $url, [
            'bearer' => $token,
            'query' => ['fields' => 'id,display_phone_number,verified_name'],
        ]);
        return [
            'ok' => $response->isSuccessful(),
            'provider' => $this->key(),
            'configured' => true,
            'http_status' => $response->status,
            'account_id' => $response->json('id'),
        ];
    }

    public function resolveInboundMedia(array $attachment, array $credentials): ?ProviderMediaDescriptor
    {
        if ($this->transport($credentials) === 'twilio') {
            $url = trim((string) ($attachment['public_url'] ?? $attachment['url'] ?? ''));
            if ($url === '') return null;
            return new ProviderMediaDescriptor($url, ['basic_auth' => (new WhatsAppTwilioTransport($this->http))->basicAuth($credentials)], null, isset($attachment['mime_type']) ? (string) $attachment['mime_type'] : null, null, null, ['provider'=>'whatsapp','transport'=>'twilio']);
        }
        $mediaId = trim((string) ($attachment['id'] ?? $attachment['provider_media_id'] ?? ''));
        if ($mediaId === '') {
            return parent::resolveInboundMedia($attachment, $credentials);
        }
        $token = $this->credential($credentials, 'access_token');
        $url = $this->graphBase($this->key(), $credentials).'/'.$this->graphVersion($this->key(), $credentials).'/'.$mediaId;
        $response = $this->requireSuccess($this->http->request('GET', $url, ['bearer' => $token]), 'media resolve');
        $downloadUrl = $response->json('url');
        if (! is_string($downloadUrl) || trim($downloadUrl) === '') {
            return null;
        }
        return new ProviderMediaDescriptor(
            trim($downloadUrl),
            ['bearer' => $token],
            isset($attachment['filename']) ? (string) $attachment['filename'] : null,
            is_string($response->json('mime_type')) ? (string) $response->json('mime_type') : ($attachment['mime_type'] ?? null),
            is_numeric($response->json('file_size')) ? (int) $response->json('file_size') : null,
            is_string($response->json('sha256')) ? (string) $response->json('sha256') : ($attachment['sha256'] ?? null),
            ['provider' => $this->key(), 'media_id' => $mediaId],
        );
    }

    public function normalizeDeliveryReceipt(array $payload): NormalizedDeliveryReceipt
    {
        if (isset($payload['MessageSid']) || isset($payload['SmsSid'])) {
            $id = $payload['MessageSid'] ?? $payload['SmsSid'] ?? null;
            $statusValue = $payload['MessageStatus'] ?? $payload['SmsStatus'] ?? 'unknown';
            return new NormalizedDeliveryReceipt($this->key(), $id === null ? null : (string) $id, strtolower((string) $statusValue), ['transport'=>'twilio']);
        }
        $status = Arr::get($payload, 'entry.0.changes.0.value.statuses.0');
        if (! is_array($status)) {
            return parent::normalizeDeliveryReceipt($payload);
        }

        return new NormalizedDeliveryReceipt(
            $this->key(),
            isset($status['id']) ? (string) $status['id'] : null,
            strtolower((string) ($status['status'] ?? 'unknown')),
            ['provider_timestamp' => $status['timestamp'] ?? null, 'recipient_id' => $status['recipient_id'] ?? null],
        );
    }

    public function normalizeInbound(array $payload, array $headers = []): NormalizedInboundMessage
    {
        if (isset($payload['MessageSid']) || isset($payload['SmsSid'])) {
            $id = (string) ($payload['MessageSid'] ?? $payload['SmsSid'] ?? '');
            $sender = isset($payload['From']) ? preg_replace('/^whatsapp:/i', '', (string) $payload['From']) : null;
            $recipient = isset($payload['To']) ? preg_replace('/^whatsapp:/i', '', (string) $payload['To']) : null;
            $attachments = []; $numMedia = max(0, (int) ($payload['NumMedia'] ?? 0));
            for ($i=0; $i<$numMedia; $i++) if (! empty($payload['MediaUrl'.$i])) $attachments[]=['public_url'=>(string)$payload['MediaUrl'.$i],'mime_type'=>$payload['MediaContentType'.$i] ?? null,'type'=>'mms'];
            return new NormalizedInboundMessage($this->key(), $id, (string) ($sender ?: $id), $id ?: null, $sender, $recipient, isset($payload['Body']) ? (string) $payload['Body'] : null, $attachments === [] ? 'text' : 'attachment', $attachments, ['raw'=>$payload,'transport'=>'twilio']);
        }
        $message = Arr::get($payload, 'entry.0.changes.0.value.messages.0');
        if (! is_array($message)) {
            return parent::normalizeInbound($payload, $headers);
        }
        $metadata = Arr::get($payload, 'entry.0.changes.0.value.metadata', []);
        $eventId = (string) ($message['id'] ?? Arr::get($payload, 'entry.0.id', ''));
        $sender = isset($message['from']) ? (string) $message['from'] : null;
        $recipient = is_array($metadata) && isset($metadata['phone_number_id']) ? (string) $metadata['phone_number_id'] : null;
        $type = (string) ($message['type'] ?? 'text');
        $body = $type === 'text' ? Arr::get($message, 'text.body') : Arr::get($message, $type.'.caption');
        $attachments = $type === 'text' ? [] : [Arr::get($message, $type, [])];
        return new NormalizedInboundMessage($this->key(), $eventId, $sender ?: $eventId, $message['id'] ?? null, $sender, $recipient, $body, $type, $attachments, ['raw' => $payload], $message['timestamp'] ?? null);
    }

    private function transport(array $credentials): string
    {
        $settings = is_array($credentials['_connection_settings'] ?? null) ? $credentials['_connection_settings'] : [];
        $transport = strtolower(trim((string) ($settings['transport'] ?? $credentials['transport'] ?? 'meta')));
        return $transport === 'twilio' ? 'twilio' : 'meta';
    }

}
