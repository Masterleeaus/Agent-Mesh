<?php

declare(strict_types=1);
$root = dirname(__DIR__, 2);
$path = $root . '/System/DTO/ApprovalState.php';
if (!is_file($path)) { fwrite(STDERR, "Missing Pass 4 approval state type\n"); exit(1); }
require_once $path;

use App\Extensions\TitanAICore\System\DTO\ApprovalState;

$pending = ApprovalState::pending('approval-1', 'plan-1', 'step-1', 'HIGH_RISK_REVIEW');
if ($pending->status !== 'PENDING' || $pending->allowsExecution()) { fwrite(STDERR, "pending approval is not fail closed\n"); exit(1); }
$approved = $pending->approve('human-7', 'manual-review', '2026-08-20T00:00:00+10:00');
if ($approved->status !== 'APPROVED' || !$approved->allowsExecution() || $approved->decidedByActorId !== 'human-7') { fwrite(STDERR, "approval decision was not captured\n"); exit(1); }
$denied = $pending->deny('human-8', 'insufficient-evidence', '2026-08-20T00:00:01+10:00');
if ($denied->status !== 'DENIED' || $denied->allowsExecution()) { fwrite(STDERR, "denied approval allowed execution\n"); exit(1); }

fwrite(STDOUT, "Pass 4 approval state test: PASS\n");
