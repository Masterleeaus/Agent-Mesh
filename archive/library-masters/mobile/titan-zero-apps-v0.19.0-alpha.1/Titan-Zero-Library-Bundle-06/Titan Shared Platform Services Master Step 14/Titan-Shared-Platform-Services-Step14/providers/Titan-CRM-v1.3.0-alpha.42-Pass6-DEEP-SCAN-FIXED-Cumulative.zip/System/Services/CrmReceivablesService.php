<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use InvalidArgumentException;

final class CrmReceivablesService
{
    public function __construct(private readonly ConnectionInterface $db) {}

    public function recalculateInvoice(int $actorUserId,string $invoicePublicId): array
    {
        $tenant=CrmCompanyScope::companyId($actorUserId);
        $invoice=$this->db->table('crm_invoices')->where('company_id',$tenant)->where('public_id',$invoicePublicId)->whereNull('deleted_at')->lockForUpdate()->first();
        if(!$invoice)throw new InvalidArgumentException('CRM invoice not found.');

        $refs=$this->db->table('crm_invoice_settlement_references')->where('company_id',$tenant)->where('invoice_public_id',$invoicePublicId)->where('status','applied');
        $paid=(int)(clone $refs)->where('direction','payment')->sum('amount_minor');
        $refunded=(int)(clone $refs)->where('direction','refund')->sum('amount_minor');
        $credited=(int)$this->db->table('crm_credit_notes')->where('company_id',$tenant)->where('invoice_public_id',$invoicePublicId)->where('status','issued')->whereNull('deleted_at')->sum('total_minor');
        $total=(int)$invoice->total_minor;
        $netPaid=max(0,$paid-$refunded);
        $netCharge=max(0,$total-$credited);
        $balance=max(0,$netCharge-$netPaid);
        $refundDue=max(0,$netPaid-$netCharge);
        $applied=$netPaid+$credited;
        $currentStatus=strtolower((string)$invoice->status);
        $receivableState=$currentStatus==='void'?'void':($currentStatus==='draft'?'draft':($refundDue>0?'refund-due':($balance===0?'settled':($applied>0?'partial':'open'))));
        $paymentState=$netPaid>0?($balance===0?'paid':'partially-paid'):'unpaid';
        $openIssues=(int)$this->db->table('crm_receivable_reconciliation_issues')->where('company_id',$tenant)->where('invoice_public_id',$invoicePublicId)->where('status','open')->count();
        $newStatus=$currentStatus;
        if(!in_array($currentStatus,['draft','void'],true)){
            if($balance===0&&$netPaid>0)$newStatus='paid';
            elseif($currentStatus==='paid')$newStatus='issued';
        }
        $update=[
            'paid_minor'=>$paid,'refunded_minor'=>$refunded,'refund_due_minor'=>$refundDue,'credited_minor'=>$credited,'balance_minor'=>$balance,
            'payment_state'=>$paymentState,'receivable_state'=>$receivableState,
            'reconciliation_status'=>$openIssues>0?'mismatch':($refs->exists()?'reconciled':'unreconciled'),
            'status'=>$newStatus,'paid_at'=>$balance===0&&$netPaid>0?($invoice->paid_at??now()):null,'updated_at'=>now(),
        ];
        $this->db->table('crm_invoices')->where('company_id',$tenant)->where('id',$invoice->id)->update($update);
        return (array)$this->db->table('crm_invoices')->where('company_id',$tenant)->where('id',$invoice->id)->first();
    }

    public function aging(int $actorUserId,?string $asOf=null): array
    {
        $tenant=CrmCompanyScope::companyId($actorUserId);$date=$asOf!==null&&trim($asOf)!==''?Carbon::parse($asOf)->startOfDay():now()->startOfDay();$agingBucket=$this->agingBucket($date);
        $rows=$this->db->table('crm_invoices')->where('company_id',$tenant)->whereNull('deleted_at')->where('balance_minor','>',0)->whereNotIn('status',['draft','void'])->selectRaw("{$agingBucket['sql']} AS aging_bucket, currency, COUNT(*) AS invoice_count, COALESCE(SUM(balance_minor),0) AS total_minor",$agingBucket['bindings'])->groupBy('aging_bucket','currency')->get();
        $names=['current','1_30','31_60','61_90','90_plus'];$buckets=[];foreach($names as $name)$buckets[$name]=['count'=>0,'total_minor_by_currency'=>[]];$open=0;
        foreach($rows as $row){$bucket=(string)$row->aging_bucket;if(!isset($buckets[$bucket]))continue;$currency=strtoupper((string)$row->currency);$count=(int)$row->invoice_count;$open+=$count;$buckets[$bucket]['count']+=$count;$buckets[$bucket]['total_minor_by_currency'][$currency]=(int)$row->total_minor;}
        return ['as_of'=>$date->toDateString(),'open_invoice_count'=>$open,'buckets'=>$buckets];
    }

    /** @return array{sql:string,bindings:list<string>} */
    private function agingBucket(Carbon $date): array
    {
        $d=$date->toDateString();$driver=$this->db->getDriverName();
        if($driver==='pgsql')return ['sql'=>"CASE WHEN due_at IS NULL OR DATE(due_at) >= ? THEN 'current' WHEN (?::date - DATE(due_at)) <= 30 THEN '1_30' WHEN (?::date - DATE(due_at)) <= 60 THEN '31_60' WHEN (?::date - DATE(due_at)) <= 90 THEN '61_90' ELSE '90_plus' END",'bindings'=>[$d,$d,$d,$d]];
        if($driver==='sqlite')return ['sql'=>"CASE WHEN due_at IS NULL OR DATE(due_at) >= ? THEN 'current' WHEN (julianday(?) - julianday(DATE(due_at))) <= 30 THEN '1_30' WHEN (julianday(?) - julianday(DATE(due_at))) <= 60 THEN '31_60' WHEN (julianday(?) - julianday(DATE(due_at))) <= 90 THEN '61_90' ELSE '90_plus' END",'bindings'=>[$d,$d,$d,$d]];
        return ['sql'=>"CASE WHEN due_at IS NULL OR DATE(due_at) >= ? THEN 'current' WHEN DATEDIFF(?, DATE(due_at)) <= 30 THEN '1_30' WHEN DATEDIFF(?, DATE(due_at)) <= 60 THEN '31_60' WHEN DATEDIFF(?, DATE(due_at)) <= 90 THEN '61_90' ELSE '90_plus' END",'bindings'=>[$d,$d,$d,$d]];
    }

    public function reconciliationIssues(int $actorUserId,array $filters=[]): array
    {
        $tenant=CrmCompanyScope::companyId($actorUserId);$q=$this->db->table('crm_receivable_reconciliation_issues')->where('company_id',$tenant);
        foreach(['status','severity','invoice_public_id','issue_type'] as $field){if(isset($filters[$field])&&is_scalar($filters[$field]))$q->where($field,(string)$filters[$field]);}
        return $q->orderByDesc('id')->limit(max(1,min(250,(int)($filters['limit']??100))))->get()->map(fn($r)=>(array)$r)->all();
    }

    public function resolveIssue(int $actorUserId,string $publicId,string $notes=''): array
    {
        $tenant=CrmCompanyScope::companyId($actorUserId);$row=$this->db->table('crm_receivable_reconciliation_issues')->where('company_id',$tenant)->where('public_id',$publicId)->lockForUpdate()->first();
        if(!$row)throw new InvalidArgumentException('Receivable reconciliation issue not found.');
        if((string)$row->status==='resolved')return (array)$row;
        $this->db->table('crm_receivable_reconciliation_issues')->where('id',$row->id)->update(['status'=>'resolved','resolution_notes'=>$notes,'resolved_at'=>now(),'resolved_by_user_id'=>CrmCompanyScope::actorUserId($actorUserId),'updated_at'=>now()]);
        if(!empty($row->invoice_public_id)){
            $this->recalculateInvoice($actorUserId,(string)$row->invoice_public_id);
            $this->db->table('crm_invoices')->where('company_id',$tenant)->where('public_id',(string)$row->invoice_public_id)->increment('entity_version');
        }
        return (array)$this->db->table('crm_receivable_reconciliation_issues')->where('id',$row->id)->first();
    }

    public function references(int $actorUserId,string $invoicePublicId): array
    {
        $tenant=CrmCompanyScope::companyId($actorUserId);
        return $this->db->table('crm_invoice_settlement_references')->where('company_id',$tenant)->where('invoice_public_id',$invoicePublicId)->orderBy('occurred_at')->orderBy('id')->get()->map(fn($r)=>(array)$r)->all();
    }
}
