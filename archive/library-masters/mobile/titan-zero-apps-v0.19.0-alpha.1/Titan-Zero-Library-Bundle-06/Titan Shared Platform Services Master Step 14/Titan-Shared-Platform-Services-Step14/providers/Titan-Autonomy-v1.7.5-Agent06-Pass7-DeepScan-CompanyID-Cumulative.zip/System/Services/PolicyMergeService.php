<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;

final class PolicyMergeService
{
    public function merge(array $platform, array $tenant): array
    {
        $risks = ['low', 'medium', 'high', 'critical'];
        $gateMinimums = [];
        $ceilings = [];

        foreach ($risks as $risk) {
            $platformMinimum = (int) (($platform['gate_minimums'][$risk] ?? PHP_INT_MAX));
            $tenantMinimum = array_key_exists($risk, $tenant['gate_minimums'] ?? [])
                ? (int) $tenant['gate_minimums'][$risk]
                : $platformMinimum;
            $gateMinimums[$risk] = max($platformMinimum, $tenantMinimum);

            $platformCeiling = $this->levelFromKey((string) ($platform['maximum_level_by_risk'][$risk] ?? 'assist'));
            $tenantCeiling = array_key_exists($risk, $tenant['maximum_level_by_risk'] ?? [])
                ? $this->levelFromKey((string) $tenant['maximum_level_by_risk'][$risk])
                : $platformCeiling;
            $effective = $tenantCeiling->value < $platformCeiling->value ? $tenantCeiling : $platformCeiling;
            $ceilings[$risk] = $effective->key();
        }

        return [
            'gate_minimums' => $gateMinimums,
            'maximum_level_by_risk' => $ceilings,
            'system_wide_learning' => (bool) ($platform['system_wide_learning_permitted'] ?? false)
                && (bool) ($tenant['system_wide_learning'] ?? false),
        ];
    }

    private function levelFromKey(string $key): AutonomyLevel
    {
        return match ($key) {
            'suggest' => AutonomyLevel::Suggest,
            'assist' => AutonomyLevel::Assist,
            'semi_auto' => AutonomyLevel::SemiAuto,
            'auto' => AutonomyLevel::Auto,
            'trusted_auto' => AutonomyLevel::TrustedAuto,
            default => AutonomyLevel::Assist,
        };
    }
}
