<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contributions;

final class AutonomyUserNavigationContribution
{
    public function __invoke(): array { return $this->items(); }

    public function items(): array
    {
        return [
            [
                'key' => 'titan-autonomy-operations',
                'label' => 'Autonomy Operations',
                'route' => 'titan-autonomy.operations.index',
                'permission' => 'titan.autonomy.view',
                'icon' => 'tabler-activity-heartbeat',
                'priority' => 79,
            ],
            [
                'key' => 'titan-autonomy-learning',
                'label' => 'Autonomy Learning',
                'route' => 'titan-autonomy.index',
                'permission' => 'titan.autonomy.view',
                'icon' => 'tabler-folders',
                'priority' => 80,
            ],
        ];
    }
}
