# CRM 1.3.0-alpha.20 — Outbound Effect Safety + Titan Connect Boundary

Alpha.20 hardens externally visible CRM effects without changing CRM's authority over invoices or other business records.

## Transaction-safe delivery

- `crm.invoice.send` and `crm.invoice.reminder.send` no longer execute `Mail::send()` inside the authoritative CRM capability transaction.
- The CRM command validates invoice state and recipient, then writes one durable communication intent to `crm_notification_outbox`.
- The command receipt reports `effect_status=queued` and `delivery_receipt_required=true`; it does not claim provider delivery.
- Failed CRM transactions roll back the communication intent, so nothing can be sent from an uncommitted command.

## Idempotent outbox v2

- Adds tenant-scoped `idempotency_key` uniqueness to the existing notification outbox.
- Carries `trace_id`, `correlation_id`, `causation_id`, `command_id` and `receipt_id` into the external-effect record.
- Captures `provider`, `provider_message_id`, `provider_status`, `claimed_at` and `last_attempt_at`.
- Adds atomic due-item claiming, bounded retry/backoff and stale-processing recovery.
- Terminal `sent` / `delivered` rows are never sent again by the CRM delivery worker.

## Titan Connect boundary

- Adds `CrmCommunicationExecutionPort` as the CRM-side communication execution contract.
- Integrated Titan deployments can bind Titan Connect to this port without changing CRM domain services.
- The safe default adapter is deferred; CRM keeps the intent queued when Titan Connect is not available.
- `CrmLegacyMailCommunicationAdapter` preserves the existing Laravel mail/PDF behavior as an explicit standalone compatibility option (`CRM_COMMUNICATION_DRIVER=legacy`).

## Delivery truth + Signals

- Provider delivery is a distinct lifecycle from CRM command acceptance.
- Delivery outcomes update the original outbox record and emit `crm.communication.*` Signal-outbox events using the original trace chain.
- Replayed/idempotent CRM commands retain the original command receipt and communication intent rather than creating duplicate effects.

## New command

`php artisan crm:outbound-effects:deliver --user=<user-id> --limit=25`

This drains due communication intents after the CRM transaction has committed.
