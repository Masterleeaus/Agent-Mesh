<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\InteractionEngine;

use Illuminate\Contracts\Foundation\Application;

final class CrmInteractionSurfaceService
{
    public function __construct(private Application $app,private CrmInteractionJourneyRegistry $journeys) {}

    /** @return array<string,mixed> */
    public function page(string $surface,array $context=[]): array
    {
        $items=$this->journeys->forSurface($surface);
        return [
            'surface'=>$surface,
            'context'=>$context,
            'interaction_engine_available'=>$this->available(),
            'journeys'=>$items,
            'primary_journey'=>$items[0]??null,
            'ai_enabled'=>(bool)config('crm.crm_assistant_enabled',true),
            'authority_mode'=>(string)config('crm.interaction.authority_mode','earned'),
        ];
    }

    public function available(): bool
    {
        $registry='App\\Extensions\\InteractionEngine\\System\\Wizard\\WizardRegistry';
        return class_exists($registry)&&$this->app->bound($registry);
    }
}
