<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ReadPlane;

final class TrustMapProjector
{
    /** @return array<string,mixed> */
    public function project(array $sourceSnapshot): array
    {
        $entries = [];
        foreach (($sourceSnapshot['authorities'] ?? []) as $authority) {
            if (!is_array($authority)) continue;
            $entries[] = $this->projectAuthority($authority);
        }

        return [
            'schema_version' => '1.0',
            'source' => (string)($sourceSnapshot['source'] ?? 'titan-autonomy'),
            'source_status' => (string)($sourceSnapshot['status'] ?? 'UNAVAILABLE'),
            'observed_at' => $sourceSnapshot['observed_at'] ?? null,
            'entries' => $entries,
            'invalid_entries' => count(array_filter($entries, static fn (array $entry): bool => $entry['integrity_status'] !== 'VALID')),
        ];
    }

    /** @return array<string,mixed> */
    private function projectAuthority(array $authority): array
    {
        $desired = $this->score($authority['desired_authority_score'] ?? $authority['desired_score'] ?? null);
        $earned = $this->score($authority['earned_authority_score'] ?? $authority['earned_score'] ?? null);
        $effective = $this->score($authority['effective_authority_score'] ?? $authority['effective_score'] ?? null);
        $predictive = $this->score($authority['predictive_readiness_score'] ?? null);

        $integrity = 'VALID';
        if ($desired === null || $earned === null || $effective === null) {
            $integrity = 'INVALID_MISSING_AUTHORITY_SCORE';
        } elseif (!$this->inRange($desired) || !$this->inRange($earned) || !$this->inRange($effective)) {
            $integrity = 'INVALID_AUTHORITY_RANGE';
        } elseif ($effective > $earned || $earned > $desired) {
            $integrity = 'INVALID_AUTHORITY_ORDER';
        }

        $evidence = is_array($authority['evidence'] ?? null) ? $authority['evidence'] : [];

        return [
            'tenant_company_id' => $authority['tenant_company_id'] ?? null,
            'agent_id' => (string)($authority['agent_id'] ?? ''),
            'capability' => (string)($authority['capability'] ?? ''),
            'capability_variant' => (string)($authority['capability_variant'] ?? 'standard'),
            'vertical' => $authority['vertical'] ?? null,
            'workflow' => $authority['workflow'] ?? null,
            'context' => $authority['context'] ?? $authority['context_key'] ?? null,
            'desired_authority_score' => $desired,
            'earned_authority_score' => $earned,
            'effective_authority_score' => $effective,
            'predictive_readiness_score' => $predictive,
            'desired_band' => $this->band($desired),
            'earned_band' => $this->band($earned),
            'effective_band' => $this->band($effective),
            'integrity_status' => $integrity,
            'evidence_summary' => $this->summarizeEvidence($evidence),
            'evidence' => $this->normalizeEvidence($evidence),
            'policy_fingerprint' => $authority['policy_fingerprint'] ?? null,
            'authority_version' => $authority['authority_version'] ?? $authority['version'] ?? null,
            'trace_id' => $authority['trace_id'] ?? null,
            'correlation_id' => $authority['correlation_id'] ?? null,
            'causation_id' => $authority['causation_id'] ?? null,
            'root_causation_id' => $authority['root_causation_id'] ?? null,
        ];
    }

    private function score(mixed $value): ?float
    {
        if ($value === null || $value === '' || !is_numeric($value)) return null;
        return (float)$value;
    }

    private function inRange(float $score): bool { return $score >= 0.0 && $score <= 100.0; }

    private function band(?float $score): ?string
    {
        if ($score === null || !$this->inRange($score)) return null;
        return match (true) {
            $score <= 15 => 'Suggest',
            $score <= 30 => 'Assist',
            $score <= 50 => 'Semi-Auto',
            $score <= 70 => 'Auto',
            $score <= 85 => 'Trusted Auto',
            default => 'Predictive',
        };
    }

    /** @return list<array<string,mixed>> */
    private function normalizeEvidence(array $evidence): array
    {
        $allowed = ['type','outcome','observed_at','evidence_ref','reason_code','source','weight'];
        $normalized = [];
        foreach ($evidence as $item) {
            if (!is_array($item)) continue;
            $row = [];
            foreach ($allowed as $field) if (array_key_exists($field, $item)) $row[$field] = $item[$field];
            if (!isset($row['type'])) $row['type'] = 'unknown';
            $normalized[] = $row;
        }
        return $normalized;
    }

    /** @return array<string,mixed> */
    private function summarizeEvidence(array $evidence): array
    {
        $types = [];
        $positive = 0;
        $negative = 0;
        $latest = null;

        foreach ($evidence as $item) {
            if (!is_array($item)) continue;
            $type = trim((string)($item['type'] ?? 'unknown')) ?: 'unknown';
            $types[$type] = ($types[$type] ?? 0) + 1;
            $outcome = strtolower((string)($item['outcome'] ?? ''));
            if (in_array($outcome, ['positive','success','approved','accepted','verified'], true)) $positive++;
            if (in_array($outcome, ['negative','failure','failed','rejected','reversed','incident','violation'], true)) $negative++;
            $observedAt = $item['observed_at'] ?? null;
            if (is_string($observedAt) && ($latest === null || $observedAt > $latest)) $latest = $observedAt;
        }

        ksort($types);
        return ['total' => count($evidence), 'positive' => $positive, 'negative' => $negative, 'by_type' => $types, 'latest_observed_at' => $latest];
    }
}
