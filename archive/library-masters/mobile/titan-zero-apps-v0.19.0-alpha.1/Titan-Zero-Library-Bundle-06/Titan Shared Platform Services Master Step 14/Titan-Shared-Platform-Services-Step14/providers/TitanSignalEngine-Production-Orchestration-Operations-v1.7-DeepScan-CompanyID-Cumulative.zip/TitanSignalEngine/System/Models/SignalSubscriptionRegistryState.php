<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalSubscriptionRegistryState extends Model
{
    protected $table = 'titan_signal_subscription_registry_state';
    protected $primaryKey = 'registry_key';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $guarded = [];
    protected $casts = ['revision' => 'integer'];
}
