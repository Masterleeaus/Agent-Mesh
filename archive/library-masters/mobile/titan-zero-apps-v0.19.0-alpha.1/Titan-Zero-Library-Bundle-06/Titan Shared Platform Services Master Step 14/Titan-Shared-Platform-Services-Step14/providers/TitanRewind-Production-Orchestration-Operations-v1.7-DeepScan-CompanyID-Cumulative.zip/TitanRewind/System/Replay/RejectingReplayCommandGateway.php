<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Replay;

use LogicException;

final class RejectingReplayCommandGateway
{
    public function mutationAllowed(): bool { return false; }

    public function dispatch(string $capability, array $input = []): never
    {
        throw new LogicException('REPLAY_BOUNDARY_VIOLATION: Titan Rewind replay cannot dispatch authoritative capability ' . $capability . '.');
    }
}
