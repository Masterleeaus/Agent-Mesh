<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Services;
use App\Extensions\TitanPayroll\Services\Integrations\PayrollReconciliationService;
use Illuminate\Support\Facades\DB;
final class PayrollReconciliationCoordinator
{
    public function __construct(private readonly PayrollReconciliationService $reconciliation,private readonly PayrollSignalOutboxService $signals){}
    public function reconcileAndRecord(int $tenantCompanyId,int $payrollRunId,string $sourceRevision,array $expected,array $actual,string $idempotencyKey):array
    {
        if($tenantCompanyId<=0||$payrollRunId<=0||trim($idempotencyKey)==='')throw new \InvalidArgumentException('Tenant, payroll run and idempotency key are required.');
        return DB::transaction(function()use($tenantCompanyId,$payrollRunId,$sourceRevision,$expected,$actual,$idempotencyKey):array{
            $run=DB::table('ext_titan_payroll_runs')->where('tenant_company_id',$tenantCompanyId)->where('id',$payrollRunId)->first(['id']);if(!$run)throw new \DomainException('Tenant-scoped payroll run not found.');
            $result=$this->reconciliation->reconcileBound($tenantCompanyId,$payrollRunId,$sourceRevision,$expected,$actual);$hash=hash('sha256',json_encode($result,JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION|JSON_THROW_ON_ERROR));$now=now();
            DB::table('ext_titan_payroll_reconciliations')->updateOrInsert(['tenant_company_id'=>$tenantCompanyId,'payroll_run_id'=>$payrollRunId,'source_revision'=>$sourceRevision,'result_hash'=>$hash],['status'=>'completed','summary'=>json_encode($result['summary'],JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR),'completed_at'=>$now,'updated_at'=>$now,'created_at'=>$now]);
            $record=DB::table('ext_titan_payroll_reconciliations')->where('tenant_company_id',$tenantCompanyId)->where('payroll_run_id',$payrollRunId)->where('source_revision',$sourceRevision)->where('result_hash',$hash)->first(['id']);$result['reconciliation_id']=(int)($record->id??0);$result['result_hash']=$hash;
            $safe=['run_id'=>$payrollRunId,'reconciliation_id'=>$result['reconciliation_id'],'source_revision'=>$sourceRevision,'source_hash'=>$hash,'status'=>'completed','summary'=>$result['summary']];$this->signals->enqueue($tenantCompanyId,'payroll.reconciliation.completed',$idempotencyKey,$safe);
            if(array_sum([$result['summary']['missing'],$result['summary']['mismatched'],$result['summary']['duplicate'],$result['summary']['unresolved']])>0)$this->signals->enqueue($tenantCompanyId,'payroll.variance.detected',$idempotencyKey.':variance',$safe);
            return $result;
        });
    }
}
