@extends('panel.layout.app')
@section('title', $presentation['title'] ?? ($journey['name'] ?? $session->definition->name))
@section('content')
@php($vm = $payload['view_model'] ?? [])
@php($step = $presentation['step'] ?? ($vm['step'] ?? null))
@php($advanced = $journey['advancedRoute'] ?? null)
<div class="container-fluid py-4" data-crm-interaction-session="{{ $session->id }}">
    <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
        <div><div class="text-muted small">Titan Interaction Engine</div><h1 class="mb-1">{{ $presentation['title'] ?? ($journey['name'] ?? $session->definition->name) }}</h1><p class="text-muted mb-0">Chat, guided wizard and advanced form are different ways to complete the same CRM action.</p></div>
        <div class="d-flex gap-2"><a class="btn btn-outline-secondary" href="{{ url()->previous() }}">Back</a>@if($advanced)<a class="btn btn-outline-secondary" href="{{ route('dashboard.user.crm.interactions.advanced',$journey['key']) }}">Advanced form</a>@endif</div>
    </div>
    <div class="d-flex flex-wrap gap-2 mb-3" role="navigation" aria-label="Interaction modes">
        <a class="btn btn-outline-primary" data-interaction-mode="chat" href="#titan-zero-chat">Chat</a>
        <a class="btn btn-primary" data-interaction-mode="wizard" href="#interaction-wizard">Wizard</a>
        <a class="btn btn-outline-secondary" data-interaction-mode="review" href="#interaction-review">Review</a>
        @if($advanced)<a class="btn btn-outline-secondary" data-interaction-mode="advanced" href="{{ route('dashboard.user.crm.interactions.advanced',$journey['key']) }}">Advanced form</a>@endif
    </div>
    <div id="titan-zero-chat">@include('crm::components.interaction-ai-bar',['scope'=>$presentation['surface'] ?? ($journey['surface'] ?? 'all'),'context'=>['session_id'=>$session->id,'wizard_id'=>$session->definition->id,'journey_key'=>$journey['key'] ?? null]])</div>
    @if($guidance)<div class="alert alert-info">{{ $guidance }}</div>@endif
    @if($interactionErrors)<div class="alert alert-danger"><strong>This step needs attention.</strong><ul class="mb-0">@foreach($interactionErrors as $field=>$messages)@foreach((array)$messages as $message)<li>{{ $message }}</li>@endforeach @endforeach</ul></div>@endif
    @if($execution)<div class="alert alert-secondary"><strong>Interaction result:</strong> {{ is_array($execution) ? ($execution['status'] ?? $execution['capability'] ?? 'Prepared') : $execution }}</div>@endif
    <div class="row g-4" id="interaction-wizard">
        <div class="col-xl-8"><div class="card"><div class="card-header d-flex justify-content-between"><div><strong>{{ $step['title'] ?? 'Review' }}</strong><div class="text-muted small">Step {{ min(($presentation['step_index'] ?? $vm['step_index'] ?? 0)+1,max(1,$presentation['step_count'] ?? $session->definition->stepCount())) }} of {{ $presentation['step_count'] ?? $session->definition->stepCount() }}</div></div><span class="badge border text-body">{{ str_replace('_',' ',ucfirst($session->status)) }}</span></div><div class="card-body">
            @if($step)
            <form method="POST" action="{{ route('dashboard.user.crm.interactions.answer',$session->id) }}">@csrf
                <div class="row g-3">
                @foreach(($step['fields'] ?? []) as $field)
                    @php($id=$field['id']) @php($type=$field['type'] ?? 'text') @php($value=$session->data[$id] ?? null)
                    <div class="col-12 {{ in_array($type,['boolean'],true) ? 'col-md-6' : '' }}"><label class="form-label">{{ $field['label'] ?? $id }} @if($field['required'] ?? false)<span class="text-danger">*</span>@endif</label>
                    @if($type==='select' || (!empty($field['options']) && $type==='text'))
                        <select class="form-select" name="data[{{ $id }}]" @required($field['required'] ?? false)>@foreach(($field['options'] ?? []) as $option)<option value="{{ $option }}" @selected((string)$value===(string)$option)>{{ ucwords(str_replace('_',' ',$option)) }}</option>@endforeach</select>
                    @elseif($type==='boolean')
                        <input type="hidden" name="data[{{ $id }}]" value="0"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="data[{{ $id }}]" value="1" @checked((bool)$value)><label class="form-check-label">Yes</label></div>
                    @elseif($type==='number')
                        <input class="form-control" type="number" step="any" name="data[{{ $id }}]" value="{{ $value }}" @if(isset($field['min'])) min="{{ $field['min'] }}" @endif @if(isset($field['max'])) max="{{ $field['max'] }}" @endif @required($field['required'] ?? false)>
                    @elseif($type==='array')
                        <textarea class="form-control" rows="4" name="data[{{ $id }}]" placeholder='[ ]' @required($field['required'] ?? false)>{{ is_array($value) ? json_encode($value,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) : $value }}</textarea><div class="form-hint">Enter a JSON list. Titan Zero can fill this from conversation.</div>
                    @else
                        <input class="form-control" type="{{ $type==='email'?'email':'text' }}" name="data[{{ $id }}]" value="{{ is_scalar($value)?$value:'' }}" @required($field['required'] ?? false) @if(isset($field['max'])) maxlength="{{ $field['max'] }}" @endif>
                    @endif
                    </div>
                @endforeach
                </div><div class="d-flex flex-wrap justify-content-between gap-2 mt-4"><button class="btn btn-outline-secondary" name="_action" value="save">Save draft</button><button class="btn btn-primary" name="_action" value="continue">Continue</button></div>
            </form>
            @elseif($session->status==='awaiting_provider')
                <div id="interaction-review"><h3 class="h5">Review</h3><p class="text-muted">The workflow is complete and is waiting for governed authority before the CRM action executes.</p><form method="POST" action="{{ route('dashboard.user.crm.interactions.approve',$session->id) }}">@csrf<button class="btn btn-primary">Approve and execute</button></form></div>
            @elseif($session->status==='completed')
                <div class="text-center py-5" id="interaction-review"><div class="fs-1" aria-hidden="true">✓</div><h3>Completed</h3><p class="text-muted">The Interaction Engine completed this governed CRM workflow.</p></div>
            @else
                <div id="interaction-review"><h3 class="h5">Review</h3><p class="text-muted mb-0">This interaction is {{ str_replace('_',' ',$session->status) }}. Your answers remain saved.</p></div>
            @endif
        </div></div></div>
        <div class="col-xl-4"><div class="card"><div class="card-header"><strong>What Titan Zero knows</strong></div><div class="card-body"><dl class="mb-0"><dt>Workflow</dt><dd>{{ $session->definition->name }}</dd><dt>Capability</dt><dd><code>{{ $session->definition->capability }}</code></dd><dt>Session</dt><dd><code>{{ $session->id }}</code></dd><dt>Mode</dt><dd>{{ ucfirst(config('crm.interaction.authority_mode','earned')) }}</dd></dl></div></div></div>
    </div>
</div>
@endsection
