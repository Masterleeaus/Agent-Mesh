<?php

return [
    'enabled' => env('PAYROLL_AI_ENABLED', false),
    'tools' => [
        'anomaly_detection' => App\Extensions\TitanPayroll\AI\Tools\PayrollAnomalyTool::class,
    ],
    'guardrails' => [
        'redact_sensitive_fields' => App\Extensions\TitanPayroll\AI\Guardrails\PayrollDataGuardrail::class,
    ],
];
