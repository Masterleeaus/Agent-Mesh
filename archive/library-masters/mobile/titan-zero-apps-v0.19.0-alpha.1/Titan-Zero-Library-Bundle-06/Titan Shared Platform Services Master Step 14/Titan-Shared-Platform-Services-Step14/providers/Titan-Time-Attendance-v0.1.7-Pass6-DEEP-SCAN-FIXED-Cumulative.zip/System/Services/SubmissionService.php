<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Services;
use App\Extensions\TitanTimeAttendance\System\Models\{TimeEntry,TimeSubmission,TimeSubmissionItem}; use Illuminate\Support\Facades\DB; use Illuminate\Validation\ValidationException;
final class SubmissionService
{
 public function __construct(private readonly SignalOutboxService $signals) {}
 public function submit(int $tenantCompanyId,int $userId,string $weekStart,string $weekEnd,array $trace=[]): TimeSubmission
 {
  return DB::transaction(function()use($tenantCompanyId,$userId,$weekStart,$weekEnd,$trace){
   $entries=TimeEntry::query()->forCompany($tenantCompanyId)->where('user_id',$userId)->whereBetween('work_date',[$weekStart,$weekEnd])->orderBy('work_date')->get();
   if($entries->isEmpty())throw ValidationException::withMessages(['week'=>'No time entries exist for this week.']);
   $submission=TimeSubmission::query()->firstOrCreate(['tenant_company_id'=>$tenantCompanyId,'user_id'=>$userId,'week_start'=>$weekStart],['week_end'=>$weekEnd,'status'=>'submitted','submitted_at'=>now()]);
   if($submission->status!=='submitted')throw ValidationException::withMessages(['week'=>'This week has already been reviewed.']);
   foreach($entries as $entry)TimeSubmissionItem::query()->firstOrCreate(['tenant_company_id'=>$tenantCompanyId,'submission_id'=>$submission->getKey(),'time_entry_id'=>$entry->getKey()]);
   $payload=['submission_id'=>$submission->getKey(),'user_id'=>$userId,'week_start'=>$weekStart,'week_end'=>$weekEnd];$this->signals->record($tenantCompanyId,'time.submission.submitted',$payload,$trace+['dedup_key'=>isset($trace['dedup_key'])?$trace['dedup_key'].':submission':null]);$this->signals->record($tenantCompanyId,'time.submission.ready_for_review',$payload,$trace+['dedup_key'=>isset($trace['dedup_key'])?$trace['dedup_key'].':ready-review':null]);return $submission;
  });
 }
 public function review(int $tenantCompanyId,int $reviewerUserId,int $submissionId,string $decision,?string $notes=null,array $trace=[]): TimeSubmission
 {
  if(!in_array($decision,['approved','rejected'],true))throw ValidationException::withMessages(['decision'=>'Decision must be approved or rejected.']);
  $submission=TimeSubmission::query()->forCompany($tenantCompanyId)->whereKey($submissionId)->firstOrFail();if($submission->status!=='submitted')throw ValidationException::withMessages(['submission'=>'Submission has already been reviewed.']);
  $submission->forceFill(['status'=>$decision,'reviewed_by_user_id'=>$reviewerUserId,'reviewed_at'=>now(),'review_notes'=>$notes])->save();
  $this->signals->record($tenantCompanyId,'time.submission.reviewed',['submission_id'=>$submission->getKey(),'reviewed_by_user_id'=>$reviewerUserId,'status'=>$decision],$trace+['dedup_key'=>isset($trace['dedup_key'])?$trace['dedup_key'].':review':null]);return $submission;
 }
}
