<?php

namespace App\Extensions\TitanPayroll\Contracts\Services;

interface CleaningPayrollSettingsServiceContract
{
    public function defaults(?int $tenantCompanyId = null): array;

    public function normalize(array $settings, ?int $tenantCompanyId = null): array;

    public function validate(array $settings): array;
}
