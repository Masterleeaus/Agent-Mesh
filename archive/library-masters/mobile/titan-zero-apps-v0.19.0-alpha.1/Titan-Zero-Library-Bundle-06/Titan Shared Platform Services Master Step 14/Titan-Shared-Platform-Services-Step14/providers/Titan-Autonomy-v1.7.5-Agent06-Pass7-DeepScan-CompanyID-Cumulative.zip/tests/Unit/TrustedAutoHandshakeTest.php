<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanAutonomy\System\Enums\HandshakeDecision;
use App\Extensions\TitanAutonomy\System\Services\TrustedAutoHandshakeService;
use PHPUnit\Framework\TestCase;

final class TrustedAutoHandshakeTest extends TestCase
{
    public function test_ai_denial_prevents_trusted_auto_even_when_platform_and_user_approve(): void
    {
        $result = (new TrustedAutoHandshakeService())->evaluate(
            HandshakeDecision::Approved,
            HandshakeDecision::Approved,
            HandshakeDecision::Denied,
            ['max_total' => 1500],
        );
        self::assertFalse($result->trustedAutoActive());
    }

    public function test_all_three_approvals_with_scope_enable_trusted_auto(): void
    {
        $result = (new TrustedAutoHandshakeService())->evaluate(
            HandshakeDecision::Approved,
            HandshakeDecision::Approved,
            HandshakeDecision::Approved,
            ['max_total' => 1500],
        );
        self::assertTrue($result->trustedAutoActive());
    }
}
