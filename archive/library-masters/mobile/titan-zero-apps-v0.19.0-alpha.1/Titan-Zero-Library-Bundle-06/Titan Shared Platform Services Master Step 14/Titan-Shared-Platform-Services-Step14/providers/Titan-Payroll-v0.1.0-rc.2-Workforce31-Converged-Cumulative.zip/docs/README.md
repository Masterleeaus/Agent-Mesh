# Titan Payroll Documentation

Titan Payroll is a tenant-isolated payroll business-domain extension for Titan/MagicAI. This documentation describes the `0.1.0-rc.1` hostless release candidate. `tenant_company_id` is the canonical company boundary and is derived from the authenticated actor; request payload tenant identifiers are never authority.

Core documents: architecture and ownership under `architecture/`; security/privacy under `security/`; AI Workforce under `workforce/`; platform boundaries under `integrations/`; installer/upgrade procedures under `installer/`; operator runbooks under `operations/`; pass evidence under `releases/` and `audits/`.

The RC is **not exact-host certified**. Production promotion requires Installer 1.7.8 validation against the real MagicAI host through package, migration, boot, navigation, authorization, runtime, upgrade and uninstall stages.
