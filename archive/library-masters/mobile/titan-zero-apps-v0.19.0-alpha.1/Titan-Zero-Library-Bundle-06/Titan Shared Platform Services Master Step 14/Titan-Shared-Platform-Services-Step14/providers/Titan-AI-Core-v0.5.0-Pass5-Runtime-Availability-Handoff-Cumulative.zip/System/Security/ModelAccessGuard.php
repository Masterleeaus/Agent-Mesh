<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Security;

use App\Extensions\TitanAICore\System\DTO\ModelCapabilityProfile;
use App\Extensions\TitanAICore\System\DTO\TenantModelAccessPolicy;

final class ModelAccessGuard
{
    public function allows(TenantModelAccessPolicy $policy, ModelCapabilityProfile $profile): bool
    {
        if ($profile->tenantCompanyId !== null && !hash_equals($policy->tenantCompanyId, $profile->tenantCompanyId)) {
            return false;
        }
        if ($profile->isGlobal() && !$policy->allowGlobalFallback) {
            return false;
        }
        if (in_array($profile->provider, $policy->blockedProviders, true)) {
            return false;
        }
        if ($policy->allowedProviders !== [] && !in_array($profile->provider, $policy->allowedProviders, true)) {
            return false;
        }
        if (in_array($profile->model, $policy->blockedModels, true)) {
            return false;
        }
        if ($policy->allowedModels !== [] && !in_array($profile->model, $policy->allowedModels, true)) {
            return false;
        }

        return true;
    }
}
