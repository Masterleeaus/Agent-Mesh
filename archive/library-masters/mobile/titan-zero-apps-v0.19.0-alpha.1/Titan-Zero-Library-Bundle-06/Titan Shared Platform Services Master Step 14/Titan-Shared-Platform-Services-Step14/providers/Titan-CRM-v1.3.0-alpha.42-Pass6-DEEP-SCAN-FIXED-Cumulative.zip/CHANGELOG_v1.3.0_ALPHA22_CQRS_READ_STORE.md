# CRM 1.3.0-alpha.22 — CQRS Read Store + Titan Go Delta Sync

## Scope

Alpha.22 introduces a portable CQRS/read-model foundation so AI and selected dashboard/mobile consumers no longer need to repeatedly scan authoritative CRM OLTP tables. CRM remains the sole operational write authority.

## Added

- `CrmReadStorePort` abstraction with a default portable SQL projection implementation.
- Versioned read-projection registry shared by AI, dashboards and future reporting adapters.
- Disposable `crm_read_projection_state` and `crm_read_projection_records` stores.
- Projection rebuild service and `crm:projections:rebuild` command.
- Governed `crm.query.projection.status` and `crm.query.projection.rebuild` capabilities.
- Event-driven local projection refresh from committed CRM Signal outbox events.
- Owner-dashboard read projection and tenant-summary projection.
- Titan Go tenant/worker-scoped mobile change feed with signed opaque `sync_token` cursors.
- Delta work-order sync, tombstones, sequence tracking, token expiry and forced re-bootstrap behavior.
- CQRS/mobile query indexes for activities, work orders and receivables.

## Changed

- Named AI projections now read `CrmReadStorePort` instead of directly querying authoritative CRM tables.
- Common legacy AI resources (customer, deal, work order, appointment, invoice and activity) map to named CQRS projections.
- `crm.owner.dashboard.read` reads the `owner_dashboard` projection.
- Signal delivery attempts local projection refresh independently of external Titan Signal delivery; projection failure cannot roll back or suppress authoritative CRM mutation/Signal delivery.
- Titan Go bootstrap establishes `delta_v1`; subsequent signed cursor pulls return changes since the last sequence rather than rescanning all assigned work orders by timestamp.

## Compatibility

- Existing alpha.21 named projection contracts remain available through `CrmAiProjectionRegistry`.
- Legacy AI resources without a CQRS projection can temporarily use the explicit `read_store.fallback_to_live` compatibility setting.
- A missing projection may be bootstrapped once from authoritative state when `read_store.bootstrap_on_miss` is enabled.
- Existing pre-delta Titan Go cursor behavior remains supported for the transition request and returns a signed sync token for the next pull.
- No CRM domain tables were moved or replaced in alpha.22.

## Boundaries

- CRM authoritative writes remain on existing transactional tables.
- Projection tables are disposable and rebuildable; they are not business truth.
- External Titan Signal remains the system-wide event owner; CRM only projects its own committed outbox events locally.
- Elasticsearch/OpenSearch/vector storage are future adapters behind `CrmReadStorePort`, not hard dependencies.
