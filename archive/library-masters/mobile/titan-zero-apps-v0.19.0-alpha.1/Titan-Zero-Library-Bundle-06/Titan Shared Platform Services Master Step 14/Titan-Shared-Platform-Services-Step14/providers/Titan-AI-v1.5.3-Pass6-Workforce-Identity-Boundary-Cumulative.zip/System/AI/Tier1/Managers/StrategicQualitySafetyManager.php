<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\AI\Tier1\Managers;

use App\Extensions\TitanAI\System\AI\Contracts\AbstractAIWorker;

final class StrategicQualitySafetyManager extends AbstractAIWorker
{
    public static function id(): string { return 'strategic-quality-safety-manager'; }
    public static function name(): string { return 'Strategic Quality & Safety Manager'; }
    public static function tier(): int { return 1; }
    public static function role(): string { return 'manager'; }

    public static function capabilities(): array
    {
        return [
            'Quality trend analysis',
            'Safety-risk forecasting',
            'Compliance improvement planning',
        ];
    }

    public static function permissions(): array
    {
        return [
            'quality.read',
            'safety.read',
            'compliance.read',
        ];
    }

    public static function definition(): array
    {
        return parent::definition() + [
            'system_chat' => 'system-ai-chat',
            'runtime' => 'workcore-native-ai-runtime',
            'delegates_to' => 'tier_2_assistants',
            'operational_authority' => 'workcore_api_only',
            'planning_only' => true,
            'requires_governed_execution' => true,
        ];
    }
}
