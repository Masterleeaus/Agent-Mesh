# Titan Installer 1.2.0 Dependency Manifest Fix

Release: 1.5.2

The running Titan Extension Manager 1.2.0 requires dependency collections to be arrays of objects. Each dependency entry must contain `slug`.

This package uses:

```json
[]
```

`optional_dependencies` is an empty array when no optional dependencies are declared.
