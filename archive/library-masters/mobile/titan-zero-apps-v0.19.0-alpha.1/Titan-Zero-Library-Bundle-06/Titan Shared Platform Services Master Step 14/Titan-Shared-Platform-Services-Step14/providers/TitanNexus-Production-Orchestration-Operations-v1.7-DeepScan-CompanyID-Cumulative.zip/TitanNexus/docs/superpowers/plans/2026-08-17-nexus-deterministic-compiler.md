# Titan Nexus Deterministic Compiler Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a side-effect-free, deterministic Titan Nexus compiler that combines a tenant BusinessProfile with the exact versioned Titan Vertical Engine definition into a CompiledTitanConfig.

**Architecture:** Keep compilation pure and framework-independent. Consume vertical truth through a local source contract and a fail-closed adapter boundary; do not import another extension's implementation classes. Merge associative maps recursively, replace lists/scalars with business overrides, and preserve source/version/hash provenance in the compiled output.

**Tech Stack:** PHP 8.2+, Laravel 10+ service container, PHPUnit-compatible tests, standalone PHP verification.

## Global Constraints

- Preserve all v0.2.0 tenant, trace, hash, lineage, persistence, routes, and installer guarantees.
- Compilation must be deterministic and side-effect-free.
- Titan Vertical Engine remains authoritative for vertical definitions; Nexus must not duplicate vertical rules.
- Do not implement provisioning, Command Bus mutation, Risk decisions, Signals, Knowledge queries, or semantic diff execution in Pass 2.
- Do not directly import implementation classes from another Titan extension.
- Fail closed when the Vertical Engine public adapter is unavailable, malformed, or returns a different vertical identity/version.
- Business overrides recursively replace vertical defaults; list arrays are replaced atomically, not concatenated.

---

### Task 1: Versioned vertical definition domain

**Files:**
- Create `System/Domain/VerticalDefinition.php`
- Test `tests/Unit/CompilerTest.php`
- Test `tests/standalone-compiler-check.php`

**Interfaces:**
- `VerticalDefinition::fromArray(array $data): VerticalDefinition`
- `verticalId(): string`
- `verticalVersion(): string`
- `knowledgeSnapshotVersion(): ?string`
- `sections(): array`
- `fingerprint(): string`

- [ ] Write failing tests for deterministic definition hashing and malformed/mismatched definition metadata.
- [ ] Run standalone compiler harness and verify RED because the class does not exist.
- [ ] Implement the immutable definition value.
- [ ] Run the standalone compiler harness through the next expected missing compiler boundary.

### Task 2: Deterministic merge and compiler

**Files:**
- Create `System/Contracts/NexusCompilerContract.php`
- Create `System/Support/DeterministicMerge.php`
- Create `System/Services/DeterministicNexusCompiler.php`
- Extend `tests/Unit/CompilerTest.php`
- Extend `tests/standalone-compiler-check.php`

**Interfaces:**
- `NexusCompilerContract::version(): string`
- `NexusCompilerContract::compile(BusinessProfile $profile, VerticalDefinition $definition, string $configurationVersion): CompiledTitanConfig`
- `DeterministicMerge::override(array $defaults, array $overrides): array`

- [ ] Test recursive map merge, atomic list replacement, deterministic output hashes, and exact vertical identity/version enforcement.
- [ ] Implement the minimal compiler and merge utility.
- [ ] Verify standalone compiler tests GREEN.

### Task 3: Vertical Engine adapter boundary

**Files:**
- Create `System/Contracts/VerticalDefinitionSourceContract.php`
- Create `System/Adapters/VerticalEngine/VerticalEngineAdapter.php`
- Modify `config/titan-nexus.php`
- Modify `System/TitanNexusServiceProvider.php`
- Extend package/architecture checks.

**Interfaces:**
- `VerticalDefinitionSourceContract::resolve(BusinessProfile $profile): VerticalDefinition`
- `VerticalEngineAdapter` accepts a resolver callable returning a public definition array and rejects unavailable/malformed/mismatched definitions.

- [ ] Test fail-closed behavior for malformed adapter results and vertical drift.
- [ ] Add a Laravel container binding driven by configurable public-contract class and method names, without cross-extension implementation imports.
- [ ] Keep the default adapter unwired rather than guessing an upstream private contract.

### Task 4: Manager compile orchestration and truthful capabilities

**Files:**
- Modify `System/Contracts/NexusManagerContract.php`
- Modify `System/Services/NexusManager.php`
- Modify `extension.json`
- Modify `extension.manifest.json`
- Modify `README.md`
- Modify views/version copy.

**Interfaces:**
- `NexusManagerContract::compileDraft(NexusCompilation $draft, string $configurationVersion = '1'): NexusCompilation`
- `newDraft(...)` uses the injected compiler's exact version.

- [ ] Test that compileDraft resolves the exact profile vertical definition and advances only the immutable compilation aggregate.
- [ ] Advertise only `nexus.compile` and adapter/domain capabilities now actually implemented; keep provisioning/preview/diff absent.
- [ ] Advance package version to 0.3.0 and compiler status metadata.

### Task 5: Verification and cumulative package

**Files:**
- Package the complete `TitanNexus/` tree.

- [ ] Run standalone domain checks.
- [ ] Run standalone compiler checks.
- [ ] Run package architecture checks.
- [ ] Lint every PHP file.
- [ ] Parse all JSON files.
- [ ] Scan for cross-extension imports, dangerous executable calls, path traversal, duplicate ZIP entries, and unexpected binaries.
- [ ] Build cumulative v0.3.0 ZIP and calculate SHA-256.
