<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Persistence\Models;

use Illuminate\Database\Eloquent\Model;
use App\Extensions\TitanPrime\System\Persistence\Models\Concerns\HasCanonicalCompanyIdCompatibility;

final class PrimeMissionRecord extends Model
{
    use HasCanonicalCompanyIdCompatibility;

    protected $table = 'titan_prime_missions';

    protected $guarded = [];

    protected $casts = [
        'company_id' => 'integer',
        'tenant_company_id' => 'integer',
        'lock_version' => 'integer',
        'objective_json' => 'array',
        'budget_json' => 'array',
        'payload' => 'array',
    ];
}
