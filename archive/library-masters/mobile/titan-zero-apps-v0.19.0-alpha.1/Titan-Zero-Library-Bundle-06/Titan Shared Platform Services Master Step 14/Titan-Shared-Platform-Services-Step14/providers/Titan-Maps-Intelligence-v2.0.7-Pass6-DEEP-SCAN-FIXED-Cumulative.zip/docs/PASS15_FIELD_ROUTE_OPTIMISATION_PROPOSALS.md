# Joint Pass 15 — Titan Field Route Optimisation Proposals

Titan Maps Intelligence now exposes a bounded, read-only Field peer operation for route optimisation proposals.

## Ownership

Maps owns spatial computation and proposal evidence. Titan Field owns routes, route stops, appointments, dispatch and every consequential write.

`FieldRouteOptimizationProposalService` accepts only an explicit Field route snapshot and geocoded stop list. It builds a traffic-aware travel matrix when the configured provider is available, conservatively reuses existing stale/fallback matrix behavior, and executes the existing deterministic `RoutePlanOptimiser` without creating or changing a Maps route plan.

The response includes:

- baseline and proposed stop order;
- baseline/optimised distance and duration;
- savings;
- appointment-window schedule and violations;
- locked-stop constraints;
- algorithm, heuristic and timeout state;
- matrix/provider/cache provenance;
- warnings;
- `input_hash` and `proposal_hash`;
- expiry;
- `read_only=true` and `no_field_write=true`.

Maps records its immutable spatial proposal evidence in `maps_field_route_optimisation_proposals`. It does not call Titan Field command/write services from the proposal engine. Titan Field separately stores the governed review/apply lifecycle.

Straight-line fallback evidence may be used only when provider matrix routing is unavailable, and the provenance/warning identifies that downgrade. It is not represented as provider road routing.
