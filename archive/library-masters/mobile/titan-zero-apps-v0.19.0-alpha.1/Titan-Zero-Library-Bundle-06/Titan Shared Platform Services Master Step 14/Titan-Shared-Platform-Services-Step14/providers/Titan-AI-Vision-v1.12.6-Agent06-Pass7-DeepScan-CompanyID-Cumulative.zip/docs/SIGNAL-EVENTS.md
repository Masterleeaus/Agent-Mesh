# Signal Events

No production Signal events are mandatory in v1.2.0. Future events must use registered schemas, service identity and causal lineage before being enabled.
