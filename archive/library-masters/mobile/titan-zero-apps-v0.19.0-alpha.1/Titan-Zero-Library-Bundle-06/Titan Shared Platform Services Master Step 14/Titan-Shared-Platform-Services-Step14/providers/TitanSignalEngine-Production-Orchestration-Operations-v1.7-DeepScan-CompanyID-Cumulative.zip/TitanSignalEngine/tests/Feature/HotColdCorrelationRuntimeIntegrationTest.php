<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Extensions\TitanSignalEngine\System\Data\SignalArchiveEntry;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Persistence\SignalEventStore;
use App\Extensions\TitanSignalEngine\System\Services\CorrelationService;
use App\Extensions\TitanSignalEngine\System\Services\HistoryCorrelationAssembler;
use App\Extensions\TitanSignalEngine\System\Services\LocalSignalArchiveStore;
use App\Extensions\TitanSignalEngine\System\Services\SignalArchiveCatalog;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority;
use App\Extensions\TitanSignalEngine\System\Services\SignalHistoryQueryService;
use App\Extensions\TitanSignalEngine\System\Services\SignalQueryService;
use App\Extensions\TitanSignalEngine\System\Services\TraceAnalyzer;
use App\Extensions\TitanSignalEngine\System\Services\TraceProfileRegistry;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

final class HotColdCorrelationRuntimeIntegrationTest extends TestCase
{
    private SignalEventStore $store;
    private SignalArchiveCatalog $catalog;
    private LocalSignalArchiveStore $archiveStore;
    private CorrelationService $correlation;

    protected function setUp(): void
    {
        parent::setUp();
        foreach (glob(dirname(__DIR__, 2) . '/database/migrations/*.php') ?: [] as $migrationFile) {
            (require $migrationFile)->up();
        }
        Storage::fake('local');
        config()->set('titan-signal-engine.archive_disk', 'local');
        config()->set('titan-signal-engine.archive_path', 'titan-signal-engine/archive');

        $authority = new SignalEmitterAuthority('hot-cold-test-secret', []);
        $validator = new SignalContextValidator($authority);
        $this->store = new SignalEventStore();
        $query = new SignalQueryService($this->store, $validator);
        $this->catalog = new SignalArchiveCatalog();
        $this->archiveStore = new LocalSignalArchiveStore();
        $history = new SignalHistoryQueryService($query, $this->store, $this->catalog, $this->archiveStore, $validator);
        $this->correlation = new CorrelationService(
            $history,
            $history,
            new TraceProfileRegistry(),
            new TraceAnalyzer(),
            new HistoryCorrelationAssembler(),
        );
    }

    private function context(int $tenant): SignalContext
    {
        return SignalContext::tenantHuman($tenant, 'reader-' . $tenant, 'session-' . $tenant, 'test');
    }

    /** @return array{root:SignalEnvelope,child:SignalEnvelope,archive:array<string,mixed>} */
    private function seedMixedTrace(): array
    {
        $root = SignalEnvelope::fromArray([
            'event_type' => 'test.root',
            'tenant_company_id' => 42,
            'source' => 'test-suite',
        ]);
        $child = $root->child('test.child', 'test-suite');
        $this->store->append($child);

        $batchId = '0198bbbb-0000-7000-8000-000000000099';
        $archive = $this->archiveStore->archive($batchId, [$root->toArray()], [
            'scope' => 'tenant',
            'tenant_company_id' => 42,
        ]);
        $this->catalog->record([
            new SignalArchiveEntry(
                eventId: $root->eventId,
                batchId: $batchId,
                scope: 'tenant',
                tenantCompanyId: 42,
                eventType: $root->eventType,
                traceId: $root->traceId,
                correlationId: $root->correlationId,
                causationId: null,
                rootCausationId: $root->rootCausationId,
                occurredAt: $root->occurredAt->format(DATE_ATOM),
                recordedAt: $root->recordedAt->format(DATE_ATOM),
                archiveDriver: $archive['driver'],
                archiveLocator: $archive['locator'],
                archiveChecksum: $archive['checksum'],
                archiveSequence: 1,
                privacyProjected: false,
                originalChecksum: $root->checksum,
            ),
        ]);

        return compact('root', 'child', 'archive');
    }

    public function test_ancestors_and_trace_cross_hot_cold_boundary(): void
    {
        ['root' => $root, 'child' => $child] = $this->seedMixedTrace();

        $ancestors = $this->correlation->ancestors($child->eventId, $this->context(42), 42);
        self::assertSame([$root->eventId], array_map(static fn (SignalEnvelope $event): string => $event->eventId, $ancestors));

        $trace = $this->correlation->trace($root->traceId, $this->context(42), 42);
        self::assertSame('mixed', $trace['storage_tier']);
        self::assertSame(1, $trace['hot_event_count']);
        self::assertSame(1, $trace['cold_event_count']);
        self::assertTrue($trace['cold_history_complete']);
        self::assertSame('cold', $trace['event_storage'][$root->eventId]['storage_tier']);
        self::assertSame('hot', $trace['event_storage'][$child->eventId]['storage_tier']);
        self::assertTrue($trace['edges'][0]['resolved_in_result']);
        self::assertSame('mixed', $trace['rewind']['storage_tier']);
    }

    public function test_corrupt_cold_batch_marks_trace_partial_instead_of_complete(): void
    {
        ['root' => $root, 'archive' => $archive] = $this->seedMixedTrace();
        Storage::disk('local')->put($archive['locator'], 'corrupt');

        $trace = $this->correlation->trace($root->traceId, $this->context(42), 42);
        self::assertSame('partial', $trace['analysis']['status']);
        self::assertFalse($trace['cold_history_complete']);
        self::assertSame(1, $trace['cold_failure_count']);
        self::assertFalse($trace['rewind']['cold_history_complete']);
    }
}
