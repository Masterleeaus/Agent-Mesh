<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface InteractionEngineBridgeContract
{
    /** Create/continue the canonical structured journey; do not execute domain mutations directly. */
    public function prepareJourney(string $capability, ?string $workflowKey, array $context): array;
}
