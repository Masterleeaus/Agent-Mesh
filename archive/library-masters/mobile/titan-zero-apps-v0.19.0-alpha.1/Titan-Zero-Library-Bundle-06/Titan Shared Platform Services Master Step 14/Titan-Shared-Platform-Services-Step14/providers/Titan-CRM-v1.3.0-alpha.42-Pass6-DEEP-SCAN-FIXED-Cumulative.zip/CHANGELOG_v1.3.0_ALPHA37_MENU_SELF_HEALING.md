# Titan CRM Core v1.3.0-alpha.37 — Menu Self-Healing & Route Integrity

## Fixed

- Adds forward migration `2026_08_18_000046_resync_crm_core_menu.php` so hosts that already recorded alpha.6/alpha.8/alpha.10 menu migrations still receive the current canonical CRM menu definition.
- Retires stale CRM-owned menu links for extracted Field, Locker, Ledger/finance, Titan Pay and historical autonomy surfaces.
- Reparents and relabels retained CRM menu records into the canonical Overview / Customers / Sales / Projects / Commercial / Insights / Automate / Settings structure.
- Preserves `company_id` as the canonical CRM tenant boundary introduced in alpha.36.
- Adds package contracts proving the resync migration exists and every canonical menu link maps to a shipped CRM/Sales named route.

## Upgrade behavior

This is intentionally versioned as alpha.37 because alpha.36 may already be recorded as installed. Extension Manager 1.7.8 will therefore execute migration `000046` as a new forward migration instead of relying on previously-recorded menu migrations.

The migration is idempotent and uses `CrmMenuInstaller::sync()`. Its rollback path retains the canonical safe menu instead of re-enabling stale links to domains CRM Core no longer owns.
