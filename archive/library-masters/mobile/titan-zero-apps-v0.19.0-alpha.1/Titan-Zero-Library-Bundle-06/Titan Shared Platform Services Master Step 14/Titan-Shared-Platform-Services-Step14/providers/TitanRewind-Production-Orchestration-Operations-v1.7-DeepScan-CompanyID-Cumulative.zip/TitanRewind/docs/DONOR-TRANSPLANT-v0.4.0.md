# Titan Rewind donor transplant — v0.4.0 forensic core

## Donor code harvested

This pass extracted and redesigned the useful concepts from the donor's:

- `RewindIntegrityService`
- `DriftDetectionService`
- `RewindDiffService`
- `RewindAssistantRouterService` root-cause intent
- `RewindIntegrityCheck`
- `RewindDriftFinding`
- snapshot comparison surface

The donor implementations were not copied blindly. Their useful behavior was reimplemented against the v0.3 canonical tenant/trace/causation architecture.

## Critical donor defects corrected

### Self-invalidating integrity hashes

The donor rebuilt hashes from persisted Eloquent attributes even though the original hash was created before database-generated fields existed. v0.4 hashes only canonical event content and explicitly excludes local persistence/integrity metadata.

### Fork-prone previous-hash chain

The donor chose the previous event without a trace serialization lock. v0.4 serializes ingestion-chain assignment by locking the tenant/trace index row, then assigns a monotonically increasing `chain_position`.

### Chronology incorrectly coupled to integrity

Late events must not look like tampering. v0.4 uses separate chronological and ingestion orders.

### Drift findings without trace-native diagnostics

v0.4 drift rules consume canonical trace integrity, timing, sequence, causation and risk evidence rather than querying a legacy generic event table.

### Shallow root-cause heuristics

v0.4 root-cause analysis selects the earliest explicit failure/rejection/denial/timeout and walks upstream causation links. It also detects later recovery/compensation events.

### Snapshot comparison tenant ambiguity

Snapshot comparison is scoped by explicit `tenant_company_id + trace_id` and compares only snapshots sharing the same entity identity.

## Still deliberately excluded

- donor global Eloquent observers
- direct rollback/model mutation
- duplicate approval engines
- duplicate correction executors
- legacy `company_id` tenancy
- donor Filament dependency
- donor AI-provider execution
- evidence/compliance export (next transplant pass)
- comparative replay (later transplant pass)
