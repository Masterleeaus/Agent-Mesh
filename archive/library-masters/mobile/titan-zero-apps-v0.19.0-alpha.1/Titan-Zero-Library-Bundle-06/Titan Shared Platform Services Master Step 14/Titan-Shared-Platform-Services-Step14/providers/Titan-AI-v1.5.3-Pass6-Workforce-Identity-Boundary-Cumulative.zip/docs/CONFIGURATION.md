# Configuration

## Runtime

Environment/config keys used by `config/titan-ai.php` include:

- `TITAN_AI_ENABLED`
- `TITAN_AI_PROVIDER`
- `TITAN_AI_MODEL`
- `TITAN_AI_OPENAI_ENDPOINT` (only for explicit custom OpenAI-compatible profiles)
- `TITAN_AI_OPENAI_KEY` (only for explicit custom OpenAI-compatible profiles)
- `OPENAI_API_KEY` (host/custom profile as configured by MagicAI)
- `TITAN_AI_WORKCORE_ENABLED`
- `TITAN_AI_WORKCORE_GATEWAY_BINDING`

The production default is `TITAN_AI_PROVIDER=magicai-host`; when `TITAN_AI_MODEL` is unset, the MagicAI host selects its default word model. Provider endpoint and credential values are server-controlled. Runtime request payloads cannot supply them.

## Governance

`config/titan-ai-governance.php` controls governance enablement, council reviewers, risk policy, cost limits and governed-memory policy.

Important environment keys include:

- `TITAN_AI_GOVERNANCE_ENABLED`
- `TITAN_COUNCIL_PROVIDER` (defaults to the explicit `openai` provider profile for the current Responses-based governance reviewer)
- `TITAN_COUNCIL_PRIMARY_REVIEWER`
- `TITAN_COUNCIL_SECONDARY_REVIEWER`

## Company boundary

No environment setting can replace the tenant key. TitanAI always uses the authenticated host company ID as `company_id`. Callers must pass a positive integer `TitanAIRequest::companyId`; request payload data must not override trusted company membership context.

## WorkCore

Canonical WorkCore should bind an object at the configured gateway binding (default `titan.workcore.ai.gateway`) exposing:

```php
read(string $domain, string $operation, array $payload): array
execute(string $domain, string $operation, array $payload): array
```

State-changing operations are fail-closed unless mapped in `titan-ai.workcore.operation_tool_map`.

Rollback is also fail-closed. A rollback is offered only when `rollback_operation_map` explicitly maps the source operation to a verified canonical WorkCore compensating operation.

## Provider credentials

The bundled resolver reads credentials from trusted Laravel configuration/environment. For company BYO-key operation, replace `CredentialResolverContract` with a host vault-backed implementation; do not inject keys into `TitanAIRequest` payloads.
