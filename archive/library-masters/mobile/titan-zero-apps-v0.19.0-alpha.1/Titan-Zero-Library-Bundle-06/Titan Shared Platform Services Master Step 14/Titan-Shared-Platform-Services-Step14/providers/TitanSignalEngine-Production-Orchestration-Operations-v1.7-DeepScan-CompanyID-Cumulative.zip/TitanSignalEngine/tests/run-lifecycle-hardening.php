<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/RetentionClass.php';
require __DIR__ . '/../System/Data/RetentionPolicy.php';
require __DIR__ . '/../System/Data/SignalRedactionOverlay.php';
require __DIR__ . '/../System/Data/SignalRateLimitDecision.php';
require __DIR__ . '/../System/Services/SourceRateLimitPolicy.php';

use App\Extensions\TitanSignalEngine\System\Data\RetentionClass;
use App\Extensions\TitanSignalEngine\System\Data\RetentionPolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalRedactionOverlay;
use App\Extensions\TitanSignalEngine\System\Services\SourceRateLimitPolicy;

function assertTrue7(bool $condition, string $message): void {
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

$audit = RetentionPolicy::for(RetentionClass::Audit);
assertTrue7($audit->retentionDays === 2555 && $audit->archiveRequired, 'Audit retention must be seven years and archived before pruning.');
$critical = RetentionPolicy::for(RetentionClass::CriticalAudit);
assertTrue7($critical->retentionDays === null && ! $critical->prunable, 'Critical audit events must never be automatically prunable.');
$telemetry = RetentionPolicy::for(RetentionClass::Telemetry);
assertTrue7($telemetry->retentionDays === 90 && $telemetry->prunable, 'Telemetry retention must default to 90 days.');
$debug = RetentionPolicy::for(RetentionClass::Debug);
assertTrue7($debug->prunable && ! $debug->archiveRequired, 'Debug retention must be prunable without forcing cold archive storage.');

$overlay = new SignalRedactionOverlay([
    ['op' => 'remove', 'path' => 'payload.customer.email'],
    ['op' => 'replace', 'path' => 'payload.customer.name', 'value' => '[REDACTED]'],
    ['op' => 'replace', 'path' => 'metadata.reason_code', 'value' => 'privacy_request'],
]);
$projected = $overlay->apply([
    'payload' => ['customer' => ['email' => 'secret@example.com', 'name' => 'Jane'], 'job_id' => 9],
    'metadata' => ['reason_code' => 'original'],
]);
assertTrue7(! isset($projected['payload']['customer']['email']), 'Redaction remove operation must remove nested values.');
assertTrue7($projected['payload']['customer']['name'] === '[REDACTED]', 'Redaction replace operation must replace nested values.');
assertTrue7($projected['payload']['job_id'] === 9, 'Redaction must not disturb unrelated payload fields.');

$policy = new SourceRateLimitPolicy(defaultPerMinute: 1000, systemPerMinute: 5000, degradedMultiplier: 0.5);
assertTrue7($policy->decide('tenant', 999, false)->allowed, 'Count below tenant limit must be allowed.');
assertTrue7(! $policy->decide('tenant', 1000, false)->allowed, 'Count at tenant limit must be rejected.');
assertTrue7($policy->decide('system', 4999, false)->allowed, 'System source below system limit must be allowed.');
assertTrue7(! $policy->decide('tenant', 500, true)->allowed, 'Backpressure must lower the tenant source limit.');
assertTrue7($policy->decide('tenant', 499, true)->effectiveLimit === 500, 'Backpressure effective limit must be explicit.');

fwrite(STDOUT, "lifecycle hardening behavior: PASS\n");
