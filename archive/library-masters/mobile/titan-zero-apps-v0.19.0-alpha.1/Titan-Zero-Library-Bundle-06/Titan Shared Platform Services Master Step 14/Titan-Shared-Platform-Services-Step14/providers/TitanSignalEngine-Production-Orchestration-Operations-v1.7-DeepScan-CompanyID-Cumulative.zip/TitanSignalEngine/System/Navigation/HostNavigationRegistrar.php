<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Navigation;

use Illuminate\Contracts\Foundation\Application;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Bridges Titan Signal navigation into modern Titan contribution registries and
 * self-heals MagicAI/Website1408's database-backed `menus` navigation.
 */
final class HostNavigationRegistrar
{
    private const OWNER = 'titan-signal-engine';
    private const USER_REGISTRY = 'App\\Support\\Extensions\\MenuContributionRegistry';
    private const CONTRIBUTION_REGISTRY = 'App\\Support\\Extensions\\ContributionRegistry';
    private const MENU_SERVICE = 'App\\Services\\Common\\MenuService';

    public function __construct(
        private readonly Application $app,
        private readonly SignalAdminNavigation $adminNavigation,
        private readonly LegacyMenuStore $menuStore,
    ) {
    }

    public function register(): void
    {
        $this->registerContributions();
        $this->syncHostMenus();
    }

    public function registerContributions(): bool
    {
        $admin = $this->adminNavigation->items();

        $adminRegistered = $this->registerWith(self::CONTRIBUTION_REGISTRY, [
            ['navigation.admin', self::OWNER, $admin],
            ['navigation.admin', $admin],
            [self::OWNER, $admin],
            [$admin],
        ]);

        if (! $adminRegistered) {
            $adminRegistered = $this->registerWith(self::USER_REGISTRY, [
                ['navigation.admin', self::OWNER, $admin],
                ['navigation.admin', $admin],
            ]);
        }

        return $adminRegistered;
    }

    /**
     * @return array{available:bool,changed:bool,regenerated:bool,reason:?string,admin_id:?int}
     */
    public function syncHostMenus(bool $forceRegenerate = false): array
    {
        if (! $this->menuStore->available()) {
            return $this->result(false, false, false, 'menus_table_unavailable');
        }

        try {
            $columns = $this->menuStore->columns();
            if (! isset($columns['id']) || ! isset($columns['key'])) {
                return $this->result(false, false, false, 'menus_identity_columns_unavailable');
            }

            $changed = false;

            // Signal is platform infrastructure. Never recreate the short-lived rc.5 user row.
            $legacyUserDeleted = $this->menuStore->deleteByKey('titan_signal_pulse');
            $changed = $legacyUserDeleted > 0 || $changed;

            $definitions = $this->adminNavigation->items();
            $parent = $definitions[0] ?? null;
            if (! is_array($parent) || ($parent['key'] ?? null) !== 'titan_signal_engine_admin') {
                return $this->result(false, $changed, false, 'navigation_definition_missing');
            }

            $changed = $this->upsertDefinition($parent, $columns, true, null) || $changed;
            $adminId = $this->menuStore->idByKey((string) $parent['key']);
            if ($adminId === null) {
                return $this->result(false, $changed, false, 'parent_menu_row_unavailable');
            }

            foreach (array_slice($definitions, 1) as $definition) {
                if (! is_array($definition)) continue;
                $changed = $this->upsertDefinition($definition, $columns, true, (int) $adminId) || $changed;
            }

            $regenerated = false;
            if ($changed || $forceRegenerate) {
                $regenerated = $this->regenerateMenuCache();
            }

            return $this->result(true, $changed, $regenerated, null, (int) $adminId);
        } catch (Throwable $e) {
            Log::warning('Titan Signal host menu self-heal failed.', [
                'error_class' => $e::class,
                'error_hash' => substr(hash('sha256', $e->getMessage()), 0, 16),
            ]);

            return $this->result(false, false, false, 'menu_sync_failed');
        }
    }

    /** @param array<string,mixed> $definition @param array<string,bool> $columns */
    private function upsertDefinition(array $definition, array $columns, bool $admin, ?int $parentId): bool
    {
        $key = trim((string) ($definition['key'] ?? ''));
        if ($key === '') return false;

        $existing = $this->menuStore->firstByKey($key);
        $matchCount = $this->menuStore->countByKey($key);
        if ($matchCount > 1) {
            Log::warning('Titan Signal detected duplicate host menu keys; preserving rows and repairing only the canonical first row.', [
                'key' => $key,
                'count' => $matchCount,
            ]);
        }

        $now = now();
        $payload = [
            'parent_id' => $parentId,
            'route' => $definition['route'] ?? null,
            'route_slug' => $definition['route_slug'] ?? null,
            'label' => $definition['label'] ?? $key,
            'icon' => $definition['icon'] ?? 'tabler-heart-rate-monitor',
            'svg' => $definition['svg'] ?? null,
            'order' => (int) ($definition['order'] ?? $definition['priority'] ?? ($admin ? 995 : 70)),
            'is_active' => (bool) ($definition['is_active'] ?? true) ? 1 : 0,
            'params' => json_encode($definition['params'] ?? [], JSON_UNESCAPED_SLASHES),
            'type' => $definition['type'] ?? 'item',
            'badge' => $definition['badge'] ?? null,
            'extension' => '1',
            'is_admin' => $admin ? 1 : 0,
            'updated_at' => $now,
        ];
        $payload = array_intersect_key($payload, $columns);

        if ($existing !== null) {
            // Preserve enable/disable choice. Preserve valid administrator ordering, but always
            // repair parent/route hierarchy because those fields are extension-owned structure.
            unset($payload['is_active']);
            if ($admin && (int) ($existing->order ?? 0) >= 900) unset($payload['order']);

            $changed = false;
            foreach ($payload as $column => $value) {
                if ($column === 'updated_at') continue;
                if ($this->normaliseComparable($existing->{$column} ?? null) !== $this->normaliseComparable($value)) {
                    $changed = true;
                    break;
                }
            }
            if (! $changed) return false;

            $this->menuStore->updateById((int) ($existing->id ?? 0), $payload);
            return true;
        }

        $insert = array_merge([
            'key' => $key,
            'created_at' => $now,
            'custom_menu' => 0,
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
        ], $payload);
        $insert = array_intersect_key($insert, $columns);
        $this->menuStore->insert($insert);

        return true;
    }

    /** @param list<array<int,mixed>> $argumentSets */
    private function registerWith(string $class, array $argumentSets): bool
    {
        if (! class_exists($class)) return false;

        try { $registry = $this->app->make($class); } catch (Throwable) { return false; }

        foreach (['register', 'contribute', 'add'] as $method) {
            if (! method_exists($registry, $method)) continue;
            foreach ($argumentSets as $arguments) {
                try {
                    $registry->{$method}(...$arguments);
                    return true;
                } catch (Throwable) {
                    // Try the next known host registry signature.
                }
            }
        }
        return false;
    }

    private function regenerateMenuCache(): bool
    {
        $class = self::MENU_SERVICE;
        if (! class_exists($class) || ! method_exists($class, 'regenerate')) return false;

        try {
            $service = $this->app->make($class);
            $service->regenerate();
            return true;
        } catch (Throwable) {
            try { $class::regenerate(); return true; } catch (Throwable) { return false; }
        }
    }

    private function normaliseComparable(mixed $value): string
    {
        if ($value === null) return '';
        if (is_bool($value)) return $value ? '1' : '0';
        return (string) $value;
    }

    /** @return array{available:bool,changed:bool,regenerated:bool,reason:?string,admin_id:?int} */
    private function result(bool $available, bool $changed, bool $regenerated, ?string $reason, ?int $adminId = null): array
    {
        return [
            'available' => $available,
            'changed' => $changed,
            'regenerated' => $regenerated,
            'reason' => $reason,
            'admin_id' => $adminId,
        ];
    }
}
