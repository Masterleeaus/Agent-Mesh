# Canonical OutcomeRecord v1

`titan_wisdom_outcome_records` is the canonical durable outcome projection. The earlier `titan_wisdom_outcomes` table is retained as a legacy compatibility seam and receives no new canonical writes.

## Lifecycle

- `pending` / `observing`: unresolved and `inconclusive`.
- `resolved`: terminal conclusion backed by validated authoritative supporting evidence.
- `revised`: new append-only conclusion linked to a prior terminal record.
- `contradicted`: new append-only conclusion backed by authoritative contradicting evidence.

Pending-to-resolved changes update the current projection through optimistic compare-and-swap and append a snapshot to `titan_wisdom_outcome_transitions`. Later corrections never mutate the historical terminal record; they create a new OutcomeRecord with `revises_outcome_id`.

## Evidence

Evidence is not embedded as interpretation. Durable evidence lives in `titan_wisdom_evidence_references`, while `titan_wisdom_outcome_evidence` stores tenant-scoped links and relationship semantics. Outcome `evidence_refs` are a projection of evidence used for the recorded conclusion.
