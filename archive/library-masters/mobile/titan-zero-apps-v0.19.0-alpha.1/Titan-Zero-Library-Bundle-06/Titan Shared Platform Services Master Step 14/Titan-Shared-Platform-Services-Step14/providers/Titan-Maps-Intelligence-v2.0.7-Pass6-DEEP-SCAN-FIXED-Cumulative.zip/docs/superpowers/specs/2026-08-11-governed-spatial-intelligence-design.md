# Titan Maps Intelligence Pass 17 — Governed Spatial Intelligence Design

## Goal

Upgrade the existing Titan Maps Intelligence extension into Titan's governed geospatial operational intelligence capability without replacing its working discovery, map, GPS, geofence, routing, dispatch, territory, analytics or resource-fallback functionality.

## Architecture

Pass 17 is an adapter/integration release. Existing extension-local services and capability IDs remain compatible. A new canonical spatial capability layer maps the platform-wide names `location.geocode`, `territory.lookup`, `territory.validate`, `route.estimate`, `route.compare`, `job.travel_context`, `service_area.check`, and `nearby.search` onto the already-implemented Maps domain services.

Maps owns spatial computation and evidence only. CRM remains authoritative for jobs, customers and source addresses. Consequential mutations remain outside Maps unless they concern Maps-owned state, and AI-originated mutation requests must be governance-checked before execution.

## Canonical Capability Contract

Every exposed Maps capability, legacy or canonical, must declare:

- capability name / ID
- owning extension: `titan-maps-intelligence`
- input schema
- output schema
- risk profile
- autonomy requirement
- evidence requirements
- offline policy
- reversibility
- idempotency strategy
- mutation/read classification
- canonical alias where applicable

Canonical capabilities:

1. `location.geocode` — geocode an address using configured provider abstraction; no CRM write.
2. `territory.lookup` — list/evaluate matching Maps-owned territory evidence for a coordinate.
3. `territory.validate` — validate whether a coordinate/reference satisfies service-territory constraints.
4. `route.estimate` — provider-backed route estimate with durable/fallback provenance.
5. `route.compare` — compare an origin against multiple destinations using Travel Matrix.
6. `job.travel_context` — resolve a CRM/WorkCore job reference through the existing reference gateway, then return spatial/service-area/route context without copying authoritative job fields.
7. `service_area.check` — return service-area inclusion/exclusion plus travel-zone/pricing-signal evidence; pricing remains advisory.
8. `nearby.search` — find authorised nearby worker/supplier/contractor resources through existing nearest-resource intelligence.

## Governance Integration

The extension introduces optional contracts for platform engines:

- `SpatialRiskGateway`
- `SpatialAssuranceGateway`
- `SpatialAutonomyGateway`
- `SpatialCommandBusGateway`
- `SpatialSignalPublisher`
- `SpatialRewindRecorder`
- `SpatialKnowledgeGateway`

The service provider prefers compatible host adapters when installed. Extension-local fallbacks are intentionally conservative:

- Signal fallback writes structured Maps audit/signal records without claiming platform Signal ingestion.
- Rewind fallback records structured decision receipts locally/audit-only.
- Knowledge fallback returns `available=false`; it never invents jurisdictional guidance.
- Risk/Assurance/Autonomy fallbacks permit read-only and preparatory spatial intelligence but do not grant increased authority for consequential mutation.
- Command Bus fallback cannot perform authoritative cross-extension mutations.

## Execution Context

AI/tool requests use a structured `SpatialExecutionContext` containing:

- `trace_id`
- `correlation_id`
- `causation_id`
- `tenant_company_id`
- actor user ID
- agent ID
- conversation ID
- capability ID
- origin (`human`, `ai`, `system`, `offline_sync`)

Client input may supply trace/correlation/causation identifiers, but `tenant_company_id` always comes from the authorised company context and cannot be overridden.

## Decision Receipt

Consequential or governance-relevant capability execution produces a structured `SpatialDecisionReceipt` containing:

- receipt ID
- trace/correlation/causation IDs
- tenant company ID
- capability ID
- risk result reference
- assurance result reference
- autonomy result reference
- evidence references
- command receipt reference where applicable
- outcome status
- reason codes
- structured rationale summary only
- timestamp

No unrestricted hidden chain-of-thought is stored.

## Signal Events

Maps emits canonical structured events for important geospatial conditions in addition to its existing Laravel domain events:

- `maps.route.failed`
- `maps.route.fallback_used`
- `maps.territory.conflict`
- `maps.service_area.excluded`
- `maps.geospatial.anomaly`
- `maps.capability.executed`
- `maps.capability.denied`

Events preserve trace/correlation/causation IDs and tenant company ID.

## Risk / Assurance / Autonomy

Read-only capabilities default to low or moderate risk, but their governance metadata remains explicit. Maps does not duplicate risk scoring, evidence assurance or autonomy calibration. When host engines are available, a governed executor asks those engines for decisions and references their receipts.

Maps-owned mutations such as territory changes remain permission-checked and must respect governance results for AI/system origin. Cross-extension authoritative mutations such as CRM assignment/promotion remain delegated through existing adapters/Command Bus boundaries rather than direct database mutation.

## Knowledge Authority

`job.travel_context` may request jurisdictional context from `SpatialKnowledgeGateway` using job coordinates and available locality/jurisdiction hints. Maps returns knowledge references only: guide/version/hash/section/jurisdiction/authority when supplied by Knowledge Authority. It does not embed regulatory rules.

## Titan Go / Offline

Each canonical capability declares one of:

- `ONLINE_EXECUTE`
- `OFFLINE_EXECUTE`
- `OFFLINE_PREPARE_ONLY`
- `OFFLINE_BLOCKED`

Pass 17 exposes an offline capability manifest for Titan Go. Offline fallbacks can use cached coordinates/territory evidence where explicitly allowed, but route/provider/network operations are prepare-only or blocked. Offline operation never increases autonomy.

## Compatibility

- Root `extension.json` remains `titan-extension-v1` for live Titan Extension Manager compatibility.
- Existing 31 capability IDs remain registered.
- The 8 canonical IDs are additive aliases/adapters.
- Existing routes, menus, migrations and UI remain intact.
- No destructive schema replacement.
- No direct AI write to CRM authoritative state.

## Verification

Tests must prove:

- all capability definitions contain the full governance metadata contract;
- the eight canonical capability IDs exist and map to real handlers;
- tenant company ID cannot be overridden by tool input;
- trace/correlation/causation IDs propagate into receipts/signals;
- read-only fallback governance does not claim unavailable Risk/Assurance/Autonomy results;
- AI-originated consequential mutation is denied when governance says no;
- offline policy never increases authority;
- Knowledge Authority absence returns explicit unavailable state rather than embedded guidance;
- legacy 31 capabilities remain present;
- installer/provider/menu/schema regressions remain green.
