<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Support\StrictBoolean;
use InvalidArgumentException;

final class NexusCompilation
{
    private function __construct(
        private readonly string $compilationUuid,
        private readonly ?string $parentCompilationUuid,
        private readonly BusinessProfile $businessProfile,
        private readonly TraceContext $traceContext,
        private readonly string $compilerVersion,
        private readonly CompilationStatus $status,
        private readonly ?CompiledTitanConfig $compiledConfiguration,
        private readonly ?ValidationResult $validationResult,
        private readonly ?ConfigurationDiff $configurationDiff,
        private readonly ?ProvisioningPlan $provisioningPlan,
        private readonly bool $dryRun,
        private readonly int $entityVersion = 0,
    ) {
        self::assertUuid($this->compilationUuid, 'compilation_uuid');
        if ($this->entityVersion < 0) { throw new InvalidArgumentException('entity_version cannot be negative.'); }

        if ($this->parentCompilationUuid !== null) {
            self::assertUuid($this->parentCompilationUuid, 'parent_compilation_uuid');
        }

        if ($this->businessProfile->tenantCompanyId() !== $this->traceContext->tenantCompanyId()) {
            throw new InvalidArgumentException('Business profile and trace context must belong to the same tenant.');
        }

        if ($this->compilerVersion === '' || strlen($this->compilerVersion) > 80) {
            throw new InvalidArgumentException('compiler_version must be between 1 and 80 characters.');
        }

        if ($this->configurationDiff !== null) {
            if ($this->compiledConfiguration === null) {
                throw new InvalidArgumentException('A configuration diff requires a compiled configuration.');
            }
            if (!hash_equals($this->compiledConfiguration->outputHash(), $this->configurationDiff->proposedOutputHash())) {
                throw new InvalidArgumentException('Configuration diff proposed hash must match the compiled configuration.');
            }
        }

        if ($this->provisioningPlan !== null) {
            if ($this->compiledConfiguration === null) {
                throw new InvalidArgumentException('A provisioning plan requires a compiled configuration.');
            }
            if ($this->provisioningPlan->tenantCompanyId() !== $this->businessProfile->tenantCompanyId()
                || strtolower($this->provisioningPlan->compilationUuid()) !== strtolower($this->compilationUuid)
                || !hash_equals($this->compiledConfiguration->outputHash(), $this->provisioningPlan->proposedOutputHash())) {
                throw new InvalidArgumentException('Provisioning plan must match the compilation tenant, UUID, and compiled output hash.');
            }
            $expectedDiffFingerprint = $this->configurationDiff?->fingerprint();
            if ($expectedDiffFingerprint !== $this->provisioningPlan->sourceDiffFingerprint()) {
                throw new InvalidArgumentException('Provisioning plan must reference the exact semantic diff attached to the compilation.');
            }
        }
    }

    public static function draft(
        BusinessProfile $businessProfile,
        TraceContext $traceContext,
        string $compilationUuid,
        string $compilerVersion,
        ?string $parentCompilationUuid = null,
        bool $dryRun = false,
    ): self {
        return new self(
            $compilationUuid,
            $parentCompilationUuid,
            $businessProfile,
            $traceContext,
            $compilerVersion,
            CompilationStatus::Draft,
            null,
            null,
            null,
            null,
            $dryRun,
            0,
        );
    }

    /** @param array<string, mixed> $data */
    public static function fromPersistence(array $data): self
    {
        $input = $data['input_snapshot'] ?? null;
        if (!is_array($input)) {
            throw new InvalidArgumentException('input_snapshot is required to restore a compilation.');
        }

        $compiledRaw = $data['compiled_configuration'] ?? null;
        $compiled = is_array($compiledRaw) ? CompiledTitanConfig::fromArray($compiledRaw) : null;

        $validationRaw = $data['validation_result'] ?? null;
        $validation = is_array($validationRaw) ? ValidationResult::fromArray($validationRaw) : null;

        $diffRaw = $data['diff_summary'] ?? null;
        $diff = is_array($diffRaw) ? ConfigurationDiff::fromArray($diffRaw) : null;

        $provisioningRaw = $data['provisioning_plan'] ?? null;
        $provisioning = is_array($provisioningRaw) ? ProvisioningPlan::fromArray($provisioningRaw) : null;

        $statusValue = $data['status'] ?? null;
        if (!is_string($statusValue) || CompilationStatus::tryFrom($statusValue) === null) {
            throw new InvalidArgumentException('Stored compilation status is invalid.');
        }

        $trace = TraceContext::fromArray([
            'tenant_company_id' => $data['tenant_company_id'] ?? null,
            'trace_id' => $data['trace_id'] ?? null,
            'correlation_id' => $data['correlation_id'] ?? null,
            'causation_id' => $data['causation_id'] ?? null,
        ]);

        $instance = new self(
            self::requiredString($data['compilation_uuid'] ?? null, 'compilation_uuid'),
            isset($data['parent_compilation_uuid']) && $data['parent_compilation_uuid'] !== '' ? (string) $data['parent_compilation_uuid'] : null,
            BusinessProfile::fromArray($input),
            $trace,
            self::requiredString($data['compiler_version'] ?? null, 'compiler_version'),
            CompilationStatus::from($statusValue),
            $compiled,
            $validation,
            $diff,
            $provisioning,
            StrictBoolean::parse($data['dry_run'] ?? false, 'dry_run'),
            self::nonNegativeInt($data['entity_version'] ?? 1, 'entity_version'),
        );

        if ($compiled !== null) {
            $instance->assertCompiledConfigurationMatches($compiled);
        }

        return $instance;
    }

    public function withCompiledConfiguration(CompiledTitanConfig $configuration): self
    {
        $this->assertCompiledConfigurationMatches($configuration);

        return new self(
            $this->compilationUuid,
            $this->parentCompilationUuid,
            $this->businessProfile,
            $this->traceContext,
            $this->compilerVersion,
            CompilationStatus::Compiled,
            $configuration,
            $this->validationResult,
            $this->configurationDiff,
            $this->provisioningPlan,
            $this->dryRun,
            $this->entityVersion,
        );
    }

    public function withValidationResult(ValidationResult $validationResult): self
    {
        return new self(
            $this->compilationUuid,
            $this->parentCompilationUuid,
            $this->businessProfile,
            $this->traceContext,
            $this->compilerVersion,
            $this->status,
            $this->compiledConfiguration,
            $validationResult,
            $this->configurationDiff,
            $this->provisioningPlan,
            $this->dryRun,
            $this->entityVersion,
        );
    }

    public function withConfigurationDiff(ConfigurationDiff $configurationDiff): self
    {
        if ($this->compiledConfiguration === null) {
            throw new InvalidArgumentException('A configuration diff can only be attached to a compiled configuration.');
        }
        if (!hash_equals($this->compiledConfiguration->outputHash(), $configurationDiff->proposedOutputHash())) {
            throw new InvalidArgumentException('Configuration diff proposed hash must match the compiled configuration.');
        }

        return new self(
            $this->compilationUuid,
            $this->parentCompilationUuid,
            $this->businessProfile,
            $this->traceContext,
            $this->compilerVersion,
            $this->status,
            $this->compiledConfiguration,
            $this->validationResult,
            $configurationDiff,
            $this->provisioningPlan,
            $this->dryRun,
            $this->entityVersion,
        );
    }

    public function withProvisioningPlan(ProvisioningPlan $provisioningPlan): self
    {
        if ($this->compiledConfiguration === null) {
            throw new InvalidArgumentException('A provisioning plan can only be attached to a compiled configuration.');
        }
        if ($provisioningPlan->tenantCompanyId() !== $this->businessProfile->tenantCompanyId()
            || strtolower($provisioningPlan->compilationUuid()) !== strtolower($this->compilationUuid)
            || !hash_equals($this->compiledConfiguration->outputHash(), $provisioningPlan->proposedOutputHash())) {
            throw new InvalidArgumentException('Provisioning plan must match this compilation.');
        }
        if ($provisioningPlan->sourceDiffFingerprint() !== $this->configurationDiff?->fingerprint()) {
            throw new InvalidArgumentException('Provisioning plan must reference the exact semantic diff attached to this compilation.');
        }

        return new self(
            $this->compilationUuid,
            $this->parentCompilationUuid,
            $this->businessProfile,
            $this->traceContext,
            $this->compilerVersion,
            $this->status,
            $this->compiledConfiguration,
            $this->validationResult,
            $this->configurationDiff,
            $provisioningPlan,
            $this->dryRun,
            $this->entityVersion,
        );
    }

    public function compilationUuid(): string
    {
        return $this->compilationUuid;
    }

    public function parentCompilationUuid(): ?string
    {
        return $this->parentCompilationUuid;
    }

    public function businessProfile(): BusinessProfile
    {
        return $this->businessProfile;
    }

    public function traceContext(): TraceContext
    {
        return $this->traceContext;
    }

    public function compilerVersion(): string
    {
        return $this->compilerVersion;
    }

    public function status(): CompilationStatus
    {
        return $this->status;
    }

    public function compiledConfiguration(): ?CompiledTitanConfig
    {
        return $this->compiledConfiguration;
    }

    public function validationResult(): ?ValidationResult
    {
        return $this->validationResult;
    }

    public function configurationDiff(): ?ConfigurationDiff
    {
        return $this->configurationDiff;
    }

    public function provisioningPlan(): ?ProvisioningPlan
    {
        return $this->provisioningPlan;
    }

    public function dryRun(): bool
    {
        return $this->dryRun;
    }

    public function entityVersion(): int
    {
        return $this->entityVersion;
    }

    public function withEntityVersion(int $entityVersion): self
    {
        if ($entityVersion < 0) { throw new InvalidArgumentException('entity_version cannot be negative.'); }
        return new self($this->compilationUuid,$this->parentCompilationUuid,$this->businessProfile,$this->traceContext,$this->compilerVersion,$this->status,$this->compiledConfiguration,$this->validationResult,$this->configurationDiff,$this->provisioningPlan,$this->dryRun,$entityVersion);
    }

    public function withFailedValidation(ValidationResult $validationResult): self
    {
        if (!$validationResult->hasErrors()) { throw new InvalidArgumentException('Failed validation state requires at least one error finding.'); }
        return new self($this->compilationUuid,$this->parentCompilationUuid,$this->businessProfile,$this->traceContext,$this->compilerVersion,CompilationStatus::Failed,$this->compiledConfiguration,$validationResult,$this->configurationDiff,$this->provisioningPlan,$this->dryRun,$this->entityVersion);
    }

    /** @return array<string, mixed> */
    public function toPersistenceArray(): array
    {
        $compiled = $this->compiledConfiguration;

        return [
            'tenant_company_id' => $this->traceContext->tenantCompanyId(),
            'entity_version' => $this->entityVersion,
            'compilation_uuid' => $this->compilationUuid,
            'parent_compilation_uuid' => $this->parentCompilationUuid,
            'trace_id' => $this->traceContext->traceId(),
            'correlation_id' => $this->traceContext->correlationId(),
            'causation_id' => $this->traceContext->causationId(),
            'type' => 'compilation',
            'status' => $this->status->value,
            'configuration_version' => $compiled?->configurationVersion(),
            'compiler_version' => $this->compilerVersion,
            'vertical_id' => $this->businessProfile->verticalId(),
            'vertical_version' => $this->businessProfile->verticalVersion(),
            'business_profile_version' => $this->businessProfile->profileVersion(),
            'knowledge_snapshot_version' => $compiled?->knowledgeSnapshotVersion(),
            'input_hash' => $this->businessProfile->fingerprint(),
            'output_hash' => $compiled?->outputHash(),
            'vertical_definition_hash' => $compiled?->sourceVerticalHash(),
            'dry_run' => $this->dryRun,
            'input_snapshot' => $this->businessProfile->toArray(),
            'compiled_configuration' => $compiled?->toArray(),
            'validation_result' => $this->validationResult?->toArray(),
            'provisioning_plan' => $this->provisioningPlan?->toArray(),
            'diff_summary' => $this->configurationDiff?->toArray(),
            'payload' => [
                'domain_version' => 4,
                'vertical_id' => $this->businessProfile->verticalId(),
                'vertical_version' => $this->businessProfile->verticalVersion(),
            ],
        ];
    }

    private function assertCompiledConfigurationMatches(CompiledTitanConfig $configuration): void
    {
        if ($configuration->tenantCompanyId() !== $this->businessProfile->tenantCompanyId()) {
            throw new InvalidArgumentException('Compiled configuration must belong to the compilation tenant.');
        }

        if ($configuration->verticalId() !== $this->businessProfile->verticalId()
            || $configuration->verticalVersion() !== $this->businessProfile->verticalVersion()) {
            throw new InvalidArgumentException('Compiled configuration vertical identity must match the business profile.');
        }

        if (!hash_equals($this->businessProfile->fingerprint(), $configuration->sourceProfileHash())) {
            throw new InvalidArgumentException('Compiled configuration must reference the exact business profile fingerprint.');
        }

        if ($configuration->compilerVersion() !== $this->compilerVersion) {
            throw new InvalidArgumentException('Compiled configuration compiler version must match the compilation.');
        }
    }

    private static function assertUuid(string $value, string $field): void
    {
        if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) !== 1) {
            throw new InvalidArgumentException("{$field} must be a valid RFC 4122/9562 UUID.");
        }
    }

    private static function nonNegativeInt(mixed $value, string $field): int
    {
        if (is_int($value)) { $resolved = $value; }
        elseif (is_string($value) && ctype_digit($value)) { $resolved = (int) $value; }
        else { throw new InvalidArgumentException("{$field} must be a non-negative integer."); }
        if ($resolved < 0) { throw new InvalidArgumentException("{$field} must be a non-negative integer."); }
        return $resolved;
    }

    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') {
            throw new InvalidArgumentException("{$field} is required.");
        }

        return trim($value);
    }
}
