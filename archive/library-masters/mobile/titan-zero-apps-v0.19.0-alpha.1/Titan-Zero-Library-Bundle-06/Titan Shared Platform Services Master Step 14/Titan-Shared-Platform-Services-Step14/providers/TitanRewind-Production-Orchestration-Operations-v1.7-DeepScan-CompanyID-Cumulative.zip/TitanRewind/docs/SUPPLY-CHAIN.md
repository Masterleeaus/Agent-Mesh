# Titan Rewind Supply Chain

The release includes an SPDX 2.3 SBOM, deterministic internal file-integrity inventory, build provenance, a 3072-bit RSA release public key and its SHA-256 DER fingerprint. The final ZIP is hashed with SHA-256 and its digest is signed with RSA-SHA256 outside the archive; the private release key is never packaged.

Release verification checks JSON/PHP syntax, internal imports, routes, Blueprint package safety, Blueprint architecture warnings, the full Rewind test suite, internal file hashes, archive traversal/symlink safety and the external package signature. The build environment contains no Composer vendor tree for the complete MagicAI host, so host Larastan/dependency resolution is a deployment certification gate rather than a fabricated package result.
