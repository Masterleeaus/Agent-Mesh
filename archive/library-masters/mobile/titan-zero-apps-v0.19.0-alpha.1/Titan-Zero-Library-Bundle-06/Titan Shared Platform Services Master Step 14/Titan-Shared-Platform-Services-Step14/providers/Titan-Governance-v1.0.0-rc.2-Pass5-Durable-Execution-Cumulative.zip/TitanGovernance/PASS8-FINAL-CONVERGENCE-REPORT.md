# Titan Governance v1.0.0-rc.1 — Pass 8 Final Convergence & Release Hardening

## Triggering live failure repaired
Installer 1.7.6 rejected Pass 7 at validation with `extension.json is missing a valid 'name' value.` The Pass 7 root manifest carried Titan installer metadata but omitted MagicAI legacy host fields. Pass 8 permanently restores `name`, `type=extension`, `description` and string `support_telegram` while retaining Titan schema/slug/folder/provider/dependency/lifecycle/integrity metadata.

The failed Pass 7 attempt reported an empty rollback and stopped at validation; no Governance migration or deployment action was reported by that attempt.

## Final-pass scope
- No new migration and no new business mutation behavior.
- Dual Installer 1.7.6 / Titan manifest preflight.
- Fresh-install, existing-install-upgrade and provider-boot static preflights.
- Exact-host certification hook that leaves untested live stages `NOT_RUN`.
- Route, menu, permission, capability, dependency, migration and performance-bound inventories.
- End-to-end causal/receipt/evidence consistency regression.
- Operator runbook and exact-host checklist.
- Full cumulative regression, Blueprint v4.2.2 architecture/MySQL/package gates and fresh-ZIP verification.

## Architectural conclusion
Governance remains the human control plane. Titan Autonomy is the authority owner, Titan Command Bus is the mutation boundary, peer engines retain their canonical state, and Workforce hierarchy/maturity cannot mint authority.
## Post-Pass-8 live installer remediations

- **H1 dependency compatibility:** Installer 1.7.6 reached dependency resolution and showed Signal/Command Bus were not registered on-host. They remain runtime-required/fail-closed but no longer block installation.
- **H2 MySQL migration restartability:** Installer 1.7.6 then validated, deployed and loaded the provider, but migration 000004 failed on a 65-character implicit MySQL index name. H2 replaces all 000004 implicit indexes with guarded, explicitly named short indexes and makes rollback/retry partial-state safe.
- The first three migration files remain unchanged. Migration 000004 is the only historical migration remediated because it did not complete/record successfully in the triggering run.

