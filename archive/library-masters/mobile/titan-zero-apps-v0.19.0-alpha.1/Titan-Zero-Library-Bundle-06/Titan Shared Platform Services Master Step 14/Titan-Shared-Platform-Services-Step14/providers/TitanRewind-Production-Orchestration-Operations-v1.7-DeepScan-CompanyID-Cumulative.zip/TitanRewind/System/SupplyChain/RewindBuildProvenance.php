<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\SupplyChain;
final class RewindBuildProvenance
{
    public function build(string $version,string $artifactSha256,array $inputs,array $verification): array
    {
        ksort($inputs);ksort($verification);
        return [
            'schema'=>'titan-build-provenance-v1','extension'=>'titan-rewind','version'=>$version,
            'artifact_sha256'=>$this->sha($artifactSha256),'inputs'=>$inputs,'verification'=>$verification,
            'generated_at'=>(new \DateTimeImmutable('now',new \DateTimeZone('UTC')))->format(DATE_ATOM),
        ];
    }
    private function sha(string $v):string{if(!preg_match('/^[a-f0-9]{64}$/i',$v))throw new \InvalidArgumentException('artifact sha256 required');return strtolower($v);}
}
