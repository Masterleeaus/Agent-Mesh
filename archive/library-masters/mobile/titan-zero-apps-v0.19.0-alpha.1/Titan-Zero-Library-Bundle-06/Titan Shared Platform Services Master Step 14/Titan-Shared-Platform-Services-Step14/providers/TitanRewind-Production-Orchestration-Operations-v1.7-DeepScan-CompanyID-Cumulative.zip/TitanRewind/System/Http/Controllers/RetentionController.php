<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Http\Controllers;
use App\Extensions\TitanRewind\System\Services\RewindRetentionService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
final class RetentionController
{
 public function run(Request $request,RewindRetentionService $retention): RedirectResponse
 {
  $tenant=(int)$request->input('tenant_company_id',0);$class=strtolower(trim((string)$request->input('retention_class','')));abort_if($tenant<1,422,'tenant_company_id is required.');abort_unless(in_array($class,['ephemeral','operational','forensic','evidence'],true),422,'Unsupported retention class.');$actor=$request->user()?->getAuthIdentifier();$retention->run($tenant,$class,is_numeric($actor)?(int)$actor:null,(int)config('titan-rewind.retention.batch_size',250));return back()->with('status','Titan Rewind retention batch completed or checkpointed.');
 }
}
