<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Models\CannedResponse;
use App\Extensions\TitanConnect\System\Services\MessagingAuditService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

final class CannedResponseController extends Controller
{
    public function __construct(private readonly CompanyContext $context, private readonly MessagingAuditService $audit) {}

    public function index(Request $request): JsonResponse
    {
        $companyId = $this->context->companyId($request); $actorId = $this->context->actorId($request); $search = trim((string) $request->query('search', ''));
        $query = CannedResponse::query()->forCompany($companyId)->where(fn ($q) => $q->where('owner_user_id', $actorId)->orWhere('is_company_shared', true));
        if ($search !== '') $query->where(fn ($q) => $q->where('title','like','%'.$search.'%')->orWhere('content','like','%'.$search.'%'));
        return response()->json(['data' => $query->latest('updated_at')->limit(5000)->get()]);
    }

    public function store(Request $request): JsonResponse
    {
        $companyId = $this->context->companyId($request); $actorId = $this->context->actorId($request);
        $data = $request->validate(['title' => ['required','string','max:191'], 'content' => ['required','string','max:20000'], 'shortcut' => ['nullable','string','max:64'], 'is_company_shared' => ['sometimes','boolean']]);
        $item = CannedResponse::query()->create(['uuid' => (string) Str::uuid(), 'company_id' => $companyId, 'owner_user_id' => $actorId] + $data);
        $this->audit->record($companyId, $actorId, 'canned-response.created', 'canned-response', $item->uuid);
        return response()->json($item, 201);
    }

    public function update(Request $request, CannedResponse $responseItem): JsonResponse
    {
        $companyId = $this->context->companyId($request); $actorId = $this->context->actorId($request);
        abort_unless((int) $responseItem->company_id === $companyId && (int) $responseItem->owner_user_id === $actorId, 403);
        $data = $request->validate(['title' => ['sometimes','string','max:191'], 'content' => ['sometimes','string','max:20000'], 'shortcut' => ['sometimes','nullable','string','max:64'], 'is_company_shared' => ['sometimes','boolean']]);
        $responseItem->fill($data)->save();
        $this->audit->record($companyId, $actorId, 'canned-response.updated', 'canned-response', $responseItem->uuid);
        return response()->json($responseItem->fresh());
    }

    public function destroy(Request $request, CannedResponse $responseItem): JsonResponse
    {
        $companyId = $this->context->companyId($request); $actorId = $this->context->actorId($request);
        abort_unless((int) $responseItem->company_id === $companyId && (int) $responseItem->owner_user_id === $actorId, 403);
        $uuid = $responseItem->uuid; $responseItem->delete(); $this->audit->record($companyId, $actorId, 'canned-response.deleted', 'canned-response', $uuid);
        return response()->json(['status' => 'deleted']);
    }
}
