<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use App\Extensions\Crm\System\Contracts\PipelineRepositoryContract;
use App\Extensions\Crm\System\Contracts\SalesDocumentRepositoryContract;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Validation\ValidationException;

final class CrmViewDataService
{
    public function __construct(
        private ConnectionInterface $db,
        private CrmDashboardService $dashboard,
        private CrmTimelineService $timeline,
        private CrmForecastService $forecast,
        private PipelineRepositoryContract $pipelines,
        private SalesDocumentRepositoryContract $sales,
    ) {}

    public function overview(int $userId): array
    {
        $deals = $this->db->table(config('crm.tables.deals'))
            ->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at')
            ->orderByDesc('updated_at')->limit(8)->get()->map(fn ($r) => (array) $r)->all();
        $leads = $this->db->table(config('crm.tables.leads'))
            ->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at')
            ->whereNotIn('status', ['converted', 'lost'])
            ->orderByRaw('CASE WHEN follow_up_at IS NULL THEN 1 ELSE 0 END')->orderBy('follow_up_at')
            ->limit(8)->get()->map(fn ($r) => (array) $r)->all();
        $activities = $this->db->table(config('crm.tables.activities'))
            ->where('company_id', CrmCompanyScope::companyId($userId))
            ->orderByDesc('occurred_at')->limit(10)->get()->map(fn ($r) => (array) $r)->all();
        return [
            'summary' => $this->dashboard->summary($userId),
            'forecast' => $this->forecast->summarize($userId),
            'recentDeals' => $deals,
            'followUpLeads' => $leads,
            'recentActivities' => $activities,
            'pipelines' => $this->pipelines->list($userId),
        ];
    }

    public function companies(int $userId, ?string $q = null): array
    {
        $query = $this->db->table(config('crm.tables.companies'))->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at');
        if ($q !== null && trim($q) !== '') {
            $term = '%' . trim($q) . '%';
            $query->where(fn ($x) => $x->where('name', 'like', $term)->orWhere('email', 'like', $term)->orWhere('phone', 'like', $term));
        }
        return $query->orderBy('name')->limit(250)->get()->map(fn ($r) => (array) $r)->all();
    }

    public function company(int $userId, string $publicId): array
    {
        $company = $this->owned(config('crm.tables.companies'), $userId, $publicId, 'Company');
        $companyId = (int) $company['id'];
        $limit=max(25,min(500,(int)config('crm.performance.detail_collection_limit',250)));$tenant=CrmCompanyScope::companyId($userId);
        $contacts=$this->bounded($this->db->table(config('crm.tables.contacts'))->where('company_id',$tenant)->where('customer_company_id',$companyId)->whereNull('deleted_at')->orderByDesc('is_primary')->orderBy('first_name'),$limit);
        $deals=$this->bounded($this->db->table(config('crm.tables.deals'))->where('company_id',$tenant)->where('customer_company_id',$companyId)->whereNull('deleted_at')->orderByDesc('updated_at'),$limit);
        $projects=$this->bounded($this->db->table('crm_projects')->where('company_id',$tenant)->where('company_public_id',$publicId)->whereNull('deleted_at')->orderByDesc('updated_at'),$limit);
        return ['company'=>$company,'contacts'=>$contacts['records'],'deals'=>$deals['records'],'projects'=>$projects['records'],'timeline'=>$this->timeline->forSubject($userId,'company',$publicId,100),'collection_limits'=>['limit'=>$limit,'contacts_truncated'=>$contacts['truncated'],'deals_truncated'=>$deals['truncated'],'projects_truncated'=>$projects['truncated']]];
    }

    public function contacts(int $userId, ?string $q = null): array
    {
        $query = $this->db->table(config('crm.tables.contacts') . ' as c')
            ->leftJoin(config('crm.tables.companies') . ' as co', 'co.id', '=', 'c.customer_company_id')
            ->where('c.company_id', CrmCompanyScope::companyId($userId))->whereNull('c.deleted_at')
            ->select('c.*', 'co.name as company_name', 'co.public_id as company_public_id');
        if ($q !== null && trim($q) !== '') {
            $term = '%' . trim($q) . '%';
            $query->where(fn ($x) => $x->where('c.first_name', 'like', $term)->orWhere('c.last_name', 'like', $term)->orWhere('c.email', 'like', $term)->orWhere('c.phone', 'like', $term));
        }
        return $query->orderBy('c.first_name')->limit(250)->get()->map(fn ($r) => (array) $r)->all();
    }

    public function contact(int $userId, string $publicId): array
    {
        $contact = $this->owned(config('crm.tables.contacts'), $userId, $publicId, 'Contact');
        $company = null;
        if ($contact['customer_company_id'] ?? null) {
            $row = $this->db->table(config('crm.tables.companies'))->where('company_id', CrmCompanyScope::companyId($userId))->where('id', $contact['customer_company_id'])->whereNull('deleted_at')->first();
            $company = $row ? (array) $row : null;
        }
        return [
            'contact' => $contact,
            'company' => $company,
            'timeline' => $this->timeline->forSubject($userId, 'contact', $publicId, 100),
        ];
    }

    public function pipeline(int $userId, string $publicId): array
    {
        return $this->pipelines->board($userId, $publicId);
    }

    public function deal(int $userId, string $publicId): array
    {
        $deal = $this->owned(config('crm.tables.deals'), $userId, $publicId, 'Deal');
        $company = null;
        $contact = null;
        $pipeline = null;
        $stage = null;
        if ($deal['customer_company_id'] ?? null) {
            $r = $this->db->table(config('crm.tables.companies'))->where('company_id', CrmCompanyScope::companyId($userId))->where('id', $deal['customer_company_id'])->whereNull('deleted_at')->first();
            $company = $r ? (array) $r : null;
        }
        if ($deal['contact_id'] ?? null) {
            $r = $this->db->table(config('crm.tables.contacts'))->where('company_id', CrmCompanyScope::companyId($userId))->where('id', $deal['contact_id'])->whereNull('deleted_at')->first();
            $contact = $r ? (array) $r : null;
        }
        if ($deal['pipeline_id'] ?? null) {
            $r = $this->db->table(config('crm.tables.pipelines'))->where('company_id', CrmCompanyScope::companyId($userId))->where('id', $deal['pipeline_id'])->whereNull('deleted_at')->first();
            $pipeline = $r ? (array) $r : null;
        }
        if ($deal['stage_id'] ?? null) {
            $r = $this->db->table(config('crm.tables.stages'))->where('id', $deal['stage_id'])->whereNull('deleted_at')->first();
            $stage = $r ? (array) $r : null;
        }
        return ['deal' => $deal, 'company' => $company, 'contact' => $contact, 'pipeline' => $pipeline, 'stage' => $stage, 'timeline' => $this->timeline->forSubject($userId, 'deal', $publicId, 100)];
    }

    public function reports(int $userId): array
    {
        $summary = $this->dashboard->summary($userId);
        $forecast = $this->forecast->summarize($userId);
        $pipelines = [];
        foreach ($this->pipelines->list($userId) as $pipeline) {
            $board = $this->pipelines->board($userId, (string) $pipeline['public_id']);
            $pipelines[] = [
                'pipeline' => $pipeline,
                'deal_count' => array_sum(array_map(fn ($s) => (int) ($s['deal_count'] ?? 0), $board['stages'] ?? [])),
                'value_minor' => array_sum(array_map(fn ($s) => (int) ($s['total_value_minor'] ?? 0), $board['stages'] ?? [])),
            ];
        }
        return compact('summary', 'forecast', 'pipelines');
    }

    public function salesList(int $userId, string $type): array
    {
        return $this->sales->search($userId, $type, ['limit' => 250]);
    }

    public function salesDocument(int $userId, string $type, string $publicId): array
    {
        $table = $this->salesTable($type);
        $doc = $this->owned($table, $userId, $publicId, ucfirst(rtrim($type, 's')));
        $tenant=CrmCompanyScope::companyId($userId);
        $lines=$this->db->table('crm_sales_document_lines')->where('company_id',$tenant)->where('document_type',$type)->where('document_public_id',$publicId)->orderBy('sequence')->get()->map(fn($r)=>(array)$r)->all();
        $settlements=$type==='invoices'&&$this->db->getSchemaBuilder()->hasTable('crm_invoice_settlement_references')?$this->db->table('crm_invoice_settlement_references')->where('company_id',$tenant)->where('invoice_public_id',$publicId)->orderByDesc('id')->get()->map(fn($r)=>(array)$r)->all():[];
        $creditNotes=$type==='invoices'&&$this->db->getSchemaBuilder()->hasTable('crm_credit_notes')?$this->db->table('crm_credit_notes')->where('company_id',$tenant)->where('invoice_public_id',$publicId)->whereNull('deleted_at')->orderByDesc('id')->get()->map(fn($r)=>(array)$r)->all():[];
        return ['document'=>$doc,'lines'=>$lines,'settlements'=>$settlements,'creditNotes'=>$creditNotes];
    }


    /** @return array{records:list<array<string,mixed>>,truncated:bool} */
    private function bounded($query,int $limit): array
    {
        $rows=$query->limit($limit+1)->get()->map(fn($r)=>(array)$r)->all();$truncated=count($rows)>$limit;if($truncated)$rows=array_slice($rows,0,$limit);return ['records'=>$rows,'truncated'=>$truncated];
    }

    private function owned(string $table, int $userId, string $publicId, string $label): array
    {
        $row = $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id', $publicId)->whereNull('deleted_at')->first();
        if (! $row) {
            throw ValidationException::withMessages(['record' => ["{$label} not found."]]);
        }
        return (array) $row;
    }

    private function salesTable(string $type): string
    {
        if (! in_array($type, ['proposals', 'estimates', 'invoices'], true)) {
            throw ValidationException::withMessages(['type' => ['Unsupported sales document type.']]);
        }
        return 'crm_' . $type;
    }
}
