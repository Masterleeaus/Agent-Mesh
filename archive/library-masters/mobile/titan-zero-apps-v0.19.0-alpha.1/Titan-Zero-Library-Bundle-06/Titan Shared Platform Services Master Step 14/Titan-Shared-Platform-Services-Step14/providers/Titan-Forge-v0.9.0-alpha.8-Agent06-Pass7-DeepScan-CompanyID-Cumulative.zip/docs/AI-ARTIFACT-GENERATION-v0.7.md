# Titan Forge Sandboxed AI Artifact Generation — v0.7

Pass 17 adds Forge's governed consumer boundary for AI-generated artifact proposals. The boundary is implemented and testable, but live AI artifact generation remains unavailable against the currently verified Titan AI Core v0.3.0 because AI Core does not yet publish an artifact-generation/model-routing contract.

## Rules

- no OpenAI, Anthropic, Gemini or other provider SDK/HTTP calls from Forge;
- proposals must arrive through `ForgeAiArtifactGatewayContract`;
- all generated files are written through `SandboxWorkspace` only;
- traversal, absolute paths, backslashes, symlinks, case collisions, file-count and size limits remain enforced;
- generated output always has `deployment_authority: none`;
- validation and release governance are unchanged after generation.

## Required provenance

Every usable AI artifact proposal requires:

- source and source plan ID;
- model provider identifier;
- model identifier;
- model route, currently required to be `titan-ai-core`;
- prompt SHA-256;
- input SHA-256;
- output SHA-256;
- template version;
- optional bounded decision summary.

The generated `generation_manifest.json` also binds the BuildSpec fingerprint, BuildPlan fingerprint, tenant and full causal context to the artifact set.

`GenerationManifestValidator` rejects AI-assisted manifests with incomplete planner/model/hash provenance or hidden-reasoning-shaped fields.

## Current activation state

`UnavailableAiArtifactGateway` is the production binding until Titan AI Core publishes a governed artifact-generation contract. Forge exposes the sandboxed generation boundary but reports `ai_artifact_gateway_available=false` and returns `generation_blocked` instead of calling providers directly.
