# Titan AI Runtime 1.5.3

Titan AI Runtime is the shared, headless AI orchestration and provider kernel for Titan Zero. Version 1.5 converges AIChatPro and AI Agent onto one Titan-owned MagicAI provider gateway while retaining their product-specific UI, persistence and workflow engines.

## Authority boundaries

- **TitanAI** owns orchestration, intent routing, source policy, trusted-tool authorization, provider/model execution, streaming events, governance and WorkCore execution policy.
- **AIChatPro** owns the authenticated staff workspace, chat history, connectors and image-product UX.
- **AI Agent** owns workflows, schedules, triggers, channels, workflow state and Copilot presentation.
- **Chatbot** remains the customer-facing conversation/RAG product and can register through the same source contracts.
- **WorkCore** remains authoritative for operational business records.

`company_id` is the canonical security boundary. `user_id` is principal/actor attribution and never substitutes for company ownership.

## Provider convergence

The default runtime provider is `magicai-host`. TitanAI resolves MagicAI host models and engines, verifies the principal belongs to the requested company, performs a host credit preflight, executes the provider request, and records/decrements usage through the host Entity credit infrastructure.

Supported shared host engine paths in this build include OpenAI, Anthropic, Gemini, DeepSeek and xAI. OpenAI uses token-level streaming. Other host engines currently return the same canonical Titan stream events after host completion; this release does not claim token-level streaming for those engines.

Custom server-controlled OpenAI-compatible provider profiles remain available as an explicit alternate gateway. Request payloads cannot supply endpoints, API keys, assistant deployments or tool schemas.

See:

- [Provider gateway](PROVIDER-GATEWAY.md)
- [AI surfaces integration](AI-SURFACES-INTEGRATION.md)
- [Architecture](ARCHITECTURE.md)
- [Company boundary](COMPANY-BOUNDARY.md)
- [Host integration](INTEGRATION.md)
- [Security](SECURITY.md)
- [Configuration](CONFIGURATION.md)
- [Operations](OPERATIONS.md)
- [Lifecycle](LIFECYCLE.md)
- [Release verification](RELEASE-VERIFICATION.md)
