<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Health;

use App\Extensions\TitanGovernance\System\Contracts\ExtensionHealth;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceCommandGatewayContract;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class TitanGovernanceHealthCheck implements ExtensionHealth
{
    public function __construct(private readonly GovernanceCommandGatewayContract $commandGateway) {}

    public function snapshot(): array
    {
        if (!config('titan-governance.enabled', true)) {
            return ['status' => 'DISABLED', 'checks' => ['extension' => 'DISABLED'], 'observed_at' => now()->toIso8601String()];
        }

        $checks = ['extension' => 'HEALTHY'];
        try { $checks['database'] = Schema::hasTable('titan_governance_views') ? 'HEALTHY' : 'UNAVAILABLE'; }
        catch (Throwable) { $checks['database'] = 'UNAVAILABLE'; }

        foreach (['titan-signal', 'titan-command-bus', 'titan-autonomy'] as $dependency) {
            $checks[$dependency] = $this->registered($dependency) ? 'HEALTHY' : 'DEGRADED';
        }
        try {
            $gatewayHealth=$this->commandGateway->health();
            $gatewayStatus=strtoupper(trim((string)($gatewayHealth['status']??'UNAVAILABLE')));
            $checks['governance-command-gateway']=in_array($gatewayStatus,['HEALTHY','READY'],true)?'HEALTHY':'DEGRADED';
        } catch (Throwable) {
            $checks['governance-command-gateway']='DEGRADED';
        }
        $status = in_array('UNAVAILABLE', $checks, true) ? 'UNAVAILABLE' : (in_array('DEGRADED', $checks, true) ? 'DEGRADED' : 'HEALTHY');
        return ['status' => $status, 'checks' => $checks, 'observed_at' => now()->toIso8601String()];
    }

    private function registered(string $key): bool
    {
        foreach (['App\\Helpers\\MarketplaceHelper', 'App\\Domains\\Marketplace\\Support\\MarketplaceHelper'] as $class) {
            if (class_exists($class) && method_exists($class, 'isRegistered')) {
                try { return (bool) $class::isRegistered($key); } catch (Throwable) { return false; }
            }
        }
        // Dependency registration cannot be proven on this host; fail visibly but non-fatally.
        return false;
    }
}
