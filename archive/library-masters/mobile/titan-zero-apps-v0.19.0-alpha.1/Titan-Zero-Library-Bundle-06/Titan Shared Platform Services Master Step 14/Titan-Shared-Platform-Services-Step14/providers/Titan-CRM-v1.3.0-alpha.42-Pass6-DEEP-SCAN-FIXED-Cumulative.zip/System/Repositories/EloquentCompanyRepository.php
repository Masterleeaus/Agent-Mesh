<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Repositories;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Contracts\CompanyRepositoryContract;
use App\Extensions\Crm\System\Services\{CrmDuplicateDetector,CrmIdentityAuthorityService,CrmDuplicateReviewService};
use App\Extensions\Crm\System\Support\CrmNormalizer;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

final class EloquentCompanyRepository implements CompanyRepositoryContract
{
    public function __construct(private ConnectionInterface $db, private CrmDuplicateDetector $duplicates, private CrmIdentityAuthorityService $identity, private CrmDuplicateReviewService $reviews) {}
    public function search(int $userId,array $filters=[]): array
    {
        $q=$this->db->table(config('crm.tables.companies'))->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at');
        if(($filters['q']??null)!==null){$term='%'.trim((string)$filters['q']).'%';$q->where(fn($x)=>$x->where('name','like',$term)->orWhere('email','like',$term)->orWhere('phone','like',$term));}
        return $q->orderBy('name')->limit(min((int)($filters['limit']??100),250))->get()->map(fn($r)=>(array)$r)->all();
    }
    public function create(int $userId,array $data): array
    {
        $email=CrmNormalizer::email($data['email']??null);$phone=CrmNormalizer::phone($data['phone']??null);$candidates=$this->duplicates->companyCandidates($userId,$email,$phone);$publicId=(string)Str::ulid();$root=(string)Str::ulid();
        $id=$this->db->table(config('crm.tables.companies'))->insertGetId(['public_id'=>$publicId,'customer_unification_id'=>$root,'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'name'=>(string)$data['name'],'legal_name'=>$data['legal_name']??null,'website'=>$data['website']??null,'email'=>$email,'normalized_email'=>$email,'phone'=>$phone,'normalized_phone'=>$phone,'address'=>$data['address']??null,'notes'=>$data['notes']??null,'status'=>$data['status']??'active','owner_user_id'=>$data['owner_user_id']??$userId,'meta'=>json_encode(['duplicate_candidates'=>$candidates]),'created_at'=>now(),'updated_at'=>now()]);
        $this->identity->syncSubjectIdentities($userId,'company',$publicId,$root,$email,$phone);foreach($candidates as $candidate)if(isset($candidate['public_id']))$this->reviews->queueForPair($userId,'company',$publicId,'company',(string)$candidate['public_id']);
        return (array)$this->db->table(config('crm.tables.companies'))->where('id',$id)->first();
    }

    public function update(int $userId, string $publicId, array $data): array
    {
        $table = config('crm.tables.companies');
        $current = $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id', $publicId)->whereNull('deleted_at')->first();
        if (! $current) abort(404, 'CRM company not found.');
        $email = CrmNormalizer::email($data['email'] ?? $current->email);
        $phone = CrmNormalizer::phone($data['phone'] ?? $current->phone);
        $payload = [
            'name' => (string) ($data['name'] ?? $current->name),
            'legal_name' => $data['legal_name'] ?? $current->legal_name,
            'website' => $data['website'] ?? $current->website,
            'email' => $email, 'normalized_email' => $email,
            'phone' => $phone, 'normalized_phone' => $phone,
            'address' => $data['address'] ?? $current->address,
            'notes' => $data['notes'] ?? $current->notes,
            'status' => $data['status'] ?? $current->status,
            'owner_user_id' => $data['owner_user_id'] ?? $current->owner_user_id,
            'updated_at' => now(),
        ];
        $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id', $publicId)->update($payload);
        $root=$this->identity->ensureRootForCompany($userId,$publicId);$this->identity->syncSubjectIdentities($userId,'company',$publicId,$root,$email,$phone);foreach($this->duplicates->companyCandidates($userId,$email,$phone) as $candidate)if(isset($candidate['public_id'])&&(string)$candidate['public_id']!==$publicId)$this->reviews->queueForPair($userId,'company',$publicId,'company',(string)$candidate['public_id']);
        return (array) $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id', $publicId)->first();
    }
}
