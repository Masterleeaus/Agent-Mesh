<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface AutonomyQueryContract
{
    public function capabilityStates(int $tenantCompanyId): array;
    public function capabilityState(int $tenantCompanyId, string $capability, string $workflowKey): ?array;
    public function learningEvents(int $tenantCompanyId, ?string $capability = null, ?string $workflowKey = null, int $limit = 1000): array;
    public function learningPreferences(int $tenantCompanyId, ?int $userId = null): array;
    public function learningSettings(int $tenantCompanyId): array;
    public function tenantPolicy(int $tenantCompanyId): ?array;
    public function platformPolicy(): ?array;
    public function handshakes(int $tenantCompanyId, ?string $capability = null, ?string $workflowKey = null, int $limit = 100): array;
    public function regressions(int $tenantCompanyId, ?string $capability = null, ?string $workflowKey = null, int $limit = 100): array;
}
