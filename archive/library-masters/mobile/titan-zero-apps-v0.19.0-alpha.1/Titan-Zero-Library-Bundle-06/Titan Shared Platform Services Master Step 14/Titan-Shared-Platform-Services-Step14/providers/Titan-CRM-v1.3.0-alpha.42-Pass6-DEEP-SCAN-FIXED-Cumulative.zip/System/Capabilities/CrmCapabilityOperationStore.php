<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Capabilities;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Governance\CrmCommandContract;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

/** Server-side idempotency and authoritative command-receipt store for governed CRM writes. */
final class CrmCapabilityOperationStore
{
    public function __construct(private readonly ConnectionInterface $db, private readonly CrmCompanyScope $scope) {}

    /** @return array{state:string,result?:array<string,mixed>} */
    public function reserve(string $capability,string $key,array $request): array
    {
        if($key==='') throw new InvalidArgumentException('CRM write idempotency key is required.');
        $ctx=$this->scope->current();
        $fingerprint=$this->fingerprint($request);
        $row=[
            'public_id'=>(string)Str::ulid(),'company_id'=>$ctx->companyId,
            'actor_user_id'=>$ctx->actorUserId,'actor_type'=>$ctx->actorType,'capability'=>$capability,
            'idempotency_key'=>$key,'resource_type'=>null,'resource_id'=>null,'source_surface'=>$ctx->sourceSurface,
            'status'=>'processing','request_fingerprint'=>json_encode(['sha256'=>$fingerprint]),'result'=>null,
            'correlation_id'=>$ctx->correlationId,'completed_at'=>null,'created_at'=>now(),'updated_at'=>now(),
        ];
        $this->putIfColumn($row,'trace_id',$ctx->traceId!==''?$ctx->traceId:$ctx->correlationId);
        $this->putIfColumn($row,'causation_id',$ctx->causationId);
        $this->putIfColumn($row,'command_id',$request['_context']['command_id']??$request['command_id']??null);
        $this->putIfColumn($row,'command_contract_version',(int)($request['_context']['command_contract_version']??CrmCommandContract::VERSION));
        $this->putIfColumn($row,'expected_entity_version',$request['expected_entity_version']??$request['expected_version']??$request['_context']['expected_entity_version']??$request['_context']['expected_version']??null);
        $this->putIfColumn($row,'request_envelope',json_encode($this->requestEnvelope($capability,$key,$request),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));

        $inserted=$this->db->table('crm_capability_operations')->insertOrIgnore($row);
        if($inserted===1)return ['state'=>'reserved'];

        $existing=$this->row($capability,$key);
        if(!$existing)return ['state'=>'processing'];
        $stored=$this->decode($existing->request_fingerprint??null)['sha256']??null;
        if(!is_string($stored)||!hash_equals($stored,$fingerprint)){
            throw new InvalidArgumentException('Idempotency key was already used with a different CRM capability payload.');
        }
        if(in_array((string)$existing->status,['completed','rejected'],true)){
            $this->recordReplay((int)$existing->id);
            return ['state'=>'completed','result'=>$this->decode($existing->result??null)];
        }
        return ['state'=>'processing'];
    }

    public function replay(string $capability,string $key): ?array
    {
        if($key==='')return null;
        $row=$this->row($capability,$key);
        if(!$row||!in_array((string)$row->status,['completed','rejected'],true))return null;
        $this->recordReplay((int)$row->id);
        return ['duplicate'=>true,'status'=>(string)$row->status,'result'=>$this->decode($row->result??null)];
    }

    /** @param array<string,mixed> $receipt */
    public function completed(string $capability,string $key,array $result,?string $resourceType=null,?string $resourceId=null,array $receipt=[]): void
    {
        if($key==='')return;
        $ctx=$this->scope->current();
        $stored=['result'=>$result,'receipt'=>$receipt,'rewind_reference'=>$receipt['rewind_reference']??null];
        $update=[
            'actor_user_id'=>$ctx->actorUserId,'actor_type'=>$ctx->actorType,'resource_type'=>$resourceType,'resource_id'=>$resourceId,
            'source_surface'=>$ctx->sourceSurface,'status'=>'completed','result'=>json_encode($stored,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),
            'correlation_id'=>$ctx->correlationId,'completed_at'=>now(),'updated_at'=>now(),
        ];
        $this->putIfColumn($update,'command_id',$receipt['command_id']??null);
        $this->putIfColumn($update,'receipt_id',$receipt['receipt_id']??null);
        $this->putIfColumn($update,'trace_id',$receipt['trace_id']??($ctx->traceId!==''?$ctx->traceId:$ctx->correlationId));
        $this->putIfColumn($update,'causation_id',$receipt['causation_id']??$ctx->causationId);
        $this->putIfColumn($update,'before_state_hash',$receipt['before_state_hash']??null);
        $this->putIfColumn($update,'after_state_hash',$receipt['after_state_hash']??null);
        $this->putIfColumn($update,'entity_version_before',$receipt['entity_version_before']??null);
        $this->putIfColumn($update,'entity_version_after',$receipt['entity_version_after']??null);
        $this->putIfColumn($update,'rewind_reference',isset($receipt['rewind_reference'])?json_encode($receipt['rewind_reference'],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR):null);
        $this->putIfColumn($update,'command_duration_ms',$receipt['command_duration_ms']??null);
        $this->putIfColumn($update,'affected_count',$receipt['affected_count']??null);
        $this->putIfColumn($update,'receipt_integrity_hash',$receipt['receipt_integrity_hash']??null);
        $this->putIfColumn($update,'remediation_suggestion',$receipt['remediation_suggestion']??null);
        $this->putIfColumn($update,'command_contract_version',$receipt['command_contract_version']??CrmCommandContract::VERSION);
        $this->putIfColumn($update,'expected_entity_version',$receipt['expected_entity_version']??null);
        $this->putIfColumn($update,'affected_resources',$this->json($receipt['affected_resources']??[]));
        $this->putIfColumn($update,'invariant_results',$this->json($receipt['invariant_results']??[]));
        $this->putIfColumn($update,'external_effect_references',$this->json($receipt['external_effect_references']??[]));
        $this->putIfColumn($update,'compensation_state',$receipt['compensation_state']??null);
        $this->putIfColumn($update,'signal_references',$this->json($receipt['signal_references']??[]));

        $this->db->table('crm_capability_operations')
            ->where('company_id',$ctx->companyId)->where('capability',$capability)->where('idempotency_key',$key)
            ->update($update);
    }

    /** Persist a deterministic non-transient rejection after the mutation transaction has rolled back. */
    public function rejected(string $capability,string $key,array $request,array $rejection): void
    {
        if($key==='')return;
        $ctx=$this->scope->current();$now=now();$fingerprint=$this->fingerprint($request);
        $stored=['rejection'=>$rejection,'result'=>[],'receipt'=>[]];
        $row=[
            'public_id'=>(string)Str::ulid(),'company_id'=>$ctx->companyId,'actor_user_id'=>$ctx->actorUserId,'actor_type'=>$ctx->actorType,
            'capability'=>$capability,'idempotency_key'=>$key,'resource_type'=>$rejection['resource_type']??null,'resource_id'=>$rejection['resource_id']??null,
            'source_surface'=>$ctx->sourceSurface,'status'=>'rejected','request_fingerprint'=>json_encode(['sha256'=>$fingerprint]),
            'result'=>json_encode($stored,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),'correlation_id'=>$ctx->correlationId,'completed_at'=>$now,'created_at'=>$now,'updated_at'=>$now,
        ];
        $this->putIfColumn($row,'trace_id',$ctx->traceId!==''?$ctx->traceId:$ctx->correlationId);
        $this->putIfColumn($row,'causation_id',$ctx->causationId);
        $this->putIfColumn($row,'command_id',$request['_context']['command_id']??$request['command_id']??null);
        $this->putIfColumn($row,'command_contract_version',(int)($request['_context']['command_contract_version']??CrmCommandContract::VERSION));
        $this->putIfColumn($row,'expected_entity_version',$request['expected_entity_version']??$request['expected_version']??$request['_context']['expected_entity_version']??$request['_context']['expected_version']??null);
        $this->putIfColumn($row,'request_envelope',json_encode($this->requestEnvelope($capability,$key,$request),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
        $this->putIfColumn($row,'invariant_results',$this->json([['name'=>$rejection['invariant_id']??'crm.command.validation','status'=>'failed','message'=>$rejection['message']??'rejected']]));
        $this->putIfColumn($row,'compensation_state','not_required');
        $this->putIfColumn($row,'remediation_suggestion',$rejection['remediation_suggestion']??null);
        $this->db->table('crm_capability_operations')->insertOrIgnore($row);
        $this->db->table('crm_capability_operations')->where('company_id',$ctx->companyId)->where('capability',$capability)->where('idempotency_key',$key)->update(array_filter([
            'status'=>'rejected','result'=>$row['result'],'completed_at'=>$now,'updated_at'=>$now,
            'remediation_suggestion'=>$this->hasColumn('remediation_suggestion')?($rejection['remediation_suggestion']??null):null,
        ],fn($v,$k)=>$k!=='remediation_suggestion'||$this->hasColumn('remediation_suggestion'),ARRAY_FILTER_USE_BOTH));
    }

    /** @return array<string,mixed> */
    private function requestEnvelope(string $capability,string $key,array $request): array
    {
        $ctx=$this->scope->current();
        return [
            'command_contract_version'=>(int)($request['_context']['command_contract_version']??CrmCommandContract::VERSION),
            'command_id'=>$request['_context']['command_id']??$request['command_id']??null,
            'company_id'=>$ctx->companyId,
            'actor'=>['user_id'=>$ctx->actorUserId,'type'=>$ctx->actorType],
            'capability'=>$capability,'source'=>$ctx->sourceSurface,
            'trace_id'=>$request['_context']['trace_id']??($ctx->traceId!==''?$ctx->traceId:$ctx->correlationId),
            'correlation_id'=>$request['_context']['correlation_id']??$ctx->correlationId,
            'causation_id'=>$request['_context']['causation_id']??$ctx->causationId,
            'idempotency_key'=>$key,
            'expected_entity_version'=>$request['expected_entity_version']??$request['expected_version']??$request['_context']['expected_entity_version']??$request['_context']['expected_version']??null,
        ];
    }

    private function json(mixed $value): string
    { return json_encode($value,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR); }

    private function row(string $capability,string $key): ?object
    {
        $ctx=$this->scope->current();
        return $this->db->table('crm_capability_operations')->where('company_id',$ctx->companyId)
            ->where('capability',$capability)->where('idempotency_key',$key)->first();
    }

    private function fingerprint(array $request): string
    {
        unset($request['idempotency_key']);
        if(isset($request['_context'])&&is_array($request['_context']))unset($request['_context']['idempotency_key']);
        $normalise=function(mixed $value) use (&$normalise):mixed{
            if(!is_array($value))return $value;
            if(array_is_list($value))return array_map($normalise,$value);
            ksort($value);foreach($value as $k=>$v)$value[$k]=$normalise($v);return $value;
        };
        return hash('sha256',json_encode($normalise($request),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
    }

    private function recordReplay(int $operationId): void
    {
        if($operationId<=0||!$this->hasColumn('duplicate_replay_count'))return;
        $update=['duplicate_replay_count'=>$this->db->raw('duplicate_replay_count + 1')];
        if($this->hasColumn('last_replayed_at'))$update['last_replayed_at']=now();
        $this->db->table('crm_capability_operations')->where('id',$operationId)->update($update);
    }

    private function hasColumn(string $column): bool
    { try{return $this->db->getSchemaBuilder()->hasColumn('crm_capability_operations',$column);}catch(\Throwable){return false;} }

    /** @param array<string,mixed> $row */
    private function putIfColumn(array &$row,string $column,mixed $value): void
    { if($this->hasColumn($column))$row[$column]=$value; }

    /** @return array<string,mixed> */
    private function decode(mixed $value): array
    {
        if(is_array($value))return $value;
        if(is_object($value))return (array)$value;
        if(!is_string($value)||$value==='')return [];
        $decoded=json_decode($value,true);return is_array($decoded)?$decoded:[];
    }
}
