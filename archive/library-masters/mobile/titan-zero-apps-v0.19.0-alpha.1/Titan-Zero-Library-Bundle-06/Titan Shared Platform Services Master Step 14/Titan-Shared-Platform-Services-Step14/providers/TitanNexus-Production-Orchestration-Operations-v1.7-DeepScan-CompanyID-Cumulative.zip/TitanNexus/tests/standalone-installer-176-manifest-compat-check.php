<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$m=json_decode((string)file_get_contents($root.'/docs/reference/installer-1.7.6-extension.json'),true);
function i176Fail(string $message): never { fwrite(STDERR,"FAIL: {$message}\n"); exit(1); }
function i176Assert(bool $condition,string $message):void{if(!$condition)i176Fail($message);}
i176Assert(is_array($m),'legacy manifest valid');
i176Assert(count($m)===5,'legacy manifest exact five fields');
foreach(['name','type','version','description','support_telegram'] as $k)i176Assert(array_key_exists($k,$m),"legacy field {$k}");
i176Assert(($m['name']??null)==='Titan Nexus','legacy name');
i176Assert(($m['type']??null)==='extension','legacy type');
fwrite(STDOUT,"PASS: Installer 1.7.6 manifest compatibility template checks\n");
