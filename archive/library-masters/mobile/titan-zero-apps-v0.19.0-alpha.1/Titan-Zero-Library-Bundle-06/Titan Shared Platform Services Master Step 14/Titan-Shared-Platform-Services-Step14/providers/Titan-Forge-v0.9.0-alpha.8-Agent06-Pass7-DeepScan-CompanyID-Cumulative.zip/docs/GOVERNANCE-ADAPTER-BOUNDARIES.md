# Forge Governance Adapter Boundaries

## Objective

Prepare Forge for Titan Risk and Titan Shield without importing their internal implementation classes or guessing their deployed public APIs.

## Contracts

### `ForgeRiskGatewayContract`

Accepts:

- `BuildSpec`
- `ArtifactSet`
- local `ValidationResult`

Returns a typed `RiskDeclaration` with level, blocking decision, provider and structured reasons/metadata.

### `ForgeShieldGatewayContract`

Accepts the same bounded Forge context and returns a `ValidationResult` suitable for combining with release-gate evidence.

## Current packaged bindings

- `UnavailableRiskGateway`
- `UnavailableShieldGateway`

Both report unavailable. If invoked, both fail closed.

This is intentional. Forge must not silently assume a successful risk or quality decision when the authoritative engine is absent or its contract has not been verified.

## Intended later flow

`local Forge validation -> Shield inspection -> Risk assessment -> optional Model Council -> Governance approval -> Command Bus release mutation`

Titan Signal should carry lifecycle facts between engines. Direct Forge-to-engine public webhooks are not part of the internal architecture.
