<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalContext;

interface SignalManagerContract
{
    /** @return array<string, mixed> */
    public function health(SignalContext $context): array;

    /** @param array<string, mixed> $signal
     *  @return array{event_id:string,recorded_at:string,duplicate:bool,original_event_id:?string}
     */
    public function emit(array $signal, SignalContext $context): array;
}
