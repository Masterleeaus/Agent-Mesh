<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Inbox;

use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

final class UnifiedInboxService
{
    public function __construct(private readonly WorkCoreAuthorizationGateway $workCore)
    {
    }

    /** @return array<int, array<string, mixed>> */
    public function items(int $companyId, int $actorId, int $limit = 50): array
    {
        $limit = min(max($limit, 1), 100);
        $items = array_merge(
            $this->internalItems($companyId, $actorId, $limit),
            $this->externalItems($companyId, $actorId, $limit),
        );

        usort($items, static fn (InboxItem $a, InboxItem $b): int => strcmp((string) $b->lastMessageAt, (string) $a->lastMessageAt));
        return array_map(static fn (InboxItem $item): array => $item->toArray(), array_slice($items, 0, $limit));
    }

    /** @return array<int, InboxItem> */
    private function internalItems(int $companyId, int $actorId, int $limit): array
    {
        $conversations = TeamConversation::query()
            ->where('company_id', $companyId)
            ->whereHas('participants', fn ($query) => $query->where('company_id', $companyId)->where('user_id', $actorId)->whereNull('left_at')->whereNull('archived_at'))
            ->with([
                'latestMessage',
                'participants' => fn ($query) => $query->where('company_id', $companyId)->where('user_id', $actorId)->whereNull('left_at'),
            ])
            ->latest('updated_at')
            ->limit($limit)
            ->limit(5000)->get();

        $items = [];
        foreach ($conversations as $conversation) {
            if (! $this->canAccessLinked($companyId, $actorId, $conversation->linked_entity_type, $conversation->linked_entity_id)) {
                continue;
            }
            $participant = $conversation->participants->first();
            $unread = $conversation->messages()
                ->where('company_id', $companyId)
                ->when($participant?->last_read_at, fn ($query, $lastRead) => $query->where('created_at', '>', $lastRead))
                ->where(function ($query) use ($actorId): void {
                    $query->whereNull('user_id')->orWhere('user_id', '!=', $actorId);
                })
                ->count();
            $latest = $conversation->latestMessage;
            $items[] = new InboxItem(
                'internal',
                (string) $conversation->uuid,
                'internal-chat',
                $conversation->name ?: ucfirst((string) $conversation->type),
                $latest?->body,
                $unread,
                optional($latest?->created_at ?? $conversation->updated_at)->toIso8601String(),
                $conversation->linked_entity_type,
                $conversation->linked_entity_id === null ? null : (string) $conversation->linked_entity_id,
                ['type' => $conversation->type, 'visibility' => $conversation->visibility],
            );
        }
        return $items;
    }

    /** @return array<int, InboxItem> */
    private function externalItems(int $companyId, int $actorId, int $limit): array
    {
        $connectionIds = ChannelConnection::query()
            ->where('company_id', $companyId)
            ->whereHas('members', fn ($query) => $query->where('company_id', $companyId)->where('user_id', $actorId)->whereNull('left_at'))
            ->pluck('id');

        if ($connectionIds->isEmpty()) {
            return [];
        }

        $threads = ExternalThread::query()
            ->where('company_id', $companyId)
            ->whereIn('channel_connection_id', $connectionIds)
            ->with([
                'latestMessage', 'connection',
                'readStates' => fn ($query) => $query->where('company_id', $companyId)->where('user_id', $actorId),
            ])
            ->latest('last_message_at')
            ->limit($limit)
            ->limit(5000)->get();

        $items = [];
        foreach ($threads as $thread) {
            if (! $this->canAccessLinked($companyId, $actorId, $thread->linked_entity_type, $thread->linked_entity_id)) {
                continue;
            }
            $read = $thread->readStates->first();
            $unread = $thread->messages()
                ->where('company_id', $companyId)
                ->where('direction', 'inbound')
                ->when($read?->last_read_at, fn ($query, $lastRead) => $query->where('created_at', '>', $lastRead))
                ->count();
            $latest = $thread->latestMessage;
            $items[] = new InboxItem(
                'external',
                (string) $thread->uuid,
                (string) $thread->provider,
                $thread->display_name ?: $thread->external_contact_ref,
                $latest?->body,
                $unread,
                optional($latest?->created_at ?? $thread->last_message_at ?? $thread->updated_at)->toIso8601String(),
                $thread->linked_entity_type,
                $thread->linked_entity_id === null ? null : (string) $thread->linked_entity_id,
                [
                    'connection_uuid' => $thread->connection?->uuid,
                    'status' => $thread->status,
                    'handoff_state' => data_get($thread->metadata, 'handoff_state', 'ai'),
                ],
            );
        }
        return $items;
    }

    private function canAccessLinked(int $companyId, int $actorId, mixed $type, mixed $id): bool
    {
        if ($type === null || $id === null) {
            return true;
        }
        try {
            $this->workCore->assertCanAccess($companyId, $actorId, (string) $type, (string) $id);
            return true;
        } catch (AccessDeniedHttpException) {
            return false;
        }
    }
}
