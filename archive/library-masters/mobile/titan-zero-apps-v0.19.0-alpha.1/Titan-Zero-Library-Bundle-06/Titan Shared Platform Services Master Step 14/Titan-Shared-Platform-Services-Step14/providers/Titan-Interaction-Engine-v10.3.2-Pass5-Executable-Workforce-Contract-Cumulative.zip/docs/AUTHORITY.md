# Authority

Six levels remain: `observe_only`, `recommend_only`, `prepare_only`, `approval_required`, `delegated_autonomous`, `user_only`.

Authorization occurs before provider routing. Prepare-only returns a prepared non-executing result. Approval-required actions need cryptographically scoped approval; delegated-autonomous always needs delegated scope; user-only honors roles/fresh-auth policy. Surface names never imply authority.
