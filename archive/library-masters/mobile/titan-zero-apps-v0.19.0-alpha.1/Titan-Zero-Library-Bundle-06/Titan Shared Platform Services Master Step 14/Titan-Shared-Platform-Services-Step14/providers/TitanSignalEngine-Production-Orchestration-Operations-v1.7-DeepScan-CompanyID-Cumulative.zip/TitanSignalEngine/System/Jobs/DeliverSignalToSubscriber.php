<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Jobs;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryDispatcherContract;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Throwable;

final class DeliverSignalToSubscriber implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 1;
    public bool $failOnTimeout = true;
    public int $timeout;
    public bool $afterCommit = true;
    public readonly string $executionToken;

    public function __construct(
        public readonly string $deliveryId,
        int $timeoutSeconds = 30,
        ?string $executionToken = null,
    ) {
        $this->timeout = max(1, min($timeoutSeconds, 3600));
        $this->executionToken = $executionToken ?? self::uuid7();
    }

    public function handle(SignalDeliveryDispatcherContract $dispatcher): void
    {
        $dispatcher->deliver(
            $this->deliveryId,
            $this->executionToken,
            'queue-job:' . $this->executionToken,
        );
    }

    public function failed(Throwable $exception): void
    {
        try {
            app(SignalDeliveryDispatcherContract::class)->transportFailed(
                $this->deliveryId,
                $exception,
                $this->executionToken,
            );
        } catch (Throwable $reportingFailure) {
            Log::error('signal.delivery_transport_failure_record_failed', [
                'delivery_id' => $this->deliveryId,
                'error_class' => $reportingFailure::class,
            ]);
        }
    }

    private static function uuid7(): string
    {
        $milliseconds = (int) floor(microtime(true) * 1000);
        $timeHex = str_pad(dechex($milliseconds), 12, '0', STR_PAD_LEFT);
        $random = bin2hex(random_bytes(10));
        $hex = $timeHex . $random;
        $hex[12] = '7';
        $variant = hexdec($hex[16]);
        $hex[16] = dechex(($variant & 0x3) | 0x8);
        return sprintf('%s-%s-%s-%s-%s', substr($hex, 0, 8), substr($hex, 8, 4), substr($hex, 12, 4), substr($hex, 16, 4), substr($hex, 20, 12));
    }
}
