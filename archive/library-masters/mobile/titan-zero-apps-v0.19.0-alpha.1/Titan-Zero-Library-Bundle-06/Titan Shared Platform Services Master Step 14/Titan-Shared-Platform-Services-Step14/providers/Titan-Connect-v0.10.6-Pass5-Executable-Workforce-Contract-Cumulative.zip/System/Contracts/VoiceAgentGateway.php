<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

interface VoiceAgentGateway
{
    public function create(array $config): array;
    public function update(string $agentId, array $config): array;
    public function delete(string $agentId): void;
    public function voices(): array;
    public function addKnowledge(string $type, mixed $content, ?string $name = null): array;
    public function removeKnowledge(string $documentId): void;
}
