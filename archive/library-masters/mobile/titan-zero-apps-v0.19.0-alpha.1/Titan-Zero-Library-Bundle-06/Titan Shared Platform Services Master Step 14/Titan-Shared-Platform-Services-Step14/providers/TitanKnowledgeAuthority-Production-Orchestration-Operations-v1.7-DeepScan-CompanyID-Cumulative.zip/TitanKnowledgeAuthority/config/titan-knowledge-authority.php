<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'tenant_key' => 'tenant_company_id',
    'refresh_enabled' => false,
    'access_context' => [
        // Host applications should bind KnowledgeAccessContextResolverContract.
        // The extension default is deliberately fail-closed.
        'default' => 'fail-closed',
    ],
];
