# Titan Rewind Disaster Recovery

**Target RPO: 15 minutes. Target RTO: 120 minutes.**

The durable backup scope is every Rewind-owned forensic table, source watermark, historical artifact, evidence package, signing-key metadata record, custody event, legal hold, Governance receipt, runtime outbox/dead-letter record and purge receipt, plus the external storage/key material required to verify evidence. Private signing keys remain governed secrets and must be backed up using the host secret-management procedure rather than copied into Rewind data.

## Restore order

1. Restore schema and migration state.
2. Restore trace events and trace indexes.
3. Restore source watermarks and historical artifacts.
4. Restore cases, snapshots and dependency projections.
5. Restore integrity/drift state and replay records.
6. Restore evidence packages, signing-key metadata and custody records.
7. Restore recovery/Governance receipts.
8. Restore legal holds **before any retention worker starts**.
9. Restore purge runs/receipts and operational outbox/dead-letter state.

## Reconciliation

After restore, run integrity verification over restored traces, verify evidence signatures, reconcile custody chains, re-apply active legal holds, perform source resynchronization from each host-owned Rewind source adapter, refresh source watermarks, rebuild incremental projections, reconcile in-flight replay/evidence/recovery operations and verify Signal/Governance circuits. Retention stays paused until those checks pass.

`tests/standalone/verify_disaster_recovery.php` exercises the package DR contract and a byte-identical hash restore simulation. Exact RPO/RTO under production storage load must be measured in the target host.
