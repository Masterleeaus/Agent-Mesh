<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\DTO;

final readonly class GovernanceDecision
{
    public function __construct(
        public bool $allowed,
        public ?string $reference,
        public ?string $riskClass = null,
        public ?string $approvalReference = null,
        public bool $approvalRequired = false,
        public ?string $reasonCode = null,
    ) {}

    public static function unavailable(): self
    {
        return new self(false, null, null, null, false, 'GOVERNANCE_UNAVAILABLE');
    }
}
