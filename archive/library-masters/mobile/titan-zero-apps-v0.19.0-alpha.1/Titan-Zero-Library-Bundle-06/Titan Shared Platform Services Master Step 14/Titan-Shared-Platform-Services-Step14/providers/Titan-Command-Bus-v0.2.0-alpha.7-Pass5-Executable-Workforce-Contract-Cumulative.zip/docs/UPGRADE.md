# Upgrade

Use forward-only additive migrations. Do not republish historical migration basenames in incremental upgrade bundles where Installer 1.7.8 treats them as new candidates. Preserve old receipts and reconcile in-flight claims before schema contraction.
