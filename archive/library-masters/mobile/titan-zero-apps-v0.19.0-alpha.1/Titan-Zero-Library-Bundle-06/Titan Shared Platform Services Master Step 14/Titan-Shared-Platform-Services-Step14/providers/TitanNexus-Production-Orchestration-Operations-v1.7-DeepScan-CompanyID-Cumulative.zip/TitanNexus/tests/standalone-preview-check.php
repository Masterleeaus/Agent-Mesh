<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Adapters\Platform\PlatformReadinessAdapter;
use App\Extensions\TitanNexus\System\Contracts\VerticalDefinitionSourceContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompilationStatus;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Exceptions\NexusValidationException;
use App\Extensions\TitanNexus\System\Services\DeterministicNexusCompiler;
use App\Extensions\TitanNexus\System\Services\NexusManager;
use App\Extensions\TitanNexus\System\Services\SemanticNexusValidator;

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
$files = [
    '/System/Support/CanonicalJson.php',
    '/System/Support/DeterministicMerge.php',
    '/System/Domain/CompilationStatus.php',
    '/System/Domain/CompilationLifecycleStage.php',
    '/System/Domain/RuntimeReadinessReport.php',
    '/System/Domain/ValueObjects/TraceContext.php',
    '/System/Domain/BusinessProfile.php',
    '/System/Domain/CompiledTitanConfig.php',
    '/System/Domain/SemanticChangeKind.php',
    '/System/Domain/SemanticChangeDisposition.php',
    '/System/Domain/SemanticDiffEntry.php',
    '/System/Domain/ConfigurationDiff.php',
    '/System/Domain/VerticalDefinition.php',
    '/System/Domain/ValidationSeverity.php',
    '/System/Domain/ValidationFinding.php',
    '/System/Domain/ValidationResult.php',
    '/System/Domain/NexusCompilation.php',
    '/System/Domain/CompilationPreview.php',
    '/System/Contracts/NexusCompilerContract.php',
    '/System/Contracts/ConfigurationDifferContract.php',
    '/System/Contracts/VerticalDefinitionSourceContract.php',
    '/System/Contracts/PlatformReadinessSourceContract.php',
    '/System/Contracts/NexusValidatorContract.php',
    '/System/Contracts/NexusManagerContract.php',
    '/System/Adapters/Platform/PlatformReadinessAdapter.php',
    '/System/Services/DeterministicNexusCompiler.php',
    '/System/Services/SemanticConfigurationDiffer.php',
    '/System/Services/SemanticNexusValidator.php',
    '/System/Exceptions/NexusValidationException.php',
    '/System/Services/NexusManager.php',
];
foreach ($files as $file) {
    $path = $root . $file;
    if (!is_file($path)) {
        fwrite(STDERR, "FAIL: missing preview production class file {$file}\n");
        exit(1);
    }
    require_once $path;
}

function previewCheck(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

$trace = TraceContext::fromArray([
    'tenant_company_id' => 42,
    'trace_id' => '11111111-1111-4111-8111-111111111111',
    'correlation_id' => '22222222-2222-4222-8222-222222222222',
    'causation_id' => '33333333-3333-4333-8333-333333333333',
]);
$compiler = new DeterministicNexusCompiler('0.4.0');

$readyProfile = BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '3.0.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
    'timezone' => 'Australia/Melbourne',
    'sections' => [
        'billing' => ['currency' => 'AUD'],
        'workforce' => ['roles' => ['cleaner']],
    ],
]);
$readySource = new class implements VerticalDefinitionSourceContract {
    public int $calls = 0;
    public function resolve(BusinessProfile $profile): VerticalDefinition
    {
        $this->calls++;
        return VerticalDefinition::fromArray([
            'vertical_id' => $profile->verticalId(),
            'vertical_version' => $profile->verticalVersion(),
            'knowledge_snapshot_version' => 'au-vic-2026.08',
            'sections' => [
                'billing' => ['currency' => 'USD', 'tax_mode' => 'exclusive'],
                'operations' => ['recurring' => true],
            ],
            'validation' => [
                'required_profile_paths' => ['sections.billing.currency'],
                'recommended_profile_paths' => ['sections.operations.service_area'],
                'required_platform_capabilities' => ['crm.customer.read'],
                'require_knowledge_snapshot' => true,
            ],
        ]);
    }
};
$manager = new NexusManager(
    $compiler,
    $readySource,
    new SemanticNexusValidator(new PlatformReadinessAdapter(null, ['crm.customer.read'])),
);
$draft = $manager->newDraft($readyProfile, $trace, '44444444-4444-4444-8444-444444444444');
$preview = $manager->previewDraft($draft, '4');
previewCheck($preview->dryRun(), 'preview must always be dry-run');
previewCheck($preview->canCompile(), 'warning-only preview must remain compilable');
previewCheck($preview->compiledConfiguration() !== null, 'ready preview must contain compiled configuration');
previewCheck($preview->validationResult()->warnings() !== [], 'recommended path warning must be preserved in preview');
previewCheck(($preview->toArray()['section_summary'][0]['name'] ?? null) === 'billing', 'section summary must be sorted deterministically');
previewCheck(($preview->toArray()['compiled_configuration']['sections']['billing']['currency'] ?? null) === 'AUD', 'preview uses the deterministic compiler output');
previewCheck($readySource->calls === 1, 'preview resolves vertical definition exactly once');
previewCheck($draft->status() === CompilationStatus::Draft, 'preview must not mutate original draft');

$compiled = $manager->compileDraft($draft, '4');
previewCheck($compiled->status() === CompilationStatus::Compiled, 'warning-only validation allows compile');
previewCheck($compiled->validationResult()?->warnings() !== [], 'compiled aggregate retains validation result');

$blockedProfile = BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '3.0.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['country_code' => 'AU'],
    'timezone' => 'Australia/Melbourne',
    'sections' => [],
]);
$blockedSource = new class implements VerticalDefinitionSourceContract {
    public int $calls = 0;
    public function resolve(BusinessProfile $profile): VerticalDefinition
    {
        $this->calls++;
        return VerticalDefinition::fromArray([
            'vertical_id' => $profile->verticalId(),
            'vertical_version' => $profile->verticalVersion(),
            'knowledge_snapshot_version' => 'au-vic-2026.08',
            'sections' => [],
            'validation' => ['required_profile_paths' => ['sections.billing.currency']],
        ]);
    }
};
$blockedManager = new NexusManager(
    $compiler,
    $blockedSource,
    new SemanticNexusValidator(new PlatformReadinessAdapter(null, [])),
);
$blockedDraft = $blockedManager->newDraft($blockedProfile, $trace, '55555555-5555-4555-8555-555555555555');
$blockedPreview = $blockedManager->previewDraft($blockedDraft, '4');
previewCheck(!$blockedPreview->canCompile(), 'blocking validation must make preview non-compilable');
previewCheck($blockedPreview->compiledConfiguration() === null, 'blocked preview must not contain compiled output');
previewCheck($blockedPreview->validationResult()->hasErrors(), 'blocked preview must expose validation errors');

$thrown = false;
try {
    $blockedManager->compileDraft($blockedDraft, '4');
} catch (NexusValidationException $e) {
    $thrown = true;
    previewCheck($e->validationResult()->hasErrors(), 'compile rejection must carry structured validation result');
}
previewCheck($thrown, 'compileDraft must reject blocking validation');
previewCheck($blockedDraft->status() === CompilationStatus::Draft, 'blocked compile must leave original draft untouched');

fwrite(STDOUT, "PASS: Titan Nexus standalone preview checks\n");
