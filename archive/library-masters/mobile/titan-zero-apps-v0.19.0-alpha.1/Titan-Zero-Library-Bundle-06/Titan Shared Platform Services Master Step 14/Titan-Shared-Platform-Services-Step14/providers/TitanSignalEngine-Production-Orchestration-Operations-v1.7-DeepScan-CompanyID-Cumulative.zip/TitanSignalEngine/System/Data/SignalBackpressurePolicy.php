<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalBackpressurePolicy
{
    public function __construct(public int $threshold)
    {
        if ($this->threshold < 1) {
            throw new InvalidArgumentException('Backpressure threshold must be positive.');
        }
    }

    /**
     * @param array<string,int> $counts
     * @return array<string,int|bool>
     */
    public function evaluate(array $counts): array
    {
        $normalized = [];
        foreach ([
            'pending',
            'retry_wait',
            'processing',
            'stale_processing',
            'recent_dead_letter',
            'unresolved_dead_letter',
            'resolved_historical_dead_letter',
        ] as $key) {
            $normalized[$key] = max(0, (int) ($counts[$key] ?? 0));
        }

        // Current throughput pressure is intentionally independent from retained
        // historical DLQ records. Stale workers and recent dead letters receive
        // extra weight because they are active recovery pressure.
        $pressure = $normalized['pending']
            + $normalized['retry_wait']
            + $normalized['processing']
            + ($normalized['stale_processing'] * 2)
            + ($normalized['recent_dead_letter'] * 5);

        return [
            ...$normalized,
            'total_pressure' => $pressure,
            'threshold' => $this->threshold,
            'backpressured' => $pressure >= $this->threshold,
        ];
    }
}
