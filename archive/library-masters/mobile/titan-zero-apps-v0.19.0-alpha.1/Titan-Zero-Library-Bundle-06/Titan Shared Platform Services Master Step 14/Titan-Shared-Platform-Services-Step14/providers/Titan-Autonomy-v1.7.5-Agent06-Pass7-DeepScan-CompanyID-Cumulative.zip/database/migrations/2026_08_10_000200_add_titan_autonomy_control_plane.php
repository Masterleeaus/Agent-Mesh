<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_autonomy_control_events')) {
            Schema::create('titan_autonomy_control_events', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->string('event_type', 96)->index();
                $table->string('capability', 120)->nullable()->index();
                $table->string('workflow_key', 120)->nullable();
                $table->json('payload_json')->nullable();
                $table->string('policy_version', 64);
                $table->string('correlation_id', 96)->nullable()->index();
                $table->string('rewind_ref', 160)->nullable()->index();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_autonomy_control_events');
    }
};
