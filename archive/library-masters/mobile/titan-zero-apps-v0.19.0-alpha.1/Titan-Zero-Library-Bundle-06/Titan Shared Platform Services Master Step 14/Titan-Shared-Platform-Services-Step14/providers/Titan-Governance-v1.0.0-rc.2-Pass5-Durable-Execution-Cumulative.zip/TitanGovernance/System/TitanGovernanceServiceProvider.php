<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanGovernance\System\Commands\CertifyExtensionCommand;
use App\Extensions\TitanGovernance\System\Commands\RefreshGovernanceProjectionsCommand;
use App\Extensions\TitanGovernance\System\Actions\GovernanceActionRepository;
use App\Extensions\TitanGovernance\System\Actions\GovernanceActionService;
use App\Extensions\TitanGovernance\System\Actions\GovernanceCommandReceiptValidator;
use App\Extensions\TitanGovernance\System\Actions\UnavailableGovernanceCommandGateway;
use App\Extensions\TitanGovernance\System\Context\TenantCompanyResolver;
use App\Extensions\TitanGovernance\System\Contracts\ExtensionHealth;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceActionDecisionStoreContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceDecisionEvidenceSourceContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceDecisionReadStoreContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceCommandGatewayContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceEscalationStoreContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceManagerContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceProjectionSinkContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceReadSourceContract;
use App\Extensions\TitanGovernance\System\ControlCentre\AuthorityContractionProjector;
use App\Extensions\TitanGovernance\System\ControlCentre\ControlCentreSourceReader;
use App\Extensions\TitanGovernance\System\ControlCentre\EngineHealthScorecard;
use App\Extensions\TitanGovernance\System\ControlCentre\EvidenceFreshnessProjector;
use App\Extensions\TitanGovernance\System\ControlCentre\GovernanceAttentionRanker;
use App\Extensions\TitanGovernance\System\ControlCentre\GovernanceControlCentre;
use App\Extensions\TitanGovernance\System\ControlCentre\ModelHealthProjector;
use App\Extensions\TitanGovernance\System\ControlCentre\PolicyComplianceHealthProjector;
use App\Extensions\TitanGovernance\System\ControlCentre\WorkforceOversightProjector;
use App\Extensions\TitanGovernance\System\ControlCentre\HumanOversightProjector;
use App\Extensions\TitanGovernance\System\Health\TitanGovernanceHealthCheck;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceDecisionEvidenceRegistry;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceDecisionReadRepository;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceDecisionIntelligence;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceEvidenceSanitizer;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceDeltaViewer;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernancePolicyComplianceProjector;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceRewindTheater;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\UnavailableDecisionEvidenceSource;
use App\Extensions\TitanGovernance\System\Escalation\GovernanceEscalationPriority;
use App\Extensions\TitanGovernance\System\Escalation\GovernanceEscalationRepository;
use App\Extensions\TitanGovernance\System\Escalation\GovernanceEscalationTarget;
use App\Extensions\TitanGovernance\System\Host\GovernanceMenuRegistrar;
use App\Extensions\TitanGovernance\System\Host\TitanHostAuthorizationAdapter;
use App\Extensions\TitanGovernance\System\Host\TitanMenuCompatibilityAdapter;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceReadPlane;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceReadSourceRegistry;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceSignalIntelligence;
use App\Extensions\TitanGovernance\System\ReadPlane\SignalHeatmapProjector;
use App\Extensions\TitanGovernance\System\ReadPlane\OperationalPressureDetector;
use App\Extensions\TitanGovernance\System\ReadPlane\CircuitBreakerProjector;
use App\Extensions\TitanGovernance\System\ReadPlane\TrustMapProjector;
use App\Extensions\TitanGovernance\System\ReadPlane\UnavailableGovernanceReadSource;
use App\Extensions\TitanGovernance\System\Services\GovernanceAuthorityConstraintFactory;
use App\Extensions\TitanGovernance\System\Projection\GovernanceProjectionService;
use App\Extensions\TitanGovernance\System\Projection\GovernanceProjectionStore;
use App\Extensions\TitanGovernance\System\Services\GovernanceManager;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;
use Throwable;

final class TitanGovernanceServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-governance.php', 'titan-governance');
        $this->app->singleton(GovernanceReadSourceRegistry::class);
        $this->app->singleton(GovernanceDecisionEvidenceRegistry::class);
        $this->app->singleton(GovernanceEvidenceSanitizer::class);
        $this->app->singleton(GovernanceDecisionReadStoreContract::class, GovernanceDecisionReadRepository::class);
        $this->app->singleton(GovernanceDecisionIntelligence::class);
        $this->app->singleton(GovernanceDeltaViewer::class);
        $this->app->singleton(GovernancePolicyComplianceProjector::class);
        $this->app->singleton(GovernanceRewindTheater::class);
        $this->app->singleton(TrustMapProjector::class);
        $this->app->singleton(SignalHeatmapProjector::class);
        $this->app->singleton(OperationalPressureDetector::class);
        $this->app->singleton(CircuitBreakerProjector::class);
        $this->app->singleton(GovernanceSignalIntelligence::class);
        $this->app->singleton(ControlCentreSourceReader::class);
        $this->app->singleton(EvidenceFreshnessProjector::class);
        $this->app->singleton(ModelHealthProjector::class);
        $this->app->singleton(PolicyComplianceHealthProjector::class);
        $this->app->singleton(WorkforceOversightProjector::class);
        $this->app->singleton(HumanOversightProjector::class);
        $this->app->singleton(AuthorityContractionProjector::class);
        $this->app->singleton(EngineHealthScorecard::class);
        $this->app->singleton(GovernanceAttentionRanker::class);
        $this->app->singleton(GovernanceControlCentre::class);
        $this->app->singleton(GovernanceProjectionSinkContract::class, GovernanceProjectionStore::class);
        $this->app->singleton(GovernanceProjectionService::class);
        $this->app->singleton(GovernanceReadPlane::class);
        $this->app->singleton(ExtensionHealth::class, TitanGovernanceHealthCheck::class);
        $this->app->singleton(TenantCompanyResolver::class);
        $this->app->singleton(TitanHostAuthorizationAdapter::class);
        $this->app->singleton(TitanMenuCompatibilityAdapter::class);
        $this->app->singleton(GovernanceMenuRegistrar::class);
        $this->app->singleton(GovernanceAuthorityConstraintFactory::class);
        $this->app->singleton(GovernanceEscalationPriority::class);
        $this->app->singleton(GovernanceEscalationStoreContract::class, GovernanceEscalationRepository::class);
        $this->app->singleton(GovernanceActionDecisionStoreContract::class, GovernanceActionRepository::class);
        $this->app->singleton(GovernanceCommandReceiptValidator::class);
        $this->app->singleton(GovernanceActionService::class);
        $this->app->singleton(GovernanceEscalationTarget::class);
        $this->app->singleton(GovernanceCommandGatewayContract::class, function ($app): GovernanceCommandGatewayContract {
            $class=config('titan-governance.command_gateway_class');
            if(is_string($class) && trim($class)!=='') {
                try {
                    $candidate=$app->make($class);
                    if($candidate instanceof GovernanceCommandGatewayContract) return $candidate;
                } catch (Throwable) {}
            }
            return new UnavailableGovernanceCommandGateway();
        });
        $this->app->singleton(GovernanceManagerContract::class, GovernanceManager::class);
    }

    public function boot(): void
    {
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->publishes([__DIR__ . '/../config/titan-governance.php' => config_path('titan-governance.php')], 'titan-governance-config');
        if ($this->app->runningInConsole()) $this->commands([CertifyExtensionCommand::class, RefreshGovernanceProjectionsCommand::class]);
        if (!config('titan-governance.enabled', true)) return;

        $this->registerReadSources();
        $this->registerDecisionEvidenceSources();
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-governance');
        $this->registerRoutes();
        try { $this->registerNavigation(); } catch (Throwable) { /* navigation must never make provider boot fatal */ }
    }

    public function registerKey(): string { return 'titan-governance'; }
    public static function uninstall(): void
    {
        try { app(TitanMenuCompatibilityAdapter::class)->removeAll(GovernanceMenuRegistrar::definitions()); } catch (Throwable) {}
        File::delete(config_path('titan-governance.php'));
    }

    private function registerReadSources(): void
    {
        $registry = $this->app->make(GovernanceReadSourceRegistry::class);
        $definitions = config('titan-governance.read_sources', []);
        if (!is_array($definitions)) $definitions = [];

        foreach ($definitions as $key => $definition) {
            if (!is_string($key) || !is_array($definition)) continue;
            $required = (bool)($definition['required'] ?? false);
            $class = $definition['class'] ?? null;
            $source = null;
            $reason = null;

            if (is_string($class) && trim($class) !== '') {
                try {
                    $candidate = $this->app->make($class);
                    if ($candidate instanceof GovernanceReadSourceContract && $candidate->key() === $key) $source = $candidate;
                    else $reason = 'INVALID_SOURCE_ADAPTER';
                } catch (Throwable) {
                    $reason = 'SOURCE_ADAPTER_RESOLUTION_FAILED';
                }
            }

            if (!$source instanceof GovernanceReadSourceContract) {
                $source = new UnavailableGovernanceReadSource($key, $required, $required ? 'UNAVAILABLE' : 'NOT_INSTALLED', $reason);
            }

            try { $registry->register($source); } catch (Throwable) { /* duplicate contribution fails closed to first registered source */ }
        }
    }

    private function registerDecisionEvidenceSources(): void
    {
        $registry=$this->app->make(GovernanceDecisionEvidenceRegistry::class);
        $definitions=config('titan-governance.decision_evidence_sources',[]);
        if(!is_array($definitions)) $definitions=[];
        foreach($definitions as $key=>$definition){
            if(!is_string($key)||!is_array($definition)) continue;
            $required=(bool)($definition['required']??false);$class=$definition['class']??null;$source=null;$reason=null;
            if(is_string($class)&&trim($class)!==''){
                try{$candidate=$this->app->make($class);if($candidate instanceof GovernanceDecisionEvidenceSourceContract && $candidate->key()===$key)$source=$candidate;else $reason='INVALID_DECISION_EVIDENCE_ADAPTER';}
                catch(Throwable){$reason='DECISION_EVIDENCE_ADAPTER_RESOLUTION_FAILED';}
            }
            if(!$source instanceof GovernanceDecisionEvidenceSourceContract) $source=new UnavailableDecisionEvidenceSource($key,$required,$required?'UNAVAILABLE':'NOT_INSTALLED',$reason);
            try{$registry->register($source);}catch(Throwable){/* first registered source wins */}
        }
    }

    private function registerRoutes(): void
    {
        /** @var Router $router */ $router=$this->app['router'];
        $router->group(['middleware'=>['web','auth'],'prefix'=>'dashboard/user/titan-governance','as'=>'dashboard.user.titan.governance.'], static function (Router $router):void{ require __DIR__.'/../routes/user.php'; });
        $router->group(['middleware'=>['web','auth','admin'],'prefix'=>'dashboard/admin/titan-governance','as'=>'dashboard.admin.titan.governance.'], static function (Router $router):void{ require __DIR__.'/../routes/admin.php'; });
    }

    private function registerNavigation(): void
    {
        $this->app->make(GovernanceMenuRegistrar::class)->registerNavigation();
    }
}
