<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalSubscriptionRuntime extends Model
{
    protected $table = 'titan_signal_subscription_runtime';
    protected $guarded = [];

    protected $casts = [
        'active_definition_version' => 'integer',
        'quarantined_at' => 'datetime',
        'last_validated_at' => 'datetime',
    ];
}
