<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalRetryPolicy
{
    /** @param list<int> $backoffSeconds */
    public function __construct(
        public int $maxAttempts,
        public array $backoffSeconds,
    ) {
        if ($this->maxAttempts < 1 || $this->maxAttempts > 100) {
            throw new InvalidArgumentException('max_attempts must be between 1 and 100.');
        }
        foreach ($this->backoffSeconds as $delay) {
            if (! is_int($delay) || $delay < 0 || $delay > 86400) {
                throw new InvalidArgumentException('backoff_seconds entries must be integers between 0 and 86400.');
            }
        }
    }

    public function shouldRetry(int $attemptNumber): bool
    {
        return $attemptNumber < $this->maxAttempts;
    }

    public function delaySecondsForAttempt(int $attemptNumber): int
    {
        if ($attemptNumber < 1) {
            throw new InvalidArgumentException('attemptNumber must be at least 1.');
        }
        if ($this->backoffSeconds === []) {
            return 0;
        }
        $index = min($attemptNumber - 1, count($this->backoffSeconds) - 1);
        return $this->backoffSeconds[$index];
    }
}
