# Titan Model Council v0.4.0 — Foundations Pass

## Implemented

### Tenant enforcement
- Canonical `tenant_company_id` is required for active Council execution.
- Tenant identity is resolved only from trusted middleware attributes, internal context, or the authenticated user's `tenant_company_id`; raw request input is not trusted.
- Compatibility response acceptance is scoped by tenant + user + chat + shared UUID.
- New Council chat messages and model response rows are stamped with `tenant_company_id`.
- Shared-response lookup/deletion is tenant scoped.
- Native Council decision reads/updates are tenant scoped.
- Forward migration adds tenant columns to compatibility records.

### Reserve → Execute → Settle Council billing
- Added `titan_model_council_billing_reservations` ledger.
- Direct streaming and non-streaming Council calls create a reservation before provider dispatch.
- Every selected participant must pass credit preflight before execution; synthesis credit is also preflighted.
- Actual successful output credits are settled against the reservation.
- Unused exposure is released at settlement; all-participant failure releases the reservation.
- Reservation/audit initialization failure fails closed before provider execution.

Important boundary: the supplied legacy host driver exposes `hasCreditBalance()` and `decreaseCredit()` but no atomic account-level hold API. v0.4.0 therefore implements the Council reservation ledger and fail-closed dispatch ordering. The future Titan AI Core billing gateway should replace this with an account-authoritative hard hold while keeping the same Council reservation contract.

### Selective activation
- Added deterministic `SelectiveActivationPolicy`.
- Added native `POST /dashboard/user/titan-model-council/plan` planning endpoint.
- Routing outcomes: `single_model`, `lightweight_council`, `parallel_consensus`.
- Greeting/low-consequence requests can bypass Council.
- Moderate uncertainty selects lightweight Council.
- High uncertainty selects parallel consensus.
- High-risk/high-consequence requests select full parallel consensus and set `governance_escalation_required` until governed role execution is implemented.
- Manual requests cannot force the reserved `governed_deliberation` runtime while it is disabled.

### Activation audit / Rewind preparation
- Decision records now capture activation reason/source, trigger metadata, strategy, risk level, requested/actual participant counts, confidence/agreement, contradiction/escalation state, and billing reservation ID.
- Trace, correlation and causation IDs propagate into Council metadata and decision records.

### Contradiction safeguard
- Added deterministic direct-contradiction detection for mutually exclusive affirmative/negative claims.
- Strong contradictions cap confidence below the configured ceiling (default 50%).
- Consequential prompts set `requires_escalation` and append an independent-verification/human-authorization caveat.
- Safeguard is applied to synthesized streaming and non-streaming outputs.

### Adaptive quorum / timeout foundations
- Provider timeout is now configurable.
- Shared-response synthesis can return early only when minimum quorum is met, agreement exceeds threshold, risk is not high/critical, and no strong contradiction is detected.
- Direct provider request cancellation remains disabled until Titan AI Core owns provider dispatch; v0.4.0 does not pretend an unsafe cancellation mechanism exists.

### Security / credential audit
- No hard-coded provider API keys found in active extension code.
- Council logging does not include provider authorization headers/request specs.
- Provider credentials remain host-managed in the legacy compatibility engine and are never written to Council decision/billing records.

## Preserved
- Existing parallel provider calls
- SSE streaming
- OpenAI / Anthropic / Gemini / DeepSeek / xAI / OpenRouter compatibility
- Synthesis and fallback synthesis
- Consensus / disagreement / discovery logic
- Legacy AI Chat Pro / Multi-Model compatibility surfaces
- User plan/model entitlement enforcement
- Existing migrations and legacy source archive

## Explicitly not claimed yet
- Proposer → Critic → Verifier → Arbiter execution
- Titan Shield runtime validation
- Direct Titan Risk Engine callback
- AI Core provider dispatch ownership
- AI Core account-authoritative billing hard holds
- Dynamic model capability ranking
- Direct in-flight HTTP cancellation for early synthesis
- Wisdom-driven adaptive model selection
