<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Attachments;

use App\Extensions\TitanConnect\System\Contracts\RetentionPolicy;
use App\Extensions\TitanConnect\System\Models\MessageAttachment;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use RuntimeException;

final class AttachmentUploadService
{
    public function __construct(
        private readonly AttachmentValidator $validator,
        private readonly RetentionPolicy $retention,
    ) {
    }

    public function stage(int $companyId, UploadedFile $file): MessageAttachment
    {
        $size = (int) ($file->getSize() ?: 0);
        $mime = strtolower(trim((string) ($file->getMimeType() ?: $file->getClientMimeType() ?: '')));
        $maxBytes = (int) config('titan-connect.attachments.max_bytes', 25 * 1024 * 1024);
        $allowed = (array) config('titan-connect.attachments.allowed_mime_types', []);

        $errors = [];
        if (! $file->isValid()) $errors['file'] = 'Attachment upload is invalid.';
        if ($size <= 0 || $size > $maxBytes) $errors['file'] = 'Attachment size is invalid or exceeds the configured limit.';
        if ($mime === '' || ($allowed !== [] && ! in_array($mime, $allowed, true))) $errors['file'] = 'Attachment MIME type is not allowed.';
        if ($errors !== []) {
            throw ValidationException::withMessages($errors);
        }

        $realPath = $file->getRealPath();
        if (! is_string($realPath) || $realPath === '' || ! is_file($realPath)) {
            throw new RuntimeException('Uploaded attachment temporary file is unavailable.');
        }
        $sha256 = hash_file('sha256', $realPath);
        if (! is_string($sha256) || $sha256 === '') {
            throw new RuntimeException('Uploaded attachment checksum could not be calculated.');
        }

        $disk = (string) config('titan-connect.attachments.storage_disk', config('filesystems.default', 'local'));
        $extension = strtolower($file->guessExtension() ?: $file->getClientOriginalExtension() ?: 'bin');
        $extension = preg_replace('/[^a-z0-9]+/', '', $extension) ?: 'bin';
        $path = sprintf('titan-connect/company/%d/%s/%s.%s', $companyId, now()->format('Y/m'), (string) Str::uuid(), $extension);

        $stream = fopen($realPath, 'rb');
        if ($stream === false) {
            throw new RuntimeException('Uploaded attachment could not be opened.');
        }
        try {
            $written = Storage::disk($disk)->put($path, $stream);
        } finally {
            fclose($stream);
        }
        if (! $written) {
            throw new RuntimeException('Uploaded attachment could not be written to configured storage.');
        }

        $days = $this->retention->daysForCompany($companyId);
        try {
            return $this->validator->registerStaged($companyId, [
                'storage_disk' => $disk,
                'storage_path' => $path,
                'original_name' => $file->getClientOriginalName(),
                'mime_type' => $mime,
                'size_bytes' => $size,
                'sha256' => $sha256,
                'provider_media' => ['source' => 'staff-upload'],
                'expires_at' => $days > 0 ? now()->addDays($days) : null,
            ]);
        } catch (\Throwable $e) {
            Storage::disk($disk)->delete($path);
            throw $e;
        }
    }
}
