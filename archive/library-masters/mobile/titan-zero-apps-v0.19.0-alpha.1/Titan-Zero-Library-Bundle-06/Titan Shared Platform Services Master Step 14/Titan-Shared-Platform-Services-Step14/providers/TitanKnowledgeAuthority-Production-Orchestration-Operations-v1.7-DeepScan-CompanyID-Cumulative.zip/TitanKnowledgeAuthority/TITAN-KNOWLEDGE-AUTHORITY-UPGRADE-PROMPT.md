# Titan Knowledge Authority — Production Upgrade Handoff

PLAN_ID: `0db30859-a499-45ba-8303-dcde2a2cc2c8`
Current release: `0.5.0-alpha.4`
Blueprint: Titan Extension Blueprint v4.2.1 Step 11
Installer: 1.7.8

## Global rules
Preserve working code and installer identity. Knowledge Authority owns trusted knowledge evidence, provenance, immutable versions, jurisdiction/applicability and contradictions; it must not own risk, assurance, autonomy, workflow state, business records or command execution. Cross-domain writes are forbidden. LLMs may not assign source authority or resolve equal-rank authority conflicts. Offline execution may never increase authority.

## Pass 1 completed — Blueprint rebase
Installer 1.7.8 root packaging, canonical manifest schema 2.2, the `intelligence-engine` + `knowledge-authority` profile, Step-11 runtime schemas and canonical governance/ownership/data/security contracts are in place.

## Pass 2 completed — Canonical Knowledge Domain Foundation
Normalized durable models/tables exist for KnowledgeSource, immutable KnowledgeSourceVersion, KnowledgeDocument, KnowledgeSection, KnowledgeClaim, KnowledgeJurisdiction and KnowledgeApplicability. The legacy source table is expanded additively. Source scope/authority/provenance/freshness metadata, SHA-256 evidence hashes, supersession, effective windows and trace/correlation/causation lineage are present.

## Pass 3 completed — Tenant, Platform and Jurisdiction Scope
Trusted read context is an explicit host boundary. Scoped repositories expose canonical platform rows, matching-tenant rows and explicitly granted jurisdiction rows. Public capability advertisement remains health-only.

## Pass 4 completed — Immutable Source Versioning
Source-version creation now goes through an explicit internal append contract. The write service serializes writes per source with a database transaction and row lock, allocates deterministic sequences/version keys, deduplicates same normalized content by SHA-256, derives tenant lineage from the canonical source, automatically supersedes only the latest predecessor, preserves byte-level raw evidence hashes/references, requires provenance and causal lineage, and rejects inactive/legacy/malformed sources. Existing versions remain protected against update/delete at the model boundary. Remote retrieval and scheduled refresh remain disabled.

## NEXT BUILD: Pass 5 — Document, Section & Citation Model
Strengthen stable document and section identities across immutable source versions. Add canonical citation value objects/envelopes linking source → version → document → section, section hierarchy integrity, deterministic section hashes and historical citation resolution. Keep claims, applicability and public `knowledge.resolve` behind later passes. Do not enable connectors or refresh yet.
