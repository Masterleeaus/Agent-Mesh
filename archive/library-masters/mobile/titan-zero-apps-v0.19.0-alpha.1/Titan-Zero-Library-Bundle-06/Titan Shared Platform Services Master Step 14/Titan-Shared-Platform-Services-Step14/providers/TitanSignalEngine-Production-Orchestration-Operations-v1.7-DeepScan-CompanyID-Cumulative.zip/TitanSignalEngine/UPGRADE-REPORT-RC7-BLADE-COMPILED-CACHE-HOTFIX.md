# Titan Signal Engine v0.20.0-rc.7 — Blade Compiled-Cache Isolation Hotfix

## Live-host evidence

rc.6 installed successfully, all 21 migrations remained applied, the ordinary user Signal row was absent, and **Signal Engine** appeared in Super Admin. Opening the page still raised `Unable to locate a class or view for component [layouts.app]`.

## Root cause

The rc.6 ZIP contains no `<x-layouts.app>` in either shipped Blade view; both extend `panel.layout.app`. The live error therefore came from Laravel continuing to execute an older compiled rc.5 view in `storage/framework/views`. Archive/deployment mtimes can leave that compiled PHP newer than the replaced source file, so Laravel does not necessarily recompile an unversioned view after an extension ZIP upgrade.

## Fix

- Controllers now render `titan-signal-engine::admin-rc7` and `titan-signal-engine::index-rc7`.
- Versioned Blade source files guarantee new compiled-cache keys.
- Provider boot performs a targeted cleanup of only the legacy Signal compiled view paths and only when their compiled PHP still contains `layouts.app`.
- Signal does **not** call global `view:clear`; other Titan/MagicAI compiled views are untouched.
- No migration, schema, event-store, delivery, correlation, Pulse, anomaly, retention, or navigation semantic change.

## Immediate operator workaround

`php artisan view:clear` would also clear the stale host cache on rc.6, but rc.7 removes the need to rely on a manual global cache clear and prevents this exact stale-path reuse for the current release.
