# Titan Financial Engine 0.4.0

Titan Financial Engine upgrades the former Discount Manager into a deterministic, auditable financial calculation, pricing and commercial quoting layer for Titan/WorkCore.

## Installer contract

- Schema: `titan-extension-v1`
- Folder: `TitanFinancialEngine`
- Provider: `App\Extensions\TitanFinancialEngine\System\TitanFinancialEngineServiceProvider`
- Migrations: enabled
- ZIP root: `extension.json`, `System/`, `database/`, `resources/`, `tests/`, `docs/`

## 17 registered calculation engines

1. `pricing`
2. `quote_estimate`
3. `labour_rate`
4. `job_costing`
5. `margin_profitability`
6. `discount_promotion`
7. `tax`
8. `inventory_materials_cost`
9. `asset_fleet_equipment_cost`
10. `recurring_pricing`
11. `payment_settlement_cost`
12. `commission_incentive`
13. `finance_instalment`
14. `forecast_cash_flow`
15. `break_even_scenario`
16. `procurement_landed_cost`
17. `formula_rules`

## v0.4 Financial Assistants UX

### Company-user sidebar

Parent: **Financial Assistants**

- All Assistants
- Quotes
- Create Quote
- Price Books
- Rate Cards
- Margin Rules
- Settings

The semantic definitions live in `System/Navigation/FinancialNavigation.php` and are registered through Blueprint/Titan `MenuContributionRegistry` when available.

For MagicAI hosts that use the verified database-backed `menus` schema, migrations `2026_08_09_000006_sync_financial_navigation_into_magicai_menus.php` and `2026_08_09_000007_upgrade_financial_assistants_navigation.php` idempotently synchronise/upgrade the user hierarchy and regenerate the host menu cache when supported.


### Guided assistant workspaces

Every registered engine now has a clickable route under `/dashboard/titan-financial-engine/assistants/{engine}`. The launcher groups assistants into Pricing & Quotes, Costs & Resources, Profit & Decisions, and Payments & Finance. Each assistant has a distinct icon, plain-English fields, formatted results and an optional calculation trace.

Complex internal payloads are hidden behind guided adapters:

- Materials Cost turns quantity/unit-cost/waste/pack fields into the engine material array.
- Cash Flow Forecast turns three simple periods into the engine period schedule.
- Formula Assistant turns Value A / Value B / operation into the structured no-`eval` formula contract.

### Super Admin sidebar

Parent: **Titan Financial Engine**

- Overview
- Promotions & Discounts
- Settings

Admin definitions are contributed through the Blueprint/Titan `ContributionRegistry` on `navigation.admin`. Database fallback rows are only synchronised when the host `menus` table has an explicit `is_admin` column, preventing admin navigation from leaking into normal user menus on older schemas.

See `docs/MENU-AND-SETTINGS.md` for compatibility details.

## Company Settings

`/dashboard/titan-financial-engine/settings`

Company-owned settings persist in `financial_settings` and cover:

- enable/disable Financial Engine for the company
- default currency
- money decimal presentation precision
- tax/GST label and default rate
- tax-inclusive default
- quote validity period
- Good / Better / Best default margins
- default deposit percentage
- customer-acceptance default
- quote prefix, next sequence and number padding
- approval margin threshold
- hard-block margin floor
- maximum discount without approval
- Jobs / Titan Gear / Titan Pay handoff switches

Company Settings become read-only when Super Admin disables company overrides.

## Super Admin Settings

`/dashboard/admin/titan-financial-engine/settings`

Platform controls include:

- global Financial Engine enabled state
- allow/disallow company overrides
- platform currency and tax defaults
- enable/disable each of the 17 calculation engines
- calculation audit persistence
- mandatory company-context governance
- manual price override policy
- platform availability for Jobs / Titan Gear / Titan Pay handoffs

Platform settings are not decorative: the calculation endpoint rejects disabled engines, global/company disable states block quote/calculation operation, audit persistence obeys governance, and company defaults inherit the platform currency/tax baseline.

## Commercial layer

### Company-user workspace

Mounted under `/dashboard/titan-financial-engine`:

- Quote list
- Quote Builder
- Good / Better / Best option generation
- Server-backed live quote simulation
- Quote option selection
- Price Book catalog loading
- Rate Card catalog loading
- Jobs / Titan Gear / Titan Pay hand-off JSON
- Direct calculation endpoint

Quote Builder uses company settings for currency, tax, validity, margin defaults and quote numbering. When no explicit Margin Policy is selected, company approval settings become the authoritative fallback.

### Super-admin/configuration workspace

Mounted under `/dashboard/admin/titan-financial-engine`:

- Financial Assistants dashboard
- Price Books
- Price Book items
- Rate Cards
- Rate Card items
- Margin policies
- Quote approval
- Promotions & Discounts
- Platform Settings
- Engine catalog and calculation endpoint

## Quote model

A quote stores:

- company/customer/job context
- price-book/rate-card/margin-policy references
- line-item cost inputs
- immutable quote versions
- Good / Better / Best options
- tax, gross profit and gross margin
- selection and approval state
- integration source references

The commercial services round document money to cents between sell-price, discount, tax and total stages while the core `Decimal` object retains six-decimal fixed-point arithmetic.

## Margin governance

`MarginApprovalService` supports:

- approved quotes above the approval threshold
- `approval_required` below the approval threshold
- hard blocking below the configured floor
- maximum safe discount calculation
- maximum-discount escalation

Explicit company Margin Policies override company Settings for the applicable quote. When no Margin Policy exists, Settings are the fallback authority.

## Price Books

Price Book items can store service/product/labour/equipment type, unit and cost, fixed sell price, pricing method, target margin, markup, tax rate, minimum price, maximum discount and effective dates.

## Rate Cards

Rate Card items can store role/skill, unit, internal cost rate, customer charge rate, overtime/weekend/public-holiday/after-hours multipliers, minimum units, call-out fees and travel rates.

## Jobs / Titan Gear / Titan Pay integration

The extension deliberately does not foreign-key external Titan modules. It exposes a stable `titan-financial-handoff-v1` payload and Laravel events.

Handoff sections:

- `jobs`: quote, customer, job, option, margin and total
- `gear`: material reservation requirements for quote lines sourced from `titan_gear`
- `pay`: reference, currency, subtotal, tax, amount and payment readiness

Company and platform integration switches filter disabled handoff sections.

Events:

- `FinancialQuoteCreated`
- `FinancialQuoteOptionSelected`
- `FinancialQuoteApproved`

## Database tables

Core:

- `financial_calculation_runs`
- `financial_calculation_steps`
- `financial_price_books`
- `financial_rate_cards`
- `financial_formula_rules`

Commercial:

- `financial_price_book_items`
- `financial_rate_card_items`
- `financial_margin_policies`
- `financial_quotes`
- `financial_quote_versions`
- `financial_quote_options`
- `financial_quote_lines`

Configuration:

- `financial_settings`

Legacy Discount Manager migrations are retained, with decimal discount storage on fresh installs.

## Core principles

- No binary floating-point arithmetic in financial decision logic.
- Every calculation context requires a positive `company_id`.
- Authenticated company boundaries reject mismatched company IDs.
- Calculation and quote inputs/outputs can be persisted for auditability.
- Formula execution is structured and whitelisted; it does not use `eval`.
- AI may prepare inputs or explain results, but deterministic services remain authoritative for money.
- Navigation compatibility is fail-open and must never prevent provider boot or extension migration.

## Framework-independent tests

```bash
php tests/run.php
```

The suite covers all 17 engines, decimal arithmetic, guided assistant metadata/adapters, clickable assistant routes, quote costing, margin governance, Good/Better/Best generation, catalog mapping, Jobs/Gear/Pay handoffs, menu contracts, user/admin route separation, settings wiring, host menu synchronisation safety and settings governance.
