<?php
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Contracts\PipelineRepositoryContract; use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class PipelineController extends Controller
{
    public function __construct(private PipelineRepositoryContract $pipelines, private \App\Extensions\Crm\System\Governance\CrmHumanMutationGateway $mutations) {}
    public function index(Request $r){$records=$this->pipelines->list((int)$r->user()->id);return $r->expectsJson()?response()->json(['data'=>$records]):view('crm::list',['title'=>'Pipelines','records'=>$records]);}
    public function store(Request $r){$data=$r->validate(['name'=>'required|string|max:160','key'=>'nullable|string|max:80','is_default'=>'nullable|boolean','stages'=>'nullable|array|min:2|max:30','stages.*.name'=>'required_with:stages|string|max:160','stages.*.key'=>'nullable|string|max:80','stages.*.color'=>'nullable|string|max:9','stages.*.probability'=>'nullable|integer|min:0|max:100','stages.*.is_closed'=>'nullable|boolean','stages.*.is_won'=>'nullable|boolean']);return response()->json($this->mutations->execute($r,'crm.pipeline.create',$data),201);}
    public function board(Request $r,string $pipeline){return response()->json($this->pipelines->board((int)$r->user()->id,$pipeline));}
}
