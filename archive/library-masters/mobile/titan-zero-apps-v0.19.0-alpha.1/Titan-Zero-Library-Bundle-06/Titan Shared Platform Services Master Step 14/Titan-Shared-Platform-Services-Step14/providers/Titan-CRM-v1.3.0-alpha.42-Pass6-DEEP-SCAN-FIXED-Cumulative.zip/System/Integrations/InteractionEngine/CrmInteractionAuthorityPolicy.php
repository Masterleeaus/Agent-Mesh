<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\InteractionEngine;

use App\Extensions\Crm\System\Integrations\TitanAutonomy\CrmAutonomyDecisionPort;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

/**
 * CRM does not own autonomy. This policy asks Titan Autonomy for an authority
 * decision and fails closed to human approval when the external engine is absent.
 */
final class CrmInteractionAuthorityPolicy
{
    private const RESTRICTIVE_MODES = ['earned','assist','approval'];

    public function __construct(private readonly CrmAutonomyDecisionPort $autonomy) {}

    public function mode(): string
    {
        $mode=(string)config('crm.interaction.authority_mode','earned');
        if($mode==='autonomous')return 'earned';
        return in_array($mode,self::RESTRICTIVE_MODES,true)?$mode:'earned';
    }

    public function workflowKey(string $capability): string
    {
        return $this->autonomy->workflowKey($capability);
    }

    public function mayAiComplete(string $capability, ?string $workflowKey=null): bool
    {
        if(in_array($this->mode(),['assist','approval'],true))return false;
        if($this->alwaysApproval($capability))return false;
        $userId=(int)(CrmCompanyScope::actorUserId()??0);
        if($userId<1)return false;
        $tenant=(int)CrmCompanyScope::companyId($userId);
        $workflow=$workflowKey ?: $this->workflowKey($capability);
        $decision=$this->autonomy->decision($userId,$tenant,$capability,$workflow);
        return ($decision['ai_may_complete']??false)===true && ($decision['human_approval_required']??true)!==true;
    }

    public function alwaysApproval(string $capability): bool
    {
        return in_array($capability,(array)config('crm.interaction.always_approval',[]),true);
    }

    /** @return array<string,mixed> */
    public function decision(string $capability, ?string $workflowKey=null): array
    {
        $userId=(int)(CrmCompanyScope::actorUserId()??0);
        $workflow=$workflowKey ?: $this->workflowKey($capability);
        if($userId<1){
            return ['mode'=>$this->mode(),'capability'=>$capability,'workflow_key'=>$workflow,'current_level'=>'suggest','next_level'=>null,'risk'=>null,'platform_gate_eligible'=>false,'ai_may_complete'=>false,'human_approval_required'=>true,'reason_codes'=>['ACCOUNTABLE_ACTOR_REQUIRED']];
        }
        $tenant=(int)CrmCompanyScope::companyId($userId);
        $external=$this->autonomy->decision($userId,$tenant,$capability,$workflow);
        $may=!in_array($this->mode(),['assist','approval'],true)&&!$this->alwaysApproval($capability)&&($external['ai_may_complete']??false)===true;
        return array_replace($external,[
            'mode'=>$this->mode(),
            'capability'=>$capability,
            'workflow_key'=>$workflow,
            'ai_may_complete'=>$may,
            'human_approval_required'=>!$may,
        ]);
    }
}
