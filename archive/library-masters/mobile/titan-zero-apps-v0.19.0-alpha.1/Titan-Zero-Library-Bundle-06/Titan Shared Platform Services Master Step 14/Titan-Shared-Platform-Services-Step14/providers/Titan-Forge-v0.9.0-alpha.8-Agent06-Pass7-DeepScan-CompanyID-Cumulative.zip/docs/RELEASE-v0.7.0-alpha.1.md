# Titan Forge v0.7.0-alpha.1 — AI Core Planning and Sandboxed AI Generation Boundary

This release implements Forge roadmap Passes 16–17 on the Forge side.

## Pass 16

- Titan AI Core typed planning adapter.
- Trusted Forge context mapped into AI Core `ExecutionIntent` / `RuntimeContext`.
- Exact context-return verification.
- AI Core validation must pass before a plan is usable.
- Typed AI Core steps deterministically map to Forge `BuildPlan`.
- AI plan source/runtime/validator provenance is persisted immutably.
- Current AI Core v0.3.0 is correctly reported as planning-blocked because its DAG validator is not implemented.

## Pass 17

- AI artifact proposal contract.
- Sandbox-only AI artifact writer.
- Per-build planner/model/hash provenance.
- AI generation-manifest validation.
- Hidden chain-of-thought persistence rejection.
- Existing validator -> Shield -> Risk -> Council/Governance -> release-candidate pipeline retained.
- Production AI artifact gateway remains fail-closed until AI Core publishes the owning contract.

Forge continues to have no direct deployment authority and no direct model-provider network dependency.
