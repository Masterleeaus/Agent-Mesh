<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Models;

use Illuminate\Database\Eloquent\Model;
use App\Extensions\TitanModelCouncil\System\Models\Concerns\HasCanonicalCompanyIdCompatibility;

final class CouncilDecisionRecord extends Model
{
    use HasCanonicalCompanyIdCompatibility;

    protected $table = 'titan_model_council_decisions';
    protected $guarded = [];

    protected $casts = [
        'company_id' => 'integer',
        'company_id' => 'integer',
            'tenant_company_id' => 'integer',
        'trigger_metadata' => 'array',
        'risk_engine_available' => 'boolean',
        'preflight_risk_payload' => 'array',
        'postflight_risk_payload' => 'array',
        'strong_contradiction' => 'boolean',
        'requires_escalation' => 'boolean',
        'payload' => 'array',
    ];
}
