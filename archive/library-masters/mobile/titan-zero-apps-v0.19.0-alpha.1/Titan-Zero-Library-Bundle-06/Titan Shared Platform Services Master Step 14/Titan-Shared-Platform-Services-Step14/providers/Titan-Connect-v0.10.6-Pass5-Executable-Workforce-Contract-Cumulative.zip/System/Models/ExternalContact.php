<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

final class ExternalContact extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use HasUuids;
    use SoftDeletes;

    protected $table = 'ext_titan_connect_external_contacts';
    protected $fillable = ['uuid', 'company_id', 'provider', 'external_contact_ref', 'display_name', 'email', 'phone', 'avatar', 'country', 'ip_address', 'linked_entity_type', 'linked_entity_id', 'metadata'];
    protected $casts = ['metadata' => 'array'];

    public function uniqueIds(): array { return ['uuid']; }
    public function threads(): HasMany { return $this->hasMany(ExternalThread::class, 'external_contact_id'); }
    public function getRouteKeyName(): string { return 'uuid'; }

}
