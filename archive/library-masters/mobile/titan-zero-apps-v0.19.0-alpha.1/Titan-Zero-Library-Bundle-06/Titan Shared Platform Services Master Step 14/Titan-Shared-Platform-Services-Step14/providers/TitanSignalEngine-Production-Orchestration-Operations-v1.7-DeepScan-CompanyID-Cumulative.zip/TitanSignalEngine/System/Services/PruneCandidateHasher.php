<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use InvalidArgumentException;

final class PruneCandidateHasher
{
    /** @param list<string> $eventIds */
    public function hash(string $scope, ?int $tenantCompanyId, array $eventIds): string
    {
        if (! in_array($scope, ['tenant', 'system'], true)) {
            throw new InvalidArgumentException('Unsupported Signal prune scope.');
        }
        if ($scope === 'tenant' && $tenantCompanyId === null) {
            throw new InvalidArgumentException('Tenant prune candidate hash requires tenant_company_id.');
        }
        if ($scope === 'system' && $tenantCompanyId !== null) {
            throw new InvalidArgumentException('System prune candidate hash cannot include tenant_company_id.');
        }
        $ids = array_values(array_unique(array_map('strval', $eventIds)));
        sort($ids, SORT_STRING);
        return hash('sha256', json_encode([
            'scope' => $scope,
            'tenant_company_id' => $tenantCompanyId,
            'event_ids' => $ids,
        ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }
}
