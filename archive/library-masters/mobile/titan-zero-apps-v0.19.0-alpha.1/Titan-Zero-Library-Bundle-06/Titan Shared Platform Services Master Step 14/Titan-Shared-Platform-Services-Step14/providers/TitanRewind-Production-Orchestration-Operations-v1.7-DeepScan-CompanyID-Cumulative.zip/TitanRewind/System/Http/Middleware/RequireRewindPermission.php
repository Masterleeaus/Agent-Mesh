<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Http\Middleware;

use App\Extensions\TitanRewind\System\Security\RewindAuthorization;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class RequireRewindPermission
{
    public function __construct(private RewindAuthorization $authorization) {}

    public function handle(Request $request, Closure $next, string $permission): Response
    {
        try {
            $this->authorization->assertActorPermission($request->user(), $permission);
        } catch (\RuntimeException $e) {
            abort(403, $e->getMessage());
        }
        return $next($request);
    }
}
