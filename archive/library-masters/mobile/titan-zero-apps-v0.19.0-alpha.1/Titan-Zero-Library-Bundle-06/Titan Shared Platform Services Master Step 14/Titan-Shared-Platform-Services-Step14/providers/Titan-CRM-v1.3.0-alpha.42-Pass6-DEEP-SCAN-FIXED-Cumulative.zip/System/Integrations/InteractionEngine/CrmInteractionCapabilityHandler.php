<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Integrations\InteractionEngine;
use App\Extensions\Crm\System\Governance\CrmCommandBusGateway;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

/** Executes only inside an already trusted CRM company context; payload tenant identifiers are ignored. */
final class CrmInteractionCapabilityHandler
{
    public function __construct(private CrmCommandBusGateway $commands,private CrmCompanyScope $companyScope){}
    public function handle(string $capability,array $payload): array
    {
        $this->companyScope->current(); // authenticated/bound server context or fail closed
        unset($payload['company_id'],$payload['tenant_id']);
        return $this->commands->request($capability,$payload,(string)($payload['_context']['source']??'interaction'));
    }
}
