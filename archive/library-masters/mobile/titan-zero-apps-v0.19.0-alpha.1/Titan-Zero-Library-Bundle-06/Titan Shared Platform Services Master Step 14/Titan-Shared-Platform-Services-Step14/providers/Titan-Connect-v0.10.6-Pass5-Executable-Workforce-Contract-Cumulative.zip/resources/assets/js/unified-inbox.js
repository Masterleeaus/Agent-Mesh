(() => {
  const root = document.getElementById('titan-connect-unified-inbox');
  if (!root) return;
  const list = root.querySelector('[data-role="unified-list"]');
  const count = root.querySelector('[data-role="unified-count"]');
  const status = root.querySelector('[data-role="unified-status"]');
  const mode = root.dataset.mode || 'unified';

  const escape = (value) => String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));
  const load = async () => {
    try {
      const response = await fetch(`${root.dataset.inboxUrl}?limit=100`, {credentials:'same-origin', headers:{Accept:'application/json'}});
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.message || 'Unable to load inbox.');
      let items = payload.data || [];
      if (mode === 'team') items = items.filter(item => item.source === 'internal');
      count.textContent = String(items.length);
      list.replaceChildren();
      if (!items.length) {
        list.innerHTML = '<div class="tc-empty">No conversations in this queue.</div>';
        return;
      }
      items.forEach(item => {
        const article = document.createElement('article');
        article.className = 'tc-thread-card';
        article.innerHTML = `<div class="tc-thread-card__title"><strong>${escape(item.title || item.provider || 'Conversation')}</strong><span class="tc-badge">${escape(item.source)}</span></div><small>${escape(item.provider || 'team')} · ${Number(item.unread_count || 0)} unread</small><p>${escape(item.preview || '')}</p>`;
        if (item.source === 'external') {
          article.tabIndex = 0;
          article.role = 'link';
          article.addEventListener('click', () => { window.location.href = root.dataset.externalUrl; });
        }
        list.append(article);
      });
    } catch (error) {
      status.textContent = error.message;
      status.classList.add('tc-status--error');
    }
  };
  load();
})();
