<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use App\Extensions\Crm\System\Contracts\SalesDocumentRepositoryContract;
use App\Extensions\Crm\System\Services\{CrmAnalyticsService, CrmPresentationService, CrmTimelineService, CrmViewDataService, SalesDocumentLifecycleService};
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Validation\ValidationException;

final class CrmPageController extends Controller
{
    public function __construct(
        private CrmViewDataService $views,
        private CrmPresentationService $presentations,
        private CrmTimelineService $timeline,
        private SalesDocumentRepositoryContract $sales,
        private CrmAnalyticsService $analytics,
        private SalesDocumentLifecycleService $salesLifecycle,
        private CrmHumanMutationGateway $mutations,
    ) {}

    public function dashboard(Request $request) { $uid=(int)$request->user()->id; return view('crm::dashboard.index',$this->views->overview($uid)); }
    public function companies(Request $request) { return view('crm::companies.index', ['companies' => $this->views->companies((int) $request->user()->id, $request->string('q')->toString()), 'q' => $request->string('q')->toString()]); }
    public function company(Request $request, string $company) { return view('crm::companies.show', $this->views->company((int) $request->user()->id, $company)); }
    public function contacts(Request $request) { return view('crm::contacts.index', ['contacts' => $this->views->contacts((int) $request->user()->id, $request->string('q')->toString()), 'q' => $request->string('q')->toString()]); }
    public function contact(Request $request, string $contact) { return view('crm::contacts.show', $this->views->contact((int) $request->user()->id, $contact)); }
    public function pipeline(Request $request, string $pipeline) { return view('crm::pipelines.board', ['pipeline' => $this->views->pipeline((int) $request->user()->id, $pipeline)]); }
    public function deal(Request $request, string $deal) { return view('crm::deals.show', $this->views->deal((int) $request->user()->id, $deal)); }
    public function timeline(Request $request, string $subjectType, string $subjectPublicId) { return view('crm::timeline.index', ['subjectType' => $subjectType, 'subjectPublicId' => $subjectPublicId, 'timeline' => $this->timeline->forSubject((int) $request->user()->id, $subjectType, $subjectPublicId, 200)]); }
    public function reports(Request $request) { return view('crm::reports.index', $this->views->reports((int) $request->user()->id) + ['analytics' => $this->analytics->snapshot((int) $request->user()->id)]); }
    public function presentations(Request $request) { return view('crm::presentations.index', ['presentation' => $this->presentations->executiveSnapshot((int) $request->user()->id)]); }
    public function sales(Request $request, string $type) { return view('crm::sales.index', ['type' => $type, 'documents' => $this->views->salesList((int) $request->user()->id, $type)]); }
    public function salesShow(Request $request, string $type, string $document) { $data = $this->views->salesDocument((int) $request->user()->id, $type, $document); return view('crm::sales.show', ['type' => $type, 'allowedTransitions' => $this->salesLifecycle->allowedTransitions($type, (string) ($data['document']['status'] ?? ''))] + $data); }

    public function salesCreate(Request $request, string $type)
    {
        $this->assertEditableSalesType($type);
        return view('crm::sales.create', [
            'type' => $type,
            'financeAssistants' => [],
            'financeContext' => [],
        ]);
    }

    public function salesStore(Request $request, string $type)
    {
        $this->assertEditableSalesType($type);
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'number' => 'nullable|string|max:80',
            'currency' => 'nullable|string|size:3',
            'due_at' => 'nullable|date',
            'expires_at' => 'nullable|date',
            'pricing_rules_version' => 'nullable|string|max:80',
            'terms' => 'nullable|string|max:20000',
            'company_public_id' => 'nullable|string|size:26',
            'contact_public_id' => 'nullable|string|size:26',
            'source_quote_public_id' => 'nullable|string|size:26',
            'source_work_order_public_id' => 'nullable|string|size:26',
            'lines' => 'required|array|min:1|max:50',
            'lines.*.description' => 'required|string|max:255',
            'lines.*.quantity' => 'required|string|max:30',
            'lines.*.unit_price' => 'required|string|max:30',
            'lines.*.tax_rate' => 'nullable|string|max:20',
        ]);
        $data['lines'] = array_values(array_map(fn (array $line) => [
            'description' => $line['description'],
            'quantity_milli' => $this->scaled($line['quantity'], 3),
            'unit_price_minor' => $this->scaled($line['unit_price'], 2),
            'tax_rate_bps' => $this->scaled($line['tax_rate'] ?? '0', 2),
        ], array_filter($data['lines'], fn (array $line) => trim((string) ($line['description'] ?? '')) !== '')));
        if ($data['lines'] === []) {
            throw ValidationException::withMessages(['lines' => ['At least one line is required.']]);
        }
        unset($data['lines_input']);
        if(in_array($type,['proposals','estimates'],true)){
            $terms=trim((string)($data['terms']??''));
            if($terms!=='')$data['terms_snapshot']=['text'=>$terms];
            unset($data['terms'],$data['due_at']);
        }else{
            unset($data['expires_at'],$data['pricing_rules_version'],$data['terms']);
        }
        $record = in_array($type,['proposals','estimates'],true)
            ? $this->mutations->execute($request,'crm.quote.create',$data+['type'=>$type])
            : $this->mutations->execute($request,'crm.invoice.create',$data);
        return redirect()->route('dashboard.user.sales.documents.show', [$type, $record['public_id']]);
    }


    private function assertEditableSalesType(string $type): void
    {
        if (! in_array($type, ['proposals', 'estimates', 'invoices'], true)) {
            abort(404);
        }
    }

    private function scaled(string|int|float $value, int $digits): int
    {
        $text = trim((string) $value);
        if (! preg_match('/^\d+(?:\.\d+)?$/', $text)) {
            throw ValidationException::withMessages(['amount' => ['Enter a non-negative decimal value.']]);
        }
        [$whole, $fraction] = array_pad(explode('.', $text, 2), 2, '');
        $fraction = substr(str_pad($fraction, $digits, '0'), 0, $digits);
        return ((int) $whole * (10 ** $digits)) + (int) $fraction;
    }
}
