<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Http\Controllers;

use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Services\RewindComplianceExportService;
use App\Extensions\TitanRewind\System\Services\RewindCustodyService;
use App\Extensions\TitanRewind\System\Services\RewindEvidencePackageService;
use App\Extensions\TitanRewind\System\Services\RewindEvidenceStreamService;
use App\Extensions\TitanRewind\System\Services\RewindTenantContextResolver;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;

final class EvidenceController
{
    public function __construct(
        private RewindTenantContextResolver $tenants,
        private RewindEvidencePackageService $evidence,
        private RewindComplianceExportService $compliance,
        private RewindEvidenceStreamService $stream,
        private RewindCustodyService $custody,
    ) {}

    public function store(Request $request, string $traceId): RedirectResponse
    {
        $tenant = $this->tenant($request);
        $type = strtolower(trim((string) $request->input('package_type','audit')));
        abort_unless(in_array($type,['audit','compliance','forensic','incident','dispute'],true), 422, 'Unsupported Titan Rewind evidence package type.');
        $actor = $request->user()?->getAuthIdentifier();
        $caseId = $request->input('case_id');
        $package = $this->evidence->forTrace(
            RewindTraceQuery::fromArray(['tenant_company_id'=>$tenant,'trace_id'=>$traceId]),
            $type,
            is_numeric($caseId) ? (int) $caseId : null,
            is_numeric($actor) ? (int) $actor : null,
        );
        return redirect()->route('dashboard.user.titan.rewind.evidence.show',['packageUuid'=>$package->package_uuid]);
    }

    public function storeCase(Request $request, string $caseUuid): RedirectResponse
    {
        $tenant = $this->tenant($request);
        $type = strtolower(trim((string) $request->input('package_type','audit')));
        abort_unless(in_array($type,['audit','compliance','forensic','incident','dispute'],true), 422, 'Unsupported Titan Rewind evidence package type.');
        $actor = $request->user()?->getAuthIdentifier();
        $package = $this->evidence->forCase($tenant, $caseUuid, $type, is_numeric($actor) ? (int) $actor : null);
        return redirect()->route('dashboard.user.titan.rewind.evidence.show',['packageUuid'=>$package->package_uuid]);
    }

    public function show(Request $request, string $packageUuid): View
    {
        $tenant = $this->tenant($request);
        $package = RewindEvidencePackage::query()->where('tenant_company_id',$tenant)->where('package_uuid',$packageUuid)->firstOrFail();
        $actor = $request->user()?->getAuthIdentifier();
        $this->custody->record($package,'viewed',is_numeric($actor)?(int)$actor:null);
        $decoded = $this->evidence->decoded($package);
        if (($decoded['verified'] ?? false) === true) $this->custody->record($package,'verified',is_numeric($actor)?(int)$actor:null);
        return view('titan-rewind::evidence', ['package'=>$package,'decoded'=>$decoded]);
    }

    public function download(Request $request, string $packageUuid): Response
    {
        $tenant = $this->tenant($request);
        $package = RewindEvidencePackage::query()->where('tenant_company_id',$tenant)->where('package_uuid',$packageUuid)->firstOrFail();
        $actor = $request->user()?->getAuthIdentifier();
        $compliance = $package->package_type === 'compliance';
        // Validate the streaming export before recording custody so a failed verification is never logged as a successful export.
        $chunks = $this->stream->chunks($package, $compliance);
        $chunks->rewind();
        $this->custody->record($package,$compliance ? 'exported' : 'downloaded',is_numeric($actor)?(int)$actor:null);
        return new StreamedResponse(function () use ($chunks): void {
            while ($chunks->valid()) { echo $chunks->current(); $chunks->next(); }
        }, 200, [
            'Content-Type'=>'application/json; charset=UTF-8',
            'Content-Disposition'=>'attachment; filename="titan-rewind-'.$package->package_type.'-'.$package->package_uuid.'.json"',
            'X-Content-Type-Options'=>'nosniff',
            'Cache-Control'=>'private, no-store, max-age=0',
        ]);
    }

    private function tenant(Request $request): int
    {
        $tenant = $this->tenants->forUser($request->user());
        abort_if($tenant === null, 403, 'Titan Rewind could not resolve an explicit tenant company for this account.');
        return $tenant;
    }
}
