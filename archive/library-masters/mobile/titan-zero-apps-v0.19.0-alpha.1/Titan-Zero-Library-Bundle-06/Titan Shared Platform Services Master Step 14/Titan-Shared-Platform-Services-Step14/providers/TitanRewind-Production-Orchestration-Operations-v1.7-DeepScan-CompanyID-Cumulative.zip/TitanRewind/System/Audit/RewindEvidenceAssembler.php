<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Audit;

use App\Extensions\TitanRewind\System\Support\CanonicalJson;

final class RewindEvidenceAssembler
{
    public function __construct(private CanonicalJson $canonical) {}

    public function assemble(
        string $packageType,
        array $trace,
        ?array $case = null,
        array $snapshots = [],
        array $integrityChecks = [],
        array $driftFindings = [],
        array $recoveryPlans = [],
        array $governanceReceipts = [],
        ?string $generatedAt = null,
        ?int $generatedById = null,
    ): array {
        $packageType = $this->packageType($packageType);
        $payload = [
            'schema_version'=>2,
            'package_type'=>$packageType,
            'trace'=>$trace,
            'case'=>$case,
            'snapshots'=>array_values($snapshots),
            'integrity_checks'=>array_values($integrityChecks),
            'drift_findings'=>array_values($driftFindings),
            'recovery_plans'=>array_values($recoveryPlans),
            'governance_receipts'=>array_values($governanceReceipts),
            'generated_at'=>$generatedAt,
            'generated_by_id'=>$generatedById,
            'authoritative_mutation'=>false,
            'hidden_chain_of_thought_included'=>false,
        ];
        $canonicalPayload = $this->canonical->encode($payload);
        // Evidence schema v2 hashes the exact persisted canonical payload so verification/export can be streamed.
        $contentHash = hash('sha256', $canonicalPayload);
        $integrityState = (string) ($trace['forensics']['integrity']['status'] ?? $trace['integrity_state'] ?? 'unknown');

        return [
            'content_hash'=>$contentHash,
            'canonical_payload'=>$canonicalPayload,
            'manifest'=>[
                'schema_version'=>2,
                'hash_algorithm'=>'sha256',
                'content_hash'=>$contentHash,
                'package_type'=>$packageType,
                'event_count'=>(int)($trace['event_count'] ?? count(is_array($trace['events'] ?? null) ? $trace['events'] : [])),
                'events_embedded_count'=>count(is_array($trace['events'] ?? null) ? $trace['events'] : []),
                'events_truncated'=>(bool)($trace['events_truncated'] ?? false),
                'streamable_hash'=>true,
                'dependency_count'=>count(is_array($trace['dependencies'] ?? null) ? $trace['dependencies'] : []),
                'snapshot_count'=>count($snapshots),
                'integrity_check_count'=>count($integrityChecks),
                'drift_finding_count'=>count($driftFindings),
                'recovery_plan_count'=>count($recoveryPlans),
                'governance_receipt_count'=>count($governanceReceipts),
                'integrity_state'=>$integrityState,
                'authoritative_mutation'=>false,
                'hidden_chain_of_thought_included'=>false,
            ],
            'payload'=>$payload,
        ];
    }

    private function packageType(string $value): string
    {
        $value = strtolower(trim($value));
        return in_array($value, ['audit','compliance','forensic','incident','dispute'], true) ? $value : 'audit';
    }
}
