# Titan Forge Workforce Assembly Boundary

## Authority

Titan AI Workforce owns the canonical workforce taxonomy, role identities, organisational relationships, role capability semantics and the complete 68 human-facing role registry. Titan Forge does not redefine that authority.

Forge consumes versioned role metadata and performs deterministic assembly, entitlement validation, isolated scaffolding and package validation. The bundled `roles-bootstrap.json` is intentionally a six-role Solo bootstrap subset only. Small Business, Growing and Enterprise compositions remain `null` and fail closed until their exact canonical Workforce mappings are imported.

## Entitlement boundary

Forge understands tier keys and maximum role counts only:

- Solo: 6 roles
- Small Business: 15 roles
- Growing: 30 roles
- Enterprise: 68 roles

Subscription prices, billing plans, trials, discounts and payment collection are not Forge concerns. Those remain owned by the platform billing/entitlement layer.

## Generation boundary

The initial workforce generator is deterministic and offline. It renders one generic schema-driven PHP stub plus canonical JSON role metadata into an isolated `storage/app/titan-forge/workspaces/<tenant>/<operation>/` workspace.

Generated role shells have `deployment_authority: none`. Forge does not copy generated files into the live `app/Extensions` tree and does not grant generated roles direct business-state mutation authority.

## Notification boundary

Forge emits an internal `ForgeBuildStatusChanged` lifecycle event. Public build-status webhooks are deliberately absent. Titan Signal is the intended cross-engine event plane; an adapter should bind this internal event to the exact installed Titan Signal contract once that runtime API is verified.

## UI compatibility

The Forge placeholder/history views intentionally avoid the unverified `<x-layouts.app>` component dependency. They render host-neutral Blade fragments until the exact installed MagicAI/Titan dashboard layout contract is verified.
