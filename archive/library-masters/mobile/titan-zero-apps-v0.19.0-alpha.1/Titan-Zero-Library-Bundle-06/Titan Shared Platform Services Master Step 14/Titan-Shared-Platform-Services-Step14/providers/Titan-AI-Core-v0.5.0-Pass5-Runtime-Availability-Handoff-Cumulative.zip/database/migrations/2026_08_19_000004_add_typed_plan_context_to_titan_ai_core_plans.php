<?php
declare(strict_types=1);
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('titan_ai_core_plans')) return;
        Schema::table('titan_ai_core_plans', function(Blueprint $table): void {
            if (!Schema::hasColumn('titan_ai_core_plans','operation_id')) $table->string('operation_id',191)->nullable()->after('plan_id')->index();
            if (!Schema::hasColumn('titan_ai_core_plans','correlation_id')) $table->string('correlation_id',191)->nullable()->after('trace_id')->index();
            if (!Schema::hasColumn('titan_ai_core_plans','causation_id')) $table->string('causation_id',191)->nullable()->after('correlation_id');
            if (!Schema::hasColumn('titan_ai_core_plans','root_causation_id')) $table->string('root_causation_id',191)->nullable()->after('causation_id');
            if (!Schema::hasColumn('titan_ai_core_plans','idempotency_key')) $table->string('idempotency_key',191)->nullable()->after('root_causation_id');
            if (!Schema::hasColumn('titan_ai_core_plans','plan_schema_version')) $table->string('plan_schema_version',16)->default('1.0')->after('schema_version');
            if (!Schema::hasColumn('titan_ai_core_plans','runtime_version')) $table->string('runtime_version',32)->nullable()->after('plan_schema_version');
        });
    }
    public function down(): void {
        if (!Schema::hasTable('titan_ai_core_plans')) return;
        Schema::table('titan_ai_core_plans', function(Blueprint $table): void {
            foreach (['operation_id','correlation_id','causation_id','root_causation_id','idempotency_key','plan_schema_version','runtime_version'] as $column) if (Schema::hasColumn('titan_ai_core_plans',$column)) $table->dropColumn($column);
        });
    }
};
