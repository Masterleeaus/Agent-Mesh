<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Http\Controllers;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskControlCentreContract;
use App\Extensions\TitanRiskEngine\System\Services\AuthenticatedTenantResolver;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

final class IndexController
{
    public function __invoke(Request $request, AuthenticatedTenantResolver $tenantResolver, RiskControlCentreContract $controlCentre): View
    {
        $tenantCompanyId = $tenantResolver->resolve($request->user());
        $capability = trim((string) $request->query('capability', '')) ?: null;
        $snapshot = $tenantCompanyId === null ? null : $controlCentre->snapshot($tenantCompanyId, $capability, 15);
        return view('titan-risk-engine::index', compact('snapshot', 'tenantCompanyId', 'capability'));
    }
}
