<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalEmitterIdentity;

interface SignalEmitterAuthorityContract
{
    public function issue(string $serviceId): SignalEmitterIdentity;

    public function assertTrusted(SignalEmitterIdentity $identity): void;
}
