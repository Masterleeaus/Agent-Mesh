<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$checks = 0;

$assert = static function (bool $condition, string $message) use (&$failures, &$checks): void {
    $checks++;
    if (! $condition) {
        $failures[] = $message;
    }
};

$renderer = $root.'/System/View/MagicAiDashboardRenderer.php';
$assert(is_file($renderer), 'Missing MagicAiDashboardRenderer.');
if (is_file($renderer)) {
    $src = file_get_contents($renderer) ?: '';
    $assert(str_contains($src, "make('panel.layout.app'"), 'Renderer must return panel.layout.app as the root view.');
    $assert(str_contains($src, 'incrementRender'), 'Renderer must preserve Blade stacks while rendering content.');
    $assert(str_contains($src, "startSection('content'"), 'Renderer must inject Titan Connect content into the host content section.');
}

$controllers = [
    $root.'/System/Http/Controllers/ChannelSettingsController.php',
    $root.'/System/Http/Controllers/InboxNavigationController.php',
    $root.'/System/Http/Controllers/OperatorInboxController.php',
    $root.'/System/Http/Controllers/VoiceCallController.php',
    $root.'/System/Http/Controllers/AdminChannelSettingsController.php',
];
foreach ($controllers as $file) {
    $src = file_get_contents($file) ?: '';
    $assert(str_contains($src, 'MagicAiDashboardRenderer'), basename($file).' must use the root dashboard renderer.');
}

$views = [
    'resources/views/admin/channels.blade.php',
    'resources/views/channels/index.blade.php',
    'resources/views/channels/show.blade.php',
    'resources/views/inbox/index.blade.php',
    'resources/views/inbox/unified.blade.php',
    'resources/views/settings/index.blade.php',
    'resources/views/voice/call.blade.php',
];
foreach ($views as $relative) {
    $src = file_get_contents($root.'/'.$relative) ?: '';
    $assert(! str_contains($src, "@extends('panel.layout.app')"), $relative.' must be a content partial, not own the host layout.');
    $assert(! str_contains($src, "@section('content')"), $relative.' must not open the content section itself.');
}

$routes = file_get_contents($root.'/routes/web.php') ?: '';
$assert(str_contains($routes, 'ViewSharedMiddleware::class'), 'Web routes must include MagicAI ViewSharedMiddleware.');
$assert(str_contains($routes, 'NewExtensionInstalled::class'), 'Web routes must include MagicAI NewExtensionInstalled middleware.');
$assert(str_contains($routes, "'updateUserActivity'"), 'Dashboard routes must include updateUserActivity.');
$assert(! str_contains($routes, "Route::view('settings'"), 'Settings page must go through the dashboard renderer controller.');

$manifest = json_decode(file_get_contents($root.'/extension.json') ?: '{}', true);
$publishes = $manifest['publishes'] ?? [];
$assert(in_array('titan-connect-assets', $publishes, true), 'extension.json must publish titan-connect-assets explicitly.');
$assert(in_array('titan-connect-config', $publishes, true), 'extension.json must publish titan-connect-config explicitly.');

if ($failures !== []) {
    fwrite(STDERR, "Titan Connect dashboard root-render contract FAILED\n");
    foreach ($failures as $failure) {
        fwrite(STDERR, " - {$failure}\n");
    }
    fwrite(STDERR, "Checks: {$checks}; failures: ".count($failures)."\n");
    exit(1);
}

echo "Titan Connect dashboard root-render contract passed: {$checks}/{$checks}\n";
