# Titan CRM Core v1.3.0-alpha.32 — Read Architecture & Search v2

- Removed AI OLTP fallback; AI context is projection-only.
- Added schema-versioned projection definitions and deterministic definition hashes.
- Added lead, quote/proposal, project and task projections.
- Added durable incremental rebuild checkpoints.
- Added projection dead-letter storage and replay command.
- Added `CrmSearchPort` with portable SQL projection adapter and replaceable external adapter binding.
- Added projection freshness SLA/lag evidence to read-store state and production health.
- Added `crm.search`, projection dead-letter read and retry capabilities.

Authority remains unchanged: projections/search are disposable derivative state and never write authoritative CRM business tables.
