<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
final class UpdateDealRequest extends FormRequest {
 public function authorize(): bool { return true; }
 public function rules(): array { return ['name'=>['sometimes','required','string','max:255'],'description'=>['sometimes','nullable','string'],'company_public_id'=>['sometimes','nullable','string','size:26'],'contact_public_id'=>['sometimes','nullable','string','size:26'],'value_minor'=>['sometimes','integer','min:0'],'currency'=>['sometimes','string','size:3'],'owner_user_id'=>['sometimes','nullable','integer','min:1'],'probability'=>['sometimes','integer','between:0,100'],'expected_close_date'=>['sometimes','nullable','date'],'metadata'=>['sometimes','nullable','array']]; }
}
