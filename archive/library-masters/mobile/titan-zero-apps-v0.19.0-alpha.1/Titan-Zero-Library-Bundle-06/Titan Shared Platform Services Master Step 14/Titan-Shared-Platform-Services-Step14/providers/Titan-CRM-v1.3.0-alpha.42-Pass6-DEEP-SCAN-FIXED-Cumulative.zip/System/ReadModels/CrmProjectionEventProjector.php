<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\ReadModels;

use Illuminate\Database\ConnectionInterface;

/** Projects committed CRM Core events into disposable Core-only CQRS rows. */
final class CrmProjectionEventProjector
{
    /** @var array<string,string> */
    private const TABLES=[
        'contacts'=>'crm_contacts','companies'=>'crm_companies','leads'=>'crm_leads','deals'=>'crm_deals',
        'activities'=>'crm_activities','proposals'=>'crm_proposals','estimates'=>'crm_estimates','invoices'=>'crm_invoices','projects'=>'crm_projects','tasks'=>'crm_tasks',
    ];

    public function __construct(
        private readonly ConnectionInterface $db,
        private readonly CrmReadProjectionRegistry $registry,
        private readonly CrmReadStorePort $readStore,
        private readonly CrmProjectionBuilder $builder,
    ) {}

    /** @return array<string,mixed> */
    public function projectEvent(array $event): array
    {
        $tenant=(int)($event['company_id']??0);$aggregate=strtolower(trim((string)($event['aggregate_type']??'')));$resourceId=trim((string)($event['aggregate_id']??''));$signalId=trim((string)($event['public_id']??''));
        if($tenant<1)return ['projected'=>0,'reason'=>'missing_tenant'];
        $table=self::TABLES[$aggregate]??null;$projected=0;$tombstone=false;
        if($table!==null&&$resourceId!==''&&$this->db->getSchemaBuilder()->hasTable($table)){
            $row=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$resourceId)->first();
            $rowArray=$row?(array)$row:[];$tombstone=$row===null||(($rowArray['deleted_at']??null)!==null);
            foreach($this->registry->forTable($table) as $definition){
                if($tombstone){$this->readStore->deleteResource($tenant,(string)$definition['projection_name'],(string)$definition['projection_version'],$resourceId,$signalId);$projected++;continue;}
                $payload=$this->selectPayload($rowArray,(array)$definition['fields']);$this->readStore->upsertResource($tenant,$definition,$resourceId,$payload,$signalId);$projected++;
            }
        }
        if(in_array($table,['crm_deals','crm_leads','crm_invoices'],true)){$this->builder->rebuildProjection($tenant,'owner_dashboard',$signalId);$projected++;}
        if($table!==null){$this->builder->rebuildProjection($tenant,'tenant_summary',$signalId);$projected++;}
        return ['projected'=>$projected,'aggregate_type'=>$aggregate,'resource_public_id'=>$resourceId,'tombstone'=>$tombstone];
    }

    private function selectPayload(array $row,array $fields): array { $out=[];foreach($fields as $field){$field=(string)$field;if(array_key_exists($field,$row))$out[$field]=$row[$field];}return $out; }
}
