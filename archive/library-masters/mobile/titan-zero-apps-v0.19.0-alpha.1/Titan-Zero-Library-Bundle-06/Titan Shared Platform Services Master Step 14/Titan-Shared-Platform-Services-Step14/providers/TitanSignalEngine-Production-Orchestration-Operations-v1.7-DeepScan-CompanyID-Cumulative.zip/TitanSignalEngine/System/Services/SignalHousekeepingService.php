<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class SignalHousekeepingService
{
    /** @return array<string,int> */
    public function run(int $limit = 5000): array
    {
        $limit = max(1, min($limit, 50000));
        $result = ['idempotency_keys' => 0, 'delivered_rows' => 0, 'dead_letters' => 0, 'resolved_anomalies' => 0, 'prune_claims' => 0, 'prune_previews' => 0];
        if (Schema::hasTable('titan_signal_idempotency_keys')) {
            $ids = DB::table('titan_signal_idempotency_keys')->whereNotNull('expires_at')->where('expires_at', '<=', now())->orderBy('id')->limit($limit)->pluck('id')->all();
            if ($ids !== []) $result['idempotency_keys'] = DB::table('titan_signal_idempotency_keys')->whereIn('id', $ids)->delete();
        }
        if (Schema::hasTable('titan_signal_deliveries')) {
            $deliveredCutoff = now()->subDays(max(1, (int) config('titan-signal-engine.housekeeping_delivered_days', 30)));
            $ids = DB::table('titan_signal_deliveries')->where('status', 'delivered')->where('delivered_at', '<=', $deliveredCutoff)->orderBy('id')->limit($limit)->pluck('id')->all();
            if ($ids !== []) $result['delivered_rows'] = DB::table('titan_signal_deliveries')->whereIn('id', $ids)->delete();
            $deadCutoff = now()->subDays(max(30, (int) config('titan-signal-engine.housekeeping_dead_letter_days', 180)));
            $ids = DB::table('titan_signal_deliveries')->where('status', 'dead_letter')->where('dead_lettered_at', '<=', $deadCutoff)->orderBy('id')->limit($limit)->pluck('id')->all();
            if ($ids !== []) $result['dead_letters'] = DB::table('titan_signal_deliveries')->whereIn('id', $ids)->delete();
        }

        if (Schema::hasTable('titan_signal_event_lifecycle') && Schema::hasColumn('titan_signal_event_lifecycle', 'prune_claim_expires_at')) {
            $result['prune_claims'] = DB::table('titan_signal_event_lifecycle')
                ->whereNull('pruned_at')->whereNotNull('prune_claim_token')->where('prune_claim_expires_at', '<=', now())
                ->limit($limit)->update(['prune_claim_token' => null, 'prune_claimed_at' => null, 'prune_claim_expires_at' => null, 'updated_at' => now()]);
        }
        if (Schema::hasTable('titan_signal_prune_previews')) {
            DB::table('titan_signal_prune_previews')->where('status', 'claimed')->whereNotNull('execution_expires_at')->where('execution_expires_at', '<=', now())
                ->limit($limit)->update(['execution_token' => null, 'execution_started_at' => null, 'execution_expires_at' => null, 'updated_at' => now()]);
            $cutoff = now()->subDays(max(1, (int) config('titan-signal-engine.housekeeping_prune_preview_days', 7)));
            $ids = DB::table('titan_signal_prune_previews')->whereIn('status', ['completed', 'invalidated', 'cancelled'])->where('updated_at', '<=', $cutoff)->orderBy('id')->limit($limit)->pluck('id')->all();
            if ($ids !== []) $result['prune_previews'] = DB::table('titan_signal_prune_previews')->whereIn('id', $ids)->delete();
        }
        if (Schema::hasTable('titan_signal_anomalies')) {
            $cutoff = now()->subDays(max(30, (int) config('titan-signal-engine.housekeeping_resolved_anomaly_days', 180)));
            $ids = DB::table('titan_signal_anomalies')->where('status', 'resolved')->where('resolved_at', '<=', $cutoff)->orderBy('id')->limit($limit)->pluck('id')->all();
            if ($ids !== []) $result['resolved_anomalies'] = DB::table('titan_signal_anomalies')->whereIn('id', $ids)->delete();
        }
        return $result;
    }
}
