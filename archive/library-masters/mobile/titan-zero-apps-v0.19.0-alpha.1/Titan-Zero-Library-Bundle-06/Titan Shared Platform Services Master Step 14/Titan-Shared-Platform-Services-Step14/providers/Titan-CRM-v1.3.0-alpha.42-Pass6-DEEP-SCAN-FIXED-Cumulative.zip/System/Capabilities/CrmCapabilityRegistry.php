<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Capabilities;

use InvalidArgumentException;

final class CrmCapabilityRegistry
{
    /** @var array<string,callable> */
    private array $handlers = [];
    /** @var array<string,array<string,mixed>> */
    private array $externalDefinitions = [];

    public function __construct(private readonly CrmCapabilityManifest $manifest) {}

    public function definitions(): array { return array_replace($this->manifest->definitions(), $this->externalDefinitions); }
    public function platformCapabilities(): array { return $this->manifest->platformCapabilities(); }
    public function definition(string $capability): array
    {
        $definition=$this->definitions()[$capability]??null;
        if(!$definition) throw new InvalidArgumentException("Unknown CRM capability: {$capability}");
        return $definition;
    }
    public function register(string $capability, callable $handler): void
    { $this->definition($capability); $this->handlers[$capability]=$handler; }
    /** @param array<string,mixed> $definition */
    public function declareExternal(string $capability,array $definition,callable $handler): void
    {
        foreach(['mode','permission','idempotent','description'] as $key) if(!array_key_exists($key,$definition)) throw new InvalidArgumentException("External capability {$capability} is missing {$key}.");
        if(!in_array((string)$definition['mode'],['read','write'],true)) throw new InvalidArgumentException("External capability {$capability} mode must be read or write.");
        $this->externalDefinitions[$capability]=$definition;
        $this->handlers[$capability]=$handler;
    }
    public function hasHandler(string $capability): bool { return isset($this->handlers[$capability]); }
    public function handler(string $capability): callable
    { if(!$this->hasHandler($capability)) throw new InvalidArgumentException("CRM capability is declared but not bound: {$capability}"); return $this->handlers[$capability]; }
}
