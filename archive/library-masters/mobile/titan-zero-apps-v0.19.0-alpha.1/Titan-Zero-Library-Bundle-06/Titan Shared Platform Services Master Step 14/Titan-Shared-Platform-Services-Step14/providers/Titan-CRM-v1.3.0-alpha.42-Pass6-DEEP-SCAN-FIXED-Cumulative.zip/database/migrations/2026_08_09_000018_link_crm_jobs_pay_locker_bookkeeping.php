<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('crm_invoices')) {
            Schema::table('crm_invoices', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_invoices','work_order_public_id')) $t->char('work_order_public_id',26)->nullable()->index();
            });
        }
        if (Schema::hasTable('crm_sales_document_lines')) {
            Schema::table('crm_sales_document_lines', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_sales_document_lines','public_id')) $t->char('public_id',26)->nullable()->unique();
                if (! Schema::hasColumn('crm_sales_document_lines','work_order_public_id')) $t->char('work_order_public_id',26)->nullable()->index();
                if (! Schema::hasColumn('crm_sales_document_lines','inventory_item_public_id')) $t->char('inventory_item_public_id',26)->nullable()->index();
                if (! Schema::hasColumn('crm_sales_document_lines','source_type')) $t->string('source_type',80)->nullable()->index();
                if (! Schema::hasColumn('crm_sales_document_lines','source_public_id')) $t->char('source_public_id',26)->nullable()->index();
                if (! Schema::hasColumn('crm_sales_document_lines','source_key')) $t->string('source_key',160)->nullable();
            });
            try { Schema::table('crm_sales_document_lines', fn(Blueprint $t) => $t->unique(['tenant_company_id','source_key'],'crm_sales_line_source_unique')); } catch (\Throwable) {}
        }
        if (Schema::hasTable('crm_products')) {
            Schema::table('crm_products', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_products','locker_inventory_item_public_id')) $t->char('locker_inventory_item_public_id',26)->nullable()->index();
                if (! Schema::hasColumn('crm_products','sku')) $t->string('sku',100)->nullable()->index();
                if (! Schema::hasColumn('crm_products','unit')) $t->string('unit',40)->nullable();
                if (! Schema::hasColumn('crm_products','cost_minor')) $t->bigInteger('cost_minor')->nullable();
                if (! Schema::hasColumn('crm_products','sale_price_minor')) $t->bigInteger('sale_price_minor')->nullable();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('crm_products')) foreach(['locker_inventory_item_public_id','sku','unit','cost_minor','sale_price_minor'] as $c) if(Schema::hasColumn('crm_products',$c)) Schema::table('crm_products',fn(Blueprint $t)=>$t->dropColumn($c));
        if (Schema::hasTable('crm_sales_document_lines')) {
            try { Schema::table('crm_sales_document_lines',fn(Blueprint $t)=>$t->dropUnique('crm_sales_line_source_unique')); } catch (\Throwable) {}
            foreach(['public_id','work_order_public_id','inventory_item_public_id','source_type','source_public_id','source_key'] as $c) if(Schema::hasColumn('crm_sales_document_lines',$c)) Schema::table('crm_sales_document_lines',fn(Blueprint $t)=>$t->dropColumn($c));
        }
        if (Schema::hasTable('crm_invoices') && Schema::hasColumn('crm_invoices','work_order_public_id')) Schema::table('crm_invoices',fn(Blueprint $t)=>$t->dropColumn('work_order_public_id'));
    }
};
