<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Contracts;

interface GovernanceDecisionEvidenceSourceContract
{
    public function key(): string;
    public function required(): bool;

    /** @return array<string,mixed> */
    public function decisionEvidence(int $tenantCompanyId, string $decisionId, array $context = []): array;
}
