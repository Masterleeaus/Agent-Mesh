<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Contracts;

interface KnowledgeAuthorityContract
{
    public function health(): array;
}
