# Titan Rewind v0.6.0 — Comparative Replay & Product Surface Transplant

This pass completes the donor/product extraction phase while preserving the modern v0.2-v0.5 tenant, trace, forensic, audit and Governance architecture.

## Added

- deterministic structural `counterfactual`, `model-compare`, `policy-compare`, and `knowledge-compare` replay modes
- safe event-scoped counterfactual overrides with an explicit allowlist of Rewind decision metadata
- canonical comparison hashes and impacted-event inventories
- historical-artifact resolver registry with fail-honest `ARTIFACT_UNAVAILABLE` reproducibility
- hard rejecting replay command gateway (`REPLAY_BOUNDARY_VIOLATION`)
- replay-run persistence for mutation policy, network policy, deterministic seed, reproducibility, result hash and decision-reexecution truth state
- deterministic guided Rewind assistant using the useful donor specialist taxonomy without external AI calls
- tenant-safe Rewind analytics over current Rewind-owned tables
- internal Rewind tool catalogue with runtime-only tenant context
- user UI for structural counterfactual/model/policy/knowledge comparisons

## Critical truthfulness boundary

v0.6 comparison is a deterministic structural projection of historical Rewind data. It does **not** claim that an old/new model, policy or knowledge engine was actually re-executed. Every result records:

- `mutation_attempted=false`
- `mutation_allowed=false`
- `decision_reexecution_performed=false`
- `execution_semantics=structural_projection_only`

Exact historical executable replay remains dependent on immutable historical-artifact/model resolvers and governed replay evaluators supplied by the wider Titan runtime.

## Donor code not imported

- direct model/provider calls
- donor correction/execution services
- legacy `company_id`
- wildcard Eloquent observers
- Nwidart `Modules\\TitanRewind` namespaces
- simplistic tenant-input AI tools
- fake automatic correction suggestions
