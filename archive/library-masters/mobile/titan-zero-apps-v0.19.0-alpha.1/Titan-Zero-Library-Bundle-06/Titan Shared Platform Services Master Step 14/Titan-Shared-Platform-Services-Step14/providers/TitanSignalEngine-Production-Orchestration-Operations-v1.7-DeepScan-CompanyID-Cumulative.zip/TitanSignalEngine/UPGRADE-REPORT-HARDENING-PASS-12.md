# Titan Signal Engine — Production Hardening Pass 12

## Release Candidate & Host Certification

Version: `0.20.0-rc.1`

This final planned hardening pass adds production-host certification tooling and corrects the root package manifest for Titan Installer 1.7.8.

### Added

- Installer 1.7.8 `titan-extension-v1` root `extension.json`.
- `SignalCertificationReport` machine-readable certification result.
- `SignalHostCertificationService` live host inspection.
- `titan:signal:certify` Artisan command.
- archive write/read/delete certification probe.
- live checks for PHP/Laravel/MySQL strict mode, owned tables, critical columns/indexes, migrations, bindings, routes, schedules, queue driver, archive storage and governed health.
- host integration test for the certification service.
- production-host certification runbook.
- explicit Blueprint Step03 root-manifest compatibility disclosure.

### Certification truth boundary

The release candidate is locally certified by standalone tests, PHP lint, Blueprint sidecar schema validation, package security scan, architecture scan, package checksums and ZIP integrity. The isolated archive environment does not contain the Titan Laravel/MySQL host, Composer or PHPUnit, so production-host certification is intentionally marked pending until the real host executes:

```bash
php artisan titan:signal:certify --strict --probe-writes --output=titan-signal-engine/certification/host.json
```

and the packaged host integration suite passes.
