<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$checks = 0;
$failures = [];
$assert = static function (bool $condition, string $message) use (&$checks, &$failures): void {
    ++$checks;
    if (!$condition) { $failures[] = $message; fwrite(STDERR, "FAIL: {$message}\n"); }
};

$required = [
    'System/Replay/RewindReplayRequest.php',
    'System/Replay/RewindStructuralComparisonEngine.php',
    'System/Replay/RejectingReplayCommandGateway.php',
    'System/Replay/RewindArtifactResolverRegistry.php',
    'System/Contracts/RewindHistoricalArtifactResolverContract.php',
    'System/AI/RewindToolCatalogue.php',
    'System/Services/RewindAssistantService.php',
    'System/Services/RewindAnalyticsService.php',
    'System/Http/Controllers/AssistantController.php',
    'database/migrations/2026_08_16_000006_add_titan_rewind_comparative_replay.php',
    'resources/views/assistant.blade.php',
];
foreach ($required as $file) $assert(is_file($root . '/' . $file), "Pass 4 file exists: {$file}");

$pure = [
    'System/Support/CanonicalJson.php',
    'System/Support/RewindPayloadSanitizer.php',
    'System/Reconstruction/RewindDiffService.php',
    'System/Contracts/RewindHistoricalArtifactResolverContract.php',
    'System/Replay/RewindReplayRequest.php',
    'System/Replay/RejectingReplayCommandGateway.php',
    'System/Replay/RewindArtifactResolverRegistry.php',
    'System/Replay/RewindVirtualClock.php',
    'System/Replay/RewindDeterministicSeed.php',
    'System/Replay/RewindStructuralComparisonEngine.php',
    'System/AI/RewindToolCatalogue.php',
    'System/Services/RewindAssistantService.php',
];
if (!array_filter($pure, static fn(string $f): bool => !is_file($root . '/' . $f))) {
    foreach ($pure as $file) require_once $root . '/' . $file;

    $sanitizer = new App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer(['password','token','secret']);
    $request = App\Extensions\TitanRewind\System\Replay\RewindReplayRequest::fromArray([
        'mode'=>'model-compare',
        'target_model'=>['provider'=>'openrouter','model'=>'candidate-model','version'=>'2'],
        'network_policy'=>'recorded-only',
        'deterministic_seed'=>'seed-1',
    ], $sanitizer);
    $assert($request->mode() === 'model-compare', 'model comparison mode validates');
    $assert($request->mutationPolicy() === 'deny', 'replay request hard-codes mutation deny');
    $assert($request->networkPolicy() === 'recorded-only', 'replay request preserves allowed network policy');

    $current = App\Extensions\TitanRewind\System\Replay\RewindReplayRequest::fromArray([
        'mode'=>'current-state',
        'current_state_overrides'=>['events'=>['aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'=>['policy_version'=>'current-policy']]],
    ], $sanitizer);
    $assert($current->mode() === 'current-state', 'current-state comparison mode validates');
    $assert($current->mutationPolicy() === 'deny', 'current-state comparison retains hard mutation denial');

    $hiddenRejected = false;
    try {
        App\Extensions\TitanRewind\System\Replay\RewindReplayRequest::fromArray([
            'mode'=>'counterfactual','counterfactual_overrides'=>['nested'=>['private_reasoning'=>'secret']],
        ], $sanitizer);
    } catch (InvalidArgumentException) { $hiddenRejected = true; }
    $assert($hiddenRejected, 'replay request rejects nested private reasoning');

    $invalidMode = false;
    try { App\Extensions\TitanRewind\System\Replay\RewindReplayRequest::fromArray(['mode'=>'production-write'], $sanitizer); }
    catch (InvalidArgumentException) { $invalidMode = true; }
    $assert($invalidMode, 'unsupported replay mode is rejected');

    $sandbox = new App\Extensions\TitanRewind\System\Replay\RejectingReplayCommandGateway();
    $assert($sandbox->mutationAllowed() === false, 'replay command gateway advertises mutation denied');
    $boundary = false;
    try { $sandbox->dispatch('invoice.update', ['invoice_id'=>4]); } catch (LogicException $e) { $boundary = str_contains($e->getMessage(), 'REPLAY_BOUNDARY_VIOLATION'); }
    $assert($boundary, 'replay command attempt throws boundary violation');

    $canonical = new App\Extensions\TitanRewind\System\Support\CanonicalJson();
    $diff = new App\Extensions\TitanRewind\System\Reconstruction\RewindDiffService();
    $registry = new App\Extensions\TitanRewind\System\Replay\RewindArtifactResolverRegistry();
    $engine = new App\Extensions\TitanRewind\System\Replay\RewindStructuralComparisonEngine($canonical, $diff, $registry, $sandbox);
    $trace = [
        'tenant_company_id'=>7,
        'trace_id'=>'11111111-1111-4111-8111-111111111111',
        'events'=>[
            ['event_id'=>'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','sequence'=>1,'event_type'=>'decision.created','source_engine'=>'titan-ai-core','decision_id'=>'d1','model_provider'=>'openrouter','model_name'=>'baseline-model','model_version'=>'1','policy_version'=>'p1','knowledge_version'=>'k1','risk_state'=>['overall'=>'medium'],'capability_name'=>'invoice.update'],
            ['event_id'=>'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','sequence'=>2,'event_type'=>'risk.assessed','source_engine'=>'titan-risk','decision_id'=>'d1','policy_version'=>'p1','risk_state'=>['overall'=>'high']],
        ],
        'forensics'=>['integrity'=>['status'=>'passed']],
    ];
    $model = $engine->compare($trace, $request);
    $assert(($model['mode'] ?? null) === 'model-compare', 'comparison result identifies model mode');
    $assert(($model['mutation_attempted'] ?? true) === false, 'comparison result reports zero mutation attempt');
    $assert(($model['decision_reexecution_performed'] ?? true) === false, 'structural comparison does not pretend to re-execute decisions');
    $assert(in_array('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', $model['impacted_event_ids'] ?? [], true), 'model comparison identifies impacted model event');
    $assert(($model['candidate']['events'][0]['model_name'] ?? null) === 'candidate-model', 'candidate projection applies target model');
    $assert(preg_match('/^[a-f0-9]{64}$/', (string)($model['result_hash'] ?? '')) === 1, 'comparison result has canonical sha256 hash');

    $cfReq = App\Extensions\TitanRewind\System\Replay\RewindReplayRequest::fromArray([
        'mode'=>'counterfactual',
        'counterfactual_overrides'=>[
            'events'=>[
                'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'=>['risk_state'=>['overall'=>'low'],'policy_version'=>'p2'],
            ],
        ],
    ], $sanitizer);
    $cf = $engine->compare($trace, $cfReq);
    $assert(($cf['candidate']['events'][0]['risk_state']['overall'] ?? null) === 'low', 'counterfactual applies safe event metadata override');

    $currentReq = App\Extensions\TitanRewind\System\Replay\RewindReplayRequest::fromArray([
        'mode'=>'current-state',
        'current_state_overrides'=>['events'=>['aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'=>['policy_version'=>'current-policy']]],
    ], $sanitizer);
    $currentResult = $engine->compare($trace, $currentReq);
    $assert(($currentResult['candidate']['events'][0]['policy_version'] ?? null) === 'current-policy', 'current-state comparison applies explicit current-state projection');
    $assert(($currentResult['decision_reexecution_performed'] ?? true) === false, 'current-state structural comparison does not claim decision re-execution');
    $assert(($cf['candidate']['events'][0]['policy_version'] ?? null) === 'p2', 'counterfactual applies policy override');
    $assert(count($cf['diff'] ?? []) > 0, 'counterfactual produces deterministic diff');

    $catalogue = new App\Extensions\TitanRewind\System\AI\RewindToolCatalogue();
    $tools = $catalogue->all();
    $ids = array_column($tools, 'id');
    foreach (['rewind.reconstruct_trace','rewind.compare_trace','rewind.verify_integrity','rewind.generate_evidence','rewind.propose_recovery'] as $id) {
        $assert(in_array($id, $ids, true), "tool catalogue exposes {$id}");
    }
    $tenantInputLeak = false;
    foreach ($tools as $tool) {
        if (isset($tool['input_schema']['properties']['tenant_company_id'])) $tenantInputLeak = true;
    }
    $assert(!$tenantInputLeak, 'tool schemas never accept tenant_company_id from AI/user input');

    $assistant = new App\Extensions\TitanRewind\System\Services\RewindAssistantService($catalogue);
    $why = $assistant->route('Why did this fail and what caused it?', ['trace_id'=>'11111111-1111-4111-8111-111111111111']);
    $assert(($why['specialist'] ?? null) === 'root-cause', 'assistant routes why/cause request to root-cause specialist');
    $compare = $assistant->route('Compare the old model with the new model', ['trace_id'=>'11111111-1111-4111-8111-111111111111']);
    $assert(($compare['specialist'] ?? null) === 'comparison', 'assistant routes comparison request to comparison specialist');
    $assert(in_array('rewind.compare_trace', $compare['tool_ids'] ?? [], true), 'comparison assistant recommends implemented compare tool');
}

$manifest = json_decode((string)file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$assert(($manifest['version'] ?? null) === '1.0.6', 'manifest version is 1.0.6');
foreach (['rewind.compare','rewind.replay.counterfactual','rewind.replay.current-state','rewind.compare.model','rewind.compare.policy','rewind.compare.knowledge','rewind.assistant','rewind.analytics'] as $cap) {
    $assert(in_array($cap, $manifest['capabilities'] ?? [], true), "manifest declares implemented {$cap}");
}

$provider = (string)file_get_contents($root . '/System/TitanRewindServiceProvider.php');
foreach (['RewindStructuralComparisonEngine::class','RewindArtifactResolverRegistry::class','RewindAssistantService::class','RewindAnalyticsService::class','RewindToolCatalogue::class'] as $needle) {
    $assert(str_contains($provider, $needle), "provider wires {$needle}");
}
$routes = (string)file_get_contents($root . '/routes/user.php');
$assert(str_contains($routes, 'AssistantController'), 'user routes expose guided assistant');
$assert(str_contains($routes, "replay.compare"), 'user routes expose comparative replay endpoint');

$systemCode = '';
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/System'));
foreach ($it as $file) if ($file->isFile() && $file->getExtension()==='php') $systemCode .= (string)file_get_contents($file->getPathname());
foreach (['Http::','curl_' . 'exec(','shell_' . 'exec(','exec(','Modules\\TitanRewind','eloquent.created: *','eloquent.updated: *'] as $forbidden) {
    $assert(!str_contains($systemCode, $forbidden), "Pass 4 runtime avoids {$forbidden}");
}
$assert(!str_contains($systemCode, "'decision_reexecution_performed'=>true"), 'runtime never falsely claims decision re-execution');

if ($failures !== []) {
    fwrite(STDERR, "\nCOMPARATIVE REPLAY VERIFICATION FAILED (".count($failures)." failures, {$checks} checks)\n");
    exit(1);
}
echo "\nCOMPARATIVE REPLAY VERIFICATION PASSED ({$checks} checks)\n";
