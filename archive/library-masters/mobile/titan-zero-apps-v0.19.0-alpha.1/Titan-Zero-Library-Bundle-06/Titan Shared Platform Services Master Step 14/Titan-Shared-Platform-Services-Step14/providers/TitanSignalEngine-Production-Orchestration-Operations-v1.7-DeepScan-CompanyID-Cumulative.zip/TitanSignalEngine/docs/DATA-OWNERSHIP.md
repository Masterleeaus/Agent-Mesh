# Data Ownership

Signal owns only Signal infrastructure state. `extension.manifest.json` is authoritative for the complete owned-table list.

Primary durable classes:

- immutable events plus immutable/versioned event-type registry definitions;
- idempotency leases;
- causal edges and trace profiles/evaluations;
- immutable/versioned subscription definitions, mutable quarantine/lifecycle runtime projection, and delivery ledger;
- Pulse projections;
- anomaly projections;
- lifecycle/legal-hold/privacy-overlay state;
- archive-batch and lifecycle-audit state.

Signal does **not** own CRM customers, jobs, invoices, workforce/domain entities, or external provider truth.

Data classifications are INTERNAL, CONFIDENTIAL and SENSITIVE. Retention is governed by explicit classes, legal holds and verified archive-before-prune.

- `titan_signal_delivery_redrives` — immutable delivery recovery audit records.
- `titan_signal_subscription_registry_state` — shared subscription-registry revision used for cache coherence.

## Transactional prune metadata

`titan_signal_prune_previews` is Signal-owned control-plane state. It stores exact prune candidate manifests, token hashes, candidate hashes, expiry and execution-lease state. It never stores plaintext preview tokens. Lifecycle rows own prune-claim state; archive batches own archive/prune execution state.
