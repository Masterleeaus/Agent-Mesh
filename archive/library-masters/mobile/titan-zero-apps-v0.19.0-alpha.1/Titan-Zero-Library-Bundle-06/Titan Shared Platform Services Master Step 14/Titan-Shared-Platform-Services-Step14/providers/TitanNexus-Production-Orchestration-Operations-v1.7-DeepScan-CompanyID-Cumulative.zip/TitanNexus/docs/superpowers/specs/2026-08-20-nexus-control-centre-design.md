# Titan Nexus Control Centre Design

## Scope
Pass 7 adds a read-first operational Control Centre on top of the existing Nexus v0.7.0 runtime. It does not add new authoritative mutation paths. Existing compile, validate, diff, recompile, provisioning, governance, Signal, and Rewind contracts remain the only execution authorities.

## Architecture
The UI reads tenant-owned compilation history through `CompilationRepositoryContract`; controllers do not query the database directly. A pure `NexusControlCentreService` converts domain aggregates into a redacted, deterministic read model. `TenantContextResolverContract` resolves the active company context from a configured public host contract or approved user attributes and fails closed when no positive tenant can be established.

The authenticated Control Centre exposes Overview, Business Profile, Compilations, Validation, Configuration Preview, History, Recompile/Diff, Provisioning Plans, and Provisioning Receipts. Compilation detail remains tenant-scoped by UUID. Admin diagnostics are read-only and use the same tenant boundary.

## UI and host compatibility
Views extend `panel.layout.app` for the current MagicAI/Titan host contract. Styling relies on host classes and CSS variables rather than hard-coded theme colors. Internal navigation uses named routes. A declarative Titan Interface contribution advertises the compilation object and read-only Control Centre views to Titan Interface Runtime; it declares no mutating actions.

## Security and privacy
No tenant ID is accepted from an unauthorised route parameter. User tenant context is resolved server-side. Control Centre payloads redact keys containing authorization, credential, password, secret, signature, token, api_key, access_key, refresh_token, private_key, or client_secret before rendering. Historical data is redacted at presentation time even if it predates semantic secret validation.

## Failure behaviour
Missing tenant context renders a non-sensitive unavailable state rather than querying unscoped data. Missing compilations render an empty state. A corrupt historical compilation is not expanded outside repository restoration behaviour. The read model limits history to 50 entries and lineage to 50 entries per request.

## Testing
Standalone tests cover tenant resolution, tenant-scoped read models, redaction, empty states, selected compilation detail, validation/diff/provisioning summaries, and route/interface declarations. Existing standalone regressions, PHP lint, JSON validation, Blueprint manifest/interface validation, package/architecture scans, migration immutability, Installer 1.7.8 integrity verification, and clean ZIP re-extraction remain release gates.
