<?php
namespace App\Extensions\Crm\System\Contracts;
interface PipelineRepositoryContract {
    public function list(int $userId): array;
    public function create(int $userId, array $data): array;
    public function board(int $userId, string $publicId): array;
}
