# Titan Forge Uninstall

The installer declares `preserve_data: true`. Uninstall removes extension code/config publication but retains Forge-owned durable build, validation and release evidence unless a separately authorized tenant/platform data-purge workflow is executed.

Generated workspace files under the Forge-owned storage path may be cleaned independently after evidence requirements are satisfied. Uninstall must not delete another extension's data or generated artifacts that have already been installed and become owned by another canonical domain.
