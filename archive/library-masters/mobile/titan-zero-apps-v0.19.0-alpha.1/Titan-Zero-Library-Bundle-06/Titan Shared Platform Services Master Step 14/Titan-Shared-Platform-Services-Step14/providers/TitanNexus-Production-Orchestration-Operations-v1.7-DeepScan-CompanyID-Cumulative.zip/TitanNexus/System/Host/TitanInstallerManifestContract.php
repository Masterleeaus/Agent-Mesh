<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Host;

final class TitanInstallerManifestContract
{
    public const SCHEMA = 'titan-extension-v1';
    public const CORE_FIELDS = ['schema','slug','folder','provider','version','requires','migrations','uninstall'];

    /** @param array<string,mixed> $manifest @return list<string> */
    public static function validate(array $manifest, bool $packaged = false): array
    {
        $errors = [];
        foreach (self::CORE_FIELDS as $field) {
            if (!array_key_exists($field, $manifest)) $errors[] = "Missing {$field}";
        }
        if (($manifest['schema'] ?? null) !== self::SCHEMA) $errors[] = 'Invalid installer schema';
        if (!is_string($manifest['slug'] ?? null) || preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', (string)$manifest['slug']) !== 1) $errors[] = 'Invalid slug';
        if (!is_string($manifest['folder'] ?? null) || preg_match('/^[A-Za-z][A-Za-z0-9_]*$/', (string)$manifest['folder']) !== 1) $errors[] = 'Invalid folder';
        if (!is_string($manifest['provider'] ?? null) || trim((string)$manifest['provider']) === '') $errors[] = 'Invalid provider';
        if (!is_string($manifest['version'] ?? null) || trim((string)$manifest['version']) === '') $errors[] = 'Invalid version';
        $requires = $manifest['requires'] ?? null;
        if (!is_array($requires) || !isset($requires['php'],$requires['laravel'],$requires['magicai'])) $errors[] = 'requires must include php, laravel and magicai';
        if (!is_bool($manifest['migrations'] ?? null)) $errors[] = 'migrations must be boolean';
        if (!is_array($manifest['uninstall'] ?? null) || !is_bool($manifest['uninstall']['preserve_data'] ?? null)) $errors[] = 'uninstall.preserve_data must be boolean';
        $allowed = array_merge(self::CORE_FIELDS, ['integrity','dependencies','optional_dependencies']);
        foreach (array_keys($manifest) as $key) if (!in_array($key,$allowed,true)) $errors[] = "Unsupported root manifest field {$key}";
        if ($packaged && !isset($manifest['integrity']['files'])) $errors[] = 'Packaged manifest requires integrity.files';
        return $errors;
    }
}
