<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$required = [
    'System/DTO/GovernanceDecision.php',
    'System/DTO/GovernancePreflightReport.php',
    'System/DTO/CommandDispatchRequest.php',
    'System/DTO/CommandDispatchReceipt.php',
    'System/Contracts/CommandBusGatewayContract.php',
    'System/Services/CommandBusMutationBoundary.php',
];
foreach ($required as $relative) {
    if (!is_file($root . '/' . $relative)) {
        fwrite(STDERR, "Missing Pass 4 Command Bus file: {$relative}\n");
        exit(1);
    }
    require_once $root . '/' . $relative;
}

use App\Extensions\TitanAICore\System\Contracts\CommandBusGatewayContract;
use App\Extensions\TitanAICore\System\DTO\CommandDispatchReceipt;
use App\Extensions\TitanAICore\System\DTO\CommandDispatchRequest;
use App\Extensions\TitanAICore\System\DTO\GovernanceDecision;
use App\Extensions\TitanAICore\System\DTO\GovernancePreflightReport;
use App\Extensions\TitanAICore\System\Services\CommandBusMutationBoundary;

final class Pass4RecordingCommandBus implements CommandBusGatewayContract {
    public int $calls = 0;
    public function dispatch(CommandDispatchRequest $request): CommandDispatchReceipt {
        $this->calls++;
        return CommandDispatchReceipt::accepted($request->planId, $request->stepId, 'receipt-1');
    }
}

$request = new CommandDispatchRequest('plan-1', 'step-1', 'crm.customer.update', ['customer_id'=>'c1'], 'company-1', 'actor-1', 'human', 'trace-1', 'corr-1', 'cause-1', 'root-1', 'op-1', 'idem-1');
$allow = new GovernancePreflightReport('ALLOW', true, false, [
    GovernanceDecision::allow('risk', 'RISK_ALLOWED', 'ok'),
    GovernanceDecision::allow('assurance', 'ASSURANCE_ALLOWED', 'ok'),
    GovernanceDecision::allow('autonomy', 'AUTONOMY_ALLOWED', 'ok'),
]);
$pending = new GovernancePreflightReport('PENDING_REVIEW', false, true, [GovernanceDecision::requireApproval('autonomy', 'APPROVAL_REQUIRED', 'review')]);

$gateway = new Pass4RecordingCommandBus();
$disabled = new CommandBusMutationBoundary($gateway, false);
$r = $disabled->dispatch($request, $allow);
if ($r->status !== 'BLOCKED' || $r->reasonCode !== 'EXECUTION_DISABLED' || $gateway->calls !== 0) {
    fwrite(STDERR, "execution-disabled boundary dispatched a mutation\n"); exit(1);
}
$enabled = new CommandBusMutationBoundary($gateway, true);
$r = $enabled->dispatch($request, $pending);
if ($r->status !== 'BLOCKED' || $r->reasonCode !== 'GOVERNANCE_NOT_APPROVED' || $gateway->calls !== 0) {
    fwrite(STDERR, "governance-denied boundary dispatched a mutation\n"); exit(1);
}
$r = $enabled->dispatch($request, $allow);
if ($r->status !== 'ACCEPTED' || $gateway->calls !== 1) {
    fwrite(STDERR, "approved mutation was not delegated exactly once to Command Bus gateway\n"); exit(1);
}
if ($r->planId !== 'plan-1' || $r->stepId !== 'step-1') {
    fwrite(STDERR, "Command Bus receipt lost plan/step identity\n"); exit(1);
}

fwrite(STDOUT, "Pass 4 Command Bus boundary test: PASS\n");
