<?php
return [
    'provider' => env('TITAN_AI_VISION_PROVIDER', 'auto'),
    'openai_api_key' => env('OPENAI_API_KEY', ''),
    'openai_model' => env('TITAN_AI_VISION_OPENAI_MODEL', 'gpt-5-mini'),
    'openai_detail' => env('TITAN_AI_VISION_OPENAI_DETAIL', 'high'),
    'max_images' => (int) env('TITAN_AI_VISION_MAX_IMAGES', 12),
    'max_image_bytes' => (int) env('TITAN_AI_VISION_MAX_IMAGE_BYTES', 12582912),
    'require_human_review_by_default' => true,
    'evidence_retention' => 'retain',
    'provider_bindings' => ['titan.vision.provider','magicai.vision.provider'],
];
