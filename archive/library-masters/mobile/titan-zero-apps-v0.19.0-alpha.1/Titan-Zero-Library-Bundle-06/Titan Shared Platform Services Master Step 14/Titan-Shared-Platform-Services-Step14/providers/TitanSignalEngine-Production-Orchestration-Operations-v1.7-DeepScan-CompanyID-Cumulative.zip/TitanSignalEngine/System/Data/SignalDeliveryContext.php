<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

final readonly class SignalDeliveryContext
{
    public function __construct(
        public string $deliveryId,
        public string $subscriberKey,
        public int $attempt,
        public string $leaseToken = '',
        public string $workerId = '',
        public string $idempotencyKey = '',
    ) {
    }
}
