<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class PlanStep {
    /**
     * @param array<int,PlanDependency> $dependsOn
     * @param array<int,PlanInput> $requiredInputs
     * @param array<int,PlanInput> $optionalInputs
     * @param array<int,PlanOutput> $outputs
     * @param array<int,string> $knowledgeRequirements
     */
    public function __construct(
        public string $stepId,
        public string $name,
        public string $action,
        public array $dependsOn = [],
        public array $requiredInputs = [],
        public array $optionalInputs = [],
        public array $outputs = [],
        public int $timeoutSeconds = 30,
        public RetryPolicy $retryPolicy = new RetryPolicy(),
        public ?WorkforceAssignment $workforceAssignment = null,
        public ?string $riskCeiling = null,
        public array $knowledgeRequirements = []
    ) {}

    public function toArray(): array {
        return [
            'step_id'=>$this->stepId,
            'name'=>$this->name,
            'action'=>$this->action,
            'depends_on'=>array_map(fn(PlanDependency $v)=>$v->toArray(),$this->dependsOn),
            'required_inputs'=>array_map(fn(PlanInput $v)=>$v->toArray(),$this->requiredInputs),
            'optional_inputs'=>array_map(fn(PlanInput $v)=>$v->toArray(),$this->optionalInputs),
            'outputs'=>array_map(fn(PlanOutput $v)=>$v->toArray(),$this->outputs),
            'timeout_seconds'=>$this->timeoutSeconds,
            'retry_policy'=>$this->retryPolicy->toArray(),
            'workforce_assignment'=>$this->workforceAssignment?->toArray(),
            'risk_ceiling'=>$this->riskCeiling,
            'knowledge_requirements'=>$this->knowledgeRequirements,
        ];
    }
}
