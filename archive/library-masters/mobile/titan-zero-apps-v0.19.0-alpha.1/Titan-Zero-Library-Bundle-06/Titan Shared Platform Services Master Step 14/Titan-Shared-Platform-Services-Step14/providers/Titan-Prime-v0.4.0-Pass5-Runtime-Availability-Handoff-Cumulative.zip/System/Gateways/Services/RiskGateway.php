<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Services;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Contracts\RiskGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;

final class RiskGateway extends AbstractEngineGateway implements RiskGatewayContract
{
    public function engine(): EngineKey { return EngineKey::Risk; }

    public function assess(TraceContext $trace, array $subject, string $operationId): EngineGatewayResult
    {
        return $this->dispatch($trace, 'risk.assess', ['subject' => $subject], $operationId);
    }
}
