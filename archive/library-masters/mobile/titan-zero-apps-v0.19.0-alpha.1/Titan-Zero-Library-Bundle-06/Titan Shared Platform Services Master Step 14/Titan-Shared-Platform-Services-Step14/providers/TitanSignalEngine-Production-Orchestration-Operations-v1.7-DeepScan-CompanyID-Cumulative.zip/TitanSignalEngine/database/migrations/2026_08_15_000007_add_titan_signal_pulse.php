<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_pulse_rollups')) {
            Schema::create('titan_signal_pulse_rollups', function (Blueprint $table): void {
                $table->id();
                $table->string('granularity', 12);
                $table->dateTime('bucket_start');
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->string('dimension', 40);
                $table->string('dimension_value', 191)->default('__all__');
                $table->unsignedBigInteger('event_count')->default(0);
                $table->unsignedBigInteger('severity_weight_sum')->default(0);
                $table->unsignedSmallInteger('max_severity_weight')->default(0);
                $table->unsignedBigInteger('error_count')->default(0);
                $table->unsignedBigInteger('critical_count')->default(0);
                $table->unsignedBigInteger('command_count')->default(0);
                $table->unsignedBigInteger('risk_count')->default(0);
                $table->unsignedBigInteger('governance_count')->default(0);
                $table->unsignedBigInteger('assurance_count')->default(0);
                $table->unsignedBigInteger('autonomy_count')->default(0);
                $table->unsignedBigInteger('subscription_failure_count')->default(0);
                $table->timestamp('first_event_at')->nullable();
                $table->timestamp('last_event_at')->nullable();
                $table->timestamps();

                $table->unique(['granularity', 'bucket_start', 'scope', 'tenant_key', 'dimension', 'dimension_value'], 'tspr_bucket_dimension_uq');
                $table->index(['scope', 'tenant_key', 'granularity', 'bucket_start'], 'tspr_scope_window_idx');
                $table->index(['scope', 'tenant_key', 'dimension', 'dimension_value', 'bucket_start'], 'tspr_dimension_window_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_pulse_projected_events')) {
            Schema::create('titan_signal_pulse_projected_events', function (Blueprint $table): void {
                $table->id();
                $table->uuid('event_id')->unique('tsppe_event_uq');
                $table->dateTime('recorded_at');
                $table->dateTime('projected_at');
                $table->timestamps();
                $table->index(['recorded_at', 'projected_at'], 'tsppe_recorded_projected_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_pulse_trace_metrics')) {
            Schema::create('titan_signal_pulse_trace_metrics', function (Blueprint $table): void {
                $table->id();
                $table->uuid('trace_id');
                $table->uuid('correlation_id');
                $table->uuid('root_causation_id')->nullable();
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->dateTime('first_occurred_at');
                $table->dateTime('last_occurred_at');
                $table->dateTime('first_recorded_at');
                $table->dateTime('last_recorded_at');
                $table->unsignedBigInteger('event_count')->default(0);
                $table->unsignedSmallInteger('max_severity_weight')->default(0);
                $table->unsignedBigInteger('duration_ms')->default(0);
                $table->string('last_event_type', 160);
                $table->timestamp('command_executed_at')->nullable();
                $table->timestamp('execution_receipt_at')->nullable();
                $table->unsignedBigInteger('command_latency_ms')->nullable();
                $table->boolean('terminal_seen')->default(false);
                $table->timestamps();

                $table->unique(['trace_id', 'scope', 'tenant_key'], 'tsptm_trace_scope_uq');
                $table->index(['scope', 'tenant_key', 'last_occurred_at'], 'tsptm_scope_last_idx');
                $table->index(['scope', 'tenant_key', 'execution_receipt_at'], 'tsptm_receipt_idx');
                $table->index(['scope', 'tenant_key', 'command_executed_at'], 'tsptm_command_idx');
                $table->index(['correlation_id', 'scope', 'tenant_key'], 'tsptm_correlation_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_pulse_trace_metrics');
        Schema::dropIfExists('titan_signal_pulse_projected_events');
        Schema::dropIfExists('titan_signal_pulse_rollups');
    }
};
