# Architecture

Titan AI Runtime is a shared AI kernel, not a presentation application.

```text
AIChatPro / AI Agent / Chatbot / Titan Mobile / other surfaces
                              |
                              v
                    ConversationSourceRegistry
                              |
                              v
                     TitanAIRuntimeContract
                              |
          source policy / context / trusted tools
                              |
                              v
                  five-tier Titan AI runtime
                              |
                governance / provider policy
                              |
                              v
                      canonical WorkCore
```

## Five-tier execution model

1. Tier 0 — Titan Zero orchestration
2. Tier 1 — Managers
3. Tier 2 — Assistants and specialists
4. Tier 3 — Atomic agents
5. Tier 4 — governed tools/capabilities

The runtime retains the canonical worker hierarchy from the converged TitanAI package.

## Ownership boundaries

TitanAI owns AI orchestration, source policy, intent routing, worker selection, provider boundaries, context assembly, trusted tool authorization, governance, approvals and AI action receipts.

WorkCore owns customers, jobs, schedules, workers, bookings, quotes, invoices, payments, inventory and other operational business records.

Presentation/automation products own their own UI, conversations, connector credentials, workflow definitions and product-specific records.

## Company boundary

MagicAI remains the authority for user/company membership. Every source adapter resolves one validated positive `company_id` from persisted/authenticated host state before constructing a `TitanAIRequest`. Caller-supplied company context is not authoritative.
