<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\AI;

final class CrmAssistantActionProtocol
{
    public const OPEN = '<<<ACTIONS>>>';
    public const CLOSE = '<<<END_ACTIONS>>>';

    public static function prompt(): string
    {
        return <<<'PROMPT'
When the user asks for a CRM mutation, do not claim it has already happened. Propose one or more actions using exactly this protocol:
<<<ACTIONS>>>[{"tool":"crm_create_company","label":"Create company","summary":"Create Acme Pty Ltd","arguments":{"name":"Acme Pty Ltd"}}]<<<END_ACTIONS>>>
The payload must be a JSON array. Every object must contain `tool`, `label`, `summary`, and `arguments`. Only use tools exposed by the CRM Assistant. Do not emit this protocol for read-only questions. The MagicAI CRM action card will require the user to approve each proposed write before execution. CRM Core does not own autonomy, learning, planning or proactive execution. Any authority decision is supplied by Titan Autonomy through its external contract; when that engine is unavailable, human approval is required.
PROMPT;
    }
}
