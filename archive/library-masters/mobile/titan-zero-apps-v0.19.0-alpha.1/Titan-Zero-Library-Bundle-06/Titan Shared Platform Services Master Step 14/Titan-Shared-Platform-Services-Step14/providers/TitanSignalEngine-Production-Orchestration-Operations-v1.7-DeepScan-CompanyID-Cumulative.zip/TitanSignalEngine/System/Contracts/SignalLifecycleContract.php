<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;

interface SignalLifecycleContract
{
    /** @param list<array{op:string,path:string,value?:mixed}> $operations @return array<string,mixed> */
    public function redact(string $eventId, array $operations, string $reason, SignalContext $context): array;

    /** @param list<array{op:string,path:string,value?:mixed}> $operations @return array<string,mixed> */
    public function correct(string $eventId, array $operations, string $reason, SignalContext $context): array;

    /** @return array<string,mixed>|null */
    public function view(string $eventId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT): ?array;

    /** @return array<string,mixed> */
    public function setLegalHold(string $eventId, bool $hold, string $reason, SignalContext $context): array;

    /** @return array<string,mixed> */
    public function previewPrune(?int $tenantCompanyId, string $scope, int $limit, SignalContext $context): array;

    /** @return array<string,mixed> */
    public function prune(string $previewToken, string $reason, SignalContext $context): array;
}
