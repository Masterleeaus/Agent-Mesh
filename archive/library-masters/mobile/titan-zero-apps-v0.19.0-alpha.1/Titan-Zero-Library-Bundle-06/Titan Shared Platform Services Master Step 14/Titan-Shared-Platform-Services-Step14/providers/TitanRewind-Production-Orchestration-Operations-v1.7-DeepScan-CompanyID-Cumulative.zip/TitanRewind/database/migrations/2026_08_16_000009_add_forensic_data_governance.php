<?php
declare(strict_types=1);
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
  if(!Schema::hasTable('titan_rewind_historical_artifacts')) Schema::create('titan_rewind_historical_artifacts',function(Blueprint $t):void{
   $t->id();$t->uuid('artifact_uuid')->unique();$t->unsignedBigInteger('tenant_company_id')->nullable()->index();$t->uuid('trace_id')->nullable()->index();$t->string('kind',80)->index();$t->string('version',191)->index();$t->string('source_key',120)->nullable()->index();$t->string('authenticity_state',30)->default('UNKNOWN')->index();$t->char('content_hash',64)->index();$t->longText('artifact_payload');$t->json('metadata')->nullable();$t->dateTime('captured_at',6)->index();$t->dateTime('last_verified_at',6)->nullable();$t->timestamps();$t->unique(['tenant_company_id','trace_id','kind','version','content_hash'],'trw_artifact_identity');
  });
  if(!Schema::hasTable('titan_rewind_signing_keys')) Schema::create('titan_rewind_signing_keys',function(Blueprint $t):void{
   $t->id();$t->string('key_id',191)->unique();$t->string('algorithm',60);$t->string('status',30)->index();$t->char('public_key_fingerprint',64)->nullable()->index();$t->dateTime('activated_at',6)->nullable();$t->dateTime('retired_at',6)->nullable();$t->dateTime('last_used_at',6)->nullable();$t->timestamps();
  });
  if(!Schema::hasTable('titan_rewind_purge_runs')) Schema::create('titan_rewind_purge_runs',function(Blueprint $t):void{
   $t->id();$t->uuid('run_uuid')->unique();$t->char('active_key',64)->nullable()->unique();$t->unsignedBigInteger('tenant_company_id')->index();$t->string('retention_class',40)->index();$t->string('status',30)->default('running')->index();$t->string('cursor_table',120)->nullable();$t->unsignedBigInteger('cursor_id')->default(0);$t->unsignedBigInteger('rows_deleted')->default(0);$t->unsignedBigInteger('rows_held')->default(0);$t->unsignedBigInteger('requested_by_id')->nullable()->index();$t->dateTime('started_at',6)->index();$t->dateTime('completed_at',6)->nullable();$t->text('last_error')->nullable();$t->timestamps();
  });
  if(!Schema::hasTable('titan_rewind_purge_receipts')) Schema::create('titan_rewind_purge_receipts',function(Blueprint $t):void{
   $t->id();$t->uuid('receipt_uuid')->unique();$t->uuid('run_uuid')->index();$t->unsignedBigInteger('tenant_company_id')->index();$t->string('table_name',120)->index();$t->string('retention_class',40)->index();$t->unsignedBigInteger('from_id')->default(0);$t->unsignedBigInteger('to_id')->default(0);$t->unsignedInteger('rows_deleted')->default(0);$t->unsignedInteger('rows_held')->default(0);$t->char('batch_hash',64);$t->json('metadata')->nullable();$t->dateTime('purged_at',6)->index();$t->timestamps();
  });
 }
 public function down(): void { Schema::dropIfExists('titan_rewind_purge_receipts');Schema::dropIfExists('titan_rewind_purge_runs');Schema::dropIfExists('titan_rewind_signing_keys');Schema::dropIfExists('titan_rewind_historical_artifacts'); }
};
