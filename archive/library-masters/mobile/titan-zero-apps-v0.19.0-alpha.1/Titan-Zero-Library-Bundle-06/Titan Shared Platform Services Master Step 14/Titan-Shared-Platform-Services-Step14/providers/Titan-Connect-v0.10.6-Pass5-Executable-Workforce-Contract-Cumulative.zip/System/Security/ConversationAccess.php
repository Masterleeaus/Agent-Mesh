<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

final class ConversationAccess
{
    public function __construct(private readonly WorkCoreAuthorizationGateway $workCore)
    {
    }

    public function assertCompany(TeamConversation $conversation, int $companyId): void
    {
        if ((int) $conversation->company_id !== $companyId) {
            throw new NotFoundHttpException();
        }
    }

    public function assertMember(TeamConversation $conversation, int $companyId, int $actorId): void
    {
        $this->assertCompany($conversation, $companyId);
        if (! $conversation->hasParticipant($actorId)) {
            throw new AccessDeniedHttpException('Conversation membership is required.');
        }
        $this->assertLinkedEntity($conversation, $companyId, $actorId);
    }

    public function assertLinkedEntity(TeamConversation $conversation, int $companyId, int $actorId): void
    {
        if (! $conversation->isLinkedRoom()) {
            return;
        }
        $this->workCore->assertCanAccess(
            $companyId,
            $actorId,
            (string) $conversation->linked_entity_type,
            (string) $conversation->linked_entity_id,
        );
    }
}
