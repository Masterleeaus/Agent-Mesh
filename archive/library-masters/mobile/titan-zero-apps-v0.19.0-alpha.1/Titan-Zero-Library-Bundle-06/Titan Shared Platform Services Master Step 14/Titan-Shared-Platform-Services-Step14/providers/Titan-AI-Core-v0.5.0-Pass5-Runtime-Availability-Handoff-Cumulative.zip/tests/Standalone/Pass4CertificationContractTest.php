<?php

declare(strict_types=1);
$root = dirname(__DIR__, 2);
$text = (string) file_get_contents($root . '/System/Commands/CertifyExtensionCommand.php');
foreach ([
    'governance_preflight', 'command_bus_boundary', 'approval_state', 'execution_fail_closed',
] as $needle) {
    if (!str_contains($text, "'{$needle}'")) { fwrite(STDERR, "certification command missing {$needle}\n"); exit(1); }
}
if (!str_contains($text, "'version'=>'0.5.0'")) { fwrite(STDERR, "certification evidence version not 0.5.0\n"); exit(1); }
fwrite(STDOUT, "Pass 4 certification contract test: PASS\n");
