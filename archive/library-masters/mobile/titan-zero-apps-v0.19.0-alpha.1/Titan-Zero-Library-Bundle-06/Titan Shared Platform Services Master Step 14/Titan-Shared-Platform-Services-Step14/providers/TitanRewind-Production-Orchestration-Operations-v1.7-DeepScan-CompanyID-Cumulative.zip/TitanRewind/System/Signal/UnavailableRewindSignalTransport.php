<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Signal;

use App\Extensions\TitanRewind\System\Contracts\RewindSignalTransportContract;
use RuntimeException;

final class UnavailableRewindSignalTransport implements RewindSignalTransportContract
{
    public function available(): bool { return false; }
    public function publish(array $event): void { throw new RuntimeException('Titan Signal transport is unavailable.'); }
}
