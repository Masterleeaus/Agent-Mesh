<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Import;
final class CrmImportMapper
{
    public function map(array $source,array $mapping): array
    {
        $out=[]; foreach($mapping as $target=>$sourceKey){ if(is_string($sourceKey) && array_key_exists($sourceKey,$source)) $out[$target]=$source[$sourceKey]; }
        return $out;
    }
}
