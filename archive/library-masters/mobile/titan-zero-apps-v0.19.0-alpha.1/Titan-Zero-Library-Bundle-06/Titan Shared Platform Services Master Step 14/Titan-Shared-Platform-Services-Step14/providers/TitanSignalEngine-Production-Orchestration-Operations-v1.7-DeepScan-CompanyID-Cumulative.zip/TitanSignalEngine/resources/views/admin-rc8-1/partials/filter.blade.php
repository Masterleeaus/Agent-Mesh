@php $req = $dashboard['request'] ?? ['scope'=>'system','tenant_company_id'=>null,'window'=>'5m','limit'=>100]; @endphp
<form method="GET" class="tse-card tse-filter tse-section" data-tse-filter>
    <div class="tse-row">
        <label>Scope
            <select name="scope" class="tse-select" data-tse-scope>
                <option value="system" @selected(($req['scope'] ?? 'system')==='system')>System</option>
                <option value="tenant" @selected(($req['scope'] ?? 'system')==='tenant')>Tenant</option>
            </select>
        </label>
        <label data-tse-tenant @if(($req['scope'] ?? 'system')!=='tenant') hidden @endif>Tenant
            <input class="tse-input" name="tenant_company_id" value="{{ $req['tenant_company_id'] ?? '' }}" inputmode="numeric" placeholder="Company ID">
        </label>
        <label>Window
            <select name="window" class="tse-select">@foreach(['5m','1h','24h','7d'] as $w)<option value="{{ $w }}" @selected(($req['window'] ?? '5m')===$w)>{{ $w }}</option>@endforeach</select>
        </label>
        <input type="hidden" name="limit" value="{{ $req['limit'] ?? 100 }}">
        <button class="tse-btn tse-btn-primary" type="submit">Refresh</button>
    </div>
</form>
<script>
document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('[data-tse-filter]').forEach(function(form){var scope=form.querySelector('[data-tse-scope]'),tenant=form.querySelector('[data-tse-tenant]');if(!scope||!tenant)return;var sync=function(){tenant.hidden=scope.value!=='tenant';if(tenant.hidden){var input=tenant.querySelector('input');if(input)input.value='';}};scope.addEventListener('change',sync);sync();});});
</script>
