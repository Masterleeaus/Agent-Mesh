<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$expect = static function (bool $condition, string $message) use (&$errors): void {
    if (! $condition) {
        $errors[] = $message;
    }
};

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$rootManifest = json_decode((string) file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);
$expect(is_string($manifest['version'] ?? null) && preg_match('/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $manifest['version']) === 1, 'sidecar version must be valid semver');
$expect(($rootManifest['version'] ?? null) === ($manifest['version'] ?? null), 'root version must match sidecar version');
$expect(($manifest['capabilities'] ?? []) === ['titan-knowledge-authority', 'knowledge.health'], 'Pass 3 must not advertise new public knowledge capabilities yet');
$expect(($manifest['queues']['used'] ?? null) === false, 'Pass 3 must keep queues disabled');
$expect(($manifest['schedules'] ?? null) === [], 'Pass 3 must keep schedules empty');
$expect(($manifest['external_hosts'] ?? null) === [], 'Pass 3 must keep external hosts empty');

$required = [
    'System/Contracts/KnowledgeAccessContextResolverContract.php',
    'System/Contracts/KnowledgeCatalogReadContract.php',
    'System/Domain/Repositories/KnowledgeSourceRepositoryContract.php',
    'System/Domain/Repositories/KnowledgeSourceVersionRepositoryContract.php',
    'System/Domain/Repositories/EloquentKnowledgeSourceRepository.php',
    'System/Domain/Repositories/EloquentKnowledgeSourceVersionRepository.php',
    'System/Domain/Services/KnowledgeScopeVisibilityPolicy.php',
    'System/Domain/ValueObjects/KnowledgeAccessContext.php',
    'System/Services/FailClosedKnowledgeAccessContextResolver.php',
    'System/Services/KnowledgeCatalogReadService.php',
];
foreach ($required as $path) {
    $expect(is_file($root . '/' . $path), "missing Pass 3 file: {$path}");
}

if (is_file($root . '/System/Domain/ValueObjects/KnowledgeAccessContext.php')
    && is_file($root . '/System/Domain/Services/KnowledgeScopeVisibilityPolicy.php')) {
    require_once $root . '/System/Domain/Enums/KnowledgeScopeType.php';
    require_once $root . '/System/Domain/ValueObjects/KnowledgeScopeContext.php';
    require_once $root . '/System/Domain/ValueObjects/KnowledgeAccessContext.php';
    require_once $root . '/System/Domain/Services/KnowledgeScopeVisibilityPolicy.php';

    $contextClass = 'App\\Extensions\\TitanKnowledgeAuthority\\System\\Domain\\ValueObjects\\KnowledgeAccessContext';
    $scopeClass = 'App\\Extensions\\TitanKnowledgeAuthority\\System\\Domain\\ValueObjects\\KnowledgeScopeContext';
    $policyClass = 'App\\Extensions\\TitanKnowledgeAuthority\\System\\Domain\\Services\\KnowledgeScopeVisibilityPolicy';

    $context = $contextClass::trusted(42, ['AU', 'AU-VIC']);
    $policy = new $policyClass();

    $expect($policy->canRead($context, $scopeClass::platform()) === true, 'platform scope must be readable with trusted context');
    $expect($policy->canRead($context, $scopeClass::tenant(42)) === true, 'matching tenant scope must be readable');
    $expect($policy->canRead($context, $scopeClass::tenant(43)) === false, 'cross-tenant scope must be denied');
    $expect($policy->canRead($context, $scopeClass::jurisdiction('AU-VIC')) === true, 'allowed jurisdiction must be readable');
    $expect($policy->canRead($context, $scopeClass::jurisdiction('AU-NSW')) === false, 'ungranted jurisdiction must be denied');
    $expect($context->allowsJurisdiction('au-vic') === true, 'jurisdiction comparison must be normalized');
    $expect($context->allowsJurisdiction('AU-NSW') === false, 'jurisdiction allowlist must fail closed');

    $tenantless = $contextClass::trusted(null, ['AU']);
    $expect($policy->canRead($tenantless, $scopeClass::platform()) === true, 'platform reads must not require a tenant');
    $expect($policy->canRead($tenantless, $scopeClass::tenant(42)) === false, 'tenantless context must not read tenant knowledge');

    require_once $root . '/System/Domain/Services/KnowledgeScopeGuard.php';
    $legacyGuardClass = 'App\\Extensions\\TitanKnowledgeAuthority\\System\\Domain\\Services\\KnowledgeScopeGuard';
    $legacyGuard = new $legacyGuardClass();
    $expect($legacyGuard->canRead($scopeClass::jurisdiction('AU-VIC'), null) === false, 'legacy primitive guard must fail closed for jurisdiction reads after Pass 3');
}

$provider = (string) @file_get_contents($root . '/System/TitanKnowledgeAuthorityServiceProvider.php');
$expect(str_contains($provider, 'KnowledgeAccessContextResolverContract::class'), 'provider must register the trusted context resolver seam');
$expect(str_contains($provider, 'FailClosedKnowledgeAccessContextResolver::class'), 'provider must default context resolution to fail closed');
$expect(str_contains($provider, 'if (! $this->app->bound(KnowledgeAccessContextResolverContract::class))'), 'provider must preserve a host-supplied trusted resolver binding');
$expect(str_contains($provider, 'KnowledgeCatalogReadContract::class'), 'provider must register internal scoped catalog reads');

$catalogContract = (string) @file_get_contents($root . '/System/Contracts/KnowledgeCatalogReadContract.php');
$expect(! str_contains($catalogContract, 'tenantCompanyId'), 'catalog read contract must not accept caller-supplied tenant ids');
$expect(! str_contains($catalogContract, 'tenant_company_id'), 'catalog read contract must not accept raw tenant_company_id');

$repositoryContract = (string) @file_get_contents($root . '/System/Domain/Repositories/KnowledgeSourceRepositoryContract.php');
$expect(str_contains($repositoryContract, 'KnowledgeAccessContext'), 'source repository must require trusted KnowledgeAccessContext');
$expect(! preg_match('/find[^\(]*\([^\)]*\?int\s+\$tenant/i', $repositoryContract), 'source repository must not accept raw tenant id read parameters');

$scopeBoundaryFiles = [
    'System/Domain/Repositories/EloquentKnowledgeSourceRepository.php',
    'System/Domain/Repositories/EloquentKnowledgeSourceVersionRepository.php',
    'System/Services/KnowledgeCatalogReadService.php',
];
foreach ($scopeBoundaryFiles as $path) {
    $code = (string) @file_get_contents($root . '/' . $path);
    $expect(! str_contains($code, 'request('), "{$path} must not source scope from request()");
    $expect(! str_contains($code, '->input('), "{$path} must not source scope from request input");
    $expect(! str_contains($code, '->query('), "{$path} must not source scope from query parameters");
}

$failClosed = (string) @file_get_contents($root . '/System/Services/FailClosedKnowledgeAccessContextResolver.php');
$expect(str_contains($failClosed, 'Knowledge access context is unavailable'), 'default resolver must explain fail-closed context unavailability');

$upgradePrompt = (string) file_get_contents($root . '/TITAN-KNOWLEDGE-AUTHORITY-UPGRADE-PROMPT.md');
$expect(str_contains($upgradePrompt, 'Pass 3'), 'upgrade prompt must record Pass 3');
$expect(str_contains($upgradePrompt, 'Pass 3 completed'), 'upgrade prompt must preserve Pass 3 completion record');

if ($errors !== []) {
    fwrite(STDERR, "Titan Knowledge Authority Pass 3 scope verification: FAIL\n - " . implode("\n - ", $errors) . "\n");
    exit(1);
}

echo "Titan Knowledge Authority Pass 3 scope verification: PASS\n";
