# Uninstall

Default policy preserves evidence and audit state. Configuration may be removed. Destructive evidence deletion must be an explicit tenant-governed operation, never an uninstall side effect.
