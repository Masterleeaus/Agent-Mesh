# Capabilities

Public capabilities are declared in `extension.manifest.json` and versioned capability schemas live under `schemas/capabilities/`.

- `signal.emit` — accept a registered, trusted-context immutable event.
- `signal.query` — bounded tenant/system event queries.
- `signal.correlate` v2.0 — trace, workflow and causal reconstruction across hot and verified cold history, with storage-tier and Rewind integrity metadata.
- `signal.health` — governed engine health.
- `signal.subscribe` / `signal.deliver` — subscriber control/data plane.
- `signal.delivery.redrive` — governed recovery of repaired dead-letter deliveries with immutable audit evidence.
- `signal.pulse` — pre-aggregated operational awareness.
- `signal.anomaly.detect` — deterministic rule-based anomaly detection.
- `signal.anomaly.manage` — governed anomaly acknowledge/suppress/resolve operations with immutable decision events.
- `signal.lifecycle` — retention/legal-hold/pruning lifecycle.
- `signal.archive` — verified cold archival.
- `signal.redact` — immutable privacy/correction overlays.
- `signal.console` — tenant/admin read-model surface.

Lifecycle/redaction/archive operations are high-risk and must remain permissioned/governed. Signal observations never replace authoritative CRM/domain records.

## signal.lifecycle v2.0

Destructive pruning uses a two-step preview/confirm contract. `preview_prune` returns an expiring exact-set `preview_token`; `prune` requires that token and a governed reason. Candidate drift, legal holds, claim conflicts or token expiry fail closed.
## Internal automatic trace evaluation

Automatic trace/profile assignment and reevaluation is an internal governed-engine projection rather than a public mutation capability. It consumes immutable Signal history through `signal.correlate` semantics and feeds fresh sequence/completeness evidence to anomaly detection.

