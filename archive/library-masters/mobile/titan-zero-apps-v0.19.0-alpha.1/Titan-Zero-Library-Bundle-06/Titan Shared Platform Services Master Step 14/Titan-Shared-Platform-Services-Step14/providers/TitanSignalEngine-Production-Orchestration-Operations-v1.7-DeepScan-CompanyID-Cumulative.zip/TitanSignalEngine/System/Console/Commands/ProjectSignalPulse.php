<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Console\Commands;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalPulseProjectorContract;
use Illuminate\Console\Command;

final class ProjectSignalPulse extends Command
{
    protected $signature = 'titan:signal-pulse:project {--limit=1000 : Maximum unprojected events to process}';
    protected $description = 'Catch up recoverable Titan Signal Pulse rollup projections.';

    public function handle(SignalPulseProjectorContract $projector): int
    {
        $result = $projector->catchUp((int) $this->option('limit'));
        $this->line(json_encode($result, JSON_THROW_ON_ERROR));
        return $result['failed'] > 0 ? self::FAILURE : self::SUCCESS;
    }
}
