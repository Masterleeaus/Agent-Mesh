<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

final class RewindRecoveryPlan extends Model
{
    protected $table = 'titan_rewind_recovery_plans';
    protected $fillable = [
        'plan_uuid','plan_key','tenant_company_id','case_id','trace_id','root_cause_event_id','status','risk_level','strategy',
        'proposed_capability','command_input','plan','plan_hash','blockers','requested_by_id','governance_request_id','governance_status','approved_at',
    ];
    protected $casts = [
        'tenant_company_id'=>'integer','case_id'=>'integer','command_input'=>'array','plan'=>'array','blockers'=>'array','requested_by_id'=>'integer','approved_at'=>'datetime',
    ];

    public function steps(): HasMany { return $this->hasMany(RewindRecoveryStep::class, 'recovery_plan_id')->orderBy('step_order'); }
    public function governanceReceipts(): HasMany { return $this->hasMany(RewindGovernanceReceipt::class, 'recovery_plan_id')->orderBy('id'); }
}
