# CRM 1.3.0-alpha.4 Migration + Donor Hardening Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make CRM retry-safe after the alpha.3 MySQL migration failure and add low-risk WorkCore-derived Pay/Locker domain algorithms without adding new persistence risk.

**Architecture:** Harden the existing field-service migration in place because it has never completed successfully on the target host and may be partially applied. Add static regression gates for MySQL identifier length and restartability. Adapt domain-pure WorkCore finance/inventory algorithms into CRM namespaces and expose them through focused CRM services/capabilities without importing WorkCore runtime or tenancy.

**Tech Stack:** PHP 8.2+, Laravel 10, MySQL/MariaDB, Titan custom extension installer v1.2.0.

## Global Constraints

- `tenant_company_id` is the CRM/Titan business tenant boundary.
- CRM `company_id` remains a customer/account-company relationship.
- No WorkCore runtime dependency or `tz_*`/`tm_*` schema dependency.
- MySQL identifiers must be <= 64 characters.
- Existing extension migrations must be retry-safe after partially executed MySQL DDL.
- Required time columns use the established CRM MySQL-safe DATETIME pattern.

---

### Task 1: Migration recovery hardening
- [ ] Add failing identifier-length and migration-restartability regression gates.
- [ ] Verify both gates fail against alpha.3.
- [ ] Give the service-recovery index an explicit short name.
- [ ] Guard all `Schema::create()` calls in migration 000011 with `Schema::hasTable()`.
- [ ] Verify the gates pass.

### Task 2: Adapt donor domain algorithms
- [ ] Add failing donor-feature contract test.
- [ ] Adapt WorkCore bank matching, collection suppression, job profitability, payment QR and inventory stock policies to CRM namespaces.
- [ ] Remove WorkCore tenancy/runtime references.
- [ ] Add focused unit scripts for pure algorithms.
- [ ] Verify donor feature tests pass.

### Task 3: CRM integration
- [ ] Wire donor algorithms behind CRM Pay/Locker service facades/capabilities without eager provider resolution.
- [ ] Add source-level integration regression checks.
- [ ] Verify provider-stage safety remains green.

### Task 4: Release packaging
- [ ] Bump to `1.3.0-alpha.4`.
- [ ] Regenerate integrity maps.
- [ ] Run full PHP/JSON/migration/Titan verifier suite.
- [ ] Package flat ZIP and verify from fresh extraction.
