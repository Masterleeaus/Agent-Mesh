# Upgrade

Use forward-compatible migrations and preserve existing `company_id` data. Installer identity remains `titan-ai` / `TitanAI`.
