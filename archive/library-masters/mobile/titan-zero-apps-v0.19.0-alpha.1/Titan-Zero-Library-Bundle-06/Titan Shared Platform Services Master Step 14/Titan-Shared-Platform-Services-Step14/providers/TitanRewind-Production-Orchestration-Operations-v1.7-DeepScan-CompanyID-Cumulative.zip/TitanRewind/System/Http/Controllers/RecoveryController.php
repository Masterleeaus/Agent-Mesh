<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Http\Controllers;

use App\Extensions\TitanRewind\System\Models\RewindGovernanceReceipt;
use App\Extensions\TitanRewind\System\Models\RewindRecoveryPlan;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Services\RewindGovernanceService;
use App\Extensions\TitanRewind\System\Services\RewindRecoveryPlanService;
use App\Extensions\TitanRewind\System\Services\RewindTenantContextResolver;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use InvalidArgumentException;
use JsonException;
use LogicException;

final class RecoveryController
{
    public function __construct(
        private RewindTenantContextResolver $tenants,
        private RewindRecoveryPlanService $plans,
        private RewindGovernanceService $governance,
    ) {}

    public function store(Request $request, string $traceId): RedirectResponse
    {
        $tenant = $this->tenant($request);
        $capability = trim((string) $request->input('proposed_capability',''));
        abort_if($capability !== '' && preg_match('/^[a-z0-9][a-z0-9._:-]{0,119}$/', $capability) !== 1, 422, 'Invalid proposed capability name.');
        $commandInput = $this->decodeCommandInput((string) $request->input('command_input_json',''));
        $actor = $request->user()?->getAuthIdentifier();
        $caseId = $request->input('case_id');
        $plan = $this->plans->createForTrace(
            RewindTraceQuery::fromArray(['tenant_company_id'=>$tenant,'trace_id'=>$traceId]),
            is_numeric($caseId) ? (int) $caseId : null,
            is_numeric($actor) ? (int) $actor : null,
            ['proposed_capability'=>$capability,'command_input'=>$commandInput],
        );
        return redirect()->route('dashboard.user.titan.rewind.recovery.show',['planUuid'=>$plan->plan_uuid]);
    }

    public function show(Request $request, string $planUuid): View
    {
        $tenant = $this->tenant($request);
        $plan = RewindRecoveryPlan::query()->where('tenant_company_id',$tenant)->where('plan_uuid',$planUuid)->with('steps','governanceReceipts')->firstOrFail();
        return view('titan-rewind::recovery', ['plan'=>$plan,'governanceAvailable'=>$this->governance->available()]);
    }

    public function requestApproval(Request $request, string $planUuid): RedirectResponse
    {
        $tenant = $this->tenant($request);
        $plan = RewindRecoveryPlan::query()->where('tenant_company_id',$tenant)->where('plan_uuid',$planUuid)->firstOrFail();
        $actor = $request->user()?->getAuthIdentifier();
        try {
            $receipt = $this->governance->requestApproval($plan, is_numeric($actor) ? (int) $actor : null);
            $message = sprintf('Governance request %s created with status %s.', $receipt->external_request_id, $receipt->status);
        } catch (LogicException|InvalidArgumentException $e) {
            $message = $e->getMessage();
        }
        return redirect()->route('dashboard.user.titan.rewind.recovery.show',['planUuid'=>$planUuid])->with('rewind_status',$message);
    }

    public function refreshApproval(Request $request, string $planUuid): RedirectResponse
    {
        $tenant = $this->tenant($request);
        $plan = RewindRecoveryPlan::query()->where('tenant_company_id',$tenant)->where('plan_uuid',$planUuid)->firstOrFail();
        $receipt = RewindGovernanceReceipt::query()->where('tenant_company_id',$tenant)->where('recovery_plan_id',$plan->id)->latest('id')->firstOrFail();
        try {
            $receipt = $this->governance->refresh($receipt);
            $message = sprintf('Governance request %s refreshed: %s.', $receipt->external_request_id, $receipt->status);
        } catch (LogicException|InvalidArgumentException $e) {
            $message = $e->getMessage();
        }
        return redirect()->route('dashboard.user.titan.rewind.recovery.show',['planUuid'=>$planUuid])->with('rewind_status',$message);
    }

    private function decodeCommandInput(string $json): array
    {
        $json = trim($json);
        if ($json === '') return [];
        abort_if(strlen($json) > 20000, 422, 'Recovery command input exceeds the 20 KB planning limit.');
        try { $decoded = json_decode($json, true, 64, JSON_THROW_ON_ERROR); }
        catch (JsonException) { abort(422, 'Recovery command input must be valid JSON.'); }
        abort_unless(is_array($decoded), 422, 'Recovery command input must decode to a JSON object or array.');
        return $decoded;
    }

    private function tenant(Request $request): int
    {
        $tenant = $this->tenants->forUser($request->user());
        abort_if($tenant === null, 403, 'Titan Rewind could not resolve an explicit tenant company for this account.');
        return $tenant;
    }
}
