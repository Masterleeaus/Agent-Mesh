<?php

declare(strict_types=1);

spl_autoload_register(function(string $class):void{$p='App\\Extensions\\TitanAutonomy\\';if(!str_starts_with($class,$p))return;$f=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($p))).'.php';if(is_file($f))require_once$f;});

use App\Extensions\TitanAutonomy\System\Contracts\TenantAssuranceBridgeContract;

$bridge=new class implements TenantAssuranceBridgeContract{public int $seen=0;public function evaluateForTenant(int $tenantCompanyId,string $capability,?string $workflowKey,array $context):array{$this->seen=$tenantCompanyId;return['status'=>'GREEN','decision'=>'approved','confidence'=>.9,'reason_codes'=>[]];}};
$r=$bridge->evaluateForTenant(77,'crm.invoice.issue','completed_job_invoice',[]);
if($bridge->seen!==77||($r['status']??null)!=='GREEN')throw new RuntimeException('Scheduled Assurance must be explicitly tenant-bound without authenticated host context.');

echo "OK: ScheduledReconciliationTenantIsolationSmokeTest\n";
