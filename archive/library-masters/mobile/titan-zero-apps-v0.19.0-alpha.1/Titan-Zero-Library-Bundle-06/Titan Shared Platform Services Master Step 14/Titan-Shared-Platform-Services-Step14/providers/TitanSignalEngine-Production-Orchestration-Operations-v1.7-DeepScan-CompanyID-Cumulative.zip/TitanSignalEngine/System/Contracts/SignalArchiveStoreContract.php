<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

interface SignalArchiveStoreContract
{
    /** @param list<array<string,mixed>> $events @param array<string,mixed> $criteria @return array{driver:string,locator:string,checksum:string,event_count:int} */
    public function archive(string $batchId, array $events, array $criteria = []): array;

    /** @param iterable<array<string,mixed>> $events @param array<string,mixed> $criteria @return array{driver:string,locator:string,checksum:string,event_count:int} */
    public function archiveStream(string $batchId, iterable $events, int $expectedEventCount, array $criteria = []): array;

    public function verify(string $locator, string $checksum, ?string $driver = null): bool;

    /** @return array{batch_id:string,criteria:array<string,mixed>,event_count:int} */
    public function metadata(string $locator, string $checksum, ?string $driver = null): array;

    /** @return array<string,mixed>|null */
    public function readEvent(string $locator, string $checksum, string $eventId, ?int $sequence = null, ?string $driver = null): ?array;

    /** @return list<array<string,mixed>> */
    public function readBatch(string $locator, string $checksum, int $limit = 1000, ?string $driver = null): array;

    /** @return iterable<int,array<string,mixed>> */
    public function stream(string $locator, string $checksum, int $startSequence = 1, ?int $limit = null, ?string $driver = null): iterable;
}
