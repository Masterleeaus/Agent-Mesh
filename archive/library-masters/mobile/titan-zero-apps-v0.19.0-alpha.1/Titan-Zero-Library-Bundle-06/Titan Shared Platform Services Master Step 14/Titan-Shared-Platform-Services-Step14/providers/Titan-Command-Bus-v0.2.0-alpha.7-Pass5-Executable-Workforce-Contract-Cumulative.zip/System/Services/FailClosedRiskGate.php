<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Services;

use App\Extensions\TitanCommandBus\System\Contracts\CommandRiskGateContract;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use App\Extensions\TitanCommandBus\System\DTO\RiskDecision;

final class FailClosedRiskGate implements CommandRiskGateContract
{
    public function available(): bool { return false; }

    public function assess(CommandContext $context, CommandRequest $request): RiskDecision
    {
        return RiskDecision::unavailable();
    }
}
