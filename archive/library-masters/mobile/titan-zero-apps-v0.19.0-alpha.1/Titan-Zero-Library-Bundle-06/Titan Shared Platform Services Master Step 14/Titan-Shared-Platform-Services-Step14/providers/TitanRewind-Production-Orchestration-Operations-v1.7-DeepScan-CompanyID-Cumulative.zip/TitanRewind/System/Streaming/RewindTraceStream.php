<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Streaming;
use App\Extensions\TitanRewind\System\Models\RewindTraceEvent;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
final class RewindTraceStream
{
    public function events(RewindTraceQuery $query): iterable
    {
        $cursor=RewindTraceEvent::query()->where('tenant_company_id',$query->tenantCompanyId())->where('trace_id',$query->traceId())
            ->orderBy('sequence')->orderBy('occurred_at')->orderBy('event_id')->cursor();
        foreach($cursor as $event) yield $event;
    }
    public function arrays(RewindTraceQuery $query): iterable
    {
        foreach($this->events($query) as $event) yield $event->toArray();
    }
    public function count(RewindTraceQuery $query): int
    {
        return (int)RewindTraceEvent::query()->where('tenant_company_id',$query->tenantCompanyId())->where('trace_id',$query->traceId())->count();
    }
    public function page(RewindTraceQuery $query,int $limit=500,?array $after=null): array
    {
        $limit=max(1,min($limit,2000));
        $q=RewindTraceEvent::query()->where('tenant_company_id',$query->tenantCompanyId())->where('trace_id',$query->traceId());
        if($after!==null){$seq=(int)($after['sequence']??-1);$at=(string)($after['occurred_at']??'');$id=(string)($after['event_id']??'');
            $q->where(function($w)use($seq,$at,$id){$w->where('sequence','>',$seq)->orWhere(function($x)use($seq,$at,$id){$x->where('sequence',$seq)->where(function($y)use($at,$id){$y->where('occurred_at','>',$at)->orWhere(function($z)use($at,$id){$z->where('occurred_at',$at)->where('event_id','>',$id);});});});});}
        $rows=[];foreach($q->orderBy('sequence')->orderBy('occurred_at')->orderBy('event_id')->limit($limit+1)->cursor() as $event)$rows[]=$event->toArray();
        $hasMore=count($rows)>$limit;if($hasMore)array_pop($rows);$last=$rows===[]?null:$rows[array_key_last($rows)];
        return ['items'=>$rows,'has_more'=>$hasMore,'next_after'=>$last===null?null:['sequence'=>(int)$last['sequence'],'occurred_at'=>(string)$last['occurred_at'],'event_id'=>(string)$last['event_id']]];
    }
}
