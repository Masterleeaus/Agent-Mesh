<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindDriftFinding extends Model
{
    protected $table = 'titan_rewind_drift_findings';
    protected $fillable = [
        'finding_uuid','finding_key','tenant_company_id','trace_id','event_id','finding_type','severity','status','summary',
        'evidence','remediation','detected_at','last_seen_at','resolved_at','resolved_by_id',
    ];
    protected $casts = [
        'tenant_company_id'=>'integer','resolved_by_id'=>'integer','evidence'=>'array','remediation'=>'array',
        'detected_at'=>'datetime','last_seen_at'=>'datetime','resolved_at'=>'datetime',
    ];
}
