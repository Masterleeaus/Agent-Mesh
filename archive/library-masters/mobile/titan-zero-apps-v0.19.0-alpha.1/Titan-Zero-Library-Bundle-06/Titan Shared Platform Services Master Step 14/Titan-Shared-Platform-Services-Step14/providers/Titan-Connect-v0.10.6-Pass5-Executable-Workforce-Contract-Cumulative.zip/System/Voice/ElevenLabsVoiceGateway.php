<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Voice;

use App\Extensions\TitanConnect\System\Contracts\ProviderHttpClient;
use RuntimeException;

final class ElevenLabsVoiceGateway
{
    public function __construct(private readonly ProviderHttpClient $http) {}

    public function start(array $credentials): array
    {
        $agentId = trim((string) ($credentials['agent_id'] ?? '')); if ($agentId === '') throw new RuntimeException('ElevenLabs agent_id is not configured.');
        $signed = trim((string) ($credentials['signed_url'] ?? ''));
        $apiKey = trim((string) ($credentials['api_key'] ?? $credentials['xi_api_key'] ?? ''));
        if ($signed === '' && $apiKey !== '') {
            $endpoint = (string) ($credentials['signed_url_endpoint'] ?? config('titan-connect.voice.elevenlabs.signed_url_endpoint', 'https://api.elevenlabs.io/v1/convai/conversation/get-signed-url'));
            $response = $this->http->request('GET', $endpoint, ['headers'=>['xi-api-key'=>$apiKey],'query'=>['agent_id'=>$agentId]]);
            if ($response->isSuccessful()) $signed = trim((string) ($response->json('signed_url') ?? $response->json('resData.signed_url') ?? ''));
        }
        return ['provider'=>'elevenlabs','agent_id'=>$agentId,'signed_url'=>$signed !== '' ? $signed : null,'sdk_url'=>(string)config('titan-connect.voice.elevenlabs.sdk_url','https://cdn.jsdelivr.net/npm/@elevenlabs/client@latest/dist/umd/elevenlabs-client.umd.js')];
    }
}
