<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Http\Controllers;

use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Services\ExecutionFeedbackService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class AutonomyExecutionFeedbackController extends Controller
{
    public function __construct(
        private readonly HostContextBridgeContract $host,
        private readonly ExecutionFeedbackService $feedback,
    ) {}

    public function store(Request $request, string $correlationId): JsonResponse|RedirectResponse
    {
        abort_unless($this->host->can('titan.autonomy.manage'),403);
        $validated=$request->validate([
            'classification'=>['required','string','in:materially_corrected,reversed,failed,rejected,exception'],
            'details'=>['sometimes','array'],
        ]);
        $result=$this->feedback->record(
            $this->host->tenantCompanyId(),
            $this->host->userId(),
            $correlationId,
            (string)$validated['classification'],
            (array)($validated['details']??[]),
        );
        return $request->expectsJson()
            ? response()->json($result)
            : back()->with('status','Titan autonomy outcome feedback recorded.');
    }
}
