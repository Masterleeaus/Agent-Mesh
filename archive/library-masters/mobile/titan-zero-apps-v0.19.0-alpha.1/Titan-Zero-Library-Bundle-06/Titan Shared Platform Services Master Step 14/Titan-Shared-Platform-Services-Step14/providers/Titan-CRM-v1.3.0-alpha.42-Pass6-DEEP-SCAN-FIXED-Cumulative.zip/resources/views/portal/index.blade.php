@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Customer Hub','subtitle'=>'Manage secure customer access and continue the customer experience in Titan Hub.','surface'=>'customers','journey'=>'new-hub-access','secondaryJourneys'=>['new-customer']])
<div class="d-flex justify-content-end mb-3"><a class="btn btn-outline-primary" href="{{ url('/portal') }}" target="_self">Open Titan Hub</a></div>
@if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif
@if(session('portal_url'))<div class="alert alert-warning"><strong>Copy this link now:</strong><br><code>{{ session('portal_url') }}</code>@if(session('portal_verification_code'))<hr><strong>Verification code:</strong> <code>{{ session('portal_verification_code') }}</code><br><small>Send the code through a separate trusted channel.</small>@endif</div>@endif
<div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Label</th><th>Status</th><th>Hint</th><th>Expires</th><th></th></tr></thead><tbody>
@forelse($grants as $grant)<tr><td>{{ $grant->label ?: 'Customer Hub access' }}</td><td>{{ ucfirst($grant->status) }}</td><td>…{{ $grant->token_hint }}</td><td>{{ $grant->expires_at }}</td><td>@if(!$grant->revoked_at)<form method="post" action="{{ route('dashboard.user.crm.portal.grants.revoke',$grant->public_id) }}">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-secondary">Revoke</button></form>@endif</td></tr>@empty<tr><td colspan="5" class="text-muted">No Customer Hub access has been issued yet.</td></tr>@endforelse
</tbody></table></div></div>
@endcomponent
@endsection
