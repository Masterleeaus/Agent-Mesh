<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface AutonomyControlStoreContract
{
    public function saveLearningSettings(int $tenantCompanyId, array $settings, string $policyVersion): void;
    public function resetCapabilityLearning(int $tenantCompanyId, string $capability, string $workflowKey, string $targetLevel, string $policyVersion): void;
    public function clearPreferences(int $tenantCompanyId, ?int $userId = null): int;
    public function lowerCapabilityLevel(int $tenantCompanyId, string $capability, string $workflowKey, string $targetLevel, string $cause, string $policyVersion): void;
    public function savePlatformPolicy(array $policy, string $policyVersion): void;
    public function saveTenantPolicy(int $tenantCompanyId, array $policy, string $policyVersion): void;
}
