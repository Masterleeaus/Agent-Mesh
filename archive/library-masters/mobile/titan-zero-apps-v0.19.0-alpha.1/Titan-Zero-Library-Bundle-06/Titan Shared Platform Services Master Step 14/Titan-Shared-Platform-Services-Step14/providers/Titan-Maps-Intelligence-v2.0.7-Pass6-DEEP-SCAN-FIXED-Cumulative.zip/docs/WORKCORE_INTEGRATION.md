# WorkCore Integration

## Authority

WorkCore is the operational authority for customers, contacts, leads, providers, contractors, suppliers, properties, jobs, invoices, and related records. Titan Maps Intelligence stores external observations and candidate workflow state only.

## Required contracts

### `WorkCoreCandidateLookup`

```php
public function find(string $companyId, string $entityType, string $entityId): ?array;
```

The adapter must enforce WorkCore tenancy and return a normalised comparison projection. It must not return unrestricted internal records.

### `WorkCoreCandidateGateway`

```php
public function promote(
    string $companyId,
    string $targetType,
    array $fields,
    array $context,
): array;
```

The gateway must execute a WorkCore service/command, including validation, permissions, transaction, audit, and domain event. Expected result fields are:

```php
[
    'entity_type' => 'provider',
    'entity_id' => '...',
    'command_id' => '...',
    'event_id' => '...',
]
```

## Promotion constraints

Promotion requires:

- `candidate.promote` permission
- candidate in the same company
- approved review status
- no unresolved ambiguous match
- supported target type
- at least one explicitly accepted allowlisted field

The extension never writes WorkCore tables directly. `candidate_promotions` stores lineage to the WorkCore command and event.

## Recommended WorkCore commands

- `CreateLeadFromExternalCandidate`
- `CreateProviderFromExternalCandidate`
- `CreateSupplierFromExternalCandidate`
- `CreateContractorFromExternalCandidate`
- `CreateCustomerFromExternalCandidate`

Each command should retain external source references and distinguish imported public data from later verified operational data.

## `FieldReferenceGateway`

Pass 6 adds a company-scoped gateway for map attachment:

```php
public function resolve(
    string $companyId,
    string $referenceType,
    string $publicReferenceId,
): ?FieldReference;
```

Supported reference types are `job`, `property`, `branch`, `worker`, `supplier`, and `contractor`. The adapter must return `null` for missing, deleted, inactive, or foreign-company records. The included `WorkCoreFieldReferenceGateway` builds on the existing tenant-scoped `WorkCoreCandidateLookup` projection and accepts only the minimum address/branch/workspace fields needed for geographic resolution.

The postal address is used as geocoding input but is not promoted to Maps authority. `MapLocationService` persists a normalized SHA-256 address fingerprint and provider-formatted output, so an address change in WorkCore causes a refresh without Maps becoming the owner of the customer/property address.
