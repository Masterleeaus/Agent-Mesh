<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface ExecutionReceiptReconcilerContract
{
    /** Reconcile one tenant-owned receipt only when its canonical maturation rules permit it. */
    public function finalizeReceiptDue(int $tenantCompanyId, string $correlationId): array;
}
