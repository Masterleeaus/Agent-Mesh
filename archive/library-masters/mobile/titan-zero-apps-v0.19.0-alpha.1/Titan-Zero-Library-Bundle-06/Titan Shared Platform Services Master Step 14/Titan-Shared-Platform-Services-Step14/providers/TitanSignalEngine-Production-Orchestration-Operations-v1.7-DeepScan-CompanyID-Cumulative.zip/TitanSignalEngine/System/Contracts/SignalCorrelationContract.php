<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;

interface SignalCorrelationContract
{
    /** @return list<SignalEnvelope> */
    public function ancestors(string $eventId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $maxDepth = 100): array;

    /** @return list<SignalEnvelope> */
    public function descendants(string $eventId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $maxDepth = 100): array;

    /** @return array<string,mixed> */
    public function trace(string $traceId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, ?string $profileKey = null, ?int $profileVersion = null, int $limit = 1000): array;

    /** @return array<string,mixed> */
    public function workflow(string $correlationId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 1000): array;
}
