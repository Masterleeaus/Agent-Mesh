<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Integrations\Governance;

use App\Extensions\TitanAICore\System\Contracts\RiskGatewayContract;
use App\Extensions\TitanAICore\System\DTO\GovernanceDecision;
use App\Extensions\TitanAICore\System\DTO\GovernancePreflightRequest;

final class UnavailableRiskGateway implements RiskGatewayContract
{
    public function evaluate(GovernancePreflightRequest $request): GovernanceDecision
    {
        return GovernanceDecision::defer('risk', 'RISK_GATEWAY_UNAVAILABLE', 'Titan Risk is not connected; execution remains blocked.');
    }
}
