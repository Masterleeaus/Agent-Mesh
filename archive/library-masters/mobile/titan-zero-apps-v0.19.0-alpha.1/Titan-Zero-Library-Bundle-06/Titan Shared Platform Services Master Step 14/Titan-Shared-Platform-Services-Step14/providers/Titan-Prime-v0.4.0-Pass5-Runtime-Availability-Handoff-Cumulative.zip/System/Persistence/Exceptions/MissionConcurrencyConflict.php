<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Persistence\Exceptions;

use RuntimeException;

final class MissionConcurrencyConflict extends RuntimeException
{
    public static function stale(
        string $missionId,
        int $expectedVersion,
        string $expectedStatus,
        int $actualVersion,
        string $actualStatus,
    ): self {
        return new self(sprintf(
            'Prime mission [%s] changed concurrently: expected version/status %d/%s, actual %d/%s.',
            $missionId,
            $expectedVersion,
            $expectedStatus,
            $actualVersion,
            $actualStatus,
        ));
    }
}
