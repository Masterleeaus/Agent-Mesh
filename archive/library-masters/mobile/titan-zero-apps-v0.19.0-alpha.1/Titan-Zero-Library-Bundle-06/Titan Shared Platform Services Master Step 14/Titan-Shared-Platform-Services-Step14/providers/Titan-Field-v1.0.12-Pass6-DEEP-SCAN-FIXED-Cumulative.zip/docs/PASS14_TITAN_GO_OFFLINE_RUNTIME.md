# Pass 14 — Titan Go Offline Field Runtime

Titan Field remains the only operational writer while Titan Go is offline. The mobile API exposes a bounded worker context plus device-bound replay endpoints; queued mutations never write directly to tables on reconnection.

## Server reconciliation contract

Each replay envelope carries `device_id`, `operation_id`, `operation`, `occurred_at`, optional trace/correlation/causation identifiers and, for stateful mutations, `entity_type`, `entity_public_id` and `base_entity_version`. Registered devices are tenant + authenticated-worker scoped and stored only as SHA-256 device hashes.

Stateful operations use optimistic concurrency. A stale version produces a durable `OFFLINE_CONFLICT_ENTITY_VERSION` receipt and does not execute the command. Missing versioned entities produce `OFFLINE_CONFLICT_ENTITY_MISSING`. Append-only notes, time entries and evidence references remain idempotent without forcing artificial version conflicts. Failed operations may be retried only with the exact same request hash; completed/conflict receipts replay deterministically.

## Supported Titan Go operations

- work-order notes and checklist/task status
- work-order status/completion and time entries
- dispatch status, check-in and check-out
- route-stop status
- form responses and submission
- evidence/signature references plus multipart evidence upload
- offline worker-location batches through `SpatialIntelligenceGateway`

All business mutations re-enter `FieldCommandGateway`; schedule/dispatch/work-order policies are therefore re-evaluated on replay. The mobile context supplies assigned work orders, tasks, appointments, active forms and today's route/stops with entity versions and a sync token.

## Spatial replay

When Titan Maps Intelligence is active, delayed GPS is delegated to its peer service. When Maps is absent, Field stores bounded fallback samples. Historical/stale samples are retained as evidence but are excluded from the fallback live-position query. Location replay requires current worker consent and route/shift evidence; samples predating consent are rejected.

## Data safety

`titan_field_offline_devices` and `titan_field_offline_receipts` are retained on uninstall/rollback for audit and reconciliation. Entity-version columns are additive. No destructive down migration is used.
