<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Integrations;

use App\Extensions\Crm\System\Services\CrmIdentityAuthorityService;
use App\Extensions\Crm\System\Support\CrmNormalizer;

final class CrmEmailLinker
{
    public function __construct(private CrmIdentityAuthorityService $identity){}
    public function resolve(int $userId,string $email): ?array
    {
        $normalized=CrmNormalizer::email($email);if($normalized===null)return null;
        $resolved=$this->identity->resolveByIdentity($userId,$normalized,null);if(($resolved['ambiguous']??false)||count($resolved['roots']??[])!==1)return null;
        $matches=(array)($resolved['roots'][0]['matches']??[]);
        foreach(['contact','company','lead'] as $preferred)foreach($matches as $match)if(($match['subject_type']??null)===$preferred)return ['type'=>$preferred,'public_id'=>$match['subject_public_id'],'customer_unification_id'=>$match['customer_unification_id']];
        return null;
    }
}
