<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/SignalSeverity.php';
require __DIR__ . '/../System/Data/SignalActor.php';
require __DIR__ . '/../System/Data/SignalEnvelope.php';
require __DIR__ . '/../System/Data/TraceProfile.php';
require __DIR__ . '/../System/Data/TraceAnalysis.php';
require __DIR__ . '/../System/Services/TraceAnalyzer.php';

use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\TraceProfile;
use App\Extensions\TitanSignalEngine\System\Services\TraceAnalyzer;

function pass3Assert(bool $condition, string $message): void {
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

$root = SignalEnvelope::fromArray([
    'event_id' => '018f6b4e-2a74-7a70-8000-000000000001',
    'event_type' => 'command.requested',
    'tenant_company_id' => 42,
    'source' => 'titan-command-bus',
    'trace_id' => '018f6b4e-2a74-7a70-8000-000000000010',
    'correlation_id' => '018f6b4e-2a74-7a70-8000-000000000020',
    'occurred_at' => '2026-08-12T10:00:00+00:00',
]);
$risk = $root->child('risk.assessed', 'titan-risk-engine', [], [
    'occurred_at' => '2026-08-12T10:02:00+00:00',
]);
$authorized = $risk->child('command.authorized', 'titan-governance', [], [
    // Deliberately earlier than its parent: offline clocks/order must not override causation.
    'occurred_at' => '2026-08-12T09:59:00+00:00',
]);
$executed = $authorized->child('command.executed', 'titan-command-bus', [], [
    'occurred_at' => '2026-08-12T10:03:00+00:00',
]);

$profile = TraceProfile::fromArray([
    'profile_key' => 'governed.command',
    'version' => 1,
    'required_event_types' => [
        'command.requested',
        'risk.assessed',
        'command.authorized',
        'command.executed',
    ],
    'ordering_rules' => [
        ['before' => 'command.requested', 'after' => 'risk.assessed'],
        ['before' => 'risk.assessed', 'after' => 'command.authorized'],
        ['before' => 'command.authorized', 'after' => 'command.executed'],
    ],
]);

$analyzer = new TraceAnalyzer();
$analysis = $analyzer->analyze([$executed, $authorized, $root, $risk], $profile);
pass3Assert($analysis->status === 'complete', 'Valid causal trace must be complete.');
pass3Assert($analysis->missingEventTypes === [], 'Complete trace must have no missing event types.');
pass3Assert($analysis->missingParentEventIds === [], 'Complete trace must have no missing parents.');
pass3Assert($analysis->sequenceViolations === [], 'Causally valid trace must ignore misleading occurred_at ordering.');
pass3Assert(array_map(fn (SignalEnvelope $e): string => $e->eventType, $analysis->orderedEvents) === [
    'command.requested', 'risk.assessed', 'command.authorized', 'command.executed',
], 'Trace ordering must prioritize causation over occurred_at.');

$ancestors = $analyzer->ancestors($executed->eventId, [$root, $risk, $authorized, $executed]);
pass3Assert(array_map(fn (SignalEnvelope $e): string => $e->eventType, $ancestors) === [
    'command.authorized', 'risk.assessed', 'command.requested',
], 'Ancestors must be returned nearest-parent first.');
$descendants = $analyzer->descendants($root->eventId, [$root, $risk, $authorized, $executed]);
pass3Assert(array_map(fn (SignalEnvelope $e): string => $e->eventType, $descendants) === [
    'risk.assessed', 'command.authorized', 'command.executed',
], 'Descendants must follow causal order.');

$missingParent = SignalEnvelope::fromArray([
    'event_id' => '018f6b4e-2a74-7a70-8000-000000000031',
    'event_type' => 'command.executed',
    'tenant_company_id' => 42,
    'source' => 'titan-command-bus',
    'trace_id' => $root->traceId,
    'correlation_id' => $root->correlationId,
    'causation_id' => '018f6b4e-2a74-7a70-8000-000000000099',
    'root_causation_id' => $root->eventId,
]);
$incomplete = $analyzer->analyze([$root, $missingParent], $profile);
pass3Assert($incomplete->status === 'incomplete', 'Missing parent/required events must make trace incomplete.');
pass3Assert(in_array($missingParent->eventId, array_keys($incomplete->missingParentEventIds), true), 'Missing parent must identify the child event.');
pass3Assert(in_array('risk.assessed', $incomplete->missingEventTypes, true), 'Required event absence must be reported.');

$badExecuted = $root->child('command.executed', 'titan-command-bus');
$lateRisk = $badExecuted->child('risk.assessed', 'titan-risk-engine');
$bad = $analyzer->analyze([$root, $badExecuted, $lateRisk], TraceProfile::fromArray([
    'profile_key' => 'bad.command',
    'version' => 1,
    'required_event_types' => ['command.requested', 'risk.assessed', 'command.executed'],
    'ordering_rules' => [['before' => 'risk.assessed', 'after' => 'command.executed']],
]));
pass3Assert($bad->status === 'incomplete', 'Illegal sequence must make trace incomplete.');
pass3Assert(count($bad->sequenceViolations) === 1, 'Illegal sequence must be reported exactly once.');

$aId = '018f6b4e-2a74-7a70-8000-000000000041';
$bId = '018f6b4e-2a74-7a70-8000-000000000042';
$a = SignalEnvelope::fromArray([
    'event_id' => $aId,
    'event_type' => 'cycle.a',
    'tenant_company_id' => 42,
    'source' => 'test',
    'trace_id' => $root->traceId,
    'correlation_id' => $root->correlationId,
    'causation_id' => $bId,
    'root_causation_id' => $aId,
]);
$b = SignalEnvelope::fromArray([
    'event_id' => $bId,
    'event_type' => 'cycle.b',
    'tenant_company_id' => 42,
    'source' => 'test',
    'trace_id' => $root->traceId,
    'correlation_id' => $root->correlationId,
    'causation_id' => $aId,
    'root_causation_id' => $aId,
]);
$cycle = $analyzer->analyze([$a, $b], null);
pass3Assert($cycle->causalCycleEventIds !== [], 'Causal cycles must be detected even without a trace profile.');
pass3Assert($cycle->status === 'invalid', 'Causal cycle must mark trace invalid.');

$terminalMissing = $analyzer->analyze([$root], TraceProfile::fromArray([
    'profile_key' => 'terminal.required',
    'version' => 1,
    'required_event_types' => ['command.requested'],
    'terminal_event_types' => ['execution.receipt', 'command.failed'],
]));
pass3Assert($terminalMissing->status === 'incomplete', 'Trace without any allowed terminal event must be incomplete.');
pass3Assert(($terminalMissing->profileViolations[0]['code'] ?? null) === 'terminal_event_missing', 'Missing terminal event must have an explicit profile violation.');

fwrite(STDOUT, "correlation-engine-behavior: PASS\n");
