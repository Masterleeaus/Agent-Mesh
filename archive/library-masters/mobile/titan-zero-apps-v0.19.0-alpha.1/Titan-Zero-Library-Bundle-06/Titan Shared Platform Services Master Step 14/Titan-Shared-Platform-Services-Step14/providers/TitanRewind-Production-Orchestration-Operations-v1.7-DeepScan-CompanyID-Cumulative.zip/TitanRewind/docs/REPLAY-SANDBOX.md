# Replay sandbox

Current Rewind replay/comparison is structural and mutation-free. A rejecting command gateway is actively used by comparative replay; any configuration that would permit mutation causes `REPLAY_BOUNDARY_VIOLATION`. Network policy is recorded as `deny-all` or `recorded-only`, and comparison results explicitly report `decision_reexecution_performed=false`.

The final executable replay runtime will additionally require a virtual clock, deterministic random seed, recorded/allowlisted provider responses and exact historical artifact resolvers. Those future components must not weaken the existing rejecting Command Bus boundary.
