<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models\Concerns;

use Illuminate\Database\Eloquent\Builder;
use InvalidArgumentException;
use LogicException;

trait BelongsToCompany
{
    public static function bootBelongsToCompany(): void
    {
        static::creating(static function ($model): void {
            if (! is_numeric($model->company_id) || (int) $model->company_id <= 0) {
                throw new LogicException('A positive company_id is required for Titan Connect company-owned records.');
            }
        });

        static::updating(static function ($model): void {
            if ($model->isDirty('company_id') && (int) $model->getOriginal('company_id') !== (int) $model->company_id) {
                throw new LogicException('company_id cannot be changed after a Titan Connect record is created.');
            }
        });
    }

    public function companyId(): int
    {
        $companyId = $this->getAttribute('company_id');
        if (! is_numeric($companyId) || (int) $companyId <= 0) {
            throw new LogicException('Titan Connect company-owned record has no valid company_id.');
        }

        return (int) $companyId;
    }

    public function scopeForCompany(Builder $query, int $companyId): Builder
    {
        if ($companyId <= 0) {
            throw new InvalidArgumentException('company_id must be a positive integer.');
        }

        return $query->where($query->getModel()->qualifyColumn('company_id'), $companyId);
    }
}
