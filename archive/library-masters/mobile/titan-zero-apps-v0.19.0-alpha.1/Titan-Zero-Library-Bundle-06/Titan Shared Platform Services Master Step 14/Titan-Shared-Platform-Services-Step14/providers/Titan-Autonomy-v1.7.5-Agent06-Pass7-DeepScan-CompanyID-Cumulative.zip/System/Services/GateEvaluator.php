<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\DTOs\EvidenceSnapshot;
use App\Extensions\TitanAutonomy\System\DTOs\GateEvaluation;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\RiskClass;

final class GateEvaluator
{
    public function __construct(private readonly array $minimums, private readonly array $ceilings) {}

    public function evaluate(
        RiskClass $risk,
        AutonomyLevel $currentLevel,
        AutonomyLevel $requestedLevel,
        EvidenceSnapshot $evidence,
        bool $capabilitySupportsLevel = true,
        bool $tenantAllowsLevel = true,
    ): GateEvaluation {
        $reasons = [];
        if ($requestedLevel !== $currentLevel->next()) $reasons[] = 'INVALID_NEXT_LEVEL';
        if (!$capabilitySupportsLevel) $reasons[] = 'CAPABILITY_LEVEL_UNSUPPORTED';
        if (!$tenantAllowsLevel) $reasons[] = 'TENANT_POLICY_DENIED';
        if (!$evidence->sampleRequirementsSatisfied) $reasons[] = 'SAMPLE_REQUIREMENTS_INSUFFICIENT';
        if (!$evidence->failureRateWithinLimit) $reasons[] = 'FAILURE_RATE_TOO_HIGH';
        if (!$evidence->reversalRateWithinLimit) $reasons[] = 'REVERSAL_RATE_TOO_HIGH';
        if (!$evidence->correctionRateWithinLimit) $reasons[] = 'CORRECTION_RATE_TOO_HIGH';
        if (!$evidence->contextConfidenceSatisfied) $reasons[] = 'CONTEXT_CONFIDENCE_INSUFFICIENT';
        if (!$evidence->dataSourcesAvailable) $reasons[] = 'REQUIRED_DATA_UNAVAILABLE';
        if (!$evidence->scopeValid) $reasons[] = 'SCOPE_INVALID';
        if (!$evidence->permissionsValid) $reasons[] = 'PERMISSIONS_INVALID';
        if (!$evidence->integrationHealthy) $reasons[] = 'INTEGRATION_UNHEALTHY';
        if ($evidence->hasUnresolvedIncident) $reasons[] = 'UNRESOLVED_INCIDENT';
        if ($evidence->safetySuspended) $reasons[] = 'SAFETY_SUSPENDED';
        if ($evidence->autonomyHold) $reasons[] = 'AUTONOMY_HOLD';
        if ($evidence->assuranceAmber) $reasons[] = 'ASSURANCE_AMBER_REVIEW_REQUIRED';
        if ($evidence->assuranceRed) $reasons[] = 'ASSURANCE_RED';

        $rawCeiling = $this->ceilings[$risk->value] ?? 'assist';
        $ceiling = is_int($rawCeiling)
            ? AutonomyLevel::from($rawCeiling)
            : match ($rawCeiling) {
                'suggest' => AutonomyLevel::Suggest,
                'assist' => AutonomyLevel::Assist,
                'semi_auto' => AutonomyLevel::SemiAuto,
                'auto' => AutonomyLevel::Auto,
                'trusted_auto' => AutonomyLevel::TrustedAuto,
                default => AutonomyLevel::Assist,
            };
        if ($requestedLevel->value > $ceiling->value) $reasons[] = 'RISK_CEILING';

        $required = $risk === RiskClass::Critical
            ? (int) ($this->minimums['critical'] ?? $this->minimums['high'] ?? 3)
            : (int) ($this->minimums[$risk->value] ?? PHP_INT_MAX);
        if ($evidence->currentSuccessStreak < $required) {
            $reasons[] = 'SUCCESS_STREAK_INSUFFICIENT';
        }

        return new GateEvaluation($reasons === [], $required, array_values(array_unique($reasons)));
    }
}
