<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Enums;

enum KnowledgeScopeType: string
{
    case Platform = 'platform';
    case Jurisdiction = 'jurisdiction';
    case Tenant = 'tenant';
}
