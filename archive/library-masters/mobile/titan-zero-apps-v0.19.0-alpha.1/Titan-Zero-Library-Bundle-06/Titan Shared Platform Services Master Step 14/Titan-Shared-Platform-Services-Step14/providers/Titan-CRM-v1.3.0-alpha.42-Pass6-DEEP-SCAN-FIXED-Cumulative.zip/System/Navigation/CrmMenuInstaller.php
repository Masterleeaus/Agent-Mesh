<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Navigation;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class CrmMenuInstaller
{
    /** Icons verified in the current Titan/MagicAI host menu stack. */
    private const HOST_SAFE_ICONS = [
        'tabler-layout-dashboard','tabler-users','tabler-folders','tabler-device-mobile','tabler-photo',
        'tabler-palette','tabler-plug-connected','tabler-shield-lock','tabler-settings','tabler-command',
        'tabler-directions','tabler-tool','tabler-components','tabler-category','tabler-stethoscope',
        'tabler-inbox','tabler-message-cog','tabler-message','tabler-phone-call','tabler-bell-ringing',
        'tabler-users-group','tabler-world','tabler-user-check','tabler-user-question','tabler-hand-stop',
        'tabler-archive','tabler-address-book','tabler-building','tabler-coin','tabler-briefcase',
        'tabler-checklist','tabler-calendar','tabler-presentation','tabler-chart-bar','tabler-receipt',
        'tabler-file-invoice','tabler-cash','tabler-file-text','tabler-calculator','tabler-share',
        'tabler-trending-up','tabler-user-plus','tabler-briefcase-2','tabler-columns','tabler-file-description',
        'tabler-checkbox','tabler-report-analytics','tabler-copy-check','tabler-robot','tabler-sparkles','tabler-bolt',
    ];

    /** Known historical CRM-owned menu keys retired after domain extraction/restructure. */
    private const RETIRED_MENU_KEYS = [
        'crm_dashboard','crm_sales_payments','crm_bookkeeping','crm_collections','crm_receivables','crm_titan_pay',
        'crm_field_overview','crm_service_requests','crm_work_orders','crm_agreements','crm_catalogue','crm_service_locations',
        'crm_forms','crm_service_areas','crm_verticals','crm_support','crm_reviews','crm_customer_assets','crm_timesheets',
        'ext_crm_crew','crm_schedule','crm_dispatch','ext_crm_gear','crm_locker','crm_locker_purchase_orders',
        'crm_locker_goods_receipts','crm_locker_stock_counts','crm_locker_stock_transfers','crm_inventory','crm_stock_locations',
        'crm_stock_control','crm_stock_reservations','crm_reorder','crm_suppliers','crm_tools','crm_equipment','crm_fleet',
        'crm_maintenance','crm_autonomy_learning','crm_autonomy_control',
    ];
    public static function sync(): void
    {
        self::syncDefinition(CrmMenuDefinition::all());
        self::deactivate(self::RETIRED_MENU_KEYS);
        self::invalidateHostMenuCache();
    }

    public static function rollback(): void
    {
        if (! Schema::hasTable('menus')) {
            return;
        }

        self::syncDefinition(CrmMenuDefinition::legacy());

        $legacyKeys = self::keys(CrmMenuDefinition::legacy());
        $newKeys = array_values(array_diff(self::keys(CrmMenuDefinition::all()), $legacyKeys));
        if ($newKeys !== [] && Schema::hasColumn('menus', 'is_active')) {
            $updates = ['is_active' => 0];
            if (Schema::hasColumn('menus', 'updated_at')) {
                $updates['updated_at'] = now();
            }
            DB::table('menus')->whereIn('key', $newKeys)->update($updates);
        }
        self::invalidateHostMenuCache();
    }

    /** @param array<int,array<string,mixed>> $definition */
    private static function syncDefinition(array $definition): void
    {
        if (! Schema::hasTable('menus')) {
            return;
        }

        $columns = array_flip(Schema::getColumnListing('menus'));
        if (! isset($columns['key'])) {
            return;
        }

        foreach ($definition as $root) {
            self::upsert($root, null, $columns);
            $parentId = isset($columns['id']) ? DB::table('menus')->where('key', $root['key'])->value('id') : null;
            if ($parentId === null && ($root['children'] ?? []) !== []) {
                continue;
            }
            foreach ($root['children'] ?? [] as $index => $child) {
                $child['order'] = $child['order'] ?? ($index + 1);
                self::upsert($child, $parentId, $columns);
            }
        }
    }

    /** @param array<string,mixed> $item @param array<string,int> $columns */
    private static function upsert(array $item, mixed $parentId, array $columns): void
    {
        $data = [
            'parent_id' => $parentId,
            'route' => $item['route'] ?? null,
            'route_slug' => null,
            'label' => $item['label'] ?? $item['key'],
            'icon' => self::safeIcon((string) ($item['icon'] ?? '')),
            'svg' => null,
            'order' => (int) ($item['order'] ?? 0),
            'is_active' => 1,
            'params' => '[]',
            'type' => 'item',
            'badge' => null,
            'extension' => '1',
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
            'updated_at' => now(),
            'custom_menu' => 0,
        ];
        $data = array_intersect_key($data, $columns);
        $query = DB::table('menus')->where('key', $item['key']);
        if ($query->exists()) {
            $query->update($data);
            return;
        }

        $insert = ['key' => $item['key']] + $data;
        if (isset($columns['created_at'])) {
            $insert['created_at'] = now();
        }
        DB::table('menus')->insert(array_intersect_key($insert, $columns));
    }


    private static function safeIcon(string $icon): string
    {
        return in_array($icon, self::HOST_SAFE_ICONS, true) ? $icon : 'tabler-folders';
    }

    /** @param array<int,string> $keys */
    private static function deactivate(array $keys): void
    {
        if ($keys === [] || ! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'is_active')) {
            return;
        }
        $updates = ['is_active' => 0];
        if (Schema::hasColumn('menus', 'updated_at')) {
            $updates['updated_at'] = now();
        }
        DB::table('menus')->whereIn('key', $keys)->update($updates);
    }

    private static function invalidateHostMenuCache(): void
    {
        if (! class_exists(\App\Services\Common\MenuService::class)) {
            return;
        }

        try {
            $menuService = app(\App\Services\Common\MenuService::class);
            if (method_exists($menuService, 'regenerate')) {
                $menuService->regenerate();
            }
        } catch (\Throwable) {
            // Menu data is already persisted. Cache invalidation must never block extension install/rollback.
        }
    }

    /** @param array<int,array<string,mixed>> $definition @return array<int,string> */
    private static function keys(array $definition): array
    {
        $keys = [];
        foreach ($definition as $root) {
            $keys[] = (string) $root['key'];
            foreach ($root['children'] ?? [] as $child) {
                $keys[] = (string) $child['key'];
            }
        }
        return array_values(array_unique($keys));
    }
}
