<?php
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Contracts\CompanyRepositoryContract; use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway; use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class CompanyController extends Controller
{
    public function __construct(private CompanyRepositoryContract $companies, private CrmHumanMutationGateway $mutations) {}
    public function index(Request $r){$records=$this->companies->search((int)$r->user()->id,$r->only(['q','limit']));return $r->expectsJson()?response()->json(['data'=>$records]):view('crm::list',['title'=>'Companies','records'=>$records]);}
    public function store(Request $r){$data=$r->validate(['name'=>'required|string|max:190','legal_name'=>'nullable|string|max:190','website'=>'nullable|string|max:255','email'=>'nullable|email|max:190','phone'=>'nullable|string|max:60','address'=>'nullable|string','notes'=>'nullable|string','status'=>'nullable|string|max:32','owner_user_id'=>'nullable|integer']);return response()->json($this->mutations->execute($r,'crm.company.create',$data),201);}
    public function update(Request $r,string $company){$data=$r->validate(['name'=>'required|string|max:190','legal_name'=>'nullable|string|max:190','website'=>'nullable|string|max:255','email'=>'nullable|email|max:190','phone'=>'nullable|string|max:60','address'=>'nullable|string','notes'=>'nullable|string','status'=>'nullable|string|max:32','owner_user_id'=>'nullable|integer']);$record=$this->mutations->execute($r,'crm.company.update',$data+['public_id'=>$company]);return $r->expectsJson()?response()->json($record):back()->with('status','Company updated.');}
}
