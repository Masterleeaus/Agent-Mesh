<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System;

use App\Extensions\TitanAutonomy\System\Contracts\AssuranceBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\AutonomyAuditSinkContract;
use App\Extensions\TitanAutonomy\System\Contracts\AutonomyControlStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;
use App\Extensions\TitanAutonomy\System\Contracts\CapabilityStateStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\CommandBusBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\ControlPlaneAuditSinkContract;
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\InteractionEngineBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\LearningSinkContract;
use App\Extensions\TitanAutonomy\System\Contracts\RewindBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\TitanAiRuntimeBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\ExecutionReceiptStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\ExecutionReceiptReconcilerContract;
use App\Extensions\TitanAutonomy\System\Contracts\OperationsQueryContract;
use App\Extensions\TitanAutonomy\System\Contracts\OperationsReviewStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\ExecutionPostconditionVerifierContract;
use App\Extensions\TitanAutonomy\System\Contracts\ExecutionReconciliationContract;
use App\Extensions\TitanAutonomy\System\Contracts\TenantRecordLookupContract;
use App\Extensions\TitanAutonomy\System\Contracts\TenantAssuranceBridgeContract;
use App\Extensions\TitanAutonomy\System\Infrastructure\DatabaseAutonomyAuditSink;
use App\Extensions\TitanAutonomy\System\Infrastructure\DatabaseAutonomyControlStore;
use App\Extensions\TitanAutonomy\System\Infrastructure\DatabaseAutonomyQuery;
use App\Extensions\TitanAutonomy\System\Infrastructure\DatabaseCapabilityStateStore;
use App\Extensions\TitanAutonomy\System\Infrastructure\DatabaseControlPlaneAuditSink;
use App\Extensions\TitanAutonomy\System\Infrastructure\DatabaseLearningSink;
use App\Extensions\TitanAutonomy\System\Infrastructure\DatabaseExecutionReceiptStore;
use App\Extensions\TitanAutonomy\System\Infrastructure\DatabaseOperationsQuery;
use App\Extensions\TitanAutonomy\System\Infrastructure\DatabaseOperationsReviewStore;
use App\Extensions\TitanAutonomy\System\Infrastructure\CrmTenantRecordLookup;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableExecutionPostconditionVerifier;
use App\Extensions\TitanAutonomy\System\Infrastructure\LaravelAuthHostContextBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\CrmCompanyHostContextBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\InteractionEngineLiveBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\InteractionCommandBusLiveBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\InteractionDelegatedAuthorityVerifier;
use App\Extensions\TitanAutonomy\System\Infrastructure\ModelCouncilAssuranceBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\ModelCouncilTenantAssuranceBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\TitanAiRuntimeLiveBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableTitanAiRuntimeBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableAssuranceBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableTenantAssuranceBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableCommandBusBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableInteractionEngineBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableRewindBridge;
use App\Extensions\TitanAutonomy\System\Services\AutonomyGrantService;
use App\Extensions\TitanAutonomy\System\Services\AutonomyRuntimeService;
use App\Extensions\TitanAutonomy\System\Services\GateEvaluator;
use App\Extensions\TitanAutonomy\System\Services\LearningResetService;
use App\Extensions\TitanAutonomy\System\Services\LearningSettingsService;
use App\Extensions\TitanAutonomy\System\Services\ManualRegressionService;
use App\Extensions\TitanAutonomy\System\Services\PlatformPolicyService;
use App\Extensions\TitanAutonomy\System\Services\AssuranceAssessmentRequestService;
use App\Extensions\TitanAutonomy\System\Services\GovernedHostExecutionService;
use App\Extensions\TitanAutonomy\System\Services\DelegatedAuthorityEnvelopeService;
use App\Extensions\TitanAutonomy\System\Services\LiveGovernedCapabilityRegistry;
use App\Extensions\TitanAutonomy\System\Services\TrustedAutoReviewService;
use App\Extensions\TitanAutonomy\System\Services\HostBridgeStatusService;
use App\Extensions\TitanAutonomy\System\Services\RewindCorrelationService;
use App\Extensions\TitanAutonomy\System\Services\CrmExecutionPostconditionVerifier;
use App\Extensions\TitanAutonomy\System\Services\ExecutionReconciliationService;
use App\Extensions\TitanAutonomy\System\Services\ExecutionFeedbackService;
use App\Extensions\TitanAutonomy\System\Services\AutonomyOperationsService;
use App\Extensions\TitanAutonomy\System\Services\OperationsRecheckService;
use App\Extensions\TitanAutonomy\System\Services\OperationsReviewService;
use App\Extensions\TitanAutonomy\System\Console\ReconcileAutonomyExecutionsCommand;
use App\Extensions\TitanAutonomy\System\Commands\CertifyExtensionCommand;
use App\Extensions\TitanAutonomy\System\Workforce\WorkforceProviderRuntimeContract;
use App\Extensions\TitanAutonomy\System\Workforce\PackageWorkforceProviderAdapter;
use App\Extensions\TitanAutonomy\System\Workforce\ProviderHealthStoreContract;
use App\Extensions\TitanAutonomy\System\Workforce\LaravelCacheProviderHealthStore;
use App\Extensions\TitanAutonomy\System\Workforce\ProviderHealthRegistry;
use App\Extensions\TitanAutonomy\System\Workforce\CapabilityResolver;
use App\Extensions\TitanAutonomy\System\Workforce\ProviderSelector;
use App\Extensions\TitanAutonomy\System\Workforce\WorkforceProviderContribution;
use App\Extensions\TitanAutonomy\System\Workforce\WorkforceProviderEventEmitter;
use App\Extensions\TitanAutonomy\System\Workforce\ProviderHealthProbeContract;
use App\Extensions\TitanAutonomy\System\Workforce\ProviderHealthProbe;
use App\Extensions\TitanAutonomy\System\Workforce\ProviderHealthRefreshService;
use App\Extensions\TitanAutonomy\System\Workforce\WorkforceProviderStatusService;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\ServiceProvider;

final class TitanAutonomyServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        
        $this->app->singleton(ProviderHealthProbeContract::class, fn($app): ProviderHealthProbeContract => new ProviderHealthProbe(
            $app->make(WorkforceProviderRuntimeContract::class),
            $app
        ));
        $this->app->singleton(ProviderHealthRefreshService::class, fn($app): ProviderHealthRefreshService => new ProviderHealthRefreshService(
            $app->make(ProviderHealthProbeContract::class),
            $app->make(ProviderHealthStoreContract::class),
            $app->make(WorkforceProviderEventEmitter::class),
        ));
        $this->app->singleton(WorkforceProviderStatusService::class, fn($app): WorkforceProviderStatusService => new WorkforceProviderStatusService(
            $app->make(WorkforceProviderRuntimeContract::class),
            $app->make(ProviderHealthStoreContract::class),
        ));
// Agent-06 Pass 5: host-facing Workforce provider registration.
        $this->app->singleton(WorkforceProviderRuntimeContract::class, fn(): WorkforceProviderRuntimeContract => PackageWorkforceProviderAdapter::fromPackageRoot(dirname(__DIR__)));
        $this->app->singleton(ProviderHealthStoreContract::class, fn($app): ProviderHealthStoreContract => new LaravelCacheProviderHealthStore($app->make('cache.store')));
        $this->app->singleton(ProviderHealthRegistry::class, fn($app): ProviderHealthRegistry => new ProviderHealthRegistry($app->make(ProviderHealthStoreContract::class)));
        $this->app->singleton(CapabilityResolver::class, fn($app): CapabilityResolver => new CapabilityResolver($app->make(ProviderHealthRegistry::class)));
        $this->app->singleton(ProviderSelector::class);
        $this->app->singleton(WorkforceProviderEventEmitter::class, fn($app): WorkforceProviderEventEmitter => new WorkforceProviderEventEmitter($app->make('events')));
        $this->app->singleton(WorkforceProviderContribution::class, fn($app): WorkforceProviderContribution => new WorkforceProviderContribution(
            $app->make(WorkforceProviderRuntimeContract::class),
            $app->make(ProviderHealthStoreContract::class),
            $app->make(CapabilityResolver::class),
            $app->make(ProviderSelector::class),
        ));
        $this->app->tag([WorkforceProviderContribution::class], 'titan.workforce.providers');

        $this->mergeConfigFrom(__DIR__ . '/../config/autonomy.php', 'titan-autonomy');

        if (!$this->app->bound(HostContextBridgeContract::class)) {
            $this->app->singleton(HostContextBridgeContract::class, function (): HostContextBridgeContract {
                return class_exists(\App\Extensions\Crm\System\Tenancy\CrmCompanyScope::class)
                    ? new CrmCompanyHostContextBridge()
                    : new LaravelAuthHostContextBridge();
            });
        }
        if (!$this->app->bound(AssuranceBridgeContract::class)) {
            $this->app->singleton(AssuranceBridgeContract::class, function ($app): AssuranceBridgeContract {
                return class_exists(\App\Extensions\ModelCouncil\System\Models\AssuranceRun::class)
                    ? new ModelCouncilAssuranceBridge($app->make(HostContextBridgeContract::class))
                    : new UnavailableAssuranceBridge();
            });
        }

        if (!$this->app->bound(TenantAssuranceBridgeContract::class)) {
            $this->app->singleton(TenantAssuranceBridgeContract::class, function (): TenantAssuranceBridgeContract {
                return class_exists(\App\Extensions\ModelCouncil\System\Models\AssuranceRun::class)
                    ? new ModelCouncilTenantAssuranceBridge()
                    : new UnavailableTenantAssuranceBridge();
            });
        }
        if (!$this->app->bound(InteractionEngineBridgeContract::class)) {
            $this->app->singleton(InteractionEngineBridgeContract::class, function ($app): InteractionEngineBridgeContract {
                $contract = \App\Extensions\InteractionEngine\System\Contracts\InteractionEngineManagerContract::class;
                $router = \App\Extensions\InteractionEngine\System\Capabilities\CapabilityRouter::class;
                if (!interface_exists($contract) || !class_exists($router) || !$app->bound($contract)) {
                    return new UnavailableInteractionEngineBridge();
                }
                $sessionStore = \App\Extensions\InteractionEngine\System\Wizard\Storage\WizardSessionStoreInterface::class;
                $commandMapper = \App\Extensions\InteractionEngine\System\Wizard\Command\CommandMapper::class;
                return new InteractionEngineLiveBridge(
                    $app->make($contract),
                    $app->make($router),
                    $app->make(HostContextBridgeContract::class),
                    interface_exists($sessionStore) && $app->bound($sessionStore) ? $app->make($sessionStore) : null,
                    class_exists($commandMapper) && $app->bound($commandMapper) ? $app->make($commandMapper) : null,
                );
            });
        }
        if (!$this->app->bound(CommandBusBridgeContract::class)) {
            $this->app->singleton(CommandBusBridgeContract::class, function ($app): CommandBusBridgeContract {
                $busContract = \App\Extensions\InteractionEngine\System\Contracts\CommandBusInterface::class;
                $bus = \App\Extensions\InteractionEngine\System\Command\CommandBus::class;
                if (!interface_exists($busContract) || !class_exists($bus) || !$app->bound($busContract)) {
                    return new UnavailableCommandBusBridge();
                }
                return new InteractionCommandBusLiveBridge(
                    $app->make($bus),
                    $app->make(HostContextBridgeContract::class),
                );
            });
        }
        if (!$this->app->bound(TitanAiRuntimeBridgeContract::class)) {
            $this->app->singleton(TitanAiRuntimeBridgeContract::class, function ($app): TitanAiRuntimeBridgeContract {
                $runtimeContract = \App\Extensions\TitanAI\System\TitanAI\Contracts\TitanAIRuntimeContract::class;
                if (!interface_exists($runtimeContract) || !$app->bound($runtimeContract)) {
                    return new UnavailableTitanAiRuntimeBridge();
                }
                return new TitanAiRuntimeLiveBridge($app->make($runtimeContract));
            });
        }
        if (!$this->app->bound(RewindBridgeContract::class)) {
            $this->app->singleton(RewindBridgeContract::class, UnavailableRewindBridge::class);
        }

        $this->app->singleton(RewindCorrelationService::class);
        $this->app->singleton(AutonomyQueryContract::class, DatabaseAutonomyQuery::class);
        $this->app->singleton(AutonomyControlStoreContract::class, DatabaseAutonomyControlStore::class);
        $this->app->singleton(ControlPlaneAuditSinkContract::class, DatabaseControlPlaneAuditSink::class);
        $this->app->singleton(ExecutionReceiptStoreContract::class, DatabaseExecutionReceiptStore::class);
        $this->app->singleton(OperationsQueryContract::class, DatabaseOperationsQuery::class);
        $this->app->singleton(OperationsReviewStoreContract::class, DatabaseOperationsReviewStore::class);
        $this->app->singleton(TenantRecordLookupContract::class, CrmTenantRecordLookup::class);
        $this->app->singleton(ExecutionPostconditionVerifierContract::class, function ($app): ExecutionPostconditionVerifierContract {
            return class_exists(\App\Extensions\Crm\System\Capabilities\CrmCapabilityExecutor::class)
                ? new CrmExecutionPostconditionVerifier($app->make(TenantRecordLookupContract::class))
                : new UnavailableExecutionPostconditionVerifier();
        });
        $this->app->singleton(DelegatedAuthorityEnvelopeService::class, function ($app): DelegatedAuthorityEnvelopeService {
            $config = $app['config']->get('titan-autonomy', []);
            return new DelegatedAuthorityEnvelopeService(
                (string) config('app.key'),
                (string) ($config['policy_version'] ?? 'unknown'),
                (int) ($config['delegated_authority']['ttl_seconds'] ?? 90),
                $app->make(ControlPlaneAuditSinkContract::class),
            );
        });

        $delegatedVerifierContract = \App\Extensions\InteractionEngine\System\Contracts\DelegatedAuthorityVerifierInterface::class;
        if (interface_exists($delegatedVerifierContract)) {
            $this->app->singleton($delegatedVerifierContract, fn ($app) => new InteractionDelegatedAuthorityVerifier(
                $app->make(DelegatedAuthorityEnvelopeService::class),
                $app->make(AutonomyQueryContract::class),
                $app->make(\App\Extensions\TitanAutonomy\System\Services\GateReviewService::class),
                $app->make(HostContextBridgeContract::class),
            ));
        }

        $this->app->singleton(GateEvaluator::class, function ($app): GateEvaluator {
            $config = $app['config']->get('titan-autonomy', []);
            return new GateEvaluator(
                $config['gate_minimums'] ?? ['low' => 1, 'medium' => 2, 'high' => 3, 'critical' => 3],
                $config['maximum_level_by_risk'] ?? ['low' => 'trusted_auto', 'medium' => 'trusted_auto', 'high' => 'auto', 'critical' => 'semi_auto'],
            );
        });

        $this->app->singleton(CapabilityStateStoreContract::class, function ($app): CapabilityStateStoreContract {
            $config = $app['config']->get('titan-autonomy', []);
            return new DatabaseCapabilityStateStore(
                $config['maximum_level_by_risk'] ?? ['low' => 'trusted_auto', 'medium' => 'trusted_auto', 'high' => 'auto', 'critical' => 'semi_auto'],
            );
        });

        $this->app->singleton(AutonomyAuditSinkContract::class, fn ($app): AutonomyAuditSinkContract =>
            new DatabaseAutonomyAuditSink($app->make(RewindCorrelationService::class))
        );
        $this->app->singleton(LearningSinkContract::class, fn ($app): LearningSinkContract =>
            new DatabaseLearningSink($app->make(RewindCorrelationService::class))
        );

        $this->app->singleton(AutonomyRuntimeService::class, function ($app): AutonomyRuntimeService {
            $config = $app['config']->get('titan-autonomy', []);
            return new AutonomyRuntimeService(
                stateStore: $app->make(CapabilityStateStoreContract::class),
                learningSink: $app->make(LearningSinkContract::class),
                auditSink: $app->make(AutonomyAuditSinkContract::class),
                gateEvaluator: $app->make(GateEvaluator::class),
                policyVersion: (string) ($config['policy_version'] ?? 'unknown'),
            );
        });

        $this->app->singleton(ExecutionReconciliationService::class, function ($app): ExecutionReconciliationService {
            $config = $app['config']->get('titan-autonomy', []);
            return new ExecutionReconciliationService(
                $app->make(ExecutionReceiptStoreContract::class),
                $app->make(ExecutionPostconditionVerifierContract::class),
                $app->make(AutonomyRuntimeService::class),
                $app->make(AutonomyQueryContract::class),
                $app->make(TenantAssuranceBridgeContract::class),
                (string)($config['policy_version'] ?? 'unknown'),
                (array)($config['outcome_reconciliation']['window_minutes_by_risk'] ?? ['low'=>15,'medium'=>60,'high'=>240,'critical'=>null]),
            );
        });
        $this->app->alias(ExecutionReconciliationService::class, ExecutionReconciliationContract::class);
        $this->app->alias(ExecutionReconciliationService::class, ExecutionReceiptReconcilerContract::class);
        $this->app->singleton(ExecutionFeedbackService::class, function ($app): ExecutionFeedbackService {
            $config = $app['config']->get('titan-autonomy', []);
            return new ExecutionFeedbackService(
                $app->make(ExecutionReceiptStoreContract::class),
                $app->make(AutonomyQueryContract::class),
                $app->make(AutonomyRuntimeService::class),
                (string)($config['policy_version'] ?? 'unknown'),
            );
        });
        $this->app->singleton(AutonomyOperationsService::class);
        $this->app->singleton(OperationsReviewService::class, function ($app): OperationsReviewService {
            $config = $app['config']->get('titan-autonomy', []);
            return new OperationsReviewService(
                $app->make(OperationsQueryContract::class),
                $app->make(OperationsReviewStoreContract::class),
                $app->make(ControlPlaneAuditSinkContract::class),
                (string)($config['policy_version'] ?? 'unknown'),
            );
        });
        $this->app->singleton(OperationsRecheckService::class, function ($app): OperationsRecheckService {
            $config = $app['config']->get('titan-autonomy', []);
            return new OperationsRecheckService(
                $app->make(OperationsQueryContract::class),
                $app->make(ExecutionReceiptReconcilerContract::class),
                $app->make(ControlPlaneAuditSinkContract::class),
                (string)($config['policy_version'] ?? 'unknown'),
            );
        });

        $this->app->singleton(AutonomyGrantService::class, function ($app): AutonomyGrantService {
            $config = $app['config']->get('titan-autonomy', []);
            return new AutonomyGrantService(
                stateStore: $app->make(CapabilityStateStoreContract::class),
                auditSink: $app->make(AutonomyAuditSinkContract::class),
                policyVersion: (string) ($config['policy_version'] ?? 'unknown'),
                controlAudit: $app->make(ControlPlaneAuditSinkContract::class),
            );
        });

        $this->app->singleton(LiveGovernedCapabilityRegistry::class);
        $this->app->singleton(GovernedHostExecutionService::class, fn ($app): GovernedHostExecutionService => new GovernedHostExecutionService(
            $app->make(HostContextBridgeContract::class),
            $app->make(LiveGovernedCapabilityRegistry::class),
            $app->make(\App\Extensions\TitanAutonomy\System\Services\ExecutionAuthorityGuard::class),
            $app->make(InteractionEngineBridgeContract::class),
            $app->make(CommandBusBridgeContract::class),
            $app->make(AssuranceBridgeContract::class),
            $app->make(\App\Extensions\TitanAutonomy\System\Services\GateReviewService::class),
            delegation: $app->make(DelegatedAuthorityEnvelopeService::class),
            reconciliation: $app->make(ExecutionReconciliationContract::class),
        ));
        $this->app->singleton(TrustedAutoReviewService::class, function ($app): TrustedAutoReviewService {
            $config = $app['config']->get('titan-autonomy', []);
            return new TrustedAutoReviewService(
                $app->make(AutonomyQueryContract::class),
                $app->make(\App\Extensions\TitanAutonomy\System\Services\GateReviewService::class),
                $app->make(AutonomyGrantService::class),
                $app->make(AssuranceBridgeContract::class),
                $app->make(TitanAiRuntimeBridgeContract::class),
                $app->make(\App\Extensions\TitanAutonomy\System\Services\AiAssuranceReliabilityEvaluator::class),
                (float) ($config['trusted_auto']['minimum_ai_confidence'] ?? 0.85),
            );
        });
        $this->app->singleton(AssuranceAssessmentRequestService::class, function ($app): AssuranceAssessmentRequestService {
            $engineContract = \App\Extensions\ModelCouncil\System\Contracts\AssuranceEngine::class;
            $engine = interface_exists($engineContract) && $app->bound($engineContract) ? $app->make($engineContract) : null;
            $config = $app['config']->get('titan-autonomy', []);
            return new AssuranceAssessmentRequestService(
                $engine,
                $app->make(HostContextBridgeContract::class),
                (string) ($config['policy_version'] ?? 'unknown'),
            );
        });

        foreach ([
            LearningSettingsService::class,
            LearningResetService::class,
            ManualRegressionService::class,
            PlatformPolicyService::class,
        ] as $service) {
            $this->app->singleton($service, function ($app) use ($service) {
                $config = $app['config']->get('titan-autonomy', []);
                return new $service(
                    $app->make(AutonomyControlStoreContract::class),
                    (string) ($config['policy_version'] ?? 'unknown'),
                    $app->make(ControlPlaneAuditSinkContract::class),
                );
            });
        }
    }

    public function boot(): void
    {
        // Titan registers providers before extension migrations. Do not query
        // autonomy tables here. Runtime repositories resolve only after the
        // extension has completed its installer migration stage.
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-autonomy');
        $this->loadRoutesFrom(__DIR__ . '/../routes/web.php');
        if ($this->app->runningInConsole()) {
            $this->commands([ReconcileAutonomyExecutionsCommand::class, CertifyExtensionCommand::class]);
        }
        $this->app->booted(function (): void {
            if (!(bool)config('titan-autonomy.outcome_reconciliation.schedule_enabled', true)) return;
            if (!$this->app->bound(Schedule::class)) return;
            $this->app->make(Schedule::class)
                ->command('titan:autonomy-reconcile --limit=' . (int)config('titan-autonomy.outcome_reconciliation.batch_size', 100))
                ->everyFifteenMinutes()
                ->onOneServer()
                ->withoutOverlapping();
        });
    }
}
