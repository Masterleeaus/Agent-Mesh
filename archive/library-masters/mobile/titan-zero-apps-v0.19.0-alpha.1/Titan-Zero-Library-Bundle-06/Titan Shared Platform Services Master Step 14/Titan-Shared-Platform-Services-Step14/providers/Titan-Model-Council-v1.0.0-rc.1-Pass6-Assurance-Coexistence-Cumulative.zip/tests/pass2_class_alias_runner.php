<?php

declare(strict_types=1);

$source = file_get_contents(__DIR__ . '/../System/TitanModelCouncilServiceProvider.php');
$required = [
    'registerLegacyClassAliases',
    "'App\\\\Extensions\\\\ModelCouncil\\\\System\\\\Services\\\\ModelCouncilService'",
    "'App\\\\Extensions\\\\ModelCouncil\\\\System\\\\Models\\\\ModelCouncilResponse'",
    'class_alias(',
];
foreach ($required as $needle) {
    if (! str_contains($source, $needle)) {
        fwrite(STDERR, "FAIL: provider missing legacy class alias seam: {$needle}\n");
        exit(1);
    }
}
echo "pass2 legacy class alias checks passed\n";
