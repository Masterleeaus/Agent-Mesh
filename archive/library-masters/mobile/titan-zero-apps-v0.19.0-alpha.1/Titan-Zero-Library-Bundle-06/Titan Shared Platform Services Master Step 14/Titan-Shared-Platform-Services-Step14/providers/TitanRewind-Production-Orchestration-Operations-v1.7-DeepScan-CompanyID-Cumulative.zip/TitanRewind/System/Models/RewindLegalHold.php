<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindLegalHold extends Model
{
    protected $table = 'titan_rewind_legal_holds';
    protected $fillable = ['hold_uuid','tenant_company_id','scope_type','scope_id','status','authority','reason','applied_by_id','applied_at','review_at','expires_at','released_by_id','released_at','release_reason'];
    protected $casts = ['tenant_company_id'=>'integer','applied_by_id'=>'integer','released_by_id'=>'integer','applied_at'=>'datetime','review_at'=>'datetime','expires_at'=>'datetime','released_at'=>'datetime'];
}
