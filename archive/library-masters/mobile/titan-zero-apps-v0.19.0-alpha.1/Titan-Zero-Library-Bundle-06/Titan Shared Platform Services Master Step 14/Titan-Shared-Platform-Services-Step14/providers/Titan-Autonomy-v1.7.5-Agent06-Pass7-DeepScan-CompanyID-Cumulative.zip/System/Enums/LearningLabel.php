<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Enums;

enum LearningLabel: string
{
    case Correct = 'correct';
    case Incorrect = 'incorrect';
    case PartiallyCorrect = 'partially_correct';
    case MateriallyCorrected = 'materially_corrected';
    case Rejected = 'rejected';
    case Failed = 'failed';
    case Reversed = 'reversed';
    case Exception = 'exception';
    case Ambiguous = 'ambiguous';
    case InsufficientInformation = 'insufficient_information';
}
