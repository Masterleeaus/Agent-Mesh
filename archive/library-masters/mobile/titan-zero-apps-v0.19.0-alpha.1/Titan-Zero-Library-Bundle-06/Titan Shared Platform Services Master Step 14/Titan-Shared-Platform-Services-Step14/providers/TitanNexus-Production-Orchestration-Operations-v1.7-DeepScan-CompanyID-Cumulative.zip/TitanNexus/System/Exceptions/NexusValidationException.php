<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Exceptions;

use App\Extensions\TitanNexus\System\Domain\ValidationResult;
use RuntimeException;

final class NexusValidationException extends RuntimeException
{
    public function __construct(private readonly ValidationResult $validationResult)
    {
        parent::__construct('Titan Nexus compilation blocked by semantic validation.');
    }

    public function validationResult(): ValidationResult
    {
        return $this->validationResult;
    }
}
