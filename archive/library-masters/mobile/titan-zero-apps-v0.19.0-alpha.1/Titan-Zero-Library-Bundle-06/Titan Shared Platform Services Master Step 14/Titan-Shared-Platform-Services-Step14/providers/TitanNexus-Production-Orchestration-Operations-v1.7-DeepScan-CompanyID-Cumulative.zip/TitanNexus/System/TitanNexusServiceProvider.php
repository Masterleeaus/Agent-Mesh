<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System;

use App\Extensions\TitanNexus\Persistence\Workforce\DatabaseDurableHandoffStore;
use App\Extensions\TitanNexus\System\Workforce\DurableHandoffStoreContract;
use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanNexus\System\Adapters\CommandBus\CommandBusProvisioningAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\AssuranceEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\AutonomyEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\GovernanceEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\RiskEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Observability\RewindEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Observability\SignalEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Platform\PlatformReadinessAdapter;
use App\Extensions\TitanNexus\System\Adapters\VerticalEngine\VerticalEngineAdapter;
use App\Extensions\TitanNexus\System\Contracts\AssuranceGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\AutonomyGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\CompilationLifecycleRepositoryContract;
use App\Extensions\TitanNexus\System\Contracts\CompilationRepositoryContract;
use App\Extensions\TitanNexus\System\Contracts\ConfigurationDifferContract;
use App\Extensions\TitanNexus\System\Contracts\GovernanceGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\NexusCompilerContract;
use App\Extensions\TitanNexus\System\Contracts\NexusManagerContract;
use App\Extensions\TitanNexus\System\Contracts\NexusControlCentreContract;
use App\Extensions\TitanNexus\System\Contracts\TenantContextResolverContract;
use App\Extensions\TitanNexus\System\Contracts\NexusValidatorContract;
use App\Extensions\TitanNexus\System\Contracts\PlatformReadinessSourceContract;
use App\Extensions\TitanNexus\System\Contracts\ProvisioningCommandGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\ProvisioningExecutorContract;
use App\Extensions\TitanNexus\System\Contracts\ProvisioningPlannerContract;
use App\Extensions\TitanNexus\System\Contracts\RewindGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\RiskGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\SignalGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\VerticalDefinitionSourceContract;
use App\Extensions\TitanNexus\System\Host\HostTenantContextResolver;
use App\Extensions\TitanNexus\System\Host\NexusMenuRegistrar;
use App\Extensions\TitanNexus\System\Host\TitanHostAuthorizationAdapter;
use App\Extensions\TitanNexus\System\Host\TitanMenuCompatibilityAdapter;
use App\Extensions\TitanNexus\System\Http\Middleware\TitanNexusAuthorizationMiddleware;
use App\Extensions\TitanNexus\System\Support\StrictBoolean;
use App\Extensions\TitanNexus\System\Repositories\EloquentCompilationLifecycleRepository;
use App\Extensions\TitanNexus\System\Repositories\EloquentCompilationRepository;
use App\Extensions\TitanNexus\System\Services\DeterministicNexusCompiler;
use App\Extensions\TitanNexus\System\Services\DeterministicProvisioningPlanner;
use App\Extensions\TitanNexus\System\Services\GovernedProvisioningExecutor;
use App\Extensions\TitanNexus\System\Services\NexusManager;
use App\Extensions\TitanNexus\System\Services\NexusControlCentreService;
use App\Extensions\TitanNexus\System\Services\SemanticConfigurationDiffer;
use App\Extensions\TitanNexus\System\Services\SemanticNexusValidator;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use RuntimeException;
use Throwable;

final class TitanNexusServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->app->singleton(\App\Extensions\TitanNexus\System\Workforce\CrossExtensionOrchestrator::class, static fn (): \App\Extensions\TitanNexus\System\Workforce\CrossExtensionOrchestrator => new \App\Extensions\TitanNexus\System\Workforce\CrossExtensionOrchestrator('TitanNexus'));
        $this->app->singleton(\App\Extensions\TitanNexus\System\Workforce\WorkforceLoopRuntime::class, static fn (): \App\Extensions\TitanNexus\System\Workforce\WorkforceLoopRuntime => \App\Extensions\TitanNexus\System\Workforce\WorkforceLoopRuntime::fromContractFile(__DIR__ . '/../workforce-integration.json'));
        $this->app->singleton(\App\Extensions\TitanNexus\System\Workforce\ProviderDiscovery::class, fn (): \App\Extensions\TitanNexus\System\Workforce\ProviderDiscovery => \App\Extensions\TitanNexus\System\Workforce\ProviderDiscovery::fromContractFile($this->app, __DIR__ . '/../workforce-integration.json'));

        $this->app->singleton(DurableHandoffStoreContract::class, static fn (): DurableHandoffStoreContract => new DatabaseDurableHandoffStore());
        $this->app->singleton(\App\Extensions\TitanNexus\System\Workforce\PersistentOrchestrationRuntime::class, static fn ($app): \App\Extensions\TitanNexus\System\Workforce\PersistentOrchestrationRuntime => new \App\Extensions\TitanNexus\System\Workforce\PersistentOrchestrationRuntime($app->make(\App\Extensions\TitanNexus\System\Workforce\CrossExtensionOrchestrator::class), $app->make(\App\Extensions\TitanNexus\System\Workforce\DurableHandoffStoreContract::class)));
        $this->app->singleton(\App\Extensions\TitanNexus\System\Workforce\OrchestrationOperations::class, static fn ($app): \App\Extensions\TitanNexus\System\Workforce\OrchestrationOperations => new \App\Extensions\TitanNexus\System\Workforce\OrchestrationOperations($app->make(\App\Extensions\TitanNexus\System\Workforce\PersistentOrchestrationRuntime::class), $app->make(\App\Extensions\TitanNexus\System\Workforce\DurableHandoffStoreContract::class)));
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-nexus.php', 'titan-nexus');

        $this->app->singleton(NexusCompilerContract::class, function ($app): DeterministicNexusCompiler {
            return new DeterministicNexusCompiler((string) $app['config']->get('titan-nexus.compiler_version', '0.5.0'));
        });

        $this->app->singleton(VerticalDefinitionSourceContract::class, function ($app): VerticalEngineAdapter {
            $contract = $app['config']->get('titan-nexus.vertical_engine.public_contract');
            $method = (string) $app['config']->get('titan-nexus.vertical_engine.resolve_method', 'resolveForNexus');
            return new VerticalEngineAdapter(self::unaryGateway($app, $contract, $method, 'Titan Vertical Engine'));
        });

        $this->app->singleton(PlatformReadinessSourceContract::class, function ($app): PlatformReadinessAdapter {
            $contract = $app['config']->get('titan-nexus.readiness.public_contract');
            $method = (string) $app['config']->get('titan-nexus.readiness.check_method', 'checkCapabilitiesForNexus');
            $static = $app['config']->get('titan-nexus.readiness.static_capabilities', []);
            $resolver = is_string($contract) && trim($contract) !== '' ? self::unaryGateway($app, $contract, $method, 'Titan readiness') : null;
            return new PlatformReadinessAdapter($resolver, is_array($static) ? array_values($static) : []);
        });

        $this->app->singleton(NexusValidatorContract::class, SemanticNexusValidator::class);
        $this->app->singleton(ProvisioningPlannerContract::class, DeterministicProvisioningPlanner::class);

        $this->app->singleton(ProvisioningCommandGatewayContract::class, function ($app): CommandBusProvisioningAdapter {
            $contract = $app['config']->get('titan-nexus.command_bus.public_contract');
            $method = (string) $app['config']->get('titan-nexus.command_bus.execute_method', 'executeForNexus');
            $gateway = is_string($contract) && trim($contract) !== '' ? self::capabilityGateway($app, $contract, $method, 'Titan Command Bus') : null;
            return new CommandBusProvisioningAdapter($gateway);
        });

        $this->app->singleton(RiskGatewayContract::class, fn ($app): RiskEngineAdapter => new RiskEngineAdapter(self::configuredUnary($app, 'risk', 'evaluate_method', 'evaluateForNexus', 'Titan Risk')));
        $this->app->singleton(GovernanceGatewayContract::class, fn ($app): GovernanceEngineAdapter => new GovernanceEngineAdapter(self::configuredUnary($app, 'governance', 'authorize_method', 'authorizeForNexus', 'Titan Governance')));
        $this->app->singleton(AssuranceGatewayContract::class, fn ($app): AssuranceEngineAdapter => new AssuranceEngineAdapter(self::configuredUnary($app, 'assurance', 'verify_method', 'verifyForNexus', 'Titan Assurance')));
        $this->app->singleton(AutonomyGatewayContract::class, fn ($app): AutonomyEngineAdapter => new AutonomyEngineAdapter(self::configuredUnary($app, 'autonomy', 'authorize_method', 'authorizeForNexus', 'Titan Autonomy')));
        $this->app->singleton(SignalGatewayContract::class, fn ($app): SignalEngineAdapter => new SignalEngineAdapter(self::configuredEvent($app, 'signal', 'emit_method', 'emitForNexus', 'Titan Signal')));
        $this->app->singleton(RewindGatewayContract::class, fn ($app): RewindEngineAdapter => new RewindEngineAdapter(self::configuredEvent($app, 'rewind', 'record_method', 'recordForNexus', 'Titan Rewind')));

        $this->app->singleton(ProvisioningExecutorContract::class, GovernedProvisioningExecutor::class);
        $this->app->singleton(ConfigurationDifferContract::class, SemanticConfigurationDiffer::class);
        $this->app->singleton(NexusManagerContract::class, function ($app): NexusManager {
            $databaseAvailable = Schema::hasTable('titan_nexus_compilations')
                && Schema::hasTable('titan_nexus_compilation_events');
            $readiness = [
                'database' => [
                    'configured' => true,
                    'bound' => true,
                    'callable' => true,
                    'available' => $databaseAvailable,
                    'reason' => $databaseAvailable ? null : 'nexus_tables_missing',
                ],
                'vertical_engine' => self::dependencyState($app, 'vertical_engine', 'resolve_method', 'resolveForNexus'),
                'command_bus' => self::dependencyState($app, 'command_bus', 'execute_method', 'executeForNexus'),
                'risk' => self::dependencyState($app, 'risk', 'evaluate_method', 'evaluateForNexus'),
                'governance' => self::dependencyState($app, 'governance', 'authorize_method', 'authorizeForNexus'),
                'assurance' => self::dependencyState($app, 'assurance', 'verify_method', 'verifyForNexus'),
                'signal' => self::dependencyState($app, 'signal', 'emit_method', 'emitForNexus'),
                'rewind' => self::dependencyState($app, 'rewind', 'record_method', 'recordForNexus'),
                'autonomy' => self::dependencyState($app, 'autonomy', 'authorize_method', 'authorizeForNexus'),
                'knowledge_authority' => self::dependencyState($app, 'knowledge_authority'),
                'interface_runtime' => self::dependencyState($app, 'interface_runtime'),
            ];
            return new NexusManager(
                $app->make(NexusCompilerContract::class),
                $app->make(VerticalDefinitionSourceContract::class),
                $app->make(NexusValidatorContract::class),
                $app->make(ConfigurationDifferContract::class),
                $app->make(ProvisioningPlannerContract::class),
                $app->make(ProvisioningExecutorContract::class),
                $app->make(CompilationRepositoryContract::class),
                $readiness,
                self::configBool($app['config']->get('titan-nexus.enabled', true), true),
                $app->make(CompilationLifecycleRepositoryContract::class),
                self::declaredCapabilities(),
            );
        });
        $this->app->singleton(CompilationRepositoryContract::class, EloquentCompilationRepository::class);
        $this->app->singleton(CompilationLifecycleRepositoryContract::class, EloquentCompilationLifecycleRepository::class);
        $this->app->singleton(NexusControlCentreContract::class, NexusControlCentreService::class);
        $this->app->singleton(TitanMenuCompatibilityAdapter::class);
        $this->app->singleton(NexusMenuRegistrar::class);
        $this->app->singleton(TitanHostAuthorizationAdapter::class);
        $this->app->singleton(TitanNexusAuthorizationMiddleware::class);

        $this->app->singleton(TenantContextResolverContract::class, function ($app): HostTenantContextResolver {
            $contract = $app['config']->get('titan-nexus.tenant_context.public_contract');
            $method = (string) $app['config']->get('titan-nexus.tenant_context.resolve_method', 'resolveTenantForNexus');
            $attributes = $app['config']->get('titan-nexus.tenant_context.user_attributes', ['company_id', 'tenant_company_id']);
            $resolver = is_string($contract) && trim($contract) !== '' ? self::unaryGateway($app, $contract, $method, 'Titan tenant context') : null;
            return new HostTenantContextResolver($resolver, is_array($attributes) ? array_values($attributes) : ['company_id', 'tenant_company_id']);
        });
    }

    public function boot(): void
    {
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-nexus');
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->publishes([__DIR__ . '/../config/titan-nexus.php' => config_path('titan-nexus.php')], 'extension');
        $this->registerRoutes();
        try { $this->registerNavigation(); } catch (Throwable) { /* navigation must never make provider boot fatal */ }
    }

    public function registerKey(): string { return 'titan-nexus'; }

    public static function uninstall(): void
    {
        try { app(TitanMenuCompatibilityAdapter::class)->removeAll(NexusMenuRegistrar::definitions()); } catch (Throwable) {}
        File::delete(config_path('titan-nexus.php'));
    }

    private function registerNavigation(): void
    {
        if (!self::configBool($this->app['config']->get('titan-nexus.navigation.enabled', true), true)) {
            return;
        }
        $this->app->make(NexusMenuRegistrar::class)->registerNavigation();
    }

    private function registerRoutes(): void
    {
        if ($this->app->bound('titan-nexus.routes.registered')) {
            return;
        }

        /** @var Router $router */
        $router = $this->app['router'];
        $router->aliasMiddleware('titan-nexus.authz', TitanNexusAuthorizationMiddleware::class);
        $router->group(['middleware'=>['web','auth','titan-nexus.authz:titan-nexus.view'],'prefix'=>'dashboard/user/titan-nexus','as'=>'dashboard.user.titan.nexus.'], static function (Router $router): void { require __DIR__ . '/../routes/user.php'; });
        $router->group(['middleware'=>['web','auth','admin','titan-nexus.authz:titan-nexus.view'],'prefix'=>'dashboard/admin/titan-nexus','as'=>'dashboard.admin.titan.nexus.'], static function (Router $router): void { require __DIR__ . '/../routes/admin.php'; });
        $this->app->instance('titan-nexus.routes.registered', true);
    }

    /** @return array{configured:bool,bound:bool,callable:bool,available:bool,reason:?string} */
    private static function dependencyState(
        mixed $app,
        string $section,
        ?string $methodKey = null,
        ?string $defaultMethod = null,
    ): array {
        $contract = $app['config']->get("titan-nexus.{$section}.public_contract");
        $configured = is_string($contract) && trim($contract) !== '';
        if (!$configured) {
            return ['configured'=>false,'bound'=>false,'callable'=>false,'available'=>false,'reason'=>'not_configured'];
        }
        $contract = trim((string) $contract);
        if (!$app->bound($contract)) {
            return ['configured'=>true,'bound'=>false,'callable'=>false,'available'=>false,'reason'=>'not_bound'];
        }
        try {
            $service = $app->make($contract);
        } catch (Throwable) {
            return ['configured'=>true,'bound'=>true,'callable'=>false,'available'=>false,'reason'=>'resolution_failed'];
        }
        if (!is_object($service)) {
            return ['configured'=>true,'bound'=>true,'callable'=>false,'available'=>false,'reason'=>'invalid_binding'];
        }
        if ($methodKey === null) {
            return ['configured'=>true,'bound'=>true,'callable'=>true,'available'=>true,'reason'=>null];
        }
        $method = (string) $app['config']->get("titan-nexus.{$section}.{$methodKey}", $defaultMethod ?? '');
        $callable = $method !== '' && is_callable([$service, $method]);
        return [
            'configured' => true,
            'bound' => true,
            'callable' => $callable,
            'available' => $callable,
            'reason' => $callable ? null : 'method_not_callable',
        ];
    }

    /** @return list<string> */
    private static function declaredCapabilities(): array
    {
        $path = __DIR__ . '/../extension.manifest.json';
        if (!is_file($path)) {
            return [];
        }
        try {
            $manifest = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        } catch (Throwable) {
            return [];
        }
        $capabilities = $manifest['capabilities'] ?? [];
        if (!is_array($capabilities)) {
            return [];
        }
        $result = [];
        foreach ($capabilities as $capability) {
            if (is_string($capability) && trim($capability) !== '') {
                $result[] = trim($capability);
            }
        }
        return array_values(array_unique($result));
    }

    private static function configBool(mixed $value, bool $default): bool
    {
        try { return StrictBoolean::parse($value, 'config_boolean'); } catch (\InvalidArgumentException) { return $default; }
    }

    private static function configuredUnary(mixed $app, string $section, string $methodKey, string $defaultMethod, string $label): ?callable
    {
        $contract = $app['config']->get("titan-nexus.{$section}.public_contract");
        $method = (string) $app['config']->get("titan-nexus.{$section}.{$methodKey}", $defaultMethod);
        return is_string($contract) && trim($contract) !== '' ? self::unaryGateway($app, $contract, $method, $label) : null;
    }

    private static function configuredEvent(mixed $app, string $section, string $methodKey, string $defaultMethod, string $label): ?callable
    {
        $contract = $app['config']->get("titan-nexus.{$section}.public_contract");
        $method = (string) $app['config']->get("titan-nexus.{$section}.{$methodKey}", $defaultMethod);
        return is_string($contract) && trim($contract) !== '' ? self::eventGateway($app, $contract, $method, $label) : null;
    }

    private static function unaryGateway(mixed $app, mixed $contract, string $method, string $label): callable
    {
        return static function (array $request) use ($app, $contract, $method, $label): array {
            if (!is_string($contract) || trim($contract) === '') { throw new RuntimeException("{$label} public contract is not configured."); }
            if ($method === '') { throw new RuntimeException("{$label} public method is not configured."); }
            if (!$app->bound($contract)) { throw new RuntimeException("Configured {$label} public contract is not bound."); }
            $gateway = $app->make($contract);
            if (!is_object($gateway) || !is_callable([$gateway, $method])) { throw new RuntimeException("Configured {$label} public gateway is not callable."); }
            $result = $gateway->{$method}($request);
            if (!is_array($result)) { throw new RuntimeException("{$label} public gateway must return an array."); }
            return $result;
        };
    }

    private static function eventGateway(mixed $app, mixed $contract, string $method, string $label): callable
    {
        return static function (string $event, array $request) use ($app, $contract, $method, $label): array {
            if (!is_string($contract) || trim($contract) === '') { throw new RuntimeException("{$label} public contract is not configured."); }
            if ($method === '') { throw new RuntimeException("{$label} public method is not configured."); }
            if (!$app->bound($contract)) { throw new RuntimeException("Configured {$label} public contract is not bound."); }
            $gateway = $app->make($contract);
            if (!is_object($gateway) || !is_callable([$gateway, $method])) { throw new RuntimeException("Configured {$label} public gateway is not callable."); }
            $result = $gateway->{$method}($event, $request);
            if (!is_array($result)) { throw new RuntimeException("{$label} public gateway must return an array."); }
            return $result;
        };
    }

    private static function capabilityGateway(mixed $app, string $contract, string $method, string $label): callable
    {
        return static function (string $capability, array $request) use ($app, $contract, $method, $label): array {
            if ($method === '') { throw new RuntimeException("{$label} public method is not configured."); }
            if (!$app->bound($contract)) { throw new RuntimeException("Configured {$label} public contract is not bound."); }
            $gateway = $app->make($contract);
            if (!is_object($gateway) || !is_callable([$gateway, $method])) { throw new RuntimeException("Configured {$label} public gateway is not callable."); }
            $result = $gateway->{$method}($capability, $request);
            if (!is_array($result)) { throw new RuntimeException("{$label} public gateway must return an array."); }
            return $result;
        };
    }
}
