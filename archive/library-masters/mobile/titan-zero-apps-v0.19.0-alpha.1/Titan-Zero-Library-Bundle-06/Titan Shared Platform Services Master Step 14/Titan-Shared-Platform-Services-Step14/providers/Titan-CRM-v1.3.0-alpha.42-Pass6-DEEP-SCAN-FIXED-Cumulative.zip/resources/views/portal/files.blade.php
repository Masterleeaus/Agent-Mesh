@extends('panel.layout.app')
@section('title', 'CRM Portal Files')
@section('content')
<div class="container-xl py-6">
    <h1>Files</h1>
    @if(session('status')) <div class="alert alert-success">{{ session('status') }}</div> @endif
    @if(in_array('files.upload', json_decode((string)($grant['scopes'] ?? '[]'), true) ?: [], true))
    <form method="POST" enctype="multipart/form-data" action="{{ route('crm.portal.files.store', $token) }}" class="mb-6">
        @csrf
        <input type="file" name="file" required>
        <button type="submit" class="btn btn-primary">Upload securely</button>
    </form>
    @endif
    <div class="space-y-2">
        @forelse($files as $file)
            <div>@if(in_array('files.download', json_decode((string)($grant['scopes'] ?? '[]'), true) ?: [], true))<a href="{{ route('crm.portal.files.download', [$token, $file['public_id']]) }}">{{ $file['original_name'] }}</a>@else{{ $file['original_name'] }}@endif <small>{{ number_format($file['size_bytes']/1024,1) }} KB · scanned</small></div>
        @empty <p>No files have been shared through this portal link.</p> @endforelse
    </div>
</div>
@endsection
