<?php

use App\Extensions\TitanNexus\System\Http\Controllers\AdminController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', AdminController::class)->name('index');
