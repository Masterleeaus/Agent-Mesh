<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$passes = [];
$failures = [];
$read = static fn (string $path): string => is_file($root.'/'.$path) ? (string) file_get_contents($root.'/'.$path) : '';
$check = static function (bool $condition, string $label) use (&$passes, &$failures): void {
    if ($condition) { $passes[] = $label; } else { $failures[] = $label; }
};

$sync = $read('System/Navigation/MagicAiMenuSynchronizer.php');
$navigation = $read('System/Navigation/TitanConnectNavigation.php');
$provider = $read('System/TitanConnectServiceProvider.php');
$web = $read('routes/web.php');
$hostSync = $read('System/Console/SyncTitanConnectHostCommand.php');
$migration = $read('database/migrations/2026_08_09_000007_sync_magicai_menu_rows.php');
$readiness = $read('System/Services/HostReadinessService.php');
$combined = $sync.$navigation.$web;

$check($sync !== '', 'LIVE HOST menu synchronizer exists');
$check(str_contains($sync, "Schema::hasTable('menus')"), 'LIVE HOST synchronizer detects menus table');
$check(str_contains($sync, "app('db')->table('menus')"), 'LIVE HOST synchronizer writes the real MagicAI menus table');
$check(!str_contains($sync, "Schema::table('menus'") && !str_contains($migration, "Schema::table('menus'"), 'LIVE HOST fallback does not mutate shared menu schema');
$check(str_contains($combined, 'ext_titan_connect_channels') && str_contains($combined, 'ext_titan_connect_inbox'), 'LIVE HOST synchronizer materializes Channels and Inbox roots');
foreach (['whatsapp','messenger','instagram','telegram','sms','voice','push'] as $providerKey) {
    $check(str_contains($combined, 'titan_connect_channel_'.$providerKey), 'LIVE HOST synchronizer materializes user channel '.$providerKey);
}
foreach (['unified','team','external','mine','unassigned','needs_human','closed'] as $mode) {
    $check(str_contains($combined, 'titan_connect_inbox_'.$mode), 'LIVE HOST synchronizer materializes inbox '.$mode);
}
$check(str_contains($sync, "'params' => '[]'") || str_contains($sync, "json_encode([]"), 'LIVE HOST rows use host params format');
$check(str_contains($sync, "'type' => 'item'"), 'LIVE HOST rows use item type');
$check(str_contains($sync, "'custom_menu' => 0"), 'LIVE HOST rows are vendor menu rows');
$check(str_contains($sync, "'badge' => null"), 'LIVE HOST shared menu rows never persist actor/company unread counts');
$check(str_contains($sync, "'extension' => null"), 'LIVE HOST DB fallback avoids unknown extension-plan gating');
$check(str_contains($sync, 'updateOrInsert') || (str_contains($sync, "->update(") && str_contains($sync, "->insert(")), 'LIVE HOST sync is idempotent');
$check(str_contains($sync, 'parent_id'), 'LIVE HOST child rows resolve numeric parent_id');
$check(str_contains($sync, "'settings'") || str_contains($migration, "'settings'"), 'LIVE HOST Super Admin fallback attaches to existing Settings root');
$check(str_contains($combined, 'dashboard.admin.settings.titan-connect.channels.index'), 'LIVE HOST Super Admin overview uses existing Settings permission route family');
$check(str_contains($combined, "'dashboard.admin.settings.titan-connect.channels.'.\$provider") || str_contains($combined, "dashboard.admin.settings.titan-connect.channels.'.$provider"), 'LIVE HOST Super Admin provider routes use the Settings route family');
foreach (['whatsapp','messenger','instagram','telegram','sms','voice','push'] as $providerKey) {
    $check(str_contains($combined, "'".$providerKey."'"), 'LIVE HOST Super Admin provider catalogue includes '.$providerKey);
}
$check(!str_contains($migration, 'App\\Extensions\\TitanConnect\\') && str_contains($migration, "app('db')->table('menus')"), 'LIVE HOST migration is self-contained for in-request extension upgrades');
$check(str_contains($provider, 'MagicAiMenuSynchronizer'), 'LIVE HOST synchronizer is container registered');
$check(str_contains($hostSync, 'MagicAiMenuSynchronizer') && str_contains($hostSync, 'sync'), 'LIVE HOST host-sync command rematerializes database menus');
$check(str_contains($web, "'updateUserActivity', 'admin'") || str_contains($web, "'auth', 'admin'"), 'LIVE HOST Super Admin routes enforce admin middleware');
$check(str_contains($web, "dashboard.admin.settings.titan-connect.channels.index"), 'LIVE HOST host-compatible Super Admin Channels route is registered');
$check(str_contains($readiness, 'navigation-menu') && str_contains($readiness, 'ext_titan_connect_channels') && str_contains($readiness, 'ext_titan_connect_inbox'), 'LIVE HOST diagnostics verify materialized menu roots');
$check(!str_contains($sync, 'tenant_id'), 'LIVE HOST menu synchronization does not introduce tenant_id');

foreach ($passes as $label) echo "PASS: {$label}\n";
foreach ($failures as $label) echo "FAIL: {$label}\n";
printf("live-host-menu contract suite: %d passed, %d failed\n", count($passes), count($failures));
exit($failures === [] ? 0 : 1);
