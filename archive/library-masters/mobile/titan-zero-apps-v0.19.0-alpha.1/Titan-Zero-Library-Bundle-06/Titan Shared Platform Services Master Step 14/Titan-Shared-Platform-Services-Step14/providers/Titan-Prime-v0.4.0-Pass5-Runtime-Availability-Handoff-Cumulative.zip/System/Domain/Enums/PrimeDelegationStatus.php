<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Enums;

enum PrimeDelegationStatus: string
{
    case Proposed = 'proposed';
    case Queued = 'queued';
    case Accepted = 'accepted';
    case Running = 'running';
    case Completed = 'completed';
    case Failed = 'failed';
    case Cancelled = 'cancelled';
}
