<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use InvalidArgumentException;
use JsonException;

final readonly class SignalPayloadGuard
{
    /** @param list<string> $prohibitedReasoningKeys */
    public function __construct(
        private int $maxPayloadBytes,
        private int $maxMetadataBytes,
        private array $prohibitedReasoningKeys,
    ) {
        if ($this->maxPayloadBytes < 1 || $this->maxMetadataBytes < 1) {
            throw new InvalidArgumentException('Signal payload and metadata limits must be positive.');
        }
    }

    /** @param array<string,mixed> $payload @param array<string,mixed> $metadata */
    public function assertAllowed(array $payload, array $metadata): void
    {
        $this->assertNoHiddenReasoning($payload);
        $this->assertNoHiddenReasoning($metadata);
        $this->assertJsonBytes($payload, $this->maxPayloadBytes, 'payload');
        $this->assertJsonBytes($metadata, $this->maxMetadataBytes, 'metadata');
    }

    /** @param array<string,mixed> $value */
    private function assertNoHiddenReasoning(array $value): void
    {
        $prohibited = array_fill_keys(array_map([self::class, 'normalizeKey'], $this->prohibitedReasoningKeys), true);
        $walk = function (array $node) use (&$walk, $prohibited): void {
            foreach ($node as $key => $item) {
                if (is_string($key) && isset($prohibited[self::normalizeKey($key)])) {
                    throw new InvalidArgumentException("Signal payload field {$key} is prohibited hidden-reasoning storage.");
                }
                if (is_array($item)) {
                    $walk($item);
                }
            }
        };
        $walk($value);
    }

    private static function normalizeKey(string $key): string
    {
        return strtolower(str_replace(['-', ' '], '_', trim($key)));
    }

    /** @param array<string,mixed> $value */
    private function assertJsonBytes(array $value, int $limit, string $label): void
    {
        try {
            $json = json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION);
        } catch (JsonException $exception) {
            throw new InvalidArgumentException("Signal {$label} is not valid JSON data.", previous: $exception);
        }
        if (strlen($json) > $limit) {
            throw new InvalidArgumentException("Signal {$label} exceeds the configured {$limit} byte limit.");
        }
    }
}
