<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface ControlPlaneAuditSinkContract
{
    public function record(array $event): string;
}
