<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Forensics;

use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;

final class RewindTemporalDiagnostics
{
    public function __construct(private int $lateThresholdSeconds = 300) {}

    public function analyse(array $events): array
    {
        usort($events, static fn (array $a, array $b): int => ((int) ($a['id'] ?? 0)) <=> ((int) ($b['id'] ?? 0)));
        return $this->analyseStream($events);
    }

    public function analyseStream(iterable $events): array
    {
        $late=0;$recordedBeforeOccurred=0;$maxLagMs=0;$sequenceCounts=[];$outOfOrder=0;$arrivalHighWater=null;$count=0;
        foreach($events as $row){++$count;$event=is_array($row)?$row:(method_exists($row,'toArray')?$row->toArray():(array)$row);
            $sequence=(int)($event['sequence']??0);$sequenceCounts[$sequence]=($sequenceCounts[$sequence]??0)+1;
            $occurred=$this->date($event['occurred_at']??null);$recorded=$this->date($event['recorded_at']??null);
            if($occurred&&$recorded){$lagMs=(int)round(((float)$recorded->format('U.u')-(float)$occurred->format('U.u'))*1000);if($lagMs<0)++$recordedBeforeOccurred;else{$maxLagMs=max($maxLagMs,$lagMs);if($lagMs>($this->lateThresholdSeconds*1000))++$late;}}
            $orderKey=$this->orderKey($event);if($arrivalHighWater!==null&&strcmp($orderKey,$arrivalHighWater)<0)++$outOfOrder;if($arrivalHighWater===null||strcmp($orderKey,$arrivalHighWater)>0)$arrivalHighWater=$orderKey;
        }
        $sequenceCollisions=count(array_filter($sequenceCounts,static fn(int $n):bool=>$n>1));
        return ['late_threshold_seconds'=>max(0,$this->lateThresholdSeconds),'late_event_count'=>$late,'out_of_order_arrival_count'=>$outOfOrder,'sequence_collision_count'=>$sequenceCollisions,'recorded_before_occurred_count'=>$recordedBeforeOccurred,'max_recording_lag_ms'=>$maxLagMs,'event_count'=>$count,'status'=>($late+$outOfOrder+$sequenceCollisions+$recordedBeforeOccurred)>0?'review':'clear','streaming'=>true];
    }

    private function orderKey(array $event): string
    {
        return sprintf('%020d|%s|%s',
            (int) ($event['sequence'] ?? 0),
            $this->date($event['occurred_at'] ?? null)?->format('Y-m-d\TH:i:s.u\Z') ?? '9999-12-31T23:59:59.999999Z',
            (string) ($event['event_id'] ?? '')
        );
    }

    private function date(mixed $value): ?DateTimeImmutable
    {
        try {
            if ($value instanceof DateTimeInterface) {
                return (new DateTimeImmutable($value->format('Y-m-d\TH:i:s.uP')))->setTimezone(new DateTimeZone('UTC'));
            }
            $raw = trim((string) $value);
            return $raw === '' ? null : (new DateTimeImmutable($raw))->setTimezone(new DateTimeZone('UTC'));
        } catch (\Throwable) {
            return null;
        }
    }
}
