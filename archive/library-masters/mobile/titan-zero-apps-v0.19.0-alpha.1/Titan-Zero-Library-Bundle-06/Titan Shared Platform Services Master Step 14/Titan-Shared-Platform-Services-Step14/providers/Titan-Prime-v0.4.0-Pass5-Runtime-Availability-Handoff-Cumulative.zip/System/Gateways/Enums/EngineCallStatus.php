<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Enums;

enum EngineCallStatus: string
{
    case Succeeded = 'succeeded';
    case Denied = 'denied';
    case Escalated = 'escalated';
    case Unavailable = 'unavailable';
    case Failed = 'failed';
}
