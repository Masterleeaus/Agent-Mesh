<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\ModelCouncil\System\Models\AssuranceRun;
use App\Extensions\TitanAutonomy\System\Contracts\TenantAssuranceBridgeContract;
use Closure;

final class ModelCouncilTenantAssuranceBridge implements TenantAssuranceBridgeContract
{
    private readonly Closure $runFinder;

    public function __construct(?callable $runFinder = null)
    {
        $this->runFinder = $runFinder instanceof Closure
            ? $runFinder
            : Closure::fromCallable($runFinder ?? function (int $tenantCompanyId, string $sourceId): ?object {
                if (!class_exists(AssuranceRun::class)) {
                    return null;
                }

                return AssuranceRun::query()
                    ->where('company_id', (string) $tenantCompanyId)
                    ->where('source_type', 'titan_autonomy')
                    ->where('source_id', $sourceId)
                    ->where('decision_type', 'autonomy_trusted_auto')
                    ->latest('id')
                    ->first();
            });
    }

    public function evaluateForTenant(
        int $tenantCompanyId,
        string $capability,
        ?string $workflowKey,
        array $context,
    ): array {
        if ($tenantCompanyId <= 0) {
            return $this->denied('RED', ['INVALID_TRUSTED_TENANT'], null, 0.0, false);
        }

        $sourceId = ModelCouncilAssuranceBridge::sourceId($capability, $workflowKey);
        $run = ($this->runFinder)($tenantCompanyId, $sourceId);
        if ($run === null) {
            return $this->denied('AMBER', ['ASSURANCE_RUN_REQUIRED'], null, 0.0);
        }

        if (isset($run->expires_at) && $run->expires_at !== null) {
            $expired = method_exists($run->expires_at, 'isPast')
                ? $run->expires_at->isPast()
                : strtotime((string) $run->expires_at) < time();
            if ($expired) {
                return $this->denied('RED', ['ASSURANCE_RUN_EXPIRED'], (string) ($run->uuid ?? $run->id ?? ''), 0.0);
            }
        }

        $status = strtolower((string) ($run->status ?? ''));
        $permission = strtolower((string) ($run->permission_state ?? 'blocked'));
        $confidence = (float) ($run->confidence_score ?? 0.0);
        if ($confidence > 1.0) {
            $confidence /= 100.0;
        }
        $confidence = max(0.0, min(1.0, $confidence));
        $ref = (string) ($run->uuid ?? $run->id ?? '');

        if ($status === 'assured' && $permission === 'permitted') {
            return [
                'status' => 'GREEN',
                'decision' => 'approved',
                'confidence' => $confidence,
                'reason_codes' => ['ASSURANCE_ASSURED', 'ASSURANCE_PERMISSION_PERMITTED'],
                'evaluation_ref' => $ref,
                'available' => true,
            ];
        }

        if ($status === 'assured_with_conditions' || in_array($status, [
            'pending',
            'queued',
            'running',
            'evaluating',
            'collecting_evidence',
            'analysing',
            'challenging',
            'awaiting_human_review',
        ], true)) {
            return $this->denied('AMBER', ['ASSURANCE_' . strtoupper($status ?: 'PENDING')], $ref, $confidence);
        }

        return $this->denied('RED', ['ASSURANCE_' . strtoupper($status ?: 'BLOCKED')], $ref, $confidence);
    }

    private function denied(string $status, array $reasons, ?string $ref, float $confidence, bool $available = true): array
    {
        return [
            'status' => $status,
            'decision' => 'denied',
            'confidence' => $confidence,
            'reason_codes' => $reasons,
            'evaluation_ref' => $ref,
            'available' => $available,
        ];
    }
}
