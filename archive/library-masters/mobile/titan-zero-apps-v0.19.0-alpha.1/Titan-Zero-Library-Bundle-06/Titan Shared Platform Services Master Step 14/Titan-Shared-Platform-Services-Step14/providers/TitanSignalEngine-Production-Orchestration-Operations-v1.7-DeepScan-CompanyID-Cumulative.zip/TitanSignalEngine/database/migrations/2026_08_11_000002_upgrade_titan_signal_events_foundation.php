<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_events')) {
            return;
        }

        Schema::table('titan_signal_events', function (Blueprint $table): void {
            if (! Schema::hasColumn('titan_signal_events', 'event_id')) $table->uuid('event_id')->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'event_type')) $table->string('event_type', 160)->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'scope')) $table->string('scope', 20)->default('tenant');
            if (! Schema::hasColumn('titan_signal_events', 'occurred_at')) $table->timestampTz('occurred_at')->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'recorded_at')) $table->timestampTz('recorded_at')->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'causation_id')) $table->uuid('causation_id')->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'actor_type')) $table->string('actor_type', 80)->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'actor_id')) $table->string('actor_id', 191)->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'source')) $table->string('source', 120)->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'source_component')) $table->string('source_component', 120)->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'schema_version')) $table->unsignedInteger('schema_version')->default(1);
            if (! Schema::hasColumn('titan_signal_events', 'metadata')) $table->json('metadata')->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'severity')) $table->string('severity', 20)->default('info');
            if (! Schema::hasColumn('titan_signal_events', 'category')) $table->string('category', 80)->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'idempotency_key')) $table->string('idempotency_key', 191)->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'deduplication_key')) $table->string('deduplication_key', 64)->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'vertical_key')) $table->string('vertical_key', 80)->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'checksum')) $table->char('checksum', 64)->nullable();
        });

        DB::table('titan_signal_events')
            ->whereNull('event_id')
            ->orderBy('id')
            ->chunkById(200, static function ($rows): void {
                foreach ($rows as $row) {
                    DB::table('titan_signal_events')->where('id', $row->id)->update([
                        'event_id' => (string) Str::uuid(),
                        'event_type' => $row->event_type ?? $row->type ?? 'legacy.record',
                        'scope' => $row->tenant_company_id === null ? 'system' : 'tenant',
                        'trace_id' => $row->trace_id ?? (string) Str::uuid(),
                        'correlation_id' => $row->correlation_id ?? $row->trace_id ?? (string) Str::uuid(),
                        'occurred_at' => $row->occurred_at ?? $row->created_at ?? now(),
                        'recorded_at' => $row->recorded_at ?? $row->created_at ?? now(),
                        'source' => $row->source ?? 'legacy:titan-signal-engine',
                        'schema_version' => $row->schema_version ?? 1,
                        'severity' => $row->severity ?? 'info',
                    ]);
                }
            });

        Schema::table('titan_signal_events', function (Blueprint $table): void {
            if (! Schema::hasIndex('titan_signal_events', 'tse_event_id_uq')) $table->unique('event_id', 'tse_event_id_uq');
            if (! Schema::hasIndex('titan_signal_events', 'tse_dedup_uq')) $table->unique('deduplication_key', 'tse_dedup_uq');
            if (! Schema::hasIndex('titan_signal_events', 'tse_tenant_time_idx')) $table->index(['tenant_company_id', 'occurred_at'], 'tse_tenant_time_idx');
            if (! Schema::hasIndex('titan_signal_events', 'tse_tenant_type_time_idx')) $table->index(['tenant_company_id', 'event_type', 'occurred_at'], 'tse_tenant_type_time_idx');
            if (! Schema::hasIndex('titan_signal_events', 'tse_tenant_trace_idx')) $table->index(['tenant_company_id', 'trace_id'], 'tse_tenant_trace_idx');
            if (! Schema::hasIndex('titan_signal_events', 'tse_tenant_corr_idx')) $table->index(['tenant_company_id', 'correlation_id'], 'tse_tenant_corr_idx');
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('titan_signal_events')) {
            return;
        }

        Schema::table('titan_signal_events', function (Blueprint $table): void {
            foreach (['tse_event_id_uq', 'tse_dedup_uq', 'tse_tenant_time_idx', 'tse_tenant_type_time_idx', 'tse_tenant_trace_idx', 'tse_tenant_corr_idx'] as $index) {
                if (Schema::hasIndex('titan_signal_events', $index)) {
                    $table->dropIndex($index);
                }
            }
        });

        Schema::table('titan_signal_events', function (Blueprint $table): void {
            $columns = [
                'event_id', 'event_type', 'scope', 'occurred_at', 'recorded_at', 'causation_id',
                'actor_type', 'actor_id', 'source', 'source_component', 'schema_version', 'metadata',
                'severity', 'category', 'idempotency_key', 'deduplication_key', 'vertical_key', 'checksum',
            ];
            foreach ($columns as $column) {
                if (Schema::hasColumn('titan_signal_events', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
