<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Privacy;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;

final class CrmRetentionService
{
    public function __construct(private ConnectionInterface $db) {}

    public function policies(int $userId): array
    {
        return $this->db->table('crm_retention_policies')->where('company_id', CrmCompanyScope::companyId($userId))->orderBy('resource_type')->get()->map(fn($r)=>(array)$r)->all();
    }

    public function set(int $userId, string $resourceType, int $days, string $action='review'): array
    {
        if ($days < 30 || $days > 36500) throw new \InvalidArgumentException('Retention days must be between 30 and 36500.');
        if (! in_array($action, ['review','anonymize','delete'], true)) throw new \InvalidArgumentException('Unsupported retention action.');
        $this->tableFor($resourceType); // validate
        $this->db->table('crm_retention_policies')->updateOrInsert(
            ['company_id' => CrmCompanyScope::companyId($userId), 'resource_type'=>$resourceType],
            ['user_id'=>CrmCompanyScope::actorUserId($userId),'retention_days'=>$days,'action'=>$action,'enabled'=>true,'created_at'=>now(),'updated_at'=>now()]
        );
        return ['resource_type'=>$resourceType,'retention_days'=>$days,'action'=>$action,'enabled'=>true,'affected_count'=>1];
    }

    public function due(int $userId, string $resourceType, int $limit=500): array
    {
        $policy = $this->db->table('crm_retention_policies')->where('company_id', CrmCompanyScope::companyId($userId))->where('resource_type',$resourceType)->where('enabled',true)->first();
        if (! $policy) return [];
        $table = $this->tableFor($resourceType);
        $limit = min(max(1,$limit),500);
        $query = $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('updated_at','<',now()->subDays((int)$policy->retention_days));
        if ($this->hasSoftDelete($resourceType)) $query->whereNull('deleted_at');
        return $query->limit($limit)->get()->map(fn($r)=>(array)$r)->all();
    }

    public function executeDue(int $userId, string $resourceType, int $limit=100, bool $confirmed = false): array
    {
        $policy = $this->db->table('crm_retention_policies')->where('company_id', CrmCompanyScope::companyId($userId))->where('resource_type',$resourceType)->where('enabled',true)->first();
        if (! $policy) return ['action'=>'none','processed'=>0];
        $limit = min(max(1,$limit),500);
        $rows = $this->due($userId, $resourceType, $limit);
        $action = (string) $policy->action;

        if ($action === 'review') return ['action'=>'review','processed'=>0,'due_count'=>count($rows)];
        if (! $confirmed) throw new \RuntimeException('Retention destructive action requires confirmation.');

        $table = $this->tableFor($resourceType);
        $processed = 0;
        $this->db->transaction(function () use ($rows,$resourceType,$table,$userId,$action,&$processed): void {
            foreach ($rows as $row) {
                $id = $row['id'] ?? null;
                if (! $id) continue;
                if ($action === 'anonymize') {
                    $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('id',$id)->update($this->anonymizeValues($resourceType));
                } elseif ($action === 'delete') {
                    $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('id',$id)->update(['deleted_at'=>now(),'updated_at'=>now()]);
                }
                $processed++;
            }
        });

        return ['action'=>$action,'processed'=>$processed,'due_count'=>count($rows)];
    }

    private function tableFor(string $resourceType): string
    {
        return match($resourceType) {
            'contacts'=>'crm_contacts',
            'leads'=>'crm_leads',
            'activities'=>'crm_activities',
            'email_messages'=>'crm_email_messages',
            default=>throw new \InvalidArgumentException('Unsupported retention resource type.'),
        };
    }

    private function hasSoftDelete(string $resourceType): bool
    {
        return in_array($resourceType, ['contacts','leads','activities','email_messages'], true);
    }

    private function anonymizeValues(string $resourceType): array
    {
        return match($resourceType) {
            'contacts'=>['first_name'=>'Anonymized','last_name'=>null,'email'=>null,'phone'=>null,'normalized_email'=>null,'normalized_phone'=>null,'updated_at'=>now()],
            'leads'=>['name'=>'Anonymized lead','email'=>null,'phone'=>null,'normalized_email'=>null,'normalized_phone'=>null,'updated_at'=>now()],
            'activities'=>['subject'=>'Anonymized activity','description'=>null,'metadata'=>json_encode([]),'updated_at'=>now()],
            'email_messages'=>['from_email'=>null,'to_emails'=>json_encode([]),'cc_emails'=>json_encode([]),'subject'=>'Anonymized email','body_text'=>null,'normalized_email'=>null,'metadata'=>json_encode([]),'updated_at'=>now()],
            default=>['updated_at'=>now()],
        };
    }
}
