<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanRewind\System\Reconstruction\RewindTimelineAssembler;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

final class FoundationContractTest extends TestCase
{
    public function test_trace_query_requires_explicit_tenant_and_uuid_trace(): void
    {
        $query=RewindTraceQuery::fromArray(['tenant_company_id'=>7,'trace_id'=>'3d6f0a0f-4fca-4f82-92ff-8ec45137eaea']); self::assertSame(7,$query->tenantCompanyId());
        $this->expectException(InvalidArgumentException::class); RewindTraceQuery::fromArray(['tenant_company_id'=>0,'trace_id'=>'3d6f0a0f-4fca-4f82-92ff-8ec45137eaea']);
    }

    public function test_snapshot_sanitizer_redacts_secrets_and_rejects_hidden_reasoning(): void
    {
        $sanitizer=new RewindPayloadSanitizer(['token']); self::assertSame('[REDACTED]',$sanitizer->sanitize(['token'=>'x'])['token']);
        $this->expectException(InvalidArgumentException::class); $sanitizer->sanitize(['nested'=>['chain_of_thought'=>'x']]);
    }

    public function test_timeline_order_is_deterministic(): void
    {
        $events=[['event_id'=>'b','sequence'=>2,'occurred_at'=>'2026-01-01T00:00:00Z'],['event_id'=>'a','sequence'=>1,'occurred_at'=>'2026-01-01T00:00:01Z']];
        self::assertSame(['a','b'],array_column((new RewindTimelineAssembler())->order($events),'event_id'));
    }
}
