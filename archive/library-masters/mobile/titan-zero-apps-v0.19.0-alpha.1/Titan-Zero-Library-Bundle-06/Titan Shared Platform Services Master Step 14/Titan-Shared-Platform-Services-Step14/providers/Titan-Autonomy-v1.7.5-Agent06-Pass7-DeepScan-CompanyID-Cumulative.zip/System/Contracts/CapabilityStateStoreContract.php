<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;

interface CapabilityStateStoreContract
{
    public function save(CapabilityState $state): void;
}
