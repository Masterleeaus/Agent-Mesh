<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Forensics\RewindTemporalDiagnostics;
use App\Extensions\TitanRewind\System\Models\RewindDriftFinding;
use App\Extensions\TitanRewind\System\Models\RewindTraceEvent;
use App\Extensions\TitanRewind\System\Models\RewindTraceIndex;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTimelineAssembler;

final class RewindTraceProjector
{
    public function __construct(private RewindTemporalDiagnostics $temporal,private RewindTimelineAssembler $assembler,private RewindIntegrityService $integrity){}

    public function refresh(int $tenantCompanyId,string $traceId): RewindTraceIndex
    {
        $sources=[];$decisions=[];$policies=[];$guides=[];$models=[];$mutationCount=0;$outcomeCount=0;$hasRecovery=false;$hasCompensation=false;$eventCount=0;$first=null;$last=null;$window=[];
        $cursor=RewindTraceEvent::query()->where('tenant_company_id',$tenantCompanyId)->where('trace_id',$traceId)->orderBy('sequence')->orderBy('occurred_at')->orderBy('event_id')->cursor();
        foreach($cursor as $event){++$eventCount;$first??=$event;$last=$event;if(count($window)<5000)$window[]=$event->toArray();
            if($event->source_engine)$sources[(string)$event->source_engine]=true;if($event->decision_id)$decisions[(string)$event->decision_id]=true;if($event->policy_version)$policies[(string)$event->policy_version]=true;if($event->guide_version)$guides[(string)$event->guide_version]=true;
            if($event->model_name){$mv=implode(':',array_filter([$event->model_provider,$event->model_name,$event->model_version],static fn($v)=>$v!==null&&$v!==''));if($mv!=='')$models[$mv]=true;}
            $type=strtolower((string)$event->event_type);if(str_contains($type,'mutation')||str_contains($type,'command.'))++$mutationCount;if(str_starts_with($type,'outcome.')||strtolower((string)$event->source_engine)==='titan-wisdom-engine')++$outcomeCount;if(str_contains($type,'recover')||str_contains($type,'rollback'))$hasRecovery=true;if(str_contains($type,'compensat'))$hasCompensation=true;
        }
        $temporalCursor=RewindTraceEvent::query()->where('tenant_company_id',$tenantCompanyId)->where('trace_id',$traceId)->orderBy('id')->cursor();$temporal=$this->temporal->analyseStream($temporalCursor);
        $causation=$this->assembler->causation($this->assembler->order($window));$integrity=$this->integrity->inspectTrace(\App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery::fromArray(['tenant_company_id'=>$tenantCompanyId,'trace_id'=>$traceId]));
        $openDriftCount=RewindDriftFinding::query()->where('tenant_company_id',$tenantCompanyId)->where('trace_id',$traceId)->where('status','open')->count();$criticalDrift=RewindDriftFinding::query()->where('tenant_company_id',$tenantCompanyId)->where('trace_id',$traceId)->where('status','open')->where('severity','critical')->exists();
        $forensicState=$criticalDrift||($integrity['status']??null)==='failed'?'critical':(($integrity['status']??null)==='partial'||($temporal['status']??null)==='review'||count($causation['orphans']??[])>0||$openDriftCount>0?'review':'clear');
        $list=static function(array $set):array{$x=array_keys($set);sort($x,SORT_STRING);return $x;};
        return RewindTraceIndex::query()->updateOrCreate(['tenant_company_id'=>$tenantCompanyId,'trace_id'=>$traceId],[
            'correlation_id'=>$last?->correlation_id??$first?->correlation_id,'first_event_at'=>$first?->occurred_at,'last_event_at'=>$last?->occurred_at,'event_count'=>$eventCount,'source_count'=>count($sources),'decision_count'=>count($decisions),'mutation_count'=>$mutationCount,'outcome_count'=>$outcomeCount,'has_recovery'=>$hasRecovery,'has_compensation'=>$hasCompensation,
            'reconstruction_status'=>$eventCount===0?'empty':'ready','integrity_state'=>$integrity['status'],'source_engines'=>$list($sources),'policy_versions'=>$list($policies),'guide_versions'=>$list($guides),'model_versions'=>$list($models),'latest_event_id'=>$last?->event_id,
            'late_event_count'=>(int)($temporal['late_event_count']??0),'out_of_order_arrival_count'=>(int)($temporal['out_of_order_arrival_count']??0),'sequence_collision_count'=>(int)($temporal['sequence_collision_count']??0),'causation_orphan_count'=>count($causation['orphans']??[]),'forensic_state'=>$forensicState,'open_drift_count'=>$openDriftCount,'materialized_at'=>now(),'reconstruction_version'=>4,
        ]);
    }
}
