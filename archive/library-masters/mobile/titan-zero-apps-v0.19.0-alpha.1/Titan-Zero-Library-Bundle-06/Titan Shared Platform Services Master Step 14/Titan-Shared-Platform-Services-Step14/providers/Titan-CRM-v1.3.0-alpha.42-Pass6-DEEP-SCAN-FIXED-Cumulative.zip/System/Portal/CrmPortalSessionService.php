<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Portal;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

final class CrmPortalSessionService
{
    public function __construct(private ConnectionInterface $db) {}

    public function bind(array $grant, Request $request): array
    {
        if (! $request->hasSession()) {
            throw new AccessDeniedHttpException('CRM portal access requires a secure browser session.');
        }
        $sessionId=trim((string)$request->session()->getId());
        if($sessionId==='') throw new AccessDeniedHttpException('CRM portal session is unavailable.');

        $grantId=(string)$grant['public_id'];
        $sessionHash=$this->hash($grantId.'|'.$sessionId);
        $existing=$this->db->table('crm_portal_sessions')->where('portal_grant_public_id',$grantId)->where('session_hash',$sessionHash)->first();
        if($existing){
            if($existing->revoked_at || now()->greaterThan($existing->expires_at)) throw new AccessDeniedHttpException('CRM portal session has expired.');
            $uaHash=$this->userAgentHash($request);$ipHash=$this->requestIpHash($request);
            if($existing->user_agent_hash && $uaHash && !hash_equals((string)$existing->user_agent_hash,$uaHash)){
                $this->db->table('crm_portal_sessions')->where('id',$existing->id)->update(['revoked_at'=>now(),'updated_at'=>now()]);
                throw new AccessDeniedHttpException('CRM portal session binding changed. Reopen the secure link in a trusted browser.');
            }
            if((bool)config('crm.portal.bind_ip',false) && $existing->ip_hash && $ipHash && !hash_equals((string)$existing->ip_hash,$ipHash)){
                $this->db->table('crm_portal_sessions')->where('id',$existing->id)->update(['revoked_at'=>now(),'updated_at'=>now()]);
                throw new AccessDeniedHttpException('CRM portal network binding changed. Reopen the secure link.');
            }
            $this->db->table('crm_portal_sessions')->where('id',$existing->id)->update(['last_seen_at'=>now(),'ip_hash'=>$ipHash,'user_agent_hash'=>$uaHash,'updated_at'=>now()]);
            return (array)$this->db->table('crm_portal_sessions')->where('id',$existing->id)->first();
        }

        $max=max(1,(int)config('crm.portal.max_active_sessions_per_grant',3));
        $active=(int)$this->db->table('crm_portal_sessions')->where('portal_grant_public_id',$grantId)->whereNull('revoked_at')->where('expires_at','>',now())->count();
        if($active >= $max) throw new AccessDeniedHttpException('CRM portal session limit reached for this access grant.');

        $expires=now()->addHours(max(1,(int)config('crm.portal.session_ttl_hours',12)));
        if(isset($grant['expires_at']) && Carbon::parse((string)$grant['expires_at'])->lessThan($expires)) $expires=Carbon::parse((string)$grant['expires_at']);
        $publicId=(string)Str::ulid();
        $this->db->table('crm_portal_sessions')->insert([
            'public_id'=>$publicId,'company_id'=>(int)$grant['company_id'],'user_id'=>(int)$grant['user_id'],
            'portal_grant_public_id'=>$grantId,'session_hash'=>$sessionHash,'ip_hash'=>$this->requestIpHash($request),'user_agent_hash'=>$this->userAgentHash($request),
            'last_seen_at'=>now(),'expires_at'=>$expires,'metadata'=>json_encode([]),'created_at'=>now(),'updated_at'=>now(),
        ]);
        return (array)$this->db->table('crm_portal_sessions')->where('public_id',$publicId)->first();
    }

    public function markVerified(array $grant, Request $request, string $method='verification_code'): array
    {
        $session=$this->bind($grant,$request);
        $this->db->table('crm_portal_sessions')->where('id',$session['id'])->update([
            'identity_method'=>$method,'identity_verified_at'=>now(),'last_seen_at'=>now(),'updated_at'=>now(),
        ]);
        return (array)$this->db->table('crm_portal_sessions')->where('id',$session['id'])->first();
    }

    public function verified(array $grant, Request $request): bool
    {
        try{$session=$this->bind($grant,$request);}catch(\Throwable){return false;}
        return !empty($session['identity_verified_at']) && empty($session['revoked_at']);
    }

    public function requireVerified(array $grant, Request $request): array
    {
        $session=$this->bind($grant,$request);
        if(empty($session['identity_verified_at'])) throw new AccessDeniedHttpException('Customer identity verification is required for this portal action.');
        return $session;
    }

    public function revokeGrant(string $grantPublicId): void
    {
        $this->db->table('crm_portal_sessions')->where('portal_grant_public_id',$grantPublicId)->whereNull('revoked_at')->update(['revoked_at'=>now(),'updated_at'=>now()]);
    }

    private function hash(string $value): string { return hash_hmac('sha256',$value,$this->secret()); }
    private function requestIpHash(Request $request): ?string { $ip=$request->ip(); return $ip?$this->hash('ip|'.$ip):null; }
    private function userAgentHash(Request $request): ?string { $ua=trim((string)$request->userAgent()); return $ua!==''?$this->hash('ua|'.mb_substr($ua,0,1000)):null; }
    private function secret(): string { $key=(string)config('app.key'); return $key!==''?$key:'crm-portal-session-fallback'; }
}
