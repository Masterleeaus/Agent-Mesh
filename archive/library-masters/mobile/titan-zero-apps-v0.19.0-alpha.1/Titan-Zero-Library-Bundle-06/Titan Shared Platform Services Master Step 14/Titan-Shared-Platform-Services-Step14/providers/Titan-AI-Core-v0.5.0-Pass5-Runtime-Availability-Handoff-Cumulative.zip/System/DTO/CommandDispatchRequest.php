<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\DTO;

final readonly class CommandDispatchRequest
{
    public function __construct(
        public string $planId,
        public string $stepId,
        public string $capability,
        public array $payload,
        public string $tenantCompanyId,
        public string $actorId,
        public string $actorType,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $rootCausationId,
        public string $operationId,
        public string $idempotencyKey,
    ) {}
}
