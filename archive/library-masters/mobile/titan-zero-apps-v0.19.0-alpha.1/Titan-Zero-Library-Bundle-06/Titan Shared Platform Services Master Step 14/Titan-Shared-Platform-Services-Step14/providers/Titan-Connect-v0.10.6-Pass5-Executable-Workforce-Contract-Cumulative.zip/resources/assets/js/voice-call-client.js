(() => {
    'use strict';

    class TitanConnectVoiceCall {
        constructor(options) {
            this.options = options || {};
            this.ws = null;
            this.connection = null;
            this.mediaStream = null;
            this.micAudioContext = null;
            this.playbackAudioContext = null;
            this.audioProcessor = null;
            this.micAnalyser = null;
            this.playbackAnalyser = null;
            this.nextPlaybackTime = 0;
            this.waveformAnimationId = null;
            this.waveform = new Array(15).fill(0);
            this.startedAt = Date.now();
            this.elapsedTimerId = null;
            this.muted = false;
            this.endPromise = null;
            this.root = document.querySelector('[data-titan-connect-voice-call]');
        }

        async connect(session) {
            if (!session || !session.provider) throw new Error('Voice session payload is missing.');
            if (session.provider === 'openai_realtime') return this.connectOpenAI(session);
            if (session.provider === 'elevenlabs') return this.connectElevenLabs(session);
            throw new Error('Unsupported voice session provider.');
        }

        async connectOpenAI(session) {
            const model = session.model || 'gpt-realtime';
            const base = session.websocket_url || 'wss://api.openai.com/v1/realtime';
            const ws = new WebSocket(`${base}?model=${encodeURIComponent(model)}`, [
                'realtime',
                `openai-insecure-api-key.${session.ephemeral_key}`,
                'openai-beta.realtime-v1'
            ]);
            this.ws = ws;
            ws.addEventListener('open', async () => {
                this.setStatus('connected');
                this.startElapsed();
                ws.send(JSON.stringify({type: 'session.update', session: {input_audio_transcription: {model: 'gpt-4o-mini-transcribe'}, turn_detection: {type: 'server_vad'}}}));
                await this.startMicrophone(ws);
                this.startWaveform();
            });
            ws.addEventListener('message', event => this.handleOpenAIMessage(event));
            ws.addEventListener('close', () => this.setStatus('disconnected'));
            ws.addEventListener('error', () => this.setStatus('error'));
        }

        handleOpenAIMessage(event) {
            let msg; try { msg = JSON.parse(event.data); } catch (_) { return; }
            if (msg.type === 'conversation.item.input_audio_transcription.completed') {
                const transcript = String(msg.transcript || '').trim(); if (transcript) this.addTranscript('user', transcript);
            }
            if (msg.type === 'response.audio_transcript.done') {
                const transcript = String(msg.transcript || '').trim(); if (transcript) this.addTranscript('assistant', transcript);
            }
            if (msg.type === 'response.audio.delta' && msg.delta) this.playPcmBase64(msg.delta);
            if (msg.type === 'error') this.setStatus('error');
        }

        async startMicrophone(ws) {
            this.mediaStream = await navigator.mediaDevices.getUserMedia({audio: {channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true}});
            this.micAudioContext = new AudioContext({sampleRate: 24000});
            const source = this.micAudioContext.createMediaStreamSource(this.mediaStream);
            this.micAnalyser = this.micAudioContext.createAnalyser(); this.micAnalyser.fftSize = 64; source.connect(this.micAnalyser);
            this.audioProcessor = this.micAudioContext.createScriptProcessor(4096, 1, 1);
            const silent = this.micAudioContext.createGain(); silent.gain.value = 0;
            source.connect(this.audioProcessor); this.audioProcessor.connect(silent); silent.connect(this.micAudioContext.destination);
            this.audioProcessor.onaudioprocess = event => {
                if (ws.readyState !== WebSocket.OPEN) return;
                const input = event.inputBuffer.getChannelData(0); const pcm16 = new Int16Array(input.length);
                for (let i = 0; i < input.length; i++) pcm16[i] = Math.max(-32768, Math.min(32767, Math.floor(input[i] * 32768)));
                const bytes = new Uint8Array(pcm16.buffer); let binary = ''; for (const byte of bytes) binary += String.fromCharCode(byte);
                ws.send(JSON.stringify({type: 'input_audio_buffer.append', audio: btoa(binary)}));
            };
        }

        playPcmBase64(base64) {
            const binary = atob(base64); const bytes = new Uint8Array(binary.length); for (let i=0;i<binary.length;i++) bytes[i]=binary.charCodeAt(i);
            const pcm16 = new Int16Array(bytes.buffer); const float32 = new Float32Array(pcm16.length); for (let i=0;i<pcm16.length;i++) float32[i]=pcm16[i]/32768;
            if (!this.playbackAudioContext) {
                this.playbackAudioContext = new AudioContext({sampleRate: 24000}); this.playbackAnalyser=this.playbackAudioContext.createAnalyser(); this.playbackAnalyser.fftSize=64; this.playbackAnalyser.connect(this.playbackAudioContext.destination);
            }
            const buffer=this.playbackAudioContext.createBuffer(1,float32.length,24000); buffer.copyToChannel(float32,0); const source=this.playbackAudioContext.createBufferSource(); source.buffer=buffer; source.connect(this.playbackAnalyser);
            const now=this.playbackAudioContext.currentTime; const start=Math.max(now,this.nextPlaybackTime); source.start(start); this.nextPlaybackTime=start+buffer.duration;
        }

        async connectElevenLabs(session) {
            if (!window.ElevenLabs || !window.ElevenLabs.Conversation) await this.loadScript(session.sdk_url);
            const ConversationClass = window.ElevenLabs?.Conversation || window.Conversation;
            if (!ConversationClass) throw new Error('ElevenLabs Conversation SDK did not load.');
            const config = {
                onConnect: () => { this.setStatus('connected'); this.startElapsed(); this.startWaveform(); },
                onDisconnect: () => this.setStatus('disconnected'),
                onError: () => this.setStatus('error'),
                onMessage: message => {
                    const role = message?.source === 'user' ? 'user' : 'assistant';
                    const text = String(message?.message || message?.text || '').trim(); if (text) this.addTranscript(role, text);
                }
            };
            if (session.signed_url) config.signedUrl = session.signed_url; else config.agentId = session.agent_id;
            this.connection = await ConversationClass.startSession(config);
        }

        loadScript(src) {
            return new Promise((resolve, reject) => { const s=document.createElement('script'); s.src=src; s.onload=resolve; s.onerror=reject; document.head.appendChild(s); });
        }

        async addTranscript(role, transcript) {
            const target=this.root?.querySelector('[data-role="transcript"]');
            if (target) { const line=document.createElement('div'); line.className=`tc-voice-line tc-voice-line--${role}`; line.textContent=`${role}: ${transcript}`; target.appendChild(line); }
            if (this.options.transcriptUrl) await fetch(this.options.transcriptUrl,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':this.options.csrf||''},body:JSON.stringify({role,message:transcript,client_event_id:(crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`)})});
        }

        startWaveform() {
            const target=this.root?.querySelector('[data-role="waveform"]'); if (!target) return;
            const update=()=>{ const analyser=this.playbackAnalyser||this.micAnalyser; const data=new Uint8Array(analyser?.frequencyBinCount||32); if(analyser) analyser.getByteFrequencyData(data); this.waveform=this.waveform.map((_,i)=>analyser?Math.max(.08,(data[i%data.length]||0)/255):.08); target.innerHTML=this.waveform.map(v=>`<i style="transform:scaleY(${v})"></i>`).join(''); this.waveformAnimationId=requestAnimationFrame(update); }; update();
        }

        setStatus(status) { const target=this.root?.querySelector('[data-role="status"]'); if(target) target.textContent=status; }

        startElapsed() {
            if (this.elapsedTimerId) return;
            const target=this.root?.querySelector('[data-role="elapsed"]');
            const tick=()=>{ const seconds=Math.max(0,Math.floor((Date.now()-this.startedAt)/1000)); const minutes=Math.floor(seconds/60); const rest=seconds%60; if(target) target.textContent=`${String(minutes).padStart(2,'0')}:${String(rest).padStart(2,'0')}`; };
            tick(); this.elapsedTimerId=window.setInterval(tick,1000);
        }

        toggleMute() {
            this.muted=!this.muted;
            if(this.mediaStream) this.mediaStream.getAudioTracks().forEach(track=>{track.enabled=!this.muted;});
            const button=this.root?.querySelector('[data-action="mute"]'); if(button) button.textContent=this.muted?'Unmute':'Mute';
            this.setStatus(this.muted?'muted':'connected');
        }

        async end() {
            if (this.endPromise) return this.endPromise;
            this.endPromise=(async()=>{
                this.setStatus('ending');
                if (this.waveformAnimationId) cancelAnimationFrame(this.waveformAnimationId);
                if (this.elapsedTimerId) window.clearInterval(this.elapsedTimerId);
                if (this.ws && this.ws.readyState < 2) this.ws.close();
                if (this.connection?.endSession) await this.connection.endSession();
                if (this.audioProcessor) this.audioProcessor.disconnect();
                if (this.mediaStream) this.mediaStream.getTracks().forEach(t=>t.stop());
                if (this.micAudioContext) await this.micAudioContext.close().catch(()=>{});
                if (this.playbackAudioContext) await this.playbackAudioContext.close().catch(()=>{});
                if (this.options.endUrl) await fetch(this.options.endUrl,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':this.options.csrf||''},body:'{}'});
                this.setStatus('ended');
            })();
            return this.endPromise;
        }
    }

    window.TitanConnectVoiceCall = TitanConnectVoiceCall;
    if (window.TitanConnectVoiceBoot) {
        const client = new TitanConnectVoiceCall(window.TitanConnectVoiceBoot); window.titanConnectVoiceCall=client;
        document.querySelector('[data-action="mute"]')?.addEventListener('click',()=>client.toggleMute());
        document.querySelector('[data-action="end-call"]')?.addEventListener('click',()=>client.end());
        if (window.TitanConnectVoiceBoot.sessionUrl) {
            fetch(window.TitanConnectVoiceBoot.sessionUrl, {method:'POST', credentials:'same-origin', headers:{'Accept':'application/json','Content-Type':'application/json','X-CSRF-TOKEN':window.TitanConnectVoiceBoot.csrf||''}, body:'{}'})
                .then(r => r.ok ? r.json() : Promise.reject(new Error(`Voice session failed (${r.status})`)))
                .then(payload => client.connect(payload.session))
                .catch(() => client.setStatus('error'));
        }
    }
})();
