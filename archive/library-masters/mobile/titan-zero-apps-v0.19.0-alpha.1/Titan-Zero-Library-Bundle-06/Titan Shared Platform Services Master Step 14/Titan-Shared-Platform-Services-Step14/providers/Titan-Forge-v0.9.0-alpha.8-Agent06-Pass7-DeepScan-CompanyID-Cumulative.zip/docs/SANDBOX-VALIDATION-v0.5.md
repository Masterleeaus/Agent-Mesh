# Titan Forge Sandbox & Validation Foundation — v0.5

## Purpose

This pass creates a bounded generation workspace and a deterministic local artifact-validation pipeline before any governed release work is allowed.

## Sandbox boundary

`SandboxWorkspaceFactory` derives a workspace only from trusted `BuildContext` values:

`<configured_root>/<tenant_company_id>/<operation_id>`

`SandboxWorkspace` owns reset, safe path resolution, atomic write, snapshot and destroy operations. It does not execute commands and it does not write to `app/Extensions`.

### Hard rejection

- traversal or absolute paths
- Windows drive/backslash paths
- NUL bytes
- symlink roots, parents or artifacts
- case-insensitive path collisions
- unsupported filesystem entries
- artifact count above policy
- artifact bytes above policy

## Typed artifact set

Every snapshot produces `BuildArtifact` records with:

- relative path
- SHA-256
- type
- byte size
- sandbox metadata

The collection is represented by `ArtifactSet`, which rejects case-insensitive duplicate paths and provides a deterministic digest.

## Validator registry

`ValidatorRegistry` requires unique stable IDs and preserves registration order. `ArtifactValidationPipeline` executes every validator and converts validator runtime errors into critical blocking findings so validation fails closed.

Current validators:

- `artifact-policy`
- `workspace-integrity`
- `generated-secret-scan`
- `generation-manifest`
- `generated-code-safety`
- `json-syntax`
- `php-syntax`

## Manifest rule

`generation_manifest.json` must preserve build/tenant/operation provenance, match the sandbox artifact set, carry a valid deterministic fingerprint and declare:

`deployment_authority: none`

## Runtime lifecycle

The deterministic workforce path now records:

`generating -> generated -> validating -> validated | validation_failed`

Validation run metadata and individual findings are stored in the existing `titan_forge_validation_runs` and `titan_forge_validation_findings` tables.

## Explicit non-goals

- no arbitrary command runner
- no network access layer
- no container/Docker execution
- no direct extension installation
- no release candidate creation from local validation alone
- no production mutation
