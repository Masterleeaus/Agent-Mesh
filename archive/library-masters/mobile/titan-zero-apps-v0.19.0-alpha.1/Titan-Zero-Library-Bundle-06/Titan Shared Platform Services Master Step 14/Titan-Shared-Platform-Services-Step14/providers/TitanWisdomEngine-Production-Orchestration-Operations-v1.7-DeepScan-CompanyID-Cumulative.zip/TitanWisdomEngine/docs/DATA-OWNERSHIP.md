# Data Ownership

Wisdom owns retrospective outcome-learning state only. Source business truth remains owned by its domain engine.

## Canonical owned tables

- `titan_wisdom_outcome_records` — canonical OutcomeRecord projections and append-only revision/contradiction records.
- `titan_wisdom_evidence_references` — evidence provenance and validation state.
- `titan_wisdom_outcome_evidence` — tenant-scoped relationship links between outcomes and evidence.
- `titan_wisdom_outcome_transitions` — append-only state-transition snapshots for mutable pending/observing projections.
- `titan_wisdom_outcomes` — retained legacy scaffold compatibility table; no new canonical writes.

Wisdom records source references rather than assuming ownership of CRM, payment, job, sensor or other business records. One canonical evidence reference may link to multiple related outcomes inside the same tenant. Every owned lookup/mutation is tenant-scoped by `tenant_company_id`; `user_id` and CRM customer `company_id` are not valid substitutes.

Attribution and calibration remain separate future Wisdom-owned domains rather than arbitrary JSON embedded into evidence or OutcomeRecord payloads.
