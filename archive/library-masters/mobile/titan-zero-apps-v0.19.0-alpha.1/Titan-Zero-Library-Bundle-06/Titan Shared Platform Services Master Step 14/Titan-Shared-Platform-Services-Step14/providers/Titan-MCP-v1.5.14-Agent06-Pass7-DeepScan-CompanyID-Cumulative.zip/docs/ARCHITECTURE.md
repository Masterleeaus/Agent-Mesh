# Architecture

Titan MCP is a `system-engine` extension. `TitanMcpServiceProvider` owns container registration, route/view/migration bootstrapping, rate limits and navigation contributions. `McpTransportController` implements the extension-owned MCP JSON-RPC transport. `McpCatalogue` is the authoritative 21-tool registry and `McpToolInvoker` resolves its handlers through Laravel's container.

Read services are separated from mutation services. Mutation services depend on `BackupManager` / `DatabaseBackupManager`, `OperationLockManager`, `WriteSafetyGate` and `AuditLogger`. The extension never becomes the source of truth for tenant business records.
