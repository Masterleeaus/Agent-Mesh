# Capabilities

Operational now:

- `titan-wisdom`
- `wisdom.health.read`
- `wisdom.readiness.read`
- `wisdom.outcome.record`
- `wisdom.evidence.attach`
- `wisdom.outcome.resolve`
- `wisdom.outcome.revise`

## wisdom.outcome.record

Creates the canonical tenant-scoped OutcomeRecord. A fresh governance `ALLOW`, complete causal context and a stable source `operation_id` are mandatory. Idempotency is capability-owned.

## wisdom.evidence.attach

Stores a canonical EvidenceReference separately from interpretation and links it to a tenant outcome as `supports`, `contradicts`, or `context`. Self-reported AI/agent evidence may remain `claimed`; it cannot become authoritative without independent validation provenance.

## wisdom.outcome.resolve

Resolves a non-terminal outcome through an optimistic CAS transition. Conclusive resolution requires at least one linked evidence reference that is `validated`, `authoritative_for_fact=true`, and related as `supports`. The transition stores the resulting record snapshot so same-operation retries can return the original receipt.

## wisdom.outcome.revise

Creates a new append-only `revised` or `contradicted` OutcomeRecord referencing the prior terminal record. It never overwrites the historical record. `contradicted` additionally requires authoritative validated evidence linked as `contradicts`.

Reserved until implemented: `wisdom.attribute`, `wisdom.learn`, and `wisdom.calibrate`.
