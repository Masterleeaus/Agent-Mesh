<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Domains\BusinessConfiguration;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class BusinessHoursService
{
    public function __construct(private readonly ConnectionInterface $db) {}

    public function read(int $actorUserId): array
    {
        return $this->db->table('crm_business_hours')
            ->where('company_id',CrmCompanyScope::companyId($actorUserId))
            ->orderBy('day_of_week')->orderBy('window_index')->get()->map(fn($r)=>(array)$r)->all();
    }

    /** Replaces the active weekly business-hours definition atomically. */
    public function update(int $actorUserId,array $definition): array
    {
        $timezone=trim((string)($definition['timezone']??''));
        if($timezone==='' || !in_array($timezone,\DateTimeZone::listIdentifiers(),true)) throw new InvalidArgumentException('A valid IANA business timezone is required.');
        $days=(array)($definition['days']??[]);
        $rows=[];
        foreach($days as $day=>$value){
            $dow=is_numeric($day)?(int)$day:$this->dayNumber((string)$day);
            if($dow<0||$dow>6) throw new InvalidArgumentException('Business-hours day must be 0-6 or a weekday name.');
            $cfg=is_array($value)?$value:[];
            $closed=(bool)($cfg['closed']??false);
            $windows=(array)($cfg['windows']??[]);
            if($closed||$windows===[]) $windows=[['opens_at'=>null,'closes_at'=>null]];
            foreach($windows as $index=>$window){
                $open=$window['opens_at']??$window['open']??null;$close=$window['closes_at']??$window['close']??null;
                if(!$closed && (!$this->validTime($open)||!$this->validTime($close))) throw new InvalidArgumentException('Open business days require valid opens_at/closes_at times.');
                $rows[]=['public_id'=>(string)Str::ulid(),'company_id'=>CrmCompanyScope::companyId($actorUserId),'day_of_week'=>$dow,'window_index'=>(int)$index,'opens_at'=>$closed?null:$open,'closes_at'=>$closed?null:$close,'closed'=>$closed,'timezone'=>$timezone,'holiday_behavior'=>(string)($cfg['holiday_behavior']??$definition['holiday_behavior']??'closed'),'after_hours_available'=>(bool)($cfg['after_hours_available']??$definition['after_hours_available']??false),'emergency_available'=>(bool)($cfg['emergency_available']??$definition['emergency_available']??false),'metadata'=>isset($cfg['metadata'])?json_encode($cfg['metadata']):null,'created_at'=>now(),'updated_at'=>now()];
            }
        }
        $this->db->transaction(function() use($actorUserId,$rows):void{
            $tenant=CrmCompanyScope::companyId($actorUserId);
            $this->db->table('crm_business_hours')->where('company_id',$tenant)->delete();
            if($rows!==[])$this->db->table('crm_business_hours')->insert($rows);
        });
        return $this->read($actorUserId);
    }

    private function dayNumber(string $day): int
    { return ['sunday'=>0,'monday'=>1,'tuesday'=>2,'wednesday'=>3,'thursday'=>4,'friday'=>5,'saturday'=>6][strtolower(trim($day))]??-1; }
    private function validTime(mixed $time): bool { return is_string($time)&&preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/',$time)===1; }
}
