<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Contracts;

use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompiledTitanConfig;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;

interface NexusCompilerContract
{
    public function version(): string;

    public function compile(
        BusinessProfile $profile,
        VerticalDefinition $definition,
        string $configurationVersion,
    ): CompiledTitanConfig;
}
