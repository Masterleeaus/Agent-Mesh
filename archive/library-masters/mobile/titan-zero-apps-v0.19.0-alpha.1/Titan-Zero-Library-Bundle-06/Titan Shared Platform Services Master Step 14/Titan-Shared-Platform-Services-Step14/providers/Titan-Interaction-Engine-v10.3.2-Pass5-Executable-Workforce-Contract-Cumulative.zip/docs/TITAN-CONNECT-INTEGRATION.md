# Titan Connect Integration

Titan Connect owns OAuth, credentials, provider APIs, transport, retries and webhooks. Interaction Engine stores only safe connection status, opaque references and message intent.

The current compatibility adapter uses the supplied public `MessagingToolGateway` only for supported outbound sends. The verified gateway uses integer company/actor IDs, so the adapter fails closed for incompatible identifiers rather than silently changing identity. Connection/OAuth start/status is not fabricated and remains unavailable until Connect exposes/binds an appropriate company-scoped public gateway.
