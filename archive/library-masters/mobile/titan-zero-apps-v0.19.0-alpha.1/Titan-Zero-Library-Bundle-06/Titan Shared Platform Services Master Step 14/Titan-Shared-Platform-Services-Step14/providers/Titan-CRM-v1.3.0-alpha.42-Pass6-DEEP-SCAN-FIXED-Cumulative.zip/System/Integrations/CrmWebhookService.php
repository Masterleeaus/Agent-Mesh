<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Integrations;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
final class CrmWebhookService
{
    public function __construct(private ConnectionInterface $db,private CrmOutboundUrlPolicy $urls){}
    public function create(int $userId,array $data):array
    {
        $url=(string)($data['url']??'');$this->urls->assertAllowed($url);$secret=$this->secret();$id=(string)Str::ulid();$events=array_values(array_unique(array_map('strval',(array)($data['events']??['*']))));
        $this->db->table('crm_webhooks')->insert(['public_id'=>$id,'company_id'=>CrmCompanyScope::companyId($userId),'user_id'=>CrmCompanyScope::actorUserId($userId),'name'=>mb_substr((string)($data['name']??'Webhook'),0,120),'url'=>$url,'secret_ciphertext'=>Crypt::encryptString($secret),'secret_version'=>1,'events'=>json_encode($events),'enabled'=>true,'created_at'=>now(),'updated_at'=>now()]);
        $row=(array)$this->db->table('crm_webhooks')->where('public_id',$id)->first();return ['webhook'=>$this->sanitizeRow($row),'secret'=>$secret];
    }
    public function rotateSecret(int $userId,string $id):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$row=$this->db->table('crm_webhooks')->where('company_id',$tenant)->where('public_id',$id)->lockForUpdate()->first();if(!$row)throw new NotFoundHttpException();
        $secret=$this->secret();$version=((int)($row->secret_version??1))+1;$grace=max(0,(int)config('crm.webhooks.rotation_grace_minutes',60));
        $this->db->table('crm_webhooks')->where('id',$row->id)->update(['previous_secret_ciphertext'=>$row->secret_ciphertext,'previous_secret_version'=>(int)($row->secret_version??1),'previous_secret_expires_at'=>$grace>0?now()->addMinutes($grace):now(),'secret_ciphertext'=>Crypt::encryptString($secret),'secret_version'=>$version,'secret_rotated_at'=>now(),'updated_at'=>now()]);
        return ['webhook'=>$this->sanitizeRow((array)$this->db->table('crm_webhooks')->where('id',$row->id)->first()),'secret'=>$secret];
    }
    public function list(int $userId):array
    {
        $tenant=CrmCompanyScope::companyId($userId);
        $deadLetters=$this->db->table('crm_webhook_deliveries')
            ->select('webhook_public_id',$this->db->raw('COUNT(*) as dead_letter_count'))
            ->where('company_id',$tenant)
            ->where('status','dead_letter')
            ->groupBy('webhook_public_id')
            ->pluck('dead_letter_count','webhook_public_id');
        return $this->db->table('crm_webhooks')->where('company_id',$tenant)->orderByDesc('id')->get()->map(function($r)use($deadLetters){
            $row=$this->sanitizeRow((array)$r);
            $row['dead_letter_count']=(int)($deadLetters[(string)$r->public_id]??0);
            return $row;
        })->all();
    }
    public function disable(int $userId,string $id):void{$n=$this->db->table('crm_webhooks')->where('company_id',CrmCompanyScope::companyId($userId))->where('public_id',$id)->update(['enabled'=>false,'updated_at'=>now()]);if(!$n)throw new NotFoundHttpException();}
    private function secret():string{return rtrim(strtr(base64_encode(random_bytes(32)),'+/','-_'),'=');}
    private function sanitizeRow(array $row):array{unset($row['secret_ciphertext'],$row['previous_secret_ciphertext']);if(isset($row['events'])&&is_string($row['events']))$row['events']=json_decode($row['events'],true)?:[];return $row;}
}
