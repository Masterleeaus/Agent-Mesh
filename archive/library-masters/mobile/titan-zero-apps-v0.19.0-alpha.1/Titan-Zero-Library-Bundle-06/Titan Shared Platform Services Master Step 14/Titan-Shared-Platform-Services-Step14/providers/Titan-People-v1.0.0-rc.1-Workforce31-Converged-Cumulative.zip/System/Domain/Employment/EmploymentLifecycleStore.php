<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Domain\Employment;
interface EmploymentLifecycleStore{public function findReceipt(int $tenantCompanyId,int $workerId,string $idempotencyKey):?EmploymentLifecycleResult;/** @return array{state:?string,version:int} */public function snapshot(int $tenantCompanyId,int $workerId):array;public function append(EmploymentLifecycleCommand $command,EmploymentLifecycleResult $result):EmploymentLifecycleResult;}
