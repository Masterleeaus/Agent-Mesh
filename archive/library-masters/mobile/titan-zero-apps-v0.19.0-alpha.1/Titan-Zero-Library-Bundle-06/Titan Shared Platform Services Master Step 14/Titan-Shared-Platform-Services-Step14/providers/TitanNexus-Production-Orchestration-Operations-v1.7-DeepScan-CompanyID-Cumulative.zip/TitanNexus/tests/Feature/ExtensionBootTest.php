<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanNexus\Feature;

use PHPUnit\Framework\TestCase;

final class ExtensionBootTest extends TestCase
{
    public function test_provider_declares_compiler_validation_history_provisioning_and_governance_bindings(): void
    {
        $provider = (string) file_get_contents(dirname(__DIR__, 2) . '/System/TitanNexusServiceProvider.php');

        foreach ([
            'CompilationRepositoryContract::class', 'EloquentCompilationRepository::class',
            'NexusCompilerContract::class', 'new DeterministicNexusCompiler',
            'VerticalDefinitionSourceContract::class', 'new VerticalEngineAdapter',
            'PlatformReadinessSourceContract::class', 'new PlatformReadinessAdapter',
            'NexusValidatorContract::class', 'SemanticNexusValidator::class',
            'ConfigurationDifferContract::class', 'SemanticConfigurationDiffer::class',
            'ProvisioningPlannerContract::class', 'DeterministicProvisioningPlanner::class',
            'ProvisioningCommandGatewayContract::class', 'CommandBusProvisioningAdapter',
            'ProvisioningExecutorContract::class', 'GovernedProvisioningExecutor::class',
            'RiskGatewayContract::class', 'RiskEngineAdapter::class',
            'GovernanceGatewayContract::class', 'GovernanceEngineAdapter::class',
            'AssuranceGatewayContract::class', 'AssuranceEngineAdapter::class',
            'SignalGatewayContract::class', 'SignalEngineAdapter::class',
            'RewindGatewayContract::class', 'RewindEngineAdapter::class',
            'AutonomyGatewayContract::class', 'AutonomyEngineAdapter::class',
            'NexusControlCentreContract::class', 'NexusControlCentreService::class',
            'TenantContextResolverContract::class', 'HostTenantContextResolver',
        ] as $token) {
            self::assertStringContainsString($token, $provider);
        }
        self::assertStringContainsString("registerKey(): string { return 'titan-nexus'; }", $provider);
    }

    public function test_manifest_truthfully_advertises_pass_six_blueprint_capabilities(): void
    {
        $manifest = json_decode((string) file_get_contents(dirname(__DIR__, 2) . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);

        self::assertSame('1.0.0-rc.2', $manifest['version']);
        self::assertSame('2.2', $manifest['schema_version']);
        self::assertSame('configuration-orchestrator', $manifest['architecture']['profile']);
        foreach ([
            'titan-nexus', 'nexus.domain-core', 'nexus.compile', 'nexus.vertical-engine-adapter',
            'nexus.validate', 'nexus.preview', 'nexus.platform-readiness-adapter',
            'nexus.compile.diff', 'nexus.recompile.plan', 'nexus.history.lineage',
            'nexus.provision.plan', 'nexus.provision.execute', 'nexus.command-bus-adapter',
            'nexus.provision.idempotency', 'nexus.provision.receipts',
            'nexus.risk.evaluate', 'nexus.governance.authorize', 'nexus.assurance.verify',
            'nexus.autonomy.authorize', 'nexus.signal.emit', 'nexus.rewind.evidence', 'nexus.contracts.v2.2',
            'nexus.control-centre', 'nexus.interface.read-model', 'nexus.host-ready', 'nexus.runtime-readiness',
        ] as $capability) {
            self::assertContains($capability, $manifest['capabilities']);
        }
        self::assertFalse($manifest['queues']['used']);
    }
}
