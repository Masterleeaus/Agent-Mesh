<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function fail_eq(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function same_eq(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_eq($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
foreach([
 '/System/Contracts/GovernanceEscalationStoreContract.php',
 '/System/Models/GovernanceEscalation.php',
 '/System/Escalation/GovernanceEscalationPriority.php',
 '/System/Escalation/GovernanceEscalationRepository.php',
] as $file){if(!is_file($root.$file))fail_eq('missing '.$file);}
require_once $root.'/System/Escalation/GovernanceEscalationPriority.php';

use App\Extensions\TitanGovernance\System\Escalation\GovernanceEscalationPriority;

$rows=[
 ['escalation_id'=>'age','risk_score'=>70.0,'urgency'=>80,'opened_at'=>'2026-08-20T10:00:00+10:00'],
 ['escalation_id'=>'risk','risk_score'=>90.0,'urgency'=>20,'opened_at'=>'2026-08-20T12:00:00+10:00'],
 ['escalation_id'=>'urgent','risk_score'=>70.0,'urgency'=>95,'opened_at'=>'2026-08-20T13:00:00+10:00'],
 ['escalation_id'=>'same-old','risk_score'=>70.0,'urgency'=>95,'opened_at'=>'2026-08-20T09:00:00+10:00'],
];
$sorted=(new GovernanceEscalationPriority())->sort($rows);
same_eq(['risk','same-old','urgent','age'],array_column($sorted,'escalation_id'),'queue order must be risk desc, urgency desc, age asc');
same_eq(90002000,$sorted[0]['priority_score'],'priority score exposes deterministic risk/urgency weighting');

$model=(string)file_get_contents($root.'/System/Models/GovernanceEscalation.php');
$repo=(string)file_get_contents($root.'/System/Escalation/GovernanceEscalationRepository.php');
if(!str_contains($model,"protected \$table='titan_governance_escalations'"))fail_eq('escalation model table mismatch');
foreach(["orderByDesc('risk_score')","orderByDesc('urgency')","orderBy('opened_at')"] as $needle)if(!str_contains($repo,$needle))fail_eq('repository missing ordering '.$needle);
if(str_contains($repo,'DB'.'::table'))fail_eq('repository bypasses Eloquent boundary');

echo "PASS: Governance escalation queue contract\n";
