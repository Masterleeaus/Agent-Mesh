# Release verification — Titan AI Runtime 1.5.3

This release is packaged for the Titan installer contract `titan-extension-v1`.

Verified release properties:

- ZIP root contains `extension.json`;
- slug: `titan-ai`;
- folder: `TitanAI`;
- provider: `App\Extensions\TitanAI\System\TitanAIServiceProvider`;
- provider file exists at the exact Linux-cased path declared by the manifest;
- version is full semantic version `1.5.3`;
- package paths use `/` separators;
- no traversal, `.env`, `.git`, `node_modules`, `__MACOSX`, or `.DS_Store` content;
- extension migrations remain inside `database/migrations/`;
- generic MagicAI `extension` publish tag is not used;
- `company_id` remains the Titan tenant boundary;
- all 330 supplied runtime PHP files remain byte-identical to 1.5.2 and pass `php -l`;
- compatibility verification PHP under `tests/` also passes `php -l`;
- production integrity hashes are stored in root `extension.json`;
- `extension.json` itself is excluded from the integrity map to avoid recursive self-hashing;
- package is unsigned because no Titan Ed25519 publishing key was supplied for this build.

The final ZIP is re-extracted and re-verified after packaging.
