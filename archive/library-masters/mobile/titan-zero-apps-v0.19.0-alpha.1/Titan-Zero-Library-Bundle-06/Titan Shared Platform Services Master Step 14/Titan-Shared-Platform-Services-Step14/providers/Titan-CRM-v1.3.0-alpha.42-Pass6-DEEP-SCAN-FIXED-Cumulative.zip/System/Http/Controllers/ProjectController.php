<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Contracts\ProjectRepositoryContract; use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class ProjectController {
 public function __construct(private ProjectRepositoryContract $projects, private \App\Extensions\Crm\System\Governance\CrmHumanMutationGateway $mutations){}
 public function index(Request $r){$records=$this->projects->search((int)$r->user()->id,$r->only(['q','status','limit']));return $r->expectsJson()?response()->json(['data'=>$records]):view('crm::projects.index',['projects'=>$records]);}
 public function store(Request $r){$d=$r->validate(['name'=>'required|string|max:255','status'=>'nullable|string|max:40','company_public_id'=>'nullable|string|size:26','deal_public_id'=>'nullable|string|size:26','description'=>'nullable|string|max:10000','starts_on'=>'nullable|date','due_on'=>'nullable|date','progress_percent'=>'nullable|integer|min:0|max:100','priority'=>'nullable|in:low,normal,high,urgent','meta'=>'nullable|array']);$record=$this->mutations->execute($r,'crm.project.create',$d);return $r->expectsJson()?response()->json($record,201):back()->with('status','Project created.');}
}
