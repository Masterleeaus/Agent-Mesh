# CRM 1.3.0-alpha.3 Provider Hotfix Report

## Failure reproduced

Titan Extension Manager 1.2.0 failed at the `provider` stage with:

`Target [App\Extensions\Crm\System\Contracts\SalesDocumentRepositoryContract] is not instantiable while building [CrmFinanceLockerServiceProvider, JobBillingService].`

## Root cause

The host Laravel application is already booted when Titan registers a custom extension. CRM alpha.2 registered `CrmFinanceLockerServiceProvider` before root repository bindings. Laravel therefore booted the finance provider immediately, which eagerly resolved `JobBillingService` before `SalesDocumentRepositoryContract` was bound.

## Repair

1. Moved focused subprovider registration to the end of `CrmServiceProvider::register()`, after root bindings and singleton registrations.
2. Changed Finance/Locker/Bookkeeping capability handlers to lazy-resolve domain services when a capability is invoked.
3. Added an installer provider-stage regression gate.
4. Kept all alpha.2 migrations and business-domain behavior unchanged.

## Failed-install recovery

The supplied failure report shows `stage: provider`, `migration_rollback_attempted: false`. Therefore no alpha.2 migration ran during that failed attempt. The installer had deployed files but did not restore the previous file backup. Installing alpha.3 should overwrite the deployed CRM files with the corrected provider ordering.
