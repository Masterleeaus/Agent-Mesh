# Phase 3 hardening summary

Phase 3 targets the defects found by the post-extensionisation deep scan: cross-company host queries, global AI caches, tenantless persistence, unsafe offline replay context, lower-layer run bypasses, stateful singleton lifetimes, stale CLI/install wiring and incomplete disable/health lifecycle behavior.

## Security invariant

Every tenant-owned operation must derive its business boundary from trusted `company_id` context. Client/device metadata may be checked for consistency but cannot establish or switch that context. If ownership cannot be proven, execution fails closed.

## Legacy-data policy

No migration invents tenant ownership. Old generic memory/audit/queue rows are quarantined in place. Existing interaction rows are backfilled only from explicit host company ownership.

## Release gate

Static/unit regression success is not a substitute for a connected multi-company MagicAI/WorkCore test. The final release gate requires installation into the actual host, two-company isolation tests, real provider discovery, migration execution, WorkCore capability execution, disable/enable behavior and repeated uninstall verification.
