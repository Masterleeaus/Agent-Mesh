<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Contracts\SalesDocumentRepositoryContract;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use DomainException;
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

final class SalesDocumentRevisionService
{
    public function __construct(private readonly ConnectionInterface $db, private readonly SalesDocumentRepositoryContract $sales) {}

    public function createRevision(int $actorUserId,string $type,string $publicId,array $overrides=[]): array
    {
        if(!in_array($type,['proposals','estimates'],true))throw new InvalidArgumentException('Only proposals and estimates support revisions.');
        $tenant=CrmCompanyScope::companyId($actorUserId);
        $table='crm_'.$type;
        $source=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->first();
        if(!$source)throw new InvalidArgumentException('Quote/estimate not found.');
        $source=(array)$source;
        if(in_array((string)$source['status'],['accepted','superseded'],true))throw new DomainException('Accepted or superseded quotes cannot be revised.');
        if(!empty($source['superseded_by_public_id']))throw new DomainException('This quote already has a superseding revision.');

        $lines=$this->db->table('crm_sales_document_lines')->where('company_id',$tenant)->where('document_type',$type)->where('document_public_id',$publicId)->orderBy('sequence')->get()->map(fn($r)=>[
            'description'=>$r->description,'quantity_milli'=>(int)$r->quantity_milli,'unit_price_minor'=>(int)$r->unit_price_minor,'tax_rate_bps'=>(int)$r->tax_rate_bps,'meta'=>$this->decode($r->meta),
        ])->all();
        $root=(string)($source['revision_root_public_id']?:$source['public_id']);
        $data=[
            'company_public_id'=>$source['company_public_id']??null,'contact_public_id'=>$source['contact_public_id']??null,
            'number'=>$overrides['number']??$source['number']??null,'title'=>$overrides['title']??$source['title']??null,
            'currency'=>$overrides['currency']??$source['currency']??'AUD','expires_at'=>$overrides['expires_at']??$source['expires_at']??null,
            'pricing_rules_version'=>$overrides['pricing_rules_version']??$source['pricing_rules_version']??null,
            'pricing_rule_snapshot'=>$overrides['pricing_rule_snapshot']??$this->decode($source['pricing_rule_snapshot']??null),
            'tax_rule_snapshot'=>$overrides['tax_rule_snapshot']??$this->decode($source['tax_rule_snapshot']??null),
            'terms_snapshot'=>$overrides['terms_snapshot']??$this->decode($source['terms_snapshot']??null),
            'service_definition_snapshot'=>$overrides['service_definition_snapshot']??$this->decode($source['service_definition_snapshot']??null),
            'discount_snapshot'=>$overrides['discount_snapshot']??$this->decode($source['discount_snapshot']??null),
            'currency_snapshot'=>$overrides['currency_snapshot']??$this->decode($source['currency_snapshot']??null),
            'lines'=>$overrides['lines']??$lines,'revision_root_public_id'=>$root,
            'revision_number'=>(int)($source['revision_number']??1)+1,'supersedes_public_id'=>$publicId,
            'meta'=>array_merge((array)$this->decode($source['meta']??null),(array)($overrides['meta']??[]),['revision_reason'=>$overrides['reason']??null]),
        ];
        return $this->sales->create($actorUserId,$type,$data+['status'=>'draft']);
    }

    public function revisions(int $actorUserId,string $type,string $publicId): array
    {
        $tenant=CrmCompanyScope::companyId($actorUserId);$table='crm_'.$type;
        $row=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$publicId)->first();
        if(!$row)throw new InvalidArgumentException('Quote/estimate not found.');
        $root=(string)($row->revision_root_public_id?:$row->public_id);
        return $this->db->table($table)->where('company_id',$tenant)->where(fn($q)=>$q->where('revision_root_public_id',$root)->orWhere('public_id',$root))->whereNull('deleted_at')->orderBy('revision_number')->get()->map(fn($r)=>(array)$r)->all();
    }

    private function decode(mixed $v): mixed { if(is_array($v)||$v===null)return $v; if(is_string($v)){ $d=json_decode($v,true); if(json_last_error()===JSON_ERROR_NONE)return $d; } return $v; }
}
