<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\InteractionEngine;

use App\Extensions\Crm\System\Tenancy\CrmCompanyContext;
use App\Extensions\InteractionEngine\System\Wizard\Renderer\HybridRenderer;
use App\Extensions\InteractionEngine\System\Wizard\Storage\WizardSessionStoreInterface;
use App\Extensions\InteractionEngine\System\Wizard\UniversalWizardEngine;
use App\Extensions\InteractionEngine\System\Wizard\WizardRegistry;
use App\Extensions\InteractionEngine\System\Wizard\Command\CommandMapper;
use App\Extensions\InteractionEngine\System\Command\CommandBus;
use Illuminate\Contracts\Foundation\Application;

/** Conversational orchestration only. CRM repositories are intentionally not available here. */
final class CrmConversationalInteractionService
{
    public function __construct(
        private Application $app,
        private CrmInteractionJourneyRegistry $journeys,
        private CrmInteractionAuthorityPolicy $authority,
        private CrmInteractionChainService $chains,
    ) {}

    /** @return array<string,mixed> */
    public function resolveIntent(string $message,?string $surface=null): array
    {
        $text=mb_strtolower(trim($message));$best=null;$score=0;
        foreach($this->journeys->definitions() as $definition){
            if($surface!==null&&$surface!==''&&$surface!=='all'&&$definition['surface']!==$surface)continue;
            $tokens=array_filter(preg_split('/[^a-z0-9]+/i',mb_strtolower($definition['name'].' '.$definition['key']))?:[]);
            $candidate=0;foreach(array_unique($tokens) as $token)if(strlen($token)>2&&str_contains($text,$token))$candidate++;
            if($candidate>$score){$score=$candidate;$best=$definition;}
        }
        return ['matched'=>$best!==null,'journey'=>$best,'confidence'=>$best===null?0:min(1,$score/2),'message'=>$message];
    }

    /** @return array<string,mixed> */
    public function start(string $journey,CrmCompanyContext $context,array $input=[]): array
    {
        $definition=$this->journeys->get($journey);$this->requireRuntime();$wizards=$this->app->make(WizardRegistry::class);
        if(!$wizards->has((string)$definition['wizard']))throw new \RuntimeException('The requested Interaction Engine wizard is not registered.');
        // autonomy_workflow_key is trusted server metadata. Browser/request input cannot select another trust namespace.
        unset($input['autonomy_workflow_key']);
        $session=$this->app->make(UniversalWizardEngine::class)->start((string)$definition['wizard'],$this->context($context,$definition,$input));
        $prefill=(array)($input['prefill']??[]);$allowed=[];foreach($session->definition->steps as $step)foreach((array)($step['fields']??[]) as $field){$id=(string)($field['id']??'');if($id!=='')$allowed[$id]=true;}
        unset($prefill['company_id'],$prefill['tenant_id'],$prefill['user_id'],$prefill['actor_id']);$session->data=array_replace($session->data,array_intersect_key($prefill,$allowed));
        $this->app->make(WizardSessionStoreInterface::class)->put($session);
        return ['status'=>'started','journey'=>$definition,'session_id'=>$session->id]+$this->app->make(HybridRenderer::class)->render($session);
    }

    /** @return array<string,mixed> */
    public function answer(string $sessionId,array $data,CrmCompanyContext $context): array
    {
        $this->requireRuntime();$store=$this->app->make(WizardSessionStoreInterface::class);$session=$store->get($sessionId);
        if($session===null)throw new \InvalidArgumentException('Interaction session not found or expired.');$this->assertContext($session->context,$context);
        $confidence=isset($data['_confidence'])?max(0.0,min(1.0,(float)$data['_confidence'])):null;unset($data['_confidence']);

        // Never let UniversalWizardEngine's final-step dispatch infer human authority from an AI-assisted session.
        // The step is first validated/prepared under a non-executable actor, then execute() performs the explicit earned-authority dispatch.
        $session->context['actor_type']='agent_pending';
        $result=$this->app->make(UniversalWizardEngine::class)->submitStep($session,$data);
        $result->session->context['titan_ai_assisted']=true;
        $result->session->context['titan_ai_proposal']=$result->session->data;
        if($confidence!==null)$result->session->context['titan_ai_confidence']=$confidence;
        $store->put($result->session);

        $capability=(string)$result->session->definition->capability;
        $workflow=$this->workflowForSession($result->session,$capability);
        $ready=$result->errors===[]&&$result->session->stepIndex>=$result->session->definition->stepCount();
        if($ready){
            if(!$this->authority->mayAiComplete($capability,$workflow)){
                return ['status'=>'approval_required','session_id'=>$sessionId,'capability'=>$capability,'workflow_key'=>$workflow,'message'=>'Titan Zero filled and validated the workflow. A human must review and approve execution.','errors'=>$result->errors,'guidance'=>$result->guidance,'command'=>$result->command,'authority'=>$this->authority->decision($capability,$workflow)]+$this->app->make(HybridRenderer::class)->render($result->session);
            }
            $result->session->context['actor_type']='agent';
            $store->put($result->session);
            return $this->execute($sessionId,$context);
        }
        return ['status'=>'in_progress','session_id'=>$sessionId,'errors'=>$result->errors,'guidance'=>$result->guidance,'command'=>$result->command]+$this->app->make(HybridRenderer::class)->render($result->session);
    }

    /**
     * Safe server-side path used by an authorised external Titan agent/worker.
     * It only advances wizard steps from already-known prefill. Missing/invalid context returns for review; nothing is guessed.
     * @return array<string,mixed>
     */
    public function executePrefilled(string $journey,CrmCompanyContext $context,array $prefill=[],?string $workflowKey=null,?float $confidence=null): array
    {
        $started=$this->start($journey,$context,['prefill'=>$prefill]);
        $sessionId=(string)$started['session_id'];$this->requireRuntime();$store=$this->app->make(WizardSessionStoreInterface::class);$session=$store->get($sessionId);
        if($session===null)throw new \RuntimeException('Interaction session could not be created.');
        if($workflowKey!==null&&trim($workflowKey)!=='')$session->context['autonomy_workflow_key']=trim($workflowKey);
        $session->context['titan_ai_assisted']=true;$session->context['titan_ai_proposal']=$session->data;
        if($confidence!==null)$session->context['titan_ai_confidence']=max(0.0,min(1.0,$confidence));
        $store->put($session);

        for($guard=0;$guard<20;$guard++){
            $session=$store->get($sessionId);
            if($session===null)throw new \RuntimeException('Interaction session expired during proactive execution.');
            if($session->stepIndex>=$session->definition->stepCount())return $this->execute($sessionId,$context);
            $step=(array)($session->currentStep()??[]);$input=[];
            foreach((array)($step['fields']??[]) as $field){$id=(string)($field['id']??'');if($id!==''&&array_key_exists($id,$session->data))$input[$id]=$session->data[$id];}
            if($confidence!==null)$input['_confidence']=$confidence;
            $result=$this->answer($sessionId,$input,$context);
            if(in_array((string)($result['status']??''),['executed','prepared','offline_deferred','approval_required'],true))return $result;
            if((array)($result['errors']??[])!==[]){
                return ['status'=>'needs_context','session_id'=>$sessionId,'journey'=>$journey,'workflow_key'=>$workflowKey,'missing_fields'=>array_values(array_keys((array)$result['errors'])),'errors'=>$result['errors'],'guidance'=>$result['guidance']??null];
            }
        }
        return ['status'=>'needs_context','session_id'=>$sessionId,'journey'=>$journey,'workflow_key'=>$workflowKey,'missing_fields'=>[],'message'=>'The externally initiated workflow exceeded its safe step limit and requires review.'];
    }

    /** @return array<string,mixed> */
    public function execute(string $sessionId,CrmCompanyContext $context): array
    {
        $this->requireRuntime();$store=$this->app->make(WizardSessionStoreInterface::class);$session=$store->get($sessionId);
        if($session===null)throw new \InvalidArgumentException('Interaction session not found or expired.');$this->assertContext($session->context,$context);
        $capability=(string)$session->definition->capability;$workflow=$this->workflowForSession($session,$capability);
        if(!$this->authority->mayAiComplete($capability,$workflow))return ['status'=>'approval_required','session_id'=>$sessionId,'capability'=>$capability,'workflow_key'=>$workflow,'authority'=>$this->authority->decision($capability,$workflow)];
        if(!$session->complete()&&$session->stepIndex<$session->definition->stepCount())return ['status'=>'in_progress','session_id'=>$sessionId,'capability'=>$capability,'message'=>'The interaction must be fully validated before autonomous execution.'];
        if(!class_exists(CommandMapper::class)||!class_exists(CommandBus::class)||!$this->app->bound(CommandMapper::class)||!$this->app->bound(CommandBus::class))throw new \RuntimeException('Interaction Engine command runtime is unavailable.');
        $session->context['actor_type']='agent';$session->context['autonomy_workflow_key']=$workflow;$store->put($session);
        $command=$this->app->make(CommandMapper::class)->map($session);$payload=$this->commandPayload($command,$session->context,$session->id);
        $result=$this->app->make(CommandBus::class)->dispatchResult((string)$command['capability'],$payload);
        return ['status'=>$result->status,'session_id'=>$sessionId,'capability'=>$capability,'workflow_key'=>$workflow,'result'=>$result->toArray(),'authority'=>$this->authority->decision($capability,$workflow)];
    }

    private function workflowForSession(object $session,string $capability):string
    {
        $explicit=trim((string)($session->context['autonomy_workflow_key']??''));
        return $explicit!==''?$explicit:$this->authority->workflowKey($capability);
    }

    /** @return array<string,mixed> */
    private function commandPayload(array $command,array $sessionContext,string $sessionId):array
    {
        $metadata=(array)($command['metadata']??[]);$payload=(array)($command['payload']??[]);$company=(string)($sessionContext['company_id']??'');
        $payload['_context']=array_replace((array)($payload['_context']??[]),[
            'company_id'=>$company,'tenant_id'=>$company,'user_id'=>$sessionContext['user_id']??null,'actor_id'=>$sessionContext['actor_id']??$sessionContext['user_id']??null,
            'actor_type'=>$sessionContext['actor_type']??'agent','roles'=>array_values((array)($sessionContext['roles']??[])),'delegated_scopes'=>array_values((array)($sessionContext['delegated_scopes']??[])),
            'source_surface'=>$sessionContext['source_surface']??'command','correlation_id'=>$metadata['correlation_id']??$sessionContext['correlation_id']??$sessionId,
            'causation_id'=>$metadata['causation_id']??$sessionContext['causation_id']??$sessionId,'idempotency_key'=>$metadata['idempotency_key']??'',
            'wizard_run_id'=>$sessionId,'session_id'=>$sessionId,'device_id'=>$sessionContext['device_id']??null,'privacy_class'=>$sessionContext['privacy_class']??'tenant_private',
            'autonomy_workflow_key'=>$sessionContext['autonomy_workflow_key']??null,
        ]);
        return $payload;
    }

    /** @return array<string,mixed> */
    public function planChain(string $chain,array $context=[]):array
    {return $this->chains->plan($chain,$context);}

    /** @return array<string,mixed> */
    public function continueChain(string $chain,int $completedStep,array $completedResult,array $chainContext,CrmCompanyContext $context,bool $startNext=true):array
    {return $this->chains->continue($chain,$completedStep,$completedResult,$chainContext,$context,$startNext);}

    private function requireRuntime(): void
    {
        foreach([WizardRegistry::class,UniversalWizardEngine::class,WizardSessionStoreInterface::class,HybridRenderer::class] as $class)if(!class_exists($class)||!$this->app->bound($class))throw new \RuntimeException('Titan Interaction Engine v10.3.1+ is required for this workflow.');
    }
    private function assertContext(array $sessionContext,CrmCompanyContext $context):void
    {if((string)($sessionContext['company_id']??'')!==(string)$context->companyId||(string)($sessionContext['user_id']??'')!==(string)($context->actorUserId??''))throw new \Illuminate\Auth\Access\AuthorizationException('Interaction session does not belong to this CRM actor/company.');}
    private function context(CrmCompanyContext $context,array $definition,array $input):array
    {unset($input['autonomy_workflow_key']);return array_replace($input,['company_id'=>(string)$context->companyId,'tenant_id'=>(string)$context->companyId,'user_id'=>(string)($context->actorUserId??''),'actor_id'=>(string)($context->actorUserId??''),'actor_type'=>$context->actorType==='user'?'human':$context->actorType,'roles'=>array_values(array_map('strval',$context->roles)),'source_surface'=>'command','interface'=>'chat','correlation_id'=>$context->correlationId?:bin2hex(random_bytes(16)),'device_id'=>(string)($context->deviceId??''),'privacy_class'=>'tenant_private','crm_surface'=>$definition['surface'],'crm_journey_key'=>$definition['key']]);}
}
