<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Contracts;

use App\Extensions\TitanAICore\System\DTO\CommandDispatchReceipt;
use App\Extensions\TitanAICore\System\DTO\CommandDispatchRequest;

interface CommandBusGatewayContract
{
    public function dispatch(CommandDispatchRequest $request): CommandDispatchReceipt;
}
