# CRM 1.3.0-alpha.6 — Core Navigation, Theme Integration & Runtime Schema Hotfix

## Runtime fixes
- Removed invalid `deleted_at` filtering from `crm_activities` reads in the dashboard overview, timeline service, and Chatbot activity projection. `crm_activities` is an immutable activity stream and does not define a `deleted_at` column.
- Corrected the contacts list tenant filter from actor `user_id` to the CRM business boundary `tenant_company_id`.

## Core business navigation
CRM is now presented as the Titan business core instead of one oversized CRM dropdown.

Top-level user navigation order:
1. Overview
2. Customers
3. Sales
4. Work
5. Money
6. Crew
7. Gear
8. Insights
9. Automate
10. Settings

The existing `ext_crm_dropdown` and `ext_sales_dropdown` keys are retained and relabelled to **Customers** and **Money** so current host/plan integrations do not lose those established keys.

Menu registration now runs in an additive migration through an adaptive `CrmMenuInstaller`, because Titan executes extension migrations during installation whereas the old `CrmMenuSeeder` was not guaranteed to run. The installer only writes menu columns that exist on the host and reuses existing child keys so upgrades move links rather than duplicate them.

## Theme integration
- Removed fixed success/danger/warning/info button palette classes from CRM Blade views.
- Primary actions now use the host theme's primary button treatment.
- Secondary/destructive actions use theme-controlled outline styling plus confirmation/state semantics instead of fixed colours.
- Removed the standalone customer portal's hard-coded dark button background; portal buttons now inherit their surrounding theme/text treatment.

## Regression gates
Added:
- `bin/verify-v130-alpha6-runtime-schema.php`
- `bin/verify-v130-alpha6-navigation.php`
- `bin/verify-v130-alpha6-theme-buttons.php`

These prevent recurrence of the missing `deleted_at` query, actor/tenant contact scoping bug, missing domain menu parents, invalid menu routes, duplicate legacy Dashboard link, and hard-coded CRM button palette classes.
