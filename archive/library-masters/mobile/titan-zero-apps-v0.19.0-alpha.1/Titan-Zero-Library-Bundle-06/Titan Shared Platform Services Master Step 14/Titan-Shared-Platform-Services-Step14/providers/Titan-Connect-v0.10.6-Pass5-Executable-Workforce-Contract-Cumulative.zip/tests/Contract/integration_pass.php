<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$passes = [];
$read = static fn (string $path): string => is_file($root.'/'.$path) ? (string) file_get_contents($root.'/'.$path) : '';
$check = static function (bool $condition, string $name) use (&$passes, &$failures): void {
    if ($condition) {
        $passes[] = $name;
    } else {
        $failures[] = $name;
    }
};

$httpContract = $read('System/Contracts/ProviderHttpClient.php');
$httpClient = $read('System/Http/LaravelProviderHttpClient.php');
$httpResponse = $read('System/DTO/ProviderHttpResponse.php');
$registry = $read('System/Providers/ProviderRegistry.php');
$whatsapp = $read('System/Providers/WhatsAppProvider.php');
$messenger = $read('System/Providers/MessengerProvider.php');
$instagram = $read('System/Providers/InstagramProvider.php');
$telegram = $read('System/Providers/TelegramProvider.php');
$sms = $read('System/Providers/SmsProvider.php');
$push = $read('System/Providers/PushProvider.php');
$vault = $read('System/Security/EncryptedCredentialVault.php');
$credentialModel = $read('System/Models/ProviderCredential.php');
$credentialController = $read('System/Http/Controllers/ProviderCredentialController.php');
$migration = $read('database/migrations/2026_08_09_000002_add_integration_runtime.php');
$provider = $read('System/TitanConnectServiceProvider.php');
$config = $read('config/titan-connect.php');
$routes = $read('routes/api.php');
$delivery = $read('System/Delivery/OutboundDeliveryService.php');
$mediaDescriptor = $read('System/DTO/ProviderMediaDescriptor.php');
$mediaIngest = $read('System/Attachments/InboundAttachmentIngestService.php');
$webhooks = $read('System/Webhooks/InboundWebhookService.php');
$bindings = $read('System/Integration/ConfiguredIntegrationBinder.php');
$eventWorkCore = $read('System/Integration/EventWorkCoreAuthorizationGateway.php');
$eventChatbot = $read('System/Integration/EventChatbotMessagingBridge.php');
$eventPush = $read('System/Integration/EventMobilePushGateway.php');
$handoff = $read('System/Services/ExternalHandoffService.php');
$handoffController = $read('System/Http/Controllers/ExternalHandoffController.php');

$check(str_contains($httpContract, 'interface ProviderHttpClient') && str_contains($httpContract, 'request('), 'HTTP provider transport contract exists');
$check(str_contains($httpClient, 'Http::') && str_contains($httpClient, 'withoutRedirecting'), 'Laravel HTTP transport disables implicit redirects');
$check(str_contains($httpResponse, 'isSuccessful') && str_contains($httpResponse, 'json'), 'Provider HTTP response DTO exists');
$check(str_contains($registry, 'ProviderHttpClient') && str_contains($registry, 'MobilePushGateway'), 'Provider registry injects network and push transports');
$check(str_contains($whatsapp, 'phone_number_id') && str_contains($whatsapp, "'/messages'") && str_contains($whatsapp, 'messaging_product'), 'WhatsApp uses direct Cloud API HTTP transport');
$check(str_contains($messenger, 'messaging_type') && str_contains($messenger, "'/messages'"), 'Messenger uses direct Send API HTTP transport');
$check(str_contains($instagram, "'/messages'") && str_contains($instagram, 'recipient'), 'Instagram uses direct Messaging API HTTP transport');
$check(str_contains($telegram, 'api.telegram.org') && str_contains($telegram, 'sendMessage') && str_contains($telegram, 'getMe'), 'Telegram direct send and health HTTP transport exist');
$check(str_contains($sms, 'api.twilio.com') && str_contains($sms, 'AccountSid') === false && str_contains($sms, 'account_sid'), 'SMS supports direct Twilio HTTP transport');
$check(str_contains($push, 'MobilePushGateway') && str_contains($push, '->send('), 'Push provider delegates to TitanMobileCore gateway');
$check(str_contains($migration, 'ext_titan_connect_provider_credentials') && str_contains($migration, 'encrypted_payload'), 'Encrypted provider credential table migration exists');
$check(str_contains($credentialModel, "protected \$hidden") && str_contains($credentialModel, 'encrypted_payload'), 'Credential model never serializes encrypted payload');
$check(str_contains($vault, 'Crypt::decryptString') && str_contains($vault, 'ConfigCredentialVault'), 'Encrypted credential vault supports encrypted DB credentials with config fallback');
$check(str_contains($credentialController, 'Crypt::encryptString') && !str_contains($credentialController, "response()->json(\$data['credentials'])"), 'Credential provisioning encrypts without echoing secrets');
$check(str_contains($credentialController, 'key_version') && str_contains($credentialController, '+ 1'), 'Credential rotation increments key-version metadata');
$check(str_contains($vault, "str_starts_with(\$reference, 'vault_')") && str_contains($vault, 'could not be found'), 'Missing encrypted vault references fail closed instead of silently falling back');
$check(str_contains($routes, 'credentials') && str_contains($routes, 'ProviderCredentialController'), 'Authenticated credential rotation/forget routes exist');
$check(str_contains($provider, 'EncryptedCredentialVault::class') && str_contains($provider, 'ProviderHttpClient::class'), 'Service provider binds encrypted vault and HTTP transport');
$check(str_contains($config, "'graph_version'") && str_contains($config, "'timeout_seconds'") && str_contains($config, "'twilio'"), 'Provider endpoints, versions, timeouts and SMS driver are configurable');
$check(str_contains($delivery, "'from' => \$connection->external_account_id"), 'Outbound provider payload includes connection sender identity');

$check(str_contains($mediaDescriptor, 'class ProviderMediaDescriptor') && str_contains($mediaDescriptor, 'downloadUrl'), 'Provider media descriptor isolates download metadata');
$check(str_contains($mediaIngest, 'Storage::disk') && str_contains($mediaIngest, 'sha256') && str_contains($mediaIngest, 'AttachmentValidator'), 'Inbound provider media is persisted through canonical attachment validation');
$check(str_contains($webhooks, 'InboundAttachmentIngestService') && str_contains($webhooks, 'ingestForExternalMessage'), 'Webhook pipeline ingests normalized provider media into attachment records');
$check(str_contains($whatsapp, 'resolveInboundMedia') && str_contains($whatsapp, "'/'.\$mediaId"), 'WhatsApp resolves provider media metadata before download');
$check(str_contains($telegram, 'resolveInboundMedia') && str_contains($telegram, 'getFile'), 'Telegram resolves file_id through getFile before download');
$check(str_contains($sms, 'resolveInboundMedia') && str_contains($sms, 'basic_auth'), 'Twilio MMS media downloads carry provider authentication');
$check(str_contains($bindings, 'configuredClass') && str_contains($bindings, 'is_a('), 'Host integration class bindings are validated before container registration');
$check(str_contains($config, "'integrations'") && str_contains($config, "'storage_disk'"), 'Host integration bindings and attachment storage are configurable');

$check(str_contains($eventWorkCore, "event('titan-connect.workcore.authorize'") && str_contains($eventWorkCore, 'AccessDeniedHttpException'), 'WorkCore event integration remains fail-closed without an explicit allow');
$check(str_contains($eventChatbot, "event('titan-connect.chatbot.inbound'") && str_contains($eventChatbot, "event('titan-connect.chatbot.handoff'"), 'Chatbot event bridge exposes inbound and handoff integration points');
$check(str_contains($eventPush, "event('titan-connect.mobile.push'") && str_contains($eventPush, 'not-configured'), 'Mobile push event bridge safely reports missing host listeners');
$check(str_contains($handoff, 'onHumanHandoffChanged') && str_contains($handoff, 'handoff_state') && str_contains($handoff, 'MessagingAuditService'), 'External handoff state is persisted, audited and bridged to Chatbot');
$chatbotContract = $read('System/Contracts/ChatbotMessagingBridge.php');
$chatbotEventBridge = $read('System/Integration/EventChatbotMessagingBridge.php');
$check(substr_count($chatbotContract, 'int $companyId') >= 2 && str_contains($chatbotEventBridge, "event('titan-connect.chatbot.inbound', [\$companyId") && str_contains($chatbotEventBridge, "event('titan-connect.chatbot.handoff', [\$companyId"), 'Chatbot integration receives explicit company boundary');
$check(str_contains($handoffController, 'canSend') && str_contains($handoffController, 'WorkCoreAuthorizationGateway'), 'Handoff controller rechecks channel and linked WorkCore authorization');
$check(str_contains($routes, 'ExternalHandoffController') && str_contains($routes, "external-threads/{thread}/handoff"), 'Authenticated external handoff route exists');

$check(str_contains($read('System/Contracts/MessagingProvider.php'), 'splitWebhookPayload') && str_contains($read('System/Contracts/MessagingProvider.php'), 'verifyWebhookChallenge'), 'Provider contract supports webhook batching and verification challenge');
$check(str_contains($whatsapp, 'foreach ($entries as $entry)') && str_contains($whatsapp, "'statuses'"), 'WhatsApp webhook splitter preserves every message and status event');
$check(str_contains($messenger, 'splitWebhookPayload') && str_contains($messenger, "'messaging'"), 'Messenger/Instagram webhook splitter preserves every messaging event');
$check(str_contains($webhooks, 'foreach ($provider->splitWebhookPayload') && str_contains($webhooks, 'receiptEventId'), 'Inbound webhook service processes provider batches and derives receipt event IDs');
$check(str_contains($read('System/Http/Controllers/WebhookController.php'), 'verify(') && str_contains($routes, "Route::get('webhooks/{provider}/{connection}'"), 'Meta-compatible GET webhook verification route exists');

$attachmentUpload = $read('System/Attachments/AttachmentUploadService.php');
$attachmentResolver = $read('System/Attachments/OutboundAttachmentResolver.php');
$attachmentController = $read('System/Http/Controllers/AttachmentController.php');
$attachmentModel = $read('System/Models/MessageAttachment.php');
$check(str_contains($attachmentUpload, 'UploadedFile') && str_contains($attachmentUpload, 'hash_file') && str_contains($attachmentUpload, 'registerStaged'), 'Authenticated attachment upload stages validated files outside message JSON');
$check(str_contains($attachmentResolver, 'temporarySignedRoute') && str_contains($attachmentResolver, "scan_status !== 'clean'"), 'Outbound attachment resolver exposes only clean files through temporary signed URLs');
$check(str_contains($attachmentController, 'function store(') && str_contains($attachmentController, 'function providerDownload('), 'Attachment controller exposes upload and signed provider-download flows');
$check(str_contains($attachmentModel, "return 'uuid'") && str_contains($routes, "attachments/{attachment}/provider"), 'Attachment routes use UUID binding and signed provider download route');
$check(str_contains($routes, "companies/{companyId}/attachments/{attachment}/provider") && str_contains($attachmentResolver, "'companyId' => \$companyId") && str_contains($attachmentController, "(int) \$attachment->company_id !== \$companyId"), 'Signed provider attachment URLs carry and enforce company boundary');
$check(str_contains($delivery, 'OutboundAttachmentResolver') && str_contains($delivery, 'resolveForProvider'), 'Outbound delivery resolves staged canonical attachments before provider send');

$webhookJob = $read('System/Jobs/ProcessInboundWebhookJob.php');
$retryCommand = $read('System/Console/RetryDueDeliveriesCommand.php');
$check(str_contains($webhookJob, 'ShouldQueue') && str_contains($webhookJob, 'InboundWebhookService'), 'Inbound webhook processing can run after acknowledgement through a queue job');
$check(str_contains($read('System/Http/Controllers/WebhookController.php'), 'afterResponse()') && str_contains($config, 'async_after_response'), 'Webhook controller verifies synchronously and can acknowledge before processing');
$check(str_contains($retryCommand, 'next_attempt_at') && str_contains($retryCommand, 'OutboundDeliveryService'), 'Due outbound retries have an executable scheduler command');
$check(str_contains($provider, 'RetryDueDeliveriesCommand::class') && str_contains($provider, 'everyMinute()'), 'Service provider registers and schedules due delivery retries');
$check(str_contains($messenger, "'mids'") && str_contains($messenger, "'sender_ref'"), 'Messenger delivery/read receipts retain per-message/contact correlation data');
$check(str_contains($delivery, 'applyWatermarkReceipt') && str_contains($delivery, "external_contact_ref"), 'Messenger-style watermark read receipts can advance matching outbound deliveries');
$check(str_contains($delivery, 'lockForUpdate') && str_contains($delivery, 'claimForAttempt'), 'Outbound provider sends use a database-backed single-attempt claim');
$check(str_contains($delivery, 'attempt_lease_seconds') && str_contains($retryCommand, "'sending'"), 'Stale sending attempts have a recoverable lease and scheduler path');
$check(str_contains($delivery, 'normalizeProviderSendStatus') && str_contains($delivery, "Provider reported outbound delivery failure"), 'Provider queued/sending acknowledgements cannot trigger duplicate resend loops and provider failures remain retryable');
$check(str_contains($push, 'not-configured') && str_contains($push, 'RuntimeException'), 'Missing MobileCore push integration fails delivery instead of being recorded as sent');
$check(!str_contains($httpClient, "ConnectionException \$e") || !str_contains($httpClient, '$e->getMessage()'), 'Provider HTTP connection failures do not persist credential-bearing URLs in error text');
$check(str_contains($read('System/Services/ChannelHealthService.php'), "'_connection_external_account_id'") && str_contains($read('System/Providers/AbstractMessagingProvider.php'), 'accountIdentity'), 'Connection external account identity is available as a safe fallback for send and health checks');
$check(str_contains($delivery, 'redactProviderValue') && str_contains($delivery, 'api_key_secret'), 'Provider responses are recursively redacted before persistence');
$connectionController = $read('System/Http/Controllers/ChannelConnectionController.php');
$check(str_contains($config, "'allow_config_fallback' => (bool) (get(getenv('TITAN_CONNECT_ALLOW_CONFIG_CREDENTIALS') !== false ? getenv('TITAN_CONNECT_ALLOW_CONFIG_CREDENTIALS') : null) !== false ? get(getenv('TITAN_CONNECT_ALLOW_CONFIG_CREDENTIALS') !== false ? getenv('TITAN_CONNECT_ALLOW_CONFIG_CREDENTIALS') : null) : false)") && str_contains($vault, 'allow_config_fallback'), 'Encrypted provider credentials fail closed unless config fallback is explicitly enabled');
$check(!str_contains($connectionController, "'credential_reference' => ['nullable'") && !str_contains($connectionController, "'credential_reference' => ['sometimes'") && str_contains($connectionController, "'status' => 'paused'"), 'Company channel APIs cannot select server credential references and new connections start paused');
$check(str_contains($credentialController, "\$connectionChanges['status'] = 'active'") && str_contains($credentialController, "'credential_reference' => \$reference"), 'Successful encrypted credential provisioning activates the channel explicitly');
$sensitiveGuard = $read('System/Security/SensitivePayloadGuard.php');
$check(str_contains($sensitiveGuard, 'ValidationException') && str_contains($sensitiveGuard, "'access_token'") && str_contains($sensitiveGuard, "'credential'"), 'Sensitive metadata/settings keys are rejected before persistence');
$check(str_contains($connectionController, 'SensitivePayloadGuard') && str_contains($delivery, 'SensitivePayloadGuard'), 'Channel settings and outbound message metadata both enforce the sensitive-payload guard');

foreach ($passes as $pass) {
    echo "PASS {$pass}\n";
}
if ($failures !== []) {
    foreach ($failures as $failure) {
        fwrite(STDERR, "FAIL {$failure}\n");
    }
    fwrite(STDERR, sprintf("\n%d failed; %d passed.\n", count($failures), count($passes)));
    exit(1);
}

echo sprintf("\nOK Titan Connect integration-pass contract suite: %d passed.\n", count($passes));
