<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Safe legacy ownership backfill.
 *
 * Only an explicit users.company_id is trusted. Runs whose owner cannot be
 * mapped remain NULL and therefore remain inaccessible to tenant-scoped runtime
 * APIs rather than being guessed into a company. Answers/events inherit only
 * from a run that has an established tenant_id.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('interaction_runs') || !Schema::hasColumn('interaction_runs', 'tenant_id')) {
            return;
        }

        if (Schema::hasTable('users') && Schema::hasColumn('users', 'company_id')) {
            DB::table('interaction_runs')
                ->whereNull('tenant_id')
                ->orderBy('id')
                ->chunkById(200, function ($runs): void {
                    $userIds = collect($runs)->pluck('user_id')->filter()->unique()->values()->all();
                    if ($userIds === []) {
                        return;
                    }

                    $companies = DB::table('users')
                        ->whereIn('id', $userIds)
                        ->whereNotNull('company_id')
                        ->pluck('company_id', 'id');

                    foreach ($runs as $run) {
                        $companyId = trim((string) ($companies[$run->user_id] ?? ''));
                        if ($companyId === '') {
                            continue;
                        }
                        DB::table('interaction_runs')
                            ->where('id', $run->id)
                            ->whereNull('tenant_id')
                            ->update(['tenant_id' => $companyId]);
                    }
                });
        }

        if (Schema::hasTable('interaction_answers') && Schema::hasColumn('interaction_answers', 'tenant_id')) {
            $this->inheritRunTenant('interaction_answers');
        }
        if (Schema::hasTable('interaction_events') && Schema::hasColumn('interaction_events', 'tenant_id')) {
            $this->inheritRunTenant('interaction_events');
        }
    }

    public function down(): void
    {
        // Ownership metadata is intentionally never removed by rollback.
    }

    private function inheritRunTenant(string $table): void
    {
        DB::table('interaction_runs')
            ->whereNotNull('tenant_id')
            ->orderBy('id')
            ->chunkById(200, function ($runs) use ($table): void {
                foreach ($runs as $run) {
                    DB::table($table)
                        ->where('run_id', $run->id)
                        ->whereNull('tenant_id')
                        ->update(['tenant_id' => $run->tenant_id]);
                }
            });
    }
};
