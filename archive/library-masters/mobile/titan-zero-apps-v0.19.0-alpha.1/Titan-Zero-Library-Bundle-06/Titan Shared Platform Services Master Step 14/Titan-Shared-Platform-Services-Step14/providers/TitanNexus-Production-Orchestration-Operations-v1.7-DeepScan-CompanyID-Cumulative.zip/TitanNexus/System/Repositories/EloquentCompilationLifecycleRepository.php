<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Repositories;

use App\Extensions\TitanNexus\System\Contracts\CompilationLifecycleRepositoryContract;
use App\Extensions\TitanNexus\System\Domain\CompilationLifecycleEvent;
use App\Extensions\TitanNexus\System\Models\NexusCompilationLifecycleRecord;
use Illuminate\Database\QueryException;
use InvalidArgumentException;
use LogicException;
use Throwable;

final class EloquentCompilationLifecycleRepository implements CompilationLifecycleRepositoryContract
{
    public function record(CompilationLifecycleEvent $event): CompilationLifecycleEvent
    {
        $data = $event->toPersistenceArray();
        try {
            $record = NexusCompilationLifecycleRecord::query()->create($data);
            return CompilationLifecycleEvent::fromPersistence($record->toArray());
        } catch (QueryException $exception) {
            $existing = NexusCompilationLifecycleRecord::query()->where('event_id', $event->eventId())->first();
            if ($existing === null) {
                throw new LogicException('Unable to persist Nexus lifecycle event.', 0, $exception);
            }
            $restored = CompilationLifecycleEvent::fromPersistence($existing->toArray());
            if (!hash_equals($restored->payloadHash(), $event->payloadHash())) {
                throw new LogicException('Lifecycle event identity collision detected.', 0, $exception);
            }
            return $restored;
        }
    }

    public function historyForTenant(int $tenantCompanyId, string $compilationUuid, int $limit = 100): array
    {
        if ($tenantCompanyId <= 0) { throw new InvalidArgumentException('tenant_company_id must be a positive integer.'); }
        $resolvedLimit = max(1, min($limit, 200));
        $events = [];
        foreach (NexusCompilationLifecycleRecord::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->where('compilation_uuid', $compilationUuid)
            ->orderBy('id')
            ->limit($resolvedLimit)
            ->cursor() as $record) {
            try { $events[] = CompilationLifecycleEvent::fromPersistence($record->toArray()); }
            catch (Throwable) { /* retain corrupt evidence row, quarantine from runtime read model */ }
        }
        return $events;
    }
}
