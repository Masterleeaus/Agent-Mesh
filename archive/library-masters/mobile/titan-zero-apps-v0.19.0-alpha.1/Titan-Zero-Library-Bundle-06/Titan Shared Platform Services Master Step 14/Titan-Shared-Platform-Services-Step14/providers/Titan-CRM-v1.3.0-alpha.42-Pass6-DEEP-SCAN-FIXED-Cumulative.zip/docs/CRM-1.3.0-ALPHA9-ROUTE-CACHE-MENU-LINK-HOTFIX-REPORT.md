# CRM 1.3.0-alpha.9 Route Cache / Menu Link Hotfix

## Failure

On the live Titan Zero host, CRM menu entries opened `_blank` and used a literal Laravel route name as a relative href, producing URLs such as:

`https://titanzero.io/dashboard/admin/dashboard.user.crm.companies.index`

## Why it happened

MagicAI's navbar expects the `route` field to contain a Laravel named route. At render time it calls `Route::has($href)` and converts a recognised name with `route(...)`. If the name is not registered, MagicAI leaves it unchanged and treats it as an external link.

The Titan extension installer can add/upgrade CRM while the host is using a route cache generated before that CRM route set existed. Laravel's standard provider `loadRoutesFrom()` path skips loading route files when routes are cached, so the CRM menu definitions can exist while the live router does not yet know their route names.

## Implementation

`System/CrmServiceProvider.php` now:

1. preserves standard `loadRoutesFrom()` calls;
2. checks sentinel named routes after normal registration;
3. directly loads the corresponding extension route file only if a sentinel is missing.

Sentinels cover:

- `dashboard.user.crm.companies.index`
- `dashboard.user.sales.invoices.index`
- `api.crm.dashboard`
- `dashboard.admin.crm.settings`
- `crm.portal.show`

This repairs the live in-memory route collection before MagicAI's navbar evaluates CRM links.

## Architectural decision

CRM menu definitions continue to store semantic named routes. Hard-coded `/dashboard/...` paths were deliberately rejected because they would weaken MagicAI's route, plan and active-state contracts and would make route-prefix changes more brittle.

## Regression protection

`bin/verify-v130-alpha9-route-cache-menu-links.php` verifies:

- Route facade usage;
- cache-safe route fallback exists;
- all five route families have sentinels;
- fallback uses `Route::has()` and loads missing route files;
- CRM menu definitions remain named-route based rather than hard-coded URL paths.
