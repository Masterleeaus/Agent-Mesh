<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\CanonicalJson;
use InvalidArgumentException;

final class ConfigurationDiff
{
    /** @var list<SemanticDiffEntry> */
    private readonly array $entries;

    /** @param list<SemanticDiffEntry> $entries */
    public function __construct(
        private readonly string $currentOutputHash,
        private readonly string $proposedOutputHash,
        array $entries,
    ) {
        self::assertHash($this->currentOutputHash, 'current_output_hash');
        self::assertHash($this->proposedOutputHash, 'proposed_output_hash');
        foreach ($entries as $entry) {
            if (!$entry instanceof SemanticDiffEntry) {
                throw new InvalidArgumentException('entries must contain SemanticDiffEntry values.');
            }
        }
        usort($entries, static fn (SemanticDiffEntry $a, SemanticDiffEntry $b): int => [$a->path(), $a->kind()->value] <=> [$b->path(), $b->kind()->value]);
        $this->entries = array_values($entries);
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $rawEntries = $data['entries'] ?? null;
        if (!is_array($rawEntries) || !array_is_list($rawEntries)) {
            throw new InvalidArgumentException('diff entries must be a list.');
        }
        $entries = [];
        foreach ($rawEntries as $raw) {
            if (!is_array($raw)) {
                throw new InvalidArgumentException('diff entries must be objects.');
            }
            $entries[] = SemanticDiffEntry::fromArray($raw);
        }
        $instance = new self(
            self::requiredString($data['current_output_hash'] ?? null, 'current_output_hash'),
            self::requiredString($data['proposed_output_hash'] ?? null, 'proposed_output_hash'),
            $entries,
        );
        $fingerprint = $data['fingerprint'] ?? null;
        if ($fingerprint !== null && (!is_string($fingerprint) || !hash_equals(strtolower($fingerprint), $instance->fingerprint()))) {
            throw new InvalidArgumentException('diff fingerprint does not match canonical contents.');
        }
        return $instance;
    }

    /** @return list<SemanticDiffEntry> */
    public function entries(): array { return $this->entries; }
    public function currentOutputHash(): string { return $this->currentOutputHash; }
    public function proposedOutputHash(): string { return $this->proposedOutputHash; }

    public function hasChanges(): bool
    {
        foreach ($this->entries as $entry) {
            if ($entry->kind() !== SemanticChangeKind::Unchanged) {
                return true;
            }
        }
        return false;
    }

    public function requiresApproval(): bool
    {
        foreach ($this->entries as $entry) {
            if ($entry->kind() !== SemanticChangeKind::Unchanged && $entry->disposition() === SemanticChangeDisposition::RequiresApproval) {
                return true;
            }
        }
        return false;
    }

    public function hasBlocked(): bool
    {
        foreach ($this->entries as $entry) {
            if ($entry->kind() !== SemanticChangeKind::Unchanged && $entry->disposition() === SemanticChangeDisposition::Blocked) {
                return true;
            }
        }
        return false;
    }

    /** @return array<string, int> */
    public function summary(): array
    {
        $summary = [
            'unchanged' => 0,
            'add' => 0,
            'modify' => 0,
            'deprecate' => 0,
            'requires_approval' => 0,
            'blocked' => 0,
        ];
        foreach ($this->entries as $entry) {
            $summary[$entry->kind()->value]++;
            if ($entry->kind() !== SemanticChangeKind::Unchanged && $entry->disposition() === SemanticChangeDisposition::RequiresApproval) {
                $summary['requires_approval']++;
            }
            if ($entry->kind() !== SemanticChangeKind::Unchanged && $entry->disposition() === SemanticChangeDisposition::Blocked) {
                $summary['blocked']++;
            }
        }
        return $summary;
    }

    public function fingerprint(): string
    {
        return hash('sha256', CanonicalJson::encode($this->withoutFingerprint()));
    }

    /** @return array<string,mixed> */
    public function toContractArray(): array
    {
        return [
            'fingerprint' => $this->fingerprint(),
            'entries' => array_map(static fn (SemanticDiffEntry $entry): array => $entry->toContractArray(), $this->entries),
        ];
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return $this->withoutFingerprint() + ['fingerprint' => $this->fingerprint()];
    }

    /** @return array<string, mixed> */
    private function withoutFingerprint(): array
    {
        return [
            'current_output_hash' => strtolower($this->currentOutputHash),
            'proposed_output_hash' => strtolower($this->proposedOutputHash),
            'summary' => $this->summary(),
            'entries' => array_map(static fn (SemanticDiffEntry $entry): array => $entry->toArray(), $this->entries),
        ];
    }

    private static function assertHash(string $value, string $field): void
    {
        if (preg_match('/^[0-9a-f]{64}$/i', $value) !== 1) {
            throw new InvalidArgumentException("{$field} must be a SHA-256 hex digest.");
        }
    }

    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') {
            throw new InvalidArgumentException("{$field} is required.");
        }
        return trim($value);
    }
}
