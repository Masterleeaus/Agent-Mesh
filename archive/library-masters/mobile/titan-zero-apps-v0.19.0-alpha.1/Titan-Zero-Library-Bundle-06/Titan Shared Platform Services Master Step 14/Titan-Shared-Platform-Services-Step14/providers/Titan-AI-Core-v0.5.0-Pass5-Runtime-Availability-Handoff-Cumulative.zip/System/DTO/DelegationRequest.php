<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class DelegationRequest { public function __construct(public string $planId, public string $stepId, public WorkforceAssignment $assignment, public array $acceptanceCriteria = []) {} }
