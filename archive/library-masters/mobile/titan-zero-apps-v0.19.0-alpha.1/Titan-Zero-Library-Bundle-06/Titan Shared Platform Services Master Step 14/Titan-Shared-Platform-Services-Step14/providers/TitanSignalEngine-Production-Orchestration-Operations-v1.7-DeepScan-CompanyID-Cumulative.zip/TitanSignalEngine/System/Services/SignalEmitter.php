<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\EventTypeRegistryContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliverySchedulerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEventStoreContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalPulseProjectorContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalLifecycleProjectorContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalSourceRateLimiterContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalReceipt;
use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

final class SignalEmitter implements SignalEmitterContract
{
    public function __construct(
        private readonly SignalEventStoreContract $store,
        private readonly EventTypeRegistryContract $registry,
        private readonly SignalContextValidator $contextValidator,
        private readonly SignalPayloadGuard $payloadGuard,
        private readonly ?SignalDeliverySchedulerContract $deliveryScheduler = null,
        private readonly ?SignalPulseProjectorContract $pulseProjector = null,
        private readonly ?SignalLifecycleProjectorContract $lifecycleProjector = null,
        private readonly ?SignalSourceRateLimiterContract $sourceRateLimiter = null,
        private readonly ?AutomaticTraceEvaluationService $traceEvaluator = null,
    ) {
    }

    public function emit(SignalEnvelope|array $signal, SignalContext $context): SignalReceipt
    {
        $input = is_array($signal) ? $signal : $signal->toArray();
        if ($signal instanceof SignalEnvelope && $signal->actor === null) {
            unset($input['actor'], $input['actor_type'], $input['actor_id'], $input['actor_identity_provider'], $input['actor_session_id']);
        }
        if ($signal instanceof SignalEnvelope && $signal->emitterId === null) {
            unset($input['emitter_id']);
        }
        unset($input['checksum'], $input['recorded_at']);
        $envelope = SignalEnvelope::fromArray($this->contextValidator->applyToInput($input, $context));

        if (! $envelope->verifyChecksum()) {
            throw new InvalidArgumentException('Signal checksum verification failed before ingestion.');
        }

        $this->payloadGuard->assertAllowed($envelope->payload, $envelope->metadata);
        $this->registry->validate($envelope);
        $this->sourceRateLimiter?->assertAllowed($envelope);

        $persistedEvent = null;
        $receipt = DB::transaction(function () use ($envelope, &$persistedEvent): SignalReceipt {
            $result = $this->store->append($envelope);
            $event = $result['event'];
            $persistedEvent = $event;
            $this->lifecycleProjector?->project($event);
            $this->deliveryScheduler?->projectForEvent($event);

            $recordedAt = $event->recorded_at instanceof \DateTimeInterface
                ? new DateTimeImmutable($event->recorded_at->format(DATE_ATOM))
                : new DateTimeImmutable((string) ($event->recorded_at ?? 'now'), new DateTimeZone('UTC'));

            return new SignalReceipt(
                (string) $event->event_id,
                $recordedAt,
                $result['duplicate'],
                $result['original_event_id'],
            );
        });

        if ($persistedEvent !== null && $this->pulseProjector !== null) {
            try {
                $this->pulseProjector->project($persistedEvent);
            } catch (Throwable $exception) {
                Log::error('signal.pulse_projection_failed', [
                    'event_id' => $persistedEvent->event_id,
                    'error_class' => $exception::class,
                ]);
            }
        }

        if ($persistedEvent !== null && ! $receipt->duplicate && $this->traceEvaluator !== null) {
            try {
                $this->traceEvaluator->observe($persistedEvent);
            } catch (Throwable $exception) {
                Log::error('signal.trace_auto_evaluation_observe_failed', [
                    'event_id' => $persistedEvent->event_id,
                    'trace_id' => $persistedEvent->trace_id,
                    'error_class' => $exception::class,
                ]);
            }
        }

        return $receipt;
    }

}
