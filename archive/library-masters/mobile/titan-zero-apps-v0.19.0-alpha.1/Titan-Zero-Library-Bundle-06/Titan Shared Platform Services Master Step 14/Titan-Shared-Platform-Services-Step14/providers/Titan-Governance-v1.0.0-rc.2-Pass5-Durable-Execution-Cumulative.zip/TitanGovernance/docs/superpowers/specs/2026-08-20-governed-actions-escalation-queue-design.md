# Titan Governance Pass 4 — Governed Actions & Escalation Queue Design

## Goal

Turn Titan Governance from a read-only control plane into the owner of human governance decisions and escalation workflow while preserving Titan Command Bus as the only cross-domain mutation path.

## Boundaries

- Governance owns policy decisions, authority constraints, escalation records, and its own action/idempotency metadata.
- Governance does not mutate CRM, Autonomy, Risk, Assurance, Workforce, or any foreign domain state.
- APPROVE, REJECT, HOLD, EXCEPTION, and ESCALATE produce an immutable Governance policy-decision reference, then dispatch a command through a public Command Bus gateway contract.
- A missing/unbound Command Bus gateway fails closed. Governance never guesses Command Bus internals or falls back to direct execution.
- Command Bus receipt truth is accepted only when it includes a durable receipt reference. `APPLIED` additionally requires authoritative domain receipt/reference and `write_verified=true`.
- Duplicate `tenant_company_id + operation_id` with the same semantic payload returns the recorded terminal result; a recorded transient Command Bus transport/unavailable failure may redispatch the same decision. A conflicting semantic payload is rejected.
- Browser/API payloads never choose authoritative tenant or actor identity; both are reconstructed server-side.
- Human reasons remain structured reason codes/evidence references. No hidden chain-of-thought storage.

## Components

1. `GovernanceCommandGatewayContract` — stable Governance-side boundary for dispatching canonical command envelopes.
2. `UnavailableGovernanceCommandGateway` — fail-closed default.
3. `GovernanceActionRequest` — validated immutable action request with causal lineage and deterministic payload hash.
4. `GovernanceActionService` — idempotency claim, immutable decision creation, Command Bus dispatch, receipt validation, and decision finalization.
5. `GovernancePolicyDecision` — Eloquent model for action/decision ledger.
6. `GovernanceEscalation` + `GovernanceEscalationRepository` — tenant-scoped queue ordered by risk, urgency, then age.
7. `GovernanceEscalationTarget` — local command target that applies Command Bus-authorized escalation state transitions only when the envelope carries the original Governance decision reference.
8. `GovernanceActionController` — authenticated user/admin endpoints; server maps tenant and actor.

## State Model

Escalation states: `OPEN`, `HELD`, `ESCALATED`, `APPROVED`, `REJECTED`, `EXCEPTION_GRANTED`, `RESOLVED`.

Allowed actions:

- `APPROVE`: OPEN/HELD/ESCALATED -> APPROVED
- `REJECT`: OPEN/HELD/ESCALATED -> REJECTED
- `HOLD`: OPEN/ESCALATED -> HELD
- `EXCEPTION`: OPEN/HELD/ESCALATED -> EXCEPTION_GRANTED
- `ESCALATE`: OPEN/HELD -> ESCALATED

Terminal states reject further action.

## Command Envelope

The Governance-side gateway receives a structured array containing:

- schema/version
- operation_id
- capability
- command_name
- tenant_company_id
- actor identity mapped by server
- escalation/subject identifiers
- governance decision reference
- reason/evidence references
- trace/correlation/causation/root-causation IDs
- expected escalation version
- canonical payload hash

No foreign authoritative fields are accepted from the client.

## Failure Semantics

- Command Bus unavailable/invalid receipt: action remains recorded as blocked/failed and escalation state does not change. Transient transport/unavailable failures are retryable under the same operation ID.
- Duplicate same semantic payload: terminal outcomes replay without redispatch; transient Command Bus unavailable/transport outcomes may redispatch the same operation and immutable Governance decision.
- Duplicate conflicting payload: `IDEMPOTENCY_CONFLICT`.
- Stale escalation version: target rejects mutation.
- Missing/mismatched decision reference: target rejects mutation.
- Applied receipt without write verification/domain receipt reference: treat as invalid and do not report success.

## Testing

TDD contract tests must prove action validation, idempotency, fail-closed gateway behavior, receipt truthfulness, queue ordering, target state transitions, authorization wiring, routes, manifest capabilities, migration reversibility, and no direct foreign-domain writes.
