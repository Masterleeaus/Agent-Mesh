# Titan Installer 1.7.8

The install root is flat and must be named `TitanPayroll`. Root `extension.json` contains exactly `schema`, `slug`, `folder`, `provider`, `version`, and `integrity`. Provider casing is `App\Extensions\TitanPayroll\System\TitanPayrollServiceProvider` -> `System/TitanPayrollServiceProvider.php`.

Release packaging regenerates `PACKAGE-FILES.sha256`, `SBOM.cdx.json`, `BUILD-PROVENANCE.json`, and `extension.json.integrity.files`. `PackageIntegrityVerifier` rejects undeclared/missing/hash-mismatched files, unsafe paths, symlinks, case collisions and common secret/junk artifacts. `bin/verify-release.php` adds JSON/FQCN/route/legacy/tenant-authority checks.

Blueprint gates required before packaging: canonical manifest v2.2 validation, package scan, architecture scan, MySQL strict migration scan and production source gate. The hostless `--allow-unverified-host` override is permitted only to create an RC; it does not represent exact-host certification.
