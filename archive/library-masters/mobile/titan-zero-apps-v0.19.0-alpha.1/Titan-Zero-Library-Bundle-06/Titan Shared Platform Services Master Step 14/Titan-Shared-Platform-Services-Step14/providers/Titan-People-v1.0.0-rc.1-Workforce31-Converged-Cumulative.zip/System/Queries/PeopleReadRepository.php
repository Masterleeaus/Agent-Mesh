<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Queries;

interface PeopleReadRepository
{
    public function overview(int $tenantCompanyId): array;
    public function paginateWorkers(int $tenantCompanyId, int $perPage): mixed;
    public function workerByPublicId(int $tenantCompanyId, string $publicId): array;
    public function organisation(int $tenantCompanyId): array;
    public function paginateLeave(int $tenantCompanyId, int $perPage): mixed;
    public function paginateHolidays(int $tenantCompanyId, int $perPage): mixed;
    public function paginateLifecycle(int $tenantCompanyId, int $perPage): mixed;
    public function profile(int $tenantCompanyId, int $workerId): array;
}
