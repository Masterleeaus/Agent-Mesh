<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanSignalEngine\System\Data\RetentionClass;
use App\Extensions\TitanSignalEngine\System\Data\RetentionPolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalRedactionOverlay;
use App\Extensions\TitanSignalEngine\System\Services\SourceRateLimitPolicy;
use PHPUnit\Framework\TestCase;

final class LifecycleHardeningTest extends TestCase
{
    public function test_retention_classes_have_safe_defaults(): void
    {
        self::assertNull(RetentionPolicy::for(RetentionClass::CriticalAudit)->retentionDays);
        self::assertFalse(RetentionPolicy::for(RetentionClass::CriticalAudit)->prunable);
        self::assertSame(2555, RetentionPolicy::for(RetentionClass::Audit)->retentionDays);
        self::assertSame(730, RetentionPolicy::for(RetentionClass::Operational)->retentionDays);
        self::assertSame(90, RetentionPolicy::for(RetentionClass::Telemetry)->retentionDays);
        self::assertSame(30, RetentionPolicy::for(RetentionClass::Debug)->retentionDays);
    }

    public function test_overlay_can_only_touch_payload_or_metadata(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        new SignalRedactionOverlay([['op' => 'replace', 'path' => 'actor.id', 'value' => 'forged']]);
    }

    public function test_rate_limit_tightens_under_backpressure(): void
    {
        $policy = new SourceRateLimitPolicy(1000, 5000, 0.5);
        self::assertTrue($policy->decide('tenant', 999, false)->allowed);
        self::assertFalse($policy->decide('tenant', 500, true)->allowed);
        self::assertSame(500, $policy->decide('tenant', 499, true)->effectiveLimit);
    }
}
