<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Certification;

use Illuminate\Broadcasting\Channel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;

final class CertificationBroadcastProbe implements ShouldBroadcastNow
{
    public function __construct(public readonly string $token)
    {
    }

    public function broadcastOn(): array
    {
        return [new Channel('titan-connect.certification.'.hash('sha256', $this->token))];
    }

    public function broadcastAs(): string
    {
        return 'titan-connect.certification.probe';
    }

    public function broadcastWith(): array
    {
        return ['probe' => hash('sha256', $this->token)];
    }
}
