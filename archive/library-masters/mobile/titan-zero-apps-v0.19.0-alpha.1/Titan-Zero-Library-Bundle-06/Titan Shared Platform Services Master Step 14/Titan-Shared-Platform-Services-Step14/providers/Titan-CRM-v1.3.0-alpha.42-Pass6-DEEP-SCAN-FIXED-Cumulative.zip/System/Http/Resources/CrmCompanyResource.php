<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

final class CrmCompanyResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'public_id' => $this->public_id,
            'customer_unification_id' => $this->customer_unification_id,
            'name' => $this->name,
            'legal_name' => $this->legal_name,
            'website' => $this->website,
            'email' => $this->email,
            'phone' => $this->phone,
            'address' => $this->address,
            'notes' => $this->notes,
            'status' => $this->status,
            'owner_user_id' => $this->owner_user_id,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
