<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalContext
{
    /** @param list<string> $permissions */
    public function __construct(
        public string $scope,
        public ?int $tenantCompanyId,
        public SignalActor $actor,
        public array $permissions = [],
        public ?SignalEmitterIdentity $emitter = null,
    ) {
        if (! in_array($this->scope, [SignalEnvelope::SCOPE_TENANT, SignalEnvelope::SCOPE_SYSTEM], true)) {
            throw new InvalidArgumentException('Signal context scope must be tenant or system.');
        }
        if ($this->scope === SignalEnvelope::SCOPE_TENANT && ($this->tenantCompanyId === null || $this->tenantCompanyId < 1)) {
            throw new InvalidArgumentException('Tenant signal context requires tenant_company_id.');
        }
        if ($this->scope === SignalEnvelope::SCOPE_SYSTEM && $this->tenantCompanyId !== null) {
            throw new InvalidArgumentException('System signal context must not contain tenant_company_id.');
        }
        if ($this->scope === SignalEnvelope::SCOPE_TENANT && $this->actor->tenantCompanyId !== null && $this->actor->tenantCompanyId !== $this->tenantCompanyId) {
            throw new InvalidArgumentException('Signal actor tenant does not match context tenant.');
        }
    }

    public static function tenantHuman(
        int $tenantCompanyId,
        string $actorId,
        string $sessionId,
        string $identityProvider,
        ?SignalEmitterIdentity $emitter = null,
        array $permissions = [],
    ): self {
        return new self(
            SignalEnvelope::SCOPE_TENANT,
            $tenantCompanyId,
            new SignalActor($actorId, 'human', $tenantCompanyId, $identityProvider, $sessionId),
            $permissions,
            $emitter,
        );
    }

    /** @param list<string> $permissions */
    public static function system(
        string $actorId,
        string $identityProvider = 'system',
        array $permissions = [],
        ?SignalEmitterIdentity $emitter = null,
    ): self {
        return new self(
            SignalEnvelope::SCOPE_SYSTEM,
            null,
            new SignalActor($actorId, 'system', null, $identityProvider, null),
            $permissions,
            $emitter,
        );
    }

    public function hasPermission(string $permission): bool
    {
        return in_array($permission, $this->permissions, true);
    }
}
