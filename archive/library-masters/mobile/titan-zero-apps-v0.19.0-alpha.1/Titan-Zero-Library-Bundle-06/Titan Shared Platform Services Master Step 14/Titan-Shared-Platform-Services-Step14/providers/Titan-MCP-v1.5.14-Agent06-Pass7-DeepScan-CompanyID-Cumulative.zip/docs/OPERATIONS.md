# Operations

Use **Titan MCP → Overview** for endpoint, catalogue hash and audit-chain health. Use **Settings** to control server enablement, trusted origins, throttles, write gates, destructive operations, retention and execution limits.

Before enabling production writes, verify encrypted recovery storage, database dump/restore binaries and a valid audit chain. Long-running workers should be restarted after changing persisted extension settings.
