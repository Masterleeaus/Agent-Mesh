<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Certification;

use Illuminate\Support\Str;
use Throwable;

final class BroadcastExecutionProbe
{
    /** @return array{name:string,status:string,message:string} */
    public function run(): array
    {
        $driver = (string) config('broadcasting.default', 'null');
        if (in_array($driver, ['null', 'log'], true)) {
            return [
                'name' => 'broadcast-execution',
                'status' => 'warning',
                'message' => "Broadcast driver [{$driver}] cannot certify realtime delivery.",
            ];
        }

        try {
            broadcast(new CertificationBroadcastProbe((string) Str::uuid()));
            return [
                'name' => 'broadcast-execution',
                'status' => 'ok',
                'message' => "Broadcast probe published through [{$driver}]. Client receipt still requires an end-to-end realtime smoke test.",
            ];
        } catch (Throwable $e) {
            return [
                'name' => 'broadcast-execution',
                'status' => 'error',
                'message' => 'Broadcast certification failed: '.$e->getMessage(),
            ];
        }
    }
}
