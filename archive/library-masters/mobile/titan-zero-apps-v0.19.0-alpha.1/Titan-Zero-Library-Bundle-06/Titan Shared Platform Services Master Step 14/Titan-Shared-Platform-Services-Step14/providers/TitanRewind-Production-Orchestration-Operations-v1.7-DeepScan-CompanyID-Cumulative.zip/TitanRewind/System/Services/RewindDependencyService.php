<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Models\RewindCaseTrace;
use App\Extensions\TitanRewind\System\Models\RewindDependency;
use App\Extensions\TitanRewind\System\Models\RewindTraceEvent;
use App\Extensions\TitanRewind\System\Reconstruction\RewindDependencyExtractor;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;

final class RewindDependencyService
{
    public function __construct(private RewindDependencyExtractor $extractor) {}

    public function recordFromEvent(RewindTraceEvent $event): array
    {
        $payload = $event->payload ?? [];
        $dependencies = $this->extractor->extract(
            $payload,
            isset($payload['entity_type']) ? (string) $payload['entity_type'] : null,
            isset($payload['entity_id']) ? (string) $payload['entity_id'] : null,
        );
        if ($dependencies === []) return [];

        $caseId = RewindCaseTrace::query()->where('tenant_company_id',$event->tenant_company_id)->where('trace_id',$event->trace_id)->value('case_id');
        $stored = [];
        foreach ($dependencies as $dependency) {
            $dependencyKey = hash('sha256', implode('|', [
                (string) $event->tenant_company_id,
                (string) $event->event_id,
                $dependency['source_entity_type'],
                (string) ($dependency['source_entity_id'] ?? ''),
                $dependency['target_entity_type'],
                (string) ($dependency['target_entity_id'] ?? ''),
                $dependency['relationship_type'],
            ]));
            $stored[] = RewindDependency::query()->firstOrCreate([
                'dependency_key' => $dependencyKey,
            ], [
                'tenant_company_id' => $event->tenant_company_id,
                'event_id' => $event->event_id,
                'source_entity_type' => $dependency['source_entity_type'],
                'source_entity_id' => $dependency['source_entity_id'],
                'target_entity_type' => $dependency['target_entity_type'],
                'target_entity_id' => $dependency['target_entity_id'],
                'relationship_type' => $dependency['relationship_type'],
                'case_id' => $caseId,
                'trace_id' => $event->trace_id,
                'risk_level' => $dependency['risk_level'],
                'metadata' => $dependency['metadata'],
            ]);
        }
        return $stored;
    }

    public function forTrace(RewindTraceQuery $query): array
    {
        return RewindDependency::query()->where('tenant_company_id',$query->tenantCompanyId())->where('trace_id',$query->traceId())->orderBy('id')->limit(1000)->lazy(250)->toArray();
    }

    public function impactForEntity(int $tenantCompanyId, string $entityType, ?string $entityId): array
    {
        $direct = RewindDependency::query()->where('tenant_company_id',$tenantCompanyId)->where('source_entity_type',$entityType)
            ->when($entityId, static fn($q) => $q->where('source_entity_id',$entityId))->limit(250)->lazy(250);
        $reverse = RewindDependency::query()->where('tenant_company_id',$tenantCompanyId)->where('target_entity_type',$entityType)
            ->when($entityId, static fn($q) => $q->where('target_entity_id',$entityId))->limit(250)->lazy(250);
        return ['direct'=>$direct->toArray(),'reverse'=>$reverse->toArray(),'count'=>$direct->count()+$reverse->count()];
    }
}
