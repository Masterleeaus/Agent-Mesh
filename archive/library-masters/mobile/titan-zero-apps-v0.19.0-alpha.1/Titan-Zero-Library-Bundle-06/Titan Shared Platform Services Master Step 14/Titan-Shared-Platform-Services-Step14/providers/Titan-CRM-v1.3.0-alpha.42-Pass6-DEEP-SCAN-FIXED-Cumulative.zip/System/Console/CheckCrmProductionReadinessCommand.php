<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\Services\CrmProductionHealthService;
use Illuminate\Console\Command;

final class CheckCrmProductionReadinessCommand extends Command
{
    protected $signature='crm:production-check {--json : Emit machine-readable JSON}';
    protected $description='Check Titan CRM Core production-readiness without mutating state.';

    public function handle(CrmProductionHealthService $health): int
    {
        $result=$health->inspect();
        if($this->option('json')){$this->line((string)json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));}
        else{
            $severity=(string)($result['severity']??strtoupper((string)$result['status']));
            $this->info('Titan CRM Core production status: '.$severity.' ('.strtoupper((string)$result['status']).')');
            foreach($result['blockers'] as $item)$this->error('BLOCKER: '.$item);
            foreach($result['warnings'] as $item)$this->warn('WARNING: '.$item);
        }
        return $result['status']==='blocked'?self::FAILURE:self::SUCCESS;
    }
}
