# Ownership

Titan Bookings & Quotes owns booking/service-request commercial facts, quote versions/lines/acceptance evidence, variation/requote lineage and its durable integration outbox.

It does not own CRM customers, workers, workforce hierarchy, schedules, shifts, dispatch assignments, field jobs, invoices, payment ledgers, payroll or accounting. Those systems are referenced through opaque IDs and typed ports.

`company_id` is the sole canonical tenant/company boundary for all new code, persistence, authorization and contracts.
