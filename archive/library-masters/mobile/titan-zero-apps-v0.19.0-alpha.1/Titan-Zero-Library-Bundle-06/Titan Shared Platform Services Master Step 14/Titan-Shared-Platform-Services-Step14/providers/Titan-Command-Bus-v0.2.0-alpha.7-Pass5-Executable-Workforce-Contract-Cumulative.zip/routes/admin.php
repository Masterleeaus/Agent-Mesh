<?php

declare(strict_types=1);

use App\Extensions\TitanCommandBus\System\Http\Controllers\AdminController;
use Illuminate\Support\Facades\Route;

Route::get('/', [AdminController::class, 'index'])->name('index');
Route::get('/health', [AdminController::class, 'health'])->name('health');
