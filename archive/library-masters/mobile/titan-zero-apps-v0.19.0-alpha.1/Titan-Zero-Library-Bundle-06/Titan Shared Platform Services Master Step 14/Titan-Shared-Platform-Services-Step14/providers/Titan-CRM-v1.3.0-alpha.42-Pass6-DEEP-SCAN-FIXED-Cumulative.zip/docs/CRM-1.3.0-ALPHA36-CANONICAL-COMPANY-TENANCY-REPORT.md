# CRM 1.3.0-alpha.36 Canonical Company Tenancy Report

## Decision

Titan CRM Core uses host `companies.id` through **`company_id`** as the authoritative tenant boundary. This supersedes CRM's earlier `tenant_company_id` runtime contract.

## Upgrade strategy

Migration history is preserved. Existing installations first run any pending historical migrations using their historical schema, then migration `000045` performs the canonical conversion. Fresh installations follow the same deterministic sequence.

Contacts and deals previously used `company_id` for the linked CRM customer organisation while also carrying `tenant_company_id`. Migration `000045` first renames that relationship to `customer_company_id`, then renames the tenant column to `company_id`.

The migration repairs pipeline stages from their parent pipeline and deterministic legacy rows from Titan user-company context. It refuses to make the tenant column non-null while unresolved CRM Core rows remain.

## Ownership boundary

Only CRM Core-owned tables are converted. Titan Field, Titan Locker, Titan Ledger, Titan Pay and historical CRM Autonomy/learning tables are excluded even when an older CRM release added `tenant_company_id` to them. Their destination extensions own future schema conversion.

For external-owned capabilities, CRM Core no longer introspects the destination table for reference validation, domain invariants or optimistic concurrency before dispatch. The owning extension is authoritative for those storage-level checks. CRM still owns the compatibility capability authorization, idempotency reservation, governed receipt, signals and audit envelope. Legacy direct-read compatibility paths fail closed if an owner table does not expose `company_id`.

## Runtime invariants

- All authoritative CRM reads and writes scope by `company_id`.
- Client payloads cannot select CRM tenant identity.
- Contact/deal customer organisation association uses `customer_company_id` or a public CRM company identifier.
- Company-level uniqueness does not include actor `user_id`.
- Pipeline stages carry and query their own `company_id`.
- Production certification is blocked until strict host CRM permission Gates are configured.

## Live database compatibility notes

The supplied Titan database was on the older CRM migration line, so alpha.36 intentionally uses a new forward migration rather than changing historical migrations already recorded by Laravel. Legacy menu rows are retired by key instead of deleted, preserving evidence and allowing destination extensions to own their own navigation.
