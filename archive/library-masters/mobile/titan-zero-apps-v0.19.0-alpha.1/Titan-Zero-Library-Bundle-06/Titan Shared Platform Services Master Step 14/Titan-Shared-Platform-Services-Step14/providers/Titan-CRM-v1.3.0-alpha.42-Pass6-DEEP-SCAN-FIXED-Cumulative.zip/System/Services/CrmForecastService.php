<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;

final class CrmForecastService
{
    public function __construct(private ConnectionInterface $db) {}

    public function summarize(int $userId): array
    {
        $row=$this->db->table(config('crm.tables.deals'))->where('company_id',CrmCompanyScope::companyId($userId))->whereNull('deleted_at')->selectRaw("SUM(CASE WHEN status='open' THEN 1 ELSE 0 END) AS open_count, COALESCE(SUM(CASE WHEN status='open' THEN value_minor ELSE 0 END),0) AS open_value_minor, COALESCE(SUM(CASE WHEN status='open' THEN value_minor * probability / 100 ELSE 0 END),0) AS weighted_value_minor, SUM(CASE WHEN status='won' THEN 1 ELSE 0 END) AS won_count, COALESCE(SUM(CASE WHEN status='won' THEN value_minor ELSE 0 END),0) AS won_value_minor, SUM(CASE WHEN status='lost' THEN 1 ELSE 0 END) AS lost_count, COALESCE(SUM(CASE WHEN status='lost' THEN value_minor ELSE 0 END),0) AS lost_value_minor")->first();
        return ['open_count'=>(int)($row->open_count??0),'open_value_minor'=>(int)($row->open_value_minor??0),'weighted_value_minor'=>(int)round((float)($row->weighted_value_minor??0)),'won_count'=>(int)($row->won_count??0),'won_value_minor'=>(int)($row->won_value_minor??0),'lost_count'=>(int)($row->lost_count??0),'lost_value_minor'=>(int)($row->lost_value_minor??0)];
    }
}
