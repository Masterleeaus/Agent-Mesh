<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\ReadModels;

use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;
use RuntimeException;

/** Portable default search adapter. Candidate discovery uses disposable indexed projection terms only. */
final class CrmSqlProjectionSearchAdapter implements CrmSearchPort
{
    public function __construct(private readonly ConnectionInterface $db,private readonly CrmReadProjectionRegistry $registry,private readonly CrmProjectionSearchIndexer $indexer) {}

    public function search(int $companyId,string $query,array $projectionNames=[],int $limit=25): array
    {
        $query=trim($query);if($companyId<1)throw new InvalidArgumentException('company_id is required.');if($query==='')return ['query'=>'','records'=>[],'count'=>0,'driver'=>'sql_projection_terms'];
        if(!$this->db->getSchemaBuilder()->hasTable('crm_read_projection_search_terms'))throw new RuntimeException('CRM projection search index is unavailable. Run CRM migrations.');
        $limit=max(1,min(100,$limit));$tokens=$this->indexer->tokenize($query);if($tokens===[])return ['query'=>$query,'records'=>[],'count'=>0,'driver'=>'sql_projection_terms'];$primary=$tokens[0];
        $names=$projectionNames!==[]?array_values(array_unique(array_map(fn($v)=>strtolower(trim((string)$v)),$projectionNames))):$this->registry->searchableNames();$definitions=[];foreach($names as $name){$definition=$this->registry->resolve($name);if((array)($definition['search_fields']??[])!==[])$definitions[$name]=$definition;}if($definitions===[])return ['query'=>$query,'records'=>[],'count'=>0,'driver'=>'sql_projection_terms'];
        $candidate_limit=max($limit,min(5000,(int)config('crm.performance.search_candidate_limit',1000)));$candidateRows=$this->db->table('crm_read_projection_search_terms')->where('company_id',$companyId)->where('term','like',$primary.'%')->whereIn('projection_name',array_keys($definitions))->orderByDesc('weight')->orderBy('id')->limit($candidate_limit)->get(['projection_name','projection_version','resource_public_id','weight']);
        $candidates=[];foreach($candidateRows as $row){$name=(string)$row->projection_name;if(!isset($definitions[$name])||(string)$row->projection_version!==(string)$definitions[$name]['projection_version'])continue;$key=$name.'|'.(string)$row->resource_public_id;$candidates[$key]=['projection_name'=>$name,'projection_version'=>(string)$row->projection_version,'resource_public_id'=>(string)$row->resource_public_id,'term_weight'=>max((int)($candidates[$key]['term_weight']??0),(int)$row->weight)];}
        $records=[];$byProjection=[];foreach($candidates as $candidate)$byProjection[$candidate['projection_name']][]=$candidate;
        foreach($byProjection as $name=>$projectionCandidates){$definition=$definitions[$name];$ids=array_column($projectionCandidates,'resource_public_id');$weightById=[];foreach($projectionCandidates as $candidate)$weightById[$candidate['resource_public_id']]=$candidate['term_weight'];foreach(array_chunk($ids,500) as $idChunk){$rows=$this->db->table('crm_read_projection_records')->where('company_id',$companyId)->where('projection_name',$name)->where('projection_version',$definition['projection_version'])->whereIn('resource_public_id',$idChunk)->get(['resource_public_id','payload','payload_hash']);foreach($rows as $row){$payload=$this->decode($row->payload??null);$score=$this->score($payload,(array)$definition['search_fields'],$tokens)+(int)($weightById[(string)$row->resource_public_id]??0);if($score<1)continue;$records[]=['projection_name'=>$name,'projection_version'=>$definition['projection_version'],'resource_public_id'=>(string)$row->resource_public_id,'score'=>$score,'payload_hash'=>(string)$row->payload_hash,'record'=>$payload];}}}
        usort($records,fn(array $a,array $b)=>$b['score']<=>$a['score']?:strcmp($a['resource_public_id'],$b['resource_public_id']));$records=array_slice($records,0,$limit);
        return ['query'=>$query,'records'=>$records,'count'=>count($records),'driver'=>'sql_projection_terms','candidate_count'=>count($candidates),'candidate_limit'=>$candidate_limit,'authoritative'=>false,'source'=>'crm_read_projection_search_terms + crm_read_projection_records'];
    }

    public function status(): array{return ['driver'=>'sql_projection_terms','authoritative'=>false,'source'=>'crm_read_projection_search_terms','oltp_access'=>false,'indexed_candidates'=>true];}
    private function score(array $payload,array $fields,array $tokens): int{$score=0;$matched=[];foreach($fields as $field){$value=$payload[(string)$field]??null;if(!is_scalar($value))continue;$hay=mb_strtolower((string)$value);foreach($tokens as $i=>$needle){if($hay===$needle){$score+=100;$matched[$i]=true;}elseif(str_starts_with($hay,$needle)){$score+=40;$matched[$i]=true;}elseif(str_contains($hay,$needle)){$score+=10;$matched[$i]=true;}}}return count($matched)===count($tokens)?$score:0;}
    private function decode(mixed $payload): array{if(is_array($payload))return $payload;if(!is_string($payload)||$payload==='')return [];return json_decode($payload,true)?:[];}
}
