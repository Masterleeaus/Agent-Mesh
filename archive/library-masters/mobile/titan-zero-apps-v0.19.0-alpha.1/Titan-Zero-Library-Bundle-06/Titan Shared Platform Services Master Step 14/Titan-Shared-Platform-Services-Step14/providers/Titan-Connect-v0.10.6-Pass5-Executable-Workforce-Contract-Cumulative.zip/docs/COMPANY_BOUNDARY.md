# Company Boundary — Titan Connect v0.10.6

`company_id` is the sole active isolation boundary.

## Rules

- Authenticated application traffic resolves company only from `request()->user()->company_id`.
- Company identity is never taken from `tenant_id`, user ID, request headers, query strings, provider payloads or client-selected values.
- Every company-owned Eloquent model implements `CompanyOwnedModel` / `BelongsToCompany`.
- `company_id` must be positive on creation and is immutable after persistence.
- `forCompany($companyId)` is the canonical explicit query scope.
- Authenticated Titan Connect routes use `EnsureCompanyRouteBindings`; foreign-company bound models are hidden with HTTP 404 before controller logic.
- Provider webhook company scope comes from the already-resolved `ChannelConnection`.
- Inbound queue jobs carry company ID + connection UUID + provider and re-resolve all three.
- Provider vault records/lookups are company scoped.
- Delivery row claims include `company_id`.
- New attachment paths use `titan-connect/company/{companyId}/...`.
- Realtime namespaces use `titan-connect.company.{companyId}.conversation.{uuid}`.
- WorkCore, Chatbot and MobileCore bridges receive company identity explicitly.

## v0.6 donor-owned data

The operator and voice additions preserve the same rule. Company ownership applies to:

- external contacts;
- contact tags and thread/tag pivot rows;
- canned responses;
- voice calls;
- voice transcripts;
- external-thread assignment/presentation metadata.

Meta OAuth state is encrypted and carries company + actor identity. Telegram onboarding creates credentials only for the authenticated company. Twilio WhatsApp remains inside the existing company-scoped WhatsApp connection. Voice browser sessions are issued only after the voice call and connection are rechecked against the authenticated company.

## Compatibility

Migration `2026_08_09_000003_migrate_tenant_boundary_to_company.php` handles pre-v0.4 canonical data. The legacy Chatbot Team Chat importer is the only runtime-adjacent compatibility component permitted to read historical `tenant_id`; it always writes `company_id`.

## v0.9 cross-cutting boundaries

- Authenticated rate-limit keys include the resolved `company_id` and actor ID; client input never selects the company key.
- Connection diagnostics are queried only from `forCompany($companyId)` records and management-authorized connections.
- Voice transcript idempotency is unique within company + voice call + client event ID.
- Host readiness diagnostics inspect schema/runtime configuration but never expose provider credentials.
