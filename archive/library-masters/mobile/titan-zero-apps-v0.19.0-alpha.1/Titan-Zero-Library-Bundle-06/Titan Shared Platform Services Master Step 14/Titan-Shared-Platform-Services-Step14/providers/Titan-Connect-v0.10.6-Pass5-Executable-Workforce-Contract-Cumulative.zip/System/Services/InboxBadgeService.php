<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Inbox\UnifiedInboxService;

final class InboxBadgeService
{
    public function __construct(
        private readonly UnifiedInboxService $unified,
        private readonly OperatorInboxService $operator,
    ) {
    }

    /** @return array<string,int> */
    public function summary(int $companyId, int $actorId): array
    {
        $items = $this->unified->items($companyId, $actorId, 100);
        $teamUnread = 0;
        $externalUnread = 0;
        foreach ($items as $item) {
            $count = max(0, (int) ($item['unread_count'] ?? 0));
            if (($item['source'] ?? null) === 'internal') {
                $teamUnread += $count;
            } elseif (($item['source'] ?? null) === 'external') {
                $externalUnread += $count;
            }
        }

        $needsHuman = count($this->operator->search($companyId, $actorId, [
            'handoff_state' => 'pending_human',
            'limit' => 100,
        ]));
        $mine = count($this->operator->search($companyId, $actorId, [
            'assigned_user_id' => $actorId,
            'status' => 'open',
            'limit' => 100,
        ]));
        $unassigned = count($this->operator->search($companyId, $actorId, [
            'unassigned' => true,
            'status' => 'open',
            'limit' => 100,
        ]));
        $closed = count($this->operator->search($companyId, $actorId, [
            'status' => 'closed',
            'limit' => 100,
        ]));

        return [
            'total' => min(999, $teamUnread + $externalUnread),
            'team' => min(999, $teamUnread),
            'external' => min(999, $externalUnread),
            'mine' => min(999, $mine),
            'unassigned' => min(999, $unassigned),
            'needs_human' => min(999, $needsHuman),
            'closed' => min(999, $closed),
        ];
    }
}
