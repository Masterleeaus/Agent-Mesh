# Titan Ledger Upgrade Prompt

Stable new-plan PLAN_ID: `9d8c7aff-0061-4732-9da0-1026dbe5b4a0`.

Current release: **v1.20.0-rc.5, Step 5/12 — Advanced Reconciliation Automation**.

Preserve all cumulative Ledger invariants: canonical `company_id` tenancy, integer minor units, immutable double-entry journals, Command Bus-only mutation, Risk/Assurance fail-closed gates, Signal durable outbox, Rewind read-only evidence, non-destructive rollback, production trigger self-heal, CRM/Titan Pay/spend/banking boundaries, GST/BAS evidence, financial reporting, and advisory-only forecasting.

## Step 2 invariants

- Fiscal-year close is prepared before execution and bound to an unchanged SHA-256 source fingerprint.
- All periods must be soft-locked; open/hard-locked periods block close.
- Draft/validated journals, Trial Balance imbalance, open bank reconciliation, prepared GST evidence, non-AUD journals or source drift block close.
- Only temporary P&L accounts are zeroed; exact net profit/loss transfers to protected Retained Earnings.
- Close creates a new immutable `year_end_close` journal; it never rewrites business journals.
- Reopen appends evidence and creates a linked `year_end_reopen` journal; it never deletes the original close.
- Historical P&L excludes close/reopen mechanics so comparisons remain economically correct.
- Closed close evidence is immutable and retained; later close cycles version/supersede rather than rewrite.
- Live production certification remains fail-closed until the real MySQL/Laravel host runs `php artisan titan-ledger:production-certify --repair --json=storage/app/titan-ledger-production-certification.json`.

Next: **Step 6/12 — Customer Credits, Deposits & Prepayments**. Complete customer deposit, unapplied cash, credit application/refund and AR subledger reconciliation without duplicating CRM or payment authority.

## Step 3 invariants

- Installer 1.7.6 root dependencies are a JSON list and every entry contains `slug` and `version`.
- Only approved GST adjustments affect BAS evidence; pending reviews block snapshot finalization.
- Financial-impact GST adjustments require a posted Ledger journal reference and cannot post journals themselves.
- Full-BAS classification completeness is fail-closed; missing G10/G11 classification prevents lodgement-ready evidence.
- Tax amendments create superseding snapshot versions; finalized evidence remains immutable.
- ATO/SBR lodgement authority remains none.


## Step 4 invariants

- Financial-account registration is immutable, `company_id` scoped, and references canonical Ledger COA accounts rather than creating a second balance store.
- Bank/clearing accounts are assets; credit-card accounts are liabilities with subtype `credit_card`.
- Internal transfers, clearing payouts and credit-card payments are balanced authoritative source journals and remain Command Bus/Risk/Assurance governed.
- Clearing settlement capture is not cash. Only a governed clearing payout into a registered bank account increases cash.
- Clearing payouts cannot exceed the posted clearing balance.
- Titan Pay provider refunds remain on the original payment funds account.
- Actual cashflow uses registered bank accounts plus cash-on-hand, excludes clearing, and nets per journal so internal transfers do not inflate gross flow.
- No payment initiation, bank credential, provider secret or card authorization authority is introduced.
- Production certification requires the Step 4 migration/tables, payment settlement funds-account column and 55 MySQL triggers.


## Step 5 invariants

- Statement import remains evidence-only and cannot create a journal.
- Economic duplicate statements fail closed even when provider IDs differ.
- Supported grouped match shapes are one-to-many and many-to-one; many-to-many is rejected.
- Exact signed summed amount and bounded date distance are required for group matching.
- Group/member evidence is immutable; rejection releases only derived active membership.
- Bank-fee and interest adjustments are the only Step 5 reconciliation-generated journal types and remain Command Bus/Risk/Assurance governed.
- Raw bank narrative remains excluded from persisted normalized evidence.
- Production certification requires migration 20, advanced reconciliation columns and 63 MySQL triggers.
