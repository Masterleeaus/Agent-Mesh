# Titan Governance v0.6.0 — Pass 5 Decision Intelligence Report

## Scope

Pass 5 adds a read-only decision-forensics layer over Governance-owned immutable decisions and bounded evidence supplied by peer Titan engines.

## Implemented

- `GovernanceDecisionEvidenceSourceContract` and deterministic adapter registry.
- Recursive evidence sanitizer that removes hidden reasoning, raw prompts/responses, credentials, tokens, secrets and authorization material.
- Tenant-scoped Governance decision read repository.
- Chronological Decision Timeline with source identity verification and failure isolation.
- Delta Viewer with bounded recursive comparison, volatile-field exclusion, display truncation and SHA-256 hashes for changed long values.
- Policy & Compliance aggregation with explicit `HEALTHY`, `DEGRADED`, `NON_COMPLIANT`, `UNAVAILABLE` and `NOT_FOUND` semantics.
- Rewind Theater bridge that renders only Titan Rewind supplied reconstruction metadata and fails closed when Rewind is absent/invalid.
- Decision detail UI and authenticated JSON endpoints.
- Recent Governance Decisions surface on the main dashboard.
- Explicit tenant resolver hardening: no fabricated tenant IDs from team/user identifiers.

## Ownership boundaries

Governance does not copy or become source of truth for Risk, Assurance, Autonomy, Signal, Rewind, Command Bus, Shield, Knowledge Authority, Model Council or Workforce state. Decision evidence adapters are read-only and independently configurable.

## Live host boundary

The package ships fail-closed/unavailable decision-evidence adapters by default. Production hosts bind adapters with the `TITAN_GOVERNANCE_*_EVIDENCE_CLASS` environment/config values. Static/package certification does not claim those host bindings have been exercised.

## Certification standard

Final source/package certification uses Titan Extension Blueprint v4.2.2 Deep-Scan Remediated Cumulative (SHA-256 `567167d6e69200620aaf01ebd591372a08acb6bfde278dbe613e76bc7c159515`). Live-host certification remains NOT_RUN.
