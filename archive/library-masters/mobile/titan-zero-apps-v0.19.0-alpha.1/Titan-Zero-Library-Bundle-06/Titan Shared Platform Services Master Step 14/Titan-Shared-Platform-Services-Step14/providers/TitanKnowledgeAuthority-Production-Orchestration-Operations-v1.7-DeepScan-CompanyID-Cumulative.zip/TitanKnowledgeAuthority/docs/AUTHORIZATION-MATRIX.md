# Authorization Matrix
| Operation | Required authority | Pass 3 behavior |
|---|---|---|
| Health | authenticated host surface | implemented |
| Internal platform source metadata read | trusted access context | allowed for canonical platform scope |
| Internal tenant source/version metadata read | matching trusted `tenant_company_id` | cross-tenant denied |
| Internal jurisdiction source/version metadata read | explicit trusted jurisdiction code | ungranted jurisdiction denied |
| Public catalog read capability | n/a | not advertised |
| Knowledge mutation | n/a | not exposed |
| Remote refresh | n/a | disabled |
| Business-state mutation | n/a | forbidden by architecture |

Tenant or jurisdiction scope must never be derived from caller request/query/body parameters. The default resolver fails closed until the Titan host binds a trusted implementation.
