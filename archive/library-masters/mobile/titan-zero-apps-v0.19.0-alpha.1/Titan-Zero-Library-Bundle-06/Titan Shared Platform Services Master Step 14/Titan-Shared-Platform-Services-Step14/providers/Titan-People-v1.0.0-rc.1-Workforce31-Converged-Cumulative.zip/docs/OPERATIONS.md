# Operations

Install through Titan Extension Installer 1.7.8. The provider loads People migrations, routes, views and idempotent menu registration. `titan-people:host-sync` repairs host menu rows while preserving administrator-controlled order and enabled state.

## Outbox delivery health

When `TITAN_PEOPLE_OUTBOX_DISPATCH_ENABLED=true`, Titan People schedules `titan-people:dispatch-outbox` every minute with single-server and overlap protection. Batch size defaults to 100 and is hard-bounded to 250.

Operational checks:

- Count unpublished `titan_people_signal_outbox` rows by tenant and inspect the oldest `occurred_at`.
- Watch `attempts` and `last_error`; failures remain replayable until a non-empty external delivery receipt is stored.
- A growing unpublished backlog indicates the host Signal delivery port is unavailable or rejecting events; People facts remain durable and no event is marked published without a receipt.
- Use `php artisan titan-people:dispatch-outbox --limit=25` for a bounded manual health probe.
- Never delete unpublished rows to clear a backlog.

## Leave reconciliation

Leave balance reconciliation compares `titan_people_leave_balances.cached_units` with the exact sum of tenant/worker/leave-type ledger entries. A mismatch is an integrity fault and must not be silently repaired from the cache.

## Lifecycle concurrency

Employment lifecycle stale-version failures require the caller to re-read current state before submitting a new command. Retrying a successfully executed command must reuse its idempotency key.
