<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryDispatcherContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryLeaseManagerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliverySchedulerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalSubscriberContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalSubscriptionRegistryContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryLease;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryReceipt;
use App\Extensions\TitanSignalEngine\System\Data\SignalRetryPolicy;
use App\Extensions\TitanSignalEngine\System\Models\SignalDelivery;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;
use RuntimeException;
use Throwable;

final class SignalDeliveryDispatcher implements SignalDeliveryDispatcherContract
{
    public function __construct(
        private readonly SignalSubscriptionRegistryContract $subscriptions,
        private readonly SignalDeliverySchedulerContract $scheduler,
        private readonly SignalSubscriptionFailureReporter $failureReporter,
        private readonly SignalDeliveryLeaseManagerContract $leases,
    ) {
    }

    public function deliver(string $deliveryId, ?string $executionToken = null, ?string $workerId = null): SignalDeliveryReceipt
    {
        $delivery = $this->delivery($deliveryId);
        if ($this->terminal($delivery)) {
            return $this->receipt($delivery);
        }

        $subscription = $this->subscriptions->find((string) $delivery->subscriber_key);
        $timeoutSeconds = $subscription?->timeoutSeconds ?? 30;
        $baseLease = function_exists('config') ? (int) config('titan-signal-engine.delivery_lease_seconds', 120) : 120;
        $grace = function_exists('config') ? (int) config('titan-signal-engine.delivery_lease_grace_seconds', 30) : 30;
        $leaseTtl = max($baseLease, $timeoutSeconds + max(5, $grace));

        $executionToken ??= $this->leases->newExecutionToken();
        $workerId ??= 'direct:' . $executionToken;
        $lease = $this->leases->claim($deliveryId, $executionToken, $workerId, $leaseTtl);
        if ($lease === null) {
            return $this->receipt($this->delivery($deliveryId));
        }

        $delivery = $this->delivery($deliveryId);
        if ($subscription === null || $subscription->status === 'disabled') {
            return $this->deadLetter($delivery, $lease, RuntimeException::class, 'subscription_unavailable');
        }
        if ($subscription->status === 'paused') {
            $this->leases->markRetry($lease, now()->addMinutes(5));
            return $this->receipt($this->delivery($deliveryId));
        }

        /** @var SignalEvent|null $event */
        $event = SignalEvent::query()->where('event_id', $delivery->event_id)->first();
        if ($event === null) {
            return $this->deadLetter($delivery, $lease, RuntimeException::class, 'source_event_missing');
        }

        try {
            $this->assertDeliveryMatchesEvent($delivery, $event);
            $handler = app($subscription->handlerClass);
            if (! $handler instanceof SignalSubscriberContract) {
                throw new RuntimeException('invalid_subscriber_handler');
            }

            $handler->handle($event, new SignalDeliveryContext(
                (string) $delivery->delivery_id,
                (string) $delivery->subscriber_key,
                (int) $delivery->attempt_count,
                $lease->token,
                $lease->workerId,
                'signal-delivery:' . (string) $delivery->delivery_id,
            ));

            $this->leases->markDelivered($lease);
            return $this->receipt($this->delivery($deliveryId));
        } catch (Throwable $exception) {
            return $this->handleFailure($delivery, $lease, $subscription->maxAttempts, $subscription->backoffSeconds, $exception);
        }
    }

    public function transportFailed(string $deliveryId, Throwable $exception, ?string $executionToken = null): SignalDeliveryReceipt
    {
        $delivery = $this->delivery($deliveryId);
        if ($this->terminal($delivery)) {
            return $this->receipt($delivery);
        }

        // Queue failure callbacks may arrive after another worker has reclaimed
        // an expired lease. Never let a stale callback mutate the current owner.
        if ($executionToken === null
            || (string) $delivery->status !== 'processing'
            || $delivery->lease_token === null
            || ! hash_equals((string) $delivery->lease_token, $executionToken)) {
            return $this->receipt($delivery);
        }

        $lease = $this->leaseFromDelivery($delivery);
        $subscription = $this->subscriptions->find((string) $delivery->subscriber_key);
        $maxAttempts = $subscription?->maxAttempts ?? max(1, (int) $delivery->attempt_count + 1);
        $backoff = $subscription?->backoffSeconds ?? [30];
        return $this->handleFailure($delivery, $lease, $maxAttempts, $backoff, $exception);
    }

    /** @param list<int> $backoffSeconds */
    private function handleFailure(
        SignalDelivery $delivery,
        SignalDeliveryLease $lease,
        int $maxAttempts,
        array $backoffSeconds,
        Throwable $exception,
    ): SignalDeliveryReceipt {
        $errorClass = $exception::class;
        $errorReference = $this->safeErrorReference($exception);
        $policy = new SignalRetryPolicy($maxAttempts, $backoffSeconds);
        $attempt = (int) $delivery->attempt_count;

        if ($policy->shouldRetry($attempt)) {
            $delay = $policy->delaySecondsForAttempt($attempt);
            if ($this->leases->markRetry($lease, now()->addSeconds($delay), $errorClass, $errorReference)) {
                $this->scheduler->enqueue((string) $delivery->delivery_id, $delay);
            }
            return $this->receipt($this->delivery((string) $delivery->delivery_id));
        }

        return $this->deadLetter($delivery, $lease, $errorClass, $errorReference);
    }

    private function deadLetter(
        SignalDelivery $delivery,
        SignalDeliveryLease $lease,
        string $errorClass,
        string $errorReference,
    ): SignalDeliveryReceipt {
        $transitioned = $this->leases->markDeadLetter($lease, $errorClass, $errorReference);
        $fresh = $this->delivery((string) $delivery->delivery_id);
        if ($transitioned && (string) $delivery->event_type !== 'signal.subscription.failed') {
            $this->failureReporter->report($fresh, $errorClass);
        }
        return $this->receipt($fresh);
    }

    private function assertDeliveryMatchesEvent(SignalDelivery $delivery, SignalEvent $event): void
    {
        if ((string) $delivery->scope !== (string) $event->scope
            || (int) ($delivery->tenant_company_id ?? 0) !== (int) ($event->tenant_company_id ?? 0)
            || (string) $delivery->event_type !== (string) $event->event_type
            || (int) $delivery->schema_version !== (int) $event->schema_version) {
            throw new RuntimeException('Signal delivery ledger does not match immutable source event ownership/schema.');
        }
    }

    private function delivery(string $deliveryId): SignalDelivery
    {
        /** @var SignalDelivery|null $delivery */
        $delivery = SignalDelivery::query()->where('delivery_id', $deliveryId)->first();
        if ($delivery === null) {
            throw new RuntimeException('Signal delivery does not exist.');
        }
        return $delivery;
    }

    private function terminal(SignalDelivery $delivery): bool
    {
        return in_array((string) $delivery->status, ['delivered', 'dead_letter'], true);
    }

    private function leaseFromDelivery(SignalDelivery $delivery): SignalDeliveryLease
    {
        if ($delivery->lease_token === null || $delivery->lease_owner === null || $delivery->lease_expires_at === null) {
            throw new RuntimeException('Signal delivery has no active lease ownership.');
        }
        return new SignalDeliveryLease(
            (string) $delivery->delivery_id,
            (string) $delivery->lease_token,
            (string) $delivery->lease_owner,
            (int) $delivery->claim_version,
            $this->toImmutable($delivery->processing_started_at ?? $delivery->reserved_at ?? now()),
            $this->toImmutable($delivery->lease_expires_at),
        );
    }

    private function receipt(SignalDelivery $delivery): SignalDeliveryReceipt
    {
        $next = $delivery->available_at === null ? null : $this->toImmutable($delivery->available_at);
        return new SignalDeliveryReceipt(
            (string) $delivery->delivery_id,
            (string) $delivery->event_id,
            (string) $delivery->subscriber_key,
            (string) $delivery->status,
            (int) $delivery->attempt_count,
            $next,
            $delivery->last_error === null ? null : (string) $delivery->last_error,
        );
    }

    private function toImmutable(mixed $value): DateTimeImmutable
    {
        if ($value instanceof DateTimeInterface) {
            return new DateTimeImmutable($value->format(DATE_ATOM));
        }
        return new DateTimeImmutable((string) $value, new DateTimeZone('UTC'));
    }

    private function safeErrorReference(Throwable $exception): string
    {
        return 'delivery_failed:' . substr(hash('sha256', $exception::class . '|' . $exception->getMessage()), 0, 20);
    }
}
