<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\TitanMobile;

use App\Extensions\Crm\System\Capabilities\CrmCapabilityManifest;
use App\Extensions\Crm\System\Governance\CrmCommandBusGateway;
use App\Extensions\Crm\System\Security\CrmPermissionService;
use App\Extensions\Crm\System\Tenancy\CrmCompanyContextResolver;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Database\ConnectionInterface;

/**
 * Additive decorators for Titan Mobile v0.13 contracts.
 *
 * Titan Mobile resolves company/customer/worker context first. CRM consumes that
 * trusted context and independently re-authorizes CRM resources; browser supplied
 * company IDs are never used here as authority.
 */
final class CrmTitanMobileIntegrationRegistrar
{
    public function __construct(private Application $app) {}

    public function register(): void
    {
        $this->advertiseCapabilities();
        $this->decorateCustomerGateway();
        $this->decorateOwnerDashboardGateway();
        $this->decorateOwnerActionGateway();
    }

    private function advertiseCapabilities(): void
    {
        $contract = \App\Extensions\TitanMobileCore\System\Contracts\MobileCapabilityRegistry::class;
        if (! interface_exists($contract) || ! $this->app->bound($contract)) {
            return;
        }
        $registry = $this->app->make($contract);
        foreach (CrmCapabilityManifest::platformCapabilities() as $capability) {
            $registry->register($capability, [
                'extension' => 'Crm',
                'version' => '1.2',
                'authority' => 'crm',
                'tenant_key' => 'company_id',
            ]);
        }

        // Transitional aliases retained for pre-1.2 Titan Mobile consumers.
        $legacy=['crm.mobile.customer','crm.mobile.owner','crm.chatbot.customer-tools'];
        foreach ($legacy as $legacyCapability) {
            $registry->register($legacyCapability, [
                'extension' => 'Crm',
                'version' => '1.2',
                'authority' => 'crm',
                'tenant_key' => 'company_id',
                'legacy_alias' => true,
            ]);
        }
    }

    private function decorateCustomerGateway(): void
    {
        $contract = \App\Extensions\TitanHub\System\Contracts\CustomerOperationsGateway::class;
        if (! (bool) config('crm.titan_mobile.customer_enabled', true)
            || ! interface_exists($contract)
            || ! $this->app->bound($contract)) {
            return;
        }
        $inner = $this->app->make($contract);
        if ($inner instanceof CrmCustomerOperationsGateway) {
            return;
        }
        $this->app->instance($contract, new CrmCustomerOperationsGateway(
            $inner,
            $this->app->make(CrmMobileIdentityResolver::class),
            $this->app->make(ConnectionInterface::class),
            $this->app->make(CrmCommandBusGateway::class),
            $this->app->make(CrmCompanyContextResolver::class),
            $this->app->make(CrmCompanyScope::class),
        ));
    }

    private function decorateOwnerDashboardGateway(): void
    {
        $contract = \App\Extensions\TitanBOS\System\Contracts\OwnerDashboardGateway::class;
        if (! (bool) config('crm.titan_mobile.owner_enabled', true)
            || ! interface_exists($contract)
            || ! $this->app->bound($contract)) {
            return;
        }
        $inner = $this->app->make($contract);
        if ($inner instanceof CrmOwnerDashboardGateway) {
            return;
        }
        $this->app->instance($contract, new CrmOwnerDashboardGateway(
            $inner,
            $this->app->make(ConnectionInterface::class),
            $this->app->make(CrmPermissionService::class),
            $this->app->make(CrmCompanyContextResolver::class),
            $this->app->make(CrmCompanyScope::class),
        ));
    }

    private function decorateOwnerActionGateway(): void
    {
        $contract = \App\Extensions\TitanBOS\System\Contracts\OwnerActionGateway::class;
        if (! (bool) config('crm.titan_mobile.owner_enabled', true)
            || ! interface_exists($contract)
            || ! $this->app->bound($contract)) {
            return;
        }
        $inner = $this->app->make($contract);
        if ($inner instanceof CrmOwnerActionGateway) {
            return;
        }
        $this->app->instance($contract, new CrmOwnerActionGateway(
            $inner,
            $this->app->make(CrmCommandBusGateway::class),
            $this->app->make(CrmCompanyContextResolver::class),
            $this->app->make(CrmCompanyScope::class),
        ));
    }


}
