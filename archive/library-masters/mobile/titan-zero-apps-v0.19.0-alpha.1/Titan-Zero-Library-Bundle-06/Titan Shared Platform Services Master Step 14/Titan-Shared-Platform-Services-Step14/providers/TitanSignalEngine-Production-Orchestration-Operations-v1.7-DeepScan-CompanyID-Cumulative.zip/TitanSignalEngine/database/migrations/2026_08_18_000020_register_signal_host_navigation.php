<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key')) {
            return;
        }

        $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
        if (! isset($columns['id'])) {
            return;
        }

        $rows = [
            [
                'key' => 'titan_signal_pulse',
                'parent_id' => null,
                'route' => 'dashboard.user.titan.signal.engine.index',
                'route_slug' => null,
                'label' => 'Signal & Pulse',
                'icon' => 'tabler-heart-rate-monitor',
                'svg' => null,
                'order' => 70,
                'is_active' => 1,
                'is_admin' => 0,
                'params' => '[]',
                'type' => 'item',
                'badge' => null,
                'extension' => null,
                'custom_menu' => 0,
                'bolt_menu' => 0,
                'bolt_background' => null,
                'bolt_foreground' => null,
                'letter_icon' => 0,
                'letter_icon_bg' => null,
            ],
            [
                'key' => 'titan_signal_engine_admin',
                'parent_id' => null,
                'route' => 'dashboard.admin.titan.signal.engine.index',
                'route_slug' => null,
                'label' => 'Signal Engine',
                'icon' => 'tabler-heart-rate-monitor',
                'svg' => null,
                'order' => 995,
                'is_active' => 1,
                'is_admin' => 1,
                'params' => '[]',
                'type' => 'item',
                'badge' => null,
                'extension' => null,
                'custom_menu' => 0,
                'bolt_menu' => 0,
                'bolt_background' => null,
                'bolt_foreground' => null,
                'letter_icon' => 0,
                'letter_icon_bg' => null,
            ],
        ];

        $changed = false;
        foreach ($rows as $row) {
            $existing = DB::table('menus')->where('key', $row['key'])->orderBy('id')->first();
            $payload = array_intersect_key($row, $columns);
            if ($existing !== null) {
                // Preserve administrator enable/disable choices. Preserve user order; repair
                // an old admin row into Website1408's 900+ Super Admin order band when needed.
                unset($payload['is_active']);
                if ($row['key'] === 'titan_signal_pulse' || (int) ($existing->order ?? 0) >= 900) {
                    unset($payload['order']);
                }
                if (isset($columns['updated_at'])) {
                    $payload['updated_at'] = now();
                }
                DB::table('menus')->where('id', (int) $existing->id)->update($payload);
                $changed = true;
                continue;
            }

            if (isset($columns['created_at'])) {
                $payload['created_at'] = now();
            }
            if (isset($columns['updated_at'])) {
                $payload['updated_at'] = now();
            }
            $payload['key'] = $row['key'];
            DB::table('menus')->insert(array_intersect_key($payload, $columns));
            $changed = true;
        }

        if ($changed && class_exists(\App\Services\Common\MenuService::class)) {
            try {
                $service = app(\App\Services\Common\MenuService::class);
                if (method_exists($service, 'regenerate')) {
                    $service->regenerate();
                }
            } catch (\Throwable) {
                try {
                    \App\Services\Common\MenuService::regenerate();
                } catch (\Throwable) {
                    // Menu rows are durable; a later provider boot/host-sync will retry cache refresh.
                }
            }
        }
    }

    public function down(): void
    {
        if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key')) {
            return;
        }

        DB::table('menus')->whereIn('key', [
            'titan_signal_pulse',
            'titan_signal_engine_admin',
        ])->delete();
    }
};
