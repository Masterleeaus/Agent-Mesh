<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Host;

use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use FilesystemIterator;

final class TitanFreshInstallPreflight
{
    /** @return array{compatible:bool,reasons:list<string>,expected:array<string,string>,actual:array<string,string>} */
    public static function hostCompatibility(array $facts): array
    {
        $actual=[
            'php'=>(string)($facts['php']??''),
            'laravel'=>(string)($facts['laravel']??''),
            'database'=>strtolower((string)($facts['database']??'')),
            'installer'=>(string)($facts['installer']??''),
        ];
        $reasons=[];
        if (!str_starts_with($actual['php'],'8.3.')) $reasons[]='PHP 8.3.x is required by this release profile.';
        if (!str_starts_with($actual['laravel'],'10.50.')) $reasons[]='Laravel 10.50.x is required by this release profile.';
        if ($actual['database']!=='mysql') $reasons[]='MySQL is the certified database driver.';
        if (!in_array($actual['installer'],['1.7.6','1.7.8'],true)) $reasons[]='Observed/certified Installer build must be 1.7.6 or 1.7.8.';
        return [
            'compatible'=>$reasons===[],
            'reasons'=>$reasons,
            'expected'=>['php'=>'8.3.x','laravel'=>'10.50.x','database'=>'mysql','installer'=>'1.7.6|1.7.8'],
            'actual'=>$actual,
        ];
    }

    public function inspect(string $root, array $hostFacts): array
    {
        $errors=[];$checks=[];
        $manifestPath=rtrim($root,'/').'/extension.json';
        $manifest=is_file($manifestPath)?json_decode((string)file_get_contents($manifestPath),true):null;
        if (!is_array($manifest)) $errors[]='extension.json is missing or invalid JSON.';
        else $errors=array_merge($errors,(new TitanInstallerManifestContract())->validate($manifest,true));
        $checks['installer_manifest']=$errors===[];

        $compat=self::hostCompatibility($hostFacts);
        if (!$compat['compatible']) $errors=array_merge($errors,$compat['reasons']);
        $checks['host_compatibility']=$compat['compatible'];

        $providerRel=is_array($manifest)?str_replace('App\\Extensions\\TitanGovernance\\','',(string)($manifest['provider']??'')):'';
        $providerFile=rtrim($root,'/').'/'.str_replace('\\','/',$providerRel).'.php';
        $checks['provider_identity']=is_file($providerFile);
        if (!$checks['provider_identity']) $errors[]='Provider file does not match extension.json provider identity.';

        $checks['routes_and_views']=is_file($root.'/routes/user.php')&&is_file($root.'/routes/admin.php')&&is_file($root.'/resources/views/index.blade.php');
        if (!$checks['routes_and_views']) $errors[]='Required routes/views are missing.';
        $checks['config_publish']=is_file($root.'/config/titan-governance.php');
        if (!$checks['config_publish']) $errors[]='Governance config file is missing.';

        $hidden=[];$actual=[];
        if (is_dir($root)) {
            $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
            foreach ($it as $file) {
                if (!$file->isFile()) continue;
                $rel=str_replace('\\','/',substr($file->getPathname(),strlen(rtrim($root,'/'))+1));
                foreach (explode('/',$rel) as $segment) if (str_starts_with($segment,'.')) { $hidden[]=$rel; break; }
                if ($rel!=='extension.json') $actual[$rel]=hash_file('sha256',$file->getPathname());
            }
        }
        $checks['hidden_files_absent']=$hidden===[];
        if ($hidden!==[]) $errors[]='Hidden files are not permitted for Installer 1.7.6 integrity compatibility: '.implode(', ',$hidden);
        $declared=is_array($manifest)?($manifest['integrity']['files']??[]):[];
        $checks['installer_integrity']=is_array($declared)&&$declared==$actual;
        if (!$checks['installer_integrity']) $errors[]='Package integrity file list does not match visible archive contents.';

        $migrations=glob(rtrim($root,'/').'/database/migrations/*.php')?:[];
        $checks['migration_sequence']=count($migrations)===4;
        if (!$checks['migration_sequence']) $errors[]='Expected exactly four Governance migrations.';

        $migration004Path=rtrim($root,'/').'/database/migrations/2026_08_20_000004_add_governed_action_metadata.php';
        $migration004=is_file($migration004Path)?(string)file_get_contents($migration004Path):'';
        $namedIndexes=[];
        if ($migration004!=='' && preg_match_all("/(?:->index|->unique)\([^;]*?,\s*'([^']+)'\)/",$migration004,$matches)) $namedIndexes=$matches[1]??[];
        $checks['mysql_identifier_safety']=$migration004!==''
            && !str_contains($migration004,"authoritative_receipt_ref', 191)->nullable()->index()")
            && in_array('tgov_policy_auth_receipt_idx',$namedIndexes,true)
            && array_reduce($namedIndexes,fn(bool $safe,string $name):bool=>$safe&&strlen($name)<=64,true);
        if (!$checks['mysql_identifier_safety']) $errors[]='Governance migration 000004 contains an unsafe MySQL index identifier.';

        $checks['migration_000004_restartable']=$migration004!==''
            && str_contains($migration004,"Schema::hasIndex('titan_governance_policy_decisions',['authoritative_receipt_ref'])")
            && str_contains($migration004,"Schema::hasIndex('titan_governance_policy_decisions',['tenant_company_id','operation_id'],'unique')")
            && str_contains($migration004,'$policyColumns = array_values(array_filter(')
            && str_contains($migration004,'$escalationColumns = array_values(array_filter(');
        if (!$checks['migration_000004_restartable']) $errors[]='Governance migration 000004 is not restart-safe after partial MySQL DDL.';
        return [
            'status'=>$errors===[]?'PASS':'FAIL',
            'errors'=>array_values(array_unique($errors)),
            'checks'=>$checks,
            'migration_count'=>count($migrations),
            'host_compatibility'=>$compat,
        ];
    }
}
