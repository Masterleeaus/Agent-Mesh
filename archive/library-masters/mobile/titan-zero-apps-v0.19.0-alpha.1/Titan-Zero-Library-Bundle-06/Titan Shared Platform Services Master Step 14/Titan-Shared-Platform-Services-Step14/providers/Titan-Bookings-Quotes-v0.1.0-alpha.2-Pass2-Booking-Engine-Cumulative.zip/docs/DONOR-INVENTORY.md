# Donor inventory

| Donor | Reuse | Adapt | Retire/Do not own |
|---|---|---|---|
| BookingModule | booking lifecycle ideas, public/customer flows, reminders, recurrence concepts, lifecycle tests | booking records, request windows, availability requirements, Signals, API/UI patterns | schedules, assignments, dispatch board, staff capacity, tasks, payments |
| Quoting wizard | builder UX and guided scoping concepts | canonical quote draft/version builder | donor-local persistence assumptions |
| Quotes | quote numbering, acceptance/expiry concepts, price-list ideas | quote/version/line/acceptance domain | direct invoice creation, raw webhooks as authority |
| QuoteEngine | pricing/calculation concepts | deterministic money/pricing services | duplicate quote storage |
| FSMSales | commercial handoff concepts | invoice-request contract only | invoices, recurring invoices, accounting ownership |
| FSMServiceAgreement | service-term concepts | future booking/quote terms reference | agreement/order ownership in this extension |
| FSMSaleAgreement | sales agreement concepts | future accepted-quote terms adapter | duplicate sales authority |
| FSMSaleRecurring | recurrence concepts | future recurring booking/quote request | invoice/recurring sales ownership |
| FSMSaleRecurringAgreement | recurrence/agreement concepts | future typed terms adapter | duplicate recurring/accounting authority |
