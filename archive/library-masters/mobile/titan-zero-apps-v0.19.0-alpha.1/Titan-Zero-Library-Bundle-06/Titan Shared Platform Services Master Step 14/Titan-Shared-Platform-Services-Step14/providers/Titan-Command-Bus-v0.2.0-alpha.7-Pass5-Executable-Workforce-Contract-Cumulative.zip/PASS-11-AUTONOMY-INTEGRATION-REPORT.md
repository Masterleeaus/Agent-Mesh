# Titan Command Bus v0.2.0-alpha.4 — Pass 11 Autonomy Integration

## Purpose

Introduce Titan Autonomy as an explicit earned-authority gate between Assurance and Governance without duplicating Autonomy policy inside Command Bus.

## Runtime order

`Risk -> Assurance -> Autonomy -> Governance -> Domain Adapter -> Receipt -> Signal`

## Fail-closed outcomes

- `AUTONOMY_UNAVAILABLE`
- `AUTONOMY_DECISION_INVALID`
- `AUTONOMY_DENIED`

Autonomy decisions must carry a durable reference and non-empty level before consequential execution. The caller cannot request or elevate its own autonomy level.

## Evidence

Receipts persist autonomy reference, earned level, workflow key and supporting evidence references. Governance receives the exact AutonomyDecision before final authorization. Signal outcomes expose the same non-secret evidence identifiers.
