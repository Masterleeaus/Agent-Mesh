# Communications Consumer

Payroll is a consumer only. It prepares privacy-minimized delivery requests and calls a typed Titan Connect/Communications capability. It does not store provider credentials or call email/SMS providers directly.
