# Data ownership

People owns workers, departments, positions, teams, reporting lines, employment relationships and immutable employment events. It does not own attendance, shifts, expense claims, payroll bank accounts, credentials, recruitment, performance or onboarding orchestration.

## Pass 2 owned records

Titan People additionally owns `titan_people_worker_profiles`, `titan_people_emergency_contacts`, `titan_people_documents`, `titan_people_document_revisions`, `titan_people_leave_types`, `titan_people_leave_requests`, `titan_people_leave_ledger`, `titan_people_leave_balances` and `titan_people_holidays`. Every tenant-owned row carries `tenant_company_id`.

Document bytes are extension-owned under `private/titan-people/...`; paths are opaque storage references, not public URLs. The leave balance cache is derived state and is never authoritative over the ledger.

## Pass 4 operational metadata

Titan People additionally owns `titan_people_signal_outbox`. This table stores privacy-minimized People event facts and delivery metadata only; it is not a copy of peer-extension data or private People documents. `tenant_company_id` remains the mandatory row boundary.
