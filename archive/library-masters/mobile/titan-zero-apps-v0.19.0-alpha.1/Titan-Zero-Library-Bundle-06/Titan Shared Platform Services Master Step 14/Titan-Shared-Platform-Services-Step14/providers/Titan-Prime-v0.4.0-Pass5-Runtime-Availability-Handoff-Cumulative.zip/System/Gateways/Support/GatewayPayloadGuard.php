<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Support;

use InvalidArgumentException;

final class GatewayPayloadGuard
{
    /** @var list<string> */
    private const FORBIDDEN_KEYS = ['password', 'token', 'secret', 'authorization', 'signature'];

    /** @param array<string,mixed> $payload */
    public static function assertSafe(array $payload): void
    {
        self::scan($payload, 'payload');
    }

    /** @param array<mixed> $value */
    private static function scan(array $value, string $path): void
    {
        foreach ($value as $key => $item) {
            $keyName = is_string($key) ? strtolower(trim($key)) : null;
            if ($keyName !== null && in_array($keyName, self::FORBIDDEN_KEYS, true)) {
                throw new InvalidArgumentException(sprintf('Gateway payload contains forbidden field at %s.%s.', $path, $key));
            }
            if (is_array($item)) {
                self::scan($item, $path . '.' . (string) $key);
            }
        }
    }
}
