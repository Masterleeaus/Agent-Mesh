@extends('panel.layout.app')
@section('content')
@php($assistantScope = $scope ?? 'all')
@php($assistantSeed = $seed ?? '')
@component('crm::components.interaction-page-shell',[
    'title'=>'CRM Assistant',
    'subtitle'=>'Talk to Titan Zero about customers, leads, deals, quotes, invoices and CRM follow-up.',
    'surface'=>$assistantScope,
    'context'=>array_filter(['assistant_scope'=>$assistantScope,'seed'=>$assistantSeed])
])
<div data-crm-operations-assistant data-template-type="{{ $templateType }}" data-chat-type="crm-assistant" data-assistant-scope="{{ $assistantScope }}" data-assistant-seed="{{ $assistantSeed }}">
    <div class="d-flex flex-wrap gap-2 mb-4" data-crm-assistant-suggestions>
        @foreach([
            ['What needs my attention today?','all'],
            ['Show customers that need follow-up','customers'],
            ['Which invoices need attention?','money'],
            ['Show leads that need follow-up','leads'],
            ['Show CRM tasks due today','work'],
        ] as [$label,$suggestedScope])
            <a class="btn btn-outline-primary btn-sm" href="{{ route('dashboard.user.crm.ai.index',['scope'=>$suggestedScope,'seed'=>$label]) }}">{{ $label }}</a>
        @endforeach
    </div>

    @if($assistantSeed !== '')
        <div class="alert alert-info d-flex justify-content-between align-items-start gap-3" data-crm-assistant-seed>
            <div><strong>Suggested request</strong><div>{{ $assistantSeed }}</div></div>
            <span class="badge border text-body">{{ $assistantScope }}</span>
        </div>
    @endif

    <div class="card overflow-hidden" data-crm-assistant-chat-runtime>
        <div class="card-body p-0">
            @include('crm::assistant.includes.chat_area_container')
        </div>
    </div>
</div>
@endcomponent
@endsection
