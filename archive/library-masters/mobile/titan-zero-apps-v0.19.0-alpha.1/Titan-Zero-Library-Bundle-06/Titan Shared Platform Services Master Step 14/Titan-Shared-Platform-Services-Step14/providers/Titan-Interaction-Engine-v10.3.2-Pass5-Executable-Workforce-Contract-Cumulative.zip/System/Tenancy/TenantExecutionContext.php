<?php

declare(strict_types=1);

namespace App\Extensions\InteractionEngine\System\Tenancy;

/**
 * Trusted per-request/per-job company context.
 *
 * The Titan platform tenant boundary is company_id. Internally the engine may
 * continue to expose this value as tenant_id in legacy payloads, but the source
 * of truth is always a trusted company identity restored by the host boundary.
 */
final class TenantExecutionContext
{
    private ?string $companyId = null;

    public function __construct(?string $companyId = null)
    {
        if ($companyId !== null && trim($companyId) !== '') {
            $this->companyId = trim($companyId);
        }
    }

    public function restore(string $companyId): void
    {
        $companyId = trim($companyId);
        if ($companyId === '') {
            throw new \InvalidArgumentException('A non-empty company_id is required to restore tenant context.');
        }

        if ($this->companyId !== null && $this->companyId !== $companyId) {
            throw new \RuntimeException('Tenant execution context cannot be switched between companies inside one scope.');
        }

        $this->companyId = $companyId;
    }

    public function companyId(): string
    {
        if ($this->companyId === null || $this->companyId === '') {
            throw new \RuntimeException('Trusted company tenant context has not been restored.');
        }

        return $this->companyId;
    }

    public function tenantId(): string
    {
        return $this->companyId();
    }

    public function cacheKey(string $suffix): string
    {
        $suffix = ltrim(trim($suffix), ':');
        if ($suffix === '') {
            throw new \InvalidArgumentException('Tenant cache suffix cannot be empty.');
        }

        return 'interaction-engine:company:' . $this->companyId() . ':' . $suffix;
    }
}
