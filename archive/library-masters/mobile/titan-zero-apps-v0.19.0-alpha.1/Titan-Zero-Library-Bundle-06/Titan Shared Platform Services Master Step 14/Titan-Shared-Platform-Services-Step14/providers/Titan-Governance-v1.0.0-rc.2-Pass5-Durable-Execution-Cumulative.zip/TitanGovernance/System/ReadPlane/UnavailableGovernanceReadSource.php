<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ReadPlane;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceReadSourceContract;

final class UnavailableGovernanceReadSource implements GovernanceReadSourceContract
{
    public function __construct(
        private readonly string $sourceKey,
        private readonly bool $isRequired,
        private readonly string $status = 'UNAVAILABLE',
        private readonly ?string $reason = null,
    ) {}

    public function key(): string { return $this->sourceKey; }
    public function required(): bool { return $this->isRequired; }

    public function snapshot(int $tenantCompanyId, array $context = []): array
    {
        return [
            'schema_version' => '1.0',
            'source' => $this->sourceKey,
            'status' => $this->status,
            'required' => $this->isRequired,
            'tenant_company_id' => $tenantCompanyId,
            'observed_at' => null,
            'reason' => $this->reason,
        ];
    }
}
