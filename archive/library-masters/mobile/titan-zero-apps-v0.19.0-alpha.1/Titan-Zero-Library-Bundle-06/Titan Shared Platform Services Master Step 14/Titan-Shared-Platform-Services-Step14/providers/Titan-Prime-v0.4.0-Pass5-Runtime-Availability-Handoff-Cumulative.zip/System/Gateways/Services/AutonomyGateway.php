<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Services;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Contracts\AutonomyGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;

final class AutonomyGateway extends AbstractEngineGateway implements AutonomyGatewayContract
{
    public function engine(): EngineKey { return EngineKey::Autonomy; }

    public function authorize(TraceContext $trace, array $subject, string $operationId): EngineGatewayResult
    {
        return $this->dispatch($trace, 'autonomy.authorize', ['subject' => $subject], $operationId);
    }
}
