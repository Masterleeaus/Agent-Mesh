<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use App\Extensions\TitanRewind\System\Models\RewindCase;
use App\Extensions\TitanRewind\System\Models\RewindTraceEvent;
use App\Extensions\TitanRewind\System\Models\RewindLegalHold;
use Illuminate\Support\Str;
use App\Extensions\TitanRewind\System\Observability\RewindTraceContext;
use InvalidArgumentException;

final class RewindLegalHoldService
{
    public function __construct(private RewindCustodyService $custody, private RewindTelemetryService $telemetry, private RewindSignalOutboxService $signals) {}

    public function apply(int $tenantCompanyId, string $scopeType, string $scopeId, string $authority, string $reason, ?int $actorId = null, ?string $reviewAt = null, ?string $expiresAt = null): RewindLegalHold
    {
        if ($tenantCompanyId < 1) throw new InvalidArgumentException('tenant_company_id is required.');
        if (!in_array($scopeType,['trace','case','evidence-package','tenant-investigation'],true)) throw new InvalidArgumentException('Unsupported legal hold scope.');
        if (trim($scopeId)==='' || trim($authority)==='' || trim($reason)==='') throw new InvalidArgumentException('Legal hold scope, authority and reason are required.');
        $this->assertScopeExists($tenantCompanyId,$scopeType,$scopeId);
        $review = $reviewAt ? new \DateTimeImmutable($reviewAt) : null;
        $expires = $expiresAt ? new \DateTimeImmutable($expiresAt) : null;
        if ($expires && $expires <= new \DateTimeImmutable('now')) throw new InvalidArgumentException('Legal hold expiry must be in the future.');
        if ($review && $expires && $review > $expires) throw new InvalidArgumentException('Legal hold review date cannot be after expiry.');
        $existing = RewindLegalHold::query()->where('tenant_company_id',$tenantCompanyId)->where('scope_type',$scopeType)->where('scope_id',$scopeId)->where('status','active')->where(static function($q):void{$q->whereNull('expires_at')->orWhere('expires_at','>',now());})->first();
        if ($existing) return $existing;
        $hold = RewindLegalHold::query()->create([
            'hold_uuid'=>(string) Str::uuid(),'tenant_company_id'=>$tenantCompanyId,'scope_type'=>$scopeType,'scope_id'=>$scopeId,'status'=>'active',
            'authority'=>trim($authority),'reason'=>trim($reason),'applied_by_id'=>$actorId,'applied_at'=>now(),'review_at'=>$review?->format('Y-m-d H:i:s'),'expires_at'=>$expires?->format('Y-m-d H:i:s'),
        ]);
        if ($scopeType === 'evidence-package') {
            $package = RewindEvidencePackage::query()->where('tenant_company_id',$tenantCompanyId)->where('package_uuid',$scopeId)->first();
            if ($package) $this->custody->record($package,'legal_hold_applied',$actorId,$reason,['hold_uuid'=>$hold->hold_uuid,'authority'=>$authority]);
        }
        if ($traceId=$this->traceIdForScope($tenantCompanyId,$scopeType,$scopeId)) {
            $ctx=RewindTraceContext::fromArray(['tenant_company_id'=>$tenantCompanyId,'trace_id'=>$traceId,'correlation_id'=>$traceId,'causation_id'=>null]);
            $this->telemetry->metric('rewind.legal_hold.active',1,'count',$ctx,['scope_type'=>$scopeType]);
            $this->signals->emit('rewind.legal_hold.applied.v1',$ctx,['hold_uuid'=>$hold->hold_uuid,'scope_type'=>$scopeType,'scope_id'=>$scopeId,'authority'=>$authority]);
        }
        return $hold;
    }

    private function traceIdForScope(int $tenantCompanyId, string $scopeType, string $scopeId): ?string
    {
        return match ($scopeType) {
            'trace' => $scopeId,
            'case' => (($case=RewindCase::query()->where('tenant_company_id',$tenantCompanyId)->where('case_uuid',$scopeId)->first()) && $case->primary_trace_id) ? (string)$case->primary_trace_id : null,
            'evidence-package' => (($package=RewindEvidencePackage::query()->where('tenant_company_id',$tenantCompanyId)->where('package_uuid',$scopeId)->first()) && $package->trace_id) ? (string)$package->trace_id : null,
            default => null,
        };
    }

    private function assertScopeExists(int $tenantCompanyId, string $scopeType, string $scopeId): void
    {
        $exists = match ($scopeType) {
            'trace' => RewindTraceEvent::query()->where('tenant_company_id',$tenantCompanyId)->where('trace_id',$scopeId)->exists(),
            'case' => RewindCase::query()->where('tenant_company_id',$tenantCompanyId)->where('case_uuid',$scopeId)->exists(),
            'evidence-package' => RewindEvidencePackage::query()->where('tenant_company_id',$tenantCompanyId)->where('package_uuid',$scopeId)->exists(),
            'tenant-investigation' => $scopeId === 'tenant:'.$tenantCompanyId,
            default => false,
        };
        if (!$exists) throw new InvalidArgumentException('Legal hold scope does not exist inside the active tenant boundary.');
    }

    public function release(int $tenantCompanyId, string $holdUuid, string $reason, ?int $actorId = null): RewindLegalHold
    {
        if (trim($reason)==='') throw new InvalidArgumentException('Legal hold release reason is required.');
        $hold = RewindLegalHold::query()->where('tenant_company_id',$tenantCompanyId)->where('hold_uuid',$holdUuid)->firstOrFail();
        if ($hold->status !== 'active') return $hold;
        $hold->forceFill(['status'=>'released','released_by_id'=>$actorId,'released_at'=>now(),'release_reason'=>trim($reason)])->save();
        if ($hold->scope_type === 'evidence-package') {
            $package = RewindEvidencePackage::query()->where('tenant_company_id',$tenantCompanyId)->where('package_uuid',$hold->scope_id)->first();
            if ($package) $this->custody->record($package,'legal_hold_released',$actorId,$reason,['hold_uuid'=>$hold->hold_uuid]);
        }
        return $hold;
    }
}
