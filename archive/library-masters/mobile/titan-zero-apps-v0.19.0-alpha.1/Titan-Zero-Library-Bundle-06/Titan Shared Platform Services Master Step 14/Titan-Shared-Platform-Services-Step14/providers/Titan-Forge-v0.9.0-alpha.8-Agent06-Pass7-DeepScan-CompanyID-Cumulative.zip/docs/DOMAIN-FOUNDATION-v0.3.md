# Titan Forge v0.3 Domain Foundation

The Forge domain now separates immutable request/specification data from plans, generated artifacts, validation evidence and release candidates.

Primary value objects:

- BuildContext
- BuildRequest
- BuildSpec
- BuildStep / BuildPlan
- BuildArtifact / ArtifactSet
- GenerationResult
- ValidationFinding / ValidationResult
- ReleaseCandidate

Persistence is normalized into extension-owned `titan_forge_*` tables. The legacy `payload` column is retained only for backward compatibility and lightweight summary data; it is no longer intended to be the authoritative container for the Forge lifecycle.
