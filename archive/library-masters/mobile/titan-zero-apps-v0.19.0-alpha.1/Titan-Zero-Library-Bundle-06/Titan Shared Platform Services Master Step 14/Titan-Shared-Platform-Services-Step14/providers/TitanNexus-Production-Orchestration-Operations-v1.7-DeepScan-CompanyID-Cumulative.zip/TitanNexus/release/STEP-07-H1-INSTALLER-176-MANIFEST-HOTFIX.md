# Step 7 H1 — Installer 1.7.6 Manifest Compatibility Hotfix

Created: 2026-08-21T09:47:35+10:00

Live failure: `01M0GR9Z95Z34RZQBF1WMN8021` at stage `validating`.

Root cause: RC2 `extension.json` omitted the legacy MagicAI custom-extension `name` field (and companion legacy fields) while Nexus' internal manifest contract incorrectly classified `name` as unsupported.

Hotfix requirements:

- `name`: `Titan Nexus`
- `type`: `extension`
- non-empty `description`
- string `support_telegram` (empty is valid)
- preserve Titan `schema`, `slug`, `folder`, `provider`, `version`, and `integrity` fields
- accept observed PHP 8.3.33 / Laravel 10.50.2 / MySQL / Installer 1.7.6 host facts in package preflight
- retain Installer 1.7.8 compatibility
- do not mark live installer certification PASS until the H1 ZIP is retried on-host

## Blueprint compatibility note

The current Blueprint production root-manifest schema is explicitly titled `Titan Extension Manager 1.7.8 Root Manifest` and has `additionalProperties: false`; it therefore rejects the legacy `name`, `type`, `description`, and `support_telegram` keys required by the observed Installer 1.7.6 host. For this live-host hotfix, the runtime install contract takes precedence for `extension.json`; the canonical Titan v2.2 contract remains authoritative in `extension.manifest.json`. Interface, package-security, architecture, and MySQL Blueprint gates remain applicable and pass. The Blueprint root-manifest schema should be widened separately if one package must be formally canonical for both Installer 1.7.6 and 1.7.8.
