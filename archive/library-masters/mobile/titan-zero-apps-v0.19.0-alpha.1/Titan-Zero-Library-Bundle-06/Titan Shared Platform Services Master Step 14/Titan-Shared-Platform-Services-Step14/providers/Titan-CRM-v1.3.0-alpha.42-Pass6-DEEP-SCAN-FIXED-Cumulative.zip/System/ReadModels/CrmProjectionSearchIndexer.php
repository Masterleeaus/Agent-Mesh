<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\ReadModels;

use Illuminate\Database\ConnectionInterface;

/**
 * Disposable token index for the portable SQL search adapter.
 * It indexes projection payloads only and never reads or writes authoritative CRM tables.
 */
final class CrmProjectionSearchIndexer
{
    public function __construct(private readonly ConnectionInterface $db,private readonly CrmReadProjectionRegistry $registry) {}

    /** @param list<array<string,mixed>> $records */
    public function indexResources(int $companyId,array $definition,array $records): int
    {
        if(!$this->ready()||$records===[])return 0;
        $name=(string)$definition['projection_name'];$version=(string)$definition['projection_version'];
        $resourceIds=[];foreach($records as $record){$id=trim((string)($record['public_id']??''));if($id!=='')$resourceIds[]=$id;}
        $resourceIds=array_values(array_unique($resourceIds));if($resourceIds===[])return 0;
        foreach(array_chunk($resourceIds,500) as $ids)$this->db->table('crm_read_projection_search_terms')->where('company_id',$companyId)->where('projection_name',$name)->where('projection_version',$version)->whereIn('resource_public_id',$ids)->delete();
        $rows=[];$now=now();$inserted=0;
        foreach($records as $record){$resourceId=trim((string)($record['public_id']??''));if($resourceId==='')continue;foreach($this->termsForPayload($definition,$record) as $term=>$weight){$rows[]=['company_id'=>$companyId,'projection_name'=>$name,'projection_version'=>$version,'resource_public_id'=>$resourceId,'term'=>$term,'weight'=>$weight,'created_at'=>$now,'updated_at'=>$now];if(count($rows)>=500){$this->db->table('crm_read_projection_search_terms')->insertOrIgnore($rows);$inserted+=count($rows);$rows=[];}}}
        if($rows!==[]){$this->db->table('crm_read_projection_search_terms')->insertOrIgnore($rows);$inserted+=count($rows);}return $inserted;
    }

    /** @param list<array<string,mixed>> $records */
    public function replaceProjection(int $companyId,array $definition,array $records): int
    {
        if(!$this->ready())return 0;$this->db->table('crm_read_projection_search_terms')->where('company_id',$companyId)->where('projection_name',$definition['projection_name'])->where('projection_version',$definition['projection_version'])->delete();return $this->indexResources($companyId,$definition,$records);
    }

    public function deleteResource(int $companyId,string $projectionName,string $projectionVersion,string $resourcePublicId): void
    {if(!$this->ready())return;$this->db->table('crm_read_projection_search_terms')->where('company_id',$companyId)->where('projection_name',$projectionName)->where('projection_version',$projectionVersion)->where('resource_public_id',$resourcePublicId)->delete();}

    /** Reindex existing disposable projection rows after an upgrade without touching OLTP truth. */
    public function reindexExisting(int $companyId,?string $projectionName=null,int $batchSize=500): array
    {
        if(!$this->ready())return ['indexed'=>0,'resources'=>0,'reason'=>'search_term_table_unavailable'];$batchSize=max(25,min(2000,$batchSize));$names=$projectionName!==null&&trim($projectionName)!==''?[strtolower(trim($projectionName))]:$this->registry->searchableNames();$indexed=0;$resources=0;
        foreach($names as $name){$definition=$this->registry->resolve($name);if((array)($definition['search_fields']??[])===[])continue;$this->db->table('crm_read_projection_search_terms')->where('company_id',$companyId)->where('projection_name',$name)->where('projection_version',$definition['projection_version'])->delete();$cursor=0;do{$rows=$this->db->table('crm_read_projection_records')->where('company_id',$companyId)->where('projection_name',$name)->where('projection_version',$definition['projection_version'])->where('id','>',$cursor)->orderBy('id')->limit($batchSize)->get(['id','resource_public_id','payload']);$batch=[];foreach($rows as $row){$cursor=max($cursor,(int)$row->id);$payload=$this->decode($row->payload??null);$payload['public_id']=$payload['public_id']??(string)$row->resource_public_id;$batch[]=$payload;}$resources+=count($batch);$indexed+=$this->indexResources($companyId,$definition,$batch);}while(count($rows)===$batchSize);}
        return ['company_id'=>$companyId,'indexed'=>$indexed,'resources'=>$resources,'projection_count'=>count($names)];
    }

    /** @return list<string> */
    public function tokenize(string $value): array
    {
        $value=mb_strtolower(trim($value));if($value==='')return [];$parts=preg_split('/[^\p{L}\p{N}@._+\-]+/u',$value,-1,PREG_SPLIT_NO_EMPTY)?:[];$terms=[];
        foreach($parts as $part){$part=mb_substr(trim((string)$part),0,96);if(mb_strlen($part)<2)continue;$terms[$part]=true;if(str_contains($part,'@')){foreach(preg_split('/[@.]+/',$part,-1,PREG_SPLIT_NO_EMPTY)?:[] as $piece)if(mb_strlen($piece)>=2)$terms[mb_substr($piece,0,96)]=true;}}
        return array_slice(array_keys($terms),0,max(4,min(64,(int)config('crm.performance.search_terms_per_resource',24))));
    }

    /** @return array<string,int> */
    private function termsForPayload(array $definition,array $payload): array
    {
        $out=[];$fields=array_values((array)($definition['search_fields']??[]));$fieldCount=max(1,count($fields));foreach($fields as $i=>$field){$value=$payload[(string)$field]??null;if(!is_scalar($value))continue;$weight=max(1,$fieldCount-$i);foreach($this->tokenize((string)$value) as $term)$out[$term]=max($out[$term]??0,$weight);}return $out;
    }
    private function ready(): bool{try{return $this->db->getSchemaBuilder()->hasTable('crm_read_projection_search_terms');}catch(\Throwable){return false;}}
    private function decode(mixed $payload): array{if(is_array($payload))return $payload;if(!is_string($payload)||$payload==='')return [];$decoded=json_decode($payload,true);return is_array($decoded)?$decoded:[];}
}
