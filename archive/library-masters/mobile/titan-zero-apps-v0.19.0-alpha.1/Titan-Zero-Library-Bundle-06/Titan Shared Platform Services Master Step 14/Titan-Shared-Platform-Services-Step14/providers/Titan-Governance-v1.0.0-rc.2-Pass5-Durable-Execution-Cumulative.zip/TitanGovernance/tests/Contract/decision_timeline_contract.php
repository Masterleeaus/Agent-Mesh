<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function fail_dt(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function ok_dt(bool $c,string $m):void{if(!$c)fail_dt($m);}function same_dt(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_dt($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
foreach([
 '/System/Contracts/GovernanceDecisionReadStoreContract.php','/System/Contracts/GovernanceDecisionEvidenceSourceContract.php',
 '/System/DecisionIntelligence/GovernanceDecisionEvidenceRegistry.php','/System/DecisionIntelligence/GovernanceEvidenceSanitizer.php','/System/DecisionIntelligence/GovernanceDecisionIntelligence.php',
] as $f){if(!is_file($root.$f))fail_dt('missing production file '.$f);require_once $root.$f;}
use App\Extensions\TitanGovernance\System\Contracts\GovernanceDecisionReadStoreContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceDecisionEvidenceSourceContract;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceDecisionEvidenceRegistry;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceDecisionIntelligence;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceEvidenceSanitizer;

final class DTStore implements GovernanceDecisionReadStoreContract{
 public function find(int $tenantCompanyId,string $decisionId):?array{return $tenantCompanyId===42&&$decisionId==='gdec-1'?['decision_id'=>'gdec-1','tenant_company_id'=>42,'policy_key'=>'gov.escalation','policy_version'=>'1.0','action'=>'APPROVE','disposition'=>'APPROVE','reason_codes'=>['HUMAN_APPROVED'],'evidence_refs'=>['ev-local'],'actor_id'=>'7','trace_id'=>'tr-1','correlation_id'=>'co-1','causation_id'=>'ca-1','root_causation_id'=>'root-1','subject_type'=>'governance_escalation','subject_id'=>'esc-1','operation_id'=>'op-1','command_status'=>'APPLIED','command_receipt_ref'=>'cmd-1','authoritative_receipt_ref'=>'crm-1','write_verified'=>true,'decided_at'=>'2026-08-20T10:02:00+10:00','result_payload'=>['reason_code'=>'OK']]:null;}
 public function recent(int $tenantCompanyId,int $limit=50):array{return $tenantCompanyId===42?[$this->find(42,'gdec-1')]:[];}
}
final class DTSource implements GovernanceDecisionEvidenceSourceContract{
 public function __construct(private string $k,private array $payload,private bool $req=false){} public function key():string{return $this->k;} public function required():bool{return $this->req;}
 public function decisionEvidence(int $tenantCompanyId,string $decisionId,array $context=[]):array{return $this->payload;}
}
$r=new GovernanceDecisionEvidenceRegistry();
$r->register(new DTSource('titan-risk',['status'=>'HEALTHY','tenant_company_id'=>42,'decision_id'=>'gdec-1','events'=>[['event_type'=>'risk.decision.observed','occurred_at'=>'2026-08-20T10:00:00+10:00','reference'=>'risk-1','reason_codes'=>['LOW_RISK'],'chain_of_thought'=>'strip-me']]]));
$r->register(new DTSource('titan-assurance',['status'=>'HEALTHY','tenant_company_id'=>42,'decision_id'=>'gdec-1','events'=>[['event_type'=>'assurance.finding.observed','occurred_at'=>'2026-08-20T10:01:00+10:00','reference'=>'assure-1']]]));
$r->register(new DTSource('bad-source',['status'=>'HEALTHY','tenant_company_id'=>999,'decision_id'=>'gdec-1','events'=>[['event_type'=>'bad.event','occurred_at'=>'2026-08-20T09:00:00+10:00']]]));
$svc=new GovernanceDecisionIntelligence(new DTStore(),$r,new GovernanceEvidenceSanitizer());
$out=$svc->inspect(42,'gdec-1');same_dt('HEALTHY',$out['status'],'decision inspection status');same_dt('gdec-1',$out['decision']['decision_id'],'local decision anchor');
same_dt('INVALID',$out['sources']['bad-source']['status'],'source tenant mismatch must be invalid');same_dt('IDENTITY_MISMATCH',$out['sources']['bad-source']['reason'],'identity mismatch reason');
$types=array_column($out['timeline'],'event_type');same_dt(['risk.decision.observed','assurance.finding.observed','governance.decision.recorded'],$types,'timeline must be chronological and include local immutable decision');
ok_dt(!isset($out['timeline'][0]['chain_of_thought']),'hidden reasoning must be stripped');
$missing=$svc->inspect(99,'gdec-1');same_dt('NOT_FOUND',$missing['status'],'cross-tenant decision lookup must fail closed');same_dt([],$missing['timeline'],'missing decision cannot query/fabricate timeline');

echo "PASS: Governance decision timeline\n";
