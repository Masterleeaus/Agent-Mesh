# Titan CRM Core Installation / Upgrade Order — alpha.29

1. Install or upgrade **Titan CRM Core v1.3.0-alpha.29**.
2. Install the domain extensions required by the deployment: **Titan Field**, **Titan Locker**, **Titan Ledger**, and/or **Titan Pay**. CRM Core can boot without them, but legacy external-domain capability calls will fail with an actionable dependency response until their owner is installed.
3. Install/bind platform engines required by production policy, especially Titan Command Bus and Titan Signal.
4. Clear/rebuild Laravel route/config caches if the host installer does not already do so.
5. Run `php bin/verify.php` on the installed package and `php artisan crm:production-check` on the target host.

For existing installations, historical `crm_*` tables owned by extracted engines are preserved. CRM Core alpha.29 does not recreate those tables on a fresh install and must not become a second writer.
