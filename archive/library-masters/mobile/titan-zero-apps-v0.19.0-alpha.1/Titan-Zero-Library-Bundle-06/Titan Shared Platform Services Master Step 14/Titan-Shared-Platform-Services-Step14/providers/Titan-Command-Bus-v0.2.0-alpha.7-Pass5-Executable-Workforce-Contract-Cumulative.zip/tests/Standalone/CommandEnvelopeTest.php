<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
require_once $root.'/System/DTO/CommandContext.php';
require_once $root.'/System/DTO/CommandRequest.php';
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
$ctx=new CommandContext(42,'human',7,'titan-command');
$req=new CommandRequest('crm.invoice.create',['amount'=>1000],'idem-1','trace','corr','cause','root',12,false);
if ($ctx->companyId!==42) throw new RuntimeException('canonical company context failed');
if ($ctx->tenantCompanyId!==42) throw new RuntimeException('legacy tenant alias compatibility failed');
if (($ctx->toAuditArray()['company_id']??null)!==42) throw new RuntimeException('audit context must expose company_id');
if (array_key_exists('tenant_company_id',$ctx->toAuditArray())) throw new RuntimeException('audit context must not expose legacy tenant key');
if ($req->capability!=='crm.invoice.create') throw new RuntimeException('capability failed');
if ($req->requestHash()==='') throw new RuntimeException('request hash missing');
if (array_key_exists('tenant_company_id',$req->toArray())) throw new RuntimeException('untrusted request must not carry tenant');
$badCapability=false;
try { new CommandRequest('CRM invoice create', [], 'idem', 't', 'c', 'x', 'r'); } catch (InvalidArgumentException) { $badCapability=true; }
if (!$badCapability) throw new RuntimeException('invalid capability key must be rejected');
$longIdem=false;
try { new CommandRequest('crm.invoice.create', [], str_repeat('x',192), 't', 'c', 'x', 'r'); } catch (InvalidArgumentException) { $longIdem=true; }
if (!$longIdem) throw new RuntimeException('oversize idempotency key must be rejected');
echo "PASS CommandEnvelopeTest\n";
