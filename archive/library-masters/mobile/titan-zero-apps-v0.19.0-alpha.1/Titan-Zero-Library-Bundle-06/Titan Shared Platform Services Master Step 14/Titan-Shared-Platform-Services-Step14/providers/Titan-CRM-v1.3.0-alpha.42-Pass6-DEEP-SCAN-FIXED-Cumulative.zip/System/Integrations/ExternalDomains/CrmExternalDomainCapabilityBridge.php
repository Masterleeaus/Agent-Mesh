<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\ExternalDomains;

use App\Extensions\Crm\System\Capabilities\CrmCapabilityOwnershipMap;
use DomainException;
use Illuminate\Contracts\Container\Container;
use Illuminate\Database\ConnectionInterface;
use App\Extensions\Crm\System\Tenancy\CrmCompanyContext;

final class CrmExternalDomainCapabilityBridge
{
    public function __construct(private Container $app, private ConnectionInterface $db, private CrmCapabilityOwnershipMap $ownership) {}

    public function handles(string $capability): bool { return $this->ownership->isExternal($capability); }
    public function available(string $owner): bool { $provider=$this->ownership->providerClass($owner); return $provider!==null && class_exists($provider); }
    public function availableForCapability(string $capability): bool { return $this->available($this->ownership->owner($capability)); }

    /** @return array<string,mixed> */
    public function execute(string $capability, int $actor, array $input): array
    {
        $owner=$this->ownership->owner($capability);
        $provider=$this->ownership->providerClass($owner);
        if ($provider===null || !class_exists($provider)) {
            throw new DomainException("{$capability} is owned by {$owner}; install/enable {$owner} to execute this compatibility capability.");
        }
        return match($owner){
            'titan-field'=>$this->field($capability,$actor,$input),
            'titan-locker'=>$this->locker($capability,$actor,$input),
            'titan-ledger'=>$this->ledger($capability,$actor,$input),
            'titan-pay'=>$this->pay($capability,$actor,$input),
            default=>throw new DomainException("Unsupported external CRM capability owner: {$owner}"),
        };
    }

    private function make(string $class): object
    {
        if(!class_exists($class)) throw new DomainException("Required extracted Titan domain service is unavailable: {$class}");
        return $this->app->make($class);
    }
    private function id(array $i,string $key='public_id'): string { $v=trim((string)($i[$key]??$i['public_id']??$i['id']??$i['resource_id']??'')); if($v==='')throw new \InvalidArgumentException("{$key} is required."); return $v; }
    private function tenant(): int { return (int)$this->app->make(CrmCompanyContext::class)->companyId; }
    private function assertReadableTable(string $table,bool $requiresPublicId=false): void
    {
        $schema=$this->db->getSchemaBuilder();
        if(!$schema->hasTable($table)||!$schema->hasColumn($table,'company_id')||($requiresPublicId&&!$schema->hasColumn($table,'public_id'))){
            throw new DomainException("External owner table {$table} is unavailable through the CRM compatibility bridge; use the owning extension's native capability surface.");
        }
    }
    private function list(string $table,array $i,string $order='created_at'): array
    {
        $this->assertReadableTable($table);
        $q=$this->db->table($table)->where('company_id',$this->tenant());
        $schema=$this->db->getSchemaBuilder();
        if($schema->hasColumn($table,'deleted_at'))$q->whereNull('deleted_at');
        $filters=(array)($i['filters']??$i);
        foreach($filters as $key=>$value){
            if(in_array((string)$key,['limit','offset','page','active_only'],true)||$value===null||is_array($value)||is_object($value))continue;
            if($key==='active_only'&&$schema->hasColumn($table,'is_active')){$q->where('is_active',(bool)$value);continue;}
            if($schema->hasColumn($table,(string)$key))$q->where((string)$key,$value);
        }
        if($schema->hasColumn($table,$order))$q->orderByDesc($order);
        return $q->limit(max(1,min(200,(int)($i['limit']??100))))->get()->map(fn($r)=>(array)$r)->all();
    }
    private function read(string $table,string $id): array { $this->assertReadableTable($table,true); $q=$this->db->table($table)->where('company_id',$this->tenant())->where('public_id',$id); if($this->db->getSchemaBuilder()->hasColumn($table,'deleted_at'))$q->whereNull('deleted_at'); $r=$q->first(); if(!$r)throw new \InvalidArgumentException('External CRM domain record not found.'); return (array)$r; }

    private function field(string $c,int $actor,array $i): array
    {
        $ns='App\\Extensions\\TitanField\\System\\Domains\\FieldServices\\';
        return match($c){
            'crm.service.search'=>$this->make($ns.'Catalogue\\ServiceCatalogueService')->list($actor,(bool)($i['active_only']??true)),
            'crm.service.read'=>$this->make($ns.'Catalogue\\ServiceCatalogueService')->find($actor,$this->id($i))??[],
            'crm.service.create'=>$this->make($ns.'Catalogue\\ServiceCatalogueService')->createService($actor,$i),
            'crm.service.update'=>$this->make($ns.'Catalogue\\ServiceCatalogueService')->updateService($actor,$this->id($i),$i),
            'crm.service_request.search'=>$this->make($ns.'Requests\\ServiceRequestService')->search($actor,(array)($i['filters']??$i),(int)($i['limit']??100)),
            'crm.service_request.read'=>$this->read('crm_service_requests',$this->id($i)),
            'crm.service_request.create'=>$this->make($ns.'Requests\\ServiceRequestService')->create($actor,$actor,$i+['source'=>$i['source']??'api']),
            'crm.work_order.search'=>$this->make($ns.'WorkOrders\\WorkOrderService')->search($actor,(array)($i['filters']??$i),(int)($i['limit']??100)),
            'crm.work_order.read'=>$this->make($ns.'WorkOrders\\WorkOrderService')->detail($actor,$this->id($i)),
            'crm.work_order.assign'=>$this->make($ns.'Dispatch\\DispatchService')->assign($actor,$actor,$this->id($i),(int)($i['worker_user_id']??0),$i),
            'crm.work_order.reschedule'=>$this->make($ns.'Scheduling\\AppointmentService')->schedule($actor,$i+['work_order_public_id'=>$this->id($i)]),
            'crm.work_order.cancel'=>$this->make($ns.'WorkOrders\\WorkOrderService')->transition($actor,$actor,$this->id($i),'cancelled',(string)($i['reason']??'Cancelled')),
            'crm.work_order.start'=>$this->make($ns.'WorkOrders\\WorkOrderService')->transition($actor,$actor,$this->id($i,'work_order_public_id'),'in_progress',(string)($i['reason']??'Started')),
            'crm.work_order.pause'=>$this->make($ns.'WorkOrders\\WorkOrderService')->transition($actor,$actor,$this->id($i,'work_order_public_id'),'paused',(string)($i['reason']??'Paused')),
            'crm.work_order.resume'=>$this->make($ns.'WorkOrders\\WorkOrderService')->transition($actor,$actor,$this->id($i,'work_order_public_id'),'in_progress',(string)($i['reason']??'Resumed')),
            'crm.work_order.complete'=>$this->make($ns.'WorkOrders\\WorkOrderService')->transition($actor,$actor,$this->id($i,'work_order_public_id'),'completed',(string)($i['reason']??'Completed'),$i),
            'crm.work_order.status.change'=>$this->make($ns.'WorkOrders\\WorkOrderService')->transition($actor,$actor,$this->id($i,'work_order_public_id'),(string)($i['status']??''),(string)($i['reason']??'Status changed')),
            'crm.work_order.material.record'=>$this->make($ns.'WorkOrders\\WorkOrderService')->addMaterial($actor,$this->id($i,'work_order_public_id'),$i),
            'crm.work_order.evidence.record'=>$this->make($ns.'Evidence\\FieldEvidenceService')->recordReference($actor,$actor,$this->id($i,'work_order_public_id'),$i),
            'crm.work_order.note.add'=>$this->make($ns.'WorkOrders\\WorkOrderService')->addNote($actor,$this->id($i,'work_order_public_id'),(string)($i['body']??$i['note']??''),$actor,$i['fingerprint']??null),
            'crm.appointment.search'=>$this->make($ns.'Scheduling\\AppointmentService')->search($actor,(array)($i['filters']??$i),(int)($i['limit']??100)),
            'crm.appointment.create'=>$this->make($ns.'Scheduling\\AppointmentService')->schedule($actor,$i),
            'crm.dispatch.read'=>$this->make($ns.'Dispatch\\DispatchService')->board($actor,$i['date']??null),
            'crm.location.search'=>$this->list('crm_service_locations',$i,'name'),
            'crm.location.read'=>$this->read('crm_service_locations',$this->id($i)),
            'crm.location.create'=>$this->make($ns.'Locations\\ServiceLocationService')->create($actor,$i),
            'crm.asset.search'=>$this->list('crm_customer_assets',$i),
            'crm.asset.read'=>$this->read('crm_customer_assets',$this->id($i)),
            'crm.asset.create'=>$this->make($ns.'Assets\\CustomerAssetService')->create($actor,$i),
            'crm.time.search'=>$this->list('crm_work_order_time_entries',$i,'started_at'),
            'crm.material.search'=>$this->list('crm_work_order_materials',$i),
            'crm.form.search'=>$this->list('crm_form_templates',$i,'name'),
            'crm.form.read'=>$this->read('crm_form_templates',$this->id($i)),
            'crm.form.create'=>$this->make($ns.'Forms\\FormService')->createTemplate($actor,$i),
            'crm.form_submission.search'=>$this->list('crm_form_submissions',$i),
            'crm.form_submission.read'=>$this->read('crm_form_submissions',$this->id($i)),
            'crm.form_submission.submit'=>$this->make($ns.'Forms\\FormService')->submit($actor,$this->id($i,'submission_public_id'),$actor),
            'crm.form_response.update'=>$this->make($ns.'Forms\\FormService')->saveResponse($actor,(string)($i['submission_public_id']??''),(string)($i['field_public_id']??''),$i['value']??null,(bool)($i['failed']??false),$i['failure_notes']??null),
            'crm.evidence.search'=>$this->list('crm_field_evidence',$i),
            'crm.evidence.read'=>$this->read('crm_field_evidence',$this->id($i)),
            'crm.review.search'=>$this->list('crm_reviews',$i),
            'crm.review.read'=>$this->read('crm_reviews',$this->id($i)),
            'crm.review.create'=>$this->make($ns.'Reviews\\ReviewRecoveryService')->recordReview($actor,$i),
            'crm.recurring.search'=>$this->list('crm_service_agreements',$i),
            'crm.recurring.read'=>$this->read('crm_service_agreements',$this->id($i)),
            'crm.recurring.create'=>$this->make($ns.'Recurring\\RecurringServiceEngine')->createAgreement($actor,$i),
            'crm.service_area.create'=>$this->make($ns.'ServiceAreas\ServiceAreaMatcher')->create($actor,$i),
            'crm.service_area.update'=>$this->make($ns.'ServiceAreas\ServiceAreaMatcher')->update($actor,$this->id($i),$i),
            'crm.service_area.check'=>$this->make($ns.'ServiceAreas\\ServiceAreaMatcher')->match($actor, $i['postcode'] ?? null, isset($i['latitude']) ? (float) $i['latitude'] : null, isset($i['longitude']) ? (float) $i['longitude'] : null, $i['service_public_id'] ?? null),
            'crm.support.create'=>$this->make($ns.'Support\\SupportService')->create($actor,$i),
            default=>throw new DomainException("Titan Field compatibility mapping is not available for {$c}; use Titan Field's native capability surface."),
        };
    }

    private function ledger(string $c,int $actor,array $i): array
    {
        $ns='App\\Extensions\\TitanLedger\\System\\Domains\\Bookkeeping\\';
        return match($c){
            'crm.bookkeeping.overview.read'=>$this->make($ns.'BookkeepingReportService')->overview($actor,$i['from']??null,$i['to']??null),
            'crm.bookkeeping.transactions.search'=>$this->make($ns.'BookkeepingTransactionService')->search($actor,(array)($i['filters']??$i),(int)($i['limit']??200)),
            'crm.bookkeeping.transaction.create'=>$this->make($ns.'BookkeepingTransactionService')->create($actor,$i),
            'crm.bookkeeping.category.search'=>$this->make($ns.'BookkeepingCategoryService')->all($actor,isset($i['type'])?(string)$i['type']:null),
            'crm.bookkeeping.category.create'=>$this->make($ns.'BookkeepingCategoryService')->create($actor,$i),
            'crm.bookkeeping.pnl.read'=>$this->make($ns.'BookkeepingReportService')->profitAndLoss($actor,$i['from']??null,$i['to']??null),
            default=>throw new DomainException("Titan Ledger compatibility mapping is not available for {$c}."),
        };
    }

    private function pay(string $c,int $actor,array $i): array
    {
        $ns='App\\Extensions\\TitanPay\\System\\Domains\\Pay\\';
        return match($c){
            'crm.payment.status','crm.payment.record','crm.payment.reconcile'=>throw new DomainException('Legacy crm.payment.* is owned by Titan Pay; use Titan Pay native capabilities and report verified outcomes back through crm.invoice.settlement.record_verified.'),
            'crm.pay.preferences.read'=>$this->make($ns.'PaymentPreferenceService')->all($actor),
            'crm.pay.preference.update'=>$this->make($ns.'PaymentPreferenceService')->update($actor,$this->id($i,'rail_key'),$i),
            'crm.pay.receivables.read'=>$this->make($ns.'ReceivablesService')->aging($actor,$i['as_of']??null),
            'crm.pay.intent.create'=>$this->make($ns.'PaymentIntentService')->createForInvoice($actor,$this->id($i,'invoice_public_id'),$i),
            'crm.pay.collection.search'=>$this->make($ns.'CollectionService')->cases($actor,(array)($i['filters']??$i)),
            'crm.pay.collection.open'=>$this->make($ns.'CollectionService')->openForInvoice($actor,$this->id($i,'invoice_public_id'),$i),
            'crm.pay.collection.event'=>$this->make($ns.'CollectionService')->event($actor,$this->id($i,'collection_case_public_id'),$this->id($i,'event_type'),$i),
            'crm.pay.job_invoice.prepare'=>$this->make($ns.'JobBillingService')->draftForJob($actor,$this->id($i,'work_order_public_id'),$i),
            'crm.pay.reconciliation.rank'=>$this->make($ns.'PayIntelligenceService')->rankBankDeposit($i),
            'crm.pay.collection.suppression.evaluate'=>$this->make($ns.'PayIntelligenceService')->evaluateSuppression($actor,$i),
            'crm.pay.job_profitability.calculate'=>$this->make($ns.'PayIntelligenceService')->jobProfitability($actor,$this->id($i,'work_order_public_id'),$i),
            default=>throw new DomainException("Titan Pay compatibility mapping is not available for {$c}."),
        };
    }

    private function locker(string $c,int $actor,array $i): array
    {
        // Locker has the widest legacy compatibility surface. Reads are safely delegated through
        // tenant-scoped tables; mutations require Titan Locker's native service API.
        if(str_ends_with($c,'.search')||str_ends_with($c,'.read')){
            $table=match(true){
                str_contains($c,'inventory')=>'crm_inventory_items',str_contains($c,'location')=>'crm_stock_locations',str_contains($c,'asset')=>'crm_assets',
                str_contains($c,'supplier')=>'crm_suppliers',str_contains($c,'purchase_order')=>'crm_purchase_orders',str_contains($c,'goods_receipt')=>'crm_goods_receipts',
                str_contains($c,'stock_count')=>'crm_stock_counts',str_contains($c,'stock_transfer')=>'crm_stock_transfers',str_contains($c,'maintenance')=>'crm_maintenance_events',
                default=>'',
            };
            if($table!=='') return str_ends_with($c,'.read')&&isset($i['public_id'])?$this->read($table,$this->id($i)):$this->list($table,$i);
        }
        throw new DomainException("{$c} is owned by titan-locker. Use Titan Locker's native governed capability surface for mutations.");
    }
}
