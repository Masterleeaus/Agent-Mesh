<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanAICore\System\Console\DiagnoseCommand;
use App\Extensions\TitanAICore\System\Console\HostSyncCommand;
use App\Extensions\TitanAICore\System\Commands\CertifyExtensionCommand;
use App\Extensions\TitanAICore\System\Contracts\AssuranceGatewayContract;
use App\Extensions\TitanAICore\System\Contracts\AutonomyGatewayContract;
use App\Extensions\TitanAICore\System\Contracts\CommandBusGatewayContract;
use App\Extensions\TitanAICore\System\Contracts\GovernancePreflightContract;
use App\Extensions\TitanAICore\System\Contracts\RiskGatewayContract;
use App\Extensions\TitanAICore\System\Contracts\HealthCheckContract;
use App\Extensions\TitanAICore\System\Contracts\HostLayoutResolverContract;
use App\Extensions\TitanAICore\System\Contracts\OrchestratorContract;
use App\Extensions\TitanAICore\System\Contracts\PlanValidatorContract;
use App\Extensions\TitanAICore\System\Contracts\RuntimeManagerContract;
use App\Extensions\TitanAICore\System\Contracts\ModelProfileRepositoryContract;
use App\Extensions\TitanAICore\System\Contracts\PlanRepositoryContract;
use App\Extensions\TitanAICore\System\Contracts\TrustedPrincipalResolverContract;
use App\Extensions\TitanAICore\System\Integrations\CommandBus\UnavailableCommandBusGateway;
use App\Extensions\TitanAICore\System\Integrations\Governance\UnavailableAssuranceGateway;
use App\Extensions\TitanAICore\System\Integrations\Governance\UnavailableAutonomyGateway;
use App\Extensions\TitanAICore\System\Integrations\Governance\UnavailableRiskGateway;
use App\Extensions\TitanAICore\System\Navigation\HostNavigationRegistrar;
use App\Extensions\TitanAICore\System\Http\Middleware\RequireCoreCapability;
use App\Extensions\TitanAICore\System\Http\Middleware\ResolveTrustedCoreContext;
use App\Extensions\TitanAICore\System\Repositories\DatabaseModelProfileRepository;
use App\Extensions\TitanAICore\System\Repositories\DatabasePlanRepository;
use App\Extensions\TitanAICore\System\Security\CapabilityAuthorizer;
use App\Extensions\TitanAICore\System\Security\HostTrustedPrincipalResolver;
use App\Extensions\TitanAICore\System\Security\TenantRuntimeGuard;
use App\Extensions\TitanAICore\System\Services\CommandBusMutationBoundary;
use App\Extensions\TitanAICore\System\Services\GovernancePreflightCoordinator;
use App\Extensions\TitanAICore\System\Services\HealthCheck;
use App\Extensions\TitanAICore\System\Services\HostLayoutResolver;
use App\Extensions\TitanAICore\System\Services\HostMenuLifecycle;
use App\Extensions\TitanAICore\System\Services\Orchestrator;
use App\Extensions\TitanAICore\System\Services\PlanValidator;
use App\Extensions\TitanAICore\System\Services\RuntimeManager;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

final class TitanAICoreServiceProvider extends ServiceProvider implements
    ExtensionRegisterKeyProviderInterface,
    UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-ai-core.php', 'titan-ai-core');

        $this->app->singleton(RuntimeManagerContract::class, RuntimeManager::class);
        $this->app->singleton(OrchestratorContract::class, Orchestrator::class);
        $this->app->singleton(PlanValidatorContract::class, PlanValidator::class);
        $this->app->singleton(HostLayoutResolverContract::class, HostLayoutResolver::class);
        $this->app->singleton(HealthCheckContract::class, HealthCheck::class);
        $this->app->singleton(HostNavigationRegistrar::class);
        $this->app->singleton(HostMenuLifecycle::class);
        $this->app->singleton(TenantRuntimeGuard::class);
        $this->app->singleton(CapabilityAuthorizer::class);
        $this->app->singleton(TrustedPrincipalResolverContract::class, HostTrustedPrincipalResolver::class);
        $this->app->singleton(PlanRepositoryContract::class, DatabasePlanRepository::class);
        $this->app->singleton(ModelProfileRepositoryContract::class, DatabaseModelProfileRepository::class);
        $this->app->singleton(RiskGatewayContract::class, UnavailableRiskGateway::class);
        $this->app->singleton(AssuranceGatewayContract::class, UnavailableAssuranceGateway::class);
        $this->app->singleton(AutonomyGatewayContract::class, UnavailableAutonomyGateway::class);
        $this->app->singleton(CommandBusGatewayContract::class, UnavailableCommandBusGateway::class);
        $this->app->singleton(GovernancePreflightContract::class, GovernancePreflightCoordinator::class);
        $this->app->singleton(CommandBusMutationBoundary::class, static function ($app): CommandBusMutationBoundary {
            return new CommandBusMutationBoundary(
                $app->make(CommandBusGatewayContract::class),
                (bool) config('titan-ai-core.execution.execution_enabled', false),
            );
        });
    }

    public function boot(Kernel $kernel): void
    {
        $this->loadTranslationsFrom(__DIR__ . '/../resources/lang', 'titan-ai-core');
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-ai-core');
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');

        $this->publishes([
            __DIR__ . '/../config/titan-ai-core.php' => config_path('titan-ai-core.php'),
        ], 'extension');

        if ($this->app->runningInConsole()) {
            $this->commands([
                DiagnoseCommand::class,
                HostSyncCommand::class,
                CertifyExtensionCommand::class,
            ]);
        }

        if (! (bool) config('titan-ai-core.enabled', true)) {
            return;
        }

        $this->registerRoutes();
        $this->app->make(HostNavigationRegistrar::class)->registerAll();
    }

    public function registerKey(): string
    {
        return 'titan-ai-core';
    }

    public static function uninstall(): void
    {
        // Intentionally retain extension-owned database data by default.
        File::delete(config_path('titan-ai-core.php'));
    }

    private function registerRoutes(): void
    {
        /** @var Router $router */
        $router = $this->app['router'];

        $router->aliasMiddleware('titan-ai-core.context', ResolveTrustedCoreContext::class);
        $router->aliasMiddleware('titan-ai-core.capability', RequireCoreCapability::class);

        $router->group([
            'middleware' => ['web', 'auth', 'titan-ai-core.context'],
            'prefix' => 'dashboard/user/titan-ai-core',
            'as' => 'dashboard.user.titan.ai.core.',
        ], static function (Router $router): void {
            require __DIR__ . '/../routes/user.php';
        });

        $router->group([
            'middleware' => ['web', 'auth', 'admin', 'titan-ai-core.context'],
            'prefix' => 'dashboard/admin/titan-ai-core',
            'as' => 'dashboard.admin.titan.ai.core.',
        ], static function (Router $router): void {
            require __DIR__ . '/../routes/admin.php';
        });
    }
}
