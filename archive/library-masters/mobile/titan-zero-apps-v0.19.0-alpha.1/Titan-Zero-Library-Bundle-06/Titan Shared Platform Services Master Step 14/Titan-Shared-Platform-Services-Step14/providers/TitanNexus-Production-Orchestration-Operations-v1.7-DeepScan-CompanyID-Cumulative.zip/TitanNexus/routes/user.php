<?php

use App\Extensions\TitanNexus\System\Http\Controllers\ControlCentreController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', [ControlCentreController::class, 'overview'])->name('index');
$router->get('/overview', [ControlCentreController::class, 'overview'])->name('overview');
$router->get('/profile', [ControlCentreController::class, 'profile'])->name('profile');
$router->get('/compilations', [ControlCentreController::class, 'compilations'])->name('compilations');
$router->get('/compilations/{compilationUuid}', [ControlCentreController::class, 'detail'])
    ->where('compilationUuid', '[0-9a-fA-F-]{36}')
    ->name('detail');
$router->get('/validation', [ControlCentreController::class, 'validation'])->name('validation');
$router->get('/preview', [ControlCentreController::class, 'preview'])->name('preview');
$router->get('/history', [ControlCentreController::class, 'history'])->name('history');
$router->get('/diff', [ControlCentreController::class, 'diff'])->name('diff');
$router->get('/provisioning', [ControlCentreController::class, 'provisioning'])->name('provisioning');
$router->get('/receipts', [ControlCentreController::class, 'receipts'])->name('receipts');
