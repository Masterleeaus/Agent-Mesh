<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Support;

use Illuminate\Contracts\Container\Container;
use Illuminate\Support\Facades\Route;
use Throwable;

final class HostNavigationRegistrar
{
    private const USER_REGISTRY = 'App\\Support\\Extensions\\MenuContributionRegistry';
    private const CONTRIBUTION_REGISTRY = 'App\\Support\\Extensions\\ContributionRegistry';
    private const MENU_SERVICE = 'App\\Services\\Common\\MenuService';

    public function __construct(private readonly Container $app, private readonly ?LegacyMenuStore $legacyMenus = null)
    {
    }

    public function register(): void
    {
        $userRegistered = $this->registerModernUserContribution();
        $adminRegistered = $this->registerModernAdminContribution();

        if (! $userRegistered) {
            $this->registerLegacyMenu(TitanKnowledgeAuthorityNavigation::user()[0], 'user');
        }

        if (! $adminRegistered) {
            $this->registerLegacyMenu(TitanKnowledgeAuthorityNavigation::admin()[0], 'admin');
        }

        if (! $userRegistered || ! $adminRegistered) {
            $this->regenerateLegacyMenus();
        }
    }

    private function registerModernUserContribution(): bool
    {
        if (! class_exists(self::USER_REGISTRY)) {
            return false;
        }

        try {
            $registry = $this->app->make(self::USER_REGISTRY);
            if (! method_exists($registry, 'register')) {
                return false;
            }

            // Blueprint host contract:
            // MenuContributionRegistry::register(string $key, string $contributor, int $priority = 100)
            $registry->register(
                TitanKnowledgeAuthorityNavigation::USER_KEY,
                TitanKnowledgeAuthorityUserNavigationContributor::class,
                TitanKnowledgeAuthorityNavigation::PRIORITY,
            );

            return true;
        } catch (Throwable) {
            return false;
        }
    }

    private function registerModernAdminContribution(): bool
    {
        if (! class_exists(self::CONTRIBUTION_REGISTRY)) {
            return false;
        }

        try {
            $registry = $this->app->make(self::CONTRIBUTION_REGISTRY);
            if (! method_exists($registry, 'register')) {
                return false;
            }

            // Blueprint host contract:
            // ContributionRegistry::register(string $registry, string $key, string $class, int $priority = 100)
            $registry->register(
                'navigation.admin',
                TitanKnowledgeAuthorityNavigation::ADMIN_KEY,
                TitanKnowledgeAuthorityAdminNavigationContributor::class,
                TitanKnowledgeAuthorityNavigation::PRIORITY,
            );

            return true;
        } catch (Throwable) {
            return false;
        }
    }

    /** @param array<string, mixed> $definition */
    private function registerLegacyMenu(array $definition, string $audience): void
    {
        $routeName = (string) ($definition['route'] ?? '');
        if ($routeName === '' || ! Route::has($routeName) || ! ($this->legacyMenus ?? new LegacyMenuStore())->available()) {
            return;
        }

        try {
            $store = $this->legacyMenus ?? new LegacyMenuStore();
            $columns = $store->columns();
            if ($columns === []) {
                return;
            }

            $identity = $this->legacyIdentity($definition, $columns, $audience);
            if ($identity === []) {
                return;
            }

            $store = $this->legacyMenus ?? new LegacyMenuStore();
            $existing = $store->first($identity);
            $payload = $this->legacyPayload($definition, $columns, $audience, $existing === null);

            // Preserve administrator-customized placement and enabled/disabled state on self-heal.
            if ($existing !== null) {
                foreach (['order', 'sort', 'position', 'enabled', 'status', 'is_active'] as $field) {
                    unset($payload[$field]);
                }
                if ($payload !== []) {
                    $store->update($identity, $payload);
                }

                return;
            }

            $store->insert(array_merge($identity, $payload));
        } catch (Throwable) {
            // Legacy menu compatibility is non-authoritative. Never break engine boot.
        }
    }

    /** @param array<string, mixed> $definition @param array<string, int> $columns @return array<string, mixed> */
    private function legacyIdentity(array $definition, array $columns, string $audience): array
    {
        $route = (string) ($definition['route'] ?? '');
        $key = (string) ($definition['key'] ?? '');

        if (isset($columns['route'])) {
            return ['route' => $route];
        }
        if (isset($columns['key'])) {
            return ['key' => $key];
        }
        if (isset($columns['slug'])) {
            return ['slug' => $key];
        }

        // Some MagicAI menu schemas identify rows by a name/title plus menu area.
        foreach (['name', 'title', 'label'] as $labelColumn) {
            if (isset($columns[$labelColumn])) {
                $identity = [$labelColumn => (string) ($definition['label'] ?? 'Knowledge Authority')];
                foreach (['menu', 'menu_type', 'location', 'audience'] as $areaColumn) {
                    if (isset($columns[$areaColumn])) {
                        $identity[$areaColumn] = $audience;
                        break;
                    }
                }
                return $identity;
            }
        }

        return [];
    }

    /** @param array<string, mixed> $definition @param array<string, int> $columns @return array<string, mixed> */
    private function legacyPayload(array $definition, array $columns, string $audience, bool $creating): array
    {
        $payload = [];
        $label = (string) ($definition['label'] ?? 'Knowledge Authority');
        $route = (string) ($definition['route'] ?? '');
        $key = (string) ($definition['key'] ?? '');
        $icon = (string) ($definition['icon'] ?? 'tabler-folders');
        $order = (int) ($definition['order'] ?? TitanKnowledgeAuthorityNavigation::PRIORITY);

        foreach (['name', 'title', 'label'] as $column) {
            if (isset($columns[$column])) {
                $payload[$column] = $label;
            }
        }
        if (isset($columns['route'])) {
            $payload['route'] = $route;
        }
        if (isset($columns['url']) && ! isset($columns['route'])) {
            $payload['url'] = route($route, [], false);
        }
        if (isset($columns['icon'])) {
            $payload['icon'] = $icon;
        }
        if (isset($columns['key'])) {
            $payload['key'] = $key;
        }
        if (isset($columns['slug'])) {
            $payload['slug'] = $key;
        }
        foreach (['menu', 'menu_type', 'location', 'audience'] as $column) {
            if (isset($columns[$column])) {
                $payload[$column] = $audience;
                break;
            }
        }

        if ($creating) {
            foreach (['order', 'sort', 'position'] as $column) {
                if (isset($columns[$column])) {
                    $payload[$column] = $order;
                }
            }
            if (isset($columns['enabled'])) {
                $payload['enabled'] = true;
            }
            if (isset($columns['is_active'])) {
                $payload['is_active'] = true;
            }
            if (isset($columns['status'])) {
                $payload['status'] = 1;
            }
            if (isset($columns['created_at'])) {
                $payload['created_at'] = now();
            }
        }
        if (isset($columns['updated_at'])) {
            $payload['updated_at'] = now();
        }

        return $payload;
    }

    private function regenerateLegacyMenus(): void
    {
        if (! class_exists(self::MENU_SERVICE)) {
            return;
        }

        try {
            $service = $this->app->make(self::MENU_SERVICE);
            if (method_exists($service, 'regenerate')) {
                $service->regenerate();
            }
        } catch (Throwable) {
            // A menu regeneration failure must not break Knowledge Authority boot.
        }
    }
}
