<?php

declare(strict_types=1);
$root=dirname(__DIR__);
require_once $root.'/System/Host/TitanInstallerManifestContract.php';
require_once $root.'/System/Host/TitanFreshInstallPreflight.php';
use App\Extensions\TitanGovernance\System\Host\TitanFreshInstallPreflight;
$facts=['installer'=>'1.7.6','php'=>'8.3.33','laravel'=>'10.50.2','database'=>'mysql'];
if (isset($argv[1])) {
    $raw=is_file($argv[1])?(string)file_get_contents($argv[1]):$argv[1];
    $decoded=json_decode($raw,true);
    if (is_array($decoded)) $facts=array_merge($facts,$decoded);
}
$result=(new TitanFreshInstallPreflight())->inspect($root,$facts);
echo json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES).PHP_EOL;
exit(($result['status']??'FAIL')==='PASS'?0:1);
