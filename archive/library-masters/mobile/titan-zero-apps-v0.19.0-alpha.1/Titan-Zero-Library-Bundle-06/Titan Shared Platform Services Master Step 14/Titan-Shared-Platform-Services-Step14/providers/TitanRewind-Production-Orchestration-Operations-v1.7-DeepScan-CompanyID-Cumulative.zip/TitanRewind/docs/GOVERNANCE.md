# Governance

Rewind is governed but read-only. It may analyze, reconstruct, simulate, compare, package evidence and propose recovery. It does not authorize itself and does not mutate authoritative business state.

Recovery handoff must bind Governance to a specific `plan_hash`, `evidence_package_id`, and `evidence_hash`. A returned Governance receipt must be verified through the external Governance contract before any downstream Command Bus request is considered authorized.
