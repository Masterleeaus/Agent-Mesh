@extends('panel.layout.app')
@section('content')
@php
    $req = $dashboard['request'];
    $surface = $dashboard['surface'];
    $pulse = $dashboard['pulse'];
    $metrics = $pulse['metrics'] ?? [];
    $latency = $pulse['latency'] ?? [];
    $hidden = [
        'scope' => $req['scope'],
        'tenant_company_id' => $req['tenant_company_id'],
        'window' => $req['window'],
        'limit' => $req['limit'],
    ];
@endphp
<style>
.tse-wrap{max-width:1500px;margin:0 auto;padding:28px 20px}.tse-head{display:flex;gap:18px;align-items:flex-start;justify-content:space-between;flex-wrap:wrap}.tse-sub{opacity:.7}.tse-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:18px 0}.tse-card{border:1px solid rgba(127,127,127,.25);border-radius:14px;padding:16px;background:rgba(127,127,127,.05)}.tse-card h3,.tse-card h2{margin-top:0}.tse-value{font-size:1.65rem;font-weight:700;line-height:1.15}.tse-row{display:flex;gap:10px;flex-wrap:wrap;align-items:end}.tse-row>*{min-width:130px}.tse-input,.tse-select{width:100%;border:1px solid rgba(127,127,127,.35);border-radius:9px;padding:9px 10px;background:transparent;color:inherit}.tse-btn{border:1px solid rgba(127,127,127,.4);border-radius:9px;padding:8px 12px;background:rgba(127,127,127,.12);color:inherit;cursor:pointer}.tse-btn-primary{font-weight:700}.tse-table{width:100%;border-collapse:collapse;font-size:.9rem}.tse-table th,.tse-table td{text-align:left;padding:9px;border-bottom:1px solid rgba(127,127,127,.18);vertical-align:top}.tse-scroll{overflow:auto}.tse-code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.82rem;word-break:break-all}.tse-pre{white-space:pre-wrap;word-break:break-word;max-height:480px;overflow:auto;background:rgba(127,127,127,.08);padding:12px;border-radius:10px}.tse-section{margin-top:22px}.tse-alert{padding:12px 14px;border-radius:10px;margin:12px 0;border:1px solid rgba(127,127,127,.3)}.tse-actions{display:flex;gap:6px;flex-wrap:wrap}.tse-badge{display:inline-block;border:1px solid rgba(127,127,127,.3);border-radius:999px;padding:2px 8px;font-size:.78rem}.tse-muted{opacity:.65}.tse-danger{border-style:dashed}.tse-two{display:grid;grid-template-columns:minmax(0,2fr) minmax(300px,1fr);gap:14px}@media(max-width:900px){.tse-two{grid-template-columns:1fr}}
</style>
<div class="tse-wrap">
    <div class="tse-head">
        <div>
            <h1>{{ __('titan-signal-engine::messages.admin_title') }}</h1>
            <div class="tse-sub">v0.20.0-rc.8.1 · immutable telemetry, correlation, Pulse, anomaly and governed lifecycle operations</div>
        </div>
        <span class="tse-badge">{{ $dashboard['health']['status'] ?? 'unknown' }}</span>
    </div>

    @if(session('status')) <div class="tse-alert">{{ session('status') }}</div> @endif
    @if(session('error')) <div class="tse-alert tse-danger">{{ session('error') }}</div> @endif
    @if(!empty($consoleError)) <div class="tse-alert tse-danger">{{ $consoleError }}</div> @endif

    <form method="GET" class="tse-card tse-section">
        <h3>{{ __('titan-signal-engine::messages.scope_window') }}</h3>
        <div class="tse-row">
            <label>{{ __('titan-signal-engine::messages.scope') }}<select name="scope" class="tse-select"><option value="system" @selected($req['scope']==='system')>{{ __('titan-signal-engine::messages.system') }}</option><option value="tenant" @selected($req['scope']==='tenant')>{{ __('titan-signal-engine::messages.tenant') }}</option></select></label>
            <label>{{ __('titan-signal-engine::messages.tenant_company_id') }}<input class="tse-input" name="tenant_company_id" value="{{ $req['tenant_company_id'] }}" inputmode="numeric" placeholder="Required for tenant scope"></label>
            <label>{{ __('titan-signal-engine::messages.window') }}<select name="window" class="tse-select">@foreach(['5m','1h','24h','7d'] as $w)<option value="{{ $w }}" @selected($req['window']===$w)>{{ $w }}</option>@endforeach</select></label>
            <label>{{ __('titan-signal-engine::messages.rows') }}<input class="tse-input" type="number" min="1" max="250" name="limit" value="{{ $req['limit'] }}"></label>
            <button class="tse-btn tse-btn-primary" type="submit">{{ __('titan-signal-engine::messages.refresh') }}</button>
        </div>
    </form>

    <div class="tse-grid">
        <div class="tse-card"><div class="tse-muted">{{ __('titan-signal-engine::messages.attention') }}</div><div class="tse-value">{{ strtoupper($surface['attention']['band'] ?? 'LOW') }}</div><div class="tse-muted">score {{ $surface['attention']['score'] ?? 0 }}</div></div>
        <div class="tse-card"><div class="tse-muted">{{ __('titan-signal-engine::messages.signals') }}</div><div class="tse-value">{{ number_format($surface['signal_count'] ?? 0) }}</div><div class="tse-muted">{{ $req['window'] }}</div></div>
        <div class="tse-card"><div class="tse-muted">{{ __('titan-signal-engine::messages.errors') }}</div><div class="tse-value">{{ number_format($surface['error_count'] ?? 0) }}</div><div class="tse-muted">critical {{ number_format($surface['critical_count'] ?? 0) }}</div></div>
        <div class="tse-card"><div class="tse-muted">{{ __('titan-signal-engine::messages.stalled_traces') }}</div><div class="tse-value">{{ number_format($surface['stalled_trace_count'] ?? 0) }}</div><div class="tse-muted">missing receipts {{ number_format($surface['missing_receipt_count'] ?? 0) }}</div></div>
        <div class="tse-card"><div class="tse-muted">{{ __('titan-signal-engine::messages.dead_letters') }}</div><div class="tse-value">{{ number_format($surface['dead_letter_count'] ?? 0) }}</div><div class="tse-muted">subscriber delivery</div></div>
        <div class="tse-card"><div class="tse-muted">{{ __('titan-signal-engine::messages.event_rate') }}</div><div class="tse-value">{{ number_format((float)($surface['event_rate_per_second'] ?? 0), 3) }}/s</div><div class="tse-muted">pre-aggregated Pulse</div></div>
    </div>

    <div class="tse-card">
        <h2>{{ $surface['headline'] ?? 'Titan Pulse' }}</h2>
        <div class="tse-row">
            <div><strong>P50</strong><br>{{ $latency['p50_ms'] ?? $latency['p50'] ?? '—' }}</div>
            <div><strong>P95</strong><br>{{ $latency['p95_ms'] ?? $latency['p95'] ?? '—' }}</div>
            <div><strong>P99</strong><br>{{ $latency['p99_ms'] ?? $latency['p99'] ?? '—' }}</div>
            <div><strong>Projection</strong><br>{{ ($surface['health']['degraded'] ?? false) ? 'degraded' : 'healthy' }}</div>
        </div>
    </div>

    <div class="tse-two tse-section">
        <div class="tse-card">
            <h2>Trace / workflow / event explorer</h2>
            <form method="GET">
                @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach
                <div class="tse-row">
                    <label>Trace ID<input class="tse-input tse-code" name="trace_id" placeholder="UUID"></label>
                    <label>Profile key<input class="tse-input" name="profile_key" placeholder="e.g. governed.command"></label>
                    <label>Profile version<input class="tse-input" name="profile_version" type="number" min="1"></label>
                    <button class="tse-btn" type="submit">Open trace</button>
                </div>
            </form>
            <form method="GET" style="margin-top:10px">
                @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach
                <div class="tse-row"><label>Correlation ID<input class="tse-input tse-code" name="correlation_id" placeholder="UUID"></label><button class="tse-btn" type="submit">Open workflow</button></div>
            </form>
            <form method="GET" style="margin-top:10px">
                @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach
                <div class="tse-row"><label>Event ID<input class="tse-input tse-code" name="event_id" placeholder="UUID"></label><button class="tse-btn" type="submit">Open event</button></div>
            </form>
        </div>
        <div class="tse-card">
            <h2>Lifecycle</h2>
            @foreach(($dashboard['lifecycle'] ?? []) as $k=>$v)<div><span class="tse-muted">{{ str_replace('_',' ',ucfirst($k)) }}</span> <strong style="float:right">{{ number_format((int)$v) }}</strong></div>@endforeach
            <form method="GET" style="margin-top:14px">
                @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach
                <input type="hidden" name="prune_preview" value="1"><button class="tse-btn" type="submit">Preview prune candidates</button>
            </form>
        </div>
    </div>

    @if($detail)
    <div class="tse-card tse-section">
        <h2>{{ ucfirst($detail['kind']) }} detail</h2>
        <div class="tse-code">{{ $detail['id'] }}</div>
        @if(in_array($detail['kind'], ['trace','workflow'], true))
            @php $d=$detail['data']; @endphp
            <div class="tse-grid">
                <div><span class="tse-muted">Returned events</span><div class="tse-value">{{ $d['returned_event_count'] ?? 0 }}</div></div>
                <div><span class="tse-muted">Total events</span><div class="tse-value">{{ $d['total_event_count'] ?? 0 }}</div></div>
                <div><span class="tse-muted">Status</span><div class="tse-value">{{ $d['analysis']['status'] ?? '—' }}</div></div>
                <div><span class="tse-muted">Truncated</span><div class="tse-value">{{ !empty($d['truncated']) ? 'YES' : 'NO' }}</div></div>
            </div>
            <h3>Timeline</h3><div class="tse-scroll"><table class="tse-table"><thead><tr><th>Occurred</th><th>Event</th><th>Severity</th><th>Source</th><th>Event ID</th><th>Causation</th></tr></thead><tbody>@foreach(($d['events'] ?? []) as $e)<tr><td>{{ $e['occurred_at'] ?? '' }}</td><td>{{ $e['event_type'] ?? '' }}</td><td>{{ $e['severity'] ?? '' }}</td><td>{{ $e['source'] ?? '' }}</td><td class="tse-code">{{ $e['event_id'] ?? '' }}</td><td class="tse-code">{{ $e['causation_id'] ?? 'root' }}</td></tr>@endforeach</tbody></table></div>
            <h3>Causal graph edges</h3><div class="tse-scroll"><table class="tse-table"><thead><tr><th>Parent</th><th>Child</th></tr></thead><tbody>@foreach(($d['edges'] ?? []) as $edge)<tr><td class="tse-code">{{ $edge['parent_event_id'] ?? $edge['parent'] ?? '' }}</td><td class="tse-code">{{ $edge['child_event_id'] ?? $edge['child'] ?? '' }}</td></tr>@endforeach</tbody></table></div>
        @elseif($detail['kind']==='event')
            @if($detail['data'])
                @php $event=$detail['data']['event'] ?? []; @endphp
                <pre class="tse-pre">{{ json_encode($detail['data'], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre>
                <div class="tse-two">
                    <div>
                        <h3>Legal hold</h3>
                        <form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.events.legal-hold', ['eventId'=>$detail['id']]) }}">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input type="hidden" name="hold" value="1"><input class="tse-input" name="reason" required maxlength="255" placeholder="Reason"><button class="tse-btn" type="submit">Apply hold</button></form>
                        <form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.events.legal-hold', ['eventId'=>$detail['id']]) }}" style="margin-top:8px">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input type="hidden" name="hold" value="0"><input class="tse-input" name="reason" required maxlength="255" placeholder="Release reason"><button class="tse-btn" type="submit">Release hold</button></form>
                    </div>
                    <div><h3>Privacy overlay</h3><form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.events.redact', ['eventId'=>$detail['id']]) }}">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<select class="tse-select" name="operation"><option value="remove">Remove</option><option value="replace">Replace</option></select><input class="tse-input" name="path" required placeholder="payload.customer.email"><input class="tse-input" name="value" placeholder="Replacement value"><input class="tse-input" name="reason" required maxlength="255" placeholder="Reason"><button class="tse-btn" type="submit">Apply redaction</button></form><form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.events.correct', ['eventId'=>$detail['id']]) }}" style="margin-top:8px">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input type="hidden" name="operation" value="replace"><input class="tse-input" name="path" required placeholder="payload.field"><input class="tse-input" name="value" required placeholder="Corrected value"><input class="tse-input" name="reason" required maxlength="255" placeholder="Correction reason"><button class="tse-btn" type="submit">Apply correction</button></form></div>
                </div>
            @else <p>No event found in the selected scope.</p> @endif
        @endif
    </div>
    @endif

    @if($prunePreview)
    <div class="tse-card tse-section tse-danger">
        <h2>{{ __('titan-signal-engine::messages.prune_preview') }}</h2><p><strong>{{ $prunePreview['candidate_count'] ?? 0 }}</strong> candidate events. Preview is non-destructive and binds the exact candidate set.</p>
        <p><small>Candidate hash: <code>{{ $prunePreview['candidate_hash'] ?? '' }}</code> · expires {{ $prunePreview['expires_at'] ?? '' }} · archive required {{ $prunePreview['archive_required_count'] ?? 0 }}</small></p>
        <pre class="tse-pre">{{ json_encode($prunePreview['by_retention_class'] ?? [], JSON_PRETTY_PRINT) }}</pre>
        @if(($prunePreview['candidate_count'] ?? 0)>0)
        <form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.lifecycle.prune') }}">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input type="hidden" name="preview_token" value="{{ $prunePreview['preview_token'] ?? '' }}"><label>Reason<input class="tse-input" name="reason" required maxlength="255" placeholder="Required governed reason"></label><button class="tse-btn tse-btn-primary" type="submit">Archive, verify & prune exact preview</button></form>
        @endif
    </div>
    @endif

    <div class="tse-card tse-section"><h2>{{ __('titan-signal-engine::messages.anomaly_feed') }}</h2><div class="tse-scroll"><table class="tse-table"><thead><tr><th>Severity</th><th>Type</th><th>Subject</th><th>Score</th><th>Occurrences</th><th>Last seen</th><th>Actions</th></tr></thead><tbody>@forelse(($dashboard['anomalies'] ?? []) as $a)<tr><td><span class="tse-badge">{{ $a['severity'] }}</span></td><td>{{ $a['type'] }}</td><td class="tse-code">{{ $a['subject_type'] }}:{{ $a['subject_id'] }}</td><td>{{ $a['score'] }}</td><td>{{ $a['occurrence_count'] }}</td><td>{{ $a['last_detected_at'] }}</td><td><div class="tse-actions"><form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.anomalies.acknowledge',['anomalyId'=>$a['anomaly_id']]) }}">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input class="tse-input" name="reason" required placeholder="Ack reason"><button class="tse-btn">Ack</button></form><form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.anomalies.resolve',['anomalyId'=>$a['anomaly_id']]) }}">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input class="tse-input" name="reason" required placeholder="Resolve reason"><button class="tse-btn">Resolve</button></form><form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.anomalies.suppress',['anomalyId'=>$a['anomaly_id']]) }}">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input class="tse-input" type="datetime-local" name="until" required><input class="tse-input" name="reason" required placeholder="Suppress reason"><button class="tse-btn">Suppress</button></form></div></td></tr>@empty<tr><td colspan="7">{{ __('titan-signal-engine::messages.no_open_anomalies') }}</td></tr>@endforelse</tbody></table></div></div>


    <div class="tse-card tse-section">
        <h2>Dead-letter recovery</h2>
        <p class="tse-muted">Redrive is governed and starts a new retry cycle only after the subscriber is repaired. Historical failure and redrive audit records are retained.</p>
        <div class="tse-scroll"><table class="tse-table"><thead><tr><th>Delivery</th><th>Subscriber</th><th>Event</th><th>Failed</th><th>Redrives</th><th>Error</th><th>Action</th></tr></thead><tbody>
        @forelse(($dashboard['dead_letters'] ?? []) as $d)
            <tr>
                <td class="tse-code">{{ $d['delivery_id'] }}</td><td class="tse-code">{{ $d['subscriber_key'] }}</td><td class="tse-code">{{ $d['event_type'] }}</td><td>{{ $d['dead_lettered_at'] ?? '—' }}</td><td>{{ $d['redrive_count'] ?? 0 }}</td><td class="tse-code">{{ $d['error_reference'] ?? $d['error_class'] ?? '—' }}</td>
                <td><form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.deliveries.redrive',['deliveryId'=>$d['delivery_id']]) }}">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input class="tse-input" name="reason" required maxlength="500" placeholder="Governed redrive reason"><button class="tse-btn" type="submit">Redrive</button></form></td>
            </tr>
        @empty<tr><td colspan="7">No unresolved dead letters in this scope.</td></tr>@endforelse
        </tbody></table></div>
    </div>

    <div class="tse-two tse-section">
        <div class="tse-card"><h2>{{ __('titan-signal-engine::messages.subscriber_health') }}</h2><div class="tse-scroll"><table class="tse-table"><thead><tr><th>Subscriber</th><th>Status</th><th>Queue</th><th>Deliveries</th></tr></thead><tbody>@forelse(($dashboard['subscriber_health'] ?? []) as $s)<tr><td class="tse-code">{{ $s['subscriber_key'] }}</td><td>{{ $s['status'] }}</td><td>{{ $s['queue'] }}</td><td>{{ collect($s['deliveries'])->map(fn($v,$k)=>$k.':'.$v)->implode(' · ') }}</td></tr>@empty<tr><td colspan="4">No subscribers registered.</td></tr>@endforelse</tbody></table></div></div>
        <div class="tse-card"><h2>{{ __('titan-signal-engine::messages.top_sources') }}</h2>@foreach(($surface['top_sources'] ?? []) as $s)<div style="margin-bottom:8px"><strong>{{ $s['dimension_value'] ?? $s['source'] ?? 'unknown' }}</strong><span style="float:right">{{ $s['event_count'] ?? $s['count'] ?? 0 }}</span></div>@endforeach<h3>{{ __('titan-signal-engine::messages.top_event_types') }}</h3>@foreach(($surface['top_event_types'] ?? []) as $e)<div style="margin-bottom:8px"><span class="tse-code">{{ $e['dimension_value'] ?? $e['event_type'] ?? 'unknown' }}</span><span style="float:right">{{ $e['event_count'] ?? $e['count'] ?? 0 }}</span></div>@endforeach</div>
    </div>

    <div class="tse-two tse-section">
        <div class="tse-card"><h2>{{ __('titan-signal-engine::messages.recent_archives') }}</h2><table class="tse-table"><thead><tr><th>Batch</th><th>Status</th><th>Events</th><th>Verified</th></tr></thead><tbody>@forelse(($dashboard['archives'] ?? []) as $a)<tr><td class="tse-code">{{ $a['batch_id'] }}</td><td>{{ $a['status'] }}</td><td>{{ $a['event_count'] }}</td><td>{{ $a['verified_at'] ?? '—' }}</td></tr>@empty<tr><td colspan="4">No archive batches.</td></tr>@endforelse</tbody></table></div>
        <div class="tse-card"><h2>{{ __('titan-signal-engine::messages.lifecycle_audit') }}</h2><table class="tse-table"><thead><tr><th>Action</th><th>Actor</th><th>When</th></tr></thead><tbody>@forelse(($dashboard['lifecycle_audit'] ?? []) as $a)<tr><td>{{ $a['action'] }}</td><td class="tse-code">{{ $a['actor_id'] }}</td><td>{{ $a['occurred_at'] }}</td></tr>@empty<tr><td colspan="3">No lifecycle actions.</td></tr>@endforelse</tbody></table></div>
    </div>
</div>
@endsection
