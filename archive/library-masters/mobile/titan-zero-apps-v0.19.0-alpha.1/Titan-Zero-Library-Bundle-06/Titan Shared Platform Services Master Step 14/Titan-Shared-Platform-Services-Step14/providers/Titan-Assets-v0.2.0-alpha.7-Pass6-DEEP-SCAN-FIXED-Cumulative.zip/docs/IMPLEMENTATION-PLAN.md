# Titan Assets Option A Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build Titan Assets as the authoritative individually-tracked asset extension and converge Titan Locker to inventory-only ownership without losing existing data or navigation.

**Architecture:** Titan Assets reuses the proven CRM/Titan Locker query-builder services against existing `crm_locker_*` asset tables, adds isolated `titan_asset_*` tables for repairs/warranties/mileage/premises links, and owns a boot-time self-healing menu service based on the live `menus` schema. Titan Locker receives a cumulative compatibility upgrade that keeps inventory/stock/purchasing while delegating legacy asset endpoints to Titan Assets.

**Tech Stack:** PHP 8.3, Laravel 10, MySQL/MariaDB, Blade, Titan Extension Manager 1.7.8.

**Spec:** `docs/superpowers/specs/2026-08-18-titan-assets-option-a-design.md`

## Global Constraints
- Preserve existing asset data and table names.
- Use `company_id` as the Titan Assets persistence boundary; resolve the active company through CRM company scope and retain `tenant_company_id` only when reading/backfilling existing legacy Locker asset tables.
- Do not import donor `Modules\\*`, `module_path()`, generic permission-table mutations, or duplicate repair schemas.
- Menu healing must fail open and regenerate only after change/version drift.
- Installer archive must contain exactly one top-level extension folder and one `extension.json`.

---

### Task 1: Release-contract test harness
**Files:** Create `tests/verify_titan_assets_release.py`.
**Interfaces:** Consumes a package root; produces deterministic release failures for missing manifest, services, safe migrations, routes and self-healing navigation.
- [ ] Write assertions for package structure, route names, legacy table preservation, menu adoption keys and no donor namespace leakage.
- [ ] Run against an empty target and confirm failure.
- [ ] Keep the harness as the final ZIP release gate.

### Task 2: Titan Assets domain core
**Files:** Create `TitanAssets/System/Domains/Assets/*.php` and service provider.
**Interfaces:** Produces `AssetRegisterService`, `ToolCustodyService`, `FleetService`, `MaintenanceService`, `WarrantyService`, `RepairService`, `RepairTemplateService`, `MileageService`, `PremisesLinkService`, `AssetQueryService`.
- [ ] Port the four proven Locker asset services to Titan Assets namespace while preserving existing tables.
- [ ] Add focused services for donor-derived warranty/repair/mileage/premises concepts.
- [ ] Register services as singletons.

### Task 3: Data-preserving migrations
**Files:** Create three Titan Assets migrations.
**Interfaces:** Produces ensured legacy core tables plus new `titan_asset_*` tables and forward menu adoption.
- [ ] Ensure legacy asset tables exist without destructive changes.
- [ ] Create repair, warranty, mileage and premises-link tables.
- [ ] Add menu rows/reparent existing asset keys using the live schema.

### Task 4: Routes, controller and UI
**Files:** Create controller, web/API routes, and `resources/views/assets/index.blade.php`.
**Interfaces:** Produces named routes consumed by menu healer and legacy Locker compatibility routes.
- [ ] Create named section routes for every menu item.
- [ ] Create guarded mutation endpoints for assets/custody/fleet/maintenance/repair/warranty/mileage/premises links.
- [ ] Duplicate the existing CRM/Titan Locker UI shell pattern and refocus it on Assets.

### Task 5: Self-healing navigation
**Files:** Create `System/Navigation/AssetMenuSelfHealer.php`, `config/navigation.php`, invoke from provider boot.
**Interfaces:** Produces `heal(): void`.
- [ ] Adopt existing live keys `crm_tools`, `crm_equipment`, `crm_fleet`, `crm_maintenance`, `crm_customer_assets`.
- [ ] Repair/create remaining children only when their routes exist.
- [ ] Rename `ext_crm_gear` to `Inventory & Supplies` when present.
- [ ] Regenerate menu cache on actual changes or schema-version drift; fail open on all exceptions.

### Task 6: Titan Locker ownership-convergence cumulative upgrade
**Files:** Modify a copy of Titan Locker provider/routes/controller/view/manifest and add compatibility bridge.
**Interfaces:** Locker keeps inventory authority and forwards legacy asset mutations to Titan Assets.
- [ ] Remove direct registration of Locker asset service implementations.
- [ ] Replace legacy asset routes with compatibility controller methods backed by Titan Assets services.
- [ ] Remove Tools/Equipment/Fleet/Maintenance from Locker UI/menu ownership while preserving old route names.
- [ ] Update domain-ownership docs and manifest dependency.

### Task 7: Final verification and packaging
**Files:** Final ZIPs, verification JSON, SHA-256 files.
**Interfaces:** Produces installer-ready Titan Assets and Titan Locker convergence packages.
- [ ] Run release harness against extracted final Titan Assets ZIP.
- [ ] Run `php -l` on all PHP and Blade files in both final packages.
- [ ] Parse JSON, inspect ZIP paths/CRC/case collisions/symlinks and scan destructive migrations.
- [ ] Publish hashes and verification report.
