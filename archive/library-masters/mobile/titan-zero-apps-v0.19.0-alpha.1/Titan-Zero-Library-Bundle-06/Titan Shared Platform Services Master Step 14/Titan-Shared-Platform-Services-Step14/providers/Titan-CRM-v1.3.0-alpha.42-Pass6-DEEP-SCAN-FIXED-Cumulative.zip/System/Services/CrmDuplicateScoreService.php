<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Support\CrmNormalizer;

final class CrmDuplicateScoreService
{
    public function __construct(private CrmNormalizer $normalizer) {}
    public function score(array $left,array $right): array
    {
        $le=$this->normalizer->email((string)($left['email']??'')); $re=$this->normalizer->email((string)($right['email']??''));
        $lp=$this->normalizer->phone((string)($left['phone']??'')); $rp=$this->normalizer->phone((string)($right['phone']??''));
        $ln=$this->name($left); $rn=$this->name($right); $points=0; $signals=[];
        if($le!==null && $re!==null && $le===$re){$points+=60;$signals[]='normalized_email';}
        if($lp!==null && $rp!==null && $lp===$rp){$points+=30;$signals[]='normalized_phone';}
        if($ln!=='' && $rn!==''){ $distance=levenshtein($ln,$rn); $max=max(strlen($ln),strlen($rn),1); $similarity=1-($distance/$max); if($similarity>=.9){$points+=20;$signals[]='name_similarity';} elseif($similarity>=.75){$points+=10;$signals[]='name_similarity';} }
        $confidence=min(100,$points); return ['confidence'=>$confidence,'signals'=>$signals,'normalized_email'=>$le,'normalized_phone'=>$lp,'is_likely_duplicate'=>$confidence>=70];
    }
    private function name(array $r): string { return strtolower(trim(preg_replace('/\s+/',' ',(string)($r['name']??trim(($r['first_name']??'').' '.($r['last_name']??'')))))); }
}
