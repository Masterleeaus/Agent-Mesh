# Governance Human Oversight + Workforce Operating View — Design

## Goal
Add a read-only Governance operating view over Titan AI Workforce so human operators can see organisation state, waiting approvals, review/handoff bottlenecks, operator workload and intervention history without duplicating Workforce or Autonomy ownership.

## Authority boundaries
- Titan AI Workforce remains authoritative for staff, hierarchy, tasks, queues, reviews, handoffs, incidents, staffing recommendations and Workforce Control Room state.
- Titan Autonomy remains the sole owner of desired/earned/effective authority.
- Governance only normalizes and prioritizes read evidence.
- Workforce tier, title, hierarchy, maturity or performance can never raise authority.
- Governance never writes Workforce tables or calls Workforce mutation services.

## Input contract
Use the existing `GovernanceReadSourceContract` source `titan-ai-workforce`. Its `control_centre` overlay may expose the canonical Workforce Control Room payload: `organisation_graph`, `queues`, `trust_health`, `handoffs`, `approvals`, `staffing`, `performance`, `outcome_health`, `outcome_refs`, `summary`, plus resilience/incident observations where available.

## Components
1. `WorkforceOversightProjector`: validates and normalizes Workforce Control Room evidence, preserves tenant-safe identifiers, computes bounded counts/statuses, and emits `can_raise_authority=false` / `authority_changed=false`.
2. `HumanOversightProjector`: derives approval age bands, manager/operator workload, review/handoff ageing and intervention history from normalized Workforce evidence plus Governance decisions.
3. `GovernanceAttentionRanker`: accepts optional Workforce/Human facets and adds deterministic attention items with drill-down metadata.
4. `GovernanceControlCentre`: includes `workforce_oversight` and `human_oversight` in the canonical snapshot.
5. `WorkforceOversightController` + `workforce.blade.php`: authenticated read-only operator surface.

## Status semantics
- Workforce source absent/not installed: `NOT_INSTALLED` or `UNAVAILABLE`; no fabricated staff/task state.
- Wrong tenant identity: existing source reader marks it `INVALID` before projection.
- Approval age: CURRENT < warning threshold; AGING >= warning; OVERDUE >= critical threshold.
- Handoff status remains source-owned; Governance may mark age severity but never change status.
- Intervention history is a view of Governance-owned decisions linked to Workforce subjects/references; absence remains empty/unknown.

## Drill-down
Needs Attention items carry structured `drill_down` metadata only: surface `workforce`, focus kind (`member`, `task`, `handoff`, `decision`, `queue`) and stable reference. The Blade surface uses these values for local filtering/highlighting; Governance does not invent foreign Workforce route parameters.

## Testing
TDD contract tests cover: source unavailable, exact Workforce Control Room normalization, hierarchy/maturity authority neutrality, approval ageing, operator workload, intervention history, attention drill-down, tenant isolation inherited from source reader, controller read-only wiring, manifest/capability release contract and cumulative regression.
