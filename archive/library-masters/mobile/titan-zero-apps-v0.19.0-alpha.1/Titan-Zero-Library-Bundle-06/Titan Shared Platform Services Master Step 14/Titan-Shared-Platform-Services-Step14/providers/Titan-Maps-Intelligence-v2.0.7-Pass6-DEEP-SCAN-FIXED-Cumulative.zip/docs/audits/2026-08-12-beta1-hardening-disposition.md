# Titan Maps Intelligence beta.1 hardening disposition

This document records the disposition of the alpha.17 audit findings. It deliberately separates implemented controls from findings that were already satisfied in alpha.17 and larger features deferred to a later release. No deferred item is claimed as implemented.

## Implemented in beta.1

- Provider quota circuit breaker: tenant/provider daily and monthly limits, 80% soft threshold by default, hard fail-closed 429 semantics, Signals, governed emergency override, quota status capability.
- Provider health and credential rotation: primary/secondary **secret references**, consecutive authentication-failure tracking, health status, secondary failover; no raw API keys stored.
- Provider guards cover Places discovery, geocoding, reverse-geocoding, routing, matrices and traffic.
- Server-authoritative geofencing: raw GPS is authoritative input, immediate server evaluation remains, plus every-minute reconciliation of recent append-only pings. Per-geofence hysteresis and transition-sample settings, GPS-accuracy-aware uncertainty and event confidence are persisted.
- GPS privacy/security: server-derived worker identity retained; 100 m default accuracy ceiling, 5-minute capture-age ceiling, future timestamp rejection, 10-second per-device throttling, impossible-jump anomaly investigation Signal, stale-team-location suppression, explicit historical-trail sharing window.
- Retention profiles: transient 7 days, standard 90 days, forensic 2555 days. Standard is default.
- Dispatch scoring policy stored per tenant and optional vertical, with governed read/update capabilities. Temporal availability, fatigue/shift-end evidence and customer familiarity can influence scoring. Unknown mandatory certification evidence is a blocker when the job explicitly requires that certification.
- Dispatch assignment continues through Command Bus and includes candidate rank for auditability.
- Deterministic territory matching: exclusion enforcement, priority → primary branch → nearest branch distance → stable ID tie-break, explicit boundary handling, rule chain and conflict Signal.
- Five-second idempotent cache for `territory.validate` and `service_area.check`, Redis-preferred with DB/application-cache fallback Signal.
- ETA `valid_until`: live/traffic-aware 15 minutes, typical 2 hours, static/traffic-unaware 24 hours. Dispatch does not use stale matrix ETA older than 2 hours after a failed refresh attempt.
- Route history filters: date range, worker and customer lineage.
- Route planning complexity control: exact search for up to 10 stops, bounded greedy + 2-opt for larger plans, 5-second default timeout, persisted algorithm/heuristic/timeout metadata and heuristic Signal.
- Resource fallback human review deadline: 4 hours by default, scheduled escalation Signal, promotion approval record with actor/reason lineage.
- Territory analytics runs are queued and fresh persisted snapshots are reused for 24 hours.
- Geocode retry state with normalized address fingerprint and exponential backoff (5 min → 1 h → 24 h), automatic retry blocked after 5 failures until forced/manual refresh, plus geocode confidence and provider-contract version metadata.
- Nearest-resource quality: stale worker locations and explicitly closed discovery resources are excluded.
- Canonical beta capabilities added: `maps.quota.status`, `maps.provider.quota.override`, `maps.provider.health`, `maps.dispatch.weights.read`, `maps.dispatch.weights.update`. All capability definitions remain versioned (`2.0`).
- Offline `route.estimate` is `OFFLINE_BLOCKED`; callers may consume a previously authorised cached snapshot through read/history paths instead of performing a new provider calculation offline.
- Authenticated user/API map route groups remain tenant-bound; there is no unauthenticated public map-data endpoint to redact.

## Already materially enforced before beta.1

- Server-derived worker identity and worker impersonation prevention.
- Tracking consent/on-duty checks before GPS ingestion.
- Future/stale timestamp validation and minimum ping/movement controls.
- Geofence event idempotency/replay protection.
- Service-area exclusions making a target non-serviceable.
- Explicit Risk denial and Autonomy enforcement in governed execution.
- CRM assignment behind Command Bus; no direct authoritative CRM assignment service call.
- Offline authority cannot increase; authoritative mutations are blocked and consequential Maps mutations prepare-only.
- Discovery/place candidate database uniqueness prevents the same provider place from being blindly duplicated within the relevant tenant/search lifecycle.
- Durable route/matrix snapshots are evidence/history, while hot-cache behavior may use Redis/application cache. They are not merely disposable cache rows.

## Deferred beyond beta.1

These require separate product/infrastructure design and are **not** claimed by beta.1:

- DB-native monthly partitioning and Parquet/object-storage archive. The existing worker/geofence/route indexes and retention policies remain portable; partitioning is deployment/database-engine specific and will not be forced into a generic installer migration.
- Server-side third-party map-tile proxy/cache. Tile caching must be implemented only for a provider whose licence explicitly permits proxying/caching; the extension will not assume that all tile providers allow a 24-hour proxy.
- Turn-by-turn voice navigation, real-time reroute alerts, weather-adjusted ETA, EV/fuel/parking/rest-stop intelligence.
- Full heatmap/capacity-map suite, customer-location-history UX, recurring-location pattern visualisation.
- Multi-geofence workflow choreography and automatic communication triggers; these should be Interaction Engine workflows invoking Connect capabilities rather than Maps owning messaging/business completion.
- Predictive demand/ETA ML through Wisdom, indoor/floor-plan navigation and dynamic territory rebalancing.
- Generic Redis-only replacement of durable route/matrix evidence. Redis is appropriate for hot cache; durable evidence remains necessary for Rewind/audit.
- CRM pricing-rule validation and surge pricing until the authoritative CRM pricing-policy contract is available. Maps pricing remains advisory and non-authoritative.
- Multi-language/fuzzy geocoding UX beyond provider language/region support and normalized fingerprinting.
- Preferred supplier scoring using historical CRM/Wisdom outcomes until that authoritative outcome adapter is available.
- End-to-end application-layer encryption of GPS beyond TLS. Transport encryption is host/platform infrastructure; adding an ad-hoc incompatible crypto protocol inside Maps would not improve server-authorised processing.
