<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Contracts;

interface RewindHistoricalArtifactResolverContract
{
    public function kind(): string;

    /**
     * Return immutable historical artifact metadata/content for the exact version,
     * or null when this resolver cannot prove that artifact exists.
     */
    public function resolve(string $version, array $context = []): ?array;
}
