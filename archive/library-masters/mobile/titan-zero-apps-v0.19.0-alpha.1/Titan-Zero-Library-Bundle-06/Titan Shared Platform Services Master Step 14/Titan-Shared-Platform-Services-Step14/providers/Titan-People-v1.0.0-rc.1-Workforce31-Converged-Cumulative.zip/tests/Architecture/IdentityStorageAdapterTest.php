<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$src = (string) @file_get_contents($root.'/System/Identity/DatabasePeopleIdentityPort.php');
$t->contains('Worker::query()', $src, 'identity adapter must use People-owned Worker model');
$t->contains("->where('tenant_company_id', \$tenantCompanyId)", $src, 'identity adapter must apply tenant scope');
$t->assert(!str_contains($src, 'Illuminate\\Support\\Facades\\DB'), 'identity adapter must not use raw DB facade');
$t->finish('identity storage adapter tenant scope');
