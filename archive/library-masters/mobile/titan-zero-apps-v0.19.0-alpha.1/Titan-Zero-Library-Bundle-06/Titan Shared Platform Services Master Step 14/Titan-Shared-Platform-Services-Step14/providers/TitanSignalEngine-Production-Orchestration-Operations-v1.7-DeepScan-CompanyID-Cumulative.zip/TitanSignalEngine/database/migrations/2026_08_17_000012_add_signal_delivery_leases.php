<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_deliveries')) {
            return;
        }

        Schema::table('titan_signal_deliveries', function (Blueprint $table): void {
            if (! Schema::hasColumn('titan_signal_deliveries', 'lease_token')) {
                $table->uuid('lease_token')->nullable()->after('reserved_at');
            }
            if (! Schema::hasColumn('titan_signal_deliveries', 'lease_owner')) {
                $table->string('lease_owner', 191)->nullable()->after('lease_token');
            }
            if (! Schema::hasColumn('titan_signal_deliveries', 'lease_expires_at')) {
                $table->timestamp('lease_expires_at')->nullable()->after('lease_owner');
            }
            if (! Schema::hasColumn('titan_signal_deliveries', 'processing_started_at')) {
                $table->timestamp('processing_started_at')->nullable()->after('lease_expires_at');
            }
            if (! Schema::hasColumn('titan_signal_deliveries', 'claim_version')) {
                $table->unsignedInteger('claim_version')->default(0)->after('processing_started_at');
            }
        });

        // Any pre-lease processing row was owned by an unknown worker. Make it
        // recoverable rather than pretending that legacy ownership still exists.
        DB::table('titan_signal_deliveries')
            ->where('status', 'processing')
            ->update([
                'status' => 'retry_wait',
                'available_at' => now(),
                'reserved_at' => null,
                'updated_at' => now(),
            ]);

        Schema::table('titan_signal_deliveries', function (Blueprint $table): void {
            $table->index(['status', 'lease_expires_at'], 'tsd_status_lease_expiry_idx');
            $table->index(['lease_owner', 'status'], 'tsd_lease_owner_status_idx');
            $table->index(['delivery_id', 'claim_version'], 'tsd_delivery_claim_idx');
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('titan_signal_deliveries')) {
            return;
        }

        Schema::table('titan_signal_deliveries', function (Blueprint $table): void {
            $table->dropIndex('tsd_status_lease_expiry_idx');
            $table->dropIndex('tsd_lease_owner_status_idx');
            $table->dropIndex('tsd_delivery_claim_idx');
            $table->dropColumn([
                'lease_token',
                'lease_owner',
                'lease_expires_at',
                'processing_started_at',
                'claim_version',
            ]);
        });
    }
};
