<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\Chatbot\Generators;

use App\Domains\Entity\Enums\EntityEnum;
use App\Extensions\Chatbot\System\Generators\OpenAIGenerator;
use App\Extensions\Chatbot\System\Tools\KnowledgeBase;
use App\Extensions\ChatbotEcommerce\System\Services\EcommerceToolService;
use App\Extensions\Crm\System\Integrations\Chatbot\CrmChatbotToolService;
use App\Helpers\Classes\ApiHelper;
use App\Helpers\Classes\MarketplaceHelper;
use Exception;
use Illuminate\Support\Facades\Log;
use Psr\Http\Message\StreamInterface;

final class CrmOpenAIGenerator extends OpenAIGenerator
{
    public function tools(): array
    {
        $base = parent::tools();
        $crm = app(CrmChatbotToolService::class);
        if ($crm->enabledForChatbot($this->chatbot)) {
            $base['tools'] = array_merge($base['tools'] ?? [], $crm->definitionsForOpenAI($this->chatbot));
        }
        return $base;
    }

    public function generate(): string
    {
        $crm = app(CrmChatbotToolService::class);
        if (! $crm->enabledForChatbot($this->chatbot)) return parent::generate();

        ApiHelper::setOpenAiKey();
        $histories = array_values($this->modifyMessages());
        $body = ['model'=>$this->getEntity()->value,'messages'=>$this->buildHistories($histories)] + $this->tools();
        $result = $this->chat($body);
        $toolCalls = $result->json('choices.0.message.tool_calls') ?: [];
        if ($toolCalls === []) return $result->json('choices.0.message.content') ?: 'Sorry, I can\'t answer that.';

        $calls=[];$toolResults=[];$ecommerceUi=null;$hasKnowledge=false;$hasCrm=false;
        foreach ($toolCalls as $index=>$call) {
            if (!isset($call['function'])) continue;
            $calls[$index]=['index'=>$index]+$call;
            $name=(string)$call['function']['name'];
            if (MarketplaceHelper::isRegistered('chatbot-ecommerce')) {
                $data=app(EcommerceToolService::class)->handleToolCallWithUi($this->chatbot,$name,$call);
                if($data!==null){$ecommerceUi=$data['ui'];$toolResults[]=['content'=>$data['ai_content'],'tool_call_id'=>$call['id']];continue;}
            }
            if (str_starts_with($name,'crm_')) {
                try {
                    $args=json_decode((string)($call['function']['arguments']??'{}'),true)?:[];
                    $data=$crm->execute($this->chatbot,$this->conversation,$name,$args);
                    if($data!==null){$hasCrm=true;$toolResults[]=['content'=>$data['ai_content'],'tool_call_id'=>$call['id']];continue;}
                } catch (\Throwable $e) {
                    $hasCrm=true;$toolResults[]=['content'=>json_encode(['ok'=>false,'error'=>$e->getMessage()]),'tool_call_id'=>$call['id']];continue;
                }
            }
            if ($name==='knowledge_base' && isset($this->embeddings) && $this->embeddings->isNotEmpty()) {
                $hasKnowledge=true;$args=json_decode((string)($call['function']['arguments']??'{}'),true)?:[];
                $content=app(KnowledgeBase::class)->setChatbot($this->chatbot)->call(EntityEnum::from($this->chatbot->getAttribute('ai_embedding_model')),(string)($args['query']??''),$this->embeddings);
                $toolResults[]=['content'=>$content,'tool_call_id'=>$call['id']];
            }
        }
        if ($calls!==[]) $body['messages'][]=['role'=>'assistant','content'=>null,'tool_calls'=>$calls];
        foreach($toolResults as $r)$body['messages'][]=['role'=>'tool','content'=>$r['content'],'tool_call_id'=>$r['tool_call_id']];
        if ($toolResults===[]) return $result->json('choices.0.message.content') ?: 'Sorry, I can\'t answer that.';

        if ($ecommerceUi!==null && !$hasKnowledge && !$hasCrm) {
            $aiText=implode(' ',array_column($toolResults,'content'));
            return '<p>'.e($aiText).'</p>'.$ecommerceUi;
        }
        $body['stream']=true;$body['stream_options']=['include_usage'=>true];$body['tool_choice']='none';
        $response=$this->chat($body)->toPsrResponse();$text='';
        while(!$response->getBody()->eof()){
            $line=$this->crmReadLine($response->getBody());if(!str_starts_with($line,'data:'))continue;$data=trim(substr($line,5));if($data==='[DONE]')break;
            $json=json_decode($data,flags:JSON_THROW_ON_ERROR);if(isset($json->error))throw new Exception($json->error->message);if(isset($json->choices[0]?->delta?->content))$text.=$json->choices[0]->delta->content;
        }
        $answer=$text?:'Sorry, I can\'t answer that.';
        return $ecommerceUi!==null?'<p>'.e($answer).'</p>'.$ecommerceUi:$answer;
    }

    private function crmReadLine(StreamInterface $stream): string
    { $buffer='';while(!$stream->eof()){if(''===($byte=$stream->read(1)))return $buffer;$buffer.=$byte;if($byte==="\n")break;}return $buffer; }
}
