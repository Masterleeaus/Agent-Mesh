# Blueprint v4 Step03 vs Installer 1.7.8 Root Manifest

Titan Signal Engine uses the current Titan Installer 1.7.8 root package contract in `extension.json`:

```json
{
  "schema": "titan-extension-v1",
  "slug": "titan-signal-engine",
  "folder": "TitanSignalEngine",
  "provider": "App\\Extensions\\TitanSignalEngine\\System\\TitanSignalEngineServiceProvider"
}
```

The supplied Blueprint v4 Step03 `validate_manifest.py` still validates `extension.json` against the older lightweight MagicAI schema that permits only `name`, `type`, `version`, `description`, and `support_telegram`. Its own `templates/governed-capability/extension.json`, however, already demonstrates the newer `titan-extension-v1` contract.

These two root schemas are mutually exclusive because the legacy schema rejects the Installer 1.7.8 fields as additional properties.

For this release candidate:

- the actual installable package keeps the Installer 1.7.8 root manifest;
- `extension.manifest.json` is validated directly against Blueprint v4 `schemas/extension-manifest.schema.json`;
- Blueprint package secret/filesystem scanning and architecture scanning run against the real package;
- the legacy root-manifest validator is recorded as **incompatible**, not falsely reported as passing.

The Blueprint should be upgraded so its governed-engine template and root validator accept the same `titan-extension-v1` contract already used by its governed-capability template.
