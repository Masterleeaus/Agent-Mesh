<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

final readonly class RewindCorrelationReceipt
{
    /** @param list<string> $rootCausationIds */
    public function __construct(
        public string $scope,
        public ?int $tenantCompanyId,
        public ?string $traceId,
        public ?string $correlationId,
        public array $rootCausationIds,
        public int $eventCount,
        public ?int $hotEventCount = null,
        public ?int $coldEventCount = null,
        public bool $coldHistoryComplete = true,
        public int $coldFailureCount = 0,
    ) {
    }

    public function storageTier(): string
    {
        $hot = $this->hotEventCount ?? $this->eventCount;
        $cold = $this->coldEventCount ?? 0;
        if ($hot > 0 && $cold > 0) return 'mixed';
        if ($cold > 0) return 'cold';
        return 'hot';
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        $hot = $this->hotEventCount ?? $this->eventCount;
        $cold = $this->coldEventCount ?? 0;
        return [
            'scope' => $this->scope,
            'tenant_company_id' => $this->tenantCompanyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'root_causation_ids' => $this->rootCausationIds,
            'event_count' => $this->eventCount,
            'hot_event_count' => $hot,
            'cold_event_count' => $cold,
            'storage_tier' => $this->storageTier(),
            'cold_history_complete' => $this->coldHistoryComplete,
            'cold_failure_count' => $this->coldFailureCount,
        ];
    }
}
