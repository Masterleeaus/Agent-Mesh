<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryReceipt;

interface SignalDeliveryRedriveContract
{
    public function redrive(string $deliveryId, string $reason, SignalContext $context): SignalDeliveryReceipt;

    /** @return array{selected:int,redriven:int,skipped:int,delivery_ids:list<string>} */
    public function redriveBatch(
        string $scope,
        ?int $tenantCompanyId,
        ?string $subscriberKey,
        int $limit,
        string $reason,
        SignalContext $context,
    ): array;
}
