# Titan Rewind Evidence & Custody

Evidence packages use canonical SHA-256 content hashes plus RSA-SHA256 signatures. v0.9 uses a rotating keyring: one active private key signs new packages while retained public keys verify historical packages after rotation.

Custody actions include generated, viewed, downloaded, exported, verified, signature_verified, superseded, legal_hold_applied, legal_hold_released, purge_blocked and purge_executed.

Private key bytes are never written to Rewind tables. Rewind persists only public-key fingerprints and lifecycle metadata. Compliance export fails if package hash/signature verification fails.
