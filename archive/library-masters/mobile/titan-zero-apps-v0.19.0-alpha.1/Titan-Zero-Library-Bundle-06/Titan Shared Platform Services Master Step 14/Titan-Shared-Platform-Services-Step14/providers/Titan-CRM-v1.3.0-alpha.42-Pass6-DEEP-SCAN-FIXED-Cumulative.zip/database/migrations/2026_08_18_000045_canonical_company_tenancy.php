<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * CRM Core-owned tables only. Extracted Field, Locker, Ledger, Pay and
     * Autonomy tables are deliberately excluded so this migration cannot
     * rewrite another extension's storage contract.
     *
     * @var list<string>
     */
    private const CORE_COMPANY_TABLES = [
        'crm_companies','crm_contacts','crm_leads','crm_pipelines','crm_pipeline_stages','crm_deals','crm_activities',
        'crm_projects','crm_tasks','crm_events','crm_products','crm_documents','crm_proposals','crm_estimates','crm_invoices',
        'crm_notes','crm_tags','crm_taggables','crm_custom_fields','crm_custom_field_values','crm_sales_document_lines',
        'crm_settings','crm_audit_log','crm_notification_outbox','crm_merge_log','crm_automation_rules','crm_automation_runs',
        'crm_portal_grants','crm_portal_events','crm_portal_comments','crm_import_batches','crm_import_rows','crm_portal_files',
        'crm_api_keys','crm_webhooks','crm_webhook_deliveries','crm_email_connections','crm_email_messages','crm_record_shares',
        'crm_retention_policies','crm_privacy_requests','crm_chatbot_identities','crm_chatbot_settings','crm_chatbot_session_grants',
        'crm_chatbot_activity_links','crm_mobile_identity_links','crm_capability_operations','crm_business_hours','crm_business_locations',
        'crm_business_configuration_drafts','crm_domain_signal_outbox','crm_capability_rate_limits','crm_import_impact_reports',
        'crm_read_projection_state','crm_read_projection_records','crm_customer_identities','crm_external_identities',
        'crm_duplicate_reviews','crm_merge_snapshots','crm_sales_document_render_jobs','crm_invoice_settlement_references',
        'crm_credit_notes','crm_credit_note_lines','crm_receivable_reconciliation_issues','crm_read_projection_dead_letters',
        'crm_read_projection_rebuild_checkpoints','crm_portal_sessions','crm_import_rollback_journal','crm_export_audit_journal',
        'crm_read_projection_search_terms',
    ];

    public function up(): void
    {
        $this->repairPipelineStageCompanyIds('tenant_company_id');
        $this->repairDeterministicCompanyIds('tenant_company_id');

        // contacts/deals historically used company_id for the linked CRM customer company.
        // Move that relationship out of the canonical tenant column before the tenant rename.
        foreach (['crm_contacts','crm_deals'] as $table) {
            if (! Schema::hasTable($table)) continue;
            $hasLegacyTenant = Schema::hasColumn($table, 'tenant_company_id');
            $hasCompany = Schema::hasColumn($table, 'company_id');
            $hasCustomerCompany = Schema::hasColumn($table, 'customer_company_id');

            if ($hasLegacyTenant && $hasCompany && ! $hasCustomerCompany) {
                Schema::table($table, fn (Blueprint $t): mixed => $t->renameColumn('company_id', 'customer_company_id'));
            } elseif ($hasLegacyTenant && $hasCompany && $hasCustomerCompany) {
                throw new \RuntimeException("CRM company tenancy migration found ambiguous company columns on {$table}.");
            }
        }

        foreach (self::CORE_COMPANY_TABLES as $table) {
            if (! Schema::hasTable($table)) continue;

            $hasLegacy = Schema::hasColumn($table, 'tenant_company_id');
            $hasCanonical = Schema::hasColumn($table, 'company_id');

            if ($hasLegacy && $hasCanonical) {
                throw new \RuntimeException("CRM company tenancy migration found both tenant_company_id and company_id on {$table}.");
            }
            if ($hasLegacy) {
                Schema::table($table, fn (Blueprint $t): mixed => $t->renameColumn('tenant_company_id', 'company_id'));
            }
        }

        $this->repairPipelineStageCompanyIds('company_id');
        $this->repairDeterministicCompanyIds('company_id');
        $this->assertNoUnscopedCoreRows();
        $this->enforceNotNullCompanyIds();
    }

    public function down(): void
    {
        foreach (array_reverse(self::CORE_COMPANY_TABLES) as $table) {
            if (! Schema::hasTable($table)) continue;
            if (Schema::hasColumn($table, 'company_id') && ! Schema::hasColumn($table, 'tenant_company_id')) {
                // Restore nullability before returning to the historical compatibility schema.
                try {
                    Schema::table($table, fn (Blueprint $t): mixed => $t->unsignedBigInteger('company_id')->nullable()->change());
                } catch (Throwable) {
                    // The rename remains reversible even on hosts that cannot alter nullability in-place.
                }
                Schema::table($table, fn (Blueprint $t): mixed => $t->renameColumn('company_id', 'tenant_company_id'));
            }
        }

        foreach (['crm_contacts','crm_deals'] as $table) {
            if (! Schema::hasTable($table)) continue;
            if (Schema::hasColumn($table, 'customer_company_id') && ! Schema::hasColumn($table, 'company_id')) {
                Schema::table($table, fn (Blueprint $t): mixed => $t->renameColumn('customer_company_id', 'company_id'));
            }
        }
    }

    private function repairPipelineStageCompanyIds(string $column): void
    {
        if (! Schema::hasTable('crm_pipeline_stages') || ! Schema::hasTable('crm_pipelines')) return;
        if (! Schema::hasColumn('crm_pipeline_stages', $column) || ! Schema::hasColumn('crm_pipelines', $column)) return;

        DB::table('crm_pipeline_stages as s')
            ->join('crm_pipelines as p', 'p.id', '=', 's.pipeline_id')
            ->whereNull('s.'.$column)
            ->whereNotNull('p.'.$column)
            ->select('s.id', 'p.'.$column.' as company_id')
            ->orderBy('s.id')
            ->chunk(250, function ($rows) use ($column): void {
                foreach ($rows as $row) {
                    DB::table('crm_pipeline_stages')->where('id', $row->id)->update([$column => (int) $row->company_id]);
                }
            });
    }

    private function repairDeterministicCompanyIds(string $column): void
    {
        if (! Schema::hasTable('users') || ! Schema::hasColumn('users', 'company_id')) return;

        foreach (self::CORE_COMPANY_TABLES as $table) {
            if (! Schema::hasTable($table) || ! Schema::hasColumn($table, $column) || ! Schema::hasColumn($table, 'user_id')) continue;

            DB::table($table)->whereNull($column)->whereNotNull('user_id')->orderBy('id')->select('id', 'user_id')->chunkById(250, function ($rows) use ($table, $column): void {
                foreach ($rows as $row) {
                    $companyId = (int) (DB::table('users')->where('id', (int) $row->user_id)->value('company_id') ?? 0);
                    if ($companyId > 0) DB::table($table)->where('id', $row->id)->update([$column => $companyId]);
                }
            });
        }
    }

    private function assertNoUnscopedCoreRows(): void
    {
        foreach (self::CORE_COMPANY_TABLES as $table) {
            if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'company_id')) continue;
            $count = (int) DB::table($table)->whereNull('company_id')->count();
            if ($count > 0) {
                throw new \RuntimeException("CRM canonical company tenancy refused to continue: {$table} contains {$count} row(s) without company_id.");
            }
        }
    }

    private function enforceNotNullCompanyIds(): void
    {
        foreach (self::CORE_COMPANY_TABLES as $table) {
            if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'company_id')) continue;
            Schema::table($table, fn (Blueprint $t): mixed => $t->unsignedBigInteger('company_id')->nullable(false)->change());
        }
    }
};
