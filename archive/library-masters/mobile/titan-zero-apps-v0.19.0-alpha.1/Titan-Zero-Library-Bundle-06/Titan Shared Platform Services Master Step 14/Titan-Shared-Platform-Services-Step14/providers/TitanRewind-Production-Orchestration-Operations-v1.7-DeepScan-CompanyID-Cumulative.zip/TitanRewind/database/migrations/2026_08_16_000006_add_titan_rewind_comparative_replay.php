<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_rewind_replay_runs')) return;
        Schema::table('titan_rewind_replay_runs', function (Blueprint $table): void {
            if (!Schema::hasColumn('titan_rewind_replay_runs','operation_id')) $table->uuid('operation_id')->nullable()->unique()->after('run_uuid');
            if (!Schema::hasColumn('titan_rewind_replay_runs','mutation_policy')) $table->string('mutation_policy',20)->default('deny')->after('target_environment');
            if (!Schema::hasColumn('titan_rewind_replay_runs','network_policy')) $table->string('network_policy',30)->default('deny-all')->after('mutation_policy');
            if (!Schema::hasColumn('titan_rewind_replay_runs','deterministic_seed')) $table->string('deterministic_seed',191)->nullable()->after('network_policy');
            if (!Schema::hasColumn('titan_rewind_replay_runs','reproducibility')) $table->string('reproducibility',40)->nullable()->index()->after('deterministic_seed');
            if (!Schema::hasColumn('titan_rewind_replay_runs','result_hash')) $table->char('result_hash',64)->nullable()->index()->after('reproducibility');
            if (!Schema::hasColumn('titan_rewind_replay_runs','decision_reexecution_performed')) $table->boolean('decision_reexecution_performed')->default(false)->after('result_hash');
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('titan_rewind_replay_runs')) return;
        $columns = ['operation_id','mutation_policy','network_policy','deterministic_seed','reproducibility','result_hash','decision_reexecution_performed'];
        $drop = array_values(array_filter($columns, static fn(string $column): bool => Schema::hasColumn('titan_rewind_replay_runs',$column)));
        if ($drop !== []) Schema::table('titan_rewind_replay_runs', static function (Blueprint $table) use ($drop): void { $table->dropColumn($drop); });
    }
};
