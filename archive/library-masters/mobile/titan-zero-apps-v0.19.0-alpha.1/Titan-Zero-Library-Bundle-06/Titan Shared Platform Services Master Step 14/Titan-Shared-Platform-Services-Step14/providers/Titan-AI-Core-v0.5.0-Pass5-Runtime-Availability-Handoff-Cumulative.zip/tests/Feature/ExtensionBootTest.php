<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\Tests\Feature;

use App\Extensions\TitanAICore\System\Contracts\OrchestratorContract;
use App\Extensions\TitanAICore\System\Contracts\PlanValidatorContract;
use App\Extensions\TitanAICore\System\Contracts\RuntimeManagerContract;
use App\Extensions\TitanAICore\System\Contracts\TrustedPrincipalResolverContract;
use App\Extensions\TitanAICore\System\Contracts\PlanRepositoryContract;
use App\Extensions\TitanAICore\System\Contracts\ModelProfileRepositoryContract;
use App\Extensions\TitanAICore\System\TitanAICoreServiceProvider;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\View;
use Tests\TestCase;

final class ExtensionBootTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->app->register(TitanAICoreServiceProvider::class);
    }

    public function test_provider_boots_routes_views_and_core_bindings(): void
    {
        self::assertTrue($this->app->bound(RuntimeManagerContract::class));
        self::assertTrue($this->app->bound(OrchestratorContract::class));
        self::assertTrue($this->app->bound(PlanValidatorContract::class));
        self::assertTrue($this->app->bound(TrustedPrincipalResolverContract::class));
        self::assertTrue($this->app->bound(PlanRepositoryContract::class));
        self::assertTrue($this->app->bound(ModelProfileRepositoryContract::class));

        self::assertNotNull(Route::getRoutes()->getByName('dashboard.user.titan.ai.core.index'));
        self::assertNotNull(Route::getRoutes()->getByName('dashboard.admin.titan.ai.core.index'));
        self::assertNotNull(Route::getRoutes()->getByName('dashboard.admin.titan.ai.core.health'));

        self::assertTrue(View::exists('titan-ai-core::index'));
        self::assertTrue(View::exists('titan-ai-core::admin'));
        self::assertTrue(View::exists('titan-ai-core::layouts.standalone'));
    }
}
