<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Contracts;
interface CustomFieldRepositoryContract { public function definitions(int $userId,array $filters=[]): array; public function createDefinition(int $userId,array $data): array; public function setValue(int $userId,string $fieldPublicId,string $subjectType,string $subjectPublicId,mixed $value): array; }
