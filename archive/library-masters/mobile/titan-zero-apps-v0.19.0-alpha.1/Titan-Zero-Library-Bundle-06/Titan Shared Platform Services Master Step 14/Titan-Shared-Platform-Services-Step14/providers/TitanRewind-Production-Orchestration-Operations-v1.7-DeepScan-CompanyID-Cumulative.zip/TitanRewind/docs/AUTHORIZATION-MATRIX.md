# Titan Rewind Authorization Matrix

| Permission | Scope | Operations |
|---|---|---|
| `rewind.trace.view` | tenant trace/evidence | trace catalogue, trace reconstruction, evidence view |
| `rewind.forensics.view` | tenant trace/case | drift/root-cause/assistant analysis |
| `rewind.integrity.verify` | tenant trace | integrity verification |
| `rewind.replay.run` | tenant trace | historical/current-state/counterfactual/model/policy/knowledge replay |
| `rewind.evidence.generate` | tenant trace/case | signed evidence generation |
| `rewind.evidence.export` | tenant evidence package | evidence/compliance download and export |
| `rewind.recovery.propose` | tenant trace/recovery plan | recovery proposal creation/view |
| `rewind.recovery.request-approval` | tenant recovery plan | Titan Governance handoff/refresh |
| `rewind.legal-hold.manage` | tenant trace/case/package/investigation | apply/release legal holds |
| `rewind.admin` | Rewind operational admin surface | operational metadata only |

HTTP routes fail closed through `RequireRewindPermission`. Rewind data services additionally scope all durable lookups by `tenant_company_id`; legal-hold creation proves the referenced object exists in the same tenant before recording the hold. Super Admin permission does not itself grant cross-tenant evidence payload access.


## MagicAI/Titan host authority bridge

The host compatibility order is:

1. `isSuperAdmin() === true` → all Rewind permissions are accepted, but tenant/object scope still applies.
2. Explicit Rewind grant via `can()`, `checkPermission()` or `hasPermissionTo()` → requested permission accepted.
3. `isAdmin() === true` → compatibility fallback only for `rewind.trace.view`, `rewind.forensics.view`, and `rewind.integrity.verify`.
4. Ordinary actors remain denied unless an explicit Rewind grant exists.

The delegated-admin fallback deliberately excludes replay, evidence generation/export, recovery proposal/approval, legal-hold management and `rewind.admin`.
