<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);function fail_pc(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function same_pc(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_pc($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
$f=$root.'/System/DecisionIntelligence/GovernancePolicyComplianceProjector.php';if(!is_file($f))fail_pc('missing production file');require_once $f;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernancePolicyComplianceProjector;
$p=new GovernancePolicyComplianceProjector();
$inspection=['status'=>'HEALTHY','sources'=>[
 'titan-assurance'=>['status'=>'HEALTHY','required'=>false,'policies'=>[
  ['policy_id'=>'licence.valid','policy_version'=>'3','status'=>'COMPLIANT','severity'=>'HIGH','observed_at'=>'2026-08-21T01:59:00+10:00','expires_at'=>'2026-08-22T00:00:00+10:00','evidence_refs'=>['ev-1']],
  ['policy_id'=>'safety.block','policy_version'=>'9','status'=>'POLICY_BLOCKED','severity'=>'CRITICAL','observed_at'=>'2026-08-21T02:10:00+10:00','reason_codes'=>['MISSING_CERT']],
 ]],
 'titan-risk'=>['status'=>'UNAVAILABLE','required'=>false,'reason'=>'NOT_INSTALLED','policies'=>[]],
]];
$out=$p->project($inspection,['now'=>'2026-08-21T02:11:00+10:00','stale_after_seconds'=>300]);same_pc('NON_COMPLIANT',$out['status'],'blocking policy must drive non-compliance');same_pc('safety.block',$out['items'][0]['policy_id'],'critical blocking policy first');same_pc(1,$out['stale_count'],'older observation becomes stale');same_pc(1,$out['unavailable_source_count'],'optional unavailable source remains visible');
$none=$p->project(['status'=>'HEALTHY','sources'=>[]]);same_pc('UNAVAILABLE',$none['status'],'no policy observations must not be called compliant');
echo "PASS: Governance policy compliance projector\n";
