<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Repositories;

use App\Extensions\TitanAICore\System\Contracts\ModelProfileRepositoryContract;
use Illuminate\Database\ConnectionInterface;

final class DatabaseModelProfileRepository implements ModelProfileRepositoryContract
{
    public function __construct(private readonly ConnectionInterface $database) {}

    public function listForTenant(string $tenantCompanyId, bool $allowGlobalFallback = false, int $limit = 250): array
    {
        $limit = max(1, min(1000, $limit));
        $query = $this->database->table('titan_ai_core_model_profiles');

        if ($allowGlobalFallback) {
            $query->where(static function ($q) use ($tenantCompanyId): void {
                $q->where('company_id', $tenantCompanyId)
                    ->orWhere('tenant_company_id', $tenantCompanyId)
                    ->orWhere(static function ($global): void { $global->whereNull('company_id')->whereNull('tenant_company_id'); });
            });
        } else {
            $query->where(static function ($q) use ($tenantCompanyId): void {
                $q->where('company_id', $tenantCompanyId)->orWhere('tenant_company_id', $tenantCompanyId);
            });
        }

        return array_map(static fn ($row): array => (array) $row, $query->limit($limit)->get()->all());
    }
}
