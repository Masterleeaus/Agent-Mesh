<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class RuntimeReceipt { public function __construct(public string $planId, public string $operationId, public string $status, public string $receiptId) {} }
