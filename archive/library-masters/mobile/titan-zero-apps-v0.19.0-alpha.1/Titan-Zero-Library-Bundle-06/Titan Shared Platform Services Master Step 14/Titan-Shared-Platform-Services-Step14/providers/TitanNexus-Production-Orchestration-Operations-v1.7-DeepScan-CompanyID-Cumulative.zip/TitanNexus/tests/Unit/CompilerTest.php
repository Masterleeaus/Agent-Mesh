<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanNexus\Unit;

use App\Extensions\TitanNexus\System\Adapters\Platform\PlatformReadinessAdapter;
use App\Extensions\TitanNexus\System\Contracts\VerticalDefinitionSourceContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompilationStatus;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Services\DeterministicNexusCompiler;
use App\Extensions\TitanNexus\System\Services\NexusManager;
use App\Extensions\TitanNexus\System\Services\SemanticNexusValidator;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;
use RuntimeException;

final class CompilerTest extends TestCase
{
    public function test_compiler_is_deterministic_and_business_overrides_vertical_defaults(): void
    {
        $profile = $this->profile([
            'operations' => ['evidence' => ['photos']],
            'billing' => ['currency' => 'AUD'],
        ]);
        $definition = VerticalDefinition::fromArray([
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'knowledge_snapshot_version' => 'au-vic-2026.08',
            'sections' => [
                'operations' => ['evidence' => ['photos', 'signature'], 'recurring' => true],
                'billing' => ['currency' => 'USD', 'tax_mode' => 'exclusive'],
            ],
        ]);

        $compiler = new DeterministicNexusCompiler('0.3.0');
        $first = $compiler->compile($profile, $definition, '1');
        $second = $compiler->compile($profile, $definition, '1');

        self::assertSame($first->outputHash(), $second->outputHash());
        self::assertSame('AUD', $first->sections()['billing']['currency']);
        self::assertSame('exclusive', $first->sections()['billing']['tax_mode']);
        self::assertSame(['photos'], $first->sections()['operations']['evidence']);
        self::assertTrue($first->sections()['operations']['recurring']);
        self::assertSame($definition->fingerprint(), $first->sourceVerticalHash());
    }

    public function test_empty_business_sections_preserve_vertical_defaults(): void
    {
        $profile = $this->profile([]);
        $definition = VerticalDefinition::fromArray([
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'knowledge_snapshot_version' => null,
            'sections' => ['operations' => ['recurring' => true]],
        ]);

        $config = (new DeterministicNexusCompiler('0.3.0'))->compile($profile, $definition, '1');

        self::assertTrue($config->sections()['operations']['recurring']);
    }

    public function test_compiler_rejects_vertical_identity_or_version_drift(): void
    {
        $profile = $this->profile([]);
        $compiler = new DeterministicNexusCompiler('0.3.0');

        $this->expectException(InvalidArgumentException::class);
        $compiler->compile($profile, VerticalDefinition::fromArray([
            'vertical_id' => 'plumbing',
            'vertical_version' => '2026.08',
            'knowledge_snapshot_version' => null,
            'sections' => [],
        ]), '1');
    }

    public function test_manager_resolves_vertical_once_and_returns_new_compiled_aggregate(): void
    {
        $profile = $this->profile(['billing' => ['currency' => 'AUD']]);
        $source = new class implements VerticalDefinitionSourceContract {
            public int $calls = 0;

            public function resolve(BusinessProfile $profile): VerticalDefinition
            {
                $this->calls++;
                return VerticalDefinition::fromArray([
                    'vertical_id' => $profile->verticalId(),
                    'vertical_version' => $profile->verticalVersion(),
                    'knowledge_snapshot_version' => 'au-vic-2026.08',
                    'sections' => ['billing' => ['currency' => 'USD']],
                ]);
            }
        };

        $manager = new NexusManager(new DeterministicNexusCompiler('0.3.0'), $source, new SemanticNexusValidator(new PlatformReadinessAdapter()));
        $draft = $manager->newDraft($profile, $this->trace(), '44444444-4444-4444-8444-444444444444');
        $compiled = $manager->compileDraft($draft, '1');

        self::assertSame(1, $source->calls);
        self::assertSame(CompilationStatus::Draft, $draft->status());
        self::assertSame(CompilationStatus::Compiled, $compiled->status());
        self::assertSame('AUD', $compiled->compiledConfiguration()?->sections()['billing']['currency']);
    }

    private function profile(array $sections): BusinessProfile
    {
        return BusinessProfile::fromArray([
            'tenant_company_id' => 42,
            'profile_version' => '2.0.0',
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
            'timezone' => 'Australia/Melbourne',
            'sections' => $sections,
        ]);
    }

    private function trace(): TraceContext
    {
        return TraceContext::fromArray([
            'tenant_company_id' => 42,
            'trace_id' => '11111111-1111-4111-8111-111111111111',
            'correlation_id' => '22222222-2222-4222-8222-222222222222',
            'causation_id' => '33333333-3333-4333-8333-333333333333',
        ]);
    }
}
