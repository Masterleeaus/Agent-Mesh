<?php

declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Services;
use App\Extensions\TitanRewind\System\Models\RewindRuntimeState;
use App\Extensions\TitanRewind\System\Runtime\RewindOperationalState;
final class RewindRuntimeStateService
{
    public function current(): RewindOperationalState
    {
        if (!(bool) config('titan-rewind.enabled',true)) return RewindOperationalState::from('DISABLED');
        $row=RewindRuntimeState::query()->where('scope_key','global')->first();
        return RewindOperationalState::from((string)($row?->state ?? 'ACTIVE'));
    }
    public function set(string $state, ?string $reason=null, ?int $actorId=null): RewindRuntimeState
    {
        $state=RewindOperationalState::from($state);
        return RewindRuntimeState::query()->updateOrCreate(['scope_key'=>'global'],['state'=>$state->value(),'reason'=>$reason,'updated_by_id'=>$actorId]);
    }
}
