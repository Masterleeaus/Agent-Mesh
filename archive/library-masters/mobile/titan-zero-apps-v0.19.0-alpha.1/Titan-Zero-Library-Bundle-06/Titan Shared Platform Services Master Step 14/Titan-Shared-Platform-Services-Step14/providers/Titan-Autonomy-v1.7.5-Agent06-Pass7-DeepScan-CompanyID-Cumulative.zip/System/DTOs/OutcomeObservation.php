<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\DTOs;

use App\Extensions\TitanAutonomy\System\Enums\UserResponseClass;

final readonly class OutcomeObservation
{
    public function __construct(
        public UserResponseClass $userResponse,
        public bool $executionSucceeded = true,
        public bool $reversed = false,
        public bool $unresolvedAssuranceIncident = false,
        public bool $materialEdit = false,
        public bool $minorEditQualifies = false,
        /** Optional governed regression cause supplied only by server-side outcome evaluators. */
        public ?string $regressionCause = null,
    ) {}
}
