<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Repositories;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Contracts\ContactRepositoryContract;
use App\Extensions\Crm\System\Support\CrmNormalizer;
use App\Extensions\Crm\System\Services\{CrmIdentityAuthorityService,CrmDuplicateDetector,CrmDuplicateReviewService};
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
final class EloquentContactRepository implements ContactRepositoryContract
{
    public function __construct(private ConnectionInterface $db, private CrmIdentityAuthorityService $identity, private CrmDuplicateDetector $duplicates, private CrmDuplicateReviewService $reviews) {}
    public function search(int $userId,array $filters=[]): array
    {
        $q=$this->db->table(config('crm.tables.contacts'))->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at');
        if(($filters['q']??null)!==null){$term='%'.trim((string)$filters['q']).'%';$q->where(fn($x)=>$x->where('first_name','like',$term)->orWhere('last_name','like',$term)->orWhere('email','like',$term)->orWhere('phone','like',$term));}
        return $q->orderBy('first_name')->limit(min((int)($filters['limit']??100),250))->get()->map(fn($r)=>(array)$r)->all();
    }
    public function create(int $userId,array $data): array
    {
        $companyId=null;
        if(isset($data['company_public_id'])){$companyId=$this->db->table(config('crm.tables.companies'))->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$data['company_public_id'])->whereNull('deleted_at')->value('id');if(!$companyId)throw ValidationException::withMessages(['company_public_id'=>['CRM company not found.']]);}
                $email=CrmNormalizer::email($data['email']??null);$phone=CrmNormalizer::phone($data['phone']??null);$candidates=$this->duplicates->contactCandidates($userId,$email,$phone);$publicId=(string)Str::ulid();
        $root=$companyId?(string)($this->db->table(config('crm.tables.companies'))->where('company_id',CrmCompanyScope::companyId($userId))->where('id',$companyId)->value('customer_unification_id')??''):(string)Str::ulid();if($root==='')$root=(string)Str::ulid();
        if(($data['is_primary']??false)&&$companyId){$this->db->table(config('crm.tables.contacts'))->where('company_id', CrmCompanyScope::companyId($userId))->where('customer_company_id',$companyId)->whereNull('deleted_at')->update(['is_primary'=>false,'updated_at'=>now()]);}
        $id=$this->db->table(config('crm.tables.contacts'))->insertGetId(['public_id'=>$publicId,'customer_unification_id'=>$root,'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'customer_company_id'=>$companyId,'first_name'=>(string)$data['first_name'],'last_name'=>$data['last_name']??null,'email'=>$email,'normalized_email'=>$email,'phone'=>$phone,'normalized_phone'=>$phone,'role'=>$data['role']??null,'is_primary'=>(bool)($data['is_primary']??false),'meta'=>isset($data['meta'])?json_encode($data['meta']):null,'created_at'=>now(),'updated_at'=>now()]);
        $this->identity->syncSubjectIdentities($userId,'contact',$publicId,$root,$email,$phone);foreach($candidates as $candidate)if(isset($candidate['public_id']))$this->reviews->queueForPair($userId,'contact',$publicId,'contact',(string)$candidate['public_id']);
        return (array)$this->db->table(config('crm.tables.contacts'))->where('id',$id)->first();
    }

    public function update(int $userId, string $publicId, array $data): array
    {
        $table = config('crm.tables.contacts');
        $current = $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id', $publicId)->whereNull('deleted_at')->first();
        if (! $current) abort(404, 'CRM contact not found.');
        $companyId = $current->customer_company_id;
        if (array_key_exists('company_public_id', $data)) {
            $companyId = $data['company_public_id'] ? $this->db->table(config('crm.tables.companies'))->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$data['company_public_id'])->whereNull('deleted_at')->value('id') : null;
            if ($data['company_public_id'] && ! $companyId) throw ValidationException::withMessages(['company_public_id'=>['CRM company not found.']]);
        }
        $email = CrmNormalizer::email($data['email'] ?? $current->email);
        $phone = CrmNormalizer::phone($data['phone'] ?? $current->phone);
        $primary = array_key_exists('is_primary', $data) ? (bool) $data['is_primary'] : (bool) $current->is_primary;
        if ($primary && $companyId) {
            $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('customer_company_id',$companyId)->where('public_id','!=',$publicId)->whereNull('deleted_at')->update(['is_primary'=>false,'updated_at'=>now()]);
        }
        $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->update([
            'customer_company_id'=>$companyId,
            'first_name'=>(string)($data['first_name'] ?? $current->first_name),
            'last_name'=>$data['last_name'] ?? $current->last_name,
            'email'=>$email,'normalized_email'=>$email,
            'phone'=>$phone,'normalized_phone'=>$phone,
            'role'=>$data['role'] ?? $current->role,
            'is_primary'=>$primary,
            'updated_at'=>now(),
        ]);
        $root=$this->identity->ensureRootForContact($userId,$publicId,$companyId);$this->identity->syncSubjectIdentities($userId,'contact',$publicId,$root,$email,$phone);foreach($this->duplicates->contactCandidates($userId,$email,$phone) as $candidate)if(isset($candidate['public_id'])&&(string)$candidate['public_id']!==$publicId)$this->reviews->queueForPair($userId,'contact',$publicId,'contact',(string)$candidate['public_id']);
        return (array) $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->first();
    }
}
