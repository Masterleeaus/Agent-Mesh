# Titan Nexus Versioned Configuration History, Semantic Diff & Recompile Planning — Design

## Goal

Add deterministic comparison and recompile planning to Titan Nexus without provisioning or mutating any owning Titan engine.

## Architecture

Pass 4 treats every compiled configuration as immutable historical evidence. A recompile plan is derived from one compiled parent plus an updated BusinessProfile and the currently resolved VerticalDefinition. Nexus validates and compiles the candidate in memory, computes a deterministic semantic diff, classifies change disposition using explicit vertical recompile policy metadata, and returns a plan artifact. Nothing is provisioned.

## Semantic comparison

The differ compares semantic configuration state only: vertical identity/version, knowledge snapshot version, and compiled `sections`. Tenant ids, source hashes, compiler version, configuration version, and output hash are provenance/version metadata and are intentionally excluded from path-level semantic changes.

Associative maps recurse by sorted keys. Lists are atomic values. Added paths are `add`, removed paths are `deprecate`, changed leaves/lists are `modify`, and equal leaves are `unchanged`. Results are canonical and sorted by path then change kind.

## Change disposition

Each change has a separate disposition: `apply`, `requires_approval`, or `blocked`. This avoids conflating the structural change kind with governance treatment. Vertical definitions may optionally publish `recompile_policy.requires_approval_paths` and `recompile_policy.blocked_paths`; entries use exact path or subtree-prefix matching. Blocked wins over approval. If no policy exists, changes default to `apply`, preserving prior vertical fingerprints.

## Recompile planning

`NexusManager::planRecompile()` requires a compiled current compilation, the same tenant in the updated profile and trace, a new UUID, and a candidate configuration version. It creates a child draft with `parent_compilation_uuid`, validates the new profile/vertical, and returns a blocked plan if semantic validation fails. Otherwise it compiles a dry-run child, computes and attaches the diff, and returns a ready plan.

A plan is `blocked` if semantic validation contains errors or any diff entry has `blocked` disposition. It is `requires_approval` if at least one entry requires approval and none is blocked. Otherwise it is `ready`.

## History and lineage

The repository retains existing tenant-scoped history and adds `lineageForTenant()`, which follows `parent_compilation_uuid` within the same tenant, is bounded to 100 records, detects loops, and never performs an unscoped lookup.

## Persistence

The existing `diff_summary` JSON column is activated. `NexusCompilation` can immutably attach/restore a `ConfigurationDiff` and persists it to `diff_summary`. No schema migration is required for the diff itself.

## Safety boundaries

Pass 4 must not call Command Bus, mutate CRM/Workforce/PWAs, emit Signals, assign autonomy, execute provisioning, or import another Titan extension implementation class.

## Testing

Standalone tests prove deterministic diffing, list atomicity, add/modify/deprecate semantics, policy precedence, backward-compatible VerticalDefinition fingerprints, blocked validation plans, approval plans, parent linkage, immutable current compilation, diff persistence round-trip, and tenant-safe lineage contract. PHPUnit mirrors core behaviors when the host harness is present.
