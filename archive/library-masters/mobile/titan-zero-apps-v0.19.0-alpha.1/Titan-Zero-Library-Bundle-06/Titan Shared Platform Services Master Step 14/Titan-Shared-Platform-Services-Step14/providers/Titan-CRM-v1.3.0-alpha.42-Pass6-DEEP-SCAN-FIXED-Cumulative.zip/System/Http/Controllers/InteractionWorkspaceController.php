<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Integrations\InteractionEngine\{CrmConversationalInteractionService,CrmInteractionJourneyRegistry,CrmInteractionPresentationAdapter,CrmInteractionRecordActionRegistry};
use App\Extensions\Crm\System\Integrations\InteractionEngine\CrmInteractionSurfaceService;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\InteractionEngine\System\Authority\ApprovalSigner;
use App\Extensions\InteractionEngine\System\Command\CommandBus;
use App\Extensions\InteractionEngine\System\Wizard\Command\CommandMapper;
use App\Extensions\InteractionEngine\System\Wizard\Renderer\HybridRenderer;
use App\Extensions\InteractionEngine\System\Wizard\Storage\WizardSessionStoreInterface;
use App\Extensions\InteractionEngine\System\Wizard\UniversalWizardEngine;
use App\Extensions\InteractionEngine\System\Wizard\WizardRegistry;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Route;

final class InteractionWorkspaceController extends Controller
{
    public function __construct(
        private Application $app,
        private CrmInteractionJourneyRegistry $journeys,
        private CrmInteractionSurfaceService $surfaces,
        private CrmConversationalInteractionService $conversation,
        private CrmInteractionPresentationAdapter $presentation,
        private CrmInteractionRecordActionRegistry $recordActions,
        private CrmCompanyScope $companyScope,
    ) {}

    public function chat(Request $request)
    {
        $message=trim((string)$request->input('message',$request->input('typed_message','')));$surface=trim((string)$request->input('surface','all'));$pageContext=(array)$request->input('context',[]);
        if($message==='')return back()->with('status','Tell Titan Zero what you want to do.');
        if($this->surfaces->available()){
            if(!empty($pageContext['record_type'])){
                $action=$this->recordActions->resolve($message,$pageContext);
                if(is_array($action)){
                    $started=$this->conversation->start((string)$action['journey'],$this->companyScope->current(),['requested_message'=>$message,'prefill'=>(array)($action['prefill']??$pageContext)]);
                    return redirect()->route('dashboard.user.crm.interactions.session',(string)$started['session_id'])
                        ->with('interaction_guidance','Titan Zero matched your request to '.$action['label'].' for this record. Confirm or fill the remaining details.');
                }
            }
            $resolved=$this->conversation->resolveIntent($message,$surface);
            if(($resolved['matched']??false)===true && is_array($resolved['journey']??null)){
                $started=$this->conversation->start((string)$resolved['journey']['key'],$this->companyScope->current(),['requested_message'=>$message,'prefill'=>$pageContext]);
                return redirect()->route('dashboard.user.crm.interactions.session',(string)$started['session_id'])
                    ->with('interaction_guidance','Titan Zero matched your request to '.$resolved['journey']['name'].'. Fill or confirm the remaining details.');
            }
        }
        return redirect()->route('dashboard.user.crm.ai.index',['scope'=>'interaction:'.$surface,'seed'=>$message]);
    }

    public function start(Request $request,string $journey)
    {
        $definition=$this->journeys->get($journey);
        if(!$this->surfaces->available())return $this->advancedRedirect($definition);
        if(!$this->bound(WizardRegistry::class)||!$this->bound(UniversalWizardEngine::class)||!$this->bound(WizardSessionStoreInterface::class))return $this->advancedRedirect($definition);
        $wizards=$this->app->make(WizardRegistry::class);
        if(!$wizards->has((string)$definition['wizard']))return $this->advancedRedirect($definition);
        $session=$this->app->make(UniversalWizardEngine::class)->start((string)$definition['wizard'],$this->trustedContext($request,$definition));
        $session->data=array_replace($session->data,$this->declaredPrefill($session->definition->steps,(array)$request->input('prefill',[]),(array)($definition['metadata']['defaults']??[])));
        $this->app->make(WizardSessionStoreInterface::class)->put($session);
        return redirect()->route('dashboard.user.crm.interactions.session',$session->id);
    }

    public function show(Request $request,string $session)
    {
        $wizardSession=$this->authorizedSession($request,$session);
        if($wizardSession instanceof \Illuminate\Http\RedirectResponse)return $wizardSession;
        $definition=$this->journeys->byWizard($wizardSession->definition->id);
        $payload=$this->app->make(HybridRenderer::class)->render($wizardSession);
        $presentation=$this->presentation->present($wizardSession,$payload,$definition);
        return view('crm::interaction.session',[
            'session'=>$wizardSession,
            'payload'=>$payload,
            'presentation'=>$presentation,
            'journey'=>$definition,
            'interactionErrors'=>(array)session('interaction_errors',[]),
            'guidance'=>session('interaction_guidance'),
            'execution'=>session('interaction_execution'),
        ]);
    }

    public function answer(Request $request,string $session)
    {
        $wizardSession=$this->authorizedSession($request,$session);
        if($wizardSession instanceof \Illuminate\Http\RedirectResponse)return $wizardSession;
        $data=(array)$request->input('data',[]);
        foreach((array)($wizardSession->currentStep()['fields']??[]) as $field){
            $id=(string)($field['id']??'');if($id===''||($field['type']??'')!=='array'||!isset($data[$id])||is_array($data[$id]))continue;
            $raw=trim((string)$data[$id]);$decoded=$raw===''?[]:json_decode($raw,true);if(is_array($decoded))$data[$id]=$decoded;
        }
        if((string)$request->input('_action')==='save'){
            $allowed=[];foreach((array)($wizardSession->currentStep()['fields']??[]) as $field){$id=(string)($field['id']??'');if($id!==''&&array_key_exists($id,$data))$allowed[$id]=$data[$id];}
            $wizardSession->data=array_replace($wizardSession->data,$allowed);$wizardSession->history[]=['event'=>'draft_saved','at'=>now()->toIso8601String()];
            $this->app->make(WizardSessionStoreInterface::class)->put($wizardSession);
            return redirect()->route('dashboard.user.crm.interactions.session',$session)->with('interaction_guidance','Draft saved. You can resume this workflow later.');
        }
        $result=$this->app->make(UniversalWizardEngine::class)->submitStep($wizardSession,$data);
        $this->app->make(WizardSessionStoreInterface::class)->put($result->session);
        return redirect()->route('dashboard.user.crm.interactions.session',$session)
            ->with('interaction_errors',$result->errors)
            ->with('interaction_guidance',$result->guidance)
            ->with('interaction_execution',$result->command);
    }

    public function approve(Request $request,string $session)
    {
        $wizardSession=$this->authorizedSession($request,$session);
        if($wizardSession instanceof \Illuminate\Http\RedirectResponse)return $wizardSession;
        abort_unless($wizardSession->stepIndex >= $wizardSession->definition->stepCount(),409,'Interaction is not ready for approval.');
        abort_unless($this->bound(CommandMapper::class)&&$this->bound(ApprovalSigner::class)&&$this->bound(CommandBus::class),503,'Interaction authority runtime is unavailable.');
        $context=$this->companyScope->current();$actor=(string)($context->actorUserId??0);abort_unless($actor!=='0',403);
        $command=$this->app->make(CommandMapper::class)->map($wizardSession);$metadata=(array)($command['metadata']??[]);
        $approval=$this->app->make(ApprovalSigner::class)->issue(
            (string)$command['capability'],(string)$context->companyId,$actor,array_values(array_map('strval',$context->roles)),600,$wizardSession->id
        );
        $command['payload']['_approval']=$approval;
        $command['payload']['_context']=array_replace((array)($command['payload']['_context']??[]),[
            'company_id'=>(string)$context->companyId,'tenant_id'=>(string)$context->companyId,'user_id'=>$actor,'actor_id'=>$actor,'actor_type'=>$context->actorType==='user'?'human':$context->actorType,
            'roles'=>array_values(array_map('strval',$context->roles)),'source_surface'=>$context->sourceSurface,'correlation_id'=>$metadata['correlation_id']??$context->correlationId??$wizardSession->id,
            'causation_id'=>$metadata['causation_id']??$context->correlationId??$wizardSession->id,'idempotency_key'=>$metadata['idempotency_key']??'',
            'wizard_run_id'=>$wizardSession->id,'session_id'=>$wizardSession->id,'device_id'=>$context->deviceId,'privacy_class'=>'tenant_private','autonomy_workflow_key'=>$wizardSession->context['autonomy_workflow_key']??null,
        ]);
        $result=$this->app->make(CommandBus::class)->dispatchResult((string)$command['capability'],(array)$command['payload']);
        if(in_array($result->status,['executed','prepared'],true))$wizardSession->status='completed';
        $this->app->make(WizardSessionStoreInterface::class)->put($wizardSession);
        return redirect()->route('dashboard.user.crm.interactions.session',$session)
            ->with('interaction_guidance',$result->reason??($result->status==='executed'?'Approved and executed.':'Prepared for the owning CRM service.'))
            ->with('interaction_execution',$result->toArray());
    }

    public function advanced(Request $request,string $journey)
    {
        return $this->advancedRedirect($this->journeys->get($journey));
    }

    /** @param list<array<string,mixed>> $steps @return array<string,mixed> */
    private function declaredPrefill(array $steps,array $prefill,array $defaults=[]): array
    {
        $allowed=[];
        foreach($steps as $step)foreach((array)($step['fields']??[]) as $field){$id=(string)($field['id']??'');if($id!=='')$allowed[$id]=true;}
        $values=array_replace($defaults,$prefill);unset($values['company_id'],$values['tenant_id'],$values['user_id'],$values['actor_id']);
        return array_intersect_key($values,$allowed);
    }

    private function authorizedSession(Request $request,string $session): mixed
    {
        if(!$this->bound(WizardSessionStoreInterface::class))return redirect()->route('dashboard.user.crm.index')->with('status','Interaction Engine is unavailable.');
        $value=$this->app->make(WizardSessionStoreInterface::class)->get($session);
        abort_if($value===null,404,'Interaction session not found or expired.');
        $context=$this->companyScope->current();
        abort_unless((string)($value->context['company_id']??'')===(string)$context->companyId,403);
        abort_unless((string)($value->context['user_id']??'')===(string)($context->actorUserId??''),403);
        return $value;
    }

    /** @return array<string,mixed> */
    private function trustedContext(Request $request,array $definition): array
    {
        $context=$this->companyScope->current();$roles=array_values(array_map('strval',$context->roles));
        if($roles===[]){$user=$request->user();if(is_object($user)&&((method_exists($user,'isSuperAdmin')&&$user->isSuperAdmin())||(method_exists($user,'isAdmin')&&$user->isAdmin())))$roles=['owner','admin','manager'];}
        return [
            'company_id'=>(string)$context->companyId,'tenant_id'=>(string)$context->companyId,
            'user_id'=>(string)($context->actorUserId??''),'actor_id'=>(string)($context->actorUserId??''),'actor_type'=>'human',
            'roles'=>$roles,'delegated_scopes'=>[],'source_surface'=>'command','interface'=>'desktop',
            'correlation_id'=>$context->correlationId?:bin2hex(random_bytes(16)),'causation_id'=>$context->correlationId?:null,
            'device_id'=>(string)($context->deviceId??$request->header('X-Device-Id','')),'privacy_class'=>'tenant_private',
            'crm_surface'=>$definition['surface'],'crm_journey_key'=>$definition['key'],
            'authenticated_at'=>$request->hasSession()?(int)($request->session()->get('auth.password_confirmed_at')??0):null,
        ];
    }

    private function advancedRedirect(array $definition)
    {
        $route=(string)($definition['advancedRoute']??'');
        if($route!==''&&Route::has($route)){ $params=array_replace((array)($definition['metadata']['advanced_params']??[]),['advanced'=>1]);return redirect()->route($route,$params); }
        return redirect()->route('dashboard.user.crm.ai.index',['scope'=>'interaction:'.$definition['surface'],'seed'=>'Help me '.$definition['name'].'.']);
    }

    private function bound(string $class): bool { return class_exists($class)&&$this->app->bound($class); }
}
