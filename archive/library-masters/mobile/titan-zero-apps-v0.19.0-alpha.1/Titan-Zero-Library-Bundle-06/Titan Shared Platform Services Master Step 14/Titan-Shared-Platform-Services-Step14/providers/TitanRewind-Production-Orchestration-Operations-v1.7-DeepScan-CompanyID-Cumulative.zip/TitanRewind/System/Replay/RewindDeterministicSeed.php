<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Replay;
final class RewindDeterministicSeed
{
    public function resolve(int|string|null $requested,int $tenantCompanyId,string $traceId,string $mode): string
    {
        if($requested!==null)return (string)$requested;
        return substr(hash('sha256',implode('|',[$tenantCompanyId,$traceId,$mode,'titan-rewind-v1'])),0,16);
    }
}
