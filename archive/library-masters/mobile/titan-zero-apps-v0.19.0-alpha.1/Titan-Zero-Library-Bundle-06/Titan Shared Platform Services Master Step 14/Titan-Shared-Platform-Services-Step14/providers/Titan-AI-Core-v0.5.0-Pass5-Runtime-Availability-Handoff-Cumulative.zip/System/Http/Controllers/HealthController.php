<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Http\Controllers;

use App\Extensions\TitanAICore\System\Contracts\HealthCheckContract;
use Illuminate\Http\JsonResponse;

final class HealthController
{
    public function __invoke(HealthCheckContract $health): JsonResponse
    {
        $result = $health->check();
        $status = ($result['status'] ?? null) === 'healthy_scaffold' ? 200 : 503;

        return response()->json($result, $status);
    }
}
