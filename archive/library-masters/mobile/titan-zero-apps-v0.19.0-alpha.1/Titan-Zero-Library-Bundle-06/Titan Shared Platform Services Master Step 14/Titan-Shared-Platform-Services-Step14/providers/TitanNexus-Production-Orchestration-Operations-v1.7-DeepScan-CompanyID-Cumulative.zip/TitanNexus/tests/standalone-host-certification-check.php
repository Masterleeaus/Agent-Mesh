<?php

declare(strict_types=1);

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
function hcFail(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function hcAssert(bool $condition, string $message): void { if (!$condition) hcFail($message); }
function hcRead(string $relative): string { global $root; $path=$root.'/'.$relative; if (!is_file($path)) hcFail("missing {$relative}"); return (string) file_get_contents($path); }

foreach ([
    'System/Host/TitanInstallerManifestContract.php',
    'System/Host/TitanPackageIntegrityBuilder.php',
    'System/Host/TitanMySqlMigrationCompatibility.php',
    'System/Host/TitanHostAuthorizationAdapter.php',
    'System/Host/TitanMenuCompatibilityAdapter.php',
    'System/Host/NexusMenuRegistrar.php',
    'System/Host/TitanFreshInstallPreflight.php',
] as $file) hcAssert(is_file($root.'/'.$file), "host compatibility file {$file} exists");

$menu = hcRead('System/Host/NexusMenuRegistrar.php');
foreach ([
    'Titan Nexus', 'Overview', 'Business Profile', 'Compilations', 'Validation',
    'Configuration Preview', 'History', 'Recompile / Diff', 'Provisioning Plans', 'Provisioning Receipts',
    'dashboard.user.titan.nexus.overview', 'dashboard.user.titan.nexus.receipts',
] as $token) hcAssert(str_contains($menu, $token), "menu registrar contains {$token}");

require_once $root.'/System/Host/NexusMenuRegistrar.php';
$definitions = \App\Extensions\TitanNexus\System\Host\NexusMenuRegistrar::definitions();
hcAssert(count($definitions) === 10, 'menu registrar exposes one parent and nine children');
foreach ($definitions as $definition) {
    $icon = $definition['icon'] ?? null;
    hcAssert(is_string($icon) && str_starts_with($icon, 'tabler-') && !str_contains($icon, ' '), 'menu icons use host-safe tabler Blade component identifiers');
    hcAssert(($definition['legacy_fields']['icon'] ?? null) === $icon, 'legacy menu icon mirrors canonical icon');
}

$adapter = hcRead('System/Host/TitanMenuCompatibilityAdapter.php');
foreach (['MenuContributionRegistry', "Schema::hasTable('menus')", 'MenuService', 'regenerate', 'preserve'] as $token) {
    hcAssert(str_contains($adapter, $token), "menu compatibility contains {$token}");
}

$provider = hcRead('System/TitanNexusServiceProvider.php');
hcAssert(str_contains($provider, 'NexusMenuRegistrar'), 'provider wires NexusMenuRegistrar');
hcAssert(str_contains($provider, 'registerNavigation'), 'provider registers navigation during boot');

$profile = json_decode(hcRead('certification/exact-host-profile.v1.json'), true, 512, JSON_THROW_ON_ERROR);
hcAssert(($profile['id'] ?? null) === 'titan.host.magicai.installer-1.7.6.v1', 'exact host profile id');
hcAssert(($profile['installer'] ?? null) === '1.7.6', 'exact host installer');
hcAssert(($profile['database'] ?? null) === 'mysql', 'exact host database');

$report = json_decode(hcRead('certification/host-certification-report.template.json'), true, 512, JSON_THROW_ON_ERROR);
hcAssert(($report['schema_version'] ?? null) === '1.0', 'host report schema');
hcAssert(($report['overall_status'] ?? null) === 'NOT_RUN', 'embedded host report template remains NOT_RUN before package sealing');
$expectedStages=['PACKAGE_CERTIFIED','INSTALLER_CERTIFIED','MIGRATION_CERTIFIED','BOOT_CERTIFIED','NAVIGATION_CERTIFIED','AUTHORIZATION_CERTIFIED','RUNTIME_CERTIFIED','UPGRADE_CERTIFIED','UNINSTALL_CERTIFIED'];
hcAssert(array_keys($report['stages'] ?? []) === $expectedStages, 'host report exact stage order');
foreach ($expectedStages as $stage) hcAssert(($report['stages'][$stage]['status'] ?? null) === 'NOT_RUN', "{$stage} remains NOT_RUN in embedded template");

foreach (['tools/verify_nexus_package.php','tools/fresh_install_preflight.php','tools/exact_host_certification.php','docs/HOST-CERTIFICATION.md','docs/FRESH-INSTALL-PREFLIGHT.md','certification/fresh-install-preflight-report.schema.json'] as $file) {
    hcAssert(is_file($root.'/'.$file), "certification artifact {$file} exists");
}

$config = hcRead('config/titan-nexus.php');
hcAssert(str_contains($config, "'version' => '1.0.0-rc.2'"), 'runtime version is release candidate');
hcAssert(str_contains($config, "'compiler_version' => '0.5.0'"), 'compiler semantics remain 0.5.0');

$certToolSource = hcRead('tools/exact_host_certification.php');
hcAssert(str_contains($certToolSource, "'host_profile' => 'titan.host.magicai.installer-1.7.6.v1'"), 'external host report emits canonical host_profile');
hcAssert(!str_contains($certToolSource, "'extension' => 'titan-nexus'"), 'external host report avoids undeclared schema fields');

$manifest = json_decode(hcRead('extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
hcAssert(($manifest['version'] ?? null) === '1.0.0-rc.2', 'manifest release candidate version');
hcAssert(in_array('nexus.host-ready', $manifest['capabilities'] ?? [], true), 'manifest advertises host-ready package capability');
hcAssert(!in_array('nexus.host-certified', $manifest['capabilities'] ?? [], true), 'manifest does not falsely advertise live host certification');

fwrite(STDOUT, "PASS: Titan Nexus standalone host certification checks\n");
