<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface AutonomyAuditSinkContract
{
    public function recordGateDecision(array $event): string;
    public function recordHandshake(array $event): string;
    public function recordRegression(array $event): string;
}
