<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Automation;
final class CrmAutomationConditionEvaluator
{
    public function matches(array $conditions,array $context): bool
    {
        if(array_is_list($conditions)){
            foreach($conditions as $condition){ if(!is_array($condition))return false; $field=(string)($condition['field']??''); $operator=(string)($condition['operator']??'equals'); $expected=$condition['value']??null; $actual=$this->value($context,$field); if(!$this->compare($actual,$operator,$expected))return false; }
            return true;
        }
        foreach($conditions as $key=>$expected) if($this->value($context,(string)$key)!==$expected)return false;
        return true;
    }
    private function value(array $context,string $field): mixed { $value=$context; foreach(explode('.',$field) as $part){if(!is_array($value)||!array_key_exists($part,$value))return null;$value=$value[$part];}return $value; }
    private function compare(mixed $actual,string $operator,mixed $expected): bool
    { return match($operator){'equals'=>$actual==$expected,'not_equals'=>$actual!=$expected,'in'=>in_array($actual,(array)$expected,true),'contains'=>is_array($actual)?in_array($expected,$actual,true):str_contains(mb_strtolower((string)$actual),mb_strtolower((string)$expected)),'greater_than'=>is_numeric($actual)&&is_numeric($expected)&&(float)$actual>(float)$expected,'less_than'=>is_numeric($actual)&&is_numeric($expected)&&(float)$actual<(float)$expected,'is_empty'=>$actual===null||$actual===''||$actual===[],default=>false}; }
}
