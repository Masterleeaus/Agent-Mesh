# Titan Signal Engine v0.20.0-rc.5 — Self-Healing Host Navigation Hotfix

## Live host evidence

Titan Signal Engine v0.20.0-rc.4 installed successfully on the live Titan/MagicAI host using Installer 1.7.8. All 19 rc.4 extension migrations completed, but no Signal menu links appeared in either the authenticated user navigation or Super Admin navigation.

## Root cause

The package contained `SignalUserNavigation` and `SignalAdminNavigation` definitions and Blueprint contribution metadata, but `TitanSignalEngineServiceProvider` never registered those definitions with a host navigation registry and never synchronised MagicAI's database-backed `menus` table. The navigation contract therefore existed only as package metadata and was not consumed by the live host.

## rc.5 correction

- Adds `HostNavigationRegistrar` with modern `MenuContributionRegistry` / generic `ContributionRegistry` registration.
- Adds Installer 1.7.8 / MagicAI `menus` table self-healing fallback.
- Adds migration `2026_08_18_000020_register_signal_host_navigation.php` so an already-installed rc.4 host receives the durable rows during upgrade.
- Adds user link `Signal & Pulse` -> `dashboard.user.titan.signal.engine.index`.
- Adds Super Admin link `Signal Engine` -> `dashboard.admin.titan.signal.engine.index` in the 900+ Super Admin order band.
- Uses `extension = NULL` for the operational menu rows so MagicAI plan-feature gating does not hide them.
- Preserves existing administrator `is_active` choices and existing user ordering; only repairs an old admin row into the Super Admin order band when required.
- Calls `App\Services\Common\MenuService::regenerate()` when available.
- Adds operator repair command `php artisan titan:signal:host-sync`.
- Extends `titan:signal:certify` with a mandatory `runtime.navigation` check so missing host rows cannot be certified silently again.
- Removes the two new unbounded navigation/certification collection reads; duplicate detection now uses `first()` plus aggregate `count()`.

## Scope

This is a host-navigation integration hotfix. It does not alter Signal event schemas, tenant authority, delivery semantics, correlation, Pulse calculations, anomaly behavior, retention behavior, or existing business-domain contracts. Database ownership expands only by one shared host table declaration (`menus`) and one idempotent navigation migration.

## Host certification status

Local/static certification is PASS. Production host certification remains pending until rc.5 is installed and both menu links are visible and `php artisan titan:signal:certify --strict --probe-writes` reports `runtime.navigation: PASS`.
