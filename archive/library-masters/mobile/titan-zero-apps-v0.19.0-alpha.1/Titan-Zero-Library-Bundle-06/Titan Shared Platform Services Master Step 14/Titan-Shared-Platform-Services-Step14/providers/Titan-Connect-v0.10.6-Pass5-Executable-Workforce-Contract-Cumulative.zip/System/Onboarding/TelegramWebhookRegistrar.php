<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Onboarding;

use App\Extensions\TitanConnect\System\Contracts\ProviderHttpClient;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ChannelConnectionMember;
use Illuminate\Support\Str;
use RuntimeException;

final class TelegramWebhookRegistrar
{
    public function __construct(private readonly ProviderHttpClient $http, private readonly ProviderCredentialStore $credentials) {}

    public function register(int $companyId, int $actorId, string $botToken, ?string $displayName = null): ChannelConnection
    {
        $botToken = trim($botToken); if ($botToken === '') throw new RuntimeException('Telegram bot token is required.');
        $base = rtrim((string) config('titan-connect.providers.telegram.api_base_url', 'https://api.telegram.org'), '/');
        $me = $this->http->request('GET', $base.'/bot'.$botToken.'/getMe');
        if (! $me->isSuccessful() || ! (bool) $me->json('ok', false)) throw new RuntimeException('Telegram bot token could not be validated.');
        $botId = trim((string) $me->json('result.id')); if ($botId === '') throw new RuntimeException('Telegram bot identity was missing.');
        $connection = ChannelConnection::query()->firstOrNew(['company_id'=>$companyId,'provider'=>'telegram','external_account_id'=>$botId]);
        if (! $connection->exists) { $connection->uuid=(string) Str::uuid(); $connection->status='paused'; }
        $username=(string) $me->json('result.username',''); $connection->display_name=$displayName ?: ($username !== '' ? '@'.$username : 'Telegram'); $connection->settings=['onboarding'=>'telegram_setWebhook','username'=>$username]; $connection->save();
        ChannelConnectionMember::query()->updateOrCreate(['channel_connection_id'=>$connection->id,'company_id'=>$companyId,'user_id'=>$actorId], ['role'=>'owner','joined_at'=>now(),'left_at'=>null]);
        $secret=Str::random(48); $webhookUrl=route('titan-connect.api.webhooks.handle',['provider'=>'telegram','connection'=>$connection->uuid]);
        $set = $this->http->request('POST', $base.'/bot'.$botToken.'/setWebhook', ['json'=>['url'=>$webhookUrl,'secret_token'=>$secret,'allowed_updates'=>['message','edited_message','business_message','edited_business_message']]]);
        if (! $set->isSuccessful() || ! (bool) $set->json('ok', false)) throw new RuntimeException('Telegram setWebhook registration failed.');
        $this->credentials->store($companyId,$actorId,$connection,['bot_token'=>$botToken,'webhook_secret'=>$secret],true);
        return $connection->fresh('members');
    }
}
