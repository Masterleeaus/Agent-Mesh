<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services\TeamChat;

use App\Extensions\TitanConnect\System\Contracts\CompanyActorDirectory;
use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Events\TeamChat\TeamConversationUpdated;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversationParticipant;
use App\Extensions\TitanConnect\System\Realtime\SafeRealtimeDispatcher;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class BusinessChannelService
{
    public function __construct(
        private readonly WorkCoreAuthorizationGateway $workCore,
        private readonly CompanyActorDirectory $actors,
        private readonly SafeRealtimeDispatcher $realtime,
    ) {
    }

    public function create(int $companyId, int $actorId, array $data, ?string $deviceId = null): TeamConversation
    {
        $memberIds = array_values(array_unique(array_map('intval', [...($data['user_ids'] ?? []), $actorId])));
        $this->actors->assertUsersBelongToCompany($companyId, $memberIds);
        $this->assertLinkedEntity($companyId, $actorId, $data['linked_entity_type'] ?? null, $data['linked_entity_id'] ?? null);

        $slug = Str::slug((string) ($data['slug'] ?? $data['name']));
        if ($slug === '') {
            throw ValidationException::withMessages(['slug' => 'A valid channel slug is required.']);
        }
        if (TeamConversation::query()->where('company_id', $companyId)->where('slug', $slug)->exists()) {
            throw ValidationException::withMessages(['slug' => 'This channel slug is already in use.']);
        }

        return DB::transaction(function () use ($companyId, $actorId, $data, $deviceId, $slug): TeamConversation {
            $conversation = TeamConversation::query()->create([
                'uuid' => (string) Str::uuid(),
                'company_id' => $companyId,
                'name' => trim((string) $data['name']),
                'slug' => $slug,
                'type' => 'channel',
                'description' => $data['description'] ?? null,
                'category' => $data['category'] ?? null,
                'owner_id' => $actorId,
                'visibility' => $data['visibility'] ?? 'private',
                'posting_policy' => $data['posting_policy'] ?? 'members',
                'is_announcement' => (bool) ($data['is_announcement'] ?? false),
                'linked_entity_type' => $data['linked_entity_type'] ?? null,
                'linked_entity_id' => isset($data['linked_entity_id']) ? (string) $data['linked_entity_id'] : null,
                'originating_device_id' => $deviceId,
                'created_by' => $actorId,
                'updated_by' => $actorId,
            ]);

            TeamConversationParticipant::query()->create([
                'conversation_id' => $conversation->id,
                'company_id' => $companyId,
                'user_id' => $actorId,
                'role' => 'owner',
                'joined_at' => now(),
            ]);

            foreach (array_unique(array_map('intval', $data['user_ids'] ?? [])) as $userId) {
                if ($userId === $actorId) {
                    continue;
                }
                TeamConversationParticipant::query()->firstOrCreate(
                    ['conversation_id' => $conversation->id, 'company_id' => $companyId, 'user_id' => $userId],
                    ['role' => 'member', 'joined_at' => now()],
                );
            }

            $this->realtime->dispatch(new TeamConversationUpdated($conversation, 'channel-created', $actorId));
            return $conversation->load('participants');
        });
    }

    public function update(TeamConversation $conversation, int $actorId, array $data): TeamConversation
    {
        if (! $conversation->isChannel()) {
            throw ValidationException::withMessages(['conversation' => 'Only channels can use channel settings.']);
        }

        $linkedType = $data['linked_entity_type'] ?? $conversation->linked_entity_type;
        $linkedId = $data['linked_entity_id'] ?? $conversation->linked_entity_id;
        $this->assertLinkedEntity((int) $conversation->company_id, $actorId, $linkedType, $linkedId);

        if (array_key_exists('slug', $data)) {
            $slug = Str::slug((string) $data['slug']);
            if ($slug === '') {
                throw ValidationException::withMessages(['slug' => 'A valid channel slug is required.']);
            }
            $duplicate = TeamConversation::query()->where('company_id', $conversation->company_id)
                ->where('slug', $slug)->whereKeyNot($conversation->getKey())->exists();
            if ($duplicate) {
                throw ValidationException::withMessages(['slug' => 'This channel slug is already in use.']);
            }
            $data['slug'] = $slug;
        }

        $conversation->fill($data);
        $conversation->updated_by = $actorId;
        $conversation->version = ((int) $conversation->version) + 1;
        $conversation->save();
        $this->realtime->dispatch(new TeamConversationUpdated($conversation, 'channel-updated', $actorId));
        return $conversation->fresh(['participants']);
    }

    public function joinPublic(TeamConversation $conversation, int $userId): TeamConversationParticipant
    {
        abort_unless($conversation->isChannel() && $conversation->visibility === 'public' && ! $conversation->channel_archived_at, 403);
        $this->actors->assertUsersBelongToCompany((int) $conversation->company_id, [$userId]);
        $this->assertLinkedEntity((int) $conversation->company_id, $userId, $conversation->linked_entity_type, $conversation->linked_entity_id);

        $participant = TeamConversationParticipant::query()->withTrashed()->firstOrNew([
            'conversation_id' => $conversation->id,
            'company_id' => $conversation->company_id,
            'user_id' => $userId,
        ]);
        $participant->fill(['role' => 'member', 'joined_at' => now(), 'left_at' => null, 'archived_at' => null]);
        $participant->deleted_at = null;
        $participant->save();
        $this->realtime->dispatch(new TeamConversationUpdated($conversation, 'channel-joined', $userId));
        return $participant;
    }

    public function archive(TeamConversation $conversation, int $actorId, bool $archived): TeamConversation
    {
        $conversation->update([
            'channel_archived_at' => $archived ? now() : null,
            'updated_by' => $actorId,
            'version' => ((int) $conversation->version) + 1,
        ]);
        $this->realtime->dispatch(new TeamConversationUpdated($conversation, $archived ? 'channel-archived' : 'channel-restored', $actorId));
        return $conversation->fresh();
    }

    private function assertLinkedEntity(int $companyId, int $actorId, mixed $type, mixed $id): void
    {
        if ($type === null && $id === null) {
            return;
        }
        if (! is_string($type) || trim($type) === '' || $id === null || trim((string) $id) === '') {
            throw ValidationException::withMessages(['linked_entity' => 'Linked entity type and ID must be provided together.']);
        }
        $this->workCore->assertCanAccess($companyId, $actorId, trim($type), trim((string) $id));
    }
}
