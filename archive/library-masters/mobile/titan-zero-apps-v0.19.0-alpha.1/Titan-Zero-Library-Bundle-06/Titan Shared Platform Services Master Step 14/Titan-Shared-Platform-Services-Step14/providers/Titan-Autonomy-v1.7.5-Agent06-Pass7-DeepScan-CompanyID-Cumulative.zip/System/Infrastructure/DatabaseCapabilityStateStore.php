<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\CapabilityStateStoreContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use Illuminate\Support\Facades\DB;

final class DatabaseCapabilityStateStore implements CapabilityStateStoreContract
{
    public function __construct(private readonly array $maximumLevelByRisk) {}

    public function save(CapabilityState $state): void
    {
        app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_capability_states')->updateOrInsert(
            [
                'tenant_company_id' => $state->tenantCompanyId,
                'capability' => $state->capability,
                'workflow_key' => $state->workflowKey,
            ],
            [
                'risk' => $state->risk->value,
                'current_level' => $state->currentLevel->key(),
                'next_level' => $state->currentLevel->next()?->key(),
                'required_success_streak' => $state->requiredSuccessStreak,
                'current_success_streak' => $state->currentSuccessStreak,
                'highest_success_streak' => $state->highestSuccessStreak,
                'total_successes' => $state->totalSuccesses,
                'total_failures' => $state->totalFailures,
                'total_edits' => $state->totalEdits,
                'total_rejections' => $state->totalRejections,
                'total_reversals' => $state->totalReversals,
                'platform_gate_eligible' => $state->platformGateEligible,
                'maximum_allowed_level' => (string) ($this->maximumLevelByRisk[$state->risk->value] ?? 'assist'),
                'scope_json' => $state->scope === [] ? null : json_encode($state->scope, JSON_THROW_ON_ERROR),
                'last_success_at' => $state->lastSuccessAt,
                'last_failure_at' => $state->lastFailureAt,
                'updated_at' => now(),
            ],
        );
    }
}
