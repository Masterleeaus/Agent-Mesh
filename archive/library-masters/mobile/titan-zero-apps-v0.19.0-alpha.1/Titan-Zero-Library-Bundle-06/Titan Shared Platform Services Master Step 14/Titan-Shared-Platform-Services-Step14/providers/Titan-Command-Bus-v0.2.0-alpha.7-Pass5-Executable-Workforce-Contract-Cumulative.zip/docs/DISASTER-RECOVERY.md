# Disaster Recovery

Restore Command Bus audit/idempotency tables from the platform database backup. Reconcile in-flight idempotency claims against domain receipts before retrying. Never blindly resend uncertain external side effects.
