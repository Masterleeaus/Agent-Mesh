<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Data\SignalBackpressurePolicy;
use App\Extensions\TitanSignalEngine\System\Models\SignalDelivery;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;

final class SignalBackpressureMonitor
{
    /**
     * @return array{backpressured:bool,pending:int,retry_wait:int,processing:int,stale_processing:int,recent_dead_letter:int,unresolved_dead_letter:int,resolved_historical_dead_letter:int,total_pressure:int,threshold:int,window_seconds:int}
     */
    public function snapshot(
        ?string $scope = null,
        ?int $tenantCompanyId = null,
        ?string $subscriberKey = null,
        ?string $source = null,
        ?string $sourceComponent = null,
    ): array {
        $cacheKey = 'titan-signal-engine:backpressure:' . hash('sha256', json_encode([
            $scope, $tenantCompanyId, $subscriberKey, $source, $sourceComponent,
        ], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));

        return Cache::remember($cacheKey, 5, function () use ($scope, $tenantCompanyId, $subscriberKey, $source, $sourceComponent): array {
            $threshold = max(1, (int) config('titan-signal-engine.backpressure_delivery_threshold', 5000));
            $windowSeconds = max(60, min((int) config('titan-signal-engine.backpressure_recent_dlq_window_seconds', 3600), 86400));
            $zero = [
                'pending' => 0,
                'retry_wait' => 0,
                'processing' => 0,
                'stale_processing' => 0,
                'recent_dead_letter' => 0,
                'unresolved_dead_letter' => 0,
                'resolved_historical_dead_letter' => 0,
            ];
            if (! Schema::hasTable('titan_signal_deliveries')) {
                return [...(new SignalBackpressurePolicy($threshold))->evaluate($zero), 'window_seconds' => $windowSeconds];
            }

            $base = SignalDelivery::query();
            $this->applyScope($base, $scope, $tenantCompanyId, $subscriberKey, $source, $sourceComponent);
            $counts = $zero;
            foreach ((clone $base)->whereIn('status', ['pending', 'retry_wait', 'processing'])
                ->selectRaw('status, COUNT(*) as aggregate')->groupBy('status')->cursor() as $row) {
                $status = (string) $row->status;
                if (array_key_exists($status, $counts)) $counts[$status] = (int) $row->aggregate;
            }

            $now = now();
            $counts['stale_processing'] = (clone $base)
                ->where('status', 'processing')
                ->where(function (Builder $query) use ($now): void {
                    $query->whereNull('lease_expires_at')->orWhere('lease_expires_at', '<=', $now);
                })->count();
            $counts['recent_dead_letter'] = (clone $base)
                ->whereNotNull('dead_lettered_at')
                ->where('dead_lettered_at', '>=', $now->copy()->subSeconds($windowSeconds))
                ->count();
            $counts['unresolved_dead_letter'] = (clone $base)->where('status', 'dead_letter')->count();
            $counts['resolved_historical_dead_letter'] = (clone $base)
                ->whereNotNull('dead_lettered_at')
                ->whereNotNull('dead_letter_resolved_at')
                ->where('status', '!=', 'dead_letter')
                ->count();

            $evaluated = (new SignalBackpressurePolicy($threshold))->evaluate($counts);
            return [
                ...$evaluated,
                'window_seconds' => $windowSeconds,
                'current_pressure' => [
                    'pending' => $evaluated['pending'],
                    'retry_wait' => $evaluated['retry_wait'],
                    'processing' => $evaluated['processing'],
                    'stale_processing' => $evaluated['stale_processing'],
                    'recent_dead_letter' => $evaluated['recent_dead_letter'],
                    'total_pressure' => $evaluated['total_pressure'],
                    'threshold' => $evaluated['threshold'],
                    'backpressured' => $evaluated['backpressured'],
                ],
                'historical_incidents' => [
                    'unresolved_dead_letter' => $evaluated['unresolved_dead_letter'],
                    'resolved_historical_dead_letter' => $evaluated['resolved_historical_dead_letter'],
                ],
            ];
        });
    }

    private function applyScope(
        Builder $query,
        ?string $scope,
        ?int $tenantCompanyId,
        ?string $subscriberKey,
        ?string $source,
        ?string $sourceComponent,
    ): void {
        if ($scope !== null) {
            $query->where('scope', $scope);
            $scope === 'tenant' ? $query->where('tenant_company_id', $tenantCompanyId) : $query->whereNull('tenant_company_id');
        }
        if ($subscriberKey !== null && $subscriberKey !== '') $query->where('subscriber_key', $subscriberKey);
        if ($source !== null && $source !== '') $query->where('source', $source);
        if ($sourceComponent !== null && $sourceComponent !== '') $query->where('source_component', $sourceComponent);
    }
}
