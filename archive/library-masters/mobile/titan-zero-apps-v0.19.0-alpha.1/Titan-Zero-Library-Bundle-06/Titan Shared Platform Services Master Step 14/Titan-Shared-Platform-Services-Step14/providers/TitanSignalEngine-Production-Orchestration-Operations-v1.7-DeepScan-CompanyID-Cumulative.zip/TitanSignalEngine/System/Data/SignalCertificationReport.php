<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use JsonSerializable;

final class SignalCertificationReport implements JsonSerializable
{
    /** @var list<array{id:string,status:string,message:string,details:array<string,mixed>}> */
    private array $checks = [];

    public function add(string $id, string $status, string $message, array $details = []): void
    {
        $status = strtoupper($status);
        if (! in_array($status, ['PASS', 'WARN', 'FAIL', 'SKIP'], true)) {
            throw new \InvalidArgumentException('Unsupported certification status: ' . $status);
        }
        $this->checks[] = [
            'id' => $id,
            'status' => $status,
            'message' => $message,
            'details' => $details,
        ];
    }

    public function overall(): string
    {
        $statuses = array_column($this->checks, 'status');
        if (in_array('FAIL', $statuses, true)) return 'FAIL';
        if (in_array('WARN', $statuses, true) || in_array('SKIP', $statuses, true)) return 'WARN';
        return 'PASS';
    }

    public function summary(): array
    {
        $summary = ['PASS' => 0, 'WARN' => 0, 'FAIL' => 0, 'SKIP' => 0];
        foreach ($this->checks as $check) $summary[$check['status']]++;
        return $summary;
    }

    public function toArray(): array
    {
        return [
            'schema' => 'titan-signal-host-certification-v1',
            'engine' => 'titan-signal-engine',
            'overall' => $this->overall(),
            'summary' => $this->summary(),
            'checks' => $this->checks,
            'certified_at' => gmdate(DATE_ATOM),
        ];
    }

    public function jsonSerialize(): array
    {
        return $this->toArray();
    }
}
