<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/SignalDeliveryRedrivePolicy.php';
require __DIR__ . '/../System/Data/SignalBackpressurePolicy.php';
require __DIR__ . '/../System/Data/SignalRegistryCachePolicy.php';

use App\Extensions\TitanSignalEngine\System\Data\SignalBackpressurePolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryRedrivePolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryCachePolicy;

function pass4RecoveryAssert(bool $condition, string $message): void
{
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

$redrive = new SignalDeliveryRedrivePolicy();
pass4RecoveryAssert($redrive->canRedrive('dead_letter'), 'Only dead-letter deliveries may enter governed redrive.');
pass4RecoveryAssert(! $redrive->canRedrive('delivered'), 'Delivered records must not be redriven.');
pass4RecoveryAssert($redrive->nextAttemptCount() === 0, 'A redrive starts a new bounded retry cycle without erasing redrive history.');
pass4RecoveryAssert(strlen($redrive->reasonHash('operator repair complete')) === 64, 'Redrive reasons must be represented by a stable SHA-256 audit hash.');

$pressure = new SignalBackpressurePolicy(100);
$snapshot = $pressure->evaluate([
    'pending' => 10,
    'retry_wait' => 5,
    'processing' => 3,
    'stale_processing' => 2,
    'recent_dead_letter' => 1,
    'unresolved_dead_letter' => 2000,
    'resolved_historical_dead_letter' => 5000,
]);
pass4RecoveryAssert($snapshot['total_pressure'] === 27, 'Historical DLQ retention must not inflate current backpressure pressure.');
pass4RecoveryAssert($snapshot['backpressured'] === false, 'Historical dead letters alone must not keep Signal permanently backpressured.');
pass4RecoveryAssert($snapshot['unresolved_dead_letter'] === 2000, 'Unresolved DLQ backlog remains visible even when it is not treated as current throughput pressure.');

$cache = new SignalRegistryCachePolicy(5);
$checkedAt = new DateTimeImmutable('2026-08-17T03:30:00+10:00');
pass4RecoveryAssert(! $cache->shouldRefresh(7, 7, $checkedAt, $checkedAt->modify('+4 seconds')), 'Same registry revision inside TTL may use the local definition cache.');
pass4RecoveryAssert($cache->shouldRefresh(7, 8, $checkedAt, $checkedAt->modify('+1 second')), 'A shared registry revision change must invalidate a worker cache immediately.');
pass4RecoveryAssert($cache->shouldRefresh(7, 7, $checkedAt, $checkedAt->modify('+5 seconds')), 'Even without explicit invalidation, TTL must bound stale worker definitions.');

fwrite(STDOUT, "delivery-recovery-behavior: PASS\n");
