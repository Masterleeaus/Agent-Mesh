<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Services;

use App\Extensions\TitanKnowledgeAuthority\System\Contracts\KnowledgeAccessContextResolverContract;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeAccessContext;
use RuntimeException;

final class FailClosedKnowledgeAccessContextResolver implements KnowledgeAccessContextResolverContract
{
    public function current(): KnowledgeAccessContext
    {
        throw new RuntimeException(
            'Knowledge access context is unavailable. Bind a trusted host KnowledgeAccessContextResolverContract implementation.'
        );
    }
}
