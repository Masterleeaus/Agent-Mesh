<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use App\Extensions\TitanConnect\System\Contracts\CompanyActorDirectory;
use Illuminate\Support\Facades\Schema;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

final class DatabaseCompanyActorDirectory implements CompanyActorDirectory
{
    public function assertUsersBelongToCompany(int $companyId, array $userIds): void
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $userIds), static fn (int $id): bool => $id > 0)));
        if ($ids === []) {
            return;
        }

        if (! Schema::hasColumn('users', 'company_id')) {
            throw new AccessDeniedHttpException('Company-aware user directory is unavailable.');
        }

        $matched = app('db')->table('users')
            ->where('company_id', $companyId)
            ->whereIn('id', $ids)
            ->pluck('id')
            ->map(fn ($id) => (int) $id)
            ->all();

        sort($matched);
        $expected = $ids;
        sort($expected);

        if ($matched !== $expected) {
            throw new AccessDeniedHttpException('One or more messaging participants are outside the active company.');
        }
    }
}
