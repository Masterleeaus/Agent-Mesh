@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Contacts','subtitle'=>'People connected to your customer accounts.','surface'=>'customers','journey'=>'new-contact','secondaryJourneys'=>['new-customer']])
<form class="mb-3"><div class="input-group"><input class="form-control" name="q" value="{{ $q }}" placeholder="Search contacts"><button class="btn btn-outline-secondary">Search</button></div></form>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Name</th><th>Company</th><th>Email</th><th>Phone</th></tr></thead><tbody>@forelse($contacts as $contact)<tr><td><a href="{{ route('dashboard.user.crm.contacts.show',$contact['public_id']) }}" class="fw-semibold">{{ trim(($contact['first_name'] ?? '').' '.($contact['last_name'] ?? '')) }}</a></td><td>{{ $contact['company_name'] ?? '—' }}</td><td>{{ $contact['email'] ?? '—' }}</td><td>{{ $contact['phone'] ?? '—' }}</td></tr>@empty<tr><td colspan="4" class="text-muted">No contacts found.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
