<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Providers;

use App\Extensions\Crm\System\Capabilities\{CrmCapabilityExecutor,CrmCapabilityManifest,CrmCapabilityOperationStore,CrmCapabilityRegistry};
use App\Extensions\Crm\System\Governance\{CrmCapabilityResourceMap,CrmCommandBusGateway,CrmHumanMutationGateway,CrmCommandBusPort,CrmCommandReceiptFactory,CrmExpectedVersionResolver,CrmWriteSurfaceAuditor,CrmDeferredCommandBusPort,CrmDomainInvariantGuard,CrmDomainSignalPublisher,CrmOptimisticConcurrencyGuard,CrmTenantReferenceGuard,CrmCapabilityRateLimiter,CrmSignalDeliveryPort,CrmDeferredSignalDeliveryPort,CrmDomainSignalDispatcher};
use App\Extensions\Crm\System\ReadModels\{CrmAiReadModelService,CrmAiProjectionRegistry,CrmReadStorePort,CrmSqlProjectionReadStore,CrmReadProjectionRegistry,CrmProjectionBuilder,CrmProjectionEventProjector,CrmSearchPort,CrmSqlProjectionSearchAdapter,CrmProjectionDeadLetterStore,CrmProjectionSearchIndexer};
use App\Extensions\Crm\System\Integrations\TitanConnect\{CrmCommunicationExecutionPort,CrmDeferredCommunicationExecutionPort,CrmLegacyMailCommunicationAdapter};
use Illuminate\Support\ServiceProvider;

final class CrmCapabilityServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        if(! $this->app->bound(CrmCommandBusPort::class))$this->app->singleton(CrmCommandBusPort::class,CrmDeferredCommandBusPort::class);
        if(! $this->app->bound(CrmSignalDeliveryPort::class))$this->app->singleton(CrmSignalDeliveryPort::class,CrmDeferredSignalDeliveryPort::class);
        if(! $this->app->bound(CrmReadStorePort::class))$this->app->singleton(CrmReadStorePort::class,CrmSqlProjectionReadStore::class);
        if(! $this->app->bound(CrmSearchPort::class)){
            $adapter=(string)config('crm.search.adapter_class','');
            $this->app->singleton(CrmSearchPort::class,($adapter!==''&&class_exists($adapter)&&is_subclass_of($adapter,CrmSearchPort::class))?$adapter:CrmSqlProjectionSearchAdapter::class);
        }
        if(! $this->app->bound(CrmCommunicationExecutionPort::class)){
            $driver=strtolower((string)config('crm.governance.communication_driver','deferred'));
            $adapter=$driver==='legacy'?CrmLegacyMailCommunicationAdapter::class:CrmDeferredCommunicationExecutionPort::class;
            $this->app->singleton(CrmCommunicationExecutionPort::class,$adapter);
        }
        foreach ([
            CrmCapabilityManifest::class, CrmCapabilityRegistry::class, CrmCapabilityOperationStore::class,
            CrmCapabilityResourceMap::class, CrmExpectedVersionResolver::class, CrmWriteSurfaceAuditor::class, CrmDomainInvariantGuard::class, CrmTenantReferenceGuard::class, CrmCapabilityRateLimiter::class,
            CrmOptimisticConcurrencyGuard::class, CrmCommandReceiptFactory::class, CrmDomainSignalPublisher::class, CrmDomainSignalDispatcher::class,
            CrmReadProjectionRegistry::class, CrmSqlProjectionReadStore::class, CrmProjectionBuilder::class, CrmProjectionEventProjector::class, CrmSqlProjectionSearchAdapter::class, CrmProjectionDeadLetterStore::class, CrmProjectionSearchIndexer::class,
            CrmAiProjectionRegistry::class, CrmAiReadModelService::class, CrmCapabilityExecutor::class, CrmCommandBusGateway::class, CrmHumanMutationGateway::class,
        ] as $service) {
            $this->app->singleton($service);
        }
    }
}
