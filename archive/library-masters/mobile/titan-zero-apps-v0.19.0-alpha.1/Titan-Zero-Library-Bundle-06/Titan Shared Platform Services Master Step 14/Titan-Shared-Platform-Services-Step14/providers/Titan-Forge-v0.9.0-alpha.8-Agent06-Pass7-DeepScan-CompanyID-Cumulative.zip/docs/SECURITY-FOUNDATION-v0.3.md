# Titan Forge v0.3 Security Foundation

This release adds pre-generation controls without activating code generation.

## Enforced now

- new build contexts require tenant, actor, trace, correlation, causation, operation and idempotency identifiers
- repository lookups are tenant-scoped
- idempotency is constrained by tenant + key and guarded by deterministic BuildSpec fingerprint
- configuration validates queue name and the canonical `tenant_company_id` key
- archive security rejects traversal, absolute/backslash paths, symlinks, case collisions and forbidden package entries
- release scanning detects common API-key/private-key signatures
- queue payloads preserve immutable tenant and trace identifiers

## Deferred intentionally

Actor membership/authority resolution is not guessed from MagicAI host models. It will be integrated through the canonical Titan company/authorization context in Pass 5. Signal, Risk, Shield, Governance, Command Bus and Model Council remain separate later integrations.
