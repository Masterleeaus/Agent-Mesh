<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);function fail_ah(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function same_ah(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_ah($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
foreach(['/System/ControlCentre/AuthorityContractionProjector.php','/System/ControlCentre/EngineHealthScorecard.php'] as $f){if(!is_file($root.$f))fail_ah('missing '.$f);require_once $root.$f;}
use App\Extensions\TitanGovernance\System\ControlCentre\AuthorityContractionProjector;
use App\Extensions\TitanGovernance\System\ControlCentre\EngineHealthScorecard;
$sources=['titan-autonomy'=>['source'=>'titan-autonomy','status'=>'HEALTHY','control_centre'=>['authority_constraints'=>[
 ['agent_id'=>'invoice-agent','capability'=>'crm.invoice.create','desired_score'=>80,'earned_score'=>70,'effective_score'=>40,'ceiling_score'=>40,'disposition'=>'REQUIRE_APPROVAL','source'=>'titan-governance','reason_codes'=>['high-value'],'observed_at'=>'2026-08-21T02:45:00+10:00','reference'=>'constraint:1'],
 ['agent_id'=>'bad-agent','capability'=>'crm.payment.record','desired_score'=>40,'earned_score'=>30,'effective_score'=>50,'ceiling_score'=>50,'disposition'=>'ALLOW','reason_codes'=>[],'observed_at'=>'2026-08-21T02:45:00+10:00'],
]]]];
$p=new AuthorityContractionProjector();$r=$p->project($sources);
same_ah(2,count($r['items']),'constraint count');$by=[];foreach($r['items'] as $row)$by[$row['agent_id']]=$row;
same_ah(70.0,$by['invoice-agent']['earned_score'],'earned preserved');same_ah(40.0,$by['invoice-agent']['effective_score'],'effective preserved');same_ah(30.0,$by['invoice-agent']['contraction_amount'],'contraction difference');same_ah('CONTRACTED',$by['invoice-agent']['status'],'contracted status');same_ah(['high-value'],$by['invoice-agent']['reason_codes'],'reason codes preserved');same_ah(false,$by['invoice-agent']['can_raise_authority'],'explanation cannot raise authority');
same_ah('INVALID_SOURCE_AUTHORITY_ORDER',$by['bad-agent']['status'],'malformed source authority must be flagged not repaired');same_ah(50.0,$by['bad-agent']['effective_score'],'invalid effective score remains unchanged');
$score=new EngineHealthScorecard();$h=$score->project(['status'=>'UNAVAILABLE','sources'=>[
 'titan-autonomy'=>['status'=>'HEALTHY','required'=>true,'observed_at'=>'2026-08-21T02:45:00+10:00'],
 'titan-signal'=>['status'=>'UNAVAILABLE','required'=>true,'observed_at'=>null],
 'titan-risk'=>['status'=>'NOT_INSTALLED','required'=>false,'observed_at'=>null],
]]);
same_ah('UNAVAILABLE',$h['status'],'required source unavailable prevents healthy scorecard');same_ah(1,$h['required_unavailable'],'required unavailable count');same_ah(1,$h['optional_not_installed'],'optional missing count');same_ah(50.0,$h['score_pct'],'score excludes optional not installed and averages active required sources');
echo "PASS: Governance authority contraction/engine health contract\n";
