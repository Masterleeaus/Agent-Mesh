<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Host;

use JsonException;

/**
 * Package-side provider/container boot preflight.
 *
 * This is deliberately not a substitute for live Laravel boot certification.
 * It proves that the packaged provider declares the expected bindings and boot
 * resources and avoids known install-time hazards before the host executes it.
 */
final class TitanProviderBootPreflight
{
    /** @return array<string,mixed> */
    public static function inspect(string $root): array
    {
        $root = rtrim($root, '/\\');
        $providerPath = $root . '/System/TitanNexusServiceProvider.php';
        $provider = is_file($providerPath) ? (string) file_get_contents($providerPath) : '';

        $checks = [
            'provider_entrypoints' => self::checkProviderEntrypoints($provider),
            'container_bindings' => self::checkContainerBindings($root, $provider),
            'boot_resources' => self::checkBootResources($root, $provider),
            'navigation_isolation' => self::checkNavigationIsolation($provider),
            'duplicate_registration' => self::checkDuplicateRegistration($provider),
            'optional_dependencies' => self::checkOptionalDependencies($root, $provider),
            'interface_contribution' => self::checkInterfaceContribution($root),
        ];

        $failed = [];
        foreach ($checks as $name => $check) {
            if (($check['status'] ?? 'FAIL') !== 'PASS') {
                $failed[] = $name;
            }
        }

        return [
            'schema_version' => '1.0',
            'kind' => 'titan-nexus-provider-boot-preflight',
            'status' => $failed === [] ? 'PASS' : 'FAIL',
            'live_boot_certified' => false,
            'failed_checks' => $failed,
            'checks' => $checks,
        ];
    }

    /** @return array{status:string,details:list<string>} */
    private static function checkProviderEntrypoints(string $provider): array
    {
        $required = [
            'final class TitanNexusServiceProvider extends ServiceProvider',
            'public function register(): void',
            'public function boot(): void',
            'public function registerKey(): string',
            'public static function uninstall(): void',
        ];
        $missing = self::missingNeedles($provider, $required);
        if (str_contains($provider, 'Kernel $kernel')) {
            $missing[] = 'boot_must_not_require_unused_http_kernel';
        }
        return self::result($missing, $required);
    }

    /** @return array{status:string,details:list<string>} */
    private static function checkContainerBindings(string $root, string $provider): array
    {
        $contracts = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($root . '/System', \FilesystemIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            if (!$file->isFile() || strtolower($file->getExtension()) !== 'php') {
                continue;
            }
            $path = $file->getPathname();
            if (str_contains($path, '/Contracts/') || str_ends_with($path, 'TitanNexusServiceProvider.php')) {
                continue;
            }
            $source = (string) file_get_contents($path);
            if (preg_match_all('/\b([A-Z][A-Za-z0-9_]*Contract)\s+\$[A-Za-z_][A-Za-z0-9_]*/', $source, $matches)) {
                foreach ($matches[1] as $contract) {
                    $contracts[$contract] = true;
                }
            }
        }

        ksort($contracts, SORT_STRING);
        $missing = [];
        foreach (array_keys($contracts) as $contract) {
            if (!str_contains($provider, "singleton({$contract}::class")) {
                $missing[] = $contract;
            }
        }

        return [
            'status' => $missing === [] ? 'PASS' : 'FAIL',
            'details' => $missing === []
                ? array_map(static fn (string $c): string => "bound:{$c}", array_keys($contracts))
                : array_map(static fn (string $c): string => "missing_binding:{$c}", $missing),
        ];
    }

    /** @return array{status:string,details:list<string>} */
    private static function checkBootResources(string $root, string $provider): array
    {
        $requiredFiles = [
            'config/titan-nexus.php',
            'routes/user.php',
            'routes/admin.php',
            'resources/views/index.blade.php',
            'resources/interface/interface-manifest.json',
        ];
        $missing = [];
        foreach ($requiredFiles as $relative) {
            if (!is_file($root . '/' . $relative)) {
                $missing[] = "missing_file:{$relative}";
            }
        }
        foreach ([
            'loadViewsFrom(',
            'loadMigrationsFrom(',
            '$this->publishes(',
            '$this->registerRoutes();',
            '$this->registerNavigation();',
        ] as $needle) {
            if (!str_contains($provider, $needle)) {
                $missing[] = "missing_boot_wiring:{$needle}";
            }
        }
        return self::result($missing, $requiredFiles);
    }

    /** @return array{status:string,details:list<string>} */
    private static function checkNavigationIsolation(string $provider): array
    {
        $required = [
            'try { $this->registerNavigation(); } catch (Throwable)',
            'TitanMenuCompatibilityAdapter::class',
            'NexusMenuRegistrar::class',
        ];
        return self::result(self::missingNeedles($provider, $required), $required);
    }

    /** @return array{status:string,details:list<string>} */
    private static function checkDuplicateRegistration(string $provider): array
    {
        $required = [
            "if (\$this->app->bound('titan-nexus.routes.registered'))",
            "\$this->app->instance('titan-nexus.routes.registered', true)",
        ];
        return self::result(self::missingNeedles($provider, $required), $required);
    }

    /** @return array{status:string,details:list<string>} */
    private static function checkOptionalDependencies(string $root, string $provider): array
    {
        $configPath = $root . '/config/titan-nexus.php';
        $config = is_file($configPath) ? (string) file_get_contents($configPath) : '';
        $sections = ['risk','governance','assurance','signal','rewind','autonomy','knowledge_authority','interface_runtime'];
        $missing = [];
        foreach ($sections as $section) {
            if (!str_contains($config, "'{$section}' => [")) {
                $missing[] = "config_section:{$section}";
            }
        }
        foreach (['configuredUnary(', 'configuredEvent(', 'dependencyState('] as $needle) {
            if (!str_contains($provider, $needle)) {
                $missing[] = "provider_optional_path:{$needle}";
            }
        }
        return self::result($missing, $sections);
    }

    /** @return array{status:string,details:list<string>} */
    private static function checkInterfaceContribution(string $root): array
    {
        $path = $root . '/resources/interface/interface-manifest.json';
        if (!is_file($path)) {
            return ['status' => 'FAIL', 'details' => ['missing_interface_manifest']];
        }
        try {
            $data = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            return ['status' => 'FAIL', 'details' => ['invalid_interface_json']];
        }
        $missing = [];
        if (($data['schema_version'] ?? null) !== '1.1') {
            $missing[] = 'interface_schema_version_1.1';
        }
        $views = $data['views'] ?? null;
        if (!is_array($views) || $views === []) {
            $missing[] = 'interface_views';
        }
        return self::result($missing, ['interface_schema_1.1', 'interface_views']);
    }

    /** @param list<string> $needles @return list<string> */
    private static function missingNeedles(string $haystack, array $needles): array
    {
        $missing = [];
        foreach ($needles as $needle) {
            if (!str_contains($haystack, $needle)) {
                $missing[] = $needle;
            }
        }
        return $missing;
    }

    /** @param list<string> $missing @param list<string> $successDetails @return array{status:string,details:list<string>} */
    private static function result(array $missing, array $successDetails): array
    {
        return [
            'status' => $missing === [] ? 'PASS' : 'FAIL',
            'details' => $missing === [] ? array_values($successDetails) : array_values($missing),
        ];
    }
}
