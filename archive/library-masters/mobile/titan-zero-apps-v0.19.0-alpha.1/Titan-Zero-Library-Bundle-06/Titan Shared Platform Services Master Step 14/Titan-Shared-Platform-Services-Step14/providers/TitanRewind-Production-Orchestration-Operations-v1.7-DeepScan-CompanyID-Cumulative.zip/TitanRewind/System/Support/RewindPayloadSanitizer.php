<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Support;

use InvalidArgumentException;

final class RewindPayloadSanitizer
{
    private const HIDDEN_REASONING_KEYS = [
        'chain_of_thought', 'chain-of-thought', 'cot', 'hidden_reasoning', 'hidden-reasoning',
        'reasoning_content', 'reasoning-content', 'private_reasoning', 'private-reasoning',
    ];

    /** @var array<string, true> */
    private array $redacted;

    public function __construct(array $redactedKeys = [])
    {
        $this->redacted = [];
        foreach ($redactedKeys as $key) {
            $normalized = strtolower(trim((string) $key));
            if ($normalized !== '') {
                $this->redacted[$normalized] = true;
            }
        }
    }

    public function sanitize(array $payload): array
    {
        return $this->walk($payload, 'payload');
    }

    private function walk(array $value, string $path): array
    {
        $clean = [];
        foreach ($value as $key => $item) {
            $normalized = is_string($key) ? strtolower(trim($key)) : null;
            $nextPath = $path . '.' . (string) $key;

            if ($normalized !== null && in_array($normalized, self::HIDDEN_REASONING_KEYS, true)) {
                throw new InvalidArgumentException("Hidden reasoning is not permitted in Titan Rewind ({$nextPath}).");
            }

            if ($normalized !== null && isset($this->redacted[$normalized])) {
                $clean[$key] = '[REDACTED]';
                continue;
            }

            if (is_array($item)) {
                $clean[$key] = $this->walk($item, $nextPath);
                continue;
            }

            if (is_object($item)) {
                $clean[$key] = '[OBJECT:' . $item::class . ']';
                continue;
            }

            if (is_resource($item)) {
                $clean[$key] = '[RESOURCE]';
                continue;
            }

            $clean[$key] = $item;
        }

        return $clean;
    }
}
