<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Import;
use RuntimeException;
final class LegacyBookingMapper{
 public function map(array $row):array{
  $company=(int)($row['company_id']??0);if($company<1)throw new RuntimeException('legacy booking has ambiguous company ownership');
  $id=(string)($row['id']??'');if($id==='')throw new RuntimeException('legacy booking id required');
  return ['company_id'=>$company,'legacy_ref'=>'bookingmodule:'.$id,'customer_ref'=>'legacy-customer:'.(string)($row['customer_id']??''),'service_ref'=>'legacy-service:'.(string)($row['service_id']??''),'status'=>$this->status((string)($row['booking_status']??'')),'site'=>['address'=>(string)($row['service_address']??'')]];
 }
 private function status(string $s):string{return match(strtolower($s)){'confirmed','accepted'=>'confirmed','cancelled','canceled'=>'cancelled',default=>'requested'};}
}
