<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

interface CompanyOwnedModel
{
    public function companyId(): int;
}
