<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\GovernedCapabilityCommand;

interface ExecutionReconciliationContract
{
    public function capture(CapabilityState $state, GovernedCapabilityCommand $command, array $context, array $commandResult, array $assuranceAtExecution, ?int $userId): array;
    public function finalizeDue(int $limit = 100): int;
}
