<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Providers;

use App\Extensions\Crm\System\Capabilities\CrmCapabilityRegistry;
use App\Extensions\Crm\System\Domains\BusinessConfiguration\{BusinessConfigurationService,BusinessHoursService,ConfigurationDraftService};
use App\Extensions\Crm\System\Domains\CommercialCalculations\CommercialCalculationService;
use App\Extensions\Crm\System\Tenancy\{CrmCompanyContext,CrmCompanyScope};
use App\Extensions\Crm\System\Contracts\{CustomFieldRepositoryContract,NoteRepositoryContract};
use App\Extensions\Crm\System\Services\{CrmSettingsService,CrmMergeService,CrmBulkActionService,CrmIdentityAuthorityService,CrmDuplicateReviewService};
use App\Extensions\Crm\System\Sharing\CrmRecordShareService;
use App\Extensions\Crm\System\Portal\CrmPortalGrantService;
use App\Extensions\Crm\System\Integrations\{CrmApiKeyService,CrmWebhookService,CrmEmailSyncService};
use App\Extensions\Crm\System\Integrations\Chatbot\CrmChatbotSettingsService;
use App\Extensions\Crm\System\Import\CrmImportBatchService;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\ServiceProvider;

final class CrmCoreDomainServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        foreach ([BusinessHoursService::class,BusinessConfigurationService::class,ConfigurationDraftService::class,CommercialCalculationService::class] as $service) {
            $this->app->singleton($service);
        }
    }

    public function boot(): void
    {
        $registry=$this->app->make(CrmCapabilityRegistry::class);
        $commercial=fn()=> $this->app->make(CommercialCalculationService::class);
        $map=[
            'crm.finance.formula_rules.calculate'=>'formula_rules',
            'crm.finance.pricing.calculate'=>'pricing',
            'crm.finance.quote_estimate.calculate'=>'quote_estimate',
            'crm.finance.discount_promotion.calculate'=>'discount_promotion',
            'crm.finance.margin_profitability.calculate'=>'margin_profitability',
            'crm.finance.tax.calculate'=>'tax',
        ];
        foreach($map as $capability=>$calculator){
            $registry->register($capability,fn(array $i,CrmCompanyContext $c)=>$commercial()->calculateForTenant($c->companyId,$calculator,(array)($i['inputs']??$i),(array)($i['context']??[])));
        }

        $actor=static fn(CrmCompanyContext $c): int => (int)($c->actorUserId??0);
        $registry->register('crm.settings.update',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmSettingsService::class)->setMany($actor($c),$i));
        $registry->register('crm.chatbot.settings.update',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmChatbotSettingsService::class)->update($actor($c),(int)($i['chatbot_id']??0),(array)($i['settings']??$i)));
        $registry->register('crm.import.execute',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmImportBatchService::class)->create($actor($c),(string)($i['source_type']??$i['type']??''),isset($i['source_filename'])?(string)$i['source_filename']:null,(array)($i['mapping']??[]),(array)($i['rows']??$i['records']??[]),(bool)($i['dry_run']??true)));
        $registry->register('crm.import.commit',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmImportBatchService::class)->commit($actor($c),(string)($i['batch_public_id']??$i['public_id']??''),(string)($i['impact_hash']??'')));
        $registry->register('crm.import.rollback',function(array $i,CrmCompanyContext $c) use($actor): array {$batch=(string)($i['batch_public_id']??$i['public_id']??'');$this->app->make(CrmImportBatchService::class)->rollback($actor($c),$batch);return ['public_id'=>$batch,'status'=>'rolled_back'];});
        $registry->register('crm.customer.identity.resolve',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmIdentityAuthorityService::class)->resolveByIdentity($actor($c),$i['email']??null,$i['phone']??null,$i['provider']??null,$i['external_identity_id']??null));
        $registry->register('crm.external_identity.link',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmIdentityAuthorityService::class)->linkExternalIdentity($actor($c),(string)($i['customer_unification_id']??''),(string)($i['provider']??''),(string)($i['external_identity_id']??''),$i['subject_type']??null,$i['subject_public_id']??null,(array)($i['metadata']??[])));
        $registry->register('crm.duplicate.review.search',fn(array $i,CrmCompanyContext $c)=>['reviews'=>$this->app->make(CrmDuplicateReviewService::class)->search($actor($c),(array)($i['filters']??$i))]);
        $registry->register('crm.duplicate.review.resolve',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmDuplicateReviewService::class)->resolve($actor($c),(string)($i['public_id']??''),$actor($c),(string)($i['decision']??''),(array)($i['resolution']??[])));
        $registry->register('crm.record.merge.preview',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmMergeService::class)->preview($actor($c),(string)($i['resource']??''),(string)($i['winner_public_id']??''),(string)($i['loser_public_id']??'')));
        $registry->register('crm.record.merge',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmMergeService::class)->merge($actor($c),$actor($c),(string)($i['resource']??''),(string)($i['winner_public_id']??''),(string)($i['loser_public_id']??'')));
        $registry->register('crm.bulk.execute',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmBulkActionService::class)->execute($actor($c),$actor($c),(string)($i['resource']??''),(string)($i['action']??''),(array)($i['ids']??[]),$i));
        $registry->register('crm.custom_field.value.set',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CustomFieldRepositoryContract::class)->setValue($actor($c),(string)($i['field_public_id']??$i['public_id']??''),(string)($i['subject_type']??''),(string)($i['subject_public_id']??''),$i['value']??null));
        $registry->register('crm.share.revoke',function(array $i,CrmCompanyContext $c) use($actor): array {$this->app->make(CrmRecordShareService::class)->revoke($actor($c),(string)($i['public_id']??''));return ['public_id'=>$i['public_id']??null,'status'=>'revoked'];});
        $registry->register('crm.shared.comment.create',fn(array $i,CrmCompanyContext $c)=>$this->app->make(NoteRepositoryContract::class)->create($actor($c),$actor($c),['subject_type'=>(string)($i['subject_type']??''),'subject_public_id'=>(string)($i['subject_public_id']??''),'body'=>(string)($i['body']??''),'is_pinned'=>false]));
        $registry->register('crm.portal.grant.revoke',function(array $i,CrmCompanyContext $c) use($actor): array {$this->app->make(CrmPortalGrantService::class)->revoke($actor($c),(string)($i['public_id']??''));return ['public_id'=>$i['public_id']??null,'status'=>'revoked'];});
        $registry->register('crm.api_key.revoke',function(array $i,CrmCompanyContext $c) use($actor): array {$this->app->make(CrmApiKeyService::class)->revoke($actor($c),(string)($i['public_id']??''),(string)($i['revocation_reason']??'manual'));return ['public_id'=>$i['public_id']??null,'status'=>'revoked'];});
        $registry->register('crm.api_key.rotate',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmApiKeyService::class)->rotate($actor($c),(string)($i['public_id']??''),isset($i['label'])?(string)$i['label']:null));
        $registry->register('crm.webhook.disable',function(array $i,CrmCompanyContext $c) use($actor): array {$this->app->make(CrmWebhookService::class)->disable($actor($c),(string)($i['public_id']??''));return ['public_id'=>$i['public_id']??null,'status'=>'disabled'];});
        $registry->register('crm.webhook.rotate',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmWebhookService::class)->rotateSecret($actor($c),(string)($i['public_id']??'')));
        $registry->register('crm.email_connection.register',fn(array $i,CrmCompanyContext $c)=>$this->app->make(CrmEmailSyncService::class)->registerConnection($actor($c),$i));
        $registry->register('crm.automation.toggle',function(array $i,CrmCompanyContext $c): array {
            $db=$this->app->make(ConnectionInterface::class);$id=(string)($i['public_id']??'');
            $row=$db->table('crm_automation_rules')->where('company_id',$c->companyId)->where('public_id',$id)->whereNull('deleted_at')->lockForUpdate()->first();
            if(!$row) throw new \InvalidArgumentException('Automation rule not found.');
            $enabled=array_key_exists('enabled',$i)?(bool)$i['enabled']:!(bool)$row->enabled;
            $db->table('crm_automation_rules')->where('id',$row->id)->update(['enabled'=>$enabled,'updated_at'=>now()]);
            return ['public_id'=>$id,'enabled'=>$enabled,'status'=>$enabled?'enabled':'disabled'];
        });
        $registry->register('crm.portal.comment.create',function(array $i,CrmCompanyContext $c): array {
            $db=$this->app->make(ConnectionInterface::class);$id=(string)\Illuminate\Support\Str::ulid();
            $db->table('crm_portal_comments')->insert(['public_id'=>$id,'company_id'=>$c->companyId,'user_id'=>$c->actorUserId,'portal_grant_public_id'=>$i['portal_grant_public_id']??null,'subject_type'=>$i['subject_type']??null,'subject_public_id'=>$i['subject_public_id']??null,'body'=>(string)($i['body']??''),'author_type'=>$i['author_type']??'customer','created_at'=>now()]);
            return ['public_id'=>$id,'status'=>'created'];
        });
    }
}
