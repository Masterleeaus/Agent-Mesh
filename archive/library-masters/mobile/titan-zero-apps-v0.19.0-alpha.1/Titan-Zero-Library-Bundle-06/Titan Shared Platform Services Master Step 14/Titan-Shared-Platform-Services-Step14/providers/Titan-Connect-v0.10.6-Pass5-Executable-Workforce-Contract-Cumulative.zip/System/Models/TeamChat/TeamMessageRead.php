<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models\TeamChat;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TeamMessageRead extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    protected $table = 'ext_titan_connect_message_reads';

    protected $fillable = ['message_id', 'company_id', 'user_id', 'read_at', 'legacy_source', 'legacy_id'];
    protected $casts = ['read_at' => 'datetime'];

    public function message(): BelongsTo
    {
        return $this->belongsTo(TeamMessage::class, 'message_id');
    }
}
