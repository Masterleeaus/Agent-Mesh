# Titan Nexus Semantic Validation & Dry-Run Preview Design

## Scope

Pass 3 adds deterministic semantic validation, platform-readiness checks, and dry-run previews to the existing v0.3.0 compiler. It does not provision, mutate another Titan engine, emit Signals, or execute Command Bus capabilities.

## Architecture

Validation remains a pure Nexus concern. `SemanticNexusValidator` consumes an immutable `BusinessProfile`, the exact versioned `VerticalDefinition`, and a public capability-readiness source. It returns an immutable `ValidationResult` containing deterministic `ValidationFinding` values. Error findings block compilation; warnings and informational findings do not.

`VerticalDefinition` gains an optional `validation` object. When it is absent or empty it is omitted from canonical serialization so existing Pass-2 vertical fingerprints remain stable. Supported rules are `required_profile_paths`, `recommended_profile_paths`, `required_platform_capabilities`, and `require_knowledge_snapshot`.

Platform readiness crosses the extension boundary only through `PlatformReadinessSourceContract`. `PlatformReadinessAdapter` can consume a configured public host contract or a static capability list. Missing or malformed readiness responses fail closed as structured validation errors rather than allowing compilation to continue silently.

`CompilationPreview` is derived from a successful in-memory compile and always reports `dry_run: true`. It contains validation, deterministic hashes/provenance, a stable top-level section summary, and the compiled configuration snapshot. Blocked previews contain findings but no compiled configuration.

## Validation Rules

1. Business profile vertical id/version must match the resolved vertical definition.
2. Every vertical-defined required profile path must exist and contain a non-empty value; missing values are errors.
3. Missing recommended profile paths are warnings.
4. Every required platform capability must be reported ready; missing capabilities are errors.
5. If the vertical requires a knowledge snapshot, a missing knowledge version is an error.
6. Secret material is forbidden in profile or vertical sections. Keys matching password, secret, token, api_key, private_key, credential, credentials, access_key, client_secret, or authorization are errors.
7. Validator/readiness exceptions are converted into deterministic blocking findings.

## Aggregate and Persistence

`NexusCompilation` retains an optional `ValidationResult` without changing the existing Draft/Compiled/Failed status model. Validation is persisted through the existing `validation_result` JSON column. `withValidationResult()` and `withCompiledConfiguration()` remain immutable.

## Manager Flow

- `validateDraft()` resolves the vertical once and returns structured findings.
- `compileDraft()` resolves once, validates, throws `NexusValidationException` on blocking findings, otherwise compiles and retains validation in the returned immutable aggregate.
- `previewDraft()` resolves once, validates, and either returns a blocked preview or compiles in memory and returns a ready dry-run preview. It never saves or provisions anything.

## Compatibility

PHP 8.2+, Laravel 10+, MagicAI 10+. No direct imports from other Titan extension implementations. Existing Pass-2 definitions without `validation` retain their prior SHA-256 fingerprint. Existing persisted v0.2/v0.3 compilations without `validation_result` remain readable.

## Verification

Standalone checks must cover finding/result determinism, required/recommended paths, secret rejection, readiness failure, knowledge-snapshot gating, preview behavior, manager blocking behavior, persistence round-trip shape, manifest truthfulness, PHP linting, JSON parsing, archive safety, and re-extracted verification.
