# Data Ownership

Payroll owns payroll runs, immutable finalized snapshots, approvals, payslip references, delivery request metadata and redacted audit facts. It does not own tenant/company, worker identity, attendance capture, payment execution, accounting ledger, communications execution or Titan governance engines.
