@php
    $items = [
        ['route' => 'dashboard.user.titan.nexus.overview', 'key' => 'overview', 'label' => 'Overview'],
        ['route' => 'dashboard.user.titan.nexus.profile', 'key' => 'profile', 'label' => 'Business Profile'],
        ['route' => 'dashboard.user.titan.nexus.compilations', 'key' => 'compilations', 'label' => 'Compilations'],
        ['route' => 'dashboard.user.titan.nexus.validation', 'key' => 'validation', 'label' => 'Validation'],
        ['route' => 'dashboard.user.titan.nexus.preview', 'key' => 'preview', 'label' => 'Configuration Preview'],
        ['route' => 'dashboard.user.titan.nexus.history', 'key' => 'history', 'label' => 'History'],
        ['route' => 'dashboard.user.titan.nexus.diff', 'key' => 'diff', 'label' => 'Recompile / Diff'],
        ['route' => 'dashboard.user.titan.nexus.provisioning', 'key' => 'provisioning', 'label' => 'Provisioning Plans'],
        ['route' => 'dashboard.user.titan.nexus.receipts', 'key' => 'receipts', 'label' => 'Provisioning Receipts'],
    ];
@endphp
<div class="d-flex flex-wrap gap-2 mb-4" aria-label="Titan Nexus sections">
    @foreach($items as $item)
        <a href="{{ route($item['route']) }}" class="btn {{ $section === $item['key'] ? 'btn-primary' : 'btn-outline-secondary' }} btn-sm">
            {{ $item['label'] }}
        </a>
    @endforeach
</div>
