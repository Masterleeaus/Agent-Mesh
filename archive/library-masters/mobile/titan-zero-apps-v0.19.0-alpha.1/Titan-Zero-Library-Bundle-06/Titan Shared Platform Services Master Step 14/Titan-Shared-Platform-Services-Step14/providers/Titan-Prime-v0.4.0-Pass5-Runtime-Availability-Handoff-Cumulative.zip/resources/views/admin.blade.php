@extends('panel.layout.app')

@section('content')
    <div class="container-fluid py-6">
        <h1>Titan Prime — Admin</h1>
        <p>Domain core v0.2.1 is active. Durable mission storage and governed orchestration are intentionally deferred to later passes.</p>
    </div>
@endsection
