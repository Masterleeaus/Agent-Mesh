@extends('panel.layout.app')

@section('content')
<div class="container-fluid py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <div><h1 class="h3 mb-1">Governance Escalations</h1><p class="text-muted mb-0">Active Governance-owned escalation queue. Risk remains authoritative for risk values and Command Bus remains the mutation boundary.</p></div>
        <a class="btn btn-outline-secondary" href="{{ route('dashboard.user.titan.governance.index') }}">Governance Overview</a>
    </div>
    <div class="card"><div class="card-body p-0">
        @if(count($items)===0)
            <div class="p-4 text-muted">No active escalations.</div>
        @else
            <div class="table-responsive"><table class="table mb-0"><thead><tr><th>ID</th><th>Status</th><th>Risk</th><th>Urgency</th><th>Opened</th><th>Subject</th></tr></thead><tbody>
            @foreach($items as $row)
                <tr><td>{{ $row['id'] ?? $row['escalation_id'] ?? '' }}</td><td>{{ $row['status'] ?? '' }}</td><td>{{ $row['risk_score'] ?? '' }}</td><td>{{ $row['urgency'] ?? '' }}</td><td>{{ $row['opened_at'] ?? '' }}</td><td>{{ ($row['subject_type'] ?? '') }} {{ ($row['subject_id'] ?? '') }}</td></tr>
            @endforeach
            </tbody></table></div>
        @endif
    </div></div>
</div>
@endsection
