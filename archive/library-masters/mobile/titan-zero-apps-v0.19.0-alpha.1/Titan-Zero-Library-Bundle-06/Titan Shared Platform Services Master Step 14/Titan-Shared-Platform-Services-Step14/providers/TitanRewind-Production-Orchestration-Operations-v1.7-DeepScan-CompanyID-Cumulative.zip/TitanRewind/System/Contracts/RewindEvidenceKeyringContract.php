<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Contracts;
interface RewindEvidenceKeyringContract extends RewindEvidenceSignerContract
{
    public function activeKeyId(): string;
    /** @return array<string,array<string,mixed>> */
    public function keyMetadata(): array;
}
