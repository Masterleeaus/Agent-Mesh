# Donor Extraction — Pass 6

The donor `titan_signal(1).zip` did not contain an anomaly subsystem strong enough to transplant. Pass 6 therefore keeps the modern architecture and uses only previously harvested principles: explicit reason codes, bounded operational scoring, and read-model separation.

Not imported:

- legacy mutable process state
- donor approval policy
- custom queue transport
- finance-specific priority heuristics
- direct host `jobs`/`invoices` reads
- unauthenticated donor API surfaces

The anomaly engine is newly implemented against Titan Pulse, Correlation evaluations, causal-edge projections and delivery state. This preserves the donor's useful observability intent without reintroducing its security and ownership problems.
