# Titan Signal Anomaly Engine v0.18.0

## Boundary

The anomaly engine detects operational patterns from Signal-owned read models. It does not authorize commands, change business state, or decide governance policy. Risk, Governance, Autonomy, Shield and other authorities may consume anomaly telemetry and decide what action is appropriate.

The detector does **not** query `titan_signal_events` during scans. Its evidence comes from:

- `titan_signal_pulse_rollups`
- `titan_signal_pulse_trace_metrics`
- `titan_signal_pulse_trace_event_counts`
- `titan_signal_pulse_causation_refs`
- `titan_signal_trace_evaluations`
- `titan_signal_deliveries`

## Initial deterministic rules

| Type | Default trigger | Evidence source |
|---|---:|---|
| `repeated_failures` | 5 source errors / 5 min | Pulse source rollups |
| `execution_loop` | 10 occurrences of one event type in a trace | Pulse trace event counts |
| `queue_retry_spike` | 10 retry-wait deliveries or 1 recent dead letter | Delivery ledger |
| `stalled_workflow` | 1 configured watched trace beyond stall timeout | Pulse trace metrics |
| `missing_receipt` | 1 executed command without receipt beyond grace | Pulse trace metrics |
| `override_spike` | 5 registered override events / 1 hour | Pulse event-type rollups |
| `event_volume_collapse` | current 5 min <= 20% of mature baseline | Pulse all-event rollups |
| `sequence_violation` | 1 profile ordering violation | Correlation evaluation projection |
| `trace_integrity` | 1 unresolved causal parent beyond grace | Causation reference projection |

All values are configurable in `config/titan-signal-engine.php`.

## Cold start

Volume-collapse detection is disabled until the scope has at least 24 hours of Pulse history by default. This prevents a new tenant or a newly installed engine from treating lack of historical traffic as an outage.

## Offline causation grace

A child event may legitimately arrive before its parent from Titan Go/offline sync. Unresolved causation is therefore not anomalous immediately. The default grace is 300 seconds. Causation projections are repaired when the parent arrives or when a later scan sees the causal edge.

## Deduplication and lifecycle

The active identity is SHA-256 over:

`scope + tenant/system + anomaly_type + subject_type + subject_id`

Repeated detections update the existing record's score, confidence, evidence, occurrence count and `last_detected_at`. They do not create a new row every scan.

Lifecycle states:

- `open`
- `acknowledged`
- `suppressed`
- `resolved`

A resolved anomaly reopens when the same condition recurs. A suppressed anomaly remains suppressed until its bounded suppression period expires, then reopens if the condition still exists.

Lifecycle mutation requires `signal.anomaly.manage`. System/tenant read permissions still apply to the underlying scope.

## Immutable lifecycle decisions (v0.18.0)

`titan_signal_anomalies` is a mutable read model for the current lifecycle state, but lifecycle decisions are now durably audited as immutable Signal events:

- `signal.anomaly.acknowledged`
- `signal.anomaly.suppressed`
- `signal.anomaly.resolved`
- `signal.anomaly.reopened`

Each event contains the anomaly/subject identity, monotonic `decision_version`, trusted actor id/type, governed reason, decision timestamp, SHA-256 evidence reference, and suppression expiry where applicable. Manual mutations and their immutable audit event commit in the same database transaction; if audit emission fails, the projection mutation fails closed. Automatic recurrence and automatic trace-recovery resolution use system actors and the same audit path.

## Notification telemetry

A new or reopened anomaly may emit `signal.anomaly.detected`. Recurring scans of an already-open condition do not emit another detection event. The event uses informational envelope severity and carries the anomaly's operational severity in payload, preventing anomaly telemetry from recursively creating failure-rate anomalies.

## Scheduling

`titan:signal-anomalies:scan --limit=100` scans Pulse-visible tenant scopes and system scope once per minute. A persisted round-robin tenant cursor advances across the fleet so bounded runs do not repeatedly scan only the lowest tenant IDs. The per-run tenant limit can be increased manually up to 1,000 scopes.
## Automatic sequence evidence (v0.16.0)

Sequence and missing-required findings now consume fresh automatic trace evaluations. Missing required events are raised only after a profile terminal event has been seen. Late/offline repair causes the corresponding mutable anomaly projection to resolve with `trace_evaluation_recovered`.

