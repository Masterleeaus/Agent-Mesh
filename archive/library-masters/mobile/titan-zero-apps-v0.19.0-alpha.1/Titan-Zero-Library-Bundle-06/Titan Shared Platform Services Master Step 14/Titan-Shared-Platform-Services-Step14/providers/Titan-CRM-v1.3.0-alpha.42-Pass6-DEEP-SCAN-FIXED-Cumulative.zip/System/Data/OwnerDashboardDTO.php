<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Data;

final class OwnerDashboardDTO
{
    public function __construct(
        public readonly mixed $today,
        public readonly mixed $dispatch,
        public readonly mixed $customers,
        public readonly mixed $sales,
        public readonly mixed $money,
        public readonly mixed $workforce,
        public readonly mixed $approvals,
    ) {}

    public function toArray(): array
    {
        return [
            'today'=>$this->today,
            'dispatch'=>$this->dispatch,
            'customers'=>$this->customers,
            'sales'=>$this->sales,
            'money'=>$this->money,
            'workforce'=>$this->workforce,
            'approvals'=>$this->approvals,
        ];
    }
}
