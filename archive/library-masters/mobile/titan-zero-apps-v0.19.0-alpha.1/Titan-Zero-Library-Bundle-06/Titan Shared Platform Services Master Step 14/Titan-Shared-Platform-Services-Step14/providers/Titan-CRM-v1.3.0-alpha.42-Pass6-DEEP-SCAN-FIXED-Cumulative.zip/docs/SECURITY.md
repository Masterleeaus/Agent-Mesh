# Security

`company_id` is canonical tenant scope for active contracts. Authorization, governance, risk and autonomy are independent checks. Missing configuration never grants authority.
