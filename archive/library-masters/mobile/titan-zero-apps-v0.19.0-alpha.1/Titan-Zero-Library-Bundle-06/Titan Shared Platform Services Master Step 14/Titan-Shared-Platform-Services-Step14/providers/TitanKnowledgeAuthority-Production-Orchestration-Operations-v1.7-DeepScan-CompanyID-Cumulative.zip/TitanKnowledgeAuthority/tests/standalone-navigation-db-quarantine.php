<?php
declare(strict_types=1);
$src=(string)file_get_contents(__DIR__.'/../System/Support/HostNavigationRegistrar.php');
if(str_contains($src,'Illuminate\\Support\\Facades\\DB')||preg_match('/\bDB::/',$src)){fwrite(STDERR,"FAIL: HostNavigationRegistrar still owns raw DB access\n");exit(1);}
echo "PASS navigation DB quarantine\n";
