<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use PHPUnit\Framework\TestCase;

final class CommandRequestTest extends TestCase
{
    public function test_request_hash_is_stable_across_associative_payload_key_order(): void
    {
        $a = new CommandRequest('crm.invoice.create', ['amount' => 100, 'meta' => ['b' => 2, 'a' => 1]], 'idem-1', 't1', 'c1', 'x1', 'r1');
        $b = new CommandRequest('crm.invoice.create', ['meta' => ['a' => 1, 'b' => 2], 'amount' => 100], 'idem-1', 't2', 'c2', 'x2', 'r2');

        self::assertSame($a->requestHash(), $b->requestHash());
    }
}
