<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Services;

use App\Extensions\TitanNexus\System\Contracts\NexusValidatorContract;
use App\Extensions\TitanNexus\System\Contracts\PlatformReadinessSourceContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\ValidationFinding;
use App\Extensions\TitanNexus\System\Domain\ValidationResult;
use App\Extensions\TitanNexus\System\Domain\ValidationSeverity;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Support\SecretFieldGuard;
use Throwable;

final class SemanticNexusValidator implements NexusValidatorContract
{

    public function __construct(private readonly PlatformReadinessSourceContract $readiness)
    {
    }

    public function validate(BusinessProfile $profile, VerticalDefinition $definition): ValidationResult
    {
        $findings = [];

        if ($profile->verticalId() !== $definition->verticalId()) {
            $findings[] = $this->error('vertical.identity.mismatch', 'vertical_id', 'Resolved vertical id does not match the business profile.');
        }
        if ($profile->verticalVersion() !== $definition->verticalVersion()) {
            $findings[] = $this->error('vertical.version.mismatch', 'vertical_version', 'Resolved vertical version does not match the business profile.');
        }

        $rules = $definition->validationRules();
        foreach ($this->stringList($rules['required_profile_paths'] ?? []) as $path) {
            if (!$this->pathHasValue($profile->toArray(), $path)) {
                $findings[] = $this->error('profile.required', $path, 'Required business profile value is missing.');
            }
        }
        foreach ($this->stringList($rules['recommended_profile_paths'] ?? []) as $path) {
            if (!$this->pathHasValue($profile->toArray(), $path)) {
                $findings[] = $this->warning('profile.recommended', $path, 'Recommended business profile value is missing.');
            }
        }

        if (($rules['require_knowledge_snapshot'] ?? false) === true && $definition->knowledgeSnapshotVersion() === null) {
            $findings[] = $this->error('knowledge.snapshot.required', 'knowledge_snapshot_version', 'This vertical requires a versioned knowledge snapshot.');
        }

        $requiredCapabilities = $this->stringList($rules['required_platform_capabilities'] ?? []);
        if ($requiredCapabilities !== []) {
            try {
                $readiness = $this->readiness->check($requiredCapabilities);
                foreach ($requiredCapabilities as $capability) {
                    if (($readiness[$capability] ?? false) !== true) {
                        $findings[] = $this->error('platform.capability.missing', 'capabilities.' . $capability, 'Required Titan platform capability is not ready.');
                    }
                }
            } catch (Throwable) {
                $findings[] = $this->error('platform.readiness.unavailable', 'capabilities', 'Titan platform readiness could not be verified.');
            }
        }

        $this->scanSecrets($profile->sections(), 'sections', $findings);
        $this->scanSecrets($definition->sections(), 'vertical.sections', $findings);

        return ValidationResult::fromFindings($findings);
    }

    /** @param array<string, mixed> $source */
    private function pathHasValue(array $source, string $path): bool
    {
        $cursor = $source;
        $parts = explode('.', $path);
        foreach ($parts as $index => $part) {
            if (!is_array($cursor) || !array_key_exists($part, $cursor)) {
                return false;
            }
            $cursor = $cursor[$part];
            if ($index < count($parts) - 1 && !is_array($cursor)) {
                return false;
            }
        }

        if ($cursor === null) {
            return false;
        }
        if (is_string($cursor)) {
            return trim($cursor) !== '';
        }
        if (is_array($cursor)) {
            return $cursor !== [];
        }
        return true;
    }

    /**
     * @param array<string|int, mixed> $value
     * @param list<ValidationFinding> $findings
     */
    private function scanSecrets(array $value, string $path, array &$findings): void
    {
        foreach ($value as $key => $item) {
            $segment = (string) $key;
            $itemPath = $path . '.' . $segment;
            if (is_string($key) && $this->isForbiddenSecretKey($key)) {
                $findings[] = $this->error('secret.material.forbidden', $itemPath, 'Secret or credential material must not be compiled by Titan Nexus.');
            }
            if (is_array($item)) {
                $this->scanSecrets($item, $itemPath, $findings);
            }
        }
    }

    private function isForbiddenSecretKey(string $key): bool
    {
        return SecretFieldGuard::isSecretLike($key);
    }

    /** @param mixed $value @return list<string> */
    private function stringList(mixed $value): array
    {
        if (!is_array($value)) {
            return [];
        }
        $result = [];
        foreach ($value as $item) {
            if (is_string($item)) {
                $result[] = trim($item);
            }
        }
        $result = array_values(array_unique($result));
        sort($result, SORT_STRING);
        return $result;
    }

    private function error(string $code, string $path, string $message): ValidationFinding
    {
        return new ValidationFinding($code, ValidationSeverity::Error, $path, $message, 'nexus.semantic');
    }

    private function warning(string $code, string $path, string $message): ValidationFinding
    {
        return new ValidationFinding($code, ValidationSeverity::Warning, $path, $message, 'nexus.semantic');
    }
}
