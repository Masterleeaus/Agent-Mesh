<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Contracts\CompilationRepositoryContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompiledTitanConfig;
use App\Extensions\TitanNexus\System\Domain\ConfigurationDiff;
use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlan;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeDisposition;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeKind;
use App\Extensions\TitanNexus\System\Domain\SemanticDiffEntry;
use App\Extensions\TitanNexus\System\Domain\ValidationFinding;
use App\Extensions\TitanNexus\System\Domain\ValidationResult;
use App\Extensions\TitanNexus\System\Domain\ValidationSeverity;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Host\HostTenantContextResolver;
use App\Extensions\TitanNexus\System\Services\NexusControlCentreService;

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
$files = [
    '/System/Support/CanonicalJson.php',
    '/System/Support/RedactedPayload.php',
    '/System/Domain/CompilationStatus.php',
    '/System/Domain/ValueObjects/TraceContext.php',
    '/System/Domain/BusinessProfile.php',
    '/System/Domain/CompiledTitanConfig.php',
    '/System/Domain/ValidationSeverity.php',
    '/System/Domain/ValidationFinding.php',
    '/System/Domain/ValidationResult.php',
    '/System/Domain/SemanticChangeKind.php',
    '/System/Domain/SemanticChangeDisposition.php',
    '/System/Domain/SemanticDiffEntry.php',
    '/System/Domain/ConfigurationDiff.php',
    '/System/Domain/ProvisioningReceiptStatus.php',
    '/System/Domain/ProvisioningReceipt.php',
    '/System/Domain/ProvisioningPlanStatus.php',
    '/System/Domain/ProvisioningOperation.php',
    '/System/Domain/ProvisioningPlan.php',
    '/System/Domain/NexusCompilation.php',
    '/System/Domain/ControlCentreSnapshot.php',
    '/System/Contracts/CompilationRepositoryContract.php',
    '/System/Contracts/TenantContextResolverContract.php',
    '/System/Contracts/NexusControlCentreContract.php',
    '/System/Host/HostTenantContextResolver.php',
    '/System/Services/NexusControlCentreService.php',
];
foreach ($files as $file) {
    require_once $root . $file;
}

function ccCheck(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

$profile = BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '3.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
    'timezone' => 'Australia/Melbourne',
    'sections' => [
        'billing' => ['currency' => 'AUD'],
        'integration' => ['api_key' => 'must-not-render'],
    ],
]);
$trace = TraceContext::fromArray([
    'tenant_company_id' => 42,
    'trace_id' => '11111111-1111-4111-8111-111111111111',
    'correlation_id' => '22222222-2222-4222-8222-222222222222',
    'causation_id' => '33333333-3333-4333-8333-333333333333',
]);
$config = new CompiledTitanConfig(
    42,
    '7',
    '0.5.0',
    'cleaning',
    '2026.08',
    'au-vic-2026.08',
    $profile->fingerprint(),
    str_repeat('b', 64),
    ['billing' => ['currency' => 'AUD'], 'integration' => ['client_secret' => 'never-render']],
);
$validation = ValidationResult::fromFindings([
    new ValidationFinding('nexus.profile.recommended_missing', ValidationSeverity::Warning, 'sections.operations.manager', 'Manager profile is recommended.', 'vertical'),
]);
$diff = new ConfigurationDiff(
    str_repeat('a', 64),
    $config->outputHash(),
    [new SemanticDiffEntry('sections.billing.currency', SemanticChangeKind::Modify, SemanticChangeDisposition::Apply, 'USD', 'AUD')],
);
$operation = new ProvisioningOperation(
    42,
    '44444444-4444-4444-8444-444444444444',
    $config->outputHash(),
    'sections.billing.currency',
    SemanticChangeKind::Modify,
    SemanticChangeDisposition::Apply,
    'crm.configuration.apply',
    'sections.billing',
    'USD',
    'AUD',
);
$plan = new ProvisioningPlan(
    42,
    '44444444-4444-4444-8444-444444444444',
    $config->outputHash(),
    $diff->fingerprint(),
    [$operation],
);
$compiled = NexusCompilation::draft($profile, $trace, '44444444-4444-4444-8444-444444444444', '0.5.0')
    ->withValidationResult($validation)
    ->withCompiledConfiguration($config)
    ->withConfigurationDiff($diff)
    ->withProvisioningPlan($plan);

$repository = new class($compiled) implements CompilationRepositoryContract {
    public array $calls = [];
    public function __construct(private NexusCompilation $compilation) {}
    public function save(NexusCompilation $compilation): NexusCompilation { $this->calls[] = ['save']; return $compilation; }
    public function findForTenant(int $tenantCompanyId, string $compilationUuid): ?NexusCompilation
    {
        $this->calls[] = ['find', $tenantCompanyId, $compilationUuid];
        return $tenantCompanyId === 42 && $compilationUuid === $this->compilation->compilationUuid() ? $this->compilation : null;
    }
    public function latestForTenant(int $tenantCompanyId, int $limit = 25): array
    {
        $this->calls[] = ['latest', $tenantCompanyId, $limit];
        return $tenantCompanyId === 42 ? [$this->compilation] : [];
    }
    public function lineageForTenant(int $tenantCompanyId, string $compilationUuid, int $limit = 25): array
    {
        $this->calls[] = ['lineage', $tenantCompanyId, $compilationUuid, $limit];
        return $tenantCompanyId === 42 ? [$this->compilation] : [];
    }
};

$resolver = new HostTenantContextResolver(null, ['company_id', 'tenant_company_id']);
$user = new class { public int $company_id = 42; };
ccCheck($resolver->resolve($user) === 42, 'host tenant resolver accepts configured positive company_id');
try {
    $resolver->resolve(new class {});
    ccCheck(false, 'host tenant resolver must fail closed when tenant context is absent');
} catch (RuntimeException) {
    ccCheck(true, 'host tenant resolver fails closed');
}

$service = new NexusControlCentreService($repository);
$snapshot = $service->snapshot(42);
$data = $snapshot->toArray();
ccCheck(($data['summary']['total_compilations'] ?? null) === 1, 'summary counts tenant compilations');
ccCheck(($data['summary']['validation']['warnings'] ?? null) === 1, 'summary exposes validation warning count');
ccCheck(($data['summary']['diff']['modify'] ?? null) === 1, 'summary exposes semantic diff counts');
ccCheck(($data['summary']['provisioning']['status'] ?? null) === 'ready', 'summary exposes provisioning status');
ccCheck(($data['selected']['profile']['sections']['integration']['api_key'] ?? null) === '[REDACTED]', 'profile secrets are redacted at presentation time');
ccCheck(($data['selected']['configuration']['sections']['integration']['client_secret'] ?? null) === '[REDACTED]', 'compiled configuration secrets are redacted at presentation time');
ccCheck(($repository->calls[0] ?? null) === ['latest', 42, 50], 'history read is tenant scoped and bounded to 50');
ccCheck(($repository->calls[1] ?? null) === ['lineage', 42, $compiled->compilationUuid(), 50], 'lineage read is tenant scoped and bounded to 50');

$selected = $service->snapshot(42, $compiled->compilationUuid())->toArray();
ccCheck(($repository->calls[2] ?? null) === ['latest', 42, 50], 'selected snapshot still loads bounded tenant history');
ccCheck(($repository->calls[3] ?? null) === ['find', 42, $compiled->compilationUuid()], 'selected compilation lookup always includes tenant boundary');
ccCheck(($selected['selected']['compilation_uuid'] ?? null) === $compiled->compilationUuid(), 'explicit tenant-safe selection is returned');

$emptyRepo = new class implements CompilationRepositoryContract {
    public function save(NexusCompilation $compilation): NexusCompilation { return $compilation; }
    public function findForTenant(int $tenantCompanyId, string $compilationUuid): ?NexusCompilation { return null; }
    public function latestForTenant(int $tenantCompanyId, int $limit = 25): array { return []; }
    public function lineageForTenant(int $tenantCompanyId, string $compilationUuid, int $limit = 25): array { return []; }
};
$empty = (new NexusControlCentreService($emptyRepo))->snapshot(99)->toArray();
ccCheck(($empty['summary']['total_compilations'] ?? null) === 0, 'empty tenant renders zero-count state');
ccCheck(array_key_exists('selected', $empty) && $empty['selected'] === null, 'empty tenant has no selected compilation');

fwrite(STDOUT, "PASS: Titan Nexus standalone Control Centre checks\n");
