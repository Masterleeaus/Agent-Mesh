<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Models\KnowledgeSource;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeAccessContext;
use InvalidArgumentException;

final class EloquentKnowledgeSourceRepository implements KnowledgeSourceRepositoryContract
{
    public function __construct(private readonly KnowledgeSourceScopeQuery $scopeQuery)
    {
    }

    public function findVisibleByKey(KnowledgeAccessContext $context, string $sourceKey): ?KnowledgeSource
    {
        $sourceKey = trim($sourceKey);
        if ($sourceKey === '') {
            throw new InvalidArgumentException('sourceKey must not be empty.');
        }

        $query = KnowledgeSource::query()
            ->with(['jurisdiction:id,code,name'])
            ->where('source_key', $sourceKey);

        return $this->scopeQuery->apply($query, $context)->first();
    }
}
