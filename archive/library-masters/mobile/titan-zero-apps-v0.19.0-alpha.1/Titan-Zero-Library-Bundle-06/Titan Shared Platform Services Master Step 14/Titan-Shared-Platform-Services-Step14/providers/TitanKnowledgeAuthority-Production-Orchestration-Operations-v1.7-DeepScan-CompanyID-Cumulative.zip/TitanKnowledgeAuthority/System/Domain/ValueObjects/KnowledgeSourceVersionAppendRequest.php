<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects;

use DateTimeImmutable;
use InvalidArgumentException;

final readonly class KnowledgeSourceVersionAppendRequest
{
    public string $contentHash;
    public string $rawEvidenceHash;

    /**
     * @param array<string, mixed> $provenance
     * @param array<string, mixed>|null $metadata
     */
    public function __construct(
        public int $sourceId,
        string $contentHash,
        string $rawEvidenceHash,
        public DateTimeImmutable $retrievedAt,
        public array $provenance,
        public ?string $contentType = null,
        public ?string $contentStorageRef = null,
        public ?string $rawEvidenceStorageRef = null,
        public ?DateTimeImmutable $publishedAt = null,
        public ?DateTimeImmutable $effectiveFrom = null,
        public ?DateTimeImmutable $effectiveUntil = null,
        public ?string $etag = null,
        public ?string $lastModified = null,
        public ?array $metadata = null,
        public ?int $expectedSupersedesVersionId = null,
        public ?string $traceId = null,
        public ?string $correlationId = null,
        public ?string $causationId = null,
    ) {
        if ($sourceId <= 0) {
            throw new InvalidArgumentException('sourceId must be a positive integer.');
        }
        if ($expectedSupersedesVersionId !== null && $expectedSupersedesVersionId <= 0) {
            throw new InvalidArgumentException('expectedSupersedesVersionId must be a positive integer when present.');
        }
        if ($provenance === []) {
            throw new InvalidArgumentException('provenance is required for every immutable knowledge source version.');
        }
        if ($effectiveFrom !== null && $effectiveUntil !== null && $effectiveUntil < $effectiveFrom) {
            throw new InvalidArgumentException('effective_until must not be before effective_from.');
        }
        $this->contentHash = self::normalizeHash($contentHash, 'contentHash');
        $this->rawEvidenceHash = self::normalizeHash($rawEvidenceHash, 'rawEvidenceHash');
    }

    private static function normalizeHash(string $hash, string $field): string
    {
        $hash = strtolower(trim($hash));
        if (! preg_match('/^[a-f0-9]{64}$/', $hash)) {
            throw new InvalidArgumentException("{$field} must be a SHA-256 hex digest.");
        }
        return $hash;
    }
}
