<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Attachments;

use App\Extensions\TitanConnect\System\Models\ExternalMessage;
use App\Extensions\TitanConnect\System\Models\MessageAttachment;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\URL;
use RuntimeException;

final class OutboundAttachmentResolver
{
    public function resolveForProvider(int $companyId, ExternalMessage $message, array $metadata): array
    {
        $attachments = $metadata['attachments'] ?? [];
        if (! is_array($attachments) || $attachments === []) {
            return $metadata;
        }

        $resolved = [];
        foreach ($attachments as $item) {
            if (! is_array($item)) {
                throw new RuntimeException('Outbound attachment metadata must be an object.');
            }
            $uuid = trim((string) ($item['attachment_uuid'] ?? ''));
            if ($uuid === '') {
                if (! empty($item['provider_media_id'])) {
                    $resolved[] = $item;
                    continue;
                }
                if (! empty($item['public_url']) && (bool) config('titan-connect.attachments.allow_external_public_urls', false)) {
                    $resolved[] = $item;
                    continue;
                }
                throw new RuntimeException('Outbound attachment must reference a staged attachment UUID or approved provider media ID.');
            }

            $attachment = MessageAttachment::query()
                ->where('company_id', $companyId)
                ->where('uuid', $uuid)
                ->firstOrFail();

            if ($attachment->message_id !== null) {
                throw new RuntimeException('Internal-message attachments cannot be reused as external outbound attachments.');
            }
            if ($attachment->external_message_id !== null && (int) $attachment->external_message_id !== (int) $message->id) {
                throw new RuntimeException('Attachment is already linked to another external message.');
            }
            if ($attachment->scan_status !== 'clean') {
                throw new RuntimeException('Outbound attachment is not cleared by the attachment security scanner.');
            }
            if ($attachment->expires_at && $attachment->expires_at->isPast()) {
                throw new RuntimeException('Outbound attachment has expired.');
            }
            if (! Storage::disk((string) $attachment->storage_disk)->exists((string) $attachment->storage_path)) {
                throw new RuntimeException('Outbound attachment file is missing from configured storage.');
            }

            if ($attachment->external_message_id === null) {
                $attachment->forceFill(['external_message_id' => $message->id])->save();
            }

            $ttl = max(60, (int) config('titan-connect.attachments.provider_url_ttl_seconds', 600));
            $item['public_url'] = URL::temporarySignedRoute(
                'titan-connect.api.attachments.provider',
                now()->addSeconds($ttl),
                ['companyId' => $companyId, 'attachment' => $attachment->uuid],
            );
            $item['mime_type'] = $attachment->mime_type;
            $item['size_bytes'] = (int) $attachment->size_bytes;
            $item['sha256'] = $attachment->sha256;
            $item['type'] = $item['type'] ?? $this->typeForMime((string) $attachment->mime_type);
            $resolved[] = $item;
        }

        $metadata['attachments'] = $resolved;
        return $metadata;
    }

    private function typeForMime(string $mime): string
    {
        if (str_starts_with($mime, 'image/')) return 'image';
        if (str_starts_with($mime, 'video/')) return 'video';
        if (str_starts_with($mime, 'audio/')) return 'audio';
        return 'document';
    }
}
