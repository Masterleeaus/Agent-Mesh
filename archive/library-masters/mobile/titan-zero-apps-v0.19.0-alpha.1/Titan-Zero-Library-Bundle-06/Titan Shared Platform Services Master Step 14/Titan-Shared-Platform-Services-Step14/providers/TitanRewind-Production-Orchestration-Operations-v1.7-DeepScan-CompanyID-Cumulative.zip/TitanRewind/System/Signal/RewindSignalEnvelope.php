<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Signal;

use App\Extensions\TitanRewind\System\Observability\RewindTraceContext;
use InvalidArgumentException;

final class RewindSignalEnvelope
{
    public static function make(string $eventType, RewindTraceContext $context, array $payload = [], string $severity = 'INFO'): array
    {
        if (preg_match('/^rewind\.[a-z0-9._-]+\.v\d+$/',$eventType)!==1) throw new InvalidArgumentException('Rewind Signal event types must be versioned.');
        return ['event_id'=>self::uuid(),'event_type'=>$eventType,'schema_version'=>'1.0','occurred_at'=>(new \DateTimeImmutable('now',new \DateTimeZone('UTC')))->format(DATE_ATOM),'extension_key'=>$context->extensionKey(),'tenant_company_id'=>$context->tenantCompanyId(),'trace_id'=>$context->traceId(),'correlation_id'=>$context->correlationId(),'causation_id'=>$context->causationId(),'severity'=>strtoupper($severity),'payload'=>$payload];
    }
    private static function uuid(): string { $d=random_bytes(16); $d[6]=chr((ord($d[6])&0x0f)|0x40); $d[8]=chr((ord($d[8])&0x3f)|0x80); $h=bin2hex($d); return substr($h,0,8).'-'.substr($h,8,4).'-'.substr($h,12,4).'-'.substr($h,16,4).'-'.substr($h,20); }
}
