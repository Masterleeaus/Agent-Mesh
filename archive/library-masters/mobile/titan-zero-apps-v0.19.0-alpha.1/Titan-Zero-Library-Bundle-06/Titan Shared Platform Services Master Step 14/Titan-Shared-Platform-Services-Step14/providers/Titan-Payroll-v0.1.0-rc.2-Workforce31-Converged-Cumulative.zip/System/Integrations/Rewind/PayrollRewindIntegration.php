<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Integrations\Rewind;
use Illuminate\Support\Facades\DB;
final class PayrollRewindIntegration implements PayrollRewindSource
{
    public const HOST_BINDING='titan.rewind.source-registry';
    public function __construct(private readonly ?PayrollRewindRecordProjector $projector=null){}
    public function available():bool{return $this->provider()!==null;}
    public function descriptor():array{return ['id'=>'titan-payroll.run-facts','contract_version'=>'1.0','tenant_key'=>'tenant_company_id','privacy'=>'minimized','source_contributor'=>true,'available'=>$this->available()];}
    public function watermark(int $tenantCompanyId,?string $occurredAt=null,?int $sequence=null):array
    {
        if($sequence===null){$sequence=(int)DB::table('ext_titan_payroll_signal_outbox')->where('tenant_company_id',$tenantCompanyId)->max('id');}
        $occurredAt=$occurredAt??date(DATE_ATOM);$opaque='v1:'.$sequence.':'.hash('sha256',$tenantCompanyId.'|'.$sequence);
        return ['contract_version'=>'1.0','tenant_company_id'=>$tenantCompanyId,'occurred_at'=>$occurredAt,'sequence'=>$sequence,'watermark'=>$opaque];
    }
    public function factsSince(int $tenantCompanyId,string $watermark):iterable
    {
        $sequence=$this->sequence($watermark);$rows=DB::table('ext_titan_payroll_signal_outbox')->where('tenant_company_id',$tenantCompanyId)->where('id','>',$sequence)->orderBy('id')->limit(500)->get(['id','signal','schema_version','payload','created_at']);$projector=$this->projector??new PayrollRewindRecordProjector();
        foreach($rows as $row){$payload=json_decode((string)$row->payload,true)?:[];yield $projector->project(['tenant_company_id'=>$tenantCompanyId,'event_type'=>(string)$row->signal,'version'=>$row->schema_version,'run_id'=>$payload['run_id']??null,'status'=>$payload['status']??null,'source_hash'=>$payload['finalized_snapshot_hash']??$payload['source_hash']??null,'decision'=>$payload['governance']??[],'sequence'=>(int)$row->id]);}
    }
    public function publish(array $facts):array{$p=$this->provider();if(!$p)return ['status'=>'rewind_unavailable','published'=>false];if(!method_exists($p,'publishSourceFacts'))throw new \RuntimeException('Configured Rewind source registry is incompatible.');$r=$p->publishSourceFacts($this->descriptor(),$facts);return is_array($r)?$r:['status'=>'invalid_rewind_receipt','published'=>false];}
    private function sequence(string $watermark):int{if(preg_match('/^v1:(\d+):[a-f0-9]{64}$/',$watermark,$m)!==1)return 0;return (int)$m[1];}
    private function provider():?object{if(!function_exists('app'))return null;try{$a=app();if(method_exists($a,'bound')&&$a->bound(self::HOST_BINDING)){ $v=$a->make(self::HOST_BINDING);return is_object($v)?$v:null;}}catch(\Throwable){}return null;}
}
