<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if(!Schema::hasTable('crm_capability_operations'))return;
        Schema::table('crm_capability_operations',function(Blueprint $t):void{
            if(!Schema::hasColumn('crm_capability_operations','command_contract_version'))$t->unsignedTinyInteger('command_contract_version')->default(3)->index('crm_cap_ops_contract_ver_idx');
            if(!Schema::hasColumn('crm_capability_operations','request_envelope'))$t->json('request_envelope')->nullable();
            if(!Schema::hasColumn('crm_capability_operations','expected_entity_version'))$t->unsignedBigInteger('expected_entity_version')->nullable();
            if(!Schema::hasColumn('crm_capability_operations','affected_resources'))$t->json('affected_resources')->nullable();
            if(!Schema::hasColumn('crm_capability_operations','invariant_results'))$t->json('invariant_results')->nullable();
            if(!Schema::hasColumn('crm_capability_operations','external_effect_references'))$t->json('external_effect_references')->nullable();
            if(!Schema::hasColumn('crm_capability_operations','compensation_state'))$t->string('compensation_state',40)->nullable()->index('crm_cap_ops_comp_state_idx');
            if(!Schema::hasColumn('crm_capability_operations','signal_references'))$t->json('signal_references')->nullable();
        });
    }

    public function down(): void
    {
        if(!Schema::hasTable('crm_capability_operations'))return;
        foreach(['signal_references','compensation_state','external_effect_references','invariant_results','affected_resources','expected_entity_version','request_envelope','command_contract_version'] as $column){
            if(Schema::hasColumn('crm_capability_operations',$column))Schema::table('crm_capability_operations',fn(Blueprint $t)=>$t->dropColumn($column));
        }
    }
};
