<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use App\Extensions\TitanSignalEngine\System\Exceptions\ImmutableRegistryDefinitionException;
use Illuminate\Database\Eloquent\Model;

/**
 * Legacy v0.4 subscription registry retained for upgrade compatibility only.
 * New control-plane writes use SignalSubscriptionVersion + runtime state.
 */
final class SignalSubscription extends Model
{
    protected $table = 'titan_signal_subscriptions';
    protected $guarded = [];

    protected $casts = [
        'event_patterns' => 'array',
        'accepted_schema_versions' => 'array',
        'scopes' => 'array',
        'categories' => 'array',
        'verticals' => 'array',
        'backoff_seconds' => 'array',
        'max_attempts' => 'integer',
        'timeout_seconds' => 'integer',
    ];

    protected static function booted(): void
    {
        static::updating(static function (): never {
            throw new ImmutableRegistryDefinitionException('Legacy Signal subscription rows are read-only; evolve the versioned registry instead.');
        });
        static::deleting(static function (): never {
            throw new ImmutableRegistryDefinitionException('Legacy Signal subscription rows cannot be deleted through the application model.');
        });
    }
}
