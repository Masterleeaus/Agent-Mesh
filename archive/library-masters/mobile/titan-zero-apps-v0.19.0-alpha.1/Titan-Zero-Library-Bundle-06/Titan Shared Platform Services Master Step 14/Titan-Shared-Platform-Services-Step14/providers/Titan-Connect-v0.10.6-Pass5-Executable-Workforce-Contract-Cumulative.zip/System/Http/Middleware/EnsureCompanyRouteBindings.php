<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Middleware;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class EnsureCompanyRouteBindings
{
    public function __construct(private readonly CompanyContext $context)
    {
    }

    public function handle(Request $request, Closure $next): Response
    {
        $companyId = $this->context->companyId($request);
        $route = $request->route();
        $parameters = is_object($route) && method_exists($route, 'parameters') ? $route->parameters() : [];

        foreach ($parameters as $parameter) {
            if ($parameter instanceof CompanyOwnedModel && $parameter->companyId() !== $companyId) {
                abort(404);
            }
        }

        return $next($request);
    }
}
