<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Automation;

use App\Extensions\Crm\System\Governance\CrmCommandBusGateway;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

/**
 * CRM automation evaluates tenant-owned rules, but never mutates authoritative
 * domain state directly. Every action is translated to a governed CRM command.
 */
final class CrmAutomationEngine
{
    public function __construct(
        private readonly ConnectionInterface $db,
        private readonly CrmAutomationTriggerCatalog $triggers,
        private readonly CrmAutomationActionCatalog $actions,
        private readonly CrmAutomationConditionEvaluator $conditionEvaluator,
        private readonly CrmCommandBusGateway $commands,
    ) {}

    /**
     * @return list<array<string,mixed>>
     */
    public function dispatch(int $userId,string $triggerKey,array $context,bool $simulation=false): array
    {
        $this->triggers->assertValid($triggerKey);
        $tenant=CrmCompanyScope::companyId($userId);
        $automationDepth=max(0,(int)($context['automation_depth']??0));
        $maxDepth=max(1,(int)config('crm.automation.max_depth',5));
        if($automationDepth >= $maxDepth)throw new RuntimeException('CRM automation recursion limit exceeded.');
        $automationChainId=trim((string)($context['automation_chain_id']??''));
        if($automationChainId==='')$automationChainId=(string)Str::ulid();

        $rules=$this->db->table('crm_automation_rules')
            ->where('company_id',$tenant)->where('enabled',true)->where('trigger_key',$triggerKey)->orderBy('id')->get();
        $runs=[];
        foreach($rules as $rule){
            $conditions=json_decode((string)($rule->conditions??'[]'),true)?:[];
            if(!$this->conditionEvaluator->matches($conditions,$context))continue;
            $fingerprint=hash('sha256',$rule->public_id.'|'.$triggerKey.'|'.$automationChainId.'|'.json_encode($context,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
            $plans=$this->plansForRule($rule,$context,$fingerprint,$automationChainId,$automationDepth);

            if($simulation){
                $runs[]=[
                    'simulation'=>true,'rule_public_id'=>(string)$rule->public_id,'trigger_key'=>$triggerKey,
                    'automation_chain_id'=>$automationChainId,'automation_depth'=>$automationDepth,
                    'fingerprint'=>$fingerprint,'actions'=>$plans,
                ];
                continue;
            }

            $existing=$this->db->table('crm_automation_runs')->where('company_id',$tenant)
                ->where('rule_public_id',$rule->public_id)->where('fingerprint',$fingerprint)->first();
            if($existing){$runs[]=(array)$existing;continue;}

            $publicId=(string)Str::ulid();
            $this->db->table('crm_automation_runs')->insert([
                'public_id'=>$publicId,'company_id'=>$tenant,'user_id'=>CrmCompanyScope::actorUserId($userId),
                'rule_public_id'=>$rule->public_id,'trigger_key'=>$triggerKey,'subject_type'=>$context['subject_type']??null,
                'subject_public_id'=>$context['subject_public_id']??null,'fingerprint'=>$fingerprint,
                'idempotency_key'=>$context['idempotency_key']??null,'status'=>'running','attempt_count'=>1,
                'context'=>json_encode($context+['automation_chain_id'=>$automationChainId,'automation_depth'=>$automationDepth],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
                'started_at'=>now(),'created_at'=>now(),'updated_at'=>now(),
            ]);

            try{
                $results=[];
                foreach($plans as $plan){
                    $results[]=[
                        'action'=>$plan['action'],'capability'=>$plan['capability'],
                        'command'=>$this->commands->request($plan['capability'],$plan['input'],'automation'),
                    ];
                }
                $status=$this->runStatus($results);
                $this->db->table('crm_automation_runs')->where('company_id',$tenant)->where('public_id',$publicId)->update([
                    'status'=>$status,'results'=>json_encode($results,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
                    'finished_at'=>now(),'updated_at'=>now(),
                ]);
            }catch(Throwable $e){
                $this->db->table('crm_automation_runs')->where('company_id',$tenant)->where('public_id',$publicId)->update([
                    'status'=>'failed','last_error'=>substr($e->getMessage(),0,2000),'finished_at'=>now(),'updated_at'=>now(),
                ]);
            }
            $row=$this->db->table('crm_automation_runs')->where('company_id',$tenant)->where('public_id',$publicId)->first();
            if($row)$runs[]=(array)$row;
        }
        return $runs;
    }

    /** @return list<array{action:string,capability:string,input:array<string,mixed>}> */
    private function plansForRule(object $rule,array $context,string $fingerprint,string $automationChainId,int $automationDepth): array
    {
        $plans=[];$definitions=json_decode((string)($rule->actions??'[]'),true)?:[];
        foreach(array_values($definitions) as $index=>$definition){
            $key=(string)($definition['action']??'');$this->actions->assertValid($key);
            $args=(array)($definition['arguments']??[]);
            $args=array_replace($args,array_intersect_key($context,array_flip([
                'subject_type','subject_public_id','contact_public_id','lead_public_id','title',
            ])));
            [$capability,$input]=$this->mapAction($key,$args,$context);
            $input['idempotency_key']='crm-automation:'.$rule->public_id.':'.$fingerprint.':'.$index;
            $input['automation_chain_id']=$automationChainId;
            $input['automation_depth']=$automationDepth+1;
            $plans[]=['action'=>$key,'capability'=>$capability,'input'=>$input];
        }
        return $plans;
    }

    /** @return array{0:string,1:array<string,mixed>} */
    private function mapAction(string $key,array $args,array $context): array
    {
        return match($key){
            'create_task'=>['crm.task.create',$args],
            'create_note'=>['crm.note.create',$args],
            'queue_notification'=>['crm.notification.queue',[
                'channel'=>(string)($args['channel']??'in_app'),'template_key'=>(string)($args['template_key']??'crm.automation'),
                'recipient'=>$args['recipient']??null,'payload'=>$args,'subject_type'=>$args['subject_type']??null,'subject_public_id'=>$args['subject_public_id']??null,
            ]],
            'update_lead_status'=>['crm.lead.update',$args+[
                'public_id'=>(string)($args['lead_public_id']??$context['subject_public_id']??''),
                'status'=>(string)($args['status']??'contacted'),
            ]],
            'dispatch_webhook'=>['crm.webhook.dispatch',[
                'event_key'=>(string)($args['event_key']??$context['trigger_key']??'crm.automation'),
                'payload'=>array_merge($context,(array)($args['payload']??[])),
            ]],
        };
    }

    /** @param list<array<string,mixed>> $results */
    private function runStatus(array $results): string
    {
        foreach($results as $result){
            $state=strtolower((string)($result['command']['status']??''));
            if(in_array($state,['rejected','failed','error'],true))return 'failed';
            if(in_array($state,['queued','deferred','awaiting_command_bus','processing'],true))return 'awaiting_governance';
        }
        return 'succeeded';
    }
}
