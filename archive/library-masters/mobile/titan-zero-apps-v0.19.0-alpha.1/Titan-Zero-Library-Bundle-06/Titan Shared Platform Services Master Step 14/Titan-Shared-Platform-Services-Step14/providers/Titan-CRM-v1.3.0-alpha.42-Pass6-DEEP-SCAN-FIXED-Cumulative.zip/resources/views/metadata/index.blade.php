@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Fields and Tags','subtitle'=>'Customise CRM metadata used across records and journeys.','surface'=>'settings','journey'=>'new-tag','secondaryJourneys'=>['new-custom-field']])
@if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif
<div class="row g-4"><div class="col-lg-5"><div class="card"><div class="card-header"><strong>Tags</strong></div><div class="card-body"><div class="d-flex flex-wrap gap-2">@forelse($tags as $tag)<span class="badge rounded-pill text-bg-light">{{ $tag['name'] }}</span>@empty<span class="text-muted">No tags yet. Use New Tag above.</span>@endforelse</div></div></div></div>
<div class="col-lg-7"><div class="card"><div class="card-header"><strong>Custom fields</strong></div><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Record</th><th>Field</th><th>Type</th><th>Required</th></tr></thead><tbody>@forelse($fields as $field)<tr><td>{{ $field['subject_type'] }}</td><td>{{ $field['name'] }}</td><td>{{ $field['field_type'] }}</td><td>{{ $field['is_required'] ? 'Yes' : 'No' }}</td></tr>@empty<tr><td colspan="4" class="text-muted">No custom fields yet. Use New Custom Field above.</td></tr>@endforelse</tbody></table></div></div></div></div>
@endcomponent
@endsection
