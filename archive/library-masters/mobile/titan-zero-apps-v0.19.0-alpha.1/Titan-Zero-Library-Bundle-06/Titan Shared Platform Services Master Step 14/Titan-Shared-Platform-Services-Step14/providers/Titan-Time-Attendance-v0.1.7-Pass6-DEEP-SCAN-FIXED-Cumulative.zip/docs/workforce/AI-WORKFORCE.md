# AI Workforce

Agent definitions are extension-owned and published through `resources/workforce/workforce-manifest.json`.

## Hierarchy

- **Time & Attendance Manager — Tier 1**: coordinates the domain and delegates bounded work.
- **Timesheet Auditor — Tier 2**: reviews time-entry/submission anomalies and costing evidence.
- **Attendance Exception Specialist — Tier 2**: investigates verification and offline evidence exceptions.
- **Workforce Presence Agent — Tier 2**: monitors active timers/presence and surfaces operational exceptions.

## Assets

The manifest defines roles, capabilities, skills, tools, prompts and workflows. `resources/workforce/wizards.json` owns guided policy setup flows; `resources/surfaces/surfaces.json` owns generative UI descriptors.

## Execution rules

Read tools are tenant-scoped and re-check the human principal's permissions. Write tools prepare or execute through `TimeWorkforceToolGateway`; authoritative identity and lineage come from `TimeWorkforceExecutionContext`, never model input.

Autonomy can be reduced by policy/runtime decisions but cannot self-promote. The extension does not duplicate Titan Risk, Assurance, Autonomy, Signal or Command Bus engines.
