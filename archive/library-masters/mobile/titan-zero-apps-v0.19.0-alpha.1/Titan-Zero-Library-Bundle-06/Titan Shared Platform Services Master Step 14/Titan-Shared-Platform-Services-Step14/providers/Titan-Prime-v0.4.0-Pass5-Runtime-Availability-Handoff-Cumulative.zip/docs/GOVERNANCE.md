# Governance

Prime cannot bypass Risk, Assurance, Autonomy, Governance or Command Bus. External constraints are authority ceilings; they never increase Prime's authority.

The v0.4.0 gateway layer reinforces that boundary:

- absence of an engine is `unavailable`, never allow;
- an engine exception is `failed`, never allow;
- explicit `denied` remains denied;
- `escalated` requires later escalation handling and never executes automatically;
- a result for the wrong engine/capability/operation is rejected as a contract mismatch;
- only `succeeded` can permit a future orchestration stage to continue.

Prime does not yet compose these engine decisions into an executable authorization chain. That is deliberately reserved for the governed-delegation pass.
