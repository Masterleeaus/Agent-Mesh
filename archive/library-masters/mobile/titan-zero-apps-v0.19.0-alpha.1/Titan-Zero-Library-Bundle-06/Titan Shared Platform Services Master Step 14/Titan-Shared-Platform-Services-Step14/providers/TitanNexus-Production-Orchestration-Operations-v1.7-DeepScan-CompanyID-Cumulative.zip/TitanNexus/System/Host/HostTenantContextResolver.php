<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Host;

use App\Extensions\TitanNexus\System\Contracts\TenantContextResolverContract;
use RuntimeException;

final class HostTenantContextResolver implements TenantContextResolverContract
{
    /** @param list<string> $userAttributes */
    public function __construct(
        private readonly mixed $publicResolver = null,
        private readonly array $userAttributes = ['company_id', 'tenant_company_id'],
    ) {}

    public function resolve(?object $user): int
    {
        if (is_callable($this->publicResolver)) {
            $response = ($this->publicResolver)(['user' => $user]);
            if (!is_array($response)) {
                throw new RuntimeException('Titan tenant context public contract must return an array.');
            }
            $tenant = $response['tenant_company_id'] ?? null;
            if (is_int($tenant) && $tenant > 0) {
                return $tenant;
            }
            if (is_string($tenant) && ctype_digit($tenant) && (int) $tenant > 0) {
                return (int) $tenant;
            }
            throw new RuntimeException('Titan tenant context public contract did not return a positive tenant_company_id.');
        }

        if ($user === null) {
            throw new RuntimeException('Titan Nexus tenant context is unavailable.');
        }

        foreach ($this->userAttributes as $attribute) {
            if (!is_string($attribute) || trim($attribute) === '') {
                continue;
            }
            $value = self::readAttribute($user, trim($attribute));
            if (is_int($value) && $value > 0) {
                return $value;
            }
            if (is_string($value) && ctype_digit($value) && (int) $value > 0) {
                return (int) $value;
            }
        }

        throw new RuntimeException('Titan Nexus tenant context is unavailable.');
    }

    private static function readAttribute(object $user, string $attribute): mixed
    {
        if (property_exists($user, $attribute)) {
            return $user->{$attribute};
        }
        if (method_exists($user, 'getAttribute')) {
            return $user->getAttribute($attribute);
        }
        return null;
    }
}
