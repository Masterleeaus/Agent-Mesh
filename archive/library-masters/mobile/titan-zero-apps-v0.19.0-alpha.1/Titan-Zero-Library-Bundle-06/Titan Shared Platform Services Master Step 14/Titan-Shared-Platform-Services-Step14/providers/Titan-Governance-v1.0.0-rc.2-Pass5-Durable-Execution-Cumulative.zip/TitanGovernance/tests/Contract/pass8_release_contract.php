<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function p8fail(string $m): never { fwrite(STDERR,"FAIL: {$m}\n"); exit(1); }
function p8ok(bool $c,string $m): void { if(!$c)p8fail($m); }
function p8same(mixed $e,mixed $a,string $m): void { if($e!==$a)p8fail($m.' expected='.var_export($e,true).' actual='.var_export($a,true)); }
$installer=json_decode((string)file_get_contents($root.'/extension.json'),true,512,JSON_THROW_ON_ERROR);
$sidecar=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
p8ok(version_compare((string)($installer['version']??'0.0.0'),'1.0.0-rc.1','>='),'installer release version >=1.0.0-rc.1');
p8ok(version_compare((string)($sidecar['version']??'0.0.0'),'1.0.0-rc.1','>='),'sidecar release version >=1.0.0-rc.1');
p8same('Titan Governance',$installer['name']??null,'legacy name');
p8same('extension',$installer['type']??null,'legacy type');
p8ok(is_string($installer['description']??null)&&trim($installer['description'])!=='','legacy description');
p8ok(array_key_exists('support_telegram',$installer)&&is_string($installer['support_telegram']),'legacy support_telegram');
foreach([
 'System/Host/TitanInstallerManifestContract.php',
 'System/Host/TitanFreshInstallPreflight.php',
 'System/Host/TitanExistingInstallUpgradePreflight.php',
 'System/Host/TitanProviderBootPreflight.php',
 'System/Host/TitanExactHostCertification.php',
 'tools/fresh_install_preflight.php',
 'tools/existing_install_upgrade_preflight.php',
 'tools/provider_boot_preflight.php',
 'tools/exact_host_certification.php',
 'release/ROUTE-INVENTORY.json',
 'release/MENU-INVENTORY.json',
 'release/CAPABILITY-INVENTORY.json',
 'release/DEPENDENCY-READINESS.json',
 'release/MIGRATION-INVENTORY.json',
 'release/HOST-CERTIFICATION-CHECKLIST.md',
 'release/OPERATOR-RUNBOOK.md',
 'PASS8-FINAL-CONVERGENCE-REPORT.md',
] as $f) p8ok(is_file($root.'/'.$f),'missing '.$f);
$migrations=glob($root.'/database/migrations/*.php')?:[];
p8same(4,count($migrations),'Pass 8 must not add a migration');
$esc=(string)file_get_contents($root.'/System/Escalation/GovernanceEscalationRepository.php');
p8ok(str_contains($esc,'min(200,$limit)'),'escalation queue must remain bounded <=200');
$dec=(string)file_get_contents($root.'/System/DecisionIntelligence/GovernanceDecisionReadRepository.php');
p8ok(str_contains($dec,'min(100,$limit)'),'decision history must remain bounded <=100');
$proj=(string)file_get_contents($root.'/System/Projection/GovernanceProjectionStore.php');
p8ok(str_contains($proj,'min(200,$limit)'),'projection history must remain bounded <=200');
$verify=(string)file_get_contents($root.'/bin/verify.php');
p8ok(str_contains($verify,"'1.0.0-rc.2'"),'self verifier targets current release candidate');
p8ok(str_contains($verify,'Installer 1.7.6'),'self verifier covers live installer compatibility');
echo "PASS: Pass 8 final release contract\n";
