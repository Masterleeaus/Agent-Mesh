<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Retention;
final class RewindLegalHoldException extends \RuntimeException {}
