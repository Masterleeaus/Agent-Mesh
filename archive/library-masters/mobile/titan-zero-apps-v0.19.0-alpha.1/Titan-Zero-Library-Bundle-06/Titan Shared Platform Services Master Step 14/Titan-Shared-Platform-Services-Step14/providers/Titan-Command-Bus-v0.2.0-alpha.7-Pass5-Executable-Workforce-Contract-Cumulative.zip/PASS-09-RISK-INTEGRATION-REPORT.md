# Pass 09 — Titan Risk Integration

## Result
PASS — Titan Command Bus now consumes authoritative Titan Risk evidence as an independent pre-Governance gate.

## Guarantees
- no local substitute risk classifier;
- Risk unavailable fails closed when required;
- Risk denial never reaches Governance or a domain adapter;
- allowed Risk decisions require durable reference + class;
- accepted Risk evidence is passed into Governance;
- receipts persist risk reference/class/optional score separately from Governance evidence;
- command outcome Signals carry the same Risk evidence;
- readiness exposes Risk dependency state;
- default Risk adapter remains unavailable until the real host binds Titan Risk.

## Runtime tests
- Risk unavailable -> blocked before Governance and adapter;
- malformed allowed decision -> blocked as `RISK_DECISION_INVALID`;
- Risk denial -> blocked with durable Risk evidence;
- accepted HIGH/0.81 decision -> passed to Governance and successful adapter receipt;
- completed Signal contains Risk reference/class;
- legacy idempotency and governed execution regressions remain green.
