<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanSignalEngine\System\Data\SignalBackpressurePolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryRedrivePolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryCachePolicy;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;

final class DeliveryRecoveryPolicyTest extends TestCase
{
    public function test_historical_dlq_counts_are_visible_but_do_not_inflate_current_pressure(): void
    {
        $snapshot = (new SignalBackpressurePolicy(100))->evaluate([
            'pending' => 1,
            'unresolved_dead_letter' => 1000,
            'resolved_historical_dead_letter' => 5000,
        ]);
        self::assertSame(1, $snapshot['total_pressure']);
        self::assertFalse($snapshot['backpressured']);
        self::assertSame(1000, $snapshot['unresolved_dead_letter']);
    }

    public function test_registry_revision_or_ttl_requires_refresh(): void
    {
        $policy = new SignalRegistryCachePolicy(5);
        $at = new DateTimeImmutable('2026-08-17T03:30:00+10:00');
        self::assertTrue($policy->shouldRefresh(1, 2, $at, $at->modify('+1 second')));
        self::assertTrue($policy->shouldRefresh(2, 2, $at, $at->modify('+5 seconds')));
        self::assertFalse($policy->shouldRefresh(2, 2, $at, $at->modify('+4 seconds')));
    }

    public function test_only_dead_letter_is_redrivable(): void
    {
        $policy = new SignalDeliveryRedrivePolicy();
        self::assertTrue($policy->canRedrive('dead_letter'));
        self::assertFalse($policy->canRedrive('delivered'));
        self::assertSame(0, $policy->nextAttemptCount());
    }
}
