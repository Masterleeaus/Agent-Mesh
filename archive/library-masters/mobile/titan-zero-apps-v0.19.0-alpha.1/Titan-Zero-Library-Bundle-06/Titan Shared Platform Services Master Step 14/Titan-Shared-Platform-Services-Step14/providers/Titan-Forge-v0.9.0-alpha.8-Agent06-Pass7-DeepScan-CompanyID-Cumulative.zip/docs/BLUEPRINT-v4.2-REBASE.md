# Blueprint v4.2 Rebase — Titan Forge v0.6.1-alpha.1

## Why this rebase exists

Titan Extension Blueprint v4.2 moved the canonical extension contract to Manifest v2.2 with production-core inheritance, canonical Signal causality, service identity, supply-chain evidence, release lifecycle and host/navigation convergence. Forge v0.6 still used an older sidecar and three-part causal chain.

## Changes applied

- Installer 1.7.8 root schema normalized to canonical fields/dependency objects.
- Governance sidecar upgraded from schema 1.0 to Manifest v2.2.
- The v0.6.1 rebase declared `builder-generator` + `signal-aware`. From v0.7 onward Forge also declares `ai-enabled` because it consumes AI Core planning/generation capabilities through public contracts; this modifier remains authority-neutral and does not imply direct model routing or deployment authority.
- `root_causation_id` added through runtime context, queue payloads, durable state and Signal envelopes.
- Canonical Signal dependency renamed/declaratively aligned to `titan-signal` and event schemas added.
- Production-core sections added for authority, governance, health, observability, authorization, concurrency, resilience, rollout, DR, supply chain, service identity, navigation and data governance.
- Production documentation set added.
- Existing Forge rule preserved: generated artifacts and release candidates have no self-deployment authority.

## Certification boundary

This is a development-stage canonical package. It is not a signed release candidate or production package, and no live MagicAI host certification is claimed. Current Governance/Command Bus callable release APIs remain unavailable, therefore release execution continues to fail closed.
