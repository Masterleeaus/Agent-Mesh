<?php

use App\Extensions\TitanGovernance\System\Http\Controllers\GovernanceActionController;
use App\Extensions\TitanGovernance\System\Http\Controllers\IndexController;
use App\Extensions\TitanGovernance\System\Http\Controllers\DecisionIntelligenceController;
use App\Extensions\TitanGovernance\System\Http\Controllers\ControlCentreController;
use App\Extensions\TitanGovernance\System\Http\Controllers\WorkforceOversightController;
use App\Extensions\TitanGovernance\System\Http\Controllers\ReadPlaneController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', IndexController::class)->name('index');
$router->get('/overview', IndexController::class)->name('overview');
$router->get('/signal-heatmap', [ReadPlaneController::class,'signalHeatmap'])->name('signal-heatmap');
$router->get('/operational-pressure', [ReadPlaneController::class,'operationalPressure'])->name('operational-pressure');
$router->get('/circuit-breakers', [ReadPlaneController::class,'circuitBreakers'])->name('circuit-breakers');
$router->get('/projection-history', [ReadPlaneController::class,'projectionHistory'])->name('projection-history');
$router->get('/control-centre', ControlCentreController::class)->name('control-centre');
$router->get('/workforce-oversight', WorkforceOversightController::class)->name('workforce-oversight');

$router->get('/decisions/{decisionId}', [DecisionIntelligenceController::class,'show'])->name('decisions.show');
$router->get('/decisions/{decisionId}/timeline', [DecisionIntelligenceController::class,'timeline'])->name('decisions.timeline');
$router->get('/decisions/{decisionId}/rewind', [DecisionIntelligenceController::class,'rewind'])->name('decisions.rewind');
$router->get('/decisions/{decisionId}/compliance', [DecisionIntelligenceController::class,'compliance'])->name('decisions.compliance');
$router->post('/decisions/delta', [DecisionIntelligenceController::class,'delta'])->middleware('throttle:60,1')->name('decisions.delta');

$router->get('/escalations', [GovernanceActionController::class,'queue'])->name('escalations.queue');
$router->post('/escalations/{escalationId}/actions/{action}', [GovernanceActionController::class,'execute'])
    ->where('action','approve|reject|hold|exception|escalate')
    ->middleware('throttle:30,1')
    ->name('escalations.actions.execute');
