@php
    $aiScope = $scope ?? 'all';
    $aiPageTitle = $pageTitle ?? '';
    $aiContext = (array) ($context ?? []);
    $record_type = $record_type ?? ($aiContext['record_type'] ?? null);
    if (is_string($record_type) && $record_type !== '') $aiContext['record_type'] = $record_type;
    try { $quickPrompts = app(\App\Extensions\Crm\System\Integrations\InteractionEngine\CrmInteractionQuickPromptRegistry::class)->forPage((string)$aiScope,(string)$aiPageTitle,is_string($record_type)?$record_type:null); } catch (\Throwable $e) { $quickPrompts = []; }
    $aiPlaceholder = $placeholder ?? ('Ask Titan about '.(trim((string)$aiPageTitle) !== '' ? strtolower((string)$aiPageTitle) : 'your operations').' or type /ai');
@endphp
<form method="POST" action="{{ route('dashboard.user.crm.interactions.chat') }}" class="crm-titan-command mb-4" data-crm-ai-bar data-surface="{{ $aiScope }}">
    @csrf
    <div class="crm-titan-command-row">
        <span class="crm-titan-spark" aria-hidden="true">✦</span>
        <div class="crm-titan-command-input-wrap">
            <input class="form-control crm-titan-command-input" name="typed_message" placeholder="{{ $aiPlaceholder }}" aria-label="Ask Titan">
        </div>
        <button class="btn btn-primary crm-titan-ask" type="submit">✦ Ask</button>
        <input type="hidden" name="surface" value="{{ $aiScope }}">
        @foreach($aiContext as $key=>$value)@if(is_scalar($value) && $value !== '')<input type="hidden" name="context[{{ $key }}]" value="{{ $value }}">@endif @endforeach
    </div>
    @if($quickPrompts !== [])
        <div class="crm-titan-quick-wrap">
            <div class="crm-titan-quick-label">Quick prompts</div>
            <div class="crm-titan-quick-list">
                @foreach($quickPrompts as $prompt)
                    <button type="submit" name="message" value="{{ $prompt['message'] }}" class="btn btn-sm crm-titan-prompt js-crm-quick-prompt">{{ $prompt['label'] }}</button>
                @endforeach
            </div>
        </div>
    @endif
</form>
@once
@push('css')
<style>
.crm-titan-command{padding:18px 20px;border:1px solid var(--tblr-primary,var(--bs-primary,#6f5cff));border-radius:22px;background:linear-gradient(135deg,var(--bs-tertiary-bg,#172033),var(--bs-body-bg,#0d1117));box-shadow:0 8px 30px rgba(0,0,0,.18);}
.crm-titan-command-row{display:flex;align-items:center;gap:12px}.crm-titan-spark{font-size:28px;line-height:1;color:var(--tblr-primary,var(--bs-primary,#6f5cff));width:34px;text-align:center}.crm-titan-command-input-wrap{flex:1;min-width:180px}.crm-titan-command-input{min-height:54px;border-radius:10px;font-size:1.05rem;background:var(--bs-body-bg,#0d1117)}.crm-titan-ask{min-height:48px;min-width:92px}.crm-titan-quick-wrap{margin-top:14px}.crm-titan-quick-label{font-size:.82rem;font-weight:600;margin-bottom:8px;opacity:.78}.crm-titan-quick-list{display:flex;flex-wrap:wrap;gap:8px}.crm-titan-prompt{border:1px solid color-mix(in srgb,var(--tblr-primary,var(--bs-primary,#6f5cff)) 55%,transparent);border-radius:999px;background:transparent;color:inherit;padding:.42rem .8rem}.crm-titan-prompt:hover{border-color:var(--tblr-primary,var(--bs-primary,#6f5cff));background:color-mix(in srgb,var(--tblr-primary,var(--bs-primary,#6f5cff)) 10%,transparent)}
@media(max-width:768px){.crm-titan-command{padding:14px}.crm-titan-command-row{flex-wrap:wrap}.crm-titan-command-input-wrap{flex-basis:calc(100% - 46px)}.crm-titan-ask{flex:1}}
</style>
@endpush
@endonce
