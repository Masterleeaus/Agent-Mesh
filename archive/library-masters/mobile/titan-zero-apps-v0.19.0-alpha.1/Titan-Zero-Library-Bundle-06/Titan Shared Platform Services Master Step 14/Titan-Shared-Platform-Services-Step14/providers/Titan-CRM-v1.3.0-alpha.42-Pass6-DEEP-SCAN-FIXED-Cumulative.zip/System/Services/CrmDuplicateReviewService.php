<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class CrmDuplicateReviewService
{
    private const TABLES=['lead'=>'crm_leads','company'=>'crm_companies','contact'=>'crm_contacts'];

    public function __construct(
        private ConnectionInterface $db,
        private CrmDuplicateScoreService $scores,
        private CrmIdentityAuthorityService $identity,
    ) {}

    public function queueForPair(int $userId,string $sourceType,string $sourcePublicId,string $candidateType,string $candidatePublicId): ?array
    {
        $tenant=CrmCompanyScope::companyId($userId);
        $source=$this->record($tenant,$sourceType,$sourcePublicId);
        $candidate=$this->record($tenant,$candidateType,$candidatePublicId);
        $sourceShape=$this->scoreShape($sourceType,$source);
        $candidateShape=$this->scoreShape($candidateType,$candidate);
        $score=$this->scores->score($sourceShape,$candidateShape);
        $threshold=(int)config('crm.identity.duplicate_review_threshold',90);
        if((int)$score['confidence']<$threshold)return null;

        $fingerprint=hash('sha256',json_encode([
            'identity_pair_fingerprint'=>1,
            'source'=>$sourceShape,
            'candidate'=>$candidateShape,
            'signals'=>$score['signals'],
        ],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
        $blocking=(int)$score['confidence']>=(int)config('crm.identity.duplicate_block_threshold',90);
        $query=$this->db->table('crm_duplicate_reviews')
            ->where('company_id',$tenant)
            ->where('source_type',$sourceType)->where('source_public_id',$sourcePublicId)
            ->where('candidate_type',$candidateType)->where('candidate_public_id',$candidatePublicId);
        $existing=$query->first();

        if(!$existing){
            $id=(string)Str::ulid();
            $this->db->table('crm_duplicate_reviews')->insertOrIgnore([
                'public_id'=>$id,'company_id'=>$tenant,
                'source_type'=>$sourceType,'source_public_id'=>$sourcePublicId,
                'candidate_type'=>$candidateType,'candidate_public_id'=>$candidatePublicId,
                'confidence'=>(int)$score['confidence'],'match_fingerprint'=>$fingerprint,
                'signals'=>json_encode($score['signals'],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
                'blocking'=>$blocking,'status'=>'pending','created_at'=>now(),'updated_at'=>now(),
            ]);
            $existing=$query->first();
        }
        if(!$existing)return null;

        $updates=[
            'confidence'=>(int)$score['confidence'],
            'match_fingerprint'=>$fingerprint,
            'signals'=>json_encode($score['signals'],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
            'blocking'=>$blocking,
            'updated_at'=>now(),
        ];
        $fingerprintChanged=!hash_equals((string)($existing->match_fingerprint??''),$fingerprint);
        if($fingerprintChanged && (string)$existing->status!=='merged'){
            $updates['status']='pending';
            $updates['resolution']=null;
            $updates['resolved_by_user_id']=null;
            $updates['resolved_at']=null;
        }
        if((string)$existing->status==='pending' || $fingerprintChanged){
            $this->db->table('crm_duplicate_reviews')->where('id',$existing->id)->update($updates);
        }
        return (array)$this->db->table('crm_duplicate_reviews')->where('id',$existing->id)->first();
    }

    public function guardLeadConversion(int $userId,string $leadPublicId): array
    {
        $tenant=CrmCompanyScope::companyId($userId);
        $lead=$this->record($tenant,'lead',$leadPublicId);
        $pending=[];$resolved=[];
        $limit=min(100,max(1,(int)config('crm.identity.max_review_candidates',20)));
        foreach(['company'=>'crm_companies','contact'=>'crm_contacts'] as $type=>$table){
            $q=$this->db->table($table)->where('company_id',$tenant)->whereNull('deleted_at');
            $email=$lead->normalized_email??null;$phone=$lead->normalized_phone??null;
            if(!$email&&!$phone)continue;
            $q->where(function($x)use($email,$phone){if($email)$x->orWhere('normalized_email',$email);if($phone)$x->orWhere('normalized_phone',$phone);});
            foreach($q->limit($limit)->get() as $candidate){
                $review=$this->queueForPair($userId,'lead',$leadPublicId,$type,(string)$candidate->public_id);
                if(!$review)continue;
                if(($review['status']??'pending')==='pending'&&($review['blocking']??false))$pending[]=$review;
                elseif(($review['status']??'')==='use_existing')$resolved[]=$review;
            }
        }
        if($pending!==[])throw ValidationException::withMessages([
            'duplicate_review'=>['Lead conversion requires duplicate review before creating or linking customer records.'],
            'review_public_ids'=>array_column($pending,'public_id'),
        ]);
        return $resolved[0]??[];
    }

    public function search(int $userId,array $filters=[]): array
    {
        $tenant=CrmCompanyScope::companyId($userId);
        $q=$this->db->table('crm_duplicate_reviews')->where('company_id',$tenant);
        if(isset($filters['status']))$q->where('status',(string)$filters['status']);
        if(isset($filters['source_type']))$q->where('source_type',(string)$filters['source_type']);
        return $q->orderByDesc('blocking')->orderByDesc('confidence')->orderByDesc('id')
            ->limit(min(250,max(1,(int)($filters['limit']??100))))->get()
            ->map(function($r)use($tenant):array{
                $row=(array)$r;
                $row['signals']=$this->decode($row['signals']??null);
                $row['resolution']=$this->decode($row['resolution']??null);
                $row['source']=$this->displayRecord($tenant,(string)$r->source_type,(string)$r->source_public_id);
                $row['candidate']=$this->displayRecord($tenant,(string)$r->candidate_type,(string)$r->candidate_public_id);
                return $row;
            })->all();
    }

    public function resolve(int $userId,string $reviewPublicId,int $actorUserId,string $decision,array $resolution=[]): array
    {
        if(!in_array($decision,['use_existing','dismissed'],true))throw ValidationException::withMessages(['decision'=>['Decision must be use_existing or dismissed.']]);
        $tenant=CrmCompanyScope::companyId($userId);
        $row=$this->db->table('crm_duplicate_reviews')->where('company_id',$tenant)->where('public_id',$reviewPublicId)->lockForUpdate()->first();
        if(!$row)throw ValidationException::withMessages(['review'=>['Duplicate review not found.']]);
        $this->record($tenant,(string)$row->source_type,(string)$row->source_public_id);
        $candidate=$this->record($tenant,(string)$row->candidate_type,(string)$row->candidate_public_id);
        $root=(string)($candidate->customer_unification_id??'');
        if($root==='')$root=match((string)$row->candidate_type){
            'company'=>$this->identity->ensureRootForCompany($userId,(string)$row->candidate_public_id),
            'contact'=>$this->identity->ensureRootForContact($userId,(string)$row->candidate_public_id,$candidate->customer_company_id?(int)$candidate->customer_company_id:null),
            'lead'=>$this->identity->ensureRootForLead($userId,(string)$row->candidate_public_id),
            default=>'',
        };
        $resolution['candidate_customer_unification_id']=$root;
        $this->db->table('crm_duplicate_reviews')->where('id',$row->id)->update([
            'status'=>$decision,'resolution'=>json_encode($resolution,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
            'resolved_by_user_id'=>$actorUserId,'resolved_at'=>now(),'updated_at'=>now(),
        ]);
        return (array)$this->db->table('crm_duplicate_reviews')->where('id',$row->id)->first();
    }

    private function displayRecord(int $tenant,string $type,string $publicId): ?array
    {
        $table=self::TABLES[$type]??null;if(!$table)return null;
        $row=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$publicId)->first();if(!$row)return null;
        return [
            'public_id'=>$publicId,'type'=>$type,
            'name'=>$type==='company'?(string)($row->name??''):trim((string)($row->name??'').' '.(string)($row->last_name??'')),
            'email'=>$row->normalized_email??$row->email??null,'phone'=>$row->normalized_phone??$row->phone??null,
            'deleted'=>!empty($row->deleted_at),'customer_unification_id'=>$row->customer_unification_id??null,
        ];
    }

    private function decode(mixed $value): array
    {
        if(is_array($value))return $value;if(!is_string($value)||$value==='')return[];
        $decoded=json_decode($value,true);return is_array($decoded)?$decoded:[];
    }

    private function record(int $tenant,string $type,string $publicId): object
    {
        $table=self::TABLES[$type]??throw ValidationException::withMessages(['resource'=>['Unsupported identity resource.']]);
        $row=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->first();
        if(!$row)throw ValidationException::withMessages(['resource'=>['Identity resource not found in this tenant.']]);
        return $row;
    }

    private function scoreShape(string $type,object $row): array
    {
        return [
            'name'=>$type==='company'?($row->name??''):($row->name??trim((string)($row->first_name??'').' '.(string)($row->last_name??''))),
            'email'=>$row->normalized_email??$row->email??null,
            'phone'=>$row->normalized_phone??$row->phone??null,
        ];
    }
}
