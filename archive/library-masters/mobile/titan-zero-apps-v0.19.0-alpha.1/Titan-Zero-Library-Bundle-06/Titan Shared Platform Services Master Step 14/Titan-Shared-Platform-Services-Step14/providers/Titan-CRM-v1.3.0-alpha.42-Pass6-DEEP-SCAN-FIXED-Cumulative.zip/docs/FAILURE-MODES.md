# Failure Modes

Fail closed on missing provider, tenant ambiguity, policy-disabled capability, failed authorization, governance denial, risk/assurance denial, autonomy denial, stale provider version or ambiguous executable provider selection.
