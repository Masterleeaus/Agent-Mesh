<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);

function fail_test(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function assert_true(bool $condition, string $message): void { if (!$condition) fail_test($message); }
function assert_same(mixed $expected, mixed $actual, string $message): void { if ($expected !== $actual) fail_test($message . ' expected=' . var_export($expected, true) . ' actual=' . var_export($actual, true)); }

$requiredFiles = [
    '/System/Contracts/GovernanceReadSourceContract.php',
    '/System/ReadPlane/GovernanceReadSourceRegistry.php',
    '/System/ReadPlane/UnavailableGovernanceReadSource.php',
    '/System/ReadPlane/TrustMapProjector.php',
    '/System/ReadPlane/GovernanceReadPlane.php',
];
foreach ($requiredFiles as $file) {
    assert_true(is_file($root . $file), 'missing read-plane production file ' . $file);
    require_once $root . $file;
}

use App\Extensions\TitanGovernance\System\Contracts\GovernanceReadSourceContract;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceReadPlane;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceReadSourceRegistry;
use App\Extensions\TitanGovernance\System\ReadPlane\TrustMapProjector;
use App\Extensions\TitanGovernance\System\ReadPlane\UnavailableGovernanceReadSource;

final class ContractAutonomySource implements GovernanceReadSourceContract
{
    public function key(): string { return 'titan-autonomy'; }
    public function required(): bool { return true; }
    public function snapshot(int $tenantCompanyId, array $context = []): array
    {
        return [
            'schema_version' => '1.0',
            'source' => 'titan-autonomy',
            'status' => 'HEALTHY',
            'observed_at' => '2026-08-19T00:00:00+10:00',
            'authorities' => [
                [
                    'tenant_company_id' => $tenantCompanyId,
                    'agent_id' => 'invoice-agent',
                    'capability' => 'crm.invoice.create',
                    'capability_variant' => 'standard',
                    'vertical' => 'field-services',
                    'workflow' => 'completed-job-invoice',
                    'context' => 'default',
                    'desired_authority_score' => 85.0,
                    'earned_authority_score' => 72.0,
                    'effective_authority_score' => 64.0,
                    'predictive_readiness_score' => 51.0,
                    'evidence' => [
                        ['type' => 'verified_success', 'outcome' => 'positive', 'observed_at' => '2026-08-18T23:30:00+10:00'],
                        ['type' => 'manager_approval', 'outcome' => 'positive', 'observed_at' => '2026-08-18T22:30:00+10:00'],
                    ],
                ],
                [
                    'tenant_company_id' => $tenantCompanyId,
                    'agent_id' => 'bad-agent',
                    'capability' => 'crm.payment.record',
                    'desired_authority_score' => 40.0,
                    'earned_authority_score' => 55.0,
                    'effective_authority_score' => 60.0,
                    'evidence' => [],
                ],
            ],
        ];
    }
}

$registry = new GovernanceReadSourceRegistry();
$registry->register(new ContractAutonomySource());
$registry->register(new UnavailableGovernanceReadSource('titan-risk', false, 'NOT_INSTALLED'));
$plane = new GovernanceReadPlane($registry, new TrustMapProjector());
$freshContext = ['now' => '2026-08-19T00:01:00+10:00', 'stale_after_seconds' => 300];
$result = $plane->trustMap(42, $freshContext);

assert_same('HEALTHY', $result['source_status'], 'autonomy source status must propagate');
assert_same(2, count($result['entries']), 'trust map entry count');
assert_same('Auto', $result['entries'][0]['effective_band'], '64 should map to Auto');
assert_same('VALID', $result['entries'][0]['integrity_status'], 'valid authority order');
assert_same(2, $result['entries'][0]['evidence_summary']['total'], 'evidence count');
assert_same('INVALID_AUTHORITY_ORDER', $result['entries'][1]['integrity_status'], 'malformed authority order must be surfaced, not repaired');
assert_same(60.0, $result['entries'][1]['effective_authority_score'], 'Governance must not rewrite source authority');

$health = $plane->sourceHealth(42, $freshContext);
assert_same('HEALTHY', $health['sources']['titan-autonomy']['status'], 'required autonomy source healthy');

$staleHealth = $plane->sourceHealth(42, ['now' => '2026-08-19T00:10:00+10:00', 'stale_after_seconds' => 300]);
assert_same('STALE', $staleHealth['sources']['titan-autonomy']['status'], 'old required source snapshot must be marked stale');
assert_same('DEGRADED', $staleHealth['status'], 'stale required observer degrades Governance but does not become fabricated authority');

$evidenceFeed = $plane->autonomyEvidence(42, $freshContext);
assert_same(2, count($evidenceFeed['evidence']), 'autonomy evidence feed must expose structured evidence records');
assert_same('verified_success', $evidenceFeed['evidence'][0]['type'], 'evidence type must remain structured');
assert_same('NOT_INSTALLED', $health['sources']['titan-risk']['status'], 'optional missing source remains visible');

$registry2 = new GovernanceReadSourceRegistry();
$registry2->register(new UnavailableGovernanceReadSource('titan-autonomy', true, 'UNAVAILABLE'));
$plane2 = new GovernanceReadPlane($registry2, new TrustMapProjector());
$missing = $plane2->trustMap(42);
assert_same('UNAVAILABLE', $missing['source_status'], 'missing required autonomy source must fail closed');
assert_same([], $missing['entries'], 'missing autonomy source cannot fabricate trust entries');

echo "PASS: Governance read plane contract\n";
