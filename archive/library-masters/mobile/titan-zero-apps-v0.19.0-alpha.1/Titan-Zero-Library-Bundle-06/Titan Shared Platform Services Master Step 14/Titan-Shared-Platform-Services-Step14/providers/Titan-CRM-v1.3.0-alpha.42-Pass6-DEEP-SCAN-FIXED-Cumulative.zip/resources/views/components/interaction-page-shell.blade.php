@php
    $interactionTitle = $title ?? 'CRM';
    $interactionSubtitle = $subtitle ?? null;
    $interactionSurface = $surface ?? 'all';
    $interactionJourney = $journey ?? null;
    if (is_string($interactionJourney) && $interactionJourney !== '') {
        try { $interactionJourney = app(\App\Extensions\Crm\System\Integrations\InteractionEngine\CrmInteractionJourneyRegistry::class)->get($interactionJourney); } catch (\Throwable $e) { $interactionJourney = null; }
    }
    $interactionContext = (array) ($context ?? []);
    $interactionRecordType = $recordType ?? ($interactionContext['record_type'] ?? null);
    if (is_string($interactionRecordType) && $interactionRecordType !== '') {
        $interactionContext['record_type'] = $interactionRecordType;
    }
    $interactionSecondaryJourneys = $secondaryJourneys ?? [];
    $resolveJourney = static function ($candidate) {
        if (!is_string($candidate) || $candidate === '') return $candidate;
        try { return app(\App\Extensions\Crm\System\Integrations\InteractionEngine\CrmInteractionJourneyRegistry::class)->get($candidate); } catch (\Throwable $e) { return null; }
    };
    $interactionSecondaryJourneys = array_values(array_filter(array_map($resolveJourney, (array) $interactionSecondaryJourneys)));
    $recordActions = (array) ($recordActions ?? []);
    if ($recordActions === [] && is_string($interactionRecordType) && $interactionRecordType !== '') {
        try { $recordActions = app(\App\Extensions\Crm\System\Integrations\InteractionEngine\CrmInteractionRecordActionRegistry::class)->forRecord($interactionRecordType,$interactionContext); } catch (\Throwable $e) { $recordActions = []; }
    }
    $globalNewMenu = ['primary'=>null,'secondary'=>[]];
    try {
        $globalNewMenu = app(\App\Extensions\Crm\System\Integrations\InteractionEngine\CrmGlobalNewMenuRegistry::class)->forPage(
            (int) auth()->id(),
            (string) $interactionSurface,
            (string) $interactionTitle,
            is_string($interactionRecordType) ? $interactionRecordType : null,
            $interactionContext,
            is_array($interactionJourney) ? ($interactionJourney['key'] ?? null) : null,
        );
    } catch (\Throwable $e) { $globalNewMenu = ['primary'=>null,'secondary'=>[]]; }
@endphp
<div class="container-fluid py-4" data-crm-interaction-page="{{ $interactionSurface }}" @if($interactionRecordType) data-record-type="{{ $interactionRecordType }}" @endif>
    @include('crm::components.interaction-ai-bar',['scope'=>$interactionSurface,'pageTitle'=>$interactionTitle,'context'=>$interactionContext,'record_type'=>$interactionRecordType])
    @include('crm::components.global-new-adapter',['menu'=>$globalNewMenu])
    <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
        <div><h1 class="mb-1">{{ $interactionTitle }}</h1>@if($interactionSubtitle)<p class="text-muted mb-0">{{ $interactionSubtitle }}</p>@endif</div>
        @if($interactionJourney || $interactionSecondaryJourneys || $recordActions)
        <div class="d-flex flex-wrap gap-2" data-crm-record-actions data-crm-local-new-fallback>
            @if($interactionJourney)@include('crm::components.interaction-launcher',['journey'=>$interactionJourney,'prefill'=>$interactionContext])@endif
            @foreach($interactionSecondaryJourneys as $secondaryJourney)@include('crm::components.interaction-primary-action',['journey'=>$secondaryJourney['key'],'label'=>$secondaryJourney['newLabel'],'prefill'=>$interactionContext])@endforeach
            @foreach($recordActions as $action)
                @if(($action['available'] ?? false) === true)
                    @include('crm::components.interaction-primary-action',['journey'=>$action['journey'],'label'=>$action['label'],'prefill'=>$action['prefill'] ?? $interactionContext])
                @endif
            @endforeach
        </div>
        @endif
    </div>
    {{ $slot }}
</div>
