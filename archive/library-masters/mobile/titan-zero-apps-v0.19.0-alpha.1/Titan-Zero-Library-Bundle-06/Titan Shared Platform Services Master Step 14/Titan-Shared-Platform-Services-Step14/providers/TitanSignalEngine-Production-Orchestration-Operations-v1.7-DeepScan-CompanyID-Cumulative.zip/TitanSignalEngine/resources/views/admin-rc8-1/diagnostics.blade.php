@extends('panel.layout.app')
@section('content')
@php
    $health=$dashboard['health']??[];$delivery=(array)($health['delivery']??[]);
    $checks=collect($certification['checks']??[])->keyBy('id');
    $schedule=$checks->get('runtime.schedules');$archive=$checks->get('runtime.archive_storage');$nav=$checks->get('runtime.navigation');$routes=$checks->get('runtime.routes');$queue=$checks->get('runtime.queue_driver');
    $pageTitle='Diagnostics';$pageSubtitle='Signal health, queues, schedules, archive status and host certification';$activePage='diagnostics';
@endphp
@include('titan-signal-engine::admin-rc8-1.partials.styles')
<div class="tse-wrap">
@include('titan-signal-engine::admin-rc8-1.partials.header')
@include('titan-signal-engine::admin-rc8-1.partials.alerts')
@include('titan-signal-engine::admin-rc8-1.partials.filter')
<div class="tse-grid tse-section">
    <div class="tse-card"><div class="tse-kpi-label">Signal health</div><div class="tse-value-sm">{{ strtoupper((string)($health['status']??'unknown')) }}</div><div class="tse-muted">captured {{ $health['captured_at']??'—' }}</div></div>
    <div class="tse-card"><div class="tse-kpi-label">Queue</div><div class="tse-value-sm">{{ $queue['status']??'UNKNOWN' }}</div><div class="tse-muted">pending {{ $delivery['pending']??0 }} · retry {{ $delivery['retry_wait']??0 }}</div></div>
    <div class="tse-card"><div class="tse-kpi-label">Schedules</div><div class="tse-value-sm">{{ $schedule['status']??'UNKNOWN' }}</div><div class="tse-muted">{{ $schedule['message']??'Not checked' }}</div></div>
    <div class="tse-card"><div class="tse-kpi-label">Archive</div><div class="tse-value-sm">{{ $archive['status']??'UNKNOWN' }}</div><div class="tse-muted">{{ $archive['message']??'Not checked' }}</div></div>
    <div class="tse-card"><div class="tse-kpi-label">Routes</div><div class="tse-value-sm">{{ $routes['status']??'UNKNOWN' }}</div><div class="tse-muted">nine Super Admin routes including eight child surfaces</div></div>
    <div class="tse-card"><div class="tse-kpi-label">Navigation</div><div class="tse-value-sm">{{ $nav['status']??'UNKNOWN' }}</div><div class="tse-muted">parent plus eight child menu rows</div></div>
    <div class="tse-card"><div class="tse-kpi-label">Host certification</div><div class="tse-value">{{ $certification['overall']??'UNKNOWN' }}</div><div class="tse-muted">PASS {{ $certification['summary']['PASS']??0 }} · WARN {{ $certification['summary']['WARN']??0 }} · FAIL {{ $certification['summary']['FAIL']??0 }}</div></div>
</div>
<div class="tse-card tse-section"><h2>Certification checks</h2><div class="tse-scroll"><table class="tse-table"><thead><tr><th>Check</th><th>Status</th><th>Message</th><th>Details</th></tr></thead><tbody>@forelse(($certification['checks']??[]) as $c)<tr><td class="tse-code">{{ $c['id'] }}</td><td><span class="tse-badge">{{ $c['status'] }}</span></td><td>{{ $c['message'] }}</td><td class="tse-code">{{ empty($c['details'])?'—':json_encode($c['details'],JSON_UNESCAPED_SLASHES) }}</td></tr>@empty<tr><td colspan="4">No certification checks returned.</td></tr>@endforelse</tbody></table></div></div>
</div>
@endsection
