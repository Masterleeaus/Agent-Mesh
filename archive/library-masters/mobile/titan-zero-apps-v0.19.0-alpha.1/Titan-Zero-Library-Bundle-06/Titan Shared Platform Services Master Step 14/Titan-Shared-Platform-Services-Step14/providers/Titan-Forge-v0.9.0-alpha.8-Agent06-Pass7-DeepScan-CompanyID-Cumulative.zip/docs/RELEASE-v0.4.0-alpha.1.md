# Titan Forge v0.4.0-alpha.1

This cumulative alpha adds the first deterministic workforce assembly slice on top of the v0.3 typed domain/persistence foundation.

Implemented:
- Titan Role Specification Draft-07 schema.
- Titan AI Workforce-owned six-role Solo bootstrap catalogue.
- tier role limits 6 / 15 / 30 / 68 without embedding subscription prices.
- non-Solo compositions fail closed until canonical Workforce mappings are imported.
- deterministic generic role stub engine.
- isolated tenant/operation workspace generation.
- idempotent generation manifest with trace, correlation, causation and operation identifiers.
- active `titan-forge` queue with unique `GenerateSkeletonTeam` job.
- `forge:manifest` and `forge:generate-skeleton` commands.
- runtime tenant middleware for user Forge surfaces.
- read-only user/admin build history.
- config fail-fast validation.
- release ZIP secret/path/symlink/case-collision scanning.
- Draft-07 role schema and team dependency validation in release verification.
- internal lifecycle event for later verified Titan Signal binding.

Not enabled:
- AI code generation.
- live deployment from Forge.
- public build webhooks.
- direct billing/pricing ownership.
- invented 15/30/68 role mappings.
- Model Council runtime invocation.
