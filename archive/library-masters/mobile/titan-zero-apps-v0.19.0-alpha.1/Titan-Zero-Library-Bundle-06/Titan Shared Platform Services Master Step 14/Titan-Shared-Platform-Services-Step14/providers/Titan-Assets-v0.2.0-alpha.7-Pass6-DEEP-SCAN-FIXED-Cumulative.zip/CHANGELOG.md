# 0.2.0-alpha.5 — Agent-01 Pass 3

- Added canonical cross-extension execution envelope, correlation/causation, idempotency scope, authority/provenance/evidence traceability, duplicate suppression and deferred unknown-outcome semantics.

# Changelog

## 0.2.0-alpha.2 — full asset donor convergence + Installer 1.7.8 manifest correction

- Corrected root `dependencies` to Installer 1.7.8 object-array form (`slug` + `version`).
- Expanded the initial convergence scaffold into the full useful asset-domain surface from Asset, FSM Equipment, Equipment Warranty, Repair, Repair Template, Vehicle, FSM Stock equipment-register/check, ManagedPremises asset-linking, and the previous Locker asset authority.
- Added asset types/categories, images/documents, lending/history, quantity allocations/revocations, full QR actions, company prefixes/settings, maintenance priority/assignment/notifications, richer repair costs/root cause/parts/stages, warranty profiles/claims/costs, downtime, mileage, location register, equipment checks, lifecycle/write-off/sale/retirement, valuation/depreciation and reports.
- New Assets schemas use `company_id`; legacy `tenant_company_id` tables are supported only for non-destructive migration compatibility.
- Expanded self-healing navigation to adopt historical CRM/Locker asset menu keys while preserving Inventory & Supplies ownership in Titan Locker.
- Corrected self-healing duplicate-route handling so the Assets parent and Overview child may intentionally share the overview route without deactivating the parent.

## 0.1.0-alpha.1 — initial authority-convergence scaffold

- Established Titan Assets as the intended asset authority and introduced first-pass tools/equipment/fleet/maintenance/repair/warranty services.
- This release did **not** contain full donor feature parity and is superseded by 0.2.0-alpha.2.

## 0.2.0-alpha.3 — Workforce / Blueprint v4.2.1 convergence
- Canonical Manifest v2.2 metadata.
- Role-neutral Titan AI Workforce integration contract; Workforce remains identity/role/work-item owner.
- Canonical active tenancy is `company_id`; legacy tenant key limited to compatibility/migration paths.
- Governed execution, provider provenance, fail-closed availability semantics and contract regression test.
