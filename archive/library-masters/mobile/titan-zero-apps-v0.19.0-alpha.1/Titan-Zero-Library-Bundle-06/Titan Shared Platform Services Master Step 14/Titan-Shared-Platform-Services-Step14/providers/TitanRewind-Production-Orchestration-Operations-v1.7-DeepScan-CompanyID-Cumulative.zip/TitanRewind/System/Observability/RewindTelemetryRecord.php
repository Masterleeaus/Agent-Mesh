<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Observability;

final class RewindTelemetryRecord
{
    private const SENSITIVE = ['password','password_confirmation','remember_token','token','access_token','refresh_token','secret','client_secret','api_key','apikey','private_key','card_number','cvv','authorization','cookie','session_id','signature'];

    public static function metric(string $name, int|float $value, string $unit, RewindTraceContext $context, array $attributes = []): array
    { return self::base('metric',$name,$context,self::sanitize($attributes))+['value'=>$value,'unit'=>$unit,'level'=>'INFO']; }
    public static function span(string $name, int|float $durationMs, string $status, RewindTraceContext $context, array $attributes = []): array
    { return self::base('span',$name,$context,self::sanitize($attributes))+['duration_ms'=>$durationMs,'status'=>strtoupper($status),'level'=>'INFO']; }
    public static function log(string $name, string $level, RewindTraceContext $context, array $attributes = []): array
    { return self::base('log',$name,$context,self::sanitize($attributes))+['level'=>strtoupper($level)]; }
    private static function base(string $kind,string $name,RewindTraceContext $context,array $attributes): array { return ['kind'=>$kind,'name'=>$name]+$context->toArray()+['attributes'=>$attributes]; }
    private static function sanitize(array $input): array
    {
        $out=[]; foreach ($input as $key=>$value) { $normalized=strtolower((string)$key); if (in_array($normalized,self::SENSITIVE,true)) continue; $out[$key]=is_array($value)?self::sanitize($value):$value; } return $out;
    }
}
