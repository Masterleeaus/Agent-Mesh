<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Extensions\TitanConnect\System\Services\ChannelHealthService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class ChannelHealthController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly ChannelAccessPolicy $policy,
    ) {
    }

    public function show(Request $request, ChannelConnection $connection, ChannelHealthService $health): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        abort_unless((int) $connection->company_id === $companyId, 404);
        abort_unless($this->policy->canManage($connection, $actorId), 403);
        return response()->json($health->check($connection));
    }
}
