<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

final class LearningScopePolicy
{
    public function userEnabled(array $settings): bool
    {
        return (bool) ($settings['user'] ?? false);
    }

    public function businessEnabled(array $settings): bool
    {
        return (bool) ($settings['business'] ?? false);
    }

    public function systemWideEnabled(array $settings, bool $payloadIsDeidentified): bool
    {
        return (bool) ($settings['system'] ?? false) && $payloadIsDeidentified;
    }
}
