<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use DateTimeInterface;
use InvalidArgumentException;

final readonly class SignalRegistryCachePolicy
{
    public function __construct(public int $ttlSeconds)
    {
        if ($this->ttlSeconds < 1 || $this->ttlSeconds > 300) {
            throw new InvalidArgumentException('Signal registry cache TTL must be between 1 and 300 seconds.');
        }
    }

    public function shouldRefresh(
        ?int $loadedRevision,
        int $currentRevision,
        ?DateTimeInterface $lastCheckedAt,
        DateTimeInterface $now,
    ): bool {
        if ($loadedRevision === null || $loadedRevision !== $currentRevision || $lastCheckedAt === null) {
            return true;
        }

        return ($now->getTimestamp() - $lastCheckedAt->getTimestamp()) >= $this->ttlSeconds;
    }
}
