# Disaster Recovery
Back up extension-owned durable knowledge state with the host database. Target policy is RPO 60 minutes and RTO 240 minutes. Restore must preserve source/provenance lineage and rerun reconciliation before authoritative operations resume. Pass 2 has durable knowledge state but still has no external refresh state or remote evidence store.
