# Signal Events

Prime is Signal-aware and carries `trace_id`, `correlation_id`, `causation_id` and `root_causation_id`. v0.2.1 declares no emitted or consumed runtime event families because mission orchestration is not active yet. Future event families must be versioned, schema-backed, Prime-owned where emitted, and must never confer business truth or execution authority.
