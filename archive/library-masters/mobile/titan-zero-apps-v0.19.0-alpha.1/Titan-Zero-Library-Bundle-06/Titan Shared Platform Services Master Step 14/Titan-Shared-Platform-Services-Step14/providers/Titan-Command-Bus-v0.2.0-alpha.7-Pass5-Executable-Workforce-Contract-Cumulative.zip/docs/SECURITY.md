# Security

Tenant and actor authority are supplied only through trusted CommandContext. Payloads never contain trusted tenant identity. Unknown capabilities fail closed. Direct foreign-domain table writes are forbidden. Secrets and raw chain-of-thought must not be stored in receipts or Signals.


## Pass 11 — Titan Autonomy integration

Command dispatch now resolves earned autonomy after Risk and Assurance and before Governance. Autonomy is capability/workflow-specific evidence, never a caller-selected permission. When `require_autonomy=true`, unavailable, denied, or malformed autonomy evidence fails closed before Governance or domain execution. Successful decisions preserve `autonomy_reference`, `autonomy_level`, `autonomy_workflow`, and evidence references in receipts and Signal telemetry.
