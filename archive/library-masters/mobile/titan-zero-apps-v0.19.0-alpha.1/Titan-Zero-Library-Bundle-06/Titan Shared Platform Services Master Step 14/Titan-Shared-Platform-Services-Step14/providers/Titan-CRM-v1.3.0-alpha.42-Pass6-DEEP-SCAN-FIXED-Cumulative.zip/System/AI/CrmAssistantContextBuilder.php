<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\AI;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Security\CrmPermissionService;
use App\Extensions\Crm\System\Services\{CrmDashboardService,CrmTimelineService};
use Illuminate\Database\ConnectionInterface;
final class CrmAssistantContextBuilder
{
    public function __construct(private CrmDashboardService $dashboard,private CrmTimelineService $timeline,private CrmPermissionService $permissions,private CrmRecordReferenceResolver $records,private ConnectionInterface $db){}
    public function build(int $userId,array $scope=[]): array
    {
        $record=$this->records->resolve($userId,$scope['record_type']??null,$scope['record_public_id']??null);
        return ['dashboard'=>$this->dashboard->summary($userId),'follow_ups'=>$this->db->table('crm_leads')->where('company_id', CrmCompanyScope::companyId($userId))->whereNotNull('next_follow_up_at')->where('next_follow_up_at','<=',now()->addDays(7))->orderBy('next_follow_up_at')->limit(20)->get()->map(fn($r)=>(array)$r)->all(),'recent_activity'=>$this->db->table('crm_activities')->where('company_id', CrmCompanyScope::companyId($userId))->orderByDesc('occurred_at')->limit(20)->get()->map(fn($r)=>(array)$r)->all(),'permissions'=>$this->permissions->grantedPermissions($userId),'record_context'=>$record];
    }
}
