<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Contracts;

interface HealthCheckContract
{
    /** @return array<string,mixed> */
    public function check(): array;
}
