# Testing Guide — Pass 3

## Dependency-free checks

```bash
php scripts/verify.php
php scripts/verify_migrations.php
php scripts/verify_security.php
```

The security verifier checks route profile registration, explicit API permissions, company-scoped route binding, anti-spoof controls, immutable tenant keys and queue tenant context.

## Blueprint checks

```bash
python3 tools/validate_manifest.py /path/to/TitanMapsIntelligence --check-files
python3 tools/scan_package.py /path/to/TitanMapsIntelligence
```

## PHP syntax

```bash
find . -type f -name '*.php' -print0 | xargs -0 -n1 php -l
```

## Architecture/unit tests

- `ManifestContractTest.php` — manifest/provider/tenant contract.
- `MigrationSchemaContractTest.php` — 13 table migrations and model/schema coverage.
- `RouteSecurityContractTest.php` — four profiles, explicit permissions, tenant-safe bindings, anti-spoof and queue invariants.
- `QueueTenantContextTest.php` — activation, nesting/restoration and empty-company rejection.

## Host feature tests

`tests/Feature/RouteSecurityTest.php` covers:

- spoofed `company_id` rejection;
- denied tenant permission;
- denied admin permission;
- a company-A request attempting to resolve a company-B route model ID.

The cross-company database test uses the same disposable MySQL host environment as the migration smoke test.

## MySQL migration smoke test

`tests/Integration/MigrationCrudSmokeTest.php` migrates the extension, validates all contract columns and CRUD-smokes all 13 persistent model types with `forCompany()` isolation.

## Environment note

The archive build workspace has no MagicAI Laravel host/MySQL runtime. Host HTTP/MySQL tests are packaged for the integrated Titan environment and must not be reported as executed until they are actually run there.

## Pass 4 configuration checks

```bash
php scripts/verify_configuration.php
php scripts/verify_configuration_wiring.php
php scripts/verify_provider_settings_save.php
```

The first script executes deterministic ranking/matching behavior against alternate valid configurations and verifies invalid weights, thresholds, caps, provider timeout and retry settings fail closed. The second verifies operational code paths are wired to `MapsConfiguration` instead of reintroducing hard-coded limits.

## Pass 6 location checks

```bash
php scripts/verify_location_domain.php
php scripts/test_location_runtime.php
```

The first verifies the canonical table/model/gateway/service contract. The second runs dependency-free checks that valid references resolve while deleted/foreign-company references do not, and that geocode/manual/GPS freshness thresholds are deterministic. Host PHPUnit coverage additionally verifies the service rejects missing/foreign references before geocoding or persistence.

## Pass 9 geofencing gates
Run `php scripts/verify_geofencing.php`, `php scripts/test_geofence_math_runtime.php` and `php scripts/test_geofence_transition_runtime.php`. Host PHPUnit adds model/evaluator/tenant tests when installed inside the full Titan Laravel application.
