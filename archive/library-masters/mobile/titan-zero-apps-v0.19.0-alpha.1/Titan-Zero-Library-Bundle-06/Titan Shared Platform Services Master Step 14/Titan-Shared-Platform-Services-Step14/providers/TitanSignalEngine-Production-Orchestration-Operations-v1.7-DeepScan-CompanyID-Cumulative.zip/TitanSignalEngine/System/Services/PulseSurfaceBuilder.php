<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Data\PulseSnapshot;

final class PulseSurfaceBuilder
{
    /** @return array<string,mixed> */
    public function build(PulseSnapshot $snapshot): array
    {
        $metrics = $snapshot->metrics;
        $attention = $snapshot->attention;
        $headline = match ($attention->band) {
            'critical' => 'Critical operational signals require attention',
            'high' => 'Elevated operational pressure detected',
            'medium' => 'Some operational issues need review',
            default => 'Operations are within normal Signal thresholds',
        };

        return [
            'headline' => $headline,
            'attention' => $attention->toArray(),
            'window' => $snapshot->window->key,
            'signal_count' => (int) ($metrics['event_count'] ?? 0),
            'event_rate_per_second' => (float) ($metrics['event_rate_per_second'] ?? 0),
            'critical_count' => (int) ($metrics['critical_count'] ?? 0),
            'error_count' => (int) ($metrics['error_count'] ?? 0),
            'stalled_trace_count' => (int) ($metrics['stalled_trace_count'] ?? 0),
            'missing_receipt_count' => (int) ($metrics['missing_receipt_count'] ?? 0),
            'dead_letter_count' => (int) ($metrics['dead_letter_count'] ?? 0),
            'latency' => $snapshot->latency,
            'top_sources' => array_slice($snapshot->sources, 0, 5),
            'top_event_types' => array_slice($snapshot->topEventTypes, 0, 5),
            'health' => $snapshot->health,
            'generated_at' => $snapshot->generatedAt->format(DATE_ATOM),
        ];
    }
}
