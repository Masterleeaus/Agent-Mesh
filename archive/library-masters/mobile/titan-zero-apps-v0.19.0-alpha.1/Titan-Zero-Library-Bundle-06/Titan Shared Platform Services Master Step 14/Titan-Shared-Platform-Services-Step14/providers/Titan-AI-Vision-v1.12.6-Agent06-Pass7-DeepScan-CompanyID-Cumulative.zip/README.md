# Titan AI Vision 1.12.0

Standalone Titan/MagicAI native extension for evidence-first visual intelligence in field and home services.

## What changed in 1.1
- Mobile-first evidence capture with live image previews.
- Mode/profile-specific evidence checklist loaded dynamically.
- Each photo can be assigned an evidence role and required capture slot before analysis.
- Findings now include `image_index` so spatial annotations attach to the correct source image.
- Non-destructive 0–1000 coordinate boxes are rendered over evidence images.
- Human review states: confirmed, rejected, or needs more evidence.
- Missing-evidence requests are persisted and displayed in Evidence Review.
- Expanded field/home-service inspection profiles including window cleaning, carpet/upholstery, pressure washing, handyman/property maintenance, arborist, locksmith/security, security systems, waste removal, NDIS home maintenance and facilities maintenance.

## Core capability
- 8 operational modes: Job Check, Before/After, Site Inspection, Equipment Scan, Damage Assessment, Safety Evidence, Parts Recognition, Completion Assurance.
- Provider-neutral `VisionProviderContract`.
- Host-provider discovery first; OpenAI Responses API fallback second.
- Immutable evidence sets with local SHA-256 fingerprints.
- Governed routing to job notes, quote scope, assets, safety review, follow-up work and Completion Assurance.
- Titan Assist context integration when `titan.assist.context` is available.
- Titan Assist governed action execution when `titan.assist.action-executor` is available.
- Titan Assurance handoff for Completion Assurance.

## Install / Upgrade
Install through Titan Extension Manager / MagicAI Marketplace extension flow, then run:

```bash
php artisan migrate --force
php artisan route:clear
php artisan view:clear
php artisan optimize:clear
```

The extension registers service alias `titan.ai.vision`. Existing v1.0 evidence tables are adopted without destructive replacement.

## Data safety
Original evidence is never edited. Spatial boxes and review decisions are overlays/metadata. Creative/retouched output from Titan Visual must never be treated as original evidence. Completion Assurance never directly calls job completion.

## Provider behavior
The manager first looks for host bindings configured in `provider_bindings` (`titan.vision.provider`, `magicai.vision.provider`). If none are available it uses the OpenAI Responses API fallback and reuses MagicAI's configured OpenAI key where possible.


## Blueprint v4.2.0 alignment
Titan AI Vision v1.3.0 is classified as an `intelligence-engine`. Inference is non-authoritative. The extension owns visual evidence state and proposals only; authoritative domain writes remain with their owning extensions and governed execution boundaries.

## v1.3 Evidence Intelligence
- Automatic before/after pairing and comparison scoring.
- Persistent evidence timelines/history by job/property/customer/asset.
- Profile-specific Completion Assurance readiness packages.
- Assurance eligibility remains advisory; Titan AI Vision cannot complete jobs.

## v1.5 Longitudinal Change Detection
- Compares the current visit only against its explicitly verified historical baseline.
- Canonical visual change states: `new`, `resolved`, `improved`, `worsened`, `unchanged`, `uncertain`, `not_comparable`.
- Titan policy deterministically owns final change classification; provider-recommended labels are retained only as metadata.
- Cross-visit capture pairing uses matching capture slots so unrelated views are not compared.
- Low comparability or low confidence automatically downgrades to `not_comparable` / `uncertain`.
- Persisted change records remain human-reviewable and appear in Evidence Review and timeline summaries.
- A change result remains non-authoritative visual inference and cannot itself mutate jobs, assets, quotes, safety status or completion state.


## Advanced Spatial Inspection (v1.12.0)
Findings may reference multiple non-destructive spatial regions. Supported geometry is rectangle, polygon, and point on the normalized 0–1000 grid. `group_key` associates related findings/regions; `parent_key`/`parent_annotation_id` represent hierarchy. These are evidence-location aids only and remain reviewable visual inference.

## Evidence Quality & Capture Guidance (v1.12.0)

Titan performs deterministic capture-quality preflight before expensive visual inference. Checks include resolution, exposure, approximate sharpness, duplicate fingerprints and subject coverage where measurable. The server recomputes quality results and never trusts browser-supplied quality labels. Severe unusability stops provider inference and asks for a retake; lesser quality problems remain reviewable warnings. Quality signals only assess whether evidence is usable and never establish job condition, completion, safety or compliance.


## Asset Visual Intelligence (v1.12.0)

Titan AI Vision maintains evidence-backed **Asset Visual Passports** that preserve visual identity candidates, verified nameplate evidence, service imagery and observed condition history. A passport is not the authoritative asset record. Manufacturer/model/serial values produced by a model remain candidates until a user explicitly verifies a designated nameplate/identifier capture. Exact serial matches against another verified passport raise a possible-duplicate conflict and cannot silently merge records. Condition trends are visual observations only and remain reviewable.


## Asset Visual Intelligence (v1.12.0)

Titan AI Vision maintains evidence-backed **Asset Visual Passports** containing visual identity candidates, verified nameplate evidence, service imagery and observed condition history. A passport is not the authoritative asset record. Manufacturer/model/serial values produced by a model remain candidates until a user explicitly verifies a designated nameplate/identifier capture. Exact serial matches against another verified passport raise a possible-duplicate conflict and cannot silently merge records. Condition trends remain visual inference and are not authoritative asset condition state.

## Deep Vertical Inspection Packs (v1.12.0)

Titan AI Vision now includes first-class domain packs for Cleaning, Plumbing, Electrical, HVAC, Roofing & Guttering, Landscaping, Pest Control, Locksmith & Security, Pool & Spa, Solar, Appliance Repair, Property Maintenance, Arborist, Pressure Washing, and Facilities Maintenance.

Each pack defines:
- trade-specific capture requirements;
- preferred finding taxonomy;
- explicit prohibited conclusions;
- risk classifications used as review/routing hints;
- allowed workflow proposal destinations; and
- deterministic Completion Assurance thresholds.

The pack is a constraint layer, not an authority layer. For example, electrical images can identify visible damage but cannot certify electrical safety or isolation; plumbing images can show visible dripping or staining but cannot prove a concealed leak path; roofing images cannot certify structural safety or watertightness.

## Completion Assurance v2 (v1.12.0)

Titan AI Vision now produces one deterministic visual-readiness state:

- `READY_FOR_ASSURANCE`
- `REVIEW_REQUIRED`
- `MORE_EVIDENCE_REQUIRED`
- `BLOCKED_BY_OPEN_FINDING`
- `BLOCKED_BY_VARIATION`

The visual provider may supply `scope_evidence` and `variation_candidates`, but Titan owns the state machine. Scope evidence only reconciles visible evidence with approved scope explicitly supplied through verified Titan context. Variation candidates never become approved because Vision says so. High/critical unresolved findings and unapproved variations block Assurance handoff. `READY_FOR_ASSURANCE` means only that the visual package is eligible to be reviewed by Titan Assurance; it is not a job-completion decision.

## Quote & Variation Intelligence (v1.12.0)

Titan AI Vision can now prepare structured commercial candidates from visual evidence:

- scope candidates;
- service candidates;
- material candidates;
- possible variation proposals;
- missing measurements;
- evidence-image references.

The package always carries `requires_pricing=true`. Titan AI Vision does not price work, invent quantities, infer labour time, calculate tax/markup, approve variations, or approve quotes. Pricing and authoritative quote creation remain the responsibility of the relevant catalogue/pricing/CRM capability through Titan's governed command path.

## Safety & Compliance Vision (v1.12.0)

Titan AI Vision now applies a central safety policy in addition to vertical inspection-pack rules. Structured visual safety findings can be classified into general, electrical, structural, gas, chemical, fire, biological, working-at-height, or confined-space domains. Regulated domains and high/critical findings always require authorised human/domain review.

Titan AI Vision never certifies electrical safety, structural safety, gas safety, chemical safety, fire safety, or regulatory compliance from imagery. It also does not infer isolation state, energisation, gas tightness, hidden structural adequacy, chemical concentration, or legal compliance. Safety findings remain visible-evidence observations routed into governed review.
