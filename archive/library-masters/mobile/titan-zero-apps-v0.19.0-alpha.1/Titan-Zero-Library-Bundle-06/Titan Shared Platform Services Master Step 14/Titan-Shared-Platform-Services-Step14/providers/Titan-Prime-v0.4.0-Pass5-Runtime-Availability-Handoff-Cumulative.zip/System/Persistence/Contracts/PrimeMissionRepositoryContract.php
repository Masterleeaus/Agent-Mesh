<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Persistence\Contracts;

use App\Extensions\TitanPrime\System\Domain\Entities\PrimeMission;
use App\Extensions\TitanPrime\System\Domain\Enums\PrimeMissionStatus;
use App\Extensions\TitanPrime\System\Persistence\Data\PrimeMissionSnapshot;
use App\Extensions\TitanPrime\System\Persistence\Data\PrimeMissionWriteReceipt;

interface PrimeMissionRepositoryContract
{
    public function create(PrimeMission $mission, string $operationId): PrimeMissionWriteReceipt;

    public function find(int $tenantCompanyId, string $missionId): ?PrimeMissionSnapshot;

    public function transition(
        int $tenantCompanyId,
        string $missionId,
        PrimeMissionStatus $expectedStatus,
        PrimeMissionStatus $nextStatus,
        int $expectedVersion,
        string $operationId,
    ): PrimeMissionWriteReceipt;
}
