# Disaster Recovery

Restore extension-owned compilation state from platform backups, verify hashes and parent lineage, then reconcile desired state through fresh governed provisioning plans. Never restore downstream engine state by writing Nexus snapshots directly into foreign tables. Target manifest RPO is 60 minutes and RTO is 240 minutes.
