<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\DTOs;

use App\Extensions\TitanAutonomy\System\Enums\HandshakeDecision;

final readonly class HandshakeEvaluation
{
    public function __construct(
        public HandshakeDecision $platform,
        public HandshakeDecision $user,
        public HandshakeDecision $aiAssurance,
        public array $scope,
    ) {}

    public function trustedAutoActive(): bool
    {
        return $this->platform === HandshakeDecision::Approved
            && $this->user === HandshakeDecision::Approved
            && $this->aiAssurance === HandshakeDecision::Approved;
    }
}
