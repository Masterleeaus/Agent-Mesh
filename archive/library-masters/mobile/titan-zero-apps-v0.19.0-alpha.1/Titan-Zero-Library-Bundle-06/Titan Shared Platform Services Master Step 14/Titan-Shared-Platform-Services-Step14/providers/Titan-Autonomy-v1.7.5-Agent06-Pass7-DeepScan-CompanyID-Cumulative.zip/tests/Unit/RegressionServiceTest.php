<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Services\RegressionService;
use PHPUnit\Framework\TestCase;

final class RegressionServiceTest extends TestCase
{
    public function test_reversal_regresses_only_the_evaluated_capability_level(): void
    {
        $service = new RegressionService();
        self::assertSame(AutonomyLevel::SemiAuto, $service->target(AutonomyLevel::TrustedAuto, 'reversal'));
    }
}
