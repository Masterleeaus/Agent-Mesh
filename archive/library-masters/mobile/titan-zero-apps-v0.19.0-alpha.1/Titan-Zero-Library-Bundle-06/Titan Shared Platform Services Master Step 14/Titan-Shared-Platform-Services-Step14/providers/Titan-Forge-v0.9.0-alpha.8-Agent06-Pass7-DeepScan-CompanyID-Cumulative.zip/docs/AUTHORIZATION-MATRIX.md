# Titan Forge Authorization Matrix

| Operation | Tenant user | Tenant admin | Platform admin | Additional boundary |
|---|---:|---:|---:|---|
| View own-tenant Forge overview/history | Yes | Yes | Yes | Tenant scope required. |
| Register/queue bounded build | Authenticated/entitled | Yes | Yes | Positive actor + tenant context and idempotency required. |
| Inspect another tenant's build | No | No | Platform-admin surface only | Explicit administrative authority required. |
| Modify generated artifact outside Forge workspace | No | No | No through Forge | Forge sandbox forbids it. |
| Create release candidate | Via governed build path | Via governed build path | Via governed build path | Local validation + external release gates. |
| Approve production release | No | No | Not owned by Forge | Titan Governance authority. |
| Execute/install production release | No | No | Not owned by Forge | Titan Command Bus/installer authority. |

Forge routes require host authentication; tenant middleware resolves the company context server-side rather than trusting arbitrary request tenant IDs.
