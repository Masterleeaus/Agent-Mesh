<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\Chatbot;

use App\Extensions\Crm\System\Tenancy\{CrmCompanyContextResolver,CrmCompanyScope};

use App\Extensions\Crm\System\Governance\CrmCommandBusGateway;
use Illuminate\Database\ConnectionInterface;

final class CrmChatbotToolService
{

    public const TOOL_NAMES = [
        'crm_identify_customer','crm_update_my_details','crm_create_enquiry','crm_request_callback',
        'crm_get_my_proposals','crm_get_my_estimates','crm_get_my_invoices','crm_get_my_projects','crm_get_my_recent_activity',
    ];

    public function __construct(
        private ConnectionInterface $db,
        private CrmChatbotIdentityService $identities,
        private CrmChatbotToolPolicy $policy,
        private CrmCompanyContextResolver $companyContexts,
        private CrmCompanyScope $companyScope,
        private CrmCommandBusGateway $commands,
    ) {}

    public function enabledForChatbot(object $chatbot): bool { return $this->policy->enabled($chatbot); }

    public function definitionsForOpenAI(object $chatbot): array
    { return array_map(fn(array $d)=>['type'=>'function','function'=>['name'=>$d['name'],'description'=>$d['description'],'parameters'=>$d['schema']]],$this->definitions($chatbot)); }
    public function definitionsForAnthropic(object $chatbot): array
    { return array_map(fn(array $d)=>['name'=>$d['name'],'description'=>$d['description'],'input_schema'=>$d['schema']],$this->definitions($chatbot)); }
    public function definitionsForGemini(object $chatbot): array
    { return array_map(fn(array $d)=>['name'=>$d['name'],'description'=>$d['description'],'parameters'=>$d['schema']],$this->definitions($chatbot)); }

    public function execute(object $chatbot, object $conversation, string $tool, array $arguments): ?array
    {
        if (! str_starts_with($tool, 'crm_')) return null;
        $trusted = $this->trustedChatbotContext($chatbot);
        return $this->companyScope->runWith($trusted, fn() => $this->executeBound($chatbot,$conversation,$tool,$arguments));
    }

    private function executeBound(object $chatbot, object $conversation, string $tool, array $arguments): ?array
    {
        if (! $this->enabledForChatbot($chatbot)) return null;

        $identity = $this->identities->resolveForConversation($conversation);
        $this->policy->authorize($chatbot, $conversation, $tool, $identity);
        $userId = (int) $chatbot->getAttribute('user_id');
        $activeVerifiedSession = $this->policy->hasActiveVerifiedSession($chatbot, $conversation, $identity);

        $result = match ($tool) {
            'crm_identify_customer' => $this->identify($identity, $activeVerifiedSession),
            'crm_update_my_details' => $this->updateDetails($userId, $conversation, $identity, $arguments),
            'crm_create_enquiry' => $this->createEnquiry($userId, $conversation, $identity, $arguments),
            'crm_request_callback' => $this->requestCallback($userId, $conversation, $identity, $arguments),
            'crm_get_my_proposals' => $this->sales($userId, 'proposals', $identity),
            'crm_get_my_estimates' => $this->sales($userId, 'estimates', $identity),
            'crm_get_my_invoices' => $this->sales($userId, 'invoices', $identity),
            'crm_get_my_projects' => $this->projects($userId, $identity),
            'crm_get_my_recent_activity' => $this->recentActivity($userId, $identity),
            default => null,
        };

        if ($result === null) return null;
        return ['data'=>$result,'ai_content'=>json_encode($result,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)];
    }

    private function trustedChatbotContext(object $chatbot): \App\Extensions\Crm\System\Tenancy\CrmCompanyContext
    {
        $chatbotId=(int)$chatbot->getKey();
        $ownerUserId=(int)$chatbot->getAttribute('user_id');
        $uuid=(string)($chatbot->getAttribute('uuid')??'');
        if($chatbotId<=0||$ownerUserId<=0||!class_exists(\App\Extensions\Chatbot\System\Models\Chatbot::class)){
            throw new \RuntimeException('CRM public Chatbot context cannot be resolved from an authoritative Chatbot record.');
        }
        $authoritative=\App\Extensions\Chatbot\System\Models\Chatbot::query()->whereKey($chatbotId)->first();
        if(!$authoritative || (int)$authoritative->getAttribute('user_id')!==$ownerUserId || ($uuid!==''&&(string)$authoritative->getAttribute('uuid')!==$uuid)){
            throw new \RuntimeException('CRM public Chatbot context failed authoritative Chatbot identity verification.');
        }
        $companyId=$this->companyContexts->companyIdForActorId($ownerUserId);
        return $this->companyContexts->fromTrustedPlatform(
            companyId:$companyId, actorUserId:$ownerUserId, actorType:'user',
            permissions:[], sourceSurface:'chatbot', membershipVerified:true,
        );
    }

    private function definitions(object $chatbot): array
    {
        if (! $this->enabledForChatbot($chatbot)) return [];
        $all = [
            ['name'=>'crm_identify_customer','description'=>'Check whether the current chatbot visitor is linked to CRM. Never use this to search for another customer.','schema'=>$this->schema([])],
            ['name'=>'crm_update_my_details','description'=>'Request a governed update to the verified current customer own CRM contact details.','schema'=>$this->schema(['name'=>'string','email'=>'string','phone'=>'string'])],
            ['name'=>'crm_create_enquiry','description'=>'Request creation of a governed CRM enquiry/lead for the current visitor.','schema'=>$this->schema(['subject'=>'string','message'=>'string'],['message'])],
            ['name'=>'crm_request_callback','description'=>'Request a governed callback activity for the current CRM customer.','schema'=>$this->schema(['reason'=>'string','preferred_time'=>'string'])],
            ['name'=>'crm_get_my_proposals','description'=>'List proposals belonging to the verified current CRM customer only.','schema'=>$this->schema([])],
            ['name'=>'crm_get_my_estimates','description'=>'List estimates belonging to the verified current CRM customer only.','schema'=>$this->schema([])],
            ['name'=>'crm_get_my_invoices','description'=>'List invoices belonging to the verified current CRM customer only.','schema'=>$this->schema([])],
            ['name'=>'crm_get_my_projects','description'=>'List CRM projects belonging to the verified current customer company.','schema'=>$this->schema([])],
            ['name'=>'crm_get_my_recent_activity','description'=>'Show recent CRM relationship activity for the verified current customer only.','schema'=>$this->schema([])],
        ];
        $allowed = $this->policy->allowedTools($chatbot);
        return array_values(array_filter($all, fn($d)=>in_array($d['name'],$allowed,true)));
    }

    private function schema(array $properties,array $required=[]): array
    {
        $p=[];
        foreach($properties as $name=>$type) {
            $p[$name] = match ($type) {
                'integer' => ['type'=>'integer'],
                'number' => ['type'=>'number'],
                default => ['type'=>$type],
            };
        }
        return ['type'=>'object','properties'=>$p,'required'=>$required,'additionalProperties'=>false];
    }

    private function identify(?array $identity,bool $activeVerifiedSession): array
    { return ['linked'=>(bool)($identity['crm_contact_public_id']??false),'identity_state'=>$identity['identity_state']??'anonymous','verified'=>$activeVerifiedSession]; }

    private function updateDetails(int $userId,object $conversation,array $identity,array $args): array
    {
        $contact=$this->db->table(config('crm.tables.contacts'))->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$identity['crm_contact_public_id'])->whereNull('deleted_at')->first();
        if(!$contact)return ['ok'=>false,'reason'=>'contact_not_found'];
        $name=trim((string)($args['name']??''));$first=null;$last=null;if($name!==''){[$first,$last]=array_pad(preg_split('/\s+/', $name,2)?:[],2,null);}
        $payload=array_filter(['public_id'=>(string)$contact->public_id,'first_name'=>$first,'last_name'=>$last,'email'=>$args['email']??null,'phone'=>$args['phone']??null],fn($v)=>$v!==null);
        $command=$this->command('crm.contact.update',$payload,$conversation,'crm_update_my_details');
        if($this->executed($command) && class_exists(\App\Extensions\Chatbot\System\Models\ChatbotCustomer::class)){
            $id=(int)$conversation->getAttribute('chatbot_customer_id');$row=\App\Extensions\Chatbot\System\Models\ChatbotCustomer::query()->whereKey($id)->where('user_id',$userId)->first();
            if($row)$row->update(array_filter(['name'=>$name?:null,'email'=>$args['email']??null,'phone'=>$args['phone']??null],fn($v)=>$v!==null));
        }
        return ['ok'=>$this->executed($command),'status'=>$command['status']??'awaiting_command_bus','command'=>$command,'contact'=>$this->executed($command)?($command['result']??null):null];
    }

    private function createEnquiry(int $userId,object $conversation,?array $identity,array $args): array
    {
        $contact=$identity? $this->contact($userId,$identity):null;
        $name=$contact?trim(($contact->first_name??'').' '.($contact->last_name??'')):'Chatbot enquiry';
        $command=$this->command('crm.lead.create',[
            'name'=>$name?:'Chatbot enquiry','email'=>$contact->email??$identity['normalized_email']??null,
            'phone'=>$contact->phone??$identity['normalized_phone']??null,'status'=>'new','source'=>'chatbot',
            'notes'=>trim((string)($args['subject']??'')."\n".(string)($args['message']??'')),
        ],$conversation,'crm_create_enquiry');
        return ['ok'=>$this->executed($command),'status'=>$command['status']??'awaiting_command_bus','command'=>$command,'lead_public_id'=>$command['result']['public_id']??null];
    }

    private function requestCallback(int $userId,object $conversation,array $identity,array $args): array
    {
        $command=$this->command('crm.activity.create',[
            'subject_type'=>'contact','subject_public_id'=>(string)$identity['crm_contact_public_id'],'type'=>'callback_requested',
            'title'=>'Callback requested','body'=>(string)($args['reason']??''),'direction'=>'inbound',
            'scheduled_at'=>$args['preferred_time']??null,'metadata'=>['source'=>'chatbot'],
        ],$conversation,'crm_request_callback');
        return ['ok'=>$this->executed($command),'status'=>$command['status']??'awaiting_command_bus','command'=>$command,'activity_public_id'=>$command['result']['public_id']??null,'preferred_time'=>$args['preferred_time']??null];
    }

    private function sales(int $userId,string $type,array $identity): array
    {
        $q=$this->db->table('crm_'.$type)->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at');
        $this->scopeToIdentity($q,$identity);
        return $q->orderByDesc('id')->limit(25)->get(['public_id','number','title','status','currency','total_minor','balance_minor','due_at','created_at'])->map(fn($r)=>(array)$r)->all();
    }

    private function projects(int $userId,array $identity): array
    { if(empty($identity['crm_company_public_id']))return [];return $this->db->table('crm_projects')->where('company_id', CrmCompanyScope::companyId($userId))->where('company_public_id',$identity['crm_company_public_id'])->whereNull('deleted_at')->orderByDesc('id')->limit(25)->get(['public_id','name','status','priority','progress_percent','due_on'])->map(fn($r)=>(array)$r)->all(); }

    private function recentActivity(int $userId,array $identity): array
    { return $this->db->table(config('crm.tables.activities'))->where('company_id', CrmCompanyScope::companyId($userId))->where('subject_type','contact')->where('subject_public_id',$identity['crm_contact_public_id'])->orderByDesc('id')->limit(15)->get(['public_id','type','title','direction','occurred_at','created_at'])->map(fn($r)=>(array)$r)->all(); }

    private function contact(int $userId,array $identity): ?object
    { if(empty($identity['crm_contact_public_id']))return null;return $this->db->table(config('crm.tables.contacts'))->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$identity['crm_contact_public_id'])->whereNull('deleted_at')->first(); }

    private function scopeToIdentity($q,array $identity): void
    {
        $contact=$identity['crm_contact_public_id']??null;$company=$identity['crm_company_public_id']??null;
        $q->where(function($w)use($contact,$company):void{
            if($contact)$w->orWhere('contact_public_id',$contact);
            if($company)$w->orWhere('company_public_id',$company);
            if(!$contact && !$company)$w->whereRaw('1 = 0');
        });
    }

    /** @return array<string,mixed> */
    private function command(string $capability,array $payload,object $conversation,string $tool): array
    {
        $payload['idempotency_key']=$payload['idempotency_key']??$this->commandKey($conversation,$tool,$payload);
        return $this->commands->request($capability,$payload,'chatbot');
    }

    private function commandKey(object $conversation,string $tool,array $payload): string
    {
        $conversationId=(string)($conversation->getKey()??$conversation->getAttribute('uuid')??$conversation->getAttribute('session_id')??'unknown');
        $normalise=function(mixed $value) use (&$normalise):mixed{
            if(!is_array($value))return $value;
            if(array_is_list($value))return array_map($normalise,$value);
            ksort($value);foreach($value as $key=>$item)$value[$key]=$normalise($item);return $value;
        };
        return 'chatbot:'.substr(hash('sha256',$conversationId.'|'.$tool.'|'.json_encode($normalise($payload),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)),0,64);
    }

    private function executed(array $command): bool
    { return ($command['executed']??false)===true && ($command['authoritative']??false)===true && (string)($command['receipt']['receipt_id']??'')!==''; }

    private function required(array $arguments,string $key): string
    { $value=trim((string)($arguments[$key]??''));if($value==='')throw new \InvalidArgumentException("CRM chatbot argument [{$key}] is required.");return $value; }

    private function nullableString(mixed $value): ?string
    { $value=trim((string)($value??''));return $value===''?null:$value; }
}
