# Deep Scan — Titan Premises & Assets Team + Titan Locker

Scanned donor modules: Asset, FSMEquipment, FSMEquipmentWarranty, FSMVehicle, FSMRepair, FSMRepairTemplate, ManagedPremises, FieldItems, FSMStock, SupplyChain and WMSInventoryCore.

Key findings used in the conversion:
- donor Asset routes are duplicated and contain a PHP syntax failure;
- donor package contains case-colliding Asset factory paths;
- multiple FSM modules independently create overlapping repair/warranty tables;
- donor code relies on legacy `Modules\\*`, `module_path()`, FSMCore/SystemCore assumptions and generic host permission mutations;
- FieldItems/FSMStock/SupplyChain/WMS overlap Titan Locker inventory authority and were not imported;
- ManagedPremises remains a separate domain; only a neutral premises-link contract was added;
- existing live asset data uses legacy `tenant_company_id` in `crm_locker_*` tables and is preserved; Titan Assets adds/backfills canonical `company_id` without destructive renaming;
- live menu rows `crm_tools`, `crm_equipment`, `crm_fleet`, `crm_maintenance`, `crm_customer_assets` are adopted into the new Assets parent rather than duplicated.


## Live database reconciliation
The supplied production dump shows CRM `1.3.0-alpha.17`, an existing `menus` table with 472 rows, and the legacy asset menu keys beneath `ext_crm_gear`. It also records all three historical Titan Locker migration basenames. Titan Assets uses three new migration basenames, adopts the existing asset menu rows by stable key, and never republishes the recorded Locker migration names.
