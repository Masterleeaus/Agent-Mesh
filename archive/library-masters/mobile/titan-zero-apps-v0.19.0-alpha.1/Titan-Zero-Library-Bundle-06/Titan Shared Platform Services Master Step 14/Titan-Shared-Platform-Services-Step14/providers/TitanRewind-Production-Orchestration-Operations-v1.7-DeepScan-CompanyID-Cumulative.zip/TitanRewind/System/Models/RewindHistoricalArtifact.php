<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Models;
use Illuminate\Database\Eloquent\Model;
final class RewindHistoricalArtifact extends Model
{
 protected $table='titan_rewind_historical_artifacts';
 protected $fillable=['artifact_uuid','tenant_company_id','trace_id','kind','version','source_key','authenticity_state','content_hash','artifact_payload','metadata','captured_at','last_verified_at'];
 protected $casts=['tenant_company_id'=>'integer','artifact_payload'=>'encrypted:array','metadata'=>'array','captured_at'=>'datetime','last_verified_at'=>'datetime'];
}
