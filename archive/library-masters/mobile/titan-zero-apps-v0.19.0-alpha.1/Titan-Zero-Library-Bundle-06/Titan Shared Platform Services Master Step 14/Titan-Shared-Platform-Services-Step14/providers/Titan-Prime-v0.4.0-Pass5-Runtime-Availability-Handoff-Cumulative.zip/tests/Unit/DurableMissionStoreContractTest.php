<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanPrime\System\Domain\Entities\PrimeMission;
use App\Extensions\TitanPrime\System\Domain\Entities\PrimeObjective;
use App\Extensions\TitanPrime\System\Domain\Enums\PrimeMissionStatus;
use App\Extensions\TitanPrime\System\Domain\ValueObjects\PrimeBudget;
use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Persistence\Data\PrimeMissionSnapshot;
use App\Extensions\TitanPrime\System\Persistence\Data\PrimeMissionWriteReceipt;
use App\Extensions\TitanPrime\System\Persistence\Support\MissionOperationFingerprint;
use PHPUnit\Framework\TestCase;

final class DurableMissionStoreContractTest extends TestCase
{
    public function test_reconstituted_mission_preserves_persisted_state(): void
    {
        $mission = $this->mission(PrimeMissionStatus::Planned);
        $snapshot = new PrimeMissionSnapshot($mission, 4);

        self::assertSame(4, $snapshot->version);
        self::assertSame(PrimeMissionStatus::Planned, $snapshot->mission->status());
        self::assertSame(7, $snapshot->mission->trace()->tenantCompanyId);
        self::assertSame('trace-1', $snapshot->mission->trace()->resolvedRootCausationId());
    }

    public function test_operation_fingerprints_are_deterministic_and_payload_specific(): void
    {
        $mission = $this->mission(PrimeMissionStatus::Draft);

        $createA = MissionOperationFingerprint::create($mission);
        $createB = MissionOperationFingerprint::create($mission);
        $transition = MissionOperationFingerprint::transition(
            'mission-001',
            PrimeMissionStatus::Draft,
            PrimeMissionStatus::Assessing,
            1,
        );

        self::assertSame($createA, $createB);
        self::assertSame(64, strlen($createA));
        self::assertNotSame($createA, $transition);
    }

    public function test_replay_receipt_is_explicit_without_mutating_original(): void
    {
        $receipt = new PrimeMissionWriteReceipt(
            tenantCompanyId: 7,
            operationId: 'op-1',
            missionId: 'mission-001',
            operationType: 'create',
            version: 1,
            status: 'draft',
            payloadHash: str_repeat('a', 64),
        );

        self::assertFalse($receipt->replayed);
        self::assertTrue($receipt->asReplay()->replayed);
        self::assertFalse($receipt->replayed);
    }

    private function mission(PrimeMissionStatus $status): PrimeMission
    {
        return PrimeMission::reconstitute(
            missionId: 'mission-001',
            trace: new TraceContext(7, 'trace-1', 'corr-1', null, 'trace-1'),
            objective: new PrimeObjective('growth', 'Increase pipeline', 'More qualified opportunities'),
            budget: new PrimeBudget(maxRiskScore: 0.4),
            initiatedByType: 'user',
            initiatedById: '11',
            status: $status,
        );
    }
}
