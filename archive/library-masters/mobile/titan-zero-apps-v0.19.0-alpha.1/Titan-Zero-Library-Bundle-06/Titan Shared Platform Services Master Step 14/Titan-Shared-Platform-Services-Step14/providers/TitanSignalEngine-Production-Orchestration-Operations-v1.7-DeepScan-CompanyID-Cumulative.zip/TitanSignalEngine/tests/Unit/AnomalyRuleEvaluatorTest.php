<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanSignalEngine\System\Data\AnomalyThresholds;
use App\Extensions\TitanSignalEngine\System\Services\AnomalyRuleEvaluator;
use PHPUnit\Framework\TestCase;

final class AnomalyRuleEvaluatorTest extends TestCase
{
    public function test_volume_collapse_requires_mature_baseline(): void
    {
        $rules = new AnomalyRuleEvaluator(new AnomalyThresholds());
        self::assertSame([], $rules->evaluate(['baseline_ready' => false, 'baseline_events_per_5m' => 100, 'events_last_5m' => 0]));
        $findings = $rules->evaluate(['baseline_ready' => true, 'baseline_events_per_5m' => 100, 'events_last_5m' => 10]);
        self::assertSame('event_volume_collapse', $findings[0]->type);
    }

    public function test_sequence_and_trace_integrity_remain_distinct(): void
    {
        $findings = (new AnomalyRuleEvaluator(new AnomalyThresholds()))->evaluate([
            'trace_id' => 'trace-1',
            'sequence_violation_count' => 1,
            'unresolved_causation_count' => 1,
        ]);
        self::assertSame(['sequence_violation', 'trace_integrity'], array_map(static fn ($f): string => $f->type, $findings));
    }
}
