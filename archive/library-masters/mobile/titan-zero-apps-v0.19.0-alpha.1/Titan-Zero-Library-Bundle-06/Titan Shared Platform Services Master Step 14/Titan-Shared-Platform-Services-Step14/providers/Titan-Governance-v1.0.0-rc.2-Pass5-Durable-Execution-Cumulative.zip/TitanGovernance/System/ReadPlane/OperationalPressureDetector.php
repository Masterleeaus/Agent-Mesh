<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ReadPlane;

final class OperationalPressureDetector
{
    /** @return array<string,mixed> */
    public function detect(array $observations): array
    {
        $items = [];
        foreach ($observations as $observation) {
            if (!is_array($observation)) continue;
            $items[] = $this->score($observation);
        }
        usort($items, static fn (array $a, array $b): int => ($b['pressure_score'] <=> $a['pressure_score']) ?: strcmp($a['source_component'], $b['source_component']));
        return [
            'schema_version' => '1.0',
            'items' => $items,
            'bottlenecks' => array_values(array_filter($items, static fn (array $row): bool => in_array($row['pressure_band'], ['HIGH','CRITICAL'], true))),
            'max_pressure_score' => $items === [] ? 0 : max(array_column($items, 'pressure_score')),
        ];
    }

    /** @return array<string,mixed> */
    private function score(array $observation): array
    {
        $queue = max(0, (int)($observation['queue_depth'] ?? 0));
        $age = max(0, (int)($observation['oldest_age_seconds'] ?? 0));
        $failure = max(0.0, min(100.0, (float)($observation['failure_rate_pct'] ?? 0)));
        $blocked = max(0, (int)($observation['blocked_count'] ?? 0));
        $saturation = max(0.0, min(100.0, (float)($observation['saturation_pct'] ?? 0)));
        $score = 0;
        $reasons = [];

        if ($queue >= 25) { $score += 25; $reasons[] = 'QUEUE_DEPTH_HIGH'; }
        elseif ($queue >= 10) { $score += 15; $reasons[] = 'QUEUE_DEPTH_ELEVATED'; }
        elseif ($queue >= 5) { $score += 5; $reasons[] = 'QUEUE_DEPTH_RISING'; }

        if ($age >= 900) { $score += 20; $reasons[] = 'OLDEST_ITEM_AGE_HIGH'; }
        elseif ($age >= 300) { $score += 10; $reasons[] = 'OLDEST_ITEM_AGE_ELEVATED'; }
        elseif ($age >= 120) { $score += 5; $reasons[] = 'OLDEST_ITEM_AGE_RISING'; }

        if ($failure >= 10) { $score += 20; $reasons[] = 'FAILURE_RATE_HIGH'; }
        elseif ($failure >= 5) { $score += 10; $reasons[] = 'FAILURE_RATE_ELEVATED'; }
        elseif ($failure >= 1) { $score += 5; $reasons[] = 'FAILURE_RATE_NONZERO'; }

        if ($blocked >= 5) { $score += 15; $reasons[] = 'BLOCKED_WORK_HIGH'; }
        elseif ($blocked >= 1) { $score += 5; $reasons[] = 'BLOCKED_WORK_PRESENT'; }

        if ($saturation >= 90) { $score += 20; $reasons[] = 'SATURATION_HIGH'; }
        elseif ($saturation >= 75) { $score += 10; $reasons[] = 'SATURATION_ELEVATED'; }
        elseif ($saturation >= 50) { $score += 5; $reasons[] = 'SATURATION_RISING'; }

        $score = min(100, $score);
        $band = match (true) {
            $score >= 70 => 'CRITICAL',
            $score >= 40 => 'HIGH',
            $score >= 20 => 'ELEVATED',
            default => 'NORMAL',
        };

        return [
            'source_component' => trim((string)($observation['source_component'] ?? 'unknown')) ?: 'unknown',
            'pressure_score' => $score,
            'pressure_band' => $band,
            'reason_codes' => $reasons,
            'queue_depth' => $queue,
            'oldest_age_seconds' => $age,
            'failure_rate_pct' => $failure,
            'blocked_count' => $blocked,
            'saturation_pct' => $saturation,
            'observed_at' => $observation['observed_at'] ?? null,
        ];
    }
}
