<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Contracts\TaskRepositoryContract; use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class TaskController {
 public function __construct(private TaskRepositoryContract $tasks, private \App\Extensions\Crm\System\Governance\CrmHumanMutationGateway $mutations){}
 public function index(Request $r){$records=$this->tasks->search((int)$r->user()->id,$r->only(['status','limit']));return $r->expectsJson()?response()->json(['data'=>$records]):view('crm::tasks.index',['tasks'=>$records]);}
 public function store(Request $r){$d=$r->validate(['name'=>'required|string|max:255','status'=>'nullable|string|max:40','priority'=>'nullable|in:low,normal,high,urgent','description'=>'nullable|string|max:10000','project_public_id'=>'nullable|string|size:26','subject_type'=>'nullable|string|max:60','subject_public_id'=>'nullable|string|size:26','due_at'=>'nullable|date','assigned_user_id'=>'nullable|integer','meta'=>'nullable|array']);$record=$this->mutations->execute($r,'crm.task.create',$d);return $r->expectsJson()?response()->json($record,201):back()->with('status','Task created.');}
 public function status(Request $r,string $task){$d=$r->validate(['status'=>'required|in:open,in_progress,blocked,done,cancelled']);$record=$this->mutations->execute($r,'crm.task.status.update',['public_id'=>$task,'status'=>$d['status']]);return $r->expectsJson()?response()->json($record):back()->with('status','Task status updated.');}
}
