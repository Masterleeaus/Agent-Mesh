# Template Audit — v10.3.0

Preserved templates: **38**. Active Field/Home Services profile: **16**.

| Template | Status | Active | Entry wizard | Capabilities |
|---|---|---:|---|---|
| `abandoned-checkout-recovery` | draft | no/dormant | `abandoned_checkout_recovery_v1` | `commerce.checkout.recover` |
| `booking-intake` | ready | no/dormant | `booking_intake_v1` | `hospitality.bookings.create` |
| `client-intake-consent` | ready | no/dormant | `client_intake_consent_v1` | `care.clients.intake` |
| `clinical-service-incident-escalation` | draft | no/dormant | `clinical_service_incident_escalation_v1` | `care.incidents.escalate` |
| `customer-onboarding` | ready | yes | `new_customer_v1` | `crm.customer.create` |
| `customer-order-capture` | ready | no/dormant | `customer_order_capture_v1` | `commerce.orders.create` |
| `event-function-setup` | ready | no/dormant | `event_function_setup_v1` | `hospitality.events.prepare` |
| `field-job-handover` | draft | yes | `field_job_handover_v1` | `jobs.handover.create`, `evidence.attach` |
| `guest-issue-resolution` | ready | no/dormant | `guest_issue_resolution_v1` | `hospitality.guest_issues.resolve` |
| `incident-response` | ready | yes | `incident_response_v1` | `crm.form.submit` |
| `inspection-corrective-action` | ready | yes | `inspection_corrective_action_v1` | `crm.form.submit` |
| `inventory-adjustment` | ready | no/dormant | `inventory_adjustment_v1` | `inventory.adjustments.record` |
| `invoice-creation` | ready | yes | `create_invoice_v1` | `crm.invoice.create` |
| `job-completion` | ready | yes | `complete_job_v1` | `crm.work_order.complete` |
| `job-creation` | ready | yes | `create_job_v1` | `crm.work_order.create` |
| `job-variation-approval` | ready | yes | `job_variation_approval_v1` | `crm.work_order.update` |
| `maintenance-request` | ready | no/dormant | `maintenance_request_v1` | `property.maintenance.request` |
| `materials-request` | ready | yes | `materials_request_v1` | `crm.work_order.material.add` |
| `order-fulfilment` | ready | no/dormant | `order_fulfilment_v1` | `commerce.orders.fulfil` |
| `order-issue-resolution` | ready | no/dormant | `order_issue_resolution_v1` | `commerce.orders.resolve_issue` |
| `payment-reconciliation` | draft | yes | `payment_reconciliation_v1` | `finance.payment.reconcile` |
| `practical-completion-defects` | ready | yes | `practical_completion_defects_v1` | `crm.work_order.update` |
| `product-catalogue-item` | ready | no/dormant | `product_catalogue_item_v1` | `commerce.products.upsert` |
| `property-onboarding` | ready | no/dormant | `property_onboarding_v1` | `property.assets.onboard` |
| `property-turnover-handover` | ready | no/dormant | `property_turnover_handover_v1` | `property.turnovers.complete` |
| `quote-builder` | ready | yes | `create_quote_v1` | `crm.quote.create` |
| `recurring-service-agreement` | draft | yes | `recurring_service_agreement_v1` | `field_services.recurring_agreements.create` |
| `refund-approval` | ready | no/dormant | `refund_approval_v1` | `commerce.refunds.approve` |
| `return-request` | ready | no/dormant | `return_request_v1` | `commerce.returns.request` |
| `service-booking` | ready | yes | `service_booking_v1` | `crm.appointment.create` |
| `service-plan-review` | draft | no/dormant | `service_plan_review_v1` | `care.service_plans.review` |
| `site-variation` | ready | yes | `site_variation_v1` | `crm.work_order.update` |
| `staff-onboarding` | draft | yes | `staff_onboarding_v1` | `workforce.staff.onboard`, `training.assign` |
| `stocktake-variance` | ready | no/dormant | `stocktake_variance_v1` | `inventory.stocktakes.complete` |
| `store-stock-transfer` | ready | no/dormant | `store_stock_transfer_v1` | `inventory.transfers.create` |
| `supplier-receiving-discrepancy` | ready | no/dormant | `supplier_receiving_discrepancy_v1` | `inventory.receipts.record` |
| `supplier-replenishment` | draft | no/dormant | `supplier_replenishment_v1` | `procurement.replenishment.request` |
| `wholesale-order` | draft | no/dormant | `wholesale_order_v1` | `wholesale.orders.create` |
