# Titan CRM 1.3.0-alpha.22 — CQRS Read Store & Mobile Delta Sync Report

## Objective

Protect transactional CRM workloads from growing AI/dashboard/mobile read pressure without changing CRM's role as authoritative Business OS state. Alpha.22 adds a rebuildable projection boundary and a signed mobile change-feed contract while preserving installer portability and existing domain behavior.

## Architecture

### Authoritative write side

Existing CRM repositories and domain services remain authoritative. Governed mutations still execute through the CRM capability executor/Command Bus boundary and create transactional CRM Signal outbox records.

### Read side

`CrmReadStorePort` is the stable read-store contract. The default `CrmSqlProjectionReadStore` writes only disposable projection tables:

- `crm_read_projection_state`
- `crm_read_projection_records`

Each state record includes projection name/version, record count, rebuild/freshness state, source watermark and the Signal ID projected through. Each projection record contains only the projection's explicit payload, source version/timestamp and a payload hash.

The design does not bind Titan CRM to Elasticsearch. A later read-replica, OpenSearch or vector adapter can implement the same port.

## Projection catalogue

Alpha.22 provides:

- `customer_summary`
- `customer_timeline`
- `sales_pipeline`
- `job_details`
- `schedule_context`
- `invoice_context`
- `receivables_context`
- `owner_dashboard`
- `tenant_summary`

Named AI projection reads use the CQRS store. Common legacy AI resource names map to these projections. Resources not yet projected may use the explicitly configured compatibility fallback until later passes migrate them.

## Projection lifecycle

1. Initial/bootstrap rebuild reads authoritative state.
2. `crm:projections:rebuild` can rebuild one or all projections for a tenant.
3. `crm.query.projection.status` reports projection version, freshness and watermarks.
4. Committed CRM Signal outbox events pass through `CrmProjectionEventProjector` during post-commit dispatch.
5. The projector upserts/deletes affected projection resources and advances projection state.
6. Projection errors are isolated: CRM truth and external Signal delivery continue because projections are disposable and can be rebuilt.

## Titan Go delta synchronization

`crm_mobile_change_feed` records committed field changes using the existing Signal/outbox event identity. Its auto-incrementing row ID is the monotonic `sync_sequence`.

`CrmMobileSyncTokenService` issues an HMAC-signed opaque token containing:

- `tenant_company_id`
- `actor_user_id`
- sequence
- issued time

A token cannot be moved between tenants/workers or modified without invalidating its signature. Token expiry forces a clean bootstrap.

Titan Go behavior is:

**bootstrap → authoritative assigned work-order snapshot + `sync_token` → delta pulls → tombstones/upserts → next `sync_token`.**

Older timestamp cursors remain accepted for transition and receive a signed delta token in the response.

## Performance/index work

Alpha.22 adds indexes for the projection stores/change feed plus focused source-query indexes on CRM activity timelines, assigned/scheduled work orders and invoice ageing/payment-state paths. Tenant partitioning and route auto-discovery are intentionally deferred until profiling proves they are justified.

## Safety decisions

- Read projections never become authoritative write targets.
- Projection failure never rolls back business state.
- Mobile sync tokens are tenant/actor bound.
- Tombstones prevent deleted/removed state from silently persisting on offline devices.
- Read-store adapters remain replaceable.
- Existing field, finance, Locker and bookkeeping domains are not extracted in this pass.

## Acceptance

Alpha.22 is acceptable when named AI projections and the canonical owner-dashboard capability operate through `CrmReadStorePort`, committed CRM events can refresh projections, projections can be rebuilt deterministically, Titan Go can transition from snapshot to signed delta sync, and all alpha.1-alpha.21 compatibility gates remain green.
