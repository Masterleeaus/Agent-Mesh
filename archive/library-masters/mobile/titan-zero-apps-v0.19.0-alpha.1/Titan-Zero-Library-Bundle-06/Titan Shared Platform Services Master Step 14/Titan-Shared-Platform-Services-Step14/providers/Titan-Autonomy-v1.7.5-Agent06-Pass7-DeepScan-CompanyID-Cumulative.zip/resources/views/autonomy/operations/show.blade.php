@extends($layout)
@section('title', 'Autonomy Execution')
@section('content')
@php($r=$detail['receipt']) @php($ops=$detail['operations'])
<div class="ta-card"><a href="{{ route('titan-autonomy.operations.index') }}">← Autonomy Operations</a><h1>{{ $r['capability'] }}</h1><p class="ta-muted">{{ $r['workflow_key'] ?: 'default' }} · {{ $r['correlation_id'] }}</p>
@if(session('titan_autonomy_status'))<div class="ta-ok">{{ session('titan_autonomy_status') }}</div>@endif
@if(session('titan_autonomy_error'))<div class="ta-error">{{ session('titan_autonomy_error') }}</div>@endif
</div>
<div class="ta-grid">
<div class="ta-card"><strong>{{ str_replace('_',' ',strtoupper($ops['status'])) }}</strong><div class="ta-muted">Operations status</div></div>
<div class="ta-card"><strong>{{ strtoupper($r['risk']) }}</strong><div class="ta-muted">Risk</div></div>
<div class="ta-card"><strong>{{ $r['autonomy_level'] }}</strong><div class="ta-muted">Authority at execution</div></div>
<div class="ta-card"><strong>{{ $r['command_status'] }}</strong><div class="ta-muted">Command status</div></div>
<div class="ta-card"><strong>{{ $r['final_label'] ?? 'Pending' }}</strong><div class="ta-muted">Learning outcome</div></div>
<div class="ta-card"><strong>{{ $r['matures_at'] ?? 'Human only' }}</strong><div class="ta-muted">Verification maturity</div></div>
</div>
<div class="ta-card"><h2>Why it is here</h2><p>{{ implode(', ', $ops['reason_codes'] ?? []) }}</p>
@if($ops['can_recheck'])<form method="post" action="{{ route('titan-autonomy.operations.recheck',['correlationId'=>$r['correlation_id']]) }}">@csrf<button class="ta-btn">Recheck now</button><small class="ta-muted"> Runs the normal persisted postcondition + tenant Assurance reconciliation. It cannot force a positive result.</small></form>@endif
</div>
<div class="ta-card"><h2>Manager review</h2><p class="ta-muted">Operational acknowledgement is metadata only. It does not alter trust, streaks, evidence, scope, gates or autonomy level.</p><form method="post" action="{{ route('titan-autonomy.operations.review',['correlationId'=>$r['correlation_id']]) }}">@csrf<select class="ta-input" name="review_status"><option value="acknowledged">Acknowledged</option><option value="needs_follow_up">Needs follow-up</option><option value="reviewed_no_change">Reviewed — no trust change</option></select><br><br><textarea class="ta-input" name="note" maxlength="2000" placeholder="Operational note"></textarea><br><br><button class="ta-btn secondary">Record review</button></form></div>
<div class="ta-card"><h2>Report a negative outcome</h2><p class="ta-muted">Positive outcomes cannot be submitted here. Only server reconciliation can create qualifying positive trust evidence.</p><form method="post" action="{{ route('titan-autonomy.executions.feedback',['correlationId'=>$r['correlation_id']]) }}">@csrf<select class="ta-input" name="classification"><option value="materially_corrected">Materially corrected</option><option value="reversed">Reversed</option><option value="failed">Failed</option><option value="rejected">Rejected</option><option value="exception">Exception</option></select><br><br><textarea class="ta-input" name="details[note]" placeholder="What happened?"></textarea><br><br><button class="ta-btn danger">Record negative outcome</button></form></div>
<div class="ta-card"><h2>Verification evidence</h2><h3>At execution</h3><pre>{{ json_encode(['postcondition'=>$r['postcondition_at_execution']??[],'assurance'=>$r['assurance_at_execution']??[]],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre><h3>At reconciliation</h3><pre>{{ json_encode(['postcondition'=>$r['postcondition_at_reconciliation']??[],'assurance'=>$r['assurance_at_reconciliation']??[],'reason_codes'=>$r['final_reason_codes']??[]],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div>
<div class="ta-card"><h2>Execution record</h2><pre>{{ json_encode(['command_payload'=>$r['command_payload']??[],'command_result'=>$r['command_result']??[],'context'=>$r['context']??[]],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div>
<div class="ta-card"><h2>Operational reviews</h2><table class="ta-table"><thead><tr><th>When</th><th>User</th><th>Status</th><th>Note</th></tr></thead><tbody>@forelse($detail['reviews'] as $review)<tr><td>{{ $review['created_at']??'' }}</td><td>{{ $review['user_id']??'' }}</td><td>{{ $review['review_status']??'' }}</td><td>{{ $review['note']??'' }}</td></tr>@empty<tr><td colspan="4">No reviews.</td></tr>@endforelse</tbody></table></div>
<div class="ta-card"><h2>Negative feedback</h2><table class="ta-table"><thead><tr><th>When</th><th>Classification</th><th>Material</th></tr></thead><tbody>@forelse($detail['feedback'] as $feedback)<tr><td>{{ $feedback['created_at']??'' }}</td><td>{{ $feedback['classification']??'' }}</td><td>{{ !empty($feedback['material_edit'])?'Yes':'No' }}</td></tr>@empty<tr><td colspan="3">No feedback.</td></tr>@endforelse</tbody></table></div>
<div class="ta-card"><h2>Capability trust state</h2><pre>{{ json_encode($detail['state']??[],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div>
<div class="ta-card"><h2>Recent regressions</h2><table class="ta-table"><thead><tr><th>When</th><th>From</th><th>To</th><th>Cause</th></tr></thead><tbody>@forelse($detail['regressions'] as $reg)<tr><td>{{ $reg['created_at']??'' }}</td><td>{{ $reg['prior_level']??'' }}</td><td>{{ $reg['new_level']??'' }}</td><td>{{ $reg['cause']??'' }}</td></tr>@empty<tr><td colspan="4">No regressions for this capability/workflow.</td></tr>@endforelse</tbody></table></div>
@endsection
