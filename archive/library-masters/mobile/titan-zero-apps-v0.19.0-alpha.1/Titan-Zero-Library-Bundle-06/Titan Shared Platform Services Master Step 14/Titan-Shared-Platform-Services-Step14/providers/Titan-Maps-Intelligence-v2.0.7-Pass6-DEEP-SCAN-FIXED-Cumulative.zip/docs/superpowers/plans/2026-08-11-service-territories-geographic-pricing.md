# Service Territories & Geographic Pricing Signals Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans. Steps use checkbox syntax for tracking.

**Goal:** Add graphical service territories, branch/travel zones, tenant-safe coverage evaluation, and advisory geographic pricing signals.

**Architecture:** Persist territory definitions separately from immutable evaluation/signal evidence. Use a pure matcher for circle/polygon/postcode/suburb rules, and the existing durable routing layer for road-distance/drive-time rules. CRM remains final pricing authority.

**Tech Stack:** PHP 8.3, Laravel 10, Eloquent/MySQL, existing Titan graphical map engine, existing durable routing service.

## Global Constraints
- Root manifest remains `titan-extension-v1`.
- No final quote/invoice pricing is written by Maps.
- No fake postcode/suburb polygons.
- No drive-time result when ETA evidence is unavailable.
- Every owned row is company-scoped.

### Task 1: Pure territory matching
- [ ] Write failing runtime tests for circle, polygon, postcode/suburb normalization and exclusion precedence.
- [ ] Implement `ServiceTerritoryMatcher` and value DTO.
- [ ] Rerun runtime tests.

### Task 2: Persistence
- [ ] Add schema-contract tests for territory definitions, evaluations, and pricing signals.
- [ ] Add three forward-safe migrations and models.
- [ ] Update schema contract and manifest owned tables.

### Task 3: Coverage/travel evaluation
- [ ] Add failing architecture verifier for service APIs and travel-zone provenance.
- [ ] Implement `ServiceTerritoryService` and `GeographicPricingSignalService`.
- [ ] Validate branch anchors via company-scoped canonical MapLocation.
- [ ] Use durable route calculation for road-distance/drive-time zones.

### Task 4: HTTP/UI/map
- [ ] Add user/API request/controller routes for CRUD/evaluate.
- [ ] Add Service Areas, Travel Zones, Geographic Pricing menu children and upgrade sync migration.
- [ ] Render graphical territory overlays and draw controls.
- [ ] Add forms/results to user navigation.

### Task 5: Titan AI and release gates
- [ ] Add territory manage/read/evaluate and pricing-signal read/evaluate capabilities.
- [ ] Update permissions, docs, version and changelog.
- [ ] Run inherited verification, lint, JSON/JS checks, integrity hashes and final ZIP byte-level certification.
