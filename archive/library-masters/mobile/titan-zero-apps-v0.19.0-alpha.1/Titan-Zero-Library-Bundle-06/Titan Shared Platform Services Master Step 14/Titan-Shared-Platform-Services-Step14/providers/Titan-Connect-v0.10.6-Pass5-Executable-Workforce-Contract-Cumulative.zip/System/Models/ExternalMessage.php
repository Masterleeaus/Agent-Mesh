<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

final class ExternalMessage extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use HasUuids;

    protected $table = 'ext_titan_connect_external_messages';

    protected $fillable = [
        'uuid', 'company_id', 'external_thread_id', 'provider', 'provider_message_id',
        'direction', 'sender_ref', 'recipient_ref', 'body', 'message_type', 'status',
        'correlation_id', 'metadata', 'provider_created_at',
    ];

    protected $casts = ['metadata' => 'array', 'provider_created_at' => 'datetime'];

    public function uniqueIds(): array
    {
        return ['uuid'];
    }

    public function thread(): BelongsTo
    {
        return $this->belongsTo(ExternalThread::class, 'external_thread_id');
    }

    public function deliveries(): HasMany
    {
        return $this->hasMany(OutboundDelivery::class, 'external_message_id');
    }

    public function attachments(): HasMany
    {
        return $this->hasMany(MessageAttachment::class, 'external_message_id');
    }
}
