<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Health;

use App\Extensions\TitanRewind\System\Contracts\RewindEvidenceSignerContract;
use App\Extensions\TitanRewind\System\Contracts\RewindGovernanceGatewayContract;
use App\Extensions\TitanRewind\System\Contracts\RewindSignalTransportContract;
use App\Extensions\TitanRewind\System\Services\RewindCircuitBreakerService;
use App\Extensions\TitanRewind\System\Services\RewindDeadLetterService;
use App\Extensions\TitanRewind\System\Services\RewindQueueAdmissionService;
use App\Extensions\TitanRewind\System\Services\RewindRuntimeStateService;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class RewindHealthCheck
{
    public function __construct(
        private RewindRuntimeStateService $runtime,
        private RewindQueueAdmissionService $admission,
        private RewindDeadLetterService $deadLetters,
        private RewindCircuitBreakerService $breakers,
        private RewindEvidenceSignerContract $signer,
        private RewindGovernanceGatewayContract $governance,
        private RewindSignalTransportContract $signal,
    ) {}

    public function liveness(): array
    {
        return (new RewindHealthSnapshot('HEALTHY',['process'=>'HEALTHY'],now()->toIso8601String()))->toArray();
    }

    public function readiness(): array
    {
        $checks=[];
        try { $runtime=$this->runtime->current(); $checks['runtime']=$runtime->healthStatus(); $status=$runtime->healthStatus(); }
        catch (Throwable) { $runtime=null; $checks['runtime']='UNAVAILABLE'; $status='UNAVAILABLE'; }
        try { $checks['database']=Schema::hasTable('titan_rewind_runtime_state')?'HEALTHY':'UNAVAILABLE'; if ($checks['database']==='UNAVAILABLE') $status='UNAVAILABLE'; } catch (Throwable) { $checks['database']='UNAVAILABLE'; $status='UNAVAILABLE'; }
        try { $checks['evidence_signer']=$this->signer->available()?'HEALTHY':'DEGRADED'; } catch (Throwable) { $checks['evidence_signer']='DEGRADED'; }
        try { $checks['governance_gateway']=$this->governance->available()?'HEALTHY':'DEGRADED'; } catch (Throwable) { $checks['governance_gateway']='DEGRADED'; }
        try { $checks['signal_transport']=$this->signal->available()?'HEALTHY':'DEGRADED'; } catch (Throwable) { $checks['signal_transport']='DEGRADED'; }
        try {
            $replay=$this->admission->decision((string)config('titan-rewind.queues.replay','titan-rewind-replay'));
            $checks['replay_backlog']=($replay['allowed']??false)?(($replay['state']??'ACTIVE')==='DEGRADED'?'DEGRADED':'HEALTHY'):'DEGRADED';
        } catch (Throwable) { $checks['replay_backlog']='DEGRADED'; }
        try { $checks['dead_letters']=$this->deadLetters->attentionCount() > (int)config('titan-rewind.dead_letter.degraded_threshold',0)?'DEGRADED':'HEALTHY'; } catch (Throwable) { $checks['dead_letters']='DEGRADED'; }
        try { $checks['circuit_breakers']='HEALTHY'; foreach ($this->breakers->states() as $breaker) if (($breaker['state']??'CLOSED')==='OPEN') { $checks['circuit_breakers']='DEGRADED'; break; } } catch (Throwable) { $checks['circuit_breakers']='DEGRADED'; }
        if ($status==='HEALTHY' && in_array('DEGRADED',$checks,true)) $status='DEGRADED';
        return (new RewindHealthSnapshot($status,$checks,now()->toIso8601String()))->toArray();
    }

    public function snapshot(): array { return $this->readiness(); }
}
