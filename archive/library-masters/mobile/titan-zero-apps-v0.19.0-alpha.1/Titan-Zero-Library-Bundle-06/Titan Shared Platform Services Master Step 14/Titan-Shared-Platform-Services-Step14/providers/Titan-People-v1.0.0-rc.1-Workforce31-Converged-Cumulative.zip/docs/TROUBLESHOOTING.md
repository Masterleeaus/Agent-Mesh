# Troubleshooting

If People navigation is missing, run `php artisan titan-people:host-sync --force`. Worker resolution failures are intentionally fail-closed: verify authenticated Titan tenant context and the tenant-scoped external subject mapping.
