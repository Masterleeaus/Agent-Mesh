## 1.20.0-rc.5 — Step 5 Advanced Reconciliation Automation

- Added one-to-many and many-to-one reconciliation group matching with exact-sum/date-window validation; many-to-many remains unsupported.
- Added immutable reconciliation group/member/event evidence plus a derived active-member uniqueness index.
- Added deterministic transfer recognition, bounded bank-fee/interest adjustment journals and advanced reconciliation suggestions.
- Added economic bank-statement SHA-256 fingerprinting to reject duplicate statements even when provider IDs differ.
- Added bank statement `classification_hint`, advanced read port/APIs/workspaces and three governed commands/events (50 total).
- Expanded production certification to migration 20, advanced reconciliation schema and 63 MySQL trigger controls.
- Preserved Installer 1.7.6 dependency-object compatibility and all prior accounting/authority boundaries.

## 1.19.0-rc.4 — Step 4 Multi-Bank, Credit Card & Clearing Accounts

- Added immutable company-scoped financial-account registry for bank, credit-card and payment-clearing Ledger accounts.
- Added governed account registration, internal-transfer, clearing-payout and credit-card-payment commands plus corresponding Signal events (47 total commands/events).
- Added balanced authoritative journals for internal transfers, clearing payouts and card-liability payments.
- Added payment-clearing account 1020 and Titan Pay `funds_account_public_id` support; Stripe/PayPal may settle to clearing while fee-free/direct rails remain direct-bank/cash semantics.
- Clearing captures are excluded from cash until payout; clearing payout cannot exceed posted clearing balance.
- Refunds are constrained to the original payment funds account.
- Extended bank reconciliation to credit-card liabilities using signed Ledger balances.
- Made actual cashflow multi-bank aware and net per journal so internal transfers do not inflate gross inflow/outflow.
- Added immutable banking movement evidence, four MySQL guards, Step 4 public read port, APIs and Banking Accounts / Multi-Account Banking workspaces.
- Expanded production certification to verify Step 4 migration/tables, payment settlement funds-account column and 55 trigger controls.
- Preserved Installer 1.7.6 dependency-object manifest contract introduced in Step 3.

## 1.18.0-rc.3 — New Plan Step 3/12: Advanced GST, BAS and Tax Adjustments + Installer 1.7.6 Manifest Hotfix

- Fixed Installer 1.7.6 validation failure by changing root `dependencies` to slug-bearing dependency objects.
- Added permanent `Installer176ManifestContractTest.php` regression coverage.
- Added immutable GST adjustment facts and append-only accountant review events.
- Added bad-debt write-off/recovery, mixed acquisition, input-taxed and explicit BAS classification adjustment support.
- Added Full BAS evidence labels G1/G2/G3/G10/G11/1A/1B with fail-closed classification completeness.
- Added governed `ledger.tax.gst_adjustment.record`, `ledger.tax.gst_adjustment.review` and `ledger.tax.gst_snapshot.amend`.
- Added immutable snapshot detail evidence and source fingerprints including adjustment/review state.
- Expanded production trigger certification from 45 to 51 controls.
- Added GST Adjustments user surface and Advanced GST Control Super Admin surface.
- Preserved no-ATO/SBR-lodgement authority.

## 1.17.0-rc.2 — New Plan Step 2/12: Fiscal Year Close and Retained Earnings Automation

- Added `titan.ledger.financial-year-close.v1` read-only close preview/history boundary.
- Added governed close preparation, close and reopen commands through Command Bus, Risk and Assurance.
- Added exact temporary-account zeroing and retained-earnings transfer for profit or loss.
- Added immutable/versioned fiscal-close evidence and append-only reopen events.
- Added `year_end_close` and `year_end_reopen` authoritative journal types with soft-lock-safe period guards.
- Added close gates for period state, unposted journals, Trial Balance, bank reconciliation, GST snapshots, AUD normalization and source-fingerprint drift.
- Preserved historical P&L/comparative continuity by excluding close/reopen mechanics from P&L while retaining their Balance Sheet effects.
- Expanded production MySQL trigger certification from 41 to 45 controls and retained the live-host `NOT_EXECUTED` fail-closed gate.
- Added Year-End Close user workspace and Fiscal Close Control Super Admin workspace.

## 1.15.0-alpha.16 — Pass 15: Cashflow, Forecasting and Profitability

- Added read-only `titan.ledger.cashflow-forecasting.v1` advisory boundary.
- Added posted-journal actual cashflow, current cash balance and trailing net-cash runway evidence.
- Added nominal due-date AR/AP cash forecast with explicit excluded evidence and evidence-coverage confidence bands.
- Added posted-journal profitability summary and account-category profitability.
- Added forecast-vs-actual variance against frozen forecast schedules.
- Added immutable `titan_ledger_forecast_snapshots` with governed prepare/finalize/supersede commands.
- Added three forecast Signal events while keeping forecasts authority-neutral and unable to create journals.
- Added Cashflow and Forecasts user workspace, Forecasting and Profitability Super Admin workspace, and authenticated read APIs.
- Preserved customer/job profitability as a foundation requiring authoritative dimension mapping instead of guessed attribution.

# Changelog

## 1.14.0-alpha.15 — Pass 14: Financial Statements and Management Reporting

- Added posted-journal-only Trial Balance, Profit and Loss and Balance Sheet reporting.
- Added retained-earnings roll-forward with explicit posted retained-earnings movement and unclosed current-period profit.
- Added previous-period and prior-year comparatives plus management variance outputs.
- Added bounded account drill-down APIs and read-only `titan.ledger.financial-reporting.v1` host binding.
- Added immutable/versioned `titan_ledger_financial_report_snapshots` with prepare, finalize and supersede commands.
- Snapshot source fingerprints include both posted journal payload identity and Chart of Accounts classification, preventing stale finalization after account reclassification.
- Added fail-closed completeness: finalized report evidence currently requires complete AUD-normalized journals; foreign-currency activity prevents false consolidated certification.
- Added Financial Reports user workspace, Financial Reporting Super Admin diagnostics and authenticated statement/report APIs.
- Expanded governed Command Bus and Signal catalogues to 36 commands/events.
- Added Pass 14 cumulative verification.

## 1.13.0-alpha.14 — Pass 13: Australian GST and Tax Ledger

- Added canonical Australian GST treatment catalogue with standard GST sales/purchase, GST-free, input-taxed and BAS-excluded codes.
- Added Simpler BAS calculator for G1, 1A and 1B from immutable Ledger invoice/spend evidence.
- Added AUD/accrual fail-closed policy; cash-basis finalization deferred until payment-level GST allocation exists.
- Added immutable versioned `titan_ledger_gst_tax_snapshots` evidence with prepare → finalize lifecycle and non-destructive supersession.
- Added governed GST snapshot commands and Signal events with full causal/governance lineage.
- Added read-only `titan.ledger.gst-tax-ledger.v1` host binding; no ATO lodgement or network authority.
- Added GST/BAS user and GST Tax Ledger Super Admin workspaces plus authenticated preview/snapshot APIs.
- Added Pass 13 cumulative verification.

## 1.12.0-alpha.13 — Pass 12: Banking and Reconciliation Engine
- Added privacy-bounded bank statement facts with signed integer minor-unit movements and statement arithmetic proof.
- Added immutable Ledger-owned bank statement/transaction evidence and open-to-closed reconciliation sessions.
- Added deterministic exact-amount/date/reference-hash matching with explicit ambiguous/unmatched outcomes and append-only match/rejection evidence.
- Added account-level close proof: every transaction matched plus Ledger opening and closing bank balances equal the statement.
- Added governed bank import/match/reject/close commands and four matching Signal events.
- Added user Bank Reconciliation and Super Admin Banking and Reconciliation surfaces and read APIs.

## 1.11.0-alpha.12 — Pass 11: Accounts Payable and Spend Adapter

- Added `SpendAccountingFact`, journal mapper, governed service and public `titan.ledger.spend-accounting.v1` port.
- Added supplier bill, supplier credit, supplier payment and immediate spend commands/events.
- Added immutable `titan_ledger_spend_postings` and derived `titan_ledger_payables`.
- Added AP balances/aging, supplier prepayment handling, cash/card funding accounts, and Ledger-only reporting integration.
- Added Payables user workspace/API and AP and Spend Adapter Super Admin diagnostics.
- Preserved external spend approval/document authority and removed any need for direct Budgeting/purchasing reads.

## 1.10.0-alpha.11 — Pass 10: Accounts Receivable and Collections

- Added company-scoped `titan_ledger_receivables` projection derived only from immutable Ledger invoice/settlement evidence.
- Added aging buckets with explicit unknown-due-date behavior and optional CRM `due_at` support.
- Added partial-payment, refund, credit-note, overpayment and receivable-credit aware outstanding-balance calculation.
- Added immutable `titan_ledger_collection_events` for governed state transitions and follow-up facts.
- Added `ledger.receivable.collection.transition` and `ledger.receivable.follow_up.record` Command Bus mutations and matching Signal events.
- Added bounded collection states, reason codes, next-action scheduling and promise-to-pay amount validation.
- Kept outbound SMS/email/phone delivery outside Ledger authority; Ledger records evidence only.
- Added authenticated Receivables and aging APIs plus user Receivables and Super Admin AR and Collections surfaces.
- Expanded cumulative registries to 22 commands and 22 events.
- Added Pass 10 red/green balance, aging, collection-policy and source-contract tests.

## 1.9.0-alpha.10 — Pass 9: Titan Pay / ZeroPay Settlement Adapter

- Added `titan.ledger.payment-settlement.v1` with compatibility alias `titan.ledger.zeropay-settlement.v1`.
- Added governed `ledger.payment.settlement.post` and `ledger.payment.refund.post` commands.
- Added integer-minor-unit settlement/refund fact validation for PayID, bank transfer, cash, Stripe and PayPal.
- Enforced fee-free PayID, bank transfer and cash settlement facts.
- Added partial-payment allocation against posted CRM invoice outstanding balances.
- Added protected `customer_overpayments` liability account and excess-payment posting.
- Added merchant-fee accounting and refund-fee accounting without rebooking invoice revenue.
- Added immutable `titan_ledger_payment_settlements` evidence with ownership-aware adoption and MySQL immutability guards.
- Added settlement/refund Signal events and bounded Risk/Assurance evidence fields.
- Updated cash reporting to Ledger-owned settlement evidence only; no direct ZeroPay/CRM payment table reads.
- Added Payment Settlements user surface and Titan Pay Adapter Super Admin surface.
- Added Pass 9 red/green fact, mapper and source-contract tests plus cumulative verifier.

## 1.6.0-alpha.7 — Pass 6: Signal Engine and Financial Event Fabric

- Added a canonical 16-event Ledger financial event catalog mapped one-to-one from governed mutation commands.
- Added deterministic financial Signal envelopes with `signal_id`/`event_id`, schema version, `company_id`, actor, command, governance reference, authoritative domain receipt, write fingerprint and full trace/correlation/causation lineage.
- Added privacy-bounded event payloads: only allowlisted financial summary fields are emitted; arbitrary memo/metadata/request payload content is excluded.
- Added `titan_ledger_signal_outbox` as a durable transactional outbox written atomically with authoritative Ledger mutations and command receipts.
- Added deterministic event idempotency and company+command+event uniqueness, retry/backoff state, delivery receipts and retained delivery evidence.
- Added MySQL guards protecting event identity/payload, legal delivery state transitions, non-decreasing attempts, delivered immutability and retained outbox rows.
- Added explicit Titan Signal host publisher binding `titan.signal.publisher.v1`; no Signal API is guessed when the host does not provide it.
- Added best-effort after-commit delivery plus retryable `titan-ledger:signal-drain` operator command. Signal downtime never becomes a second financial writer and does not erase committed accounting truth.
- Added machine-readable financial event schema and event catalog resources.
- Added user **Financial Events** and Super Admin **Signal Fabric** routes/menu links with diagnostics.
- Added Pass 6 red/green event catalog, envelope/privacy and source-contract tests plus cumulative verification.

# Changelog

## 1.5.0-alpha.6 — Pass 5: Command Bus Posting Authority and Full Menu Navigation

- Removed the in-progress local command bridge so Ledger HTTP mutations cannot bypass Titan Command Bus.
- Added 16 canonical Ledger mutation command definitions with owner, permission, target, receipt and idempotency metadata.
- Added a fail-closed Command Bus gateway contract and Ledger-owned authoritative domain adapter binding.
- Added immutable company-scoped domain command receipts with governance reference, trace lineage, write verification and replay-safe request fingerprints.
- Required Titan Command Bus for steady-state Ledger mutation execution.
- Kept direct domain services internal to the authoritative adapter; HTTP mutation controllers submit commands instead of mutating tables/services directly.
- Added one Titan Ledger user parent with Overview, Bookkeeping, Chart of Accounts, Journals, Financial Years, Accounting Periods, Command Receipts and Diagnostics children.
- Added one Titan Ledger Super Admin parent with Overview, Command Authority, Menu Diagnostics and System Diagnostics children.
- Added registry-first navigation plus schema-aware, route-aware, duplicate-safe MagicAI menus-table self-healing and menu-cache regeneration.
- Added `titan-ledger:host-sync` for non-destructive navigation repair.
- Added Pass 5 command/navigation/source contracts and cumulative verification.
- Bound domain execution to the original submission fingerprint so Command Bus payload mutation is rejected before accounting writes.
- Hardened adopted receipt schemas, receipt completion transitions and immutable receipt identity fields; failed authoritative mutations retain durable failure evidence.

## 1.4.0-alpha.5 — Pass 4: Financial Periods, Years and Locks

- Added company-scoped financial years and accounting periods.
- Added Australian Jul-Jun automatic coverage and custom fiscal-year creation with partial-month boundary preservation.
- Added open, soft-locked and hard-locked accounting period states.
- Added append-only period lock event provenance with MySQL immutability triggers.
- Added financial-year close/reopen governance; reopening returns periods to soft-lock rather than silently reopening historical posting.
- Added posting-date attribution to financial year/accounting period and lock-state snapshot on posted journals.
- Added governed prior-period adjustments: soft-locked periods accept only adjustment/correction/reversal journals with explicit override reason.
- Hard-locked periods and closed financial years reject posting until explicitly reopened.
- Added a MySQL posting guard so direct database posting cannot bypass period controls.
- Added authenticated financial-year/accounting-period APIs and cumulative Pass 4 verification.

## 1.3.0-alpha.4 — Pass 3: Immutable Double-Entry Journal Engine

- Added canonical company-scoped journal headers and journal lines.
- Added integer-minor-unit double-entry validation and exact debit/credit balancing.
- Added draft -> validated -> posted lifecycle with row locking and payload hashing.
- Added company-scoped posting idempotency keys with collision rejection.
- Added source/event/trace/correlation/causation provenance.
- Added linked reversal and correction journal flows; generic draft creation cannot spoof those types.
- Reversals preserve historical correctness when an original account was later deactivated.
- Added MySQL triggers preventing direct mutation/deletion of posted headers and any mutation of posted lines.
- Added journal API routes/controller and service registration.
- Corrected stale Pass 1 upgrade metadata left in `extension.json`.
- Preserved Pass 1 and Pass 2 behavior and compatibility surfaces.

# Titan Ledger 1.2.0-alpha.3 — Pass 2: Canonical Chart of Accounts

## Added

- Ledger-owned `titan_ledger_accounts` canonical Chart of Accounts schema.
- Company-scoped unique account codes and unique protected system-account identities.
- Account hierarchy, subtype, normal-balance, tax-code, active/system/protected state and metadata fields.
- `ChartOfAccountCatalog` with a curated Australian SME baseline and deterministic debit/credit normal-balance rules.
- `ChartOfAccountsService` for default provisioning, listing, lookup, custom-account creation and safe updates.
- Protected control-account conflict detection and concurrency-safe default provisioning.
- Same-company parent validation and hierarchy-cycle rejection.
- Authenticated Chart of Accounts API list/create/update endpoints using existing CRM bookkeeping permissions.
- Pass 2 source-contract and catalog regression tests plus cumulative verifier.

## Architecture

- Rejected Money Team's duplicate `acc_coa` / `chart_of_accounts` model split.
- Adopted one namespaced Ledger-owned table so future journals have an unambiguous accounting authority.
- Kept simple bookkeeping as a compatibility projection; it is not yet converted into authoritative journal postings.

## Preserved

- Pass 1 canonical `company_id` tenancy and legacy compatibility migration.
- GST-safe manual transaction updates.
- Ownership-aware non-destructive migration policy.
- Existing bookkeeping routes, reports, UI and historical `crm_bookkeeping_*` data.

## 1.7.0-alpha.8 — Pass 7 Rewind, Risk and Assurance Integration

- Added fail-closed Ledger-facing Titan Risk and Titan Assurance gateways.
- Added privacy-bounded governance evidence builder and external decision normalizer.
- Risk is evaluated before Assurance; denial/unavailability prevents Ledger domain execution.
- Persisted immutable Risk/Assurance references/classes/scores/ruleset versions on command receipts and Signal outbox rows.
- Added read-only `titan-ledger.rewind-source` with company/trace scoping, as-of reads, watermarks and canonical source hashes.
- Added Governance Evidence, Risk and Assurance, and Rewind Integration navigation surfaces.
- Added Pass 7 behavioral/source regression suite.

## 1.8.0-alpha.9 — Pass 8 CRM Invoice Accounting Adapter
- Added contract-driven `titan.ledger.crm-invoice-accounting.v1` port for CRM invoice and credit-note facts.
- Added governed `ledger.crm.invoice.post` and `ledger.crm.credit_note.post` commands.
- Added immutable CRM-document-to-Ledger posting evidence and source-event idempotency.
- Issued invoices post DR Accounts Receivable / CR Revenue / CR GST Payable.
- Credit notes post linked correcting journals: DR Revenue + GST Payable / CR Accounts Receivable.
- Removed direct CRM invoice/payment/refund table reads from Ledger reporting; invoice accrual reporting now reads Ledger-owned posting evidence and cash remains conservative until Titan Pay settlement integration.
- Added Invoice Accounting and CRM Invoice Adapter navigation surfaces.

## 1.16.0-rc.1 — Production Certification and Live-Host Hardening
- Added `titan-ledger:production-certify` with optional `--repair` and machine-readable `--json` output.
- Added live MySQL certification for required Ledger tables, canonical `company_id` tenancy, 41 immutability/period/evidence triggers, Command Bus, Risk, Assurance, Signal outbox, Rewind source, routes and menus.
- Added upgrade-time trigger self-heal by idempotently replaying trigger-bearing migrations and verifying the complete trigger catalog.
- Hardened Command Bus/Risk/Assurance `available()` probes so bound-but-invalid host services no longer report ready.
- Converted every packaged migration rollback path to non-destructive retention of financial/governance/forensic evidence.
- Added a Production Certification Super Admin surface and read-only certification binding `titan.ledger.production-certification.v1`.
- Lowered declared MagicAI compatibility floor to 10.91 while preserving Laravel 10 / PHP 8.2+ compatibility contracts.
