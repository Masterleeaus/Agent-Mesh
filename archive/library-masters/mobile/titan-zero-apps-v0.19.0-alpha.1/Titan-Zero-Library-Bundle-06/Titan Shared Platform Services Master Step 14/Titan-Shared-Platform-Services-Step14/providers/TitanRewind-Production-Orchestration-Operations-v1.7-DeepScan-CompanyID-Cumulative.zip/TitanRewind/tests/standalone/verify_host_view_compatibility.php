<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$views = glob($root . '/resources/views/*.blade.php') ?: [];
$failures = [];
$checks = 0;
$check = static function (bool $condition, string $message) use (&$failures, &$checks): void {
    ++$checks;
    if (! $condition) {
        $failures[] = $message;
    }
};

$check(count($views) === 7, 'all seven Rewind Blade surfaces are present');

foreach ($views as $view) {
    $name = basename($view);
    $text = (string) file_get_contents($view);
    $check(! str_contains($text, '<x-layouts.app>') && ! str_contains($text, '</x-layouts.app>'), "{$name} does not use unavailable x-layouts.app component");
    $check(str_contains($text, "@extends('panel.layout.app')"), "{$name} extends the verified MagicAI panel layout");
    $check(str_contains($text, "@section('content')"), "{$name} defines panel content section");
    $check(str_contains($text, '@endsection'), "{$name} closes the content section");
}

$allBlade = '';
foreach ($views as $view) {
    $allBlade .= (string) file_get_contents($view) . "\n";
}
$check(! preg_match('/<x-layouts\.[A-Za-z0-9_.:-]+/', $allBlade), 'no unverified layouts.* Blade component remains');

if ($failures !== []) {
    fwrite(STDERR, "Host view compatibility verification failed ({$checks} checks):\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

printf("Host view compatibility PASS (%d/%d)\n", $checks, $checks);
