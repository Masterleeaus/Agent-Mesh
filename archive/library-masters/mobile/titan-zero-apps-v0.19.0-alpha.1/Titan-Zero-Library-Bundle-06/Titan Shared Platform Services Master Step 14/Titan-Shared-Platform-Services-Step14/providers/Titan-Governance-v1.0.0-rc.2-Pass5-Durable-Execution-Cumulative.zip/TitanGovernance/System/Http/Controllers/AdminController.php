<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Http\Controllers;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceManagerContract;
use App\Extensions\TitanGovernance\System\Host\TitanHostAuthorizationAdapter;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

final class AdminController
{
    public function __construct(private readonly GovernanceManagerContract $governance, private readonly TitanHostAuthorizationAdapter $authorization) {}
    public function __invoke(Request $request): View
    {
        $user = $request->user(); abort_unless($user && $this->authorization->allows($user, 'titan-governance.admin', ['titan-governance.admin']), 403);
        return view('titan-governance::admin', ['health' => $this->governance->health()]);
    }
}
