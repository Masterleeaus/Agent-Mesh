<?php

declare(strict_types=1);

require __DIR__ . '/../System/Tenancy/TenantContext.php';
require __DIR__ . '/../System/Tenancy/TenantIdResolver.php';

use App\Extensions\TitanModelCouncil\System\Tenancy\TenantIdResolver;

$r = new TenantIdResolver();
assert($r->resolve(['tenant_company_id' => 44], ['tenant_company_id' => 55]) === 44);
assert($r->resolve([], ['tenant_company_id' => 55]) === 55);
assert($r->resolve(['tenant_company_id' => 0], ['tenant_company_id' => null]) === null);
assert($r->resolve(['company_id' => 99], []) === null); // never confuse CRM customer company_id with tenant_company_id

echo "pass3_tenant_context_runner: OK\n";
