<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalArchiveCatalogContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalArchiveStoreContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEventStoreContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalHistoryQueryContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalHistoryTraversalContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalQueryContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalArchiveEntry;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalHistoryRecord;
use App\Extensions\TitanSignalEngine\System\Data\SignalHistoryWindow;
use App\Extensions\TitanSignalEngine\System\Exceptions\SignalIntegrityException;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use Throwable;

final class SignalHistoryQueryService implements SignalHistoryQueryContract, SignalHistoryTraversalContract
{
    public function __construct(
        private readonly SignalQueryContract $hot,
        private readonly SignalEventStoreContract $hotStore,
        private readonly SignalArchiveCatalogContract $catalog,
        private readonly SignalArchiveStoreContract $archiveStore,
        private readonly SignalContextValidator $contextValidator,
    ) {
    }

    public function find(string $eventId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT): ?SignalHistoryRecord
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        $hot = $this->hot->find($eventId, $context, $tenantCompanyId, $scope);
        if ($hot !== null) return SignalHistoryRecord::hot($hot->toArray(), true);
        $entry = $this->catalog->find($eventId, $tenantCompanyId, $scope);
        return $entry === null ? null : $this->coldRecord($entry);
    }

    public function byTrace(string $traceId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array
    {
        $window = $this->traceWindow($traceId, $context, $tenantCompanyId, $scope, $limit);
        $this->assertColdHistoryComplete($window);
        return $window->records;
    }

    public function byCorrelation(string $correlationId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array
    {
        $window = $this->correlationWindow($correlationId, $context, $tenantCompanyId, $scope, $limit);
        $this->assertColdHistoryComplete($window);
        return $window->records;
    }

    public function childrenOf(string $parentEventId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        $bounded = $this->bound($limit);
        $hotRows = $this->hotStore->byCausation($parentEventId, $tenantCompanyId, $scope, $bounded);
        $hot = array_map(fn (SignalEvent $event): SignalEnvelope => $this->hotEnvelope($event), $hotRows);
        $cold = $this->catalog->byCausation($parentEventId, $tenantCompanyId, $scope, $bounded);
        $window = $this->window($hot, $cold, count($hot), count($cold), $bounded);
        $this->assertColdHistoryComplete($window);
        return $window->records;
    }

    public function byRootCausation(string $rootCausationId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        $bounded = $this->bound($limit);
        $hot = $this->hot->byRootCausation($rootCausationId, $context, $tenantCompanyId, $scope, $bounded);
        $cold = $this->catalog->byRootCausation($rootCausationId, $tenantCompanyId, $scope, $bounded);
        $window = $this->window($hot, $cold, count($hot), count($cold), $bounded);
        $this->assertColdHistoryComplete($window);
        return $window->records;
    }

    public function traceWindow(string $traceId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 1000): SignalHistoryWindow
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        $bounded = $this->bound($limit);
        $hotCount = $this->hotStore->countByTrace($traceId, $tenantCompanyId, $scope);
        $coldCount = $this->catalog->countByTrace($traceId, $tenantCompanyId, $scope);
        return $this->window(
            $this->hot->byTrace($traceId, $context, $tenantCompanyId, $scope, $bounded),
            $this->catalog->byTrace($traceId, $tenantCompanyId, $scope, $bounded),
            $hotCount,
            $coldCount,
            $bounded,
        );
    }

    public function correlationWindow(string $correlationId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 1000): SignalHistoryWindow
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        $bounded = $this->bound($limit);
        $hotCount = $this->hotStore->countByCorrelation($correlationId, $tenantCompanyId, $scope);
        $coldCount = $this->catalog->countByCorrelation($correlationId, $tenantCompanyId, $scope);
        return $this->window(
            $this->hot->byCorrelation($correlationId, $context, $tenantCompanyId, $scope, $bounded),
            $this->catalog->byCorrelation($correlationId, $tenantCompanyId, $scope, $bounded),
            $hotCount,
            $coldCount,
            $bounded,
        );
    }

    /**
     * @param list<SignalEnvelope> $hot
     * @param list<SignalArchiveEntry> $cold
     */
    private function window(array $hot, array $cold, int $hotCount, int $coldCount, int $limit): SignalHistoryWindow
    {
        $records = [];
        foreach ($hot as $envelope) $records[$envelope->eventId] = SignalHistoryRecord::hot($envelope->toArray(), true);

        $coldByBatch = [];
        foreach ($cold as $entry) {
            if (isset($records[$entry->eventId])) continue;
            $key = $entry->batchId . '|' . $entry->archiveLocator . '|' . $entry->archiveChecksum;
            $coldByBatch[$key]['entries'][] = $entry;
            $coldByBatch[$key]['locator'] = $entry->archiveLocator;
            $coldByBatch[$key]['checksum'] = $entry->archiveChecksum;
            $coldByBatch[$key]['driver'] = $entry->archiveDriver;
            $coldByBatch[$key]['batch_id'] = $entry->batchId;
        }

        $failures = [];
        foreach ($coldByBatch as $group) {
            $wanted = [];
            foreach ($group['entries'] as $entry) $wanted[$entry->eventId] = $entry;
            try {
                $maxBatch = max($limit, (int) config('titan-signal-engine.prune_batch_limit', 1000));
                foreach ($this->archiveStore->stream($group['locator'], $group['checksum'], 1, $maxBatch, $group['driver']) as $event) {
                    $eventId = (string) ($event['event_id'] ?? '');
                    if ($eventId === '' || ! isset($wanted[$eventId])) continue;
                    $records[$eventId] = SignalHistoryRecord::cold($event, $wanted[$eventId], true);
                    unset($wanted[$eventId]);
                    if ($wanted === []) break;
                }
                if ($wanted !== []) {
                    $failures[] = ['batch_id' => (string) $group['batch_id'], 'code' => 'archive_event_missing'];
                }
            } catch (Throwable) {
                $failures[] = ['batch_id' => (string) $group['batch_id'], 'code' => 'archive_unavailable_or_invalid'];
            }
        }

        uasort($records, static function (SignalHistoryRecord $a, SignalHistoryRecord $b): int {
            $aOccurred = (string) ($a->event['occurred_at'] ?? '');
            $bOccurred = (string) ($b->event['occurred_at'] ?? '');
            $cmp = strcmp($aOccurred, $bOccurred);
            return $cmp !== 0 ? $cmp : strcmp((string) $a->event['event_id'], (string) $b->event['event_id']);
        });

        $total = $hotCount + $coldCount;
        $truncated = $total > $limit;
        return new SignalHistoryWindow(
            array_slice(array_values($records), 0, $limit),
            $hotCount,
            $coldCount,
            $total,
            $truncated,
            $failures,
        );
    }

    private function coldRecord(SignalArchiveEntry $entry): SignalHistoryRecord
    {
        $event = $this->archiveStore->readEvent($entry->archiveLocator, $entry->archiveChecksum, $entry->eventId, $entry->archiveSequence, $entry->archiveDriver);
        if ($event === null) throw new SignalIntegrityException('Signal archive catalog points to a missing event record.');
        return SignalHistoryRecord::cold($event, $entry, true);
    }

    private function hotEnvelope(SignalEvent $event): SignalEnvelope
    {
        $envelope = SignalEnvelope::fromPersistenceArray(array_replace($event->getAttributes(), [
            'payload' => $event->payload ?? [],
            'metadata' => $event->metadata ?? [],
        ]));
        if (! $envelope->verifyChecksum()) throw new SignalIntegrityException("Signal checksum verification failed for event {$envelope->eventId}.");
        return $envelope;
    }

    private function assertColdHistoryComplete(SignalHistoryWindow $window): void
    {
        if (! $window->integrityComplete()) throw new SignalIntegrityException('Signal cold history is unavailable or failed archive-integrity verification.');
    }

    private function bound(int $limit): int
    {
        return max(1, min($limit, (int) config('titan-signal-engine.archive_query_limit', 1000)));
    }
}
