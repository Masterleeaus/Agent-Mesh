# CRM 1.3.0-alpha.13 — Forecast Runtime Contract Hotfix

## Live failure

CRM Overview returned HTTP 500:

`Call to undefined method App\\Extensions\\Crm\\System\\Services\\CrmForecastService::summary()`

## Root cause

`CrmForecastService` exposes the canonical method:

`public function summarize(int $userId): array`

but `CrmViewDataService` retained two stale calls to `summary($userId)` in:

- `overview()`
- `reports()`

Other CRM forecast consumers already used `summarize()` correctly.

The mismatch existed in alpha.10, alpha.11 and alpha.12 and was not covered by the previous runtime verifier.

## Fix

Both stale `CrmViewDataService` calls now use:

`$this->forecast->summarize($userId)`

No duplicate `summary()` alias was added, so CRM retains one canonical Forecast API.

## Regression protection

Added `bin/verify-v130-alpha13-forecast-contract.php`.

The gate requires:

- `CrmForecastService::summarize(int $userId): array`
- Overview to call `summarize()`
- Reports to call `summarize()`
- no stale `$this->forecast->summary(...)` call in `CrmViewDataService`

A whole-CRM concrete typed-service scan was also run after the repair and found no other concrete service calls targeting missing methods.
