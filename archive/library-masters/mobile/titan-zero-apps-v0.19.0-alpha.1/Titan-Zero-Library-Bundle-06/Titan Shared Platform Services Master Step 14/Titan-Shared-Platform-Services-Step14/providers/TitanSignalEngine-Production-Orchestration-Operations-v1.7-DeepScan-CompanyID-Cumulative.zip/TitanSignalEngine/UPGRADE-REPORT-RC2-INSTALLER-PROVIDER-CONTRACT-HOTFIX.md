# Titan Signal Engine v0.20.0-rc.2 — Installer 1.7.8 Provider Contract Hotfix

## Root cause

Installer 1.7.8 loads the staged service provider with `require_once` during deployment. rc.1 imported `ExtensionRegisterKeyProviderInterface` and `UninstallExtensionServiceProviderInterface` from `App\Extensions\Concerns`, a namespace that does not exist on the target MagicAI/Titan host. PHP therefore failed while declaring the provider class, before migrations or boot logic could run.

## Fix

The provider now imports the canonical Marketplace contracts used by the Titan Extension Blueprint templates and Installer 1.7.8:

- `App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface`
- `App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface`

A deployment-stage regression test stubs those real host interfaces and `Illuminate\Support\ServiceProvider`, then `require_once`s the provider exactly at the failure boundary.

## Scope

No database migration, Signal envelope, capability, queue, lifecycle, or retention behavior changed. This is a host-contract compatibility hotfix.
