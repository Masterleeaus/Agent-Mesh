<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Persistence;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalEventStoreContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use App\Extensions\TitanSignalEngine\System\Models\SignalCausalEdge;
use App\Extensions\TitanSignalEngine\System\Models\SignalIdempotencyKey;
use App\Extensions\TitanSignalEngine\System\Services\CausalEdgeProjector;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use RuntimeException;

final class SignalEventStore implements SignalEventStoreContract
{
    private readonly CausalEdgeProjector $edgeProjector;

    public function __construct(?CausalEdgeProjector $edgeProjector = null)
    {
        $this->edgeProjector = $edgeProjector ?? new CausalEdgeProjector();
    }

    public function append(SignalEnvelope $signal): array
    {
        $deduplicationKey = $this->deduplicationKey($signal);

        try {
            return DB::transaction(function () use ($signal, $deduplicationKey): array {
                $this->assertCausalBoundary($signal);

                $existing = SignalEvent::query()->where('event_id', $signal->eventId)->first();
                if ($existing !== null) {
                    $this->assertSameOwnership($existing, $signal);
                    $this->assertSameEventIdentity($existing, $signal);
                    $this->edgeProjector->projectForEvent($existing);
                    return ['event' => $existing, 'duplicate' => true, 'original_event_id' => (string) $existing->event_id];
                }

                if ($deduplicationKey !== null) {
                    $idempotency = SignalIdempotencyKey::query()->where('deduplication_key', $deduplicationKey)->first();
                    if ($idempotency !== null) {
                        if ($this->isExpired($idempotency->expires_at)) {
                            $idempotency->delete();
                        } else {
                            if ((string) $idempotency->request_fingerprint !== $signal->idempotencyFingerprint()) {
                                throw new RuntimeException('Signal idempotency key was reused for different event content.');
                            }
                            $existing = SignalEvent::query()->where('event_id', $idempotency->event_id)->first();
                            if ($existing === null) {
                                throw new RuntimeException('Signal idempotency record references a missing event.');
                            }
                            $this->assertSameOwnership($existing, $signal);
                            return ['event' => $existing, 'duplicate' => true, 'original_event_id' => (string) $existing->event_id];
                        }
                    }
                }

                $expiresAt = $deduplicationKey === null ? null : $this->idempotencyExpiry();
                $attributes = $signal->toPersistenceArray();
                $attributes['deduplication_key'] = $deduplicationKey;
                $attributes['idempotency_expires_at'] = $expiresAt;

                /** @var SignalEvent $event */
                $event = SignalEvent::query()->create($attributes);
                $this->edgeProjector->projectForEvent($event);

                if ($deduplicationKey !== null && $expiresAt !== null) {
                    SignalIdempotencyKey::query()->create([
                        'deduplication_key' => $deduplicationKey,
                        'event_id' => $event->event_id,
                        'scope' => $signal->scope,
                        'tenant_company_id' => $signal->tenantCompanyId,
                        'source' => $signal->source,
                        'idempotency_key' => $signal->idempotencyKey,
                        'request_fingerprint' => $signal->idempotencyFingerprint(),
                        'expires_at' => $expiresAt,
                    ]);
                }

                return ['event' => $event, 'duplicate' => false, 'original_event_id' => null];
            });
        } catch (QueryException $exception) {
            $existing = SignalEvent::query()->where('event_id', $signal->eventId)->first();
            if ($existing === null && $deduplicationKey !== null) {
                $key = SignalIdempotencyKey::query()->where('deduplication_key', $deduplicationKey)->first();
                if ($key !== null && ! $this->isExpired($key->expires_at)) {
                    if ((string) $key->request_fingerprint !== $signal->idempotencyFingerprint()) {
                        throw new RuntimeException('Signal idempotency key was reused for different event content.');
                    }
                    $existing = SignalEvent::query()->where('event_id', $key->event_id)->first();
                }
            }

            if ($existing === null) {
                throw $exception;
            }

            $this->assertSameOwnership($existing, $signal);
            if ((string) $existing->event_id === $signal->eventId) {
                $this->assertSameEventIdentity($existing, $signal);
            }
            return ['event' => $existing, 'duplicate' => true, 'original_event_id' => (string) $existing->event_id];
        }
    }

    public function find(string $eventId, ?int $tenantCompanyId, string $scope): ?SignalEvent
    {
        /** @var SignalEvent|null $event */
        $event = SignalEvent::query()
            ->inScope($scope, $tenantCompanyId)
            ->where('event_id', $eventId)
            ->first();

        return $event;
    }

    public function byTrace(string $traceId, ?int $tenantCompanyId, string $scope, int $limit): array
    {
        return SignalEvent::query()
            ->inScope($scope, $tenantCompanyId)
            ->where('trace_id', $traceId)
            ->orderBy('occurred_at')
            ->orderBy('event_id')
            ->limit($this->boundedGraphLimit($limit))
            ->cursor()
            ->all();
    }

    public function countByTrace(string $traceId, ?int $tenantCompanyId, string $scope): int
    {
        return SignalEvent::query()->inScope($scope, $tenantCompanyId)->where('trace_id', $traceId)->count();
    }

    public function byCorrelation(string $correlationId, ?int $tenantCompanyId, string $scope, int $limit): array
    {
        return SignalEvent::query()
            ->inScope($scope, $tenantCompanyId)
            ->where('correlation_id', $correlationId)
            ->orderBy('occurred_at')
            ->orderBy('event_id')
            ->limit($this->boundedGraphLimit($limit))
            ->cursor()
            ->all();
    }

    public function countByCorrelation(string $correlationId, ?int $tenantCompanyId, string $scope): int
    {
        return SignalEvent::query()->inScope($scope, $tenantCompanyId)->where('correlation_id', $correlationId)->count();
    }

    public function byCausation(string $causationId, ?int $tenantCompanyId, string $scope, int $limit): array
    {
        return SignalEvent::query()
            ->inScope($scope, $tenantCompanyId)
            ->where('causation_id', $causationId)
            ->orderBy('occurred_at')
            ->orderBy('event_id')
            ->limit($this->boundedGraphLimit($limit))
            ->cursor()
            ->all();
    }

    public function byRootCausation(string $rootCausationId, ?int $tenantCompanyId, string $scope, int $limit): array
    {
        return SignalEvent::query()
            ->inScope($scope, $tenantCompanyId)
            ->where('root_causation_id', $rootCausationId)
            ->orderBy('occurred_at')
            ->orderBy('event_id')
            ->limit($this->boundedGraphLimit($limit))
            ->cursor()
            ->all();
    }

    public function causalParentId(string $childEventId, ?int $tenantCompanyId, string $scope): ?string
    {
        $edge = $this->edgeQuery($scope, $tenantCompanyId)
            ->where('child_event_id', $childEventId)
            ->first();

        return $edge === null ? null : (string) $edge->parent_event_id;
    }

    public function causalChildIds(string $parentEventId, ?int $tenantCompanyId, string $scope, int $limit): array
    {
        return $this->edgeQuery($scope, $tenantCompanyId)
            ->where('parent_event_id', $parentEventId)
            ->orderBy('id')
            ->limit($this->boundedGraphLimit($limit))
            ->pluck('child_event_id')
            ->map(static fn ($id): string => (string) $id)
            ->all();
    }

    public function causalEdgesByTrace(string $traceId, ?int $tenantCompanyId, string $scope, int $limit): array
    {
        return $this->edgeQuery($scope, $tenantCompanyId)
            ->where('trace_id', $traceId)
            ->orderBy('id')
            ->limit($this->boundedGraphLimit($limit))
            ->cursor()
            ->map(static fn ($row): array => [
                'parent_event_id' => (string) $row->parent_event_id,
                'child_event_id' => (string) $row->child_event_id,
            ])
            ->all();
    }

    public function causalEdgesByCorrelation(string $correlationId, ?int $tenantCompanyId, string $scope, int $limit): array
    {
        return $this->edgeQuery($scope, $tenantCompanyId)
            ->where('correlation_id', $correlationId)
            ->orderBy('id')
            ->limit($this->boundedGraphLimit($limit))
            ->cursor()
            ->map(static fn ($row): array => [
                'parent_event_id' => (string) $row->parent_event_id,
                'child_event_id' => (string) $row->child_event_id,
            ])
            ->all();
    }

    private function edgeQuery(string $scope, ?int $tenantCompanyId)
    {
        $query = SignalCausalEdge::query()->where('scope', $scope);
        if ($scope === SignalEnvelope::SCOPE_TENANT) {
            if ($tenantCompanyId === null || $tenantCompanyId < 1) {
                throw new RuntimeException('tenant_company_id is required for tenant causal-edge queries.');
            }
            return $query->where('tenant_company_id', $tenantCompanyId);
        }
        if ($scope !== SignalEnvelope::SCOPE_SYSTEM) {
            throw new RuntimeException('Signal causal-edge scope must be tenant or system.');
        }
        return $query->whereNull('tenant_company_id');
    }

    private function assertCausalBoundary(SignalEnvelope $signal): void
    {
        $this->assertNoCausalCycle($signal);

        if ($signal->causationId !== null) {
            /** @var SignalEvent|null $parent */
            $parent = SignalEvent::query()->where('event_id', $signal->causationId)->first();
            if ($parent !== null) {
                $this->assertCausalRelationship($parent, $signal);
            }
        }

        // Offline synchronization can deliver children before parents. When the
        // parent eventually arrives, validate every waiting child before accepting it.
        $waitingQuery = SignalEvent::query()->where('causation_id', $signal->eventId);
        $waitingCount = (clone $waitingQuery)->count();
        $waitingLimit = $this->boundedGraphLimit($waitingCount === 0 ? 1 : $waitingCount);
        if ($waitingCount > $waitingLimit) {
            throw new RuntimeException('Signal parent has more waiting causal children than the configured graph safety limit.');
        }
        foreach ($waitingQuery->orderBy('id')->limit($waitingLimit)->cursor() as $child) {
            if ((string) $child->scope !== $signal->scope
                || (int) ($child->tenant_company_id ?? 0) !== (int) ($signal->tenantCompanyId ?? 0)
                || (string) $child->trace_id !== $signal->traceId
                || (string) $child->correlation_id !== $signal->correlationId
                || (string) $child->root_causation_id !== $signal->rootCausationId) {
                throw new RuntimeException('Signal parent would complete an invalid cross-boundary causal relationship.');
            }
        }
    }

    private function assertNoCausalCycle(SignalEnvelope $signal): void
    {
        if ($signal->causationId === null) {
            return;
        }

        $currentId = $signal->causationId;
        $seen = [$signal->eventId => true];
        $maxDepth = function_exists('config') ? (int) config('titan-signal-engine.max_causal_depth', 256) : 256;
        $maxDepth = max(1, min($maxDepth, 4096));

        for ($depth = 0; $depth < $maxDepth && $currentId !== null; $depth++) {
            if (isset($seen[$currentId])) {
                throw new RuntimeException('Signal causation would create a causal cycle.');
            }
            $seen[$currentId] = true;

            /** @var SignalEvent|null $parent */
            $parent = SignalEvent::query()->where('event_id', $currentId)->first();
            if ($parent === null) {
                return;
            }
            $currentId = $parent->causation_id === null ? null : (string) $parent->causation_id;
        }

        if ($currentId !== null) {
            throw new RuntimeException('Signal causal chain exceeded the configured maximum depth.');
        }
    }

    private function assertCausalRelationship(SignalEvent $parent, SignalEnvelope $child): void
    {
        $expectedRoot = (string) ($parent->root_causation_id ?: $parent->event_id);
        if ((string) $parent->scope !== $child->scope
            || (int) ($parent->tenant_company_id ?? 0) !== (int) ($child->tenantCompanyId ?? 0)) {
            throw new RuntimeException('Signal causation cannot cross tenant/scope boundaries.');
        }
        if ((string) $parent->trace_id !== $child->traceId || (string) $parent->correlation_id !== $child->correlationId) {
            throw new RuntimeException('Signal causation cannot cross trace/correlation boundaries.');
        }
        if ($expectedRoot !== $child->rootCausationId) {
            throw new RuntimeException('Signal root causation does not match the parent causal chain.');
        }
    }

    private function deduplicationKey(SignalEnvelope $signal): ?string
    {
        if ($signal->idempotencyKey === null) {
            return null;
        }

        return hash('sha256', implode('|', [
            $signal->scope,
            (string) ($signal->tenantCompanyId ?? 'system'),
            $signal->source,
            $signal->idempotencyKey,
        ]));
    }

    private function idempotencyExpiry(): DateTimeImmutable
    {
        $ttlSeconds = function_exists('config') ? (int) config('titan-signal-engine.idempotency_ttl_seconds', 86400) : 86400;
        $ttlSeconds = max(60, $ttlSeconds);

        return (new DateTimeImmutable('now', new DateTimeZone('UTC')))->modify("+{$ttlSeconds} seconds");
    }

    private function isExpired(mixed $expiresAt): bool
    {
        if ($expiresAt === null) {
            return true;
        }
        $expiry = $expiresAt instanceof \DateTimeInterface
            ? new DateTimeImmutable($expiresAt->format(DATE_ATOM))
            : new DateTimeImmutable((string) $expiresAt, new DateTimeZone('UTC'));

        return $expiry <= new DateTimeImmutable('now', new DateTimeZone('UTC'));
    }

    private function assertSameOwnership(SignalEvent $existing, SignalEnvelope $signal): void
    {
        if ((string) $existing->scope !== $signal->scope
            || (int) ($existing->tenant_company_id ?? 0) !== (int) ($signal->tenantCompanyId ?? 0)
            || (string) $existing->source !== $signal->source) {
            throw new RuntimeException('Signal idempotency collision crossed an ownership/source boundary.');
        }
    }

    private function assertSameEventIdentity(SignalEvent $existing, SignalEnvelope $signal): void
    {
        if ((string) ($existing->checksum ?? '') !== $signal->checksum) {
            throw new RuntimeException('Signal event_id was reused with different immutable content.');
        }
    }

    private function boundedLimit(int $limit): int
    {
        $max = function_exists('config') ? (int) config('titan-signal-engine.max_query_limit', 1000) : 1000;
        return max(1, min($limit, max(1, $max)));
    }

    private function boundedGraphLimit(int $limit): int
    {
        $max = function_exists('config') ? (int) config('titan-signal-engine.max_graph_query_limit', 5000) : 5000;
        return max(1, min($limit, max(1, $max)));
    }
}
