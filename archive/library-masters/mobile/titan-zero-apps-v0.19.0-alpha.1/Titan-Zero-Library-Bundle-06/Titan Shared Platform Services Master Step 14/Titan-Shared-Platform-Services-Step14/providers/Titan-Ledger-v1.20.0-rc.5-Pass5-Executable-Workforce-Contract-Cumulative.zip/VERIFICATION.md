# Titan Ledger Cumulative Verification — through New Plan Step 3

Pass 7 requires all Pass 1-6 cumulative gates plus:

- governance evidence privacy/decision normalization test;
- Risk -> Assurance ordering and fail-closed behavior test;
- Rewind projector privacy/integrity test;
- Pass 7 source/integration contract test;
- 10-user / 7-Super-Admin navigation contract;
- full PHP lint and JSON parse;
- exact extension/inventory SHA-256 sets;
- flat ZIP safety, CRC and fresh-extraction rerun.

Live host certification remains required for actual MySQL migration/trigger execution and real Titan Risk, Assurance, Command Bus, Signal and Rewind integration.

Working-tree release inventory before hash freeze: 111 regular files, 95 PHP, 7 JSON, 8 migrations.

## Pass 8
- CRM invoice fact arithmetic and revenue-split validation.
- Invoice and credit-note double-entry mapping.
- Command/Signal registry expansion to 18 governed mutations/events.
- No direct CRM invoice/payment/refund table reads in BookkeepingReportService.
- CRM invoice accounting port binding, immutable posting-evidence migration and navigation routes.
- Full cumulative Pass 1–8 regression, lint, JSON, integrity and exact-ZIP fresh-extraction gate.

## Pass 9

Run:

- `php tests/TitanPaySettlementFactTest.php`
- `php tests/TitanPaySettlementJournalMapperTest.php`
- `php tests/Pass9SourceContractTest.php`
- `php bin/verify-pass9.php`

Pass 9 also requires exact final-ZIP PHP lint, JSON parse, integrity inventory, path/case/duplicate/junk checks and CRC verification. Live host certification remains separate.

## Pass 10

Run:

- `php tests/ReceivableBalanceCalculatorTest.php`
- `php tests/ReceivableAgingPolicyTest.php`
- `php tests/ReceivableCollectionPolicyTest.php`
- `php tests/Pass10SourceContractTest.php`
- `php bin/verify-pass10.php`
- `php bin/verify-pass11.php`

Pass 10 requires 22 governed commands/events, 13 user and 10 Super Admin menu children, no invented due dates, immutable collection events, exact source inventory and fresh final-ZIP extraction verification. Live-host certification remains separate.


## Pass 11 release gate

Pass 11 requires 26 governed commands/events, 14 user and 11 Super Admin menu children, integer-minor-unit supplier/spend facts, balanced AP/GST/funding journals, immutable spend evidence, company-scoped payables projections, no direct external spend-table reads, exact source integrity and fresh final-ZIP verification. Live-host certification remains separate.

## Pass 12 release gate

Run `php bin/verify-pass12.php`. Pass 12 requires 30 governed commands/events, 15 user and 12 Super Admin menu children, signed-integer bank statement arithmetic, privacy-bounded reference hashing, deterministic exact-amount/date matching, ambiguous/unmatched preservation, immutable match history, evidence-only statement import, and close-time Ledger opening/closing bank-balance proof. Exact source integrity and a fresh extraction of the final ZIP must pass; live-host MySQL/Command Bus/bank-feed certification remains separate.


## Pass 13 release gate

Current frozen source counts before archive packaging: **164 PHP files**, **13 JSON files**, **185 exact inventory entries** (FILE-SHA256 excludes itself). Run `php bin/verify-pass13.php`. Pass 13 requires 33 governed commands/events, 16 user and 13 Super Admin menu children, canonical Australian GST treatments, Simpler BAS G1/1A/1B calculation, AUD-only source evidence, accrual-basis finalization, negative-label review gating, immutable finalized snapshots, non-destructive supersession, a read-only GST tax-ledger binding, and no ATO lodgement/network authority. Exact source integrity and fresh extraction of the final ZIP must pass; live-host MySQL/Command Bus/tax-professional certification remains separate.


## Pass 14 release gate

Run `php bin/verify-pass14.php`. Pass 14 requires 36 governed commands/events, 17 user and 14 Super Admin menu children, posted-journal-only financial statements, explicit Trial Balance/Balance Sheet integrity, retained-earnings roll-forward, previous-period/prior-year comparatives, bounded account drill-down, account-classification-aware source fingerprints, immutable versioned report snapshots, and fail-closed finalization when report evidence is unbalanced or incomplete. Exact source integrity and a fresh extraction of the final ZIP must pass; live-host MySQL/Command Bus/financial-controller certification remains separate.


## Pass 15 release gate

Run `php bin/verify-pass15.php`. Pass 15 requires 39 governed commands/events, 18 user and 15 Super Admin menu children, posted-journal cashflow, Ledger-owned AR/AP due-date forecasting, explicit evidence coverage rather than invented payment probability, burn-based runway evidence, posted-journal profitability, forecast-vs-actual variance, immutable forecast snapshots, read-only advisory integration, and zero forecast-to-journal mutation authority. Exact integrity and a fresh extraction of the final ZIP must pass; live-host MySQL/Command Bus/Risk/Assurance and production-volume forecast certification remain separate.


### Pass 15 frozen source counts

Before final archive packaging: **195 PHP files**, **15 JSON files**, **219 regular files total**, with **218 FILE-SHA256 inventory entries** and **217 extension integrity entries** expected under the exact self-reference exclusions.

## v1.16.0-rc.1 production hardening verification
Static/fresh-ZIP verification covers migration rollback retention, 41-trigger catalog completeness, gateway readiness validation, canonical `company_id` runtime boundary, no provider-private finance table reads, non-GET mutation routes, Command Bus/forecast authority isolation, Production Certification route/menu/command wiring, PHP lint, JSON parse, exact SHA inventory and ZIP safety. The package also contains a live-host certification command that queries MySQL `information_schema.TRIGGERS` and Laravel route/container state. This build environment does not contain the user's real Laravel/MySQL host, so host certification must be executed after installation; the command fails closed until all required live checks pass.

`HOST_CERTIFICATION_GATE.json` is intentionally shipped with `status=NOT_EXECUTED` and `host_certified=false`. It must remain that way in this build artifact because no real Titan Laravel/MySQL host was available here. After installation, the generated host report from `titan-ledger:production-certify --repair` is the only evidence that may set live-host certification to PASS.


## New-plan Step 2 release gate — v1.17.0-rc.2

Run `php bin/verify-step2.php`. Step 2 requires: exact retained-earnings close arithmetic for profit and loss, fiscal close checklist fail-closed rules, immutable/versioned close evidence, append-only reopen evidence, historical P&L continuity, 40 governed commands, 40 Signal mappings, 19 user and 17 Super Admin menu children, and 45 production MySQL trigger definitions. All historical Pass 1–15 and Step 1 production-hardening regressions must remain green. Exact integrity and a fresh extraction of the final ZIP must pass.

The shipped `HOST_CERTIFICATION_GATE.json` remains `NOT_EXECUTED`/`host_certified=false` because this build environment does not contain the real Titan Laravel/MySQL host. Static/fresh-ZIP PASS must not be presented as live-host PASS.

## New Plan Step 3

- Installer 1.7.6 dependency-manifest contract test.
- Advanced GST adjustment calculator and policy tests.
- Full-BAS G1/G2/G3/G10/G11/1A/1B completeness and review gates.
- Bad-debt and mixed-acquisition GST adjustment behavior.
- Pending accountant review blocks finalization.
- Three new governed commands and three new Signal mappings (43 total each).
- Production trigger catalogue expanded to 51.
- 20 user / 18 Super Admin navigation contract.
- Full cumulative Step 1-2 + historical Pass 1-15 regression, PHP lint, JSON parse, exact integrity and fresh-ZIP extraction verification.

## Step 3 release gate — v1.18.0-rc.3

- Parent: `v1.17.0-rc.2`, SHA-256 `adccab3966a416af8633a4f11bd3200f523e0693543f2c172f558ab90456b73c`.
- Installer 1.7.6 manifest regression: PASS.
- Standalone tests: 68/68 PASS.
- PHP lint: 226/226 PASS.
- JSON parse: 19/19 PASS.
- Governed Command Bus definitions: 43.
- Signal mappings: 43.
- Production MySQL trigger catalogue: 51.
- Navigation: 20 user + 18 Super Admin children.
- Source tree regular files before exact integrity freeze: 254.
- Files changed vs Step 2 parent: 48 (10 added, 38 modified, 0 deleted).
- Live host migration/Installer retry remains a separate gate; this package fixes the reported validating-stage dependency-schema failure in code and includes a permanent regression test.


## New-plan Step 4 release gate — v1.19.0-rc.4

Run `php bin/verify-step4.php`. Step 4 requires Installer 1.7.6 dependency compatibility, multi-account banking fact validation, balanced transfer/clearing/card-payment journals, clearing-balance protection, Titan Pay funds-account continuity, registered-bank cashflow, credit-card reconciliation, 47 Command Bus definitions, 47 Signal mappings, 21 user and 19 Super Admin menu children, and 55 production MySQL trigger definitions. Actual cashflow must net per journal so internal bank transfers do not inflate gross cash movement.

All historical Pass 1–15 and Steps 1–3 regressions, PHP lint, JSON parsing, exact integrity, extraction contract and ZIP safety must pass. The shipped `HOST_CERTIFICATION_GATE.json` remains `NOT_EXECUTED`/`host_certified=false` until the real Laravel/MySQL host runs production certification.

### Step 4 frozen source counts

Before final archive packaging: **239 PHP files**, **20 JSON files**, **268 regular files total**, with **267 FILE-SHA256 inventory entries** and **266 extension integrity entries**. Step 4 changes **55 files** versus the Step 3 parent (14 added, 41 modified, 0 deleted).


## New-plan Step 5 release gate — v1.20.0-rc.5

Run `php bin/verify-step5.php`. Step 5 requires Installer 1.7.6 manifest compatibility, deterministic advanced matching, duplicate-statement policy, bounded reconciliation adjustment journals, migration/source contracts, 50 Command Bus definitions, 50 Signal mappings, 22 user and 20 Super Admin menu children, and 63 production MySQL trigger definitions. Statement import must remain evidence-only and many-to-many matching must fail closed.

The final archive must be freshly extracted and rerun through `bin/verify-step5.php`, all standalone tests, PHP lint, JSON parse, exact integrity, CRC and archive path/duplicate/case/symlink/wrapper/junk checks before release.


### Step 5 frozen source counts

Before final archive packaging: **251 PHP files**, **21 JSON files**, **281 regular files total**, with an expected **280 FILE-SHA256 inventory entries** and **279 extension integrity entries** after integrity regeneration. Step 5 changes **51 files** versus the Step 4 parent (13 added, 38 modified, 0 deleted). Standalone regression: **76/76 test files PASS** before freeze.
