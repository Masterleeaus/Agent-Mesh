# Architecture

Titan AI Core is the canonical `orchestration-planning` owner. Pass 2 established typed, non-executable plan contracts. Pass 3 adds the trusted security context that every future plan must carry.

```text
Authenticated host principal
        ↓
HostTrustedPrincipalResolver
        ↓
TrustedPrincipal
        ↓
TrustedContextFactory
        ↓
RuntimeContext
 ├─ tenant_company_id
 ├─ trusted ActorContext
 ├─ AuthorityContext
 ├─ causal identifiers
 └─ idempotency key
        ↓
PlanEnvelope
        ↓
PlanValidator security gate
        ↓
DAG validation (Pass 5; still disabled)
```

Risk, Assurance, Autonomy, Command Bus, Workforce, Model Council, Signal, Rewind, Wisdom and Knowledge remain external authorities. Core does not gain their authority merely because it coordinates them.
