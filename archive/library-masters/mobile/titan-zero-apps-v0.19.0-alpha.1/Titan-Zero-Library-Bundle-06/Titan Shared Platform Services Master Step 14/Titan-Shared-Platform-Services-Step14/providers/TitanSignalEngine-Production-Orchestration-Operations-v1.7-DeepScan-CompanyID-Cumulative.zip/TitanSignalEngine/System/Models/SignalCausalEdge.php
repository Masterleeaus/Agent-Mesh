<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalCausalEdge extends Model
{
    protected $table = 'titan_signal_causal_edges';
    protected $guarded = [];
    public $timestamps = true;

    protected $casts = [
        'tenant_company_id' => 'integer',
    ];
}
