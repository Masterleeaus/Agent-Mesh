<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects;

use InvalidArgumentException;

/**
 * Read authority context produced by a trusted host resolver.
 *
 * Public catalog APIs intentionally do not accept tenant identifiers. The
 * resolver constructs this context from host-authenticated state instead.
 */
final readonly class KnowledgeAccessContext
{
    /** @var list<string> */
    public array $jurisdictionCodes;

    /**
     * @param list<string> $jurisdictionCodes
     */
    private function __construct(
        public ?int $tenantCompanyId,
        array $jurisdictionCodes,
    ) {
        if ($tenantCompanyId !== null && $tenantCompanyId <= 0) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer when present.');
        }

        $normalized = [];
        foreach ($jurisdictionCodes as $code) {
            $code = self::normalizeJurisdictionCode($code);
            if ($code === '') {
                throw new InvalidArgumentException('Jurisdiction codes must not be empty.');
            }
            $normalized[$code] = true;
        }

        $this->jurisdictionCodes = array_keys($normalized);
    }

    /**
     * This factory is reserved for trusted host context resolvers and tests.
     * Request/query/body tenant identifiers must never be passed here.
     *
     * @param list<string> $jurisdictionCodes
     */
    public static function trusted(?int $tenantCompanyId, array $jurisdictionCodes = []): self
    {
        return new self($tenantCompanyId, $jurisdictionCodes);
    }

    public function allowsTenant(int $tenantCompanyId): bool
    {
        return $this->tenantCompanyId !== null && $this->tenantCompanyId === $tenantCompanyId;
    }

    public function allowsJurisdiction(string $code): bool
    {
        return in_array(self::normalizeJurisdictionCode($code), $this->jurisdictionCodes, true);
    }

    /** @return list<string> */
    public function jurisdictions(): array
    {
        return $this->jurisdictionCodes;
    }

    private static function normalizeJurisdictionCode(string $code): string
    {
        return strtoupper(trim($code));
    }
}
