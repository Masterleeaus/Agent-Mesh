# 2.0.5 — Agent-01 Pass 3

- Added canonical cross-extension execution envelope, correlation/causation, idempotency scope, authority/provenance/evidence traceability, duplicate suppression and deferred unknown-outcome semantics.

# Titan Maps Intelligence Changelog

## 2.0.2 — Installer 1.7.3/MySQL compatibility hotfix

- Short explicit indexes for route optimisation proposal storage.
- Create-or-repair recovery for the partial table left by failed MySQL DDL.
- Package-wide MySQL 64-character identifier regression gate.

## 2.0.1 — Post-production deep-scan hotfix

- Unified delayed-GPS idempotency and persisted live/historical/debounced replay classification.
- Prevented historical/debounced offline samples from generating retroactive geofence transitions.
- Enforced current tracking consent, on-duty state, freshness and history-sharing across all worker-location surfaces.
- Replaced `Gate::has()` visibility widening with current-user authorization.
- Made unregistered consequential permission gates fail closed.
- Scheduled worker-location retention pruning hourly.
- Added explicit offline privacy provenance columns and a dedicated post-production regression gate.

## 2.0.0-beta.1.13 — Joint Pass 15: Titan Field Route Optimisation Proposals

- Added immutable `maps_field_route_optimisation_proposals` evidence store (39th owned table; 53rd migration).
- Added `FieldRouteOptimizationProposalService` over the existing travel-matrix and route-plan optimiser runtime.
- Added optional Field peer method returning explainable baseline/proposed order, savings, schedule/window evidence, constraints, provenance, warnings and expiry.
- Preserved proposal-only authority: Maps never applies Field route mutations.
- Updated schema/release verifiers for the new retained proposal table and current Laravel column primitives.

## 2.0.0-beta.1.12 — Joint Pass 14: Offline Worker Location Sync

- Added bounded delayed-GPS replay through `OfflineWorkerLocationSyncService` and the Field spatial peer.
- Added `client_sample_id`, device-hash, offline-sync and per-sample retention provenance to location pings.
- Fresh monotonic replay uses the normal tracking/geofence path; stale replay is historical-only and cannot overwrite live position or create retroactive geofence transitions.
- Revalidates current tracking consent, on-duty state, sample capture time, coordinate bounds, GPS accuracy, future skew and offline age.
- Added `/worker-tracking/offline-sync` and `worker.location.offline-sync` capability metadata.
- Extended the location-retention pruner to honour explicit per-sample retention expiry.

# Changelog

## 2.0.0-beta.1.11 — Joint Pass 13: Field Capacity Pressure Evidence

- Extended `FieldSpatialPeerGateway` with read-only `capacityPressureEvidence`.
- Uses the existing nearest-resource/travel-matrix pipeline to estimate nearest on-duty worker travel pressure for bounded Field demand points.
- Returns freshness, distance/time, uncovered-demand and existing territory-evaluation evidence.
- Labels `capacity_adjustment_seconds` as a one-way nearest-worker proxy rather than a future route commitment.
- Performs no Titan Field operational writes and remains independently bootable when Field is absent.

## 2.0.0-beta.1.10 — Joint Pass 12: Field Spatial Cost Evidence

- Extended `FieldSpatialPeerGateway` with tenant-verified read-only `workOrderCostEvidence`.
- Returns latest persisted route/ETA distance/time evidence and territory evaluation evidence for a Field work order.
- Exposes persisted geographic pricing signals only as advisory, non-authoritative evidence.
- Explicitly marks the peer payload as non-financial authority and performs no Field financial writes.
- Updated cumulative release verifiers to accept beta.1.9-or-later while requiring root/sidecar version equality.

## 2.0.0-beta.1.9 — Joint Pass 11: Titan Field Peer Bridge

- Added bounded `FieldSpatialPeerGateway` for live worker position, route/ETA evidence, location ingestion and map payload/UI consumption by Titan Field.
- Added preferred Titan Field reference, dispatch-evidence, worker-qualification and governed assignment adapters while preserving standalone WorkCore/CRM fallbacks.
- Field dispatch assignment proposals now enter Titan Field through its governed command gateway instead of Maps writing operational tables.
- Field-team map payloads expose the existing live-refresh endpoint to embedded peer surfaces.
- Preserved Maps ownership of high-frequency GPS history, retention, freshness, confidence, geofencing and routing.
- No hard dependency on Titan Field was introduced; peer discovery is runtime/string based.

## 2.0.0-beta.1.8 — Blade Compiler Compatibility Hotfix

- Fixed the live `navigation.blade.php` parse failure (`syntax error, unexpected token "class"`) caused by inline Blade `@php(...)` compilation under the Titan Zero Livewire/Blade stack.
- Replaced inline `@php(...)` directives with explicit `@php ... @endphp` blocks in both `resources/views/user/navigation.blade.php` and `resources/views/components/candidate-card.blade.php`.
- Added `scripts/test_blade_inline_php_compatibility_runtime.php` to reject this compiler-sensitive pattern across every shipped Blade view.
- Cache-busted Maps user assets to beta.1.8.
- Preserved all beta.1.7 distinct workspaces, navigation, routes, schema, permissions and capabilities.



## 2.0.0-beta.1.7 — Distinct Navigation Workspaces Hotfix

- Fixed 35 shared-controller user menu pages that were routed distinctly but visually collapsed into the same global KPI/map/generic-record shell.
- Added an explicit workspace contract for every shared Maps page and retained Resource Fallback as its dedicated controller/view.
- KPI cards now show page-relevant metrics instead of the same global 13 metrics everywhere.
- Replaced the generic four-column `Recent records` fallback with page-specific record tables and empty states for field, discovery, territory, travel and settings workflows.
- Added focused parent-workspace quick links and runtime configuration facts.
- Differentiated Business Discovery and Nearby Services search composition.
- Added `scripts/test_navigation_page_distinction_runtime.php` covering the full shared user navigation surface.
- No schema, migration, named-route, permission, capability or menu-key changes.

## 2.0.0-beta.1.6 — Host-theme Readable KPI Card Hotfix

- Fixed dark-theme KPI labels that could render too close to the card background by using the host body text colour with controlled opacity.
- Removed the six-colour per-card accent rotation; Maps KPI values and rails now follow the active Titan/Tabler primary theme colour.
- Reduced decorative tint strength while retaining host card surfaces, borders, responsive wrapping and consistent card heights.
- Cache-busted shared Maps CSS to beta.1.6 and added readability/theme regression coverage.
- No database, route, permission, capability or navigation changes.

## 2.0.0-beta.1.5 — Theme-aware Maps KPI Card Hotfix

- Converted the shared Maps KPI metrics from generic host cards into dedicated `titan-maps-kpi-card` components.
- Added host-theme-driven card surfaces, borders, accent rails, value colours and subtle tinted backgrounds using Titan/Tabler CSS variables.
- Added deterministic theme accent rotation across primary, info, success, warning, danger and purple with safe primary fallbacks.
- Made the Maps stylesheet load on every shared Maps navigation page so KPI card styling is not conditional on graphical map payload availability.
- Preserved the beta.1.4 responsive grid (`col-6 col-md-4 col-lg-3 col-xxl-2`) and moved wrapping behavior out of inline markup into component CSS.
- Added a theme-card runtime regression test and cache-busted Maps assets to beta.1.5.
- No schema, route, capability, permission or menu changes.

## 2.0.0-beta.1.4 — Responsive Maps KPI Layout Hotfix

- Fixed the shared Maps KPI grid that rendered 13 `col-lg` auto-width cards in one row and compressed labels to one-character-wide columns on tablet/desktop layouts.
- KPI cards now use explicit responsive widths: 2 per row on small screens, 3 on medium, 4 on large and up to 6 on very large screens.
- Added normal word-wrapping guards and stable KPI regression-test hooks.
- Cache-busted existing Maps JS/CSS asset URLs to the beta.1.4 release identifier.
- Added a package regression test that rejects recurrence of the auto-width `col-lg` KPI layout.
- No schema, route, capability, permission or menu changes.

## 2.0.0-beta.1.3 — MySQL Required Timestamp Compatibility Hotfix

- Fixes installer SQLSTATE `[42000]` / MySQL error `1067 Invalid default value for 'received_at'` in `maps_location_pings`.
- Converts all 15 required application-supplied event timestamps from bare `TIMESTAMP` columns to non-null `DATETIME` columns, avoiding MySQL legacy implicit timestamp defaults while preserving required-value semantics.
- Leaves 53 nullable timestamp declarations and Laravel `created_at` / `updated_at` behavior unchanged.
- Extends migration verification to reject future required bare `timestamp()` declarations unless they explicitly declare a safe default policy.
- Preserves the beta.1.2 guarded `titan.company` stale-route compatibility alias and all existing Maps functionality.

## 2.0.0-beta.1.2 — Route-Cache Company Middleware Compatibility Hotfix

- Keeps all new Maps user/API routes on extension-owned `titan.maps.company`.
- Adds a guarded compatibility registration for legacy `titan.company` only when the host has not already registered that alias.
- Allows Laravel route caches created from beta.1 to resolve their stale middleware name after the extension is upgraded.
- Never overwrites a host-owned `titan.company` alias.
- Adds regression coverage for stale-route-cache compatibility; no schema or menu migration is introduced.

## 2.0.0-beta.1.1 — Host Company Middleware Hotfix

- Removed the hard dependency on the nonexistent global `titan.company` middleware alias.
- Added extension-owned `titan.maps.company` middleware that resolves and stamps trusted company context before company-scoped route binding.
- Extended the fallback company resolver to understand `tenant_company_id`, `active_company_id`, trusted CRM request context, and the optional CRM company scope when available.
- Rejects client-supplied `tenant_company_id` alongside `company_id` / `tenant_id`.
- Preserves all beta.1 tenant isolation, permissions, governance, route binding and installer behavior.

## 2.0.0-beta.1 — Safety, Cost, Privacy and Scalability Hardening

- Added tenant/provider daily/monthly quota circuit breaker with soft-limit fallback, hard-limit 429 denial, Governance Signal and governed override.
- Added provider health tracking plus primary/secondary Vault-reference credential failover.
- Added scheduled server-side geofence reconciliation, per-geofence hysteresis/sample settings and accuracy-derived event confidence.
- Hardened worker privacy with stale-current filtering, history sharing windows, device throttling, GPS anomaly investigation and 7/90/2555-day retention policies.
- Added tenant/vertical dispatch scoring policies, temporal/fatigue/familiarity inputs and mandatory-certification unknown blocking.
- Added deterministic territory tie-breaking, boundary semantics, conflict Signals and matched rule chains.
- Added ETA valid-until semantics, stale recommendation suppression, route-history filtering and bounded exact/heuristic route optimisation.
- Queued territory analytics and reuse fresh persisted snapshots for 24 hours.
- Added geocode retry/backoff state, normalized address fingerprinting, confidence and geocoder-version provenance.
- Added fallback review deadlines/escalation and promotion approval lineage.
- Added Redis-preferred short idempotency cache with fallback Signal for territory validation/service-area checks.
- Added `maps.quota.status`, `maps.provider.quota.override`, `maps.provider.health`, `maps.dispatch.weights.read` and `maps.dispatch.weights.update`; capability total is 44.
- Preserved `titan-extension-v1` installer compatibility and all alpha.17 capabilities/routes/UI.

## 2.0.0-alpha.17 — Pass 17 Governed Spatial Intelligence Integration

- Added eight canonical Titan spatial capabilities: `location.geocode`, `territory.lookup`, `territory.validate`, `route.estimate`, `route.compare`, `job.travel_context`, `service_area.check`, and `nearby.search`, while preserving all 31 legacy capability IDs.
- Added a single capability-policy catalog declaring owner, risk, autonomy, evidence, offline policy, reversibility, idempotency and mutation class for all 39 capabilities.
- Added server-derived spatial execution context and structured governance receipts carrying trace/correlation/causation/tenant references without hidden chain-of-thought.
- Added optional, host-portable adapters for Titan Risk, Assurance, Autonomy, Command Bus, Signal, Rewind and Knowledge Authority; missing engines never fabricate approval and do not break extension installation.
- Added Titan Go offline capability manifest with authority-reducing `OFFLINE_EXECUTE`, `OFFLINE_PREPARE_ONLY` and `OFFLINE_BLOCKED` policy metadata.
- Added canonical structured Signal publication for capability execution/denial/failure, route failures/fallbacks, territory conflicts/exclusions and worker GPS anomalies/acceptance.
- Moved authoritative CRM job assignment behind the Command Bus gateway and governed AI-originated candidate/resource promotion and consequential Maps-owned decisions.
- Added `job.travel_context` to combine authorised job reference, canonical map projection, territory/travel evidence and optional jurisdictional Knowledge Authority references without copying CRM truth.
- No database or menu migrations were added in this integration pass.

## 2.0.0-alpha.16 — Pass 16 Governed Contractor/Supplier Resource Fallback

- Added company-scoped resource fallback requests, ranked candidate evidence and human decision lineage.
- Enforced sourcing order: internal dispatch suitability first, approved contractor/supplier network second, Maps Discovery only after both are exhausted.
- Added supplier fallback lineage for Titan Gear `inventory_shortage` needs using an explicit shortage public ID plus target coordinates.
- Added optional open-now discovery constraint and deterministic service/travel/completeness/reputation scoring with unknown evidence preserved as unknown.
- Added graphical Field Operations → Resource Fallback page with source-stage status, ranked candidate map, review controls and explicit discovery-candidate promotion.
- Reused the existing candidate review/promotion lifecycle; approved-network resources are never re-promoted and no fallback candidate is auto-assigned.
- Added structured audit records linking operational need → internal/network checks → discovery search → human decision → promotion result.
- Added four governed Titan AI capabilities for fallback start/read/decide/promote; AI decision and promotion operations require `confirmed=true`.
- Added 3 owned schema tables and one idempotent menu-sync migration.

## 2.0.0-alpha.15 — Pass 15 Real Territory Analytics

- Replaced generic territory analysis with six distinct methodology engines: provider coverage, competitor density, supplier travel-time access, service gaps, branch coverage and expansion opportunity.
- Added deterministic geographic-cell generation with explicit square-kilometre area denominators and persisted per-cell evidence.
- Added competitor density as competitor count divided by explicit analysed area rather than a generic count score.
- Added supplier access bands based on provider/stale matrix ETA with an explicit unavailable band; straight-line fallback never invents supplier travel time.
- Added service-gap scoring from observed job concentration plus provider/internal coverage; when no canonical job demand evidence exists, demand remains unavailable.
- Added expansion opportunity scoring with configurable evidence weights and evidence-completeness reduction when inputs are missing.
- Added Branch Coverage and Expansion Opportunities pages plus graphical persisted cell overlays.
- Persisted methodology key/version, analysed area, input summary, findings and per-cell evidence for reproducible audits.
- Added two governed AI capabilities for running and reading territory analytics.
- Added one owned evidence table, one guarded additive migration and one idempotent navigation-sync migration.

## 2.0.0-alpha.14 — Pass 14 Service Territories and Geographic Pricing Signals

- Added company-scoped service territories, territory evaluations and geographic pricing-signal persistence.
- Added graphical circle/polygon service areas plus exact postcode/suburb territory rules.
- Added include/exclude effects and deterministic priority ordering; any matching exclusion blocks normal coverage.
- Added branch-centred road-distance and drive-time travel zones backed by durable routing provenance; straight-line fallback never qualifies a travel band.
- Added advisory fixed/percentage pricing hints stored only as non-authoritative, not-applied signals.
- Added `GeographicPricingSignalProvider` so CRM/quoting can consume coverage/travel/pricing evidence without Maps mutating final prices.
- Added Territories and Coverage → Service Areas, Travel Zones and Geographic Pricing with graphical evaluation evidence.
- Added four governed Titan AI capabilities for territory manage/read/evaluate and geographic-pricing read.
- Added 3 owned schema tables and one idempotent navigation-sync migration.

## 2.0.0-alpha.13 — Pass 13 Explainable Dispatch Intelligence

- Added deterministic explainable dispatch scoring across travel, skill/experience, availability, workload, territory, customer continuity and urgency.
- Added explicit hard blockers and preserved unknown qualification/certification evidence without false verification.
- Added tenant-safe recommendation, candidate evidence and append-only human decision persistence.
- Added optional tenant-verified CRM evidence and authoritative assignment adapters without hard host dependencies.
- Added Field Operations → Dispatch Intelligence with ranked graphical worker candidates and human Approve / Approve and assign / Reject controls.
- Added confirmation-gated Titan AI dispatch recommend/read/decide capabilities.
- Added 3 owned schema tables and one idempotent menu-sync migration.

## 2.0.0-alpha.12 — Pass 12 Multi-Stop Route Planning and Optimisation

- Added company-scoped route plans, stops and immutable optimisation-run revisions.
- Added depot/job/supplier/contractor/break/custom stop types, appointment windows and locked stop positions.
- Added deterministic matrix-backed sequencing with explicit window-conflict reporting and straight-line-only fallback honesty.
- Added automatic re-optimisation after emergency insertion, stop completion, cancellation and reopening.
- Added persisted before/after distance/time metrics and estimated savings with provider/stale/estimate provenance.
- Added optional road-geometry rendering through existing point-route snapshots with a configurable segment cap; otherwise the UI uses explicitly labelled sequence connectors.
- Added Travel and Routing → Route Planner, API routes and Titan AI route-plan read/manage capabilities.
- Added 3 owned tables and one idempotent navigation-sync migration.

## 2.0.0-alpha.11 — Pass 11 Travel Matrix and Nearest Resource Intelligence
- Added company-scoped `maps_travel_matrix_snapshots` and `maps_travel_matrix_elements` for durable matrix provenance and caching.
- Added fresh matrix cache reuse to reduce provider requests, quota validation before provider calls, stale-matrix fallback and straight-line-only fallback with ETA unavailable.
- Added nearest operational resource ranking for on-duty workers, suppliers and contractors using travel ETA first and distance second.
- Added Travel Matrix web/API endpoints, matrix/nearest permissions and Titan AI capabilities.
- Added graphical ranked comparison pins and explicitly non-route dashed comparison connectors.
- Added matrix history, configuration controls, quota/runtime verification and tenant-aware worker-location privacy checks.

## 2.0.0-alpha.10 — Pass 10 Durable Road Routing and ETA
- Added company-scoped `maps_route_snapshots` and `maps_eta_snapshots` with route/traffic provenance and freshness timestamps.
- Added durable `RouteCalculationService` with explicit provider-route → stale last-valid snapshot → straight-line-only fallback order.
- Straight-line fallback can never populate road distance or ETA fields.
- Added route calculate/history API endpoints, route-specific permissions, company-safe route binding, and Titan AI route capabilities.
- Added route/ETA history to Travel pages with graphical fresh/stale/estimate route rendering.
- Added configurable route freshness TTLs, last-valid maximum age, coordinate signature precision and history limits.
- Added route/ETA architecture and runtime verification plus tenant-isolation coverage.

## 2.0.0-alpha.9 — Pass 9 Native Graphical Geofencing
- Added circle and polygon geofence persistence, worker evaluation state and append-only geofence events.
- Added drag-to-radius circle drawing and click-to-polygon drawing on the graphical map engine.
- Added GPS accuracy-aware circle containment, hysteresis and configurable consecutive-sample transition filtering.
- Added entry, exit, dwell, job-arrival and job-departure event semantics.
- Job/property operational actions require explicit confirmation by default; confirmed job actions emit dedicated domain events.
- Added Geofences under Field Operations with an upgrade menu-sync migration.
- Added runtime geofence math and jitter-trace verification.

## 2.0.0-alpha.8 — Graphical Map Engine

- Added a real extension-owned interactive graphical map renderer with pan, zoom, fit, tiles, markers, popups, polylines, polygons and radius circles.
- Added graphical Live Map, Locations, Team Map, Check-ins, Location Intelligence, Territories and Travel surfaces.
- Added live Team Map refresh from the authenticated web session.
- Added worker GPS trail rendering and territory/search overlays.
- Added graphical Route Calculator backed by the provider-neutral routing service, including encoded-polyline decoding, road distance, traffic duration/delay and route line rendering.
- Added configurable tile URL/attribution/zoom settings and default OpenStreetMap interactive tiles.
- Renamed Field Operations > Overview to **Live Map** and added an upgrade menu-sync migration.
- Added graphical map architecture verification plus JS/PHP syntax gates.

# 2.0.0-alpha.7 — Live Worker Location

- Added authenticated Titan Go/PWA worker GPS ingestion.
- Added `maps_location_pings` history and `maps_worker_tracking_states` consent/duty state.
- Latest accepted GPS is projected into canonical `map_locations`.
- Added stale/future/accuracy/motion validation and anti-impersonation worker identity resolution.
- Added minimum interval + movement debounce and replay dedupe.
- Added configurable GPS retention and `titan-maps:prune-location-pings`.
- Added Team Map and Check-ins child navigation plus an upgrade menu-sync migration.
- Added worker tracking architecture, runtime, security, retention and migration tests.

# 2.0.0-alpha.6.3 — Navigation Visibility Hotfix

- Added adaptive MagicAI `menus` table synchronization so the installed extension is visible without core sidebar edits.
- Added five company parent menus with 25 working child links: Field Operations, Location Intelligence, Territories and Coverage, Travel and Routing, and Maps and Location.
- Added Titan Maps Intelligence Super Admin navigation when the host exposes `menus.is_admin`; older hosts receive a safe Settings-parent admin fallback.
- Added real named web routes and MagicAI panel-layout pages for every new menu link.
- Added host-safe menu icon sanitization and non-fatal `MenuService::regenerate()` cache refresh.
- Added upgrade migration `2026_08_10_000200_sync_titan_maps_navigation.php` so existing alpha.6.2 installations receive menus automatically.
- Added host-portable Gate behavior: registered host abilities remain authoritative; when Maps-specific Gate abilities are absent, authenticated company-scoped access is used unless `permissions.strict_host_gates` is enabled.
- Added navigation regression verification to prevent literal `/dashboard/...` menu URLs, dead named routes, unsafe icons, missing cache refresh, or missing menu migration.

# Changelog

## 2.0.0-alpha.6.2 - Provider portability hotfix

- Removed mandatory install-time dependencies on host-specific `App\Titan\Maps\*` classes.
- Added extension-local fallbacks for company context, permission authorization, environment-backed secret resolution, audit logging, capability registration, WorkCore fail-closed integration, and private exports.
- Host adapters are still preferred automatically when they exist and implement the extension contract.
- Replaced the hard `MapsExportController` route import with a conditional host/local download controller.
- Added host-portability architecture verification so missing host adapters cannot regress into provider-stage installer failures.


## 2.0.0-alpha.6.1 - Installer manifest hotfix

- Replaced the incompatible five-field primary manifest with the Titan Extension Manager 1.5.3 contract.
- `extension.json` now declares `schema: titan-extension-v1`, slug, folder, canonical provider, and migrations.
- Retained `extension.manifest.json` as the hardened architecture sidecar.
- Updated package verification/tests so this installer contract cannot regress.

## 2.0.0-alpha.6.1 — Pass 6

- Added canonical `map_locations` projection for company-scoped WorkCore job/property/branch/worker/supplier/contractor references.
- Added `FieldReferenceGateway` and WorkCore adapter with missing/deleted/inactive/foreign-company rejection.
- Added geocode-and-cache with address fingerprinting, provider provenance, source/precision and verification timestamps.
- Added optional reverse-geocode metadata without overwriting WorkCore authoritative addresses.
- Added source-aware configurable location freshness and location-domain security/architecture/runtime tests.

## 2.0.0-alpha.5 — Pass 5

- Added provider-neutral geocoding, routing and traffic contracts and registries.
- Added Google Geocoding API v4 adapter with explicit field masks and Vault credential references.
- Added Google Routes API v2 point-route and route-matrix adapter with traffic-aware/static durations.
- Added provider usage recording for new operational services and deterministic fake providers/tests.
- Expanded provider host allowlist to geocode.googleapis.com and routes.googleapis.com.
- Added matrix element-limit enforcement and duration normalization.

## 2.0.0-alpha.4 — Pass 4

- Added validated central `MapsConfiguration`.
- Ranking/matching weights and thresholds now come from configuration rather than hard-coded service constants.
- Search caps, provider page size, Google timeout/retries and algorithm distance thresholds are validated and configuration-driven.
- Added configuration-version audit metadata to searches and candidate matching.
- Added deterministic configuration behavior and wiring tests.
- Locked the proposed Field & Home navigation hierarchy for the later menu/UI pass.

## 2.0.0-alpha.3 — Pass 3

- Split Maps routes into authenticated-user dashboard, admin dashboard, authenticated API and fail-closed internal profiles.
- Added route-level permission middleware for all existing API actions and explicit `titan-maps-intelligence.admin.access` authorization for admin routes.
- Added company-safe route-model resolution for searches, candidates and territory analyses; foreign-company IDs resolve as not found.
- Added anti-spoof middleware rejecting client-supplied `company_id`/`tenant_id`.
- Made tenant ownership immutable after model creation.
- Added queue tenant execution context around both discovery queue jobs.
- Added architecture, unit and host feature security tests plus dependency-free security verification.

## 2.0.0-alpha.2 — Pass 2

- Added 12 forward-only Laravel migrations for all persistent Maps domain tables.
- Added `company_id` indexes, tenant-scoped composite relationship keys and query-specific indexes.
- Added company/provider uniqueness for provider connections and external provider-place identity.
- Wired migrations into the canonical service provider and changed the hardened sidecar to `database.migrations: true`.
- Added `database/schema-contract.json`, dependency-free migration verification and a host MySQL migration/CRUD integration test.
- Documented safe handling for pre-existing manually created Maps tables; package migrations never drop them.

## 2.0.0-alpha.1 — Pass 1

- Converted `extension.json` to the hardened blueprint five-field legacy contract.
- Added authoritative `extension.manifest.json` sidecar metadata.
- Moved the canonical provider to `System/TitanMapsIntelligenceServiceProvider.php` while retaining a legacy root provider alias.
- Added MagicAI registration key and idempotent uninstall lifecycle hooks.
- Declared the existing discovery capabilities, permissions, provider host, tenant boundary, queue use and owned data.
- Added architecture/package verification checks and release metadata.
- Preserved the existing discovery, provenance, candidate governance, exports and WorkCore adapter behavior.

### Known Pass-1 boundary

Database migrations are intentionally declared as not yet packaged. Pass 2 adds forward-only migrations for the existing Maps domain and changes the sidecar migration declaration to `true`.
## 2.0.3 — Workforce / Blueprint v4.2.1 convergence
- Canonical Manifest v2.2 metadata.
- Role-neutral Titan AI Workforce integration contract; Workforce remains identity/role/work-item owner.
- Canonical active tenancy is `company_id`; legacy tenant key limited to compatibility/migration paths.
- Governed execution, provider provenance, fail-closed availability semantics and contract regression test.
