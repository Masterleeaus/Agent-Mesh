<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

final class CannedResponse extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use HasUuids;
    use SoftDeletes;

    protected $table = 'ext_titan_connect_canned_responses';
    protected $fillable = ['uuid', 'company_id', 'owner_user_id', 'title', 'content', 'shortcut', 'is_company_shared'];
    protected $casts = ['is_company_shared' => 'boolean'];

    public function uniqueIds(): array { return ['uuid']; }
    public function getRouteKeyName(): string { return 'uuid'; }

}
