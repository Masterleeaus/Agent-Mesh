<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\OperationsQueryContract;
use Illuminate\Support\Facades\DB;

final class DatabaseOperationsQuery implements OperationsQueryContract
{
    public function receipts(int $tenantCompanyId, array $filters = [], int $limit = 100): array
    {
        $query = app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_execution_receipts')->where('tenant_company_id', $tenantCompanyId);
        if (($filters['capability'] ?? '') !== '') $query->where('capability', (string)$filters['capability']);
        if (($filters['workflow_key'] ?? '') !== '') $query->where('workflow_key', (string)$filters['workflow_key']);
        if (($filters['observation_status'] ?? '') !== '') $query->where('observation_status', (string)$filters['observation_status']);
        if (($filters['final_label'] ?? '') !== '') $query->where('final_label', (string)$filters['final_label']);
        return array_map(fn($r) => $this->normalise((array)$r), $query->orderByDesc('id')->limit(max(1, min(500, $limit)))->get()->all());
    }

    public function receipt(int $tenantCompanyId, string $correlationId): ?array
    {
        $row = app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_execution_receipts')->where('tenant_company_id', $tenantCompanyId)->where('correlation_id', trim($correlationId))->first();
        return $row ? $this->normalise((array)$row) : null;
    }

    public function feedback(int $tenantCompanyId, string $receiptPublicId, int $limit = 100): array
    {
        return array_map(fn($r) => $this->normalise((array)$r), app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_execution_feedback')
            ->where('tenant_company_id', $tenantCompanyId)->where('receipt_public_id', $receiptPublicId)
            ->orderByDesc('id')->limit(max(1, min(500, $limit)))->get()->all());
    }

    private function normalise(array $row): array
    {
        foreach ($row as $key => $value) {
            if (str_ends_with($key, '_json') && is_string($value) && $value !== '') {
                $decoded = json_decode($value, true);
                if (json_last_error() === JSON_ERROR_NONE) $row[substr($key, 0, -5)] = $decoded;
            }
        }
        return $row;
    }
}
