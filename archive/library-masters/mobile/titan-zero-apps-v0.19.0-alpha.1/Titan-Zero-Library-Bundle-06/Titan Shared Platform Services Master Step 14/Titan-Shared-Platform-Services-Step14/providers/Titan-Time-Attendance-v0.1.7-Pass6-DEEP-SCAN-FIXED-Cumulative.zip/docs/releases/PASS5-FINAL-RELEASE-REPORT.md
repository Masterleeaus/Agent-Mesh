# Titan Time & Attendance 0.1.0 — Pass 5 Final Release Report

## Scope

Pass 5 completes the five-pass module-to-extension conversion with installer 1.6.9 packaging, retained-data lifecycle hardening, leased Signal delivery, stale-worker recovery, bounded retry/dead-letter behavior and final cumulative verification.

## Final runtime hardening

- Signal outbox rows are claimed transactionally with `lockForUpdate`.
- Claims carry a unique claim token, claim time and lease expiry.
- Expired `delivering` leases are eligible for controlled recovery.
- Retry uses bounded exponential backoff.
- Rows reaching the configured attempt ceiling enter `dead_letter` rather than retrying forever.
- Stored failure diagnostics record exception class only; raw exception messages are not persisted.
- Scheduler entries use `withoutOverlapping` plus `onOneServer` for multi-node deployments.
- Stable event IDs and deduplication keys provide downstream replay identity; delivery is explicitly at-least-once rather than falsely claiming exactly-once transport.

## Installer/lifecycle hardening

- Root manifest moved to Titan Custom Extension Manager 1.6.9 `integrity.files` shape.
- Root scoped `publishes` metadata matches the provider publish tag.
- Base create migrations are retained-data reinstall-safe.
- New reversible Signal-delivery migration adds claim/lease/dead-letter state.
- Standalone release-ZIP verifier enforces flat root, POSIX paths, traversal/symlink/case checks, 250x archive expansion limit, provider identity and exact packaged-byte integrity.

## Cross-extension truth boundary

Titan Rewind remains a verified real source-adapter integration. CRM uses governed public-reference reads. Workforce definitions remain extension-owned and centrally discoverable. Current Command Bus/Governance peer builds do not expose a stable callable execution contract that this extension can safely bind automatically, so AI mutations remain fail-closed unless the host supplies the Time Command Bus port. No fake adapter was introduced to make integration appear complete.

## Data policy

Disable and uninstall are non-destructive by default. Uninstall removes only the published extension configuration; operational and audit data are retained.

## Certification boundary

This release is package/static and hostless-contract certified only. Production certification requires installation in the actual Titan/MagicAI host, real MySQL migration/rollback testing, Laravel boot/cache checks, queue-worker failure testing and live optional integration tests.

## Source-tree verification

The frozen 0.1.0 source tree passed the complete hostless release matrix before packaging:

- standalone tests: **13 / 13 PASS**
- PHP syntax: **103 / 103 PASS**
- JSON documents: **6 / 6 PASS**
- migrations with `down()`: **8 / 8**
- foreign/shared-table migration references: **0**
- MySQL explicit identifiers over 64 characters: **0**
- duplicate named PHP FQCNs: **0**
- state-changing GET-route findings: **0**
- duplicate route names: **0**
- provider identity/import-resolution errors: **0**
- dangerous legacy/debug/merge-marker hygiene findings: **0**

The exact archive is verified again after clean extraction. The external `.sha256.txt` sidecar records the final ZIP checksum so the ZIP does not contain a self-referential checksum.
