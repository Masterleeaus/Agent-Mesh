<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Extensions\TitanConnect\System\Services\ConnectionDiagnosticsService;
use App\Extensions\TitanConnect\System\View\MagicAiDashboardRenderer;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\View\View;

final class ChannelSettingsController extends Controller
{
    /** @var array<string,string> */
    private const PROVIDERS = [
        'whatsapp' => 'WhatsApp',
        'messenger' => 'Messenger',
        'instagram' => 'Instagram',
        'telegram' => 'Telegram',
        'sms' => 'SMS',
        'voice' => 'Voice',
        'push' => 'Push / Mobile',
    ];

    public function __construct(
        private readonly CompanyContext $context,
        private readonly ChannelAccessPolicy $policy,
        private readonly MagicAiDashboardRenderer $dashboard,
    ) {
    }

    public function index(Request $request): View
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $counts = [];
        foreach (array_keys(self::PROVIDERS) as $provider) {
            $counts[$provider] = ChannelConnection::query()
                ->forCompany($companyId)
                ->where('provider', $provider)
                ->whereHas('members', fn ($query) => $query
                    ->where('company_id', $companyId)
                    ->where('user_id', $actorId)
                    ->whereNull('left_at'))
                ->count();
        }

        return $this->dashboard->render('titan-connect::channels.index', [
            'providers' => self::PROVIDERS,
            'counts' => $counts,
        ], __('Channels'));
    }

    public function show(Request $request, string $provider, ConnectionDiagnosticsService $diagnostics): View
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $provider = strtolower(trim($provider));
        abort_unless(array_key_exists($provider, self::PROVIDERS), 404);

        $connections = ChannelConnection::query()
            ->forCompany($companyId)
            ->where('provider', $provider)
            ->whereHas('members', fn ($query) => $query
                ->where('company_id', $companyId)
                ->where('user_id', $actorId)
                ->whereNull('left_at'))
            ->with(['members' => fn ($query) => $query->where('company_id', $companyId)->whereNull('left_at')])
            ->orderBy('display_name')
            ->limit(5000)->get()
            ->map(fn (ChannelConnection $connection): array => [
                'connection' => $connection,
                'diagnostic' => $diagnostics->inspect($connection),
                'can_manage' => $this->policy->canManage($connection, $actorId),
            ])
            ->values();

        return $this->dashboard->render('titan-connect::channels.show', [
            'provider' => $provider,
            'providerLabel' => self::PROVIDERS[$provider],
            'connections' => $connections,
        ], self::PROVIDERS[$provider]);
    }
}
