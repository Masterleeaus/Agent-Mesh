<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Models;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScoped;
use Illuminate\Database\Eloquent\Model;

final class CrmActivity extends Model
{
    use CrmCompanyScoped;

    protected $table = 'crm_activities';
    protected $guarded = ['id'];
    protected $casts = ['occurred_at' => 'datetime', 'scheduled_at' => 'datetime', 'completed_at' => 'datetime', 'metadata' => 'array'];
}
