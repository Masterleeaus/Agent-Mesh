# CRM 1.3.0-alpha.18 — Host Panel Layout Runtime Hotfix Report

## Live failure

`View [panel.layout.app] not found` while rendering `crm::leads.index`.

## Root cause

CRM uses MagicAI's host dashboard shell rather than shipping a competing shell. A scan of the alpha.17 package found 56 CRM Blade views extending `panel.layout.app`. The installed Laravel view finder did not resolve that alias for the failing request, even though the standard MagicAI host layout is stored under `resources/views/default/panel/layout/app.blade.php`.

## Repair

`CrmServiceProvider::boot()` now registers a non-overriding host fallback before CRM views are used.

1. If `panel.layout.app` already exists, no change is made.
2. Otherwise CRM checks for `resources/views/default/panel/layout/app.blade.php`.
3. When present, `resources/views/default` is appended to Laravel's existing view-finder locations.
4. Existing active-theme locations therefore keep priority.
5. The CRM templates continue extending `panel.layout.app`; no 56-file template rewrite is required.

## Safety

- No MagicAI core view is modified.
- No CRM business data or migrations are changed.
- No route/menu/autonomy/Interaction Engine behavior is changed.
- The repair is idempotent and avoids adding the same fallback path twice.

## Regression gate

`bin/verify-v130-alpha18-host-layout-fallback.php` validates the provider call order, standard MagicAI fallback path and shared dependent-view contract.
