<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Queue;

use App\Extensions\TitanAICore\System\DTO\RuntimeContext;
use App\Extensions\TitanAICore\System\Security\TenantRuntimeGuard;

trait RestoresTrustedTenantContext
{
    protected function assertRestoredTenantContext(
        RuntimeContext $runtimeContext,
        string $serializedTenantCompanyId,
        TenantRuntimeGuard $guard,
    ): void {
        $guard->assertTenant($serializedTenantCompanyId, $runtimeContext);
    }
}
