<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';
require dirname(__DIR__,2).'/System/Import/LegacyBookingMapper.php';
use App\Extensions\TitanBookingsQuotes\System\Import\LegacyBookingMapper;
$t=new TitanBQTest();$m=new LegacyBookingMapper();
$r=$m->map(['id'=>42,'company_id'=>5,'customer_id'=>9,'service_id'=>3,'booking_status'=>'pending','service_address'=>'1 Test St']);
$t->assert($r['company_id']===5&&$r['legacy_ref']==='bookingmodule:42','mapped explicit company');
$t->assert($r['customer_ref']==='legacy-customer:9','customer mapped as opaque legacy reference');
try{$m->map(['id'=>43,'customer_id'=>9]);$t->assert(false,'missing company must fail');}catch(RuntimeException $e){$t->assert(str_contains($e->getMessage(),'company'),'ambiguous company refused');}
$t->finish('Pass2 importer');
