# CRM alpha.33 — Security, Portal & Integration Production Gate

## Security boundary
CRM Core owns customer/commercial portal access and CRM integration metadata, but external access must never bypass tenant, identity, scope or governed mutation rules. Alpha.33 makes those boundaries fail closed.

## Customer Hub
A portal invitation has two separate secrets: the URL token and a six-digit verification code intended for a separate trusted channel. Verification binds a durable server-side portal session to the browser session and user-agent evidence. Grants must reference a real same-tenant company or contact. Scope dependencies prevent action-only grants such as `sales.accept` without `sales.view` or `files.download` without `files.view`.

Uploads enter quarantine first. Only a configured `CrmPortalFileScanner` can release a clean file to portal storage. Downloads require an explicit download scope and verified session. Legacy unverified grants/files are revoked/quarantined during upgrade rather than silently trusted.

## API keys
API secrets remain hash-only. Alpha.33 adds mandatory bounded expiry, optional not-before/IP/CIDR policy, granular read scopes and rotation families. Middleware supplies the actual request IP to the policy service.

## Webhooks
Webhook v3 signatures bind timestamp, nonce, delivery ID and body. Secret versions and rotation overlap are durable; retries preserve delivery/idempotency identity. Exhausted deliveries become durable dead letters and can be manually requeued.

## Imports / exports
Imports now follow `stage -> review impact hash -> governed commit`. Every created row gets rollback evidence; automatic rollback is blocked if current state diverges from the imported snapshot. Portable exports exclude internal numeric/tenant/actor persistence IDs and include a SHA-256 manifest plus audit journal entry.

## Operations
Run `php artisan crm:production-check` on the real host. Package verification cannot prove malware scanner, Command Bus, Signal, HTTP egress or storage behavior in the target environment.
