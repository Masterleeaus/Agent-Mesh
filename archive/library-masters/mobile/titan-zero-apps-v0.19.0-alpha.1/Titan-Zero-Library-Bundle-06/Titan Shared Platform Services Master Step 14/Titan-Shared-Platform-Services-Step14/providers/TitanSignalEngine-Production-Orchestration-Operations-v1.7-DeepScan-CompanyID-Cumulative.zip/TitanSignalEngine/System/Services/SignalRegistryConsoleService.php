<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Models\SignalSubscriptionRuntime;
use App\Extensions\TitanSignalEngine\System\Models\SignalSubscriptionVersion;
use App\Extensions\TitanSignalEngine\System\Models\SignalTraceProfile;
use App\Extensions\TitanSignalEngine\System\Models\SignalTypeVersion;
use Illuminate\Support\Facades\Schema;

final class SignalRegistryConsoleService
{
    /** @return array{event_types:list<array<string,mixed>>,subscriptions:list<array<string,mixed>>,trace_profiles:list<array<string,mixed>>} */
    public function snapshot(int $limit = 100): array
    {
        $limit = max(1, min($limit, 250));

        return [
            'event_types' => $this->eventTypes($limit),
            'subscriptions' => $this->subscriptions($limit),
            'trace_profiles' => $this->traceProfiles($limit),
        ];
    }

    /** @return list<array<string,mixed>> */
    private function eventTypes(int $limit): array
    {
        if (! Schema::hasTable('titan_signal_type_versions')) return [];

        $rows = [];
        $seen = [];
        foreach (SignalTypeVersion::query()->orderBy('event_type')->orderByDesc('definition_version')->cursor() as $row) {
            $key = (string) $row->event_type;
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $rows[] = [
                'event_type' => $key,
                'definition_version' => (int) $row->definition_version,
                'owner_source' => (string) ($row->owner_source ?? ''),
                'owner_service_id' => (string) ($row->owner_service_id ?? ''),
                'current_schema_version' => (int) ($row->current_schema_version ?? 1),
                'allowed_scopes' => (array) ($row->allowed_scopes ?? []),
                'allowed_severities' => (array) ($row->allowed_severities ?? []),
                'registered_at' => $row->registered_at?->format(DATE_ATOM),
            ];
            if (count($rows) >= $limit) break;
        }
        return $rows;
    }

    /** @return list<array<string,mixed>> */
    private function subscriptions(int $limit): array
    {
        if (! Schema::hasTable('titan_signal_subscription_runtime')) return [];

        $rows = [];
        foreach (SignalSubscriptionRuntime::query()->orderBy('subscriber_key')->limit($limit)->cursor() as $runtime) {
            $definition = null;
            if (Schema::hasTable('titan_signal_subscription_versions')) {
                $definition = SignalSubscriptionVersion::query()
                    ->where('subscriber_key', $runtime->subscriber_key)
                    ->where('definition_version', $runtime->active_definition_version)
                    ->first();
            }
            $rows[] = [
                'subscriber_key' => (string) $runtime->subscriber_key,
                'definition_version' => (int) ($runtime->active_definition_version ?? 0),
                'runtime_status' => (string) ($runtime->runtime_status ?? 'unknown'),
                'lifecycle_status' => (string) ($runtime->lifecycle_status ?? 'unknown'),
                'quarantine_reason_code' => $runtime->quarantine_reason_code === null ? null : (string) $runtime->quarantine_reason_code,
                'quarantined_at' => $runtime->quarantined_at?->format(DATE_ATOM),
                'last_validated_at' => $runtime->last_validated_at?->format(DATE_ATOM),
                'owner_service_id' => $definition === null ? null : (string) $definition->owner_service_id,
                'queue' => $definition === null ? null : (string) $definition->queue,
                'event_patterns' => $definition === null ? [] : (array) ($definition->event_patterns ?? []),
            ];
        }
        return $rows;
    }

    /** @return list<array<string,mixed>> */
    private function traceProfiles(int $limit): array
    {
        if (! Schema::hasTable('titan_signal_trace_profiles')) return [];

        $rows = [];
        $seen = [];
        foreach (SignalTraceProfile::query()->orderBy('profile_key')->orderByDesc('version')->cursor() as $row) {
            $key = (string) $row->profile_key;
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $rows[] = [
                'profile_key' => $key,
                'version' => (int) $row->version,
                'status' => (string) ($row->status ?? 'unknown'),
                'required_event_types' => (array) ($row->required_event_types ?? []),
                'terminal_event_types' => (array) ($row->terminal_event_types ?? []),
                'match_event_types' => (array) ($row->match_event_types ?? []),
            ];
            if (count($rows) >= $limit) break;
        }
        return $rows;
    }
}
