<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\CanonicalJson;
use InvalidArgumentException;

final class RecompilePlan
{
    private readonly RecompilePlanStatus $status;

    public function __construct(
        private readonly string $currentCompilationUuid,
        private readonly string $currentOutputHash,
        private readonly NexusCompilation $candidate,
        private readonly ?ConfigurationDiff $diff,
    ) {
        self::assertUuid($this->currentCompilationUuid, 'current_compilation_uuid');
        self::assertHash($this->currentOutputHash, 'current_output_hash');

        if ($this->candidate->parentCompilationUuid() !== $this->currentCompilationUuid) {
            throw new InvalidArgumentException('Recompile candidate must point to the current compilation as its parent.');
        }
        if (!$this->candidate->dryRun()) {
            throw new InvalidArgumentException('Recompile candidate must be a dry-run compilation.');
        }

        $validation = $this->candidate->validationResult();
        if ($validation === null) {
            throw new InvalidArgumentException('Recompile candidate must contain validation evidence.');
        }

        if ($validation->hasErrors()) {
            if ($this->diff !== null || $this->candidate->compiledConfiguration() !== null) {
                throw new InvalidArgumentException('Validation-blocked recompile plans cannot contain a compiled candidate or diff.');
            }
            $this->status = RecompilePlanStatus::Blocked;
            return;
        }

        if ($this->diff === null || $this->candidate->compiledConfiguration() === null) {
            throw new InvalidArgumentException('Validated recompile plans require a compiled candidate and semantic diff.');
        }
        if ($this->candidate->configurationDiff()?->fingerprint() !== $this->diff->fingerprint()) {
            throw new InvalidArgumentException('Recompile candidate must retain the exact semantic diff.');
        }

        $this->status = $this->diff->hasBlocked()
            ? RecompilePlanStatus::Blocked
            : ($this->diff->requiresApproval() ? RecompilePlanStatus::RequiresApproval : RecompilePlanStatus::Ready);
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data, NexusCompilation $candidate): self
    {
        $rawDiff = $data['diff'] ?? null;
        $diff = is_array($rawDiff) ? ConfigurationDiff::fromArray($rawDiff) : null;
        $instance = new self(
            self::requiredString($data['current_compilation_uuid'] ?? null, 'current_compilation_uuid'),
            self::requiredString($data['current_output_hash'] ?? null, 'current_output_hash'),
            $candidate,
            $diff,
        );

        $status = $data['status'] ?? null;
        if ($status !== null && (!is_string($status) || $status !== $instance->status()->value)) {
            throw new InvalidArgumentException('Stored recompile plan status does not match derived status.');
        }
        $fingerprint = $data['fingerprint'] ?? null;
        if ($fingerprint !== null && (!is_string($fingerprint) || !hash_equals(strtolower($fingerprint), $instance->fingerprint()))) {
            throw new InvalidArgumentException('Stored recompile plan fingerprint does not match canonical contents.');
        }

        return $instance;
    }

    public function status(): RecompilePlanStatus { return $this->status; }
    public function currentCompilationUuid(): string { return $this->currentCompilationUuid; }
    public function currentOutputHash(): string { return $this->currentOutputHash; }
    public function candidate(): NexusCompilation { return $this->candidate; }
    public function diff(): ?ConfigurationDiff { return $this->diff; }

    public function fingerprint(): string
    {
        return hash('sha256', CanonicalJson::encode($this->withoutFingerprint()));
    }

    /** @return array<string,mixed> */
    public function toContractArray(): array
    {
        $validation = $this->candidate->validationResult();
        if ($validation === null) { throw new InvalidArgumentException('Recompile contract export requires validation evidence.'); }
        $blockedReason = null;
        if ($this->status === RecompilePlanStatus::Blocked) {
            $errors = $validation->errors();
            $blockedReason = $errors !== [] ? $errors[0]->message() : ($this->diff?->hasBlocked() ? 'Semantic diff contains blocked changes.' : 'Recompile is blocked.');
        }
        return [
            'tenant_company_id' => $this->candidate->businessProfile()->tenantCompanyId(),
            'parent_compilation_uuid' => strtolower($this->currentCompilationUuid),
            'candidate_compilation_uuid' => strtolower($this->candidate->compilationUuid()),
            'status' => $this->status->value,
            'validation_fingerprint' => $validation->fingerprint(),
            'diff_fingerprint' => $this->diff?->fingerprint(),
            'vertical_definition_hash' => $this->candidate->compiledConfiguration()?->sourceVerticalHash(),
            'blocked_reason' => $blockedReason,
        ];
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return $this->withoutFingerprint() + ['fingerprint' => $this->fingerprint()];
    }

    /** @return array<string, mixed> */
    private function withoutFingerprint(): array
    {
        return [
            'current_compilation_uuid' => $this->currentCompilationUuid,
            'current_output_hash' => strtolower($this->currentOutputHash),
            'candidate_compilation_uuid' => $this->candidate->compilationUuid(),
            'candidate_configuration_version' => $this->candidate->compiledConfiguration()?->configurationVersion(),
            'candidate_output_hash' => $this->candidate->compiledConfiguration()?->outputHash(),
            'status' => $this->status->value,
            'validation_result' => $this->candidate->validationResult()?->toArray(),
            'diff' => $this->diff?->toArray(),
        ];
    }

    private static function assertUuid(string $value, string $field): void
    {
        if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) !== 1) {
            throw new InvalidArgumentException("{$field} must be a valid UUID.");
        }
    }

    private static function assertHash(string $value, string $field): void
    {
        if (preg_match('/^[0-9a-f]{64}$/i', $value) !== 1) {
            throw new InvalidArgumentException("{$field} must be a SHA-256 hex digest.");
        }
    }

    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') {
            throw new InvalidArgumentException("{$field} is required.");
        }
        return trim($value);
    }
}
