# Titan Forge v0.9.0-alpha.1 — Titan Installer Contract

The release targets the current `titan-extension-v1` custom-extension package contract:

- root `extension.json`
- slug `titan-forge`
- folder `TitanForge`
- provider `App\\Extensions\\TitanForge\\System\\TitanForgeServiceProvider`
- flat ZIP root; no outer `TitanForge/` wrapper
- migrations enabled
- PHP `>=8.2`, MagicAI `>=10.91`, Titan Platform `>=1.0`
- dependency arrays
- scoped publish tag `titan-forge-config`
- `integrity.files` hashes every packaged regular file except `extension.json`
- no traversal, symlinks, case collisions, forbidden secret files or Windows path separators

The extension is unsigned because no Titan publishing private key is available. No signature is fabricated.

This static package contract does not claim live Laravel provider boot, database migration execution, queue-worker execution or dashboard rendering on the deployed host.
