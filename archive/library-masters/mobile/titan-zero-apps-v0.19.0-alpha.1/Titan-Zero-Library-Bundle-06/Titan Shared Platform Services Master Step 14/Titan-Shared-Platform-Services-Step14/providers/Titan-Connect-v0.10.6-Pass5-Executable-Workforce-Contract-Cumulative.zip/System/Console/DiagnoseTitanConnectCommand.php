<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Console;

use App\Extensions\TitanConnect\System\Services\HostReadinessService;
use Illuminate\Console\Command;

final class DiagnoseTitanConnectCommand extends Command
{
    protected $signature = 'titan-connect:diagnose {--json : Emit machine-readable JSON}';
    protected $description = 'Check Titan Connect host readiness without exposing provider credentials.';

    public function handle(HostReadinessService $readiness): int
    {
        $checks = $readiness->checks();
        if ((bool) $this->option('json')) {
            $this->line((string) json_encode(['checks' => $checks], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        } else {
            $this->table(['Check', 'Status', 'Message'], array_map(static fn (array $check): array => [$check['name'], strtoupper($check['status']), $check['message']], $checks));
        }
        foreach ($checks as $check) if ($check['status'] === 'error') return self::FAILURE;
        return self::SUCCESS;
    }
}
