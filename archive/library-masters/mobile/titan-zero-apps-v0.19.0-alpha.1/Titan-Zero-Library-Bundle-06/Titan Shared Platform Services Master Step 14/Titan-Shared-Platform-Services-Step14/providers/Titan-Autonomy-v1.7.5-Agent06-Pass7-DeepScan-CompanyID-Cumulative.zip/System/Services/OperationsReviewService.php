<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\{ControlPlaneAuditSinkContract,OperationsQueryContract,OperationsReviewStoreContract};
use InvalidArgumentException;
use RuntimeException;

final class OperationsReviewService
{
    private const ALLOWED = ['acknowledged','needs_follow_up','reviewed_no_change'];

    public function __construct(
        private readonly OperationsQueryContract $query,
        private readonly OperationsReviewStoreContract $reviews,
        private readonly ControlPlaneAuditSinkContract $audit,
        private readonly string $policyVersion,
    ) {}

    public function record(int $tenantCompanyId, int $userId, string $correlationId, string $reviewStatus, ?string $note = null): array
    {
        if (!in_array($reviewStatus, self::ALLOWED, true)) throw new InvalidArgumentException('INVALID_OPERATIONS_REVIEW_STATUS');
        $receipt = $this->query->receipt($tenantCompanyId, trim($correlationId));
        if ($receipt === null) throw new RuntimeException('EXECUTION_RECEIPT_NOT_FOUND');
        $cleanNote = trim((string)$note);
        if (strlen($cleanNote) > 2000) throw new InvalidArgumentException('OPERATIONS_REVIEW_NOTE_TOO_LONG');
        $reviewRef = $this->reviews->append([
            'receipt_public_id'=>(string)$receipt['public_id'],
            'tenant_company_id'=>$tenantCompanyId,
            'user_id'=>$userId,
            'review_status'=>$reviewStatus,
            'note'=>$cleanNote === '' ? null : $cleanNote,
            'policy_version'=>$this->policyVersion,
        ]);
        $auditRef = $this->audit->record([
            'tenant_company_id'=>$tenantCompanyId,
            'user_id'=>$userId,
            'event_type'=>'autonomy.operations.review',
            'capability'=>$receipt['capability']??null,
            'workflow_key'=>$receipt['workflow_key']??null,
            'correlation_id'=>$receipt['correlation_id']??null,
            'payload'=>['review_ref'=>$reviewRef,'review_status'=>$reviewStatus],
            'policy_version'=>$this->policyVersion,
        ]);
        return ['review_ref'=>$reviewRef,'audit_ref'=>$auditRef,'review_status'=>$reviewStatus];
    }
}
