# Titan Prime — company_id persistence convergence

This pass makes `company_id` the canonical new Workforce-facing company boundary while retaining `tenant_company_id` only as an additive legacy storage/protocol compatibility path.

- Existing historical migrations are unchanged.
- `database/migrations/2026_08_22_000005_add_canonical_company_id_compatibility.php` adds nullable `company_id`, backfills it from legacy rows, and provides rollback.
- New writes dual-stamp canonical and legacy keys where this extension owns the persistence record.
- Reads remain compatible with pre-pass data.
- Blueprint v2.2 protocol fields that still require `tenant_company_id` are retained solely for Blueprint/installer compatibility.
