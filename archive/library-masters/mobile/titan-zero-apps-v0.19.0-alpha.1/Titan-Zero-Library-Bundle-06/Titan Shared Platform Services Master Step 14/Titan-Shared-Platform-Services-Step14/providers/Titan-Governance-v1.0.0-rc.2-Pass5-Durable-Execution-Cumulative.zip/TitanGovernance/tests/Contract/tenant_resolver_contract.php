<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);require_once $root.'/System/Context/TenantCompanyResolver.php';
use App\Extensions\TitanGovernance\System\Context\TenantCompanyResolver;
function fail_tr(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function same_tr(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_tr($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
$r=new TenantCompanyResolver();same_tr(42,$r->resolve((object)['tenant_company_id'=>'42','company_id'=>77]),'explicit tenant_company_id wins');same_tr(77,$r->resolve((object)['company_id'=>'77','id'=>7]),'host company_id alias resolves as int');
foreach([(object)['team_id'=>'9','id'=>7],(object)['id'=>'7'],(object)[]] as $user){$thrown=false;try{$r->resolve($user);}catch(RuntimeException){$thrown=true;}if(!$thrown)fail_tr('tenant resolver must not fabricate tenant from team/user identity');}
echo "PASS: Governance tenant resolver explicit-boundary contract\n";
