# Titan Field Menu Compatibility Contract

Titan Field inherits the field/home-service navigation surfaces that were previously shipped by Titan CRM. It intentionally preserves their Laravel named routes rather than replacing them with hard-coded URLs.

## Self-healing behavior

`TitanFieldMenuInstaller`:

1. checks whether the host `menus` schema is present;
2. locates a historical row by its preferred CRM key;
3. if the key is not present, locates the row by the canonical named route and adopts that existing row/key;
4. repairs route, label, parent, icon, ordering and active state only when necessary;
5. creates a new preferred row only when no historical row exists;
6. rebuilds the host merged menu through `MenuService::regenerate()` when supported;
7. never allows menu/cache failures to prevent Titan Zero from booting.

`TitanFieldServiceProvider` additionally checks field-service route sentinels after Laravel's normal package route loader. If a stale host route cache omitted Titan Field routes, the package route file is loaded before menu rendering.

## Reused navigation families

- **Customers:** Support; Reviews and Recovery.
- **Work:** Work Overview; Service Requests; Jobs; Recurring Work; Services and Catalogue; Service Locations; Forms; Service Areas; Vertical Profiles.
- **Crew:** Schedule; Dispatch; Timesheets.
- **Gear:** Customer Assets.

Other CRM/Core, Project, commercial, workforce and gear links remain owned by their respective domains/extensions. Titan Field does not duplicate them.
