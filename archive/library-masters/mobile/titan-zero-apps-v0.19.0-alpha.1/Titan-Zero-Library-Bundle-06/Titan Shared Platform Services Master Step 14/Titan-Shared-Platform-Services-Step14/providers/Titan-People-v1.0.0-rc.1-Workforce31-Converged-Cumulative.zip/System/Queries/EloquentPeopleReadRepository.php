<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Queries;

use App\Extensions\TitanPeople\System\Models\DepartmentRecord;
use App\Extensions\TitanPeople\System\Models\EmergencyContact;
use App\Extensions\TitanPeople\System\Models\EmploymentEventRecord;
use App\Extensions\TitanPeople\System\Models\EmploymentRelationshipRecord;
use App\Extensions\TitanPeople\System\Models\Holiday;
use App\Extensions\TitanPeople\System\Models\LeaveRequestRecord;
use App\Extensions\TitanPeople\System\Models\PositionRecord;
use App\Extensions\TitanPeople\System\Models\ReportingLineRecord;
use App\Extensions\TitanPeople\System\Models\TeamRecord;
use App\Extensions\TitanPeople\System\Models\Worker;
use App\Extensions\TitanPeople\System\Models\WorkerProfile;
use Illuminate\Database\Eloquent\ModelNotFoundException;

final class EloquentPeopleReadRepository implements PeopleReadRepository
{
    public function overview(int $tenantCompanyId): array
    {
        return [
            'workers' => Worker::query()->where('tenant_company_id', $tenantCompanyId)->count(),
            'active_workers' => Worker::query()->where('tenant_company_id', $tenantCompanyId)->where('employment_status', 'active')->count(),
            'departments' => DepartmentRecord::query()->where('tenant_company_id', $tenantCompanyId)->where('is_active', true)->count(),
            'pending_leave' => LeaveRequestRecord::query()->where('tenant_company_id', $tenantCompanyId)->whereIn('state', ['submitted','pending'])->count(),
        ];
    }

    public function paginateWorkers(int $tenantCompanyId, int $perPage): mixed
    {
        return Worker::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->orderByRaw('COALESCE(preferred_name, legal_name, employee_number, public_id) asc')
            ->paginate($perPage, ['public_id','employee_number','preferred_name','legal_name','work_email','employment_status']);
    }

    public function workerByPublicId(int $tenantCompanyId, string $publicId): array
    {
        $worker = Worker::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->where('public_id', $publicId)
            ->first(['id','public_id','employee_number','preferred_name','legal_name','work_email','personal_email','phone','employment_status']);
        if ($worker === null) throw (new ModelNotFoundException())->setModel(Worker::class, [$publicId]);

        $relationship = EmploymentRelationshipRecord::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->where('worker_id', (int) $worker->getKey())
            ->orderByDesc('starts_on')
            ->limit(1)
            ->first();
        $profile = WorkerProfile::query()->where('tenant_company_id', $tenantCompanyId)->where('worker_id', (int) $worker->getKey())->first();
        return ['worker'=>$worker,'relationship'=>$relationship,'profile'=>$profile];
    }

    public function organisation(int $tenantCompanyId): array
    {
        return [
            'departments' => DepartmentRecord::query()->where('tenant_company_id', $tenantCompanyId)->orderBy('name')->limit(250)->get(['public_id','parent_id','name','is_active']),
            'positions' => PositionRecord::query()->where('tenant_company_id', $tenantCompanyId)->orderBy('name')->limit(500)->get(['public_id','department_id','name','is_active']),
            'teams' => TeamRecord::query()->where('tenant_company_id', $tenantCompanyId)->orderBy('name')->limit(250)->get(['public_id','name','is_active']),
            'reporting_lines' => ReportingLineRecord::query()->where('tenant_company_id', $tenantCompanyId)->whereNull('effective_to')->orderBy('manager_worker_id')->limit(1000)->get(['manager_worker_id','report_worker_id','effective_from']),
        ];
    }

    public function paginateLeave(int $tenantCompanyId, int $perPage): mixed
    {
        return LeaveRequestRecord::query()->where('tenant_company_id', $tenantCompanyId)->orderByDesc('starts_at')->paginate($perPage, ['public_id','worker_id','leave_type_id','state','starts_at','ends_at','requested_units','reason']);
    }

    public function paginateHolidays(int $tenantCompanyId, int $perPage): mixed
    {
        return Holiday::query()->where('tenant_company_id', $tenantCompanyId)->where('active', true)->orderBy('starts_on')->paginate($perPage, ['public_id','name','starts_on','ends_on','team_id','location_id','worker_id','timezone']);
    }

    public function paginateLifecycle(int $tenantCompanyId, int $perPage): mixed
    {
        return EmploymentEventRecord::query()->where('tenant_company_id', $tenantCompanyId)->orderByDesc('effective_at')->paginate($perPage, ['event_id','worker_id','action','state','effective_at','reason','entity_version']);
    }

    public function profile(int $tenantCompanyId, int $workerId): array
    {
        $worker = Worker::query()->where('tenant_company_id', $tenantCompanyId)->whereKey($workerId)->firstOrFail(['id','public_id','employee_number','preferred_name','legal_name','work_email','personal_email','phone','employment_status']);
        $profile = WorkerProfile::query()->where('tenant_company_id', $tenantCompanyId)->where('worker_id', $workerId)->first();
        $contacts = EmergencyContact::query()->where('tenant_company_id', $tenantCompanyId)->where('worker_id', $workerId)->orderBy('priority')->limit(10)->get(['name','relationship','phone','email','priority']);
        return ['worker'=>$worker,'profile'=>$profile,'emergency_contacts'=>$contacts];
    }
}
