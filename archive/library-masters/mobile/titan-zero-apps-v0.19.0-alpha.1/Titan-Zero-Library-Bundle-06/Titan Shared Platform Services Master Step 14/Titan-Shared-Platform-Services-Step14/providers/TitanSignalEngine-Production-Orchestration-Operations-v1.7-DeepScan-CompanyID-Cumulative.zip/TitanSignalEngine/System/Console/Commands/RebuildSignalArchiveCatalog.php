<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Console\Commands;

use App\Extensions\TitanSignalEngine\System\Services\SignalArchiveCatalogRebuilder;
use Illuminate\Console\Command;

final class RebuildSignalArchiveCatalog extends Command
{
    protected $signature = 'titan:signal-archive:catalog {--limit=100 : Maximum verified archive batches to inspect}';
    protected $description = 'Rebuild the Titan Signal cold-history catalog for verified pre-catalog archive batches.';

    public function handle(SignalArchiveCatalogRebuilder $rebuilder): int
    {
        $result = $rebuilder->rebuild((int) $this->option('limit'));
        $this->line(json_encode($result, JSON_THROW_ON_ERROR));
        return self::SUCCESS;
    }
}
