<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Contracts;

interface RewindGovernanceGatewayContract
{
    public function key(): string;
    public function available(): bool;

    /** Return request_id, status=pending|approved|rejected|cancelled|expired and optional final receipt/decision metadata. */
    public function requestApproval(array $request): array;

    /** Refresh a previously issued external Governance request. */
    public function refresh(string $externalRequestId, int $tenantCompanyId): array;

    /** Verify authenticity/provenance of a final Governance decision response. */
    public function verifyReceipt(array $receipt): bool;
}
