<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Commands;

use App\Extensions\TitanPrime\System\TitanPrimeServiceProvider;
use App\Extensions\TitanPrime\System\Gateways\Contracts\AiCoreGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\AssuranceGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\AutonomyGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\EngineBridgeContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\EngineGatewayCatalogContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\GovernanceGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\RewindGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\RiskGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\SignalGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\WisdomGatewayContract;
use App\Extensions\TitanPrime\System\Persistence\Contracts\PrimeMissionRepositoryContract;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class CertifyExtensionCommand extends Command
{
    protected $signature = 'titan:titan-prime:certify {--json : Emit JSON evidence only}';
    protected $description = 'Run non-destructive Titan host certification checks for Titan Prime.';

    public function handle(): int
    {
        $checks = [];
        $record = static function (string $name, bool $passed, string $detail = '') use (&$checks): void {
            $checks[] = ['check' => $name, 'passed' => $passed, 'detail' => $detail];
        };

        $record('php', PHP_VERSION_ID >= 80200, PHP_VERSION);
        $record('laravel', str_starts_with((string) app()->version(), '10.'), (string) app()->version());
        $record('provider_binding', app()->providerIsLoaded(TitanPrimeServiceProvider::class));
        $record('mission_repository_binding', app()->bound(PrimeMissionRepositoryContract::class));
        $record('engine_bridge_binding', app()->bound(EngineBridgeContract::class));
        $record('engine_gateway_catalog_binding', app()->bound(EngineGatewayCatalogContract::class));
        foreach ([
            AiCoreGatewayContract::class,
            SignalGatewayContract::class,
            RiskGatewayContract::class,
            AssuranceGatewayContract::class,
            AutonomyGatewayContract::class,
            GovernanceGatewayContract::class,
            RewindGatewayContract::class,
            WisdomGatewayContract::class,
        ] as $gatewayContract) {
            $record('gateway_binding:' . $gatewayContract, app()->bound($gatewayContract));
        }
        $record('storage', is_writable(storage_path()), storage_path());

        try {
            DB::connection()->getPdo();
            $record('database', DB::connection()->getDriverName() === 'mysql', DB::connection()->getDriverName());
        } catch (Throwable $e) {
            $record('database', false, $e->getMessage());
        }

        $manifestPath = dirname(__DIR__, 2) . '/extension.manifest.json';
        $manifest = is_file($manifestPath) ? json_decode((string) file_get_contents($manifestPath), true) : null;
        $record('manifest', is_array($manifest) && ($manifest['schema_version'] ?? null) === '2.2', $manifestPath);

        if (is_array($manifest)) {
            foreach (($manifest['database']['owned_tables'] ?? []) as $table) {
                $record('table:' . $table, Schema::hasTable((string) $table));
            }
        }

        foreach ([
            'titan_prime_missions' => [
                'tenant_company_id', 'mission_id', 'trace_id', 'correlation_id', 'causation_id',
                'root_causation_id', 'objective_json', 'budget_json', 'initiated_by_type',
                'lock_version', 'record_format',
            ],
            'titan_prime_mission_operations' => [
                'tenant_company_id', 'operation_id', 'mission_id', 'operation_type',
                'payload_hash', 'receipt_json', 'expires_at',
            ],
        ] as $table => $columns) {
            if (!Schema::hasTable($table)) {
                continue;
            }
            foreach ($columns as $column) {
                $record('column:' . $table . '.' . $column, Schema::hasColumn($table, $column));
            }
        }

        foreach (['dashboard.user.titan.prime.index', 'dashboard.admin.titan.prime.index'] as $routeName) {
            $record('route:' . $routeName, Route::has($routeName), $routeName);
        }

        $passed = collect($checks)->every(static fn (array $check): bool => $check['passed'] === true);
        $evidence = [
            'schema_version' => '1.0',
            'contract' => 'titan.release-certification.v1',
            'extension' => 'titan-prime',
            'host_certified' => $passed,
            'checked_at' => now()->toIso8601String(),
            'checks' => $checks,
        ];

        $json = json_encode($evidence, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        if ($this->option('json')) {
            $this->line((string) $json);
        } else {
            $this->info($passed ? 'Host certification PASS' : 'Host certification FAILED');
            $this->line((string) $json);
        }

        return $passed ? self::SUCCESS : self::FAILURE;
    }
}
