<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Services;

use App\Extensions\TitanAICore\System\Contracts\HealthCheckContract;
use App\Extensions\TitanAICore\System\Contracts\PlanValidatorContract;
use App\Extensions\TitanAICore\System\DTO\ActorContext;
use App\Extensions\TitanAICore\System\DTO\ExecutionIntent;
use App\Extensions\TitanAICore\System\DTO\PlanEnvelope;
use App\Extensions\TitanAICore\System\DTO\RuntimeContext;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory as ViewFactory;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class HealthCheck implements HealthCheckContract
{
    public function __construct(
        private readonly Application $app,
        private readonly Router $router,
        private readonly ViewFactory $views,
        private readonly PlanValidatorContract $validator,
    ) {}

    public function check(): array
    {
        $checks = [
            'enabled' => (bool) config('titan-ai-core.enabled', true),
            'user_route' => $this->router->getRoutes()->getByName('dashboard.user.titan.ai.core.index') !== null,
            'admin_route' => $this->router->getRoutes()->getByName('dashboard.admin.titan.ai.core.index') !== null,
            'user_view' => $this->views->exists('titan-ai-core::index'),
            'admin_view' => $this->views->exists('titan-ai-core::admin'),
            'orchestrator_bound' => $this->app->bound('App\\Extensions\\TitanAICore\\System\\Contracts\\OrchestratorContract'),
            'runtime_bound' => $this->app->bound('App\\Extensions\\TitanAICore\\System\\Contracts\\RuntimeManagerContract'),
            'validator_bound' => $this->app->bound(PlanValidatorContract::class),
            'trusted_principal_resolver_bound' => $this->app->bound('App\\Extensions\\TitanAICore\\System\\Contracts\\TrustedPrincipalResolverContract'),
            'plan_repository_bound' => $this->app->bound('App\\Extensions\\TitanAICore\\System\\Contracts\\PlanRepositoryContract'),
            'model_profile_repository_bound' => $this->app->bound('App\\Extensions\\TitanAICore\\System\\Contracts\\ModelProfileRepositoryContract'),
            'risk_gateway_bound' => $this->app->bound('App\\Extensions\\TitanAICore\\System\\Contracts\\RiskGatewayContract'),
            'assurance_gateway_bound' => $this->app->bound('App\\Extensions\\TitanAICore\\System\\Contracts\\AssuranceGatewayContract'),
            'autonomy_gateway_bound' => $this->app->bound('App\\Extensions\\TitanAICore\\System\\Contracts\\AutonomyGatewayContract'),
            'command_bus_gateway_bound' => $this->app->bound('App\\Extensions\\TitanAICore\\System\\Contracts\\CommandBusGatewayContract'),
            'governance_preflight_bound' => $this->app->bound('App\\Extensions\\TitanAICore\\System\\Contracts\\GovernancePreflightContract'),
            'command_bus_boundary_bound' => $this->app->bound('App\\Extensions\\TitanAICore\\System\\Services\\CommandBusMutationBoundary'),
            'validator_fails_closed' => $this->validatorFailsClosed(),
            'plans_table' => $this->tableExists('titan_ai_core_plans'),
            'model_profiles_table' => $this->tableExists('titan_ai_core_model_profiles'),
        ];

        $requiredRuntimeChecks = [
            'enabled',
            'user_route',
            'admin_route',
            'user_view',
            'admin_view',
            'orchestrator_bound',
            'runtime_bound',
            'validator_bound',
            'trusted_principal_resolver_bound',
            'plan_repository_bound',
            'model_profile_repository_bound',
            'risk_gateway_bound',
            'assurance_gateway_bound',
            'autonomy_gateway_bound',
            'command_bus_gateway_bound',
            'governance_preflight_bound',
            'command_bus_boundary_bound',
            'validator_fails_closed',
        ];

        $healthy = true;
        foreach ($requiredRuntimeChecks as $key) {
            if (($checks[$key] ?? false) !== true) {
                $healthy = false;
                break;
            }
        }

        $databaseReady = $checks['plans_table'] && $checks['model_profiles_table'];
        $workforceState = ! $checks['enabled']
            ? 'policy_disabled'
            : (! $databaseReady ? 'unavailable' : ($healthy ? 'available' : 'degraded'));

        return [
            'extension' => 'titan-ai-core',
            'version' => '0.5.0',
            'status' => $healthy ? 'HEALTHY' : 'DEGRADED',
            'workforce_state' => $workforceState,
            'database_ready' => $databaseReady,
            'checks' => $checks,
        ];
    }

    private function validatorFailsClosed(): bool
    {
        try {
            $actor = new ActorContext('health-probe', 'service', 'health-probe', [], 0, true);
            $context = new RuntimeContext('health-probe', $actor, 'health-trace', 'health-correlation', 'health-causation', 'health-root', 'health-operation', 'health-idempotency');
            $result = $this->validator->validate(new PlanEnvelope('health-plan', $context, new ExecutionIntent('health_probe', 'Verify fail-closed validation')));
            return $result->valid === false && $result->executable === false;
        } catch (Throwable) {
            return false;
        }
    }

    private function tableExists(string $table): bool
    {
        try {
            return Schema::hasTable($table);
        } catch (Throwable) {
            return false;
        }
    }
}
