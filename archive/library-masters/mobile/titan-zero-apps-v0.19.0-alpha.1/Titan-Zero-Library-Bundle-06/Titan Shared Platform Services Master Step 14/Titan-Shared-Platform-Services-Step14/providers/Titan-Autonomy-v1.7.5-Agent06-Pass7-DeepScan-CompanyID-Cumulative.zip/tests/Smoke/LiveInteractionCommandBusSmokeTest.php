<?php
declare(strict_types=1);
namespace App\Extensions\InteractionEngine\System\Contracts { interface InteractionEngineManagerContract { public function health():array; public function isEnabled():bool; } }
namespace App\Extensions\InteractionEngine\System\Capabilities {
 final class CapabilityExecutionContext { public function __construct(public string $companyId,public string $actorId,public string $actorType,public array $roles,public array $scopes,public string $sourceSurface,public string $correlationId,public ?string $interactionId=null,public ?string $wizardId=null,public ?string $sessionId=null,public ?string $deviceId=null,public ?string $idempotencyKey=null,public array $approvalEvidence=[]){} }
 final class CapabilityRouter { public function canonical(string $c):string{return $c;} public function status(string $c,?CapabilityExecutionContext $x=null):array{return ['availability'=>'available','supported'=>true,'canonical_capability'=>$c];} }
}
namespace App\Extensions\InteractionEngine\System\Command { final class CommandBus { public array $calls=[]; public function dispatchResult(string $c,array $p):object{$this->calls[]=[$c,$p]; return new class($c){public function __construct(private string $c){} public function toArray():array{return ['status'=>'executed','capability'=>$this->c];}};} } }
namespace {
spl_autoload_register(function(string $class):void{ $p='App\\Extensions\\TitanAutonomy\\'; if(!str_starts_with($class,$p))return; $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($path))require_once $path; });
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\DTOs\GovernedCapabilityCommand;
use App\Extensions\TitanAutonomy\System\Infrastructure\InteractionCommandBusLiveBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\InteractionEngineLiveBridge;
$host=new class implements HostContextBridgeContract {public function tenantCompanyId():int{return 42;}public function userId():int{return 7;}public function can(string $p):bool{return true;}public function isSuperAdmin():bool{return false;}};
$manager=new class implements \App\Extensions\InteractionEngine\System\Contracts\InteractionEngineManagerContract {public function health():array{return ['status'=>'ok'];}public function isEnabled():bool{return true;}};
$router=new \App\Extensions\InteractionEngine\System\Capabilities\CapabilityRouter();
$i=new InteractionEngineLiveBridge($manager,$router,$host);
$r=$i->prepareJourney('crm.invoice.issue','completed_job_invoice',['correlation_id'=>'corr-1']);
if(($r['ready']??false)!==true)throw new RuntimeException('live Interaction bridge must report ready for available capability');
$bus=new \App\Extensions\InteractionEngine\System\Command\CommandBus();
$b=new InteractionCommandBusLiveBridge($bus,$host);
$cmd=new GovernedCapabilityCommand('crm.invoice.issue',['amount'=>500,'_delegated_authority'=>['grant_id'=>'forged'],'_context'=>['company_id'=>'999','autonomy_workflow_key'=>'forged']],'completed_job_invoice','corr-1');
$serverGrant=['grant_id'=>'server-grant','signature'=>'server-signature'];
$out=$b->dispatch($cmd,['roles'=>['owner'],'scopes'=>['crm.invoices.manage'],'workflow_key'=>'completed_job_invoice','autonomy_level'=>'auto','delegated_authority'=>$serverGrant]);
if(($out['status']??null)!=='executed')throw new RuntimeException('dispatchResult must be returned');
$payload=$bus->calls[0][1]??[];
if(($payload['_context']['company_id']??null)!=='42')throw new RuntimeException('trusted host tenant must overwrite client company_id');
if(($payload['_context']['actor_id']??null)!=='7')throw new RuntimeException('trusted actor id required');
if(($payload['_context']['actor_type']??null)!=='system')throw new RuntimeException('Auto delegation must execute as system actor, not masquerade as a human');
if(($payload['_context']['roles']??null)!==[])throw new RuntimeException('Auto delegation must not inherit caller role claims');
if(($payload['_context']['autonomy_workflow_key']??null)!=='completed_job_invoice')throw new RuntimeException('server authority context must set autonomy workflow key');
if(($payload['_delegated_authority']['grant_id']??null)!=='server-grant')throw new RuntimeException('server-issued delegated authority must replace client delegation');
echo "OK: LiveInteractionCommandBusSmokeTest\n";
}
