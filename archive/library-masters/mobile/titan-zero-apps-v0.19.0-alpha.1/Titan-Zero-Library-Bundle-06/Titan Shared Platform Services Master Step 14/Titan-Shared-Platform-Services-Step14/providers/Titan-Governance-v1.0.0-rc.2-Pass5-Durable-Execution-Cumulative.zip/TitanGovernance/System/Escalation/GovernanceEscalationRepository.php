<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Escalation;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceEscalationStoreContract;
use App\Extensions\TitanGovernance\System\Models\GovernanceEscalation;
use RuntimeException;

final class GovernanceEscalationRepository implements GovernanceEscalationStoreContract
{
    public function __construct(private readonly GovernanceEscalationPriority $priority) {}

    public function queue(int $tenantCompanyId,int $limit=50): array
    {
        $rows=GovernanceEscalation::query()
            ->where('tenant_company_id',$tenantCompanyId)
            ->whereIn('status',['OPEN','HELD','ESCALATED'])
            ->orderByDesc('risk_score')
            ->orderByDesc('urgency')
            ->orderBy('opened_at')
            ->limit(max(1,min(200,$limit)))->get();
        $items=[];
        foreach($rows as $row) if($row instanceof GovernanceEscalation)$items[]=$this->toArray($row);
        return $this->priority->sort($items);
    }

    public function find(int $tenantCompanyId,string $escalationId): ?array
    {
        $row=GovernanceEscalation::query()->where('tenant_company_id',$tenantCompanyId)->where('escalation_id',$escalationId)->first();
        return $row instanceof GovernanceEscalation?$this->toArray($row):null;
    }

    public function applyTransition(int $tenantCompanyId,string $escalationId,int $expectedVersion,string $nextStatus,string $resolutionAction,string $decisionId,string $commandReceiptRef): array
    {
        $terminal=in_array($nextStatus,['APPROVED','REJECTED','EXCEPTION_GRANTED','RESOLVED'],true);
        $updated=GovernanceEscalation::query()
            ->where('tenant_company_id',$tenantCompanyId)
            ->where('escalation_id',$escalationId)
            ->where('version',$expectedVersion)
            ->update([
                'status'=>$nextStatus,
                'resolution_action'=>$resolutionAction,
                'last_decision_id'=>$decisionId,
                'last_command_receipt_ref'=>$commandReceiptRef,
                'resolved_at'=>$terminal?now():null,
                'version'=>$expectedVersion+1,
                'updated_at'=>now(),
            ]);
        if($updated!==1) throw new RuntimeException('ESCALATION_VERSION_CONFLICT');
        $row=GovernanceEscalation::query()->where('tenant_company_id',$tenantCompanyId)->where('escalation_id',$escalationId)->first();
        if(!$row instanceof GovernanceEscalation) throw new RuntimeException('ESCALATION_NOT_FOUND_AFTER_UPDATE');
        return $this->toArray($row);
    }

    /** @return array<string,mixed> */
    private function toArray(GovernanceEscalation $row): array
    {
        $opened=$row->opened_at; $resolved=$row->resolved_at;
        return [
            'escalation_id'=>(string)$row->escalation_id,
            'tenant_company_id'=>(int)$row->tenant_company_id,
            'subject_type'=>(string)$row->subject_type,
            'subject_id'=>(string)$row->subject_id,
            'risk_score'=>$row->risk_score===null?null:(float)$row->risk_score,
            'urgency'=>(int)$row->urgency,
            'status'=>(string)$row->status,
            'reason_codes'=>is_array($row->reason_codes)?$row->reason_codes:[],
            'evidence_refs'=>is_array($row->evidence_refs)?$row->evidence_refs:[],
            'trace_id'=>(string)$row->trace_id,
            'correlation_id'=>(string)$row->correlation_id,
            'causation_id'=>$row->causation_id,
            'root_causation_id'=>(string)$row->root_causation_id,
            'opened_at'=>$opened?->toIso8601String(),
            'resolved_at'=>$resolved?->toIso8601String(),
            'version'=>(int)($row->version??1),
            'resolution_action'=>$row->resolution_action,
            'last_decision_id'=>$row->last_decision_id,
            'last_command_receipt_ref'=>$row->last_command_receipt_ref,
        ];
    }
}
