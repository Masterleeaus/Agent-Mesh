# Capabilities

Nexus provides deterministic compile, semantic validation, preview, configuration history, semantic diff, recompile planning, governed provisioning planning/execution, idempotent mutation receipts, and public Risk/Governance/Assurance/Autonomy/Signal/Rewind adapters.


## Runtime availability

Manifest capabilities describe functionality shipped by the package. Runtime availability is projected independently by `NexusManager::health()` and must be consulted before invoking dependency-conditioned capabilities. `nexus.runtime-readiness` exposes exact dependency reasons and execution-mode readiness.
