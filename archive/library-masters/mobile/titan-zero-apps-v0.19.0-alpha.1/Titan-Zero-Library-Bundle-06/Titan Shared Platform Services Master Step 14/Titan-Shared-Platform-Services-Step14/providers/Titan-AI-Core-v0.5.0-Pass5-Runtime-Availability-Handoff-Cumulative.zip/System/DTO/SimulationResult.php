<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class SimulationResult { public function __construct(public bool $available, public bool $sideEffectFree, public array $projectedChanges = [], public array $warnings = []) {} }
