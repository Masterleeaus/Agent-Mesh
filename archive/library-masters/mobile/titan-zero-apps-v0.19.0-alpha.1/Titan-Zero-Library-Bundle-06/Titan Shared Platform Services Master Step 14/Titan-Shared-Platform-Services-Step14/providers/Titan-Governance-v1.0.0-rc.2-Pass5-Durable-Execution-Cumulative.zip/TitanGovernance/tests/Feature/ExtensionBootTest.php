<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\Tests\Feature;

use PHPUnit\Framework\TestCase;

final class ExtensionBootTest extends TestCase
{
    public function test_installer_identity_resolves_provider_path(): void
    {
        $root=dirname(__DIR__,2); $manifest=json_decode((string)file_get_contents($root.'/extension.json'),true,512,JSON_THROW_ON_ERROR);
        self::assertSame('titan-extension-v1',$manifest['schema']); self::assertSame('TitanGovernance',$manifest['folder']);
        self::assertFileExists($root.'/System/TitanGovernanceServiceProvider.php');
        self::assertSame('App\Extensions\TitanGovernance\System\TitanGovernanceServiceProvider',$manifest['provider']);
    }
}
