<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers\TeamChat;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Events\TeamChat\TeamUserTyping;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use App\Extensions\TitanConnect\System\Realtime\SafeRealtimeDispatcher;
use App\Extensions\TitanConnect\System\Security\ConversationAccess;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class TeamRealtimeController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly ConversationAccess $access,
        private readonly SafeRealtimeDispatcher $realtime,
    ) {
    }

    public function typing(Request $request, TeamConversation $conversation): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->access->assertMember($conversation, $companyId, $actorId);
        $data = $request->validate(['typing' => ['required', 'boolean']]);
        $this->realtime->dispatch(new TeamUserTyping($conversation, $actorId, (bool) $data['typing']));
        return response()->json(['status' => 'accepted']);
    }
}
