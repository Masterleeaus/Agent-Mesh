<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

final class EngineGatewayBoundaryTest extends TestCase
{
    public function test_gateway_layer_does_not_import_foreign_extension_implementations(): void
    {
        $root = realpath(__DIR__ . '/../../System/Gateways');
        self::assertNotFalse($root);

        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));
        foreach ($iterator as $file) {
            if (!$file->isFile() || $file->getExtension() !== 'php') {
                continue;
            }
            $source = (string) file_get_contents($file->getPathname());
            self::assertDoesNotMatchRegularExpression(
                '/use\\s+App\\\\Extensions\\\\(?!TitanPrime\\\\)/',
                $source,
                'Prime gateways must not import another extension implementation: ' . $file->getFilename(),
            );
        }
    }

    public function test_provider_defaults_to_fail_closed_bridge_but_allows_host_override(): void
    {
        $provider = (string) file_get_contents(__DIR__ . '/../../System/TitanPrimeServiceProvider.php');

        self::assertStringContainsString('if (!$this->app->bound(EngineBridgeContract::class))', $provider);
        self::assertStringContainsString('EngineBridgeContract::class, FailClosedEngineBridge::class', $provider);
        self::assertStringContainsString('RiskGatewayContract::class, RiskGateway::class', $provider);
        self::assertStringContainsString('GovernanceGatewayContract::class, GovernanceGateway::class', $provider);
        self::assertStringContainsString('AutonomyGatewayContract::class, AutonomyGateway::class', $provider);
    }

    public function test_gateway_requests_require_causal_context_and_caller_owned_operation_ids(): void
    {
        $request = (string) file_get_contents(__DIR__ . '/../../System/Gateways/Data/EngineGatewayRequest.php');

        self::assertStringContainsString('public TraceContext $trace', $request);
        self::assertStringContainsString('public string $operationId', $request);
        self::assertStringContainsString("'operation_id' => \$this->operationId", $request);
        self::assertStringContainsString("'trace' => \$this->trace->toArray()", $request);
    }
}
