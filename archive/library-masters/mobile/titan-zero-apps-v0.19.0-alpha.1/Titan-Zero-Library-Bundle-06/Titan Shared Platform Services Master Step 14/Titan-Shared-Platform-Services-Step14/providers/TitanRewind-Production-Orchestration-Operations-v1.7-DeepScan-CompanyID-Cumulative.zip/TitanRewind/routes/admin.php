<?php

use App\Extensions\TitanRewind\System\Http\Controllers\AdminController;
use App\Extensions\TitanRewind\System\Http\Controllers\RuntimeController;
use App\Extensions\TitanRewind\System\Http\Controllers\RetentionController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', AdminController::class)->middleware('titan-rewind.permission:rewind.admin')->name('index');

$router->post('/runtime-state', [RuntimeController::class,'setState'])->middleware('titan-rewind.permission:rewind.admin')->name('runtime.state');
$router->post('/dead-letters/{deadLetterUuid}/retry', [RuntimeController::class,'retryDeadLetter'])->middleware('titan-rewind.permission:rewind.admin')->name('dead-letter.retry');

$router->post('/retention/run', [RetentionController::class,'run'])->middleware('titan-rewind.permission:rewind.admin')->name('retention.run');
