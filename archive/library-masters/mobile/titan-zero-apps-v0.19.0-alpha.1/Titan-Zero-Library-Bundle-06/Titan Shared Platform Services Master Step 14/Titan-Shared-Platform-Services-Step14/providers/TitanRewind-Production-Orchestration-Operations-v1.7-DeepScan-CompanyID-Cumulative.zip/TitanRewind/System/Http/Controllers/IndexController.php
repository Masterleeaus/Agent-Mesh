<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Http\Controllers;

use App\Extensions\TitanRewind\System\Models\RewindCase;
use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use App\Extensions\TitanRewind\System\Models\RewindRecoveryPlan;
use App\Extensions\TitanRewind\System\Models\RewindReplayRun;
use App\Extensions\TitanRewind\System\Models\RewindTraceIndex;
use App\Extensions\TitanRewind\System\Services\RewindTenantContextResolver;
use App\Extensions\TitanRewind\System\Services\RewindAnalyticsService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

final class IndexController
{
    public function __construct(private RewindTenantContextResolver $tenants, private RewindAnalyticsService $analytics) {}

    public function __invoke(Request $request): View { return $this->render($request, 'overview'); }
    public function traces(Request $request): View { return $this->render($request, 'traces'); }
    public function cases(Request $request): View { return $this->render($request, 'cases'); }
    public function replays(Request $request): View { return $this->render($request, 'replays'); }
    public function evidence(Request $request): View { return $this->render($request, 'evidence'); }
    public function recovery(Request $request): View { return $this->render($request, 'recovery'); }

    private function render(Request $request, string $surface): View
    {
        $tenant = $this->tenants->forUser($request->user());
        $traces = $cases = $replays = $evidencePackages = $recoveryPlans = collect();
        $analytics = [];
        if ($tenant !== null) {
            $traces = RewindTraceIndex::query()->where('tenant_company_id',$tenant)->latest('last_event_at')->limit(25)->lazy(100);
            $cases = RewindCase::query()->where('tenant_company_id',$tenant)->latest('detected_at')->limit(25)->lazy(100);
            $replays = RewindReplayRun::query()->where('tenant_company_id',$tenant)->latest()->limit(25)->lazy(100);
            $evidencePackages = RewindEvidencePackage::query()->where('tenant_company_id',$tenant)->latest()->limit(25)->lazy(100);
            $recoveryPlans = RewindRecoveryPlan::query()->where('tenant_company_id',$tenant)->latest()->limit(25)->lazy(100);
            $analytics = $this->analytics->dashboard($tenant);
        }
        return view('titan-rewind::index', compact('tenant','traces','cases','replays','evidencePackages','recoveryPlans','analytics','surface'));
    }
}
