<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('settings')) {
            return;
        }

        $missing = array_filter([
            'crm_enabled' => ! Schema::hasColumn('settings', 'crm_enabled'),
            'crm_assistant_enabled' => ! Schema::hasColumn('settings', 'crm_assistant_enabled'),
            'crm_presentations_enabled' => ! Schema::hasColumn('settings', 'crm_presentations_enabled'),
        ]);

        if ($missing === []) {
            return;
        }

        Schema::table('settings', function (Blueprint $table) use ($missing): void {
            if (isset($missing['crm_enabled'])) {
                $table->boolean('crm_enabled')->default(true);
            }
            if (isset($missing['crm_assistant_enabled'])) {
                $table->boolean('crm_assistant_enabled')->default(true);
            }
            if (isset($missing['crm_presentations_enabled'])) {
                $table->boolean('crm_presentations_enabled')->default(true);
            }
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('settings')) {
            return;
        }

        foreach (['crm_enabled', 'crm_assistant_enabled', 'crm_presentations_enabled'] as $column) {
            if (Schema::hasColumn('settings', $column)) {
                Schema::table('settings', fn (Blueprint $table) => $table->dropColumn($column));
            }
        }
    }
};
