<?php
declare(strict_types=1);
namespace {
spl_autoload_register(function(string $class):void{ $p='App\\Extensions\\TitanAutonomy\\'; if(!str_starts_with($class,$p))return; $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($path))require_once $path; });
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Infrastructure\ModelCouncilAssuranceBridge;
$host=new class implements HostContextBridgeContract {public function tenantCompanyId():int{return 42;}public function userId():int{return 7;}public function can(string $p):bool{return true;}public function isSuperAdmin():bool{return false;}};
$run=(object)['uuid'=>'run-1','company_id'=>'42','status'=>'assured','permission_state'=>'permitted','confidence_score'=>94.0,'expires_at'=>null,'final_recommendation'=>'Proceed'];
$b=new ModelCouncilAssuranceBridge($host,fn(int $tenant,string $sourceId)=>$run);
$ok=$b->evaluate('crm.invoice.issue','completed_job_invoice',[]);
if(($ok['status']??null)!=='GREEN'||($ok['decision']??null)!=='approved')throw new RuntimeException('assured+permitted must normalize GREEN approved');
$run->status='assured_with_conditions';
$amber=$b->evaluate('crm.invoice.issue','completed_job_invoice',[]);
if(($amber['status']??null)!=='AMBER'||($amber['decision']??null)!=='denied')throw new RuntimeException('conditional assurance must not mint Trusted Auto approval');
$run->status='policy_blocked';
$red=$b->evaluate('crm.invoice.issue','completed_job_invoice',[]);
if(($red['status']??null)!=='RED'||($red['decision']??null)!=='denied')throw new RuntimeException('blocked assurance must be RED denied');
$missing=new ModelCouncilAssuranceBridge($host,fn()=>null);
$m=$missing->evaluate('crm.invoice.issue','completed_job_invoice',[]);
if(($m['decision']??null)!=='denied')throw new RuntimeException('missing run must fail closed');
echo "OK: LiveAssuranceBridgeSmokeTest\n";
}
