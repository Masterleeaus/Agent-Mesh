# Troubleshooting

## Actions show COMMAND_BUS_UNAVAILABLE

The package is intentionally fail-closed. Confirm `TITAN_GOVERNANCE_COMMAND_GATEWAY_CLASS` points to a Laravel-resolvable class implementing `GovernanceCommandGatewayContract`, then run `php artisan titan:titan-governance:certify --json`.

## Action returns ESCALATION_VERSION_CONFLICT

Another action changed the escalation after the page loaded. Reload the Governance dashboard/queue and act against the new version. Do not retry a stale version with a new operation ID.

## Action returns IDEMPOTENCY_CONFLICT

The same tenant-scoped operation ID was reused for different semantic content. Preserve the existing operation for retries of the same decision; generate/use a distinct operation only for a genuinely new human decision.

## Action is BLOCKED after a transient outage

Retry the same action/operation. v0.5.0 may redispatch the same immutable Governance decision after Command Bus unavailable/transport failures. Terminal outcomes do not redispatch.

## Command Bus claims success but Governance reports COMMAND_RECEIPT_INVALID

Inspect the Command Bus integration. `APPLIED` must carry matching Governance decision reference, command receipt, authoritative domain receipt, adapter identity and `write_verified=true`. Governance intentionally refuses optimistic success.
