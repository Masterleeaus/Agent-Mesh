<?php

declare(strict_types=1);
$root = dirname(__DIR__, 2);
$provider = (string) file_get_contents($root . '/System/TitanAICoreServiceProvider.php');
$config = (string) file_get_contents($root . '/config/titan-ai-core.php');
$contract = json_decode((string) file_get_contents($root . '/contracts/orchestration-planning.json'), true, flags: JSON_THROW_ON_ERROR);
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);

foreach ([
    'RiskGatewayContract::class', 'AssuranceGatewayContract::class', 'AutonomyGatewayContract::class',
    'CommandBusGatewayContract::class', 'GovernancePreflightContract::class', 'CommandBusMutationBoundary::class',
] as $needle) {
    if (!str_contains($provider, $needle)) { fwrite(STDERR, "provider missing Pass 4 binding: {$needle}\n"); exit(1); }
}
if (!str_contains($config, "'execution_enabled' => false") || !str_contains($config, "'command_bus_only_mutation' => true")) {
    fwrite(STDERR, "Pass 4 execution boundary config is not fail closed\n"); exit(1);
}
$evidence = $contract['implementation_evidence'] ?? [];
if (($evidence['governance_preflight'] ?? null) !== true || ($evidence['governed_execution'] ?? null) !== false) {
    fwrite(STDERR, "orchestration contract over/under-states Pass 4 implementation evidence\n"); exit(1);
}
if (($contract['mutation_boundary'] ?? null) !== 'command-bus-only' || ($contract['denial_state'] ?? null) !== 'PENDING_REVIEW') {
    fwrite(STDERR, "orchestration mutation/denial boundary drifted\n"); exit(1);
}
if (($manifest['authority']['cross_domain_write_policy'] ?? null) !== 'command-bus-only') {
    fwrite(STDERR, "manifest no longer requires Command Bus-only cross-domain writes\n"); exit(1);
}

$forbidden = [];
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/System'));
foreach ($it as $file) {
    if (!$file->isFile() || $file->getExtension() !== 'php') continue;
    $relative = str_replace($root . '/', '', $file->getPathname());
    if (str_starts_with($relative, 'System/Repositories/')) continue; // extension-owned persistence only
    $text = (string) file_get_contents($file->getPathname());
    foreach (['DB::' . 'insert(', 'DB::' . 'update(', 'DB::' . 'delete(', '->' . 'insert(', '->' . 'update(', '->' . 'delete('] as $needle) {
        if (str_contains($text, $needle)) $forbidden[] = $relative . ':' . $needle;
    }
}
if ($forbidden !== []) {
    fwrite(STDERR, "direct mutation primitive found outside extension-owned repositories: " . implode(', ', $forbidden) . "\n"); exit(1);
}

fwrite(STDOUT, "Pass 4 runtime wiring contract test: PASS\n");
