<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Contracts;

use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlan;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;

interface ProvisioningExecutorContract
{
    public function execute(
        ProvisioningPlan $plan,
        TraceContext $traceContext,
        bool $approvalGranted = false,
        ?ProvisioningExecutionContext $executionContext = null,
    ): ProvisioningPlan;
}
