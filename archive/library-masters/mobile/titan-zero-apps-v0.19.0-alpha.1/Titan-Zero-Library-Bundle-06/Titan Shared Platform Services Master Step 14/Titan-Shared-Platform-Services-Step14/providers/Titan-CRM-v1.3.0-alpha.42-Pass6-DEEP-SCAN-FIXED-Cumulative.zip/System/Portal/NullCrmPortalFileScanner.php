<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Portal;

final class NullCrmPortalFileScanner implements CrmPortalFileScanner
{
    public function scan(string $path, string $mimeType): array
    {
        return ['status'=>'scanner_unavailable','engine'=>'none'];
    }
}
