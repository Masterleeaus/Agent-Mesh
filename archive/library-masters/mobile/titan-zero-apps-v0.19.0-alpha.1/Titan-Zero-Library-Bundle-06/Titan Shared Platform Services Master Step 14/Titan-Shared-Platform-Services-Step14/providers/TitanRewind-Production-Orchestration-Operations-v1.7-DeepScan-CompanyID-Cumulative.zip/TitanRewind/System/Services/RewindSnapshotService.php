<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Models\RewindSnapshot;
use App\Extensions\TitanRewind\System\Models\RewindTraceEvent;
use App\Extensions\TitanRewind\System\Support\CanonicalJson;
use App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer;
use Illuminate\Support\Str;
use InvalidArgumentException;
use LogicException;

final class RewindSnapshotService
{
    public function __construct(private RewindPayloadSanitizer $sanitizer, private CanonicalJson $canonicalJson) {}

    public function captureFromEvent(RewindTraceEvent $event): ?RewindSnapshot
    {
        $payload = $event->payload ?? [];
        $state = null;
        $snapshotType = 'event_state';
        if (is_array($payload['snapshot'] ?? null)) $state = $payload['snapshot'];
        elseif (is_array($payload['after_state'] ?? null)) { $state = $payload['after_state']; $snapshotType = 'after_state'; }
        if ($state === null) return null;

        $entityType = trim((string) ($payload['entity_type'] ?? ''));
        $entityId = trim((string) ($payload['entity_id'] ?? ''));
        if ($entityType === '' || $entityId === '') return null;

        return $this->store(
            (int) $event->tenant_company_id, (string) $event->trace_id, $entityType, $entityId, $snapshotType, $state,
            (string) $event->event_id, $event->correlation_id, $event->causation_id, $event->occurred_at
        );
    }

    public function store(
        int $tenantCompanyId,
        string $traceId,
        string $entityType,
        string $entityId,
        string $snapshotType,
        array $state,
        ?string $eventId = null,
        ?string $correlationId = null,
        ?string $causationId = null,
        mixed $occurredAt = null,
    ): RewindSnapshot {
        if ($tenantCompanyId < 1) throw new InvalidArgumentException('tenant_company_id must be positive for snapshots.');
        if (trim($traceId) === '' || trim($entityType) === '' || trim($entityId) === '') throw new InvalidArgumentException('trace/entity identity is required for snapshots.');

        $clean = $this->sanitizer->sanitize($state);
        $json = $this->canonicalJson->encode($clean);
        $stateHash = hash('sha256', $json);
        $snapshotKey = hash('sha256', $this->canonicalJson->encode([
            'tenant_company_id'=>$tenantCompanyId,'trace_id'=>$traceId,'event_id'=>$eventId,'entity_type'=>$entityType,
            'entity_id'=>$entityId,'snapshot_type'=>$snapshotType,
        ]));
        $integrityHash = hash('sha256', $this->canonicalJson->encode([
            'snapshot_key'=>$snapshotKey,'state_hash'=>$stateHash,
        ]));

        $existing = RewindSnapshot::query()->where('snapshot_key', $snapshotKey)->first();
        if ($existing) {
            if ($existing->state_hash && !hash_equals((string) $existing->state_hash, $stateHash)) {
                throw new LogicException('An idempotent Rewind snapshot key was reused with different state.');
            }
            return $existing;
        }

        return RewindSnapshot::query()->create([
            'snapshot_uuid' => (string) Str::uuid(),
            'snapshot_key' => $snapshotKey,
            'tenant_company_id' => $tenantCompanyId,
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId,
            'type' => 'state',
            'status' => 'captured',
            'payload' => $clean,
            'occurred_at' => $occurredAt ?? now(),
            'reconstruction_version' => 2,
            'source_hash' => $stateHash,
            'integrity_hash' => $integrityHash,
            'metadata' => ['source' => 'rewind.snapshot'],
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'snapshot_type' => trim($snapshotType) ?: 'state',
            'event_id' => $eventId,
            'state_hash' => $stateHash,
            'size_bytes' => strlen($json),
            'captured_at' => now(),
        ]);
    }

    public function latest(int $tenantCompanyId, string $entityType, string $entityId): ?RewindSnapshot
    {
        return RewindSnapshot::query()->where('tenant_company_id',$tenantCompanyId)->where('entity_type',$entityType)->where('entity_id',$entityId)->latest('captured_at')->first();
    }
}
