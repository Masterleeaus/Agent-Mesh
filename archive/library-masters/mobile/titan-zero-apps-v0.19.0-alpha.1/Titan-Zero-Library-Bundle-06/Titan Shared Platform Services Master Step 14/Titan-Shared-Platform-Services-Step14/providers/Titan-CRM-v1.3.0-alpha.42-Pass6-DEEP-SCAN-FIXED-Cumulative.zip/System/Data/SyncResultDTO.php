<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Data;

final class SyncResultDTO
{
    public function __construct(
        public readonly mixed $status,
        public readonly mixed $idempotencyKey,
        public readonly mixed $serverRevision,
        public readonly mixed $result,
        public readonly mixed $conflict,
    ) {}

    public function toArray(): array
    {
        return [
            'status'=>$this->status,
            'idempotencyKey'=>$this->idempotencyKey,
            'serverRevision'=>$this->serverRevision,
            'result'=>$this->result,
            'conflict'=>$this->conflict,
        ];
    }
}
