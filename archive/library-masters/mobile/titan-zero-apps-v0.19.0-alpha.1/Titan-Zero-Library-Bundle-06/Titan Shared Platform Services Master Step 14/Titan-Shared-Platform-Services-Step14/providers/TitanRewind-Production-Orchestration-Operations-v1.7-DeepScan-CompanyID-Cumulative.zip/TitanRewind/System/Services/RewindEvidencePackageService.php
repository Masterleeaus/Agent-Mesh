<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Audit\RewindEvidenceAssembler;
use App\Extensions\TitanRewind\System\Contracts\RewindEvidenceSignerContract;
use App\Extensions\TitanRewind\System\Models\RewindCase;
use App\Extensions\TitanRewind\System\Models\RewindCaseTrace;
use App\Extensions\TitanRewind\System\Models\RewindDriftFinding;
use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use App\Extensions\TitanRewind\System\Models\RewindGovernanceReceipt;
use App\Extensions\TitanRewind\System\Models\RewindIntegrityCheck;
use App\Extensions\TitanRewind\System\Models\RewindRecoveryPlan;
use App\Extensions\TitanRewind\System\Models\RewindSnapshot;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Support\CanonicalJson;
use App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer;
use App\Extensions\TitanRewind\System\Observability\RewindTraceContext;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class RewindEvidencePackageService
{
    public function __construct(
        private RewindReconstructionService $reconstruction,
        private RewindIntegrityService $integrity,
        private RewindEvidenceAssembler $assembler,
        private RewindPayloadSanitizer $sanitizer,
        private CanonicalJson $canonicalJson,
        private RewindEvidenceSignerContract $signer,
        private RewindCustodyService $custody,
        private RewindTelemetryService $telemetry,
        private RewindSignalOutboxService $signals,
        private RewindSigningKeyService $signingKeys,
    ) {}

    public function forTrace(RewindTraceQuery $query, string $type = 'audit', ?int $caseId = null, ?int $generatedById = null): RewindEvidencePackage
    {
        $case = $this->resolveCase($query, $caseId);
        $data = $this->collectTrace($query, $generatedById);
        $assembled = $this->assembler->assemble(
            packageType: $this->packageType($type),
            trace: $data['trace'],
            case: $case ? $this->sanitizer->sanitize($case->toArray()) : null,
            snapshots: $data['snapshots'],
            integrityChecks: [$data['integrity_summary']],
            driftFindings: $data['drift'],
            recoveryPlans: $data['plans'],
            governanceReceipts: $data['receipts'],
            generatedAt: now()->toIso8601String(),
            generatedById: $generatedById,
        );

        return $this->persist(
            tenantCompanyId: $query->tenantCompanyId(),
            scopeType: 'trace',
            scopeId: $query->traceId(),
            packageType: $this->packageType($type),
            assembled: $assembled,
            traceId: $query->traceId(),
            caseId: $case?->id,
            integrityCheckUuid: $data['integrity_check']->check_uuid,
            generatedById: $generatedById,
            ready: (string) $data['integrity_check']->status === 'passed' && (($data['trace']['source_completeness']['complete_for_audit'] ?? false) === true),
            sourceCompleteness: (string) ($data['trace']['source_completeness']['state'] ?? 'PARTIAL'),
        );
    }

    public function forCase(int $tenantCompanyId, string $caseUuid, string $type = 'audit', ?int $generatedById = null): RewindEvidencePackage
    {
        if ($tenantCompanyId < 1) throw new InvalidArgumentException('tenant_company_id is required for case evidence.');
        /** @var RewindCase $case */
        $case = RewindCase::query()->where('tenant_company_id',$tenantCompanyId)->where('case_uuid',$caseUuid)->firstOrFail();
        $traceIds = RewindCaseTrace::query()->where('tenant_company_id',$tenantCompanyId)->where('case_id',$case->id)->orderBy('id')->pluck('trace_id')->map(static fn ($v): string => (string) $v)->all();
        if ($case->primary_trace_id && !in_array((string) $case->primary_trace_id,$traceIds,true)) $traceIds[] = (string) $case->primary_trace_id;
        $traceIds = array_values(array_unique(array_filter($traceIds)));
        if ($traceIds === []) throw new InvalidArgumentException('The Rewind case has no explicitly linked traces.');

        $traceBundles = $events = $dependencies = $comparisons = $snapshots = $integritySummaries = $drift = $plans = $receipts = [];
        $worstIntegrity = 'passed';
        $worstSourceCompleteness = 'COMPLETE';
        $caseTruncated = false;
        $totalEventCount = 0;
        $embeddedLimit = 5000;
        foreach ($traceIds as $traceId) {
            $query = RewindTraceQuery::fromArray(['tenant_company_id'=>$tenantCompanyId,'trace_id'=>$traceId]);
            $data = $this->collectTrace($query, $generatedById);
            $totalEventCount += (int)($data['trace']['event_count'] ?? count($data['trace']['events'] ?? []));
            $traceSummary = $data['trace']; unset($traceSummary['events']); $traceBundles[] = $traceSummary;
            $this->appendBounded($events, $data['trace']['events'] ?? [], $embeddedLimit, $caseTruncated);
            $this->appendBounded($dependencies, $data['trace']['dependencies'] ?? [], $embeddedLimit, $caseTruncated);
            $this->appendBounded($comparisons, $data['trace']['snapshot_comparisons'] ?? [], $embeddedLimit, $caseTruncated);
            $this->appendBounded($snapshots, $data['snapshots'], $embeddedLimit, $caseTruncated);
            $integritySummaries[] = $data['integrity_summary'];
            $this->appendBounded($drift, $data['drift'], $embeddedLimit, $caseTruncated);
            $this->appendBounded($plans, $data['plans'], $embeddedLimit, $caseTruncated);
            $this->appendBounded($receipts, $data['receipts'], $embeddedLimit, $caseTruncated);
            $caseTruncated = $caseTruncated || (bool)($data['truncated'] ?? false);
            $worstIntegrity = $this->worseIntegrity($worstIntegrity, (string) $data['integrity_check']->status);
            $traceSourceState = (string)($data['trace']['source_completeness']['state'] ?? 'PARTIAL');
            if ($data['truncated'] ?? false) $traceSourceState = 'PARTIAL';
            $worstSourceCompleteness = $this->worseSourceCompleteness($worstSourceCompleteness, $traceSourceState);
        }
        if ($events === []) throw new InvalidArgumentException('The Rewind case has no evidence-bearing trace events.');

        $trace = [
            'tenant_company_id'=>$tenantCompanyId,
            'trace_id'=>null,
            'trace_ids'=>$traceIds,
            'event_count'=>$totalEventCount,
            'events'=>$events,
            'events_returned'=>count($events),
            'events_truncated'=>$caseTruncated,
            'analysis_scope'=>$caseTruncated ? 'BOUNDED_WINDOW' : 'COMPLETE_CASE',
            'dependencies'=>$dependencies,
            'snapshot_comparisons'=>$comparisons,
            'traces'=>$traceBundles,
            'forensics'=>['status'=>$worstIntegrity === 'failed' ? 'critical' : ($worstIntegrity === 'partial' ? 'review' : 'clear'),'integrity'=>['status'=>$worstIntegrity]],
            'source_completeness'=>['state'=>$caseTruncated ? 'PARTIAL' : $worstSourceCompleteness,'complete_for_audit'=>!$caseTruncated && $worstSourceCompleteness === 'COMPLETE'],
            'mutation_allowed'=>false,
        ];
        $assembled = $this->assembler->assemble(
            packageType: $this->packageType($type),
            trace: $this->sanitizer->sanitize($trace),
            case: $this->sanitizer->sanitize($case->toArray()),
            snapshots: $snapshots,
            integrityChecks: $integritySummaries,
            driftFindings: $drift,
            recoveryPlans: $plans,
            governanceReceipts: $receipts,
            generatedAt: now()->toIso8601String(),
            generatedById: $generatedById,
        );

        return $this->persist(
            tenantCompanyId: $tenantCompanyId,
            scopeType: 'case',
            scopeId: $caseUuid,
            packageType: $this->packageType($type),
            assembled: $assembled,
            traceId: $traceIds[0] ?? null,
            caseId: (int) $case->id,
            integrityCheckUuid: null,
            generatedById: $generatedById,
            ready: !$caseTruncated && $worstIntegrity === 'passed' && $worstSourceCompleteness === 'COMPLETE',
            sourceCompleteness: $caseTruncated ? 'PARTIAL' : $worstSourceCompleteness,
        );
    }

    public function verify(RewindEvidencePackage $package): bool
    {
        $manifest=is_array($package->manifest)?$package->manifest:[];$manifestHash=(string)($manifest['content_hash']??'');
        if($manifestHash===''||!hash_equals((string)$package->content_hash,$manifestHash)||!$this->payloadHashVerified($package))return false;
        $signature=(string)($package->signature??'');$keyId=(string)($package->signature_key_id??'');
        $verified=$signature!==''&&$keyId!==''&&$this->signer->verify((string)$package->content_hash,$signature,$keyId);
        if($verified)$this->custody->record($package,'signature_verified',null,null,['key_id'=>$keyId]);
        return $verified;
    }

    public function decoded(RewindEvidencePackage $package): array
    {
        $payload=json_decode((string)$package->payload_json,true,512,JSON_THROW_ON_ERROR);$hashVerified=$this->payloadHashVerified($package);
        $signatureVerified=$hashVerified&&(string)($package->signature??'')!==''&&$this->signer->verify((string)$package->content_hash,(string)$package->signature,(string)$package->signature_key_id);
        return ['package_uuid'=>$package->package_uuid,'content_hash'=>$package->content_hash,'manifest'=>$package->manifest,'payload'=>$payload,'hash_verified'=>$hashVerified,'signature_verified'=>$signatureVerified,'verified'=>$hashVerified&&$signatureVerified,'source_completeness'=>$package->source_completeness];
    }

    private function payloadHashVerified(RewindEvidencePackage $package): bool
    {
        $raw=(string)$package->payload_json;$manifest=is_array($package->manifest)?$package->manifest:[];
        if((int)($manifest['schema_version']??1)>=2)return hash_equals((string)$package->content_hash,hash('sha256',$raw));
        $payload=json_decode($raw,true,512,JSON_THROW_ON_ERROR);if(!is_array($payload))return false;unset($payload['generated_at'],$payload['generated_by_id']);
        return hash_equals((string)$package->content_hash,hash('sha256',$this->canonicalJson->encode($payload)));
    }

    private function collectTrace(RewindTraceQuery $query, ?int $actorId): array
    {
        $check=$this->integrity->verifyTrace($query,$actorId);$trace=$this->reconstruction->reconstruct($query,true);
        if((int)($trace['event_count']??0)<1)throw new InvalidArgumentException('Cannot generate evidence for an empty Rewind trace.');
        $tenant=$query->tenantCompanyId();$traceId=$query->traceId();
        [$snapshots,$snapshotsTruncated]=$this->boundedMap(RewindSnapshot::query()->where('tenant_company_id',$tenant)->where('trace_id',$traceId)->orderBy('captured_at')->orderBy('id')->lazy(250),fn($m):array=>$this->sanitizer->sanitize($m->toArray()));
        [$findings,$findingsTruncated]=$this->boundedMap(RewindDriftFinding::query()->where('tenant_company_id',$tenant)->where('trace_id',$traceId)->orderBy('detected_at')->orderBy('id')->lazy(250),fn($m):array=>$this->sanitizer->sanitize($m->toArray()));
        [$plans,$plansTruncated]=$this->boundedMap(RewindRecoveryPlan::query()->where('tenant_company_id',$tenant)->where('trace_id',$traceId)->with('steps')->orderBy('id')->lazy(250),fn($m):array=>$this->sanitizer->sanitize($m->toArray()));
        $planIds=array_values(array_filter(array_map(static fn(array $p)=>$p['id']??null,$plans),'is_numeric'));
        [$receipts,$receiptsTruncated]=$planIds===[]?[[],false]:$this->boundedMap(RewindGovernanceReceipt::query()->where('tenant_company_id',$tenant)->whereIn('recovery_plan_id',$planIds)->orderBy('id')->lazy(250),fn($m):array=>$this->sanitizer->sanitize($m->toArray()));
        $sectionsTruncated=$snapshotsTruncated||$findingsTruncated||$plansTruncated||$receiptsTruncated||(bool)($trace['events_truncated']??false);
        if($sectionsTruncated){$trace['source_completeness']['state']='PARTIAL';$trace['source_completeness']['complete_for_audit']=false;$trace['evidence_window_state']='PARTIAL';}
        else{$trace['evidence_window_state']='COMPLETE';}
        $trace['evidence_sections_truncated']=['events'=>(bool)($trace['events_truncated']??false),'snapshots'=>$snapshotsTruncated,'drift'=>$findingsTruncated,'recovery_plans'=>$plansTruncated,'governance_receipts'=>$receiptsTruncated];
        $summary=$this->integritySummary($check);if(isset($trace['forensics'])&&is_array($trace['forensics']))$trace['forensics']['latest_integrity_check']=$summary;
        return ['trace'=>$trace,'snapshots'=>$snapshots,'integrity_check'=>$check,'integrity_summary'=>$summary,'drift'=>$findings,'plans'=>$plans,'receipts'=>$receipts,'truncated'=>$sectionsTruncated];
    }

    private function boundedMap(iterable $rows, callable $map, int $limit=5000): array
    {
        $items=[];$count=0;foreach($rows as $row){++$count;if(count($items)<$limit)$items[]=$map($row);}return [$items,$count>$limit];
    }

    private function appendBounded(array &$target, array $source, int $limit, bool &$truncated): void
    {
        foreach($source as $item){if(count($target)>=$limit){$truncated=true;break;}$target[]=$item;}
        if(count($source)>0 && count($target)>=$limit && count($source)>$limit)$truncated=true;
    }

    private function persist(int $tenantCompanyId, string $scopeType, string $scopeId, string $packageType, array $assembled, ?string $traceId, ?int $caseId, ?string $integrityCheckUuid, ?int $generatedById, bool $ready, string $sourceCompleteness): RewindEvidencePackage
    {
        $contentHash = (string) $assembled['content_hash'];
        $packageKey = hash('sha256', implode('|',[$tenantCompanyId,$scopeType,$scopeId,$packageType,$contentHash,'signed-v1']));
        $existing = RewindEvidencePackage::query()->where('package_key',$packageKey)->first();
        if ($existing) return $existing;
        $this->signingKeys->synchronize();
        $signature = $this->signer->sign($contentHash);
        $this->signingKeys->recordUse((string)$signature['key_id']);
        $previous = RewindEvidencePackage::query()->where('tenant_company_id',$tenantCompanyId)->where('scope_type',$scopeType)->where('scope_id',$scopeId)->where('package_type',$packageType)->latest('generated_at')->first();

        $manifest = $assembled['manifest'];
        $manifest['signature'] = ['algorithm'=>$signature['algorithm'],'key_id'=>$signature['key_id']];
        $manifest['source_completeness'] = $sourceCompleteness;
        $package = RewindEvidencePackage::query()->create([
            'package_uuid'=>(string) Str::uuid(),
            'package_key'=>$packageKey,
            'tenant_company_id'=>$tenantCompanyId,
            'scope_type'=>$scopeType,
            'scope_id'=>$scopeId,
            'case_id'=>$caseId,
            'trace_id'=>$traceId,
            'package_type'=>$packageType,
            'status'=>$ready ? 'ready' : 'review_required',
            'source_completeness'=>$sourceCompleteness,
            'content_hash'=>$contentHash,
            'signature_algorithm'=>$signature['algorithm'],
            'signature_key_id'=>$signature['key_id'],
            'signature'=>$signature['signature'],
            'signed_at'=>now(),
            'manifest'=>$manifest,
            'payload_json'=>$assembled['canonical_payload'],
            'integrity_check_uuid'=>$integrityCheckUuid,
            'generated_at'=>now(),
            'generated_by_id'=>$generatedById,
            'supersedes_package_uuid'=>$previous?->package_uuid,
        ]);
        $this->custody->record($package,'generated',$generatedById,null,['source_completeness'=>$sourceCompleteness]);
        if ($previous) $this->custody->record($previous,'superseded',$generatedById,null,['superseded_by'=>$package->package_uuid]);
        if ($traceId !== null) {
            $ctx=RewindTraceContext::fromArray(['tenant_company_id'=>$tenantCompanyId,'trace_id'=>$traceId,'correlation_id'=>$traceId,'causation_id'=>null]);
            $this->telemetry->metric('rewind.evidence.generated',1,'count',$ctx,['package_type'=>$packageType,'status'=>$package->status,'source_completeness'=>$sourceCompleteness]);
            $this->signals->emit('rewind.evidence.generated.v1',$ctx,['package_uuid'=>$package->package_uuid,'package_type'=>$packageType,'status'=>$package->status,'content_hash'=>$package->content_hash,'source_completeness'=>$sourceCompleteness]);
        }
        return $package;
    }

    private function integritySummary(RewindIntegrityCheck $check): array
    {
        return $this->sanitizer->sanitize([
            'status'=>(string) $check->status,
            'events_checked'=>(int) $check->events_checked,
            'failures_count'=>(int) $check->failures_count,
            'unsealed_count'=>(int) $check->unsealed_count,
            'result'=>is_array($check->result) ? $check->result : [],
        ]);
    }

    private function resolveCase(RewindTraceQuery $query, ?int $caseId): ?RewindCase
    {
        if ($caseId !== null) {
            $case = RewindCase::query()->where('tenant_company_id',$query->tenantCompanyId())->whereKey($caseId)->first();
            if (!$case) throw new InvalidArgumentException('Evidence case does not exist inside the requested tenant boundary.');
            $linked = (string) $case->primary_trace_id === $query->traceId() || RewindCaseTrace::query()->where('tenant_company_id',$query->tenantCompanyId())->where('case_id',$case->id)->where('trace_id',$query->traceId())->exists();
            if (!$linked) throw new InvalidArgumentException('Evidence case is not linked to the requested trace.');
            return $case;
        }
        $case = RewindCase::query()->where('tenant_company_id',$query->tenantCompanyId())->where('primary_trace_id',$query->traceId())->orderBy('id')->first();
        if ($case) return $case;
        $link = RewindCaseTrace::query()->where('tenant_company_id',$query->tenantCompanyId())->where('trace_id',$query->traceId())->orderBy('id')->first();
        return $link ? RewindCase::query()->where('tenant_company_id',$query->tenantCompanyId())->whereKey($link->case_id)->first() : null;
    }

    private function packageType(string $type): string
    {
        $type = strtolower(trim($type));
        if (!in_array($type,['audit','compliance','forensic','incident','dispute'],true)) throw new InvalidArgumentException('Unsupported Titan Rewind evidence package type.');
        return $type;
    }

    private function worseSourceCompleteness(string $left, string $right): string
    {
        $rank = ['COMPLETE'=>0,'PARTIAL'=>1,'STALE'=>2,'UNAVAILABLE'=>3];
        $left = strtoupper($left); $right = strtoupper($right);
        return ($rank[$right] ?? 3) > ($rank[$left] ?? 3) ? $right : $left;
    }

    private function worseIntegrity(string $left, string $right): string
    {
        $rank = ['passed'=>0,'empty'=>1,'partial'=>2,'failed'=>3,'running'=>2,'unknown'=>2];
        $left = strtolower($left); $right = strtolower($right);
        return ($rank[$right] ?? 2) > ($rank[$left] ?? 2) ? $right : $left;
    }
}
