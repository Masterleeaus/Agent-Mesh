<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Entities;

use InvalidArgumentException;

final readonly class PrimeObservation
{
    /**
     * @param list<string> $evidenceReferences
     * @param array<string,mixed> $metadata
     */
    public function __construct(
        public string $observationId,
        public string $missionId,
        public string $signalType,
        public string $summary,
        public array $evidenceReferences = [],
        public array $metadata = [],
        public ?string $observedAt = null,
    ) {
        if (trim($observationId) === '' || trim($missionId) === '' || trim($signalType) === '' || trim($summary) === '') {
            throw new InvalidArgumentException('Observation id, mission id, signal type and summary are required.');
        }
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'observation_id' => $this->observationId,
            'mission_id' => $this->missionId,
            'signal_type' => $this->signalType,
            'summary' => $this->summary,
            'evidence_references' => array_values($this->evidenceReferences),
            'metadata' => $this->metadata,
            'observed_at' => $this->observedAt,
        ];
    }
}
