<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;

/** Resolves the current authoritative version before a command is handed to Titan Command Bus. */
final class CrmExpectedVersionResolver
{
    public function __construct(
        private readonly ConnectionInterface $db,
        private readonly CrmCompanyScope $scope,
        private readonly CrmCapabilityResourceMap $resources,
    ) {}

    public function resolve(string $capability,array $input): ?int
    {
        $supplied=$input['expected_entity_version']??$input['expected_version']??$input['_context']['expected_entity_version']??$input['_context']['expected_version']??null;
        if($supplied!==null && is_numeric($supplied) && (int)$supplied>0)return (int)$supplied;
        $target=$this->resources->before($capability,$input);
        if($target===null)return null;
        try{
            $schema=$this->db->getSchemaBuilder();
            if(!$schema->hasTable($target['table'])||!$schema->hasColumn($target['table'],'entity_version'))return null;
            $version=$this->db->table($target['table'])
                ->where('company_id',$this->scope->current()->companyId)
                ->where('public_id',$target['public_id'])->value('entity_version');
            return is_numeric($version)&&((int)$version)>0?(int)$version:null;
        }catch(\Throwable){return null;}
    }
}
