# Titan Forge Security

Forge treats generated code as untrusted until validation and governance gates complete.

Controls include tenant-scoped BuildContext, idempotency collision rejection, isolated workspaces, path canonicalization, traversal/symlink/case-collision rejection, file/size limits, secret-pattern scanning, unsafe-code primitive checks, JSON/PHP syntax checks, immutable artifact hashes and release-gate fingerprints.

Forge stores no API credentials and has no declared external hosts in this release. Secret-like content is rejected from generated artifacts. Logging and Signal payloads must redact authorization, token, secret, password and signature fields.

No generated artifact gains runtime or deployment authority by being generated. High/consequential release progression requires fresh external governance; unavailable Governance or Command Bus contracts fail closed.


## Model Council disclosure boundary

Forge never sends build instructions, request input payloads, artifact bytes, artifact metadata content, credentials or hidden reasoning to Model Council. The Council packet is bounded to target type, fingerprints/digests, up to 50 artifact paths with hashes/types/sizes, validation counts/status and bounded Risk reasons. Forge persists only sanitized decision metadata plus hashes and rejects any Council result that claims execution authority other than `advisory_only`.
