<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Management;
use App\Extensions\TitanPeople\System\Models\Worker;
use Illuminate\Database\Eloquent\ModelNotFoundException;
final class WorkerManagementService
{
    public function __construct(private readonly WorkerManagementPolicy $policy){}
    /** @param array<string,mixed> $input */
    public function update(int $tenantCompanyId,string $publicId,array $input):void
    {
        $worker=Worker::query()->where('tenant_company_id',$tenantCompanyId)->where('public_id',$publicId)->first();
        if($worker===null) throw (new ModelNotFoundException())->setModel(Worker::class,[$publicId]);
        $worker->fill($this->policy->filter($input));$worker->save();
    }
}
