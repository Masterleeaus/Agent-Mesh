<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Tenancy;

final class TenantIdResolver
{
    /**
     * Resolve only Titan's canonical tenant_company_id.
     * Never fall back to company_id: CRM customer company_id is a different identity.
     *
     * @param array<string,mixed> ...$sources
     */
    public function resolve(array ...$sources): ?int
    {
        foreach ($sources as $source) {
            $value = $source['tenant_company_id'] ?? null;
            if (is_int($value) || is_numeric($value)) {
                $id = (int) $value;
                if ($id > 0) {
                    return $id;
                }
            }
        }
        return null;
    }
}
