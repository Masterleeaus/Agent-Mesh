<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class OutboundDelivery extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use HasUuids;

    protected $table = 'ext_titan_connect_outbound_deliveries';

    protected $fillable = [
        'uuid', 'company_id', 'external_message_id', 'channel_connection_id', 'provider',
        'idempotency_key', 'correlation_id', 'provider_message_id', 'status', 'attempt_count',
        'next_attempt_at', 'sent_at', 'delivered_at', 'read_at', 'last_error', 'provider_response',
    ];

    protected $casts = [
        'attempt_count' => 'integer', 'next_attempt_at' => 'datetime', 'sent_at' => 'datetime',
        'delivered_at' => 'datetime', 'read_at' => 'datetime', 'provider_response' => 'array',
    ];

    public function uniqueIds(): array
    {
        return ['uuid'];
    }

    public function getRouteKeyName(): string
    {
        return 'uuid';
    }

    public function message(): BelongsTo
    {
        return $this->belongsTo(ExternalMessage::class, 'external_message_id');
    }

    public function connection(): BelongsTo
    {
        return $this->belongsTo(ChannelConnection::class, 'channel_connection_id');
    }
}
