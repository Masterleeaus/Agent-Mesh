<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanPrime\System\Domain\Entities\PrimeMission;
use App\Extensions\TitanPrime\System\Domain\Entities\PrimeObjective;
use App\Extensions\TitanPrime\System\Domain\Enums\PrimeMissionStatus;
use App\Extensions\TitanPrime\System\Domain\Exceptions\InvalidMissionTransition;
use App\Extensions\TitanPrime\System\Domain\ValueObjects\PrimeBudget;
use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use PHPUnit\Framework\TestCase;

final class ScaffoldContractTest extends TestCase
{
    public function test_mission_enforces_governed_lifecycle(): void
    {
        $mission = PrimeMission::draft(
            missionId: 'mission-001',
            trace: new TraceContext(7, 'trace-1', 'correlation-1', 'cause-1'),
            objective: new PrimeObjective('growth', 'Increase pipeline', 'More qualified opportunities'),
            budget: new PrimeBudget(maxRiskScore: 0.4),
            initiatedByType: 'user',
            initiatedById: '11',
        );

        self::assertSame(PrimeMissionStatus::Draft, $mission->status());
        $mission->transitionTo(PrimeMissionStatus::Assessing);
        $mission->transitionTo(PrimeMissionStatus::Planned);
        self::assertSame(PrimeMissionStatus::Planned, $mission->status());

        $this->expectException(InvalidMissionTransition::class);
        $mission->transitionTo(PrimeMissionStatus::Completed);
    }

    public function test_trace_context_requires_tenant_and_preserves_causation(): void
    {
        $trace = new TraceContext(21, 'trace-2', 'correlation-2', 'cause-2', 'root-cause-2');

        self::assertSame(21, $trace->tenantCompanyId);
        self::assertSame('cause-2', $trace->toArray()['causation_id']);
        self::assertSame('root-cause-2', $trace->toArray()['root_causation_id']);
    }

    public function test_budget_rejects_risk_above_ceiling(): void
    {
        $budget = new PrimeBudget(maxRiskScore: 0.25);

        self::assertTrue($budget->allowsRisk(0.25));
        self::assertFalse($budget->allowsRisk(0.2501));
    }
}
