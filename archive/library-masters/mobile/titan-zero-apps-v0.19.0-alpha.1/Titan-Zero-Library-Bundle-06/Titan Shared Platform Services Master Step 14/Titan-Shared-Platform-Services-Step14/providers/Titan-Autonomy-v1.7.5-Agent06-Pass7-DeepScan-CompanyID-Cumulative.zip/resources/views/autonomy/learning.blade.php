@extends($layout)
@section('title', 'Titan Learning Settings')
@section('content')
<div class="ta-card"><a href="{{ route('titan-autonomy.index') }}">← Autonomy Learning</a><h1>Titan Learning</h1><p class="ta-muted">Control user, business and optional de-identified system-wide learning.</p>
@if(session('titan_autonomy_status'))<div class="ta-ok">{{ session('titan_autonomy_status') }}</div>@endif</div>
<div class="ta-card"><h2>Learning settings</h2><form method="post" action="{{ route('titan-autonomy.learning.settings') }}">@csrf
<label><input type="checkbox" name="user_learning" value="1" {{ ($settings['user_learning'] ?? true) ? 'checked':'' }}> User learning</label><br><br>
<label><input type="checkbox" name="business_learning" value="1" {{ ($settings['business_learning'] ?? true) ? 'checked':'' }}> Business learning</label><br><br>
<label><input type="checkbox" name="system_wide_learning" value="1" {{ ($settings['system_wide_learning'] ?? false) ? 'checked':'' }} {{ !($platformPolicy['system_wide_learning_permitted'] ?? false) ? 'disabled':'' }}> System-wide learning</label>
@if(!($platformPolicy['system_wide_learning_permitted'] ?? false))<div class="ta-muted">Disabled by platform policy.</div>@endif
<br><label>Learning event retention days <input class="ta-input" style="max-width:160px" type="number" name="learning_event_retention_days" value="{{ $settings['learning_event_retention_days'] ?? '' }}"></label><br><br>
<label>Autonomy evidence retention days <input class="ta-input" style="max-width:160px" type="number" name="autonomy_evidence_retention_days" value="{{ $settings['autonomy_evidence_retention_days'] ?? '' }}"></label><br><br><button class="ta-btn">Save settings</button></form></div>
<div class="ta-card"><h2>Portability</h2><a class="ta-btn secondary" href="{{ route('titan-autonomy.learning.export') }}">Export learning dataset</a>
<form method="post" action="{{ route('titan-autonomy.learning.preferences.clear') }}" style="margin-top:16px">@csrf<label><input type="checkbox" name="confirmed" value="1" required> Clear my learned preferences</label> <button class="ta-btn danger">Clear preferences</button></form></div>
<div class="ta-card"><h2>Learned preferences</h2><table class="ta-table"><thead><tr><th>Scope</th><th>Key</th><th>Confidence</th></tr></thead><tbody>@forelse($preferences as $pref)<tr><td>{{ $pref['scope'] }}</td><td>{{ $pref['preference_key'] }}</td><td>{{ $pref['confidence'] ?? '—' }}</td></tr>@empty<tr><td colspan="3">No learned preferences.</td></tr>@endforelse</tbody></table></div>
<div class="ta-card"><h2>Recent learning events</h2><table class="ta-table"><thead><tr><th>When</th><th>Capability</th><th>Workflow</th><th>Label</th><th>Level</th></tr></thead><tbody>@forelse($events as $event)<tr><td>{{ $event['created_at'] ?? '' }}</td><td>{{ $event['capability'] }}</td><td>{{ $event['workflow_key'] ?: 'default' }}</td><td>{{ $event['learning_label'] }}</td><td>{{ $event['autonomy_level'] }}</td></tr>@empty<tr><td colspan="5">No learning events.</td></tr>@endforelse</tbody></table></div>
@endsection
