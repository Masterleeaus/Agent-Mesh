<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        $this->ensureOwnershipRegistry();
        foreach (['crm_bookkeeping_categories','crm_bookkeeping_transactions'] as $table) {
            if (! Schema::hasTable($table)) continue;
            $this->recordUnknownLegacyOwnership($table);
            $this->canonicalizeCompanyColumn($table);
        }
    }

    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }

    private function canonicalizeCompanyColumn(string $table): void
    {
        $hasCanonical=Schema::hasColumn($table,'company_id');
        $hasLegacy=Schema::hasColumn($table,'tenant_company_id');

        if (! $hasCanonical && $hasLegacy) {
            Schema::table($table,function(Blueprint $t): void {$t->renameColumn('tenant_company_id','company_id');});
            return;
        }

        if ($hasCanonical && $hasLegacy) {
            $conflicts=DB::table($table)->whereNotNull('company_id')->where('company_id','>',0)->whereNotNull('tenant_company_id')->whereColumn('company_id','<>','tenant_company_id')->count();
            if ($conflicts > 0) throw new RuntimeException("Titan Ledger refused to canonicalize {$table}: conflicting company boundaries were found.");
            DB::table($table)->where(function($q){$q->whereNull('company_id')->orWhere('company_id','<=',0);})->whereNotNull('tenant_company_id')->update(['company_id'=>DB::raw('tenant_company_id')]);
            return;
        }

        if (! $hasCanonical) throw new RuntimeException("Titan Ledger refused to adopt {$table}: no company_id boundary exists.");
    }

    private function ensureOwnershipRegistry(): void
    {
        if (Schema::hasTable('titan_ledger_schema_ownership')) return;
        Schema::create('titan_ledger_schema_ownership', function(Blueprint $t): void {
            $t->id();
            $t->string('table_name',190)->unique();
            $t->string('owner_extension',100)->index();
            $t->string('ownership_mode',30)->index();
            $t->timestamp('first_seen_at')->nullable();
            $t->json('metadata')->nullable();
            $t->timestamps();
        });
    }

    private function recordUnknownLegacyOwnership(string $table): void
    {
        if (DB::table('titan_ledger_schema_ownership')->where('table_name',$table)->exists()) return;
        DB::table('titan_ledger_schema_ownership')->insert([
            'table_name'=>$table,'owner_extension'=>'titan-ledger','ownership_mode'=>'legacy_unknown','first_seen_at'=>now(),
            'metadata'=>json_encode(['policy'=>'retain','reason'=>'pre-Pass1 provenance cannot be proven safely']),'created_at'=>now(),'updated_at'=>now(),
        ]);
    }
};
