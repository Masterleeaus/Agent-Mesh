<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use InvalidArgumentException;

final class RewindComplianceExportService
{
    public function __construct(private RewindEvidencePackageService $evidence) {}

    public function generate(RewindTraceQuery $query, ?int $caseId = null, ?int $generatedById = null): RewindEvidencePackage
    {
        return $this->evidence->forTrace($query, 'compliance', $caseId, $generatedById);
    }

    public function generateCase(int $tenantCompanyId, string $caseUuid, ?int $generatedById = null): RewindEvidencePackage
    {
        return $this->evidence->forCase($tenantCompanyId, $caseUuid, 'compliance', $generatedById);
    }

    public function export(RewindEvidencePackage $package): array
    {
        if (!$this->evidence->verify($package)) throw new InvalidArgumentException('Titan Rewind evidence package hash verification failed.');
        $decoded = $this->evidence->decoded($package);
        return [
            'format'=>'titan-rewind-compliance-evidence-v1',
            'package_uuid'=>$package->package_uuid,
            'scope'=>['type'=>$package->scope_type,'id'=>$package->scope_id],
            'content_hash'=>$package->content_hash,
            'verified'=>true,
            'manifest'=>$package->manifest,
            'payload'=>$decoded['payload'],
        ];
    }
}
