# Chatbot Integration

Chatbot owns chatbot identity, persona/instructions, knowledge, customer capabilities, experience, handoff, channel association, preview/readiness and activation. Interaction Engine exposes those as governed capabilities but does not embed Chatbot Builder or query Chatbot models.

No public company-scoped provisioning gateway from the supplied Chatbot build is assumed. Missing gateway = unavailable. No simulated success is returned.
