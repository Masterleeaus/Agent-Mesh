# Titan Rewind Localization

Rewind publishes interface strings through the `titan-rewind::rewind` Laravel translation namespace. English is the bundled source locale in `resources/lang/en/rewind.php`. Host deployments may add corresponding locale files or override translated strings using the normal Laravel localization mechanism.

Forensic evidence is locale-neutral: canonical hashes are calculated from structured source values, IDs, timestamps, reason codes and canonical JSON rather than translated UI labels. Changing the operator locale therefore cannot change an evidence content hash.

Dates persisted by Rewind are normalized for forensic use; locale-specific date and number formatting belongs at the presentation boundary.
