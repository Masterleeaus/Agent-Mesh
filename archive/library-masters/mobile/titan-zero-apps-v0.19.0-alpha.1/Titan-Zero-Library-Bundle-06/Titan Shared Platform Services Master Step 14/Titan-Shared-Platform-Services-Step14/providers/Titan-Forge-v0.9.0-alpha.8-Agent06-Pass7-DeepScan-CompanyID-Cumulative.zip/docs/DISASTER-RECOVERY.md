# Titan Forge Disaster Recovery

Target development-profile recovery objectives: RPO 60 minutes; RTO 240 minutes.

Back up Forge-owned durable database tables plus immutable release evidence/provenance required to reconstruct candidate state. Transient workspace files need not be authoritative if artifact hashes/provenance and the original source inputs are retained.

Restore sequence:

1. place Forge in maintenance/disabled mode and stop new queue dispatch;
2. restore Forge-owned durable tables from the verified backup;
3. restore required release evidence/provenance and configuration;
4. run migrations to the installed Forge version;
5. verify tenant boundaries, integrity hashes and candidate fingerprints;
6. reconcile queued/in-progress builds, marking ambiguous stale work for manual review rather than replaying mutations blindly;
7. verify Signal/Risk/Shield/Governance/Command Bus dependencies;
8. run canonical Blueprint/package certification and Forge health checks;
9. re-enable generation in a canary cohort before general use.

Never reconstruct production deployment authority from a stale Forge workspace alone.
