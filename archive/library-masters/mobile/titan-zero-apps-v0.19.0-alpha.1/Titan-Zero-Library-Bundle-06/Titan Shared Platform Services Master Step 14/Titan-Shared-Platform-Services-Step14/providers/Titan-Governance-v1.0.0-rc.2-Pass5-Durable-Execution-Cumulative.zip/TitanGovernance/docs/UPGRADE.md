# Upgrade

Titan Governance uses expand → migrate → contract upgrades and preserves governance/audit history by default.

## v0.4.0 → v0.5.0

Migration `2026_08_20_000004_add_governed_action_metadata.php` expands existing Governance tables with:

- policy-decision operation/idempotency and command-receipt metadata;
- escalation optimistic version and last-decision/receipt metadata.

Existing rows remain valid. New `operation_id` fields are nullable for historical compatibility; all v0.5.0 runtime-created action decisions supply a non-null operation ID. The tenant + operation unique key prevents new duplicate operations while allowing historical null values.

Do not delete existing Governance decision, escalation or projection rows during upgrade. If the migration is interrupted, use the installer/migration recovery workflow and inspect schema state before forward-fixing; do not manually purge audit data.
