<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/AnomalyFinding.php';
require __DIR__ . '/../System/Data/AnomalyThresholds.php';
require __DIR__ . '/../System/Services/AnomalyRuleEvaluator.php';

use App\Extensions\TitanSignalEngine\System\Data\AnomalyThresholds;
use App\Extensions\TitanSignalEngine\System\Services\AnomalyRuleEvaluator;

function anomalyAssert(bool $condition, string $message): void {
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

$rules = new AnomalyRuleEvaluator(new AnomalyThresholds());

$failures = $rules->evaluate([
    'source' => 'titan-command-bus',
    'error_count_5m' => 7,
    'loop_event_count' => 0,
    'retry_wait_count' => 0,
    'dead_letter_count' => 0,
    'stalled_trace_count' => 0,
    'missing_receipt_count' => 0,
    'override_count_1h' => 0,
    'sequence_violation_count' => 0,
    'unresolved_causation_count' => 0,
    'baseline_ready' => false,
    'baseline_events_per_5m' => 0.0,
    'events_last_5m' => 0,
]);
anomalyAssert(count($failures) === 1, 'Seven source errors in five minutes must produce exactly one repeated-failure anomaly.');
anomalyAssert($failures[0]->type === 'repeated_failures', 'Repeated failures must use the canonical anomaly type.');
anomalyAssert($failures[0]->severity === 'high', 'Repeated failures above threshold must be high severity.');
anomalyAssert($failures[0]->confidence >= 0.7, 'Rule-based anomaly confidence must be explicit.');

$loop = $rules->evaluate([
    'trace_id' => '018f7f22-1111-7111-8111-111111111111',
    'event_type' => 'command.retry_requested',
    'error_count_5m' => 0,
    'loop_event_count' => 12,
    'retry_wait_count' => 0,
    'dead_letter_count' => 0,
    'stalled_trace_count' => 0,
    'missing_receipt_count' => 0,
    'override_count_1h' => 0,
    'sequence_violation_count' => 0,
    'unresolved_causation_count' => 0,
    'baseline_ready' => false,
    'baseline_events_per_5m' => 0.0,
    'events_last_5m' => 0,
]);
anomalyAssert(count($loop) === 1 && $loop[0]->type === 'execution_loop', 'Repeated event types in one trace must detect execution loops.');

$cold = $rules->evaluate([
    'error_count_5m' => 0,
    'loop_event_count' => 0,
    'retry_wait_count' => 0,
    'dead_letter_count' => 0,
    'stalled_trace_count' => 0,
    'missing_receipt_count' => 0,
    'override_count_1h' => 0,
    'sequence_violation_count' => 0,
    'unresolved_causation_count' => 0,
    'baseline_ready' => false,
    'baseline_events_per_5m' => 100.0,
    'events_last_5m' => 0,
]);
anomalyAssert($cold === [], 'Volume collapse must not alert during cold start.');

$collapse = $rules->evaluate([
    'error_count_5m' => 0,
    'loop_event_count' => 0,
    'retry_wait_count' => 0,
    'dead_letter_count' => 0,
    'stalled_trace_count' => 0,
    'missing_receipt_count' => 0,
    'override_count_1h' => 0,
    'sequence_violation_count' => 0,
    'unresolved_causation_count' => 0,
    'baseline_ready' => true,
    'baseline_events_per_5m' => 100.0,
    'events_last_5m' => 10,
]);
anomalyAssert(count($collapse) === 1 && $collapse[0]->type === 'event_volume_collapse', 'A >=80% volume collapse after baseline maturity must be detected.');

$integrity = $rules->evaluate([
    'error_count_5m' => 0,
    'loop_event_count' => 0,
    'retry_wait_count' => 0,
    'dead_letter_count' => 0,
    'stalled_trace_count' => 0,
    'missing_receipt_count' => 0,
    'override_count_1h' => 0,
    'sequence_violation_count' => 2,
    'unresolved_causation_count' => 1,
    'baseline_ready' => false,
    'baseline_events_per_5m' => 0.0,
    'events_last_5m' => 0,
]);
anomalyAssert(count($integrity) === 2, 'Sequence and causation integrity findings must remain separate anomalies.');
anomalyAssert(in_array('sequence_violation', array_map(fn ($x) => $x->type, $integrity), true), 'Sequence violation anomaly missing.');
anomalyAssert(in_array('trace_integrity', array_map(fn ($x) => $x->type, $integrity), true), 'Trace integrity anomaly missing.');

$keys = array_map(fn ($x) => $x->deduplicationKey('tenant', 42), $integrity);
anomalyAssert(count(array_unique($keys)) === count($keys), 'Different anomaly types must have different deduplication keys.');


$missingRequired = $rules->evaluate([
    'trace_id' => '018f7f22-2222-7222-8222-222222222222',
    'sequence_violation_count' => 0,
    'missing_required_event_count' => 2,
]);
anomalyAssert(count($missingRequired) === 1, 'Terminal trace with missing required events must create one missing-required anomaly.');
anomalyAssert($missingRequired[0]->type === 'required_event_missing', 'Missing required events must use the canonical required_event_missing anomaly type.');
anomalyAssert($missingRequired[0]->subjectType === 'trace', 'Missing required event anomaly must be trace-scoped.');

fwrite(STDOUT, "anomaly-behavior: PASS\n");
