<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Reconstruction;

use InvalidArgumentException;

final class RewindTraceQuery
{
    private function __construct(
        private readonly int $tenantCompanyId,
        private readonly string $traceId,
        private readonly ?string $correlationId,
    ) {
    }

    public static function fromArray(array $input): self
    {
        $tenantCompanyId = (int) ($input['tenant_company_id'] ?? 0);
        if ($tenantCompanyId < 1) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }

        $traceId = trim((string) ($input['trace_id'] ?? ''));
        self::assertUuid($traceId, 'trace_id');

        $correlationId = isset($input['correlation_id']) ? trim((string) $input['correlation_id']) : null;
        if ($correlationId === '') {
            $correlationId = null;
        }
        if ($correlationId !== null) {
            self::assertUuid($correlationId, 'correlation_id');
        }

        return new self($tenantCompanyId, $traceId, $correlationId);
    }

    public function tenantCompanyId(): int
    {
        return $this->tenantCompanyId;
    }

    public function traceId(): string
    {
        return $this->traceId;
    }

    public function correlationId(): ?string
    {
        return $this->correlationId;
    }

    public function toArray(): array
    {
        return [
            'tenant_company_id' => $this->tenantCompanyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
        ];
    }

    private static function assertUuid(string $value, string $field): void
    {
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value)) {
            throw new InvalidArgumentException("{$field} must be a UUID.");
        }
    }
}
