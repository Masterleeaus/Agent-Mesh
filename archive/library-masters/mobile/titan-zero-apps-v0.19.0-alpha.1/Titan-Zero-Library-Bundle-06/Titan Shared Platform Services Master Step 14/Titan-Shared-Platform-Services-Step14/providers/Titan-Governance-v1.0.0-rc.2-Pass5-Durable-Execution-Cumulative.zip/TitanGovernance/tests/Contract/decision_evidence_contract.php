<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function fail_de(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function ok_de(bool $c,string $m):void{if(!$c)fail_de($m);}function same_de(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_de($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
foreach([
 '/System/Contracts/GovernanceDecisionEvidenceSourceContract.php',
 '/System/DecisionIntelligence/GovernanceDecisionEvidenceRegistry.php',
 '/System/DecisionIntelligence/UnavailableDecisionEvidenceSource.php',
 '/System/DecisionIntelligence/GovernanceEvidenceSanitizer.php',
] as $f){if(!is_file($root.$f))fail_de('missing production file '.$f);require_once $root.$f;}

use App\Extensions\TitanGovernance\System\Contracts\GovernanceDecisionEvidenceSourceContract;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceDecisionEvidenceRegistry;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceEvidenceSanitizer;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\UnavailableDecisionEvidenceSource;

final class DESource implements GovernanceDecisionEvidenceSourceContract{
 public function __construct(private string $k){} public function key():string{return $this->k;} public function required():bool{return false;}
 public function decisionEvidence(int $tenantCompanyId,string $decisionId,array $context=[]):array{return ['status'=>'HEALTHY','tenant_company_id'=>$tenantCompanyId,'decision_id'=>$decisionId,'events'=>[]];}
}
$r=new GovernanceDecisionEvidenceRegistry();$r->register(new DESource('titan-risk'));same_de('titan-risk',$r->get('titan-risk')?->key(),'registry lookup');
$duplicate=false;try{$r->register(new DESource('titan-risk'));}catch(InvalidArgumentException){$duplicate=true;}ok_de($duplicate,'duplicate source key must be rejected');
$u=new UnavailableDecisionEvidenceSource('titan-rewind',false,'NOT_INSTALLED');$us=$u->decisionEvidence(42,'gdec-1');same_de('NOT_INSTALLED',$us['status'],'unavailable source status');same_de([],$us['events'],'unavailable source cannot fabricate events');

$s=new GovernanceEvidenceSanitizer(maxDepth:5,maxItems:20,maxStringLength:64);
$clean=$s->sanitize([
 'reason_codes'=>['POLICY_BLOCK'],
 'summary'=>'bounded summary',
 'chain_of_thought'=>'private',
 'reasoning'=>'private2',
 'prompt'=>'secret prompt',
 'raw_response'=>['text'=>'private response'],
 'api_key'=>'sk-secret',
 'authorization'=>'Bearer secret',
 'nested'=>['access_token'=>'abc','evidence_ref'=>'ev-1','safe'=>'ok'],
]);
ok_de(isset($clean['reason_codes']),'structured reason codes must survive');same_de('bounded summary',$clean['summary'],'safe summary survives');
foreach(['chain_of_thought','reasoning','prompt','raw_response','api_key','authorization'] as $k)ok_de(!array_key_exists($k,$clean),'sensitive key must be removed: '.$k);
ok_de(!array_key_exists('access_token',$clean['nested']),'nested token must be removed');same_de('ev-1',$clean['nested']['evidence_ref'],'evidence reference survives');

echo "PASS: Governance decision evidence boundary\n";
