<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_connect_conversations')) {
            Schema::create('ext_titan_connect_conversations', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('name')->nullable();
                $table->string('slug')->nullable();
                $table->string('type', 32)->default('direct')->index();
                $table->string('avatar', 2048)->nullable();
                $table->text('description')->nullable();
                $table->string('category', 120)->nullable();
                $table->unsignedBigInteger('owner_id')->nullable()->index();
                $table->string('visibility', 20)->default('private');
                $table->string('posting_policy', 32)->default('members');
                $table->boolean('is_announcement')->default(false);
                $table->string('linked_entity_type', 120)->nullable();
                $table->string('linked_entity_id', 191)->nullable();
                $table->timestamp('channel_archived_at')->nullable();
                $table->boolean('is_archived')->default(false)->index();
                $table->unsignedBigInteger('version')->default(1);
                $table->unsignedBigInteger('sync_sequence')->default(0)->index();
                $table->string('originating_device_id', 191)->nullable()->index();
                $table->unsignedBigInteger('created_by')->nullable();
                $table->unsignedBigInteger('updated_by')->nullable();
                $table->string('legacy_source', 64)->nullable();
                $table->unsignedBigInteger('legacy_id')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->unique(['company_id', 'slug'], 'tc_conversations_company_slug_unique');
                $table->unique(['legacy_source', 'legacy_id'], 'tc_conversations_legacy_unique');
                $table->index(['company_id', 'type', 'updated_at'], 'tc_conversations_lookup_idx');
                $table->index(['company_id', 'linked_entity_type', 'linked_entity_id'], 'tc_linked_room_idx');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_participants')) {
            Schema::create('ext_titan_connect_participants', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('conversation_id')->constrained('ext_titan_connect_conversations')->cascadeOnDelete();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('user_id')->index();
                $table->string('role', 20)->default('member');
                $table->timestamp('last_read_at')->nullable();
                $table->timestamp('joined_at')->nullable();
                $table->timestamp('left_at')->nullable();
                $table->boolean('is_muted')->default(false);
                $table->boolean('is_pinned')->default(false);
                $table->timestamp('archived_at')->nullable();
                $table->string('legacy_source', 64)->nullable();
                $table->unsignedBigInteger('legacy_id')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->unique(['conversation_id', 'user_id'], 'tc_participants_unique');
                $table->unique(['legacy_source', 'legacy_id'], 'tc_participants_legacy_unique');
                $table->index(['company_id', 'user_id', 'archived_at'], 'tc_participants_inbox_idx');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_messages')) {
            Schema::create('ext_titan_connect_messages', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid');
                $table->unsignedBigInteger('company_id')->index();
                $table->foreignId('conversation_id')->constrained('ext_titan_connect_conversations')->cascadeOnDelete();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->longText('body')->nullable();
                $table->string('message_type', 30)->default('text');
                $table->foreignId('reply_to_id')->nullable()->constrained('ext_titan_connect_messages')->nullOnDelete();
                $table->json('metadata')->nullable();
                $table->unsignedBigInteger('version')->default(1);
                $table->unsignedBigInteger('sync_sequence')->default(0)->index();
                $table->string('originating_device_id', 191)->nullable()->index();
                $table->timestamp('edited_at')->nullable();
                $table->unsignedBigInteger('created_by')->nullable();
                $table->unsignedBigInteger('updated_by')->nullable();
                $table->string('legacy_source', 64)->nullable();
                $table->unsignedBigInteger('legacy_id')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->unique(['company_id', 'uuid'], 'tc_messages_company_uuid_unique');
                $table->unique(['legacy_source', 'legacy_id'], 'tc_messages_legacy_unique');
                $table->index(['conversation_id', 'created_at', 'id'], 'tc_message_order_idx');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_message_reads')) {
            Schema::create('ext_titan_connect_message_reads', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('message_id')->constrained('ext_titan_connect_messages')->cascadeOnDelete();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('user_id')->index();
                $table->timestamp('read_at')->useCurrent();
                $table->string('legacy_source', 64)->nullable();
                $table->unsignedBigInteger('legacy_id')->nullable();
                $table->timestamps();
                $table->unique(['message_id', 'user_id'], 'tc_message_reads_unique');
                $table->unique(['legacy_source', 'legacy_id'], 'tc_message_reads_legacy_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_channel_connections')) {
            Schema::create('ext_titan_connect_channel_connections', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('provider', 40)->index();
                $table->string('display_name')->nullable();
                $table->string('external_account_id')->nullable();
                $table->string('credential_reference', 191)->nullable();
                $table->string('status', 24)->default('active')->index();
                $table->json('settings')->nullable();
                $table->timestamp('last_health_checked_at')->nullable();
                $table->timestamp('last_inbound_at')->nullable();
                $table->timestamp('last_outbound_at')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->unique(['company_id', 'provider', 'external_account_id'], 'tc_channel_account_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_channel_members')) {
            Schema::create('ext_titan_connect_channel_members', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('channel_connection_id')->constrained('ext_titan_connect_channel_connections')->cascadeOnDelete();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('user_id')->index();
                $table->string('role', 24)->default('agent')->index();
                $table->timestamp('joined_at')->nullable();
                $table->timestamp('left_at')->nullable();
                $table->timestamps();
                $table->unique(['channel_connection_id', 'user_id'], 'tc_channel_members_unique');
                $table->index(['company_id', 'user_id', 'left_at'], 'tc_channel_members_access_idx');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_external_threads')) {
            Schema::create('ext_titan_connect_external_threads', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->foreignId('channel_connection_id')->constrained('ext_titan_connect_channel_connections')->cascadeOnDelete();
                $table->string('provider', 40)->index();
                $table->string('provider_thread_id', 191);
                $table->string('external_contact_ref', 191)->nullable()->index();
                $table->string('display_name')->nullable();
                $table->string('linked_entity_type', 120)->nullable();
                $table->string('linked_entity_id', 191)->nullable();
                $table->string('status', 24)->default('open')->index();
                $table->json('metadata')->nullable();
                $table->timestamp('last_message_at')->nullable()->index();
                $table->timestamps();
                $table->softDeletes();
                $table->unique(['channel_connection_id', 'provider_thread_id'], 'tc_external_thread_unique');
                $table->index(['company_id', 'linked_entity_type', 'linked_entity_id'], 'tc_external_link_idx');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_external_messages')) {
            Schema::create('ext_titan_connect_external_messages', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->foreignId('external_thread_id')->constrained('ext_titan_connect_external_threads')->cascadeOnDelete();
                $table->string('provider', 40)->index();
                $table->string('provider_message_id', 191)->nullable()->index();
                $table->string('direction', 12)->index();
                $table->string('sender_ref', 191)->nullable();
                $table->string('recipient_ref', 191)->nullable();
                $table->longText('body')->nullable();
                $table->string('message_type', 30)->default('text');
                $table->string('status', 24)->default('received')->index();
                $table->string('correlation_id', 64)->nullable()->index();
                $table->json('metadata')->nullable();
                $table->timestamp('provider_created_at')->nullable();
                $table->timestamps();
                $table->unique(['company_id', 'provider', 'provider_message_id'], 'tc_external_provider_message_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_external_thread_reads')) {
            Schema::create('ext_titan_connect_external_thread_reads', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('external_thread_id')->constrained('ext_titan_connect_external_threads', 'id', 'tc_ext_reads_thread_fk')->cascadeOnDelete();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('user_id')->index();
                $table->foreignId('last_read_message_id')->nullable()->constrained('ext_titan_connect_external_messages', 'id', 'tc_ext_reads_last_msg_fk')->nullOnDelete();
                $table->timestamp('last_read_at')->nullable();
                $table->timestamps();
                $table->unique(['external_thread_id', 'user_id'], 'tc_external_thread_reads_unique');
                $table->index(['company_id', 'user_id', 'last_read_at'], 'tc_external_thread_reads_lookup_idx');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_outbound_deliveries')) {
            Schema::create('ext_titan_connect_outbound_deliveries', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->foreignId('external_message_id')->constrained('ext_titan_connect_external_messages', 'id', 'tc_out_delivery_msg_fk')->cascadeOnDelete();
                $table->foreignId('channel_connection_id')->constrained('ext_titan_connect_channel_connections', 'id', 'tc_out_delivery_conn_fk')->cascadeOnDelete();
                $table->string('provider', 40)->index();
                $table->string('idempotency_key', 191);
                $table->string('correlation_id', 64)->index();
                $table->string('provider_message_id', 191)->nullable()->index();
                $table->string('status', 24)->default('queued')->index();
                $table->unsignedInteger('attempt_count')->default(0);
                $table->timestamp('next_attempt_at')->nullable()->index();
                $table->timestamp('sent_at')->nullable();
                $table->timestamp('delivered_at')->nullable();
                $table->timestamp('read_at')->nullable();
                $table->text('last_error')->nullable();
                $table->json('provider_response')->nullable();
                $table->timestamps();
                $table->unique(['company_id', 'idempotency_key'], 'tc_outbound_idempotency_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_webhook_events')) {
            Schema::create('ext_titan_connect_webhook_events', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->foreignId('channel_connection_id')->constrained('ext_titan_connect_channel_connections')->cascadeOnDelete();
                $table->string('provider', 40)->index();
                $table->string('provider_event_id', 191);
                $table->string('event_type', 80)->nullable()->index();
                $table->char('payload_hash', 64)->index();
                $table->string('status', 24)->default('received')->index();
                $table->text('failure_reason')->nullable();
                $table->timestamp('processed_at')->nullable();
                $table->timestamps();
                $table->unique(['company_id', 'channel_connection_id', 'provider', 'provider_event_id'], 'tc_webhook_event_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_attachments')) {
            Schema::create('ext_titan_connect_attachments', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->foreignId('message_id')->nullable()->constrained('ext_titan_connect_messages')->cascadeOnDelete();
                $table->foreignId('external_message_id')->nullable()->constrained('ext_titan_connect_external_messages')->cascadeOnDelete();
                $table->string('storage_disk', 80);
                $table->string('storage_path', 2048);
                $table->string('original_name')->nullable();
                $table->string('mime_type', 191)->nullable();
                $table->unsignedBigInteger('size_bytes')->default(0);
                $table->char('sha256', 64)->nullable()->index();
                $table->string('scan_status', 24)->default('pending')->index();
                $table->json('provider_media')->nullable();
                $table->timestamp('expires_at')->nullable()->index();
                $table->timestamps();
                $table->index(['company_id', 'message_id'], 'tc_attachment_internal_idx');
                $table->index(['company_id', 'external_message_id'], 'tc_attachment_external_idx');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_audit_logs')) {
            Schema::create('ext_titan_connect_audit_logs', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('actor_id')->nullable()->index();
                $table->string('action', 120)->index();
                $table->string('subject_type', 120)->nullable();
                $table->string('subject_id', 191)->nullable();
                $table->string('correlation_id', 64)->nullable()->index();
                $table->json('metadata')->nullable();
                $table->timestamp('created_at')->useCurrent()->index();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_connect_audit_logs');
        Schema::dropIfExists('ext_titan_connect_attachments');
        Schema::dropIfExists('ext_titan_connect_webhook_events');
        Schema::dropIfExists('ext_titan_connect_outbound_deliveries');
        Schema::dropIfExists('ext_titan_connect_external_thread_reads');
        Schema::dropIfExists('ext_titan_connect_external_messages');
        Schema::dropIfExists('ext_titan_connect_external_threads');
        Schema::dropIfExists('ext_titan_connect_channel_members');
        Schema::dropIfExists('ext_titan_connect_channel_connections');
        Schema::dropIfExists('ext_titan_connect_message_reads');
        Schema::dropIfExists('ext_titan_connect_messages');
        Schema::dropIfExists('ext_titan_connect_participants');
        Schema::dropIfExists('ext_titan_connect_conversations');
    }
};
