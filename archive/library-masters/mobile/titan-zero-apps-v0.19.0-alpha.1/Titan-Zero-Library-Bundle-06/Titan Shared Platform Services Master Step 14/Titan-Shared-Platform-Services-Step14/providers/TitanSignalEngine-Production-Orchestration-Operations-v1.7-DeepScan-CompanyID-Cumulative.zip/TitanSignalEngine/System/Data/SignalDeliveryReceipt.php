<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use DateTimeImmutable;

final readonly class SignalDeliveryReceipt
{
    public function __construct(
        public string $deliveryId,
        public string $eventId,
        public string $subscriberKey,
        public string $status,
        public int $attemptCount,
        public ?DateTimeImmutable $nextAttemptAt = null,
        public ?string $error = null,
    ) {
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'delivery_id' => $this->deliveryId,
            'event_id' => $this->eventId,
            'subscriber_key' => $this->subscriberKey,
            'status' => $this->status,
            'attempt_count' => $this->attemptCount,
            'next_attempt_at' => $this->nextAttemptAt?->format(DATE_ATOM),
            'error' => $this->error,
        ];
    }
}
