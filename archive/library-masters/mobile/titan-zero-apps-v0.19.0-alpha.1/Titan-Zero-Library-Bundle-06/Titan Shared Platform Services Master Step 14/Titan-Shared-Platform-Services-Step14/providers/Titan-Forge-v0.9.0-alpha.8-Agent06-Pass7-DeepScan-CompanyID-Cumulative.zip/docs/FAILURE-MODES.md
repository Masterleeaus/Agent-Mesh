# Titan Forge Failure Modes

| Failure | Required behavior |
|---|---|
| Tenant/actor context missing | Reject before build registration. |
| Idempotency key reused with different spec | Reject collision; never overwrite original result. |
| Unsafe workspace path/symlink/case collision | Reject artifact publication. |
| Generated secret/unsafe primitive/syntax error | Persist validation finding; no release candidate. |
| Signal emission unavailable | Report degraded governance telemetry; never fabricate an event receipt. |
| Shield blocking finding | Reject release candidate progression. |
| Risk DENY | Reject release candidate. |
| Risk approval/hold directive | `approval_required`; do not execute. |
| Council governed-deliberation contract unavailable | Hold high/critical candidate. |
| Council role-model policy missing/partial/under-diverse | Fail closed as `configuration_required`; do not deliberate. |
| Council deliberation escalates/fails/rejects | Hold high/critical candidate for Governance; do not execute. |
| Council claims mutation/deployment authority | Reject the Council evidence and hold progression; Forge/Council authority remains advisory. |
| Governance callable decision API unavailable | Fail closed / approval hold. |
| Command Bus callable release API unavailable | Fail closed; no direct deployment fallback. |
| Queue worker failure | Mark build failed with bounded retry semantics; preserve evidence. |
