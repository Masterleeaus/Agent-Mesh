<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\AI\Tools;

final class CrmToolRegistry
{
    public function tools(): array
    {
        return [
            ['name'=>'crm_search_contacts','mode'=>'read','description'=>'Search CRM contacts.'],
            ['name'=>'crm_search_companies','mode'=>'read','description'=>'Search CRM companies.'],
            ['name'=>'crm_search_leads','mode'=>'read','description'=>'Search CRM leads.'],
            ['name'=>'crm_list_pipelines','mode'=>'read','description'=>'List CRM sales pipelines.'],
            ['name'=>'crm_view_pipeline_board','mode'=>'read','description'=>'View a CRM pipeline board.'],
            ['name'=>'crm_search_deals','mode'=>'read','description'=>'Search CRM deals.'],
            ['name'=>'crm_list_activities','mode'=>'read','description'=>'List CRM activity for a record.'],
            ['name'=>'crm_get_dashboard','mode'=>'read','description'=>'Read CRM dashboard metrics and follow-up signals.'],
            ['name'=>'crm_get_analytics','mode'=>'read','description'=>'Read six-month CRM trend, funnel and sales metrics.'],
            ['name'=>'crm_get_timeline','mode'=>'read','description'=>'Read the unified activity and notes timeline for a CRM record.'],
            ['name'=>'crm_search_projects','mode'=>'read','description'=>'Search CRM projects.'],
            ['name'=>'crm_search_tasks','mode'=>'read','description'=>'Search CRM tasks.'],
            ['name'=>'crm_search_calendar','mode'=>'read','description'=>'Search CRM calendar events.'],
            ['name'=>'crm_search_sales_documents','mode'=>'read','description'=>'Search proposals, estimates, invoices or payment receipts.'],
            ['name'=>'crm_create_company','mode'=>'write','description'=>'Create a CRM company.'],
            ['name'=>'crm_create_contact','mode'=>'write','description'=>'Create a CRM contact.'],
            ['name'=>'crm_create_lead','mode'=>'write','description'=>'Create a CRM lead.'],
            ['name'=>'crm_create_deal','mode'=>'write','description'=>'Create a CRM deal.'],
            ['name'=>'crm_move_deal','mode'=>'write','description'=>'Move a CRM deal to another stage.'],
            ['name'=>'crm_record_activity','mode'=>'write','description'=>'Record a CRM activity.'],
            ['name'=>'crm_create_note','mode'=>'write','description'=>'Add a note to an authorised CRM record.'],
            ['name'=>'crm_create_project','mode'=>'write','description'=>'Create a CRM project.'],
            ['name'=>'crm_create_task','mode'=>'write','description'=>'Create a CRM task.'],
            ['name'=>'crm_create_calendar_event','mode'=>'write','description'=>'Create a CRM calendar event.'],
        ];
    }
}
