<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
final class StoreDealRequest extends FormRequest {
 public function authorize(): bool { return true; }
 public function rules(): array { return ['name'=>['required','string','max:255'],'description'=>['nullable','string'],'company_public_id'=>['nullable','string','size:26'],'contact_public_id'=>['nullable','string','size:26'],'pipeline_public_id'=>['nullable','string','size:26'],'stage_public_id'=>['nullable','string','size:26'],'value_minor'=>['nullable','integer','min:0'],'currency'=>['nullable','string','size:3'],'owner_user_id'=>['nullable','integer','min:1'],'probability'=>['nullable','integer','between:0,100'],'position'=>['nullable','integer','min:0'],'expected_close_date'=>['nullable','date'],'metadata'=>['nullable','array']]; }
}
