<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterAuthorityContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use InvalidArgumentException;

final class SignalContextValidator
{
    public function __construct(private readonly SignalEmitterAuthorityContract $emitterAuthority)
    {
    }
    /** @param array<string,mixed> $input @return array<string,mixed> */
    public function applyToInput(array $input, SignalContext $context): array
    {
        $eventType = trim((string) ($input['event_type'] ?? ''));
        $this->assertEmitterAllowed($eventType, $context);

        $requestedScope = (string) ($input['scope'] ?? $context->scope);
        $requestedTenant = $input['tenant_company_id'] ?? $context->tenantCompanyId;
        $requestedTenant = $requestedTenant === null || $requestedTenant === '' ? null : (int) $requestedTenant;

        if ($context->scope === SignalEnvelope::SCOPE_TENANT) {
            if ($requestedScope !== SignalEnvelope::SCOPE_TENANT || $requestedTenant !== $context->tenantCompanyId) {
                throw new InvalidArgumentException('Authenticated tenant context cannot emit outside its tenant boundary.');
            }
        } elseif ($requestedScope === SignalEnvelope::SCOPE_TENANT) {
            if (! $context->hasPermission('signal.tenant.emit') || $requestedTenant === null) {
                throw new InvalidArgumentException('System context requires signal.tenant.emit permission to emit tenant signals.');
            }
        } elseif ($requestedScope !== SignalEnvelope::SCOPE_SYSTEM) {
            throw new InvalidArgumentException('Unsupported signal scope.');
        }

        $claimed = $input['actor'] ?? null;
        if (is_array($claimed)) {
            $this->assertActorClaimsMatch($claimed, $context);
        } else {
            $this->assertLegacyActorClaimsMatch($input, $context);
        }
        $this->assertEmitterClaimsMatch($input, $context);

        $input['scope'] = $requestedScope;
        $input['tenant_company_id'] = $requestedTenant;
        $input['actor'] = $context->actor->toArray();
        $input['actor_type'] = $context->actor->type;
        $input['actor_id'] = $context->actor->id;
        $input['actor_identity_provider'] = $context->actor->identityProvider;
        $input['actor_session_id'] = $context->actor->sessionId;
        $input['source'] = $context->emitter->source;
        $input['source_component'] = $context->emitter->sourceComponent;
        $input['emitter_id'] = $context->emitter->serviceId;

        return $input;
    }

    public function validateEnvelope(SignalEnvelope $signal, SignalContext $context): void
    {
        $this->assertEmitterAllowed($signal->eventType, $context);

        if ($context->scope === SignalEnvelope::SCOPE_TENANT) {
            if ($signal->scope !== SignalEnvelope::SCOPE_TENANT || $signal->tenantCompanyId !== $context->tenantCompanyId) {
                throw new InvalidArgumentException('Signal envelope does not match authenticated tenant context.');
            }
        } elseif ($signal->scope === SignalEnvelope::SCOPE_TENANT && ! $context->hasPermission('signal.tenant.emit')) {
            throw new InvalidArgumentException('System context lacks permission to emit tenant signals.');
        }

        if ($signal->actor === null || $signal->actor->toArray() !== $context->actor->toArray()) {
            throw new InvalidArgumentException('Signal envelope actor does not match authenticated actor context.');
        }
        if ($signal->source !== $context->emitter->source || $signal->sourceComponent !== $context->emitter->sourceComponent || $signal->emitterId !== $context->emitter->serviceId) {
            throw new InvalidArgumentException('Signal envelope source/emitter identity does not match authenticated emitter identity.');
        }
    }

    public function assertQueryAllowed(string $scope, ?int $tenantCompanyId, ?SignalContext $context): void
    {
        if ($context === null) {
            throw new InvalidArgumentException('Signal queries require an authenticated SignalContext.');
        }

        if ($scope === SignalEnvelope::SCOPE_SYSTEM) {
            if ($context->scope !== SignalEnvelope::SCOPE_SYSTEM || ! $context->hasPermission('signal.system.read')) {
                throw new InvalidArgumentException('System signal queries require signal.system.read permission.');
            }
            return;
        }

        if ($scope !== SignalEnvelope::SCOPE_TENANT || $tenantCompanyId === null || $tenantCompanyId < 1) {
            throw new InvalidArgumentException('Tenant signal queries require a valid tenant_company_id.');
        }
        if ($context->scope === SignalEnvelope::SCOPE_TENANT && $context->tenantCompanyId !== $tenantCompanyId) {
            throw new InvalidArgumentException('Authenticated tenant context cannot query another tenant.');
        }
        if ($context->scope === SignalEnvelope::SCOPE_SYSTEM && ! $context->hasPermission('signal.tenant.read')) {
            throw new InvalidArgumentException('System context requires signal.tenant.read permission for tenant signal queries.');
        }
    }

    public function assertEmitterAllowed(string $eventType, SignalContext $context): void
    {
        if ($context->emitter === null) {
            throw new InvalidArgumentException('Signal emission requires an authenticated emitter identity.');
        }
        $this->emitterAuthority->assertTrusted($context->emitter);
        if (! $context->emitter->hasPermission('signal.emit')) {
            throw new InvalidArgumentException('Authenticated emitter lacks signal.emit permission.');
        }
        if ($eventType === '' || ! $context->emitter->allowsEventType($eventType)) {
            throw new InvalidArgumentException('Authenticated emitter is not permitted to emit this event type.');
        }
    }

    /** @param array<string,mixed> $input */
    private function assertEmitterClaimsMatch(array $input, SignalContext $context): void
    {
        $emitter = $context->emitter;
        if ($emitter === null) {
            throw new InvalidArgumentException('Signal emission requires an authenticated emitter identity.');
        }
        if (array_key_exists('source', $input) && (string) $input['source'] !== $emitter->source) {
            throw new InvalidArgumentException('Signal source claim does not match authenticated emitter identity.');
        }
        if (array_key_exists('emitter_id', $input) && (string) $input['emitter_id'] !== $emitter->serviceId) {
            throw new InvalidArgumentException('Signal emitter_id claim does not match authenticated emitter identity.');
        }
        if (array_key_exists('source_component', $input)) {
            $claimed = $input['source_component'] === null || $input['source_component'] === '' ? null : (string) $input['source_component'];
            if ($claimed !== $emitter->sourceComponent) {
                throw new InvalidArgumentException('Signal source_component claim does not match authenticated emitter identity.');
            }
        }
    }

    /** @param array<string,mixed> $claimed */
    private function assertActorClaimsMatch(array $claimed, SignalContext $context): void
    {
        $trusted = $context->actor->toArray();
        foreach (['id', 'type', 'tenant_company_id', 'identity_provider', 'session_id'] as $key) {
            if (! array_key_exists($key, $claimed)) continue;
            $actual = $claimed[$key];
            if ($key === 'tenant_company_id' && $actual !== null && is_numeric($actual)) $actual = (int) $actual;
            if ($actual !== $trusted[$key]) {
                throw new InvalidArgumentException("Signal actor claim {$key} does not match authenticated context.");
            }
        }
    }

    /** @param array<string,mixed> $input */
    private function assertLegacyActorClaimsMatch(array $input, SignalContext $context): void
    {
        $pairs = [
            'actor_id' => $context->actor->id,
            'actor_type' => $context->actor->type,
            'actor_identity_provider' => $context->actor->identityProvider,
            'actor_session_id' => $context->actor->sessionId,
        ];
        foreach ($pairs as $key => $trusted) {
            if (array_key_exists($key, $input) && $input[$key] !== $trusted) {
                throw new InvalidArgumentException("Signal actor claim {$key} does not match authenticated context.");
            }
        }
    }
}
