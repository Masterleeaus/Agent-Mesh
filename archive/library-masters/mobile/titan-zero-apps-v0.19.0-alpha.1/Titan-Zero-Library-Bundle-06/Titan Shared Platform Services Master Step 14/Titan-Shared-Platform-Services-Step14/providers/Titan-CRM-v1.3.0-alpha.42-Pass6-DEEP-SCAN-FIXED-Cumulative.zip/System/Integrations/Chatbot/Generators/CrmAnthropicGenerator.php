<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\Chatbot\Generators;

use App\Domains\Entity\Enums\EntityEnum;
use App\Extensions\Chatbot\System\Generators\AnthropicGenerator;
use App\Extensions\Chatbot\System\Tools\KnowledgeBase;
use App\Extensions\ChatbotEcommerce\System\Services\EcommerceToolService;
use App\Extensions\Crm\System\Integrations\Chatbot\CrmChatbotToolService;
use App\Helpers\Classes\MarketplaceHelper;
use Exception;
use Psr\Http\Message\StreamInterface;

final class CrmAnthropicGenerator extends AnthropicGenerator
{
    public function tools(): array
    {
        $base=parent::tools();$crm=app(CrmChatbotToolService::class);
        return $crm->enabledForChatbot($this->chatbot)?array_merge($base,$crm->definitionsForAnthropic($this->chatbot)):$base;
    }

    public function generate(): string
    {
        $crm=app(CrmChatbotToolService::class);if(!$crm->enabledForChatbot($this->chatbot))return parent::generate();
        $histories=array_values($this->modifyMessages());$build=$this->buildHistories($histories);$system=$this->extractSystemMessage($build);$messages=$this->removeSystemMessages($build);
        $body=['model'=>$this->entity->value,'max_tokens'=>4096,'messages'=>$messages,'tools'=>$this->tools()];if($system)$body['system']=$system;
        $result=$this->chat($body);$uses=$this->extractToolUses($result);if($uses===[])return $this->extractText($result)?:'Sorry, I can\'t answer that.';
        $messages[]=['role'=>'assistant','content'=>$result->json('content',[])];$results=[];$ecommerceUi=null;$hasKnowledge=false;$hasCrm=false;
        foreach($uses as $use){$name=(string)$use['name'];
            if(MarketplaceHelper::isRegistered('chatbot-ecommerce')){$data=app(EcommerceToolService::class)->handleAnthropicToolCallWithUi($this->chatbot,$name,$use['input']);if($data!==null){$ecommerceUi=$data['ui'];$results[]=['type'=>'tool_result','tool_use_id'=>$use['id'],'content'=>$data['ai_content']];continue;}}
            if(str_starts_with($name,'crm_')){try{$data=$crm->execute($this->chatbot,$this->conversation,$name,(array)$use['input']);if($data!==null){$hasCrm=true;$results[]=['type'=>'tool_result','tool_use_id'=>$use['id'],'content'=>$data['ai_content']];continue;}}catch(\Throwable $e){$hasCrm=true;$results[]=['type'=>'tool_result','tool_use_id'=>$use['id'],'content'=>json_encode(['ok'=>false,'error'=>$e->getMessage()])];continue;}}
            if($name==='knowledge_base'&&isset($this->embeddings)&&$this->embeddings->isNotEmpty()){$hasKnowledge=true;$args=(array)$use['input'];$content=app(KnowledgeBase::class)->setChatbot($this->chatbot)->call(EntityEnum::from($this->chatbot->getAttribute('ai_embedding_model')),(string)($args['query']??''),$this->embeddings);$results[]=['type'=>'tool_result','tool_use_id'=>$use['id'],'content'=>$content];}
        }
        if($results===[])return $this->extractText($result)?:'Sorry, I can\'t answer that.';
        if($ecommerceUi!==null&&!$hasKnowledge&&!$hasCrm){$text=implode(' ',array_column($results,'content'));return '<p>'.e($text).'</p>'.$ecommerceUi;}
        $messages[]=['role'=>'user','content'=>$results];$body['messages']=$messages;$body['stream']=true;unset($body['tools']);$response=$this->chat($body)->toPsrResponse();$text='';
        while(!$response->getBody()->eof()){$line=$this->crmReadLine($response->getBody());if(!str_starts_with($line,'data:'))continue;$data=trim(substr($line,5));if($data==='')continue;$json=json_decode($data,flags:JSON_THROW_ON_ERROR);if(isset($json->error))throw new Exception($json->error->message);if(($json->type??null)==='content_block_delta'&&isset($json->delta->text))$text.=$json->delta->text;}
        $answer=$text?:'Sorry, I can\'t answer that.';return $ecommerceUi!==null?'<p>'.e($answer).'</p>'.$ecommerceUi:$answer;
    }

    private function crmReadLine(StreamInterface $stream): string
    { $buffer='';while(!$stream->eof()){if(''===($byte=$stream->read(1)))return $buffer;$buffer.=$byte;if($byte==="\n")break;}return $buffer; }
}
