<?php
declare(strict_types=1);

$GLOBALS['tcb_test_config'] = [
    'titan-command-bus.enabled' => true,
    'titan-command-bus.require_lifecycle' => false,
    'titan-command-bus.kill_switch' => false,
    'titan-command-bus.max_payload_bytes' => 65536,
    'titan-command-bus.allow_offline_revalidation' => true,
    'titan-command-bus.require_signal' => true,
    'titan-command-bus.require_risk' => true,
    'titan-command-bus.require_assurance' => true,
    'titan-command-bus.require_autonomy' => true,
];
if (!function_exists('config')) {
    function config(string $key, mixed $default = null): mixed { return $GLOBALS['tcb_test_config'][$key] ?? $default; }
}

$root=dirname(__DIR__,2);
foreach ([
    'System/DTO/CommandContext.php','System/DTO/CommandRequest.php','System/DTO/RiskDecision.php','System/DTO/AssuranceDecision.php','System/DTO/AutonomyDecision.php','System/DTO/GovernanceDecision.php','System/DTO/CommandExecutionResult.php','System/DTO/CommandReceipt.php',
    'System/Contracts/CommandAdapterContract.php','System/Contracts/CommandAdapterRegistryContract.php','System/Contracts/CommandRiskGateContract.php','System/Contracts/CommandAssuranceGateContract.php','System/Contracts/CommandAutonomyGateContract.php','System/Contracts/CommandGovernanceGateContract.php','System/Contracts/CommandReceiptStoreContract.php','System/Contracts/CommandSignalEmitterContract.php','System/Contracts/CommandBusContract.php',
    'System/Contracts/CommandLifecycleStoreContract.php','System/Services/CommandLifecycleState.php','System/Services/CommandBus.php',
] as $rel) require_once $root.'/'.$rel;

use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterRegistryContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAssuranceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAutonomyGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandRiskGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandGovernanceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandReceiptStoreContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandSignalEmitterContract;
use App\Extensions\TitanCommandBus\System\DTO\AssuranceDecision;
use App\Extensions\TitanCommandBus\System\DTO\AutonomyDecision;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandExecutionResult;
use App\Extensions\TitanCommandBus\System\DTO\CommandReceipt;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use App\Extensions\TitanCommandBus\System\DTO\GovernanceDecision;
use App\Extensions\TitanCommandBus\System\DTO\RiskDecision;
use App\Extensions\TitanCommandBus\System\Services\CommandBus;

final class AutoTestAdapter implements CommandAdapterContract {
    public int $calls=0;
    public function capability(): string { return 'crm.invoice.create'; }
    public function execute(CommandContext $context, CommandRequest $request, string $operationId): CommandExecutionResult {
        $this->calls++;
        return new CommandExecutionResult('crm:invoice:111', true, 111, 'invoice', 8);
    }
}
final class AutoTestRegistry implements CommandAdapterRegistryContract {
    public function __construct(public AutoTestAdapter $adapter) {}
    public function register(CommandAdapterContract $adapter): void {}
    public function has(string $capability): bool { return $capability===$this->adapter->capability(); }
    public function forCapability(string $capability): ?CommandAdapterContract { return $this->has($capability)?$this->adapter:null; }
    public function count(): int { return 1; }
}
final class AutoTestRisk implements CommandRiskGateContract {
    public int $calls=0;
    public function available(): bool { return true; }
    public function assess(CommandContext $context, CommandRequest $request): RiskDecision { $this->calls++; return new RiskDecision(true,'risk:11','MEDIUM',0.44); }
}
final class AutoTestAssurance implements CommandAssuranceGateContract {
    public int $calls=0;
    public function available(): bool { return true; }
    public function assess(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null): AssuranceDecision { $this->calls++; return new AssuranceDecision(true,'assurance:11','POLICY',['evidence:11']); }
}
final class AutoTestAutonomy implements CommandAutonomyGateContract {
    public int $calls=0;
    public function __construct(public bool $isAvailable, public string $mode='allow') {}
    public function available(): bool { return $this->isAvailable; }
    public function resolve(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null, ?AssuranceDecision $assurance = null): AutonomyDecision {
        $this->calls++;
        return match($this->mode) {
            'deny' => new AutonomyDecision(false,'autonomy:deny','ASSIST','completed_job_invoice',['evidence:insufficient'],'AUTONOMY_DENIED'),
            'malformed' => new AutonomyDecision(true,null,'AUTO','completed_job_invoice',[]),
            'invalid-level' => new AutonomyDecision(true,'autonomy:bad','ROOT','completed_job_invoice',[]),
            default => new AutonomyDecision(true,'autonomy:11','AUTO','completed_job_invoice',['streak:17','policy:autonomy:3']),
        };
    }
}
final class AutoTestGovernance implements CommandGovernanceGateContract {
    public int $calls=0;
    public ?string $lastAutonomyReference=null;
    public ?string $lastAutonomyLevel=null;
    public function available(): bool { return true; }
    public function evaluate(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null, ?AssuranceDecision $assurance = null, ?AutonomyDecision $autonomy = null): GovernanceDecision {
        $this->calls++;
        $this->lastAutonomyReference=$autonomy?->reference;
        $this->lastAutonomyLevel=$autonomy?->level;
        return new GovernanceDecision(true,'gov:11',null,'approval:11');
    }
}
final class AutoTestStore implements CommandReceiptStoreContract {
    public array $claims=[];
    private function key(CommandContext $c, CommandRequest $r): string { return $c->tenantCompanyId.'|'.$r->idempotencyKey; }
    public function existing(CommandContext $context, CommandRequest $request): ?array { return $this->claims[$this->key($context,$request)] ?? null; }
    public function claim(CommandContext $context, CommandRequest $request, string $operationId, string $requestHash): bool { $k=$this->key($context,$request); if(isset($this->claims[$k])) return false; $this->claims[$k]=['request_hash'=>$requestHash,'operation_id'=>$operationId,'status'=>'processing','receipt'=>null]; return true; }
    public function complete(CommandReceipt $receipt): void { $k=$receipt->tenantCompanyId.'|'.$receipt->idempotencyKey; $this->claims[$k]['status']=$receipt->status; $this->claims[$k]['receipt']=$receipt->toArray(); }
    public function health(): array { return ['receipts_table'=>true,'idempotency_table'=>true]; }
}
final class AutoTestSignals implements CommandSignalEmitterContract {
    public array $events=[];
    public function available(): bool { return true; }
    public function emit(string $type, array $payload): void { $this->events[$type]=$payload; }
}

$ctx=new CommandContext(42,'agent','ar-agent','titan-workforce');
$risk=new AutoTestRisk(); $assurance=new AutoTestAssurance(); $signals=new AutoTestSignals();
$adapter=new AutoTestAdapter(); $registry=new AutoTestRegistry($adapter);

$autonomy=new AutoTestAutonomy(false); $gov=new AutoTestGovernance();
$bus=new CommandBus($registry,$risk,$assurance,$gov,new AutoTestStore(),$signals,$autonomy);
$blocked=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>900],'auto-unavailable','t1','c1','cause1','root1'));
if($blocked->status!=='blocked'||$blocked->reasonCode!=='AUTONOMY_UNAVAILABLE'||$adapter->calls!==0||$gov->calls!==0||$risk->calls!==1||$assurance->calls!==1) throw new RuntimeException('autonomy unavailable must fail closed after risk/assurance but before governance and adapter');

$gov=new AutoTestGovernance();
$bus=new CommandBus($registry,$risk,$assurance,$gov,new AutoTestStore(),$signals,new AutoTestAutonomy(true,'malformed'));
$malformed=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>900],'auto-malformed','t2','c2','cause2','root2'));
if($malformed->status!=='blocked'||$malformed->reasonCode!=='AUTONOMY_DECISION_INVALID'||$gov->calls!==0||$adapter->calls!==0) throw new RuntimeException('malformed autonomy allow without durable reference must fail closed');

$gov=new AutoTestGovernance();
$bus=new CommandBus($registry,$risk,$assurance,$gov,new AutoTestStore(),$signals,new AutoTestAutonomy(true,'invalid-level'));
$invalidLevel=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>900],'auto-invalid-level','ti','ci','causei','rooti'));
if($invalidLevel->status!=='blocked'||$invalidLevel->reasonCode!=='AUTONOMY_DECISION_INVALID'||$gov->calls!==0||$adapter->calls!==0) throw new RuntimeException('non-canonical autonomy level must fail closed');

$gov=new AutoTestGovernance(); $deny=new AutoTestAutonomy(true,'deny');
$bus=new CommandBus($registry,$risk,$assurance,$gov,new AutoTestStore(),$signals,$deny);
$denied=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>900],'auto-denied','t3','c3','cause3','root3'));
if($denied->status!=='blocked'||$denied->reasonCode!=='AUTONOMY_DENIED'||$denied->autonomyReference!=='autonomy:deny'||$denied->autonomyLevel!=='ASSIST'||$denied->autonomyWorkflow!=='completed_job_invoice'||$gov->calls!==0||$adapter->calls!==0) throw new RuntimeException('autonomy denial must be durable and stop before governance');

$adapter2=new AutoTestAdapter(); $registry2=new AutoTestRegistry($adapter2); $gov=new AutoTestGovernance(); $signals=new AutoTestSignals();
$bus=new CommandBus($registry2,$risk,$assurance,$gov,new AutoTestStore(),$signals,new AutoTestAutonomy(true,'allow'));
$applied=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>900],'auto-allow','t4','c4','cause4','root4'));
if($applied->status!=='applied'||$applied->autonomyReference!=='autonomy:11'||$applied->autonomyLevel!=='AUTO'||$applied->autonomyWorkflow!=='completed_job_invoice'||$applied->autonomyEvidence!==['streak:17','policy:autonomy:3']||$gov->calls!==1||$gov->lastAutonomyReference!=='autonomy:11'||$gov->lastAutonomyLevel!=='AUTO'||$adapter2->calls!==1) throw new RuntimeException('earned autonomy evidence must flow into governance and successful receipt');
if(($signals->events['command.completed']['autonomy_reference']??null)!=='autonomy:11'||($signals->events['command.completed']['autonomy_level']??null)!=='AUTO') throw new RuntimeException('autonomy evidence must propagate into command outcome Signal telemetry');
$health=$bus->health(); if(($health['dependencies']['autonomy']??null)!==true) throw new RuntimeException('health must report autonomy dependency readiness');

echo "PASS AutonomyIntegrationTest\n";
