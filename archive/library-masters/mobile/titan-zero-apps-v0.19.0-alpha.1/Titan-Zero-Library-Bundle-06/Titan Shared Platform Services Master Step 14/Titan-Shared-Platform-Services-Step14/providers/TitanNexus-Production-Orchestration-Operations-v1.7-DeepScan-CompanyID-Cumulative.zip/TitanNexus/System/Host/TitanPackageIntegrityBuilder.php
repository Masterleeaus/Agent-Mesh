<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Host;

use FilesystemIterator;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

final class TitanPackageIntegrityBuilder
{
    /** @return array<string,string> */
    public static function build(string $root): array
    {
        $root = rtrim(realpath($root) ?: $root, DIRECTORY_SEPARATOR);
        $files = [];
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $file) {
            if (!$file->isFile() || $file->isLink()) {
                continue;
            }
            $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
            if ($relative === 'extension.json') {
                continue;
            }
            $files[$relative] = hash_file('sha256', $file->getPathname());
        }
        ksort($files, SORT_STRING);
        return $files;
    }
}
