<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);function fail_wo(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function same_wo(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_wo($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}function ok_wo(bool $c,string $m):void{if(!$c)fail_wo($m);}
$f=$root.'/System/ControlCentre/WorkforceOversightProjector.php';if(!is_file($f))fail_wo('missing WorkforceOversightProjector');require_once $f;
use App\Extensions\TitanGovernance\System\ControlCentre\WorkforceOversightProjector;
$p=new WorkforceOversightProjector();
$missing=$p->project(['titan-ai-workforce'=>['status'=>'NOT_INSTALLED','required'=>false,'control_centre'=>[]]]);
same_wo('NOT_INSTALLED',$missing['status'],'missing workforce status');same_wo([], $missing['members'],'missing workforce must not fabricate members');
$src=['titan-ai-workforce'=>['source'=>'titan-ai-workforce','required'=>false,'status'=>'HEALTHY','observed_at'=>'2026-08-21T03:55:00+10:00','control_centre'=>[
 'organisation_graph'=>['nodes'=>[
  ['id'=>7,'name'=>'Collections Specialist','role'=>'collections','tier'=>'SPECIALIST','division'=>'Finance','manager_id'=>2,'manager'=>'Finance Manager','status'=>'WORKING','maturity'=>'PROVEN','risk_ceiling'=>'HIGH'],
  ['id'=>2,'name'=>'Finance Manager','role'=>'finance-manager','tier'=>'MANAGER','division'=>'Finance','manager_id'=>null,'manager'=>null,'status'=>'AVAILABLE','maturity'=>'TRUSTED','risk_ceiling'=>'HIGH'],
 ],'edges'=>[['source'=>2,'target'=>7,'type'=>'MANAGES','metadata'=>['authority_inherited'=>true]]]],
 'queues'=>[['manager_id'=>2,'manager'=>'Finance Manager','division'=>'Finance','health'=>['queue_depth'=>12,'review_count'=>3,'blocked_count'=>1,'overdue_count'=>2,'pressure'=>'HIGH','oldest_task_minutes'=>95]]],
 'handoffs'=>[['id'=>41,'task_id'=>55,'status'=>'ESCALATED','updated_at'=>'2026-08-21T02:00:00+10:00','origin_manager_id'=>2,'receiver_manager_id'=>9]],
 'approvals'=>[['id'=>55,'task_uuid'=>'task-55','title'=>'Review overdue accounts','status'=>'UNDER_REVIEW','manager_id'=>2,'priority'=>90,'updated_at'=>'2026-08-21T02:15:00+10:00']],
 'performance'=>[['member_id'=>7,'maturity'=>['recommended_level'=>'TRUSTED'],'authority_changed'=>false]],
 'summary'=>['active_staff'=>2,'divisions'=>1,'pending_approvals'=>1,'open_handoffs'=>1,'staffing_recommendations'=>0],
]]];
$r=$p->project($src);
same_wo('HEALTHY',$r['status'],'healthy workforce');same_wo(2,count($r['members']),'member count');same_wo(1,count($r['queues']),'queue count');same_wo(1,count($r['approvals']),'approval count');same_wo(1,count($r['handoffs']),'handoff count');same_wo(false,$r['can_raise_authority'],'workforce cannot raise authority');same_wo(false,$r['authority_changed'],'projector cannot change authority');
$edge=$r['relationships'][0]??[];same_wo(false,$edge['authority_inherited']??null,'hierarchy must never imply authority inheritance');
$member=$r['members'][0]??[];ok_wo(array_key_exists('maturity',$member),'maturity may remain visible');same_wo(false,$member['maturity_changes_authority']??null,'maturity visibility is authority-neutral');
echo "PASS: Governance Workforce oversight contract\n";
