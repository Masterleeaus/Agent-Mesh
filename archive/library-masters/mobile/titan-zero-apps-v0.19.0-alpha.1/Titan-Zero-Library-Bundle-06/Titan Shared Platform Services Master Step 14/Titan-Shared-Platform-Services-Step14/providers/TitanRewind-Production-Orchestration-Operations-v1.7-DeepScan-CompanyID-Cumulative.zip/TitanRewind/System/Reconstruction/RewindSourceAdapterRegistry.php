<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Reconstruction;

use App\Extensions\TitanRewind\System\Contracts\RewindSourceAdapterContract;
use App\Extensions\TitanRewind\System\Contracts\RewindSourceWatermarkProviderContract;
use InvalidArgumentException;

final class RewindSourceAdapterRegistry
{
    /** @var array<string, RewindSourceAdapterContract> */
    private array $adapters = [];

    public function register(RewindSourceAdapterContract $adapter): void
    {
        $key = trim($adapter->key());
        if ($key === '') {
            throw new InvalidArgumentException('Rewind source adapter keys cannot be empty.');
        }
        if (isset($this->adapters[$key]) && $this->adapters[$key] !== $adapter) {
            throw new InvalidArgumentException("A Rewind source adapter is already registered for {$key}.");
        }
        $this->adapters[$key] = $adapter;
    }

    public function has(string $key): bool { return isset($this->adapters[trim($key)]); }

    /** @return array<string, RewindSourceAdapterContract> */
    public function all(): array
    {
        ksort($this->adapters, SORT_STRING);
        return $this->adapters;
    }

    /** @return list<array{source:string,state:string,observed_through:?string,source_lag_seconds:?int,metadata?:array<string,mixed>}> */
    public function watermarks(RewindTraceQuery $query): array
    {
        $result = [];
        foreach ($this->all() as $key => $adapter) {
            if (!$adapter instanceof RewindSourceWatermarkProviderContract) {
                $result[] = ['source'=>$key,'state'=>'PARTIAL','observed_through'=>null,'source_lag_seconds'=>null,'metadata'=>['reason'=>'adapter-does-not-provide-watermark']];
                continue;
            }
            $watermark = $adapter->watermark($query);
            $state = strtoupper((string)($watermark['state'] ?? 'UNAVAILABLE'));
            if (!in_array($state,['COMPLETE','PARTIAL','STALE','UNAVAILABLE'],true)) {
                throw new InvalidArgumentException("Invalid Rewind source watermark state from {$key}.");
            }
            $result[] = [
                'source'=>$key,'state'=>$state,'observed_through'=>isset($watermark['observed_through'])?(string)$watermark['observed_through']:null,
                'source_lag_seconds'=>isset($watermark['source_lag_seconds'])?(int)$watermark['source_lag_seconds']:null,
                'metadata'=>is_array($watermark['metadata'] ?? null)?$watermark['metadata']:[],
            ];
        }
        return $result;
    }

    /** @return iterable<RewindEventRecord> */
    public function records(RewindTraceQuery $query): iterable
    {
        foreach ($this->all() as $adapter) {
            foreach ($adapter->records($query) as $record) {
                if (!$record instanceof RewindEventRecord) {
                    throw new InvalidArgumentException('Rewind source adapters must yield RewindEventRecord instances.');
                }
                yield $record;
            }
        }
    }
}
