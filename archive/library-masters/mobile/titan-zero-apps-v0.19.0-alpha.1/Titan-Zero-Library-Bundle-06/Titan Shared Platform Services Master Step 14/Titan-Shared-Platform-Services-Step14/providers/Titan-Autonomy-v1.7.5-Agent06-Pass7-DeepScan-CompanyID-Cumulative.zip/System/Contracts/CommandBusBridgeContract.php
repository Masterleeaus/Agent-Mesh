<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface CommandBusBridgeContract
{
    /** Execute only after current autonomy/scope and Interaction Engine readiness have been revalidated. */
    public function dispatch(object $command, array $authorityContext): mixed;
}
