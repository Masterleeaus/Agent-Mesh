# Capabilities

Titan People exposes read capabilities plus governed mutation/proposal contracts. Capability payloads never accept caller-controlled `tenant_company_id`; tenant authority comes from trusted authenticated Titan context.

## Authoritative People mutations

- `people.lifecycle.mutate` — HIGH risk lifecycle transition.
- `people.leave.mutate` — MEDIUM risk leave mutation.
- `people.documents.manage` — private People document management.
- `people.holidays.manage` — holiday calendar management.
- `people.worker.create.from-hire` — governed Recruit ingress for worker/employment creation.
- `people.policy.acknowledge` — governed acknowledgement fact ingress.

## AI Workforce proposal capabilities

- `people.lifecycle.propose`
- `people.leave.propose`
- `people.records.propose`

AI tools may create recommendations/tasks and prepare Command Bus proposals. They cannot self-approve, silently terminate/suspend workers, alter leave balances, increase autonomy, or bypass Risk/Assurance/Autonomy. State-changing Workforce tools declare `execution=command_bus` and require independent approval.
