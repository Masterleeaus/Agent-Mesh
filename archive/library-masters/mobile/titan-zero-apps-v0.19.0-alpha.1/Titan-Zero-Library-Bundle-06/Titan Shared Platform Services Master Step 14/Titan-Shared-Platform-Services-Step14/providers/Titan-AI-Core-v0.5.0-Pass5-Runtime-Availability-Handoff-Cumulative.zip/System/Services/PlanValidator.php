<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Services;

use App\Extensions\TitanAICore\System\Contracts\PlanValidatorContract;
use App\Extensions\TitanAICore\System\DTO\PlanEnvelope;
use App\Extensions\TitanAICore\System\DTO\ValidationIssue;
use App\Extensions\TitanAICore\System\DTO\ValidationReport;

final class PlanValidator implements PlanValidatorContract
{
    public function validate(PlanEnvelope $plan): ValidationReport
    {
        if (!$plan->runtimeContext->actor->trusted) {
            return new ValidationReport(
                valid: false,
                executable: false,
                errors: [new ValidationIssue('error', 'UNTRUSTED_ACTOR_CONTEXT', 'Plan actor context was not derived from a trusted authenticated principal.')],
                warnings: [],
                suggestions: [new ValidationIssue('suggestion', 'REBUILD_TRUSTED_CONTEXT', 'Recreate RuntimeContext from the host-authenticated principal before validation.')],
            );
        }

        if (!hash_equals($plan->runtimeContext->tenantCompanyId, $plan->runtimeContext->actor->tenantCompanyId)) {
            return new ValidationReport(
                valid: false,
                executable: false,
                errors: [new ValidationIssue('error', 'TENANT_CONTEXT_MISMATCH', 'Actor tenant and runtime tenant do not match.')],
                warnings: [],
                suggestions: [new ValidationIssue('suggestion', 'REBUILD_TRUSTED_CONTEXT', 'Resolve actor and tenant from the same trusted principal.')],
            );
        }

        return new ValidationReport(
            valid: false,
            executable: false,
            errors: [new ValidationIssue('error', 'DAG_VALIDATOR_NOT_IMPLEMENTED', 'Typed plan accepted, but deterministic DAG validation is not implemented yet.')],
            warnings: [],
            suggestions: [new ValidationIssue('suggestion', 'NEXT_PASS_REQUIRED', 'Run the deterministic DAG validation pass before execution.')],
        );
    }
}
