<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_signal_events')) { return; }
        Schema::create('titan_signal_events', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
            $table->uuid('trace_id')->nullable()->index();
            $table->uuid('correlation_id')->nullable()->index();
            $table->string('type', 120)->default('record')->index();
            $table->string('status', 40)->default('scaffold')->index();
            $table->json('payload')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_events');
    }
};
