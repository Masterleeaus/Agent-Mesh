# Titan Signal Correlation Engine Implementation Plan

> **For agentic workers:** implement task-by-task with tests first and preserve the v0.2.1 immutable event foundation.

**Goal:** Add tenant-safe causal graph projection, trace/workflow reconstruction, trace profiles, completeness analysis, sequence validation, and Rewind-ready correlation receipts.

**Architecture:** Immutable SignalEvent remains authoritative. `titan_signal_causal_edges` is an idempotent read projection written at ingest; `TraceAnalyzer` performs framework-independent causal ordering/completeness checks; `CorrelationService` applies authenticated query boundaries and returns read projections. Trace profiles define expected workflow shape without making Signal the workflow authority.

**Tech Stack:** PHP 8.2+, Laravel 10/Eloquent, MySQL-compatible migrations, UUID event identities.

## Global Constraints

- Never mutate existing SignalEvent rows.
- Never permit causation across scope, tenant, trace, or correlation boundaries.
- Causation order outranks `occurred_at`; `recorded_at` is ingestion chronology only.
- Keep cross-tenant correlation unsupported.
- No graph database, custom queue, ML detector, or alert transport in this pass.

### Task 1: Pure trace analysis
- [x] Write failing behavior runner for causal ordering, ancestry, descendants, missing parents, sequence rules, and cycles.
- [x] Implement `TraceProfile`, `TraceAnalysis`, and `TraceAnalyzer`.
- [x] Run behavior runner to GREEN.

### Task 2: Persistence projections
- [x] Add causal-edge and trace-profile models/tables.
- [x] Project edges idempotently during event append, including late parent arrival.
- [x] Reject causal cycles at the store boundary.

### Task 3: Correlation service
- [x] Add authenticated `SignalCorrelationContract`.
- [x] Implement ancestors, descendants, trace and workflow projections.
- [x] Resolve optional trace profiles and return completeness/sequence diagnostics.

### Task 4: Runtime verification and packaging
- [x] Add Laravel integration tests for edges, late-parent projection, cycle rejection and tenant isolation.
- [x] Update provider, manifest, config, README and upgrade report.
- [x] Lint, run framework-independent tests, scan boundaries, ZIP integrity-check, and package cumulative release.
