## v0.20.0-rc.8.1 — Blade Shared Error-Bag Hotfix

The live rc.8 Overview failed inside MagicAI's `panel.layout.app` because the child Blade assigned the numeric Signal error count to `$errors`, replacing Laravel's shared `ViewErrorBag`; the host layout then called `$errors->any()` on an integer. rc.8.1 renames that metric to `$errorCount` and renders all eight Super Admin pages from the fresh `admin-rc8-1` namespace so stale compiled rc.8 child templates cannot survive the update. No migration is added.

## v0.20.0-rc.8 — Super Admin Console Information Architecture and Card UI

rc.8 preserves Signal runtime contracts and adds one Super Admin parent plus eight real child menu rows/routes. The overview is status-first, tenant company ID is conditional on tenant scope, and governed mutations are isolated to their relevant child surfaces. Migration 22 self-heals `menus.parent_id` relationships and host certification now verifies the parent plus all eight children.

## v0.20.0-rc.7 — Blade Compiled-Cache Isolation Hotfix

rc.6 installed successfully and placed Signal Engine correctly in Super Admin, but the host continued executing an older compiled rc.5 Blade containing `<x-layouts.app>`. rc.7 switches controller rendering to versioned `admin-rc7` / `index-rc7` source paths and performs a targeted cleanup of only stale compiled Signal legacy views containing `layouts.app`. No migration is added.

## v0.20.0-rc.6 — Super Admin Placement & MagicAI Blade Layout Hotfix

The rc.5 package installed and created a user-sidebar link, but Signal Engine is platform infrastructure and its operational console belongs in Super Admin. The first page render also failed because MagicAI 10.91 does not provide `<x-layouts.app>`. rc.6 deletes the rc.5 user menu row, repairs/retains the Super Admin row, registers only `navigation.admin`, and converts both shipped Blade views to `@extends('panel.layout.app')`. The tenant read-only Pulse route remains available for future embedding/direct governed use but is intentionally not advertised in the user menu.

## v0.20.0-rc.6 — Self-Healing Host Navigation Hotfix

The rc.4 package installed successfully on the live Installer 1.7.8 host but no Signal menu links appeared. Root cause: `SignalUserNavigation` and `SignalAdminNavigation` existed and were declared in the Blueprint sidecar, but `TitanSignalEngineServiceProvider` never registered either contribution and never synchronised MagicAI's database-backed `menus` table. rc.5 adds modern contribution-registry registration, durable `menus` self-healing, menu-cache regeneration, migration 20 for already-installed hosts, `titan:signal:host-sync`, and a host-certification navigation gate. Full production-host certification remains pending until all 20 packaged migrations plus `titan:signal:certify --strict --probe-writes` pass on the real host.

## v0.20.0-rc.4 migration index collision hotfix

Live Installer 1.7.8 install `01M0ACNY4SMNR6SXHT8P2F73TD` passed validation/deployment and recorded 12 Signal migrations before migration 13 failed with MySQL `SQLSTATE[42000] / 1061 Duplicate key name tsd_subscriber_status_idx`. Migration 6 already owns `tsd_subscriber_status_idx` on `(subscriber_key, status, available_at)`, which covers `(subscriber_key, status)` via the MySQL leftmost-prefix rule. rc.4 removes the redundant migration-13 index creation and its matching `down()` drop so rollback cannot accidentally remove migration 6's foundational index. A whole-chain regression now rejects duplicate explicit key names on the same table. Full host certification remains pending until all 19 migrations and `titan:signal:certify --strict --probe-writes` pass on the real host.

## v0.20.0-rc.3 MySQL strict timestamp migration compatibility hotfix

Live Installer 1.7.8 install `01M0ABSS6EK24CDQVSW79HBJB0` passed validation and deployment, then recorded six Signal migrations before migration 7 failed with `SQLSTATE[42000] / 1067 Invalid default value for projected_at`. rc.3 converts all 25 required application-managed `timestamp()` declarations without explicit defaults in migrations 7–18 to `dateTime()`. Nullable timestamps and Laravel `timestamps()` metadata remain unchanged. This is a pre-production RC migration-compatibility correction; full host certification remains pending until all 19 migrations and `titan:signal:certify --strict --probe-writes` pass on the real host.

## v0.20.0-rc.2 Installer 1.7.8 provider contract hotfix

The rc.1 provider referenced obsolete/non-host interfaces under `App\Extensions\Concerns`. rc.2 uses the Installer 1.7.8-compatible Marketplace contracts:

- `App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface`
- `App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface`

No migration changes are introduced by this hotfix.

## v0.20.0-rc.1 release candidate / Installer 1.7.8 certification

No new database schema migration is introduced in this pass. The root package manifest is upgraded to the Installer 1.7.8 `titan-extension-v1` contract and the extension adds `php artisan titan:signal:certify`. Deploy the cumulative RC to staging, run `titan:signal:certify --strict --probe-writes`, run the packaged Laravel integration suite, verify Installer 1.7.8 install/disable/re-enable/uninstall-retain behavior, and only then promote to production. Historical migration reproducibility hardening remains from v0.19.0.

## v0.18.0 immutable anomaly decision audit migration

Migration `2026_08_18_000019_add_immutable_anomaly_decision_audit.php` adds `decision_version`, `last_decision_event_id`, and `last_decision_at` to the anomaly projection and seeds the four package-owned decision event definitions. Acknowledgement now requires a governed reason. Existing anomaly rows remain valid with decision version 0 until their next lifecycle transition. No immutable historical Signal event is rewritten.

## v0.17.0 Pulse/health correctness migration

Migration `2026_08_18_000018_harden_pulse_health_correctness.php` adds scoped Pulse freshness, per-command receipt latency, and the maintained operational-health snapshot. No immutable Signal event is rewritten. Freshness rows warm as events are observed/projected after upgrade; health therefore reports `idle` rather than borrowing another tenant's global freshness. The new `signal-health-refresh` schedule runs every minute after Pulse projection.

## v0.16.0 automatic trace-evaluation migration

Run the additive migration `2026_08_17_000017_add_automatic_trace_evaluation.php`. It adds `match_event_types`, automatic assignment state, and freshness metadata without rewriting immutable Signal events. After deployment, keep the scheduler running so `titan:signal-traces:evaluate` can catch up open/partial assignments before anomaly scans.

## v0.15.0 correlation/read migration

`SignalCorrelationContract` keeps the same method signatures but its capability contract is now `signal.correlate v2.0`. Trace/workflow outputs add `storage_tier`, hot/cold counts, `event_storage`, mixed-tier edges and Rewind integrity metadata. Archived history requires the v0.13 catalog; run `titan:signal-archive:catalog` after upgrade if older verified archives were created before that catalog existed.

# Upgrade

Use forward-only compatible migrations and the Blueprint v4 expand → migrate → contract discipline.

Rules:

- never rewrite old migration files to match new runtime assumptions;
- new/old workers must coexist through additive transitions;
- large backfills are chunked/resumable;
- immutable historical events are not rewritten during normal upgrades;
- event/envelope/capability versions evolve independently;
- breaking public contract changes require a documented migration window.

v0.9.1 upgrades packaging/runtime declarations to Blueprint v4 manifest schema 2.0 without changing historical event identities.


v0.10.0 introduces versioned control-plane registries. Run all forward migrations before enabling writes. Existing `titan_signal_types` and `titan_signal_subscriptions` rows are copied into immutable version tables and retained as legacy compatibility data. Registry callers must migrate to `SignalRegistryAuthorityContract` + `SignalRegistryIdentity`.

## v0.14.0 lifecycle API migration

Pruning no longer accepts `confirmed=true`. Integrations must first call `previewPrune(tenant, scope, limit, context)`, persist the returned `preview_token` only for the confirmation interaction, then call `prune(preview_token, reason, context)`. The token is bound to the exact candidate hash and expires.
