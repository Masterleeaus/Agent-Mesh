<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Compatibility\Legacy;

use App\Extensions\TitanModelCouncil\System\Compatibility\Legacy\Services\ModelCouncilService;
use App\Models\User;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * Compatibility seam for the proven pre-Titan Model Council implementation.
 *
 * New Titan callers should depend on CouncilGatewayContract. Existing AI Chat Pro
 * integration can be migrated onto this adapter without importing legacy internals.
 */
final class LegacyCouncilAdapter
{
    public function __construct(private readonly ModelCouncilService $service)
    {
    }

    public function generateCouncilResponse(Request $request, array $chatParams, array $history, ?User $user): array
    {
        return $this->service->generateCouncilResponse($request, $chatParams, $history, $user);
    }

    public function streamCouncilResponse(Request $request, array $chatParams, array $history, ?User $user): StreamedResponse
    {
        return $this->service->streamCouncilResponse($request, $chatParams, $history, $user);
    }

    public function streamCouncilSummaryFromShared(Request $request, array $chatParams, ?User $user): StreamedResponse
    {
        return $this->service->streamCouncilSummaryFromShared($request, $chatParams, $user);
    }
}
