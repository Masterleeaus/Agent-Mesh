<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Jobs;

use App\Extensions\TitanRewind\System\Contracts\RewindSignalTransportContract;
use App\Extensions\TitanRewind\System\Models\RewindSignalOutbox;
use App\Extensions\TitanRewind\System\Observability\RewindTraceContext;
use App\Extensions\TitanRewind\System\Services\RewindCircuitBreakerService;
use App\Extensions\TitanRewind\System\Services\RewindDeadLetterService;
use App\Extensions\TitanRewind\System\Services\RewindTelemetryService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use RuntimeException;
use Throwable;

final class PublishRewindSignalJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 4;
    public int $timeout = 30;

    public function __construct(public int $outboxId, public int $tenantCompanyId) {}

    public function backoff(): array { return [5, 30, 120]; }

    public function handle(RewindSignalTransportContract $transport, RewindCircuitBreakerService $breaker, RewindTelemetryService $telemetry): void
    {
        $row = RewindSignalOutbox::query()->where('tenant_company_id',$this->tenantCompanyId)->find($this->outboxId);
        if ($row === null || $row->status === 'published') return;
        $ctx = RewindTraceContext::fromArray($row->toArray());
        $breaker->assertAvailable('titan-signal');
        $row->increment('attempts');
        $started = microtime(true);
        try {
            if (!$transport->available()) throw new RuntimeException('Titan Signal transport is unavailable.');
            $transport->publish((array)$row->payload);
            $row->forceFill(['status'=>'published','published_at'=>now(),'last_error'=>null])->save();
            $breaker->success('titan-signal');
            $telemetry->span('rewind.signal.publish',(microtime(true)-$started)*1000,'OK',$ctx,['event_type'=>$row->event_type]);
        } catch (Throwable $e) {
            $row->forceFill(['status'=>'retry','last_error'=>substr($e->getMessage(),0,2000),'available_at'=>now()->addSeconds(5)])->save();
            $breaker->failure('titan-signal',$e);
            $telemetry->log('rewind.signal.publish.failed','ERROR',$ctx,['event_type'=>$row->event_type,'exception'=>$e::class]);
            throw $e;
        }
    }

    public function failed(Throwable $e): void
    {
        $row = RewindSignalOutbox::query()->where('tenant_company_id',$this->tenantCompanyId)->find($this->outboxId);
        if ($row === null) return;
        $row->forceFill(['status'=>'attention','last_error'=>substr($e->getMessage(),0,2000)])->save();
        app(RewindDeadLetterService::class)->record((string)config('titan-rewind.queues.signal','titan-rewind-signal'),self::class,$this->tenantCompanyId,(string)$row->event_id,['outbox_id'=>$row->id,'event_type'=>$row->event_type],$e,(int)($this->attempts() ?: $row->attempts));
        $ctx = RewindTraceContext::fromArray($row->toArray());
        app(RewindTelemetryService::class)->log('rewind.signal.dead_lettered','CRITICAL',$ctx,['event_type'=>$row->event_type,'exception'=>$e::class]);
    }
}
