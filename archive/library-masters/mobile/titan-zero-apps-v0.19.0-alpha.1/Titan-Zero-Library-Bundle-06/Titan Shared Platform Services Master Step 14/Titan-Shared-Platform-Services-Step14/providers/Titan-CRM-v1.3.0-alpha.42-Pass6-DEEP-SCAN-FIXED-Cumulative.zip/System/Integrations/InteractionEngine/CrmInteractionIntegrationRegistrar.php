<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\InteractionEngine;

use App\Extensions\Crm\System\Capabilities\CrmCapabilityRegistry;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Contracts\Foundation\Application;

final class CrmInteractionIntegrationRegistrar
{
    public function __construct(
        private Application $app,
        private CrmCapabilityRegistry $crm,
        private CrmInteractionCapabilityHandler $handler,
        private CrmInteractionJourneyRegistry $journeys,
        private CrmInteractionAuthorityPolicy $authority,
        private CrmCompanyScope $companyScope,
    ) {}

    public function register(): void
    {
        $capabilityClass=\App\Extensions\InteractionEngine\System\Registry\CapabilityRegistry::class;
        if(class_exists($capabilityClass)&&$this->app->bound($capabilityClass)){
            $registry=$this->app->make($capabilityClass);
            foreach(array_keys($this->crm->definitions()) as $capability){
                $registry->register($capability,fn(array $payload):array=>$this->handler->handle($capability,$payload),false);
            }
        }
        $this->registerJourneys();
        $this->registerAuthorityPolicies();
    }

    private function registerAuthorityPolicies(): void
    {
        $engineClass=\App\Extensions\InteractionEngine\System\Policy\PolicyEngine::class;
        $policyClass=\App\Extensions\InteractionEngine\System\Authority\CapabilityPolicy::class;
        $levelClass=\App\Extensions\InteractionEngine\System\Authority\AuthorityLevel::class;
        if(!class_exists($engineClass)||!class_exists($policyClass)||!enum_exists($levelClass)||!$this->app->bound($engineClass))return;
        $engine=$this->app->make($engineClass);$capabilities=[];
        foreach($this->journeys->definitions() as $definition)$capabilities[(string)$definition['capability']]=true;
        foreach(array_keys($capabilities) as $capability){
            $alwaysApproval=$this->authority->alwaysApproval($capability);
            $baseAuthority=$alwaysApproval?$levelClass::ApprovalRequired:$levelClass::DelegatedAutonomous;
            $engine->registerCapabilityPolicy(new $policyClass(
                capability:$capability,authority:$baseAuthority,requiredRoles:[],delegatedScopes:[],freshAuthenticationSeconds:0,approvalTtlSeconds:900
            ));
            // Second gate: Interaction Engine proves command authority; CRM proves the exact tenant/workflow has earned it.
            $engine->registerPolicy($capability,function(array $payload)use($capability,$alwaysApproval):bool|string{
                $context=(array)($payload['_context']??[]);$company=(string)($context['company_id']??'');
                try{$trusted=$this->companyScope->current();}catch(\Throwable){return 'CRM trusted company context is unavailable.';}
                if($company===''||$company!==(string)$trusted->companyId)return 'CRM command company does not match the trusted company context.';
                $payloadUser=(int)($context['user_id']??0);if($trusted->actorUserId!==null&&$payloadUser>0&&$payloadUser!==$trusted->actorUserId)return 'CRM command actor does not match the trusted actor.';
                $actorType=(string)($context['actor_type']??'unknown');
                if($actorType==='human'){
                    // Critical capabilities are already signer-verified by Interaction Engine's ApprovalRequired base policy.
                    if($alwaysApproval)return true;
                    return $this->validHumanApproval($capability,$payload,$company,$payloadUser)
                        ? true : 'A valid explicit human approval is required before this prepared CRM action may execute.';
                }
                if(in_array($actorType,['agent','ai','titan_ai'],true)){
                    if($alwaysApproval)return 'This critical CRM capability permanently requires human approval.';
                    $workflow=trim((string)($context['autonomy_workflow_key']??''));
                    return $this->authority->mayAiComplete($capability,$workflow!==''?$workflow:null)
                        ? true : 'Titan Autonomy has not authorised this capability/workflow; human approval is required.';
                }
                return 'Unsupported CRM command actor type.';
            });
        }
    }

    private function validHumanApproval(string $capability,array $payload,string $company,int $userId):bool
    {
        $signerClass=\App\Extensions\InteractionEngine\System\Authority\ApprovalSigner::class;
        if(!class_exists($signerClass)||!$this->app->bound($signerClass))return false;
        $approval=(array)($payload['_approval']??[]);if($approval===[])return false;
        try{$signer=$this->app->make($signerClass);}catch(\Throwable){return false;}
        if(!$signer->verify($approval))return false;
        $now=time();
        return (string)($approval['capability']??'')===$capability
            && (string)($approval['company_id']??'')===$company
            && (!isset($approval['tenant_id'])||(string)$approval['tenant_id']===$company)
            && (int)($approval['approved_at']??0)>0
            && (int)($approval['expires_at']??0)>=$now
            && (int)($approval['expires_at']??0)-(int)($approval['approved_at']??0)<=900
            && $userId>0
            && (string)($approval['approved_by']??'')===(string)$userId;
    }

    private function registerJourneys(): void
    {
        $wizardClass=\App\Extensions\InteractionEngine\System\Wizard\WizardRegistry::class;
        $journeyClass=\App\Extensions\InteractionEngine\System\Journey\JourneyRegistry::class;
        $definitionClass=\App\Extensions\InteractionEngine\System\Journey\JourneyDefinition::class;
        if(!class_exists($wizardClass)||!class_exists($journeyClass)||!class_exists($definitionClass))return;
        if(!$this->app->bound($wizardClass)||!$this->app->bound($journeyClass))return;
        $wizards=$this->app->make($wizardClass);$journeys=$this->app->make($journeyClass);
        $directory=dirname(__DIR__,3).'/resources/interactions/crm';
        if(is_dir($directory)){
            foreach(glob($directory.'/*.json')?:[] as $file){
                $data=json_decode((string)file_get_contents($file),true);
                if(is_array($data))$wizards->register($data);
            }
        }
        foreach($this->journeys->definitions() as $definition){
            if(!$wizards->has($definition['wizard']))continue;
            $id='crm_'.$definition['key'];
            if($journeys->has($id))continue;
            $journeys->register(new $definitionClass(
                $id,$definition['name'],[$definition['wizard']],['command'],metadata:[
                    'crm_surface'=>$definition['surface'],'crm_capability'=>$definition['capability'],'crm_journey_key'=>$definition['key'],
                ]
            ));
        }
    }
}
