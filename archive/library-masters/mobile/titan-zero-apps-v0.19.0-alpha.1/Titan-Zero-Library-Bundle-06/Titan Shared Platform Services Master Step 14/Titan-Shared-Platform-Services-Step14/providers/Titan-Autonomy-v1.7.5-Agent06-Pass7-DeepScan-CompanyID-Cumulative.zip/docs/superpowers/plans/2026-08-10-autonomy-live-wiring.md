# Titan Autonomy v1.3 Live Host Wiring Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Bind Titan Autonomy to verified Titan CRM, Interaction Engine, CommandBus, TitanAI runtime availability, and Titan AI Assurance APIs without inventing host interfaces or weakening fail-closed autonomy rules.

**Architecture:** Keep Autonomy as the policy authority and use thin verified host adapters. Tenant identity is resolved from CRM's authenticated `CrmCompanyScope` and translated only at the Interaction/Assurance boundary where those subsystems canonically use `company_id`. Governed execution always goes Autonomy authority check → verified Interaction/CommandBus path; Trusted Auto consumes completed structured Assurance runs and may request a new pending run, but never creates a model panel or self-approves. Rewind remains optional because no verified Rewind source/API is available in the supplied source set.

**Tech Stack:** PHP 8.3, Laravel 10, Titan Extension Manager package contract, Titan CRM alpha.13, Titan Interaction Engine v10.3.2, TitanAI Runtime v1.5.2, Titan AI Assurance/ModelCouncil v1.9.0.

## Global Constraints

- Autonomy escalation remains capability- and workflow-specific.
- Gate minimums remain LOW=1, MEDIUM=2, HIGH=3; tenants cannot weaken platform minimums.
- Trusted Auto requires platform approval AND explicit authorised-user approval AND structured TitanAI/Assurance approval.
- CRM-backed tenancy uses `tenant_company_id`; request/client tenant IDs never establish tenancy.
- Interaction Engine and ModelCouncil may receive translated `company_id` only from trusted server-side tenant context because those verified subsystems use that field canonically.
- No direct CRM mutation path is introduced; governed execution uses the Interaction Engine CommandBus.
- No free-form LLM result can mint autonomy approval.
- Missing/unhealthy host integrations fail closed.
- Rewind remains additive/optional until a verified host API is supplied.

---

### Task 1: Verified CRM host context bridge

**Files:**
- Create: `System/Infrastructure/CrmCompanyHostContextBridge.php`
- Modify: `System/TitanAutonomyServiceProvider.php`
- Test: `tests/smoke/live_crm_host_context.php`

**Interfaces:**
- Consumes: `App\\Extensions\\Crm\\System\\Tenancy\\CrmCompanyScope::tenantCompanyId()` and current authenticated user.
- Produces: existing `HostContextBridgeContract` with trusted `tenantCompanyId()`, `userId()`, permission and Super Admin checks.

- [ ] Write a failing smoke test proving the bridge obtains tenancy from `CrmCompanyScope`, ignores a user-supplied fake tenant attribute, and preserves auth permission checks.
- [ ] Run the test and verify RED because the bridge does not exist.
- [ ] Implement the bridge and conditional service-provider binding when CRM tenancy classes exist.
- [ ] Run the test and verify GREEN.

### Task 2: Verified Interaction Engine / CommandBus adapters

**Files:**
- Create: `System/DTOs/GovernedCapabilityCommand.php`
- Create: `System/Infrastructure/InteractionEngineLiveBridge.php`
- Create: `System/Infrastructure/InteractionCommandBusLiveBridge.php`
- Modify: `System/TitanAutonomyServiceProvider.php`
- Test: `tests/smoke/live_interaction_command_bus.php`

**Interfaces:**
- Consumes: `InteractionEngineManagerContract::isEnabled()/health()`, `CapabilityRouter::canonical()/status()`, `CommandBus::dispatchResult()`.
- Produces: existing Interaction and CommandBus bridge contracts; server-generated `_context.company_id`, actor ID, source surface and correlation ID.

- [ ] Write a failing test proving client `_context.company_id` is overwritten by trusted host context and dispatch goes through `dispatchResult()`.
- [ ] Verify RED.
- [ ] Implement minimal adapters using only verified methods from Interaction Engine v10.3.2.
- [ ] Verify GREEN.

### Task 3: Live ModelCouncil Assurance bridge

**Files:**
- Create: `System/Infrastructure/ModelCouncilAssuranceBridge.php`
- Create: `System/Services/AssuranceAssessmentRequestService.php`
- Modify: `System/TitanAutonomyServiceProvider.php`
- Test: `tests/smoke/live_assurance_bridge.php`

**Interfaces:**
- Consumes: ModelCouncil `AssuranceRun` and `AssuranceEngine::createRun()/lockEvidence()`.
- Produces: normalized `GREEN/AMBER/RED`, `approved/denied`, confidence, reason codes and evaluation reference; request service can create and evidence-lock a pending autonomy assurance run but does not start a panel.

- [ ] Write failing tests for assured/permitted = GREEN, conditional = AMBER denied, blocked/failed = RED denied, pending/missing = fail-closed, and request creation remains pending.
- [ ] Verify RED.
- [ ] Implement the bridge and request service using verified v1.9 fields/status constants.
- [ ] Verify GREEN.

### Task 4: Governed capability registry and execution pipeline

**Files:**
- Create: `System/Services/LiveGovernedCapabilityRegistry.php`
- Create: `System/Services/GovernedHostExecutionService.php`
- Test: `tests/smoke/live_governed_execution.php`

**Interfaces:**
- Consumes: capability state/policy, `ExecutionAuthorityGuard`, Interaction bridge, CommandBus bridge, live Assurance bridge.
- Produces: one host execution path that verifies state/capability/workflow/tenant, authority, interaction readiness and scope before dispatch.

- [ ] Write failing tests proving denied authority never dispatches, capability mismatch never dispatches, and approved execution dispatches exactly once.
- [ ] Verify RED.
- [ ] Implement the service and registry with only exact CRM capabilities verified in alpha.13.
- [ ] Verify GREEN.

### Task 5: Live bridge diagnostics and control-plane actions

**Files:**
- Modify: `System/Services/HostBridgeStatusService.php`
- Modify: tenant controller/routes/views only where needed for Assurance assessment request and live bridge status.
- Test: `tests/smoke/live_bridge_diagnostics.php`

**Interfaces:**
- Produces tenant-visible diagnostics for CRM tenancy, Interaction, CommandBus, TitanAI runtime presence and Assurance; no diagnostic can elevate authority.

- [ ] Write failing tests for exact live/unavailable diagnostics and no authority mutation.
- [ ] Verify RED.
- [ ] Implement diagnostics and an authorised “Request Assurance Assessment” action.
- [ ] Verify GREEN.

### Task 6: Package/version/docs and regression verification

**Files:**
- Modify: `extension.json`, `engineering-sidecar.json`, README/CHANGELOG/reports/integrity files.
- Test: all existing smoke, unit/feature assertion shim, PHP lint, manifest/package gates.

- [ ] Bump extension to v1.3.0 and document verified host versions/API boundaries.
- [ ] Run every prior v1.2 test plus all new v1.3 live-adapter smoke tests.
- [ ] Run PHP lint over all PHP files.
- [ ] Validate JSON/manifest/integrity and Titan package gate.
- [ ] Build the installer ZIP and verify CRC, root layout and SHA-256.
