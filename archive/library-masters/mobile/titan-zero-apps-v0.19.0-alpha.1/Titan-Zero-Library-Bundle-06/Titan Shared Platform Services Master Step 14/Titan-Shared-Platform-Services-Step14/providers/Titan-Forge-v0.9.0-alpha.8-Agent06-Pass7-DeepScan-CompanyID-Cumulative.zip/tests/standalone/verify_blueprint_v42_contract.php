<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
require_once $root . '/System/Domain/BuildContext.php';
require_once $root . '/System/Domain/ForgeSignalEvent.php';

use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\ForgeSignalEvent;

function fail(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok(bool $condition, string $message): void { if (!$condition) fail($message); }

$rootCause = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
$ctx = new BuildContext(
    42,
    7,
    '11111111-1111-4111-8111-111111111111',
    '22222222-2222-4222-8222-222222222222',
    '33333333-3333-4333-8333-333333333333',
    '44444444-4444-4444-8444-444444444444',
    'forge:blueprint:v42',
    $rootCause,
);
ok(($ctx->toArray()['root_causation_id'] ?? null) === $rootCause, 'BuildContext must preserve root_causation_id.');

$event = new ForgeSignalEvent(
    'forge.build.requested',
    42,
    $ctx->traceId,
    $ctx->correlationId,
    $ctx->causationId,
    $ctx->operationId,
    7,
    'forge:blueprint:v42:event',
    ['build_id' => 1],
    [],
    'info',
    'forge.lifecycle',
    $rootCause,
);
$signal = $event->toSignalArray();
ok(($signal['root_causation_id'] ?? null) === $rootCause, 'Forge Signal envelope must propagate root_causation_id.');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
ok(($manifest['schema_version'] ?? null) === '2.2', 'Blueprint sidecar must be Manifest v2.2.');
ok(($manifest['architecture']['profile'] ?? null) === 'builder-generator', 'Forge must use builder-generator profile.');
ok(in_array('signal-aware', $manifest['architecture']['modifiers'] ?? [], true), 'Forge must be signal-aware.');
ok(in_array('ai-enabled', $manifest['architecture']['modifiers'] ?? [], true), 'Forge must declare ai-enabled once AI Core planning and sandboxed artifact boundaries exist.');
ok(($manifest['authority']['canonical_owner'] ?? null) === true, 'Forge must be canonical owner of its domain.');
ok(in_array('build-generation', $manifest['authority']['owns'] ?? [], true), 'Forge must own build-generation.');
ok(($manifest['authority']['cross_domain_write_policy'] ?? null) === 'command-bus-only', 'Cross-domain writes must be Command Bus only.');
ok(($manifest['governance']['signal'] ?? null) === 'required', 'Signal is mandatory for canonical Forge.');
ok(($manifest['governance']['command_bus'] ?? null) === 'required', 'Command Bus is mandatory for Forge release execution.');
ok(($manifest['governance']['risk'] ?? null) === 'required', 'Risk is mandatory for Forge release candidates.');
ok(($manifest['governance']['shield'] ?? null) === 'required', 'Shield is mandatory for Forge release candidates.');
ok(($manifest['service_identity']['service_id'] ?? null) === 'titan-forge', 'Forge service identity must be titan-forge.');
ok(($manifest['signal']['integration_contract'] ?? null) === 'titan.signal.integration.v1', 'Forge must declare Signal integration v1.');
ok(($manifest['navigation']['host_sync'] ?? null) === true, 'Forge navigation must host-sync.');
ok(($manifest['navigation']['preserve_admin_customization'] ?? null) === true, 'Forge navigation sync must preserve admin customization.');

$installer = json_decode((string) file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);
ok(($installer['schema'] ?? null) === 'titan-extension-v1', 'Root installer manifest must remain titan-extension-v1.');
ok(isset($installer['uninstall']['preserve_data']), 'Installer uninstall preserve_data is required.');
ok(isset($installer['requires']['laravel']), 'Installer Laravel compatibility is required.');
ok(!isset($installer['requires']['titan_platform']), 'Installer 1.7.8 root requires must not contain titan_platform.');
ok(!isset($installer['description']) && !isset($installer['name']) && !isset($installer['type']) && !isset($installer['publishes']), 'Installer root manifest must not carry legacy unsupported fields.');

$migration = glob($root . '/database/migrations/*root_causation*.php');
ok(is_array($migration) && count($migration) === 1, 'A forward migration must add root_causation_id.');

foreach ([
    'docs/ARCHITECTURE.md', 'docs/CAPABILITIES.md', 'docs/OPERATIONS.md', 'docs/SECURITY.md',
    'docs/DATA-OWNERSHIP.md', 'docs/UPGRADE.md', 'docs/UNINSTALL.md', 'docs/TROUBLESHOOTING.md',
    'docs/INTEGRATION-CONTRACTS.md', 'docs/SIGNAL-EVENTS.md', 'docs/GOVERNANCE.md',
    'docs/FAILURE-MODES.md', 'docs/AUTHORIZATION-MATRIX.md', 'docs/DISASTER-RECOVERY.md', 'CHANGELOG.md',
] as $relative) {
    ok(is_file($root . '/' . $relative), "Blueprint-required document missing: {$relative}");
}

fwrite(STDOUT, "PASS: Titan Forge Blueprint v4.2 contract\n");
