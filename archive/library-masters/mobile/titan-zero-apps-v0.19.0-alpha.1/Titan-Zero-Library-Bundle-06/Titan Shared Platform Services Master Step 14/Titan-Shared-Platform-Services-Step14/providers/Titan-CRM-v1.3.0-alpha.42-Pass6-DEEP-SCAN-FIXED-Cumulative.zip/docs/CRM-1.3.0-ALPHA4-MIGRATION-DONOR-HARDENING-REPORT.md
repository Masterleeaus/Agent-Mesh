# CRM 1.3.0-alpha.4 Migration + Donor Hardening Report

## Live failure addressed

Titan Extension Manager reached migration `2026_08_09_000011_add_field_service_domains.php` and MySQL rejected Laravel's generated index name for `rebooking_service_request_public_id` because the resulting identifier was 68 characters. MySQL identifiers are limited to 64 characters.

The failed migration may have already created tables because MySQL DDL is not transactionally rolled back as one Laravel migration. In particular, `crm_service_recovery_cases` may exist without its failed rebooking index.

## Recovery implementation

- Explicit short index: `crm_recovery_rebook_req_idx`.
- 29 `Schema::create()` operations in migration 000011 are individually guarded with `Schema::hasTable()`.
- A post-create `ensureIndex()` step checks MySQL `information_schema.statistics` and adds `crm_recovery_rebook_req_idx` when the table exists but the index is missing.
- Fresh installations create the same index during table creation; `ensureIndex()` sees it and performs no duplicate alteration.

## Permanent migration gates

- `bin/verify-mysql-identifier-lengths.php`
- `bin/verify-migration-000011-restartability.php`
- `bin/verify-migration-000011-partial-index-repair.php`

## Donor integration

WorkCore was used strictly as a donor source. Alpha.4 adapts pure finance/inventory algorithms into `App\\Extensions\\Crm\\System\\Domains` and exposes governed CRM capability handlers. It does not import WorkCore tenancy, providers, tables or runtime dependencies.

New Pay intelligence includes confidence-based bank matching, collections suppression and job-profitability calculations. Locker now uses adapted inventory quantity and stock-movement policies internally.

## Live upgrade guidance

Install alpha.4 directly over the failed alpha.3 deployment. Do not manually delete the partially created field-service tables. Migration 000011 is specifically hardened to continue from that state.
