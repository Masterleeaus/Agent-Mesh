# Phase 6.2 — Installer Clean Boot + Super Admin Navigation

- Fixed Titan installer provider-stage failure when `INTERACTION_APPROVAL_SECRET` is not yet configured.
- `ApprovalSigner` now boots unconfigured but remains fail-closed: it cannot issue or verify approval grants until a secret of at least 16 characters is configured.
- The encrypted wizard outbox now also boots safely before configuration; queueing/decryption remain unavailable until a non-empty outbox secret exists.
- Preserved compatibility with existing non-empty `INTERACTION_OUTBOX_SECRET` values from v10.3.1; 16+ random characters are recommended for new deployments.
- Added a Super Admin Interaction Engine overview route and dashboard.
- Added Super Admin navigation definitions for **Interaction Engine → Overview / Settings** through Titan's `navigation.admin` contribution registry.
- Added an idempotent MagicAI `menus` table fallback under the host Settings menu when the contribution registry is unavailable and the live schema can be identified safely.
- Menu integration is best-effort and can never make provider boot fail.
- Added menu-cache regeneration through `App\\Services\\Common\\MenuService::regenerate()` when available.
- Enhanced Super Admin settings with approval/outbox readiness and explicit fail-closed status without exposing secret values.
- Bumped release version to 10.3.2.
