<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

final class CrmActivityRecorder
{
    public function __construct(private ConnectionInterface $db) {}

    public function record(int $userId, string $subjectType, string $subjectPublicId, string $type, ?string $title, ?string $body, ?string $direction, ?string $scheduledAt, ?string $completedAt, int $actorUserId, array $metadata = []): array
    {
        $publicId = (string) Str::ulid();
        $id = $this->db->table(config('crm.tables.activities'))->insertGetId([
            'public_id'=>$publicId, 'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId), 'subject_type'=>$subjectType, 'subject_public_id'=>$subjectPublicId,
            'type'=>$type, 'title'=>$title, 'body'=>$body, 'direction'=>$direction, 'scheduled_at'=>$scheduledAt,
            'completed_at'=>$completedAt, 'actor_user_id'=>$actorUserId, 'metadata'=>$metadata === [] ? null : json_encode($metadata),
            'created_at'=>now(), 'updated_at'=>now(),
        ]);
        return (array) $this->db->table(config('crm.tables.activities'))->where('id', $id)->first();
    }
}
