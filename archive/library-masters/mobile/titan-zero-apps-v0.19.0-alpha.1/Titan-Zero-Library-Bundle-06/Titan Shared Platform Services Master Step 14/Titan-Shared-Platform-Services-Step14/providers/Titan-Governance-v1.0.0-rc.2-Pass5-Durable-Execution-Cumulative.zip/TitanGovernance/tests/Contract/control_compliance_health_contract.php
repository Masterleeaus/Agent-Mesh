<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);function fail_cch(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function same_cch(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_cch($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
$f=$root.'/System/ControlCentre/PolicyComplianceHealthProjector.php';if(!is_file($f))fail_cch('missing PolicyComplianceHealthProjector.php');require_once $f;
use App\Extensions\TitanGovernance\System\ControlCentre\PolicyComplianceHealthProjector;
$sources=[
 'titan-assurance'=>['source'=>'titan-assurance','required'=>false,'status'=>'HEALTHY','observed_at'=>'2026-08-21T02:40:00+10:00','control_centre'=>[
  'policies'=>[
   ['policy_key'=>'invoice.limit','expected_version'=>'3','current_version'=>'2','status'=>'ACTIVE','observed_at'=>'2026-08-21T02:39:00+10:00','reference'=>'policy:invoice'],
   ['policy_key'=>'privacy.retention','expected_version'=>'5','current_version'=>'5','status'=>'ACTIVE','observed_at'=>'2026-08-21T02:39:00+10:00'],
  ],
  'controls'=>[
   ['control_key'=>'privacy.redaction','obligation_key'=>'privacy','status'=>'NON_COMPLIANT','evidence_status'=>'CURRENT','observed_at'=>'2026-08-21T02:39:00+10:00','reference'=>'control:1'],
   ['control_key'=>'invoice.approval','obligation_key'=>'finance','status'=>'COMPLIANT','evidence_status'=>'CURRENT','observed_at'=>'2026-08-21T02:39:00+10:00'],
  ],
 ]],
 'titan-shield'=>['source'=>'titan-shield','required'=>false,'status'=>'NOT_INSTALLED','observed_at'=>null,'control_centre'=>[]],
];
$decisions=[
 ['decision_id'=>'d-expiring','action'=>'EXCEPTION','decided_at'=>'2026-08-21T02:00:00+10:00','result_payload'=>['expires_at'=>'2026-08-21T03:00:00+10:00'],'reason_codes'=>['temporary-waiver']],
 ['decision_id'=>'d-expired','action'=>'EXCEPTION','decided_at'=>'2026-08-20T01:00:00+10:00','result_payload'=>['expires_at'=>'2026-08-21T02:00:00+10:00'],'reason_codes'=>['old-waiver']],
];
$p=new PolicyComplianceHealthProjector();$r=$p->project($sources,$decisions,['now'=>'2026-08-21T02:50:00+10:00','exception_expiring_seconds'=>3600]);
same_cch('NON_COMPLIANT',$r['status'],'explicit non-compliant control must dominate');same_cch(1,$r['policy_drift_count'],'version mismatch count');
$pol=[];foreach($r['policies'] as $row)$pol[$row['policy_key']]=$row;same_cch('DRIFT',$pol['invoice.limit']['drift_status'],'policy mismatch drift');same_cch('CURRENT',$pol['privacy.retention']['drift_status'],'policy versions match');
$ctl=[];foreach($r['controls'] as $row)$ctl[$row['control_key']]=$row;same_cch('NON_COMPLIANT',$ctl['privacy.redaction']['status'],'explicit control non-compliance');
$ex=[];foreach($r['exceptions'] as $row)$ex[$row['decision_id']]=$row;same_cch('EXPIRING',$ex['d-expiring']['expiry_status'],'exception within window');same_cch('EXPIRED',$ex['d-expired']['expiry_status'],'expired exception');
same_cch(1,$r['visibility_degraded_sources'],'missing optional source degrades visibility count only');
$optionalOnly=$p->project(['x'=>['source'=>'x','required'=>false,'status'=>'NOT_INSTALLED','control_centre'=>[]]],[],['now'=>'2026-08-21T02:50:00+10:00']);same_cch('DEGRADED',$optionalOnly['status'],'optional absence should be degraded not compliant');
echo "PASS: Governance policy/compliance health contract\n";
