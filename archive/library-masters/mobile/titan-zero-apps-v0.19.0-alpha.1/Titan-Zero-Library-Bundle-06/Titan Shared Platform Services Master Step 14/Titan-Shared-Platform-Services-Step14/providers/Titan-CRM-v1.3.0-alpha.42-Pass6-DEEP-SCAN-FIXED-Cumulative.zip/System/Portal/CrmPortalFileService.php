<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Portal;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

final class CrmPortalFileService
{
    public function __construct(private ConnectionInterface $db, private CrmPortalFileScanner $scanner) {}

    public function store(array $grant, UploadedFile $file): array
    {
        $allowedMimes=(array)config('crm.portal.files.allowed_mimes',['application/pdf','image/jpeg','image/png','text/plain']);
        $maxBytes=(int)config('crm.portal.files.max_bytes',10*1024*1024);
        $mime=(string)($file->getMimeType()?:'application/octet-stream'); $size=(int)$file->getSize();
        if(!in_array($mime,$allowedMimes,true)) throw ValidationException::withMessages(['file'=>['This file type is not allowed.']]);
        if($size<=0||$size>$maxBytes) throw ValidationException::withMessages(['file'=>['The file exceeds the CRM portal upload limit.']]);
        $real=$file->getRealPath();
        if(!is_string($real)||$real===''||!is_file($real)) throw ValidationException::withMessages(['file'=>['The uploaded file could not be read.']]);

        $sha256=hash_file('sha256',$real); $disk=(string)config('crm.portal.files.disk','local'); $publicId=(string)Str::ulid();
        $extension=strtolower((string)$file->getClientOriginalExtension()); $suffix=$extension!==''?'.'.preg_replace('/[^a-z0-9]+/','',$extension):'';
        $randomName=bin2hex(random_bytes(24)).$suffix;
        $quarantineKey='crm/quarantine/'.(int)$grant['company_id'].'/'.(string)$grant['public_id'].'/'.$randomName;
        $availableKey='crm/portal/'.(int)$grant['company_id'].'/'.(string)$grant['public_id'].'/'.$randomName;
        $stream=fopen($real,'rb');
        if($stream===false||!Storage::disk($disk)->put($quarantineKey,$stream)) throw ValidationException::withMessages(['file'=>['The file could not be quarantined.']]);
        if(is_resource($stream))fclose($stream);

        $original=trim(preg_replace('/[\x00-\x1F\x7F]+/u','',basename((string)$file->getClientOriginalName()))?:'upload');
        $this->db->table('crm_portal_files')->insert([
            'public_id'=>$publicId,'company_id'=>(int)$grant['company_id'],'user_id'=>(int)$grant['user_id'],'portal_grant_public_id'=>(string)$grant['public_id'],
            'disk'=>$disk,'storage_key'=>$quarantineKey,'quarantine_storage_key'=>$quarantineKey,'original_name'=>mb_substr($original,0,500),'mime_type'=>$mime,'size_bytes'=>$size,'sha256'=>$sha256,
            'status'=>'quarantined','scan_status'=>'pending','uploaded_by_type'=>'customer','metadata'=>json_encode([]),'uploaded_at'=>now(),'created_at'=>now(),'updated_at'=>now(),
        ]);

        $scan=$this->scanner->scan($real,$mime); $scanStatus=(string)($scan['status']??'scanner_unavailable'); $engine=(string)($scan['engine']??'unknown');
        if($scanStatus!=='clean'){
            $status=$scanStatus==='infected'?'infected':'scan_failed';
            $this->db->table('crm_portal_files')->where('public_id',$publicId)->update([
                'status'=>$status,'scan_status'=>$scanStatus,'scan_engine'=>mb_substr($engine,0,120),'scanned_at'=>now(),'metadata'=>json_encode(['scan'=>$scan]),'updated_at'=>now(),
            ]);
            if($scanStatus==='infected') throw ValidationException::withMessages(['file'=>['The uploaded file failed the malware scan.']]);
            if((bool)config('crm.portal.files.require_scanner',true)) throw ValidationException::withMessages(['file'=>['File scanning is required but the scanner is unavailable. The file remains quarantined.']]);
        }

        if($scanStatus==='clean' || !(bool)config('crm.portal.files.require_scanner',true)){
            if(!Storage::disk($disk)->move($quarantineKey,$availableKey)){
                $this->db->table('crm_portal_files')->where('public_id',$publicId)->update(['status'=>'quarantined','scan_status'=>'storage_move_failed','updated_at'=>now()]);
                throw ValidationException::withMessages(['file'=>['The scanned file could not be released from quarantine.']]);
            }
            $this->db->table('crm_portal_files')->where('public_id',$publicId)->update([
                'storage_key'=>$availableKey,'status'=>'available','scan_status'=>$scanStatus,'scan_engine'=>mb_substr($engine,0,120),'scanned_at'=>now(),'metadata'=>json_encode(['scan'=>$scan]),'updated_at'=>now(),
            ]);
        }
        return (array)$this->db->table('crm_portal_files')->where('public_id',$publicId)->first();
    }

    public function list(array $grant): array
    {
        $limit=max(25,min(500,(int)config('crm.performance.detail_collection_limit',250)));
        return $this->db->table('crm_portal_files')->where('company_id',(int)$grant['company_id'])->where('portal_grant_public_id',(string)$grant['public_id'])
            ->where('status','available')->where('scan_status','clean')->whereNull('deleted_at')->orderByDesc('id')->limit($limit)->get()->map(fn($r)=>(array)$r)->all();
    }

    public function resolve(array $grant,string $publicId): array
    {
        $row=$this->db->table('crm_portal_files')->where('company_id',(int)$grant['company_id'])->where('portal_grant_public_id',(string)$grant['public_id'])
            ->where('public_id',$publicId)->where('status','available')->where('scan_status','clean')->whereNull('deleted_at')->first();
        if(!$row) throw new NotFoundHttpException();
        return (array)$row;
    }
}
