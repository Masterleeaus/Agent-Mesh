<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\Tenancy\CrmTenantTableMap;
use Illuminate\Console\Command;
use Illuminate\Database\ConnectionInterface;

final class AuditCrmCompanyTenancyCommand extends Command
{
    protected $signature = 'crm:titan-company-tenancy:audit {--table=}';
    protected $description = 'Read-only audit of CRM 1.1 -> 1.2 company-tenancy migration state.';

    public function __construct(private readonly ConnectionInterface $db) { parent::__construct(); }

    public function handle(): int
    {
        $tables = $this->option('table') ? [(string)$this->option('table')] : CrmTenantTableMap::TABLES;
        $totals=['records'=>0,'migrated'=>0,'unresolved'=>0,'missing_company_context'=>0,'conflicts'=>0];
        $rows=[]; $schema=$this->db->getSchemaBuilder();
        foreach ($tables as $table) {
            if (! $schema->hasTable($table) || ! $schema->hasColumn($table,'company_id')) continue;
            $total=$this->db->table($table)->count();
            $migrated=$this->db->table($table)->whereNotNull('company_id')->count();
            $unresolved=$total-$migrated;
            $conflicts=$schema->hasTable('crm_tenancy_migration_reviews') ? $this->db->table('crm_tenancy_migration_reviews')->where('source_table',$table)->where('reason','conflicting_company_membership')->where('status','unresolved')->count() : 0;
            $rows[]=[$table,$total,$migrated,$unresolved,$conflicts];
            $totals['records']+=$total;$totals['migrated']+=$migrated;$totals['unresolved']+=$unresolved;$totals['missing_company_context']+=$unresolved;$totals['conflicts']+=$conflicts;
        }
        $this->table(['table','total','migrated','unresolved','conflicts'],$rows);
        $this->line(json_encode($totals, JSON_UNESCAPED_SLASHES));
        return $totals['unresolved']===0 ? self::SUCCESS : self::FAILURE;
    }
}
