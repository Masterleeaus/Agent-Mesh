<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyOverlayStoreContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskPolicyScope;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyOverlay;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Database\ConnectionInterface;

final class DatabaseRiskPolicyOverlayStore implements RiskPolicyOverlayStoreContract
{
    public function __construct(
        private readonly ConnectionInterface $database,
        private readonly string $table = 'titan_risk_policy_overlays',
        private readonly ?RiskPolicyIntegrityVerifier $integrity = null,
    ) {}

    public function effectiveFor(int|string $tenantCompanyId, string $capability, DateTimeImmutable $asOf): array
    {
        $rows = $this->database->table($this->table)
            ->where('effective_at', '<=', $this->stamp($asOf))
            ->where(function ($q) use ($tenantCompanyId, $capability): void {
                $q->where('scope', RiskPolicyScope::GLOBAL->value)
                    ->orWhere(function ($q) use ($tenantCompanyId): void {
                        $q->where('scope', RiskPolicyScope::TENANT->value)->where('tenant_company_id', $tenantCompanyId);
                    })
                    ->orWhere(function ($q) use ($capability): void {
                        $q->where('scope', RiskPolicyScope::CAPABILITY->value)->where('capability', $capability);
                    })
                    ->orWhere(function ($q) use ($tenantCompanyId, $capability): void {
                        $q->where('scope', RiskPolicyScope::TENANT_CAPABILITY->value)
                            ->where('tenant_company_id', $tenantCompanyId)
                            ->where('capability', $capability);
                    });
            })
            ->orderBy('effective_at')
            ->orderBy('id')
            ->limit(256)->get()->all();

        return array_map(fn ($row): RiskPolicyOverlay => $this->hydrate($row), $rows);
    }

    public function register(RiskPolicyOverlay $overlay): void
    {
        $now = $this->stamp(new DateTimeImmutable('now', new DateTimeZone('UTC')));
        $this->database->table($this->table)->insert([
            'binding_key' => $this->bindingKey($overlay->policyKey, $overlay->scope, $overlay->tenantCompanyId, $overlay->capability),
            'policy_key' => $overlay->policyKey,
            'version' => $overlay->version,
            'scope' => $overlay->scope->value,
            'tenant_company_id' => $overlay->tenantCompanyId,
            'capability' => $overlay->capability,
            'constraints' => json_encode($overlay->constraints, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
            'effective_at' => $this->stamp($overlay->effectiveAt),
            'supersedes_version' => $overlay->supersedesVersion,
            'content_digest' => $overlay->contentDigest(),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    public function versionsFor(string $policyKey, RiskPolicyScope $scope, int|string|null $tenantCompanyId, ?string $capability): array
    {
        $binding = $this->bindingKey($policyKey, $scope, $tenantCompanyId, $capability);
        return array_map(fn ($row): RiskPolicyOverlay => $this->hydrate($row), $this->database->table($this->table)
            ->where('binding_key', $binding)
            ->orderBy('effective_at')
            ->orderBy('id')
            ->limit(1000)->get()->all());
    }

    private function hydrate(object $row): RiskPolicyOverlay
    {
        $constraints = json_decode((string) $row->constraints, true, 64, JSON_THROW_ON_ERROR);
        $overlay = new RiskPolicyOverlay(
            policyKey: (string) $row->policy_key,
            version: (string) $row->version,
            scope: RiskPolicyScope::from((string) $row->scope),
            constraints: is_array($constraints) ? $constraints : [],
            effectiveAt: new DateTimeImmutable((string) $row->effective_at, new DateTimeZone('UTC')),
            tenantCompanyId: $row->tenant_company_id,
            capability: $row->capability === null ? null : (string) $row->capability,
            supersedesVersion: $row->supersedes_version === null ? null : (string) $row->supersedes_version,
        );
        ($this->integrity ?? new RiskPolicyIntegrityVerifier())->assertOverlayDigest($overlay, (string) $row->content_digest);

        return $overlay;
    }

    private function bindingKey(string $policyKey, RiskPolicyScope $scope, int|string|null $tenantCompanyId, ?string $capability): string
    {
        return hash('sha256', implode('|', [$policyKey, $scope->value, (string) ($tenantCompanyId ?? ''), (string) ($capability ?? '')]));
    }

    private function stamp(DateTimeImmutable $at): string
    {
        return $at->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.u');
    }
}
