<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;

final class RegressionService
{
    public function target(AutonomyLevel $current, string $cause): AutonomyLevel
    {
        $severe = in_array($cause, ['reversal', 'assurance_red', 'wrong_autonomous_action', 'authority_breach'], true);
        if ($severe) {
            return match ($current) {
                AutonomyLevel::TrustedAuto, AutonomyLevel::Auto => AutonomyLevel::SemiAuto,
                AutonomyLevel::SemiAuto => AutonomyLevel::Assist,
                AutonomyLevel::Assist => AutonomyLevel::Suggest,
                AutonomyLevel::Suggest => AutonomyLevel::Suggest,
            };
        }
        return match ($current) {
            AutonomyLevel::TrustedAuto => AutonomyLevel::Auto,
            AutonomyLevel::Auto => AutonomyLevel::SemiAuto,
            AutonomyLevel::SemiAuto => AutonomyLevel::Assist,
            AutonomyLevel::Assist => AutonomyLevel::Suggest,
            AutonomyLevel::Suggest => AutonomyLevel::Suggest,
        };
    }
}
