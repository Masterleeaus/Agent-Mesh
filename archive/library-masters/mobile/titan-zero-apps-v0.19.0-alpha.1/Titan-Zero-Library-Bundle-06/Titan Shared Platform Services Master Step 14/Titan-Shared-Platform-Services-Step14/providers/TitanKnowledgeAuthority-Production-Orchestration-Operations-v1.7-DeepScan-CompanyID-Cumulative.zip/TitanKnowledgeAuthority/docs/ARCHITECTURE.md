# Architecture
Titan Knowledge Authority is an `intelligence-engine` with the `knowledge-authority` modifier. It canonically owns knowledge sources, immutable versions, documents, sections, claims, jurisdictions, applicability, contradictions/exceptions and refresh-state metadata. It does not own business records, risk, assurance, autonomy, workflow state or command execution; cross-domain writes are forbidden.

## Durable knowledge domain
`KnowledgeSource -> KnowledgeSourceVersion -> KnowledgeDocument -> KnowledgeSection -> KnowledgeClaim -> KnowledgeApplicability`

`KnowledgeJurisdiction` provides stable scope identity for jurisdiction-bound sources/applicability.

## Trusted scope boundary
Canonical reads and writes are context-derived rather than caller-scoped. A host binds `KnowledgeAccessContextResolverContract` from trusted authenticated/system state; otherwise the extension uses the fail-closed resolver. `KnowledgeSourceScopeQuery` constrains the source row before catalog reads or version appends. Tenant knowledge requires exact `tenant_company_id`; jurisdiction knowledge requires an explicit trusted jurisdiction grant; malformed/legacy scopes are excluded.

## Pass 4 immutable-version boundary
`KnowledgeSourceVersionWriteService` is the sole extension-owned append service for new canonical source versions. It serializes writers by locking the already-scoped source row inside a transaction. Duplicate content hashes return idempotently before predecessor checks. Existing duplicate/latest rows must have tenant lineage consistent with their source. New content receives the next monotonic sequence and supersedes the current latest version. Callers may provide an expected predecessor ID as a precondition, but cannot provide the actual supersession pointer, sequence, version key or tenant ownership.

`KnowledgeSourceVersion` rejects mutable creation flags, invalid canonical identifiers/hashes, updates and Eloquent deletes. The source foreign key is changed from cascading deletion to restricted deletion so source removal cannot erase version history through the parent relationship.

Remote source acquisition, refresh, precedence resolution, jurisdiction inheritance and public `knowledge.resolve` remain later passes.

## Pass 4 immutable version append boundary
`KnowledgeSourceVersionWriteContract` is the only extension-owned creation seam for canonical source versions. It serializes writes per source, derives tenant ownership from the source row, deduplicates normalized content, assigns deterministic sequence/key values and links each new version only to the latest predecessor. Existing version rows remain append-only and cannot be updated or deleted through the model.
