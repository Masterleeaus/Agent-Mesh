<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Providers;

use App\Extensions\TitanConnect\System\DTO\NormalizedDeliveryReceipt;
use App\Extensions\TitanConnect\System\DTO\NormalizedInboundMessage;
use App\Extensions\TitanConnect\System\DTO\ProviderSendResult;
use Illuminate\Support\Arr;

class MessengerProvider extends AbstractMessagingProvider
{
    public function key(): string { return 'messenger'; }

    public function verifyWebhook(array $headers, string $body, array $credentials): bool
    {
        return $this->verifyHmac($headers, $body, (string) ($credentials['app_secret'] ?? ''), 'x-hub-signature-256', 'sha256=');
    }

    public function verifyWebhookChallenge(array $query, array $credentials): ?string
    {
        $mode = (string) ($query['hub.mode'] ?? $query['hub_mode'] ?? '');
        $token = (string) ($query['hub.verify_token'] ?? $query['hub_verify_token'] ?? '');
        $challenge = $query['hub.challenge'] ?? $query['hub_challenge'] ?? null;
        $expected = trim((string) ($credentials['verify_token'] ?? ''));
        if ($mode !== 'subscribe' || $expected === '' || ! hash_equals($expected, $token) || ! is_scalar($challenge)) {
            return null;
        }
        return (string) $challenge;
    }

    public function splitWebhookPayload(array $payload): array
    {
        $events = [];
        $entries = is_array($payload['entry'] ?? null) ? $payload['entry'] : [];
        foreach ($entries as $entry) {
            if (! is_array($entry)) continue;
            $messaging = is_array($entry['messaging'] ?? null) ? $entry['messaging'] : [];
            foreach ($messaging as $item) {
                if (! is_array($item)) continue;
                $mids = is_array($item['delivery']['mids'] ?? null) ? $item['delivery']['mids'] : [];
                if (count($mids) > 1) {
                    foreach ($mids as $mid) {
                        if (! is_scalar($mid)) continue;
                        $single = $item;
                        $single['delivery']['mids'] = [(string) $mid];
                        $events[] = ['object' => $payload['object'] ?? null, 'entry' => [[
                            'id' => $entry['id'] ?? null,
                            'time' => $entry['time'] ?? null,
                            'messaging' => [$single],
                        ]]];
                    }
                    continue;
                }
                $events[] = ['object' => $payload['object'] ?? null, 'entry' => [[
                    'id' => $entry['id'] ?? null,
                    'time' => $entry['time'] ?? null,
                    'messaging' => [$item],
                ]]];
            }
        }
        return $events;
    }

    public function send(array $message, array $credentials): ProviderSendResult
    {
        $token = $this->credential($credentials, 'access_token');
        $pageId = $this->accountIdentity($credentials, 'page_id', $message);

        $payload = [
            'recipient' => ['id' => (string) ($message['to'] ?? '')],
            'messaging_type' => (string) data_get($message, 'metadata.messaging_type', 'RESPONSE'),
        ];
        if (($attachment = $this->firstAttachment($message)) !== null && ! empty($attachment['public_url'])) {
            $type = strtolower((string) ($attachment['type'] ?? 'file'));
            if (! in_array($type, ['image', 'video', 'audio', 'file'], true)) {
                $type = 'file';
            }
            $payload['message'] = ['attachment' => ['type' => $type, 'payload' => ['url' => (string) $attachment['public_url'], 'is_reusable' => true]]];
        } else {
            $payload['message'] = ['text' => (string) ($message['body'] ?? '')];
        }

        $url = $this->graphBase($this->key(), $credentials).'/'.$this->graphVersion($this->key(), $credentials).'/'.$pageId.'/messages';
        $response = $this->requireSuccess($this->http->request('POST', $url, [
            'bearer' => $token,
            'json' => $payload,
        ]), 'send');

        $providerId = $response->json('message_id');
        return new ProviderSendResult('sent', is_scalar($providerId) ? (string) $providerId : null, $response->json);
    }

    public function health(array $credentials): array
    {
        $token = $this->credential($credentials, 'access_token');
        $pageId = $this->accountIdentity($credentials, 'page_id');
        $url = $this->graphBase($this->key(), $credentials).'/'.$this->graphVersion($this->key(), $credentials).'/'.$pageId;
        $response = $this->http->request('GET', $url, ['bearer' => $token, 'query' => ['fields' => 'id,name']]);
        return ['ok' => $response->isSuccessful(), 'provider' => $this->key(), 'configured' => true, 'http_status' => $response->status, 'account_id' => $response->json('id')];
    }

    public function normalizeDeliveryReceipt(array $payload): NormalizedDeliveryReceipt
    {
        $item = Arr::get($payload, 'entry.0.messaging.0');
        if (! is_array($item)) {
            return parent::normalizeDeliveryReceipt($payload);
        }
        if (isset($item['delivery']) && is_array($item['delivery'])) {
            $mid = $item['delivery']['mids'][0] ?? null;
            return new NormalizedDeliveryReceipt($this->key(), $mid === null ? null : (string) $mid, 'delivered', [
                'watermark' => $item['delivery']['watermark'] ?? null,
                'sender_ref' => Arr::get($item, 'sender.id'),
                'recipient_ref' => Arr::get($item, 'recipient.id'),
            ]);
        }
        if (isset($item['read']) && is_array($item['read'])) {
            return new NormalizedDeliveryReceipt($this->key(), null, 'read', [
                'watermark' => $item['read']['watermark'] ?? null,
                'sender_ref' => Arr::get($item, 'sender.id'),
                'recipient_ref' => Arr::get($item, 'recipient.id'),
            ]);
        }
        return parent::normalizeDeliveryReceipt($payload);
    }

    public function normalizeInbound(array $payload, array $headers = []): NormalizedInboundMessage
    {
        $item = Arr::get($payload, 'entry.0.messaging.0');
        if (! is_array($item)) {
            return parent::normalizeInbound($payload, $headers);
        }
        $message = is_array($item['message'] ?? null) ? $item['message'] : [];
        $sender = Arr::get($item, 'sender.id');
        $recipient = Arr::get($item, 'recipient.id');
        $messageId = $message['mid'] ?? null;
        $eventId = (string) ($messageId ?? ($item['timestamp'] ?? Arr::get($payload, 'entry.0.id', '')));
        return new NormalizedInboundMessage(
            $this->key(), $eventId, (string) ($sender ?? $eventId), $messageId === null ? null : (string) $messageId,
            $sender === null ? null : (string) $sender, $recipient === null ? null : (string) $recipient,
            isset($message['text']) ? (string) $message['text'] : null,
            empty($message['attachments']) ? 'text' : 'attachment',
            is_array($message['attachments'] ?? null) ? $message['attachments'] : [],
            ['raw' => $payload], isset($item['timestamp']) ? (string) $item['timestamp'] : null,
        );
    }
}
