<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Jobs;
use App\Extensions\TitanTimeAttendance\System\Services\TimeAttentionService;use Illuminate\Bus\Queueable;use Illuminate\Contracts\Queue\ShouldBeUnique;use Illuminate\Contracts\Queue\ShouldQueue;use Illuminate\Foundation\Bus\Dispatchable;use Illuminate\Queue\InteractsWithQueue;use Illuminate\Queue\SerializesModels;
final class DetectTimeAttentionJob implements ShouldQueue,ShouldBeUnique
{
    use Dispatchable,InteractsWithQueue,Queueable,SerializesModels;
    public int $tries=3;public array $backoff=[30,120,300];
    public function __construct(public readonly int $tenantCompanyId){$this->onQueue('titan-time-attendance');}
    public function uniqueId(): string{return 'time-attention:'.$this->tenantCompanyId;}
    public function handle(TimeAttentionService $service): void{$service->refreshTenant($this->tenantCompanyId);}
}
