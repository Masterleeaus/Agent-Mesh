# Release Status

Titan Nexus `1.0.0-rc.2` is package-certified after the RC1 deep-audit remediation cycle and RC2 deep adversarial-safety hardening.

Step 2 adds explicit regression attacks for strict booleans, approval downgrade, agent/system Autonomy, secret variants, idempotency tampering, optimistic concurrency guards, tenant mismatches, malformed canonical definitions, mutation receipts, dependency cycles and menu registration failure isolation.

Step 3 adds the durable compilation lifecycle journal so Business Profile identity, validation outcomes, compilation output, recompile/diff evidence, provisioning plans and receipts remain reconstructable as an ordered tenant-scoped trace instead of existing only as the latest mutable aggregate.


Step 4 adds dependency/capability readiness truth: runtime health now evaluates database, Vertical Engine, Command Bus, Risk, Governance, Assurance, Signal, Rewind, conditional Autonomy/Knowledge Authority and optional Interface Runtime, and publishes exact available/unavailable capability projections instead of equating manifest presence with runtime usability.

Step 5 adds deterministic Installer 1.7.6/1.7.8 fresh-install preflight certification for package identity/integrity, provider lifecycle entrypoints, migration order/MySQL compatibility, routes/views, config publishing, Interface Runtime contribution and navigation wiring. The preflight passes package-side while live `INSTALLER_CERTIFIED` remains `NOT_RUN` until this exact ZIP is executed on the real MagicAI/Titan host.

It is **not final `1.0.0`** because the live MagicAI/Titan host is not mounted in the isolated build environment. Installer, migration, provider-boot, navigation, authorization, runtime, upgrade and uninstall stages therefore remain `NOT_RUN` until executed against the exact deployment host.

Production promotion also requires trusted release signing. No trusted signing identity is fabricated by this build.

Step 6 preparation adds deterministic existing-install upgrade preflight. Package-side checks now verify the target package remains fresh-install safe, migration ordering is stable, route/menu/service identities are unique, and installed-host facts can be evaluated for RC1→RC2 migration-prefix compatibility, duplicate compilation identities, lifecycle-table consistency and downgrade hazards. Live `UPGRADE_CERTIFIED` remains `NOT_RUN` until this exact ZIP is applied over a real prior Nexus installation.

Step 7 preparation adds deterministic provider/container boot preflight, removes unused HTTP Kernel injection from provider boot, recursively verifies constructor-injected Nexus contracts have bindings, and makes route registration idempotent within a running application. Package-side provider preflight passes while live `BOOT_CERTIFIED` remains `NOT_RUN` until the exact ZIP boots on the target MagicAI/Titan host.


Pass7-H1 responds to live Installer 1.7.6 validation failure `01M0GR9Z95Z34RZQBF1WMN8021`. The root cause was a compatibility regression in `extension.json`: the RC2 Titan manifest omitted the legacy MagicAI fields `name`, `type`, `description`, and `support_telegram`, while the internal manifest contract incorrectly rejected `name` as unsupported. The hotfix restores those fields, updates the internal contract, and explicitly recognizes the observed Installer 1.7.6 host profile. Live install must be retried with the exact H1 ZIP before `INSTALLER_CERTIFIED` can advance.
