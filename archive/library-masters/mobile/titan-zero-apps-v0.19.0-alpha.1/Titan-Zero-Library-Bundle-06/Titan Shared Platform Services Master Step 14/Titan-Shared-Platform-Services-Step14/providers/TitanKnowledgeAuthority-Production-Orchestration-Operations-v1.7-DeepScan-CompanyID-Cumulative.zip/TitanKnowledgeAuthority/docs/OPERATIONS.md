# Operations
The extension boots synchronously and uses no queue, schedule, webhook, remote host, or external provider in this pass. `config/titan-knowledge-authority.php` contains the local enable/refresh gates; refresh remains disabled.
