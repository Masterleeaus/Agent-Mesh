# Titan Signal Engine v0.6.0 — Pass 6 Upgrade Report

## Implemented

- rule-based anomaly engine and public contract
- deterministic thresholds, severity, confidence and evidence
- Pulse trace event-count projection for execution-loop detection
- Pulse causation-reference projection with late-parent repair
- versioned Correlation trace-evaluation projection for sequence integrity
- repeated failure, retry/dead-letter, stalled workflow, missing receipt, override, volume-collapse, sequence and causal-integrity rules
- 24-hour cold-start safeguard for volume collapse
- offline causal-parent grace period
- anomaly deduplication and prioritized feed
- acknowledge, suppress, resolve and reopen lifecycle
- explicit lifecycle authorization
- new/reopened anomaly telemetry only
- scheduled anomaly scanner and health metrics
- standalone rule behavior runner and host-Laravel integration tests

## Deliberately not implemented

- ML anomaly scoring
- cross-tenant anomaly aggregation
- direct PagerDuty/Slack alert policy
- arbitrary raw-event scans during anomaly detection
- destructive retention

Those boundaries keep Signal observational and transparent.
