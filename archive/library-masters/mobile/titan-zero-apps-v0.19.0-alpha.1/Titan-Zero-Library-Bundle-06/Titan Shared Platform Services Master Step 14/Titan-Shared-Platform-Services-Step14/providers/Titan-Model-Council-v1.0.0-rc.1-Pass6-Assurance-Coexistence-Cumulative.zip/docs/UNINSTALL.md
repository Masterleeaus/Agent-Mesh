# Uninstall

Uninstall removes published Council configuration but preserves durable Council data by default. The extension manifest declares `preserve_data=true`. Host-controlled purge/anonymisation must be an explicit governed retention operation, tenant scoped and auditable.

The extension must stop new deliberation work before uninstall. Provider calls are not background-owned by this package after request termination.
