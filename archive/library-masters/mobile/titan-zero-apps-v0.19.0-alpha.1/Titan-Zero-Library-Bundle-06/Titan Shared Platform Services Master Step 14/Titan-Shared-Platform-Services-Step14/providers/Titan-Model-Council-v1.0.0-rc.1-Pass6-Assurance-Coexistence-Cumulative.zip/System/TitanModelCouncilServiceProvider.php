<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanModelCouncil\System\Compatibility\Legacy\LegacyCouncilAdapter;
use App\Extensions\TitanModelCouncil\System\Compatibility\Legacy\LegacyGovernedProviderRuntime;
use App\Extensions\TitanModelCouncil\System\Compatibility\Legacy\Models\ModelCouncilResponse as LegacyModelCouncilResponse;
use App\Extensions\TitanModelCouncil\System\Compatibility\Legacy\Services\ModelCouncilService as LegacyModelCouncilService;
use App\Extensions\TitanModelCouncil\System\Contracts\CouncilGatewayContract;
use App\Extensions\TitanModelCouncil\System\Contracts\ExtensionHealth;
use App\Extensions\TitanModelCouncil\System\Health\TitanModelCouncilHealthCheck;
use App\Extensions\TitanModelCouncil\System\Signal\CouncilSignalEmitter;
use App\Extensions\TitanModelCouncil\System\Signal\SignalPeerRegistration;
use App\Extensions\TitanModelCouncil\System\Navigation\HostNavigationRegistrar;
use App\Extensions\TitanModelCouncil\System\Navigation\ModelCouncilNavigation;
use App\Extensions\TitanModelCouncil\System\Models\HostMenuRecord;
use App\Extensions\TitanModelCouncil\System\Assurance\CouncilAssuranceBridge;
use App\Extensions\TitanModelCouncil\System\Receipts\CouncilDecisionReceiptService;
use App\Extensions\TitanModelCouncil\System\Commands\CertifyExtensionCommand;
use App\Extensions\TitanModelCouncil\System\Governed\CouncilParticipantExecutor;
use App\Extensions\TitanModelCouncil\System\Governed\CouncilParticipantExecutorContract;
use App\Extensions\TitanModelCouncil\System\Governed\GovernedCouncilRuntime;
use App\Extensions\TitanModelCouncil\System\Governed\GovernedDeliberationOrchestrator;
use App\Extensions\TitanModelCouncil\System\Governed\GovernedProviderRuntimeContract;
use App\Extensions\TitanModelCouncil\System\Billing\CouncilBillingReservationService;
use App\Extensions\TitanModelCouncil\System\AICore\AICoreRuntimeProbe;
use App\Extensions\TitanModelCouncil\System\Policies\SelectiveActivationPolicy;
use App\Extensions\TitanModelCouncil\System\Risk\CouncilRiskGatewayContract;
use App\Extensions\TitanModelCouncil\System\Risk\NullCouncilRiskGateway;
use App\Extensions\TitanModelCouncil\System\Risk\TitanRiskEngineGateway;
use App\Extensions\TitanModelCouncil\System\Policies\AdaptiveQuorumPolicy;
use App\Extensions\TitanModelCouncil\System\Persistence\CouncilDecisionRepository;
use App\Extensions\TitanModelCouncil\System\Quality\ContradictionResolver;
use App\Extensions\TitanModelCouncil\System\Tenancy\TenantContextResolver;
use App\Extensions\TitanModelCouncil\System\Tenancy\TenantIdResolver;
use App\Extensions\TitanModelCouncil\System\Http\Controllers\Compatibility\ModelCouncilController as LegacyModelCouncilController;
use App\Extensions\TitanModelCouncil\System\Services\CouncilGateway;
use App\Extensions\TitanModelCouncil\System\Settings\ModelCouncilSettingsRepository;
use App\Extensions\TitanModelCouncil\System\Shield\CouncilShieldGateContract;
use App\Extensions\TitanModelCouncil\System\Shield\LocalCouncilShieldGate;
use App\Extensions\TitanModelCouncil\System\Shield\ShieldAwareCouncilGate;
use App\Extensions\TitanModelCouncil\System\Shield\ShieldRuntimeProbe;
use App\Extensions\TitanModelCouncil\System\Shield\TitanShieldInspectionBridge;
use App\Helpers\Classes\MarketplaceHelper;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

final class TitanModelCouncilServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-model-council.php', 'titan-model-council');
        SignalPeerRegistration::register($this->app);
        $this->registerLegacyClassAliases();
        $this->app->singleton(LegacyModelCouncilService::class);
        $this->app->singleton(LegacyCouncilAdapter::class);
        $this->app->singleton(GovernedProviderRuntimeContract::class, LegacyGovernedProviderRuntime::class);
        $this->app->singleton(CouncilParticipantExecutorContract::class, CouncilParticipantExecutor::class);
        $this->app->singleton(CouncilBillingReservationService::class);
        $this->app->singleton(AICoreRuntimeProbe::class, static fn ($app) => new AICoreRuntimeProbe(
            executionContract: (($contract = config('titan-model-council.ai_core.execution_contract')) && is_string($contract)) ? $contract : null,
        ));
        $this->app->singleton(CouncilRiskGatewayContract::class, static function ($app): CouncilRiskGatewayContract {
            if ((bool) config('titan-model-council.risk_engine.enabled', true) && TitanRiskEngineGateway::isAvailable($app)) {
                return new TitanRiskEngineGateway($app);
            }
            return new NullCouncilRiskGateway();
        });
        $this->app->singleton(CouncilDecisionRepository::class);
        $this->app->singleton(CouncilAssuranceBridge::class);
        $this->app->singleton(CouncilDecisionReceiptService::class);
        $this->app->singleton(CouncilSignalEmitter::class, static fn ($app) => new CouncilSignalEmitter(
            $app,
            (array) config('titan-model-council.signal.contract_candidates', []),
        ));
        $this->app->singleton(ModelCouncilSettingsRepository::class);
        $this->app->singleton(ModelCouncilNavigation::class);
        $this->app->singleton(HostNavigationRegistrar::class);
        $this->app->singleton(ExtensionHealth::class, TitanModelCouncilHealthCheck::class);
        $this->app->singleton(AdaptiveQuorumPolicy::class, static fn () => new AdaptiveQuorumPolicy(
            (int) config('titan-model-council.adaptive_quorum.minimum_successful_participants', 2),
            (int) config('titan-model-council.adaptive_quorum.minimum_agreement_percent', 90),
        ));
        $this->app->singleton(TenantIdResolver::class);
        $this->app->singleton(TenantContextResolver::class);
        $this->app->singleton(ContradictionResolver::class, static fn () => new ContradictionResolver((int) config('titan-model-council.contradiction.confidence_ceiling', 50)));
        $this->app->singleton(SelectiveActivationPolicy::class, static fn () => new SelectiveActivationPolicy((array) config('titan-model-council.selective_activation', [])));
        $this->app->singleton(ShieldRuntimeProbe::class, static fn ($app) => new ShieldRuntimeProbe(
            $app,
            (($contract = config('titan-model-council.shield.validation_contract')) && is_string($contract)) ? $contract : null,
        ));
        $this->app->singleton(LocalCouncilShieldGate::class);
        $this->app->singleton(TitanShieldInspectionBridge::class);
        $this->app->singleton(CouncilShieldGateContract::class, ShieldAwareCouncilGate::class);
        $this->app->singleton(GovernedDeliberationOrchestrator::class);
        $this->app->singleton(GovernedCouncilRuntime::class);
        $this->app->singleton(CouncilGatewayContract::class, CouncilGateway::class);
    }

    public function boot(Kernel $kernel): void
    {
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-model-council');
        $this->loadViewsFrom(__DIR__ . '/../resources/views/legacy', 'model-council');
        $this->loadTranslationsFrom(__DIR__ . '/../resources/lang', 'model-council');
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        // Apply persisted Super Admin policy overrides before runtime services are resolved.
        // Missing settings table is expected during first install and is fail-open.
        try {
            $this->app->make(ModelCouncilSettingsRepository::class)->applyRuntimeOverrides();
        } catch (\Throwable) {
            // Extension defaults remain authoritative until settings storage is available.
        }
        $this->publishes([
            __DIR__ . '/../config/titan-model-council.php' => config_path('titan-model-council.php'),
        ], 'extension');

        $this->registerRoutes();
        $this->registerCompatibilityRoutes();

        // Self-heal both tenant-user and Super Admin host navigation after the
        // application is fully booted. Navigation failure must never prevent Council boot.
        $this->app->booted(function (): void {
            try {
                $navigation = $this->app->make(HostNavigationRegistrar::class);
                $navigation->registerContributions();
                $navigation->syncHostMenus();
            } catch (\Throwable) {
                // Host navigation compatibility is fail-open.
            }
        });
        if ($this->app->runningInConsole()) {
            $this->commands([CertifyExtensionCommand::class]);
        }
    }

    public function registerKey(): string
    {
        return 'titan-model-council';
    }

    public static function uninstall(): void
    {
        File::delete(config_path('titan-model-council.php'));

        try {
            if (Schema::hasTable('menus') && Schema::hasColumn('menus', 'key')) {
                HostMenuRecord::query()
                    ->whereIn('key', [
                        'titan_model_council',
                        'titan_model_council_admin',
                        'titan_model_council_admin_overview',
                        'titan_model_council_admin_settings',
                        'titan_model_council_admin_strategies',
                        'titan_model_council_admin_providers',
                        'titan_model_council_admin_integrations',
                        'titan_model_council_admin_billing',
                        'titan_model_council_admin_diagnostics',
                    ])
                    ->delete();

                $menuService = 'App\\Services\\Common\\MenuService';
                if (class_exists($menuService) && method_exists($menuService, 'regenerate')) {
                    try {
                        app($menuService)->regenerate();
                    } catch (\Throwable) {
                        try {
                            $menuService::regenerate();
                        } catch (\Throwable) {
                            // Menu rows are already removed; cache will refresh on a later request.
                        }
                    }
                }
            }
        } catch (\Throwable) {
            // Navigation cleanup must never prevent extension uninstall.
        }
    }

    private function registerLegacyClassAliases(): void
    {
        // Never shadow an actively registered copy of the original extension.
        if (MarketplaceHelper::isRegistered('model-council')) {
            return;
        }

        $aliases = [
            'App\\Extensions\\ModelCouncil\\System\\Services\\ModelCouncilService' => LegacyModelCouncilService::class,
            'App\\Extensions\\ModelCouncil\\System\\Models\\ModelCouncilResponse' => LegacyModelCouncilResponse::class,
            'App\\Extensions\\ModelCouncil\\System\\Http\\Controllers\\ModelCouncilController' => LegacyModelCouncilController::class,
        ];

        foreach ($aliases as $legacyClass => $titanClass) {
            // autoload=false avoids loading a disabled legacy package merely because
            // its files remain on disk during a staged migration.
            if (! class_exists($legacyClass, false)) {
                class_alias($titanClass, $legacyClass);
            }
        }
    }

    private function registerRoutes(): void
    {
        /** @var Router $router */
        $router = $this->app['router'];
        $router->group([
            'middleware' => ['web', 'auth'],
            'prefix' => 'dashboard/user/titan-model-council',
            'as' => 'dashboard.user.titan.model.council.',
        ], static function (Router $router): void {
            require __DIR__ . '/../routes/user.php';
        });

        $router->group([
            'middleware' => ['web', 'auth', 'admin'],
            'prefix' => 'dashboard/admin/titan-model-council',
            'as' => 'dashboard.admin.titan.model.council.',
        ], static function (Router $router): void {
            require __DIR__ . '/../routes/admin.php';
        });
    }

    private function registerCompatibilityRoutes(): void
    {
        if (! MarketplaceHelper::isRegistered('ai-chat-pro')) {
            return;
        }

        // Avoid collisions when either the original Model Council or Multi-Model
        // extension still owns the legacy /dashboard/user/multimodel surface.
        if (MarketplaceHelper::isRegistered('model-council') || MarketplaceHelper::isRegistered('multi-model')) {
            return;
        }

        /** @var Router $router */
        $router = $this->app['router'];
        $router->group([
            'middleware' => ['web', 'auth'],
            'prefix' => 'dashboard/user/multimodel',
        ], static function (Router $router): void {
            require __DIR__ . '/../routes/compatibility.php';
        });
    }
}
