<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\DTO;

final readonly class CommandDispatchReceipt
{
    public function __construct(
        public string $planId,
        public string $stepId,
        public string $status,
        public string $reasonCode,
        public ?string $receiptId = null,
        public array $metadata = [],
    ) {}

    public static function accepted(string $planId, string $stepId, string $receiptId, array $metadata = []): self
    {
        return new self($planId, $stepId, 'ACCEPTED', 'COMMAND_ACCEPTED', $receiptId, $metadata);
    }

    public static function blocked(string $planId, string $stepId, string $reasonCode, array $metadata = []): self
    {
        return new self($planId, $stepId, 'BLOCKED', $reasonCode, null, $metadata);
    }

    public static function unavailable(string $planId, string $stepId, string $reasonCode = 'COMMAND_BUS_UNAVAILABLE'): self
    {
        return new self($planId, $stepId, 'UNAVAILABLE', $reasonCode);
    }
}
