# Titan CRM Core Production Readiness — alpha.29

Run `php artisan crm:production-check` after installation and after changing engine bindings. The command is non-mutating and returns a blocked state when production prerequisites are absent.

## Blocking requirements

- All required CRM Core tables exist.
- Titan Command Bus port is bound when `CRM_PRODUCTION_REQUIRE_COMMAND_BUS=true` (default).
- Titan Signal delivery port is bound when `CRM_PRODUCTION_REQUIRE_SIGNAL_DELIVERY=true` (default).
- `CRM_ALLOW_LEGACY_LOCAL_HUMAN_MUTATIONS` remains false.
- A real `CrmPortalFileScanner` implementation is bound when portal scanning is required.

Titan Field owns Titan Go field/offline sync secrets and state. CRM Core no longer requires or validates `CRM_MOBILE_SYNC_SECRET`.

## Expected warnings

- Deferred communication driver means Titan Connect is not yet executing outbound messages.
- CQRS live fallback means some Core read traffic may fall back to OLTP and should be disabled for scaled deployments.
- Missing Titan Autonomy means AI authority remains approval-only.
- Preserved legacy CRM autonomy/learning tables remain migration evidence until destination import receipts are verified.

## Extracted domains

Titan Field, Locker, Ledger and Pay are optional to CRM Core boot. Their legacy `crm.*` capability names are compatibility routing contracts only. Missing extracted domains must produce actionable dependency failures; CRM Core must never reclaim their writes.

## Host validation still required

Package verification proves source, installer and static runtime contracts. Before public production traffic, run the readiness command against the real host, apply migrations, verify Command Bus/Signal/scanner bindings, and perform deployment-specific database/load/backup/restore tests.

## Alpha.28 identity gate
Production readiness blocks if customer identity tables are missing or active companies/contacts/leads lack `customer_unification_id`. Pending blocking duplicate reviews are surfaced as operational warnings requiring resolution.

## Alpha.29 commercial-contract gate

Production readiness requires `crm_sales_document_render_jobs` and verifies that previously issued proposals/estimates have immutable issued snapshots. Accepted contracts without acceptance evidence are blockers. Failed/stalled document render jobs are surfaced operationally. Run `php artisan crm:documents:render` under the production queue/scheduler strategy and use durable storage appropriate to the deployment.

## Alpha.30 invoice & receivables gate

Production readiness blocks when issued invoices lack immutable invoice-contract snapshots. It warns on open settlement reconciliation issues and on `refund_due_minor` amounts that Titan Pay must refund. CRM does not require legacy local payment tables.


## Alpha.31 command governance
- `crm:governance:audit-writes` must report PASS.
- `crm_capability_operations` must contain all Command Contract v3 evidence columns.
- `crm:production-check` treats either failure as a blocker.
- Privacy/retention destructive execution must remain behind Command Bus.

## Alpha.34 reliability gate
- Run `php artisan crm:production-check --json` for PASS/WARN/BLOCK severity.
- Run `php artisan crm:metrics --json` for structured command/Signal/projection/outbound/import/portal/webhook metrics.
- Run `php artisan crm:doctor --json` for remediation guidance.
- Follow `docs/CRM-OPERATIONS-RUNBOOK.md`; never clear evidence or enable legacy write fallbacks during incident recovery.


## Alpha.35 performance & scale gate
- Rebuild the disposable projection term index after upgrade with `php artisan crm:projections:search-index <company_id>`.
- Run `php artisan crm:performance:certify <company_id> --iterations=5 --json` against representative production-like tenants.
- Treat package `bin/benchmark-v130-alpha35-scale.php` output as synthetic working-set evidence only; it does not certify live MySQL latency.
- Large full projection rebuilds must use the incremental `--until-complete` path rather than silent truncation.
- Do not introduce table partitioning until host profiling proves indexed/bounded architecture is insufficient.

## Alpha.36 canonical tenancy and permissions gate

- `company_id` is the authoritative CRM tenant boundary after migration `2026_08_18_000045_canonical_company_tenancy.php`.
- Contacts/deals use `customer_company_id` for their linked CRM organisation; tenant identity must never come from a client payload.
- `crm:production-check` returns BLOCK while `crm.permissions.strict_host_gates` is disabled. Enable strict mode only after the host has registered the CRM permission Gates.
- Extracted Field/Locker/Ledger/Pay and historical Autonomy tables are intentionally outside CRM Core's canonical-company migration.
