<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Certification;
final class RewindFaultMatrix
{
    public function cases(): array
    {
        return [
            'source_timeout'=>['retryable'=>true,'expected'=>'bounded-retry-then-attention-required'],
            'queue_unavailable'=>['retryable'=>true,'expected'=>'backpressure-or-dead-letter'],
            'signal_circuit_open'=>['retryable'=>true,'expected'=>'outbox-retained-until-half-open'],
            'integrity_mismatch'=>['retryable'=>false,'expected'=>'fail-closed'],
            'replay_boundary_violation'=>['retryable'=>false,'expected'=>'permanent-failure-and-signal'],
            'signing_key_unavailable'=>['retryable'=>false,'expected'=>'evidence-generation-blocked'],
            'governance_unavailable'=>['retryable'=>true,'expected'=>'no-self-approval'],
            'legal_hold_conflict'=>['retryable'=>false,'expected'=>'purge-blocked'],
        ];
    }
}
