<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use DomainException;
use Illuminate\Database\ConnectionInterface;

/** Cross-domain invariants that protect authoritative CRM state at the governed boundary. */
final class CrmDomainInvariantGuard
{
    public function __construct(private readonly ConnectionInterface $db,private readonly CrmCompanyScope $scope) {}

    public function assertBefore(string $capability,array $input,?array $snapshot): void
    {
        $state=(array)($snapshot['state']??[]);$status=strtolower((string)($state['status']??''));

        if(in_array($capability,['crm.work_order.assign','crm.work_order.reschedule'],true) && in_array($status,['completed','invoiced','closed','cancelled'],true)){
            throw new DomainException("Work order in {$status} state cannot remain dispatchable or be rescheduled.");
        }
        if($capability==='crm.work_order.cancel' && in_array($status,['completed','invoiced','closed'],true)){
            throw new DomainException('Completed/closed work cannot be cancelled; use the governed reopen/correction lifecycle.');
        }
        if(in_array($capability,['crm.invoice.send','crm.invoice.reminder.send'],true) && in_array($status,['draft','void','cancelled','paid'],true)){
            throw new DomainException("Invoice in {$status} state cannot be sent as an open receivable.");
        }
        if($capability==='crm.appointment.create')$this->assertNoSchedulingConflict($input,null);
        if($capability==='crm.work_order.assign'){
            $worker=(int)($input['worker_user_id']??$input['assigned_user_id']??0);
            $window=[
                'assigned_user_id'=>$worker,
                'scheduled_start'=>$input['scheduled_start']??($state['scheduled_start']??null),
                'scheduled_end'=>$input['scheduled_end']??($state['scheduled_end']??null),
            ];
            $this->assertNoSchedulingConflict($window,(string)($state['public_id']??$input['public_id']??$input['work_order_public_id']??''));
        }
    }


    private function assertNoSchedulingConflict(array $input,?string $sameWorkOrder): void
    {
        $worker=(int)($input['assigned_user_id']??0);$start=$input['scheduled_start']??null;$end=$input['scheduled_end']??null;
        if($worker<1||!is_string($start)||$start===''||!is_string($end)||$end==='')return;
        if(!$this->db->getSchemaBuilder()->hasTable('crm_appointments'))return;
        $query=$this->db->table('crm_appointments')->where('company_id',$this->scope->current()->companyId)
            ->where('assigned_user_id',$worker)->whereNull('deleted_at')->whereNotIn('status',['cancelled','completed'])
            ->where('scheduled_start','<',$end)->where('scheduled_end','>',$start);
        if($sameWorkOrder!==''&&$sameWorkOrder!==null)$query->where(function($q)use($sameWorkOrder):void{$q->whereNull('work_order_public_id')->orWhere('work_order_public_id','!=',$sameWorkOrder);});
        if($query->exists())throw new DomainException('Scheduling conflict: assigned worker already has an overlapping appointment.');
    }
}
