<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Tenancy;

use App\Models\User;
use Illuminate\Http\Request;

final class TenantContextResolver
{
    public function __construct(private readonly TenantIdResolver $ids = new TenantIdResolver())
    {
    }

    /** @param array<string,mixed> $context */
    public function resolve(Request $request, ?User $user = null, array $context = []): ?TenantContext
    {
        $attributeValue = $request->attributes->get('company_id') ?? $request->attributes->get('tenant_company_id');
        $userValue = null;
        if ($user && method_exists($user, 'getAttribute')) {
            $userValue = $user->getAttribute('company_id') ?? $user->getAttribute('tenant_company_id');
        }
        $id = $this->ids->resolve(
            ['company_id' => $attributeValue, 'tenant_company_id' => $attributeValue],
            $context,
            ['company_id' => $userValue, 'tenant_company_id' => $userValue],
        );
        return $id ? new TenantContext($id) : null;
    }
}
