<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Commands;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceManagerContract;
use Illuminate\Console\Command;

final class RefreshGovernanceProjectionsCommand extends Command
{
    protected $signature='titan:titan-governance:refresh-projections {--tenant= : Tenant company ID to refresh}';
    protected $description='Refresh Titan Governance read-side projections for one tenant.';

    public function handle(GovernanceManagerContract $governance): int
    {
        $tenant=(int)$this->option('tenant');
        if($tenant<1){$this->error('A positive --tenant company ID is required.');return self::INVALID;}
        $snapshot=$governance->dashboardSnapshot($tenant);
        $status=(string)($snapshot['projection']['write_status'] ?? 'DEGRADED');
        $this->line(json_encode(['tenant_company_id'=>$tenant,'projection_write_status'=>$status,'source_health'=>$snapshot['source_health']['status'] ?? 'UNAVAILABLE'],JSON_UNESCAPED_SLASHES));
        return $status==='HEALTHY'?self::SUCCESS:self::FAILURE;
    }
}
