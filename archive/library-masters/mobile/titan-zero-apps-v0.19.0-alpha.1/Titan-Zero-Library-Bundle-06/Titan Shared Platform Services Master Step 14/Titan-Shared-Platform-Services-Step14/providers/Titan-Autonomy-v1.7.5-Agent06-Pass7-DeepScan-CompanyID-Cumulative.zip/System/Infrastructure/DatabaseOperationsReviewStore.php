<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\OperationsReviewStoreContract;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class DatabaseOperationsReviewStore implements OperationsReviewStoreContract
{
    public function append(array $review): string
    {
        $id = (string)Str::ulid();
        app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_execution_reviews')->insert([
            'public_id' => $id,
            'receipt_public_id' => (string)$review['receipt_public_id'],
            'tenant_company_id' => (int)$review['tenant_company_id'],
            'user_id' => (int)$review['user_id'],
            'review_status' => (string)$review['review_status'],
            'note' => $review['note'] ?? null,
            'policy_version' => (string)($review['policy_version'] ?? 'unknown'),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        return $id;
    }

    public function forReceipt(int $tenantCompanyId, string $receiptPublicId, int $limit = 100): array
    {
        return array_map(fn($r)=>(array)$r, app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_execution_reviews')
            ->where('tenant_company_id', $tenantCompanyId)->where('receipt_public_id', $receiptPublicId)
            ->orderByDesc('id')->limit(max(1, min(500, $limit)))->get()->all());
    }
}
