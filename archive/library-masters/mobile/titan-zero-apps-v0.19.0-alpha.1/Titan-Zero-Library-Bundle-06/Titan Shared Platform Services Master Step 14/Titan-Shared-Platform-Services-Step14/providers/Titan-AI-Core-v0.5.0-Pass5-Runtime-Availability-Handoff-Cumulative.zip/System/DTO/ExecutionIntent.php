<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class ExecutionIntent {
    /** @param array<string,mixed> $parameters */
    public function __construct(public string $type, public string $objective, public array $parameters = []) {}
    public function toArray(): array { return ['type'=>$this->type,'objective'=>$this->objective,'parameters'=>$this->parameters]; }
}
