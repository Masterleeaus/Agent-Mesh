<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use LogicException;

final class KnowledgeSourceVersion extends Model
{
    protected $table = 'titan_knowledge_source_versions';

    protected $guarded = [
        'id', 'source_id', 'version_sequence', 'version_key', 'content_hash',
        'raw_evidence_hash', 'supersedes_version_id', 'tenant_company_id', 'immutable',
    ];

    protected $casts = [
        'immutable' => 'boolean',
        'provenance' => 'array',
        'metadata' => 'array',
        'retrieved_at' => 'immutable_datetime',
        'published_at' => 'immutable_datetime',
        'effective_from' => 'immutable_datetime',
        'effective_until' => 'immutable_datetime',
    ];

    protected static function booted(): void
    {
        static::creating(static function (self $version): void {
            if ((bool) $version->immutable !== true) {
                throw new LogicException('Knowledge source versions must be created as immutable records.');
            }
            if ((int) $version->source_id <= 0 || (int) $version->version_sequence <= 0) {
                throw new LogicException('Knowledge source versions require positive source and sequence identifiers.');
            }
            if (! preg_match('/^v\d{10}$/', (string) $version->version_key)) {
                throw new LogicException('Knowledge source version keys must use the canonical v########## format.');
            }
            foreach (['content_hash', 'raw_evidence_hash'] as $hashField) {
                if (! preg_match('/^[a-f0-9]{64}$/', (string) $version->{$hashField})) {
                    throw new LogicException("{$hashField} must be a SHA-256 hex digest.");
                }
            }
        });

        static::updating(static function (): never {
            throw new LogicException('Knowledge source versions are immutable; create a new version instead.');
        });
        static::deleting(static function (): never {
            throw new LogicException('Knowledge source versions are immutable and may not be deleted.');
        });
    }

    public function source(): BelongsTo
    {
        return $this->belongsTo(KnowledgeSource::class, 'source_id');
    }

    public function supersedes(): BelongsTo
    {
        return $this->belongsTo(self::class, 'supersedes_version_id');
    }

    public function supersededBy(): HasOne
    {
        return $this->hasOne(self::class, 'supersedes_version_id');
    }

    public function documents(): HasMany
    {
        return $this->hasMany(KnowledgeDocument::class, 'source_version_id');
    }

    public function claims(): HasMany
    {
        return $this->hasMany(KnowledgeClaim::class, 'source_version_id');
    }
}
