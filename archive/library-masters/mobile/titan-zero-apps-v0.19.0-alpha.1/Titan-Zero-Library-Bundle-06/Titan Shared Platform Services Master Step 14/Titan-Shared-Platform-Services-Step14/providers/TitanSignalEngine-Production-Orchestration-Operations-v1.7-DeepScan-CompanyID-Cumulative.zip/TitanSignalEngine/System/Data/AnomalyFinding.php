<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class AnomalyFinding
{
    /** @param array<string,mixed> $evidence */
    public function __construct(
        public string $type,
        public string $severity,
        public int $score,
        public float $confidence,
        public string $subjectType,
        public string $subjectId,
        public array $evidence,
    ) {
        if (! preg_match('/^[a-z0-9._-]+$/', $this->type)) {
            throw new InvalidArgumentException('Anomaly type must be a lowercase slug.');
        }
        if (! in_array($this->severity, ['info', 'warn', 'high', 'critical'], true)) {
            throw new InvalidArgumentException('Invalid anomaly severity.');
        }
        if ($this->score < 0 || $this->score > 100) {
            throw new InvalidArgumentException('Anomaly score must be between 0 and 100.');
        }
        if ($this->confidence < 0.0 || $this->confidence > 1.0) {
            throw new InvalidArgumentException('Anomaly confidence must be between 0 and 1.');
        }
        if ($this->subjectType === '' || $this->subjectId === '') {
            throw new InvalidArgumentException('Anomaly subject type and id are required.');
        }
    }

    public function deduplicationKey(string $scope, ?int $tenantCompanyId): string
    {
        return hash('sha256', implode('|', [
            $scope,
            (string) ($tenantCompanyId ?? 'system'),
            $this->type,
            $this->subjectType,
            $this->subjectId,
        ]));
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'type' => $this->type,
            'severity' => $this->severity,
            'score' => $this->score,
            'confidence' => $this->confidence,
            'subject_type' => $this->subjectType,
            'subject_id' => $this->subjectId,
            'evidence' => $this->evidence,
        ];
    }
}
