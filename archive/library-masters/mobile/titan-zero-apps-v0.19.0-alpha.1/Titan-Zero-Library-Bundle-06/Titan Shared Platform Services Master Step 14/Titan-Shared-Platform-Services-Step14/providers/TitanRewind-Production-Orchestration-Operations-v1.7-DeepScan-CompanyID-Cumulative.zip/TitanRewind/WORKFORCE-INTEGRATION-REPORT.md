# Workforce Integration Report

## Provider

- Extension: `Titan Rewind` (`titan-rewind`)
- Source version: `1.0.6`
- Existing Blueprint manifest schema: `2.0`
- Canonical Workforce tenant boundary for this integration: `company_id`

## Deep-scan outcome

This pass found no active extension-owned Workforce employee/role registry that should remain authoritative. Existing domain capabilities remain extension-owned. Existing `tenant_company_id` references are treated as legacy compatibility/persistence surfaces rather than being mass-renamed without a migration contract.

Published Workforce surfaces: **41 read capabilities**, **2 command/side-effect candidates**, **2 declared emitted events discovered from capability contracts**, and **5 normalized work types**. Availability fails closed and is independent from authorization, governance, risk, assurance and Titan Autonomy.

## Architecture boundary

Rewind is reconstruction/audit evidence, not a parallel command authority. Titan AI Workforce owns employee identity, hierarchy, teams, responsibilities, assignments, work items and orchestration. This extension owns its domain implementation and exposes provider-provenanced execution/read/evidence surfaces only.

## Compatibility and unresolved baseline drift

- Existing persisted/runtime `tenant_company_id` contracts were not destructively renamed. New Workforce integration uses `company_id`; legacy fields are adapter-only compatibility.
- Blueprint canonical validation may still report pre-existing installer/Manifest-v2.2 convergence or raw-DB architecture findings. Those require extension-specific host-aware remediation and must not be hidden by this Workforce pass.
- Host certification is not claimed by this local batch verification.

## Verification

Run `php tests/standalone/verify_workforce_integration.php`, PHP lint across the package, JSON parse across all JSON files, and the Blueprint package/migration scanners. Final batch evidence is in the outer `AGENT-BATCH-REPORT.md`.


## Further convergence pass

- Upgraded provider contract to `titan.workforce.extension-provider.v1.1`.
- Added explicit `titan.observation-knowledge-outcome-loop.v1` role and causal handoff requirements.
- Added executable standalone verification and JSON Schema for the provider contract.
- Canonical integration tenancy remains `company_id`; legacy tenant fields are compatibility-only.
- Work item identity/orchestration remains owned by Titan AI Workforce; provider changes never rewrite employee role identity.
