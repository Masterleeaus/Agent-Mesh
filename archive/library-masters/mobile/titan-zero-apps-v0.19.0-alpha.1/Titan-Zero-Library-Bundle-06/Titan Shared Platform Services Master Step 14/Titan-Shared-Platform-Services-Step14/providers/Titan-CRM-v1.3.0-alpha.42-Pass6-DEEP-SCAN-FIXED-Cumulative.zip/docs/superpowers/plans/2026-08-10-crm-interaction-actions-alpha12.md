# CRM 1.3.0-alpha.12 Conversational Operations Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Extend CRM's Interaction-first UX from creation into ongoing operations so Titan Zero can update existing records, perform governed operational actions, chain workflows, and prepare controlled bulk actions conversationally.

**Architecture:** CRM remains system of record and capability executor. Interaction Engine remains the structured wizard/session/authority runtime. Alpha.12 adds record-action journeys, a context-aware action resolver, CRM chain orchestration between completed journeys, and a preview-first bulk planner. Autonomous execution is allowed only through the existing CRM authority policy and Interaction Engine command bus; approval-gated actions remain human-approved.

**Tech Stack:** PHP 8.2+, Laravel 10 / MagicAI 11, Blade, Titan Interaction Engine >=10.3.1 <11.0, TitanAI CRM Interaction tools, CRM capability registry/executor, JSON wizard definitions.

## Global Constraints

- Build from certified CRM `1.3.0-alpha.11`.
- Interaction Engine compatibility remains `>=10.3.1 <11.0`.
- CRM tenancy remains `tenant_company_id`; CRM `company_id` remains customer/account relationship data.
- No WorkCore runtime dependency.
- No direct AI financial arithmetic; Financial Assistants remain authoritative.
- All writes go through governed CRM capabilities and Interaction Engine authority.
- AI cannot mint approvals or bypass approval-required actions.
- Existing alpha.8 icon, alpha.9 route-cache, alpha.10 menu, and alpha.11 Interaction-first protections remain intact.

---

### Task 1: Context-aware record action catalogue

**Files:**
- Modify: `System/Integrations/InteractionEngine/CrmInteractionJourneyRegistry.php`
- Create: `System/Integrations/InteractionEngine/CrmInteractionRecordActionRegistry.php`
- Create: `resources/interactions/crm/*.json` action wizards
- Test: `bin/verify-v130-alpha12-record-actions.php`

**Interfaces:**
- `CrmInteractionRecordActionRegistry::forRecord(string $type, array $context): array`
- `CrmInteractionRecordActionRegistry::resolve(string $message, array $context): ?array`

- [ ] Write failing test covering customer update, job reschedule/assign/status/time, quote acceptance, invoice issue/payment, PO lifecycle, stock transfer lifecycle, tool custody, fleet and maintenance actions.
- [ ] Run test and confirm RED.
- [ ] Add action journey definitions and resolver metadata with exact record ID prefill fields.
- [ ] Run test and confirm GREEN.

### Task 2: Governed update/action capability coverage

**Files:**
- Modify: `System/Capabilities/CrmCapabilityManifest.php`
- Modify: `System/Capabilities/CrmCapabilityExecutor.php`
- Modify provider bindings only where an existing domain service already exposes the operation.
- Test: `bin/verify-v130-alpha12-action-capabilities.php`

**Interfaces:**
- Adds stable capabilities for contact/lead/deal/task/project/calendar updates and sales document transitions where currently absent.
- Reuses existing Locker/Gear lifecycle capabilities without duplicate implementations.

- [ ] Write RED test requiring every alpha.12 action journey capability to be declared and executable through a CRM service/repository or existing provider binding.
- [ ] Implement minimal missing update/status/transition adapters.
- [ ] Run GREEN.

### Task 3: Contextual action buttons and page-aware AI

**Files:**
- Modify: `resources/views/components/interaction-page-shell.blade.php`
- Modify: `resources/views/components/interaction-ai-bar.blade.php`
- Modify relevant record detail views.
- Modify: `System/Http/Controllers/InteractionWorkspaceController.php`
- Test: `bin/verify-v130-alpha12-context-actions.php`

**Interfaces:**
- Detail pages can pass `recordType`, `recordContext`, and `recordActions` into the shared shell.
- AI chat receives trusted public record references and resolves “this job”, “this invoice”, etc. against current page context.

- [ ] Write RED test for contextual actions on Customer, Contact, Lead, Opportunity, Job, Quote/Estimate/Invoice, PO, Tool, Fleet and Maintenance surfaces.
- [ ] Implement action buttons and current-record intent resolution.
- [ ] Run GREEN.

### Task 4: Real autonomous execution through Interaction Engine

**Files:**
- Modify: `System/Integrations/InteractionEngine/CrmConversationalInteractionService.php`
- Modify: `System/Integrations/InteractionEngine/CrmInteractionAuthorityPolicy.php`
- Test: `bin/verify-v130-alpha12-autonomous-execution.php`

**Interfaces:**
- When a validated session completes and `mayAiComplete(capability)` is true, AI execution dispatches the mapped command through Interaction Engine `CommandBus`.
- Approval-gated actions still return `approval_required` and never receive AI-generated approval grants.

- [ ] Write RED test proving alpha.11 placeholder autonomous execution is insufficient and proving approval-gated capabilities cannot auto-dispatch.
- [ ] Implement validated CommandMapper/CommandBus dispatch for allowlisted autonomous actions only.
- [ ] Run GREEN.

### Task 5: Chained conversational workflows

**Files:**
- Create: `System/Integrations/InteractionEngine/CrmInteractionChainService.php`
- Modify: `System/Integrations/InteractionEngine/CrmConversationalInteractionService.php`
- Modify: `System/Integrations/TitanAI/CrmInteractionAIToolProvider.php`
- Test: `bin/verify-v130-alpha12-chains.php`

**Interfaces:**
- `CrmInteractionChainService::plan(string $message, array $context): array`
- `CrmInteractionChainService::continue(array $completedResult, array $plan): array`
- Supports explicit safe chains such as customer→job, job→quote, completed job→invoice, PO→goods receipt, maintenance→fleet status.

- [ ] Write RED tests for chain detection, result-to-next-step prefill, tenant/context preservation, and no silent execution of approval-gated second steps.
- [ ] Implement explicit chain templates; do not build an open-ended autonomous planner.
- [ ] Run GREEN.

### Task 6: Preview-first bulk conversational actions

**Files:**
- Create: `System/Integrations/InteractionEngine/CrmInteractionBulkPlanner.php`
- Modify: `System/Services/CrmBulkActionService.php`
- Modify: `System/Integrations/TitanAI/CrmInteractionAIToolProvider.php`
- Test: `bin/verify-v130-alpha12-bulk-actions.php`

**Interfaces:**
- `CrmInteractionBulkPlanner::preview(string $resource, string $action, array $ids, array $arguments): array`
- Bulk execution requires explicit approved selection and remains capped at 100 records.

- [ ] Write RED tests for preview counts, tenant isolation, max-100 limit, and no execution during planning.
- [ ] Add preview support and governed execution bridge using the existing `CrmBulkActionService`.
- [ ] Run GREEN.

### Task 7: Release hardening and packaging

**Files:**
- Add alpha.12 changelog/report.
- Modify: `extension.json`, `extension.manifest.json`, `README.md`, `bin/verify.php`, integrity inventories.

- [ ] Run inherited alpha.2-alpha.11 verification chain and all alpha.12 gates.
- [ ] Lint every PHP file and parse every JSON file.
- [ ] Verify all migrations retain reversible `down()` methods.
- [ ] Regenerate integrity manifests.
- [ ] Build a flat Titan installer ZIP.
- [ ] Fresh-extract the exact ZIP and rerun master verifier, lint, JSON, path-safety and case-collision checks.
