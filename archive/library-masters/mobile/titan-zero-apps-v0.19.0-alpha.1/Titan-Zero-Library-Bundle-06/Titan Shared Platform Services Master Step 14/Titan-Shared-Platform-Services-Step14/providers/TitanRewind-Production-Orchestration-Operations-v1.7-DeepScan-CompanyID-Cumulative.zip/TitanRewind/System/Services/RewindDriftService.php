<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Forensics\RewindDriftRules;
use App\Extensions\TitanRewind\System\Forensics\RewindTemporalDiagnostics;
use App\Extensions\TitanRewind\System\Models\RewindDriftFinding;
use App\Extensions\TitanRewind\System\Models\RewindTraceEvent;
use App\Extensions\TitanRewind\System\Models\RewindTraceIndex;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTimelineAssembler;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Observability\RewindTraceContext;
use App\Extensions\TitanRewind\System\Streaming\RewindStreamWindow;
use Illuminate\Support\Str;

final class RewindDriftService
{
    public function __construct(
        private RewindIntegrityService $integrity,
        private RewindTemporalDiagnostics $temporal,
        private RewindTimelineAssembler $assembler,
        private RewindDriftRules $rules,
        private RewindTelemetryService $telemetry,
        private RewindSignalOutboxService $signals,
    ) {}

    public function scanTrace(RewindTraceQuery $query, ?int $resolvedById = null): array
    {
        $cursor=RewindTraceEvent::query()->where('tenant_company_id',$query->tenantCompanyId())->where('trace_id',$query->traceId())->orderBy('sequence')->orderBy('occurred_at')->orderBy('event_id')->cursor();
        $window=(new RewindStreamWindow(5000))->consume((function()use($cursor){foreach($cursor as $event)yield $event->toArray();})());
        $events=$window['items'];$ordered=$this->assembler->order($events);$causation=$this->assembler->causation($ordered);
        $integrity=$this->integrity->inspectTrace($query);$temporal=$this->temporal->analyse($events);
        $desired=$this->rules->evaluate($integrity,$temporal,$causation,$ordered);$desiredTypes=array_column($desired,'finding_type');$now=now();$persisted=[];
        if($window['truncated'])$desired[]=['finding_type'=>'large_trace_window','severity'=>'medium','summary'=>'Drift analysis used a bounded 5,000-event window.','evidence'=>['event_count'=>$window['observed_count'],'window_size'=>5000],'remediation'=>'Use paginated/streamed forensic review for full-trace inspection.'];

        foreach($desired as $finding){
            $key=hash('sha256',implode('|',[$query->tenantCompanyId(),$query->traceId(),$finding['finding_type']]));$record=RewindDriftFinding::query()->firstOrNew(['finding_key'=>$key]);
            if(!$record->exists){$record->finding_uuid=(string)Str::uuid();$record->tenant_company_id=$query->tenantCompanyId();$record->trace_id=$query->traceId();$record->detected_at=$now;}
            $record->fill(['finding_type'=>$finding['finding_type'],'severity'=>$finding['severity'],'status'=>'open','summary'=>$finding['summary'],'evidence'=>$finding['evidence'],'remediation'=>$finding['remediation'],'last_seen_at'=>$now,'resolved_at'=>null,'resolved_by_id'=>null]);$record->save();$persisted[]=$record->refresh();
        }
        $desiredTypes=array_column($desired,'finding_type');
        $stale=RewindDriftFinding::query()->where('tenant_company_id',$query->tenantCompanyId())->where('trace_id',$query->traceId())->where('status','open');if($desiredTypes!==[])$stale->whereNotIn('finding_type',$desiredTypes);$stale->update(['status'=>'resolved','resolved_at'=>$now,'resolved_by_id'=>$resolvedById]);
        $openCount=RewindDriftFinding::query()->where('tenant_company_id',$query->tenantCompanyId())->where('trace_id',$query->traceId())->where('status','open')->count();
        $forensicState=($integrity['status']??null)==='failed'?'critical':($openCount>0?'review':'clear');RewindTraceIndex::query()->where('tenant_company_id',$query->tenantCompanyId())->where('trace_id',$query->traceId())->update(['open_drift_count'=>$openCount,'forensic_state'=>$forensicState]);
        $ctx=RewindTraceContext::fromArray(['tenant_company_id'=>$query->tenantCompanyId(),'trace_id'=>$query->traceId(),'correlation_id'=>$query->correlationId()?:$query->traceId(),'causation_id'=>null]);$this->telemetry->metric('rewind.drift.open_findings',$openCount,'count',$ctx,['forensic_state'=>$forensicState]);if($openCount>0)$this->signals->emit('rewind.drift.detected.v1',$ctx,['open_finding_count'=>$openCount,'forensic_state'=>$forensicState],'WARNING');
        return ['tenant_company_id'=>$query->tenantCompanyId(),'trace_id'=>$query->traceId(),'status'=>$forensicState,'open_finding_count'=>$openCount,'findings'=>array_map(static fn(RewindDriftFinding $finding):array=>$finding->toArray(),$persisted),'integrity'=>$integrity,'temporal'=>$temporal,'causation'=>$causation,'analysis_scope'=>$window['truncated']?'BOUNDED_WINDOW':'COMPLETE_TRACE','events_observed'=>$window['observed_count']];
    }

    public function openForTrace(RewindTraceQuery $query): array
    {
        return RewindDriftFinding::query()->where('tenant_company_id',$query->tenantCompanyId())->where('trace_id',$query->traceId())->where('status','open')
            ->orderByRaw("CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END")->orderBy('id')->lazy(250)
            ->map(static fn(RewindDriftFinding $finding):array=>$finding->toArray())->all();
    }
}
