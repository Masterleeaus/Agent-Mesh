# Titan Signal Engine v0.20.0-rc.8.1

Titan's governed, immutable event and telemetry nervous-system foundation.


## Release Candidate rc.8.1 — Blade shared error-bag hotfix

- Fixes the rc.8 Overview Blade assigning an integer to Laravel's shared `$errors` variable, which caused `panel.layout.app` to fail at `$errors->any()`.
- Renames the local counter to `$errorCount`; Laravel's `ViewErrorBag` remains untouched.
- Moves the eight Super Admin page templates to the fresh `admin-rc8-1` view namespace so a compiled rc.8 child view cannot survive the hotfix.
- Extends the information-architecture regression to reject `$errors` assignment in every Signal Super Admin page.
- No schema, migration, Signal event, delivery, anomaly, lifecycle, registry, or authorization contract changes.

## Release Candidate rc.8 — Super Admin console information architecture


- Replaces the single overloaded Super Admin console with one Signal Engine parent and eight child surfaces.
- Adds themed operational overview cards and a compact scope/window filter with conditional tenant selection.
- Keeps anomaly suppression, event redaction/correction, DLQ redrive and prune execution on their governed child pages.
- Extends host self-heal/certification to verify all eight child menu rows, routes and `parent_id` relationships.
- Keeps Signal Engine absent from the normal user sidebar.

- rc.4 removes a duplicate `tsd_subscriber_status_idx` declaration from migration 13; migration 6 already owns the covering `(subscriber_key, status, available_at)` index.
- Added whole-chain migration index-name collision regression coverage and rollback-ownership protection for the foundational delivery index.
- Root `extension.json` now follows Titan Installer 1.7.8 `titan-extension-v1`.
- Added `php artisan titan:signal:certify` for live Laravel/MySQL/schema/binding/route/schedule/queue/archive/health certification.
- Added machine-readable RC status and explicit production-host certification runbook.
- Local/Blueprint sidecar/package verification may pass while production-host certification remains pending until executed on the actual Titan host.
- The supplied Blueprint Step03 legacy root-manifest validator conflict is documented rather than hidden.

## Production Hardening Pass 11 — v0.19.0 runtime/console/config hardening

- Console failures are converted to safe reference codes while full exceptions remain server-side logs.
- Historical migrations no longer import evolving Signal runtime classes; v0.2 checksum/idempotency backfill logic is frozen inside the migration.
- User/admin Signal & Pulse navigation is self-healing: modern contribution registries are used when present, with an idempotent MagicAI `menus` fallback and `MenuService::regenerate()` cache refresh. Run `php artisan titan:signal:host-sync` for explicit repair.
- Decorative config keys were removed; queue, recovery limits, rollout stage, registry/history bounds and causation-repair chunk sizes now drive runtime behavior.
- Console and operational read paths use bounded cursors/chunks rather than broad collection loads.
- Blueprint architecture review warnings were reduced substantially without weakening transactional locking semantics.


## Production Hardening Pass 10 — v0.18.0 immutable anomaly decisions

- anomaly acknowledge, suppress, resolve, and reopen transitions now emit immutable Signal audit events
- every lifecycle transition carries trusted actor identity, governed reason, decision version, decision timestamp, evidence SHA-256 reference, and suppression expiry where applicable
- `titan_signal_anomalies` remains the mutable current-state projection; immutable Signal history is the audit authority
- transition versioning provides stable idempotency and links each projection to `last_decision_event_id`
- automatic trace-recovery resolutions and recurrence reopenings are audited, not silently projected
- anomaly state mutation and immutable audit emission share one database transaction and fail closed together

## Production Hardening Pass 9 — v0.17.0 Pulse/health correctness

- Pulse projection freshness is maintained per tenant/system scope and per source instead of borrowing the latest global projection.
- Command→receipt latency is projected per command event, supporting multiple command lifecycles inside one trace.
- Operational health is refreshed into a bounded snapshot every minute; live health reads no longer recalculate growing global counts.
- Current degradation is separated from bounded historical incident counters, so resolved historical DLQs do not keep the engine degraded.
- Backpressure surfaces current pressure and historical incident state separately while preserving scoped tenant/source protection.


## Production Hardening Pass 8 — v0.16.0 automatic trace evaluation

Signal now assigns active trace profiles automatically, reevaluates open/partial traces on schedule, evaluates terminal workflows without an operator opening the trace explorer, and resolves sequence/missing-required anomalies when late events repair the trace. See `docs/AUTOMATIC-TRACE-EVALUATION.md`.

## Production Hardening Pass 7 — v0.15.0 hot/cold correlation and Rewind continuity

- Correlation now reconstructs ancestors, descendants, traces and workflows across hot and verified cold history.
- `titan_signal_archive_catalog` acts as the durable cold causal tombstone and now has a causation index.
- mixed-tier edges report parent/child storage tiers and whether both endpoints were resolved in the returned window.
- Rewind receipts report hot/cold counts, `hot|cold|mixed` storage, and cold-history completeness.
- archive corruption/unavailability cannot produce a false complete trace; correlation returns `partial` with bounded failure codes.
- no-archive retention classes intentionally terminate recoverable history and therefore remain visible as missing-parent/incomplete traces when referenced by surviving events.


## Production Hardening Pass 6 — v0.14.0 transactional pruning and streaming archives

Pass 6 binds pruning to persisted preview manifests and one-time confirmation tokens, atomically claims the exact approved candidate set, adds execution leases for concurrent prune protection, supports verified-unpruned recovery, respects no-archive retention classes, and uses bounded-memory streaming archive reads/writes.

## Production Hardening Pass 5 — v0.13.0 cold-history retrieval

- verified archive files are now governed read sources instead of write-only retention artifacts
- `SignalArchiveCatalogContract` indexes event/trace/correlation/root-causation metadata without scanning cold objects
- `SignalHistoryQueryContract` merges hot and cold records while preserving tenant/system authorization
- cold reads verify the archive SHA-256 before returning data
- privacy-projected archives explicitly distinguish archive integrity from canonical event-checksum integrity
- lifecycle/event inspection falls back to cold history after hot pruning
- `titan:signal-archive:catalog` rebuilds catalog entries for verified pre-v0.13 archive batches
- archive driver identity is persisted and honored on read even if the current default storage disk changes



## Production Hardening Pass 4 — v0.12.0 delivery recovery

- governed DLQ redrive with immutable redrive audit records
- stable subscriber idempotency key across redrive generations
- shared subscription-registry revision with bounded worker cache TTL
- recent/current backpressure separated from historical DLQ retention
- tenant/source-specific source throttling pressure
- admin console and CLI redrive controls


## Production Hardening Pass 2 — v0.10.0 registry governance

- Event type definitions are append-only immutable versions.
- Subscription definitions are append-only immutable versions.
- Registry writes require a host-attested `SignalRegistryIdentity`.
- Event families and subscriber keys have explicit service ownership.
- Cross-extension registry takeover is rejected.
- Broken/missing subscriber handlers are quarantined in a separate runtime projection and skipped during matching, so they cannot block valid Signal ingestion.
- Legacy registry rows are preserved and can be claimed only through authenticated evolution.

## Blueprint v4 alignment overlay — v0.9.1

- production `extension.manifest.json` schema 2.0
- `runtime_profile: titan-governed-engine`
- versioned capability contracts and JSON schemas
- independent liveness/readiness health contract
- canonical observability `TraceContext`
- named `onOneServer()` + `withoutOverlapping()` schedules
- explicit SLO, resilience, rollout, DR, supply-chain and governance declarations
- Blueprint-required operational/security/data/governance documentation
- localization catalog and provider translation loading
- production signing is declared mandatory; this handoff ZIP is intentionally unsigned because no release private key was supplied

## Production Hardening Pass 1 — v0.9.0 trusted execution context

- mandatory `SignalContext` on all public emission and tenant-sensitive read contracts
- host-attested `SignalEmitterIdentity` separate from actor identity
- public `SignalEmitterAuthorityContract` for registered Titan components to obtain replaceable emitter grants
- allowlisted emitter service/source/component/event-family definitions
- source/source-component spoof rejection
- persisted checksum-covered `emitter_id` for all new events
- tenant-to-tenant and contextless query paths rejected
- global health permission-gated via `signal.health.read`
- additive nullable `emitter_id` migration preserving historical checksum compatibility
- Signal's anomaly and subscription-failure telemetry uses explicit internal emitter grants


## Pass 1 — canonical foundation (cumulative)

- canonical immutable `SignalEnvelope`
- event, trace, correlation and immediate causation identities
- explicit tenant vs system scope
- automatic causal child-event propagation
- actor/source/schema/severity/category/vertical metadata
- deterministic event checksum
- idempotent ingestion foundation
- immutable Eloquent event model
- tenant-scoped event store and query service
- public emitter/query/manager contracts
- additive forward-only migration for existing v0.1.0 installs
- composite tenant/time/type/trace/correlation indexes

## Pass 2 — v0.2.1 foundation hardening

- `envelope_version = 1.0` separate from event `schema_version`
- UUIDv7 generation for new event/trace/correlation identities while accepting historical UUIDs
- `root_causation_id` with automatic child propagation and indexed retrieval
- structured `SignalActor` representation plus identity provider and actor session ID
- trusted `SignalContext` boundary preventing actor/tenant spoofing
- system-query authorization (`signal.system.read`) and optional governed system-to-tenant read/emit permissions
- global severity enumeration with numeric aggregation weights
- explicit `checksum_alg = sha256` and `verifyChecksum()` tamper detection
- query-layer checksum integrity rejection via `SignalIntegrityException`
- `EventTypeRegistryContract`, persisted `titan_signal_types` registry, schema/scope/source/payload validation
- independent 64 KiB payload and 8 KiB metadata limits (configurable)
- recursive hidden-reasoning-key rejection while allowing structured summaries/evidence/reason codes
- 24-hour configurable idempotency TTL using `titan_signal_idempotency_keys`
- duplicate receipts return `original_event_id`
- persisted causation validates tenant/scope/trace/correlation/root boundaries, including late parent arrival
- blocked update/delete attempts are logged and throw `ImmutableSignalEventException`
- additive compatibility migration recalculates v0.2.0 checksum metadata without changing historical event content
- host-Laravel runtime tests for immutability, idempotency, tenant isolation, checksum tampering and actor spoofing
- standalone pure-PHP hardening behavior runner for framework-independent primitives


## Pass 3 — v0.3.0 Correlation Engine

- persisted causal-edge projection in `titan_signal_causal_edges`
- late/offline parent arrival repairs missing edge projections without mutating events
- causal-cycle rejection at ingestion and detection during analysis
- `SignalCorrelationContract` with ancestors, descendants, trace and workflow reconstruction
- versioned `TraceProfile` definitions in `titan_signal_trace_profiles`
- required-event, ordering and terminal-event completeness rules
- causation-first topological ordering so offline timestamps cannot override causal structure
- missing-parent and illegal-sequence diagnostics
- multi-trace workflow reconstruction by `correlation_id`
- Rewind-ready correlation receipts with trace/correlation/root-causation anchors
- separate bounded graph query ceiling (default 5,000 events)
- `returned_event_count`, `total_event_count`, `truncated` and `partial` projection semantics
- donor process/timeline concepts selectively rewritten without importing legacy `tz_*` runtime coupling

## Event type governance

Every emitted event type must be registered before ingestion. Definitions declare:

- current and supported event schema versions
- functional category
- allowed scope (`tenant` and/or `system`)
- required and optional top-level payload fields
- whether extra payload fields are allowed
- owner/source component
- allowed severities
- active/deprecated/disabled status and optional replacement type

Other Titan extensions register their own event types through `EventTypeRegistryContract`. Signal Engine ships only its own bootstrap definitions in configuration.

## Actor, tenant and emitter authenticity

Caller-supplied actor, tenant and source fields are not trusted. Every public Signal emission requires a `SignalContext`, and every emitting context must carry a host-attested `SignalEmitterIdentity`. Tenant identity must match the authenticated context; `source`, `source_component` and `emitter_id` are derived from the trusted emitter grant rather than accepted as authority from the payload.

Read-only tenant contexts do not need an emitter identity, but all tenant-sensitive query/correlation/Pulse/anomaly/lifecycle contracts require an authenticated `SignalContext`. System reads require `signal.system.read`; governed system-to-tenant reads/emits require the corresponding explicit permission. Global health requires `signal.health.read`.

Trusted emitter grants are allowlisted in host configuration and attested by `SignalEmitterAuthority` using a key derived from Laravel's configured `app.key`. New persisted events record the attested `emitter_id`; historical events remain readable with a null emitter ID.

## Immutability

Signal events remain append-only. Updating or deleting a `SignalEvent` through Eloquent is blocked, logged and throws `ImmutableSignalEventException`. Compliance correction/redaction will be implemented later as a governed projection/correction mechanism rather than rewriting historical facts.

## Idempotency

An active idempotency key is scoped by:

`scope + tenant/system + source + idempotency_key`

The active key expires after `idempotency_ttl_seconds` (default 86,400 seconds). The historical event remains immutable; only the active deduplication lease expires. Duplicate ingestion returns the original event ID.

## Verification

Blueprint alignment can be checked with `php tests/run-blueprint-alignment.php` and the supplied Blueprint v4 validator (`tools/validate_manifest.py <extension> --check-files --production`).

Standalone archive verification can execute `php tests/run-foundation-hardening.php`, `php tests/run-correlation-engine.php`, `php tests/run-subscriptions.php`, `php tests/run-pulse.php`, `php tests/run-anomaly-engine.php`, `php tests/run-lifecycle-hardening.php`, and `php tests/run-operational-console.php` without Laravel. Full persistence/runtime integration tests are packaged in `tests/Feature/FoundationRuntimeIntegrationTest.php` and require the host Laravel test environment.

## Pass 4 — v0.4.0 Subscriptions & Distribution

Signal now supports isolated, queue-backed event consumers without making Signal Core own downstream engine logic.

- code-registered `SignalSubscriberContract` consumer boundary
- persisted `titan_signal_subscriptions` definitions
- exact or bounded suffix-prefix event families such as `command.*`
- explicit accepted event schema versions per subscriber
- optional tenant/system scope, category and vertical filters
- unrestricted `*` subscriptions are rejected
- durable per-subscriber `titan_signal_deliveries` ledger
- one immutable event projects independently to each matching subscriber
- at-least-once delivery semantics using Laravel Queue
- stable `delivery_id` + immutable `event_id` for consumer idempotency
- per-subscriber retry policies and bounded backoff
- subscriber-specific dead-letter state
- queue/worker stale-delivery recovery command
- one-minute Laravel scheduler recovery hook
- paused/disabled subscription handling
- queue-level timeout/failure capture
- safe hashed error references instead of persisting arbitrary exception messages
- `signal.subscription.failed` immutable telemetry on terminal delivery failure
- failure-of-failure recursion protection
- duplicate event ingestion cannot duplicate `(event_id, subscriber_key)` delivery rows
- Signal health now reports active pending/queued/processing/retry/dead-letter counts

### Registering a subscriber

Another Titan extension implements `SignalSubscriberContract` and registers its definition through `SignalSubscriptionRegistryContract`:

```php
$registry->register(SignalSubscriptionDefinition::fromArray([
    'subscriber_key' => 'titan-risk.command-events',
    'handler_class' => RiskSignalSubscriber::class,
    'event_patterns' => ['command.*'],
    'accepted_schema_versions' => [1],
    'scopes' => ['tenant'],
    'categories' => ['risk', 'operations'],
    'queue' => 'titan-signal-engine',
    'max_attempts' => 5,
    'backoff_seconds' => [1, 5, 30, 120],
]));
```

The subscriber receives the immutable `SignalEvent` plus a `SignalDeliveryContext`. Delivery is intentionally at-least-once. Consequential consumers must deduplicate side effects with `SignalDeliveryContext::idempotencyKey` (`signal-delivery:<delivery_id>`); lease tokens identify attempts, not business idempotency.

### Recovery

The extension registers:

```text
titan:signal-deliveries:recover --limit=250
```

and schedules it every minute through Laravel's scheduler. Pending, due-retry and stale queued/processing rows can therefore be re-enqueued after transport or worker interruption without re-emitting the original event.


## Pass 5 — v0.5.0 Titan Pulse

Pulse is now an operational read-model layer over immutable Signal history. It intentionally avoids dashboard-time scans over the raw event store.

- minute/hour/day rollups for tenant and system scopes
- rollup dimensions for source, event type, category, severity and vertical
- idempotent `titan_signal_pulse_projected_events` projection ledger
- recoverable `titan:signal-pulse:project --limit=1000` catch-up command
- one-minute scheduled projection recovery
- trace-duration and command-to-receipt latency projections
- P50/P95/P99 nearest-rank latency summaries
- configurable missing-execution-receipt detection
- configurable stalled-trace candidate detection
- event/command throughput and error-rate metrics
- risk/governance/assurance/autonomy activity counts
- current subscription dead-letter/retry pressure
- source and event-type summaries
- deterministic attention score with reason codes
- compact `PulseSurfaceBuilder` read model for Titan Zero/Prime/generative UI surfaces

Pulse is eventually consistent by design: immutable event persistence remains authoritative, while projection failure is recoverable and does not fail signal ingestion. Exact forensic counts and causal reconstruction remain Query/Correlation responsibilities. See `docs/PULSE-METRICS.md` for metric semantics and thresholds.


## Pass 6 — v0.6.0 Rule-Based Anomaly Engine

Anomaly detection is a deterministic operational projection over Pulse/Correlation evidence. It does not scan the immutable raw event table and it does not use machine-learning models.

- `signal.anomaly.detect` and `signal.anomaly.manage` capabilities through `SignalAnomalyContract`
- repeated-failure detection per source over five-minute Pulse rollups
- execution-loop detection using per-trace event-type counts
- retry/dead-letter spike detection from subscriber delivery state
- stalled-workflow and missing-execution-receipt detection from Pulse trace metrics
- configurable governance/autonomy/command override spike detection
- event-volume-collapse detection with a default 24-hour cold-start requirement
- sequence-violation detection from complete, versioned Correlation trace evaluations
- unresolved-causation integrity detection with an offline-arrival grace period
- explicit anomaly severity, score, confidence, subject and evidence
- stable deduplication keys so recurring scans update one anomaly instead of creating alert floods
- lifecycle states: open, acknowledged, suppressed, resolved, and reopen-on-recurrence
- bounded suppression duration and explicit `signal.anomaly.manage` authorization
- prioritized anomaly feed ordered by score and recency
- `signal.anomaly.detected` detection telemetry plus immutable `signal.anomaly.acknowledged|suppressed|resolved|reopened` lifecycle audit events
- `titan:signal-anomalies:scan --limit=100` one-minute detection schedule with persisted round-robin tenant cursor
- anomaly health surfaced through `SignalManager::health()`

Rule thresholds are configuration-driven. The initial engine deliberately uses transparent rules rather than ML so operators can tune signal-to-noise from production evidence before introducing statistical or learned detectors. See `docs/ANOMALY-ENGINE.md`.


## Pass 7 — v0.7.0 Lifecycle, Archive, Redaction & Operational Hardening

The immutable event row remains authoritative while lifecycle governance is stored in sidecar projections.

- retention classes: `critical_audit`, `audit`, `operational`, `telemetry`, `debug`
- defaults: critical audit never auto-prunes; audit 7 years; operational 2 years; telemetry 90 days; debug 30 days
- per-event retention sidecar with `retain_until`, legal holds, archive and prune timestamps
- dry-run pruning preview with bounded batches
- explicit confirmed pruning only after archive write + SHA-256 archive verification
- portable Laravel Storage archive driver using gzip JSONL; no S3/PostgreSQL lock-in
- privacy-safe archive projection when redaction/correction overlays exist
- immutable redaction/correction overlays instead of rewriting event history
- immutable lifecycle audit records for holds, overlays and pruning
- per-source/component rate limiting with automatic tightening during delivery backpressure
- backpressure state surfaced through `SignalManager::health()`
- daily housekeeping for expired idempotency leases and old operational delivery/anomaly rows
- physical deletion of `titan_signal_events` exists only inside the governed lifecycle service

### Privacy-safe reads

`SignalLifecycleContract::view()` verifies the original event checksum first, then applies immutable redaction/correction overlays to the returned projection. The stored event and its checksum remain unchanged. Low-level raw `SignalQueryContract` access should be treated as forensic/internal access rather than exposed directly to ordinary UI surfaces.

### Pruning safety

Pruning follows: preview → explicit confirmation → archive → archive checksum verification → lifecycle/audit transaction → removal of hot event and per-event operational projections. Legal holds and `critical_audit` retention prevent automatic pruning.

### Multi-node rate limiting

For horizontally scaled Titan deployments, configure Laravel with a shared cache/rate-limiter backend so source limits are enforced across all application nodes.


## Pass 8 — v0.8.0 Signal/Pulse Operational Console

The final planned pass exposes the hardened read models and governed lifecycle operations through a tenant-safe operational console.

- `signal.console` capability and `SignalConsoleContract`
- admin operational console with explicit system/tenant scope switching
- tenant-facing read-only Signal/Pulse console derived only from the authenticated user's tenant identity
- Pulse attention, throughput, failure, stall, missing-receipt and latency surfaces
- prioritized anomaly feed with admin acknowledge/resolve/suppress lifecycle controls
- trace explorer with profile-aware completeness analysis and causal edge projection
- workflow explorer by `correlation_id`
- privacy-projected event inspector
- admin legal-hold controls
- governed redaction/correction overlay endpoints
- prune preview followed by explicit archive/verify/prune confirmation
- subscriber delivery-health surface
- top source/event-type summaries
- recent archive-batch and lifecycle-audit surfaces
- compact `SignalConsoleContract::surface()` read model for Titan Zero/Prime/generative UI
- no console controller writes Signal-owned tables directly; mutations go through Anomaly/Lifecycle contracts
- tenant console never receives global subscriber, lifecycle, archive or cross-tenant engine counts

### Console routes

- `/dashboard/admin/titan-signal-engine` — administrative operational console
- `/dashboard/user/titan-signal-engine` — tenant read-only console

The admin console remains protected by the host `auth` + `admin` middleware group. Tenant identity is derived from the authenticated user (`tenant_company_id`, with `company_id` compatibility fallback); query-string tenant IDs are never trusted on the user route.

See `docs/OPERATIONAL-CONSOLE.md` for the security and interaction contract.


## Release Candidate Certification

Version `0.20.0-rc.8.1` includes `php artisan titan:signal:certify`. Production promotion requires `--strict --probe-writes` to return `overall: PASS` on the real Titan Laravel/MySQL host. See `docs/PRODUCTION-HOST-CERTIFICATION.md`.
