# Governance

Titan Model Council is a governance engine and the canonical owner of `model-deliberation`, but it is **not** an authority-granting engine.

Risk may raise required Council depth and reduce or block downstream authority. Shield may reject validation. Assurance, Rewind, Wisdom and Command Bus remain external owners. Council cannot convert an advisory output into permission to mutate business state. Offline execution is denied.

Governed role order: Proposer → Critic → Verifier → pre-validation → Arbiter → final validation. Roles are logically distinct from providers; at least the configured number of distinct models is required.
