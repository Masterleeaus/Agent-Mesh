# CRM 1.3.0-alpha.17 — Context-Aware Global New Report

## Goal

Use MagicAI's permanent top-right green `+ New` control as the primary CRM creation surface while preserving Titan's Interaction Engine governance.

## Architecture

CRM does not patch MagicAI core. `CrmGlobalNewMenuRegistry` resolves a permission-filtered list of Interaction Engine journeys from the current CRM surface, title, record type, declared page journey and safe record context.

The shared CRM page shell renders hidden CSRF-protected journey forms. `global-new-adapter.blade.php` then finds the visible host `New`/`+ New` control that sits outside `[data-crm-interaction-page]`, changes its label to the page's primary action, and adds a dropdown for secondary actions.

The adapter contains no `fetch`, `CommandBus`, `CrmCapabilityExecutor` or direct database path.

## Fallback

Alpha.17 deliberately keeps the existing in-page Interaction action block as a compatibility fallback. It is marked `data-crm-local-new-fallback` so a later runtime-hardening release can hide/de-emphasise it only after the host button is confirmed across installed themes.

## Security

The registry maps each journey to its capability in `CrmCapabilityManifest`, obtains the corresponding CRM permission, and calls `CrmPermissionService::allows()` before exposing the action. Interaction Engine remains the execution boundary and continues to apply validation, tenant context, approvals and autonomy policy.
