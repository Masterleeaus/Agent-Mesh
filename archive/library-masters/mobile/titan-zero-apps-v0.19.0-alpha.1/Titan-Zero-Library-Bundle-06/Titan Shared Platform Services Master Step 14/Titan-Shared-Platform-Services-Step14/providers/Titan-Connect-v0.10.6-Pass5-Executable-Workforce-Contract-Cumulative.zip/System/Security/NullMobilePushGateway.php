<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use App\Extensions\TitanConnect\System\Contracts\MobilePushGateway;

final class NullMobilePushGateway implements MobilePushGateway
{
    public function send(int $companyId, array $recipientUserIds, array $notification): array
    {
        return ['status' => 'not-configured', 'company_id' => $companyId, 'recipients' => count($recipientUserIds)];
    }
}
