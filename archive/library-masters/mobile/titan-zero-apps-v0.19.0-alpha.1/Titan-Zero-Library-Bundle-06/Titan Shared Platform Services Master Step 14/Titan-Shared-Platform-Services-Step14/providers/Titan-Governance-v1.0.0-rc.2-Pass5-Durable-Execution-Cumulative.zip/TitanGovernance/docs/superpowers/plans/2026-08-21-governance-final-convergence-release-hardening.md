# Titan Governance Final Convergence & Release Hardening Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Produce a dual-compatible Installer 1.7.6 / Titan v2.2 Governance `v1.0.0-rc.1` release candidate with final forensic, lifecycle, inventory and packaging proof.

**Architecture:** Preserve Pass 1-7 runtime behavior. Add pure host-preflight/release tooling and machine-readable inventories around the existing extension, plus permanent installer and causal-chain regressions. No new migration or cross-domain write path is introduced.

**Tech Stack:** PHP 8.3, Laravel 10.50.x extension source, MySQL, JSON Manifest 2.2, Titan/MagicAI Installer manifests.

**Spec:** `docs/superpowers/specs/2026-08-21-governance-final-convergence-release-hardening-design.md`

## Global Constraints
- Root `extension.json` must retain `name`, `type`, `description`, `support_telegram` for live Installer 1.7.6.
- Sidecar stays Manifest schema 2.2 / `governance-engine`.
- Exactly four historical migrations remain; Pass 8 creates none.
- No Governance code may mint or raise Titan Autonomy authority.
- No cross-domain mutation may bypass Titan Command Bus.
- Exact-host stages stay `NOT_RUN` without live evidence.

### Task 1: Installer 1.7.6 compatibility regression
- [x] Write missing-name regression and verify RED.
- [x] Restore legacy host fields without deleting Titan metadata.
- [x] Verify the regression GREEN.

### Task 2: Final host preflight contracts
- [x] Write RED tests for manifest, fresh-install, upgrade, provider boot, and host certification.
- [ ] Implement pure host-preflight contracts.
- [ ] Verify exact live host facts `1.7.6 / PHP 8.3.33 / Laravel 10.50.2 / MySQL` pass static compatibility.

### Task 3: Causal execution/reconstruction audit
- [x] Write/repair the decision→Command Bus→authoritative receipt→Decision Intelligence/Rewind regression.
- [x] Verify all four causal IDs and applied receipt proof remain present.

### Task 4: Release inventories and operator evidence
- [ ] Generate route, menu, capability, dependency and migration inventories from current source/sidecar.
- [ ] Add host-certification checklist and operator runbook.
- [ ] Add final Pass 8 convergence report.

### Task 5: RC metadata and cumulative compatibility
- [ ] Set root/sidecar/self-verifier to `1.0.0-rc.1`.
- [ ] Convert Pass 7 version assertions to minimum-version inherited checks.
- [ ] Regenerate SBOM, provenance, package inventory and Installer integrity.

### Task 6: Exact final package certification
- [ ] Run every cumulative standalone contract.
- [ ] Run PHP lint and JSON parse.
- [ ] Run Blueprint v4.2.2 sidecar/architecture/MySQL/frozen-migration/package scans.
- [ ] Run dual Installer 1.7.6/1.7.8 manifest/integrity preflight.
- [ ] Build flat-root ZIP, fresh extract it, and rerun all applicable gates.
- [ ] Produce SHA-256 and machine-readable Pass 8 certification with live host stages truthful.
