<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Integration;

use Illuminate\Contracts\Container\Container;
use LogicException;

final class ConfiguredIntegrationBinder
{
    public function bind(Container $app, string $contract, string $configKey, string $defaultClass): void
    {
        if ($app->bound($contract)) {
            return;
        }

        $class = $this->configuredClass($configKey, $defaultClass);
        if (! class_exists($class)) {
            throw new LogicException("Configured Titan Connect integration class [{$class}] does not exist for [{$configKey}].");
        }
        if (! is_a($class, $contract, true)) {
            throw new LogicException("Configured Titan Connect integration class [{$class}] must implement [{$contract}].");
        }

        $app->bind($contract, $class);
    }

    public function configuredClass(string $configKey, string $defaultClass): string
    {
        $configured = trim((string) config($configKey, $defaultClass));
        return $configured !== '' ? $configured : $defaultClass;
    }
}
