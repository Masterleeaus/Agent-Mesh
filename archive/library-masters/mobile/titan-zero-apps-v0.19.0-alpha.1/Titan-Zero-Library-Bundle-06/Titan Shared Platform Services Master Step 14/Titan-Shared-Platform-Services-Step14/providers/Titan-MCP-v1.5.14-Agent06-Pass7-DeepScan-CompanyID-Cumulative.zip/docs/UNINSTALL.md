# Uninstall

Uninstall is idempotent. It removes Titan MCP menu rows and extension-owned permission rows/role links, then allows the host to delete `app/Extensions/TitanMcp`. Recovery backups, audit evidence and settings are retained by default for forensic/reinstall purposes. Purge those only through an explicit operator retention decision.
