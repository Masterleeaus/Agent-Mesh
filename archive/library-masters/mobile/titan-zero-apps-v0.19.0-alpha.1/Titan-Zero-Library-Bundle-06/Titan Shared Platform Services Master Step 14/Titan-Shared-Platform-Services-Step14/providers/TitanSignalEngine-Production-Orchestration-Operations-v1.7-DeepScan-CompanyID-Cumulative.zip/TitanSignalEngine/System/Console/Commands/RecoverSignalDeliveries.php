<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Console\Commands;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliverySchedulerContract;
use Illuminate\Console\Command;

final class RecoverSignalDeliveries extends Command
{
    protected $signature = 'titan:signal-deliveries:recover {--limit=250 : Maximum deliveries to recover}';
    protected $description = 'Re-enqueue due or stale Titan Signal subscriber deliveries.';

    public function handle(SignalDeliverySchedulerContract $scheduler): int
    {
        $count = $scheduler->recoverDue((int) $this->option('limit'));
        $this->info("Recovered {$count} Signal deliveries.");
        return self::SUCCESS;
    }
}
