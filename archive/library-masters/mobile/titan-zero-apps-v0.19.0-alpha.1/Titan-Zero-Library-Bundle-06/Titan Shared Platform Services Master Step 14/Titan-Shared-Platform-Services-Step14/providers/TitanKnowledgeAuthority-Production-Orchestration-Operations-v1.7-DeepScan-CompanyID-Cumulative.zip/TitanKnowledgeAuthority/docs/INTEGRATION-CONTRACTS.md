# Integration Contracts

## Trusted access-context seam
Hosts consuming internal scoped catalog reads or source-version appends must bind `KnowledgeAccessContextResolverContract` from trusted authenticated/system context. Tenant or jurisdiction authority must not come from request body, query string, AI prompt or other caller-controlled fields. Without a host resolver, reads and appends fail closed.

## Internal catalog read seam
`KnowledgeCatalogReadContract` exposes source/version metadata reads without tenant parameters. Repository-level scope filters protect platform, tenant and jurisdiction visibility.

## Internal immutable-version append seam
`KnowledgeSourceVersionWriteContract::append()` accepts `KnowledgeSourceVersionAppendRequest`: hashes, provenance, retrieval/effective timestamps, optional storage metadata and optional `expectedSupersedesVersionId`. Tenant ownership, version sequence, canonical version key and actual supersession are always derived by Knowledge Authority.

A duplicate `(source_id, content_hash)` returns the existing version with status `unchanged` after tenant-lineage validation. New content returns `created`. A supplied predecessor precondition that does not match the current latest version raises `SourceVersionConflictException`.

These contracts remain internal host integration seams, not public capability-bus surfaces.
