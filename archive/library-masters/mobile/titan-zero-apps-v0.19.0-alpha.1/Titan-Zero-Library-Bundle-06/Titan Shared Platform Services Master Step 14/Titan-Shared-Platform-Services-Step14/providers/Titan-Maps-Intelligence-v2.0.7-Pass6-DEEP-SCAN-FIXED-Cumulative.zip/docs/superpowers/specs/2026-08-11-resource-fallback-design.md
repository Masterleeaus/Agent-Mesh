# Titan Maps Intelligence Pass 16 — Governed Resource Fallback Design

## Goal
When Titan cannot satisfy a contractor/supplier need from an internal or already-approved resource, create an auditable fallback workflow that searches approved external resources first and Maps Discovery only when necessary, enriches every candidate with fit/travel evidence, and requires explicit human review before promotion into CRM.

## Authority boundaries
- CRM/operations remains authoritative for jobs, workers, suppliers, contractors and final operational assignment/use.
- Maps owns geographic sourcing evidence, discovery candidates, travel evidence and the fallback workflow audit trail.
- No discovery result becomes a CRM supplier/contractor without candidate approval and explicit promotion.
- No fallback workflow auto-assigns a contractor or supplier to a job.

## Search order
1. **Internal suitability check** — for contractor needs tied to a job, reuse Dispatch Intelligence to determine whether a suitable internal worker exists. If one exists, stop external escalation.
2. **Approved network** — inspect company-scoped canonical contractor/supplier locations already known to Titan and rank them by travel evidence. These are proposed for review; they are not newly created entities.
3. **Maps Discovery** — only if the approved network has no usable candidates. Launch a company-scoped discovery search centred on the need location and link the search to the fallback request.
4. **Discovery refresh** — once provider search results exist, attach the resulting discovery candidates to the fallback request and compute travel/fit evidence.

## Lifecycle
Fallback request statuses:
`new -> internal_available | approved_network_review | discovery_searching -> discovery_review -> approved -> promoted -> closed`
with `failed` and `cancelled` terminal states.

Fallback candidate statuses:
`proposed -> reviewed -> approved | rejected -> promoted`.

The existing Discovery Candidate lifecycle remains authoritative for discovery candidate classification/approval/promotion. Fallback candidate records link that lifecycle to a sourcing request and preserve ranking/evidence.

## Evidence and ranking
Every fallback candidate stores:
- source: `internal`, `approved_network`, or `discovery`
- source reference/public ID
- resource type (`contractor` or `supplier`)
- service/category fit basis and score
- road distance / ETA when provider-derived or retained
- straight-line distance separately
- route/ETA provenance and freshness
- data completeness signal
- overall deterministic score and explanation

Unknown skill/category/certification evidence stays `unknown`; it cannot be converted into a verified positive signal.

## Persistence
New tenant-scoped tables:
- `maps_resource_fallback_requests`
- `maps_resource_fallback_candidates`
- `maps_resource_fallback_decisions`

## User experience
New **Field Operations → Resource Fallback** page:
- start contractor/supplier fallback
- enter job public ID or target coordinates
- view current sourcing stage
- see approved-network/discovery candidates on the graphical map
- see travel/fit evidence and source badges
- Review / Approve / Reject
- Promote an approved discovery candidate into CRM contractor/supplier
- close/cancel request

## API / AI
Governed capabilities:
- `titan-maps-intelligence.resource-fallback.start`
- `titan-maps-intelligence.resource-fallback.read`
- `titan-maps-intelligence.resource-fallback.decide`
- `titan-maps-intelligence.resource-fallback.promote`

Promotion requires `confirmed=true` at the AI/tool boundary and an already-approved discovery candidate. Approved-network records are existing operational resources and are never re-promoted.

## Safety
- company-scoped model binding on requests
- client `company_id` prohibited
- discovery can only begin after earlier sourcing stages are exhausted
- no candidate promotion without explicit approval
- no promotion if the discovery candidate has an unresolved match
- no auto assignment/use of the selected external resource
- stale route/ETA evidence is visibly stale
- straight-line fallback never becomes road ETA
