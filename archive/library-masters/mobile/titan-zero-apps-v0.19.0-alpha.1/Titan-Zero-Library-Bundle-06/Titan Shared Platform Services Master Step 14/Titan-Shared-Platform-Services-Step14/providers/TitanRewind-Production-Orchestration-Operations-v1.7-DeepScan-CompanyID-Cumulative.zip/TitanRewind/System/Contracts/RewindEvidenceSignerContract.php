<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Contracts;

interface RewindEvidenceSignerContract
{
    /** @return array{algorithm:string,key_id:string,signature:string} */
    public function sign(string $contentHash): array;
    public function verify(string $contentHash, string $signature, string $keyId): bool;
    public function available(): bool;
}
