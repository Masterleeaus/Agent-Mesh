# Titan Interaction Engine v10.3.0 Phase 6 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Cut Titan Interaction Engine from active WorkCore runtime dependency to a company-scoped, governed multi-extension capability router serving CRM, Titan Builder, Chatbot, Titan Connect, Titan Mobile and TitanAI across Hub, Go, Command and Onboarding surfaces.

**Architecture:** Preserve the mature wizard, authority, LocalBrain, cognition, memory, offline and onboarding systems. Replace the single `DomainAdapterInterface`/WorkCore dispatcher execution path with a provider registry/router whose providers bind only to published external extension contracts; missing providers fail closed. Evolve onboarding plans into dependency-aware multi-provider actions and expose generic journey/surface presentation/readiness APIs while keeping compatibility aliases for existing field-services routes and capability names.

**Tech Stack:** PHP 8+/Laravel extension conventions, JSON wizard/template data, TypeScript offline companion, MagicAI Extension Blueprint manifests, standalone PHP regression harnesses.

## Global Constraints

- `company_id` is the canonical Titan business tenant; `user_id`, `tenant_id` and `team_id` never establish tenancy.
- CRM owns authoritative operational business state; Interaction Engine does not import CRM Eloquent models.
- Optional providers must not be hard boot dependencies.
- Unknown/unavailable capability fails closed; no reflection/model mutation fallback.
- Authority and approval checks occur before provider execution.
- Secure connection credentials never enter wizard answers/plans/logs.
- Preserve LocalBrain v2 and Titan Go offline behavior.
- Preserve 30 wizard JSON definitions, 38 templates, 121 source onboarding entries, 116 runtime questions and 16 sections unless an explicit compatibility migration documents the change.
- Field/Home Services active profile uses exactly ten canonical slugs: `cleaning`, `plumbing`, `electrical`, `hvac`, `handyman-property-maintenance`, `landscaping-gardening`, `pest-control`, `locksmith-security`, `roofing-guttering`, `appliance-equipment-repair`.
- Do not claim host certification without an actual Laravel/MagicAI host boot.

---

### Task 1: Baseline and WorkCore reference ledger
**Files:** create `docs/WORKCORE-REMOVAL.md`; create `reports/phase6-baseline.json`; test `tests/phase6_workcore_removal.php`.
**Interfaces:** Produces a classified reference ledger and regression gate that forbids WorkCore in `System/`, `routes/`, `config/`, active manifest metadata and active JSON wizard/template capability mappings.
- [ ] Write failing test scanning active runtime paths for `WorkCore|workcore` and allowing only explicitly marked historical docs/tests.
- [ ] Run the test and confirm current WorkCore runtime references fail.
- [ ] Record exact wizard/template/engine/onboarding counts and WorkCore reference classifications.
- [ ] Remove active runtime/config WorkCore bindings while retaining historical migration notes only.
- [ ] Re-run test to green.

### Task 2: Capability routing core
**Files:** create `System/Capabilities/{CapabilityRouter.php,CapabilityProviderRegistry.php,CapabilityProviderInterface.php,CapabilityDescriptor.php,CapabilityExecutionContext.php,CapabilityResult.php,CapabilityAliasRegistry.php}`; modify `System/Registry/CapabilityRegistry.php`; test `tests/phase6_capability_router.php`.
**Interfaces:** `CapabilityProviderInterface::providerKey(): string`, `descriptors(): array`, `supports(string): bool`, `available(string, CapabilityExecutionContext): bool`, `execute(string,array,CapabilityExecutionContext): CapabilityResult`; `CapabilityRouter::execute(string,array,CapabilityExecutionContext): CapabilityResult`.
- [ ] Write failing tests for provider routing, missing provider, unknown capability, wrong company and standardized outcomes.
- [ ] Implement immutable descriptor/context/result types and provider registry.
- [ ] Implement alias resolution before descriptor lookup and authority dispatch.
- [ ] Evolve `CapabilityRegistry` to expose declared/supported/available descriptor state without a domain adapter constructor.
- [ ] Re-run focused tests.

### Task 3: CommandBus router integration and authority ordering
**Files:** modify `System/Command/CommandBus.php`, `System/Contracts/CommandBusInterface.php`, authority policy wiring; test `tests/phase6_authority_router.php`.
**Interfaces:** CommandBus calls authority/approval first, then `CapabilityRouter`; returns/records structured `CapabilityResult` without provider exceptions corrupting wizard state.
- [ ] Write failing tests covering all six authority levels and proving provider execution does not occur before authorization.
- [ ] Wire CommandBus to CapabilityRouter rather than registered domain callables for external capabilities.
- [ ] Preserve local handlers for Interaction-owned actions through a local provider.
- [ ] Verify approval evidence binds company/capability/correlation/action context.
- [ ] Re-run authority tests.

### Task 4: CRM provider from published CRM contracts
**Files:** create `System/Capabilities/Providers/CrmCapabilityProvider.php`; create `System/Capabilities/Contracts/CrmCapabilityGateway.php`; docs `docs/CRM-INTEGRATION.md`; test `tests/phase6_crm_provider.php`.
**Interfaces:** Adapter resolves only published CRM field-service services/registries present in CRM 1.1; translates Interaction `company_id` to CRM's company argument and never imports CRM models/tables.
- [ ] Inventory CRM 1.1 public services and method signatures from supplied archive.
- [ ] Write failing provider tests using contract doubles matching verified signatures.
- [ ] Register only verified capabilities; unsupported examples remain unavailable.
- [ ] Implement structured reads/writes for verified profile/services/requests/work-orders/appointments/support/customer operations where public contracts exist.
- [ ] Add cross-company and idempotency tests.

### Task 5: Builder provider
**Files:** create `System/Capabilities/Providers/BuilderCapabilityProvider.php`; contract `System/Capabilities/Contracts/BuilderProvisioningGateway.php`; docs `docs/TITAN-BUILDER-INTEGRATION.md`; test `tests/phase6_builder_provider.php`.
**Interfaces:** Wrap verified Titan Builder registry/application definition services; no Builder model/table imports.
- [ ] Inventory Builder 1.0.0 application/brand/navigation/features/theme/preview/validate/publish entry points.
- [ ] Write failing availability/execution tests.
- [ ] Register only verified capabilities; keep unsupported publish/rollback unavailable if no stable gateway exists.
- [ ] Verify company propagation and presentation-only ownership.

### Task 6: Chatbot provider
**Files:** create `System/Capabilities/Providers/ChatbotCapabilityProvider.php`; contract `System/Capabilities/Contracts/ChatbotProvisioningGateway.php`; docs `docs/CHATBOT-INTEGRATION.md`; test `tests/phase6_chatbot_provider.php`.
**Interfaces:** Use Chatbot 6.9 company-scoped provisioning/training service boundaries; no Chatbot model direct access.
- [ ] Inventory `ChatbotProvisioningService` and public configuration/training surfaces.
- [ ] Write failing identity/persona/knowledge/readiness tests for only proven operations.
- [ ] Implement fail-closed provider and explicit unavailable descriptors for unproven operations.
- [ ] Verify `company_id` remains sole tenant boundary.

### Task 7: Titan Connect provider
**Files:** create `System/Capabilities/Providers/ConnectCapabilityProvider.php`; contract `System/Capabilities/Contracts/ConnectCapabilityGateway.php`; docs `docs/TITAN-CONNECT-INTEGRATION.md`; test `tests/phase6_connect_provider.php`.
**Interfaces:** Interaction passes opaque connection references/status and message intent only; Connect owns OAuth, credentials, provider APIs, retry/webhooks.
- [ ] Inventory TitanConnect 0.7 public messaging/readiness gateways.
- [ ] Write failing tests for connection status/message send and secret exclusion.
- [ ] Implement only verified capabilities and online-required metadata.
- [ ] Verify no credentials enter Interaction payload persistence.

### Task 8: Mobile and TitanAI providers
**Files:** create `System/Capabilities/Providers/{MobileCapabilityProvider.php,TitanAIConfigurationProvider.php}`; contracts under `System/Capabilities/Contracts/`; docs `docs/TITAN-MOBILE-INTEGRATION.md`, `docs/TITANAI-INTEGRATION.md`; tests `tests/phase6_mobile_ai_providers.php`.
**Interfaces:** Mobile provider uses published Mobile capability registry/gateways; TitanAI provider uses shared capability/runtime contracts only for configuration/readiness, not unrestricted business mutation.
- [ ] Inventory Mobile 0.14 and TitanAI 1.4 public contracts.
- [ ] Write failing availability/context tests.
- [ ] Implement verified capability descriptors and fail-closed execution.
- [ ] Verify no WorkCore bridge is required by Interaction Engine provider code.

### Task 9: Capability namespace migration
**Files:** create `config/capability-aliases.php`; modify wizard/template JSON capability fields and registry declaration; docs `docs/UPGRADE-10.2-TO-10.3.md`; test `tests/phase6_capability_aliases.php`.
**Interfaces:** aliases resolve `jobs.create -> crm.work_order.create`, `jobs.complete -> crm.work_order.complete`, `quotes.create -> crm.quote.create`, `finance.invoice.create -> crm.invoice.create`, `finance.payment.record -> crm.payment.record` without duplicate handlers.
- [ ] Write failing alias/deprecation tests.
- [ ] Normalize active wizard/template capabilities to canonical ownership names.
- [ ] Keep controlled legacy aliases for compatibility and expose deprecation metadata.
- [ ] Scan active resources for stale ambiguous names.

### Task 10: Multi-provider onboarding plan
**Files:** modify `System/Onboarding/{OnboardingAction.php,OnboardingPlanCompiler.php,OnboardingActionExecutor.php}`; create `System/Onboarding/OnboardingReadinessService.php`; update onboarding question metadata JSON; tests `tests/phase6_onboarding_multi_provider.php`.
**Interfaces:** `OnboardingAction` carries provider/capability/group/risk/approval/payload/dependencies/order/readiness/idempotency metadata; compiler maps answer keys to owning subsystem based on data metadata.
- [ ] Write Apex Plumbing failing plan test routing CRM/Builder/Chatbot/Connect/TitanAI actions.
- [ ] Add destination-provider/capability/risk/ui/offline metadata to data-driven onboarding fields without secrets.
- [ ] Compile group answers into multiple provider actions and explicit dependencies.
- [ ] Execute only dependency-ready actions; return `blocked_dependency` otherwise.
- [ ] Aggregate provider readiness and block activation until required providers are ready.
- [ ] Keep activation explicit, approval-required and final.

### Task 11: Journey and four-surface platform
**Files:** create `System/Journey/{JourneyDefinition.php,JourneyRegistry.php,JourneyService.php}`; create `System/Surfaces/{InteractionSurface.php,SurfaceWizardPolicy.php}`; generic controller/routes; docs `docs/FOUR-PWA-WIZARD-SURFACES.md`, `docs/TITAN-ONBOARDING.md`; test `tests/phase6_four_surfaces.php`.
**Interfaces:** surfaces `hub|go|command|onboarding|chatbot|api|system`; journey discovery/start/resume/readiness APIs reuse WizardSession.
- [ ] Write failing visibility/security tests for Hub, Go, Command and Onboarding.
- [ ] Map existing wizards to allowed surfaces/roles without duplicating wizard engines.
- [ ] Add generic journey discovery/start/session answer/next/preview/approve/execute/readiness endpoints.
- [ ] Preserve old field-services onboarding routes as compatibility aliases.
- [ ] Add initial journeys: business onboarding, customer onboarding, staff onboarding, new service, new location, channel connection, AI configuration.

### Task 12: Generated UI/presentation contract
**Files:** create `System/Presentation/InteractionPresentation.php`; modify conversational/hybrid/array renderers and API responses; docs `docs/GENERATED-UI-CONTRACT.md`; test `tests/phase6_generated_ui.php`.
**Interfaces:** response fields include interaction_id, wizard_id, session_id, step_id, title, prompt, description, input_type, options, validation, ui_hint, help_text, progress, actions, requires_online, authority_state.
- [ ] Write failing renderer contract tests.
- [ ] Normalize all renderer output into one presentation envelope.
- [ ] Verify same WizardSession accepts normalized voice/text/form answers.

### Task 13: Offline classification and Titan Go safety
**Files:** extend capability descriptors/offline queue logic; docs `docs/OFFLINE-WIZARDS.md`, `docs/LOCALBRAIN-V2.md`; test `tests/phase6_offline_go.php`.
**Interfaces:** `offline_local|offline_queueable|online_required` is descriptor-owned; clients cannot override it.
- [ ] Write failing queueability/online-required tests.
- [ ] Enforce descriptor classification at queue/dispatch boundaries.
- [ ] Propagate conflicts/rejections to wizard session state without authority elevation.
- [ ] Re-run LocalBrain/offline suites.

### Task 14: Ten vertical packs and profile audit
**Files:** modify `System/Product/FieldHomeServicesProfile.php`, wizard metadata and template profile metadata; docs `docs/FIELD-HOME-SERVICES.md`; test `tests/phase6_verticals.php`.
**Interfaces:** exactly ten canonical slugs; verticals modify terminology/questions/evidence/checklists, not UniversalWizardEngine logic.
- [ ] Write failing exact-slug/profile tests.
- [ ] Normalize existing cleaning/gardening/handyman/etc. aliases to canonical slugs.
- [ ] Audit all 30 wizards and 38 templates for surface, vertical, capability, authority and offline metadata.
- [ ] Archive non-target resources from active profile rather than deleting reusable definitions.

### Task 15: Provider registration/service-provider cleanup
**Files:** split focused provider registration classes if needed; modify `System/InteractionEngineServiceProvider.php`, config and manifest; test `tests/phase6_provider_boot.php`.
**Interfaces:** core boots with zero optional provider extensions installed; missing provider yields unavailable capability.
- [ ] Write failing no-provider boot/static wiring test.
- [ ] Remove `WorkCoreAdapter`, `GovernedWorkCoreDispatcher`, WorkCore config and bindings.
- [ ] Register router/provider discovery without resolving optional external classes during provider `register()`.
- [ ] Update manifest capabilities/dependencies/table ownership/version to 10.3.0.

### Task 16: Documentation, static gates and release packaging
**Files:** update/create all docs named in Phase 6 spec, `README.md`, `extension.json`, `extension.manifest.json`, `files.sha256.json`; tests/verifier.
**Interfaces:** final report labels every integration IMPLEMENTED/PARTIAL/SCAFFOLDED/NOT IMPLEMENTED/UNVERIFIED.
- [ ] Run PHP lint across all PHP.
- [ ] Parse all JSON and JS/TS tests/build.
- [ ] Run every standalone Interaction test including Phase 6 suites.
- [ ] Search/classify WorkCore, stale capability aliases, tenant/team/user tenancy assumptions, TODO/fake handlers and merge markers.
- [ ] Validate MagicAI manifests against Blueprint schemas.
- [ ] Rebuild integrity inventory, stage a clean package, rerun all verification inside staged bytes, ZIP and hash.
- [ ] Document host verification as UNVERIFIED unless a full Laravel/MagicAI host is actually available and executed.
