# Titan CRM Outbound Effect Safety & Titan Connect Boundary — Design

## Goal

Upgrade Titan CRM alpha.19 in place so externally visible CRM side effects are never executed inside the authoritative database transaction, are idempotent across retries/crashes, expose provider/delivery receipts, and can be delegated to Titan Connect without moving CRM business truth out of CRM.

## Existing system preserved

The existing CRM notification outbox, sales-document PDF/email templates, invoice lifecycle rules, capability executor, command receipts, Signal outbox, tenancy model and human UI remain. The pass strengthens the execution boundary around them rather than replacing the underlying sales or notification implementations.

## Selected approach

Use an **outbox-first, port-based delivery boundary**:

1. `crm.invoice.send` and `crm.invoice.reminder.send` validate authoritative invoice state and recipient inside the CRM command transaction.
2. They enqueue one deterministic communication intent in `crm_notification_outbox`; no provider/network call occurs in the transaction.
3. The command receipt records the effect/outbox reference with delivery state `queued`.
4. Delivery workers claim pending effects atomically after commit.
5. A `CrmCommunicationExecutionPort` performs the actual provider execution. Titan Connect may bind this port. The legacy CRM mail adapter remains as an explicit compatibility adapter, not the architectural owner.
6. Provider outcomes update the outbox with `provider`, `provider_message_id`, `provider_status`, attempts and timestamps.
7. Duplicate commands reuse the same outbox record through a tenant-scoped idempotency key and never create a second send intent.

## Capability contract

Externally visible capabilities declare:

- `side_effect_class`: `none`, `internal`, or `external`
- `side_effect_execution`: `in_transaction`, `after_commit_outbox`, or `not_applicable`
- `delivery_receipt_required`
- `external_owner` where applicable (`titan_connect` for communications)

`crm.invoice.send` and `crm.invoice.reminder.send` remain stable names for compatibility, but their authoritative CRM result means **delivery accepted/queued**, not provider-confirmed delivery. Provider delivery state is explicit in the result/outbox record.

## Outbox v2

The existing `crm_notification_outbox` receives additive fields:

- `idempotency_key`
- `trace_id`
- `correlation_id`
- `causation_id`
- `command_id`
- `receipt_id`
- `provider`
- `provider_message_id`
- `provider_status`
- `claimed_at`
- `last_attempt_at`

A bounded unique index on `(tenant_company_id, idempotency_key)` prevents duplicate communication intents.

## Delivery safety

A worker claims a row by transitioning `pending|failed -> processing` with a bounded attempt policy. Already `sent|delivered` rows are terminal and are never re-sent. Failed rows retain the same idempotency key and may retry without creating a new intent.

Legacy mail delivery is moved behind `CrmCommunicationExecutionPort`. It renders the existing sales-document/reminder views and PDFs only after the CRM transaction commits.

## Titan Connect boundary

CRM defines only the port/intent contract. Titan Connect owns canonical channel/provider execution in the integrated platform. When Titan Connect is installed it can bind `CrmCommunicationExecutionPort`; CRM does not duplicate channel orchestration.

Standalone compatibility is available through a legacy adapter selected by configuration. This preserves installer behavior while making the intended engine ownership explicit.

## Signals and Rewind

The original CRM command receipt retains the authoritative business decision and outbox reference. Delivery transitions emit structured CRM Signal outbox events referencing the original trace/correlation/causation and command/receipt IDs. No hidden reasoning is stored.

## Failure behavior

- CRM transaction fails before commit: the communication intent rolls back and nothing is sent.
- CRM transaction commits but provider fails: CRM truth remains committed, outbox becomes `failed`, provider error is recorded, and retry remains idempotent.
- Worker crashes after claim: stale `processing` rows may be safely released/retried according to timeout policy.
- Duplicate capability command: returns the original authoritative command receipt and references the same communication intent.
- Titan Connect unavailable: intent remains queued/deferred; CRM does not report it as delivered.

## Testing

Alpha.20 verification must prove:

- no `Mail::send` remains in `SalesDocumentDeliveryService`;
- invoice send/reminder paths enqueue instead of sending in the transaction;
- outbox has deterministic idempotency and trace/provider receipt fields;
- a communication execution port exists and Titan Connect can rebind it;
- the legacy compatibility adapter is explicit;
- delivery worker is terminal-state safe and bounded;
- capability metadata declares external effect ownership;
- alpha.19 and all prior verifier gates remain green.
