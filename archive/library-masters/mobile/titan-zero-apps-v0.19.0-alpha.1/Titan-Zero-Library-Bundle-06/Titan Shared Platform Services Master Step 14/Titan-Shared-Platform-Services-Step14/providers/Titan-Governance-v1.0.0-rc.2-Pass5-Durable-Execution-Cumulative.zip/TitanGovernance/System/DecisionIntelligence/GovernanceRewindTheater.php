<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\DecisionIntelligence;

final class GovernanceRewindTheater
{
    /** @return array<string,mixed> */
    public function project(array $inspection):array
    {
        $decisionId=(string)($inspection['decision_id']??'');
        if(($inspection['status']??null)==='NOT_FOUND') return ['schema_version'=>'1.0','status'=>'NOT_FOUND','decision_id'=>$decisionId,'trace_id'=>null,'correlation_id'=>null,'reconstruction'=>null];
        $decision=is_array($inspection['decision']??null)?$inspection['decision']:[];
        $source=is_array($inspection['sources']['titan-rewind']??null)?$inspection['sources']['titan-rewind']:null;
        if($source===null) return ['schema_version'=>'1.0','status'=>'UNAVAILABLE','reason'=>'REWIND_SOURCE_NOT_CONFIGURED','decision_id'=>$decisionId,'trace_id'=>$decision['trace_id']??null,'correlation_id'=>$decision['correlation_id']??null,'reconstruction'=>null];
        $sourceStatus=strtoupper(trim((string)($source['status']??'UNAVAILABLE')));
        if($sourceStatus==='INVALID') return ['schema_version'=>'1.0','status'=>'INVALID','reason'=>$source['reason']??'REWIND_SOURCE_INVALID','decision_id'=>$decisionId,'trace_id'=>$decision['trace_id']??null,'correlation_id'=>$decision['correlation_id']??null,'reconstruction'=>null];
        $rewind=is_array($source['rewind']??null)?$source['rewind']:null;
        if(!in_array($sourceStatus,['HEALTHY','DEGRADED','STALE'],true)||$rewind===null) return ['schema_version'=>'1.0','status'=>'UNAVAILABLE','reason'=>$source['reason']??'REWIND_UNAVAILABLE','decision_id'=>$decisionId,'trace_id'=>$decision['trace_id']??null,'correlation_id'=>$decision['correlation_id']??null,'reconstruction'=>null];
        return [
            'schema_version'=>'1.0','status'=>strtoupper(trim((string)($rewind['status']??'READY')))?:'READY','decision_id'=>$decisionId,
            'trace_id'=>$rewind['trace_id']??$decision['trace_id']??null,'correlation_id'=>$rewind['correlation_id']??$decision['correlation_id']??null,
            'source_status'=>$sourceStatus,'reconstruction'=>$rewind,
        ];
    }
}
