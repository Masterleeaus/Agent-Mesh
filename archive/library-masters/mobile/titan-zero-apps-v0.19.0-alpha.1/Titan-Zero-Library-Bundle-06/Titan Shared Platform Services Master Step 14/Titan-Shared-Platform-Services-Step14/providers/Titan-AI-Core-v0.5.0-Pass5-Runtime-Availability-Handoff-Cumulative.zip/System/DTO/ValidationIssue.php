<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class ValidationIssue { public function __construct(public string $severity, public string $code, public string $message, public ?string $stepId = null) {} public function toArray(): array { return ['severity'=>$this->severity,'code'=>$this->code,'message'=>$this->message,'step_id'=>$this->stepId]; } }
