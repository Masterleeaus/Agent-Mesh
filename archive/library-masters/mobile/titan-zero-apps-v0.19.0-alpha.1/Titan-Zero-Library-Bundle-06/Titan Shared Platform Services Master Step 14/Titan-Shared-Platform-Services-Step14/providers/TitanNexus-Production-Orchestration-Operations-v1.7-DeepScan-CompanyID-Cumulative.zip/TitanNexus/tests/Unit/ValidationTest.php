<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanNexus\Unit;

use App\Extensions\TitanNexus\System\Adapters\Platform\PlatformReadinessAdapter;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\ValidationFinding;
use App\Extensions\TitanNexus\System\Domain\ValidationResult;
use App\Extensions\TitanNexus\System\Domain\ValidationSeverity;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Services\SemanticNexusValidator;
use PHPUnit\Framework\TestCase;

final class ValidationTest extends TestCase
{
    public function test_validation_result_is_deterministic(): void
    {
        $error = new ValidationFinding('profile.required', ValidationSeverity::Error, 'sections.billing.currency', 'Missing.', 'nexus.semantic');
        $warning = new ValidationFinding('profile.recommended', ValidationSeverity::Warning, 'sections.operations.area', 'Recommended.', 'nexus.semantic');

        self::assertSame(
            ValidationResult::fromFindings([$error, $warning])->fingerprint(),
            ValidationResult::fromFindings([$warning, $error])->fingerprint(),
        );
    }

    public function test_validator_blocks_missing_requirements_and_secrets(): void
    {
        $profile = BusinessProfile::fromArray([
            'tenant_company_id' => 42,
            'profile_version' => '3.0.0',
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'jurisdiction' => ['country_code' => 'AU'],
            'timezone' => 'Australia/Melbourne',
            'sections' => ['integrations' => ['token' => 'bad']],
        ]);
        $definition = VerticalDefinition::fromArray([
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'knowledge_snapshot_version' => null,
            'sections' => [],
            'validation' => [
                'required_profile_paths' => ['sections.billing.currency'],
                'required_platform_capabilities' => ['crm.customer.read'],
                'require_knowledge_snapshot' => true,
            ],
        ]);

        $result = (new SemanticNexusValidator(new PlatformReadinessAdapter(null, [])))->validate($profile, $definition);
        $codes = array_column($result->toArray()['findings'], 'code');

        self::assertTrue($result->hasErrors());
        self::assertContains('profile.required', $codes);
        self::assertContains('platform.capability.missing', $codes);
        self::assertContains('knowledge.snapshot.required', $codes);
        self::assertContains('secret.material.forbidden', $codes);
    }
}
