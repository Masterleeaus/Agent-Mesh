# Uninstall

Owned data is retained by default unless an explicitly governed uninstall policy says otherwise.
