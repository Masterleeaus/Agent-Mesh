<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

final class PulsePercentiles
{
    /** @param list<int|float> $samples @return array{count:int,min:float|null,max:float|null,avg:float|null,p50:float|null,p95:float|null,p99:float|null} */
    public static function summarize(array $samples): array
    {
        $normalized = array_values(array_map(static fn (int|float $value): float => (float) $value, $samples));
        sort($normalized, SORT_NUMERIC);
        $count = count($normalized);
        if ($count === 0) {
            return ['count' => 0, 'min' => null, 'max' => null, 'avg' => null, 'p50' => null, 'p95' => null, 'p99' => null];
        }

        return [
            'count' => $count,
            'min' => $normalized[0],
            'max' => $normalized[$count - 1],
            'avg' => round(array_sum($normalized) / $count, 3),
            'p50' => self::nearestRank($normalized, 0.50),
            'p95' => self::nearestRank($normalized, 0.95),
            'p99' => self::nearestRank($normalized, 0.99),
        ];
    }

    /** @param list<float> $sorted */
    private static function nearestRank(array $sorted, float $percentile): float
    {
        $rank = max(1, (int) ceil($percentile * count($sorted)));
        return $sorted[$rank - 1];
    }
}
