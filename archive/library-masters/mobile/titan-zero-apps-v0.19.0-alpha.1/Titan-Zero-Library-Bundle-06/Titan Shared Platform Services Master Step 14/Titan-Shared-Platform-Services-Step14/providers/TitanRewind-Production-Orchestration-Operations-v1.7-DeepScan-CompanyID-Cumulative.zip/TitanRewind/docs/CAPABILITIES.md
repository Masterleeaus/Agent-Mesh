# Titan Rewind Capabilities

Implemented capabilities include health/foundation discovery, timeline and reconstruction, cases, snapshots and dependency graphs, historical dry-run replay, integrity/drift/root-cause diagnostics, snapshot comparison, signed evidence/compliance export, recovery planning/Governance handoff, counterfactual/current-state/model/policy/knowledge structural comparisons, guided assistant/analytics, custody and legal holds.

All replay/comparison capabilities are mutation-free. Structural comparison does not claim historical model re-execution.
