<?php

declare(strict_types=1);

namespace Tests\Feature;

use PHPUnit\Framework\TestCase;

final class ExtensionBootTest extends TestCase
{
    public function test_provider_registers_canonical_certifier_and_scoped_publish_tag(): void
    {
        $root = dirname(__DIR__, 2);
        $provider = (string) file_get_contents($root . '/System/TitanCommandBusServiceProvider.php');

        self::assertStringContainsString('CertifyExtensionCommand::class', $provider);
        self::assertStringContainsString("'titan-command-bus-config'", $provider);
        self::assertStringNotContainsString("], 'extension');", $provider);
        self::assertFileExists($root . '/routes/admin.php');
    }
}
