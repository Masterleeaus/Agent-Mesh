<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Persistence\Repositories;

use App\Extensions\TitanPrime\System\Domain\Entities\PrimeMission;
use App\Extensions\TitanPrime\System\Domain\Entities\PrimeObjective;
use App\Extensions\TitanPrime\System\Domain\Enums\PrimeMissionStatus;
use App\Extensions\TitanPrime\System\Domain\Exceptions\InvalidMissionTransition;
use App\Extensions\TitanPrime\System\Domain\State\PrimeMissionStateMachine;
use App\Extensions\TitanPrime\System\Domain\ValueObjects\PrimeBudget;
use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Persistence\Contracts\PrimeMissionRepositoryContract;
use App\Extensions\TitanPrime\System\Persistence\Data\PrimeMissionSnapshot;
use App\Extensions\TitanPrime\System\Persistence\Data\PrimeMissionWriteReceipt;
use App\Extensions\TitanPrime\System\Persistence\Exceptions\DuplicateMission;
use App\Extensions\TitanPrime\System\Persistence\Exceptions\MissionConcurrencyConflict;
use App\Extensions\TitanPrime\System\Persistence\Exceptions\MissionIdempotencyConflict;
use App\Extensions\TitanPrime\System\Persistence\Exceptions\MissionNotFound;
use App\Extensions\TitanPrime\System\Persistence\Models\PrimeMissionOperationRecord;
use App\Extensions\TitanPrime\System\Persistence\Models\PrimeMissionRecord;
use App\Extensions\TitanPrime\System\Persistence\Support\MissionOperationFingerprint;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

final class DatabasePrimeMissionRepository implements PrimeMissionRepositoryContract
{
    public function __construct(private readonly PrimeMissionStateMachine $stateMachine = new PrimeMissionStateMachine()) {}

    public function create(PrimeMission $mission, string $operationId): PrimeMissionWriteReceipt
    {
        $this->assertOperationId($operationId);
        $trace = $mission->trace();
        $payloadHash = MissionOperationFingerprint::create($mission);

        return DB::transaction(function () use ($mission, $operationId, $trace, $payloadHash): PrimeMissionWriteReceipt {
            $this->releaseExpiredOperation($trace->tenantCompanyId, $operationId);
            if (($existing = $this->existingOperation($trace->tenantCompanyId, $operationId)) !== null) {
                return $this->replayOrReject($existing, $payloadHash);
            }

            $receipt = new PrimeMissionWriteReceipt(
                tenantCompanyId: $trace->tenantCompanyId,
                operationId: $operationId,
                missionId: $mission->missionId(),
                operationType: 'create',
                version: 1,
                status: $mission->status()->value,
                payloadHash: $payloadHash,
            );

            try {
                PrimeMissionRecord::query()->create($this->missionRow($mission, 1));
            } catch (QueryException $exception) {
                if (($existing = $this->existingOperation($trace->tenantCompanyId, $operationId)) !== null) {
                    return $this->replayOrReject($existing, $payloadHash);
                }
                if ($this->missionRowExists($trace->tenantCompanyId, $mission->missionId())) {
                    throw DuplicateMission::forTenant($trace->tenantCompanyId, $mission->missionId());
                }
                throw $exception;
            }

            $this->recordOperation($receipt);

            return $receipt;
        }, 3);
    }

    public function find(int $tenantCompanyId, string $missionId): ?PrimeMissionSnapshot
    {
        $this->assertTenantAndMission($tenantCompanyId, $missionId);

        $row = PrimeMissionRecord::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->where('mission_id', $missionId)
            ->where('record_format', 'mission-v2')
            ->first();

        return $row === null ? null : $this->hydrate($row);
    }

    public function transition(
        int $tenantCompanyId,
        string $missionId,
        PrimeMissionStatus $expectedStatus,
        PrimeMissionStatus $nextStatus,
        int $expectedVersion,
        string $operationId,
    ): PrimeMissionWriteReceipt {
        $this->assertTenantAndMission($tenantCompanyId, $missionId);
        $this->assertOperationId($operationId);
        if ($expectedVersion < 1) {
            throw new InvalidArgumentException('expectedVersion must be at least 1.');
        }
        if (!$this->stateMachine->canTransition($expectedStatus, $nextStatus)) {
            throw InvalidMissionTransition::between($expectedStatus->value, $nextStatus->value);
        }

        $payloadHash = MissionOperationFingerprint::transition($missionId, $expectedStatus, $nextStatus, $expectedVersion);

        return DB::transaction(function () use (
            $tenantCompanyId,
            $missionId,
            $expectedStatus,
            $nextStatus,
            $expectedVersion,
            $operationId,
            $payloadHash,
        ): PrimeMissionWriteReceipt {
            $this->releaseExpiredOperation($tenantCompanyId, $operationId);
            if (($existing = $this->existingOperation($tenantCompanyId, $operationId)) !== null) {
                return $this->replayOrReject($existing, $payloadHash);
            }

            $affected = PrimeMissionRecord::query()
                ->where('tenant_company_id', $tenantCompanyId)
                ->where('mission_id', $missionId)
                ->where('record_format', 'mission-v2')
                ->where('status', $expectedStatus->value)
                ->where('lock_version', $expectedVersion)
                ->update([
                    'status' => $nextStatus->value,
                    'lock_version' => $expectedVersion + 1,
                    'updated_at' => now(),
                ]);

            if ($affected !== 1) {
                if (($existing = $this->existingOperation($tenantCompanyId, $operationId)) !== null) {
                    return $this->replayOrReject($existing, $payloadHash);
                }

                $current = PrimeMissionRecord::query()
                    ->where('tenant_company_id', $tenantCompanyId)
                    ->where('mission_id', $missionId)
                    ->where('record_format', 'mission-v2')
                    ->first(['status', 'lock_version']);

                if ($current === null) {
                    throw MissionNotFound::forTenant($tenantCompanyId, $missionId);
                }

                throw MissionConcurrencyConflict::stale(
                    missionId: $missionId,
                    expectedVersion: $expectedVersion,
                    expectedStatus: $expectedStatus->value,
                    actualVersion: (int) $current->lock_version,
                    actualStatus: (string) $current->status,
                );
            }

            $receipt = new PrimeMissionWriteReceipt(
                tenantCompanyId: $tenantCompanyId,
                operationId: $operationId,
                missionId: $missionId,
                operationType: 'transition',
                version: $expectedVersion + 1,
                status: $nextStatus->value,
                payloadHash: $payloadHash,
            );
            $this->recordOperation($receipt);

            return $receipt;
        }, 3);
    }

    /** @return array<string,mixed> */
    private function missionRow(PrimeMission $mission, int $version): array
    {
        $trace = $mission->trace()->toArray();

        return [
            'tenant_company_id' => $trace['tenant_company_id'],
            'mission_id' => $mission->missionId(),
            'trace_id' => $trace['trace_id'],
            'correlation_id' => $trace['correlation_id'],
            'causation_id' => $trace['causation_id'],
            'root_causation_id' => $trace['root_causation_id'],
            'type' => $mission->objective()->type,
            'objective_type' => $mission->objective()->type,
            'status' => $mission->status()->value,
            'objective_json' => $mission->objective()->toArray(),
            'budget_json' => $mission->budget()->toArray(),
            'payload' => $mission->toArray(),
            'initiated_by_type' => $mission->initiatedByType(),
            'initiated_by_id' => $mission->initiatedById(),
            'lock_version' => $version,
            'record_format' => 'mission-v2',
        ];
    }

    private function hydrate(PrimeMissionRecord $row): PrimeMissionSnapshot
    {
        $objective = $this->requireArray($row->objective_json, 'objective_json');
        $budget = $this->requireArray($row->budget_json, 'budget_json');

        $mission = PrimeMission::reconstitute(
            missionId: (string) $row->mission_id,
            trace: new TraceContext(
                tenantCompanyId: (int) $row->tenant_company_id,
                traceId: (string) $row->trace_id,
                correlationId: (string) $row->correlation_id,
                causationId: $row->causation_id !== null ? (string) $row->causation_id : null,
                rootCausationId: (string) $row->root_causation_id,
            ),
            objective: new PrimeObjective(
                type: (string) $objective['type'],
                statement: (string) $objective['statement'],
                desiredOutcome: (string) $objective['desired_outcome'],
                successCriteria: array_values(array_map('strval', $objective['success_criteria'] ?? [])),
            ),
            budget: new PrimeBudget(
                maxCostMinor: (int) ($budget['max_cost_minor'] ?? 0),
                maxTokens: (int) ($budget['max_tokens'] ?? 0),
                maxRuntimeSeconds: (int) ($budget['max_runtime_seconds'] ?? 0),
                maxDelegations: (int) ($budget['max_delegations'] ?? 0),
                maxParallelDelegations: (int) ($budget['max_parallel_delegations'] ?? 0),
                maxRiskScore: (float) ($budget['max_risk_score'] ?? 0.0),
                maxExternalActions: (int) ($budget['max_external_actions'] ?? 0),
            ),
            initiatedByType: (string) $row->initiated_by_type,
            initiatedById: $row->initiated_by_id !== null ? (string) $row->initiated_by_id : null,
            status: PrimeMissionStatus::from((string) $row->status),
        );

        return new PrimeMissionSnapshot($mission, (int) $row->lock_version);
    }

    /** @return array<string,mixed> */
    private function requireArray(mixed $value, string $field): array
    {
        if (!is_array($value)) {
            throw new InvalidArgumentException(sprintf('Persisted %s must be an object.', $field));
        }

        return $value;
    }

    private function recordOperation(PrimeMissionWriteReceipt $receipt): void
    {
        try {
            PrimeMissionOperationRecord::query()->create([
                'tenant_company_id' => $receipt->tenantCompanyId,
                'operation_id' => $receipt->operationId,
                'mission_id' => $receipt->missionId,
                'operation_type' => $receipt->operationType,
                'payload_hash' => $receipt->payloadHash,
                'receipt_json' => $receipt->toArray(),
                'expires_at' => now()->addSeconds((int) config('titan-prime.idempotency_ttl_seconds', 86400)),
            ]);
        } catch (QueryException $exception) {
            $existing = $this->existingOperation($receipt->tenantCompanyId, $receipt->operationId);
            if ($existing !== null) {
                $this->replayOrReject($existing, $receipt->payloadHash);
                return;
            }
            throw $exception;
        }
    }

    private function existingOperation(int $tenantCompanyId, string $operationId): ?PrimeMissionOperationRecord
    {
        return PrimeMissionOperationRecord::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->where('operation_id', $operationId)
            ->where('expires_at', '>', now())
            ->first();
    }

    private function replayOrReject(PrimeMissionOperationRecord $operation, string $payloadHash): PrimeMissionWriteReceipt
    {
        if (!hash_equals((string) $operation->payload_hash, $payloadHash)) {
            throw MissionIdempotencyConflict::forOperation((string) $operation->operation_id);
        }

        return PrimeMissionWriteReceipt::fromArray($this->requireArray($operation->receipt_json, 'receipt_json'))->asReplay();
    }

    private function releaseExpiredOperation(int $tenantCompanyId, string $operationId): void
    {
        PrimeMissionOperationRecord::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->where('operation_id', $operationId)
            ->where('expires_at', '<=', now())
            ->delete();
    }

    private function missionRowExists(int $tenantCompanyId, string $missionId): bool
    {
        return PrimeMissionRecord::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->where('mission_id', $missionId)
            ->where('record_format', 'mission-v2')
            ->exists();
    }

    private function assertTenantAndMission(int $tenantCompanyId, string $missionId): void
    {
        if ($tenantCompanyId < 1) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }
        if (trim($missionId) === '') {
            throw new InvalidArgumentException('mission_id must not be empty.');
        }
    }

    private function assertOperationId(string $operationId): void
    {
        if (trim($operationId) === '') {
            throw new InvalidArgumentException('operation_id must not be empty.');
        }
    }
}
