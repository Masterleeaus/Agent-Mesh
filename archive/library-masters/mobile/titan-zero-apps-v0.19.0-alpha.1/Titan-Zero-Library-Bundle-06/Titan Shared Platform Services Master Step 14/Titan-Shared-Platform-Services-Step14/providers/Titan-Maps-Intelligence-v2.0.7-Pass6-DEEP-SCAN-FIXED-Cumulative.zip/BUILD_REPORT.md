# Joint Pass 15 update — 2.0.0

Added the explainable Titan Field route-optimisation proposal peer, immutable proposal evidence, 39th owned table / 53rd migration, and explicit no-Field-write authority boundary. Full source and archive certification is recorded externally after final packaging.

# Joint Pass 13 update — 2.0.0-beta.1.11

Added bounded, read-only Titan Field capacity-pressure peer evidence using existing nearest-resource/travel-matrix and territory evidence. Full archive certification is recorded externally after final packaging.

# Titan Maps Intelligence 2.0.0-beta.1.9 Build Report

## Beta 1 — Safety, Cost, Privacy and Scalability Hardening

This release hardens the existing alpha.17 geospatial domain without replacing its working discovery, graphical maps, GPS, geofencing, routing, planning, dispatch, territories, analytics, fallback or governed-engine integrations.

### Implemented

- Per-tenant/provider quota circuit breaker with soft-limit downgrade, hard-limit denial and governed emergency override.
- Provider health tracking and primary/secondary Vault-reference failover.
- Server-side geofence reconciliation every minute, per-fence hysteresis/transition samples and GPS-accuracy-derived event confidence.
- Worker privacy/stale-location controls, historical-trail sharing windows, device throttling, impossible-jump anomaly Signals and 7/90/2555-day retention profiles.
- Tenant/vertical dispatch scoring policies, temporal/fatigue/familiarity evidence and mandatory-certification unknown blocker.
- Deterministic territory resolution and conflict evidence/rule chains.
- ETA `valid_until`, stale recommendation suppression, route history filters and time-bounded exact/heuristic route planning.
- Queued territory analytics with 24-hour persisted snapshot reuse.
- Geocode retry/backoff state, normalized fingerprints, confidence and provider-contract version metadata.
- Resource-fallback review deadlines/escalation and explicit promotion approval lineage.
- Redis-preferred short idempotency cache for territory validation/service-area checks with cache-fallback Signal.
- Closed-resource/stale-worker filtering in nearest-resource intelligence.
- Five new governed beta capabilities, bringing the total capability surface to 44.

### Package shape

- Version: 2.0.0-beta.1.9
- Owned tables: 38
- Total migrations: 51
- Capabilities: 44
- Company navigation: 5 parents / 36 children
- Root installer schema: `titan-extension-v1`

### Important non-claims

DB-native partitioning/Parquet archive, tile-proxy caching, turn-by-turn navigation, weather routing, predictive ML, floorplans, dynamic territory rebalancing and CRM pricing-rule validation are documented as post-beta work and are not represented as implemented in this release.

Full Laravel/MySQL execution against installed Titan Risk/Command Bus/Signal/etc. implementations remains a host integration test and is not claimed by archive-level verification.

### Exact installer-stage certification

The exact physical `TitanMapsIntelligence/` release candidate passed:

- 73/73 package verification/runtime scripts.
- 532/532 PHP syntax checks.
- 2/2 JavaScript syntax checks.
- 4/4 JSON parse checks.
- 38 owned tables / 51 total migrations.
- 44 governed capabilities and matching sidecar declarations.
- 5 company menu parents / 36 child links.
- 579/579 candidate integrity hashes.
- Hardened sidecar JSON Schema validation.
- Blueprint secret/filesystem scan.

The final ZIP is re-extracted and re-certified after this report is included; those final artifact results are reported in the release handoff.

## beta.1.1 live-host hotfix

Live host exception reproduced from the installed route stack: Laravel attempted to resolve middleware alias `titan.company`, but that alias is not registered by the target Titan host. Root cause was a hard-coded route-group dependency in `TitanMapsIntelligenceServiceProvider`.

Fix:
- replace `titan.company` with extension-owned `titan.maps.company`;
- resolve trusted `tenant_company_id`/`active_company_id` and optional CRM company context through `AuthorisedCompanyContext`;
- stamp company context into request attributes before company-scoped model binding;
- reject client-provided `tenant_company_id`;
- keep the existing permission and tenant-scoped binding layers intact.

No schema or menu migration is introduced by this hotfix.

## beta.1.2 stale route-cache compatibility hotfix

A second live-host failure showed that upgrading the source alone is insufficient when Laravel still has a route definition cached from beta.1. That cached route can retain the literal `titan.company` middleware name even though beta.1.1 source now uses `titan.maps.company`.

Fix:
- keep all newly registered Maps routes on `titan.maps.company`;
- inspect the router's existing middleware aliases during Maps route registration;
- if the host already owns `titan.company`, preserve it unchanged;
- otherwise register `titan.company` as a compatibility alias to the same trusted `ResolveMapsCompanyContext` middleware so stale beta.1 cached Maps routes can resolve;
- add regression verification proving the compatibility alias is guarded and that new route groups do not regress to the legacy dependency.

No schema or menu migration is introduced by this hotfix.

## beta.1.3 MySQL required-timestamp compatibility hotfix

Live installer build 1.7.8 reached scoped migrations and failed before recording any migration with MySQL error 1067 on `maps_location_pings.received_at`. The package used two consecutive required bare Laravel `timestamp()` columns (`captured_at`, `received_at`). On MySQL configurations retaining legacy implicit TIMESTAMP defaults, the first required TIMESTAMP can receive implicit `CURRENT_TIMESTAMP` behavior and the second can receive an invalid zero-date default under strict SQL modes.

Fix:
- convert all 15 required application/event timestamps across 14 migrations to non-null `dateTime()` / MySQL `DATETIME` semantics;
- preserve all 53 nullable timestamp declarations and Laravel nullable Eloquent timestamps;
- add a migration-verifier regression guard that rejects future required bare `timestamp()` declarations without an explicit safe default policy;
- retain all beta.1.2 route-cache middleware compatibility behavior unchanged.

The failed host install recorded 0 extension migrations and reported successful file/migration rollback, so no repair migration is required for that failed attempt.

## beta.1.4 responsive Maps KPI layout hotfix

Live tablet/desktop rendering exposed a Bootstrap grid defect in the shared Maps navigation view: 13 KPI cards used `col-lg` auto-width columns, so Bootstrap attempted to keep all metrics in one row and compressed labels to character-width columns.

Fix:
- replace the auto-width KPI column with `col-6 col-md-4 col-lg-3 col-xxl-2`;
- preserve normal word wrapping on KPI labels;
- add stable `data-titan-maps-kpi-grid` / `data-titan-maps-kpi-label` hooks;
- add a regression script that fails if the auto-width layout returns;
- cache-bust Maps assets to beta.1.4.

No schema, route, capability, permission or menu change is introduced.

## beta.1.5 Theme-aware KPI card hotfix

- Dedicated theme-aware KPI cards use host Titan/Tabler CSS variables and remain responsive.
- Shared Maps stylesheet loads on every Maps navigation page.
- Added `scripts/test_theme_kpi_cards_runtime.php`.
- No database, route, permission, capability or menu changes.
## beta.1.5 Verification summary

- Runtime/package scripts: 71/71 pass before archive build.
- PHP syntax: 530/530 pass before archive build.
- JavaScript syntax: 2/2 pass before archive build.
- JSON parse: 4/4 pass before archive build.
- Final archive verification is performed again after re-extraction.

## beta.1.6 host-theme readable KPI hotfix

Live dark-theme verification showed beta.1.5 KPI labels could inherit a secondary colour with insufficient contrast, while the six-tone accent rotation visually diverged from the active Titan Zero theme. Beta.1.6 uses the host card surface and body text tokens, one host primary accent, reduced decorative tint, consistent heights, and the existing bounded responsive grid. A runtime regression test enforces these requirements.


## beta.1.7 distinct navigation workspaces hotfix

Live UI verification showed that the named menu routes were distinct, but 35 user routes shared one presentation shell and most fell through to the same global KPI grid plus generic map/records fallback. This made different menu links appear to be the same page with a changed heading.

Fix:
- preserve all 36 existing user menu child routes and their middleware contracts;
- give each of the 35 shared-controller routes an explicit workspace definition and relevant KPI subset;
- preserve Resource Fallback as its dedicated controller/view;
- replace the generic four-column `Recent records` fallback with page-specific tables for canonical locations, team positions, check-ins, dispatch recommendations, geofences, discovery searches, candidate categories, territory analytics, route plans, provider/routing configuration, tracking state and provider usage;
- add meaningful overview quick links and configuration facts to the five parent workspaces;
- differentiate Business Discovery and Nearby Services search composition;
- remove unrelated generic empty-state cards from specialized route, matrix, planner, geofence, dispatch and territory pages;
- add a static regression contract covering all shared user navigation pages.

No schema, migration, named-route, permission, capability or menu-key change is introduced.

### beta.1.7 verification summary

- Runtime/package scripts: 73/73 pass from a correctly named physical `TitanMapsIntelligence/` tree.
- User navigation: 5 parents / 36 child links verified; 35 shared pages have distinct workspace contracts and Resource Fallback retains its dedicated page.
- PHP syntax: 532/532 pass.
- JavaScript syntax: 2/2 pass.
- JSON parse: 4/4 pass.
- Candidate integrity manifest: 579/579 files after regeneration.
- Final ZIP is re-extracted and re-certified before handoff.


## beta.1.8 Blade compiler compatibility hotfix

Live beta.1.7 verification showed that the Titan Zero Livewire/Blade compiler path did not safely compile inline Blade `@php(...)` assignment directives before HTML. The generated cached PHP lacked a closing boundary and treated the following `<div class=...>` as PHP, producing `unexpected token "class"`.

Fix:
- replace all inline `@php(...)` directives with explicit `@php ... @endphp` blocks;
- cover both the shared navigation view and candidate-card component;
- add a package-wide Blade compatibility regression that fails on any inline `@php(...)` directive;
- preserve the beta.1.7 workspace/controller/navigation behavior unchanged.

No database, migration, route, permission, capability or menu-key change is introduced.


### beta.1.8 pre-archive verification summary

- Runtime/package scripts: 74/74 pass from a correctly named physical `TitanMapsIntelligence/` tree.
- PHP syntax: 533/533 pass.
- JavaScript syntax: 2/2 pass.
- JSON parse: 4/4 pass.
- Blade inline-PHP compatibility regression: PASS; 0 inline `@php(...)` directives remain.
- Candidate integrity manifest: 580/580 files after regeneration.
- Final ZIP is re-extracted and re-certified before handoff.

## Joint Pass 11 peer certification
- Optional Titan Field peer only; no required dependency added.
- Maps remains spatial authority for worker tracking, map rendering, routing/ETA and geofences.
- Titan Field remains operational authority; Maps dispatch assignment adapter calls the Field command gateway and never inserts Field dispatch rows directly.

## Joint Pass 14

Offline worker-location replay is device-bound, idempotent, consent/on-duty revalidated, freshness preserving and retention bounded. Stale samples are historical-only and bypass live-state/geofence transition mutation. Pass-14 verification is `php scripts/test_joint_pass14_offline_worker_location_sync.php`.
