<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Enums;

enum PrimeCheckpointStatus: string
{
    case Pending = 'pending';
    case Reached = 'reached';
    case Missed = 'missed';
    case Failed = 'failed';
}
