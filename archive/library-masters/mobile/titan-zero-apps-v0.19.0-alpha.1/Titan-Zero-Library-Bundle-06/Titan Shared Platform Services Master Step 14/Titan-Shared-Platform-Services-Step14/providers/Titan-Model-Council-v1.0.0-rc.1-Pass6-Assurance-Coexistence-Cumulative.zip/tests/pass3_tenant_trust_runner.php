<?php

declare(strict_types=1);

$source = file_get_contents(__DIR__ . '/../System/Tenancy/TenantContextResolver.php');
if (str_contains($source, "input('tenant_company_id')")) {
    fwrite(STDERR, "FAIL: tenant_company_id must never be trusted from raw request input\n");
    exit(1);
}
if (! str_contains($source, "attributes->get('tenant_company_id')")) {
    fwrite(STDERR, "FAIL: trusted middleware tenant attribute support missing\n");
    exit(1);
}
echo "pass3_tenant_trust_runner: OK\n";
