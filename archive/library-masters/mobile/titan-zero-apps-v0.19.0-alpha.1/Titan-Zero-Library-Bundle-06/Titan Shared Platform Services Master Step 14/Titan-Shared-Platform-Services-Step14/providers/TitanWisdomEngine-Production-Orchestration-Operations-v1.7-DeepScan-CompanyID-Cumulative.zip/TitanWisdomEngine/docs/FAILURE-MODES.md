# Failure Modes

- Missing/incomplete tenant or causal context: fail closed.
- Missing/stale/denied governance: no mutation.
- Same idempotency identity with conflicting semantic payload: fail closed.
- Evidence reference reused with conflicting semantics: fail closed.
- Agent/AI self-report marked authoritative or self-validated: reject.
- Resolution evidence not already linked to the same tenant outcome: reject.
- Conclusive resolution without validated authoritative supporting evidence: reject.
- Contradicted revision without validated authoritative `contradicts` evidence: reject.
- Optimistic CAS race: return the winning identical operation receipt when possible; otherwise require retry from fresh state.
- Queue duplicate: unique dispatch/idempotency identity suppresses concurrent duplicates; downstream event consumers must remain idempotent under at-least-once delivery.
- Queue worker cannot obtain evidence/governance: no outcome mutation occurs.
- Disabled runtime or observation dispatcher: no new schedule dispatch; durable history remains intact.
