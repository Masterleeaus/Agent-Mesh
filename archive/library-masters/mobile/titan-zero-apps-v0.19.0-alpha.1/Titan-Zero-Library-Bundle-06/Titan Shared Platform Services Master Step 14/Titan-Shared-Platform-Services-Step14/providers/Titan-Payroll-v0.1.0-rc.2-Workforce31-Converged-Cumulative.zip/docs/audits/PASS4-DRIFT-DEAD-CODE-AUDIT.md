# Pass 4 Drift / Dead Code Audit

## Scope and method

A class/provider/route/container reachability review was run from the Titan service provider, routes, tests and resource contracts. The alpha.3 input contained 903 files. Pass 4 removed unreachable Worksuite-era runtime layers and empty scaffolds while retaining historical evidence under `docs/reference/`.

## Removed/relocated

- 282 empty `.gitkeep` scaffolds and a stray `.tmp` test file.
- Dormant Filament and GraphQL surfaces and duplicate/legacy providers.
- Unreachable donor controllers, DataTables, jobs/listeners/observers, legacy repositories/models, upper-case resource/database trees and unused workflow/security scaffolds.
- Live Envato/Worksuite activation config and helper bootstrap.
- `module_path()` and `Modules\Payroll` live coupling.
- Loose root historical reports moved to `docs/reference/donor-reports/`; legacy docs/manifests moved under `docs/reference/`.
- Reference PHP migrations renamed `.php.txt` so they remain evidence without being executable/scanned production code.

## Preserved donor behavior

Deterministic payroll calculation and cleaning-payroll domain services remain behind Titan contracts. `CleanerShiftReconciliationService` was found unwired during the audit; a failing preservation test exposed the mismatch, then the service was made to implement its contract with canonical tenant/run/source provenance and wired through the Titan provider.

## Result before packaging

Live roots are concentrated in `System/`, `Services/`, `Contracts/`, `Support/`, canonical migrations/routes/config/resources. Current working tree after cleanup: 348 files / 206 PHP files before generated release artifacts are refreshed. No live `.gitkeep`, `.tmp`, Envato identifiers, `module_path()` or `Modules\Payroll` coupling remains.
