# Security

## Beta.1 hardening

- Provider requests are quota-guarded per tenant/provider. Soft limit can degrade to explicitly labelled fallback evidence; hard limit fails closed and does not call the provider.
- Provider credentials remain opaque Vault references; beta.1 adds a secondary secret reference and health-driven failover without persisting raw keys.
- Raw GPS pings remain the only authoritative geofence input. The server evaluates accepted pings immediately and reconciles recent append-only pings every minute; client-enter/exit events are not authoritative.
- Worker GPS accepts only the authenticated server-resolved worker, tracking-enabled/on-duty state, bounded accuracy/timestamps and per-device throttling. Team history requires an active sharing window; stale current locations are excluded.
- `route.estimate` is offline blocked. Offline devices may use separately authorised cached/read evidence but cannot initiate provider routing offline.
- Mandatory certification marked required by the job blocks dispatch when authoritative evidence is failed **or unavailable/unknown**.
- Territory conflicts resolve deterministically and exclusions remain authoritative.

Titan Maps Intelligence is tenant scoped by `company_id`. Tenant identity is resolved from authenticated Titan context and must never be accepted from a client payload.

## Route profiles

Pass 3 registers four explicit profiles:

- authenticated user dashboard: `web`, `auth`, `titan.maps.company`, anti-spoof and company-model binding;
- authenticated API: `api`, `auth:sanctum`, `titan.maps.company`, anti-spoof, company-model binding and action-level Maps permissions;
- admin: `web`, `auth`, `admin` plus explicit `titan-maps-intelligence.admin.access` authorization;
- internal: `api` plus `titan.maps.internal`; it fails closed unless the host binds a service-identity `InternalRequestAuthorizer`.

## Tenant invariants

- `company_id` is required on every persistent Maps model.
- `company_id` is immutable after record creation.
- route IDs for searches, candidates and territory analyses are resolved through the active company boundary; foreign IDs return not found.
- `company_id` and `tenant_id` request fields are rejected before controller execution.

## Credentials

Provider credentials must be opaque Titan Vault references. Plaintext provider keys must not be committed, stored in extension configuration, written to logs or returned in API payloads.

## Exports

Exports remain private, signed and permission-protected through the host `PrivateExportStore`/download controller path.

## Queues

Discovery jobs serialize `companyId`. Pass 3 wraps the entire queued job body in `QueueTenantContext`, then still uses explicit `company_id` predicates for every search/run/candidate/usage lookup. Nested queue work receives the same serialized company ID.

## Reporting

Handle security defects privately through the Titan Zero project security process. Do not include live credentials, private customer data or full production request payloads in reports.

## Operational location references

Pass 6 resolves every job/property/branch/worker/supplier/contractor reference through `FieldReferenceGateway` inside the active `company_id`. No geocoding or `map_locations` write occurs when the reference is missing, deleted, inactive, or foreign to the active company. `map_locations.company_id` remains immutable through `CompanyScopedModel`, and the table has a company-scoped unique reference key. Reverse-geocode output is stored as provider metadata only and cannot overwrite WorkCore authoritative address data.

## Live worker location — alpha.7

Worker location is privacy-sensitive data. Titan Maps resolves company and authenticated user server-side, rejects tenant overrides, requires persisted tracking consent plus on-duty state, and denies conflicting worker references. GPS history is retained separately from the latest operational position and can be pruned according to configured retention. Team-level location reads require a registered host Gate for `titan-maps-intelligence.worker-location.read`; when that Gate is absent, the fallback view/API is restricted to the authenticated worker's own location history.

## Graphical map rendering — alpha.8

Graphical map payloads are produced exclusively from company-scoped queries. The renderer inserts marker labels/metadata with DOM `textContent` and never interprets provider or customer text as HTML. Extension map JavaScript/CSS are served through an explicit allowlisted asset controller and `X-Content-Type-Options: nosniff`. Live Team Map refresh uses the authenticated web route and retains the Pass-7 own-worker fallback whenever no team-location Gate exists.

The default OpenStreetMap tile URL receives only normal viewport requests initiated by an interactive human map. Titan Maps does not prefetch or bulk-download standard OSM tiles. Production operators can replace the tile template and attribution through environment configuration.

## Geofence safety and privacy (alpha.9)
Geofence evaluation runs only on already-authorised accepted worker GPS pings. Geofences and events are company-scoped, attached references are validated inside the company boundary, precise coordinates are not copied into audit records, and job/property arrival/departure actions require confirmation by default. Boundary jitter is suppressed with accuracy-aware containment, hysteresis and consecutive-sample evidence.

## Dispatch Intelligence safety (alpha.13)
Dispatch scoring considers only company-scoped, on-duty, tracking-enabled workers with a fresh accepted Maps location. Worker-team visibility preserves the existing `worker-location.read` privacy boundary. CRM evidence is read only when its resolved tenant ID exactly matches the active Maps company; optional qualification evidence remains unknown when no trusted resolver exists. Explicit mandatory qualification/certification failure and explicit schedule conflict are blockers. Recommendations are not assignments: browser/API assignment requires an explicit human approval action, and AI dispatch decisions additionally require `confirmed=true`. Dispatch recommendations expire, blocked candidates cannot be approved, and the authoritative CRM assignment outcome is persisted separately from the human decision.

## Service territory and geographic pricing boundary — alpha.14

Service territories, evaluations and pricing signals are always scoped to the authenticated `company_id`. Branch-centred travel zones resolve only canonical branch locations owned by that company. Circle and polygon coordinates are bounds-validated, locality values are normalized exact rules, and foreign/unknown branch references fail closed. Travel-zone qualification preserves route provenance: straight-line fallback cannot satisfy a road-distance or drive-time rule, and missing ETA is never fabricated. Geographic pricing signals are evidence only; they are persisted with `authoritative=false` and `application_status=not_applied`. Maps exposes `GeographicPricingSignalProvider` for CRM/quoting consumption but contains no quote, invoice or customer-price mutation path.



## Territory analytics evidence boundary — alpha.15

Territory analytics are company-scoped and persist the methodology/version and source evidence used for each run. Missing canonical job demand remains `unavailable`; missing supplier routing evidence remains in the `unavailable` travel-time band; straight-line fallback is never relabelled as supplier ETA or road distance. Expansion scoring reduces evidence completeness when inputs are unknown. Persisted cell overlays contain derived geographic evidence and do not change CRM records or customer pricing.


## Governed resource fallback — alpha.16

Fallback requests, candidate evidence and human decisions are scoped to the active `company_id`. Contractor escalation tied to a job cannot open external discovery unless the internal Dispatch Intelligence check successfully proves that no eligible internal worker exists; a technical failure in that check fails closed. Approved-network resources are evaluated before new discovery and are never re-promoted. Titan Gear supplier shortages can be linked by `inventory_shortage` public ID, but Maps stores only the operational reference and supplied geographic target and does not mutate Gear inventory records. Discovery candidates require explicit human approval before promotion; AI decisions and promotion additionally require `confirmed=true`. No fallback workflow auto-assigns an external resource. Structured audit records preserve operational-need → search → review → promotion lineage without copying precise target coordinates into logs.

## Governed spatial execution — alpha.17

- Tenant context is resolved server-side. AI/tool inputs containing `tenant_company_id`, `company_id` or `tenant_id` are rejected.
- Execution origin is not exposed as an AI/tool input field. Governed tool handlers stamp `ai` internally; human/system/offline origins are supplied only by trusted server-side call paths.
- Governed execution propagates trace, correlation and causation references and emits structured receipts; unrestricted hidden model reasoning is never persisted.
- Explicit Risk or Autonomy denial blocks execution. AI/system Maps-owned mutation requires available Risk and Autonomy decisions; authoritative cross-extension AI mutation additionally requires Command Bus availability.
- Missing optional Titan engines are reported as unavailable rather than simulated as approved.
- CRM job assignment is no longer performed by a direct CRM service call; it is delegated to the Command Bus adapter using a deterministic idempotency key.
- Titan Go receives only capability/offline-policy metadata. Provider secrets, host handler class names and credential references are not exposed by the offline manifest.
- Authoritative mutations are `OFFLINE_BLOCKED`; consequential Maps-owned mutations are `OFFLINE_PREPARE_ONLY`; only explicitly safe deterministic reads may use `OFFLINE_EXECUTE`.
- Canonical Signal payloads avoid raw GPS/target coordinates where structured identifiers and reason evidence are sufficient.

## Host company middleware compatibility

The extension does not depend on a host-global `titan.company` middleware alias. Authenticated user/API routes use extension-owned `titan.maps.company`, which derives company scope from trusted authenticated/server context and stamps `tenant_company_id`/`company_id` request attributes. Client-provided `tenant_company_id`, `company_id`, and `tenant_id` are rejected. When CRM is installed, Maps may consume CRM's trusted resolved company context without making CRM a required dependency.

## Joint Pass 14

Offline worker-location replay is device-bound, idempotent, consent/on-duty revalidated, freshness preserving and retention bounded. Stale samples are historical-only and bypass live-state/geofence transition mutation. Pass-14 verification is `php scripts/test_joint_pass14_offline_worker_location_sync.php`.


## Joint Pass 15 — optimisation proposal boundary

Route optimisation is computation/evidence only. Requests are company-scoped and proposal rows preserve hashed inputs, exact stop-set evidence, constraints, provider/fallback provenance and expiry. Maps never imports or calls Titan Field mutation classes to apply an order. A Field route can change only after Titan Field independently validates the proposal baseline and runs its own governed command/write path.
