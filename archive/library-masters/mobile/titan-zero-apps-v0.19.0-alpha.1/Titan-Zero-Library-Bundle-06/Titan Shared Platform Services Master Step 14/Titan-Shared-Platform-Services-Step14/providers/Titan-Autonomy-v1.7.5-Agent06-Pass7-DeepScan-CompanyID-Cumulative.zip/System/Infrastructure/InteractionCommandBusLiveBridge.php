<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\InteractionEngine\System\Command\CommandBus;
use App\Extensions\TitanAutonomy\System\Contracts\CommandBusBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\DTOs\GovernedCapabilityCommand;
use InvalidArgumentException;

final class InteractionCommandBusLiveBridge implements CommandBusBridgeContract
{
    public function __construct(
        private readonly CommandBus $bus,
        private readonly HostContextBridgeContract $host,
    ) {}

    public function dispatch(object $command, array $authorityContext): mixed
    {
        if (!$command instanceof GovernedCapabilityCommand) {
            throw new InvalidArgumentException('COMMAND_MUST_BE_GOVERNED_CAPABILITY_COMMAND');
        }

        $payload = $command->payload;
        unset($payload['tenant_company_id'], $payload['tenant_id'], $payload['company_id'], $payload['user_id'], $payload['actor_id'], $payload['_delegated_authority']);
        $clientContext = (array) ($payload['_context'] ?? []);
        unset($clientContext['company_id'], $clientContext['tenant_id'], $clientContext['user_id'], $clientContext['actor_id'], $clientContext['roles'], $clientContext['delegated_scopes'], $clientContext['approval_evidence'], $clientContext['autonomy_workflow_key']);

        $correlation = $command->correlationId ?: (trim((string) ($authorityContext['correlation_id'] ?? '')) ?: bin2hex(random_bytes(16)));
        $idempotency = $command->idempotencyKey ?: (trim((string) ($authorityContext['idempotency_key'] ?? '')) ?: $correlation);

        $autonomyLevel = (string) ($authorityContext['autonomy_level'] ?? '');
        $delegatedExecution = in_array($autonomyLevel, ['auto', 'trusted_auto'], true);
        $payload['_context'] = array_replace($clientContext, [
            'company_id' => (string) $this->host->tenantCompanyId(),
            'tenant_id' => (string) $this->host->tenantCompanyId(),
            'user_id' => (string) $this->host->userId(),
            'actor_id' => (string) $this->host->userId(),
            'actor_type' => $delegatedExecution ? 'system' : 'human',
            'roles' => $delegatedExecution ? [] : array_values(array_filter((array) ($authorityContext['roles'] ?? []), 'is_string')),
            'delegated_scopes' => $delegatedExecution ? [] : array_values(array_filter((array) ($authorityContext['scopes'] ?? []), 'is_string')),
            'source_surface' => 'titan_autonomy',
            'correlation_id' => $correlation,
            'idempotency_key' => $idempotency,
            'interaction_id' => $command->interactionId,
            'session_id' => $command->sessionId,
            'privacy_class' => 'tenant_private',
            'autonomy_workflow_key' => (string) ($authorityContext['workflow_key'] ?? ''),
        ]);
        if (!empty($authorityContext['approval_evidence']) && is_array($authorityContext['approval_evidence'])) {
            $payload['_approval'] = $authorityContext['approval_evidence'];
        } elseif (!$command->trustedInteractionMapped) {
            unset($payload['_approval']);
        }
        if (!empty($authorityContext['delegated_authority']) && is_array($authorityContext['delegated_authority'])) {
            $payload['_delegated_authority'] = $authorityContext['delegated_authority'];
        } else {
            unset($payload['_delegated_authority']);
        }

        $result = $this->bus->dispatchResult($command->capability, $payload);
        return method_exists($result, 'toArray') ? $result->toArray() : $result;
    }
}
