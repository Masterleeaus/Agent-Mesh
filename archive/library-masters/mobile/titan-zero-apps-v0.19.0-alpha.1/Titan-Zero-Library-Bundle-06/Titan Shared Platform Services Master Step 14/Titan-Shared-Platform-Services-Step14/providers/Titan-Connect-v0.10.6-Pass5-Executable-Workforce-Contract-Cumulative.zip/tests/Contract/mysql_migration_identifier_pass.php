<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$files = glob($root.'/database/migrations/*.php') ?: [];
$failures = [];
$checks = 0;

$check = static function (bool $ok, string $message) use (&$failures, &$checks): void {
    $checks++;
    if (! $ok) {
        $failures[] = $message;
        fwrite(STDERR, "FAIL: {$message}\n");
    }
};

foreach ($files as $file) {
    $lines = file($file, FILE_IGNORE_NEW_LINES) ?: [];
    $table = null;

    foreach ($lines as $lineNumber => $line) {
        if (preg_match("/Schema::(?:create|table)\\('([^']+)'/", $line, $m) === 1) {
            $table = $m[1];
        }

        if ($table === null) {
            continue;
        }

        if (preg_match('/\$table->foreignId\(\'([^\']+)\'\)([^;]*?)->constrained\(\'([^\']+)\'(?:\s*,\s*\'[^\']+\')?(?:\s*,\s*\'([^\']+)\')?\)/', $line, $m) === 1) {
            $column = $m[1];
            $explicit = $m[4] ?? '';
            $name = $explicit !== '' ? $explicit : $table.'_'.$column.'_foreign';
            $check(strlen($name) <= 64, basename($file).':'.($lineNumber + 1)." foreign key identifier too long ({$name}, ".strlen($name).' chars)');
        }

        if (preg_match('/\$table->foreign\(\'([^\']+)\'\s*,\s*\'([^\']+)\'\)/', $line, $m) === 1) {
            $check(strlen($m[2]) <= 64, basename($file).':'.($lineNumber + 1)." explicit foreign key identifier too long ({$m[2]})");
        }

        if (preg_match('/\$table->(?:[A-Za-z]+)\(\'([^\']+)\'[^;]*?->(index|unique)\(\)/', $line, $m) === 1) {
            $name = $table.'_'.$m[1].'_'.$m[2];
            $check(strlen($name) <= 64, basename($file).':'.($lineNumber + 1)." generated {$m[2]} identifier too long ({$name}, ".strlen($name).' chars)');
        }
    }
}

$repairPath = $root.'/database/migrations/2026_08_09_000006_repair_partial_mysql_install.php';
$check(is_file($repairPath), 'partial-install repair migration exists');
$repair = is_file($repairPath) ? (file_get_contents($repairPath) ?: '') : '';
$check(str_contains($repair, 'foreignKeyExists('), 'repair migration detects existing foreign keys before adding them');
$check(str_contains($repair, 'indexExistsForColumns('), 'repair migration detects existing indexes before adding them');
$check(str_contains($repair, 'ext_titan_connect_external_thread_reads'), 'repair migration covers external thread reads left by the failed first migration');
$check(str_contains($repair, 'ext_titan_connect_external_thread_tags'), 'repair migration covers donor thread-tag partial installs');
$check(str_contains($repair, 'ext_titan_connect_outbound_deliveries'), 'repair migration covers outbound delivery foreign keys');

if ($failures !== []) {
    fwrite(STDERR, "\nMySQL migration identifier/recovery contract: ".count($failures)." failure(s) across {$checks} checks.\n");
    exit(1);
}

echo "MySQL migration identifier/recovery contract: {$checks}/{$checks} passed.\n";
