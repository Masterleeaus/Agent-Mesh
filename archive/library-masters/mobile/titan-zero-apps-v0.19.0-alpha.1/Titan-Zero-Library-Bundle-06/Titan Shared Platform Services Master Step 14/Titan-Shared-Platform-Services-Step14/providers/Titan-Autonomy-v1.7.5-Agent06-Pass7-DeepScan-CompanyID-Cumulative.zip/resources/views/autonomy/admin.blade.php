@extends($layout)
@section('title', 'Titan Autonomy — Platform Policy')
@section('content')
@php
$mins = $policy['gate_minimums'] ?? $policy['gate_minimums_json'] ?? ['low'=>1,'medium'=>2,'high'=>3,'critical'=>3];
$ceilings = $policy['maximum_level_by_risk'] ?? $policy['maximum_level_by_risk_json'] ?? ['low'=>'trusted_auto','medium'=>'trusted_auto','high'=>'auto','critical'=>'semi_auto'];
$limits = $policy['limits'] ?? [];
@endphp
<div class="ta-card"><a href="{{ route('titan-autonomy.index') }}">← Autonomy Learning</a><h1>Titan Autonomy — Super Admin</h1><p class="ta-muted">Platform safety minimums and maximum authority ceilings. Tenants can only become stricter.</p>@if(session('titan_autonomy_status'))<div class="ta-ok">{{ session('titan_autonomy_status') }}</div>@endif</div>
<form method="post" action="{{ route('titan-autonomy.admin.update') }}">@csrf
<div class="ta-card"><h2>Gate requirements</h2><table class="ta-table"><thead><tr><th>Risk</th><th>Minimum consecutive qualifying successes</th></tr></thead><tbody>
@foreach(['low'=>1,'medium'=>2,'high'=>3,'critical'=>3] as $risk=>$floor)<tr><td>{{ strtoupper($risk) }}</td><td><input class="ta-input" style="max-width:130px" type="number" min="{{ $floor }}" name="gate_{{ $risk }}" value="{{ $mins[$risk] ?? $floor }}"></td></tr>@endforeach
</tbody></table></div>
<div class="ta-card"><h2>Maximum levels by risk</h2><table class="ta-table"><thead><tr><th>Risk</th><th>Maximum</th></tr></thead><tbody>
@foreach(['low','medium','high','critical'] as $risk)<tr><td>{{ strtoupper($risk) }}</td><td><select class="ta-input" style="max-width:220px" name="ceiling_{{ $risk }}">@foreach(['suggest','assist','semi_auto','auto','trusted_auto'] as $level)<option value="{{ $level }}" {{ ($ceilings[$risk] ?? '')===$level?'selected':'' }}>{{ $level }}</option>@endforeach</select></td></tr>@endforeach
</tbody></table>
<label><input type="checkbox" name="high_trusted_auto_exception" value="1" {{ ($limits['high_trusted_auto_exception'] ?? false)?'checked':'' }}> Explicitly permit High-risk Trusted Auto ceiling</label><br><br>
<label><input type="checkbox" name="critical_autonomy_exception" value="1" {{ ($limits['critical_autonomy_exception'] ?? false)?'checked':'' }}> Explicitly permit Critical-risk ceiling above Semi-Auto</label>
<p class="ta-muted">Capability-specific ceilings, bounded scope, evidence gates and the three-way Trusted Auto handshake still apply. These switches do not directly activate autonomy.</p></div>
<div class="ta-card"><h2>Learning configuration</h2><label><input type="checkbox" name="system_wide_learning_permitted" value="1" {{ ($policy['system_wide_learning_permitted'] ?? false)?'checked':'' }}> Allow tenants to opt into de-identified system-wide learning</label><p class="ta-muted">Tenant opt-in remains separate. Raw private tenant records are not eligible for shared learning.</p></div>
<button class="ta-btn" type="submit">Save platform policy</button>
</form>
@endsection
