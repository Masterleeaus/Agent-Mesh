<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Repositories;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Contracts\DealRepositoryContract;
use App\Extensions\Crm\System\Services\{CrmActivityRecorder,DefaultSalesPipelineProvisioner};
use App\Extensions\Crm\System\Automation\Events\CrmAutomationTriggered;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class EloquentDealRepository implements DealRepositoryContract
{
    public function __construct(private ConnectionInterface $db, private DefaultSalesPipelineProvisioner $defaults, private CrmActivityRecorder $activities) {}
    public function search(int $userId,array $filters=[]): array
    {
        $query=$this->db->table(config('crm.tables.deals'))->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at');
        if(($filters['status']??null)!==null)$query->where('status',$filters['status']);
        if(($filters['pipeline_id']??null)!==null)$query->where('pipeline_id',(int)$filters['pipeline_id']);
        if(($filters['q']??null)!==null){$term='%'.trim((string)$filters['q']).'%';$query->where('name','like',$term);}
        return $query->orderByDesc('id')->limit(min((int)($filters['limit']??100),250))->get()->map(fn($r)=>(array)$r)->all();
    }
    public function create(int $userId,int $actorUserId,array $data): array
    {
        $pipeline=$data['pipeline_public_id']??null; $pipelineRow=null;
        if($pipeline){$pipelineRow=$this->db->table(config('crm.tables.pipelines'))->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$pipeline)->whereNull('deleted_at')->first();}
        if(!$pipelineRow){$default=$this->defaults->ensure($userId);$pipelineRow=$this->db->table(config('crm.tables.pipelines'))->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$default['public_id'])->first();}
        $stagePublic=$data['stage_public_id']??null;
        $companyId=CrmCompanyScope::companyId($userId);
        $stage=$stagePublic ? $this->db->table(config('crm.tables.stages'))->where('company_id',$companyId)->where('pipeline_id',$pipelineRow->id)->where('public_id',$stagePublic)->whereNull('deleted_at')->first() : $this->db->table(config('crm.tables.stages'))->where('company_id',$companyId)->where('pipeline_id',$pipelineRow->id)->whereNull('deleted_at')->orderBy('position')->first();
        if(!$stage) throw ValidationException::withMessages(['stage_public_id'=>['A valid pipeline stage is required.']]);
        $publicId=(string)Str::ulid();
        $id=$this->db->table(config('crm.tables.deals'))->insertGetId([
            'public_id'=>$publicId,'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'customer_company_id'=>$this->internalId('companies',$userId,$data['company_public_id']??null),'contact_id'=>$this->internalId('contacts',$userId,$data['contact_public_id']??null),
            'pipeline_id'=>$pipelineRow->id,'stage_id'=>$stage->id,'name'=>(string)$data['name'],'description'=>$data['description']??null,'value_minor'=>(int)($data['value_minor']??0),'currency'=>strtoupper((string)($data['currency']??'AUD')),
            'status'=>'open','owner_user_id'=>$data['owner_user_id']??$actorUserId,'probability'=>(int)($data['probability']??$stage->probability??0),'position'=>(int)($data['position']??0),'expected_close_date'=>$data['expected_close_date']??null,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now(),
        ]);
        $this->activities->record($userId,'deal',$publicId,'created','Deal created',null,null,null,null,$actorUserId);
        return (array)$this->db->table(config('crm.tables.deals'))->where('id',$id)->first();
    }
    public function update(int $userId,string $publicId,int $actorUserId,array $data): array
    {
        $deal=$this->deal($userId,$publicId);$updates=[];
        foreach(['name','description','owner_user_id','probability','expected_close_date'] as $key){if(array_key_exists($key,$data))$updates[$key]=$data[$key];}
        if(array_key_exists('value_minor',$data))$updates['value_minor']=(int)$data['value_minor'];
        if(array_key_exists('currency',$data))$updates['currency']=strtoupper((string)$data['currency']);
        if(array_key_exists('company_public_id',$data))$updates['customer_company_id']=$this->internalId('companies',$userId,$data['company_public_id']);
        if(array_key_exists('contact_public_id',$data))$updates['contact_id']=$this->internalId('contacts',$userId,$data['contact_public_id']);
        if(array_key_exists('metadata',$data))$updates['metadata']=$data['metadata']===null?null:json_encode($data['metadata']);
        if($updates){$updates['updated_at']=now();$this->db->table(config('crm.tables.deals'))->where('id',$deal->id)->update($updates);$this->activities->record($userId,'deal',$publicId,'updated','Deal updated',null,null,null,null,$actorUserId);}
        return (array)$this->deal($userId,$publicId);
    }
    public function move(int $userId,string $publicId,int $actorUserId,array $data): array
    {
        $deal=$this->deal($userId,$publicId);$stage=$this->db->table(config('crm.tables.stages'))->where('company_id',CrmCompanyScope::companyId($userId))->where('pipeline_id',$deal->pipeline_id)->where('public_id',(string)$data['stage_public_id'])->whereNull('deleted_at')->first();if(!$stage)throw ValidationException::withMessages(['stage_public_id'=>['Stage not found in this pipeline.']]);
        $updates=['stage_id'=>$stage->id,'probability'=>(int)($data['probability']??$stage->probability),'position'=>(int)($data['position']??0),'updated_at'=>now()];
        if($stage->is_closed){$updates['status']=$stage->is_won?'won':'lost';$updates['closed_at']=now();}
        $this->db->table(config('crm.tables.deals'))->where('id',$deal->id)->update($updates);$this->activities->record($userId,'deal',$publicId,'stage_changed','Deal stage changed',null,null,null,null,$actorUserId,['stage_public_id'=>$stage->public_id]);event(new CrmAutomationTriggered($userId,'deal.stage_changed',['subject_type'=>'deal','subject_public_id'=>$publicId,'stage_public_id'=>$stage->public_id,'idempotency_key'=>'deal.stage_changed:'.$publicId.':'.$stage->public_id]));return (array)$this->deal($userId,$publicId);
    }
    public function markWon(int $userId,string $publicId,int $actorUserId): array
    { return $this->close($userId,$publicId,$actorUserId,true,null); }
    public function markLost(int $userId,string $publicId,int $actorUserId,string $reason): array
    { return $this->close($userId,$publicId,$actorUserId,false,$reason); }
    private function close(int $userId,string $publicId,int $actorUserId,bool $won,?string $reason): array
    {
        $deal=$this->deal($userId,$publicId);$stage=$this->db->table(config('crm.tables.stages'))->where('company_id',CrmCompanyScope::companyId($userId))->where('pipeline_id',$deal->pipeline_id)->where('is_closed',true)->where('is_won',$won)->whereNull('deleted_at')->orderBy('position')->first();if(!$stage)throw ValidationException::withMessages(['deal'=>['Pipeline does not have the required closed stage.']]);$this->db->table(config('crm.tables.deals'))->where('id',$deal->id)->update(['stage_id'=>$stage->id,'status'=>$won?'won':'lost','probability'=>$won?100:0,'closed_at'=>now(),'lost_reason'=>$won?null:$reason,'updated_at'=>now()]);$this->activities->record($userId,'deal',$publicId,$won?'won':'lost',$won?'Deal won':'Deal lost',$reason,null,null,now()->toDateTimeString(),$actorUserId);if($won)event(new CrmAutomationTriggered($userId,'deal.won',['subject_type'=>'deal','subject_public_id'=>$publicId,'idempotency_key'=>'deal.won:'.$publicId]));return (array)$this->deal($userId,$publicId);
    }
    private function deal(int $userId,string $publicId): object{$row=$this->db->table(config('crm.tables.deals'))->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at')->first();if(!$row)throw ValidationException::withMessages(['deal'=>['Deal not found.']]);return $row;}
    private function internalId(string $tableKey,int $userId,?string $publicId): ?int{if(!$publicId)return null;$id=$this->db->table(config('crm.tables.'.$tableKey))->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at')->value('id');if(!$id)throw ValidationException::withMessages([$tableKey.'_public_id'=>['Referenced CRM record not found.']]);return (int)$id;}
}
