<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Host;

final class TitanConnectPermissionCatalogue
{
    /** @return array<int,array{key:string,label:string,routes:array<int,string>}> */
    public function all(): array
    {
        return [
            ['key' => 'admin_titan_connect_channels', 'label' => 'Titan Connect Channels', 'routes' => ['titan-connect.admin.channels.*']],
            ['key' => 'admin_titan_connect_channels_overview', 'label' => 'Titan Connect Overview / Diagnostics', 'routes' => ['titan-connect.admin.channels.index']],
            ['key' => 'admin_titan_connect_channel_whatsapp', 'label' => 'Titan Connect WhatsApp', 'routes' => ['titan-connect.admin.channels.whatsapp']],
            ['key' => 'admin_titan_connect_channel_messenger', 'label' => 'Titan Connect Messenger', 'routes' => ['titan-connect.admin.channels.messenger']],
            ['key' => 'admin_titan_connect_channel_instagram', 'label' => 'Titan Connect Instagram', 'routes' => ['titan-connect.admin.channels.instagram']],
            ['key' => 'admin_titan_connect_channel_telegram', 'label' => 'Titan Connect Telegram', 'routes' => ['titan-connect.admin.channels.telegram']],
            ['key' => 'admin_titan_connect_channel_sms', 'label' => 'Titan Connect SMS', 'routes' => ['titan-connect.admin.channels.sms']],
            ['key' => 'admin_titan_connect_channel_voice', 'label' => 'Titan Connect Voice', 'routes' => ['titan-connect.admin.channels.voice']],
            ['key' => 'admin_titan_connect_channel_push', 'label' => 'Titan Connect Push / Mobile', 'routes' => ['titan-connect.admin.channels.push']],
        ];
    }

    /** @return array<int,string> */
    public function keys(): array
    {
        return array_column($this->all(), 'key');
    }
}
