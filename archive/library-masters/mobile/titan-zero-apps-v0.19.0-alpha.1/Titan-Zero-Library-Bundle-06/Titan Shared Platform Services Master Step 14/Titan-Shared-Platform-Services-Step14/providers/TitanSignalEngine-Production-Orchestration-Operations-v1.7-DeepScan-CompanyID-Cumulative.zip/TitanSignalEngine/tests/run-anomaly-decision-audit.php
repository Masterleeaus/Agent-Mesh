<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/AnomalyDecisionAudit.php';

use App\Extensions\TitanSignalEngine\System\Data\AnomalyDecisionAudit;

function auditAssert(bool $condition, string $message): void {
    if (! $condition) throw new RuntimeException($message);
}

$ack = AnomalyDecisionAudit::make(
    action: 'acknowledged',
    anomalyId: '0198f5fd-1111-7111-8111-111111111111',
    anomalyType: 'sequence_violation',
    subjectType: 'trace',
    subjectId: '0198f5fd-2222-7222-8222-222222222222',
    reason: 'operator_reviewed',
    actorId: 'usr_42',
    actorType: 'human',
    decisionVersion: 3,
    decidedAt: new DateTimeImmutable('2026-08-18T02:00:00+00:00'),
    evidenceReference: 'sha256:abcdef',
);

auditAssert($ack->eventType === 'signal.anomaly.acknowledged', 'Acknowledgement must map to the canonical immutable event type.');
auditAssert($ack->payload['decision_version'] === 3, 'Decision version must be included in the immutable payload.');
auditAssert($ack->payload['actor_id'] === 'usr_42', 'Trusted actor id must be retained in the immutable payload.');
auditAssert($ack->payload['reason'] === 'operator_reviewed', 'Lifecycle reason must be retained.');
auditAssert($ack->idempotencyKey === 'anomaly-decision:0198f5fd-1111-7111-8111-111111111111:3:acknowledged', 'Idempotency must be stable per lifecycle transition version.');

$suppressed = AnomalyDecisionAudit::make(
    action: 'suppressed',
    anomalyId: '0198f5fd-1111-7111-8111-111111111111',
    anomalyType: 'sequence_violation',
    subjectType: 'trace',
    subjectId: '0198f5fd-2222-7222-8222-222222222222',
    reason: 'maintenance_window',
    actorId: 'usr_42',
    actorType: 'human',
    decisionVersion: 4,
    decidedAt: new DateTimeImmutable('2026-08-18T02:01:00+00:00'),
    suppressionUntil: new DateTimeImmutable('2026-08-18T03:01:00+00:00'),
);

auditAssert($suppressed->payload['suppression_until'] === '2026-08-18T03:01:00+00:00', 'Suppression expiry must be immutable audit evidence.');

$reopened = AnomalyDecisionAudit::make(
    action: 'reopened',
    anomalyId: '0198f5fd-1111-7111-8111-111111111111',
    anomalyType: 'sequence_violation',
    subjectType: 'trace',
    subjectId: '0198f5fd-2222-7222-8222-222222222222',
    reason: 'condition_recurred',
    actorId: 'titan-signal-anomaly-engine',
    actorType: 'system',
    decisionVersion: 5,
    decidedAt: new DateTimeImmutable('2026-08-18T02:02:00+00:00'),
);

auditAssert($reopened->eventType === 'signal.anomaly.reopened', 'Automatic recurrence must have its own immutable lifecycle event.');

$thrown = false;
try {
    AnomalyDecisionAudit::make(
        action: 'deleted',
        anomalyId: '0198f5fd-1111-7111-8111-111111111111',
        anomalyType: 'sequence_violation',
        subjectType: 'trace',
        subjectId: '0198f5fd-2222-7222-8222-222222222222',
        reason: 'invalid',
        actorId: 'usr_42',
        actorType: 'human',
        decisionVersion: 6,
        decidedAt: new DateTimeImmutable('2026-08-18T02:03:00+00:00'),
    );
} catch (InvalidArgumentException) {
    $thrown = true;
}
auditAssert($thrown, 'Unknown anomaly lifecycle actions must be rejected.');


$manifest = json_decode((string) file_get_contents(__DIR__ . '/../extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
auditAssert(($manifest['version'] ?? null) === '0.20.0-rc.8.1', 'Manifest must advertise v0.20.0-rc.8.1.');
auditAssert(in_array('signal.anomaly.manage', $manifest['capabilities'] ?? [], true), 'Manifest must advertise signal.anomaly.manage.');
$manage = null;
foreach (($manifest['capability_contracts'] ?? []) as $contract) {
    if (($contract['id'] ?? null) === 'signal.anomaly.manage') $manage = $contract;
}
auditAssert(is_array($manage), 'Blueprint capability contract for signal.anomaly.manage is missing.');
auditAssert(count($manage['emitted_events'] ?? []) === 4, 'Anomaly manage contract must declare all four immutable lifecycle events.');

$config = require __DIR__ . '/../config/titan-signal-engine.php';
$patterns = $config['trusted_emitters']['titan-signal-engine:anomaly-engine']['event_type_patterns'] ?? [];
foreach (['signal.anomaly.detected','signal.anomaly.acknowledged','signal.anomaly.suppressed','signal.anomaly.resolved','signal.anomaly.reopened'] as $eventType) {
    auditAssert(in_array($eventType, $patterns, true), "Trusted anomaly emitter must allow {$eventType}.");
    auditAssert(isset($config['event_types'][$eventType]), "Package event registry must define {$eventType}.");
}

$serviceSource = (string) file_get_contents(__DIR__ . '/../System/Services/AnomalyDetectionService.php');
auditAssert(str_contains($serviceSource, 'recordDecision($row, \'acknowledged\''), 'Acknowledgement must route through immutable decision audit.');
auditAssert(str_contains($serviceSource, 'recordDecision($row, \'suppressed\''), 'Suppression must route through immutable decision audit.');
auditAssert(str_contains($serviceSource, 'recordDecision($row, \'resolved\''), 'Resolution must route through immutable decision audit.');
auditAssert(str_contains($serviceSource, 'recordDecision($row, \'reopened\''), 'Reopening must route through immutable decision audit.');

fwrite(STDOUT, "anomaly-decision-audit: PASS\n");
