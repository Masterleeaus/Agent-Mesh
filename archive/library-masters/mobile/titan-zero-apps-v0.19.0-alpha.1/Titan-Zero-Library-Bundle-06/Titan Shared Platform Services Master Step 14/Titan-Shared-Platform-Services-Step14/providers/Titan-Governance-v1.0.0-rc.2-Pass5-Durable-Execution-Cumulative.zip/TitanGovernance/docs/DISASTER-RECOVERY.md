# Disaster recovery

Document backup scope, RPO/RTO, restore steps, dependency ordering and post-restore reconciliation.
