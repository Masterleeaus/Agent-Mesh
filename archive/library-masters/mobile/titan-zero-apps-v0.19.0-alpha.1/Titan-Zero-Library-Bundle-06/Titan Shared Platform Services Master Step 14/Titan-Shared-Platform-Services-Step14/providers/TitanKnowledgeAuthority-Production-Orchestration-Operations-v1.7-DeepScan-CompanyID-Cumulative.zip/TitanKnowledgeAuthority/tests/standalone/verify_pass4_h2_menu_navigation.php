<?php
$root = dirname(__DIR__, 2);
$fail = [];
$registrar = file_get_contents($root.'/System/Support/HostNavigationRegistrar.php') ?: '';
$nav = file_get_contents($root.'/System/Support/TitanKnowledgeAuthorityNavigation.php') ?: '';
$provider = file_get_contents($root.'/System/TitanKnowledgeAuthorityServiceProvider.php') ?: '';
$checks = [
    'modern user registry class contributor' => str_contains($registrar, "MenuContributionRegistry") && str_contains($registrar, 'TitanKnowledgeAuthorityUserNavigationContributor::class'),
    'modern registry correct user key' => str_contains($nav, "USER_KEY = 'titan_knowledge_authority'"),
    'admin contribution registry direct' => str_contains($registrar, "'navigation.admin'") && str_contains($registrar, 'ContributionRegistry'),
    'legacy menus fallback' => str_contains($registrar, 'LegacyMenuStore') && is_file($root.'/System/Support/LegacyMenuStore.php'),
    'menu service regenerate fallback' => str_contains($registrar, "MENU_SERVICE = 'App\\\\Services\\\\Common\\\\MenuService'") && str_contains($registrar, 'regenerate'),
    'route existence guard' => str_contains($registrar, 'Route::has'),
    'preserve admin menu state' => str_contains($registrar, "'order'") && str_contains($registrar, "'enabled'") && str_contains($registrar, "'is_active'"),
    'safe icon fallback' => str_contains($nav, 'tabler-folders'),
    'provider registers navigation after routes' => strpos($provider, '$this->registerRoutes();') !== false && strpos($provider, '(new HostNavigationRegistrar') > strpos($provider, '$this->registerRoutes();'),
];
foreach ($checks as $name=>$ok) { if (!$ok) $fail[]=$name; }
if ($fail) { fwrite(STDERR, "FAIL\n - ".implode("\n - ",$fail)."\n"); exit(1); }
echo "PASS menu navigation H2\n";
