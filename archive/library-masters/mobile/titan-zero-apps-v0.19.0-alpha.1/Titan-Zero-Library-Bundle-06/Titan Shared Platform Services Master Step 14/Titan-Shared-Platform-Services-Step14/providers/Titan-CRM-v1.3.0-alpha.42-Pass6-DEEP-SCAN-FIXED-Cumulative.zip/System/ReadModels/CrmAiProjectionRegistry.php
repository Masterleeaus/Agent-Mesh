<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\ReadModels;

/** Backward-compatible AI registry facade over the canonical CQRS projection registry. */
final class CrmAiProjectionRegistry
{
    /** Historical alpha.21 projection contract retained for installer/regression introspection. */
    private const LEGACY_PROJECTION_NAMES=['customer_summary','customer_timeline','sales_pipeline','invoice_context','receivables_context'];
    private const LEGACY_VERSION_KEY='projection_version';
    public function __construct(private readonly CrmReadProjectionRegistry $registry) {}

    /** @return array<string,mixed> */
    public function resolve(string $name,?string $version=null): array { return $this->registry->resolve($name,$version); }

    /** @return list<string> */
    public function names(): array { return $this->registry->names(); }
}
