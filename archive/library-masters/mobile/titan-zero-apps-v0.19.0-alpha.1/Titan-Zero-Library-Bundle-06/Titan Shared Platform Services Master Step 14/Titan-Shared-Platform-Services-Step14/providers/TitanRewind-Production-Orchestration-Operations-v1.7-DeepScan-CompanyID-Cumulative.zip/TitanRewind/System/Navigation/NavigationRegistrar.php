<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Navigation;

use Illuminate\Contracts\Container\Container;
use ReflectionMethod;
use Throwable;

final class NavigationRegistrar
{
    private const USER_REGISTRY = 'App\\Support\\Extensions\\MenuContributionRegistry';
    private const GENERIC_REGISTRY = 'App\\Support\\Extensions\\ContributionRegistry';

    public static function register(Container $container): array
    {
        $user = self::registerUser($container);
        $admin = self::registerAdmin($container);
        $database = MagicAiMenuSynchronizer::sync($container);

        return [
            'user' => $user,
            'admin' => $admin,
            'database' => $database,
        ];
    }

    private static function registerUser(Container $container): bool
    {
        if (!class_exists(self::USER_REGISTRY)) {
            return false;
        }

        try {
            $registry = $container->make(self::USER_REGISTRY);
            return self::invoke($registry, 'navigation.user', TitanRewindNavigation::user(), false);
        } catch (Throwable) {
            return false;
        }
    }

    private static function registerAdmin(Container $container): bool
    {
        if (!class_exists(self::GENERIC_REGISTRY)) {
            return false;
        }

        try {
            $registry = $container->make(self::GENERIC_REGISTRY);
            return self::invoke($registry, 'navigation.admin', TitanRewindNavigation::admin(), true);
        } catch (Throwable) {
            return false;
        }
    }

    private static function invoke(object $registry, string $channel, array $definitions, bool $generic): bool
    {
        foreach (['register', 'contribute', 'add'] as $method) {
            if (!method_exists($registry, $method)) {
                continue;
            }

            try {
                $reflection = new ReflectionMethod($registry, $method);
                $count = $reflection->getNumberOfParameters();

                if ($generic) {
                    if ($count >= 3) {
                        $registry->{$method}($channel, 'titan-rewind', $definitions);
                        return true;
                    }
                    if ($count === 2) {
                        $registry->{$method}($channel, $definitions);
                        return true;
                    }
                    continue;
                }

                if ($count >= 3) {
                    $registry->{$method}($channel, 'titan-rewind', $definitions);
                    return true;
                }
                if ($count === 2) {
                    $first = strtolower($reflection->getParameters()[0]->getName());
                    if (str_contains($first, 'channel')) {
                        $registry->{$method}($channel, $definitions);
                    } else {
                        $registry->{$method}('titan-rewind', $definitions);
                    }
                    return true;
                }
                if ($count === 1) {
                    $registry->{$method}($definitions);
                    return true;
                }
            } catch (Throwable) {
                continue;
            }
        }

        return false;
    }
}
