# MagicAI CRM 1.2 Architecture

## Status
**IMPLEMENTED — source/package level.** Live Laravel/database host execution remains **UNVERIFIED** until installed in a real MagicAI host.

## Authority
MagicAI CRM is the authoritative business operating layer for Titan Zero. It owns business state for customers, account companies, leads, sales, service catalogue, service requests, work orders, appointments, dispatch, recurring services, field records, forms/evidence, support/reviews, invoices, payment/reconciliation state, and business operating configuration.

External systems do not duplicate that authority:

```text
Titan surfaces / Chatbot / Onboarding / TitanAI
                    |
          Interaction / capability routing
                    |
             governed CRM contracts
                    |
                 CRM 1.2
          authoritative business state
                    |
       ZeroPay / provider executes payment
```

TitanAI owns model routing/orchestration. Interaction Engine owns intent/workflow/approval orchestration. Titan Connect owns communications transport. Titan Builder owns visual/app schemas. Titan Mobile owns device/offline storage. CRM owns business validation, transactions and persistence.

## Tenant boundary
`tenant_company_id` is the physical CRM tenant key. `company_id` continues to mean a CRM customer/account company relationship. `user_id` is non-authoritative actor/legacy provenance; explicit owner/assignee/worker fields remain person identifiers.

Trusted company context is represented by `CrmCompanyContext`, resolved by `CrmCompanyContextResolver`, stored by `CrmCompanyScope`, established for authenticated CRM routes by `CrmCompanyContextMiddleware`, and re-authorized by `CrmCompanyAuthorizationGateway`.

## External contracts
External Titan consumers receive explicit DTOs/gateways/capabilities, not raw Eloquent models. The platform manifest advertises `crm.company-tenancy`, `crm.customer.operations`, `crm.field.offline`, `crm.owner.dashboard`, `crm.business.configuration`, `crm.titanai.tools`, `crm.interaction.actions`, and `crm.field-home-services`.

## Focused providers
`CrmServiceProvider` delegates 1.2 concerns to `CrmTenantServiceProvider`, `CrmFieldServiceProvider`, `CrmCapabilityServiceProvider`, and `CrmTitanIntegrationServiceProvider` so the root provider remains manageable.
