# Integration Contracts

Other Titan extensions integrate through Signal public contracts only.

## Emission

1. Resolve `SignalEmitterAuthorityContract`.
2. Obtain the registered/attested emitter identity for the calling component.
3. Build a trusted `SignalContext` with canonical tenant and actor identity.
4. Emit through `SignalEmitterContract`.
5. Use a registered event type and stable idempotency key for retryable delivery.

Do not import `TitanSignalEngine\System\Services` concrete implementations from another extension.

## Reads

Use `SignalQueryContract`, `SignalCorrelationContract`, `SignalPulseContract` or `SignalConsoleContract` with the correct trusted context. System scope requires explicit system-read authority.

## Subscriptions

Resolve `SignalRegistryAuthorityContract`, obtain the calling extension's registered `SignalRegistryIdentity`, then register through `SignalSubscriptionRegistryContract`. Subscriber definitions are immutable versions; changes use `evolve()`. Subscriber keys are owner-scoped. Missing handlers are quarantined and skipped rather than blocking Signal ingestion. Subscribers must still tolerate at-least-once delivery and use event/delivery identities for idempotency.


## Event-type registry

Event owners register through `EventTypeRegistryContract` using the same trusted registry identity. First registration uses `register()`; schema/control-plane changes use `evolve()`. Ownership cannot be silently transferred and historical definition versions remain queryable through `history()`.

## Subscriber delivery context

`SignalSubscriberContract::handle()` receives `SignalDeliveryContext` with `deliveryId`, `subscriberKey`, `attempt`, `leaseToken`, `workerId`, and stable `idempotencyKey`. Subscriber implementations must not persist or authorize against the lease token; it expires and changes on reclaim.

## signal.lifecycle v2.0

The prune operation is a two-step destructive contract: `previewPrune()` returns a one-time `preview_token` bound to a persisted exact candidate hash, then `prune(preview_token, reason, context)` confirms only that set. Boolean `confirmed=true` callers are no longer supported.
