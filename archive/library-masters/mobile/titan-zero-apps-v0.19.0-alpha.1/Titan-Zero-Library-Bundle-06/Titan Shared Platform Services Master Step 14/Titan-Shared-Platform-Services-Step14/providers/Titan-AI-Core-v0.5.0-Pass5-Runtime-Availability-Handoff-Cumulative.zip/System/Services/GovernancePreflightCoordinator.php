<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Services;

use App\Extensions\TitanAICore\System\Contracts\AssuranceGatewayContract;
use App\Extensions\TitanAICore\System\Contracts\AutonomyGatewayContract;
use App\Extensions\TitanAICore\System\Contracts\GovernancePreflightContract;
use App\Extensions\TitanAICore\System\Contracts\RiskGatewayContract;
use App\Extensions\TitanAICore\System\DTO\GovernanceDecision;
use App\Extensions\TitanAICore\System\DTO\GovernancePreflightReport;
use App\Extensions\TitanAICore\System\DTO\GovernancePreflightRequest;

final readonly class GovernancePreflightCoordinator implements GovernancePreflightContract
{
    public function __construct(
        private RiskGatewayContract $risk,
        private AssuranceGatewayContract $assurance,
        private AutonomyGatewayContract $autonomy,
    ) {}

    public function evaluate(GovernancePreflightRequest $request): GovernancePreflightReport
    {
        $decisions = [
            $this->risk->evaluate($request),
            $this->assurance->evaluate($request),
            $this->autonomy->evaluate($request),
        ];

        $executable = array_reduce(
            $decisions,
            static fn (bool $allowed, GovernanceDecision $decision): bool => $allowed && $decision->allowsExecution(),
            true,
        );

        $requiresHumanReview = !$executable || array_reduce(
            $decisions,
            static fn (bool $required, GovernanceDecision $decision): bool => $required || $decision->requiresHumanReview(),
            false,
        );

        return new GovernancePreflightReport(
            state: $executable ? 'ALLOW' : 'PENDING_REVIEW',
            executable: $executable,
            requiresHumanReview: $requiresHumanReview,
            decisions: $decisions,
        );
    }
}
