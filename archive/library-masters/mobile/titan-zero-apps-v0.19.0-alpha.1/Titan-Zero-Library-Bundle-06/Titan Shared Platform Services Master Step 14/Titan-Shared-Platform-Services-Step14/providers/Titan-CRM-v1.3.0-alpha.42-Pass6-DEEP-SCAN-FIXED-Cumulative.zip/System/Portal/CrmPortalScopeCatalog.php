<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Portal;

final class CrmPortalScopeCatalog
{
    public const SCOPES = [
        'profile.view',
        'sales.view',
        'sales.accept',
        'sales.comment',
        'files.view',
        'files.download',
        'files.upload',
    ];

    public function validate(array $scopes): array
    {
        $scopes = array_values(array_unique(array_map('strval', $scopes)));
        $bad = array_diff($scopes, self::SCOPES);
        if ($bad) {
            throw new \InvalidArgumentException('Unsupported CRM portal scope: '.implode(', ', $bad));
        }

        if (in_array('files.download', $scopes, true) && !in_array('files.view', $scopes, true)) {
            throw new \InvalidArgumentException('files.download requires files.view');
        }
        if (in_array('files.upload', $scopes, true) && !in_array('files.view', $scopes, true)) {
            throw new \InvalidArgumentException('files.upload requires files.view');
        }
        if (in_array('sales.accept', $scopes, true) && !in_array('sales.view', $scopes, true)) {
            throw new \InvalidArgumentException('sales.accept requires sales.view');
        }
        if (in_array('sales.comment', $scopes, true) && !in_array('sales.view', $scopes, true)) {
            throw new \InvalidArgumentException('sales.comment requires sales.view');
        }

        return $scopes;
    }
}
