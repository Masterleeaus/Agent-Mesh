<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$config = file_get_contents($root . '/config/titan-signal-engine.php') ?: '';
$admin = file_get_contents($root . '/System/Http/Controllers/AdminController.php') ?: '';
$user = file_get_contents($root . '/System/Http/Controllers/IndexController.php') ?: '';
$provider = file_get_contents($root . '/System/TitanSignalEngineServiceProvider.php') ?: '';
$health = file_get_contents($root . '/System/Health/TitanSignalEngineHealthCheck.php') ?: '';
$migration = file_get_contents($root . '/database/migrations/2026_08_11_000004_harden_titan_signal_foundation.php') ?: '';
$console = file_get_contents($root . '/System/Services/SignalConsoleService.php') ?: '';
$manifest = json_decode(file_get_contents($root . '/extension.manifest.json') ?: '{}', true);

$assert(! str_contains($admin, '->getMessage()'), 'Admin console must not expose raw exception messages.');
$assert(! str_contains($user, '->getMessage()'), 'Tenant console must not expose raw exception messages.');
$assert(is_file($root . '/System/Services/SignalConsoleErrorReporter.php'), 'Safe console error reporter must exist.');
$assert(str_contains($admin, 'SignalConsoleErrorReporter'), 'Admin console must use the safe error reporter.');
$assert(str_contains($user, 'SignalConsoleErrorReporter'), 'Tenant console must use the safe error reporter.');

$assert(! str_contains($migration, 'SignalEnvelope'), 'Historical migration must not depend on the runtime SignalEnvelope class.');
$assert(! str_contains($migration, 'App\\Extensions\\TitanSignalEngine\\System'), 'Historical migration must be runtime-class independent.');

$navigation = is_array($manifest['navigation'] ?? null) ? $manifest['navigation'] : [];
$userNavigation = is_array($navigation['user'] ?? null) ? $navigation['user'] : [];
$adminNavigation = is_array($navigation['admin'] ?? null) ? $navigation['admin'] : [];
$assert($userNavigation === [], 'Manifest must not declare ordinary user navigation for Signal Engine.');
$assert($adminNavigation !== [], 'Manifest must declare Super Admin navigation contribution.');
$assert(! is_file($root . '/System/Navigation/SignalUserNavigation.php'), 'User navigation contributor must be removed from the Super Admin-only package.');
$assert(is_file($root . '/System/Navigation/SignalAdminNavigation.php'), 'Super Admin navigation contributor must exist.');

foreach (['tenant_key', 'default_schema_version', 'envelope_version', 'checksum_algorithm', 'query_limit'] as $deadKey) {
    $assert(! preg_match("/'" . preg_quote($deadKey, '/') . "'\\s*=>/", $config), "Decorative config key {$deadKey} must be removed.");
}
$assert(str_contains($provider, "delivery_recovery_limit"), 'Configured delivery_recovery_limit must drive the scheduled recovery command.');
$assert(str_contains($provider, "config('titan-signal-engine.queue'"), 'Configured queue name must be wired at runtime.');
$assert(str_contains($health, "rollout_stage"), 'Configured rollout_stage must appear in health output.');

$assert(str_contains($console, 'limit($runtimeLimit * 8)->cursor()'), 'Console subscriber delivery aggregation must be bounded.');

if ($failures !== []) {
    fwrite(STDERR, "Runtime drift hardening FAILED:\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "Runtime drift hardening PASS\n";
