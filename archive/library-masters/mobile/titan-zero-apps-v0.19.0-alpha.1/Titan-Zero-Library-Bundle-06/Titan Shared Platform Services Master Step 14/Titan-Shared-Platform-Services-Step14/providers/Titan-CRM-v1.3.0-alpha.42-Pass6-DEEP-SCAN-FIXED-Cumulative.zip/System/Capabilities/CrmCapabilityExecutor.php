<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Capabilities;

use App\Extensions\Crm\System\Contracts\{CompanyRepositoryContract,ContactRepositoryContract,LeadRepositoryContract,DealRepositoryContract,PipelineRepositoryContract,CalendarRepositoryContract,ProjectRepositoryContract,TaskRepositoryContract,SalesDocumentRepositoryContract,TagRepositoryContract,CustomFieldRepositoryContract,ActivityRepositoryContract,NoteRepositoryContract};
use App\Extensions\Crm\System\Domains\BusinessConfiguration\BusinessConfigurationService;
use App\Extensions\Crm\System\Integrations\ExternalDomains\CrmExternalDomainCapabilityBridge;
use App\Extensions\Crm\System\Portal\CrmPortalGrantService;
use App\Extensions\Crm\System\Privacy\{CrmPrivacyService,CrmRetentionService};
use App\Extensions\Crm\System\Integrations\{CrmApiKeyService,CrmWebhookService,CrmWebhookDispatcher};
use App\Extensions\Crm\System\Sharing\CrmRecordShareService;
use App\Extensions\Crm\System\Services\{CrmAuditRecorder,CrmNotificationOutboxService,SalesDocumentDeliveryService,SalesDocumentRevisionService,SalesDocumentRenderQueueService,LeadQualificationService,CrmIdentityAuthorityService,CrmDuplicateReviewService,CrmMergeService,CrmInvoiceSettlementReferenceService,CrmCreditNoteService,CrmReceivablesService};
use App\Extensions\Crm\System\Automation\{CrmAutomationActionCatalog,CrmAutomationTriggerCatalog};
use App\Extensions\Crm\System\Governance\{CrmCommandReceiptFactory,CrmDomainInvariantGuard,CrmDomainSignalPublisher,CrmOptimisticConcurrencyGuard,CrmTenantReferenceGuard,CrmConcurrencyException};
use App\Extensions\Crm\System\ReadModels\{CrmAiReadModelService,CrmReadStorePort,CrmProjectionBuilder,CrmSearchPort,CrmProjectionDeadLetterStore};
use App\Extensions\Crm\System\Import\CrmImportBatchService;
use Illuminate\Support\Str;
use App\Extensions\Crm\System\Tenancy\{CrmCompanyAuthorizationGateway,CrmCompanyScope};
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;
use DomainException;
use Throwable;

/** Governed CRM action surface used by TitanAI, Interaction Engine, Mobile and future onboarding. */
final class CrmCapabilityExecutor
{
    public function __construct(
        private readonly CrmCapabilityRegistry $registry,
        private readonly CrmCompanyAuthorizationGateway $authorization,
        private readonly CrmCompanyScope $scope,
        private readonly CrmCapabilityOperationStore $operations,
        private readonly CrmDomainInvariantGuard $invariants,
        private readonly CrmTenantReferenceGuard $tenantReferences,
        private readonly CrmOptimisticConcurrencyGuard $concurrency,
        private readonly CrmCommandReceiptFactory $receipts,
        private readonly CrmDomainSignalPublisher $signals,
        private readonly CrmAiReadModelService $aiReadModels,
        private readonly CrmReadStorePort $readStore,
        private readonly CrmProjectionBuilder $projectionBuilder,
        private readonly CrmSearchPort $searchPort,
        private readonly CrmProjectionDeadLetterStore $projectionDeadLetters,
        private readonly CrmImportBatchService $imports,
        private readonly ConnectionInterface $db,
        private readonly ContactRepositoryContract $contacts,
        private readonly ActivityRepositoryContract $activities,
        private readonly NoteRepositoryContract $notes,
        private readonly TagRepositoryContract $tags,
        private readonly CustomFieldRepositoryContract $customFields,
        private readonly CompanyRepositoryContract $companies,
        private readonly LeadRepositoryContract $leads,
        private readonly LeadQualificationService $leadQualification,
        private readonly CrmIdentityAuthorityService $identityAuthority,
        private readonly CrmDuplicateReviewService $duplicateReviews,
        private readonly CrmMergeService $merges,
        private readonly DealRepositoryContract $deals,
        private readonly PipelineRepositoryContract $pipelines,
        private readonly CalendarRepositoryContract $calendar,
        private readonly ProjectRepositoryContract $projects,
        private readonly TaskRepositoryContract $tasks,
        private readonly CrmExternalDomainCapabilityBridge $externalDomains,
        private readonly SalesDocumentRepositoryContract $sales,
        private readonly SalesDocumentRevisionService $salesRevisions,
        private readonly SalesDocumentRenderQueueService $documentRenders,
        private readonly CrmPortalGrantService $portalGrants,
        private readonly CrmApiKeyService $apiKeys,
        private readonly CrmWebhookService $webhooks,
        private readonly CrmWebhookDispatcher $webhookDispatcher,
        private readonly CrmRecordShareService $recordShares,
        private readonly BusinessConfigurationService $business,
        private readonly CrmAuditRecorder $audit,
        private readonly CrmInvoiceSettlementReferenceService $invoiceSettlements,
        private readonly CrmCreditNoteService $creditNotes,
        private readonly CrmReceivablesService $receivables,
        private readonly CrmPrivacyService $privacy,
        private readonly CrmRetentionService $retention,
        private readonly SalesDocumentDeliveryService $salesDelivery,
        private readonly CrmNotificationOutboxService $notificationOutbox,
        private readonly CrmAutomationTriggerCatalog $automationTriggers,
        private readonly CrmAutomationActionCatalog $automationActions,
    ) {}

    public function execute(string $capability,array $input=[]): array
    {
        $definition=$this->registry->definition($capability);
        $context=$this->authorization->authorize($definition['permission']);
        $idempotencyKey=trim((string)($input['idempotency_key']??$input['_context']['idempotency_key']??''));
        if($definition['mode']==='write' && $definition['idempotent'] && $idempotencyKey==='') throw new InvalidArgumentException("{$capability} requires an idempotency_key.");

        if($definition['mode']==='read'){
            $result=$this->dispatch($capability,$context->actorUserId??0,$input);
            if(!is_array($result))$result=['value'=>$result];
            return [
                'capability'=>$capability,'status'=>'ok','authoritative'=>true,'result'=>$result,
                'company_id'=>$context->companyId,'trace_id'=>$context->traceId!==''?$context->traceId:$context->correlationId,
                'correlation_id'=>$context->correlationId,'causation_id'=>$context->causationId,
            ];
        }

        $actor=$context->actorUserId??0;
        if($actor<=0) throw new \Illuminate\Auth\Access\AuthorizationException('CRM write capability requires a delegated accountable user actor.');
        $startedAt=hrtime(true);$reserved=false;

        try{
            return $this->db->transaction(function() use($definition,$context,$capability,$input,$idempotencyKey,$actor,$startedAt,&$reserved):array {
                if($definition['idempotent']){
                    $reservation=$this->operations->reserve($capability,$idempotencyKey,$input);
                    if($reservation['state']==='completed')return $this->duplicateEnvelope($capability,$context,$reservation['result']??[]);
                    if($reservation['state']==='processing'){
                        return [
                            'capability'=>$capability,'status'=>'processing','executed'=>false,'authoritative'=>false,'duplicate'=>true,'retryable'=>true,'result'=>[],
                            'company_id'=>$context->companyId,'trace_id'=>$context->traceId!==''?$context->traceId:$context->correlationId,
                            'correlation_id'=>$context->correlationId,'causation_id'=>$context->causationId,
                        ];
                    }
                    $reserved=$reservation['state']==='reserved';
                }

                // CRM Core owns company-scoped guards only for CRM Core storage. Extracted-domain
                // capabilities retain CRM authorization/idempotency/receipts, while their owning
                // extension is authoritative for storage references, invariants and concurrency.
                $externalOwned=$this->externalDomains->handles($capability);
                $expectedVersion=$input['expected_entity_version']??$input['expected_version']??$input['_context']['expected_entity_version']??$input['_context']['expected_version']??null;
                if(!$externalOwned){
                    $this->tenantReferences->assertInput($capability,$input);
                }
                $before=$externalOwned ? null : $this->concurrency->snapshot($capability,$input);
                if(!$externalOwned)$this->invariants->assertBefore($capability,$input,$before);
                $invariantResults=$externalOwned?[
                    ['name'=>'crm.external_owner_storage_guards','status'=>'delegated','capability'=>$capability,'owner'=>'external'],
                ]:[
                    ['name'=>'crm.tenant_reference_guard','status'=>'passed','capability'=>$capability],
                    ['name'=>'crm.optimistic_concurrency','status'=>$before!==null?'passed':'not_applicable','expected_entity_version'=>$expectedVersion,'entity_version_before'=>$before['entity_version']??null],
                    ['name'=>'crm.domain.preconditions','status'=>'passed','capability'=>$capability],
                ];

                $result=$this->dispatch($capability,$actor,$input);
                if(!is_array($result))$result=['value'=>$result];
                $after=$externalOwned ? null : $this->concurrency->advance($capability,$input,$result,$before);
                $durationMs=max(0,(int)round((hrtime(true)-$startedAt)/1_000_000));
                $signalId=$this->signals->newMutationReference();
                $receipt=$this->receipts->make($capability,$input,$result,$context,$before,$after,[
                    'command_duration_ms'=>$durationMs,
                    'affected_count'=>$result['affected_count']??null,
                    'affected_resources'=>$result['affected_resources']??[],
                    'invariant_results'=>$invariantResults,
                    'signal_references'=>[['type'=>'crm_domain_signal_outbox','public_id'=>$signalId]],
                    'compensation_state'=>isset($result['outbox_public_id'])||isset($result['delivery']['outbox_public_id'])?'external_owner':'available',
                ]);
                [$resourceType,$resourceId]=[$receipt['resource_type']??null,$receipt['resource_id']??null];
                $outboxPublicId=(string)($result['outbox_public_id']??($result['delivery']['outbox_public_id']??''));
                if($outboxPublicId!==''){
                    $effectIntent=$this->notificationOutbox->attachGovernance($actor,$outboxPublicId,$receipt);
                    $this->signals->recordExternalEffectLifecycle($effectIntent,'queued',[]);
                }

                $signalId=$this->signals->recordMutation($capability,$result,$receipt,$context,$signalId);
                if($definition['idempotent'])$this->operations->completed($capability,$idempotencyKey,$result,$resourceType,$resourceId,$receipt);
                $this->audit->record($actor,$actor,'capability.'.$capability,$resourceType,$resourceId,$before['state']??null,$after['state']??$result,[
                    'company_id'=>$context->companyId,'actor_type'=>$context->actorType,'source_surface'=>$context->sourceSurface,
                    'trace_id'=>$receipt['trace_id'],'correlation_id'=>$receipt['correlation_id'],'causation_id'=>$receipt['causation_id'],
                    'command_id'=>$receipt['command_id'],'receipt_id'=>$receipt['receipt_id'],'rewind_reference'=>$receipt['rewind_reference'],
                    'expected_version'=>$expectedVersion,'capability'=>$capability,'command_duration_ms'=>$durationMs,
                ]);

                return [
                    'capability'=>$capability,'status'=>'ok','executed'=>true,'authoritative'=>true,'duplicate'=>false,'result'=>$result,
                    'receipt'=>$receipt,'rewind_reference'=>$receipt['rewind_reference'],'signal_outbox_id'=>$signalId,
                    'external_effect'=>$this->externalEffectState($actor,$result),
                    'company_id'=>$context->companyId,'trace_id'=>$receipt['trace_id'],'correlation_id'=>$receipt['correlation_id'],'causation_id'=>$receipt['causation_id'],
                ];
            });
        }catch(CrmConcurrencyException|DomainException|InvalidArgumentException $e){
            // The transaction has already rolled back here. Persist only deterministic rejection evidence afterwards.
            $rejection=$this->rejectionPayload($capability,$input,$e);
            if($reserved && $definition['idempotent'])$this->operations->rejected($capability,$idempotencyKey,$input,$rejection);
            $this->signals->recordRejection($capability,$rejection,$context,(string)($input['_context']['command_id']??$input['command_id']??''));
            throw $e;
        }
    }

    /** @param array<string,mixed> $stored @return array<string,mixed> */
    private function duplicateEnvelope(string $capability,object $context,array $stored): array
    {
        $domainResult=(array)($stored['result']??$stored);
        $receipt=(array)($stored['receipt']??[]);
        $actor=(int)($context->actorUserId??0);
        $externalEffect=$actor>0?$this->externalEffectState($actor,$domainResult):null;
        if(is_array($externalEffect)){
            $domainResult['delivery_status']=$externalEffect['delivery_status'];
            $domainResult['effect_status']=$externalEffect['effect_status'];
            $domainResult['provider']=$externalEffect['provider'];
            $domainResult['provider_message_id']=$externalEffect['provider_message_id'];
            $domainResult['provider_status']=$externalEffect['provider_status'];
        }
        return [
            'capability'=>$capability,'status'=>'ok','executed'=>true,'authoritative'=>true,'duplicate'=>true,'result'=>$domainResult,
            'receipt'=>$receipt,'rewind_reference'=>$stored['rewind_reference']??($receipt['rewind_reference']??null),'external_effect'=>$externalEffect,
            'company_id'=>$context->companyId,'trace_id'=>$receipt['trace_id']??($context->traceId!==''?$context->traceId:$context->correlationId),
            'correlation_id'=>$receipt['correlation_id']??$context->correlationId,'causation_id'=>$receipt['causation_id']??$context->causationId,
        ];
    }

    private function dispatch(string $c,int $actor,array $i): array
    {
        if($this->externalDomains->handles($c)) return $this->externalDomains->execute($c,$actor,$i);
        return match($c){
            'crm.company.context.read'=>$this->scope->current()->toArray(),
            'crm.ai.context.read'=>$this->aiReadModels->context($i),
            'crm.query.projection.status'=>['projections'=>$this->readStore->status($this->scope->current()->companyId,isset($i['projection_name'])?(string)$i['projection_name']:null)],
            'crm.query.projection.rebuild'=>!empty($i['incremental'])&&isset($i['projection_name'])?$this->projectionBuilder->rebuildProjectionIncremental($this->scope->current()->companyId,(string)$i['projection_name'],isset($i['batch_size'])?(int)$i['batch_size']:null):$this->projectionBuilder->rebuild($this->scope->current()->companyId,isset($i['projection_name'])&&trim((string)$i['projection_name'])!==''?(string)$i['projection_name']:null),
            'crm.query.projection.dead_letters'=>['dead_letters'=>$this->projectionDeadLetters->search($this->scope->current()->companyId,(array)($i['filters']??$i))],
            'crm.query.projection.dead_letter.retry'=>$this->projectionDeadLetters->requestRetry($this->scope->current()->companyId,$this->requiredId($i)),
            'crm.search'=>$this->searchPort->search($this->scope->current()->companyId,(string)($i['query']??''),(array)($i['projections']??[]),(int)($i['limit']??25)),
            'crm.customer.search'=>$this->contacts->search($actor,(array)($i['filters']??$i)),
            'crm.customer.read'=>$this->readByPublicId('crm_contacts',$this->requiredId($i)),
            'crm.customer.create'=>$this->createCustomer($actor,$i),
            'crm.customer.update'=>$this->updateCustomer($actor,$i),
            'crm.contact.search'=>$this->contacts->search($actor,(array)($i['filters']??$i)),
            'crm.contact.read'=>$this->readByPublicId('crm_contacts',$this->requiredId($i)),
            'crm.contact.create'=>$this->contacts->create($actor,$i),
            'crm.contact.update'=>$this->contacts->update($actor,$this->requiredId($i),$i),
            'crm.customer.identity.resolve'=>$this->identityAuthority->resolveByIdentity($actor,$i['email']??null,$i['phone']??null,$i['provider']??null,$i['external_identity_id']??null),
            'crm.external_identity.link'=>$this->identityAuthority->linkExternalIdentity($actor,(string)($i['customer_unification_id']??''),(string)($i['provider']??''),(string)($i['external_identity_id']??''),$i['subject_type']??null,$i['subject_public_id']??null,(array)($i['metadata']??[])),
            'crm.duplicate.review.search'=>['reviews'=>$this->duplicateReviews->search($actor,(array)($i['filters']??$i))],
            'crm.duplicate.review.resolve'=>$this->duplicateReviews->resolve($actor,$this->requiredId($i),$actor,(string)($i['decision']??''),(array)($i['resolution']??[])),
            'crm.record.merge.preview'=>$this->merges->preview($actor,(string)($i['resource']??''),(string)($i['winner_public_id']??''),(string)($i['loser_public_id']??'')),
            'crm.company.search'=>$this->companies->search($actor,(array)($i['filters']??$i)),
            'crm.company.create'=>$this->companies->create($actor,$i),
            'crm.company.update'=>$this->companies->update($actor,$this->requiredId($i),$i),
            'crm.lead.search'=>$this->leads->search($actor,(array)($i['filters']??$i)),
            'crm.lead.create'=>$this->leads->create($actor,$actor,$i),
            'crm.lead.update'=>$this->leads->update($actor,$this->requiredId($i),$actor,$i),
            'crm.lead.convert'=>$this->leads->convert($actor,$this->requiredId($i),$actor),
            'crm.lead.qualify'=>$this->leadQualification->qualify($actor,$this->requiredId($i),$actor,$i),
            'crm.deal.create'=>$this->deals->create($actor,$actor,$i),
            'crm.deal.update'=>$this->deals->update($actor,$this->requiredId($i),$actor,$i),
            'crm.deal.move'=>$this->deals->move($actor,$this->requiredId($i),$actor,$i),
            'crm.deal.win'=>$this->deals->markWon($actor,$this->requiredId($i),$actor),
            'crm.deal.lose'=>$this->deals->markLost($actor,$this->requiredId($i),$actor,(string)($i['reason']??'Not specified')),
            'crm.pipeline.create'=>$this->pipelines->create($actor,$i),
            'crm.form_response.update'=>$this->forms->saveResponse($actor,(string)($i['submission_public_id']??''),(string)($i['field_public_id']??''),$i['value']??null,(bool)($i['failed']??false),$i['failure_notes']??null),
            'crm.calendar.create'=>$this->calendar->create($actor,$i),
            'crm.quote.search'=>$this->searchQuotes($i),
            'crm.quote.read'=>$this->readQuote($actor,$i),
            'crm.quote.create'=>$this->createQuote($actor,$i),
            'crm.estimate.create'=>$this->sales->create($actor,'estimates',array_merge($i,['type'=>'estimates','status'=>'draft'])),
            'crm.quote.prepare'=>$this->sales->create($actor,(string)($i['type']??'estimates'),array_merge($i,['status'=>'draft'])),
            'crm.quote.approve'=>$this->sales->transition($actor,(string)($i['type']??'estimates'),$this->requiredId($i),'accepted',$i),
            'crm.quote.transition'=>$this->sales->transition($actor,(string)($i['type']??'estimates'),$this->requiredId($i),(string)($i['status']??throw new InvalidArgumentException('Quote status is required.')),$i),
            'crm.quote.expire'=>$this->sales->transition($actor,(string)($i['type']??'estimates'),$this->requiredId($i),'expired',$i),
            'crm.quote.withdraw'=>$this->sales->transition($actor,(string)($i['type']??'estimates'),$this->requiredId($i),'withdrawn',$i),
            'crm.quote.revise'=>$this->salesRevisions->createRevision($actor,(string)($i['type']??'estimates'),$this->requiredId($i),$i),
            'crm.quote.revisions'=>$this->salesRevisions->revisions($actor,(string)($i['type']??'estimates'),$this->requiredId($i)),
            'crm.quote.send'=>$this->sendQuote($actor,$i),
            'crm.document.render.request'=>$this->documentRenders->request($actor,(string)($i['type']??'estimates'),(string)($i['document_public_id']??$this->requiredId($i)),(string)($i['idempotency_key']??'')),
            'crm.document.render.status'=>$this->documentRenders->status($actor,(string)($i['job_public_id']??$this->requiredId($i))),
            'crm.invoice.read'=>$this->readSales($actor,'invoices',$this->requiredId($i)),
            'crm.invoice.status'=>$this->invoiceStatus($actor,$this->requiredId($i)),
            'crm.invoice.create'=>$this->createInvoice($actor,$i),
            'crm.invoice.issue'=>$this->issueInvoice($actor,$i),
            'crm.invoice.transition'=>$this->sales->transition($actor,'invoices',$this->requiredId($i),(string)($i['status']??throw new InvalidArgumentException('Invoice status is required.'))),
            'crm.invoice.send'=>$this->sendInvoice($actor,$i,false),
            'crm.invoice.reminder.send'=>$this->sendInvoice($actor,$i,true),
            'crm.invoice.settlement.record_verified'=>$this->invoiceSettlements->recordVerified($actor,$i),
            'crm.invoice.settlement.references'=>['references'=>$this->receivables->references($actor,(string)($i['invoice_public_id']??$this->requiredId($i)))],
            'crm.receivables.aging.read'=>$this->receivables->aging($actor,isset($i['as_of'])?(string)$i['as_of']:null),
            'crm.receivables.reconciliation_issues.read'=>['issues'=>$this->receivables->reconciliationIssues($actor,(array)($i['filters']??$i))],
            'crm.receivables.reconciliation_issue.resolve'=>$this->receivables->resolveIssue($actor,(string)($i['issue_public_id']??$this->requiredId($i)),(string)($i['resolution_notes']??'')),
            'crm.credit_note.create'=>$this->creditNotes->create($actor,(string)($i['invoice_public_id']??$this->requiredId($i)),$i),
            'crm.credit_note.issue'=>$this->creditNotes->issue($actor,$this->requiredId($i)),
            'crm.credit_note.void'=>$this->creditNotes->void($actor,$this->requiredId($i),(string)($i['reason']??'')),
            'crm.credit_note.read'=>$this->creditNotes->read($actor,$this->requiredId($i)),
            'crm.import.report'=>$this->imports->report($actor,(string)($i['batch_public_id']??$this->requiredId($i))),
            'crm.activity.create'=>$this->activities->create($actor,$actor,$i),
            'crm.note.create'=>$this->notes->create($actor,$actor,$i),
            'crm.tag.create'=>$this->tags->create($actor,$i),
            'crm.tag.attach'=>$this->attachTag($actor,$i),
            'crm.custom_field.create'=>$this->customFields->createDefinition($actor,$i),
            'crm.api_key.create'=>$this->createApiKey($actor,$i),
            'crm.webhook.create'=>$this->createWebhook($actor,$i),
            'crm.webhook.dispatch'=>$this->dispatchWebhook($actor,$i),
            'crm.share.create'=>$this->recordShares->grant($actor,(string)($i['subject_type']??''),(string)($i['subject_public_id']??''),(int)($i['grantee_user_id']??0),(array)($i['permissions']??['view']),$i['expires_at']??null),
            'crm.privacy.request'=>$this->privacy->request($actor,$actor,(string)($i['request_type']??''),(string)($i['subject_type']??''),$i['subject_public_id']??null,$i['subject_email']??null,(bool)($i['dry_run']??true)),
            'crm.retention.policy.update'=>$this->retention->set($actor,(string)($i['resource_type']??''),(int)($i['retention_days']??0),(string)($i['action']??'review')),
            'crm.retention.execute'=>$this->retention->executeDue($actor,(string)($i['resource_type']??''),(int)($i['limit']??100),(bool)($i['confirmed']??false)),
            'crm.settings.business.read'=>$this->businessSettings($actor),
            'crm.portal.grant.create'=>$this->createPortalGrant($actor,$i),
            'crm.project.create'=>$this->projects->create($actor,$i),
            'crm.task.create'=>$this->tasks->create($actor,$i),
            'crm.task.status.update'=>$this->tasks->updateStatus($actor,$this->requiredId($i),(string)($i['status']??throw new InvalidArgumentException('Task status is required.'))),
            'crm.notification.queue'=>$this->queueNotification($actor,$i),
            'crm.automation.create'=>$this->createAutomation($actor,$i),
            'crm.owner.dashboard.read'=>$this->ownerDashboard(),
            'crm.business.profile.read'=>$this->business->profile($actor),
            'crm.business.profile.update'=>$this->business->updateProfile($actor,$i),
            'crm.business.hours.read'=>$this->business->hours($actor),
            'crm.business.hours.update'=>$this->business->updateHours($actor,$i),
            'crm.business.service.read'=>$this->business->service($actor,$this->requiredId($i))??[],
            'crm.business.service.create'=>$this->business->createService($actor,$i),
            'crm.business.service.update'=>$this->business->updateService($actor,$this->requiredId($i),$i),
            'crm.business.location.create'=>$this->business->createLocation($actor,$i),
            'crm.business.location.update'=>$this->business->updateLocation($actor,$this->requiredId($i),$i),
            'crm.business.service_area.update'=>$this->business->updateServiceArea($actor,$i),
            'crm.business.booking_rules.read'=>$this->business->readSetting($actor,'business.booking_rules'),
            'crm.business.booking_rules.update'=>$this->business->updateSetting($actor,'business.booking_rules',$i),
            'crm.business.pricing.read'=>$this->business->readSetting($actor,'business.pricing'),
            'crm.business.pricing.update'=>$this->business->updateSetting($actor,'business.pricing',$i),
            'crm.business.staff.invite'=>$this->business->inviteStaff($actor,$i),
            'crm.business.staff.role.assign'=>$this->business->assignStaffRole($actor,$i),
            'crm.business.field_rules.read'=>$this->business->readSetting($actor,'business.field_rules'),
            'crm.business.field_rules.update'=>$this->business->updateSetting($actor,'business.field_rules',$i),
            'crm.business.notification_defaults.update'=>$this->business->updateSetting($actor,'business.notification_defaults',$i),
            'crm.business.invoice_settings.update'=>$this->business->updateSetting($actor,'business.invoice_settings',$i),
            default=>$this->dispatchRegistered($c,$i),
        };
    }

    private function dispatchRegistered(string $capability,array $input): array
    { $handler=$this->registry->handler($capability);$result=$handler($input,$this->scope->current());return is_array($result)?$result:['value'=>$result]; }

    private function attachTag(int $actor,array $input): array
    {
        $tag=$this->requiredId($input);
        $subjectType=trim((string)($input['subject_type']??''));
        $subjectPublicId=trim((string)($input['subject_public_id']??''));
        if($subjectType===''||$subjectPublicId==='')throw new InvalidArgumentException('Tag attachment requires subject_type and subject_public_id.');
        $this->tags->attach($actor,$tag,$subjectType,$subjectPublicId);
        return ['public_id'=>$tag,'subject_type'=>$subjectType,'subject_public_id'=>$subjectPublicId,'attached'=>true];
    }

    private function queueNotification(int $actor,array $input): array
    {
        $channel=trim((string)($input['channel']??'in_app'));
        $template=trim((string)($input['template_key']??'crm.automation'));
        $idempotency=trim((string)($input['idempotency_key']??$input['_context']['idempotency_key']??''));
        if($idempotency==='')throw new InvalidArgumentException('Governed notification requires idempotency_key.');
        return $this->notificationOutbox->enqueueGoverned(
            $actor,$channel,$template,$input['recipient']??null,(array)($input['payload']??$input),
            $input['subject_type']??null,$input['subject_public_id']??null,$idempotency,
            ['trace_id'=>$this->scope->current()->traceId,'correlation_id'=>$this->scope->current()->correlationId,'causation_id'=>$this->scope->current()->causationId]
        );
    }

    private function dispatchWebhook(int $actor,array $input): array
    {
        $eventKey=trim((string)($input['event_key']??''));
        if($eventKey==='')throw new InvalidArgumentException('Webhook event_key is required.');
        return ['public_id'=>(string)($input['public_id']??Str::ulid()),'deliveries'=>$this->webhookDispatcher->dispatch($actor,$eventKey,(array)($input['payload']??[]))];
    }

    private function rejectionPayload(string $capability,array $input,Throwable $error): array
    {
        $base=[
            'message'=>$error->getMessage(),'resource_type'=>$input['resource_type']??null,
            'resource_id'=>$input['public_id']??$input['resource_id']??$input['invoice_public_id']??$input['work_order_public_id']??null,
            'retryable'=>false,'remediation_suggestion'=>'Refresh the authoritative CRM state, correct the request, and retry with a new command if appropriate.',
        ];
        if($error instanceof CrmConcurrencyException)return array_merge($base,$error->context(),['rejection_type'=>'concurrency']);
        if($error instanceof DomainException){
            $base['rejection_type']='domain_invariant';
            $base['invariant_id']='crm.'.str_replace('.','_',preg_replace('/[^a-z0-9_.]+/','_',strtolower($capability))).'.invariant';
        }else $base['rejection_type']='validation';
        return $base;
    }

    private function createApiKey(int $actor,array $input): array
    {
        $label=trim((string)($input['label']??''));if($label==='')throw new InvalidArgumentException('API key label is required.');
        $issued=$this->apiKeys->issue($actor,$label,(array)($input['scopes']??['crm.read']),$input['expires_at']??null,null,(array)($input['allowed_ip_cidrs']??[]));
        $key=(array)($issued['api_key']??[]);return ['public_id'=>$key['public_id']??null,'api_key'=>$key,'secret'=>$issued['secret']??null];
    }

    private function createWebhook(int $actor,array $input): array
    {
        $name=trim((string)($input['name']??''));$url=trim((string)($input['url']??''));if($name===''||$url==='')throw new InvalidArgumentException('Webhook name and URL are required.');
        $created=$this->webhooks->create($actor,['name'=>$name,'url'=>$url,'events'=>(array)($input['events']??['*'])]);
        $hook=(array)($created['webhook']??[]);return ['public_id'=>$hook['public_id']??null,'webhook'=>$hook,'secret'=>$created['secret']??null];
    }

    private function createAutomation(int $actor,array $input): array
    {
        $name=trim((string)($input['name']??''));$trigger=trim((string)($input['trigger_key']??''));
        if($name===''||$trigger==='')throw new InvalidArgumentException('Automation name and trigger_key are required.');
        $this->automationTriggers->assertValid($trigger);$actions=(array)($input['actions']??[]);if($actions===[])throw new InvalidArgumentException('Automation requires at least one action.');
        foreach($actions as $definition){if(!is_array($definition))throw new InvalidArgumentException('Each automation action must be an object.');$this->automationActions->assertValid((string)($definition['action']??''));}
        $publicId=(string)Str::ulid();$this->db->table('crm_automation_rules')->insert([
            'public_id'=>$publicId,'company_id'=>CrmCompanyScope::companyId($actor),'user_id'=>CrmCompanyScope::actorUserId($actor),'name'=>$name,
            'enabled'=>(bool)($input['enabled']??true),'trigger_key'=>$trigger,'conditions'=>json_encode((array)($input['conditions']??[])),'actions'=>json_encode($actions),
            'cooldown_seconds'=>(int)($input['cooldown_seconds']??0),'created_at'=>now(),'updated_at'=>now(),
        ]);
        return (array)$this->db->table('crm_automation_rules')->where('company_id',CrmCompanyScope::companyId($actor))->where('public_id',$publicId)->first();
    }

    private function sendInvoice(int $actor,array $input,bool $reminder):array
    {
        $id=(string)($input['invoice_public_id']??$this->requiredId($input));
        $tenant=$this->scope->current()->companyId;
        $invoice=$this->db->table('crm_invoices')->where('company_id',$tenant)->where('public_id',$id)->whereNull('deleted_at')->first();
        if(!$invoice)throw new InvalidArgumentException('CRM invoice not found.');
        $status=(string)$invoice->status;
        if(in_array($status,['paid','void','voided','cancelled'],true))throw new InvalidArgumentException('This invoice cannot be sent in its current status.');
        if($reminder){
            if($invoice->due_at===null||now()->lte(\Illuminate\Support\Carbon::parse((string)$invoice->due_at)))throw new InvalidArgumentException('Invoice reminders require an overdue invoice.');
        }elseif($status==='draft'){
            throw new InvalidArgumentException('Issue the invoice before sending it.');
        }
        $recipient=trim((string)($input['email']??$input['recipient']??''));
        if($recipient==='')$recipient=$this->invoiceRecipient($tenant,(array)$invoice);
        if($recipient==='')throw new InvalidArgumentException('No customer email is available for this invoice.');
        $commandKey=trim((string)($input['idempotency_key']??$input['_context']['idempotency_key']??''));
        if($commandKey==='')throw new InvalidArgumentException('Invoice delivery requires an idempotency_key.');
        $purpose=$reminder?'crm.invoice.reminder.send':'crm.invoice.send';
        $effectKey=hash('sha256',$purpose.'|'.$commandKey);
        $governance=[
            'trace_id'=>$input['_context']['trace_id']??$input['trace_id']??null,
            'correlation_id'=>$input['_context']['correlation_id']??$input['correlation_id']??null,
            'causation_id'=>$input['_context']['causation_id']??$input['causation_id']??null,
            'command_id'=>$input['_context']['command_id']??$input['command_id']??null,
        ];
        $render=$this->documentRenders->request($actor,'invoices',$id,$commandKey.':render');
        $governance['render_job_public_id']=$render['public_id']??null;
        $delivery=$reminder
            ?$this->salesDelivery->sendReminderEmail($actor,$id,$recipient,$effectKey,$governance)
            :$this->salesDelivery->sendEmail($actor,'invoices',$id,$recipient,$effectKey,$governance);
        return [
            'invoice_public_id'=>$id,'recipient'=>$recipient,'render_job'=>$render,'delivery'=>$delivery,'reminder'=>$reminder,
            'outbox_public_id'=>$delivery['outbox_public_id']??null,'effect_status'=>$delivery['effect_status']??'queued',
            'delivery_status'=>$delivery['delivery_status']??'pending','delivery_receipt_required'=>true,
        ];
    }

    private function invoiceRecipient(int $tenant,array $invoice):string { return $this->salesRecipient($tenant,$invoice); }

    private function ownerDashboard():array
    {
        $tenant=$this->scope->current()->companyId;$status=$this->readStore->status($tenant,'owner_dashboard');
        if($status===[]&&(bool)config('crm.read_store.bootstrap_on_miss',true))$this->projectionBuilder->rebuildProjection($tenant,'owner_dashboard');
        $rows=$this->readStore->query($tenant,'owner_dashboard','1.0',[],null,1);$row=$rows[0]??[];unset($row['public_id']);
        return $row+['projection_status'=>($this->readStore->status($tenant,'owner_dashboard')[0]??null),'source'=>'crm_read_store'];
    }
    private function createPortalGrant(int $actor,array $input):array
    {
        $issued=$this->portalGrants->issue($actor,$input);
        $grant=(array)($issued['grant']??[]);
        return ['public_id'=>$grant['public_id']??null,'grant'=>$grant,'token'=>$issued['token']??null,'verification_code'=>$issued['verification_code']??null];
    }

    private function updateCustomer(int $actor,array $input):array
    {
        $kind=strtolower(trim((string)($input['customer_kind']??$input['customer_type']??'individual')));$id=$this->requiredId($input);
        if(in_array($kind,['business','company','account'],true))return $this->companies->update($actor,$id,$input);
        return $this->contacts->update($actor,$id,$input);
    }

    private function createCustomer(int $actor,array $input):array
    {
        $type=strtolower(trim((string)($input['customer_type']??'individual')));
        if(!in_array($type,['individual','business'],true))throw new InvalidArgumentException('Customer type must be individual or business.');
        if($type==='business'){
            $name=trim((string)($input['company_name']??$input['name']??''));
            if($name==='')throw new InvalidArgumentException('Business name is required.');
            $company=$this->companies->create($actor,[
                'name'=>$name,'email'=>$input['email']??null,'phone'=>$input['phone']??null,
                'address'=>$input['address']??null,'notes'=>$input['notes']??null,
            ]);
            $contact=null;
            $first=trim((string)($input['first_name']??''));
            if($first!=='' || !empty($input['email']) || !empty($input['phone'])){
                $contact=$this->contacts->create($actor,[
                    'company_public_id'=>$company['public_id'],'first_name'=>$first!==''?$first:$name,
                    'last_name'=>$input['last_name']??null,'email'=>$input['email']??null,'phone'=>$input['phone']??null,
                    'is_primary'=>true,'meta'=>['address'=>$input['address']??null,'notes'=>$input['notes']??null],
                ]);
            }
            return ['public_id'=>$company['public_id'],'customer_type'=>'business','company'=>$company,'contact'=>$contact];
        }
        $first=trim((string)($input['first_name']??''));
        if($first==='')throw new InvalidArgumentException('First name is required for an individual customer.');
        $contact=$this->contacts->create($actor,[
            'first_name'=>$first,'last_name'=>$input['last_name']??null,'email'=>$input['email']??null,'phone'=>$input['phone']??null,
            'meta'=>['address'=>$input['address']??null,'notes'=>$input['notes']??null],
        ]);
        return ['public_id'=>$contact['public_id'],'customer_type'=>'individual','contact'=>$contact];
    }

    private function sendQuote(int $actor,array $input): array
    {
        $type=(string)($input['type']??'estimates');
        if(!in_array($type,['proposals','estimates'],true))throw new InvalidArgumentException('Quote type must be proposals or estimates.');
        $document=$this->readSales($actor,$type,$this->requiredId($input));
        if(!in_array((string)($document['status']??''),['sent'],true))throw new DomainException('Only sent quotes/estimates may be queued for customer delivery.');
        $recipient=trim((string)($input['email']??$input['recipient']??''));
        if($recipient==='')$recipient=$this->salesRecipient($this->scope->current()->companyId,$document);
        if($recipient===''||!filter_var($recipient,FILTER_VALIDATE_EMAIL))throw new DomainException('CRM could not resolve a valid customer email for this quote.');
        $commandKey=(string)($input['idempotency_key']??'');
        $render=$this->documentRenders->request($actor,$type,(string)$document['public_id'],$commandKey.':render');
        $delivery=$this->salesDelivery->sendEmail($actor,$type,(string)$document['public_id'],$recipient,$commandKey,['render_job_public_id'=>$render['public_id']??null]);
        return ['public_id'=>$document['public_id'],'recipient'=>$recipient,'render_job'=>$render,'delivery'=>$delivery,'outbox_public_id'=>$delivery['outbox_public_id']??null,'effect_status'=>$delivery['effect_status']??'queued','delivery_receipt_required'=>true];
    }

    private function salesRecipient(int $tenant,array $document): string
    {
        $contact=(string)($document['contact_public_id']??'');
        if($contact!==''){ $email=$this->db->table('crm_contacts')->where('company_id',$tenant)->where('public_id',$contact)->value('email'); if(is_string($email)&&filter_var($email,FILTER_VALIDATE_EMAIL))return $email; }
        $company=(string)($document['company_public_id']??'');
        if($company!==''){ $email=$this->db->table('crm_companies')->where('company_id',$tenant)->where('public_id',$company)->value('email'); if(is_string($email)&&filter_var($email,FILTER_VALIDATE_EMAIL))return $email; }
        return '';
    }

    private function createQuote(int $actor,array $input):array
    {
        $type=(string)($input['type']??'proposals');
        if(!in_array($type,['proposals','estimates'],true))throw new InvalidArgumentException('Quote type must be proposals or estimates.');
        return $this->sales->create($actor,$type,array_merge($input,['status'=>'draft']));
    }
    private function createInvoice(int $actor,array $input):array
    {
        $invoice=$this->sales->create($actor,'invoices',$input+['status'=>'draft']);
        if((bool)($input['issue_now']??$input['send_to_customer']??false))return $this->sales->transition($actor,'invoices',(string)$invoice['public_id'],'issued');
        return $invoice;
    }
    private function issueInvoice(int $actor,array $input):array{ $id=(string)($input['invoice_public_id']??$this->requiredId($input)); return $this->sales->transition($actor,'invoices',$id,'issued',$input); }
    private function readQuote(int $actor,array $i):array{$type=(string)($i['type']??'estimates');if(!in_array($type,['proposals','estimates'],true))throw new InvalidArgumentException('Quote type must be proposals or estimates.');return $this->readSales($actor,$type,$this->requiredId($i));}
    private function readSales(int $actor,string $type,string $id):array{$row=$this->db->table('crm_'.$type)->where('company_id',$this->scope->current()->companyId)->where('public_id',$id)->whereNull('deleted_at')->first();if(!$row)throw new InvalidArgumentException('CRM sales record not found.');return (array)$row;}
    private function invoiceStatus(int $actor,string $id):array{$r=$this->readSales($actor,'invoices',$id);return ['public_id'=>$r['public_id'],'status'=>$r['status'],'total_minor'=>(int)$r['total_minor'],'paid_minor'=>(int)($r['paid_minor']??0),'refunded_minor'=>(int)($r['refunded_minor']??0),'refund_due_minor'=>(int)($r['refund_due_minor']??0),'credited_minor'=>(int)($r['credited_minor']??0),'outstanding_minor'=>(int)($r['balance_minor']??0),'receivable_state'=>$r['receivable_state']??null,'payment_state'=>$r['payment_state']??null,'reconciliation_status'=>$r['reconciliation_status']??null,'source_quote_public_id'=>$r['source_quote_public_id']??null,'source_work_order_public_id'=>$r['source_work_order_public_id']??null,'issued_snapshot_hash'=>$r['issued_snapshot_hash']??null,'settlement_references'=>$this->receivables->references($actor,$id)];}
    private function listTable(string $table,array $input,string $orderColumn):array
    {
        $limit=max(1,min(200,(int)($input['limit']??100)));
        $q=$this->db->table($table)->where('company_id',$this->scope->current()->companyId);
        if($this->hasColumn($table,'deleted_at'))$q->whereNull('deleted_at');
        foreach((array)($input['filters']??[]) as $column=>$value){
            if(!is_string($column)||!preg_match('/^[a-z0-9_]+$/i',$column)||in_array($column,['company_id','user_id'],true))continue;
            if($this->hasColumn($table,$column)&&is_scalar($value))$q->where($column,$value);
        }
        if($this->hasColumn($table,$orderColumn))$q->orderByDesc($orderColumn);
        return $q->limit($limit)->get()->map(fn($r)=>(array)$r)->all();
    }
    private function searchQuotes(array $i):array
    {
        $type=(string)($i['type']??'estimates');
        if(!in_array($type,['proposals','estimates'],true))throw new InvalidArgumentException('Quote type must be proposals or estimates.');
        return $this->listTable('crm_'.$type,$i,'created_at');
    }
    private function businessSettings(int $actor):array
    {
        $out=['profile'=>$this->business->profile($actor),'hours'=>$this->business->hours($actor)];
        foreach(['booking_rules','pricing','field_rules','notification_defaults','invoice_settings'] as $key)$out[$key]=$this->business->readSetting($actor,'business.'.$key);
        return $out;
    }
    private function readByPublicId(string $table,string $id):array{$r=$this->db->table($table)->where('company_id',$this->scope->current()->companyId)->where('public_id',$id)->when($this->hasColumn($table,'deleted_at'),fn($q)=>$q->whereNull('deleted_at'))->first();if(!$r)throw new InvalidArgumentException('CRM resource not found.');return (array)$r;}
    private function requiredId(array $input):string{$id=trim((string)($input['public_id']??$input['id']??$input['resource_id']??''));if($id==='')throw new InvalidArgumentException('CRM resource public_id is required.');return $id;}
    private function resourceReference(array $r,array $i):array{$value=$r['result']??$r;$id=$value['public_id']??$value['record_id']??$i['public_id']??$i['id']??null;return [$i['resource_type']??null,$id!==null?(string)$id:null];}
    /** @return array<string,mixed>|null */
    private function externalEffectState(int $actor,array $result):?array
    {
        $publicId=trim((string)($result['outbox_public_id']??($result['delivery']['outbox_public_id']??'')));
        if($publicId==='')return null;
        $row=$this->notificationOutbox->find($actor,$publicId);
        if($row===[])return [
            'outbox_public_id'=>$publicId,'effect_status'=>'queued','delivery_status'=>'unknown',
            'provider'=>null,'provider_message_id'=>null,'provider_status'=>null,'delivery_receipt_required'=>true,
        ];
        $status=strtolower((string)($row['status']??'pending'));
        $effectStatus=in_array($status,['sent','delivered'],true)?'delivered':($status==='failed'?'failed':'queued');
        return [
            'outbox_public_id'=>$publicId,'effect_status'=>$effectStatus,'delivery_status'=>$status,
            'provider'=>$row['provider']??null,'provider_message_id'=>$row['provider_message_id']??null,
            'provider_status'=>$row['provider_status']??null,'delivery_receipt_required'=>!in_array($status,['sent','delivered'],true),
        ];
    }

    private function decode(mixed $v):array{if(is_array($v))return $v;if(!is_string($v)||$v==='')return [];return json_decode($v,true)?:[];}
    private function hasColumn(string $table,string $column):bool{try{return $this->db->getSchemaBuilder()->hasColumn($table,$column);}catch(\Throwable){return false;}}
}
