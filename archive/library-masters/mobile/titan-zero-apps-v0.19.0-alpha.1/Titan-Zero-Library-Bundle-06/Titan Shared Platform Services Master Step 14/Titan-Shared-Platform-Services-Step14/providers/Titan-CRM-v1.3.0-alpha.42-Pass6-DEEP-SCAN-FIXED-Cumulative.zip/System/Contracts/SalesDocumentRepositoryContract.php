<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Contracts;

interface SalesDocumentRepositoryContract
{
    public function search(int $userId,string $type,array $filters=[]): array;
    public function create(int $userId,string $type,array $data): array;
    public function transition(int $userId,string $type,string $publicId,string $toStatus,array $context=[]): array;
}
