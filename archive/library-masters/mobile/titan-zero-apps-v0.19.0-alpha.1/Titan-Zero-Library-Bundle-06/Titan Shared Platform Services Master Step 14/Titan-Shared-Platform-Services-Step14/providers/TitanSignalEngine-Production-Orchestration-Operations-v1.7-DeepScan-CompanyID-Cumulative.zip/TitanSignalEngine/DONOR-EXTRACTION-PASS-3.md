# Titan Signal Engine — Donor Extraction Pass 3

Source donor: `titan_signal(1).zip`.

This pass deliberately **rewrites concepts** rather than copying the donor runtime. The donor's mutable process tables, unauthenticated API assumptions, direct domain-table reads, approval logic, custom queue transport and `tz_*` persistence remain excluded.

## Extracted concepts

| Donor source | Useful concept | Titan v0.3.0 implementation |
|---|---|---|
| `ProcessStateMachine.php` | explicit expected process transitions | versioned `TraceProfile` required-event and ordering rules |
| `ProcessRecorder.php` | durable process reconstruction anchors | immutable event causation + `titan_signal_causal_edges` projection |
| `AuditTrail.php` | timeline reconstruction | `CorrelationService::trace()` / `workflow()` projections |
| `SignalsService::process()` | combined process/signals/timeline read model | tenant-safe trace/workflow projection with completeness analysis |
| `RewindSubscriber.php` | rewind anchor concept | `RewindCorrelationReceipt` using trace/correlation/root-causation identities |

## Explicitly rejected donor behavior

- no `tz_processes`, `tz_process_states`, `tz_signals`, `tz_signal_queue` or `tz_approval_queue`
- no mutable process state owned by Signal
- no direct `jobs` / `invoices` reads
- no caller-supplied approval actor
- no `updateOrInsert` mutation of historical Signal events
- no custom queue transport
- no donor namespace dependencies

The result preserves the donor's strongest reconstruction ideas while keeping the newer Titan Signal boundaries: immutable events are authoritative; graph edges and completeness results are projections only.
