<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\ReadModels;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use InvalidArgumentException;

/** AI/Workforce read facade. Alpha.32 is projection-only: no arbitrary OLTP fallback. */
final class CrmAiReadModelService
{
    /** @var array<string,string> */
    private const RESOURCE_PROJECTIONS=[
        'customer'=>'customer_summary','contact'=>'customer_summary','organization'=>'organization_summary','company'=>'organization_summary',
        'lead'=>'lead_summary','deal'=>'sales_pipeline','quote'=>'quote_context','estimate'=>'quote_context','proposal'=>'proposal_context',
        'invoice'=>'invoice_context','project'=>'project_summary','task'=>'task_summary','activity'=>'customer_timeline',
    ];

    public function __construct(
        private readonly CrmCompanyScope $scope,
        private readonly CrmAiProjectionRegistry $projections,
        private readonly CrmReadStorePort $readStore,
        private readonly CrmProjectionBuilder $builder,
    ) {}

    /** @return array<string,mixed> */
    public function context(array $input): array
    {
        $projectionName=strtolower(trim((string)($input['projection_name']??'')));
        if($projectionName!=='')return $this->projection($projectionName,(string)($input['projection_version']??''),$input);
        $resource=strtolower(trim((string)($input['resource']??$input['entity_type']??'')));
        if($resource==='')return $this->summary();
        $projection=self::RESOURCE_PROJECTIONS[$resource]??null;
        if($projection===null)throw new InvalidArgumentException('This CRM AI resource is not exposed through a normalized read projection.');
        return $this->projection($projection,(string)($input['projection_version']??''),$input,['resource_alias'=>$resource]);
    }

    /** @return array<string,mixed> */
    private function projection(string $name,string $version,array $input,array $extra=[]): array
    {
        $projection=$this->projections->resolve($name,$version!==''?$version:null);$tenant=$this->scope->current()->companyId;
        $this->bootstrapProjectionIfMissing($tenant,$projection);
        $allowed=array_fill_keys((array)$projection['filter_fields'],true);$filters=[];
        foreach((array)($input['filters']??[]) as $field=>$value){if(is_string($field)&&isset($allowed[$field])&&is_scalar($value))$filters[$field]=$value;}
        $publicId=trim((string)($input['public_id']??$input['entity_public_id']??''));$limit=max(1,min(50,(int)($input['limit']??20)));
        $records=$this->readStore->query($tenant,(string)$projection['projection_name'],(string)$projection['projection_version'],$filters,$publicId!==''?$publicId:null,$limit);
        return $this->projectionEnvelope($projection,$records,$this->firstStatus($tenant,(string)$projection['projection_name']),$extra);
    }

    /** @return array<string,mixed> */
    private function summary(): array
    {
        $tenant=$this->scope->current()->companyId;$projection=$this->projections->resolve('tenant_summary');$this->bootstrapProjectionIfMissing($tenant,$projection);
        $records=$this->readStore->query($tenant,'tenant_summary',(string)$projection['projection_version'],[],null,1);$record=$records[0]??[];unset($record['public_id'],$record['generated_at']);
        return ['source'=>'crm_read_store','authority'=>'projection_of_authoritative_operational_state','read_model'=>'crm.ai.context.read','read_model_version'=>'4.0','scope'=>'summary','counts'=>$record,'projection_status'=>$this->firstStatus($tenant,'tenant_summary'),'limits'=>['max_records_per_resource'=>50,'arbitrary_table_access'=>false,'oltp_fallback'=>false]];
    }

    private function bootstrapProjectionIfMissing(int $tenant,array $projection): void
    {
        $status=$this->readStore->status($tenant,(string)$projection['projection_name']);
        foreach($status as $row)if((string)($row['projection_version']??'')===(string)$projection['projection_version'])return;
        if(!(bool)config('crm.read_store.bootstrap_on_miss',true))return;
        $this->builder->rebuildProjection($tenant,(string)$projection['projection_name']);
    }
    /** @return array<string,mixed>|null */
    private function firstStatus(int $tenant,string $name): ?array{$rows=$this->readStore->status($tenant,$name);foreach($rows as $row)if(!(bool)($row['is_obsolete_version']??false))return $row;return $rows[0]??null;}
    /** @param array<string,mixed> $projection @param list<array<string,mixed>> $records */
    private function projectionEnvelope(array $projection,array $records,?array $status,array $extra=[]): array
    {return ['source'=>'crm_read_store','authority'=>'projection_of_authoritative_operational_state','read_model'=>'crm.ai.context.read','read_model_version'=>'4.0','projection_name'=>$projection['projection_name'],'projection_version'=>$projection['projection_version'],'schema_version'=>$projection['schema_version'],'definition_hash'=>$projection['definition_hash'],'resource'=>$projection['resource'],'records'=>$records,'count'=>count($records),'projection_status'=>$status,'limits'=>['max_records'=>50,'arbitrary_table_access'=>false,'relationship_ids_exposed'=>false,'entity_version_exposed'=>true,'oltp_fallback'=>false]]+$extra;}
}
