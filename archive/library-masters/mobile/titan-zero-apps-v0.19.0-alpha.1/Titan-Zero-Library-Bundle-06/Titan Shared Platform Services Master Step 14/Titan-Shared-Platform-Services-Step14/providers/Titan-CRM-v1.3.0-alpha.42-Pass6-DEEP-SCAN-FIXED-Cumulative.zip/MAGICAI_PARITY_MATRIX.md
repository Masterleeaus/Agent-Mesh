# MagicAI CRM Host Parity Matrix — v0.6.0

| MagicAI v11 host expectation | Recreated CRM status |
|---|---|
| `crm` marketplace register key | Implemented |
| `App\Extensions\Crm\System\CrmServiceProvider` | Implemented |
| `dashboard.user.crm.index` | Implemented |
| `dashboard.user.crm.ai.index` | Implemented |
| Contacts | Implemented |
| Companies | Implemented |
| Deals | Implemented |
| Projects | Implemented |
| Tasks | Implemented |
| Calendar | Implemented |
| Presentations | Implemented snapshot surface |
| Reports | Implemented |
| Invoices | Implemented CRM-sales foundation |
| Payments | Implemented with invoice allocation |
| Proposals | Implemented |
| Estimates | Implemented |
| `crmAssistant` generator type | Implemented |
| `crm-assistant` chat context | Implemented |
| `App\Extensions\Crm\System\Services\CrmAssistantChatService` | Implemented exact class/signature |
| `crm::assistant.includes.chat_area_container` | Implemented exact Blade namespace |
| `ContactCapturedEvent` integration | Implemented conditionally when host event exists |
| `ext_crm_dropdown` | Preserved |
| `ext_sales_dropdown` | Preserved |
| `crm_admin_settings` route target | Preserved |
| CRM Assistant action-card CSS hook | Implemented |
| WorkCore runtime dependency | None |
| MagicAI core modification required | None for extension runtime |

## Additional generic CRM capability beyond confirmed host surface

- leads and conversion
- qualification scoring
- duplicate merge
- notes/tags/custom fields
- unified timeline
- bounded import/export
- bulk actions
- audit log
- notification outbox
- deterministic sales line arithmetic
- partial-payment allocations
- pipeline drag/drop
