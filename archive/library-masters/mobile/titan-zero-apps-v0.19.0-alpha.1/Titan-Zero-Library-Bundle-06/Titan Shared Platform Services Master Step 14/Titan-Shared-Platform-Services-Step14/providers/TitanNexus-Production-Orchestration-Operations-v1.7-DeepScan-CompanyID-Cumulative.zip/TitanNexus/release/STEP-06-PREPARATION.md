# Step 06 Preparation — Existing-Install Upgrade Certification

Status: PACKAGE-SIDE UPGRADE PREFLIGHT PASS; LIVE UPGRADE NOT RUN.

This candidate adds a deterministic upgrade preflight for an existing Titan Nexus installation before any live migration is executed.

Package-side checks:
- Fresh-install package contract still passes.
- Packaged migration chain is strictly ordered.
- Full named route identities are unique.
- Nexus menu keys and legacy fallback route identities are unique.
- Provider singleton declarations are unique.

Installed-state checks when host facts are supplied:
- installed version must not be newer than target;
- `titan_nexus_compilations` must already exist;
- applied Nexus migrations must be an exact prefix of the packaged migration chain;
- unknown/out-of-order applied migrations block upgrade;
- duplicate compilation identities block upgrade before `000004` unique-key migration;
- duplicate menu, route or service registrations block upgrade;
- lifecycle table existence must agree with application of migration `000005`.

RC1 → RC2 expected pending migration sequence:
1. `2026_08_21_000004_add_nexus_compilation_concurrency_guards`
2. `2026_08_21_000005_create_titan_nexus_compilation_events_table`

The package-side preflight does not grant `UPGRADE_CERTIFIED`. The exact target ZIP must still be installed over the real prior Nexus installation on the MagicAI/Titan host, with backup, migration, provider boot, data-retention, duplicate-registration and second-boot evidence recorded.
