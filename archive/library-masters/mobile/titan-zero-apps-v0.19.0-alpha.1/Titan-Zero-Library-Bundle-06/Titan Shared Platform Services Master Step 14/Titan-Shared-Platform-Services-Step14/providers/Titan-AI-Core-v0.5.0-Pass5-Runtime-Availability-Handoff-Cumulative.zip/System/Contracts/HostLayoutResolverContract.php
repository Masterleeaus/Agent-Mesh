<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Contracts;

interface HostLayoutResolverContract
{
    public function resolve(): string;
}
