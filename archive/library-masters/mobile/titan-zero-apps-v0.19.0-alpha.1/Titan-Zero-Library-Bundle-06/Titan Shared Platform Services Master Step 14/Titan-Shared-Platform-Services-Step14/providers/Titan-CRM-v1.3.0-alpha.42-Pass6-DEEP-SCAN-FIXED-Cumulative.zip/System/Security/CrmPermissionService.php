<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Security;

use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

final class CrmPermissionService
{
    public function allows(int $userId, string $permission): bool
    {
        if (!in_array($permission, CrmPermissionCatalog::ALL, true)) return false;
        $actorId = auth()->id();
        if ($actorId !== null && (int)$actorId !== $userId) return false;
        if ((bool) config('crm.permissions.strict_host_gates', false)) {
            return Gate::has($permission) && Gate::allows($permission);
        }
        if (Gate::has($permission)) return Gate::allows($permission);
        return true; // company-scoped CRM records remain the baseline data boundary when the host defines no CRM gates.
    }

    public function authorize(int $userId, string $permission): void
    {
        if (!$this->allows($userId, $permission)) throw new AccessDeniedHttpException("CRM permission denied: {$permission}");
    }

    public function permissionForTool(string $tool): ?string
    {
        return CrmPermissionCatalog::TOOL_MAP[$tool] ?? null;
    }

    public function authorizeTool(int $userId, string $tool): void
    {
        $permission = $this->permissionForTool($tool);
        if ($permission === null) throw new AccessDeniedHttpException("CRM tool is not permission-mapped: {$tool}");
        $this->authorize($userId, $permission);
    }

    public function grantedPermissions(int $userId): array
    {
        return array_values(array_filter(CrmPermissionCatalog::ALL, fn(string $p): bool => $this->allows($userId, $p)));
    }
}
