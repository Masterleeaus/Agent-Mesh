<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Runtime;

use InvalidArgumentException;

final readonly class RewindQueueAdmission
{
    public function __construct(private int $softBacklog, private int $hardBacklog)
    {
        if ($softBacklog < 0 || $hardBacklog < 1 || $softBacklog >= $hardBacklog) throw new InvalidArgumentException('Invalid Rewind queue backpressure thresholds.');
    }

    public function evaluate(string $runtimeState, int $backlog): array
    {
        $state = RewindOperationalState::from($runtimeState);
        if (!$state->acceptsNewWork()) return ['allowed'=>false,'state'=>$state->value(),'backlog'=>$backlog,'reason'=>'runtime_'.strtolower($state->value())];
        if ($backlog >= $this->hardBacklog) return ['allowed'=>false,'state'=>'DEGRADED','backlog'=>$backlog,'reason'=>'hard_backpressure'];
        if ($backlog >= $this->softBacklog) return ['allowed'=>true,'state'=>'DEGRADED','backlog'=>$backlog,'reason'=>'soft_backpressure'];
        return ['allowed'=>true,'state'=>$state->value(),'backlog'=>$backlog,'reason'=>'accepted'];
    }
}
