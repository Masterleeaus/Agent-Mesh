<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Contracts;

interface GovernanceProjectionSinkContract
{
    public function record(int $tenantCompanyId, string $type, string $sourceEngine, string $status, array $payload, array $meta=[]): bool;

    /** @return list<array<string,mixed>> */
    public function recent(int $tenantCompanyId, string $type, int $limit=50): array;
}
