# Titan Onboarding

Titan Onboarding is a thin voice/chat/generated-UI PWA over Interaction Engine. The engine retains the existing Field/Home Services onboarding wizard: 121 source catalogue entries, 116 runtime questions, 16 sections and five admin/platform exclusions.

Question metadata owns destination provider/capability/group. `OnboardingPlanCompiler` converts validated answers into provider-specific actions with explicit dependency/order/readiness/idempotency metadata. Plans are stored by `company_id + plan_id`; current actor authority is rebuilt at execution time.

High-risk payment/workforce/access/communications/AI/integration/compliance/activation changes require grouped approval. Activation is last and is blocked while required dependencies or provider readiness are blocked.
