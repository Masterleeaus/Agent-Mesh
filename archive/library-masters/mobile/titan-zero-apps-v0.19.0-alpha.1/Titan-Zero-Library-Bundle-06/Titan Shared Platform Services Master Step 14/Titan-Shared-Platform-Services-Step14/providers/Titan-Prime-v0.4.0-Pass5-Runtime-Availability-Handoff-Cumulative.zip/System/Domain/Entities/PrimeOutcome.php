<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Entities;

use InvalidArgumentException;

final readonly class PrimeOutcome
{
    /**
     * @param array<string,int|float|string|bool|null> $metrics
     * @param list<string> $evidenceReferences
     */
    public function __construct(
        public string $outcomeId,
        public string $missionId,
        public string $outcomeCode,
        public string $summary,
        public bool $successful,
        public array $metrics = [],
        public array $evidenceReferences = [],
        public ?string $recordedAt = null,
    ) {
        if (trim($outcomeId) === '' || trim($missionId) === '' || trim($outcomeCode) === '' || trim($summary) === '') {
            throw new InvalidArgumentException('Outcome id, mission id, outcome code and summary are required.');
        }
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'outcome_id' => $this->outcomeId,
            'mission_id' => $this->missionId,
            'outcome_code' => $this->outcomeCode,
            'summary' => $this->summary,
            'successful' => $this->successful,
            'metrics' => $this->metrics,
            'evidence_references' => array_values($this->evidenceReferences),
            'recorded_at' => $this->recordedAt,
        ];
    }
}
