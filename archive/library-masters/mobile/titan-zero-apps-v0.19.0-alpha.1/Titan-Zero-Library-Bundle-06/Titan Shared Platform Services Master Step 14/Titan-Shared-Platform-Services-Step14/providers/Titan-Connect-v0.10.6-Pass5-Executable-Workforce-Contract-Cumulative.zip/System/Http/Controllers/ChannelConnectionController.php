<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyActorDirectory;
use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ChannelConnectionMember;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Extensions\TitanConnect\System\Providers\ProviderRegistry;
use App\Extensions\TitanConnect\System\Security\SensitivePayloadGuard;
use App\Extensions\TitanConnect\System\Services\MessagingAuditService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class ChannelConnectionController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly CompanyActorDirectory $actors,
        private readonly ChannelAccessPolicy $policy,
        private readonly ProviderRegistry $providers,
        private readonly MessagingAuditService $audit,
        private readonly SensitivePayloadGuard $sensitive,
    ) {
    }

    public function index(Request $request): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $connections = ChannelConnection::query()
            ->where('company_id', $companyId)
            ->whereHas('members', fn ($query) => $query->where('company_id', $companyId)->where('user_id', $actorId)->whereNull('left_at'))
            ->with(['members' => fn ($query) => $query->where('company_id', $companyId)->whereNull('left_at')])
            ->orderBy('provider')->orderBy('display_name')
            ->limit(5000)->get();
        return response()->json($connections);
    }

    public function store(Request $request): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->actors->assertUsersBelongToCompany($companyId, [$actorId]);
        $data = $request->validate([
            'provider' => ['required', 'string', 'max:40'],
            'display_name' => ['nullable', 'string', 'max:255'],
            'external_account_id' => ['nullable', 'string', 'max:191'],
            'settings' => ['nullable', 'array'],
        ]);
        $provider = strtolower(trim($data['provider']));
        $this->providers->get($provider);
        $this->sensitive->assertSafe(is_array($data['settings'] ?? null) ? $data['settings'] : [], 'settings');

        $connection = DB::transaction(function () use ($companyId, $actorId, $provider, $data): ChannelConnection {
            $connection = ChannelConnection::query()->create([
                'uuid' => (string) Str::uuid(),
                'company_id' => $companyId,
                'provider' => $provider,
                'display_name' => $data['display_name'] ?? ucfirst($provider),
                'external_account_id' => $data['external_account_id'] ?? null,
                'credential_reference' => null,
                'settings' => $data['settings'] ?? [],
                'status' => 'paused',
            ]);
            ChannelConnectionMember::query()->create([
                'channel_connection_id' => $connection->id,
                'company_id' => $companyId,
                'user_id' => $actorId,
                'role' => 'owner',
                'joined_at' => now(),
            ]);
            return $connection;
        });
        $this->audit->record($companyId, $actorId, 'channel-connection.created', 'channel-connection', $connection->uuid, null, ['provider' => $provider]);
        return response()->json($connection->load('members'), 201);
    }

    public function update(Request $request, ChannelConnection $connection): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->assertCompany($connection, $companyId);
        abort_unless($this->policy->canManage($connection, $actorId), 403);
        $data = $request->validate([
            'display_name' => ['sometimes', 'nullable', 'string', 'max:255'],
            'settings' => ['sometimes', 'array'],
            'status' => ['sometimes', 'in:active,paused,disabled'],
        ]);
        $this->sensitive->assertSafe(is_array($data['settings'] ?? null) ? $data['settings'] : [], 'settings');
        $connection->fill($data)->save();
        $this->audit->record($companyId, $actorId, 'channel-connection.updated', 'channel-connection', $connection->uuid, null, ['fields' => array_keys($data)]);
        return response()->json($connection->fresh('members'));
    }

    public function addMember(Request $request, ChannelConnection $connection): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->assertCompany($connection, $companyId);
        abort_unless($this->policy->canManage($connection, $actorId), 403);
        $data = $request->validate(['user_id' => ['required', 'integer'], 'role' => ['required', 'in:admin,moderator,agent,viewer']]);
        $userId = (int) $data['user_id'];
        $this->actors->assertUsersBelongToCompany($companyId, [$userId]);
        $member = ChannelConnectionMember::query()->firstOrNew([
            'channel_connection_id' => $connection->id,
            'company_id' => $companyId,
            'user_id' => $userId,
        ]);
        $member->fill(['role' => $data['role'], 'joined_at' => now(), 'left_at' => null])->save();
        $this->audit->record($companyId, $actorId, 'channel-member.added', 'channel-connection', $connection->uuid, null, ['member_user_id' => $userId, 'role' => $data['role']]);
        return response()->json($member, 201);
    }

    public function removeMember(Request $request, ChannelConnection $connection, ChannelConnectionMember $member): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->assertCompany($connection, $companyId);
        abort_unless($this->policy->canManage($connection, $actorId), 403);
        abort_unless((int) $member->company_id === $companyId && (int) $member->channel_connection_id === (int) $connection->id, 404);
        abort_if($member->role === 'owner', 403, 'Transfer channel ownership before removing the owner.');
        $member->forceFill(['left_at' => now()])->save();
        $this->audit->record($companyId, $actorId, 'channel-member.removed', 'channel-connection', $connection->uuid, null, ['member_user_id' => (int) $member->user_id]);
        return response()->json(['status' => 'success']);
    }

    private function assertCompany(ChannelConnection $connection, int $companyId): void
    {
        abort_unless((int) $connection->company_id === $companyId, 404);
    }
}
