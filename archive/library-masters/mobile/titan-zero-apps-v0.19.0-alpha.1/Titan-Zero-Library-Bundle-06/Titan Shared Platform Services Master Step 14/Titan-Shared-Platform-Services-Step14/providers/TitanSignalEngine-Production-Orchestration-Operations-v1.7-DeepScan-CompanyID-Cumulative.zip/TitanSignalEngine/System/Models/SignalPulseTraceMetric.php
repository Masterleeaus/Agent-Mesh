<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalPulseTraceMetric extends Model
{
    protected $table = 'titan_signal_pulse_trace_metrics';
    protected $guarded = [];

    protected $casts = [
        'tenant_company_id' => 'integer',
        'tenant_key' => 'integer',
        'event_count' => 'integer',
        'max_severity_weight' => 'integer',
        'duration_ms' => 'integer',
        'command_latency_ms' => 'integer',
        'terminal_seen' => 'boolean',
        'first_occurred_at' => 'immutable_datetime',
        'last_occurred_at' => 'immutable_datetime',
        'first_recorded_at' => 'immutable_datetime',
        'last_recorded_at' => 'immutable_datetime',
        'command_executed_at' => 'immutable_datetime',
        'execution_receipt_at' => 'immutable_datetime',
    ];
}
