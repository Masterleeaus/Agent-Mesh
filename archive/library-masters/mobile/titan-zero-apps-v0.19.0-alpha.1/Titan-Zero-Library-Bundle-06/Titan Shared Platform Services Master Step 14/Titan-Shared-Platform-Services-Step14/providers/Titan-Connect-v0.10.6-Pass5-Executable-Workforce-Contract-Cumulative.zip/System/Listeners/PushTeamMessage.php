<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Listeners;

use App\Extensions\TitanConnect\System\Contracts\MobilePushGateway;
use App\Extensions\TitanConnect\System\Events\TeamChat\TeamMessageCreated;

final class PushTeamMessage
{
    public function __construct(private readonly MobilePushGateway $push)
    {
    }

    public function handle(TeamMessageCreated $event): void
    {
        $message = $event->message;
        $conversation = $message->conversation;
        $recipients = $conversation->participants()
            ->where('company_id', $conversation->company_id)
            ->whereNull('left_at')
            ->where('user_id', '!=', $message->user_id)
            ->pluck('user_id')->map(fn ($id) => (int) $id)->all();

        if ($recipients === []) {
            return;
        }

        $this->push->send((int) $conversation->company_id, $recipients, [
            'type' => 'titan-connect.message',
            'conversation_uuid' => (string) $conversation->uuid,
            'message_uuid' => (string) $message->uuid,
            'body_preview' => mb_substr((string) $message->body, 0, 160),
        ]);
    }
}
