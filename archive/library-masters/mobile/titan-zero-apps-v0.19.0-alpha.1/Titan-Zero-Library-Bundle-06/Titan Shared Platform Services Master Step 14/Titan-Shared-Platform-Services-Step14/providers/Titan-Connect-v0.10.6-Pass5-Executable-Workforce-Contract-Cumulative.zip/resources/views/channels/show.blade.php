@push('css')
<link rel="stylesheet" href="{{ asset('vendor/titan-connect/css/operator-inbox.css') }}">
@endpush

<div class="container-fluid py-6">
<section
    id="titan-connect-channel-settings"
    class="tc-operator tc-settings"
    data-provider="{{ $provider }}"
    data-diagnostics-base="{{ url('/api/titan-connect/diagnostics') }}"
    data-connections-base="{{ url('/api/titan-connect/connections') }}"
    data-health-base="{{ url('/api/titan-connect/connections') }}"
    data-csrf="{{ csrf_token() }}"
>
    <header class="tc-operator__header">
        <div>
            <h1>{{ $providerLabel }}</h1>
            <p>{{ __('Connection settings, access and diagnostic state for this company. Credentials stay encrypted and are never displayed here.') }}</p>
        </div>
        <div class="tc-operator__header-actions">
            <a class="tc-btn" href="{{ route('dashboard.user.titan-connect.channels.index') }}">{{ __('All channels') }}</a>
            <a class="tc-btn tc-btn--ghost" href="{{ route('dashboard.user.titan-connect.inbox.external') }}">{{ __('Open inbox') }}</a>
            @if (in_array($provider, ['instagram', 'messenger'], true))
                <a class="tc-btn tc-btn--primary" href="{{ route('dashboard.user.titan-connect.onboarding.meta.start', ['provider' => $provider]) }}">{{ __('Connect with Meta') }}</a>
            @endif
        </div>
    </header>

    @if ($provider === 'telegram')
        <div class="tc-settings__notice"><strong>{{ __('Telegram setup') }}</strong><span>{{ __('New bots can be connected from the Inbox connection manager; Titan Connect validates the bot and registers its webhook automatically.') }}</span></div>
    @elseif ($provider === 'whatsapp')
        <div class="tc-settings__notice"><strong>{{ __('WhatsApp transports') }}</strong><span>{{ __('Titan Connect supports Meta Cloud API and Twilio WhatsApp behind the same company-scoped channel model.') }}</span></div>
    @elseif ($provider === 'voice')
        <div class="tc-settings__notice"><strong>{{ __('Voice engines') }}</strong><span>{{ __('OpenAI Realtime and ElevenLabs voice sessions are configured through company-owned voice connections.') }}</span></div>
    @elseif ($provider === 'push')
        <div class="tc-settings__notice"><strong>{{ __('Push / Mobile') }}</strong><span>{{ __('Push delivery delegates to TitanMobileCore; device identity and push subscriptions remain owned by the mobile platform.') }}</span></div>
    @endif

    <section class="tc-panel">
        <div class="tc-panel__title"><strong>{{ __('Connections & diagnostics') }}</strong></div>
        <div class="tc-connection-list">
            @forelse ($connections as $item)
                @php($connection = $item['connection'])
                @php($diagnostic = $item['diagnostic'])
                <article class="tc-connection-row" data-connection-uuid="{{ $connection->uuid }}" data-diagnostic-provider="{{ $provider }}">
                    <div>
                        <strong>{{ $connection->display_name ?: $providerLabel }}</strong>
                        <small>{{ $connection->status }} · {{ __('credentials') }} {{ $diagnostic['credential_state'] }}</small>
                    </div>
                    <div class="tc-connection-row__counters">
                        {{ __('queued') }} {{ $diagnostic['queued_deliveries'] }} ·
                        {{ __('failed') }} {{ $diagnostic['failed_deliveries'] }} ·
                        {{ __('webhook errors') }} {{ $diagnostic['failed_webhooks'] }} ·
                        {{ __('members') }} {{ $diagnostic['member_count'] }}
                    </div>
                    <div class="tc-inline-actions">
                        @if ($item['can_manage'])
                            <button class="tc-btn tc-btn--ghost" type="button" data-action="health">{{ __('Check health') }}</button>
                            <button class="tc-btn tc-btn--ghost" type="button" data-action="toggle" data-status="{{ $connection->status }}">{{ $connection->status === 'active' ? __('Pause') : __('Activate') }}</button>
                        @else
                            <span class="tc-badge">{{ __('Read only') }}</span>
                        @endif
                    </div>
                </article>
            @empty
                <div class="tc-empty">
                    {{ __('No :provider connections are available to your account yet.', ['provider' => $providerLabel]) }}
                    {{ __('Use Connect & manage channels in the Inbox to create one.') }}
                </div>
            @endforelse
        </div>
    </section>
    <div class="tc-status" data-role="channel-settings-status" aria-live="polite"></div>
</section>

</div>

@push('script')
<script src="{{ asset('vendor/titan-connect/js/channel-settings.js') }}" defer></script>
@endpush
