<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Console;
use App\Extensions\Crm\System\ReadModels\{CrmProjectionDeadLetterStore,CrmProjectionEventProjector};
use Illuminate\Console\Command;
use Throwable;
final class ReplayCrmProjectionDeadLettersCommand extends Command
{
    protected $signature='crm:projections:dead-letters {--limit=50 : Maximum due failures to replay}';
    protected $description='Replay retryable CRM projection dead letters without blocking authoritative Signal delivery.';
    public function handle(CrmProjectionDeadLetterStore $store,CrmProjectionEventProjector $projector): int{$ok=0;$failed=0;foreach($store->due((int)$this->option('limit')) as $row){try{$event=json_decode((string)$row['event_payload'],true,512,JSON_THROW_ON_ERROR);$projector->projectEvent($event);$store->markResolved((string)$row['public_id']);$ok++;}catch(Throwable $e){$store->recordFailure(json_decode((string)$row['event_payload'],true)?:[],$e,$row['projection_name']??null,$row['projection_version']??null);$failed++;}}$this->line(json_encode(['replayed'=>$ok,'failed'=>$failed]));return $failed===0?self::SUCCESS:self::FAILURE;}
}
