# Operations

## Health

Governance health separates dependency installation from actual action-path readiness. `governance-command-gateway` is healthy only when the configured `GovernanceCommandGatewayContract` reports `HEALTHY` or `READY`.

## Host certification

Run:

```text
php artisan titan:titan-governance:certify --json
```

The command checks provider boot, MySQL connectivity, Governance tables, required routes, Pass 4 columns, manifest version and the actual Command Bus gateway binding. An unbound Command Bus gateway correctly fails host certification for live governed actions.

## Projection refresh

Use:

```text
php artisan titan:titan-governance:refresh-projections --tenant=<id>
```

Projection failure must not be treated as authority failure or success. Live source reads remain separate from retained projection history.

## Action recovery

For `COMMAND_BUS_UNAVAILABLE`, dispatch exceptions, timeouts or transport failures, retry the same semantic operation ID. Do not create a new human decision merely because transport failed. For a version conflict, reload the escalation and submit a new action against the current version.
