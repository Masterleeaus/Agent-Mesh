# Host Integration Gaps

## Required host authorities

Titan Maps intentionally does not create duplicate users, companies, roles or WorkCore records. The host must provide authoritative implementations for:

- active company/membership context;
- granular company permission authorization;
- Titan capability registry;
- Titan Vault secret resolution;
- operational audit recording;
- private signed export storage;
- WorkCore candidate lookup/promotion.

## Pass 3 route/security requirements

The host must also provide:

1. `titan.company` middleware that resolves the authenticated active company server-side;
2. Sanctum/API authentication;
3. host `admin` middleware;
4. Laravel Gate ability `titan-maps-intelligence.admin.access` for platform administrators;
5. optional `InternalRequestAuthorizer` binding before any internal Maps route is added/enabled.

The internal profile deliberately fails closed without item 5.

## Queue integration

The extension supplies its own `QueueTenantContext` so queued discovery work is not dependent on HTTP ambient tenant state. If the host has a wider tenant-context activation facility, it may decorate/replace this contract, but it must preserve the serialized `companyId` boundary and fail on missing tenant IDs.

## Required integrated checks

- cross-company HTTP model-ID isolation;
- permission denial paths;
- super-admin/company permission separation;
- queue tenant activation/restoration;
- all existing migration/CRUD tests.

## Prohibited shortcut

Do not add extension-local users, companies, memberships, plaintext secrets or duplicate WorkCore tables merely to make the module boot. Those create competing authorities and invalidate tenant isolation.
