# Integration Contracts

## Governance read sources

Implement `App\\Extensions\\TitanGovernance\\System\\Contracts\\GovernanceReadSourceContract` and configure the class under `titan-governance.read_sources`.

Every adapter must:

- return tenant-scoped data for the requested `tenant_company_id`;
- perform no source-engine or business-state mutation;
- identify its stable `key()`;
- expose whether it is required;
- carry observed timestamps and causal references where available;
- return structured fields rather than hidden reasoning or provider secrets.

Required read sources are `titan-autonomy` and `titan-signal`. Optional sources remain visible as `NOT_INSTALLED`/`UNAVAILABLE` without crashing Governance.

## Governance → Titan Command Bus

Governed actions use `GovernanceCommandGatewayContract` only:

```php
interface GovernanceCommandGatewayContract
{
    public function health(): array;
    public function dispatch(array $command): array;
}
```

Configure the host implementation with `TITAN_GOVERNANCE_COMMAND_GATEWAY_CLASS`. The class must be resolvable by Laravel and implement the contract exactly. Invalid/missing bindings degrade to `UnavailableGovernanceCommandGateway`; there is no direct-execution fallback.

The dispatched envelope includes the server-mapped tenant, actor, operation ID, action capability, Governance decision reference, expected escalation version, structured reason/evidence references and four-ID causal lineage. Browser payloads cannot provide authoritative tenant, actor, permissions or causal IDs.

### Receipt contract

For `APPLIED`, Governance accepts success only when the Command Bus response contains:

- matching `governance_decision_ref`;
- durable `command_receipt_ref`;
- `authoritative_domain_receipt_ref`;
- non-empty adapter identity;
- `write_verified=true`.

Early `BLOCKED`/`FAILED` Command Bus results may legitimately occur before Governance-reference echo and remain truthful failures. `REPLAYED` requires a durable Command Bus receipt reference.

### Retry/idempotency contract

`tenant_company_id + operation_id` identifies one human Governance decision. Semantic payload identity excludes fresh transport trace IDs, so an HTTP/transport retry can reuse the same operation safely. A different actor/action/escalation/version/reason/evidence payload under the same operation ID is rejected as `IDEMPOTENCY_CONFLICT`.

Transient Command Bus reasons (`COMMAND_BUS_UNAVAILABLE`, dispatch/timeout/transport failures) may redispatch the same operation and same decision ID. Terminal outcomes are returned as replays and do not redispatch.

## Titan Command Bus → Governance escalation target

`GovernanceEscalationTarget` is the Governance-owned authoritative implementation for escalation-state transitions. It must be registered with the installed Command Bus/domain adapter layer for `governance.escalation.approve|reject|hold|exception|escalate`.

The target verifies tenant, Governance decision reference, action, escalation ID, semantic payload hash and expected version before changing Governance-owned escalation state. It returns an authoritative `governance://escalations/.../versions/...` receipt. Governance controllers/services must never call this target directly as a shortcut around Command Bus.

## Projection contract

Governance may persist only normalized read projections. Projection rows are non-authoritative and cannot be used to increase Autonomy, bypass Risk/Assurance, or execute a Command Bus mutation.

## Titan AI Workforce oversight adapter — Pass 7

Governance consumes Titan AI Workforce only through the existing `GovernanceReadSourceContract` entry keyed `titan-ai-workforce`. The host adapter may project the canonical Workforce Control Room payload into `snapshot()['control_centre']` with `organisation_graph`, `queues`, `handoffs`, `approvals`, `performance`, `trust_health`, `outcome_health`, `outcome_refs` and `summary`.

Governance normalizes this payload but does not call Workforce models/services directly and does not persist a competing Workforce state store. Hierarchy, title, maturity and performance are presentation/evidence fields only; they cannot raise desired, earned or effective authority. The effective authority owner remains Titan Autonomy.
