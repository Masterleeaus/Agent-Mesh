<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface EvidenceRecalculatorContract
{
    /** Recalculate streak, eligibility and supported authority after reset/deletion/policy change. */
    public function recalculate(int $tenantCompanyId, string $capability, ?string $workflowKey): array;
}
