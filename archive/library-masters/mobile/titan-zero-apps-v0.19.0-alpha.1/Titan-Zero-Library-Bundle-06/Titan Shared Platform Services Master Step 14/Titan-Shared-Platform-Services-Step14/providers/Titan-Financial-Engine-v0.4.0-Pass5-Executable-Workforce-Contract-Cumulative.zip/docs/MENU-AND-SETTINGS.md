# Titan Financial Engine — Menu & Settings Integration

## Navigation authority

Titan Financial Engine keeps one semantic navigation definition in:

`System/Navigation/FinancialNavigation.php`

It does not patch MagicAI's large central `MenuService` directly.

### Blueprint/Titan hosts

At provider boot, `HostNavigationRegistrar` attempts:

- `App\Support\Extensions\MenuContributionRegistry` for `navigation.user`
- `App\Support\Extensions\ContributionRegistry` for `navigation.admin`

The adapter accepts common `register`, `contribute`, and `add` method shapes and fails open if a host exposes a different API. A navigation API mismatch must not make the financial engine fail to install.

### Database-backed MagicAI fallback

Migration `2026_08_09_000006_sync_financial_navigation_into_magicai_menus.php` calls `MenuDatabaseSynchronizer`.

The synchronizer:

1. checks that `menus` exists;
2. checks required columns before writing;
3. idempotently upserts the **Financial Assistants** user parent and its children;
4. writes admin rows only if the schema has an explicit `is_admin` column;
5. calls `App\Services\Common\MenuService::regenerate()` when available;
6. removes only Titan Financial Engine-owned menu keys during rollback/uninstall.

This split is intentional. On older MagicAI schemas without `is_admin`, blindly inserting an admin hierarchy into the ordinary menu table can expose administrator navigation to regular users. Such hosts should use the shared Titan menu-contribution bridge for Super Admin navigation rather than a module-specific core patch.

## Company menu

```text
Financial Assistants
├── All Assistants
├── Quotes
├── Create Quote
├── Price Books
├── Rate Cards
├── Margin Rules
└── Settings
```


## Assistant launcher and routes

The user parent remains intentionally compact. It does not add 17 engine children to the sidebar. **All Assistants** opens a grouped launcher where every registered calculation engine is a clickable card with a distinct icon.

Each assistant is available at:

`GET /dashboard/titan-financial-engine/assistants/{engine}`

Calculations submit to:

`POST /dashboard/titan-financial-engine/assistants/{engine}`

Super Admin has equivalent routes beneath `/dashboard/admin/titan-financial-engine/assistants/{engine}` and must supply a company ID so company settings and audit boundaries remain explicit.

The v0.4 upgrade migration `2026_08_09_000007_upgrade_financial_assistants_navigation.php` re-runs the owned menu upsert so sites that already installed v0.3 receive the new parent label and child icons.

## Super Admin menu

```text
Titan Financial Engine
├── Overview
├── Promotions & Discounts
└── Settings
```

## Settings persistence

All extension-owned configuration uses `financial_settings`.

Rows use stable scope keys:

- `platform`
- `company:{company_id}`

No `.env`, MagicAI core config, or central settings table is overwritten.

## Runtime effects

Settings are consumed by runtime code, including:

- global/company enabled state;
- platform engine enablement;
- platform audit-persistence policy;
- quote currency/tax/margin/validity defaults;
- atomic quote numbering sequence;
- approval and hard-block fallback thresholds;
- maximum no-approval discount;
- Jobs, Titan Gear and Titan Pay handoff availability.

Explicit Margin Policies take precedence over Settings for a quote when configured.
