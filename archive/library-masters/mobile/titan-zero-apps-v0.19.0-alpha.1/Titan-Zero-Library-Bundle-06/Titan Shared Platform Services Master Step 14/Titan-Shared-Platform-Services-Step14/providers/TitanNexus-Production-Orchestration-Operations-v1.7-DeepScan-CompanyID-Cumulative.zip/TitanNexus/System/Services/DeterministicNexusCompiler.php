<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Services;

use App\Extensions\TitanNexus\System\Contracts\NexusCompilerContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompiledTitanConfig;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Support\DeterministicMerge;
use InvalidArgumentException;

final class DeterministicNexusCompiler implements NexusCompilerContract
{
    public function __construct(private readonly string $compilerVersion)
    {
        if ($this->compilerVersion === '' || strlen($this->compilerVersion) > 80) {
            throw new InvalidArgumentException('compiler_version must be between 1 and 80 characters.');
        }
    }

    public function version(): string
    {
        return $this->compilerVersion;
    }

    public function compile(
        BusinessProfile $profile,
        VerticalDefinition $definition,
        string $configurationVersion,
    ): CompiledTitanConfig {
        if ($profile->verticalId() !== $definition->verticalId()) {
            throw new InvalidArgumentException('Vertical definition identity must exactly match the business profile.');
        }

        if ($profile->verticalVersion() !== $definition->verticalVersion()) {
            throw new InvalidArgumentException('Vertical definition version must exactly match the business profile.');
        }

        return CompiledTitanConfig::fromArray([
            'tenant_company_id' => $profile->tenantCompanyId(),
            'configuration_version' => $configurationVersion,
            'compiler_version' => $this->compilerVersion,
            'vertical_id' => $definition->verticalId(),
            'vertical_version' => $definition->verticalVersion(),
            'knowledge_snapshot_version' => $definition->knowledgeSnapshotVersion(),
            'source_profile_hash' => $profile->fingerprint(),
            'source_vertical_hash' => $definition->fingerprint(),
            'sections' => DeterministicMerge::override($definition->sections(), $profile->sections()),
        ]);
    }
}
