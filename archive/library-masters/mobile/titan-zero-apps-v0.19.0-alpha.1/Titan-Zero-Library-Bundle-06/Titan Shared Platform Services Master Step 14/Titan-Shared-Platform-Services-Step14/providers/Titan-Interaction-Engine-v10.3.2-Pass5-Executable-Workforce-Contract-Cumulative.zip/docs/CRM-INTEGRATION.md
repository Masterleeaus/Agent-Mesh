# CRM Integration

CRM is the authoritative Field/Home Services business operating system. Interaction Engine consumes only public CRM capability/read-model gateway contracts; it does not import CRM Eloquent models or shared business tables.

Interaction `company_id` maps inside the CRM adapter to CRM's physical company tenancy representation (for example `tenant_company_id` where the CRM contract defines it). That storage naming never leaks into generic Interaction contracts.

Phase 6 declares CRM profile/hours/services/service areas/customer/work-order/appointment/quote/invoice/payment/staff/support/form capabilities. The supplied CRM 1.1 source does not expose the required public company-scoped Phase 6 gateway, so the provider is **SCAFFOLDED/UNVERIFIED for live host execution** and fails closed by default.
