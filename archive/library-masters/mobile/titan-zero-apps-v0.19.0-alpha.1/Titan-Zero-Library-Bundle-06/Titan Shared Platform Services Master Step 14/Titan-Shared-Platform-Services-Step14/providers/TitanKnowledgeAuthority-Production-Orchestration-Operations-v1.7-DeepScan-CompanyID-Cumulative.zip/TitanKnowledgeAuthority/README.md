# Titan Knowledge Authority v0.5.0-alpha.4

> **Installer compatibility H1:** this cumulative package targets the live Titan Extension Manager `1.7.6` root-manifest validator while retaining the canonical schema 2.2 architecture sidecar.

> **Navigation H2:** fixes modern Titan menu-registry registration and adds the MagicAI `menus` table + `MenuService::regenerate()` fallback required by older/Installer 1.7.6 hosts. Existing administrator order/enabled state is preserved.


Titan Knowledge Authority is Titan's canonical engine for versioned knowledge evidence, provenance, authority, jurisdiction, applicability and future deterministic resolution.

## Pass 4 — Immutable Source Versioning
This cumulative release preserves Passes 1–3 and adds a transaction-safe append boundary around the durable source-version store.

Implemented in this pass:
- `KnowledgeSourceVersionWriteContract` and `KnowledgeSourceVersionWriteService`
- validated `SourceVersionCreateRequest` that intentionally contains no caller-supplied tenant identifier
- explicit `SourceVersionWriteResult` distinguishing created vs content-deduplicated writes
- per-source transaction serialization using a source-row `lockForUpdate()`
- deterministic monotonically increasing sequences and stable keys such as `v00000001`
- normalized SHA-256 content hashing plus byte-preserving raw-evidence hashing
- idempotent same-content detection under the same source
- automatic supersession of the latest prior source version; callers cannot choose an arbitrary predecessor
- source/version tenant lineage derived from the canonical source, never from request input
- fail-closed validation of legacy, inactive or malformed source scope before append
- explicit raw-evidence storage reference field
- continued model-level rejection of source-version updates and deletes
- effective-window validation and required provenance/trace/correlation/causation input

## Security and authority boundary
This write contract is an internal domain seam, not a newly advertised external capability. Public capabilities remain `titan-knowledge-authority` and `knowledge.health`. The extension still has no external hosts, HTTP retrieval, scraping, queues, schedules, recurring refresh or `knowledge.resolve`.

Pass 5 will add stable document/section citation semantics on top of immutable source versions.
