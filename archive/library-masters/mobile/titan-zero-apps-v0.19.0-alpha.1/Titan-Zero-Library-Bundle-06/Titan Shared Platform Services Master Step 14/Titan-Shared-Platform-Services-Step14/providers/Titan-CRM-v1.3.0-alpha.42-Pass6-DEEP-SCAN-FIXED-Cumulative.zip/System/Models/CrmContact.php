<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Models;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScoped;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class CrmContact extends Model
{
    use CrmCompanyScoped, SoftDeletes;

    protected $table = 'crm_contacts';
    protected $guarded = ['id'];
    protected $casts = ['is_primary' => 'boolean', 'meta' => 'array'];

    public function company(): BelongsTo { return $this->belongsTo(CrmCompany::class, 'customer_company_id'); }
}
