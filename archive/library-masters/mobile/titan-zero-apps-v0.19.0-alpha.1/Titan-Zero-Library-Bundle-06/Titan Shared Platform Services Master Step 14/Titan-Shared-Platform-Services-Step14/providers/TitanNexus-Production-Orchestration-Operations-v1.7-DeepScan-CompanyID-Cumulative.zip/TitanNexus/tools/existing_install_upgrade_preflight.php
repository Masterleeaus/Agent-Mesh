<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Host\TitanExistingInstallUpgradePreflight;

$args = [];
foreach (array_slice($argv, 1) as $argument) {
    if (str_starts_with($argument, '--') && str_contains($argument, '=')) {
        [$key, $value] = explode('=', substr($argument, 2), 2);
        $args[$key] = $value;
    }
}

$root = $args['root'] ?? dirname(__DIR__);
require_once $root . '/System/Host/TitanInstallerManifestContract.php';
require_once $root . '/System/Host/TitanPackageIntegrityBuilder.php';
require_once $root . '/System/Host/TitanMySqlMigrationCompatibility.php';
require_once $root . '/System/Host/TitanFreshInstallPreflight.php';
require_once $root . '/System/Host/NexusMenuRegistrar.php';
require_once $root . '/System/Host/TitanExistingInstallUpgradePreflight.php';

$package = TitanExistingInstallUpgradePreflight::verifyDirectory($root);
$factsPath = $args['installed-facts'] ?? null;
$installed = null;
if (is_string($factsPath) && $factsPath !== '') {
    if (!is_file($factsPath)) {
        $installed = ['compatible' => false, 'reasons' => ['installed_facts_file_missing']];
    } else {
        $facts = json_decode((string) file_get_contents($factsPath), true, 512, JSON_THROW_ON_ERROR);
        $installed = TitanExistingInstallUpgradePreflight::evaluateInstalledState($root, is_array($facts) ? $facts : []);
    }
}

$result = [
    'schema_version' => '1.0',
    'package_preflight' => $package,
    'installed_state' => $installed ?? [
        'compatible' => null,
        'reasons' => ['installed_facts_not_supplied'],
        'note' => 'Package upgrade preflight does not grant live UPGRADE_CERTIFIED.',
    ],
    'live_upgrade_certified' => false,
];
$result['status'] = ($package['status'] ?? 'FAIL') === 'PASS'
    && ($installed === null || ($installed['compatible'] ?? false) === true)
    ? 'PASS' : 'FAIL';

$json = json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . PHP_EOL;
if (isset($args['output']) && is_string($args['output']) && $args['output'] !== '') {
    file_put_contents($args['output'], $json);
}
echo $json;
exit($result['status'] === 'PASS' ? 0 : 1);
