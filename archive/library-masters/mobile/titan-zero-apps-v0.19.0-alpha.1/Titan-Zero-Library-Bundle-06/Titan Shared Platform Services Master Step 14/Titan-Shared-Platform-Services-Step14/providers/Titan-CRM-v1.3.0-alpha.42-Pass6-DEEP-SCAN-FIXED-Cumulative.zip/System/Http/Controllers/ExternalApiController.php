<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Contracts\{ContactRepositoryContract,CompanyRepositoryContract,DealRepositoryContract}; use App\Extensions\Crm\System\Services\CrmDashboardService; use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class ExternalApiController extends Controller
{
    private function uid(Request $request): int { return (int)$request->attributes->get('crm_api_user_id'); }
    public function dashboard(Request $request,CrmDashboardService $dashboard){return response()->json(['data'=>$dashboard->summary($this->uid($request))]);}
    public function contacts(Request $request,ContactRepositoryContract $contacts){return response()->json(['data'=>$contacts->search($this->uid($request),['q'=>$request->query('query'),'limit'=>max(1,min((int)$request->query('per_page',50),100))])]);}
    public function companies(Request $request,CompanyRepositoryContract $companies){return response()->json(['data'=>$companies->search($this->uid($request),['q'=>$request->query('query'),'limit'=>max(1,min((int)$request->query('per_page',50),100))])]);}
    public function deals(Request $request,DealRepositoryContract $deals){return response()->json(['data'=>$deals->search($this->uid($request),['q'=>$request->query('query'),'limit'=>max(1,min((int)$request->query('per_page',50),100))])]);}
}
