@extends('panel.layout.app')

@section('content')
@php
    $summary = $snapshot['summary'] ?? [];
    $selected = $snapshot['selected'] ?? null;
    $compilations = $snapshot['compilations'] ?? [];
    $lineage = $snapshot['lineage'] ?? [];
    $pretty = static fn (mixed $value): string => (string) json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
@endphp
<div class="container-fluid py-4 titan-nexus-control-centre">
    <div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-4">
        <div>
            <h1 class="mb-1">Titan Nexus Control Centre</h1>
            <p class="text-muted mb-0">Tenant-scoped configuration compilation, validation, history, semantic diff and governed provisioning evidence.</p>
        </div>
        <div class="text-end">
            <span class="badge bg-secondary">Nexus v1.0.0-rc.2</span>
            @if($available && isset($snapshot['tenant_company_id']))
                <div class="small text-muted mt-1">Company context #{{ $snapshot['tenant_company_id'] }}</div>
            @endif
        </div>
    </div>

    @include('titan-nexus::partials.control-centre-nav', ['section' => $section])

    @if(!$available)
        <div class="alert alert-warning" role="alert">
            <strong>Control Centre unavailable.</strong> {{ $message }}
        </div>
    @elseif($section === 'overview')
        <div class="row g-3 mb-4">
            <div class="col-6 col-lg-2"><div class="card h-100"><div class="card-body"><div class="text-muted small">Compilations</div><div class="fs-2 fw-bold">{{ $summary['total_compilations'] ?? 0 }}</div></div></div></div>
            <div class="col-6 col-lg-2"><div class="card h-100"><div class="card-body"><div class="text-muted small">Current state</div><div class="fw-semibold">{{ $summary['current_status'] ?? 'No compilation' }}</div></div></div></div>
            <div class="col-6 col-lg-2"><div class="card h-100"><div class="card-body"><div class="text-muted small">Vertical</div><div class="fw-semibold">{{ $summary['vertical_id'] ?? '—' }}</div><div class="small text-muted">{{ $summary['vertical_version'] ?? '' }}</div></div></div></div>
            <div class="col-6 col-lg-2"><div class="card h-100"><div class="card-body"><div class="text-muted small">Validation</div><div class="fw-semibold">{{ $summary['validation']['errors'] ?? 0 }} errors</div><div class="small text-muted">{{ $summary['validation']['warnings'] ?? 0 }} warnings</div></div></div></div>
            <div class="col-6 col-lg-2"><div class="card h-100"><div class="card-body"><div class="text-muted small">Changes</div><div class="fw-semibold">{{ ($summary['diff']['add'] ?? 0) + ($summary['diff']['modify'] ?? 0) + ($summary['diff']['deprecate'] ?? 0) }}</div><div class="small text-muted">{{ $summary['diff']['blocked'] ?? 0 }} blocked</div></div></div></div>
            <div class="col-6 col-lg-2"><div class="card h-100"><div class="card-body"><div class="text-muted small">Provisioning</div><div class="fw-semibold">{{ $summary['provisioning']['status'] ?? 'Not planned' }}</div><div class="small text-muted">{{ $summary['provisioning']['operations'] ?? 0 }} operations</div></div></div></div>
        </div>
        <div class="card">
            <div class="card-header"><h2 class="card-title mb-0">Recent compilations</h2></div>
            <div class="table-responsive">
                <table class="table table-vcenter card-table mb-0">
                    <thead><tr><th>Compilation</th><th>Vertical</th><th>Status</th><th>Config</th><th>Validation</th><th>Provisioning</th></tr></thead>
                    <tbody>
                    @forelse($compilations as $item)
                        <tr>
                            <td><a href="{{ route('dashboard.user.titan.nexus.detail', ['compilationUuid' => $item['compilation_uuid']]) }}"><code>{{ $item['compilation_uuid'] }}</code></a></td>
                            <td>{{ $item['vertical_id'] }} <span class="text-muted">{{ $item['vertical_version'] }}</span></td>
                            <td>{{ $item['status'] }}</td>
                            <td>{{ $item['configuration_version'] ?? '—' }}</td>
                            <td>{{ $item['validation']['errors'] ?? 0 }}E / {{ $item['validation']['warnings'] ?? 0 }}W</td>
                            <td>{{ $item['provisioning_status'] ?? '—' }}</td>
                        </tr>
                    @empty
                        <tr><td colspan="6" class="text-muted py-4 text-center">No Nexus compilations exist for this company yet.</td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    @elseif($section === 'profile')
        <div class="card"><div class="card-header"><h2 class="card-title mb-0">Business Profile</h2></div><div class="card-body">
            @if($selected)<pre class="mb-0 text-wrap">{{ $pretty($selected['profile']) }}</pre>@else<p class="text-muted mb-0">No compiled business profile is available.</p>@endif
        </div></div>
    @elseif($section === 'compilations')
        <div class="card mb-4"><div class="card-header"><h2 class="card-title mb-0">Compilations</h2></div><div class="table-responsive"><table class="table table-vcenter card-table mb-0"><thead><tr><th>UUID</th><th>Parent</th><th>Profile</th><th>Vertical</th><th>Status</th><th>Output hash</th></tr></thead><tbody>
        @forelse($compilations as $item)<tr><td><a href="{{ route('dashboard.user.titan.nexus.detail', ['compilationUuid' => $item['compilation_uuid']]) }}"><code>{{ $item['compilation_uuid'] }}</code></a></td><td><code>{{ $item['parent_compilation_uuid'] ?? '—' }}</code></td><td>{{ $item['profile_version'] }}</td><td>{{ $item['vertical_id'] }} {{ $item['vertical_version'] }}</td><td>{{ $item['status'] }}</td><td><code>{{ $item['output_hash'] ?? '—' }}</code></td></tr>@empty<tr><td colspan="6" class="text-muted py-4 text-center">No compilations found.</td></tr>@endforelse
        </tbody></table></div></div>
        @if($selected)<div class="card"><div class="card-header"><h3 class="card-title mb-0">Selected compilation</h3></div><div class="card-body"><pre class="mb-0 text-wrap">{{ $pretty(['compilation_uuid'=>$selected['compilation_uuid'],'parent_compilation_uuid'=>$selected['parent_compilation_uuid'],'status'=>$selected['status'],'dry_run'=>$selected['dry_run'],'compiler_version'=>$selected['compiler_version'],'trace'=>$selected['trace']]) }}</pre></div></div>@endif
    @elseif($section === 'validation')
        <div class="card"><div class="card-header"><h2 class="card-title mb-0">Validation</h2></div><div class="card-body">
        @if($selected && $selected['validation'])
            <div class="mb-3"><span class="badge bg-secondary">{{ $summary['validation']['errors'] ?? 0 }} errors</span> <span class="badge bg-secondary">{{ $summary['validation']['warnings'] ?? 0 }} warnings</span> <span class="badge bg-secondary">{{ $summary['validation']['info'] ?? 0 }} info</span></div>
            <pre class="mb-0 text-wrap">{{ $pretty($selected['validation']) }}</pre>
        @else<p class="text-muted mb-0">No validation result is attached to the selected compilation.</p>@endif
        </div></div>
    @elseif($section === 'preview')
        <div class="card"><div class="card-header"><h2 class="card-title mb-0">Configuration Preview</h2></div><div class="card-body">
        @if($selected && $selected['configuration'])<pre class="mb-0 text-wrap">{{ $pretty($selected['configuration']) }}</pre>@else<p class="text-muted mb-0">No compiled configuration is available.</p>@endif
        </div></div>
    @elseif($section === 'history')
        <div class="card"><div class="card-header"><h2 class="card-title mb-0">History</h2></div><div class="table-responsive"><table class="table table-vcenter card-table mb-0"><thead><tr><th>Compilation</th><th>Parent</th><th>Status</th><th>Config</th><th>Vertical</th></tr></thead><tbody>
        @forelse($lineage as $item)<tr><td><code>{{ $item['compilation_uuid'] }}</code></td><td><code>{{ $item['parent_compilation_uuid'] ?? '—' }}</code></td><td>{{ $item['status'] }}</td><td>{{ $item['configuration_version'] ?? '—' }}</td><td>{{ $item['vertical_id'] }} {{ $item['vertical_version'] }}</td></tr>@empty<tr><td colspan="5" class="text-muted py-4 text-center">No lineage is available.</td></tr>@endforelse
        </tbody></table></div>
        <h5 class="mt-4">Durable lifecycle</h5>
        @php($lifecycle = $selected['lifecycle'] ?? [])
        <div class="table-responsive"><table class="table table-sm align-middle"><thead><tr><th>Stage</th><th>Entity version</th><th>Trace</th><th>Event</th></tr></thead><tbody>
        @forelse($lifecycle as $event)<tr><td>{{ $event['stage'] }}</td><td>{{ $event['entity_version'] }}</td><td><code>{{ $event['trace']['trace_id'] ?? '—' }}</code></td><td><code>{{ $event['event_id'] }}</code></td></tr>@empty<tr><td colspan="4" class="text-muted py-4 text-center">No lifecycle events are available.</td></tr>@endforelse
        </tbody></table></div></div>
    @elseif($section === 'diff')
        <div class="card"><div class="card-header"><h2 class="card-title mb-0">Recompile / Diff</h2></div><div class="card-body">
        @if($selected && $selected['diff'])
            <div class="row g-2 mb-3">@foreach(($summary['diff'] ?? []) as $key => $value)<div class="col-6 col-md-2"><div class="border rounded p-2"><div class="small text-muted">{{ str_replace('_',' ',ucfirst($key)) }}</div><strong>{{ $value }}</strong></div></div>@endforeach</div>
            <pre class="mb-0 text-wrap">{{ $pretty($selected['diff']) }}</pre>
        @else<p class="text-muted mb-0">No semantic diff is attached to the selected compilation.</p>@endif
        </div></div>
    @elseif($section === 'provisioning')
        <div class="card"><div class="card-header"><h2 class="card-title mb-0">Provisioning Plans</h2></div><div class="card-body">
        @if($selected && $selected['provisioning'])
            <p><strong>Status:</strong> {{ $summary['provisioning']['status'] ?? '—' }} &nbsp; <strong>Operations:</strong> {{ $summary['provisioning']['operations'] ?? 0 }} &nbsp; <strong>Executed:</strong> {{ ($summary['provisioning']['executed'] ?? false) ? 'Yes' : 'No' }}</p>
            <pre class="mb-0 text-wrap">{{ $pretty(['fingerprint'=>$selected['provisioning']['fingerprint'] ?? null,'operations'=>$selected['provisioning']['operations'] ?? []]) }}</pre>
        @else<p class="text-muted mb-0">No provisioning plan is attached to the selected compilation.</p>@endif
        </div></div>
    @elseif($section === 'receipts')
        <div class="card"><div class="card-header"><h2 class="card-title mb-0">Provisioning Receipts</h2></div><div class="card-body">
        @if($selected && $selected['provisioning'] && !empty($selected['provisioning']['receipts']))
            <pre class="mb-0 text-wrap">{{ $pretty($selected['provisioning']['receipts']) }}</pre>
        @else<p class="text-muted mb-0">No provisioning receipts are available for the selected compilation.</p>@endif
        </div></div>
    @endif
</div>
@endsection
