@extends('panel.layout.app')
@section('content')
@php
    $adminMode = $adminMode ?? str_starts_with((string) request()->route()?->getName(), 'dashboard.admin.');
    $action = $adminMode ? route('dashboard.admin.crm.settings.update') : route('dashboard.user.crm.settings.update');
@endphp
@component('crm::components.interaction-page-shell',['title'=>'Settings','subtitle'=>$adminMode ? 'MagicAI-wide CRM feature switches and interaction controls.' : 'Your CRM defaults, workflow preferences and Interaction Engine behaviour.','surface'=>'settings'])
    <div class="d-flex justify-content-end mb-4"><span class="badge text-bg-light">crm · {{ config('crm.assistant_template_type') }}</span></div>
    @if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif

    @if($adminMode)
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="card"><div class="card-header"><strong>MagicAI CRM feature switches</strong></div><div class="card-body">
                    <form method="post" action="{{ $action }}" class="row g-3">@csrf
                        @foreach([
                            'crm_enabled' => ['CRM enabled', 'Controls the CRM and Sales root menus.'],
                            'crm_assistant_enabled' => ['CRM Assistant enabled', 'Controls the MagicAI CRM Assistant menu and prompt integration.'],
                            'crm_presentations_enabled' => ['CRM presentations enabled', 'Controls the Presentations menu.'],
                        ] as $key => [$label, $help])
                            <div class="col-12">
                                <input type="hidden" name="{{ $key }}" value="0">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" role="switch" id="{{ $key }}" name="{{ $key }}" value="1" @checked($hostSettings[$key] ?? true)>
                                    <label class="form-check-label" for="{{ $key }}"><strong>{{ $label }}</strong><br><span class="text-muted small">{{ $help }}</span></label>
                                </div>
                            </div>
                        @endforeach
                        <div class="col-12"><button class="btn btn-primary">Save settings</button></div>
                    </form>
                </div></div>
            </div>
            <div class="col-lg-4">
                <div class="card"><div class="card-header"><strong>Host contract</strong></div><div class="card-body"><dl class="mb-0">
                    <dt>Extension</dt><dd><code>crm</code></dd>
                    <dt>Provider</dt><dd><code>App\Extensions\Crm\System\CrmServiceProvider</code></dd>
                    <dt>Plan features</dt><dd><code>ext_crm_dropdown</code><br><code>ext_sales_dropdown</code></dd>
                    <dt>Assistant</dt><dd><code>crmAssistant</code> / <code>crm-assistant</code></dd>
                    <dt>Uninstall policy</dt><dd>Retain CRM data</dd>
                </dl></div></div>
            </div>
        </div>
    @else
        <div class="row g-4"><div class="col-lg-8"><div class="card"><div class="card-body"><form method="post" action="{{ $action }}" class="row g-3">@csrf
            <div class="col-md-4"><label class="form-label">Default currency</label><input name="default_currency" maxlength="3" class="form-control text-uppercase" value="{{ $settings['default_currency'] ?? 'AUD' }}"></div>
            <div class="col-md-4"><label class="form-label">Lead follow-up days</label><input name="lead_follow_up_days" type="number" min="1" max="365" class="form-control" value="{{ $settings['lead_follow_up_days'] ?? 3 }}"></div>
            <div class="col-md-4"><label class="form-label">Notification channel</label><select name="notification_channel" class="form-select">@foreach(['in_app','email','webhook'] as $ch)<option value="{{ $ch }}" @selected(($settings['notification_channel']??'in_app')===$ch)>{{ $ch }}</option>@endforeach</select></div>
            <div class="col-12"><label class="form-label">Default pipeline public ID</label><input name="default_pipeline_public_id" class="form-control font-monospace" value="{{ $settings['default_pipeline_public_id'] ?? '' }}" placeholder="Optional 26-character pipeline ULID"></div>
            <div class="col-md-4"><div class="form-check"><input type="hidden" name="auto_capture_contacts" value="0"><input class="form-check-input" type="checkbox" name="auto_capture_contacts" value="1" id="autoCapture" @checked($settings['auto_capture_contacts'] ?? true)><label class="form-check-label" for="autoCapture">Capture MagicAI contacts</label></div></div>
            <div class="col-md-4"><div class="form-check"><input type="hidden" name="create_lead_on_capture" value="0"><input class="form-check-input" type="checkbox" name="create_lead_on_capture" value="1" id="leadCapture" @checked($settings['create_lead_on_capture'] ?? true)><label class="form-check-label" for="leadCapture">Create lead on capture</label></div></div>
            <div class="col-md-4"><div class="form-check"><input type="hidden" name="notifications_enabled" value="0"><input class="form-check-input" type="checkbox" name="notifications_enabled" value="1" id="notify" @checked($settings['notifications_enabled'] ?? true)><label class="form-check-label" for="notify">CRM notifications</label></div></div>
            <div class="col-12"><button class="btn btn-primary">Save settings</button></div>
        </form></div></div></div>
        <div class="col-lg-4"><div class="card"><div class="card-header"><strong>MagicAI host state</strong></div><div class="card-body"><ul class="list-unstyled mb-0">@foreach($hostSettings as $key => $enabled)<li class="mb-2"><code>{{ $key }}</code> <span class="badge {{ $enabled ? 'text-bg-success' : 'text-bg-secondary' }}">{{ $enabled ? 'on' : 'off' }}</span></li>@endforeach</ul></div></div></div></div>
    @endif
@endcomponent
@endsection
