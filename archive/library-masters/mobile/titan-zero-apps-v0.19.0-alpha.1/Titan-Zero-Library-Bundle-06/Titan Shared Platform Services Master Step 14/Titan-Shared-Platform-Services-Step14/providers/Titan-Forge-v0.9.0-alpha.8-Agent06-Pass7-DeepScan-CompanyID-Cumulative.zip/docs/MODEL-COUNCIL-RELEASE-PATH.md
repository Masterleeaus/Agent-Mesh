# Titan Forge — Model Council Release Path

Model Council is not part of deterministic scaffold generation. It is an escalation/review gate for high-risk generated release candidates.

Target release path:

1. A user or Titan engine submits a typed BuildRequest.
2. Forge creates an immutable BuildSpec and deterministic BuildPlan.
3. Static generators create a safe baseline in the Forge workspace.
4. Titan AI Core may propose bounded changes only when AI generation is enabled.
5. Titan Shield validates syntax, package integrity, secrets, paths, tenancy declarations and architecture rules.
6. Titan Risk assigns contextual risk.
7. Low/medium risk follows configured governance policy.
8. High/critical risk invokes Titan Model Council v0.7 governed deliberation using a bounded metadata packet and host-policy model assignments. Forge records only a sanitized decision receipt; Council owns the full deliberation evidence.
9. Titan Governance decides whether the validated candidate may become a release candidate.
10. Titan Command Bus, not Forge, performs any consequential installation or release operation.
11. Titan Signal records lifecycle facts; Titan Rewind retains structured receipts; Titan Wisdom receives post-release outcomes.

Forge never treats Model Council agreement as deployment authority. Council advice is evidence for Governance.
