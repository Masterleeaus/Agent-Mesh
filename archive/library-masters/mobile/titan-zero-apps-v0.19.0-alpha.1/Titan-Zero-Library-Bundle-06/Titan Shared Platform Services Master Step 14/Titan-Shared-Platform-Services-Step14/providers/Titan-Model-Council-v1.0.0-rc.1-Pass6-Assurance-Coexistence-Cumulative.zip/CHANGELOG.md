## 1.0.0-rc.1 Installer 1.7.5 Super Admin Control Plane Hotfix 5 — 2026-08-20

- Replaced the single operational Super Admin page with a native Model Council control centre and child navigation.
- Added persisted extension-owned settings with runtime config overlay.
- Added controls for activation, governed mode, provider/model limits, Risk/Shield/Assurance, contradiction, adaptive quorum, provider resilience and billing ceilings.
- Added Providers & Models, Integrations, Billing & Limits and Diagnostics & Audit views.
- Added idempotent child host-menu migration/self-heal and uninstall cleanup.
- Intentional peer-engine disablement now reports `DISABLED` rather than `DEGRADED`.

## 1.0.0-rc.1 Installer 1.7.5 MySQL Migration Hotfix 3 — 2026-08-20

- Fixed MySQL error 1059 in migration `2026_08_11_000010_add_governed_validation_fields.php` by replacing Laravel's overlong inferred index names with bounded explicit names.
- Hardened migration retry behavior for partial MySQL DDL: governed validation columns and their indexes are now created/repaired independently.
- Added full migration identifier audit coverage and a partial-DDL retry regression test.
- No Council runtime, billing, tenancy, Risk, Shield, Signal, provider, route or UI behavior changed.

## 1.0.0-rc.1 Installer 1.7.5 Manifest Hotfix 2 — 2026-08-19

- Added required root `extension.json` field `name: "Titan Model Council"`.
- Added permanent Installer 1.7.5 manifest-contract regression coverage.
- Regenerated package integrity/provenance only; runtime PHP, routes, migrations, billing, tenancy and Council logic are unchanged.

## Installer 1.7.4 Packaging Hotfix

- Renamed archived donor `legacy-source/extension.json` to `legacy-source/extension-json.legacy.txt` so the archive contains exactly one discoverable `extension.json`.
- Preserved donor bytes and SHA-256; added `legacy-source/LEGACY-FILE-MAP.json`.
- No active runtime code changed.
- Installer runtime dependency now requires current `titan-signal-engine >=0.20.0-rc.7`; Blueprint sidecar retains canonical `titan-signal >=1.0`.

# Changelog

## 1.0.0-rc.1 — Production Hardening Release Candidate

- Updated causal Signal integration for Titan Signal Engine v0.20 trusted emitter/context contracts.
- Updated Shield integration for v0.5 `ShieldManagerContract::evaluateInspection()` with legacy fallback.
- Added Titan Assurance v2.2 assessment boundary and required-Assurance fail-closed escalation.
- Added canonical SHA-256 Council decision receipts with participant output hashes only.
- Added receipt health/certification coverage and host-safe user/admin dashboard views.
- Preserved provider circuit breaking, bounded timeouts, adaptive quorum, partial-provider tolerance and reserve → execute → settle billing.
- Kept Council advisory-only and Risk authority-floor semantics.
- Retained Blueprint v4.2 / Installer 1.7.8 canonical package contract; package remains development-stage until live-host certification/signing.

## 0.7.0 — Blueprint v4.2 Rebase

- Adopted Installer 1.7.8 `titan-extension-v1` root manifest and Blueprint schema 2.2.
- Declared canonical `model-deliberation` ownership and governance-engine architecture.
- Added canonical Signal lifecycle/event schemas, root causation propagation, certification command and operational health contract.
- Replaced active raw table access with extension-owned Eloquent records.
- Added bounded provider polling and Blueprint production resilience controls.
- Preserved all prior v0.6 governed-deliberation, Risk, Shield, billing and legacy compatibility behavior.

## Installer 1.7.5 Host Navigation Hotfix 4 — 2026-08-20

- Fixed successful installs that exposed no Model Council menu entry.
- Added tenant-user `Model Council` navigation to `dashboard.user.titan.model.council.index`.
- Added Super Admin `Model Council` navigation to `dashboard.admin.titan.model.council.index`.
- Added modern contribution-registry registration plus Website1408/MagicAI `menus` self-heal and cache regeneration.
- Added an idempotent host-navigation migration for already-installed deployments.
- Preserved Blueprint v4.2 domain boundaries by using an Eloquent host-menu compatibility record in active runtime code.
- Added menu-row uninstall cleanup and permanent navigation regression coverage.
