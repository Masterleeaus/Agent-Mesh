<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
spl_autoload_register(static function (string $class) use ($root): void {
    $prefix = 'App\\Extensions\\TitanPrime\\System\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $path = $root . '/System/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) {
        require_once $path;
    }
});

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Bridges\FailClosedEngineBridge;
use App\Extensions\TitanPrime\System\Gateways\Contracts\EngineBridgeContract;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineAvailability;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayRequest;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineCallStatus;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;
use App\Extensions\TitanPrime\System\Gateways\Services\AiCoreGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\AssuranceGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\AutonomyGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\GovernanceGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\RewindGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\RiskGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\SignalGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\WisdomGateway;

function assert_true(bool $condition, string $message): void {
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

$trace = new TraceContext(7, 'trace-1', 'corr-1', 'cause-1', 'root-1');
$failClosed = new FailClosedEngineBridge();
$request = new EngineGatewayRequest(
    engine: EngineKey::Risk,
    capability: 'risk.assess',
    operationId: 'op-risk-1',
    trace: $trace,
    payload: ['mission_id' => 'mission-1'],
);
$result = $failClosed->dispatch($request);
assert_true($result->status === EngineCallStatus::Unavailable, 'Unbound bridge must fail closed as unavailable.');
assert_true(!$result->isSuccess(), 'Unavailable result must never be successful.');
assert_true($failClosed->availability(EngineKey::Risk)->available === false, 'Fail-closed bridge must report unavailable.');

$bridge = new class implements EngineBridgeContract {
    public array $requests = [];

    public function dispatch(EngineGatewayRequest $request): EngineGatewayResult
    {
        $this->requests[] = $request;
        if ($request->engine === EngineKey::Governance) {
            return EngineGatewayResult::denied($request, ['policy_denied']);
        }
        return EngineGatewayResult::succeeded($request, ['accepted' => true], 'receipt-' . $request->operationId);
    }

    public function availability(EngineKey $engine): EngineAvailability
    {
        return new EngineAvailability($engine, true, 'available');
    }
};

$gateways = [
    new AiCoreGateway($bridge),
    new SignalGateway($bridge),
    new RiskGateway($bridge),
    new AssuranceGateway($bridge),
    new AutonomyGateway($bridge),
    new GovernanceGateway($bridge),
    new RewindGateway($bridge),
    new WisdomGateway($bridge),
];
foreach ($gateways as $gateway) {
    assert_true($gateway->availability()->available, $gateway::class . ' must surface bridge availability.');
}

assert_true((new AiCoreGateway($bridge))->plan($trace, ['mission_id' => 'mission-1'], 'op-ai-1')->isSuccess(), 'AI Core gateway should dispatch.');
assert_true((new SignalGateway($bridge))->publish($trace, 'prime.mission.created', ['mission_id' => 'mission-1'], 'op-signal-1')->isSuccess(), 'Signal gateway should dispatch.');
assert_true((new RiskGateway($bridge))->assess($trace, ['mission_id' => 'mission-1'], 'op-risk-2')->isSuccess(), 'Risk gateway should dispatch.');
assert_true((new AssuranceGateway($bridge))->verify($trace, ['mission_id' => 'mission-1'], 'op-assurance-1')->isSuccess(), 'Assurance gateway should dispatch.');
assert_true((new AutonomyGateway($bridge))->authorize($trace, ['mission_id' => 'mission-1'], 'op-autonomy-1')->isSuccess(), 'Autonomy gateway should dispatch.');
$gov = (new GovernanceGateway($bridge))->evaluate($trace, ['mission_id' => 'mission-1'], 'op-gov-1');
assert_true($gov->status === EngineCallStatus::Denied && !$gov->isSuccess(), 'Governance denial must stay denied and fail closed.');
assert_true((new RewindGateway($bridge))->record($trace, ['receipt_id' => 'prime-r1'], 'op-rewind-1')->isSuccess(), 'Rewind gateway should dispatch.');
assert_true((new WisdomGateway($bridge))->recordOutcome($trace, ['outcome_id' => 'outcome-1'], 'op-wisdom-1')->isSuccess(), 'Wisdom gateway should dispatch.');

try {
    new EngineGatewayRequest(
        engine: EngineKey::AiCore,
        capability: 'core.plan',
        operationId: 'op-secret',
        trace: $trace,
        payload: ['authorization' => 'Bearer secret'],
    );
    throw new RuntimeException('Forbidden secret-like gateway payload was accepted.');
} catch (InvalidArgumentException $expected) {
    assert_true(str_contains($expected->getMessage(), 'forbidden'), 'Secret rejection should explain the boundary.');
}

$throwingBridge = new class implements EngineBridgeContract {
    public function dispatch(EngineGatewayRequest $request): EngineGatewayResult { throw new RuntimeException('sensitive backend failure'); }
    public function availability(EngineKey $engine): EngineAvailability { throw new RuntimeException('sensitive availability failure'); }
};
$failed = (new RiskGateway($throwingBridge))->assess($trace, ['mission_id' => 'mission-1'], 'op-risk-throw');
assert_true($failed->status === EngineCallStatus::Failed, 'Bridge exception must become a fail-closed failed result.');
assert_true(!str_contains(json_encode($failed->toArray(), JSON_THROW_ON_ERROR), 'sensitive backend failure'), 'Raw bridge exception messages must not leak into result payloads.');
assert_true((new RiskGateway($throwingBridge))->availability()->available === false, 'Availability exceptions must fail closed.');

$mismatchBridge = new class implements EngineBridgeContract {
    public function dispatch(EngineGatewayRequest $request): EngineGatewayResult
    {
        return new EngineGatewayResult(
            EngineKey::AiCore,
            $request->capability,
            $request->operationId,
            EngineCallStatus::Succeeded,
        );
    }
    public function availability(EngineKey $engine): EngineAvailability { return new EngineAvailability($engine, true, 'available'); }
};
$mismatch = (new RiskGateway($mismatchBridge))->assess($trace, ['mission_id' => 'mission-1'], 'op-risk-mismatch');
assert_true($mismatch->status === EngineCallStatus::Failed, 'Mismatched engine response must fail closed.');
assert_true(in_array('bridge_contract_mismatch', $mismatch->reasonCodes, true), 'Mismatched response must identify the contract mismatch.');

$catalog = new App\Extensions\TitanPrime\System\Gateways\Services\EngineGatewayCatalog($failClosed);
assert_true(!$catalog->allRequiredForExecutionAvailable(), 'Fail-closed catalog must not report engine readiness.');
assert_true(count($catalog->snapshot()) === count(EngineKey::cases()), 'Catalog must report every declared engine gateway.');

echo "PASS: Pass 3 engine gateway smoke\n";
