@extends('panel.layout.app')
@section('content')
<div class="container-fluid py-4">
    <div class="mb-4"><h1 class="h3 mb-1">Titan Governance</h1><p class="text-muted mb-0">Platform governance administration</p></div>
    <div class="row g-3">
        @foreach(['Control Plane'=>'Versioned policy definitions and governance projections','Authority Constraints'=>'Upper-bound-only constraints; Governance cannot mint authority','Read Plane'=>'Trust Map, structured evidence and federated source readiness','Signal Intelligence'=>'Heatmap, operational pressure, bottlenecks, circuit status and durable projection history','System Health'=>'Signal, Autonomy and Command Bus dependency readiness','Certification'=>'Use titan:titan-governance:certify for exact-host evidence'] as $title => $description)
        <div class="col-12 col-md-6"><div class="card h-100"><div class="card-body"><h5 class="card-title">{{ $title }}</h5><p class="card-text text-muted mb-0">{{ $description }}</p></div></div></div>
        @endforeach
    </div>
    <div class="card mt-4"><div class="card-body"><h5 class="card-title">Current health</h5><pre class="mb-0">{{ json_encode($health, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div></div>
</div>
@endsection
