<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Escalation;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceActionDecisionStoreContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceEscalationStoreContract;
use Throwable;

final class GovernanceEscalationTarget
{
    private const TRANSITIONS=[
        'APPROVE'=>['OPEN'=>'APPROVED','HELD'=>'APPROVED','ESCALATED'=>'APPROVED'],
        'REJECT'=>['OPEN'=>'REJECTED','HELD'=>'REJECTED','ESCALATED'=>'REJECTED'],
        'HOLD'=>['OPEN'=>'HELD','ESCALATED'=>'HELD'],
        'EXCEPTION'=>['OPEN'=>'EXCEPTION_GRANTED','HELD'=>'EXCEPTION_GRANTED','ESCALATED'=>'EXCEPTION_GRANTED'],
        'ESCALATE'=>['OPEN'=>'ESCALATED','HELD'=>'ESCALATED'],
    ];

    public function __construct(private readonly GovernanceEscalationStoreContract $escalations,private readonly GovernanceActionDecisionStoreContract $decisions){}

    /** @param array<string,mixed> $command @param array<string,mixed> $executionContext @return array<string,mixed> */
    public function apply(array $command,array $executionContext=[]): array
    {
        $decisionId=trim((string)($command['governance']['decision_ref']??''));
        $tenant=(int)($command['context']['tenant_company_id']??0);
        $payload=is_array($command['payload']??null)?$command['payload']:[];
        $escalationId=trim((string)($payload['escalation_id']??''));
        $action=strtoupper(trim((string)($payload['action']??'')));
        $expectedVersion=(int)($payload['expected_version']??0);
        $payloadHash=trim((string)($payload['payload_hash']??''));
        $operationId=trim((string)($command['operation_id']??''));
        if($tenant<1 || $decisionId==='' || $escalationId==='' || $operationId==='' || $expectedVersion<1 || !isset(self::TRANSITIONS[$action])) return $this->blocked('COMMAND_TARGET_INVALID');

        $decision=$this->decisions->findDecision($decisionId);
        if(!is_array($decision) || (int)($decision['tenant_company_id']??0)!==$tenant || (string)($decision['subject_id']??'')!==$escalationId || (string)($decision['action']??'')!==$action || !hash_equals((string)($decision['payload_hash']??''),$payloadHash)) return $this->blocked('GOVERNANCE_DECISION_MISMATCH');

        $current=$this->escalations->find($tenant,$escalationId);
        if(!is_array($current)) return $this->blocked('ESCALATION_NOT_FOUND');
        if((int)($current['version']??0)!==$expectedVersion) return $this->blocked('ESCALATION_VERSION_CONFLICT');
        $status=(string)($current['status']??'');
        $next=self::TRANSITIONS[$action][$status]??null;
        if($next===null) return $this->blocked('ESCALATION_TRANSITION_NOT_ALLOWED');

        try{
            $updated=$this->escalations->applyTransition($tenant,$escalationId,$expectedVersion,$next,$action,$decisionId,(string)($executionContext['command_execution_ref']??''));
        }catch(Throwable $e){return $this->blocked($e->getMessage()==='ESCALATION_VERSION_CONFLICT'?'ESCALATION_VERSION_CONFLICT':'ESCALATION_WRITE_FAILED');}
        $version=(int)($updated['version']??($expectedVersion+1));
        return [
            'schema_version'=>'1.0','status'=>'APPLIED','reason_code'=>null,'adapter'=>'titan-governance.escalation-target','governance_decision_ref'=>$decisionId,
            'authoritative_domain_receipt_ref'=>'governance://escalations/'.$escalationId.'/versions/'.$version,'write_verified'=>true,'entity_version'=>$version,
        ];
    }

    /** @return array<string,mixed> */
    private function blocked(string $reason): array{return ['schema_version'=>'1.0','status'=>'BLOCKED','reason_code'=>$reason,'write_verified'=>false];}
}
