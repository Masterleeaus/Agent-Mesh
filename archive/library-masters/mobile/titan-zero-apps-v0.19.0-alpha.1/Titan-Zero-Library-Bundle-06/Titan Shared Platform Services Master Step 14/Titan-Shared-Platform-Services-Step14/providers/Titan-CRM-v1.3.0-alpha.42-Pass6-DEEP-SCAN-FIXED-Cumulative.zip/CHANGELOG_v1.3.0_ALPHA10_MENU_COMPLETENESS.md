# CRM 1.3.0-alpha.10 — Core Menu Completeness

## Navigation language

- `CRM Settings` is now `Settings`.
- Menu labels no longer contain ampersands. Examples:
  - `Reviews and Recovery`
  - `Services and Catalogue`
  - `Fields and Tags`
  - `Privacy and Retention`

## Expanded parent navigation

Top-level business flow remains:

`Overview → Customers → Leads → Work → Money → Crew → Gear → Insights → Automate → Settings`

### Money

- Invoices
- Payments
- Titan Pay
- Receivables
- Collections
- Bookkeeping

### Crew

- Schedule
- Dispatch
- Timesheets
- Calendar

### Gear

- Gear Overview
- Inventory
- Stock Locations
- Stock Control
- Stock Reservations
- Reorder
- Suppliers
- Purchase Orders
- Goods Receipts
- Stock Counts
- Stock Transfers
- Tools
- Equipment
- Fleet Manager
- Maintenance
- Customer Assets

### Automate

- CRM Assistant
- Automations
- Integrations
- Chatbot Integration

## UI route correction

Purchase Orders, Goods Receipts, Stock Counts and Stock Transfers previously used browser menu routes whose controller methods returned JSON. Alpha.10 keeps the JSON/API endpoints but adds dedicated UI route aliases for navigation.

## Gear UI expansion

- Stock Locations now has an actual management card and location table.
- Goods Receipts now has a visible receipt history table.
- Dedicated Gear routes open the correct section on the Gear page.
- `Titan Locker` user-facing page title is now `Titan Gear`; internal Locker namespaces/tables remain stable.

## Crew

A Timesheets page now lists tenant-scoped job time entries and links each entry back to its job.

## Menu cache lifecycle

After CRM menu rows are synchronized, alpha.10 calls MagicAI `MenuService::regenerate()` when available. Failure to invalidate the host cache is non-fatal so extension installation cannot be blocked by a host cache implementation difference.
