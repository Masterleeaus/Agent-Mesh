<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Models\RewindCase;
use App\Extensions\TitanRewind\System\Models\RewindCaseTrace;
use App\Extensions\TitanRewind\System\Models\RewindRecoveryPlan;
use App\Extensions\TitanRewind\System\Models\RewindRecoveryStep;
use App\Extensions\TitanRewind\System\Recovery\RewindRecoveryPlanner;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer;
use App\Extensions\TitanRewind\System\Observability\RewindTraceContext;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class RewindRecoveryPlanService
{
    public function __construct(
        private RewindReconstructionService $reconstruction,
        private RewindRecoveryPlanner $planner,
        private RewindPayloadSanitizer $sanitizer,
        private RewindTelemetryService $telemetry,
        private RewindSignalOutboxService $signals,
    ) {}

    public function createForTrace(RewindTraceQuery $query, ?int $caseId = null, ?int $requestedById = null, array $options = []): RewindRecoveryPlan
    {
        $case = $this->resolveCase($query, $caseId);
        $cleanOptions = $this->sanitizer->sanitize($options);
        $commandInput = is_array($cleanOptions['command_input'] ?? null) ? $cleanOptions['command_input'] : [];
        $encodedCommandInput = json_encode($commandInput, JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        if (strlen($encodedCommandInput) > 20000) throw new InvalidArgumentException('Recovery command input exceeds the 20 KB planning limit.');
        $cleanOptions['command_input'] = $commandInput;
        if ($case) $cleanOptions['case_id'] = (int) $case->id;
        $trace = $this->reconstruction->reconstruct($query, true);
        if ((int) ($trace['event_count'] ?? 0) < 1) throw new InvalidArgumentException('Cannot create a recovery plan for an empty Rewind trace.');
        $plan = $this->planner->build($trace, $cleanOptions);
        $planHash = (string) ($plan['proposal_hash'] ?? '');
        if (preg_match('/^[a-f0-9]{64}$/', $planHash) !== 1) throw new InvalidArgumentException('Recovery planner did not produce a valid proposal hash.');
        $planKey = hash('sha256', implode('|', [(string) $query->tenantCompanyId(), $query->traceId(), (string) ($case?->id ?? 0), $planHash]));
        $status = ($plan['submission_ready'] ?? false) ? 'draft' : 'blocked';

        $record=DB::transaction(function () use ($query, $case, $requestedById, $plan, $planHash, $planKey, $status): RewindRecoveryPlan {
            $record = RewindRecoveryPlan::query()->firstOrCreate(
                ['plan_key'=>$planKey],
                [
                    'plan_uuid'=>(string) Str::uuid(),
                    'tenant_company_id'=>$query->tenantCompanyId(),
                    'case_id'=>$case?->id,
                    'trace_id'=>$query->traceId(),
                    'root_cause_event_id'=>$plan['root_cause_event_id'] ?? null,
                    'status'=>$status,
                    'risk_level'=>$plan['risk_level'],
                    'strategy'=>$plan['strategy'],
                    'proposed_capability'=>$plan['proposed_capability'],
                    'command_input'=>$plan['command_input'],
                    'plan'=>$plan,
                    'plan_hash'=>$planHash,
                    'blockers'=>$plan['blockers'],
                    'requested_by_id'=>$requestedById,
                ]
            );

            if (!$record->wasRecentlyCreated) return $record->load('steps','governanceReceipts');

            foreach ($plan['steps'] as $step) {
                RewindRecoveryStep::query()->create([
                    'step_uuid'=>(string) Str::uuid(),
                    'tenant_company_id'=>$query->tenantCompanyId(),
                    'recovery_plan_id'=>$record->id,
                    'step_order'=>(int) $step['step_order'],
                    'step_type'=>(string) $step['step_type'],
                    'status'=>'proposed',
                    'execution_owner'=>(string) $step['execution_owner'],
                    'requires_human'=>(bool) $step['requires_human'],
                    'input'=>$step['input'] ?? [],
                    'success_evidence'=>$step['success_evidence'] ?? [],
                ]);
            }

            return $record->load('steps','governanceReceipts');
        });
        $ctx=RewindTraceContext::fromArray(['tenant_company_id'=>$query->tenantCompanyId(),'trace_id'=>$query->traceId(),'correlation_id'=>$query->correlationId() ?: $query->traceId(),'causation_id'=>null]);
        $this->telemetry->metric('rewind.recovery.proposed',1,'count',$ctx,['risk_level'=>$record->risk_level,'status'=>$record->status]);
        $this->signals->emit('rewind.recovery.proposed.v1',$ctx,['plan_uuid'=>$record->plan_uuid,'plan_hash'=>$record->plan_hash,'risk_level'=>$record->risk_level,'status'=>$record->status]);
        return $record;
    }

    private function resolveCase(RewindTraceQuery $query, ?int $caseId): ?RewindCase
    {
        if ($caseId === null) return null;
        $case = RewindCase::query()->where('tenant_company_id',$query->tenantCompanyId())->whereKey($caseId)->first();
        if (!$case) throw new InvalidArgumentException('Recovery case does not exist inside the requested tenant boundary.');
        $linked = $case->primary_trace_id === $query->traceId() || RewindCaseTrace::query()->where('tenant_company_id',$query->tenantCompanyId())->where('case_id',$case->id)->where('trace_id',$query->traceId())->exists();
        if (!$linked) throw new InvalidArgumentException('Recovery case is not linked to the requested trace.');
        return $case;
    }
}
