# Titan CRM Core alpha.28 — Customer & Organisation Authority Report

## Authority boundary
CRM Core remains authoritative for customer, organisation, contact, lead, sales and commercial truth. This pass does not reclaim Titan Field, Locker, Ledger, Pay, Autonomy, AI planning, Workforce or Wisdom ownership.

## Identity model
`customer_unification_id` is a stable public CRM identity root. An organisation owns a root; contacts linked to it inherit that root; standalone contacts and leads receive independent roots until a governed conversion/merge establishes the surviving identity. Email, phone and external channel identifiers are stored separately and tenant-scoped.

## Duplicate safety
Strong duplicate candidates create durable review records. Blocking reviews stop Lead conversion until an operator resolves them. The evidence is fingerprinted; if the normalized identity evidence changes, a previous dismissal or use-existing decision is reopened automatically. Completed merges remain terminal.

## Merge evidence
Merge preview is non-mutating. Execution stores before-state snapshots, relationship summaries, before/after hashes and a structured rollback reference for Rewind. The rollback reference is forensic evidence; this release does not claim automatic destructive merge reversal.

## Conversion lineage
Lead conversion records whether it created or reused a customer identity root. Notes and tags are copied. Custom fields are mapped by field key into target subject-specific definitions and the exact source/target public IDs are recorded in `conversion_map`.

## Automated consumers
Chatbot, Titan Mobile/Hub and email matching resolve through the same root authority. Ambiguous matches fail closed rather than binding to the first database row.
