# Authorization Matrix

Authenticated tenant users may inspect tenant-scoped Nexus configuration artifacts subject to host policy. Admin routes require host admin middleware. Consequential provisioning requires Risk, Governance, Assurance, Signal and Rewind gates; agent/system initiated execution additionally requires Autonomy evidence. Cross-domain writes are Command Bus only.
