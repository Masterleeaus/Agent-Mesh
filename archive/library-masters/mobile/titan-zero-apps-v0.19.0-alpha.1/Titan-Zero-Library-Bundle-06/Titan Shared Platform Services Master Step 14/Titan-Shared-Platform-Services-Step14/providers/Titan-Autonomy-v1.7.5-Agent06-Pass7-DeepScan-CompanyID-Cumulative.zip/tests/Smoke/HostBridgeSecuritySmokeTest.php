<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableAssuranceBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableCommandBusBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableInteractionEngineBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableRewindBridge;
use App\Extensions\TitanAutonomy\System\Services\HostBridgeStatusService;

function assertTrue(bool $condition, string $message): void { if (!$condition) throw new RuntimeException($message); }

$assurance = new UnavailableAssuranceBridge();
$evaluation = $assurance->evaluate('crm.invoice.issue', 'completed_job_invoice', []);
assertTrue(($evaluation['status'] ?? null) === 'RED', 'unavailable Assurance must fail closed as RED');
assertTrue(in_array('ASSURANCE_BRIDGE_UNAVAILABLE', $evaluation['reason_codes'] ?? [], true), 'unavailable Assurance must explain denial');

$interaction = new UnavailableInteractionEngineBridge();
$journey = $interaction->prepareJourney('crm.invoice.issue', 'completed_job_invoice', []);
assertTrue(($journey['ready'] ?? true) === false, 'unavailable Interaction Engine must not report ready');

$threw = false;
try { (new UnavailableCommandBusBridge())->dispatch(new stdClass(), []); } catch (RuntimeException) { $threw = true; }
assertTrue($threw, 'unavailable CommandBus must refuse dispatch');

$rewind = new UnavailableRewindBridge();
assertTrue($rewind->available() === false, 'unavailable Rewind must report unavailable');

$status = (new HostBridgeStatusService($assurance, $interaction, new UnavailableCommandBusBridge(), $rewind))->status();
assertTrue($status['assurance']['available'] === false, 'status must identify fallback Assurance bridge');
assertTrue($status['command_bus']['available'] === false, 'status must identify fallback CommandBus bridge');

echo "OK: HostBridgeSecuritySmokeTest\n";
