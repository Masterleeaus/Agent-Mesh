# Titan Field — Agent Upgrade / Continuation Prompt

You are working on an EXISTING Titan Zero extension extracted from Titan CRM v1.3.0-alpha.23. **Do not rebuild it from scratch.** Deep scan the entire package before modifying anything and preserve working domain services, routes, migrations, UI, installer conventions and tenant isolation.

## Mission

Owns service requests, work orders, appointments, SchedulingKernel, dispatch, recurring service occurrences, field forms/submissions, field evidence, service areas, support/reviews/recovery and field-service vertical profiles.

## Non-negotiable Titan rules

1. `tenant_company_id` is the canonical tenant boundary. Never substitute CRM customer `company_id` or `user_id`.
2. AI does not write authoritative business state directly. Titan Field now exposes the domain-native `FieldCommandGateway`; consequential Field mutations must enter that governed boundary. Titan Command Bus, AI Workforce, CRM compatibility consumers and Titan Go may adapt to it, but must not write Field tables directly.
3. Important state changes emit Titan Signal-compatible events with `trace_id`, `correlation_id`, `causation_id`, and tenant identity.
4. External side effects must be idempotent.
5. Preserve Titan Rewind-compatible structured receipts; never store unrestricted hidden chain-of-thought.
6. Preserve installer compatibility and existing table data. This extraction intentionally retains the historical `crm_*` table names during the strangler migration. Do **not** rename/move tables destructively.
7. Maintain exactly one authoritative writer per domain. Do not reintroduce duplicate domain logic into CRM Core.
8. Prefer adapters/ports over cross-extension table writes.
9. Every exposed capability must declare owner, input/output contract, risk, autonomy, evidence, offline policy, reversibility, and idempotency.
10. Do not claim functionality exists unless implemented and tested.

## Current ownership

Owns service requests, work orders, appointments, SchedulingKernel, dispatch, recurring service occurrences, field forms/submissions, field evidence, service areas, support/reviews/recovery and field-service vertical profiles.

## Known transitional debt to remove safely

Legacy `crm.*` field capabilities may still be dispatched by CRM Core `CrmCapabilityExecutor` in older consumers, but Titan Field now resolves those names as aliases to canonical `titan.field.*` capabilities at its own command boundary. Move CRM chatbot/business-configuration/mobile consumers to `FieldCommandGateway`/explicit Field ports before deleting aliases.

## Required next-agent procedure

- Run syntax/tests/verifiers before edits and again after edits.
- Trace every cross-extension import. Replace direct cross-domain table reads with read/query ports before deleting compatibility aliases.
- Keep legacy `crm.*` capability names working until all consumers migrate; canonical new capability aliases may be introduced additively.
- If adopting existing tables, migrations must use `Schema::hasTable/hasColumn` and be safe on both upgraded and fresh installs.
- Never create a second writer as a migration shortcut.
- Update README, ownership map, changelog, capability manifest, agent prompt and CODEE artifact metadata on every cumulative release.

## Done when

The extension owns only its declared domain, can be installed/upgraded without data loss, integrates through governed contracts, and CRM Core no longer contains a second implementation of the same domain.

## Current cumulative programme

Stable PLAN_ID: `f739670d-d92b-49f0-97f4-4e2f191e6a3a`.

Passes 1–5 established the production-hardening baseline, Field-owned ports, fail-closed tenant/reference integrity, governed `titan.field.*` capability definitions, transactional Signal outbox, governed command gateway, durable idempotency receipts, and Field-owned permission aliases. Continue with Pass 6 (Advanced Recurrence + Availability / Blackout Policies); preserve legacy `crm.*` aliases and never bypass the command/integrity boundaries.

Titan Field owns and self-heals its extracted field/home-service navigation surfaces while preserving the historical CRM Laravel named routes. When a historical menu key is unknown or differs across CRM versions, adopt the existing host row by its canonical named route rather than creating a duplicate.
