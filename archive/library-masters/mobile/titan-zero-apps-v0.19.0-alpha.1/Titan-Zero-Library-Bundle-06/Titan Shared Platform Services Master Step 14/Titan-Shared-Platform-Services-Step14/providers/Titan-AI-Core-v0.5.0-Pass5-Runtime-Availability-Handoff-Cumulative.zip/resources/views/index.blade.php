@extends($hostLayout ?? 'titan-ai-core::layouts.standalone')

@section('title', 'Titan AI Core')

@section('content')
<div class="container-fluid titan-ai-core-card">
    <h1>Titan AI Core</h1>
    <p>Governed AI execution kernel — hardened foundation scaffold.</p>
    <pre>{{ json_encode($runtime, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) }}</pre>
</div>
@endsection
