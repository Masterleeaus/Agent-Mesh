<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Providers;

use App\Extensions\TitanConnect\System\Contracts\MessagingProvider;
use App\Extensions\TitanConnect\System\Contracts\MobilePushGateway;
use App\Extensions\TitanConnect\System\Contracts\ProviderHttpClient;
use InvalidArgumentException;

final class ProviderRegistry
{
    /** @var array<string, MessagingProvider> */
    private array $providers = [];

    public function __construct(ProviderHttpClient $http, MobilePushGateway $push)
    {
        foreach ([
            new WhatsAppProvider($http),
            new MessengerProvider($http),
            new InstagramProvider($http),
            new TelegramProvider($http),
            new SmsProvider($http),
            new PushProvider($http, $push),
            new VoiceProvider($http),
        ] as $provider) {
            $this->register($provider);
        }
    }

    public function register(MessagingProvider $provider): void
    {
        $this->providers[$provider->key()] = $provider;
    }

    public function get(string $key): MessagingProvider
    {
        $key = strtolower(trim($key));
        if (! isset($this->providers[$key])) {
            throw new InvalidArgumentException("Unknown Titan Connect messaging provider [{$key}].");
        }
        return $this->providers[$key];
    }

    /** @return array<string, MessagingProvider> */
    public function all(): array
    {
        return $this->providers;
    }

    public function keys(): array
    {
        return array_keys($this->providers);
    }
}
