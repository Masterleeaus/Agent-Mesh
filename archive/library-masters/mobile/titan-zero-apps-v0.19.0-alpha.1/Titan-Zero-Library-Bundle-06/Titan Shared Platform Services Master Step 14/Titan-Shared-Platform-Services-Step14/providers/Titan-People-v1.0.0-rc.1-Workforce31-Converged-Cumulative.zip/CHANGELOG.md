# Changelog

## 1.0.0-rc.1 — Pass 5 Production Hardening & Certification

- Added scheduled, overlap-safe, single-server durable Signal outbox dispatch with bounded batches.
- Hardened outbox receipt/failure mutations with explicit tenant scope.
- Hardened private document storage so all reads/writes/existence checks remain under `private/titan-people/`.
- Expanded upgrade, uninstall, operations and disaster-recovery runbooks for production recovery.
- Added Pass 5 regression coverage and final cumulative certification gates.

## 0.1.0-alpha.4
- Added tenant-scoped durable Signal outbox, privacy allowlisting, Rewind source contribution and host-pluggable receipt-based delivery.
- Added deterministic AI Workforce detectors for record, lifecycle, probation, leave, policy-acknowledgement and People-document exceptions.
- Added Command Bus-only proposal tools with independent approval and fail-closed Workforce task runtime.
- Added typed Time Attendance, Payroll, Credentials, Recruit, Performance, Onboarding and Communications integration ports with no peer private-table access.
- Added idempotent proactive responsibility planning with severity-based escalation.
- Wired accepted employment lifecycle transitions to privacy-minimized durable Signal facts.

## 0.1.0-alpha.3
- Added real authenticated Overview, People Directory, Person detail/edit, Organisation, Leave & Absence, Holidays, Lifecycle and My Profile surfaces.
- Added Step 10 host-authorization middleware and trusted People execution-context construction for browser and API requests.
- Added actor-derived self-service profile updates with strict personal-field allowlisting and no caller-controlled worker/tenant authority.
- Added protected manager-edit boundaries for lifecycle, organisation authority, leave balances, host credentials/avatar and tenant/worker identity.
- Added `/api/v1/titan-people` read/self-service contracts using opaque People IDs and bounded pagination (25 default, 100 maximum).
- Completed People navigation with seven real child pages and retained idempotent host menu/cache repair.

## 0.1.0-alpha.2
- Added governed, idempotent employment lifecycle command services with optimistic concurrency and database-backed append-only event persistence.
- Added tenant-scoped private profile/emergency-contact persistence and field-level sensitive-profile policy.
- Added private HR document/revision persistence, private filesystem port, SHA-256 integrity, traversal/size/MIME/content-signature controls and cross-tenant access checks.
- Added tenant-scoped leave types/requests, append-only leave ledger, reconciled balance cache, idempotent accrual and self-approval prevention.
- Added tenant/team/location/worker holiday applicability and privacy-minimized absence read model.
- Added typed People Command Bus/governance ports, fail-closed defaults and canonical Manifest 2.2 capability contracts for governed mutations.
- Removed `tenant_company_id` from mass-assignable fields across People models, including the Pass 1 Worker model.

## 0.1.0-alpha.1
- Blueprint v4 Step 10 / Manifest 2.2 shell.
- Canonical tenant-scoped People worker identity.
- Organisation and employment foundation.
- Explicit HRCore import boundary.
- Navigation/authorization baseline.
- Workforce Manifest 2.0 foundation.
