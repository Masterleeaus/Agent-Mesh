# Titan Signal Engine v0.11.0 — Production Hardening Pass 3

## Atomic Subscriber Delivery & Concurrency Hardening

This cumulative pass removes read-modify-save ownership races from subscriber delivery.

### Added

- Atomic delivery leases with token, owner, expiry, processing timestamp, and claim generation.
- Compare-and-set claim and terminal transition service.
- Expired-lease recovery and safe reclaim.
- Queue execution tokens propagated into transport-failure callbacks.
- Stable per-delivery subscriber idempotency key.
- Retry/dead-letter transitions that reject stale workers.
- Additive migration that converts pre-lease `processing` rows into recoverable `retry_wait` rows.
- Host-Laravel integration tests for claim exclusivity, stale-worker rejection, expired lease recovery, and retry idempotency context.

### Delivery guarantee

Signal distribution remains at-least-once. The ledger guarantees single active lease ownership; consequential subscribers must deduplicate side effects by `signal-delivery:<delivery_id>`.
