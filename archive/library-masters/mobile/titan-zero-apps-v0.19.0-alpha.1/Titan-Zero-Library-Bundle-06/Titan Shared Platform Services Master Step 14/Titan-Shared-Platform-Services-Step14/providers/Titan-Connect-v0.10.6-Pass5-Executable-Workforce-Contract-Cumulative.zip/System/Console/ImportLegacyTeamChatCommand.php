<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Console;

use App\Extensions\TitanConnect\System\Services\Legacy\LegacyTeamChatImporter;
use Illuminate\Console\Command;

final class ImportLegacyTeamChatCommand extends Command
{
    protected $signature = 'titan-connect:import-legacy-team-chat {--force : Run even when no operator confirmation is available}';
    protected $description = 'Idempotently import legacy Chatbot Team Chat rows into Titan Connect canonical tables.';

    public function handle(LegacyTeamChatImporter $importer): int
    {
        $result = $importer->import();
        $this->line(json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        return ($result['status'] ?? null) === 'ok' || ($result['status'] ?? null) === 'skipped' ? self::SUCCESS : self::FAILURE;
    }
}
