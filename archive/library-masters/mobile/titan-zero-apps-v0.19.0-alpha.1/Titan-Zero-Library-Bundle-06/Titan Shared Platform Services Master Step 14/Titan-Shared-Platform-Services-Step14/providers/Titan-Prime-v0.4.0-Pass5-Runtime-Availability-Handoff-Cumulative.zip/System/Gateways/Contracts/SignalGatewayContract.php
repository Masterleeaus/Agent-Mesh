<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Contracts;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;

interface SignalGatewayContract extends EngineGatewayContract
{
    /** @param array<string,mixed> $payload */
    public function publish(TraceContext $trace, string $signalName, array $payload, string $operationId): EngineGatewayResult;
}
