<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\TitanAutonomy;

interface CrmAutonomyDecisionPort
{
    public function workflowKey(string $capability): string;

    /** @return array<string,mixed> */
    public function decision(int $actorUserId, int $companyId, string $capability, string $workflowKey): array;
}
