<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\DTO;

final readonly class AutonomyDecision
{
    /**
     * @param array<int,string> $evidenceReferences
     */
    public function __construct(
        public bool $allowed,
        public ?string $reference,
        public ?string $level,
        public ?string $workflowKey = null,
        public array $evidenceReferences = [],
        public ?string $reasonCode = null,
    ) {}

    public static function unavailable(): self
    {
        return new self(false, null, null, null, [], 'AUTONOMY_UNAVAILABLE');
    }
}
