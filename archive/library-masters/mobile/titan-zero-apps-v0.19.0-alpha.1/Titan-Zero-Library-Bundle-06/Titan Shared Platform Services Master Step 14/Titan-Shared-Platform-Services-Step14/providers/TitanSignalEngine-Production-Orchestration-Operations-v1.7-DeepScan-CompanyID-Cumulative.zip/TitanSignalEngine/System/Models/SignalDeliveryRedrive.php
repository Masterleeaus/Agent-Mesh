<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use App\Extensions\TitanSignalEngine\System\Exceptions\ImmutableSignalDeliveryRedriveException;
use Illuminate\Database\Eloquent\Model;

final class SignalDeliveryRedrive extends Model
{
    protected $table = 'titan_signal_delivery_redrives';
    protected $guarded = [];
    protected $casts = [
        'tenant_company_id' => 'integer',
        'redrive_count' => 'integer',
        'failed_attempt_count' => 'integer',
        'dead_lettered_at' => 'immutable_datetime',
        'requested_at' => 'immutable_datetime',
    ];

    protected static function booted(): void
    {
        static::updating(static function (): never {
            throw new ImmutableSignalDeliveryRedriveException('Signal delivery redrive audit records are immutable.');
        });
        static::deleting(static function (): never {
            throw new ImmutableSignalDeliveryRedriveException('Signal delivery redrive audit records cannot be deleted through the application model.');
        });
    }
}
