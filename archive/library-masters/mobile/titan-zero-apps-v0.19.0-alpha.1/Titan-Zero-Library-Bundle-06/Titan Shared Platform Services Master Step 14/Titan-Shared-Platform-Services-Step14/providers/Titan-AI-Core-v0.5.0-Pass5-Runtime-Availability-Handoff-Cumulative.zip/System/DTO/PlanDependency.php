<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class PlanDependency { public function __construct(public string $stepId, public string $type = 'hard') {} public function toArray(): array { return ['step_id'=>$this->stepId,'type'=>$this->type]; } }
