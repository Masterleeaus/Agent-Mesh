<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\StrictBoolean;
use InvalidArgumentException;

final class RiskDecision
{
    public function __construct(
        private readonly bool $allowed,
        private readonly string $decisionReference,
        private readonly string $riskClass,
        private readonly string $requiredAssurance,
        private readonly ?string $reason = null,
    ) {
        self::assertText($this->decisionReference, 'decision_reference');
        if (!in_array($this->riskClass, ['MINIMAL','LOW','MEDIUM','HIGH','EXTREME','contextual'], true)) {
            throw new InvalidArgumentException('risk_class is invalid.');
        }
        if (!in_array($this->requiredAssurance, ['NONE','RED','AMBER','GREEN','policy'], true)) {
            throw new InvalidArgumentException('required_assurance is invalid.');
        }
        if ($this->reason !== null) { self::assertText($this->reason, 'reason', 1000); }
    }
    /** @param array<string,mixed> $data */
    public static function fromArray(array $data): self
    {
        return new self(
            StrictBoolean::parse($data['allowed'] ?? false, 'allowed'),
            self::required($data['decision_reference'] ?? null, 'decision_reference'),
            self::required($data['risk_class'] ?? null, 'risk_class'),
            self::required($data['required_assurance'] ?? null, 'required_assurance'),
            self::nullable($data['reason'] ?? null),
        );
    }
    public function allowed(): bool { return $this->allowed; }
    public function decisionReference(): string { return $this->decisionReference; }
    public function riskClass(): string { return $this->riskClass; }
    public function requiredAssurance(): string { return $this->requiredAssurance; }
    public function reason(): ?string { return $this->reason; }
    /** @return array<string,mixed> */
    public function toArray(): array { return ['allowed'=>$this->allowed,'decision_reference'=>$this->decisionReference,'risk_class'=>$this->riskClass,'required_assurance'=>$this->requiredAssurance,'reason'=>$this->reason]; }
    private static function required(mixed $v,string $f): string { if(!is_string($v)||trim($v)===''){throw new InvalidArgumentException("{$f} is required.");} return trim($v); }
    private static function nullable(mixed $v): ?string { if($v===null)return null; if(!is_string($v))throw new InvalidArgumentException('reason must be string or null.'); return trim($v); }
    private static function assertText(string $v,string $f,int $m=300): void { if(trim($v)===''||strlen($v)>$m)throw new InvalidArgumentException("{$f} is invalid."); }
}
