<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Context;

use InvalidArgumentException;

final readonly class PeopleExecutionContext
{
    public function __construct(
        public int $tenantCompanyId,
        public string|int $actorSubject,
        public string $traceId,
        public string $correlationId,
        public ?string $causationId = null,
    ) {
        if ($tenantCompanyId <= 0) {
            throw new InvalidArgumentException('tenant_company_id must be a positive authenticated tenant identifier.');
        }
        if ((string) $actorSubject === '') {
            throw new InvalidArgumentException('actor subject is required.');
        }
        if ($traceId === '' || $correlationId === '') {
            throw new InvalidArgumentException('trace_id and correlation_id are required.');
        }
    }
}
