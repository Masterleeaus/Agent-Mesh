<?php
declare(strict_types=1);
namespace App\Extensions\TitanCommandBus\System\DTO;
final readonly class ApprovalDecision {
    public function __construct(public bool $allowed, public ?string $reference, public ?string $scopeHash = null, public ?string $expiresAt = null, public array $evidenceReferences = [], public ?string $reasonCode = null) {}
    public static function unavailable(): self { return new self(false, null, null, null, [], 'APPROVAL_UNAVAILABLE'); }
}
