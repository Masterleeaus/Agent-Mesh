<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$passes = [];
$failures = [];
$read = static fn (string $path): string => is_file($root.'/'.$path) ? (string) file_get_contents($root.'/'.$path) : '';
$check = static function (bool $condition, string $name) use (&$passes, &$failures): void {
    if ($condition) $passes[] = $name; else $failures[] = $name;
};

$command = $read('System/Console/CertifyTitanConnectCommand.php');
$orchestrator = $read('System/Services/HostCertificationService.php');
$integrations = $read('System/Services/IntegrationReadinessService.php');
$queueJob = $read('System/Certification/CertificationQueueProbeJob.php');
$queueProbe = $read('System/Certification/QueueExecutionProbe.php');
$broadcastEvent = $read('System/Certification/CertificationBroadcastProbe.php');
$broadcastProbe = $read('System/Certification/BroadcastExecutionProbe.php');
$isolation = $read('System/Certification/CompanyIsolationProbe.php');
$provider = $read('System/TitanConnectServiceProvider.php');
$config = $read('config/titan-connect.php');
$hostDoc = $read('docs/HOST_CERTIFICATION.md');
$manifest = $read('extension.json');
$readiness = $read('System/Services/HostReadinessService.php');

$check(str_contains($command, 'titan-connect:certify') && str_contains($command, '--queue-probe') && str_contains($command, '--broadcast-probe') && str_contains($command, '--two-company-probe'), 'CERT command exposes explicit runtime probes');
$check(str_contains($command, '--strict') && str_contains($command, '--output='), 'CERT command supports strict mode and report output');
$check(str_contains($orchestrator, 'HostReadinessService') && str_contains($orchestrator, 'IntegrationReadinessService'), 'CERT orchestrator composes readiness and integration checks');
$check(str_contains($orchestrator, 'queueProbe') && str_contains($orchestrator, 'broadcastProbe') && str_contains($orchestrator, 'companyIsolationProbe'), 'CERT orchestrator can run all optional probes');
$check(str_contains($integrations, 'titan-connect.workcore.authorize') && str_contains($integrations, 'titan-connect.chatbot.inbound') && str_contains($integrations, 'titan-connect.mobile.push'), 'CERT integration readiness checks host bridge listeners');
$check(str_contains($queueJob, 'ShouldQueue') && str_contains($queueJob, 'company') === false && str_contains($queueJob, 'Cache::put'), 'CERT queue probe job is side-effect bounded to cache');
$check(str_contains($queueProbe, 'CertificationQueueProbeJob') && str_contains($queueProbe, 'timeout'), 'CERT queue execution probe waits for worker acknowledgement');
$check(str_contains($broadcastEvent, 'ShouldBroadcastNow') && str_contains($broadcastEvent, 'titan-connect.certification'), 'CERT broadcast probe is isolated from company channels');
$check(str_contains($broadcastProbe, 'CertificationBroadcastProbe') && str_contains($broadcastProbe, 'broadcast('), 'CERT broadcast execution probe publishes through host driver');
$check(str_contains($isolation, 'beginTransaction') && str_contains($isolation, 'rollBack') && str_contains($isolation, 'forCompany'), 'CERT two-company isolation probe always rolls back and uses company scopes');
$check(str_contains($provider, 'CertifyTitanConnectCommand::class'), 'CERT command is registered by service provider');
$check(str_contains($config, "'certification'") && str_contains($config, "'probe_timeout_seconds'"), 'CERT configuration is packaged');
$check(str_contains($readiness, "'ext_titan_connect_participants'") && !str_contains($readiness, "'ext_titan_connect_conversation_participants'"), 'CERT readiness uses canonical participant table name');
$check(str_contains($readiness, "'ext_titan_connect_external_thread_tags'"), 'CERT readiness includes company-scoped thread tag pivot');
$check(str_contains($hostDoc, 'titan-connect:certify') && str_contains($hostDoc, '--two-company-probe') && str_contains($hostDoc, '--strict'), 'CERT runbook documents executable certification');
$check(str_contains($manifest, '0.10.6'), 'CERT release manifest is v0.10.6');

foreach ($passes as $pass) echo "PASS {$pass}\n";
if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL {$failure}\n");
    fwrite(STDERR, sprintf("\n%d failed; %d passed.\n", count($failures), count($passes)));
    exit(1);
}

echo sprintf("\nOK Titan Connect runtime-certification contract suite: %d passed.\n", count($passes));
