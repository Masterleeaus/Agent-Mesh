# Changelog

## 1.5.2 - Titan installer contract
- Repackaged as flat-root `titan-extension-v1`.
- Added installer dependency/platform metadata and production integrity map.
- Replaced generic publish tag with `titan-ai-config`.

## 1.5.0 - 2026-08-09

- Centralized MagicAI provider/model execution in `MagicAIHostProviderGateway`.
- Added `ProviderExecutionRegistry` and provider-independent runtime streaming delegation.
- Added OpenAI, Anthropic, Gemini, DeepSeek and xAI host engine paths.
- Added server/client trusted-tool execution modes.
- Preserved OpenAI tool-call protocol metadata across streamed continuation turns.
- Added principal/company validation and preflight host credit checks before provider execution.
- Moved request conversation history into canonical runtime context and ordered trusted system context ahead of history.
- Made `magicai-host` the default provider while keeping governance model review on its explicit OpenAI Responses profile.
- Normalized stream finalization so content/generative-UI events are emitted once and failed runs terminate with `run.failed` rather than contradictory `run.completed`.

## 1.4.0 - 2026-08-09

- Added concurrent `ConversationSourceRegistry` integration for multiple AI surfaces.
- Added source-specific capability, tool and deterministic business-action policy.
- Added trusted static/dynamic tool contribution registry; request-supplied tool schemas remain rejected.
- Added principal/actor identity context for staff and autonomous workflow sources.
- Added server-side source context registration and source-aware deployment resolution.
- Added MagicAI server credential fallback for the OpenAI-compatible provider and best-effort usage/credit recording.
- Integrated AIChatPro as the authenticated staff source and AI Agent/AI Agent Copilot as workflow sources.
- Prevented Copilot/workflow-builder prompts from invoking deterministic WorkCore business actions without explicit source permission.

## 1.3.0 - 2026-08-09

- Standardised TitanAI on positive integer `company_id` as the single tenant boundary.
- Removed runtime/controller fallback to legacy `tenant_id`.
- Changed `TitanAIRequest` and governance council context to carry canonical `companyId` values.
- Scoped approval execution receipt updates by both `company_id` and approval ID.
- Propagated `company_id` through direct WorkCore worker metadata and governed WorkCore calls.
- Changed governed-memory maintenance filtering from `--tenant` to `--company`.
- Updated fresh-install governance migrations to create `company_id` columns.
- Added a forward-only migration that validates legacy boundary values and materializes them into indexed, non-null `unsignedBigInteger company_id` columns before removing the legacy column.
- Added dedicated company-boundary documentation and cross-company production verification gates.

## 1.2.0 - 2026-08-09

- Consolidated all human-facing documentation beneath `docs/`; removed root documentation and standalone `host-patches/`.
- Removed development-only tests, verification tooling and internal execution plans from the production ZIP while retaining release evidence in `docs/`.
- Rejected caller-supplied `assistant_deployment` payload definitions; trusted host/default deployment resolution is now mandatory.
- Stopped promoting tool permission IDs into assistant capability IDs.
- Restricted capability output to registered capability definitions.
- Removed unused raw provider/adapter response retention from the normalized conversation engine.
- Extended runtime-disable semantics to direct governed execution, approval execution and rollback execution.
- Updated manifest metadata, schema location, operations/security docs and release verification.
- Corrected governed-memory encryption metadata to avoid claiming application-layer encryption that the current JSON persistence does not provide.

## 1.1.0 - 2026-08-09

- Enforced explicit runtime disable behavior before provider or WorkCore execution.
- Made governance fail closed when governance is disabled.
- Replaced synthetic rollback operation names with explicit canonical WorkCore rollback mappings.
- Moved remote rollback execution outside database transactions and added retry/replay metadata with stable idempotency.
- Fixed rollback actor context by passing validated `user_id` and `company_id`.
- Removed request-controlled provider tool schemas and wired permission-filtered TitanAI tool context.
- Expanded diagnostics for runtime, provider credential, WorkCore mapping and rollback readiness.
- Added post-conversion and conversational-tool security regression tests.

## 1.0.0 - 2026-08-09

- Converted Titan AI Runtime extraction to a native MagicAI extension package.
- Added MagicAI lifecycle manifests/provider and hardened sidecar metadata.
- Converged TitanAI-owned namespaces and removed extraction classmaps/nested extension identities.
- Merged governance and repaired approval/idempotency execution.
- Externalized WorkCore behind a canonical bridge.
- Removed direct Chatbot coupling.
- Hardened provider endpoints/credentials.
- Generalized the intent kernel beyond the cleaning-only extraction while retaining compatibility aliases.
- Added standalone architecture/security/runtime/worker/WorkCore boundary verification.

## 1.5.3 — Workforce Runtime Compatibility

- Raised package identity from 1.5.2 to 1.5.3 to satisfy Titan AI Workforce's established dependency floor without lowering that requirement.
- Added a machine-readable Workforce runtime/provider/model compatibility contract.
- Added SHA-256 preservation verification proving all 330 supplied runtime PHP files are unchanged from 1.5.2.
- No runtime/provider/model execution behavior or authority policy changed.
