<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Host\TitanProviderBootPreflight;

$root = $argv[1] ?? dirname(__DIR__);
$output = $argv[2] ?? null;

require_once rtrim($root, '/\\') . '/System/Host/TitanProviderBootPreflight.php';

$report = TitanProviderBootPreflight::inspect($root);
$report['generated_at'] = gmdate('c');
$report['root_basename'] = basename(rtrim($root, '/\\'));

$json = json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . PHP_EOL;
if (is_string($output) && trim($output) !== '') {
    file_put_contents($output, $json);
}
echo $json;
exit(($report['status'] ?? 'FAIL') === 'PASS' ? 0 : 1);
