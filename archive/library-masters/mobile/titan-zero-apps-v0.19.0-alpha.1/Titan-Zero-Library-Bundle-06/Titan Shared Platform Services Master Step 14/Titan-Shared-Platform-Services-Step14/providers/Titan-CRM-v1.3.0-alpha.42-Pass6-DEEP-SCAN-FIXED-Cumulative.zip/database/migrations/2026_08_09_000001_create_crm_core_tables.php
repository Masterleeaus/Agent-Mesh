<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
  Schema::create('crm_companies',function(Blueprint $t){$t->id();$t->unsignedBigInteger('user_id')->index();$t->string('name');$t->string('website')->nullable();$t->string('email')->nullable();$t->string('phone')->nullable();$t->json('meta')->nullable();$t->timestamps();});
  Schema::create('crm_contacts',function(Blueprint $t){$t->id();$t->unsignedBigInteger('user_id')->index();$t->unsignedBigInteger('company_id')->nullable()->index();$t->string('first_name');$t->string('last_name')->nullable();$t->string('email')->nullable()->index();$t->string('phone')->nullable();$t->json('meta')->nullable();$t->timestamps();});
  Schema::create('crm_leads',function(Blueprint $t){$t->id();$t->unsignedBigInteger('user_id')->index();$t->string('name');$t->string('email')->nullable();$t->string('phone')->nullable();$t->string('status')->default('new');$t->string('source')->nullable();$t->json('meta')->nullable();$t->timestamps();});
  Schema::create('crm_pipelines',function(Blueprint $t){$t->id();$t->unsignedBigInteger('user_id')->index();$t->string('name');$t->boolean('is_default')->default(false);$t->timestamps();});
  Schema::create('crm_pipeline_stages',function(Blueprint $t){$t->id();$t->unsignedBigInteger('pipeline_id')->index();$t->string('name');$t->unsignedInteger('position')->default(0);$t->timestamps();});
  Schema::create('crm_deals',function(Blueprint $t){$t->id();$t->unsignedBigInteger('user_id')->index();$t->unsignedBigInteger('company_id')->nullable()->index();$t->unsignedBigInteger('contact_id')->nullable()->index();$t->unsignedBigInteger('pipeline_id')->nullable()->index();$t->unsignedBigInteger('stage_id')->nullable()->index();$t->string('name');$t->bigInteger('value_minor')->default(0);$t->string('currency',3)->default('AUD');$t->string('status')->default('open');$t->json('meta')->nullable();$t->timestamps();});
  Schema::create('crm_activities',function(Blueprint $t){$t->id();$t->unsignedBigInteger('user_id')->index();$t->string('subject_type')->nullable();$t->unsignedBigInteger('subject_id')->nullable();$t->string('type')->default('note');$t->text('body')->nullable();$t->timestamp('occurred_at')->nullable();$t->timestamps();$t->index(['subject_type','subject_id']);});
  foreach(['projects','tasks','events','products','documents'] as $name){ Schema::create('crm_'.$name,function(Blueprint $t) use($name){$t->id();$t->unsignedBigInteger('user_id')->index();$t->string('name');$t->string('status')->nullable();$t->json('meta')->nullable();$t->timestamps();}); }
 }
 public function down(): void { foreach(['crm_documents','crm_products','crm_events','crm_tasks','crm_projects','crm_activities','crm_deals','crm_pipeline_stages','crm_pipelines','crm_leads','crm_contacts','crm_companies'] as $table){ Schema::dropIfExists($table); } }
};
