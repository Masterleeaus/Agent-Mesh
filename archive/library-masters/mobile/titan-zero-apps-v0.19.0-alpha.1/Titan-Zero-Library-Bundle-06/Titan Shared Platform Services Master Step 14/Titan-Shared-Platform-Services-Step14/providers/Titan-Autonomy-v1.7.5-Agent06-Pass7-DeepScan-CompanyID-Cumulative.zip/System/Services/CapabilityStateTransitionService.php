<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\OutcomeObservation;
use App\Extensions\TitanAutonomy\System\DTOs\StateTransitionResult;
use App\Extensions\TitanAutonomy\System\Enums\UserResponseClass;

final class CapabilityStateTransitionService
{
    public function __construct(private readonly SuccessStreakService $streaks = new SuccessStreakService()) {}

    public function recordOutcome(CapabilityState $state, OutcomeObservation $outcome): StateTransitionResult
    {
        $result = $this->streaks->apply(
            $state->currentSuccessStreak,
            $outcome->userResponse,
            $outcome->minorEditQualifies,
            $outcome->executionSucceeded,
            $outcome->reversed,
            $outcome->unresolvedAssuranceIncident,
        );

        $isEdit = in_array($outcome->userResponse, [
            UserResponseClass::ApprovedMinorEdit,
            UserResponseClass::ApprovedMaterialEdit,
        ], true);

        $isFailure = !$outcome->executionSucceeded || $outcome->userResponse === UserResponseClass::Failed;
        $isRejected = $outcome->userResponse === UserResponseClass::Rejected;
        $isReversed = $outcome->reversed || $outcome->userResponse === UserResponseClass::Reversed;

        $newStreak = $result['streak'];
        $newState = new CapabilityState(
            tenantCompanyId: $state->tenantCompanyId,
            capability: $state->capability,
            workflowKey: $state->workflowKey,
            risk: $state->risk,
            currentLevel: $state->currentLevel,
            requiredSuccessStreak: $state->requiredSuccessStreak,
            currentSuccessStreak: $newStreak,
            highestSuccessStreak: max($state->highestSuccessStreak, $newStreak),
            totalSuccesses: $state->totalSuccesses + ($result['qualifying'] ? 1 : 0),
            totalFailures: $state->totalFailures + ($isFailure ? 1 : 0),
            totalEdits: $state->totalEdits + ($isEdit ? 1 : 0),
            totalRejections: $state->totalRejections + ($isRejected ? 1 : 0),
            totalReversals: $state->totalReversals + ($isReversed ? 1 : 0),
            platformGateEligible: $state->platformGateEligible,
            scope: $state->scope,
            lastSuccessAt: $result['qualifying'] ? gmdate('Y-m-d H:i:s') : $state->lastSuccessAt,
            lastFailureAt: (!$result['qualifying'] && ($isFailure || $isRejected || $isReversed || $isEdit)) ? gmdate('Y-m-d H:i:s') : $state->lastFailureAt,
        );

        return new StateTransitionResult($newState, $result['label'], $result['qualifying']);
    }
}
