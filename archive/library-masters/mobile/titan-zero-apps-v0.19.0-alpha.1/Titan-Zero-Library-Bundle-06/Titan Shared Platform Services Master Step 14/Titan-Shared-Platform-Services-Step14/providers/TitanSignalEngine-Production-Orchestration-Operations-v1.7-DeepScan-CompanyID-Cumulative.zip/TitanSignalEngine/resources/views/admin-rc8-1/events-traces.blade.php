@extends('panel.layout.app')
@section('content')
@php
    $req=$dashboard['request'] ?? [];
    $hidden=['scope'=>$req['scope']??'system','tenant_company_id'=>$req['tenant_company_id']??null,'window'=>$req['window']??'5m','limit'=>$req['limit']??100];
    $pageTitle='Events and Traces';$pageSubtitle='Event lookup, trace explorer, workflow correlation and causal timeline';$activePage='events-traces';
@endphp
@include('titan-signal-engine::admin-rc8-1.partials.styles')
<div class="tse-wrap">
@include('titan-signal-engine::admin-rc8-1.partials.header')
@include('titan-signal-engine::admin-rc8-1.partials.alerts')
@include('titan-signal-engine::admin-rc8-1.partials.filter')
<div class="tse-grid tse-section">
    <div class="tse-card"><h2>Trace explorer</h2><form method="GET">@foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<div class="tse-stack"><label>Trace ID<input class="tse-input tse-code" name="trace_id" placeholder="UUID"></label><label>Profile key<input class="tse-input" name="profile_key" placeholder="e.g. governed.command"></label><label>Profile version<input class="tse-input" type="number" min="1" name="profile_version"></label><button class="tse-btn tse-btn-primary" type="submit">Open trace</button></div></form></div>
    <div class="tse-card"><h2>Workflow explorer</h2><form method="GET">@foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<div class="tse-stack"><label>Correlation ID<input class="tse-input tse-code" name="correlation_id" placeholder="UUID"></label><button class="tse-btn tse-btn-primary" type="submit">Open workflow</button></div></form></div>
    <div class="tse-card"><h2>Event lookup</h2><form method="GET">@foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<div class="tse-stack"><label>Event ID<input class="tse-input tse-code" name="event_id" placeholder="UUID"></label><button class="tse-btn tse-btn-primary" type="submit">Open event</button></div></form></div>
</div>
@if($detail)
<div class="tse-card tse-section">
    <h2>{{ ucfirst($detail['kind']) }} detail</h2><div class="tse-code">{{ $detail['id'] }}</div>
    @if(in_array($detail['kind'],['trace','workflow'],true))
        @php $d=$detail['data'] ?? []; @endphp
        <div class="tse-grid tse-section"><div class="tse-kpi"><div class="tse-kpi-label">Returned events</div><div class="tse-value">{{ $d['returned_event_count'] ?? 0 }}</div></div><div class="tse-kpi"><div class="tse-kpi-label">Total events</div><div class="tse-value">{{ $d['total_event_count'] ?? 0 }}</div></div><div class="tse-kpi"><div class="tse-kpi-label">Status</div><div class="tse-value-sm">{{ strtoupper((string)($d['analysis']['status'] ?? 'unknown')) }}</div></div><div class="tse-kpi"><div class="tse-kpi-label">Truncated</div><div class="tse-value-sm">{{ !empty($d['truncated']) ? 'YES' : 'NO' }}</div></div></div>
        <h3>Timeline</h3><div class="tse-scroll"><table class="tse-table"><thead><tr><th>Occurred</th><th>Event</th><th>Severity</th><th>Source</th><th>Event ID</th><th>Causation</th></tr></thead><tbody>@forelse(($d['events'] ?? []) as $e)<tr><td>{{ $e['occurred_at'] ?? '—' }}</td><td class="tse-code">{{ $e['event_type'] ?? '—' }}</td><td>{{ $e['severity'] ?? '—' }}</td><td>{{ $e['source'] ?? '—' }}</td><td class="tse-code">{{ $e['event_id'] ?? '—' }}</td><td class="tse-code">{{ $e['causation_id'] ?? '—' }}</td></tr>@empty<tr><td colspan="6">No events returned.</td></tr>@endforelse</tbody></table></div>
        @if(!empty($d['edges']))<h3>Causal edges</h3><div class="tse-scroll"><table class="tse-table"><thead><tr><th>Parent</th><th>Child</th><th>Storage</th></tr></thead><tbody>@foreach($d['edges'] as $edge)<tr><td class="tse-code">{{ $edge['parent_event_id'] ?? $edge['parent'] ?? '—' }}</td><td class="tse-code">{{ $edge['child_event_id'] ?? $edge['child'] ?? '—' }}</td><td>{{ $edge['storage'] ?? $edge['storage_tier'] ?? '—' }}</td></tr>@endforeach</tbody></table></div>@endif
    @elseif($detail['kind']==='event')
        @if($detail['data'])
            <pre class="tse-pre tse-section">{{ json_encode($detail['data'],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre>
            <div class="tse-two tse-section">
                <div class="tse-card tse-card-soft"><h3>Legal hold</h3><form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.events.legal-hold',['eventId'=>$detail['id']]) }}">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input type="hidden" name="hold" value="1"><div class="tse-stack"><input class="tse-input" name="reason" required maxlength="255" placeholder="Reason"><button class="tse-btn" type="submit">Apply hold</button></div></form><form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.events.legal-hold',['eventId'=>$detail['id']]) }}" style="margin-top:10px">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input type="hidden" name="hold" value="0"><div class="tse-stack"><input class="tse-input" name="reason" required maxlength="255" placeholder="Release reason"><button class="tse-btn" type="submit">Release hold</button></div></form></div>
                <div class="tse-card tse-card-soft"><h3>Privacy and correction</h3><form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.events.redact',['eventId'=>$detail['id']]) }}">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<div class="tse-stack"><select class="tse-select" name="operation"><option value="remove">Remove</option><option value="replace">Replace</option></select><input class="tse-input" name="path" required placeholder="payload.customer.email"><input class="tse-input" name="value" placeholder="Replacement value"><input class="tse-input" name="reason" required maxlength="255" placeholder="Governed reason"><button class="tse-btn" type="submit">Apply redaction</button></div></form><form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.events.correct',['eventId'=>$detail['id']]) }}" style="margin-top:10px">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input type="hidden" name="operation" value="replace"><div class="tse-stack"><input class="tse-input" name="path" required placeholder="payload.field"><input class="tse-input" name="value" required placeholder="Corrected value"><input class="tse-input" name="reason" required maxlength="255" placeholder="Correction reason"><button class="tse-btn" type="submit">Apply correction</button></div></form></div>
            </div>
        @else<p>No event found in the selected scope.</p>@endif
    @endif
</div>
@endif
</div>
@endsection
