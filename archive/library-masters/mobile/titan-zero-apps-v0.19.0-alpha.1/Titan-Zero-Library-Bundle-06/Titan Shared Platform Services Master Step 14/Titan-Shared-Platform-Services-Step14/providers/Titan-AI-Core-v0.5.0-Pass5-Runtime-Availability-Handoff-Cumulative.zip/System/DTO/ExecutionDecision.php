<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class ExecutionDecision { public function __construct(public string $decision, public string $reasonCode, public bool $humanApprovalRequired = false) {} }
