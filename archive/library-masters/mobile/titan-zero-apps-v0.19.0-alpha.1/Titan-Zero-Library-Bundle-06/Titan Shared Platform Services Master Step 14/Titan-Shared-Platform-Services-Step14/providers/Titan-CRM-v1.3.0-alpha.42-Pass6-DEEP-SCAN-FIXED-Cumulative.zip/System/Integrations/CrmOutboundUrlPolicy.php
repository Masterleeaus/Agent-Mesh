<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations;

final class CrmOutboundUrlPolicy
{
    /** @return list<string> */
    public function assertAllowed(string $url): array
    {
        $parts = parse_url($url);
        if (! is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https' || empty($parts['host'])) {
            throw new \InvalidArgumentException('CRM webhook targets must use HTTPS.');
        }
        if (isset($parts['user']) || isset($parts['pass'])) {
            throw new \InvalidArgumentException('Webhook URLs may not contain embedded credentials.');
        }

        $host = strtolower(rtrim((string) $parts['host'], '.'));
        if ($host === '' || $host === 'localhost' || str_ends_with($host, '.localhost')) {
            throw new \InvalidArgumentException('Local webhook targets are not allowed.');
        }

        $port = (int) ($parts['port'] ?? 443);
        $allowedPorts = array_map('intval', (array) config('crm.webhooks.allowed_ports', [443]));
        if (! in_array($port, $allowedPorts, true)) {
            throw new \InvalidArgumentException('Webhook target port is not allowed.');
        }

        if (filter_var($host, FILTER_VALIDATE_IP) !== false) {
            $this->assertPublicIp($host);
            return [$host];
        }

        $records = @dns_get_record($host, DNS_A | DNS_AAAA);
        $ips = [];
        if (is_array($records)) {
            foreach ($records as $record) {
                $ip = (string) ($record['ip'] ?? $record['ipv6'] ?? '');
                if ($ip !== '') {
                    $this->assertPublicIp($ip);
                    $ips[] = $ip;
                }
            }
        }

        if ($ips === []) {
            $fallback = @gethostbynamel($host) ?: [];
            foreach ($fallback as $ip) {
                $this->assertPublicIp((string) $ip);
                $ips[] = (string) $ip;
            }
        }

        if ($ips === []) {
            throw new \InvalidArgumentException('Webhook hostname did not resolve to a public address.');
        }

        return array_values(array_unique($ips));
    }

    private function assertPublicIp(string $ip): void
    {
        if (filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        ) === false) {
            throw new \InvalidArgumentException('Private or reserved webhook targets are not allowed.');
        }
    }
}
