<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_governance_views') || Schema::hasColumn('titan_governance_views','projection_fingerprint')) return;
        Schema::table('titan_governance_views', function (Blueprint $table): void {
            $table->char('projection_fingerprint',64)->nullable()->unique('titan_gov_views_projection_fingerprint_uq');
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('titan_governance_views') || !Schema::hasColumn('titan_governance_views','projection_fingerprint')) return;
        Schema::table('titan_governance_views', function (Blueprint $table): void {
            $table->dropUnique('titan_gov_views_projection_fingerprint_uq');
            $table->dropColumn('projection_fingerprint');
        });
    }
};
