# Architecture

Titan Time & Attendance is the single Titan Zero authority for time capture, timers, timesheet submission/review, attendance verification, offline attendance reconciliation and time-attendance policy.

## Authority boundaries

- **Titan Time & Attendance owns:** `ext_titan_time_*` records, time policies, verification receipts, offline sync receipts, command receipts, attention findings and Workforce workflow receipts.
- **Titan CRM owns:** canonical work-order and service-location records. This extension stores only public references and checks access through the CRM authority port.
- **Titan Workforce owns:** central discovery/orchestration of digital workers. Agent definitions remain source-of-truth in this extension's Workforce manifest.
- **Titan Command Bus owns:** governed AI/non-human mutation execution when available.
- **Titan Signal owns:** cross-system event delivery; this extension uses a transactional outbox and tenant-partitioned queue jobs.
- **Titan Risk / Assurance / Autonomy own:** platform decisions for high-risk AI execution. This extension consumes them through ports and fails closed where they are required.
- **Titan Rewind owns:** historical reconstruction. This extension contributes a read-only, privacy-minimised Rewind source adapter when Rewind v0.3+ is installed.

## Canonical execution flow

`authenticated actor → tenant resolution → permission → capability definition → input shield → Command Bus/local-human gate → domain service → owned database → Signal outbox → Signal Engine → Workforce/analytics/Rewind consumers`

AI Workforce writes add a prior decision layer:

`trusted Workforce context → role/tool allow-list → capability allow-list → risk ceiling → autonomy/approval/risk/assurance gate → Command Bus`

Model input cannot provide authoritative tenant, actor, source, trace, causation, correlation or idempotency identity.

## Offline flow

Titan Go submits a UUID event ID, tenant-pseudonymous device identity derived server-side, monotonic device sequence and minimised evidence. Presence events are revalidated on the server using the same verification service as online attendance before they become verified evidence.
