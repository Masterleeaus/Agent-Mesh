<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_causal_edges')) {
            Schema::create('titan_signal_causal_edges', function (Blueprint $table): void {
                $table->id();
                $table->uuid('parent_event_id');
                $table->uuid('child_event_id');
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->uuid('trace_id');
                $table->uuid('correlation_id');
                $table->uuid('root_causation_id');
                $table->timestamps();

                $table->unique('child_event_id', 'tsce_child_uq');
                $table->index(['parent_event_id', 'child_event_id'], 'tsce_parent_child_idx');
                $table->index(['tenant_company_id', 'trace_id', 'parent_event_id'], 'tsce_tenant_trace_parent_idx');
                $table->index(['tenant_company_id', 'correlation_id'], 'tsce_tenant_corr_idx');
                $table->index(['root_causation_id', 'parent_event_id'], 'tsce_root_parent_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_trace_profiles')) {
            Schema::create('titan_signal_trace_profiles', function (Blueprint $table): void {
                $table->id();
                $table->string('profile_key', 160);
                $table->unsignedInteger('version')->default(1);
                $table->json('required_event_types');
                $table->json('ordering_rules');
                $table->json('terminal_event_types')->nullable();
                $table->string('status', 20)->default('active');
                $table->text('description')->nullable();
                $table->timestamps();

                $table->unique(['profile_key', 'version'], 'tstp_key_version_uq');
                $table->index(['profile_key', 'status', 'version'], 'tstp_lookup_idx');
            });
        }

        if (Schema::hasTable('titan_signal_trace_profiles')) {
            DB::table('titan_signal_trace_profiles')->insertOrIgnore([
                'profile_key' => 'governed.command',
                'version' => 1,
                'required_event_types' => json_encode([
                    'command.requested', 'risk.assessed', 'command.authorized', 'command.executed', 'execution.receipt',
                ], JSON_THROW_ON_ERROR),
                'ordering_rules' => json_encode([
                    ['before' => 'command.requested', 'after' => 'risk.assessed'],
                    ['before' => 'risk.assessed', 'after' => 'command.authorized'],
                    ['before' => 'command.authorized', 'after' => 'command.executed'],
                    ['before' => 'command.executed', 'after' => 'execution.receipt'],
                ], JSON_THROW_ON_ERROR),
                'terminal_event_types' => json_encode(['execution.receipt'], JSON_THROW_ON_ERROR),
                'status' => 'active',
                'description' => 'Expected sequence for a governed consequential command. Applied only when explicitly requested by the caller.',
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        if (Schema::hasTable('titan_signal_events') && Schema::hasTable('titan_signal_causal_edges')) {
            DB::table('titan_signal_events')
                ->whereNotNull('causation_id')
                ->orderBy('id')
                ->chunkById(500, static function ($rows): void {
                    foreach ($rows as $row) {
                        $parent = DB::table('titan_signal_events')
                            ->select(['event_id', 'scope', 'tenant_company_id', 'trace_id', 'correlation_id', 'root_causation_id'])
                            ->where('event_id', $row->causation_id)
                            ->first();
                        if ($parent === null) {
                            continue;
                        }
                        if ((string) $parent->scope !== (string) $row->scope
                            || (int) ($parent->tenant_company_id ?? 0) !== (int) ($row->tenant_company_id ?? 0)
                            || (string) $parent->trace_id !== (string) $row->trace_id
                            || (string) $parent->correlation_id !== (string) $row->correlation_id) {
                            throw new RuntimeException("Cannot project invalid causal edge for event {$row->event_id}.");
                        }

                        DB::table('titan_signal_causal_edges')->updateOrInsert(
                            ['child_event_id' => $row->event_id],
                            [
                                'parent_event_id' => $parent->event_id,
                                'scope' => $row->scope,
                                'tenant_company_id' => $row->tenant_company_id,
                                'trace_id' => $row->trace_id,
                                'correlation_id' => $row->correlation_id,
                                'root_causation_id' => $row->root_causation_id ?: $parent->root_causation_id ?: $parent->event_id,
                                'created_at' => $row->recorded_at ?? $row->created_at ?? now(),
                                'updated_at' => now(),
                            ],
                        );
                    }
                });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_causal_edges');
        Schema::dropIfExists('titan_signal_trace_profiles');
    }
};
