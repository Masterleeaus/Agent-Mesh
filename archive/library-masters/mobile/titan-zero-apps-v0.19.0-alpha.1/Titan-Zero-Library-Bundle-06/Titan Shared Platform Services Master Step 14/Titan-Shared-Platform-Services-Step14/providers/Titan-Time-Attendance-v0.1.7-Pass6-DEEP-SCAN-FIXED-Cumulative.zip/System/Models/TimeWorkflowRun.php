<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;
use Illuminate\Database\Eloquent\Builder;use Illuminate\Database\Eloquent\Model;
final class TimeWorkflowRun extends Model
{
    protected $table='ext_titan_time_workflow_runs';
    protected $fillable=['tenant_company_id','workflow_id','source_event_id','dedup_key','dedup_hash','assigned_role','status','payload','trace_id','correlation_id','causation_id'];
    protected $casts=['payload'=>'array'];
    public function scopeForCompany(Builder $query,int $tenantCompanyId): Builder{return $query->where('tenant_company_id',$tenantCompanyId);}
}
