<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface HostContextBridgeContract
{
    /** Resolve tenancy only from authenticated server-side state. */
    public function tenantCompanyId(): int;

    public function userId(): int;

    public function can(string $permission): bool;

    public function isSuperAdmin(): bool;
}
