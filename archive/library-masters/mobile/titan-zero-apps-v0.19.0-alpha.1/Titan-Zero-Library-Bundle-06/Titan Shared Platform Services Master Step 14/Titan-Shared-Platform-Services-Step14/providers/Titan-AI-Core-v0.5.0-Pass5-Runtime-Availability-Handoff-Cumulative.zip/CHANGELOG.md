# Changelog

## 0.5.0
- Added fail-closed Risk, Assurance and Autonomy gateway contracts and default unavailable adapters.
- Added structured governance preflight decisions and `PENDING_REVIEW` escalation handling.
- Added typed human approval state without enabling the full approval workflow UI.
- Added Command Bus request/receipt contracts with tenant, actor and causal-context propagation.
- Added Command Bus-only mutation boundary; execution remains disabled by default.
- Added governance/Command Bus binding health checks and runtime status.
- Updated orchestration implementation evidence: governance preflight is implemented, governed execution remains false.

## 0.4.0
- Added trusted authenticated-principal resolution for tenant, actor and authority context.
- Added tenant/actor/actor-type spoofing prevention and validator-level trust enforcement.
- Added explicit AI Core capability permissions and route/navigation authorization gates.
- Added tenant-scoped plan/model-profile repositories with explicit global-model fallback rules.
- Added model access policy guard and deterministic tenant/global profile scope keys.
- Added trusted actor audit columns to plan persistence.
- Added future queue tenant-restoration guard foundation while queues remain disabled.
- Hardened PlanEnvelope schema for trusted actor + authority context.
- Extended operational health checks for security/repository bindings.

## 0.3.0
- Blueprint v4.2 / sidecar v2.2 rebase.
- Typed plan, step, data-flow, runtime, actor, validation and receipt contracts.
- Canonical plan hashing and causal/idempotency context.
- Forward plan-context migration and certification command.
