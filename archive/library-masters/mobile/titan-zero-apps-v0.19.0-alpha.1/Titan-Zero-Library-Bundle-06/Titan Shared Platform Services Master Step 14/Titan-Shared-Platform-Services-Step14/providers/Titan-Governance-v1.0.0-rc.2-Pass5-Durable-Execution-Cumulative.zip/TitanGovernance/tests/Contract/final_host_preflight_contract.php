<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function hpfail(string $m): never { fwrite(STDERR,"FAIL: {$m}\n"); exit(1); }
function hpok(bool $c,string $m): void { if(!$c)hpfail($m); }
foreach([
 '/System/Host/TitanInstallerManifestContract.php',
 '/System/Host/TitanFreshInstallPreflight.php',
 '/System/Host/TitanExistingInstallUpgradePreflight.php',
 '/System/Host/TitanProviderBootPreflight.php',
 '/System/Host/TitanExactHostCertification.php',
] as $file) hpok(is_file($root.$file),'missing '.$file);
require_once $root.'/System/Host/TitanInstallerManifestContract.php';
require_once $root.'/System/Host/TitanFreshInstallPreflight.php';
require_once $root.'/System/Host/TitanExistingInstallUpgradePreflight.php';
require_once $root.'/System/Host/TitanProviderBootPreflight.php';
require_once $root.'/System/Host/TitanExactHostCertification.php';

use App\Extensions\TitanGovernance\System\Host\TitanInstallerManifestContract;
use App\Extensions\TitanGovernance\System\Host\TitanFreshInstallPreflight;
use App\Extensions\TitanGovernance\System\Host\TitanExistingInstallUpgradePreflight;
use App\Extensions\TitanGovernance\System\Host\TitanProviderBootPreflight;
use App\Extensions\TitanGovernance\System\Host\TitanExactHostCertification;

$manifest=json_decode((string)file_get_contents($root.'/extension.json'),true,512,JSON_THROW_ON_ERROR);
$contract=new TitanInstallerManifestContract();
hpok($contract->validate($manifest,false)===[],'current dual-compatible manifest validates');
$bad=$manifest; unset($bad['name']);
hpok(in_array("extension.json is missing a valid 'name' value.",$contract->validate($bad,false),true),'missing-name failure is permanently reproduced');
$host=['installer'=>'1.7.6','php'=>'8.3.33','laravel'=>'10.50.2','database'=>'mysql'];
$compat=TitanFreshInstallPreflight::hostCompatibility($host);
$full=(new TitanFreshInstallPreflight())->inspect($root,$host);
hpok(($full['status']??null)==='PASS','full live-style fresh-install preflight passes independent of filesystem enumeration order');
hpok(($compat['compatible']??false)===true,'exact live Installer 1.7.6 host facts accepted');
$compat178=TitanFreshInstallPreflight::hostCompatibility(['installer'=>'1.7.8','php'=>'8.3.33','laravel'=>'10.50.2','database'=>'mysql']);
hpok(($compat178['compatible']??false)===true,'Installer 1.7.8 host facts retained');
$tooOld=TitanFreshInstallPreflight::hostCompatibility(['installer'=>'1.7.5','php'=>'8.3.33','laravel'=>'10.50.2','database'=>'mysql']);
hpok(($tooOld['compatible']??true)===false,'older unobserved Installer 1.7.5 fails closed');
$upgrade=(new TitanExistingInstallUpgradePreflight())->inspect($root,[]);
hpok(($upgrade['migration_count']??0)===4,'upgrade preflight sees frozen four migrations');
hpok(($upgrade['new_migrations_added_by_pass8']??true)===false,'Pass 8 adds no migration');
$boot=(new TitanProviderBootPreflight())->inspect($root);
hpok(($boot['status']??null)==='PASS','provider boot preflight passes static source contract');
$cert=(new TitanExactHostCertification())->report('not-yet-built',[]);
hpok(($cert['stages']['PACKAGE_CERTIFIED']['status']??null)==='PASS','package stage represented');
foreach(['INSTALLER_CERTIFIED','MIGRATION_CERTIFIED','BOOT_CERTIFIED','NAVIGATION_CERTIFIED','AUTHORIZATION_CERTIFIED','RUNTIME_CERTIFIED','UPGRADE_CERTIFIED','UNINSTALL_CERTIFIED'] as $stage){
 hpok(($cert['stages'][$stage]['status']??null)==='NOT_RUN',$stage.' must fail closed without live evidence');
}
echo "PASS: final host preflight contract\n";
