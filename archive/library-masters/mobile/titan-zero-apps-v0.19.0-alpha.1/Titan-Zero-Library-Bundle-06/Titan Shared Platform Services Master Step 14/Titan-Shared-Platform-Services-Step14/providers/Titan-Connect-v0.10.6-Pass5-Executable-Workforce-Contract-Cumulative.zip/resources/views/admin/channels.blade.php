@push('css')
<link rel="stylesheet" href="{{ asset('vendor/titan-connect/css/operator-inbox.css') }}">
@endpush

<div class="container-fluid py-6">
<section class="tc-operator tc-settings">
    <header class="tc-operator__header">
        <div>
            <h1>{{ __('Titan Connect Channels') }}{{ $provider ? ' — '.$providers[$provider] : '' }}</h1>
            <p>{{ __('Installation-level channel administration. Company credentials and operational conversations remain company-owned and are not exposed here.') }}</p>
        </div>
    </header>
    <div class="tc-settings__notice">
        <strong>{{ __('Runtime certification') }}</strong>
        <span><code>php artisan titan-connect:diagnose</code> · <code>php artisan titan-connect:certify --strict</code></span>
    </div>
    <div class="tc-provider-grid">
        @foreach ($providers as $key => $label)
            <a class="tc-provider-card" href="{{ route('dashboard.admin.settings.titan-connect.channels.'.$key) }}">
                <strong>{{ $label }}</strong>
                <span>{{ __('Provider configuration & readiness') }}</span>
            </a>
        @endforeach
    </div>
    @if ($provider)
        <section class="tc-panel">
            <div class="tc-panel__title"><strong>{{ $providers[$provider] }}</strong></div>
            <p>{{ __('Company-specific provider credentials are configured by company owners/admins under Channels → :provider. Super Admin retains platform diagnostics and integration configuration only.', ['provider' => $providers[$provider]]) }}</p>
        </section>
    @endif
</section>
</div>
