<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Repositories;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Contracts\ActivityRepositoryContract;
use App\Extensions\Crm\System\Services\{CrmActivityRecorder,CrmSubjectReferenceValidator};
use Illuminate\Database\ConnectionInterface;
final class EloquentActivityRepository implements ActivityRepositoryContract
{
    public function __construct(private ConnectionInterface $db, private CrmActivityRecorder $recorder, private CrmSubjectReferenceValidator $subjects) {}
    public function create(int $userId,int $actorUserId,array $data): array{$this->subjects->require($userId,(string)$data['subject_type'],(string)$data['subject_public_id']);return $this->recorder->record($userId,(string)$data['subject_type'],(string)$data['subject_public_id'],(string)($data['type']??'note'),$data['title']??null,$data['body']??null,$data['direction']??null,$data['scheduled_at']??null,$data['completed_at']??null,$actorUserId,$data['metadata']??[]);}
    public function forSubject(int $userId,string $subjectType,string $subjectPublicId,int $limit=100): array{$this->subjects->require($userId,$subjectType,$subjectPublicId);return $this->db->table(config('crm.tables.activities'))->where('company_id', CrmCompanyScope::companyId($userId))->where('subject_type',$subjectType)->where('subject_public_id',$subjectPublicId)->orderByDesc('created_at')->limit(max(1,min($limit,250)))->get()->map(fn($r)=>(array)$r)->all();}
}
