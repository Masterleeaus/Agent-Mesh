<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Contracts\{CompanyRepositoryContract,ContactRepositoryContract,LeadRepositoryContract,DealRepositoryContract};
use InvalidArgumentException;

final class CrmImportService
{
    public function __construct(
        private CompanyRepositoryContract $companies,
        private ContactRepositoryContract $contacts,
        private LeadRepositoryContract $leads,
        private DealRepositoryContract $deals,
    ) {}

    public function import(int $userId, int $actorUserId, string $type, array $records): array
    {
        if (count($records) > (int) config('crm.import.max_records', 1000)) {
            throw new InvalidArgumentException('CRM import exceeds the configured record limit.');
        }
        $created = [];
        foreach ($records as $index => $record) {
            if (! is_array($record)) {
                throw new InvalidArgumentException("CRM import row {$index} must be an object.");
            }
            $created[] = match ($type) {
                'companies' => $this->companies->create($userId, $record),
                'contacts' => $this->contacts->create($userId, $record),
                'leads' => $this->leads->create($userId, $actorUserId, $record),
                'deals' => $this->deals->create($userId, $actorUserId, $record),
                default => throw new InvalidArgumentException('Unsupported CRM import type.'),
            };
        }
        return ['type' => $type, 'created' => count($created), 'records' => $created];
    }
}
