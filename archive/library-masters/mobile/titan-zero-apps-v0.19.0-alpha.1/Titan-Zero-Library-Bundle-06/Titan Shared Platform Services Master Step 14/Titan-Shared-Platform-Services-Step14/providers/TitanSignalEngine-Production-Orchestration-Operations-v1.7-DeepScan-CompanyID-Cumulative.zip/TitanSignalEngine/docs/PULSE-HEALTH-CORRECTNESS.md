# Pulse, Health & Backpressure Correctness — v0.17.0

## Scoped freshness

`titan_signal_pulse_projection_freshness` is a mutable read projection keyed by scope, tenant key and dimension. Every successful new Pulse projection updates platform, exact scope, source and source-component freshness without changing the immutable Signal event.

A tenant Pulse request never uses another tenant's latest projection as evidence of freshness.

## Per-command execution latency

`titan_signal_pulse_command_receipts` stores one row for each `command.executed`. `execution.receipt` events pair by direct causation first. If causation is not direct, Signal may pair the receipt with the latest unmatched preceding command in the same trace and records `pairing_method=trace_unmatched` explicitly.

This replaces the former Pulse read behavior that sampled one overwritten command/receipt timestamp pair from each trace. The legacy fields remain for upgrade compatibility but are not used for Pulse latency percentiles when the new table exists.

## Operational health snapshots

`titan_signal_operational_health_snapshots` stores the maintained platform health projection. `titan:signal-health:refresh` runs every minute after Pulse projection. Health reads may refresh a stale snapshot, but normal dashboard traffic no longer performs growing table-wide counts on every request.

Current health and historical incidents are separate:

- current: active backpressure, recent DLQs, current critical anomalies, scoped platform Pulse freshness, due/stale trace evaluation and lifecycle pressure;
- historical: resolved DLQs in the last 30 days, resolved critical anomalies in the last 30 days, and archive history counters.

Historical incidents are evidence, not current degradation.
