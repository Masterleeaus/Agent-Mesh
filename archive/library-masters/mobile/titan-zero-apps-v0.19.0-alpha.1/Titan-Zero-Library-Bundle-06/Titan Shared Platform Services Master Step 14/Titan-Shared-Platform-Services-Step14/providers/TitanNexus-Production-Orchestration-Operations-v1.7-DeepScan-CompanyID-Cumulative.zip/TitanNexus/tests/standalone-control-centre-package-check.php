<?php

declare(strict_types=1);

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
function ccPkg(bool $condition, string $message): void { if (!$condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } }
function ccRead(string $path): string { if (!is_file($path)) { fwrite(STDERR, "FAIL: missing {$path}\n"); exit(1); } return (string) file_get_contents($path); }

$userRoutes = ccRead($root . '/routes/user.php');
foreach (['overview','profile','compilations','validation','preview','history','diff','provisioning','receipts','detail'] as $name) {
    ccPkg(str_contains($userRoutes, "->name('{$name}')"), "user routes declare named {$name} Control Centre route");
}
ccPkg(str_contains($userRoutes, 'ControlCentreController::class'), 'user routes use ControlCentreController');

$controller = ccRead($root . '/System/Http/Controllers/ControlCentreController.php');
ccPkg(str_contains($controller, 'TenantContextResolverContract'), 'Control Centre resolves tenant context through contract');
ccPkg(str_contains($controller, 'NexusControlCentreContract'), 'Control Centre reads through read-model contract');
ccPkg(!str_contains($controller, 'DB::') && !str_contains($controller, 'NexusCompilationRecord'), 'Control Centre controller has no direct database access');

$index = ccRead($root . '/resources/views/index.blade.php') . ccRead($root . '/resources/views/partials/control-centre-nav.blade.php');
ccPkg(str_contains($index, "@extends('panel.layout.app')"), 'Control Centre uses MagicAI panel.layout.app host layout');
foreach (['Overview','Business Profile','Compilations','Validation','Configuration Preview','History','Recompile / Diff','Provisioning Plans','Provisioning Receipts'] as $label) {
    ccPkg(str_contains($index, $label), "Control Centre contains {$label} surface");
}
ccPkg(!str_contains($index, '<form') && !str_contains($index, 'method="POST"'), 'Pass 7 Control Centre contains no direct mutation form');

$admin = ccRead($root . '/System/Http/Controllers/AdminController.php');
ccPkg(str_contains($admin, 'TenantContextResolverContract') && str_contains($admin, 'NexusControlCentreContract'), 'admin diagnostics reuse tenant-safe read model');

fwrite(STDOUT, "PASS: Titan Nexus standalone Control Centre package checks\n");
