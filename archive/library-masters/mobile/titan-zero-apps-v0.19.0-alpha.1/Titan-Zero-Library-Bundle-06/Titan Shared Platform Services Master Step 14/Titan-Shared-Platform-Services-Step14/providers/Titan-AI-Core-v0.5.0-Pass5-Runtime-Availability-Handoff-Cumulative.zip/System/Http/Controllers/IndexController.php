<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Http\Controllers;

use App\Extensions\TitanAICore\System\Contracts\HostLayoutResolverContract;
use App\Extensions\TitanAICore\System\Contracts\RuntimeManagerContract;
use Illuminate\Contracts\View\View;

final class IndexController
{
    public function __invoke(RuntimeManagerContract $runtime, HostLayoutResolverContract $layouts): View
    {
        return view('titan-ai-core::index', [
            'runtime' => $runtime->status(),
            'hostLayout' => $layouts->resolve(),
        ]);
    }
}
