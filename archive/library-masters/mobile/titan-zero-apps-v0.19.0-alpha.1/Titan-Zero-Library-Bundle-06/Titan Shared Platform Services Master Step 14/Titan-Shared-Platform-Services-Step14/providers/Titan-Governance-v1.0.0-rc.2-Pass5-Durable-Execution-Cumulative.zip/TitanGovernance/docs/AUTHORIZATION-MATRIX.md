# Authorization Matrix

| Surface / action | Super Admin | Delegated Admin | Tenant Admin | Ordinary User |
|---|---:|---:|---:|---:|
| Platform Governance | allow | explicit `titan-governance.admin` | deny | deny |
| Tenant Governance dashboard | allow | explicit `titan-governance.view` | explicit `titan-governance.view` | explicit permission only |
| Escalation queue | allow | `titan-governance.escalations.view` | explicit permission | deny by default |
| Approve / reject / hold / escalate | allow | `titan-governance.escalations.act` | explicit permission | deny by default |
| Grant Governance exception | allow | `titan-governance.escalations.act` + `titan-governance.exceptions.grant` | explicit dual permission | deny |
| Policy/authority evidence | allow | bounded permission | bounded permission | deny by default |
| Cross-domain mutation | Command Bus only | Command Bus only | Command Bus only | Command Bus only |

The URL or menu location is never authorization. Tenant scope and actor identity are reconstructed server-side. Client-supplied tenant, actor, roles, permissions or causal authority fields are rejected by the action-request boundary.
