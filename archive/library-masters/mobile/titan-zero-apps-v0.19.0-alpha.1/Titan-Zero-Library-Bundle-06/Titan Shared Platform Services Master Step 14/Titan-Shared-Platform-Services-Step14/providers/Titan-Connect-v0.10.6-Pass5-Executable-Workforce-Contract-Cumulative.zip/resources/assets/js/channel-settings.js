(() => {
  const root = document.getElementById('titan-connect-channel-settings');
  if (!root) return;
  const csrf = root.dataset.csrf;
  const status = (message, error = false) => {
    const el = root.querySelector('[data-role="channel-settings-status"]');
    if (!el) return;
    el.textContent = message || '';
    el.classList.toggle('tc-status--error', Boolean(error));
  };
  const request = async (url, options = {}) => {
    const response = await fetch(url, {
      credentials: 'same-origin',
      headers: {'Accept':'application/json','Content-Type':'application/json','X-CSRF-TOKEN':csrf, ...(options.headers || {})},
      ...options,
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.message || `Request failed (${response.status})`);
    return payload;
  };
  root.querySelectorAll('[data-connection-uuid]').forEach((row) => {
    const uuid = row.dataset.connectionUuid;
    row.querySelector('[data-action="health"]')?.addEventListener('click', async () => {
      try {
        status('Checking provider health…');
        await request(`${root.dataset.healthBase}/${uuid}/health`);
        window.location.reload();
      } catch (error) { status(error.message, true); }
    });
    row.querySelector('[data-action="toggle"]')?.addEventListener('click', async (event) => {
      try {
        const current = event.currentTarget.dataset.status;
        const next = current === 'active' ? 'paused' : 'active';
        status(`Setting connection ${next}…`);
        await request(`${root.dataset.connectionsBase}/${uuid}`, {method:'PATCH', body:JSON.stringify({status:next})});
        window.location.reload();
      } catch (error) { status(error.message, true); }
    });
  });
})();
