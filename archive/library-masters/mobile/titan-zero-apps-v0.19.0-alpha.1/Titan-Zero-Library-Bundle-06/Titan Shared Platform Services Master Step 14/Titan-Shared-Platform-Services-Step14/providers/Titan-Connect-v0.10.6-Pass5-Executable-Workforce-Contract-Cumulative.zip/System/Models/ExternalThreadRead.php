<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class ExternalThreadRead extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    protected $table = 'ext_titan_connect_external_thread_reads';
    protected $fillable = ['external_thread_id', 'company_id', 'user_id', 'last_read_message_id', 'last_read_at'];
    protected $casts = ['last_read_at' => 'datetime'];

    public function thread(): BelongsTo
    {
        return $this->belongsTo(ExternalThread::class, 'external_thread_id');
    }
}
