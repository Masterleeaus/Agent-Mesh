<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Navigation;

final class TitanRewindNavigation
{
    public static function user(): array
    {
        $parent = self::item(
            parentKey: null,
            key: 'titan_rewind',
            route: 'dashboard.user.titan.rewind.index',
            label: 'Titan Rewind',
            icon: 'tabler-history-toggle',
            order: 88,
            permission: 'rewind.trace.view',
        );
        $parent['active_condition'] = ['dashboard.user.titan.rewind.*'];

        return [
            $parent,
            self::item('titan_rewind', 'titan_rewind_overview', 'dashboard.user.titan.rewind.index', 'Overview', 'tabler-layout-dashboard', 1, 'rewind.trace.view'),
            self::item('titan_rewind', 'titan_rewind_traces', 'dashboard.user.titan.rewind.traces.index', 'Traces', 'tabler-timeline-event', 2, 'rewind.trace.view'),
            self::item('titan_rewind', 'titan_rewind_cases', 'dashboard.user.titan.rewind.cases.index', 'Cases', 'tabler-briefcase', 3, 'rewind.trace.view'),
            self::item('titan_rewind', 'titan_rewind_replays', 'dashboard.user.titan.rewind.replay.index', 'Replay Runs', 'tabler-player-play', 4, 'rewind.replay.run'),
            self::item('titan_rewind', 'titan_rewind_evidence', 'dashboard.user.titan.rewind.evidence.index', 'Evidence Vault', 'tabler-shield-check', 5, 'rewind.trace.view'),
            self::item('titan_rewind', 'titan_rewind_recovery', 'dashboard.user.titan.rewind.recovery.index', 'Recovery Plans', 'tabler-lifebuoy', 6, 'rewind.recovery.propose'),
            self::item('titan_rewind', 'titan_rewind_assistant', 'dashboard.user.titan.rewind.assistant.index', 'Forensic Assistant', 'tabler-sparkles', 7, 'rewind.forensics.view'),
        ];
    }

    public static function admin(): array
    {
        return [[
            'parent_key' => null,
            'key' => 'titan_rewind_admin',
            'route' => 'dashboard.admin.titan.rewind.index',
            'route_slug' => null,
            'label' => 'Titan Rewind',
            'icon' => 'tabler-history-toggle',
            'order' => 88,
            'is_active' => true,
            'params' => [],
            'type' => 'item',
            'badge' => null,
            'extension' => true,
            'active_condition' => ['dashboard.admin.titan.rewind.*'],
            'show_condition' => true,
            'permission' => 'rewind.admin',
            'is_admin' => true,
        ]];
    }

    private static function item(?string $parentKey, string $key, string $route, string $label, string $icon, int $order, string $permission): array
    {
        return [
            'parent_key' => $parentKey,
            'key' => $key,
            'route' => $route,
            'route_slug' => null,
            'label' => $label,
            'icon' => $icon,
            'order' => $order,
            'is_active' => true,
            'params' => [],
            'type' => 'item',
            'badge' => null,
            'extension' => true,
            'active_condition' => [$route === 'dashboard.user.titan.rewind.index' ? 'dashboard.user.titan.rewind.index' : $route],
            'show_condition' => true,
            'permission' => $permission,
            'is_admin' => false,
        ];
    }
}
