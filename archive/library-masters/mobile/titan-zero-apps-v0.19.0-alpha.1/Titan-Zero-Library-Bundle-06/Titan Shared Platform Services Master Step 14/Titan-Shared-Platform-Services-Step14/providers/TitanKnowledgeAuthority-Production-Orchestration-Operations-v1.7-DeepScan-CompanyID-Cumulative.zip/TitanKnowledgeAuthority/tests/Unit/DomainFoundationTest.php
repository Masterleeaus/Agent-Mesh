<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Services\KnowledgeScopeGuard;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Services\SourceVersionHasher;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeScopeContext;
use PHPUnit\Framework\TestCase;

final class DomainFoundationTest extends TestCase
{
    public function test_tenant_scope_is_fail_closed_across_tenants(): void
    {
        $guard = new KnowledgeScopeGuard();
        $scope = KnowledgeScopeContext::tenant(42);

        self::assertTrue($guard->canRead($scope, 42));
        self::assertFalse($guard->canRead($scope, 41));
        self::assertFalse($guard->canRead($scope, null));
    }

    public function test_primitive_guard_keeps_platform_visible_and_jurisdiction_fail_closed(): void
    {
        $guard = new KnowledgeScopeGuard();

        self::assertTrue($guard->canRead(KnowledgeScopeContext::platform(), null));
        self::assertFalse($guard->canRead(KnowledgeScopeContext::jurisdiction('AU-VIC'), null));
    }

    public function test_source_hash_is_deterministic_after_line_ending_normalization(): void
    {
        $hasher = new SourceVersionHasher();

        self::assertSame($hasher->hash("a\r\nb\r\n"), $hasher->hash("a\nb\n"));
        self::assertNotSame($hasher->hash('alpha'), $hasher->hash('beta'));
    }
}
