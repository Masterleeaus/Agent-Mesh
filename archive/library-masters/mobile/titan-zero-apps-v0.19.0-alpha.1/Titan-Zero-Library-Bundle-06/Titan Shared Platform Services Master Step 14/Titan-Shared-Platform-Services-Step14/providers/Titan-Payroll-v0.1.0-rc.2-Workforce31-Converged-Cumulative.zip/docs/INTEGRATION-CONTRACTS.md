# Integration Contracts

- **Titan Time Attendance:** approved payroll-input evidence only through `TimeAttendancePayrollInputPort`; Payroll never queries its tables.
- **Titan Command Bus:** required execution path for AI/Workforce state writes and preferred governed path for mutations.
- **Titan Risk + Assurance:** fail-closed for high/critical financial actions.
- **Titan Autonomy:** sole source of effective AI authority; Payroll stores role intent only.
- **Titan Communications / Titan Connect:** Payroll is a delivery consumer. Provider execution and provider receipts remain external facts.
- **Titan Rewind:** Payroll is a source contributor. It provides privacy-minimized versioned facts and monotonic watermarks, not a second Rewind engine.
- **Accounting / Payment systems:** output ports distinguish local export/preparation from confirmed external transmission/payment.
