# Titan Forge v0.9.0-alpha.1 — Rewind Deterministic Reconstruction

Titan Forge is Titan's governed system-construction layer. This cumulative alpha preserves the installer, deterministic workforce, sandbox, validation, AI Core consumer boundaries and governed release foundations, and adds a Blueprint v4.2.1-native, read-only Titan Rewind source contribution with deterministic reconstruction evidence.

Forge still **does not deploy to production**. It generates, validates and records release candidates; production authority remains outside Forge.

## Active foundations

- current `titan-extension-v1` installer and SHA-256 integrity contract
- strict tenant-bound `BuildContext` with actor, trace, correlation, causation, root-causation, operation and idempotency IDs
- deterministic `BuildRequest` / `BuildSpec` fingerprints
- normalized persistence for specs, plans, artifacts, validation, release candidates, approvals, releases and receipts
- tenant-scoped build and release-candidate repositories
- authenticated tenant middleware and fail-fast configuration validation
- read-only user/admin build-history surfaces
- active `titan-forge` queue for bounded deterministic workforce generation

## Deterministic workforce assembly

Forge consumes Titan AI Workforce definitions; it does not own the canonical workforce taxonomy.

Current deterministic bootstrap:

- Operations Manager
- Receptionist
- Booking Coordinator
- Scheduler
- Job Coordinator
- Billing Coordinator

Entitlement limits remain 6 / 15 / 30 / 68 for Solo / Small Business / Growing / Enterprise. Larger mappings fail closed until exact canonical Workforce definitions are imported.

## Sandbox and local validation

Generated files are written only below:

`storage/app/titan-forge/workspaces/<tenant_company_id>/<operation_id>/`

The sandbox provides safe relative paths, atomic publication, bounded file/size limits, clean retries, symlink rejection, traversal rejection and case-collision protection.

The deterministic validator registry runs:

1. artifact policy limits
2. workspace integrity/hash verification
3. generated-content secret scan
4. generation-manifest/provenance verification
5. unsafe-code primitive scan
6. JSON syntax
7. PHP syntax using `TOKEN_PARSE`

A failed local validation never creates a release candidate.

## AI Core planning and generation boundary

Forge now consumes Titan AI Core typed planning through public contracts. A returned plan is usable only after AI Core validation and exact tenant/causal-context verification, then maps into a deterministic Forge `BuildPlan`.

The currently verified Titan AI Core v0.3.0 intentionally reports `DAG_VALIDATOR_NOT_IMPLEMENTED`, so live planning is `planning_blocked`. AI Core also exposes no governed artifact-generation contract yet, so the production AI artifact gateway is fail-closed as `generation_blocked`. Forge does not call model providers directly.

The implemented sandbox boundary accepts typed AI artifact proposals, writes them only through Forge `SandboxWorkspace`, persists model/plan/hash provenance, rejects chain-of-thought-shaped metadata and then runs the same deterministic validation/governance path as static generation.

See `docs/AI-CORE-PLANNING-v0.7.md`, `docs/AI-ARTIFACT-GENERATION-v0.7.md` and `docs/PEER-CONTRACT-MATRIX-v0.7.md`.

## Verified governance bridge

Forge v0.9 preserves the verified governance adapters, governed Council contract and authority boundaries:

- Titan Signal Engine v0.2.0
- Titan Risk Engine v0.2.1
- Titan Shield v0.3.0
- Titan Model Council v0.7.0
- Titan Governance v0.1.0
- Titan Command Bus v0.1.0

### Signal

When Titan Signal's `SignalEmitterContract` is installed, Forge emits tenant-scoped lifecycle events with full trace lineage and event-specific idempotency.

### Risk

When Titan Risk's `RiskGateContract` is installed, release candidates are assessed before progression. Risk `DENY` rejects a candidate; hold directives block progression.

### Shield

Forge local validators remain responsible for code/artifact validation. Titan Shield receives Forge findings through its public governance-response contract and can block progression or request additional governance.

### Model Council

High/critical Risk levels now trigger a bounded Council **governed deliberation** through Titan Model Council v0.7.0. Forge sends only target type, stable fingerprints/digests, bounded artifact path/hash/size metadata, validation status and Risk evidence—never build instructions, request inputs, artifact contents, credentials or unrestricted reasoning.

Council role-to-model assignments are host-controlled configuration: all four roles (`proposer`, `critic`, `verifier`, `arbiter`) must be configured together and at least three distinct models are required. Forge never chooses models dynamically per request. Council output remains `execution_authority: advisory_only`; Forge stores only a sanitized hashed receipt and Council decision ID, not participant response text or raw final answers. Escalated/rejected/failed/configuration-missing Council outcomes hold release progression for Governance.

### Governance and Command Bus

The verified Governance v0.1.0 and Command Bus v0.1.0 public contracts expose health only. They do not expose release-decision or dispatch methods yet.

Forge therefore fails closed with `health_only_contract`. It does **not** fabricate those APIs and does not directly install or deploy anything.


## Titan Rewind source contribution

Forge now exports `titan-forge.rewind-source` through the Blueprint v4.2.1 host-owned `App\Support\Extensions\RewindSourceAdapter` contract. The contribution is authority-neutral and `read-only`; Forge does not import Titan Rewind internals or write to Rewind-owned tables.

The source reconstructs bounded durable evidence across:

1. build registration/state
2. persisted plans
3. generated artifact receipts
4. validation runs
5. Shield governance responses
6. Risk assessments
7. governed Model Council decisions
8. Governance gate state
9. release candidates and Forge receipts

Events are tenant/trace scoped, deterministically sequenced, canonical-JSON hashed and linked by `previous_hash`. Evidence contains identifiers, bounded state and hashes only—never build instructions, generated artifact contents, Council transcripts/final-answer text, credentials or hidden reasoning. Long source reads use cursor-backed persistence reads and streaming projection/watermark aggregation.

A current durable trace can report source completeness `COMPLETE`. Exact historical `as_of` reconstruction is deliberately **not** claimed because the primary Forge build row remains mutable; `supports_as_of=false` and Forge reconstruction therefore reports `PARTIALLY_REPRODUCIBLE` rather than inventing full historical reproducibility.

See `docs/REWIND-PASS19.md` and `docs/PEER-CONTRACT-MATRIX-v0.9.md`.

## Release candidates

After local validation succeeds, Forge evaluates:

`Shield -> Risk -> selective Council -> Governance boundary -> Command Bus boundary`

Then it records a tenant-scoped candidate as:

- `validated`
- `approval_required`
- `rejected`

Candidate metadata includes the gate fingerprint, peer results, reason codes, trace lineage and `deployment_authority: none`.

With the currently verified Governance/Command Bus versions, candidates remain held from execution even if earlier gates pass.

## Commands

```text
php artisan forge:manifest solo
php artisan forge:manifest solo --json
php artisan forge:generate-skeleton solo --tenant=<id> --actor=<id>
```

## Deliberately not active

- live AI/LLM artifact generation against the currently verified AI Core v0.3.0 contract
- arbitrary shell/process execution
- direct production deployment
- public build-status webhooks
- subscription billing logic
- invented larger Workforce mappings
- Governance release approval without a public decision contract
- Command Bus release execution without a public dispatch contract

See `docs/PEER-CONTRACT-MATRIX-v0.9.md`, `docs/REWIND-PASS19.md`, `docs/MODEL-COUNCIL-PASS18.md` and `docs/GOVERNED-RELEASE-CANDIDATES-v0.6.md` for the exact peer, forensic and release-authority boundaries.

## Blueprint v4.2.1 status

This package uses Manifest v2.2 with the `builder-generator` profile plus `signal-aware`, `ai-enabled` and `rewind-source-contributor` modifiers. `ai-enabled` means Forge consumes AI/runtime capabilities without gaining execution authority; it does **not** claim the current AI Core can yet produce executable plans or artifact proposals. The package remains development-stage: no release signature or live-host certification is claimed.
