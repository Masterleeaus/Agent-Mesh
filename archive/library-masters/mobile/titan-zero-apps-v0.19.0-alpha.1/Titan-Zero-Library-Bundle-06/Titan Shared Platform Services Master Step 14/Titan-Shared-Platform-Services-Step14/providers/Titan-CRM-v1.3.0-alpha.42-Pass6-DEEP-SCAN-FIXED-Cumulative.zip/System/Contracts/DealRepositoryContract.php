<?php
namespace App\Extensions\Crm\System\Contracts;
interface DealRepositoryContract {
    public function search(int $userId, array $filters=[]): array;
    public function create(int $userId, int $actorUserId, array $data): array;
    public function update(int $userId, string $publicId, int $actorUserId, array $data): array;
    public function move(int $userId, string $publicId, int $actorUserId, array $data): array;
    public function markWon(int $userId, string $publicId, int $actorUserId): array;
    public function markLost(int $userId, string $publicId, int $actorUserId, string $reason): array;
}
