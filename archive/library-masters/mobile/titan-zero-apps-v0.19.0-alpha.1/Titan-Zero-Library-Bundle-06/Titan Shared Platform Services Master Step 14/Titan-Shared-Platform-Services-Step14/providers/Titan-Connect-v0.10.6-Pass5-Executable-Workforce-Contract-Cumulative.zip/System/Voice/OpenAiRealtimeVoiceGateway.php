<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Voice;

use App\Extensions\TitanConnect\System\Contracts\ProviderHttpClient;
use RuntimeException;

final class OpenAiRealtimeVoiceGateway
{
    public function __construct(private readonly ProviderHttpClient $http) {}

    public function start(array $credentials): array
    {
        $apiKey = trim((string) ($credentials['api_key'] ?? $credentials['openai_api_key'] ?? ''));
        if ($apiKey === '') throw new RuntimeException('OpenAI Realtime API key is not configured.');
        $model = trim((string) ($credentials['model'] ?? config('titan-connect.voice.openai.model', 'gpt-realtime')));
        $voice = trim((string) ($credentials['voice'] ?? config('titan-connect.voice.openai.voice', 'verse')));
        $endpoint = (string) ($credentials['client_secret_endpoint'] ?? config('titan-connect.voice.openai.client_secret_endpoint', 'https://api.openai.com/v1/realtime/client_secrets'));
        $response = $this->http->request('POST', $endpoint, ['bearer'=>$apiKey,'json'=>['session'=>['type'=>'realtime','model'=>$model,'audio'=>['output'=>['voice'=>$voice]]]]]);
        if (! $response->isSuccessful()) throw new RuntimeException('OpenAI Realtime client credential request failed.');
        $ephemeral = $response->json('value') ?? $response->json('client_secret.value');
        if (! is_scalar($ephemeral) || trim((string) $ephemeral) === '') throw new RuntimeException('OpenAI Realtime ephemeral key was missing.');
        return ['provider'=>'openai_realtime','ephemeral_key'=>(string)$ephemeral,'model'=>$model,'voice'=>$voice,'websocket_url'=>(string)config('titan-connect.voice.openai.websocket_url','wss://api.openai.com/v1/realtime')];
    }
}
