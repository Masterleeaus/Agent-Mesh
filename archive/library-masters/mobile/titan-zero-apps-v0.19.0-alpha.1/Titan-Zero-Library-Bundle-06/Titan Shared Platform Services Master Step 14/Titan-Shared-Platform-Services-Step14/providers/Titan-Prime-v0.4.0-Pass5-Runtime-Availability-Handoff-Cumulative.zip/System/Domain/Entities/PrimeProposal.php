<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Entities;

use App\Extensions\TitanPrime\System\Domain\Enums\PrimeProposalStatus;
use InvalidArgumentException;

final readonly class PrimeProposal
{
    /**
     * @param list<string> $alternatives
     * @param list<string> $evidenceReferences
     * @param list<string> $reasonCodes
     */
    public function __construct(
        public string $proposalId,
        public string $missionId,
        public string $recommendation,
        public array $alternatives = [],
        public array $evidenceReferences = [],
        public array $reasonCodes = [],
        public float $confidence = 0.0,
        public PrimeProposalStatus $status = PrimeProposalStatus::Draft,
    ) {
        if (trim($proposalId) === '' || trim($missionId) === '' || trim($recommendation) === '') {
            throw new InvalidArgumentException('Proposal id, mission id and recommendation are required.');
        }
        if ($confidence < 0.0 || $confidence > 1.0) {
            throw new InvalidArgumentException('Proposal confidence must be between 0.0 and 1.0.');
        }
    }
}
