<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);function fail_wa(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function ok_wa(bool $c,string $m):void{if(!$c)fail_wa($m);}function same_wa(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_wa($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
$f=$root.'/System/ControlCentre/GovernanceAttentionRanker.php';if(!is_file($f))fail_wa('missing ranker');require_once $f;
use App\Extensions\TitanGovernance\System\ControlCentre\GovernanceAttentionRanker;
$human=['approvals'=>[['task_id'=>'task-1','age_status'=>'OVERDUE','manager_id'=>2,'manager'=>'Finance Manager','observed_at'=>'2026-08-21T00:00:00+10:00']], 'handoffs'=>[['handoff_id'=>'h-1','task_id'=>'task-2','status'=>'ESCALATED','age_status'=>'AGING','observed_at'=>'2026-08-21T01:00:00+10:00']]];
$workforce=['queues'=>[['manager_id'=>2,'manager'=>'Finance Manager','division'=>'Finance','health'=>['pressure'=>'HIGH','queue_depth'=>25,'overdue_count'=>4],'observed_at'=>'2026-08-21T03:00:00+10:00']]];
$r=(new GovernanceAttentionRanker())->rank([],[],[],[],[],[],[],$workforce,$human);
$reasons=array_column($r['items'],'reason_code');ok_wa(in_array('WORKFORCE_APPROVAL_OVERDUE',$reasons,true),'overdue approval attention');ok_wa(in_array('WORKFORCE_HANDOFF_ESCALATED',$reasons,true),'handoff attention');ok_wa(in_array('WORKFORCE_QUEUE_PRESSURE_HIGH',$reasons,true),'queue pressure attention');
$approval=current(array_filter($r['items'],fn($x)=>$x['reason_code']==='WORKFORCE_APPROVAL_OVERDUE'));same_wa('workforce',$approval['drill_down']['surface']??null,'workforce drilldown surface');same_wa('task',$approval['drill_down']['focus_type']??null,'approval focus type');same_wa('task-1',$approval['drill_down']['focus_id']??null,'approval focus id');
echo "PASS: Governance Workforce attention contract\n";
