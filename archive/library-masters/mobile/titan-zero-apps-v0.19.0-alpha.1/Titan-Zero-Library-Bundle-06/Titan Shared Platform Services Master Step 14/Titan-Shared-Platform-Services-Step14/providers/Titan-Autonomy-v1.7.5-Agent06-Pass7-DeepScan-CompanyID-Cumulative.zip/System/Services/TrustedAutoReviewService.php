<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\AssuranceBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;
use App\Extensions\TitanAutonomy\System\Contracts\TitanAiRuntimeBridgeContract;
use App\Extensions\TitanAutonomy\System\DTOs\LevelActivationResult;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\HandshakeDecision;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableTitanAiRuntimeBridge;

final class TrustedAutoReviewService
{
    private readonly TitanAiRuntimeBridgeContract $titanAi;
    private readonly AiAssuranceReliabilityEvaluator $reliability;

    public function __construct(
        private readonly AutonomyQueryContract $query,
        private readonly GateReviewService $gateReview,
        private readonly AutonomyGrantService $grantService,
        private readonly AssuranceBridgeContract $assurance,
        ?TitanAiRuntimeBridgeContract $titanAi = null,
        ?AiAssuranceReliabilityEvaluator $reliability = null,
        private readonly float $minimumConfidence = 0.85,
    ) {
        $this->titanAi = $titanAi ?? new UnavailableTitanAiRuntimeBridge();
        $this->reliability = $reliability ?? new AiAssuranceReliabilityEvaluator();
    }

    public function reviewAndGrant(
        int $tenantCompanyId,
        string $capability,
        string $workflowKey,
        int $actorUserId,
        bool $actorCanGrant,
        HandshakeDecision $userDecision,
        array $scope,
        ?string $correlationId = null,
    ): LevelActivationResult {
        $review = $this->gateReview->review($tenantCompanyId, $capability, $workflowKey);
        $state = $review['state'];
        $gate = $review['gate'];

        $assurance = $this->assurance->evaluate($capability, $workflowKey, [
            'tenant_company_id' => $tenantCompanyId,
            'current_level' => $state->currentLevel->key(),
            'requested_level' => AutonomyLevel::TrustedAuto->key(),
            'scope' => $scope,
            'success_streak' => $state->currentSuccessStreak,
            'total_successes' => $state->totalSuccesses,
            'total_failures' => $state->totalFailures,
            'total_edits' => $state->totalEdits,
            'total_rejections' => $state->totalRejections,
            'total_reversals' => $state->totalReversals,
        ]);
        $titanAi = $this->titanAi->status();

        $attempts = max(1, $state->totalSuccesses + $state->totalFailures + $state->totalEdits + $state->totalRejections + $state->totalReversals);
        $assuranceApproved = strtolower((string) ($assurance['decision'] ?? 'denied')) === 'approved';
        $assuranceStatus = strtoupper((string) ($assurance['status'] ?? 'RED'));
        if (!$assuranceApproved && $assuranceStatus === 'GREEN') $assuranceStatus = 'RED';
        $confidence = max(0.0, min(1.0, (float) ($assurance['confidence'] ?? 0.0)));
        $runtimeAvailable = ($titanAi['available'] ?? false) === true;

        $evaluation = $this->reliability->evaluate([
            'sufficient_history' => $state->totalSuccesses >= $state->requiredSuccessStreak && $state->currentSuccessStreak >= $state->requiredSuccessStreak,
            'recent_reliability_ok' => $state->currentSuccessStreak >= $state->requiredSuccessStreak,
            'correction_rate_ok' => ($state->totalEdits / $attempts) <= 0.20,
            'failure_rate_ok' => ($state->totalFailures / $attempts) <= 0.10,
            'reversal_rate_ok' => ($state->totalReversals / $attempts) <= 0.05,
            'context_stable' => $assuranceApproved && $assuranceStatus === 'GREEN',
            'data_complete' => $assuranceApproved && $assuranceStatus === 'GREEN',
            'integrations_healthy' => ($assurance['available'] ?? true) === true && $runtimeAvailable,
            'tool_model_reliable' => $runtimeAvailable && $assuranceApproved && $assuranceStatus === 'GREEN',
            'in_distribution' => $assuranceApproved && $assuranceStatus === 'GREEN',
            'ambiguity_acceptable' => $assuranceApproved && $assuranceStatus === 'GREEN',
            'assurance_status' => $assuranceStatus,
            'amber_mitigated' => false,
            'confidence' => $confidence,
            'confidence_threshold_met' => $confidence >= $this->minimumConfidence,
        ]);

        $aiReasonCodes = array_values(array_unique(array_merge(
            array_values(array_filter((array) ($assurance['reason_codes'] ?? []), 'is_string')),
            array_values(array_filter((array) ($titanAi['reason_codes'] ?? []), 'is_string')),
            $evaluation['reason_codes'],
        )));

        return $this->grantService->grantNextLevel(
            state: $state,
            requestedLevel: AutonomyLevel::TrustedAuto,
            gate: $gate,
            actorUserId: $actorUserId,
            actorCanGrant: $actorCanGrant,
            userDecision: $userDecision,
            aiAssuranceDecision: $evaluation['decision'],
            aiConfidence: $evaluation['confidence'],
            platformReasonCodes: $gate->reasonCodes,
            aiReasonCodes: $aiReasonCodes,
            assuranceEvaluationRef: isset($assurance['evaluation_ref']) ? (string) $assurance['evaluation_ref'] : null,
            scope: $scope,
            correlationId: $correlationId,
        );
    }
}
