# Titan Forge v0.6.0-alpha.1

## Scope

Cumulative governance-bridge release implementing Forge roadmap passes 11–15 on the Forge side:

- Pass 11 — Titan Signal lifecycle adapter
- Pass 12 — fail-closed Command Bus release boundary
- Pass 13 — Titan Risk release assessment
- Pass 14 — Titan Shield governance-response bridge
- Pass 15 — fail-closed Governance decision boundary

Model Council selective activation assessment is included for high/critical risk candidates, but formal Forge roadmap Pass 18 remains later because the verified Council peer reports `governed_deliberation=false`.

## Added

- lazy optional peer adapters for Signal, Risk, Shield and Model Council
- explicit health-only/fail-closed Governance and Command Bus boundaries
- `ReleaseGovernanceService`
- `ReleaseGateResult`, `CouncilReview` and `ForgeSignalEvent`
- tenant-scoped `EloquentReleaseRepository`
- persisted release candidates after successful local validation
- release-gate fingerprints and structured evidence
- lifecycle emission to Titan Signal when its public emitter is installed
- event-specific signal idempotency keys
- high-risk Council activation assessment without code/source disclosure

## Non-goals

- no direct install/deploy action
- no fabricated Governance approval API
- no fabricated Command Bus dispatch API
- no Model Council deliberation completion claim
- no AI/LLM code generation
- no arbitrary shell execution
