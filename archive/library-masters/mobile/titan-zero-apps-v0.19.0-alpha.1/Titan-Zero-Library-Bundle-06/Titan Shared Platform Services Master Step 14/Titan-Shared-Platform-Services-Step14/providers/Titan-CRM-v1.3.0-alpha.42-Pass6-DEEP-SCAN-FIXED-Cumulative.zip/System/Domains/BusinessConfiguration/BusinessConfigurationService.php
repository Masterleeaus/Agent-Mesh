<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Domains\BusinessConfiguration;

use App\Extensions\Crm\System\Integrations\ExternalDomains\CrmExternalDomainCapabilityBridge;
use App\Extensions\Crm\System\Services\CrmSettingsService;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class BusinessConfigurationService
{
    private const SETTING_KEYS=['business.profile','business.booking_rules','business.pricing','business.field_rules','business.notification_defaults','business.invoice_settings'];

    public function __construct(
        private readonly ConnectionInterface $db,
        private readonly CrmSettingsService $settings,
        private readonly BusinessHoursService $hours,
        private readonly CrmExternalDomainCapabilityBridge $externalDomains,
    ) {}

    public function profile(int $actor): array { return (array)$this->settings->get($actor,'business.profile',[]); }
    public function updateProfile(int $actor,array $data): array
    {
        $timezone=trim((string)($data['timezone']??($this->profile($actor)['timezone']??'')));
        if($timezone!==''&&!in_array($timezone,\DateTimeZone::listIdentifiers(),true))throw new InvalidArgumentException('Business profile timezone must be a valid IANA timezone.');
        $allowed=['name','legal_name','email','phone','website','timezone','currency','tax_identifier','selected_vertical','metadata'];
        $current=$this->profile($actor);$next=array_replace($current,array_intersect_key($data,array_flip($allowed)));
        $this->settings->setMany($actor,['business.profile'=>$next]); return $next;
    }
    public function hours(int $actor):array{return $this->hours->read($actor);} public function updateHours(int $actor,array $data):array{return $this->hours->update($actor,$data);}
    public function service(int $actor,string $id):?array{return $this->externalDomains->execute('crm.service.read',$actor,['public_id'=>$id]);} public function createService(int $actor,array $data):array{return $this->externalDomains->execute('crm.service.create',$actor,$data);} public function updateService(int $actor,string $id,array $data):array{return $this->externalDomains->execute('crm.service.update',$actor,$data+['public_id'=>$id]);}

    public function locations(int $actor):array{return $this->db->table('crm_business_locations')->where('company_id',CrmCompanyScope::companyId($actor))->orderByDesc('primary')->orderBy('name')->get()->map(fn($r)=>(array)$r)->all();}
    public function createLocation(int $actor,array $data):array
    {
        $name=trim((string)($data['name']??''));$timezone=trim((string)($data['timezone']??($this->profile($actor)['timezone']??'')));
        if($name==='')throw new InvalidArgumentException('Business location name is required.');if($timezone===''||!in_array($timezone,\DateTimeZone::listIdentifiers(),true))throw new InvalidArgumentException('Business location timezone is required.');
        $id=(string)Str::ulid();$row=$this->locationPayload($data)+['public_id'=>$id,'company_id'=>CrmCompanyScope::companyId($actor),'name'=>$name,'timezone'=>$timezone,'created_at'=>now(),'updated_at'=>now()];
        if($row['primary'])$this->db->table('crm_business_locations')->where('company_id',CrmCompanyScope::companyId($actor))->update(['primary'=>false,'updated_at'=>now()]);
        $this->db->table('crm_business_locations')->insert($row);return (array)$this->db->table('crm_business_locations')->where('company_id',CrmCompanyScope::companyId($actor))->where('public_id',$id)->first();
    }
    public function updateLocation(int $actor,string $id,array $data):array
    {
        $q=$this->db->table('crm_business_locations')->where('company_id',CrmCompanyScope::companyId($actor))->where('public_id',$id);$current=$q->first();if(!$current)throw new InvalidArgumentException('Business location not found.');
        $merged=array_replace((array)$current,$data);$payload=$this->locationPayload($merged);$payload['name']=trim((string)$merged['name']);$payload['timezone']=(string)$merged['timezone'];$payload['updated_at']=now();
        if($payload['primary'])$this->db->table('crm_business_locations')->where('company_id',CrmCompanyScope::companyId($actor))->where('public_id','!=',$id)->update(['primary'=>false,'updated_at'=>now()]);
        $q->update($payload);return (array)$q->first();
    }
    public function updateServiceArea(int $actor,array $data):array { $cap=empty($data['public_id'])?'crm.service_area.create':'crm.service_area.update'; return $this->externalDomains->execute($cap,$actor,$data); }
    public function readSetting(int $actor,string $key):array { $this->assertSettingKey($key);return (array)$this->settings->get($actor,$key,[]); }
    public function updateSetting(int $actor,string $key,array $value):array { $this->assertSettingKey($key);$this->settings->setMany($actor,[$key=>$value]);return $value; }

    public function inviteStaff(int $actor,array $data):array
    {
        $inviter=config('crm.tenancy.staff_inviter');
        if(!is_string($inviter)||$inviter===''||!class_exists($inviter)) throw new \RuntimeException('Host staff invitation adapter is not configured; CRM will not write membership tables directly.');
        $service=app($inviter);if(!method_exists($service,'invite'))throw new \RuntimeException('Configured staff invitation adapter does not support invite().');
        return (array)$service->invite(CrmCompanyScope::companyId($actor),$actor,$data);
    }
    public function assignStaffRole(int $actor,array $data):array
    {
        $adapter=config('crm.tenancy.staff_role_assigner');
        if(!is_string($adapter)||$adapter===''||!class_exists($adapter)) throw new \RuntimeException('Host staff role adapter is not configured; CRM will not write membership tables directly.');
        $service=app($adapter);if(!method_exists($service,'assign'))throw new \RuntimeException('Configured staff role adapter does not support assign().');
        return (array)$service->assign(CrmCompanyScope::companyId($actor),$actor,$data);
    }

    private function assertSettingKey(string $key):void { if(!in_array($key,self::SETTING_KEYS,true))throw new InvalidArgumentException('Unsupported business configuration setting.'); }
    private function locationPayload(array $d):array{return ['location_type'=>$d['location_type']??'operating_site','address_line_1'=>$d['address_line_1']??null,'address_line_2'=>$d['address_line_2']??null,'suburb'=>$d['suburb']??null,'state'=>$d['state']??null,'postcode'=>$d['postcode']??null,'country'=>$d['country']??null,'primary'=>(bool)($d['primary']??false),'active'=>(bool)($d['active']??true),'metadata'=>isset($d['metadata'])?(is_string($d['metadata'])?$d['metadata']:json_encode($d['metadata'])):null];}
}
