# Security

- `tenant_company_id` is resolved only from trusted application context; request input cannot claim a tenant.
- Response acceptance is scoped by authenticated user, tenant, chat and shared UUID. Null shared UUIDs never trigger sibling deletion.
- Provider credentials are not stored in Council decision/participant records or Signal payloads.
- Signal payloads redact password, token, secret, authorization and signature fields.
- Model outputs are treated as untrusted analysis artifacts; no hidden chain-of-thought is required or stored.
- Governed pre-validation can stop arbitration. Risk `BLOCK`/`REDUCE_AUTHORITY`/`REQUIRE_APPROVAL` cannot be raised by Council consensus.
