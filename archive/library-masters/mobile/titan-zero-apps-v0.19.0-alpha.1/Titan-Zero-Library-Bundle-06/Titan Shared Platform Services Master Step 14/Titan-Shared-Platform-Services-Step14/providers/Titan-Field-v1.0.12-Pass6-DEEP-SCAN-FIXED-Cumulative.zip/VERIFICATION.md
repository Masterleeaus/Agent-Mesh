# Titan Field Verification — 1.0.0

Pass 5 certification is cumulative and must keep every earlier regression gate green on both source and freshly extracted final ZIP bytes.

Required checks:

- Passes 1–5 standalone regression gates;
- embedded extraction/hardening verifier;
- PHP syntax validation across every PHP file;
- JSON parsing across every JSON file;
- all 10 canonical vertical profiles;
- retained-domain migrations with no destructive `down()` drops;
- self-healing legacy CRM named-route/menu compatibility;
- direct CRM implementation imports absent from Field domains/controller/routes;
- tenant/reference integrity and active worker validation;
- transactional Signal outbox and governed capability metadata;
- `FieldCommandGateway` / authorizer / router provider bindings;
- all browser mutation controller methods enter the governed command gateway;
- all read/write capability definitions declare a canonical permission and command gateway;
- command idempotency receipts use tenant-scoped bounded hashes plus request fingerprints;
- legacy `crm.*` capability aliases and legacy CRM field permission aliases remain resolvable;
- Field-owned permission service honors canonical or legacy host Gates and can operate in strict fail-closed mode;
- command/outbox/audit evidence is retained on rollback;
- evidence file compensation exists for an outer command-transaction failure;
- integrity maps match exact packaged bytes;
- archive traversal, backslash, duplicate, case-collision, symlink and junk-path checks.

The final reply records the exact assertion/check counts produced by fresh verification. A full Laravel/MySQL deployment remains required in Pass 16 before the overall programme is declared production-certified.

## Pass 6
Verify `tests/TitanFieldPass6RecurrenceAvailabilityPoliciesTest.php` plus inherited Pass 1-5 gates. The embedded verifier also asserts recurrence policy ownership, restartable retained policy migrations, and SchedulingKernel integration.

## Pass 7
- SchedulingKernel v2 retains all Pass 6 hard constraints and adds configured service-area enforcement plus daily load/remaining-capacity metrics.
- Technician recommendations are read-only, rank only kernel-eligible workers, return explicit ineligible reasons, and cannot assign work directly.
- Travel scoring uses deterministic Haversine fallback with no hidden network dependency.
- `titan.field.scheduling.recommend_workers` retains `crm.scheduling.recommend_workers` as its compatibility alias.
- `tests/TitanFieldPass7SchedulingRecommendationsTest.php` is the dedicated architecture regression gate.

## Pass 8
Run `php tests/TitanFieldPass8RecommendationHardeningTest.php`. The gate verifies the v3 explainable recommendation policy, workload/territory/route/continuity evidence, immutable recommendation snapshot store and alpha.9 release contract.

## Pass 9 — SLA + Operational Exceptions
Titan Field v1.0.0-alpha.10 adds the governed operational exception queue, SLA deadlines, deduplicated detection, lifecycle history, Signals, menu/UI and command-gateway mutations.


## Pass 10
Run `php tests/TitanFieldPass10RoutesLivePositionTest.php`. Verify retained route/location migrations, governed route commands, self-healing Routes & Live Map navigation, privacy controls, transactional Signals, and no optimizer claim.

## Joint Pass 11
- Titan Maps is an optional runtime peer; Titan Field still boots and routes without it.
- `SpatialIntelligenceGateway` selects Maps only when its peer contract is bound/healthy and otherwise uses deterministic Field fallbacks.
- Preferred high-frequency GPS ingestion no longer inserts directly from `RouteService`; peer writes go to Maps and standalone fallback writes remain bounded by Field privacy policy.
- Field Control is read-only except for move/resize actions, which execute `titan.field.scheduling|reschedule_appointment` through the governed command gateway and `SchedulingKernel`.
- Maps graphical assets are loaded only when the Maps asset route exists.


## Joint Pass 12
- `tests/TitanFieldPass12WorkOrderHealthProfitabilityTest.php` verifies the read-only health/profitability boundary and pure calculator behavior.
- `SpatialIntelligenceGateway::workOrderCostEvidence()` must be implemented by both Maps-preferred and Field fallback paths.
- Health projection must not insert/update authoritative records.
- Incomplete cost coverage must return null forecast/margin rather than inferred cost.
- Fresh package certification must re-run Pass 1–12 gates plus `bin/verify-extraction.php`.

## Joint Pass 13

Run `php tests/TitanFieldPass13CapacityForecastingTest.php` plus all inherited Pass 1–12 gates. Verify the forecast is read-only, uses retained worker/availability/appointment/work-demand records, exposes skill/service-area pressure, and consumes Maps `capacityPressureEvidence` only through `SpatialIntelligenceGateway`. Spatial evidence must remain non-authoritative and no forecast endpoint may assign/reschedule work.

## Pass 14

Run `php tests/TitanFieldPass14OfflineRuntimeTest.php`. Certification also runs Passes 1–13, `php bin/verify-extraction.php`, whole-tree PHP/JSON validation and fresh-ZIP byte/integrity checks. The Pass-14 gate proves device-bound replay, entity-version conflicts, governed command routing, offline API wiring and spatial replay contracts.


## Pass 15

Run `php tests/TitanFieldPass15OptimisationWorkforceTest.php`. Certification must also run every Pass 1–14 regression gate, `php bin/verify-extraction.php`, whole-tree PHP/JSON validation, direct peer-import scans, and fresh-ZIP byte/integrity checks. The Pass-15 gate proves Maps remains proposal-only, Field owns accept/reject/apply, stale baselines fail closed, route application reuses the governed Field writer, and Workforce Manifest 2.0 contributions cannot self-activate or bypass command/risk/autonomy governance.
