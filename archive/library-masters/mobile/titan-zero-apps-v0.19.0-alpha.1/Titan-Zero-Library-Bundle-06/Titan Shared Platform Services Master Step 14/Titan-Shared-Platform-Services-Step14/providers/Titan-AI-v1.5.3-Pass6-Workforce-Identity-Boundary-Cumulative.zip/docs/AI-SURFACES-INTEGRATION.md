# AI surfaces integration

## Source registry

TitanAI supports concurrent product integrations through `ConversationSourceRegistry`:

- `aichatpro` — authenticated staff workspace;
- `ai-agent` — autonomous workflow execution;
- `ai-agent-copilot` — workflow-builder Copilot;
- future sources such as `chatbot` can register without replacing existing sources.

Source adapters contribute trusted deployment/context. They no longer own generic provider execution.

## Principal and actor

`TitanAIRequest` separates:

- `companyId` — canonical security boundary;
- `userId` / principal user — host authority and credit identity;
- `actorType` + `actorId` — actual actor, e.g. staff user or workflow.

## Source policy

`ConversationSourcePolicyRegistry` filters capabilities, deterministic business-action access and trusted tools.

- AIChatPro staff may use governed business actions only within current host permission policy.
- AI Agent Copilot cannot execute deterministic WorkCore actions while editing a workflow.
- Autonomous AI Agent workflows can use business actions only when explicit workflow permission grants intersect current principal permissions.

## Trusted tools

Dynamic tool definitions are server-contributed through `TrustedToolContributionRegistry`; request/browser tool schemas are rejected.

The registry distinguishes server tools from client actions so one source cannot trick TitanAI into executing UI-only actions on the server.

## Provider execution

All authenticated AIChatPro and AI Agent generation now converges on TitanAI's `ProviderExecutionRegistry`. The default `magicai-host` gateway owns shared provider/model routing and host credit accounting. Product adapters no longer call their former generic provider services.
