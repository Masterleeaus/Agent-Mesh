<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

final class CrmPresentationService
{
    public function __construct(private CrmViewDataService $views) {}

    public function executiveSnapshot(int $userId): array
    {
        $data = $this->views->reports($userId);
        return [
            'title' => 'CRM Executive Snapshot',
            'generated_at' => now()->toIso8601String(),
            'slides' => [
                ['title' => 'CRM Health', 'kind' => 'metrics', 'data' => $data['summary']],
                ['title' => 'Sales Forecast', 'kind' => 'forecast', 'data' => $data['forecast']],
                ['title' => 'Pipeline Performance', 'kind' => 'pipelines', 'data' => $data['pipelines']],
            ],
        ];
    }
}
