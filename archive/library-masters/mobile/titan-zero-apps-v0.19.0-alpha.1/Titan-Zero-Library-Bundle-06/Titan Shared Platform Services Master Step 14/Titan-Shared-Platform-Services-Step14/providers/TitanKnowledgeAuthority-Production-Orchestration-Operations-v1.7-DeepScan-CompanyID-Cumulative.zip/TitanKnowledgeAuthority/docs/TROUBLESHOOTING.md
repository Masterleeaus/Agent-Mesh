# Troubleshooting
Validate `extension.json` and `extension.manifest.json`, confirm the physical folder is exactly `TitanKnowledgeAuthority`, confirm the provider path/casing, run PHP lint, then verify both migrations. Host-specific failures require checking Laravel boot, route registration, navigation registries, middleware, and database migration execution.
