<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration {
    public function up(): void
    {
        $this->extendInvoices();
        $this->createSettlementReferences();
        $this->createCreditNotes();
        $this->createReconciliationIssues();
        $this->backfillLegacyPayments();
        $this->backfillIssuedInvoiceSnapshots();
    }

    private function extendInvoices(): void
    {
        if (!Schema::hasTable('crm_invoices')) return;
        $columns=[
            'source_quote_public_id'=>fn(Blueprint $t)=>$t->char('source_quote_public_id',26)->nullable()->index('crm_inv_source_quote_idx'),
            'source_quote_snapshot_hash'=>fn(Blueprint $t)=>$t->char('source_quote_snapshot_hash',64)->nullable()->index('crm_inv_source_quote_hash_idx'),
            'source_quote_revision_root_public_id'=>fn(Blueprint $t)=>$t->char('source_quote_revision_root_public_id',26)->nullable()->index('crm_inv_quote_root_idx'),
            'source_work_order_public_id'=>fn(Blueprint $t)=>$t->char('source_work_order_public_id',26)->nullable()->index('crm_inv_source_work_idx'),
            'issued_snapshot'=>fn(Blueprint $t)=>$t->json('issued_snapshot')->nullable(),
            'issued_snapshot_hash'=>fn(Blueprint $t)=>$t->char('issued_snapshot_hash',64)->nullable()->index('crm_inv_issued_hash_idx'),
            'invoice_contract_version'=>fn(Blueprint $t)=>$t->string('invoice_contract_version',30)->default('1.0'),
            'credited_minor'=>fn(Blueprint $t)=>$t->bigInteger('credited_minor')->default(0),
            'refunded_minor'=>fn(Blueprint $t)=>$t->bigInteger('refunded_minor')->default(0),
            'refund_due_minor'=>fn(Blueprint $t)=>$t->bigInteger('refund_due_minor')->default(0),
            'receivable_state'=>fn(Blueprint $t)=>$t->string('receivable_state',30)->default('open')->index('crm_inv_receivable_state_idx'),
            'void_reason'=>fn(Blueprint $t)=>$t->text('void_reason')->nullable(),
            'voided_by_user_id'=>fn(Blueprint $t)=>$t->unsignedBigInteger('voided_by_user_id')->nullable()->index('crm_inv_void_actor_idx'),
            'lineage_meta'=>fn(Blueprint $t)=>$t->json('lineage_meta')->nullable(),
            'sent_at'=>fn(Blueprint $t)=>$t->timestamp('sent_at')->nullable()->index('crm_inv_sent_at_idx'),
            'viewed_at'=>fn(Blueprint $t)=>$t->timestamp('viewed_at')->nullable()->index('crm_inv_viewed_at_idx'),
        ];
        foreach($columns as $column=>$add){ if(!Schema::hasColumn('crm_invoices',$column)) Schema::table('crm_invoices',$add); }
    }

    private function createSettlementReferences(): void
    {
        if (Schema::hasTable('crm_invoice_settlement_references')) return;
        Schema::create('crm_invoice_settlement_references', function(Blueprint $t): void {
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('tenant_company_id')->index();$t->unsignedBigInteger('user_id')->nullable()->index();
            $t->char('invoice_public_id',26)->index();$t->string('external_owner',60)->default('titan-pay')->index();$t->string('external_payment_public_id',120)->nullable()->index('crm_inv_settle_ext_payment_idx');
            $t->string('provider',80)->nullable()->index();$t->string('provider_reference',190)->nullable()->index();$t->string('direction',20)->index();
            $t->bigInteger('amount_minor');$t->string('currency',3);$t->string('status',30)->default('applied')->index();$t->boolean('verified')->default(false)->index();
            $t->timestamp('verified_at')->nullable();$t->timestamp('occurred_at')->nullable()->index();$t->string('source_event_id',190)->nullable()->index();
            $t->string('idempotency_key',190);$t->char('payload_hash',64);$t->json('metadata')->nullable();$t->timestamps();
            $t->unique(['tenant_company_id','idempotency_key'],'crm_inv_settle_idem_uq');
            $t->index(['tenant_company_id','invoice_public_id','status'],'crm_inv_settle_invoice_idx');
        });
    }

    private function createCreditNotes(): void
    {
        if(!Schema::hasTable('crm_credit_notes')){
            Schema::create('crm_credit_notes',function(Blueprint $t):void{
                $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('tenant_company_id')->index();$t->unsignedBigInteger('user_id')->index();
                $t->char('invoice_public_id',26)->index();$t->unsignedBigInteger('entity_version')->default(1);$t->string('number',80)->nullable()->index();$t->string('status',30)->default('draft')->index();$t->string('currency',3);
                $t->bigInteger('subtotal_minor')->default(0);$t->bigInteger('tax_minor')->default(0);$t->bigInteger('total_minor')->default(0);$t->text('reason')->nullable();
                $t->json('issued_snapshot')->nullable();$t->char('issued_snapshot_hash',64)->nullable()->index();$t->timestamp('issued_at')->nullable();$t->timestamp('voided_at')->nullable();
                $t->unsignedBigInteger('voided_by_user_id')->nullable();$t->char('snapshot_hash',64)->nullable()->index();$t->json('meta')->nullable();$t->timestamps();$t->softDeletes();
                $t->index(['tenant_company_id','invoice_public_id','status'],'crm_credit_invoice_status_idx');
            });
        }
        if(!Schema::hasTable('crm_credit_note_lines')){
            Schema::create('crm_credit_note_lines',function(Blueprint $t):void{
                $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('tenant_company_id')->index();$t->unsignedBigInteger('user_id')->index();
                $t->char('credit_note_public_id',26)->index();$t->unsignedInteger('sequence');$t->string('description');$t->unsignedBigInteger('quantity_milli')->default(1000);
                $t->bigInteger('unit_price_minor')->default(0);$t->unsignedInteger('tax_rate_bps')->default(0);$t->bigInteger('line_subtotal_minor')->default(0);
                $t->bigInteger('line_tax_minor')->default(0);$t->bigInteger('line_total_minor')->default(0);$t->json('meta')->nullable();$t->timestamps();
                $t->index(['tenant_company_id','credit_note_public_id','sequence'],'crm_credit_lines_idx');
            });
        }
    }

    private function createReconciliationIssues(): void
    {
        if(Schema::hasTable('crm_receivable_reconciliation_issues'))return;
        Schema::create('crm_receivable_reconciliation_issues',function(Blueprint $t):void{
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('tenant_company_id')->index();$t->char('invoice_public_id',26)->nullable()->index();
            $t->char('settlement_reference_public_id',26)->nullable()->index('crm_recv_issue_settle_ref_idx');$t->unsignedBigInteger('entity_version')->default(1);$t->string('issue_type',60)->index();$t->string('severity',20)->default('high')->index();
            $t->string('status',30)->default('open')->index();$t->json('expected')->nullable();$t->json('actual')->nullable();$t->text('resolution_notes')->nullable();
            $t->timestamp('resolved_at')->nullable();$t->unsignedBigInteger('resolved_by_user_id')->nullable();$t->timestamps();
            $t->index(['tenant_company_id','status','severity'],'crm_recv_issue_status_idx');
        });
    }

    private function backfillLegacyPayments(): void
    {
        if(!Schema::hasTable('crm_payments')||!Schema::hasTable('crm_payment_allocations')||!Schema::hasTable('crm_invoice_settlement_references'))return;
        DB::table('crm_payment_allocations')->orderBy('id')->chunkById(200,function($allocations):void{
            foreach($allocations as $allocation){
                $payment=DB::table('crm_payments')->where('tenant_company_id',$allocation->tenant_company_id)->where('public_id',$allocation->payment_public_id)->first();
                if(!$payment)continue;
                $key='legacy-crm:'.$allocation->payment_public_id.':'.$allocation->invoice_public_id;
                if(DB::table('crm_invoice_settlement_references')->where('tenant_company_id',$allocation->tenant_company_id)->where('idempotency_key',$key)->exists())continue;
                $payload=['payment_public_id'=>$allocation->payment_public_id,'invoice_public_id'=>$allocation->invoice_public_id,'allocated_minor'=>(int)$allocation->allocated_minor,'currency'=>$allocation->currency];
                DB::table('crm_invoice_settlement_references')->insert([
                    'public_id'=>(string)Str::ulid(),'tenant_company_id'=>$allocation->tenant_company_id,'user_id'=>$allocation->user_id??null,'invoice_public_id'=>$allocation->invoice_public_id,
                    'external_owner'=>'legacy-crm','external_payment_public_id'=>$allocation->payment_public_id,'provider'=>$payment->provider??null,'provider_reference'=>$payment->provider_reference??null,
                    'direction'=>'payment','amount_minor'=>(int)$allocation->allocated_minor,'currency'=>(string)$allocation->currency,'status'=>'applied','verified'=>(string)($payment->reconciliation_status??'')==='reconciled',
                    'verified_at'=>(string)($payment->reconciliation_status??'')==='reconciled'?($payment->updated_at??now()):null,'occurred_at'=>$payment->paid_at??$payment->created_at??now(),
                    'source_event_id'=>null,'idempotency_key'=>$key,'payload_hash'=>hash('sha256',(string)json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),
                    'metadata'=>json_encode(['migration'=>'alpha30','legacy_payment_number'=>$payment->number??null]),'created_at'=>now(),'updated_at'=>now(),
                ]);
            }
        },'id');
    }

    private function backfillIssuedInvoiceSnapshots(): void
    {
        if(!Schema::hasTable('crm_invoices')||!Schema::hasColumn('crm_invoices','issued_snapshot_hash'))return;
        DB::table('crm_invoices')->whereNull('deleted_at')->whereNull('issued_snapshot_hash')->where(function($q):void{$q->whereNotNull('issued_at')->orWhereIn('status',['issued','sent','viewed','paid','void']);})->orderBy('id')->chunkById(200,function($rows):void{
            foreach($rows as $row){
                $lines=Schema::hasTable('crm_sales_document_lines')?DB::table('crm_sales_document_lines')->where('tenant_company_id',$row->tenant_company_id)->where('document_type','invoices')->where('document_public_id',$row->public_id)->orderBy('sequence')->get()->map(fn($l)=>[
                    'sequence'=>(int)$l->sequence,'description'=>(string)$l->description,'quantity_milli'=>(int)$l->quantity_milli,'unit_price_minor'=>(int)$l->unit_price_minor,'tax_rate_bps'=>(int)$l->tax_rate_bps,
                    'line_subtotal_minor'=>(int)$l->line_subtotal_minor,'line_tax_minor'=>(int)$l->line_tax_minor,'line_total_minor'=>(int)$l->line_total_minor,
                ])->all():[];
                $snapshot=['schema'=>'crm.invoice-contract.v1','document_public_id'=>(string)$row->public_id,'number'=>$row->number,'company_public_id'=>$row->company_public_id,'contact_public_id'=>$row->contact_public_id,
                    'currency'=>(string)$row->currency,'subtotal_minor'=>(int)$row->subtotal_minor,'tax_minor'=>(int)$row->tax_minor,'total_minor'=>(int)$row->total_minor,'due_at'=>$row->due_at,
                    'source_quote_public_id'=>$row->source_quote_public_id??null,'source_quote_snapshot_hash'=>$row->source_quote_snapshot_hash??null,'source_work_order_public_id'=>$row->source_work_order_public_id??($row->work_order_public_id??null),
                    'legacy_backfill'=>true,'lines'=>$lines];
                $encoded=json_encode($snapshot,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
                DB::table('crm_invoices')->where('id',$row->id)->update(['issued_snapshot'=>$encoded,'issued_snapshot_hash'=>hash('sha256',(string)$encoded),'invoice_contract_version'=>'1.0','updated_at'=>now()]);
            }
        },'id');
    }

    public function down(): void
    {
        Schema::dropIfExists('crm_receivable_reconciliation_issues');Schema::dropIfExists('crm_credit_note_lines');Schema::dropIfExists('crm_credit_notes');Schema::dropIfExists('crm_invoice_settlement_references');
        if(!Schema::hasTable('crm_invoices'))return;
        foreach(['viewed_at','sent_at','lineage_meta','voided_by_user_id','void_reason','receivable_state','refund_due_minor','refunded_minor','credited_minor','invoice_contract_version','issued_snapshot_hash','issued_snapshot','source_work_order_public_id','source_quote_revision_root_public_id','source_quote_snapshot_hash','source_quote_public_id'] as $column){
            if(Schema::hasColumn('crm_invoices',$column))Schema::table('crm_invoices',fn(Blueprint $t)=>$t->dropColumn($column));
        }
    }
};
