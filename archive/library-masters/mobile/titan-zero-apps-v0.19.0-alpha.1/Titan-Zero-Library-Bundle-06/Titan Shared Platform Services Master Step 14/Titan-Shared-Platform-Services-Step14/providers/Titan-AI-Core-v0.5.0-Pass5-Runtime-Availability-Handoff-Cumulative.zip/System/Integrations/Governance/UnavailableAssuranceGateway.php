<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Integrations\Governance;

use App\Extensions\TitanAICore\System\Contracts\AssuranceGatewayContract;
use App\Extensions\TitanAICore\System\DTO\GovernanceDecision;
use App\Extensions\TitanAICore\System\DTO\GovernancePreflightRequest;

final class UnavailableAssuranceGateway implements AssuranceGatewayContract
{
    public function evaluate(GovernancePreflightRequest $request): GovernanceDecision
    {
        return GovernanceDecision::defer('assurance', 'ASSURANCE_GATEWAY_UNAVAILABLE', 'Titan Assurance is not connected; execution remains blocked.');
    }
}
