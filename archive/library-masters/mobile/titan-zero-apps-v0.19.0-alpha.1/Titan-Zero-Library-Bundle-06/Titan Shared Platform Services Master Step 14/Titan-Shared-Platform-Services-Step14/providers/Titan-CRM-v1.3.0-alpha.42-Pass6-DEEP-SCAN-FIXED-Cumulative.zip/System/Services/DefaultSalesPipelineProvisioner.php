<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

final class DefaultSalesPipelineProvisioner
{
    public const STAGES = [
        ['key'=>'new','name'=>'New','color'=>'#64748b','probability'=>10,'position'=>0,'is_closed'=>false,'is_won'=>false],
        ['key'=>'qualified','name'=>'Qualified','color'=>'#2563eb','probability'=>30,'position'=>1,'is_closed'=>false,'is_won'=>false],
        ['key'=>'proposal','name'=>'Proposal','color'=>'#9333ea','probability'=>55,'position'=>2,'is_closed'=>false,'is_won'=>false],
        ['key'=>'negotiation','name'=>'Negotiation','color'=>'#d97706','probability'=>80,'position'=>3,'is_closed'=>false,'is_won'=>false],
        ['key'=>'won','name'=>'Won','color'=>'#16a34a','probability'=>100,'position'=>4,'is_closed'=>true,'is_won'=>true],
        ['key'=>'lost','name'=>'Lost','color'=>'#dc2626','probability'=>0,'position'=>5,'is_closed'=>true,'is_won'=>false],
    ];

    public function __construct(private ConnectionInterface $db) {}

    public function ensure(int $userId): array
    {
        return $this->db->transaction(function () use ($userId): array {
            $pipeline = $this->db->table(config('crm.tables.pipelines'))
                ->where('company_id', CrmCompanyScope::companyId($userId))->where('key', 'sales')->whereNull('deleted_at')
                ->lockForUpdate()->first();

            if ($pipeline === null) {
                $id = $this->db->table(config('crm.tables.pipelines'))->insertGetId([
                    'public_id'=>(string) Str::ulid(), 'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId), 'key'=>'sales', 'name'=>'Sales Pipeline',
                    'is_default'=>true, 'is_active'=>true, 'created_at'=>now(), 'updated_at'=>now(),
                ]);
                $pipeline = $this->db->table(config('crm.tables.pipelines'))->where('id', $id)->first();
            }

            foreach (self::STAGES as $stage) {
                $exists = $this->db->table(config('crm.tables.stages'))
                    ->where('company_id', CrmCompanyScope::companyId($userId))->where('pipeline_id', $pipeline->id)->where('key', $stage['key'])->whereNull('deleted_at')->exists();
                if ($exists) continue;
                $this->db->table(config('crm.tables.stages'))->insert($stage + [
                    'public_id'=>(string) Str::ulid(), 'company_id' => CrmCompanyScope::companyId($userId), 'pipeline_id'=>$pipeline->id, 'created_at'=>now(), 'updated_at'=>now(), 'is_active'=>true,
                ]);
            }

            return (array) $this->db->table(config('crm.tables.pipelines'))
                ->where('company_id', CrmCompanyScope::companyId($userId))->where('id', $pipeline->id)->first(['public_id','key','name','is_default','is_active']);
        }, 3);
    }
}
