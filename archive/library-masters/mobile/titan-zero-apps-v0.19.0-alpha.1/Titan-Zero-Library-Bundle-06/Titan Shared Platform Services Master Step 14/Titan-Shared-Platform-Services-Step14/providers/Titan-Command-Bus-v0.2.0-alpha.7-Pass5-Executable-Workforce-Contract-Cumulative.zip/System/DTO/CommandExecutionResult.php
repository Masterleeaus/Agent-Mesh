<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\DTO;

final readonly class CommandExecutionResult
{
    public function __construct(
        public string $domainReceiptReference,
        public bool $writeVerified,
        public int|string|null $resultEntityId = null,
        public ?string $resultEntityType = null,
        public int|string|null $resultEntityVersion = null,
        public array $metadata = [],
    ) {
        if ($domainReceiptReference === '') {
            throw new \InvalidArgumentException('A domain receipt reference is required for applied mutations.');
        }
        if (! $writeVerified) {
            throw new \InvalidArgumentException('Applied mutations must be independently write-verified by the authoritative domain adapter.');
        }
    }
}
