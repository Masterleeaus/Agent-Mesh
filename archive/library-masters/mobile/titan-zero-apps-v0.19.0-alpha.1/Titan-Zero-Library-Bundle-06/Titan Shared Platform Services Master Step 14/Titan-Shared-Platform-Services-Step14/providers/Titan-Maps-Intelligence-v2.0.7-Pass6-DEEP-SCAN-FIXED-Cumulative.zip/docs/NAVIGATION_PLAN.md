# Titan Maps Intelligence v2 Navigation Plan

This navigation contract is intentionally documented in Pass 4 and implemented in the later UI/menu contribution pass. It keeps operational work separate from geographic intelligence and administration.

## Company/user navigation

### Field Operations

1. Live Map
2. Jobs Map
3. Team Map
4. Dispatch
5. Routes & ETA
6. Geofences
7. Check-ins

### Location Intelligence

1. Overview
2. Business Discovery
3. Candidates
4. Suppliers
5. Contractors
6. Competitors
7. Nearby Services

### Territories & Coverage

1. Service Areas
2. Territory Analysis
3. Service Gaps
4. Competitor Density
5. Supplier Coverage
6. Branch Coverage
7. Expansion Opportunities

### Travel & Routing

1. Today's Routes
2. Route Optimiser
3. Travel Matrix
4. Traffic & ETA
5. Travel Zones
6. Pricing Signals

## Company settings navigation

### Maps & Location

1. Providers
2. Google Maps & Places
3. Routing
4. Location Tracking
5. Geofences
6. Dispatch Rules
7. Travel Zones
8. Privacy & Retention
9. Usage & Limits

## Super Admin navigation

### Titan Maps Intelligence

1. Dashboard
2. Provider Health
3. Companies
4. Provider Connections
5. API Usage
6. API Costs
7. Routing Usage
8. Queue Health
9. Failed Requests
10. Global Limits
11. Location Policies
12. Retention Defaults
13. Permissions
14. Diagnostics

## Contribution rule

These links should be registered through extension navigation contributions rather than edits to MagicAI core sidebar files. Parent groups should only render when the current user has at least one visible permitted child. Child permissions remain capability-specific and company-scoped.
## Alpha 6.3 implementation note

The navigation visibility portion was brought forward from the later UI pass because alpha.6.2 installed successfully but had no host menu records. Alpha.6.3 now installs the parent/child hierarchy and working routed shell pages. Rich operational map canvases and live tracking still remain in their planned implementation passes.


## Alpha 7 implementation note

Pass 7 activates **Team Map** and **Check-ins**. Pass 8 brings **Live Map** forward with real graphical maps. Pass 9 now activates **Geofences** under Field Operations with visual circle/polygon drawing and confirmation-gated arrival/departure events. Jobs Map and Dispatch remain scheduled for their dedicated operational passes rather than being exposed as dead links.
