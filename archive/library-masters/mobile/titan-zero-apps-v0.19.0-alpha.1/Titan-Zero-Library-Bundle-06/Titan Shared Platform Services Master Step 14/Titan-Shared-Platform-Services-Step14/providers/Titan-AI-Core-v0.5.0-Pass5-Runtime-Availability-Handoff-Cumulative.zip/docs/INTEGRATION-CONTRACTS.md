# Integration Contracts

## Implemented Core-side ports

- `RiskGatewayContract`
- `AssuranceGatewayContract`
- `AutonomyGatewayContract`
- `GovernancePreflightContract`
- `CommandBusGatewayContract`

The default Risk/Assurance/Autonomy and Command Bus adapters fail closed when their external engines are not connected. They are intentional integration seams, not reimplementations of those engines.

## Governance data propagated

Preflight carries plan ID, step ID, tenant, actor identity/type, authority level, capability and causal context (`trace_id`, `correlation_id`, `causation_id`, `root_causation_id`).

Command Bus dispatch additionally carries operation ID and idempotency key. Core consumes the returned receipt; it does not mutate authoritative external domain state directly.

## Still future adapters

Workforce, Model Council, Knowledge Authority, Wisdom, Signal event emission and Rewind execution/reconstruction remain later-pass integrations.
