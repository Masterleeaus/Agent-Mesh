<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\ReadModels\CrmReadProjectionRegistry;
use Illuminate\Database\ConnectionInterface;
use Throwable;

/**
 * Read-only operational telemetry derived from durable CRM journals/outboxes.
 * This service never mutates authoritative or derived state.
 */
final class CrmOperationalMetricsService
{
    public function __construct(
        private readonly ConnectionInterface $db,
        private readonly CrmReadProjectionRegistry $projections,
    ) {}

    /** @return array<string,mixed> */
    public function collect(?int $companyId=null,int $windowHours=24): array
    {
        $windowHours=max(1,min(168,$windowHours));
        $since=now()->subHours($windowHours);
        return [
            'window_hours'=>$windowHours,
            'company_id'=>$companyId,
            'command_operations'=>$this->commandOperations($companyId,$since),
            'signal_outbox'=>$this->statusMetrics('crm_domain_signal_outbox',['pending','retry','claimed','dispatched','dead_letter'],$companyId,$since),
            'projection_health'=>$this->projectionHealth($companyId),
            'outbound_effects'=>$this->statusMetrics('crm_notification_outbox',['pending','processing','delivered','failed','deferred'],$companyId,$since),
            'imports'=>$this->statusMetrics('crm_import_batches',['validating','ready_to_commit','validation_failed','completed','failed','rolled_back'],$companyId,$since),
            'portal'=>$this->portalMetrics($companyId),
            'webhooks'=>$this->statusMetrics('crm_webhook_deliveries',['pending','sending','delivered','failed','dead_letter'],$companyId,$since),
            'document_rendering'=>$this->statusMetrics('crm_sales_document_render_jobs',['requested','rendering','ready','failed'],$companyId,$since),
            'concurrency_conflicts'=>$this->rejectionMetric($companyId,$since,'concurr'),
            'invariant_violations'=>$this->rejectionMetric($companyId,$since,'invariant'),
            'duplicate_replays'=>$this->duplicateReplayMetric($companyId,$since),
        ];
    }

    /** @return array<string,mixed> */
    private function commandOperations(?int $tenant,$since): array
    {
        if(!$this->hasTable('crm_capability_operations'))return ['available'=>false];
        $q=$this->db->table('crm_capability_operations');$this->tenant($q,$tenant);$this->since($q,'created_at',$since);
        $total=(int)(clone $q)->count();
        $statuses=[];foreach(['processing','completed','rejected'] as $status)$statuses[$status]=(int)(clone $q)->where('status',$status)->count();
        $latencies=[];
        if($this->hasColumn('crm_capability_operations','command_duration_ms')){
            $latencies=(clone $q)->whereNotNull('command_duration_ms')->orderBy('command_duration_ms')->pluck('command_duration_ms')->map(fn($v)=>(int)$v)->all();
        }
        $percentile=static function(array $values,float $p):int{if($values===[])return 0;$i=(int)floor((count($values)-1)*$p);return (int)$values[max(0,min(count($values)-1,$i))];};
        return [
            'available'=>true,'total'=>$total,'statuses'=>$statuses,
            'latency_ms'=>['avg'=>$latencies===[]?0:(int)round(array_sum($latencies)/count($latencies)),'p50'=>$percentile($latencies,.50),'p95'=>$percentile($latencies,.95),'max'=>$latencies===[]?0:max($latencies)],
        ];
    }

    /** @return array<string,mixed> */
    private function statusMetrics(string $table,array $statuses,?int $tenant,$since): array
    {
        if(!$this->hasTable($table))return ['available'=>false];
        $base=$this->db->table($table);$this->tenant($base,$tenant);$counts=[];
        foreach($statuses as $status)$counts[$status]=(int)(clone $base)->where('status',$status)->count();
        $recent=(clone $base);$this->since($recent,'created_at',$since);
        $oldest=$this->oldestBacklogAge($base,$statuses);
        return ['available'=>true,'statuses'=>$counts,'recent_total'=>(int)$recent->count(),'backlog_total'=>array_sum(array_intersect_key($counts,array_flip(['pending','retry','claimed','processing','sending','failed','deferred','requested','rendering','ready_to_commit','validation_failed','dead_letter']))),'oldest_backlog_age_seconds'=>$oldest];
    }

    /** @return array<string,mixed> */
    private function projectionHealth(?int $tenant): array
    {
        if(!$this->hasTable('crm_read_projection_state'))return ['available'=>false];
        $q=$this->db->table('crm_read_projection_state');$this->tenant($q,$tenant);$rows=$q->get();
        $stale=0;$obsolete=0;$maxLag=0;
        foreach($rows as $row){
            try{$def=$this->projections->resolve((string)$row->projection_name);$obsoleteRow=(string)$row->projection_version!==(string)$def['projection_version'];}
            catch(Throwable){$obsoleteRow=true;$def=[];}
            if($obsoleteRow){$obsolete++;continue;}
            $lag=0;$table=(string)($def['table']??'');
            if($table!==''&&$this->hasTable($table)&&$this->hasColumn($table,'updated_at')){
                $source=$this->db->table($table);$this->tenant($source,(int)$row->company_id);$latest=$source->max('updated_at');$last=$row->last_projected_at??$row->rebuilt_at??null;
                if($latest!==null){$sourceTs=strtotime((string)$latest);$lastTs=$last?strtotime((string)$last):false;$lag=$lastTs===false?PHP_INT_MAX:max(0,$sourceTs-$lastTs);}
            }
            $maxLag=max($maxLag,$lag);$sla=(int)($row->freshness_sla_seconds??300);if((string)($row->status??'stale')!=='ready'||$lag>$sla)$stale++;
        }
        $dead=0;if($this->hasTable('crm_read_projection_dead_letters')){$d=$this->db->table('crm_read_projection_dead_letters')->whereNull('resolved_at');$this->tenant($d,$tenant);$dead=(int)$d->count();}
        return ['available'=>true,'states'=>$rows->count(),'stale'=>$stale,'obsolete'=>$obsolete,'max_lag_seconds'=>$maxLag,'dead_letters'=>$dead];
    }

    /** @return array<string,mixed> */
    private function portalMetrics(?int $tenant): array
    {
        $out=['available'=>$this->hasTable('crm_portal_sessions')||$this->hasTable('crm_portal_files'),'active_sessions'=>0,'quarantined_files'=>0,'scan_failed_files'=>0,'infected_files'=>0];
        if($this->hasTable('crm_portal_sessions')){$q=$this->db->table('crm_portal_sessions')->whereNull('revoked_at')->where('expires_at','>',now());$this->tenant($q,$tenant);$out['active_sessions']=(int)$q->count();}
        if($this->hasTable('crm_portal_files'))foreach(['quarantined','scan_failed','infected'] as $s){$q=$this->db->table('crm_portal_files')->where('status',$s);$this->tenant($q,$tenant);$out[$s.'_files']=(int)$q->count();}
        return $out;
    }

    private function rejectionMetric(?int $tenant,$since,string $needle): int
    {
        if(!$this->hasTable('crm_capability_operations'))return 0;$q=$this->db->table('crm_capability_operations')->where('status','rejected');$this->tenant($q,$tenant);$this->since($q,'created_at',$since);
        if($this->hasColumn('crm_capability_operations','result'))$q->where('result','like','%'.$needle.'%');return (int)$q->count();
    }

    private function duplicateReplayMetric(?int $tenant,$since): int
    {
        if(!$this->hasTable('crm_capability_operations')||!$this->hasColumn('crm_capability_operations','duplicate_replay_count'))return 0;
        $q=$this->db->table('crm_capability_operations');$this->tenant($q,$tenant);$this->since($q,'created_at',$since);return (int)$q->sum('duplicate_replay_count');
    }

    private function oldestBacklogAge($query,array $statuses): int
    {
        $active=array_values(array_intersect($statuses,['pending','retry','claimed','processing','sending','failed','deferred','requested','rendering','ready_to_commit','validation_failed','dead_letter']));
        if($active===[]||!$this->hasColumn($query->from,'created_at'))return 0;$value=(clone $query)->whereIn('status',$active)->min('created_at');if($value===null)return 0;$ts=strtotime((string)$value);return $ts===false?0:max(0,time()-$ts);
    }

    private function tenant($query,?int $tenant): void
    {if($tenant!==null&&$tenant>0&&$this->hasColumn($query->from,'company_id'))$query->where('company_id',$tenant);}
    private function since($query,string $column,$since): void
    {if($this->hasColumn($query->from,$column))$query->where($column,'>=',$since);}
    private function hasTable(string $table): bool
    {try{return $this->db->getSchemaBuilder()->hasTable($table);}catch(Throwable){return false;}}
    private function hasColumn(string $table,string $column): bool
    {try{return $this->db->getSchemaBuilder()->hasTable($table)&&$this->db->getSchemaBuilder()->hasColumn($table,$column);}catch(Throwable){return false;}}
}
