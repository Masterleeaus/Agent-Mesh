<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Actions;

final class GovernanceCommandReceiptValidator
{
    /** @param array<string,mixed> $response @return array<string,mixed> */
    public function normalize(array $response,GovernanceActionRequest $request,string $decisionId): array
    {
        $status=strtoupper(trim((string)($response['status']??'')));
        if($status==='UNAVAILABLE') return [
            'schema_version'=>'1.0','status'=>'BLOCKED','reason_code'=>(string)($response['reason_code']??'COMMAND_BUS_UNAVAILABLE'),'operation_id'=>$request->operationId,'governance_decision_ref'=>$decisionId,'write_verified'=>false,
        ];
        if(!in_array($status,['APPLIED','BLOCKED','FAILED','REPLAYED'],true)) return $this->invalid($request,$decisionId);

        $normalized=[
            'schema_version'=>'1.0',
            'status'=>$status,
            'reason_code'=>$this->nullableString($response['reason_code']??null),
            'operation_id'=>$request->operationId,
            'command_receipt_ref'=>$this->nullableString($response['command_receipt_ref']??null),
            'authoritative_domain_receipt_ref'=>$this->nullableString($response['authoritative_domain_receipt_ref']??null),
            'write_verified'=>(bool)($response['write_verified']??false),
            'adapter'=>$this->nullableString($response['adapter']??null),
            'governance_decision_ref'=>$this->nullableString($response['governance_decision_ref']??null),
            'replayed'=>(bool)($response['replayed']??($status==='REPLAYED')),
        ];

        $decisionRef=$normalized['governance_decision_ref'];
        if($decisionRef!==null && $decisionRef!==$decisionId) return $this->invalid($request,$decisionId);
        if($status==='APPLIED'){
            if($decisionRef!==$decisionId || $normalized['command_receipt_ref']===null || $normalized['authoritative_domain_receipt_ref']===null || $normalized['adapter']===null || $normalized['write_verified']!==true) return $this->invalid($request,$decisionId);
        }
        if($status==='REPLAYED' && $normalized['command_receipt_ref']===null) return $this->invalid($request,$decisionId);
        return $normalized;
    }

    /** @return array<string,mixed> */
    private function invalid(GovernanceActionRequest $request,string $decisionId): array
    {
        return ['schema_version'=>'1.0','status'=>'FAILED','reason_code'=>'COMMAND_RECEIPT_INVALID','operation_id'=>$request->operationId,'governance_decision_ref'=>$decisionId,'write_verified'=>false];
    }

    private function nullableString(mixed $value): ?string
    {
        if($value===null)return null;$s=trim((string)$value);return $s===''?null:$s;
    }
}
