# Capabilities

Titan AI exposes governed runtime, provider, tool and context capabilities declared in `extension.manifest.json`. Organisational Workforce identities are not owned here.
