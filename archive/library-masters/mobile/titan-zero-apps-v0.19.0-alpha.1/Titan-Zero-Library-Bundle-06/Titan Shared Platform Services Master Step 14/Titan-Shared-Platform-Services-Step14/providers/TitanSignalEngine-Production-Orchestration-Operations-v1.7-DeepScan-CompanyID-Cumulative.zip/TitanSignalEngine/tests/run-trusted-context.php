<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/SignalSeverity.php';
require __DIR__ . '/../System/Data/SignalActor.php';
require __DIR__ . '/../System/Data/SignalEmitterIdentity.php';
require __DIR__ . '/../System/Data/SignalContext.php';
require __DIR__ . '/../System/Data/SignalEnvelope.php';
require __DIR__ . '/../System/Contracts/SignalEmitterAuthorityContract.php';
require __DIR__ . '/../System/Services/SignalEmitterAuthority.php';
require __DIR__ . '/../System/Services/SignalContextValidator.php';

use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEmitterIdentity;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;

function tcAssert(bool $condition, string $message): void {
    if (! $condition) throw new RuntimeException($message);
}
function tcInvalid(callable $fn, string $message): void {
    try { $fn(); } catch (InvalidArgumentException) { return; }
    throw new RuntimeException($message);
}

$authority = new SignalEmitterAuthority('test-attestation-secret', [
    'command-bus-service' => [
        'source' => 'titan-command-bus',
        'source_component' => 'command-runtime',
        'permissions' => ['signal.emit'],
        'event_type_patterns' => ['command.*'],
    ],
]);
$emitter = $authority->issue('command-bus-service');
$tenant = SignalContext::tenantHuman(7, 'usr_7', 'sess_7', 'titan-auth', $emitter);
$validator = new SignalContextValidator($authority);

$trusted = $validator->applyToInput([
    'event_type' => 'command.requested',
    'tenant_company_id' => 7,
    'source' => 'titan-command-bus',
    'source_component' => 'command-runtime',
    'payload' => [],
], $tenant);
tcAssert($trusted['source'] === 'titan-command-bus', 'Trusted emitter source must be applied.');
tcAssert($trusted['source_component'] === 'command-runtime', 'Trusted emitter component must be applied.');
tcAssert($trusted['emitter_id'] === 'command-bus-service', 'Trusted emitter service identity must be persisted.');
$trustedEnvelope = \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope::fromArray($trusted);
tcAssert($trustedEnvelope->emitterId === 'command-bus-service', 'Trusted envelope must carry emitter_id.');
tcAssert($trustedEnvelope->verifyChecksum(), 'Emitter identity must be covered by the envelope checksum.');

tcInvalid(fn () => $validator->applyToInput([
    'event_type' => 'command.requested',
    'tenant_company_id' => 7,
    'source' => 'titan-risk-engine',
], $tenant), 'Emitter source spoofing must fail.');

tcInvalid(fn () => $validator->applyToInput([
    'event_type' => 'risk.assessed',
    'tenant_company_id' => 7,
], $tenant), 'Emitter must not emit outside its event family.');

$readOnly = SignalContext::tenantHuman(7, 'usr_7', 'sess_7', 'titan-auth');
tcInvalid(fn () => $validator->applyToInput([
    'event_type' => 'command.requested',
    'tenant_company_id' => 7,
], $readOnly), 'Emission without trusted emitter identity must fail.');

tcInvalid(fn () => $validator->assertQueryAllowed('tenant', 7, null), 'Contextless tenant query must fail.');
$validator->assertQueryAllowed('tenant', 7, $readOnly);
tcInvalid(fn () => $validator->assertQueryAllowed('tenant', 8, $readOnly), 'Tenant context must not query another tenant.');

$systemRead = SignalContext::system('operator', 'system', ['signal.system.read', 'signal.tenant.read']);
$validator->assertQueryAllowed('system', null, $systemRead);
$validator->assertQueryAllowed('tenant', 7, $systemRead);


$forged = new SignalEmitterIdentity(
    'command-bus-service',
    'titan-command-bus',
    'command-runtime',
    ['signal.emit'],
    ['command.*'],
    str_repeat('0', 64),
);
$forgedContext = SignalContext::tenantHuman(7, 'usr_7', 'sess_7', 'titan-auth', $forged);
tcInvalid(fn () => $validator->applyToInput([
    'event_type' => 'command.requested',
    'tenant_company_id' => 7,
], $forgedContext), 'Forged emitter attestation must fail.');

foreach ([
    'SignalEmitterContract.php',
    'SignalQueryContract.php',
    'SignalCorrelationContract.php',
    'SignalPulseContract.php',
    'SignalAnomalyContract.php',
    'SignalLifecycleContract.php',
    'SignalManagerContract.php',
] as $contractFile) {
    $contract = file_get_contents(__DIR__ . '/../System/Contracts/' . $contractFile);
    tcAssert($contract !== false && ! str_contains($contract, '?SignalContext'), $contractFile . ' must not expose nullable SignalContext authorization.');
    tcAssert($contract !== false && ! str_contains($contract, '$context = null'), $contractFile . ' must not expose contextless authorization defaults.');
}

fwrite(STDOUT, "trusted-context-behavior: PASS\n");
