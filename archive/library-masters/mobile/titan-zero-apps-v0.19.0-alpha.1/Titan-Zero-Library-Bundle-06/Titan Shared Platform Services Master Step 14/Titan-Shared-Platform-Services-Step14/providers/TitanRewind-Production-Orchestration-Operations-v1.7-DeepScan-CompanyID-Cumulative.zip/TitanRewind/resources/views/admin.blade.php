@extends('panel.layout.app')
@section('title', 'Titan Rewind — Admin')

@section('content')
    <a href="#titan-rewind-content" class="sr-only focus:not-sr-only">{{ __('titan-rewind::rewind.accessibility_skip') }}</a>
    <main id="titan-rewind-content" role="main" class="container py-8 space-y-6">
        <div><h1 class="text-2xl font-semibold">Titan Rewind — Admin</h1><p class="text-sm opacity-70">Operational and forensic state for Rewind-owned data. No production mutation controls are exposed.</p></div>
        <section class="rounded border p-4 space-y-3">
            <div class="flex flex-wrap items-center gap-3"><h2 class="text-lg font-semibold">Runtime health</h2><span class="rounded border px-2 py-1 text-xs">{{ $health['status'] }}</span><span class="text-sm opacity-70">State: {{ $runtimeState }}</span></div>
            <div class="grid gap-2 md:grid-cols-4">@foreach($health['checks'] as $check => $state)<div class="rounded border p-2 text-sm"><strong>{{ $check }}</strong><div>{{ $state }}</div></div>@endforeach</div>
            <form method="POST" action="{{ route('dashboard.admin.titan.rewind.runtime.state') }}" class="flex flex-wrap gap-2 items-end">@csrf
                <label class="text-sm">Operational state<select name="state" class="block rounded border"><option>ACTIVE</option><option>DEGRADED</option><option>MAINTENANCE</option><option>DRAINING</option><option>DISABLED</option><option>UNAVAILABLE</option></select></label>
                <label class="text-sm flex-1 min-w-64">Reason<input name="reason" maxlength="2000" class="block w-full rounded border" placeholder="Operator reason / incident reference" aria-label="reason"></label>
                <button class="rounded border px-3 py-2" type="submit">Update state</button>
            </form>
            <div class="text-sm">Attention required: <strong>{{ $attentionDeadLetterCount }}</strong> dead letters · <strong>{{ $pendingSignalCount }}</strong> Signal deliveries · <strong>{{ $observabilityEventCount }}</strong> telemetry records</div>
        </section>
        <div class="grid gap-4 md:grid-cols-5">
            <div class="rounded border p-3"><strong>{{ $traceCount }}</strong><div>Traces</div></div>
            <div class="rounded border p-3"><strong>{{ $eventCount }}</strong><div>Events</div></div>
            <div class="rounded border p-3"><strong>{{ $caseCount }}</strong><div>Cases</div></div>
            <div class="rounded border p-3"><strong>{{ $openDriftCount }}</strong><div>Open drift findings</div></div>
            <div class="rounded border p-3"><strong>{{ $failedIntegrityCount }}</strong><div>Failed integrity checks</div></div>
            <div class="rounded border p-3"><strong>{{ $criticalTraceCount }}</strong><div>Critical traces</div></div>
            <div class="rounded border p-3"><strong>{{ $reviewTraceCount }}</strong><div>Review traces</div></div>
            <div class="rounded border p-3"><strong>{{ $queuedReplayCount }}</strong><div>Queued/running replays</div></div>
            <div class="rounded border p-3"><strong>{{ $failedReplayCount }}</strong><div>Failed replays</div></div>
            <div class="rounded border p-3"><strong>{{ $evidencePackageCount }}</strong><div>Evidence packages</div></div>
            <div class="rounded border p-3"><strong>{{ $evidenceReviewCount }}</strong><div>Evidence review required</div></div>
            <div class="rounded border p-3"><strong>{{ $recoveryPlanCount }}</strong><div>Recovery plans</div></div>
            <div class="rounded border p-3"><strong>{{ $pendingGovernanceCount }}</strong><div>Pending Governance</div></div>
            <div class="rounded border p-3"><strong>{{ $governanceReceiptCount }}</strong><div>Governance receipts</div></div>
            <div class="rounded border p-3"><strong>{{ $custodyEventCount }}</strong><div>Custody events</div></div>
            <div class="rounded border p-3"><strong>{{ $activeLegalHoldCount }}</strong><div>Active legal holds</div></div>
            <div class="rounded border p-3"><strong>{{ $partialSourceWatermarkCount }}</strong><div>Non-complete source watermarks</div></div>
            <div class="rounded border p-3"><strong>{{ $historicalArtifactCount }}</strong><div>Archived historical artifacts</div></div>
            <div class="rounded border p-3"><strong>{{ $activeSigningKeyCount }}/{{ $signingKeyCount }}</strong><div>Active / known signing keys</div></div>
            <div class="rounded border p-3"><strong>{{ $purgeReceiptCount }}</strong><div>Purge receipts</div></div>
        </div>

        <section class="rounded border p-4 space-y-3"><h2 class="text-lg font-semibold">Retention governance</h2><p class="text-sm opacity-70">Runs one bounded, resumable batch. Active trace/case/evidence/tenant legal holds block deletion and are recorded.</p>
            <form method="POST" action="{{ route('dashboard.admin.titan.rewind.retention.run') }}" class="flex flex-wrap items-end gap-2">@csrf
                <label class="text-sm">Tenant company ID<input type="number" min="1" required name="tenant_company_id" class="block rounded border" aria-label="tenant company id"></label>
                <label class="text-sm">Retention class<select name="retention_class" class="block rounded border"><option value="ephemeral">Ephemeral</option><option value="operational">Operational</option><option value="forensic">Forensic</option><option value="evidence">Evidence</option></select></label>
                <button type="submit" class="rounded border px-3 py-2">Run bounded batch</button>
            </form>
            <div class="grid gap-2 md:grid-cols-3"><div class="rounded border p-2 text-sm">Purge runs: <strong>{{ $purgeRunCount }}</strong></div><div class="rounded border p-2 text-sm">Receipts: <strong>{{ $purgeReceiptCount }}</strong></div><div class="rounded border p-2 text-sm">Schedule: daily, resumable</div></div>
        </section>

        <section><h2 class="text-lg font-semibold mb-3">Evidence signing keys</h2><div class="overflow-x-auto"><table class="w-full text-sm"><caption class=\"sr-only\">{{ __('titan-rewind::rewind.table_caption') }}</caption><thead><tr><th>Key</th><th>Status</th><th>Algorithm</th><th>Fingerprint</th><th>Last used</th></tr></thead><tbody>@forelse($signingKeys as $key)<tr class="border-t"><td>{{ $key->key_id }}</td><td>{{ $key->status }}</td><td>{{ $key->algorithm }}</td><td><code>{{ $key->public_key_fingerprint ? substr($key->public_key_fingerprint,0,16).'…' : 'unavailable' }}</code></td><td>{{ $key->last_used_at }}</td></tr>@empty<tr><td colspan="5" class="py-4">Signing key metadata is populated on signed-evidence use.</td></tr>@endforelse</tbody></table></div></section>

        <section><h2 class="text-lg font-semibold mb-3">Recent retention runs</h2><div class="overflow-x-auto"><table class="w-full text-sm"><caption class=\"sr-only\">{{ __('titan-rewind::rewind.table_caption') }}</caption><thead><tr><th>Tenant</th><th>Class</th><th>Status</th><th>Deleted</th><th>Held</th><th>Cursor</th></tr></thead><tbody>@forelse($recentPurgeRuns as $run)<tr class="border-t"><td>{{ $run->tenant_company_id }}</td><td>{{ $run->retention_class }}</td><td>{{ $run->status }}</td><td>{{ $run->rows_deleted }}</td><td>{{ $run->rows_held }}</td><td>{{ $run->cursor_table }}#{{ $run->cursor_id }}</td></tr>@empty<tr><td colspan="6" class="py-4">No retention runs yet.</td></tr>@endforelse</tbody></table></div></section>

        <section><h2 class="text-lg font-semibold mb-3">Recent integrity checks</h2><div class="overflow-x-auto"><table class="w-full text-sm"><caption class=\"sr-only\">{{ __('titan-rewind::rewind.table_caption') }}</caption><thead><tr><th>Tenant</th><th>Trace</th><th>Status</th><th>Events</th><th>Failures</th><th>Unsealed</th></tr></thead><tbody>@forelse($recentIntegrityChecks as $check)<tr class="border-t"><td class="text-center">{{ $check->tenant_company_id }}</td><td><code>{{ $check->trace_id }}</code></td><td class="text-center">{{ $check->status }}</td><td class="text-center">{{ $check->events_checked }}</td><td class="text-center">{{ $check->failures_count }}</td><td class="text-center">{{ $check->unsealed_count }}</td></tr>@empty<tr><td colspan="6" class="py-4">No integrity checks.</td></tr>@endforelse</tbody></table></div></section>

        <section><h2 class="text-lg font-semibold mb-3">Open forensic findings</h2><div class="overflow-x-auto"><table class="w-full text-sm"><caption class=\"sr-only\">{{ __('titan-rewind::rewind.table_caption') }}</caption><thead><tr><th>Tenant</th><th>Trace</th><th>Severity</th><th>Type</th><th>Summary</th></tr></thead><tbody>@forelse($recentDriftFindings as $finding)<tr class="border-t"><td class="text-center">{{ $finding->tenant_company_id }}</td><td><code>{{ $finding->trace_id }}</code></td><td class="text-center">{{ $finding->severity }}</td><td>{{ $finding->finding_type }}</td><td>{{ $finding->summary }}</td></tr>@empty<tr><td colspan="5" class="py-4">No open findings.</td></tr>@endforelse</tbody></table></div></section>


        <section><h2 class="text-lg font-semibold mb-3">Recent evidence packages</h2><div class="overflow-x-auto"><table class="w-full text-sm"><caption class=\"sr-only\">{{ __('titan-rewind::rewind.table_caption') }}</caption><thead><tr><th>Tenant</th><th>Trace</th><th>Type</th><th>Status</th><th>Hash</th></tr></thead><tbody>@forelse($recentEvidencePackages as $package)<tr class="border-t"><td class="text-center">{{ $package->tenant_company_id }}</td><td><code>{{ $package->trace_id }}</code></td><td class="text-center">{{ $package->package_type }}</td><td class="text-center">{{ $package->status }}</td><td><code>{{ substr($package->content_hash,0,16) }}…</code></td></tr>@empty<tr><td colspan="5" class="py-4">No evidence packages.</td></tr>@endforelse</tbody></table></div></section>

        <section><h2 class="text-lg font-semibold mb-3">Recent recovery plans</h2><div class="overflow-x-auto"><table class="w-full text-sm"><caption class=\"sr-only\">{{ __('titan-rewind::rewind.table_caption') }}</caption><thead><tr><th>Tenant</th><th>Trace</th><th>Risk</th><th>Status</th><th>Capability</th></tr></thead><tbody>@forelse($recentRecoveryPlans as $plan)<tr class="border-t"><td class="text-center">{{ $plan->tenant_company_id }}</td><td><code>{{ $plan->trace_id }}</code></td><td class="text-center">{{ $plan->risk_level }}</td><td class="text-center">{{ $plan->status }}</td><td>{{ $plan->proposed_capability ?: 'not defined' }}</td></tr>@empty<tr><td colspan="5" class="py-4">No recovery plans.</td></tr>@endforelse</tbody></table></div></section>

        <section><h2 class="text-lg font-semibold mb-3">Attention required / dead letters</h2><div class="overflow-x-auto"><table class="w-full text-sm"><caption class=\"sr-only\">{{ __('titan-rewind::rewind.table_caption') }}</caption><thead><tr><th>Queue</th><th>Type</th><th>Class</th><th>Attempts</th><th>Error</th><th>Action</th></tr></thead><tbody>@forelse($recentDeadLetters as $letter)<tr class="border-t"><td>{{ $letter->queue_name }}</td><td>{{ class_basename($letter->job_type) }}</td><td>{{ $letter->classification }}</td><td class="text-center">{{ $letter->attempts }}</td><td>{{ \Illuminate\Support\Str::limit($letter->error_message,120) }}</td><td>@if($letter->status === 'attention')<form method="POST" action="{{ route('dashboard.admin.titan.rewind.dead-letter.retry',$letter->dead_letter_uuid) }}">@csrf<button class="rounded border px-2 py-1">Retry</button></form>@else{{ $letter->status }}@endif</td></tr>@empty<tr><td colspan="6" class="py-4">No dead-letter items.</td></tr>@endforelse</tbody></table></div></section>

        <section><h2 class="text-lg font-semibold mb-3">Circuit breakers</h2><div class="grid gap-2 md:grid-cols-3">@forelse($circuitBreakers as $breaker)<div class="rounded border p-3"><strong>{{ $breaker['key'] }}</strong><div>{{ $breaker['state'] }} · failures {{ $breaker['failure_count'] }}</div></div>@empty<div>No external circuit state recorded yet.</div>@endforelse</div></section>

        <section><h2 class="text-lg font-semibold mb-3">Recent replay runs</h2><div class="overflow-x-auto"><table class="w-full text-sm"><caption class=\"sr-only\">{{ __('titan-rewind::rewind.table_caption') }}</caption><thead><tr><th>Tenant</th><th>Trace</th><th>Status</th><th>Created</th></tr></thead><tbody>@forelse($recentReplays as $run)<tr class="border-t"><td class="text-center">{{ $run->tenant_company_id }}</td><td><code>{{ $run->trace_id }}</code></td><td class="text-center">{{ $run->status }}</td><td class="text-center">{{ $run->created_at }}</td></tr>@empty<tr><td colspan="4" class="py-4">No replay runs.</td></tr>@endforelse</tbody></table></div></section>
    </main>
@endsection
