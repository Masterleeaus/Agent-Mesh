# Signal Events

Signals are observations, not authority or business truth by themselves. Consequential operations preserve trace, correlation, causation and root causation context where runtime support exists.
