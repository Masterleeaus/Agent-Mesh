<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ReadPlane;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceReadSourceContract;
use InvalidArgumentException;

final class GovernanceReadSourceRegistry
{
    /** @var array<string,GovernanceReadSourceContract> */
    private array $sources = [];

    public function register(GovernanceReadSourceContract $source): void
    {
        $key = trim($source->key());
        if ($key === '') throw new InvalidArgumentException('Governance read source key cannot be empty.');
        if (isset($this->sources[$key])) throw new InvalidArgumentException("Governance read source [{$key}] is already registered.");
        $this->sources[$key] = $source;
    }

    public function get(string $key): ?GovernanceReadSourceContract
    {
        return $this->sources[$key] ?? null;
    }

    /** @return array<string,GovernanceReadSourceContract> */
    public function all(): array
    {
        return $this->sources;
    }
}
