<?php

declare(strict_types=1);

function pcheck(bool $condition, string $message): void { if (!$condition) throw new RuntimeException($message); }
$root = dirname(__DIR__, 2);
$provider = file_get_contents($root . '/System/TitanAutonomyServiceProvider.php');
pcheck(str_contains($provider, 'loadRoutesFrom'), 'provider must load extension routes');
pcheck(str_contains($provider, 'loadViewsFrom'), 'provider must load extension views');
pcheck(str_contains($provider, 'HostContextBridgeContract::class'), 'provider must bind server-derived host context');
pcheck(str_contains($provider, 'CrmCompanyHostContextBridge'), 'provider must prefer verified CRM company context');
pcheck(str_contains($provider, 'ModelCouncilAssuranceBridge'), 'provider must bind verified ModelCouncil Assurance bridge when present');
pcheck(str_contains($provider, 'ModelCouncilTenantAssuranceBridge'), 'provider must bind tenant-explicit Assurance for scheduled reconciliation');
pcheck(str_contains($provider, 'UnavailableTenantAssuranceBridge'), 'scheduled Assurance must retain a fail-closed fallback');
pcheck(str_contains($provider, 'InteractionEngineLiveBridge'), 'provider must bind verified Interaction Engine bridge when present');
pcheck(str_contains($provider, 'InteractionCommandBusLiveBridge'), 'provider must bind verified Interaction CommandBus bridge when present');
pcheck(str_contains($provider, 'TitanAiRuntimeLiveBridge'), 'provider must bind verified TitanAI runtime bridge when present');
pcheck(str_contains($provider, 'UnavailableAssuranceBridge'), 'provider must retain fail-closed Assurance fallback');
pcheck(str_contains($provider, 'UnavailableCommandBusBridge'), 'provider must retain fail-closed CommandBus fallback');
pcheck(str_contains($provider, 'UnavailableInteractionEngineBridge'), 'provider must retain fail-closed Interaction fallback');
pcheck(str_contains($provider, 'UnavailableTitanAiRuntimeBridge'), 'provider must retain fail-closed TitanAI fallback');
pcheck(str_contains($provider, 'UnavailableRewindBridge'), 'provider must retain Rewind fallback until a verified API is available');
pcheck(str_contains($provider, 'DatabaseAutonomyQuery::class'), 'provider must bind tenant query repository');
pcheck(str_contains($provider, 'DatabaseControlPlaneAuditSink::class'), 'provider must bind control-plane audit sink');
pcheck(str_contains($provider, 'GovernedHostExecutionService::class'), 'provider must register governed live execution service');
pcheck(str_contains($provider, 'AssuranceAssessmentRequestService::class'), 'provider must register live Assurance assessment request service');
pcheck(str_contains($provider, 'ExecutionReconciliationService'), 'provider must register closed-loop outcome reconciliation');
pcheck(str_contains($provider, 'DatabaseOperationsQuery'), 'provider must bind tenant operations query');
pcheck(str_contains($provider, 'DatabaseOperationsReviewStore'), 'provider must bind operations review store');
pcheck(str_contains($provider, 'ExecutionReceiptReconcilerContract'), 'provider must expose due-only single receipt reconciler');
pcheck(str_contains($provider, 'ReconcileAutonomyExecutionsCommand::class'), 'provider must register reconciliation command');
pcheck(str_contains($provider, 'everyFifteenMinutes()'), 'provider must schedule reconciliation every fifteen minutes');
pcheck(str_contains($provider, 'onOneServer()') && str_contains($provider, 'withoutOverlapping()'), 'scheduled reconciliation must be single-server and overlap protected');

$migration = $root . '/database/migrations/2026_08_10_000200_add_titan_autonomy_control_plane.php';
pcheck(is_file($migration), 'control-plane audit migration required');
$migrationText = file_get_contents($migration);
pcheck(str_contains($migrationText, "Schema::create('titan_autonomy_control_events'"), 'control-plane audit table required');
pcheck(str_contains($migrationText, "'rewind_ref'"), 'control audit must persist Rewind correlation reference');

$executionMigration = $root . '/database/migrations/2026_08_11_000300_add_titan_autonomy_execution_reconciliation.php';
pcheck(is_file($executionMigration), 'execution reconciliation migration required');
$executionMigrationText = file_get_contents($executionMigration);
pcheck(str_contains($executionMigrationText, "Schema::create('titan_autonomy_execution_receipts'"), 'execution receipt table required');
pcheck(str_contains($executionMigrationText, "Schema::create('titan_autonomy_execution_feedback'"), 'execution feedback table required');
pcheck(str_contains($executionMigrationText, "['tenant_company_id','correlation_id']"), 'execution correlation IDs must be unique within a trusted tenant boundary');

$operationsMigration = $root . '/database/migrations/2026_08_11_000400_add_titan_autonomy_operations_reviews.php';
pcheck(is_file($operationsMigration), 'operations review migration required');
pcheck(str_contains(file_get_contents($operationsMigration), "Schema::create('titan_autonomy_execution_reviews'"), 'operations review table required');

$manifest = json_decode(file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
pcheck(($manifest['version'] ?? null) === '1.6.0', 'manifest version must be 1.6.0');
pcheck(in_array('titan_autonomy_control_events', $manifest['database']['owned_tables'] ?? [], true), 'manifest must own control audit table');
pcheck(in_array('titan_autonomy_execution_receipts', $manifest['database']['owned_tables'] ?? [], true), 'manifest must own execution receipt table');
pcheck(in_array('titan_autonomy_execution_feedback', $manifest['database']['owned_tables'] ?? [], true), 'manifest must own execution feedback table');
pcheck(in_array('titan_autonomy_execution_reviews', $manifest['database']['owned_tables'] ?? [], true), 'manifest must own operations review table');
pcheck(($manifest['schedules'][0]['key'] ?? null) === 'titan-autonomy-reconcile', 'manifest must declare reconciliation schedule');
pcheck(count($manifest['routes'] ?? []) >= 2, 'manifest must declare authenticated-user and admin route profiles');
$registries = array_column($manifest['contributions'] ?? [], 'registry');
pcheck(in_array('navigation.user', $registries, true), 'tenant navigation contribution required');
pcheck(in_array('navigation.admin', $registries, true), 'admin navigation contribution required');

$extension = json_decode(file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);
pcheck(($extension['version'] ?? null) === '1.6.0', 'extension version must be 1.6.0');
pcheck(is_file($root . '/CHANGELOG-v1.6.md'), 'v1.6 changelog required');

pcheck(str_contains(file_get_contents($root . '/config/autonomy.php'), "'policy_version' => 'titan-autonomy-1.6.0-2026-08-11'"), 'v1.6 policy version required');
pcheck(str_contains(file_get_contents($root . '/config/autonomy.php'), "'delegated_authority'"), 'delegated authority config required');
pcheck(str_contains(file_get_contents($root . '/config/autonomy.php'), "'outcome_reconciliation'"), 'closed-loop outcome reconciliation config required');

echo "OK: ProviderIntegrationSmokeTest\n";
