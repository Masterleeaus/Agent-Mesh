<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\DTO;

final readonly class ModelCapabilityProfile
{
    /** @param array<string,float|int|string|bool|null> $calibration */
    public function __construct(
        public string $provider,
        public string $model,
        public string $version,
        public array $calibration = [],
        public string $riskCeiling = 'low',
        public string $capability = 'general',
        public ?string $tenantCompanyId = null,
    ) {}

    public function isGlobal(): bool
    {
        return $this->tenantCompanyId === null;
    }
}
