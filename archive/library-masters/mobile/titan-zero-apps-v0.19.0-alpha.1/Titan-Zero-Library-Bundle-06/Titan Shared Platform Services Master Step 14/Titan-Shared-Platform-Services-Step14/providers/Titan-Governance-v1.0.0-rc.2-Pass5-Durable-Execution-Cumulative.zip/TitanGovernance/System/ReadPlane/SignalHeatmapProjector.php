<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ReadPlane;

final class SignalHeatmapProjector
{
    /** @return array<string,mixed> */
    public function project(array $sourceSnapshot): array
    {
        $cells = [];
        $recent = [];
        $signals = is_array($sourceSnapshot['signals'] ?? null) ? $sourceSnapshot['signals'] : [];

        foreach ($signals as $signal) {
            if (!is_array($signal)) continue;
            $component = trim((string)($signal['source_component'] ?? $signal['source_engine'] ?? 'unknown')) ?: 'unknown';
            $category = trim((string)($signal['category'] ?? 'general')) ?: 'general';
            $severity = $this->severity($signal['severity'] ?? null);
            $key = $component . '|' . $category;

            if (!isset($cells[$key])) {
                $cells[$key] = [
                    'source_component' => $component,
                    'category' => $category,
                    'total' => 0,
                    'info' => 0,
                    'warning' => 0,
                    'error' => 0,
                    'critical' => 0,
                    'pressure_weight' => 0,
                    'latest_observed_at' => null,
                ];
            }

            $cells[$key]['total']++;
            $cells[$key][$severity]++;
            $cells[$key]['pressure_weight'] += match ($severity) {
                'critical' => 8,
                'error' => 5,
                'warning' => 2,
                default => 1,
            };
            $observedAt = is_string($signal['observed_at'] ?? null) ? $signal['observed_at'] : null;
            if ($observedAt !== null && ($cells[$key]['latest_observed_at'] === null || $observedAt > $cells[$key]['latest_observed_at'])) {
                $cells[$key]['latest_observed_at'] = $observedAt;
            }
            $recent[] = $this->normalizeSignal($signal, $component, $category, $severity);
        }

        $cells = array_values($cells);
        usort($cells, static fn (array $a, array $b): int => ($b['pressure_weight'] <=> $a['pressure_weight']) ?: strcmp($a['source_component'], $b['source_component']));
        usort($recent, static fn (array $a, array $b): int => strcmp((string)($b['observed_at'] ?? ''), (string)($a['observed_at'] ?? '')));

        return [
            'schema_version' => '1.0',
            'source' => (string)($sourceSnapshot['source'] ?? 'titan-signal'),
            'source_status' => strtoupper((string)($sourceSnapshot['status'] ?? 'UNAVAILABLE')),
            'observed_at' => $sourceSnapshot['observed_at'] ?? null,
            'total_signals' => count($recent),
            'cells' => $cells,
            'recent' => array_slice($recent, 0, 100),
        ];
    }

    private function severity(mixed $value): string
    {
        $value = strtolower(trim((string)$value));
        return in_array($value, ['info','warning','error','critical'], true) ? $value : 'info';
    }

    /** @return array<string,mixed> */
    private function normalizeSignal(array $signal, string $component, string $category, string $severity): array
    {
        $row = [
            'event_type' => (string)($signal['event_type'] ?? $signal['type'] ?? 'unknown'),
            'source_component' => $component,
            'category' => $category,
            'severity' => $severity,
            'status' => $signal['status'] ?? null,
            'observed_at' => $signal['observed_at'] ?? null,
        ];
        foreach (['trace_id','correlation_id','causation_id','root_causation_id','reason_code','evidence_ref'] as $field) {
            if (array_key_exists($field, $signal)) $row[$field] = $signal[$field];
        }
        return $row;
    }
}
