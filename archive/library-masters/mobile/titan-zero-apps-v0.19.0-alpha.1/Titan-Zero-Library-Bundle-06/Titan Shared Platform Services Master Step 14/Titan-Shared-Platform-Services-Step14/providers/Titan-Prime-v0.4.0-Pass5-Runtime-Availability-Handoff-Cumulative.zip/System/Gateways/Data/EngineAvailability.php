<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Data;

use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;
use InvalidArgumentException;

final readonly class EngineAvailability
{
    /** @param array<string,mixed> $metadata */
    public function __construct(
        public EngineKey $engine,
        public bool $available,
        public string $code,
        public array $metadata = [],
    ) {
        if (trim($code) === '') {
            throw new InvalidArgumentException('Engine availability code must not be empty.');
        }
    }

    public function workforceState(): string
    {
        if ($this->available) {
            return 'available';
        }

        $code = strtolower($this->code);
        if (str_contains($code, 'policy') || str_contains($code, 'disabled')) {
            return 'policy_disabled';
        }
        if (str_contains($code, 'unbound') || str_contains($code, 'missing_provider')) {
            return 'missing_provider';
        }
        if (str_contains($code, 'blocked') || str_contains($code, 'denied')) {
            return 'blocked';
        }
        if (str_contains($code, 'degraded')) {
            return 'degraded';
        }

        return 'unavailable';
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'engine' => $this->engine->value,
            'available' => $this->available,
            'workforce_state' => $this->workforceState(),
            'code' => $this->code,
            'metadata' => $this->metadata,
        ];
    }
}
