<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Actions;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceActionDecisionStoreContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceCommandGatewayContract;
use Throwable;

final class GovernanceActionService
{
    private const RETRYABLE_REASONS = ['COMMAND_BUS_UNAVAILABLE','COMMAND_BUS_DISPATCH_FAILED','COMMAND_BUS_TIMEOUT','COMMAND_BUS_TRANSPORT_FAILED'];
    public function __construct(
        private readonly GovernanceActionDecisionStoreContract $decisions,
        private readonly GovernanceCommandGatewayContract $commandBus,
        private readonly GovernanceCommandReceiptValidator $receipts,
    ) {}

    /** @return array<string,mixed> */
    public function execute(GovernanceActionRequest $request): array
    {
        $claim=$this->decisions->claim($request);
        $claimStatus=(string)($claim['status']??'FAILED');
        if($claimStatus==='IDEMPOTENCY_CONFLICT') return $claim;
        $decisionId=trim((string)($claim['decision_id']??''));
        if($claimStatus==='REPLAYED') {
            $recorded=is_array($claim['result']??null)?$claim['result']:[];
            $reason=strtoupper(trim((string)($recorded['reason_code']??'')));
            $recordedStatus=strtoupper(trim((string)($claim['command_status']??'')));
            if($decisionId==='' || $recordedStatus!=='BLOCKED' || !in_array($reason,self::RETRYABLE_REASONS,true)) return [
                'status'=>'REPLAYED',
                'decision_id'=>$decisionId!==''?$decisionId:null,
                'original_status'=>$claim['command_status']??null,
                'result'=>$recorded,
            ];
        } elseif($claimStatus!=='CLAIMED' || $decisionId==='') {
            return ['status'=>'FAILED','reason_code'=>'GOVERNANCE_DECISION_CLAIM_FAILED'];
        }

        try{$response=$this->commandBus->dispatch($request->commandEnvelope($decisionId));}
        catch(Throwable){$response=['status'=>'UNAVAILABLE','reason_code'=>'COMMAND_BUS_DISPATCH_FAILED'];}
        $result=$this->receipts->normalize($response,$request,$decisionId);
        $this->decisions->finalize($decisionId,$result);
        return ['decision_id'=>$decisionId]+$result;
    }
}
