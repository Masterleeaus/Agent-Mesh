# Integration Contracts

Canonical Workforce integration is `resources/workforce/workforce-integration.json`. It is role-neutral and provider-versioned.
