<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalRegistryAuthorityContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryIdentity;
use InvalidArgumentException;

final class RegistryOwnershipPolicy
{
    public function __construct(private readonly SignalRegistryAuthorityContract $authority)
    {
    }

    public function assertEventRegistration(
        SignalRegistryIdentity $registrar,
        string $eventType,
        ?string $ownerSource,
        ?string $existingOwnerServiceId,
    ): void {
        $this->authority->assertTrusted($registrar);
        $override = $registrar->hasPermission('signal.registry.override');
        if (! $override && ! $registrar->hasPermission('signal.registry.event.manage')) {
            throw new InvalidArgumentException('Registry actor lacks signal.registry.event.manage.');
        }
        if (! $override && ! $registrar->allowsEventType($eventType)) {
            throw new InvalidArgumentException("Registry actor does not own event family {$eventType}.");
        }
        if (! $override && $ownerSource !== null && $ownerSource !== $registrar->ownerSource) {
            throw new InvalidArgumentException('Event definition owner_source does not match authenticated registry owner.');
        }
        if (! $override && $existingOwnerServiceId !== null
            && $existingOwnerServiceId !== $registrar->serviceId
            && ! str_starts_with($existingOwnerServiceId, 'legacy:')
            && ! str_starts_with($existingOwnerServiceId, 'package:')) {
            throw new InvalidArgumentException('Event type is owned by another registry service.');
        }
    }

    public function assertSubscriberRegistration(
        SignalRegistryIdentity $registrar,
        string $subscriberKey,
        ?string $existingOwnerServiceId,
    ): void {
        $this->authority->assertTrusted($registrar);
        $override = $registrar->hasPermission('signal.registry.override');
        if (! $override && ! $registrar->hasPermission('signal.registry.subscription.manage')) {
            throw new InvalidArgumentException('Registry actor lacks signal.registry.subscription.manage.');
        }
        if (! $override && ! $registrar->allowsSubscriberKey($subscriberKey)) {
            throw new InvalidArgumentException("Registry actor does not own subscriber key {$subscriberKey}.");
        }
        if (! $override && $existingOwnerServiceId !== null
            && $existingOwnerServiceId !== $registrar->serviceId
            && ! str_starts_with($existingOwnerServiceId, 'legacy:')
            && ! str_starts_with($existingOwnerServiceId, 'package:')) {
            throw new InvalidArgumentException('Subscriber key is owned by another registry service.');
        }
    }
}
