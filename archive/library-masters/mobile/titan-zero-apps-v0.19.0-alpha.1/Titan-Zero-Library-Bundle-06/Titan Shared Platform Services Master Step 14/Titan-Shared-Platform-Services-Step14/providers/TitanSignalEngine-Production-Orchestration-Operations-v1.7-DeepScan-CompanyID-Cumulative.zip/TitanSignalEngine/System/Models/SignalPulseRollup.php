<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalPulseRollup extends Model
{
    protected $table = 'titan_signal_pulse_rollups';
    protected $guarded = [];

    protected $casts = [
        'tenant_company_id' => 'integer',
        'tenant_key' => 'integer',
        'event_count' => 'integer',
        'severity_weight_sum' => 'integer',
        'max_severity_weight' => 'integer',
        'error_count' => 'integer',
        'critical_count' => 'integer',
        'command_count' => 'integer',
        'risk_count' => 'integer',
        'governance_count' => 'integer',
        'assurance_count' => 'integer',
        'autonomy_count' => 'integer',
        'subscription_failure_count' => 'integer',
        'bucket_start' => 'immutable_datetime',
        'first_event_at' => 'immutable_datetime',
        'last_event_at' => 'immutable_datetime',
    ];
}
