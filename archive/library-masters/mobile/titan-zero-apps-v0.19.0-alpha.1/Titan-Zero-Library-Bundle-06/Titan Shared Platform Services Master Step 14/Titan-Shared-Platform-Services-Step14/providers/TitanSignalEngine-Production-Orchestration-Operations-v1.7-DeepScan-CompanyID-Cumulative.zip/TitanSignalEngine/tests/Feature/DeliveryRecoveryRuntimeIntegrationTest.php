<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalSubscriberContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryLeasePolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryRedrivePolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalReceipt;
use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryCachePolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalSubscriptionDefinition;
use App\Extensions\TitanSignalEngine\System\Models\SignalDelivery;
use App\Extensions\TitanSignalEngine\System\Models\SignalDeliveryRedrive;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use App\Extensions\TitanSignalEngine\System\Services\RegistryOwnershipPolicy;
use App\Extensions\TitanSignalEngine\System\Services\SignalBackpressureMonitor;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;
use App\Extensions\TitanSignalEngine\System\Services\SignalDeliveryLeaseManager;
use App\Extensions\TitanSignalEngine\System\Services\SignalDeliveryRedriveService;
use App\Extensions\TitanSignalEngine\System\Services\SignalDeliveryScheduler;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority;
use App\Extensions\TitanSignalEngine\System\Services\SignalRegistryAuthority;
use App\Extensions\TitanSignalEngine\System\Services\SignalSubscriptionRegistry;
use App\Extensions\TitanSignalEngine\System\Services\SignalSubscriptionRegistryRevision;
use DateTimeImmutable;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Queue;
use InvalidArgumentException;
use Tests\TestCase;

final class RecoverySignalSubscriber implements SignalSubscriberContract
{
    public function handle(SignalEvent $event, SignalDeliveryContext $delivery): void
    {
    }
}

final class NoopRecoveryEmitter implements SignalEmitterContract
{
    public function emit(SignalEnvelope|array $signal, SignalContext $context): SignalReceipt
    {
        return new SignalReceipt('00000000-0000-7000-8000-000000000001', new DateTimeImmutable('now'), false, null);
    }
}

final class DeliveryRecoveryRuntimeIntegrationTest extends TestCase
{
    private SignalSubscriptionRegistry $registry;
    private SignalDeliveryRedriveService $redrive;
    private \App\Extensions\TitanSignalEngine\System\Data\SignalRegistryIdentity $registrar;

    protected function setUp(): void
    {
        parent::setUp();
        foreach (glob(dirname(__DIR__, 2) . '/database/migrations/*.php') ?: [] as $migrationFile) {
            (require $migrationFile)->up();
        }
        Cache::flush();
        Queue::fake();
        config()->set('titan-signal-engine.subscription_registry_cache_ttl_seconds', 1);
        config()->set('titan-signal-engine.backpressure_delivery_threshold', 100);
        config()->set('titan-signal-engine.backpressure_recent_dlq_window_seconds', 3600);

        $registryAuthority = new SignalRegistryAuthority('delivery-recovery-registry-secret', [
            'test-registry' => [
                'owner_source' => 'test-suite',
                'permissions' => ['signal.registry.subscription.manage', 'signal.registry.override'],
                'event_type_patterns' => ['*'],
                'subscriber_key_patterns' => ['test.*'],
            ],
        ]);
        $this->registrar = $registryAuthority->issue('test-registry');
        $ownership = new RegistryOwnershipPolicy($registryAuthority);
        $revision = new SignalSubscriptionRegistryRevision();
        $this->registry = new SignalSubscriptionRegistry($ownership, $revision, new SignalRegistryCachePolicy(1));
        $this->registry->register(SignalSubscriptionDefinition::fromArray([
            'subscriber_key' => 'test.recovery',
            'handler_class' => RecoverySignalSubscriber::class,
            'event_patterns' => ['test.signal'],
            'accepted_schema_versions' => [1],
            'scopes' => ['tenant'],
            'max_attempts' => 2,
            'backoff_seconds' => [0],
        ]), $this->registrar);

        $emitterAuthority = new SignalEmitterAuthority('delivery-recovery-emitter-secret', [
            'titan-signal-engine:delivery-recovery' => [
                'source' => 'titan-signal-engine',
                'source_component' => 'delivery-recovery',
                'permissions' => ['signal.emit'],
                'event_type_patterns' => ['signal.subscription.redriven'],
            ],
        ]);
        $leaseManager = new SignalDeliveryLeaseManager(new SignalDeliveryLeasePolicy(120));
        $scheduler = new SignalDeliveryScheduler($this->registry, $leaseManager);
        $this->redrive = new SignalDeliveryRedriveService(
            $scheduler,
            $this->registry,
            new NoopRecoveryEmitter(),
            $emitterAuthority,
            new SignalContextValidator($emitterAuthority),
            new SignalDeliveryRedrivePolicy(),
        );
    }

    public function test_dead_letter_redrive_is_audited_and_starts_new_retry_cycle(): void
    {
        $delivery = SignalDelivery::query()->create([
            'delivery_id' => '00000000-0000-7000-8000-000000000101',
            'event_id' => '00000000-0000-7000-8000-000000000201',
            'subscriber_key' => 'test.recovery',
            'scope' => 'tenant',
            'tenant_company_id' => 42,
            'event_type' => 'test.signal',
            'schema_version' => 1,
            'source' => 'test-suite',
            'source_component' => 'recovery-test',
            'queue' => 'titan-signal-engine',
            'status' => 'dead_letter',
            'attempt_count' => 2,
            'claim_version' => 2,
            'dead_lettered_at' => now()->subMinute(),
            'last_error_class' => 'RuntimeException',
            'last_error' => 'delivery_failed:test',
        ]);
        $context = SignalContext::tenantHuman(42, 'user:1', 'session-1', 'test', null, ['signal.delivery.redrive']);

        $receipt = $this->redrive->redrive((string) $delivery->delivery_id, 'Subscriber repaired', $context);
        $fresh = SignalDelivery::query()->where('delivery_id', $delivery->delivery_id)->firstOrFail();

        self::assertSame('queued', $receipt->status);
        self::assertSame(0, (int) $fresh->attempt_count);
        self::assertSame(1, (int) $fresh->redrive_count);
        self::assertNotNull($fresh->dead_letter_resolved_at);
        self::assertSame(1, SignalDeliveryRedrive::query()->where('delivery_id', $delivery->delivery_id)->count());

        $this->expectException(InvalidArgumentException::class);
        $this->redrive->redrive((string) $delivery->delivery_id, 'Duplicate redrive', $context);
    }

    public function test_historical_resolved_dead_letters_do_not_create_current_backpressure(): void
    {
        for ($i = 0; $i < 200; $i++) {
            SignalDelivery::query()->create([
                'delivery_id' => sprintf('00000000-0000-7000-8000-%012d', 1000 + $i),
                'event_id' => sprintf('00000000-0000-7000-8000-%012d', 2000 + $i),
                'subscriber_key' => 'test.recovery',
                'scope' => 'tenant',
                'tenant_company_id' => 42,
                'event_type' => 'test.signal',
                'schema_version' => 1,
                'source' => 'test-suite',
                'queue' => 'titan-signal-engine',
                'status' => 'delivered',
                'attempt_count' => 1,
                'claim_version' => 1,
                'dead_lettered_at' => now()->subDays(30),
                'dead_letter_resolved_at' => now()->subDays(29),
                'delivered_at' => now()->subDays(29),
            ]);
        }

        $snapshot = (new SignalBackpressureMonitor())->snapshot('tenant', 42, 'test.recovery', 'test-suite', null);
        self::assertFalse($snapshot['backpressured']);
        self::assertSame(0, $snapshot['recent_dead_letter']);
        self::assertSame(200, $snapshot['resolved_historical_dead_letter']);
    }

    public function test_registry_revision_invalidates_another_worker_cache(): void
    {
        $registryAuthority = new SignalRegistryAuthority('delivery-recovery-registry-secret', [
            'test-registry' => [
                'owner_source' => 'test-suite',
                'permissions' => ['signal.registry.subscription.manage', 'signal.registry.override'],
                'event_type_patterns' => ['*'],
                'subscriber_key_patterns' => ['test.*'],
            ],
        ]);
        $ownership = new RegistryOwnershipPolicy($registryAuthority);
        $worker = new SignalSubscriptionRegistry($ownership, new SignalSubscriptionRegistryRevision(), new SignalRegistryCachePolicy(30));
        self::assertSame(2, $worker->find('test.recovery')?->maxAttempts);

        $this->registry->evolve(SignalSubscriptionDefinition::fromArray([
            'subscriber_key' => 'test.recovery',
            'handler_class' => RecoverySignalSubscriber::class,
            'event_patterns' => ['test.signal'],
            'accepted_schema_versions' => [1],
            'scopes' => ['tenant'],
            'max_attempts' => 5,
            'backoff_seconds' => [0, 1, 5, 30],
        ]), $this->registrar);

        self::assertSame(5, $worker->find('test.recovery')?->maxAttempts);
    }
}
