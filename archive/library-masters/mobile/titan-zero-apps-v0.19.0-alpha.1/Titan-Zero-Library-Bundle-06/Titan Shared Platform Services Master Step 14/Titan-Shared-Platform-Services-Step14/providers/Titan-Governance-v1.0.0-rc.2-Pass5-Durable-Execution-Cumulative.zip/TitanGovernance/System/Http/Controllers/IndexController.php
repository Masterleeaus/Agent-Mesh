<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Http\Controllers;

use App\Extensions\TitanGovernance\System\Context\TenantCompanyResolver;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceManagerContract;
use App\Extensions\TitanGovernance\System\Host\TitanHostAuthorizationAdapter;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

final class IndexController
{
    public function __construct(private readonly GovernanceManagerContract $governance, private readonly TenantCompanyResolver $tenants, private readonly TitanHostAuthorizationAdapter $authorization) {}

    public function __invoke(Request $request): View
    {
        $user = $request->user();
        abort_unless($user && $this->authorization->allows($user, 'titan-governance.view', ['titan-governance.view']), 403);
        $tenantCompanyId = $this->tenants->resolve($user);
        $dashboard=$this->governance->dashboardSnapshot($tenantCompanyId);

        return view('titan-governance::index', [
            'health' => $this->governance->health(),
            'tenantCompanyId' => $tenantCompanyId,
            'trustMap' => $dashboard['trust_map'],
            'sourceHealth' => $dashboard['source_health'],
            'autonomyEvidence' => $dashboard['autonomy_evidence'],
            'signalIntelligence' => $dashboard['signal_intelligence'],
            'projection' => $dashboard['projection'],
            'escalationQueue' => $dashboard['escalation_queue'] ?? [],
            'recentDecisions' => $dashboard['recent_decisions'] ?? [],
            'controlCentre' => $dashboard['control_centre'] ?? [],
            'canAct' => $this->authorization->allows($user, 'titan-governance.escalations.act', ['titan-governance.escalations.act']),
            'canGrantException' => $this->authorization->allows($user, 'titan-governance.exceptions.grant', ['titan-governance.exceptions.grant']),
        ]);
    }
}
