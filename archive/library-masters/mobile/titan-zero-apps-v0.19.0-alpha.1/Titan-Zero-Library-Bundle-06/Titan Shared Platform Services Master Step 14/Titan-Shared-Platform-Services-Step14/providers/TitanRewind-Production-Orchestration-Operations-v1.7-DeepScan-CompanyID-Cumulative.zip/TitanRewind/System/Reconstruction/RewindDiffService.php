<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Reconstruction;

final class RewindDiffService
{
    private const HIGH_RISK_KEYS = [
        'total', 'amount', 'price', 'status', 'tenant_company_id', 'user_id', 'role_id',
        'permission', 'permissions', 'deleted_at', 'payment', 'payment_status', 'bank_account',
    ];

    public function compare(?array $before, ?array $after): array
    {
        $changes = [];
        $this->walk($before ?? [], $after ?? [], '', $changes);

        $risk = 'low';
        foreach ($changes as $change) {
            $path = strtolower((string) ($change['path'] ?? ''));
            foreach (self::HIGH_RISK_KEYS as $key) {
                if ($path === $key || str_ends_with($path, '.' . $key) || str_contains($path, 'payment')) {
                    $risk = 'high';
                    break 2;
                }
            }
        }
        if ($risk === 'low' && count($changes) > 5) {
            $risk = 'medium';
        }

        return [
            'changes' => $changes,
            'count' => count($changes),
            'risk' => $risk,
        ];
    }

    private function walk(array $before, array $after, string $prefix, array &$changes): void
    {
        $keys = array_values(array_unique(array_merge(array_keys($before), array_keys($after))));
        sort($keys);

        foreach ($keys as $key) {
            $path = $prefix === '' ? (string) $key : $prefix . '.' . (string) $key;
            $hasBefore = array_key_exists($key, $before);
            $hasAfter = array_key_exists($key, $after);

            if (!$hasBefore) {
                $changes[] = ['path' => $path, 'type' => 'added', 'before' => null, 'after' => $after[$key]];
                continue;
            }
            if (!$hasAfter) {
                $changes[] = ['path' => $path, 'type' => 'removed', 'before' => $before[$key], 'after' => null];
                continue;
            }

            if (is_array($before[$key]) && is_array($after[$key])) {
                if (array_is_list($before[$key]) || array_is_list($after[$key])) {
                    if ($before[$key] !== $after[$key]) {
                        $changes[] = ['path' => $path, 'type' => 'modified', 'before' => $before[$key], 'after' => $after[$key]];
                    }
                } else {
                    $this->walk($before[$key], $after[$key], $path, $changes);
                }
                continue;
            }

            if ($before[$key] !== $after[$key]) {
                $changes[] = ['path' => $path, 'type' => 'modified', 'before' => $before[$key], 'after' => $after[$key]];
            }
        }
    }
}
