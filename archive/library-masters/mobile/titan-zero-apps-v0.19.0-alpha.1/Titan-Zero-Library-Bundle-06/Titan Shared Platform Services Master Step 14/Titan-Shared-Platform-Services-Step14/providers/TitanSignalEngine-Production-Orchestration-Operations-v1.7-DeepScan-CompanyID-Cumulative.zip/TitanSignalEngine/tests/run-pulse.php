<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/PulseWindow.php';
require __DIR__ . '/../System/Data/PulsePercentiles.php';
require __DIR__ . '/../System/Data/PulseAttentionScore.php';
require __DIR__ . '/../System/Services/PulseAttentionScorer.php';

use App\Extensions\TitanSignalEngine\System\Data\PulseWindow;
use App\Extensions\TitanSignalEngine\System\Data\PulsePercentiles;
use App\Extensions\TitanSignalEngine\System\Services\PulseAttentionScorer;

function pulseAssert(bool $condition, string $message): void {
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

$now = new DateTimeImmutable('2026-08-15T19:58:47+10:00');
$five = PulseWindow::fromKey('5m', $now);
pulseAssert($five->granularity === 'minute', '5m must read minute rollups.');
pulseAssert($five->seconds === 300, '5m must equal 300 seconds.');
pulseAssert($five->start->format(DATE_ATOM) === '2026-08-15T19:53:47+10:00', '5m start must be exact rolling window.');

$hour = PulseWindow::fromKey('1h', $now);
pulseAssert($hour->granularity === 'minute', '1h must read minute rollups.');
pulseAssert($hour->seconds === 3600, '1h must equal 3600 seconds.');

$day = PulseWindow::fromKey('24h', $now);
pulseAssert($day->granularity === 'hour', '24h must read hour rollups.');

$week = PulseWindow::fromKey('7d', $now);
pulseAssert($week->granularity === 'day', '7d must read day rollups.');

$stats = PulsePercentiles::summarize([10, 20, 30, 40, 50, 60, 70, 80, 90, 100]);
pulseAssert($stats['count'] === 10, 'Percentile sample count must be retained.');
pulseAssert($stats['p50'] === 50.0, 'P50 must use deterministic nearest-rank percentile.');
pulseAssert($stats['p95'] === 100.0, 'P95 nearest-rank must select the 10th sample for n=10.');
pulseAssert($stats['p99'] === 100.0, 'P99 nearest-rank must select the 10th sample for n=10.');

$score = (new PulseAttentionScorer())->score([
    'critical_count' => 2,
    'error_count' => 5,
    'dead_letter_count' => 1,
    'stalled_trace_count' => 2,
    'missing_receipt_count' => 1,
    'subscription_failure_count' => 1,
]);
pulseAssert($score->score === 100, 'Attention score must cap at 100.');
pulseAssert($score->band === 'critical', 'High operational pressure must be critical.');
pulseAssert(in_array('dead_letters', $score->reasons, true), 'Dead letters must contribute an explicit reason code.');
pulseAssert(in_array('missing_receipts', $score->reasons, true), 'Missing receipts must contribute an explicit reason code.');

$quiet = (new PulseAttentionScorer())->score([
    'critical_count' => 0,
    'error_count' => 0,
    'dead_letter_count' => 0,
    'stalled_trace_count' => 0,
    'missing_receipt_count' => 0,
    'subscription_failure_count' => 0,
]);
pulseAssert($quiet->score === 0 && $quiet->band === 'low', 'Quiet systems must score low attention pressure.');

fwrite(STDOUT, "pulse-behavior: PASS\n");
