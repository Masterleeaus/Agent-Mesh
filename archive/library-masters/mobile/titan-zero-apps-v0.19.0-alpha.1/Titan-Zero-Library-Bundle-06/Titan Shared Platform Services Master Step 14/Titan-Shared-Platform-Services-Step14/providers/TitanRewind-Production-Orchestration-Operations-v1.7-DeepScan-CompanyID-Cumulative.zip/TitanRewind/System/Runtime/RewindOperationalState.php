<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Runtime;

use InvalidArgumentException;

final readonly class RewindOperationalState
{
    private const ALLOWED = ['ACTIVE','DEGRADED','MAINTENANCE','DRAINING','DISABLED','UNAVAILABLE','UNINSTALLING'];

    private function __construct(private string $state) {}

    public static function from(string $state): self
    {
        $state = strtoupper(trim($state));
        if (!in_array($state,self::ALLOWED,true)) throw new InvalidArgumentException('Unsupported Titan Rewind operational state.');
        return new self($state);
    }

    public function value(): string { return $this->state; }
    public function acceptsNewWork(): bool { return in_array($this->state,['ACTIVE','DEGRADED'],true); }
    public function allowsInFlightCompletion(): bool { return !in_array($this->state,['DISABLED','UNAVAILABLE','UNINSTALLING'],true); }
    public function healthStatus(): string
    {
        return match ($this->state) {
            'ACTIVE' => 'HEALTHY', 'DEGRADED' => 'DEGRADED', 'MAINTENANCE' => 'MAINTENANCE', 'DRAINING' => 'DRAINING',
            'DISABLED','UNINSTALLING' => 'DISABLED', default => 'UNAVAILABLE',
        };
    }
}
