<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Retention;
use InvalidArgumentException;
final class RewindRetentionPolicy
{
    public function __construct(private array $classes){}
    public function days(string $class): int { if($class==='preserve') return PHP_INT_MAX; $days=(int)($this->classes[$class]??0); if($days<1) throw new InvalidArgumentException("Unknown Rewind retention class: {$class}"); return $days; }
    public function classFor(string $table): string
    {
        return match($table){
            'titan_rewind_replay_runs','titan_rewind_observability_events','titan_rewind_signal_outbox','titan_rewind_dead_letters'=>'ephemeral',
            'titan_rewind_integrity_checks','titan_rewind_drift_findings','titan_rewind_timeline_entries'=>'operational',
            'titan_rewind_snapshots','titan_rewind_dependencies'=>'forensic',
            'titan_rewind_historical_artifacts'=>'evidence',
            'titan_rewind_evidence_packages'=>'evidence',
            'titan_rewind_governance_receipts','titan_rewind_recovery_plans','titan_rewind_recovery_steps'=>'preserve',
            'titan_rewind_custody_events','titan_rewind_legal_holds','titan_rewind_signing_keys','titan_rewind_purge_runs','titan_rewind_purge_receipts'=>'preserve',
            default=>'preserve',
        };
    }
    public function cutoff(string $class,?\DateTimeImmutable $now=null): ?\DateTimeImmutable { if($class==='preserve') return null; $now??=new \DateTimeImmutable('now',new \DateTimeZone('UTC')); return $now->sub(new \DateInterval('P'.$this->days($class).'D')); }
}
