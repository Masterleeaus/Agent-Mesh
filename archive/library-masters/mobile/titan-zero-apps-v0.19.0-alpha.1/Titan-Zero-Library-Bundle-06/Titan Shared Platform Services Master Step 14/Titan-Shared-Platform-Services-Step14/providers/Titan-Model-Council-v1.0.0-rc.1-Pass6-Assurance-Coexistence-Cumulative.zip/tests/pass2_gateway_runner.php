<?php

declare(strict_types=1);

$contract = file_get_contents(__DIR__ . '/../System/Contracts/CouncilGatewayContract.php');
$gateway = file_get_contents(__DIR__ . '/../System/Services/CouncilGateway.php');
foreach (['function health', 'function strategies', 'function supportsStrategy'] as $needle) {
    if (! str_contains($contract, $needle)) {
        fwrite(STDERR, "FAIL: CouncilGatewayContract missing {$needle}\n");
        exit(1);
    }
}
foreach (['risk-integrated', 'parallel_consensus', 'LegacyCouncilAdapter'] as $needle) {
    if (! str_contains($gateway, $needle)) {
        fwrite(STDERR, "FAIL: CouncilGateway missing active compatibility marker {$needle}\n");
        exit(1);
    }
}
echo "pass2 gateway checks passed\n";
