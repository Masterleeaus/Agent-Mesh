<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class CrmExportService
{
    private const TYPES = ['companies', 'contacts', 'leads', 'deals', 'activities'];

    /** Internal persistence/governance fields are intentionally excluded from portable exports. */
    private const INTERNAL_FIELDS = [
        'id',
        'company_id',
        'user_id',
        'created_by_user_id',
        'updated_by_user_id',
        'deleted_by_user_id',
        'entity_version',
        'lock_version',
    ];

    public function __construct(private ConnectionInterface $db) {}

    public function export(int $userId, string $type): array
    {
        if (!in_array($type, self::TYPES, true)) {
            throw new InvalidArgumentException('Unsupported CRM export type.');
        }

        $tenant = CrmCompanyScope::companyId($userId);
        $table = (string) config('crm.tables.'.$type);
        $rows = $this->db->table($table)
            ->where('company_id', $tenant)
            ->when($type !== 'activities', fn ($q) => $q->whereNull('deleted_at'))
            ->orderBy('id')
            ->get()
            ->map(fn ($row) => $this->sanitizeExportRow((array) $row))
            ->all();

        $dataJson = json_encode($rows, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        $sha256 = hash('sha256', $dataJson);
        $exportId = (string) Str::ulid();
        $manifest = [
            'schema' => 'crm.export.v2',
            'export_id' => $exportId,
            'resource_type' => $type,
            'record_count' => count($rows),
            'sha256' => $sha256,
            'exported_at' => now()->toIso8601String(),
        ];

        $this->db->table('crm_export_audit_journal')->insert([
            'public_id' => $exportId,
            'company_id' => $tenant,
            'user_id' => CrmCompanyScope::actorUserId($userId),
            'resource_type' => $type,
            'record_count' => count($rows),
            'sha256' => $sha256,
            'export_manifest' => json_encode($manifest, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'exported_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return ['export_manifest' => $manifest, 'sha256' => $sha256, 'data' => $rows];
    }

    private function sanitizeExportRow(array $row): array
    {
        foreach (self::INTERNAL_FIELDS as $field) {
            unset($row[$field]);
        }
        return $row;
    }
}
