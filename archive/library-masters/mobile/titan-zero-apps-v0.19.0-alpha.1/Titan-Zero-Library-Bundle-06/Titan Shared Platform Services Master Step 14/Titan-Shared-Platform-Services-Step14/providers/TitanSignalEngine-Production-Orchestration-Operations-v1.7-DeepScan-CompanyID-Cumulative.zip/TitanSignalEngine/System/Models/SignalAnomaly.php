<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalAnomaly extends Model
{
    protected $table = 'titan_signal_anomalies';
    protected $guarded = [];
    protected $casts = [
        'tenant_company_id' => 'integer',
        'tenant_key' => 'integer',
        'score' => 'integer',
        'confidence' => 'float',
        'evidence' => 'array',
        'occurrence_count' => 'integer',
        'decision_version' => 'integer',
        'first_detected_at' => 'immutable_datetime',
        'last_detected_at' => 'immutable_datetime',
        'acknowledged_at' => 'immutable_datetime',
        'suppressed_until' => 'immutable_datetime',
        'resolved_at' => 'immutable_datetime',
        'reopened_at' => 'immutable_datetime',
        'last_decision_at' => 'immutable_datetime',
    ];
}
