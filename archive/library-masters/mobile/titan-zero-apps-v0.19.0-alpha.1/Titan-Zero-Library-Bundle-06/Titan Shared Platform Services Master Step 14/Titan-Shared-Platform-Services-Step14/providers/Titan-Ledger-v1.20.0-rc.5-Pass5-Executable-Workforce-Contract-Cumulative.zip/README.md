# Titan Ledger 1.20.0-rc.5

Titan Ledger is Titan Zero's authoritative accounting boundary. New-plan Step 5/12 adds advanced deterministic reconciliation automation over immutable bank-statement evidence: one-to-many and many-to-one matching, transfer recognition, bank fee/interest adjustment journals, economic duplicate-statement protection and append-only reconciliation group evidence while preserving Command Bus-only mutation and canonical `company_id` tenancy.

## New Plan Step 3 — Advanced GST, BAS and Tax Adjustments

- `extension.json.dependencies` is now an Installer 1.7.6-compatible list of objects with explicit `slug` and `version` fields.
- Supported GST reporting methods are `simpler_bas` and `full_bas`, accrual/AUD only.
- Full-BAS evidence covers G1, G2, G3, G10, G11, 1A and 1B; classification completeness is fail-closed.
- Immutable GST adjustments support bad debts, recoveries, mixed acquisitions, input-taxed corrections and BAS classifications.
- Financial-impact GST adjustments require a posted Ledger journal reference; classification-only adjustments do not create accounting entries.
- Adjustment review is append-only (`pending`, `approved`, `rejected`); pending adjustments block BAS finalization.
- Finalized tax snapshots remain immutable; amendments create superseding prepared versions through governed commands.
- Titan Ledger prepares tax evidence only and has no ATO/SBR lodgement authority.

## Pass 7 guarantees

- `company_id` remains the canonical tenant boundary.
- Titan Command Bus remains the only steady-state mutation entry point.
- Before Ledger opens a domain receipt or changes financial state, Titan Risk and Titan Assurance must return accepted decisions through Ledger-facing gateways.
- Risk decisions require a durable reference and canonical LOW/MEDIUM/HIGH/CRITICAL class; optional score/ruleset version are retained.
- Assurance decisions require an accepted durable reference and bounded class; optional score/ruleset version are retained.
- Missing, malformed or denied Risk/Assurance decisions fail closed.
- Ledger does not reproduce Risk classification or Assurance reasoning. It sends only bounded structural accounting evidence and consumes external decisions.
- Journal memo, arbitrary metadata and raw financial command payload text are excluded from the governance evidence envelope.
- Risk and Assurance references are persisted immutably on Ledger command receipts and copied into the corresponding Signal envelope/outbox evidence.
- Titan Rewind receives a Ledger-owned, read-only source contribution rather than importing Ledger persistence internals.
- Rewind records are company + trace scoped, support historical `asOf`, expose watermarks/completeness and canonical SHA-256 source-record hashes, and omit raw result/Signal payloads and hidden reasoning.

## Host governance bindings

Ledger-facing Risk bindings, in priority order:

- `titan.risk.gateway.titan-ledger`
- `titan.risk.gateway`

Ledger-facing Assurance bindings:

- `titan.assurance.gateway.titan-ledger`
- `titan.assurance.gateway`

The Risk gateway must expose `evaluate(array $evidence)`. Assurance should expose `verify(array $evidence)`; `evaluate` is accepted as a compatibility shape. These are thin host ports, not embedded engine implementations.

## Rewind contribution

Binding: `titan.ledger.rewind-source`

Source key: `titan-ledger.rewind-source`

Machine-readable declaration: `resources/rewind/source-manifest.json`.

The source exposes `sourceKey()`, `watermark(company_id, trace_id)` and `records(company_id, trace_id, asOf)` and is strictly authority-neutral/read-only.

## Navigation

### User — Titan Ledger

1. Overview
2. Bookkeeping
3. Chart of Accounts
4. Journals
5. Financial Years
6. Accounting Periods
7. Command Receipts
8. Financial Events
9. Governance Evidence
10. Invoice Accounting
11. Payment Settlements
12. Receivables
13. Payables
14. Bank Reconciliation
15. GST and BAS
16. Financial Reports
17. Cashflow and Forecasts
18. Diagnostics

### Super Admin — Titan Ledger

1. Overview
2. Command Authority
3. Signal Fabric
4. Risk and Assurance
5. Rewind Integration
6. CRM Invoice Adapter
7. Titan Pay Adapter
8. AR and Collections
9. AP and Spend Adapter
10. Banking and Reconciliation
11. GST Tax Ledger
12. Financial Reporting
13. Forecasting and Profitability
14. Menu Diagnostics
15. System Diagnostics

## Cumulative foundation

Passes 1-6 remain intact: canonical tenancy, GST-safe bookkeeping, canonical Chart of Accounts, immutable double-entry journals, fiscal periods/locks, Command Bus-only mutation receipts, and durable financial Signal events.

## Certification boundary

Standalone verification proves source contracts, pure governance/Rewind behavior, syntax, JSON validity, package integrity and fresh-ZIP extraction. A live Titan/MagicAI host is still required to prove real Risk/Assurance bridge resolution, MySQL migrations/triggers, Rewind source registration, Command Bus execution and UI rendering.

## Pass 8 — CRM Invoice Accounting Adapter
CRM remains the customer-facing invoice authority. Titan Ledger consumes bounded versioned invoice facts through `titan.ledger.crm-invoice-accounting.v1`; the port submits governed Command Bus commands and never writes Ledger tables directly. Invoice and credit-note facts are persisted only as immutable accounting-posting evidence linked to posted double-entry journals. Direct reads from CRM invoice/payment/refund tables were removed from Ledger reporting.


## Pass 9 — Titan Pay / ZeroPay Settlement Adapter

Canonical binding: `titan.ledger.payment-settlement.v1`. Legacy compatibility alias: `titan.ledger.zeropay-settlement.v1`.

Titan Pay remains settlement authority; Titan Ledger remains the only accounting-posting authority. Payment and refund facts enter through Command Bus and retain Risk, Assurance, receipt, Signal and Rewind lineage.

Supported settlement rails are PayID, bank transfer, cash, Stripe and PayPal. PayID, bank transfer and cash facts are required to be fee-free. All monetary facts use integer minor units.

Payment accounting:

- DR Business Bank Account for net cash.
- DR Bank and Merchant Fees for provider fee where applicable.
- CR Accounts Receivable up to the invoice's current outstanding balance.
- CR Customer Credits and Overpayments for excess receipts.

Refund accounting:

- DR Customer Credits and Overpayments first when an unrefunded customer credit exists.
- DR Accounts Receivable for the allocated portion of the refund.
- DR Bank and Merchant Fees for any new refund fee.
- CR Business Bank Account for cash refunded plus refund fee.

Settlement evidence is immutable in `titan_ledger_payment_settlements`. Ledger never reads `zeropay_*`, `crm_payments` or `crm_payment_allocations` tables. Cash reporting reads only Ledger-owned settlement evidence, so invoice revenue is not double-counted when paid.

## Pass 10 — Accounts Receivable and Collections

Pass 10 adds `titan_ledger_receivables` as a company-scoped projection derived only from Ledger-owned CRM invoice posting and Titan Pay settlement evidence. It tracks invoice total, credits, allocated payments, allocation refunds, outstanding AR, receivable credit balances, customer overpayment credit, due date, aging bucket and collection state.

CRM may supply an optional `due_at` in the invoice accounting fact. Legacy invoices without a due date remain `unknown_due_date`; Ledger does not invent overdue status. Aging buckets are `current`, `1_30`, `31_60`, `61_90`, `91_plus`, `unknown_due_date` and `settled`.

Governed collection commands are `ledger.receivable.collection.transition` and `ledger.receivable.follow_up.record`. They append immutable rows to `titan_ledger_collection_events`. Follow-up records store bounded channel/outcome/reason facts and never send messages; outbound communications remain an external authority.

The read model is refreshed transactionally after invoice, credit-note, payment and refund posting, and refreshed again on reads so time-based aging stays current. Credit notes issued after payment can create a separate receivable credit balance rather than being rejected or counted as new revenue.


## Pass 11 — Accounts Payable and Spend Adapter

Pass 11 adds the external spend-accounting boundary without absorbing Budgeting or purchasing authority into Titan Ledger. The public binding is `titan.ledger.spend-accounting.v1`; payables projections are available through `titan.ledger.payables.v1`.

Governed source facts now support supplier bills, supplier credits, supplier payments, and immediate spend actuals. Supplier bills debit approved Ledger asset/cost/expense accounts plus GST Receivable and credit Accounts Payable. Credits create linked immutable corrections. Payments reduce Accounts Payable and move any excess into the protected Supplier Deposits and Prepayments asset. Cash uses Cash on Hand, card funding uses Credit Card Payable, and other supported outgoing rails use the Business Bank Account.

`titan_ledger_spend_postings` is immutable posting evidence. `titan_ledger_payables` is a company-scoped derived read model with outstanding balances, supplier credits/prepayments, due dates, aging and financial state. No runtime query reads Budgeting, purchasing, legacy Accountings or supplier-invoice tables outside Ledger.

The governed path remains: external spend authority → Titan Command Bus → Risk → Assurance → Titan Ledger → immutable journal/evidence → Signal + Rewind.

Next: Pass 12 — Banking and Reconciliation Engine.

## Pass 12 — Banking and Reconciliation Engine

Pass 12 introduces the public `titan.ledger.bank-reconciliation.v1` boundary. External bank-feed/connectivity systems remain statement/fact authorities; Titan Ledger owns reconciliation evidence and balance proof. Importing a statement never creates a financial journal.

Bank statement facts use signed integer minor units, must reconcile `opening + movements = closing`, and persist only bounded reference hashes rather than raw bank narrative. Reconciliation candidates are existing posted Ledger bank-account journal lines. Automatic suggestions require exact signed amount and bounded date proximity; exact reference hashes strengthen ranking. Ties remain ambiguous instead of being auto-selected.

A reconciliation session can close only when every statement transaction has an active confirmed match and the Ledger bank-account balance immediately before the statement period equals the statement opening balance while the Ledger balance through period end equals the statement closing balance.


## Pass 13 — Australian GST and Tax Ledger

Pass 13 introduces the read-only `titan.ledger.gst-tax-ledger.v1` boundary and three governed evidence commands: prepare, finalize and supersede GST snapshots. The tax ledger calculates Simpler BAS G1 total sales, 1A GST on sales and 1B GST on purchases from immutable CRM invoice and spend-posting evidence. It is AUD-only and accrual-basis in this pass; non-AUD evidence fails closed and cash-basis finalization is intentionally unsupported until payment-level GST allocation exists. Negative BAS labels are retained internally but marked review-required rather than falsely declared lodgement-ready. Finalized snapshots are immutable; later accounting corrections require a new superseding version. Titan Ledger does not call, submit to, or act as an ATO lodgement authority.

Next: Pass 14 — Financial Statements and Management Reporting.


## Pass 14 — Financial Statements and Management Reporting

Pass 14 introduces `titan.ledger.financial-reporting.v1`, a read-only company-scoped reporting port derived exclusively from posted `titan_ledger_journals`, `titan_ledger_journal_lines` and canonical Chart of Accounts classification. It provides Trial Balance, Profit and Loss, Balance Sheet, retained-earnings roll-forward, previous-period/prior-year comparisons, bounded account drill-down and a management pack with revenue/profit variances.

Balance Sheet reports expose unclosed earnings explicitly rather than requiring a destructive year-end close merely to balance. Prepared report snapshots include journal + account-definition source fingerprints, deterministic report hashes, completeness/balance flags and immutable supersession lineage. Finalization is governed through Command Bus/Risk/Assurance and currently requires complete AUD evidence; foreign-currency journals are visible in per-currency reads but prevent a snapshot from being falsely certified as consolidated. Legacy simple-bookkeeping rows are intentionally excluded from canonical financial statements until represented by posted double-entry journals.

Next: Pass 15 — Cashflow, Forecasting and Profitability.


## Pass 15 — Cashflow, Forecasting and Profitability

Pass 15 introduces the read-only advisory binding `titan.ledger.cashflow-forecasting.v1`. Actual cashflow is derived from posted journal lines on canonical cash accounts. Forward cash forecasts use the current Ledger cash balance plus company-scoped receivables/payables projections and nominal due dates; they are deliberately not probability weighted. Forecast confidence means evidence coverage only. Unknown or out-of-horizon working-capital evidence is exposed rather than guessed.

Profitability uses posted journal/account classifications only and reports revenue, direct cost, gross profit/margin, operating expense and net profit/margin, with account-type/subtype category detail. Customer/job profitability is exposed only as a foundation contract until an authoritative external dimension mapping exists; Ledger does not invent customer/job attribution from unrelated document IDs.

Forecast snapshots are versioned evidence in `titan_ledger_forecast_snapshots`. Preparation/finalization/supersession are governed through Command Bus/Risk/Assurance, but the snapshot has no accounting mutation authority. Finalized snapshots are immutable and source-fingerprint drift requires a new version. Forecast-vs-actual variance compares a frozen cash schedule to later posted cash movements without altering either history.

Next: Pass 16 — Titan Finance Intelligence and Production Certification.

## Production certification
Titan Ledger v1.16.0-rc.1 adds a live-host certification gate. Run `php artisan titan-ledger:production-certify --repair --json=storage/app/titan-ledger-production-certification.json` after installation. The repair mode replays idempotent trigger-bearing migration `up()` logic, marks schema ownership as retain-by-default, and then verifies 41 MySQL guards plus tenant, route, Command Bus, Risk, Assurance, Signal-outbox and Rewind readiness. Financial evidence is intentionally retained on rollback/uninstall.


## New plan Step 2/12 — Fiscal Year Close & Retained Earnings Automation

Canonical read-only close boundary: `titan.ledger.financial-year-close.v1`. Consequential close mutations remain Command Bus-only through `ledger.financial_year.close.prepare`, `ledger.financial_year.close`, and `ledger.financial_year.reopen`.

A close may be prepared only when every accounting period is soft-locked, no draft/validated journals remain, Trial Balance is balanced, no overlapping bank reconciliation is open, no prepared GST snapshot remains, the year is AUD-normalized, and the canonical source fingerprint is stable. The close calculator zeros temporary revenue/cost/expense accounts only and transfers the exact net profit/loss to the protected Retained Earnings account.

Closing posts a new immutable `year_end_close` journal and then closes the financial year. Reopening never deletes or edits that journal: it appends reopen evidence and posts a new linked `year_end_reopen` journal that reverses the close mechanics. Historical Profit & Loss excludes `year_end_close` and `year_end_reopen`, while Balance Sheet/retained-earnings reporting includes their real posted effects without double-counting current-period earnings.

Evidence is retained in `titan_ledger_financial_year_closes` and `titan_ledger_financial_year_close_events`. Closed close evidence is immutable. Later re-close cycles create a higher version and explicit supersession lineage. Production trigger certification now covers 45 MySQL controls.


## New plan Step 4/12 — Multi-Bank, Credit Card & Clearing Accounts

Step 4 introduces the read-only `titan.ledger.multi-account-banking.v1` boundary and a Ledger-owned financial-account registry over existing Chart of Accounts records. Registered account kinds are `bank`, `credit_card`, and `clearing`; registration is immutable and company-scoped. No bank credential, payment initiation, card authorization or provider-secret authority is added to Ledger.

Governed mutations are `ledger.banking.account.register`, `ledger.banking.transfer.post`, `ledger.banking.clearing.settle`, and `ledger.banking.credit_card.payment.post`. Internal transfers post destination-bank DR / source-bank CR and only real fees affect company cashflow. Credit-card payments post card-liability DR / bank CR. Stripe/PayPal settlement facts may target a registered payment-clearing account; those captures do not become bank cash until a separately governed clearing payout posts clearing CR / bank DR. Clearing payouts fail closed when the requested payout exceeds the posted clearing balance.

Bank reconciliation now accepts registered credit-card liability accounts using signed Ledger debit-minus-credit balance convention. Actual cashflow is multi-bank aware, excludes clearing balances from cash, and nets each journal before classifying inflow/outflow so transfers between cash accounts do not inflate gross cash movement. Titan Pay refunds must use the original payment funds account. Production certification verifies the new tables, migration, `funds_account_public_id` column, and 55 MySQL trigger controls. Installer 1.7.6 dependency-object compatibility from Step 3 is preserved.

Next: **Step 5/12 — Advanced Reconciliation Automation**.


## New plan Step 5/12 — Advanced Reconciliation Automation

- Read-only public boundary: `titan.ledger.advanced-reconciliation.v1`.
- Supported deterministic match shapes are one-to-one, one-to-many and many-to-one; many-to-many remains fail-closed.
- Match groups require exact signed summed amounts and a bounded three-day date window; tied/ambiguous suggestions are never auto-confirmed.
- Rejected group matches append rejection evidence and release only the derived active-member index; immutable group/member history remains retained.
- Statement duplicate detection uses a canonical economic SHA-256 fingerprint that excludes provider statement/transaction IDs.
- Bounded adjustment posting supports only `bank_fee`, `interest_income` and `interest_expense`, through Command Bus/Risk/Assurance into an authoritative Ledger journal.
- Raw bank narrative remains excluded; only bounded reference hashes/classification hints may be retained.
- Payment initiation and bank credential authority remain outside Ledger.
