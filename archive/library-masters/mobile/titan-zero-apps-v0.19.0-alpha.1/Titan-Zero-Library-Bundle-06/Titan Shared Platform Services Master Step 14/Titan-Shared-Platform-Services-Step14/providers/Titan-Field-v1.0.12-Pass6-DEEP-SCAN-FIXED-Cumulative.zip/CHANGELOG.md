# 1.0.10 — Agent-01 Pass 3

- Added canonical cross-extension execution envelope, correlation/causation, idempotency scope, authority/provenance/evidence traceability, duplicate suppression and deferred unknown-outcome semantics.

# Titan Field Changelog

## 1.0.6 — Schedule navigation canonicalization hotfix

- Collapses the legacy `crm_calendar` and canonical `crm_schedule` Crew rows into one visible Schedule entry.
- Rewrites and deactivates the obsolete Calendar row so it cannot keep opening the old CRM list surface.
- In staged CRM alpha.17-alpha.23 mode, both the Schedule child and Crew parent open the real read-only month calendar.
- On authoritative activation, the Crew parent returns to the canonical Titan Field Schedule route.
- Menu health checks now detect both an active legacy Calendar duplicate and Crew-parent route drift.
- Adds a regression gate matching the exact duplicate-menu shape present in the supplied host DB dump.

## 1.0.5 — Schedule calendar UI hotfix

- Replaced the table-only Schedule page with a real Monday–Sunday month calendar.
- Added Previous / Today / Next month navigation and a selected-day appointment agenda.
- Calendar cells show appointment time, title, status and assigned worker.
- Kept the canonical navigation label as `Schedule`.
- Hardened menu self-healing so an existing CRM row labelled `Calendar` is detected as drift and renamed to `Schedule` when Field activates.
- On CRM alpha.17-alpha.23, exposes a bounded read-only Schedule calendar and repoints only the existing schedule row, so the corrected calendar is visible before authoritative Field activation.
- Preserved governed SchedulingKernel mutations and existing Field Control integration.

## 1.0.4 — Installer 1.7.4 MySQL timestamp-mode compatibility

- Replaces six required operational `TIMESTAMP` columns with `DATETIME` so Field does not depend on MySQL implicit TIMESTAMP defaults.
- Fixes live install failure `Invalid default value for consent_granted_at` in worker-location history.
- Hardens the same latent issue in offline device/receipt timestamps before it can fail later in the migration chain.
- Preserves restartability: route, route-stop, location, offline-device and offline-receipt tables remain guarded with `Schema::hasTable()`.
- Adds a package-wide migration regression gate that rejects required `timestamp()` columns unless they are nullable or carry an explicit safe default.
- Preserves CRM alpha.17 staged-install / alpha.24 authoritative-activation behavior.

## 1.0.3 — CRM alpha.17 staged-activation compatibility

- Installer dependency now accepts CRM `>=1.3.0-alpha.17` so the extension schema can be staged on the current host.
- Authoritative activation remains hard-gated to CRM `>=1.3.0-alpha.24`.
- Below the activation floor, provider registration is schema-only: no CRM adapters, command gateway, domain runtime, routes, menus, AI Workforce contribution, Titan Go replay, commands, or schedules are registered.
- The self-healing menu migration is activation-gated so staged installs cannot alter Field navigation.
- Titan Maps continues to detect Field activation via the bound `FieldCommandGateway`, so Maps will not route operational writes to a dormant Field installation.
- Added staged-activation and Installer 1.7.3 regression coverage.

## 1.0.2 — Installer 1.7.3/MySQL compatibility hotfix

- Installer 1.7.3 dependency schema compatibility.
- Explicit short MySQL index names for all overlength Field migration identifiers.
- Package-wide MySQL 64-character identifier regression gate.

## 1.0.1 — Post-production deep-scan hotfix

- Restored the safe CRM extraction dependency floor to `>=1.3.0-alpha.24`.
- Made Titan Go offline receipt reservation concurrency-safe and recoverable.
- Enforced current consent/shift checks and scheduled retention pruning for Field fallback GPS.
- Preserved offline replay classification on duplicate samples.
- Replaced the route menu ampersand with `and` for host-safe navigation rendering.
- Added a dedicated post-production regression gate and certification report.

## 1.0.0-alpha.16 — Joint Pass 15: Optimisation Proposals + AI Workforce

- Added Maps-backed, read-only route optimisation proposal requests with immutable proposal evidence and input/proposal hashes.
- Added separate governed request / accept / reject / apply lifecycle; only Titan Field applies accepted proposals through the existing route writer.
- Added expiry and baseline-order staleness checks so changed routes cannot receive obsolete proposals.
- Added Field-owned Workforce Manifest 2.0 with dispatcher/operations roles and governance-bound tool definitions.
- Added host DB reconciliation notes preserving existing Crew and Maps menus without duplicate parents/children.

## 1.0.0-alpha.15 — Joint Pass 14: Titan Go Offline Field Runtime

- Added device-bound Titan Go mobile context, device registration, replay, batch sync and evidence APIs.
- Added durable offline device/operation receipt stores with request hashing, idempotent receipt replay and retry-safe failed-operation handling.
- Added optimistic `entity_version` conflict protection for work orders, work-order tasks, dispatch, forms, routes and route stops.
- Added offline work-order checklist/task status support and transactional task-status Signal/audit evidence.
- Routed every offline business mutation back through `FieldCommandGateway`; no second offline writer was introduced.
- Added Maps-preferred delayed GPS replay with consent/shift validation and bounded Field fallback storage when Maps is absent.
- Stale fallback GPS is retained as historical evidence but filtered out of live-position surfaces.

# Titan Field Changelog

## 1.0.0-alpha.14 — Joint Pass 13: Capacity Forecasting + Predictive Operations

- Added read-only `CapacityForecastCalculator` and `CapacityForecastService`.
- Forecasts worker/team capacity from normalized availability, legacy availability fallback, time off, availability exceptions, business/worker blackouts and booked appointments.
- Models unfilled demand from unscheduled/unassigned work orders plus unresolved service requests not already converted to work orders.
- Adds skill-pressure and service-area-pressure evidence without double-counting demand as scheduled work.
- Extended the optional Maps peer with non-authoritative `capacityPressureEvidence` for nearest-worker travel-matrix, freshness and territory pressure.
- Added self-healing **Capacity Forecast** navigation and a read-only forecast surface; all corrective actions still require governed scheduling/dispatch commands.

## 1.0.0-alpha.13 — Joint Pass 12: Work-Order Health, Profitability + Spatial Cost Intelligence

- Added pure `WorkOrderProfitabilityCalculator` and read-only `WorkOrderHealthService`.
- Derives quote/revenue basis, planned/actual labour, materials, known actual cost, forecast final cost, projected margin, over-hours/over-budget state and cost-coverage evidence from retained Field records.
- Missing labour/material cost rates fail transparently to incomplete/unknown forecast rather than invented profitability.
- Extended optional spatial peer contract with read-only `workOrderCostEvidence`; Maps supplies distance/time/territory evidence while Field remains financial authority.
- Field can convert travel time/distance into cost only when explicit Field-owned cost rates exist.
- Added work-order health UI indicators and retained Maps pricing hints as advisory-only evidence.

## 1.0.0-alpha.12 — Joint Pass 11: Titan Maps Bridge + Field Control

- Added optional `SpatialIntelligenceGateway` with Maps-preferred and deterministic Field fallback implementations.
- Added a real Maps-engine-backed Field Control surface with worker lanes, live positions, routes/ETA and operational exceptions.
- Added governed appointment move/resize through `titan.field.scheduling|reschedule_appointment` and `SchedulingKernel` revalidation.
- Moved preferred high-frequency GPS ingestion behind the Maps peer when installed while retaining Field ping storage as standalone fallback/upgrade compatibility.
- Normalized route travel evidence to meters/seconds and fixed the prior fallback key mismatch that could leave route totals at zero.
- Preserved standalone Field boot and all historical CRM-style named routes/menu self-healing.

## 1.0.0-alpha.11 — Pass 10: Routes, Route Stops & Live Worker Position

- Added Titan-owned day routes, ordered route stops and travel estimates without claiming route optimization.
- Added governed route create/add-stop/resequence/status/location commands and self-healing Crew navigation.
- Added consent-bound, active-shift-only worker location pings with accuracy validation and 1–30 day retention.
- Added transactional route/location Signals and retained non-destructive migrations.
- Adapted donor routing concepts without importing donor tables/providers/writers.


## 1.0.0-alpha.4 — Pass 3: Tenant & Reference Integrity

- Added central `FieldReferenceIntegrity` fail-closed relationship validator.
- Tenant-scoped validation now covers customer/company/contact, locations, assets, services, requests, work orders, appointments, forms/submissions, reviews, service areas, agreements, leads/deals and support references.
- Added contact→company, location→customer, asset→location/customer, work-order and appointment relationship-consistency checks.
- Worker assignment and time recording now require an active worker profile in the active tenant.
- Extended `FieldTenantContext` with tenant-user membership validation; CRM membership resolution remains isolated in the CRM compatibility adapter.
- Service-request/work-order/support/recovery owner references now reject users outside the active tenant.
- Recurring agreement service lists, service-area service restrictions and catalogue form-template references are tenant validated before persistence.
- Dispatch `in_progress` transition now coordinates dispatch/work-order state inside one transaction instead of swallowing work-order transition failures.
- Added Pass-3 regression and embedded release-verifier coverage.

## 1.0.0-alpha.2 — Pass 1: Baseline/P0 Hardening + Self-Healing Navigation

- made field-service profile migration restartable;
- converted historical field-domain/profile rollbacks to non-destructive retention;
- restored the 10 canonical vertical profile resources from the current CRM lineage;
- added Titan-owned self-healing menu definition/installer;
- preserved legacy CRM field-service Laravel named routes;
- adopted pre-existing CRM menu rows by route before creating a preferred key;
- added Customers / Work / Crew / Gear compatibility placement;
- added route-cache sentinel recovery and MagicAI menu cache regeneration;
- added a menu synchronization migration;
- expanded the embedded release verifier;
- added Pass-1 regression coverage and donor/provenance documentation.

## 1.0.0-alpha.1

Initial extraction from Titan CRM v1.3.0-alpha.23 with preserved domain implementation, routes, UI and schema ownership.

## 1.0.0-alpha.3 — Pass 2: Titan Field Ports & Domain Boundaries

- Added Field-owned contracts for tenancy, audit, automation, host gating and permission gating.
- Isolated all direct CRM implementation namespaces under `System/Infrastructure/Compatibility/Crm`.
- Replaced CRM middleware imports in routes with Titan Field middleware wrappers while preserving legacy CRM-named routes and permissions.
- Added the `titan-field.*` configuration namespace with upgrade-safe CRM compatibility defaults.
- Converted Field domain services and controller tenancy resolution to `FieldTenantContext`.
- Converted mutation audit paths to `FieldAuditPort` and automation triggers to `FieldAutomationPort`.
- Preserved historical `crm_*` tables and the CRM dependency as an explicit compatibility bridge; no data authority moved back to CRM.

## 1.0.0-alpha.5 — Pass 4 Governed Capabilities + Signals

- Replaced the flat capability-name-only declaration with 23 canonical `titan.field.*` governed capability definitions while preserving every legacy `crm.*` alias.
- Each capability now declares owner, input/output contracts, risk, autonomy, evidence, offline policy, reversibility and idempotency expectations.
- Added `FieldSignalPort` and the Titan-owned `DatabaseFieldSignalOutbox`.
- Added restartable retained `titan_field_signal_outbox` schema with tenant, trace, correlation, causation, idempotency, payload and structured receipt fields.
- Important Service Request, Work Order, Appointment, Dispatch, Recurring, Form, Evidence, Support and Review mutations now write Signal envelopes inside the authoritative database transaction.
- Signal/outbox failure is fail-closed and rolls back the business mutation; evidence file writes compensate by deleting the stored file when DB/outbox persistence fails.
- CRM automation events remain a non-authoritative compatibility delivery path while existing consumers migrate; the Titan Field outbox is now the canonical Signal record.

## 1.0.0-alpha.6 — Pass 5 Governed Command Gateway + Compatibility Alias Bridge

- Added Field-owned `FieldCommandGateway`, `FieldCommandAuthorizer` and `FieldCommandRouter` contracts.
- Added `GovernedFieldCommandGateway` and routed all current browser mutation endpoints through it while leaving read surfaces unchanged.
- Added retained `titan_field_command_receipts` with canonical/requested capability, operation, tenant/actor, trace/correlation/causation, request fingerprint and durable idempotency metadata.
- Matching command retries replay the completed structured receipt; conflicting payload reuse of an idempotency key fails closed.
- Added concurrent idempotency reservation protection and outer-transaction evidence-file compensation.
- Added Field-owned `FieldPermissionCatalog` / `FieldPermissionService`; historical CRM field permission names are compatibility aliases and no longer depend on the newer CRM permission catalogue containing extracted Field permissions.
- Preserved the Pass-2 `CrmFieldPermissionGate` as an injectable compatibility artifact without keeping it as the canonical Field route gate.
- Added canonical permission and command-gateway metadata to every read/write capability definition.
- Preserved all historical CRM field-service named routes, menu-healing behavior, `crm_*` table identities, and `crm.*` capability aliases.

## 1.0.0-alpha.7 — Pass 6
- Added Titan-owned advanced recurrence calculator with weekday, day-of-month, nth/last weekday and include/exclude semantics.
- Existing RecurringServiceEngine remains the sole occurrence writer with locking/idempotency preserved.
- Added normalized worker availability rules/exceptions and generalized blackout policies.
- SchedulingKernel now consumes normalized policies and falls back to legacy weekly availability JSON where no normalized rules exist.
- Added donor provenance record; no donor FSM tables/writers imported.

## 1.0.0-alpha.8 — Pass 7: Scheduling Kernel v2 + Explainable Technician Matching
- Extended SchedulingKernel hard constraints with service-area enforcement and daily capacity metrics.
- Added non-authoritative TechnicianRecommendationService ranking only workers that pass the hard kernel.
- Added deterministic offline Haversine travel estimates, workload/capacity, skills, service-area and continuity explanations.
- Added governed read capability `titan.field.scheduling.recommend_workers` with legacy alias `crm.scheduling.recommend_workers`.
- Added permission-gated recommendation endpoint without changing authoritative assignment writes.

## 1.0.0-alpha.9 — Pass 8
- Hardened technician recommendations with transparent 100-point scoring across hard eligibility, skills, rolling workload, territory preference, route adjacency and continuity.
- Added immutable `titan_field_recommendation_snapshots` decision evidence with deterministic context/recommendation hashes and trace/correlation metadata.
- Preserved non-authoritative recommendation semantics; assignments still require the governed command gateway.

## Pass 9 — SLA + Operational Exceptions
Titan Field v1.0.0-alpha.10 adds the governed operational exception queue, SLA deadlines, deduplicated detection, lifecycle history, Signals, menu/UI and command-gateway mutations.
## 1.0.8 — Workforce / Blueprint v4.2.1 convergence
- Canonical Manifest v2.2 metadata.
- Role-neutral Titan AI Workforce integration contract; Workforce remains identity/role/work-item owner.
- Canonical active tenancy is `company_id`; legacy tenant key limited to compatibility/migration paths.
- Governed execution, provider provenance, fail-closed availability semantics and contract regression test.
