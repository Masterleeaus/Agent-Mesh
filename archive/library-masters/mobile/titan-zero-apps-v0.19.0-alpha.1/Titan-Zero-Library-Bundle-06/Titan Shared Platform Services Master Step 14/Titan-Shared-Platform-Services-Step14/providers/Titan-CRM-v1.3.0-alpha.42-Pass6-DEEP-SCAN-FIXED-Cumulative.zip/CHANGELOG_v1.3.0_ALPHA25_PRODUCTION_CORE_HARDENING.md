# Titan CRM Core v1.3.0-alpha.25 — Production Core Hardening

- Removed active registration/navigation for extracted Titan Field, Locker, Ledger and Pay domains.
- Added split-aware capability ownership and lazy external-domain compatibility bridge.
- Removed active legacy CRM autonomy/control routes and menu surfaces; Titan Autonomy remains the external authority.
- Routed core human, portal, import, chatbot-settings, sharing and integration mutations through governed Command Bus execution.
- Disabled legacy local-human mutation fallback by default.
- Added lead conversion forensic mapping and quote/estimate expiry + pricing/tax/terms snapshots.
- Hardened API-key revocation/rotation, webhook replay metadata/signatures and bounded portal grants.
- Portal file scanning is fail-closed; production health blocks when no real scanner is bound.
- Added production health/readiness command and Core-specific exact-package verifier.
- Corrected Titan Hub quote acceptance to `crm.quote.approve`.
- Deprecated the stale CRM recurring-service generator; Titan Field owns recurring generation.
- Preserved historical `crm_*` data tables and compatibility capability names without duplicate domain writers.
