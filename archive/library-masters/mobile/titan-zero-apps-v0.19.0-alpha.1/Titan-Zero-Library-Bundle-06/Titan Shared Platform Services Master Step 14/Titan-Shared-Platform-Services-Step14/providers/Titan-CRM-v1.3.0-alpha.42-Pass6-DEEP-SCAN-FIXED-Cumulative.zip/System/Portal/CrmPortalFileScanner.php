<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Portal;

interface CrmPortalFileScanner
{
    /** @return array{status:string,engine?:string,details?:string} */
    public function scan(string $path, string $mimeType): array;
}
