<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Host;

final class TitanInstallerManifestContract
{
    /** @return list<string> */
    public function validate(array $manifest, bool $packaged = true): array
    {
        $errors=[];
        foreach (['name','type','version','description','schema','slug','folder','provider'] as $key) {
            if (!isset($manifest[$key]) || !is_string($manifest[$key]) || trim($manifest[$key])==='') {
                $errors[]="extension.json is missing a valid '{$key}' value.";
            }
        }
        if (($manifest['type']??null)!=='extension') $errors[]="extension.json 'type' must be 'extension'.";
        if (($manifest['schema']??null)!=='titan-extension-v1') $errors[]="extension.json 'schema' must be 'titan-extension-v1'.";
        if (array_key_exists('support_telegram',$manifest) && !is_string($manifest['support_telegram'])) {
            $errors[]="extension.json 'support_telegram' must be a string.";
        }
        foreach (['dependencies','optional_dependencies'] as $field) {
            if (!array_key_exists($field,$manifest)) continue;
            if (!is_array($manifest[$field]) || !array_is_list($manifest[$field])) {
                $errors[]="extension.json '{$field}' must be a list.";
                continue;
            }
            foreach ($manifest[$field] as $i=>$dependency) {
                if (!is_array($dependency) || !is_string($dependency['slug']??null) || trim((string)$dependency['slug'])===''
                    || !is_string($dependency['version']??null) || trim((string)$dependency['version'])==='') {
                    $errors[]="extension.json '{$field}.{$i}' must contain non-empty slug and version strings.";
                }
            }
        }
        if ($packaged) {
            $files=$manifest['integrity']['files']??null;
            if (!is_array($files) || $files===[]) $errors[]="extension.json is missing a valid 'integrity.files' map.";
            elseif (array_is_list($files)) $errors[]="extension.json 'integrity.files' must be a path-to-SHA256 map.";
            else foreach ($files as $path=>$sha) {
                if (!is_string($path) || trim($path)==='' || !is_string($sha) || preg_match('/^[a-f0-9]{64}$/',$sha)!==1) {
                    $errors[]="extension.json contains an invalid integrity entry.";
                    break;
                }
            }
        }
        return array_values(array_unique($errors));
    }
}
