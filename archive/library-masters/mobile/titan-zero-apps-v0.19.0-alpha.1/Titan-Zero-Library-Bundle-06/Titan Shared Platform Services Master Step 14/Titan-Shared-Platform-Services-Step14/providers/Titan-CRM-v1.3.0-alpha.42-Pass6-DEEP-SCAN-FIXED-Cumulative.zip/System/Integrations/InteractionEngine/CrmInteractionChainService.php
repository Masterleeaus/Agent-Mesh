<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\InteractionEngine;

use App\Extensions\Crm\System\Tenancy\CrmCompanyContext;
use Illuminate\Contracts\Foundation\Application;
use InvalidArgumentException;

/** Bounded multi-step chains composed only of CRM Core-owned journeys. */
final class CrmInteractionChainService
{
    /** @var array<string,array<int,string>> */
    private const CHAINS = [
        'customer-quote' => ['new-customer', 'new-quote'],
        'lead-opportunity' => ['new-lead', 'new-opportunity'],
        'quote-invoice' => ['new-quote', 'new-invoice'],
    ];

    public function __construct(
        private Application $app,
        private CrmInteractionJourneyRegistry $journeys,
    ) {}

    /** @return array<string,mixed> */
    public function plan(string $chain, array $context = []): array
    {
        $chain = trim($chain);
        if (! isset(self::CHAINS[$chain])) {
            throw new InvalidArgumentException("Unknown CRM interaction chain: {$chain}");
        }

        $steps = [];
        foreach (self::CHAINS[$chain] as $index => $journeyKey) {
            $journey = $this->journeys->get($journeyKey);
            $steps[] = [
                'index' => $index,
                'journey' => $journeyKey,
                'name' => $journey['name'],
                'capability' => $journey['capability'],
                'surface' => $journey['surface'],
            ];
        }

        return [
            'status' => 'planned',
            'chain' => $chain,
            'step_index' => 0,
            'steps' => $steps,
            'next_journey' => self::CHAINS[$chain][0],
            'prefill' => $this->prefill($chain, 0, $context, []),
            'context' => $this->safeContext($context),
        ];
    }

    /** @return array<string,mixed> */
    public function continue(
        string $chain,
        int $completedStep,
        array $completedResult,
        array $context,
        CrmCompanyContext $companyContext,
        bool $startNext = true,
    ): array {
        if (! isset(self::CHAINS[$chain])) {
            throw new InvalidArgumentException("Unknown CRM interaction chain: {$chain}");
        }

        $nextIndex = $completedStep + 1;
        if ($nextIndex >= count(self::CHAINS[$chain])) {
            return ['status' => 'completed', 'chain' => $chain, 'step_index' => $completedStep, 'result' => $completedResult];
        }

        $nextJourney = self::CHAINS[$chain][$nextIndex];
        $prefill = $this->prefill($chain, $nextIndex, $context, $completedResult);
        $next = [
            'status' => 'ready',
            'chain' => $chain,
            'step_index' => $nextIndex,
            'next_journey' => $nextJourney,
            'prefill' => $prefill,
            'context' => $this->safeContext($context),
        ];

        if (! $startNext) return $next;

        /** @var CrmConversationalInteractionService $interactions */
        $interactions = $this->app->make(CrmConversationalInteractionService::class);
        return $next + ['started' => $interactions->start($nextJourney, $companyContext, ['prefill' => $prefill])];
    }

    /** @return array<string,mixed> */
    public function prefill(string $chain, int $stepIndex, array $context = [], array $completedResult = []): array
    {
        if (! isset(self::CHAINS[$chain])) {
            throw new InvalidArgumentException("Unknown CRM interaction chain: {$chain}");
        }

        $prefill = $this->safeContext($context);
        foreach (['company_id','tenant_id','company_id','user_id','actor_id'] as $unsafe) unset($prefill[$unsafe]);
        if ($stepIndex === 0) return $prefill;

        $resource = $this->resource($completedResult);
        $publicId = $this->publicId($resource);

        if ($chain === 'customer-quote') {
            $kind = strtolower((string)($resource['customer_kind'] ?? $resource['type'] ?? $context['customer_kind'] ?? ''));
            if ($publicId !== '') {
                if ($kind === 'business' || isset($resource['company_name']) || isset($resource['legal_name'])) $prefill['company_public_id'] = $publicId;
                else $prefill['contact_public_id'] = $publicId;
            }
            $companyId = $this->firstString($resource, ['company_public_id','company.public_id']);
            $contactId = $this->firstString($resource, ['contact_public_id','primary_contact_public_id','contact.public_id']);
            if ($companyId !== '') $prefill['company_public_id'] = $companyId;
            if ($contactId !== '') $prefill['contact_public_id'] = $contactId;
        }

        if ($chain === 'lead-opportunity' && $publicId !== '') {
            $prefill['lead_public_id'] = $publicId;
        }

        if ($chain === 'quote-invoice') {
            $companyId = $this->firstString($resource, ['company_public_id']);
            $contactId = $this->firstString($resource, ['contact_public_id']);
            if ($companyId !== '') $prefill['company_public_id'] = $companyId;
            if ($contactId !== '') $prefill['contact_public_id'] = $contactId;
            if ($publicId !== '') $prefill['source_quote_public_id'] = $publicId;
        }

        return array_filter($prefill, static fn($value) => $value !== null && $value !== '');
    }

    /** @return array<string,mixed> */
    private function safeContext(array $context): array
    {
        $allowed = [
            'public_id','customer_kind','company_public_id','contact_public_id','lead_public_id','deal_public_id',
            'title','description','currency','lines','due_at','status','reason','notes','priority','source_quote_public_id',
        ];
        return array_intersect_key($context, array_flip($allowed));
    }

    /** @return array<string,mixed> */
    private function resource(array $result): array
    {
        $cursor = $result;
        for ($i = 0; $i < 5; $i++) {
            if (isset($cursor['result']) && is_array($cursor['result'])) { $cursor = $cursor['result']; continue; }
            if (isset($cursor['data']) && is_array($cursor['data'])) { $cursor = $cursor['data']; continue; }
            break;
        }
        return $cursor;
    }

    private function publicId(array $resource): string { return trim((string)($resource['public_id'] ?? '')); }

    private function firstString(array $resource, array $paths): string
    {
        foreach ($paths as $path) {
            $value = $resource;
            foreach (explode('.', $path) as $segment) {
                if (! is_array($value) || ! array_key_exists($segment, $value)) { $value = null; break; }
                $value = $value[$segment];
            }
            if (is_scalar($value) && trim((string)$value) !== '') return trim((string)$value);
        }
        return '';
    }
}
