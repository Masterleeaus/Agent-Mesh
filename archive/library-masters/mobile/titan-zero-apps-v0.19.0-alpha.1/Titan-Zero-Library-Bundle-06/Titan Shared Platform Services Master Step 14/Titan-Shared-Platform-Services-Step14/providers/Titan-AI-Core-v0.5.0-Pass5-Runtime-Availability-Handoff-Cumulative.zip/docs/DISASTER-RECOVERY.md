# Disaster Recovery
Back up extension-owned plan/model-profile tables with the host database. Restore and reconcile by plan ID, trace ID and idempotency key; never infer completion from partial rows.
