<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Services\EvidenceResetPolicy;
use PHPUnit\Framework\TestCase;

final class EvidenceResetPolicyTest extends TestCase
{
    public function test_reset_downgrades_authority_when_old_evidence_no_longer_supports_it(): void
    {
        $policy = new EvidenceResetPolicy();
        self::assertSame(
            AutonomyLevel::Assist,
            $policy->effectiveLevelAfterReset(AutonomyLevel::TrustedAuto, AutonomyLevel::Assist),
        );
        self::assertFalse($policy->gateEligibleAfterReset(false));
    }
}
