<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use App\Extensions\Crm\System\Integrations\{CrmApiKeyService,CrmWebhookService};
use App\Extensions\Crm\System\Security\CrmPermissionService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class IntegrationController extends Controller
{
    public function __construct(private CrmHumanMutationGateway $mutations) {}
    public function index(Request $request,CrmApiKeyService $keys,CrmWebhookService $webhooks,CrmPermissionService $permissions)
    { $uid=(int)$request->user()->id;$permissions->authorize($uid,'crm.integrations.manage');return view('crm::integrations.index',['apiKeys'=>$keys->list($uid),'webhooks'=>$webhooks->list($uid)]); }
    public function issueApiKey(Request $request,CrmPermissionService $permissions)
    { $permissions->authorize((int)$request->user()->id,'crm.api_keys.manage');$data=$request->validate(['label'=>'required|string|max:120','scopes'=>'required|array|min:1','expires_at'=>'nullable|date|after:now','allowed_ip_cidrs'=>'nullable|array|max:20','allowed_ip_cidrs.*'=>'string|max:80']);$issued=$this->mutations->execute($request,'crm.api_key.create',$data);return back()->with('api_key_secret',$issued['secret']??null)->with('status','API key created. Copy it now; only the hash is stored.'); }
    public function rotateApiKey(Request $request,string $key,CrmPermissionService $permissions)
    { $permissions->authorize((int)$request->user()->id,'crm.api_keys.manage');$issued=$this->mutations->execute($request,'crm.api_key.rotate',['public_id'=>$key]);return back()->with('api_key_secret',$issued['secret']??null)->with('status','API key rotated. Copy the replacement secret now.'); }

    public function revokeApiKey(Request $request,string $key,CrmPermissionService $permissions)
    { $permissions->authorize((int)$request->user()->id,'crm.api_keys.manage');$data=$request->validate(['revocation_reason'=>'nullable|string|max:120']);$this->mutations->execute($request,'crm.api_key.revoke',['public_id'=>$key,'revocation_reason'=>$data['revocation_reason']??'manual']);return back()->with('status','API key revoked.'); }
    public function createWebhook(Request $request,CrmPermissionService $permissions)
    { $permissions->authorize((int)$request->user()->id,'crm.webhooks.manage');$data=$request->validate(['name'=>'required|string|max:120','url'=>'required|url|max:1000','events'=>'required|array|min:1']);$created=$this->mutations->execute($request,'crm.webhook.create',$data);return back()->with('webhook_secret',$created['secret']??null)->with('status','Webhook created. Copy the signing secret now.'); }
    public function rotateWebhook(Request $request,string $webhook,CrmPermissionService $permissions)
    { $permissions->authorize((int)$request->user()->id,'crm.webhooks.manage');$rotated=$this->mutations->execute($request,'crm.webhook.rotate',['public_id'=>$webhook]);return back()->with('webhook_secret',$rotated['secret']??null)->with('status','Webhook signing secret rotated. Copy the new secret now.'); }

    public function disableWebhook(Request $request,string $webhook,CrmPermissionService $permissions)
    { $permissions->authorize((int)$request->user()->id,'crm.webhooks.manage');$this->mutations->execute($request,'crm.webhook.disable',['public_id'=>$webhook]);return back()->with('status','Webhook disabled.'); }
    public function registerEmail(Request $request,CrmPermissionService $permissions)
    { $permissions->authorize((int)$request->user()->id,'crm.integrations.manage');$data=$request->validate(['provider'=>'required|string|max:60','account_email'=>'required|email|max:320','external_account_id'=>'nullable|string|max:255','credentials_reference'=>'nullable|string|max:255']);$this->mutations->execute($request,'crm.email_connection.register',$data);return back()->with('status','Email sync connection metadata saved.'); }
    public function apiStatus(Request $request){return response()->json(['ok'=>true,'user_id'=>(int)$request->attributes->get('crm_api_user_id'),'scopes'=>$request->attributes->get('crm_api_scopes',[])]);}
}
