<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Console;

use App\Extensions\TitanAICore\System\Navigation\HostNavigationRegistrar;
use App\Extensions\TitanAICore\System\Services\HostMenuLifecycle;
use Illuminate\Console\Command;

final class HostSyncCommand extends Command
{
    protected $signature = 'titan-ai-core:host-sync';
    protected $description = 'Register Titan AI Core host contributions and regenerate MagicAI menu caches when supported.';

    public function handle(HostNavigationRegistrar $navigation, HostMenuLifecycle $menus): int
    {
        $registered = $navigation->registerAll();
        $cache = $menus->regenerate();

        foreach ($registered as $channel => $ok) {
            $this->line(sprintf('%s %s', $ok ? '[OK]' : '[--]', $channel));
        }
        $this->line(sprintf('%s MenuService available', $cache['available'] ? '[OK]' : '[--]'));
        $this->line(sprintf('%s menu cache regenerated', $cache['regenerated'] ? '[OK]' : '[--]'));

        // Missing host registries are a compatibility state, not an AI runtime failure.
        return self::SUCCESS;
    }
}
