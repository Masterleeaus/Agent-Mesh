<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Contracts;
interface NoteRepositoryContract { public function search(int $userId,array $filters=[]): array; public function create(int $userId,int $actorUserId,array $data): array; }
