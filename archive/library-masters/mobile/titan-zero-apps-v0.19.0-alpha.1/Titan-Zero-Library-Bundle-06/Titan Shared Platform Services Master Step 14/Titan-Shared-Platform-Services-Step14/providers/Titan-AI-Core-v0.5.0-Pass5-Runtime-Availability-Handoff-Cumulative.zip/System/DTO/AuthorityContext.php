<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\DTO;

final readonly class AuthorityContext
{
    /** @param array<int,string> $permissions */
    public function __construct(
        public int $level = 0,
        public array $permissions = [],
        public string $source = 'unverified',
    ) {}

    public function allows(string $capability): bool
    {
        return in_array($capability, $this->permissions, true);
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'level' => $this->level,
            'permissions' => $this->permissions,
            'source' => $this->source,
        ];
    }
}
