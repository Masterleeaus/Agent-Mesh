# Titan CRM v1.3.0-alpha.21 Integrity & Governance Hardening Design

## Scope
Harden the existing alpha.20 CRM in place. Preserve all working CRM, Pay, Locker, field-service, mobile, portal, Interaction Engine, TitanAI, Chatbot, automation and installer behavior. Do not extract Locker/Ledger/Field in this pass.

## Confirmed targets
1. Explicit versioned AI projections that expose declared fields only and omit tenant/internal relationship identifiers.
2. Tenant reference guard for cross-entity public-id references before governed writes.
3. Provider payment replay protection with tenant/provider/provider-reference uniqueness and original-record replay semantics.
4. Signal outbox delivery metadata, dedup keys, retry/dead-letter lifecycle and dispatcher command.
5. Automation action execution through CrmCommandBusGateway with recursion/causation depth protection and simulation support.
6. Command receipt v2 metadata: duration, affected count, version hint, receipt integrity hash, remediation information.
7. Actionable optimistic-concurrency exception details and invariant observability.
8. Tenant/actor/capability write-rate limiting for AI and Chatbot mutation paths.
9. Import impact reports, relationship validation, staged execution and all-or-nothing batch transactions for actual domain writes.

## Boundaries
- CRM remains authoritative business state.
- Titan Command Bus remains governance owner; CRM exposes/consumes its port.
- Titan Signal remains event transport owner; CRM persists a transactional outbox and delivers after commit.
- Titan Rewind remains audit/reconstruction owner; CRM receipts expose references.
- Existing simple bookkeeping/Locker/field domains remain compatibility-owned by CRM until later extraction passes.
