<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyControlStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\ControlPlaneAuditSinkContract;

final class LearningSettingsService
{
    public function __construct(
        private readonly AutonomyControlStoreContract $store,
        private readonly string $policyVersion,
        private readonly ?ControlPlaneAuditSinkContract $audit = null,
    ) {}

    public function save(int $tenantCompanyId, array $requested, array $platformPolicy, ?int $actorUserId = null, ?string $correlationId = null): array
    {
        $settings = [
            'user' => (bool) ($requested['user'] ?? false),
            'business' => (bool) ($requested['business'] ?? false),
            'system' => (bool) ($requested['system'] ?? false) && (bool) ($platformPolicy['system_wide_learning_permitted'] ?? false),
            'learning_event_retention_days' => $this->retention($requested['learning_event_retention_days'] ?? null),
            'autonomy_evidence_retention_days' => $this->retention($requested['autonomy_evidence_retention_days'] ?? null),
        ];
        $this->store->saveLearningSettings($tenantCompanyId, $settings, $this->policyVersion);
        $this->audit?->record([
            'tenant_company_id' => $tenantCompanyId,
            'user_id' => $actorUserId,
            'event_type' => 'learning.settings_changed',
            'payload' => ['settings' => $settings],
            'policy_version' => $this->policyVersion,
            'correlation_id' => $correlationId,
        ]);
        return $settings;
    }

    private function retention(mixed $value): ?int
    {
        if ($value === null || $value === '') return null;
        $days = (int) $value;
        return max(1, min(3650, $days));
    }
}
