<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Models\ExternalContact;
use Illuminate\Support\Str;

final class ExternalContactService
{
    public function resolve(int $companyId, string $provider, ?string $externalRef, array $metadata = []): ?ExternalContact
    {
        $externalRef = trim((string) $externalRef);
        if ($externalRef === '') return null;
        $contact = ExternalContact::query()->firstOrNew([
            'company_id' => $companyId,
            'provider' => strtolower($provider),
            'external_contact_ref' => $externalRef,
        ]);
        if (! $contact->exists) $contact->uuid = (string) Str::uuid();
        $profile = is_array($metadata['contact'] ?? null) ? $metadata['contact'] : [];
        $changes = array_filter([
            'display_name' => $profile['display_name'] ?? $profile['name'] ?? null,
            'email' => $profile['email'] ?? null,
            'phone' => $profile['phone'] ?? null,
            'avatar' => $profile['avatar'] ?? $profile['profile_picture_url'] ?? null,
            'country' => $profile['country'] ?? null,
            'ip_address' => $profile['ip_address'] ?? null,
        ], static fn ($value): bool => $value !== null && $value !== '');
        $context = $profile;
        foreach (['display_name','name','email','phone','avatar','profile_picture_url','country','ip_address'] as $key) unset($context[$key]);
        if ($context !== []) {
            $existing = is_array($contact->metadata) ? $contact->metadata : [];
            $changes['metadata'] = array_replace_recursive($existing, $context);
        }
        $contact->fill($changes)->save();
        return $contact;
    }
}
