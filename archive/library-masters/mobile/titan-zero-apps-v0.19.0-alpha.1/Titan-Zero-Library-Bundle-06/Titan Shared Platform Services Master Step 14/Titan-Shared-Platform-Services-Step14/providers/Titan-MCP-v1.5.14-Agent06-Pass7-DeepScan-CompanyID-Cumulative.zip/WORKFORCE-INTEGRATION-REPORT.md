# Workforce Integration Report — titan-mcp

## Result

This extension remains the owner of its domain implementation and now publishes an authority-neutral Workforce provider contract in `workforce-integration.json`. Titan AI Workforce owns employee identity, hierarchy, teams, responsibilities, assignments and work items. Titan Autonomy remains the effective authority source.

## Tenant boundary

New Workforce/runtime integration metadata uses `company_id`. No missing licence, price, geographic coverage, emergency service, permission or authority is inferred.

## Published surfaces

- Capabilities: 36
- Read/tool surfaces: 26
- Governed command surfaces: 10
- Availability is fail-closed across available/degraded/unavailable/missing_provider/blocked/policy_disabled.
- Provider provenance/version is required for executable work.
- Disable, removal or upgrade does not mutate Workforce role/employee identity and cannot grant fallback authority.

## Verification

`tests/standalone/verify_workforce_integration.php` validates the machine-readable contract and authority/tenancy invariants.
