<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindCustodyEvent extends Model
{
    protected $table = 'titan_rewind_custody_events';
    protected $fillable = ['event_uuid','tenant_company_id','package_uuid','action','actor_id','reason','metadata','occurred_at'];
    protected $casts = ['tenant_company_id'=>'integer','actor_id'=>'integer','metadata'=>'array','occurred_at'=>'datetime'];
}
