# Extension Lifecycle

## Install / preflight

Preflight verifies PHP extensions, host `APP_KEY`, manifests, required migrations, provider files, Workforce assets and complete package SHA-256 integrity before the extension is considered healthy.

## Enable / disable

`config('titan-time-attendance.enabled')` gates provider boot, routes, schedules and runtime services. Disabling the extension stops new runtime work without deleting operational or audit data.

## Upgrade

Upgrades use forward-only extension-owned migrations. No migration writes or alters CRM, users, jobs, sites or other foreign-owned tables. Every shipped migration includes a `down()` path for staged rollback testing.

## Uninstall

Uninstall removes the published `titan-time-attendance.php` configuration file only. Operational, verification, audit, command, Signal and workflow data are retained by default. Destructive data purge is intentionally not part of ordinary extension uninstall.

## Retained-data reinstall

The base create migrations guard every extension-owned table with `Schema::hasTable`. This matches the default retain-on-uninstall policy: reinstalling the extension over retained operational data does not attempt to recreate existing base tables, while later additive migrations remain independently guarded and reversible for staged rollback tests.

## Signal worker lifecycle

Signal delivery uses tenant-partitioned leased claims. A worker claims one row under a database row lock, commits the lease, performs delivery outside the transaction and finalizes only when its claim token still owns the row. Expired leases are recoverable, retries are bounded, and persistent failures are dead-lettered. Transport semantics are explicitly at-least-once; downstream consumers use stable event/deduplication identity.
