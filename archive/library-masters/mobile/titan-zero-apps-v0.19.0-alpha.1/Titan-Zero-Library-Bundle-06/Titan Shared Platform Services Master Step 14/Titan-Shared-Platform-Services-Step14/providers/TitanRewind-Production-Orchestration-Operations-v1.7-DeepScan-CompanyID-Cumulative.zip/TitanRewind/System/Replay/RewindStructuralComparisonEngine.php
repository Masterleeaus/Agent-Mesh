<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Replay;

use App\Extensions\TitanRewind\System\Reconstruction\RewindDiffService;
use App\Extensions\TitanRewind\System\Support\CanonicalJson;
use App\Extensions\TitanRewind\System\Artifacts\RewindHistoricalArtifactArchive;
use InvalidArgumentException;

final class RewindStructuralComparisonEngine
{
    private const PROJECTED_FIELDS = [
        'event_id','sequence','occurred_at','event_type','source_engine','tier','lane','decision_id','capability_name','capability_version',
        'model_provider','model_name','model_version','policy_version','guide_version','knowledge_version',
        'risk_state','assurance_state','autonomy_state','governance_state','reason_codes','evidence_refs','rationale',
    ];

    private const COUNTERFACTUAL_FIELDS = [
        'capability_name','capability_version','model_provider','model_name','model_version','policy_version','guide_version','knowledge_version',
        'risk_state','assurance_state','autonomy_state','governance_state','reason_codes','evidence_refs','rationale',
    ];

    public function __construct(
        private CanonicalJson $canonical,
        private RewindDiffService $diff,
        private RewindArtifactResolverRegistry $artifacts,
        private RejectingReplayCommandGateway $commands,
        private ?RewindHistoricalArtifactArchive $artifactArchive = null,
        private ?RewindDeterministicSeed $seeds = null,
    ) {}

    public function compare(array $trace, RewindReplayRequest $request): array
    {
        if ($this->commands->mutationAllowed()) {
            throw new \LogicException('REPLAY_BOUNDARY_VIOLATION: comparative replay command gateway must deny mutation.');
        }
        if (($trace['event_count'] ?? count($trace['events'] ?? [])) < 1 || !is_array($trace['events'] ?? null)) {
            throw new InvalidArgumentException('Comparative replay requires at least one reconstructed trace event.');
        }

        $baseline = $this->project($trace);
        $candidate = $baseline;
        $impacted = [];
        $artifactResolution = [];

        match ($request->mode()) {
            'current-state' => $this->applyCounterfactual($candidate, $request->currentStateOverrides(), $impacted),
            'counterfactual' => $this->applyCounterfactual($candidate, $request->counterfactualOverrides(), $impacted),
            'model-compare' => $this->applyArtifactTarget($candidate, 'model', $request->targetModel() ?? [], $impacted, $artifactResolution),
            'policy-compare' => $this->applyArtifactTarget($candidate, 'policy', $request->targetPolicy() ?? [], $impacted, $artifactResolution),
            'knowledge-compare' => $this->applyArtifactTarget($candidate, 'knowledge', $request->targetKnowledge() ?? [], $impacted, $artifactResolution),
            default => throw new InvalidArgumentException('Unsupported comparison mode.'),
        };

        $comparison = $this->diff->compare($baseline, $candidate);
        $seed = ($this->seeds ?? new RewindDeterministicSeed())->resolve(
            $request->deterministicSeed(),
            (int)($trace['tenant_company_id'] ?? 0),
            (string)($trace['trace_id'] ?? ''),
            $request->mode(),
        );
        $anchor = (string)($baseline['events'][0]['occurred_at'] ?? '1970-01-01T00:00:00Z');
        try { $clock = new RewindVirtualClock($anchor); } catch (\Throwable) { $clock = new RewindVirtualClock('1970-01-01T00:00:00Z'); }
        sort($impacted, SORT_STRING);
        $impacted = array_values(array_unique($impacted));
        $integrity = strtolower((string)($trace['forensics']['integrity']['status'] ?? 'unknown'));
        $reproducibility = $artifactResolution !== [] && in_array('unavailable', array_column($artifactResolution, 'status'), true)
            ? 'ARTIFACT_UNAVAILABLE'
            : 'PARTIALLY_REPRODUCIBLE';

        $result = [
            'schema_version' => '1.0',
            'mode' => $request->mode(),
            'status' => 'COMPLETED',
            'trace_id' => $trace['trace_id'] ?? null,
            'tenant_company_id' => $trace['tenant_company_id'] ?? null,
            'mutation_attempted' => false,
            'mutation_allowed' => false,
            'sandbox' => ['command_gateway'=>'rejecting','mutation_policy'=>'deny'],
            'mutation_policy' => 'deny',
            'network_policy' => $request->networkPolicy(),
            'deterministic' => true,
            'deterministic_seed' => $seed,
            'clock_mode' => 'virtual',
            'virtual_now' => $clock->iso8601(),
            'decision_reexecution_performed' => false,
            'execution_semantics' => 'structural_projection_only',
            'integrity_status' => $integrity,
            'reproducibility' => $reproducibility,
            'artifact_resolution' => $artifactResolution,
            'impacted_event_ids' => $impacted,
            'baseline' => $baseline,
            'candidate' => $candidate,
            'diff' => $comparison['changes'],
            'diff_count' => $comparison['count'],
            'diff_risk' => $comparison['risk'],
            'violations' => [],
        ];
        $result['result_hash'] = hash('sha256', $this->canonical->encode($result));
        return $result;
    }

    private function project(array $trace): array
    {
        $events = [];
        foreach ($trace['events'] as $event) {
            if (!is_array($event)) continue;
            $projected = [];
            foreach (self::PROJECTED_FIELDS as $field) {
                $projected[$field] = $event[$field] ?? null;
            }
            $events[] = $projected;
        }
        return [
            'tenant_company_id' => $trace['tenant_company_id'] ?? null,
            'trace_id' => $trace['trace_id'] ?? null,
            'event_count' => count($events),
            'events' => $events,
        ];
    }

    private function applyCounterfactual(array &$candidate, array $overrides, array &$impacted): void
    {
        $eventOverrides = $overrides['events'] ?? [];
        if (!is_array($eventOverrides) || $eventOverrides === []) {
            throw new InvalidArgumentException('Counterfactual replay requires event-scoped overrides.');
        }
        $indexById = [];
        foreach ($candidate['events'] as $index => $event) {
            if (is_string($event['event_id'] ?? null)) $indexById[$event['event_id']] = $index;
        }
        foreach ($eventOverrides as $eventId => $changes) {
            if (!is_string($eventId) || !isset($indexById[$eventId]) || !is_array($changes) || $changes === []) {
                throw new InvalidArgumentException('Counterfactual override references an unknown event or empty change set.');
            }
            foreach ($changes as $field => $value) {
                if (!is_string($field) || !in_array($field, self::COUNTERFACTUAL_FIELDS, true)) {
                    throw new InvalidArgumentException('Counterfactual override field is not allowed: ' . (string)$field);
                }
                $candidate['events'][$indexById[$eventId]][$field] = $value;
            }
            $impacted[] = $eventId;
        }
    }

    private function applyArtifactTarget(array &$candidate, string $kind, array $target, array &$impacted, array &$artifactResolution): void
    {
        $version = isset($target['version']) && is_scalar($target['version']) ? (string)$target['version'] : '';
        if ($version === '') throw new InvalidArgumentException("{$kind} comparison requires a target version.");

        $fieldMap = [
            'model' => ['model_provider','model_name','model_version'],
            'policy' => ['policy_version'],
            'knowledge' => ['knowledge_version'],
        ];
        $fields = $fieldMap[$kind];
        foreach ($candidate['events'] as $index => $event) {
            $hasBaseline = false;
            foreach ($fields as $field) if (($event[$field] ?? null) !== null) { $hasBaseline = true; break; }
            if (!$hasBaseline) continue;

            if ($kind === 'model') {
                if (isset($target['provider']) && is_scalar($target['provider'])) $candidate['events'][$index]['model_provider'] = (string)$target['provider'];
                if (isset($target['model']) && is_scalar($target['model'])) $candidate['events'][$index]['model_name'] = (string)$target['model'];
                $candidate['events'][$index]['model_version'] = $version;
            } elseif ($kind === 'policy') {
                $candidate['events'][$index]['policy_version'] = $version;
            } else {
                $candidate['events'][$index]['knowledge_version'] = $version;
            }
            if (is_string($event['event_id'] ?? null)) $impacted[] = $event['event_id'];
        }

        $context=['target'=>$target,'tenant_company_id'=>$candidate['tenant_company_id'] ?? null,'trace_id'=>$candidate['trace_id'] ?? null];
        $archived = $this->artifactArchive !== null
            ? $this->artifactArchive->resolveAndArchive($kind, $version, $context)
            : (($resolved = $this->artifacts->resolve($kind, $version, $context)) === null
                ? ['status'=>'ARTIFACT_UNAVAILABLE','artifact'=>null,'content_hash'=>null]
                : ['status'=>'RESOLVED','artifact'=>$resolved,'content_hash'=>$resolved['content_hash'] ?? null]);
        $artifactResolution[] = [
            'kind' => $kind,
            'version' => $version,
            'status' => $archived['status'] === 'ARTIFACT_UNAVAILABLE' ? 'unavailable' : 'resolved',
            'artifact' => $archived['artifact'] ?? null,
            'content_hash' => $archived['content_hash'] ?? null,
            'artifact_uuid' => $archived['artifact_uuid'] ?? null,
        ];
    }
}
