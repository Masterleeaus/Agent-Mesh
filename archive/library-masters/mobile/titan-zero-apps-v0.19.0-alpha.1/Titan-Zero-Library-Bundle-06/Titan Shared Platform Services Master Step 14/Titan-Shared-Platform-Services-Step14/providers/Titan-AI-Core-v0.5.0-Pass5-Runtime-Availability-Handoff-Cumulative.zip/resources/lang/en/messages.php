<?php

return [
    'name' => 'Titan AI Core',
    'description' => 'Governed AI execution kernel for Titan Zero.',
];
