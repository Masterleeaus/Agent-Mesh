<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Tenancy;

final class CrmCompanyContextStore
{
    /** @var list<CrmCompanyContext> */
    private array $stack = [];

    public function current(): ?CrmCompanyContext
    {
        return $this->stack === [] ? null : $this->stack[array_key_last($this->stack)];
    }

    public function push(CrmCompanyContext $context): void
    {
        $this->stack[] = $context;
    }

    public function pop(): void
    {
        array_pop($this->stack);
    }

    public function clear(): void
    {
        $this->stack = [];
    }
}
