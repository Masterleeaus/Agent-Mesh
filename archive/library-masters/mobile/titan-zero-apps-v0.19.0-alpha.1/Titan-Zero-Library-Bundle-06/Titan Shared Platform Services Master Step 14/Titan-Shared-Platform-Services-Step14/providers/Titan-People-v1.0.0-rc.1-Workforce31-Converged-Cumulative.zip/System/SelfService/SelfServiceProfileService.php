<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\SelfService;

use App\Extensions\TitanPeople\System\Contracts\PeopleIdentityPort;
use App\Extensions\TitanPeople\System\Models\EmergencyContact;
use App\Extensions\TitanPeople\System\Models\Worker;
use App\Extensions\TitanPeople\System\Models\WorkerProfile;
use Illuminate\Support\Facades\DB;

final class SelfServiceProfileService
{
    public function __construct(private readonly PeopleIdentityPort $identity, private readonly SelfServiceProfilePolicy $policy) {}

    /** @param array<string,mixed> $input */
    public function update(int $tenantCompanyId, string|int $actorSubject, array $input): void
    {
        $workerIdentity = $this->identity->resolveWorker($tenantCompanyId, $actorSubject);
        $data = $this->policy->filter($input);
        DB::transaction(function () use ($tenantCompanyId, $workerIdentity, $data): void {
            if (array_key_exists('personal_email', $data)) {
                Worker::query()->where('tenant_company_id', $tenantCompanyId)->whereKey($workerIdentity->workerId)->update(['personal_email'=>$data['personal_email']]);
            }
            $profileData = array_intersect_key($data, array_flip(['personal_phone','timezone','locale']));
            if (array_key_exists('home_address', $data)) $profileData['home_address_json'] = $data['home_address'];
            if ($profileData !== []) {
                WorkerProfile::query()->updateOrCreate(
                    ['tenant_company_id'=>$tenantCompanyId,'worker_id'=>$workerIdentity->workerId],
                    $profileData,
                );
            }
            if (array_key_exists('emergency_contacts', $data) && is_array($data['emergency_contacts'])) {
                EmergencyContact::query()->where('tenant_company_id', $tenantCompanyId)->where('worker_id', $workerIdentity->workerId)->delete();
                foreach (array_slice($data['emergency_contacts'], 0, 10) as $index => $contact) {
                    if (! is_array($contact) || trim((string) ($contact['name'] ?? '')) === '' || trim((string) ($contact['phone'] ?? '')) === '') continue;
                    $row = new EmergencyContact();
                    $row->setAttribute('tenant_company_id', $tenantCompanyId);
                    $row->fill([
                        'worker_id'=>$workerIdentity->workerId,
                        'name'=>trim((string) $contact['name']),
                        'relationship'=>trim((string) ($contact['relationship'] ?? '')) ?: null,
                        'phone'=>trim((string) $contact['phone']),
                        'email'=>trim((string) ($contact['email'] ?? '')) ?: null,
                        'priority'=>$index + 1,
                    ]);
                    $row->save();
                }
            }
        });
    }
}
