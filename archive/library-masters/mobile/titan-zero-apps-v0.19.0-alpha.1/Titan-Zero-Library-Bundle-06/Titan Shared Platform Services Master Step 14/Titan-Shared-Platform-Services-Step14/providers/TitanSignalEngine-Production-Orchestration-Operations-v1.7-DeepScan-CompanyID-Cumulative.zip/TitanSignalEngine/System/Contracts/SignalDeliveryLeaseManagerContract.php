<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryLease;
use DateTimeInterface;

interface SignalDeliveryLeaseManagerContract
{
    public function newExecutionToken(): string;

    public function claim(string $deliveryId, string $executionToken, string $workerId, int $ttlSeconds): ?SignalDeliveryLease;

    public function markDelivered(SignalDeliveryLease $lease): bool;

    public function markRetry(
        SignalDeliveryLease $lease,
        DateTimeInterface $availableAt,
        ?string $errorClass = null,
        ?string $errorReference = null,
    ): bool;

    public function markDeadLetter(
        SignalDeliveryLease $lease,
        string $errorClass,
        string $errorReference,
    ): bool;

    public function releaseExpired(string $deliveryId): bool;
}
