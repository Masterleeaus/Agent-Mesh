<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

use App\Extensions\Crm\System\Tenancy\CrmCompanyContext;
use Illuminate\Support\Str;

final class CrmCommandReceiptFactory
{
    /** @param array<string,mixed> $metrics @return array<string,mixed> */
    public function make(string $capability,array $input,array $result,CrmCompanyContext $context,?array $before,?array $after,array $metrics=[]): array
    {
        $receiptId=(string)Str::ulid();
        $commandId=trim((string)($input['_context']['command_id']??$input['command_id']??''));
        if($commandId==='')$commandId=(string)Str::uuid();
        $traceId=trim((string)($input['_context']['trace_id']??''));if($traceId==='')$traceId=$context->traceId!==''?$context->traceId:$context->correlationId;
        $correlationId=trim((string)($input['_context']['correlation_id']??''));if($correlationId==='')$correlationId=$context->correlationId;
        $causationId=trim((string)($input['_context']['causation_id']??''));if($causationId==='')$causationId=$context->causationId;
        $resourceType=(string)($after['type']??$before['type']??$input['resource_type']??'');
        $resourceId=(string)($after['public_id']??$before['public_id']??$result['public_id']??$this->nestedPublicId($result));
        $effect=(array)($result['delivery']??$result);
        $outboxPublicId=(string)($result['outbox_public_id']??$effect['outbox_public_id']??'');
        $effectStatus=$outboxPublicId!==''?(string)($result['effect_status']??$effect['effect_status']??'queued'):null;
        $deliveryReceiptRequired=$outboxPublicId!==''?(bool)($result['delivery_receipt_required']??$effect['delivery_receipt_required']??true):false;
        $duration=max(0,(int)($metrics['command_duration_ms']??0));
        $affectedResources=$this->affectedResources($result,$resourceType,$resourceId,$after);
        $affected=max(0,(int)($metrics['affected_count']??count($affectedResources)?:$this->affectedCount($result,$resourceId)));
        $versionHint=$after['entity_version']??null;
        $expected=$input['expected_entity_version']??$input['expected_version']??$input['_context']['expected_entity_version']??$input['_context']['expected_version']??null;
        $expected=is_numeric($expected)?(int)$expected:null;
        $invariantResults=array_values((array)($metrics['invariant_results']??[['name'=>'crm.domain.preconditions','status'=>'passed']]));
        $signalReferences=array_values((array)($metrics['signal_references']??[]));
        $externalEffectReferences=$outboxPublicId!==''?[[
            'owner'=>'titan_connect','outbox_public_id'=>$outboxPublicId,'effect_status'=>$effectStatus,
            'delivery_receipt_required'=>$deliveryReceiptRequired,
        ]]:array_values((array)($metrics['external_effect_references']??[]));
        $compensationState=(string)($metrics['compensation_state']??($externalEffectReferences!==[]?CrmCommandContract::COMPENSATION_EXTERNAL:CrmCommandContract::COMPENSATION_AVAILABLE));
        $remediation=(string)($metrics['remediation_suggestion']??'Use the Rewind reference for governed correction; never mutate authoritative CRM state outside Command Bus.');

        $rewind=[
            'receipt_id'=>$receiptId,'command_id'=>$commandId,'company_id'=>$context->companyId,
            'capability'=>$capability,'resource_type'=>$resourceType?:null,'resource_id'=>$resourceId?:null,
            'affected_resources'=>$affectedResources,
            'entity_version_before'=>$before['entity_version']??null,'entity_version_after'=>$after['entity_version']??null,
            'before_state_hash'=>$before['state_hash']??null,'after_state_hash'=>$after['state_hash']??null,
            'trace_id'=>$traceId,'correlation_id'=>$correlationId,'causation_id'=>$causationId,
            'signal_references'=>$signalReferences,'compensation_state'=>$compensationState,
            'external_effect'=>$externalEffectReferences[0]??null,
        ];
        $receipt=[
            'command_contract_version'=>CrmCommandContract::VERSION,
            'receipt_id'=>$receiptId,'command_id'=>$commandId,'status'=>'executed','authoritative'=>true,
            'company_id'=>$context->companyId,
            'actor'=>['user_id'=>$context->actorUserId,'type'=>$context->actorType,'source_surface'=>$context->sourceSurface],
            'capability'=>$capability,'idempotency_key'=>$input['idempotency_key']??$input['_context']['idempotency_key']??null,
            'expected_entity_version'=>$expected,
            'resource_type'=>$resourceType?:null,'resource_id'=>$resourceId?:null,
            'affected_resources'=>$affectedResources,
            'entity_version_before'=>$before['entity_version']??null,'entity_version_after'=>$after['entity_version']??null,
            'version_hint'=>$versionHint,'before_state_hash'=>$before['state_hash']??null,'after_state_hash'=>$after['state_hash']??null,
            'invariant_results'=>$invariantResults,
            'command_duration_ms'=>$duration,'affected_count'=>$affected,
            'trace_id'=>$traceId,'correlation_id'=>$correlationId,'causation_id'=>$causationId,
            'signal_references'=>$signalReferences,
            'external_effect_references'=>$externalEffectReferences,
            'outbox_public_id'=>$outboxPublicId!==''?$outboxPublicId:null,'effect_status'=>$effectStatus,
            'delivery_receipt_required'=>$deliveryReceiptRequired,'real_world_outcome_validated'=>!$deliveryReceiptRequired,
            'compensation_state'=>$compensationState,'remediation_suggestion'=>$remediation,
            'rewind_reference'=>$rewind,
        ];
        $receipt['receipt_integrity_hash']=$this->integrityHash($receipt);
        $receipt['rewind_reference']['receipt_integrity_hash']=$receipt['receipt_integrity_hash'];
        return $receipt;
    }

    private function affectedCount(array $result,string $resourceId): int
    {
        if(isset($result['affected_count'])&&is_numeric($result['affected_count']))return (int)$result['affected_count'];
        foreach(['created_count','updated_count','deleted_count','accepted_rows','created_rows'] as $key)if(isset($result[$key])&&is_numeric($result[$key]))return (int)$result[$key];
        return $resourceId!==''?1:($result!==[]?1:0);
    }

    /** @return list<array<string,mixed>> */
    private function affectedResources(array $result,string $resourceType,string $resourceId,?array $after): array
    {
        $resources=[];
        if($resourceId!=='')$resources[]=['type'=>$resourceType?:null,'public_id'=>$resourceId,'entity_version'=>$after['entity_version']??null];
        foreach((array)($result['affected_resources']??[]) as $resource){
            if(!is_array($resource))continue;
            $id=trim((string)($resource['public_id']??$resource['resource_id']??''));if($id==='')continue;
            $resources[]=['type'=>$resource['type']??$resource['resource_type']??null,'public_id'=>$id,'entity_version'=>$resource['entity_version']??null];
        }
        $seen=[];$out=[];
        foreach($resources as $resource){$key=(string)($resource['type']??'').'|'.(string)$resource['public_id'];if(isset($seen[$key]))continue;$seen[$key]=true;$out[]=$resource;}
        return $out;
    }

    private function nestedPublicId(array $result): string
    {
        foreach(['invoice','credit_note','contact','company','lead','deal','task','project'] as $key){
            if(isset($result[$key])&&is_array($result[$key])&&!empty($result[$key]['public_id']))return (string)$result[$key]['public_id'];
        }
        return '';
    }
    private function integrityHash(array $receipt): string
    {
        unset($receipt['receipt_integrity_hash']);
        $normalise=function(mixed $value)use(&$normalise):mixed{if(!is_array($value))return $value;if(array_is_list($value))return array_map($normalise,$value);ksort($value);foreach($value as $k=>$v)$value[$k]=$normalise($v);return $value;};
        return hash('sha256',json_encode($normalise($receipt),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
    }
}
