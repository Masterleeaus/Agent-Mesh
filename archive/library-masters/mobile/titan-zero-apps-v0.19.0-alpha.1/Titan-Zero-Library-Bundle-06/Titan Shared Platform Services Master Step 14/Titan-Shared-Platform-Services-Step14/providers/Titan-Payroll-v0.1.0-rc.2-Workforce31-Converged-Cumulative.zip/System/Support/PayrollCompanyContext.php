<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Support;

use RuntimeException;

final class PayrollCompanyContext
{
    private const CRM_SCOPE = 'App\\Extensions\\Crm\\System\\Tenancy\\CrmCompanyScope';

    public static function id(object $user): int
    {
        $value = (int) self::attribute($user, 'tenant_company_id');
        if ($value > 0) return $value;

        if (class_exists(self::CRM_SCOPE) && function_exists('app') && app()->bound(self::CRM_SCOPE)) {
            $actorId = (int) (method_exists($user, 'getKey') ? $user->getKey() : ($user->id ?? 0));
            $scope = self::CRM_SCOPE;
            $resolved = (int) $scope::tenantCompanyId($actorId > 0 ? $actorId : null);
            if ($resolved > 0) return $resolved;
        }
        throw new RuntimeException('Titan Payroll requires canonical tenant_company_id on the authorised actor context.');
    }

    public static function assertMatches(int $tenantCompanyId, object $user): void
    {
        if ($tenantCompanyId < 1 || $tenantCompanyId !== self::id($user)) {
            throw new RuntimeException('Titan Payroll tenant boundary mismatch.');
        }
    }

    private static function attribute(object $user, string $key): mixed
    {
        return method_exists($user, 'getAttribute') ? $user->getAttribute($key) : ($user->{$key} ?? null);
    }
}
