# Governance

Intelligence is not authority. Effective authority remains external to Titan AI and consequential work must fail closed when required governance is unavailable.
