<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Services;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Contracts\GovernanceGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;

final class GovernanceGateway extends AbstractEngineGateway implements GovernanceGatewayContract
{
    public function engine(): EngineKey { return EngineKey::Governance; }

    public function evaluate(TraceContext $trace, array $subject, string $operationId): EngineGatewayResult
    {
        return $this->dispatch($trace, 'governance.evaluate', ['subject' => $subject], $operationId);
    }
}
