<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Contracts;

interface EngineGatewayCatalogContract
{
    /** @return array<string,array<string,mixed>> */
    public function snapshot(): array;

    public function allRequiredForExecutionAvailable(): bool;
}
