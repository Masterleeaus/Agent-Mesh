<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Providers;

use App\Extensions\TitanConnect\System\Contracts\MobilePushGateway;
use App\Extensions\TitanConnect\System\Contracts\ProviderHttpClient;
use App\Extensions\TitanConnect\System\DTO\NormalizedInboundMessage;
use App\Extensions\TitanConnect\System\DTO\ProviderSendResult;
use App\Extensions\TitanConnect\System\Security\NullMobilePushGateway;
use LogicException;

final class PushProvider extends AbstractMessagingProvider
{
    public function __construct(ProviderHttpClient $http, private readonly MobilePushGateway $push)
    {
        parent::__construct($http);
    }

    public function key(): string { return 'push'; }
    public function capabilities(): array { return ['notifications', 'deep_links', 'delivery_receipts']; }
    public function supportsInbound(): bool { return false; }

    public function verifyWebhook(array $headers, string $body, array $credentials): bool
    {
        return false;
    }

    public function normalizeInbound(array $payload, array $headers = []): NormalizedInboundMessage
    {
        throw new LogicException('Push provider does not accept public inbound messages.');
    }

    public function send(array $message, array $credentials): ProviderSendResult
    {
        $companyId = (int) ($message['company_id'] ?? 0);
        $recipient = $message['to'] ?? null;
        $recipientIds = is_array($recipient) ? array_values(array_filter(array_map('intval', $recipient))) : [(int) $recipient];
        $recipientIds = array_values(array_filter($recipientIds, static fn (int $id): bool => $id > 0));
        if ($companyId <= 0 || $recipientIds === []) {
            throw new \RuntimeException('Push delivery requires a company and at least one Titan user recipient ID.');
        }
        $result = $this->push->send($companyId, $recipientIds, [
            'type' => (string) data_get($message, 'metadata.type', 'titan-connect.external-message'),
            'body' => (string) ($message['body'] ?? ''),
            'thread_uuid' => (string) ($message['thread_uuid'] ?? ''),
            'correlation_id' => (string) ($message['correlation_id'] ?? ''),
            'deep_link' => data_get($message, 'metadata.deep_link'),
        ]);
        $status = strtolower((string) ($result['status'] ?? 'sent'));
        if ($status === 'not-configured') {
            throw new \RuntimeException('TitanMobileCore push gateway is not configured.');
        }
        if (! in_array($status, ['queued', 'sending', 'sent', 'delivered', 'read', 'failed'], true)) {
            throw new \RuntimeException("Mobile push gateway returned unsupported status [{$status}].");
        }
        $providerId = $result['provider_message_id'] ?? $result['id'] ?? null;
        return new ProviderSendResult($status, is_scalar($providerId) ? (string) $providerId : null, $result);
    }

    public function health(array $credentials): array
    {
        $configured = method_exists($this->push, 'configured')
            ? (bool) $this->push->configured()
            : ! ($this->push instanceof NullMobilePushGateway);
        return [
            'ok' => $configured,
            'provider' => $this->key(),
            'configured' => $configured,
            'gateway' => get_debug_type($this->push),
        ];
    }
}
