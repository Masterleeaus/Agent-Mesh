<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Services;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Enums\KnowledgeScopeType;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeScopeContext;

/**
 * Pass-2 compatibility guard.
 *
 * @deprecated Production reads must use KnowledgeScopeVisibilityPolicy with a
 * trusted KnowledgeAccessContext. Jurisdiction reads fail closed here because
 * this primitive API has no jurisdiction allowlist.
 */
final class KnowledgeScopeGuard
{
    /** @return list<string> */
    public function supportedScopes(): array
    {
        return ['platform', 'jurisdiction', 'tenant'];
    }

    public function canRead(KnowledgeScopeContext $scope, ?int $actorTenantCompanyId): bool
    {
        return match ($scope->type) {
            KnowledgeScopeType::Platform => true,
            KnowledgeScopeType::Jurisdiction => false,
            KnowledgeScopeType::Tenant => $actorTenantCompanyId !== null
                && $actorTenantCompanyId === $scope->tenantCompanyId,
        };
    }

    public function assertCanRead(KnowledgeScopeContext $scope, ?int $actorTenantCompanyId): void
    {
        if (! $this->canRead($scope, $actorTenantCompanyId)) {
            throw new \DomainException('Knowledge scope access denied.');
        }
    }
}
