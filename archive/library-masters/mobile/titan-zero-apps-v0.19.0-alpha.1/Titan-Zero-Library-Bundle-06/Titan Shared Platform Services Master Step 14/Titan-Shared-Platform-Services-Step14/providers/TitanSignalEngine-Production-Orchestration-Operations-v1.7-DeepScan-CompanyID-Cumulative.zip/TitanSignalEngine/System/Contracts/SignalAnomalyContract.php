<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use DateTimeInterface;

interface SignalAnomalyContract
{
    /** @return list<array<string,mixed>> */
    public function scan(SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT): array;

    /** @return list<array<string,mixed>> */
    public function feed(SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 100): array;

    /** @return array<string,mixed> */
    public function acknowledge(string $anomalyId, string $reason, SignalContext $context): array;

    /** @return array<string,mixed> */
    public function resolve(string $anomalyId, string $reason, SignalContext $context): array;

    /** @return array<string,mixed> */
    public function suppress(string $anomalyId, DateTimeInterface $until, string $reason, SignalContext $context): array;
}
