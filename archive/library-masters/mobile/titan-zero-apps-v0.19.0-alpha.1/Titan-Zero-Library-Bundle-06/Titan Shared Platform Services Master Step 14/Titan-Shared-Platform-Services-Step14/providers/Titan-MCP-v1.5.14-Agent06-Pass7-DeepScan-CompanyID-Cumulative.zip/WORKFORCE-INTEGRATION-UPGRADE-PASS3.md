# Agent-06 Upgrade Pass 3 — Runtime Discovery & Health

This package advances the Workforce provider contract to **v1.2**.

## Added
- company-scoped runtime provider discovery owned by Titan AI Workforce;
- non-mutating provider health probes with a five-minute freshness TTL;
- fail-closed capability availability derived from health, policy, authority and dependencies;
- deterministic duplicate-provider blocking until explicitly pinned;
- health and availability event envelopes that forbid secret material;
- explicit recovery semantics requiring a fresh health observation.

Installation alone never means available or authorized. Health never grants authority.
All new runtime scope uses `company_id`.
