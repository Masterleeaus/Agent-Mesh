# Wizard Audit — v10.3.0

Preserved source definitions: **30**. Active Field/Home Services: **13**.

| Wizard | Active | Capability | Surfaces | Roles |
|---|---:|---|---|---|
| `booking_intake_v1` | no/dormant | `hospitality.bookings.create` | dormant | staff, supervisor, manager, admin |
| `client_intake_consent_v1` | no/dormant | `care.clients.intake` | dormant | clinician, practitioner, care_worker, manager, admin |
| `complete_job_v1` | yes | `crm.work_order.complete` | go, command | field_worker, supervisor, admin, owner, manager |
| `create_invoice_v1` | yes | `crm.invoice.create` | command | finance, manager, admin, owner |
| `create_job_v1` | yes | `crm.work_order.create` | command | dispatcher, operations, admin, owner, manager |
| `create_quote_v1` | yes | `crm.quote.create` | command | estimator, sales, manager, admin, owner |
| `customer_order_capture_v1` | no/dormant | `commerce.orders.create` | dormant | staff, supervisor, manager, admin |
| `event_function_setup_v1` | no/dormant | `hospitality.events.prepare` | dormant | staff, supervisor, manager, admin |
| `field_home_services_onboarding_v1` | yes | `interaction.onboarding.compile` | onboarding | owner, admin |
| `guest_issue_resolution_v1` | no/dormant | `hospitality.guest_issues.resolve` | dormant | staff, supervisor, manager, admin |
| `incident_response_v1` | yes | `crm.form.submit` | go, command | field_worker, supervisor, manager, admin, owner |
| `inspection_corrective_action_v1` | yes | `crm.form.submit` | go, command | field_worker, supervisor, manager, admin, owner |
| `inventory_adjustment_v1` | no/dormant | `inventory.adjustments.record` | dormant | staff, supervisor, manager, admin |
| `job_variation_approval_v1` | yes | `crm.work_order.update` | go, command | supervisor, manager, admin, owner |
| `maintenance_request_v1` | no/dormant | `property.maintenance.request` | dormant | staff, supervisor, manager, admin |
| `materials_request_v1` | yes | `crm.work_order.material.add` | go, command | field_worker, supervisor, manager, admin, owner |
| `new_customer_v1` | yes | `crm.customer.create` | hub, command | customer, sales, support, admin, owner, manager |
| `order_fulfilment_v1` | no/dormant | `commerce.orders.fulfil` | dormant | staff, supervisor, manager, admin |
| `order_issue_resolution_v1` | no/dormant | `commerce.orders.resolve_issue` | dormant | staff, supervisor, manager, admin |
| `practical_completion_defects_v1` | yes | `crm.work_order.update` | go, command | field_worker, supervisor, manager, admin, owner |
| `product_catalogue_item_v1` | no/dormant | `commerce.products.upsert` | dormant | staff, supervisor, manager, admin |
| `property_onboarding_v1` | no/dormant | `property.assets.onboard` | dormant | staff, supervisor, manager, admin |
| `property_turnover_handover_v1` | no/dormant | `property.turnovers.complete` | dormant | staff, supervisor, manager, admin |
| `refund_approval_v1` | no/dormant | `commerce.refunds.approve` | dormant | staff, supervisor, manager, admin |
| `return_request_v1` | no/dormant | `commerce.returns.request` | dormant | staff, supervisor, manager, admin |
| `service_booking_v1` | yes | `crm.appointment.create` | hub, command | customer, staff, supervisor, manager, admin, owner, dispatcher |
| `site_variation_v1` | yes | `crm.work_order.update` | go, command | supervisor, manager, admin, owner |
| `stocktake_variance_v1` | no/dormant | `inventory.stocktakes.complete` | dormant | staff, supervisor, manager, admin |
| `store_stock_transfer_v1` | no/dormant | `inventory.transfers.create` | dormant | staff, supervisor, manager, admin |
| `supplier_receiving_discrepancy_v1` | no/dormant | `inventory.receipts.record` | dormant | staff, supervisor, manager, admin |
