@extends($layout)
@section('title', $state['capability'])
@section('content')
<div class="ta-card"><a href="{{ route('titan-autonomy.index') }}">← Autonomy Learning</a><h1>{{ $state['capability'] }}</h1><p class="ta-muted">Workflow: {{ $state['workflow_key'] ?: 'default' }}</p>
@if(session('titan_autonomy_status'))<div class="ta-ok">{{ session('titan_autonomy_status') }}</div>@endif
@if(session('titan_autonomy_error'))<div class="ta-error">{{ session('titan_autonomy_error') }}</div>@endif
</div>
<div class="ta-grid">
<div class="ta-card"><strong>{{ $state['current_level'] }}</strong><div class="ta-muted">Current level</div></div>
<div class="ta-card"><strong>{{ $state['next_level'] ?? '—' }}</strong><div class="ta-muted">Next gate</div></div>
<div class="ta-card"><strong>{{ $state['current_success_streak'] }} / {{ $state['required_success_streak'] }}</strong><div class="ta-muted">Qualifying streak</div></div>
<div class="ta-card"><strong>{{ $state['platform_gate_eligible'] ? 'Eligible' : 'Locked' }}</strong><div class="ta-muted">Platform gate</div></div>
<div class="ta-card"><strong>{{ $state['ai_confidence'] ?? '—' }}</strong><div class="ta-muted">AI confidence</div></div>
<div class="ta-card"><strong>{{ $state['assurance_status'] ?? '—' }}</strong><div class="ta-muted">Assurance</div></div>
</div>
<div class="ta-card"><h2>Live Assurance assessment</h2>
@if(($state['current_level'] ?? '') === 'auto' && ($state['next_level'] ?? '') === 'trusted_auto')
<p>Trusted Auto requires a completed Titan AI Assurance assessment. Requesting an assessment locks the current evidence but does not start or fabricate an AI panel and does not grant authority.</p>
<form method="post" action="{{ route('titan-autonomy.capability.request-assurance',['capability'=>$state['capability']]) }}">@csrf
<input type="hidden" name="workflow_key" value="{{ $state['workflow_key'] }}">
<label>Trusted scope to assess</label><textarea class="ta-input" name="scope">{{ json_encode($state['scope'] ?? ['workflow'=>$state['workflow_key']], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</textarea><br><br>
<button class="ta-btn secondary" type="submit" {{ $gate->eligible ? '' : 'disabled' }}>Request Assurance Assessment</button>
@if(!$gate->eligible)<div class="ta-muted">Assessment locked until platform gate passes: {{ implode(', ', $gate->reasonCodes) }}</div>@endif
</form>
@else<p class="ta-muted">A Trusted Auto assessment is requested only after this capability reaches Auto and its next gate becomes eligible.</p>@endif
</div>
<div class="ta-card"><h2>Increase authority</h2>
<p>This action grants only the <strong>server-calculated next level</strong>. It cannot skip a gate.</p>
@if($state['next_level'])
<form method="post" action="{{ route('titan-autonomy.capability.grant-next',['capability'=>$state['capability']]) }}">@csrf
<input type="hidden" name="workflow_key" value="{{ $state['workflow_key'] }}">
<label>Bounded scope (JSON; required from Semi-Auto upward)</label>
<textarea class="ta-input" name="scope">{{ json_encode($state['scope'] ?? ['workflow'=>$state['workflow_key']], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</textarea><br><br>
<button class="ta-btn" type="submit" {{ $gate->eligible ? '' : 'disabled' }}>Enable {{ $state['next_level'] }}</button>
@if(!$gate->eligible)<div class="ta-muted">Locked: {{ implode(', ', $gate->reasonCodes) }}</div>@endif
</form>@else<p class="ta-muted">This capability is already at its maximum recorded level.</p>@endif
</div>
<div class="ta-card"><h2>Reduce or reset</h2>
<form class="inline" method="post" action="{{ route('titan-autonomy.capability.lower',['capability'=>$state['capability']]) }}">@csrf<input type="hidden" name="workflow_key" value="{{ $state['workflow_key'] }}"><select name="target_level" class="ta-input" style="width:auto"><option>suggest</option><option>assist</option><option>semi_auto</option><option>auto</option></select> <button class="ta-btn secondary">Lower autonomy</button></form>
<form method="post" action="{{ route('titan-autonomy.capability.reset-learning',['capability'=>$state['capability']]) }}" style="margin-top:12px">@csrf<input type="hidden" name="workflow_key" value="{{ $state['workflow_key'] }}"><input type="hidden" name="target_level" value="suggest"><label><input type="checkbox" name="confirmed" value="1" required> I understand this clears capability learning evidence and may reduce autonomy.</label> <button class="ta-btn danger">Reset training</button></form>
</div>
<div class="ta-card"><h2>Current scope</h2><pre>{{ json_encode($state['scope'] ?? [], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div>
<div class="ta-card"><h2>Recent learning</h2><table class="ta-table"><thead><tr><th>When</th><th>Label</th><th>Level</th><th>Confidence</th></tr></thead><tbody>@forelse($events as $event)<tr><td>{{ $event['created_at'] ?? '' }}</td><td>{{ $event['learning_label'] }}</td><td>{{ $event['autonomy_level'] }}</td><td>{{ $event['confidence'] ?? '—' }}</td></tr>@empty<tr><td colspan="4">No events.</td></tr>@endforelse</tbody></table></div>
<div class="ta-card"><h2>Trusted Auto handshakes</h2><table class="ta-table"><thead><tr><th>When</th><th>Platform</th><th>User</th><th>Titan/Assurance</th><th>Final</th></tr></thead><tbody>@forelse($handshakes as $h)<tr><td>{{ $h['created_at'] ?? '' }}</td><td>{{ $h['platform_decision'] }}</td><td>{{ $h['user_decision'] }}</td><td>{{ $h['ai_decision'] }} {{ $h['ai_confidence'] ?? '' }}</td><td>{{ $h['final_decision'] }}</td></tr>@empty<tr><td colspan="5">No handshakes.</td></tr>@endforelse</tbody></table></div>
<div class="ta-card"><h2>Regression history</h2><table class="ta-table"><thead><tr><th>When</th><th>From</th><th>To</th><th>Cause</th></tr></thead><tbody>@forelse($regressions as $r)<tr><td>{{ $r['created_at'] ?? '' }}</td><td>{{ $r['prior_level'] }}</td><td>{{ $r['new_level'] }}</td><td>{{ $r['cause'] }}</td></tr>@empty<tr><td colspan="4">No regressions.</td></tr>@endforelse</tbody></table></div>
@endsection
