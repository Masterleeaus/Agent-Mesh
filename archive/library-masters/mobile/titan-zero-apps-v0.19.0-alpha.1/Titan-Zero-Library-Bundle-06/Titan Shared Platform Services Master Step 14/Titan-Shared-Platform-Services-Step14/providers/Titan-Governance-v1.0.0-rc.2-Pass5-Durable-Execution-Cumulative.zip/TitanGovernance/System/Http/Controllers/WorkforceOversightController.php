<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Http\Controllers;

use App\Extensions\TitanGovernance\System\Context\TenantCompanyResolver;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceManagerContract;
use App\Extensions\TitanGovernance\System\Host\TitanHostAuthorizationAdapter;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

final class WorkforceOversightController
{
    public function __construct(
        private readonly GovernanceManagerContract $governance,
        private readonly TenantCompanyResolver $tenants,
        private readonly TitanHostAuthorizationAdapter $authorization,
    ) {}

    public function __invoke(Request $request):View
    {
        $user=$request->user();
        abort_unless($user&&$this->authorization->allows($user,'titan-governance.view',['titan-governance.view']),403);
        $tenantCompanyId=$this->tenants->resolve($user);
        return view('titan-governance::workforce',[
            'tenantCompanyId'=>$tenantCompanyId,
            'oversight'=>$this->governance->workforceOversight($tenantCompanyId),
            'focusType'=>trim((string)$request->query('focus_type','')),
            'focusId'=>trim((string)$request->query('focus_id','')),
        ]);
    }
}
