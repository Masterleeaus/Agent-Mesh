<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalTraceEvaluation extends Model
{
    protected $table = 'titan_signal_trace_evaluations';
    protected $guarded = [];
    protected $casts = [
        'tenant_company_id' => 'integer',
        'tenant_key' => 'integer',
        'profile_version' => 'integer',
        'event_count' => 'integer',
        'sequence_violation_count' => 'integer',
        'missing_event_count' => 'integer',
        'missing_parent_count' => 'integer',
        'causal_cycle_count' => 'integer',
        'profile_violation_count' => 'integer',
        'terminal_seen' => 'boolean',
        'history_complete' => 'boolean',
        'cold_history_complete' => 'boolean',
        'evaluation_generation' => 'integer',
        'evaluated_at' => 'immutable_datetime',
        'fresh_until' => 'immutable_datetime',
        'last_event_at' => 'immutable_datetime',
    ];
}
