<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_type_versions')) {
            Schema::create('titan_signal_type_versions', function (Blueprint $table): void {
                $table->id();
                $table->string('event_type', 160);
                $table->unsignedInteger('definition_version');
                $table->unsignedInteger('current_schema_version')->default(1);
                $table->json('supported_schema_versions');
                $table->string('category', 80)->nullable()->index();
                $table->json('allowed_scopes');
                $table->json('required_payload_fields')->nullable();
                $table->json('optional_payload_fields')->nullable();
                $table->boolean('allow_additional_payload_fields')->default(true);
                $table->string('owner_source', 120)->nullable()->index();
                $table->string('owner_service_id', 180)->index();
                $table->string('registrar_service_id', 180)->index();
                $table->json('allowed_severities')->nullable();
                $table->string('status', 20)->default('active')->index();
                $table->string('replacement_event_type', 160)->nullable();
                $table->string('registration_checksum', 64);
                $table->dateTime('registered_at');
                $table->timestamps();
                $table->unique(['event_type', 'definition_version'], 'tstv_event_version_uq');
                $table->index(['event_type', 'definition_version', 'status'], 'tstv_event_latest_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_subscription_versions')) {
            Schema::create('titan_signal_subscription_versions', function (Blueprint $table): void {
                $table->id();
                $table->string('subscriber_key', 160);
                $table->unsignedInteger('definition_version');
                $table->string('handler_class', 255);
                $table->json('event_patterns');
                $table->json('accepted_schema_versions');
                $table->json('scopes');
                $table->json('categories')->nullable();
                $table->json('verticals')->nullable();
                $table->string('queue', 120)->default('titan-signal-engine');
                $table->unsignedSmallInteger('max_attempts')->default(5);
                $table->json('backoff_seconds');
                $table->unsignedSmallInteger('timeout_seconds')->default(30);
                $table->string('status', 20)->default('active');
                $table->string('owner_source', 120)->nullable()->index();
                $table->string('owner_service_id', 180)->index();
                $table->string('registrar_service_id', 180)->index();
                $table->string('registration_checksum', 64);
                $table->dateTime('registered_at');
                $table->timestamps();
                $table->unique(['subscriber_key', 'definition_version'], 'tssv_key_version_uq');
                $table->index(['subscriber_key', 'definition_version', 'status'], 'tssv_key_latest_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_subscription_runtime')) {
            Schema::create('titan_signal_subscription_runtime', function (Blueprint $table): void {
                $table->id();
                $table->string('subscriber_key', 160)->unique('tssr_subscriber_uq');
                $table->unsignedInteger('active_definition_version');
                $table->string('runtime_status', 24)->default('active')->index();
                $table->string('lifecycle_status', 24)->default('installed')->index();
                $table->string('quarantine_reason_code', 80)->nullable();
                $table->string('quarantine_detail_hash', 64)->nullable();
                $table->timestamp('quarantined_at')->nullable();
                $table->timestamp('last_validated_at')->nullable();
                $table->timestamps();
                $table->index(['runtime_status', 'lifecycle_status'], 'tssr_runtime_lifecycle_idx');
            });
        }

        $this->backfillEventTypes();
        $this->seedPackageEventTypes();
        $this->backfillSubscriptions();
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_subscription_runtime');
        Schema::dropIfExists('titan_signal_subscription_versions');
        Schema::dropIfExists('titan_signal_type_versions');
    }

    private function backfillEventTypes(): void
    {
        if (! Schema::hasTable('titan_signal_types') || ! Schema::hasTable('titan_signal_type_versions')) return;
        if (DB::table('titan_signal_type_versions')->exists()) return;

        DB::table('titan_signal_types')->orderBy('id')->chunkById(250, function ($rows): void {
            foreach ($rows as $row) {
                $ownerSource = $row->owner_source === null ? null : (string) $row->owner_source;
                $payload = [
                    'event_type' => (string) $row->event_type,
                    'definition_version' => 1,
                    'current_schema_version' => (int) $row->current_schema_version,
                    'supported_schema_versions' => $row->supported_schema_versions,
                    'category' => $row->category,
                    'allowed_scopes' => $row->allowed_scopes,
                    'required_payload_fields' => $row->required_payload_fields,
                    'optional_payload_fields' => $row->optional_payload_fields,
                    'allow_additional_payload_fields' => (bool) $row->allow_additional_payload_fields,
                    'owner_source' => $ownerSource,
                    'owner_service_id' => 'legacy:' . ($ownerSource ?: 'unowned'),
                    'registrar_service_id' => 'migration:v0.10.0',
                    'allowed_severities' => $row->allowed_severities,
                    'status' => (string) $row->status,
                    'replacement_event_type' => $row->replacement_event_type,
                    'registered_at' => $row->created_at ?? now(),
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
                $payload['registration_checksum'] = self::checksum($payload);
                DB::table('titan_signal_type_versions')->insertOrIgnore($payload);
            }
        }, 'id');
    }

    private function seedPackageEventTypes(): void
    {
        if (! Schema::hasTable('titan_signal_type_versions')) return;

        $definitions = [
            'signal.engine.started' => [
                'current_schema_version' => 1,
                'supported_schema_versions' => [1],
                'category' => 'system',
                'allowed_scopes' => ['system'],
                'required_payload_fields' => [],
                'optional_payload_fields' => ['version'],
                'allow_additional_payload_fields' => false,
                'allowed_severities' => ['info'],
                'status' => 'active',
                'replacement_event_type' => null,
            ],
            'signal.security.context_rejected' => [
                'current_schema_version' => 1,
                'supported_schema_versions' => [1],
                'category' => 'security',
                'allowed_scopes' => ['system'],
                'required_payload_fields' => ['reason'],
                'optional_payload_fields' => ['source_component'],
                'allow_additional_payload_fields' => false,
                'allowed_severities' => ['warn', 'error'],
                'status' => 'active',
                'replacement_event_type' => null,
            ],
            'signal.subscription.failed' => [
                'current_schema_version' => 1,
                'supported_schema_versions' => [1],
                'category' => 'operations',
                'allowed_scopes' => ['tenant', 'system'],
                'required_payload_fields' => ['delivery_id', 'event_id', 'subscriber_key', 'attempt_count', 'error_class'],
                'optional_payload_fields' => [],
                'allow_additional_payload_fields' => false,
                'allowed_severities' => ['error', 'critical'],
                'status' => 'active',
                'replacement_event_type' => null,
            ],
            'signal.anomaly.detected' => [
                'current_schema_version' => 1,
                'supported_schema_versions' => [1],
                'category' => 'operations',
                'allowed_scopes' => ['tenant', 'system'],
                'required_payload_fields' => ['anomaly_id', 'anomaly_type', 'severity', 'score', 'confidence', 'subject_type', 'subject_id'],
                'optional_payload_fields' => [],
                'allow_additional_payload_fields' => false,
                'allowed_severities' => ['info'],
                'status' => 'active',
                'replacement_event_type' => null,
            ],
        ];

        foreach ($definitions as $eventType => $definition) {
            if (DB::table('titan_signal_type_versions')->where('event_type', $eventType)->exists()) continue;
            $payload = [
                'event_type' => $eventType,
                'definition_version' => 1,
                'current_schema_version' => $definition['current_schema_version'],
                'supported_schema_versions' => json_encode($definition['supported_schema_versions'], JSON_THROW_ON_ERROR),
                'category' => $definition['category'],
                'allowed_scopes' => json_encode($definition['allowed_scopes'], JSON_THROW_ON_ERROR),
                'required_payload_fields' => json_encode($definition['required_payload_fields'], JSON_THROW_ON_ERROR),
                'optional_payload_fields' => json_encode($definition['optional_payload_fields'], JSON_THROW_ON_ERROR),
                'allow_additional_payload_fields' => $definition['allow_additional_payload_fields'],
                'owner_source' => 'titan-signal-engine',
                'owner_service_id' => 'package:titan-signal-engine',
                'registrar_service_id' => 'migration:v0.10.0',
                'allowed_severities' => json_encode($definition['allowed_severities'], JSON_THROW_ON_ERROR),
                'status' => $definition['status'],
                'replacement_event_type' => $definition['replacement_event_type'],
                'registered_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ];
            $payload['registration_checksum'] = self::checksum($payload);
            DB::table('titan_signal_type_versions')->insertOrIgnore($payload);
        }
    }

    private function backfillSubscriptions(): void
    {
        if (! Schema::hasTable('titan_signal_subscriptions') || ! Schema::hasTable('titan_signal_subscription_versions')) return;
        if (DB::table('titan_signal_subscription_versions')->exists()) return;

        DB::table('titan_signal_subscriptions')->orderBy('id')->chunkById(250, function ($rows): void {
            foreach ($rows as $row) {
                $subscriberKey = (string) $row->subscriber_key;
                $payload = [
                    'subscriber_key' => $subscriberKey,
                    'definition_version' => 1,
                    'handler_class' => (string) $row->handler_class,
                    'event_patterns' => $row->event_patterns,
                    'accepted_schema_versions' => $row->accepted_schema_versions,
                    'scopes' => $row->scopes,
                    'categories' => $row->categories,
                    'verticals' => $row->verticals,
                    'queue' => (string) $row->queue,
                    'max_attempts' => (int) $row->max_attempts,
                    'backoff_seconds' => $row->backoff_seconds,
                    'timeout_seconds' => (int) $row->timeout_seconds,
                    'status' => (string) $row->status,
                    'owner_source' => null,
                    'owner_service_id' => 'legacy:' . $subscriberKey,
                    'registrar_service_id' => 'migration:v0.10.0',
                    'registered_at' => $row->created_at ?? now(),
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
                $payload['registration_checksum'] = self::checksum($payload);
                DB::table('titan_signal_subscription_versions')->insertOrIgnore($payload);

                DB::table('titan_signal_subscription_runtime')->updateOrInsert(
                    ['subscriber_key' => $subscriberKey],
                    [
                        'active_definition_version' => 1,
                        'runtime_status' => in_array((string) $row->status, ['active', 'paused', 'disabled'], true) ? (string) $row->status : 'disabled',
                        'lifecycle_status' => 'installed',
                        'last_validated_at' => null,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ],
                );
            }
        }, 'id');
    }

    /** @param array<string,mixed> $payload */
    private static function checksum(array $payload): string
    {
        unset($payload['created_at'], $payload['updated_at']);
        ksort($payload);
        return hash('sha256', json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }
};
