<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterAuthorityContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Models\SignalDelivery;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use Illuminate\Support\Facades\Log;
use Throwable;

final class SignalSubscriptionFailureReporter
{
    public function __construct(
        private readonly SignalEmitterContract $emitter,
        private readonly SignalEmitterAuthorityContract $emitterAuthority,
    ) {
    }

    public function report(SignalDelivery $delivery, string $errorClass): void
    {
        try {
            /** @var SignalEvent|null $sourceEvent */
            $sourceEvent = SignalEvent::query()->where('event_id', $delivery->event_id)->first();
            if ($sourceEvent === null) {
                return;
            }

            $context = SignalContext::system(
                'titan-signal-engine:delivery',
                'system',
                ['signal.tenant.emit'],
                $this->emitterAuthority->issue('titan-signal-engine:subscription-dispatcher'),
            );

            $this->emitter->emit([
                'event_type' => 'signal.subscription.failed',
                'scope' => (string) $delivery->scope,
                'tenant_company_id' => $delivery->tenant_company_id,
                'trace_id' => (string) $sourceEvent->trace_id,
                'correlation_id' => (string) $sourceEvent->correlation_id,
                'causation_id' => (string) $sourceEvent->event_id,
                'root_causation_id' => (string) ($sourceEvent->root_causation_id ?: $sourceEvent->event_id),
                'source' => 'titan-signal-engine',
                'source_component' => 'subscription-dispatcher',
                'schema_version' => 1,
                'severity' => 'error',
                'category' => 'operations',
                'vertical_key' => $sourceEvent->vertical_key,
                'idempotency_key' => 'dead-letter:' . $delivery->delivery_id . ':r' . (int) ($delivery->redrive_count ?? 0) . ':a' . $delivery->attempt_count,
                'payload' => [
                    'delivery_id' => (string) $delivery->delivery_id,
                    'event_id' => (string) $delivery->event_id,
                    'subscriber_key' => (string) $delivery->subscriber_key,
                    'attempt_count' => (int) $delivery->attempt_count,
                    'error_class' => $errorClass,
                ],
            ], $context);
        } catch (Throwable $exception) {
            Log::error('signal.subscription_failure_report_failed', [
                'delivery_id' => $delivery->delivery_id,
                'error_class' => $exception::class,
            ]);
        }
    }
}
