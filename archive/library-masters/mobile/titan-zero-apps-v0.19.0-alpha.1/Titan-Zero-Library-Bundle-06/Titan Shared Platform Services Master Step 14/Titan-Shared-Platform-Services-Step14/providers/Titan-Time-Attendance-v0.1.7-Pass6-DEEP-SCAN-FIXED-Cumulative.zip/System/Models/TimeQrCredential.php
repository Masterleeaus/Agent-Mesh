<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;
use Illuminate\Database\Eloquent\Builder; use Illuminate\Database\Eloquent\Model;
final class TimeQrCredential extends Model
{
 protected $table='ext_titan_time_qr_credentials';
 protected $fillable=['tenant_company_id','site_id','service_location_public_id','mode','token_hash','valid_from','valid_until','active'];
 protected $casts=['valid_from'=>'datetime','valid_until'=>'datetime','active'=>'boolean'];
 public function scopeForCompany(Builder $query,int $tenantCompanyId): Builder{return $query->where('tenant_company_id',$tenantCompanyId);}
}
