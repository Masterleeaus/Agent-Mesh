<?php

declare(strict_types=1);

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
$requiredFiles = [
    '/System/Domain/ProvisioningReceiptStatus.php',
    '/System/Domain/ProvisioningPlanStatus.php',
    '/System/Domain/ProvisioningOperation.php',
    '/System/Domain/ProvisioningReceipt.php',
    '/System/Domain/ProvisioningPlan.php',
    '/System/Contracts/ProvisioningPlannerContract.php',
    '/System/Contracts/ProvisioningCommandGatewayContract.php',
    '/System/Contracts/ProvisioningExecutorContract.php',
    '/System/Adapters/CommandBus/CommandBusProvisioningAdapter.php',
    '/System/Services/DeterministicProvisioningPlanner.php',
    '/System/Domain/ProvisioningExecutionContext.php',
    '/System/Domain/RiskDecision.php',
    '/System/Domain/GovernanceDecision.php',
    '/System/Domain/AutonomyDecision.php',
    '/System/Domain/AssuranceDecision.php',
    '/System/Contracts/RiskGatewayContract.php',
    '/System/Contracts/GovernanceGatewayContract.php',
    '/System/Contracts/AutonomyGatewayContract.php',
    '/System/Contracts/AssuranceGatewayContract.php',
    '/System/Contracts/SignalGatewayContract.php',
    '/System/Contracts/RewindGatewayContract.php',
    '/System/Adapters/Governance/RiskEngineAdapter.php',
    '/System/Adapters/Governance/GovernanceEngineAdapter.php',
    '/System/Adapters/Governance/AutonomyEngineAdapter.php',
    '/System/Adapters/Governance/AssuranceEngineAdapter.php',
    '/System/Adapters/Observability/SignalEngineAdapter.php',
    '/System/Adapters/Observability/RewindEngineAdapter.php',
    '/System/Services/GovernedProvisioningExecutor.php',
];
foreach ($requiredFiles as $file) {
    if (!is_file($root . $file)) {
        fwrite(STDERR, "FAIL: missing Pass 5 production file {$file}\n");
        exit(1);
    }
}

foreach ([
    '/System/Support/CanonicalJson.php',
    '/System/Support/DeterministicMerge.php',
    '/System/Domain/CompilationStatus.php',
    '/System/Domain/ValidationSeverity.php',
    '/System/Domain/ValidationFinding.php',
    '/System/Domain/ValidationResult.php',
    '/System/Domain/ValueObjects/TraceContext.php',
    '/System/Domain/BusinessProfile.php',
    '/System/Domain/CompiledTitanConfig.php',
    '/System/Domain/SemanticChangeKind.php',
    '/System/Domain/SemanticChangeDisposition.php',
    '/System/Domain/SemanticDiffEntry.php',
    '/System/Domain/ConfigurationDiff.php',
    '/System/Domain/ProvisioningReceiptStatus.php',
    '/System/Domain/ProvisioningPlanStatus.php',
    '/System/Domain/ProvisioningOperation.php',
    '/System/Domain/ProvisioningReceipt.php',
    '/System/Domain/ProvisioningPlan.php',
    '/System/Domain/VerticalDefinition.php',
    '/System/Domain/NexusCompilation.php',
    '/System/Contracts/ProvisioningPlannerContract.php',
    '/System/Contracts/ProvisioningCommandGatewayContract.php',
    '/System/Contracts/ProvisioningExecutorContract.php',
    '/System/Domain/ProvisioningExecutionContext.php',
    '/System/Domain/RiskDecision.php',
    '/System/Domain/GovernanceDecision.php',
    '/System/Domain/AutonomyDecision.php',
    '/System/Domain/AssuranceDecision.php',
    '/System/Contracts/RiskGatewayContract.php',
    '/System/Contracts/GovernanceGatewayContract.php',
    '/System/Contracts/AutonomyGatewayContract.php',
    '/System/Contracts/AssuranceGatewayContract.php',
    '/System/Contracts/SignalGatewayContract.php',
    '/System/Contracts/RewindGatewayContract.php',
    '/System/Adapters/CommandBus/CommandBusProvisioningAdapter.php',
    '/System/Adapters/Governance/RiskEngineAdapter.php',
    '/System/Adapters/Governance/GovernanceEngineAdapter.php',
    '/System/Adapters/Governance/AutonomyEngineAdapter.php',
    '/System/Adapters/Governance/AssuranceEngineAdapter.php',
    '/System/Adapters/Observability/SignalEngineAdapter.php',
    '/System/Adapters/Observability/RewindEngineAdapter.php',
    '/System/Services/DeterministicProvisioningPlanner.php',
    '/System/Services/GovernedProvisioningExecutor.php',
] as $file) {
    require_once $root . $file;
}

use App\Extensions\TitanNexus\System\Adapters\CommandBus\CommandBusProvisioningAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\RiskEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\GovernanceEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\AutonomyEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\AssuranceEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Observability\SignalEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Observability\RewindEngineAdapter;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompiledTitanConfig;
use App\Extensions\TitanNexus\System\Domain\ConfigurationDiff;
use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlan;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlanStatus;
use App\Extensions\TitanNexus\System\Domain\ProvisioningReceiptStatus;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeDisposition;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeKind;
use App\Extensions\TitanNexus\System\Domain\SemanticDiffEntry;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Services\DeterministicProvisioningPlanner;
use App\Extensions\TitanNexus\System\Services\GovernedProvisioningExecutor;

function p5check(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

function p5expect(callable $callback, string $message): void
{
    try {
        $callback();
    } catch (InvalidArgumentException|LogicException|RuntimeException) {
        return;
    }
    fwrite(STDERR, "FAIL: expected rejection: {$message}\n");
    exit(1);
}

function p5executor(CommandBusProvisioningAdapter $adapter): GovernedProvisioningExecutor
{
    $risk = new RiskEngineAdapter(static fn (array $request): array => [
        'allowed' => true,
        'decision_reference' => 'risk:pass5-regression',
        'risk_class' => 'MEDIUM',
        'required_assurance' => 'AMBER',
    ]);
    $governance = new GovernanceEngineAdapter(static fn (array $request): array => [
        'allowed' => true,
        'decision_reference' => 'governance:pass5-regression',
        'approval_required' => ($request['operation']['governance_disposition'] ?? '') === 'requires_approval',
        'approval_reference' => $request['execution_context']['approval_reference'] ?? null,
    ]);
    $autonomy = new AutonomyEngineAdapter(static fn (array $request): array => [
        'allowed' => true,
        'decision_reference' => 'autonomy:pass5-regression',
        'authority_level' => 'Semi-Auto',
    ]);
    $assurance = new AssuranceEngineAdapter(static fn (array $request): array => [
        'allowed' => true,
        'evidence_reference' => 'assurance:pass5-regression',
        'assurance_level' => 'AMBER',
    ]);
    $signal = new SignalEngineAdapter(static fn (string $event, array $request): array => [
        'signal_reference' => 'signal:' . $event,
    ]);
    $rewind = new RewindEngineAdapter(static fn (string $event, array $request): array => [
        'rewind_reference' => 'rewind:' . $event,
    ]);

    return new GovernedProvisioningExecutor($adapter, $risk, $governance, $assurance, $signal, $rewind, $autonomy);
}

function p5profile(): BusinessProfile
{
    return BusinessProfile::fromArray([
        'tenant_company_id' => 42,
        'profile_version' => '3.0.0',
        'vertical_id' => 'cleaning',
        'vertical_version' => '2026.08',
        'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
        'timezone' => 'Australia/Melbourne',
        'sections' => ['crm' => ['enabled' => true], 'workforce' => ['roles' => ['cleaner']]],
    ]);
}

function p5trace(): TraceContext
{
    return TraceContext::fromArray([
        'tenant_company_id' => 42,
        'trace_id' => '11111111-1111-4111-8111-111111111111',
        'correlation_id' => '22222222-2222-4222-8222-222222222222',
        'causation_id' => '33333333-3333-4333-8333-333333333333',
    ]);
}

function p5vertical(): VerticalDefinition
{
    return VerticalDefinition::fromArray([
        'vertical_id' => 'cleaning',
        'vertical_version' => '2026.08',
        'knowledge_snapshot_version' => 'au-vic-2026.08',
        'sections' => [],
        'provisioning' => [
            'routes' => [
                'sections.crm' => [
                    'capability' => 'crm.configuration.apply',
                    'depends_on' => [],
                ],
                'sections.workforce' => [
                    'capability' => 'workforce.configuration.apply',
                    'depends_on' => ['sections.crm'],
                ],
            ],
        ],
    ]);
}

$definition = p5vertical();
$roundTripDefinition = VerticalDefinition::fromArray($definition->toArray());
p5check($definition->fingerprint() === $roundTripDefinition->fingerprint(), 'provisioning metadata round-trips deterministically');
$withoutProvisioning = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => [],
]);
p5check(!array_key_exists('provisioning', $withoutProvisioning->toArray()), 'absent provisioning metadata remains omitted');

p5expect(static fn () => VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'sections' => [],
    'provisioning' => ['routes' => [
        'sections.crm' => ['capability' => 'crm.apply', 'depends_on' => ['sections.workforce']],
        'sections.workforce' => ['capability' => 'workforce.apply', 'depends_on' => ['sections.crm']],
    ]],
]), 'route dependency cycles are rejected');

$profile = p5profile();
$config = new CompiledTitanConfig(
    42,
    '3',
    '0.6.0',
    'cleaning',
    '2026.08',
    'au-vic-2026.08',
    $profile->fingerprint(),
    $definition->fingerprint(),
    $profile->sections(),
);
$compiled = NexusCompilation::draft(
    $profile,
    p5trace(),
    '44444444-4444-4444-8444-444444444444',
    '0.6.0',
)->withCompiledConfiguration($config);

$planner = new DeterministicProvisioningPlanner();
$initialPlan = $planner->plan($compiled, $definition);
p5check($initialPlan->status() === ProvisioningPlanStatus::Ready, 'routed initial configuration is ready');
p5check(count($initialPlan->operations()) === 2, 'initial plan has one operation per top-level routed section');
$initialOps = $initialPlan->operations();
p5check($initialOps[0]->path() === 'sections.crm', 'crm is ordered before dependent workforce');
p5check($initialOps[1]->path() === 'sections.workforce', 'workforce follows crm');
p5check($initialOps[1]->dependsOnOperationIds() === [$initialOps[0]->operationId()], 'dependency resolves to deterministic operation id');
p5check($initialOps[0]->backupRequired(), 'every mutation operation requires backup');
p5check($planner->plan($compiled, $definition)->fingerprint() === $initialPlan->fingerprint(), 'same compiled state produces identical provisioning plan');
p5check($planner->plan($compiled, $definition)->operations()[0]->idempotencyKey() === $initialOps[0]->idempotencyKey(), 'idempotency key is stable');


$workforceOnlyProfile = BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '3.0.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
    'timezone' => 'Australia/Melbourne',
    'sections' => ['workforce' => ['roles' => ['cleaner']]],
]);
$workforceOnlyConfig = new CompiledTitanConfig(
    42, '3', '0.6.0', 'cleaning', '2026.08', 'au-vic-2026.08',
    $workforceOnlyProfile->fingerprint(), $definition->fingerprint(), $workforceOnlyProfile->sections(),
);
$workforceOnlyCompilation = NexusCompilation::draft(
    $workforceOnlyProfile, p5trace(), 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', '0.6.0'
)->withCompiledConfiguration($workforceOnlyConfig);
p5check($planner->plan($workforceOnlyCompilation, $definition)->status() === ProvisioningPlanStatus::Blocked, 'initial provisioning blocks when a declared dependency route is absent from desired state');

$unroutedDefinition = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => [],
    'provisioning' => ['routes' => [
        'sections.crm' => ['capability' => 'crm.configuration.apply', 'depends_on' => []],
    ]],
]);
$unroutedConfig = new CompiledTitanConfig(
    42, '3', '0.6.0', 'cleaning', '2026.08', 'au-vic-2026.08',
    $profile->fingerprint(), $unroutedDefinition->fingerprint(), $profile->sections(),
);
$unroutedCompiled = NexusCompilation::draft(
    $profile, p5trace(), '55555555-5555-4555-8555-555555555555', '0.6.0'
)->withCompiledConfiguration($unroutedConfig);
$blockedPlan = $planner->plan($unroutedCompiled, $unroutedDefinition);
p5check($blockedPlan->status() === ProvisioningPlanStatus::Blocked, 'missing route coverage blocks provisioning');
p5check($blockedPlan->operations()[1]->disposition() === SemanticChangeDisposition::Blocked, 'unrouted operation is explicitly blocked');

$diff = new ConfigurationDiff(
    str_repeat('a', 64),
    $config->outputHash(),
    [
        new SemanticDiffEntry('sections.crm.enabled', SemanticChangeKind::Modify, SemanticChangeDisposition::RequiresApproval, false, true, 'Owner approval required.'),
        new SemanticDiffEntry('sections.workforce.roles', SemanticChangeKind::Modify, SemanticChangeDisposition::Apply, ['assistant'], ['cleaner'], null),
    ],
);
$recompileCandidate = $compiled->withConfigurationDiff($diff);
$approvalPlan = $planner->plan($recompileCandidate, $definition);
p5check($approvalPlan->status() === ProvisioningPlanStatus::RequiresApproval, 'diff approval disposition flows into provisioning plan');

$persisted = $recompileCandidate->withProvisioningPlan($approvalPlan)->toPersistenceArray();
$restored = NexusCompilation::fromPersistence($persisted);
p5check($restored->provisioningPlan()?->fingerprint() === $approvalPlan->fingerprint(), 'provisioning plan persists through existing JSON column');

$appliedRequests = [];
$adapter = new CommandBusProvisioningAdapter(static function (string $capability, array $request) use (&$appliedRequests): array {
    $appliedRequests[] = [$capability, $request];
    return [
        'operation_id' => $request['operation_id'],
        'idempotency_key' => $request['idempotency_key'],
        'status' => 'applied',
        'backup_reference' => 'backup:' . $request['operation_id'],
        'backup_verified' => true,
        'write_verified' => true,
        'audit_reference' => 'audit:' . $request['operation_id'],
        'rollback_reference' => 'rollback:' . $request['operation_id'],
    ];
});
$executor = p5executor($adapter);
p5expect(static fn () => $executor->execute($approvalPlan, p5trace(), false), 'approval-required plan cannot execute without explicit approval');
$executed = $executor->execute($approvalPlan, p5trace(), true);
p5check($executed->status() === ProvisioningPlanStatus::Applied, 'approved plan executes successfully');
p5check(count($executed->receipts()) === 2, 'execution records one receipt per operation');
p5check(($appliedRequests[0][1]['mutation_safety']['verify_backup_before_write'] ?? null) === true, 'adapter requires backup verification before mutation');
p5check(($appliedRequests[0][1]['mutation_safety']['preserve_rollback_metadata'] ?? null) === true, 'adapter requires rollback metadata preservation');

$alreadyAdapter = new CommandBusProvisioningAdapter(static function (string $capability, array $request): array {
    return [
        'operation_id' => $request['operation_id'],
        'idempotency_key' => $request['idempotency_key'],
        'status' => 'already_applied',
        'durable_idempotency_reference' => 'idempotency:' . $request['idempotency_key'],
    ];
});
$alreadyPlan = p5executor($alreadyAdapter)->execute($initialPlan, p5trace());
p5check($alreadyPlan->status() === ProvisioningPlanStatus::Applied, 'already-applied operations satisfy idempotent execution');
p5check($alreadyPlan->receipts()[0]->status() === ProvisioningReceiptStatus::AlreadyApplied, 'receipt records durable duplicate suppression');

$unsafeAdapter = new CommandBusProvisioningAdapter(static function (string $capability, array $request): array {
    return [
        'operation_id' => $request['operation_id'],
        'idempotency_key' => $request['idempotency_key'],
        'status' => 'applied',
        'backup_verified' => false,
        'write_verified' => true,
        'audit_reference' => 'audit',
        'rollback_reference' => 'rollback',
    ];
});
p5expect(static fn () => $unsafeAdapter->execute($initialPlan->operations()[0], p5trace()), 'applied receipt without verified backup is rejected');

$partialAdapter = new CommandBusProvisioningAdapter(static function (string $capability, array $request): array {
    if ($capability === 'crm.configuration.apply') {
        return [
            'operation_id' => $request['operation_id'],
            'idempotency_key' => $request['idempotency_key'],
            'status' => 'failed',
            'message' => 'crm unavailable',
        ];
    }
    throw new RuntimeException('dependent operation should have been skipped');
});
$partial = p5executor($partialAdapter)->execute($initialPlan, p5trace());
p5check($partial->status() === ProvisioningPlanStatus::Failed, 'no successful writes plus failure resolves to failed');
p5check($partial->receipts()[0]->status() === ProvisioningReceiptStatus::Failed, 'failed dependency receipt retained');
p5check($partial->receipts()[1]->status() === ProvisioningReceiptStatus::SkippedDependency, 'dependent operation is skipped after dependency failure');


$threeProfile = BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '3.0.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
    'timezone' => 'Australia/Melbourne',
    'sections' => [
        'analytics' => ['enabled' => true],
        'crm' => ['enabled' => true],
        'workforce' => ['roles' => ['cleaner']],
    ],
]);
$threeDefinition = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => [],
    'provisioning' => ['routes' => [
        'sections.analytics' => ['capability' => 'analytics.configuration.apply', 'depends_on' => []],
        'sections.crm' => ['capability' => 'crm.configuration.apply', 'depends_on' => []],
        'sections.workforce' => ['capability' => 'workforce.configuration.apply', 'depends_on' => ['sections.crm']],
    ]],
]);
$threeConfig = new CompiledTitanConfig(
    42, '3', '0.6.0', 'cleaning', '2026.08', 'au-vic-2026.08',
    $threeProfile->fingerprint(), $threeDefinition->fingerprint(), $threeProfile->sections(),
);
$threeCompilation = NexusCompilation::draft(
    $threeProfile, p5trace(), 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb', '0.6.0'
)->withCompiledConfiguration($threeConfig);
$threePlan = $planner->plan($threeCompilation, $threeDefinition);
$partialIndependentAdapter = new CommandBusProvisioningAdapter(static function (string $capability, array $request): array {
    if ($capability === 'crm.configuration.apply') {
        return [
            'operation_id' => $request['operation_id'],
            'idempotency_key' => $request['idempotency_key'],
            'status' => 'failed',
            'message' => 'crm unavailable',
        ];
    }
    return [
        'operation_id' => $request['operation_id'],
        'idempotency_key' => $request['idempotency_key'],
        'status' => 'applied',
        'backup_reference' => 'backup:' . $request['operation_id'],
        'backup_verified' => true,
        'write_verified' => true,
        'audit_reference' => 'audit:' . $request['operation_id'],
        'rollback_reference' => 'rollback:' . $request['operation_id'],
    ];
});
$partialIndependent = p5executor($partialIndependentAdapter)->execute($threePlan, p5trace());
p5check($partialIndependent->status() === ProvisioningPlanStatus::PartiallyApplied, 'independent successful mutation plus failed branch resolves to partially_applied');

p5expect(static fn () => (new CommandBusProvisioningAdapter())->execute($initialPlan->operations()[0], p5trace()), 'unconfigured Command Bus gateway fails closed');

p5check(ProvisioningPlan::fromArray($executed->toArray())->fingerprint() === $executed->fingerprint(), 'executed plan round-trip preserves fingerprint');

fwrite(STDOUT, "PASS: Titan Nexus standalone governed provisioning checks\n");
