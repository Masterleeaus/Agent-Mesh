<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Entities;

use InvalidArgumentException;

final readonly class PrimeObjective
{
    /** @param list<string> $successCriteria */
    public function __construct(
        public string $type,
        public string $statement,
        public string $desiredOutcome,
        public array $successCriteria = [],
    ) {
        if (trim($type) === '' || trim($statement) === '' || trim($desiredOutcome) === '') {
            throw new InvalidArgumentException('Objective type, statement and desired outcome are required.');
        }
    }

    /** @return array{type:string,statement:string,desired_outcome:string,success_criteria:list<string>} */
    public function toArray(): array
    {
        return [
            'type' => $this->type,
            'statement' => $this->statement,
            'desired_outcome' => $this->desiredOutcome,
            'success_criteria' => array_values($this->successCriteria),
        ];
    }
}
