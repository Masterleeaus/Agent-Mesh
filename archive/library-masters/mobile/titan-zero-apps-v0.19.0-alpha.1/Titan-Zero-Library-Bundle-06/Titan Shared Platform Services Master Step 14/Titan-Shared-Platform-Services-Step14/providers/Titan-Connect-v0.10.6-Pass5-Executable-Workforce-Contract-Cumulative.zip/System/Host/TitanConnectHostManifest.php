<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Host;

final class TitanConnectHostManifest
{
    public function __construct(
        private readonly TitanConnectPermissionCatalogue $permissions,
        private readonly TitanConnectFeatureCatalogue $features,
    ) {
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'register_key' => 'titan-connect',
            'provider' => 'App\\Extensions\\TitanConnect\\System\\TitanConnectServiceProvider',
            'tenant_boundary' => 'company_id',
            'routes' => [
                'user' => ['titan-connect.*'],
                'admin' => ['titan-connect.admin.channels.*'],
                'api' => ['titan-connect.api.*'],
            ],
            'plan_features' => $this->features->all(),
            'admin_permissions' => $this->permissions->all(),
            'published_assets' => ['public/vendor/titan-connect'],
            'published_config' => ['config/titan-connect.php'],
            'uninstall' => [
                'preserve_database_data' => true,
                'remove_published_assets' => true,
                'remove_published_config' => false,
                'remote_cleanup' => false,
            ],
        ];
    }
}
