<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanCommandBus\System\Commands\CertifyExtensionCommand;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterRegistryContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandApprovalGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAssuranceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAutonomyGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandBusContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandGovernanceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandLifecycleStoreContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandReceiptStoreContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandRiskGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandSignalEmitterContract;
use App\Extensions\TitanCommandBus\System\Navigation\CommandBusAdminNavigationContributor;
use App\Extensions\TitanCommandBus\System\Services\CommandAdapterRegistry;
use App\Extensions\TitanCommandBus\System\Services\CommandBus;
use App\Extensions\TitanCommandBus\System\Infrastructure\Persistence\DatabaseCommandLifecycleStore;
use App\Extensions\TitanCommandBus\System\Infrastructure\Persistence\DatabaseCommandReceiptStore;
use App\Extensions\TitanCommandBus\System\Services\FailClosedApprovalGate;
use App\Extensions\TitanCommandBus\System\Services\FailClosedAssuranceGate;
use App\Extensions\TitanCommandBus\System\Services\FailClosedAutonomyGate;
use App\Extensions\TitanCommandBus\System\Services\FailClosedGovernanceGate;
use App\Extensions\TitanCommandBus\System\Services\FailClosedRiskGate;
use App\Extensions\TitanCommandBus\System\Services\NullCommandSignalEmitter;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

final class TitanCommandBusServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-command-bus.php', 'titan-command-bus');
        $this->app->singleton(CommandAdapterRegistryContract::class, CommandAdapterRegistry::class);
        $this->app->singleton(CommandRiskGateContract::class, FailClosedRiskGate::class);
        $this->app->singleton(CommandAssuranceGateContract::class, FailClosedAssuranceGate::class);
        $this->app->singleton(CommandAutonomyGateContract::class, FailClosedAutonomyGate::class);
        $this->app->singleton(CommandApprovalGateContract::class, FailClosedApprovalGate::class);
        $this->app->singleton(CommandGovernanceGateContract::class, FailClosedGovernanceGate::class);
        $this->app->singleton(CommandReceiptStoreContract::class, DatabaseCommandReceiptStore::class);
        $this->app->singleton(CommandLifecycleStoreContract::class, DatabaseCommandLifecycleStore::class);
        $this->app->singleton(CommandSignalEmitterContract::class, NullCommandSignalEmitter::class);
        $this->app->singleton(CommandBusContract::class, CommandBus::class);
    }

    public function boot(): void
    {
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-command-bus');
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->publishes([__DIR__ . '/../config/titan-command-bus.php' => config_path('titan-command-bus.php')], 'titan-command-bus-config');
        $this->registerRoutes();
        $this->registerNavigation();
        if ($this->app->runningInConsole()) {
            $this->commands([CertifyExtensionCommand::class]);
        }
    }

    public function registerKey(): string { return 'titan-command-bus'; }

    public static function uninstall(): void
    {
        File::delete(config_path('titan-command-bus.php'));
    }

    private function registerRoutes(): void
    {
        /** @var Router $router */
        $router = $this->app['router'];
        $router->group([
            'middleware' => ['web', 'auth', 'admin'],
            'prefix' => 'dashboard/admin/titan-command-bus',
            'as' => 'dashboard.admin.titan.command.bus.',
        ], static function (): void {
            require __DIR__ . '/../routes/admin.php';
        });
    }

    private function registerNavigation(): void
    {
        $registryClass = 'App\\Support\\Extensions\\ContributionRegistry';
        if (! class_exists($registryClass)) {
            return;
        }
        try {
            $registry = $this->app->make($registryClass);
            if (method_exists($registry, 'register')) {
                $registry->register('navigation.admin', 'titan-command-bus', CommandBusAdminNavigationContributor::class, 80);
            }
        } catch (\LogicException $e) {
            if (! str_contains($e->getMessage(), 'already registered')) {
                throw $e;
            }
        }
    }
}
