# Installer 1.7.3 Compatibility Hotfix 1.0.2

- Converts `extension.json.dependencies` to the Extension Manager 1.7.3 list-of-objects schema (`slug` + `version`).
- Preserves the safe CRM extraction floor `>=1.3.0-alpha.24`.
- Replaces five Laravel auto-generated MySQL index names that exceeded MySQL's 64-character identifier limit with explicit short names.
- Adds a package-wide regression scanner for generated MySQL index/unique names.
