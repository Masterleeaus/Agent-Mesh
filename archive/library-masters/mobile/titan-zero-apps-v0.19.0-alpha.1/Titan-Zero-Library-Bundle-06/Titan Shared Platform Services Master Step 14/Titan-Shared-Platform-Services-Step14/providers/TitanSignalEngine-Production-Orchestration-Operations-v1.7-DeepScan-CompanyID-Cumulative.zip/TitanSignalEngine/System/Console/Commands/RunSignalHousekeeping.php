<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Console\Commands;

use App\Extensions\TitanSignalEngine\System\Services\SignalHousekeepingService;
use Illuminate\Console\Command;

final class RunSignalHousekeeping extends Command
{
    protected $signature = 'titan:signal-housekeeping {--limit=5000}';
    protected $description = 'Clean expired Signal operational projections without mutating retained immutable events.';

    public function handle(SignalHousekeepingService $housekeeping): int
    {
        $result = $housekeeping->run((int) $this->option('limit'));
        $this->line(json_encode($result, JSON_THROW_ON_ERROR));
        return self::SUCCESS;
    }
}
