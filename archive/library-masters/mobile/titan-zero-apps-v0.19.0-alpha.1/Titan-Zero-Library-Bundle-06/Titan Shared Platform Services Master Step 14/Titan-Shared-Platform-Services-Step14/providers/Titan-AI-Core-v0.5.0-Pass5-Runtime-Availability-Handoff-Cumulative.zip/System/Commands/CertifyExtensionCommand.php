<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\Commands;
use Illuminate\Console\Command;
final class CertifyExtensionCommand extends Command {
    protected $signature = 'titan:titan-ai-core:certify {--json : Emit machine-readable evidence}';
    protected $description = 'Emit Titan AI Core host-certification evidence for package/runtime wiring.';
    public function handle(): int {
        $root=dirname(__DIR__,2);
        $checks=[
            'manifest_v22'=>is_file($root.'/extension.manifest.json') && str_contains((string)file_get_contents($root.'/extension.manifest.json'),'"schema_version": "2.2"'),
            'typed_plan_envelope'=>is_file($root.'/System/DTO/PlanEnvelope.php'),
            'typed_plan_step'=>is_file($root.'/System/DTO/PlanStep.php'),
            'typed_runtime_context'=>is_file($root.'/System/DTO/RuntimeContext.php'),
            'constructive_validation'=>is_file($root.'/System/DTO/ValidationReport.php'),
            'governance_preflight'=>is_file($root.'/System/Services/GovernancePreflightCoordinator.php'),
            'command_bus_boundary'=>is_file($root.'/System/Services/CommandBusMutationBoundary.php'),
            'approval_state'=>is_file($root.'/System/DTO/ApprovalState.php'),
            'execution_fail_closed'=>is_file($root.'/config/titan-ai-core.php') && str_contains((string)file_get_contents($root.'/config/titan-ai-core.php'), "'execution_enabled' => false"),
        ];
        $ok=!in_array(false,$checks,true);
        $evidence=['contract'=>'titan.release-certification.v1','extension'=>'titan-ai-core','version'=>'0.5.0','package_verified'=>$ok,'host_certified'=>false,'production_signed'=>false,'checks'=>$checks];
        if ((bool)$this->option('json')) $this->line((string)json_encode($evidence,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
        else { $this->info('Titan AI Core certification evidence'); foreach($checks as $k=>$v)$this->line(($v?'[OK] ':'[--] ').$k); $this->warn('host_certified=false until executed against the live Titan Zero host.'); }
        return $ok?self::SUCCESS:self::FAILURE;
    }
}
