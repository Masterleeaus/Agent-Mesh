# Workforce Integration Report

## Scope

Deep-scan migration for **titan-command-bus 0.2.0-alpha.6** against the Titan Extension Blueprint v4.2.1 / Workforce handoff contract.

## Ownership result

- Canonical tenant boundary: `company_id`.
- Titan AI Workforce remains the only owner of employee identity, organisational role identity, hierarchy, teams, responsibilities, assignments, work items and orchestration.
- Extension domain ownership: canonical governed mutation execution boundary; owns command lifecycle/receipts only, never foreign business records or Workforce identity.
- Installed capability/provider presence does **not** grant authority.

## Published Workforce surfaces

- Capabilities: 3.
- Non-mutating reads: 2.
- Governed commands: 1.
- Signals: 4.
- Work types: 3.
- Availability states: available, degraded, unavailable, missing_provider, blocked, policy_disabled.

Machine-readable contract: `workforce-integration.json`. Runtime helper: `System/Workforce/WorkforceIntegrationContract.php`.

## Authority and execution

Consequential commands are declared as governed execution surfaces. Workforce orchestration must not call extension UI routes or internal services as an authority shortcut. Reads remain non-mutating. The contract is fail-closed and keeps provider availability separate from authorization, governance, risk and autonomy.

## Compatibility / deep-scan notes

- Legacy tenant_company_id naming remains an explicitly documented compatibility boundary inside the current Command Bus DTO/persistence contract; new Workforce contract uses company_id only.
- Installed/registered capability adapters do not imply authorization.

## Verification added

Run `php tests/Standalone/WorkforceIntegrationContractTest.php`. The test validates canonical tenancy, authority-neutral discovery, read/command separation, fail-closed availability states and positive `company_id` validation.

## Next upgrade — data-access and execution hardening

- Added explicit safety bounds to previously unbounded production read materialization paths where applicable; historical migrations remain frozen.
- Preserved `company_id` as the Workforce-facing tenant boundary and did not expand authority.
- Re-ran Blueprint architecture analysis to distinguish domain code from legitimate infrastructure persistence.
- Moved Command Bus durable database receipt/lifecycle stores from the runtime service namespace into `System/Infrastructure/Persistence`, making persistence ownership explicit without changing the contracts bound to callers.

## Pass 4 — Canonical Company Tenancy & Execution Contract

- Command Bus runtime queries now use `company_id` as the authoritative tenant boundary.
- Added non-destructive migration `2026_08_22_000008_canonicalize_command_bus_company_tenancy.php` to add/backfill canonical company columns and canonical idempotency/lifecycle uniqueness.
- Existing `tenant_company_id` persistence and receipt/signal fields remain only as explicit dual-write compatibility aliases for pre-Pass4 hosts and v1 consumers.
- Trusted audit context exposes only `company_id`; installed capability still grants no authority.
- Added executable `CanonicalCompanyTenancyTest.php`.

## Pass 5 — Executable Workforce Discovery Contract

- Workforce integration contract upgraded to 1.1 without changing the extension's domain ownership.
- Explicit non-mutating `tools` and `data_sources` are now published for every read surface.
- Every executable command is pinned to provider + provider version and requires canonical `company_id`, causal trace context and an idempotency key.
- Mutations explicitly require governed evidence and an execution receipt, and fail closed when the execution provider is missing or degraded.
- Work types now declare provider pinning and fail-closed unavailability behavior; provider removal cannot mutate Workforce identity.
- Executable contract tests reject unknown commands and incomplete execution context.

