<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Forensics\RewindIntegrityHasher;
use App\Extensions\TitanRewind\System\Models\RewindTraceEvent;
use App\Extensions\TitanRewind\System\Models\RewindTraceIndex;
use App\Extensions\TitanRewind\System\Reconstruction\RewindEventRecord;
use App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use LogicException;

final class RewindEventStore
{
    public function __construct(
        private RewindPayloadSanitizer $sanitizer,
        private RewindIntegrityHasher $integrityHasher,
        private RewindTimelineService $timeline,
        private RewindDependencyService $dependencies,
        private RewindSnapshotService $snapshots,
        private RewindTraceProjector $projector,
    ) {}

    public function store(RewindEventRecord $record): RewindTraceEvent
    {
        $input = $record->toArray();
        foreach (['reason_codes','evidence_refs','rationale','risk_state','assurance_state','autonomy_state','governance_state','payload'] as $field) {
            if (is_array($input[$field] ?? null)) $input[$field] = $this->sanitizer->sanitize($input[$field]);
        }

        $canonicalHash = $this->integrityHasher->contentHash($input);
        $input['recorded_at'] = $input['recorded_at'] ?: now();
        $input['canonical_hash'] = $canonicalHash;
        $input['integrity_hash'] = $canonicalHash;

        /** @var RewindTraceEvent $event */
        $event = DB::transaction(function () use ($input, $canonicalHash): RewindTraceEvent {
            $existing = RewindTraceEvent::query()->where('event_id', $input['event_id'])->first();
            if ($existing) {
                if ((int) $existing->tenant_company_id !== (int) $input['tenant_company_id']) {
                    throw new LogicException('A duplicate Rewind event_id crossed tenant boundaries.');
                }
                foreach (['trace_id','source_engine','event_type'] as $immutableField) {
                    if ((string) $existing->{$immutableField} !== (string) $input[$immutableField]) {
                        throw new LogicException("A duplicate Rewind event_id changed immutable {$immutableField}.");
                    }
                }
                $existingCanonical = $this->integrityHasher->contentHash($existing->toArray());
                if (!hash_equals($existingCanonical, $canonicalHash)) {
                    throw new LogicException('A duplicate Rewind event_id was replayed with different canonical content.');
                }
                return $existing;
            }

            RewindTraceIndex::query()->insertOrIgnore([
                'tenant_company_id'=>$input['tenant_company_id'],
                'trace_id'=>$input['trace_id'],
                'correlation_id'=>$input['correlation_id'],
                'reconstruction_status'=>'pending',
                'integrity_state'=>'unknown',
                'forensic_state'=>'unknown',
                'created_at'=>now(),
                'updated_at'=>now(),
            ]);

            RewindTraceIndex::query()
                ->where('tenant_company_id',$input['tenant_company_id'])
                ->where('trace_id',$input['trace_id'])
                ->lockForUpdate()->firstOrFail();

            $lastSealed = RewindTraceEvent::query()
                ->where('tenant_company_id',$input['tenant_company_id'])
                ->where('trace_id',$input['trace_id'])
                ->whereNotNull('chain_position')
                ->orderByDesc('chain_position')
                ->lockForUpdate()->first();

            $chainPosition = ((int) ($lastSealed?->chain_position ?? 0)) + 1;
            $chainPreviousHash = $lastSealed?->chain_hash ?: null;
            $chainHash = $this->integrityHasher->chainHash($chainPreviousHash, $canonicalHash, (string) $input['event_id'], $chainPosition);

            return RewindTraceEvent::query()->create(array_merge([
                'record_uuid'=>(string) Str::uuid(),
                'chain_position'=>$chainPosition,
                'chain_previous_hash'=>$chainPreviousHash,
                'chain_hash'=>$chainHash,
            ], $input));
        }, 3);

        $this->timeline->materializeEvent($event);
        $this->dependencies->recordFromEvent($event);
        $this->snapshots->captureFromEvent($event);
        $this->projector->refresh((int) $event->tenant_company_id, (string) $event->trace_id);

        return $event->refresh();
    }
}
