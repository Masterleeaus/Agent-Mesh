@php($interactionNewLabel = $label ?? 'New')
@php($interactionJourneyKey = $journey ?? null)
@php($interactionPrefill = (array)($prefill ?? []))
@if($interactionJourneyKey)
<form method="POST" action="{{ route('dashboard.user.crm.interactions.start',$interactionJourneyKey) }}" class="d-inline">@csrf
    @foreach($interactionPrefill as $key=>$value)@if(is_scalar($value) && $value !== '')<input type="hidden" name="prefill[{{ $key }}]" value="{{ $value }}">@endif @endforeach
    <button class="btn btn-primary" type="submit"><x-tabler-plus class="size-4 me-1" />{{ $interactionNewLabel }}</button>
</form>
@endif
