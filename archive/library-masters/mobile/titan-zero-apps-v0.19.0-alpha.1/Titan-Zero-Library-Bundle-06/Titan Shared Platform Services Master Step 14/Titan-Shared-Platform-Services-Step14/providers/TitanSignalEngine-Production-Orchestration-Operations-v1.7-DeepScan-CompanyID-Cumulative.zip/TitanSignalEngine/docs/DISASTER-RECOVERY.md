# Disaster Recovery

Target RPO: 60 minutes. Target RTO: 240 minutes.

## Backup scope

Back up all Signal-owned durable tables plus archive objects/catalog metadata and the deployed configuration required to interpret them. Do not back up transient caches as authoritative state.

## Restore order

1. Restore database schema/migrations.
2. Restore immutable events and registry definitions.
3. Restore correlation/subscription/lifecycle state.
4. Restore archive batches/objects and verify checksums.
5. Restore/rebuild Pulse and anomaly projections where safe.
6. Reconcile pending/retry/dead-letter deliveries.
7. Validate tenant isolation, event checksums and archive references.
8. Resume schedules/workers.

A restore is incomplete until queue/delivery, projection and archive reconciliation passes.
