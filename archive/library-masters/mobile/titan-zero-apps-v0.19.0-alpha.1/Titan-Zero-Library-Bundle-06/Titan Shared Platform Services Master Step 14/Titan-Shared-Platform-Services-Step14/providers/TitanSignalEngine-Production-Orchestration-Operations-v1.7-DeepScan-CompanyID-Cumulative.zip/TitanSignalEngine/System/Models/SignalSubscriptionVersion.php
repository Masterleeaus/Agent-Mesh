<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use App\Extensions\TitanSignalEngine\System\Exceptions\ImmutableRegistryDefinitionException;
use Illuminate\Database\Eloquent\Model;

final class SignalSubscriptionVersion extends Model
{
    protected $table = 'titan_signal_subscription_versions';
    protected $guarded = [];

    protected $casts = [
        'definition_version' => 'integer',
        'event_patterns' => 'array',
        'accepted_schema_versions' => 'array',
        'scopes' => 'array',
        'categories' => 'array',
        'verticals' => 'array',
        'backoff_seconds' => 'array',
        'max_attempts' => 'integer',
        'timeout_seconds' => 'integer',
        'registered_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::updating(static function (): never {
            throw new ImmutableRegistryDefinitionException('Signal subscription versions are immutable; register a new definition version.');
        });
        static::deleting(static function (): never {
            throw new ImmutableRegistryDefinitionException('Signal subscription versions cannot be deleted through the application model.');
        });
    }
}
