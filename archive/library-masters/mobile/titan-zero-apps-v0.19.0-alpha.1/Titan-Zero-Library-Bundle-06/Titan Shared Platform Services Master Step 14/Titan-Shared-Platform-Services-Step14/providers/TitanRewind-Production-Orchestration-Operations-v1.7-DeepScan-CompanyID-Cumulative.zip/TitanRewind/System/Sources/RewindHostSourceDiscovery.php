<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Sources;
use App\Extensions\TitanRewind\System\Reconstruction\RewindSourceAdapterRegistry;
use Illuminate\Contracts\Container\Container;
final class RewindHostSourceDiscovery
{
    public function __construct(private Container $app,private RewindSourceAdapterRegistry $registry){}
    public function discover(): array
    {
        $class='App\\Support\\Extensions\\RewindSourceRegistry'; if(!class_exists($class)||!$this->app->bound($class)) return ['available'=>false,'discovered'=>0,'keys'=>[]];
        $host=$this->app->make($class); if(!is_object($host)||!method_exists($host,'all')) return ['available'=>false,'discovered'=>0,'keys'=>[]];
        $count=0;$keys=[]; foreach((array)$host->all() as $source){ if(!is_object($source)) continue; $adapter=new RewindHostSourceAdapter($source); $key=$adapter->key(); if(!$this->registry->has($key)){ $this->registry->register($adapter); $count++; } $keys[]=$key; }
        sort($keys,SORT_STRING); return ['available'=>true,'discovered'=>$count,'keys'=>array_values(array_unique($keys))];
    }
}
