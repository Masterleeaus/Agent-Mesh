<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindTraceIndex extends Model
{
    protected $table = 'titan_rewind_trace_index';
    protected $guarded = [];
    protected $casts = [
        'tenant_company_id'=>'integer','event_count'=>'integer','source_count'=>'integer','decision_count'=>'integer',
        'mutation_count'=>'integer','outcome_count'=>'integer','late_event_count'=>'integer','out_of_order_arrival_count'=>'integer','sequence_collision_count'=>'integer','causation_orphan_count'=>'integer','open_drift_count'=>'integer','has_recovery'=>'boolean','has_compensation'=>'boolean',
        'source_engines'=>'array','policy_versions'=>'array','guide_versions'=>'array','model_versions'=>'array',
        'first_event_at'=>'datetime','last_event_at'=>'datetime','materialized_at'=>'datetime','last_integrity_check_at'=>'datetime','reconstruction_version'=>'integer',
    ];
}
