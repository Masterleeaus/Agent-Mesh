# Upgrade

Forward-only metadata convergence. Historical migrations remain frozen; legacy tenant-key readers may remain only as explicit compatibility paths.
