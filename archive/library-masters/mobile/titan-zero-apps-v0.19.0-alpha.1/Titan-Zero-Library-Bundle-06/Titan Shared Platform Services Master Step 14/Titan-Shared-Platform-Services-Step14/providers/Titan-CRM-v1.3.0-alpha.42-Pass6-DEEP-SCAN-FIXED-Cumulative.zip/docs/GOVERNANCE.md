# Governance

Intelligence is not authority. Titan Autonomy owns earned/effective authority. State-writing Workforce actions use the governed execution boundary and require execution receipts.
