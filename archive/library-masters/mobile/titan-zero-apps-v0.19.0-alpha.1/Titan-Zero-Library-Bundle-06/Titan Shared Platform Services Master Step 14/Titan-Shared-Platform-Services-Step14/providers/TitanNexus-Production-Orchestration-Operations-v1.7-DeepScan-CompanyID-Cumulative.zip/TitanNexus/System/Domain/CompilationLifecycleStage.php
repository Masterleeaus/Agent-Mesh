<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

enum CompilationLifecycleStage: string
{
    case DraftCreated = 'draft_created';
    case ValidationCompleted = 'validation_completed';
    case ValidationFailed = 'validation_failed';
    case Compiled = 'compiled';
    case DiffCalculated = 'diff_calculated';
    case RecompilePlanned = 'recompile_planned';
    case ProvisioningPlanned = 'provisioning_planned';
    case ProvisioningExecuted = 'provisioning_executed';
}
