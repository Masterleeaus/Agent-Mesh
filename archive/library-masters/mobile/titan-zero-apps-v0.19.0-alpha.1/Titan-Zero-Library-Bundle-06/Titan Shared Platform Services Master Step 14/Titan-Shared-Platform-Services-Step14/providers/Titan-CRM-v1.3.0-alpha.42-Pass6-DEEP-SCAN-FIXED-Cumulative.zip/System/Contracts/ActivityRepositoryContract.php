<?php
namespace App\Extensions\Crm\System\Contracts;
interface ActivityRepositoryContract {
    public function create(int $userId, int $actorUserId, array $data): array;
    public function forSubject(int $userId, string $subjectType, string $subjectPublicId, int $limit=100): array;
}
