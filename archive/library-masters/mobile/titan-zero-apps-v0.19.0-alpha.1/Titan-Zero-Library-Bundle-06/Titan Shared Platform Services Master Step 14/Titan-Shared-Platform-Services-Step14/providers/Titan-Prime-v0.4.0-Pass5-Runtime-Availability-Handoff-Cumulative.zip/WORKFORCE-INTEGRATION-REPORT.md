# Workforce Integration Report — Titan-Prime

## Result

This pass makes **Titan-Prime** a subordinate runtime/provider to Titan AI Workforce. Workforce is the sole active owner of employee identity, organisational roles, hierarchy, teams, responsibilities, assignments, work items and organisational orchestration. The extension publishes runtime/domain execution surfaces only.

## Canonical tenancy

New Workforce-facing contracts use `company_id`. Prime missions and delegation intent remain Prime-owned strategic state; employee identity, roles, teams, assignments and work items remain Workforce-owned. Existing tenant_company_id persistence is compatibility-only.

## Published surfaces

- Capabilities: prime.mission.plan, prime.mission.checkpoint, prime.mission.delegate-intent, prime.outcome.record, prime.engine-gateway
- Tools: prime.mission.read, prime.gateway.status, prime.outcome.read
- Commands: prime.mission.mutate-via-command-bus, prime.delegate-to-workforce
- Reads: prime.mission.read, prime.outcome.read, prime.gateway.status
- Signals: prime.mission.started, prime.mission.delegated, prime.mission.completed, prime.gateway.degraded
- Work types: prime.mission, prime.delegation-intent, prime.outcome-review

## Safety invariants

Installation never grants authority. Availability, authorization, governance, risk and autonomy remain separate decisions. Missing provider/configuration fails closed. Side effects must use the Command Bus or the platform's canonical governed execution boundary. Reads are non-mutating. Provider disable/removal/upgrade does not mutate Workforce employee identity or grant fallback authority.

## Availability states

`available`, `degraded`, `unavailable`, `missing_provider`, `blocked`, `policy_disabled`.

## Verification

See `tests/workforce_integration_contract_runner.php` and the batch report for fresh extracted-package pass counts.
