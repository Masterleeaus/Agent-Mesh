<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Actions;

use InvalidArgumentException;

final readonly class GovernanceActionRequest
{
    private const ACTIONS = ['APPROVE','REJECT','HOLD','EXCEPTION','ESCALATE'];
    private const FORBIDDEN_CLIENT_KEYS = ['tenant_company_id','actor_id','actor','roles','permissions','trace_id','correlation_id','causation_id','root_causation_id','governance_decision_ref'];

    /** @param list<string> $reasonCodes @param list<string> $evidenceRefs */
    private function __construct(
        public int $tenantCompanyId,
        public string $actorId,
        public string $operationId,
        public string $action,
        public string $escalationId,
        public int $expectedVersion,
        public array $reasonCodes,
        public array $evidenceRefs,
        public string $traceId,
        public string $correlationId,
        public ?string $causationId,
        public string $rootCausationId,
    ) {}

    /** @param array<string,mixed> $client @param array<string,mixed> $causal */
    public static function fromClient(array $client, int $tenantCompanyId, string $actorId, array $causal): self
    {
        if ($tenantCompanyId < 1) throw new InvalidArgumentException('tenant_company_id must be positive');
        if (trim($actorId) === '') throw new InvalidArgumentException('actor_id is required');
        foreach (self::FORBIDDEN_CLIENT_KEYS as $key) if (array_key_exists($key, $client)) throw new InvalidArgumentException('client cannot supply '.$key);

        $operationId = trim((string)($client['operation_id'] ?? ''));
        $action = strtoupper(trim((string)($client['action'] ?? '')));
        $escalationId = trim((string)($client['escalation_id'] ?? ''));
        $expectedVersion = (int)($client['expected_version'] ?? 1);
        $reasonCodes = self::stringList($client['reason_codes'] ?? [], 32);
        $evidenceRefs = self::stringList($client['evidence_refs'] ?? [], 64);

        if (strlen($operationId) < 8 || strlen($operationId) > 80) throw new InvalidArgumentException('operation_id length invalid');
        if (!in_array($action, self::ACTIONS, true)) throw new InvalidArgumentException('unsupported governance action');
        if ($escalationId === '' || strlen($escalationId) > 80) throw new InvalidArgumentException('escalation_id invalid');
        if ($expectedVersion < 1) throw new InvalidArgumentException('expected_version must be positive');
        if ($reasonCodes === []) throw new InvalidArgumentException('reason_codes required');

        $traceId = self::requiredCausal($causal, 'trace_id');
        $correlationId = self::requiredCausal($causal, 'correlation_id');
        $rootCausationId = self::requiredCausal($causal, 'root_causation_id');
        $causationId = isset($causal['causation_id']) && trim((string)$causal['causation_id']) !== '' ? trim((string)$causal['causation_id']) : null;

        return new self($tenantCompanyId, trim($actorId), $operationId, $action, $escalationId, $expectedVersion, $reasonCodes, $evidenceRefs, $traceId, $correlationId, $causationId, $rootCausationId);
    }

    public function capability(): string
    {
        return 'governance.escalation.'.strtolower($this->action);
    }

    public function payloadHash(): string
    {
        $payload = [
            'tenant_company_id'=>$this->tenantCompanyId,
            'actor_id'=>$this->actorId,
            'operation_id'=>$this->operationId,
            'action'=>$this->action,
            'escalation_id'=>$this->escalationId,
            'expected_version'=>$this->expectedVersion,
            'reason_codes'=>$this->reasonCodes,
            'evidence_refs'=>$this->evidenceRefs,
        ];
        self::ksortRecursive($payload);
        return hash('sha256', json_encode($payload, JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES));
    }

    /** @return array<string,mixed> */
    public function commandEnvelope(string $decisionId): array
    {
        if (trim($decisionId) === '') throw new InvalidArgumentException('governance decision reference required');
        return [
            'schema_version'=>'titan.command-request.v1',
            'operation_id'=>$this->operationId,
            'capability'=>$this->capability(),
            'command_name'=>'titan-governance.escalation-action',
            'context'=>[
                'tenant_company_id'=>$this->tenantCompanyId,
                'actor_id'=>$this->actorId,
                'trace_id'=>$this->traceId,
                'correlation_id'=>$this->correlationId,
                'causation_id'=>$this->causationId,
                'root_causation_id'=>$this->rootCausationId,
            ],
            'governance'=>[
                'decision_ref'=>$decisionId,
                'decision_owner'=>'titan-governance',
                'fresh'=>true,
            ],
            'payload'=>[
                'action'=>$this->action,
                'escalation_id'=>$this->escalationId,
                'expected_version'=>$this->expectedVersion,
                'reason_codes'=>$this->reasonCodes,
                'evidence_refs'=>$this->evidenceRefs,
                'payload_hash'=>$this->payloadHash(),
            ],
        ];
    }

    /** @return list<string> */
    private static function stringList(mixed $value, int $maxItems): array
    {
        if (!is_array($value)) throw new InvalidArgumentException('expected list');
        if (count($value) > $maxItems) throw new InvalidArgumentException('list too large');
        $out=[];
        foreach ($value as $item) {
            if (!is_scalar($item)) throw new InvalidArgumentException('list values must be scalar strings');
            $s=trim((string)$item);
            if ($s === '' || strlen($s) > 240) throw new InvalidArgumentException('list value invalid');
            $out[]=$s;
        }
        $out=array_values(array_unique($out));
        sort($out,SORT_STRING);
        return $out;
    }

    /** @param array<string,mixed> $causal */
    private static function requiredCausal(array $causal, string $key): string
    {
        $value=trim((string)($causal[$key] ?? ''));
        if ($value === '' || strlen($value) > 80) throw new InvalidArgumentException($key.' required');
        return $value;
    }

    /** @param array<string,mixed> $value */
    private static function ksortRecursive(array &$value): void
    {
        foreach ($value as &$item) if (is_array($item)) self::ksortRecursive($item);
        unset($item);
        if (!array_is_list($value)) ksort($value);
    }
}
