# Integration Contracts

Optional integrations: Titan Assist context, Titan Assurance, Titan Autonomy, Titan Signal, Titan Command Bus and Titan Rewind. Absence must degrade to evidence capture/review without cross-domain mutation.
