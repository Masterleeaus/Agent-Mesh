<?php

declare(strict_types=1);

use App\Extensions\TitanAutonomy\System\Http\Controllers\AutonomyActionController;
use App\Extensions\TitanAutonomy\System\Http\Controllers\AutonomyDashboardController;
use App\Extensions\TitanAutonomy\System\Http\Controllers\AutonomyAdminController;
use App\Extensions\TitanAutonomy\System\Http\Controllers\AutonomyExecutionFeedbackController;
use App\Extensions\TitanAutonomy\System\Http\Controllers\AutonomyOperationsController;
use Illuminate\Support\Facades\Route;

Route::middleware(config('titan-autonomy.route_middleware', ['web', 'auth']))
    ->prefix(config('titan-autonomy.route_prefix', 'dashboard/titan-autonomy'))
    ->name('titan-autonomy.')
    ->group(function (): void {
        Route::get('/', [AutonomyDashboardController::class, 'index'])->name('index');
        Route::get('/capabilities/{capability}/{workflowKey?}', [AutonomyDashboardController::class, 'capability'])->name('capability');
        Route::get('/learning', [AutonomyDashboardController::class, 'learning'])->name('learning');
        Route::get('/operations', [AutonomyOperationsController::class, 'index'])->name('operations.index');
        Route::get('/operations/{correlationId}', [AutonomyOperationsController::class, 'show'])->name('operations.show');
        Route::post('/operations/{correlationId}/recheck', [AutonomyOperationsController::class, 'recheck'])->name('operations.recheck');
        Route::post('/operations/{correlationId}/review', [AutonomyOperationsController::class, 'review'])->name('operations.review');
        Route::get('/learning/export', [AutonomyActionController::class, 'export'])->name('learning.export');
        Route::get('/admin', [AutonomyAdminController::class, 'index'])->name('admin');
        Route::post('/admin', [AutonomyAdminController::class, 'update'])->name('admin.update');

        Route::post('/capabilities/{capability}/request-assurance', [AutonomyActionController::class, 'requestAssurance'])->name('capability.request-assurance');
        Route::post('/capabilities/{capability}/grant-next', [AutonomyActionController::class, 'grantNext'])->name('capability.grant-next');
        Route::post('/capabilities/{capability}/lower', [AutonomyActionController::class, 'lower'])->name('capability.lower');
        Route::post('/capabilities/{capability}/reset-learning', [AutonomyActionController::class, 'resetLearning'])->name('capability.reset-learning');
        Route::post('/learning/settings', [AutonomyActionController::class, 'updateLearningSettings'])->name('learning.settings');
        Route::post('/learning/preferences/clear', [AutonomyActionController::class, 'clearPreferences'])->name('learning.preferences.clear');
        Route::post('/executions/{correlationId}/feedback', [AutonomyExecutionFeedbackController::class, 'store'])->name('executions.feedback');
    });
