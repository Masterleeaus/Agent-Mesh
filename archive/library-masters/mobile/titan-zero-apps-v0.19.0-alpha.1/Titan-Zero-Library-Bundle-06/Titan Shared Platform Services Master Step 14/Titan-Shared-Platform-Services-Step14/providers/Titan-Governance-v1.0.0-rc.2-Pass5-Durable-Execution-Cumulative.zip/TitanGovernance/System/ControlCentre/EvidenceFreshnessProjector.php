<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ControlCentre;

use DateTimeImmutable;
use Throwable;

final class EvidenceFreshnessProjector
{
    /** @param list<array<string,mixed>> $records @return array<string,mixed> */
    public function project(array $records,array $context=[]):array
    {
        $now=$this->now($context);
        $threshold=max(1,(int)($context['fresh_after_seconds']??300));
        $items=[];$status='HEALTHY';$staleRequired=0;$invalid=0;$unknown=0;
        foreach(array_slice($records,0,500) as $record){
            if(!is_array($record))continue;
            $source=trim((string)($record['source']??'unknown')) ?: 'unknown';
            $required=(bool)($record['required']??false);
            $observed=$record['observed_at']??null;
            $freshness='UNKNOWN';$age=null;
            if(is_string($observed)&&trim($observed)!==''){
                try{
                    $at=new DateTimeImmutable($observed);
                    $age=max(0,$now->getTimestamp()-$at->getTimestamp());
                    $freshness=$age>$threshold?'STALE':'FRESH';
                }catch(Throwable){$freshness='INVALID';}
            }
            if($freshness==='STALE'&&$required){$staleRequired++;$status='DEGRADED';}
            if($freshness==='INVALID'){$invalid++;if($required)$status='DEGRADED';}
            if($freshness==='UNKNOWN')$unknown++;
            $items[]=['source'=>$source,'required'=>$required,'observed_at'=>$observed,'freshness'=>$freshness,'age_seconds'=>$age];
        }
        return ['status'=>$status,'threshold_seconds'=>$threshold,'stale_required'=>$staleRequired,'invalid'=>$invalid,'unknown'=>$unknown,'items'=>$items,'observed_at'=>$now->format(DATE_ATOM)];
    }

    private function now(array $context):DateTimeImmutable
    {
        $value=$context['now']??null;
        if(is_string($value)&&trim($value)!==''){try{return new DateTimeImmutable($value);}catch(Throwable){}}
        return new DateTimeImmutable('now');
    }
}
