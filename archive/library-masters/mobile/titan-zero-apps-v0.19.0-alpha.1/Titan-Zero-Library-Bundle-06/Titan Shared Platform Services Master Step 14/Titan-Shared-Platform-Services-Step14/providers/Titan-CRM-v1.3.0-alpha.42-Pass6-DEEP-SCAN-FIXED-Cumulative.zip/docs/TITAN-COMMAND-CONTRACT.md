# Titan BOS / Owner-Business Contract

## Status
**IMPLEMENTED at source/contract level.** `CrmOwnerDashboardGateway` targets the clean Titan BOS owner/business gateway and adds compact decision-ready CRM sections for Today, Dispatch, Customers, Leads, Money, Workforce, Approvals, Recurring, Reviews and Service Recovery.

`CrmOwnerActionGateway` exposes explicit actions rather than generic model updates: work-order assign/reschedule/cancel, quote approval, invoice issue, customer update, staff schedule and service update.

All owner calls bind trusted company/actor context and still pass CRM permission/capability authorization. A source-surface label such as `owner` is context only and never grants permission. Retried state-changing actions use CRM capability idempotency receipts.
