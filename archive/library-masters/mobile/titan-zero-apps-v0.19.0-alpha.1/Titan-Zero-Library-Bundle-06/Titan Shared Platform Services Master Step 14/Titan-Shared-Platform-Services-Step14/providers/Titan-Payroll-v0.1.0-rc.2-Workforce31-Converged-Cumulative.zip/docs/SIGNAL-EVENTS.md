# Signal Events

Titan Payroll emits privacy-minimized, tenant-scoped outbox facts with schema version `1.0` for:

- `payroll.run.prepared`
- `payroll.run.submitted`
- `payroll.run.approved`
- `payroll.run.rejected`
- `payroll.run.finalized`
- `payroll.variance.detected`
- `payroll.reconciliation.completed`
- `payroll.payslip.delivery.failed`
- `payroll.period.locked`
- `payroll.period.unlocked`

The outbox permits IDs, statuses, versions, source hashes and governance decision references. Bank account/routing values, tax identifiers, full payslips/documents, secrets and provider tokens are denied recursively. Rewind consumes only the privacy-minimized projection of these facts.
