<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

final class ContactTag extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use HasUuids;

    protected $table = 'ext_titan_connect_contact_tags';
    protected $fillable = ['uuid', 'company_id', 'name', 'color', 'background_color', 'created_by'];

    public function uniqueIds(): array { return ['uuid']; }
    public function threads(): BelongsToMany
    {
        return $this->belongsToMany(ExternalThread::class, 'ext_titan_connect_external_thread_tags', 'contact_tag_id', 'external_thread_id')
            ->withPivot('company_id')->withTimestamps();
    }
    public function getRouteKeyName(): string { return 'uuid'; }

}
