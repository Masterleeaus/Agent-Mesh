<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindRecoveryStep extends Model
{
    protected $table = 'titan_rewind_recovery_steps';
    protected $fillable = [
        'step_uuid','tenant_company_id','recovery_plan_id','step_order','step_type','status','execution_owner','requires_human','input','success_evidence','result',
    ];
    protected $casts = [
        'tenant_company_id'=>'integer','recovery_plan_id'=>'integer','step_order'=>'integer','requires_human'=>'boolean','input'=>'array','success_evidence'=>'array','result'=>'array',
    ];
}
