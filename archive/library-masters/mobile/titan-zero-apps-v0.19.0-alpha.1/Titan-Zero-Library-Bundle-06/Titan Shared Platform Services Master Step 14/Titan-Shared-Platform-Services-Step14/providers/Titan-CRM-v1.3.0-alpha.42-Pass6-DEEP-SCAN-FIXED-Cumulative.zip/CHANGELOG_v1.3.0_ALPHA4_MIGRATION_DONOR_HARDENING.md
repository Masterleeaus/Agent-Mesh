# CRM 1.3.0-alpha.4 — MySQL Migration Recovery + WorkCore Donor Intelligence

## Installer / migration fixes

- Repaired MySQL error 1059 caused by Laravel's generated index name `crm_service_recovery_cases_rebooking_service_request_public_id_index` exceeding MySQL's 64-character identifier limit.
- The service-recovery rebooking index now uses the explicit name `crm_recovery_rebook_req_idx`.
- Made all 29 table creations in migration `2026_08_09_000011_add_field_service_domains.php` restart-safe with `Schema::hasTable()` guards.
- Added targeted partial-DDL recovery for `crm_service_recovery_cases`: if the table exists from the failed alpha.3 run but the short index is absent, the migration creates the index through `information_schema.statistics` detection.
- Added permanent regression gates for MySQL identifier lengths, migration 000011 restartability and partial-index recovery.

## WorkCore donor code adapted into CRM

The following domain-pure WorkCore algorithms were transplanted into CRM namespaces. No WorkCore provider, tenancy resolver, runtime dependency, `tz_*` table or `tm_*` table is used.

### Titan Pay

- Integer minor-unit `Money` and validated `CurrencyCode` value objects.
- Bank-deposit-to-receivable ranking with explainable confidence scoring for exact amount, near amount, payment reference, payer hint, timing and duplicate evidence.
- Collection suppression decisions for paid, disputed, payment-plan, pending-payment-claim, paused, voided, credited and active promise-to-pay cases.
- Job profitability calculation covering revenue, labour, materials, other direct costs, total cost, profit and margin basis points.
- Governed calculation capabilities:
  - `crm.pay.reconciliation.rank`
  - `crm.pay.collection.suppression.evaluate`
  - `crm.pay.job_profitability.calculate`

### Titan Locker

- WorkCore-derived inventory quantity policy adapted to Locker reservation semantics.
- WorkCore-derived stock movement policy adapted to CRM Locker movement names and location rules.
- Allocation and stock movement services now consume those focused policies rather than duplicating validation logic.

## Scope

Alpha.4 deliberately does not add the schema-heavy WorkCore purchasing/PO/stock-count donor modules. Those are reserved for the next pass after the repaired live migration chain is confirmed on the Titan host.
