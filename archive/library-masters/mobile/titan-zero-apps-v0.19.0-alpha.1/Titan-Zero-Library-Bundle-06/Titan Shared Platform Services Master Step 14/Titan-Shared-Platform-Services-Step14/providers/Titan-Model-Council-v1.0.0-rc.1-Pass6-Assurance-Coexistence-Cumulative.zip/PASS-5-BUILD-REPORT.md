# Titan Model Council v0.6.0 — Pass 5 Build Report

## Scope

Pass 5 adds governed deliberation while retaining the existing parallel consensus compatibility engine.

Implemented role sequence:

1. Proposer
2. Critic
3. Verifier
4. Pre-arbiter validation
5. Arbiter
6. Final validation

## Governance and safety

- High/extreme Risk Engine outcomes and approval/block/reduced-authority decisions can raise activation to governed deliberation.
- Risk remains a floor: manual strategy selection cannot reduce stronger Risk requirements.
- Council outputs are advisory evidence only and never grant mutation authority.
- `BLOCK` and reduced-authority states are preserved into the governed result.
- Prior participant text is passed to later roles as explicitly untrusted analysis data, never system instructions.
- Verifier prompts prohibit pretending external fact verification occurred when only supplied evidence is available.
- No unrestricted hidden chain-of-thought is requested or stored.

## Billing and entitlement

- Council feature/plan entitlement is checked before governed execution.
- Every assigned model is checked for model entitlement and available credit before reservation/provider dispatch.
- Governed billing reservation is role-aware, so repeated model assignments cannot under-reserve role usage.
- Actual usage is settled once provider output charges are known, before later postflight audit operations.

## Titan Shield

The latest reviewed Titan Shield v0.2.0 exposes `InspectionEngineContract` and the inspection lifecycle domain. It does not yet publish a semantic/factual Council-verdict generator.

Model Council therefore:

- applies conservative local structural validation;
- blocks arbitration when required role artifacts are absent/failed;
- blocks final release when Arbiter output is absent/failed;
- records the structural observation through Shield's real inspection lifecycle when the peer contract is available;
- records the same tenant/trace/correlation/causation chain;
- does not invent a `validateCouncil()` or equivalent Shield API.

## Persistence

Added `titan_model_council_participants` for tenant-scoped role evidence and metrics. Decision records now expose pre-arbiter/final validation statuses and validation source.

## Provider runtime boundary

The available Titan AI Core v0.2.0 still does not publish a provider execution contract. Governed execution therefore uses `GovernedProviderRuntimeContract` backed by the preserved legacy provider runtime. This keeps the swap boundary explicit for the final integration pass.

## Verification boundary

Standalone regression/security runners and PHP syntax validation are executable inside this package. Full Laravel/MagicAI HTTP/database integration requires the host application/vendor tree, which is not included in the extension ZIP.
