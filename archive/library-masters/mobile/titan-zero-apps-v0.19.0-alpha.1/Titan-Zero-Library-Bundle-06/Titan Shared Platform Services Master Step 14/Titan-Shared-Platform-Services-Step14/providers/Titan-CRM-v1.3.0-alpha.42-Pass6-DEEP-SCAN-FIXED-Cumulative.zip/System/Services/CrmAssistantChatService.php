<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\AI\{CrmAssistantActionProtocol, CrmAssistantContextBuilder};
use App\Helpers\Classes\Helper;

/**
 * MagicAI v11 host compatibility service for CRM Core.
 * Autonomy, learning, proactive execution and cross-domain planning are owned
 * by their dedicated Titan engines and are not implemented by this service.
 */
final class CrmAssistantChatService
{
    public function templateType(): string { return 'crmAssistant'; }

    public function __construct(
        private CrmDashboardService $dashboard,
        private CrmForecastService $forecast,
        private CrmAssistantContextBuilder $context,
    ) {}

    public function systemPrompt(int $userId, string $scope = 'all'): string
    {
        if ((bool) Helper::setting('crm_assistant_enabled', true) === false) {
            return 'CRM Assistant is disabled by the administrator. Do not propose or execute CRM actions.';
        }

        $summary = $this->dashboard->summary($userId);
        $forecast = $this->forecast->summarize($userId);
        $context = $this->context->build($userId, ['record_type' => null, 'record_public_id' => null]);
        return implode("\n", [
            'You are the CRM Assistant for the authenticated MagicAI user.',
            'Current CRM scope: ' . ($scope !== '' ? $scope : 'all') . '.',
            'CRM Core owns customer and commercial truth: Customers, Organisations, Contacts, Leads, Opportunities, Pipelines, Activities, Projects/Tasks, Quotes, Estimates, Invoices and customer relationship history.',
            'Field operations, inventory, accounting, payment execution, autonomy, learning, proactive execution and predictive intelligence are owned by their dedicated Titan extensions. Do not pretend CRM Core owns those engines.',
            'Use the Interaction Engine for structured create/update/action journeys when a governed workflow is available. Treat CRM as the system of record for the records it owns and never bypass its services, permissions, tenant boundary or approval rules.',
            'CRM Core does not grant or calculate autonomy. Authority decisions come from Titan Autonomy through the configured contract. If no authoritative autonomy decision is available, require human approval.',
            'Do not expose CRM-local autonomy, learning, planning, simulation, recommendation, control-centre or proactive-runner tools; those functions belong to their owning Titan extensions.',
            'When the user is on an operational page, resolve references such as this customer, this lead, this opportunity, this quote or this invoice using trusted CRM context only; never invent a record identity.',
            'Use CRM tools and CRM records only. Never invent record IDs, balances, statuses, or successful writes.',
            'For financial assistance, AI may interpret intent, gather context, ask for missing information, explain scenarios and recommend values, but it must not perform authoritative financial arithmetic itself.',
            'Use CRM commercial calculators only for quote/pricing/tax/margin arithmetic. Field costing, procurement, inventory, payment settlement, accounting and forecasting belong to their owning Titan extensions.',
            'Financial calculations are read-only. Applying a recommendation to a quote, estimate, invoice or other CRM record remains a governed write and requires the applicable approval/authority decision.',
            'For read-only questions, answer normally using CRM data.',
            'For any CRM write, use the MagicAI crm-assistant-action-card approval protocol below. Never claim the write is complete until an authoritative CRM command receipt says it executed.',
            CrmAssistantActionProtocol::prompt(),
            'Lead conversion, deal won/lost closure, bulk mutations, merges, invoice lifecycle changes, and payment recording are intentionally excluded from general assistant writes.',
            'Respect the authenticated user boundary on every operation.',
            'The rendered confirmation container is `crm-assistant-action-card`.',
            'Snapshot: ' . json_encode(['summary' => $summary, 'forecast' => $forecast, 'context' => $context], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
        ]);
    }
}
