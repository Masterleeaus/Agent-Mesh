<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

/** Maps governed capability operations to authoritative CRM aggregate rows. */
final class CrmCapabilityResourceMap
{
    /** @return array{table:string,type:string,public_id:string}|null */
    public function before(string $capability,array $input): ?array
    {
        $id=$this->inputId($capability,$input);
        if($id==='')return null;
        $table=$this->table($capability,$input);
        return $table===null?null:['table'=>$table,'type'=>$this->type($table),'public_id'=>$id];
    }

    /** @return array{table:string,type:string,public_id:string}|null */
    public function after(string $capability,array $input,array $result,?array $before=null): ?array
    {
        if($before!==null)return $before;
        $table=$this->table($capability,$input);
        if($table===null)return null;
        $id=$this->resultId($capability,$result,$input);
        return $id===''?null:['table'=>$table,'type'=>$this->type($table),'public_id'=>$id];
    }

    private function table(string $capability,array $input): ?string
    {
        if(trim((string)($input['work_order_public_id']??''))!=='' && in_array($capability,[
            'crm.dispatch.transition','crm.form_submission.submit','crm.form_response.update','crm.time.create','crm.support.create',
        ],true))return 'crm_work_orders';
        if(str_starts_with($capability,'crm.customer.')){
            $kind=strtolower((string)($input['customer_kind']??$input['customer_type']??'individual'));
            return in_array($kind,['business','company','account'],true)?'crm_companies':'crm_contacts';
        }
        if(str_starts_with($capability,'crm.contact.'))return 'crm_contacts';
        if(str_starts_with($capability,'crm.company.'))return 'crm_companies';
        if(str_starts_with($capability,'crm.lead.'))return 'crm_leads';
        if(str_starts_with($capability,'crm.deal.'))return 'crm_deals';
        if(str_starts_with($capability,'crm.service_request.'))return 'crm_service_requests';
        if(str_starts_with($capability,'crm.work_order.'))return 'crm_work_orders';
        if(str_starts_with($capability,'crm.appointment.'))return 'crm_appointments';
        if(str_starts_with($capability,'crm.dispatch.'))return 'crm_dispatch_assignments';
        if(str_starts_with($capability,'crm.form_submission.'))return 'crm_form_submissions';
        if(str_starts_with($capability,'crm.asset.'))return 'crm_customer_assets';
        if(str_starts_with($capability,'crm.project.'))return 'crm_projects';
        if(str_starts_with($capability,'crm.activity.'))return 'crm_activities';
        if(str_starts_with($capability,'crm.note.'))return 'crm_notes';
        if(str_starts_with($capability,'crm.calendar.'))return 'crm_calendar_events';
        if(str_starts_with($capability,'crm.support.'))return 'crm_support_tickets';
        if(str_starts_with($capability,'crm.review.'))return 'crm_reviews';
        if(str_starts_with($capability,'crm.location.'))return 'crm_service_locations';
        if(str_starts_with($capability,'crm.service.'))return 'crm_services';
        if(str_starts_with($capability,'crm.task.'))return 'crm_tasks';
        if(str_starts_with($capability,'crm.document.render.')){
            return match((string)($input['type']??'')){'proposals'=>'crm_proposals','estimates'=>'crm_estimates','invoices'=>'crm_invoices',default=>null};
        }
        if(str_starts_with($capability,'crm.invoice.'))return 'crm_invoices';
        if(str_starts_with($capability,'crm.credit_note.'))return 'crm_credit_notes';
        if($capability==='crm.receivables.reconciliation_issue.resolve')return 'crm_receivable_reconciliation_issues';
        if(in_array($capability,['crm.payment.record','crm.payment.reconcile'],true))return 'crm_invoices';
        if(str_starts_with($capability,'crm.quote.')||str_starts_with($capability,'crm.estimate.')){
            return ((string)($input['type']??'estimates'))==='proposals'?'crm_proposals':'crm_estimates';
        }
        return null;
    }

    private function inputId(string $capability,array $input): string
    {
        $keys=['public_id','id','resource_id'];
        if(str_starts_with($capability,'crm.work_order.') || (trim((string)($input['work_order_public_id']??''))!=='' && in_array($capability,['crm.dispatch.transition','crm.form_submission.submit','crm.form_response.update','crm.time.create','crm.support.create'],true)))array_unshift($keys,'work_order_public_id');
        if(str_starts_with($capability,'crm.dispatch.'))array_unshift($keys,'dispatch_public_id');
        if(str_starts_with($capability,'crm.form_submission.'))array_unshift($keys,'submission_public_id');
        if(str_starts_with($capability,'crm.invoice.')||in_array($capability,['crm.payment.record','crm.payment.reconcile'],true))array_unshift($keys,'invoice_public_id');
        if($capability==='crm.credit_note.create')array_unshift($keys,'invoice_public_id');
        if(str_starts_with($capability,'crm.credit_note.')&&$capability!=='crm.credit_note.create')array_unshift($keys,'credit_note_public_id');
        if($capability==='crm.receivables.reconciliation_issue.resolve')array_unshift($keys,'issue_public_id');
        if(str_starts_with($capability,'crm.document.render.'))array_unshift($keys,'document_public_id');
        if(str_starts_with($capability,'crm.quote.')||str_starts_with($capability,'crm.estimate.'))array_unshift($keys,'quote_public_id','estimate_public_id','proposal_public_id');
        if(str_starts_with($capability,'crm.appointment.'))array_unshift($keys,'appointment_public_id');
        if(str_starts_with($capability,'crm.deal.'))array_unshift($keys,'deal_public_id');
        if(str_starts_with($capability,'crm.lead.'))array_unshift($keys,'lead_public_id');
        foreach($keys as $key){$v=trim((string)($input[$key]??''));if($v!=='')return $v;}
        return '';
    }

    private function resultId(string $capability,array $result,array $input): string
    {
        foreach(['public_id','record_id','id'] as $key){$v=trim((string)($result[$key]??''));if($v!=='')return $v;}
        if(str_starts_with($capability,'crm.customer.')){
            foreach(['contact','company'] as $nested){$v=trim((string)($result[$nested]['public_id']??''));if($v!=='')return $v;}
        }
        if(isset($result['invoice'])&&is_array($result['invoice'])){
            $v=trim((string)($result['invoice']['public_id']??''));if($v!=='')return $v;
        }
        return $this->inputId($capability,$input);
    }

    private function type(string $table): string { return str_replace('crm_','',$table); }
}
