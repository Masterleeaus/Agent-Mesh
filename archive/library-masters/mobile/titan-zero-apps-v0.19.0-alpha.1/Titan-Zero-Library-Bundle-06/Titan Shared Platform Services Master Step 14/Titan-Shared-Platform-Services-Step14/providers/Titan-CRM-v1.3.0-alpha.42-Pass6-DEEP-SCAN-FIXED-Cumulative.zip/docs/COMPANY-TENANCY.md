# Company Tenancy

## Contract
**IMPLEMENTED.** The canonical CRM tenant is the Titan business company and is stored as `tenant_company_id`.

The identities are deliberately distinct:

| Field | Meaning |
|---|---|
| `tenant_company_id` | Titan business using CRM; authoritative tenancy boundary |
| `company_id` | CRM customer/account-company relationship; never tenant authority |
| `user_id` | actor/legacy provenance compatibility; never tenant authority |
| `owner_user_id`, `assigned_user_id`, `worker_user_id`, etc. | real people/roles |

There are **83 tenant-owned table definitions** in `CrmTenantTableMap`; 78 belong to the 1.1 schema and five are new 1.2 tenant-owned contract/configuration tables. `crm_tenancy_migration_reviews` is deliberately not tenant-owned business state; it is an upgrade diagnostic ledger.

## Resolution rules
- Authenticated CRM traffic resolves company from trusted user/company membership.
- A custom host membership resolver can be configured.
- Multiple memberships without an active deterministic company selection fail closed.
- Missing membership fails closed.
- Caller `request('company_id')` is not tenant authority.
- `user_id` is never substituted for a missing company ID.
- Server-to-server integrations use `fromTrustedPlatform()` only after the calling platform has resolved the authoritative company context.

## Query isolation
Core models use `CrmCompanyScoped`; repositories/domain services have explicit `tenant_company_id` predicates for raw query-builder paths. External record lookups resolve by company plus stable resource identifier. Authorization verifies company + actor + capability + resource.

## Migration
Migration `2026_08_09_000013_add_company_tenancy_and_titan_contracts.php` adds nullable indexed `tenant_company_id` to 1.1 tenant-owned tables. It backfills only a deterministic one-company membership. Zero or multiple candidate companies remain NULL and receive a row in `crm_tenancy_migration_reviews`.

Migration `2026_08_09_000014_replace_legacy_user_tenant_unique_indexes.php` replaces legacy `user_id`-scoped uniqueness rules with company-scoped equivalents. Actor/assignee columns are not rewritten.

Run `php artisan crm:titan-company-tenancy:audit` after migration and before enabling production traffic. The audit is read-only.
