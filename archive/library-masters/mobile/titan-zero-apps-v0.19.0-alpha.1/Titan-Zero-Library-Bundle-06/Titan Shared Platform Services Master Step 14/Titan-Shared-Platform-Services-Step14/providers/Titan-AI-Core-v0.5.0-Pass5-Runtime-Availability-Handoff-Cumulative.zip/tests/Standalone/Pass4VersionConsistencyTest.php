<?php

declare(strict_types=1);
$root = dirname(__DIR__, 2);
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$rootManifest = json_decode((string) file_get_contents($root . '/extension.json'), true, flags: JSON_THROW_ON_ERROR);
$version = (string) ($manifest['version'] ?? '');
if ($version !== '0.5.0' || ($rootManifest['version'] ?? null) !== $version) {
    fwrite(STDERR, "Pass 4 package version mismatch\n"); exit(1);
}
foreach ([
    'System/DTO/PlanEnvelope.php',
    'System/DTO/ValidationReport.php',
    'System/Services/Orchestrator.php',
    'System/Services/HealthCheck.php',
    'System/Services/RuntimeManager.php',
    'System/Commands/CertifyExtensionCommand.php',
] as $relative) {
    $text = (string) file_get_contents($root . '/' . $relative);
    if (!str_contains($text, $version)) {
        fwrite(STDERR, "Runtime version not updated in {$relative}\n"); exit(1);
    }
}
fwrite(STDOUT, "Pass 4 version consistency test: PASS\n");
