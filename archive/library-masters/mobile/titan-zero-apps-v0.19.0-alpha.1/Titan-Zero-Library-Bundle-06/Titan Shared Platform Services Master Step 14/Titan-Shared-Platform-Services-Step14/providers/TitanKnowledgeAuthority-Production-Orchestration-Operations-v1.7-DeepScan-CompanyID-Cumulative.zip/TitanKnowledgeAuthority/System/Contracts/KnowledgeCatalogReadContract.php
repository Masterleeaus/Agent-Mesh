<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Contracts;

interface KnowledgeCatalogReadContract
{
    /** @return array<string, mixed>|null */
    public function sourceMetadata(string $sourceKey): ?array;

    /** @return array<string, mixed>|null */
    public function versionMetadata(int $versionId): ?array;
}
