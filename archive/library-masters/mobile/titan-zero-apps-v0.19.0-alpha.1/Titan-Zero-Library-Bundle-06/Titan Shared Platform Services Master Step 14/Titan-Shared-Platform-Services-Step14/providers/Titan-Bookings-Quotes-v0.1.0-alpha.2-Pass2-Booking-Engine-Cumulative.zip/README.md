# Titan Bookings & Quotes

Cumulative Pass 1 foundation release. This extension consolidates the useful commercial front-office concepts from the Titan Front Office Team donor bundle behind canonical Titan ownership boundaries.

`company_id` is the sole tenant/company boundary. Pass 1 establishes contracts and authority only; booking and quote persistence begins in later passes.
