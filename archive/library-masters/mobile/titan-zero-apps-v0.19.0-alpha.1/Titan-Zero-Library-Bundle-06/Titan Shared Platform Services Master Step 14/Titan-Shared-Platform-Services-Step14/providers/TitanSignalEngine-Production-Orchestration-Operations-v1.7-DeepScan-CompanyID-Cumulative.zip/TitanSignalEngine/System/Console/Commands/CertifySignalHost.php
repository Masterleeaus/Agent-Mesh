<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Console\Commands;

use App\Extensions\TitanSignalEngine\System\Services\SignalHostCertificationService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

final class CertifySignalHost extends Command
{
    protected $signature = 'titan:signal:certify
        {--strict : Treat production-only requirements such as MySQL and async queues as release blockers}
        {--probe-writes : Perform a temporary archive write/read/delete probe}
        {--output= : Optional storage-relative JSON report path}';

    protected $description = 'Run Titan Signal Engine production-host certification checks and emit a machine-readable report.';

    public function handle(SignalHostCertificationService $certification): int
    {
        $report = $certification->certify((bool) $this->option('probe-writes'), (bool) $this->option('strict'))->toArray();
        $json = json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $this->line($json);

        $output = trim((string) ($this->option('output') ?? ''));
        if ($output !== '') {
            Storage::disk('local')->put($output, $json . "\n");
            $this->info('Certification report written to storage/app/' . ltrim($output, '/'));
        }

        return $report['overall'] === 'FAIL' ? self::FAILURE : self::SUCCESS;
    }
}
