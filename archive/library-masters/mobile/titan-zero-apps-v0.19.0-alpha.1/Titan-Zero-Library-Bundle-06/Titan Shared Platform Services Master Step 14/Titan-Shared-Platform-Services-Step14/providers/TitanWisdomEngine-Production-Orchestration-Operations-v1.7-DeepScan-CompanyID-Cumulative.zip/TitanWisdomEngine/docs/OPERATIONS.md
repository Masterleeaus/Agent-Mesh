# Operations

Use `titan:titan-wisdom:certify --json` for non-destructive host checks.

Delayed outcome dispatcher:

```bash
php artisan titan:wisdom:dispatch-due-outcomes --limit=250
```

The runtime schedule executes the same dispatcher every five minutes with one-server and overlap protection. Jobs use the configured `titan-wisdom` queue, 5 attempts, exponential backoff and a 60-second timeout.

Runtime controls:

- `TITAN_WISDOM_ENGINE_ENABLED=false`: disables routes and schedule; data remains intact and certification remains available.
- `TITAN_WISDOM_OBSERVATION_DISPATCH_ENABLED=false`: leaves the runtime available but stops new due-observation dispatches.
- `TITAN_WISDOM_OBSERVATION_SCAN_LIMIT`: bounded 1–1000 scan size.
