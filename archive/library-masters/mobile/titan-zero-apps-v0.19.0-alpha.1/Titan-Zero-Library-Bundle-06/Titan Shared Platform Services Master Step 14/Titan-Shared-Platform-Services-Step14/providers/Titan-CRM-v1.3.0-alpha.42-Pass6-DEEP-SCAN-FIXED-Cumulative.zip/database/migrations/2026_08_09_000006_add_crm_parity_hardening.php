<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('crm_settings', function (Blueprint $t): void {
            $t->id(); $t->unsignedBigInteger('user_id')->index(); $t->string('key', 120); $t->json('value')->nullable(); $t->timestamps();
            $t->unique(['user_id','key']);
        });
        Schema::create('crm_audit_log', function (Blueprint $t): void {
            $t->id(); $t->char('public_id', 26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('actor_user_id')->nullable()->index();
            $t->string('action', 120)->index(); $t->string('subject_type', 60)->nullable()->index(); $t->char('subject_public_id', 26)->nullable()->index();
            $t->json('before')->nullable(); $t->json('after')->nullable(); $t->json('context')->nullable(); $t->dateTime('occurred_at')->index();
            $t->index(['user_id','subject_type','subject_public_id']);
        });
        Schema::create('crm_notification_outbox', function (Blueprint $t): void {
            $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->string('channel',30)->index();
            $t->string('recipient')->nullable(); $t->string('template_key',120)->index(); $t->string('subject_type',60)->nullable()->index(); $t->char('subject_public_id',26)->nullable()->index();
            $t->json('payload')->nullable(); $t->string('status',30)->default('pending')->index(); $t->unsignedInteger('attempts')->default(0); $t->text('last_error')->nullable();
            $t->timestamp('available_at')->nullable()->index(); $t->timestamp('sent_at')->nullable(); $t->timestamps();
        });
        Schema::create('crm_merge_log', function (Blueprint $t): void {
            $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('actor_user_id')->nullable()->index();
            $t->string('resource_type',40)->index(); $t->char('winner_public_id',26)->index(); $t->char('loser_public_id',26)->index();
            $t->json('merged_fields')->nullable(); $t->dateTime('merged_at')->index();
            $t->unique(['user_id','resource_type','loser_public_id']);
        });
        Schema::table('crm_leads', function (Blueprint $t): void {
            $t->unsignedTinyInteger('lead_score')->default(0)->index();
            $t->string('qualification_status',40)->default('unqualified')->index();
            $t->timestamp('next_follow_up_at')->nullable()->index();
            $t->timestamp('last_contacted_at')->nullable()->index();
        });
        Schema::table('crm_projects', function (Blueprint $t): void {
            $t->unsignedTinyInteger('progress_percent')->default(0)->index();
            $t->unsignedBigInteger('owner_user_id')->nullable()->index();
            $t->string('priority',20)->default('normal')->index();
        });
        Schema::table('crm_tasks', function (Blueprint $t): void {
            $t->string('priority',20)->default('normal')->index();
            $t->text('description')->nullable();
            $t->timestamp('completed_at')->nullable()->index();
            $t->string('subject_type',60)->nullable()->index();
            $t->char('subject_public_id',26)->nullable()->index();
        });
        Schema::table('crm_events', function (Blueprint $t): void {
            $t->string('subject_type',60)->nullable()->index();
            $t->char('subject_public_id',26)->nullable()->index();
            $t->string('location')->nullable();
            $t->text('description')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('crm_events', fn (Blueprint $t) => $t->dropColumn(['subject_type','subject_public_id','location','description']));
        Schema::table('crm_tasks', fn (Blueprint $t) => $t->dropColumn(['priority','description','completed_at','subject_type','subject_public_id']));
        Schema::table('crm_projects', fn (Blueprint $t) => $t->dropColumn(['progress_percent','owner_user_id','priority']));
        Schema::table('crm_leads', fn (Blueprint $t) => $t->dropColumn(['lead_score','qualification_status','next_follow_up_at','last_contacted_at']));
        Schema::dropIfExists('crm_merge_log');
        Schema::dropIfExists('crm_notification_outbox');
        Schema::dropIfExists('crm_audit_log');
        Schema::dropIfExists('crm_settings');
    }
};
