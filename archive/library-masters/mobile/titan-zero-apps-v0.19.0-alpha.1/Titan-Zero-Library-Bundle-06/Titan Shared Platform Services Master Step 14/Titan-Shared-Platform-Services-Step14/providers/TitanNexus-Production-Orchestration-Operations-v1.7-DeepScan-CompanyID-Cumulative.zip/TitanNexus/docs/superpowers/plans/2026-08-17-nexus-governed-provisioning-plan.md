# Titan Nexus Governed Provisioning Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build deterministic, idempotent provisioning plans and a fail-closed public Command Bus execution boundary with mandatory mutation-safety evidence.

**Architecture:** Extend the immutable VerticalDefinition with optional normalized route metadata, derive immutable provisioning operations from compiled state/diffs, persist plans on NexusCompilation, and execute only through an injected gateway contract. The executor remains dependency-aware and never performs direct foreign-engine writes.

**Tech Stack:** PHP 8.2+, Laravel 10+, MagicAI 10+, PHPUnit-compatible tests plus standalone PHP verification.

## Global Constraints

- Preserve all Pass 1–4 behavior and existing migration bytes.
- No direct imports from other Titan extension implementation namespaces.
- No direct writes to foreign tables or models.
- Every applied mutation must prove verified backup, verified write, audit reference, and rollback metadata.
- All plan, operation, receipt, and idempotency fingerprints must be deterministic SHA-256 over canonical JSON.
- Missing routes, malformed gateway responses, and missing public gateway bindings fail closed.

---

### Task 1: Provisioning policy and operation domain

**Files:**
- Modify: `System/Domain/VerticalDefinition.php`
- Create: `System/Domain/ProvisioningOperation.php`
- Create: `System/Domain/ProvisioningReceipt.php`
- Create: `System/Domain/ProvisioningReceiptStatus.php`
- Create: `System/Domain/ProvisioningPlan.php`
- Create: `System/Domain/ProvisioningPlanStatus.php`
- Test: `tests/standalone-provisioning-check.php`

**Interfaces:**
- Consumes: `SemanticChangeKind`, `SemanticChangeDisposition`, `CanonicalJson`.
- Produces: immutable normalized provisioning metadata and canonical plan artifacts.

- [ ] **Step 1: Write a failing standalone test** that constructs a vertical with routes, creates deterministic operations, verifies stable idempotency keys, rejects route dependency cycles, and round-trips plans.
- [ ] **Step 2: Run `php tests/standalone-provisioning-check.php`** and verify failure occurs because provisioning domain classes are absent.
- [ ] **Step 3: Implement the minimal domain classes and VerticalDefinition provisioning normalization** needed to satisfy the test.
- [ ] **Step 4: Re-run the standalone test** and verify the domain assertions pass.

### Task 2: Deterministic planner and persistence

**Files:**
- Create: `System/Contracts/ProvisioningPlannerContract.php`
- Create: `System/Services/DeterministicProvisioningPlanner.php`
- Modify: `System/Domain/NexusCompilation.php`
- Modify: `System/Services/NexusManager.php`
- Modify: `System/Contracts/NexusManagerContract.php`
- Test: `tests/standalone-provisioning-check.php`

**Interfaces:**
- Consumes: compiled configuration, optional `ConfigurationDiff`, exact `VerticalDefinition`.
- Produces: `planProvisioning(NexusCompilation $compiled): NexusCompilation` with immutable attached `ProvisioningPlan`.

- [ ] **Step 1: Extend the failing test** for initial plan generation, recompile plan generation, route coverage blocking and persistence round-trip.
- [ ] **Step 2: Run the test** and verify failure on missing planner/manager behavior.
- [ ] **Step 3: Implement deterministic planner, manager orchestration and NexusCompilation plan persistence.**
- [ ] **Step 4: Re-run tests** and verify planning behavior passes without executing mutations.

### Task 3: Public Command Bus adapter and governed executor

**Files:**
- Create: `System/Contracts/ProvisioningCommandGatewayContract.php`
- Create: `System/Contracts/ProvisioningExecutorContract.php`
- Create: `System/Adapters/CommandBus/CommandBusProvisioningAdapter.php`
- Create: `System/Services/GovernedProvisioningExecutor.php`
- Modify: `System/Services/NexusManager.php`
- Modify: `System/Contracts/NexusManagerContract.php`
- Modify: `config/titan-nexus.php`
- Modify: `System/TitanNexusServiceProvider.php`
- Test: `tests/standalone-provisioning-check.php`

**Interfaces:**
- Consumes: `ProvisioningPlan`, `TraceContext`, configured public gateway callable.
- Produces: immutable executed plan/receipts; no direct database mutation.

- [ ] **Step 1: Extend the failing test** for approval rejection, verified applied receipts, malformed backup proof rejection, already-applied idempotency, failure continuation, and dependent skips.
- [ ] **Step 2: Run the test** and verify failure on missing execution classes.
- [ ] **Step 3: Implement adapter validation and dependency-aware executor.**
- [ ] **Step 4: Re-run the test** and verify execution safety assertions pass.

### Task 4: Package truth, PHPUnit mirrors, and verification

**Files:**
- Create: `tests/Unit/ProvisioningTest.php`
- Modify: `tests/standalone-package-check.php`
- Modify: `README.md`
- Modify: `extension.json`
- Modify: `extension.manifest.json`
- Modify: `resources/views/index.blade.php`
- Modify: `resources/views/admin.blade.php`

**Interfaces:**
- Consumes: completed Pass-5 public API.
- Produces: truthful v0.6.0 package metadata and verification coverage.

- [ ] **Step 1: Add PHPUnit-compatible core provisioning tests and package assertions.**
- [ ] **Step 2: Run all standalone suites and PHP lint.**
- [ ] **Step 3: Verify JSON, production-boundary safety, and byte-identical Pass-1–4 migrations.**
- [ ] **Step 4: Build the cumulative ZIP, re-extract it, and repeat the complete verification suite.**
