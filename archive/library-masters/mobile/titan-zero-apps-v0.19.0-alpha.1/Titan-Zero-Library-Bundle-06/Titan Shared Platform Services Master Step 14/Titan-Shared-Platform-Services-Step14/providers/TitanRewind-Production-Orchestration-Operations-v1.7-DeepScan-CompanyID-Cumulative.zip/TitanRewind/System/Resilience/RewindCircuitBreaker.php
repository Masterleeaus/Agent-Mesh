<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Resilience;

final readonly class RewindCircuitBreaker
{
    public function __construct(private int $failureThreshold = 5, private int $resetSeconds = 60) {}
    public function afterFailure(string $state, int $failureCount, int $now): array
    {
        $count=$failureCount+1;
        if (strtoupper($state)==='HALF_OPEN') return ['state'=>'OPEN','failure_count'=>max($count,$this->failureThreshold),'next_probe_at'=>$now+$this->resetSeconds];
        if ($count >= $this->failureThreshold) return ['state'=>'OPEN','failure_count'=>$count,'next_probe_at'=>$now+$this->resetSeconds];
        return ['state'=>'CLOSED','failure_count'=>$count,'next_probe_at'=>null];
    }
    public function afterSuccess(): array { return ['state'=>'CLOSED','failure_count'=>0,'next_probe_at'=>null]; }
    public function canAttempt(string $state, ?int $nextProbeAt, int $now): array
    {
        $state=strtoupper($state); if ($state==='CLOSED') return ['allowed'=>true,'state'=>'CLOSED'];
        if ($state==='OPEN' && $nextProbeAt!==null && $now >= $nextProbeAt) return ['allowed'=>true,'state'=>'HALF_OPEN'];
        if ($state==='HALF_OPEN') return ['allowed'=>true,'state'=>'HALF_OPEN'];
        return ['allowed'=>false,'state'=>'OPEN'];
    }
}
