<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\DTO;

/**
 * Trusted execution context for a single company.
 *
 * The constructor keeps the legacy $tenantCompanyId parameter name so older
 * named-argument callers remain source-compatible. New runtime code must use
 * $companyId; $tenantCompanyId is a deprecated compatibility alias only.
 */
final readonly class CommandContext
{
    public int $companyId;
    public int $tenantCompanyId;

    public function __construct(
        int $tenantCompanyId,
        public string $actorType,
        public int|string|null $actorId,
        public string $serviceId,
    ) {
        if ($tenantCompanyId < 1) {
            throw new \InvalidArgumentException('company_id must be a positive integer.');
        }
        if ($actorType === '' || $serviceId === '') {
            throw new \InvalidArgumentException('actor_type and service_id are required.');
        }
        $this->companyId = $tenantCompanyId;
        $this->tenantCompanyId = $tenantCompanyId;
    }

    public static function forCompany(int $companyId, string $actorType, int|string|null $actorId, string $serviceId): self
    {
        return new self($companyId, $actorType, $actorId, $serviceId);
    }

    public function toAuditArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'actor_type' => $this->actorType,
            'actor_id' => $this->actorId,
            'service_id' => $this->serviceId,
        ];
    }
}
