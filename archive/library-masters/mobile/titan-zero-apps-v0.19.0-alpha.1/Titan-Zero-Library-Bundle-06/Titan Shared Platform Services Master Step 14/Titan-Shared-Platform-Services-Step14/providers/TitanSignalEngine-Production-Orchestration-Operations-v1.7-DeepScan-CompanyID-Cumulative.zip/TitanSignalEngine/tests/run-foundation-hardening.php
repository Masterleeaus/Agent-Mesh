<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/SignalSeverity.php';
require __DIR__ . '/../System/Data/SignalActor.php';
require __DIR__ . '/../System/Data/SignalEmitterIdentity.php';
require __DIR__ . '/../System/Data/SignalContext.php';
require __DIR__ . '/../System/Data/EventTypeDefinition.php';
require __DIR__ . '/../System/Data/SignalEnvelope.php';
require __DIR__ . '/../System/Contracts/SignalEmitterAuthorityContract.php';
require __DIR__ . '/../System/Services/SignalEmitterAuthority.php';
require __DIR__ . '/../System/Services/SignalContextValidator.php';
require __DIR__ . '/../System/Services/SignalPayloadGuard.php';

use App\Extensions\TitanSignalEngine\System\Data\EventTypeDefinition;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEmitterIdentity;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalSeverity;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;
use App\Extensions\TitanSignalEngine\System\Services\SignalPayloadGuard;

function assertTrue(bool $condition, string $message): void {
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

function expectInvalid(callable $callback, string $message): void {
    try {
        $callback();
    } catch (InvalidArgumentException) {
        return;
    }
    throw new RuntimeException($message);
}

$root = SignalEnvelope::fromArray([
    'event_type' => 'command.requested',
    'tenant_company_id' => 42,
    'source' => 'titan-command-bus',
    'severity' => 'info',
    'payload' => ['command_id' => 7],
]);
assertTrue($root->envelopeVersion === '1.0', 'Envelope version must default to 1.0.');
assertTrue($root->checksumAlgorithm === 'sha256', 'Checksum algorithm must be explicit SHA-256.');
assertTrue($root->rootCausationId === $root->eventId, 'Root event must identify itself as the root causation event.');
assertTrue(substr($root->eventId, 14, 1) === '7', 'Generated event IDs must be UUIDv7.');
assertTrue($root->verifyChecksum(), 'Fresh envelope checksum must verify.');

$child = $root->child('risk.assessed', 'titan-risk-engine', ['risk' => 'low'], ['severity' => 'warn']);
assertTrue($child->rootCausationId === $root->eventId, 'Child must inherit root causation.');
assertTrue($child->causationId === $root->eventId, 'Child must point to its immediate parent.');
assertTrue($child->severity === 'warn', 'Whitelisted child severity override must be allowed.');
expectInvalid(
    fn () => $root->child('risk.assessed', 'titan-risk-engine', [], ['root_causation_id' => $child->eventId]),
    'Child must not override root causation.'
);

$tampered = SignalEnvelope::fromPersistenceArray([
    ...$root->toArray(),
    'payload' => ['command_id' => 999],
    'checksum' => $root->checksum,
]);
assertTrue(! $tampered->verifyChecksum(), 'Checksum verification must detect payload tampering.');
assertTrue(SignalSeverity::fromName('critical')->weight() > SignalSeverity::fromName('warn')->weight(), 'Severity weights must be ordered.');
expectInvalid(
    fn () => SignalEnvelope::fromArray([
        'event_type' => 'x.invalid',
        'tenant_company_id' => 42,
        'source' => 'test',
        'severity' => 'banana',
    ]),
    'Unknown severity must be rejected.'
);

$definition = EventTypeDefinition::fromArray([
    'event_type' => 'command.requested',
    'current_schema_version' => 1,
    'category' => 'command',
    'allowed_scopes' => ['tenant'],
    'required_payload_fields' => ['command_id'],
    'optional_payload_fields' => ['capability'],
    'allow_additional_payload_fields' => false,
    'owner_source' => 'titan-command-bus',
]);
$definition->validate($root);
expectInvalid(
    fn () => $definition->validate(SignalEnvelope::fromArray([
        'event_type' => 'command.requested',
        'tenant_company_id' => 42,
        'source' => 'titan-command-bus',
        'payload' => [],
    ])),
    'Registry definition must reject missing required payload fields.'
);

$authority = new SignalEmitterAuthority('foundation-test-secret', [
    'test-command-ui' => [
        'source' => 'titan-command',
        'source_component' => null,
        'permissions' => ['signal.emit'],
        'event_type_patterns' => ['ui.*'],
    ],
]);
$context = SignalContext::tenantHuman(42, 'usr_1', 'session_1', 'titan-auth', $authority->issue('test-command-ui'));
$validator = new SignalContextValidator($authority);
$trusted = $validator->applyToInput([
    'event_type' => 'ui.action',
    'tenant_company_id' => 42,
    'source' => 'titan-command',
    'actor_type' => 'human',
    'actor_id' => 'usr_1',
], $context);
assertTrue($trusted['actor_id'] === 'usr_1', 'Trusted actor must be preserved.');
expectInvalid(
    fn () => $validator->applyToInput([
        'event_type' => 'ui.action',
        'tenant_company_id' => 42,
        'source' => 'titan-command',
        'actor_type' => 'human',
        'actor_id' => 'usr_2',
    ], $context),
    'Actor spoofing must be rejected.'
);
expectInvalid(
    fn () => $validator->applyToInput([
        'event_type' => 'ui.action',
        'tenant_company_id' => 99,
        'source' => 'titan-command',
    ], $context),
    'Tenant spoofing must be rejected.'
);

$guard = new SignalPayloadGuard(64, 64, ['chain_of_thought', 'hidden_reasoning', 'scratchpad']);
$guard->assertAllowed(['ok' => true], ['trace' => 'safe']);
expectInvalid(fn () => $guard->assertAllowed(['chain_of_thought' => 'private'], []), 'Hidden reasoning field must be rejected.');
expectInvalid(fn () => $guard->assertAllowed(['blob' => str_repeat('x', 128)], []), 'Oversized payload must be rejected.');

fwrite(STDOUT, "foundation-hardening-behavior: PASS\n");
