<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Repositories;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use App\Extensions\Crm\System\Contracts\LeadRepositoryContract;
use App\Extensions\Crm\System\Services\{CrmActivityRecorder,CrmDuplicateDetector,CrmIdentityAuthorityService,CrmDuplicateReviewService,LeadLifecycleService};
use App\Extensions\Crm\System\Support\CrmNormalizer;
use App\Extensions\Crm\System\Automation\Events\CrmAutomationTriggered;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

final class EloquentLeadRepository implements LeadRepositoryContract
{
    public function __construct(private ConnectionInterface $db, private CrmDuplicateDetector $duplicates, private LeadLifecycleService $lifecycle, private CrmActivityRecorder $activities, private CrmIdentityAuthorityService $identity, private CrmDuplicateReviewService $reviews) {}

    public function search(int $userId, array $filters=[]): array
    {
        $query = $this->db->table(config('crm.tables.leads'))->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at');
        if (($filters['status'] ?? null) !== null) $query->where('status',$filters['status']);
        if (($filters['qualification_status'] ?? null) !== null) $query->where('qualification_status',$filters['qualification_status']);
        if (($filters['follow_up_due'] ?? false)) $query->whereNotNull('next_follow_up_at')->where('next_follow_up_at','<=',now());
        if (($filters['q'] ?? null) !== null) {
            $term = '%' . trim((string)$filters['q']) . '%';
            $query->where(fn($q)=>$q->where('name','like',$term)->orWhere('email','like',$term)->orWhere('company_name','like',$term));
        }
        return $query->orderByDesc('id')->limit(min((int)($filters['limit'] ?? 100),250))->get()->map(fn($r)=>(array)$r)->all();
    }

    public function find(int $userId, string $publicId): array
    {
        $row = $this->db->table(config('crm.tables.leads'))->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at')->first();
        if (! $row) throw \Illuminate\Validation\ValidationException::withMessages(['lead'=>['Lead not found.']]);
        return (array) $row;
    }

    public function create(int $userId, int $actorUserId, array $data): array
    {
        $email=CrmNormalizer::email($data['email']??null); $phone=CrmNormalizer::phone($data['phone']??null);$candidates=$this->duplicates->leadCandidates($userId,$email,$phone);
        $publicId=(string)Str::ulid();$root=(string)Str::ulid();
        $id=$this->db->table(config('crm.tables.leads'))->insertGetId([
            'public_id'=>$publicId,'customer_unification_id'=>$root,'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'name'=>(string)$data['name'],'email'=>$email,'normalized_email'=>$email,
            'phone'=>$phone,'normalized_phone'=>$phone,'company_name'=>$data['company_name']??null,'notes'=>$data['notes']??null,
            'status'=>$data['status']??'new','source'=>$data['source']??null,'owner_user_id'=>$data['owner_user_id']??$actorUserId,
            'priority'=>(int)($data['priority']??0),'follow_up_at'=>$data['follow_up_at']??null,'meta'=>json_encode(['duplicate_candidates'=>$candidates]),
            'created_at'=>now(),'updated_at'=>now(),
        ]);
        $this->identity->syncSubjectIdentities($userId,'lead',$publicId,$root,$email,$phone);foreach($candidates as $candidate)if(isset($candidate['public_id']))$this->reviews->queueForPair($userId,'lead',$publicId,'lead',(string)$candidate['public_id']);
        $this->activities->record($userId,'lead',$publicId,'created','Lead created',null,null,null,null,$actorUserId);
        event(new CrmAutomationTriggered($userId,'lead.created',['subject_type'=>'lead','subject_public_id'=>$publicId,'idempotency_key'=>'lead.created:'.$publicId]));
        return (array)$this->db->table(config('crm.tables.leads'))->where('id',$id)->first();
    }
    public function update(int $userId,string $publicId,int $actorUserId,array $data): array { return $this->lifecycle->update($userId,$publicId,$actorUserId,$data); }
    public function convert(int $userId,string $publicId,int $actorUserId): array { return $this->lifecycle->convert($userId,$publicId,$actorUserId); }
}
