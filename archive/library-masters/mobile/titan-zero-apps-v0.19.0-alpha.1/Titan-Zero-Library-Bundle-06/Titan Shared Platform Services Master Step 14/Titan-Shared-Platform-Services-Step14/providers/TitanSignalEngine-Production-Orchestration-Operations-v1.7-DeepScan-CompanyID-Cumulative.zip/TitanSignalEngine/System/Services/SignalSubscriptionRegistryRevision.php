<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Models\SignalSubscriptionRegistryState;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class SignalSubscriptionRegistryRevision
{
    private const KEY = 'subscriptions';
    private const CACHE_KEY = 'titan-signal-engine:subscription-registry-revision';

    public function current(): int
    {
        if (! Schema::hasTable('titan_signal_subscription_registry_state')) return 0;
        $ttl = max(1, min((int) config('titan-signal-engine.subscription_registry_cache_ttl_seconds', 5), 300));
        return (int) Cache::remember(self::CACHE_KEY, $ttl, function (): int {
            return (int) (SignalSubscriptionRegistryState::query()->where('registry_key', self::KEY)->value('revision') ?? 0);
        });
    }

    public function bump(): int
    {
        if (! Schema::hasTable('titan_signal_subscription_registry_state')) return 0;
        $revision = DB::transaction(function (): int {
            /** @var SignalSubscriptionRegistryState|null $state */
            $state = SignalSubscriptionRegistryState::query()->where('registry_key', self::KEY)->lockForUpdate()->first();
            if ($state === null) {
                $state = SignalSubscriptionRegistryState::query()->create(['registry_key' => self::KEY, 'revision' => 1]);
                return 1;
            }
            $state->revision = (int) $state->revision + 1;
            $state->save();
            return (int) $state->revision;
        }, 3);

        Cache::forget(self::CACHE_KEY);
        if (DB::transactionLevel() > 0) {
            DB::afterCommit(static fn (): bool => Cache::forget(self::CACHE_KEY));
        }
        return $revision;
    }
}
