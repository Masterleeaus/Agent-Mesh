<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Repositories;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Contracts\ProjectRepositoryContract; use Illuminate\Database\ConnectionInterface; use Illuminate\Support\Str;
final class EloquentProjectRepository implements ProjectRepositoryContract {
 public function __construct(private ConnectionInterface $db){}
 public function search(int $userId,array $filters=[]): array { $q=$this->db->table('crm_projects')->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at'); if($v=$filters['status']??null)$q->where('status',$v); if($v=$filters['q']??null)$q->where('name','like','%'.trim((string)$v).'%'); return $q->orderByRaw("CASE priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 WHEN 'normal' THEN 3 ELSE 4 END")->orderBy('due_on')->limit(min((int)($filters['limit']??100),250))->get()->map(fn($r)=>(array)$r)->all(); }
 public function create(int $userId,array $data): array { $id=$this->db->table('crm_projects')->insertGetId(['public_id'=>(string)Str::ulid(),'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'name'=>(string)$data['name'],'status'=>$data['status']??'active','company_public_id'=>$data['company_public_id']??null,'deal_public_id'=>$data['deal_public_id']??null,'description'=>$data['description']??null,'starts_on'=>$data['starts_on']??null,'due_on'=>$data['due_on']??null,'progress_percent'=>(int)($data['progress_percent']??0),'owner_user_id'=>$data['owner_user_id']??$userId,'priority'=>$data['priority']??'normal','meta'=>json_encode($data['meta']??[]),'created_at'=>now(),'updated_at'=>now()]); return (array)$this->db->table('crm_projects')->where('id',$id)->first(); }
}
