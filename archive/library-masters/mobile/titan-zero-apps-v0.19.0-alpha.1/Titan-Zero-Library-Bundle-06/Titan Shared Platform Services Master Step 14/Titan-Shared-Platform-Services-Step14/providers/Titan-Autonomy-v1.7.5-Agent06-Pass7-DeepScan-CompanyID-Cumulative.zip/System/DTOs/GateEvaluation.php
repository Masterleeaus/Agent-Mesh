<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\DTOs;

final readonly class GateEvaluation
{
    public function __construct(
        public bool $eligible,
        public int $requiredSuccessStreak,
        public array $reasonCodes = [],
    ) {}
}
