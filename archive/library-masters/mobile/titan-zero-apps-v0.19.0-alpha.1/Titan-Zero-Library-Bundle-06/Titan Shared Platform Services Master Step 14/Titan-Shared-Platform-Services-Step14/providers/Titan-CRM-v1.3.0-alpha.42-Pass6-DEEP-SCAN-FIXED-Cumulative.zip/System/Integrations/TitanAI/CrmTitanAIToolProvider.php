<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\TitanAI;

use App\Extensions\Crm\System\Governance\CrmCommandBusGateway;
use App\Extensions\Crm\System\Capabilities\CrmCapabilityRegistry;
use App\Extensions\Crm\System\Tenancy\CrmCompanyContext;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

/** Governed CRM tool provider for standalone TitanAI. No raw Eloquent/database handle is exposed. */
final class CrmTitanAIToolProvider
{
    private const READS = [
        'crm.ai.context.read','crm.customer.search','crm.customer.read','crm.quote.read','crm.invoice.read','crm.invoice.status',
        'crm.finance.formula_rules.calculate','crm.finance.pricing.calculate','crm.finance.quote_estimate.calculate',
        'crm.finance.discount_promotion.calculate','crm.finance.margin_profitability.calculate','crm.finance.tax.calculate',
    ];
    private const WRITES = [
        'crm.customer.create','crm.quote.prepare',
    ];

    public function __construct(
        private CrmCapabilityRegistry $registry,
        private CrmCommandBusGateway $commands,
        private CrmCompanyScope $companyScope,
    ) {}

    /** @return array<string,array<string,mixed>> */
    public function readTools(): array { return $this->tools(self::READS); }
    /** @return array<string,array<string,mixed>> */
    public function writeTools(): array { return $this->tools(self::WRITES); }
    /** @return array<string,array<string,mixed>> */
    public function all(): array { return $this->readTools()+$this->writeTools(); }

    public function execute(string $tool,array $payload,CrmCompanyContext $trustedContext): array
    {
        if(!isset($this->all()[$tool])) throw new \InvalidArgumentException("Unknown CRM TitanAI tool: {$tool}");
        return $this->companyScope->runWith($trustedContext,fn()=>$this->commands->request($tool,$payload,'ai'));
    }

    private function tools(array $ids): array
    {
        $out=[];foreach($ids as $id){$d=$this->registry->definition($id);$out[$id]=[
            'id'=>$id,'name'=>$id,'operation'=>$id,'mode'=>$d['mode'],'permissions'=>[$d['permission']],
            'requires_approval'=>$d['mode']==='write','idempotent'=>$d['idempotent'],'description'=>$d['description'],
            'input_schema'=>['type'=>'object','additionalProperties'=>true],
        ];}return $out;
    }
}
