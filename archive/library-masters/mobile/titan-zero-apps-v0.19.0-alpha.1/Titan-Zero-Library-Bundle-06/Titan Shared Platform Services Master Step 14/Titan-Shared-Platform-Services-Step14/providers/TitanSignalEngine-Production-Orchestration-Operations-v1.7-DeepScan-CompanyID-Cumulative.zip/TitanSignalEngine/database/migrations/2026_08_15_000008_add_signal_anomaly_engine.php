<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_pulse_trace_event_counts')) {
            Schema::create('titan_signal_pulse_trace_event_counts', function (Blueprint $table): void {
                $table->id();
                $table->uuid('trace_id');
                $table->string('event_type', 160);
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->unsignedBigInteger('event_count')->default(0);
                $table->dateTime('first_occurred_at');
                $table->dateTime('last_occurred_at');
                $table->timestamps();
                $table->unique(['trace_id', 'event_type', 'scope', 'tenant_key'], 'tsptec_trace_type_uq');
                $table->index(['scope', 'tenant_key', 'event_count', 'last_occurred_at'], 'tsptec_loop_scan_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_pulse_causation_refs')) {
            Schema::create('titan_signal_pulse_causation_refs', function (Blueprint $table): void {
                $table->id();
                $table->uuid('child_event_id')->unique('tspcr_child_uq');
                $table->uuid('parent_event_id');
                $table->uuid('trace_id');
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->boolean('resolved')->default(false);
                $table->dateTime('occurred_at');
                $table->timestamp('resolved_at')->nullable();
                $table->timestamps();
                $table->index(['scope', 'tenant_key', 'resolved', 'occurred_at'], 'tspcr_integrity_scan_idx');
                $table->index(['parent_event_id', 'resolved'], 'tspcr_parent_resolved_idx');
                $table->index(['trace_id', 'scope', 'tenant_key'], 'tspcr_trace_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_trace_evaluations')) {
            Schema::create('titan_signal_trace_evaluations', function (Blueprint $table): void {
                $table->id();
                $table->uuid('trace_id');
                $table->uuid('correlation_id')->nullable();
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->string('profile_key', 160);
                $table->unsignedInteger('profile_version');
                $table->string('status', 24);
                $table->unsignedInteger('event_count')->default(0);
                $table->unsignedInteger('sequence_violation_count')->default(0);
                $table->unsignedInteger('missing_event_count')->default(0);
                $table->unsignedInteger('missing_parent_count')->default(0);
                $table->unsignedInteger('causal_cycle_count')->default(0);
                $table->unsignedInteger('profile_violation_count')->default(0);
                $table->dateTime('evaluated_at');
                $table->timestamps();
                $table->unique(['trace_id', 'scope', 'tenant_key', 'profile_key', 'profile_version'], 'tste_trace_profile_uq');
                $table->index(['scope', 'tenant_key', 'sequence_violation_count', 'evaluated_at'], 'tste_sequence_scan_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_anomaly_scan_state')) {
            Schema::create('titan_signal_anomaly_scan_state', function (Blueprint $table): void {
                $table->string('scan_key', 80)->primary();
                $table->unsignedBigInteger('cursor_tenant_company_id')->default(0);
                $table->timestamp('last_completed_at')->nullable();
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('titan_signal_anomalies')) {
            Schema::create('titan_signal_anomalies', function (Blueprint $table): void {
                $table->id();
                $table->uuid('anomaly_id')->unique('tsa_anomaly_uq');
                $table->char('deduplication_key', 64)->unique('tsa_dedup_uq');
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->string('anomaly_type', 100);
                $table->string('severity', 20);
                $table->unsignedSmallInteger('score')->default(0);
                $table->decimal('confidence', 5, 4)->default(0);
                $table->string('subject_type', 80);
                $table->string('subject_id', 255);
                $table->string('status', 24)->default('open');
                $table->json('evidence');
                $table->unsignedBigInteger('occurrence_count')->default(1);
                $table->dateTime('first_detected_at');
                $table->dateTime('last_detected_at');
                $table->timestamp('acknowledged_at')->nullable();
                $table->string('acknowledged_by', 191)->nullable();
                $table->timestamp('suppressed_until')->nullable();
                $table->string('suppressed_by', 191)->nullable();
                $table->string('suppression_reason', 255)->nullable();
                $table->timestamp('resolved_at')->nullable();
                $table->string('resolved_by', 191)->nullable();
                $table->string('resolution_reason', 255)->nullable();
                $table->timestamp('reopened_at')->nullable();
                $table->timestamps();
                $table->index(['scope', 'tenant_key', 'status', 'score', 'last_detected_at'], 'tsa_feed_idx');
                $table->index(['scope', 'tenant_key', 'anomaly_type', 'last_detected_at'], 'tsa_type_idx');
                $table->index(['suppressed_until', 'status'], 'tsa_suppression_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_anomalies');
        Schema::dropIfExists('titan_signal_anomaly_scan_state');
        Schema::dropIfExists('titan_signal_trace_evaluations');
        Schema::dropIfExists('titan_signal_pulse_causation_refs');
        Schema::dropIfExists('titan_signal_pulse_trace_event_counts');
    }
};
