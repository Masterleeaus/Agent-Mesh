<?php

declare(strict_types=1);

use App\Extensions\Crm\System\Navigation\CrmMenuInstaller;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('menus')) {
            return;
        }

        CrmMenuInstaller::sync();
    }

    public function down(): void
    {
        if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key') || ! Schema::hasColumn('menus', 'label')) {
            return;
        }

        $previousLabels = [
            'ext_crm_sales' => 'Sales',
            'crm_portal' => 'Customer Portal',
            'crm_deals' => 'Deals',
            'crm_sales_proposals' => 'Proposals',
            'crm_work_orders' => 'Work Orders',
        ];

        foreach ($previousLabels as $key => $label) {
            $updates = ['label' => $label];
            if (Schema::hasColumn('menus', 'updated_at')) {
                $updates['updated_at'] = now();
            }
            DB::table('menus')->where('key', $key)->update($updates);
        }
    }
};
