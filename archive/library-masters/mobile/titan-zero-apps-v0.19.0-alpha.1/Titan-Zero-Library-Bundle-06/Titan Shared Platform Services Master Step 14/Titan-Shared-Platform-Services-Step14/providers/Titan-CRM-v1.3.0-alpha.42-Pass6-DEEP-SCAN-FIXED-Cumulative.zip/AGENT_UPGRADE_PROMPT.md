# TITAN CRM CORE — ALPHA.36 CANONICAL COMPANY TENANCY AGENT HANDOFF

Continue **Titan CRM Core v1.3.0-alpha.36** as the authoritative customer/commercial CRM. Deep-scan before modifying anything and preserve all current authority boundaries.

## CRM Core authority
CRM owns customers, organisations, contacts, customer-unification roots, leads, deals, pipelines, CRM coordination projects/tasks/calendar, commercial catalogue definitions, quotes, estimates, invoices, receivables business state, customer/commercial history, portal/import/integration metadata, CRM CQRS and governed CRM capabilities.

CRM does **not** own Titan Field, Locker, Ledger, Pay, Autonomy, AI Core planning, AI Workforce proactive execution, Wisdom learning, Signal, Risk, Assurance, Connect or Command Bus.

## Production contracts that must not regress
- `company_id` fail-closed tenancy; `tenant_company_id` is legacy migration-only state.
- Command Contract v3 and exact receipt/Signal/Rewind lineage.
- `crm:governance:audit-writes` must pass.
- AI/search reads stay projection-only; no OLTP fallback.
- immutable quote/estimate/invoice contract snapshots and async document rendering.
- CRM owns receivables truth; Titan Pay owns money movement; Titan Ledger owns accounting.
- portal identity/session verification and malware quarantine stay fail closed.
- API key expiry/IP scopes, webhook v3 signing/dead letters and staged hash-approved imports stay enabled.

## Preserved alpha.34 operations contract
1. `crm:production-check` reports **PASS**, **WARN** or **BLOCK** (`status` remains `ready`, `ready_with_warnings`, `blocked` for compatibility).
2. Only BLOCK returns a failing production-check exit code; WARN remains operable but requires remediation.
3. `crm:metrics --json` derives telemetry from existing durable journals/outboxes. Metrics are non-authoritative.
4. `crm:doctor --json` combines health + metrics + remediation and points to `docs/CRM-OPERATIONS-RUNBOOK.md`.
5. Duplicate idempotent command replays increment the original operation's `duplicate_replay_count`; do not create a second authoritative command record.
6. Operational recovery must never enable local mutation fallbacks or delete audit/outbox evidence to make dashboards green.

## Capability ownership
Compatibility-visible catalogue: **253 names** = **130 CRM Core authoritative + 123 external compatibility**. External names are routing contracts only.

## Alpha.35 performance/scale contract
1. Projection rebuilds use bulk upserts and durable incremental checkpoints; never restore per-resource full counts/state updates.
2. SQL search stays projection-only and uses disposable indexed search terms; never scan authoritative CRM tables.
3. Pipeline/timeline/detail/portal collections remain bounded and expose truncation where relevant.
4. Forecast/analytics/receivables aggregation remains in SQL instead of materialising unbounded rows in PHP.
5. Import staging may batch inserts; authoritative import commit remains repository/governance/rollback-journal aware.
6. Package synthetic 10k/100k/1m benchmarks prove bounded working sets only. Real performance certification must run `crm:performance:certify` on the installed MySQL host.
7. Do not add partitioning unless host-runtime profiling proves indexed bounded architecture is insufficient.

## Next roadmap pass — alpha.37 Compatibility Retirement
Retire remaining strangler-era aliases/routes/providers only when native destination owners and downstream consumers are proven. Preserve centralized compatibility routing until each dependency is safe to remove.

Every release must pass `bin/verify.php` from a clean ZIP extraction plus the retained standalone verifier/test suite.
