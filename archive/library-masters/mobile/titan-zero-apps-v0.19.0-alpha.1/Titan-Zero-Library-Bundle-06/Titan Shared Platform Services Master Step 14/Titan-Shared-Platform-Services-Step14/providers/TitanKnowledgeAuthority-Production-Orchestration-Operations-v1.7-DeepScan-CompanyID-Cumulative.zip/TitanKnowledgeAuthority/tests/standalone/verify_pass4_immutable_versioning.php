<?php

declare(strict_types=1);
$root = dirname(__DIR__, 2); $errors=[];
$expect=static function(bool $c,string $m) use (&$errors):void{if(!$c)$errors[]=$m;};
$required=[
'System/Contracts/KnowledgeSourceVersionWriteContract.php','System/Domain/ValueObjects/KnowledgeSourceVersionAppendRequest.php','System/Domain/ValueObjects/KnowledgeSourceVersionAppendResult.php','System/Domain/Services/SourceVersionLineagePolicy.php','System/Domain/Services/SourceVersionTenantLineagePolicy.php','System/Domain/Exceptions/SourceVersionConflictException.php','System/Services/KnowledgeSourceVersionWriteService.php','database/migrations/2026_08_21_000006_harden_knowledge_source_version_immutability.php'];
foreach($required as $p)$expect(is_file($root.'/'.$p),"missing {$p}");
$m=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true);
$expect(($m['version']??null)==='0.5.0-alpha.4','manifest version must advance to 0.5.0-alpha.4');
$expect(($m['capabilities']??null)===['titan-knowledge-authority','knowledge.health'],'Pass 4 must not advertise new public capabilities');
$expect(($m['queues']['used']??null)===false,'Pass 4 must keep queues disabled'); $expect(($m['schedules']??null)===[],'Pass 4 must keep schedules disabled'); $expect(($m['external_hosts']??null)===[],'Pass 4 must keep external hosts disabled');
$provider=(string)@file_get_contents($root.'/System/TitanKnowledgeAuthorityServiceProvider.php');
$expect(str_contains($provider,'KnowledgeSourceVersionWriteContract'),'provider must bind immutable source-version writer contract');
$service=(string)@file_get_contents($root.'/System/Services/KnowledgeSourceVersionWriteService.php');
foreach(['KnowledgeAccessContextResolverContract','KnowledgeSourceScopeQuery','DB::transaction','lockForUpdate','SourceVersionTenantLineagePolicy'] as $needle)$expect(str_contains($service,$needle),"writer missing {$needle}");
$expect(substr_count($service,'assertConsistent')>=2,'writer must validate duplicate and latest version tenant lineage');
$dpos=strpos($service,"where('content_hash'"); $lpos=strpos($service,'assertExpectedPrevious'); $expect($dpos!==false&&$lpos!==false&&$dpos<$lpos,'duplicate detection must precede predecessor conflict validation');
$request=(string)@file_get_contents($root.'/System/Domain/ValueObjects/KnowledgeSourceVersionAppendRequest.php');
foreach(['tenantCompanyId','versionSequence','versionKey'] as $forbidden)$expect(!str_contains($request,$forbidden),"append request must not accept {$forbidden}");
$expect(str_contains($request,'expectedSupersedesVersionId'),'append request predecessor precondition missing'); $expect(str_contains($request,'effective_until must not be before effective_from'),'effective window validation missing');
$model=(string)@file_get_contents($root.'/System/Domain/Models/KnowledgeSourceVersion.php'); foreach(['static::creating','static::updating','static::deleting','supersededBy'] as $needle)$expect(str_contains($model,$needle),"model missing {$needle}");
$mig=(string)@file_get_contents($root.'/database/migrations/2026_08_21_000006_harden_knowledge_source_version_immutability.php'); foreach(["dropForeign(['source_id'])",'restrictOnDelete','cascadeOnDelete'] as $needle)$expect(str_contains($mig,$needle),"migration missing {$needle}");
$schema=json_decode((string)file_get_contents($root.'/schemas/knowledge-source-version.schema.json'),true); foreach(['version_sequence','version_key','raw_evidence_hash'] as $f)$expect(in_array($f,$schema['required']??[],true),"schema must require {$f}");
$up=(string)file_get_contents($root.'/TITAN-KNOWLEDGE-AUTHORITY-UPGRADE-PROMPT.md'); $expect(str_contains($up,'Pass 4 completed'),'upgrade prompt must record Pass 4'); $expect(str_contains($up,'NEXT BUILD: Pass 5'),'upgrade prompt must advance to Pass 5');
if($errors){fwrite(STDERR,"Titan Knowledge Authority Pass 4 immutable-version verification: FAIL\n - ".implode("\n - ",$errors)."\n");exit(1);} echo "Titan Knowledge Authority Pass 4 immutable-version verification: PASS\n";
