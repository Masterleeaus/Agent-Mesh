<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Repositories;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Contracts\TagRepositoryContract; use App\Extensions\Crm\System\Services\CrmSubjectReferenceValidator; use Illuminate\Database\ConnectionInterface; use Illuminate\Support\Str;
final class EloquentTagRepository implements TagRepositoryContract {
 public function __construct(private ConnectionInterface $db,private CrmSubjectReferenceValidator $subjects){}
 public function search(int $userId,array $filters=[]): array { $q=$this->db->table('crm_tags')->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at'); if($v=$filters['q']??null)$q->where('name','like','%'.trim((string)$v).'%'); return $q->orderBy('name')->limit(250)->get()->map(fn($r)=>(array)$r)->all(); }
 public function create(int $userId,array $data): array { $name=trim((string)$data['name']); $existing=$this->db->table('crm_tags')->where('company_id', CrmCompanyScope::companyId($userId))->whereRaw('LOWER(name)=?',[mb_strtolower($name)])->whereNull('deleted_at')->first(); if($existing)return (array)$existing; $id=$this->db->table('crm_tags')->insertGetId(['public_id'=>(string)Str::ulid(),'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'name'=>$name,'color'=>$data['color']??null,'created_at'=>now(),'updated_at'=>now()]); return (array)$this->db->table('crm_tags')->where('id',$id)->first(); }
 public function attach(int $userId,string $tagPublicId,string $subjectType,string $subjectPublicId): void { $this->subjects->require($userId,$subjectType,$subjectPublicId); $tag=$this->db->table('crm_tags')->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$tagPublicId)->whereNull('deleted_at')->first(); if(!$tag) abort(404,'Tag not found.'); $this->db->table('crm_taggables')->updateOrInsert(['company_id' => CrmCompanyScope::companyId($userId), 'tag_public_id'=>$tagPublicId,'subject_type'=>$subjectType,'subject_public_id'=>$subjectPublicId],['user_id'=>CrmCompanyScope::actorUserId($userId),'created_at'=>now()]); }
}
