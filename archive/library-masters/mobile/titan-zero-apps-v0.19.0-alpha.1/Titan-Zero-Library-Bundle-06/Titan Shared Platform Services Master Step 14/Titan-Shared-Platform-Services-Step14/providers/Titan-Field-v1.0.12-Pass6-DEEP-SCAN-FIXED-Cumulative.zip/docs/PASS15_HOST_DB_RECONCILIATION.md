# Pass 15 Host DB Reconciliation — admin_titan_1787056710(3).sql

The supplied MariaDB dump was used as a host-truth compatibility input for Pass 15.

Observed host state:

- `extensions` contains installed `titan-maps-intelligence` version `2.0.0-beta.1.8`, folder `TitanMapsIntelligence`, provider `App\\Extensions\\TitanMapsIntelligence\\System\\TitanMapsIntelligenceServiceProvider`.
- `extensions` contains CRM version `1.3.0-alpha.17` in the dump snapshot.
- No `titan-field` extension registry row is present in this dump snapshot.
- No `titan_field_*` tables or `crm_field_worker_profiles` table are present in the dump snapshot; Titan Field migrations therefore must create them restartably when Field is installed/upgraded.
- Existing CRM-era menu rows are already present, including root `ext_crm_crew`, child `crm_schedule` and child `crm_dispatch` using the historical named routes retained by Titan Field.
- Existing Maps navigation is present, including `titan_maps_field_operations` and `titan_maps_field_overview` (`Live Map`).
- The host `menus` schema uses unique `key`, nullable `parent_id`, named `route`, active state, ordering and extension metadata. Pass 15 does not introduce a duplicate Field/Maps parent menu.
- Existing Maps route-plan/location tables are present. Pass 15 adds only its own restartable Maps proposal-evidence table.

Compatibility disposition:

1. Keep Field self-healing menu adoption by existing route/key; do not duplicate `Crew` or Maps `Field Operations` roots.
2. Keep Field's historical `crm.*` table names for extracted operational state.
3. Create Pass-15 proposal tables only when absent; retain data on rollback/uninstall.
4. Publish Workforce role definitions as files/contributions, not ad-hoc rows in host `roles`/`permissions` tables.
5. Do not infer Titan Field as installed merely because its source files are on disk; peer activation continues to require the bound Field governed command contract.
