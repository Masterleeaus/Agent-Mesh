# Four-PWA Wizard Surfaces

`SurfaceWizardPolicy` filters the shared wizard catalogue without creating separate engines.

- Hub: `new_customer_v1`, `service_booking_v1`.
- Go: job completion, materials, variations, practical completion/defects, incident and inspection workflows.
- Command: customer/quote/work-order/invoice/booking and operational approval workflows.
- Onboarding: `field_home_services_onboarding_v1`.

Surface filtering is additive to role/session/company authorization; knowing a wizard ID is never sufficient authority.
