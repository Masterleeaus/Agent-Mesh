<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/SignalPrunePreviewToken.php';
require __DIR__ . '/../System/Services/PruneCandidateHasher.php';

use App\Extensions\TitanSignalEngine\System\Data\SignalPrunePreviewToken;
use App\Extensions\TitanSignalEngine\System\Services\PruneCandidateHasher;

function assertTrue14(bool $condition, string $message): void {
    if (! $condition) throw new RuntimeException($message);
}

$token = SignalPrunePreviewToken::issue('018f7f47-7c2b-7f3b-8000-111111111111');
assertTrue14(str_starts_with($token->plainText, '018f7f47-7c2b-7f3b-8000-111111111111.'), 'Preview token must bind its preview id.');
assertTrue14(strlen($token->hash) === 64, 'Preview token hash must be SHA-256.');
assertTrue14($token->verify($token->plainText), 'Issued preview token must verify.');
assertTrue14(! $token->verify($token->plainText . 'x'), 'Tampered preview token must fail verification.');

$hasher = new PruneCandidateHasher();
$a = $hasher->hash('tenant', 42, ['b', 'a', 'c']);
$b = $hasher->hash('tenant', 42, ['c', 'b', 'a']);
assertTrue14($a === $b, 'Candidate hashes must be stable regardless of input order.');
assertTrue14($a !== $hasher->hash('tenant', 43, ['a', 'b', 'c']), 'Candidate hash must bind tenant identity.');
assertTrue14($a !== $hasher->hash('system', null, ['a', 'b', 'c']), 'Candidate hash must bind scope.');


$archiveSource = file_get_contents(__DIR__ . '/../System/Services/LocalSignalArchiveStore.php');
assertTrue14(is_string($archiveSource) && str_contains($archiveSource, 'archiveStream('), 'Archive store must expose streaming writes.');
assertTrue14(! str_contains((string) $archiveSource, 'gzencode('), 'Archive store must not build a whole compressed archive in memory.');
assertTrue14(! str_contains((string) $archiveSource, '->get($locator)'), 'Archive reads must not load the whole remote object with get().');
assertTrue14(str_contains((string) $archiveSource, 'readStream($locator)'), 'Archive reads must use streaming object reads.');

$lifecycleSource = file_get_contents(__DIR__ . '/../System/Services/SignalLifecycleService.php');
assertTrue14(is_string($lifecycleSource) && str_contains($lifecycleSource, 'preview_token'), 'Pruning must require a persisted preview token.');
assertTrue14(str_contains((string) $lifecycleSource, 'candidate_hash'), 'Pruning must bind the exact candidate hash.');
assertTrue14(str_contains((string) $lifecycleSource, 'execution_token'), 'Pruning must use an execution lease for concurrent callers.');
assertTrue14(str_contains((string) $lifecycleSource, "'verified_unpruned'"), 'Verified-but-not-pruned batches must be resumable.');
assertTrue14(! str_contains((string) $lifecycleSource, 'confirmed=true'), 'Legacy boolean prune confirmation must be removed.');

fwrite(STDOUT, "transactional pruning behavior: PASS\n");
