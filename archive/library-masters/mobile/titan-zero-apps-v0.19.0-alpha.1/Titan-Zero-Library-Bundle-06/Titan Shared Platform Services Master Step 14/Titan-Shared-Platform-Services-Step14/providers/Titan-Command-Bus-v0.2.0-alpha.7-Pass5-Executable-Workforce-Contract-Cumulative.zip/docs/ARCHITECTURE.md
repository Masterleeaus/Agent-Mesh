# Architecture

Command Bus is a system-engine and canonical owner of governed-mutation. It orchestrates execution only; authoritative domain logic stays in domain adapters. Internal command/idempotency/receipt state is the sole self-write exception and never recursively dispatches through the Bus.

## Mutation decision order

`envelope/idempotency -> capability adapter availability -> Titan Risk -> Titan Governance -> domain adapter -> immutable receipt -> Signal`.

Risk and Governance are independent authorities. Risk supplies contextual risk evidence and required controls; Governance receives that evidence and makes the authorization decision. Command Bus never calculates its own substitute risk score and never allows Governance to erase a Risk denial.


## Pass 10 — Assurance / Shield boundary
Mutation dispatch now requires an authoritative Assurance/Shield decision after Titan Risk and before Governance. The default bridge is fail-closed; no local assurance or Shield policy is inferred. Accepted evidence is durable and is passed into Governance, receipts, and outcome Signals.


## Pass 11 — Titan Autonomy integration

Command dispatch now resolves earned autonomy after Risk and Assurance and before Governance. Autonomy is capability/workflow-specific evidence, never a caller-selected permission. When `require_autonomy=true`, unavailable, denied, or malformed autonomy evidence fails closed before Governance or domain execution. Successful decisions preserve `autonomy_reference`, `autonomy_level`, `autonomy_workflow`, and evidence references in receipts and Signal telemetry.
