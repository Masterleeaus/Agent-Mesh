## Persistent orchestration v1.5

- Added durable outbox, lease recovery, deduplication, retry/dead-letter/redrive, provider deferral and health telemetry for Workforce handoffs.


## Runtime hardening pass
- Added container-bound Workforce loop runtime with fail-closed provider health aggregation.
- Enforced canonical `company_id` plus full causal context on cross-extension handoffs.
- Added provider/version pinning and authority-neutral handoff envelopes.
- Enforced outcome lineage and execution receipts.
- Quarantined raw host-menu database access as legacy navigation compatibility only.

# Changelog

## 0.3.0 — Evidence + Delayed Outcome Resolution

- Added canonical `EvidenceReference` v1 with claimed/observed/validated/rejected/superseded states and supports/contradicts/context relationships.
- Added independent-validation rule: AI/agent self-report can be stored as a claim but cannot self-validate as authoritative truth.
- Added tenant-scoped durable evidence and outcome-evidence link tables.
- Activated `wisdom.evidence.attach` with governance, tenant scoping, semantic idempotency and collision rejection.
- Activated `wisdom.outcome.resolve`; conclusive resolution requires linked validated authoritative supporting evidence.
- Added optimistic compare-and-swap outcome projection updates with append-only transition snapshots and duplicate-return semantics.
- Activated append-only `wisdom.outcome.revise` for later revisions and contradictions; original terminal records remain immutable.
- Contradicted revisions require validated authoritative evidence linked as `contradicts`.
- Added overdue outcome scanning, dedicated `titan-wisdom` queue delivery, unique observation jobs and the `wisdom.outcome.observation_due.v1` event.
- Added one-server, five-minute, overlap-protected delayed observation schedule and a manual dispatch command.
- Expanded certification/readiness and fixed disabled-runtime certification so intentionally absent routes do not create a false failure.
- Added Blueprint-compatible capability, evidence, resolution, revision and delayed-observation schemas.

## 0.2.0 — Canonical OutcomeRecord Domain

- Added the canonical `titan_wisdom_outcome_records` table while preserving the legacy scaffold table without new writes.
- Added typed outcome classifications and resolution states aligned with the Blueprint Wisdom contract.
- Added `OutcomeRecordDraft`, immutable `OutcomeRecord`, contract receipt and strict lifecycle invariants.
- Added tenant-scoped `OutcomeRecordRepositoryContract` and Laravel database repository.
- Added governed `WisdomOutcomeRecorder` and concrete `RecordOutcomeCapability`.
- Activated truthful public capability `wisdom.outcome.record`.
- Added capability-owned idempotency derived from tenant + source `operation_id`; duplicates return the original record and conflicting payload reuse fails closed.
- Added canonical payload hashing, governance provenance, source provenance, version references and revision-lineage fields.
- Added Blueprint-compatible input, output and OutcomeRecord JSON schemas plus Manifest v2.2 capability contract metadata.
- Extended certification, unit/security tests and documentation for the canonical domain.

## 0.1.3 — Governance Integration Foundation

- Added a typed fail-closed governance gate for all future Wisdom mutations.
- Added canonical governance dispositions: `ALLOW`, `DENY`, `HOLD`, and `REQUIRE_APPROVAL`.
- Added tenant-, operation-, freshness-, expiry- and policy-version validation for governance decisions.
- Made `REQUIRE_APPROVAL` explicitly non-equivalent to `ALLOW`.
- Added hard Wisdom authority boundaries that cannot be overridden by an upstream allow decision: no learning-candidate promotion to authority, no autonomy grant, and no cross-domain write.
- Added configurable governance decision freshness TTL with a 300-second default.
- Added the governance gate to service-provider bindings, readiness and non-destructive host certification.
- Added `titan-governance` as an optional install-time dependency while retaining execution-time governance requirements for future mutations.
- Preserved truthful public capabilities: health/readiness only.

## 0.1.2 — Blueprint v4.2 Foundation Rebase

- Rebased root installer contract to `titan-extension-v1` for Installer 1.7.8.
- Rebased architecture manifest to canonical Manifest v2.2.
- Changed canonical extension identity from legacy `titan-wisdom-engine` to Blueprint owner key `titan-wisdom`.
- Classified Wisdom as an `intelligence-engine` with `signal-aware` modifier.
- Added `root_causation_id` to required future execution context and legacy compatibility schema.
- Added non-destructive `titan:titan-wisdom:certify` host certification command.
- Changed Blade views to MagicAI host layout `panel.layout.app`.
- Preserved truthful capability advertising: health/readiness only.
- Added explicit authority, governance, data-governance, Signal and integration documentation.

## 0.1.1 — Contract and Boundary Hardening

- Added truthful health/readiness capabilities and strict tenant/trace context.
- Removed unimplemented outcome/attribution/learning/calibration capability claims.
