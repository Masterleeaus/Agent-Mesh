# Security

Nexus is tenant-scoped, forbids secret material in compiled profiles, uses deterministic hashes for provenance, requires backup/write/audit/rollback evidence for applied mutations, and forbids direct foreign-domain writes. External gateway failures are redacted to class-level failure evidence.
