# Titan CRM Domain Extraction Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Split Titan CRM alpha.23 into separately installable Titan CRM Core, Titan Field, Titan Locker, Titan Ledger, and Titan Pay extensions without replacing useful code or creating dual authoritative writers.

**Architecture:** Use a strangler extraction. Existing domain implementations are moved into dedicated extensions; CRM Core retains customer/sales authority and compatibility ports. During migration each extracted domain has one writer, preserves `tenant_company_id`, uses governed capability contracts, and can adopt pre-existing CRM-owned tables without destructive data migration.

**Tech Stack:** PHP 8.2+, Laravel 10 / MagicAI 11 extension conventions, MySQL, Titan Command Bus/Signal/Rewind contracts.

## Global Constraints

- Preserve useful alpha.23 code; do not rebuild working domain logic from scratch.
- Preserve installer compatibility and MySQL-safe migrations.
- Preserve tenant isolation with `tenant_company_id`.
- No dual writers for extracted domain tables.
- Cross-domain mutation must be expressible through governed capability contracts.
- Existing tables are adopted when present; fresh installs create only the owning domain schema.
- AI never gains direct database mutation authority through the extraction.
- Each ZIP must contain an agent handoff prompt and CODEE artifact signature.
- Every package must pass PHP syntax lint and package-structure verification.

---

### Task 1: Freeze ownership map and compatibility contracts

**Files:**
- Create: `docs/DOMAIN-OWNERSHIP-MAP.md`
- Create: `docs/EXTRACTION-COMPATIBILITY-CONTRACT.md`
- Test: `bin/verify-domain-extraction.php`

**Interfaces:**
- CRM Core produces commercial/customer capabilities and shared tenant/governance context.
- Titan Field consumes CRM customer/service/invoice references and owns field-operation tables/capabilities.
- Titan Locker consumes job references and owns inventory/purchasing/fleet tables/capabilities.
- Titan Ledger consumes financial events and owns journal/reporting accounting state.
- Titan Pay consumes invoice/payment references and owns provider/payment execution state.

- [ ] Write failing verifier asserting five package roots, manifests, providers, prompts, ownership manifests, and non-overlapping domain writer declarations.
- [ ] Run verifier and confirm missing-package failure.
- [ ] Write the ownership and compatibility contract documents.
- [ ] Keep verifier red until all packages are assembled.

### Task 2: Extract Titan Locker

**Files:**
- Move/adapt: `System/Domains/Locker/**`
- Move/adapt: Locker controller/routes/views
- Create: `System/TitanLockerServiceProvider.php`
- Create: `System/Capabilities/TitanLockerCapabilityProvider.php`
- Create: adopt-or-create Locker migrations derived from CRM migrations 000017, 000019, 000020 and Locker portions of 000018.
- Create: `docs/AGENT_HANDOFF_PROMPT.md`

**Interfaces:**
- Exposes `crm.locker.*` compatibility aliases plus canonical `locker.*` capability names.
- Depends on CRM Core only for transitional tenant/company/job references; Command Bus remains mutation gateway.

- [ ] Copy existing Locker code before namespace changes.
- [ ] Refactor namespace from `App\\Extensions\\Crm` to `App\\Extensions\\TitanLocker` for owned code.
- [ ] Add transitional CRM Core adapters for tenant/job references rather than copying CRM repositories.
- [ ] Add idempotent adoption migration guards.
- [ ] Verify Locker package contains no Bookkeeping/Pay/Field service implementations.

### Task 3: Extract Titan Ledger

**Files:**
- Move/adapt: `System/Domains/Bookkeeping/**`
- Create: `System/TitanLedgerServiceProvider.php`
- Create: `System/Capabilities/TitanLedgerCapabilityProvider.php`
- Create: adopt-or-create bookkeeping migration derived from CRM migration 000015.
- Create: `docs/AGENT_HANDOFF_PROMPT.md`

**Interfaces:**
- Exposes transitional `crm.bookkeeping.*` aliases plus canonical `ledger.*` capabilities.
- Reads CRM invoice/payment references through contracts; no direct CRM table mutation.

- [ ] Preserve current bookkeeping implementation as compatibility layer.
- [ ] Add append-only Ledger boundary interfaces for future double-entry upgrade without claiming double-entry is already implemented.
- [ ] Refactor namespace and service provider.
- [ ] Verify Ledger package contains no Locker/Field/Pay implementation.

### Task 4: Extract Titan Pay

**Files:**
- Move/adapt: `System/Domains/Pay/**`
- Move/adapt: payment reconciliation services needed by Pay.
- Create: `System/TitanPayServiceProvider.php`
- Create: `System/Capabilities/TitanPayCapabilityProvider.php`
- Create: adopt-or-create Pay migration derived from CRM migration 000016 and payment-link portions of later migrations.
- Create: `docs/AGENT_HANDOFF_PROMPT.md`

**Interfaces:**
- Exposes transitional `crm.pay.*` aliases plus canonical `pay.*` capabilities.
- CRM remains invoice/payment business-state authority during transition; Titan Pay owns payment-provider execution, intents, links, refunds and reconciliation evidence.

- [ ] Preserve provider payment idempotency and replay protections from alpha.21.
- [ ] Preserve tenant-scoped provider transaction identity.
- [ ] Refactor namespace/provider.
- [ ] Verify Pay package contains no Locker/Field/Bookkeeping implementation.

### Task 5: Extract Titan Field

**Files:**
- Move/adapt: `System/Domains/FieldServices/**`
- Move/adapt: field DTOs, Titan Go field reconciliation, FieldService controller/routes/views/resources
- Create: `System/TitanFieldServiceProvider.php`
- Create: `System/Capabilities/TitanFieldCapabilityProvider.php`
- Create: adopt-or-create Field migrations derived from 000011, 000012 and 000033.
- Create: `docs/AGENT_HANDOFF_PROMPT.md`

**Interfaces:**
- Exposes transitional `crm.work_order.*`, `crm.dispatch.*`, `crm.service_request.*`, etc. plus canonical `field.*` aliases.
- Consumes CRM customer/service/invoice references through compatibility ports; Titan Maps can later bind travel intelligence.

- [ ] Preserve SchedulingKernel, completion evidence hash, recurring watermark and Titan Go governed reconciliation.
- [ ] Preserve field tables/data by adopting existing schema when present.
- [ ] Refactor namespace/provider/controllers/routes.
- [ ] Verify Field package contains no Locker/Pay/Bookkeeping implementation.

### Task 6: Produce Titan CRM Core

**Files:**
- Modify copy of alpha.23 CRM package.
- Remove ownership/registration of Field, Locker, Pay and Bookkeeping implementations.
- Add compatibility port contracts for extracted engines.
- Add conditional compatibility capability forwarding when extracted extension is installed.
- Create: `docs/AGENT_HANDOFF_PROMPT.md`

**Interfaces:**
- CRM Core owns customers, organisations, contacts, leads, deals, pipelines, services/commercial catalogue compatibility, quotes, estimates, invoices, portal/customer relationship, imports, integrations, CQRS, governance adapters and commercial history.
- It no longer writes extracted domain tables.

- [ ] Remove extracted provider registration from CRM Core.
- [ ] Remove extracted domain service files from CRM Core package.
- [ ] Preserve shared tenancy/governance/read-store infrastructure required during strangler transition.
- [ ] Add explicit extension dependency/optional integration declarations.
- [ ] Verify CRM Core contains no active Locker/Bookkeeping/Pay/Field domain implementation classes.

### Task 7: Package-level handoff prompts and CODEE signatures

**Files:**
- Create in every package: `docs/AGENT_HANDOFF_PROMPT.md`
- Create in every package: `CODEE_ARTIFACT.txt`
- Create in every package: `docs/EXTRACTION_STATUS.md`

**Interfaces:**
- Prompts state actual implemented ownership, compatibility debt, required next work, engine integrations, testing obligations and strict no-placeholder/no-rewrite rules.

- [ ] Generate extension-specific prompts.
- [ ] Include original source version and extraction lineage.
- [ ] Include capability/table ownership lists.
- [ ] Include explicit “do not claim implemented unless tested” requirements.

### Task 8: Verify and package five installable ZIPs

**Files:**
- Test: `bin/verify-domain-extraction.php`
- Output: five ZIP packages and one bundle index.

**Interfaces:**
- Each ZIP has one extension root, manifest, provider, migrations/config/routes as applicable, prompt, docs and CODEE signature.

- [ ] Run PHP syntax lint on every PHP file in all five packages.
- [ ] Run extraction verifier; require 0 failures.
- [ ] Scan cross-package ownership to ensure no domain implementation is duplicated.
- [ ] Generate SHA-256 inventory for each package.
- [ ] Zip each package.
- [ ] Extract each ZIP to a clean directory and rerun package verification/lint.
