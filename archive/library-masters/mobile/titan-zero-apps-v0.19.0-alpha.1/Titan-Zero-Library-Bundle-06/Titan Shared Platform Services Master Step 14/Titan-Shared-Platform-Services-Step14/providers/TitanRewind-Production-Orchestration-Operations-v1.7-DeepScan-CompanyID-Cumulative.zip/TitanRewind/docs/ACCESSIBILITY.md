# Titan Rewind Accessibility

Titan Rewind targets WCAG 2.2 AA at the extension markup boundary. Every shipped Rewind surface provides a keyboard skip link and a `role="main"` content landmark. Data tables have accessible captions, form controls are explicitly labelled or carry an accessible name, native buttons/details/summary controls are retained instead of click-only divs, and dynamic trace status messages use an ARIA live region where appropriate.

The static release gate is `tests/standalone/verify_accessibility_localization.php`. It verifies main landmarks, translation usage and table captions across all shipped Blade views.

The host application owns final typography, contrast, focus ring appearance, zoom/reflow behaviour and global navigation. Those visual properties must be checked in the exact MagicAI theme during host certification; the package does not claim that a host theme it has not been run inside is WCAG conformant.
