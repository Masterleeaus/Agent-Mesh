<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\ControlPlaneAuditSinkContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use RuntimeException;

final class DelegatedAuthorityEnvelopeService
{
    private string $signingKey;

    public function __construct(
        string $applicationKey,
        private readonly string $policyVersion,
        private readonly int $ttlSeconds = 90,
        private readonly ?ControlPlaneAuditSinkContract $audit = null,
    ) {
        $applicationKey = trim($applicationKey);
        if (strlen($applicationKey) < 16) {
            throw new RuntimeException('AUTONOMY_DELEGATION_SIGNING_KEY_UNAVAILABLE');
        }
        $this->signingKey = hash_hmac('sha256', 'titan-autonomy-delegation-v1', $applicationKey, true);
    }

    public function policyVersion(): string
    {
        return $this->policyVersion;
    }

    public function issue(
        CapabilityState $state,
        array $effectivePolicy,
        int $issuingUserId,
        string $sessionId,
        ?string $interactionId,
        ?string $correlationId,
        array $grantedScopes = [],
    ): array {
        if (!in_array($state->currentLevel, [AutonomyLevel::Auto, AutonomyLevel::TrustedAuto], true)) {
            throw new RuntimeException('AUTONOMY_LEVEL_NOT_DELEGABLE');
        }
        if ($state->scope === []) {
            throw new RuntimeException('AUTONOMY_SCOPE_REQUIRED_FOR_DELEGATION');
        }
        $sessionId = trim($sessionId);
        $correlationId = trim((string) $correlationId);
        if ($sessionId === '' || $correlationId === '') {
            throw new RuntimeException('DELEGATION_REQUIRES_SESSION_AND_CORRELATION');
        }

        $now = time();
        $claims = [
            'schema' => 'titan-autonomy-delegation-v1',
            'grant_id' => bin2hex(random_bytes(16)),
            'tenant_company_id' => $state->tenantCompanyId,
            'capability' => $state->capability,
            'workflow_key' => $state->workflowKey,
            'autonomy_level' => $state->currentLevel->key(),
            'scope_hash' => $this->scopeHash($state->scope),
            'policy_version' => $this->policyVersion,
            'policy_fingerprint' => $this->policyFingerprint($effectivePolicy),
            'issued_by_user_id' => $issuingUserId,
            'session_id' => $sessionId,
            'interaction_id' => trim((string) $interactionId),
            'correlation_id' => $correlationId,
            'granted_scopes' => array_values(array_unique(array_values(array_filter(array_map('strval', $grantedScopes), static fn (string $v): bool => $v !== '')))),
            'issued_at' => $now,
            'expires_at' => $now + max(1, min(300, $this->ttlSeconds)),
            'nonce' => bin2hex(random_bytes(16)),
        ];
        $claims['signature'] = hash_hmac('sha256', $this->canonical($claims), $this->signingKey);
        $this->audit?->record([
            'tenant_company_id' => $state->tenantCompanyId,
            'user_id' => $issuingUserId,
            'event_type' => 'autonomy.delegation_issued',
            'capability' => $state->capability,
            'workflow_key' => $state->workflowKey,
            'payload' => [
                'grant_id' => $claims['grant_id'],
                'autonomy_level' => $claims['autonomy_level'],
                'scope_hash' => $claims['scope_hash'],
                'policy_fingerprint' => $claims['policy_fingerprint'],
                'session_id' => $claims['session_id'],
                'interaction_id' => $claims['interaction_id'],
                'granted_scopes' => $claims['granted_scopes'],
                'expires_at' => $claims['expires_at'],
            ],
            'policy_version' => $this->policyVersion,
            'correlation_id' => $correlationId,
        ]);
        return $claims;
    }

    public function verify(array $envelope): ?array
    {
        $signature = (string) ($envelope['signature'] ?? '');
        if ($signature === '') return null;
        unset($envelope['signature']);
        if (!hash_equals(hash_hmac('sha256', $this->canonical($envelope), $this->signingKey), $signature)) return null;
        if (($envelope['schema'] ?? null) !== 'titan-autonomy-delegation-v1') return null;
        if (($envelope['policy_version'] ?? null) !== $this->policyVersion) return null;
        $now = time();
        $issuedAt = (int) ($envelope['issued_at'] ?? 0);
        $expiresAt = (int) ($envelope['expires_at'] ?? 0);
        if ($issuedAt <= 0 || $expiresAt < $now || $issuedAt > ($now + 30) || ($expiresAt - $issuedAt) > 300) return null;
        if (trim((string) ($envelope['grant_id'] ?? '')) === '') return null;
        if (trim((string) ($envelope['capability'] ?? '')) === '') return null;
        if (trim((string) ($envelope['session_id'] ?? '')) === '') return null;
        if (trim((string) ($envelope['correlation_id'] ?? '')) === '') return null;
        return $envelope + ['signature' => $signature];
    }

    public function scopeHash(array $scope): string
    {
        return hash('sha256', $this->canonical($scope));
    }

    public function policyFingerprint(array $policy): string
    {
        return hash('sha256', $this->canonical($policy));
    }

    private function canonical(array $value): string
    {
        $normalised = $this->normalise($value);
        return json_encode($normalised, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    private function normalise(mixed $value): mixed
    {
        if (!is_array($value)) return $value;
        if (array_is_list($value)) {
            return array_map(fn (mixed $item): mixed => $this->normalise($item), $value);
        }
        ksort($value);
        foreach ($value as $key => $item) $value[$key] = $this->normalise($item);
        return $value;
    }
}
