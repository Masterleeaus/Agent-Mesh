<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalPulseCommandReceipt extends Model
{
    protected $table = 'titan_signal_pulse_command_receipts';
    protected $guarded = [];
    protected $casts = [
        'tenant_company_id' => 'integer',
        'tenant_key' => 'integer',
        'latency_ms' => 'integer',
        'command_occurred_at' => 'immutable_datetime',
        'receipt_occurred_at' => 'immutable_datetime',
    ];
}
