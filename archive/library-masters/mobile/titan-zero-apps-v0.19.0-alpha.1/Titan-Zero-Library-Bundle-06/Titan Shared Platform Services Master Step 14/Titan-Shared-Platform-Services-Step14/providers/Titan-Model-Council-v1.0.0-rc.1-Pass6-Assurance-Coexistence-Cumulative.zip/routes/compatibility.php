<?php

declare(strict_types=1);

use App\Extensions\TitanModelCouncil\System\Http\Controllers\Compatibility\ModelCouncilController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->post('/accept-response', [ModelCouncilController::class, 'acceptResponse'])
    ->name('titan-model-council.compatibility.prefer');
