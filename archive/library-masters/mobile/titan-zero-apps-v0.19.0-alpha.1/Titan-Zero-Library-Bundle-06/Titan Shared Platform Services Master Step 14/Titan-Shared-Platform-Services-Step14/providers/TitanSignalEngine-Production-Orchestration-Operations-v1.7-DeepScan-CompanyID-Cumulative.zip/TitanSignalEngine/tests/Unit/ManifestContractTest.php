<?php

declare(strict_types=1);

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

final class ManifestContractTest extends TestCase
{
    public function test_manifest_advertises_lifecycle_hardening_and_owned_tables(): void
    {
        $manifest = json_decode((string) file_get_contents(dirname(__DIR__, 2) . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);

        self::assertSame('0.20.0-rc.8.1', $manifest['version']);
        self::assertSame('2.0', $manifest['schema_version']);
        self::assertSame('titan-governed-engine', $manifest['runtime_profile']);
        self::assertTrue($manifest['observability']['signal_events']);
        self::assertContains('signal.emit', $manifest['capabilities']);
        self::assertContains('signal.query', $manifest['capabilities']);
        self::assertContains('signal.history.query', $manifest['capabilities']);
        self::assertContains('signal.correlate', $manifest['capabilities']);
        self::assertContains('signal.subscribe', $manifest['capabilities']);
        self::assertContains('signal.deliver', $manifest['capabilities']);
        self::assertContains('signal.delivery.redrive', $manifest['capabilities']);
        self::assertContains('signal.pulse', $manifest['capabilities']);
        self::assertContains('signal.anomaly.detect', $manifest['capabilities']);
        self::assertContains('signal.lifecycle', $manifest['capabilities']);
        self::assertContains('signal.archive', $manifest['capabilities']);
        self::assertContains('signal.redact', $manifest['capabilities']);
        self::assertContains('signal.console', $manifest['capabilities']);
        self::assertContains('signal.console.manage', $manifest['permissions']);
        self::assertContains('signal.delivery.redrive', $manifest['permissions']);
        self::assertContains('signal.health.read', $manifest['permissions']);
        self::assertContains('signal.system.read', $manifest['permissions']);
        self::assertContains('signal.tenant.read', $manifest['permissions']);
        self::assertTrue($manifest['queues']['used']);
        self::assertContains('titan-signal-engine', $manifest['queues']['queue_names']);
        self::assertContains('titan_signal_types', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_idempotency_keys', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_causal_edges', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_trace_profiles', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_subscriptions', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_deliveries', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_pulse_rollups', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_pulse_projected_events', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_pulse_trace_metrics', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_pulse_trace_event_counts', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_pulse_causation_refs', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_pulse_projection_freshness', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_pulse_command_receipts', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_operational_health_snapshots', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_trace_evaluations', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_trace_assignments', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_anomalies', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_anomaly_scan_state', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_event_lifecycle', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_event_overlays', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_archive_batches', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_archive_catalog', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_lifecycle_audit', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_delivery_redrives', $manifest['database']['owned_tables']);
        self::assertContains('titan_signal_subscription_registry_state', $manifest['database']['owned_tables']);
        self::assertNotEmpty(array_filter($manifest['schedules'], static fn (array $schedule): bool => ($schedule['key'] ?? null) === 'signal-health-refresh'));
        self::assertNotEmpty(array_filter($manifest['schedules'], static fn (array $schedule): bool => ($schedule['key'] ?? null) === 'signal-trace-evaluation'));
        self::assertNotEmpty(array_filter($manifest['schedules'], static fn (array $schedule): bool => ($schedule['key'] ?? null) === 'signal-housekeeping'));
    }
}
