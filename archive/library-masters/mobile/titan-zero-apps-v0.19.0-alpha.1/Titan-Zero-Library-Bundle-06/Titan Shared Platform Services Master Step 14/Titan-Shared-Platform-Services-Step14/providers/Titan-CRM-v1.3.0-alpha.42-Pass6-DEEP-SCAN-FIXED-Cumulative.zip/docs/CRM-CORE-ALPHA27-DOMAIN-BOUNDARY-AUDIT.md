# Titan CRM Core alpha.27 — Commercial Domain Boundary Audit

## Purpose

Alpha.27 completes the first post-extraction boundary audit of Titan CRM Core. Its goal is not to add another business domain. Its goal is to prove that CRM Core owns customer and commercial truth while extracted Titan engines remain the only authoritative owners of their domains.

## Core-owned runtime

Titan CRM Core actively owns and may execute governed mutations for:

- customers, organisations and contacts
- leads, opportunities/deals and pipelines
- CRM activities, notes, tags and custom fields
- CRM coordination projects, tasks and calendar events
- commercial service/catalogue definitions used to sell work
- quotes, estimates and invoices
- receivables business state and commercial document lifecycle
- commercial deterministic calculations: formula rules, pricing, quote estimates, discounts/promotions, margin/profitability and tax
- CRM imports/exports
- commercial Customer Hub/portal access
- CRM API keys, webhooks, record sharing and integration metadata
- CRM automation rules whose triggers/actions remain inside the Core boundary
- CRM CQRS projections and AI-safe commercial/customer read models
- Command Bus, Signal outbox, Rewind references, idempotency and optimistic-concurrency adapters

CRM Core may keep a reference to an externally owned record when commercial lineage requires it. For example, a quote or invoice may reference a Titan Field work order. That relationship does not grant CRM authority to mutate the work order.

## Central compatibility retained temporarily

The following compatibility infrastructure remains intentionally in CRM Core during the strangler migration:

- `CrmExternalDomainCapabilityBridge`
- `CrmCapabilityOwnershipMap`
- external resource mappings in `CrmCapabilityResourceMap`
- external tenant-table mappings used by guarded compatibility checks
- compatibility branches in `CrmTenantReferenceGuard` and `CrmDomainInvariantGuard`
- legacy `crm.*` capability names whose `owning_extension` is an extracted engine
- guarded migration logic that can recognise already-existing extracted-domain tables during upgrades

These components are routing/migration contracts. They are **not** second domain implementations and must not become writers.

At alpha.27 the compatibility-visible capability catalogue contains 226 governed names:

- 106 owned by `crm`
- 54 owned by `titan-field`
- 49 owned by `titan-locker`
- 11 owned by `titan-pay`
- 6 owned by `titan-ledger`

The 120 non-CRM names are compatibility aliases only and are planned for retirement in the compatibility-retirement pass after all consumers use native destination contracts.

## External authoritative owners

### Titan Field

Owns:

- service requests
- work orders/jobs
- field scheduling and appointments
- dispatch
- service locations and customer assets used for field execution
- field time/material records
- field forms/checklists/evidence
- recurring field work
- service areas
- field support/review workflows
- Titan Go field/offline delta state

### Titan Locker

Owns:

- inventory and stock
- stock locations/reservations/transfers/counts
- suppliers and purchase orders
- goods receipts
- tools/equipment
- fleet
- maintenance

### Titan Ledger

Owns accounting/bookkeeping truth and its future journal/reporting model.

### Titan Pay

Owns payment-provider execution, payment intent/provider state, collections and provider reconciliation. CRM may retain invoice/receivables commercial state and compatible payment references, but generic CRM commercial routes must not become payment-provider writers.

### Titan intelligence/governance engines

- Titan Autonomy owns authority decisions.
- Titan AI Core owns cross-domain planning.
- Titan AI Workforce owns proactive AI work execution/orchestration.
- Titan Wisdom owns learning/outcome patterns.
- Titan Risk and Titan Assurance remain external governance authorities.
- Titan Signal and Titan Rewind remain external event/reconstruction authorities.
- Titan Connect owns provider communication execution.

## Alpha.27 removals

The audit removes active or executable residue that no longer belongs in CRM Core, including:

- per-class Field/Locker/Ledger/Pay compatibility alias directories
- obsolete extracted-domain provider classes
- obsolete Field/Locker/Ledger/Pay controller aliases
- CRM-owned Titan Go Field offline/delta implementation
- Field-owned CQRS projections and mobile change feed
- Field-owned analytics and owner-dashboard augmentation
- external-domain Chatbot tools
- Field/Locker/Ledger/Pay automation triggers/actions
- external-domain Global New actions, quick prompts, record actions and Interaction chains
- 51 dormant Interaction JSON wizards for jobs, payments, purchasing, inventory, fleet, maintenance and other extracted-domain actions
- obsolete Finance Assistant runtime; six deterministic commercial calculators remain under `CommercialCalculations`
- obsolete Phase-0 monolith diagnostic commands/services
- historical regression scripts whose only purpose was testing code already extracted from CRM

## Fresh-install schema boundary

A fresh alpha.27 CRM Core installation no longer creates:

- Titan Field domain schema migrations extracted from Core
- CRM Field sync-operation tables
- Titan Field mobile change-feed tables
- Titan Pay `crm_payments`
- Titan Pay `crm_payment_allocations`
- Titan Locker schema
- Titan Ledger/bookkeeping schema

Existing installations are not destructively rewritten. Historical migrations may contain guarded compatibility logic that only runs when an old table already exists. That is upgrade compatibility, not fresh-install ownership.

## Read boundary

CRM Core projections are now limited to:

- customer summary
- customer timeline
- sales pipeline
- invoice context
- receivables context
- owner commercial dashboard
- tenant commercial/customer summary

CRM Core no longer publishes `job_details`, `schedule_context`, Titan Go mobile change feeds, work-order projections, appointment projections or asset projections.

## UI/AI boundary

CRM Core active UI, AI and Interaction registries advertise only CRM-owned actions. A Field record supplied as context may still expose CRM commercial actions such as **Prepare Quote** or **Create Invoice**. It must not expose Field mutations such as assigning a technician, adding time, dispatching or rescheduling.

## Invariant

The alpha.27 invariant is:

> CRM Core may know about an external record, reference it, validate a compatibility request and route a legacy capability to its owner. It must never become a second authoritative writer for that external domain.

## Later retirement

Compatibility mappings and legacy capability aliases remain until the planned compatibility-retirement pass. They may be removed only after:

1. the destination extension exposes the native replacement contract;
2. callers have migrated to that contract;
3. cross-extension tests prove the replacement; and
4. no active CRM consumer depends on the compatibility name.
