<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use DateTimeImmutable;

final class PulseProjectionFreshness
{
    /** @return array{status:string,last_projection_at:?string,latest_projected_recorded_at:?string,latest_ingested_recorded_at:?string,projection_backlog_seconds:?int,last_projection_delay_seconds:?int,last_projection_age_seconds:?int} */
    public static function evaluate(?DateTimeImmutable $projectedAt, ?DateTimeImmutable $projectedRecordedAt, ?DateTimeImmutable $ingestedRecordedAt, DateTimeImmutable $now, int $thresholdSeconds): array
    {
        $thresholdSeconds = max(1, $thresholdSeconds);
        if ($projectedAt === null && $projectedRecordedAt === null && $ingestedRecordedAt === null) {
            return [
                'status' => 'idle', 'last_projection_at' => null, 'latest_projected_recorded_at' => null,
                'latest_ingested_recorded_at' => null, 'projection_backlog_seconds' => null,
                'last_projection_delay_seconds' => null, 'last_projection_age_seconds' => null,
            ];
        }
        $backlog = $ingestedRecordedAt === null ? 0 : ($projectedRecordedAt === null ? $thresholdSeconds + 1 : max(0, $ingestedRecordedAt->getTimestamp() - $projectedRecordedAt->getTimestamp()));
        $delay = ($projectedAt === null || $projectedRecordedAt === null) ? null : max(0, $projectedAt->getTimestamp() - $projectedRecordedAt->getTimestamp());
        $age = $projectedAt === null ? null : max(0, $now->getTimestamp() - $projectedAt->getTimestamp());
        return [
            'status' => $backlog > $thresholdSeconds ? 'degraded' : 'healthy',
            'last_projection_at' => $projectedAt?->format(DATE_ATOM),
            'latest_projected_recorded_at' => $projectedRecordedAt?->format(DATE_ATOM),
            'latest_ingested_recorded_at' => $ingestedRecordedAt?->format(DATE_ATOM),
            'projection_backlog_seconds' => $backlog,
            'last_projection_delay_seconds' => $delay,
            'last_projection_age_seconds' => $age,
        ];
    }
}
