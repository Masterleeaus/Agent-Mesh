<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Middleware;

use App\Helpers\Classes\Helper;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class EnsureCrmHostEnabled
{
    public function handle(Request $request, Closure $next): Response
    {
        abort_unless((bool) Helper::setting('crm_enabled', true), 404);

        $routeName = (string) $request->route()?->getName();
        if (str_starts_with($routeName, 'dashboard.user.crm.ai.')) {
            abort_unless((bool) Helper::setting('crm_assistant_enabled', true), 404);
        }
        if (str_starts_with($routeName, 'dashboard.user.crm.presentations.')) {
            abort_unless((bool) Helper::setting('crm_presentations_enabled', true), 404);
        }

        return $next($request);
    }
}
