# Client Compatibility

## Shared client contract — Titan MCP 1.5

The `initialize` result publishes `_meta["io.titanzero/client-contract"]` with schema `titan-mcp-client-contract/1`. It identifies the exact catalogue contract hash, the prepare/commit/status tools, the server write ceilings, support for two-phase mutation tickets, and the requirement that mutation arguments remain exact between client intent and server preparation.

Every `tools/list` entry also publishes `_meta["io.titanzero/tool-policy"]` with schema `titan-mcp-tool-policy/1`. This policy gives trusted Titan-aware clients a deterministic classification (`READ`, `WRITE`, `DESTRUCTIVE`, or `COORDINATE`), ticketability, preferred mutation flow, backup domains, exact-argument requirements, and post-write verification level. Standard MCP annotations remain present and are now accurate: additive repository writes are not mislabeled destructive, while delete/rollback/database mutation/Artisan mutation/commit remain destructive where appropriate.

## ChatGPT

Titan MCP uses MCP JSON-RPC over the configured HTTPS endpoint, standard tool annotations, structured tool results, explicit JSON Schemas, and stable tool names. Direct write tools remain supported when the ChatGPT product supplies its own write-action approval. Prefer inspect → expected SHA-256 → exact replace/batch write → verify.

For workflows that need a server-side recovery point *before* approval, use `titan_mutation_prepare` → approval → `titan_mutation_commit`.

## Codee Chrome extension

Codee v2.3.4+ should consume the Titan 1.5 client/tool policy metadata and prefer:

`exact mutation arguments` → `titan_mutation_prepare` → independently verify returned backup evidence → show bounded approval evidence → user approval → `titan_mutation_commit(ticketId)` → client readback/server commit verification → Codee audit receipt.

The commit call accepts only the ticket ID; Titan executes the immutable stored tool+arguments. The approval record exposes the argument SHA-256 and recovery domains while Codee keeps obvious secret literals out of its local preview record.

Use the canonical MCP endpoint and Titan API bearer token. Add the exact `chrome-extension://<32-character-extension-id>` origin to Titan MCP trusted origins. Wildcard Chrome-extension origins are not accepted. Codee v2.3.4 displays this origin in its MCP settings surface.

## Error handling

Tool execution failures are returned as MCP tool results with `isError: true` and a structured `TITAN_TOOL_EXECUTION_FAILED` payload. JSON-RPC errors remain reserved for protocol, authorization, and argument failures.
