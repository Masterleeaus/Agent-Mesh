<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_anomalies')) return;

        Schema::table('titan_signal_anomalies', function (Blueprint $table): void {
            if (! Schema::hasColumn('titan_signal_anomalies', 'decision_version')) {
                $table->unsignedBigInteger('decision_version')->default(0)->after('occurrence_count');
            }
            if (! Schema::hasColumn('titan_signal_anomalies', 'last_decision_event_id')) {
                $table->uuid('last_decision_event_id')->nullable()->after('decision_version');
                $table->index(['last_decision_event_id'], 'tsa_last_decision_event_idx');
            }
            if (! Schema::hasColumn('titan_signal_anomalies', 'last_decision_at')) {
                $table->timestamp('last_decision_at')->nullable()->after('last_decision_event_id');
            }
        });

        $this->seedDecisionEventTypes();
    }

    private function seedDecisionEventTypes(): void
    {
        if (! Schema::hasTable('titan_signal_type_versions')) return;

        $commonRequired = ['anomaly_id', 'anomaly_type', 'subject_type', 'subject_id', 'decision_version', 'reason', 'actor_id', 'actor_type', 'decided_at', 'evidence_reference'];
        $definitions = [
            'signal.anomaly.acknowledged' => ['required' => $commonRequired, 'optional' => ['suppression_until']],
            'signal.anomaly.suppressed' => ['required' => [...$commonRequired, 'suppression_until'], 'optional' => []],
            'signal.anomaly.resolved' => ['required' => $commonRequired, 'optional' => ['suppression_until']],
            'signal.anomaly.reopened' => ['required' => $commonRequired, 'optional' => ['suppression_until']],
        ];

        foreach ($definitions as $eventType => $definition) {
            if (DB::table('titan_signal_type_versions')->where('event_type', $eventType)->exists()) continue;
            $payload = [
                'event_type' => $eventType,
                'definition_version' => 1,
                'current_schema_version' => 1,
                'supported_schema_versions' => json_encode([1], JSON_THROW_ON_ERROR),
                'category' => 'operations',
                'allowed_scopes' => json_encode(['tenant', 'system'], JSON_THROW_ON_ERROR),
                'required_payload_fields' => json_encode($definition['required'], JSON_THROW_ON_ERROR),
                'optional_payload_fields' => json_encode($definition['optional'], JSON_THROW_ON_ERROR),
                'allow_additional_payload_fields' => false,
                'owner_source' => 'titan-signal-engine',
                'owner_service_id' => 'package:titan-signal-engine',
                'registrar_service_id' => 'migration:v0.18.0',
                'allowed_severities' => json_encode(['info'], JSON_THROW_ON_ERROR),
                'status' => 'active',
                'replacement_event_type' => null,
                'registered_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ];
            $payload['registration_checksum'] = self::checksum($payload);
            DB::table('titan_signal_type_versions')->insertOrIgnore($payload);
        }
    }

    /** @param array<string,mixed> $payload */
    private static function checksum(array $payload): string
    {
        ksort($payload);
        return hash('sha256', json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    public function down(): void
    {
        if (! Schema::hasTable('titan_signal_anomalies')) return;
        Schema::table('titan_signal_anomalies', function (Blueprint $table): void {
            if (Schema::hasColumn('titan_signal_anomalies', 'last_decision_event_id')) {
                $table->dropIndex('tsa_last_decision_event_idx');
            }
            $columns = [];
            foreach (['decision_version', 'last_decision_event_id', 'last_decision_at'] as $column) {
                if (Schema::hasColumn('titan_signal_anomalies', $column)) $columns[] = $column;
            }
            if ($columns !== []) $table->dropColumn($columns);
        });
    }
};
