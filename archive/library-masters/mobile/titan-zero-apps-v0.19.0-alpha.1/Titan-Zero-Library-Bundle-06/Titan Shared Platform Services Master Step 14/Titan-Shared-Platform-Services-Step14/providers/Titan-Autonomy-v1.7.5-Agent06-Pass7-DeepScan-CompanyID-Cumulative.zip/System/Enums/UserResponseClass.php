<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Enums;

enum UserResponseClass: string
{
    case ApprovedUnchanged = 'approved_unchanged';
    /** System-classified only after deterministic postcondition + observation reconciliation. */
    case AutonomousVerified = 'autonomous_verified';
    /** System-classified when an autonomous action's persisted postcondition is materially wrong. */
    case AutonomousIncorrect = 'autonomous_incorrect';
    case ApprovedMinorEdit = 'approved_minor_edit';
    case ApprovedMaterialEdit = 'approved_material_edit';
    case Rejected = 'rejected';
    case Reversed = 'reversed';
    case Failed = 'failed';
    case PartiallyCorrect = 'partially_correct';
    case Exception = 'exception';
    case Ambiguous = 'ambiguous';
    case InsufficientInformation = 'insufficient_information';
}
