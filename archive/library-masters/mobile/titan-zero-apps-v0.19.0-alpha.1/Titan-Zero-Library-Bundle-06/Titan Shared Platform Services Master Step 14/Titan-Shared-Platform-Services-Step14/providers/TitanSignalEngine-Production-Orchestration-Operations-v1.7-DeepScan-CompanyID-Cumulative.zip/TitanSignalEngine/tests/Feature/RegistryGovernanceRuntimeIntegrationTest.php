<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalSubscriberContract;
use App\Extensions\TitanSignalEngine\System\Data\EventTypeDefinition;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalSubscriptionDefinition;
use App\Extensions\TitanSignalEngine\System\Exceptions\ImmutableRegistryDefinitionException;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use App\Extensions\TitanSignalEngine\System\Models\SignalSubscriptionRuntime;
use App\Extensions\TitanSignalEngine\System\Models\SignalSubscriptionVersion;
use App\Extensions\TitanSignalEngine\System\Models\SignalTypeVersion;
use App\Extensions\TitanSignalEngine\System\Services\EventTypeRegistry;
use App\Extensions\TitanSignalEngine\System\Services\RegistryOwnershipPolicy;
use App\Extensions\TitanSignalEngine\System\Services\SignalRegistryAuthority;
use App\Extensions\TitanSignalEngine\System\Services\SignalSubscriptionRegistry;
use InvalidArgumentException;
use Tests\TestCase;

final class RegistryHealthySubscriber implements SignalSubscriberContract
{
    public function handle(SignalEvent $event, SignalDeliveryContext $delivery): void
    {
    }
}

final class RegistryGovernanceRuntimeIntegrationTest extends TestCase
{
    private SignalRegistryAuthority $authority;
    private EventTypeRegistry $eventTypes;
    private SignalSubscriptionRegistry $subscriptions;

    protected function setUp(): void
    {
        parent::setUp();
        foreach (glob(dirname(__DIR__, 2) . '/database/migrations/*.php') ?: [] as $migrationFile) {
            (require $migrationFile)->up();
        }

        $this->authority = new SignalRegistryAuthority('registry-feature-secret', [
            'crm-registry' => [
                'owner_source' => 'titan-crm',
                'permissions' => ['signal.registry.event.manage', 'signal.registry.subscription.manage'],
                'event_type_patterns' => ['crm.*'],
                'subscriber_key_patterns' => ['titan-crm.*'],
            ],
            'risk-registry' => [
                'owner_source' => 'titan-risk-engine',
                'permissions' => ['signal.registry.event.manage', 'signal.registry.subscription.manage'],
                'event_type_patterns' => ['risk.*'],
                'subscriber_key_patterns' => ['titan-risk.*'],
            ],
        ]);
        $policy = new RegistryOwnershipPolicy($this->authority);
        $this->eventTypes = new EventTypeRegistry($policy);
        $this->subscriptions = new SignalSubscriptionRegistry($policy, new \App\Extensions\TitanSignalEngine\System\Services\SignalSubscriptionRegistryRevision(), new \App\Extensions\TitanSignalEngine\System\Data\SignalRegistryCachePolicy(1));
    }

    public function test_event_registry_appends_immutable_versions_and_blocks_takeover(): void
    {
        $crm = $this->authority->issue('crm-registry');
        $definition = EventTypeDefinition::fromArray([
            'event_type' => 'crm.customer.created',
            'current_schema_version' => 1,
            'supported_schema_versions' => [1],
            'allowed_scopes' => ['tenant'],
            'owner_source' => 'titan-crm',
        ]);
        $this->eventTypes->register($definition, $crm);
        $this->eventTypes->evolve(EventTypeDefinition::fromArray([
            'event_type' => 'crm.customer.created',
            'current_schema_version' => 2,
            'supported_schema_versions' => [1, 2],
            'allowed_scopes' => ['tenant'],
            'owner_source' => 'titan-crm',
        ]), $crm);

        self::assertSame(2, SignalTypeVersion::query()->where('event_type', 'crm.customer.created')->count());
        self::assertSame(2, $this->eventTypes->find('crm.customer.created')?->definitionVersion);

        $this->expectException(InvalidArgumentException::class);
        $this->eventTypes->evolve(EventTypeDefinition::fromArray([
            'event_type' => 'crm.customer.created',
            'current_schema_version' => 3,
            'supported_schema_versions' => [1, 2, 3],
            'allowed_scopes' => ['tenant'],
            'owner_source' => 'titan-crm',
        ]), $this->authority->issue('risk-registry'));
    }

    public function test_registry_version_rows_cannot_be_mutated(): void
    {
        $crm = $this->authority->issue('crm-registry');
        $this->eventTypes->register(EventTypeDefinition::fromArray([
            'event_type' => 'crm.job.created',
            'current_schema_version' => 1,
            'supported_schema_versions' => [1],
            'allowed_scopes' => ['tenant'],
            'owner_source' => 'titan-crm',
        ]), $crm);

        $row = SignalTypeVersion::query()->where('event_type', 'crm.job.created')->firstOrFail();
        $row->status = 'disabled';
        $this->expectException(ImmutableRegistryDefinitionException::class);
        $row->save();
    }

    public function test_missing_subscription_handler_is_quarantined_without_breaking_matching(): void
    {
        $crm = $this->authority->issue('crm-registry');
        $this->subscriptions->register(SignalSubscriptionDefinition::fromArray([
            'subscriber_key' => 'titan-crm.healthy',
            'handler_class' => RegistryHealthySubscriber::class,
            'event_patterns' => ['crm.*'],
            'accepted_schema_versions' => [1],
        ]), $crm);
        $this->subscriptions->register(SignalSubscriptionDefinition::fromArray([
            'subscriber_key' => 'titan-crm.missing',
            'handler_class' => 'App\\Missing\\Subscriber',
            'event_patterns' => ['crm.*'],
            'accepted_schema_versions' => [1],
        ]), $crm);

        $event = new SignalEvent();
        $event->event_type = 'crm.customer.created';
        $event->schema_version = 1;
        $event->scope = 'tenant';
        $event->category = null;
        $event->vertical_key = null;

        $matches = $this->subscriptions->matching($event);
        self::assertSame(['titan-crm.healthy'], array_map(static fn ($definition): string => $definition->subscriberKey, $matches));
        self::assertSame('quarantined', SignalSubscriptionRuntime::query()->where('subscriber_key', 'titan-crm.missing')->value('runtime_status'));
        self::assertSame(1, SignalSubscriptionVersion::query()->where('subscriber_key', 'titan-crm.missing')->count());
    }
}
