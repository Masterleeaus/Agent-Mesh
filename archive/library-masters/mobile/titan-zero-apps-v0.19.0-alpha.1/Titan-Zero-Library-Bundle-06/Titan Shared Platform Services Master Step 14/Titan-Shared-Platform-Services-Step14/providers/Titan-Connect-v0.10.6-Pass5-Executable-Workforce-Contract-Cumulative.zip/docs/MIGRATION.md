# Titan Connect v0.10.4 Migration / Upgrade Guide

Titan Connect owns additive `ext_titan_connect_*` persistence. Legacy Chatbot tables remain owned by Chatbot and are never renamed/deleted automatically.

## Upgrade from v0.5.0

1. Back up database/files.
2. Drain or pause Titan Connect queue workers during deployment.
3. Install the v0.6 extension files.
4. Run the host's normal migrations. Migration `2026_08_09_000004_add_official_comms_donor_features.php`:
   - adds assignment/pin/color/priority/close/contact fields to external threads;
   - creates company-scoped external contacts;
   - creates contact tags and thread/tag pivot;
   - creates canned responses;
   - creates voice-call and voice-transcript tables.
5. Publish `titan-connect-assets` so the operator and voice clients are available.
6. Resume workers and run the standalone/host certification checks.

The migration is additive and does not rewrite existing messages, deliveries, credentials or attachment paths.

## Existing Chatbot Team Chat installations

Use `php artisan titan-connect:import-legacy-team-chat` after canonical migrations. The importer reads the legacy `ext_chatbot_team_*` tables, writes company-scoped Titan Connect records, records provenance and is designed to be re-runnable/idempotent. Titan Connect never deletes the source tables automatically.

## Company boundary history

Pre-v0.4 canonical installs use migration `000003` to rename canonical `tenant_id` columns to `company_id`. v0.6 introduces no alternative tenant key; all new tables use `company_id` from creation.

## Operational compatibility

- Existing v0.4/v0.5 attachment paths remain readable; new files continue under the company namespace.
- Existing provider connections remain valid.
- WhatsApp defaults to Meta transport unless the connection explicitly selects `settings.transport=twilio` and Twilio credentials are provisioned in the encrypted vault.
- Meta OAuth/Telegram onboarding create or update canonical connections rather than donor tables.
- Voice is a new canonical provider key and requires a company-owned voice connection plus encrypted provider credentials.

## Upgrade to v0.7.0

1. Deploy the v0.7 extension files.
2. Run migration `2026_08_09_000005_harden_voice_runtime.php`; it adds nullable `client_event_id` to voice transcripts and a company/call/event unique key without rewriting existing transcript rows.
3. Republish Titan Connect assets so `settings.js`, updated operator inbox assets and voice controls are available.
4. Review `titan-connect.rate_limits` defaults and use a shared cache store in multi-node production deployments.
5. Run `php artisan titan-connect:diagnose` and the host certification suite before enabling production traffic.


## Retry after failed v0.10.1 MySQL installation

The v0.10.1 installer could fail while creating `ext_titan_connect_external_thread_reads` because Laravel generated a foreign-key identifier longer than MySQL's 64-character limit. The installer reported zero recorded migrations, but MySQL DDL may still have created some earlier tables or the read table itself before the failing `ALTER TABLE`.

v0.10.2 is designed to retry safely:

1. Five potentially overlong foreign keys now use explicit short names in their owning migrations.
2. Migration `2026_08_09_000006_repair_partial_mysql_install.php` inspects `information_schema` and restores missing foreign keys/indexes on the affected tables.
3. Existing keys/indexes are detected before creation, so the repair can run whether the prior failed installer left no tables, some tables, or partial table metadata.
4. The repair migration does not delete messages, credentials, connections, or other Titan Connect data.

Do not manually drop Titan Connect tables solely because of the v0.10.1 error; install v0.10.2 and let the repair migration reconcile the partial DDL state.


## Upgrade to v0.10.4 — live MagicAI menu materialization

The live Titan Zero host stores sidebar structure in the shared `menus` table. v0.10.4 adds migration `2026_08_09_000007_sync_magicai_menu_rows.php`, which idempotently materializes Titan Connect Inbox/Channels user rows and Super Admin channel settings beneath the host's existing Settings root. The migration does not store company/user unread counts in the shared badge column. After synchronization it attempts MagicAI menu cache regeneration through `MenuService::regenerate()`.

`php artisan titan-connect:host-sync` can be rerun safely after install or menu customization.

## v0.10.4 — in-request installer class reload safety

Titan's custom extension installer upgrades an extension inside an already-booted Laravel request. PHP classes resolved from the previously installed Titan Connect release can remain loaded until the next request even after the extension files are replaced. v0.10.4 therefore makes migration `2026_08_09_000007_sync_magicai_menu_rows.php` fully self-contained: it writes the MagicAI `menus` rows directly through Laravel's DB/Schema facades and does not resolve Titan Connect runtime services or call newly-added navigation methods. The optional `titan-connect:host-sync` command remains a post-install/manual repair command and is not advertised as an automatic same-request upgrade hook.
