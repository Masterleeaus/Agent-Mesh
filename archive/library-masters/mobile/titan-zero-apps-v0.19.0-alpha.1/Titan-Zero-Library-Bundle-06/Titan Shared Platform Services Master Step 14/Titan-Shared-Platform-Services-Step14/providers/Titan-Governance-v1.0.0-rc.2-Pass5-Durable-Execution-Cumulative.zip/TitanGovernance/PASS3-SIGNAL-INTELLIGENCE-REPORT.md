# Titan Governance v0.4.0 — Pass 3 Signal Intelligence & Durable Projections

## Scope

Pass 3 adds the Governance-owned operational projection layer without changing source-of-truth ownership or enabling governed mutations.

## Implemented

- Signal Heatmap from normalized Titan Signal snapshots.
- Deterministic operational-pressure and bottleneck detection from queue depth, oldest-item age, failure rate, blocked work and saturation.
- Circuit-breaker visibility with OPEN/HALF_OPEN/CLOSED/DISABLED normalization.
- Durable, tenant-scoped projection history in `titan_governance_views` with SHA-256 payload deduplication.
- Separate source-health history and recent incident-rate projection.
- Read-only JSON endpoints for heatmap, pressure, breakers and projection history.
- `titan:titan-governance:refresh-projections --tenant=<id>` for explicit refresh/cron integration.
- Projection writes fail independently from live source reads.

## Ownership invariants

- Titan Signal remains canonical for telemetry.
- Titan Autonomy remains canonical for desired/earned/effective authority.
- Operational pressure is a Governance-derived management metric, **not** Titan Risk.
- Circuit state is observed, never opened/closed by Governance in this pass.
- Projection rows are cache/history only and never confer authority.
