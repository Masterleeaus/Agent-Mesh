<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Contracts\CompilationLifecycleRepositoryContract;
use App\Extensions\TitanNexus\System\Contracts\CompilationRepositoryContract;
use App\Extensions\TitanNexus\System\Contracts\ProvisioningExecutorContract;
use App\Extensions\TitanNexus\System\Contracts\VerticalDefinitionSourceContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompilationLifecycleEvent;
use App\Extensions\TitanNexus\System\Domain\CompilationLifecycleStage;
use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlan;
use App\Extensions\TitanNexus\System\Domain\ProvisioningReceipt;
use App\Extensions\TitanNexus\System\Domain\ProvisioningReceiptStatus;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Services\DeterministicNexusCompiler;
use App\Extensions\TitanNexus\System\Services\DeterministicProvisioningPlanner;
use App\Extensions\TitanNexus\System\Services\NexusControlCentreService;
use App\Extensions\TitanNexus\System\Services\NexusManager;
use App\Extensions\TitanNexus\System\Services\SemanticNexusValidator;
use App\Extensions\TitanNexus\System\Adapters\Platform\PlatformReadinessAdapter;

$root = dirname(__DIR__);
foreach ([
    '/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php','/System/Support/CanonicalJson.php','/System/Support/DeterministicMerge.php','/System/Support/RedactedPayload.php',
    '/System/Domain/CompilationStatus.php','/System/Domain/CompilationLifecycleStage.php','/System/Domain/CompilationLifecycleEvent.php',
    '/System/Domain/ValidationSeverity.php','/System/Domain/ValidationFinding.php','/System/Domain/ValidationResult.php','/System/Domain/ValueObjects/TraceContext.php',
    '/System/Domain/BusinessProfile.php','/System/Domain/CompiledTitanConfig.php','/System/Domain/SemanticChangeKind.php','/System/Domain/SemanticChangeDisposition.php',
    '/System/Domain/SemanticDiffEntry.php','/System/Domain/ConfigurationDiff.php','/System/Domain/ProvisioningReceiptStatus.php','/System/Domain/ProvisioningPlanStatus.php',
    '/System/Domain/ProvisioningOperation.php','/System/Domain/ProvisioningReceipt.php','/System/Domain/ProvisioningPlan.php','/System/Domain/ProvisioningExecutionContext.php',
    '/System/Domain/VerticalDefinition.php','/System/Domain/CompilationPreview.php','/System/Domain/RecompilePlanStatus.php','/System/Domain/RecompilePlan.php',
    '/System/Domain/NexusCompilation.php','/System/Domain/ControlCentreSnapshot.php',
    '/System/Contracts/NexusCompilerContract.php','/System/Contracts/ConfigurationDifferContract.php','/System/Contracts/VerticalDefinitionSourceContract.php',
    '/System/Contracts/PlatformReadinessSourceContract.php','/System/Contracts/NexusValidatorContract.php','/System/Contracts/ProvisioningPlannerContract.php',
    '/System/Contracts/ProvisioningExecutorContract.php','/System/Contracts/CompilationRepositoryContract.php','/System/Contracts/CompilationLifecycleRepositoryContract.php',
    '/System/Contracts/NexusManagerContract.php','/System/Contracts/NexusControlCentreContract.php',
    '/System/Exceptions/NexusValidationException.php',
    '/System/Adapters/Platform/PlatformReadinessAdapter.php','/System/Services/DeterministicNexusCompiler.php','/System/Services/SemanticConfigurationDiffer.php',
    '/System/Services/SemanticNexusValidator.php','/System/Services/DeterministicProvisioningPlanner.php','/System/Services/NexusManager.php','/System/Services/NexusControlCentreService.php',
] as $file) {
    require_once $root . $file;
}

function lifeCheck(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

final class MemoryCompilationRepository implements CompilationRepositoryContract
{
    /** @var array<int,array<string,array<string,mixed>>> */
    private array $rows = [];
    /** @var list<array{tenant:int,uuid:string}> */
    private array $order = [];

    public function save(NexusCompilation $compilation): NexusCompilation
    {
        $tenant = $compilation->businessProfile()->tenantCompanyId();
        $uuid = strtolower($compilation->compilationUuid());
        $existing = $this->rows[$tenant][$uuid] ?? null;
        $expected = $compilation->entityVersion();
        if ($existing === null) {
            if ($expected !== 0) { throw new LogicException('stale create'); }
            $next = 1;
            $this->order[] = ['tenant'=>$tenant,'uuid'=>$uuid];
        } else {
            if ((int)($existing['entity_version'] ?? 0) !== $expected) { throw new LogicException('stale update'); }
            $next = $expected + 1;
        }
        $row = $compilation->toPersistenceArray();
        $row['entity_version'] = $next;
        $this->rows[$tenant][$uuid] = $row;
        return NexusCompilation::fromPersistence($row);
    }

    public function findForTenant(int $tenantCompanyId, string $compilationUuid): ?NexusCompilation
    {
        $row = $this->rows[$tenantCompanyId][strtolower($compilationUuid)] ?? null;
        return is_array($row) ? NexusCompilation::fromPersistence($row) : null;
    }

    public function latestForTenant(int $tenantCompanyId, int $limit = 25): array
    {
        $items = [];
        foreach (array_reverse($this->order) as $entry) {
            if ($entry['tenant'] !== $tenantCompanyId) { continue; }
            $item = $this->findForTenant($tenantCompanyId, $entry['uuid']);
            if ($item !== null) { $items[] = $item; }
            if (count($items) >= $limit) { break; }
        }
        return $items;
    }

    public function lineageForTenant(int $tenantCompanyId, string $compilationUuid, int $limit = 25): array
    {
        $items = [];
        $seen = [];
        $uuid = strtolower($compilationUuid);
        while ($uuid !== '' && count($items) < $limit) {
            if (isset($seen[$uuid])) { throw new LogicException('cycle'); }
            $seen[$uuid] = true;
            $item = $this->findForTenant($tenantCompanyId, $uuid);
            if ($item === null) { break; }
            $items[] = $item;
            $uuid = strtolower($item->parentCompilationUuid() ?? '');
        }
        return $items;
    }
}

final class MemoryLifecycleRepository implements CompilationLifecycleRepositoryContract
{
    /** @var array<string,array<string,mixed>> */
    private array $rows = [];
    /** @var list<string> */
    private array $order = [];

    public function record(CompilationLifecycleEvent $event): CompilationLifecycleEvent
    {
        $id = $event->eventId();
        if (!isset($this->rows[$id])) {
            $this->rows[$id] = $event->toPersistenceArray();
            $this->order[] = $id;
        }
        return CompilationLifecycleEvent::fromPersistence($this->rows[$id]);
    }

    public function historyForTenant(int $tenantCompanyId, string $compilationUuid, int $limit = 100): array
    {
        $out = [];
        foreach ($this->order as $id) {
            $event = CompilationLifecycleEvent::fromPersistence($this->rows[$id]);
            if ($event->tenantCompanyId() !== $tenantCompanyId || strtolower($event->compilationUuid()) !== strtolower($compilationUuid)) { continue; }
            $out[] = $event;
            if (count($out) >= $limit) { break; }
        }
        return $out;
    }
}

function lifeProfile(string $profileVersion, string $currency = 'AUD'): BusinessProfile
{
    return BusinessProfile::fromArray([
        'tenant_company_id'=>42,'profile_version'=>$profileVersion,'vertical_id'=>'cleaning','vertical_version'=>'2026.08',
        'jurisdiction'=>['country_code'=>'AU','region'=>'VIC'],'timezone'=>'Australia/Melbourne',
        'sections'=>['crm'=>['enabled'=>true],'billing'=>['currency'=>$currency]],
    ]);
}
function lifeTrace(string $trace, string $causation): TraceContext
{
    return TraceContext::fromArray([
        'tenant_company_id'=>42,'trace_id'=>$trace,'correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>$causation,
    ]);
}

$source = new class implements VerticalDefinitionSourceContract {
    public function resolve(BusinessProfile $profile): VerticalDefinition
    {
        return VerticalDefinition::fromArray([
            'vertical_id'=>$profile->verticalId(),'vertical_version'=>$profile->verticalVersion(),'sections'=>[],
            'provisioning'=>['routes'=>[
                'sections.crm'=>['capability'=>'crm.configuration.apply','depends_on'=>[]],
                'sections.billing'=>['capability'=>'billing.configuration.apply','depends_on'=>['sections.crm']],
            ]],
        ]);
    }
};
$executor = new class implements ProvisioningExecutorContract {
    public function execute(ProvisioningPlan $plan, TraceContext $traceContext, bool $approvalGranted = false, ?\App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext $executionContext = null): ProvisioningPlan
    {
        $receipts = [];
        foreach ($plan->operations() as $operation) {
            $receipts[] = new ProvisioningReceipt(
                $operation->operationId(),$operation->idempotencyKey(),ProvisioningReceiptStatus::Applied,
                'backup:'.$operation->operationId(),true,true,'audit:'.$operation->operationId(),'rollback:'.$operation->operationId(),
            );
        }
        return $plan->withReceipts($receipts);
    }
};

$compilations = new MemoryCompilationRepository();
$lifecycle = new MemoryLifecycleRepository();
$manager = new NexusManager(
    new DeterministicNexusCompiler('0.5.0'),$source,new SemanticNexusValidator(new PlatformReadinessAdapter()),null,
    new DeterministicProvisioningPlanner(),$executor,$compilations,[],true,$lifecycle,
);

$parentTrace = lifeTrace('11111111-1111-4111-8111-111111111111','33333333-3333-4333-8333-333333333333');
$parent = $manager->newDraft(lifeProfile('1.0.0'),$parentTrace,'44444444-4444-4444-8444-444444444444');
lifeCheck($parent->entityVersion() === 1, 'draft persists as entity version 1');
$validation = $manager->validateDraft($parent);
lifeCheck(!$validation->hasErrors(), 'validation succeeds');
$compiledParent = $manager->compileDraft($parent,'1');
lifeCheck($compiledParent->entityVersion() === 2, 'compile advances durable entity version');

$parentEvents = $lifecycle->historyForTenant(42,$parent->compilationUuid());
$parentStages = array_map(static fn (CompilationLifecycleEvent $e): string => $e->stage()->value,$parentEvents);
lifeCheck($parentStages === ['draft_created','validation_completed','compiled'], 'parent lifecycle preserves draft, validation, compile order without duplicate validation');
lifeCheck($parentEvents[1]->payload()['validation_result']['status'] === 'ready', 'validation result is durable even before compilation persistence');

$childTrace = lifeTrace('55555555-5555-4555-8555-555555555555','44444444-4444-4444-8444-444444444444');
$recompile = $manager->planRecompile($compiledParent,lifeProfile('2.0.0','NZD'),$childTrace,'66666666-6666-4666-8666-666666666666','2');
$child = $recompile->candidate();
lifeCheck($child->parentCompilationUuid() === $compiledParent->compilationUuid(), 'recompile child preserves parent lineage');
lifeCheck($child->configurationDiff() !== null, 'semantic diff is attached to durable child');

$planned = $manager->planProvisioning($child);
$executed = $manager->executeProvisioning($planned,$childTrace);
lifeCheck($executed->provisioningPlan()?->executed() === true, 'provisioning execution persists receipt-bearing plan');
lifeCheck(count($executed->provisioningPlan()?->receipts() ?? []) > 0, 'receipts are durable');

$reloaded = $compilations->findForTenant(42,$child->compilationUuid());
lifeCheck($reloaded !== null, 'child reloads from persistence');
lifeCheck($reloaded->configurationDiff()?->fingerprint() === $executed->configurationDiff()?->fingerprint(), 'diff survives persistence round trip');
lifeCheck($reloaded->provisioningPlan()?->fingerprint() === $executed->provisioningPlan()?->fingerprint(), 'provisioning plan and receipts survive persistence round trip');

$childEvents = $lifecycle->historyForTenant(42,$child->compilationUuid());
$childStages = array_map(static fn (CompilationLifecycleEvent $e): string => $e->stage()->value,$childEvents);
foreach (['validation_completed','compiled','diff_calculated','recompile_planned','provisioning_planned','provisioning_executed'] as $requiredStage) {
    lifeCheck(in_array($requiredStage,$childStages,true), "child lifecycle contains {$requiredStage}");
}
$last = $childEvents[count($childEvents)-1];
lifeCheck($last->traceContext()->traceId() === $childTrace->traceId(), 'execution lifecycle preserves action trace');
lifeCheck(($last->payload()['receipts'][0]['status'] ?? null) === 'applied', 'receipt outcome is present in durable lifecycle payload');

$before = count($childEvents);
$lifecycle->record($last);
lifeCheck(count($lifecycle->historyForTenant(42,$child->compilationUuid())) === $before, 'lifecycle record is idempotent on retry');
lifeCheck($lifecycle->historyForTenant(99,$child->compilationUuid()) === [], 'lifecycle history is tenant isolated');

$lineage = $compilations->lineageForTenant(42,$child->compilationUuid());
lifeCheck(count($lineage) === 2 && $lineage[0]->compilationUuid() === $child->compilationUuid() && $lineage[1]->compilationUuid() === $parent->compilationUuid(), 'durable lineage reconstructs child to parent');

$control = new NexusControlCentreService($compilations,$lifecycle);
$snapshot = $control->snapshot(42,$child->compilationUuid())->toArray();
lifeCheck(count($snapshot['selected']['lifecycle'] ?? []) === count($childEvents), 'Control Centre exposes durable lifecycle timeline');
lifeCheck(($snapshot['selected']['lifecycle'][0]['trace']['tenant_company_id'] ?? null) === 42, 'Control Centre lifecycle keeps tenant trace evidence');


$badProfile = BusinessProfile::fromArray([
    'tenant_company_id'=>42,'profile_version'=>'bad-1','vertical_id'=>'cleaning','vertical_version'=>'2026.08',
    'jurisdiction'=>['country_code'=>'AU','region'=>'VIC'],'timezone'=>'Australia/Melbourne',
    'sections'=>['integration'=>['api_key'=>'forbidden']],
]);
$badTrace = lifeTrace('77777777-7777-4777-8777-777777777777','66666666-6666-4666-8666-666666666666');
$badDraft = $manager->newDraft($badProfile,$badTrace,'88888888-8888-4888-8888-888888888888');
$blocked = false;
try { $manager->compileDraft($badDraft,'1'); }
catch (\App\Extensions\TitanNexus\System\Exceptions\NexusValidationException) { $blocked = true; }
lifeCheck($blocked, 'invalid profile is blocked from compilation');
$badReloaded = $compilations->findForTenant(42,$badDraft->compilationUuid());
lifeCheck($badReloaded?->status()->value === 'failed', 'failed validation aggregate is durable');
$badStages = array_map(static fn (CompilationLifecycleEvent $e): string => $e->stage()->value,$lifecycle->historyForTenant(42,$badDraft->compilationUuid()));
lifeCheck($badStages === ['draft_created','validation_failed'], 'failed validation lifecycle is durable and ordered');

fwrite(STDOUT,"PASS: Titan Nexus durable compilation lifecycle checks\n");
