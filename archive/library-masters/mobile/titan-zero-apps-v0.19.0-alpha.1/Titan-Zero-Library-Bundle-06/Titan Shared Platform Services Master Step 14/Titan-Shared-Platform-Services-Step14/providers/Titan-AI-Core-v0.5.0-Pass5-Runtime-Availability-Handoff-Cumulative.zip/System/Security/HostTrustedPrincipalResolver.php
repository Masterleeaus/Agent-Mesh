<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Security;

use App\Extensions\TitanAICore\System\Contracts\TrustedPrincipalResolverContract;
use App\Extensions\TitanAICore\System\DTO\TrustedPrincipal;
use App\Extensions\TitanAICore\System\Exceptions\SecurityContextException;

final class HostTrustedPrincipalResolver implements TrustedPrincipalResolverContract
{
    /** @param array<int,string>|null $permissionCatalog */
    public function __construct(private readonly ?array $permissionCatalog = null) {}

    public function resolve(object $principal): TrustedPrincipal
    {
        $actorId = $this->resolveActorId($principal);
        $tenantCompanyId = $this->resolveTenantCompanyId($principal);
        $actorType = $this->resolveActorType($principal);
        $permissions = $this->resolvePermissions($principal);
        $authorityLevel = $this->readInt($principal, ['titan_authority_level', 'authority_level']) ?? 1;

        return new TrustedPrincipal(
            actorId: $actorId,
            actorType: $actorType,
            tenantCompanyId: $tenantCompanyId,
            permissions: $permissions,
            authorityLevel: max(0, $authorityLevel),
            authenticationSource: 'host-authenticated-principal',
        );
    }

    private function resolveActorId(object $principal): string
    {
        if (method_exists($principal, 'getAuthIdentifier')) {
            $id = $principal->getAuthIdentifier();
            if (is_scalar($id) && (string) $id !== '') {
                return (string) $id;
            }
        }

        $id = $this->read($principal, ['id', 'uuid']);
        if ($id !== null && (string) $id !== '') {
            return (string) $id;
        }

        throw new SecurityContextException('ACTOR_ID_UNRESOLVED', 'Authenticated principal does not expose a stable actor identifier.');
    }

    private function resolveTenantCompanyId(object $principal): string
    {
        if (method_exists($principal, 'titanTenantCompanyId')) {
            $value = $principal->titanTenantCompanyId();
            if (is_scalar($value) && (string) $value !== '') {
                return (string) $value;
            }
        }

        $candidates = function_exists('config')
            ? (array) config('titan-ai-core.security.tenant_principal_attributes', ['company_id', 'tenant_company_id'])
            : ['company_id', 'tenant_company_id'];
        $value = $this->read($principal, $candidates);
        if ($value !== null && (string) $value !== '') {
            return (string) $value;
        }

        throw new SecurityContextException('TENANT_CONTEXT_UNRESOLVED', 'Authenticated principal does not expose an approved Titan tenant identifier.');
    }

    private function resolveActorType(object $principal): string
    {
        if (method_exists($principal, 'titanActorType')) {
            $value = $principal->titanActorType();
            if (is_string($value) && $value !== '') {
                return $value;
            }
        }

        $value = $this->read($principal, ['actor_type']);
        return is_string($value) && $value !== '' ? $value : 'human';
    }

    /** @return array<int,string> */
    private function resolvePermissions(object $principal): array
    {
        $catalog = $this->permissionCatalog ?? [
            'ai.core.read',
            'ai.core.health.read',
            'ai.core.admin',
            'ai.core.plan.create',
        ];
        if (!method_exists($principal, 'can')) {
            return [];
        }

        $allowed = [];
        foreach ($catalog as $capability) {
            try {
                if ($principal->can($capability)) {
                    $allowed[] = $capability;
                }
            } catch (\Throwable) {
                // Unknown host ability remains denied.
            }
        }
        return $allowed;
    }

    /** @param array<int,string> $names */
    private function read(object $principal, array $names): mixed
    {
        foreach ($names as $name) {
            if (method_exists($principal, 'getAttribute')) {
                try {
                    $value = $principal->getAttribute($name);
                    if ($value !== null && $value !== '') {
                        return $value;
                    }
                } catch (\Throwable) {
                    // Continue to public-property probing.
                }
            }
            if (isset($principal->{$name}) || property_exists($principal, $name)) {
                try {
                    $value = $principal->{$name};
                    if ($value !== null && $value !== '') {
                        return $value;
                    }
                } catch (\Throwable) {
                    // Continue to next candidate.
                }
            }
        }
        return null;
    }

    /** @param array<int,string> $names */
    private function readInt(object $principal, array $names): ?int
    {
        $value = $this->read($principal, $names);
        return is_numeric($value) ? (int) $value : null;
    }
}
