# Signal Events

Canonical operation events include `nexus.operation.authorized`, `nexus.operation.blocked`, `nexus.operation.applied`, `nexus.operation.already_applied`, `nexus.operation.failed`, and `nexus.operation.skipped`. Every event carries tenant, trace, correlation and causation context through the public Signal gateway.
