# Titan AI Vision Architecture

Primary Blueprint profile: `intelligence-engine`. Titan AI Vision owns visual evidence state, spatial annotations, confidence and human review state. It does not own CRM/job/quote/invoice/asset truth. Cross-domain changes are proposals only and must be executed by the authoritative domain through governed capabilities/Command Bus.

## v1.3 Evidence comparison and readiness
Before/after pairing is deterministic and based on explicit pair keys or normalised capture keys. Provider-returned comparison factors are treated as untrusted inference inputs; Titan computes comparability scores itself. Completion Assurance readiness is an evidence-quality package only and cannot mutate job completion state.
