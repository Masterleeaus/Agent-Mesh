<div class="tse-head">
    <div>
        <h1>{{ $pageTitle }}</h1>
        <div class="tse-sub">{{ $pageSubtitle }}</div>
    </div>
    <span class="tse-badge">{{ strtoupper((string)($dashboard['health']['status'] ?? 'unknown')) }}</span>
</div>
<div class="tse-page-tabs" aria-label="Signal Engine sections">
    @php
        $tabs = [
            'overview' => ['Overview','dashboard.admin.titan.signal.engine.overview'],
            'pulse-health' => ['Pulse and Health','dashboard.admin.titan.signal.engine.pulse-health'],
            'events-traces' => ['Events and Traces','dashboard.admin.titan.signal.engine.events-traces'],
            'anomalies' => ['Anomalies','dashboard.admin.titan.signal.engine.anomalies'],
            'deliveries-dlq' => ['Deliveries and DLQ','dashboard.admin.titan.signal.engine.deliveries-dlq'],
            'lifecycle-archives' => ['Lifecycle and Archives','dashboard.admin.titan.signal.engine.lifecycle-archives'],
            'registries' => ['Registries','dashboard.admin.titan.signal.engine.registries'],
            'diagnostics' => ['Diagnostics','dashboard.admin.titan.signal.engine.diagnostics'],
        ];
        $rq = array_filter([
            'scope'=>$dashboard['request']['scope'] ?? 'system',
            'tenant_company_id'=>$dashboard['request']['tenant_company_id'] ?? null,
            'window'=>$dashboard['request']['window'] ?? '5m',
            'limit'=>$dashboard['request']['limit'] ?? 100,
        ], static fn($v)=>$v!==null && $v!=='');
    @endphp
    @foreach($tabs as $key=>$tab)
        <a href="{{ route($tab[1], $rq) }}" @if(($activePage ?? '')===$key) aria-current="page" @endif>{{ $tab[0] }}</a>
    @endforeach
</div>
