# Titan Assets Option A — Installation Order

1. Confirm Titan CRM is installed and enabled. The supplied host dump reports CRM `1.3.0-alpha.17`.
2. Install `TitanAssets` through Titan Extension Manager 1.7.8.
3. Install the companion Titan Locker `1.1.0-alpha.2` Assets Convergence package.
4. Run `php artisan optimize:clear` only if the installer/host has not already cleared caches.
5. Re-open navigation. The Assets self-healer adopts the historical asset rows and leaves inventory/supplies under the former Gear parent.

Do not manually delete the historical `crm_locker_*` asset tables. They are retained as persistence contracts and their records remain authoritative under Titan Assets ownership.
