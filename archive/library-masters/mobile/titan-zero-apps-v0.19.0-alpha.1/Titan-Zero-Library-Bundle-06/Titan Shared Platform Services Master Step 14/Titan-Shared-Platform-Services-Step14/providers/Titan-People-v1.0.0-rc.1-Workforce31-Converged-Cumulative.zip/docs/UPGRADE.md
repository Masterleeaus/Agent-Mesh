# Upgrade

Titan People migrations are forward-only, extension-owned and tenant-scoped. Legacy HRCore conversion remains an explicit mapped import; upgrades never rewrite host HR tables.

## 0.1.0-alpha.4 → 1.0.0-rc.1

1. Back up all `titan_people_*` tables and the configured private `private/titan-people/` document root.
2. Confirm the current package is `0.1.0-alpha.4` and no People migration is partially applied.
3. Install `1.0.0-rc.1` through Titan Extension Installer 1.7.8.
4. Run extension migrations once. Migrations are idempotent at the schema boundary and retain People-owned data.
5. Run `titan-people:host-sync` to reconcile navigation contributions.
6. Confirm `titan-people:dispatch-outbox --limit=25` runs without an exception. If the host Signal port is unavailable, delivery fails closed and unpublished rows remain replayable.
7. Verify People overview, directory, organisation, leave, lifecycle, holidays and My Profile under two tenant contexts before reopening administrative writes.

Do not downgrade by deleting newer columns or tables. Restore the pre-upgrade backup instead if rollback is required.
