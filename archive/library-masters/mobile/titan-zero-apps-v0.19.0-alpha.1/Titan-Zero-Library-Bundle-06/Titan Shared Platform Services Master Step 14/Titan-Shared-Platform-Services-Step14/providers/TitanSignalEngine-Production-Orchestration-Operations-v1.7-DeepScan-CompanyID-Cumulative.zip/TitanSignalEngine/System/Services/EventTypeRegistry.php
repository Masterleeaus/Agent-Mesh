<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\EventTypeRegistryContract;
use App\Extensions\TitanSignalEngine\System\Data\EventTypeDefinition;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryIdentity;
use App\Extensions\TitanSignalEngine\System\Models\SignalType;
use App\Extensions\TitanSignalEngine\System\Models\SignalTypeVersion;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

final class EventTypeRegistry implements EventTypeRegistryContract
{
    public function __construct(private readonly RegistryOwnershipPolicy $ownership)
    {
    }

    public function register(EventTypeDefinition $definition, SignalRegistryIdentity $registrar, ?string $ownerServiceId = null): void
    {
        $this->writeDefinition($definition, $registrar, $ownerServiceId, false);
    }

    public function evolve(EventTypeDefinition $definition, SignalRegistryIdentity $registrar, ?string $ownerServiceId = null): void
    {
        $this->writeDefinition($definition, $registrar, $ownerServiceId, true);
    }

    public function find(string $eventType): ?EventTypeDefinition
    {
        $eventType = trim($eventType);
        if ($eventType === '') return null;

        try {
            if (Schema::hasTable('titan_signal_type_versions')) {
                /** @var SignalTypeVersion|null $row */
                $row = SignalTypeVersion::query()
                    ->where('event_type', $eventType)
                    ->orderByDesc('definition_version')
                    ->first();
                if ($row !== null) return $this->definitionFromVersion($row);
            }

            if (Schema::hasTable('titan_signal_types')) {
                /** @var SignalType|null $legacy */
                $legacy = SignalType::query()->where('event_type', $eventType)->first();
                if ($legacy !== null) return $this->definitionFromLegacy($legacy);
            }
        } catch (Throwable) {
            // Early install/bootstrap can legitimately fall through to package-owned definitions.
        }

        return $this->configuredDefinition($eventType);
    }

    public function history(string $eventType): array
    {
        $eventType = trim($eventType);
        if ($eventType === '') return [];
        if (! Schema::hasTable('titan_signal_type_versions')) {
            $configured = $this->configuredDefinition($eventType);
            return $configured === null ? [] : [$configured];
        }

        $history = SignalTypeVersion::query()
            ->where('event_type', $eventType)
            ->orderBy('definition_version')
            ->limit(max(1, min((int) config('titan-signal-engine.registry_history_limit', 1000), 5000)))
            ->cursor()
            ->map(fn (SignalTypeVersion $row): EventTypeDefinition => $this->definitionFromVersion($row))
            ->values()
            ->all();
        if ($history !== []) return $history;
        $configured = $this->configuredDefinition($eventType);
        return $configured === null ? [] : [$configured];
    }

    public function validate(SignalEnvelope $signal): EventTypeDefinition
    {
        $definition = $this->find($signal->eventType);
        if ($definition === null) {
            throw new InvalidArgumentException("Signal event type {$signal->eventType} is not registered.");
        }
        $definition->validate($signal);
        return $definition;
    }

    private function writeDefinition(
        EventTypeDefinition $definition,
        SignalRegistryIdentity $registrar,
        ?string $ownerServiceId,
        bool $evolution,
    ): void {
        if (! Schema::hasTable('titan_signal_type_versions')) {
            throw new RuntimeException('Versioned Signal event type registry is not installed.');
        }

        DB::transaction(function () use ($definition, $registrar, $ownerServiceId, $evolution): void {
            /** @var SignalTypeVersion|null $latest */
            $latest = SignalTypeVersion::query()
                ->where('event_type', $definition->eventType)
                ->orderByDesc('definition_version')
                ->lockForUpdate()
                ->first();

            if (! $evolution && $latest !== null) {
                throw new InvalidArgumentException('Signal event type already exists; use evolve() to create a new immutable definition version.');
            }
            if ($evolution && $latest === null) {
                throw new InvalidArgumentException('Signal event type does not exist; use register() for the first definition version.');
            }

            $existingOwner = $latest === null ? null : (string) $latest->owner_service_id;
            $effectiveOwner = $ownerServiceId;
            if ($effectiveOwner === null || trim($effectiveOwner) === '') {
                $effectiveOwner = ($existingOwner !== null && ! str_starts_with($existingOwner, 'legacy:') && ! str_starts_with($existingOwner, 'package:'))
                    ? $existingOwner
                    : $registrar->serviceId;
            }

            $this->ownership->assertEventRegistration(
                $registrar,
                $definition->eventType,
                $definition->ownerSource,
                $existingOwner,
            );

            if (! $registrar->hasPermission('signal.registry.override') && $effectiveOwner !== $registrar->serviceId) {
                throw new InvalidArgumentException('Registry actor cannot assign event ownership to another service.');
            }

            if ($latest !== null) {
                $this->assertCompatibleEvolution($latest, $definition);
            }

            $version = $latest === null ? 1 : ((int) $latest->definition_version + 1);
            $registeredAt = now();
            $payload = $definition->toArray();
            unset($payload['definition_version'], $payload['owner_service_id'], $payload['registrar_service_id'], $payload['registered_at']);

            SignalTypeVersion::query()->create([
                ...$payload,
                'definition_version' => $version,
                'owner_service_id' => $effectiveOwner,
                'registrar_service_id' => $registrar->serviceId,
                'registered_at' => $registeredAt,
                'registration_checksum' => self::checksum([
                    ...$payload,
                    'definition_version' => $version,
                    'owner_service_id' => $effectiveOwner,
                    'registrar_service_id' => $registrar->serviceId,
                ]),
            ]);
        }, 3);
    }

    private function assertCompatibleEvolution(SignalTypeVersion $latest, EventTypeDefinition $next): void
    {
        $previousCurrent = (int) $latest->current_schema_version;
        $previousSupported = array_map('intval', (array) ($latest->supported_schema_versions ?? []));
        if ($next->currentSchemaVersion < $previousCurrent) {
            throw new InvalidArgumentException('Event schema current version cannot move backwards.');
        }
        if (array_diff($previousSupported, $next->supportedSchemaVersions) !== []) {
            throw new InvalidArgumentException('Event schema evolution cannot silently remove previously supported schema versions.');
        }
        $previousOwnerSource = $latest->owner_source === null ? null : (string) $latest->owner_source;
        if ($previousOwnerSource !== null && $next->ownerSource !== $previousOwnerSource) {
            throw new InvalidArgumentException('Event owner_source is immutable across definition versions.');
        }
    }

    private function definitionFromVersion(SignalTypeVersion $row): EventTypeDefinition
    {
        return EventTypeDefinition::fromArray([
            ...$row->getAttributes(),
            'supported_schema_versions' => $row->supported_schema_versions ?? [],
            'allowed_scopes' => $row->allowed_scopes ?? [],
            'required_payload_fields' => $row->required_payload_fields ?? [],
            'optional_payload_fields' => $row->optional_payload_fields ?? [],
            'allowed_severities' => $row->allowed_severities ?? [],
            'registered_at' => $row->registered_at?->format(DATE_ATOM),
        ]);
    }

    private function definitionFromLegacy(SignalType $row): EventTypeDefinition
    {
        return EventTypeDefinition::fromArray([
            ...$row->getAttributes(),
            'supported_schema_versions' => $row->supported_schema_versions ?? [],
            'allowed_scopes' => $row->allowed_scopes ?? [],
            'required_payload_fields' => $row->required_payload_fields ?? [],
            'optional_payload_fields' => $row->optional_payload_fields ?? [],
            'allowed_severities' => $row->allowed_severities ?? [],
            'definition_version' => 1,
            'owner_service_id' => 'legacy:' . ($row->owner_source ?: 'unowned'),
            'registrar_service_id' => 'migration:legacy',
        ]);
    }

    private function configuredDefinition(string $eventType): ?EventTypeDefinition
    {
        $definitions = function_exists('config') ? (array) config('titan-signal-engine.event_types', []) : [];
        if (! isset($definitions[$eventType]) || ! is_array($definitions[$eventType])) return null;
        return EventTypeDefinition::fromArray([
            'event_type' => $eventType,
            ...$definitions[$eventType],
            'definition_version' => 1,
            'owner_service_id' => 'package:titan-signal-engine',
            'registrar_service_id' => 'package:titan-signal-engine',
        ]);
    }

    /** @param array<string,mixed> $payload */
    private static function checksum(array $payload): string
    {
        ksort($payload);
        return hash('sha256', json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }
}
