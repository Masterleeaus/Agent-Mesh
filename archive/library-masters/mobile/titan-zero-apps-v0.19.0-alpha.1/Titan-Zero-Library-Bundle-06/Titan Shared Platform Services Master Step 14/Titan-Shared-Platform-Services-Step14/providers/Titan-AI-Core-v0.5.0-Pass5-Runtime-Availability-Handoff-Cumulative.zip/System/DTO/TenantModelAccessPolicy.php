<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\DTO;

final readonly class TenantModelAccessPolicy
{
    /**
     * @param array<int,string> $allowedProviders
     * @param array<int,string> $blockedProviders
     * @param array<int,string> $allowedModels
     * @param array<int,string> $blockedModels
     */
    public function __construct(
        public string $tenantCompanyId,
        public array $allowedProviders = [],
        public array $blockedProviders = [],
        public array $allowedModels = [],
        public array $blockedModels = [],
        public bool $allowGlobalFallback = false,
    ) {}
}
