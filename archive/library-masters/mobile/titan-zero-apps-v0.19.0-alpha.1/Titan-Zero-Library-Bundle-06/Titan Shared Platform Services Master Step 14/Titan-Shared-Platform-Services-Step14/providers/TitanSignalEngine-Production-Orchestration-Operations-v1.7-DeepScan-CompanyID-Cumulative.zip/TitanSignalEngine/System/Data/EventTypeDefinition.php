<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class EventTypeDefinition
{
    /**
     * @param list<int> $supportedSchemaVersions
     * @param list<string> $allowedScopes
     * @param list<string> $requiredPayloadFields
     * @param list<string> $optionalPayloadFields
     * @param list<string> $allowedSeverities
     */
    public function __construct(
        public string $eventType,
        public int $currentSchemaVersion,
        public array $supportedSchemaVersions,
        public ?string $category,
        public array $allowedScopes,
        public array $requiredPayloadFields,
        public array $optionalPayloadFields,
        public bool $allowAdditionalPayloadFields,
        public ?string $ownerSource,
        public array $allowedSeverities,
        public string $status = 'active',
        public ?string $replacementEventType = null,
        public int $definitionVersion = 1,
        public ?string $ownerServiceId = null,
        public ?string $registrarServiceId = null,
        public ?string $registeredAt = null,
    ) {
        if ($this->eventType === '' || $this->currentSchemaVersion < 1) {
            throw new InvalidArgumentException('Invalid event type definition.');
        }
        if ($this->allowedScopes === [] || array_diff($this->allowedScopes, [SignalEnvelope::SCOPE_TENANT, SignalEnvelope::SCOPE_SYSTEM]) !== []) {
            throw new InvalidArgumentException('Event type allowed scopes must contain only tenant/system.');
        }
        if (! in_array($this->currentSchemaVersion, $this->supportedSchemaVersions, true)) {
            throw new InvalidArgumentException('Current event schema version must be included in supported_schema_versions.');
        }
        foreach ($this->allowedSeverities as $severity) {
            SignalSeverity::fromName($severity);
        }
        if (! in_array($this->status, ['active', 'deprecated', 'disabled'], true)) {
            throw new InvalidArgumentException('Event type status must be active, deprecated or disabled.');
        }
        if ($this->definitionVersion < 1) {
            throw new InvalidArgumentException('Event type definition_version must be positive.');
        }
    }

    /** @param array<string,mixed> $data */
    public static function fromArray(array $data): self
    {
        $current = (int) ($data['current_schema_version'] ?? 1);
        $supported = array_values(array_unique(array_map('intval', $data['supported_schema_versions'] ?? [$current])));
        sort($supported);

        return new self(
            trim((string) ($data['event_type'] ?? '')),
            $current,
            $supported,
            self::nullableString($data['category'] ?? null),
            array_map('strtolower', self::stringList($data['allowed_scopes'] ?? [SignalEnvelope::SCOPE_TENANT])),
            self::stringList($data['required_payload_fields'] ?? []),
            self::stringList($data['optional_payload_fields'] ?? []),
            (bool) ($data['allow_additional_payload_fields'] ?? true),
            self::nullableString($data['owner_source'] ?? null),
            array_map('strtolower', self::stringList($data['allowed_severities'] ?? [])),
            strtolower((string) ($data['status'] ?? 'active')),
            self::nullableString($data['replacement_event_type'] ?? null),
            max(1, (int) ($data['definition_version'] ?? 1)),
            self::nullableString($data['owner_service_id'] ?? null),
            self::nullableString($data['registrar_service_id'] ?? null),
            self::nullableString($data['registered_at'] ?? null),
        );
    }

    public function validate(SignalEnvelope $signal): void
    {
        if ($signal->eventType !== $this->eventType) {
            throw new InvalidArgumentException('Signal event type does not match registry definition.');
        }
        if ($this->status !== 'active') {
            $suffix = $this->replacementEventType === null ? '' : " Use {$this->replacementEventType} instead.";
            throw new InvalidArgumentException("Signal event type {$this->eventType} is {$this->status}.{$suffix}");
        }
        if (! in_array($signal->schemaVersion, $this->supportedSchemaVersions, true)) {
            throw new InvalidArgumentException("Schema version {$signal->schemaVersion} is not registered for {$this->eventType}.");
        }
        if (! in_array($signal->scope, $this->allowedScopes, true)) {
            throw new InvalidArgumentException("Signal scope {$signal->scope} is not allowed for {$this->eventType}.");
        }
        if ($this->ownerSource !== null && $signal->source !== $this->ownerSource) {
            throw new InvalidArgumentException("Signal source {$signal->source} does not own {$this->eventType}.");
        }
        if ($signal->category !== null && $this->category !== null && $signal->category !== $this->category) {
            throw new InvalidArgumentException("Signal category {$signal->category} does not match registry category {$this->category}.");
        }
        if ($this->allowedSeverities !== [] && ! in_array($signal->severity, $this->allowedSeverities, true)) {
            throw new InvalidArgumentException("Signal severity {$signal->severity} is not allowed for {$this->eventType}.");
        }
        foreach ($this->requiredPayloadFields as $field) {
            if (! array_key_exists($field, $signal->payload)) {
                throw new InvalidArgumentException("Signal payload is missing required field {$field}.");
            }
        }
        if (! $this->allowAdditionalPayloadFields) {
            $allowed = array_flip(array_merge($this->requiredPayloadFields, $this->optionalPayloadFields));
            foreach (array_keys($signal->payload) as $field) {
                if (! isset($allowed[$field])) {
                    throw new InvalidArgumentException("Signal payload field {$field} is not registered for {$this->eventType}.");
                }
            }
        }
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'event_type' => $this->eventType,
            'current_schema_version' => $this->currentSchemaVersion,
            'supported_schema_versions' => $this->supportedSchemaVersions,
            'category' => $this->category,
            'allowed_scopes' => $this->allowedScopes,
            'required_payload_fields' => $this->requiredPayloadFields,
            'optional_payload_fields' => $this->optionalPayloadFields,
            'allow_additional_payload_fields' => $this->allowAdditionalPayloadFields,
            'owner_source' => $this->ownerSource,
            'allowed_severities' => $this->allowedSeverities,
            'status' => $this->status,
            'replacement_event_type' => $this->replacementEventType,
            'definition_version' => $this->definitionVersion,
            'owner_service_id' => $this->ownerServiceId,
            'registrar_service_id' => $this->registrarServiceId,
            'registered_at' => $this->registeredAt,
        ];
    }

    /** @return list<string> */
    private static function stringList(mixed $value): array
    {
        if (! is_array($value)) {
            throw new InvalidArgumentException('Event type definition list must be an array.');
        }

        return array_values(array_map(static fn (mixed $item): string => trim((string) $item), $value));
    }

    private static function nullableString(mixed $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        return trim((string) $value);
    }
}
