# Integration contracts

Cross-extension access is typed and authority-safe. Peer extensions do not receive permission to query People tables directly, and Titan People does not query or mutate peer private tables.

- `TimeAttendancePeoplePort` — active/eligible worker status and minimal People identity facts only; Time Attendance remains attendance writer.
- `PayrollPeoplePort` — employment/profile/pay-policy references only; Payroll remains pay-run, disbursement and bank authority.
- `CredentialsPeoplePort` — stable People worker identity only; Credentials owns credential evidence/eligibility.
- `RecruitPeopleIngressPort` — hired candidate reference/facts enter through a governed `people.worker.create.from-hire` Command Bus request.
- `PerformancePeoplePort` — stable worker/organisation references only.
- `OnboardingPeoplePort` — submits governed acknowledgement/People facts; onboarding workflow ownership remains external.
- `CommunicationsPort` — notification request only. Titan People owns no provider transport and the default adapter fails closed.

All cross-domain mutations require authenticated tenant context plus the governed Command Bus boundary. No adapter may read or write attendance, shift, payroll, credentials, recruiting, performance, onboarding or communications private tables.
