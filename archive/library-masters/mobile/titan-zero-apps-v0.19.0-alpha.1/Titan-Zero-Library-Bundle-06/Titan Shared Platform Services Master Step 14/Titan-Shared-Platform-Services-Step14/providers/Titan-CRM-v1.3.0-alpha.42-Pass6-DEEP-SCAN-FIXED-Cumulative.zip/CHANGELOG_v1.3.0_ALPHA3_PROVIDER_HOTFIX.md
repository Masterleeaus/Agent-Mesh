# CRM 1.3.0-alpha.3 — Titan Installer Provider Hotfix

## Fixed

- Fixed Titan Extension Manager provider-stage failure when CRM is registered into an already-booted Laravel application.
- Root CRM repository contracts are now bound before focused subproviders are registered.
- `CrmFinanceLockerServiceProvider` no longer eagerly constructs Pay/Locker/Bookkeeping domain services during `boot()`. Capability handlers resolve their domain services lazily when invoked.
- Added `bin/verify-provider-install-safety.php` to prevent regression of provider registration order or eager `JobBillingService` resolution.

## Root cause

Titan Extension Manager loads the extension provider before running migrations. In an already-booted Laravel application, `Application::register()` can immediately boot a newly registered provider. CRM alpha.2 registered `CrmFinanceLockerServiceProvider` before binding `SalesDocumentRepositoryContract`; the subprovider booted immediately and attempted to construct `JobBillingService`, producing a `BindingResolutionException`.

## Database impact

None. The reported alpha.2 failure occurred at the provider stage before migration execution. This hotfix adds no migration and changes no data schema.
