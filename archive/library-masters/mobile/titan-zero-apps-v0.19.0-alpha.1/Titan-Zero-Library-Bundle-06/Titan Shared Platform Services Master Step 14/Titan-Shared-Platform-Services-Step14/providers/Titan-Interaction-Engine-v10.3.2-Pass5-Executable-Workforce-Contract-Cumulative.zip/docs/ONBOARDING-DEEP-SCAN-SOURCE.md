# Titan Zero / WorkCore Onboarding Wizard — Deep Scan

## Scope

Scanned:

- `MagicAI-v10.91-WorkCore-CLEANING-ONBOARDING-INTEGRATED(1).zip`
- both WorkCore Onboarding Wizard Question Scan Packs
- CSV and JSON question catalogues
- ManagementSettings deep-scan report
- supplied SHA-256 file

The integrated archive contains 6,921 files. The focused wizard/vertical scan linted 175 PHP files with zero syntax errors. The supplied SHA-256 exactly matches the uploaded integrated ZIP:

`19f467c118870f9a436ed087da79e34d06e959e23ecc62a0c340025fe992cb4c`

## Executive verdict

Keep the canonical WorkCore Wizards module. Do not install another universal wizard runtime.

The existing module is a sound foundation for Titan Zero because it already provides:

- tenant-scoped persisted definitions, runs, answers, approvals and events;
- pause/resume;
- conditional branching;
- answer provenance and confidence;
- risk-based approval;
- action/read-model registration;
- API and web routes;
- AI tool registration;
- owner and staff audiences;
- vertical-filter metadata.

However, it is not yet a complete onboarding engine. Its completion path records a completed status and produces a draft action plan, but it does not execute canonical WorkCore actions. The runtime itself labels every plan item `canonical_workcore_action_adapter_required`.

## What is present

### Canonical module

`app/Domains/WorkCore/System/Modules/Wizards`

Core services:

- `WizardRuntime`
- `WizardDefinitionRegistry`
- `WizardBranchEvaluator`
- `WizardAnswerValidator`
- `WizardRiskPolicy`
- `EloquentWizardRepository`

Runtime actions:

- start
- save answer
- approve section
- pause
- resume
- complete
- create definition
- publish definition

Persistence tables:

- `tz_wizard_definitions`
- `tz_wizard_runs`
- `tz_wizard_answers`
- `tz_wizard_section_approvals`
- `tz_wizard_events`
- `tz_wizard_action_results`

### Definitions

19 definitions are present, including:

- company launch
- cleaning owner onboarding
- cleaning staff onboarding
- business profile
- availability and booking
- territories
- service catalogue
- payments
- workforce
- customer experience
- portal/security
- communications
- AI manager
- integrations
- brand/public presence
- compliance
- activation readiness
- specialist AI agent
- voice agent

The cleaning owner wizard has 23 questions. The cleaning worker wizard has 16 questions.

### Catalogue coverage

The supplied full catalogue contains 121 entries.

- 116 catalogue keys occur in the runtime definitions.
- The five absent keys are deliberately excluded platform/admin controls:
  - `admin.cron`
  - `admin.database_backup`
  - `admin.maintenance`
  - `platform.app_versions`
  - `platform.commission`
- Runtime definitions contain another 52 keys, mainly cleaning staff, AI-agent and voice-agent questions.

This means question coverage is strong. Execution coverage is not.

## Strong architectural decisions

1. The standalone donor interaction engine was not copied into WorkCore.
2. Tenant ownership uses `company_id` on runs, answers, approvals, events and action results.
3. API access uses authentication plus WorkCore API and tenant middleware.
4. BusinessActionDispatcher controls mutations and supplies permission and confirmation boundaries.
5. High-risk and medium-risk sections require approval.
6. Critical settings are blocked from wizard writes.
7. AI-derived answers carry provenance, confidence and confirmation state.
8. Secure tasks are identified separately from ordinary answers.
9. Owner and staff onboarding are separated, preventing staff exposure to owner finance and platform settings.
10. Australian cleaning defaults are declared rather than hard-coded into the core runtime.

## Critical gaps

### 1. Completion does not apply configuration

`WizardRuntime::complete()`:

- verifies all applicable questions are answered;
- verifies required section approvals;
- changes the run status to completed;
- returns an action plan grouped by target owner.

It does not dispatch company, catalogue, territory, scheduling, workforce, finance, notification, compliance or lifecycle actions.

Required fix: add a `WizardPlanCompiler` and `WizardActionExecutor` that translate approved answers into canonical `ActionRequest` objects, execute idempotently, and persist each result in `tz_wizard_action_results`.

### 2. No transaction/saga for activation

A launch wizard can create records across many domains. There is no orchestration for partial failure, retries, compensation or resumable activation.

Required fix: use a staged activation saga:

1. compile;
2. validate;
3. preview;
4. approve;
5. execute per domain;
6. record results;
7. retry failed steps;
8. activate company only after required steps pass.

### 3. `tz_wizard_action_results` is unused

The migration creates the correct table, but no scanned service writes execution outcomes to it.

### 4. Company launch sequence is declarative only

`company-launch-onboarding` declares a `wizard_sequence`, but the runtime does not orchestrate child wizards, pass shared answers, skip irrelevant child wizards, or calculate overall launch readiness.

### 5. UI does not implement most catalogue response types

The UI properly supports:

- boolean
- select
- multi-select
- text
- email
- phone
- slug
- money/duration as plain text
- integer/number

Most advanced types fall back to one textarea, including:

- weekly schedule
- address lookup
- map radius/polygon
- repeatable collections
- skill matrices
- credential collections
- role/channel matrices
- file collections
- checklist builders
- rule builders
- secure connection tasks

This loses structured validation and creates avoidable AI parsing ambiguity.

### 6. “Conversation mode” is not actually conversational

The current screen repeats the question in a Titan-styled box. There is no natural-language extraction service in this UI. The browser submits the field value and labels it `ai_extracted` with a hard-coded confidence of `0.8`.

That provenance is inaccurate unless an AI extractor actually produced the value.

### 7. Approval can become stale

After a section is approved, an answer in that section can be edited without visibly invalidating the approval in the scanned repository code.

Required fix: changing an answer must revoke or version the relevant section approval.

### 8. Validation is too shallow

The validator handles only a small subset of types. It does not enforce:

- min/max values;
- phone formats;
- currency precision;
- date/time and timezone validity;
- schedule overlap;
- postcode/suburb/radius/polygon schemas;
- files and MIME constraints;
- cross-field rules;
- secure-task state;
- question-specific Laravel validation rules.

### 9. Definition version immutability needs stronger enforcement

Runs store a definition version, but runtime lookup is primarily by definition key. A run must always resolve the exact immutable definition snapshot/version with which it started.

### 10. No feature tests were included

No wizard/onboarding tests were found under `tests/`. The audit document itself says Laravel boot, migrations and feature tests still need to be run in a deployment environment.

### 11. Routes are disabled by default

`WORKCORE_WIZARDS_ROUTES_ENABLED` defaults to false. This is safe for packaging, but installation/activation must explicitly enable and verify the module.

### 12. Secrets boundary is described, not fully implemented

Definitions mark secure tasks, and the UI displays a warning, but a complete secure credential component and callback state machine were not found in the scanned wizard UI.

## Security and tenancy assessment

### Good

- All run lookup paths constrain by active `company_id`.
- Mutating API actions pass through `BusinessActionDispatcher`.
- Permissions are declared for view, design, publish, use and approve.
- Critical settings are blocked.
- Idempotency and confirmation identifiers are accepted.
- AI cannot directly approve sections through the intended policy.

### Needs correction

- Verify web-page controllers enforce the declared read permission, not only authentication and tenant middleware.
- Never trust client-supplied provenance or confidence. The server should derive actor/source from authenticated execution context.
- Do not let the browser claim `ai_extracted` or assign confidence.
- Revoke approvals after answer changes.
- Encrypt or tokenise sensitive answers that are legitimately persisted.
- Store only connection references/status for secrets.
- Add rate limits and run ownership/participant rules for staff onboarding.
- Add audit events for failed validation, revoked approvals, execution attempts and compensation.

## Best integration with Titan Vertical Engine

The onboarding engine should be the configuration intake and activation layer for the Vertical Engine.

### Recommended flow

1. User chooses primary vertical and business subtype.
2. Vertical Engine loads terminology, theme, navigation, roles, capabilities and question overlays.
3. Wizard Registry composes:
   - universal P0 launch questions;
   - vertical-family questions;
   - subtype questions;
   - country/regulatory questions;
   - selected-capability questions;
   - role-specific onboarding.
4. Titan imports or infers safe answers and records evidence/provenance.
5. User reviews grouped assumptions and policies.
6. Plan compiler generates canonical WorkCore actions.
7. Preview shows exactly what will be created or changed.
8. Approved actions execute idempotently.
9. Vertical profile, terminology, theme and navigation activate only after required domain setup succeeds.
10. Optional follow-up wizards remain available from a setup checklist.

### Do not create separate hard-coded owner wizards for every business

Use layered definition composition:

`base company launch → country overlay → vertical family overlay → subtype overlay → capability overlay → tenant custom questions`

Example:

`company-launch + AU + field-services + cleaning + recurring-services + photo-evidence`

This avoids maintaining hundreds of copied JSON definitions.

## Recommended product structure

### Titan Launch

The first-run company and vertical configuration engine.

### Titan Onboarding

Reusable onboarding for:

- business owners/admins;
- new staff;
- contractors/providers;
- customers/clients/guests/members;
- new properties/locations/assets;
- newly enabled capabilities.

### Titan Learn

The small LMS/induction layer that attaches training and competency requirements to onboarding plans.

The wizard should create an onboarding plan; the LMS should complete required learning, acknowledgements, quizzes, evidence and competency sign-off before role activation where required.

## Required implementation order

### Phase 1 — make completion real

- plan compiler;
- canonical action mappings;
- preview endpoint;
- action executor;
- action-result persistence;
- retries and idempotency;
- activation saga.

### Phase 2 — make questions truly structured

Build components and validators for schedules, territories/maps, services, repeaters, files, skills, credentials, role/channel matrices, checklists, rules and secure connections.

### Phase 3 — compose vertical onboarding

- question-overlay schema;
- family and subtype packs;
- terminology-aware question text;
- country/regulatory overlays;
- capability-driven branching;
- child-wizard orchestration.

### Phase 4 — staff induction and LMS

- onboarding plans/tasks;
- training modules;
- acknowledgements;
- quizzes;
- evidence upload;
- expiry/renewal;
- supervisor sign-off;
- role activation gate.

### Phase 5 — tests and release validation

Minimum tests:

- tenant isolation;
- exact definition-version resolution;
- branch evaluation;
- advanced response validation;
- approval invalidation;
- AI provenance enforcement;
- secrets exclusion;
- action preview;
- idempotent execution;
- partial failure/retry;
- activation gating;
- owner/staff permission separation;
- vertical overlay composition;
- accessibility and mobile/offline behaviour.

## Final decision

Retain and upgrade the integrated WorkCore Wizards module. It is substantially better than installing a second donor wizard engine and has the right persistence, tenancy, approval and action-boundary concepts.

Do not call it complete yet. At present it is a governed, resumable questionnaire and review system. It becomes Titan Zero's true onboarding and vertical setup engine only after approved answers can be compiled, previewed and executed through canonical WorkCore actions.
