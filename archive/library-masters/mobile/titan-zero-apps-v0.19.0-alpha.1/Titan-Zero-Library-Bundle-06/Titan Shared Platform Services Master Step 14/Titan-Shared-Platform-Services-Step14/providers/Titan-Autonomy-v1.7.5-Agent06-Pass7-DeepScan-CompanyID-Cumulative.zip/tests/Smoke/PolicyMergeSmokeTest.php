<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\Services\PolicyMergeService;

function ok(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}

$merged = (new PolicyMergeService())->merge(
    platform: [
        'gate_minimums' => ['low' => 1, 'medium' => 2, 'high' => 3, 'critical' => 3],
        'maximum_level_by_risk' => ['low' => 'trusted_auto', 'medium' => 'trusted_auto', 'high' => 'auto', 'critical' => 'semi_auto'],
        'system_wide_learning_permitted' => false,
    ],
    tenant: [
        'gate_minimums' => ['low' => 0, 'medium' => 1, 'high' => 2, 'critical' => 1],
        'maximum_level_by_risk' => ['high' => 'trusted_auto', 'critical' => 'trusted_auto'],
        'system_wide_learning' => true,
    ],
);
ok($merged['gate_minimums']['medium'] === 2, 'tenant must not lower platform evidence minimum');
ok($merged['maximum_level_by_risk']['high'] === 'auto', 'tenant must not raise platform risk ceiling');
ok($merged['maximum_level_by_risk']['critical'] === 'semi_auto', 'critical ceiling must remain platform bounded');
ok($merged['system_wide_learning'] === false, 'tenant cannot enable system learning when platform disallows it');

$stricter = (new PolicyMergeService())->merge(
    platform: [
        'gate_minimums' => ['low' => 1, 'medium' => 2, 'high' => 3, 'critical' => 3],
        'maximum_level_by_risk' => ['low' => 'trusted_auto', 'medium' => 'trusted_auto', 'high' => 'auto', 'critical' => 'semi_auto'],
        'system_wide_learning_permitted' => true,
    ],
    tenant: [
        'gate_minimums' => ['medium' => 5],
        'maximum_level_by_risk' => ['medium' => 'semi_auto'],
        'system_wide_learning' => true,
    ],
);
ok($stricter['gate_minimums']['medium'] === 5, 'tenant may choose stricter evidence requirements');
ok($stricter['maximum_level_by_risk']['medium'] === 'semi_auto', 'tenant may lower its autonomy ceiling');
ok($stricter['system_wide_learning'] === true, 'system learning requires both platform permission and tenant opt-in');

echo "OK: PolicyMergeSmokeTest\n";
