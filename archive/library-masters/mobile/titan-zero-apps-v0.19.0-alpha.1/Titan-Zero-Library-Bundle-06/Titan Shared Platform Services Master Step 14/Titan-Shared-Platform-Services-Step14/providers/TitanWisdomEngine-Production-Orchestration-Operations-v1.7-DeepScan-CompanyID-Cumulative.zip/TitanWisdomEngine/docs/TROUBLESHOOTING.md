# Troubleshooting

Run `php artisan titan:titan-wisdom:certify --json`. Verify Installer 1.7.8 recognizes the flat-root package, the provider key is `titan-wisdom`, the database is MySQL, migrations are present, and the named user/admin routes exist.
