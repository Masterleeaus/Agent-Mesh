<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    private const TABLES = [
        'titan_command_receipts',
        'titan_command_idempotency',
        'titan_commands',
        'titan_command_attempts',
    ];

    public function up(): void
    {
        foreach (self::TABLES as $tableName) {
            if (! Schema::hasTable($tableName)) {
                continue;
            }
            if (! Schema::hasColumn($tableName, 'company_id')) {
                Schema::table($tableName, function (Blueprint $table): void {
                    $table->unsignedBigInteger('company_id')->nullable()->index();
                });
            }
            if (Schema::hasColumn($tableName, 'tenant_company_id')) {
                DB::table($tableName)
                    ->whereNull('company_id')
                    ->whereNotNull('tenant_company_id')
                    ->update(['company_id' => DB::raw('tenant_company_id')]);
            }
        }

        $this->addCanonicalUnique('titan_command_idempotency', ['company_id', 'idempotency_key'], 'tcb_company_idem_uq');
        $this->addCanonicalUnique('titan_commands', ['company_id', 'command_id'], 'tcb_commands_company_command_uq');
        $this->addCanonicalUnique('titan_command_attempts', ['company_id', 'command_id', 'sequence'], 'tcb_attempts_company_command_sequence_uq');
    }

    public function down(): void
    {
        // Non-destructive by design: company_id and audit evidence are retained.
    }

    private function addCanonicalUnique(string $tableName, array $columns, string $indexName): void
    {
        if (! Schema::hasTable($tableName) || ! Schema::hasColumn($tableName, 'company_id')) {
            return;
        }
        try {
            Schema::table($tableName, function (Blueprint $table) use ($columns, $indexName): void {
                $table->unique($columns, $indexName);
            });
        } catch (\Throwable) {
            // Existing upgraded hosts may already carry the canonical index.
        }
    }
};
