<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\CanonicalJson;
use DateTimeZone;
use InvalidArgumentException;

final class BusinessProfile
{
    /**
     * @param array<string, mixed> $jurisdiction
     * @param array<string, mixed> $sections
     */
    public function __construct(
        private readonly int $tenantCompanyId,
        private readonly string $profileVersion,
        private readonly string $verticalId,
        private readonly string $verticalVersion,
        private readonly array $jurisdiction,
        private readonly string $timezone,
        private readonly array $sections = [],
    ) {
        if ($this->tenantCompanyId <= 0) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }

        self::assertToken($this->profileVersion, 'profile_version', 80);
        self::assertToken($this->verticalId, 'vertical_id', 120);
        self::assertToken($this->verticalVersion, 'vertical_version', 80);

        $countryCode = $this->jurisdiction['country_code'] ?? null;
        if (!is_string($countryCode) || preg_match('/^[A-Z]{2}$/', $countryCode) !== 1) {
            throw new InvalidArgumentException('jurisdiction.country_code must be a two-letter uppercase country code.');
        }

        try {
            new DateTimeZone($this->timezone);
        } catch (\Throwable) {
            throw new InvalidArgumentException('timezone must be a valid IANA timezone.');
        }
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $jurisdiction = $data['jurisdiction'] ?? null;
        $sections = $data['sections'] ?? [];

        if (!is_array($jurisdiction)) {
            throw new InvalidArgumentException('jurisdiction must be an object-like array.');
        }

        if (!is_array($sections)) {
            throw new InvalidArgumentException('sections must be an object-like array.');
        }

        return new self(
            self::positiveInt($data['tenant_company_id'] ?? null, 'tenant_company_id'),
            self::requiredString($data['profile_version'] ?? null, 'profile_version'),
            self::requiredString($data['vertical_id'] ?? null, 'vertical_id'),
            self::requiredString($data['vertical_version'] ?? null, 'vertical_version'),
            $jurisdiction,
            self::requiredString($data['timezone'] ?? null, 'timezone'),
            $sections,
        );
    }

    public function tenantCompanyId(): int
    {
        return $this->tenantCompanyId;
    }

    public function profileVersion(): string
    {
        return $this->profileVersion;
    }

    public function verticalId(): string
    {
        return $this->verticalId;
    }

    public function verticalVersion(): string
    {
        return $this->verticalVersion;
    }

    /** @return array<string, mixed> */
    public function jurisdiction(): array
    {
        return $this->jurisdiction;
    }

    public function timezone(): string
    {
        return $this->timezone;
    }

    /** @return array<string, mixed> */
    public function sections(): array
    {
        return $this->sections;
    }

    public function fingerprint(): string
    {
        return hash('sha256', CanonicalJson::encode($this->toArray()));
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'tenant_company_id' => $this->tenantCompanyId,
            'profile_version' => $this->profileVersion,
            'vertical_id' => $this->verticalId,
            'vertical_version' => $this->verticalVersion,
            'jurisdiction' => $this->jurisdiction,
            'timezone' => $this->timezone,
            'sections' => $this->sections,
        ];
    }

    private static function assertToken(string $value, string $field, int $maxLength): void
    {
        if ($value === '' || strlen($value) > $maxLength) {
            throw new InvalidArgumentException("{$field} must be between 1 and {$maxLength} characters.");
        }
    }

    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') {
            throw new InvalidArgumentException("{$field} is required.");
        }

        return trim($value);
    }

    private static function positiveInt(mixed $value, string $field): int
    {
        if (is_int($value)) {
            $resolved = $value;
        } elseif (is_string($value) && ctype_digit($value)) {
            $resolved = (int) $value;
        } else {
            throw new InvalidArgumentException("{$field} must be a positive integer.");
        }

        if ($resolved <= 0) {
            throw new InvalidArgumentException("{$field} must be a positive integer.");
        }

        return $resolved;
    }
}
