# Governance

Every native state-changing dispatch requires fresh Titan Risk evidence before a fresh Governance decision. Risk, Assurance, Autonomy and Governance constrain authority; Command Bus does not calculate or elevate authority.

## Pass 9 risk boundary
- `CommandRiskGateContract` owns only the integration port, not risk logic.
- Default `FailClosedRiskGate` reports unavailable.
- Required Risk unavailable -> `RISK_UNAVAILABLE`.
- Explicit Risk denial -> the Risk reason code is preserved and execution stops before Governance.
- An allowed Risk decision lacking a durable reference or risk class -> `RISK_DECISION_INVALID`.
- Governance receives the accepted `RiskDecision` so downstream approval cannot ignore the current risk context.
- Risk evidence is persisted separately from `governance_reference`.

Autonomy remains a subsequent pass. Assurance/Shield is implemented as an external fail-closed integration boundary in Pass 10; no local assurance engine is simulated.


## Pass 10 — Assurance / Shield boundary
Mutation dispatch now requires an authoritative Assurance/Shield decision after Titan Risk and before Governance. The default bridge is fail-closed; no local assurance or Shield policy is inferred. Accepted evidence is durable and is passed into Governance, receipts, and outcome Signals.


## Pass 11 — Titan Autonomy integration

Command dispatch now resolves earned autonomy after Risk and Assurance and before Governance. Autonomy is capability/workflow-specific evidence, never a caller-selected permission. When `require_autonomy=true`, unavailable, denied, or malformed autonomy evidence fails closed before Governance or domain execution. Successful decisions preserve `autonomy_reference`, `autonomy_level`, `autonomy_workflow`, and evidence references in receipts and Signal telemetry.
