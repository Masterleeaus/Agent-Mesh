<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use DomainException;

final class SalesDocumentLifecycleService
{
    private const TRANSITIONS=[
        'proposals'=>[
            'draft'=>['sent','withdrawn','void'],
            'sent'=>['accepted','rejected','expired','withdrawn','void'],
            'accepted'=>[], 'rejected'=>[], 'expired'=>[], 'withdrawn'=>[], 'superseded'=>[], 'void'=>[],
        ],
        'estimates'=>[
            'draft'=>['sent','withdrawn','void'],
            'sent'=>['accepted','rejected','expired','withdrawn','void'],
            'accepted'=>[], 'rejected'=>[], 'expired'=>[], 'withdrawn'=>[], 'superseded'=>[], 'void'=>[],
        ],
        'invoices'=>[
            'draft'=>['issued','void'],'issued'=>['sent','void'],'sent'=>['viewed','void'],'viewed'=>['void'],'paid'=>[],'void'=>[],
        ],
    ];

    public function allowedTransitions(string $type,string $from): array { return self::TRANSITIONS[$type][$from]??[]; }

    public function assertTransition(string $type,string $from,string $to): void
    {
        $allowed=self::TRANSITIONS[$type][$from]??null;
        if($allowed===null||!in_array($to,$allowed,true))throw new DomainException("Invalid {$type} transition {$from} -> {$to}.");
    }

    public function assertNotExpired(string $type,object|array $row,string $to): void
    {
        if(!in_array($type,['proposals','estimates'],true)||$to!=='accepted')return;
        $expires=is_array($row)?($row['expires_at']??null):($row->expires_at??null);
        if($expires!==null&&strtotime((string)$expires)!==false&&strtotime((string)$expires)<time())throw new DomainException('Expired quotes cannot be accepted.');
    }

    public function timestampColumn(string $to): ?string
    {
        return match($to){'issued','sent'=>'issued_at','accepted'=>'accepted_at','paid','confirmed'=>'paid_at','void'=>'voided_at','withdrawn'=>'withdrawn_at','rejected'=>'rejected_at','superseded'=>'superseded_at',default=>null};
    }
}
