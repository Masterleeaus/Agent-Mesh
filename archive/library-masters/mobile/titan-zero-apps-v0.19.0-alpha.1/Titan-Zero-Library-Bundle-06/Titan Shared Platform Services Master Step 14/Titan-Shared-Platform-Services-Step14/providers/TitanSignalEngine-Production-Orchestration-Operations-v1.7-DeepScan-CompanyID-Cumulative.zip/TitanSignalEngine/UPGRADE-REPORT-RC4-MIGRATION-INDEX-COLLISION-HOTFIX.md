# Titan Signal Engine v0.20.0-rc.4 — Migration Index Collision Hotfix

## Live host evidence

Installer 1.7.8 install `01M0ACNY4SMNR6SXHT8P2F73TD` on PHP 8.3.33 / Laravel 10.50.2 / MySQL passed validation and deployment, then recorded 12 extension migrations before migration 13 failed with `SQLSTATE[42000] / 1061 Duplicate key name tsd_subscriber_status_idx`.

## Root cause

Migration 6 creates `tsd_subscriber_status_idx` on `(subscriber_key, status, available_at)`. Migration 13 attempted to create the same index name on `(subscriber_key, status)`. The second index is redundant because the existing composite index already covers queries constrained by its leftmost `(subscriber_key, status)` prefix.

Migration 13 also attempted to drop `tsd_subscriber_status_idx` in `down()`, which would have removed migration 6's foundational index if left in place after removing the duplicate creation.

## Fix

- Removed the migration-13 duplicate index creation.
- Removed the migration-13 `dropIndex('tsd_subscriber_status_idx')`.
- Preserved migration 6 as the sole owner of the covering index.
- Added `tests/run-migration-index-chain-compatibility.php` to reject duplicate explicit key names and redundant explicit left-prefix indexes in the migration chain.

No runtime capability, event, queue, retention, archive, API, or business-data semantics changed. Production host certification remains pending until the full migration chain and host certification command pass.
