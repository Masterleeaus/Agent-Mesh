<?php
namespace App\Extensions\Crm\System\Contracts;
interface CalendarRepositoryContract { public function search(int $userId,array $filters=[]): array; public function create(int $userId,array $data): array; }
