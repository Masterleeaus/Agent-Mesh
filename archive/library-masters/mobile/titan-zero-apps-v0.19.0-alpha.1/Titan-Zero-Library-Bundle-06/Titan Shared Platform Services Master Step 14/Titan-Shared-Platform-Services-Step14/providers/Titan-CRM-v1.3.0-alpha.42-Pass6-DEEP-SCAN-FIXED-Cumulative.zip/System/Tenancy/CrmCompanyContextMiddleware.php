<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Tenancy;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class CrmCompanyContextMiddleware
{
    public function __construct(
        private readonly CrmCompanyContextResolver $resolver,
        private readonly CrmCompanyContextStore $store,
    ) {}

    public function handle(Request $request, Closure $next): Response
    {
        $context = $this->resolver->resolveAuthenticated($request->user(), 'crm');
        $this->store->push($context);
        $request->attributes->set('crm_company_context', $context);
        $request->attributes->set('company_id', $context->companyId);
        try { return $next($request); }
        finally { $this->store->pop(); }
    }
}
