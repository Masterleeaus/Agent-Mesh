<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Navigation;

final class TitanAICoreNavigation
{
    /** @return array<int,array<string,mixed>> */
    public static function user(): array
    {
        return [
            [
                'key' => 'titan-ai',
                'label' => 'Titan AI',
                'name' => 'Titan AI',
                'route' => 'dashboard.user.titan.ai.core.index',
                'active_condition' => 'dashboard.user.titan.ai.*',
                'extension' => 'titan-ai-core',
                'is_admin' => false,
                'permission' => 'ai.core.read',
                'sort' => 600,
            ],
            [
                'parent_key' => 'titan-ai',
                'key' => 'titan-ai-core',
                'label' => 'AI Core',
                'name' => 'AI Core',
                'route' => 'dashboard.user.titan.ai.core.index',
                'active_condition' => 'dashboard.user.titan.ai.core.*',
                'extension' => 'titan-ai-core',
                'is_admin' => false,
                'permission' => 'ai.core.read',
                'sort' => 10,
            ],
        ];
    }

    /** @return array<int,array<string,mixed>> */
    public static function admin(): array
    {
        return [
            [
                'key' => 'titan-ai-admin',
                'label' => 'Titan AI',
                'name' => 'Titan AI',
                'route' => 'dashboard.admin.titan.ai.core.index',
                'active_condition' => 'dashboard.admin.titan.ai.*',
                'extension' => 'titan-ai-core',
                'is_admin' => true,
                'permission' => 'ai.core.admin',
                'sort' => 600,
            ],
            [
                'parent_key' => 'titan-ai-admin',
                'key' => 'titan-ai-core-admin',
                'label' => 'AI Core',
                'name' => 'AI Core',
                'route' => 'dashboard.admin.titan.ai.core.index',
                'active_condition' => 'dashboard.admin.titan.ai.core.*',
                'extension' => 'titan-ai-core',
                'is_admin' => true,
                'permission' => 'ai.core.admin',
                'sort' => 10,
            ],
        ];
    }
}
