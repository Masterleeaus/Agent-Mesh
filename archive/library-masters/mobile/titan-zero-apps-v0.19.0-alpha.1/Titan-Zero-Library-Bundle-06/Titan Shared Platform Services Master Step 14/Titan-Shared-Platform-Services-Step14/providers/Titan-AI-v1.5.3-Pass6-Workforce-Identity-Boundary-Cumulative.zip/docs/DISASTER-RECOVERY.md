# Disaster recovery

Restore extension-owned durable state from host backups, verify tenant isolation and receipt/idempotency integrity, then reconcile provider-independent runtime state before enabling mutations.
