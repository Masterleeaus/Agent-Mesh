<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Host;

final class GovernanceMenuRegistrar
{
    public function __construct(private readonly TitanMenuCompatibilityAdapter $adapter) {}

    public function registerNavigation(): void
    {
        $this->adapter->registerAll(self::definitions());
    }

    /** @return list<array<string,mixed>> */
    public static function definitions(): array
    {
        $parentKey = 'titan-governance';
        $definitions = [
            self::definition(
                $parentKey,
                'Titan Governance',
                'dashboard.user.titan.governance.index',
                '/dashboard/user/titan-governance',
                null,
                780,
                'tabler-shield-check',
                'titan-governance.view'
            ),
        ];

        $children = [
            ['overview', 'Overview', 'dashboard.user.titan.governance.overview', '/dashboard/user/titan-governance/overview', 'tabler-layout-dashboard'],
            ['control-centre', 'Control Centre', 'dashboard.user.titan.governance.control-centre', '/dashboard/user/titan-governance/control-centre', 'tabler-dashboard'],
            ['escalations', 'Escalations', 'dashboard.user.titan.governance.escalations.queue', '/dashboard/user/titan-governance/escalations', 'tabler-alert-triangle'],
            ['signal-heatmap', 'Signal Heatmap', 'dashboard.user.titan.governance.signal-heatmap', '/dashboard/user/titan-governance/signal-heatmap', 'tabler-activity'],
            ['operational-pressure', 'Operational Pressure', 'dashboard.user.titan.governance.operational-pressure', '/dashboard/user/titan-governance/operational-pressure', 'tabler-gauge'],
            ['circuit-breakers', 'Circuit Breakers', 'dashboard.user.titan.governance.circuit-breakers', '/dashboard/user/titan-governance/circuit-breakers', 'tabler-bolt-off'],
            ['workforce-oversight', 'Workforce Oversight', 'dashboard.user.titan.governance.workforce-oversight', '/dashboard/user/titan-governance/workforce-oversight', 'tabler-users'],
        ];

        foreach ($children as $index => [$key, $label, $route, $url, $icon]) {
            $definitions[] = self::definition(
                "titan-governance.{$key}",
                $label,
                $route,
                $url,
                $parentKey,
                781 + $index,
                $icon,
                'titan-governance.view'
            );
        }

        $definitions[] = self::definition(
            'titan-governance.admin',
            'Governance Admin',
            'dashboard.admin.titan.governance.index',
            '/dashboard/admin/titan-governance',
            null,
            790,
            'tabler-shield-lock',
            'titan-governance.admin',
            ['admin'],
            false
        );

        return $definitions;
    }

    /** @param list<string> $surfaces @return array<string,mixed> */
    private static function definition(
        string $key,
        string $label,
        string $route,
        string $url,
        ?string $parentKey,
        int $priority,
        string $icon,
        string $permission,
        array $surfaces = ['command'],
        bool $legacyEnabled = true
    ): array {
        return [
            'registry' => 'navigation',
            'key' => $key,
            'label' => $label,
            'route' => $route,
            'parent_key' => $parentKey,
            'priority' => $priority,
            'icon' => $icon,
            'permission' => $permission,
            'surfaces' => $surfaces,
            'legacy_enabled' => $legacyEnabled,
            'legacy_identity' => ['key' => $key],
            'legacy_fallback_identity' => ['route' => $route],
            'legacy_fields' => [
                'key' => $key,
                'name' => $label,
                'title' => $label,
                'label' => $label,
                'route' => $route,
                'url' => $url,
                'icon' => $icon,
                'permission' => $permission,
            ],
        ];
    }
}
