<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Providers;

use App\Extensions\TitanConnect\System\Contracts\MessagingProvider;
use App\Extensions\TitanConnect\System\Contracts\ProviderHttpClient;
use App\Extensions\TitanConnect\System\DTO\NormalizedDeliveryReceipt;
use App\Extensions\TitanConnect\System\DTO\NormalizedInboundMessage;
use App\Extensions\TitanConnect\System\DTO\ProviderHttpResponse;
use App\Extensions\TitanConnect\System\DTO\ProviderMediaDescriptor;
use Illuminate\Support\Arr;
use RuntimeException;

abstract class AbstractMessagingProvider implements MessagingProvider
{
    public function __construct(protected readonly ProviderHttpClient $http)
    {
    }

    public function supportsInbound(): bool
    {
        return true;
    }

    public function supportsOutbound(): bool
    {
        return true;
    }

    public function capabilities(): array
    {
        return ['messages', 'attachments', 'delivery_receipts'];
    }

    public function verifyWebhookChallenge(array $query, array $credentials): ?string
    {
        return null;
    }

    public function splitWebhookPayload(array $payload): array
    {
        return [$payload];
    }

    public function normalizeInbound(array $payload, array $headers = []): NormalizedInboundMessage
    {
        $eventId = (string) ($payload['event_id'] ?? $payload['update_id'] ?? $payload['id'] ?? Arr::get($payload, 'message.id') ?? '');
        $messageId = $payload['message_id'] ?? Arr::get($payload, 'message.id');
        $sender = $payload['sender'] ?? $payload['from'] ?? Arr::get($payload, 'message.from.id');
        $recipient = $payload['recipient'] ?? $payload['to'] ?? null;
        $thread = $payload['thread_id'] ?? $payload['conversation_id'] ?? $sender ?? $recipient ?? $eventId;
        $body = $payload['text'] ?? $payload['body'] ?? Arr::get($payload, 'message.text');
        $attachments = $payload['attachments'] ?? $payload['media'] ?? [];

        return new NormalizedInboundMessage(
            $this->key(),
            $eventId,
            (string) $thread,
            $messageId === null ? null : (string) $messageId,
            $sender === null ? null : (string) $sender,
            $recipient === null ? null : (string) $recipient,
            $body === null ? null : (string) $body,
            $attachments === [] ? 'text' : 'attachment',
            is_array($attachments) ? $attachments : [$attachments],
            ['raw' => $payload],
        );
    }

    public function normalizeDeliveryReceipt(array $payload): NormalizedDeliveryReceipt
    {
        $id = $payload['provider_message_id'] ?? $payload['message_id'] ?? $payload['id'] ?? null;
        $status = strtolower((string) ($payload['status'] ?? 'unknown'));
        return new NormalizedDeliveryReceipt($this->key(), $id === null ? null : (string) $id, $status, ['raw' => $payload]);
    }

    public function resolveInboundMedia(array $attachment, array $credentials): ?ProviderMediaDescriptor
    {
        $url = data_get($attachment, 'public_url')
            ?? data_get($attachment, 'url')
            ?? data_get($attachment, 'payload.url');
        if (! is_string($url) || trim($url) === '') {
            return null;
        }

        return new ProviderMediaDescriptor(
            trim($url),
            [],
            isset($attachment['name']) ? (string) $attachment['name'] : null,
            isset($attachment['mime_type']) ? (string) $attachment['mime_type'] : null,
            isset($attachment['size_bytes']) ? (int) $attachment['size_bytes'] : null,
            isset($attachment['sha256']) ? (string) $attachment['sha256'] : null,
            ['provider' => $this->key(), 'source' => 'webhook-url'],
        );
    }

    public function health(array $credentials): array
    {
        return ['ok' => false, 'provider' => $this->key(), 'configured' => $credentials !== [], 'reason' => 'provider-health-not-implemented'];
    }

    protected function verifyHmac(array $headers, string $body, string $secret, string $header = 'x-titan-connect-signature', string $prefix = ''): bool
    {
        if ($secret === '') {
            return false;
        }
        $provided = $this->header($headers, $header);
        if ($provided === null) {
            return false;
        }
        $expected = $prefix.hash_hmac('sha256', $body, $secret);
        return hash_equals($expected, trim($provided));
    }

    protected function header(array $headers, string $name): ?string
    {
        foreach ($headers as $key => $value) {
            if (strcasecmp((string) $key, $name) !== 0) {
                continue;
            }
            if (is_array($value)) {
                return isset($value[0]) ? (string) $value[0] : null;
            }
            return (string) $value;
        }
        return null;
    }

    protected function credential(array $credentials, string $key): string
    {
        $value = trim((string) ($credentials[$key] ?? ''));
        if ($value === '') {
            throw new RuntimeException("Missing required {$this->key()} credential [{$key}].");
        }
        return $value;
    }

    protected function accountIdentity(array $credentials, string $key, ?array $message = null): string
    {
        $value = trim((string) ($credentials[$key] ?? ''));
        if ($value === '' && $message !== null) {
            $value = trim((string) ($message['from'] ?? ''));
        }
        if ($value === '') {
            $value = trim((string) ($credentials['_connection_external_account_id'] ?? ''));
        }
        if ($value === '') {
            throw new RuntimeException("Missing required {$this->key()} account identity [{$key}].");
        }
        return $value;
    }

    protected function requireSuccess(ProviderHttpResponse $response, string $operation): ProviderHttpResponse
    {
        if ($response->isSuccessful()) {
            return $response;
        }

        $providerMessage = data_get($response->json, 'error.message')
            ?? data_get($response->json, 'message')
            ?? data_get($response->json, 'description');
        $suffix = is_string($providerMessage) && trim($providerMessage) !== '' ? ': '.trim($providerMessage) : '';
        throw new RuntimeException(sprintf('%s %s failed with HTTP %d%s', ucfirst($this->key()), $operation, $response->status, $suffix));
    }

    protected function firstAttachment(array $message): ?array
    {
        $attachments = data_get($message, 'metadata.attachments', []);
        if (! is_array($attachments) || $attachments === []) {
            return null;
        }
        $attachment = array_values($attachments)[0] ?? null;
        return is_array($attachment) ? $attachment : null;
    }

    protected function graphBase(string $provider, array $credentials): string
    {
        return rtrim((string) ($credentials['graph_base_url'] ?? config("titan-connect.providers.{$provider}.graph_base_url", 'https://graph.facebook.com')), '/');
    }

    protected function graphVersion(string $provider, array $credentials): string
    {
        return trim((string) ($credentials['graph_version'] ?? config("titan-connect.providers.{$provider}.graph_version", 'v25.0')), '/');
    }
}
