# Failure Modes

## Governed actions

| Failure | Result | Retry policy | State mutation |
|---|---|---|---|
| Command Bus gateway unbound | `BLOCKED / COMMAND_BUS_UNAVAILABLE` | same operation may retry | none |
| Dispatch exception | `BLOCKED / COMMAND_BUS_DISPATCH_FAILED` | same operation may retry | none |
| Command Bus timeout/transport failure | `BLOCKED` | same operation may retry | none |
| Operation ID reused with different semantic payload | `IDEMPOTENCY_CONFLICT` | use a new operation only for a genuinely new decision | none |
| Invalid/mismatched APPLIED receipt | `FAILED / COMMAND_RECEIPT_INVALID` | investigate integration; do not assume write | none reported by Governance |
| Stale escalation version | `BLOCKED / ESCALATION_VERSION_CONFLICT` | reload queue and create a new action against current version | none |
| Invalid transition | `BLOCKED / ESCALATION_TRANSITION_NOT_ALLOWED` | terminal unless state changes independently | none |
| Missing/mismatched Governance decision | `BLOCKED / GOVERNANCE_DECISION_MISMATCH` | integration fault | none |

A transient dispatch failure may overwrite the *last command outcome metadata* when successfully retried, but it never overwrites the immutable human decision facts. Command Bus remains responsible for its own execution-attempt and receipt history.

## Read/projection failures

Projection storage failure degrades retained history only. Current Trust Map, source health and Signal reads remain source-backed and cannot use stale projection rows to grant authority.
