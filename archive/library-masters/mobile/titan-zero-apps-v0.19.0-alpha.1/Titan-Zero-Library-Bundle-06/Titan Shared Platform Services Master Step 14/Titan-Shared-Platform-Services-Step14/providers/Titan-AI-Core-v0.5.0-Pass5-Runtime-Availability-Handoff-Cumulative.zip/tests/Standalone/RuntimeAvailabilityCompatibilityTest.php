<?php
$root = dirname(__DIR__, 2);
$errors = [];
$manifest = json_decode((string) file_get_contents($root . '/workforce-integration.json'), true);
$states = $manifest['runtime_contract']['availability_states'] ?? [];
$expected = ['available','degraded','unavailable','missing_provider','blocked','policy_disabled'];
if ($states !== $expected) { $errors[] = 'availability states mismatch'; }
if (($manifest['runtime_contract']['ambiguous_unpinned_execution_allowed'] ?? true) !== false) { $errors[] = 'unpinned execution not fail-closed'; }
$src8 = (string) file_get_contents($root . '/System/Services/HealthCheck.php');
if (! str_contains($src8, '\'workforce_state\' => $workforceState')) { $errors[] = 'System/Services/HealthCheck.php: missing contract marker'; }
if (! str_contains($src8, '\'policy_disabled\'')) { $errors[] = 'System/Services/HealthCheck.php: missing contract marker'; }
if (! str_contains($src8, '\'unavailable\'')) { $errors[] = 'System/Services/HealthCheck.php: missing contract marker'; }
if (! str_contains($src8, '\'available\'')) { $errors[] = 'System/Services/HealthCheck.php: missing contract marker'; }
if ($errors !== []) { fwrite(STDERR, implode("\n", $errors) . "\n"); exit(1); }
echo "RUNTIME_AVAILABILITY_COMPATIBILITY: PASS\n";
