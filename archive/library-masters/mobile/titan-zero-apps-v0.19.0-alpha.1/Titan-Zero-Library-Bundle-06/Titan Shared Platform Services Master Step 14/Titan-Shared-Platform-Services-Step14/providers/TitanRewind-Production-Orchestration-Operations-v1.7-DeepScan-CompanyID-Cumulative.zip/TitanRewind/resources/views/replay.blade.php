@extends('panel.layout.app')
@section('title', 'Titan Rewind — Replay')

@section('content')
    <a href="#titan-rewind-content" class="sr-only focus:not-sr-only">{{ __('titan-rewind::rewind.accessibility_skip') }}</a>
    <main id="titan-rewind-content" role="main" class="container py-8 space-y-5">
        <div><h1 class="text-2xl font-semibold">Rewind Replay / Comparison</h1><code>{{ $run->run_uuid }}</code></div>
        <div class="rounded border p-4">
            <strong>Status:</strong> {{ $run->status }}<br>
            <strong>Mode:</strong> {{ $run->mode }}<br>
            <strong>Trace:</strong> {{ $run->trace_id }}<br>
            <strong>Target:</strong> {{ $run->target_environment }}<br>
            <strong>Mutation policy:</strong> {{ $run->mutation_policy ?: 'deny' }}<br>
            <strong>Network policy:</strong> {{ $run->network_policy ?: 'deny-all' }}
        </div>
        @if($run->status === 'completed')
            <div class="rounded border p-4 space-y-1">
                <div><strong>Mutation attempted:</strong> {{ data_get($run->result, 'mutation_attempted') ? 'yes' : 'no' }}</div>
                <div><strong>Decision re-execution performed:</strong> {{ data_get($run->result, 'decision_reexecution_performed') ? 'yes' : 'no' }}</div>
                <div><strong>Execution semantics:</strong> {{ data_get($run->result, 'execution_semantics', 'historical projection') }}</div>
                <div><strong>Reproducibility:</strong> {{ data_get($run->result, 'reproducibility', $run->reproducibility) }}</div>
                @if(data_get($run->result, 'diff_count') !== null)<div><strong>Differences:</strong> {{ data_get($run->result, 'diff_count', 0) }} · Risk {{ data_get($run->result, 'diff_risk', 'unknown') }}</div>@endif
                @if(data_get($run->result, 'event_count') !== null)<div><strong>Events simulated:</strong> {{ data_get($run->result, 'event_count', 0) }}</div>@endif
            </div>
            @if(data_get($run->result, 'impacted_event_ids'))
                <section class="rounded border p-4"><h2 class="font-semibold mb-2">Impacted historical events</h2><div class="flex flex-wrap gap-2">@foreach(data_get($run->result, 'impacted_event_ids', []) as $eventId)<code class="rounded border px-2 py-1">{{ $eventId }}</code>@endforeach</div></section>
            @endif
            @if(data_get($run->result, 'artifact_resolution'))
                <section class="rounded border p-4"><h2 class="font-semibold mb-2">Historical artifact resolution</h2><pre class="overflow-x-auto text-xs">{{ json_encode(data_get($run->result, 'artifact_resolution'), JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></section>
            @endif
            <pre class="overflow-x-auto rounded border p-4 text-xs">{{ json_encode($run->result, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre>
        @elseif($run->status === 'failed')
            <div class="rounded border p-4">Replay failed: {{ $run->error_text }}</div>
        @else
            <div class="rounded border p-4">The replay/comparison is queued or running on <code>titan-rewind-replay</code>. Refresh this page to see the persisted result.</div>
        @endif
    </main>
@endsection
