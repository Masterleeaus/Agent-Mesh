<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Contracts;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;

interface AiCoreGatewayContract extends EngineGatewayContract
{
    /** @param array<string,mixed> $mission */
    public function plan(TraceContext $trace, array $mission, string $operationId): EngineGatewayResult;
}
