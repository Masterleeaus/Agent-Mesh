<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanNexus\Unit;

use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompiledTitanConfig;
use App\Extensions\TitanNexus\System\Domain\CompilationStatus;
use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

final class DomainCoreTest extends TestCase
{
    public function test_profile_fingerprint_is_canonical_and_stable(): void
    {
        $a = $this->profile(['b' => 2, 'a' => 1]);
        $b = $this->profile(['a' => 1, 'b' => 2]);

        self::assertSame($a->fingerprint(), $b->fingerprint());
    }

    public function test_trace_context_requires_canonical_identifiers(): void
    {
        $this->expectException(InvalidArgumentException::class);
        TraceContext::fromArray([
            'tenant_company_id' => 7,
            'trace_id' => 'bad',
            'correlation_id' => '22222222-2222-4222-8222-222222222222',
            'causation_id' => '33333333-3333-4333-8333-333333333333',
        ]);
    }

    public function test_compilation_rejects_cross_tenant_context(): void
    {
        $this->expectException(InvalidArgumentException::class);
        NexusCompilation::draft(
            $this->profile([]),
            TraceContext::fromArray([
                'tenant_company_id' => 8,
                'trace_id' => '11111111-1111-4111-8111-111111111111',
                'correlation_id' => '22222222-2222-4222-8222-222222222222',
                'causation_id' => '33333333-3333-4333-8333-333333333333',
            ]),
            '44444444-4444-4444-8444-444444444444',
            '0.2.0'
        );
    }

    public function test_compiled_configuration_advances_draft_without_mutating_it(): void
    {
        $profile = $this->profile([]);
        $trace = $this->trace();
        $draft = NexusCompilation::draft($profile, $trace, '44444444-4444-4444-8444-444444444444', '0.2.0');
        $config = CompiledTitanConfig::fromArray([
            'tenant_company_id' => 7,
            'configuration_version' => '1',
            'compiler_version' => '0.2.0',
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'knowledge_snapshot_version' => null,
            'source_profile_hash' => $profile->fingerprint(),
            'sections' => ['operations' => ['enabled' => true]],
        ]);

        $compiled = $draft->withCompiledConfiguration($config);

        self::assertSame(CompilationStatus::Draft, $draft->status());
        self::assertSame(CompilationStatus::Compiled, $compiled->status());
        self::assertSame($config->outputHash(), $compiled->compiledConfiguration()?->outputHash());
    }

    private function profile(array $sections): BusinessProfile
    {
        return BusinessProfile::fromArray([
            'tenant_company_id' => 7,
            'profile_version' => '1.0.0',
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
            'timezone' => 'Australia/Melbourne',
            'sections' => $sections,
        ]);
    }

    private function trace(): TraceContext
    {
        return TraceContext::fromArray([
            'tenant_company_id' => 7,
            'trace_id' => '11111111-1111-4111-8111-111111111111',
            'correlation_id' => '22222222-2222-4222-8222-222222222222',
            'causation_id' => '33333333-3333-4333-8333-333333333333',
        ]);
    }
}
