<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_pulse_projection_freshness')) {
            Schema::create('titan_signal_pulse_projection_freshness', function (Blueprint $table): void {
                $table->id();
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->string('dimension', 40);
                $table->string('dimension_value', 191)->default('__all__');
                $table->uuid('last_event_id')->nullable();
                $table->timestamp('last_recorded_at')->nullable();
                $table->uuid('last_ingested_event_id')->nullable();
                $table->timestamp('last_ingested_recorded_at')->nullable();
                $table->timestamp('last_projected_at')->nullable();
                $table->unsignedBigInteger('projected_count')->default(0);
                $table->timestamps();
                $table->unique(['scope', 'tenant_key', 'dimension', 'dimension_value'], 'tsppf_scope_dimension_uq');
                $table->index(['scope', 'tenant_key', 'last_projected_at'], 'tsppf_scope_freshness_idx');
                $table->index(['dimension', 'dimension_value', 'last_projected_at'], 'tsppf_dimension_freshness_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_pulse_command_receipts')) {
            Schema::create('titan_signal_pulse_command_receipts', function (Blueprint $table): void {
                $table->id();
                $table->uuid('command_event_id')->unique('tspcrp_command_uq');
                $table->uuid('receipt_event_id')->nullable()->unique('tspcrp_receipt_uq');
                $table->uuid('trace_id');
                $table->uuid('correlation_id')->nullable();
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->string('source', 191)->nullable();
                $table->string('source_component', 191)->nullable();
                $table->dateTime('command_occurred_at');
                $table->timestamp('receipt_occurred_at')->nullable();
                $table->unsignedBigInteger('latency_ms')->nullable();
                $table->string('pairing_method', 32)->nullable();
                $table->timestamps();
                $table->index(['scope', 'tenant_key', 'command_occurred_at'], 'tspcrp_missing_idx');
                $table->index(['scope', 'tenant_key', 'receipt_occurred_at'], 'tspcrp_latency_idx');
                $table->index(['trace_id', 'scope', 'tenant_key', 'command_occurred_at'], 'tspcrp_trace_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_operational_health_snapshots')) {
            Schema::create('titan_signal_operational_health_snapshots', function (Blueprint $table): void {
                $table->id();
                $table->string('snapshot_key', 80)->unique();
                $table->string('status', 24);
                $table->json('current_state');
                $table->json('historical_incidents');
                $table->dateTime('captured_at')->index();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_operational_health_snapshots');
        Schema::dropIfExists('titan_signal_pulse_command_receipts');
        Schema::dropIfExists('titan_signal_pulse_projection_freshness');
    }
};
