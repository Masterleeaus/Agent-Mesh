<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Events;

use App\Extensions\TitanConnect\System\Models\OutboundDelivery;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

final class ExternalMessageStatusChanged
{
    use Dispatchable;
    use SerializesModels;

    public function __construct(
        public readonly OutboundDelivery $delivery,
        public readonly string $previousStatus,
    ) {
    }
}
