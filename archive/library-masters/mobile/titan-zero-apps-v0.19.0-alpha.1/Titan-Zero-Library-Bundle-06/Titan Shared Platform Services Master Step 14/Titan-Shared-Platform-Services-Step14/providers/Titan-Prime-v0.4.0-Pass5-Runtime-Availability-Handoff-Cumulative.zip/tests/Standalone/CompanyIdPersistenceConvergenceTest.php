<?php
$root = dirname(__DIR__, 2);
$migration = file_get_contents($root . '/database/migrations/2026_08_22_000005_add_canonical_company_id_compatibility.php');
if ($migration === false || ! str_contains($migration, "'company_id'") || ! str_contains($migration, "tenant_company_id")) { fwrite(STDERR, "company-id additive migration missing\n"); exit(1); }
$report = file_get_contents($root . '/PASS-COMPANY-ID-PERSISTENCE-CONVERGENCE.md');
if ($report === false || ! str_contains($report, '`company_id`')) { fwrite(STDERR, "company-id pass report missing\n"); exit(1); }
echo "COMPANY_ID_PERSISTENCE_CONVERGENCE: PASS\n";
