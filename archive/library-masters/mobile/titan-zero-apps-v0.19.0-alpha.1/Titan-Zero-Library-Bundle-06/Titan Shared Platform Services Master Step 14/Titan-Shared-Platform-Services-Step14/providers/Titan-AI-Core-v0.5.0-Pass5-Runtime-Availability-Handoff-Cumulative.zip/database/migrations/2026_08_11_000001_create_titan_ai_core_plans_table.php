<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('titan_ai_core_plans')) {
            return;
        }

        Schema::create('titan_ai_core_plans', function (Blueprint $table): void {
            $table->id();
            $table->string('tenant_company_id')->index();
            $table->uuid('plan_id')->unique();
            $table->uuid('trace_id')->index();
            $table->text('intent');
            $table->string('status', 64)->default('planned')->index();
            $table->json('plan')->nullable();
            $table->json('validation')->nullable();
            $table->json('simulation')->nullable();
            $table->string('schema_version', 16)->default('1.0');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        // Explicit migration rollback is supported. Extension uninstall does not invoke
        // rollback and retains owned tenant data by default.
        Schema::dropIfExists('titan_ai_core_plans');
    }
};
