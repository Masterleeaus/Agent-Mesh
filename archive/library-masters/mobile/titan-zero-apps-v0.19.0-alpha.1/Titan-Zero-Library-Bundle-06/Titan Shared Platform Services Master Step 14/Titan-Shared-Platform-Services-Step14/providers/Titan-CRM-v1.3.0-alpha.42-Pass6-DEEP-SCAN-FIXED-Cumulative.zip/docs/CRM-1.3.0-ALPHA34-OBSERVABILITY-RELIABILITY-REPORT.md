# CRM Observability, Reliability & Operations — v1.3.0-alpha.34

Alpha.34 introduces a read-only operational metrics layer and doctor workflow over existing durable CRM journals/outboxes. It does not create a second source of business truth.

Key additions:
- structured 24-hour command, Signal, projection, outbound-effect, import, portal, webhook and document-render metrics;
- command latency p50/p95/max, rejection/invariant/concurrency counts and durable duplicate replay counts;
- `crm:metrics` and `crm:doctor` read-only commands;
- PASS/WARN/BLOCK severity on production readiness;
- configurable warning thresholds under `crm.observability`;
- explicit recovery runbook for Signal, projections, Command Bus, scanner, webhook, imports, document rendering and Titan Connect;
- production readiness warnings for operational backlogs without weakening fail-closed blockers.

CRM Observability, Reliability & Operations remains derivative/read-only. Recovery tooling may advance queue journals or rebuild disposable projections only through their existing dedicated workers; it may not bypass governed CRM mutation paths.
