<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface TenantRecordLookupContract
{
    public function find(string $table, int $tenantCompanyId, string $publicId): ?array;
}
