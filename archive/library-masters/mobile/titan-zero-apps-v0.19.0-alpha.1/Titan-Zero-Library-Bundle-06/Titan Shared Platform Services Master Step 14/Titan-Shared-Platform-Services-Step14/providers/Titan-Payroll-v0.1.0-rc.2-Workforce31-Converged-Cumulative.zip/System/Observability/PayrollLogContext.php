<?php
namespace App\Extensions\TitanPayroll\System\Observability;
final class PayrollLogContext { public static function make(int $tenantCompanyId,?string $trace=null,?string $correlation=null,?string $causation=null): array { return ['extension_key'=>'titan-payroll','tenant_company_id'=>$tenantCompanyId,'trace_id'=>$trace,'correlation_id'=>$correlation,'causation_id'=>$causation]; } }
