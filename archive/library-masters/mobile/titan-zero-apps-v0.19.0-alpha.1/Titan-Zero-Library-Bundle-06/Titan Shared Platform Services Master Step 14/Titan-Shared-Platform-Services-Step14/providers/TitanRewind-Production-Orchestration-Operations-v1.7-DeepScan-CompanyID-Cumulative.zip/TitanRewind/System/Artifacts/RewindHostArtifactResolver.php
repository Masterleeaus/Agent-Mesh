<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Artifacts;
use App\Extensions\TitanRewind\System\Contracts\RewindHistoricalArtifactResolverContract;
use InvalidArgumentException;
final class RewindHostArtifactResolver implements RewindHistoricalArtifactResolverContract
{
 public function __construct(private object $resolver){if(!method_exists($resolver,'artifactKind')&&!method_exists($resolver,'kind'))throw new InvalidArgumentException('Host artifact resolver must expose artifactKind() or kind().');if(!method_exists($resolver,'resolve'))throw new InvalidArgumentException('Host artifact resolver must expose resolve().');}
 public function kind(): string{$kind=method_exists($this->resolver,'artifactKind')?(string)$this->resolver->artifactKind():(string)$this->resolver->kind();$kind=strtolower(trim($kind));if($kind===''||preg_match('/^[a-z][a-z0-9._-]{1,79}$/',$kind)!==1)throw new InvalidArgumentException('Host artifact resolver kind is invalid.');return $kind;}
 public function resolve(string $version,array $context=[]): ?array{$result=$this->resolver->resolve($version,$context);if($result===null)return null;if(!is_array($result))throw new InvalidArgumentException('Host artifact resolver must return an array or null.');return $result;}
}
