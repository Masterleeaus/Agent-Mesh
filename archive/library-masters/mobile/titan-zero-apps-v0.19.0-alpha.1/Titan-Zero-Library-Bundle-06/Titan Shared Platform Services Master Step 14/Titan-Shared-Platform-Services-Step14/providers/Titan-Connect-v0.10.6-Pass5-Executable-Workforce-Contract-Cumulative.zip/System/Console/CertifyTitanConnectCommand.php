<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Console;

use App\Extensions\TitanConnect\System\Services\HostCertificationService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use RuntimeException;

final class CertifyTitanConnectCommand extends Command
{
    protected $signature = 'titan-connect:certify
        {--json : Emit machine-readable JSON}
        {--strict : Treat warnings as certification failures}
        {--queue-probe : Dispatch a cache-only probe and wait for a real queue worker}
        {--broadcast-probe : Publish an isolated realtime probe through the configured broadcaster}
        {--two-company-probe : Run a rollback-only live database isolation probe}
        {--timeout= : Probe timeout in seconds}
        {--output= : Write the credential-free JSON certification report to this path}';

    protected $description = 'Run Titan Connect host certification without sending provider messages or voice calls.';

    public function handle(HostCertificationService $certification): int
    {
        $timeout = $this->option('timeout');
        $report = $certification->certify([
            'queue' => (bool) $this->option('queue-probe'),
            'broadcast' => (bool) $this->option('broadcast-probe'),
            'two_company' => (bool) $this->option('two-company-probe'),
            'timeout' => $timeout !== null ? max(1, (int) $timeout) : (int) config('titan-connect.certification.probe_timeout_seconds', 10),
        ]);

        $encoded = (string) json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        $output = trim((string) ($this->option('output') ?? ''));
        if ($output !== '') {
            $directory = dirname($output);
            if ($directory !== '.' && ! is_dir($directory)) File::makeDirectory($directory, 0750, true);
            if (File::put($output, $encoded."\n") === false) throw new RuntimeException('Unable to write Titan Connect certification report.');
        }

        if ((bool) $this->option('json')) {
            $this->line($encoded);
        } else {
            $this->table(['Check', 'Status', 'Message'], array_map(
                static fn (array $check): array => [$check['name'], strtoupper($check['status']), $check['message']],
                $report['checks'],
            ));
            $this->line(sprintf('Summary: %d ok, %d warnings, %d errors.', $report['summary']['ok'], $report['summary']['warning'], $report['summary']['error']));
            if ($output !== '') $this->info('Report written to '.$output);
        }

        return $certification->passes($report, (bool) $this->option('strict')) ? self::SUCCESS : self::FAILURE;
    }
}
