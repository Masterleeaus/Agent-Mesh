# MagicAI 11 Host Certification

This extension is certified statically against the supplied MagicAI 11.00 server package.

Confirmed host contracts:

- Provider: `App\Extensions\Crm\System\CrmServiceProvider`
- Marketplace register key: `crm`
- CRM Assistant service: `App\Extensions\Crm\System\Services\CrmAssistantChatService`
- CRM Assistant system prompt signature: `systemPrompt(int $userId, string $scope)`
- Assistant view: `crm::assistant.includes.chat_area_container`
- Assistant template type: `crmAssistant`
- Assistant website/chat context: `crm-assistant`
- CRM plan entitlement: `ext_crm_dropdown`
- Sales plan entitlement: `ext_sales_dropdown`
- Admin settings route: `dashboard.admin.crm.settings`
- Contact-capture event: `App\Events\ContactCapturedEvent`

The MagicAI marketplace installer creates `app/Extensions/Crm` first and extracts the downloaded ZIP into that folder. Therefore the marketplace ZIP must contain `extension.json`, `System/`, `routes/`, etc. at ZIP root; it must **not** contain an outer `Crm/` directory.

Static certification cannot substitute for a full Laravel boot because the supplied server archive does not include `vendor/` or a production database.
