# Security operations

Default production posture: trusted HTTPS origins plus explicitly allowlisted Chrome-extension origins where Codee is used, destructive operations disabled, raw query tool disabled, token scope enabled where the host auth stack supplies token abilities, and dedicated query-only DB credentials for arbitrary SQL reads.

Capability enforcement is performed inside every tool as well as at the transport access boundary. Cross-domain mutation is never inferred from read authority.

## Mutation ticket security
Mutation tickets live under the protected Titan MCP storage subtree, which generic repository tools cannot access. Ticket JSON has a sidecar SHA-256 seal, strict id syntax, symlink-safe storage, 0600 files, bounded serialized arguments, actor ownership, expiry, canonical argument hashing and an atomic prepared→committing compare-and-swap. Raw arguments are never returned from `titan_mutation_status`.
