<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanAutonomy\System\DTOs\EvidenceSnapshot;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\RiskClass;
use App\Extensions\TitanAutonomy\System\Services\GateEvaluator;
use PHPUnit\Framework\TestCase;

final class GateEvaluatorTest extends TestCase
{
    private function evaluator(): GateEvaluator
    {
        return new GateEvaluator(
            ['low' => 1, 'medium' => 2, 'high' => 3, 'critical' => 3],
            ['low' => 'trusted_auto', 'medium' => 'trusted_auto', 'high' => 'auto', 'critical' => 'semi_auto'],
        );
    }

    public function test_low_risk_requires_one_consecutive_success(): void
    {
        $result = $this->evaluator()->evaluate(
            RiskClass::Low,
            AutonomyLevel::Suggest,
            AutonomyLevel::Assist,
            new EvidenceSnapshot(currentSuccessStreak: 1),
        );
        self::assertTrue($result->eligible);
    }

    public function test_medium_risk_requires_two_consecutive_successes(): void
    {
        $locked = $this->evaluator()->evaluate(
            RiskClass::Medium,
            AutonomyLevel::Suggest,
            AutonomyLevel::Assist,
            new EvidenceSnapshot(currentSuccessStreak: 1),
        );
        $eligible = $this->evaluator()->evaluate(
            RiskClass::Medium,
            AutonomyLevel::Suggest,
            AutonomyLevel::Assist,
            new EvidenceSnapshot(currentSuccessStreak: 2),
        );
        self::assertFalse($locked->eligible);
        self::assertTrue($eligible->eligible);
    }

    public function test_high_risk_requires_three_and_ceiling_blocks_trusted_auto(): void
    {
        $eligible = $this->evaluator()->evaluate(
            RiskClass::High,
            AutonomyLevel::SemiAuto,
            AutonomyLevel::Auto,
            new EvidenceSnapshot(currentSuccessStreak: 3),
        );
        $ceiling = $this->evaluator()->evaluate(
            RiskClass::High,
            AutonomyLevel::Auto,
            AutonomyLevel::TrustedAuto,
            new EvidenceSnapshot(currentSuccessStreak: 3),
        );
        self::assertTrue($eligible->eligible);
        self::assertFalse($ceiling->eligible);
        self::assertContains('RISK_CEILING', $ceiling->reasonCodes);
    }
}
