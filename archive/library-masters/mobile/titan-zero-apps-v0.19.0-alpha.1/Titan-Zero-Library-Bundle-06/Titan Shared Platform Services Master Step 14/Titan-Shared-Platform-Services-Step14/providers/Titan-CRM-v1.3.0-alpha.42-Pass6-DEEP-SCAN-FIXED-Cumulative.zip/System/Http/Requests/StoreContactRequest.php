<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
final class StoreContactRequest extends FormRequest {
 public function authorize(): bool { return true; }
 public function rules(): array { return ['company_public_id'=>['nullable','string','size:26'],'first_name'=>['required','string','max:190'],'last_name'=>['nullable','string','max:190'],'email'=>['nullable','email','max:190','required_without:phone'],'phone'=>['nullable','string','max:60','required_without:email'],'role'=>['nullable','string','max:100'],'is_primary'=>['sometimes','boolean']]; }
}
