<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$readJson = static function (string $path) use (&$errors): array {
    $raw = @file_get_contents($path);
    if ($raw === false) {
        $errors[] = "missing JSON: {$path}";
        return [];
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        $errors[] = "invalid JSON: {$path}";
        return [];
    }
    return $data;
};

$installer = $readJson($root . '/extension.json');
$sidecar = $readJson($root . '/extension.manifest.json');

$expectedInstallerCore = ['schema', 'slug', 'folder', 'provider', 'version', 'integrity'];
foreach ($expectedInstallerCore as $key) {
    if (!array_key_exists($key, $installer)) $errors[] = 'extension.json missing Titan core field: ' . $key;
}
if (($installer['schema'] ?? null) !== 'titan-extension-v1') $errors[] = 'installer schema mismatch';
if (($installer['slug'] ?? null) !== 'titan-knowledge-authority') $errors[] = 'installer slug mismatch';
if (($installer['folder'] ?? null) !== 'TitanKnowledgeAuthority') $errors[] = 'installer folder mismatch';
if ((!is_string($installer['version'] ?? null) || preg_match('/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $installer['version']) !== 1)) $errors[] = 'installer version mismatch';

if (($sidecar['schema_version'] ?? null) !== '2.2') $errors[] = 'sidecar must be canonical schema 2.2';
if (($sidecar['version'] ?? null) !== ($installer['version'] ?? null)) $errors[] = 'sidecar version mismatch';
if (($sidecar['architecture']['profile'] ?? null) !== 'intelligence-engine') $errors[] = 'architecture profile must be intelligence-engine';
if (!in_array('knowledge-authority', $sidecar['architecture']['modifiers'] ?? [], true)) $errors[] = 'knowledge-authority modifier missing';
if (($sidecar['authority']['canonical_owner'] ?? null) !== true) $errors[] = 'Knowledge Authority must be canonical owner';
if (($sidecar['authority']['cross_domain_write_policy'] ?? null) !== 'forbidden') $errors[] = 'cross-domain writes must be forbidden';
if (($sidecar['governance']['knowledge_authority'] ?? null) !== 'self') $errors[] = 'governance.knowledge_authority must be self';
if (($sidecar['governance']['offline_never_increases_authority'] ?? null) !== true) $errors[] = 'offline authority invariant missing';

$ka = $sidecar['knowledge_authority'] ?? [];
foreach (['immutable_versions','deterministic_authority_precedence','deterministic_applicability','provenance_required','freshness_required','contradictions_explicit','source_access_policy_required','raw_evidence_preserved'] as $field) {
    if (($ka[$field] ?? null) !== true) $errors[] = "knowledge_authority.{$field} must be true";
}
foreach (['llm_may_assign_authority','llm_may_resolve_equal_rank_conflict','offline_authority_promotion'] as $field) {
    if (($ka[$field] ?? null) !== false) $errors[] = "knowledge_authority.{$field} must be false";
}

$expectedSchemas = [
    'schemas/knowledge-source.schema.json',
    'schemas/knowledge-source-version.schema.json',
    'schemas/knowledge-claim.schema.json',
    'schemas/knowledge-jurisdiction.schema.json',
    'schemas/knowledge-applicability.schema.json',
    'schemas/knowledge-contradiction.schema.json',
    'schemas/knowledge-refresh-receipt.schema.json',
    'schemas/knowledge-resolution.schema.json',
];
foreach ($expectedSchemas as $rel) {
    if (!is_file($root . '/' . $rel)) $errors[] = "missing Knowledge Authority runtime schema: {$rel}";
}

$tests = $sidecar['tests'] ?? [];
foreach ($tests as $testFamily) {
    if (!in_array($testFamily, ['unit','feature','integration','architecture','security'], true)) {
        $errors[] = "non-canonical test family: {$testFamily}";
    }
}
if (array_key_exists('titan_platform', $sidecar['compatibility'] ?? [])) $errors[] = 'compatibility.titan_platform is not canonical v2.2';

$docs = $sidecar['documentation'] ?? [];
foreach ($docs as $rel) {
    if (is_string($rel) && $rel !== '' && !is_file($root . '/' . $rel)) $errors[] = "missing documented file: {$rel}";
}

$integrity = $installer['integrity']['files'] ?? null;
if (!is_array($integrity)) {
    $errors[] = 'integrity.files must be an object';
} else {
    $actual = [];
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $file) {
        if (!$file->isFile()) continue;
        $rel = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
        if ($rel === 'extension.json') continue;
        $actual[$rel] = hash_file('sha256', $file->getPathname());
    }
    ksort($actual);
    ksort($integrity);
    if ($actual !== $integrity) $errors[] = 'integrity.files must exactly hash every packaged file except extension.json';
}

if ($errors) {
    foreach ($errors as $error) fwrite(STDERR, "FAIL: {$error}\n");
    exit(1);
}

echo "Titan Knowledge Authority Blueprint v4.2.1 rebase verification: PASS\n";
