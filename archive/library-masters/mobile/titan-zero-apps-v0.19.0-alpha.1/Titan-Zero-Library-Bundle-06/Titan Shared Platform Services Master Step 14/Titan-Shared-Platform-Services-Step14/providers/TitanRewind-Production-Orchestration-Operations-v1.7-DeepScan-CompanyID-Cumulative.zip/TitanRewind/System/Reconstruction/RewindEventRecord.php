<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Reconstruction;

use DateTimeImmutable;
use InvalidArgumentException;

final class RewindEventRecord
{
    private const HIDDEN_REASONING_KEYS = [
        'chain_of_thought',
        'chain-of-thought',
        'cot',
        'hidden_reasoning',
        'hidden-reasoning',
        'reasoning_content',
        'reasoning-content',
        'private_reasoning',
        'private-reasoning',
    ];

    private function __construct(private readonly array $data)
    {
    }

    public static function fromArray(array $input): self
    {
        $tenantCompanyId = (int) ($input['tenant_company_id'] ?? 0);
        if ($tenantCompanyId < 1) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }

        $eventId = trim((string) ($input['event_id'] ?? ''));
        $traceId = trim((string) ($input['trace_id'] ?? ''));
        self::assertUuid($eventId, 'event_id');
        self::assertUuid($traceId, 'trace_id');

        $correlationId = self::nullableUuid($input['correlation_id'] ?? null, 'correlation_id');
        $causationId = self::nullableUuid($input['causation_id'] ?? null, 'causation_id');

        $sourceEngine = self::boundedString($input['source_engine'] ?? null, 'source_engine', 80, true);
        $sourceRecordId = self::boundedString($input['source_record_id'] ?? null, 'source_record_id', 191, false);
        $eventType = self::boundedString($input['event_type'] ?? null, 'event_type', 120, true);

        $sequence = filter_var($input['sequence'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
        if ($sequence === false) {
            throw new InvalidArgumentException('sequence must be a non-negative integer.');
        }

        $occurredAt = trim((string) ($input['occurred_at'] ?? ''));
        if ($occurredAt === '') {
            throw new InvalidArgumentException('occurred_at is required.');
        }
        try {
            new DateTimeImmutable($occurredAt);
        } catch (\Throwable) {
            throw new InvalidArgumentException('occurred_at must be a valid date/time value.');
        }

        $tier = $input['tier'] ?? null;
        if ($tier !== null) {
            $tier = filter_var($tier, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 255]]);
            if ($tier === false) {
                throw new InvalidArgumentException('tier must be between 0 and 255 when present.');
            }
        }

        $lane = self::boundedString($input['lane'] ?? null, 'lane', 80, false);

        foreach (['reason_codes', 'evidence_refs', 'rationale', 'payload', 'risk_state', 'assurance_state', 'autonomy_state', 'governance_state'] as $jsonField) {
            if (isset($input[$jsonField]) && !is_array($input[$jsonField])) {
                throw new InvalidArgumentException("{$jsonField} must be an array when present.");
            }
            if (isset($input[$jsonField])) {
                self::assertNoHiddenReasoning($input[$jsonField], $jsonField);
            }
        }

        $data = [
            'tenant_company_id' => $tenantCompanyId,
            'event_id' => $eventId,
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId,
            'source_engine' => $sourceEngine,
            'source_record_id' => $sourceRecordId,
            'event_type' => $eventType,
            'sequence' => (int) $sequence,
            'occurred_at' => $occurredAt,
            'recorded_at' => isset($input['recorded_at']) ? trim((string) $input['recorded_at']) : null,
            'tier' => $tier === null ? null : (int) $tier,
            'lane' => $lane,
            'actor_type' => self::boundedString($input['actor_type'] ?? null, 'actor_type', 60, false),
            'actor_id' => self::boundedString($input['actor_id'] ?? null, 'actor_id', 191, false),
            'decision_id' => self::boundedString($input['decision_id'] ?? null, 'decision_id', 128, false),
            'policy_version' => self::boundedString($input['policy_version'] ?? null, 'policy_version', 120, false),
            'guide_version' => self::boundedString($input['guide_version'] ?? null, 'guide_version', 120, false),
            'knowledge_version' => self::boundedString($input['knowledge_version'] ?? null, 'knowledge_version', 120, false),
            'model_provider' => self::boundedString($input['model_provider'] ?? null, 'model_provider', 80, false),
            'model_name' => self::boundedString($input['model_name'] ?? null, 'model_name', 120, false),
            'model_version' => self::boundedString($input['model_version'] ?? null, 'model_version', 120, false),
            'capability_name' => self::boundedString($input['capability_name'] ?? null, 'capability_name', 160, false),
            'capability_version' => self::boundedString($input['capability_version'] ?? null, 'capability_version', 80, false),
            'reason_codes' => $input['reason_codes'] ?? null,
            'evidence_refs' => $input['evidence_refs'] ?? null,
            'rationale' => $input['rationale'] ?? null,
            'risk_state' => $input['risk_state'] ?? null,
            'assurance_state' => $input['assurance_state'] ?? null,
            'autonomy_state' => $input['autonomy_state'] ?? null,
            'governance_state' => $input['governance_state'] ?? null,
            'payload' => $input['payload'] ?? null,
            'source_hash' => self::hashValue($input['source_hash'] ?? null, 'source_hash'),
            'previous_hash' => self::hashValue($input['previous_hash'] ?? null, 'previous_hash'),
            'integrity_hash' => self::hashValue($input['integrity_hash'] ?? null, 'integrity_hash'),
            'schema_version' => max(1, (int) ($input['schema_version'] ?? 1)),
        ];

        if ($data['recorded_at'] === '') {
            $data['recorded_at'] = null;
        }
        if ($data['recorded_at'] !== null) {
            try {
                new DateTimeImmutable($data['recorded_at']);
            } catch (\Throwable) {
                throw new InvalidArgumentException('recorded_at must be a valid date/time value when present.');
            }
        }

        return new self($data);
    }

    public function toArray(): array
    {
        return $this->data;
    }

    public function tenantCompanyId(): int { return (int) $this->data['tenant_company_id']; }
    public function traceId(): string { return (string) $this->data['trace_id']; }

    private static function nullableUuid(mixed $value, string $field): ?string
    {
        if ($value === null) {
            return null;
        }

        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }

        self::assertUuid($value, $field);

        return $value;
    }

    private static function assertUuid(string $value, string $field): void
    {
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value)) {
            throw new InvalidArgumentException("{$field} must be a UUID.");
        }
    }

    private static function boundedString(mixed $value, string $field, int $maxLength, bool $required): ?string
    {
        if ($value === null) {
            if ($required) {
                throw new InvalidArgumentException("{$field} is required.");
            }
            return null;
        }

        $value = trim((string) $value);
        if ($value === '') {
            if ($required) {
                throw new InvalidArgumentException("{$field} is required.");
            }
            return null;
        }

        if (strlen($value) > $maxLength) {
            throw new InvalidArgumentException("{$field} exceeds {$maxLength} bytes.");
        }

        return $value;
    }

    private static function hashValue(mixed $value, string $field): ?string
    {
        if ($value === null || trim((string) $value) === '') {
            return null;
        }

        $value = strtolower(trim((string) $value));
        if (!preg_match('/^[0-9a-f]{64}$/', $value)) {
            throw new InvalidArgumentException("{$field} must be a SHA-256 hex digest.");
        }

        return $value;
    }

    private static function assertNoHiddenReasoning(array $value, string $path): void
    {
        foreach ($value as $key => $item) {
            $normalizedKey = strtolower(trim((string) $key));
            if (in_array($normalizedKey, self::HIDDEN_REASONING_KEYS, true)) {
                throw new InvalidArgumentException("Hidden chain-of-thought content is not permitted at {$path}.{$normalizedKey}.");
            }

            if (is_array($item)) {
                self::assertNoHiddenReasoning($item, $path . '.' . $normalizedKey);
            }
        }
    }
}
