@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Calendar','subtitle'=>'Meetings, calls, deadlines and synchronised CRM events.','surface'=>'crew','journey'=>'new-calendar-event'])
@if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif
<div class="card"><div class="list-group list-group-flush">@forelse($events as $event)<div class="list-group-item"><div class="d-flex justify-content-between"><div><strong>{{ $event['name'] }}</strong><div class="small text-muted">{{ $event['location'] ?? '' }}</div></div><span class="badge border text-body">{{ ucfirst($event['status'] ?? 'scheduled') }}</span></div><div class="mt-2">{{ $event['starts_at'] ?? '—' }} @if($event['ends_at']??null)→ {{ $event['ends_at'] }}@endif</div>@if($event['external_provider']??null)<div class="small text-muted">Synced: {{ $event['external_provider'] }}</div>@endif</div>@empty<div class="list-group-item text-muted">No calendar events.</div>@endforelse</div></div>
@endcomponent
@endsection
