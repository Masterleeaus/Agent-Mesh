<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use DateTimeImmutable;
use InvalidArgumentException;

final class CommandReceiptPairing
{
    /** @return array{command_event_id:string,receipt_event_id:string,latency_ms:int,pairing_method:string} */
    public static function pair(string $commandEventId, DateTimeImmutable $commandAt, string $receiptEventId, DateTimeImmutable $receiptAt, string $method): array
    {
        if ($commandEventId === '' || $receiptEventId === '') {
            throw new InvalidArgumentException('Command and receipt event ids are required.');
        }
        if (! in_array($method, ['direct_causation', 'trace_unmatched'], true)) {
            throw new InvalidArgumentException('Unsupported command/receipt pairing method.');
        }
        $latency = max(0, (int) round(((float) $receiptAt->format('U.u') - (float) $commandAt->format('U.u')) * 1000));
        return [
            'command_event_id' => $commandEventId,
            'receipt_event_id' => $receiptEventId,
            'latency_ms' => $latency,
            'pairing_method' => $method,
        ];
    }
}
