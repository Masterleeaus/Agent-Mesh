<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Governance\{CrmCommandBusGateway,CrmHumanMutationGateway};
use App\Extensions\Crm\System\Portal\CrmPortalGrantService;
use App\Extensions\Crm\System\Security\CrmPermissionService;
use App\Extensions\Crm\System\Tenancy\{CrmCompanyContextResolver,CrmCompanyScope};
use Illuminate\Database\ConnectionInterface;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Symfony\Component\HttpKernel\Exception\ServiceUnavailableHttpException;

final class PortalController extends Controller
{
    public function __construct(private CrmHumanMutationGateway $mutations,private CrmCommandBusGateway $commands) {}

    public function index(Request $request,ConnectionInterface $db,CrmPermissionService $permissions)
    { $uid=(int)$request->user()->id;$permissions->authorize($uid,'crm.portal.manage');return view('crm::portal.index',['grants'=>$db->table('crm_portal_grants')->where('company_id',CrmCompanyScope::companyId($uid))->orderByDesc('id')->limit(200)->get()]); }

    public function show(Request $request,string $token,CrmPortalGrantService $grants,ConnectionInterface $db)
    {
        $grant=$grants->resolve($token,$request); $document=null; $comments=[]; $verified=$grants->isVerifiedSession($grant,$request);
        if($verified && $grant['document_type'] && $grant['document_public_id'] && $grants->allows($grant,'sales.view')){
            $table=$this->salesTable((string)$grant['document_type']);
            if($table) $document=$db->table($table)->where('company_id',(int)$grant['company_id'])->where('public_id',$grant['document_public_id'])->first();
        }
        if($verified && $grants->allows($grant,'sales.comment')) $comments=$db->table('crm_portal_comments')->where('company_id',(int)$grant['company_id'])->where('portal_grant_public_id',$grant['public_id'])->orderBy('id')->get();
        return view('crm::portal.show',['grant'=>$grant,'document'=>$document,'comments'=>$comments,'token'=>$token,'verified'=>$verified]);
    }

    public function verify(Request $request,string $token,CrmPortalGrantService $grants)
    {
        $data=$request->validate(['verification_code'=>'required|digits:6']);
        $grants->verifyIdentity($token,(string)$data['verification_code'],$request);
        return redirect()->route('crm.portal.show',$token)->with('status','Customer identity verified for this secure session.');
    }

    public function accept(Request $request,string $token,CrmPortalGrantService $grants,CrmCompanyContextResolver $contexts,CrmCompanyScope $scope)
    {
        $grant=$grants->resolve($token,$request); $grants->requireVerifiedSession($grant,$request); abort_unless($grants->allows($grant,'sales.accept'),403);
        $type=(string)($grant['document_type']??''); abort_unless(in_array($type,['proposal','estimate'],true),422,'Only proposals and estimates can be accepted in the CRM portal.');
        $trusted=$contexts->fromTrustedPlatform((int)$grant['company_id'],(int)$grant['user_id'],'customer',permissions:['crm.sales.manage'],sourceSurface:'customer_portal',membershipVerified:true);
        $envelope=$scope->runWith($trusted,fn()=>$this->commands->request('crm.quote.approve',[
            'type'=>$type.'s','public_id'=>(string)$grant['document_public_id'],
            'idempotency_key'=>'portal:accept:'.(string)$grant['public_id'].':'.(string)$grant['document_public_id'],
            'portal_grant_public_id'=>(string)$grant['public_id'],
            'accepted_via'=>'customer_portal',
            'accepted_actor_type'=>'customer',
            'accepted_actor_reference'=>$grant['contact_public_id']??$grant['company_public_id']??null,
            'acceptance_session_id'=>$request->hasSession()?$request->session()->getId():(string)$grant['public_id'],
            'customer_identity_reference'=>$grant['contact_public_id']??$grant['company_public_id']??null,
        ],'customer_portal'));
        if(($envelope['executed']??false)!==true||($envelope['authoritative']??false)!==true) throw new ServiceUnavailableHttpException(5,'Quote acceptance is awaiting governed execution.');
        return redirect()->route('crm.portal.show',$token)->with('status',ucfirst($type).' accepted.');
    }

    public function comment(Request $request,string $token,CrmPortalGrantService $grants,CrmCompanyContextResolver $contexts,CrmCompanyScope $scope)
    {
        $grant=$grants->resolve($token,$request); $grants->requireVerifiedSession($grant,$request); abort_unless($grants->allows($grant,'sales.comment'),403);$data=$request->validate(['body'=>'required|string|max:10000']);
        $trusted=$contexts->fromTrustedPlatform((int)$grant['company_id'],(int)$grant['user_id'],'customer',permissions:['crm.portal.manage'],sourceSurface:'customer_portal',membershipVerified:true);
        $envelope=$scope->runWith($trusted,fn()=>$this->commands->request('crm.portal.comment.create',[
            'portal_grant_public_id'=>(string)$grant['public_id'],'subject_type'=>$grant['document_type'],'subject_public_id'=>$grant['document_public_id'],
            'body'=>$data['body'],'author_type'=>'customer','idempotency_key'=>'portal:comment:'.hash('sha256',(string)$grant['public_id'].'|'.$data['body']),
        ],'customer_portal'));
        if(($envelope['executed']??false)!==true) throw new ServiceUnavailableHttpException(5,'Portal comment is awaiting governed execution.');
        return redirect()->route('crm.portal.show',$token)->with('status','Comment added.');
    }

    public function issue(Request $request,CrmPermissionService $permissions)
    {
        $permissions->authorize((int)$request->user()->id,'crm.portal.manage');
        $data=$request->validate(['label'=>'nullable|string|max:255','company_public_id'=>'nullable|string|size:26','contact_public_id'=>'nullable|string|size:26','document_type'=>'nullable|in:proposal,estimate,invoice','document_public_id'=>'nullable|string|size:26','scopes'=>'required|array|min:1','expires_at'=>'nullable|date|after:now']);
        $issued=$this->mutations->execute($request,'crm.portal.grant.create',$data);
        if($request->expectsJson()) return response()->json($issued,201);
        $url=route('crm.portal.show',$issued['token']);return redirect()->route('dashboard.user.crm.portal.index')->with('portal_url',$url)->with('portal_verification_code',$issued['verification_code']??null)->with('status','Customer Hub link created. Send the link and verification code through separate trusted channels.');
    }

    public function revoke(Request $request,string $grant,CrmPermissionService $permissions)
    { $permissions->authorize((int)$request->user()->id,'crm.portal.manage');$this->mutations->execute($request,'crm.portal.grant.revoke',['public_id'=>$grant]);return $request->expectsJson()?response()->json(['status'=>'revoked']):back()->with('status','Customer Hub link revoked.'); }

    private function salesTable(string $type): ?string { return match($type){'proposal'=>'crm_proposals','estimate'=>'crm_estimates','invoice'=>'crm_invoices',default=>null}; }
}
