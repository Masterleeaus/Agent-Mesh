# Titan Maps Intelligence v2.0 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Upgrade Titan Maps Intelligence from business/place discovery into Titan Zero's tenant-safe location, routing, geofencing, dispatch, territory, sourcing and geographic pricing engine for Field & Home while preserving the existing discovery/provenance core.

**Architecture:** Use modular expansion rather than a rewrite. Existing discovery, candidate governance, provenance, exports and WorkCore promotion remain intact; new Location, Routing, Geofence, Dispatch and Territory modules communicate through explicit provider and WorkCore contracts. WorkCore stays authoritative for jobs/workers/customers; Maps stores geographic state, observations, routes and derived intelligence keyed by company-scoped public IDs.

**Tech Stack:** PHP 8.3, Laravel 10.50.x, MySQL, Blade/JavaScript, queues, Laravel policies/gates, Titan capability/contribution registries, Titan Vault, Google Places/Routes/Geocoding initially behind provider-neutral interfaces.

## Global Constraints

- `company_id` is the mandatory tenant boundary for every tenant-owned record and queued operation.
- Do not create duplicate authoritative job, worker, customer, property or CRM records inside Maps.
- Preserve the existing discovery/provenance/candidate-governance subsystem and its public behaviors unless a migration is explicitly defined.
- Keep `extension.json` compatible with the live Titan Extension Manager (`schema: titan-extension-v1`); put advanced metadata in `extension.manifest.json`.
- Separate authenticated-user, admin and internal/API route security profiles.
- Do not patch MagicAI core menus directly; register menu contributions.
- Provider credentials resolve through Titan Vault/SecretResolver and are never stored or logged in plaintext.
- External provider errors must fail explicitly; never label straight-line estimates as road distance or live traffic ETA.
- All queue jobs must restore and validate tenant context before touching tenant data.
- Lifecycle disable/uninstall must be idempotent and must never drop parent/shared WorkCore data.
- New features are test-first and each pass ends with a releasable/testable checkpoint.

---

## File/Module Map

### Preserve and extend
- `Services/DiscoverySearchService.php` — existing place/business discovery orchestration.
- `Services/ProvenanceService.php` — source/evidence lineage.
- `Services/CandidateMatchingService.php` — WorkCore duplicate/match scoring.
- `Services/CandidatePromotionService.php` — governed WorkCore promotion.
- `Providers/GooglePlacesProvider.php` — existing Google Places implementation.
- `Providers/PlacesProviderRegistry.php` — provider registry pattern reused for routing/geocoding.
- `TitanMapsIntelligenceServiceProvider.php` — refactor into registration orchestration without becoming a monolith.

### New bounded modules
- `Contracts/GeocodingProvider.php`
- `Contracts/RoutingProvider.php`
- `Contracts/TrafficProvider.php`
- `Contracts/FieldReferenceGateway.php`
- `Contracts/MenuContributionRegistrar.php`
- `DTO/RouteRequest.php`, `DTO/RouteResult.php`, `DTO/TravelMatrixRequest.php`, `DTO/TravelMatrixResult.php`
- `Models/MapLocation.php`, `LocationPing.php`, `Geofence.php`, `GeofenceEvent.php`
- `Models/MapRoute.php`, `RouteStop.php`, `RouteSnapshot.php`, `TravelMatrix.php`, `EtaSnapshot.php`
- `Models/ServiceTerritory.php`, `TerritoryRule.php`, `TravelZone.php`
- `Models/DispatchRecommendation.php`, `DispatchScore.php`
- `Services/Location/`, `Services/Geofencing/`, `Services/Routing/`, `Services/Dispatch/`, `Services/Territory/`
- `Providers/Google/GoogleGeocodingProvider.php`, `GoogleRoutingProvider.php`, `GoogleTrafficProvider.php`
- `Http/Controllers/User/`, `Http/Controllers/Admin/`, `Http/Controllers/Api/`
- `routes/user.php`, `routes/admin.php`, `routes/api.php`, `routes/internal.php`
- `Navigation/User/`, `Navigation/Admin/`
- `resources/views/user/`, `resources/views/admin/`, `resources/js/maps/`
- `database/migrations/`
- `tests/Feature/`, `tests/Unit/`, `tests/Integration/`, `tests/Architecture/`

---

## Pass 1 — Harden package contract and baseline

**Deliverable:** A blueprint-valid v2 package skeleton that still boots the existing discovery engine.

- [x] Snapshot current file inventory and PHP syntax status.
- [x] Use the Titan Extension Manager `titan-extension-v1` primary manifest; retain advanced metadata in the sidecar.
- [x] Create `extension.manifest.json` containing provider identity, compatibility, dependencies, capabilities, contributions, route profiles, migrations, queues, permissions, owned data and lifecycle declarations.
- [x] Add `CHANGELOG.md`, `SECURITY.md`, release metadata and package verification scripts expected by the blueprint.
- [x] Move/alias the provider to the exact manifest-declared namespace/folder if needed without breaking existing namespace references.
- [x] Add architecture tests validating both manifests and declared-file existence.
- [x] Run blueprint `validate_manifest.py --check-files`, PHP syntax scan and current conformance suite.

**Gate:** Existing discovery code loads; both manifests validate; no missing declared files.

## Pass 2 — Real migrations for the existing Maps domain

**Deliverable:** Existing 13 models have forward-only, company-scoped database migrations.

- [x] Write failing migration/schema tests for each current model/table.
- [x] Add migrations for provider connections, searches, runs, places, contacts, observations, candidates, matches, promotions, suppressions, usage and territory analyses.
- [x] Add `company_id` indexes and composite indexes for common tenant queries.
- [x] Add unique keys for provider IDs/canonical identities that are scoped safely by company/provider.
- [x] Add migration smoke test on clean MySQL schema.
- [x] Add upgrade test from an empty extension state and document handling for any pre-existing manually created tables.

**Gate:** Migration source/schema contract passes locally. The packaged MySQL host smoke test verifies `php artisan migrate` plus CRUD for all persistent models when run in a disposable MagicAI MySQL test host; that runtime is not present in the archive-only build environment.

## Pass 3 — Tenant, permission and route-security hardening

**Deliverable:** All existing and future Maps entry points enforce company context and explicit permissions.

- [x] Split routes into authenticated user, admin, API and internal profiles.
- [x] Keep API routes under `auth:sanctum` + `titan.company`; add capability/permission checks per action.
- [x] Add user routes under `web`, `auth`, company context and policy/capability middleware.
- [x] Add admin routes under `web`, `auth`, `admin` plus explicit Maps admin authorization.
- [x] Add route-model binding that rejects cross-company IDs.
- [x] Add feature tests for spoofed `company_id`, cross-tenant model IDs, denied permissions and admin isolation.

**Gate:** Cross-company read/write attempts fail closed across controllers, policies and queues.

## Pass 4 — Configuration and algorithm correctness

**Deliverable:** Ranking/matching/limits actually honor extension configuration.

- [x] Add tests proving ranking weights come from `config/titan_maps_intelligence.php`.
- [x] Remove hardcoded ranking weights from `ProviderRankingService`.
- [x] Move matching thresholds/weights into validated config and inject them into `CandidateMatchingService`.
- [x] Validate result caps, provider timeouts, retries and distance thresholds at boot/settings save.
- [x] Add config-version metadata so later changes are auditable.

**Gate:** Changing configured weights/thresholds changes deterministic test results without code edits.

## Pass 5 — Provider-neutral geocoding, routing and traffic contracts

**Deliverable:** Stable interfaces exist before operational features depend on any one map vendor.

- [x] Define `GeocodingProvider`, `RoutingProvider` and `TrafficProvider` contracts plus typed DTOs.
- [x] Create provider registries mirroring `PlacesProviderRegistry`.
- [x] Implement Google geocoding adapter.
- [x] Implement Google Routes adapter for point-to-point routes and route matrices.
- [x] Implement traffic-aware duration handling where provider data supports it.
- [x] Record provider usage/cost units through existing `ProviderUsageService`.
- [x] Add fake providers for deterministic tests.

**Gate:** A test can swap Google for a fake provider without changing routing/domain services.

## Pass 6 — Canonical location/reference domain

**Deliverable:** Jobs, properties, branches, workers and suppliers can be located without duplicating WorkCore records.

- [x] Create `MapLocation` migration/model with `company_id`, reference type, public reference ID, coordinates, source, precision and timestamps.
- [x] Define `FieldReferenceGateway` for resolving authorized WorkCore job/worker/property/branch references.
- [x] Add geocode-and-cache service for postal addresses.
- [x] Add reverse-geocode support as optional metadata, not authoritative customer data.
- [x] Add stale-location refresh rules.
- [x] Add tests proving deleted/foreign WorkCore references cannot be attached to a tenant's map location.

**Gate:** Maps can resolve a WorkCore job/property to a company-scoped coordinate without copying the full WorkCore entity.

## Pass 7 — Worker live-location ingestion

**Deliverable:** Titan Go/PWA can safely publish current on-duty worker positions.

- [x] Add `maps_location_pings` and latest-position storage/indexing.
- [x] Create authenticated location ingestion endpoint accepting worker reference, lat/lng, accuracy, captured-at and optional motion metadata.
- [x] Resolve the authenticated worker/company server-side; reject client-supplied tenant switching.
- [x] Add on-duty/off-duty and tracking-permission checks.
- [x] Add retention policy and pruning command/job.
- [x] Add rate/debounce rules to prevent excessive GPS writes.
- [x] Add tests for stale timestamps, impossible coordinates, off-duty writes, cross-tenant worker references and retention.

**Gate:** An authorized on-duty worker can update location; unauthorized/off-duty/cross-company writes fail.

## Pass 8 — Graphical map engine

**Deliverable:** Titan Maps renders actual interactive maps before geofence/dispatch automation is layered on top.

- [x] Add extension-owned graphical slippy-map renderer with configurable raster tiles and attribution.
- [x] Add pan/zoom/fit controls, markers/popups, polylines, polygons and circles.
- [x] Render canonical locations and discovery candidates on real maps.
- [x] Add live Team Map refresh and worker GPS trail rendering.
- [x] Render territory/search overlays.
- [x] Expose the existing routing provider through a graphical Route Calculator and draw provider polylines.
- [x] Rename Field Operations Overview to Live Map and resync installed menus.
- [x] Add map asset/security/configuration verification.

**Gate:** Installed browser pages contain a genuine interactive map canvas backed by tenant-scoped data, not placeholder cards/tables.

## Pass 9 — Native geofence engine

**Deliverable:** Radius and polygon geofences generate reliable entry/exit/dwell events on top of the graphical map engine.

- [x] Add `maps_geofences` and `maps_geofence_events` migrations/models.
- [x] Implement radius containment service using geodesic distance.
- [x] Implement polygon point-in-polygon containment.
- [x] Add hysteresis/debounce to avoid GPS jitter creating repeated entry/exit events.
- [x] Add job/property/branch/custom geofence types.
- [x] Emit `WorkerEnteredJobGeofence`, `WorkerExitedJobGeofence`, `WorkerArrivedAtJob`, `WorkerDepartedJob`, `GeofenceDwellThresholdReached`.
- [x] Add graphical circle/polygon drawing/editing on the Pass-8 map engine.
- [x] Add configurable arrival confirmation instead of silently starting jobs by default.
- [x] Add privacy/audit records for geofence-derived actions.

**Gate:** Simulated GPS traces produce exactly one expected enter/arrival/exit sequence despite boundary jitter, and geofences can be edited visually.

## Pass 10 — Point-to-point routing, road distance and ETA

**Deliverable:** Maps returns honest road distance and ETA with provenance/freshness.

- [x] Add route/ETA DTO tests for normal, traffic-aware, unavailable and stale cases.
- [x] Create route calculation service using `RoutingProvider`.
- [x] Persist optional `RouteSnapshot`/`EtaSnapshot` records with provider, calculated-at and traffic basis.
- [x] Preserve Haversine as explicit `straight_line_estimate`, never as `road_distance`.
- [x] Add fallback policy: last-valid route snapshot or clearly labeled straight-line estimate.
- [x] Add route API endpoints and capability permissions.

**Gate:** Road distance/ETA is provider-derived or explicitly marked as estimated/stale; fabricated live ETA is impossible.

## Pass 11 — Travel matrix and nearest-resource engine

**Deliverable:** Titan can rank workers, contractors and suppliers by actual travel cost/time.

- [x] Add matrix request/result DTOs and persistence/cache strategy.
- [x] Implement multi-origin/multi-destination matrix calls with provider-safe element limits.
- [x] Add nearest-worker query constrained by company and duty/tracking status; apply service-territory eligibility once Pass 14 provides authoritative territory membership evidence.
- [x] Add nearest-supplier/contractor enrichment for canonical resources and approved Discovery candidates.
- [x] Cache matrices by coordinate signature/time window while respecting traffic freshness.
- [x] Add provider quota/cost safeguards and pre-provider limits for 625-element normal matrices and 100-element optimal/transit matrices.

**Gate:** Given multiple origins/resources, Titan returns deterministic ranked travel results with provider usage metering.

## Pass 12 — Multi-stop route planning and optimisation

**Deliverable:** A worker's day can be sequenced subject to time windows and locked stops.

- [x] Add `maps_route_plans`, `maps_route_plan_stops`, `maps_route_plan_runs` migrations/models alongside existing durable route snapshots.
- [x] Model stop types: job, depot, supplier, contractor, break and custom.
- [x] Support fixed/locked stop order and appointment windows with explicit conflict reporting.
- [x] Use provider route-matrix travel costs when available; sequencing remains constraint-aware and provider-neutral rather than pretending waypoint-order APIs understand Titan appointment locks.
- [x] Add deterministic locked-stop/time-window heuristic with straight-line distance fallback only when matrix ETA is unavailable.
- [x] Recalculate route after stop completion/cancellation/emergency insertion and persist revision triggers.
- [x] Persist before/after distance/time metrics, savings, schedule, violations, matrix provenance and optional segment route-snapshot geometry.

**Gate:** Route optimizer never moves locked appointments outside constraints and can explain changed stop order.

## Pass 13 — Dispatch Intelligence Engine

**Deliverable:** Titan recommends the best worker, not merely the nearest worker.

- [x] Add `maps_dispatch_recommendations`, `maps_dispatch_candidates` and `maps_dispatch_decisions` migrations/models.
- [x] Define scoring inputs: skill match, certification, availability, ETA, territory, workload, urgency suitability and continuity/history.
- [x] Fetch authoritative skill/availability/workload data through tenant-verified optional CRM/host evidence adapters.
- [x] Make score weights configuration-driven with validated totals of exactly 100.
- [x] Store factor-by-factor explanations for every recommendation.
- [x] Add human approval/assignment handoff rather than direct silent assignment by default.
- [x] Add tests where closest worker is correctly not selected due to skill/certification constraints.

**Gate:** Recommendations are explainable, company-scoped and respect hard eligibility constraints before soft scoring.

## Pass 14 — Service territories and geographic pricing signals

**Deliverable:** Companies can define service areas and send distance/drive-time pricing inputs to the quoting engine.

- [x] Add service territory, persisted territory evaluation and geographic pricing signal models/migrations.
- [x] Support radius, polygon, postcode/suburb list and branch-centered territories.
- [x] Add inclusion/exclusion and priority rules.
- [x] Implement travel zone lookup by provider-derived road distance and/or drive time, never straight-line substitution.
- [x] Expose neutral coverage/travel/zone/pricing-hint signals without calculating or applying final quote dollars inside Maps.
- [x] Add `GeographicPricingSignalProvider` contract for CRM/quoting-engine consumption.

**Gate:** A job location resolves to the correct service territory/travel zone and produces a stable pricing signal.

## Pass 15 — Real territory analytics

**Deliverable:** Existing territory analysis modes become genuinely distinct engines.

- [x] Split `TerritoryAnalysisService` into coverage, competitor-density, supplier-coverage and service-gap analyzers.
- [x] Calculate provider coverage by geographic cells/territories.
- [x] Calculate competitor density with explicit area denominator.
- [x] Calculate supplier access using travel-time bands.
- [x] Define service-gap score from demand/job concentration plus internal/provider coverage, without inventing demand where WorkCore data is absent.
- [x] Add expansion-opportunity analysis using configurable inputs.
- [x] Store analysis methodology/version with results.

**Gate:** Selecting different analysis modes produces methodologically distinct outputs with tested formulas.

## Pass 16 — Contractor/supplier fallback workflows

**Deliverable:** No-resource situations can flow from WorkCore to Maps Discovery and back under human governance.

- [x] Add service that first queries approved internal/contractor network.
- [x] If none qualify, invoke existing Maps business discovery with job location, category, radius and open-now constraints.
- [x] Enrich discovery candidates with travel ETA/distance.
- [x] Reuse candidate match/approve/promote workflow before operational use.
- [x] Add supplier workflow that can accept Titan Gear inventory shortages and locate nearby suppliers.
- [x] Add audit events tying the operational need to discovery/promotion lineage.

**Gate:** Missing plumber/supplier scenario can produce governed candidates without auto-creating CRM/provider records.

## Pass 17 — Governed spatial intelligence integration

**Deliverable:** Existing Maps capabilities participate in the new Titan governed-engine architecture without duplicating engine ownership or breaking alpha.16 compatibility.

- [x] Preserve all 31 existing capability IDs and add canonical `location.geocode`, `territory.lookup`, `territory.validate`, `route.estimate`, `route.compare`, `job.travel_context`, `service_area.check` and `nearby.search` handlers.
- [x] Declare owner, input/output contract, risk, autonomy, evidence, offline policy, reversibility and idempotency for every exposed capability.
- [x] Add server-derived tenant execution context with trace/correlation/causation propagation and structured decision receipts.
- [x] Add optional host-portable gateways for Risk, Assurance, Autonomy, Command Bus, Signal, Rewind and Knowledge Authority without installer-time hard dependencies.
- [x] Fail closed for consequential AI/system mutation when required governance is denied/unavailable; offline authority never increases.
- [x] Move authoritative CRM job assignment behind Command Bus and govern AI promotion/decision paths.
- [x] Emit structured spatial Signals for capability lifecycle, route failures/fallbacks, territory conflicts/exclusions and worker-location anomalies.
- [x] Add Titan Go offline capability-policy manifest without exposing provider secrets or handler internals.

**Gate:** Maps installs without optional engines, never fabricates governance approval, and consequential AI/cross-extension mutation is traceable and Command-Bus bounded.

## Pass 18 — Advanced operational map UI and dispatch pages

**Deliverable:** Expand the Pass-8 graphical foundation into full dispatch, route and geofence operational workspaces under the Pass-17 governed capability layer.

- [x] Live Map graphical foundation exists from Pass 8; add toggleable operational layers for jobs, routes, geofences, suppliers and contractors.
- [x] Dispatch Intelligence page exists with ranked recommendation evidence; harden richer drawer/layer interactions.
- [ ] Build consolidated Routes & ETA daily workspace with route-plan revisions and recalculation actions.
- [x] Geofences page/editor supports radius/polygon graphical boundaries.
- [x] Business Discovery/Candidates graphical map foundations exist; add filtering, clustering and workflow actions.
- [x] Territory graphical overlays and real persisted analytics cells exist; refine service-gap/density visualizations.
- [ ] Add mobile-responsive controls and accessible non-map list/table fallbacks across every operational map workflow.

**Gate:** Core workflows remain usable on desktop/mobile, accessible without a map, and action-taking UI invokes governed capabilities rather than hidden direct mutations.

## Pass 19 — Complete menus, settings and admin navigation

**Deliverable:** Extend the working MagicAI menu sync with complete company settings and operational administration.

- [x] Field Operations, Location Intelligence, Territory and Travel/Routing parent menus and current real child pages exist.
- [ ] Complete company Settings > Maps & Location children: Providers, Google Maps/Places, Routing, Location Tracking, Geofences, Dispatch Rules, Travel Zones, Privacy & Retention, Usage & Limits.
- [ ] Complete Super Admin `Titan Maps Intelligence`: Dashboard, Provider Health, Companies, Provider Connections, API Usage/Costs, Routing Usage, Queue Health, Failed Requests, Global Limits, Location Policies, Retention Defaults, Permissions, Diagnostics.
- [x] Adaptive extension-owned `menus` table synchronization and cache regeneration remains installer-safe without MagicAI core sidebar edits.
- [ ] Hide children when the user lacks permission/capability and preserve correct active/open parent state.

**Gate:** Menu tests prove every contributed route exists, inaccessible items are hidden and uninstall/disable handles contributions safely.

## Pass 20 — Capability and AI interaction refinement

**Deliverable:** Titan AI/Workforce/Interaction surfaces consume the 39-capability governed spatial contract consistently.

- [x] Preserve all legacy Maps tools and the eight canonical spatial capability IDs.
- [x] Register complete structured input/output schemas and governance metadata.
- [x] Reject tool-provided tenant/company overrides and propagate trace/correlation/causation data.
- [ ] Add example Workforce/Interaction usage contracts for “who should I send?”, “optimize tomorrow”, “find emergency supplier”, and jurisdiction-aware job travel context.
- [ ] Add explicit UI/explanation mapping from canonical capabilities to legacy compatibility IDs for diagnostics/admin support.
- [ ] Validate selective Assurance/Risk/Autonomy integration against the live engine contract versions when those engines are installed.

**Gate:** Titan AI and Workforce can consume canonical spatial intelligence without bypassing tenant, Risk, Autonomy or Command Bus boundaries.

## Pass 21 — Operations, queues, observability and lifecycle

**Deliverable:** The extension is operable and safe under retries, provider outages, disable and uninstall, while integrating with Titan Signal/Support/Governance.

- [ ] Add/confirm named queues for discovery, geofence evaluation, route refresh and analytics with mandatory tenant restoration.
- [ ] Add idempotency keys to remaining retryable location/geofence/provider jobs.
- [ ] Add provider health, failure/rate-limit, queue-health and governed-capability metrics for admin diagnostics.
- [ ] Expand usage metering to all geocoding/routes/matrices/traffic calls and expose Signal-compatible operational anomalies.
- [ ] Implement extension disable behavior that stops new work while preserving data and critical dependency safety.
- [ ] Implement idempotent uninstall phases and selectable retain/anonymise/delete policy for extension-owned data only.
- [ ] Ensure shared CRM/WorkCore references/data are never deleted.

**Gate:** Repeated disable/uninstall operations do not error; retried work does not duplicate events/actions; diagnostics consume the same structured Signal model.

## Pass 22 — Full verification, packaging and installer-ready release

**Deliverable:** `TitanMapsIntelligence-v2.0.0-Titan-Installer-Ready.zip`.

- [ ] Run unit, feature, integration, migration, governance, queue and lifecycle suites.
- [ ] Run full PHP/JavaScript/JSON syntax scans and package integrity verification.
- [ ] Validate the hardened sidecar schema separately while preserving the live `titan-extension-v1` root installer contract.
- [ ] Verify ZIP path safety: `/` separators, no `__MACOSX`, `.DS_Store`, `.env`, `.git`, `node_modules`, traversal or absolute paths.
- [ ] Verify provider namespace/path/case exactly matches Titan installer expectations.
- [ ] Test clean install, boot, migrate, enable, user menus, super-admin menus, optional-engine presence/absence, disable and repeated uninstall on the live target host.
- [ ] Generate final build/migration/route/capability/menu inventories and SHA-256.
- [ ] Package final installer-ready ZIP and preserve pre-upgrade source archive.

**Gate:** Clean Titan installation completes and every declared capability/route/migration/menu/governance contract passes hardened and live-host validation.

---

## Release Milestones

- **Milestone A — Installer-safe Maps Core:** Passes 1–4
- **Milestone B — Field Location + Graphical Maps:** Passes 5–9
- **Milestone C — Routing & Dispatch:** Passes 10–13
- **Milestone D — Territory & Sourcing:** Passes 14–16
- **Milestone E — Governed Spatial Product:** Passes 17–20
- **Milestone F — Production Operations & Release:** Passes 21–22

## Final v2 Capability Set

Titan Maps Intelligence v2.0 will provide one coherent governed spatial-intelligence service for business/place discovery, live worker location, job/property geography, service areas, geofences, routing/ETA/matrices, route planning, dispatch recommendations, territories, geographic pricing signals, sourcing fallback, geographic analytics and interactive maps. CRM remains authoritative for business/job/customer truth; Maps supplies spatial evidence through traceable canonical capabilities and uses Titan Signal, Risk, Assurance, Autonomy, Command Bus, Knowledge Authority and Rewind through explicit adapters rather than duplicating those engines.
