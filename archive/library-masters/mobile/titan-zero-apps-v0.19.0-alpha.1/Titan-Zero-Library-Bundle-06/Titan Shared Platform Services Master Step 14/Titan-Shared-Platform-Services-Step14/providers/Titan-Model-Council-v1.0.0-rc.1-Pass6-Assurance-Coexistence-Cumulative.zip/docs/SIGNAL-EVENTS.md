# Signal Events

Council lifecycle events are tenant-scoped, causally linked, redacted and emitted through the current Signal v0.20 trusted-emitter contract when available.

Every event carries:

- `tenant_company_id`
- `trace_id`
- `correlation_id`
- `causation_id`
- `root_causation_id`

Secrets, API keys, authorization headers and provider credentials are forbidden.

Events:

- `council.activation.decided` — deterministic/Risk-aware activation result.
- `council.deliberation.started` — governed or parallel deliberation begins.
- `council.deliberation.completed` — advisory decision reached without mandatory escalation.
- `council.deliberation.escalated` — Risk, contradiction, Assurance or validation requires escalation/reduced authority.
- `council.deliberation.failed` — terminal deliberation failure.

Terminal governed events may include `receipt_id` and `receipt_hash`, allowing downstream Rewind/observability systems to correlate against the immutable-style Council receipt without receiving participant hidden reasoning.

Schemas live under `schemas/events/`.
