# Titan AI Runtime 1.5.3 — Workforce Compatibility Release

## Purpose

Titan AI Workforce requires `titan-ai >=1.5.3`, while the supplied Titan AI Runtime package identified itself as `1.5.2`. A source-level contract audit found that the 1.5.2 runtime already exposes the complete Workforce-facing runtime seam used by the compatibility adapter.

## Compatibility decision

Version 1.5.3 is therefore a compatibility/provenance release, not a runtime rewrite. The package version is raised to 1.5.3 without lowering Workforce's dependency requirement and without changing Titan AI's PHP runtime behavior.

The following contracts are preserved:

- `TitanAIRuntimeContract::execute(TitanAIRequest): TitanAIResponse`
- `TitanAIRuntimeContract::stream(TitanAIRequest, callable): TitanAIResponse`
- Workforce request context fields: company, workflow, idempotency, response mode, tool permissions and AI actor identity
- `TitanAIResponse::toArray()` including `run_uuid`
- `ProviderRegistry` and `ProviderExecutionRegistry`
- `AssistantDeploymentResolverContract` and trusted provider/model resolution
- `UnifiedTitanAIRuntime` binding through `TitanAIRuntimeServiceProvider`

## Runtime preservation

All 330 supplied non-test PHP files are pinned to their 1.5.2 SHA-256 hashes in `tests/fixtures/titan-ai-1.5.2-php-sha256.json`. The 1.5.3 package verification fails if any of those PHP files changes.

No provider endpoint, model selection behavior, tool authority, governance rule, tenant boundary or business execution path is weakened by this release.

## Workforce contract

The machine-readable declaration is `resources/runtime-compatibility.json`. It documents the Titan AI runtime, provider and model contracts and the `titan.agent-runtime/1` Workforce adapter protocol.
