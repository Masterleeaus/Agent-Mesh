<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('interaction_answers') && !Schema::hasColumn('interaction_answers', 'tenant_id')) {
            Schema::table('interaction_answers', function (Blueprint $table): void {
                $table->string('tenant_id', 191)->nullable()->after('id')->index();
                $table->index(['tenant_id', 'run_id'], 'interaction_answers_tenant_run_idx');
            });
        }
        if (Schema::hasTable('interaction_events') && !Schema::hasColumn('interaction_events', 'tenant_id')) {
            Schema::table('interaction_events', function (Blueprint $table): void {
                $table->string('tenant_id', 191)->nullable()->after('id')->index();
                $table->index(['tenant_id', 'run_id', 'event_type'], 'interaction_events_tenant_run_type_idx');
            });
        }
    }

    public function down(): void
    {
        // Forward-only: tenant ownership metadata is never removed automatically.
    }
};
