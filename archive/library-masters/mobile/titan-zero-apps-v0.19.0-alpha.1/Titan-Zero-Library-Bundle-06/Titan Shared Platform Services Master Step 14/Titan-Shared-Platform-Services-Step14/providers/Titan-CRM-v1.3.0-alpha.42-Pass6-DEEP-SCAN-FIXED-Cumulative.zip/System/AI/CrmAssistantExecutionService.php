<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\AI;

use App\Extensions\Crm\System\Contracts\{
    ActivityRepositoryContract, CalendarRepositoryContract, CompanyRepositoryContract, ContactRepositoryContract,
    DealRepositoryContract, LeadRepositoryContract, NoteRepositoryContract, PipelineRepositoryContract,
    ProjectRepositoryContract, SalesDocumentRepositoryContract, TaskRepositoryContract
};
use App\Extensions\Crm\System\Services\{CrmAnalyticsService, CrmDashboardService, CrmDuplicateDetector, CrmForecastService, CrmTimelineService};
use App\Extensions\Crm\System\Security\CrmPermissionService;
use App\Extensions\Crm\System\Domains\CommercialCalculations\CommercialCalculationService;
use App\Extensions\Crm\System\Governance\CrmCommandBusGateway;
use InvalidArgumentException;

final class CrmAssistantExecutionService
{
    public function __construct(
        private CompanyRepositoryContract $companies,
        private ContactRepositoryContract $contacts,
        private LeadRepositoryContract $leads,
        private DealRepositoryContract $deals,
        private PipelineRepositoryContract $pipelines,
        private ActivityRepositoryContract $activities,
        private NoteRepositoryContract $notes,
        private ProjectRepositoryContract $projects,
        private TaskRepositoryContract $tasks,
        private CalendarRepositoryContract $calendar,
        private SalesDocumentRepositoryContract $sales,
        private CrmDashboardService $dashboard,
        private CrmAnalyticsService $analytics,
        private CrmTimelineService $timeline,
        private CrmForecastService $forecast,
        private CrmDuplicateDetector $duplicates,
        private CrmPermissionService $permissions,
        private CommercialCalculationService $commercial,
        private CrmCommandBusGateway $commands,
    ) {}

    public function execute(int $userId, string $tool, array $arguments = []): array
    {
        $this->permissions->authorizeTool($userId, $tool);
        return match ($tool) {
            'crm_search_contacts' => ['data' => $this->contacts->search($userId, $arguments)],
            'crm_search_companies' => ['data' => $this->companies->search($userId, $arguments)],
            'crm_search_leads' => ['data' => $this->leads->search($userId, $arguments)],
            'crm_list_pipelines' => ['data' => $this->pipelines->list($userId)],
            'crm_view_pipeline_board' => ['data' => $this->pipelines->board($userId, $this->required($arguments, 'pipeline_public_id'))],
            'crm_search_deals' => ['data' => $this->deals->search($userId, $arguments)],
            'crm_list_activities' => ['data' => $this->activities->forSubject($userId, $this->required($arguments, 'subject_type'), $this->required($arguments, 'subject_public_id'), (int) ($arguments['limit'] ?? 100))],
            'crm_get_dashboard' => ['data' => $this->dashboard->summary($userId)],
            'crm_get_analytics' => ['data' => $this->analytics->snapshot($userId)],
            'crm_get_timeline' => ['data' => $this->timeline->forSubject($userId, $this->required($arguments, 'subject_type'), $this->required($arguments, 'subject_public_id'), (int) ($arguments['limit'] ?? 100))],
            'crm_search_projects' => ['data' => $this->projects->search($userId, $arguments)],
            'crm_search_tasks' => ['data' => $this->tasks->search($userId, $arguments)],
            'crm_search_calendar' => ['data' => $this->calendar->search($userId, $arguments)],
            'crm_search_sales_documents' => ['data' => $this->sales->search($userId, $this->required($arguments, 'type'), $arguments)],
            'crm_get_follow_ups' => ['data' => $this->leads->search($userId, ['follow_up_due'=>true,'limit'=>(int)($arguments['limit']??100)])],
            'crm_get_forecast' => ['data' => $this->forecast->summarize($userId)],
            'crm_find_duplicates' => ['data' => $this->duplicateCandidates($userId,$arguments)],
            'crm_get_source_conversion' => ['data' => $this->analytics->sourceConversion($userId)],
            'crm_get_stale_pipeline' => ['data' => $this->analytics->stalePipeline($userId,(int)($arguments['days']??14))],
            'crm_finance_formula_rules_calculate' => ['data' => $this->commercial->calculate($userId, 'formula_rules', (array) ($arguments['inputs'] ?? $arguments), (array) ($arguments['context'] ?? []))],
            'crm_finance_pricing_calculate' => ['data' => $this->commercial->calculate($userId, 'pricing', (array) ($arguments['inputs'] ?? $arguments), (array) ($arguments['context'] ?? []))],
            'crm_finance_quote_estimate_calculate' => ['data' => $this->commercial->calculate($userId, 'quote_estimate', (array) ($arguments['inputs'] ?? $arguments), (array) ($arguments['context'] ?? []))],
            'crm_finance_discount_promotion_calculate' => ['data' => $this->commercial->calculate($userId, 'discount_promotion', (array) ($arguments['inputs'] ?? $arguments), (array) ($arguments['context'] ?? []))],
            'crm_finance_margin_profitability_calculate' => ['data' => $this->commercial->calculate($userId, 'margin_profitability', (array) ($arguments['inputs'] ?? $arguments), (array) ($arguments['context'] ?? []))],
            'crm_finance_tax_calculate' => ['data' => $this->commercial->calculate($userId, 'tax', (array) ($arguments['inputs'] ?? $arguments), (array) ($arguments['context'] ?? []))],
            'crm_create_company' => ['data' => $this->commands->request('crm.company.create',$arguments,'ai')],
            'crm_create_contact' => ['data' => $this->commands->request('crm.contact.create',$arguments,'ai')],
            'crm_create_lead' => ['data' => $this->commands->request('crm.lead.create',$arguments,'ai')],
            'crm_create_deal' => ['data' => $this->commands->request('crm.deal.create',$arguments,'ai')],
            'crm_move_deal' => ['data' => $this->commands->request('crm.deal.move',$arguments+['public_id'=>$this->required($arguments,'deal_public_id')],'ai')],
            'crm_record_activity' => ['data' => $this->commands->request('crm.activity.create',$arguments,'ai')],
            'crm_create_note' => ['data' => $this->commands->request('crm.note.create',$arguments,'ai')],
            'crm_create_project' => ['data' => $this->commands->request('crm.project.create',$arguments,'ai')],
            'crm_create_task' => ['data' => $this->commands->request('crm.task.create',$arguments,'ai')],
            'crm_create_calendar_event' => ['data' => $this->commands->request('crm.calendar.create',$arguments,'ai')],
            default => throw new InvalidArgumentException("CRM assistant tool [{$tool}] is not allowlisted."),
        };
    }

    private function duplicateCandidates(int $userId,array $arguments): array
    { $resource=(string)($arguments['resource']??'contact'); $email=$arguments['email']??null; $phone=$arguments['phone']??null; return match($resource){'company'=>$this->duplicates->companyCandidates($userId,$email,$phone),'lead'=>$this->duplicates->leadCandidates($userId,$email,$phone),default=>$this->duplicates->contactCandidates($userId,$email,$phone)}; }

    private function required(array $arguments, string $key): string
    {
        $value = trim((string) ($arguments[$key] ?? ''));
        if ($value === '') throw new InvalidArgumentException("CRM assistant argument [{$key}] is required.");
        return $value;
    }
}
