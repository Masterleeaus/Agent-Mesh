# Pass 5 Verification — Production Hardening & Certification

Pass 5 is the final planned hardening pass for the five-pass Titan People handoff.

## Hardening changes

- Durable Signal outbox has a registered `titan-people:dispatch-outbox` command and an every-minute schedule protected by `withoutOverlapping(5)` and `onOneServer()`.
- Outbox publish/failure mutations are scoped by both `tenant_company_id` and `event_id`.
- Dispatch batch size is configurable and hard-bounded to 250.
- Private HR document storage rejects every path outside `private/titan-people/` on write, read and existence checks.
- Upgrade, uninstall, operations and disaster-recovery procedures are explicit for the alpha.4 → rc.1 transition.
- Production source remains free of process execution/debug helpers/state-changing GET routes.

## Certification truth

Package/static certification can be performed in this build environment. Exact-host INSTALLER, MIGRATION, BOOT, NAVIGATION, AUTHORIZATION, RUNTIME, UPGRADE and UNINSTALL stages require a mounted MagicAI 10.91 / Laravel 10 / Installer 1.7.8 host and must remain `NOT_RUN` when that host is absent.
