## 0.1.0-rc.2 — Post-RC wiring remediation
- Functional tenant-scoped Payroll workspaces, Workforce host discovery, Signal outbox delivery, manifest cross-validation, and dead-code cleanup.

# Changelog

## 0.1.0-alpha.3
- Pass 3 reconciliation and variance records with immutable tenant/run/source provenance and governed resolution proposals; no automatic monetary correction.
- Added versioned compliance/tax rule-set boundary with effective-date resolution and fail-closed unknown jurisdictions; configured validations are explicitly not legal certification.
- Added deterministic payroll forecast scenarios with bounded horizons and explicit assumptions/uncertainty.
- Completed Workforce role/tool/workflow/wizard wiring; all state-writing tools use Command Bus and high-impact actions retain human/Risk/Assurance gates.
- Added privacy-minimized idempotent Payroll Signal outbox and Rewind source projection/watermarks.
- Added accounting export and payment-instruction output ports with explicit local-preparation versus external-transmission semantics.
- Added typed Communications consumer behavior and functional browser workspaces for Overview, Pay Runs, Time Inputs, Payslips, Approvals, Reconciliation, Reports and Settings.

## 0.1.0-alpha.2
- Pass 2 core payroll runtime: deterministic calculation snapshots, approved Time Attendance input boundary, governed/idempotent mutations, approval/finalization immutability, canonical payslip self-service, financial resilience and health.
- Added configured Command Bus, Risk and Assurance host adapters with fail-closed HIGH/CRITICAL payroll writes.
- Removed remaining direct notification provider side effects from donor runtime paths and strengthened sensitive-value redaction.
- Corrected canonical route metadata and expanded owned-table/health dependency declarations.

## 0.1.0-alpha.1
- Blueprint v4 Step 10 foundation, canonical tenant authority, navigation, Workforce v2 skeleton and Titan-owned migrations.
## 0.1.0-rc.1 — Pass 4 release hardening

- Removed unreachable Worksuite-era runtime/scaffolding and live donor activation coupling.
- Completed Titan Payroll operator, architecture, security, integration, Workforce and Installer documentation.
- Added Installer 1.7.8 package integrity verifier and hostless release verifier.
- Bounded finalized payslip materialization with 500-row chunking.
- Preserved/wired cleaning-payroll donor services behind canonical Titan contracts.
- Prepared RC supply-chain artifacts and exact-host certification handoff; no production-host certification claimed.

