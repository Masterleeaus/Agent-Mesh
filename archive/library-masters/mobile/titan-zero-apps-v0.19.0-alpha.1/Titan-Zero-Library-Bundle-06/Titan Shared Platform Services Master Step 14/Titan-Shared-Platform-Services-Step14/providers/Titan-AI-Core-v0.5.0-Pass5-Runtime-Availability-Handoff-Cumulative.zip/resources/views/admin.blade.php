@extends($hostLayout ?? 'titan-ai-core::layouts.standalone')

@section('title', 'Titan AI Core — Administration')

@section('content')
<div class="container-fluid">
    <div class="titan-ai-core-card">
        <h1>Titan AI Core — Administration</h1>
        <p>Runtime status and host-health diagnostics. Execution remains fail-closed in this foundation release.</p>
    </div>
    <div class="titan-ai-core-card">
        <h2>Runtime</h2>
        <pre>{{ json_encode($runtime, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) }}</pre>
    </div>
    <div class="titan-ai-core-card">
        <h2>Health</h2>
        <pre>{{ json_encode($health, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) }}</pre>
    </div>
</div>
@endsection
