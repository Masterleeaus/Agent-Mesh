# Archive Read & Cold-History Contract

Titan Signal Engine keeps the immutable hot event store and cold retention archives as separate storage tiers. Cold storage is not treated as a second mutable event database.

## Contracts

- `SignalArchiveStoreContract` owns portable archive object operations: write, verify, metadata, event read, bounded batch read and bounded iteration.
- `SignalArchiveCatalogContract` owns the database-side discovery index for archived events.
- `SignalHistoryQueryContract` is the governed retention-transparent read boundary for callers that need history regardless of storage tier.

Every cold read verifies the archive object's SHA-256 before returning an event. The archive driver (`laravel-storage:<disk>`) is stored with each catalog row so future changes to the default archive disk do not orphan older history.

## Privacy projections

Retention archives are created from the privacy-projected representation when redaction/correction overlays exist. Such a cold record has two distinct integrity statements:

1. `archive_verified=true` — the archived object matches its verified SHA-256.
2. `canonical_checksum_verified=false` — expected when privacy projection changed payload/metadata relative to the original immutable event checksum.

The original checksum is retained only as a forensic reference; cold reads never claim a redacted representation is byte-equivalent to the original event.

## Catalog

`titan_signal_archive_catalog` stores only discovery/reconstruction metadata: event, tenant/scope, type, trace/correlation/causation identifiers, timestamps, archive location/checksum/sequence, privacy-projection state and original checksum reference.

It does not duplicate full payloads.

## Upgrade recovery

Verified archives created before v0.13.0 can be catalogued with:

```text
titan:signal-archive:catalog --limit=100
```

The command re-verifies each archive and tenant/scope boundary before recording catalog entries. It does not restore archived events into the hot table.

## Hot/cold correlation in v0.15

Correlation now consumes `SignalHistoryTraversalContract` and treats the archive catalog as the durable cold causal tombstone. Ancestors, descendants, traces and workflows can cross the retention boundary. Mixed-tier results expose storage metadata and Rewind receipts. If a required archive is unavailable or fails SHA-256 verification, the result is explicitly partial rather than falsely complete.

## v0.14 streaming implementation

Archive reads now use Laravel `readStream()` plus incremental SHA-256 verification into bounded temporary storage, then gzip line iteration. Archive writes use incremental gzip output and stream upload. `verified_unpruned` batches are valid cold objects awaiting final hot-store deletion and may be resumed by the transactional pruning flow.
