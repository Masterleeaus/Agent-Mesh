<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_signal_types')) {
            return;
        }

        Schema::create('titan_signal_types', function (Blueprint $table): void {
            $table->id();
            $table->string('event_type', 160)->unique('tst_event_type_uq');
            $table->unsignedInteger('current_schema_version')->default(1);
            $table->json('supported_schema_versions');
            $table->string('category', 80)->nullable()->index();
            $table->json('allowed_scopes');
            $table->json('required_payload_fields')->nullable();
            $table->json('optional_payload_fields')->nullable();
            $table->boolean('allow_additional_payload_fields')->default(true);
            $table->string('owner_source', 120)->nullable()->index();
            $table->json('allowed_severities')->nullable();
            $table->string('status', 20)->default('active')->index();
            $table->string('replacement_event_type', 160)->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_types');
    }
};
