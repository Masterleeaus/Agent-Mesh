<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Tenancy;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use RuntimeException;

final class CrmCompanyContextResolver
{
    public function __construct(private readonly ConnectionInterface $db) {}

    public function resolveAuthenticated(?Authenticatable $actor = null, string $sourceSurface = 'crm'): CrmCompanyContext
    {
        $actor ??= auth()->user();
        if ($actor === null) {
            throw new RuntimeException('CRM company context resolution failed: authenticated actor is required.');
        }

        $actorId = (int) $actor->getAuthIdentifier();
        if ($actorId <= 0) {
            throw new RuntimeException('CRM company context resolution failed: authenticated actor id is invalid.');
        }

        $companyId = $this->resolveCompanyIdForActor($actor, $actorId);
        if ($companyId <= 0) {
            throw new RuntimeException('CRM company context resolution failed: no authenticated company membership.');
        }

        return new CrmCompanyContext(
            companyId: $companyId,
            actorUserId: $actorId,
            actorType: 'user',
            roles: $this->actorRoles($actor),
            permissions: [],
            authenticatedCompanyMembership: true,
            correlationId: $correlationId=(string) Str::uuid(),
            sourceSurface: $sourceSurface,
            traceId: $correlationId,
            causationId: null,
        );
    }

    /**
     * For server-to-server adapters only. The company id must already have been
     * derived from a trusted platform object (e.g. Chatbot record, MobileCore
     * context, signed worker/customer grant), never from an arbitrary request field.
     */
    public function fromTrustedPlatform(
        int $companyId,
        ?int $actorUserId,
        string $actorType,
        array $roles = [],
        array $permissions = [],
        string $sourceSurface = 'api',
        ?string $correlationId = null,
        ?string $deviceId = null,
        bool $membershipVerified = true,
        ?string $traceId = null,
        ?string $causationId = null,
    ): CrmCompanyContext {
        if ($companyId <= 0) {
            throw new RuntimeException('Trusted CRM platform context is missing company_id.');
        }
        if ($actorType === 'user' && $actorUserId !== null && $membershipVerified && ! $this->actorBelongsToCompany($actorUserId, $companyId)) {
            throw new RuntimeException('Trusted CRM platform actor is not a member of company_id.');
        }

        return new CrmCompanyContext(
            $companyId,
            $actorUserId,
            $actorType,
            $roles,
            $permissions,
            $membershipVerified,
            $correlationId ?: (string) Str::uuid(),
            $sourceSurface,
            $deviceId,
            $traceId ?: ($correlationId ?: (string) Str::uuid()),
            $causationId,
        );
    }

    public function companyIdForActorId(int $actorUserId): int
    {
        $model = config('auth.providers.users.model');
        if (! is_string($model) || ! class_exists($model)) {
            throw new RuntimeException('CRM company context cannot resolve actor membership without an authenticated user model.');
        }
        $actor = $model::query()->find($actorUserId);
        if (! $actor instanceof Authenticatable) {
            throw new RuntimeException('CRM company context actor was not found.');
        }
        return $this->resolveAuthenticated($actor)->companyId;
    }

    public function actorBelongsToCompany(int $actorUserId, int $companyId): bool
    {
        if ($actorUserId <= 0 || $companyId <= 0) return false;

        $membershipTable = trim((string) config('crm.tenancy.membership_table', ''));
        if ($membershipTable !== '' && $this->tableExists($membershipTable)) {
            $userColumn = (string) config('crm.tenancy.membership_user_column', 'user_id');
            $companyColumn = (string) config('crm.tenancy.membership_company_column', 'company_id');
            return $this->db->table($membershipTable)->where($userColumn, $actorUserId)->where($companyColumn, $companyId)->exists();
        }

        $usersTable = (string) config('crm.tenancy.users_table', 'users');
        if (! $this->tableExists($usersTable)) return false;
        foreach ((array) config('crm.tenancy.user_company_columns', ['active_company_id','current_company_id','company_id']) as $column) {
            if ($this->columnExists($usersTable, (string) $column)) {
                $value = (int) ($this->db->table($usersTable)->where('id', $actorUserId)->value((string) $column) ?? 0);
                if ($value === $companyId) return true;
            }
        }
        return false;
    }

    private function resolveCompanyIdForActor(Authenticatable $actor, int $actorId): int
    {
        $custom = config('crm.tenancy.membership_resolver');
        if (is_string($custom) && $custom !== '' && class_exists($custom)) {
            $resolver = app($custom);
            if (method_exists($resolver, 'companyIdForActor')) {
                $value = (int) $resolver->companyIdForActor($actor);
                if ($value > 0) return $value;
            }
        }

        $candidates = [];
        foreach ((array) config('crm.tenancy.user_company_columns', ['active_company_id','current_company_id','company_id']) as $column) {
            $value = $actor->getAttribute((string) $column);
            if (is_numeric($value) && (int) $value > 0) $candidates[(int) $value] = true;
        }
        if (count($candidates) > 1) {
            throw new RuntimeException('CRM company context resolution failed: conflicting authenticated company identifiers.');
        }
        if (count($candidates) === 1) {
            $companyId = (int) array_key_first($candidates);
            $membershipTable = trim((string) config('crm.tenancy.membership_table', ''));
            if ($membershipTable !== '' && ! $this->actorBelongsToCompany($actorId, $companyId)) {
                throw new RuntimeException('CRM company context resolution failed: company membership validation failed.');
            }
            return $companyId;
        }

        $membershipTable = trim((string) config('crm.tenancy.membership_table', ''));
        if ($membershipTable !== '' && $this->tableExists($membershipTable)) {
            $userColumn = (string) config('crm.tenancy.membership_user_column', 'user_id');
            $companyColumn = (string) config('crm.tenancy.membership_company_column', 'company_id');
            $ids = $this->db->table($membershipTable)->where($userColumn, $actorId)->pluck($companyColumn)->filter(fn($v) => is_numeric($v) && (int)$v > 0)->map(fn($v)=>(int)$v)->unique()->values();
            if ($ids->count() === 1) return (int) $ids->first();
            if ($ids->count() > 1) throw new RuntimeException('CRM company context resolution failed: actor belongs to multiple companies without an active company selection.');
        }

        // Fail closed. Never fall back to actor user id or caller request company_id.
        throw new RuntimeException('CRM company context resolution failed: no deterministic company membership.');
    }

    private function actorRoles(Authenticatable $actor): array
    {
        try {
            if (method_exists($actor, 'getRoleNames')) return array_values(array_map('strval', $actor->getRoleNames()->all()));
            $role = $actor->getAttribute('role');
            return is_string($role) && $role !== '' ? [$role] : [];
        } catch (\Throwable) { return []; }
    }

    private function tableExists(string $table): bool
    {
        try { return $this->db->getSchemaBuilder()->hasTable($table); } catch (\Throwable) { return false; }
    }

    private function columnExists(string $table, string $column): bool
    {
        try { return $this->db->getSchemaBuilder()->hasColumn($table, $column); } catch (\Throwable) { return false; }
    }
}
