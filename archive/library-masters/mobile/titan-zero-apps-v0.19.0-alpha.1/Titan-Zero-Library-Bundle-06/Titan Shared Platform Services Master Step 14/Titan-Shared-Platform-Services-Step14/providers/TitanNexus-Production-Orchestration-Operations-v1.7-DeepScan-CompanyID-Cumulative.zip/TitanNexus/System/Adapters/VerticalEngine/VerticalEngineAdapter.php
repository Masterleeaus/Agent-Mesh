<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Adapters\VerticalEngine;

use App\Extensions\TitanNexus\System\Contracts\VerticalDefinitionSourceContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use Closure;
use InvalidArgumentException;
use RuntimeException;

final class VerticalEngineAdapter implements VerticalDefinitionSourceContract
{
    private readonly Closure $resolver;

    public function __construct(callable $resolver)
    {
        $this->resolver = Closure::fromCallable($resolver);
    }

    public function resolve(BusinessProfile $profile): VerticalDefinition
    {
        $raw = ($this->resolver)($profile->toArray());

        if (!is_array($raw)) {
            throw new RuntimeException('Titan Vertical Engine adapter must return a definition array.');
        }

        try {
            $definition = VerticalDefinition::fromArray($raw);
        } catch (InvalidArgumentException $exception) {
            throw new RuntimeException('Titan Vertical Engine returned an invalid definition.', 0, $exception);
        }

        if ($definition->verticalId() !== $profile->verticalId()) {
            throw new RuntimeException('Titan Vertical Engine returned a different vertical identity than requested.');
        }

        if ($definition->verticalVersion() !== $profile->verticalVersion()) {
            throw new RuntimeException('Titan Vertical Engine returned a different vertical version than requested.');
        }

        return $definition;
    }
}
