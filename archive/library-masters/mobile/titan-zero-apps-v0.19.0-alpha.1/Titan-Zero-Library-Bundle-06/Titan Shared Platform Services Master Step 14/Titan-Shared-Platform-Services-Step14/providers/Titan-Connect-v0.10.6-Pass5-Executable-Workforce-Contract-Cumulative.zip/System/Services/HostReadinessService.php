<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Contracts\AttachmentSecurityScanner;
use Illuminate\Contracts\Container\Container;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Throwable;

final class HostReadinessService
{
    private const COMPANY_TABLES = [
        'ext_titan_connect_conversations', 'ext_titan_connect_participants',
        'ext_titan_connect_messages', 'ext_titan_connect_message_reads', 'ext_titan_connect_channel_connections',
        'ext_titan_connect_channel_members', 'ext_titan_connect_external_threads', 'ext_titan_connect_external_messages',
        'ext_titan_connect_external_thread_reads', 'ext_titan_connect_outbound_deliveries', 'ext_titan_connect_webhook_events',
        'ext_titan_connect_attachments', 'ext_titan_connect_audit_logs', 'ext_titan_connect_provider_credentials',
        'ext_titan_connect_external_contacts', 'ext_titan_connect_contact_tags', 'ext_titan_connect_external_thread_tags', 'ext_titan_connect_canned_responses',
        'ext_titan_connect_voice_calls', 'ext_titan_connect_voice_transcripts',
    ];

    public function __construct(private readonly Container $app)
    {
    }

    /** @return array<int,array{name:string,status:string,message:string}> */
    public function checks(): array
    {
        $checks = [];
        $push = static function (string $name, string $status, string $message) use (&$checks): void {
            $checks[] = compact('name', 'status', 'message');
        };

        try {
            $driver = (string) app('db')->connection()->getDriverName();
            $push('database', $driver === 'mysql' ? 'ok' : 'error', 'Database driver: '.$driver.' (MySQL required for certification).');
        } catch (Throwable $e) {
            $push('database', 'error', 'Database connection unavailable: '.$e->getMessage());
        }

        try {
            $push('users.company_id', Schema::hasColumn('users', 'company_id') ? 'ok' : 'error', Schema::hasColumn('users', 'company_id') ? 'users.company_id is present.' : 'users.company_id is missing.');
            $missing = [];
            foreach (self::COMPANY_TABLES as $table) {
                if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'company_id')) $missing[] = $table;
            }
            $push('company-schema', $missing === [] ? 'ok' : 'error', $missing === [] ? 'All Titan Connect company tables expose company_id.' : 'Missing company scope: '.implode(', ', $missing));
        } catch (Throwable $e) {
            $push('company-schema', 'error', 'Schema inspection failed: '.$e->getMessage());
        }

        try {
            if (! Schema::hasTable('menus')) {
                $push('navigation-menu', 'error', 'MagicAI menus table is missing; Titan Connect navigation cannot be materialized.');
            } else {
                $requiredMenuKeys = [
                    'ext_titan_connect_channels',
                    'ext_titan_connect_inbox',
                    'titan_connect_channel_whatsapp',
                    'titan_connect_channel_messenger',
                    'titan_connect_channel_instagram',
                    'titan_connect_channel_telegram',
                    'titan_connect_channel_sms',
                    'titan_connect_channel_voice',
                    'titan_connect_channel_push',
                    'titan_connect_inbox_unified',
                    'titan_connect_inbox_team',
                    'titan_connect_inbox_external',
                    'titan_connect_inbox_mine',
                    'titan_connect_inbox_unassigned',
                    'titan_connect_inbox_needs_human',
                    'titan_connect_inbox_closed',
                ];
                $present = app('db')->table('menus')->whereIn('key', $requiredMenuKeys)->pluck('key')->all();
                $missingMenus = array_values(array_diff($requiredMenuKeys, array_map('strval', $present)));
                $push(
                    'navigation-menu',
                    $missingMenus === [] ? 'ok' : 'error',
                    $missingMenus === []
                        ? 'Titan Connect Channels and Inbox navigation rows are materialized.'
                        : 'Missing Titan Connect menu keys: '.implode(', ', $missingMenus),
                );
            }
        } catch (Throwable $e) {
            $push('navigation-menu', 'error', 'Menu inspection failed: '.$e->getMessage());
        }

        $queue = (string) config('queue.default', 'sync');
        $push('queue', $queue === 'sync' ? 'warning' : 'ok', 'Queue connection: '.$queue.'.');
        $cache = (string) config('cache.default', 'file');
        $push('cache', $cache === 'array' ? 'warning' : 'ok', 'Cache store: '.$cache.'. Rate limiting depends on a shared cache in multi-node deployments.');
        $broadcast = (string) config('broadcasting.default', 'null');
        $push('broadcast', in_array($broadcast, ['null', 'log'], true) ? 'warning' : 'ok', 'Broadcast driver: '.$broadcast.'.');

        try {
            $disk = (string) config('titan-connect.attachments.storage_disk', config('filesystems.default', 'local'));
            Storage::disk($disk);
            $push('storage', 'ok', 'Attachment storage disk resolved: '.$disk.'.');
        } catch (Throwable $e) {
            $push('storage', 'error', 'Attachment storage disk failed to resolve: '.$e->getMessage());
        }

        try {
            $scanner = $this->app->make(AttachmentSecurityScanner::class);
            $push('attachment-scanner', str_contains($scanner::class, 'PendingAttachmentSecurityScanner') ? 'warning' : 'ok', 'Attachment scanner binding: '.$scanner::class.'.');
        } catch (Throwable $e) {
            $push('attachment-scanner', 'error', 'Attachment scanner binding failed: '.$e->getMessage());
        }

        return $checks;
    }

    public function hasErrors(): bool
    {
        foreach ($this->checks() as $check) if ($check['status'] === 'error') return true;
        return false;
    }
}
