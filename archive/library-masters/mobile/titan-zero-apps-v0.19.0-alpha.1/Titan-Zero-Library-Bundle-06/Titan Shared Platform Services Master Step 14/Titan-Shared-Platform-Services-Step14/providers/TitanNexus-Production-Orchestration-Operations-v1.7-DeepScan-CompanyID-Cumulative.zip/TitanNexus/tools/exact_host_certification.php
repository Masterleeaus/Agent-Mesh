<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Host\TitanZipPackageVerifier;

$arguments = [];
foreach (array_slice($argv, 1) as $argument) {
    if (str_starts_with($argument, '--') && str_contains($argument, '=')) {
        [$key, $value] = explode('=', substr($argument, 2), 2);
        $arguments[$key] = $value;
    }
}


$sequence = [
    'upload','validate_manifest','verify_integrity','backup','deploy','migrate','boot_provider',
    'enumerate_routes','render_user_menu','render_admin_menu','click_primary_route','test_super_admin',
    'test_delegated_admin','test_ordinary_user_denial','test_tenant_isolation','queue_scheduler_health',
    'upgrade','disable','uninstall_retain_data',
];
$stageNames = ['PACKAGE_CERTIFIED','INSTALLER_CERTIFIED','MIGRATION_CERTIFIED','BOOT_CERTIFIED','NAVIGATION_CERTIFIED','AUTHORIZATION_CERTIFIED','RUNTIME_CERTIFIED','UPGRADE_CERTIFIED','UNINSTALL_CERTIFIED'];
if (in_array('--print-sequence', array_slice($argv, 1), true)) {
    echo json_encode([
        'stages' => $stageNames,
        'sequence' => $sequence,
        'expected_host' => ['php'=>'8.3','laravel'=>'10.50.x','installer'=>'1.7.6','database'=>'mysql'],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . PHP_EOL;
    exit(0);
}

$package = $arguments['package'] ?? null;
$output = $arguments['output'] ?? null;
$root = dirname(__DIR__);
require_once $root . '/System/Host/TitanZipPackageVerifier.php';

$packageResult = is_string($package) ? TitanZipPackageVerifier::verify($package) : [
    'valid' => false,
    'errors' => ['--package=<exact ZIP> is required'],
    'entries' => 0,
    'integrity_files' => 0,
];

$stages = [
    'PACKAGE_CERTIFIED' => [
        'status' => $packageResult['valid'] ? 'PASS' : 'FAIL',
        'evidence' => $packageResult['valid']
            ? ["ZIP entries={$packageResult['entries']}", "integrity files={$packageResult['integrity_files']}"]
            : $packageResult['errors'],
    ],
    'INSTALLER_CERTIFIED' => ['status' => 'NOT_RUN', 'evidence' => ['requires exact MagicAI Installer 1.7.6 host']],
    'MIGRATION_CERTIFIED' => ['status' => 'NOT_RUN', 'evidence' => ['requires exact host database']],
    'BOOT_CERTIFIED' => ['status' => 'NOT_RUN', 'evidence' => ['requires provider boot in exact host']],
    'NAVIGATION_CERTIFIED' => ['status' => 'NOT_RUN', 'evidence' => ['requires exact host menu registry/fallback']],
    'AUTHORIZATION_CERTIFIED' => ['status' => 'NOT_RUN', 'evidence' => ['requires exact host users/permissions']],
    'RUNTIME_CERTIFIED' => ['status' => 'NOT_RUN', 'evidence' => ['requires exact host public Titan contracts']],
    'UPGRADE_CERTIFIED' => ['status' => 'NOT_RUN', 'evidence' => ['requires upgrade from installed prior version']],
    'UNINSTALL_CERTIFIED' => ['status' => 'NOT_RUN', 'evidence' => ['requires exact host uninstall lifecycle']],
];

$report = [
    'schema_version' => '1.0',
    'host_profile' => 'titan.host.magicai.installer-1.7.6.v1',
    'package_sha256' => is_string($package) && is_file($package) ? hash_file('sha256', $package) : str_repeat('0', 64),
    'overall_status' => $packageResult['valid'] ? 'PARTIAL' : 'FAILED',
    'stages' => $stages,
];
$json = json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . PHP_EOL;
if (is_string($output) && $output !== '') {
    file_put_contents($output, $json);
}
echo $json;
exit($packageResult['valid'] ? 0 : 1);
