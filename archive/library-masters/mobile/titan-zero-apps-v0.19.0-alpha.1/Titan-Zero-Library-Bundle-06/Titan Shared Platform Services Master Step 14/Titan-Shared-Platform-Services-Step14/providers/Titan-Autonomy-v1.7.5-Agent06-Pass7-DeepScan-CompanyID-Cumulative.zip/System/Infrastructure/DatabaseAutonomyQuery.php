<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;
use Illuminate\Support\Facades\DB;

final class DatabaseAutonomyQuery implements AutonomyQueryContract
{
    public function capabilityStates(int $tenantCompanyId): array
    {
        return array_map(fn ($row) => $this->normalise((array) $row), app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_capability_states')
            ->where('tenant_company_id', $tenantCompanyId)
            ->orderBy('capability')->orderBy('workflow_key')->limit(1000)->get()->all());
    }

    public function capabilityState(int $tenantCompanyId, string $capability, string $workflowKey): ?array
    {
        $row = app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_capability_states')
            ->where('tenant_company_id', $tenantCompanyId)
            ->where('capability', $capability)
            ->where('workflow_key', $workflowKey)
            ->first();
        return $row ? $this->normalise((array) $row) : null;
    }

    public function learningEvents(int $tenantCompanyId, ?string $capability = null, ?string $workflowKey = null, int $limit = 1000): array
    {
        $query = app(\Illuminate\Database\DatabaseManager::class)->table('titan_learning_events')->where('tenant_company_id', $tenantCompanyId);
        if ($capability !== null) $query->where('capability', $capability);
        if ($workflowKey !== null) $query->where('workflow_key', $workflowKey);
        return array_map(fn ($row) => $this->normalise((array) $row), $query->orderByDesc('id')->limit(max(1, min(5000, $limit)))->limit(1000)->get()->all());
    }

    public function learningPreferences(int $tenantCompanyId, ?int $userId = null): array
    {
        $query = app(\Illuminate\Database\DatabaseManager::class)->table('titan_learning_preferences')->where('tenant_company_id', $tenantCompanyId);
        if ($userId !== null) $query->where('user_id', $userId);
        return array_map(fn ($row) => $this->normalise((array) $row), $query->orderBy('scope')->orderBy('preference_key')->limit(1000)->get()->all());
    }

    public function learningSettings(int $tenantCompanyId): array
    {
        $row = app(\Illuminate\Database\DatabaseManager::class)->table('titan_learning_settings')->where('tenant_company_id', $tenantCompanyId)->first();
        return $row ? $this->normalise((array) $row) : [];
    }

    public function tenantPolicy(int $tenantCompanyId): ?array
    {
        $row = app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_policies')->where('scope_type', 'tenant')->where('scope_key', 'tenant:' . $tenantCompanyId)->where('active', true)->first();
        return $row ? $this->normalise((array) $row) : null;
    }

    public function platformPolicy(): ?array
    {
        $row = app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_policies')->where('scope_type', 'platform')->where('scope_key', 'global')->where('active', true)->first();
        return $row ? $this->normalise((array) $row) : null;
    }

    public function handshakes(int $tenantCompanyId, ?string $capability = null, ?string $workflowKey = null, int $limit = 100): array
    {
        $query = app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_handshakes')->where('tenant_company_id', $tenantCompanyId);
        if ($capability !== null) $query->where('capability', $capability);
        if ($workflowKey !== null) $query->where('workflow_key', $workflowKey);
        return array_map(fn ($row) => $this->normalise((array) $row), $query->orderByDesc('id')->limit(max(1, min(1000, $limit)))->limit(1000)->get()->all());
    }

    public function regressions(int $tenantCompanyId, ?string $capability = null, ?string $workflowKey = null, int $limit = 100): array
    {
        $query = app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_regressions')->where('tenant_company_id', $tenantCompanyId);
        if ($capability !== null) $query->where('capability', $capability);
        if ($workflowKey !== null) $query->where('workflow_key', $workflowKey);
        return array_map(fn ($row) => $this->normalise((array) $row), $query->orderByDesc('id')->limit(max(1, min(1000, $limit)))->limit(1000)->get()->all());
    }

    private function normalise(array $row): array
    {
        foreach ($row as $key => $value) {
            if (str_ends_with($key, '_json') && is_string($value) && $value !== '') {
                $decoded = json_decode($value, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $row[substr($key, 0, -5)] = $decoded;
                }
            }
        }
        return $row;
    }
}
