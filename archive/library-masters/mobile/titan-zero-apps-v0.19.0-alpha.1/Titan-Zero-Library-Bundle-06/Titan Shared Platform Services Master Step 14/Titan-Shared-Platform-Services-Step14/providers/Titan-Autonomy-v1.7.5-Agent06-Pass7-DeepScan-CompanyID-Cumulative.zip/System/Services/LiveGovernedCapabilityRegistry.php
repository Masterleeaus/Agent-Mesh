<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use InvalidArgumentException;

final class LiveGovernedCapabilityRegistry
{
    /**
     * Verified against MagicAI CRM 1.3.0-alpha.14 CrmCapabilityManifest and
     * CrmInteractionJourneyRegistry. A null journey_key means CRM publishes
     * the capability but does not currently publish a first-party Interaction
     * Engine journey for that action.
     */
    private const PROFILES = [
        'crm.customer.create' => ['risk' => 'medium', 'permission' => 'crm.contacts.create', 'journey_key' => 'new-customer'],
        'crm.work_order.create' => ['risk' => 'medium', 'permission' => 'crm.work_orders.manage', 'journey_key' => 'new-job'],
        'crm.work_order.assign' => ['risk' => 'medium', 'permission' => 'crm.dispatch.manage', 'journey_key' => 'new-dispatch-assignment'],
        'crm.work_order.reschedule' => ['risk' => 'medium', 'permission' => 'crm.scheduling.manage', 'journey_key' => 'reschedule-job'],
        'crm.work_order.cancel' => ['risk' => 'high', 'permission' => 'crm.work_orders.manage', 'journey_key' => 'cancel-job'],
        'crm.appointment.create' => ['risk' => 'medium', 'permission' => 'crm.scheduling.manage', 'journey_key' => 'new-appointment'],
        'crm.staff.schedule' => ['risk' => 'medium', 'permission' => 'crm.scheduling.manage', 'journey_key' => null],
        'crm.quote.create' => ['risk' => 'medium', 'permission' => 'crm.sales.manage', 'journey_key' => 'new-quote'],
        'crm.quote.approve' => ['risk' => 'high', 'permission' => 'crm.sales.manage', 'journey_key' => 'accept-quote'],
        'crm.quote.transition' => ['risk' => 'high', 'permission' => 'crm.sales.manage', 'journey_key' => 'transition-quote'],
        'crm.invoice.create' => ['risk' => 'medium', 'permission' => 'crm.invoices.manage', 'journey_key' => 'new-invoice'],
        'crm.invoice.issue' => ['risk' => 'medium', 'permission' => 'crm.invoices.manage', 'journey_key' => null],
        'crm.invoice.transition' => ['risk' => 'high', 'permission' => 'crm.invoices.manage', 'journey_key' => 'transition-invoice'],
        'crm.payment.record' => ['risk' => 'critical', 'permission' => 'crm.invoices.manage', 'journey_key' => 'new-payment'],
        'crm.payment.reconcile' => ['risk' => 'critical', 'permission' => 'crm.invoices.manage', 'journey_key' => null],
    ];

    public function has(string $capability): bool { return isset(self::PROFILES[$capability]); }
    public function all(): array { return self::PROFILES; }
    public function profile(string $capability): array
    {
        if (!$this->has($capability)) throw new InvalidArgumentException('UNVERIFIED_OR_UNGOVERNED_HOST_CAPABILITY');
        return self::PROFILES[$capability] + ['capability' => $capability];
    }
}
