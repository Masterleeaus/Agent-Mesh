# Titan Governance v1.0.0-rc.1 H1 — Installer 1.7.6 Dependency Compatibility

## Trigger

Live Installer 1.7.6 rejected the Pass 8 RC during dependency resolution with:

`Unsatisfied extension dependencies: titan-signal >=0.2.0, titan-command-bus >=0.2.0-alpha.1.`

The failed attempt stopped in `validating` and reported an empty rollback.

## Root cause

The root Installer manifest incorrectly treated Titan Signal and Titan Command Bus as hard installation prerequisites. Governance runtime already supports their absence through explicit unavailable adapters: health degrades, required read/evidence facets report unavailable, and consequential actions fail closed through `UnavailableGovernanceCommandGateway`. Their absence therefore does not prevent a safe provider boot or migration.

## Correction

- Root `extension.json.dependencies`: retains only `titan-autonomy >=0.1`.
- Root `extension.json.optional_dependencies`: now includes `titan-signal >=0.2.0` and `titan-command-bus >=0.2.0-alpha.1` plus existing optional observers.
- Canonical `extension.manifest.json` continues to classify Signal, Command Bus and Autonomy as runtime-required.
- `config/titan-governance.php` continues to classify all three as required for full Governance operation.
- No migration, route, permission, capability, policy, execution or database behavior is changed.

## Runtime truth

Installing without Signal/Command Bus is allowed, but Governance must report DEGRADED/UNAVAILABLE facets and must not dispatch consequential actions until trusted runtime adapters are available.
