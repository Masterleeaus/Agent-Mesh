-- Titan Connect v0.10.5 live Titan Zero / MagicAI dashboard navigation repair.
-- Normally migration 2026_08_10_000008_repair_magicai_dashboard_navigation.php performs this automatically.
-- This fallback targets the supplied live host schema (shared menus table without is_admin).
START TRANSACTION;

DELETE FROM `menus` WHERE `key` IN (
  'titan_connect_admin_settings_overview','titan_connect_admin_settings_whatsapp',
  'titan_connect_admin_settings_messenger','titan_connect_admin_settings_instagram',
  'titan_connect_admin_settings_telegram','titan_connect_admin_settings_sms',
  'titan_connect_admin_settings_voice','titan_connect_admin_settings_push'
);

INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`) VALUES
(NULL,'ext_titan_connect_inbox','dashboard.user.titan-connect.inbox.unified',NULL,'Inbox','tabler-inbox',NULL,6,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(NULL,'ext_titan_connect_channels','dashboard.user.titan-connect.channels.index',NULL,'Channels','tabler-message-cog',NULL,7,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0)
ON DUPLICATE KEY UPDATE `parent_id`=NULL,`route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`order`=VALUES(`order`),`is_active`=1,`extension`=NULL,`badge`=NULL,`updated_at`=NOW();

SET @tc_inbox := (SELECT `id` FROM `menus` WHERE `key`='ext_titan_connect_inbox' LIMIT 1);
SET @tc_channels := (SELECT `id` FROM `menus` WHERE `key`='ext_titan_connect_channels' LIMIT 1);

INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`) VALUES
(@tc_inbox,'titan_connect_inbox_unified','dashboard.user.titan-connect.inbox.unified',NULL,'Unified Inbox','tabler-inbox',NULL,1,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_team','dashboard.user.titan-connect.inbox.team',NULL,'Team / Internal','tabler-users-group',NULL,2,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_external','dashboard.user.titan-connect.inbox.external',NULL,'External / Omnichannel','tabler-world',NULL,3,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_mine','dashboard.user.titan-connect.inbox.mine',NULL,'Assigned to Me','tabler-user-check',NULL,4,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_unassigned','dashboard.user.titan-connect.inbox.unassigned',NULL,'Unassigned','tabler-user-question',NULL,5,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_needs_human','dashboard.user.titan-connect.inbox.needs_human',NULL,'Needs Human','tabler-hand-stop',NULL,6,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_closed','dashboard.user.titan-connect.inbox.closed',NULL,'Closed / Archived','tabler-archive',NULL,7,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_whatsapp','dashboard.user.titan-connect.channels.whatsapp',NULL,'WhatsApp','tabler-message',NULL,1,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_messenger','dashboard.user.titan-connect.channels.messenger',NULL,'Messenger','tabler-message',NULL,2,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_instagram','dashboard.user.titan-connect.channels.instagram',NULL,'Instagram','tabler-photo',NULL,3,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_telegram','dashboard.user.titan-connect.channels.telegram',NULL,'Telegram','tabler-message',NULL,4,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_sms','dashboard.user.titan-connect.channels.sms',NULL,'SMS','tabler-message',NULL,5,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_voice','dashboard.user.titan-connect.channels.voice',NULL,'Voice','tabler-phone-call',NULL,6,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_push','dashboard.user.titan-connect.channels.push',NULL,'Push / Mobile','tabler-bell-ringing',NULL,7,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0)
ON DUPLICATE KEY UPDATE `parent_id`=VALUES(`parent_id`),`route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`order`=VALUES(`order`),`is_active`=1,`extension`=NULL,`badge`=NULL,`updated_at`=NOW();

SET @tc_admin_settings := (SELECT `id` FROM `menus` WHERE `key`='settings' LIMIT 1);
INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`)
SELECT @tc_admin_settings,'titan_connect_admin_settings','dashboard.admin.settings.titan-connect.channels.index',NULL,'Titan Connect','tabler-message-cog',NULL,90,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0
WHERE @tc_admin_settings IS NOT NULL
ON DUPLICATE KEY UPDATE `parent_id`=VALUES(`parent_id`),`route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`order`=VALUES(`order`),`is_active`=1,`extension`=NULL,`badge`=NULL,`updated_at`=NOW();

COMMIT;
-- Optional after manual use: php artisan titan-connect:host-sync
