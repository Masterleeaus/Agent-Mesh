<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

interface RetentionPolicy
{
    public function daysForCompany(int $companyId): int;
}
