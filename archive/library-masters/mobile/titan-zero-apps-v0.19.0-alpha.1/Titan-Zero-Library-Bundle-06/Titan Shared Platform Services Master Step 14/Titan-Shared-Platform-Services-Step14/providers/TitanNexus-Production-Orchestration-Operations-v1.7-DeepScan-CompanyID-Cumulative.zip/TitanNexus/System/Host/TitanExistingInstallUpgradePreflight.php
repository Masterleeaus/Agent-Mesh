<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Host;

use Throwable;

final class TitanExistingInstallUpgradePreflight
{
    /** @return array{status:string,errors:list<string>,checks:array<string,bool>,target_version:?string,migrations:list<string>} */
    public static function verifyDirectory(string $root): array
    {
        $root = realpath($root) ?: rtrim($root, '/\\');
        $errors = [];
        $checks = [
            'fresh_install_contract' => false,
            'migration_chain' => false,
            'route_names_unique' => false,
            'menu_identities_unique' => false,
            'provider_bindings_unique' => false,
        ];

        $fresh = TitanFreshInstallPreflight::verifyDirectory($root);
        if (($fresh['status'] ?? 'FAIL') !== 'PASS') {
            foreach (($fresh['errors'] ?? []) as $error) {
                $errors[] = 'fresh_install_contract: ' . (string) $error;
            }
        }
        $checks['fresh_install_contract'] = !self::hasPrefix($errors, 'fresh_install_contract:');

        $migrations = self::migrationNames($root, $errors);
        $checks['migration_chain'] = !self::hasPrefix($errors, 'migration_chain:');

        self::verifyRouteNames($root, $errors);
        $checks['route_names_unique'] = !self::hasPrefix($errors, 'route_names_unique:');

        self::verifyMenuIdentities($root, $errors);
        $checks['menu_identities_unique'] = !self::hasPrefix($errors, 'menu_identities_unique:');

        self::verifyProviderBindings($root, $errors);
        $checks['provider_bindings_unique'] = !self::hasPrefix($errors, 'provider_bindings_unique:');

        return [
            'status' => $errors === [] ? 'PASS' : 'FAIL',
            'errors' => $errors,
            'checks' => $checks,
            'target_version' => self::targetVersion($root),
            'migrations' => $migrations,
        ];
    }

    /**
     * @param array<string,mixed> $facts
     * @return array{compatible:bool,reasons:list<string>,target_version:?string,installed_version:?string,applied_migrations:list<string>,pending_migrations:list<string>,acceptance_sequence:list<string>}
     */
    public static function evaluateInstalledState(string $root, array $facts): array
    {
        $package = self::verifyDirectory($root);
        $targetVersion = $package['target_version'] ?? null;
        $packagedMigrations = $package['migrations'] ?? [];
        $installedVersion = self::nonEmptyString($facts['installed_version'] ?? null);
        $applied = self::stringList($facts['applied_migrations'] ?? []);
        $reasons = [];

        if (($package['status'] ?? 'FAIL') !== 'PASS') {
            $reasons[] = 'package_upgrade_preflight_failed';
        }
        if ($installedVersion === null) {
            $reasons[] = 'installed_version_missing';
        } elseif ($targetVersion !== null && version_compare($installedVersion, $targetVersion, '>')) {
            $reasons[] = 'installed_version_newer_than_target';
        }
        if (!self::truthyFact($facts['compilation_table_exists'] ?? false)) {
            $reasons[] = 'compilation_table_missing';
        }

        $unknown = array_values(array_diff($applied, $packagedMigrations));
        if ($unknown !== []) {
            $reasons[] = 'unknown_applied_migration';
        }
        $expectedPrefix = array_slice($packagedMigrations, 0, count($applied));
        if ($unknown === [] && $applied !== $expectedPrefix) {
            $reasons[] = 'applied_migration_chain_not_prefix';
        }

        $duplicates = [
            'duplicate_compilation_identities',
            'duplicate_menu_keys',
            'duplicate_route_names',
            'duplicate_service_bindings',
        ];
        foreach ($duplicates as $key) {
            if (self::nonNegativeInt($facts[$key] ?? 0) > 0) {
                $reasons[] = $key;
            }
        }

        $eventMigration = '2026_08_21_000005_create_titan_nexus_compilation_events_table';
        $eventApplied = in_array($eventMigration, $applied, true);
        $eventTable = self::truthyFact($facts['lifecycle_table_exists'] ?? false);
        if ($eventApplied !== $eventTable) {
            $reasons[] = $eventApplied ? 'lifecycle_table_missing_after_migration' : 'unexpected_lifecycle_table_before_migration';
        }

        $pending = array_values(array_diff($packagedMigrations, $applied));
        return [
            'compatible' => $reasons === [],
            'reasons' => array_values(array_unique($reasons)),
            'target_version' => $targetVersion,
            'installed_version' => $installedVersion,
            'applied_migrations' => $applied,
            'pending_migrations' => $pending,
            'acceptance_sequence' => [
                'capture_pre_upgrade_backup',
                'verify_exact_current_version_and_migration_prefix',
                'verify_zero_duplicate_compilation_identities',
                'disable_nexus_write_paths',
                'deploy_exact_target_zip',
                'run_pending_migrations_in_order',
                'boot_provider_once',
                'verify_no_duplicate_routes_menus_or_bindings',
                'verify_existing_compilations_and_lifecycle_history',
                'verify_control_centre_reads_existing_tenant_data',
                'verify_idempotent_second_boot_and_route_registration',
                'record_upgrade_certification_evidence',
            ],
        ];
    }

    /** @param list<string> $errors @return list<string> */
    private static function migrationNames(string $root, array &$errors): array
    {
        $files = glob($root . '/database/migrations/*.php') ?: [];
        sort($files, SORT_STRING);
        $names = [];
        $previous = null;
        foreach ($files as $file) {
            $name = basename($file, '.php');
            if (preg_match('/^(\d{4}_\d{2}_\d{2}_\d{6})_[a-z0-9_]+$/', $name, $match) !== 1) {
                $errors[] = "migration_chain: invalid migration {$name}";
                continue;
            }
            if ($previous !== null && strcmp($previous, $match[1]) >= 0) {
                $errors[] = "migration_chain: non-increasing migration timestamp {$name}";
            }
            $previous = $match[1];
            $names[] = $name;
        }
        if ($names === []) { $errors[] = 'migration_chain: no migrations found'; }
        return $names;
    }

    /** @param list<string> $errors */
    private static function verifyRouteNames(string $root, array &$errors): void
    {
        $seen = [];
        foreach (['user' => 'dashboard.user.titan.nexus.', 'admin' => 'dashboard.admin.titan.nexus.'] as $file => $prefix) {
            $source = (string) @file_get_contents($root . "/routes/{$file}.php");
            preg_match_all("/->name\\('([^']+)'\\)/", $source, $matches);
            foreach ($matches[1] ?? [] as $local) {
                $name = $prefix . $local;
                if (isset($seen[$name])) { $errors[] = "route_names_unique: duplicate route {$name}"; }
                $seen[$name] = true;
            }
        }
    }

    /** @param list<string> $errors */
    private static function verifyMenuIdentities(string $root, array &$errors): void
    {
        $path = $root . '/System/Host/NexusMenuRegistrar.php';
        if (!is_file($path)) { $errors[] = 'menu_identities_unique: registrar missing'; return; }
        try {
            $definitions = NexusMenuRegistrar::definitions();
        } catch (Throwable $e) {
            $errors[] = 'menu_identities_unique: registrar definitions failed';
            return;
        }
        $keys = []; $fallbacks = [];
        foreach ($definitions as $definition) {
            $key = self::nonEmptyString($definition['key'] ?? null);
            $fallback = self::nonEmptyString($definition['legacy_fallback_identity']['route'] ?? null);
            if ($key === null) { $errors[] = 'menu_identities_unique: empty menu key'; }
            elseif (isset($keys[$key])) { $errors[] = "menu_identities_unique: duplicate menu key {$key}"; }
            else { $keys[$key] = true; }
            if ($fallback === null) { $errors[] = 'menu_identities_unique: empty fallback route'; }
            elseif (isset($fallbacks[$fallback])) { $errors[] = "menu_identities_unique: duplicate fallback route {$fallback}"; }
            else { $fallbacks[$fallback] = true; }
        }
    }

    /** @param list<string> $errors */
    private static function verifyProviderBindings(string $root, array &$errors): void
    {
        $source = (string) @file_get_contents($root . '/System/TitanNexusServiceProvider.php');
        preg_match_all('/\$this->app->singleton\(([^,\n]+),/', $source, $matches);
        $seen = [];
        foreach ($matches[1] ?? [] as $binding) {
            $binding = preg_replace('/\s+/', '', trim((string) $binding));
            if ($binding === '') { continue; }
            if (isset($seen[$binding])) { $errors[] = "provider_bindings_unique: duplicate singleton {$binding}"; }
            $seen[$binding] = true;
        }
    }

    private static function targetVersion(string $root): ?string
    {
        $path = $root . '/extension.json';
        if (!is_file($path)) { return null; }
        try { $data = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR); }
        catch (Throwable) { return null; }
        return self::nonEmptyString($data['version'] ?? null);
    }

    private static function nonEmptyString(mixed $value): ?string
    {
        return is_string($value) && trim($value) !== '' ? trim($value) : null;
    }

    /** @return list<string> */
    private static function stringList(mixed $value): array
    {
        if (!is_array($value)) { return []; }
        $result = [];
        foreach ($value as $item) { if (is_string($item) && trim($item) !== '') { $result[] = trim($item); } }
        return array_values($result);
    }

    private static function nonNegativeInt(mixed $value): int
    {
        if (is_int($value)) { return max(0, $value); }
        if (is_string($value) && ctype_digit($value)) { return (int) $value; }
        return 0;
    }

    private static function truthyFact(mixed $value): bool
    {
        return $value === true || $value === 1 || $value === '1' || $value === 'true';
    }

    /** @param list<string> $values */
    private static function hasPrefix(array $values, string $prefix): bool
    {
        foreach ($values as $value) { if (str_starts_with($value, $prefix)) { return true; } }
        return false;
    }
}
