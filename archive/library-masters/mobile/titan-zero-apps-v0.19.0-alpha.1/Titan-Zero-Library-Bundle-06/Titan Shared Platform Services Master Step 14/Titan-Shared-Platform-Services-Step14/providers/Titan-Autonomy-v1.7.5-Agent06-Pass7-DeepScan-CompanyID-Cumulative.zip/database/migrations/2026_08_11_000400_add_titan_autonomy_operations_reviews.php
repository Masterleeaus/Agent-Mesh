<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_autonomy_execution_reviews')) {
            Schema::create('titan_autonomy_execution_reviews', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->char('public_id', 26)->unique();
                $table->char('receipt_public_id', 26)->index();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('user_id')->index();
                $table->string('review_status', 32)->index();
                $table->text('note')->nullable();
                $table->string('policy_version', 64);
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_autonomy_execution_reviews');
    }
};
