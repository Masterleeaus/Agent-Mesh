# Installer 1.7.4 / MySQL timestamp-mode hotfix

Live failure:

`SQLSTATE[42000] 1067 Invalid default value for consent_granted_at`

## Root cause

The worker-location table declared three required Laravel `timestamp()` columns without explicit defaults. On MySQL configurations that do not use the modern explicit TIMESTAMP-default behavior, a later required TIMESTAMP may receive an implicit zero-date default. Strict/NO_ZERO_DATE mode then rejects the CREATE TABLE statement.

## Repair

Required business/event timestamps now use `dateTime()` for:

- `titan_field_worker_location_pings.captured_at`
- `titan_field_worker_location_pings.consent_granted_at`
- `titan_field_worker_location_pings.retention_expires_at`
- `titan_field_offline_devices.registered_at`
- `titan_field_offline_receipts.occurred_at`
- `titan_field_offline_receipts.received_at`

Nullable timestamps and timestamps with explicit `useCurrent()` remain unchanged.

## Failed-install recovery

Migration `000007` independently guards routes, route stops and worker pings with `Schema::hasTable()`. If the failed attempt already created the first two tables, the retry skips them and creates only the missing location table. Migration `000008` has the same table guards for offline runtime tables.

No manual table deletion is required by this package repair.
