<?php

declare(strict_types=1);

namespace Tests\Feature;

use PHPUnit\Framework\TestCase;

final class ExtensionBootTest extends TestCase
{
    public function test_installer_and_sidecar_match_canonical_rebased_identity(): void
    {
        $root = dirname(__DIR__, 2);
        $installer = json_decode((string) file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);
        $sidecar = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);

        self::assertSame('titan-extension-v1', $installer['schema']);
        self::assertSame('0.5.0-alpha.4', $installer['version']);
        self::assertSame('TitanKnowledgeAuthority', $installer['folder']);
        self::assertSame('App\\Extensions\\TitanKnowledgeAuthority\\System\\TitanKnowledgeAuthorityServiceProvider', $installer['provider']);
        foreach (['schema', 'slug', 'folder', 'provider', 'version', 'integrity'] as $key) {
            self::assertArrayHasKey($key, $installer);
        }
        self::assertSame('Titan Knowledge Authority', $installer['name'] ?? null);
        self::assertSame('extension', $installer['type'] ?? null);
        self::assertSame('2.2', $sidecar['schema_version']);
        self::assertSame('intelligence-engine', $sidecar['architecture']['profile']);
        self::assertContains('knowledge-authority', $sidecar['architecture']['modifiers']);
        self::assertSame('self', $sidecar['governance']['knowledge_authority']);
        self::assertSame('forbidden', $sidecar['authority']['cross_domain_write_policy']);
        self::assertFalse($sidecar['queues']['used']);
        self::assertSame(['titan-knowledge-authority', 'knowledge.health'], $sidecar['capabilities']);
    }
}
