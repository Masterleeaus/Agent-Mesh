# Architecture

Titan Payroll is a business-domain extension. `tenant_company_id` is actor-derived. Payroll owns payroll truth; cross-domain writes are command-bus-only. Time Attendance is consumed through a typed port in later passes.
