<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Models;

use Illuminate\Database\Eloquent\Model;
use App\Extensions\TitanModelCouncil\System\Models\Concerns\HasCanonicalCompanyIdCompatibility;

final class CouncilReceiptRecord extends Model
{
    use HasCanonicalCompanyIdCompatibility;

    protected $table = 'titan_model_council_receipts';
    protected $guarded = ['id'];

    protected $casts = [
        'company_id' => 'integer',
        'company_id' => 'integer',
            'tenant_company_id' => 'integer',
        'decision_id' => 'integer',
        'requires_escalation' => 'boolean',
        'receipt_payload' => 'array',
        'recorded_at' => 'datetime',
    ];
}
