<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Enums\KnowledgeScopeType;
use InvalidArgumentException;

final readonly class KnowledgeScopeContext
{
    private function __construct(
        public KnowledgeScopeType $type,
        public ?int $tenantCompanyId,
        public ?string $jurisdictionCode,
    ) {
        if ($type === KnowledgeScopeType::Tenant && $tenantCompanyId === null) {
            throw new InvalidArgumentException('Tenant knowledge scope requires tenant_company_id.');
        }
        if ($type === KnowledgeScopeType::Jurisdiction && ($jurisdictionCode === null || trim($jurisdictionCode) === '')) {
            throw new InvalidArgumentException('Jurisdiction knowledge scope requires a jurisdiction code.');
        }
        if ($type !== KnowledgeScopeType::Tenant && $tenantCompanyId !== null) {
            throw new InvalidArgumentException('Only tenant knowledge scope may carry tenant_company_id.');
        }
    }

    public static function platform(): self
    {
        return new self(KnowledgeScopeType::Platform, null, null);
    }

    public static function jurisdiction(string $code): self
    {
        return new self(KnowledgeScopeType::Jurisdiction, null, trim($code));
    }

    public static function tenant(int $tenantCompanyId): self
    {
        if ($tenantCompanyId <= 0) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }

        return new self(KnowledgeScopeType::Tenant, $tenantCompanyId, null);
    }

    public function scopeKey(): string
    {
        return match ($this->type) {
            KnowledgeScopeType::Platform => 'platform',
            KnowledgeScopeType::Jurisdiction => 'jurisdiction:' . $this->jurisdictionCode,
            KnowledgeScopeType::Tenant => 'tenant:' . $this->tenantCompanyId,
        };
    }
}
