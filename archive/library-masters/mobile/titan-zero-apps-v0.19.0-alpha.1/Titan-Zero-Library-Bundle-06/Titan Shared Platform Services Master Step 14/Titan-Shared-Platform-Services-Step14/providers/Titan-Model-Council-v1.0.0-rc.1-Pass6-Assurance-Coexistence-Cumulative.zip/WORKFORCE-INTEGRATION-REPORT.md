# Workforce Integration Report — Titan-Model-Council

## Result

This pass makes **Titan-Model-Council** a subordinate runtime/provider to Titan AI Workforce. Workforce is the sole active owner of employee identity, organisational roles, hierarchy, teams, responsibilities, assignments, work items and organisational orchestration. The extension publishes runtime/domain execution surfaces only.

## Canonical tenancy

New Workforce-facing contracts use `company_id`. Council proposer/critic/verifier/arbiter are deliberation roles, not organisational roles or Workforce employee identities. Existing tenant_company_id persistence is compatibility-only.

## Published surfaces

- Capabilities: model.council.plan, model.council.deliberate, model.council.consensus, model.council.verify, model.council.arbitrate
- Tools: model.council.status, model.council.participant.read, model.council.receipt.read
- Commands: model.council.deliberate-governed
- Reads: model.council.status, model.council.receipt.read
- Signals: model.council.started, model.council.completed, model.council.degraded, model.council.blocked
- Work types: model.deliberation, model.consensus, model.verification

## Safety invariants

Installation never grants authority. Availability, authorization, governance, risk and autonomy remain separate decisions. Missing provider/configuration fails closed. Side effects must use the Command Bus or the platform's canonical governed execution boundary. Reads are non-mutating. Provider disable/removal/upgrade does not mutate Workforce employee identity or grant fallback authority.

## Availability states

`available`, `degraded`, `unavailable`, `missing_provider`, `blocked`, `policy_disabled`.

## Verification

See `tests/workforce_integration_contract_runner.php` and the batch report for fresh extracted-package pass counts.
