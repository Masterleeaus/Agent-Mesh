<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Security;

final class RewindPermissions
{
    public const TRACE_VIEW = 'rewind.trace.view';
    public const FORENSICS_VIEW = 'rewind.forensics.view';
    public const INTEGRITY_VERIFY = 'rewind.integrity.verify';
    public const REPLAY_RUN = 'rewind.replay.run';
    public const EVIDENCE_GENERATE = 'rewind.evidence.generate';
    public const EVIDENCE_EXPORT = 'rewind.evidence.export';
    public const RECOVERY_PROPOSE = 'rewind.recovery.propose';
    public const RECOVERY_REQUEST_APPROVAL = 'rewind.recovery.request-approval';
    public const LEGAL_HOLD_MANAGE = 'rewind.legal-hold.manage';
    public const ADMIN = 'rewind.admin';

    /** @return list<string> */
    public static function all(): array
    {
        return [
            self::TRACE_VIEW, self::FORENSICS_VIEW, self::INTEGRITY_VERIFY, self::REPLAY_RUN,
            self::EVIDENCE_GENERATE, self::EVIDENCE_EXPORT, self::RECOVERY_PROPOSE,
            self::RECOVERY_REQUEST_APPROVAL, self::LEGAL_HOLD_MANAGE, self::ADMIN,
        ];
    }

    /**
     * Compatibility fallback for delegated MagicAI administrators on hosts where
     * Titan-specific permissions are not assigned per user. Keep this list
     * deliberately read/diagnostic-only; sensitive actions still need an
     * explicit Rewind permission or Super Admin authority.
     *
     * @return list<string>
     */
    public static function delegatedAdminFallback(): array
    {
        return [self::TRACE_VIEW, self::FORENSICS_VIEW, self::INTEGRITY_VERIFY];
    }
}
