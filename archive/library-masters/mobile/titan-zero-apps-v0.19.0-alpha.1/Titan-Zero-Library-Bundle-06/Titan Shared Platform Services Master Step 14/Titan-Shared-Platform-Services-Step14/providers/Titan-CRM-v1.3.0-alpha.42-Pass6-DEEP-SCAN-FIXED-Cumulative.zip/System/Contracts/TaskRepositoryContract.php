<?php
namespace App\Extensions\Crm\System\Contracts;
interface TaskRepositoryContract { public function search(int $userId,array $filters=[]): array; public function create(int $userId,array $data): array; public function updateStatus(int $userId,string $publicId,string $status): array; }
