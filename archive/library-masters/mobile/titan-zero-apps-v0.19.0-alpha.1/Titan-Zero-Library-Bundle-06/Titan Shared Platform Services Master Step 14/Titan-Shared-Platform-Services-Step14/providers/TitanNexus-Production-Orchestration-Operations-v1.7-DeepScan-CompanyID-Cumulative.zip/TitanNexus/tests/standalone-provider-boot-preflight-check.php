<?php

declare(strict_types=1);

$root = dirname(__DIR__);
require_once $root . '/System/Host/TitanProviderBootPreflight.php';

use App\Extensions\TitanNexus\System\Host\TitanProviderBootPreflight;

function pbAssert(bool $condition, string $message): void {
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

$report = TitanProviderBootPreflight::inspect($root);
pbAssert(($report['status'] ?? null) === 'PASS', 'provider boot preflight must pass');
pbAssert(($report['checks']['provider_entrypoints']['status'] ?? null) === 'PASS', 'provider entrypoints');
pbAssert(($report['checks']['container_bindings']['status'] ?? null) === 'PASS', 'all injected contracts are bound');
pbAssert(($report['checks']['boot_resources']['status'] ?? null) === 'PASS', 'views migrations config routes wired');
pbAssert(($report['checks']['navigation_isolation']['status'] ?? null) === 'PASS', 'navigation failure isolated');
pbAssert(($report['checks']['duplicate_registration']['status'] ?? null) === 'PASS', 'provider route registration idempotency');
pbAssert(($report['checks']['optional_dependencies']['status'] ?? null) === 'PASS', 'optional dependency degradation');
pbAssert(($report['checks']['interface_contribution']['status'] ?? null) === 'PASS', 'interface contribution wiring');

$provider = (string) file_get_contents($root . '/System/TitanNexusServiceProvider.php');
pbAssert(str_contains($provider, "'titan-nexus.routes.registered'"), 'provider must carry an app-scoped route registration guard');
pbAssert(str_contains($provider, "if (\$this->app->bound('titan-nexus.routes.registered'))"), 'route guard must be checked');
pbAssert(str_contains($provider, "\$this->app->instance('titan-nexus.routes.registered', true)"), 'route guard must be set');
pbAssert(!str_contains($provider, 'Kernel $kernel'), 'provider boot must not require unused HTTP Kernel injection');

echo "PROVIDER_BOOT_PREFLIGHT_CHECK: PASS\n";
