# Signal events

This package declares the Signal v1 integration boundary but does not claim emitted or consumed event families in this release.
