<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;

interface SignalEventStoreContract
{
    /** @return array{event:SignalEvent,duplicate:bool,original_event_id:?string} */
    public function append(SignalEnvelope $signal): array;

    public function find(string $eventId, ?int $tenantCompanyId, string $scope): ?SignalEvent;

    /** @return list<SignalEvent> */
    public function byTrace(string $traceId, ?int $tenantCompanyId, string $scope, int $limit): array;

    public function countByTrace(string $traceId, ?int $tenantCompanyId, string $scope): int;

    /** @return list<SignalEvent> */
    public function byCorrelation(string $correlationId, ?int $tenantCompanyId, string $scope, int $limit): array;

    public function countByCorrelation(string $correlationId, ?int $tenantCompanyId, string $scope): int;

    /** @return list<SignalEvent> */
    public function byCausation(string $causationId, ?int $tenantCompanyId, string $scope, int $limit): array;

    /** @return list<SignalEvent> */
    public function byRootCausation(string $rootCausationId, ?int $tenantCompanyId, string $scope, int $limit): array;

    public function causalParentId(string $childEventId, ?int $tenantCompanyId, string $scope): ?string;

    /** @return list<string> */
    public function causalChildIds(string $parentEventId, ?int $tenantCompanyId, string $scope, int $limit): array;

    /** @return list<array{parent_event_id:string,child_event_id:string}> */
    public function causalEdgesByTrace(string $traceId, ?int $tenantCompanyId, string $scope, int $limit): array;

    /** @return list<array{parent_event_id:string,child_event_id:string}> */
    public function causalEdgesByCorrelation(string $correlationId, ?int $tenantCompanyId, string $scope, int $limit): array;
}
