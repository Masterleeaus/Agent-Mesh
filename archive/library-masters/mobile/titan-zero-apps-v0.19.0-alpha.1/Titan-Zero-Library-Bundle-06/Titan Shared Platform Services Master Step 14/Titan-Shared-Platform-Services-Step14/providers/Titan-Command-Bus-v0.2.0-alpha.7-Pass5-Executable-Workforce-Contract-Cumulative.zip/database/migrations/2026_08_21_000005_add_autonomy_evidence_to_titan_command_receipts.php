<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('titan_command_receipts')) {
            return;
        }

        Schema::table('titan_command_receipts', static function (Blueprint $table): void {
            if (! Schema::hasColumn('titan_command_receipts', 'autonomy_reference')) {
                $table->string('autonomy_reference', 191)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_command_receipts', 'autonomy_level')) {
                $table->string('autonomy_level', 32)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_command_receipts', 'autonomy_workflow')) {
                $table->string('autonomy_workflow', 191)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_command_receipts', 'autonomy_evidence')) {
                $table->json('autonomy_evidence')->nullable();
            }
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('titan_command_receipts')) {
            return;
        }

        Schema::table('titan_command_receipts', static function (Blueprint $table): void {
            foreach (['autonomy_evidence', 'autonomy_workflow', 'autonomy_level', 'autonomy_reference'] as $column) {
                if (Schema::hasColumn('titan_command_receipts', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
