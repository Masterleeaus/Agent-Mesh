<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\TitanAutonomy;

final class CrmDeferredAutonomyDecisionPort implements CrmAutonomyDecisionPort
{
    public function workflowKey(string $capability): string
    {
        $key = trim(str_replace(['crm.', '.'], ['', '_'], $capability), '_');
        return $key !== '' ? $key : 'default';
    }

    public function decision(int $actorUserId, int $companyId, string $capability, string $workflowKey): array
    {
        return [
            'contract' => 'titan.autonomy.v1',
            'provider' => 'deferred',
            'capability' => $capability,
            'workflow_key' => $workflowKey !== '' ? $workflowKey : $this->workflowKey($capability),
            'current_level' => 'suggest',
            'next_level' => null,
            'risk' => null,
            'platform_gate_eligible' => false,
            'ai_may_complete' => false,
            'human_approval_required' => true,
            'reason_codes' => ['TITAN_AUTONOMY_UNAVAILABLE'],
        ];
    }
}
