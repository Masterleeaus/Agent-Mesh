<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Extensions\TitanSignalEngine\System\Data\EventTypeDefinition;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Persistence\SignalEventStore;
use App\Extensions\TitanSignalEngine\System\Services\EventTypeRegistry;
use App\Extensions\TitanSignalEngine\System\Services\SignalRegistryAuthority;
use App\Extensions\TitanSignalEngine\System\Services\RegistryOwnershipPolicy;
use App\Extensions\TitanSignalEngine\System\Services\PulseAttentionScorer;
use App\Extensions\TitanSignalEngine\System\Services\PulseProjector;
use App\Extensions\TitanSignalEngine\System\Services\PulseQueryService;
use App\Extensions\TitanSignalEngine\System\Services\PulseSurfaceBuilder;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitter;
use App\Extensions\TitanSignalEngine\System\Services\SignalPayloadGuard;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseProjectedEvent;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseRollup;
use InvalidArgumentException;
use Tests\TestCase;

final class PulseRuntimeIntegrationTest extends TestCase
{
    private SignalEmitter $emitter;
    private \App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority $emitterAuthority;
    private PulseQueryService $pulse;
    private EventTypeRegistry $registry;

    protected function setUp(): void
    {
        parent::setUp();
        foreach (glob(dirname(__DIR__, 2) . '/database/migrations/*.php') ?: [] as $migrationFile) {
            (require $migrationFile)->up();
        }
        config()->set('titan-signal-engine.pulse_missing_receipt_after_seconds', 0);
        config()->set('titan-signal-engine.pulse_stalled_after_seconds', 0);

        $this->emitterAuthority = new \App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority('feature-test-secret', [
            'test-service:pulse-test:root' => [
                'source' => 'pulse-test',
                'source_component' => null,
                'permissions' => ['signal.emit'],
                'event_type_patterns' => ['*'],
            ],
        ]);
        $validator = new SignalContextValidator($this->emitterAuthority);
        $registryAuthority = new SignalRegistryAuthority('feature-registry-secret', [
            'test-registry' => [
                'owner_source' => 'test-suite',
                'permissions' => ['signal.registry.event.manage', 'signal.registry.override'],
                'event_type_patterns' => ['*'],
                'subscriber_key_patterns' => ['*'],
            ],
        ]);
        $registryIdentity = $registryAuthority->issue('test-registry');
        $ownership = new RegistryOwnershipPolicy($registryAuthority);
        $this->registry = new EventTypeRegistry($ownership);
        foreach (['command.executed', 'execution.receipt', 'test.signal'] as $type) {
            $this->registry->register(EventTypeDefinition::fromArray([
                'event_type' => $type,
                'current_schema_version' => 1,
                'supported_schema_versions' => [1],
                'category' => $type === 'test.signal' ? 'test' : 'operations',
                'allowed_scopes' => ['tenant'],
                'required_payload_fields' => [],
                'optional_payload_fields' => ['value'],
                'allow_additional_payload_fields' => false,
                'owner_source' => 'pulse-test',
                'allowed_severities' => ['info', 'error', 'critical'],
            ]), $registryIdentity);
        }
        $projector = new PulseProjector();
        $this->emitter = new SignalEmitter(new SignalEventStore(), $this->registry, $validator, new SignalPayloadGuard(65536, 8192, []), null, $projector);
        $this->pulse = new PulseQueryService($validator, new PulseAttentionScorer(), new PulseSurfaceBuilder());
    }


    private function emitTrusted(
        \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope|array $signal,
        ?\App\Extensions\TitanSignalEngine\System\Data\SignalContext $context = null,
    ): \App\Extensions\TitanSignalEngine\System\Data\SignalReceipt {
        $source = is_array($signal) ? (string) ($signal['source'] ?? 'test-suite') : $signal->source;
        $component = is_array($signal) ? ($signal['source_component'] ?? null) : $signal->sourceComponent;
        $scope = is_array($signal) ? (string) ($signal['scope'] ?? 'tenant') : $signal->scope;
        $tenant = is_array($signal) ? ($signal['tenant_company_id'] ?? null) : $signal->tenantCompanyId;
        $serviceId = 'test-service:' . $source . ':' . ($component ?? 'root');
        $identity = $this->emitterAuthority->issue($serviceId);
        if ($context === null) {
            $context = $scope === 'system'
                ? \App\Extensions\TitanSignalEngine\System\Data\SignalContext::system('test-system', 'test', ['signal.tenant.emit'], $identity)
                : \App\Extensions\TitanSignalEngine\System\Data\SignalContext::tenantHuman((int) $tenant, 'test-user', 'test-session', 'test', $identity);
        } else {
            $context = new \App\Extensions\TitanSignalEngine\System\Data\SignalContext(
                $context->scope,
                $context->tenantCompanyId,
                $context->actor,
                $context->permissions,
                $identity,
            );
        }

        return $this->emitter->emit($signal, $context);
    }

    public function test_emit_projects_rollups_exactly_once_and_snapshot_uses_them(): void
    {
        $input = ['event_type' => 'test.signal', 'tenant_company_id' => 1, 'source' => 'pulse-test', 'idempotency_key' => 'pulse-once', 'severity' => 'error', 'category' => 'test', 'payload' => ['value' => 1]];
        $first = $this->emitTrusted($input);
        $second = $this->emitTrusted($input);

        self::assertSame($first->eventId, $second->eventId);
        self::assertSame(1, SignalPulseProjectedEvent::query()->where('event_id', $first->eventId)->count());
        self::assertSame(3, SignalPulseRollup::query()->where('tenant_company_id', 1)->where('dimension', 'all')->count());

        $snapshot = $this->pulse->snapshot(SignalContext::tenantHuman(1, 'reader-1', 'sess-1', 'test'), 1, 'tenant', '5m');
        self::assertSame(1, $snapshot->metrics['event_count']);
        self::assertSame(1, $snapshot->metrics['error_count']);
        self::assertSame('pulse-test', $snapshot->sources[0]['key']);
    }

    public function test_missing_execution_receipt_is_exposed_without_scanning_raw_events(): void
    {
        $this->emitTrusted(['event_type' => 'command.executed', 'tenant_company_id' => 1, 'source' => 'pulse-test', 'category' => 'operations', 'payload' => []]);
        $snapshot = $this->pulse->snapshot(SignalContext::tenantHuman(1, 'reader-1', 'sess-1', 'test'), 1, 'tenant', '5m');
        self::assertSame(1, $snapshot->metrics['missing_receipt_count']);
    }

    public function test_pulse_query_enforces_tenant_context(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->pulse->snapshot(SignalContext::tenantHuman(1, 'usr_1', 'sess_1', 'titan-auth'), 2, 'tenant', '5m');
    }

    public function test_surface_is_a_compact_zero_friendly_read_model(): void
    {
        $this->emitTrusted(['event_type' => 'test.signal', 'tenant_company_id' => 1, 'source' => 'pulse-test', 'severity' => 'critical', 'category' => 'test', 'payload' => ['value' => 7]]);
        $surface = $this->pulse->surface(SignalContext::tenantHuman(1, 'reader-1', 'sess-1', 'test'), 1, 'tenant', '5m');
        self::assertArrayHasKey('headline', $surface);
        self::assertArrayHasKey('attention', $surface);
        self::assertArrayHasKey('top_sources', $surface);
    }

    public function test_projection_freshness_is_tenant_scoped(): void
    {
        $this->emitTrusted(['event_type' => 'test.signal', 'tenant_company_id' => 1, 'source' => 'pulse-test', 'category' => 'test', 'payload' => ['value' => 1]]);
        $one = $this->pulse->snapshot(SignalContext::tenantHuman(1, 'reader-1', 'sess-1', 'test'), 1, 'tenant', '5m');
        $two = $this->pulse->snapshot(SignalContext::tenantHuman(2, 'reader-2', 'sess-2', 'test'), 2, 'tenant', '5m');
        self::assertSame('healthy', $one->health['status']);
        self::assertSame('idle', $two->health['status']);
    }

    public function test_multiple_commands_in_one_trace_have_independent_receipt_latency(): void
    {
        $trace = \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope::uuidV7();
        $correlation = \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope::uuidV7();
        $cmd1 = $this->emitTrusted(['event_type' => 'command.executed', 'tenant_company_id' => 1, 'source' => 'pulse-test', 'category' => 'operations', 'trace_id' => $trace, 'correlation_id' => $correlation, 'payload' => []]);
        $cmd2 = $this->emitTrusted(['event_type' => 'command.executed', 'tenant_company_id' => 1, 'source' => 'pulse-test', 'category' => 'operations', 'trace_id' => $trace, 'correlation_id' => $correlation, 'payload' => []]);
        $this->emitTrusted(['event_type' => 'execution.receipt', 'tenant_company_id' => 1, 'source' => 'pulse-test', 'category' => 'operations', 'trace_id' => $trace, 'correlation_id' => $correlation, 'causation_id' => $cmd1->eventId, 'payload' => []]);
        $this->emitTrusted(['event_type' => 'execution.receipt', 'tenant_company_id' => 1, 'source' => 'pulse-test', 'category' => 'operations', 'trace_id' => $trace, 'correlation_id' => $correlation, 'causation_id' => $cmd2->eventId, 'payload' => []]);
        self::assertSame(2, \App\Extensions\TitanSignalEngine\System\Models\SignalPulseCommandReceipt::query()->where('trace_id', $trace)->whereNotNull('receipt_event_id')->count());
        $snapshot = $this->pulse->snapshot(SignalContext::tenantHuman(1, 'reader-1', 'sess-1', 'test'), 1, 'tenant', '5m');
        self::assertSame(2, $snapshot->latency['command_receipt_ms']['count']);
    }

}
