<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Extensions\TitanSignalEngine\System\Data\SignalConsoleRequest;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Services\SignalConsoleContextFactory;
use Illuminate\Http\Request;
use Illuminate\Session\Store;
use Illuminate\Session\ArraySessionHandler;
use Tests\TestCase;

final class ConsoleRuntimeIntegrationTest extends TestCase
{
    public function test_admin_context_can_switch_between_system_and_explicit_tenant_without_actor_spoofing(): void
    {
        $user = new class {
            public function getAuthIdentifier(): int { return 77; }
        };
        $request = Request::create('/dashboard/admin/titan-signal-engine', 'GET');
        $request->setUserResolver(static fn () => $user);
        $request->setLaravelSession(new Store('test', new ArraySessionHandler(60)));
        $factory = new SignalConsoleContextFactory();

        $system = $factory->forAdmin($request, SignalConsoleRequest::fromArray(['scope' => 'system']));
        self::assertSame('system', $system->scope);
        self::assertTrue($system->hasPermission('signal.system.read'));

        $tenant = $factory->forAdmin($request, SignalConsoleRequest::fromArray(['scope' => 'tenant', 'tenant_company_id' => 42]));
        self::assertSame('tenant', $tenant->scope);
        self::assertSame(42, $tenant->tenantCompanyId);
        self::assertNull($tenant->actor->tenantCompanyId);
        self::assertTrue($tenant->hasPermission('signal.retention.manage'));
    }

    public function test_tenant_context_comes_from_authenticated_user_not_query_input(): void
    {
        $user = new class {
            public int $tenant_company_id = 9;
            public function getAuthIdentifier(): int { return 88; }
        };
        $request = Request::create('/dashboard/user/titan-signal-engine?tenant_company_id=999', 'GET');
        $request->setUserResolver(static fn () => $user);
        $request->setLaravelSession(new Store('test', new ArraySessionHandler(60)));

        $context = (new SignalConsoleContextFactory())->forTenant($request);
        self::assertSame(9, $context->tenantCompanyId);
        self::assertSame(9, $context->actor->tenantCompanyId);
    }
}
