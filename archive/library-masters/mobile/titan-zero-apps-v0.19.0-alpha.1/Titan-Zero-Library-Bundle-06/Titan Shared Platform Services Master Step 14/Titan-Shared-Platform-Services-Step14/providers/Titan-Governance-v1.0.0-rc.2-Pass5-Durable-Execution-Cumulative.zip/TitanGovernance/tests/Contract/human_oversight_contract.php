<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);function fail_ho(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function same_ho(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_ho($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}function ok_ho(bool $c,string $m):void{if(!$c)fail_ho($m);}
$f=$root.'/System/ControlCentre/HumanOversightProjector.php';if(!is_file($f))fail_ho('missing HumanOversightProjector');require_once $f;
use App\Extensions\TitanGovernance\System\ControlCentre\HumanOversightProjector;
$workforce=['status'=>'HEALTHY','approvals'=>[
 ['task_id'=>'task-current','title'=>'Current','manager_id'=>2,'manager'=>'Finance Manager','status'=>'UNDER_REVIEW','updated_at'=>'2026-08-21T03:50:00+10:00','priority'=>40],
 ['task_id'=>'task-aging','title'=>'Aging','manager_id'=>2,'manager'=>'Finance Manager','status'=>'UNDER_REVIEW','updated_at'=>'2026-08-21T02:20:00+10:00','priority'=>60],
 ['task_id'=>'task-overdue','title'=>'Overdue','manager_id'=>9,'manager'=>'Ops Manager','status'=>'ESCALATED','updated_at'=>'2026-08-20T22:00:00+10:00','priority'=>95],
 ],'handoffs'=>[['handoff_id'=>'handoff-1','task_id'=>'task-overdue','status'=>'ESCALATED','updated_at'=>'2026-08-20T23:00:00+10:00','receiver_manager_id'=>9]],'queues'=>[]];
$decisions=[
 ['decision_id'=>'d1','subject_type'=>'workforce_task','subject_id'=>'task-overdue','action'=>'APPROVE','decided_at'=>'2026-08-21T03:00:00+10:00','actor_id'=>11],
 ['decision_id'=>'d2','subject_type'=>'invoice','subject_id'=>'INV-1','action'=>'APPROVE','decided_at'=>'2026-08-21T03:10:00+10:00','actor_id'=>11],
];
$p=new HumanOversightProjector();$r=$p->project($workforce,$decisions,['now'=>'2026-08-21T04:00:00+10:00','approval_warning_seconds'=>3600,'approval_critical_seconds'=>14400]);
$by=[];foreach($r['approvals'] as $row)$by[$row['task_id']]=$row;
same_ho('CURRENT',$by['task-current']['age_status'],'current approval');same_ho('AGING',$by['task-aging']['age_status'],'aging approval');same_ho('OVERDUE',$by['task-overdue']['age_status'],'overdue approval');$work=[];foreach($r['operator_workload'] as $row)$work[(string)($row['manager_id']??'')]= $row;same_ho(2,$work['2']['open_approvals'],'finance manager workload count');same_ho(1,count($r['intervention_history']),'only workforce-linked governance decision retained');same_ho('d1',$r['intervention_history'][0]['decision_id'],'workforce intervention id');same_ho(false,$r['can_raise_authority'],'human oversight does not raise authority');
echo "PASS: Governance human oversight contract\n";
