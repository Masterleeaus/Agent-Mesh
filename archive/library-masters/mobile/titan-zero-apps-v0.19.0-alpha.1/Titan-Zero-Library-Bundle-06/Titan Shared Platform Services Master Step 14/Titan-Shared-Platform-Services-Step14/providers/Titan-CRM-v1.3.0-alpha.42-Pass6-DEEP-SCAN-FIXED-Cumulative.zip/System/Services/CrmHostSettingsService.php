<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Models\Setting;
use Illuminate\Support\Facades\Schema;

final class CrmHostSettingsService
{
    private const FLAGS = [
        'crm_enabled',
        'crm_assistant_enabled',
        'crm_presentations_enabled',
    ];

    public function all(): array
    {
        $setting = Setting::getCache();
        $out = [];
        foreach (self::FLAGS as $flag) {
            $out[$flag] = (bool) ($setting?->getAttribute($flag) ?? true);
        }
        return $out;
    }

    public function update(array $data): array
    {
        abort_unless(Schema::hasTable('settings'), 500, 'MagicAI settings table is unavailable.');
        $setting = Setting::query()->first();
        abort_unless($setting, 500, 'MagicAI settings row is unavailable.');

        foreach (self::FLAGS as $flag) {
            if (array_key_exists($flag, $data) && Schema::hasColumn('settings', $flag)) {
                $setting->setAttribute($flag, (bool) $data[$flag]);
            }
        }

        $setting->save();
        Setting::forgetCache();

        return $this->all();
    }
}
