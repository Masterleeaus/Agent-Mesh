<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\{AutonomyQueryContract,OperationsQueryContract,OperationsReviewStoreContract};
use RuntimeException;

final class AutonomyOperationsService
{
    public function __construct(
        private readonly OperationsQueryContract $operations,
        private readonly OperationsReviewStoreContract $reviews,
        private readonly AutonomyQueryContract $autonomy,
        private readonly OperationsStatusClassifier $classifier,
    ) {}

    public function queue(int $tenantCompanyId, array $filters = []): array
    {
        $rows = $this->operations->receipts($tenantCompanyId, [
            'capability'=>(string)($filters['capability']??''),
        ], 500);
        $items=[];
        $summary=['total'=>0,'attention'=>0,'observing'=>0,'due'=>0,'human_review'=>0,'exceptions'=>0,'regressions'=>0,'verified'=>0];
        foreach($rows as $row){
            $ops=$this->classifier->classify($row);
            $item=$row+['operations'=>$ops];
            $summary['total']++;
            if($ops['attention'])$summary['attention']++;
            if($ops['status']==='observing')$summary['observing']++;
            if($ops['status']==='due_for_reconciliation')$summary['due']++;
            if($ops['status']==='awaiting_human_verification')$summary['human_review']++;
            if(in_array($ops['status'],['verification_failed','execution_failed','assurance_red','assurance_amber','exception','reversed','materially_corrected','rejected','verification_inconclusive'],true))$summary['exceptions']++;
            if(in_array('regression',$ops['flags'],true))$summary['regressions']++;
            if($ops['status']==='verified_correct')$summary['verified']++;
            $statusFilter=(string)($filters['status']??'attention');
            if($statusFilter==='attention'&&!$ops['attention'])continue;
            if($statusFilter==='pending'&&!in_array($ops['status'],['observing','due_for_reconciliation','awaiting_human_verification'],true))continue;
            if($statusFilter!=='all'&&$statusFilter!=='attention'&&$statusFilter!=='pending'&&$statusFilter!==$ops['status'])continue;
            $items[]=$item;
        }
        usort($items,function(array $a,array $b):int{
            $p=((int)($b['operations']['priority']??0))<=>((int)($a['operations']['priority']??0));
            if($p!==0)return $p;
            return strcmp((string)($b['created_at']??''),(string)($a['created_at']??''));
        });
        return ['summary'=>$summary,'items'=>array_slice($items,0,200),'filters'=>$filters];
    }

    public function detail(int $tenantCompanyId, string $correlationId): array
    {
        $receipt=$this->operations->receipt($tenantCompanyId,trim($correlationId));
        if($receipt===null)throw new RuntimeException('EXECUTION_RECEIPT_NOT_FOUND');
        $capability=(string)($receipt['capability']??'');
        $workflow=(string)($receipt['workflow_key']??'');
        return [
            'receipt'=>$receipt,
            'operations'=>$this->classifier->classify($receipt),
            'feedback'=>$this->operations->feedback($tenantCompanyId,(string)$receipt['public_id'],100),
            'reviews'=>$this->reviews->forReceipt($tenantCompanyId,(string)$receipt['public_id'],100),
            'state'=>$this->autonomy->capabilityState($tenantCompanyId,$capability,$workflow),
            'regressions'=>$this->autonomy->regressions($tenantCompanyId,$capability,$workflow,25),
        ];
    }
}
