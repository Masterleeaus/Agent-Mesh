<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Services;

use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterRegistryContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandApprovalGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAssuranceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAutonomyGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandBusContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandGovernanceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandLifecycleStoreContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandReceiptStoreContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandRiskGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandSignalEmitterContract;
use App\Extensions\TitanCommandBus\System\DTO\AssuranceDecision;
use App\Extensions\TitanCommandBus\System\DTO\AutonomyDecision;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandExecutionResult;
use App\Extensions\TitanCommandBus\System\DTO\CommandReceipt;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use Throwable;

final class CommandBus implements CommandBusContract
{
    public function __construct(
        private readonly CommandAdapterRegistryContract $adapters,
        private readonly CommandRiskGateContract $risk,
        private readonly CommandAssuranceGateContract $assurance,
        private readonly CommandGovernanceGateContract $governance,
        private readonly CommandReceiptStoreContract $store,
        private readonly CommandSignalEmitterContract $signals,
        private readonly ?CommandAutonomyGateContract $autonomy = null,
        private readonly ?CommandApprovalGateContract $approval = null,
        private readonly ?CommandLifecycleStoreContract $lifecycle = null,
    ) {}

    public function dispatch(CommandContext $context, CommandRequest $request): CommandReceipt
    {
        $requestHash = $request->requestHash();
        $operationId = hash('sha256', $context->tenantCompanyId . '|' . $request->idempotencyKey . '|' . $request->capability);

        if (! (bool) config('titan-command-bus.enabled', true) || (bool) config('titan-command-bus.kill_switch', false)) {
            return $this->blocked($context, $request, $operationId, $requestHash, 'COMMAND_BUS_DISABLED');
        }
        $payloadBytes = strlen(json_encode($request->payload, JSON_THROW_ON_ERROR));
        if ($payloadBytes > (int) config('titan-command-bus.max_payload_bytes', 65536)) {
            return $this->blocked($context, $request, $operationId, $requestHash, 'PAYLOAD_TOO_LARGE');
        }

        $existing = $this->store->existing($context, $request);
        if ($existing !== null) {
            if (! hash_equals((string) $existing['request_hash'], $requestHash)) {
                return $this->blocked($context, $request, $operationId, $requestHash, 'IDEMPOTENCY_KEY_PAYLOAD_MISMATCH');
            }
            return $this->replay($context, $request, $operationId, $requestHash, $existing);
        }

        if (! $this->store->claim($context, $request, $operationId, $requestHash)) {
            $existing = $this->store->existing($context, $request);
            if ($existing !== null && hash_equals((string) $existing['request_hash'], $requestHash) && $existing['receipt'] !== null) {
                return $this->replay($context, $request, $operationId, $requestHash, $existing);
            }
            return $this->blocked($context, $request, $operationId, $requestHash, 'IDEMPOTENCY_IN_FLIGHT');
        }

        $lifecycleRequired = (bool) config('titan-command-bus.require_lifecycle', true);
        if ($lifecycleRequired && ($this->lifecycle === null || ! $this->lifecycle->available())) {
            return $this->persistBlocked($context, $request, $operationId, $requestHash, 'LIFECYCLE_UNAVAILABLE', false);
        }
        if ($this->lifecycle !== null && $this->lifecycle->available()) {
            try {
                $this->lifecycle->begin($context, $request, $operationId, $requestHash);
                $this->lifecycle->transition($context, $request, $operationId, CommandLifecycleState::PREFLIGHT);
            } catch (Throwable) {
                return $this->persistBlocked($context, $request, $operationId, $requestHash, 'LIFECYCLE_PERSISTENCE_FAILED', false);
            }
        }

        $this->emit('command.requested', $context, $request, $operationId, null, null);

        if ($request->preparedOffline && ! (bool) config('titan-command-bus.allow_offline_revalidation', true)) {
            return $this->persistBlocked($context, $request, $operationId, $requestHash, 'OFFLINE_REVALIDATION_DISABLED', false);
        }
        if ((bool) config('titan-command-bus.require_signal', true) && ! $this->signals->available()) {
            return $this->persistBlocked($context, $request, $operationId, $requestHash, 'SIGNAL_UNAVAILABLE', false);
        }

        $adapter = $this->adapters->forCapability($request->capability);
        if ($adapter === null) {
            return $this->persistBlocked($context, $request, $operationId, $requestHash, 'CAPABILITY_UNAVAILABLE', false);
        }

        $riskRequired = (bool) config('titan-command-bus.require_risk', true);
        if ($riskRequired && ! $this->risk->available()) {
            return $this->persistBlocked($context, $request, $operationId, $requestHash, 'RISK_UNAVAILABLE', false);
        }

        $risk = $this->risk->available()
            ? $this->risk->assess($context, $request)
            : null;

        if ($riskRequired) {
            if ($risk === null || ! $risk->allowed || $risk->reference === null || $risk->reference === '' || $risk->riskClass === null || $risk->riskClass === '') {
                $reason = $risk === null
                    ? 'RISK_DECISION_INVALID'
                    : (! $risk->allowed ? ($risk->reasonCode ?: 'RISK_DENIED') : 'RISK_DECISION_INVALID');
                return $this->persistBlocked(
                    $context,
                    $request,
                    $operationId,
                    $requestHash,
                    $reason,
                    false,
                    null,
                    $risk?->reference,
                    $risk?->riskClass,
                    $risk?->riskScore,
                );
            }
        } elseif ($risk !== null && ! $risk->allowed) {
            return $this->persistBlocked(
                $context,
                $request,
                $operationId,
                $requestHash,
                $risk->reasonCode ?: 'RISK_DENIED',
                false,
                null,
                $risk->reference,
                $risk->riskClass,
                $risk->riskScore,
            );
        }

        $assuranceRequired = (bool) config('titan-command-bus.require_assurance', true);
        if ($assuranceRequired && ! $this->assurance->available()) {
            return $this->persistBlocked(
                $context,
                $request,
                $operationId,
                $requestHash,
                'ASSURANCE_UNAVAILABLE',
                false,
                null,
                $risk?->reference,
                $risk?->riskClass,
                $risk?->riskScore,
            );
        }

        $assurance = $this->assurance->available()
            ? $this->assurance->assess($context, $request, $risk)
            : null;

        if ($assuranceRequired) {
            if ($assurance === null || ! $assurance->allowed || $assurance->reference === null || $assurance->reference === '' || $assurance->assuranceLevel === null || $assurance->assuranceLevel === '') {
                $reason = $assurance === null
                    ? 'ASSURANCE_DECISION_INVALID'
                    : (! $assurance->allowed ? ($assurance->reasonCode ?: 'ASSURANCE_DENIED') : 'ASSURANCE_DECISION_INVALID');
                return $this->persistBlocked(
                    $context,
                    $request,
                    $operationId,
                    $requestHash,
                    $reason,
                    false,
                    null,
                    $risk?->reference,
                    $risk?->riskClass,
                    $risk?->riskScore,
                    null,
                    $assurance?->reference,
                    $assurance?->assuranceLevel,
                    $assurance?->evidenceReferences ?? [],
                );
            }
        } elseif ($assurance !== null && ! $assurance->allowed) {
            return $this->persistBlocked(
                $context,
                $request,
                $operationId,
                $requestHash,
                $assurance->reasonCode ?: 'ASSURANCE_DENIED',
                false,
                null,
                $risk?->reference,
                $risk?->riskClass,
                $risk?->riskScore,
                null,
                $assurance->reference,
                $assurance->assuranceLevel,
                $assurance->evidenceReferences,
            );
        }

        $autonomyRequired = (bool) config('titan-command-bus.require_autonomy', true);
        if ($autonomyRequired && ($this->autonomy === null || ! $this->autonomy->available())) {
            return $this->persistBlocked(
                $context,
                $request,
                $operationId,
                $requestHash,
                'AUTONOMY_UNAVAILABLE',
                false,
                null,
                $risk?->reference,
                $risk?->riskClass,
                $risk?->riskScore,
                null,
                $assurance?->reference,
                $assurance?->assuranceLevel,
                $assurance?->evidenceReferences ?? [],
            );
        }

        $autonomy = ($this->autonomy !== null && $this->autonomy->available())
            ? $this->autonomy->resolve($context, $request, $risk, $assurance)
            : null;

        if ($autonomyRequired) {
            if ($autonomy === null || ! $autonomy->allowed || $autonomy->reference === null || $autonomy->reference === '' || $autonomy->level === null || ! $this->validAutonomyLevel($autonomy->level)) {
                $reason = $autonomy === null
                    ? 'AUTONOMY_DECISION_INVALID'
                    : (! $autonomy->allowed ? ($autonomy->reasonCode ?: 'AUTONOMY_DENIED') : 'AUTONOMY_DECISION_INVALID');
                return $this->persistBlocked(
                    $context,
                    $request,
                    $operationId,
                    $requestHash,
                    $reason,
                    false,
                    null,
                    $risk?->reference,
                    $risk?->riskClass,
                    $risk?->riskScore,
                    null,
                    $assurance?->reference,
                    $assurance?->assuranceLevel,
                    $assurance?->evidenceReferences ?? [],
                    $autonomy?->reference,
                    $autonomy?->level,
                    $autonomy?->workflowKey,
                    $autonomy?->evidenceReferences ?? [],
                );
            }
        } elseif ($autonomy !== null && ! $autonomy->allowed) {
            return $this->persistBlocked(
                $context,
                $request,
                $operationId,
                $requestHash,
                $autonomy->reasonCode ?: 'AUTONOMY_DENIED',
                false,
                null,
                $risk?->reference,
                $risk?->riskClass,
                $risk?->riskScore,
                null,
                $assurance?->reference,
                $assurance?->assuranceLevel,
                $assurance?->evidenceReferences ?? [],
                $autonomy->reference,
                $autonomy->level,
                $autonomy->workflowKey,
                $autonomy->evidenceReferences,
            );
        }

        if (! $this->governance->available()) {
            return $this->persistBlocked(
                $context,
                $request,
                $operationId,
                $requestHash,
                'GOVERNANCE_UNAVAILABLE',
                false,
                null,
                $risk?->reference,
                $risk?->riskClass,
                $risk?->riskScore,
                null,
                $assurance?->reference,
                $assurance?->assuranceLevel,
                $assurance?->evidenceReferences ?? [],
                $autonomy?->reference,
                $autonomy?->level,
                $autonomy?->workflowKey,
                $autonomy?->evidenceReferences ?? [],
            );
        }

        $decision = $this->governance->evaluate($context, $request, $risk, $assurance, $autonomy);
        if (! $decision->allowed || $decision->reference === null || $decision->reference === '') {
            return $this->persistBlocked(
                $context,
                $request,
                $operationId,
                $requestHash,
                $decision->reasonCode ?: 'GOVERNANCE_DENIED',
                true,
                $decision->reference,
                $risk?->reference,
                $risk?->riskClass,
                $risk?->riskScore,
                $decision->approvalReference,
                $assurance?->reference,
                $assurance?->assuranceLevel,
                $assurance?->evidenceReferences ?? [],
                $autonomy?->reference,
                $autonomy?->level,
                $autonomy?->workflowKey,
                $autonomy?->evidenceReferences ?? [],
            );
        }

        $this->transitionLifecycle($context, $request, $operationId, CommandLifecycleState::GOVERNED, null, [
            'risk_reference' => $risk?->reference,
            'assurance_reference' => $assurance?->reference,
            'autonomy_reference' => $autonomy?->reference,
            'governance_reference' => $decision->reference,
        ]);

        $approval = null;
        if ($decision->approvalRequired) {
            if ((bool) config('titan-command-bus.require_approval_verification', true) && ($this->approval === null || ! $this->approval->available())) {
                return $this->persistBlocked($context, $request, $operationId, $requestHash, 'APPROVAL_UNAVAILABLE', true, $decision->reference, $risk?->reference, $risk?->riskClass, $risk?->riskScore, $decision->approvalReference, $assurance?->reference, $assurance?->assuranceLevel, $assurance?->evidenceReferences ?? [], $autonomy?->reference, $autonomy?->level, $autonomy?->workflowKey, $autonomy?->evidenceReferences ?? []);
            }
            $approval = $this->approval->verify($context, $request, $decision, $risk, $assurance, $autonomy);
            $expectedScope = hash('sha256', $context->tenantCompanyId.'|'.$request->capability.'|'.$requestHash);
            if (! $approval->allowed || $approval->reference === null || $approval->reference === '' || $approval->scopeHash === null || ! hash_equals($expectedScope, $approval->scopeHash)) {
                $reason = ! $approval->allowed ? ($approval->reasonCode ?: 'APPROVAL_DENIED') : 'APPROVAL_SCOPE_MISMATCH';
                return $this->persistBlocked($context, $request, $operationId, $requestHash, $reason, true, $decision->reference, $risk?->reference, $risk?->riskClass, $risk?->riskScore, $approval->reference ?? $decision->approvalReference, $assurance?->reference, $assurance?->assuranceLevel, $assurance?->evidenceReferences ?? [], $autonomy?->reference, $autonomy?->level, $autonomy?->workflowKey, $autonomy?->evidenceReferences ?? []);
            }
            if ($approval->expiresAt !== null && strtotime($approval->expiresAt) <= time()) {
                return $this->persistBlocked($context, $request, $operationId, $requestHash, 'APPROVAL_EXPIRED', true, $decision->reference, $risk?->reference, $risk?->riskClass, $risk?->riskScore, $approval->reference, $assurance?->reference, $assurance?->assuranceLevel, $assurance?->evidenceReferences ?? [], $autonomy?->reference, $autonomy?->level, $autonomy?->workflowKey, $autonomy?->evidenceReferences ?? []);
            }
        }

        $this->transitionLifecycle($context, $request, $operationId, CommandLifecycleState::AUTHORIZED, null, [
            'risk_reference' => $risk?->reference,
            'assurance_reference' => $assurance?->reference,
            'autonomy_reference' => $autonomy?->reference,
            'governance_reference' => $decision->reference,
            'approval_reference' => $approval?->reference ?? $decision->approvalReference,
        ]);
        $this->transitionLifecycle($context, $request, $operationId, CommandLifecycleState::EXECUTING, null, [
            'adapter' => $adapter::class,
        ]);

        try {
            $result = $adapter->execute($context, $request, $operationId);
            $receipt = $this->applied(
                $context,
                $request,
                $operationId,
                $requestHash,
                $decision->reference,
                $risk?->reference,
                $risk?->riskClass,
                $risk?->riskScore,
                $assurance?->reference,
                $assurance?->assuranceLevel,
                $assurance?->evidenceReferences ?? [],
                $autonomy?->reference,
                $autonomy?->level,
                $autonomy?->workflowKey,
                $autonomy?->evidenceReferences ?? [],
                $approval?->reference ?? $decision->approvalReference,
                $adapter::class,
                $result,
            );
            $this->store->complete($receipt);
            $this->transitionLifecycle($context, $request, $operationId, CommandLifecycleState::COMPLETED, null, [
                'governance_reference' => $receipt->governanceReference,
                'approval_reference' => $receipt->approvalReference,
                'adapter' => $receipt->adapter,
                'domain_receipt_reference' => $receipt->domainReceiptReference,
            ]);
            $this->emit('command.completed', $context, $request, $operationId, $receipt->status, null, $receipt);
            return $receipt;
        } catch (Throwable $e) {
            $receipt = $this->failed(
                $context,
                $request,
                $operationId,
                $requestHash,
                $decision->reference,
                $risk?->reference,
                $risk?->riskClass,
                $risk?->riskScore,
                $assurance?->reference,
                $assurance?->assuranceLevel,
                $assurance?->evidenceReferences ?? [],
                $autonomy?->reference,
                $autonomy?->level,
                $autonomy?->workflowKey,
                $autonomy?->evidenceReferences ?? [],
                $approval?->reference ?? $decision->approvalReference,
                $adapter::class,
                'ADAPTER_FAILURE',
            );
            $this->store->complete($receipt);
            $this->transitionLifecycle($context, $request, $operationId, CommandLifecycleState::FAILED, 'ADAPTER_FAILURE', [
                'governance_reference' => $receipt->governanceReference,
                'approval_reference' => $receipt->approvalReference,
                'adapter' => $receipt->adapter,
            ]);
            $this->emit('command.failed', $context, $request, $operationId, $receipt->status, 'ADAPTER_FAILURE', $receipt);
            return $receipt;
        }
    }

    public function health(): array
    {
        $db = $this->store->health();
        $dbReady = ! in_array(false, $db, true);
        $riskReady = ! (bool) config('titan-command-bus.require_risk', true) || $this->risk->available();
        $assuranceReady = ! (bool) config('titan-command-bus.require_assurance', true) || $this->assurance->available();
        $autonomyReady = ! (bool) config('titan-command-bus.require_autonomy', true) || ($this->autonomy !== null && $this->autonomy->available());
        $governanceReady = $this->governance->available();
        $approvalReady = ! (bool) config('titan-command-bus.require_approval_verification', true) || ($this->approval !== null && $this->approval->available());
        $lifecycleReady = ! (bool) config('titan-command-bus.require_lifecycle', true) || ($this->lifecycle !== null && $this->lifecycle->available());
        $signalReady = ! (bool) config('titan-command-bus.require_signal', true) || $this->signals->available();
        $readiness = (bool) config('titan-command-bus.enabled', true)
            && ! (bool) config('titan-command-bus.kill_switch', false)
            && $dbReady
            && $riskReady
            && $assuranceReady
            && $autonomyReady
            && $governanceReady
            && $approvalReady
            && $lifecycleReady
            && $signalReady;

        return [
            'engine' => 'titan-command-bus',
            'version' => '0.2.0-alpha.7',
            'liveness' => true,
            'readiness' => $readiness,
            'operational_status' => $readiness ? 'HEALTHY' : 'DEGRADED',
            'registered_adapters' => $this->adapters->count(),
            'dependencies' => [
                'database' => $db,
                'risk' => $riskReady,
                'assurance' => $assuranceReady,
                'autonomy' => $autonomyReady,
                'governance' => $governanceReady,
                'approval' => $approvalReady,
                'lifecycle' => $lifecycleReady,
                'signal' => $signalReady,
            ],
            'kill_switch' => (bool) config('titan-command-bus.kill_switch', false),
        ];
    }

    private function applied(
        CommandContext $c,
        CommandRequest $r,
        string $op,
        string $hash,
        string $gov,
        ?string $riskReference,
        ?string $riskClass,
        ?float $riskScore,
        ?string $assuranceReference,
        ?string $assuranceLevel,
        array $assuranceEvidence,
        ?string $autonomyReference,
        ?string $autonomyLevel,
        ?string $autonomyWorkflow,
        array $autonomyEvidence,
        ?string $approval,
        string $adapter,
        CommandExecutionResult $result,
    ): CommandReceipt {
        return new CommandReceipt(
            operationId: $op,
            idempotencyKey: $r->idempotencyKey,
            requestHash: $hash,
            tenantCompanyId: $c->companyId,
            serviceId: $c->serviceId,
            actorType: $c->actorType,
            actorId: $c->actorId,
            capability: $r->capability,
            status: 'applied',
            traceId: $r->traceId,
            correlationId: $r->correlationId,
            causationId: $r->causationId,
            rootCausationId: $r->rootCausationId,
            freshGovernance: true,
            governanceReference: $gov,
            riskReference: $riskReference,
            riskClass: $riskClass,
            riskScore: $riskScore,
            assuranceReference: $assuranceReference,
            assuranceLevel: $assuranceLevel,
            assuranceEvidence: $assuranceEvidence,
            autonomyReference: $autonomyReference,
            autonomyLevel: $autonomyLevel,
            autonomyWorkflow: $autonomyWorkflow,
            autonomyEvidence: $autonomyEvidence,
            approvalReference: $approval,
            adapter: $adapter,
            domainReceiptReference: $result->domainReceiptReference,
            writeVerified: $result->writeVerified,
            expectedEntityVersion: $r->expectedEntityVersion,
            resultEntityType: $result->resultEntityType,
            resultEntityId: $result->resultEntityId,
            resultEntityVersion: $result->resultEntityVersion,
            metadata: $result->metadata,
        );
    }

    private function failed(
        CommandContext $c,
        CommandRequest $r,
        string $op,
        string $hash,
        ?string $gov,
        ?string $riskReference,
        ?string $riskClass,
        ?float $riskScore,
        ?string $assuranceReference,
        ?string $assuranceLevel,
        array $assuranceEvidence,
        ?string $autonomyReference,
        ?string $autonomyLevel,
        ?string $autonomyWorkflow,
        array $autonomyEvidence,
        ?string $approval,
        ?string $adapter,
        string $reason,
    ): CommandReceipt {
        return new CommandReceipt(
            operationId: $op,
            idempotencyKey: $r->idempotencyKey,
            requestHash: $hash,
            tenantCompanyId: $c->companyId,
            serviceId: $c->serviceId,
            actorType: $c->actorType,
            actorId: $c->actorId,
            capability: $r->capability,
            status: 'failed',
            traceId: $r->traceId,
            correlationId: $r->correlationId,
            causationId: $r->causationId,
            rootCausationId: $r->rootCausationId,
            freshGovernance: true,
            governanceReference: $gov,
            riskReference: $riskReference,
            riskClass: $riskClass,
            riskScore: $riskScore,
            assuranceReference: $assuranceReference,
            assuranceLevel: $assuranceLevel,
            assuranceEvidence: $assuranceEvidence,
            autonomyReference: $autonomyReference,
            autonomyLevel: $autonomyLevel,
            autonomyWorkflow: $autonomyWorkflow,
            autonomyEvidence: $autonomyEvidence,
            approvalReference: $approval,
            adapter: $adapter,
            expectedEntityVersion: $r->expectedEntityVersion,
            reasonCode: $reason,
        );
    }

    private function blocked(
        CommandContext $c,
        CommandRequest $r,
        string $op,
        string $hash,
        string $reason,
        bool $freshGovernance = false,
        ?string $gov = null,
        ?string $riskReference = null,
        ?string $riskClass = null,
        ?float $riskScore = null,
        ?string $approval = null,
        ?string $assuranceReference = null,
        ?string $assuranceLevel = null,
        array $assuranceEvidence = [],
        ?string $autonomyReference = null,
        ?string $autonomyLevel = null,
        ?string $autonomyWorkflow = null,
        array $autonomyEvidence = [],
    ): CommandReceipt {
        return new CommandReceipt(
            operationId: $op,
            idempotencyKey: $r->idempotencyKey,
            requestHash: $hash,
            tenantCompanyId: $c->companyId,
            serviceId: $c->serviceId,
            actorType: $c->actorType,
            actorId: $c->actorId,
            capability: $r->capability,
            status: 'blocked',
            traceId: $r->traceId,
            correlationId: $r->correlationId,
            causationId: $r->causationId,
            rootCausationId: $r->rootCausationId,
            freshGovernance: $freshGovernance,
            governanceReference: $gov,
            riskReference: $riskReference,
            riskClass: $riskClass,
            riskScore: $riskScore,
            assuranceReference: $assuranceReference,
            assuranceLevel: $assuranceLevel,
            assuranceEvidence: $assuranceEvidence,
            autonomyReference: $autonomyReference,
            autonomyLevel: $autonomyLevel,
            autonomyWorkflow: $autonomyWorkflow,
            autonomyEvidence: $autonomyEvidence,
            approvalReference: $approval,
            expectedEntityVersion: $r->expectedEntityVersion,
            reasonCode: $reason,
        );
    }

    private function persistBlocked(
        CommandContext $c,
        CommandRequest $r,
        string $op,
        string $hash,
        string $reason,
        bool $freshGovernance,
        ?string $gov = null,
        ?string $riskReference = null,
        ?string $riskClass = null,
        ?float $riskScore = null,
        ?string $approval = null,
        ?string $assuranceReference = null,
        ?string $assuranceLevel = null,
        array $assuranceEvidence = [],
        ?string $autonomyReference = null,
        ?string $autonomyLevel = null,
        ?string $autonomyWorkflow = null,
        array $autonomyEvidence = [],
    ): CommandReceipt {
        $receipt = $this->blocked($c, $r, $op, $hash, $reason, $freshGovernance, $gov, $riskReference, $riskClass, $riskScore, $approval, $assuranceReference, $assuranceLevel, $assuranceEvidence, $autonomyReference, $autonomyLevel, $autonomyWorkflow, $autonomyEvidence);
        $this->store->complete($receipt);
        $this->transitionLifecycle($c, $r, $op, CommandLifecycleState::REFUSED, $reason, [
            'risk_reference' => $riskReference,
            'assurance_reference' => $assuranceReference,
            'autonomy_reference' => $autonomyReference,
            'governance_reference' => $gov,
            'approval_reference' => $approval,
        ]);
        $this->emit('command.refused', $c, $r, $op, $receipt->status, $reason, $receipt);
        return $receipt;
    }

    private function replay(CommandContext $c, CommandRequest $r, string $op, string $hash, array $existing): CommandReceipt
    {
        if ($this->lifecycle !== null && $this->lifecycle->available()) {
            $this->lifecycle->observe($c, $r, (string) $existing['operation_id'], CommandLifecycleState::REPLAYED);
        }

        $stored = is_array($existing['receipt'] ?? null) ? $existing['receipt'] : [];
        $originalStatus = (string) ($stored['status'] ?? $existing['status'] ?? 'failed');
        $status = $originalStatus === 'applied' ? 'already_applied' : $originalStatus;
        $reason = $stored['reason_code'] ?? $stored['reasonCode'] ?? null;

        return new CommandReceipt(
            operationId: $op,
            idempotencyKey: $r->idempotencyKey,
            requestHash: $hash,
            tenantCompanyId: $c->companyId,
            serviceId: $c->serviceId,
            actorType: $c->actorType,
            actorId: $c->actorId,
            capability: $r->capability,
            status: $status,
            traceId: $r->traceId,
            correlationId: $r->correlationId,
            causationId: $r->causationId,
            rootCausationId: $r->rootCausationId,
            freshGovernance: false,
            originalReceiptReference: 'command:' . (string) $existing['operation_id'],
            expectedEntityVersion: $r->expectedEntityVersion,
            reasonCode: is_string($reason) && $reason !== '' ? $reason : null,
            replayed: true,
        );
    }

    private function transitionLifecycle(CommandContext $context, CommandRequest $request, string $operationId, string $state, ?string $reasonCode = null, array $evidence = []): void
    {
        if ($this->lifecycle === null || ! $this->lifecycle->available()) {
            return;
        }
        $this->lifecycle->transition($context, $request, $operationId, $state, $reasonCode, $evidence);
    }

    private function validAutonomyLevel(string $level): bool
    {
        return in_array($level, ['SUGGEST', 'ASSIST', 'SEMI_AUTO', 'AUTO', 'TRUSTED_AUTO'], true);
    }

    private function emit(string $type, CommandContext $c, CommandRequest $r, string $op, ?string $status, ?string $reason, ?CommandReceipt $receipt = null): void
    {
        if (! $this->signals->available()) {
            return;
        }
        $this->signals->emit($type, [
            'event_id' => hash('sha256', $type . '|' . $op . '|' . microtime(true)),
            'type' => $type,
            'company_id' => $c->companyId,
            // v1 signal compatibility alias; company_id is authoritative.
            'tenant_company_id' => $c->companyId,
            'trace_id' => $r->traceId,
            'correlation_id' => $r->correlationId,
            'causation_id' => $r->causationId,
            'root_causation_id' => $r->rootCausationId,
            'occurred_at' => gmdate('c'),
            'command_id' => $op,
            'capability' => $r->capability,
            'status' => $status,
            'reason_code' => $reason,
            'risk_reference' => $receipt?->riskReference,
            'risk_class' => $receipt?->riskClass,
            'risk_score' => $receipt?->riskScore,
            'assurance_reference' => $receipt?->assuranceReference,
            'assurance_level' => $receipt?->assuranceLevel,
            'autonomy_reference' => $receipt?->autonomyReference,
            'autonomy_level' => $receipt?->autonomyLevel,
            'autonomy_workflow' => $receipt?->autonomyWorkflow,
        ]);
    }
}
