<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\TitanMobile;

use App\Extensions\Crm\System\Governance\CrmCommandBusGateway;
use App\Extensions\Crm\System\Tenancy\CrmCompanyContextResolver;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\TitanBOS\System\Contracts\OwnerActionGateway;
use App\Extensions\TitanBOS\System\Data\OwnerContext;
use Illuminate\Auth\Access\AuthorizationException;
use InvalidArgumentException;

/** Explicit governed owner actions for Titan BOS. No generic model/column mutation API. */
final class CrmOwnerActionGateway implements OwnerActionGateway
{
    private const ACTIONS = [
        'crm.quote.approve' => 'crm.quote.approve',
        'crm.invoice.issue' => 'crm.invoice.issue',
        'crm.customer.update' => 'crm.customer.update',
    ];

    public function __construct(
        private OwnerActionGateway $inner,
        private CrmCommandBusGateway $commands,
        private CrmCompanyContextResolver $companyContexts,
        private CrmCompanyScope $companyScope,
    ) {}

    public function preview(OwnerContext $context, string $action, array $payload): array
    {
        if (! isset(self::ACTIONS[$action])) return $this->inner->preview($context,$action,$payload);
        return $this->withOwner($context, fn() => [
            'ok'=>true,'source'=>'crm','action'=>$action,'requires_confirmation'=>true,
            'resource_id'=>$payload['public_id']??$payload['id']??null,
            'summary'=>$this->summary($action,$payload),
        ]);
    }

    public function execute(OwnerContext $context, string $action, array $payload, string $idempotencyKey): array
    {
        if (! isset(self::ACTIONS[$action])) return $this->inner->execute($context,$action,$payload,$idempotencyKey);
        if (trim($idempotencyKey)==='') throw new InvalidArgumentException('Owner CRM action requires idempotency key.');
        return $this->withOwner($context, fn() => $this->commands->request(self::ACTIONS[$action],$payload+['idempotency_key'=>$idempotencyKey],'owner'));
    }

    private function withOwner(OwnerContext $context, callable $callback): mixed
    {
        if($context->tenantId<=0||$context->userId<=0) throw new AuthorizationException('Titan BOS company/actor context is invalid.');
        $trusted=$this->companyContexts->fromTrustedPlatform($context->tenantId,$context->userId,'user',roles:[$context->role],permissions:$context->permissions,sourceSurface:'owner',deviceId:$context->deviceUuid,membershipVerified:true);
        return $this->companyScope->runWith($trusted,fn()=>$callback());
    }

    private function summary(string $action,array $payload): string
    {
        return match($action){
            'crm.quote.approve'=>'Approve CRM quote', 'crm.invoice.issue'=>'Issue CRM invoice',
            'crm.customer.update'=>'Update CRM customer', default=>$action,
        };
    }
}
