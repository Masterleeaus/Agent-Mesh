# Time Attendance Boundary

Payroll consumes approved time through `TimeAttendancePayrollInputPort`. It never queries Time Attendance tables directly.

For hourly/time-derived payroll, the port must return authoritative approved entries plus a stable `source_revision`; absence is fail-closed. Salaried payroll may explicitly declare that time input is not required and records `salary-policy:no-time-required` when no source revision applies.

The current hostless RC contains a configured adapter boundary, but the inspected Time & Attendance reference exposes export descriptors rather than a callable payroll-input API. Until the host provides the typed binding, hourly preparation is expected to block safely. This is a known integration dependency, not a silent fallback.
