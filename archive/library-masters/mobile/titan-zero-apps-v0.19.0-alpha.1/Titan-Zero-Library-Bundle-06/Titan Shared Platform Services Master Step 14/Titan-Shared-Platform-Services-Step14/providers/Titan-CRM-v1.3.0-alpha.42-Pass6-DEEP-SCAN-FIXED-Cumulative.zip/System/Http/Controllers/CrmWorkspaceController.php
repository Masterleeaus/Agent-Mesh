<?php
namespace App\Extensions\Crm\System\Http\Controllers;
use Illuminate\Routing\Controller;
final class CrmWorkspaceController extends Controller { public function index(){ return view('crm::workspace',['section'=>'overview']); } public function section(string $section){ return view('crm::workspace',compact('section')); } }
