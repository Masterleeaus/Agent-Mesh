<?php
declare(strict_types=1);
namespace App\Extensions\TitanGovernance\System\Workforce;
interface GuardrailDecisionAdapter { public function stage(): string; public function evaluate(array $request): array; }
