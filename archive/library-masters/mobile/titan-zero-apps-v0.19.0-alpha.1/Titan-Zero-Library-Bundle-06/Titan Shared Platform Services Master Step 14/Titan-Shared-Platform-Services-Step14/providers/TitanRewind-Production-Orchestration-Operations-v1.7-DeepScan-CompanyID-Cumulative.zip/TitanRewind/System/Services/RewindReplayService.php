<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Jobs\RunReplaySimulationJob;
use App\Extensions\TitanRewind\System\Models\RewindReplayRun;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Replay\RewindReplayRequest;
use App\Extensions\TitanRewind\System\Replay\RewindStructuralComparisonEngine;
use App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer;
use App\Extensions\TitanRewind\System\Support\CanonicalJson;
use App\Extensions\TitanRewind\System\Observability\RewindTraceContext;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class RewindReplayService
{
    public function __construct(
        private RewindReconstructionService $reconstruction,
        private RewindStructuralComparisonEngine $comparison,
        private RewindPayloadSanitizer $sanitizer,
        private CanonicalJson $canonical,
        private RewindQueueAdmissionService $admission,
        private RewindTelemetryService $telemetry,
        private RewindSignalOutboxService $signals,
    ) {}

    public function queueDryRun(RewindTraceQuery $query, ?int $requestedById = null, array $input = []): RewindReplayRun
    {
        $this->admission->assertCanAccept((string) config('titan-rewind.queues.replay', 'titan-rewind-replay'));
        $preview = $this->reconstruction->reconstruct($query, true);
        if (($preview['event_count'] ?? 0) < 1) {
            throw new InvalidArgumentException('A Rewind dry-run requires at least one tenant-scoped trace event.');
        }

        $run = RewindReplayRun::query()->create([
            'run_uuid' => (string) Str::uuid(),
            'operation_id' => (string) Str::uuid(),
            'tenant_company_id' => $query->tenantCompanyId(),
            'trace_id' => $query->traceId(),
            'correlation_id' => $query->correlationId(),
            'mode' => 'historical_dry_run',
            'status' => 'queued',
            'target_environment' => 'simulation',
            'mutation_policy' => 'deny',
            'network_policy' => 'deny-all',
            'requested_by_id' => $requestedById,
            'input' => $this->sanitizer->sanitize($input),
            'decision_reexecution_performed' => false,
        ]);

        $ctx=$this->contextForRun($run);
        $this->telemetry->metric('rewind.replay.queued',1,'count',$ctx,['mode'=>$run->mode]);
        $this->signals->emit('rewind.replay.queued.v1',$ctx,['run_uuid'=>$run->run_uuid,'mode'=>$run->mode]);
        $this->dispatch($run);
        return $run;
    }

    public function queueComparison(RewindTraceQuery $query, string $mode, ?int $requestedById = null, array $input = []): RewindReplayRun
    {
        $this->admission->assertCanAccept((string) config('titan-rewind.queues.replay', 'titan-rewind-replay'));
        $preview = $this->reconstruction->reconstruct($query, true);
        if (($preview['event_count'] ?? 0) < 1) {
            throw new InvalidArgumentException('A Rewind comparison requires at least one tenant-scoped trace event.');
        }

        $request = RewindReplayRequest::fromArray(array_merge($input, ['mode'=>$mode]), $this->sanitizer);
        $run = RewindReplayRun::query()->create([
            'run_uuid' => (string) Str::uuid(),
            'operation_id' => (string) Str::uuid(),
            'tenant_company_id' => $query->tenantCompanyId(),
            'trace_id' => $query->traceId(),
            'correlation_id' => $query->correlationId(),
            'mode' => $request->mode(),
            'status' => 'queued',
            'target_environment' => 'simulation',
            'mutation_policy' => 'deny',
            'network_policy' => $request->networkPolicy(),
            'deterministic_seed' => $request->deterministicSeed() === null ? null : (string)$request->deterministicSeed(),
            'requested_by_id' => $requestedById,
            'input' => $request->toArray(),
            'decision_reexecution_performed' => false,
        ]);

        $ctx=$this->contextForRun($run);
        $this->telemetry->metric('rewind.replay.queued',1,'count',$ctx,['mode'=>$run->mode]);
        $this->signals->emit('rewind.replay.queued.v1',$ctx,['run_uuid'=>$run->run_uuid,'mode'=>$run->mode]);
        $this->dispatch($run);
        return $run;
    }

    public function executeRun(RewindReplayRun $run): RewindReplayRun
    {
        if ($run->status === 'completed') return $run;
        $startedAt=microtime(true);

        $run->forceFill(['status'=>'running','started_at'=>$run->started_at ?? now(),'error_text'=>null])->save();
        $query = RewindTraceQuery::fromArray([
            'tenant_company_id' => $run->tenant_company_id,
            'trace_id' => $run->trace_id,
            'correlation_id' => $run->correlation_id,
        ]);

        if (in_array($run->mode, ['historical_dry_run','historical'], true)) {
            $result = $this->dryRun($query);
            $reproducibility = $result['reproducibility'] ?? 'PARTIALLY_REPRODUCIBLE';
        } else {
            $request = RewindReplayRequest::fromArray(array_merge((array)$run->input, ['mode'=>$run->mode]), $this->sanitizer);
            $result = $this->comparison->compare($this->reconstruction->reconstruct($query, true), $request);
            $reproducibility = $result['reproducibility'] ?? 'PARTIALLY_REPRODUCIBLE';
        }

        $result['operation_id'] = $run->operation_id;
        unset($result['result_hash']);
        $result['result_hash'] = hash('sha256', $this->canonical->encode($result));
        $run->forceFill([
            'status'=>'completed',
            'result'=>$result,
            'reproducibility'=>$reproducibility,
            'result_hash'=>$result['result_hash'] ?? null,
            'decision_reexecution_performed'=>false,
            'finished_at'=>now(),
        ])->save();
        $fresh=$run->refresh();
        $ctx=$this->contextForRun($fresh);
        $this->telemetry->span('rewind.replay.execute',(microtime(true)-$startedAt)*1000,'OK',$ctx,['mode'=>$fresh->mode,'reproducibility'=>$fresh->reproducibility]);
        $this->signals->emit('rewind.replay.completed.v1',$ctx,['run_uuid'=>$fresh->run_uuid,'mode'=>$fresh->mode,'result_hash'=>$fresh->result_hash,'reproducibility'=>$fresh->reproducibility]);
        return $fresh;
    }

    public function dryRun(RewindTraceQuery $query): array
    {
        $reconstruction = $this->reconstruction->reconstruct($query, true);
        $steps = array_map(static fn(array $event): array => [
            'event_id'=>$event['event_id'] ?? null,
            'sequence'=>$event['sequence'] ?? null,
            'event_type'=>$event['event_type'] ?? null,
            'source_engine'=>$event['source_engine'] ?? null,
            'tier'=>$event['tier'] ?? null,
            'lane'=>$event['lane'] ?? null,
            'decision_id'=>$event['decision_id'] ?? null,
            'capability_name'=>$event['capability_name'] ?? null,
            'result'=>'simulated_only',
        ], $reconstruction['events']);

        return [
            'mode'=>'historical_dry_run',
            'trace_id'=>$query->traceId(),
            'event_count'=>count($steps),
            'dependency_count'=>count($reconstruction['dependencies']),
            'causation_edges'=>count($reconstruction['causation']['edges']),
            'orphan_causation_count'=>count($reconstruction['causation']['orphans']),
            'deterministic'=>true,
            'would_apply'=>false,
            'mutation_attempted'=>false,
            'mutation_allowed'=>false,
            'mutation_policy'=>'deny',
            'decision_reexecution_performed'=>false,
            'execution_semantics'=>'historical_projection_only',
            'reproducibility'=>'PARTIALLY_REPRODUCIBLE',
            'steps'=>$steps,
            'reconstruction_version'=>$reconstruction['reconstruction_version'],
        ];
    }

    private function contextForRun(RewindReplayRun $run): RewindTraceContext
    {
        return RewindTraceContext::fromArray(['tenant_company_id'=>$run->tenant_company_id,'trace_id'=>$run->trace_id,'correlation_id'=>$run->correlation_id ?: $run->trace_id,'causation_id'=>null]);
    }

    private function dispatch(RewindReplayRun $run): void
    {
        RunReplaySimulationJob::dispatch($run->id, $run->tenant_company_id)
            ->onQueue((string) config('titan-rewind.queues.replay', 'titan-rewind-replay'));
    }
}
