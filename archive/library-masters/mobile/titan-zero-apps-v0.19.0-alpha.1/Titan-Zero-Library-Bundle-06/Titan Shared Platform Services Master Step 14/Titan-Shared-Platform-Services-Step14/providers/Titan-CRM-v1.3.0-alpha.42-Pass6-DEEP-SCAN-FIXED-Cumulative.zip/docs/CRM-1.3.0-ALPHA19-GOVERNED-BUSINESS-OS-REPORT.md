# Titan CRM 1.3.0-alpha.19 — Governed Business OS Upgrade Report

## Scope

This pass applies the Titan CRM portion of the Titan Zero governed architecture to the existing MagicAI CRM extension. It is an in-place upgrade, not a rewrite.

## Deep-scan findings

The supplied alpha.18 extension already contained substantial production-oriented functionality: CRM contacts/companies/leads/deals, sales documents, projects/tasks/calendar, Field Services, scheduling/dispatch, customer assets, recurring work, Pay, Locker, bookkeeping, finance assistants, Titan Mobile gateways, Chatbot integration, Interaction Engine integration, TitanAI capability registration, tenancy infrastructure, earned-autonomy compatibility and installer/verification tooling.

The existing canonical company boundary was already strong. `CrmCompanyContextResolver` fails closed and resolves `tenant_company_id` from trusted company membership rather than falling back to browser-supplied company IDs or treating `user_id` as the tenant.

The main architectural defect found was at the mutation boundary: several AI-facing integrations still directly invoked CRM repositories/domain services. That meant model-originated requests could bypass a future system-wide Command Bus even though newer TitanAI code already had a capability abstraction.

## Implemented architecture

### CRM remains authoritative

Existing repositories/domain services still perform the actual CRM mutation. They were not replaced with a second data model or generic AI-owned state store.

### Command Bus adapter boundary

`CrmCommandBusGateway` is now the external mutation boundary. CRM exposes `CrmCommandBusPort` so the Titan Command Bus extension can bind the platform implementation without CRM inventing or duplicating that engine.

- Reads may execute locally through normalized CRM capabilities.
- AI, Chatbot and Interaction writes are deferred if Command Bus is unavailable.
- Trusted web/admin/owner human paths can use an explicit compatibility fallback configured in `config/crm.php`.

### Authoritative execution envelope

For writes that reach `CrmCapabilityExecutor`, the flow is:

1. Resolve and authorize the canonical tenant/company context.
2. Reserve the idempotency key.
3. Lock/snapshot the target aggregate and validate `expected_version` when supplied.
4. Check cross-domain invariants.
5. Execute the existing authoritative CRM domain service/repository.
6. Advance `entity_version` where supported.
7. Build an authoritative command receipt and structured Rewind reference.
8. Persist the idempotent result/receipt.
9. Record the CRM audit event.
10. Insert the Titan Signal outbox event in the same database transaction.
11. Return the authoritative result plus receipt.

### Signal/Rewind

The new `crm_domain_signal_outbox` is a transactional outbox. A Titan Signal adapter can dispatch pending rows after commit without making the domain transaction depend on a network call. Command receipts contain structured before/after version/hash references suitable for Titan Rewind reconstruction without storing hidden model reasoning.

### AI read models

`crm.ai.context.read` provides a fixed allowlist of operational resources, tenant scoping, bounded result sizes and sensitive-field stripping. It is the intended AI/Workforce context surface instead of unrestricted SQL/table access.

## Compatibility retained

- Existing UI and routes remain unchanged.
- Existing alpha.18 panel layout fallback remains.
- Existing domain services/repositories remain in place.
- Existing migrations are not rewritten; alpha.19 adds one additive migration.
- Existing installer/provider conventions remain.
- Human compatibility fallback is configurable and intentionally excludes AI/Chatbot/Interaction sources.

## Explicit boundary / limitation

This CRM package does **not** contain the standalone Titan Command Bus, Titan Signal or Titan Rewind engines. Alpha.19 implements CRM-side contracts, receipts and the Signal outbox. Platform engine extensions must bind/consume those contracts at deployment time. When Command Bus is absent, AI-originated writes safely defer rather than pretending to have executed.

## Acceptance claims supported by this package

- AI-facing CRM writes no longer directly call authoritative CRM repositories from the legacy assistant, TitanAI provider, Interaction handler or Chatbot CRM tool service.
- `tenant_company_id` remains canonical.
- Governed writes are idempotent and receipt-backed.
- Important aggregates support additive optimistic versioning.
- CRM emits durable domain Signal records for governed writes.
- Rewind-compatible structured references are returned/persisted.
- AI has a bounded normalized read model.
- No unrestricted hidden chain-of-thought storage was added.

Cross-extension end-to-end behavior involving separately installed Titan engines must be integration-tested in the full Titan platform after those engines bind their adapters.
