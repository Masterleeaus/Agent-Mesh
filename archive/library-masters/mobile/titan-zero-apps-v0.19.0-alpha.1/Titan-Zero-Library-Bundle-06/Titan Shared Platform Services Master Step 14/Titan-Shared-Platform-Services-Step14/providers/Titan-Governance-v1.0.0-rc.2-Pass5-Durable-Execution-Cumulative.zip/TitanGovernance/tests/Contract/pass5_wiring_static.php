<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);function fail_p5w(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function has_p5w(string $hay,string $needle,string $m):void{if(!str_contains($hay,$needle))fail_p5w($m.' missing='.$needle);}function no_p5w(string $hay,string $needle,string $m):void{if(str_contains($hay,$needle))fail_p5w($m.' forbidden='.$needle);}
$files=['System/Http/Controllers/DecisionIntelligenceController.php','System/TitanGovernanceServiceProvider.php','System/Contracts/GovernanceManagerContract.php','System/Services/GovernanceManager.php','routes/user.php','config/titan-governance.php'];foreach($files as $f)if(!is_file($root.'/'.$f))fail_p5w('missing '.$f);
$c=file_get_contents($root.'/System/Http/Controllers/DecisionIntelligenceController.php');$p=file_get_contents($root.'/System/TitanGovernanceServiceProvider.php');$m=file_get_contents($root.'/System/Services/GovernanceManager.php');$i=file_get_contents($root.'/System/Contracts/GovernanceManagerContract.php');$r=file_get_contents($root.'/routes/user.php');$cfg=file_get_contents($root.'/config/titan-governance.php');
foreach(['decisionTimeline','decisionDelta','decisionCompliance','rewindTheater','recentDecisions','decisionDetail'] as $method){has_p5w($i,'function '.$method,'manager contract method '.$method);has_p5w($m,'function '.$method,'manager implementation '.$method);}
foreach(['GovernanceDecisionEvidenceRegistry','GovernanceDecisionReadStoreContract','GovernanceDecisionIntelligence','GovernanceDeltaViewer','GovernancePolicyComplianceProjector','GovernanceRewindTheater'] as $binding)has_p5w($p,$binding,'provider wiring '.$binding);
has_p5w($p,'registerDecisionEvidenceSources','decision evidence adapter registration');has_p5w($cfg,"'decision_evidence_sources'",'decision evidence config');
foreach(['decisions/{decisionId}','decisions/{decisionId}/timeline','decisions/{decisionId}/rewind','decisions/{decisionId}/compliance','decisions/delta'] as $route)has_p5w($r,$route,'route '.$route);has_p5w($r,"->post('/decisions/delta'",'delta must be POST');
foreach(['DB::','->query()','GovernancePolicyDecision','GovernanceEscalation::','CommandGateway','performEscalationAction'] as $forbidden)no_p5w($c,$forbidden,'decision controller must stay read-only and repository-free');
has_p5w($c,"'titan-governance.view'",'decision reads require view permission');
echo "PASS: Governance Pass 5 wiring\n";
