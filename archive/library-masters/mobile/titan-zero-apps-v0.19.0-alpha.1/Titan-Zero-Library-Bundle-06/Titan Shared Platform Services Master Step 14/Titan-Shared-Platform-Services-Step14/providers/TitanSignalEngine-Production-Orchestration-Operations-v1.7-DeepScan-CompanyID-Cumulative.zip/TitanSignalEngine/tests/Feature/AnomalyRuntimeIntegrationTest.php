<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Extensions\TitanSignalEngine\System\Data\AnomalyThresholds;
use App\Extensions\TitanSignalEngine\System\Data\EventTypeDefinition;
use App\Extensions\TitanSignalEngine\System\Data\SignalActor;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Models\SignalAnomaly;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseCausationRef;
use App\Extensions\TitanSignalEngine\System\Persistence\SignalEventStore;
use App\Extensions\TitanSignalEngine\System\Services\AnomalyDetectionService;
use App\Extensions\TitanSignalEngine\System\Services\AnomalyRuleEvaluator;
use App\Extensions\TitanSignalEngine\System\Services\EventTypeRegistry;
use App\Extensions\TitanSignalEngine\System\Services\SignalRegistryAuthority;
use App\Extensions\TitanSignalEngine\System\Services\RegistryOwnershipPolicy;
use App\Extensions\TitanSignalEngine\System\Services\PulseProjector;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitter;
use App\Extensions\TitanSignalEngine\System\Services\SignalPayloadGuard;
use InvalidArgumentException;
use Tests\TestCase;

final class AnomalyRuntimeIntegrationTest extends TestCase
{
    private SignalEmitter $emitter;
    private \App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority $emitterAuthority;
    private AnomalyDetectionService $anomalies;

    protected function setUp(): void
    {
        parent::setUp();
        foreach (glob(dirname(__DIR__, 2) . '/database/migrations/*.php') ?: [] as $migrationFile) {
            (require $migrationFile)->up();
        }
        config()->set('titan-signal-engine.anomaly_repeated_failure_count_5m', 2);
        config()->set('titan-signal-engine.anomaly_execution_loop_count', 3);
        config()->set('titan-signal-engine.anomaly_missing_parent_grace_seconds', 1);

        $this->emitterAuthority = new \App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority('feature-test-secret', [
            'test-service:broken-source:root' => [
                'source' => 'broken-source',
                'source_component' => null,
                'permissions' => ['signal.emit'],
                'event_type_patterns' => ['*'],
            ],
            'test-service:late-parent:root' => [
                'source' => 'late-parent',
                'source_component' => null,
                'permissions' => ['signal.emit'],
                'event_type_patterns' => ['*'],
            ],
            'test-service:loop-source:root' => [
                'source' => 'loop-source',
                'source_component' => null,
                'permissions' => ['signal.emit'],
                'event_type_patterns' => ['*'],
            ],
            'titan-signal-engine:anomaly-engine' => [
                'source' => 'titan-signal-engine',
                'source_component' => 'anomaly-engine',
                'permissions' => ['signal.emit'],
                'event_type_patterns' => ['signal.anomaly.detected', 'signal.anomaly.acknowledged', 'signal.anomaly.suppressed', 'signal.anomaly.resolved', 'signal.anomaly.reopened'],
            ],
        ]);
        $validator = new SignalContextValidator($this->emitterAuthority);
        $registryAuthority = new SignalRegistryAuthority('feature-registry-secret', [
            'test-registry' => [
                'owner_source' => 'test-suite',
                'permissions' => ['signal.registry.event.manage', 'signal.registry.override'],
                'event_type_patterns' => ['*'],
                'subscriber_key_patterns' => ['*'],
            ],
        ]);
        $registryIdentity = $registryAuthority->issue('test-registry');
        $ownership = new RegistryOwnershipPolicy($registryAuthority);
        $registry = new EventTypeRegistry($ownership);
        foreach (['test.failure', 'test.loop'] as $type) {
            $registry->register(EventTypeDefinition::fromArray([
                'event_type' => $type,
                'current_schema_version' => 1,
                'supported_schema_versions' => [1],
                'category' => 'test',
                'allowed_scopes' => ['tenant'],
                'required_payload_fields' => [],
                'optional_payload_fields' => [],
                'allow_additional_payload_fields' => false,
                'owner_source' => null,
                'allowed_severities' => ['info', 'error'],
            ]), $registryIdentity);
        }
        $this->emitter = new SignalEmitter(new SignalEventStore(), $registry, $validator, new SignalPayloadGuard(65536, 8192, []), null, new PulseProjector());
        $thresholds = new AnomalyThresholds(repeatedFailureCount5m: 2, executionLoopCount: 3);
        $this->anomalies = new AnomalyDetectionService($validator, new AnomalyRuleEvaluator($thresholds), $this->emitterAuthority, $this->emitter);
    }


    private function emitTrusted(
        \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope|array $signal,
        ?\App\Extensions\TitanSignalEngine\System\Data\SignalContext $context = null,
    ): \App\Extensions\TitanSignalEngine\System\Data\SignalReceipt {
        $source = is_array($signal) ? (string) ($signal['source'] ?? 'test-suite') : $signal->source;
        $component = is_array($signal) ? ($signal['source_component'] ?? null) : $signal->sourceComponent;
        $scope = is_array($signal) ? (string) ($signal['scope'] ?? 'tenant') : $signal->scope;
        $tenant = is_array($signal) ? ($signal['tenant_company_id'] ?? null) : $signal->tenantCompanyId;
        $serviceId = 'test-service:' . $source . ':' . ($component ?? 'root');
        $identity = $this->emitterAuthority->issue($serviceId);
        if ($context === null) {
            $context = $scope === 'system'
                ? \App\Extensions\TitanSignalEngine\System\Data\SignalContext::system('test-system', 'test', ['signal.tenant.emit'], $identity)
                : \App\Extensions\TitanSignalEngine\System\Data\SignalContext::tenantHuman((int) $tenant, 'test-user', 'test-session', 'test', $identity);
        } else {
            $context = new \App\Extensions\TitanSignalEngine\System\Data\SignalContext(
                $context->scope,
                $context->tenantCompanyId,
                $context->actor,
                $context->permissions,
                $identity,
            );
        }

        return $this->emitter->emit($signal, $context);
    }

    private function anomalyReadContext(): SignalContext
    {
        return SignalContext::tenantHuman(1, 'anomaly-reader', 'anomaly-session', 'test');
    }

    public function test_repeated_failure_is_deduplicated_across_scans(): void
    {
        $this->emitTrusted(['event_type' => 'test.failure', 'tenant_company_id' => 1, 'source' => 'broken-source', 'severity' => 'error']);
        $this->emitTrusted(['event_type' => 'test.failure', 'tenant_company_id' => 1, 'source' => 'broken-source', 'severity' => 'error']);

        $first = $this->anomalies->scan($this->anomalyReadContext(), 1);
        $second = $this->anomalies->scan($this->anomalyReadContext(), 1);

        self::assertCount(1, array_values(array_filter($first, static fn (array $row): bool => $row['type'] === 'repeated_failures')));
        self::assertSame(1, SignalAnomaly::query()->where('anomaly_type', 'repeated_failures')->count());
        self::assertGreaterThanOrEqual(2, SignalAnomaly::query()->where('anomaly_type', 'repeated_failures')->firstOrFail()->occurrence_count);
        self::assertSame($first[0]['anomaly_id'], $second[0]['anomaly_id']);
    }

    public function test_repeated_event_type_in_same_trace_detects_loop(): void
    {
        $root = SignalEnvelope::fromArray(['event_type' => 'test.loop', 'tenant_company_id' => 1, 'source' => 'loop-source']);
        $this->emitTrusted($root);
        $this->emitTrusted($root->child('test.loop', 'loop-source'));
        $this->emitTrusted($root->child('test.loop', 'loop-source'));

        $rows = $this->anomalies->scan($this->anomalyReadContext(), 1);
        self::assertTrue(collect($rows)->contains(static fn (array $row): bool => $row['type'] === 'execution_loop'));
    }

    public function test_late_parent_resolves_causation_projection(): void
    {
        $parentId = '018f6b4e-2a74-7a70-8000-000000000191';
        $traceId = '018f6b4e-2a74-7a70-8000-000000000192';
        $correlationId = '018f6b4e-2a74-7a70-8000-000000000193';
        $child = SignalEnvelope::fromArray([
            'event_type' => 'test.loop', 'tenant_company_id' => 1, 'source' => 'late-parent',
            'trace_id' => $traceId, 'correlation_id' => $correlationId,
            'causation_id' => $parentId, 'root_causation_id' => $parentId,
        ]);
        $this->emitTrusted($child);
        self::assertFalse((bool) SignalPulseCausationRef::query()->where('child_event_id', $child->eventId)->firstOrFail()->resolved);

        $parent = SignalEnvelope::fromArray([
            'event_id' => $parentId, 'event_type' => 'test.loop', 'tenant_company_id' => 1, 'source' => 'late-parent',
            'trace_id' => $traceId, 'correlation_id' => $correlationId, 'root_causation_id' => $parentId,
        ]);
        $this->emitTrusted($parent);
        self::assertTrue((bool) SignalPulseCausationRef::query()->where('child_event_id', $child->eventId)->firstOrFail()->resolved);
    }

    public function test_lifecycle_mutation_requires_explicit_permission(): void
    {
        $this->emitTrusted(['event_type' => 'test.failure', 'tenant_company_id' => 1, 'source' => 'broken-source', 'severity' => 'error']);
        $this->emitTrusted(['event_type' => 'test.failure', 'tenant_company_id' => 1, 'source' => 'broken-source', 'severity' => 'error']);
        $anomalyId = $this->anomalies->scan($this->anomalyReadContext(), 1)[0]['anomaly_id'];

        $this->expectException(InvalidArgumentException::class);
        $this->anomalies->acknowledge($anomalyId, 'unauthorized_attempt', SignalContext::tenantHuman(1, 'usr_1', 'sess_1', 'titan-auth'));
    }

    public function test_authorized_tenant_can_acknowledge_own_anomaly(): void
    {
        $this->emitTrusted(['event_type' => 'test.failure', 'tenant_company_id' => 1, 'source' => 'broken-source', 'severity' => 'error']);
        $this->emitTrusted(['event_type' => 'test.failure', 'tenant_company_id' => 1, 'source' => 'broken-source', 'severity' => 'error']);
        $anomalyId = $this->anomalies->scan($this->anomalyReadContext(), 1)[0]['anomaly_id'];
        $context = new SignalContext('tenant', 1, new SignalActor('usr_1', 'human', 1, 'titan-auth', 'sess_1'), ['signal.anomaly.manage']);

        $result = $this->anomalies->acknowledge($anomalyId, 'operator_reviewed', $context);
        self::assertSame(1, (int) $result['decision_version']);
        self::assertNotNull($result['last_decision_event_id']);
        self::assertSame(1, \App\Extensions\TitanSignalEngine\System\Models\SignalEvent::query()->where('event_type', 'signal.anomaly.acknowledged')->where('tenant_company_id', 1)->count());
        self::assertSame('acknowledged', $result['status']);
    }
    public function test_resolve_and_suppress_emit_immutable_decision_events(): void
    {
        $this->emitTrusted(['event_type' => 'test.failure', 'tenant_company_id' => 1, 'source' => 'broken-source', 'severity' => 'error']);
        $this->emitTrusted(['event_type' => 'test.failure', 'tenant_company_id' => 1, 'source' => 'broken-source', 'severity' => 'error']);
        $anomalyId = $this->anomalies->scan($this->anomalyReadContext(), 1)[0]['anomaly_id'];
        $context = new SignalContext('tenant', 1, new SignalActor('usr_1', 'human', 1, 'titan-auth', 'sess_1'), ['signal.anomaly.manage']);

        $suppressed = $this->anomalies->suppress($anomalyId, new \DateTimeImmutable('+1 hour'), 'maintenance_window', $context);
        self::assertSame('suppressed', $suppressed['status']);
        self::assertSame(1, \App\Extensions\TitanSignalEngine\System\Models\SignalEvent::query()->where('event_type', 'signal.anomaly.suppressed')->count());

        $resolved = $this->anomalies->resolve($anomalyId, 'operator_confirmed_recovery', $context);
        self::assertSame('resolved', $resolved['status']);
        self::assertSame(2, (int) $resolved['decision_version']);
        self::assertSame(1, \App\Extensions\TitanSignalEngine\System\Models\SignalEvent::query()->where('event_type', 'signal.anomaly.resolved')->count());
    }

}
