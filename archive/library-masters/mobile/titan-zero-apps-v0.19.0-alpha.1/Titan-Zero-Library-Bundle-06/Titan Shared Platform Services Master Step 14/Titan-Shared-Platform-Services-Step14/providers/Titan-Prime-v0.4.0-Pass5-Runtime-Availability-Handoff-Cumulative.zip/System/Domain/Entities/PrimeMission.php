<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Entities;

use App\Extensions\TitanPrime\System\Domain\Enums\PrimeMissionStatus;
use App\Extensions\TitanPrime\System\Domain\Exceptions\InvalidMissionTransition;
use App\Extensions\TitanPrime\System\Domain\State\PrimeMissionStateMachine;
use App\Extensions\TitanPrime\System\Domain\ValueObjects\PrimeBudget;
use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use InvalidArgumentException;

final class PrimeMission
{
    private PrimeMissionStatus $status;

    private function __construct(
        private readonly string $missionId,
        private readonly TraceContext $trace,
        private readonly PrimeObjective $objective,
        private readonly PrimeBudget $budget,
        private readonly string $initiatedByType,
        private readonly ?string $initiatedById,
        PrimeMissionStatus $status,
    ) {
        if (trim($missionId) === '' || trim($initiatedByType) === '') {
            throw new InvalidArgumentException('Mission id and initiated-by type are required.');
        }

        $this->status = $status;
    }

    public static function reconstitute(
        string $missionId,
        TraceContext $trace,
        PrimeObjective $objective,
        PrimeBudget $budget,
        string $initiatedByType,
        ?string $initiatedById,
        PrimeMissionStatus $status,
    ): self {
        return new self(
            missionId: $missionId,
            trace: $trace,
            objective: $objective,
            budget: $budget,
            initiatedByType: $initiatedByType,
            initiatedById: $initiatedById,
            status: $status,
        );
    }

    public static function draft(
        string $missionId,
        TraceContext $trace,
        PrimeObjective $objective,
        PrimeBudget $budget,
        string $initiatedByType,
        ?string $initiatedById = null,
    ): self {
        return new self(
            missionId: $missionId,
            trace: $trace,
            objective: $objective,
            budget: $budget,
            initiatedByType: $initiatedByType,
            initiatedById: $initiatedById,
            status: PrimeMissionStatus::Draft,
        );
    }

    public function transitionTo(PrimeMissionStatus $next, ?PrimeMissionStateMachine $stateMachine = null): void
    {
        $stateMachine ??= new PrimeMissionStateMachine();

        if (!$stateMachine->canTransition($this->status, $next)) {
            throw InvalidMissionTransition::between($this->status->value, $next->value);
        }

        $this->status = $next;
    }

    public function missionId(): string { return $this->missionId; }
    public function trace(): TraceContext { return $this->trace; }
    public function objective(): PrimeObjective { return $this->objective; }
    public function budget(): PrimeBudget { return $this->budget; }
    public function status(): PrimeMissionStatus { return $this->status; }
    public function initiatedByType(): string { return $this->initiatedByType; }
    public function initiatedById(): ?string { return $this->initiatedById; }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'mission_id' => $this->missionId,
            ...$this->trace->toArray(),
            'objective' => $this->objective->toArray(),
            'budget' => $this->budget->toArray(),
            'status' => $this->status->value,
            'initiated_by_type' => $this->initiatedByType,
            'initiated_by_id' => $this->initiatedById,
        ];
    }
}
