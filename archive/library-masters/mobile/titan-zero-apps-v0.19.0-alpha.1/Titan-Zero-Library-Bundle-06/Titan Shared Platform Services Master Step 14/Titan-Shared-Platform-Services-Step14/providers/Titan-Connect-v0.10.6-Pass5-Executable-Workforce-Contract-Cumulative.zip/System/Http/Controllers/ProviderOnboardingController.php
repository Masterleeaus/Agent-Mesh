<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Onboarding\MetaOAuthService;
use App\Extensions\TitanConnect\System\Onboarding\TelegramWebhookRegistrar;
use App\Extensions\TitanConnect\System\Services\MessagingAuditService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use RuntimeException;

final class ProviderOnboardingController extends Controller
{
    public function __construct(private readonly CompanyContext $context, private readonly MetaOAuthService $meta, private readonly TelegramWebhookRegistrar $telegram, private readonly MessagingAuditService $audit) {}

    public function metaStart(Request $request, string $provider): RedirectResponse
    {
        $companyId=$this->context->companyId($request); $actorId=$this->context->actorId($request);
        $redirect=route('titan-connect.onboarding.meta.callback',['provider'=>$provider]);
        return redirect()->away($this->meta->authorizationUrl($companyId,$actorId,$provider,$redirect));
    }

    public function metaCallback(Request $request, string $provider): RedirectResponse|JsonResponse
    {
        $companyId=$this->context->companyId($request); $actorId=$this->context->actorId($request);
        $data=$request->validate(['code'=>['required','string'],'state'=>['required','string']]);
        try { $connection=$this->meta->complete($companyId,$actorId,$provider,$data['code'],$data['state'],route('titan-connect.onboarding.meta.callback',['provider'=>$provider])); }
        catch (RuntimeException $e) { return response()->json(['status'=>'error','message'=>$e->getMessage()],422); }
        $this->audit->record($companyId,$actorId,'provider.onboarded','channel-connection',$connection->uuid,null,['provider'=>$provider,'method'=>'meta_oauth']);
        return redirect()->route('dashboard.user.titan-connect.inbox.unified')->with('status', ucfirst($provider).' connected.');
    }

    public function telegram(Request $request): JsonResponse
    {
        $companyId=$this->context->companyId($request); $actorId=$this->context->actorId($request);
        $data=$request->validate(['bot_token'=>['required','string','max:255'],'display_name'=>['nullable','string','max:255']]);
        try { $connection=$this->telegram->register($companyId,$actorId,$data['bot_token'],$data['display_name'] ?? null); }
        catch (RuntimeException $e) { return response()->json(['status'=>'error','message'=>$e->getMessage()],422); }
        $this->audit->record($companyId,$actorId,'provider.onboarded','channel-connection',$connection->uuid,null,['provider'=>'telegram','method'=>'setWebhook']);
        return response()->json($connection,201);
    }
}
