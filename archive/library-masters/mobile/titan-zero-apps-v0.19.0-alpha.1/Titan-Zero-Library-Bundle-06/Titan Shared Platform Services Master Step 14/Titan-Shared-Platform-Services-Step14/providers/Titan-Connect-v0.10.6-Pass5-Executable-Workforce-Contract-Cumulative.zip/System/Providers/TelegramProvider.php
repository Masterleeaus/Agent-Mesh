<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Providers;

use App\Extensions\TitanConnect\System\DTO\NormalizedInboundMessage;
use App\Extensions\TitanConnect\System\DTO\ProviderSendResult;
use App\Extensions\TitanConnect\System\DTO\ProviderMediaDescriptor;

final class TelegramProvider extends AbstractMessagingProvider
{
    public function key(): string { return 'telegram'; }

    public function verifyWebhook(array $headers, string $body, array $credentials): bool
    {
        $secret = (string) ($credentials['webhook_secret'] ?? '');
        $provided = $this->header($headers, 'x-telegram-bot-api-secret-token');
        return $secret !== '' && $provided !== null && hash_equals($secret, trim($provided));
    }

    public function send(array $message, array $credentials): ProviderSendResult
    {
        $token = $this->credential($credentials, 'bot_token');
        $base = rtrim((string) ($credentials['api_base_url'] ?? config('titan-connect.providers.telegram.api_base_url', 'https://api.telegram.org')), '/');
        $chatId = (string) ($message['to'] ?? '');
        $attachment = $this->firstAttachment($message);
        $method = 'sendMessage';
        $payload = ['chat_id' => $chatId, 'text' => (string) ($message['body'] ?? '')];

        if ($attachment !== null && ! empty($attachment['public_url'])) {
            $type = strtolower((string) ($attachment['type'] ?? 'document'));
            $map = [
                'image' => ['sendPhoto', 'photo'],
                'photo' => ['sendPhoto', 'photo'],
                'video' => ['sendVideo', 'video'],
                'audio' => ['sendAudio', 'audio'],
                'voice' => ['sendVoice', 'voice'],
                'document' => ['sendDocument', 'document'],
                'file' => ['sendDocument', 'document'],
            ];
            [$method, $field] = $map[$type] ?? $map['document'];
            $payload = ['chat_id' => $chatId, $field => (string) $attachment['public_url']];
            if (! empty($message['body']) && $method !== 'sendVoice') {
                $payload['caption'] = (string) $message['body'];
            }
        }

        $response = $this->requireSuccess($this->http->request('POST', $base.'/bot'.$token.'/'.$method, ['json' => $payload]), 'send');
        $providerId = $response->json('result.message_id');
        return new ProviderSendResult('sent', is_scalar($providerId) ? (string) $providerId : null, $response->json);
    }

    public function health(array $credentials): array
    {
        $token = $this->credential($credentials, 'bot_token');
        $base = rtrim((string) ($credentials['api_base_url'] ?? config('titan-connect.providers.telegram.api_base_url', 'https://api.telegram.org')), '/');
        $response = $this->http->request('GET', $base.'/bot'.$token.'/getMe');
        return [
            'ok' => $response->isSuccessful() && (bool) $response->json('ok', false),
            'provider' => $this->key(),
            'configured' => true,
            'http_status' => $response->status,
            'bot_id' => $response->json('result.id'),
            'username' => $response->json('result.username'),
        ];
    }

    public function resolveInboundMedia(array $attachment, array $credentials): ?ProviderMediaDescriptor
    {
        $token = $this->credential($credentials, 'bot_token');
        $base = rtrim((string) ($credentials['api_base_url'] ?? config('titan-connect.providers.telegram.api_base_url', 'https://api.telegram.org')), '/');
        $type = strtolower((string) ($attachment['type'] ?? ''));
        $candidate = $attachment;
        if ($type === 'photo' && is_array($attachment['value'] ?? null)) {
            $photos = array_values(array_filter($attachment['value'], 'is_array'));
            $candidate = $photos === [] ? [] : $photos[array_key_last($photos)];
        } elseif (is_array($attachment['value'] ?? null)) {
            $candidate = $attachment['value'];
        }
        $fileId = trim((string) ($candidate['file_id'] ?? $attachment['file_id'] ?? ''));
        if ($fileId === '') {
            return parent::resolveInboundMedia($attachment, $credentials);
        }
        $response = $this->requireSuccess($this->http->request('GET', $base.'/bot'.$token.'/getFile', ['query' => ['file_id' => $fileId]]), 'getFile');
        $filePath = $response->json('result.file_path');
        if (! is_string($filePath) || trim($filePath) === '') {
            return null;
        }
        return new ProviderMediaDescriptor(
            $base.'/file/bot'.$token.'/'.ltrim($filePath, '/'),
            [],
            isset($candidate['file_name']) ? (string) $candidate['file_name'] : null,
            isset($candidate['mime_type']) ? (string) $candidate['mime_type'] : null,
            is_numeric($candidate['file_size'] ?? null) ? (int) $candidate['file_size'] : null,
            null,
            ['provider' => $this->key(), 'file_id' => $fileId, 'file_unique_id' => $candidate['file_unique_id'] ?? null, 'type' => $type],
        );
    }

    public function normalizeInbound(array $payload, array $headers = []): NormalizedInboundMessage
    {
        $message = $payload['message']
            ?? $payload['edited_message']
            ?? $payload['channel_post']
            ?? $payload['business_message']
            ?? $payload['edited_business_message']
            ?? $payload['guest_message']
            ?? null;
        if (! is_array($message)) {
            return parent::normalizeInbound($payload, $headers);
        }
        $chatId = isset($message['chat']['id']) ? (string) $message['chat']['id'] : (string) ($payload['update_id'] ?? '');
        $messageId = isset($message['message_id']) ? (string) $message['message_id'] : null;
        $eventId = (string) ($payload['update_id'] ?? $messageId ?? '');
        $sender = isset($message['from']['id']) ? (string) $message['from']['id'] : null;
        $body = $message['text'] ?? $message['caption'] ?? null;
        $attachments = [];
        foreach (['photo', 'document', 'video', 'audio', 'voice', 'animation', 'video_note'] as $type) {
            if (isset($message[$type])) {
                $attachments[] = ['type' => $type, 'value' => $message[$type]];
            }
        }
        return new NormalizedInboundMessage(
            $this->key(), $eventId, $chatId, $messageId, $sender, $chatId,
            $body === null ? null : (string) $body,
            $attachments === [] ? 'text' : 'attachment', $attachments,
            ['raw' => $payload], isset($message['date']) ? (string) $message['date'] : null,
        );
    }
}
