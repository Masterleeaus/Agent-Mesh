<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Console;

use App\Extensions\TitanConnect\System\Navigation\HostNavigationRegistrar;
use App\Extensions\TitanConnect\System\Navigation\MagicAiMenuSynchronizer;
use Illuminate\Console\Command;

final class SyncTitanConnectHostCommand extends Command
{
    protected $signature = 'titan-connect:host-sync';
    protected $description = 'Register Titan Connect host contributions and regenerate MagicAI navigation caches when supported.';

    public function handle(HostNavigationRegistrar $registrar, MagicAiMenuSynchronizer $synchronizer): int
    {
        $result = $synchronizer->sync(false);
        $registrar->register(true);

        if ($result['supported']) {
            $this->components->info(sprintf(
                'Titan Connect host menus synchronized (%d user, %d admin) and host menu cache regeneration attempted.',
                $result['user'],
                $result['admin'],
            ));
        } else {
            $this->components->warn('MagicAI menus table was not detected; registry contributions were attempted instead.');
        }

        return self::SUCCESS;
    }
}
