<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('crm_chatbot_identities', function (Blueprint $t): void {
            $t->id();
            $t->char('public_id', 26)->unique();
            $t->unsignedBigInteger('user_id')->index();
            $t->unsignedBigInteger('chatbot_id')->index();
            $t->unsignedBigInteger('chatbot_customer_id')->index();
            $t->char('crm_contact_public_id', 26)->nullable()->index();
            $t->char('crm_company_public_id', 26)->nullable()->index();
            $t->char('crm_lead_public_id', 26)->nullable()->index();
            $t->string('session_hash', 64)->index();
            $t->string('channel', 60)->nullable()->index();
            $t->string('identity_state', 30)->default('anonymous')->index();
            $t->unsignedTinyInteger('identity_confidence')->default(0);
            $t->string('normalized_email', 320)->nullable()->index();
            $t->string('normalized_phone', 80)->nullable()->index();
            $t->timestamp('verified_at')->nullable();
            $t->timestamp('first_seen_at')->nullable();
            $t->timestamp('last_seen_at')->nullable();
            $t->json('metadata')->nullable();
            $t->timestamps();
            $t->unique(['user_id','chatbot_id','chatbot_customer_id'], 'crm_chatbot_identity_customer_unique');
        });

        Schema::create('crm_chatbot_settings', function (Blueprint $t): void {
            $t->id();
            $t->unsignedBigInteger('user_id')->index();
            $t->unsignedBigInteger('chatbot_id')->index();
            $t->boolean('enabled')->default(false)->index();
            $t->boolean('capture_contacts')->default(true);
            $t->boolean('create_lead_on_capture')->default(true);
            $t->boolean('record_activity')->default(true);
            $t->boolean('allow_financial_reads')->default(true);
            $t->boolean('require_verified_financial_identity')->default(true);
            $t->char('default_pipeline_public_id', 26)->nullable();
            $t->unsignedBigInteger('default_owner_user_id')->nullable()->index();
            $t->json('allowed_tools')->nullable();
            $t->json('metadata')->nullable();
            $t->timestamps();
            $t->unique(['user_id','chatbot_id'], 'crm_chatbot_settings_unique');
        });

        Schema::create('crm_chatbot_session_grants', function (Blueprint $t): void {
            $t->id();
            $t->char('public_id', 26)->unique();
            $t->unsignedBigInteger('user_id')->index();
            $t->unsignedBigInteger('chatbot_id')->index();
            $t->unsignedBigInteger('chatbot_customer_id')->index();
            $t->char('crm_contact_public_id', 26)->index();
            $t->string('session_hash', 64)->index();
            $t->timestamp('issued_at')->nullable();
            $t->dateTime('expires_at')->index();
            $t->timestamp('revoked_at')->nullable()->index();
            $t->json('metadata')->nullable();
            $t->timestamps();
            $t->unique(
                ['user_id','chatbot_id','chatbot_customer_id','session_hash'],
                'crm_chatbot_session_grant_unique'
            );
        });

        Schema::create('crm_chatbot_activity_links', function (Blueprint $t): void {
            $t->id();
            $t->unsignedBigInteger('user_id')->index();
            $t->unsignedBigInteger('chatbot_id')->index();
            $t->unsignedBigInteger('chatbot_conversation_id')->index();
            $t->char('crm_contact_public_id', 26)->nullable()->index();
            $t->char('crm_activity_public_id', 26)->nullable()->index();
            $t->string('event_type', 80)->index();
            $t->string('event_fingerprint', 64)->index();
            $t->timestamp('occurred_at')->nullable();
            $t->json('metadata')->nullable();
            $t->timestamps();
            $t->unique(['user_id','event_fingerprint'], 'crm_chatbot_activity_fingerprint_unique');
        });

        Schema::create('crm_mobile_identity_links', function (Blueprint $t): void {
            $t->id();
            $t->char('public_id', 26)->unique();
            $t->unsignedBigInteger('user_id')->index();
            $t->string('surface', 40)->index();
            $t->string('external_identity_id', 160)->index();
            $t->char('crm_contact_public_id', 26)->nullable()->index();
            $t->char('crm_company_public_id', 26)->nullable()->index();
            $t->string('identity_state', 30)->default('matched')->index();
            $t->timestamp('verified_at')->nullable();
            $t->timestamp('last_seen_at')->nullable();
            $t->json('metadata')->nullable();
            $t->timestamps();
            $t->unique(['user_id','surface','external_identity_id'], 'crm_mobile_identity_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('crm_mobile_identity_links');
        Schema::dropIfExists('crm_chatbot_session_grants');
        Schema::dropIfExists('crm_chatbot_activity_links');
        Schema::dropIfExists('crm_chatbot_settings');
        Schema::dropIfExists('crm_chatbot_identities');
    }
};
