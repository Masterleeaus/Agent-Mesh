<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanPrime\System\Commands\CertifyExtensionCommand;
use App\Extensions\TitanPrime\System\Gateways\Bridges\FailClosedEngineBridge;
use App\Extensions\TitanPrime\System\Gateways\Contracts\AiCoreGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\AssuranceGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\AutonomyGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\EngineBridgeContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\EngineGatewayCatalogContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\GovernanceGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\RewindGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\RiskGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\SignalGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\WisdomGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Services\AiCoreGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\AssuranceGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\AutonomyGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\EngineGatewayCatalog;
use App\Extensions\TitanPrime\System\Gateways\Services\GovernanceGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\RewindGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\RiskGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\SignalGateway;
use App\Extensions\TitanPrime\System\Gateways\Services\WisdomGateway;
use App\Extensions\TitanPrime\System\Contracts\PrimeManagerContract;
use App\Extensions\TitanPrime\System\Services\PrimeManager;
use App\Extensions\TitanPrime\System\Persistence\Contracts\PrimeMissionRepositoryContract;
use App\Extensions\TitanPrime\System\Persistence\Repositories\DatabasePrimeMissionRepository;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

final class TitanPrimeServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-prime.php', 'titan-prime');
        if (!$this->app->bound(EngineBridgeContract::class)) {
            $this->app->singleton(EngineBridgeContract::class, FailClosedEngineBridge::class);
        }

        $this->app->singleton(AiCoreGatewayContract::class, AiCoreGateway::class);
        $this->app->singleton(SignalGatewayContract::class, SignalGateway::class);
        $this->app->singleton(RiskGatewayContract::class, RiskGateway::class);
        $this->app->singleton(AssuranceGatewayContract::class, AssuranceGateway::class);
        $this->app->singleton(AutonomyGatewayContract::class, AutonomyGateway::class);
        $this->app->singleton(GovernanceGatewayContract::class, GovernanceGateway::class);
        $this->app->singleton(RewindGatewayContract::class, RewindGateway::class);
        $this->app->singleton(WisdomGatewayContract::class, WisdomGateway::class);
        $this->app->singleton(EngineGatewayCatalogContract::class, EngineGatewayCatalog::class);
        $this->app->singleton(PrimeManagerContract::class, PrimeManager::class);
        $this->app->singleton(PrimeMissionRepositoryContract::class, DatabasePrimeMissionRepository::class);
    }

    public function boot(Kernel $kernel): void
    {
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-prime');
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->publishes([__DIR__ . '/../config/titan-prime.php' => config_path('titan-prime.php')], 'extension');
        $this->registerRoutes();

        if ($this->app->runningInConsole()) {
            $this->commands([CertifyExtensionCommand::class]);
        }
    }

    public function registerKey(): string { return 'titan-prime'; }

    public static function uninstall(): void
    {
        File::delete(config_path('titan-prime.php'));
    }

    private function registerRoutes(): void
    {
        /** @var Router $router */
        $router = $this->app['router'];
        $router->group(['middleware'=>['web','auth'],'prefix'=>'dashboard/user/titan-prime','as'=>'dashboard.user.titan.prime.'], static function (Router $router): void { require __DIR__ . '/../routes/user.php'; });
        $router->group(['middleware'=>['web','auth','admin'],'prefix'=>'dashboard/admin/titan-prime','as'=>'dashboard.admin.titan.prime.'], static function (Router $router): void { require __DIR__ . '/../routes/admin.php'; });
    }
}
