<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Contracts;

use App\Extensions\TitanGovernance\System\Actions\GovernanceActionRequest;

interface GovernanceActionDecisionStoreContract
{
    /** @return array<string,mixed> */
    public function claim(GovernanceActionRequest $request): array;

    /** @param array<string,mixed> $result @return array<string,mixed> */
    public function finalize(string $decisionId, array $result): array;

    /** @return array<string,mixed>|null */
    public function findDecision(string $decisionId): ?array;
}
