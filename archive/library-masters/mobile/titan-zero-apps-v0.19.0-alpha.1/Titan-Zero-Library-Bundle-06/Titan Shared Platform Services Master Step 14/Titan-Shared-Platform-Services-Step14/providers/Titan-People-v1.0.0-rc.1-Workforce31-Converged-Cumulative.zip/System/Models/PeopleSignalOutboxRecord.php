<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Models;
use Illuminate\Database\Eloquent\Model;
final class PeopleSignalOutboxRecord extends Model
{
    protected $table='titan_people_signal_outbox';
    protected $guarded=['id','tenant_company_id'];
    protected $casts=['payload'=>'array','published_at'=>'datetime','occurred_at'=>'datetime'];
}
