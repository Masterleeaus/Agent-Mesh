<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Inbox\UnifiedInboxService;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use App\Extensions\TitanConnect\System\Models\ExternalThreadRead;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Extensions\TitanConnect\System\Services\MessagingAuditService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class InboxController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly ChannelAccessPolicy $channelPolicy,
        private readonly WorkCoreAuthorizationGateway $workCore,
        private readonly MessagingAuditService $audit,
    ) {
    }

    public function index(Request $request, UnifiedInboxService $inbox): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $items = $inbox->items($companyId, $actorId, (int) $request->integer('limit', 50));
        $this->audit->record($companyId, $actorId, 'inbox.viewed', 'inbox', null, null, ['item_count' => count($items)]);
        return response()->json(['data' => $items]);
    }

    public function markExternalRead(Request $request, ExternalThread $thread): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        abort_unless((int) $thread->company_id === $companyId, 404);
        abort_unless($this->channelPolicy->canView($thread->connection, $actorId), 403);
        if ($thread->linked_entity_type !== null && $thread->linked_entity_id !== null) {
            $this->workCore->assertCanAccess($companyId, $actorId, (string) $thread->linked_entity_type, (string) $thread->linked_entity_id);
        }
        $latest = $thread->messages()->where('company_id', $companyId)->latest('created_at')->first();
        $read = ExternalThreadRead::query()->updateOrCreate(
            ['external_thread_id' => $thread->id, 'user_id' => $actorId],
            ['company_id' => $companyId, 'last_read_message_id' => $latest?->id, 'last_read_at' => now()],
        );
        $this->audit->record($companyId, $actorId, 'external-thread.read', 'external-thread', $thread->uuid);
        return response()->json($read);
    }
}
