# Operations

Use `php artisan titan:titan-model-council:certify --json` for extension-local release evidence. Health checks verify owned tables, Signal availability, route/provider registration, and optional peer degradation.

Provider timeouts and quorum thresholds are configured in `config/titan-model-council.php`. Provider circuit state is bounded and automatically cools down before probing again. When optional Risk, AI Core, or Shield peers are absent, health reports the applicable degraded state; required Signal absence makes readiness fail.

Operator rule: Council output remains advisory even at high confidence. Any downstream mutation must travel through the owning capability/governance path outside this extension.

## v1.0.0-rc.1 promotion gates

Before production promotion, verify the exact packaged ZIP on the target MagicAI/Titan host using `php artisan titan:titan-model-council:certify --json`, confirm migrations/tables, resolve the Blueprint `titan-signal` versus current `titan-signal-engine` identity transition, run the approved package signer, and preserve the exact certified package hash. Do not rebuild after host certification because that invalidates package-hash evidence.
