<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function fail_ps(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);} function assert_ps(bool $c,string $m):void{if(!$c)fail_ps($m);} function same_ps(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_ps($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
foreach([
 '/System/Contracts/GovernanceProjectionSinkContract.php',
 '/System/Projection/GovernanceProjectionService.php',
] as $file){if(!is_file($root.$file))fail_ps('missing '.$file);require_once $root.$file;}

use App\Extensions\TitanGovernance\System\Contracts\GovernanceProjectionSinkContract;
use App\Extensions\TitanGovernance\System\Projection\GovernanceProjectionService;

final class PSFakeSink implements GovernanceProjectionSinkContract{
 public array $records=[]; public function record(int $tenantCompanyId,string $type,string $sourceEngine,string $status,array $payload,array $meta=[]):bool{$this->records[]=compact('tenantCompanyId','type','sourceEngine','status','payload','meta');return true;}
 public function recent(int $tenantCompanyId,string $type,int $limit=50):array{return $type==='source-health' ? [
  ['source_engine'=>'titan-signal','status'=>'UNAVAILABLE','captured_at'=>'2026-08-20T16:00:00+10:00','payload'=>[]],
  ['source_engine'=>'titan-signal','status'=>'HEALTHY','captured_at'=>'2026-08-20T15:00:00+10:00','payload'=>[]],
 ] : [];}
}

$sink=new PSFakeSink();
$service=new GovernanceProjectionService($sink);
$result=$service->persist(42,
 ['schema_version'=>'1.0','source'=>'titan-autonomy','source_status'=>'HEALTHY','observed_at'=>'2026-08-20T17:00:00+10:00','entries'=>[]],
 ['schema_version'=>'1.0','source'=>'titan-autonomy','source_status'=>'HEALTHY','observed_at'=>'2026-08-20T17:00:00+10:00','evidence'=>[]],
 ['status'=>'DEGRADED','observed_at'=>'2026-08-20T17:00:00+10:00','sources'=>[
   'titan-autonomy'=>['status'=>'HEALTHY','required'=>true,'observed_at'=>'2026-08-20T17:00:00+10:00','reason'=>null],
   'titan-signal'=>['status'=>'STALE','required'=>true,'observed_at'=>'2026-08-20T16:50:00+10:00','reason'=>null],
 ]],
 ['source_status'=>'HEALTHY','observed_at'=>'2026-08-20T17:00:00+10:00','heatmap'=>['schema_version'=>'1.0','source_status'=>'HEALTHY','observed_at'=>'2026-08-20T17:00:00+10:00','cells'=>[],'recent'=>[],'total_signals'=>0], 'operational_pressure'=>['schema_version'=>'1.0','items'=>[['source_component'=>'crm','pressure_score'=>70,'pressure_band'=>'CRITICAL','reason_codes'=>['QUEUE_DEPTH_HIGH']]],'bottlenecks'=>[],'max_pressure_score'=>70], 'circuit_breakers'=>['schema_version'=>'1.0','source_status'=>'HEALTHY','items'=>[['breaker_key'=>'crm-provider','source_component'=>'crm','state'=>'OPEN']],'open_count'=>1,'half_open_count'=>0]]
);

same_ps('HEALTHY',$result['write_status'],'projection persistence should remain healthy when all writes succeed');
$types=array_column($sink->records,'type');
foreach(['trust-map','autonomy-evidence','source-health','signal-heatmap','operational-pressure','circuit-breaker'] as $type) assert_ps(in_array($type,$types,true),'missing persisted projection type '.$type);
same_ps(50.0,$result['recent_incident_rate_pct'],'one of two recent source-health history rows is unhealthy');

$sinkFail=new class implements GovernanceProjectionSinkContract{
 public function record(int $tenantCompanyId,string $type,string $sourceEngine,string $status,array $payload,array $meta=[]):bool{return false;}
 public function recent(int $tenantCompanyId,string $type,int $limit=50):array{return [];}
};
$degraded=(new GovernanceProjectionService($sinkFail))->persist(42,['source_status'=>'HEALTHY'],['source_status'=>'HEALTHY'],['status'=>'HEALTHY','sources'=>[]],['source_status'=>'HEALTHY','heatmap'=>[],'operational_pressure'=>['items'=>[]],'circuit_breakers'=>['items'=>[]]]);
same_ps('DEGRADED',$degraded['write_status'],'projection storage failure must not masquerade as healthy');

echo "PASS: Governance projection service contract\n";
