# Schema Ownership Map

Titan Payroll owns only `ext_titan_payroll_*` tables. `tenant_company_id` is the canonical boundary. Legacy donor migrations are archived under `docs/reference/legacy-migrations/` and are not loaded. Host users, companies, permissions, expenses, attendance and accounting tables are never mutated.
