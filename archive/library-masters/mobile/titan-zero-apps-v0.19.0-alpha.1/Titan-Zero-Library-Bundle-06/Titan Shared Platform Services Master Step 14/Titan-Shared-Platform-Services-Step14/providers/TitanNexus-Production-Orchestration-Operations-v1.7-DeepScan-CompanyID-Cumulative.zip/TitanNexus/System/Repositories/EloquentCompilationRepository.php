<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Repositories;

use App\Extensions\TitanNexus\System\Contracts\CompilationRepositoryContract;
use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Models\NexusCompilationRecord;
use Illuminate\Database\QueryException;
use InvalidArgumentException;
use LogicException;
use Throwable;

final class EloquentCompilationRepository implements CompilationRepositoryContract
{
    public function save(NexusCompilation $compilation): NexusCompilation
    {
        $data = $compilation->toPersistenceArray();
        $tenant = $compilation->traceContext()->tenantCompanyId();
        $uuid = $compilation->compilationUuid();
        $expectedVersion = $compilation->entityVersion();

        if ($expectedVersion === 0) {
            $nextVersion = 1;
            $data['entity_version'] = $nextVersion;
            try {
                NexusCompilationRecord::query()->create($data);
            } catch (QueryException $exception) {
                throw new LogicException('Concurrent Nexus compilation creation conflict.', 0, $exception);
            }
            return $compilation->withEntityVersion($nextVersion);
        }

        $nextVersion = $expectedVersion + 1;
        $data['entity_version'] = $nextVersion;
        $updated = NexusCompilationRecord::query()
            ->where('tenant_company_id', $tenant)
            ->where('compilation_uuid', $uuid)
            ->where('entity_version', $expectedVersion)
            ->update($data);

        if ($updated !== 1) {
            throw new LogicException('Concurrent Nexus compilation update conflict. Reload the compilation before retrying.');
        }

        return $compilation->withEntityVersion($nextVersion);
    }

    public function findForTenant(int $tenantCompanyId, string $compilationUuid): ?NexusCompilation
    {
        $this->assertTenant($tenantCompanyId);
        $record = NexusCompilationRecord::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->where('compilation_uuid', $compilationUuid)
            ->first();
        return $record === null ? null : $this->safeHydrate($record);
    }

    public function latestForTenant(int $tenantCompanyId, int $limit = 25): array
    {
        $this->assertTenant($tenantCompanyId);
        $resolvedLimit = max(1, min($limit, 100));
        $result = [];
        foreach (NexusCompilationRecord::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->orderByDesc('id')
            ->limit($resolvedLimit)
            ->cursor() as $record) {
            $hydrated = $this->safeHydrate($record);
            if ($hydrated !== null) { $result[] = $hydrated; }
        }
        return $result;
    }

    public function lineageForTenant(int $tenantCompanyId, string $compilationUuid, int $limit = 25): array
    {
        $this->assertTenant($tenantCompanyId);
        $resolvedLimit = max(1, min($limit, 100));
        $lineage = [];
        $seen = [];
        $currentUuid = $compilationUuid;

        while ($currentUuid !== '' && count($lineage) < $resolvedLimit) {
            if (isset($seen[$currentUuid])) { throw new LogicException('Compilation lineage contains a cycle.'); }
            $seen[$currentUuid] = true;
            $record = NexusCompilationRecord::query()
                ->where('tenant_company_id', $tenantCompanyId)
                ->where('compilation_uuid', $currentUuid)
                ->first();
            if ($record === null) { break; }
            $compilation = $this->safeHydrate($record);
            if ($compilation === null) { break; }
            $lineage[] = $compilation;
            $currentUuid = $compilation->parentCompilationUuid() ?? '';
        }
        return $lineage;
    }

    private function safeHydrate(NexusCompilationRecord $record): ?NexusCompilation
    {
        try {
            return NexusCompilation::fromPersistence($record->toArray());
        } catch (Throwable) {
            // Legacy scaffold/corrupt rows are quarantined from read models. They remain retained for forensic/manual repair.
            return null;
        }
    }

    private function assertTenant(int $tenantCompanyId): void
    {
        if ($tenantCompanyId <= 0) { throw new InvalidArgumentException('tenant_company_id must be a positive integer.'); }
    }
}
