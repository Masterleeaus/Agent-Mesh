<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Capabilities;

/** Stable, machine-readable CRM platform contract. No model/table mutation capabilities are exposed. */
final class CrmCapabilityManifest
{
    public function __construct(private readonly ?CrmCapabilityOwnershipMap $ownership=null) {}
    public const PLATFORM = [
        'crm.company-tenancy', 'crm.customer.operations', 'crm.owner.dashboard', 'crm.business.configuration',
        'crm.titanai.tools', 'crm.interaction.actions', 'crm.commercial-calculations', 'crm.governed-business-os',
        'crm.command-receipts', 'crm.domain-signals', 'crm.optimistic-concurrency', 'crm.ai-read-models',
        'crm.outbound-effect-safety', 'crm.titan-connect-boundary', 'crm.cqrs-read-store', 'crm.read-projections',
        'crm.projection-rebuild', 'crm.projection-dead-letters', 'crm.search-port', 'crm.projection-freshness-sla', 'crm.production-readiness', 'crm.core-domain-boundary',
        'crm.customer-identity-authority', 'crm.duplicate-review-workflow', 'crm.commercial-contracts', 'crm.document-rendering',
        'crm.security-portal-integration-gate', 'crm.portal-session-binding', 'crm.api-key-policy', 'crm.webhook-signing-v3', 'crm.staged-imports',
    ];

    /** @return array<string,array<string,mixed>> */
    public function definitions(): array
    {
        $definitions = [
            'crm.company.context.read'=>$this->d('read','crm.settings',false,'Read the resolved authoritative company context.'),
            'crm.ai.context.read'=>$this->d('read','crm.assistant',false,'Read a bounded normalized authoritative CRM context for AI and Workforce consumers.'),
            'crm.customer.search'=>$this->d('read','crm.contacts.view',false,'Search customers/contacts within the active company.'),
            'crm.customer.read'=>$this->d('read','crm.contacts.view',false,'Read one customer/contact within the active company.'),
            'crm.customer.create'=>$this->d('write','crm.contacts.create',true,'Create a customer/contact.'),
            'crm.customer.update'=>$this->d('write','crm.contacts.update',true,'Update a customer/contact.'),
            'crm.contact.search'=>$this->d('read','crm.contacts.view',false,'Search CRM contacts.'),
            'crm.contact.read'=>$this->d('read','crm.contacts.view',false,'Read one CRM contact.'),
            'crm.contact.create'=>$this->d('write','crm.contacts.create',true,'Create a CRM contact.'),
            'crm.contact.update'=>$this->d('write','crm.contacts.update',true,'Update a CRM contact.'),
            'crm.customer.identity.resolve'=>$this->d('read','crm.contacts.view',false,'Resolve normalized CRM identity signals to stable customer unification roots.'),
            'crm.external_identity.link'=>$this->d('write','crm.contacts.update',true,'Link an external channel identity to an existing customer unification root.'),
            'crm.duplicate.review.search'=>$this->d('read','crm.contacts.view',false,'Search the tenant-scoped duplicate review queue.'),
            'crm.duplicate.review.resolve'=>$this->d('write','crm.duplicates.merge',true,'Resolve a blocking duplicate review before conversion or merge.'),
            'crm.record.merge.preview'=>$this->d('read','crm.duplicates.merge',false,'Preview merge field and relationship effects without mutating CRM state.'),
            'crm.company.search'=>$this->d('read','crm.companies.view',false,'Search CRM account companies.'),
            'crm.company.create'=>$this->d('write','crm.companies.create',true,'Create a CRM account/company.'),
            'crm.company.update'=>$this->d('write','crm.companies.update',true,'Update a CRM account/company.'),
            'crm.lead.search'=>$this->d('read','crm.leads.view',false,'Search leads.'),
            'crm.lead.create'=>$this->d('write','crm.leads.create',true,'Create a lead.'),
            'crm.lead.update'=>$this->d('write','crm.leads.update',true,'Update a lead.'),
            'crm.lead.convert'=>$this->d('write','crm.leads.convert',true,'Convert a lead through the CRM lifecycle.'),
            'crm.lead.qualify'=>$this->d('write','crm.leads.update',true,'Update deterministic lead qualification fields through the governed boundary.'),
            'crm.deal.create'=>$this->d('write','crm.deals.create',true,'Create a CRM opportunity.'),
            'crm.deal.update'=>$this->d('write','crm.deals.update',true,'Update a CRM opportunity.'),
            'crm.deal.move'=>$this->d('write','crm.deals.move',true,'Move an opportunity to another pipeline stage.'),
            'crm.deal.win'=>$this->d('write','crm.deals.close',true,'Mark an opportunity won.'),
            'crm.deal.lose'=>$this->d('write','crm.deals.close',true,'Mark an opportunity lost.'),
            'crm.pipeline.create'=>$this->d('write','crm.deals.create',true,'Create a CRM pipeline.'),
            'crm.service.search'=>$this->d('read','crm.services.view',false,'Search the service catalogue.'),
            'crm.service.read'=>$this->d('read','crm.services.view',false,'Read a service.'),
            'crm.service.create'=>$this->d('write','crm.services.manage',true,'Create a service.'),
            'crm.service.update'=>$this->d('write','crm.services.manage',true,'Update a service.'),
            'crm.service_request.search'=>$this->d('read','crm.field_services.view',false,'Search service requests.'),
            'crm.service_request.read'=>$this->d('read','crm.field_services.view',false,'Read a service request.'),
            'crm.service_request.create'=>$this->d('write','crm.service_requests.manage',true,'Create a service request.'),
            'crm.work_order.search'=>$this->d('read','crm.field_services.view',false,'Search work orders.'),
            'crm.work_order.read'=>$this->d('read','crm.field_services.view',false,'Read a work order with operational detail.'),
            'crm.work_order.create'=>$this->d('write','crm.work_orders.manage',true,'Create a work order.'),
            'crm.work_order.update'=>$this->d('write','crm.work_orders.manage',true,'Apply an explicit work-order action.'),
            'crm.work_order.assign'=>$this->d('write','crm.dispatch.manage',true,'Assign a work order to a worker.'),
            'crm.work_order.reschedule'=>$this->d('write','crm.scheduling.manage',true,'Reschedule a work order appointment.'),
            'crm.work_order.cancel'=>$this->d('write','crm.work_orders.manage',true,'Cancel a work order.'),
            'crm.work_order.start'=>$this->d('write','crm.work_orders.manage',true,'Start a governed field work order.'),
            'crm.work_order.pause'=>$this->d('write','crm.work_orders.manage',true,'Pause an in-progress field work order.'),
            'crm.work_order.resume'=>$this->d('write','crm.work_orders.manage',true,'Resume a paused field work order.'),
            'crm.work_order.complete'=>$this->d('write','crm.work_orders.manage',true,'Complete a work order after evidence validation.'),
            'crm.work_order.status.change'=>$this->d('write','crm.work_orders.manage',true,'Apply an explicit governed work-order lifecycle transition.'),
            'crm.work_order.task.complete'=>$this->d('write','crm.work_orders.manage',true,'Complete or update a work-order task/checklist item.'),
            'crm.work_order.material.record'=>$this->d('write','crm.work_orders.manage',true,'Record job material usage through the governed boundary.'),
            'crm.work_order.evidence.record'=>$this->d('write','crm.work_orders.manage',true,'Record a field evidence reference through the governed boundary.'),
            'crm.work_order.note.add'=>$this->d('write','crm.work_orders.manage',true,'Append a governed field note to service history.'),
            'crm.form_submission.submit'=>$this->d('write','crm.forms.manage',true,'Submit a field form through the governed boundary.'),
            'crm.form_response.update'=>$this->d('write','crm.forms.manage',true,'Update a field form response through the governed boundary.'),
            'crm.dispatch.transition'=>$this->d('write','crm.dispatch.manage',true,'Transition a worker dispatch assignment through the governed boundary.'),
            'crm.appointment.search'=>$this->d('read','crm.field_services.view',false,'Search appointments.'),
            'crm.appointment.create'=>$this->d('write','crm.scheduling.manage',true,'Create an appointment.'),
            'crm.calendar.create'=>$this->d('write','crm.calendar.manage',true,'Create a CRM calendar event.'),
            'crm.dispatch.read'=>$this->d('read','crm.field_services.view',false,'Read dispatch assignments.'),
            'crm.location.search'=>$this->d('read','crm.field_services.view',false,'Search service locations.'),
            'crm.location.read'=>$this->d('read','crm.field_services.view',false,'Read one service location.'),
            'crm.location.create'=>$this->d('write','crm.field_services.manage',true,'Create a customer service location.'),
            'crm.asset.search'=>$this->d('read','crm.field_services.view',false,'Search customer assets.'),
            'crm.asset.read'=>$this->d('read','crm.field_services.view',false,'Read one customer asset.'),
            'crm.asset.create'=>$this->d('write','crm.field_services.manage',true,'Create a customer asset.'),
            'crm.time.search'=>$this->d('read','crm.field_services.view',false,'Search field time records.'),
            'crm.material.search'=>$this->d('read','crm.field_services.view',false,'Search field material usage.'),
            'crm.form.search'=>$this->d('read','crm.field_services.view',false,'Search form/checklist templates.'),
            'crm.form.read'=>$this->d('read','crm.field_services.view',false,'Read one form/checklist template.'),
            'crm.form.create'=>$this->d('write','crm.forms.manage',true,'Create a form/checklist template.'),
            'crm.form_submission.search'=>$this->d('read','crm.field_services.view',false,'Search form submissions.'),
            'crm.form_submission.read'=>$this->d('read','crm.field_services.view',false,'Read one form submission.'),
            'crm.evidence.search'=>$this->d('read','crm.field_services.view',false,'Search field evidence metadata.'),
            'crm.evidence.read'=>$this->d('read','crm.field_services.view',false,'Read field evidence metadata.'),
            'crm.review.search'=>$this->d('read','crm.reviews.manage',false,'Search reviews.'),
            'crm.review.read'=>$this->d('read','crm.reviews.manage',false,'Read a review.'),
            'crm.review.create'=>$this->d('write','crm.reviews.manage',true,'Record a customer review through the governed CRM boundary.'),
            'crm.review.request'=>$this->d('write','crm.reviews.manage',true,'Create a governed customer review request.'),
            'crm.recurring.search'=>$this->d('read','crm.field_services.view',false,'Search recurring service agreements.'),
            'crm.recurring.read'=>$this->d('read','crm.field_services.view',false,'Read a recurring service agreement.'),
            'crm.recurring.create'=>$this->d('write','crm.recurring.manage',true,'Create a recurring service agreement.'),
            'crm.service_area.create'=>$this->d('write','crm.service_areas.manage',true,'Create a field-service area.'),
            'crm.quote.search'=>$this->d('read','crm.sales.view',false,'Search quotes/proposals/estimates.'),
            'crm.quote.read'=>$this->d('read','crm.sales.view',false,'Read quotes/proposals/estimates.'),
            'crm.quote.create'=>$this->d('write','crm.sales.manage',true,'Create a draft CRM quote through the Interaction Engine or another governed surface.'),
            'crm.estimate.create'=>$this->d('write','crm.sales.manage',true,'Create a draft CRM estimate.'),
            'crm.quote.prepare'=>$this->d('write','crm.sales.manage',true,'Prepare a quote/estimate.'),
            'crm.quote.approve'=>$this->d('write','crm.sales.manage',true,'Approve/accept a quote.'),
            'crm.quote.transition'=>$this->d('write','crm.sales.manage',true,'Transition an existing proposal/estimate through its governed lifecycle.'),
            'crm.quote.expire'=>$this->d('write','crm.sales.manage',true,'Expire an issued proposal/estimate; expired quotes cannot be accepted.'),
            'crm.quote.withdraw'=>$this->d('write','crm.sales.manage',true,'Withdraw a draft or issued proposal/estimate without deleting contract evidence.'),
            'crm.quote.revise'=>$this->d('write','crm.sales.manage',true,'Create a new draft revision linked to the prior commercial contract.'),
            'crm.quote.revisions'=>$this->d('read','crm.sales.view',false,'Read the revision chain for a proposal/estimate.'),
            'crm.quote.send'=>$this->d('write','crm.sales.manage',true,'Queue an issued proposal/estimate for rendering and delivery through Titan Connect.'),
            'crm.document.render.request'=>$this->d('write','crm.sales.manage',true,'Queue asynchronous rendering for a CRM commercial document.'),
            'crm.document.render.status'=>$this->d('read','crm.sales.view',false,'Read asynchronous CRM document rendering status.'),
            'crm.invoice.read'=>$this->d('read','crm.invoices.view',false,'Read an invoice.'),
            'crm.invoice.status'=>$this->d('read','crm.invoices.view',false,'Read invoice payment/reconciliation status.'),
            'crm.invoice.create'=>$this->d('write','crm.invoices.manage',true,'Create a draft CRM invoice through the Interaction Engine or another governed surface.'),
            'crm.invoice.issue'=>$this->d('write','crm.invoices.manage',true,'Issue a CRM invoice.'),
            'crm.invoice.transition'=>$this->d('write','crm.invoices.manage',true,'Transition an existing invoice through its governed lifecycle.'),
            'crm.invoice.send'=>$this->d('write','crm.invoices.manage',true,'Send an issued CRM invoice to its resolved customer email channel.'),
            'crm.invoice.reminder.send'=>$this->d('write','crm.invoices.manage',true,'Send a routine overdue invoice reminder to the resolved customer email channel.'),
            'crm.invoice.settlement.record_verified'=>$this->d('write','crm.invoices.manage',true,'Apply an authenticated Titan Pay payment/refund outcome to CRM receivable truth without executing money movement.'),
            'crm.invoice.settlement.references'=>$this->d('read','crm.invoices.view',false,'Read verified external settlement references attached to a CRM invoice.'),
            'crm.receivables.aging.read'=>$this->d('read','crm.invoices.view',false,'Read CRM authoritative receivables ageing from invoice balances.'),
            'crm.receivables.reconciliation_issues.read'=>$this->d('read','crm.invoices.view',false,'Read CRM receivable settlement mismatch issues.'),
            'crm.receivables.reconciliation_issue.resolve'=>$this->d('write','crm.invoices.manage',true,'Resolve a reviewed CRM receivable reconciliation mismatch issue.'),
            'crm.credit_note.create'=>$this->d('write','crm.invoices.manage',true,'Create a draft CRM credit note against an open invoice receivable.'),
            'crm.credit_note.issue'=>$this->d('write','crm.invoices.manage',true,'Issue a CRM credit note and reduce authoritative receivable balance.'),
            'crm.credit_note.void'=>$this->d('write','crm.invoices.manage',true,'Void a CRM credit note and recalculate the invoice receivable.'),
            'crm.credit_note.read'=>$this->d('read','crm.invoices.view',false,'Read a CRM credit note and its lines.'),
            'crm.payment.status'=>$this->d('read','crm.invoices.view',false,'Legacy compatibility route owned by Titan Pay; use CRM invoice settlement references for receivable evidence.'),
            'crm.payment.record'=>$this->d('write','crm.invoices.manage',true,'Legacy compatibility route owned by Titan Pay; CRM Core does not execute or persist payment transactions.'),
            'crm.payment.reconcile'=>$this->d('write','crm.invoices.manage',true,'Legacy compatibility route owned by Titan Pay; verified outcomes enter CRM through invoice settlement references.'),
            'crm.import.report'=>$this->d('read','crm.import',false,'Read a staged CRM import impact report.'),
            'crm.import.execute'=>$this->d('write','crm.import',true,'Stage and validate a tenant-scoped CRM import without authoritative domain writes.'),
            'crm.import.commit'=>$this->d('write','crm.import',true,'Commit a staged CRM import only when the reviewed impact hash matches.'),
            'crm.import.rollback'=>$this->d('write','crm.import',true,'Rollback authoritative records created by a completed CRM import batch.'),
            'crm.query.projection.status'=>$this->d('read','crm.settings',false,'Read tenant-scoped CQRS projection freshness, version and lag state.'),
            'crm.query.projection.rebuild'=>$this->d('write','crm.settings',true,'Rebuild one or all disposable CRM read projections from authoritative state.'),
            'crm.query.projection.dead_letters'=>$this->d('read','crm.settings',false,'Read tenant-scoped projection dead-letter evidence and retry state.'),
            'crm.query.projection.dead_letter.retry'=>$this->d('write','crm.settings',true,'Request replay of a reviewed projection dead-letter event.'),
            'crm.search'=>$this->d('read','crm.contacts.view',false,'Search normalized CRM Core read projections through the configured search adapter.'),
            'crm.activity.create'=>$this->d('write','crm.activities.create',true,'Record a CRM activity.'),
            'crm.note.create'=>$this->d('write','crm.activities.create',true,'Create a CRM note.'),
            'crm.tag.create'=>$this->d('write','crm.metadata.manage',true,'Create a CRM tag.'),
            'crm.tag.attach'=>$this->d('write','crm.metadata.manage',true,'Attach a CRM tag to a tenant-scoped subject.'),
            'crm.custom_field.create'=>$this->d('write','crm.metadata.manage',true,'Create a CRM custom field definition.'),
            'crm.custom_field.value.set'=>$this->d('write','crm.metadata.manage',true,'Set a tenant-scoped CRM custom field value.'),
            'crm.settings.update'=>$this->d('write','crm.settings',true,'Update tenant-scoped CRM settings.'),
            'crm.privacy.request'=>$this->d('write','crm.privacy.manage',true,'Create and, when approved, execute a tenant-scoped CRM privacy request.'),
            'crm.retention.policy.update'=>$this->d('write','crm.privacy.manage',true,'Create or update a tenant-scoped CRM retention policy.'),
            'crm.retention.execute'=>$this->d('write','crm.privacy.manage',true,'Execute a confirmed due CRM retention policy through governed command execution.'),
            'crm.chatbot.settings.update'=>$this->d('write','crm.settings',true,'Update tenant-scoped CRM chatbot integration settings.'),
            'crm.record.merge'=>$this->d('write','crm.duplicates.merge',true,'Merge a verified duplicate record into the selected tenant-scoped winner.'),
            'crm.bulk.execute'=>$this->d('write','crm.bulk.manage',true,'Execute a bounded CRM bulk mutation through the governed boundary.'),
            'crm.api_key.create'=>$this->d('write','crm.api_keys.manage',true,'Create a scoped CRM API key.'),
            'crm.api_key.revoke'=>$this->d('write','crm.api_keys.manage',true,'Revoke a CRM API key with an auditable reason.'),
            'crm.api_key.rotate'=>$this->d('write','crm.api_keys.manage',true,'Rotate a CRM API key while preserving lineage.'),
            'crm.webhook.create'=>$this->d('write','crm.webhooks.manage',true,'Create a CRM webhook.'),
            'crm.webhook.rotate'=>$this->d('write','crm.webhooks.manage',true,'Rotate a CRM webhook signing secret with a bounded overlap window.'),
            'crm.webhook.disable'=>$this->d('write','crm.webhooks.manage',true,'Disable a configured CRM webhook.'),
            'crm.email_connection.register'=>$this->d('write','crm.integrations.manage',true,'Register CRM email-connection metadata using an opaque credential reference.'),
            'crm.webhook.dispatch'=>$this->d('write','crm.webhooks.manage',true,'Dispatch a configured CRM webhook through the governed boundary.'),
            'crm.share.create'=>$this->d('write','crm.sharing.manage',true,'Share a CRM record with another Titan user.'),
            'crm.share.revoke'=>$this->d('write','crm.sharing.manage',true,'Revoke an existing CRM record share.'),
            'crm.shared.comment.create'=>$this->d('write','crm.activities.create',true,'Create a governed comment from an authorized shared-record grant.'),
            'crm.settings.business.read'=>$this->d('read','crm.settings',false,'Read the governed business-operating settings bundle.'),
            'crm.support.create'=>$this->d('write','crm.support.manage',true,'Create a support case.'),
            'crm.portal.grant.create'=>$this->d('write','crm.portal.manage',true,'Create Customer Hub access.'),
            'crm.portal.grant.revoke'=>$this->d('write','crm.portal.manage',true,'Revoke Customer Hub access.'),
            'crm.portal.comment.create'=>$this->d('write','crm.portal.manage',true,'Record a Customer Hub comment against the authorized portal grant.'),
            'crm.project.create'=>$this->d('write','crm.projects.manage',true,'Create a CRM project.'),
            'crm.task.create'=>$this->d('write','crm.tasks.manage',true,'Create a CRM task.'),
            'crm.notification.queue'=>$this->d('write','crm.notifications.manage',true,'Queue a governed CRM notification intent.'),
            'crm.time.create'=>$this->d('write','crm.work_orders.manage',true,'Record a governed job time entry.'),
            'crm.automation.create'=>$this->d('write','crm.automations.manage',true,'Create a CRM automation rule.'),
            'crm.automation.toggle'=>$this->d('write','crm.automations.manage',true,'Enable or disable a CRM automation rule.'),
            'crm.staff.schedule'=>$this->d('write','crm.scheduling.manage',true,'Schedule an explicit staff appointment/action.'),
            'crm.owner.dashboard.read'=>$this->d('read','crm.deals.view',false,'Read compact CRM commercial owner decision data.'),
            'crm.business.profile.read'=>$this->d('read','crm.settings',false,'Read business profile configuration.'),
            'crm.business.profile.update'=>$this->d('write','crm.business.configure',true,'Update business profile configuration.'),
            'crm.business.hours.read'=>$this->d('read','crm.settings',false,'Read business hours.'),
            'crm.business.hours.update'=>$this->d('write','crm.business.configure',true,'Update business hours.'),
            'crm.business.service.read'=>$this->d('read','crm.services.view',false,'Read onboarding service configuration.'),
            'crm.business.service.create'=>$this->d('write','crm.business.configure',true,'Create an onboarding service.'),
            'crm.business.service.update'=>$this->d('write','crm.business.configure',true,'Update an onboarding service.'),
            'crm.business.location.create'=>$this->d('write','crm.business.configure',true,'Create a business/service location.'),
            'crm.business.location.update'=>$this->d('write','crm.business.configure',true,'Update a business/service location.'),
            'crm.business.service_area.update'=>$this->d('write','crm.business.configure',true,'Update service area configuration.'),
            'crm.business.booking_rules.read'=>$this->d('read','crm.settings',false,'Read booking rules.'),
            'crm.business.booking_rules.update'=>$this->d('write','crm.business.configure',true,'Update booking rules.'),
            'crm.business.pricing.read'=>$this->d('read','crm.settings',false,'Read pricing defaults.'),
            'crm.business.pricing.update'=>$this->d('write','crm.business.configure',true,'Update pricing defaults.'),
            'crm.business.staff.invite'=>$this->d('write','crm.staff.manage',true,'Invite staff through the host membership action.'),
            'crm.business.staff.role.assign'=>$this->d('write','crm.staff.manage',true,'Assign an operational role through the host membership action.'),
            'crm.business.field_rules.read'=>$this->d('read','crm.settings',false,'Read field rules.'),
            'crm.business.field_rules.update'=>$this->d('write','crm.business.configure',true,'Update field rules.'),
            'crm.business.notification_defaults.update'=>$this->d('write','crm.business.configure',true,'Update notification defaults.'),
            'crm.business.invoice_settings.update'=>$this->d('write','crm.business.configure',true,'Update invoice settings.'),
            'crm.finance.formula_rules.calculate'=>$this->d('read','crm.finance_assistants.use',false,'Evaluate a governed formula/rule calculation using deterministic CRM finance arithmetic.'),
            'crm.finance.pricing.calculate'=>$this->d('read','crm.finance_assistants.use',false,'Calculate a selling price using target margin, markup or fixed-price rules.'),
            'crm.finance.quote_estimate.calculate'=>$this->d('read','crm.finance_assistants.use',false,'Calculate quote or estimate subtotal from explicit job cost components.'),
            'crm.finance.discount_promotion.calculate'=>$this->d('read','crm.finance_assistants.use',false,'Calculate discount amount and resulting price.'),
            'crm.finance.margin_profitability.calculate'=>$this->d('read','crm.finance_assistants.use',false,'Calculate gross profit, margin, markup and margin decision status.'),
            'crm.finance.tax.calculate'=>$this->d('read','crm.finance_assistants.use',false,'Calculate tax/GST exclusive, tax amount and total.'),
            'crm.bookkeeping.overview.read'=>$this->d('read','crm.bookkeeping.view',false,'Read cash-basis income, expense, GST and cash movement summary.'),
            'crm.bookkeeping.transactions.search'=>$this->d('read','crm.bookkeeping.view',false,'Search manual and domain-linked bookkeeping records.'),
            'crm.bookkeeping.transaction.create'=>$this->d('write','crm.bookkeeping.manage',true,'Create a manual bookkeeping income or expense record.'),
            'crm.bookkeeping.category.search'=>$this->d('read','crm.bookkeeping.view',false,'List bookkeeping categories.'),
            'crm.bookkeeping.category.create'=>$this->d('write','crm.bookkeeping.categories.manage',true,'Create a bookkeeping category.'),
            'crm.bookkeeping.pnl.read'=>$this->d('read','crm.bookkeeping.reports.view',false,'Read the simple cash-basis profit and loss report.'),
            'crm.pay.preferences.read'=>$this->d('read','crm.pay.view',false,'Read enabled payment rails and ordering.'),
            'crm.pay.preference.update'=>$this->d('write','crm.pay.manage',true,'Update a payment rail preference.'),
            'crm.pay.receivables.read'=>$this->d('read','crm.pay.view',false,'Read accounts-receivable aging from CRM invoices.'),
            'crm.pay.intent.create'=>$this->d('write','crm.pay.manage',true,'Create a payment intent and secure checkout link for an invoice.'),
            'crm.pay.collection.search'=>$this->d('read','crm.pay.view',false,'Search Titan Collect cases.'),
            'crm.pay.collection.open'=>$this->d('write','crm.pay.collect.manage',true,'Open a collection case for an outstanding invoice.'),
            'crm.pay.collection.event'=>$this->d('write','crm.pay.collect.manage',true,'Record a Titan Collect reminder, promise-to-pay or escalation event.'),
            'crm.pay.job_invoice.prepare'=>$this->d('write','crm.pay.manage',true,'Prepare or sync a draft job invoice from CRM work-order services and Locker materials.'),
            'crm.pay.reconciliation.rank'=>$this->d('read','crm.pay.view',false,'Rank bank-deposit evidence against open receivables with explainable confidence scoring.'),
            'crm.pay.collection.suppression.evaluate'=>$this->d('read','crm.pay.view',false,'Evaluate whether a collection action should be suppressed by payment, dispute, plan, promise or pause state.'),
            'crm.pay.job_profitability.calculate'=>$this->d('read','crm.pay.view',false,'Calculate job revenue, direct costs, profit and margin from explicit monetary inputs.'),
            'crm.locker.inventory.search'=>$this->d('read','crm.locker.view',false,'Search Locker inventory and consumables.'),
            'crm.locker.inventory.create'=>$this->d('write','crm.locker.manage',true,'Create a Locker inventory or consumable item.'),
            'crm.locker.locations.read'=>$this->d('read','crm.locker.view',false,'Read Locker warehouse, van, site and worker stock locations.'),
            'crm.locker.location.create'=>$this->d('write','crm.locker.manage',true,'Create a Locker stock location.'),
            'crm.locker.stock.on_hand'=>$this->d('read','crm.locker.view',false,'Read current stock on hand from the movement ledger.'),
            'crm.locker.stock.receive'=>$this->d('write','crm.locker.stock.manage',true,'Receive stock into a Locker location.'),
            'crm.locker.stock.transfer'=>$this->d('write','crm.locker.stock.manage',true,'Transfer stock between Locker locations.'),
            'crm.locker.job.consume'=>$this->d('write','crm.locker.stock.manage',true,'Consume Locker stock against a CRM work order and record job material cost.'),
            'crm.locker.assets.read'=>$this->d('read','crm.locker.view',false,'Read tools, equipment or fleet records.'),
            'crm.locker.asset.create'=>$this->d('write','crm.locker.assets.manage',true,'Create a tool, equipment or fleet asset record.'),
            'crm.locker.stock.available'=>$this->d('read','crm.locker.view',false,'Read stock available after active reservations.'),
            'crm.locker.allocation.search'=>$this->d('read','crm.locker.view',false,'Search Locker stock reservations and allocations.'),
            'crm.locker.allocation.reserve'=>$this->d('write','crm.locker.stock.manage',true,'Reserve Locker stock for a CRM work order.'),
            'crm.locker.allocation.release'=>$this->d('write','crm.locker.stock.manage',true,'Release a Locker stock reservation.'),
            'crm.locker.allocation.fulfill'=>$this->d('write','crm.locker.stock.manage',true,'Fulfil reserved stock through an immutable stock movement.'),
            'crm.locker.reorder.rules.read'=>$this->d('read','crm.locker.view',false,'Read Locker reorder rules.'),
            'crm.locker.reorder.rule.update'=>$this->d('write','crm.locker.manage',true,'Create or update a Locker reorder rule.'),
            'crm.locker.reorder.suggestions.read'=>$this->d('read','crm.locker.view',false,'Read reorder suggestions based on available stock.'),
            'crm.locker.supplier.create'=>$this->d('write','crm.locker.purchasing.manage',true,'Create a Titan Gear supplier.'),
            'crm.locker.supplier.rating.read'=>$this->d('read','crm.locker.view',false,'Read Locker supplier rating history and averages.'),
            'crm.locker.supplier.rating.create'=>$this->d('write','crm.locker.purchasing.manage',true,'Rate a Locker supplier for quality, delivery and service.'),
            'crm.locker.purchase_order.search'=>$this->d('read','crm.locker.view',false,'Search Locker purchase orders.'),
            'crm.locker.purchase_order.create'=>$this->d('write','crm.locker.purchasing.manage',true,'Create a draft Locker purchase order.'),
            'crm.locker.purchase_order.submit'=>$this->d('write','crm.locker.purchasing.manage',true,'Submit a draft Locker purchase order.'),
            'crm.locker.purchase_order.approve'=>$this->d('write','crm.locker.purchasing.manage',true,'Approve a submitted Locker purchase order.'),
            'crm.locker.purchase_order.cancel'=>$this->d('write','crm.locker.purchasing.manage',true,'Cancel a receivable or unreceived Locker purchase order.'),
            'crm.locker.goods_receipt.search'=>$this->d('read','crm.locker.view',false,'Search Locker goods receipts.'),
            'crm.locker.goods_receipt.create'=>$this->d('write','crm.locker.purchasing.manage',true,'Receive purchase-order goods into Locker stock.'),
            'crm.locker.stock_count.search'=>$this->d('read','crm.locker.view',false,'Search Locker cycle and full stock counts.'),
            'crm.locker.stock_count.create'=>$this->d('write','crm.locker.stock_counts.manage',true,'Create a Locker stock count snapshot.'),
            'crm.locker.stock_count.complete'=>$this->d('write','crm.locker.stock_counts.manage',true,'Complete a Locker stock count and post approved variances.'),
            'crm.locker.stock_transfer.search'=>$this->d('read','crm.locker.view',false,'Search Locker requested and in-transit stock transfers.'),
            'crm.locker.stock_transfer.create'=>$this->d('write','crm.locker.transfers.manage',true,'Create a Locker stock transfer request.'),
            'crm.locker.stock_transfer.dispatch'=>$this->d('write','crm.locker.transfers.manage',true,'Dispatch a Locker stock transfer into in-transit state.'),
            'crm.locker.stock_transfer.receive'=>$this->d('write','crm.locker.transfers.manage',true,'Receive an in-transit Locker stock transfer.'),
            'crm.locker.stock_transfer.cancel'=>$this->d('write','crm.locker.transfers.manage',true,'Cancel a requested Locker stock transfer.'),
            'crm.locker.reorder.purchase_orders.draft'=>$this->d('write','crm.locker.purchasing.manage',true,'Convert selected Locker reorder suggestions into draft purchase orders.'),
            'crm.locker.tool.checkout'=>$this->d('write','crm.locker.assets.manage',true,'Check out a Locker tool to a custodian.'),
            'crm.locker.tool.return'=>$this->d('write','crm.locker.assets.manage',true,'Return a Locker tool to available custody.'),
            'crm.locker.tool.damage'=>$this->d('write','crm.locker.assets.manage',true,'Mark a Locker tool damaged with an audit event.'),
            'crm.locker.tool.lost'=>$this->d('write','crm.locker.assets.manage',true,'Mark a Locker tool lost with an audit event.'),
            'crm.locker.fleet.assign'=>$this->d('write','crm.locker.fleet.manage',true,'Assign a fleet vehicle to a worker.'),
            'crm.locker.fleet.unassign'=>$this->d('write','crm.locker.fleet.manage',true,'Unassign a fleet vehicle.'),
            'crm.locker.fleet.odometer.update'=>$this->d('write','crm.locker.fleet.manage',true,'Record a monotonic fleet odometer reading.'),
            'crm.locker.fleet.status.update'=>$this->d('write','crm.locker.fleet.manage',true,'Change operational fleet status.'),
            'crm.locker.maintenance.read'=>$this->d('read','crm.locker.view',false,'Read due and overdue Locker maintenance.'),
            'crm.locker.maintenance.schedule'=>$this->d('write','crm.locker.assets.manage',true,'Schedule Locker asset maintenance.'),
            'crm.locker.maintenance.complete'=>$this->d('write','crm.locker.assets.manage',true,'Complete Locker maintenance and set next service state.'),
            'crm.locker.maintenance.cancel'=>$this->d('write','crm.locker.assets.manage',true,'Cancel scheduled Locker maintenance.'),
        ];

        return $this->enrich($definitions);
    }

    public static function platformCapabilities(): array { return self::PLATFORM; }

    /** @param array<string,array<string,mixed>> $definitions */
    private function enrich(array $definitions): array
    {
        foreach ($definitions as $capability => $definition) {
            $mode=(string)($definition['mode']??'read');
            $isWrite=$mode==='write';
            $isFinancial=str_contains($capability,'.payment.')||str_contains($capability,'.invoice.')||str_contains($capability,'.pay.')||str_contains($capability,'.bookkeeping.');
            $isExternalAccess=str_contains($capability,'.api_key.')||str_contains($capability,'.webhook.')||str_contains($capability,'.share.')||str_contains($capability,'.portal.grant.');
            $isOperational=str_contains($capability,'.work_order.')||str_contains($capability,'.appointment.')||str_contains($capability,'.dispatch.')||str_contains($capability,'.locker.');
            $isCommunicationEffect=in_array($capability,['crm.invoice.send','crm.invoice.reminder.send'],true);
            $definitions[$capability]=array_merge($definition,[
                'capability_name'=>$capability,
                'owning_extension'=>$this->ownerOf($capability),
                'input_contract'=>[
                    'type'=>'object',
                    'command_contract_version'=>$isWrite?3:null,
                    'tenant_field'=>'company_id',
                    'tenant_from_trusted_context'=>true,
                    'required_command_fields'=>$isWrite?['command_id','company_id','actor','capability','trace_id','correlation_id','idempotency_key']:[],
                    'trace_fields'=>['trace_id','correlation_id','causation_id'],
                    'idempotency_required'=>$isWrite && (bool)($definition['idempotent']??false),
                    'expected_version_supported'=>$isWrite && $this->targetsExistingEntity($capability),
                    'expected_entity_version_required'=>$isWrite && $this->targetsExistingEntity($capability),
                ],
                'output_contract'=>[
                    'type'=>'object',
                    'authoritative'=>$isWrite,
                    'receipt_required'=>$isWrite,
                    'receipt_contract'=>$isWrite?'crm.command-receipt.v3':null,
                    'resource_reference'=>true,
                    'entity_version'=>$isWrite && $this->targetsExistingEntity($capability),
                    'affected_resources'=>$isWrite,
                    'rewind_reference'=>$isWrite,
                    'signal_references'=>$isWrite,
                ],
                'risk_profile'=>$isFinancial||$isExternalAccess?'high':($isOperational&&$isWrite?'medium':'low'),
                'autonomy_requirement'=>$isWrite?'titan_autonomy_decision':'none',
                'evidence_requirements'=>$isWrite?($isFinancial?['actor_authorization','financial_source_evidence','command_bus_decision']:['actor_authorization','command_bus_decision']):[],
                'offline_policy'=>$isWrite?($isFinancial||$isExternalAccess?'OFFLINE_BLOCKED':'OFFLINE_PREPARE_ONLY'):'ONLINE_EXECUTE',
                'reversibility'=>$this->reversibility($capability,$mode),
                'idempotency_strategy'=>$isWrite?'tenant+capability+idempotency_key':'not_applicable',
                'concurrency_policy'=>$isWrite&&$this->targetsExistingEntity($capability)?'optimistic_expected_version':'none',
                'side_effect_class'=>$isCommunicationEffect?'external':($isWrite?'internal':'none'),
                'side_effect_execution'=>$isCommunicationEffect?'after_commit_outbox':($isWrite?'in_transaction':'not_applicable'),
                'delivery_receipt_required'=>$isCommunicationEffect,
                'external_owner'=>$isCommunicationEffect?'titan_connect':null,
                'provider_delivery_authoritative'=>$isCommunicationEffect?false:null,
                'governance'=>[
                    'risk_engine'=>$isWrite,
                    'assurance_engine'=>$isWrite,
                    'autonomy_engine'=>$isWrite,
                    'command_bus'=>$isWrite,
                    'signal_event'=>$isWrite,
                    'rewind_reference'=>$isWrite,
                ],
            ]);
        }
        return $definitions;
    }

    private function ownerOf(string $capability): string
    {
        if($this->ownership!==null) return $this->ownership->owner($capability);
        if(str_starts_with($capability,'crm.locker.')) return 'titan-locker';
        if(str_starts_with($capability,'crm.bookkeeping.')) return 'titan-ledger';
        if(str_starts_with($capability,'crm.pay.')) return 'titan-pay';
        if($capability==='crm.staff.schedule') return 'titan-field';
        foreach(['crm.service.','crm.service_request.','crm.work_order.','crm.appointment.','crm.dispatch.','crm.location.','crm.asset.','crm.time.','crm.material.','crm.form.','crm.form_submission.','crm.evidence.','crm.review.','crm.recurring.','crm.service_area.','crm.support.'] as $prefix){
            if(str_starts_with($capability,$prefix)) return 'titan-field';
        }
        return 'crm';
    }

    private function targetsExistingEntity(string $capability): bool
    {
        foreach (['.update','.move','.win','.lose','.convert','.assign','.reschedule','.cancel','.approve','.transition','.issue','.send','.record','.reconcile','.release','.fulfill','.submit','.complete','.dispatch','.receive','.return','.damage','.lost','.unassign'] as $suffix) {
            if (str_contains($capability,$suffix)) return true;
        }
        return false;
    }

    private function reversibility(string $capability,string $mode): string
    {
        if($mode==='read')return 'not_applicable';
        if(str_contains($capability,'.payment.')||str_contains($capability,'.reconcile')||str_contains($capability,'.goods_receipt.')||str_contains($capability,'.stock.'))return 'compensation_required';
        if(str_contains($capability,'.send')||str_contains($capability,'.webhook.'))return 'external_side_effect_not_reversible';
        return 'domain_compensation_or_followup';
    }

    private function d(string $mode,string $permission,bool $idempotent,string $description): array
    { return compact('mode','permission','idempotent','description'); }
}
