<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
foreach ([
    'System/DTO/AuthorityContext.php',
    'System/DTO/ActorContext.php',
    'System/DTO/RuntimeContext.php',
    'System/DTO/ExecutionIntent.php',
    'System/DTO/PlanConstraint.php',
    'System/DTO/PlanDependency.php',
    'System/DTO/PlanInput.php',
    'System/DTO/PlanOutput.php',
    'System/DTO/RetryPolicy.php',
    'System/DTO/WorkforceAssignment.php',
    'System/DTO/PlanStep.php',
    'System/DTO/PlanEnvelope.php',
    'System/DTO/ValidationIssue.php',
    'System/DTO/ValidationReport.php',
    'System/Contracts/PlanValidatorContract.php',
    'System/Services/PlanValidator.php',
] as $relative) {
    require_once $root . '/' . $relative;
}

use App\Extensions\TitanAICore\System\DTO\ActorContext;
use App\Extensions\TitanAICore\System\DTO\ExecutionIntent;
use App\Extensions\TitanAICore\System\DTO\PlanEnvelope;
use App\Extensions\TitanAICore\System\DTO\RuntimeContext;
use App\Extensions\TitanAICore\System\Services\PlanValidator;

$validator = new PlanValidator();
$untrustedActor = new ActorContext('actor-1', 'human', 'company-1', [], 1, false);
$untrustedContext = new RuntimeContext('company-1', $untrustedActor, 't', 'c', 'cause', 'root', 'op', 'idem');
$report = $validator->validate(new PlanEnvelope('plan-1', $untrustedContext, new ExecutionIntent('test', 'test')));
if (($report->errors[0]->code ?? null) !== 'UNTRUSTED_ACTOR_CONTEXT') {
    fwrite(STDERR, "validator did not reject untrusted actor first\n"); exit(1);
}

$trustedWrongTenantActor = new ActorContext('actor-1', 'human', 'company-2', [], 1, true, 'test');
$mismatchContext = new RuntimeContext('company-1', $trustedWrongTenantActor, 't', 'c', 'cause', 'root', 'op', 'idem');
$report = $validator->validate(new PlanEnvelope('plan-2', $mismatchContext, new ExecutionIntent('test', 'test')));
if (($report->errors[0]->code ?? null) !== 'TENANT_CONTEXT_MISMATCH') {
    fwrite(STDERR, "validator did not reject actor/runtime tenant mismatch first\n"); exit(1);
}

$trustedActor = new ActorContext('actor-1', 'human', 'company-1', [], 1, true, 'test');
$trustedContext = new RuntimeContext('company-1', $trustedActor, 't', 'c', 'cause', 'root', 'op', 'idem');
$report = $validator->validate(new PlanEnvelope('plan-3', $trustedContext, new ExecutionIntent('test', 'test')));
if (($report->errors[0]->code ?? null) !== 'DAG_VALIDATOR_NOT_IMPLEMENTED') {
    fwrite(STDERR, "trusted context should proceed to fail-closed DAG gate\n"); exit(1);
}

fwrite(STDOUT, "Pass 3 plan validation security test: PASS\n");
