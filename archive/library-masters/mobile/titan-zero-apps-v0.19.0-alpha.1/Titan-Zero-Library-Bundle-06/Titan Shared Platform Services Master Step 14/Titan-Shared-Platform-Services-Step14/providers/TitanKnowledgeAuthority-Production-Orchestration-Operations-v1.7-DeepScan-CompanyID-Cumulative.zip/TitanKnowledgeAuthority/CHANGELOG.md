## Persistent orchestration v1.5

- Added durable outbox, lease recovery, deduplication, retry/dead-letter/redrive, provider deferral and health telemetry for Workforce handoffs.


## Runtime hardening pass
- Added container-bound Workforce loop runtime with fail-closed provider health aggregation.
- Enforced canonical `company_id` plus full causal context on cross-extension handoffs.
- Added provider/version pinning and authority-neutral handoff envelopes.
- Enforced outcome lineage and execution receipts.
- Quarantined raw host-menu database access as legacy navigation compatibility only.

# Changelog

## v0.5.0-alpha.4 H2 — Menu Navigation Compatibility
- Corrects the Blueprint MenuContributionRegistry call shape to register stable contributor classes instead of menu-definition arrays.
- Adds separate user/admin contributor classes so each navigation registry resolves the correct definitions.
- Adds Installer 1.7.6 / legacy MagicAI `menus` table self-heal with named-route guards and `MenuService::regenerate()`.
- Preserves existing administrator menu order/enabled state on self-heal.
- Normalizes the menu icon to the Blueprint-proven `tabler-folders` component.
- Adds standalone regression coverage for both modern and legacy navigation paths.

## 0.5.0-alpha.4 — Immutable Source Versioning
- Adds an explicit internal append-only source-version write contract and service.
- Serializes version writes per source using a database transaction and source-row lock.
- Adds deterministic sequence allocation and stable version keys.
- Deduplicates normalized content by SHA-256 and returns an explicit idempotent result.
- Automatically supersedes only the latest prior version; callers cannot select arbitrary predecessors.
- Derives tenant lineage from the canonical source instead of request input.
- Preserves normalized content hashes and byte-level raw-evidence hashes/references.
- Rejects inactive, legacy and malformed source scopes before append.
- Adds effective-window, provenance and causal-lineage validation.
- Keeps remote acquisition, queues, schedules and public resolution disabled.

## 0.5.0-alpha.4 — Immutable Source Versioning
- Adds trusted-context transactional source-version append service.
- Serializes per-source allocation with a scoped source row lock.
- Adds deterministic sequence/version-key allocation and idempotent content-hash deduplication.
- Validates optional expected predecessor and existing source/version tenant lineage.
- Copies tenant ownership from the source instead of caller input.
- Strengthens immutable model creation/update/delete invariants and reverse supersession lineage.
- Replaces source-to-version cascade deletion with restricted deletion.
- Keeps public capabilities health-only and all remote acquisition/refresh paths disabled.

## 0.4.0-alpha.3 — Tenant, Platform & Jurisdiction Scope
- Adds trusted `KnowledgeAccessContext` and host resolver contract.
- Defaults context resolution to fail closed while preserving host-supplied resolver bindings.
- Adds canonical platform/matching-tenant/explicit-jurisdiction visibility policy.
- Adds scoped source and source-version repositories.
- Adds internal source/version metadata catalog reads with no caller-supplied tenant IDs.
- Excludes legacy and malformed scope rows from canonical scoped reads.
- Makes the legacy primitive jurisdiction guard fail closed so it cannot bypass the trusted allowlist.
- Adds cross-tenant and ungranted-jurisdiction regression coverage.
- Keeps public capability advertisement health-only and keeps remote acquisition disabled.

## 0.3.0-alpha.2 — Canonical Knowledge Domain Foundation
- Expands `titan_knowledge_sources` additively while preserving legacy rows.
- Adds durable source versions, documents, sections, claims, jurisdictions and applicability tables.
- Adds Eloquent models for the seven canonical knowledge entities.
- Makes source-version updates/deletes fail closed at the model boundary.
- Adds deterministic SHA-256 source content hashing.
- Adds platform/jurisdiction/tenant scope value objects and a fail-closed tenant scope guard.
- Adds source authority, publisher, provenance, access-policy and freshness metadata.
- Adds trace/correlation/causation lineage across normalized durable records.
- Adds extension-local document and section schemas.
- Keeps source connectors, queues, schedules, refresh and `knowledge.resolve` disabled.

## 0.2.0-alpha.1 — Blueprint v4.2.1 / Installer 1.7.8 Rebase
- Rebases the extension to canonical sidecar schema 2.2.
- Adopts `intelligence-engine` + `knowledge-authority` architecture identity.
- Moves rich architecture out of root `extension.json` into the sidecar.
- Adds the eight Knowledge Authority runtime/evidence schemas from Blueprint Step 11.
- Adds canonical ownership, governance, data, authorization, rollout, supply-chain and documentation contracts.
- Keeps the callable surface truthful: health only; refresh/resolution remain disabled.

## v0.5.0-alpha.4 H1 — Installer 1.7.6 compatibility
- Restored required root `extension.json` marketplace identity including `name` and `type` for the live Installer 1.7.6 validator.
- Restored Installer 1.7.6 migration/dependency/requires/publishes metadata while retaining Titan schema/slug/folder/provider/integrity fields.
- Preserved canonical architecture in `extension.manifest.json` schema 2.2; no runtime/domain downgrade.
- Added standalone regression coverage for the live 1.7.6 manifest contract.
