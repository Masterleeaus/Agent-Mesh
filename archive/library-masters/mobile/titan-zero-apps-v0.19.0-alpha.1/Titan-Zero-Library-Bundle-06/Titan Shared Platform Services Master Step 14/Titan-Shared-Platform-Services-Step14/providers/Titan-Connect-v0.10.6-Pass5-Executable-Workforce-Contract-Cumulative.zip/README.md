# Titan Connect v0.10.6

> v0.10.6 repairs live MagicAI dashboard placement/styling for Inbox and Channels, web-installer asset publishing, and the PHP 8.3 VoiceProvider inheritance fatal.


Live MagicAI menu materialization is included: Inbox and Channels are synchronized into the host `menus` table during migration, with Super Admin channel settings attached to the existing Settings administrator root.

## v0.10.6 live dashboard rendering repair

- returns MagicAI `panel.layout.app` as the **root Laravel View** for Titan Connect full-page UI;
- renders Titan Connect screens as content partials injected into the host `content` section;
- preserves `@push('css')` / `@push('script')` stacks until the host layout consumes them;
- mirrors the current MagicAI route wrapper middleware on provider-loaded dashboard routes;
- explicitly declares `titan-connect-assets` and `titan-connect-config` in `extension.json` so the Titan Extension Manager publishes them during install/upgrade;
- preserves the v0.10.5 PHP 8.3 `VoiceProvider` inheritance fix and corrected user Inbox/Channels menu placement.

## Product overview

Titan Zero's company-isolated communications extension: internal team messaging, omnichannel customer messaging, operator inbox, secure provider onboarding, voice sessions, company-aware rate limiting, connection diagnostics and host-readiness tooling behind one canonical runtime.

## Core capabilities

- direct, group and business-channel team conversations;
- WhatsApp via Meta Cloud API **or Twilio WhatsApp** under one canonical provider;
- Messenger, Instagram, Telegram, SMS and TitanMobileCore push;
- professional operator inbox with filters, assignment, pin/close, customer context, tags, internal notes, canned replies, exports and unread notifications;
- AI reply rewrite actions through a configurable host adapter;
- Meta OAuth onboarding for Messenger/Instagram and Telegram automatic webhook registration;
- OpenAI Realtime and ElevenLabs voice-session support with transcript persistence and browser audio client;
- optional ElevenLabs voice-agent/knowledge integration behind a fail-closed host contract;
- signed webhooks, replay/idempotency protection, delivery receipts, retries and provider health checks;
- encrypted per-company provider credentials;
- canonical attachment validation/scanning/storage and provider media ingestion;
- governed WorkCore, Chatbot, TitanAI/Interaction and TitanMobileCore boundaries;
- audit/privacy/retention hooks and persistence-first realtime fallback.

## Production-readiness foundation

- company + actor scoped rate limits for send/admin/upload/AI/voice mutation surfaces;
- safe per-connection diagnostics with queued/failed delivery counts, webhook failures, activity and credential-presence state without returning secrets;
- operator connection manager and dedicated Titan Connect Settings page;
- `php artisan titan-connect:diagnose` host-readiness command;
- idempotent voice transcript events through `client_event_id`;
- voice lifecycle guards, duplicate active-context protection, elapsed call timer, mute/unmute and idempotent browser end handling.

## Navigation foundation

- top-level **Channels** menu with dedicated WhatsApp, Messenger, Instagram, Telegram, SMS, Voice and Push / Mobile settings links;
- separate top-level **Inbox** menu with Unified, Team / Internal, External, Assigned to Me, Unassigned, Needs Human and Closed / Archived queues;
- company + actor scoped asynchronous unread/action badges, never cached in MagicAI's global structural menu catalogue;
- Blueprint-v3 `MenuContributionRegistry` and `ContributionRegistry` host integration, including Super Admin Channels navigation;
- provider settings/diagnostics pages and an official-style header Inbox notification surface.

## Security boundary

`company_id` is the sole active tenant/security boundary. Company ownership is enforced in models, route binding, queries, queued webhook identity, credential lookups, rate-limit keys, delivery locks, diagnostics, storage paths and realtime channels. Provider payloads and browser clients cannot select the active company.

## Installation / upgrade

The extension manifest is `extension.json`. Run all migrations in `database/migrations/`, including:

- `2026_08_09_000004_add_official_comms_donor_features.php`
- `2026_08_09_000005_harden_voice_runtime.php`

Existing v0.6 data is preserved. Publish assets/config through the host's normal extension workflow or Laravel publish tags:

```bash
php artisan vendor:publish --tag=titan-connect-config
php artisan vendor:publish --tag=titan-connect-assets
```

Run host diagnostics after installation:

```bash
php artisan titan-connect:diagnose
```

## Standalone verification

```bash
php tests/Contract/run.php
php tests/Contract/integration_pass.php
php tests/Contract/host_certification_pass.php
php tests/Contract/donor_extraction_pass.php
php tests/Contract/production_readiness_pass.php
php tests/Contract/runtime_certification_pass.php
php tests/Contract/navigation_menu_pass.php
php tests/Contract/dashboard_shell_menu_repair_pass.php
php tests/Contract/dashboard_root_render_pass.php
php tests/Contract/dashboard_renderer_runtime.php
php tests/Contract/provider_inheritance_runtime_pass.php
php tools/verify-company-boundary.php
php tools/verify-package.php
node --check resources/assets/js/team-chat/team-chat-client.js
node --check resources/assets/js/team-chat/business-channels.js
node --check resources/assets/js/operator-inbox.js
node --check resources/assets/js/voice-call-client.js
node --check resources/assets/js/settings.js
node --check resources/assets/js/navigation-badges.js
node --check resources/assets/js/unified-inbox.js
node --check resources/assets/js/channel-settings.js
```

Passing standalone checks does not certify the actual Titan Zero host. Run the opt-in Laravel/MySQL suite and provider sandbox smoke tests in `docs/HOST_CERTIFICATION.md` before production certification.
