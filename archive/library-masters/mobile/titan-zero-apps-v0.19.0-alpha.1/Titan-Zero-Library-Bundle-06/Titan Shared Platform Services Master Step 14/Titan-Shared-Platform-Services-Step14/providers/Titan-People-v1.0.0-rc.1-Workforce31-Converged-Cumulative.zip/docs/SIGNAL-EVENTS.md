# Signal events

Pass 4 adds `titan_people_signal_outbox`, an append-only tenant-scoped durable outbox. Events carry `tenant_company_id`, opaque/source references, event type, trace/correlation/causation IDs, idempotency key and a privacy-minimized facts payload.

`PeopleSignalSanitizer` is allowlist-based. Names, email addresses, phone numbers, emergency-contact bodies, document bytes/content and bank/payment data are never valid Signal/Rewind fields. Employment lifecycle free-text reasons are deliberately omitted from emitted facts.

`PeopleOutboxDispatcher` delivers pending facts only through the host-supplied `PeopleSignalDeliveryPort`. The default adapter fails closed. Successful delivery records an external receipt by marking the row published; failures increment bounded attempts and retain the row for later replay.

Rewind contribution uses `RewindPeopleSourceContributor`: it returns source fact type, aggregate/event references, timestamps and sanitized facts. It never copies People document contents or private profile payloads.
