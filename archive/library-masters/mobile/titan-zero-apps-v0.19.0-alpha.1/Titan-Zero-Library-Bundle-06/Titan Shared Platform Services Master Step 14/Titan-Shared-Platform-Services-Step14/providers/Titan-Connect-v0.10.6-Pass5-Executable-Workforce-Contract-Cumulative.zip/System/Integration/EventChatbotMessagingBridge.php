<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Integration;

use App\Extensions\TitanConnect\System\Contracts\ChatbotMessagingBridge;
use App\Extensions\TitanConnect\System\Models\ExternalMessage;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use RuntimeException;

final class EventChatbotMessagingBridge implements ChatbotMessagingBridge
{
    public function onInboundMessage(int $companyId, ExternalThread $thread, ExternalMessage $message): void
    {
        if ((int) $thread->company_id !== $companyId || (int) $message->company_id !== $companyId) {
            throw new RuntimeException('Chatbot inbound company scope mismatch.');
        }

        event('titan-connect.chatbot.inbound', [$companyId, $thread, $message]);
    }

    public function onHumanHandoffChanged(int $companyId, ExternalThread $thread, string $state, ?int $actorId = null): void
    {
        if ((int) $thread->company_id !== $companyId) {
            throw new RuntimeException('Chatbot handoff company scope mismatch.');
        }

        event('titan-connect.chatbot.handoff', [$companyId, $thread, $state, $actorId]);
    }
}
