<?php

declare(strict_types=1);
namespace App\Extensions\InteractionEngine\System\Journey;
final class JourneyRegistry
{
    /** @var array<string,JourneyDefinition> */ private array$journeys=[];
    public function __construct(){
        $this->register(new JourneyDefinition('business_initial_onboarding','Business initial onboarding',['field_home_services_onboarding_v1'],['onboarding'],metadata:['profile'=>'field_home_services']));
        $this->register(new JourneyDefinition('new_customer_onboarding','New customer onboarding',['new_customer_v1'],['hub','command']));
        $this->register(new JourneyDefinition('service_booking','Service booking',['service_booking_v1'],['hub','command']));
        $this->register(new JourneyDefinition('field_job_completion','Field job completion',['complete_job_v1'],['go','command']));
    }
    public function register(JourneyDefinition$j):void{$this->journeys[$j->id]=$j;}
    public function has(string$id):bool{return isset($this->journeys[$id]);}
    public function get(string$id):JourneyDefinition{if(!$this->has($id))throw new \RuntimeException("Journey '{$id}' is not registered.");return$this->journeys[$id];}
    /** @return array<string,JourneyDefinition> */ public function all():array{return$this->journeys;}
    /** @return list<JourneyDefinition> */ public function forSurface(string$surface):array{return array_values(array_filter($this->journeys,static fn(JourneyDefinition$j)=>in_array($surface,$j->surfaces,true)));}
}
