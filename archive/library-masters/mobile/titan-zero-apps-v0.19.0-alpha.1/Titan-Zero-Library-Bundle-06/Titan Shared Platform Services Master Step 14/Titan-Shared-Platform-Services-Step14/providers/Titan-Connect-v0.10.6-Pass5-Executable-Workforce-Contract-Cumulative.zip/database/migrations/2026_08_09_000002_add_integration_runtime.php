<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_connect_provider_credentials')) {
            Schema::create('ext_titan_connect_provider_credentials', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('provider', 40)->index();
                $table->string('reference', 191);
                $table->longText('encrypted_payload');
                $table->unsignedInteger('key_version')->default(1);
                $table->unsignedBigInteger('created_by')->nullable()->index();
                $table->unsignedBigInteger('updated_by')->nullable()->index();
                $table->timestamps();
                $table->unique(['company_id', 'provider', 'reference'], 'tc_provider_credential_unique');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_connect_provider_credentials');
    }
};
