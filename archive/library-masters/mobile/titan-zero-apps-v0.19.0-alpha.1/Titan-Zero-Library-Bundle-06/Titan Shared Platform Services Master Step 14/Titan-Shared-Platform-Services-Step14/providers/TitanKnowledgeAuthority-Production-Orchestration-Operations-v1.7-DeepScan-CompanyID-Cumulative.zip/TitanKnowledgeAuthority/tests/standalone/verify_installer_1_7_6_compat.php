<?php
declare(strict_types=1);
$root=realpath(__DIR__.'/../..');
$m=json_decode((string)file_get_contents($root.'/docs/reference/installer-1.7.6-extension.json'),true);
$errors=[];$c=static function(bool $ok,string $msg)use(&$errors){if(!$ok)$errors[]=$msg;};
$c(is_array($m),'legacy template invalid');
foreach(['name','type','version','description','support_telegram'] as $k)$c(array_key_exists($k,$m),"missing $k");
$c(count($m)===5,'legacy template must be exact five-field shape');
$c(($m['name']??null)==='Titan Knowledge Authority','name mismatch');
$c(($m['type']??null)==='extension','type mismatch');
if($errors){fwrite(STDERR,"Installer 1.7.6 compatibility verification: FAIL\n- ".implode("\n- ",$errors)."\n");exit(1);}
echo "Installer 1.7.6 compatibility template verification: PASS\n";
