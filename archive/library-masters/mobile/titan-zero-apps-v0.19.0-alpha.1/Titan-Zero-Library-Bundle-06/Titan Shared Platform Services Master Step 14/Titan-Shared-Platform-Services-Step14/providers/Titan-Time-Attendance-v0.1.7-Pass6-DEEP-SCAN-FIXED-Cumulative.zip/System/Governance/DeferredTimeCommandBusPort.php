<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Governance;

final class DeferredTimeCommandBusPort implements TimeCommandBusPort
{
    public function available(): bool { return false; }

    public function dispatch(TimeCommandRequest $request): array
    {
        return [
            'status' => 'blocked_dependency',
            'executed' => false,
            'capability' => $request->capability,
            'command_id' => $request->commandId,
            'tenant_company_id' => $request->tenantCompanyId,
            'trace_id' => $request->traceId,
            'correlation_id' => $request->correlationId,
            'reason' => 'Titan Command Bus is unavailable.',
        ];
    }
}
