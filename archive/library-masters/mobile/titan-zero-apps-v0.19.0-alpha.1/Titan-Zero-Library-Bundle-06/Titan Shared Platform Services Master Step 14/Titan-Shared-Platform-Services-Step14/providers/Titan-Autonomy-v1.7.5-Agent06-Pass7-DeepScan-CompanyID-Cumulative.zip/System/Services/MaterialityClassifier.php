<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

final class MaterialityClassifier
{
    public function isMaterial(array $changedFields, array $capabilityMaterialFields): bool
    {
        return array_intersect($changedFields, $capabilityMaterialFields) !== [];
    }
}
