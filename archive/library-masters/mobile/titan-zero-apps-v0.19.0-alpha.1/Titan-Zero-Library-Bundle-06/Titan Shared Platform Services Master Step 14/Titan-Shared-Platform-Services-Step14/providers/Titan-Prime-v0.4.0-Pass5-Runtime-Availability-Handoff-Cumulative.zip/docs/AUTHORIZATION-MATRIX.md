# Authorization Matrix

| Surface | Authentication | Scope | Mutation authority |
|---|---|---|---|
| User Prime overview | authenticated user | current tenant | none in v0.2.1 |
| Admin Prime overview | authenticated platform admin | platform administration | none in v0.2.1 |
| Certification command | console operator | host | diagnostic reads only |

Future mission mutations must add explicit tenant-object authorization before activation.
