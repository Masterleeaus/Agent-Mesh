
## Upgrade to 1.5.0

Run migrations to create `titan_vision_changes`. Existing evidence, annotations, comparisons and verified baseline lineage are preserved. Change detection activates only when a current evidence set has an explicitly verified prior baseline with matching capture slots.

# Upgrade

v1.2.0 adopts Blueprint v4.2.0 Manifest v2.2 and Installer 1.7.8 manifest. Existing v1.0/v1.1 evidence tables are preserved. Run migrations before cache clear.

## Upgrade to 1.4.0

Run migrations to add continuity metadata and `titan_vision_evidence_lineage`. Existing evidence remains unverified by default and is never silently promoted to a trusted baseline.
