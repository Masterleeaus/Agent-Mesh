<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Validation\ValidationException;

final class LeadQualificationService
{
    public function __construct(private ConnectionInterface $db, private CrmAuditRecorder $audit) {}

    public function score(array $lead): int
    {
        $score = 0;
        if (! empty($lead['email'])) $score += 20;
        if (! empty($lead['phone'])) $score += 20;
        if (! empty($lead['company_name'])) $score += 15;
        if (! empty($lead['notes'])) $score += 10;
        if (! empty($lead['source'])) $score += 10;
        if ((int) ($lead['priority'] ?? 0) > 0) $score += min(15, (int) $lead['priority'] * 5);
        if (! empty($lead['follow_up_at']) || ! empty($lead['next_follow_up_at'])) $score += 10;
        return min(100, $score);
    }

    public function qualify(int $userId, string $publicId, int $actorUserId, array $data): array
    {
        return $this->db->transaction(function () use ($userId, $publicId, $actorUserId, $data): array {
            $row = $this->db->table(config('crm.tables.leads'))->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id', $publicId)->whereNull('deleted_at')->lockForUpdate()->first();
            if (! $row) throw ValidationException::withMessages(['lead' => ['Lead not found.']]);
            $before = (array) $row;
            $candidate = array_merge($before, $data);
            $score = array_key_exists('lead_score', $data) ? max(0, min(100, (int) $data['lead_score'])) : $this->score($candidate);
            $status = (string) ($data['qualification_status'] ?? ($score >= 70 ? 'qualified' : ($score >= 40 ? 'nurture' : 'unqualified')));
            $update = [
                'lead_score' => $score,
                'qualification_status' => $status,
                'next_follow_up_at' => $data['next_follow_up_at'] ?? $row->next_follow_up_at,
                'last_contacted_at' => $data['last_contacted_at'] ?? $row->last_contacted_at,
                'updated_at' => now(),
            ];
            $this->db->table(config('crm.tables.leads'))->where('id', $row->id)->update($update);
            $after = (array) $this->db->table(config('crm.tables.leads'))->where('id', $row->id)->first();
            $this->audit->record($userId, $actorUserId, 'lead.qualified', 'lead', $publicId, $before, $after);
            return $after;
        });
    }
}
