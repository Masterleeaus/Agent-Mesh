<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalManagerContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use InvalidArgumentException;

final class SignalManager implements SignalManagerContract
{
    public function __construct(
        private readonly SignalEmitterContract $emitter,
        private readonly SignalOperationalHealthService $operationalHealth,
    ) {}

    public function health(SignalContext $context): array
    {
        if (! $context->hasPermission('signal.health.read')) {
            throw new InvalidArgumentException('Global Signal health requires signal.health.read permission.');
        }
        $snapshot = $this->operationalHealth->snapshot();
        $current = (array) ($snapshot['current'] ?? []);
        $backpressure = [
            'backpressured' => (bool) ($current['backpressured'] ?? false),
            'pending' => (int) ($current['pending'] ?? 0),
            'retry_wait' => (int) ($current['retry_wait'] ?? 0),
            'processing' => (int) ($current['processing'] ?? 0),
            'stale_processing' => (int) ($current['stale_processing'] ?? 0),
            'recent_dead_letter' => (int) ($current['recent_dead_letter'] ?? 0),
            'unresolved_dead_letter' => (int) ($current['unresolved_dead_letter'] ?? 0),
        ];

        return [
            'engine' => 'titan-signal-engine',
            'status' => (string) ($snapshot['status'] ?? 'healthy'),
            'version' => '0.20.0-rc.8.1',
            'envelope_version' => '1.0',
            'checksum_algorithm' => 'sha256',
            'capabilities' => ['signal.emit', 'signal.query', 'signal.history.query', 'signal.correlate', 'signal.subscribe', 'signal.deliver', 'signal.delivery.redrive', 'signal.pulse', 'signal.anomaly.detect', 'signal.anomaly.manage', 'signal.lifecycle', 'signal.archive', 'signal.redact', 'signal.console', 'signal.health'],
            'delivery' => $backpressure,
            'pulse' => (array) ($current['pulse_projection'] ?? ['status' => 'idle']),
            'anomaly' => ['critical_open' => (int) ($current['critical_open'] ?? 0)],
            'trace_evaluation' => (array) ($current['trace_evaluation'] ?? []),
            'lifecycle' => (array) ($current['lifecycle'] ?? []),
            'backpressure' => $backpressure,
            'historical_incidents' => (array) ($snapshot['historical_incidents'] ?? []),
            'captured_at' => $snapshot['captured_at'] ?? null,
        ];
    }

    public function emit(array $signal, SignalContext $context): array
    {
        return $this->emitter->emit($signal, $context)->toArray();
    }
}
