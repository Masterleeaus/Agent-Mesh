<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Jobs;

use App\Extensions\TitanRewind\System\Models\RewindReplayRun;
use App\Extensions\TitanRewind\System\Observability\RewindTraceContext;
use App\Extensions\TitanRewind\System\Services\RewindDeadLetterService;
use App\Extensions\TitanRewind\System\Services\RewindReplayService;
use App\Extensions\TitanRewind\System\Services\RewindSignalOutboxService;
use App\Extensions\TitanRewind\System\Services\RewindTelemetryService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Throwable;

final class RunReplaySimulationJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 4;
    public int $timeout = 120;

    public function __construct(public int $replayRunId, public int $tenantCompanyId) {}

    public function backoff(): array { return [5, 30, 120]; }

    public function handle(RewindReplayService $replay): void
    {
        $run = RewindReplayRun::query()->where('tenant_company_id',$this->tenantCompanyId)->find($this->replayRunId);
        if ($run !== null) $replay->executeRun($run);
    }

    public function failed(Throwable $e): void
    {
        $run = RewindReplayRun::query()->where('tenant_company_id',$this->tenantCompanyId)->whereKey($this->replayRunId)->first();
        if ($run === null) return;
        $run->forceFill(['status'=>'failed','error_text'=>substr($e::class . ': ' . $e->getMessage(),0,2000),'finished_at'=>now()])->save();
        $attempts=(int)($this->attempts() ?: $this->tries);
        app(RewindDeadLetterService::class)->record((string)config('titan-rewind.queues.replay','titan-rewind-replay'),self::class,$this->tenantCompanyId,(string)$run->operation_id,['replay_run_id'=>$run->id,'run_uuid'=>$run->run_uuid,'trace_id'=>$run->trace_id,'mode'=>$run->mode],$e,$attempts);
        $ctx=RewindTraceContext::fromArray(['tenant_company_id'=>$run->tenant_company_id,'trace_id'=>$run->trace_id,'correlation_id'=>$run->correlation_id ?: $run->trace_id,'causation_id'=>null]);
        app(RewindTelemetryService::class)->log('rewind.replay.dead_lettered','CRITICAL',$ctx,['run_uuid'=>$run->run_uuid,'mode'=>$run->mode,'exception'=>$e::class]);
        app(RewindSignalOutboxService::class)->emit('rewind.replay.failed.v1',$ctx,['run_uuid'=>$run->run_uuid,'mode'=>$run->mode,'error_class'=>$e::class],'ERROR');
    }
}
