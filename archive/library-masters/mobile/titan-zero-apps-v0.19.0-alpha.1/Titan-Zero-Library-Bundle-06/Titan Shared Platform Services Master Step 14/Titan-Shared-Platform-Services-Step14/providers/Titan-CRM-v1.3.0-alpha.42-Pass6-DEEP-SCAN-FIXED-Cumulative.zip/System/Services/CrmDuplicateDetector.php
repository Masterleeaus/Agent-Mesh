<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use App\Extensions\Crm\System\Support\CrmNormalizer;
use Illuminate\Database\ConnectionInterface;

final class CrmDuplicateDetector
{
    public function __construct(private ConnectionInterface $db) {}

    public function companyCandidates(int $userId, ?string $email, ?string $phone): array
    {
        return $this->candidates(config('crm.tables.companies'), $userId, $email, $phone, 'name');
    }


    public function contactCandidates(int $userId, ?string $email, ?string $phone): array
    {
        return $this->contactCandidateRows($userId, $email, $phone);
    }

    public function leadCandidates(int $userId, ?string $email, ?string $phone): array
    {
        return $this->candidates(config('crm.tables.leads'), $userId, $email, $phone, 'name');
    }


    private function contactCandidateRows(int $userId, ?string $email, ?string $phone): array
    {
        $email = CrmNormalizer::email($email); $phone = CrmNormalizer::phone($phone); if ($email === null && $phone === null) return [];
        return $this->db->table(config('crm.tables.contacts'))->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at')->where(function($q) use($email,$phone){ if($email!==null)$q->orWhere('normalized_email',$email); if($phone!==null)$q->orWhere('normalized_phone',$phone); })->limit(10)->get(['public_id','first_name','last_name','email','phone'])->map(fn($r)=>['public_id'=>$r->public_id,'name'=>trim($r->first_name.' '.($r->last_name??'')),'email'=>$r->email,'phone'=>$r->phone])->all();
    }

    private function candidates(string $table, int $userId, ?string $email, ?string $phone, string $nameColumn): array
    {
        $email = CrmNormalizer::email($email);
        $phone = CrmNormalizer::phone($phone);
        if ($email === null && $phone === null) {
            return [];
        }

        return $this->db->table($table)
            ->where('company_id', CrmCompanyScope::companyId($userId))
            ->whereNull('deleted_at')
            ->where(function ($query) use ($email, $phone): void {
                if ($email !== null) {
                    $query->orWhere('normalized_email', $email);
                }
                if ($phone !== null) {
                    $query->orWhere('normalized_phone', $phone);
                }
            })
            ->limit(10)
            ->get(['public_id', $nameColumn . ' as name', 'email', 'phone'])
            ->map(static fn (object $row): array => (array) $row)
            ->all();
    }
}
