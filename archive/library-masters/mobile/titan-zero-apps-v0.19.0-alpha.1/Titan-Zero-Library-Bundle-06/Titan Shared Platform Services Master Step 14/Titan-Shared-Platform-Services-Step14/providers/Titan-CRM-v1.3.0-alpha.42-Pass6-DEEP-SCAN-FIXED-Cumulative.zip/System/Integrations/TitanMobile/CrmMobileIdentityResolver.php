<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\TitanMobile;

use App\Extensions\Crm\System\Integrations\Chatbot\CrmChatbotSessionGrantService;
use App\Extensions\Crm\System\Support\CrmNormalizer;
use App\Extensions\Crm\System\Services\CrmIdentityAuthorityService;
use App\Extensions\Crm\System\Tenancy\CrmCompanyContextResolver;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use RuntimeException;

/** Resolve a verified Titan Hub identity to exactly one CRM contact in the bound company. */
final class CrmMobileIdentityResolver
{
    public function __construct(
        private ConnectionInterface $db,
        private CrmChatbotSessionGrantService $sessionGrants,
        private CrmCompanyContextResolver $companyContexts,
        private CrmIdentityAuthorityService $identityAuthority,
    ) {}

    public function resolveCustomer(array $context): ?array
    {
        // company_id must already be bound by the trusted Titan Hub adapter.
        $companyId = CrmCompanyScope::companyId();
        $external = (string) ($context['identity_id'] ?? $context['customer_id'] ?? $context['chatbot_customer_id'] ?? '');
        $verified = ($context['verified'] ?? false) === true;

        if ($external !== '') {
            $saved = $this->db->table('crm_mobile_identity_links')
                ->where('company_id', $companyId)->where('surface', 'customer')
                ->where('external_identity_id', $external)->first();
            if ($saved && $saved->crm_contact_public_id) {
                $contact = $this->contactByPublicId($companyId, (string) $saved->crm_contact_public_id);
                if ($contact) {
                    if ($verified) $this->issueVerifiedGrant($companyId, $context, $contact);
                    return $this->snapshot($companyId, $external, $contact, (array)$saved, $verified);
                }
            }
        }

        $email = CrmNormalizer::email($context['email'] ?? ($context['identity']['email'] ?? null));
        $phone = CrmNormalizer::phone($context['phone'] ?? ($context['identity']['phone'] ?? null));
        $contact = $this->matchContact($companyId, $email, $phone);
        if (! $contact) return null;

        $this->persist($companyId, 'customer', $external, $contact, $verified, [
            'identity_id'=>$context['identity_id'] ?? null,
            'customer_id'=>$context['customer_id'] ?? null,
            'chatbot_customer_id'=>$context['chatbot_customer_id'] ?? null,
            'portal_id'=>$context['portal_id'] ?? null,
        ]);
        if ($verified) $this->issueVerifiedGrant($companyId, $context, $contact);
        return $this->snapshot($companyId, $external, $contact, null, $verified);
    }

    public function resolveFromRecord(int $legacyOwnerUserId, array $record, string $surface = 'field'): ?array
    {
        $companyId = CrmCompanyScope::companyId($legacyOwnerUserId);
        $contact = null;
        foreach (['crm_contact_public_id','contact_public_id','customer_public_id'] as $key) {
            if (! empty($record[$key])) {
                $contact = $this->contactByPublicId($companyId, (string)$record[$key]);
                if ($contact) break;
            }
        }
        if (! $contact) {
            $email = CrmNormalizer::email($record['customer_email'] ?? ($record['customer']['email'] ?? null));
            $phone = CrmNormalizer::phone($record['customer_phone'] ?? ($record['customer']['phone'] ?? null));
            $contact = $this->matchContact($companyId, $email, $phone);
        }
        if (! $contact) return null;
        return $this->snapshot($companyId, (string)($record['id'] ?? $record['public_id'] ?? ''), $contact, null, false);
    }

    private function issueVerifiedGrant(int $companyId, array $context, object $contact): void
    {
        $chatbotCustomerId = (int) ($context['chatbot_customer_id'] ?? 0);
        $sessionId = (string) ($context['chatbot_session_id'] ?? $context['session_id'] ?? '');
        if ($chatbotCustomerId <= 0 || $sessionId === '') return;

        $chatbotId = 0;
        $chatbotUuid = (string) ($context['chatbot_uuid'] ?? '');
        if ($chatbotUuid !== '' && class_exists(\App\Extensions\Chatbot\System\Models\Chatbot::class)) {
            // Chatbot 6.5 owns user_id as its account owner. It does not own CRM company_id.
            $chatbot = \App\Extensions\Chatbot\System\Models\Chatbot::query()->where('uuid', $chatbotUuid)->first();
            if ($chatbot) {
                $ownerUserId = (int) ($chatbot->user_id ?? 0);
                if ($ownerUserId <= 0 || $this->companyContexts->companyIdForActorId($ownerUserId) !== $companyId) {
                    throw new RuntimeException('Chatbot company context does not match the verified Titan Hub company.');
                }
                $chatbotId = (int) $chatbot->id;
            }
        }
        if ($chatbotId <= 0 && Schema::hasTable('crm_chatbot_identities')) {
            $chatbotId = (int) ($this->db->table('crm_chatbot_identities')->where('company_id', $companyId)
                ->where('chatbot_customer_id', $chatbotCustomerId)->value('chatbot_id') ?? 0);
        }
        if ($chatbotId <= 0) return;

        $legacyOwnerUserId = (int) ($contact->user_id ?? 0);
        if ($legacyOwnerUserId <= 0) throw new RuntimeException('CRM contact has no legacy owner user required for transitional grant persistence.');
        $this->sessionGrants->issueVerifiedGrant($legacyOwnerUserId, $chatbotId, $chatbotCustomerId, (string)$contact->public_id, $sessionId);
        $this->markChatbotVerified($companyId, $legacyOwnerUserId, $chatbotCustomerId, (string)$contact->public_id);
    }

    private function markChatbotVerified(int $companyId, int $legacyOwnerUserId, int $chatbotCustomerId, string $contactPublicId): void
    {
        if ($chatbotCustomerId <= 0 || ! Schema::hasTable('crm_chatbot_identities')) return;
        $this->db->table('crm_chatbot_identities')->where('company_id', $companyId)
            ->where('chatbot_customer_id', $chatbotCustomerId)
            ->where(function ($q) use ($contactPublicId): void { $q->whereNull('crm_contact_public_id')->orWhere('crm_contact_public_id', $contactPublicId); })
            ->update(['crm_contact_public_id'=>$contactPublicId,'identity_state'=>'verified','identity_confidence'=>100,'verified_at'=>now(),'last_seen_at'=>now(),'updated_at'=>now()]);
    }

    private function matchContact(int $companyId, ?string $email, ?string $phone): ?object
    {
        if (! $email && ! $phone) return null;
        $q = $this->db->table(config('crm.tables.contacts'))->where('company_id', $companyId)->whereNull('deleted_at');
        $q->where(function ($w) use ($email,$phone): void {
            if ($email) $w->orWhere('normalized_email', $email);
            if ($phone) $w->orWhere('normalized_phone', $phone);
        });
        // Ambiguous identity must fail closed instead of selecting a random customer.
        $rows = $q->limit(2)->get();
        return $rows->count() === 1 ? $rows->first() : null;
    }

    private function contactByPublicId(int $companyId, string $id): ?object
    {
        return $this->db->table(config('crm.tables.contacts'))->where('company_id', $companyId)
            ->where('public_id',$id)->whereNull('deleted_at')->first();
    }

    private function company(int $companyId, ?int $id): ?object
    {
        return $id ? $this->db->table(config('crm.tables.companies'))->where('company_id',$companyId)
            ->where('id',$id)->whereNull('deleted_at')->first() : null;
    }

    private function snapshot(int $companyId, string $external, object $contact, ?array $saved, bool $verified): array
    {
        $company = $this->company($companyId, isset($contact->customer_company_id) ? (int)$contact->customer_company_id : null);
        return [
            'company_id'=>$companyId,
            'legacy_owner_user_id'=>(int)($contact->user_id ?? 0),
            'external_identity_id'=>$external,
            'crm_contact_public_id'=>(string)$contact->public_id,
            'crm_company_public_id'=>$company?->public_id,
            'identity_state'=>$verified ? 'verified' : 'matched',
            'verified'=>$verified,
            'contact'=>[
                'public_id'=>(string)$contact->public_id,
                'name'=>trim((string)$contact->first_name.' '.(string)($contact->last_name ?? '')),
                'email'=>$contact->email ?? null,'phone'=>$contact->phone ?? null,'role'=>$contact->role ?? null,
            ],
            'company'=>$company ? ['public_id'=>$company->public_id,'name'=>$company->name] : null,
        ];
    }

    private function persist(int $companyId, string $surface, string $external, object $contact, bool $verified, array $meta): void
    {
        if ($external === '') return;
        $company = $this->company($companyId, isset($contact->customer_company_id) ? (int)$contact->customer_company_id : null);
        $row = $this->db->table('crm_mobile_identity_links')->where('company_id',$companyId)
            ->where('surface',$surface)->where('external_identity_id',$external)->first();
        $payload = [
            'crm_contact_public_id'=>$contact->public_id,'crm_company_public_id'=>$company?->public_id,
            'identity_state'=>$verified?'verified':'matched','verified_at'=>$verified?now():($row?->verified_at),
            'last_seen_at'=>now(),'metadata'=>json_encode($meta),'updated_at'=>now(),
        ];
        if ($row) $this->db->table('crm_mobile_identity_links')->where('company_id',$companyId)->where('id',$row->id)->update($payload);
        else {
            $legacyOwnerUserId=(int)($contact->user_id??0);
            if($legacyOwnerUserId<=0) throw new RuntimeException('CRM contact has no transitional owner user for identity-link persistence.');
            $this->db->table('crm_mobile_identity_links')->insert([
                'public_id'=>(string)Str::ulid(),'company_id'=>$companyId,'user_id'=>$legacyOwnerUserId,
                'surface'=>$surface,'external_identity_id'=>$external,'created_at'=>now(),
            ] + $payload);
        }
        $legacyOwnerUserId=(int)($contact->user_id??0);
        if($legacyOwnerUserId>0){$root=$this->identityAuthority->ensureRootForContact($legacyOwnerUserId,(string)$contact->public_id,isset($contact->customer_company_id)&&$contact->customer_company_id?(int)$contact->customer_company_id:null);$this->identityAuthority->linkExternalIdentity($legacyOwnerUserId,$root,'titan_mobile:'.strtolower($surface),$external,'contact',(string)$contact->public_id,['verified'=>$verified]+$meta);}
    }
}
