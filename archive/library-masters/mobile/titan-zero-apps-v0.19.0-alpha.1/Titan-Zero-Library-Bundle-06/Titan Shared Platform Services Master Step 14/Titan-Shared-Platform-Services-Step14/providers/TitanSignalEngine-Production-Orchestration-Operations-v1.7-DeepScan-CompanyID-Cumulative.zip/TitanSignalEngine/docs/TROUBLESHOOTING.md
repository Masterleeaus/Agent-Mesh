# Troubleshooting

## Engine unavailable
Check `app.key`, database connectivity, extension enable state and `runtime_state`.

## Signals rejected
Check trusted emitter registration/attestation, event-type registration, tenant context, payload limits and required permissions.

## Delivery backlog
Run `titan:signal-deliveries:recover`, inspect subscriber handler availability and dead-letter state.

## Pulse stale
Run `titan:signal-pulse:project` and check `titan_signal_pulse_projected_events`.

## Anomalies missing
Confirm Pulse projections are current and trace evaluations exist for sequence-dependent rules.

## Archive/prune blocked
Check legal holds, archive disk access and archive checksum verification. A failed archive must never be bypassed to prune hot events.

## Dead letter remains after repair

First repair/revalidate the subscriber. Then use the admin Dead-letter Recovery surface or `titan:signal-deliveries:redrive --reason=...`. Do not manually update the delivery row: governed redrive appends audit evidence and resets only the retry cycle.
