<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Models\KnowledgeSourceVersion;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeAccessContext;

interface KnowledgeSourceVersionRepositoryContract
{
    public function findVisibleById(KnowledgeAccessContext $context, int $versionId): ?KnowledgeSourceVersion;
}
