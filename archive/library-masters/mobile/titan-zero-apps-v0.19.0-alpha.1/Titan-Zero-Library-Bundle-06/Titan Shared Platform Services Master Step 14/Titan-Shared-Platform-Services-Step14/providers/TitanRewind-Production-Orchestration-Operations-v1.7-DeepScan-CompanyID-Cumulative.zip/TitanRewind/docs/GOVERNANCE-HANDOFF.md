# Titan Rewind — Governance Handoff Contract

## Purpose

Titan Rewind may discover a failure, reconstruct evidence and propose a compensating action. It must not authorize that action itself. Titan Governance remains the approval authority, and Titan Command Bus remains the authoritative execution boundary.

## Host binding

Bind an implementation of:

`App\\Extensions\\TitanRewind\\System\\Contracts\\RewindGovernanceGatewayContract`

before Titan Rewind resolves the contract. If no implementation is bound, Titan Rewind installs `FailClosedRewindGovernanceGateway` and approval submission remains unavailable.

Required methods:

```php
public function key(): string;
public function available(): bool;
public function requestApproval(array $request): array;
public function refresh(string $externalRequestId, int $tenantCompanyId): array;
public function verifyReceipt(array $receipt): bool;
```

## Approval request

Rewind submits a sanitized request containing:

- `request_type=titan-rewind.recovery-approval`
- `tenant_company_id`
- `trace_id`
- optional `case_id`
- `recovery_plan_uuid`
- `plan_hash`
- `evidence_package_uuid`
- `evidence_content_hash`
- `evidence_manifest`
- `risk_level`
- `proposed_capability`
- sanitized `command_input`
- requesting actor ID when known
- `authoritative_mutation_requested_from_rewind=false`
- `execution_owner=titan-command-bus`

Before this request is sent, Rewind regenerates an audit evidence package and requires all three conditions:

1. evidence manifest integrity state is `passed`;
2. evidence package status is `ready`;
3. the stored evidence payload re-hashes to the stored SHA-256 content hash.

This binds the approval decision to a specific recovery plan and a specific verified evidence state.

## Gateway response

`requestApproval()` and `refresh()` must return an array with:

- non-empty `request_id`
- `status` in `pending`, `approved`, `rejected`, `cancelled`, `expired`
- optional `authority`
- optional structured `decision`
- optional `requested_at` / `decided_at`
- provider-specific receipt/proof fields needed by `verifyReceipt()`

Terminal states (`approved`, `rejected`, `cancelled`, `expired`) are rejected by Rewind unless `verifyReceipt()` returns `true` for that exact response.

## Persistence

Rewind stores only its copy of the external request/decision receipt in `titan_rewind_governance_receipts`. The record contains:

- stable Rewind receipt UUID
- tenant + recovery-plan boundary
- external Governance request ID
- authority/status
- canonical request payload hash
- exact evidence package UUID used for the handoff
- sanitized external decision/receipt
- request/decision timestamps

This copy is forensic evidence, not the authoritative Governance ledger.

## Execution boundary

An approved Rewind recovery plan is still only an approved proposal. Rewind does not expose an `approve()`, `apply()`, `execute()` or direct Eloquent business-mutation service.

Expected flow:

`Rewind reconstruction -> verified evidence -> recovery proposal -> Titan Governance -> Titan Command Bus -> authoritative domain -> Signal/outcome -> Rewind verification`
