# Titan Rewind v1.0.4 — Menu Navigation Compatibility

## Problem

Titan Rewind v1.0.3 installed successfully on Titan Extension Manager 1.7.8, including all scoped migrations, but no navigation link appeared.

## Cause

The extension registered only through the newer Titan contribution registries. The live MagicAI/Titan host still materializes navigation from the shared `menus` table and caches the merged result through `App\Services\Common\MenuService`.

## v1.0.4 behaviour

1. Register user navigation through `MenuContributionRegistry` when available.
2. Register Super Admin navigation through `ContributionRegistry` when available.
3. Independently inspect the `menus` table.
4. Create the missing `titan_rewind` user row or repair stale route/label/icon/type metadata.
5. Preserve an existing administrator-controlled `order` and `is_active` value.
6. Create `titan_rewind_admin` only on hosts whose menu table has an `is_admin` column.
7. Regenerate MagicAI menu caches only when a row changed.
8. Fail open if the legacy table or MenuService is unavailable; navigation compatibility can never prevent Rewind boot.

## Routes

- User: `dashboard.user.titan.rewind.index`
- Super Admin: `dashboard.admin.titan.rewind.index`

All routes remain protected by existing Rewind permission middleware.

## v1.0.5 authorization compatibility

The menu self-heal remains unchanged. Route authorization now recognizes MagicAI/Titan Super Admin authority and explicit host permission APIs. Delegated administrators receive only the narrow read/diagnostic fallback documented in `HOST-AUTHORIZATION-BRIDGE-v1.0.5.md`.
