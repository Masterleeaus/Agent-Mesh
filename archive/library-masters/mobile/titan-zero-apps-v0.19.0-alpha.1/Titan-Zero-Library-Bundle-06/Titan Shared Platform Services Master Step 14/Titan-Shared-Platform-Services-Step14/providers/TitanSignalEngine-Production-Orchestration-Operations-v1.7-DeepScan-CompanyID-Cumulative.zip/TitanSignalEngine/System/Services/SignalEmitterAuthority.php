<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterAuthorityContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalEmitterIdentity;
use InvalidArgumentException;
use JsonException;

final class SignalEmitterAuthority implements SignalEmitterAuthorityContract
{
    /** @param array<string,array<string,mixed>> $definitions */
    public function __construct(
        private readonly string $secret,
        private readonly array $definitions,
    ) {
        if (trim($this->secret) === '') {
            throw new InvalidArgumentException('Signal emitter authority requires a non-empty attestation secret.');
        }
    }

    public function issue(string $serviceId): SignalEmitterIdentity
    {
        $definition = $this->definition($serviceId);
        $payload = [
            'service_id' => $serviceId,
            'source' => trim((string) ($definition['source'] ?? '')),
            'source_component' => self::nullableString($definition['source_component'] ?? null),
            'permissions' => self::stringList($definition['permissions'] ?? ['signal.emit']),
            'event_type_patterns' => self::stringList($definition['event_type_patterns'] ?? []),
        ];
        if ($payload['source'] === '' || $payload['event_type_patterns'] === []) {
            throw new InvalidArgumentException("Trusted Signal emitter {$serviceId} has an invalid definition.");
        }

        return new SignalEmitterIdentity(
            $payload['service_id'],
            $payload['source'],
            $payload['source_component'],
            $payload['permissions'],
            $payload['event_type_patterns'],
            $this->sign($payload),
        );
    }

    public function assertTrusted(SignalEmitterIdentity $identity): void
    {
        $expected = $this->issue($identity->serviceId);
        if ($identity->attestationPayload() !== $expected->attestationPayload() || ! hash_equals($expected->attestation, $identity->attestation)) {
            throw new InvalidArgumentException('Signal emitter identity is not trusted by the host emitter authority.');
        }
    }

    /** @return array<string,mixed> */
    private function definition(string $serviceId): array
    {
        $serviceId = trim($serviceId);
        if ($serviceId === '' || ! isset($this->definitions[$serviceId]) || ! is_array($this->definitions[$serviceId])) {
            throw new InvalidArgumentException("Signal emitter service {$serviceId} is not registered as trusted.");
        }
        return $this->definitions[$serviceId];
    }

    /** @param array<string,mixed> $payload */
    private function sign(array $payload): string
    {
        try {
            $json = json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        } catch (JsonException $exception) {
            throw new InvalidArgumentException('Signal emitter identity cannot be attested.', previous: $exception);
        }
        return hash_hmac('sha256', $json, $this->secret);
    }

    /** @return list<string> */
    private static function stringList(mixed $value): array
    {
        if (! is_array($value)) throw new InvalidArgumentException('Signal emitter permissions/patterns must be arrays.');
        return array_values(array_map(static fn (mixed $item): string => trim((string) $item), $value));
    }

    private static function nullableString(mixed $value): ?string
    {
        if ($value === null || $value === '') return null;
        return trim((string) $value);
    }
}
