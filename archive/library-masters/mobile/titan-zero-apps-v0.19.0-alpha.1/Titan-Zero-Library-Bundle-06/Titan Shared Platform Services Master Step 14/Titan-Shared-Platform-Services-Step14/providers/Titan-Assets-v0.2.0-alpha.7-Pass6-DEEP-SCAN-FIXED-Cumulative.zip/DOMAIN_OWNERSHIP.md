# Titan Assets Domain Ownership

Titan Assets is the single writer for individually tracked business assets: tools, equipment, fleet vehicles, custody/lending, allocations, maintenance, repairs, repair templates, downtime, warranties/profiles, mileage, location equipment checks, asset documents/images, lifecycle events, operational valuation and premises links.

Existing `crm_locker_tools`, `crm_locker_equipment`, `crm_locker_fleet_vehicles`, `crm_locker_maintenance_records` and `crm_locker_asset_events` tables remain stable persistence contracts while write authority transfers to Titan Assets. v0.2 adds/backfills `company_id` and retains legacy `tenant_company_id` compatibility during transition.

Titan Locker remains authoritative for inventory, consumables/materials, stock locations, stock movements, stock reservations, stock counts, stock transfers, suppliers, purchase orders, goods receipts and reorder logic.

CRM remains authoritative for CRM/customer/business data. Titan Assets may store a customer public-ID link for an asset but does not become the customer master. Full property/premises records remain outside this extension; Titan Assets owns only the asset-to-premises association.
