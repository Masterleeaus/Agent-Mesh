<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;

final class TrustedContextBoundaryTest extends TestCase
{
    public function test_catalog_reads_do_not_accept_caller_supplied_tenant_scope(): void
    {
        $root = dirname(__DIR__, 2);
        $contract = (string) file_get_contents($root . '/System/Contracts/KnowledgeCatalogReadContract.php');
        $service = (string) file_get_contents($root . '/System/Services/KnowledgeCatalogReadService.php');

        self::assertStringNotContainsString('tenantCompanyId', $contract);
        self::assertStringNotContainsString('tenant_company_id', $contract);
        self::assertStringNotContainsString('request(', $service);
        self::assertStringNotContainsString('->input(', $service);
        self::assertStringNotContainsString('->query(', $service);
    }
}
