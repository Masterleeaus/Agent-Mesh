<?php

declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Models;
use Illuminate\Database\Eloquent\Model;
final class RewindCircuitBreakerState extends Model
{
    protected $table='titan_rewind_circuit_breakers';
    protected $fillable=['breaker_key','state','failure_count','last_error','opened_at','next_probe_at','last_success_at'];
    protected $casts=['failure_count'=>'integer','opened_at'=>'datetime','next_probe_at'=>'datetime','last_success_at'=>'datetime'];
}
