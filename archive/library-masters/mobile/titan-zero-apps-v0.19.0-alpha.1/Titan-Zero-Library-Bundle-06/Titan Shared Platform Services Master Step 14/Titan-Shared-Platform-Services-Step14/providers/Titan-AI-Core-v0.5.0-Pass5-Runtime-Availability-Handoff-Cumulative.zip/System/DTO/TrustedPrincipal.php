<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\DTO;

final readonly class TrustedPrincipal
{
    /** @param array<int,string> $permissions */
    public function __construct(
        public string $actorId,
        public string $actorType,
        public string $tenantCompanyId,
        public array $permissions = [],
        public int $authorityLevel = 0,
        public string $authenticationSource = 'host-auth',
    ) {}

    public function toActorContext(): ActorContext
    {
        return new ActorContext(
            actorId: $this->actorId,
            actorType: $this->actorType,
            tenantCompanyId: $this->tenantCompanyId,
            permissions: $this->permissions,
            authorityLevel: $this->authorityLevel,
            trusted: true,
            authoritySource: $this->authenticationSource,
        );
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'actor_id' => $this->actorId,
            'actor_type' => $this->actorType,
            'tenant_company_id' => $this->tenantCompanyId,
            'permissions' => $this->permissions,
            'authority_level' => $this->authorityLevel,
            'authentication_source' => $this->authenticationSource,
        ];
    }
}
