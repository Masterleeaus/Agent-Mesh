<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Automation;
final class CrmAutomationActionCatalog
{
    public const ACTIONS = ['create_task','create_note','queue_notification','update_lead_status','dispatch_webhook'];
    public function all(): array { return self::ACTIONS; }
    public function assertValid(string $key): void { if (!in_array($key,self::ACTIONS,true)) throw new \InvalidArgumentException("Unsupported CRM automation action: {$key}"); }
}
