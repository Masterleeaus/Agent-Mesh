<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\DTO;

final readonly class CommandReceipt
{
    public int $companyId;

    public function __construct(
        public string $operationId,
        public string $idempotencyKey,
        public string $requestHash,
        public int $tenantCompanyId,
        public string $serviceId,
        public string $actorType,
        public int|string|null $actorId,
        public string $capability,
        public string $status,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $rootCausationId,
        public bool $freshGovernance,
        public ?string $governanceReference = null,
        public ?string $riskReference = null,
        public ?string $riskClass = null,
        public ?float $riskScore = null,
        public ?string $assuranceReference = null,
        public ?string $assuranceLevel = null,
        public array $assuranceEvidence = [],
        public ?string $autonomyReference = null,
        public ?string $autonomyLevel = null,
        public ?string $autonomyWorkflow = null,
        public array $autonomyEvidence = [],
        public ?string $approvalReference = null,
        public ?string $adapter = null,
        public ?string $domainReceiptReference = null,
        public ?bool $writeVerified = null,
        public ?string $originalReceiptReference = null,
        public int|string|null $expectedEntityVersion = null,
        public ?string $resultEntityType = null,
        public int|string|null $resultEntityId = null,
        public int|string|null $resultEntityVersion = null,
        public ?string $reasonCode = null,
        public bool $replayed = false,
        public array $metadata = [],
    ) {
        $this->companyId = $tenantCompanyId;
    }

    public function toArray(): array
    {
        return [
            'operation_id' => $this->operationId,
            'idempotency_key' => $this->idempotencyKey,
            'request_hash' => $this->requestHash,
            'company_id' => $this->companyId,
            // Compatibility alias for v1 receipt consumers; not authoritative.
            'tenant_company_id' => $this->companyId,
            'service_id' => $this->serviceId,
            'actor_type' => $this->actorType,
            'actor_id' => $this->actorId,
            'capability' => $this->capability,
            'status' => $this->status,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
            'fresh_governance' => $this->freshGovernance,
            'governance_reference' => $this->governanceReference,
            'risk_reference' => $this->riskReference,
            'risk_class' => $this->riskClass,
            'risk_score' => $this->riskScore,
            'assurance_reference' => $this->assuranceReference,
            'assurance_level' => $this->assuranceLevel,
            'assurance_evidence' => $this->assuranceEvidence,
            'autonomy_reference' => $this->autonomyReference,
            'autonomy_level' => $this->autonomyLevel,
            'autonomy_workflow' => $this->autonomyWorkflow,
            'autonomy_evidence' => $this->autonomyEvidence,
            'approval_reference' => $this->approvalReference,
            'adapter' => $this->adapter,
            'domain_receipt_reference' => $this->domainReceiptReference,
            'write_verified' => $this->writeVerified,
            'original_receipt_reference' => $this->originalReceiptReference,
            'expected_entity_version' => $this->expectedEntityVersion,
            'result_entity_type' => $this->resultEntityType,
            'result_entity_id' => $this->resultEntityId,
            'result_entity_version' => $this->resultEntityVersion,
            'reason_code' => $this->reasonCode,
            'replayed' => $this->replayed,
            'occurred_at' => gmdate('c'),
            'metadata' => $this->metadata,
        ];
    }
}
