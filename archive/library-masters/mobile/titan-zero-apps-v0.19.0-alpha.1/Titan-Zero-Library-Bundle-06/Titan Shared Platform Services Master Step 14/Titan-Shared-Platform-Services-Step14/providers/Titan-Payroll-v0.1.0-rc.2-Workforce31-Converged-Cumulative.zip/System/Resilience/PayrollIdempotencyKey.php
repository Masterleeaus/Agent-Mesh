<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Resilience;
final class PayrollIdempotencyKey{public static function forRun(int $tenantCompanyId,string $periodKey,string $operation,string $clientKey):string{if($tenantCompanyId<1||$periodKey===''||$operation===''||$clientKey==='')throw new \InvalidArgumentException('Complete idempotency identity is required.');return hash('sha256',implode('|',[$tenantCompanyId,$periodKey,$operation,$clientKey]));}}
