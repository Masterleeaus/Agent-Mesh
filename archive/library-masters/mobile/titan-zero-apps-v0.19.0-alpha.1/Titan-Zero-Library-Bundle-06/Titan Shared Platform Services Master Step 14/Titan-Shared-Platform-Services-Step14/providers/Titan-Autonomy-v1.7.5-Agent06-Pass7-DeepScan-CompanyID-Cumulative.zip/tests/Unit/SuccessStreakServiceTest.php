<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanAutonomy\System\Enums\UserResponseClass;
use App\Extensions\TitanAutonomy\System\Services\SuccessStreakService;
use PHPUnit\Framework\TestCase;

final class SuccessStreakServiceTest extends TestCase
{
    public function test_material_correction_resets_consecutive_streak(): void
    {
        $service = new SuccessStreakService();
        $first = $service->apply(0, UserResponseClass::ApprovedUnchanged);
        $corrected = $service->apply($first['streak'], UserResponseClass::ApprovedMaterialEdit);
        $third = $service->apply($corrected['streak'], UserResponseClass::ApprovedUnchanged);

        self::assertSame(1, $third['streak']);
        self::assertFalse($corrected['qualifying']);
    }
}
