# Titan CRM Core v1.3.0-alpha.35 — Performance & Scale Certification

## Scope

This pass hardens CRM Core for large-tenant workloads by removing query-count, row-materialisation and unbounded-working-set problems found in the alpha.34 codebase. The certification has two deliberately separate layers:

1. **Package synthetic certification** — dependency-free bounded-working-set tests that run in the release package and model logical tenant sizes of **10,000**, **100,000** and **1,000,000** rows.
2. **Installed host-runtime certification** — real Laravel/database timing and index inspection using `php artisan crm:performance:certify <tenant_company_id> --iterations=5 --json` after installation on the production-like MySQL host.

The current build environment does not provide the installed Laravel/MySQL runtime or a MySQL client/server. Therefore this report does **not** claim live MySQL latency at 10k/100k/1m scale. Host-runtime certification remains an explicit deployment gate.

## Proven alpha.34 bottlenecks and alpha.35 changes

### Projection rebuilds

Alpha.34 could perform a projection row write, full projection `COUNT(*)`, and state update for every rebuilt resource. Alpha.35 adds `CrmReadStorePort::upsertResources()`, chunked SQL upserts, one state update per batch, and bulk search indexing. Large full rebuilds refuse silent truncation and direct operators to the durable incremental path:

```bash
php artisan crm:projections:rebuild --projection=<name> --incremental --until-complete
```

### Projection search

The old SQL search path inspected only a recent bounded slice of projection records. Alpha.35 adds disposable `crm_read_projection_search_terms` with indexed term/resource lookup and `CrmProjectionSearchIndexer`. Search remains projection-only and non-authoritative.

After upgrade, rebuild the disposable search index with:

```bash
php artisan crm:projections:search-index <tenant_company_id>
```

### Pipeline board

The previous board path queried deals once per stage. Alpha.35 uses grouped SQL aggregates plus one bounded detail query and exposes truncation metadata when the configured detail ceiling is reached.

### Customer timeline

The previous timeline loaded all matching activities, notes and emails before sorting. Alpha.35 loads only a bounded, indexed newest window from each source before merging.

### Forecast, analytics and receivables

Forecast totals, monthly/source analytics and receivables ageing now use database aggregation rather than materialising complete qualifying datasets into PHP memory.

### Import staging

Import **staging** inserts are batched. The authoritative commit intentionally remains per-record through CRM repositories so identity normalization, Command Bus governance, invariant checks and rollback journaling are preserved. Alpha.35 does not trade correctness for bulk-write speed.

### Detail collections and portal files

Company detail collections and portal file listings are bounded by configuration and report truncation where relevant.

## Index hardening

Migration `2026_08_17_000044_add_crm_performance_scale.php` adds composite/index support for high-frequency customer/contact lists, pipeline/stage reads, timeline sources, invoice ageing, import commit lookup, Signal delivery, operation metrics, webhook retry, portal-file health and projection batch scanning.

The migration also creates the disposable projection token index. No table partitioning was introduced. Partitioning remains deliberately deferred until real host profiling demonstrates that normal indexing, bounded reads and projection architecture are insufficient.

## Package synthetic benchmark

Command:

```bash
php bin/benchmark-v130-alpha35-scale.php
```

The benchmark varies the **logical tenant size** while holding the intended in-process working sets to the production bounds. These timings are package/PHP algorithm measurements only, not database response times.

| Logical scale | Timeline source rows | Timeline ms | Projection batch | Projection ms | Search candidates | Search tokenize ms |
|---:|---:|---:|---:|---:|---:|---:|
| 10,000 | 750 | 0.140 | 500 | 0.244 | 1,000 | 0.833 |
| 100,000 | 750 | 0.112 | 500 | 0.429 | 1,000 | 1.049 |
| 1,000,000 | 750 | 0.144 | 500 | 0.321 | 1,000 | 1.134 |

Observed benchmark peak memory: **2,097,152 bytes (2 MiB)**.

The important result is not the sub-millisecond timing itself; it is that the measured working-set ceilings remain fixed as the modeled tenant size grows:

- `timeline_merge`: maximum 750 source rows, returns 100.
- `projection_batch`: maximum 500 rows.
- `search_tokenize`: maximum 1,000 candidate rows.

The harness emits `host_runtime_required: true` to prevent these synthetic results being mistaken for production database certification.

## Installed host-runtime certification

After installing alpha.35 on the target Laravel/MySQL environment, run:

```bash
php artisan crm:performance:certify <tenant_company_id> --iterations=5 --json
```

The read-only command inspects representative tenant row counts, scale band, expected MySQL index coverage, representative query timings and PHP peak memory. It returns **PASS**, **WARN** or **BLOCK** and performs no authoritative CRM mutations.

Recommended deployment evidence should retain the JSON output for representative small, large and largest production-like tenants. If index coverage or timings exceed configured budgets, optimize the measured query before considering more invasive architecture.

## Performance configuration

Alpha.35 introduces configurable ceilings/budgets for:

- timeline source windows
- pipeline board detail rows
- detail collection rows
- projection write batch size
- search candidate rows
- terms per projection resource
- import staging insert batch size
- query warning/block thresholds
- memory warning threshold
- large-tenant and million-scale classification thresholds

These bounds are defaults, not permission to bypass tenant isolation or governance.

## Certification conclusion

The package-level architecture now avoids the specific unbounded/N+1 paths identified in alpha.34 and provides a repeatable synthetic proof that key in-process working sets remain bounded at logical **10,000 / 100,000 / 1,000,000** scale. Real MySQL latency and index effectiveness require the separate **host-runtime** certification command on the installed environment before production scale is declared certified.
