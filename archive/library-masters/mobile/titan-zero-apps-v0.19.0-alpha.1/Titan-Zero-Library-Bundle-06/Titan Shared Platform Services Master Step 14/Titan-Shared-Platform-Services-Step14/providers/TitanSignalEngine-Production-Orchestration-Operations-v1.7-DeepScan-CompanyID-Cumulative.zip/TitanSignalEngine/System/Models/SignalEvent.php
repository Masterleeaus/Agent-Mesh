<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use App\Extensions\TitanSignalEngine\System\Exceptions\ImmutableSignalEventException;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;
use InvalidArgumentException;

final class SignalEvent extends Model
{
    protected $table = 'titan_signal_events';
    protected $guarded = [];

    protected $casts = [
        'payload' => 'array',
        'metadata' => 'array',
        'occurred_at' => 'immutable_datetime',
        'recorded_at' => 'immutable_datetime',
        'idempotency_expires_at' => 'immutable_datetime',
        'tenant_company_id' => 'integer',
        'schema_version' => 'integer',
    ];

    protected static function booted(): void
    {
        static::updating(static function (SignalEvent $event): never {
            self::logBlockedMutation($event, 'update');
            throw new ImmutableSignalEventException('Signal events are immutable and cannot be updated.');
        });

        static::deleting(static function (SignalEvent $event): never {
            self::logBlockedMutation($event, 'delete');
            throw new ImmutableSignalEventException('Signal events are immutable and cannot be deleted through the event model.');
        });
    }

    /** @param Builder<SignalEvent> $query */
    public function scopeInScope(Builder $query, string $scope, ?int $tenantCompanyId): Builder
    {
        if (! in_array($scope, ['tenant', 'system'], true)) {
            throw new InvalidArgumentException('Signal query scope must be tenant or system.');
        }

        $query->where('scope', $scope);

        if ($scope === 'tenant') {
            if ($tenantCompanyId === null || $tenantCompanyId < 1) {
                throw new InvalidArgumentException('tenant_company_id is required for tenant-scoped signal queries.');
            }
            $query->where('tenant_company_id', $tenantCompanyId);
        } else {
            $query->whereNull('tenant_company_id');
        }

        return $query;
    }

    private static function logBlockedMutation(SignalEvent $event, string $operation): void
    {
        Log::warning('signal.immutable_mutation_blocked', [
            'operation' => $operation,
            'event_id' => $event->getAttribute('event_id'),
            'tenant_company_id' => $event->getAttribute('tenant_company_id'),
            'trace_id' => $event->getAttribute('trace_id'),
        ]);
    }
}
