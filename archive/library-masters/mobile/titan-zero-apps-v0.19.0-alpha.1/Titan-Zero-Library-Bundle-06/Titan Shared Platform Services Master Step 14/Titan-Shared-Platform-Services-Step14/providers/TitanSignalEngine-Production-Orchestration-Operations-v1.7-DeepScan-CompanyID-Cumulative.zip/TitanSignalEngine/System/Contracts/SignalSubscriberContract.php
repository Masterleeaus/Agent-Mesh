<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryContext;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;

interface SignalSubscriberContract
{
    public function handle(SignalEvent $event, SignalDeliveryContext $delivery): void;
}
