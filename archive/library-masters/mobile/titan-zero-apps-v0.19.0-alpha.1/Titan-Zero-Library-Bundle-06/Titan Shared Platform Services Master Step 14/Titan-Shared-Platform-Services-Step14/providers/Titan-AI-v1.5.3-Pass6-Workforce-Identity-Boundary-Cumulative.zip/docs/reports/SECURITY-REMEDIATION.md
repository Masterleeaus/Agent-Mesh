# Security Remediation

- Removed request-controlled provider endpoints and API keys.
- Added trusted provider registry with HTTPS/host allow-list checks and private-IP rejection.
- Added credential resolver contract so host vaults can replace environment/config credentials.
- Removed direct Chatbot model dependency from runtime deployment resolution.
- Removed embedded WorkCore implementation and direct WorkCore compile-time dependencies.
- Added company-scoped approval reads/claims/resolution and rollback controllers remain company constrained.
- Added stable idempotency reuse for governed actions and approval requests.
- Moved action-receipt SQL behind a repository boundary.
- Governance routes are actually registered and inherit `web` + `auth`; controllers require explicit host abilities.
- Secrets are not intentionally written to logs or diagnostics.
- Added explicit runtime disable enforcement and governance fail-closed behavior.
- Removed caller-supplied provider tool schemas; conversational tools now come from the TitanAI registry and require validated host permissions.
- Replaced invented rollback operation names with explicit canonical WorkCore rollback mappings.
- Moved remote WorkCore rollback calls outside database transactions and added stable rollback idempotency/retry state.
- Rejected caller-supplied assistant deployment definitions and separated tool permissions from capability declarations.
- Filtered assistant capability output to registered capability IDs only.
- Removed unused raw provider/host-adapter response retention from normalized conversation results.
- Extended runtime-disable enforcement to direct governed tool, approval and rollback execution paths.

## v1.3.0 company-boundary hardening

- Standardised runtime, governance, memory, persona, skill, tool-permission and WorkCore execution boundaries on positive integer `company_id`.
- Removed runtime/controller fallback to legacy tenant identifiers.
- Added explicit positive-company validation at public approval and rollback service boundaries.
- Scoped approval/receipt/rollback reads and mutations by both object identifier and `company_id`.
- Propagated canonical `company_id` through governed WorkCore metadata and direct retained Tier-3 WorkCore workers.
- Added a fail-closed forward migration that validates legacy values, creates an indexed unsigned bigint `company_id`, copies only valid values, verifies every row is bounded, removes the legacy column and makes `company_id` non-null.
