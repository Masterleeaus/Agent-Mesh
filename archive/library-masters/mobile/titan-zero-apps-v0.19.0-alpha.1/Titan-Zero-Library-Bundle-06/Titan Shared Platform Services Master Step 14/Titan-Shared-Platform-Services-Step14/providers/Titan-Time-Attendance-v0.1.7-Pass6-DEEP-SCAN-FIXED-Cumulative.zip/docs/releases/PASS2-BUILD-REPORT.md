# Titan Time & Attendance v0.1.0-alpha.2 — Pass 2 Build Report

## Purpose

Pass 2 converts the Alpha.1 domain foundation into a governed Titan participant without duplicating the central Titan engines.

## Implemented

### Governed mutations

- `TimeCommandBusGateway`
- `TimeCommandBusPort` and fail-closed deferred default
- immutable `TimeCommandRequest`
- capability permission/risk/human-approval metadata
- input allowlisting/tenant stripping through `TimeInputShield`
- tenant-scoped command receipts
- pre-execution idempotency reservation
- row locking to serialize concurrent retries
- local execution limited to configured human sources
- AI/non-human writes blocked when Command Bus is unavailable

### Canonical cross-extension authority

- CRM work orders use `work_order_public_id`.
- CRM service locations use `service_location_public_id`.
- CRM is queried only through `CrmCapabilityExecutor` read capabilities.
- No CRM model/table import was added.
- Tenant context can adapt to CRM's canonical `CrmCompanyScope` when CRM is installed.

### Signals

- Signal outbox deduplication has a database uniqueness boundary and insert-race recovery.
- Signal delivery is partitioned by tenant.
- Scheduler dispatches unique tenant jobs to `titan-time-attendance`.
- Jobs emit canonical envelopes through Laravel event `titan.signal`.
- Retry/backoff metadata remains in the extension-owned outbox.

### AI Workforce

The extension remains authoritative for its Workforce definitions. Pass 2 aligns all four roles to the current Titan Workforce role schema with Tier 1 manager / Tier 2 specialist-agent roles and records that writes must use Titan Command Bus. Read tools now support canonical CRM work-order/service-location filtering.

### Security/hardening

- canonical CRM location evidence is fail-closed for geofence and QR verification
- no caller-controlled tenant identity accepted
- IP verification still uses server-observed IP and tenant-owned policy
- command replay is tenant + capability + idempotency scoped
- concurrent retries are row-locked before domain mutation
- explicit MySQL-safe index names avoid the 64-character identifier limit
- rollback removes indexes before canonical reference columns
- full lint discovered and corrected a `TimeEntryController` syntax defect

## Database delta

Migration `2026_08_15_000005_add_ext_titan_time_governance.php`:

- creates `ext_titan_time_command_receipts`
- adds Signal `dedup_key`
- adds `work_order_public_id` to time entries/timers
- adds `service_location_public_id` to geofence/QR/IP/verification records
- adds explicit reversible indexes

No foreign/shared table is created or altered.

## Verification boundary

The release gate checks architecture, PHP syntax, JSON validity, current Titan Workforce role schema, migration identifier lengths, migration reversibility, package integrity and archive hygiene. Live Titan Zero host installation remains an external runtime gate.

## Pre-package verification — 2026-08-15

- Pass 2 architecture contract: PASS
- standalone package verifier: PASS
- PHP syntax: 60 / 60 PASS
- JSON parsing: 4 / 4 PASS
- current Titan Workforce RoleDefinition schema: 4 / 4 roles PASS
- explicit MySQL index identifiers over 64 characters: 0
- active dangerous/legacy module token hits: 0

These are source/package checks. They do not replace a live Titan Zero host migration/queue/HTTP test.
