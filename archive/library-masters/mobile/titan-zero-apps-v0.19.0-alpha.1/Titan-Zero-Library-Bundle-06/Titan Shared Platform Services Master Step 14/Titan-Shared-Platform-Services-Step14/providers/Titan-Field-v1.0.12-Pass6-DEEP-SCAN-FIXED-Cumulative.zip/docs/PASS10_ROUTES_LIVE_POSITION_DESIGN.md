# Pass 10 — Routes, Route Stops & Live Worker Position

Titan Field owns day routes, ordered stops and shift-bounded worker location evidence. Donor concepts from Dispatch/FSM routing are adapted without importing donor tables, providers or writers.

## Boundaries
- One route per tenant + worker + day.
- Stops reference existing Titan Field appointments/work orders/locations.
- Stop order is explicit/manual or appointment-time derived. **Route optimization is not claimed.**
- Route/stop mutations use the governed command gateway and transactional Signal outbox.
- Live location is privacy-sensitive: active worker, explicit consent metadata, active same-day route, bounded accuracy, and 1–30 day retention.
- Location pings are operational telemetry only and do not confer assignment or authorization.
