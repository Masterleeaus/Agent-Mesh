# Titan Assets — donor feature convergence matrix

This release ports the **useful asset-domain behaviour** from the supplied donor set. It intentionally does not preserve old framework scaffolding or functionality that belongs to Titan Locker or the future premises authority.

| Donor surface | Donor behaviour | Titan Assets 0.2.0-alpha.2 | Decision |
|---|---|---|---|
| Asset | asset dashboard/register CRUD | Overview + Asset Register + detail/edit/delete | Ported |
| Asset | image upload/removal | company-scoped asset media service | Ported |
| Asset | asset type CRUD | Asset Types | Ported |
| Asset | asset categorisation | Asset Categories | Ported/normalized |
| Asset | asset tag/ref identity | configurable prefix + generated references | Ported |
| Asset | QR identity and scan | QR token + scan lookup | Ported |
| Asset | issue/lend, return, history | Custody + Lending/Asset History | Ported |
| Asset | allocation, quantity, revoke | Allocations + partial/full revocation | Ported |
| Asset | QR issue | scan issue action | Ported |
| Asset | QR return | scan return action | Ported |
| Asset | QR report | scan report action | Ported |
| Asset | QR send to maintenance | scan maintenance action | Ported |
| Asset | QR complete maintenance | scan complete-maintenance action | Ported |
| Asset | QR allocate | scan allocation action | Ported |
| Asset | QR revoke allocation | scan revocation action | Ported |
| Asset | maintenance CRUD | Maintenance lifecycle | Ported |
| Asset | maintenance priority/assignment/details | reference, priority, assignee, notes, next due | Ported |
| Asset | maintenance notifications/settings | sent/assigned notification toggles, recipients, subjects/bodies | Ported |
| Asset | acquisition/value/status/condition | Asset Register + Lifecycle/Valuation | Ported |
| Asset | depreciation/write-off | depreciation + write-off lifecycle | Ported |
| Asset | warranty fields | unified Warranties | Ported/converged |
| FSMEquipment | repair order CRUD | Repairs | Ported/converged |
| FSMEquipment | repair assignment/stages | repair assignee + governed stages | Ported |
| FSMEquipment | repair templates | Repair Templates | Ported/converged |
| FSMEquipment | warranty CRUD | Warranties | Ported/converged |
| FSMEquipment | downtime report | Downtime aggregation/report | Ported |
| FSMEquipmentWarranty | warranty profile CRUD | Warranty Profiles | Ported |
| FSMEquipmentWarranty | expiry computation | warranty-profile compute service/route | Ported |
| FSMRepair | repair API/domain | canonical Repairs web/API service | Converged; duplicate donor schema rejected |
| FSMRepair | parts/labour cost, root cause, parts, warranty state | canonical repair fields and totals | Ported |
| FSMRepairTemplate | template CRUD/API | canonical Repair Templates web/API | Converged; duplicate donor schema rejected |
| FSMVehicle | vehicle CRUD/status | Fleet register/status | Ported |
| FSMVehicle | vehicle reporting/service state | Fleet report + service/registration alerts | Ported |
| FSMVehicle | mileage logs | Mileage | Ported |
| FSMStock | location equipment register | Location Register | Ported |
| FSMStock | equipment check events | Equipment Check-in/Check-out | Ported |
| FSMStock | stock categories/items/moves/reorder/order stock lines | Titan Locker inventory authority | Excluded from Assets by design |
| ManagedPremises | property-to-asset relationships | Premises Links | Ported as a boundary/link only |
| ManagedPremises | properties/units/rooms/contacts/jobs/keys/photos/checklists/tags/hazards/windows/service plans/visits/inspections/documents | premises authority | Excluded from Assets by design |
| FieldItems / SupplyChain / WMS | stock, warehouse, transfers, procurement | Titan Locker | Excluded from Assets by design |

## Donor source size inspected

The asset-adjacent donor modules contain hundreds of files because they include controllers, old module registration, UI, translations, migrations and duplicated framework infrastructure. `docs/DONOR-ASSET-SURFACE-INVENTORY.json` records the exact scanned controller/route surface used for this convergence.

## Rejected implementation patterns

The source donor is **not** copied wholesale because doing so would import known defects: duplicated `Asset/Routes/web.php`, route-name duplication, case-colliding factory paths, overlapping repair/warranty schemas, legacy `Modules\\*` namespaces, Worksuite helpers, `module_path()`, `FSMCore`/`SystemCore` assumptions, and old menu/subscription/permission glue. Titan Assets ports the business behaviour into a single authority instead.
