# Titan Nexus RC2 Adversarial Safety

Step 2 adds fail-closed regression coverage for the highest-risk Nexus boundaries. The standalone suite `tests/standalone-adversarial-safety-check.php` attacks:

- ambiguous/string boolean coercion at governance and mutation boundaries;
- approval downgrade attempts against `requires_approval` operations;
- missing Autonomy grants for agent/system initiators;
- snake, kebab, camel and Pascal secret-key variants, including nested receipt metadata;
- forged operation and idempotency digests;
- incomplete applied/already-applied mutation evidence;
- cross-tenant provisioning execution;
- unknown/self/cyclic provisioning dependencies;
- canonical Vertical Definition content tampering under a stale `definition_hash`;
- legacy menu identity collisions and unisolated provider navigation failures;
- missing database uniqueness / optimistic compare-and-swap concurrency guards.

The test is intentionally standalone so these safety invariants can be checked without a mounted Laravel host. Live database races and exact-host menu failure injection remain part of later host-certification passes.
