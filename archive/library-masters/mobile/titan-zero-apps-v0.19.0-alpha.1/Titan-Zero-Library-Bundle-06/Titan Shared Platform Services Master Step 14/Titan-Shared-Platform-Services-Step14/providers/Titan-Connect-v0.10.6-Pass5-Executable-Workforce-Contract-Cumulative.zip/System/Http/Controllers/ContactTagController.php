<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Models\ContactTag;
use App\Extensions\TitanConnect\System\Services\MessagingAuditService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

final class ContactTagController extends Controller
{
    public function __construct(private readonly CompanyContext $context, private readonly MessagingAuditService $audit) {}

    public function index(Request $request): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        return response()->json(['data' => ContactTag::query()->forCompany($companyId)->orderBy('name')->limit(5000)->get()]);
    }

    public function store(Request $request): JsonResponse
    {
        $companyId = $this->context->companyId($request); $actorId = $this->context->actorId($request);
        $data = $request->validate(['name' => ['required','string','max:120'], 'color' => ['nullable','regex:/^#[0-9A-Fa-f]{6}$/'], 'background_color' => ['nullable','regex:/^#[0-9A-Fa-f]{6}$/']]);
        $tag = ContactTag::query()->firstOrNew(['company_id' => $companyId, 'name' => trim($data['name'])]);
        if (! $tag->exists) { $tag->uuid = (string) Str::uuid(); $tag->created_by = $actorId; }
        $tag->color = $data['color'] ?? $tag->color ?? '#64748b';
        $tag->background_color = $data['background_color'] ?? $tag->background_color;
        $tag->save();
        $this->audit->record($companyId, $actorId, $tag->wasRecentlyCreated ? 'contact-tag.created' : 'contact-tag.updated', 'contact-tag', $tag->uuid);
        return response()->json($tag, $tag->wasRecentlyCreated ? 201 : 200);
    }

    public function destroy(Request $request, ContactTag $tag): JsonResponse
    {
        $companyId = $this->context->companyId($request); $actorId = $this->context->actorId($request);
        abort_unless((int) $tag->company_id === $companyId, 404); $uuid = $tag->uuid; $tag->delete();
        $this->audit->record($companyId, $actorId, 'contact-tag.deleted', 'contact-tag', $uuid);
        return response()->json(['status' => 'deleted']);
    }
}
