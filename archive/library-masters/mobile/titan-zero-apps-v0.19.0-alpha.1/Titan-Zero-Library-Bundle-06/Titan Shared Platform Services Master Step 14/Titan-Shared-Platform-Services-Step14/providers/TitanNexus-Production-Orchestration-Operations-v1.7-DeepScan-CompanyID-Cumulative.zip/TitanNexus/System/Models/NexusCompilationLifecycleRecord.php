<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Models;

use Illuminate\Database\Eloquent\Model;

final class NexusCompilationLifecycleRecord extends Model
{
    protected $table = 'titan_nexus_compilation_events';
    public $timestamps = false;
    protected $guarded = ['id', 'occurred_at'];
    protected $casts = [
        'tenant_company_id' => 'integer',
        'entity_version' => 'integer',
        'payload' => 'array',
    ];
}
