<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Contracts;

use App\Extensions\TitanGovernance\System\Actions\GovernanceActionRequest;

interface GovernanceManagerContract
{
    public function health(): array;
    public function dashboardSnapshot(int $tenantCompanyId, array $context = []): array;
    public function trustMap(int $tenantCompanyId, array $context = []): array;
    public function sourceHealth(int $tenantCompanyId, array $context = []): array;
    public function autonomyEvidence(int $tenantCompanyId, array $context = []): array;
    public function signalHeatmap(int $tenantCompanyId, array $context = []): array;
    public function operationalPressure(int $tenantCompanyId, array $context = []): array;
    public function circuitBreakers(int $tenantCompanyId, array $context = []): array;
    public function projectionHistory(int $tenantCompanyId, string $type, int $limit = 50): array;
    public function escalationQueue(int $tenantCompanyId, int $limit = 50): array;
    public function performEscalationAction(GovernanceActionRequest $request): array;
    public function recentDecisions(int $tenantCompanyId, int $limit = 25): array;
    public function decisionTimeline(int $tenantCompanyId, string $decisionId, array $context = []): array;
    public function decisionDetail(int $tenantCompanyId, string $decisionId, array $context = []): array;
    public function decisionDelta(int $tenantCompanyId, string $leftDecisionId, string $rightDecisionId, array $context = []): array;
    public function decisionCompliance(int $tenantCompanyId, string $decisionId, array $context = []): array;
    public function rewindTheater(int $tenantCompanyId, string $decisionId, array $context = []): array;
    public function controlCentre(int $tenantCompanyId, array $context = []): array;
    public function workforceOversight(int $tenantCompanyId, array $context = []): array;
    public function humanOversight(int $tenantCompanyId, array $context = []): array;
    public function authorityConstraint(array $autonomyKey, string $disposition, ?float $ceilingScore, array $reasonCodes, array $evidenceRefs, string $policyVersion, string $traceId): array;
}
