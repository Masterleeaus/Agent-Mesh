<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'version' => '1.0.0-rc.2',
    'compiler_version' => '0.5.0',
    'tenant_key' => 'tenant_company_id',

    'navigation' => [
        'enabled' => true,
    ],

    'authorization' => [
        'delegated_admin_permissions' => [],
    ],

    'tenant_context' => [
        'public_contract' => null,
        'resolve_method' => 'resolveTenantForNexus',
        'user_attributes' => ['company_id', 'tenant_company_id'],
    ],

    'vertical_engine' => [
        'public_contract' => null,
        'resolve_method' => 'resolveForNexus',
    ],

    'readiness' => [
        'public_contract' => null,
        'check_method' => 'checkCapabilitiesForNexus',
        'static_capabilities' => [],
    ],

    'command_bus' => [
        'public_contract' => null,
        'execute_method' => 'executeForNexus',
    ],

    // Required before any consequential provisioning mutation.
    'risk' => [
        'public_contract' => null,
        'evaluate_method' => 'evaluateForNexus',
    ],
    'governance' => [
        'public_contract' => null,
        'authorize_method' => 'authorizeForNexus',
    ],
    'assurance' => [
        'public_contract' => null,
        'verify_method' => 'verifyForNexus',
    ],
    'signal' => [
        'public_contract' => null,
        'emit_method' => 'emitForNexus',
    ],
    'rewind' => [
        'public_contract' => null,
        'record_method' => 'recordForNexus',
    ],

    // Required only for agent/system initiated provisioning.
    'autonomy' => [
        'public_contract' => null,
        'authorize_method' => 'authorizeForNexus',
    ],


    // Conditional readiness: required only when a vertical/policy requires Knowledge Authority evidence.
    'knowledge_authority' => [
        'public_contract' => null,
    ],

    // Optional UI integration readiness. Nexus routes remain usable without Interface Runtime.
    'interface_runtime' => [
        'public_contract' => null,
    ],
];
