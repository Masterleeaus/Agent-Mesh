<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Services\InboxBadgeService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class NavigationController extends Controller
{
    public function __construct(private readonly CompanyContext $context)
    {
    }

    public function badges(Request $request, InboxBadgeService $badges): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);

        return response()->json([
            'data' => $badges->summary($companyId, $actorId),
        ]);
    }
}
