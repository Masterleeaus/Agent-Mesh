# Disaster recovery

Filesystem and database mutations create verified recovery points before writes. Restore verifies sealed manifests, payload hashes and database target identity. Rollback itself snapshots current state first. Keep `storage/app/titan-mcp/backups` and `storage/logs/titan-mcp-audit.jsonl` on durable encrypted storage and include them in host backups. After disaster recovery, verify the audit chain and several representative backup manifests before re-enabling writes.
