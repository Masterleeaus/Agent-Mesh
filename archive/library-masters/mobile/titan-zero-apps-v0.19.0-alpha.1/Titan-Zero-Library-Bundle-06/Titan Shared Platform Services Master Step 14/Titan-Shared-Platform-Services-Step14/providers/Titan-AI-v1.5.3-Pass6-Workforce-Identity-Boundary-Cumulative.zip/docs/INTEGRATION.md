# Host and product integration

## MagicAI host

TitanAI depends on MagicAI for authentication, company membership, permissions, Laravel lifecycle and extension discovery. Where the host still uses the static marketplace provider map, register:

```php
'titan-ai' => \App\Extensions\TitanAI\System\TitanAIServiceProvider::class,
```

## Product sources

Installed product extensions register adapters with `ConversationSourceRegistry` and source policy with `ConversationSourcePolicyRegistry`. Dynamic trusted tools are registered with `TrustedToolContributionRegistry`.

Do not replace TitanAI's source registries with a product-specific singleton binding. Multiple sources must coexist.

## Company context

Each source adapter derives `company_id` from trusted persisted host state and validates principal membership/ownership before calling TitanAI. Do not accept company authority from a browser body, webhook body or workflow payload.

## WorkCore

Business actions cross `WorkCoreRuntimeBridgeContract`. When canonical WorkCore is absent, non-business conversation features may still operate while mapped business actions fail closed.

## Permissions

Source adapters pass a current host permission snapshot. AI Agent additionally intersects that snapshot with explicit workflow permission grants. Empty required permission sets fail closed.
