<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Navigation;

use App\Extensions\TitanConnect\System\Host\HostMenuLifecycle;
use Illuminate\Support\Facades\Schema;

/**
 * Synchronizes Titan Connect with MagicAI's database-backed menu catalogue.
 *
 * User navigation stays outside MagicAI's legacy extension-plan gate because Titan Connect
 * is not yet a native item in that catalogue. Company authorization remains enforced by
 * Titan Connect routes/services. Dynamic unread counts are never persisted in this table.
 */
final class MagicAiMenuSynchronizer
{
    /** Icons already proven by the current Titan/MagicAI navbar component set. */
    private const HOST_SAFE_ICONS = [
        'tabler-layout-dashboard', 'tabler-inbox', 'tabler-message-cog', 'tabler-message',
        'tabler-photo', 'tabler-phone-call', 'tabler-bell-ringing', 'tabler-users-group',
        'tabler-world', 'tabler-user-check', 'tabler-user-question', 'tabler-hand-stop',
        'tabler-archive', 'tabler-settings', 'tabler-folders',
    ];

    /** @var array<int,string> */
    private const OBSOLETE_OLD_HOST_ADMIN_KEYS = [
        'titan_connect_admin_settings_overview',
        'titan_connect_admin_settings_whatsapp',
        'titan_connect_admin_settings_messenger',
        'titan_connect_admin_settings_instagram',
        'titan_connect_admin_settings_telegram',
        'titan_connect_admin_settings_sms',
        'titan_connect_admin_settings_voice',
        'titan_connect_admin_settings_push',
    ];

    public function __construct(
        private readonly TitanConnectNavigation $navigation,
        private readonly HostMenuLifecycle $menuLifecycle,
    ) {
    }

    /** @return array{supported:bool,user:int,admin:int,cache_regenerated:bool} */
    public function sync(bool $regenerateCaches = true): array
    {
        $result = ['supported' => false, 'user' => 0, 'admin' => 0, 'cache_regenerated' => false];

        if (! Schema::hasTable('menus')) {
            return $result;
        }

        $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
        if (! isset($columns['key'])) {
            return $result;
        }

        $result['supported'] = true;
        $hasAdminColumn = isset($columns['is_admin']);
        $result['user'] = $this->syncDefinitions($this->navigation->user(), $columns, $hasAdminColumn ? 0 : null);

        if ($hasAdminColumn) {
            $this->removeOldHostAdminFallback();
            $result['admin'] = $this->syncDefinitions($this->navigation->admin(), $columns, 1);
        } else {
            $this->removeOldHostAdminFallback();
            if ($this->menuId('settings') !== null) {
                $result['admin'] = $this->syncDefinitions($this->liveHostAdminDefinitions(), $columns, null);
            }
        }

        if ($regenerateCaches) {
            $result['cache_regenerated'] = $this->menuLifecycle->regenerate();
        }

        return $result;
    }

    public function remove(bool $regenerateCaches = true): void
    {
        if (! Schema::hasTable('menus')) {
            return;
        }

        $keys = [];
        foreach (array_merge($this->navigation->user(), $this->navigation->admin(), $this->liveHostAdminDefinitions()) as $definition) {
            if (isset($definition['key']) && is_string($definition['key'])) {
                $keys[] = $definition['key'];
            }
        }
        $keys = array_merge($keys, self::OBSOLETE_OLD_HOST_ADMIN_KEYS);

        if ($keys !== []) {
            app('db')->table('menus')->whereIn('key', array_values(array_unique($keys)))->delete();
        }

        if ($regenerateCaches) {
            $this->menuLifecycle->regenerate();
        }
    }

    /**
     * @param array<int,array<string,mixed>> $definitions
     * @param array<string,bool> $columns
     */
    private function syncDefinitions(array $definitions, array $columns, ?int $isAdmin): int
    {
        $count = 0;
        $roots = array_values(array_filter($definitions, static fn (array $item): bool => ($item['parent_key'] ?? null) === null));
        $children = array_values(array_filter($definitions, static fn (array $item): bool => ($item['parent_key'] ?? null) !== null));

        foreach (array_merge($roots, $children) as $definition) {
            $key = (string) ($definition['key'] ?? '');
            if ($key === '') {
                continue;
            }

            $parentId = null;
            $parentKey = $definition['parent_key'] ?? null;
            if (is_string($parentKey) && $parentKey !== '') {
                $parentId = $this->menuId($parentKey);
                if ($parentId === null) {
                    continue;
                }
            }

            $this->upsert($definition, $parentId, $columns, $isAdmin);
            $count++;
        }

        return $count;
    }

    /** @param array<string,mixed> $definition @param array<string,bool> $columns */
    private function upsert(array $definition, ?int $parentId, array $columns, ?int $isAdmin): void
    {
        $key = (string) $definition['key'];
        $now = function_exists('now') ? now() : date('Y-m-d H:i:s');
        $row = [
            'parent_id' => $parentId,
            'route' => $definition['route'] ?? null,
            'route_slug' => $definition['route_slug'] ?? null,
            'label' => $definition['label'] ?? $key,
            'icon' => $this->safeIcon((string) ($definition['icon'] ?? '')),
            'svg' => null,
            'order' => (int) ($definition['order'] ?? 0),
            'is_active' => 1,
            'params' => '[]',
            'type' => 'item',
            'badge' => null,
            // Do not set the legacy MagicAI extension-plan flag until Titan Connect is
            // registered in the host's native plan feature catalogue. Super Admin bypasses
            // that gate, normal users do not, which was the cause of admin-only visibility.
            'extension' => null,
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
            'custom_menu' => 0,
            'is_admin' => $isAdmin,
            'updated_at' => $now,
        ];
        $row = array_intersect_key($row, $columns);
        if ($isAdmin === null) {
            unset($row['is_admin']);
        }

        $query = app('db')->table('menus')->where('key', $key);
        if ($query->exists()) {
            // These are extension-owned structural fields. Updating order is intentional here:
            // v0.10.4 could place items in the wrong host section and must be repaired in place.
            $query->update($row);
            return;
        }

        $insert = ['key' => $key] + $row;
        if (isset($columns['created_at'])) {
            $insert['created_at'] = $now;
        }
        app('db')->table('menus')->insert(array_intersect_key($insert, $columns));
    }

    /** @return array<int,array<string,mixed>> */
    private function liveHostAdminDefinitions(): array
    {
        return [[
            'parent_key' => 'settings',
            'key' => 'titan_connect_admin_settings',
            'route' => 'dashboard.admin.settings.titan-connect.channels.index',
            'label' => 'Titan Connect',
            'icon' => 'tabler-message-cog',
            'order' => 90,
        ]];
    }

    private function removeOldHostAdminFallback(): void
    {
        app('db')->table('menus')->whereIn('key', self::OBSOLETE_OLD_HOST_ADMIN_KEYS)->delete();
    }

    private function safeIcon(string $icon): string
    {
        return in_array($icon, self::HOST_SAFE_ICONS, true) ? $icon : 'tabler-folders';
    }

    private function menuId(string $key): ?int
    {
        $value = app('db')->table('menus')->where('key', $key)->value('id');

        return is_numeric($value) ? (int) $value : null;
    }
}
