<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/SignalDeliveryLease.php';
require __DIR__ . '/../System/Data/SignalDeliveryLeasePolicy.php';

use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryLease;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryLeasePolicy;

function pass3ConcurrencyAssert(bool $condition, string $message): void
{
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

$now = new DateTimeImmutable('2026-08-17T01:30:00+10:00');
$policy = new SignalDeliveryLeasePolicy(120);
$lease = $policy->issue('delivery-1', 'worker-a', $now, 7);

pass3ConcurrencyAssert($lease instanceof SignalDeliveryLease, 'Lease policy must issue a typed lease.');
pass3ConcurrencyAssert($lease->deliveryId === 'delivery-1', 'Lease must retain delivery identity.');
pass3ConcurrencyAssert($lease->workerId === 'worker-a', 'Lease must retain worker identity.');
pass3ConcurrencyAssert($lease->claimVersion === 7, 'Lease must retain claim version.');
pass3ConcurrencyAssert($lease->expiresAt == $now->modify('+120 seconds'), 'Lease expiry must use bounded TTL.');
pass3ConcurrencyAssert($policy->isActive($lease, $now->modify('+119 seconds')), 'Lease must remain active before expiry.');
pass3ConcurrencyAssert(! $policy->isActive($lease, $now->modify('+120 seconds')), 'Lease must be expired at its expiry boundary.');
pass3ConcurrencyAssert($policy->canFinalize($lease, $lease->token, 7, $now->modify('+30 seconds')), 'Current lease token/version must be able to finalize.');
pass3ConcurrencyAssert(! $policy->canFinalize($lease, 'stale-token', 7, $now->modify('+30 seconds')), 'Stale token must not finalize.');
pass3ConcurrencyAssert(! $policy->canFinalize($lease, $lease->token, 8, $now->modify('+30 seconds')), 'Stale claim version must not finalize.');
pass3ConcurrencyAssert(! $policy->canFinalize($lease, $lease->token, 7, $now->modify('+121 seconds')), 'Expired lease must not finalize.');
pass3ConcurrencyAssert($policy->subscriberIdempotencyKey('delivery-1') === 'signal-delivery:delivery-1', 'Subscriber idempotency key must remain stable across retries.');

echo "PASS delivery concurrency behavior\n";
