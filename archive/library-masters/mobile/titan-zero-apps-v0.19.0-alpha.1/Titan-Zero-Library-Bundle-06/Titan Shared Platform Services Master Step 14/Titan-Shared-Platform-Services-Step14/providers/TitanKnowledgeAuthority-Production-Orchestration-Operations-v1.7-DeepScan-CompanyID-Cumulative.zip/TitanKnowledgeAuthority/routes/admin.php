<?php

use App\Extensions\TitanKnowledgeAuthority\System\Http\Controllers\AdminController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', AdminController::class)->name('index');
