<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use DomainException;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

/** Records verified Titan Pay outcomes as CRM receivable evidence; it never executes a payment/refund. */
final class CrmInvoiceSettlementReferenceService
{
    public function __construct(private readonly ConnectionInterface $db,private readonly CrmReceivablesService $receivables) {}

    public function recordVerified(int $actorUserId,array $input): array
    {
        if(($input['verified']??false)!==true)throw new AuthorizationException('Settlement outcome must be verified by Titan Pay before CRM can apply it.');
        $owner=strtolower(trim((string)($input['external_owner']??'titan-pay')));
        if($owner!=='titan-pay')throw new AuthorizationException('New CRM settlement references are accepted only from titan-pay.');
        $invoiceId=trim((string)($input['invoice_public_id']??''));
        $externalId=trim((string)($input['external_payment_public_id']??$input['payment_public_id']??''));
        $direction=strtolower(trim((string)($input['direction']??'payment')));
        $amount=(int)($input['amount_minor']??0);$currency=strtoupper(trim((string)($input['currency']??'')));
        $idempotency=trim((string)($input['idempotency_key']??$input['source_event_id']??''));
        if($invoiceId===''||$externalId===''||!in_array($direction,['payment','refund'],true)||$amount<1||$currency===''||$idempotency==='')throw new InvalidArgumentException('Verified settlement requires invoice_public_id, external_payment_public_id, payment/refund direction, positive amount_minor, currency and idempotency_key.');
        $tenant=CrmCompanyScope::companyId($actorUserId);
        $canonical=['invoice_public_id'=>$invoiceId,'external_owner'=>$owner,'external_payment_public_id'=>$externalId,'provider'=>$input['provider']??null,'provider_reference'=>$input['provider_reference']??null,'direction'=>$direction,'amount_minor'=>$amount,'currency'=>$currency,'source_event_id'=>$input['source_event_id']??null];
        $payloadHash=hash('sha256',(string)json_encode($canonical,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));

        return $this->db->transaction(function()use($actorUserId,$input,$tenant,$invoiceId,$externalId,$direction,$amount,$currency,$idempotency,$payloadHash,$canonical):array{
            $existing=$this->db->table('crm_invoice_settlement_references')->where('company_id',$tenant)->where('idempotency_key',$idempotency)->lockForUpdate()->first();
            if($existing){
                if(!hash_equals((string)$existing->payload_hash,$payloadHash))throw new DomainException('Settlement idempotency key was replayed with a different payload.');
                return ['duplicate'=>true,'reference'=>(array)$existing,'invoice'=>$this->receivables->recalculateInvoice($actorUserId,$invoiceId)];
            }
            $invoice=$this->db->table('crm_invoices')->where('company_id',$tenant)->where('public_id',$invoiceId)->whereNull('deleted_at')->lockForUpdate()->first();
            if(!$invoice)return $this->mismatch($tenant,$invoiceId,null,'invoice_not_found',[], $canonical);
            if(in_array(strtolower((string)$invoice->status),['draft','void'],true))return $this->mismatch($tenant,$invoiceId,null,'invoice_not_open',['status'=>'issued|sent|viewed|paid'],['status'=>$invoice->status]+$canonical);
            if(strtoupper((string)$invoice->currency)!==$currency)return $this->mismatch($tenant,$invoiceId,null,'currency_mismatch',['currency'=>$invoice->currency],$canonical);
            if($direction==='payment'&&$amount>(int)$invoice->balance_minor)return $this->mismatch($tenant,$invoiceId,null,'overpayment',['maximum_minor'=>(int)$invoice->balance_minor],$canonical);
            $netPaid=(int)$this->db->table('crm_invoice_settlement_references')->where('company_id',$tenant)->where('invoice_public_id',$invoiceId)->where('status','applied')->where('direction','payment')->sum('amount_minor')-(int)$this->db->table('crm_invoice_settlement_references')->where('company_id',$tenant)->where('invoice_public_id',$invoiceId)->where('status','applied')->where('direction','refund')->sum('amount_minor');
            if($direction==='refund'&&$amount>$netPaid)return $this->mismatch($tenant,$invoiceId,null,'refund_exceeds_settled',['maximum_minor'=>max(0,$netPaid)],$canonical);

            $publicId=(string)Str::ulid();
            $this->db->table('crm_invoice_settlement_references')->insert([
                'public_id'=>$publicId,'company_id'=>$tenant,'user_id'=>CrmCompanyScope::actorUserId($actorUserId),'invoice_public_id'=>$invoiceId,
                'external_owner'=>'titan-pay','external_payment_public_id'=>$externalId,'provider'=>$input['provider']??null,'provider_reference'=>$input['provider_reference']??null,
                'direction'=>$direction,'amount_minor'=>$amount,'currency'=>$currency,'status'=>'applied','verified'=>true,'verified_at'=>now(),'occurred_at'=>$input['occurred_at']??now(),
                'source_event_id'=>$input['source_event_id']??null,'idempotency_key'=>$idempotency,'payload_hash'=>$payloadHash,'metadata'=>json_encode((array)($input['metadata']??[])),
                'created_at'=>now(),'updated_at'=>now(),
            ]);
            $invoice=$this->receivables->recalculateInvoice($actorUserId,$invoiceId);
            $refs=$this->receivables->references($actorUserId,$invoiceId);
            $this->db->table('crm_invoices')->where('company_id',$tenant)->where('public_id',$invoiceId)->update(['payment_references'=>json_encode(array_map(fn($r)=>['external_owner'=>$r['external_owner'],'external_payment_public_id'=>$r['external_payment_public_id'],'provider'=>$r['provider'],'reference'=>$r['provider_reference'],'direction'=>$r['direction'],'amount_minor'=>$r['amount_minor']],$refs)),'updated_at'=>now()]);
            return ['duplicate'=>false,'reference'=>(array)$this->db->table('crm_invoice_settlement_references')->where('public_id',$publicId)->first(),'invoice'=>$invoice];
        });
    }

    private function mismatch(int $tenant,string $invoiceId,?string $referenceId,string $type,array $expected,array $actual): array
    {
        $publicId=(string)Str::ulid();
        $this->db->table('crm_receivable_reconciliation_issues')->insert(['public_id'=>$publicId,'company_id'=>$tenant,'invoice_public_id'=>$invoiceId?:null,'settlement_reference_public_id'=>$referenceId,'issue_type'=>$type,'severity'=>'high','status'=>'open','expected'=>json_encode($expected),'actual'=>json_encode($actual),'created_at'=>now(),'updated_at'=>now()]);
        if($invoiceId!==''&&$this->db->table('crm_invoices')->where('company_id',$tenant)->where('public_id',$invoiceId)->exists())$this->db->table('crm_invoices')->where('company_id',$tenant)->where('public_id',$invoiceId)->update(['reconciliation_status'=>'mismatch','updated_at'=>now()]);
        return ['applied'=>false,'mismatch'=>true,'issue_public_id'=>$publicId,'issue_type'=>$type,'invoice_public_id'=>$invoiceId];
    }
}
