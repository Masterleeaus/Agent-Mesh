# Data Ownership

Titan Knowledge Authority now owns these durable tables:

- `titan_knowledge_sources`
- `titan_knowledge_source_versions`
- `titan_knowledge_documents`
- `titan_knowledge_sections`
- `titan_knowledge_claims`
- `titan_knowledge_jurisdictions`
- `titan_knowledge_applicability`

It is the canonical owner of knowledge source identity, immutable source versions, documents, sections, normalized claims, jurisdiction metadata and applicability rules. Knowledge history is retained by default; uninstall must not silently delete authoritative evidence.

The extension does **not** own CRM/business records, risk, assurance, autonomy, workflow state or command execution. Cross-domain writes are forbidden.

## Lineage
Durable knowledge records carry tenant scope where relevant plus `trace_id`, `correlation_id` and `causation_id` so later Signal/Rewind integrations can preserve causal lineage.

## Legacy compatibility
The pre-Pass-2 `titan_knowledge_sources` structure remains in place. Additive fields use explicit transitional defaults for existing records. No destructive data backfill is performed in Pass 2.

## Immutable source-version lineage
Source-version tenant ownership is copied from the canonical `KnowledgeSource` inside the transaction. Callers cannot supply or override `tenant_company_id`, `version_sequence`, `version_key` or `supersedes_version_id`. Raw evidence may be stored externally, but its SHA-256 hash and storage reference are owned by Knowledge Authority as provenance metadata.
