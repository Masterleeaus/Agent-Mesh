<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Domain\People;

use DomainException;

final readonly class ReportingLine
{
    public function __construct(
        public int $tenantCompanyId,
        public int $managerWorkerId,
        public int $reportWorkerId,
    ) {
        if ($tenantCompanyId <= 0 || $managerWorkerId <= 0 || $reportWorkerId <= 0) {
            throw new DomainException('Reporting line requires positive tenant and worker IDs.');
        }
        if ($managerWorkerId === $reportWorkerId) {
            throw new DomainException('A worker cannot report to themselves.');
        }
    }
}
