<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface RewindBridgeContract
{
    public function available(): bool;

    /** Correlate an autonomy event with the wider Titan audit/recovery timeline. */
    public function record(string $eventType, array $payload): ?string;
}
