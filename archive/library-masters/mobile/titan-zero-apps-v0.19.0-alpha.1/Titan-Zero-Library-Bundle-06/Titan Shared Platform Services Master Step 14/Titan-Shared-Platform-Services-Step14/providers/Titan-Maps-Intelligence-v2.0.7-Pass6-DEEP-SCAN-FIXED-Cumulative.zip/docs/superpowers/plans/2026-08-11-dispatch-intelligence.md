# Dispatch Intelligence Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Add tenant-safe, explainable worker recommendations and human-approved dispatch decisions to Titan Maps Intelligence.

**Architecture:** Persist recommendation/candidate/decision evidence inside Maps, consume authoritative CRM/host evidence through optional gateways, reuse TravelMatrixService for travel scoring, and never mutate CRM until an explicit approval step requests assignment. Missing external evidence remains visibly unknown.

**Tech Stack:** PHP 8.3, Laravel 10, Eloquent, Blade, existing Titan map engine and Travel Matrix services.

## Global Constraints
- Preserve `titan-extension-v1` root manifest.
- Preserve all alpha.12 installer/provider/menu/map/geofence/routing fixes.
- Company scope every Maps-owned record and lookup.
- Human approval required for assignment.
- No fabricated certification, ETA, skill, or availability evidence.

---

### Task 1: Scoring contract and runtime
**Files:** Create DTOs and `Services/DispatchScoreService.php`; create `scripts/test_dispatch_scoring_runtime.php`.
- [x] Write failing deterministic score/blocker runtime test.
- [x] Run and verify RED.
- [x] Implement weighted score, unknown-evidence handling and blocker rules.
- [x] Run and verify GREEN.

### Task 2: Persistence
**Files:** Create three migrations and Models for recommendations, candidates and decisions; update schema contract/manifest.
- [x] Extend architecture verifier first and verify RED.
- [x] Add tenant-safe schema/models.
- [x] Run migration/schema verifier GREEN.

### Task 3: Authoritative evidence gateways
**Files:** Create `Contracts/DispatchEvidenceGateway.php`, `Contracts/DispatchAssignmentGateway.php`, CRM-aware/local adapters and provider bindings.
- [x] Add failing gateway/portability checks.
- [x] Implement tenant-verified CRM reads and explicit unavailable assignment fallback.
- [x] Verify host portability remains GREEN.

### Task 4: Recommendation orchestration
**Files:** Create `Services/DispatchIntelligenceService.php` and events.
- [x] Add failing orchestration architecture test.
- [x] Reuse on-duty worker state + TravelMatrixService, score candidates, persist evidence.
- [x] Add approve/reject flow and optional CRM assignment request.
- [x] Verify cross-tenant and human-control invariants.

### Task 5: API, AI and UI
**Files:** Create controller/tools, routes, menu definition/migration, navigation page and JS hooks.
- [x] Add route/menu/capability failing checks.
- [x] Implement Dispatch Intelligence page with graphical ranked workers and score breakdown.
- [x] Add 3 governed capabilities and permissions.
- [x] Verify named-route/menu consistency.

### Task 6: Release hardening
**Files:** version/manifest/readme/changelog/build report/package hashes.
- [x] Run all inherited verifiers plus Pass-13 gates.
- [x] Lint PHP/JS and parse JSON.
- [x] Stage exact `TitanMapsIntelligence/` folder and regenerate integrity files.
- [x] Build ZIP, re-extract, rerun packaged-byte certification.
