<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Models;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScoped;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class CrmPipelineStage extends Model
{
    use CrmCompanyScoped, SoftDeletes;

    protected $table = 'crm_pipeline_stages';
    protected $guarded = ['id'];
    protected $casts = ['is_closed' => 'boolean', 'is_won' => 'boolean', 'is_active' => 'boolean'];

    public function pipeline(): BelongsTo { return $this->belongsTo(CrmPipeline::class, 'pipeline_id'); }
}
