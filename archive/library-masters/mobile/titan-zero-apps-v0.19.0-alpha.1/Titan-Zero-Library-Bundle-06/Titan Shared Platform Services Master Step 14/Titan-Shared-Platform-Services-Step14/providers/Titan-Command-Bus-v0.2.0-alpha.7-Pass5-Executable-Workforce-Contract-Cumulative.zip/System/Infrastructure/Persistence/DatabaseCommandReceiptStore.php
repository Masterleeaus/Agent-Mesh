<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Infrastructure\Persistence;

use App\Extensions\TitanCommandBus\System\Contracts\CommandReceiptStoreContract;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandReceipt;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use Illuminate\Database\QueryException;
use Illuminate\Database\DatabaseManager;
use Illuminate\Support\Facades\Schema;

final class DatabaseCommandReceiptStore implements CommandReceiptStoreContract
{
    public function __construct(private readonly DatabaseManager $db) {}

    public function existing(CommandContext $context, CommandRequest $request): ?array
    {
        $claim = $this->db->table('titan_command_idempotency')
            ->where('company_id', $context->companyId)
            ->where('idempotency_key', $request->idempotencyKey)
            ->first();
        if (! $claim) {
            return null;
        }
        $receipt = null;
        if ($claim->receipt_id !== null) {
            $receipt = $this->db->table('titan_command_receipts')->where('id', $claim->receipt_id)->first();
        }
        return [
            'request_hash' => (string) $claim->request_hash,
            'operation_id' => (string) $claim->command_id,
            'status' => (string) $claim->status,
            'receipt' => $receipt ? (array) $receipt : null,
        ];
    }

    public function claim(CommandContext $context, CommandRequest $request, string $operationId, string $requestHash): bool
    {
        try {
            $this->db->table('titan_command_idempotency')->insert([
                'company_id' => $context->companyId,
                'tenant_company_id' => $context->companyId,
                'idempotency_key' => $request->idempotencyKey,
                'request_hash' => $requestHash,
                'command_id' => $operationId,
                'status' => 'processing',
                'claimed_at' => now(),
                'expires_at' => now()->addDay(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            return true;
        } catch (QueryException $e) {
            $message = strtolower($e->getMessage());
            if (str_contains($message, 'duplicate') || str_contains($message, 'unique')) {
                return false;
            }
            throw $e;
        }
    }

    public function complete(CommandReceipt $receipt): void
    {
        $this->db->transaction(function () use ($receipt): void {
            $data = $receipt->toArray();
            $id = $this->db->table('titan_command_receipts')->insertGetId([
                'company_id' => $receipt->companyId,
                'tenant_company_id' => $receipt->companyId,
                'command_id' => $receipt->operationId,
                'idempotency_key' => $receipt->idempotencyKey,
                'request_hash' => $receipt->requestHash,
                'trace_id' => $receipt->traceId,
                'correlation_id' => $receipt->correlationId,
                'causation_id' => $receipt->causationId,
                'root_causation_id' => $receipt->rootCausationId,
                'actor_type' => $receipt->actorType,
                'actor_id' => $receipt->actorId === null ? null : (string) $receipt->actorId,
                'service_id' => $receipt->serviceId,
                'type' => 'command',
                'capability' => $receipt->capability,
                'status' => $receipt->status,
                'reason_code' => $receipt->reasonCode,
                'risk_reference' => $receipt->riskReference,
                'risk_class' => $receipt->riskClass,
                'risk_score' => $receipt->riskScore,
                'assurance_reference' => $receipt->assuranceReference,
                'assurance_level' => $receipt->assuranceLevel,
                'assurance_evidence' => json_encode($receipt->assuranceEvidence, JSON_THROW_ON_ERROR),
                'autonomy_reference' => $receipt->autonomyReference,
                'autonomy_level' => $receipt->autonomyLevel,
                'autonomy_workflow' => $receipt->autonomyWorkflow,
                'autonomy_evidence' => json_encode($receipt->autonomyEvidence, JSON_THROW_ON_ERROR),
                'governance_reference' => $receipt->governanceReference,
                'approval_reference' => $receipt->approvalReference,
                'adapter' => $receipt->adapter,
                'domain_receipt_reference' => $receipt->domainReceiptReference,
                'write_verified' => $receipt->writeVerified,
                'expected_entity_version' => is_scalar($receipt->expectedEntityVersion) ? (string) $receipt->expectedEntityVersion : null,
                'result_entity_type' => $receipt->resultEntityType,
                'result_entity_id' => is_scalar($receipt->resultEntityId) ? (string) $receipt->resultEntityId : null,
                'result_entity_version' => is_scalar($receipt->resultEntityVersion) ? (string) $receipt->resultEntityVersion : null,
                'replayed' => $receipt->replayed,
                'payload' => json_encode($data, JSON_THROW_ON_ERROR),
                'executed_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            $this->db->table('titan_command_idempotency')
                ->where('company_id', $receipt->companyId)
                ->where('idempotency_key', $receipt->idempotencyKey)
                ->update(['status' => $receipt->status, 'receipt_id' => $id, 'updated_at' => now()]);
        });
    }

    public function health(): array
    {
        return [
            'receipts_table' => Schema::hasTable('titan_command_receipts'),
            'idempotency_table' => Schema::hasTable('titan_command_idempotency'),
        ];
    }
}
