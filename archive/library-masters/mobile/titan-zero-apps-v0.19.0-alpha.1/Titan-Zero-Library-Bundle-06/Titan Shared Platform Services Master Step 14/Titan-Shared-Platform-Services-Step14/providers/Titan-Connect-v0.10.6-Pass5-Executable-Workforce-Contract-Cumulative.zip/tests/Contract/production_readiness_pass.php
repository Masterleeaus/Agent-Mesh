<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$passes = [];
$failures = [];
$read = static fn (string $path): string => is_file($root.'/'.$path) ? (string) file_get_contents($root.'/'.$path) : '';
$check = static function (bool $condition, string $name) use (&$passes, &$failures): void {
    if ($condition) $passes[] = $name; else $failures[] = $name;
};

$rate = $read('System/Http/Middleware/EnforceCompanyRateLimit.php');
$config = $read('config/titan-connect.php');
$api = $read('routes/api.php');
$web = $read('routes/web.php');
$diagService = $read('System/Services/ConnectionDiagnosticsService.php');
$readiness = $read('System/Services/HostReadinessService.php');
$diagController = $read('System/Http/Controllers/DiagnosticsController.php');
$diagnoseCommand = $read('System/Console/DiagnoseTitanConnectCommand.php');
$provider = $read('System/TitanConnectServiceProvider.php');
$settings = $read('resources/views/settings/index.blade.php');
$inbox = $read('resources/views/inbox/index.blade.php');
$operatorJs = $read('resources/assets/js/operator-inbox.js');
$voiceMigration = $read('database/migrations/2026_08_09_000005_harden_voice_runtime.php');
$voiceTranscript = $read('System/Models/VoiceTranscript.php');
$voiceManager = $read('System/Voice/VoiceSessionManager.php');
$voiceController = $read('System/Http/Controllers/VoiceCallController.php');
$voiceView = $read('resources/views/voice/call.blade.php');
$voiceJs = $read('resources/assets/js/voice-call-client.js');
$hostDoc = $read('docs/HOST_CERTIFICATION.md');
$manifest = $read('extension.json');

$check(str_contains($rate, 'EnforceCompanyRateLimit') && str_contains($rate, 'CompanyContext'), 'RATE middleware exists and resolves authenticated company context');
$check(str_contains($rate, 'companyId') && str_contains($rate, 'actorId') && str_contains($rate, 'RateLimiter'), 'RATE key includes company + actor and uses Laravel RateLimiter');
$check(str_contains($rate, 'Retry-After') && str_contains($rate, '429'), 'RATE rejection returns 429 with Retry-After');
foreach (['send','admin','upload','ai','voice'] as $bucket) {
    $check(str_contains($config, "'{$bucket}'") && str_contains($config, "'rate_limits'"), 'RATE config bucket '.$bucket.' exists');
}
$check(str_contains($api, "EnforceCompanyRateLimit::class.':send'") && str_contains($api, "EnforceCompanyRateLimit::class.':admin'"), 'RATE authenticated mutation routes use named buckets');
$check(!preg_match('/webhooks\/{provider}\/{connection}[^\n]+EnforceCompanyRateLimit/', $api), 'RATE public provider webhooks are not behind authenticated rate limiter');

$check(str_contains($diagService, 'ConnectionDiagnosticsService') && str_contains($diagService, 'company_id'), 'DIAG connection diagnostics are company-aware');
$check(str_contains($diagService, 'queued_deliveries') && str_contains($diagService, 'failed_deliveries') && str_contains($diagService, 'failed_webhooks'), 'DIAG exposes safe operational counters');
$check(!preg_match('/credential_reference\s*=>|access_token\s*=>|auth_token\s*=>|api_key\s*=>/', $diagService), 'DIAG does not return credential material');
$check(str_contains($readiness, 'HostReadinessService') && str_contains($readiness, 'database') && str_contains($readiness, 'storage'), 'DIAG host readiness service checks runtime prerequisites');
$check(str_contains($diagController, 'ChannelAccessPolicy') && str_contains($diagController, 'canManage'), 'DIAG API requires connection management permission');
$check(str_contains($diagnoseCommand, "titan-connect:diagnose") && str_contains($diagnoseCommand, 'HostReadinessService'), 'DIAG Artisan command exists');
$check(str_contains($provider, 'DiagnoseTitanConnectCommand::class'), 'DIAG command is registered by service provider');
$check(str_contains($api, 'DiagnosticsController') && str_contains($api, 'diagnostics'), 'DIAG authenticated diagnostics routes exist');

$check(str_contains($settings, 'Titan Connect Settings') && str_contains($settings, 'diagnostics'), 'UI settings page exists and surfaces diagnostics');
$check(str_contains($web, "settings") && str_contains($web, 'titan-connect.settings'), 'UI authenticated settings route exists');
$check(str_contains($inbox, 'Connection health') || str_contains($inbox, 'Manage connections'), 'UI inbox exposes connection management/health');
$check(str_contains($operatorJs, 'diagnostic') && str_contains($operatorJs, 'health'), 'UI operator JS loads diagnostics/health');
$check(str_contains($operatorJs, 'status') && str_contains($operatorJs, 'paused') && str_contains($operatorJs, 'active'), 'UI operator JS can safely activate/pause connections');

$check(str_contains($voiceMigration, 'client_event_id') && str_contains($voiceMigration, 'unique'), 'VOICE migration adds idempotent transcript event key');
$check(str_contains($voiceTranscript, 'client_event_id'), 'VOICE transcript model stores client event ID');
$check(str_contains($voiceManager, 'clientEventId') && (str_contains($voiceManager, 'firstOrCreate') || str_contains($voiceManager, 'firstOrNew')), 'VOICE transcript persistence is idempotent by client event ID');
$check(str_contains($voiceManager, "status === 'ended'") || str_contains($voiceManager, "status !== 'active'"), 'VOICE lifecycle rejects operations on ended calls');
$check(str_contains($voiceController, 'client_event_id'), 'VOICE controller accepts client transcript event ID');
$check(str_contains($voiceView, 'elapsed') && str_contains($voiceView, 'mute'), 'VOICE view exposes elapsed timer and mute control');
$check(str_contains($voiceJs, 'toggleMute') && str_contains($voiceJs, 'elapsed') && str_contains($voiceJs, 'crypto.randomUUID'), 'VOICE browser client implements mute/timer/idempotent transcript IDs');
$check(str_contains($voiceJs, 'ending') || str_contains($voiceJs, 'endPromise'), 'VOICE browser end operation is idempotent');

$check(str_contains($hostDoc, 'titan-connect:diagnose') && str_contains($hostDoc, 'rate limit') && str_contains($hostDoc, 'voice'), 'DOC host certification covers diagnose, rate limiting and voice readiness');
$check(str_contains($manifest, '0.10.6'), 'RELEASE manifest version is 0.10.6');

foreach ($passes as $pass) echo "PASS {$pass}\n";
if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL {$failure}\n");
    fwrite(STDERR, sprintf("\n%d failed; %d passed.\n", count($failures), count($passes)));
    exit(1);
}

echo sprintf("\nOK Titan Connect production-readiness contract suite: %d passed.\n", count($passes));
