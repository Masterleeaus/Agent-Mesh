# Titan CRM Core Ownership — alpha.29

**CRM Core owns customer and commercial truth.**

## Owns

- customers, organisations and contacts
- leads, deals and pipelines
- CRM activities, notes, tags and custom fields
- CRM projects/tasks/calendar for commercial coordination
- commercial service/catalogue definitions
- quotes, estimates and invoices
- receivables business state
- customer/commercial history
- CRM portal/import/integration metadata
- CRM governance/read-model infrastructure
- six commercial calculation capabilities

## Does not own

- field execution — **Titan Field**
- inventory/fleet/purchasing — **Titan Locker**
- accounting journals/reporting — **Titan Ledger**
- payment-provider execution/collections — **Titan Pay**
- autonomous authority — **Titan Autonomy**
- cross-domain planning — **Titan AI Core**
- proactive AI operations — **Titan AI Workforce**
- learning/outcome patterns — **Titan Wisdom**

## Compatibility

CRM Core retains only centralized compatibility through `CrmCapabilityOwnershipMap` and `CrmExternalDomainCapabilityBridge`, plus guarded migration/reference mappings needed by upgraded installations. Per-class external-domain aliases are removed.

At alpha.29 there are 116 CRM-owned governed capabilities and 120 compatibility-visible names owned by extracted domains (236 visible names total). The latter are routing contracts, not CRM writers.

## Alpha.28 identity ownership
CRM Core owns customer-unification roots, normalized customer identities, duplicate-review decisions, merge evidence and Lead-to-Customer conversion lineage. These are CRM commercial/customer truth and are not delegated to extracted operational engines.

## Alpha.29 commercial contract ownership
CRM Core owns immutable issued quote/estimate contract snapshots, revision/supersession lineage, acceptance evidence, and document-render job metadata. Titan Connect owns external delivery execution; Titan Pay owns money movement; Titan Ledger owns accounting consequences.

## Alpha.30 finance boundary

- CRM Core: invoice contract, amount owed, credit notes, ageing, reconciliation evidence.
- Titan Pay: payment/refund execution and provider-side payment truth.
- Titan Ledger: journal/accounting truth.
- Titan Field: validates work-order billability before handing an opaque work-order lineage reference to CRM.

Capability catalogue: 128 CRM-owned + 123 external compatibility = 251 visible names.


## Command Contract v3
CRM owns the command/receipt evidence for CRM-owned mutations. Titan Command Bus remains the execution authority boundary. Every new mutation surface must pass `crm:governance:audit-writes`.

## Alpha.34 observability boundary
Operational metrics, health checks and doctor diagnostics are derivative/read-only. They may inspect CRM-owned journals/outboxes and externally-owned integration health, but do not gain authority to mutate Field, Locker, Pay, Ledger, Autonomy, Signal, Connect or authoritative CRM business records. Capability catalogue remains 130 CRM-owned + 123 compatibility = 253 visible names.


## Alpha.35 scale boundary
Performance tooling does not change domain authority. Projection search terms, rebuild checkpoints, performance metrics and host certification results are disposable/read-only operational state. They cannot become a second writer for customer/commercial truth. Capability ownership remains **130 CRM Core authoritative + 123 external compatibility = 253 visible names**.
