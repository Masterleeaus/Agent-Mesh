# Titan CRM Governed Business OS Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn the existing CRM capability boundary into Titan's authoritative governed Business OS boundary without replacing working CRM domain code.

**Architecture:** Preserve existing repositories/domain services, enrich capability contracts, add a Command Bus port for AI-originated mutations, add trace propagation, optimistic concurrency, durable receipts/Rewind references and a transactional Signal outbox, then expose normalized AI read models. All schema work is additive and installer-safe.

**Tech Stack:** PHP 8.2+, Laravel 10, MySQL-compatible migrations, existing Titan extension installer conventions.

## Global Constraints

- Preserve working CRM functionality, routes, UI, services, models, migrations, installers, commands and integrations.
- Canonical tenant key is `tenant_company_id`; never repurpose CRM customer `company_id` or actor `user_id`.
- No direct AI database/domain mutation.
- Consequential mutations use governed capability contracts and return execution receipts.
- Every important governed mutation records Signal and Rewind-compatible trace metadata.
- External effects remain idempotent.
- Schema evolution is additive and upgrade-safe.
- Offline authority never increases.

---

### Task 1: Contract and trace verification

**Files:**
- Create: `bin/verify-v130-alpha19-governed-business-os.php`
- Modify: none initially

**Produces:** A failing static verifier covering capability metadata, trace IDs, Command Bus port, receipts, concurrency, Signal outbox, normalized AI read models and the absence of direct legacy assistant writes.

- [ ] Write verifier assertions for the intended architecture.
- [ ] Run verifier and confirm it fails because alpha.19 components do not yet exist.

### Task 2: Capability contract v2 and trace context

**Files:**
- Modify: `System/Capabilities/CrmCapabilityManifest.php`
- Modify: `System/Tenancy/CrmCompanyContext.php`
- Modify: `System/Tenancy/CrmCompanyContextResolver.php`

**Produces:** `CrmCapabilityManifest::definitions()` where every capability includes governance metadata, plus trace/correlation/causation IDs on CRM context.

- [ ] Implement contract enrichment using capability-aware policy defaults.
- [ ] Append trace and causation fields without breaking current positional constructor calls.
- [ ] Re-run verifier until this slice passes.

### Task 3: Command Bus port and AI mutation boundary

**Files:**
- Create: `System/Governance/CrmCommandBusPort.php`
- Create: `System/Governance/CrmCommandRequest.php`
- Create: `System/Governance/CrmCommandBusGateway.php`
- Modify: `System/Providers/CrmCapabilityServiceProvider.php`
- Modify: `System/AI/CrmAssistantExecutionService.php`
- Modify: `System/Integrations/InteractionEngine/CrmInteractionCapabilityHandler.php`

**Produces:** AI-originated writes become governed command requests and cannot fall through to direct repository mutation when Titan Command Bus is absent.

- [ ] Bind the CRM command bus port/gateway.
- [ ] Route legacy assistant mutation tools through the gateway.
- [ ] Preserve read-only assistant behavior.
- [ ] Route Interaction Engine capability execution through the same governed gateway.
- [ ] Re-run verifier.

### Task 4: Additive governed-state schema

**Files:**
- Create: `database/migrations/2026_08_11_000029_add_governed_business_os_contracts.php`

**Produces:** Important entities gain `entity_version`; capability operations gain trace/receipt fields; a transactional `crm_domain_signal_outbox` exists.

- [ ] Add columns/tables only when absent.
- [ ] Use bounded index names compatible with MySQL.
- [ ] Make rollback remove only alpha.19 additions.
- [ ] Re-run migration safety/lint verifiers.

### Task 5: Invariants, concurrency, receipts and Signal/Rewind records

**Files:**
- Create: `System/Governance/CrmCapabilityResourceMap.php`
- Create: `System/Governance/CrmDomainInvariantGuard.php`
- Create: `System/Governance/CrmOptimisticConcurrencyGuard.php`
- Create: `System/Governance/CrmDomainSignalPublisher.php`
- Create: `System/Governance/CrmCommandReceiptFactory.php`
- Modify: `System/Capabilities/CrmCapabilityOperationStore.php`
- Modify: `System/Capabilities/CrmCapabilityExecutor.php`
- Modify: `System/Providers/CrmCapabilityServiceProvider.php`

**Produces:** Governed writes reject stale versions, validate boundary invariants, persist durable receipts, emit Signal outbox events and return Rewind-compatible references.

- [ ] Resolve target resource/table for mutable capabilities.
- [ ] Snapshot/check `expected_version` before writes.
- [ ] Execute existing authoritative domain service.
- [ ] Advance version where applicable.
- [ ] Build/persist receipt and Signal event in the same transaction.
- [ ] Re-run verifier.

### Task 6: Safe normalized AI read model

**Files:**
- Create: `System/ReadModels/CrmAiReadModelService.php`
- Modify: `System/Capabilities/CrmCapabilityManifest.php`
- Modify: `System/Capabilities/CrmCapabilityExecutor.php`
- Modify: `System/Integrations/TitanAI/CrmTitanAIToolProvider.php`
- Modify: `System/Providers/CrmCapabilityServiceProvider.php`

**Produces:** `crm.ai.context.read` returns bounded, normalized authoritative context with entity versions and no unrestricted table handle.

- [ ] Implement supported entity map and sanitization.
- [ ] Register the read capability and TitanAI tool.
- [ ] Re-run verifier.

### Task 7: Manifest, docs, versioning and package verification

**Files:**
- Modify: `extension.json`
- Modify: `extension.manifest.json`
- Modify: `CHANGELOG.md`
- Create: `CHANGELOG_v1.3.0_ALPHA19_GOVERNED_BUSINESS_OS.md`
- Create: `docs/CRM-1.3.0-ALPHA19-GOVERNED-BUSINESS-OS-REPORT.md`
- Regenerate: `FILE-SHA256.json`

**Produces:** Installer-ready alpha.19 package with explicit Titan engine integration metadata and verifiable file inventory.

- [ ] Update version to `1.3.0-alpha.19`.
- [ ] Declare required/optional Titan engine integration contracts without hard-coupling installation.
- [ ] Run all alpha.19 verifier checks and all existing feasible verification scripts.
- [ ] PHP-lint every PHP file.
- [ ] Regenerate SHA-256 inventory.
- [ ] Zip the complete extension and compute final archive SHA-256.
