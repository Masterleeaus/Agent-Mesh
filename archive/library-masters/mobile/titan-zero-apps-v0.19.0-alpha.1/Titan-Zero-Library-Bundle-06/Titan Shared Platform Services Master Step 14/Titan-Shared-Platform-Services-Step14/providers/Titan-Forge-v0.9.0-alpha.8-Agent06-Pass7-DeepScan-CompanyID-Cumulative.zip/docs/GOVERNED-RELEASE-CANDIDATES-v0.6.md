# Titan Forge v0.6 — Governed Release Candidates

Forge v0.6 turns a locally validated artifact set into an immutable **candidate record**, not a deployment.

## Gate sequence

```text
Generated artifact set
  -> Forge local validation
  -> Titan Shield governance response
  -> Titan Risk assessment
  -> high/critical only: Model Council activation assessment
  -> Titan Governance decision boundary
  -> Titan Command Bus dispatch boundary
  -> candidate status
```

Candidate status is one of:

- `validated` — every required release gate is callable and permits progression.
- `approval_required` — no hard rejection occurred, but one or more governance gates hold progression.
- `rejected` — local validation blocks, Shield blocks progression, or Risk returns `DENY`.

With the verified peer versions used for this pass, Titan Governance and Titan Command Bus expose health-only contracts. Therefore v0.6 candidates **cannot reach production execution** and normally remain `approval_required` even when Signal, Shield and Risk are available.

## Persisted evidence

`titan_forge_release_candidates.metadata` records:

- gate fingerprint
- Shield validation/governance result
- Risk declaration and execution directive
- Council activation assessment where required
- Governance API availability
- Command Bus API availability
- reason codes
- trace/correlation/causation/operation IDs
- actor ID
- `deployment_authority: none`

The candidate is tenant-bound through `tenant_company_id` and references its persisted validation run.

## High-risk rule

High/critical Risk levels require Council review metadata. A Council activation response alone is insufficient. If Council health reports `governed_deliberation=false`, Forge records `council.governed_deliberation_unavailable` and keeps the candidate on hold.

## Signal events

Forge maps persisted lifecycle states into Titan Signal event types:

- `queued` -> `forge.build.requested`
- `generating` -> `forge.build.started`
- `generated` -> `forge.artifact.generated`
- `validating` -> `forge.validation.started`
- `validated` -> `forge.validation.passed`
- `validation_failed` -> `forge.validation.failed`
- `failed` -> `forge.build.failed`
- candidate creation -> `forge.release.candidate_created`

Each lifecycle event uses a distinct idempotency key derived from the build idempotency key plus event type, preventing one stage from deduplicating another stage.
