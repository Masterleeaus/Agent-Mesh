# MagicAI CRM 1.3.0-alpha.1 — Titan Installer Contract

## Package identity

This package is a **modified official MagicAI CRM replacement**, not a companion extension.

- schema: `titan-extension-v1`
- slug: `crm`
- folder: `Crm`
- provider: `App\Extensions\Crm\System\CrmServiceProvider`
- version: `1.3.0-alpha.1`
- migrations: enabled

Keeping the official identity preserves MagicAI provider-map, menu, route and UI assumptions.

## Platform requirements

- PHP `>=8.2`
- MagicAI `>=11.0`
- Titan Platform `>=1.0`

No Titan/Chatbot/Mobile extension is a hard install dependency. Those integrations are optional and guarded at runtime; the richer `extension.manifest.json` records their compatibility ranges.

## Publishing

CRM merges its packaged `config/crm.php` at runtime. Optional config publishing uses the extension-specific tag:

`crm-config`

The generic shared `extension` tag is not used by CRM 1.3.0-alpha.1.

## ZIP safety

The production archive must remain flat at ZIP root and use `/` separators. It must not contain an outer `Crm/` wrapper, traversal paths, `__MACOSX`, `.DS_Store`, `.env`, `.git`, `node_modules`, MagicAI core application files, or nested extension manifests.

## Integrity

`extension.json` contains SHA-256 hashes for production package files except `extension.json` itself and `FILE-SHA256.json` to avoid recursive hashing.

`FILE-SHA256.json` independently inventories and hashes every package file except itself, including `extension.json`.

## Signing

This build is **unsigned**. No Titan Ed25519 private publishing key was provided, so no signature is fabricated. It is appropriate for installer policies that allow unsigned/local packages; trusted registry signing can be applied later by the Titan signing pipeline.

## Runtime boundary

This installer-hardening pass changes package metadata, integrity verification and the provider publish tag only. It does not claim Laravel/database production certification and does not activate dormant Phase 1 code merely because source files exist.
