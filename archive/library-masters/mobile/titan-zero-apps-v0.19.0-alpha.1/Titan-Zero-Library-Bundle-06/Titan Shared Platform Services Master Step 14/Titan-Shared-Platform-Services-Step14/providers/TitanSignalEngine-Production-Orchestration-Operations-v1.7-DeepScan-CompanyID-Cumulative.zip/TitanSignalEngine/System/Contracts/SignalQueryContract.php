<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;

interface SignalQueryContract
{
    public function find(string $eventId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT): ?SignalEnvelope;

    /** @return list<SignalEnvelope> */
    public function byTrace(string $traceId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array;

    /** @return list<SignalEnvelope> */
    public function byCorrelation(string $correlationId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array;

    /** @return list<SignalEnvelope> */
    public function byRootCausation(string $rootCausationId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array;
}
