<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalSubscriberContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalSubscriptionRegistryContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryIdentity;
use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryCachePolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalSubscriptionDefinition;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use App\Extensions\TitanSignalEngine\System\Models\SignalSubscriptionRuntime;
use App\Extensions\TitanSignalEngine\System\Models\SignalSubscriptionVersion;
use DateTimeImmutable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

final class SignalSubscriptionRegistry implements SignalSubscriptionRegistryContract
{
    /** @var array<string,SignalSubscriptionDefinition>|null */
    private ?array $cache = null;
    private ?int $cacheRevision = null;
    private ?DateTimeImmutable $cacheCheckedAt = null;

    public function __construct(
        private readonly RegistryOwnershipPolicy $ownership,
        private readonly SignalSubscriptionRegistryRevision $revision,
        private readonly SignalRegistryCachePolicy $cachePolicy,
    ) {
    }

    public function register(SignalSubscriptionDefinition $definition, SignalRegistryIdentity $registrar, ?string $ownerServiceId = null): void
    {
        $this->writeDefinition($definition, $registrar, $ownerServiceId, false);
    }

    public function evolve(SignalSubscriptionDefinition $definition, SignalRegistryIdentity $registrar, ?string $ownerServiceId = null): void
    {
        $this->writeDefinition($definition, $registrar, $ownerServiceId, true);
    }

    public function find(string $subscriberKey): ?SignalSubscriptionDefinition
    {
        $subscriberKey = trim($subscriberKey);
        if ($subscriberKey === '') return null;
        return $this->all()[$subscriberKey] ?? null;
    }

    public function history(string $subscriberKey): array
    {
        $subscriberKey = trim($subscriberKey);
        if ($subscriberKey === '' || ! Schema::hasTable('titan_signal_subscription_versions')) return [];

        return SignalSubscriptionVersion::query()
            ->where('subscriber_key', $subscriberKey)
            ->orderBy('definition_version')
            ->limit(max(1, min((int) config('titan-signal-engine.registry_history_limit', 1000), 5000)))
            ->cursor()
            ->map(fn (SignalSubscriptionVersion $row): SignalSubscriptionDefinition => $this->definitionFromVersion($row))
            ->values()
            ->all();
    }

    public function matching(SignalEvent $event): array
    {
        $matches = [];
        foreach ($this->all() as $definition) {
            if ($definition->matches(
                (string) $event->event_type,
                (int) $event->schema_version,
                (string) $event->scope,
                $event->category === null ? null : (string) $event->category,
                $event->vertical_key === null ? null : (string) $event->vertical_key,
            )) {
                $matches[] = $definition;
            }
        }
        return $matches;
    }

    public function revalidate(string $subscriberKey, SignalRegistryIdentity $registrar): bool
    {
        $subscriberKey = trim($subscriberKey);
        $latest = $this->latestVersion($subscriberKey, true);
        if ($latest === null) return false;

        $this->ownership->assertSubscriberRegistration($registrar, $subscriberKey, (string) $latest->owner_service_id);
        $valid = $this->handlerIsValid((string) $latest->handler_class);
        if (! $valid) {
            $this->quarantineSafely($subscriberKey, (int) $latest->definition_version, 'invalid_handler', (string) $latest->handler_class);
            $this->invalidateLocalCache();
            return false;
        }

        if ($this->writeRuntime(
            $subscriberKey,
            (int) $latest->definition_version,
            $this->normalizedDefinitionStatus((string) $latest->status),
            'installed',
            null,
            null,
        )) {
            $this->revision->bump();
        }
        $this->invalidateLocalCache();
        return true;
    }

    public function markUninstalled(string $subscriberKey, SignalRegistryIdentity $registrar): void
    {
        $subscriberKey = trim($subscriberKey);
        $latest = $this->latestVersion($subscriberKey, true);
        if ($latest === null) throw new InvalidArgumentException('Signal subscriber key does not exist.');
        $this->ownership->assertSubscriberRegistration($registrar, $subscriberKey, (string) $latest->owner_service_id);
        if ($this->writeRuntime($subscriberKey, (int) $latest->definition_version, 'disabled', 'uninstalled', null, null)) {
            $this->revision->bump();
        }
        $this->invalidateLocalCache();
    }

    private function writeDefinition(
        SignalSubscriptionDefinition $definition,
        SignalRegistryIdentity $registrar,
        ?string $ownerServiceId,
        bool $evolution,
    ): void {
        if (! Schema::hasTable('titan_signal_subscription_versions') || ! Schema::hasTable('titan_signal_subscription_runtime')) {
            throw new RuntimeException('Versioned Signal subscription registry is not installed.');
        }

        DB::transaction(function () use ($definition, $registrar, $ownerServiceId, $evolution): void {
            $latest = $this->latestVersion($definition->subscriberKey, true);
            if (! $evolution && $latest !== null) {
                throw new InvalidArgumentException('Signal subscriber key already exists; use evolve() to create a new immutable definition version.');
            }
            if ($evolution && $latest === null) {
                throw new InvalidArgumentException('Signal subscriber key does not exist; use register() for the first definition version.');
            }

            $existingOwner = $latest === null ? null : (string) $latest->owner_service_id;
            $effectiveOwner = $ownerServiceId;
            if ($effectiveOwner === null || trim($effectiveOwner) === '') {
                $effectiveOwner = ($existingOwner !== null && ! str_starts_with($existingOwner, 'legacy:') && ! str_starts_with($existingOwner, 'package:'))
                    ? $existingOwner
                    : $registrar->serviceId;
            }

            $this->ownership->assertSubscriberRegistration($registrar, $definition->subscriberKey, $existingOwner);
            if (! $registrar->hasPermission('signal.registry.override') && $effectiveOwner !== $registrar->serviceId) {
                throw new InvalidArgumentException('Registry actor cannot assign subscriber ownership to another service.');
            }

            $version = $latest === null ? 1 : ((int) $latest->definition_version + 1);
            $registeredAt = now();
            $payload = $definition->toArray();
            unset($payload['definition_version'], $payload['owner_source'], $payload['owner_service_id'], $payload['registrar_service_id'], $payload['registered_at']);

            SignalSubscriptionVersion::query()->create([
                ...$payload,
                'definition_version' => $version,
                'owner_source' => $effectiveOwner === $registrar->serviceId ? $registrar->ownerSource : null,
                'owner_service_id' => $effectiveOwner,
                'registrar_service_id' => $registrar->serviceId,
                'registered_at' => $registeredAt,
                'registration_checksum' => self::checksum([
                    ...$payload,
                    'definition_version' => $version,
                    'owner_source' => $effectiveOwner === $registrar->serviceId ? $registrar->ownerSource : null,
                    'owner_service_id' => $effectiveOwner,
                    'registrar_service_id' => $registrar->serviceId,
                ]),
            ]);

            if ($this->handlerIsValid($definition->handlerClass)) {
                $this->writeRuntime(
                    $definition->subscriberKey,
                    $version,
                    $this->normalizedDefinitionStatus($definition->status),
                    'installed',
                    null,
                    null,
                );
            } else {
                $this->quarantineSafely($definition->subscriberKey, $version, 'invalid_handler', $definition->handlerClass, false);
            }
            $this->revision->bump();
        }, 3);

        $this->invalidateLocalCache();
    }

    /** @return array<string,SignalSubscriptionDefinition> */
    private function all(): array
    {
        $currentRevision = $this->revision->current();
        $checkedAt = new DateTimeImmutable('now');
        if ($this->cache !== null && ! $this->cachePolicy->shouldRefresh($this->cacheRevision, $currentRevision, $this->cacheCheckedAt, $checkedAt)) {
            return $this->cache;
        }
        if (! Schema::hasTable('titan_signal_subscription_versions')) {
            $this->cacheRevision = $currentRevision;
            $this->cacheCheckedAt = $checkedAt;
            return $this->cache = [];
        }

        $definitions = [];
        $seen = [];
        $rows = SignalSubscriptionVersion::query()
            ->orderBy('subscriber_key')
            ->orderByDesc('definition_version')
            ->limit(max(1, min((int) config('titan-signal-engine.registry_scan_limit', 5000), 20000)))
            ->cursor();

        foreach ($rows as $row) {
            $key = (string) $row->subscriber_key;
            if (isset($seen[$key])) continue;
            $seen[$key] = true;

            try {
                $runtime = $this->runtimeFor($key);
                if ($runtime !== null && (string) $runtime->lifecycle_status === 'uninstalled') continue;
                if ($runtime !== null && (string) $runtime->runtime_status === 'quarantined') continue;
                if (! $this->handlerIsValid((string) $row->handler_class)) {
                    $this->quarantineSafely($key, (int) $row->definition_version, 'invalid_handler', (string) $row->handler_class);
                    continue;
                }

                $effectiveStatus = $runtime === null
                    ? $this->normalizedDefinitionStatus((string) $row->status)
                    : (string) $runtime->runtime_status;
                $definitions[$key] = $this->definitionFromVersion($row, $effectiveStatus);
            } catch (Throwable $exception) {
                $this->quarantineSafely($key, (int) $row->definition_version, 'definition_invalid', $exception::class . '|' . $exception->getMessage());
                continue;
            }
        }

        $this->cacheRevision = $this->revision->current();
        $this->cacheCheckedAt = $checkedAt;
        return $this->cache = $definitions;
    }

    private function latestVersion(string $subscriberKey, bool $lock = false): ?SignalSubscriptionVersion
    {
        if (! Schema::hasTable('titan_signal_subscription_versions')) return null;
        $query = SignalSubscriptionVersion::query()
            ->where('subscriber_key', $subscriberKey)
            ->orderByDesc('definition_version');
        if ($lock) $query->lockForUpdate();
        /** @var SignalSubscriptionVersion|null $row */
        $row = $query->first();
        return $row;
    }

    private function runtimeFor(string $subscriberKey): ?SignalSubscriptionRuntime
    {
        if (! Schema::hasTable('titan_signal_subscription_runtime')) return null;
        /** @var SignalSubscriptionRuntime|null $row */
        $row = SignalSubscriptionRuntime::query()->where('subscriber_key', $subscriberKey)->first();
        return $row;
    }

    private function writeRuntime(
        string $subscriberKey,
        int $definitionVersion,
        string $runtimeStatus,
        string $lifecycleStatus,
        ?string $reasonCode,
        ?string $reasonDetail,
    ): bool {
        /** @var SignalSubscriptionRuntime $runtime */
        $runtime = SignalSubscriptionRuntime::query()->firstOrNew(['subscriber_key' => $subscriberKey]);
        $runtime->active_definition_version = $definitionVersion;
        $runtime->runtime_status = $runtimeStatus;
        $runtime->lifecycle_status = $lifecycleStatus;
        $runtime->quarantine_reason_code = $reasonCode;
        $runtime->quarantine_detail_hash = $reasonDetail === null ? null : hash('sha256', $reasonDetail);
        $runtime->quarantined_at = $runtimeStatus === 'quarantined' ? now() : null;
        $runtime->last_validated_at = now();
        $changed = ! $runtime->exists || $runtime->isDirty([
            'active_definition_version', 'runtime_status', 'lifecycle_status',
            'quarantine_reason_code', 'quarantine_detail_hash', 'quarantined_at',
        ]);
        $runtime->save();
        return $changed;
    }

    private function quarantineSafely(string $subscriberKey, int $definitionVersion, string $reasonCode, string $detail, bool $bumpRevision = true): void
    {
        try {
            if (! Schema::hasTable('titan_signal_subscription_runtime')) return;
            if ($this->writeRuntime($subscriberKey, $definitionVersion, 'quarantined', 'installed', $reasonCode, $detail)) {
                if ($bumpRevision) {
                    $this->revision->bump();
                    $this->invalidateLocalCache();
                }
            }
            Log::warning('signal.subscription_quarantined', [
                'subscriber_key' => $subscriberKey,
                'definition_version' => $definitionVersion,
                'reason_code' => $reasonCode,
            ]);
        } catch (Throwable) {
            // Quarantine reporting must never turn a bad subscriber definition into Signal ingestion failure.
        }
    }

    private function definitionFromVersion(SignalSubscriptionVersion $row, ?string $effectiveStatus = null): SignalSubscriptionDefinition
    {
        return SignalSubscriptionDefinition::fromArray([
            'subscriber_key' => $row->subscriber_key,
            'handler_class' => $row->handler_class,
            'event_patterns' => $row->event_patterns ?? [],
            'accepted_schema_versions' => $row->accepted_schema_versions ?? [],
            'scopes' => $row->scopes ?? ['tenant', 'system'],
            'categories' => $row->categories ?? [],
            'verticals' => $row->verticals ?? [],
            'queue' => $row->queue,
            'max_attempts' => $row->max_attempts,
            'backoff_seconds' => $row->backoff_seconds ?? [],
            'timeout_seconds' => $row->timeout_seconds,
            'status' => $effectiveStatus ?? $row->status,
            'definition_version' => $row->definition_version,
            'owner_source' => $row->owner_source,
            'owner_service_id' => $row->owner_service_id,
            'registrar_service_id' => $row->registrar_service_id,
            'registered_at' => $row->registered_at?->format(DATE_ATOM),
        ]);
    }

    private function invalidateLocalCache(): void
    {
        $this->cache = null;
        $this->cacheRevision = null;
        $this->cacheCheckedAt = null;
    }

    private function handlerIsValid(string $handlerClass): bool
    {
        return class_exists($handlerClass) && is_subclass_of($handlerClass, SignalSubscriberContract::class);
    }

    private function normalizedDefinitionStatus(string $status): string
    {
        return in_array($status, ['active', 'paused', 'disabled'], true) ? $status : 'disabled';
    }

    /** @param array<string,mixed> $payload */
    private static function checksum(array $payload): string
    {
        ksort($payload);
        return hash('sha256', json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }
}
