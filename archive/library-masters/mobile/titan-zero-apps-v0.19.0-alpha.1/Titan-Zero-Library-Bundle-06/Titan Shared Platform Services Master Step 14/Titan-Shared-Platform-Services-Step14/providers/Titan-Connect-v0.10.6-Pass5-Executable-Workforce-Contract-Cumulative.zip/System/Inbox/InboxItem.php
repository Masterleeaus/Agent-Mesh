<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Inbox;

final class InboxItem
{
    public function __construct(
        public readonly string $source,
        public readonly string $uuid,
        public readonly ?string $provider,
        public readonly ?string $title,
        public readonly ?string $preview,
        public readonly int $unreadCount,
        public readonly ?string $lastMessageAt,
        public readonly ?string $linkedEntityType = null,
        public readonly ?string $linkedEntityId = null,
        public readonly array $metadata = [],
    ) {
    }

    public function toArray(): array
    {
        return [
            'source' => $this->source,
            'uuid' => $this->uuid,
            'provider' => $this->provider,
            'title' => $this->title,
            'preview' => $this->preview,
            'unread_count' => $this->unreadCount,
            'last_message_at' => $this->lastMessageAt,
            'linked_entity_type' => $this->linkedEntityType,
            'linked_entity_id' => $this->linkedEntityId,
            'metadata' => $this->metadata,
        ];
    }
}
