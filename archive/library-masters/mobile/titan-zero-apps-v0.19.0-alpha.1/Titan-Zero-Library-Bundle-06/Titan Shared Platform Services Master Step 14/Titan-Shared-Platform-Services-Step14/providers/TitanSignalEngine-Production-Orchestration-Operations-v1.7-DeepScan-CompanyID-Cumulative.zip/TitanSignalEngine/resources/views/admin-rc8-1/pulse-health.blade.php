@extends('panel.layout.app')
@section('content')
@php
    $surface=$dashboard['surface'] ?? [];$pulse=$dashboard['pulse'] ?? [];$health=$dashboard['health'] ?? [];$latency=$pulse['latency'] ?? [];$delivery=$health['delivery'] ?? [];
    $pageTitle='Pulse and Health';$pageSubtitle='Throughput, latency, projection freshness, source mix and operational health';$activePage='pulse-health';
@endphp
@include('titan-signal-engine::admin-rc8-1.partials.styles')
<div class="tse-wrap">
@include('titan-signal-engine::admin-rc8-1.partials.header')
@include('titan-signal-engine::admin-rc8-1.partials.alerts')
@include('titan-signal-engine::admin-rc8-1.partials.filter')
<div class="tse-grid tse-section">
    <div class="tse-card"><div class="tse-kpi-label">Attention</div><div class="tse-value">{{ strtoupper((string)($surface['attention']['band'] ?? 'unknown')) }}</div><div class="tse-muted">score {{ $surface['attention']['score'] ?? 0 }}</div></div>
    <div class="tse-card"><div class="tse-kpi-label">Throughput</div><div class="tse-value">{{ number_format((float)($surface['event_rate_per_second'] ?? 0),3) }}/s</div><div class="tse-muted">{{ number_format((int)($surface['signal_count'] ?? 0)) }} signals</div></div>
    <div class="tse-card"><div class="tse-kpi-label">Projection</div><div class="tse-value-sm">{{ strtoupper((string)($health['pulse']['status'] ?? 'unknown')) }}</div><div class="tse-muted">backlog {{ $health['pulse']['projection_backlog_seconds'] ?? '—' }}s · age {{ $health['pulse']['last_projection_age_seconds'] ?? '—' }}s</div></div>
    <div class="tse-card"><div class="tse-kpi-label">Backpressure</div><div class="tse-value-sm">{{ !empty($delivery['backpressured']) ? 'ACTIVE' : 'CLEAR' }}</div><div class="tse-muted">pending {{ $delivery['pending'] ?? 0 }} · retry {{ $delivery['retry_wait'] ?? 0 }}</div></div>
</div>
<div class="tse-two tse-section">
    <div class="tse-card"><h2>Latency</h2><div class="tse-grid"><div><div class="tse-kpi-label">P50</div><div class="tse-value">{{ $latency['p50_ms'] ?? $latency['p50'] ?? '—' }}</div></div><div><div class="tse-kpi-label">P95</div><div class="tse-value">{{ $latency['p95_ms'] ?? $latency['p95'] ?? '—' }}</div></div><div><div class="tse-kpi-label">P99</div><div class="tse-value">{{ $latency['p99_ms'] ?? $latency['p99'] ?? '—' }}</div></div></div></div>
    <div class="tse-card"><h2>Operational health</h2>@foreach(['status'=>'Engine','captured_at'=>'Captured'] as $k=>$label)<div class="tse-statline"><span>{{ $label }}</span><strong>{{ $health[$k] ?? '—' }}</strong></div>@endforeach<div class="tse-statline"><span>Critical anomalies</span><strong>{{ $health['anomaly']['critical_open'] ?? 0 }}</strong></div><div class="tse-statline"><span>Stale processing</span><strong>{{ $delivery['stale_processing'] ?? 0 }}</strong></div></div>
</div>
<div class="tse-two tse-section">
    <div class="tse-card"><h2>Top sources</h2>@forelse(($surface['top_sources'] ?? []) as $s)<div class="tse-statline"><span>{{ $s['dimension_value'] ?? $s['source'] ?? 'unknown' }}</span><strong>{{ $s['event_count'] ?? $s['count'] ?? 0 }}</strong></div>@empty<p class="tse-muted">No source projection data.</p>@endforelse</div>
    <div class="tse-card"><h2>Top event types</h2>@forelse(($surface['top_event_types'] ?? []) as $e)<div class="tse-statline"><span class="tse-code">{{ $e['dimension_value'] ?? $e['event_type'] ?? 'unknown' }}</span><strong>{{ $e['event_count'] ?? $e['count'] ?? 0 }}</strong></div>@empty<p class="tse-muted">No event type projection data.</p>@endforelse</div>
</div>
</div>
@endsection
