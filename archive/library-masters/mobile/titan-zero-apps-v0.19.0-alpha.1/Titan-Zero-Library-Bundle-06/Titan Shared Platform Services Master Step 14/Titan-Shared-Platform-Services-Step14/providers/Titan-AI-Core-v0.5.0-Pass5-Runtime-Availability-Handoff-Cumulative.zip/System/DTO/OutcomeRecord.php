<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class OutcomeRecord { public function __construct(public string $planId, public string $plannedStatus, public string $actualStatus, public array $metrics = []) {} }
