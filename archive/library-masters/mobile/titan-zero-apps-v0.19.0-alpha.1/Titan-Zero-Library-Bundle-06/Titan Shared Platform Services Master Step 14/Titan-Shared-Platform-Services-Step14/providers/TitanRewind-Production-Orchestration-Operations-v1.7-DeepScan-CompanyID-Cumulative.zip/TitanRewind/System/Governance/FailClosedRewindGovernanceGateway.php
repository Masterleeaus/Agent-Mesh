<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Governance;

use App\Extensions\TitanRewind\System\Contracts\RewindGovernanceGatewayContract;
use LogicException;

final class FailClosedRewindGovernanceGateway implements RewindGovernanceGatewayContract
{
    public function key(): string { return 'unavailable'; }
    public function available(): bool { return false; }
    public function requestApproval(array $request): array { throw new LogicException('Titan Governance gateway is not bound; Rewind authorization fails closed.'); }
    public function refresh(string $externalRequestId, int $tenantCompanyId): array { throw new LogicException('Titan Governance gateway is not bound; Rewind authorization refresh fails closed.'); }
    public function verifyReceipt(array $receipt): bool { return false; }
}
