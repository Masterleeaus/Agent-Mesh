<?php

declare(strict_types=1);

$root = realpath(__DIR__ . '/..');
$installer = json_decode((string) file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);

function check(bool $ok, string $message): void { if (! $ok) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } }

check(($installer['schema'] ?? null) === 'titan-extension-v1', 'Installer root must use titan-extension-v1.');
check(($installer['slug'] ?? null) === 'titan-model-council', 'Installer slug must be canonical.');
check(($manifest['schema_version'] ?? null) === '2.2', 'Blueprint sidecar must use schema 2.2.');
check(($manifest['architecture']['profile'] ?? null) === 'governance-engine', 'Model Council must be a governance-engine.');
check(in_array('signal-aware', $manifest['architecture']['modifiers'] ?? [], true), 'Model Council must be signal-aware.');
check(in_array('ai-enabled', $manifest['architecture']['modifiers'] ?? [], true), 'Model Council must declare ai-enabled.');
check(in_array('model-deliberation', $manifest['authority']['owns'] ?? [], true), 'Model Council must own the registered model-deliberation domain.');
check(($manifest['authority']['cross_domain_write_policy'] ?? null) === 'explicit-versioned-contract', 'Legacy chat compatibility writes must be declared as an explicit versioned contract.');
check(($manifest['governance']['model_council'] ?? null) === 'not-applicable', 'The Model Council must not depend on itself.');
check(($manifest['governance']['signal'] ?? null) === 'required', 'Signal governance must be required.');
check(($manifest['billing']['mode'] ?? null) === 'host-entity-credits', 'Council credit billing must map to the Blueprint billing enum.');
check(($manifest['data']['tenant_key'] ?? null) === 'tenant_company_id', 'Council tenant key must remain tenant_company_id.');
check(($manifest['verification']['certification_command'] ?? null) === 'titan:titan-model-council:certify', 'Governed engine certification command must be canonical.');

foreach (($manifest['documentation'] ?? []) as $name => $relative) {
    check(is_string($relative) && is_file($root . '/' . $relative), "Missing documentation file: {$name}");
}
foreach (($manifest['capability_contracts'] ?? []) as $capability) {
    check(is_file($root . '/' . $capability['input_schema']), 'Missing capability input schema.');
    check(is_file($root . '/' . $capability['output_schema']), 'Missing capability output schema.');
}
foreach (($manifest['signal']['emits'] ?? []) as $event) {
    check(is_file($root . '/' . $event['schema']), 'Missing Signal event schema.');
}

$activeRawDb = [];
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/System'));
foreach ($it as $file) {
    if (! $file->isFile() || strtolower($file->getExtension()) !== 'php') { continue; }
    $text = (string) file_get_contents($file->getPathname());
    if (preg_match('/\\bDB::(?:table|statement|select|insert|update|delete)\\s*\\(/', $text)) {
        $activeRawDb[] = str_replace($root . '/', '', $file->getPathname());
    }
}
check($activeRawDb === [], 'Active System code must not use raw DB table access: ' . implode(', ', $activeRawDb));

check(is_file($root . '/System/Commands/CertifyExtensionCommand.php'), 'Certification command must be packaged.');
check(is_file($root . '/System/Signal/CouncilSignalEmitter.php'), 'Signal integration adapter must be packaged.');
check(is_file($root . '/System/Resilience/ProviderCircuitBreaker.php'), 'Provider circuit breaker must be packaged.');
$legacyService = (string) file_get_contents($root . '/System/Compatibility/Legacy/Services/ModelCouncilService.php');
check(str_contains($legacyService, 'ProviderCircuitBreaker'), 'Legacy provider compatibility runtime must pass through the provider circuit breaker.');

echo "PASS pass5r_blueprint_v42_runner\n";
