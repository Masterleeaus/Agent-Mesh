# Operations

Use the Super Admin page for readiness and dependency health. `risk` is now a first-class readiness dependency alongside database, Governance and Signal. Use `titan:titan-command-bus:certify --json` for host evidence. The kill switch blocks new execution. Registered adapters are runtime contributions and should be observable in future operations passes.


## Pass 10 — Assurance / Shield boundary
Mutation dispatch now requires an authoritative Assurance/Shield decision after Titan Risk and before Governance. The default bridge is fail-closed; no local assurance or Shield policy is inferred. Accepted evidence is durable and is passed into Governance, receipts, and outcome Signals.


## Pass 11 — Titan Autonomy integration

Command dispatch now resolves earned autonomy after Risk and Assurance and before Governance. Autonomy is capability/workflow-specific evidence, never a caller-selected permission. When `require_autonomy=true`, unavailable, denied, or malformed autonomy evidence fails closed before Governance or domain execution. Successful decisions preserve `autonomy_reference`, `autonomy_level`, `autonomy_workflow`, and evidence references in receipts and Signal telemetry.
