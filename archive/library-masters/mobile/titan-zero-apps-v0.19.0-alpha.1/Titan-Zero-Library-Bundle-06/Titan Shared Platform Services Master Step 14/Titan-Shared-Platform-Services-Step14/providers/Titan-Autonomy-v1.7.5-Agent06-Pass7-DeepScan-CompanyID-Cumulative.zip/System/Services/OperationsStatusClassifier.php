<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

final class OperationsStatusClassifier
{
    public function classify(array $receipt, ?int $now = null): array
    {
        $now ??= time();
        $observation = (string)($receipt['observation_status'] ?? 'unknown');
        $label = (string)($receipt['final_label'] ?? '');
        $assurance = strtoupper((string)(($receipt['assurance_at_reconciliation']['status'] ?? $receipt['assurance_at_execution']['status'] ?? '')));
        $maturesAt = $this->timestamp($receipt['matures_at'] ?? null);
        $flags = [];
        if (!empty($receipt['regression_ref'])) $flags[] = 'regression';
        if (!empty($receipt['feedback_ref'])) $flags[] = 'feedback';

        if ($observation === 'observing') {
            if ($maturesAt !== null && $maturesAt <= $now) {
                return $this->result('due_for_reconciliation', 75, true, true, $flags, ['MATURATION_WINDOW_COMPLETE']);
            }
            return $this->result('observing', 20, false, false, $flags, ['OBSERVATION_WINDOW_ACTIVE']);
        }

        if ($observation === 'awaiting_human_verification') {
            return $this->result('awaiting_human_verification', 85, true, false, $flags, ['HUMAN_VERIFICATION_REQUIRED']);
        }

        if ($label === 'correct') {
            return $this->result('verified_correct', 0, false, false, $flags, ['POSTCONDITION_VERIFIED', 'ASSURANCE_GREEN']);
        }
        if ($label === 'reversed') return $this->result('reversed', 100, true, false, $flags, ['ACTION_REVERSED']);
        if ($label === 'materially_corrected') return $this->result('materially_corrected', 98, true, false, $flags, ['MATERIAL_CORRECTION']);
        if ($label === 'incorrect') return $this->result('verification_failed', 98, true, false, $flags, ['POSTCONDITION_FAILED']);
        if ($label === 'failed') return $this->result('execution_failed', 95, true, false, $flags, ['EXECUTION_FAILED']);
        if ($label === 'rejected') return $this->result('rejected', 90, true, false, $flags, ['ACTION_REJECTED']);
        if ($assurance === 'RED') return $this->result('assurance_red', 100, true, false, $flags, ['ASSURANCE_RED']);
        if ($assurance === 'AMBER') return $this->result('assurance_amber', 88, true, false, $flags, ['ASSURANCE_AMBER']);
        if ($label === 'exception') return $this->result('exception', 92, true, false, $flags, ['AUTONOMY_EXCEPTION']);
        if ($label === 'insufficient_information') return $this->result('verification_inconclusive', 80, true, false, $flags, ['INSUFFICIENT_INFORMATION']);

        return $this->result($observation !== '' ? $observation : 'unknown', 50, true, false, $flags, ['UNCLASSIFIED_OPERATION_STATE']);
    }

    private function result(string $status, int $priority, bool $attention, bool $canRecheck, array $flags, array $reasonCodes): array
    {
        return ['status'=>$status,'priority'=>$priority,'attention'=>$attention,'can_recheck'=>$canRecheck,'flags'=>$flags,'reason_codes'=>$reasonCodes];
    }

    private function timestamp(mixed $value): ?int
    {
        if ($value === null || $value === '') return null;
        $timestamp = strtotime((string)$value);
        return $timestamp === false ? null : $timestamp;
    }
}
