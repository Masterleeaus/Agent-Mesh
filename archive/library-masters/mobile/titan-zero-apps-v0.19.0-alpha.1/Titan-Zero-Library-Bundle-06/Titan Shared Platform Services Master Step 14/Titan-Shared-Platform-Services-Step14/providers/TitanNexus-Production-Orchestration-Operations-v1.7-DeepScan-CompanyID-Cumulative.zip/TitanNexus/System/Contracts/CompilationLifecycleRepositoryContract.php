<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Contracts;

use App\Extensions\TitanNexus\System\Domain\CompilationLifecycleEvent;

interface CompilationLifecycleRepositoryContract
{
    public function record(CompilationLifecycleEvent $event): CompilationLifecycleEvent;

    /** @return list<CompilationLifecycleEvent> */
    public function historyForTenant(int $tenantCompanyId, string $compilationUuid, int $limit = 100): array;
}
