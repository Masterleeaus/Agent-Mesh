<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Services;

use App\Extensions\TitanNexus\System\Contracts\CompilationLifecycleRepositoryContract;
use App\Extensions\TitanNexus\System\Contracts\CompilationRepositoryContract;
use App\Extensions\TitanNexus\System\Contracts\NexusControlCentreContract;
use App\Extensions\TitanNexus\System\Domain\CompilationLifecycleEvent;
use App\Extensions\TitanNexus\System\Domain\ControlCentreSnapshot;
use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Support\RedactedPayload;
use InvalidArgumentException;

final class NexusControlCentreService implements NexusControlCentreContract
{
    private const LIMIT = 50;

    public function __construct(
        private readonly CompilationRepositoryContract $repository,
        private readonly ?CompilationLifecycleRepositoryContract $lifecycle = null,
    ) {}

    public function snapshot(int $tenantCompanyId, ?string $compilationUuid = null): ControlCentreSnapshot
    {
        if ($tenantCompanyId <= 0) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }

        $history = $this->repository->latestForTenant($tenantCompanyId, self::LIMIT);
        $selected = null;
        if ($compilationUuid !== null && trim($compilationUuid) !== '') {
            $selected = $this->repository->findForTenant($tenantCompanyId, trim($compilationUuid));
        } elseif ($history !== []) {
            $selected = $history[0];
        }

        $lineage = $selected === null
            ? []
            : $this->repository->lineageForTenant($tenantCompanyId, $selected->compilationUuid(), self::LIMIT);

        return new ControlCentreSnapshot(
            $tenantCompanyId,
            $this->summary($history, $selected),
            array_map(fn (NexusCompilation $item): array => $this->summaryRow($item), $history),
            $selected === null ? null : $this->detail($selected),
            array_map(fn (NexusCompilation $item): array => $this->summaryRow($item), $lineage),
        );
    }

    /** @param list<NexusCompilation> $history @return array<string,mixed> */
    private function summary(array $history, ?NexusCompilation $selected): array
    {
        $compiled = 0;
        $draft = 0;
        foreach ($history as $item) {
            if ($item->status()->value === 'compiled') {
                $compiled++;
            } elseif ($item->status()->value === 'draft') {
                $draft++;
            }
        }

        $validation = $selected?->validationResult();
        $diff = $selected?->configurationDiff();
        $plan = $selected?->provisioningPlan();
        $config = $selected?->compiledConfiguration();

        return [
            'total_compilations' => count($history),
            'compiled' => $compiled,
            'draft' => $draft,
            'current_status' => $selected?->status()->value,
            'vertical_id' => $selected?->businessProfile()->verticalId(),
            'vertical_version' => $selected?->businessProfile()->verticalVersion(),
            'configuration_version' => $config?->configurationVersion(),
            'validation' => [
                'errors' => $validation === null ? 0 : count($validation->errors()),
                'warnings' => $validation === null ? 0 : count($validation->warnings()),
                'info' => $validation === null ? 0 : count($validation->info()),
            ],
            'diff' => $diff?->summary() ?? [
                'unchanged' => 0,
                'add' => 0,
                'modify' => 0,
                'deprecate' => 0,
                'requires_approval' => 0,
                'blocked' => 0,
            ],
            'provisioning' => [
                'status' => $plan?->status()->value,
                'operations' => $plan === null ? 0 : count($plan->operations()),
                'receipts' => $plan === null ? 0 : count($plan->receipts()),
                'executed' => $plan?->executed() ?? false,
            ],
        ];
    }

    /** @return array<string,mixed> */
    private function summaryRow(NexusCompilation $compilation): array
    {
        $profile = $compilation->businessProfile();
        $config = $compilation->compiledConfiguration();
        $validation = $compilation->validationResult();
        $diff = $compilation->configurationDiff();
        $plan = $compilation->provisioningPlan();

        return [
            'compilation_uuid' => $compilation->compilationUuid(),
            'parent_compilation_uuid' => $compilation->parentCompilationUuid(),
            'status' => $compilation->status()->value,
            'dry_run' => $compilation->dryRun(),
            'profile_version' => $profile->profileVersion(),
            'vertical_id' => $profile->verticalId(),
            'vertical_version' => $profile->verticalVersion(),
            'compiler_version' => $compilation->compilerVersion(),
            'configuration_version' => $config?->configurationVersion(),
            'output_hash' => $config?->outputHash(),
            'validation' => [
                'errors' => $validation === null ? 0 : count($validation->errors()),
                'warnings' => $validation === null ? 0 : count($validation->warnings()),
                'info' => $validation === null ? 0 : count($validation->info()),
            ],
            'diff' => $diff?->summary(),
            'provisioning_status' => $plan?->status()->value,
        ];
    }

    /** @return array<string,mixed> */
    private function detail(NexusCompilation $compilation): array
    {
        $config = $compilation->compiledConfiguration();
        $validation = $compilation->validationResult();
        $diff = $compilation->configurationDiff();
        $plan = $compilation->provisioningPlan();

        $lifecycle = $this->lifecycle?->historyForTenant(
            $compilation->businessProfile()->tenantCompanyId(),
            $compilation->compilationUuid(),
            100,
        ) ?? [];

        return [
            'compilation_uuid' => $compilation->compilationUuid(),
            'parent_compilation_uuid' => $compilation->parentCompilationUuid(),
            'status' => $compilation->status()->value,
            'dry_run' => $compilation->dryRun(),
            'compiler_version' => $compilation->compilerVersion(),
            'trace' => $compilation->traceContext()->toArray(),
            'profile' => RedactedPayload::apply($compilation->businessProfile()->toArray()),
            'validation' => $validation === null ? null : RedactedPayload::apply($validation->toArray()),
            'configuration' => $config === null ? null : RedactedPayload::apply($config->toArray()),
            'diff' => $diff === null ? null : RedactedPayload::apply($diff->toArray()),
            'provisioning' => $plan === null ? null : RedactedPayload::apply($plan->toArray()),
            'lifecycle' => array_map(
                static fn (CompilationLifecycleEvent $event): array => RedactedPayload::apply($event->toArray()),
                $lifecycle,
            ),
        ];
    }
}
