<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
$adapter=(string)file_get_contents($root.'/System/Host/TitanMenuCompatibilityAdapter.php');
$model=$root.'/System/Host/LegacyMenuRow.php';
$errors=[];
if(str_contains($adapter, 'DB'.'::table'."('menus')"))$errors[]='menu fallback still uses raw DB table access';
if(!is_file($model))$errors[]='dedicated host menu compatibility model missing';
if(is_file($model) && !str_contains((string)file_get_contents($model),"protected \$table = 'menus';"))$errors[]='host menu model not scoped to menus table';
if($errors){fwrite(STDERR,'FAIL: '.implode(', ',$errors)."\n");exit(1);}echo "PASS: menu compatibility persistence boundary\n";
