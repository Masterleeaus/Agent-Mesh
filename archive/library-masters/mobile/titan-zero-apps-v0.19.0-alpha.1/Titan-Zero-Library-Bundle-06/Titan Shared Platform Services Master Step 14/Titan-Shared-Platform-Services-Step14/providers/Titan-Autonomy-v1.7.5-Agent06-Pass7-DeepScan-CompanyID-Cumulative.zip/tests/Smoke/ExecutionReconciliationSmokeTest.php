<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\Contracts\{AutonomyAuditSinkContract,AutonomyQueryContract,CapabilityStateStoreContract,ExecutionPostconditionVerifierContract,ExecutionReceiptStoreContract,LearningSinkContract,TenantAssuranceBridgeContract};
use App\Extensions\TitanAutonomy\System\DTOs\{CapabilityState,GovernedCapabilityCommand};
use App\Extensions\TitanAutonomy\System\Enums\{AutonomyLevel,RiskClass};
use App\Extensions\TitanAutonomy\System\Services\{AutonomyRuntimeService,ExecutionReconciliationService,GateEvaluator};

$states = new class implements CapabilityStateStoreContract {
    public ?CapabilityState $saved = null;
    public function save(CapabilityState $state): void {$this->saved=$state;}
};
$learning = new class implements LearningSinkContract { public array $events=[]; public function record(array $event): string {$this->events[]=$event;return 'L'.count($this->events);} };
$audit = new class implements AutonomyAuditSinkContract {
    public array $reg=[]; public function recordGateDecision(array $decision): string{return 'G1';} public function recordHandshake(array $handshake): string{return 'H1';} public function recordRegression(array $regression): string{$this->reg[]=$regression;return 'R'.count($this->reg);} 
};
$runtime = new AutonomyRuntimeService($states,$learning,$audit,new GateEvaluator(['low'=>1,'medium'=>2,'high'=>3,'critical'=>3],['low'=>'trusted_auto','medium'=>'trusted_auto','high'=>'auto','critical'=>'semi_auto']),'test-policy');
$receipts = new class implements ExecutionReceiptStoreContract {
    public array $rows=[]; public int $n=0;
    public function create(array $receipt): string {$id='E'.(++$this->n);$this->rows[$id]=$receipt+['public_id'=>$id];return $id;}
    public function findByCorrelation(int $tenantCompanyId,string $correlationId): ?array {foreach($this->rows as $r)if((int)$r['tenant_company_id']===$tenantCompanyId&&($r['correlation_id']??null)===$correlationId)return $r;return null;}
    public function due(int $limit=100): array {return array_values(array_filter($this->rows,fn($r)=>($r['observation_status']??'')==='observing'));}
    public function finalize(string $publicId,array $fields): void {$this->rows[$publicId]=array_merge($this->rows[$publicId],$fields,['observation_status'=>'finalized']);}
    public function appendFeedback(string $publicId,array $feedback): string{return 'F1';}
};
$verifier = new class implements ExecutionPostconditionVerifierContract { public string $status='verified'; public function verify(CapabilityState $state,GovernedCapabilityCommand $command,array $commandResult,array $context=[]): array{return ['status'=>$this->status,'confidence'=>.99,'reason_codes'=>[],'facts'=>['checked'=>true]];} };
$assurance = new class implements TenantAssuranceBridgeContract { public string $status='GREEN'; public function evaluateForTenant(int $tenantCompanyId,string $c,?string $w,array $x):array{return ['status'=>$this->status,'decision'=>$this->status==='GREEN'?'approved':'denied','confidence'=>.96,'reason_codes'=>[]];} };
$query = new class implements AutonomyQueryContract {
    public array $state=[];
    public function capabilityStates(int $t):array{return $this->state?[$this->state]:[];} public function capabilityState(int $t,string $c,string $w):?array{return $this->state?:null;}
    public function learningEvents(int $t,?string $c=null,?string $w=null,int $l=1000):array{return [];} public function learningPreferences(int $t,?int $u=null):array{return [];} public function learningSettings(int $t):array{return ['user_learning'=>true,'business_learning'=>true,'system_wide_learning'=>false];} public function tenantPolicy(int $t):?array{return null;} public function platformPolicy():?array{return null;} public function handshakes(int $t,?string $c=null,?string $w=null,int $l=100):array{return [];} public function regressions(int $t,?string $c=null,?string $w=null,int $l=100):array{return [];} 
};
$state = new CapabilityState(42,'crm.invoice.issue','completed_job_invoice',RiskClass::Medium,AutonomyLevel::Auto,2,0,0,0,0,0,0,0,false,['max_total'=>1500]);
$query->state=['tenant_company_id'=>42,'capability'=>'crm.invoice.issue','workflow_key'=>'completed_job_invoice','risk'=>'medium','current_level'=>'auto','required_success_streak'=>2,'current_success_streak'=>0,'highest_success_streak'=>0,'total_successes'=>0,'total_failures'=>0,'total_edits'=>0,'total_rejections'=>0,'total_reversals'=>0,'platform_gate_eligible'=>false,'scope'=>['max_total'=>1500]];
$svc = new ExecutionReconciliationService($receipts,$verifier,$runtime,$query,$assurance,'test-policy',['low'=>0,'medium'=>0,'high'=>0,'critical'=>null]);
$cmd = new GovernedCapabilityCommand('crm.invoice.issue',['total_minor'=>50000],'completed_job_invoice','corr-1',null,'sess-1','idem-1',true);
$captured = $svc->capture($state,$cmd,['workflow'=>'completed_job_invoice'],['status'=>'executed','data'=>['status'=>'ok','result'=>['public_id'=>'INV1']]],['status'=>'GREEN','confidence'=>.96],7);
if (($captured['observation_status']??null)!=='observing') throw new RuntimeException('Successful autonomous dispatch must enter observation instead of immediately becoming success evidence.');
if ($states->saved !== null || count($learning->events)!==0) throw new RuntimeException('Capture must not increment autonomy evidence before reconciliation matures.');
$finalized = $svc->finalizeDue(10);
if ($finalized !== 1) throw new RuntimeException('Due verified autonomous receipt should finalize once.');
if ($states->saved?->currentSuccessStreak !== 1 || count($learning->events)!==1 || ($learning->events[0]['learning_label']??null)!=='correct') {
    throw new RuntimeException('Matured deterministic + GREEN outcome must become one qualifying correct action.');
}

// A claimed execution whose persisted postcondition later fails must be negative and regress Auto -> Semi-Auto.
$query->state['current_level']='auto';$query->state['current_success_streak']=1;$query->state['total_successes']=1;$states->saved=null;$verifier->status='failed';
$cmd2 = new GovernedCapabilityCommand('crm.invoice.issue',['total_minor'=>50000],'completed_job_invoice','corr-2',null,'sess-2','idem-2',true);
$svc->capture($state,$cmd2,['workflow'=>'completed_job_invoice'],['status'=>'executed','data'=>['status'=>'ok','result'=>['public_id'=>'INV2']]],['status'=>'GREEN','confidence'=>.96],7);
$svc->finalizeDue(10);
if ($states->saved?->currentLevel !== AutonomyLevel::SemiAuto || ($learning->events[array_key_last($learning->events)]['learning_label']??null)!=='incorrect') {
    throw new RuntimeException('Failed postcondition must be incorrect evidence and regress an autonomous level.');
}


// Critical-risk execution may be observed for negative outcomes but must never auto-mature positive trust evidence.
$critical = new CapabilityState(42,'crm.payment.record','payment_record',RiskClass::Critical,AutonomyLevel::Auto,3,0,0,0,0,0,0,0,false,['max_total'=>100]);
$criticalCommand = new GovernedCapabilityCommand('crm.payment.record',['amount_minor'=>1000],'payment_record','corr-critical',null,'sess-critical','idem-critical',true);
$criticalCapture = $svc->capture($critical,$criticalCommand,['workflow'=>'payment_record'],['status'=>'executed','data'=>['status'=>'ok','result'=>['public_id'=>'PAY1']]],['status'=>'GREEN','confidence'=>.99],7);
if (($criticalCapture['observation_status']??null)!=='awaiting_human_verification' || !array_key_exists('matures_at',$criticalCapture) || $criticalCapture['matures_at']!==null) {
    throw new RuntimeException('Critical-risk autonomous execution must never enter automatic positive-evidence maturation.');
}

echo "OK: ExecutionReconciliationSmokeTest\n";
