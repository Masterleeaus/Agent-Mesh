# Workforce Integration Report — Titan Assets

## Result

Converged for Agent-01 operational-backbone integration. Titan AI Workforce is the sole owner of employee identity, organisational roles, hierarchy, teams, responsibilities, assignments and work items. `Titan Assets` remains authoritative only for its declared domain.

## Canonical boundary

- Tenant key: `company_id`.
- Legacy `tenant_company_id`: permitted only in explicitly retained migration/compatibility readers.
- Extension-local Workforce role/agent identity: **not active**.
- Workforce discovery: `resources/workforce/workforce-integration.json`.
- Installation/availability does not grant authorization or autonomy.
- Mutating Workforce actions require governed execution / Command Bus and execution receipts.
- Provider provenance and provider pinning are required for executable work.

## Published surfaces

Capabilities: **45**. Read/data operations: **43**. Command candidates: **2**. Responsibilities: **4**. Work types: **4**.

## Availability semantics

`available`, `degraded`, `unavailable`, `missing_provider`, `blocked`, `policy_disabled`. Provider disable/removal does not mutate Workforce identity and does not silently grant fallback authority.

## Deep-scan remediation

- Replaced active Blueprint 1.x sidecar metadata with canonical Manifest v2.2 metadata.
- Re-established `company_id` as the active contract boundary.
- Added role-neutral Workforce discovery contract and ownership migration marker.
- Added executable contract regression test.
- Preserved historical migrations and explicit legacy tenant compatibility paths instead of destructive rewrites.

## Remaining host-only evidence

Exact-host certification and production signing require the actual MagicAI host and signing material. Local verification must not be represented as `host_certified`.
