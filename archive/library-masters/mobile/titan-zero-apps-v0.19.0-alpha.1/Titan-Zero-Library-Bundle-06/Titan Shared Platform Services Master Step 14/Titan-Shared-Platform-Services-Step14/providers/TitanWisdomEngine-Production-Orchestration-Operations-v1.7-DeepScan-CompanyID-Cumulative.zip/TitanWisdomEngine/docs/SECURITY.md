# Security

All durable Wisdom operations are tenant-scoped and carry full trace, correlation, causation and root-causation lineage. Cross-tenant lookup paths fail closed.

## Evidence security

Evidence is stored separately from interpretation. `authoritative_for_fact=true` is permitted only for independently validated evidence with validator provenance. AI/agent/model self-report types cannot self-validate as authoritative truth. Content may be referenced by source record and optional SHA-256 hash instead of copied into Wisdom.

## Resolution security

Conclusive resolution requires validated authoritative evidence linked to the same tenant outcome. Later contradiction creates a new lineage record and cannot erase the original conclusion. Governance is evaluated before idempotency or mutation.

## Queue security

Delayed observation jobs contain immutable identifiers and no credentials or serialized service clients. The job is non-mutating, uses a dedicated queue, bounded retries and stable idempotency identity. Offline/degraded processing never increases authority.
