<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Data;

final class AppointmentDTO
{
    public function __construct(
        public readonly mixed $publicId,
        public readonly mixed $title,
        public readonly mixed $status,
        public readonly mixed $scheduledStart,
        public readonly mixed $scheduledEnd,
        public readonly mixed $timezone,
        public readonly mixed $assignedUserId,
    ) {}

    public function toArray(): array
    {
        return [
            'publicId'=>$this->publicId,
            'title'=>$this->title,
            'status'=>$this->status,
            'scheduledStart'=>$this->scheduledStart,
            'scheduledEnd'=>$this->scheduledEnd,
            'timezone'=>$this->timezone,
            'assignedUserId'=>$this->assignedUserId,
        ];
    }
}
