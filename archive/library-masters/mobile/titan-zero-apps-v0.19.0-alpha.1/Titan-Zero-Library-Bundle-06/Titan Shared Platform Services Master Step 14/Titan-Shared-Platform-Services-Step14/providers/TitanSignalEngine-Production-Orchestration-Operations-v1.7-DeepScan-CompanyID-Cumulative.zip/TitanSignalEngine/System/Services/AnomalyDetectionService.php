<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalAnomalyContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterAuthorityContract;
use App\Extensions\TitanSignalEngine\System\Data\AnomalyFinding;
use App\Extensions\TitanSignalEngine\System\Data\AnomalyDecisionAudit;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Models\SignalAnomaly;
use App\Extensions\TitanSignalEngine\System\Models\SignalDelivery;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseCausationRef;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseRollup;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseTraceEventCount;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseTraceMetric;
use App\Extensions\TitanSignalEngine\System\Models\SignalTraceEvaluation;
use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

final class AnomalyDetectionService implements SignalAnomalyContract
{
    public function __construct(
        private readonly SignalContextValidator $contextValidator,
        private readonly AnomalyRuleEvaluator $rules,
        private readonly SignalEmitterAuthorityContract $emitterAuthority,
        private readonly ?SignalEmitterContract $emitter = null,
    ) {
    }

    public function scan(SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT): array
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        if (! Schema::hasTable('titan_signal_anomalies')) {
            return [];
        }

        $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $tenantKey = $scope === SignalEnvelope::SCOPE_TENANT ? (int) $tenantCompanyId : 0;
        $findings = [];
        array_push($findings, ...$this->sourceFailureFindings($scope, $tenantKey, $now));
        array_push($findings, ...$this->scopeFindings($scope, $tenantCompanyId, $tenantKey, $now));
        array_push($findings, ...$this->loopFindings($scope, $tenantKey, $now));
        array_push($findings, ...$this->sequenceFindings($scope, $tenantKey, $now));
        array_push($findings, ...$this->integrityFindings($scope, $tenantKey, $now));

        $records = [];
        foreach ($findings as $finding) {
            [$record, $notifiable] = $this->persistFinding($finding, $scope, $tenantCompanyId, $now);
            $records[] = $this->recordArray($record);
            if ($notifiable) {
                $this->reportDetected($record);
            }
        }
        $this->resolveRecoveredTraceEvaluationAnomalies($scope, $tenantCompanyId, $tenantKey, $now);
        usort($records, static fn (array $a, array $b): int => [$b['score'], $b['last_detected_at']] <=> [$a['score'], $a['last_detected_at']]);
        return $records;
    }

    public function feed(SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 100): array
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        if (! Schema::hasTable('titan_signal_anomalies')) {
            return [];
        }
        $limit = max(1, min($limit, (int) config('titan-signal-engine.anomaly_feed_limit', 250)));
        $query = $this->scopeQuery($scope, $tenantCompanyId)
            ->whereIn('status', ['open', 'acknowledged'])
            ->orderByDesc('score')
            ->orderByDesc('last_detected_at')
            ->limit($limit);
        return $query->cursor()->map(fn (SignalAnomaly $row): array => $this->recordArray($row))->all();
    }

    public function acknowledge(string $anomalyId, string $reason, SignalContext $context): array
    {
        $reason = $this->validatedReason($reason);
        $row = DB::transaction(function () use ($anomalyId, $reason, $context): SignalAnomaly {
            $row = $this->findManageable($anomalyId, $context, true);
            if (in_array($row->status, ['resolved', 'acknowledged'], true)) return $row;

            $at = new DateTimeImmutable('now', new DateTimeZone('UTC'));
            $row->status = 'acknowledged';
            $row->acknowledged_at = $at;
            $row->acknowledged_by = $context->actor->id;
            $row->suppressed_until = null;
            $row->suppressed_by = null;
            $row->suppression_reason = null;
            $this->recordDecision($row, 'acknowledged', $reason, $context, $at);
            return $row;
        }, 3);
        return $this->recordArray($row);
    }

    public function resolve(string $anomalyId, string $reason, SignalContext $context): array
    {
        $reason = $this->validatedReason($reason);
        $row = DB::transaction(function () use ($anomalyId, $reason, $context): SignalAnomaly {
            $row = $this->findManageable($anomalyId, $context, true);
            if ($row->status === 'resolved') return $row;

            $at = new DateTimeImmutable('now', new DateTimeZone('UTC'));
            $row->status = 'resolved';
            $row->resolved_at = $at;
            $row->resolved_by = $context->actor->id;
            $row->resolution_reason = $reason;
            $row->suppressed_until = null;
            $row->suppressed_by = null;
            $row->suppression_reason = null;
            $this->recordDecision($row, 'resolved', $reason, $context, $at);
            return $row;
        }, 3);
        return $this->recordArray($row);
    }

    public function suppress(string $anomalyId, DateTimeInterface $until, string $reason, SignalContext $context): array
    {
        $reason = $this->validatedReason($reason);
        $until = new DateTimeImmutable($until->format(DATE_ATOM));
        $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        if ($until <= $now) {
            throw new InvalidArgumentException('Anomaly suppression must end in the future.');
        }
        $maxUntil = $now->modify('+' . (int) config('titan-signal-engine.anomaly_max_suppression_days', 30) . ' days');
        if ($until > $maxUntil) {
            throw new InvalidArgumentException('Anomaly suppression exceeds the configured maximum duration.');
        }
        $row = DB::transaction(function () use ($anomalyId, $until, $reason, $context, $now): SignalAnomaly {
            $row = $this->findManageable($anomalyId, $context, true);
            if ($row->status === 'suppressed' && $row->suppressed_until?->format(DATE_ATOM) === $until->format(DATE_ATOM) && $row->suppression_reason === $reason) return $row;

            $row->status = 'suppressed';
            $row->suppressed_until = $until;
            $row->suppressed_by = $context->actor->id;
            $row->suppression_reason = $reason;
            $this->recordDecision($row, 'suppressed', $reason, $context, $now, $until);
            return $row;
        }, 3);
        return $this->recordArray($row);
    }

    /** @return list<AnomalyFinding> */
    private function sourceFailureFindings(string $scope, int $tenantKey, DateTimeImmutable $now): array
    {
        if (! Schema::hasTable('titan_signal_pulse_rollups')) return [];
        $rows = SignalPulseRollup::query()->where('scope', $scope)->where('tenant_key', $tenantKey)->where('granularity', 'minute')->where('dimension', 'source')
            ->whereBetween('bucket_start', [$now->modify('-5 minutes'), $now])
            ->selectRaw('dimension_value, SUM(error_count) as error_count')->groupBy('dimension_value')
            ->havingRaw('SUM(error_count) >= ?', [(int) config('titan-signal-engine.anomaly_repeated_failure_count_5m', 5)])->limit(100)->cursor();
        $result = [];
        foreach ($rows as $row) {
            array_push($result, ...$this->rules->evaluate(['source' => (string) $row->dimension_value, 'error_count_5m' => (int) $row->error_count]));
        }
        return $result;
    }

    /** @return list<AnomalyFinding> */
    private function scopeFindings(string $scope, ?int $tenantCompanyId, int $tenantKey, DateTimeImmutable $now): array
    {
        $retryWait = 0;
        $deadLetters = 0;
        if (Schema::hasTable('titan_signal_deliveries')) {
            $delivery = SignalDelivery::query()->where('scope', $scope);
            $scope === SignalEnvelope::SCOPE_TENANT ? $delivery->where('tenant_company_id', $tenantCompanyId) : $delivery->whereNull('tenant_company_id');
            $retryWait = (clone $delivery)->where('status', 'retry_wait')->count();
            $deadLetters = (clone $delivery)->where('status', 'dead_letter')->where('dead_lettered_at', '>=', $now->modify('-1 hour'))->count();
        }

        $stalled = 0;
        $missingReceipt = 0;
        if (Schema::hasTable('titan_signal_pulse_trace_metrics')) {
            $base = fn (): Builder => SignalPulseTraceMetric::query()->where('scope', $scope)->where('tenant_key', $tenantKey);
            $stallAfter = $now->modify('-' . (int) config('titan-signal-engine.pulse_stalled_after_seconds', 3600) . ' seconds');
            $receiptAfter = $now->modify('-' . (int) config('titan-signal-engine.pulse_missing_receipt_after_seconds', 300) . ' seconds');
            $horizon = $now->modify('-' . (int) config('titan-signal-engine.pulse_stall_horizon_seconds', 604800) . ' seconds');
            $watched = (array) config('titan-signal-engine.pulse_stall_watch_event_types', ['command.requested', 'risk.assessed', 'command.authorized', 'command.executed']);
            $stalled = $base()->where('terminal_seen', false)->whereIn('last_event_type', $watched)->whereBetween('last_occurred_at', [$horizon, $stallAfter])->count();
            $missingReceipt = $base()->whereNotNull('command_executed_at')->whereNull('execution_receipt_at')->whereBetween('command_executed_at', [$horizon, $receiptAfter])->count();
        }

        $overrides = 0;
        $current5m = 0;
        $baselineReady = false;
        $baselinePer5m = 0.0;
        if (Schema::hasTable('titan_signal_pulse_rollups')) {
            $overrideTypes = (array) config('titan-signal-engine.anomaly_override_event_types', []);
            if ($overrideTypes !== []) {
                $overrides = (int) SignalPulseRollup::query()->where('scope', $scope)->where('tenant_key', $tenantKey)->where('granularity', 'minute')->where('dimension', 'event_type')
                    ->whereIn('dimension_value', $overrideTypes)->whereBetween('bucket_start', [$now->modify('-1 hour'), $now])->sum('event_count');
            }
            $baseAll = fn (): Builder => SignalPulseRollup::query()->where('scope', $scope)->where('tenant_key', $tenantKey)->where('granularity', 'minute')->where('dimension', 'all')->where('dimension_value', '__all__');
            $current5m = (int) $baseAll()->whereBetween('bucket_start', [$now->modify('-5 minutes'), $now])->sum('event_count');
            $earliest = $baseAll()->min('bucket_start');
            $baselineAge = max(3600, (int) config('titan-signal-engine.anomaly_baseline_min_age_seconds', 86400));
            $baselineStart = $now->modify('-' . $baselineAge . ' seconds');
            $baselineEnd = $now->modify('-5 minutes');
            if ($earliest !== null && new DateTimeImmutable((string) $earliest) <= $baselineStart) {
                $baselineTotal = (int) $baseAll()->whereBetween('bucket_start', [$baselineStart, $baselineEnd])->sum('event_count');
                $baselineReady = true;
                $baselineWindows = max(1.0, ($baselineAge - 300) / 300.0);
                $baselinePer5m = $baselineTotal / $baselineWindows;
            }
        }

        return $this->rules->evaluate([
            'scope_subject' => $scope === SignalEnvelope::SCOPE_TENANT ? 'tenant:' . $tenantKey : 'system',
            'retry_wait_count' => $retryWait,
            'dead_letter_count' => $deadLetters,
            'stalled_trace_count' => $stalled,
            'missing_receipt_count' => $missingReceipt,
            'override_count_1h' => $overrides,
            'baseline_ready' => $baselineReady,
            'baseline_events_per_5m' => $baselinePer5m,
            'events_last_5m' => $current5m,
        ]);
    }

    /** @return list<AnomalyFinding> */
    private function loopFindings(string $scope, int $tenantKey, DateTimeImmutable $now): array
    {
        if (! Schema::hasTable('titan_signal_pulse_trace_event_counts')) return [];
        $threshold = (int) config('titan-signal-engine.anomaly_execution_loop_count', 10);
        $rows = SignalPulseTraceEventCount::query()->where('scope', $scope)->where('tenant_key', $tenantKey)->where('event_count', '>=', $threshold)
            ->where('last_occurred_at', '>=', $now->modify('-1 hour'))->orderByDesc('event_count')->limit((int) config('titan-signal-engine.anomaly_scan_subject_limit', 250))->cursor();
        $result = [];
        foreach ($rows as $row) {
            array_push($result, ...$this->rules->evaluate(['trace_id' => (string) $row->trace_id, 'event_type' => (string) $row->event_type, 'loop_event_count' => (int) $row->event_count]));
        }
        return $result;
    }

    /** @return list<AnomalyFinding> */
    private function sequenceFindings(string $scope, int $tenantKey, DateTimeImmutable $now): array
    {
        if (! Schema::hasTable('titan_signal_trace_evaluations')) return [];
        $cutoff = $now->modify('-1 hour');
        $rows = SignalTraceEvaluation::query()
            ->where('scope', $scope)
            ->where('tenant_key', $tenantKey)
            ->where(function (Builder $query) use ($now, $cutoff): void {
                $query->where('fresh_until', '>=', $now)
                    ->orWhere(function (Builder $legacy) use ($cutoff): void {
                        $legacy->whereNull('fresh_until')->where('evaluated_at', '>=', $cutoff);
                    });
            })
            ->where(function (Builder $query): void {
                $query->where('sequence_violation_count', '>', 0)
                    ->orWhere(function (Builder $missing): void {
                        $missing->where('terminal_seen', true)->where('missing_event_count', '>', 0);
                    });
            })
            ->orderByDesc('sequence_violation_count')
            ->limit((int) config('titan-signal-engine.anomaly_scan_subject_limit', 250))
            ->cursor();
        $byTrace = [];
        foreach ($rows as $row) {
            $traceId = (string) $row->trace_id;
            $byTrace[$traceId] ??= ['sequence' => 0, 'missing' => 0];
            $byTrace[$traceId]['sequence'] = max($byTrace[$traceId]['sequence'], (int) $row->sequence_violation_count);
            if ((bool) $row->terminal_seen) {
                $byTrace[$traceId]['missing'] = max($byTrace[$traceId]['missing'], (int) $row->missing_event_count);
            }
        }
        $result = [];
        foreach ($byTrace as $traceId => $state) {
            array_push($result, ...$this->rules->evaluate([
                'trace_id' => $traceId,
                'sequence_violation_count' => $state['sequence'],
                'missing_required_event_count' => $state['missing'],
            ]));
        }
        return $result;
    }

    private function resolveRecoveredTraceEvaluationAnomalies(string $scope, ?int $tenantCompanyId, int $tenantKey, DateTimeImmutable $now): void
    {
        if (! Schema::hasTable('titan_signal_trace_evaluations') || ! Schema::hasTable('titan_signal_anomalies')) return;
        $limit = max(1, min((int) config('titan-signal-engine.anomaly_scan_subject_limit', 250) * 4, 2000));
        $rows = SignalTraceEvaluation::query()
            ->where('scope', $scope)
            ->where('tenant_key', $tenantKey)
            ->where('fresh_until', '>=', $now)
            ->orderByDesc('evaluated_at')
            ->limit($limit)
            ->get(['trace_id', 'sequence_violation_count', 'missing_event_count', 'terminal_seen']);

        $byTrace = [];
        foreach ($rows as $row) {
            $traceId = (string) $row->trace_id;
            $byTrace[$traceId] ??= ['sequence' => 0, 'missing' => 0, 'terminal' => false];
            $byTrace[$traceId]['sequence'] = max($byTrace[$traceId]['sequence'], (int) $row->sequence_violation_count);
            if ((bool) $row->terminal_seen) {
                $byTrace[$traceId]['terminal'] = true;
                $byTrace[$traceId]['missing'] = max($byTrace[$traceId]['missing'], (int) $row->missing_event_count);
            }
        }

        foreach ($byTrace as $traceId => $state) {
            if ($state['sequence'] === 0) $this->resolveAutoAnomaly($scope, $tenantCompanyId, 'sequence_violation', $traceId, $now);
            if ($state['terminal'] && $state['missing'] === 0) $this->resolveAutoAnomaly($scope, $tenantCompanyId, 'required_event_missing', $traceId, $now);
        }
    }

    private function resolveAutoAnomaly(string $scope, ?int $tenantCompanyId, string $type, string $traceId, DateTimeImmutable $now): void
    {
        $key = hash('sha256', implode('|', [$scope, (string) ($tenantCompanyId ?? 'system'), $type, 'trace', $traceId]));
        DB::transaction(function () use ($key, $now): void {
            /** @var SignalAnomaly|null $row */
            $row = SignalAnomaly::query()
                ->where('deduplication_key', $key)
                ->whereIn('status', ['open', 'acknowledged', 'suppressed'])
                ->lockForUpdate()
                ->first();
            if ($row === null) return;

            $context = $this->automaticDecisionContext('titan-signal-trace-evaluator');
            $row->status = 'resolved';
            $row->resolved_at = $now;
            $row->resolved_by = $context->actor->id;
            $row->resolution_reason = 'trace_evaluation_recovered';
            $row->suppressed_until = null;
            $row->suppressed_by = null;
            $row->suppression_reason = null;
            $this->recordDecision($row, 'resolved', 'trace_evaluation_recovered', $context, $now);
        }, 3);
    }

    /** @return list<AnomalyFinding> */
    private function integrityFindings(string $scope, int $tenantKey, DateTimeImmutable $now): array
    {
        if (! Schema::hasTable('titan_signal_pulse_causation_refs')) return [];
        $this->refreshCausationResolutions($scope, $tenantKey);
        $grace = max(60, (int) config('titan-signal-engine.anomaly_missing_parent_grace_seconds', 300));
        $rows = SignalPulseCausationRef::query()->where('scope', $scope)->where('tenant_key', $tenantKey)->where('resolved', false)
            ->where('occurred_at', '<=', $now->modify('-' . $grace . ' seconds'))
            ->selectRaw('trace_id, COUNT(*) as unresolved_count')->groupBy('trace_id')->orderByDesc('unresolved_count')->limit((int) config('titan-signal-engine.anomaly_scan_subject_limit', 250))->cursor();
        $result = [];
        foreach ($rows as $row) {
            array_push($result, ...$this->rules->evaluate(['trace_id' => (string) $row->trace_id, 'unresolved_causation_count' => (int) $row->unresolved_count]));
        }
        return $result;
    }

    private function refreshCausationResolutions(string $scope, int $tenantKey): void
    {
        if (! Schema::hasTable('titan_signal_causal_edges')) return;
        $rows = SignalPulseCausationRef::query()->where('scope', $scope)->where('tenant_key', $tenantKey)->where('resolved', false)->limit(500)->cursor();
        foreach ($rows as $row) {
            $resolved = DB::table('titan_signal_causal_edges')->where('child_event_id', $row->child_event_id)->where('parent_event_id', $row->parent_event_id)->exists();
            if ($resolved) {
                $row->resolved = true;
                $row->resolved_at = now();
                $row->save();
            }
        }
    }

    /** @return array{0:SignalAnomaly,1:bool} */
    private function persistFinding(AnomalyFinding $finding, string $scope, ?int $tenantCompanyId, DateTimeImmutable $now): array
    {
        $key = $finding->deduplicationKey($scope, $tenantCompanyId);
        return DB::transaction(function () use ($finding, $scope, $tenantCompanyId, $now, $key): array {
            /** @var SignalAnomaly|null $row */
            $row = SignalAnomaly::query()->where('deduplication_key', $key)->lockForUpdate()->first();
            $notifiable = false;
            if ($row === null) {
                $row = SignalAnomaly::query()->create([
                    'anomaly_id' => self::uuid7(),
                    'deduplication_key' => $key,
                    'scope' => $scope,
                    'tenant_company_id' => $tenantCompanyId,
                    'tenant_key' => (int) ($tenantCompanyId ?? 0),
                    'anomaly_type' => $finding->type,
                    'severity' => $finding->severity,
                    'score' => $finding->score,
                    'confidence' => $finding->confidence,
                    'subject_type' => $finding->subjectType,
                    'subject_id' => $finding->subjectId,
                    'status' => 'open',
                    'evidence' => $finding->evidence,
                    'occurrence_count' => 1,
                    'first_detected_at' => $now,
                    'last_detected_at' => $now,
                ]);
                $notifiable = true;
            } else {
                $wasResolved = $row->status === 'resolved';
                $suppressionActive = $row->status === 'suppressed' && $row->suppressed_until !== null && $row->suppressed_until > $now;
                $row->severity = $finding->severity;
                $row->score = $finding->score;
                $row->confidence = $finding->confidence;
                $row->evidence = $finding->evidence;
                $row->occurrence_count++;
                $row->last_detected_at = $now;
                if ($wasResolved || ($row->status === 'suppressed' && ! $suppressionActive)) {
                    $row->status = 'open';
                    $row->reopened_at = $now;
                    $row->resolved_at = null;
                    $row->resolved_by = null;
                    $row->resolution_reason = null;
                    $row->suppressed_until = null;
                    $row->suppressed_by = null;
                    $row->suppression_reason = null;
                    $reason = $wasResolved ? 'condition_recurred' : 'suppression_expired_condition_recurred';
                    $this->recordDecision($row, 'reopened', $reason, $this->automaticDecisionContext('titan-signal-anomaly-engine'), $now);
                    $notifiable = true;
                } else {
                    $row->save();
                }
            }
            return [$row, $notifiable];
        });
    }

    private function reportDetected(SignalAnomaly $row): void
    {
        if ($this->emitter === null) return;
        try {
            $permissions = ['signal.system.read', 'signal.tenant.read', 'signal.tenant.emit'];
            $context = SignalContext::system(
                'titan-signal-anomaly-engine',
                'system',
                $permissions,
                $this->emitterAuthority->issue('titan-signal-engine:anomaly-engine'),
            );
            $this->emitter->emit([
                'event_type' => 'signal.anomaly.detected',
                'scope' => (string) $row->scope,
                'tenant_company_id' => $row->tenant_company_id,
                'source' => 'titan-signal-engine',
                'source_component' => 'anomaly-engine',
                'schema_version' => 1,
                'severity' => 'info',
                'category' => 'operations',
                'payload' => [
                    'anomaly_id' => (string) $row->anomaly_id,
                    'anomaly_type' => (string) $row->anomaly_type,
                    'severity' => (string) $row->severity,
                    'score' => (int) $row->score,
                    'confidence' => (float) $row->confidence,
                    'subject_type' => (string) $row->subject_type,
                    'subject_id' => (string) $row->subject_id,
                ],
                'metadata' => ['detector' => 'rule-based-v1'],
                'idempotency_key' => 'anomaly-detected:' . $row->anomaly_id . ':' . ($row->reopened_at?->format('U') ?? 'initial'),
            ], $context);
        } catch (Throwable) {
            // The anomaly read model remains authoritative even if notification emission is unavailable.
        }
    }

    private function findManageable(string $anomalyId, SignalContext $context, bool $lock = false): SignalAnomaly
    {
        if (! $context->hasPermission('signal.anomaly.manage')) {
            throw new InvalidArgumentException('Anomaly lifecycle mutations require signal.anomaly.manage permission.');
        }
        /** @var SignalAnomaly|null $row */
        $query = SignalAnomaly::query()->where('anomaly_id', $anomalyId);
        if ($lock) $query->lockForUpdate();
        $row = $query->first();
        if ($row === null) throw new InvalidArgumentException('Unknown Signal anomaly.');
        $this->contextValidator->assertQueryAllowed((string) $row->scope, $row->tenant_company_id === null ? null : (int) $row->tenant_company_id, $context);
        return $row;
    }

    private function recordDecision(
        SignalAnomaly $row,
        string $action,
        string $reason,
        SignalContext $actorContext,
        DateTimeImmutable $at,
        ?DateTimeInterface $suppressionUntil = null,
    ): void {
        if ($this->emitter === null) {
            throw new RuntimeException('Immutable anomaly lifecycle audit requires SignalEmitterContract.');
        }

        $row->decision_version = ((int) ($row->decision_version ?? 0)) + 1;
        $row->last_decision_at = $at;
        $row->save();

        $decision = AnomalyDecisionAudit::make(
            action: $action,
            anomalyId: (string) $row->anomaly_id,
            anomalyType: (string) $row->anomaly_type,
            subjectType: (string) $row->subject_type,
            subjectId: (string) $row->subject_id,
            reason: $reason,
            actorId: $actorContext->actor->id,
            actorType: $actorContext->actor->type,
            decisionVersion: (int) $row->decision_version,
            decidedAt: $at,
            suppressionUntil: $suppressionUntil,
            evidenceReference: AnomalyDecisionAudit::evidenceReference((array) $row->evidence),
        );

        $auditContext = $this->auditEmissionContext($actorContext);
        $receipt = $this->emitter->emit([
            'event_type' => $decision->eventType,
            'scope' => (string) $row->scope,
            'tenant_company_id' => $row->tenant_company_id,
            'schema_version' => 1,
            'severity' => 'info',
            'category' => 'operations',
            'occurred_at' => $at->format(DATE_ATOM),
            'payload' => $decision->payload,
            'metadata' => ['audit' => 'anomaly-lifecycle-v1'],
            'idempotency_key' => $decision->idempotencyKey,
        ], $auditContext);

        $row->last_decision_event_id = $receipt->eventId;
        $row->save();
    }

    private function auditEmissionContext(SignalContext $actorContext): SignalContext
    {
        $permissions = $actorContext->permissions;
        if ($actorContext->scope === SignalEnvelope::SCOPE_SYSTEM && ! in_array('signal.tenant.emit', $permissions, true)) {
            $permissions[] = 'signal.tenant.emit';
        }
        return new SignalContext(
            $actorContext->scope,
            $actorContext->tenantCompanyId,
            $actorContext->actor,
            array_values(array_unique($permissions)),
            $this->emitterAuthority->issue('titan-signal-engine:anomaly-engine'),
        );
    }

    private function automaticDecisionContext(string $actorId): SignalContext
    {
        return SignalContext::system(
            $actorId,
            'system',
            ['signal.system.read', 'signal.tenant.read', 'signal.tenant.emit', 'signal.anomaly.manage'],
            $this->emitterAuthority->issue('titan-signal-engine:anomaly-engine'),
        );
    }

    private function scopeQuery(string $scope, ?int $tenantCompanyId): Builder
    {
        $query = SignalAnomaly::query()->where('scope', $scope);
        return $scope === SignalEnvelope::SCOPE_TENANT ? $query->where('tenant_company_id', $tenantCompanyId) : $query->whereNull('tenant_company_id');
    }

    private function validatedReason(string $reason): string
    {
        $reason = trim($reason);
        if ($reason === '' || strlen($reason) > 255) throw new InvalidArgumentException('Anomaly lifecycle reason must be 1-255 characters.');
        return $reason;
    }

    /** @return array<string,mixed> */
    private function recordArray(SignalAnomaly $row): array
    {
        return [
            'anomaly_id' => (string) $row->anomaly_id,
            'type' => (string) $row->anomaly_type,
            'severity' => (string) $row->severity,
            'score' => (int) $row->score,
            'confidence' => (float) $row->confidence,
            'subject_type' => (string) $row->subject_type,
            'subject_id' => (string) $row->subject_id,
            'status' => (string) $row->status,
            'evidence' => (array) $row->evidence,
            'occurrence_count' => (int) $row->occurrence_count,
            'decision_version' => (int) ($row->decision_version ?? 0),
            'last_decision_event_id' => $row->last_decision_event_id === null ? null : (string) $row->last_decision_event_id,
            'last_decision_at' => $row->last_decision_at?->format(DATE_ATOM),
            'first_detected_at' => $row->first_detected_at?->format(DATE_ATOM),
            'last_detected_at' => $row->last_detected_at?->format(DATE_ATOM),
            'suppressed_until' => $row->suppressed_until?->format(DATE_ATOM),
            'resolved_at' => $row->resolved_at?->format(DATE_ATOM),
        ];
    }

    private static function uuid7(): string
    {
        $milliseconds = (int) floor(microtime(true) * 1000);
        $hex = str_pad(dechex($milliseconds), 12, '0', STR_PAD_LEFT) . bin2hex(random_bytes(10));
        $hex[12] = '7';
        $hex[16] = dechex((hexdec($hex[16]) & 0x3) | 0x8);
        return sprintf('%s-%s-%s-%s-%s', substr($hex, 0, 8), substr($hex, 8, 4), substr($hex, 12, 4), substr($hex, 16, 4), substr($hex, 20, 12));
    }
}
