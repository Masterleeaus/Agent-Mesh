<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Services;

final class CommandLifecycleState
{
    public const RECEIVED = 'RECEIVED';
    public const PREFLIGHT = 'PREFLIGHT';
    public const GOVERNED = 'GOVERNED';
    public const AUTHORIZED = 'AUTHORIZED';
    public const EXECUTING = 'EXECUTING';
    public const COMPLETED = 'COMPLETED';
    public const REFUSED = 'REFUSED';
    public const FAILED = 'FAILED';
    public const REPLAYED = 'REPLAYED';

    /** @return list<string> */
    public static function terminal(): array
    {
        return [self::COMPLETED, self::REFUSED, self::FAILED];
    }
}
