<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalArchiveStoreContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalArchiveCatalogContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalHistoryQueryContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEventStoreContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalLifecycleContract;
use App\Extensions\TitanSignalEngine\System\Data\RetentionClass;
use App\Extensions\TitanSignalEngine\System\Data\SignalArchiveEntry;
use App\Extensions\TitanSignalEngine\System\Data\RetentionPolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalRedactionOverlay;
use App\Extensions\TitanSignalEngine\System\Data\SignalPrunePreviewToken;
use App\Extensions\TitanSignalEngine\System\Exceptions\SignalIntegrityException;
use App\Extensions\TitanSignalEngine\System\Models\SignalArchiveBatch;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use App\Extensions\TitanSignalEngine\System\Models\SignalEventLifecycle;
use App\Extensions\TitanSignalEngine\System\Models\SignalEventOverlay;
use App\Extensions\TitanSignalEngine\System\Models\SignalLifecycleAudit;
use App\Extensions\TitanSignalEngine\System\Models\SignalPrunePreview;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use InvalidArgumentException;

final class SignalLifecycleService implements SignalLifecycleContract
{
    public function __construct(
        private readonly SignalEventStoreContract $store,
        private readonly SignalContextValidator $contextValidator,
        private readonly SignalArchiveStoreContract $archiveStore,
        private readonly SignalArchiveCatalogContract $archiveCatalog,
        private readonly SignalHistoryQueryContract $historyQuery,
        private readonly PruneCandidateHasher $candidateHasher,
    ) {
    }

    public function redact(string $eventId, array $operations, string $reason, SignalContext $context): array
    {
        return $this->createOverlay('redaction', $eventId, $operations, $reason, $context);
    }

    public function correct(string $eventId, array $operations, string $reason, SignalContext $context): array
    {
        return $this->createOverlay('correction', $eventId, $operations, $reason, $context);
    }

    public function view(string $eventId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT): ?array
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        $event = $this->store->find($eventId, $tenantCompanyId, $scope);
        if ($event === null) {
            $history = $this->historyQuery->find($eventId, $context, $tenantCompanyId, $scope);
            if ($history === null) return null;
            return [
                'event' => $history->event,
                'projection' => [
                    'storage_tier' => $history->storageTier,
                    'archive_verified' => $history->archiveVerified,
                    'canonical_checksum_verified' => $history->canonicalChecksumVerified,
                    'redacted_or_corrected' => $history->archive?->privacyProjected ?? false,
                    'original_checksum' => $history->archive?->originalChecksum,
                ],
                'archive' => $history->archive?->toArray(),
            ];
        }
        $envelope = SignalEnvelope::fromPersistenceArray(array_replace($event->getAttributes(), ['payload' => $event->payload ?? [], 'metadata' => $event->metadata ?? []]));
        if (! $envelope->verifyChecksum()) {
            throw new SignalIntegrityException("Signal checksum verification failed for event {$eventId}.");
        }
        $projected = $envelope->toArray();
        $overlayCount = 0;
        foreach (SignalEventOverlay::query()->where('event_id', $eventId)->orderBy('id')->cursor() as $overlayRow) {
            $overlay = new SignalRedactionOverlay((array) $overlayRow->operations);
            $projected = $overlay->apply($projected);
            $overlayCount++;
        }
        return [
            'event' => $projected,
            'projection' => [
                'overlay_count' => $overlayCount,
                'redacted_or_corrected' => $overlayCount > 0,
                'original_checksum' => $envelope->checksum,
                'original_checksum_alg' => $envelope->checksumAlgorithm,
            ],
        ];
    }

    public function setLegalHold(string $eventId, bool $hold, string $reason, SignalContext $context): array
    {
        $this->assertManage($context, 'signal.retention.manage');
        if (trim($reason) === '') throw new InvalidArgumentException('Legal hold changes require a reason.');
        /** @var SignalEventLifecycle|null $row */
        $row = SignalEventLifecycle::query()->where('event_id', $eventId)->first();
        if ($row === null) throw new InvalidArgumentException('Unknown Signal lifecycle event.');
        $this->contextValidator->assertQueryAllowed((string) $row->scope, $row->tenant_company_id === null ? null : (int) $row->tenant_company_id, $context);
        $row->legal_hold = $hold;
        $row->legal_hold_at = $hold ? now() : null;
        $row->legal_hold_by = $hold ? $context->actor->id : null;
        $row->legal_hold_reason = $hold ? $reason : null;
        $row->save();
        $this->audit($context, $hold ? 'legal_hold.applied' : 'legal_hold.released', $eventId, null, $reason, ['hold' => $hold]);
        return ['event_id' => $eventId, 'legal_hold' => $hold];
    }

    public function previewPrune(?int $tenantCompanyId, string $scope, int $limit, SignalContext $context): array
    {
        $this->assertManage($context, 'signal.retention.manage');
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        $rows = $this->pruneCandidates($tenantCompanyId, $scope, $limit);
        $byClass = [];
        $archiveRequired = 0;
        foreach ($rows as $row) {
            $byClass[$row->retention_class] = ($byClass[$row->retention_class] ?? 0) + 1;
            try {
                if (RetentionPolicy::for(RetentionClass::from((string) $row->retention_class))->archiveRequired) $archiveRequired++;
            } catch (\ValueError) {}
        }
        $eventIds = array_map(static fn (SignalEventLifecycle $row): string => (string) $row->event_id, $rows);
        $previewId = self::uuid7();
        $token = SignalPrunePreviewToken::issue($previewId);
        $ttl = max(60, (int) config('titan-signal-engine.prune_preview_ttl_seconds', 900));
        $expiresAt = now()->addSeconds($ttl);
        $candidateHash = $this->candidateHasher->hash($scope, $tenantCompanyId, $eventIds);
        SignalPrunePreview::query()->create([
            'preview_id' => $previewId,
            'scope' => $scope,
            'tenant_company_id' => $tenantCompanyId,
            'tenant_key' => (int) ($tenantCompanyId ?? 0),
            'status' => 'previewed',
            'token_hash' => $token->hash,
            'candidate_hash' => $candidateHash,
            'candidate_count' => count($eventIds),
            'event_ids' => $eventIds,
            'by_retention_class' => $byClass,
            'created_by' => $context->actor->id,
            'expires_at' => $expiresAt,
        ]);
        $this->audit($context, 'prune.previewed', null, null, 'prune_preview', [
            'preview_id' => $previewId,
            'candidate_hash' => $candidateHash,
            'candidate_count' => count($eventIds),
            'archive_required_count' => $archiveRequired,
        ]);
        return [
            'dry_run' => true,
            'preview_id' => $previewId,
            'preview_token' => $token->plainText,
            'expires_at' => $expiresAt->toAtomString(),
            'candidate_hash' => $candidateHash,
            'candidate_count' => count($eventIds),
            'event_ids' => $eventIds,
            'by_retention_class' => $byClass,
            'archive_required_count' => $archiveRequired,
            'no_archive_required_count' => count($eventIds) - $archiveRequired,
        ];
    }

    public function prune(string $previewToken, string $reason, SignalContext $context): array
    {
        $this->assertManage($context, 'signal.retention.manage');
        if (trim($reason) === '') throw new InvalidArgumentException('Signal pruning requires a reason.');
        $previewId = SignalPrunePreviewToken::previewIdFrom($previewToken);
        $claimToken = hash('sha256', 'titan-signal-prune-claim|' . $previewId);
        $claimTtl = max(900, (int) config('titan-signal-engine.prune_claim_ttl_seconds', 21600));
        $executionToken = hash('sha256', $previewId . '|' . bin2hex(random_bytes(24)));
        $executionTtl = max(300, (int) config('titan-signal-engine.prune_execution_ttl_seconds', 3600));

        /** @var SignalPrunePreview $preview */
        $preview = DB::transaction(function () use ($previewId, $previewToken, $claimToken, $claimTtl, $executionToken, $executionTtl, $context): SignalPrunePreview {
            /** @var SignalPrunePreview|null $row */
            $row = SignalPrunePreview::query()->where('preview_id', $previewId)->lockForUpdate()->first();
            if ($row === null || ! hash_equals((string) $row->token_hash, hash('sha256', $previewToken))) {
                throw new InvalidArgumentException('Signal prune preview token is invalid.');
            }
            $this->contextValidator->assertQueryAllowed((string) $row->scope, $row->tenant_company_id === null ? null : (int) $row->tenant_company_id, $context);
            if ((string) $row->status === 'completed') return $row;
            if (in_array((string) $row->status, ['invalidated', 'cancelled'], true)) throw new InvalidArgumentException('Signal prune preview is no longer valid.');
            if ($row->execution_token !== null && $row->execution_expires_at !== null && $row->execution_expires_at->isFuture()) {
                throw new InvalidArgumentException('Signal prune preview is already being executed by another worker.');
            }
            if (in_array((string) $row->status, ['previewed', 'failed_retryable'], true) && $row->expires_at !== null && $row->expires_at->isPast()) {
                $row->status = 'invalidated';
                $row->invalidated_at = now();
                $row->invalid_reason = 'preview_expired';
                $row->save();
                return $row;
            }

            $eventIds = array_values(array_map('strval', (array) $row->event_ids));
            if (count($eventIds) !== (int) $row->candidate_count
                || ! hash_equals((string) $row->candidate_hash, $this->candidateHasher->hash((string) $row->scope, $row->tenant_company_id === null ? null : (int) $row->tenant_company_id, $eventIds))) {
                throw new SignalIntegrityException('Signal prune preview candidate manifest is corrupt.');
            }
            if ($eventIds === []) {
                $row->status = 'completed';
                $row->completed_at = now();
                $row->save();
                return $row;
            }

            $lifecycle = SignalEventLifecycle::query()->whereIn('event_id', $eventIds)->limit(count($eventIds))->lockForUpdate()->get();
            if ($lifecycle->count() !== count($eventIds)) return $this->invalidatePreview($row, 'candidate_metadata_changed', $claimToken);
            $now = now();
            foreach ($lifecycle as $candidate) {
                $tenantMatches = (string) $candidate->scope === (string) $row->scope
                    && (($candidate->tenant_company_id === null ? null : (int) $candidate->tenant_company_id) === ($row->tenant_company_id === null ? null : (int) $row->tenant_company_id));
                $claimAvailable = $candidate->prune_claim_token === null
                    || hash_equals((string) $candidate->prune_claim_token, $claimToken)
                    || ($candidate->prune_claim_expires_at !== null && $candidate->prune_claim_expires_at->lte($now));
                $prunable = false;
                try { $prunable = RetentionPolicy::for(RetentionClass::from((string) $candidate->retention_class))->prunable; } catch (\ValueError) {}
                if (! $tenantMatches || $candidate->pruned_at !== null || (bool) $candidate->legal_hold || $candidate->retain_until === null || $candidate->retain_until->gt($now) || ! $prunable || ! $claimAvailable) {
                    return $this->invalidatePreview($row, 'candidate_set_changed', $claimToken);
                }
            }
            SignalEventLifecycle::query()->whereIn('event_id', $eventIds)->update([
                'prune_claim_token' => $claimToken,
                'prune_claimed_at' => $now,
                'prune_claim_expires_at' => $now->copy()->addSeconds($claimTtl),
                'updated_at' => $now,
            ]);
            $row->status = 'claimed';
            $row->claimed_at = $now;
            $row->execution_token = $executionToken;
            $row->execution_started_at = $now;
            $row->execution_expires_at = $now->copy()->addSeconds($executionTtl);
            $row->save();
            return $row->fresh();
        });

        if ((string) $preview->status === 'completed') {
            $batch = $preview->archive_batch_id === null ? null : SignalArchiveBatch::query()->where('batch_id', $preview->archive_batch_id)->first();
            return ['pruned' => (int) $preview->candidate_count, 'archived' => (int) ($batch?->archive_event_count ?? 0), 'preview_id' => $previewId, 'batch_id' => $batch?->batch_id, 'status' => 'completed'];
        }
        if ((string) $preview->status === 'invalidated') throw new InvalidArgumentException('Signal prune preview is invalid or expired; create a new preview.');

        $eventIds = array_values(array_map('strval', (array) $preview->event_ids));
        $lifecycleRows = SignalEventLifecycle::query()->whereIn('event_id', $eventIds)->orderBy('id')->limit(count($eventIds))->get();
        $archiveIds = [];
        $noArchiveIds = [];
        foreach ($lifecycleRows as $row) {
            $policy = RetentionPolicy::for(RetentionClass::from((string) $row->retention_class));
            if ($policy->archiveRequired) $archiveIds[] = (string) $row->event_id;
            else $noArchiveIds[] = (string) $row->event_id;
        }
        if (SignalEvent::query()->whereIn('event_id', $eventIds)->count() !== count($eventIds)) {
            $this->markPreviewRetryable($previewId, $claimToken, 'immutable_event_set_changed');
            throw new SignalIntegrityException('Signal prune approved set no longer matches the immutable event store.');
        }

        $batch = SignalArchiveBatch::query()->where('preview_id', $previewId)->first();
        if ($batch === null) {
            $batchId = self::uuid7();
            $criteria = [
                'preview_id' => $previewId,
                'scope' => (string) $preview->scope,
                'tenant_company_id' => $preview->tenant_company_id,
                'candidate_hash' => (string) $preview->candidate_hash,
                'prune_event_ids' => $eventIds,
                'archive_event_ids' => $archiveIds,
                'non_archive_event_ids' => $noArchiveIds,
            ];
            $batch = SignalArchiveBatch::query()->create([
                'batch_id' => $batchId,
                'preview_id' => $previewId,
                'scope' => (string) $preview->scope,
                'tenant_company_id' => $preview->tenant_company_id,
                'tenant_key' => (int) ($preview->tenant_company_id ?? 0),
                'status' => 'preparing',
                'archive_driver' => $archiveIds === [] ? 'none' : 'pending',
                'event_count' => count($archiveIds),
                'prune_event_count' => count($eventIds),
                'archive_event_count' => count($archiveIds),
                'criteria' => $criteria,
            ]);
            SignalPrunePreview::query()->where('preview_id', $previewId)->update(['archive_batch_id' => $batchId, 'updated_at' => now()]);
        }

        $catalogEntries = [];
        $archive = null;
        try {
            if ($archiveIds !== [] && ! in_array((string) $batch->status, ['verified_unpruned', 'pruned'], true)) {
                $batch->status = 'archiving';
                $batch->failure_code = null;
                $batch->save();
                $events = $this->archiveEventStream($archiveIds);
                $archive = $this->archiveStore->archiveStream((string) $batch->batch_id, $events, count($archiveIds), (array) $batch->criteria);
                if (! $this->archiveStore->verify($archive['locator'], $archive['checksum'], $archive['driver'])) throw new SignalIntegrityException('Signal archive verification failed; pruning aborted.');
                $batch->archive_driver = $archive['driver'];
                $batch->archive_locator = $archive['locator'];
                $batch->archive_checksum = $archive['checksum'];
                $batch->event_count = $archive['event_count'];
                $batch->archive_event_count = $archive['event_count'];
                $batch->archived_at = now();
                $batch->verified_at = now();
                $batch->status = 'verified_unpruned';
                $batch->save();
            } elseif ($archiveIds === [] && ! in_array((string) $batch->status, ['verified_unpruned_no_archive', 'pruned'], true)) {
                $batch->status = 'verified_unpruned_no_archive';
                $batch->archive_driver = 'none';
                $batch->archive_event_count = 0;
                $batch->event_count = 0;
                $batch->verified_at = now();
                $batch->save();
            }

            $batch->refresh();
            if ((string) $batch->status === 'verified_unpruned' && ($batch->archive_locator === null || $batch->archive_checksum === null || ! $this->archiveStore->verify((string) $batch->archive_locator, (string) $batch->archive_checksum, (string) $batch->archive_driver))) {
                throw new SignalIntegrityException('Verified Signal archive is no longer readable; pruning aborted.');
            }
            if ($catalogEntries === [] && $archiveIds !== [] && $batch->archive_locator !== null && $batch->archive_checksum !== null) {
                $catalogEntries = $this->catalogEntriesFromHotEvents($archiveIds, $batch);
            }

            DB::transaction(function () use ($previewId, $claimToken, $executionToken, $eventIds, $archiveIds, $noArchiveIds, $batch, $catalogEntries, $context, $reason): void {
                /** @var SignalPrunePreview|null $lockedPreview */
                $lockedPreview = SignalPrunePreview::query()->where('preview_id', $previewId)->lockForUpdate()->first();
                if ($lockedPreview === null || ! in_array((string) $lockedPreview->status, ['claimed'], true)) throw new SignalIntegrityException('Signal prune preview is not in a claimable completion state.');
                if (! hash_equals((string) ($lockedPreview->execution_token ?? ''), $executionToken)) throw new SignalIntegrityException('Signal prune execution lease was lost before commit.');
                $rows = SignalEventLifecycle::query()->whereIn('event_id', $eventIds)->limit(count($eventIds))->lockForUpdate()->get();
                if ($rows->count() !== count($eventIds)) throw new SignalIntegrityException('Signal prune claim metadata changed before commit.');
                foreach ($rows as $row) {
                    if (! hash_equals((string) ($row->prune_claim_token ?? ''), $claimToken) || $row->pruned_at !== null || (bool) $row->legal_hold) throw new SignalIntegrityException('Signal prune claim was lost or invalidated before commit.');
                }
                if ($catalogEntries !== []) $this->archiveCatalog->record($catalogEntries);
                $now = now();
                SignalEventLifecycle::query()->whereIn('event_id', $eventIds)->update([
                    'pruned_at' => $now,
                    'prune_claim_token' => null,
                    'prune_claimed_at' => null,
                    'prune_claim_expires_at' => null,
                    'updated_at' => $now,
                ]);
                if ($archiveIds !== []) SignalEventLifecycle::query()->whereIn('event_id', $archiveIds)->update(['archive_batch_id' => (string) $batch->batch_id, 'archived_at' => $now, 'updated_at' => $now]);
                if ($noArchiveIds !== []) SignalEventLifecycle::query()->whereIn('event_id', $noArchiveIds)->update(['archive_batch_id' => null, 'archived_at' => null, 'updated_at' => $now]);
                $this->cleanupDerivedRows($eventIds);
                $deleted = DB::table('titan_signal_events')->whereIn('event_id', $eventIds)->delete();
                if ($deleted !== count($eventIds)) throw new SignalIntegrityException('Signal prune deleted a different event count than the approved preview.');
                SignalArchiveBatch::query()->where('batch_id', $batch->batch_id)->update(['status' => 'pruned', 'pruned_at' => $now, 'updated_at' => $now]);
                $lockedPreview->status = 'completed';
                $lockedPreview->execution_token = null;
                $lockedPreview->execution_started_at = null;
                $lockedPreview->execution_expires_at = null;
                $lockedPreview->completed_at = $now;
                $lockedPreview->save();
                $this->audit($context, 'events.pruned', null, (string) $batch->batch_id, $reason, [
                    'preview_id' => $previewId,
                    'candidate_hash' => (string) $lockedPreview->candidate_hash,
                    'event_count' => count($eventIds),
                    'archive_event_count' => count($archiveIds),
                    'archive_checksum' => $batch->archive_checksum,
                ]);
            });
        } catch (\Throwable $exception) {
            SignalPrunePreview::query()->where('preview_id', $previewId)->where('execution_token', $executionToken)->update([
                'execution_token' => null, 'execution_started_at' => null, 'execution_expires_at' => null, 'updated_at' => now(),
            ]);
            $batch->refresh();
            if (! in_array((string) $batch->status, ['verified_unpruned', 'verified_unpruned_no_archive', 'pruned'], true)) {
                $batch->status = 'failed_retryable';
                $batch->failure_code = substr(strtolower((new \ReflectionClass($exception))->getShortName()), 0, 120);
                $batch->save();
                $this->markPreviewRetryable($previewId, $claimToken, 'archive_or_prune_failed');
            }
            $this->audit($context, 'prune.failed', null, (string) $batch->batch_id, $reason, ['preview_id' => $previewId, 'error_class' => $exception::class]);
            throw $exception;
        }

        $batch->refresh();
        return [
            'pruned' => count($eventIds),
            'archived' => count($archiveIds),
            'preview_id' => $previewId,
            'candidate_hash' => (string) $preview->candidate_hash,
            'batch_id' => (string) $batch->batch_id,
            'archive_checksum' => $batch->archive_checksum,
            'status' => (string) $batch->status,
        ];
    }

    /** @param list<array{op:string,path:string,value?:mixed}> $operations @return array<string,mixed> */
    private function createOverlay(string $type, string $eventId, array $operations, string $reason, SignalContext $context): array
    {
        $this->assertManage($context, 'signal.redact');
        if (trim($reason) === '') throw new InvalidArgumentException('Signal overlays require a reason.');
        $overlay = new SignalRedactionOverlay($operations);
        /** @var SignalEvent|null $event */
        $event = SignalEvent::query()->where('event_id', $eventId)->first();
        if ($event === null) throw new InvalidArgumentException('Unknown Signal event.');
        $this->contextValidator->assertQueryAllowed((string) $event->scope, $event->tenant_company_id === null ? null : (int) $event->tenant_company_id, $context);
        $row = SignalEventOverlay::query()->create([
            'overlay_id' => self::uuid7(), 'event_id' => $eventId, 'scope' => $event->scope, 'tenant_company_id' => $event->tenant_company_id,
            'tenant_key' => (int) ($event->tenant_company_id ?? 0), 'overlay_type' => $type, 'operations' => $overlay->operations,
            'reason' => $reason, 'actor_id' => $context->actor->id, 'applied_at' => now(),
        ]);
        $this->audit($context, 'event.' . $type, $eventId, null, $reason, ['overlay_id' => $row->overlay_id, 'operation_count' => count($operations)]);
        return ['overlay_id' => (string) $row->overlay_id, 'event_id' => $eventId, 'overlay_type' => $type];
    }

    /** @return list<SignalEventLifecycle> */
    private function pruneCandidates(?int $tenantCompanyId, string $scope, int $limit): array
    {
        if (! Schema::hasTable('titan_signal_event_lifecycle')) return [];
        $limit = max(1, min($limit, (int) config('titan-signal-engine.prune_batch_limit', 1000)));
        $query = SignalEventLifecycle::query()->where('scope', $scope)->whereNull('pruned_at')->where('legal_hold', false)->whereNotNull('retain_until')->where('retain_until', '<=', now())
            ->where(function ($claim): void {
                $claim->whereNull('prune_claim_token')->orWhereNull('prune_claim_expires_at')->orWhere('prune_claim_expires_at', '<=', now());
            });
        $query = $scope === SignalEnvelope::SCOPE_TENANT ? $query->where('tenant_company_id', $tenantCompanyId) : $query->whereNull('tenant_company_id');
        $rows = $query->orderBy('retain_until')->limit($limit)->get()->all();
        return array_values(array_filter($rows, static function (SignalEventLifecycle $row): bool {
            try { return RetentionPolicy::for(RetentionClass::from((string) $row->retention_class))->prunable; } catch (\ValueError) { return false; }
        }));
    }

    private function invalidatePreview(SignalPrunePreview $preview, string $reason, ?string $claimToken = null): SignalPrunePreview
    {
        $preview->status = 'invalidated';
        $preview->invalidated_at = now();
        $preview->invalid_reason = $reason;
        $preview->execution_token = null;
        $preview->execution_started_at = null;
        $preview->execution_expires_at = null;
        $preview->save();
        if ($claimToken !== null) {
            SignalEventLifecycle::query()->whereIn('event_id', array_values(array_map('strval', (array) $preview->event_ids)))
                ->where('prune_claim_token', $claimToken)->whereNull('pruned_at')->update([
                    'prune_claim_token' => null, 'prune_claimed_at' => null, 'prune_claim_expires_at' => null, 'updated_at' => now(),
                ]);
        }
        return $preview;
    }

    private function markPreviewRetryable(string $previewId, string $claimToken, string $reason): void
    {
        DB::transaction(function () use ($previewId, $claimToken, $reason): void {
            $preview = SignalPrunePreview::query()->where('preview_id', $previewId)->lockForUpdate()->first();
            if ($preview !== null && (string) $preview->status !== 'completed') {
                $preview->status = 'failed_retryable';
                $preview->invalid_reason = $reason;
                $preview->expires_at = now()->addSeconds(max(60, (int) config('titan-signal-engine.prune_preview_ttl_seconds', 900)));
                $preview->execution_token = null;
                $preview->execution_started_at = null;
                $preview->execution_expires_at = null;
                $preview->save();
            }
            SignalEventLifecycle::query()->where('prune_claim_token', $claimToken)->whereNull('pruned_at')->update([
                'prune_claim_token' => null,
                'prune_claimed_at' => null,
                'prune_claim_expires_at' => null,
                'updated_at' => now(),
            ]);
        });
    }

    /** @param list<string> $archiveIds */
    private function archiveEventStream(array $archiveIds): \Generator
    {
        $events = SignalEvent::query()->whereIn('event_id', $archiveIds)->orderBy('recorded_at')->orderBy('event_id')->cursor();
        foreach ($events as $event) {
            $envelope = SignalEnvelope::fromPersistenceArray(array_replace($event->getAttributes(), ['payload' => $event->payload ?? [], 'metadata' => $event->metadata ?? []]));
            if (! $envelope->verifyChecksum()) throw new SignalIntegrityException('Refusing to archive a Signal event with invalid checksum: ' . $event->event_id);
            $original = $envelope->toArray();
            $overlayCount = 0;
            $archived = $original;
            foreach (SignalEventOverlay::query()->where('event_id', $event->event_id)->orderBy('id')->cursor() as $overlayRow) {
                $archived = (new SignalRedactionOverlay((array) $overlayRow->operations))->apply($archived);
                $overlayCount++;
            }
            $privacyProjected = $overlayCount > 0;
            if ($privacyProjected) {
                $archived = [
                    'projected_event' => $archived,
                    'archive_projection' => [
                        'overlay_count' => $overlayCount,
                        'original_checksum' => $envelope->checksum,
                        'original_checksum_alg' => $envelope->checksumAlgorithm,
                        'privacy_projected' => true,
                    ],
                ];
            }
            yield $archived;
        }
    }

    /** @param list<string> $archiveIds @return list<SignalArchiveEntry> */
    private function catalogEntriesFromHotEvents(array $archiveIds, SignalArchiveBatch $batch): array
    {
        $entries = [];
        $sequence = 0;
        foreach (SignalEvent::query()->whereIn('event_id', $archiveIds)->orderBy('recorded_at')->orderBy('event_id')->cursor() as $event) {
            $sequence++;
            $entries[] = new SignalArchiveEntry(
                eventId: (string) $event->event_id,
                batchId: (string) $batch->batch_id,
                scope: (string) $event->scope,
                tenantCompanyId: $event->tenant_company_id === null ? null : (int) $event->tenant_company_id,
                eventType: (string) $event->event_type,
                traceId: (string) $event->trace_id,
                correlationId: (string) $event->correlation_id,
                causationId: $event->causation_id === null ? null : (string) $event->causation_id,
                rootCausationId: (string) $event->root_causation_id,
                occurredAt: $event->occurred_at->toAtomString(),
                recordedAt: $event->recorded_at->toAtomString(),
                archiveDriver: (string) $batch->archive_driver,
                archiveLocator: (string) $batch->archive_locator,
                archiveChecksum: (string) $batch->archive_checksum,
                archiveSequence: $sequence,
                privacyProjected: SignalEventOverlay::query()->where('event_id', $event->event_id)->exists(),
                originalChecksum: (string) $event->checksum,
            );
        }
        if (count($entries) !== count($archiveIds)) throw new SignalIntegrityException('Signal archive catalog source set changed before prune commit.');
        return $entries;
    }

    /** @param list<string> $eventIds */
    private function cleanupDerivedRows(array $eventIds): void
    {
        $tables = [
            ['titan_signal_idempotency_keys', 'event_id'],
            ['titan_signal_causal_edges', 'parent_event_id'],
            ['titan_signal_causal_edges', 'child_event_id'],
            ['titan_signal_deliveries', 'event_id'],
            ['titan_signal_pulse_projected_events', 'event_id'],
            ['titan_signal_pulse_causation_refs', 'child_event_id'],
            ['titan_signal_pulse_causation_refs', 'parent_event_id'],
        ];
        foreach ($tables as [$table, $column]) {
            if (Schema::hasTable($table)) DB::table($table)->whereIn($column, $eventIds)->delete();
        }
    }

    private function assertManage(SignalContext $context, string $permission): void
    {
        if (! $context->hasPermission($permission)) throw new InvalidArgumentException("Signal lifecycle operation requires {$permission} permission.");
    }

    /** @param array<string,mixed> $details */
    private function audit(SignalContext $context, string $action, ?string $eventId, ?string $batchId, string $reason, array $details): void
    {
        if (! Schema::hasTable('titan_signal_lifecycle_audit')) return;
        SignalLifecycleAudit::query()->create([
            'action_id' => self::uuid7(), 'scope' => $context->scope, 'tenant_company_id' => $context->tenantCompanyId, 'tenant_key' => (int) ($context->tenantCompanyId ?? 0),
            'action' => $action, 'target_event_id' => $eventId, 'batch_id' => $batchId, 'actor_id' => $context->actor->id, 'reason' => $reason, 'details' => $details, 'occurred_at' => now(),
        ]);
    }

    private static function uuid7(): string
    {
        $ms = (int) floor(microtime(true) * 1000);
        $timeHex = str_pad(dechex($ms), 12, '0', STR_PAD_LEFT);
        $random = bin2hex(random_bytes(10));
        return substr($timeHex, 0, 8) . '-' . substr($timeHex, 8, 4) . '-7' . substr($random, 1, 3) . '-' . dechex((hexdec($random[4]) & 0x3) | 0x8) . substr($random, 5, 3) . '-' . substr($random, 8, 12);
    }
}
