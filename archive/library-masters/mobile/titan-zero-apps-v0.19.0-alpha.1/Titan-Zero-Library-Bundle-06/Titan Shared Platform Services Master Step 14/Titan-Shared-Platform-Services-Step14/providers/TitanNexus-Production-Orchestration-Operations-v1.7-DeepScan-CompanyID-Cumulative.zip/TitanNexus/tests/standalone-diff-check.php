<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Domain\CompiledTitanConfig;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeDisposition;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeKind;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Services\SemanticConfigurationDiffer;

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
foreach ([
    '/System/Support/CanonicalJson.php',
    '/System/Domain/CompiledTitanConfig.php',
    '/System/Domain/VerticalDefinition.php',
    '/System/Domain/SemanticChangeKind.php',
    '/System/Domain/SemanticChangeDisposition.php',
    '/System/Domain/SemanticDiffEntry.php',
    '/System/Domain/ConfigurationDiff.php',
    '/System/Contracts/ConfigurationDifferContract.php',
    '/System/Services/SemanticConfigurationDiffer.php',
] as $file) {
    require_once $root . $file;
}

function diffCheck(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

function compiled(array $sections, string $outputVersion = '1', string $verticalId = 'cleaning', string $verticalVersion = '2026.08', ?string $knowledge = 'au-vic-2026.08'): CompiledTitanConfig
{
    return CompiledTitanConfig::fromArray([
        'tenant_company_id' => 42,
        'configuration_version' => $outputVersion,
        'compiler_version' => '0.5.0',
        'vertical_id' => $verticalId,
        'vertical_version' => $verticalVersion,
        'knowledge_snapshot_version' => $knowledge,
        'source_profile_hash' => str_repeat('a', 64),
        'source_vertical_hash' => str_repeat('b', 64),
        'sections' => $sections,
    ]);
}

$baseVertical = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => [
        'billing' => ['currency' => 'AUD'],
        'roles' => ['cleaner'],
    ],
    'validation' => ['required_profile_paths' => ['sections.billing']],
]);
diffCheck($baseVertical->fingerprint() === 'c8d96640ed8dcc83241bf0e4b20fd932ae58663ccf0fe9cbf41d0324ed1649bf', 'adding optional recompile policy must preserve old vertical fingerprint when absent');

$policyVertical = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => [],
    'recompile_policy' => [
        'requires_approval_paths' => ['sections.billing', 'sections.billing'],
        'blocked_paths' => ['sections.compliance.locked'],
    ],
]);
$policy = $policyVertical->recompilePolicy();
diffCheck($policy['requires_approval_paths'] === ['sections.billing'], 'approval paths normalize as sorted unique set');
diffCheck($policy['blocked_paths'] === ['sections.compliance.locked'], 'blocked paths normalize');

$current = compiled([
    'billing' => ['currency' => 'AUD', 'tax_mode' => 'exclusive'],
    'roles' => ['cleaner', 'supervisor'],
    'operations' => ['evidence' => true],
    'compliance' => ['locked' => false],
]);
$proposed = compiled([
    'billing' => ['currency' => 'NZD', 'tax_mode' => 'exclusive'],
    'roles' => ['cleaner'],
    'new_module' => ['enabled' => true],
    'compliance' => ['locked' => true],
], '2');

$differ = new SemanticConfigurationDiffer();
$diff = $differ->diff($current, $proposed, $policyVertical);
$entries = $diff->entries();
$byPath = [];
foreach ($entries as $entry) {
    $byPath[$entry->path()] = $entry;
}

diffCheck(($byPath['sections.billing.currency'] ?? null)?->kind() === SemanticChangeKind::Modify, 'changed scalar is modify');
diffCheck(($byPath['sections.billing.currency'] ?? null)?->disposition() === SemanticChangeDisposition::RequiresApproval, 'approval subtree policy applies to changed child');
diffCheck(($byPath['sections.billing.tax_mode'] ?? null)?->kind() === SemanticChangeKind::Unchanged, 'equal scalar is unchanged');
diffCheck(($byPath['sections.roles'] ?? null)?->kind() === SemanticChangeKind::Modify, 'lists compare atomically');
diffCheck(($byPath['sections.operations'] ?? null)?->kind() === SemanticChangeKind::Deprecate, 'removed subtree is deprecate');
diffCheck(($byPath['sections.new_module'] ?? null)?->kind() === SemanticChangeKind::Add, 'new subtree is add');
diffCheck(($byPath['sections.compliance.locked'] ?? null)?->disposition() === SemanticChangeDisposition::Blocked, 'blocked policy wins for matching path');

$removedProtected = compiled([
    'billing' => ['currency' => 'AUD', 'tax_mode' => 'exclusive'],
    'roles' => ['cleaner', 'supervisor'],
    'operations' => ['evidence' => true],
], '4');
$removedDiff = $differ->diff($current, $removedProtected, $policyVertical);
$removedByPath = [];
foreach ($removedDiff->entries() as $entry) {
    $removedByPath[$entry->path()] = $entry;
}
diffCheck(($removedByPath['sections.compliance'] ?? null)?->disposition() === SemanticChangeDisposition::Blocked, 'removing a parent subtree cannot bypass a blocked descendant policy');
diffCheck($diff->hasBlocked(), 'diff reports blocked changes');
diffCheck($diff->requiresApproval(), 'diff reports approval changes independently');

diffCheck($diff->toArray()['entries'] === $diff->toArray()['entries'], 'diff serialization is stable');
$roundTrip = App\Extensions\TitanNexus\System\Domain\ConfigurationDiff::fromArray($diff->toArray());
diffCheck($roundTrip->fingerprint() === $diff->fingerprint(), 'diff persistence round-trip preserves fingerprint');

$reorderedPolicy = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => [],
    'recompile_policy' => [
        'blocked_paths' => ['sections.compliance.locked'],
        'requires_approval_paths' => ['sections.billing'],
    ],
]);
$diff2 = $differ->diff($current, $proposed, $reorderedPolicy);
diffCheck($diff2->fingerprint() === $diff->fingerprint(), 'equivalent normalized policy produces deterministic diff fingerprint');

$verticalChanged = compiled($current->sections(), '3', 'plumbing', '1.0', null);
$plumbingDefinition = VerticalDefinition::fromArray([
    'vertical_id' => 'plumbing',
    'vertical_version' => '1.0',
    'sections' => [],
]);
$identityDiff = $differ->diff($current, $verticalChanged, $plumbingDefinition);
$identityByPath = [];
foreach ($identityDiff->entries() as $entry) {
    $identityByPath[$entry->path()] = $entry;
}
diffCheck(($identityByPath['vertical.id'] ?? null)?->disposition() === SemanticChangeDisposition::RequiresApproval, 'vertical identity change requires approval by default');

fwrite(STDOUT, "PASS: Titan Nexus standalone semantic diff checks\n");
