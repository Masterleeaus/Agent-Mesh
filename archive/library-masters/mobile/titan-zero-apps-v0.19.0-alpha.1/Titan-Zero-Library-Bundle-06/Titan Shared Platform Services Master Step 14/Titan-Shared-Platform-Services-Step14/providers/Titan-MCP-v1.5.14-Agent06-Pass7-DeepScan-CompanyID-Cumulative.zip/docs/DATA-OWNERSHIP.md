# Data ownership

Titan MCP owns only its control-plane settings, filesystem/database backup artifacts, operation locks and audit ledger. It does not own business-domain truth.

It writes shared `permissions`, `role_has_permissions` and `menus` rows only for its own keys. Uninstall removes those contribution rows but retains recovery/audit state by default.
