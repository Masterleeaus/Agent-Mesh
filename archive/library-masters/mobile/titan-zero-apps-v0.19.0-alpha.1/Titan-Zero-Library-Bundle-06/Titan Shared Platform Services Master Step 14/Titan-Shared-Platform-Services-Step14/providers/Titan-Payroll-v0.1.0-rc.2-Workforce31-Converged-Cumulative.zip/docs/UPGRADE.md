# Upgrade

Use expand-migrate-contract migrations. Legacy donor migrations are reference-only and are never replayed against the Titan host.
