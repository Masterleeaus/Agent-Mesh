<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\AI\RewindToolCatalogue;

final class RewindAssistantService
{
    public function __construct(private RewindToolCatalogue $tools) {}

    public function route(string $message, array $context = []): array
    {
        $text = strtolower(trim($message));
        $specialist = 'audit';
        if ($this->containsAny($text, ['compare','counterfactual','what if','model','policy','knowledge version'])) $specialist = 'comparison';
        elseif ($this->containsAny($text, ['rollback','restore','recover','correction','correct','fix'])) $specialist = 'recovery';
        elseif ($this->containsAny($text, ['compliance','export','evidence','audit bundle'])) $specialist = 'compliance';
        elseif ($this->containsAny($text, ['drift','integrity','hash','tamper'])) $specialist = 'integrity';
        elseif ($this->containsAny($text, ['timeline','who changed','when did','sequence'])) $specialist = 'timeline';
        elseif ($this->containsAny($text, ['why','cause','root cause','failed','failure'])) $specialist = 'root-cause';

        [$recommendation,$toolIds] = match ($specialist) {
            'comparison' => ['Run a mutation-free structural comparison first. It will show changed decision metadata and impacted historical events without claiming model re-execution.', ['rewind.compare_trace','rewind.reconstruct_trace']],
            'recovery' => ['Reconstruct and verify the trace, then create a governed recovery proposal. Rewind must not execute the business mutation.', ['rewind.reconstruct_trace','rewind.verify_integrity','rewind.propose_recovery']],
            'compliance' => ['Verify integrity before generating or exporting an evidence package.', ['rewind.verify_integrity','rewind.generate_evidence']],
            'integrity' => ['Verify the trace integrity chain and inspect forensic drift before trusting downstream evidence.', ['rewind.verify_integrity','rewind.reconstruct_trace']],
            'timeline' => ['Reconstruct the deterministic timeline ordered by sequence, occurrence time and event ID.', ['rewind.reconstruct_trace']],
            'root-cause' => ['Reconstruct the trace and inspect the first explicit failure plus its upstream causation path.', ['rewind.reconstruct_trace']],
            default => ['Start with the deterministic trace reconstruction and inspect its evidence, source and governance metadata.', ['rewind.reconstruct_trace']],
        };

        $toolIds = array_values(array_filter($toolIds, fn(string $id): bool => $this->tools->byId($id) !== null));
        return [
            'specialist'=>$specialist,
            'mode'=>'guided-deterministic',
            'recommendation'=>$recommendation,
            'tool_ids'=>$toolIds,
            'context'=>array_intersect_key($context, array_flip(['trace_id','case_uuid'])),
            'hidden_chain_of_thought'=>false,
            'external_ai_called'=>false,
        ];
    }

    private function containsAny(string $text, array $needles): bool
    {
        foreach ($needles as $needle) if (str_contains($text, $needle)) return true;
        return false;
    }
}
