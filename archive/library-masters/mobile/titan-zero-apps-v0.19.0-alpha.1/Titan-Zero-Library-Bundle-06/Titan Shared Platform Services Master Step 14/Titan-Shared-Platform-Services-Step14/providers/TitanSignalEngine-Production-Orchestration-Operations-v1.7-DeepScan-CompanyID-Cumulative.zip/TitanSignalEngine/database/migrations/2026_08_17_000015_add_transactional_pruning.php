<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_prune_previews')) {
            Schema::create('titan_signal_prune_previews', function (Blueprint $table): void {
                $table->id();
                $table->uuid('preview_id')->unique('tspp_preview_uq');
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->string('status', 32)->default('previewed');
                $table->char('token_hash', 64);
                $table->char('candidate_hash', 64);
                $table->unsignedInteger('candidate_count');
                $table->json('event_ids');
                $table->json('by_retention_class')->nullable();
                $table->string('created_by', 191);
                $table->dateTime('expires_at');
                $table->uuid('archive_batch_id')->nullable();
                $table->timestamp('claimed_at')->nullable();
                $table->char('execution_token', 64)->nullable();
                $table->timestamp('execution_started_at')->nullable();
                $table->timestamp('execution_expires_at')->nullable();
                $table->timestamp('completed_at')->nullable();
                $table->timestamp('invalidated_at')->nullable();
                $table->string('invalid_reason', 191)->nullable();
                $table->timestamps();
                $table->index(['scope', 'tenant_key', 'status', 'expires_at'], 'tspp_scope_status_idx');
                $table->index(['archive_batch_id'], 'tspp_batch_idx');
            });
        }

        if (Schema::hasTable('titan_signal_event_lifecycle')) {
            Schema::table('titan_signal_event_lifecycle', function (Blueprint $table): void {
                if (! Schema::hasColumn('titan_signal_event_lifecycle', 'prune_claim_token')) $table->char('prune_claim_token', 64)->nullable()->after('pruned_at');
                if (! Schema::hasColumn('titan_signal_event_lifecycle', 'prune_claimed_at')) $table->timestamp('prune_claimed_at')->nullable()->after('prune_claim_token');
                if (! Schema::hasColumn('titan_signal_event_lifecycle', 'prune_claim_expires_at')) $table->timestamp('prune_claim_expires_at')->nullable()->after('prune_claimed_at');
            });
            try { Schema::table('titan_signal_event_lifecycle', fn (Blueprint $table): mixed => $table->index(['scope', 'tenant_key', 'prune_claim_expires_at'], 'tsel_prune_claim_idx')); } catch (\Throwable) {}
        }

        if (Schema::hasTable('titan_signal_archive_batches')) {
            Schema::table('titan_signal_archive_batches', function (Blueprint $table): void {
                if (! Schema::hasColumn('titan_signal_archive_batches', 'preview_id')) $table->uuid('preview_id')->nullable()->after('batch_id');
                if (! Schema::hasColumn('titan_signal_archive_batches', 'prune_event_count')) $table->unsignedBigInteger('prune_event_count')->default(0)->after('event_count');
                if (! Schema::hasColumn('titan_signal_archive_batches', 'archive_event_count')) $table->unsignedBigInteger('archive_event_count')->default(0)->after('prune_event_count');
                if (! Schema::hasColumn('titan_signal_archive_batches', 'pruned_at')) $table->timestamp('pruned_at')->nullable()->after('verified_at');
                if (! Schema::hasColumn('titan_signal_archive_batches', 'failure_code')) $table->string('failure_code', 120)->nullable()->after('pruned_at');
            });
            try { Schema::table('titan_signal_archive_batches', fn (Blueprint $table): mixed => $table->unique(['preview_id'], 'tsab_preview_uq')); } catch (\Throwable) {}
            try { Schema::table('titan_signal_archive_batches', fn (Blueprint $table): mixed => $table->index(['status', 'preview_id'], 'tsab_status_preview_idx')); } catch (\Throwable) {}
        }

        // Pre-v0.14 processing claims cannot be trusted. Clear any partial values on upgrade.
        if (Schema::hasTable('titan_signal_event_lifecycle') && Schema::hasColumn('titan_signal_event_lifecycle', 'prune_claim_token')) {
            DB::table('titan_signal_event_lifecycle')->whereNull('pruned_at')->update([
                'prune_claim_token' => null,
                'prune_claimed_at' => null,
                'prune_claim_expires_at' => null,
            ]);
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_prune_previews');
        // Additive production migration: retain lifecycle/archive columns on rollback to avoid losing recovery state.
    }
};
