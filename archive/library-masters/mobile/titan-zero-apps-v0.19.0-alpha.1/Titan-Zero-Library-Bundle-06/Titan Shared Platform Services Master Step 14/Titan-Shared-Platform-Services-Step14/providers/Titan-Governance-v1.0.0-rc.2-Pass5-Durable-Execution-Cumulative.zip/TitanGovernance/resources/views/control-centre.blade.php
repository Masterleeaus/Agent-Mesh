@extends('panel.layout.app')

@section('content')
<div class="container-fluid py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <div>
            <h1 class="h3 mb-1">Governance Control Centre</h1>
            <p class="text-muted mb-0">Read-only operating view across governance health, attention, model, policy, evidence and authority contraction.</p>
        </div>
        <a class="btn btn-outline-secondary" href="{{ route('dashboard.user.titan.governance.index') }}">Governance Overview</a>
    </div>

    @php
        $attention = is_array($snapshot['attention'] ?? null) ? $snapshot['attention'] : [];
        $engines = is_array($snapshot['engine_health'] ?? null) ? $snapshot['engine_health'] : [];
        $model = is_array($snapshot['model_health'] ?? null) ? $snapshot['model_health'] : [];
        $compliance = is_array($snapshot['policy_compliance'] ?? null) ? $snapshot['policy_compliance'] : [];
    @endphp

    <div class="row g-3 mb-4">
        <div class="col-6 col-xl-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Needs attention</div><div class="h3 mb-0">{{ count($attention) }}</div></div></div></div>
        <div class="col-6 col-xl-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Engine health</div><div class="h5 mb-0">{{ $snapshot['status'] ?? ($engines['status'] ?? 'UNKNOWN') }}</div></div></div></div>
        <div class="col-6 col-xl-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Model health</div><div class="h5 mb-0">{{ $model['status'] ?? 'UNKNOWN' }}</div></div></div></div>
        <div class="col-6 col-xl-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Policy / compliance</div><div class="h5 mb-0">{{ $compliance['status'] ?? 'UNKNOWN' }}</div></div></div></div>
    </div>

    <div class="card mb-4">
        <div class="card-header"><h5 class="mb-0">Needs Attention</h5></div>
        <div class="card-body p-0">
            @if(count($attention) === 0)
                <div class="p-4 text-muted">No current Governance attention items.</div>
            @else
                <div class="table-responsive"><table class="table mb-0"><thead><tr><th>Priority</th><th>Category</th><th>Subject</th><th>Reason</th></tr></thead><tbody>
                @foreach($attention as $row)
                    <tr><td>{{ $row['priority'] ?? 'LOW' }}</td><td>{{ $row['category'] ?? 'UNKNOWN' }}</td><td>{{ ($row['subject_type'] ?? '') }} {{ ($row['subject_id'] ?? '') }}</td><td>{{ implode(', ', is_array($row['reason_codes'] ?? null) ? $row['reason_codes'] : []) }}</td></tr>
                @endforeach
                </tbody></table></div>
            @endif
        </div>
    </div>

    <div class="card">
        <div class="card-header"><h5 class="mb-0">Control Centre Snapshot</h5></div>
        <div class="card-body"><pre class="mb-0" style="white-space:pre-wrap">{{ json_encode($snapshot, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div>
    </div>
</div>
@endsection
