<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\DecisionIntelligence;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceDecisionEvidenceSourceContract;

final class UnavailableDecisionEvidenceSource implements GovernanceDecisionEvidenceSourceContract
{
    public function __construct(private readonly string $sourceKey,private readonly bool $isRequired=false,private readonly string $status='UNAVAILABLE',private readonly ?string $reason=null){}
    public function key(): string{return $this->sourceKey;}
    public function required(): bool{return $this->isRequired;}
    public function decisionEvidence(int $tenantCompanyId,string $decisionId,array $context=[]):array{return [
        'status'=>strtoupper($this->status),'source'=>$this->sourceKey,'required'=>$this->isRequired,'tenant_company_id'=>$tenantCompanyId,'decision_id'=>$decisionId,'observed_at'=>null,'events'=>[],'policies'=>[],'rewind'=>null,'reason'=>$this->reason,
    ];}
}
