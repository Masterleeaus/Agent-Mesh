# Failure modes

Failures before backup verification result in no write. Failed writes attempt verified pre-write recovery. A successful write whose final audit commit fails is compensated back to pre-write state. Backup/audit corruption blocks further mutations. Database target drift blocks restore. Recovery failures surface manual-recovery metadata instead of reporting success.
