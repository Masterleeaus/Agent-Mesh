<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

enum ProvisioningReceiptStatus: string
{
    case Applied = 'applied';
    case AlreadyApplied = 'already_applied';
    case Failed = 'failed';
    case SkippedDependency = 'skipped_dependency';

    public function successful(): bool
    {
        return $this === self::Applied || $this === self::AlreadyApplied;
    }
}
