# MagicAI provider gateway

## Production path

```text
AIChatPro / AI Agent / other Titan source
        -> TitanAIRuntimeContract
        -> source policy + trusted tools
        -> ProviderExecutionRegistry
        -> MagicAIHostProviderGateway
        -> MagicAI host provider/model credentials
        -> MagicAI Entity credit accounting
```

`magicai-host` is the default production provider driver.

The gateway derives provider engine from the trusted host `EntityEnum` model. If no trusted model is supplied, MagicAI's current default engine/default word model is used.

## Security

Before execution the gateway requires:

1. positive `company_id` already validated by `TitanAIRequest`;
2. a real principal user;
3. principal `user.company_id` equal to the request company;
4. a registered host model when an override is supplied;
5. sufficient MagicAI credit balance;
6. source-authorized trusted tools only.

The caller cannot supply provider endpoint URLs, authorization headers, API keys, tool schemas or arbitrary assistant deployment objects.

## Providers

The shared gateway contains host-compatible execution paths for:

- OpenAI;
- Anthropic;
- Gemini;
- DeepSeek;
- xAI.

Provider credentials continue to be resolved by the MagicAI host infrastructure used by the original extensions.

## Streaming

TitanAI emits a provider-independent event contract including:

- `run.started`;
- `content.delta`;
- `tool.call.started`;
- `tool.call.completed`;
- `generative_ui`;
- `run.completed`;
- `run.failed`.

OpenAI currently provides token-level content streaming and streamed tool-call assembly. Non-OpenAI host engines execute through the same provider gateway and are normalized into the event contract after completion.

## Trusted tools

Tools declare one of two execution modes:

- `server` — TitanAI executes the registered server-side contributor after source-policy authorization;
- `client` — TitanAI returns a pending client action and never executes it server-side.

AIChatPro connector tools are server tools. AI Agent Copilot workflow-builder actions are client tools.

## Billing

The gateway performs a host credit balance preflight before provider execution. Successful textual output is then charged through MagicAI's `Entity::driver(...)->forUser(...)->calculateCredit()->decreaseCredit()` path and recorded through the host usage model.

Custom OpenAI-compatible provider profiles remain an explicit alternate path and use the extension's compatibility usage recorder; they are not the default MagicAI production route.
