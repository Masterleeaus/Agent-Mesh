<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Data;

final class WorkOrderDetailDTO
{
    public function __construct(
        public readonly mixed $workOrder,
        public readonly mixed $tasks,
        public readonly mixed $appointments,
        public readonly mixed $dispatch,
        public readonly mixed $forms,
        public readonly mixed $evidence,
        public readonly mixed $materials,
        public readonly mixed $timeEntries,
    ) {}

    public function toArray(): array
    {
        return [
            'workOrder'=>$this->workOrder,
            'tasks'=>$this->tasks,
            'appointments'=>$this->appointments,
            'dispatch'=>$this->dispatch,
            'forms'=>$this->forms,
            'evidence'=>$this->evidence,
            'materials'=>$this->materials,
            'timeEntries'=>$this->timeEntries,
        ];
    }
}
