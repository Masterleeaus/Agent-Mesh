<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\GovernedCapabilityCommand;

interface ExecutionPostconditionVerifierContract
{
    /**
     * @return array{status:string,confidence?:float,reason_codes?:array,facts?:array}
     * status is one of verified|failed|pending|unavailable.
     */
    public function verify(CapabilityState $state, GovernedCapabilityCommand $command, array $commandResult, array $context = []): array;
}
