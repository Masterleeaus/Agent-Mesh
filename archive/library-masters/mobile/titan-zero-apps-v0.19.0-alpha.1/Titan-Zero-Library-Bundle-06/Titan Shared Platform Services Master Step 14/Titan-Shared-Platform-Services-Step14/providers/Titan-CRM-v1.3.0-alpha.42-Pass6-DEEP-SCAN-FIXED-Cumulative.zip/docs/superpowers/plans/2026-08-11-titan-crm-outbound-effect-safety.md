# Titan CRM Outbound Effect Safety Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make CRM outbound communication effects crash-safe, idempotent, receipt-backed and Titan Connect-ready without replacing existing CRM domain behavior.

**Architecture:** Preserve the authoritative CRM command transaction, convert invoice delivery to an outbox intent, execute provider calls only after commit through a replaceable communication port, and persist provider outcomes against the original trace/command/receipt chain. Existing legacy mail rendering remains available only as a compatibility adapter.

**Tech Stack:** PHP 8.2+, Laravel 10, MySQL-compatible additive migrations, existing Titan CRM installer/verifier conventions.

## Global Constraints

- Preserve alpha.19 governed Business OS behavior.
- `tenant_company_id` remains canonical.
- No provider/network call inside the authoritative CRM command transaction.
- External effects require tenant-scoped idempotency.
- Titan Connect owns canonical communications execution when installed.
- Provider success is distinct from CRM command acceptance.
- All trace/correlation/causation IDs must survive into the delivery record.
- Additive installer-safe migration only.

---

### Task 1: Alpha.20 failing architecture verifier

**Files:**
- Create: `bin/verify-v130-alpha20-outbound-effect-safety.php`

**Produces:** A red verifier for outbox v2, communication port, no in-transaction mail send, capability side-effect metadata and provider receipts.

- [ ] Write assertions for the alpha.20 contract.
- [ ] Run verifier and confirm failure because alpha.20 components are absent.

### Task 2: Add outbox v2 schema

**Files:**
- Create: `database/migrations/2026_08_11_000030_harden_crm_outbound_effects.php`

**Produces:** Additive idempotency, trace and provider receipt fields plus tenant/idempotency uniqueness.

- [ ] Add guarded columns/indexes with MySQL-safe names.
- [ ] Add rollback limited to alpha.20 additions.
- [ ] Run migration static verifiers.

### Task 3: Communication execution port and adapters

**Files:**
- Create: `System/Integrations/TitanConnect/CrmCommunicationExecutionPort.php`
- Create: `System/Integrations/TitanConnect/CrmDeferredCommunicationExecutionPort.php`
- Create: `System/Integrations/TitanConnect/CrmLegacyMailCommunicationAdapter.php`
- Modify: `System/Providers/CrmCapabilityServiceProvider.php`
- Modify: `config/crm.php`

**Produces:** Replaceable Titan Connect boundary with explicit standalone legacy compatibility.

- [ ] Define structured `deliver(array $intent): array` contract.
- [ ] Implement deferred adapter.
- [ ] Move existing mail/PDF provider execution into legacy adapter.
- [ ] Bind adapter according to configuration without overriding a Titan Connect binding.

### Task 4: Idempotent outbox API and post-commit delivery worker

**Files:**
- Modify: `System/Services/CrmNotificationOutboxService.php`
- Modify: `System/Services/CrmNotificationDeliveryService.php`
- Create: `System/Console/DeliverCrmOutboundEffectsCommand.php`
- Modify: `System/CrmServiceProvider.php`

**Produces:** Deterministic enqueue, atomic claim, bounded retry, terminal-state safety and explicit provider receipt persistence.

- [ ] Add `enqueueGoverned()` keyed by tenant + idempotency key.
- [ ] Add claim/read/mark provider outcome methods.
- [ ] Deliver only claimed rows through communication port.
- [ ] Never resend terminal `sent|delivered` records.
- [ ] Register `crm:outbound-effects:deliver` command.

### Task 5: Refactor invoice send/reminder to queue only

**Files:**
- Modify: `System/Services/SalesDocumentDeliveryService.php`
- Modify: `System/Capabilities/CrmCapabilityExecutor.php`
- Modify: `System/Capabilities/CrmCapabilityOperationStore.php`
- Modify: `System/Governance/CrmCommandReceiptFactory.php`

**Produces:** Invoice send/reminder validate and enqueue inside the transaction, then return an authoritative receipt with `effect_status=queued` and `outbox_public_id`; no mail/provider call occurs there.

- [ ] Convert sales delivery service to intent preparation/enqueue only.
- [ ] Thread command/idempotency/trace metadata into outbox.
- [ ] Add effect reference to command receipt and stored idempotent result.
- [ ] Preserve stable capability names and current invoice validation.

### Task 6: Side-effect contract metadata and delivery Signals

**Files:**
- Modify: `System/Capabilities/CrmCapabilityManifest.php`
- Modify: `System/Governance/CrmDomainSignalPublisher.php`
- Modify: `System/Services/CrmNotificationDeliveryService.php`

**Produces:** Machine-readable external-effect ownership and delivery lifecycle Signal records tied to original trace IDs.

- [ ] Add side-effect metadata to all definitions.
- [ ] Mark invoice send/reminder external, after-commit, owner `titan_connect`.
- [ ] Record queued/sent/failed delivery lifecycle Signal events.

### Task 7: Versioning, docs and full regression verification

**Files:**
- Modify: `extension.json`
- Modify: `extension.manifest.json`
- Modify: `CHANGELOG.md`
- Create: `CHANGELOG_v1.3.0_ALPHA20_OUTBOUND_EFFECT_SAFETY.md`
- Create: `docs/CRM-1.3.0-ALPHA20-OUTBOUND-EFFECT-SAFETY-REPORT.md`
- Regenerate: `FILE-SHA256.json`

**Produces:** Installer-ready `1.3.0-alpha.20` package.

- [ ] Run alpha.20 verifier.
- [ ] Run master verifier and all standalone verifier/test scripts.
- [ ] PHP-lint all PHP files.
- [ ] Regenerate integrity inventory.
- [ ] Create ZIP, test ZIP integrity, extract cleanly and rerun alpha.20/master verification.
