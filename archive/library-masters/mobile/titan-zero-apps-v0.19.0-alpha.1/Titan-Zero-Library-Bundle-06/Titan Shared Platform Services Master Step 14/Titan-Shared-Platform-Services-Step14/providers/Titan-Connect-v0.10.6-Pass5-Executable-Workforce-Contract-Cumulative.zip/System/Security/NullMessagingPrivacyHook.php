<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use App\Extensions\TitanConnect\System\Contracts\MessagingPrivacyHook;

final class NullMessagingPrivacyHook implements MessagingPrivacyHook
{
    public function beforeExport(int $companyId, int $actorId): void
    {
    }

    public function requestDeletion(int $companyId, int $actorId, array $context = []): array
    {
        return [
            'status' => 'policy-adapter-required',
            'company_id' => $companyId,
            'actor_id' => $actorId,
            'deleted' => false,
        ];
    }
}
