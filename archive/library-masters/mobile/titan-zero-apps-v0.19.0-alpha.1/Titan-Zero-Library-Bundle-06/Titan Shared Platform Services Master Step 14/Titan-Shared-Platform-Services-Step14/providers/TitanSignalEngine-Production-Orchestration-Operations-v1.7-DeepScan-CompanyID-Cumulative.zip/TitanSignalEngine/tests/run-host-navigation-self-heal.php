<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$adminPath = $root . '/System/Navigation/SignalAdminNavigation.php';
$registrarPath = $root . '/System/Navigation/HostNavigationRegistrar.php';
$menuStorePath = $root . '/System/Navigation/LegacyMenuStore.php';
$commandPath = $root . '/System/Console/Commands/SyncSignalMenuCommand.php';
$providerPath = $root . '/System/TitanSignalEngineServiceProvider.php';
$migrationPath = $root . '/database/migrations/2026_08_20_000022_add_signal_super_admin_child_navigation.php';

$assert(is_file($registrarPath), 'missing HostNavigationRegistrar');
$assert(is_file($menuStorePath), 'missing LegacyMenuStore');
$assert(is_file($commandPath), 'missing SyncSignalMenuCommand');
$assert(is_file($migrationPath), 'missing rc.8 child-navigation migration');
$assert(is_file($adminPath), 'missing admin navigation definition');

$expected = [
    'titan_signal_engine_overview' => 'dashboard.admin.titan.signal.engine.overview',
    'titan_signal_engine_pulse_health' => 'dashboard.admin.titan.signal.engine.pulse-health',
    'titan_signal_engine_events_traces' => 'dashboard.admin.titan.signal.engine.events-traces',
    'titan_signal_engine_anomalies' => 'dashboard.admin.titan.signal.engine.anomalies',
    'titan_signal_engine_deliveries_dlq' => 'dashboard.admin.titan.signal.engine.deliveries-dlq',
    'titan_signal_engine_lifecycle_archives' => 'dashboard.admin.titan.signal.engine.lifecycle-archives',
    'titan_signal_engine_registries' => 'dashboard.admin.titan.signal.engine.registries',
    'titan_signal_engine_diagnostics' => 'dashboard.admin.titan.signal.engine.diagnostics',
];

if (is_file($adminPath)) {
    require_once $adminPath;
    $adminClass = 'App\\Extensions\\TitanSignalEngine\\System\\Navigation\\SignalAdminNavigation';
    $items = (new $adminClass())->items();
    $assert(count($items) === 9, 'Signal admin navigation must expose one parent plus eight children');
    $parent = $items[0] ?? [];
    $assert(($parent['key'] ?? null) === 'titan_signal_engine_admin', 'unexpected admin parent key');
    $assert(array_key_exists('parent_key', $parent) && $parent['parent_key'] === null, 'parent must be top-level');
    $assert(($parent['route'] ?? null) === 'dashboard.admin.titan.signal.engine.index', 'unexpected parent route');
    $assert((string)($parent['extension'] ?? '') === '1', 'parent must use Website1408 extension marker');
    $assert(($parent['is_admin'] ?? null) === true, 'parent must be admin');
    $assert((int)($parent['order'] ?? 0) >= 900, 'parent must use Super Admin order band');

    foreach (array_slice($items, 1) as $item) {
        $key = (string)($item['key'] ?? '');
        $assert(isset($expected[$key]), 'unexpected child menu key: ' . $key);
        $assert(($item['parent_key'] ?? null) === 'titan_signal_engine_admin', $key . ' missing parent_key');
        $assert(($item['route'] ?? null) === ($expected[$key] ?? null), $key . ' route mismatch');
        $assert((string)($item['extension'] ?? '') === '1', $key . ' extension marker mismatch');
        $assert(($item['is_admin'] ?? null) === true, $key . ' must be admin');
        $assert(! str_contains((string)($item['label'] ?? ''), '&'), $key . ' label must avoid ampersand host escaping');
    }
}

$registrar = @file_get_contents($registrarPath) ?: '';
foreach (['MenuContributionRegistry','ContributionRegistry',"'navigation.admin'",'LegacyMenuStore',"'extension' => '1'",'MenuService','regenerate','syncHostMenus','duplicate host menu keys','parent_menu_row_unavailable','array_slice($definitions, 1)'] as $needle) {
    $assert(str_contains($registrar, $needle), 'host registrar missing: ' . $needle);
}

$menuStore = @file_get_contents($menuStorePath) ?: '';
foreach (["Schema::hasTable('menus')","Schema::getColumnListing('menus')","DB::table('menus')"] as $needle) {
    $assert(str_contains($menuStore, $needle), 'legacy menu store missing: ' . $needle);
}
$assert(! str_contains($registrar, "Schema::hasTable('menus')"), 'host registrar must keep legacy DB schema access quarantined');

$provider = @file_get_contents($providerPath) ?: '';
foreach (['HostNavigationRegistrar','SyncSignalMenuCommand','syncHostMenus','registerContributions','titan_signal_engine_diagnostics'] as $needle) {
    $assert(str_contains($provider, $needle), 'provider missing navigation wiring/cleanup: ' . $needle);
}
$assert(str_contains($provider, '$this->app->booted'), 'navigation self-heal must run after host boot');

$migration = @file_get_contents($migrationPath) ?: '';
foreach (array_merge(['titan_signal_engine_admin', "'dashboard.admin.titan.signal.engine.index'", "'parent_id' => \$rootId"], array_keys($expected), array_values($expected)) as $needle) {
    $assert(str_contains($migration, $needle), 'rc.8 navigation migration missing: ' . $needle);
}

$certification = @file_get_contents($root . '/System/Services/SignalHostCertificationService.php') ?: '';
foreach (["'runtime.navigation'",'REQUIRED_MENU_ROWS','titan_signal_engine_admin','titan_signal_engine_diagnostics','parent_relationship','eight child menu rows'] as $needle) {
    $assert(str_contains($certification, $needle), 'host certification missing navigation gate: ' . $needle);
}

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Signal rc.8 host navigation parent/child self-heal contract\n";
