# Troubleshooting

For v0.7:

1. Confirm the active account resolves an explicit `tenant_company_id` and holds the required Rewind permission.
2. Check source watermark state; adapters without watermark support intentionally produce `PARTIAL` audit completeness.
3. Verify trace integrity before trusting evidence/recovery planning.
4. Check evidence RSA private/public key paths and key ID if evidence generation or export fails.
5. Treat replay boundary violations as permanent safety failures, not retryable errors.
6. Check active legal holds before any manual deletion or future purge workflow.
7. Check the `titan-rewind-replay` queue for queued/failed replay work.

Structured runtime health, DLQ/backpressure and broader observability diagnostics are added in the next hardening pass.
