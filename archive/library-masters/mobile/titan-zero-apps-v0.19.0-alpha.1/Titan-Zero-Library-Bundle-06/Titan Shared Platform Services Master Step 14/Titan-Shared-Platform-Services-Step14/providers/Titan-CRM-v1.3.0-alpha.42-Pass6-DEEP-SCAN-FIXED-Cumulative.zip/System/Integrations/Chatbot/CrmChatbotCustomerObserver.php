<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Integrations\Chatbot;
final class CrmChatbotCustomerObserver
{
    public function __construct(private CrmChatbotIdentityService $identities) {}
    public function created(object $customer): void { $this->safe($customer); }
    public function updated(object $customer): void { if ($customer->wasChanged(['email','phone','name','chatbot_channel','payload'])) $this->safe($customer); }
    private function safe(object $customer): void { try { $this->identities->syncCustomer($customer); } catch (\Throwable $e) { report($e); } }
}
