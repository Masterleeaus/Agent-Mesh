<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Domains\CommercialCalculations;

use App\Extensions\Crm\System\Domains\CommercialCalculations\DTO\CalculationContext;
use App\Extensions\Crm\System\Domains\CommercialCalculations\Engines\{
    DiscountPromotionEngine, FormulaRulesEngine, MarginProfitabilityEngine, PricingEngine, QuoteEstimateEngine, TaxEngine
};
use App\Extensions\Crm\System\Domains\CommercialCalculations\Services\CalculatingEngineService;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use InvalidArgumentException;

/** Deterministic, read-only commercial calculations that belong to CRM quote/pricing authority. */
final class CommercialCalculationService
{
    private const DEFINITIONS = [
        'formula_rules'=>['name'=>'Formula Rules','category'=>'commercial'],
        'pricing'=>['name'=>'Pricing','category'=>'commercial'],
        'quote_estimate'=>['name'=>'Quote / Estimate','category'=>'commercial'],
        'discount_promotion'=>['name'=>'Discount / Promotion','category'=>'commercial'],
        'margin_profitability'=>['name'=>'Margin / Profitability','category'=>'commercial'],
        'tax'=>['name'=>'Tax','category'=>'commercial'],
    ];

    private CalculatingEngineService $engines;

    public function __construct(?CalculatingEngineService $engines = null)
    {
        $this->engines = $engines ?? new CalculatingEngineService();
        foreach ([new FormulaRulesEngine(),new PricingEngine(),new QuoteEstimateEngine(),new DiscountPromotionEngine(),new MarginProfitabilityEngine(),new TaxEngine()] as $engine) {
            if (! $this->engines->has($engine->key())) $this->engines->registerEngine($engine);
        }
    }

    /** @return array<string,mixed> */
    public function calculate(int $userId,string $calculator,array $inputs,array $context=[]): array
    { return $this->calculateForTenant(CrmCompanyScope::companyId($userId),$calculator,$inputs,$context); }

    /** @return array<string,mixed> */
    public function calculateForTenant(int $companyId,string $calculator,array $inputs,array $context=[]): array
    {
        $definition=self::DEFINITIONS[$calculator]??null;
        if($definition===null||!$this->engines->has($calculator)) throw new InvalidArgumentException("Unknown CRM commercial calculator: {$calculator}");
        $currency=strtoupper(trim((string)($context['currency']??$inputs['currency']??'AUD')));
        $result=$this->engines->calculate([$calculator],new CalculationContext($companyId,$currency,$inputs,[
            'surface'=>(string)($context['surface']??'crm'),
            'record_type'=>$context['record_type']??null,
            'record_public_id'=>$context['record_public_id']??null,
        ]))->toArray();
        $values=(array)($result['values']??[]);
        $warnings=[];
        if(($values['margin_status']??null)==='approval_required')$warnings[]='Calculated margin is below the supplied minimum and requires review.';
        return [
            'calculator'=>$calculator,'name'=>$definition['name'],'category'=>$definition['category'],'inputs'=>$inputs,
            'results'=>$values,'steps'=>(array)($result['steps']??[]),'warnings'=>$warnings,
            'provenance'=>['authority'=>'deterministic','source'=>'crm-commercial-calculations','company_id'=>$companyId,'currency'=>$currency,'surface'=>(string)($context['surface']??'crm')],
        ];
    }

    /** @return list<string> */
    public function calculators(): array { return array_keys(self::DEFINITIONS); }
}
