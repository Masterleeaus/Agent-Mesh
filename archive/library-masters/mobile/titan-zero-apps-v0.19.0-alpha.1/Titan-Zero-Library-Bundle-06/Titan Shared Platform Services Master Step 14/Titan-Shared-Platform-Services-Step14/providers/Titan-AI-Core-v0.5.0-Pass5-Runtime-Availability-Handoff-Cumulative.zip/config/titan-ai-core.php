<?php

declare(strict_types=1);

return [
    'enabled' => env('TITAN_AI_CORE_ENABLED', true),
    'queue' => env('TITAN_AI_CORE_QUEUE', 'titan-ai-core'),
    'tenant_key' => 'company_id',
    'runtime_kill_switch' => env('TITAN_AI_CORE_KILL_SWITCH', false),
    'execution' => [
        // Pass 4 establishes the governance and Command Bus boundary but does not
        // activate mutation execution. A later governed-execution pass must opt in.
        'execution_enabled' => false,
        'command_bus_only_mutation' => true,
        'denial_state' => 'PENDING_REVIEW',
        'fail_closed_when_gateway_unavailable' => true,
    ],
    'security' => [
        // Tenant identity is resolved only from the authenticated host principal.
        // No request/plan payload may override these trusted attributes.
        'tenant_principal_attributes' => ['company_id', 'tenant_company_id'],
        'reject_payload_identity_overrides' => true,
    ],
    'plan_schema_version' => '1.0',
    'max_plan_duration_seconds' => 86400,
    'host_layout_candidates' => [
        'panel.layout.app',
        'default.panel.layout.app',
        'panel.layout.master',
        'default.panel.layout.master',
    ],
    'orchestrator' => [
        'max_plan_steps' => 64,
        'require_validation' => true,
        'require_simulation' => true,
    ],
    'model_governance' => [
        'shadow_rollout_enabled' => true,
        'default_risk_ceiling' => 'low',
    ],
];
