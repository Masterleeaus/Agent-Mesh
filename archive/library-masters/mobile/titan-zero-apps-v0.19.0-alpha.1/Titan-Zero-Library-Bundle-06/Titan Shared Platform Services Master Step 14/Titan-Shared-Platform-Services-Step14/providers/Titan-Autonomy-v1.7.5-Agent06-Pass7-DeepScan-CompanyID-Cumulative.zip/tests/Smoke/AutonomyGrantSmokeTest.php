<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyAuditSinkContract;
use App\Extensions\TitanAutonomy\System\Contracts\CapabilityStateStoreContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\GateEvaluation;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\HandshakeDecision;
use App\Extensions\TitanAutonomy\System\Enums\RiskClass;
use App\Extensions\TitanAutonomy\System\Services\AutonomyGrantService;

function assertx(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}

$store = new class implements CapabilityStateStoreContract {
    public array $saved = [];
    public function save(CapabilityState $state): void { $this->saved[] = $state; }
};
$audit = new class implements AutonomyAuditSinkContract {
    public array $handshakes = [];
    public function recordGateDecision(array $event): string { return 'gate'; }
    public function recordHandshake(array $event): string { $this->handshakes[] = $event; return 'hs-'.count($this->handshakes); }
    public function recordRegression(array $event): string { return 'reg'; }
};
$service = new AutonomyGrantService($store, $audit, policyVersion: '2026-08-10.v1');
$auto = new CapabilityState(7, 'crm.invoice.issue', 'completed_job_invoice', RiskClass::Medium, AutonomyLevel::Auto, 2, 2, 7, 22);
$gate = new GateEvaluation(true, 2, []);

$denied = $service->grantNextLevel(
    state: $auto,
    requestedLevel: AutonomyLevel::TrustedAuto,
    gate: $gate,
    actorUserId: 42,
    actorCanGrant: true,
    userDecision: HandshakeDecision::Approved,
    aiAssuranceDecision: HandshakeDecision::Denied,
    aiConfidence: 0.61,
    platformReasonCodes: [],
    aiReasonCodes: ['RECENT_MATERIAL_CORRECTIONS'],
    assuranceEvaluationRef: 'assurance-100',
    scope: ['workflow' => 'completed_job_invoice', 'max_total' => 1500],
);
assertx(!$denied->approved, 'AI denial must refuse Trusted Auto grant');
assertx(count($audit->handshakes) === 1, 'Trusted Auto attempt must be persisted');
assertx(($audit->handshakes[0]['final_decision'] ?? null) === 'denied', 'denied handshake must record final denial');
assertx(count($store->saved) === 0, 'denied grant must not mutate state');

$approved = $service->grantNextLevel(
    state: $auto,
    requestedLevel: AutonomyLevel::TrustedAuto,
    gate: $gate,
    actorUserId: 42,
    actorCanGrant: true,
    userDecision: HandshakeDecision::Approved,
    aiAssuranceDecision: HandshakeDecision::Approved,
    aiConfidence: 0.95,
    platformReasonCodes: [],
    aiReasonCodes: ['SUFFICIENT_HISTORY'],
    assuranceEvaluationRef: 'assurance-101',
    scope: ['workflow' => 'completed_job_invoice', 'max_total' => 1500],
);
assertx($approved->approved, 'complete three-way handshake should grant Trusted Auto');
assertx(count($store->saved) === 1, 'approved grant must persist new state');
assertx(($audit->handshakes[1]['final_decision'] ?? null) === 'approved', 'approved handshake must record final approval');
assertx(($audit->handshakes[1]['requested_scope']['max_total'] ?? null) === 1500, 'handshake must preserve exact scope');

echo "OK: AutonomyGrantSmokeTest\n";
