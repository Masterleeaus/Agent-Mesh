<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Enums\LearningLabel;
use App\Extensions\TitanAutonomy\System\Enums\UserResponseClass;

final class SuccessStreakService
{
    /** @return array{streak:int,label:LearningLabel,qualifying:bool} */
    public function apply(
        int $currentStreak,
        UserResponseClass $response,
        bool $minorEditQualifies = false,
        bool $executionSucceeded = true,
        bool $reversed = false,
        bool $unresolvedAssuranceIncident = false,
    ): array {
        if ($reversed || $response === UserResponseClass::Reversed) {
            return ['streak' => 0, 'label' => LearningLabel::Reversed, 'qualifying' => false];
        }
        if (!$executionSucceeded || $response === UserResponseClass::Failed) {
            return ['streak' => 0, 'label' => LearningLabel::Failed, 'qualifying' => false];
        }
        if ($unresolvedAssuranceIncident) {
            return ['streak' => 0, 'label' => LearningLabel::Exception, 'qualifying' => false];
        }
        if ($response === UserResponseClass::ApprovedUnchanged || $response === UserResponseClass::AutonomousVerified) {
            return ['streak' => $currentStreak + 1, 'label' => LearningLabel::Correct, 'qualifying' => true];
        }
        if ($response === UserResponseClass::ApprovedMinorEdit && $minorEditQualifies) {
            return ['streak' => $currentStreak + 1, 'label' => LearningLabel::Correct, 'qualifying' => true];
        }
        return match ($response) {
            UserResponseClass::AutonomousIncorrect => ['streak' => 0, 'label' => LearningLabel::Incorrect, 'qualifying' => false],
            UserResponseClass::ApprovedMaterialEdit => ['streak' => 0, 'label' => LearningLabel::MateriallyCorrected, 'qualifying' => false],
            UserResponseClass::Rejected => ['streak' => 0, 'label' => LearningLabel::Rejected, 'qualifying' => false],
            UserResponseClass::PartiallyCorrect => ['streak' => 0, 'label' => LearningLabel::PartiallyCorrect, 'qualifying' => false],
            UserResponseClass::Exception => ['streak' => 0, 'label' => LearningLabel::Exception, 'qualifying' => false],
            UserResponseClass::Ambiguous => ['streak' => 0, 'label' => LearningLabel::Ambiguous, 'qualifying' => false],
            UserResponseClass::InsufficientInformation => ['streak' => 0, 'label' => LearningLabel::InsufficientInformation, 'qualifying' => false],
            default => ['streak' => 0, 'label' => LearningLabel::Incorrect, 'qualifying' => false],
        };
    }
}
