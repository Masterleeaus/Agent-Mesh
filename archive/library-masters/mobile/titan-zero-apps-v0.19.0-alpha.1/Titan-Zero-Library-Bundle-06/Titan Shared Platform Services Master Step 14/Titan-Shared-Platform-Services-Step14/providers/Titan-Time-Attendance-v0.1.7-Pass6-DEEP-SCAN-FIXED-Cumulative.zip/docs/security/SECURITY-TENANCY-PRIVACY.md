# Security, Tenancy and Privacy

## Tenant boundary

Every owned business record is scoped by `tenant_company_id`. Caller-supplied `company_id`, `tenant_id` and trusted actor/lineage fields are stripped or rejected. CRM company context may be used only through its canonical public tenancy resolver.

## Authorization

All user actions pass `TimeAttendancePermissionService` or the governed capability gateway. Self-service fallback is limited to the authenticated worker's own `view`, `record` and `submit` operations. Cross-worker reads/writes and review, audit and policy actions require explicit permission.

The Workforce manifest is not exposed through a normal authenticated-user HTTP route. It is discovered server-side by Titan Workforce.

## AI execution

- tool access is role allow-listed;
- capability access is separately allow-listed in trusted context;
- risk ceiling is enforced;
- Suggest/Assist cannot execute;
- high-risk actions require Risk/Assurance availability where configured;
- mandatory human approval cannot be self-bypassed;
- AI writes do not fall back to direct Eloquent mutation.

## Attendance evidence

Raw QR tokens and IP addresses are not persisted. Location is HMAC-minimised unless an explicit policy allows raw coordinates. Hashing requires a real host `APP_KEY` and fails closed without it.

## Offline replay

Two tenant-scoped replay barriers are maintained:

1. `tenant_company_id + source_event_id`
2. `tenant_company_id + pseudonymous device_id + device_sequence`

Offline verification exceptions persist fixed reason codes rather than raw exception text.

## Rewind privacy

The Rewind source adapter exports only bounded operational identifiers and status metadata. It intentionally excludes raw coordinates, QR tokens/hashes, IP addresses/hashes, free-text notes and arbitrary stored payload blobs.
