<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * This migration is intentionally self-contained.
     *
     * Titan's extension installer upgrades files inside an already-booted Laravel request.
     * Classes from the previously installed Titan Connect release may therefore remain loaded
     * in PHP memory until the next request. Migration-time code must not call Titan Connect
     * runtime classes or methods that may differ between the old and new release.
     */
    public function up(): void
    {
        if (! Schema::hasTable('menus')) {
            return;
        }

        $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
        $definitions = $this->definitions();

        $roots = array_values(array_filter(
            $definitions,
            static fn (array $item): bool => ($item['parent_key'] ?? null) === null,
        ));
        $children = array_values(array_filter(
            $definitions,
            static fn (array $item): bool => ($item['parent_key'] ?? null) !== null,
        ));

        foreach (array_merge($roots, $children) as $definition) {
            $key = (string) ($definition['key'] ?? '');
            if ($key === '') {
                continue;
            }

            $parentId = null;
            $parentKey = $definition['parent_key'] ?? null;
            if (is_string($parentKey) && $parentKey !== '') {
                $value = DB::table('menus')->where('key', $parentKey)->value('id');
                if (! is_numeric($value)) {
                    // The only external parent is MagicAI's existing Settings root. If a
                    // host does not have it, skip admin fallback rows without blocking install.
                    continue;
                }
                $parentId = (int) $value;
            }

            $now = function_exists('now') ? now() : date('Y-m-d H:i:s');
            $row = [
                'parent_id' => $parentId,
                'key' => $key,
                'route' => $definition['route'] ?? null,
                'route_slug' => null,
                'label' => $definition['label'] ?? $key,
                'icon' => $definition['icon'] ?? null,
                'svg' => null,
                'order' => (int) ($definition['order'] ?? 0),
                'is_active' => 1,
                'params' => '[]',
                'type' => 'item',
                'badge' => null,
                // Titan Connect is not in the legacy MagicAI extension-plan catalogue.
                // Keep DB fallback neutral so normal users are not hidden by plan gating.
                'extension' => null,
                'bolt_menu' => 0,
                'bolt_background' => null,
                'bolt_foreground' => null,
                'letter_icon' => 0,
                'letter_icon_bg' => null,
                'custom_menu' => 0,
                'updated_at' => $now,
            ];

            $row = array_intersect_key($row, $columns);
            $existing = DB::table('menus')->where('key', $key)->first();

            if ($existing !== null) {
                // Preserve administrator-controlled order/enabled state on an existing row.
                unset($row['order'], $row['is_active']);
                DB::table('menus')->where('key', $key)->update($row);
                continue;
            }

            if (isset($columns['created_at'])) {
                $row['created_at'] = $now;
            }
            DB::table('menus')->insert($row);
        }

        $this->regenerateMenuCache();
    }

    public function down(): void
    {
        if (! Schema::hasTable('menus')) {
            return;
        }

        $keys = array_map(
            static fn (array $item): string => (string) $item['key'],
            $this->definitions(),
        );

        DB::table('menus')->whereIn('key', $keys)->delete();
        $this->regenerateMenuCache();
    }

    /** @return array<int,array{parent_key:?string,key:string,route:string,label:string,icon:string,order:int}> */
    private function definitions(): array
    {
        return [
            // User roots.
            ['parent_key' => null, 'key' => 'ext_titan_connect_inbox', 'route' => 'dashboard.user.titan-connect.inbox.unified', 'label' => 'Inbox', 'icon' => 'tabler-inbox', 'order' => 6],
            ['parent_key' => null, 'key' => 'ext_titan_connect_channels', 'route' => 'dashboard.user.titan-connect.channels.index', 'label' => 'Channels', 'icon' => 'tabler-message-cog', 'order' => 7],

            // Channel settings.
            ['parent_key' => 'ext_titan_connect_channels', 'key' => 'titan_connect_channel_whatsapp', 'route' => 'dashboard.user.titan-connect.channels.whatsapp', 'label' => 'WhatsApp', 'icon' => 'tabler-message', 'order' => 1],
            ['parent_key' => 'ext_titan_connect_channels', 'key' => 'titan_connect_channel_messenger', 'route' => 'dashboard.user.titan-connect.channels.messenger', 'label' => 'Messenger', 'icon' => 'tabler-message', 'order' => 2],
            ['parent_key' => 'ext_titan_connect_channels', 'key' => 'titan_connect_channel_instagram', 'route' => 'dashboard.user.titan-connect.channels.instagram', 'label' => 'Instagram', 'icon' => 'tabler-photo', 'order' => 3],
            ['parent_key' => 'ext_titan_connect_channels', 'key' => 'titan_connect_channel_telegram', 'route' => 'dashboard.user.titan-connect.channels.telegram', 'label' => 'Telegram', 'icon' => 'tabler-message', 'order' => 4],
            ['parent_key' => 'ext_titan_connect_channels', 'key' => 'titan_connect_channel_sms', 'route' => 'dashboard.user.titan-connect.channels.sms', 'label' => 'SMS', 'icon' => 'tabler-message', 'order' => 5],
            ['parent_key' => 'ext_titan_connect_channels', 'key' => 'titan_connect_channel_voice', 'route' => 'dashboard.user.titan-connect.channels.voice', 'label' => 'Voice', 'icon' => 'tabler-phone-call', 'order' => 6],
            ['parent_key' => 'ext_titan_connect_channels', 'key' => 'titan_connect_channel_push', 'route' => 'dashboard.user.titan-connect.channels.push', 'label' => 'Push / Mobile', 'icon' => 'tabler-bell-ringing', 'order' => 7],

            // Inbox views.
            ['parent_key' => 'ext_titan_connect_inbox', 'key' => 'titan_connect_inbox_unified', 'route' => 'dashboard.user.titan-connect.inbox.unified', 'label' => 'Unified Inbox', 'icon' => 'tabler-inbox', 'order' => 1],
            ['parent_key' => 'ext_titan_connect_inbox', 'key' => 'titan_connect_inbox_team', 'route' => 'dashboard.user.titan-connect.inbox.team', 'label' => 'Team / Internal', 'icon' => 'tabler-users-group', 'order' => 2],
            ['parent_key' => 'ext_titan_connect_inbox', 'key' => 'titan_connect_inbox_external', 'route' => 'dashboard.user.titan-connect.inbox.external', 'label' => 'External / Omnichannel', 'icon' => 'tabler-world', 'order' => 3],
            ['parent_key' => 'ext_titan_connect_inbox', 'key' => 'titan_connect_inbox_mine', 'route' => 'dashboard.user.titan-connect.inbox.mine', 'label' => 'Assigned to Me', 'icon' => 'tabler-user-check', 'order' => 4],
            ['parent_key' => 'ext_titan_connect_inbox', 'key' => 'titan_connect_inbox_unassigned', 'route' => 'dashboard.user.titan-connect.inbox.unassigned', 'label' => 'Unassigned', 'icon' => 'tabler-user-question', 'order' => 5],
            ['parent_key' => 'ext_titan_connect_inbox', 'key' => 'titan_connect_inbox_needs_human', 'route' => 'dashboard.user.titan-connect.inbox.needs_human', 'label' => 'Needs Human', 'icon' => 'tabler-hand-stop', 'order' => 6],
            ['parent_key' => 'ext_titan_connect_inbox', 'key' => 'titan_connect_inbox_closed', 'route' => 'dashboard.user.titan-connect.inbox.closed', 'label' => 'Closed / Archived', 'icon' => 'tabler-archive', 'order' => 7],

            // Super Admin fallback under the host's existing Settings root/permission family.
            ['parent_key' => 'settings', 'key' => 'titan_connect_admin_settings', 'route' => 'dashboard.admin.settings.titan-connect.channels.index', 'label' => 'Titan Connect', 'icon' => 'tabler-message-cog', 'order' => 90],
        ];
    }

    private function regenerateMenuCache(): void
    {
        $menuService = 'App\\Services\\Common\\MenuService';
        if (! class_exists($menuService) || ! function_exists('app')) {
            return;
        }

        try {
            $service = app($menuService);
            if (is_object($service) && method_exists($service, 'regenerate')) {
                $service->regenerate();
            }
        } catch (Throwable $exception) {
            if (function_exists('report')) {
                report($exception);
            }
        }
    }
};
