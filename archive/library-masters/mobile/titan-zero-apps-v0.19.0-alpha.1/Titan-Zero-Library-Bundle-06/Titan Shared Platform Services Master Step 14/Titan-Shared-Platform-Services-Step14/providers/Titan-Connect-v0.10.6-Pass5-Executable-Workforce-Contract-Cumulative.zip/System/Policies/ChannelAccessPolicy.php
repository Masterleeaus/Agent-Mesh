<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Policies;

use App\Extensions\TitanConnect\System\Models\ChannelConnection;

final class ChannelAccessPolicy
{
    private const VIEW_ROLES = ['owner', 'admin', 'moderator', 'agent', 'viewer'];
    private const SEND_ROLES = ['owner', 'admin', 'moderator', 'agent'];
    private const MODERATE_ROLES = ['owner', 'admin', 'moderator'];
    private const MANAGE_ROLES = ['owner', 'admin'];

    public function canView(ChannelConnection $connection, int $actorId): bool
    {
        return $this->hasRole($connection, $actorId, self::VIEW_ROLES);
    }

    public function canSend(ChannelConnection $connection, int $actorId): bool
    {
        return $this->hasRole($connection, $actorId, self::SEND_ROLES);
    }

    public function canModerate(ChannelConnection $connection, int $actorId): bool
    {
        return $this->hasRole($connection, $actorId, self::MODERATE_ROLES);
    }

    public function canManage(ChannelConnection $connection, int $actorId): bool
    {
        return $this->hasRole($connection, $actorId, self::MANAGE_ROLES);
    }

    private function hasRole(ChannelConnection $connection, int $actorId, array $roles): bool
    {
        return $connection->members()
            ->where('company_id', $connection->company_id)
            ->where('user_id', $actorId)
            ->whereNull('left_at')
            ->whereIn('role', $roles)
            ->exists();
    }
}
