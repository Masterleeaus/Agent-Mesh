# Data Ownership

Canonical domain: `model-deliberation`.

Owned durable state: `titan_model_council_decisions`, `titan_model_council_participants`, `titan_model_council_billing_reservations`, and `model_council_responses`.

Shared compatibility state: `user_openai_chat_messages`. Writes to that table exist solely to preserve the versioned AI Chat/Multi-Model compatibility workflow and are tenant/user/chat scoped. They do not make Model Council authoritative for chat or business-domain records.

Default uninstall policy is retain. Export/retention/deletion must preserve tenant boundaries and audit integrity.
