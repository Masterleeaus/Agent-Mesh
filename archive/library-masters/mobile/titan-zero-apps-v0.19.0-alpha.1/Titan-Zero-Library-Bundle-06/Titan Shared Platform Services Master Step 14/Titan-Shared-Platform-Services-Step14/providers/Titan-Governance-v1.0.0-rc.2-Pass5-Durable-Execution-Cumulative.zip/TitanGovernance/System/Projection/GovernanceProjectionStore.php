<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Projection;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceProjectionSinkContract;
use App\Extensions\TitanGovernance\System\Models\GovernanceProjection;
use Throwable;

final class GovernanceProjectionStore implements GovernanceProjectionSinkContract
{
    public function record(int $tenantCompanyId, string $type, string $sourceEngine, string $status, array $payload, array $meta=[]): bool
    {
        try {
            $payloadHash=hash('sha256',$this->canonicalJson($payload));
            $fingerprint=hash('sha256',implode('|',[(string)$tenantCompanyId,$type,$sourceEngine,$payloadHash]));
            GovernanceProjection::query()->firstOrCreate(
                ['projection_fingerprint'=>$fingerprint],
                [
                    'tenant_company_id'=>$tenantCompanyId,
                    'trace_id'=>$this->uuidOrNull($meta['trace_id'] ?? null),
                    'correlation_id'=>$this->uuidOrNull($meta['correlation_id'] ?? null),
                    'causation_id'=>$meta['causation_id'] ?? null,
                    'root_causation_id'=>$meta['root_causation_id'] ?? null,
                    'type'=>$type,
                    'status'=>strtoupper($status),
                    'payload'=>$payload,
                    'source_engine'=>$sourceEngine,
                    'source_type'=>$meta['source_type'] ?? 'projection',
                    'source_id'=>$meta['source_id'] ?? null,
                    'schema_version'=>(string)($payload['schema_version'] ?? '1.0'),
                    'severity'=>$meta['severity'] ?? null,
                    'observed_at'=>$meta['observed_at'] ?? $payload['observed_at'] ?? null,
                    'expires_at'=>$meta['expires_at'] ?? null,
                    'payload_hash'=>$payloadHash,
                ]
            );
            return true;
        } catch (Throwable) {
            return false;
        }
    }

    /** @return list<array<string,mixed>> */
    public function recent(int $tenantCompanyId, string $type, int $limit=50): array
    {
        try {
            $rows=[];
            $query=GovernanceProjection::query()
                ->where('tenant_company_id',$tenantCompanyId)
                ->where('type',$type)
                ->orderByDesc('id')
                ->limit(max(1,min(200,$limit)));
            foreach($query->cursor() as $row){
                $rows[]=[
                    'source_engine'=>$row->source_engine,
                    'status'=>$row->status,
                    'severity'=>$row->severity,
                    'observed_at'=>$row->observed_at?->toAtomString(),
                    'captured_at'=>$row->created_at?->toAtomString(),
                    'payload'=>$row->payload,
                ];
            }
            return $rows;
        } catch (Throwable) {
            return [];
        }
    }

    private function canonicalJson(array $payload): string
    {
        $normalize=function(mixed $value) use (&$normalize): mixed {
            if (!is_array($value)) return $value;
            if (array_is_list($value)) return array_map($normalize,$value);
            ksort($value);
            foreach($value as $key=>$item) $value[$key]=$normalize($item);
            return $value;
        };
        return (string)json_encode($normalize($payload),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION);
    }

    private function uuidOrNull(mixed $value): ?string
    {
        if (!is_string($value)) return null;
        return preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',$value)===1 ? $value : null;
    }
}
