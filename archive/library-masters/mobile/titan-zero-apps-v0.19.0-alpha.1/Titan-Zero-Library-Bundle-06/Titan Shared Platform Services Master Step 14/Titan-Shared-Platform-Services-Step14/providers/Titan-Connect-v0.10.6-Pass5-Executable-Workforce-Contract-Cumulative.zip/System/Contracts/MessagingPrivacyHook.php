<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

interface MessagingPrivacyHook
{
    public function beforeExport(int $companyId, int $actorId): void;

    /** @return array<string, mixed> */
    public function requestDeletion(int $companyId, int $actorId, array $context = []): array;
}
