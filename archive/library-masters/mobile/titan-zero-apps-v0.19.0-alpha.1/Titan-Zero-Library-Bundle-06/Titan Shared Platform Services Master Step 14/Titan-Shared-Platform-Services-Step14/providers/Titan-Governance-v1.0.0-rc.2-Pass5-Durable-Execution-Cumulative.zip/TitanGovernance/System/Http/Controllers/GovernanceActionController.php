<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Http\Controllers;

use App\Extensions\TitanGovernance\System\Actions\GovernanceActionRequest;
use App\Extensions\TitanGovernance\System\Context\TenantCompanyResolver;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceManagerContract;
use App\Extensions\TitanGovernance\System\Host\TitanHostAuthorizationAdapter;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class GovernanceActionController
{
    public function __construct(
        private readonly GovernanceManagerContract $governance,
        private readonly TenantCompanyResolver $tenants,
        private readonly TitanHostAuthorizationAdapter $authorization,
    ) {}

    public function queue(Request $request): JsonResponse|View
    {
        $user=$request->user();
        abort_unless($user && $this->authorization->allows($user,'titan-governance.escalations.view',['titan-governance.escalations.view']),403);
        $tenantCompanyId=$this->tenants->resolve($user);
        $payload=['items'=>$this->governance->escalationQueue($tenantCompanyId,50)];
        if($request->expectsJson()) return response()->json($payload);
        return view('titan-governance::escalations',[
            'tenantCompanyId'=>$tenantCompanyId,
            'items'=>$payload['items'],
        ]);
    }

    public function execute(Request $request,string $escalationId,string $action): JsonResponse|RedirectResponse
    {
        $user=$request->user();
        abort_unless($user && $this->authorization->allows($user,'titan-governance.escalations.act',['titan-governance.escalations.act']),403);
        $normalized=strtoupper(trim($action));
        abort_unless(in_array($normalized,['APPROVE','REJECT','HOLD','EXCEPTION','ESCALATE'],true),404);
        if($normalized==='EXCEPTION') abort_unless($this->authorization->allows($user,'titan-governance.exceptions.grant',['titan-governance.exceptions.grant']),403);

        $tenantCompanyId=$this->tenants->resolve($user);
        $actorId=$this->actorId($user);
        $trace=(string)Str::ulid();
        $causal=[
            'trace_id'=>$trace,
            'correlation_id'=>(string)Str::ulid(),
            'causation_id'=>null,
            'root_causation_id'=>$trace,
        ];

        try {
            $input=[
                'operation_id'=>(string)$request->input('operation_id',''),
                'action'=>$normalized,
                'escalation_id'=>$escalationId,
                'expected_version'=>(int)$request->input('expected_version',0),
                'reason_codes'=>$this->stringList($request->input('reason_codes',[])),
                'evidence_refs'=>$this->stringList($request->input('evidence_refs',[])),
            ];
            $command=GovernanceActionRequest::fromClient($input,$tenantCompanyId,$actorId,$causal);
            $result=$this->governance->performEscalationAction($command);
        } catch (InvalidArgumentException $e) {
            return $this->respond($request,['status'=>'INVALID','reason_code'=>'ACTION_REQUEST_INVALID','message'=>$e->getMessage()],422);
        }

        $status=(string)($result['status']??'FAILED');
        $code=match($status){
            'APPLIED','REPLAYED'=>200,
            'IDEMPOTENCY_CONFLICT'=>409,
            'BLOCKED','UNAVAILABLE'=>503,
            default=>422,
        };
        return $this->respond($request,$result,$code);
    }

    /** @return list<string> */
    private function stringList(mixed $value): array
    {
        if($value===null || $value==='') return [];
        if(!is_array($value)) $value=[$value];
        $out=[];
        foreach($value as $item) if(is_scalar($item) && trim((string)$item)!=='') $out[]=trim((string)$item);
        return array_values(array_unique($out));
    }

    private function actorId(object $user): string
    {
        if(method_exists($user,'getAuthIdentifier')) {
            $id=$user->getAuthIdentifier();
            if(is_scalar($id) && trim((string)$id)!=='') return (string)$id;
        }
        $id=$user->id??null;
        if(is_scalar($id) && trim((string)$id)!=='') return (string)$id;
        throw new InvalidArgumentException('Authenticated actor identifier unavailable');
    }

    /** @param array<string,mixed> $result */
    private function respond(Request $request,array $result,int $status): JsonResponse|RedirectResponse
    {
        if($request->expectsJson()) return response()->json($result,$status);
        return redirect()->back()->with('governance_action_result',$result);
    }
}
