<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use App\Extensions\TitanSignalEngine\System\Exceptions\ImmutableRegistryDefinitionException;
use Illuminate\Database\Eloquent\Model;

/**
 * Legacy v0.2 registry projection retained for upgrade compatibility only.
 * New control-plane writes use SignalTypeVersion.
 */
final class SignalType extends Model
{
    protected $table = 'titan_signal_types';
    protected $guarded = [];

    protected $casts = [
        'current_schema_version' => 'integer',
        'supported_schema_versions' => 'array',
        'allowed_scopes' => 'array',
        'required_payload_fields' => 'array',
        'optional_payload_fields' => 'array',
        'allow_additional_payload_fields' => 'boolean',
        'allowed_severities' => 'array',
    ];

    protected static function booted(): void
    {
        static::updating(static function (): never {
            throw new ImmutableRegistryDefinitionException('Legacy Signal event type rows are read-only; evolve the versioned registry instead.');
        });
        static::deleting(static function (): never {
            throw new ImmutableRegistryDefinitionException('Legacy Signal event type rows cannot be deleted through the application model.');
        });
    }
}
