<?php

declare(strict_types=1);

namespace Tests\Security;

use PHPUnit\Framework\TestCase;

final class KnowledgeAuthorityPolicyTest extends TestCase
{
    public function test_authority_policy_forbids_llm_precedence_and_cross_domain_writes(): void
    {
        $root = dirname(__DIR__, 2);
        $manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);

        self::assertSame('forbidden', $manifest['authority']['cross_domain_write_policy']);
        self::assertFalse($manifest['knowledge_authority']['llm_may_assign_authority']);
        self::assertFalse($manifest['knowledge_authority']['llm_may_resolve_equal_rank_conflict']);
        self::assertFalse($manifest['knowledge_authority']['offline_authority_promotion']);
        self::assertTrue($manifest['governance']['offline_never_increases_authority']);
    }
}
