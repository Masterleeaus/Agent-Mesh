# Phase 4 — Capability execution and company boundary

## Tenant invariant

`company_id` is the sole authority-bearing tenant boundary for WorkCore-connected execution.

Legacy `tenant_id` fields remain only where older Interaction Engine envelopes or persistence contracts require them. When present, `tenant_id` must be an exact mirror of the trusted `company_id`; it can never select or switch company context. `team_id` is not a tenant boundary.

## Capability truth model

Phase 4 separates three concepts that were previously conflated:

1. **Declared** — the wizard/template catalogue names the capability.
2. **Supported/mapped** — a domain adapter has an explicit service or governed WorkCore action mapping.
3. **Available** — the mapping can actually execute for the current trusted company context.

`CapabilityRegistry::has()` is retained as a compatibility alias, but now means executable availability rather than mere registration.

The current wizard catalogue declares 29 unique capabilities. Every one is present in `config/interaction-engine.php` under `capability_actions`. Unverified WorkCore action keys are deliberately `null`; those capabilities remain declared but unavailable and therefore fail closed.

## Current verified governed mappings

Only mappings already evidenced by the supplied source are enabled by default:

- `crm.customer.create` -> `workcore.customer.create`
- `jobs.create` -> `workcore.work_order.create`
- `jobs.complete` -> `workcore.work_order.change_status`

Other capability mappings require connected-host verification before being enabled. No guessed WorkCore service/action names are shipped as executable mappings.

## Company-safe execution path

The online path is now:

```text
Authenticated actor
    -> trusted TenantExecutionContext(company_id)
    -> wizard/command context(company_id)
    -> CapabilityRegistry availability check
    -> WorkCoreAdapter
    -> GovernedWorkCoreDispatcher
    -> active WorkCore company context cross-check
    -> verified WorkCore action/service
```

Execution is rejected if:

- trusted `company_id` is absent;
- command `company_id` differs from the scoped execution company;
- a legacy `tenant_id` alias differs from `company_id`;
- the active WorkCore company differs from the Interaction Engine company;
- the capability has no verified adapter mapping;
- authority policy or required approval is not satisfied.

When a wizard capability is unavailable online, the wizard does not claim success. It takes the existing safe offline/deferred path instead.

## Authority

Every ready wizard capability receives a conservative human-actor policy by default. More restrictive explicit policies continue to override that baseline. This prevents a newly connected WorkCore mapping from becoming automatically executable merely because the adapter reports it available.

Signed approvals are company-scoped and contain `company_id`. A legacy `tenant_id` alias, when emitted for compatibility, mirrors the same company ID and is checked for equality.

## Offline replay

Offline replay requires `metadata.company_id`, then compares it with the server-resolved authenticated company. Client metadata cannot select the tenant. Roles/scopes are reconstructed server-side. A legacy `metadata.tenant_id`, if supplied, is only a compatibility assertion and must equal `company_id`.

## Remaining connected-host gates

Phase 4 does not fabricate WorkCore mappings. Before marketplace release, run against the real MagicAI/WorkCore installation and verify:

- provider discovery and host boot;
- the active WorkCore tenant-context contract uses `company_id` as expected;
- two-company isolation with real records;
- every WorkCore action/service key before changing a `null` capability mapping to executable;
- authority/approval behaviour for each newly enabled mutation;
- end-to-end create/update flows and transaction rollback behaviour.
