<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;

final class DurableMissionStoreBoundaryTest extends TestCase
{
    public function test_repository_is_tenant_scoped_and_uses_atomic_version_compare_and_swap(): void
    {
        $source = (string) file_get_contents(__DIR__ . '/../../System/Persistence/Repositories/DatabasePrimeMissionRepository.php');

        self::assertStringContainsString("->where('tenant_company_id', \$tenantCompanyId)", $source);
        self::assertStringContainsString("->where('lock_version', \$expectedVersion)", $source);
        self::assertStringContainsString("'lock_version' => \$expectedVersion + 1", $source);
        self::assertStringContainsString("->where('operation_id', \$operationId)", $source);
        self::assertStringContainsString("'payload_hash' => \$receipt->payloadHash", $source);
        self::assertStringNotContainsString('DB::' . 'table(', $source);
    }

    public function test_durable_store_schema_has_tenant_identity_idempotency_and_expiry_guards(): void
    {
        $missionMigration = (string) file_get_contents(__DIR__ . '/../../database/migrations/2026_08_19_000003_upgrade_titan_prime_missions_for_durable_store.php');
        $operationMigration = (string) file_get_contents(__DIR__ . '/../../database/migrations/2026_08_19_000004_create_titan_prime_mission_operations_table.php');

        self::assertStringContainsString("unique(['tenant_company_id', 'mission_id']", $missionMigration);
        self::assertStringContainsString("'lock_version'", $missionMigration);
        self::assertStringContainsString("'record_format'", $missionMigration);
        self::assertStringContainsString("unique(['tenant_company_id', 'operation_id']", $operationMigration);
        self::assertStringContainsString("'payload_hash'", $operationMigration);
        self::assertStringContainsString("'expires_at'", $operationMigration);
    }

    public function test_provider_binds_repository_contract_to_database_adapter(): void
    {
        $provider = (string) file_get_contents(__DIR__ . '/../../System/TitanPrimeServiceProvider.php');

        self::assertStringContainsString('PrimeMissionRepositoryContract::class, DatabasePrimeMissionRepository::class', $provider);
    }
}
