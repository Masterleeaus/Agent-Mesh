# Uninstall

Default policy retains business data unless an explicit governed retention policy authorizes deletion. Provider disable/removal does not mutate Workforce identity or grant fallback authority.
