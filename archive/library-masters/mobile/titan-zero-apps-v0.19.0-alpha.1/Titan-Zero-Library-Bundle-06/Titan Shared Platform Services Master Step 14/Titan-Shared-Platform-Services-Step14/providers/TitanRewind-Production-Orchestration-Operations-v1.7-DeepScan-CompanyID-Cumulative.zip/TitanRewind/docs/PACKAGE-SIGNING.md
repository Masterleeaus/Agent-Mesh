# Titan Rewind v1.0.6 Package Signing

The final cumulative v1.0.6 installer ZIP is signed externally with **RSA-3072 / SHA-256** after the archive bytes are frozen.

- Public key: `docs/RELEASE-PUBLIC-KEY.txt`
- Public-key DER SHA-256 fingerprint: `4ae5462b3645bed85c31bcc31a4ffaf787c89b40edd1c955b88120ea1fcb5c40`
- Private release key: generated outside the extension tree, used only to sign the final ZIP, then deleted.
- Detached signature record: shipped beside the ZIP, not inside it.

Package signing is distinct from Rewind evidence signing. Evidence signing keys remain host/runtime configuration and are never replaced by the release key.
