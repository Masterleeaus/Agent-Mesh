<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Sources;
use App\Extensions\TitanRewind\System\Contracts\RewindSourceAdapterContract;
use App\Extensions\TitanRewind\System\Contracts\RewindSourceWatermarkProviderContract;
use App\Extensions\TitanRewind\System\Reconstruction\RewindEventRecord;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use InvalidArgumentException;
final class RewindHostSourceAdapter implements RewindSourceAdapterContract, RewindSourceWatermarkProviderContract
{
    public function __construct(private object $source){ foreach(['sourceKey','watermark','records'] as $m) if(!method_exists($source,$m)) throw new InvalidArgumentException("Host Rewind source is missing {$m}()."); }
    public function key(): string { $key=trim((string)$this->source->sourceKey()); if($key===''||strlen($key)>120) throw new InvalidArgumentException('Invalid host Rewind source key.'); return $key; }
    public function watermark(RewindTraceQuery $query): array
    {
        $w=$this->source->watermark($query->tenantCompanyId(),$query->traceId()); if(!is_array($w)) throw new InvalidArgumentException('Host Rewind watermark must be an array.');
        $state=strtoupper((string)($w['state']??'UNAVAILABLE')); if(!in_array($state,['COMPLETE','PARTIAL','STALE','UNAVAILABLE'],true)) throw new InvalidArgumentException('Host Rewind watermark state is invalid.');
        $lagMs=max(0,(int)($w['source_lag_ms']??0)); return ['state'=>$state,'observed_through'=>isset($w['observed_through'])?(string)$w['observed_through']:null,'source_lag_seconds'=>(int)ceil($lagMs/1000),'metadata'=>['cursor'=>$w['cursor']??null,'source_lag_ms'=>$lagMs,'authenticity_state'=>(string)($w['authenticity_state']??'UNKNOWN')]];
    }
    public function records(RewindTraceQuery $query): iterable
    {
        foreach($this->source->records($query->tenantCompanyId(),$query->traceId(),null) as $raw){ if(!is_array($raw)) throw new InvalidArgumentException('Host Rewind sources must yield normalized arrays.'); $record=RewindEventRecord::fromArray($raw); if($record->tenantCompanyId()!==$query->tenantCompanyId()||$record->traceId()!==$query->traceId()) throw new InvalidArgumentException('Host Rewind source record crossed the requested tenant/trace boundary.'); yield $record; }
    }
}
