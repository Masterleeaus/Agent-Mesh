<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_knowledge_source_versions')) {
            Schema::create('titan_knowledge_source_versions', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('source_id')->constrained('titan_knowledge_sources')->cascadeOnDelete();
                $table->unsignedInteger('version_sequence');
                $table->string('version_key', 190);
                $table->char('content_hash', 64)->index();
                $table->char('raw_evidence_hash', 64)->index();
                $table->string('content_type', 120)->nullable();
                $table->text('content_storage_ref')->nullable();
                $table->timestamp('retrieved_at')->index();
                $table->timestamp('published_at')->nullable()->index();
                $table->timestamp('effective_from')->nullable()->index();
                $table->timestamp('effective_until')->nullable()->index();
                $table->foreignId('supersedes_version_id')->nullable()->constrained('titan_knowledge_source_versions')->nullOnDelete();
                $table->string('etag', 255)->nullable();
                $table->text('last_modified')->nullable();
                $table->boolean('immutable')->default(true);
                $table->json('provenance');
                $table->json('metadata')->nullable();
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
                $table->uuid('trace_id')->nullable()->index();
                $table->uuid('correlation_id')->nullable()->index();
                $table->uuid('causation_id')->nullable()->index();
                $table->timestamps();
                $table->unique(['source_id', 'version_sequence'], 'tka_source_versions_sequence_unique');
                $table->unique(['source_id', 'content_hash'], 'tka_source_versions_hash_unique');
                $table->unique(['source_id', 'version_key'], 'tka_source_versions_key_unique');
            });
        }

        if (! Schema::hasTable('titan_knowledge_documents')) {
            Schema::create('titan_knowledge_documents', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('source_version_id')->constrained('titan_knowledge_source_versions')->cascadeOnDelete();
                $table->string('document_key', 190);
                $table->string('title', 500)->nullable();
                $table->string('document_type', 120)->default('document')->index();
                $table->char('content_hash', 64)->nullable()->index();
                $table->timestamp('effective_from')->nullable()->index();
                $table->timestamp('effective_until')->nullable()->index();
                $table->json('metadata')->nullable();
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
                $table->uuid('trace_id')->nullable()->index();
                $table->uuid('correlation_id')->nullable()->index();
                $table->uuid('causation_id')->nullable()->index();
                $table->timestamps();
                $table->unique(['source_version_id', 'document_key'], 'tka_documents_version_key_unique');
            });
        }

        if (! Schema::hasTable('titan_knowledge_sections')) {
            Schema::create('titan_knowledge_sections', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('document_id')->constrained('titan_knowledge_documents')->cascadeOnDelete();
                $table->foreignId('parent_section_id')->nullable()->constrained('titan_knowledge_sections')->nullOnDelete();
                $table->string('section_key', 190);
                $table->string('heading', 500)->nullable();
                $table->unsignedInteger('ordinal')->default(0)->index();
                $table->char('content_hash', 64)->nullable()->index();
                $table->longText('normalized_text')->nullable();
                $table->text('content_storage_ref')->nullable();
                $table->json('metadata')->nullable();
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
                $table->uuid('trace_id')->nullable()->index();
                $table->uuid('correlation_id')->nullable()->index();
                $table->uuid('causation_id')->nullable()->index();
                $table->timestamps();
                $table->unique(['document_id', 'section_key'], 'tka_sections_document_key_unique');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_knowledge_sections');
        Schema::dropIfExists('titan_knowledge_documents');
        Schema::dropIfExists('titan_knowledge_source_versions');
    }
};
