# Titan Installer Package Contract

This release is packaged for the Titan custom-extension installer.

- schema: `titan-extension-v1`
- slug: `titan-ai`
- folder: `TitanAI`
- provider: `App\Extensions\TitanAI\System\TitanAIServiceProvider`
- install target: `app/Extensions/TitanAI/`
- canonical tenant boundary: `company_id`
- required PHP: `>=8.2`
- required MagicAI: `>=10.91`
- publish tag: `titan-ai-config`

The release ZIP is intentionally flat: `extension.json`, `System/`, `config/`, `database/`, and other extension content are at archive root. Titan uses `folder` to choose the deployment directory.

The `integrity` object in `extension.json` covers every packaged regular file except `extension.json` itself, which cannot self-hash without recursion. Registry signatures remain a registry/publisher concern and are not fabricated by this package.

## Installer 1.2.0 dependency shape

Titan Extension Manager 1.2.0 validates dependency entries as objects. `dependencies` and `optional_dependencies` must be JSON arrays. Each non-empty dependency entry must contain a `slug`; use `version` for its semantic-version constraint.

Example:

```json
{
  "dependencies": [
    {
      "slug": "titan-ai",
      "version": ">=1.5.3"
    }
  ],
  "optional_dependencies": []
}
```

Do not use the older map form such as `{ "titan-ai": ">=1.5.3" }`; installer build 1.2.0 rejects it with `Each dependencies entry must contain a slug.`
