# Governed Spatial Intelligence

Titan Maps Intelligence is Titan's geospatial operational-intelligence extension. CRM remains authoritative for jobs, customers and addresses. Maps stores company-scoped geographic projections, route/territory evidence and Maps-owned workflow state; it does not become a competing CRM or orchestration engine.

## Canonical spatial capabilities

| Capability | Purpose | Typical authority |
|---|---|---|
| `location.geocode` | Resolve a postal address to provider-backed coordinates | provider observation write |
| `territory.lookup` | Return matching territory evidence | read/derived evidence |
| `territory.validate` | Validate a target against active territory rules | read/derived evidence |
| `route.estimate` | Return road route/ETA or explicit stale/estimate fallback | provider observation write |
| `route.compare` | Compare multiple destinations using route-matrix evidence | provider observation write |
| `job.travel_context` | Resolve an authorised CRM/WorkCore job reference to geographic/travel/territory/jurisdiction context | provider observation write |
| `service_area.check` | Return service-area eligibility and exclusions | read/derived evidence |
| `nearby.search` | Rank nearby workers/suppliers/contractors with travel provenance | provider observation write |

The 31 pre-Pass-17 `titan-maps-intelligence.*` capability IDs remain registered for compatibility. Each of the 39 definitions exposes owner, input/output schema, risk profile, autonomy requirement, evidence requirements, offline policy, reversibility, idempotency strategy and mutation class.

## Engine boundaries

Pass 17 uses optional adapter contracts rather than hard dependencies:

- Titan Risk: contextual authorization evidence; explicit denial stops execution.
- Titan Assurance: evidence-strength context; absence is reported, never fabricated.
- Titan Autonomy: effective authority; explicit denial stops execution. AI/system Maps mutations require an available autonomy decision.
- Titan Command Bus: authoritative cross-extension mutation. AI promotion and CRM job assignment must pass through this boundary.
- Titan Signal: structured lifecycle, routing failure/fallback, territory conflict and geospatial anomaly events.
- Titan Rewind: structured decision receipts and references; no hidden chain-of-thought is persisted.
- Titan Knowledge Authority: optional jurisdiction/knowledge references for job travel context.
- Titan Go: consumes the offline capability manifest; offline policy can reduce authority but cannot increase it.

If a platform engine is not installed, Maps keeps installing and its read/low-risk features remain available according to policy. It never invents a positive governance result. Consequential AI mutations fail closed when the required engine evidence is unavailable.

## Trace contract

Governed execution propagates:

- `trace_id`
- `correlation_id`
- `causation_id`
- server-derived `tenant_company_id`
- actor/user/agent references
- capability ID and execution origin

Tool callers cannot provide or override tenant/company identifiers. For installer/database compatibility, existing Maps-owned tables retain their historical `company_id` column; externally governed contracts and receipts expose that same server-derived tenant boundary as `tenant_company_id` rather than introducing a destructive tenant-column migration. Structured decision receipts contain reason codes, evidence references and engine/Command Bus/Rewind references but never unrestricted model reasoning.

## Command boundary

Maps may own Maps state such as territory definitions, route-plan revisions and candidate-review decisions. It does not directly mutate authoritative CRM assignment/vendor state from AI tools. The CRM assignment gateway now emits canonical `job.assign` through `SpatialCommandBusGateway`; promotion paths are classified as authoritative mutations and require the governed execution envelope.

## Signal contract

Canonical structured signals include:

- `maps.capability.executed`
- `maps.capability.denied`
- `maps.capability.failed`
- `maps.route.failed`
- `maps.route.fallback_used`
- `maps.territory.conflict`
- `maps.service_area.excluded`
- `maps.geospatial.anomaly`
- `maps.worker_location.accepted`

Signal payloads avoid raw worker/target coordinates where identifiers and structured evidence are sufficient.

## Offline policy

The offline capability manifest exposes only governance metadata, never provider credentials or handler internals. Policies are one of:

- `ONLINE_EXECUTE`
- `OFFLINE_EXECUTE`
- `OFFLINE_PREPARE_ONLY`
- `OFFLINE_BLOCKED`

Authoritative cross-extension mutation is offline-blocked; Maps-owned consequential mutation is prepare-only; deterministic cached territory/service-area reads may execute offline. Reconnect must revalidate server state and governance before mutation execution.
