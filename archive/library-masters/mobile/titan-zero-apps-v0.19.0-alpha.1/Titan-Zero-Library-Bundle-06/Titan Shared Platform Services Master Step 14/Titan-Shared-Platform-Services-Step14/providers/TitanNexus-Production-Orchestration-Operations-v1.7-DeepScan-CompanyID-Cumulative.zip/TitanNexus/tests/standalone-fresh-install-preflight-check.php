<?php

declare(strict_types=1);

$root = dirname(__DIR__);
require_once $root . '/System/Host/TitanInstallerManifestContract.php';
require_once $root . '/System/Host/TitanPackageIntegrityBuilder.php';
require_once $root . '/System/Host/TitanMySqlMigrationCompatibility.php';
require_once $root . '/System/Host/TitanFreshInstallPreflight.php';

use App\Extensions\TitanNexus\System\Host\TitanFreshInstallPreflight;

function fiFail(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function fiAssert(bool $condition, string $message): void { if (!$condition) fiFail($message); }

$result = TitanFreshInstallPreflight::verifyDirectory($root);
fiAssert(($result['status'] ?? null) === 'PASS', 'fresh install directory preflight passes');
fiAssert(($result['checks']['installer_manifest'] ?? false) === true, 'installer manifest validated');
fiAssert(($result['checks']['provider_identity'] ?? false) === true, 'provider identity validated');
fiAssert(($result['checks']['migration_sequence'] ?? false) === true, 'migration sequence validated');
fiAssert(($result['checks']['routes_and_views'] ?? false) === true, 'routes/controllers/views validated');
fiAssert(($result['checks']['config_publish'] ?? false) === true, 'config publishing validated');
fiAssert(($result['checks']['interface_manifest'] ?? false) === true, 'interface contribution validated');
fiAssert(($result['checks']['navigation_wiring'] ?? false) === true, 'navigation wiring validated');
fiAssert(($result['migration_count'] ?? 0) === 6, 'all six current migrations included in fresh install order');

$compatible = TitanFreshInstallPreflight::evaluateHostFacts([
    'php' => '8.3.33',
    'laravel' => '10.50.2',
    'database' => 'mysql',
    'installer' => '1.7.8',
]);
fiAssert(($compatible['compatible'] ?? false) === true, 'exact supported host facts accepted');

$live176 = TitanFreshInstallPreflight::evaluateHostFacts([
    'php' => '8.3.33',
    'laravel' => '10.50.2',
    'database' => 'mysql',
    'installer' => '1.7.6',
]);
fiAssert(($live176['compatible'] ?? false) === true, 'live Installer 1.7.6 host facts accepted');

$wrongPhp = TitanFreshInstallPreflight::evaluateHostFacts([
    'php' => '8.4.23',
    'laravel' => '10.50.2',
    'database' => 'mysql',
    'installer' => '1.7.8',
]);
fiAssert(($wrongPhp['compatible'] ?? true) === false, 'wrong PHP minor is not live-host certified');
fiAssert(in_array('php_version_mismatch', $wrongPhp['reasons'] ?? [], true), 'PHP mismatch reason exposed');

$wrongInstaller = TitanFreshInstallPreflight::evaluateHostFacts([
    'php' => '8.3.33',
    'laravel' => '10.50.2',
    'database' => 'mysql',
    'installer' => '1.7.7',
]);
fiAssert(($wrongInstaller['compatible'] ?? true) === false, 'wrong Installer version rejected');
fiAssert(in_array('installer_version_mismatch', $wrongInstaller['reasons'] ?? [], true), 'Installer mismatch reason exposed');

$tool = (string) file_get_contents($root . '/tools/fresh_install_preflight.php');
fiAssert(str_contains($tool, 'TitanFreshInstallPreflight'), 'fresh install preflight CLI is wired');
$certTool = (string) file_get_contents($root . '/tools/exact_host_certification.php');
fiAssert(str_contains($certTool, 'print-sequence'), 'exact host certification exposes live acceptance sequence');
fiAssert(str_contains($certTool, 'boot_provider'), 'live acceptance sequence includes provider boot');

$template = json_decode((string) file_get_contents($root . '/certification/host-certification-report.template.json'), true, 512, JSON_THROW_ON_ERROR);
fiAssert(($template['stages']['INSTALLER_CERTIFIED']['status'] ?? null) === 'NOT_RUN', 'fresh preflight does not falsely certify live installer');

fwrite(STDOUT, "PASS: Titan Nexus fresh install preflight checks\n");
