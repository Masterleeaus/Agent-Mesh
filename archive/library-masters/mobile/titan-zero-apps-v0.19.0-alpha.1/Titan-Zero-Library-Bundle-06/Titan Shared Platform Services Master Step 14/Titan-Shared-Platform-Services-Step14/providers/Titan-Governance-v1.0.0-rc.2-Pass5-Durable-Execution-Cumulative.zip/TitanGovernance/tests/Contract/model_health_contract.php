<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);function fail_mh(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function same_mh(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_mh($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
$f=$root.'/System/ControlCentre/ModelHealthProjector.php';if(!is_file($f))fail_mh('missing ModelHealthProjector.php');require_once $f;
use App\Extensions\TitanGovernance\System\ControlCentre\ModelHealthProjector;
$sources=[
 'titan-model-council'=>['source'=>'titan-model-council','status'=>'HEALTHY','observed_at'=>'2026-08-21T02:40:00+10:00','control_centre'=>[
   'models'=>[
      ['model_id'=>'gpt-main','provider'=>'provider-a','version'=>'2','previous_version'=>'1','status'=>'HEALTHY','transition_status'=>'COMPLETED','drift_score'=>0.08,'observed_at'=>'2026-08-21T02:39:00+10:00','reference'=>'model:1'],
      ['model_id'=>'backup','provider'=>'provider-b','version'=>'4','previous_version'=>'3','status'=>'DEGRADED','transition_status'=>'ROLLING_OUT','drift_score'=>0.42,'observed_at'=>'2026-08-21T02:39:00+10:00','reference'=>'model:2'],
      ['model_id'=>'broken','provider'=>'provider-c','version'=>'9','status'=>'FAILED','transition_status'=>'FAILED','drift_score'=>0.7,'observed_at'=>'2026-08-21T02:38:00+10:00','reference'=>'model:3'],
   ],
   'council'=>['status'=>'HEALTHY','disagreement_score'=>0.78,'material_disagreement'=>true,'participant_count'=>5,'observed_at'=>'2026-08-21T02:39:30+10:00','reference'=>'council:22'],
 ]],
];
$p=new ModelHealthProjector();$r=$p->project($sources,['now'=>'2026-08-21T02:41:00+10:00','fresh_after_seconds'=>600]);
same_mh('DEGRADED',$r['status'],'failed/degraded models must degrade model health');same_mh(3,count($r['models']),'model count');
$by=[];foreach($r['models'] as $m)$by[$m['model_id']]=$m;
same_mh('HEALTHY',$by['gpt-main']['health'],'completed healthy transition');same_mh('TRANSITIONING',$by['backup']['health'],'rolling out degraded model represented as transitioning');same_mh('FAILED',$by['broken']['health'],'failed transition');same_mh(0.42,$by['backup']['drift_score'],'drift preserved');
same_mh('HIGH',$r['council']['disagreement_level'],'council disagreement band');same_mh(true,$r['council']['material_disagreement'],'material disagreement preserved');same_mh(5,$r['council']['participant_count'],'participant count preserved');same_mh(false,$r['council']['changes_authority'],'council disagreement cannot directly change authority');
$stale=$p->project(['x'=>['source'=>'x','status'=>'HEALTHY','control_centre'=>['models'=>[['model_id'=>'old','status'=>'HEALTHY','transition_status'=>'COMPLETED','observed_at'=>'2026-08-20T00:00:00+10:00']]]]],['now'=>'2026-08-21T02:41:00+10:00','fresh_after_seconds'=>600]);same_mh('STALE',$stale['models'][0]['health'],'stale model evidence must not stay healthy');
echo "PASS: Governance model/council health contract\n";
