<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Contracts;

use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningReceipt;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;

interface ProvisioningCommandGatewayContract
{
    public function execute(ProvisioningOperation $operation, TraceContext $traceContext): ProvisioningReceipt;
}
