<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\Tests\Architecture;

use PHPUnit\Framework\TestCase;

final class BoundaryTest extends TestCase
{
    public function test_manifest_declares_canonical_governance_boundary(): void
    {
        $manifest=json_decode((string)file_get_contents(dirname(__DIR__,2).'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
        self::assertSame('governance-engine',$manifest['architecture']['profile']);
        self::assertContains('governance-control-plane',$manifest['authority']['owns']);
        self::assertSame('command-bus-only',$manifest['authority']['cross_domain_write_policy']);
        self::assertTrue($manifest['governance']['external_constraints_are_upper_bounds']);
        self::assertFalse($manifest['governance']['governance_may_raise_earned_authority']);
    }
}
