<?php

declare(strict_types=1);

namespace Illuminate\View {
    final class View
    {
        public function __construct(
            public string $name,
            private string $html = '',
            private ?Factory $factory = null,
        ) {}

        public function render(): string
        {
            if ($this->name === 'titan-connect::probe') {
                $this->factory?->push('css', '<link data-probe-css>');
                $this->factory?->push('script', '<script data-probe-script></script>');
            }

            return $this->html;
        }
    }

    final class Factory
    {
        public int $renderCount = 0;
        /** @var array<string,string> */
        public array $sections = [];
        /** @var array<string,list<string>> */
        public array $pushes = [];
        /** @var list<string> */
        public array $made = [];
        public bool $flushed = false;

        public function incrementRender(): void { $this->renderCount++; }
        public function decrementRender(): void { $this->renderCount--; }
        public function flushState(): void { $this->flushed = true; $this->sections = []; $this->pushes = []; }
        public function startSection(string $name, mixed $content = ''): void { $this->sections[$name] = (string) $content; }
        public function push(string $name, string $content): void { $this->pushes[$name][] = $content; }

        /** @param array<string,mixed> $data */
        public function make(string $name, array $data = []): View
        {
            $this->made[] = $name;
            if ($name === 'titan-connect::probe') {
                return new View($name, '<main data-titan-content>Inbox</main>', $this);
            }
            if ($name === 'panel.layout.app') {
                return new View($name, '<html><body>HOST SHELL</body></html>', $this);
            }
            throw new \RuntimeException('Unexpected view '.$name);
        }
    }
}

namespace {
    require dirname(__DIR__, 2).'/System/View/MagicAiDashboardRenderer.php';

    use App\Extensions\TitanConnect\System\View\MagicAiDashboardRenderer;
    use Illuminate\View\Factory;

    $factory = new Factory();
    $renderer = new MagicAiDashboardRenderer($factory);
    $root = $renderer->render('titan-connect::probe', ['company_id' => 7], 'Unified Inbox');

    $checks = [
        [$root->name === 'panel.layout.app', 'host layout is returned as root view'],
        [$factory->made === ['titan-connect::probe', 'panel.layout.app'], 'content renders before host root layout'],
        [($factory->sections['content'] ?? null) === '<main data-titan-content>Inbox</main>', 'content is injected into host content section'],
        [($factory->sections['title'] ?? null) === 'Unified Inbox', 'title is injected into host title section'],
        [isset($factory->pushes['css'][0]), 'content CSS stack survives until host layout render'],
        [isset($factory->pushes['script'][0]), 'content script stack survives until host layout render'],
        [$factory->renderCount === 0, 'render counter is balanced'],
        [$factory->flushed === false, 'normal render path does not flush view state early'],
    ];

    $passed = 0;
    foreach ($checks as [$ok, $label]) {
        if ($ok) {
            echo "PASS: {$label}\n";
            $passed++;
        } else {
            fwrite(STDERR, "FAIL: {$label}\n");
        }
    }

    printf("Titan Connect dashboard renderer runtime: %d/%d passed\n", $passed, count($checks));
    exit($passed === count($checks) ? 0 : 1);
}
