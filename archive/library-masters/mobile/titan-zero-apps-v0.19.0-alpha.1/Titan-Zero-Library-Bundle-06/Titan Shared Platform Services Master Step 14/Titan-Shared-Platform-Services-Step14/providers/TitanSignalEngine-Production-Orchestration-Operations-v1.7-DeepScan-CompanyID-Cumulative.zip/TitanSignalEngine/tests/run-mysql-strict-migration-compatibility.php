<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$migrations = glob($root.'/database/migrations/*.php') ?: [];
sort($migrations);
$violations = [];
foreach ($migrations as $migration) {
    $lines = file($migration, FILE_IGNORE_NEW_LINES) ?: [];
    foreach ($lines as $i => $line) {
        if (! str_contains($line, '$table->timestamp(')) {
            continue;
        }
        if (str_contains($line, '->nullable()') || str_contains($line, '->useCurrent()') || str_contains($line, '->default(')) {
            continue;
        }
        $violations[] = basename($migration).':'.($i + 1).': '.trim($line);
    }
}

if ($violations !== []) {
    fwrite(STDERR, "FAIL mysql-strict migration compatibility\nRequired timestamp columns without explicit defaults:\n - ".implode("\n - ", $violations)."\n");
    exit(1);
}

fwrite(STDOUT, "PASS mysql-strict migration compatibility\n");
