<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Data;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;
use App\Extensions\TitanPrime\System\Gateways\Support\GatewayPayloadGuard;
use InvalidArgumentException;

final readonly class EngineGatewayRequest
{
    /** @param array<string,mixed> $payload */
    public function __construct(
        public EngineKey $engine,
        public string $capability,
        public string $operationId,
        public TraceContext $trace,
        public array $payload,
        public string $contractVersion = '1.0',
    ) {
        foreach (['capability' => $capability, 'operation_id' => $operationId, 'contract_version' => $contractVersion] as $name => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException(sprintf('%s must not be empty.', $name));
            }
        }
        if (!preg_match('/^[a-z0-9][a-z0-9._:-]*$/', $capability)) {
            throw new InvalidArgumentException('capability must use a stable lowercase contract identifier.');
        }
        GatewayPayloadGuard::assertSafe($payload);
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'engine' => $this->engine->value,
            'capability' => $this->capability,
            'operation_id' => $this->operationId,
            'contract_version' => $this->contractVersion,
            'trace' => $this->trace->toArray(),
            'payload' => $this->payload,
        ];
    }
}
