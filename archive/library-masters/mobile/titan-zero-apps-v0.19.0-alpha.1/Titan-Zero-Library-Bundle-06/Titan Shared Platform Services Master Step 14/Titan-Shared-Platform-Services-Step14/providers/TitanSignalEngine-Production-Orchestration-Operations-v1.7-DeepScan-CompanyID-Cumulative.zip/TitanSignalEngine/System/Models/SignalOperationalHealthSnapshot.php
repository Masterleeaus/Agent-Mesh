<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalOperationalHealthSnapshot extends Model
{
    protected $table = 'titan_signal_operational_health_snapshots';
    protected $guarded = [];
    protected $casts = [
        'current_state' => 'array',
        'historical_incidents' => 'array',
        'captured_at' => 'immutable_datetime',
    ];
}
