# Pass 1 Verification

Foundation tests require `company_id`, Manifest 2.2, typed ports, donor inventory, ownership exclusions, no `tenant_company_id` in production PHP, and no state-changing GET routes.
