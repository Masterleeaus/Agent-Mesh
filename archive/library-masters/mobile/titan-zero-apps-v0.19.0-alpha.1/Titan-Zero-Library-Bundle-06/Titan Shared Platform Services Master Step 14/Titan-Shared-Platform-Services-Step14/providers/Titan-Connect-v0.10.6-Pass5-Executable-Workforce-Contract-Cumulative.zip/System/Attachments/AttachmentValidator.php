<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Attachments;

use App\Extensions\TitanConnect\System\Contracts\AttachmentSecurityScanner;
use App\Extensions\TitanConnect\System\Models\ExternalMessage;
use App\Extensions\TitanConnect\System\Models\MessageAttachment;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamMessage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class AttachmentValidator
{
    public function __construct(private readonly AttachmentSecurityScanner $scanner)
    {
    }

    public function registerInternal(int $companyId, TeamMessage $message, array $metadata): MessageAttachment
    {
        abort_unless((int) $message->company_id === $companyId, 403);
        return $this->register($companyId, $metadata + ['message_id' => $message->id, 'external_message_id' => null]);
    }

    public function registerExternal(int $companyId, ExternalMessage $message, array $metadata): MessageAttachment
    {
        abort_unless((int) $message->company_id === $companyId, 403);
        return $this->register($companyId, $metadata + ['message_id' => null, 'external_message_id' => $message->id]);
    }

    public function registerStaged(int $companyId, array $metadata): MessageAttachment
    {
        return $this->register($companyId, $metadata + ['message_id' => null, 'external_message_id' => null]);
    }

    private function register(int $companyId, array $metadata): MessageAttachment
    {
        $path = trim((string) ($metadata['storage_path'] ?? ''));
        $disk = trim((string) ($metadata['storage_disk'] ?? ''));
        $mime = strtolower(trim((string) ($metadata['mime_type'] ?? '')));
        $size = (int) ($metadata['size_bytes'] ?? 0);
        $allowed = (array) config('titan-connect.attachments.allowed_mime_types', []);
        $maxBytes = (int) config('titan-connect.attachments.max_bytes', 25 * 1024 * 1024);

        $errors = [];
        if ($path === '') $errors['storage_path'] = 'Attachment storage path is required.';
        if ($disk === '') $errors['storage_disk'] = 'Attachment storage disk is required.';
        if ($size < 0 || $size > $maxBytes) $errors['size_bytes'] = 'Attachment size exceeds the configured limit.';
        if ($mime === '' || ($allowed !== [] && ! in_array($mime, $allowed, true))) $errors['mime_type'] = 'Attachment MIME type is not allowed.';
        if (isset($metadata['sha256']) && ! preg_match('/^[a-f0-9]{64}$/i', (string) $metadata['sha256'])) $errors['sha256'] = 'Attachment SHA-256 must be a 64-character hex digest.';
        if ($errors !== []) {
            throw ValidationException::withMessages($errors);
        }

        $scanStatus = $this->scanner->scanMetadata($companyId, $metadata);
        if (! in_array($scanStatus, ['clean', 'pending', 'rejected'], true)) {
            throw ValidationException::withMessages(['scan_status' => 'Attachment scanner returned an invalid status.']);
        }
        if ($scanStatus === 'rejected') {
            throw ValidationException::withMessages(['attachment' => 'Attachment was rejected by the security scanner.']);
        }

        return MessageAttachment::query()->create([
            'uuid' => (string) Str::uuid(),
            'company_id' => $companyId,
            'message_id' => $metadata['message_id'] ?? null,
            'external_message_id' => $metadata['external_message_id'] ?? null,
            'storage_disk' => $disk,
            'storage_path' => $path,
            'original_name' => $metadata['original_name'] ?? null,
            'mime_type' => $mime,
            'size_bytes' => $size,
            'sha256' => isset($metadata['sha256']) ? strtolower((string) $metadata['sha256']) : null,
            'scan_status' => $scanStatus,
            'provider_media' => $metadata['provider_media'] ?? null,
            'expires_at' => $metadata['expires_at'] ?? null,
        ]);
    }
}
