# CRM 1.3.0-alpha.11 — Interaction-First Business OS

## Interaction Engine becomes the primary CRM interaction layer

CRM now treats Titan Interaction Engine `>=10.3.1 <11.0` as the primary structured interaction runtime for create workflows while CRM remains the authoritative business-record system.

Every major internal CRM page uses one shared interaction shell with:

- page title and context
- contextual Titan Zero AI command bar
- a standard `New ...` action where the page owns a creatable business record
- consistent list/manage content
- Interaction Engine wizard execution
- Advanced-form fallback where a mature direct form already exists

## Conversational execution

Titan Zero can resolve a plain-English request to a CRM journey, start an Interaction Engine session, prefill known page/record context, answer wizard steps and prepare governed execution.

AI does not bypass Interaction Engine authority. Approval-required actions cannot be self-approved by the conversational AI service.

Authority modes are:

- `assist`
- `approval`
- `autonomous`

The autonomous mode is bounded by an explicit capability allowlist. High-consequence actions such as jobs, quotes, invoices, payments, bookkeeping transactions, purchasing and stock-control mutations remain approval-gated by default.

## CRM-owned primary journeys

The Interaction Engine donor wizards for customer/job/quote/invoice did not exactly match CRM service contracts, so alpha.11 supplies CRM-owned definitions for:

- New Customer
- New Job
- New Quote
- New Invoice

The definitions use CRM public IDs, required work-order fields and deterministic sales `lines` payloads. Financial totals are still calculated by CRM's deterministic sales/Financial Assistant services rather than by AI.

## Journey coverage

Interaction journeys now cover core business creation across:

- Customers and contacts
- Leads, opportunities and pipelines
- Quotes and estimates
- Jobs, service requests, projects and tasks
- Calendar events, appointments and dispatch assignments
- Time entries
- Services, service locations and recurring work
- Forms, customer assets and service areas
- Support cases and Customer Hub access
- Invoices, payments and bookkeeping transactions
- Automations
- Inventory, locations, reservations and reorder rules
- Suppliers and purchasing
- Goods receipts, stock counts and stock transfers
- Tools, equipment, vehicles and maintenance
- Tags and custom fields
- API keys and webhooks
- CRM record sharing

## Consistent page UX

Default inline create forms have been removed from major list/manage pages. Creation now starts from the standard New action or Titan Zero conversation.

Record details and Advanced forms retain the same AI command surface and pass record context such as customer, contact, job and financial-document public IDs into new Interaction sessions.

Customer-facing Customer Hub pages and generated PDF/email output remain outside the internal CRM AI shell.

## Compatibility

- CRM tenancy remains `tenant_company_id`.
- CRM `company_id` remains customer/account relationship data.
- WorkCore remains donor-only and is not a runtime dependency.
- Standalone Titan Financial Engine remains unnecessary.
- Existing alpha.10 navigation, alpha.9 route-cache recovery and alpha.8 icon safety are preserved.
- Titan Hub, Titan Go and Titan BOS clean identities remain preserved.
