# Disaster Recovery

Wisdom-owned durable state is included in normal Titan database backup scope. Target RPO is 60 minutes and RTO is 240 minutes for this foundation profile. After restore, run database integrity checks and `php artisan titan:titan-wisdom:certify --json`; later outcome-domain passes must add reconciliation of pending outcome/evidence/calibration state before normal learning resumes.
