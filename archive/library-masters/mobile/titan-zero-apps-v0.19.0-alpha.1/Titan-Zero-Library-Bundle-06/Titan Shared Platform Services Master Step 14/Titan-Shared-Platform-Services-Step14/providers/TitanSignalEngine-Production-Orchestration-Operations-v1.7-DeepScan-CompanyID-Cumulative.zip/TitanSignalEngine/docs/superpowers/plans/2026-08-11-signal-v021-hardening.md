# Titan Signal Engine v0.2.1 Foundation Hardening Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Prove and harden the v0.2.0 Signal foundation before the Correlation Engine depends on it.

**Architecture:** Preserve the current append-only Signal boundary and add narrowly scoped validation primitives: envelope format versioning, ordered identities, root causation, checksum verification, event-type governance, authenticated emission context, independent payload limits, and stronger persistence/query tests. All schema changes are additive forward-only migrations.

**Tech Stack:** PHP 8.2+, Laravel 10+, Eloquent, Laravel migrations, PHPUnit-compatible tests.

## Global Constraints

- Preserve existing installer/provider/routes and v0.1.0/v0.2.0 migrations.
- Keep `scope` limited to `tenant|system`.
- Do not weaken immutable-event semantics; correction/redaction remains a later governed projection.
- No cross-tenant queries.
- No queued subscriptions, Pulse, anomaly detection, ML, graph DB, Elasticsearch, or cold-storage implementation in this pass.
- Do not store unrestricted hidden model chain-of-thought.

---

### Task 1: Canonical envelope hardening
**Files:** Modify `System/Data/SignalEnvelope.php`; add pure unit tests in `tests/Unit/SignalEnvelopeHardeningTest.php`.
**Produces:** envelope_version=1.0, checksum_alg=sha256, UUIDv7 generation, root_causation_id propagation, checksum verification, global severity validation, actor_session_id.

### Task 2: Event Type Registry
**Files:** Create registry contract/data/model/service, migration `000003`, seed core event definitions through config, bind provider, add unit/feature tests.
**Produces:** registered event definition lookup/validation and `titan_signal_types` table.

### Task 3: Authenticated Signal Context
**Files:** Create `SignalContext`, `SignalContextValidator`, contract; update emitter to validate array input against trusted context; add tests.
**Produces:** tenant/system actor authenticity boundary and anti-spoofing checks.

### Task 4: Payload and reasoning guards
**Files:** Update config/emitter; create payload guard service; tests.
**Produces:** independent payload/metadata byte limits and prohibited hidden-reasoning key rejection.

### Task 5: Persistence hardening
**Files:** Add migration `000004`; update event model/store/receipt; add Laravel integration tests.
**Produces:** root/envelope/checksum/session fields persisted, idempotency expiry metadata, original event ID returned on duplicate, indexes.

### Task 6: Query and architecture proof
**Files:** Expand feature/architecture tests and docs/report/manifest version.
**Produces:** tenant-boundary, immutability, idempotency, checksum and query contract proof definitions plus accurate v0.2.1 documentation.

### Task 7: Verification and cumulative package
**Files:** No production changes unless verification finds a defect.
**Produces:** PHP lint, JSON validation, pure behavioral test runner, static security scans, ZIP integrity and cumulative v0.2.1 archive.
