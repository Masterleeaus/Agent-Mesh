<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\TitanConnect;

/** Safe default when no canonical Titan Connect/compatibility adapter is bound. */
final class CrmDeferredCommunicationExecutionPort implements CrmCommunicationExecutionPort
{
    public function deliver(array $intent): array
    {
        return [
            'status'=>'deferred',
            'provider'=>'titan_connect',
            'provider_message_id'=>null,
            'provider_status'=>'unavailable',
            'retryable'=>true,
            'reason'=>'Titan Connect communication execution adapter is not bound.',
        ];
    }
}
