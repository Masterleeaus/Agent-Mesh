<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function fail_p4r(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function assert_p4r(bool $c,string $m):void{if(!$c)fail_p4r($m);}
$installer=json_decode((string)file_get_contents($root.'/extension.json'),true,512,JSON_THROW_ON_ERROR);
$manifest=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
assert_p4r(is_string($installer['version']??null) && version_compare($installer['version'],'0.5.0','>='),'root installer must retain Pass 4 or newer version');
assert_p4r(is_string($manifest['version']??null) && version_compare($manifest['version'],'0.5.0','>='),'rich manifest must retain Pass 4 or newer version');
$deps=[];foreach(array_merge(($installer['dependencies']??[]),($installer['optional_dependencies']??[])) as $d){if(is_array($d)&&isset($d['slug']))$deps[$d['slug']]=$d['version']??null;}
assert_p4r(($deps['titan-signal']??null)==='>=0.2.0','Signal floor must match current public v0.2 contract');
assert_p4r(($deps['titan-command-bus']??null)==='>=0.2.0-alpha.1','Command Bus floor must accept current public dispatch runtime');
$routes=(string)file_get_contents($root.'/routes/user.php');
assert_p4r(str_contains($routes,"middleware('throttle:30,1')"),'governance action POST must be rate limited');
$health=(string)file_get_contents($root.'/System/Health/TitanGovernanceHealthCheck.php');
assert_p4r(str_contains($health,'GovernanceCommandGatewayContract'),'health must include actual action-gateway readiness');
$cert=(string)file_get_contents($root.'/System/Commands/CertifyExtensionCommand.php');
assert_p4r(str_contains($cert,'manifest_version_match'),'host certification must verify installer/manifest version agreement');
assert_p4r(str_contains($cert,'dashboard.user.titan.governance.escalations.queue'),'host certification must check escalation queue route');
assert_p4r(str_contains($cert,'GovernanceCommandGatewayContract'),'host certification must inspect real action gateway readiness');
echo "PASS: Governance Pass 4 release contract\n";
