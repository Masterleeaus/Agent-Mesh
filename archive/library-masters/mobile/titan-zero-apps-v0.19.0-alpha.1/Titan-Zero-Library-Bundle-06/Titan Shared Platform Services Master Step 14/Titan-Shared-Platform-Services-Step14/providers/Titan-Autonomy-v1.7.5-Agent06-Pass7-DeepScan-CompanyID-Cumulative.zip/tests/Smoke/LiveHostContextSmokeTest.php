<?php
declare(strict_types=1);
namespace App\Extensions\Crm\System\Tenancy { final class CrmCompanyScope { public static int $tenant=42; public static function tenantCompanyId(?int $legacy=null): int { return self::$tenant; } } }
namespace {
spl_autoload_register(function(string $class):void{ $p='App\\Extensions\\TitanAutonomy\\'; if(!str_starts_with($class,$p))return; $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($path))require_once $path; });
use App\Extensions\TitanAutonomy\System\Infrastructure\CrmCompanyHostContextBridge;
function hc(bool $v,string $m):void{if(!$v)throw new RuntimeException($m);} 
$user=new class { public int $id=7; public int $tenant_company_id=999; public function can(string $p):bool{return $p==='crm.invoices.manage';} public function isSuperAdmin():bool{return false;} };
$b=new CrmCompanyHostContextBridge(fn()=>$user);
hc($b->tenantCompanyId()===42,'CRM authoritative tenant must win over user-supplied/legacy tenant attribute');
hc($b->userId()===7,'authenticated actor required');
hc($b->can('crm.invoices.manage')===true,'permission must delegate to authenticated actor');
echo "OK: LiveHostContextSmokeTest\n";
}
