<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Titan AI Core')</title>
    <style>
        body { margin: 0; font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #f5f7fb; color: #111827; }
        .titan-ai-core-shell { max-width: 1100px; margin: 0 auto; padding: 32px 20px; }
        .titan-ai-core-card { background: #fff; border: 1px solid #e5e7eb; border-radius: 14px; padding: 20px; margin-bottom: 16px; }
        .titan-ai-core-card pre { white-space: pre-wrap; overflow-wrap: anywhere; }
    </style>
</head>
<body>
    <main class="titan-ai-core-shell">
        @yield('content')
    </main>
</body>
</html>
