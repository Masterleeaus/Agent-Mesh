<?php

declare(strict_types=1);

namespace Tests\Feature\HostCertification;

use App\Extensions\TitanConnect\System\Attachments\AttachmentUploadService;
use App\Extensions\TitanConnect\System\Contracts\AttachmentSecurityScanner;
use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Http\Middleware\EnsureCompanyRouteBindings;
use App\Extensions\TitanConnect\System\Http\Middleware\EnforceCompanyRateLimit;
use App\Extensions\TitanConnect\System\Jobs\ProcessInboundWebhookJob;
use App\Extensions\TitanConnect\System\TitanConnectServiceProvider;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use LogicException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Tests\TestCase;

final class CompanyBoundaryTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();

        if (! filter_var((get(getenv('TITAN_CONNECT_HOST_CERTIFICATION') !== false ? getenv('TITAN_CONNECT_HOST_CERTIFICATION') : null) !== false ? get(getenv('TITAN_CONNECT_HOST_CERTIFICATION') !== false ? getenv('TITAN_CONNECT_HOST_CERTIFICATION') : null) : false), FILTER_VALIDATE_BOOL)) {
            $this->markTestSkipped('Set TITAN_CONNECT_HOST_CERTIFICATION=1 to run Titan Connect host certification.');
        }

        $this->assertSame('mysql', app('db')->connection()->getDriverName(), 'Host certification must run against the production-equivalent MySQL driver.');
    }

    public function test_host_schema_exposes_company_boundary(): void
    {
        $this->assertTrue(Schema::hasColumn('users', 'company_id'), 'Host users table must expose company_id.');

        foreach ($this->companyTables() as $table) {
            $this->assertTrue(Schema::hasTable($table), "Missing Titan Connect table: {$table}");
            $this->assertTrue(Schema::hasColumn($table, 'company_id'), "Missing company_id on {$table}");
        }
    }

    public function test_company_scope_cannot_read_another_company_record(): void
    {
        $companyA = 910001;
        $companyB = 910002;
        $a = $this->connection($companyA);
        $b = $this->connection($companyB);

        $this->assertTrue(ChannelConnection::query()->forCompany($companyA)->whereKey($a->getKey())->exists());
        $this->assertFalse(ChannelConnection::query()->forCompany($companyA)->whereKey($b->getKey())->exists());
    }

    public function test_company_id_is_immutable_after_persistence(): void
    {
        $connection = $this->connection(920001);
        $connection->company_id = 920002;

        $this->expectException(LogicException::class);
        $this->expectExceptionMessage('company_id cannot be changed');
        $connection->save();
    }

    public function test_authenticated_route_binding_hides_foreign_company_model(): void
    {
        $actorCompanyId = 930001;
        $foreign = $this->connection(930002);
        $userClass = (string) config('auth.providers.users.model');
        $this->assertTrue(class_exists($userClass), 'Configured auth user model is not loadable.');

        $user = new $userClass();
        $user->forceFill([
            $user->getAuthIdentifierName() => 990001,
            'company_id' => $actorCompanyId,
        ]);

        $request = Request::create('/dashboard/titan-connect/team/conversations/foreign', 'GET');
        $request->setUserResolver(static fn () => $user);
        $request->setRouteResolver(static fn () => new class($foreign) {
            public function __construct(private readonly ChannelConnection $model) {}
            public function parameters(): array { return ['connection' => $this->model]; }
        });

        $middleware = new EnsureCompanyRouteBindings($this->app->make(CompanyContext::class));

        try {
            $middleware->handle($request, static fn () => response('unexpected', 200));
            $this->fail('Cross-company route-bound model was not rejected.');
        } catch (NotFoundHttpException $e) {
            $this->assertSame(404, $e->getStatusCode());
        }
    }

    public function test_webhook_job_serializes_company_connection_and_provider_identity(): void
    {
        $job = new ProcessInboundWebhookJob(940001, (string) Str::uuid(), 'telegram', ['x-test' => ['1']], '{}');

        $this->assertSame(940001, $job->companyId);
        $this->assertNotSame('', $job->connectionUuid);
        $this->assertSame('telegram', $job->provider);
    }

    public function test_attachment_storage_path_is_company_namespaced(): void
    {
        $companyId = 950001;
        Storage::fake('titan-connect-certification');
        config()->set('titan-connect.attachments.storage_disk', 'titan-connect-certification');
        config()->set('titan-connect.attachments.allowed_mime_types', ['text/plain']);

        $this->app->bind(AttachmentSecurityScanner::class, static fn () => new class implements AttachmentSecurityScanner {
            public function scanMetadata(int $companyId, array $metadata): string { return 'clean'; }
        });
        $this->app->forgetInstance(AttachmentUploadService::class);

        $attachment = $this->app->make(AttachmentUploadService::class)->stage(
            $companyId,
            UploadedFile::fake()->create('certification.txt', 1, 'text/plain'),
        );

        $this->assertSame($companyId, (int) $attachment->company_id);
        $this->assertStringStartsWith("titan-connect/company/{$companyId}/", (string) $attachment->storage_path);
        Storage::disk('titan-connect-certification')->assertExists((string) $attachment->storage_path);
    }

    public function test_production_readiness_schema_and_command_are_available(): void
    {
        $this->assertTrue(Schema::hasColumn('ext_titan_connect_voice_transcripts', 'client_event_id'), 'Voice transcript idempotency column is missing.');
        $this->assertArrayHasKey('titan-connect:diagnose', Artisan::all(), 'Titan Connect diagnose command is not registered.');
        $this->assertArrayHasKey('titan-connect:certify', Artisan::all(), 'Titan Connect certify command is not registered.');
    }

    public function test_host_navigation_and_lifecycle_contracts_are_registered(): void
    {
        $this->assertSame('titan-connect', TitanConnectServiceProvider::registerKey());
        $this->assertArrayHasKey('titan-connect:host-sync', Artisan::all(), 'Titan Connect host-sync command is not registered.');
        $this->assertTrue(Route::has('titan-connect.inbox.unified'), 'Titan Connect unified inbox route is not registered.');
        $this->assertTrue(Route::has('titan-connect.channels.whatsapp'), 'Titan Connect WhatsApp settings route is not registered.');
        $this->assertTrue(Route::has('titan-connect.admin.channels.index'), 'Titan Connect admin Channels route is not registered.');
        $this->assertTrue(Route::has('dashboard.admin.settings.titan-connect.channels.index'), 'Titan Connect live-host admin Settings route is not registered.');
    }

    public function test_authenticated_rate_limit_is_keyed_by_company_and_actor(): void
    {
        config()->set('titan-connect.rate_limits.send', ['attempts' => 1, 'decay_seconds' => 60]);
        $companyId = 960001; $actorId = 990001;
        $context = new class($companyId, $actorId) implements CompanyContext {
            public function __construct(private int $companyIdValue, private int $actorIdValue) {}
            public function companyId(Request $request): int { return $this->companyIdValue; }
            public function actorId(Request $request): int { return $this->actorIdValue; }
        };
        $middleware = new EnforceCompanyRateLimit($context);
        $key = sprintf('titan-connect:send:company:%d:actor:%d', $companyId, $actorId);
        RateLimiter::clear($key);
        $request = Request::create('/api/titan-connect/test-rate', 'POST');
        $first = $middleware->handle($request, static fn () => response()->json(['ok' => true]), 'send');
        $second = $middleware->handle($request, static fn () => response()->json(['ok' => true]), 'send');
        $this->assertSame(200, $first->getStatusCode());
        $this->assertSame(429, $second->getStatusCode());
        $this->assertNotNull($second->headers->get('Retry-After'));
        RateLimiter::clear($key);
    }

    private function connection(int $companyId): ChannelConnection
    {
        return ChannelConnection::query()->create([
            'uuid' => (string) Str::uuid(),
            'company_id' => $companyId,
            'provider' => 'telegram',
            'display_name' => 'Titan Connect certification',
            'external_account_id' => (string) Str::uuid(),
            'status' => 'paused',
            'settings' => [],
        ]);
    }

    /** @return array<int,string> */
    private function companyTables(): array
    {
        return [
            'ext_titan_connect_conversations',
            'ext_titan_connect_participants',
            'ext_titan_connect_messages',
            'ext_titan_connect_message_reads',
            'ext_titan_connect_channel_connections',
            'ext_titan_connect_channel_members',
            'ext_titan_connect_external_threads',
            'ext_titan_connect_external_messages',
            'ext_titan_connect_external_thread_reads',
            'ext_titan_connect_outbound_deliveries',
            'ext_titan_connect_webhook_events',
            'ext_titan_connect_attachments',
            'ext_titan_connect_audit_logs',
            'ext_titan_connect_provider_credentials',
            'ext_titan_connect_external_contacts',
            'ext_titan_connect_contact_tags',
            'ext_titan_connect_external_thread_tags',
            'ext_titan_connect_canned_responses',
            'ext_titan_connect_voice_calls',
            'ext_titan_connect_voice_transcripts',
        ];
    }
}
