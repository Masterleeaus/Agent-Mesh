# Upgrade, Rollback and Uninstall

## Upgrade

Back up database and package, verify ZIP/hash, place the extension under canonical `TitanPayroll` casing, run Installer 1.7.8 validation/migrations, boot provider, regenerate navigation, run smoke checks, then enable writes. Migrations are extension-owned and additive; tenant boundaries and finalized-run immutability must remain intact.

## Rollback

If boot/runtime verification fails, disable Payroll writes with the extension kill/feature control, stop queue consumers for Payroll, restore the prior extension package, and run only the rollback procedure supported by the exact migration state. Never edit finalized payroll rows to simulate rollback.

## Uninstall

Disable writes/queues, export required audit/payroll records according to retention policy, remove menu contributions, run extension uninstall only after explicit data-retention choice, remove files, then verify no scheduled/queue references remain. Do not delete host-owned identity, Time Attendance, Communications or Rewind data.

Exact rollback/uninstall certification is pending the real host and is part of the final host certification matrix.
