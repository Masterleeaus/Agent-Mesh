<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

enum CompilationStatus: string
{
    case Draft = 'draft';
    case Compiled = 'compiled';
    case Failed = 'failed';
}
