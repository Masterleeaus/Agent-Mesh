# LocalBrain v2

LocalBrain v2 remains an Interaction Engine subsystem for bounded offline/local assistance: field intent recognition, local wizard guidance, context/memory, checklist help, recommendations, temporal reasoning and predictive completion. It cannot invent authoritative CRM state or elevate capability authority. When a remote/AI capability is needed, execution is deferred or escalated to the online owning subsystem.
