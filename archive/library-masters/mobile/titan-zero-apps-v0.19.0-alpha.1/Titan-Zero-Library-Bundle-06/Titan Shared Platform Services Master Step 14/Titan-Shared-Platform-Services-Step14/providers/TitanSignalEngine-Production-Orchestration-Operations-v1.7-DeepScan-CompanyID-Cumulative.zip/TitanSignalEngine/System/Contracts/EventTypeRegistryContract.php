<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\EventTypeDefinition;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryIdentity;

interface EventTypeRegistryContract
{
    public function register(EventTypeDefinition $definition, SignalRegistryIdentity $registrar, ?string $ownerServiceId = null): void;

    public function evolve(EventTypeDefinition $definition, SignalRegistryIdentity $registrar, ?string $ownerServiceId = null): void;

    public function find(string $eventType): ?EventTypeDefinition;

    /** @return list<EventTypeDefinition> */
    public function history(string $eventType): array;

    public function validate(SignalEnvelope $signal): EventTypeDefinition;
}
