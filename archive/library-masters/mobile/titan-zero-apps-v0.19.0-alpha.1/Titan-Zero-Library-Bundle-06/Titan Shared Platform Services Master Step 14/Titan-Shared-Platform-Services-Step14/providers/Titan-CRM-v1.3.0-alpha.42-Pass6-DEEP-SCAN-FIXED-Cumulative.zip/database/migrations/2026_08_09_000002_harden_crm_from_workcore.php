<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('crm_companies', function (Blueprint $t): void {
            $t->char('public_id', 26)->nullable()->unique()->after('id');
            $t->string('legal_name')->nullable()->after('name');
            $t->string('normalized_email')->nullable()->index();
            $t->string('normalized_phone', 60)->nullable()->index();
            $t->text('address')->nullable();
            $t->text('notes')->nullable();
            $t->string('status', 32)->default('active')->index();
            $t->unsignedBigInteger('owner_user_id')->nullable()->index();
            $t->softDeletes();
        });
        Schema::table('crm_contacts', function (Blueprint $t): void {
            $t->char('public_id', 26)->nullable()->unique()->after('id');
            $t->string('normalized_email')->nullable()->index();
            $t->string('normalized_phone', 60)->nullable()->index();
            $t->string('role')->nullable();
            $t->boolean('is_primary')->default(false)->index();
            $t->softDeletes();
        });
        Schema::table('crm_leads', function (Blueprint $t): void {
            $t->char('public_id', 26)->nullable()->unique()->after('id');
            $t->string('normalized_email')->nullable()->index();
            $t->string('normalized_phone', 60)->nullable()->index();
            $t->string('company_name')->nullable();
            $t->text('notes')->nullable();
            $t->unsignedBigInteger('owner_user_id')->nullable()->index();
            $t->unsignedInteger('priority')->default(0)->index();
            $t->timestamp('follow_up_at')->nullable()->index();
            $t->unsignedBigInteger('converted_company_id')->nullable()->index();
            $t->timestamp('converted_at')->nullable();
            $t->softDeletes();
        });
        Schema::table('crm_pipelines', function (Blueprint $t): void {
            $t->char('public_id', 26)->nullable()->unique()->after('id');
            $t->string('key', 80)->nullable()->index();
            $t->boolean('is_active')->default(true)->index();
            $t->softDeletes();
        });
        Schema::table('crm_pipeline_stages', function (Blueprint $t): void {
            $t->char('public_id', 26)->nullable()->unique()->after('id');
            $t->string('key', 80)->nullable()->index();
            $t->string('color', 9)->default('#2563eb');
            $t->unsignedTinyInteger('probability')->default(0);
            $t->boolean('is_closed')->default(false);
            $t->boolean('is_won')->default(false);
            $t->boolean('is_active')->default(true)->index();
            $t->softDeletes();
        });
        Schema::table('crm_deals', function (Blueprint $t): void {
            $t->char('public_id', 26)->nullable()->unique()->after('id');
            $t->text('description')->nullable();
            $t->unsignedBigInteger('owner_user_id')->nullable()->index();
            $t->unsignedTinyInteger('probability')->default(0);
            $t->unsignedInteger('position')->default(0);
            $t->date('expected_close_date')->nullable()->index();
            $t->timestamp('closed_at')->nullable();
            $t->text('lost_reason')->nullable();
            $t->json('metadata')->nullable();
            $t->softDeletes();
        });
        Schema::table('crm_activities', function (Blueprint $t): void {
            $t->char('public_id', 26)->nullable()->unique()->after('id');
            $t->char('subject_public_id', 26)->nullable()->index();
            $t->string('title')->nullable();
            $t->string('direction', 16)->nullable();
            $t->timestamp('scheduled_at')->nullable()->index();
            $t->timestamp('completed_at')->nullable()->index();
            $t->unsignedBigInteger('actor_user_id')->nullable()->index();
            $t->json('metadata')->nullable();
        });

        foreach (['crm_projects','crm_tasks','crm_events','crm_products','crm_documents'] as $table) {
            Schema::table($table, function (Blueprint $t): void {
                $t->char('public_id', 26)->nullable()->unique()->after('id');
                $t->softDeletes();
            });
        }

        foreach (['crm_companies','crm_contacts','crm_leads','crm_pipelines','crm_pipeline_stages','crm_deals','crm_activities','crm_projects','crm_tasks','crm_events','crm_products','crm_documents'] as $table) {
            DB::table($table)->whereNull('public_id')->orderBy('id')->select('id')->each(function (object $row) use ($table): void {
                DB::table($table)->where('id', $row->id)->update(['public_id' => (string) Str::ulid()]);
            });
        }

        DB::table('crm_companies')->whereNull('normalized_email')->whereNotNull('email')->orderBy('id')->select('id','email')->each(function (object $row): void {
            DB::table('crm_companies')->where('id',$row->id)->update(['normalized_email'=>strtolower(trim((string)$row->email))]);
        });
        DB::table('crm_contacts')->whereNull('normalized_email')->whereNotNull('email')->orderBy('id')->select('id','email')->each(function (object $row): void {
            DB::table('crm_contacts')->where('id',$row->id)->update(['normalized_email'=>strtolower(trim((string)$row->email))]);
        });
        DB::table('crm_leads')->whereNull('normalized_email')->whereNotNull('email')->orderBy('id')->select('id','email')->each(function (object $row): void {
            DB::table('crm_leads')->where('id',$row->id)->update(['normalized_email'=>strtolower(trim((string)$row->email))]);
        });
    }

    public function down(): void
    {
        // Forward-only by design. CRM operational data is retained across upgrades/uninstall.
    }
};
