# Titan Rewind donor transplant — v0.3.0

This release extracted and adapted the donor's investigation-case, snapshot, timeline, dependency and replay-run concepts into the native `App\\Extensions\\TitanRewind` extension architecture.

The v0.2 Foundation remains canonical for tenancy and trace identity. Donor `company_id` fields were not copied. Donor wildcard Eloquent capture and direct model rollback code were deliberately rejected. Snapshot persistence now uses centralized recursive secret redaction and rejects hidden-reasoning keys. Historical replay is persisted and queue-backed but cannot issue production mutations.
