<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Extensions\TitanSignalEngine\System\Data\AnomalyThresholds;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\TraceEvaluationPolicy;
use App\Extensions\TitanSignalEngine\System\Data\TraceProfile;
use App\Extensions\TitanSignalEngine\System\Models\SignalAnomaly;
use App\Extensions\TitanSignalEngine\System\Models\SignalTraceAssignment;
use App\Extensions\TitanSignalEngine\System\Models\SignalTraceEvaluation;
use App\Extensions\TitanSignalEngine\System\Persistence\SignalEventStore;
use App\Extensions\TitanSignalEngine\System\Services\AnomalyDetectionService;
use App\Extensions\TitanSignalEngine\System\Services\AnomalyRuleEvaluator;
use App\Extensions\TitanSignalEngine\System\Services\AutomaticTraceEvaluationService;
use App\Extensions\TitanSignalEngine\System\Services\CorrelationService;
use App\Extensions\TitanSignalEngine\System\Services\HistoryCorrelationAssembler;
use App\Extensions\TitanSignalEngine\System\Services\LocalSignalArchiveStore;
use App\Extensions\TitanSignalEngine\System\Services\SignalArchiveCatalog;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority;
use App\Extensions\TitanSignalEngine\System\Services\SignalHistoryQueryService;
use App\Extensions\TitanSignalEngine\System\Services\SignalQueryService;
use App\Extensions\TitanSignalEngine\System\Services\TraceAnalyzer;
use App\Extensions\TitanSignalEngine\System\Services\TraceEvaluationProjector;
use App\Extensions\TitanSignalEngine\System\Services\TraceProfileRegistry;
use Tests\TestCase;

final class AutomaticTraceEvaluationRuntimeIntegrationTest extends TestCase
{
    private SignalEventStore $store;
    private TraceProfileRegistry $profiles;
    private AutomaticTraceEvaluationService $automatic;
    private AnomalyDetectionService $anomalies;

    protected function setUp(): void
    {
        parent::setUp();
        foreach (glob(dirname(__DIR__, 2) . '/database/migrations/*.php') ?: [] as $migrationFile) {
            (require $migrationFile)->up();
        }

        $this->store = new SignalEventStore();
        $authority = new SignalEmitterAuthority('automatic-trace-test-secret', [
            'titan-signal-engine:anomaly-engine' => [
                'source' => 'titan-signal-engine',
                'source_component' => 'anomaly-engine',
                'permissions' => ['signal.emit'],
                'event_type_patterns' => ['signal.anomaly.detected', 'signal.anomaly.acknowledged', 'signal.anomaly.suppressed', 'signal.anomaly.resolved', 'signal.anomaly.reopened'],
            ],
        ]);
        $validator = new SignalContextValidator($authority);
        $query = new SignalQueryService($this->store, $validator);
        $history = new SignalHistoryQueryService($query, $this->store, new SignalArchiveCatalog(), new LocalSignalArchiveStore(), $validator);
        $this->profiles = new TraceProfileRegistry();
        $correlation = new CorrelationService(
            $history,
            $history,
            $this->profiles,
            new TraceAnalyzer(),
            new HistoryCorrelationAssembler(),
            new TraceEvaluationProjector(),
        );
        $this->automatic = new AutomaticTraceEvaluationService(
            $this->profiles,
            $correlation,
            new TraceEvaluationPolicy(60, 300, 5, 900),
        );
        $auditEmitter = new class implements \App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterContract {
            public array $events = [];
            public function emit(\App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope|array $signal, \App\Extensions\TitanSignalEngine\System\Data\SignalContext $context): \App\Extensions\TitanSignalEngine\System\Data\SignalReceipt
            {
                $this->events[] = is_array($signal) ? $signal : $signal->toArray();
                return new \App\Extensions\TitanSignalEngine\System\Data\SignalReceipt(
                    '0198cccc-0000-7000-8000-' . str_pad((string) count($this->events), 12, '0', STR_PAD_LEFT),
                    new \DateTimeImmutable('now', new \DateTimeZone('UTC')),
                );
            }
        };
        $this->anomalies = new AnomalyDetectionService(
            $validator,
            new AnomalyRuleEvaluator(new AnomalyThresholds()),
            $authority,
            $auditEmitter,
        );

        $this->profiles->register(TraceProfile::fromArray([
            'profile_key' => 'test.automatic',
            'version' => 1,
            'required_event_types' => ['step.started', 'step.finished'],
            'ordering_rules' => [['before' => 'step.started', 'after' => 'step.finished']],
            'terminal_event_types' => ['step.finished'],
        ]));
    }

    public function test_terminal_first_trace_is_detected_then_resolved_when_late_parent_repairs_history(): void
    {
        $parentId = '0198bbbb-0000-7000-8000-000000000001';
        $traceId = '0198bbbb-0000-7000-8000-000000000010';
        $correlationId = '0198bbbb-0000-7000-8000-000000000020';

        $terminal = SignalEnvelope::fromArray([
            'event_id' => '0198bbbb-0000-7000-8000-000000000002',
            'event_type' => 'step.finished',
            'tenant_company_id' => 42,
            'source' => 'test-suite',
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $parentId,
            'root_causation_id' => $parentId,
            'occurred_at' => '2026-08-17T10:01:00+00:00',
        ]);
        $terminalRow = $this->store->append($terminal)['event'];
        $this->automatic->observe($terminalRow);

        $assignment = SignalTraceAssignment::query()->where('trace_id', $traceId)->where('profile_key', 'test.automatic')->firstOrFail();
        self::assertTrue((bool) $assignment->terminal_seen);
        self::assertSame(1, (int) $assignment->last_missing_event_count);

        $evaluation = SignalTraceEvaluation::query()->where('trace_id', $traceId)->where('profile_key', 'test.automatic')->firstOrFail();
        self::assertSame(1, (int) $evaluation->missing_event_count);
        self::assertTrue((bool) $evaluation->terminal_seen);
        self::assertSame('automatic', (string) $evaluation->evaluation_source);

        $context = SignalContext::system('automatic-trace-test', 'test', ['signal.system.read', 'signal.tenant.read']);
        $this->anomalies->scan($context, 42, SignalEnvelope::SCOPE_TENANT);
        self::assertSame('open', SignalAnomaly::query()->where('anomaly_type', 'required_event_missing')->where('subject_id', $traceId)->value('status'));

        $parent = SignalEnvelope::fromArray([
            'event_id' => $parentId,
            'event_type' => 'step.started',
            'tenant_company_id' => 42,
            'source' => 'test-suite',
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'root_causation_id' => $parentId,
            'occurred_at' => '2026-08-17T10:00:00+00:00',
        ]);
        $parentRow = $this->store->append($parent)['event'];
        $this->automatic->observe($parentRow);
        $this->anomalies->scan($context, 42, SignalEnvelope::SCOPE_TENANT);

        $assignment->refresh();
        self::assertSame('closed', (string) $assignment->status);
        self::assertSame(0, (int) $assignment->last_missing_event_count);
        self::assertSame('resolved', SignalAnomaly::query()->where('anomaly_type', 'required_event_missing')->where('subject_id', $traceId)->value('status'));
    }
}
