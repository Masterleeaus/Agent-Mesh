<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_archive_catalog')) {
            Schema::create('titan_signal_archive_catalog', function (Blueprint $table): void {
                $table->id();
                $table->uuid('event_id')->unique('tsac_event_uq');
                $table->uuid('batch_id');
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->string('event_type', 191);
                $table->uuid('trace_id');
                $table->uuid('correlation_id');
                $table->uuid('causation_id')->nullable();
                $table->uuid('root_causation_id');
                $table->dateTime('occurred_at');
                $table->dateTime('recorded_at');
                $table->string('archive_driver', 80);
                $table->string('archive_locator', 1024);
                $table->char('archive_checksum', 64);
                $table->unsignedInteger('archive_sequence');
                $table->boolean('privacy_projected')->default(false);
                $table->char('original_checksum', 64);
                $table->timestamps();

                $table->index(['scope', 'tenant_key', 'trace_id', 'occurred_at'], 'tsac_trace_idx');
                $table->index(['scope', 'tenant_key', 'correlation_id', 'occurred_at'], 'tsac_corr_idx');
                $table->index(['scope', 'tenant_key', 'root_causation_id', 'occurred_at'], 'tsac_root_idx');
                $table->index(['batch_id', 'archive_sequence'], 'tsac_batch_seq_idx');
                $table->index(['scope', 'tenant_key', 'event_type', 'occurred_at'], 'tsac_type_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_archive_catalog');
    }
};
