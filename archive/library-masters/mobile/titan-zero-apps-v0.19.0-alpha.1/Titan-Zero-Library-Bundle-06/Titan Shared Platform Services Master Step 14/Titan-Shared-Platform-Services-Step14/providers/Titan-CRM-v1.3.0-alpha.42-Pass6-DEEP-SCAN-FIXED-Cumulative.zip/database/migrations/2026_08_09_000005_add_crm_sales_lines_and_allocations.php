<?php

declare(strict_types=1);
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
  Schema::create('crm_sales_document_lines',function(Blueprint $t){$t->id();$t->unsignedBigInteger('user_id')->index();$t->string('document_type',30)->index();$t->char('document_public_id',26)->index();$t->unsignedInteger('sequence')->default(1);$t->string('description');$t->unsignedBigInteger('quantity_milli')->default(1000);$t->bigInteger('unit_price_minor')->default(0);$t->unsignedInteger('tax_rate_bps')->default(0);$t->bigInteger('line_subtotal_minor')->default(0);$t->bigInteger('line_tax_minor')->default(0);$t->bigInteger('line_total_minor')->default(0);$t->json('meta')->nullable();$t->timestamps();$t->index(['user_id','document_type','document_public_id'],'crm_sales_lines_document');});
 }
 public function down(): void {Schema::dropIfExists('crm_sales_document_lines');}
};
