<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Integration;

use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

final class EventWorkCoreAuthorizationGateway implements WorkCoreAuthorizationGateway
{
    public function assertCanAccess(int $companyId, int $actorId, string $entityType, string $entityId): void
    {
        $responses = event('titan-connect.workcore.authorize', [
            $companyId,
            $actorId,
            $entityType,
            $entityId,
        ]) ?: [];

        foreach ($responses as $response) {
            if ($response === true) {
                return;
            }
        }

        throw new AccessDeniedHttpException('WorkCore did not explicitly authorize access to this linked conversation.');
    }
}
