<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key')) {
            return;
        }

        $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
        if (! isset($columns['id'])) return;

        // rc.5 exposed the engine in the ordinary user sidebar. Remove that row: Signal
        // Engine operations are platform infrastructure and belong in Super Admin.
        DB::table('menus')->where('key', 'titan_signal_pulse')->delete();

        $row = [
            'key' => 'titan_signal_engine_admin',
            'parent_id' => null,
            'route' => 'dashboard.admin.titan.signal.engine.index',
            'route_slug' => null,
            'label' => 'Signal Engine',
            'icon' => 'tabler-heart-rate-monitor',
            'svg' => null,
            'order' => 995,
            'is_active' => 1,
            'is_admin' => 1,
            'params' => '[]',
            'type' => 'item',
            'badge' => null,
            'extension' => '1',
            'custom_menu' => 0,
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
        ];

        $existing = DB::table('menus')->where('key', 'titan_signal_engine_admin')->orderBy('id')->first();
        $payload = array_intersect_key($row, $columns);
        if ($existing !== null) {
            // Preserve explicit administrator enable/disable choice, repair all vendor-owned
            // structural fields, and force the root into the Super Admin order band.
            unset($payload['is_active']);
            if (isset($columns['updated_at'])) $payload['updated_at'] = now();
            DB::table('menus')->where('id', (int) $existing->id)->update($payload);
        } else {
            if (isset($columns['created_at'])) $payload['created_at'] = now();
            if (isset($columns['updated_at'])) $payload['updated_at'] = now();
            DB::table('menus')->insert($payload);
        }

        if (class_exists(\App\Services\Common\MenuService::class)) {
            try {
                $service = app(\App\Services\Common\MenuService::class);
                if (method_exists($service, 'regenerate')) $service->regenerate();
            } catch (\Throwable) {
                try { \App\Services\Common\MenuService::regenerate(); } catch (\Throwable) {}
            }
        }
    }

    public function down(): void
    {
        // Do not recreate the rc.5 user sidebar exposure on rollback. The Super Admin row
        // remains a safe compatibility surface and is removed by extension uninstall.
    }
};
