<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Adapters\CommandBus\CommandBusProvisioningAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\RiskEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\GovernanceEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\AutonomyEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\AssuranceEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Observability\SignalEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Observability\RewindEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Platform\PlatformReadinessAdapter;
use App\Extensions\TitanNexus\System\Contracts\VerticalDefinitionSourceContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlanStatus;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Services\DeterministicNexusCompiler;
use App\Extensions\TitanNexus\System\Services\DeterministicProvisioningPlanner;
use App\Extensions\TitanNexus\System\Services\GovernedProvisioningExecutor;
use App\Extensions\TitanNexus\System\Services\NexusManager;
use App\Extensions\TitanNexus\System\Services\SemanticNexusValidator;

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
foreach ([
    '/System/Support/CanonicalJson.php',
    '/System/Support/DeterministicMerge.php',
    '/System/Domain/CompilationStatus.php',
    '/System/Domain/CompilationLifecycleStage.php',
    '/System/Domain/RuntimeReadinessReport.php',
    '/System/Domain/ValidationSeverity.php',
    '/System/Domain/ValidationFinding.php',
    '/System/Domain/ValidationResult.php',
    '/System/Domain/ValueObjects/TraceContext.php',
    '/System/Domain/BusinessProfile.php',
    '/System/Domain/CompiledTitanConfig.php',
    '/System/Domain/SemanticChangeKind.php',
    '/System/Domain/SemanticChangeDisposition.php',
    '/System/Domain/SemanticDiffEntry.php',
    '/System/Domain/ConfigurationDiff.php',
    '/System/Domain/ProvisioningReceiptStatus.php',
    '/System/Domain/ProvisioningPlanStatus.php',
    '/System/Domain/ProvisioningOperation.php',
    '/System/Domain/ProvisioningReceipt.php',
    '/System/Domain/ProvisioningPlan.php',
    '/System/Domain/ProvisioningExecutionContext.php',
    '/System/Domain/RiskDecision.php',
    '/System/Domain/GovernanceDecision.php',
    '/System/Domain/AutonomyDecision.php',
    '/System/Domain/AssuranceDecision.php',
    '/System/Domain/VerticalDefinition.php',
    '/System/Domain/CompilationPreview.php',
    '/System/Domain/RecompilePlanStatus.php',
    '/System/Domain/RecompilePlan.php',
    '/System/Domain/NexusCompilation.php',
    '/System/Contracts/NexusCompilerContract.php',
    '/System/Contracts/ConfigurationDifferContract.php',
    '/System/Contracts/VerticalDefinitionSourceContract.php',
    '/System/Contracts/PlatformReadinessSourceContract.php',
    '/System/Contracts/NexusValidatorContract.php',
    '/System/Contracts/ProvisioningPlannerContract.php',
    '/System/Contracts/ProvisioningCommandGatewayContract.php',
    '/System/Contracts/ProvisioningExecutorContract.php',
    '/System/Contracts/RiskGatewayContract.php',
    '/System/Contracts/GovernanceGatewayContract.php',
    '/System/Contracts/AutonomyGatewayContract.php',
    '/System/Contracts/AssuranceGatewayContract.php',
    '/System/Contracts/SignalGatewayContract.php',
    '/System/Contracts/RewindGatewayContract.php',
    '/System/Contracts/NexusManagerContract.php',
    '/System/Adapters/Platform/PlatformReadinessAdapter.php',
    '/System/Adapters/CommandBus/CommandBusProvisioningAdapter.php',
    '/System/Adapters/Governance/RiskEngineAdapter.php',
    '/System/Adapters/Governance/GovernanceEngineAdapter.php',
    '/System/Adapters/Governance/AutonomyEngineAdapter.php',
    '/System/Adapters/Governance/AssuranceEngineAdapter.php',
    '/System/Adapters/Observability/SignalEngineAdapter.php',
    '/System/Adapters/Observability/RewindEngineAdapter.php',
    '/System/Exceptions/NexusValidationException.php',
    '/System/Services/DeterministicNexusCompiler.php',
    '/System/Services/SemanticConfigurationDiffer.php',
    '/System/Services/SemanticNexusValidator.php',
    '/System/Services/DeterministicProvisioningPlanner.php',
    '/System/Services/GovernedProvisioningExecutor.php',
    '/System/Services/NexusManager.php',
] as $file) {
    require_once $root . $file;
}

function pmExecutor(CommandBusProvisioningAdapter $gateway): GovernedProvisioningExecutor
{
    return new GovernedProvisioningExecutor(
        $gateway,
        new RiskEngineAdapter(static fn (array $request): array => ['allowed'=>true,'decision_reference'=>'risk:pm','risk_class'=>'MEDIUM','required_assurance'=>'AMBER']),
        new GovernanceEngineAdapter(static fn (array $request): array => ['allowed'=>true,'decision_reference'=>'gov:pm','approval_required'=>false]),
        new AssuranceEngineAdapter(static fn (array $request): array => ['allowed'=>true,'evidence_reference'=>'assurance:pm','assurance_level'=>'AMBER']),
        new SignalEngineAdapter(static fn (string $event, array $request): array => ['signal_reference'=>'signal:'.$event]),
        new RewindEngineAdapter(static fn (string $event, array $request): array => ['rewind_reference'=>'rewind:'.$event]),
        new AutonomyEngineAdapter(static fn (array $request): array => ['allowed'=>true,'decision_reference'=>'autonomy:pm','authority_level'=>'Semi-Auto']),
    );
}

function pmCheck(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

$profile = BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '3.0.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
    'timezone' => 'Australia/Melbourne',
    'sections' => ['crm' => ['enabled' => true]],
]);
$trace = TraceContext::fromArray([
    'tenant_company_id' => 42,
    'trace_id' => '11111111-1111-4111-8111-111111111111',
    'correlation_id' => '22222222-2222-4222-8222-222222222222',
    'causation_id' => '33333333-3333-4333-8333-333333333333',
]);
$source = new class implements VerticalDefinitionSourceContract {
    public function resolve(BusinessProfile $profile): VerticalDefinition
    {
        return VerticalDefinition::fromArray([
            'vertical_id' => $profile->verticalId(),
            'vertical_version' => $profile->verticalVersion(),
            'sections' => [],
            'provisioning' => ['routes' => [
                'sections.crm' => ['capability' => 'crm.configuration.apply', 'depends_on' => []],
            ]],
        ]);
    }
};
$gateway = new CommandBusProvisioningAdapter(static fn (string $capability, array $request): array => [
    'operation_id' => $request['operation_id'],
    'idempotency_key' => $request['idempotency_key'],
    'status' => 'applied',
    'backup_reference' => 'backup:' . $request['operation_id'],
    'backup_verified' => true,
    'write_verified' => true,
    'audit_reference' => 'audit:' . $request['operation_id'],
    'rollback_reference' => 'rollback:' . $request['operation_id'],
]);
$manager = new NexusManager(
    new DeterministicNexusCompiler('0.5.0'),
    $source,
    new SemanticNexusValidator(new PlatformReadinessAdapter()),
    null,
    new DeterministicProvisioningPlanner(),
    pmExecutor($gateway),
);
$draft = $manager->newDraft($profile, $trace, '44444444-4444-4444-8444-444444444444');
$compiled = $manager->compileDraft($draft, '1');
$planned = $manager->planProvisioning($compiled);
pmCheck($planned->provisioningPlan()?->status() === ProvisioningPlanStatus::Ready, 'manager attaches a ready provisioning plan');
pmCheck($compiled->provisioningPlan() === null, 'planning preserves immutable input compilation');
$executed = $manager->executeProvisioning($planned, $trace);
pmCheck($executed->provisioningPlan()?->status() === ProvisioningPlanStatus::Applied, 'manager executes through injected public gateway');
pmCheck($executed->provisioningPlan()?->receipts()[0]->successful() === true, 'manager execution retains verified receipt');
pmCheck(($manager->health()['status'] ?? null) === 'UNAVAILABLE', 'health reports truthful unavailable status without runtime dependencies');

fwrite(STDOUT, "PASS: Titan Nexus standalone provisioning manager checks\n");
