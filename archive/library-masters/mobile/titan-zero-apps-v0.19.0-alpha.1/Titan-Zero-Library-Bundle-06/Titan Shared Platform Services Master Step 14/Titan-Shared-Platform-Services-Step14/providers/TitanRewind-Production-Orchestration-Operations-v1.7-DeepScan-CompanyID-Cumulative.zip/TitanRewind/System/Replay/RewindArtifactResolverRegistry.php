<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Replay;

use App\Extensions\TitanRewind\System\Contracts\RewindHistoricalArtifactResolverContract;
use InvalidArgumentException;

final class RewindArtifactResolverRegistry
{
    /** @var array<string,RewindHistoricalArtifactResolverContract> */
    private array $resolvers = [];

    public function register(RewindHistoricalArtifactResolverContract $resolver): void
    {
        $kind = strtolower(trim($resolver->kind()));
        if ($kind === '' || !preg_match('/^[a-z][a-z0-9._-]{1,79}$/', $kind)) {
            throw new InvalidArgumentException('Invalid Rewind historical artifact resolver kind.');
        }
        $this->resolvers[$kind] = $resolver;
    }

    public function has(string $kind): bool { return isset($this->resolvers[strtolower($kind)]); }

    public function resolve(string $kind, string $version, array $context = []): ?array
    {
        $resolver = $this->resolvers[strtolower($kind)] ?? null;
        return $resolver?->resolve($version, $context);
    }

    public function kinds(): array
    {
        $kinds = array_keys($this->resolvers);
        sort($kinds, SORT_STRING);
        return $kinds;
    }
}
