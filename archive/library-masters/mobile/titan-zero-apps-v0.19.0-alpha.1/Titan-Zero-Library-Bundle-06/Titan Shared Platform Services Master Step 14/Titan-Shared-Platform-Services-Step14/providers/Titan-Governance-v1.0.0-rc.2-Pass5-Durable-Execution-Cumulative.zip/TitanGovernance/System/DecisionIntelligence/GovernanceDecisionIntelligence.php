<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\DecisionIntelligence;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceDecisionReadStoreContract;
use DateTimeImmutable;
use Throwable;

final class GovernanceDecisionIntelligence
{
    public function __construct(
        private readonly GovernanceDecisionReadStoreContract $decisions,
        private readonly GovernanceDecisionEvidenceRegistry $sources,
        private readonly GovernanceEvidenceSanitizer $sanitizer,
    ){}

    /** @return array<string,mixed> */
    public function inspect(int $tenantCompanyId,string $decisionId,array $context=[]):array
    {
        $decision=$this->decisions->find($tenantCompanyId,$decisionId);
        if($decision===null) return ['schema_version'=>'1.0','status'=>'NOT_FOUND','tenant_company_id'=>$tenantCompanyId,'decision_id'=>$decisionId,'decision'=>null,'sources'=>[],'timeline'=>[]];

        $safeDecision=$this->sanitizer->sanitize($decision);
        $timeline=[$this->localEvent($safeDecision)];
        $sourceRows=[];

        foreach($this->sources->all() as $key=>$source){
            try{$snapshot=$this->sanitizer->sanitize($source->decisionEvidence($tenantCompanyId,$decisionId,$context));}
            catch(Throwable){$snapshot=['status'=>'UNAVAILABLE','source'=>$key,'required'=>$source->required(),'events'=>[],'policies'=>[],'rewind'=>null,'reason'=>'SOURCE_READ_FAILED'];}

            $identityMismatch=(isset($snapshot['tenant_company_id']) && (int)$snapshot['tenant_company_id']!==$tenantCompanyId)
                || (isset($snapshot['decision_id']) && trim((string)$snapshot['decision_id'])!==$decisionId);
            if($identityMismatch){
                $sourceRows[$key]=['status'=>'INVALID','required'=>$source->required(),'reason'=>'IDENTITY_MISMATCH','observed_at'=>$snapshot['observed_at']??null,'events'=>[],'policies'=>[],'rewind'=>null];
                continue;
            }

            $status=strtoupper(trim((string)($snapshot['status']??'UNAVAILABLE')));
            $events=[];
            foreach(array_slice(is_array($snapshot['events']??null)?$snapshot['events']:[],0,100) as $event){
                if(!is_array($event)) continue;
                $normalized=$this->normalizeSourceEvent($key,$event);
                if($normalized!==null){$events[]=$normalized;$timeline[]=$normalized;}
            }
            $sourceRows[$key]=[
                'status'=>$status===''?'UNAVAILABLE':$status,'required'=>$source->required(),'reason'=>$snapshot['reason']??null,
                'observed_at'=>$snapshot['observed_at']??null,'events'=>$events,
                'policies'=>array_values(array_slice(is_array($snapshot['policies']??null)?$snapshot['policies']:[],0,100)),
                'rewind'=>is_array($snapshot['rewind']??null)?$snapshot['rewind']:null,
            ];
        }

        usort($timeline,fn(array $a,array $b):int=>$this->eventTimestamp($a)<=>$this->eventTimestamp($b) ?: strcmp((string)($a['source']??''),(string)($b['source']??'')) ?: strcmp((string)($a['event_type']??''),(string)($b['event_type']??'')));

        return ['schema_version'=>'1.0','status'=>'HEALTHY','tenant_company_id'=>$tenantCompanyId,'decision_id'=>$decisionId,'decision'=>$safeDecision,'sources'=>$sourceRows,'timeline'=>$timeline];
    }

    /** @return list<array<string,mixed>> */
    public function recent(int $tenantCompanyId,int $limit=50):array
    {
        return array_map(fn(array $row):array=>$this->sanitizer->sanitize($row),$this->decisions->recent($tenantCompanyId,max(1,min(100,$limit))));
    }

    /** @param array<string,mixed> $decision @return array<string,mixed> */
    private function localEvent(array $decision):array
    {
        return [
            'source'=>'titan-governance','event_type'=>'governance.decision.recorded','occurred_at'=>$decision['decided_at']??null,
            'reference'=>$decision['decision_id']??null,'status'=>$decision['action']??$decision['disposition']??null,
            'reason_codes'=>array_values(is_array($decision['reason_codes']??null)?$decision['reason_codes']:[]),
            'evidence_refs'=>array_values(is_array($decision['evidence_refs']??null)?$decision['evidence_refs']:[]),
            'policy_id'=>$decision['policy_key']??null,'policy_version'=>$decision['policy_version']??null,
            'summary'=>'Governance decision recorded.','metadata'=>array_filter([
                'subject_type'=>$decision['subject_type']??null,'subject_id'=>$decision['subject_id']??null,'command_status'=>$decision['command_status']??null,
                'command_receipt_ref'=>$decision['command_receipt_ref']??null,'authoritative_receipt_ref'=>$decision['authoritative_receipt_ref']??null,'write_verified'=>$decision['write_verified']??false,
            ],static fn(mixed $v):bool=>$v!==null),
        ];
    }

    /** @param array<string,mixed> $event @return array<string,mixed>|null */
    private function normalizeSourceEvent(string $source,array $event):?array
    {
        $type=trim((string)($event['event_type']??$event['type']??''));
        if($type==='') return null;
        $safe=$this->sanitizer->sanitize($event);
        return [
            'source'=>$source,'event_type'=>$type,'occurred_at'=>$safe['occurred_at']??$safe['observed_at']??null,
            'reference'=>$safe['reference']??$safe['event_id']??$safe['id']??null,'status'=>$safe['status']??null,
            'reason_codes'=>array_values(is_array($safe['reason_codes']??null)?$safe['reason_codes']:[]),
            'evidence_refs'=>array_values(is_array($safe['evidence_refs']??null)?$safe['evidence_refs']:[]),
            'policy_id'=>$safe['policy_id']??$safe['policy_key']??null,'policy_version'=>$safe['policy_version']??null,
            'summary'=>$safe['summary']??null,
            'metadata'=>array_diff_key($safe,array_flip(['event_type','type','occurred_at','observed_at','reference','event_id','id','status','reason_codes','evidence_refs','policy_id','policy_key','policy_version','summary'])),
        ];
    }

    /** @param array<string,mixed> $event */
    private function eventTimestamp(array $event):int
    {
        $value=$event['occurred_at']??null;if(!is_string($value)||trim($value)==='') return PHP_INT_MAX;
        try{return (new DateTimeImmutable($value))->getTimestamp();}catch(Throwable){return PHP_INT_MAX;}
    }
}
