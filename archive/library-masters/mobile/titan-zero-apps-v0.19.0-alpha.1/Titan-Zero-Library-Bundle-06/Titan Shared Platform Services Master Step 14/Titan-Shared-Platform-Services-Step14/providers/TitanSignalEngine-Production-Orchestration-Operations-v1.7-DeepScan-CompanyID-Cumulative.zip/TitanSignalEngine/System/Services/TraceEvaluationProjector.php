<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Data\TraceAnalysis;
use App\Extensions\TitanSignalEngine\System\Models\SignalTraceEvaluation;
use Illuminate\Support\Facades\Schema;

final class TraceEvaluationProjector
{
    public function project(string $traceId, ?string $correlationId, string $scope, ?int $tenantCompanyId, TraceAnalysis $analysis): void
    {
        if ($analysis->profileKey === null || $analysis->profileVersion === null || ! Schema::hasTable('titan_signal_trace_evaluations')) {
            return;
        }

        SignalTraceEvaluation::query()->updateOrCreate(
            [
                'trace_id' => $traceId,
                'scope' => $scope,
                'tenant_key' => (int) ($tenantCompanyId ?? 0),
                'profile_key' => $analysis->profileKey,
                'profile_version' => $analysis->profileVersion,
            ],
            [
                'correlation_id' => $correlationId,
                'tenant_company_id' => $tenantCompanyId,
                'status' => $analysis->status,
                'event_count' => count($analysis->orderedEvents),
                'sequence_violation_count' => count($analysis->sequenceViolations),
                'missing_event_count' => count($analysis->missingEventTypes),
                'missing_parent_count' => count($analysis->missingParentEventIds),
                'causal_cycle_count' => count($analysis->causalCycleEventIds),
                'profile_violation_count' => count($analysis->profileViolations),
                'history_complete' => true,
                'cold_history_complete' => true,
                'evaluation_source' => 'manual',
                'fresh_until' => now()->addSeconds(max(60, (int) config('titan-signal-engine.trace_evaluation_fresh_seconds', 600))),
                'evaluated_at' => now(),
            ],
        );
    }
}
