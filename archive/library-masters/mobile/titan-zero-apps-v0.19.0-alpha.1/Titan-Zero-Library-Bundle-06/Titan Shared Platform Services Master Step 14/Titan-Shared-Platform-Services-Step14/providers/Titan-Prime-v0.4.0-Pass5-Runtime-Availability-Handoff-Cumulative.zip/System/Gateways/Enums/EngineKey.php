<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Enums;

enum EngineKey: string
{
    case AiCore = 'titan-ai-core';
    case Signal = 'titan-signal';
    case Risk = 'titan-risk';
    case Assurance = 'titan-assurance';
    case Autonomy = 'titan-autonomy';
    case Governance = 'titan-governance';
    case Rewind = 'titan-rewind';
    case Wisdom = 'titan-wisdom';
}
