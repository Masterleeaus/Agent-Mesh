# Blueprint v4 Signal Alignment

This v0.9.1 overlay aligns Titan Signal Engine with `Titan Extension Blueprint v4.0 — Production Runtime Standard` without advancing the separate 12-pass Production Hardening plan.

Added/aligned:

- manifest schema 2.0 and `titan-governed-engine` runtime profile;
- capability contracts and JSON schemas;
- liveness/readiness health contract;
- canonical trace/log context adapter;
- named one-server non-overlapping schedules;
- observability, resilience, SLO, rollout, DR and supply-chain declarations;
- required production documentation and localization resources.

The manifest intentionally requires signed production releases. This cumulative handoff ZIP is not a signed production release because no release private key was supplied; it must be signed by the deployment/release pipeline.

## AI Workforce applicability

The supplied Blueprint is the Step03 AI Workforce cumulative baseline, but its canonical `templates/titan-governed-engine` package does not embed a Workforce manifest. Signal is a core governed engine and telemetry authority, not a business-domain workforce owner. This alignment therefore does **not** invent Signal Manager/Specialist/Action Worker roles. Domain/capability-owning extensions remain responsible for their own Workforce definitions and may consume Signal through the public contracts.

If a future dedicated Signal Operations workforce is deliberately introduced, it should be an explicit additive design with read/investigate/prepare capabilities and no direct pruning/redaction self-approval.
