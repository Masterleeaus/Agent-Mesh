<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ControlCentre;

final class WorkforceOversightProjector
{
    /** @param array<string,array<string,mixed>> $sources @return array<string,mixed> */
    public function project(array $sources,array $context=[]):array
    {
        $source=is_array($sources['titan-ai-workforce']??null)?$sources['titan-ai-workforce']:null;
        if($source===null)return $this->empty('NOT_INSTALLED',null,null);
        $status=strtoupper(trim((string)($source['status']??'UNAVAILABLE')));
        $observedAt=$this->scalar($source['observed_at']??null);
        $cc=$this->arrayish($source['control_centre']??[]);
        if(!in_array($status,['HEALTHY','DEGRADED','STALE'],true)||$cc===[]){return $this->empty($status===''?'UNAVAILABLE':$status,$observedAt,$source['reason']??null);}

        $graph=$this->arrayish($cc['organisation_graph']??[]);
        $members=[];
        foreach(array_slice($this->listish($graph['nodes']??[]),0,500) as $row){
            $r=$this->arrayish($row);if($r===[])continue;
            $members[]=[
                'member_id'=>$this->scalar($r['id']??$r['member_id']??null),'name'=>$this->scalar($r['name']??null),'role'=>$this->scalar($r['role']??null),
                'tier'=>$this->upper($r['tier']??null),'division'=>$this->scalar($r['division']??null),'manager_id'=>$this->scalar($r['manager_id']??null),'manager'=>$this->scalar($r['manager']??null),
                'status'=>$this->upper($r['status']??null),'maturity'=>$this->scalar($r['maturity']??$r['maturity_level']??null),'risk_ceiling'=>$this->scalar($r['risk_ceiling']??null),
                'maturity_changes_authority'=>false,'hierarchy_changes_authority'=>false,
            ];
        }
        $relationships=[];
        foreach(array_slice($this->listish($graph['edges']??[]),0,1000) as $row){$r=$this->arrayish($row);if($r===[])continue;$relationships[]=['source'=>$this->scalar($r['source']??null),'target'=>$this->scalar($r['target']??null),'type'=>$this->upper($r['type']??null),'authority_inherited'=>false];}
        $queues=[];
        foreach(array_slice($this->listish($cc['queues']??[]),0,200) as $row){$r=$this->arrayish($row);if($r===[])continue;$h=$this->arrayish($r['health']??[]);$queues[]=[
            'manager_id'=>$this->scalar($r['manager_id']??null),'manager'=>$this->scalar($r['manager']??null),'division'=>$this->scalar($r['division']??null),
            'health'=>[
                'queue_depth'=>$this->int($h['queue_depth']??0),'review_count'=>$this->int($h['review_count']??0),'blocked_count'=>$this->int($h['blocked_count']??0),'escalated_count'=>$this->int($h['escalated_count']??0),
                'overdue_count'=>$this->int($h['overdue_count']??0),'starved_count'=>$this->int($h['starved_count']??0),'oldest_task_minutes'=>$this->int($h['oldest_task_minutes']??0),
                'pressure'=>$this->upper($h['pressure']??$h['backpressure_band']??'UNKNOWN'),'backpressure_score'=>$this->number($h['backpressure_score']??null),
                'attention_incidents'=>$this->int($h['attention_incident_count']??$h['attention_incidents']??0),'open_circuits'=>$this->int($h['open_circuit_count']??$h['open_circuits']??0),
            ],'observed_at'=>$observedAt,
        ];}
        $approvals=[];
        foreach(array_slice($this->listish($cc['approvals']??[]),0,250) as $row){$r=$this->arrayish($row);if($r===[])continue;$manager=$this->arrayish($r['manager']??[]);$approvals[]=[
            'task_id'=>(string)($this->scalar($r['task_uuid']??$r['task_id']??$r['id']??'')??''),'title'=>$this->scalar($r['title']??null),'status'=>$this->upper($r['status']??'UNKNOWN'),
            'manager_id'=>$this->scalar($r['manager_id']??$manager['id']??null),'manager'=>$this->scalar(is_array($r['manager']??null)?($manager['name']??null):($r['manager']??null)),
            'assignee_id'=>$this->scalar($r['assignee_member_id']??$this->arrayish($r['assignee']??[])['id']??null),'priority'=>$this->int($r['priority']??0),
            'created_at'=>$this->scalar($r['created_at']??null),'submitted_at'=>$this->scalar($r['submitted_at']??null),'updated_at'=>$this->scalar($r['updated_at']??$r['last_activity_at']??null),'deadline_at'=>$this->scalar($r['deadline_at']??null),
            'trace_id'=>$this->scalar($r['trace_id']??null),'correlation_id'=>$this->scalar($r['correlation_id']??null),
        ];}
        $handoffs=[];
        foreach(array_slice($this->listish($cc['handoffs']??[]),0,250) as $row){$r=$this->arrayish($row);if($r===[])continue;$handoffs[]=[
            'handoff_id'=>(string)($this->scalar($r['handoff_uuid']??$r['id']??'')??''),'task_id'=>(string)($this->scalar($r['task_uuid']??$r['task_id']??'')??''),'status'=>$this->upper($r['status']??'UNKNOWN'),
            'origin_manager_id'=>$this->scalar($r['origin_manager_id']??$r['from_manager_id']??null),'receiver_manager_id'=>$this->scalar($r['receiver_manager_id']??$r['to_manager_id']??null),
            'created_at'=>$this->scalar($r['created_at']??null),'updated_at'=>$this->scalar($r['updated_at']??null),'reason'=>$this->scalar($r['reason']??null),
        ];}
        $performance=[];
        foreach(array_slice($this->listish($cc['performance']??[]),0,500) as $row){$r=$this->arrayish($row);if($r===[])continue;$performance[]=[
            'member_id'=>$this->scalar($r['member_id']??null),'name'=>$this->scalar($r['name']??null),'role'=>$this->scalar($r['role']??null),'division'=>$this->scalar($r['division']??null),
            'open_tasks'=>$this->int($r['open_tasks']??0),'completed_tasks'=>$this->int($r['completed_tasks']??0),'manager_acceptance_rate'=>$this->number($r['manager_acceptance_rate']??null),
            'downstream_acceptance_rate'=>$this->number($r['downstream_acceptance_rate']??null),'policy_violations'=>$this->int($r['policy_violations']??0),'recent_serious_failure'=>(bool)($r['recent_serious_failure']??false),
            'maturity'=>$this->arrayish($r['maturity']??[]),'authority_changed'=>false,
        ];}
        $outcomeRefs=[];foreach(array_slice($this->listish($cc['outcome_refs']??[]),0,200) as $row){$r=$this->arrayish($row);if($r!==[])$outcomeRefs[]=['task_id'=>$this->scalar($r['task_id']??null),'status'=>$this->upper($r['status']??null),'trace_id'=>$this->scalar($r['trace_id']??null),'correlation_id'=>$this->scalar($r['correlation_id']??null),'receipt_ref'=>$this->scalar($r['receipt_ref']??null),'rewind_ref'=>$this->scalar($r['rewind_ref']??null),'outcome_ref'=>$this->scalar($r['outcome_ref']??null)];}
        $summary=$this->arrayish($cc['summary']??[]);
        return ['schema_version'=>'1.0','status'=>$status,'source'=>'titan-ai-workforce','observed_at'=>$observedAt,'members'=>$members,'relationships'=>$relationships,'queues'=>$queues,'approvals'=>$approvals,'handoffs'=>$handoffs,'performance'=>$performance,'outcome_refs'=>$outcomeRefs,'summary'=>[
            'active_staff'=>$this->int($summary['active_staff']??count($members)),'divisions'=>$this->int($summary['divisions']??0),'pending_approvals'=>$this->int($summary['pending_approvals']??count($approvals)),'open_handoffs'=>$this->int($summary['open_handoffs']??count($handoffs)),'staffing_recommendations'=>$this->int($summary['staffing_recommendations']??0),
        ],'trust_health'=>$this->arrayish($cc['trust_health']??[]),'outcome_health'=>$this->arrayish($cc['outcome_health']??[]),'can_raise_authority'=>false,'authority_changed'=>false,'authority_owner'=>'titan-autonomy'];
    }

    private function empty(string $status,?string $observedAt,mixed $reason):array{return ['schema_version'=>'1.0','status'=>$status,'source'=>'titan-ai-workforce','observed_at'=>$observedAt,'reason'=>$this->scalar($reason),'members'=>[],'relationships'=>[],'queues'=>[],'approvals'=>[],'handoffs'=>[],'performance'=>[],'outcome_refs'=>[],'summary'=>['active_staff'=>0,'divisions'=>0,'pending_approvals'=>0,'open_handoffs'=>0,'staffing_recommendations'=>0],'trust_health'=>[],'outcome_health'=>[],'can_raise_authority'=>false,'authority_changed'=>false,'authority_owner'=>'titan-autonomy'];}
    private function arrayish(mixed $v):array{if(is_array($v))return $v;if(is_object($v)){if(method_exists($v,'toArray')){$a=$v->toArray();return is_array($a)?$a:[];}if($v instanceof \JsonSerializable){$a=$v->jsonSerialize();return is_array($a)?$a:[];}return get_object_vars($v);}return [];}
    private function listish(mixed $v):array{$a=$this->arrayish($v);return array_is_list($a)?$a:array_values($a);}
    private function scalar(mixed $v):int|float|string|bool|null{return is_scalar($v)?$v:null;}
    private function upper(mixed $v):?string{$s=$this->scalar($v);if($s===null)return null;$s=strtoupper(trim((string)$s));return $s===''?null:$s;}
    private function int(mixed $v):int{return is_numeric($v)?max(0,(int)$v):0;}
    private function number(mixed $v):?float{return is_numeric($v)?(float)$v:null;}
}
