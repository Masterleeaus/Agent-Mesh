<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\DecisionIntelligence;

final class GovernanceEvidenceSanitizer
{
    public function __construct(private readonly int $maxDepth=8,private readonly int $maxItems=100,private readonly int $maxStringLength=2048){}

    /** @return array<string|int,mixed> */
    public function sanitize(array $value): array { return $this->walk($value,0); }

    /** @return array<string|int,mixed> */
    private function walk(array $value,int $depth): array
    {
        if($depth >= $this->maxDepth) return [];
        $out=[];$count=0;
        foreach($value as $key=>$item){
            if($count++ >= $this->maxItems) break;
            if(is_string($key) && $this->blockedKey($key)) continue;
            if(is_array($item)){$out[$key]=$this->walk($item,$depth+1);continue;}
            if(is_string($item)){$out[$key]=substr($item,0,$this->maxStringLength);continue;}
            if(is_int($item)||is_float($item)||is_bool($item)||$item===null){$out[$key]=$item;}
        }
        return $out;
    }

    private function blockedKey(string $key): bool
    {
        $k=strtolower(trim($key));
        if(in_array($k,['chain_of_thought','chain-of-thought','reasoning','prompt','raw_prompt','system_prompt','developer_prompt','raw_response','provider_response','authorization','cookie','set-cookie','api_key','apikey','password','credential','credentials'],true)) return true;
        return preg_match('/(^|_)(access|refresh|auth|bearer)?_?token$/',$k)===1 || preg_match('/(^|_)(api_?)?secret$/',$k)===1 || str_ends_with($k,'_password');
    }
}
