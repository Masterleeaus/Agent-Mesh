# Titan Signal Engine Architecture

Titan Signal Engine is the governed, immutable telemetry and causal-observation fabric for Titan Zero. It records observations; authoritative domain extensions remain the source of business truth.

## Primary layers

1. Trusted execution context and emitter attestation.
2. Event type registry and canonical immutable `SignalEnvelope`.
3. Durable event store with idempotency and integrity checks.
4. Hot/cold causal graph, trace profiles and Rewind-oriented correlation with archive-integrity completeness semantics.
5. Isolated subscriber delivery with durable delivery ledger.
6. Pulse projections and operational read models.
7. Rule-based anomaly detection.
8. Retention, privacy overlays, archive and governed pruning.
9. Tenant/admin operational console.

Cross-extension integration uses public contracts and registries. Signal does not import another Titan extension's internal namespace and does not authorize domain mutations.
