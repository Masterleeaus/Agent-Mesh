<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_titan_connect_voice_transcripts') && ! Schema::hasColumn('ext_titan_connect_voice_transcripts', 'client_event_id')) {
            Schema::table('ext_titan_connect_voice_transcripts', function (Blueprint $table): void {
                $table->string('client_event_id', 191)->nullable()->after('voice_call_id');
                $table->unique(['company_id', 'voice_call_id', 'client_event_id'], 'tc_voice_transcript_event_unique');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('ext_titan_connect_voice_transcripts') && Schema::hasColumn('ext_titan_connect_voice_transcripts', 'client_event_id')) {
            Schema::table('ext_titan_connect_voice_transcripts', function (Blueprint $table): void {
                $table->dropUnique('tc_voice_transcript_event_unique');
                $table->dropColumn('client_event_id');
            });
        }
    }
};
