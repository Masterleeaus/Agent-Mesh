<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\StrictBoolean;
use InvalidArgumentException;

final class GovernanceDecision
{
    public function __construct(
        private readonly bool $allowed,
        private readonly string $decisionReference,
        private readonly bool $approvalRequired,
        private readonly ?string $approvalReference = null,
        private readonly ?string $reason = null,
    ) {
        self::assertText($this->decisionReference, 'decision_reference');
        if ($this->approvalReference !== null) { self::assertText($this->approvalReference, 'approval_reference'); }
        if ($this->reason !== null) { self::assertText($this->reason, 'reason', 1000); }
        if ($this->allowed && $this->approvalRequired && $this->approvalReference === null) {
            throw new InvalidArgumentException('Allowed governance decision requiring approval must include approval_reference.');
        }
    }
    /** @param array<string,mixed> $data */
    public static function fromArray(array $data): self
    {
        return new self(StrictBoolean::parse($data['allowed'] ?? false, 'allowed'),self::required($data['decision_reference']??null,'decision_reference'),StrictBoolean::parse($data['approval_required'] ?? false, 'approval_required'),self::nullable($data['approval_reference']??null),self::nullable($data['reason']??null));
    }
    public function allowed(): bool{return $this->allowed;}
    public function decisionReference(): string{return $this->decisionReference;}
    public function approvalRequired(): bool{return $this->approvalRequired;}
    public function approvalReference(): ?string{return $this->approvalReference;}
    public function reason(): ?string{return $this->reason;}
    /** @return array<string,mixed> */ public function toArray(): array{return ['allowed'=>$this->allowed,'decision_reference'=>$this->decisionReference,'approval_required'=>$this->approvalRequired,'approval_reference'=>$this->approvalReference,'reason'=>$this->reason];}
    private static function required(mixed $v,string $f): string{if(!is_string($v)||trim($v)==='')throw new InvalidArgumentException("{$f} is required.");return trim($v);} private static function nullable(mixed $v):?string{if($v===null)return null;if(!is_string($v))throw new InvalidArgumentException('optional governance text must be string or null.');return trim($v);} private static function assertText(string $v,string $f,int $m=300):void{if(trim($v)===''||strlen($v)>$m)throw new InvalidArgumentException("{$f} is invalid.");}
}
