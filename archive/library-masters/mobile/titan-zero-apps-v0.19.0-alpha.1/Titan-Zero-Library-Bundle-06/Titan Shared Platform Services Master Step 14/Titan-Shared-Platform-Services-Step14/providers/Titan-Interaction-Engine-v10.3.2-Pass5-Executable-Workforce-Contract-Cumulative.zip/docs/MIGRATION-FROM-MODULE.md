# Migration from the legacy module package

Current upgrade mapping:

| Legacy | MagicAI-native extension |
|---|---|
| `TitanZero\Interaction\...` | `App\Extensions\InteractionEngine\System\...` |
| `TitanZero\Engines\...` | `App\Extensions\InteractionEngine\System\Engines\...` |
| `src/Providers/InteractionServiceProvider.php` | `System/InteractionEngineServiceProvider.php` |
| `config/interaction.php` | `config/interaction-engine.php` with a legacy compatibility shim |
| root `interactions/` | `resources/interactions/` |
| root `wizards/` | `resources/wizards/` |
| root `templates/` | `resources/templates/` |
| `/api/interaction/...` | `/api/interaction-engine/v1/...` plus a temporary compatibility alias |

Phase 3 establishes WorkCore `company_id` as the authoritative tenant boundary. Internal legacy envelopes may still call the copied value `tenant_id`, but it originates from the trusted company context.

Persistence mapping for collision-prone legacy tables:

| Legacy generic table | Extension-owned table |
|---|---|
| `queued_commands` | `interaction_queued_commands` |
| `episodic_memory` | `interaction_episodic_memory` |
| `semantic_memory` | `interaction_semantic_memory` |
| `audit_logs` | `interaction_audit_logs` |
| `governance_logs` | `interaction_governance_logs` |
| `user_actions` | `interaction_user_actions` |
| `user_preferences` | `interaction_user_preferences` |

The new tables carry explicit `company_id`. Legacy generic rows are deliberately **not** bulk-copied because those tables historically lack a trustworthy company key. They remain untouched for explicit reconciliation.

A separate forward migration backfills legacy interaction-run ownership only where the host provides an explicit `users.company_id`. Answers/events inherit a tenant only from a run whose company ownership is already known. Unresolved legacy rows remain inaccessible rather than being guessed into a tenant.

The legacy standalone `module.json` and Composer package metadata are no longer part of the runtime extension contract. Development-only metadata is retained under `development/` while the TypeScript build manifest remains available during this work-in-progress phase.
