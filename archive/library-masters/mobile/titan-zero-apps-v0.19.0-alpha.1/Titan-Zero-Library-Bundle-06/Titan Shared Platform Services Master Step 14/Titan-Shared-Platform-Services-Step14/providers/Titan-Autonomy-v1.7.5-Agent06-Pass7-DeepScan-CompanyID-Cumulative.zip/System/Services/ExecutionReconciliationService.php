<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\{AutonomyQueryContract,ExecutionPostconditionVerifierContract,ExecutionReceiptReconcilerContract,ExecutionReceiptStoreContract,ExecutionReconciliationContract,TenantAssuranceBridgeContract};
use App\Extensions\TitanAutonomy\System\DTOs\{CapabilityState,EvidenceSnapshot,GovernedCapabilityCommand,OutcomeObservation};
use App\Extensions\TitanAutonomy\System\Enums\{AutonomyLevel,RiskClass,UserResponseClass};

final class ExecutionReconciliationService implements ExecutionReconciliationContract, ExecutionReceiptReconcilerContract
{
    /** @param array<string,?int> $windowMinutesByRisk */
    public function __construct(
        private readonly ExecutionReceiptStoreContract $receipts,
        private readonly ExecutionPostconditionVerifierContract $verifier,
        private readonly AutonomyRuntimeService $runtime,
        private readonly AutonomyQueryContract $query,
        private readonly TenantAssuranceBridgeContract $assurance,
        private readonly string $policyVersion,
        private readonly array $windowMinutesByRisk = ['low'=>15,'medium'=>60,'high'=>240,'critical'=>null],
        private readonly ExecutionReceiptSanitizer $sanitizer = new ExecutionReceiptSanitizer(),
    ) {}

    public function capture(
        CapabilityState $state,
        GovernedCapabilityCommand $command,
        array $context,
        array $commandResult,
        array $assuranceAtExecution,
        ?int $userId,
    ): array {
        $correlationId = trim((string) ($command->correlationId ?? ''));
        if ($correlationId === '') throw new \InvalidArgumentException('AUTONOMOUS_EXECUTION_CORRELATION_ID_REQUIRED');

        $verification = $this->verifier->verify($state, $command, $commandResult, $context);
        $status = (string) ($commandResult['status'] ?? 'unknown');
        $executed = in_array($status, ['executed','ok'], true);
        $window = $this->windowMinutesByRisk[$state->risk->value] ?? null;
        $maturesAt = $window === null ? null : gmdate('Y-m-d H:i:s', time() + max(0, (int) $window) * 60);

        $observationStatus = !$executed ? 'finalized' : ($window === null ? 'awaiting_human_verification' : 'observing');

        $receiptId = $this->receipts->create([
            'tenant_company_id'=>$state->tenantCompanyId,
            'user_id'=>$userId,
            'capability'=>$state->capability,
            'workflow_key'=>$state->workflowKey,
            'risk'=>$state->risk->value,
            'autonomy_level'=>$state->currentLevel->key(),
            'correlation_id'=>$correlationId,
            'interaction_id'=>$command->interactionId,
            'session_id'=>$command->sessionId,
            'idempotency_key'=>$command->idempotencyKey,
            'command_status'=>$status,
            'command_payload'=>$this->sanitizer->sanitize($command->payload),
            'command_result'=>$this->sanitizer->sanitize($commandResult),
            'context'=>$this->sanitizer->sanitize($context),
            'assurance_at_execution'=>$this->sanitizer->sanitize($assuranceAtExecution),
            'postcondition_at_execution'=>$verification,
            'observation_status'=>$observationStatus,
            'matures_at'=>$maturesAt,
            'policy_version'=>$this->policyVersion,
        ]);

        if (!$executed) {
            $runtime = $this->record($state, UserResponseClass::Failed, false, false, false, null, $context, $command->payload, $command->payload, [
                'dispatch_status'=>$status,'command_result'=>$commandResult,'postcondition'=>$verification,
            ], $assuranceAtExecution, $userId);
            $this->receipts->finalize($receiptId, $this->runtimeRefs($runtime) + ['final_label'=>'failed','finalized_at'=>gmdate('Y-m-d H:i:s')]);
            return ['receipt_id'=>$receiptId,'observation_status'=>'finalized','learning_label'=>'failed'];
        }

        // A successful dispatch never becomes positive evidence at capture time.
        return ['receipt_id'=>$receiptId,'observation_status'=>$observationStatus,'matures_at'=>$maturesAt,'postcondition_status'=>(string)($verification['status']??'unavailable')];
    }

    public function finalizeDue(int $limit = 100): int
    {
        $count = 0;
        foreach ($this->receipts->due(max(1, min(500, $limit))) as $receipt) {
            if (($receipt['observation_status'] ?? '') !== 'observing') continue;
            $this->finalizeReceipt($receipt);
            $count++;
        }
        return $count;
    }

    public function finalizeReceiptDue(int $tenantCompanyId, string $correlationId): array
    {
        $receipt = $this->receipts->findByCorrelation($tenantCompanyId, trim($correlationId));
        if ($receipt === null) throw new \RuntimeException('EXECUTION_RECEIPT_NOT_FOUND');
        if (($receipt['observation_status'] ?? '') !== 'observing') throw new \RuntimeException('EXECUTION_RECEIPT_NOT_OBSERVING');
        $maturesAt = isset($receipt['matures_at']) && $receipt['matures_at'] !== null ? strtotime((string)$receipt['matures_at']) : false;
        if ($maturesAt === false) throw new \RuntimeException('EXECUTION_RECEIPT_REQUIRES_HUMAN_VERIFICATION');
        if ($maturesAt > time()) throw new \RuntimeException('EXECUTION_RECEIPT_NOT_MATURED');
        return $this->finalizeReceipt($receipt);
    }

    private function finalizeReceipt(array $receipt): array
    {
        $stateRow = $this->query->capabilityState((int) $receipt['tenant_company_id'], (string) $receipt['capability'], (string) ($receipt['workflow_key'] ?? ''));
        if ($stateRow === null) {
            $fields = ['final_label'=>'insufficient_information','finalized_at'=>gmdate('Y-m-d H:i:s'),'final_reason_codes'=>['CAPABILITY_STATE_NOT_FOUND']];
            $this->receipts->finalize((string)$receipt['public_id'], $fields);
            return ['status'=>'finalized','final_label'=>'insufficient_information','reason_codes'=>['CAPABILITY_STATE_NOT_FOUND'],'correlation_id'=>$receipt['correlation_id']??null];
        }
        $state = $this->hydrateState($stateRow);
        $command = new GovernedCapabilityCommand(
            capability:(string)$receipt['capability'],
            payload:(array)($receipt['command_payload']??[]),
            workflowKey:(string)($receipt['workflow_key']??''),
            correlationId:(string)($receipt['correlation_id']??''),
            interactionId:isset($receipt['interaction_id'])?(string)$receipt['interaction_id']:null,
            sessionId:isset($receipt['session_id'])?(string)$receipt['session_id']:null,
            idempotencyKey:isset($receipt['idempotency_key'])?(string)$receipt['idempotency_key']:null,
            trustedInteractionMapped:true,
        );
        $context = (array) ($receipt['context'] ?? []);
        $verification = $this->verifier->verify($state, $command, (array)($receipt['command_result']??[]), $context);
        $assurance = $this->assurance->evaluateForTenant($state->tenantCompanyId, $state->capability, $state->workflowKey, [
            'tenant_company_id'=>$state->tenantCompanyId,
            'current_level'=>$state->currentLevel->key(),
            'scope'=>$state->scope,
            'reconciliation'=>true,
            'correlation_id'=>$receipt['correlation_id']??null,
            'postcondition'=>$verification,
        ]);

        $verificationStatus = (string) ($verification['status'] ?? 'unavailable');
        $assuranceStatus = strtoupper((string) ($assurance['status'] ?? 'RED'));
        if ($verificationStatus === 'failed') {
            $runtime = $this->record($state, UserResponseClass::AutonomousIncorrect, true, false, false, 'wrong_autonomous_action', $context, (array)($receipt['command_payload']??[]), (array)($receipt['command_payload']??[]), ['postcondition'=>$verification,'assurance'=>$assurance], $assurance, isset($receipt['user_id'])?(int)$receipt['user_id']:null);
            $label='incorrect';
        } elseif ($assuranceStatus === 'RED') {
            $runtime = $this->record($state, UserResponseClass::Exception, true, false, true, 'assurance_red', $context, (array)($receipt['command_payload']??[]), (array)($receipt['command_payload']??[]), ['postcondition'=>$verification,'assurance'=>$assurance], $assurance, isset($receipt['user_id'])?(int)$receipt['user_id']:null);
            $label='exception';
        } elseif ($verificationStatus === 'verified' && $assuranceStatus === 'GREEN') {
            $runtime = $this->record($state, UserResponseClass::AutonomousVerified, true, false, false, null, $context, (array)($receipt['command_payload']??[]), (array)($receipt['command_payload']??[]), ['postcondition'=>$verification,'assurance'=>$assurance,'action_selection_quality'=>1.0,'context_resolution_quality'=>1.0,'authority_decision_quality'=>1.0], $assurance, isset($receipt['user_id'])?(int)$receipt['user_id']:null);
            $label='correct';
        } else {
            $runtime = $this->record($state, UserResponseClass::InsufficientInformation, true, false, false, null, $context, (array)($receipt['command_payload']??[]), (array)($receipt['command_payload']??[]), ['postcondition'=>$verification,'assurance'=>$assurance], $assurance, isset($receipt['user_id'])?(int)$receipt['user_id']:null);
            $label='insufficient_information';
        }
        $fields = $this->runtimeRefs($runtime) + [
            'final_label'=>$label,
            'postcondition_at_reconciliation'=>$verification,
            'assurance_at_reconciliation'=>$assurance,
            'finalized_at'=>gmdate('Y-m-d H:i:s'),
        ];
        $this->receipts->finalize((string)$receipt['public_id'], $fields);
        return ['status'=>'finalized','final_label'=>$label,'correlation_id'=>$receipt['correlation_id']??null] + $this->runtimeRefs($runtime);
    }

    private function record(CapabilityState $state, UserResponseClass $class, bool $executionSucceeded, bool $reversed, bool $assuranceIncident, ?string $regressionCause, array $context, array $proposal, array $finalAction, array $outcome, array $assurance, ?int $userId): object
    {
        $settings = $this->query->learningSettings($state->tenantCompanyId);
        $learning = [
            'user'=>(bool)($settings['user_learning']??true),
            'business'=>(bool)($settings['business_learning']??true),
            'system'=>(bool)($settings['system_wide_learning']??false),
        ];
        $evidence = new EvidenceSnapshot(
            currentSuccessStreak:$state->currentSuccessStreak,
            totalSuccesses:$state->totalSuccesses,
            totalFailures:$state->totalFailures,
            totalEdits:$state->totalEdits,
            totalRejections:$state->totalRejections,
            totalReversals:$state->totalReversals,
            hasUnresolvedIncident:$assuranceIncident,
            assuranceAmber:strtoupper((string)($assurance['status']??''))==='AMBER',
            assuranceRed:strtoupper((string)($assurance['status']??''))==='RED',
        );
        $confidence = max(0.0,min(1.0,(float)($assurance['confidence']??0.0)));
        return $this->runtime->recordOutcome(
            $state,
            new OutcomeObservation($class,$executionSucceeded,$reversed,$assuranceIncident,false,false,$regressionCause),
            $evidence,
            $userId,
            $context,
            $proposal,
            $finalAction,
            $outcome,
            $confidence,
            $learning,
        );
    }

    private function runtimeRefs(object $runtime): array
    {
        return [
            'learning_ref'=>$runtime->learningReference??null,
            'gate_ref'=>$runtime->gateAuditReference??null,
            'regression_ref'=>$runtime->regressionAuditReference??null,
        ];
    }

    private function hydrateState(array $row): CapabilityState
    {
        $level = match((string)($row['current_level']??'suggest')){'assist'=>AutonomyLevel::Assist,'semi_auto'=>AutonomyLevel::SemiAuto,'auto'=>AutonomyLevel::Auto,'trusted_auto'=>AutonomyLevel::TrustedAuto,default=>AutonomyLevel::Suggest};
        return new CapabilityState(
            (int)$row['tenant_company_id'],(string)$row['capability'],(string)($row['workflow_key']??''),RiskClass::from((string)$row['risk']),$level,
            (int)($row['required_success_streak']??0),(int)($row['current_success_streak']??0),(int)($row['highest_success_streak']??0),(int)($row['total_successes']??0),(int)($row['total_failures']??0),(int)($row['total_edits']??0),(int)($row['total_rejections']??0),(int)($row['total_reversals']??0),(bool)($row['platform_gate_eligible']??false),is_array($row['scope']??null)?$row['scope']:[],
            isset($row['last_success_at']) && $row['last_success_at'] !== null ? (string)$row['last_success_at'] : null,
            isset($row['last_failure_at']) && $row['last_failure_at'] !== null ? (string)$row['last_failure_at'] : null
        );
    }
}
