# Blueprint / exact-host root-manifest note

Blueprint v4.0 Step10 correctly establishes that Installer 1.7.8 host behavior is the final compatibility authority. Its bundled `titan-installer-manifest.schema.json` currently models five root identity fields and disallows `name`, while the supplied real MagicAI/Titan Installer 1.7.8 `CustomExtensionManifestValidator` requires six fields: `schema`, `slug`, `name`, `version`, `folder`, and `provider`.

This package follows the actual host source. `extension.json` therefore contains the six host-required identity fields plus the non-circular `integrity.files` map. All richer architectural metadata remains exclusively in canonical `extension.manifest.json` schema 2.2.
