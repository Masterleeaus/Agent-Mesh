# Titan Signal Lifecycle Hardening v0.7.0

## Invariants

1. `titan_signal_events` remains immutable through the application model.
2. Privacy corrections use append-only overlays; they do not rewrite the event row.
3. Physical pruning is allowed only through `SignalLifecycleService`.
4. Pruning requires an explicit preview/confirmation flow and a verified archive.
5. Legal holds always win over expiry.
6. `critical_audit` events are never automatically prunable.
7. Archived representations honor active privacy overlays so cold storage does not resurrect redacted values.

## Retention classes

| Class | Default | Auto-prunable | Archive required |
|---|---:|---:|---:|
| `critical_audit` | indefinite | no | yes if explicitly exported |
| `audit` | 2555 days | yes | yes |
| `operational` | 730 days | yes | yes |
| `telemetry` | 90 days | yes | yes |
| `debug` | 30 days | yes | no |

Retention classification is a sidecar policy. It is not part of the canonical event checksum and can therefore evolve under governance without changing historical facts.

## Privacy overlays

Supported operations are deliberately small:

- `remove` on `payload.*` or `metadata.*`
- `replace` on `payload.*` or `metadata.*`

Overlay rows are themselves immutable and record reason, actor and timestamp. Standard presentation surfaces should use `SignalLifecycleContract::view()`.

## Archive format

The default driver writes gzip-compressed JSON Lines through Laravel Storage. The first line is a batch manifest; subsequent lines are archived records. A SHA-256 checksum over the compressed bytes is stored in `titan_signal_archive_batches` and verified before hot-event deletion.

The contract `SignalArchiveStoreContract` allows future S3/object-storage/Parquet implementations without changing lifecycle logic.

## Backpressure and rate limiting

Rate limits are keyed by scope + tenant/system + source + source component. Normal defaults are 10,000 events/minute per tenant source and 600,000/minute per system source. When delivery pressure crosses the configured threshold, the effective source limit is multiplied by the configured backpressure multiplier (default 0.5).

The limiter rejects before persistence with `SignalRateLimitException` (429 semantics); already accepted immutable events are never dropped retroactively.

## Housekeeping

`titan:signal-housekeeping --limit=5000` runs daily and removes only operational projection data:

- expired idempotency leases
- old delivered delivery-ledger rows
- old dead-letter rows after the longer configured horizon
- old resolved anomalies

It does not delete retained immutable Signal events.

## v0.14 transactional prune gate

Physical deletion now requires a persisted prune preview token and exact candidate hash, atomic lifecycle claims, a single active execution lease, verified archive state where required, and exact deleted-row count equality. See `TRANSACTIONAL-PRUNING.md`.
