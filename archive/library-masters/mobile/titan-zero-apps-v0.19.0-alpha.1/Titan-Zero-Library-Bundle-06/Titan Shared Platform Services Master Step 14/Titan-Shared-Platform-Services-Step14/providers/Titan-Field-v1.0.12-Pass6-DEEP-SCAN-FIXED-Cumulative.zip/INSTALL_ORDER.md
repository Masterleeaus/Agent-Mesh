# Titan Field Install / Upgrade Order

1. Install/upgrade **Titan CRM Core >= 1.3.0-alpha.24** while the extraction compatibility bridge remains active.
2. Install/upgrade **Titan Field**. Pass 1 safely adopts existing `crm_*` field data/menu rows; Pass 2 resolves CRM implementation dependencies only through Field-owned compatibility adapters; Pass 3 rejects cross-tenant/dangling field relationships through the central integrity gate; Pass 5 adopts governed command receipts and Field-owned permission aliases without renaming the historical routes/tables.
3. Optional Titan engines (Command Bus, Signal, Rewind, Risk, Assurance, Autonomy) may be installed independently. External command-bus adapters should target `FieldCommandGateway`; they must not write Field tables directly.
4. Titan Go/mobile consumers should continue treating Titan Field as authoritative for field-work mutations.

Do not install donor archives (`FieldCore.zip` or `Titan Operations Team.zip`) as competing runtime extensions.

## Pass 4 migration note

`2026_08_17_000002_create_titan_field_signal_outbox.php` must run before Field mutations are served by the upgraded provider. The migration is restartable and its `down()` method intentionally retains Signal/receipt evidence.


## Pass 5 migration note

`2026_08_17_000003_create_titan_field_command_receipts.php` must run before mutation traffic is moved to `GovernedFieldCommandGateway`. The table is retained on rollback because command receipts are idempotency, audit and rollback evidence. Existing legacy CRM field permission strings remain valid aliases through the Field-owned permission catalogue.

## Optional Titan Maps Intelligence peer
Titan Maps Intelligence may be installed before or after Titan Field. Titan Field must remain functional when Maps is absent/disabled. When both are active, Maps is the preferred spatial provider and Field remains the governed operational writer.


## Pass 15 install note

`2026_08_18_000009_create_titan_field_route_optimisation_proposals.php` is restartable and retains proposal/decision evidence on rollback. Titan Maps Intelligence is optional: without it, proposal requests return an explicit unavailable result and normal Field routes continue to operate. AI Workforce is also optional; the extension merely contributes its manifest when Workforce discovery is present. Existing Crew and Maps menu rows from the supplied host dump must be adopted, not duplicated.
