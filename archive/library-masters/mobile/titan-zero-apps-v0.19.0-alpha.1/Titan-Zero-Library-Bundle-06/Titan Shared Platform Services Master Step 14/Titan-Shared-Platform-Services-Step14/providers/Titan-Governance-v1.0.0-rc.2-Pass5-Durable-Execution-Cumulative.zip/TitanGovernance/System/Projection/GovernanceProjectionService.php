<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Projection;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceProjectionSinkContract;

final class GovernanceProjectionService
{
    public function __construct(private readonly GovernanceProjectionSinkContract $sink) {}

    /** @return list<array<string,mixed>> */
    public function history(int $tenantCompanyId, string $type, int $limit=50): array
    {
        return $this->sink->recent($tenantCompanyId,$type,$limit);
    }

    /**
     * Persist normalized Governance-owned projections only. Source engines retain canonical truth.
     *
     * @return array<string,mixed>
     */
    public function persist(int $tenantCompanyId, array $trustMap, array $autonomyEvidence, array $sourceHealth, array $signalIntelligence): array
    {
        $writes=[];
        $writes[]=$this->sink->record($tenantCompanyId,'trust-map','titan-autonomy',(string)($trustMap['source_status'] ?? 'UNAVAILABLE'),$trustMap,['observed_at'=>$trustMap['observed_at'] ?? null]);
        $writes[]=$this->sink->record($tenantCompanyId,'autonomy-evidence','titan-autonomy',(string)($autonomyEvidence['source_status'] ?? 'UNAVAILABLE'),$autonomyEvidence,['observed_at'=>$autonomyEvidence['observed_at'] ?? null]);

        foreach (($sourceHealth['sources'] ?? []) as $sourceKey=>$row) {
            if(!is_string($sourceKey) || !is_array($row)) continue;
            $payload=['schema_version'=>'1.0','source'=>$sourceKey] + $row;
            $writes[]=$this->sink->record($tenantCompanyId,'source-health',$sourceKey,(string)($row['status'] ?? 'UNAVAILABLE'),$payload,['source_id'=>$sourceKey,'observed_at'=>$row['observed_at'] ?? null]);
        }

        $heatmap=is_array($signalIntelligence['heatmap'] ?? null)?$signalIntelligence['heatmap']:[];
        $writes[]=$this->sink->record($tenantCompanyId,'signal-heatmap','titan-signal',(string)($signalIntelligence['source_status'] ?? 'UNAVAILABLE'),$heatmap,['observed_at'=>$signalIntelligence['observed_at'] ?? null]);

        foreach (($signalIntelligence['operational_pressure']['items'] ?? []) as $row) {
            if(!is_array($row)) continue;
            $component=(string)($row['source_component'] ?? 'unknown');
            $severity=match((string)($row['pressure_band'] ?? 'NORMAL')){'CRITICAL'=>'critical','HIGH'=>'error','ELEVATED'=>'warning',default=>'info'};
            $writes[]=$this->sink->record($tenantCompanyId,'operational-pressure',$component,'OBSERVED',['schema_version'=>'1.0']+$row,['source_id'=>$component,'severity'=>$severity,'observed_at'=>$row['observed_at'] ?? $signalIntelligence['observed_at'] ?? null]);
        }

        foreach (($signalIntelligence['circuit_breakers']['items'] ?? []) as $row) {
            if(!is_array($row)) continue;
            $component=(string)($row['source_component'] ?? 'unknown');
            $key=(string)($row['breaker_key'] ?? 'unknown');
            $severity=($row['state'] ?? null)==='OPEN'?'critical':(($row['state'] ?? null)==='HALF_OPEN'?'warning':'info');
            $writes[]=$this->sink->record($tenantCompanyId,'circuit-breaker',$component,(string)($row['state'] ?? 'UNKNOWN'),['schema_version'=>'1.0']+$row,['source_id'=>$key,'severity'=>$severity,'observed_at'=>$row['observed_at'] ?? $signalIntelligence['observed_at'] ?? null]);
        }

        $history=$this->sink->recent($tenantCompanyId,'source-health',50);
        $unhealthy=0;
        foreach($history as $row){$status=strtoupper((string)($row['status'] ?? 'UNAVAILABLE'));if(!in_array($status,['HEALTHY','DISABLED'],true))$unhealthy++;}
        $rate=$history===[]?0.0:round(($unhealthy/count($history))*100,1);

        return [
            'write_status'=>in_array(false,$writes,true)?'DEGRADED':'HEALTHY',
            'writes_attempted'=>count($writes),
            'writes_succeeded'=>count(array_filter($writes,static fn(bool $ok):bool=>$ok)),
            'source_health_history'=>$history,
            'recent_incident_rate_pct'=>$rate,
        ];
    }
}
