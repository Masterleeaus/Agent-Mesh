# Security

## Trusted identity boundary

Tenant, actor ID, actor type, permissions and authority are derived from the authenticated MagicAI/Titan host principal. They are not trusted when supplied by request, generated plan, tool payload or AI agent output.

The web middleware rejects conflicting `tenant_company_id`, `actor_id` and `actor_type` values with a 403 security code. `TrustedContextFactory` applies the same rule outside HTTP request handling.

## Tenant isolation

- Core canonical tenant key: `tenant_company_id`.
- `DatabasePlanRepository` scopes lookups by tenant and forces writes to the trusted runtime tenant.
- Model profile queries are tenant-only by default.
- Global model fallback must be explicitly enabled by the caller/policy.
- Foreign-tenant model profiles are always denied.
- The validator rejects actor/runtime tenant mismatch before DAG validation.

## Authority

Capabilities currently declared:

- `ai.core.read`
- `ai.core.health.read`
- `ai.core.admin`
- `ai.core.plan.create`

`CapabilityAuthorizer` requires a trusted actor and fails closed on missing capability or insufficient authority level.

## Queue boundary

AI Core still declares `queues.used=false`. Pass 3 only introduces `RestoresTrustedTenantContext` as the mandatory tenant-check foundation for future jobs; it does not claim active queue execution.

## Mutation boundary

AI Core performs no direct consequential business-domain mutation. Pass 4 adds `CommandBusMutationBoundary`, which is the sole Core-side delegation path for future consequential writes. The boundary is fail closed in two independent ways: execution is disabled by default, and a governance preflight report must be executable/`ALLOW` before dispatch can reach the Command Bus gateway.

Unavailable Command Bus or governance engines never trigger a direct-write fallback.
