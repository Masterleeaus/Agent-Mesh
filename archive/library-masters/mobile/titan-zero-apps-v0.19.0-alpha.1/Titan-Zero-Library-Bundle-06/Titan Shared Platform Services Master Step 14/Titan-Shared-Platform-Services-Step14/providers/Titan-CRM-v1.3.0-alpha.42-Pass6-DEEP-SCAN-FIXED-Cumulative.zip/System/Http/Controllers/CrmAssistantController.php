<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\AI\CrmAssistantExecutionService;
use App\Extensions\Crm\System\Services\CrmAssistantChatService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use InvalidArgumentException;

final class CrmAssistantController extends Controller
{
    public function __construct(private CrmAssistantChatService $assistant) {}

    public function index(Request $request)
    {
        abort_unless((bool) config('crm.crm_assistant_enabled', true), 404);

        $scope = trim((string) $request->query('scope', 'all'));
        if ($scope === '' || preg_match('/^[A-Za-z0-9:_-]{1,100}$/', $scope) !== 1) {
            $scope = 'all';
        }
        $seed = trim((string) $request->query('seed', ''));
        $seed = mb_substr($seed, 0, 1000);

        return view('crm::assistant.index', [
            'templateType' => $this->assistant->templateType(),
            'scope' => $scope,
            'seed' => $seed,
        ]);
    }

    public function executeWeb(Request $request, CrmAssistantExecutionService $execution)
    {
        $tool = trim((string) $request->input('tool', ''));
        if ($tool === '') {
            return response()->json(['message' => 'CRM tool is required.'], 422);
        }
        return $this->execute($request, $execution, $tool);
    }

    public function execute(Request $request, CrmAssistantExecutionService $execution, string $tool)
    {
        abort_unless((bool) config('crm.crm_assistant_enabled', true), 404);
        try {
            return response()->json($execution->execute((int) $request->user()->id, $tool, (array) $request->input('arguments', [])));
        } catch (InvalidArgumentException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }
    }
}
