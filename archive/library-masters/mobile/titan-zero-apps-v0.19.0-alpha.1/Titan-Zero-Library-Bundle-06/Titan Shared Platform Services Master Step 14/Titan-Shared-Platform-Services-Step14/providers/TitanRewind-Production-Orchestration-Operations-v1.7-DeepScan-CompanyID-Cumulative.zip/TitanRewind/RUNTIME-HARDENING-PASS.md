# TitanRewind — Workforce Runtime Hardening Pass

## Changes

- Added `System/Workforce/WorkforceLoopRuntime.php` and bound it as a singleton in the extension service provider.
- Added fail-closed dependency health aggregation across the six canonical availability states.
- Enforced canonical `company_id`; `tenant_company_id` remains legacy adapter compatibility only and cannot substitute for canonical runtime context.
- Enforced `trace_id`, `correlation_id`, `causation_id`, and `root_causation_id` on cross-extension handoffs.
- Added provider/version pinning, authority-neutral handoff envelopes, and explicit Workforce work-item ownership.
- Enforced outcome lineage plus execution receipts before outcomes are accepted into the learning loop.
- Marked direct host-menu database access as compatibility-only, outside Workforce identity/authority/data-plane contracts.
- Added standalone runtime-hardening regression coverage.

## Verification

See the batch `FINAL-VERIFICATION.txt`; verification is performed again against freshly extracted final ZIPs.
