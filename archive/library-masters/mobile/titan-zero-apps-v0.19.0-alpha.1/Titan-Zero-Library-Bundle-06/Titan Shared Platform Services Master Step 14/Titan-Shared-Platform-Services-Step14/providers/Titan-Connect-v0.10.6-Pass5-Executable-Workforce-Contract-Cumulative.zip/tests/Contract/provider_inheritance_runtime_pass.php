<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$checks = 0;
$failures = [];

$check = static function (bool $ok, string $message) use (&$checks, &$failures): void {
    $checks++;
    if (! $ok) {
        $failures[] = $message;
    }
};

$voice = file_get_contents($root.'/System/Providers/VoiceProvider.php');
$check($voice !== false, 'VoiceProvider source is readable');
$check(! str_contains((string) $voice, 'private readonly ProviderHttpClient $http'), 'VoiceProvider must not narrow/redeclare inherited $http property');
$check(str_contains((string) $voice, 'parent::__construct($http)'), 'VoiceProvider delegates HTTP client storage to AbstractMessagingProvider');

$providerFiles = glob($root.'/System/Providers/*Provider.php') ?: [];
foreach ($providerFiles as $file) {
    $source = file_get_contents($file) ?: '';
    if (! str_contains($source, 'extends AbstractMessagingProvider')) {
        continue;
    }
    $check(! preg_match('/(?:private|public)\s+readonly\s+ProviderHttpClient\s+\$http/', $source), basename($file).' must not redeclare inherited $http with incompatible visibility');
}

$tmp = tempnam(sys_get_temp_dir(), 'tc-provider-runtime-');
if ($tmp === false) {
    fwrite(STDERR, "Unable to allocate provider runtime test fixture\n");
    exit(1);
}
$fixture = <<<'PHP'
<?php
require %s;
require %s;
require %s;
require %s;
require %s;
require %s;
require %s;
require %s;
require %s;
require %s;
require %s;
require %s;
echo "provider-runtime-ok\n";
PHP;
file_put_contents($tmp, sprintf(
    $fixture,
    var_export($root.'/System/Contracts/MessagingProvider.php', true),
    var_export($root.'/System/Contracts/ProviderHttpClient.php', true),
    var_export($root.'/System/Contracts/MobilePushGateway.php', true),
    var_export($root.'/System/Providers/AbstractMessagingProvider.php', true),
    var_export($root.'/System/Providers/WhatsAppProvider.php', true),
    var_export($root.'/System/Providers/MessengerProvider.php', true),
    var_export($root.'/System/Providers/InstagramProvider.php', true),
    var_export($root.'/System/Providers/TelegramProvider.php', true),
    var_export($root.'/System/Providers/SmsProvider.php', true),
    var_export($root.'/System/Providers/PushProvider.php', true),
    var_export($root.'/System/Providers/VoiceProvider.php', true),
    var_export($root.'/System/Providers/ProviderRegistry.php', true),
));
$output = [];
$exit = 0;
exec(escapeshellarg(PHP_BINARY).' '.escapeshellarg($tmp).' 2>&1', $output, $exit);
unlink($tmp);
$check($exit === 0, 'Complete provider inheritance graph must load under PHP 8.3: '.implode("\n", $output));

if ($failures !== []) {
    fwrite(STDERR, "Provider inheritance runtime contract FAILED ({$checks} checks)\n");
    foreach ($failures as $failure) {
        fwrite(STDERR, " - {$failure}\n");
    }
    exit(1);
}

echo "Provider inheritance runtime contract: {$checks}/{$checks} passed\n";
