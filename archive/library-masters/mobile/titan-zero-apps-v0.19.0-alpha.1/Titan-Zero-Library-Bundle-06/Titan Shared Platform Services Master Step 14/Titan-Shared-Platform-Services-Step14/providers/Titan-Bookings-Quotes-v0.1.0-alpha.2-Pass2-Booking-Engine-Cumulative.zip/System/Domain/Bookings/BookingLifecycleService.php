<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
use RuntimeException;
final readonly class BookingLifecycleService{
 private const TRANSITIONS=['create'=>[null,'requested'],'scope'=>['requested','scoped'],'quote'=>['scoped','quote_pending'],'confirm'=>['quote_pending','confirmed'],'cancel'=>['*','cancelled']];
 public function __construct(private BookingStore $store){}
 public function execute(BookingCommand $c):array{
  if(trim($c->idempotencyKey)==='')throw new RuntimeException('idempotency key required');
  if($old=$this->store->receipt($c->companyId,$c->idempotencyKey))return $old;
  $current=$this->store->find($c->companyId,$c->bookingRef);$version=(int)($current['version']??0);
  if($version!==$c->expectedVersion)throw new RuntimeException('stale booking version');
  $rule=self::TRANSITIONS[$c->action]??null;if(!$rule)throw new RuntimeException('illegal booking transition');
  $status=$current['status']??null;
  if($rule[0]!=='*'&&$rule[0]!==$status)throw new RuntimeException('illegal booking transition');
  $next=array_merge($current??[], $c->payload, ['company_id'=>$c->companyId,'public_id'=>$c->bookingRef,'status'=>$rule[1],'version'=>$version+1]);
  foreach(['tenant'.'_company_id','worker_id','schedule_id','invoice_id','payment_id'] as $forbidden)unset($next[$forbidden]);
  return $this->store->commit($c,$next);
 }
}
