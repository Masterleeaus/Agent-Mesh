<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

interface ReplyAssistant
{
    public function rewrite(int $companyId, int $actorId, string $message, string $variant): string;
}
