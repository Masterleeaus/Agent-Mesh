<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Providers;

use App\Extensions\TitanConnect\System\Contracts\ProviderHttpClient;
use App\Extensions\TitanConnect\System\DTO\ProviderSendResult;
use RuntimeException;

final class WhatsAppTwilioTransport
{
    public function __construct(private readonly ProviderHttpClient $http) {}

    public function send(array $message, array $credentials): ProviderSendResult
    {
        $accountSid = trim((string) ($credentials['account_sid'] ?? ''));
        $username = trim((string) ($credentials['api_key_sid'] ?? $accountSid));
        $password = trim((string) ($credentials['api_key_secret'] ?? $credentials['auth_token'] ?? ''));
        if ($accountSid === '' || $password === '') throw new RuntimeException('Twilio WhatsApp account credentials are incomplete.');
        $from = $this->address((string) ($credentials['from'] ?? $credentials['whatsapp_from'] ?? $message['from'] ?? ''));
        $to = $this->address((string) ($message['to'] ?? ''));
        if ($from === 'whatsapp:' || $to === 'whatsapp:') throw new RuntimeException('Twilio WhatsApp sender and recipient are required.');
        $form = ['From' => $from, 'To' => $to, 'Body' => (string) ($message['body'] ?? '')];
        $attachment = data_get($message, 'metadata.attachments.0');
        if (is_array($attachment) && ! empty($attachment['public_url'])) $form['MediaUrl'] = (string) $attachment['public_url'];
        if (! empty($credentials['status_callback'])) $form['StatusCallback'] = (string) $credentials['status_callback'];
        $base = rtrim((string) ($credentials['api_base_url'] ?? config('titan-connect.providers.whatsapp.twilio.api_base_url', 'https://api.twilio.com/2010-04-01')), '/');
        $response = $this->http->request('POST', $base.'/Accounts/'.$accountSid.'/Messages.json', ['basic_auth' => [$username,$password], 'form' => $form]);
        if (! $response->isSuccessful()) throw new RuntimeException('Twilio WhatsApp send failed with HTTP '.$response->status.'.');
        $status = strtolower((string) $response->json('status', 'queued'));
        if (! in_array($status, ['queued','sending','sent','delivered','read','failed'], true)) $status = 'queued';
        return new ProviderSendResult($status, is_scalar($response->json('sid')) ? (string) $response->json('sid') : null, $response->json);
    }

    public function health(array $credentials): array
    {
        $accountSid = trim((string) ($credentials['account_sid'] ?? ''));
        $username = trim((string) ($credentials['api_key_sid'] ?? $accountSid));
        $password = trim((string) ($credentials['api_key_secret'] ?? $credentials['auth_token'] ?? ''));
        if ($accountSid === '' || $password === '') throw new RuntimeException('Twilio WhatsApp account credentials are incomplete.');
        $base = rtrim((string) ($credentials['api_base_url'] ?? config('titan-connect.providers.whatsapp.twilio.api_base_url', 'https://api.twilio.com/2010-04-01')), '/');
        $response = $this->http->request('GET', $base.'/Accounts/'.$accountSid.'.json', ['basic_auth' => [$username,$password]]);
        return ['ok'=>$response->isSuccessful(),'provider'=>'whatsapp','transport'=>'twilio','configured'=>true,'http_status'=>$response->status,'account_sid'=>$response->json('sid')];
    }

    public function basicAuth(array $credentials): array
    {
        $accountSid = trim((string) ($credentials['account_sid'] ?? ''));
        $username = trim((string) ($credentials['api_key_sid'] ?? $accountSid));
        $password = trim((string) ($credentials['api_key_secret'] ?? $credentials['auth_token'] ?? ''));
        if ($accountSid === '' || $password === '') throw new RuntimeException('Twilio WhatsApp account credentials are incomplete.');
        return [$username,$password];
    }

    private function address(string $value): string
    {
        $value = trim($value); if (str_starts_with(strtolower($value), 'whatsapp:')) return $value; return 'whatsapp:'.$value;
    }
}
