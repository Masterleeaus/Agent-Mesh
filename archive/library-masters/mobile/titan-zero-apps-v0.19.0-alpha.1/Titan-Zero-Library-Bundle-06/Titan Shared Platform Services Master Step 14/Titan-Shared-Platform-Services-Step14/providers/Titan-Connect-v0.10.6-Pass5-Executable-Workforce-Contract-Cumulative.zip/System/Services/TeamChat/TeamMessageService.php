<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services\TeamChat;

use App\Extensions\TitanConnect\System\Events\TeamChat\TeamMessageCreated;
use App\Extensions\TitanConnect\System\Events\TeamChat\TeamMessageRead as TeamMessageReadEvent;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamMessage;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamMessageRead;
use App\Extensions\TitanConnect\System\Policies\TeamChat\TeamConversationPolicy;
use App\Extensions\TitanConnect\System\Realtime\SafeRealtimeDispatcher;
use App\Extensions\TitanConnect\System\Services\MessagingAuditService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class TeamMessageService
{
    public function __construct(
        private readonly TeamConversationPolicy $policy,
        private readonly SafeRealtimeDispatcher $realtime,
        private readonly MessagingAuditService $audit,
    ) {
    }

    public function send(TeamConversation $conversation, int $companyId, int $actorId, string $body, ?string $localUuid = null, ?string $deviceId = null): TeamMessage
    {
        abort_unless((int) $conversation->company_id === $companyId && $conversation->hasParticipant($actorId), 403);
        abort_unless($this->policy->canPost($conversation, $actorId), 403);
        $body = trim($body);
        if ($body === '') {
            throw ValidationException::withMessages(['body' => 'Message body cannot be empty.']);
        }

        $message = DB::transaction(function () use ($conversation, $companyId, $actorId, $body, $localUuid, $deviceId): TeamMessage {
            $uuid = $localUuid ?: (string) Str::uuid();
            $message = TeamMessage::query()->firstOrCreate(
                ['uuid' => $uuid, 'company_id' => $companyId],
                [
                    'conversation_id' => $conversation->id,
                    'user_id' => $actorId,
                    'body' => $body,
                    'message_type' => 'text',
                    'originating_device_id' => $deviceId,
                    'created_by' => $actorId,
                    'updated_by' => $actorId,
                ],
            );

            if ((int) $message->conversation_id !== (int) $conversation->id) {
                abort(409, 'Idempotency UUID is already used by another conversation.');
            }

            if ($message->wasRecentlyCreated) {
                $conversation->increment('version');
                $conversation->touch();
            }
            return $message;
        });

        if ($message->wasRecentlyCreated) {
            $this->audit->record($companyId, $actorId, 'internal-message.sent', 'message', $message->uuid, null, ['conversation_uuid' => $conversation->uuid]);
            $this->realtime->dispatch(new TeamMessageCreated($message));
        }
        return $message;
    }

    public function markRead(TeamMessage $message, int $companyId, int $actorId): TeamMessageRead
    {
        abort_unless((int) $message->company_id === $companyId && $message->conversation->hasParticipant($actorId), 403);

        $receipt = TeamMessageRead::query()->firstOrCreate(
            ['message_id' => $message->id, 'user_id' => $actorId],
            ['company_id' => $companyId, 'read_at' => now()],
        );

        if ((int) $receipt->company_id !== $companyId) {
            abort(403);
        }

        $message->conversation->participants()
            ->where('company_id', $companyId)->where('user_id', $actorId)->whereNull('left_at')
            ->update(['last_read_at' => $receipt->read_at]);

        if ($receipt->wasRecentlyCreated) {
            $this->audit->record($companyId, $actorId, 'internal-message.read', 'message', $message->uuid, null, ['conversation_uuid' => $message->conversation->uuid]);
            $this->realtime->dispatch(new TeamMessageReadEvent($message, $actorId, $receipt->read_at->toIso8601String()));
        }
        return $receipt;
    }
}
