<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Compatibility\Legacy;

use App\Extensions\TitanModelCouncil\System\Compatibility\Legacy\Services\ModelCouncilService;
use App\Extensions\TitanModelCouncil\System\Governed\GovernedProviderRuntimeContract;

final class LegacyGovernedProviderRuntime implements GovernedProviderRuntimeContract
{
    public function __construct(private readonly ModelCouncilService $legacy)
    {
    }

    public function preflight(int $userId, array $modelSlugs): array
    {
        return $this->legacy->governedModelPreflight($userId, $modelSlugs);
    }

    public function execute(int $userId, string $modelSlug, array $messages): array
    {
        $result = $this->legacy->executeGovernedModel($userId, $modelSlug, $messages);
        $result['runtime'] = 'legacy-provider-compatibility';
        return $result;
    }

    public function charge(int $userId, string $modelSlug, string $responseText): int
    {
        return $this->legacy->chargeGovernedOutput($userId, $modelSlug, $responseText);
    }
}
