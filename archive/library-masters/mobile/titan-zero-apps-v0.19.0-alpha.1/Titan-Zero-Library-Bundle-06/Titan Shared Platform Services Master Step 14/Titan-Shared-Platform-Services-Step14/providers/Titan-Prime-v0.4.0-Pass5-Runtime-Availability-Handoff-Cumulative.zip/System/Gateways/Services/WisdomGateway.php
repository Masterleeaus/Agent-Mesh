<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Services;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Contracts\WisdomGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;

final class WisdomGateway extends AbstractEngineGateway implements WisdomGatewayContract
{
    public function engine(): EngineKey { return EngineKey::Wisdom; }

    public function recordOutcome(TraceContext $trace, array $subject, string $operationId): EngineGatewayResult
    {
        return $this->dispatch($trace, 'wisdom.record-outcome', ['subject' => $subject], $operationId);
    }
}
