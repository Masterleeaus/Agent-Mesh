# Upgrade 10.3.1 → 10.3.2

## Purpose

v10.3.2 is a clean-boot and administration compatibility release for the current Titan custom-extension installer.

The v10.3.1 provider could resolve `ApprovalSigner` during install-time policy registration before `INTERACTION_APPROVAL_SECRET` existed. Because the signer constructor rejected a missing/short secret, installation failed at the provider stage before Super Admin could reach the settings UI.

## Upgrade

1. Install the v10.3.2 ZIP through Titan Extension Manager.
2. Run normal extension migrations if the installer does not do so automatically.
3. Clear application caches after installation (`php artisan optimize:clear`) on the target host.
4. Open **Interaction Engine → Settings** in Super Admin.
5. Configure `INTERACTION_APPROVAL_SECRET` with a strong random value of at least 16 characters before enabling approval-required execution.
6. Configure `INTERACTION_OUTBOX_SECRET` with a strong random value before relying on encrypted offline queueing. Existing non-empty v10.3.1 values remain compatible; 16+ characters are recommended.
7. Reload long-running PHP/Laravel workers after environment/config changes.

## Clean-boot behavior

Missing security configuration no longer prevents the provider from registering:

- approval signing: provider boots, but approval issue/verify remains fail-closed;
- encrypted outbox: provider boots, but encrypted queue/decrypt remains unavailable;
- settings and health pages remain reachable so the administrator can diagnose configuration.

No fallback approval key or fake outbox key is generated.

## Super Admin navigation

The extension contributes:

- **Interaction Engine**
  - Overview
  - Settings

Preferred host integration uses `App\\Support\\Extensions\\ContributionRegistry` on `navigation.admin` and supports the common `register`, `contribute`, and `add` method shapes.

For older MagicAI hosts without that registry, the extension attempts an idempotent `menus`-table fallback only when the host schema is safely recognizable. It prefers the existing `settings` menu as parent. Navigation failure is non-fatal and cannot prevent extension boot.

Direct routes remain available:

- `GET /dashboard/admin/interaction-engine`
- `GET /dashboard/admin/interaction-engine/settings`
- `POST /dashboard/admin/interaction-engine/settings`
- `GET /dashboard/admin/interaction-engine/health`

## Data and tenancy

This release does not change the business tenant model. `company_id` remains the canonical company boundary. No CRM, Builder, Chatbot, Connect, Mobile, TitanAI, Pay or Gear business tables are copied or rewritten.
