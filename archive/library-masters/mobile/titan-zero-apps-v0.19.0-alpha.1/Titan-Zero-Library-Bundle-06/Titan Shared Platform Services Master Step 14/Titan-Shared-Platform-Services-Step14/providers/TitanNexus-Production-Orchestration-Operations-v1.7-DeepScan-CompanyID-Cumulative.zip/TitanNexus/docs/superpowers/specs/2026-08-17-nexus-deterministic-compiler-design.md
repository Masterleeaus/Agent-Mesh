# Titan Nexus Deterministic Compiler Design

## Goal

Advance Titan Nexus from a domain-only foundation to a real deterministic compiler that consumes the exact versioned vertical definition selected by the BusinessProfile and returns a CompiledTitanConfig without mutating authoritative state.

## Compiler Boundary

`DeterministicNexusCompiler` is framework-independent. It accepts only a validated `BusinessProfile`, a validated `VerticalDefinition`, and an explicit configuration version. It rejects any vertical ID or vertical version mismatch before producing output.

The compiler does not resolve extensions, write databases, dispatch commands, emit Signals, query knowledge, or provision capabilities. Those operations remain outside the pure compiler boundary.

## Vertical Engine Boundary

Titan Vertical Engine remains the source of vertical truth. Nexus owns `VerticalDefinitionSourceContract` plus `VerticalEngineAdapter`; the adapter receives a callable that must return a public definition array.

Laravel wiring is configuration-driven through `titan-nexus.vertical_engine.public_contract` and `resolve_method`. The package intentionally ships with no guessed upstream class. If the public contract is absent, unbound, non-callable, malformed, or returns a different vertical ID/version, Nexus fails closed.

## Merge Semantics

Vertical definition sections are defaults. Business profile sections are tenant-specific overrides.

- associative maps merge recursively;
- scalar overrides replace defaults;
- list arrays replace atomically rather than concatenate;
- empty business section maps preserve vertical defaults;
- source objects are immutable and are never modified during compilation.

These rules avoid implicit list duplication and make output reproducible.

## Provenance

New compiled outputs retain:

- source BusinessProfile SHA-256 fingerprint;
- source VerticalDefinition SHA-256 fingerprint;
- compiler version;
- vertical ID and version;
- knowledge snapshot version carried by the vertical definition;
- deterministic compiled output SHA-256.

`source_vertical_hash` is optional when reading older v0.2.0 compiled snapshots so prior output hashes remain valid. New v0.3.0 compiler output always includes it.

## Orchestration

`NexusManager::compileDraft()` accepts only a draft created for the active compiler version. It resolves the vertical definition exactly once, invokes the pure compiler, and returns a new immutable compiled aggregate. It does not save or provision the result automatically.

## Persistence

A forward migration adds `vertical_definition_hash` to the Nexus-owned compilation table for queryable provenance. Existing migration files remain unchanged.

## Scope Exclusions

Pass 2 does not implement semantic validation, preview UX, diff/recompile execution, Signal emission, Risk evaluation, Knowledge Authority queries, Command Bus execution, provisioning, or cross-engine authoritative writes.

## Testing

Standalone checks verify deterministic hashes, recursive merge behavior, atomic list replacement, empty-map behavior, vertical mismatch rejection, malformed adapter rejection, manager immutability, and package boundaries. PHPUnit-compatible tests mirror the compiler behaviors for execution inside the host application test environment.
