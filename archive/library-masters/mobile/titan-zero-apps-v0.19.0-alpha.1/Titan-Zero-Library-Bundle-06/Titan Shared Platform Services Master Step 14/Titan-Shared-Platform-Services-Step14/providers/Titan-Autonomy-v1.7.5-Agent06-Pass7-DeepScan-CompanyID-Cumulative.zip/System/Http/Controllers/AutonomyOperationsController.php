<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Http\Controllers;

use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Services\{AutonomyOperationsService,OperationsRecheckService,OperationsReviewService};
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\View\View as ViewContract;
use Throwable;

final class AutonomyOperationsController extends Controller
{
    public function __construct(
        private readonly HostContextBridgeContract $host,
        private readonly AutonomyOperationsService $operations,
        private readonly OperationsRecheckService $recheck,
        private readonly OperationsReviewService $reviews,
    ) {}

    public function index(Request $request): ViewContract
    {
        $this->authorise('titan.autonomy.view');
        $validated=$request->validate([
            'status'=>['sometimes','string','max:64'],
            'capability'=>['sometimes','string','max:120'],
        ]);
        $filters=[
            'status'=>(string)($validated['status']??'attention'),
            'capability'=>(string)($validated['capability']??''),
        ];
        return view('titan-autonomy::autonomy.operations.index',[
            'layout'=>$this->layout(),
            'queue'=>$this->operations->queue($this->host->tenantCompanyId(),$filters),
        ]);
    }

    public function show(string $correlationId): ViewContract
    {
        $this->authorise('titan.autonomy.view');
        return view('titan-autonomy::autonomy.operations.show',[
            'layout'=>$this->layout(),
            'detail'=>$this->operations->detail($this->host->tenantCompanyId(),$correlationId),
        ]);
    }

    public function recheck(string $correlationId): RedirectResponse
    {
        $this->authorise('titan.autonomy.manage');
        try {
            $result=$this->recheck->recheck($this->host->tenantCompanyId(),$this->host->userId(),$correlationId);
            return back()->with('titan_autonomy_status','Execution rechecked through canonical reconciliation: '.($result['final_label']??$result['status']??'complete').'.');
        } catch (Throwable $e) {
            return back()->with('titan_autonomy_error',$e->getMessage());
        }
    }

    public function review(Request $request,string $correlationId): RedirectResponse
    {
        $this->authorise('titan.autonomy.manage');
        $validated=$request->validate([
            'review_status'=>['required','string','in:acknowledged,needs_follow_up,reviewed_no_change'],
            'note'=>['nullable','string','max:2000'],
        ]);
        try {
            $this->reviews->record($this->host->tenantCompanyId(),$this->host->userId(),$correlationId,(string)$validated['review_status'],$validated['note']??null);
            return back()->with('titan_autonomy_status','Operational review recorded. Trust evidence was not changed.');
        } catch (Throwable $e) {
            return back()->with('titan_autonomy_error',$e->getMessage());
        }
    }

    private function authorise(string $permission): void { abort_unless($this->host->can($permission),403); }
    private function layout(): string
    {
        $configured=(string)config('titan-autonomy.view_layout','panel.layout.app');
        return View::exists($configured)?$configured:'titan-autonomy::autonomy.layout';
    }
}
