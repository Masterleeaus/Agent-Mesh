<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Events;

use App\Extensions\TitanConnect\System\Models\ExternalMessage;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

final class InboundMessageReceived
{
    use Dispatchable;
    use SerializesModels;

    public function __construct(
        public readonly ExternalThread $thread,
        public readonly ExternalMessage $message,
    ) {
    }
}
