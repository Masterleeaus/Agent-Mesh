<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$passes = [];
$check = static function (bool $condition, string $label) use (&$failures, &$passes): void {
    if ($condition) { $passes[] = $label; } else { $failures[] = $label; }
};
$read = static fn (string $path): string => is_file($root.'/'.$path) ? (string) file_get_contents($root.'/'.$path) : '';

$navigation = $read('System/Navigation/TitanConnectNavigation.php');
$registrar = $read('System/Navigation/HostNavigationRegistrar.php');
$web = $read('routes/web.php');
$api = $read('routes/api.php');
$badge = $read('System/Services/InboxBadgeService.php');
$header = $read('resources/views/header/inbox-notification.blade.php');
$providerView = $read('resources/views/channels/show.blade.php');

$check($navigation !== '', 'navigation definition service exists');
$check(str_contains($navigation, 'ext_titan_connect_channels'), 'Channels parent menu is defined');
$check(str_contains($navigation, 'ext_titan_connect_inbox'), 'Inbox parent menu is defined');
foreach (['whatsapp','messenger','instagram','telegram','sms','voice','push'] as $provider) {
    $check(str_contains($navigation, 'titan_connect_channel_'.$provider), 'channel menu child exists: '.$provider);
}
foreach (['unified','team','external','mine','unassigned','needs_human','closed'] as $mode) {
    $check(str_contains($navigation, 'titan_connect_inbox_'.$mode), 'inbox menu child exists: '.$mode);
}
$check(str_contains($registrar, 'App\\Support\\Extensions\\MenuContributionRegistry'), 'Blueprint-v3 user menu registry integration exists');
$check(str_contains($registrar, 'App\\Support\\Extensions\\ContributionRegistry'), 'Blueprint-v3 contribution registry integration exists');
$check(str_contains($registrar, 'navigation.admin'), 'Super Admin navigation contribution is registered');
$check(str_contains($web, "channels/{provider}") || str_contains($web, "channels/{channel}"), 'provider-specific channel settings route exists');
$check(str_contains($web, "inbox/{mode}"), 'named inbox mode route exists');
$check(str_contains($api, 'navigation/badges'), 'navigation badge API exists');
$check(str_contains($badge, 'companyId') && str_contains($badge, 'actorId'), 'badge service is company and actor scoped');
$check(str_contains($badge, 'needs_human'), 'badge service reports human handoff count');
$check(str_contains($header, 'navigation.badges') || str_contains($header, 'navigation-badges'), 'official-style header inbox badge surface exists');
$check(str_contains($providerView, 'provider') && str_contains($providerView, 'diagnostic'), 'channel-specific settings view exposes provider diagnostics');
$check(!str_contains($navigation.$registrar.$badge, 'tenant_id'), 'new navigation runtime does not use tenant_id');

foreach ($passes as $label) echo "PASS: {$label}\n";
foreach ($failures as $label) echo "FAIL: {$label}\n";
printf("navigation-menu contract suite: %d passed, %d failed\n", count($passes), count($failures));
exit($failures === [] ? 0 : 1);
