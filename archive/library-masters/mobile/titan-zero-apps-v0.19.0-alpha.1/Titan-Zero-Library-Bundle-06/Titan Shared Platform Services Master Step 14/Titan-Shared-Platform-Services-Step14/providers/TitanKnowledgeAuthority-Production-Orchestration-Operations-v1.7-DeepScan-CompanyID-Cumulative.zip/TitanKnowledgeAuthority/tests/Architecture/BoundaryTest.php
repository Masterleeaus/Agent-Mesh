<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

final class BoundaryTest extends TestCase
{
    public function test_system_code_does_not_import_other_extension_internals_or_mutate_database_directly(): void
    {
        $system = dirname(__DIR__, 2) . '/System';
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($system));
        $violations = [];

        foreach ($iterator as $file) {
            if (! $file->isFile() || $file->getExtension() !== 'php') {
                continue;
            }

            $source = (string) file_get_contents($file->getPathname());
            if (preg_match('/use\\s+App\\\\Extensions\\\\(?!TitanKnowledgeAuthority\\\\)/', $source) === 1) {
                $violations[] = $file->getFilename() . ': imports another extension internal namespace';
            }
            if (str_contains($source, 'DB::' . 'table(') || str_contains($source, 'DB::' . 'statement(')) {
                $violations[] = $file->getFilename() . ': performs direct database mutation/query through DB facade';
            }
        }

        self::assertSame([], $violations, implode("\n", $violations));
    }
}
