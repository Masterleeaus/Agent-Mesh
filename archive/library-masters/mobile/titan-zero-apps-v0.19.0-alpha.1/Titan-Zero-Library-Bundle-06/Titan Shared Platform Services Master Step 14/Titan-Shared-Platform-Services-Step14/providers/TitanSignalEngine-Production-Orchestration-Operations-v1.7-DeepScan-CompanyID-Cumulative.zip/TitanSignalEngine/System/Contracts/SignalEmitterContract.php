<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalReceipt;

interface SignalEmitterContract
{
    /** @param SignalEnvelope|array<string, mixed> $signal */
    public function emit(SignalEnvelope|array $signal, SignalContext $context): SignalReceipt;
}
