<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Voice;

use App\Extensions\TitanConnect\System\Contracts\CredentialVault;
use App\Extensions\TitanConnect\System\Contracts\VoiceSessionGateway;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ExternalMessage;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamMessage;
use App\Extensions\TitanConnect\System\Models\VoiceCall;
use App\Extensions\TitanConnect\System\Models\VoiceTranscript;
use App\Extensions\TitanConnect\System\Services\MessagingAuditService;
use Illuminate\Support\Str;
use RuntimeException;

final class VoiceSessionManager
{
    public function __construct(private readonly CredentialVault $vault, private readonly VoiceSessionGateway $gateway, private readonly MessagingAuditService $audit) {}

    /** @return array{call:VoiceCall,session:array<string,mixed>} */
    public function start(int $companyId, int $actorId, ChannelConnection $connection, ?ExternalThread $thread = null, ?TeamConversation $conversation = null, string $direction = 'outbound'): array
    {
        if ((int) $connection->company_id !== $companyId || $connection->provider !== 'voice') throw new RuntimeException('Voice connection company/provider mismatch.');
        if ($thread && ((int)$thread->company_id !== $companyId)) throw new RuntimeException('Voice external thread company mismatch.');
        if ($conversation && ((int)$conversation->company_id !== $companyId)) throw new RuntimeException('Voice conversation company mismatch.');
        $active = VoiceCall::query()->forCompany($companyId)->where('channel_connection_id', $connection->id)->where('actor_id', $actorId)->whereIn('status', ['starting', 'active']);
        if ($thread) $active->where('external_thread_id', $thread->id);
        elseif ($conversation) $active->where('conversation_id', $conversation->id);
        else $active->whereNull('external_thread_id')->whereNull('conversation_id');
        if ($active->exists()) throw new RuntimeException('An active voice call already exists for this context.');
        $call = VoiceCall::query()->create(['uuid'=>(string)Str::uuid(),'company_id'=>$companyId,'channel_connection_id'=>$connection->id,'external_thread_id'=>$thread?->id,'conversation_id'=>$conversation?->id,'actor_id'=>$actorId,'provider'=>'starting','direction'=>$direction,'status'=>'starting','started_at'=>now(),'metadata'=>[]]);
        try {
            $session = $this->gateway->start($call, $connection, $this->vault->credentials($companyId,$connection));
            $call->forceFill(['provider'=>(string)($session['provider'] ?? 'voice'),'status'=>'active','external_session_id'=>isset($session['session_id'])?(string)$session['session_id']:null])->save();
            $this->audit->record($companyId,$actorId,'voice-call.started','voice-call',$call->uuid,null,['provider'=>$call->provider,'external_thread_uuid'=>$thread?->uuid,'conversation_uuid'=>$conversation?->uuid]);
            $this->recordTimelineEvent($companyId, $actorId, $call, 'voice_call_started', 'Voice call started');
            return ['call'=>$call->fresh(),'session'=>$session];
        } catch (\Throwable $e) {
            $call->forceFill(['status'=>'failed','ended_at'=>now(),'metadata'=>['error'=>'session-start-failed']])->save(); throw $e;
        }
    }

    /** @return array<string,mixed> */
    public function clientSession(int $companyId, VoiceCall $call): array
    {
        $this->assertCall($companyId, $call);
        if (! in_array((string) $call->status, ['starting', 'active'], true)) {
            throw new RuntimeException('Voice call is not active.');
        }
        $connection = $call->connection;
        if (! $connection || (int) $connection->company_id !== $companyId || $connection->provider !== 'voice') {
            throw new RuntimeException('Voice connection is unavailable for this company.');
        }
        return $this->gateway->start($call, $connection, $this->vault->credentials($companyId, $connection));
    }

    public function transcript(int $companyId, int $actorId, VoiceCall $call, string $role, string $message, ?string $clientEventId = null): VoiceTranscript
    {
        $this->assertCall($companyId, $call);
        if ((string) $call->status !== 'active') throw new RuntimeException('Voice call is not active.');
        $role = strtolower(trim($role));
        if (! in_array($role, ['user', 'assistant', 'human_agent', 'system'], true)) throw new RuntimeException('Invalid voice transcript role.');
        $message = trim($message);
        if ($message === '') throw new RuntimeException('Voice transcript message is required.');
        $clientEventId = $clientEventId === null ? null : trim($clientEventId);
        if ($clientEventId === '') $clientEventId = null;
        if ($clientEventId !== null && strlen($clientEventId) > 191) throw new RuntimeException('Voice transcript event ID is too long.');

        $values = ['uuid' => (string) Str::uuid(), 'role' => $role, 'message' => $message, 'spoken_at' => now(), 'metadata' => ['actor_id' => $actorId]];
        if ($clientEventId !== null) {
            return VoiceTranscript::query()->firstOrCreate([
                'company_id' => $companyId,
                'voice_call_id' => $call->id,
                'client_event_id' => $clientEventId,
            ], $values);
        }
        return VoiceTranscript::query()->create(['company_id' => $companyId, 'voice_call_id' => $call->id, 'client_event_id' => null] + $values);
    }

    public function end(int $companyId, int $actorId, VoiceCall $call): VoiceCall
    {
        $this->assertCall($companyId,$call);
        if ((string) $call->status === 'ended') return $call->fresh('transcripts');
        $ended=now(); $started=$call->started_at ?? $call->created_at; $duration=$started ? max(0,$started->diffInSeconds($ended)) : 0;
        $call->forceFill(['status'=>'ended','ended_at'=>$ended,'duration_seconds'=>$duration])->save();
        $this->recordTimelineEvent($companyId, $actorId, $call, 'voice_call_ended', 'Voice call ended');
        $this->audit->record($companyId,$actorId,'voice-call.ended','voice-call',$call->uuid,null,['duration_seconds'=>$duration]); return $call->fresh('transcripts');
    }

    private function recordTimelineEvent(int $companyId, int $actorId, VoiceCall $call, string $type, string $body): void
    {
        if ($call->external_thread_id) {
            ExternalMessage::query()->create([
                'uuid' => (string) Str::uuid(),
                'company_id' => $companyId,
                'external_thread_id' => $call->external_thread_id,
                'provider' => 'voice',
                'direction' => 'internal',
                'sender_ref' => 'user:'.$actorId,
                'body' => $body,
                'message_type' => $type,
                'status' => 'stored',
                'metadata' => ['voice_call_uuid' => $call->uuid, 'voice_provider' => $call->provider],
            ]);
            ExternalThread::query()->forCompany($companyId)->whereKey($call->external_thread_id)->update(['last_message_at' => now()]);
        }
        if ($call->conversation_id) {
            TeamMessage::query()->create([
                'uuid' => (string) Str::uuid(),
                'company_id' => $companyId,
                'conversation_id' => $call->conversation_id,
                'user_id' => null,
                'body' => $body,
                'message_type' => $type,
                'created_by' => $actorId,
                'metadata' => ['voice_call_uuid' => $call->uuid, 'voice_provider' => $call->provider],
            ]);
        }
    }

    private function assertCall(int $companyId, VoiceCall $call): void { if ((int)$call->company_id !== $companyId) throw new RuntimeException('Voice call company mismatch.'); }
}
