<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;

interface SignalDeliverySchedulerContract
{
    public function projectForEvent(SignalEvent $event): int;
    public function enqueue(string $deliveryId, int $delaySeconds = 0): void;
    public function recoverDue(int $limit = 100): int;
}
