<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\Services\CrmNotificationDeliveryService;
use Illuminate\Console\Command;

final class DeliverCrmOutboundEffectsCommand extends Command
{
    protected $signature='crm:outbound-effects:deliver {--user=} {--limit=25}';
    protected $description='Deliver due CRM outbound effects after authoritative transactions have committed.';

    public function handle(CrmNotificationDeliveryService $delivery):int
    {
        $user=(int)($this->option('user')??0);
        if($user<1){
            $this->error('Provide --user=<accountable user id> so CRM can resolve company_id safely.');
            return self::FAILURE;
        }
        $result=$delivery->deliverPending($user,(int)$this->option('limit'));
        $this->info(sprintf(
            'CRM outbound effects processed: %d; delivered: %d; deferred: %d; failed: %d.',
            $result['processed'],$result['delivered'],$result['deferred'],$result['failed']
        ));
        return self::SUCCESS;
    }
}
