<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Middleware;

use App\Extensions\Crm\System\Security\CrmPermissionService;
use Closure;
use Illuminate\Http\Request;

final class EnsureCrmPermission
{
    public function __construct(private CrmPermissionService $permissions) {}
    public function handle(Request $request, Closure $next, string $permission)
    {
        $this->permissions->authorize((int)$request->user()->id, $permission);
        return $next($request);
    }
}
