<?php

use App\Extensions\TitanSignalEngine\System\Http\Controllers\AdminController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', AdminController::class)->name('index');
$router->get('/overview', [AdminController::class, 'overview'])->name('overview');
$router->get('/pulse-health', [AdminController::class, 'pulseHealth'])->name('pulse-health');
$router->get('/events-traces', [AdminController::class, 'eventsTraces'])->name('events-traces');
$router->get('/anomalies', [AdminController::class, 'anomalies'])->name('anomalies');
$router->get('/deliveries-dlq', [AdminController::class, 'deliveriesDlq'])->name('deliveries-dlq');
$router->get('/lifecycle-archives', [AdminController::class, 'lifecycleArchives'])->name('lifecycle-archives');
$router->get('/registries', [AdminController::class, 'registries'])->name('registries');
$router->get('/diagnostics', [AdminController::class, 'diagnostics'])->name('diagnostics');

$router->post('/anomalies/{anomalyId}/acknowledge', [AdminController::class, 'acknowledgeAnomaly'])->name('anomalies.acknowledge');
$router->post('/anomalies/{anomalyId}/resolve', [AdminController::class, 'resolveAnomaly'])->name('anomalies.resolve');
$router->post('/anomalies/{anomalyId}/suppress', [AdminController::class, 'suppressAnomaly'])->name('anomalies.suppress');
$router->post('/events/{eventId}/legal-hold', [AdminController::class, 'legalHold'])->name('events.legal-hold');
$router->post('/events/{eventId}/redact', [AdminController::class, 'redact'])->name('events.redact');
$router->post('/events/{eventId}/correct', [AdminController::class, 'correct'])->name('events.correct');
$router->post('/deliveries/{deliveryId}/redrive', [AdminController::class, 'redriveDelivery'])->name('deliveries.redrive');
$router->post('/lifecycle/prune', [AdminController::class, 'prune'])->name('lifecycle.prune');
