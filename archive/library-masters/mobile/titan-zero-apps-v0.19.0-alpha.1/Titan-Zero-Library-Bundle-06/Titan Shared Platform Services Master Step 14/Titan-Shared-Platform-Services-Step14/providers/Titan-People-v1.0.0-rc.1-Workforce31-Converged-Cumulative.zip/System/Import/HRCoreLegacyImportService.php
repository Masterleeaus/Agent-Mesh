<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Import;

use InvalidArgumentException;

/**
 * Explicit legacy import planner. It never infers tenant ownership and never
 * imports Time Attendance, Scheduling, Finance or Payroll-owned slices.
 */
final class HRCoreLegacyImportService
{
    private const ALLOWED = ['employees', 'departments', 'designations', 'teams', 'hierarchy', 'lifecycle'];
    private const EXCLUDED = ['attendance', 'attendance_breaks', 'attendance_logs', 'attendance_regularizations', 'shifts', 'expenses', 'expense_types', 'bank_accounts'];

    /** @param array<string,mixed> $source @param array<string,mixed> $mapping */
    public function import(array $source, array $mapping): HRCoreImportReport
    {
        $tenant = $mapping['tenant_company_id'] ?? null;
        $sourceName = $mapping['source'] ?? null;
        if ((! is_int($tenant) && ! (is_string($tenant) && ctype_digit($tenant))) || (int) $tenant <= 0 || ! is_string($sourceName) || trim($sourceName) === '') {
            throw new InvalidArgumentException('Explicit tenant_company_id and source mapping are required for HRCore import.');
        }

        $tenant = (int) $tenant;
        $counts = [];
        foreach (self::ALLOWED as $slice) {
            $rows = $source[$slice] ?? [];
            $counts[$slice] = is_array($rows) ? count($rows) : 0;
        }

        $excluded = [];
        foreach (self::EXCLUDED as $slice) {
            if (array_key_exists($slice, $source)) $excluded[] = $slice;
        }

        $fingerprint = hash('sha256', json_encode([
            'tenant_company_id' => $tenant,
            'source' => $sourceName,
            'allowed' => array_intersect_key($source, array_flip(self::ALLOWED)),
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));

        return new HRCoreImportReport(
            tenantCompanyId: $tenant,
            idempotencyKey: 'hrcore:'.$tenant.':'.$fingerprint,
            importedCounts: $counts,
            excludedSlices: $excluded,
            conflicts: [],
        );
    }
}
