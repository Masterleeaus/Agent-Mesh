# Titan Connect Host Certification Tests

These tests are intentionally opt-in because they exercise the installed extension against the host application's real Laravel bindings and a production-equivalent MySQL database.

Run from the Titan Zero / MagicAI application root:

```bash
TITAN_CONNECT_HOST_CERTIFICATION=1 php artisan test App/Extensions/TitanConnect/tests/Feature/HostCertification/CompanyBoundaryTest.php
```

If your extension installer places tests elsewhere, pass that installed path to `php artisan test`.

The suite verifies `users.company_id`, all canonical Titan Connect `company_id` columns, company-scoped Eloquent queries, immutable company ownership, authenticated route binding denial, queue payload company identity, and company-namespaced attachment storage.
