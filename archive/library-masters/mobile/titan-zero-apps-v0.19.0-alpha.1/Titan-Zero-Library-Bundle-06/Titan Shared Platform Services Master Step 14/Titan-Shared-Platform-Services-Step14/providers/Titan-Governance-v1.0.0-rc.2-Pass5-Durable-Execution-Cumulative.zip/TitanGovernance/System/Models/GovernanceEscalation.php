<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Models;

use Illuminate\Database\Eloquent\Model;

final class GovernanceEscalation extends Model
{
    protected $table='titan_governance_escalations';
    protected $guarded=[];
    protected $casts=[
        'risk_score'=>'float',
        'urgency'=>'integer',
        'reason_codes'=>'array',
        'evidence_refs'=>'array',
        'opened_at'=>'datetime',
        'resolved_at'=>'datetime',
        'version'=>'integer',
    ];
}
