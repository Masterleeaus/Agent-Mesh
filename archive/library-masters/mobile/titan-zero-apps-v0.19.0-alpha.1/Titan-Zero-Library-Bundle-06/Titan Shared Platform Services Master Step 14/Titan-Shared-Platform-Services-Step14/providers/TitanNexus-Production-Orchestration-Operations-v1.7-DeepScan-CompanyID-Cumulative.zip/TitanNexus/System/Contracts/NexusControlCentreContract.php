<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Contracts;

use App\Extensions\TitanNexus\System\Domain\ControlCentreSnapshot;

interface NexusControlCentreContract
{
    public function snapshot(int $tenantCompanyId, ?string $compilationUuid = null): ControlCentreSnapshot;
}
