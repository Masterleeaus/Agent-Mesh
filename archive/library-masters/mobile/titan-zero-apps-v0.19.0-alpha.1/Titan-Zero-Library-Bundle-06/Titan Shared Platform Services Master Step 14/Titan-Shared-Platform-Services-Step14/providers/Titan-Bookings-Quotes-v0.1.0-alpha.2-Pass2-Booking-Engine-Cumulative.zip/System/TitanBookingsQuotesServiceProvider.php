<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System;
use Illuminate\Support\ServiceProvider;
final class TitanBookingsQuotesServiceProvider extends ServiceProvider
{
    public function register():void{$this->mergeConfigFrom(__DIR__.'/../config/bookings-quotes.php','titan-bookings-quotes');}
    public function boot():void
    {
        $migrations=__DIR__.'/../database/migrations';if(is_dir($migrations))$this->loadMigrationsFrom($migrations);
        $views=__DIR__.'/../resources/views';if(is_dir($views))$this->loadViewsFrom($views,'titan-bookings-quotes');
    }
}
