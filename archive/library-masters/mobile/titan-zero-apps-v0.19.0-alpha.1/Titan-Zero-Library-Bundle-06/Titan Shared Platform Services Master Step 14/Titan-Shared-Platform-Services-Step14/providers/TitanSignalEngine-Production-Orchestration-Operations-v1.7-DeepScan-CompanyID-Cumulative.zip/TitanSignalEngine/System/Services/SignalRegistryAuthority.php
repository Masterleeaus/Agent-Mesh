<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalRegistryAuthorityContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryIdentity;
use InvalidArgumentException;
use JsonException;

final class SignalRegistryAuthority implements SignalRegistryAuthorityContract
{
    /** @param array<string,array<string,mixed>> $definitions */
    public function __construct(
        private readonly string $secret,
        private readonly array $definitions,
    ) {
        if (trim($this->secret) === '') {
            throw new InvalidArgumentException('Signal registry authority requires a non-empty attestation secret.');
        }
    }

    public function issue(string $serviceId): SignalRegistryIdentity
    {
        $definition = $this->definition($serviceId);
        $payload = [
            'service_id' => trim($serviceId),
            'owner_source' => trim((string) ($definition['owner_source'] ?? '')),
            'permissions' => self::stringList($definition['permissions'] ?? []),
            'event_type_patterns' => self::stringList($definition['event_type_patterns'] ?? []),
            'subscriber_key_patterns' => self::stringList($definition['subscriber_key_patterns'] ?? []),
        ];
        if ($payload['owner_source'] === '' || $payload['permissions'] === []) {
            throw new InvalidArgumentException("Trusted Signal registry actor {$serviceId} has an invalid definition.");
        }

        return new SignalRegistryIdentity(
            $payload['service_id'],
            $payload['owner_source'],
            $payload['permissions'],
            $payload['event_type_patterns'],
            $payload['subscriber_key_patterns'],
            $this->sign($payload),
        );
    }

    public function assertTrusted(SignalRegistryIdentity $identity): void
    {
        $expected = $this->issue($identity->serviceId);
        if ($identity->attestationPayload() !== $expected->attestationPayload()
            || ! hash_equals($expected->attestation, $identity->attestation)) {
            throw new InvalidArgumentException('Signal registry identity is not trusted by the host registry authority.');
        }
    }

    /** @return array<string,mixed> */
    private function definition(string $serviceId): array
    {
        $serviceId = trim($serviceId);
        if ($serviceId === '' || ! isset($this->definitions[$serviceId]) || ! is_array($this->definitions[$serviceId])) {
            throw new InvalidArgumentException("Signal registry service {$serviceId} is not registered as trusted.");
        }
        return $this->definitions[$serviceId];
    }

    /** @param array<string,mixed> $payload */
    private function sign(array $payload): string
    {
        try {
            $json = json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        } catch (JsonException $exception) {
            throw new InvalidArgumentException('Signal registry identity cannot be attested.', previous: $exception);
        }
        return hash_hmac('sha256', $json, $this->secret);
    }

    /** @return list<string> */
    private static function stringList(mixed $value): array
    {
        if (! is_array($value)) throw new InvalidArgumentException('Signal registry permissions/patterns must be arrays.');
        return array_values(array_filter(array_map(static fn (mixed $item): string => trim((string) $item), $value), static fn (string $item): bool => $item !== ''));
    }
}
