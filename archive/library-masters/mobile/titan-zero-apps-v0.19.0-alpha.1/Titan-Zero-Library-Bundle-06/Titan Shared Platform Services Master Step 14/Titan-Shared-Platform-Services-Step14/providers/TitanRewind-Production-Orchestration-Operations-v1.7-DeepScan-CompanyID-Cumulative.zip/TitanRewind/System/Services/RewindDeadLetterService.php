<?php

declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Services;
use App\Extensions\TitanRewind\System\Models\RewindDeadLetter;
use App\Extensions\TitanRewind\System\Runtime\RewindFailureClassifier;
use App\Extensions\TitanRewind\System\Jobs\RunReplaySimulationJob;
use App\Extensions\TitanRewind\System\Jobs\PublishRewindSignalJob;
use Illuminate\Support\Str;
use Throwable;
final class RewindDeadLetterService
{
    public function __construct(private RewindFailureClassifier $classifier) {}
    public function record(string $queue,string $jobType,?int $tenantCompanyId,?string $operationId,array $payload,Throwable $error,int $attempts): RewindDeadLetter
    {
        return RewindDeadLetter::query()->create(['dead_letter_uuid'=>(string)Str::uuid(),'tenant_company_id'=>$tenantCompanyId,'queue_name'=>$queue,'job_type'=>$jobType,'operation_id'=>$operationId,'status'=>'attention','classification'=>$this->classifier->classify($error),'attempts'=>$attempts,'payload'=>$payload,'error_class'=>$error::class,'error_message'=>substr($error->getMessage(),0,4000),'failed_at'=>now()]);
    }
    public function attentionCount(): int { return RewindDeadLetter::query()->where('status','attention')->count(); }
    public function markRetried(RewindDeadLetter $letter): RewindDeadLetter { $letter->forceFill(['status'=>'retried','retried_at'=>now()])->save(); return $letter->refresh(); }
    public function retry(string $deadLetterUuid): RewindDeadLetter
    {
        $letter=RewindDeadLetter::query()->where('dead_letter_uuid',$deadLetterUuid)->firstOrFail();
        if ($letter->status!=='attention') return $letter;
        $payload=is_array($letter->payload)?$letter->payload:[];
        if ($letter->job_type===RunReplaySimulationJob::class && isset($payload['replay_run_id'],$letter->tenant_company_id)) {
            RunReplaySimulationJob::dispatch((int)$payload['replay_run_id'],(int)$letter->tenant_company_id)->onQueue($letter->queue_name);
        } elseif ($letter->job_type===PublishRewindSignalJob::class && isset($payload['outbox_id'],$letter->tenant_company_id)) {
            PublishRewindSignalJob::dispatch((int)$payload['outbox_id'],(int)$letter->tenant_company_id)->onQueue($letter->queue_name);
        } else {
            throw new \LogicException('This Titan Rewind dead letter cannot be retried automatically.');
        }
        return $this->markRetried($letter);
    }
    public function resolve(RewindDeadLetter $letter): RewindDeadLetter { $letter->forceFill(['status'=>'resolved','resolved_at'=>now()])->save(); return $letter->refresh(); }
}
