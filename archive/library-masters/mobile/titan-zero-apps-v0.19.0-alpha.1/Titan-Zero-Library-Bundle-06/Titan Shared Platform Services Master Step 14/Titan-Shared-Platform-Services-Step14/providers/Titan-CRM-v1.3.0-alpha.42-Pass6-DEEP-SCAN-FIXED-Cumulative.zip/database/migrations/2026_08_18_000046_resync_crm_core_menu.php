<?php

declare(strict_types=1);

use App\Extensions\Crm\System\Navigation\CrmMenuInstaller;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key')) {
            return;
        }

        // Earlier menu migrations may already be recorded on long-lived hosts.
        // Force the current canonical CRM navigation definition to be applied
        // during this upgrade so stale extracted-domain links are retired.
        CrmMenuInstaller::sync();
    }

    public function down(): void
    {
        // Keep the canonical menu definition safe even if this migration is
        // rolled back as part of an installer recovery. Re-enabling stale CRM
        // links would point at domains CRM Core no longer owns.
        if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key')) {
            return;
        }

        CrmMenuInstaller::sync();
    }
};
