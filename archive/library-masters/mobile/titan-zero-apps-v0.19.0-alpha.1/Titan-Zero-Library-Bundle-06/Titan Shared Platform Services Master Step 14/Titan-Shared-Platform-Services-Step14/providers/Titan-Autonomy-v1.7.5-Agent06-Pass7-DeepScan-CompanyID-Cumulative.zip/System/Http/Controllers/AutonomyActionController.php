<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Http\Controllers;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\HandshakeDecision;
use App\Extensions\TitanAutonomy\System\Services\AutonomyGrantService;
use App\Extensions\TitanAutonomy\System\Services\AssuranceAssessmentRequestService;
use App\Extensions\TitanAutonomy\System\Services\GateReviewService;
use App\Extensions\TitanAutonomy\System\Services\LearningExportService;
use App\Extensions\TitanAutonomy\System\Services\LearningResetService;
use App\Extensions\TitanAutonomy\System\Services\LearningSettingsService;
use App\Extensions\TitanAutonomy\System\Services\ManualRegressionService;
use App\Extensions\TitanAutonomy\System\Services\TrustedAutoReviewService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class AutonomyActionController
{
    public function __construct(
        private readonly HostContextBridgeContract $context,
        private readonly AutonomyQueryContract $query,
        private readonly GateReviewService $gateReview,
        private readonly AutonomyGrantService $grantService,
        private readonly TrustedAutoReviewService $trustedAuto,
        private readonly AssuranceAssessmentRequestService $assuranceRequest,
        private readonly LearningSettingsService $learningSettings,
        private readonly LearningResetService $learningReset,
        private readonly ManualRegressionService $manualRegression,
        private readonly LearningExportService $exporter,
    ) {}

    public function requestAssurance(Request $request, string $capability): RedirectResponse
    {
        $this->authorise('titan.autonomy.manage');
        $tenantCompanyId = $this->context->tenantCompanyId();
        $workflowKey = trim((string) $request->input('workflow_key', ''));
        $review = $this->gateReview->review($tenantCompanyId, $capability, $workflowKey);
        $state = $review['state'];
        abort_unless($state->currentLevel === AutonomyLevel::Auto && $state->currentLevel->next() === AutonomyLevel::TrustedAuto, 422, 'Assurance assessment is only requested for the Trusted Auto gate.');
        abort_unless($review['gate']->eligible, 422, 'Platform gate requirements must pass before requesting the Trusted Auto assurance assessment.');

        $scope = $this->scope($request->input('scope', $state->scope));
        abort_if($scope === [], 422, 'Trusted Auto requires an explicit bounded scope.');
        $result = $this->assuranceRequest->request(
            $capability,
            $workflowKey,
            [
                'scope' => $scope,
                'current_success_streak' => $state->currentSuccessStreak,
                'required_success_streak' => $review['gate']->requiredSuccessStreak,
                'highest_success_streak' => $state->highestSuccessStreak,
                'total_successes' => $state->totalSuccesses,
                'total_failures' => $state->totalFailures,
                'total_edits' => $state->totalEdits,
                'total_rejections' => $state->totalRejections,
                'total_reversals' => $state->totalReversals,
            ],
            $state->risk->value,
            $request->header('X-Correlation-ID'),
        );
        return back()->with('titan_autonomy_status', 'Assurance assessment requested: ' . ($result['evaluation_ref'] ?? 'pending') . '. Trusted Auto remains inactive until the assessment passes.');
    }

    public function grantNext(Request $request, string $capability): RedirectResponse
    {
        $this->authorise('titan.autonomy.manage');
        $tenantCompanyId = $this->context->tenantCompanyId();
        $workflowKey = trim((string) $request->input('workflow_key', ''));
        $scope = $this->scope($request->input('scope', []));
        $review = $this->gateReview->review($tenantCompanyId, $capability, $workflowKey);
        $state = $review['state'];
        $next = $state->currentLevel->next();
        abort_if($next === null, 422, 'No higher autonomy level is available.');

        if ($next === AutonomyLevel::TrustedAuto) {
            $result = $this->trustedAuto->reviewAndGrant(
                $tenantCompanyId,
                $capability,
                $workflowKey,
                $this->context->userId(),
                $this->context->can('titan.autonomy.manage'),
                HandshakeDecision::Approved,
                $scope,
                $request->header('X-Correlation-ID'),
            );
        } else {
            $result = $this->grantService->grantNextLevel(
                state: $state,
                requestedLevel: $next,
                gate: $review['gate'],
                actorUserId: $this->context->userId(),
                actorCanGrant: $this->context->can('titan.autonomy.manage'),
                userDecision: HandshakeDecision::Approved,
                aiAssuranceDecision: HandshakeDecision::Pending,
                aiConfidence: 0.0,
                platformReasonCodes: $review['gate']->reasonCodes,
                aiReasonCodes: [],
                assuranceEvaluationRef: null,
                scope: $scope,
                correlationId: $request->header('X-Correlation-ID'),
            );
        }

        if (!$result->approved) {
            return back()->with('titan_autonomy_error', implode(', ', $result->reasonCodes));
        }
        return back()->with('titan_autonomy_status', 'Autonomy level updated to ' . $result->state->currentLevel->key() . '.');
    }

    public function lower(Request $request, string $capability): RedirectResponse
    {
        $this->authorise('titan.autonomy.manage');
        $tenantCompanyId = $this->context->tenantCompanyId();
        $workflowKey = trim((string) $request->input('workflow_key', ''));
        $targetLevel = trim((string) $request->input('target_level', 'suggest'));
        $state = $this->query->capabilityState($tenantCompanyId, $capability, $workflowKey);
        abort_if($state === null, 404);

        $ok = $this->manualRegression->lower(
            $tenantCompanyId,
            $capability,
            $workflowKey,
            (string) $state['current_level'],
            $targetLevel,
            'user_requested',
            $this->context->userId(),
            $request->header('X-Correlation-ID'),
        );
        abort_unless($ok, 422, 'Autonomy may only be lowered through this action.');
        return back()->with('titan_autonomy_status', 'Autonomy lowered to ' . $targetLevel . '.');
    }

    public function resetLearning(Request $request, string $capability): RedirectResponse
    {
        $this->authorise('titan.learning.manage');
        abort_unless($request->boolean('confirmed'), 422, 'Explicit reset confirmation is required.');
        $tenantCompanyId = $this->context->tenantCompanyId();
        $workflowKey = trim((string) $request->input('workflow_key', ''));
        $targetLevel = trim((string) $request->input('target_level', 'suggest'));
        $this->learningReset->resetCapability($tenantCompanyId, $capability, $workflowKey, $targetLevel, $this->context->userId(), $request->header('X-Correlation-ID'));
        return back()->with('titan_autonomy_status', 'Capability learning evidence reset and authority recalculated conservatively.');
    }

    public function updateLearningSettings(Request $request): RedirectResponse
    {
        $this->authorise('titan.learning.manage');
        $tenantCompanyId = $this->context->tenantCompanyId();
        $platformPolicy = $this->query->platformPolicy() ?? [
            'system_wide_learning_permitted' => (bool) config('titan-autonomy.learning.system_wide_permitted', false),
        ];
        $this->learningSettings->save($tenantCompanyId, [
            'user' => $request->boolean('user_learning'),
            'business' => $request->boolean('business_learning'),
            'system' => $request->boolean('system_wide_learning'),
            'learning_event_retention_days' => $request->input('learning_event_retention_days'),
            'autonomy_evidence_retention_days' => $request->input('autonomy_evidence_retention_days'),
        ], $platformPolicy, $this->context->userId(), $request->header('X-Correlation-ID'));
        return back()->with('titan_autonomy_status', 'Learning settings updated.');
    }

    public function clearPreferences(Request $request): RedirectResponse
    {
        $this->authorise('titan.learning.manage');
        abort_unless($request->boolean('confirmed'), 422, 'Explicit clear confirmation is required.');
        $this->learningReset->clearPreferences($this->context->tenantCompanyId(), $this->context->userId(), $this->context->userId(), $request->header('X-Correlation-ID'));
        return back()->with('titan_autonomy_status', 'Your learned preferences were cleared.');
    }

    public function export(): JsonResponse
    {
        $this->authorise('titan.learning.view');
        $tenantCompanyId = $this->context->tenantCompanyId();
        return response()->json($this->exporter->exportTenant($tenantCompanyId), Response::HTTP_OK, [
            'Content-Disposition' => 'attachment; filename="titan-learning-' . $tenantCompanyId . '.json"',
        ]);
    }

    private function scope(mixed $value): array
    {
        if (is_array($value)) return $value;
        if (!is_string($value) || trim($value) === '') return [];
        $decoded = json_decode($value, true);
        return is_array($decoded) ? $decoded : [];
    }

    private function authorise(string $permission): void
    {
        abort_unless($this->context->can($permission), 403);
    }
}
