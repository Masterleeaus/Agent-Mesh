<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Forensics;

final class RewindDriftRules
{
    public function evaluate(array $integrity, array $temporal, array $causation, array $events): array
    {
        $findings = [];
        if (($integrity['status'] ?? null) === 'failed' || (int) ($integrity['failures_count'] ?? 0) > 0) {
            $findings[] = $this->finding('integrity_failure','critical','Stored Rewind event integrity verification failed.', [
                'failures_count'=>(int) ($integrity['failures_count'] ?? 0),
            ], 'Quarantine the affected trace from evidentiary export and inspect the reported event IDs before relying on it.');
        }
        if ((int) ($integrity['unsealed_count'] ?? 0) > 0) {
            $findings[] = $this->finding('integrity_unsealed','medium','Legacy Rewind events are not fully sealed into the ingestion chain.', [
                'unsealed_count'=>(int) $integrity['unsealed_count'],
            ], 'Seal or re-ingest legacy events before treating the trace as cryptographically chained.');
        }
        if ((int) ($temporal['late_event_count'] ?? 0) > 0 || (int) ($temporal['out_of_order_arrival_count'] ?? 0) > 0) {
            $findings[] = $this->finding('late_event_arrival','medium','Events arrived materially late or outside deterministic chronological order.', [
                'late_event_count'=>(int) ($temporal['late_event_count'] ?? 0),
                'out_of_order_arrival_count'=>(int) ($temporal['out_of_order_arrival_count'] ?? 0),
                'max_recording_lag_ms'=>(int) ($temporal['max_recording_lag_ms'] ?? 0),
            ], 'Inspect source adapter latency and retain deterministic event ordering instead of rewriting occurrence timestamps.');
        }
        if ((int) ($temporal['sequence_collision_count'] ?? 0) > 0) {
            $findings[] = $this->finding('sequence_collision','high','Multiple events share the same source sequence position.', [
                'sequence_collision_count'=>(int) $temporal['sequence_collision_count'],
            ], 'Verify source sequencing semantics; Rewind will continue to break ties deterministically by occurred_at and event_id.');
        }
        if ((int) ($temporal['recorded_before_occurred_count'] ?? 0) > 0) {
            $findings[] = $this->finding('clock_order_anomaly','medium','One or more events were recorded before their declared occurrence time.', [
                'recorded_before_occurred_count'=>(int) $temporal['recorded_before_occurred_count'],
            ], 'Check producer clock synchronization and timestamp provenance.');
        }
        if (count($causation['orphans'] ?? []) > 0) {
            $findings[] = $this->finding('causation_orphan','high','Trace events reference causation parents that are not present in the trace.', [
                'orphans'=>$causation['orphans'],
            ], 'Retrieve the missing source events or confirm that the parent belongs to an intentionally external trace.');
        }

        $highRiskFailures = [];
        foreach ($events as $event) {
            $type = strtolower((string) ($event['event_type'] ?? ''));
            $risk = $this->riskLevel($event);
            if (in_array($risk, ['high','critical'], true) && preg_match('/fail|error|reject|deny|timeout/', $type)) {
                $highRiskFailures[] = ['event_id'=>$event['event_id'] ?? null,'event_type'=>$event['event_type'] ?? null,'risk_level'=>$risk];
            }
        }
        if ($highRiskFailures !== []) {
            $findings[] = $this->finding('high_risk_failure','high','High-risk or critical events failed, were rejected, denied or timed out.', [
                'events'=>$highRiskFailures,
            ], 'Open root-cause reconstruction and review Risk/Governance/Command Bus evidence before proposing recovery.');
        }

        return $findings;
    }

    private function finding(string $type, string $severity, string $summary, array $evidence, string $remediation): array
    {
        return ['finding_type'=>$type,'severity'=>$severity,'summary'=>$summary,'evidence'=>$evidence,'remediation'=>['recommendation'=>$remediation]];
    }

    private function riskLevel(array $event): string
    {
        $risk = is_array($event['risk_state'] ?? null) ? $event['risk_state'] : [];
        foreach (['level','risk_level','overall','severity'] as $key) {
            if (isset($risk[$key]) && is_scalar($risk[$key])) return strtolower(trim((string) $risk[$key]));
        }
        return 'unknown';
    }
}
