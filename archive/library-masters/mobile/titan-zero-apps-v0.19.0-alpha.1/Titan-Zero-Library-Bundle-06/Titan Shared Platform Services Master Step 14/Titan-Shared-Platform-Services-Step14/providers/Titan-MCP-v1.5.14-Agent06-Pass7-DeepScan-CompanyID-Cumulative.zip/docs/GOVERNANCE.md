# Governance

Titan MCP is governed locally by explicit capabilities, write/destructive kill switches, verified backup-before-write, exact restore, operation serialization, audit-chain integrity and fail-closed recovery rules. Optional Titan Command Bus/Risk/Shield/Signal/Rewind integrations may observe or further constrain work but are not required to grant baseline authority.

## Two-phase approval governance (v1.4+, strengthened in v1.5)
Approval-centric clients should use `titan_mutation_prepare` before showing the final human confirmation. Titan validates current mutation preconditions and creates verified recovery evidence while holding the host mutation lock. The returned ticket is actor-bound, argument-hash-bound, expiring and single-use. `titan_mutation_commit` accepts no replacement arguments and atomically consumes the ticket before invoking the canonical stored tool call. Direct mutation tools remain governed and supported for clients that provide approval before the direct call.
