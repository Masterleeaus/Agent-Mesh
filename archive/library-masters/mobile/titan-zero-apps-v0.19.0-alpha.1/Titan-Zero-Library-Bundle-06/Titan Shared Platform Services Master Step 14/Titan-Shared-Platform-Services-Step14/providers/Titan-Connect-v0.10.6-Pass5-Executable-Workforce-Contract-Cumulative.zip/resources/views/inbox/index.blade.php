@push('css')
<link rel="stylesheet" href="{{ asset('vendor/titan-connect/css/operator-inbox.css') }}">
@endpush

<div class="container-fluid py-6">
<section
    id="titan-connect-operator"
    class="tc-operator"
    data-index-url="{{ route('titan-connect.api.operator.index') }}"
    data-notification-url="{{ route('titan-connect.api.operator.notification') }}"
    data-tags-url="{{ route('titan-connect.api.tags.index') }}"
    data-canned-url="{{ route('titan-connect.api.canned.index') }}"
    data-rewrite-url="{{ route('titan-connect.api.reply.rewrite') }}"
    data-thread-base="{{ url('/api/titan-connect/operator/threads') }}"
    data-send-base="{{ url('/api/titan-connect/connections') }}"
    data-read-base="{{ url('/api/titan-connect/external-threads') }}"
    data-connections-url="{{ route('titan-connect.api.connections.store') }}"
    data-connections-list-url="{{ route('titan-connect.api.connections.index') }}"
    data-diagnostics-url="{{ route('titan-connect.api.diagnostics.index') }}"
    data-diagnostics-base="{{ url('/api/titan-connect/diagnostics') }}"
    data-settings-url="{{ route('dashboard.user.titan-connect.settings.index') }}"
    data-voice-show-base="{{ url('/dashboard/user/titan-connect/voice') }}"
    data-telegram-onboarding-url="{{ route('titan-connect.api.onboarding.telegram') }}"
    data-meta-instagram-url="{{ route('dashboard.user.titan-connect.onboarding.meta.start', ['provider' => 'instagram']) }}"
    data-meta-messenger-url="{{ route('dashboard.user.titan-connect.onboarding.meta.start', ['provider' => 'messenger']) }}"
    data-csrf="{{ csrf_token() }}"
    data-initial-filters='@json($initialFilters ?? [])'
    data-inbox-mode="{{ $mode ?? 'external' }}"
>
    <header class="tc-operator__header">
        <div>
            <h1>{{ __('Titan Connect Inbox') }}</h1>
            <p>{{ __('Team-grade omnichannel support across WhatsApp, Messenger, Instagram, Telegram, SMS and voice.') }}</p>
        </div>
        <div class="tc-operator__header-actions">
            <span class="tc-badge" data-role="unread-badge" hidden>0</span>
            <a class="tc-btn tc-btn--ghost" href="{{ route('dashboard.user.titan-connect.channels.index') }}">{{ __('Channels') }}</a>
            <a class="tc-btn tc-btn--ghost" href="{{ route('dashboard.user.titan-connect.settings.index') }}">{{ __('Settings') }}</a>
            <button type="button" class="tc-btn tc-btn--primary" data-action="connections">{{ __('Manage connections') }}</button>
            <button type="button" class="tc-btn" data-action="refresh">{{ __('Refresh') }}</button>
        </div>
    </header>

    <div class="tc-operator__filters">
        <input type="search" data-filter="search" placeholder="{{ __('Search conversations') }}">
        <select data-filter="provider">
            <option value="">{{ __('All channels') }}</option>
            <option value="whatsapp">WhatsApp</option><option value="messenger">Messenger</option>
            <option value="instagram">Instagram</option><option value="telegram">Telegram</option>
            <option value="sms">SMS</option><option value="voice">{{ __('Voice') }}</option>
        </select>
        <select data-filter="status"><option value="">{{ __('All statuses') }}</option><option value="open">{{ __('Open') }}</option><option value="closed">{{ __('Closed') }}</option></select>
        <select data-filter="priority"><option value="">{{ __('All priorities') }}</option><option value="urgent">{{ __('Urgent') }}</option><option value="high">{{ __('High') }}</option><option value="normal">{{ __('Normal') }}</option><option value="low">{{ __('Low') }}</option></select>
        <select data-filter="sort"><option value="newest">{{ __('Newest') }}</option><option value="oldest">{{ __('Oldest') }}</option></select>
        <input type="number" min="1" data-filter="assigned_user_id" placeholder="{{ __('Agent user ID') }}">
        <input type="date" data-filter="from" aria-label="{{ __('From date') }}">
        <input type="date" data-filter="to" aria-label="{{ __('To date') }}">
        <label><input type="checkbox" data-filter="unread"> {{ __('Unread only') }}</label>
        <label><input type="checkbox" data-filter="unassigned"> {{ __('Unassigned') }}</label>
        <input type="hidden" data-filter="handoff_state" value="">
    </div>

    <div class="tc-operator__grid">
        <aside class="tc-panel tc-thread-list" aria-label="{{ __('Conversations') }}">
            <div class="tc-panel__title"><strong>{{ __('Conversations') }}</strong><span data-role="thread-count"></span></div>
            <div data-role="thread-list" class="tc-thread-list__items"></div>
            <div data-role="empty" class="tc-empty" hidden>{{ __('No conversations match these filters.') }}</div>
        </aside>

        <main class="tc-panel tc-conversation">
            <div class="tc-conversation__header" data-role="conversation-header">
                <div><strong data-role="conversation-name">{{ __('Select a conversation') }}</strong><small data-role="conversation-meta"></small></div>
                <div class="tc-inline-actions">
                    <button type="button" class="tc-btn tc-btn--ghost" data-action="voice-call" disabled>{{ __('Voice call') }}</button>
                    <button type="button" class="tc-btn tc-btn--ghost" data-action="pin" disabled>{{ __('Pin') }}</button>
                    <button type="button" class="tc-btn tc-btn--ghost" data-action="close" disabled>{{ __('Close') }}</button>
                </div>
            </div>
            <div class="tc-messages" data-role="messages"><div class="tc-empty">{{ __('Choose a conversation to view messages.') }}</div></div>
            <div class="tc-compose">
                <textarea data-role="composer" rows="3" placeholder="{{ __('Write a reply…') }}" disabled></textarea>
                <div class="tc-compose__tools">
                    <button type="button" class="tc-btn tc-btn--ghost" data-action="canned" disabled>{{ __('Canned response') }}</button>
                    <button type="button" class="tc-btn tc-btn--ghost" data-action="internal-note" disabled>{{ __('Internal note') }}</button>
                    <button type="button" class="tc-btn tc-btn--ghost" data-action="tags" disabled>{{ __('Tag') }}</button>
                    <span class="tc-compose__spacer"></span>
                    <button type="button" class="tc-btn tc-btn--ghost" data-rewrite="improve" disabled>{{ __('Make it better') }}</button>
                    <button type="button" class="tc-btn tc-btn--ghost" data-rewrite="lengthen" disabled>{{ __('Make it longer') }}</button>
                    <button type="button" class="tc-btn tc-btn--ghost" data-rewrite="fix_grammar" disabled>{{ __('Fix grammar') }}</button>
                    <button type="button" class="tc-btn tc-btn--primary" data-action="send" disabled>{{ __('Send') }}</button>
                </div>
                <div class="tc-status" data-role="status" aria-live="polite"></div>
            </div>
        </main>

        <aside class="tc-panel tc-contact">
            <div class="tc-panel__title"><strong>{{ __('Customer context') }}</strong></div>
            <div data-role="contact-card" class="tc-contact__body"><div class="tc-empty">{{ __('Customer details appear here.') }}</div></div>
            <div class="tc-contact__section">
                <strong>{{ __('Operator controls') }}</strong>
                <label class="tc-field"><small>{{ __('Display name') }}</small><input type="text" data-role="edit-name" maxlength="255"></label>
                <label class="tc-field"><small>{{ __('Assigned user ID') }}</small><input type="number" min="1" data-role="edit-assignee"></label>
                <label class="tc-field"><small>{{ __('Priority') }}</small><select data-role="edit-priority"><option value="low">{{ __('Low') }}</option><option value="normal">{{ __('Normal') }}</option><option value="high">{{ __('High') }}</option><option value="urgent">{{ __('Urgent') }}</option></select></label>
                <label class="tc-field"><small>{{ __('Conversation colour') }}</small><input type="color" data-role="edit-color" value="#64748b"></label>
                <button type="button" class="tc-btn tc-btn--primary" data-action="save-thread" disabled>{{ __('Save') }}</button>
            </div>
            <div class="tc-contact__section">
                <strong>{{ __('Tags') }}</strong><div data-role="thread-tags" class="tc-tags"></div>
            </div>
            <div class="tc-contact__section">
                <strong>{{ __('Export') }}</strong>
                <div class="tc-inline-actions"><button class="tc-btn tc-btn--ghost" data-export="json" disabled>JSON</button><button class="tc-btn tc-btn--ghost" data-export="csv" disabled>CSV</button><button class="tc-btn tc-btn--ghost" data-export="text" disabled>TXT</button><button class="tc-btn tc-btn--ghost" data-export="pdf" disabled>PDF</button></div>
            </div>
        </aside>
    </div>

    <dialog data-dialog="connections" class="tc-dialog tc-dialog--wide">
        <form method="dialog"><header><strong>{{ __('Connect & manage channels') }}</strong><button value="cancel" aria-label="{{ __('Close') }}">×</button></header></form>
        <section class="tc-connection-manager">
            <div class="tc-panel__title"><strong>{{ __('Connection health') }}</strong><button type="button" class="tc-btn tc-btn--ghost" data-action="refresh-connections">{{ __('Refresh') }}</button></div>
            <div data-role="connection-list" class="tc-connection-list"><div class="tc-empty">{{ __('Loading manageable connections…') }}</div></div>
        </section>
        <div class="tc-provider-grid">
            <a class="tc-provider-card" href="{{ route('dashboard.user.titan-connect.onboarding.meta.start', ['provider' => 'instagram']) }}"><img src="{{ asset('vendor/titan-connect/icons/instagram.svg') }}" alt=""><strong>Instagram</strong><span>{{ __('Connect with Meta OAuth') }}</span></a>
            <a class="tc-provider-card" href="{{ route('dashboard.user.titan-connect.onboarding.meta.start', ['provider' => 'messenger']) }}"><img src="{{ asset('vendor/titan-connect/icons/messenger.svg') }}" alt=""><strong>Messenger</strong><span>{{ __('Connect with Meta OAuth') }}</span></a>
            <button type="button" class="tc-provider-card" data-setup="telegram"><img src="{{ asset('vendor/titan-connect/icons/telegram.svg') }}" alt=""><strong>Telegram</strong><span>{{ __('Validate bot and register webhook') }}</span></button>
            <button type="button" class="tc-provider-card" data-setup="whatsapp"><img src="{{ asset('vendor/titan-connect/icons/whatsapp.svg') }}" alt=""><strong>WhatsApp</strong><span>{{ __('Meta Cloud API or Twilio') }}</span></button>
            <button type="button" class="tc-provider-card" data-setup="voice"><span class="tc-provider-card__glyph">◉</span><strong>{{ __('Voice') }}</strong><span>{{ __('OpenAI Realtime or ElevenLabs') }}</span></button>
        </div>

        <form data-setup-form="telegram" class="tc-setup-form" hidden>
            <h3>{{ __('Telegram bot') }}</h3>
            <label class="tc-field"><small>{{ __('Display name') }}</small><input name="display_name" maxlength="255"></label>
            <label class="tc-field"><small>{{ __('Bot token') }}</small><input name="bot_token" type="password" required autocomplete="off"></label>
            <button class="tc-btn tc-btn--primary" type="submit">{{ __('Connect Telegram') }}</button>
        </form>

        <form data-setup-form="whatsapp" class="tc-setup-form" hidden>
            <h3>{{ __('WhatsApp') }}</h3>
            <label class="tc-field"><small>{{ __('Transport') }}</small><select name="transport"><option value="meta">Meta Cloud API</option><option value="twilio">Twilio WhatsApp</option></select></label>
            <label class="tc-field"><small>{{ __('Display name') }}</small><input name="display_name" required maxlength="255"></label>
            <label class="tc-field"><small>{{ __('Sender / external account ID') }}</small><input name="external_account_id" required maxlength="191"></label>
            <div data-whatsapp-fields="meta">
                <label class="tc-field"><small>{{ __('Phone number ID') }}</small><input name="phone_number_id" autocomplete="off"></label>
                <label class="tc-field"><small>{{ __('Access token') }}</small><input name="access_token" type="password" autocomplete="off"></label>
                <label class="tc-field"><small>{{ __('Meta app secret') }}</small><input name="app_secret" type="password" autocomplete="off"></label>
                <label class="tc-field"><small>{{ __('Webhook verify token') }}</small><input name="verify_token" type="password" autocomplete="off"></label>
            </div>
            <div data-whatsapp-fields="twilio" hidden>
                <label class="tc-field"><small>{{ __('Account SID') }}</small><input name="account_sid" autocomplete="off"></label>
                <label class="tc-field"><small>{{ __('Auth token') }}</small><input name="auth_token" type="password" autocomplete="off"></label>
                <label class="tc-field"><small>{{ __('WhatsApp sender') }}</small><input name="from" placeholder="+61…"></label>
                <label class="tc-field"><small>{{ __('Status callback (optional)') }}</small><input name="status_callback" type="url"></label>
            </div>
            <button class="tc-btn tc-btn--primary" type="submit">{{ __('Connect WhatsApp') }}</button>
        </form>

        <form data-setup-form="voice" class="tc-setup-form" hidden>
            <h3>{{ __('Voice connection') }}</h3>
            <label class="tc-field"><small>{{ __('Engine') }}</small><select name="engine"><option value="openai_realtime">OpenAI Realtime</option><option value="elevenlabs">ElevenLabs</option></select></label>
            <label class="tc-field"><small>{{ __('Display name') }}</small><input name="display_name" required maxlength="255"></label>
            <div data-voice-fields="openai_realtime">
                <label class="tc-field"><small>{{ __('OpenAI API key') }}</small><input name="openai_api_key" type="password" autocomplete="off"></label>
                <label class="tc-field"><small>{{ __('Voice override (optional)') }}</small><input name="voice"></label>
            </div>
            <div data-voice-fields="elevenlabs" hidden>
                <label class="tc-field"><small>{{ __('ElevenLabs API key') }}</small><input name="elevenlabs_api_key" type="password" autocomplete="off"></label>
                <label class="tc-field"><small>{{ __('Agent ID') }}</small><input name="agent_id"></label>
            </div>
            <button class="tc-btn tc-btn--primary" type="submit">{{ __('Create voice connection') }}</button>
        </form>
        <div class="tc-status" data-role="connection-status" aria-live="polite"></div>
    </dialog>

    <dialog data-dialog="canned" class="tc-dialog">
        <form method="dialog"><header><strong>{{ __('Canned responses') }}</strong><button value="cancel" aria-label="{{ __('Close') }}">×</button></header></form>
        <input type="search" data-role="canned-search" placeholder="{{ __('Search canned responses') }}">
        <div data-role="canned-list" class="tc-dialog__list"></div>
    </dialog>

    <dialog data-dialog="tags" class="tc-dialog">
        <form method="dialog"><header><strong>{{ __('Conversation tags') }}</strong><button value="cancel" aria-label="{{ __('Close') }}">×</button></header></form>
        <div data-role="tag-list" class="tc-dialog__list"></div>
        <button type="button" class="tc-btn tc-btn--primary" data-action="save-tags">{{ __('Apply tags') }}</button>
    </dialog>
</section>

</div>

@push('script')
<script src="{{ asset('vendor/titan-connect/js/operator-inbox.js') }}" defer></script>
@endpush
