# Build Report

- Extension: Titan AI Runtime
- Slug: `titan-ai`
- Version: `1.5.2`
- Installer schema: `titan-extension-v1`
- Folder: `TitanAI`
- Provider: `App\Extensions\TitanAI\System\TitanAIServiceProvider`
- Tenant boundary: `company_id`
- Production files: 362
- PHP files: 330
- Dependency representation: array of objects containing `slug` and optional `version`

This release incorporates the Titan Extension Manager 1.2.0 dependency-entry validation discovered during installation.
