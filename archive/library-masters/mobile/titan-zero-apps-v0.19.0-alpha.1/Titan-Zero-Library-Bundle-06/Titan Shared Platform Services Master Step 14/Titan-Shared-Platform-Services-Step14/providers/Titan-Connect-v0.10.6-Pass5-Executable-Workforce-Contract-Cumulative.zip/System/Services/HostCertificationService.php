<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Certification\BroadcastExecutionProbe;
use App\Extensions\TitanConnect\System\Certification\CompanyIsolationProbe;
use App\Extensions\TitanConnect\System\Certification\QueueExecutionProbe;

final class HostCertificationService
{
    public function __construct(
        private readonly HostReadinessService $readiness,
        private readonly IntegrationReadinessService $integrations,
        private readonly QueueExecutionProbe $queueProbe,
        private readonly BroadcastExecutionProbe $broadcastProbe,
        private readonly CompanyIsolationProbe $companyIsolationProbe,
    ) {
    }

    /**
     * @param array{queue?:bool,broadcast?:bool,two_company?:bool,timeout?:int} $options
     * @return array{version:string,generated_at:string,checks:array<int,array{name:string,status:string,message:string}>,summary:array{ok:int,warning:int,error:int}}
     */
    public function certify(array $options = []): array
    {
        $checks = array_merge($this->readiness->checks(), $this->integrations->checks());
        $timeout = max(1, (int) ($options['timeout'] ?? config('titan-connect.certification.probe_timeout_seconds', 10)));

        if (($options['queue'] ?? false) === true) $checks[] = $this->queueProbe->run($timeout);
        if (($options['broadcast'] ?? false) === true) $checks[] = $this->broadcastProbe->run();
        if (($options['two_company'] ?? false) === true) $checks[] = $this->companyIsolationProbe->run();

        $summary = ['ok' => 0, 'warning' => 0, 'error' => 0];
        foreach ($checks as $check) {
            $status = in_array($check['status'], ['ok', 'warning', 'error'], true) ? $check['status'] : 'error';
            $summary[$status]++;
        }

        return [
            'version' => '0.10.5',
            'generated_at' => now()->toIso8601String(),
            'checks' => $checks,
            'summary' => $summary,
        ];
    }

    /** @param array{summary:array{ok:int,warning:int,error:int}} $report */
    public function passes(array $report, bool $strict = false): bool
    {
        if (($report['summary']['error'] ?? 0) > 0) return false;
        return ! $strict || ($report['summary']['warning'] ?? 0) === 0;
    }
}
