<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration {
    public function up(): void
    {
        foreach (['crm_companies','crm_contacts','crm_leads'] as $table) {
            if (!Schema::hasTable($table)) continue;
            Schema::table($table, function (Blueprint $t) use ($table): void {
                if (!Schema::hasColumn($table, 'customer_unification_id')) {
                    $t->char('customer_unification_id',26)->nullable();
                    $t->index(['tenant_company_id','customer_unification_id'], substr($table,4,16).'_tenant_unify_idx');
                }
            });
        }
        if (Schema::hasTable('crm_leads') && !Schema::hasColumn('crm_leads','converted_customer_unification_id')) {
            Schema::table('crm_leads', function (Blueprint $t): void {
                $t->char('converted_customer_unification_id',26)->nullable();
                $t->index(['tenant_company_id','converted_customer_unification_id'],'crm_leads_conv_unify_idx');
            });
        }

        if (!Schema::hasTable('crm_customer_identities')) {
            Schema::create('crm_customer_identities', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('tenant_company_id')->index();
                $t->char('customer_unification_id',26)->index(); $t->string('subject_type',24)->index(); $t->char('subject_public_id',26)->index();
                $t->string('identity_type',24)->index(); $t->string('normalized_value',320); $t->string('source',40)->default('crm');
                $t->boolean('is_primary')->default(false); $t->dateTime('verified_at')->nullable(); $t->json('metadata')->nullable();
                $t->timestamps();
                $t->unique(['tenant_company_id','subject_type','subject_public_id','identity_type','normalized_value'],'crm_identity_subject_value_uq');
                $t->index(['tenant_company_id','identity_type','normalized_value'],'crm_identity_lookup_idx');
                $t->index(['tenant_company_id','customer_unification_id'],'crm_identity_root_idx');
            });
        }
        if (!Schema::hasTable('crm_external_identities')) {
            Schema::create('crm_external_identities', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('tenant_company_id')->index();
                $t->char('customer_unification_id',26)->index(); $t->string('provider',80); $t->string('external_identity_id',191);
                $t->string('subject_type',24)->nullable(); $t->char('subject_public_id',26)->nullable(); $t->dateTime('verified_at')->nullable();
                $t->json('metadata')->nullable(); $t->timestamps();
                $t->unique(['tenant_company_id','provider','external_identity_id'],'crm_external_identity_uq');
                $t->index(['tenant_company_id','customer_unification_id'],'crm_external_root_idx');
            });
        }
        if (!Schema::hasTable('crm_duplicate_reviews')) {
            Schema::create('crm_duplicate_reviews', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('tenant_company_id')->index();
                $t->string('source_type',24); $t->char('source_public_id',26); $t->string('candidate_type',24); $t->char('candidate_public_id',26);
                $t->unsignedTinyInteger('confidence'); $t->char('match_fingerprint',64)->index(); $t->json('signals')->nullable(); $t->boolean('blocking')->default(false)->index();
                $t->string('status',24)->default('pending')->index(); $t->json('resolution')->nullable(); $t->unsignedBigInteger('resolved_by_user_id')->nullable();
                $t->dateTime('resolved_at')->nullable(); $t->timestamps();
                $t->unique(['tenant_company_id','source_type','source_public_id','candidate_type','candidate_public_id'],'crm_dup_review_pair_uq');
                $t->index(['tenant_company_id','status','blocking'],'crm_dup_review_queue_idx');
            });
        }
        if (!Schema::hasTable('crm_merge_snapshots')) {
            Schema::create('crm_merge_snapshots', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('tenant_company_id')->index();
                $t->string('resource_type',24); $t->char('winner_public_id',26); $t->char('loser_public_id',26);
                $t->json('winner_before'); $t->json('loser_before'); $t->json('relationship_summary')->nullable();
                $t->char('before_snapshot_hash',64); $t->char('after_snapshot_hash',64)->nullable(); $t->string('rollback_reference',120)->unique();
                $t->unsignedBigInteger('actor_user_id')->nullable(); $t->dateTime('merged_at')->nullable(); $t->timestamps();
                $t->index(['tenant_company_id','resource_type','winner_public_id'],'crm_merge_snapshot_lookup_idx');
            });
        }
        if (Schema::hasTable('crm_merge_log')) {
            Schema::table('crm_merge_log', function (Blueprint $t): void {
                if (!Schema::hasColumn('crm_merge_log','snapshot_public_id')) $t->char('snapshot_public_id',26)->nullable()->index();
                if (!Schema::hasColumn('crm_merge_log','rollback_reference')) $t->string('rollback_reference',120)->nullable()->index();
                if (!Schema::hasColumn('crm_merge_log','before_snapshot_hash')) $t->char('before_snapshot_hash',64)->nullable();
                if (!Schema::hasColumn('crm_merge_log','after_snapshot_hash')) $t->char('after_snapshot_hash',64)->nullable();
            });
        }

        $companyRoots=[];
        if (Schema::hasTable('crm_companies')) {
            DB::table('crm_companies')->whereNull('customer_unification_id')->orderBy('id')->select('id','tenant_company_id')->each(function(object $row) use (&$companyRoots): void {
                $root=(string)Str::ulid(); $companyRoots[(string)$row->tenant_company_id.':'.$row->id]=$root;
                DB::table('crm_companies')->where('id',$row->id)->update(['customer_unification_id'=>$root]);
            });
            DB::table('crm_companies')->whereNotNull('customer_unification_id')->orderBy('id')->select('id','tenant_company_id','customer_unification_id')->each(function(object $row) use (&$companyRoots): void {
                $companyRoots[(string)$row->tenant_company_id.':'.$row->id]=(string)$row->customer_unification_id;
            });
        }
        if (Schema::hasTable('crm_contacts')) {
            DB::table('crm_contacts')->whereNull('customer_unification_id')->orderBy('id')->select('id','tenant_company_id','company_id')->each(function(object $row) use (&$companyRoots): void {
                $root=$row->company_id ? ($companyRoots[(string)$row->tenant_company_id.':'.$row->company_id]??null) : null;
                DB::table('crm_contacts')->where('id',$row->id)->update(['customer_unification_id'=>$root ?: (string)Str::ulid()]);
            });
        }
        if (Schema::hasTable('crm_leads')) {
            DB::table('crm_leads')->whereNull('customer_unification_id')->orderBy('id')->select('id')->each(fn(object $row)=>DB::table('crm_leads')->where('id',$row->id)->update(['customer_unification_id'=>(string)Str::ulid()]));
        }

        // Normalize legacy contact points before building identity indexes.
        foreach (['crm_companies','crm_contacts','crm_leads'] as $table) {
            if (!Schema::hasTable($table)) continue;
            DB::table($table)->whereNull('normalized_email')->whereNotNull('email')->orderBy('id')->select('id','email')->each(function(object $row) use($table): void {
                $email=strtolower(trim((string)$row->email));DB::table($table)->where('id',$row->id)->update(['normalized_email'=>$email!==''?$email:null]);
            });
            DB::table($table)->whereNull('normalized_phone')->whereNotNull('phone')->orderBy('id')->select('id','phone')->each(function(object $row) use($table): void {
                $raw=trim((string)$row->phone);$international=str_starts_with($raw,'+')||str_starts_with($raw,'00');$digits=preg_replace('/\D+/','',$raw)??'';if(str_starts_with($raw,'00'))$digits=substr($digits,2);$phone=$digits===''?null:($international?'+'.$digits:$digits);DB::table($table)->where('id',$row->id)->update(['normalized_phone'=>$phone]);
            });
        }

        // Build normalized identity indexes for existing CRM records without changing record ownership.
        foreach (['company'=>'crm_companies','contact'=>'crm_contacts','lead'=>'crm_leads'] as $subjectType=>$table) {
            if (!Schema::hasTable($table)) continue;
            DB::table($table)->whereNotNull('customer_unification_id')->whereNull('deleted_at')->orderBy('id')->select('public_id','tenant_company_id','customer_unification_id','normalized_email','normalized_phone')->each(function(object $row) use($subjectType): void {
                foreach (['email'=>$row->normalized_email??null,'phone'=>$row->normalized_phone??null] as $identityType=>$value) {
                    $value=trim((string)$value); if($value==='') continue;
                    DB::table('crm_customer_identities')->insertOrIgnore(['public_id'=>(string)Str::ulid(),'tenant_company_id'=>$row->tenant_company_id,'customer_unification_id'=>$row->customer_unification_id,'subject_type'=>$subjectType,'subject_public_id'=>$row->public_id,'identity_type'=>$identityType,'normalized_value'=>$value,'source'=>'migration','is_primary'=>true,'metadata'=>json_encode(['backfilled'=>true]),'created_at'=>now(),'updated_at'=>now()]);
                }
            });
        }
        if (Schema::hasTable('crm_mobile_identity_links') && Schema::hasColumn('crm_mobile_identity_links','tenant_company_id')) {
            DB::table('crm_mobile_identity_links')->whereNotNull('external_identity_id')->orderBy('id')->each(function(object $link): void {
                $root=null;$subjectType=null;$subjectPublicId=null;
                if(!empty($link->crm_contact_public_id)){$row=DB::table('crm_contacts')->where('tenant_company_id',$link->tenant_company_id)->where('public_id',$link->crm_contact_public_id)->first();if($row){$root=$row->customer_unification_id??null;$subjectType='contact';$subjectPublicId=$row->public_id;}}
                if(!$root&&!empty($link->crm_company_public_id)){$row=DB::table('crm_companies')->where('tenant_company_id',$link->tenant_company_id)->where('public_id',$link->crm_company_public_id)->first();if($row){$root=$row->customer_unification_id??null;$subjectType='company';$subjectPublicId=$row->public_id;}}
                if(!$root)return; $provider='titan_mobile:'.strtolower(trim((string)($link->surface??'unknown')));
                DB::table('crm_external_identities')->insertOrIgnore(['public_id'=>(string)Str::ulid(),'tenant_company_id'=>$link->tenant_company_id,'customer_unification_id'=>$root,'provider'=>$provider,'external_identity_id'=>(string)$link->external_identity_id,'subject_type'=>$subjectType,'subject_public_id'=>$subjectPublicId,'verified_at'=>$link->verified_at??null,'metadata'=>$link->metadata??json_encode(['backfilled'=>true]),'created_at'=>now(),'updated_at'=>now()]);
            });
        }

        if (Schema::hasTable('crm_chatbot_identities') && Schema::hasColumn('crm_chatbot_identities','tenant_company_id')) {
            DB::table('crm_chatbot_identities')->whereNotNull('crm_contact_public_id')->orderBy('id')->each(function(object $link): void {
                $contact=DB::table('crm_contacts')->where('tenant_company_id',$link->tenant_company_id)->where('public_id',$link->crm_contact_public_id)->first();if(!$contact||empty($contact->customer_unification_id))return;
                DB::table('crm_external_identities')->insertOrIgnore(['public_id'=>(string)Str::ulid(),'tenant_company_id'=>$link->tenant_company_id,'customer_unification_id'=>$contact->customer_unification_id,'provider'=>'chatbot','external_identity_id'=>(string)$link->chatbot_id.':'.(string)$link->chatbot_customer_id,'subject_type'=>'contact','subject_public_id'=>$contact->public_id,'verified_at'=>$link->verified_at??null,'metadata'=>$link->metadata??json_encode(['backfilled'=>true]),'created_at'=>now(),'updated_at'=>now()]);
            });
        }
    }

    public function down(): void
    {
        foreach (['crm_merge_snapshots','crm_duplicate_reviews','crm_external_identities','crm_customer_identities'] as $table) Schema::dropIfExists($table);
        if (Schema::hasTable('crm_merge_log')) Schema::table('crm_merge_log', function(Blueprint $t): void { foreach(['snapshot_public_id','rollback_reference','before_snapshot_hash','after_snapshot_hash'] as $c) if(Schema::hasColumn('crm_merge_log',$c)) $t->dropColumn($c); });
        if (Schema::hasTable('crm_leads') && Schema::hasColumn('crm_leads','converted_customer_unification_id')) Schema::table('crm_leads',fn(Blueprint $t)=>$t->dropColumn('converted_customer_unification_id'));
        foreach(['crm_companies','crm_contacts','crm_leads'] as $table) if(Schema::hasTable($table)&&Schema::hasColumn($table,'customer_unification_id')) Schema::table($table,fn(Blueprint $t)=>$t->dropColumn('customer_unification_id'));
    }
};
