<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Contracts\RewindManagerContract;
use App\Extensions\TitanRewind\System\Contracts\RewindEvidenceSignerContract;
use App\Extensions\TitanRewind\System\Contracts\RewindSourceAdapterContract;
use App\Extensions\TitanRewind\System\Contracts\RewindHistoricalArtifactResolverContract;
use App\Extensions\TitanRewind\System\AI\RewindToolCatalogue;
use App\Extensions\TitanRewind\System\Replay\RewindArtifactResolverRegistry;
use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use App\Extensions\TitanRewind\System\Models\RewindGovernanceReceipt;
use App\Extensions\TitanRewind\System\Models\RewindIntegrityCheck;
use App\Extensions\TitanRewind\System\Models\RewindRecoveryPlan;
use App\Extensions\TitanRewind\System\Models\RewindLegalHold;
use App\Extensions\TitanRewind\System\Models\RewindReplayRun;
use App\Extensions\TitanRewind\System\Reconstruction\RewindSourceAdapterRegistry;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Health\RewindHealthCheck;
use App\Extensions\TitanRewind\System\Sources\RewindHostSourceDiscovery;
use App\Extensions\TitanRewind\System\Artifacts\RewindHistoricalArtifactArchive;
use App\Extensions\TitanRewind\System\Artifacts\RewindHostArtifactDiscovery;

final class RewindManager implements RewindManagerContract
{
    public function __construct(
        private RewindSourceAdapterRegistry $sources,
        private RewindReconstructionService $reconstruction,
        private RewindReplayService $replay,
        private RewindIntegrityService $integrity,
        private RewindDriftService $drift,
        private RewindEvidencePackageService $evidence,
        private RewindRecoveryPlanService $recovery,
        private RewindGovernanceService $governance,
        private RewindArtifactResolverRegistry $artifacts,
        private RewindAssistantService $assistantService,
        private RewindAnalyticsService $analyticsService,
        private RewindToolCatalogue $tools,
        private RewindEvidenceSignerContract $signer,
        private RewindSourceWatermarkService $watermarks,
        private RewindLegalHoldService $legalHolds,
        private RewindHealthCheck $healthCheck,
        private RewindRuntimeStateService $runtime,
        private RewindDeadLetterService $deadLetters,
        private RewindHostSourceDiscovery $sourceDiscovery,
        private RewindHistoricalArtifactArchive $artifactArchive,
        private RewindRetentionService $retention,
        private RewindHostArtifactDiscovery $artifactDiscovery,
    ) {}

    public function health(): array
    {
        $liveness=$this->healthCheck->liveness();
        $readiness=$this->healthCheck->readiness();
        return ['engine'=>'titan-rewind','status'=>$readiness['status'],'version'=>'1.0.6','liveness'=>$liveness,'readiness'=>$readiness,'authoritative_mutation'=>false,'replay_mutation'=>false,'governance_gateway_available'=>$this->governance->available(),'evidence_signer_available'=>$this->signer->available(),'blueprint_profile_active'=>true,'package_profile_certified'=>true,'host_runtime_certified'=>false,'final_blueprint_profile_certified'=>false];
    }

    public function liveness(): array { return $this->healthCheck->liveness(); }
    public function readiness(): array { return $this->healthCheck->readiness(); }

    public function foundation(): array
    {
        return [
            'capabilities'=>['titan-rewind','rewind.observability','rewind.signal','rewind.dead-letter','rewind.runtime-state','rewind.backpressure','rewind.circuit-breaker','rewind.source-discovery','rewind.artifact.archive','rewind.retention','rewind.purge.receipts','rewind.evidence.key-rotation','rewind.health','rewind.foundation','rewind.timeline','rewind.reconstruct','rewind.case','rewind.snapshot','rewind.dependencies','rewind.replay.dry_run','rewind.integrity','rewind.drift','rewind.root_cause','rewind.snapshot.compare','rewind.diagnostics','rewind.audit','rewind.evidence','rewind.compliance.export','rewind.recovery.plan','rewind.governance.handoff','rewind.compare','rewind.replay.counterfactual','rewind.compare.model','rewind.compare.policy','rewind.compare.knowledge','rewind.assistant','rewind.analytics','rewind.evidence.signed','rewind.custody','rewind.legal-hold','rewind.source-watermarks','rewind.replay.current-state','rewind.streaming','rewind.host-certification'],
            'trace_context'=>['tenant_company_id','trace_id','correlation_id','causation_id'],
            'source_mode'=>'read-only-adapters',
            'hidden_chain_of_thought_storage'=>false,
            'reconstruction_available'=>true,
            'historical_dry_run_available'=>true,
            'comparative_replay_available'=>true,
            'current_state_structural_compare_available'=>true,
            'signed_evidence_required'=>true,
            'source_watermarks_available'=>true,
            'legal_hold_available'=>true,
            'runtime_resilience_available'=>true,
            'structured_observability_available'=>true,
            'signal_outbox_available'=>true,
            'dead_letter_attention_available'=>true,
            'maintenance_and_draining_available'=>true,
            'host_source_discovery_available'=>true,
            'historical_artifact_archive_available'=>true,
            'retention_and_purge_receipts_available'=>true,
            'evidence_key_rotation_available'=>true,
            'bounded_streaming_available'=>true,
            'blueprint_profile_active'=>true,
            'package_profile_certified'=>true,
            'host_runtime_certified'=>false,
            'final_blueprint_profile_certified'=>false,
            'comparison_semantics'=>'structural_projection_only',
            'decision_reexecution_performed'=>false,
            'audit_export_available'=>true,
            'recovery_planning_available'=>true,
            'governance_gateway_available'=>$this->governance->available(),
            'authoritative_mutation'=>false,
        ];
    }

    public function registerSourceAdapter(RewindSourceAdapterContract $adapter): void { $this->sources->register($adapter); }
    public function discoverHostSources(): array { return $this->sourceDiscovery->discover(); }
    public function historicalArtifact(string $kind,string $version,array $context=[]): array { return $this->artifactArchive->resolveAndArchive($kind,$version,$context); }
    public function discoverHistoricalArtifactResolvers(): array { return $this->artifactDiscovery->discover(); }
    public function retentionPreview(int $tenantCompanyId,?string $class=null): array { return $this->retention->preview($tenantCompanyId,$class); }
    public function runRetention(int $tenantCompanyId,string $class,?int $actorId=null,int $batchSize=250): array { return $this->retention->run($tenantCompanyId,$class,$actorId,$batchSize)->toArray(); }
    public function registerHistoricalArtifactResolver(RewindHistoricalArtifactResolverContract $resolver): void { $this->artifacts->register($resolver); }
    public function reconstruct(RewindTraceQuery $query): array { return $this->reconstruction->reconstruct($query, true); }
    public function queueDryRun(RewindTraceQuery $query, ?int $requestedById = null, array $input = []): RewindReplayRun { return $this->replay->queueDryRun($query,$requestedById,$input); }
    public function queueComparison(RewindTraceQuery $query, string $mode, ?int $requestedById = null, array $input = []): RewindReplayRun { return $this->replay->queueComparison($query,$mode,$requestedById,$input); }
    public function assistant(string $message, array $context = []): array { return $this->assistantService->route($message,$context); }
    public function analytics(int $tenantCompanyId): array { return $this->analyticsService->dashboard($tenantCompanyId); }
    public function toolCatalogue(): array { return $this->tools->all(); }
    public function verifyIntegrity(RewindTraceQuery $query, ?int $checkedById = null): RewindIntegrityCheck { return $this->integrity->verifyTrace($query, $checkedById); }
    public function scanDrift(RewindTraceQuery $query, ?int $actorId = null): array { return $this->drift->scanTrace($query, $actorId); }
    public function generateEvidence(RewindTraceQuery $query, string $type = 'audit', ?int $caseId = null, ?int $actorId = null): RewindEvidencePackage { return $this->evidence->forTrace($query,$type,$caseId,$actorId); }
    public function generateCaseEvidence(int $tenantCompanyId, string $caseUuid, string $type = 'audit', ?int $actorId = null): RewindEvidencePackage { return $this->evidence->forCase($tenantCompanyId,$caseUuid,$type,$actorId); }
    public function createRecoveryPlan(RewindTraceQuery $query, ?int $caseId = null, ?int $actorId = null, array $options = []): RewindRecoveryPlan { return $this->recovery->createForTrace($query,$caseId,$actorId,$options); }
    public function governanceAvailable(): bool { return $this->governance->available(); }
    public function requestRecoveryApproval(RewindRecoveryPlan $plan, ?int $actorId = null): RewindGovernanceReceipt { return $this->governance->requestApproval($plan,$actorId); }
    public function sourceCompleteness(RewindTraceQuery $query): array { return $this->watermarks->forTrace($query); }
    public function applyLegalHold(int $tenantCompanyId, string $scopeType, string $scopeId, string $authority, string $reason, ?int $actorId = null): RewindLegalHold { return $this->legalHolds->apply($tenantCompanyId,$scopeType,$scopeId,$authority,$reason,$actorId); }
    public function releaseLegalHold(int $tenantCompanyId, string $holdUuid, string $reason, ?int $actorId = null): RewindLegalHold { return $this->legalHolds->release($tenantCompanyId,$holdUuid,$reason,$actorId); }
    public function runtimeState(): array { $state=$this->runtime->current(); return ['state'=>$state->value(),'accepts_new_work'=>$state->acceptsNewWork(),'allows_in_flight_completion'=>$state->allowsInFlightCompletion()]; }
    public function setRuntimeState(string $state, ?string $reason = null, ?int $actorId = null): array { $row=$this->runtime->set($state,$reason,$actorId); return ['state'=>$row->state,'reason'=>$row->reason,'updated_by_id'=>$row->updated_by_id]; }
    public function retryDeadLetter(string $deadLetterUuid): array { return $this->deadLetters->retry($deadLetterUuid)->toArray(); }
}
