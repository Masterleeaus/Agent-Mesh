@extends('panel.layout.app')
@section('content')
@php
    $req=$dashboard['request']??[];
    $hidden=['scope'=>$req['scope']??'system','tenant_company_id'=>$req['tenant_company_id']??null,'window'=>$req['window']??'5m','limit'=>$req['limit']??100];
    $lifecycle=$dashboard['lifecycle']??[];
    $pageTitle='Lifecycle and Archives';$pageSubtitle='Retention, legal holds, archive verification, prune preview and lifecycle audit';$activePage='lifecycle-archives';
@endphp
@include('titan-signal-engine::admin-rc8-1.partials.styles')
<div class="tse-wrap">
@include('titan-signal-engine::admin-rc8-1.partials.header')
@include('titan-signal-engine::admin-rc8-1.partials.alerts')
@include('titan-signal-engine::admin-rc8-1.partials.filter')
<div class="tse-grid tse-section">
    @foreach(['active'=>'Active','legal_holds'=>'Legal holds','prune_candidates'=>'Prune candidates','archived'=>'Archived','pruned'=>'Pruned'] as $k=>$label)<div class="tse-card"><div class="tse-kpi-label">{{ $label }}</div><div class="tse-value">{{ number_format((int)($lifecycle[$k]??0)) }}</div></div>@endforeach
</div>
<div class="tse-card tse-section tse-danger"><h2>Governed prune</h2><p class="tse-muted">Preview first. Execution is bound to the exact candidate set and must archive and verify before hot-event pruning.</p><form method="GET">@foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input type="hidden" name="prune_preview" value="1"><button class="tse-btn" type="submit">Preview prune candidates</button></form></div>
@if($prunePreview)
<div class="tse-card tse-section tse-danger"><h2>Prune preview</h2><p><strong>{{ $prunePreview['candidate_count']??0 }}</strong> candidate events. This preview is non-destructive and binds the exact candidate set.</p><p class="tse-code">Candidate hash: {{ $prunePreview['candidate_hash']??'' }} · expires {{ $prunePreview['expires_at']??'' }}</p><pre class="tse-pre">{{ json_encode($prunePreview['by_retention_class']??[],JSON_PRETTY_PRINT) }}</pre>@if(($prunePreview['candidate_count']??0)>0)<form method="POST" action="{{ route('dashboard.admin.titan.signal.engine.lifecycle.prune') }}">@csrf @foreach($hidden as $k=>$v) @if($v!==null)<input type="hidden" name="{{ $k }}" value="{{ $v }}">@endif @endforeach<input type="hidden" name="preview_token" value="{{ $prunePreview['preview_token']??'' }}"><div class="tse-stack"><label>Reason<input class="tse-input" name="reason" required maxlength="255" placeholder="Required governed reason"></label><button class="tse-btn tse-btn-primary" type="submit">Archive, verify and prune exact preview</button></div></form>@endif</div>
@endif
<div class="tse-two tse-section">
    <div class="tse-card"><h2>Recent archives</h2><div class="tse-scroll"><table class="tse-table"><thead><tr><th>Batch</th><th>Status</th><th>Events</th><th>Driver</th><th>Verified</th></tr></thead><tbody>@forelse(($dashboard['archives']??[]) as $a)<tr><td class="tse-code">{{ $a['batch_id'] }}</td><td>{{ $a['status'] }}</td><td>{{ $a['event_count'] }}</td><td>{{ $a['archive_driver']??'—' }}</td><td>{{ $a['verified_at']??'—' }}</td></tr>@empty<tr><td colspan="5">No archive batches.</td></tr>@endforelse</tbody></table></div></div>
    <div class="tse-card"><h2>Lifecycle audit</h2><div class="tse-scroll"><table class="tse-table"><thead><tr><th>Action</th><th>Actor</th><th>Target</th><th>When</th></tr></thead><tbody>@forelse(($dashboard['lifecycle_audit']??[]) as $a)<tr><td>{{ $a['action'] }}</td><td class="tse-code">{{ $a['actor_id'] }}</td><td class="tse-code">{{ $a['target_event_id']??$a['batch_id']??'—' }}</td><td>{{ $a['occurred_at'] }}</td></tr>@empty<tr><td colspan="4">No lifecycle actions.</td></tr>@endforelse</tbody></table></div></div>
</div>
</div>
@endsection
