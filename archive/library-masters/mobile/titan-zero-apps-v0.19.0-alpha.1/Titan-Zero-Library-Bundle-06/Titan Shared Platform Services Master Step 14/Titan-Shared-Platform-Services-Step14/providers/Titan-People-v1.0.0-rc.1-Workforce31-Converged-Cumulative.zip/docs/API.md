# Titan People API v1

Base route: `/api/v1/titan-people`.

All routes require authenticated host identity and the Titan People host authorization middleware. Tenant authority is derived from trusted server-side host context. Request body/query `tenant_company_id` and worker primary keys are never accepted as authority.

## Read endpoints

- `GET /people` — bounded directory; `per_page` defaults to 25 and is capped at 100.
- `GET /people/{workerPublicId}` — tenant-scoped worker by opaque People public ID.
- `GET /organisation` — bounded department, position and team read model.
- `GET /leave` — bounded leave request read model.
- `GET /holidays` — bounded holiday read model.
- `GET /lifecycle` — bounded lifecycle event read model.
- `GET /me` — actor-derived self profile.

## Self-service mutation

- `PATCH /me` — allowlisted personal fields only. It cannot change tenant, worker identity, employment status, organisation authority, leave balances, password or avatar.

Management lifecycle/leave mutations remain governed by their existing People command/capability boundaries and are not exposed as generic CRUD API writes.
