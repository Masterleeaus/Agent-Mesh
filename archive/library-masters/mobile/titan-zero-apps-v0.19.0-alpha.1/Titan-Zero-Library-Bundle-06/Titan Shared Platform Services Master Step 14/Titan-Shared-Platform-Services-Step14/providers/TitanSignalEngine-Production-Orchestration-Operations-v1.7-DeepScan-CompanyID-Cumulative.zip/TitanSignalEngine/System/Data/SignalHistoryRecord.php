<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalHistoryRecord
{
    /** @param array<string,mixed> $event */
    private function __construct(
        public array $event,
        public string $storageTier,
        public bool $archiveVerified,
        public bool $canonicalChecksumVerified,
        public ?SignalArchiveEntry $archive,
    ) {
        if (! in_array($this->storageTier, ['hot', 'cold'], true)) {
            throw new InvalidArgumentException('Signal history storage tier must be hot or cold.');
        }
        if (($this->event['event_id'] ?? '') === '') {
            throw new InvalidArgumentException('Signal history record requires event_id.');
        }
    }

    /** @param array<string,mixed> $event */
    public static function hot(array $event, bool $canonicalChecksumVerified): self
    {
        return new self($event, 'hot', false, $canonicalChecksumVerified, null);
    }

    /** @param array<string,mixed> $event */
    public static function cold(array $event, SignalArchiveEntry $entry, bool $archiveVerified): self
    {
        return new self(
            $event,
            'cold',
            $archiveVerified,
            $entry->privacyProjected ? false : $archiveVerified,
            $entry,
        );
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'event' => $this->event,
            'storage_tier' => $this->storageTier,
            'integrity' => [
                'archive_verified' => $this->archiveVerified,
                'canonical_checksum_verified' => $this->canonicalChecksumVerified,
                'privacy_projected' => $this->archive?->privacyProjected ?? false,
                'original_checksum' => $this->archive?->originalChecksum ?? ($this->event['checksum'] ?? null),
            ],
            'archive' => $this->archive?->toArray(),
        ];
    }
}
