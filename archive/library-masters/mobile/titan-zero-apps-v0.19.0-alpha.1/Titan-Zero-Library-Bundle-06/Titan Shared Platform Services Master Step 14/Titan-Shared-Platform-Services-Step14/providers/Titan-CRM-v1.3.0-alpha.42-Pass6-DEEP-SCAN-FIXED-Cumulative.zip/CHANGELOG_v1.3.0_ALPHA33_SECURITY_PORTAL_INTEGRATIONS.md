# Titan CRM Core v1.3.0-alpha.33 — Security, Portal & Integration Production Gate

## Portal
- Customer Hub grants now require a real same-tenant company/contact anchor and dependent scopes are validated.
- Portal access uses a separate one-time identity verification code and a durable bound browser session.
- Sensitive commercial actions, comments, file listing/upload/download require a verified portal session.
- Uploads are quarantined until a configured malware scanner releases them; scanner failure is fail-closed.
- Downloads require `files.download`, force attachment disposition and `nosniff`, and only expose clean released files.
- Pre-alpha.33 unverified active grants are revoked on upgrade and must be reissued; legacy unverified files are quarantined.

## API keys
- Keys are hash-only, tenant-bound, time-bounded by default, and may be restricted to exact IPs/CIDRs.
- Route-specific read scopes are enforced while broad `crm.read` remains a compatible parent scope.
- Rotation preserves family lineage and IP/scope restrictions and revokes the predecessor with an auditable reason.

## Webhooks
- Signing contract upgraded to v3: timestamp + nonce + delivery ID + body are HMAC-bound.
- Deliveries persist deterministic idempotency keys, nonce, secret version, response hash and dead-letter timestamps.
- Signing-secret rotation supports a bounded previous-secret verification/retry window.
- Dead-lettered deliveries can be inspected/requeued with `crm:webhooks:retry --dead-letter=<delivery_public_id>`.
- Fixed legacy dispatcher defects involving duplicate payload keys and undefined signing variables.

## Imports and exports
- Non-dry-run imports stage first, produce a canonical impact hash, and require separate governed `crm.import.commit` confirmation.
- Rollback uses per-record before/after evidence and refuses destructive rollback if imported records changed or legacy evidence is absent.
- Exports are tenant-scoped, strip internal persistence identifiers, include an integrity SHA-256/manifest, and write an audit journal.

## Production gate
`crm:production-check` now blocks on missing portal-session/import-rollback security schema, missing scanner binding, or active indefinite API keys, and warns on quarantine, dead-letter and staged-import backlogs.
