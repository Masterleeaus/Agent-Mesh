<?php

declare(strict_types=1);
namespace Tests\Unit;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Exceptions\SourceVersionConflictException; use App\Extensions\TitanKnowledgeAuthority\System\Domain\Services\SourceVersionLineagePolicy; use PHPUnit\Framework\TestCase;
final class SourceVersionLineagePolicyTest extends TestCase { public function test_sequence_and_version_key_are_deterministic():void{$p=new SourceVersionLineagePolicy();self::assertSame(1,$p->nextSequence(null));self::assertSame(42,$p->nextSequence(41));self::assertSame('v0000000042',$p->versionKey(42));} public function test_stale_expected_predecessor_is_rejected():void{$p=new SourceVersionLineagePolicy();$this->expectException(SourceVersionConflictException::class);$p->assertExpectedPrevious(11,10);} }
