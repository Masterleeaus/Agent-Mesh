# Capability Router

`CapabilityRouter` routes canonical capabilities to independent providers registered in `CapabilityProviderRegistry`. `CapabilityDescriptor` exposes provider, version, read/write, risk, authority, approval, offline classification, idempotency, roles/scopes, fresh-auth requirements, schemas, availability and reason.

Outcomes are `executed`, `prepared`, `pending_approval`, `unavailable`, `unauthorized`, `validation_failed`, `conflict`, `offline_deferred`, `failed`, or `blocked_dependency`.

Legacy names resolve through `CapabilityAliasRegistry`; aliases do not create duplicate handlers or policies. Unknown/unbound capabilities fail closed.
