<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use App\Extensions\Crm\System\Integrations\Chatbot\{CrmChatbotCompatibility,CrmChatbotSettingsService,CrmChatbotToolService};
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
final class ChatbotIntegrationController extends Controller
{
    public function __construct(private CrmChatbotCompatibility $compatibility,private CrmChatbotSettingsService $settings,private CrmHumanMutationGateway $mutations) {}
    public function index(Request $request)
    {
        $userId=(int)$request->user()->id;$chatbots=[];
        if($this->compatibility->installed()&&class_exists(\App\Extensions\Chatbot\System\Models\Chatbot::class)){
            $chatbots=\App\Extensions\Chatbot\System\Models\Chatbot::query()->where('company_id', CrmCompanyScope::companyId($userId))->orderBy('name')->get()->map(fn($c)=>['id'=>(int)$c->getKey(),'uuid'=>$c->getAttribute('uuid'),'name'=>$c->getAttribute('name')?:('Chatbot #'.$c->getKey()),'settings'=>$this->settings->forChatbot($userId,(int)$c->getKey())])->all();
        }
        return view('crm::integrations.chatbot',[
            'chatbots'=>$chatbots,
            'installed'=>$this->compatibility->installed(),
            'supported'=>$this->compatibility->supported(),
            'version'=>$this->compatibility->version(),
            'tools'=>CrmChatbotToolService::TOOL_NAMES,
        ]);
    }
    public function update(Request $request)
    {
        $v=$request->validate(['chatbot_id'=>['required','integer'],'enabled'=>['nullable','boolean'],'capture_contacts'=>['nullable','boolean'],'create_lead_on_capture'=>['nullable','boolean'],'record_activity'=>['nullable','boolean'],'allow_financial_reads'=>['nullable','boolean'],'require_verified_financial_identity'=>['nullable','boolean'],'allowed_tools'=>['nullable','array'],'allowed_tools.*'=>['string','max:100']]);
        $userId=(int)$request->user()->id;abort_unless(class_exists(\App\Extensions\Chatbot\System\Models\Chatbot::class),404);$chatbot=\App\Extensions\Chatbot\System\Models\Chatbot::query()->where('company_id', CrmCompanyScope::companyId($userId))->whereKey($v['chatbot_id'])->firstOrFail();
        $payload=[];foreach(['enabled','capture_contacts','create_lead_on_capture','record_activity','allow_financial_reads','require_verified_financial_identity'] as $k)$payload[$k]=$request->boolean($k);$payload['allowed_tools']=$v['allowed_tools']??[];
        $this->mutations->execute($request,'crm.chatbot.settings.update',['chatbot_id'=>(int)$chatbot->getKey(),'settings'=>$payload]);return back()->with('success',trans('Chatbot CRM settings updated.'));
    }
}
