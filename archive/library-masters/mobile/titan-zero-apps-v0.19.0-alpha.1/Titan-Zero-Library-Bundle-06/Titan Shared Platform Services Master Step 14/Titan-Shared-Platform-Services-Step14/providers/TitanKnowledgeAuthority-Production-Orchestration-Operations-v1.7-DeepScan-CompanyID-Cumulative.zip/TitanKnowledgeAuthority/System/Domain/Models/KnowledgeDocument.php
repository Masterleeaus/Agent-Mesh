<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

final class KnowledgeDocument extends Model
{
    protected $table = 'titan_knowledge_documents';
    protected $guarded = ['id'];
    protected $casts = [
        'metadata' => 'array',
        'effective_from' => 'immutable_datetime',
        'effective_until' => 'immutable_datetime',
    ];

    public function sourceVersion(): BelongsTo
    {
        return $this->belongsTo(KnowledgeSourceVersion::class, 'source_version_id');
    }

    public function sections(): HasMany
    {
        return $this->hasMany(KnowledgeSection::class, 'document_id');
    }
}
