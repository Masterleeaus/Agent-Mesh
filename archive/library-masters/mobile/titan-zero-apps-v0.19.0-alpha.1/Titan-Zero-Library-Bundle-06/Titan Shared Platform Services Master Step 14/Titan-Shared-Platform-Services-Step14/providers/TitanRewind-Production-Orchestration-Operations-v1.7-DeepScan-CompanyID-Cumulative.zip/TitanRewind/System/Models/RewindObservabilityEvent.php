<?php

declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Models;
use Illuminate\Database\Eloquent\Model;
final class RewindObservabilityEvent extends Model
{
    public $timestamps=false;
    protected $table='titan_rewind_observability_events';
    protected $fillable=['tenant_company_id','trace_id','correlation_id','causation_id','kind','name','level','value','unit','status','duration_ms','attributes','occurred_at'];
    protected $casts=['tenant_company_id'=>'integer','value'=>'float','duration_ms'=>'float','attributes'=>'array','occurred_at'=>'datetime'];
}
