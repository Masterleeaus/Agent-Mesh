<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

final class CrmLeadResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'public_id' => $this->public_id,
            'customer_unification_id' => $this->customer_unification_id,
            'name' => $this->name,
            'email' => $this->email,
            'phone' => $this->phone,
            'company_name' => $this->company_name,
            'status' => $this->status,
            'source' => $this->source,
            'owner_user_id' => $this->owner_user_id,
            'priority' => $this->priority,
            'follow_up_at' => $this->follow_up_at,
            'converted_at' => $this->converted_at,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
