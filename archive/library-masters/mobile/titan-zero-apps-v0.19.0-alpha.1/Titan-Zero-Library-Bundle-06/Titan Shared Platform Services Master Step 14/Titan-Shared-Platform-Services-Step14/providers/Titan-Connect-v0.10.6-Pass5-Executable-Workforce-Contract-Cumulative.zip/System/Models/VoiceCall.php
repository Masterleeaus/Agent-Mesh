<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

final class VoiceCall extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use HasUuids;

    protected $table = 'ext_titan_connect_voice_calls';
    protected $fillable = ['uuid', 'company_id', 'channel_connection_id', 'external_thread_id', 'conversation_id', 'actor_id', 'provider', 'direction', 'status', 'external_session_id', 'started_at', 'ended_at', 'duration_seconds', 'metadata'];
    protected $casts = ['started_at' => 'datetime', 'ended_at' => 'datetime', 'metadata' => 'array'];

    public function uniqueIds(): array { return ['uuid']; }
    public function connection(): BelongsTo { return $this->belongsTo(ChannelConnection::class, 'channel_connection_id'); }
    public function externalThread(): BelongsTo { return $this->belongsTo(ExternalThread::class, 'external_thread_id'); }
    public function conversation(): BelongsTo { return $this->belongsTo(\App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation::class, 'conversation_id'); }
    public function transcripts(): HasMany { return $this->hasMany(VoiceTranscript::class, 'voice_call_id')->orderBy('created_at'); }
    public function getRouteKeyName(): string { return 'uuid'; }

}
