<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Artifacts;
use App\Extensions\TitanRewind\System\Replay\RewindArtifactResolverRegistry;
use Illuminate\Contracts\Container\Container;
final class RewindHostArtifactDiscovery
{
 public const TAG='titan.rewind.artifact-resolvers';
 public function __construct(private Container $app,private RewindArtifactResolverRegistry $registry){}
 public function discover(): array
 {
  if(!method_exists($this->app,'tagged'))return ['available'=>false,'discovered'=>0,'kinds'=>[]];
  $count=0;$kinds=[];foreach($this->app->tagged(self::TAG) as $resolver){if(!is_object($resolver))continue;$wrapped=new RewindHostArtifactResolver($resolver);$kind=$wrapped->kind();if(!$this->registry->has($kind)){$this->registry->register($wrapped);$count++;}$kinds[]=$kind;}sort($kinds,SORT_STRING);return ['available'=>true,'discovered'=>$count,'kinds'=>array_values(array_unique($kinds))];
 }
}
