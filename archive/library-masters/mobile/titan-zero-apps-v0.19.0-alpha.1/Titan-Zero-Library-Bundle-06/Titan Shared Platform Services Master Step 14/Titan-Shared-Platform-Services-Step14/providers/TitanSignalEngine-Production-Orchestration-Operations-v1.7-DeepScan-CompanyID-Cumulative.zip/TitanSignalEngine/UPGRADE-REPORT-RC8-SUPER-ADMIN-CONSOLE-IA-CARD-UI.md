# Titan Signal Engine v0.20.0-rc.8 — Super Admin Console Information Architecture and Card UI

## Scope

- Replaced the overloaded single Super Admin console with one Signal Engine parent and eight child surfaces.
- Preserved all existing Signal backend contracts and governed mutation paths.
- Added themed status cards, compact filtering, conditional tenant selection, registry visibility, and host diagnostics.
- Added migration 22 plus provider self-heal for real MagicAI `menus.parent_id` hierarchy.
- Kept the ordinary user sidebar free of Signal Engine navigation.

## Child surfaces

1. Overview
2. Pulse and Health
3. Events and Traces
4. Anomalies
5. Deliveries and DLQ
6. Lifecycle and Archives
7. Registries
8. Diagnostics

## Governance placement

- Event legal hold, redaction and correction: Events and Traces
- Anomaly acknowledge, suppress and resolve: Anomalies
- Dead-letter redrive: Deliveries and DLQ
- Prune preview and execution: Lifecycle and Archives
- Overview: no destructive controls

## Local verification

- PHP lint: 264/264 PASS
- Standalone suites: 27/27 PASS
- New rc.8 IA regression: PASS
- Parent/child navigation self-heal regression: PASS
- Blade compiled-cache isolation: PASS
- Installer 1.7.8 provider-load regression: PASS
- MySQL strict migration compatibility: PASS

Live Laravel/MySQL host certification remains required before production promotion.
