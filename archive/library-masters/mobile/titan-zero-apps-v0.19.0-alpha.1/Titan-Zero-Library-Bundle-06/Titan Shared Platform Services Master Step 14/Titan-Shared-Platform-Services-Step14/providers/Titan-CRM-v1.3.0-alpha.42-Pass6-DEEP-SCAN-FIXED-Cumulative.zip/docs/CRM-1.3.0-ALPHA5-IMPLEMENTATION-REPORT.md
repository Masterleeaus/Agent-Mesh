# CRM 1.3.0-alpha.5 Implementation Report

## Scope
Alpha.5 adapts the strongest WorkCore Supply donor workflows into CRM-native Titan Locker code. WorkCore architecture and tenancy are not imported.

## Implemented supply loop
`Supplier → Purchase Order → Approval → Partial/Full Goods Receipt → Locker Stock → Count/Adjustment → Transfer → Job Consumption → Pay/Bookkeeping context`

## New tables
- `crm_locker_supplier_ratings`
- `crm_locker_purchase_orders`
- `crm_locker_purchase_order_items`
- `crm_locker_goods_receipts`
- `crm_locker_goods_receipt_items`
- `crm_locker_stock_counts`
- `crm_locker_stock_count_items`
- `crm_locker_stock_transfers`
- `crm_locker_stock_transfer_items`

Existing `crm_locker_suppliers` is additively enriched with contact, tax, payment-term, currency, address and capability fields.

## New services
- `SupplyStatePolicy`
- `SupplierService`
- `PurchaseOrderService`
- `GoodsReceiptService`
- `StockCountService`
- `StockTransferWorkflowService`
- `ReorderPurchaseService`

## Stock integrity
- PO receipt locks PO/header lines before quantity updates.
- Goods receipt rejects over-receipt and duplicate PO lines.
- Transfer dispatch uses the existing reserved-stock-aware stock service, so reserved job stock cannot be transferred away.
- Transfer receipt uses a separate destination movement, preserving in-transit inventory semantics.
- Count adjustments use the immutable stock ledger and respect reservations for negative corrections.

## Out of scope for alpha.5
- FIFO/LIFO cost layers
- weighted-average recalculation engine
- batch/lot/serial expiry layers
- supplier invoice/accounts-payable ledger
- supplier payment automation
- asset depreciation

These remain appropriate for later passes.
