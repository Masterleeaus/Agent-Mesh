# Failure Modes

Missing vertical/readiness/governance gateways fail closed. Validation blockers prevent compilation. Unrouted or cyclic provisioning dependencies block planning. Risk, Governance, Autonomy or Assurance denial prevents Command Bus mutation. Post-write Signal/Rewind failure is recorded as degraded observability evidence and requires reconciliation; it must not be misreported as an unperformed mutation.
