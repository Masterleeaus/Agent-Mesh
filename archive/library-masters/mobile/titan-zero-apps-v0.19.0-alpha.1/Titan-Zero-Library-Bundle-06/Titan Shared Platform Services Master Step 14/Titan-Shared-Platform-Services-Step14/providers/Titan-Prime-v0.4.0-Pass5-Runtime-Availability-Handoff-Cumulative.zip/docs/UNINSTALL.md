# Uninstall

Uninstall removes the published Prime configuration file but retains Prime-owned durable data by default. Destructive data deletion requires a separate explicit governed policy decision; uninstall must not silently drop strategic records.
