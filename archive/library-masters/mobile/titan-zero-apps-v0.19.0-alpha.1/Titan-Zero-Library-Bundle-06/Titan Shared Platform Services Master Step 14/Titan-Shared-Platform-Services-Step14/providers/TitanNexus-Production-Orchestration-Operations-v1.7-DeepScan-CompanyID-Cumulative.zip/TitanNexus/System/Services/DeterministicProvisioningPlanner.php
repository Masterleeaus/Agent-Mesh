<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Services;

use App\Extensions\TitanNexus\System\Contracts\ProvisioningPlannerContract;
use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlan;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeDisposition;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeKind;
use App\Extensions\TitanNexus\System\Domain\SemanticDiffEntry;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use InvalidArgumentException;
use LogicException;

final class DeterministicProvisioningPlanner implements ProvisioningPlannerContract
{
    public function plan(NexusCompilation $compilation, VerticalDefinition $definition): ProvisioningPlan
    {
        $configuration = $compilation->compiledConfiguration();
        if ($configuration === null) {
            throw new LogicException('Provisioning planning requires a compiled configuration.');
        }
        if ($configuration->verticalId() !== $definition->verticalId() || $configuration->verticalVersion() !== $definition->verticalVersion()) {
            throw new InvalidArgumentException('Provisioning definition must match the compiled vertical identity.');
        }
        if ($configuration->sourceVerticalHash() !== null && !hash_equals($configuration->sourceVerticalHash(), $definition->fingerprint())) {
            throw new InvalidArgumentException('Provisioning must use the exact VerticalDefinition that produced the compiled configuration.');
        }

        $initialProvisioning = $compilation->configurationDiff() === null;
        $changes = $this->changes($compilation);
        $routes = $definition->provisioningPolicy()['routes'] ?? [];
        $specs = [];
        foreach ($changes as $change) {
            $routePath = $this->resolveRoutePath($change->path(), $routes);
            if ($routePath === null) {
                $specs[] = [
                    'change' => $change,
                    'route_path' => null,
                    'capability' => 'nexus.unrouted',
                    'route_dependencies' => [],
                    'disposition' => SemanticChangeDisposition::Blocked,
                    'reason' => 'No provisioning route owns this configuration path.',
                ];
                continue;
            }
            $route = $routes[$routePath];
            $specs[] = [
                'change' => $change,
                'route_path' => $routePath,
                'capability' => $route['capability'],
                'route_dependencies' => $route['depends_on'],
                'disposition' => $change->disposition(),
                'reason' => $change->reason(),
            ];
        }

        $provisional = [];
        $byRoute = [];
        foreach ($specs as $index => $spec) {
            /** @var SemanticDiffEntry $change */
            $change = $spec['change'];
            $operation = new ProvisioningOperation(
                $configuration->tenantCompanyId(),
                $compilation->compilationUuid(),
                $configuration->outputHash(),
                $change->path(),
                $change->kind(),
                $spec['disposition'],
                $spec['capability'],
                $spec['route_path'],
                $change->before(),
                $change->after(),
                [],
                $spec['reason'],
            );
            $provisional[$index] = $operation;
            if ($spec['route_path'] !== null) {
                $byRoute[$spec['route_path']][] = $operation->operationId();
            }
        }

        $operations = [];
        foreach ($specs as $index => $spec) {
            $base = $provisional[$index];
            $dependencyIds = [];
            $missingInitialDependency = null;
            foreach ($spec['route_dependencies'] as $dependencyRoute) {
                if ($initialProvisioning && ($byRoute[$dependencyRoute] ?? []) === []) {
                    $missingInitialDependency = $dependencyRoute;
                    continue;
                }
                foreach ($byRoute[$dependencyRoute] ?? [] as $operationId) {
                    $dependencyIds[] = $operationId;
                }
            }
            $dependencyIds = array_values(array_unique($dependencyIds));
            sort($dependencyIds, SORT_STRING);
            $disposition = $base->disposition();
            $reason = $base->reason();
            if ($missingInitialDependency !== null) {
                $disposition = SemanticChangeDisposition::Blocked;
                $reason = 'Initial provisioning requires route ' . $missingInitialDependency . ' to be present in the compiled desired state.';
            }
            $operations[] = new ProvisioningOperation(
                $base->tenantCompanyId(),
                $base->compilationUuid(),
                $base->proposedOutputHash(),
                $base->path(),
                $base->kind(),
                $disposition,
                $base->capability(),
                $base->routePath(),
                $base->before(),
                $base->after(),
                $dependencyIds,
                $reason,
            );
        }
        $operations = $this->topologicalSort($operations);

        return new ProvisioningPlan(
            $configuration->tenantCompanyId(),
            $compilation->compilationUuid(),
            $configuration->outputHash(),
            $compilation->configurationDiff()?->fingerprint(),
            $operations,
        );
    }

    /** @return list<SemanticDiffEntry> */
    private function changes(NexusCompilation $compilation): array
    {
        $diff = $compilation->configurationDiff();
        if ($diff !== null) {
            return array_values(array_filter(
                $diff->entries(),
                static fn (SemanticDiffEntry $entry): bool => $entry->kind() !== SemanticChangeKind::Unchanged,
            ));
        }
        $configuration = $compilation->compiledConfiguration();
        $sections = $configuration?->sections() ?? [];
        $keys = array_keys($sections);
        sort($keys, SORT_STRING);
        $changes = [];
        foreach ($keys as $key) {
            $changes[] = new SemanticDiffEntry(
                'sections.' . $key,
                SemanticChangeKind::Add,
                SemanticChangeDisposition::Apply,
                null,
                $sections[$key],
                null,
            );
        }
        return $changes;
    }

    /** @param array<string, array{capability:string,depends_on:list<string>}> $routes */
    private function resolveRoutePath(string $path, array $routes): ?string
    {
        $matches = [];
        foreach (array_keys($routes) as $routePath) {
            if ($path === $routePath || str_starts_with($path, $routePath . '.')) {
                $matches[] = $routePath;
            }
        }
        if ($matches === []) {
            return null;
        }
        usort($matches, static fn (string $a, string $b): int => strlen($b) <=> strlen($a) ?: strcmp($a, $b));
        return $matches[0];
    }

    /** @param list<ProvisioningOperation> $operations @return list<ProvisioningOperation> */
    private function topologicalSort(array $operations): array
    {
        $byId = [];
        $incoming = [];
        $dependents = [];
        foreach ($operations as $operation) {
            $id = $operation->operationId();
            $byId[$id] = $operation;
            $incoming[$id] = count($operation->dependsOnOperationIds());
            foreach ($operation->dependsOnOperationIds() as $dependency) {
                $dependents[$dependency][] = $id;
            }
        }
        $ready = array_keys(array_filter($incoming, static fn (int $count): bool => $count === 0));
        usort($ready, fn (string $a, string $b): int => $this->compareOperations($byId[$a], $byId[$b]));
        $sorted = [];
        while ($ready !== []) {
            $id = array_shift($ready);
            $sorted[] = $byId[$id];
            foreach ($dependents[$id] ?? [] as $dependent) {
                $incoming[$dependent]--;
                if ($incoming[$dependent] === 0) {
                    $ready[] = $dependent;
                    usort($ready, fn (string $a, string $b): int => $this->compareOperations($byId[$a], $byId[$b]));
                }
            }
        }
        if (count($sorted) !== count($operations)) {
            throw new LogicException('Provisioning operation dependencies contain a cycle.');
        }
        return $sorted;
    }

    private function compareOperations(ProvisioningOperation $a, ProvisioningOperation $b): int
    {
        return strcmp($a->path(), $b->path()) ?: strcmp($a->operationId(), $b->operationId());
    }
}
