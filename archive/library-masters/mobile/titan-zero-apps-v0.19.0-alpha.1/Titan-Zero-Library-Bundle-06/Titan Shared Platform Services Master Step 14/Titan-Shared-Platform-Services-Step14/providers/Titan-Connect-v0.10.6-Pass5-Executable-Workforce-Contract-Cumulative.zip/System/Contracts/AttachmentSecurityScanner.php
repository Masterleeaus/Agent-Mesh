<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

interface AttachmentSecurityScanner
{
    /** Return clean, pending, or rejected. */
    public function scanMetadata(int $companyId, array $metadata): string;
}
