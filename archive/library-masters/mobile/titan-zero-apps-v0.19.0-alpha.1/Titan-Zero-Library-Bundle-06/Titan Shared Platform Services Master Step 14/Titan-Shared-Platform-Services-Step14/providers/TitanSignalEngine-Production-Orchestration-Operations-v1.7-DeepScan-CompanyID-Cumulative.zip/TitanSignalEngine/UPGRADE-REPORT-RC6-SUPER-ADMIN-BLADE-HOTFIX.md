# Titan Signal Engine v0.20.0-rc.6 — Super Admin Placement & MagicAI Blade Layout Hotfix

## Live-host evidence

- rc.5 installed successfully on Installer 1.7.8.
- `Signal & Pulse` appeared in the ordinary user sidebar.
- Super Admin placement was not the effective visible surface.
- Opening the view failed with `Unable to locate a class or view for component [layouts.app]`.

## Correction

Signal Engine operational controls are platform infrastructure. rc.6 registers only the Super Admin navigation contribution, deletes the legacy rc.5 user menu row, repairs `titan_signal_engine_admin` at order 995, and uses the Website1408-compatible extension marker. Both Blade views now extend `panel.layout.app`, matching the real MagicAI 10.91 host.

The tenant read-only Pulse route remains internally available but is no longer a sidebar contribution.
