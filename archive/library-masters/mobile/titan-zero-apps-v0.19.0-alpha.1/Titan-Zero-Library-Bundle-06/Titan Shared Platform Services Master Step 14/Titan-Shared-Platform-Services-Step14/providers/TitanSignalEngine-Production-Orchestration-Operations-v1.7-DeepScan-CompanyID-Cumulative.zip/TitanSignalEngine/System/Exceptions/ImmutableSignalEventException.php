<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Exceptions;

use RuntimeException;

final class ImmutableSignalEventException extends RuntimeException
{
}
