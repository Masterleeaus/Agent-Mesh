<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use Illuminate\Database\Eloquent\Builder;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

final class OperatorInboxService
{
    public function __construct(private readonly WorkCoreAuthorizationGateway $workCore) {}

    /** @return array<int,array<string,mixed>> */
    public function search(int $companyId, int $actorId, array $filters = []): array
    {
        $limit = min(100, max(1, (int) ($filters['limit'] ?? 50)));
        $query = ExternalThread::query()
            ->forCompany($companyId)
            ->whereHas('connection.members', static fn (Builder $q): Builder => $q
                ->where('company_id', $companyId)
                ->where('user_id', $actorId)
                ->whereNull('left_at'))
            ->with([
                'connection:id,uuid,company_id,provider,display_name,status',
                'latestMessage',
                'readStates' => static fn ($q) => $q->where('company_id', $companyId)->where('user_id', $actorId),
                'tags:id,uuid,company_id,name,color,background_color',
                'contact',
            ]);

        if (($provider = trim((string) ($filters['provider'] ?? ''))) !== '') {
            $query->where('provider', $provider);
        }
        if (($status = trim((string) ($filters['status'] ?? ''))) !== '') {
            $query->where('status', $status);
        }
        if (isset($filters['assigned_user_id']) && (int) $filters['assigned_user_id'] > 0) {
            $query->where('assigned_user_id', (int) $filters['assigned_user_id']);
        }
        if (! empty($filters['unassigned'])) {
            $query->whereNull('assigned_user_id');
        }
        if (($priority = trim((string) ($filters['priority'] ?? ''))) !== '') {
            $query->where('priority', $priority);
        }
        if (($search = trim((string) ($filters['search'] ?? ''))) !== '') {
            $query->where(function (Builder $q) use ($search, $companyId): void {
                $q->where('display_name', 'like', '%'.$search.'%')
                    ->orWhere('external_contact_ref', 'like', '%'.$search.'%')
                    ->orWhereHas('messages', static fn (Builder $m): Builder => $m
                        ->where('company_id', $companyId)
                        ->where('body', 'like', '%'.$search.'%'));
            });
        }
        if (($tagId = (int) ($filters['tag_id'] ?? 0)) > 0) {
            $query->whereHas('tags', static fn (Builder $q): Builder => $q->where('ext_titan_connect_contact_tags.id', $tagId)->where('ext_titan_connect_contact_tags.company_id', $companyId));
        }
        if (($from = trim((string) ($filters['from'] ?? ''))) !== '') {
            $query->where('last_message_at', '>=', $from);
        }
        if (($to = trim((string) ($filters['to'] ?? ''))) !== '') {
            $query->where('last_message_at', '<=', $to);
        }

        $sort = strtolower((string) ($filters['sort'] ?? 'newest'));
        $query->orderByDesc('pinned_rank');
        $sort === 'oldest' ? $query->orderBy('last_message_at') : $query->orderByDesc('last_message_at');

        $threads = $query->limit($limit * (! empty($filters['unread']) ? 3 : 1))->get();
        $rows = [];
        foreach ($threads as $thread) {
            if (! $this->canAccessLinked($companyId, $actorId, $thread->linked_entity_type, $thread->linked_entity_id)) continue;
            $handoffState = (string) data_get($thread->metadata, 'handoff_state', 'ai');
            if (($requestedHandoff = trim((string) ($filters['handoff_state'] ?? ''))) !== '' && $handoffState !== $requestedHandoff) {
                continue;
            }
            $read = $thread->readStates->first();
            $unread = $thread->messages()
                ->where('company_id', $companyId)
                ->where('direction', 'inbound')
                ->when($read?->last_read_at, fn (Builder $q, $at): Builder => $q->where('created_at', '>', $at))
                ->count();
            if (! empty($filters['unread']) && $unread === 0) {
                continue;
            }
            $latest = $thread->latestMessage;
            $rows[] = [
                'uuid' => (string) $thread->uuid,
                'provider' => (string) $thread->provider,
                'connection_uuid' => (string) $thread->connection?->uuid,
                'connection_name' => $thread->connection?->display_name,
                'display_name' => $thread->display_name ?: $thread->contact?->display_name ?: $thread->external_contact_ref,
                'external_contact_ref' => $thread->external_contact_ref,
                'status' => $thread->status,
                'assigned_user_id' => $thread->assigned_user_id === null ? null : (int) $thread->assigned_user_id,
                'pinned_rank' => (int) $thread->pinned_rank,
                'color' => $thread->color,
                'priority' => $thread->priority,
                'handoff_state' => $handoffState,
                'preview' => $latest?->body,
                'last_message_at' => $thread->last_message_at?->toIso8601String(),
                'unread_count' => $unread,
                'tags' => $thread->tags->map(fn ($tag) => ['id' => (int) $tag->id, 'uuid' => $tag->uuid, 'name' => $tag->name, 'color' => $tag->color, 'background_color' => $tag->background_color])->values()->all(),
                'contact' => $thread->contact ? [
                    'uuid' => $thread->contact->uuid,
                    'display_name' => $thread->contact->display_name,
                    'avatar' => $thread->contact->avatar,
                    'email' => $thread->contact->email,
                    'phone' => $thread->contact->phone,
                    'country' => $thread->contact->country,
                    'ip_address' => $thread->contact->ip_address,
                    'metadata' => $thread->contact->metadata,
                ] : null,
            ];
            if (count($rows) >= $limit) break;
        }
        return $rows;
    }

    private function canAccessLinked(int $companyId, int $actorId, mixed $type, mixed $id): bool
    {
        if ($type === null || $id === null) return true;
        try { $this->workCore->assertCanAccess($companyId, $actorId, (string) $type, (string) $id); return true; }
        catch (AccessDeniedHttpException) { return false; }
    }

    public function unreadCount(int $companyId, int $actorId): int
    {
        return array_sum(array_column($this->search($companyId, $actorId, ['limit' => 100, 'unread' => true]), 'unread_count'));
    }
}
