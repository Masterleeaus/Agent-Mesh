<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Contracts;

use App\Extensions\TitanPrime\System\Gateways\Data\EngineAvailability;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayRequest;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;

interface EngineBridgeContract
{
    public function dispatch(EngineGatewayRequest $request): EngineGatewayResult;

    public function availability(EngineKey $engine): EngineAvailability;
}
