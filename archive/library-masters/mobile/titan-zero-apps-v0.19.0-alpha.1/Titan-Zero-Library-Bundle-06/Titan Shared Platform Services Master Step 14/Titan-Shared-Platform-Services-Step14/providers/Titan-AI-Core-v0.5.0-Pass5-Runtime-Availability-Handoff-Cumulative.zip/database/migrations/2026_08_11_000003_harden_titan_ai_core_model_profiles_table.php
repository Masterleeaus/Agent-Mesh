<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const GLOBAL_SCOPE_HASH = 'aac2bb7efd3d5e2e49f859692a2d1abb849b52e0baff8a0194dc3122fc80410a';

    public function up(): void
    {
        if (! Schema::hasTable('titan_ai_core_model_profiles')) {
            return;
        }

        // Fresh v0.2.0 installs already have the hardened schema from 000002.
        if (Schema::hasColumn('titan_ai_core_model_profiles', 'profile_scope_key')) {
            return;
        }

        Schema::table('titan_ai_core_model_profiles', function (Blueprint $table): void {
            $table->char('profile_scope_key', 64)
                ->default(self::GLOBAL_SCOPE_HASH)
                ->after('tenant_company_id');
        });

        DB::table('titan_ai_core_model_profiles')
            ->select(['id', 'tenant_company_id'])
            ->orderBy('id')
            ->chunkById(250, static function ($rows): void {
                foreach ($rows as $row) {
                    $tenant = is_string($row->tenant_company_id ?? null) && $row->tenant_company_id !== ''
                        ? $row->tenant_company_id
                        : '__global__';

                    DB::table('titan_ai_core_model_profiles')
                        ->where('id', $row->id)
                        ->update(['profile_scope_key' => hash('sha256', $tenant)]);
                }
            });

        // v0.1.0 used this nullable, oversized composite index. Remove it when present.
        try {
            Schema::table('titan_ai_core_model_profiles', function (Blueprint $table): void {
                $table->dropUnique('taicore_model_capability_unique');
            });
        } catch (\Throwable) {
            // A partially repaired host may already have removed the old index.
        }

        Schema::table('titan_ai_core_model_profiles', function (Blueprint $table): void {
            $table->unique(
                ['profile_scope_key', 'provider', 'model', 'model_version', 'capability'],
                'taicore_model_profile_unique'
            );
        });
    }

    public function down(): void
    {
        // Do not reconstruct the unsafe v0.1.0 index. Migration rollback of the
        // extension is handled by the table-owning creation migrations.
    }
};
