<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /** @var array<string,string> */
    private array $tables = [
        'interaction_runs' => 'interaction_runs_company_idx',
        'interaction_answers' => 'interaction_answers_company_idx',
        'interaction_events' => 'interaction_events_company_idx',
        'interaction_cognitive_events' => 'interaction_cognitive_company_idx',
        'local_intelligence_memories' => 'local_memory_company_idx',
    ];

    public function up(): void
    {
        foreach ($this->tables as $tableName => $indexName) {
            if (!Schema::hasTable($tableName)) continue;
            if (!Schema::hasColumn($tableName, 'company_id')) {
                Schema::table($tableName, function (Blueprint $table) use ($indexName): void {
                    $table->string('company_id', 191)->nullable()->index($indexName);
                });
            }
            if (Schema::hasColumn($tableName, 'tenant_id')) {
                DB::table($tableName)
                    ->whereNull('company_id')
                    ->whereNotNull('tenant_id')
                    ->update(['company_id' => DB::raw('tenant_id')]);
            }
        }
    }

    public function down(): void
    {
        // Forward-only. Canonical company ownership metadata is never removed automatically.
    }
};
