# Upgrade, Rollback, Disable and Uninstall

## Installer target

Titan Time & Attendance 0.1.1 is packaged for `titan-extension-v1` and the Titan Custom Extension Manager 1.7.8 contract. The ZIP has a flat root, exact Linux-cased provider identity, dependency arrays, scoped publish metadata, extension-scoped migrations and `integrity.files` covering every packaged file except `extension.json`.

## Upgrade

Upgrades are forward-only and extension-owned. The extension never mutates canonical CRM user/job/site tables. Existing 0.1.0-alpha installations upgrade through the same migration lineage. The four base create migrations now guard existing tables with `Schema::hasTable`, while additive migrations guard columns/tables, so retained-data reinstall does not blindly recreate extension-owned schema.

Installer upgrades should use the Titan Extension Manager backup/staging/registry lifecycle. Do not manually overwrite `app/Extensions/TitanTimeAttendance` in production.

## Disable

Disable is non-destructive. `titan-time-attendance.enabled=false` prevents routes, schedules and runtime services from booting while leaving extension data intact. Pending queue jobs must be drained or stopped by the platform operator during a controlled disable.

## Rollback

Package-code rollback is owned by the Titan Extension Manager backup/upgrade lifecycle. Database migration rollback is supported structurally by `down()` on every extension migration, but destructive rollback of operational time/attendance tables should only be used when data deletion is explicitly intended. Normal code rollback should retain data and restore the previous package version.

Signal delivery uses stable `event_id`/`dedup_key` and at-least-once semantics. A worker crash can cause a stale lease to be retried; downstream Titan Signal consumers must deduplicate stable event identity.

## Uninstall

The provider uninstall hook removes only the published `titan-time-attendance.php` configuration file. Operational, attendance, audit, command receipt, Workflow and Signal outbox records are retained by default. Data purge is intentionally not performed by the extension uninstall hook.

## Reinstall after retained-data uninstall

Reinstallation is designed to tolerate retained extension tables. Base migrations skip tables that already exist; additive migrations check their own columns/tables. The package must still be installed through Titan Extension Manager so migration history and registry state remain authoritative.

## Production boundary

Live certification still requires the target Titan/MagicAI host for real MySQL migration execution, service-container boot, route/config/view caching, queue worker behavior and optional peer-engine resolution.
