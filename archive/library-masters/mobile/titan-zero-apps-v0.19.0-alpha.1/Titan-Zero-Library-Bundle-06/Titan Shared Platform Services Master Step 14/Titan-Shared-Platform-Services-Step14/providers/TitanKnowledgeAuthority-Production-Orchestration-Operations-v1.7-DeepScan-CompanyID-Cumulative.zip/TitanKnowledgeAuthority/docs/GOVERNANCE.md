# Governance
Knowledge Authority is self-governing only for knowledge authority ownership. It does not own risk, assurance, autonomy, or command execution. Authority precedence and applicability must be deterministic; LLMs may not assign authority or resolve equal-rank authority conflicts. Offline operation may never increase authority.
