<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\View\MagicAiDashboardRenderer;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\View\View;

final class AdminChannelSettingsController extends Controller
{
    public function __construct(private readonly MagicAiDashboardRenderer $dashboard)
    {
    }

    /** @var array<string,string> */
    private const PROVIDERS = [
        'whatsapp' => 'WhatsApp', 'messenger' => 'Messenger', 'instagram' => 'Instagram',
        'telegram' => 'Telegram', 'sms' => 'SMS', 'voice' => 'Voice', 'push' => 'Push / Mobile',
    ];

    public function index(Request $request): View
    {
        $this->assertAdmin($request);
        return $this->dashboard->render('titan-connect::admin.channels', ['providers' => self::PROVIDERS, 'provider' => null], __('Titan Connect'));
    }

    public function show(Request $request, string $provider): View
    {
        $this->assertAdmin($request);
        $provider = strtolower(trim($provider));
        abort_unless(array_key_exists($provider, self::PROVIDERS), 404);
        return $this->dashboard->render('titan-connect::admin.channels', ['providers' => self::PROVIDERS, 'provider' => $provider], __('Titan Connect'));
    }

    private function assertAdmin(Request $request): void
    {
        $user = $request->user();
        abort_unless($user !== null, 401);

        $allowed = false;
        if (method_exists($user, 'isAdmin')) {
            $allowed = (bool) $user->isAdmin();
        }
        $type = strtolower((string) ($user->type ?? $user->user_type ?? ''));
        $allowed = $allowed || in_array($type, ['admin', 'super_admin', 'superadmin'], true) || (bool) ($user->is_admin ?? false);
        abort_unless($allowed, 403);
    }
}
