<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Models;

use Illuminate\Database\Eloquent\Model;

final class GovernanceProjection extends Model
{
    protected $table='titan_governance_views';
    protected $guarded=[];
    protected $casts=[
        'payload'=>'array',
        'observed_at'=>'datetime',
        'expires_at'=>'datetime',
    ];
}
