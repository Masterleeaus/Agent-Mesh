<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class WebhookEvent extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    protected $table = 'ext_titan_connect_webhook_events';

    protected $fillable = [
        'company_id', 'channel_connection_id', 'provider', 'provider_event_id',
        'event_type', 'payload_hash', 'status', 'failure_reason', 'processed_at',
    ];

    protected $casts = ['processed_at' => 'datetime'];

    public function connection(): BelongsTo
    {
        return $this->belongsTo(ChannelConnection::class, 'channel_connection_id');
    }
}
