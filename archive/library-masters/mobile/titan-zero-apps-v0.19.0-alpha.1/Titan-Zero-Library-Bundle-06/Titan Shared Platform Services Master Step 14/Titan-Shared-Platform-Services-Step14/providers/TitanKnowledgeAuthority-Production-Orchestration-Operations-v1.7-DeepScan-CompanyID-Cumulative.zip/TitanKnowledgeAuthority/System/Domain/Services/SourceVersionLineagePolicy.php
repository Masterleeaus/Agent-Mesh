<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Services;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Exceptions\SourceVersionConflictException;
use InvalidArgumentException;
use OverflowException;

final class SourceVersionLineagePolicy
{
    private const MAX_SEQUENCE = 4_294_967_295;

    public function nextSequence(?int $latestSequence): int
    {
        if ($latestSequence === null) {
            return 1;
        }
        if ($latestSequence <= 0) {
            throw new InvalidArgumentException('latestSequence must be a positive integer when present.');
        }
        if ($latestSequence >= self::MAX_SEQUENCE) {
            throw new OverflowException('Knowledge source version sequence is exhausted.');
        }
        return $latestSequence + 1;
    }

    public function versionKey(int $sequence): string
    {
        if ($sequence <= 0 || $sequence > self::MAX_SEQUENCE) {
            throw new InvalidArgumentException('sequence must be between 1 and 4294967295.');
        }
        return sprintf('v%010d', $sequence);
    }

    public function assertExpectedPrevious(?int $latestVersionId, ?int $expectedPreviousVersionId): ?int
    {
        if ($latestVersionId !== null && $latestVersionId <= 0) {
            throw new InvalidArgumentException('latestVersionId must be positive when present.');
        }
        if ($expectedPreviousVersionId !== null && $expectedPreviousVersionId <= 0) {
            throw new InvalidArgumentException('expectedSupersedesVersionId must be positive when present.');
        }
        if ($expectedPreviousVersionId !== null && $latestVersionId !== $expectedPreviousVersionId) {
            throw new SourceVersionConflictException('Knowledge source changed since the caller observed its latest version.');
        }
        return $latestVersionId;
    }
}
