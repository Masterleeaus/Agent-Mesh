@extends('panel.layout.app')
@section('title', 'Titan Rewind — Assistant')

@section('content')
    <a href="#titan-rewind-content" class="sr-only focus:not-sr-only">{{ __('titan-rewind::rewind.accessibility_skip') }}</a>
    <main id="titan-rewind-content" role="main" class="container py-8 space-y-6">
        <div>
            <h1 class="text-2xl font-semibold">Titan Rewind Assistant</h1>
            <p class="text-sm opacity-70">Deterministic specialist routing over Rewind's implemented tools. This surface does not call an external AI provider and never exposes hidden chain-of-thought.</p>
        </div>
        <form method="POST" action="{{ route('dashboard.user.titan.rewind.assistant.ask') }}" class="rounded border p-4 space-y-3">
            @csrf
            <div><label class="block text-sm font-medium">Question</label><textarea name="message" rows="4" class="w-full rounded border px-3 py-2" placeholder="Why did this fail? Compare the old policy with the new one. What is the safest recovery path?" aria-label="message"></textarea></div>
            <div class="grid gap-3 md:grid-cols-2">
                <div><label class="block text-sm font-medium">Optional trace UUID</label><input name="trace_id" class="w-full rounded border px-3 py-2" aria-label="trace id"></div>
                <div><label class="block text-sm font-medium">Optional case UUID</label><input name="case_uuid" class="w-full rounded border px-3 py-2" aria-label="case uuid"></div>
            </div>
            <button class="rounded border px-4 py-2">Route request</button>
        </form>
        @if($response)
            <section class="rounded border p-4 space-y-2">
                <h2 class="text-lg font-semibold">{{ $response['specialist'] }} specialist</h2>
                <p>{{ $response['recommendation'] }}</p>
                <div class="text-sm opacity-70">Mode: {{ $response['mode'] }} · External AI called: {{ $response['external_ai_called'] ? 'yes' : 'no' }}</div>
                <div class="flex flex-wrap gap-2 mt-2">@foreach($response['tool_ids'] as $toolId)<code class="rounded border px-2 py-1">{{ $toolId }}</code>@endforeach</div>
            </section>
        @endif
        <section class="rounded border p-4">
            <h2 class="text-lg font-semibold mb-3">Available Rewind tools</h2>
            @foreach($tools as $tool)
                <div class="border-t py-3 first:border-t-0"><strong>{{ $tool['id'] }}</strong><div class="text-sm">{{ $tool['description'] }}</div><div class="text-xs opacity-70">Effect: {{ $tool['effect'] }} · Tenant: {{ $tool['tenant_context'] }} · Authoritative mutation: {{ $tool['authoritative_mutation'] ? 'yes' : 'no' }}</div></div>
            @endforeach
        </section>
    </main>
@endsection
