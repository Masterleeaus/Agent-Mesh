<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

enum SignalSeverity: string
{
    case DEBUG = 'debug';
    case INFO = 'info';
    case WARN = 'warn';
    case ERROR = 'error';
    case CRITICAL = 'critical';
    case FATAL = 'fatal';

    public function weight(): int
    {
        return match ($this) {
            self::DEBUG => 10,
            self::INFO => 20,
            self::WARN => 30,
            self::ERROR => 40,
            self::CRITICAL => 50,
            self::FATAL => 60,
        };
    }

    public static function fromName(string $severity): self
    {
        $value = self::tryFrom(strtolower(trim($severity)));
        if ($value === null) {
            throw new InvalidArgumentException('Signal severity must be one of: debug, info, warn, error, critical, fatal.');
        }

        return $value;
    }
}
