# Payslip Delivery

Payslip records are tenant and worker scoped. Access grants bind tenant, authenticated employee, payslip ID, expiry and access version. Full payslip documents and sensitive fields are not copied into Signals, Rewind, AI prompts or logs.

Payroll does not directly email or notify. Resend creates a Communications request/receipt. `pending_communications` or provider-unavailable means delivery has **not** occurred. Acknowledgement is an idempotent employee action and cannot be used to mutate payroll monetary values.
