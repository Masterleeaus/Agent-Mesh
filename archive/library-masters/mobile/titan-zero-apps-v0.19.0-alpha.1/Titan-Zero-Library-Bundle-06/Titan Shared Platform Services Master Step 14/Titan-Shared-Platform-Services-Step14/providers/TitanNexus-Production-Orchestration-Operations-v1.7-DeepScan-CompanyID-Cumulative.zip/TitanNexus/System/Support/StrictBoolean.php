<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Support;

use InvalidArgumentException;

final class StrictBoolean
{
    public static function parse(mixed $value, string $field): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) && ($value === 0 || $value === 1)) {
            return $value === 1;
        }
        if (is_string($value)) {
            $normalized = strtolower(trim($value));
            if ($normalized === 'true' || $normalized === '1') {
                return true;
            }
            if ($normalized === 'false' || $normalized === '0') {
                return false;
            }
        }
        throw new InvalidArgumentException("{$field} must be a strict boolean value.");
    }
}
