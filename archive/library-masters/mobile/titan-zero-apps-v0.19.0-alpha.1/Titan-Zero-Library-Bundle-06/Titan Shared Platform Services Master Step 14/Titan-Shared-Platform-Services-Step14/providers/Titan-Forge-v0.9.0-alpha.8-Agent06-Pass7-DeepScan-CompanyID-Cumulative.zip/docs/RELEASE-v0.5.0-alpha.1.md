# Titan Forge v0.5.0-alpha.1 — Sandbox & Validation Foundation

## Added

- bounded `SandboxWorkspace` and tenant/operation-scoped factory
- atomic safe writes and clean deterministic workspace reset
- typed `ArtifactSet` snapshot from generated output
- symlink/case-collision/path/file-count/artifact-size enforcement
- validator contract and deterministic validator registry
- local artifact-validation pipeline with fail-closed validator failures
- workspace SHA/size integrity validator
- generated-content secret scanner
- generation-manifest provenance/artifact-set validator
- unsafe generated-PHP execution-primitive scanner
- JSON syntax validator
- in-process PHP syntax validator using `TOKEN_PARSE`
- automatic generated -> validating -> validated / validation_failed runtime flow
- persisted validation runs and findings
- typed Risk declaration
- Risk and Shield adapter contracts with fail-closed unavailable bindings

## Preserved

- deterministic six-role Solo workforce scaffold
- Workforce authority boundary
- 6/15/30/68 entitlement limits with non-Solo rosters fail-closed
- tenant + idempotency build boundary
- active `titan-forge` queue
- no direct deployment authority
- no direct AI provider calls
- no inter-engine public build-status webhooks

## Deferred

- verified live Titan Risk adapter
- verified live Titan Shield adapter
- Model Council escalation
- release-candidate governance state machine
- Command Bus release execution
- Titan Signal runtime adapter
- generalized extension/PWA/workflow generators
