# CRM alpha.32 — Read Architecture & Search v2

## Boundary
CRM authoritative tables remain the write source of truth. CQRS/search state is derivative, tenant-scoped, rebuildable, and non-authoritative.

## Projection contract
Every definition declares projection version, schema version, definition hash, allowed filters/search fields, and freshness SLA. Version changes create a new projection namespace rather than mutating older payload contracts in place.

## Rebuilds and failures
Full rebuild remains supported. Incremental rebuild uses `crm_read_projection_rebuild_checkpoints` with a durable numeric cursor and bounded batch size. Projection exceptions are stored in `crm_read_projection_dead_letters`; they do not block authoritative Titan Signal delivery and may be replayed independently.

## Search
`CrmSearchPort` is the stable adapter boundary. The default SQL implementation searches only `crm_read_projection_records`; deployments may bind an OpenSearch/Elasticsearch/semantic adapter without changing CRM domain code.

## AI
`crm.ai.context.read` is now projection-only and read-model v4.0. There is no live OLTP compatibility path. Unsupported resources fail closed until a normalized projection exists.
