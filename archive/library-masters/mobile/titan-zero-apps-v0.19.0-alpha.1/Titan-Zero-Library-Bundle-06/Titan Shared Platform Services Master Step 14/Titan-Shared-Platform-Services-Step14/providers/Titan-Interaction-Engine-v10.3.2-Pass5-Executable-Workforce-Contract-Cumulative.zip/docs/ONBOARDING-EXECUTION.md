# Onboarding Execution

Execution is server-side and dependency-aware. Each `OnboardingAction` records provider, canonical capability, group, risk, approval requirement, payload, explicit dependencies, execution order, readiness requirements, offline mode and idempotency metadata.

The executor rebuilds current actor context, validates company ownership, checks dependencies, validates stored scoped approval, checks readiness/availability, dispatches through the governed CommandBus/CapabilityRouter, records an idempotent execution ledger, and preserves state on provider failure.
