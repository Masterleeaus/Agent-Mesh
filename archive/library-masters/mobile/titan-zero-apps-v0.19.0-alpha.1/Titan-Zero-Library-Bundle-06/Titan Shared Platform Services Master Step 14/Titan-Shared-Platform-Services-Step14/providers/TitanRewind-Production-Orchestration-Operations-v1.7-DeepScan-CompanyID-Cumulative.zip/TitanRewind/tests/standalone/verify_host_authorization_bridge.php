<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
require_once $root . '/System/Security/RewindPermissions.php';
require_once $root . '/System/Security/RewindAuthorization.php';

use App\Extensions\TitanRewind\System\Security\RewindAuthorization;
use App\Extensions\TitanRewind\System\Security\RewindPermissions;

$checks = 0;
$failures = [];
$assert = static function (bool $condition, string $message) use (&$checks, &$failures): void {
    ++$checks;
    if (!$condition) { $failures[] = $message; fwrite(STDERR, "FAIL: {$message}\n"); }
};

final class SuperAdminActor {
    public function isSuperAdmin(): bool { return true; }
    public function can(string $permission): bool { return false; }
}
final class ExplicitCanActor {
    public function can(string $permission): bool { return $permission === RewindPermissions::EVIDENCE_EXPORT; }
}
final class ExplicitHostPermissionActor {
    public function checkPermission(string $permission): bool { return $permission === RewindPermissions::RECOVERY_PROPOSE; }
}
final class ExplicitSpatieActor {
    public function hasPermissionTo(string $permission): bool { return $permission === RewindPermissions::LEGAL_HOLD_MANAGE; }
}
final class DelegatedAdminActor {
    public function isSuperAdmin(): bool { return false; }
    public function isAdmin(): bool { return true; }
    public function can(string $permission): bool { return false; }
    public function checkPermission(string $permission): bool { return false; }
}
final class OrdinaryActor {
    public function isSuperAdmin(): bool { return false; }
    public function isAdmin(): bool { return false; }
    public function can(string $permission): bool { return false; }
    public function checkPermission(string $permission): bool { return false; }
}

$auth = new RewindAuthorization();

foreach (RewindPermissions::all() as $permission) {
    $allowed = true;
    try { $auth->assertActorPermission(new SuperAdminActor(), $permission); } catch (RuntimeException) { $allowed = false; }
    $assert($allowed, "Super Admin bypasses {$permission}");
}

foreach ([
    [new ExplicitCanActor(), RewindPermissions::EVIDENCE_EXPORT, 'Laravel can() explicit permission'],
    [new ExplicitHostPermissionActor(), RewindPermissions::RECOVERY_PROPOSE, 'MagicAI checkPermission() explicit permission'],
    [new ExplicitSpatieActor(), RewindPermissions::LEGAL_HOLD_MANAGE, 'Spatie hasPermissionTo() explicit permission'],
] as [$actor, $permission, $label]) {
    $allowed = true;
    try { $auth->assertActorPermission($actor, $permission); } catch (RuntimeException) { $allowed = false; }
    $assert($allowed, $label . ' is accepted');
}

foreach (RewindPermissions::delegatedAdminFallback() as $permission) {
    $allowed = true;
    try { $auth->assertActorPermission(new DelegatedAdminActor(), $permission); } catch (RuntimeException) { $allowed = false; }
    $assert($allowed, "delegated admin fallback allows {$permission}");
}

foreach ([
    RewindPermissions::EVIDENCE_GENERATE,
    RewindPermissions::EVIDENCE_EXPORT,
    RewindPermissions::RECOVERY_PROPOSE,
    RewindPermissions::RECOVERY_REQUEST_APPROVAL,
    RewindPermissions::LEGAL_HOLD_MANAGE,
    RewindPermissions::ADMIN,
] as $permission) {
    $denied = false;
    try { $auth->assertActorPermission(new DelegatedAdminActor(), $permission); } catch (RuntimeException) { $denied = true; }
    $assert($denied, "delegated admin does not implicitly receive sensitive {$permission}");
}

$denied = false;
try { $auth->assertActorPermission(new OrdinaryActor(), RewindPermissions::TRACE_VIEW); } catch (RuntimeException) { $denied = true; }
$assert($denied, 'ordinary actor without explicit permission remains denied');

$denied = false;
try { $auth->assertActorPermission(null, RewindPermissions::TRACE_VIEW); } catch (RuntimeException) { $denied = true; }
$assert($denied, 'null actor remains denied');

$denied = false;
try { $auth->assertActorPermission(new SuperAdminActor(), ''); } catch (RuntimeException) { $denied = true; }
$assert($denied, 'blank permission remains denied even for Super Admin');

if ($failures !== []) {
    fwrite(STDERR, sprintf("\n%d/%d checks failed.\n", count($failures), $checks));
    exit(1);
}
printf("PASS: %d/%d host authorization bridge checks passed.\n", $checks, $checks);
