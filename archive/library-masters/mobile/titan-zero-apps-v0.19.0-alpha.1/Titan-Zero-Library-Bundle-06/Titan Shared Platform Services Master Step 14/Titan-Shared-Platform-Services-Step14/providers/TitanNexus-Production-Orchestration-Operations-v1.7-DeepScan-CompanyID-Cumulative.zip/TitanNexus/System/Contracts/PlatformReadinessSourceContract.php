<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Contracts;

interface PlatformReadinessSourceContract
{
    /**
     * @param list<string> $capabilities
     * @return array<string, bool>
     */
    public function check(array $capabilities): array;
}
