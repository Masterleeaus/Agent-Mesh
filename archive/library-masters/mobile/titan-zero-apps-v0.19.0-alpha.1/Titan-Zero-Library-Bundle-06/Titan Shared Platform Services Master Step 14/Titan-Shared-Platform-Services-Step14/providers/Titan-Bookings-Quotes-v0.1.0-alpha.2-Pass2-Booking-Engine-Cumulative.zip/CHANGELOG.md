# Changelog

## 0.1.0-alpha.2 — Pass 2 Canonical Booking Engine
- Added canonical booking aggregate, requested windows and append-only lifecycle events.
- Added optimistic concurrency and company-scoped idempotency.
- Added explicit fail-closed BookingModule legacy mapper.
- Kept scheduling/dispatch/invoice/payment ownership outside this extension.


## 0.1.0-alpha.1 — Pass 1 Foundation
- Established Titan Bookings & Quotes extension shell and authority boundaries.
- Inventoried nine donor areas and recorded keep/adapt/retire decisions.
- Added typed booking, quote, CRM-reference, scheduling, invoice, payment and governance ports.
- Added Workforce Manifest 2.0 with four Front Office roles and read-only foundation tools.
