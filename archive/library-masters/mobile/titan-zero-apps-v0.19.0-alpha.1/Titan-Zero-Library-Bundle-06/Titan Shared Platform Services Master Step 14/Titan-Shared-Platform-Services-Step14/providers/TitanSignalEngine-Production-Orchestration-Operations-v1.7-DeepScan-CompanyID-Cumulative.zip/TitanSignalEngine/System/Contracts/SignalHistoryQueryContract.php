<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalHistoryRecord;

interface SignalHistoryQueryContract
{
    public function find(string $eventId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT): ?SignalHistoryRecord;

    /** @return list<SignalHistoryRecord> */
    public function byTrace(string $traceId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array;

    /** @return list<SignalHistoryRecord> */
    public function byCorrelation(string $correlationId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array;

    /** @return list<SignalHistoryRecord> */
    public function childrenOf(string $parentEventId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array;

    /** @return list<SignalHistoryRecord> */
    public function byRootCausation(string $rootCausationId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array;
}
