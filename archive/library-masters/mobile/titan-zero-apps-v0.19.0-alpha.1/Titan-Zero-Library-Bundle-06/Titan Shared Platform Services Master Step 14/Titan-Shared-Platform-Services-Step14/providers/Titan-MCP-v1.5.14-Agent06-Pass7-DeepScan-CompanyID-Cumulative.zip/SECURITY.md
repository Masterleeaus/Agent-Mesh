# Security

Titan MCP is a privileged system extension. Production access must use authenticated API identities and least-privilege permissions. Destructive capabilities are disabled by default and are separate from ordinary write capabilities.

Repository access denies secrets, `.env`, keys, vendor/node_modules, runtime sessions, logs and Titan MCP recovery storage. Raw SQL is disabled by default and may only use dedicated query-only database connections. Database and repository mutations require verified backups before execution.

Audit records are secret-redacted and hash chained. A broken audit chain blocks new mutation work. Recovery storage must be encrypted at rest before production writes are enabled. Never expose the MCP endpoint to untrusted origins.
