<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitScope;
use InvalidArgumentException;

final readonly class RiskCircuitKey
{
    public function __construct(
        public int|string $tenantCompanyId,
        public RiskCircuitScope $scope,
        public ?string $capability = null,
    ) {
        RiskFieldConstraints::required('tenantCompanyId', $this->tenantCompanyId, 64);
        RiskFieldConstraints::text('capability', $this->capability, 160);
        if ($scope === RiskCircuitScope::TENANT_CAPABILITY && ($capability === null || trim($capability) === '')) {
            throw new InvalidArgumentException('capability is required for TENANT_CAPABILITY Risk circuits.');
        }
        if ($scope === RiskCircuitScope::TENANT && $capability !== null) {
            throw new InvalidArgumentException('TENANT Risk circuits must not carry a capability.');
        }
    }

    public function capabilityKey(): string
    {
        return $this->scope === RiskCircuitScope::TENANT ? '__tenant__' : (string) $this->capability;
    }

    public function storageKey(): string
    {
        return (string) $this->tenantCompanyId . '|' . $this->scope->value . '|' . $this->capabilityKey();
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'tenant_company_id' => $this->tenantCompanyId,
            'scope' => $this->scope->value,
            'capability' => $this->capability,
        ];
    }
}
