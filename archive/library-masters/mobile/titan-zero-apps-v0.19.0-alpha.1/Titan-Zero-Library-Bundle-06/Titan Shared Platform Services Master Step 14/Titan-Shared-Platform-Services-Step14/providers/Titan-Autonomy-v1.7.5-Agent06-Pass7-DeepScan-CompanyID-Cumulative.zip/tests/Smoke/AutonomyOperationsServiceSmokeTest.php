<?php

declare(strict_types=1);

spl_autoload_register(function(string $class):void{$prefix='App\\Extensions\\TitanAutonomy\\';if(!str_starts_with($class,$prefix))return;$path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($prefix))).'.php';if(is_file($path))require_once $path;});
use App\Extensions\TitanAutonomy\System\Contracts\{AutonomyQueryContract,OperationsQueryContract,OperationsReviewStoreContract};
use App\Extensions\TitanAutonomy\System\Services\{AutonomyOperationsService,OperationsStatusClassifier};
$query=new class implements OperationsQueryContract{public array $rows=[];public function receipts(int $t,array $f=[],int $l=100):array{return array_values(array_filter($this->rows,fn($r)=>($f['capability']??'')===''||($r['capability']??'')===$f['capability']));}public function receipt(int $t,string $c):?array{foreach($this->rows as $r)if(($r['correlation_id']??'')===$c&&(int)$r['tenant_company_id']===$t)return$r;return null;}public function feedback(int $t,string $p,int $l=100):array{return[];}};
$query->rows=[['public_id'=>'E1','tenant_company_id'=>42,'capability'=>'crm.invoice.issue','workflow_key'=>'job','correlation_id'=>'c1','observation_status'=>'observing','matures_at'=>gmdate('Y-m-d H:i:s',time()-1),'created_at'=>'2026-08-11 01:00:00'],['public_id'=>'E2','tenant_company_id'=>42,'capability'=>'crm.customer.create','workflow_key'=>'','correlation_id'=>'c2','observation_status'=>'finalized','final_label'=>'correct','created_at'=>'2026-08-11 02:00:00']];
$reviews=new class implements OperationsReviewStoreContract{public function append(array $r):string{return'R';}public function forReceipt(int $t,string $p,int $l=100):array{return[];}};
$autonomy=new class implements AutonomyQueryContract{public function capabilityStates(int $t):array{return[];}public function capabilityState(int $t,string $c,string $w):?array{return['tenant_company_id'=>$t,'capability'=>$c,'workflow_key'=>$w];}public function learningEvents(int $t,?string $c=null,?string $w=null,int $l=1000):array{return[];}public function learningPreferences(int $t,?int $u=null):array{return[];}public function learningSettings(int $t):array{return[];}public function tenantPolicy(int $t):?array{return null;}public function platformPolicy():?array{return null;}public function handshakes(int $t,?string $c=null,?string $w=null,int $l=100):array{return[];}public function regressions(int $t,?string $c=null,?string $w=null,int $l=100):array{return[];}};
$svc=new AutonomyOperationsService($query,$reviews,$autonomy,new OperationsStatusClassifier());
$q=$svc->queue(42,['status'=>'attention','capability'=>'']);
if(($q['summary']['total']??0)!==2||count($q['items'])!==1||($q['items'][0]['correlation_id']??'')!=='c1')throw new RuntimeException('Operations queue must count all receipts but show only requested attention projection.');
$d=$svc->detail(42,'c1');if(($d['operations']['status']??'')!=='due_for_reconciliation')throw new RuntimeException('Operations detail must classify canonical tenant receipt.');

echo "OK: AutonomyOperationsServiceSmokeTest\n";
