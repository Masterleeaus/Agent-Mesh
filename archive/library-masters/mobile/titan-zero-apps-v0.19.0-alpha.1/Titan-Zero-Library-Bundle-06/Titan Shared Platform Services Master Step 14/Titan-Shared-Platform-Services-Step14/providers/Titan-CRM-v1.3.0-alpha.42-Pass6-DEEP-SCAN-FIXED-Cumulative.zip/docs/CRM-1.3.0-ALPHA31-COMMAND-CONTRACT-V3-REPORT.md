# CRM Core alpha.31 — Command Contract v3 Report

## Authority
CRM Core remains the authoritative customer/commercial domain. Command Contract v3 changes mutation governance only; it does not reclaim Field, Locker, Pay, Ledger, Autonomy, planning or learning ownership.

## Command envelope
Every governed write is represented by a v3 envelope with a command ID, tenant, accountable actor, capability, source, trace/correlation/causation IDs, idempotency key and an expected entity version whenever a versioned target can be resolved.

## Receipt
`crm.command-receipt.v3` persists primary and affected resources, before/after state hashes, entity versions, invariant results, external-effect references, compensation state, remediation guidance, a Rewind reference and the exact transactional Signal outbox public ID.

## Write-surface audit
`php artisan crm:governance:audit-writes` statically audits HTTP POST/PUT/PATCH/DELETE routes and console mutation surfaces. A surface must use `CrmHumanMutationGateway` / `CrmCommandBusGateway` or appear in a small explicit non-business exception registry. `crm:production-check` blocks if the audit fails.

## Closed bypasses
Privacy requests, retention policy updates and scheduled destructive retention execution now enter through governed capabilities. Retention scheduler commands establish a trusted tenant/actor context from the stored policy and submit `crm.retention.execute` to Command Bus rather than mutating business records directly.
