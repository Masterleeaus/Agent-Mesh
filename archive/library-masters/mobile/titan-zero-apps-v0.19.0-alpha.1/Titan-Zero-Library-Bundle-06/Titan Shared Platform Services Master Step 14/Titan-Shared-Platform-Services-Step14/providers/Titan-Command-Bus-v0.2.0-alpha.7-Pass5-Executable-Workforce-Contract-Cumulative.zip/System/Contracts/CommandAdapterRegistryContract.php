<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Contracts;

interface CommandAdapterRegistryContract
{
    public function register(CommandAdapterContract $adapter): void;
    public function has(string $capability): bool;
    public function forCapability(string $capability): ?CommandAdapterContract;
    public function count(): int;
}
