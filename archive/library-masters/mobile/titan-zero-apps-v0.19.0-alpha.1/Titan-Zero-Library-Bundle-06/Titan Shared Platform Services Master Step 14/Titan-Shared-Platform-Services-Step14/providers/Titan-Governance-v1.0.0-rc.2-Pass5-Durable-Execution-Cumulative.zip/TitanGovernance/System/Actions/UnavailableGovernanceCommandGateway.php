<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Actions;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceCommandGatewayContract;

final class UnavailableGovernanceCommandGateway implements GovernanceCommandGatewayContract
{
    public function health(): array
    {
        return ['status' => 'UNAVAILABLE', 'reason_code' => 'COMMAND_BUS_GATEWAY_UNBOUND'];
    }

    public function dispatch(array $command): array
    {
        return [
            'schema_version' => '1.0',
            'status' => 'UNAVAILABLE',
            'reason_code' => 'COMMAND_BUS_UNAVAILABLE',
            'operation_id' => $command['operation_id'] ?? null,
        ];
    }
}
