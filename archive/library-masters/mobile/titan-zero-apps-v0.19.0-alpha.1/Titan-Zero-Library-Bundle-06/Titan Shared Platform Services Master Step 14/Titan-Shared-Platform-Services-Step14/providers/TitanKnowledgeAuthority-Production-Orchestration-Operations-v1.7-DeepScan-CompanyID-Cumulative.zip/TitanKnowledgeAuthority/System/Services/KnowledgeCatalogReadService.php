<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Services;

use App\Extensions\TitanKnowledgeAuthority\System\Contracts\KnowledgeAccessContextResolverContract;
use App\Extensions\TitanKnowledgeAuthority\System\Contracts\KnowledgeCatalogReadContract;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Models\KnowledgeSource;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Models\KnowledgeSourceVersion;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories\KnowledgeSourceRepositoryContract;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories\KnowledgeSourceVersionRepositoryContract;

final class KnowledgeCatalogReadService implements KnowledgeCatalogReadContract
{
    public function __construct(
        private readonly KnowledgeAccessContextResolverContract $contextResolver,
        private readonly KnowledgeSourceRepositoryContract $sources,
        private readonly KnowledgeSourceVersionRepositoryContract $versions,
    ) {
    }

    public function sourceMetadata(string $sourceKey): ?array
    {
        $source = $this->sources->findVisibleByKey($this->contextResolver->current(), $sourceKey);

        return $source === null ? null : $this->mapSource($source);
    }

    public function versionMetadata(int $versionId): ?array
    {
        $version = $this->versions->findVisibleById($this->contextResolver->current(), $versionId);

        if ($version === null) {
            return null;
        }

        return [
            'id' => $version->getKey(),
            'source_id' => $version->source_id,
            'version_sequence' => $version->version_sequence,
            'version_key' => $version->version_key,
            'content_hash' => $version->content_hash,
            'raw_evidence_hash' => $version->raw_evidence_hash,
            'retrieved_at' => $version->retrieved_at?->toAtomString(),
            'published_at' => $version->published_at?->toAtomString(),
            'effective_from' => $version->effective_from?->toAtomString(),
            'effective_until' => $version->effective_until?->toAtomString(),
            'source' => $version->source instanceof KnowledgeSource ? $this->mapSource($version->source) : null,
        ];
    }

    /** @return array<string, mixed> */
    private function mapSource(KnowledgeSource $source): array
    {
        return [
            'id' => $source->getKey(),
            'source_key' => $source->source_key,
            'scope_type' => $source->scope_type,
            'scope_key' => $source->scope_key,
            'authority_class' => $source->authority_class?->value ?? null,
            'authority_rank' => $source->authority_rank,
            'publisher' => $source->publisher,
            'official_source' => (bool) $source->official_source,
            'jurisdiction' => $source->jurisdiction === null ? null : [
                'code' => $source->jurisdiction->code,
                'name' => $source->jurisdiction->name,
            ],
            'published_at' => $source->published_at?->toAtomString(),
            'last_checked_at' => $source->last_checked_at?->toAtomString(),
            'last_changed_at' => $source->last_changed_at?->toAtomString(),
            'stale_after' => $source->stale_after?->toAtomString(),
        ];
    }
}
