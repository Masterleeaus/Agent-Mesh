<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Contracts;

use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;

interface RewindSourceAdapterContract
{
    public function key(): string;

    /**
     * Return normalized, read-only historical records for the exact tenant-scoped trace.
     * Implementations must not mutate source systems.
     *
     * @return iterable<\App\Extensions\TitanRewind\System\Reconstruction\RewindEventRecord>
     */
    public function records(RewindTraceQuery $query): iterable;
}
