# Titan CRM Core v1.3.0-alpha.36

**CRM Core owns customer and commercial truth.** It is the authoritative Titan Zero extension for customer identity, sales relationships and commercial document state. It deliberately does not own field execution, inventory, accounting, payment-provider execution or autonomous intelligence.

## Core ownership

CRM Core owns:

- customers, organisations and contacts
- leads, deals/opportunities and pipelines
- CRM activities, notes, tags and custom fields
- CRM projects/tasks/calendar used for commercial coordination
- commercial service/catalogue definitions
- quotes, estimates and invoices
- receivables business state and customer/commercial history
- Customer Hub CRM access and commercial actions
- CRM imports/exports and integration metadata
- CRM-owned automation rules
- governed CRM capabilities, receipts and tenant isolation
- CRM CQRS/read projections and AI-safe customer/commercial read models
- six deterministic commercial calculators: formula rules, pricing, quote estimates, discounts/promotions, margin/profitability and tax

## External domain ownership

CRM Core does **not** own:

- **Titan Field** — service requests, work orders, scheduling, dispatch, field execution, field evidence/forms, recurring work and Titan Go field state
- **Titan Locker** — inventory, purchasing, suppliers, stock, tools, fleet and maintenance
- **Titan Ledger** — accounting journals and accounting/reporting truth
- **Titan Pay** — payment-provider execution, payment intents, collections and provider reconciliation
- **Titan Autonomy** — autonomous authority
- **Titan AI Core** — cross-domain planning
- **Titan AI Workforce** — proactive AI execution/orchestration
- **Titan Wisdom** — learning and outcome patterns

Risk, Assurance, Signal, Rewind, Connect and Interaction remain separate Titan contracts/engines.

## Compatibility boundary

CRM keeps one centralized compatibility layer for legacy `crm.*` names:

- `CrmCapabilityOwnershipMap` declares the authoritative owner.
- `CrmExternalDomainCapabilityBridge` routes an old capability outward when its destination extension is installed.
- CRM Core does not keep per-class Field/Locker/Ledger/Pay implementation aliases.

The alpha.29 catalogue contains **116 CRM-owned governed capabilities** and **120 external compatibility capability names** (**236 visible names total**). Compatibility names are not CRM authority and will be retired after downstream callers adopt native destination contracts.

## Cross-domain references

CRM commercial records may reference externally owned records where lineage requires it. For example, an invoice may reference a Titan Field work order. CRM can create or update the commercial record, but it cannot mutate the Field work order through that relationship.

## Canonical company tenancy (alpha.36)

CRM tenant isolation now uses `company_id` everywhere in authoritative runtime code. Contacts and deals use `customer_company_id` for the linked CRM organisation, keeping customer relationships distinct from the host-company tenant boundary. Historical migrations retain the old key only to support deterministic forward upgrades.

## Governance

Consequential CRM mutations go through Titan Command Bus via CRM's governed gateways. `company_id` is the canonical tenant boundary. Production local-human bypass is disabled by default. AI cannot grant itself authority locally; `CrmAutonomyDecisionPort` delegates authority decisions to Titan Autonomy and falls back to human approval only.

## Alpha.27 boundary audit

Alpha.27 removes remaining active monolith residue from runtime, projections, Chatbot tools, owner/mobile augmentation, automation, Interaction registries and dormant JSON wizards. See:

`docs/CRM-CORE-ALPHA27-DOMAIN-BOUNDARY-AUDIT.md`

## Production checks

Package gate:

```bash
php bin/verify.php
```

Target-host gate:

```bash
php artisan crm:production-check
```

A clean ZIP does not prove the target server is production-ready. The host must supply the required Command Bus, Signal delivery, malware scanner and deployment configuration reported by `crm:production-check`.

## Install shape

The marketplace ZIP contains extension contents at ZIP root (`extension.json`, `System/`, `database/`, etc.). Do not wrap it in an outer `Crm/` folder. Existing data is retained on disable/uninstall unless a separately governed purge is explicitly executed.

## Upgrade rule

Do not merge Titan Field, Locker, Ledger, Pay or autonomous-intelligence implementations back into CRM Core. Compatibility aliases are routing contracts only and should be removed only after all consumers use the native destination capability.

## Customer identity authority (alpha.28)
CRM uses stable `customer_unification_id` roots plus tenant-scoped normalized identities. Strong duplicate candidates require review before conversion/merge; automated channel matching fails closed on ambiguity.

## Commercial contract authority (alpha.29)

Quotes and estimates are mutable only while draft. Issuing captures an immutable `crm.commercial-contract.v1` snapshot and SHA-256; later commercial changes require a new revision that supersedes its predecessor when issued. Acceptance is bound to the exact issued hash with `crm.quote-acceptance.v1` evidence. PDF generation is durable/asynchronous through `crm_sales_document_render_jobs` and `php artisan crm:documents:render`.

## Invoice & receivables authority (alpha.30)

CRM Core owns **what the customer owes**: immutable invoice contracts, accepted-quote/Titan Field lineage references, credit notes, authoritative receivable balances, ageing and reconciliation evidence.

CRM Core does **not** own payment/refund execution. Titan Pay owns money movement and provider state; verified Titan Pay outcomes are recorded through `crm.invoice.settlement.record_verified`. Titan Ledger remains accounting authority.

Current alpha.36 catalogue exposes 130 CRM-owned governed capabilities and 123 external compatibility routes (253 visible names total). The three legacy `crm.payment.*` names are Titan Pay compatibility routes, not CRM writers.

## Command Contract v3 (alpha.31)
All consequential CRM writes now use `crm.command-receipt.v3`. The envelope carries command/tenant/actor/capability/tracing/idempotency and resolved expected-version metadata. Receipts persist affected resources, before/after hashes, invariant results, compensation state, Rewind and exact Signal references. Run `php artisan crm:governance:audit-writes` to audit public/scheduled mutation surfaces.

Current alpha.36 catalogue exposes **130 CRM-owned governed capabilities** and **123 external compatibility routes** (**253 visible names** total).

## Alpha.34 operational observability

CRM Core provides read-only `crm:metrics` and `crm:doctor` commands over its durable command/outbox/projection/import/security journals. `crm:production-check` reports PASS/WARN/BLOCK and fails only on BLOCK. Recovery procedures are documented in `docs/CRM-OPERATIONS-RUNBOOK.md`. Observability state is derivative and cannot become a second business writer.

Capability catalogue: **130 CRM-owned + 123 external compatibility = 253 visible governed names**.


## Alpha.35 performance & scale

Large-tenant hot paths are now explicitly bounded or database-aggregated: projection rebuilds use batch upserts/checkpoints, projection search uses a disposable indexed term table, pipeline/timeline/detail reads are bounded, forecast/analytics/receivables aggregate in SQL, and import staging inserts are batched. Run `php artisan crm:performance:certify <company_id> --iterations=5 --json` on the installed Laravel/MySQL host for real query/index certification. Package verification also runs `php bin/benchmark-v130-alpha35-scale.php`, which is synthetic bounded-working-set evidence and is not a substitute for host-runtime MySQL testing. No partitioning is introduced.
