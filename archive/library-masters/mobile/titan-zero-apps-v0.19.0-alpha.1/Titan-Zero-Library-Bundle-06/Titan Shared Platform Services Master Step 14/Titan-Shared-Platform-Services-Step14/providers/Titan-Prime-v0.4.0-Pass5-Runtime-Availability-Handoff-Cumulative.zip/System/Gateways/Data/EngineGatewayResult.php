<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Data;

use App\Extensions\TitanPrime\System\Gateways\Enums\EngineCallStatus;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;
use InvalidArgumentException;

final readonly class EngineGatewayResult
{
    /**
     * @param array<string,mixed> $payload
     * @param list<string> $reasonCodes
     * @param array<string,mixed> $metadata
     */
    public function __construct(
        public EngineKey $engine,
        public string $capability,
        public string $operationId,
        public EngineCallStatus $status,
        public array $payload = [],
        public array $reasonCodes = [],
        public ?string $receiptId = null,
        public array $metadata = [],
    ) {
        foreach (['capability' => $capability, 'operation_id' => $operationId] as $name => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException(sprintf('%s must not be empty.', $name));
            }
        }
    }

    /** @param array<string,mixed> $payload */
    public static function succeeded(EngineGatewayRequest $request, array $payload = [], ?string $receiptId = null): self
    {
        return new self($request->engine, $request->capability, $request->operationId, EngineCallStatus::Succeeded, $payload, [], $receiptId);
    }

    /** @param list<string> $reasonCodes */
    public static function denied(EngineGatewayRequest $request, array $reasonCodes): self
    {
        return new self($request->engine, $request->capability, $request->operationId, EngineCallStatus::Denied, [], array_values($reasonCodes));
    }

    /** @param list<string> $reasonCodes */
    public static function escalated(EngineGatewayRequest $request, array $reasonCodes): self
    {
        return new self($request->engine, $request->capability, $request->operationId, EngineCallStatus::Escalated, [], array_values($reasonCodes));
    }

    /** @param list<string> $reasonCodes */
    public static function unavailable(EngineGatewayRequest $request, array $reasonCodes = ['engine_unavailable']): self
    {
        return new self($request->engine, $request->capability, $request->operationId, EngineCallStatus::Unavailable, [], array_values($reasonCodes));
    }

    /** @param list<string> $reasonCodes @param array<string,mixed> $metadata */
    public static function failed(EngineGatewayRequest $request, array $reasonCodes = ['engine_call_failed'], array $metadata = []): self
    {
        return new self($request->engine, $request->capability, $request->operationId, EngineCallStatus::Failed, [], array_values($reasonCodes), null, $metadata);
    }

    public function isSuccess(): bool
    {
        return $this->status === EngineCallStatus::Succeeded;
    }

    public function permitsContinuation(): bool
    {
        return $this->status === EngineCallStatus::Succeeded;
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'engine' => $this->engine->value,
            'capability' => $this->capability,
            'operation_id' => $this->operationId,
            'status' => $this->status->value,
            'payload' => $this->payload,
            'reason_codes' => array_values($this->reasonCodes),
            'receipt_id' => $this->receiptId,
            'metadata' => $this->metadata,
        ];
    }
}
