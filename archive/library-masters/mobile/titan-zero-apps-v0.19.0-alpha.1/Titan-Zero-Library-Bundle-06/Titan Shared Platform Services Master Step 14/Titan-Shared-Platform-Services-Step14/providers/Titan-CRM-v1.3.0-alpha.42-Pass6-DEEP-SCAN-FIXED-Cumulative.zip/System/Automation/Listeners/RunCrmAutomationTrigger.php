<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Automation\Listeners;
use App\Extensions\Crm\System\Automation\CrmAutomationEngine;
use App\Extensions\Crm\System\Automation\Events\CrmAutomationTriggered;
final class RunCrmAutomationTrigger
{
    public function __construct(private CrmAutomationEngine $engine) {}
    public function handle(CrmAutomationTriggered $event): void { $this->engine->dispatch($event->userId,$event->triggerKey,$event->context); }
}
