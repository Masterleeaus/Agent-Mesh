# Changelog

## 1.12.0 — Pass 9: Safety & Compliance Vision
- Added a central deterministic SafetyCompliancePolicyService across all verticals.
- Added structured safety findings with hazard key, domain, severity, confidence, evidence references, regulated-domain status and human-review state.
- Added regulated domains for electrical, structural, gas, chemical, fire, biological, working-at-height and confined-space observations.
- High/critical or regulated findings require authorised human/domain review.
- Added explicit certification prohibition for electrical, structural, gas, chemical, fire and regulatory compliance.
- Added Safety & Compliance panel to Evidence Review.
- Safety-review proposals now carry the structured safety package, mandatory human-authority flag, and certification_allowed=false.
- Preserved the non-authoritative boundary: Vision observes visible potential hazards but never certifies safety or compliance.


## 1.11.0 — Pass 8: Quote & Variation Intelligence
- Added structured visual quote candidates split into scope, service, and material candidates.
- Added missing-measurement flags instead of allowing Vision to guess quantities or dimensions.
- Added evidence-image references for quote and variation candidates.
- Added deterministic QuoteVariationIntelligenceService to build governed commercial proposal packages.
- Added quote intelligence persistence in evidence-set coverage and Evidence Review visibility.
- Quote routing now includes structured quote intelligence, scope evidence, variation candidates, and an explicit authoritative-pricing requirement.
- Vision still cannot invent price, tax, labour rate, quantity, discount, markup, total, scope approval, or variation approval.


## 1.10.0 — Pass 7: Completion Assurance v2
- Added deterministic completion-readiness states: READY_FOR_ASSURANCE, REVIEW_REQUIRED, MORE_EVIDENCE_REQUIRED, BLOCKED_BY_OPEN_FINDING, and BLOCKED_BY_VARIATION.
- Added structured scope-to-evidence reconciliation against approved scope explicitly present in verified Titan context.
- Added visual variation candidates with approval status; pending/unapproved candidates block Assurance handoff.
- Added unresolved high/critical visual finding blockers.
- Persisted the full Completion Assurance v2 package inside evidence-set coverage.
- Updated Evidence Review to show scope evidence, variation candidates, explicit readiness state, blockers, and scores.
- Updated Assurance routing so only READY_FOR_ASSURANCE may be submitted onward.
- Preserved the authority boundary: Vision never approves scope, approves variations, or completes a job.


## 1.9.0 — Pass 6: Deep Vertical Inspection Packs
- Added 15 first-class vertical inspection packs for priority field/home-service trades.
- Each pack now owns required captures, finding taxonomy, prohibited conclusions, risk classes, allowed workflow routes, and completion-assurance rules.
- Wired pack captures into Evidence Checklist requirements.
- Wired pack taxonomy/prohibited conclusions/risk classes/routes into Titan Vision prompts.
- Wired pack completion rules into deterministic Completion Assurance thresholds.
- Restricted Vision workflow proposals to routes explicitly allowed by the active vertical pack.
- Preserved non-authoritative visual intelligence: packs constrain inference and routing but do not establish safety, compliance, completion, pricing, or domain truth.


## 1.8.0 — Pass 5: Asset Visual Intelligence
- Added persistent Asset Visual Passports separate from the authoritative asset register.
- Added evidence-backed manufacturer/model/serial identity candidates and explicit nameplate verification.
- Added exact-serial possible-duplicate detection without automatic asset merging.
- Added persistent visual condition snapshots and observed condition trends across service evidence.
- Added asset-specific capture requirements and passport/service-history imagery.
- Added user review routes for identity verification and candidate rejection/more-evidence states.
- Preserved the authority boundary: Vision may propose identity/duplicate candidates but cannot create, merge or mutate authoritative asset truth directly.


## 1.8.0 — Pass 5: Asset Visual Intelligence
- Added persistent Asset Visual Passports separate from the authoritative asset register.
- Added evidence-backed manufacturer/model/serial identity candidates and explicit nameplate verification.
- Added exact-serial possible-duplicate detection without automatic asset merging.
- Added persistent visual condition snapshots and observed condition trends across service evidence.
- Added asset-profile capture requirements and passport/service-history imagery.
- Added user review routes for identity verification and candidate rejection/more-evidence states.
- Preserved the authority boundary: Vision may propose identity/duplicate candidates but cannot create, merge or mutate authoritative asset truth directly.


## 1.7.0 — Pass 4: Evidence Quality & Capture Guidance
- Added deterministic pre-inference evidence quality analysis for resolution, darkness, overexposure, approximate sharpness, duplicate captures and subject coverage.
- Added server-authoritative preflight reports and retake guidance before provider inference.
- Added hard fail-safe for severely unusable evidence while allowing non-critical quality warnings to proceed under review.
- Persisted per-image quality reports with evidence items and quality summary with the evidence set.
- Added mobile capture quality feedback and explicit retake guidance in Titan Vision.
- Kept quality checks non-authoritative: they assess capture usability, not job condition, safety or compliance.


## 1.6.0 — Pass 3: Advanced Spatial Inspection
- Added multi-region findings with rectangle, polygon, and point geometry on the normalized 0–1000 evidence grid.
- Added stable region keys, grouping keys, parent-child spatial relationships, and non-destructive geometry persistence.
- Added evidence-review rendering for polygon/point/rectangle regions.
- Preserved non-authoritative evidence semantics: spatial regions locate visible evidence and never establish hidden condition or business truth.


## 1.5.0
- Add longitudinal visual change detection against explicitly verified historical baselines.
- Add canonical change states: new, resolved, improved, worsened, unchanged, uncertain and not_comparable.
- Add deterministic classification thresholds for comparability, confidence, evidence completeness and visible severity.
- Add cross-visit provider comparison with capture-slot pairing and non-authoritative structured results.
- Add persistent `titan_vision_changes` history, review states, Evidence Review controls and timeline summaries.
- Preserve Blueprint v4.2 authority boundaries: visual change inference does not become domain truth or directly execute business writes.

## 1.3.0
- Add automatic before/after evidence pairing with stable pair keys.
- Add deterministic comparison-quality scoring for framing, angle, lighting and coverage.
- Add persistent comparison records and evidence-set timeline/history.
- Add profile-specific Completion Assurance readiness rules and evidence scoring.
- Block Assurance handoff while required evidence/review/comparison blockers remain unresolved.
- Preserve Blueprint v4.2 non-authoritative visual intelligence boundaries.

## 1.2.0
- Adopt Blueprint v4.2.0 canonical Manifest v2.2 and Installer 1.7.8 root manifest.
- Reclassify as intelligence-engine with non-authoritative inference boundaries.
- Make cross-domain routing proposal-only.
- Add production documentation and tenant-context compatibility migration.

## Agent-06 Workforce Provider Migration

- Added fail-closed `workforce-integration.json` using canonical `company_id`.
- Workforce identity/roles/hierarchy remain owned by Titan AI Workforce; provider capabilities remain extension-owned.
- Converged package/manifest metadata toward Titan Extension Blueprint v4.2.1.

## 1.12.6 — Agent-06 Upgrade Pass 2
- Workforce provider contract v1.1 with per-capability operational policy metadata.
- Command-bus/receipt enforcement metadata for state-changing Workforce actions.
- Explicit provider health, degradation, idempotency, offline and provenance requirements.
- Standalone schema/contract consistency verification.
