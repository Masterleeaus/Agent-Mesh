<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\CommandBusBridgeContract;
use RuntimeException;

final class UnavailableCommandBusBridge implements CommandBusBridgeContract
{
    public function dispatch(object $command, array $authorityContext): mixed
    {
        throw new RuntimeException('COMMAND_BUS_BRIDGE_UNAVAILABLE');
    }
}
