<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Context;

use RuntimeException;

/**
 * Resolves tenant authority only from trusted/authenticated host context.
 * Caller request payload fields are deliberately ignored as authority.
 */
final class TenantCompanyContextResolver
{
    /** @param array<string,mixed> $trustedContext */
    public function resolve(array $trustedContext): int
    {
        $value = $trustedContext['authenticated_tenant_company_id'] ?? null;
        if (! is_int($value) && ! (is_string($value) && ctype_digit($value))) {
            throw new RuntimeException('Authenticated Titan tenant context is missing.');
        }

        $tenantCompanyId = (int) $value;
        if ($tenantCompanyId <= 0) {
            throw new RuntimeException('Authenticated Titan tenant context is invalid.');
        }

        return $tenantCompanyId;
    }
}
