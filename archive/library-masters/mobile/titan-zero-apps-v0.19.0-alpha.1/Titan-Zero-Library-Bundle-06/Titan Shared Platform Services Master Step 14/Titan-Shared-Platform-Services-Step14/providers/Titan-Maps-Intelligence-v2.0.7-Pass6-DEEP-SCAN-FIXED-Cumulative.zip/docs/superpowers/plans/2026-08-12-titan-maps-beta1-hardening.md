# Titan Maps Intelligence v2.0.0-beta.1 Hardening Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship a beta hardening release that closes verified cost, privacy, routing-freshness, territory-determinism, dispatch-flexibility and scalability gaps without regressing alpha.17.

**Architecture:** Add narrowly scoped Maps-owned policy/evidence tables and services, keep external Titan engines optional through adapters, and place provider/capability controls before external side effects. Preserve legacy routes/tools and add backward-compatible governed capability contracts.

**Tech Stack:** PHP/Laravel extension code, Eloquent migrations/models, existing Google provider adapters, Laravel cache/queue/scheduler abstractions, standalone PHP verification scripts.

## Global Constraints
- Preserve root `titan-extension-v1` manifest compatibility.
- Preserve tenant isolation and server-derived tenant/worker identity.
- CRM remains authoritative for jobs/customers/assignments/pricing.
- No AI direct authoritative writes; consequential cross-extension writes use Command Bus.
- Offline authority cannot increase.
- No hidden chain-of-thought storage.
- Optional Titan engines remain optional installer dependencies.

---

### Task 1: Provider quota and health circuit breaker
- [ ] Add failing runtime/architecture tests for soft/hard quota, override, provider health and Signals.
- [ ] Add quota policy model/migration and usage service enforcement before provider calls.
- [ ] Add `maps.quota.status`, `maps.provider.quota.override`, and provider-health capability handlers.
- [ ] Verify cached/straight-line downgrade on soft limit and 429-style hard-limit denial.

### Task 2: Server-side geofence reconciliation and confidence
- [ ] Add failing test proving client transition events cannot create authoritative geofence events.
- [ ] Add scheduled reconcile command/job over append-only pings.
- [ ] Add per-geofence hysteresis and dwell fields with GPS-accuracy-adjusted confidence.
- [ ] Verify replay/idempotency and Signal emission path.

### Task 3: Worker privacy, stale status and retention
- [ ] Add failing tests for history-sharing visibility, stale threshold, device rate limiting and retention tiers.
- [ ] Add sharing/stale/retention configuration/state fields and pruning policies.
- [ ] Add anomaly score for impossible jumps and investigation Signal metadata.

### Task 4: Configurable dispatch scoring profiles
- [ ] Add failing tests for tenant/vertical weight overrides, total=100 validation and temporal/fatigue/familiarity factors.
- [ ] Add dispatch scoring policy model/migration/service.
- [ ] Add governed read/update capabilities; update scoring runtime to use resolved policy.
- [ ] Preserve CRM final authority and include candidate rank in Command Bus assignment input.

### Task 5: Territory determinism and explainability
- [ ] Add failing tests for overlap, boundary points, tie-break order and matched rule chain.
- [ ] Add deterministic resolution and dry-run conflict detection.
- [ ] Emit territory conflict Signal and return full rule chain.

### Task 6: Route freshness, history and optimisation limits
- [ ] Add failing tests for ETA valid-until policy, stale auto-refresh, query filters and optimiser timeout metadata.
- [ ] Add `valid_until` to ETA snapshots and refresh rules.
- [ ] Add route-history filters by worker/customer/date.
- [ ] Add exact-small/heuristic-large optimiser strategy with timeout/best-found metadata and heuristic Signal.

### Task 7: Cache/data-quality hardening
- [ ] Add cache-store abstraction preferring Redis and emitting fallback Signal when DB cache is used.
- [ ] Add normalized geocode/cache keys and candidate dedupe/business-status checks.
- [ ] Add capability metadata cache and idempotent short-TTL territory/service-area read cache.

### Task 8: Analytics/fallback operational hardening
- [ ] Add queued analytics snapshot contract with 24h TTL/version metadata.
- [ ] Add resource-fallback human-review deadline/escalation evidence and internal promotion approval record.

### Task 9: Public response and provider security hardening
- [ ] Add public-map redaction verifier for tenant identifiers.
- [ ] Add provider key rotation/secondary-key health contract without exposing credentials.
- [ ] Add explicit provider/capability timeout error details.

### Task 10: Release verification
- [ ] Update sidecar capability/table declarations, README/SECURITY/CHANGELOG/BUILD_REPORT and roadmap.
- [ ] Run all standalone runtime/architecture scripts.
- [ ] Run PHP, JS and JSON syntax checks.
- [ ] Regenerate package hashes.
- [ ] Stage exact `TitanMapsIntelligence/` folder and rerun all gates.
- [ ] Build flat-root ZIP, extract fresh, rerun packaged-byte certification and compute SHA-256.
