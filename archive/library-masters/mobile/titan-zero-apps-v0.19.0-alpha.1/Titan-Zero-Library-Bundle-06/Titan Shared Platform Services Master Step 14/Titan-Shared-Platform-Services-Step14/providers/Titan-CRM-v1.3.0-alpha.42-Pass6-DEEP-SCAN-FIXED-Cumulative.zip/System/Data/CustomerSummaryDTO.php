<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Data;

final class CustomerSummaryDTO
{
    public function __construct(
        public readonly mixed $publicId,
        public readonly mixed $name,
        public readonly mixed $email,
        public readonly mixed $phone,
        public readonly mixed $companyPublicId,
    ) {}

    public function toArray(): array
    {
        return [
            'publicId'=>$this->publicId,
            'name'=>$this->name,
            'email'=>$this->email,
            'phone'=>$this->phone,
            'companyPublicId'=>$this->companyPublicId,
        ];
    }
}
