# Failure Modes
Current failures are limited to install/boot/navigation/database/configuration boundaries because remote retrieval is disabled. Future source failures must fail closed on authority promotion, preserve prior immutable evidence, record freshness/staleness, and surface unresolved contradictions for review.

## Source-version append failures
New version appends fail closed for missing/inactive/legacy/malformed sources, invalid effective windows, invalid causal UUIDs or database conflicts. Same normalized content is idempotently returned as the existing version rather than creating a duplicate. The service never repairs conflicts by mutating an existing immutable version.
