<?php
namespace App\Extensions\Crm\System\Contracts;
interface LeadRepositoryContract {
    public function search(int $userId, array $filters=[]): array;
    public function find(int $userId, string $publicId): array;
    public function create(int $userId, int $actorUserId, array $data): array;
    public function update(int $userId, string $publicId, int $actorUserId, array $data): array;
    public function convert(int $userId, string $publicId, int $actorUserId): array;
}
