<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$check = static function (bool $ok, string $message) use (&$errors): void {
    if (! $ok) $errors[] = $message;
};

$installer = json_decode((string) @file_get_contents($root . '/extension.json'), true);
$sidecar = json_decode((string) @file_get_contents($root . '/extension.manifest.json'), true);
$check(is_array($installer), 'extension.json invalid');
$check(is_array($sidecar), 'extension.manifest.json invalid');
$check(is_string($installer['version'] ?? null) && preg_match('/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $installer['version']) === 1, 'installer version must be valid semver');
$check(($sidecar['version'] ?? null) === ($installer['version'] ?? null), 'sidecar version must match installer version');

$expectedTables = [
    'titan_knowledge_sources',
    'titan_knowledge_source_versions',
    'titan_knowledge_documents',
    'titan_knowledge_sections',
    'titan_knowledge_claims',
    'titan_knowledge_jurisdictions',
    'titan_knowledge_applicability',
];
foreach ($expectedTables as $table) {
    $check(in_array($table, $sidecar['database']['owned_tables'] ?? [], true), "owned table missing: {$table}");
}

$expectedModels = [
    'KnowledgeSource', 'KnowledgeSourceVersion', 'KnowledgeDocument', 'KnowledgeSection',
    'KnowledgeClaim', 'KnowledgeJurisdiction', 'KnowledgeApplicability',
];
foreach ($expectedModels as $model) {
    $path = $root . '/System/Domain/Models/' . $model . '.php';
    $check(is_file($path), "domain model missing: {$model}");
}

foreach ([
    'System/Domain/Enums/KnowledgeScopeType.php',
    'System/Domain/Enums/AuthorityClass.php',
    'System/Domain/Enums/KnowledgeSourceStatus.php',
    'System/Domain/ValueObjects/KnowledgeScopeContext.php',
    'System/Domain/Services/KnowledgeScopeGuard.php',
    'System/Domain/Services/SourceVersionHasher.php',
] as $relative) {
    $check(is_file($root . '/' . $relative), "domain support missing: {$relative}");
}

$migrations = glob($root . '/database/migrations/*.php') ?: [];
$check(count($migrations) >= 5, 'Pass 2 must add at least three forward migrations');
$migrationText = '';
foreach ($migrations as $migration) $migrationText .= "\n" . (string) file_get_contents($migration);
foreach ($expectedTables as $table) {
    $check(str_contains($migrationText, $table), "migration does not mention table: {$table}");
}
foreach (['source_key','scope_type','scope_key','authority_class','authority_rank','publisher','canonical_uri','retrieval_method','access_policy','provenance','content_hash','raw_evidence_hash','retrieved_at','effective_from','effective_until','supersedes_version_id','document_key','section_key','claim_key','jurisdiction_id','vertical_key','workflow_key','specificity'] as $field) {
    $check(str_contains($migrationText, "'{$field}'"), "domain migration field missing: {$field}");
}
foreach (['tenant_company_id','trace_id','correlation_id','causation_id'] as $lineage) {
    $occurrences = substr_count($migrationText, "'{$lineage}'");
    $check($occurrences >= 5, "durable lineage field insufficiently represented: {$lineage}");
}

$versionModel = (string) @file_get_contents($root . '/System/Domain/Models/KnowledgeSourceVersion.php');
$check(str_contains($versionModel, 'static::updating'), 'source version model must reject updates');
$check(str_contains($versionModel, 'static::deleting'), 'source version model must reject deletion');
$check(str_contains($versionModel, 'immutable'), 'source version model must expose immutable semantics');

$guard = (string) @file_get_contents($root . '/System/Domain/Services/KnowledgeScopeGuard.php');
$check(str_contains($guard, 'tenant'), 'scope guard must handle tenant scope');
$check(str_contains($guard, 'platform'), 'scope guard must handle platform scope');
$check(str_contains($guard, 'jurisdiction'), 'scope guard must handle jurisdiction scope');

$hasher = (string) @file_get_contents($root . '/System/Domain/Services/SourceVersionHasher.php');
$check(str_contains($hasher, "hash('sha256'"), 'source version hasher must use SHA-256');

$service = (string) @file_get_contents($root . '/System/Services/KnowledgeAuthority.php');
$check(str_contains($service, "'domain_model_ready' => true"), 'health must preserve domain model readiness');
$check(str_contains($service, "'domain_model_ready' => true"), 'health must report domain model ready');
$check(str_contains($service, "'refresh_enabled' => false"), 'refresh must remain disabled');

$caps = $sidecar['capabilities'] ?? [];
foreach (['knowledge.resolve', 'knowledge.refresh', 'knowledge.source.read', 'knowledge.version.read', 'knowledge.applicability.evaluate'] as $unimplemented) {
    $check(! in_array($unimplemented, $caps, true), "Pass 2 must not advertise unimplemented capability: {$unimplemented}");
}
$check(($sidecar['queues']['used'] ?? null) === false, 'queues must remain disabled in Pass 2');
$check(($sidecar['external_hosts'] ?? null) === [], 'external_hosts must remain empty in Pass 2');
$check(($sidecar['schedules'] ?? null) === [], 'schedules must remain empty in Pass 2');

if (is_file($root . '/System/Domain/Services/KnowledgeScopeGuard.php') && is_file($root . '/System/Domain/ValueObjects/KnowledgeScopeContext.php') && is_file($root . '/System/Domain/Enums/KnowledgeScopeType.php')) {
    require_once $root . '/System/Domain/Enums/KnowledgeScopeType.php';
    require_once $root . '/System/Domain/ValueObjects/KnowledgeScopeContext.php';
    require_once $root . '/System/Domain/Services/KnowledgeScopeGuard.php';
    $guardClass = 'App\\Extensions\\TitanKnowledgeAuthority\\System\\Domain\\Services\\KnowledgeScopeGuard';
    $contextClass = 'App\\Extensions\\TitanKnowledgeAuthority\\System\\Domain\\ValueObjects\\KnowledgeScopeContext';
    if (class_exists($guardClass) && class_exists($contextClass)) {
        $scopeGuard = new $guardClass();
        $platform = $contextClass::platform();
        $jurisdiction = $contextClass::jurisdiction('AU-VIC');
        $tenant42 = $contextClass::tenant(42);
        $check($scopeGuard->canRead($platform, null) === true, 'platform scope should be globally readable');
        $check($scopeGuard->canRead($jurisdiction, null) === false, 'primitive jurisdiction guard must fail closed once Pass 3 trusted context exists');
        $check($scopeGuard->canRead($tenant42, 42) === true, 'matching tenant should be readable');
        $check($scopeGuard->canRead($tenant42, 41) === false, 'cross-tenant read must be denied');
        $check($scopeGuard->canRead($tenant42, null) === false, 'tenant scope without actor tenant must be denied');
    }
}

if (is_file($root . '/System/Domain/Services/SourceVersionHasher.php')) {
    require_once $root . '/System/Domain/Services/SourceVersionHasher.php';
    $hasherClass = 'App\\Extensions\\TitanKnowledgeAuthority\\System\\Domain\\Services\\SourceVersionHasher';
    if (class_exists($hasherClass)) {
        $h = new $hasherClass();
        $check($h->hash("hello\r\nworld\r\n") === $h->hash("hello\nworld\n"), 'hasher should normalize CRLF to LF');
        $check($h->hash('alpha') !== $h->hash('beta'), 'hasher must distinguish changed content');
    }
}

if ($errors !== []) {
    foreach ($errors as $error) fwrite(STDERR, "FAIL: {$error}\n");
    exit(1);
}

echo "Titan Knowledge Authority Pass 2 domain foundation verification: PASS\n";
