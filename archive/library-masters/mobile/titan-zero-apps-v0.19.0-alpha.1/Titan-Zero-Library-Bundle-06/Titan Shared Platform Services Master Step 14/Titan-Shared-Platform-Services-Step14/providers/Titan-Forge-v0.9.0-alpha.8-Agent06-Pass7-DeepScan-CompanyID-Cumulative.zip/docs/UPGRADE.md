# Titan Forge Upgrade

Upgrades are forward-migration compatible and preserve existing durable build history.

For v0.6.1-alpha.1, migration `2026_08_18_000003_add_root_causation_to_titan_forge_builds.php` adds nullable indexed `root_causation_id`. Existing rows remain valid; new events/build contexts populate the field, falling back to `causation_id` for historical compatibility.

Upgrade procedure: back up Forge-owned durable state, disable new generation, install the new package through Titan Extension Manager, run migrations, clear/reload host caches as required, run health and manifest checks, then re-enable generation. Do not bypass failed canonical verification.

## v0.7.0-alpha.1 — AI planning provenance

Migration `2026_08_19_000004_add_ai_planning_provenance_to_forge_build_plans.php` additively extends `titan_forge_build_plans` with AI Core source-plan/schema/runtime/provenance metadata. Existing deterministic plans remain valid; no existing Forge-owned table is replaced or destructively rewritten.


## v0.8.0-alpha.1 — Model Council governed deliberation

No database migration is required. Pass 18 reuses `titan_forge_receipts` for sanitized Council decision receipts. Sites that want governed Council review must install Titan Model Council `>=0.7.0` and configure all four trusted `TITAN_FORGE_COUNCIL_*_MODEL` assignments with at least three distinct models. Leaving all four unset is valid, but high/critical candidates then remain `approval_required` with `council.configuration_required`.

## v0.9.0-alpha.1 — Rewind source contribution

No database migration is required. Pass 19 adds a read-only Blueprint v4.2.1 `rewind-source` contribution over existing Forge-owned durable evidence. Titan Rewind `>=1.0.0` is optional. Forge does not write to Rewind-owned tables. Existing Forge data remains authoritative in Forge. Exact `as_of` reconstruction is intentionally unavailable until an immutable lifecycle history can support truthful point-in-time reads.
