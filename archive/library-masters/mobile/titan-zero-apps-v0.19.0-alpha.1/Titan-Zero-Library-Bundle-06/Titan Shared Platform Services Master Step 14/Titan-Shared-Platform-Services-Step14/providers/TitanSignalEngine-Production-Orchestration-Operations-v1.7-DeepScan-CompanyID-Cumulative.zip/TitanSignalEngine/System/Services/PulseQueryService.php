<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalPulseContract;
use App\Extensions\TitanSignalEngine\System\Data\PulsePercentiles;
use App\Extensions\TitanSignalEngine\System\Data\PulseProjectionFreshness;
use App\Extensions\TitanSignalEngine\System\Data\PulseSnapshot;
use App\Extensions\TitanSignalEngine\System\Data\PulseWindow;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Models\SignalDelivery;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseProjectedEvent;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseProjectionFreshness;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseCommandReceipt;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseRollup;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseTraceMetric;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Schema;

final class PulseQueryService implements SignalPulseContract
{
    public function __construct(
        private readonly SignalContextValidator $contextValidator,
        private readonly PulseAttentionScorer $attentionScorer,
        private readonly PulseSurfaceBuilder $surfaceBuilder,
    ) {
    }

    public function snapshot(SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, string $window = '5m'): PulseSnapshot
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $pulseWindow = PulseWindow::fromKey($window, $now);
        $tenantKey = $scope === SignalEnvelope::SCOPE_TENANT ? (int) $tenantCompanyId : 0;

        $totals = $this->rollupTotals($scope, $tenantKey, $pulseWindow);
        $delivery = $this->deliveryHealth($scope, $tenantCompanyId);
        $trace = $this->traceHealth($scope, $tenantKey, $pulseWindow, $now);

        $eventCount = (int) ($totals['event_count'] ?? 0);
        $metrics = array_merge($totals, $delivery, $trace['counts'], [
            'event_rate_per_second' => round($eventCount / $pulseWindow->seconds, 6),
            'command_rate_per_second' => round(((int) ($totals['command_count'] ?? 0)) / $pulseWindow->seconds, 6),
            'error_rate' => $eventCount > 0 ? round(((int) ($totals['error_count'] ?? 0)) / $eventCount, 6) : 0.0,
        ]);

        $attention = $this->attentionScorer->score($metrics);
        $health = $this->projectionHealth($scope, $tenantKey, $now);

        return new PulseSnapshot(
            $scope,
            $tenantCompanyId,
            $pulseWindow,
            $now,
            $metrics,
            $trace['latency'],
            $health,
            $attention,
            $this->dimensionSummary($scope, $tenantKey, $pulseWindow, 'source', 10),
            $this->dimensionSummary($scope, $tenantKey, $pulseWindow, 'event_type', 10),
        );
    }

    public function surface(SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, string $window = '5m'): array
    {
        return $this->surfaceBuilder->build($this->snapshot($context, $tenantCompanyId, $scope, $window));
    }

    /** @return array<string,int> */
    private function rollupTotals(string $scope, int $tenantKey, PulseWindow $window): array
    {
        if (! Schema::hasTable('titan_signal_pulse_rollups')) {
            return $this->emptyTotals();
        }
        $row = SignalPulseRollup::query()
            ->where('scope', $scope)
            ->where('tenant_key', $tenantKey)
            ->where('granularity', $window->granularity)
            ->where('dimension', 'all')
            ->where('dimension_value', '__all__')
            ->where('bucket_start', '>=', $window->start)
            ->where('bucket_start', '<=', $window->end)
            ->selectRaw('COALESCE(SUM(event_count),0) as event_count, COALESCE(SUM(error_count),0) as error_count, COALESCE(SUM(critical_count),0) as critical_count, COALESCE(SUM(command_count),0) as command_count, COALESCE(SUM(risk_count),0) as risk_count, COALESCE(SUM(governance_count),0) as governance_count, COALESCE(SUM(assurance_count),0) as assurance_count, COALESCE(SUM(autonomy_count),0) as autonomy_count, COALESCE(SUM(subscription_failure_count),0) as subscription_failure_count')
            ->first();
        if ($row === null) {
            return $this->emptyTotals();
        }
        return [
            'event_count' => (int) $row->event_count,
            'error_count' => (int) $row->error_count,
            'critical_count' => (int) $row->critical_count,
            'command_count' => (int) $row->command_count,
            'risk_count' => (int) $row->risk_count,
            'governance_count' => (int) $row->governance_count,
            'assurance_count' => (int) $row->assurance_count,
            'autonomy_count' => (int) $row->autonomy_count,
            'subscription_failure_count' => (int) $row->subscription_failure_count,
        ];
    }

    /** @return array<string,int> */
    private function emptyTotals(): array
    {
        return ['event_count' => 0, 'error_count' => 0, 'critical_count' => 0, 'command_count' => 0, 'risk_count' => 0, 'governance_count' => 0, 'assurance_count' => 0, 'autonomy_count' => 0, 'subscription_failure_count' => 0];
    }

    /** @return array<string,int> */
    private function deliveryHealth(string $scope, ?int $tenantCompanyId): array
    {
        $counts = ['pending' => 0, 'queued' => 0, 'processing' => 0, 'retry_wait' => 0, 'dead_letter' => 0];
        if (! Schema::hasTable('titan_signal_deliveries')) {
            return ['pending_delivery_count' => 0, 'queued_delivery_count' => 0, 'processing_delivery_count' => 0, 'retry_wait_count' => 0, 'dead_letter_count' => 0];
        }
        $query = SignalDelivery::query()->where('scope', $scope);
        $scope === SignalEnvelope::SCOPE_TENANT ? $query->where('tenant_company_id', $tenantCompanyId) : $query->whereNull('tenant_company_id');
        foreach ($query->whereIn('status', array_keys($counts))->selectRaw('status, COUNT(*) as aggregate')->groupBy('status')->cursor() as $row) {
            $counts[(string) $row->status] = (int) $row->aggregate;
        }
        return [
            'pending_delivery_count' => $counts['pending'],
            'queued_delivery_count' => $counts['queued'],
            'processing_delivery_count' => $counts['processing'],
            'retry_wait_count' => $counts['retry_wait'],
            'dead_letter_count' => $counts['dead_letter'],
        ];
    }

    /** @return array{counts:array<string,int>,latency:array<string,mixed>} */
    private function traceHealth(string $scope, int $tenantKey, PulseWindow $window, DateTimeImmutable $now): array
    {
        if (! Schema::hasTable('titan_signal_pulse_trace_metrics')) {
            return ['counts' => ['stalled_trace_count' => 0, 'missing_receipt_count' => 0], 'latency' => ['trace_ms' => PulsePercentiles::summarize([]), 'command_receipt_ms' => PulsePercentiles::summarize([])]];
        }
        $base = fn (): Builder => SignalPulseTraceMetric::query()->where('scope', $scope)->where('tenant_key', $tenantKey);
        $stallAfter = $now->modify('-' . (int) config('titan-signal-engine.pulse_stalled_after_seconds', 3600) . ' seconds');
        $receiptAfter = $now->modify('-' . (int) config('titan-signal-engine.pulse_missing_receipt_after_seconds', 300) . ' seconds');
        $horizon = $now->modify('-' . (int) config('titan-signal-engine.pulse_stall_horizon_seconds', 604800) . ' seconds');
        $watched = (array) config('titan-signal-engine.pulse_stall_watch_event_types', ['command.requested', 'risk.assessed', 'command.authorized', 'command.executed']);

        $stalled = $base()->where('terminal_seen', false)->whereIn('last_event_type', $watched)->whereBetween('last_occurred_at', [$horizon, $stallAfter])->count();
        $sampleLimit = max(100, min((int) config('titan-signal-engine.pulse_latency_sample_limit', 5000), 20000));
        if (Schema::hasTable('titan_signal_pulse_command_receipts')) {
            $pairBase = fn (): Builder => SignalPulseCommandReceipt::query()->where('scope', $scope)->where('tenant_key', $tenantKey);
            $missingReceipt = $pairBase()->whereNull('receipt_event_id')->whereBetween('command_occurred_at', [$horizon, $receiptAfter])->count();
            $commandSamples = $pairBase()->whereNotNull('latency_ms')->whereBetween('receipt_occurred_at', [$window->start, $window->end])
                ->orderByDesc('receipt_occurred_at')->limit($sampleLimit)->pluck('latency_ms')->map(static fn ($v): int => (int) $v)->all();
        } else {
            $missingReceipt = $base()->whereNotNull('command_executed_at')->whereNull('execution_receipt_at')->whereBetween('command_executed_at', [$horizon, $receiptAfter])->count();
            $commandSamples = $base()->whereNotNull('command_latency_ms')->whereBetween('execution_receipt_at', [$window->start, $window->end])->orderByDesc('execution_receipt_at')->limit($sampleLimit)->pluck('command_latency_ms')->map(static fn ($v): int => (int) $v)->all();
        }
        $traceSamples = $base()->where('terminal_seen', true)->whereBetween('last_occurred_at', [$window->start, $window->end])->orderByDesc('last_occurred_at')->limit($sampleLimit)->pluck('duration_ms')->map(static fn ($v): int => (int) $v)->all();

        return [
            'counts' => ['stalled_trace_count' => (int) $stalled, 'missing_receipt_count' => (int) $missingReceipt],
            'latency' => ['trace_ms' => PulsePercentiles::summarize($traceSamples), 'command_receipt_ms' => PulsePercentiles::summarize($commandSamples)],
        ];
    }

    /** @return list<array<string,mixed>> */
    private function dimensionSummary(string $scope, int $tenantKey, PulseWindow $window, string $dimension, int $limit): array
    {
        if (! Schema::hasTable('titan_signal_pulse_rollups')) {
            return [];
        }
        $rows = [];
        foreach (SignalPulseRollup::query()->where('scope', $scope)->where('tenant_key', $tenantKey)->where('granularity', $window->granularity)->where('dimension', $dimension)
            ->where('bucket_start', '>=', $window->start)->where('bucket_start', '<=', $window->end)
            ->selectRaw('dimension_value, SUM(event_count) as event_count, SUM(error_count) as error_count, SUM(critical_count) as critical_count, MAX(last_event_at) as last_event_at')
            ->groupBy('dimension_value')->orderByDesc('event_count')->limit($limit)->cursor() as $row) {
            $rows[] = $row;
        }
        $freshness = [];
        if ($dimension === 'source' && Schema::hasTable('titan_signal_pulse_projection_freshness')) {
            $keys = array_values(array_map(static fn ($row): string => (string) $row->dimension_value, $rows));
            if ($keys !== []) {
                foreach (SignalPulseProjectionFreshness::query()->where('scope', $scope)->where('tenant_key', $tenantKey)->where('dimension', 'source')->whereIn('dimension_value', $keys)->limit(count($keys))->cursor() as $item) {
                    $freshness[(string) $item->dimension_value] = $item;
                }
            }
        }
        $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $threshold = (int) config('titan-signal-engine.pulse_projection_degraded_after_seconds', 300);
        return array_map(static function ($row) use ($freshness, $now, $threshold): array {
            $count = (int) $row->event_count;
            $errors = (int) $row->error_count;
            $item = $freshness[(string) $row->dimension_value] ?? null;
            $projection = $item === null ? null : PulseProjectionFreshness::evaluate(
                $item->last_projected_at ? new DateTimeImmutable($item->last_projected_at->format(DATE_ATOM)) : null,
                $item->last_recorded_at ? new DateTimeImmutable($item->last_recorded_at->format(DATE_ATOM)) : null,
                $item->last_ingested_recorded_at ? new DateTimeImmutable($item->last_ingested_recorded_at->format(DATE_ATOM)) : null,
                $now,
                $threshold,
            );
            return [
                'key' => (string) $row->dimension_value,
                'event_count' => $count,
                'error_count' => $errors,
                'critical_count' => (int) $row->critical_count,
                'error_rate' => $count > 0 ? round($errors / $count, 6) : 0.0,
                'last_event_at' => $row->last_event_at,
                'projection' => $projection,
                'status' => ((int) $row->critical_count) > 0 ? 'degraded' : ($errors > 0 ? 'warning' : (($projection['status'] ?? 'healthy') === 'degraded' ? 'stale' : 'active')),
            ];
        }, $rows);
    }

    /** @return array<string,mixed> */
    private function projectionHealth(string $scope, int $tenantKey, DateTimeImmutable $now): array
    {
        if (! Schema::hasTable('titan_signal_pulse_projection_freshness')) {
            return ['status' => 'not_initialized', 'last_projection_at' => null, 'latest_projected_recorded_at' => null, 'projection_lag_seconds' => null];
        }
        $row = SignalPulseProjectionFreshness::query()->where('scope', $scope)->where('tenant_key', $tenantKey)->where('dimension', 'all')->where('dimension_value', '__all__')->first();
        $threshold = (int) config('titan-signal-engine.pulse_projection_degraded_after_seconds', 300);
        $freshness = $row === null
            ? PulseProjectionFreshness::evaluate(null, null, null, $now, $threshold)
            : PulseProjectionFreshness::evaluate(
                $row->last_projected_at ? new DateTimeImmutable($row->last_projected_at->format(DATE_ATOM)) : null,
                $row->last_recorded_at ? new DateTimeImmutable($row->last_recorded_at->format(DATE_ATOM)) : null,
                $row->last_ingested_recorded_at ? new DateTimeImmutable($row->last_ingested_recorded_at->format(DATE_ATOM)) : null,
                $now,
                $threshold,
            );
        $recentStart = $now->modify('-5 minutes');
        $recentEventCount = Schema::hasTable('titan_signal_pulse_rollups')
            ? (int) SignalPulseRollup::query()->where('scope', $scope)->where('tenant_key', $tenantKey)->where('granularity', 'minute')->where('dimension', 'all')->where('dimension_value', '__all__')->whereBetween('bucket_start', [$recentStart, $now])->sum('event_count')
            : 0;
        return [...$freshness, 'events_last_5_minutes' => $recentEventCount, 'scope' => $scope, 'tenant_key' => $tenantKey];
    }

}
