<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\LearningSinkContract;
use App\Extensions\TitanAutonomy\System\Services\RewindCorrelationService;
use Illuminate\Support\Facades\DB;

final class DatabaseLearningSink implements LearningSinkContract
{
    public function __construct(private readonly ?RewindCorrelationService $rewind = null) {}
    public function record(array $event): string
    {
        return (string) app(\Illuminate\Database\DatabaseManager::class)->transaction(function () use ($event): int {
            $id = (int) app(\Illuminate\Database\DatabaseManager::class)->table('titan_learning_events')->insertGetId([
                'tenant_company_id' => $event['tenant_company_id'],
                'user_id' => $event['user_id'] ?? null,
                'capability' => $event['capability'],
                'workflow_key' => $event['workflow_key'] ?? '',
                'risk' => $event['risk'],
                'autonomy_level' => $event['autonomy_level'],
                'context_json' => $this->json($event['context'] ?? null),
                'proposal_json' => $this->json($event['proposal'] ?? null),
                'user_response_json' => $this->json($event['user_response'] ?? null),
                'final_action_json' => $this->json($event['final_action'] ?? null),
                'outcome_json' => $this->json($event['outcome'] ?? null),
                'learning_label' => $event['learning_label'],
                'learning_scopes_json' => $this->json($event['learning_scopes'] ?? []),
                'material_edit' => (bool) ($event['material_edit'] ?? false),
                'success' => (bool) ($event['success'] ?? false),
                'reversed' => (bool) ($event['reversed'] ?? false),
                'confidence' => $event['confidence'] ?? null,
                'policy_version' => $event['policy_version'] ?? null,
                'correlation_id' => $event['correlation_id'] ?? null,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            foreach ((array) ($event['quality_signals'] ?? []) as $signal => $score) {
                if ($score === null) continue;
                app(\Illuminate\Database\DatabaseManager::class)->table('titan_learning_outcomes')->insert([
                    'learning_event_id' => $id,
                    'signal' => (string) $signal,
                    'score' => is_numeric($score) ? (float) $score : null,
                    'details_json' => is_numeric($score) ? null : $this->json(['value' => $score]),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }

            $this->rewind?->record('learning.outcome', [
                'learning_event_id' => $id,
                'tenant_company_id' => $event['tenant_company_id'],
                'user_id' => $event['user_id'] ?? null,
                'capability' => $event['capability'],
                'workflow_key' => $event['workflow_key'] ?? '',
                'learning_label' => $event['learning_label'],
                'material_edit' => (bool) ($event['material_edit'] ?? false),
                'reversed' => (bool) ($event['reversed'] ?? false),
                'correlation_id' => $event['correlation_id'] ?? null,
            ]);
            return $id;
        });
    }

    private function json(mixed $value): ?string
    {
        return $value === null ? null : json_encode($value, JSON_THROW_ON_ERROR);
    }
}
