<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if(!Schema::hasTable('titan_autonomy_execution_receipts')){
            Schema::create('titan_autonomy_execution_receipts',function(Blueprint $table):void{
                $table->bigIncrements('id');
                $table->char('public_id',26)->unique();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->string('capability',120)->index();
                $table->string('workflow_key',120)->default('');
                $table->string('risk',16);
                $table->string('autonomy_level',24);
                $table->string('correlation_id',96)->index();
                $table->string('interaction_id',120)->nullable()->index();
                $table->string('session_id',120)->nullable()->index();
                $table->string('idempotency_key',160)->nullable()->index();
                $table->string('command_status',32);
                $table->json('command_payload_json')->nullable();
                $table->json('command_result_json')->nullable();
                $table->json('context_json')->nullable();
                $table->json('assurance_at_execution_json')->nullable();
                $table->json('postcondition_at_execution_json')->nullable();
                $table->string('observation_status',24)->default('observing')->index();
                $table->string('final_label',40)->nullable()->index();
                $table->json('final_reason_codes_json')->nullable();
                $table->json('postcondition_at_reconciliation_json')->nullable();
                $table->json('assurance_at_reconciliation_json')->nullable();
                $table->string('feedback_ref',80)->nullable()->index();
                $table->string('learning_ref',80)->nullable()->index();
                $table->string('gate_ref',80)->nullable()->index();
                $table->string('regression_ref',80)->nullable()->index();
                $table->timestamp('matures_at')->nullable()->index();
                $table->timestamp('finalized_at')->nullable();
                $table->string('policy_version',64);
                $table->timestamps();
                $table->unique(['tenant_company_id','correlation_id'],'titan_autonomy_execution_receipt_unique');
            });
        }
        if(!Schema::hasTable('titan_autonomy_execution_feedback')){
            Schema::create('titan_autonomy_execution_feedback',function(Blueprint $table):void{
                $table->bigIncrements('id');
                $table->char('public_id',26)->unique();
                $table->char('receipt_public_id',26)->index();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->string('source',32);
                $table->string('classification',40)->index();
                $table->boolean('material_edit')->default(false);
                $table->json('details_json')->nullable();
                $table->string('policy_version',64);
                $table->timestamps();
            });
        }
    }
    public function down(): void
    {
        Schema::dropIfExists('titan_autonomy_execution_feedback');
        Schema::dropIfExists('titan_autonomy_execution_receipts');
    }
};
