<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\{CrmCompanyContextResolver,CrmCompanyScope};
use DomainException;
use Illuminate\Contracts\Filesystem\Factory as FilesystemFactory;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;
use Throwable;

final class SalesDocumentRenderQueueService
{
    public function __construct(
        private readonly ConnectionInterface $db,
        private readonly SalesDocumentPdfService $pdf,
        private readonly FilesystemFactory $filesystems,
        private readonly CrmCompanyScope $scope,
        private readonly CrmCompanyContextResolver $contexts,
    ) {}

    /** @return array<string,mixed> */
    public function request(int $actorUserId,string $type,string $documentPublicId,string $idempotencyKey=''): array
    {
        $this->assertType($type);
        $tenant=CrmCompanyScope::companyId($actorUserId);
        $table='crm_'.$type;
        $doc=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$documentPublicId)->whereNull('deleted_at')->first();
        if(!$doc)throw new InvalidArgumentException('Sales document not found.');

        $sourceHash=(string)($doc->issued_snapshot_hash??$doc->snapshot_hash??'');
        if($sourceHash==='')throw new DomainException('Document cannot be rendered until a source snapshot hash exists.');
        $renderer=(string)config('crm.documents.renderer_version','dompdf-v1');
        $template=(string)config('crm.documents.template_version','crm-sales-v1');
        $disk=(string)config('crm.documents.disk','local');
        $idem=$idempotencyKey!==''?hash('sha256',implode('|',[$tenant,$type,$documentPublicId,$sourceHash,$idempotencyKey])):hash('sha256',implode('|',[$tenant,$type,$documentPublicId,$sourceHash,$renderer,$template]));

        $existing=$this->db->table('crm_sales_document_render_jobs')->where('company_id',$tenant)->where('idempotency_key',$idem)->first();
        if($existing)return $this->publicView((array)$existing);
        $sameArtifact=$this->db->table('crm_sales_document_render_jobs')->where('company_id',$tenant)->where('document_type',$type)->where('document_public_id',$documentPublicId)->where('source_snapshot_hash',$sourceHash)->where('renderer_version',$renderer)->where('template_version',$template)->whereIn('status',['requested','rendering','ready'])->orderByDesc('id')->first();
        if($sameArtifact)return $this->publicView((array)$sameArtifact);

        $id=(string)Str::ulid();$now=now();
        $this->db->table('crm_sales_document_render_jobs')->insert([
            'public_id'=>$id,'company_id'=>$tenant,'user_id'=>CrmCompanyScope::actorUserId($actorUserId),
            'document_type'=>$type,'document_public_id'=>$documentPublicId,'idempotency_key'=>$idem,'status'=>'requested',
            'source_snapshot_hash'=>$sourceHash,'renderer_version'=>$renderer,'template_version'=>$template,'storage_disk'=>$disk,
            'attempts'=>0,'requested_at'=>$now,'available_at'=>$now,'created_at'=>$now,'updated_at'=>$now,
        ]);
        $this->db->table($table)->where('company_id',$tenant)->where('public_id',$documentPublicId)->update([
            'document_generation_status'=>'requested','document_generation_error'=>null,'updated_at'=>$now,
        ]);
        return $this->publicView((array)$this->db->table('crm_sales_document_render_jobs')->where('public_id',$id)->first());
    }

    /** @return array<string,mixed> */
    public function status(int $actorUserId,string $jobPublicId): array
    {
        $tenant=CrmCompanyScope::companyId($actorUserId);
        $row=$this->db->table('crm_sales_document_render_jobs')->where('company_id',$tenant)->where('public_id',$jobPublicId)->first();
        if(!$row)throw new InvalidArgumentException('Document render job not found.');
        return $this->publicView((array)$row);
    }

    /** @return array{processed:int,ready:int,failed:int,skipped:int} */
    public function processPending(int $limit=25): array
    {
        $limit=max(1,min(100,$limit));$processed=0;$ready=0;$failed=0;$skipped=0;
        $stale=now()->subSeconds(max(30,(int)config('crm.documents.claim_timeout_seconds',300)));
        $ids=$this->db->table('crm_sales_document_render_jobs')
            ->where('attempts','<',(int)config('crm.documents.max_attempts',3))
            ->where(function($q)use($stale):void{
                $q->where(function($qq):void{$qq->whereIn('status',['requested','failed'])->where(fn($due)=>$due->whereNull('available_at')->orWhere('available_at','<=',now()));})
                  ->orWhere(function($qq)use($stale):void{$qq->where('status','rendering')->whereNotNull('started_at')->where('started_at','<',$stale);});
            })->orderBy('id')->limit($limit)->pluck('id')->all();
        foreach($ids as $id){
            try{
                $claimed=$this->processOne((int)$id,$stale);
                if(!$claimed){$skipped++;continue;}
                $processed++;$ready++;
            }catch(Throwable){$processed++;$failed++;}
        }
        return compact('processed','ready','failed','skipped');
    }

    /** @return array<string,mixed> */
    public function artifact(int $actorUserId,string $type,string $documentPublicId): array
    {
        $this->assertType($type);$tenant=CrmCompanyScope::companyId($actorUserId);
        $job=$this->db->table('crm_sales_document_render_jobs')->where('company_id',$tenant)
            ->where('document_type',$type)->where('document_public_id',$documentPublicId)->where('status','ready')->orderByDesc('id')->first();
        if(!$job)return [];
        $disk=$this->filesystems->disk((string)$job->storage_disk);$path=(string)$job->storage_path;
        if($path===''||!$disk->exists($path))return [];
        return [
            'job_public_id'=>$job->public_id,'bytes'=>$disk->get($path),'filename'=>basename($path),
            'output_hash'=>$job->output_hash,'storage_disk'=>$job->storage_disk,'storage_path'=>$path,
        ];
    }

    public function download(int $actorUserId,string $type,string $documentPublicId)
    {
        $artifact=$this->artifact($actorUserId,$type,$documentPublicId);
        if($artifact===[])throw new DomainException('Document PDF is not ready. Request rendering first.');
        return response($artifact['bytes'],200,[
            'Content-Type'=>'application/pdf',
            'Content-Disposition'=>'attachment; filename="'.$artifact['filename'].'"',
            'ETag'=>'"'.(string)$artifact['output_hash'].'"',
        ]);
    }

    private function processOne(int $id, $stale): bool
    {
        $job=$this->db->transaction(function()use($id,$stale){
            $row=$this->db->table('crm_sales_document_render_jobs')->where('id',$id)->lockForUpdate()->first();
            if(!$row)return null;
            $due=in_array((string)$row->status,['requested','failed'],true)&&($row->available_at===null||strtotime((string)$row->available_at)<=time());
            $staleClaim=(string)$row->status==='rendering'&&$row->started_at!==null&&strtotime((string)$row->started_at)<strtotime((string)$stale);
            if(!$due&&!$staleClaim)return null;
            $now=now();
            $this->db->table('crm_sales_document_render_jobs')->where('id',$id)->update([
                'status'=>'rendering','attempts'=>(int)$row->attempts+1,'started_at'=>$now,'failed_at'=>null,'last_error'=>null,'updated_at'=>$now,
            ]);
            return (array)$row;
        });
        if(!$job)return false;
        $table='crm_'.$job['document_type'];
        try{
            $current=$this->db->table($table)->where('company_id',$job['company_id'])->where('public_id',$job['document_public_id'])->first();
            if(!$current)throw new DomainException('Sales document disappeared before rendering.');
            $currentHash=(string)($current->issued_snapshot_hash??$current->snapshot_hash??'');
            if($currentHash!==$job['source_snapshot_hash'])throw new DomainException('Document source changed after render was requested. Request a new render.');

            $trusted=$this->contexts->fromTrustedPlatform((int)$job['company_id'],(int)$job['user_id'],'system',permissions:['crm.sales.view'],sourceSurface:'crm_document_renderer',membershipVerified:true);
            $bytes=$this->scope->runWith($trusted,fn()=>$this->pdf->render((int)$job['user_id'],(string)$job['document_type'],(string)$job['document_public_id']));
            $hash=hash('sha256',$bytes);$filename=$this->pdf->filename((string)$job['document_type'],(array)$current);
            $path='crm/documents/'.$job['company_id'].'/'.$job['document_type'].'/'.$job['document_public_id'].'/'.$job['source_snapshot_hash'].'/'.$filename;
            $this->filesystems->disk((string)$job['storage_disk'])->put($path,$bytes);
            $now=now();
            $this->db->table('crm_sales_document_render_jobs')->where('id',$id)->update([
                'status'=>'ready','storage_path'=>$path,'output_hash'=>$hash,'completed_at'=>$now,'available_at'=>null,'last_error'=>null,'updated_at'=>$now,
            ]);
            $this->db->table($table)->where('company_id',$job['company_id'])->where('public_id',$job['document_public_id'])->update([
                'document_generation_status'=>'ready','document_generation_error'=>null,'document_hash'=>$hash,'document_generated_at'=>$now,
                'renderer_version'=>$job['renderer_version'],'template_version'=>$job['template_version'],'updated_at'=>$now,
            ]);
            return true;
        }catch(Throwable $e){
            $now=now();$message=mb_substr($e->getMessage(),0,2000);
            $attempt=(int)$this->db->table('crm_sales_document_render_jobs')->where('id',$id)->value('attempts');
            $delay=max(10,(int)config('crm.documents.retry_base_seconds',30))*(2**max(0,min($attempt-1,6)));
            $this->db->table('crm_sales_document_render_jobs')->where('id',$id)->update(['status'=>'failed','failed_at'=>$now,'available_at'=>$now->copy()->addSeconds($delay),'last_error'=>$message,'updated_at'=>$now]);
            $this->db->table($table)->where('company_id',$job['company_id'])->where('public_id',$job['document_public_id'])->update(['document_generation_status'=>'failed','document_generation_error'=>$message,'updated_at'=>$now]);
            throw $e;
        }
    }

    /** @param array<string,mixed> $row @return array<string,mixed> */
    private function publicView(array $row): array
    {
        return array_intersect_key($row,array_flip([
            'public_id','document_type','document_public_id','status','source_snapshot_hash','renderer_version','template_version','output_hash','attempts',
            'requested_at','started_at','completed_at','failed_at','last_error','created_at','updated_at',
        ]));
    }

    private function assertType(string $type): void
    {
        if(!in_array($type,['proposals','estimates','invoices'],true))throw new InvalidArgumentException('Unsupported render document type.');
    }
}
