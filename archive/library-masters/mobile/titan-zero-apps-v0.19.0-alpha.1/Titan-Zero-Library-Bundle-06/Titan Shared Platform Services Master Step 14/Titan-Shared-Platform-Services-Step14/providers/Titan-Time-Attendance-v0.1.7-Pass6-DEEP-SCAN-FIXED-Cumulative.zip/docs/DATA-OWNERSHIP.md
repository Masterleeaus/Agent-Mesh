# Data Ownership

This extension owns only its declared `titan-time-attendance` domain state. It does not own Titan AI Workforce employees, organisational roles, hierarchy, teams, responsibilities, assignments or work items.
