<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Support;

final class TitanKnowledgeAuthorityNavigation
{
    public const USER_KEY = 'titan_knowledge_authority';
    public const ADMIN_KEY = 'titan_knowledge_authority_admin';
    public const PRIORITY = 460;

    /** @return array<int, array<string, mixed>> */
    public static function user(): array
    {
        return [[
            'key' => self::USER_KEY,
            'label' => 'Knowledge Authority',
            'route' => 'dashboard.user.titan.knowledge.authority.index',
            'icon' => 'tabler-folders',
            'order' => self::PRIORITY,
        ]];
    }

    /** @return array<int, array<string, mixed>> */
    public static function admin(): array
    {
        return [[
            'key' => self::ADMIN_KEY,
            'label' => 'Knowledge Authority',
            'route' => 'dashboard.admin.titan.knowledge.authority.index',
            'icon' => 'tabler-folders',
            'order' => self::PRIORITY,
        ]];
    }

    /** Default contribution used by hosts that instantiate a contributor class. */
    public function __invoke(): array
    {
        return self::user();
    }
}
