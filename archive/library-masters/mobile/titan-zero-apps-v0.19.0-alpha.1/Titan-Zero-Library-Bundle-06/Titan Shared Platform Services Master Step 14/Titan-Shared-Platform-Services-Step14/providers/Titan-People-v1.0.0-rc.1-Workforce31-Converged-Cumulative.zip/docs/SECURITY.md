# Security

`tenant_company_id` is derived from authenticated Titan context and is required on all People-owned persistence. Caller-supplied tenant IDs are not authority. Authorization is deny-by-default. HR documents will use private storage in later passes. Pass 1 has no state-changing API endpoints.

## Pass 2 sensitive-data controls

People models do not mass-assign `tenant_company_id`. Sensitive profile fields use field-level policy. HR document uploads reject path traversal, zero/oversized files, disallowed MIME types and PDF/JPEG/PNG byte-signature mismatches. Document bytes are written with private visibility and the storage adapter exposes no URL-generation API. Document access must re-check authenticated tenant scope before content is read or streamed.
