<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\ExecutionReceiptStoreContract;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class DatabaseExecutionReceiptStore implements ExecutionReceiptStoreContract
{
    public function create(array $receipt): string
    {
        $tenant = (int)$receipt['tenant_company_id'];
        $correlation = trim((string)$receipt['correlation_id']);
        $capability = (string)$receipt['capability'];
        $existing = app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_execution_receipts')
            ->where('tenant_company_id',$tenant)->where('correlation_id',$correlation)->first();
        if ($existing) {
            if ((string)$existing->capability !== $capability) throw new \RuntimeException('CORRELATION_CAPABILITY_COLLISION');
            return (string)$existing->public_id;
        }

        $id=(string)Str::ulid();
        app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_execution_receipts')->insert([
            'public_id'=>$id,
            'tenant_company_id'=>$tenant,
            'user_id'=>$receipt['user_id']??null,
            'capability'=>$capability,
            'workflow_key'=>(string)($receipt['workflow_key']??''),
            'risk'=>(string)$receipt['risk'],
            'autonomy_level'=>(string)$receipt['autonomy_level'],
            'correlation_id'=>$correlation,
            'interaction_id'=>$receipt['interaction_id']??null,
            'session_id'=>$receipt['session_id']??null,
            'idempotency_key'=>$receipt['idempotency_key']??null,
            'command_status'=>(string)($receipt['command_status']??'unknown'),
            'command_payload_json'=>$this->json($receipt['command_payload']??[]),
            'command_result_json'=>$this->json($receipt['command_result']??[]),
            'context_json'=>$this->json($receipt['context']??[]),
            'assurance_at_execution_json'=>$this->json($receipt['assurance_at_execution']??[]),
            'postcondition_at_execution_json'=>$this->json($receipt['postcondition_at_execution']??[]),
            'observation_status'=>(string)($receipt['observation_status']??'observing'),
            'matures_at'=>$receipt['matures_at']??null,
            'policy_version'=>(string)($receipt['policy_version']??'unknown'),
            'created_at'=>now(),'updated_at'=>now(),
        ]);
        return $id;
    }

    public function findByCorrelation(int $tenantCompanyId, string $correlationId): ?array
    {
        $row=app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_execution_receipts')
            ->where('tenant_company_id',$tenantCompanyId)->where('correlation_id',trim($correlationId))->orderByDesc('id')->first();
        return $row?$this->normalise((array)$row):null;
    }

    public function due(int $limit=100): array
    {
        return array_map(fn($r)=>$this->normalise((array)$r),app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_execution_receipts')
            ->where('observation_status','observing')->whereNotNull('matures_at')->where('matures_at','<=',now())
            ->orderBy('matures_at')->limit(max(1,min(500,$limit)))->get()->all());
    }

    public function finalize(string $publicId,array $fields): void
    {
        $allowed=['final_label','feedback_ref','learning_ref','gate_ref','regression_ref','finalized_at','final_reason_codes','postcondition_at_reconciliation','assurance_at_reconciliation'];
        $update=['observation_status'=>'finalized','updated_at'=>now()];
        foreach($allowed as $key){if(!array_key_exists($key,$fields))continue;$column=match($key){'final_reason_codes'=>'final_reason_codes_json','postcondition_at_reconciliation'=>'postcondition_at_reconciliation_json','assurance_at_reconciliation'=>'assurance_at_reconciliation_json',default=>$key};$value=$fields[$key];if(str_ends_with($column,'_json'))$value=$this->json($value);$update[$column]=$value;}
        app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_execution_receipts')->where('public_id',$publicId)->update($update);
    }

    public function appendFeedback(string $publicId,array $feedback): string
    {
        $id=(string)Str::ulid();
        app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_execution_feedback')->insert([
            'public_id'=>$id,
            'receipt_public_id'=>$publicId,
            'tenant_company_id'=>(int)$feedback['tenant_company_id'],
            'user_id'=>$feedback['user_id']??null,
            'source'=>(string)($feedback['source']??'system'),
            'classification'=>(string)$feedback['classification'],
            'material_edit'=>(bool)($feedback['material_edit']??false),
            'details_json'=>$this->json($feedback['details']??[]),
            'policy_version'=>(string)($feedback['policy_version']??'unknown'),
            'created_at'=>now(),'updated_at'=>now(),
        ]);
        return $id;
    }

    private function normalise(array $row): array
    {
        foreach($row as $key=>$value){if(str_ends_with($key,'_json')&&is_string($value)&&$value!==''){$decoded=json_decode($value,true);if(json_last_error()===JSON_ERROR_NONE)$row[substr($key,0,-5)]=$decoded;}}
        return $row;
    }

    private function json(mixed $value): ?string {return $value===null?null:json_encode($value,JSON_THROW_ON_ERROR);}
}
