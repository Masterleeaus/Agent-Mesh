<?php

declare(strict_types=1);
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
  Schema::table('crm_projects',function(Blueprint $t){$t->char('company_public_id',26)->nullable()->index();$t->char('deal_public_id',26)->nullable()->index();$t->text('description')->nullable();$t->date('starts_on')->nullable();$t->date('due_on')->nullable();});
  Schema::table('crm_tasks',function(Blueprint $t){$t->char('project_public_id',26)->nullable()->index();$t->timestamp('due_at')->nullable()->index();$t->unsignedBigInteger('assigned_user_id')->nullable()->index();});
  Schema::table('crm_events',function(Blueprint $t){$t->timestamp('starts_at')->nullable()->index();$t->timestamp('ends_at')->nullable();$t->boolean('all_day')->default(false);$t->string('external_provider',60)->nullable()->index();$t->string('external_event_id')->nullable()->index();});
  foreach(['proposals','estimates','invoices'] as $type){Schema::create('crm_'.$type,function(Blueprint $t){$t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('user_id')->index();$t->char('company_public_id',26)->nullable()->index();$t->char('contact_public_id',26)->nullable()->index();$t->string('number',80)->nullable()->index();$t->string('title');$t->string('status',40)->default('draft')->index();$t->string('currency',3)->default('AUD');$t->bigInteger('subtotal_minor')->default(0);$t->bigInteger('tax_minor')->default(0);$t->bigInteger('total_minor')->default(0);$t->timestamp('due_at')->nullable()->index();$t->json('meta')->nullable();$t->timestamps();$t->softDeletes();});}
 }
 public function down(): void { foreach(['crm_invoices','crm_estimates','crm_proposals'] as $table)Schema::dropIfExists($table); }
};
