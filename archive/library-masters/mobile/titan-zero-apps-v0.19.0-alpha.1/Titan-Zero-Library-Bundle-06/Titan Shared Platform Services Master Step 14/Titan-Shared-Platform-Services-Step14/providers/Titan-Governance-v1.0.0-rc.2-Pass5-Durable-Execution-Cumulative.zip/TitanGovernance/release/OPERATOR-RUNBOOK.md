# Titan Governance v1.0.0-rc.1 — Operator Runbook

## Install order
Required before Governance can be fully operational: Titan Signal, Titan Command Bus and Titan Autonomy at the manifest floors. Risk, Assurance, Rewind, Wisdom, Knowledge Authority, Shield, Model Council and AI Workforce are optional observers and should degrade visibly when absent.

## Installer 1.7.6 validation
The root manifest deliberately includes both MagicAI host-facing legacy fields (`name`, `type`, `description`, `support_telegram`) and Titan fields. Do not strip the legacy fields during future Blueprint regeneration. Run:

```bash
php tests/Contract/installer_176_manifest_contract.php
php tools/fresh_install_preflight.php
```

## Runtime adapters
Bind `TITAN_GOVERNANCE_COMMAND_GATEWAY_CLASS` to the installed Command Bus bridge. Bind read/evidence adapter environment keys only to implementations of the Governance public contracts. Missing required adapters fail closed; optional adapters report degraded/not-installed state.

## Incident handling
- `COMMAND_BUS_UNAVAILABLE`: do not perform the business mutation manually through Governance; restore the bridge and retry the same operation ID.
- Invalid authority order: investigate Titan Autonomy source state; Governance must not rewrite scores.
- Stale required evidence: restore source freshness; do not treat stale as current.
- Rewind unavailable: Decision Intelligence remains usable but forensic reconstruction is explicitly incomplete.
- Installer integrity mismatch: inspect hidden files (`.gitkeep`, `.DS_Store`, `.env`, `.git`) and regenerate integrity from visible packaged files; never bypass integrity.

## Release truth
Package certification proves static/fresh-archive properties only. Live installer, migration, boot, navigation, authorization, runtime, upgrade and uninstall stages remain separate exact-host gates.

## Installer dependency policy

Installer 1.7.6 hard dependency: `titan-autonomy >=0.1`.

Installer-optional but runtime-required peers: `titan-signal >=0.2.0` and `titan-command-bus >=0.2.0-alpha.1`. Governance may install without them, but health remains degraded and consequential dispatch remains fail closed until trusted adapters are bound.
## Installer 1.7.6 H2 migration note
The H2 ZIP is restart-safe for the observed migration-000004 MySQL 1059 failure. Do not manually delete Governance columns before retrying; the migration detects existing columns/indexes and fills only missing schema elements.

