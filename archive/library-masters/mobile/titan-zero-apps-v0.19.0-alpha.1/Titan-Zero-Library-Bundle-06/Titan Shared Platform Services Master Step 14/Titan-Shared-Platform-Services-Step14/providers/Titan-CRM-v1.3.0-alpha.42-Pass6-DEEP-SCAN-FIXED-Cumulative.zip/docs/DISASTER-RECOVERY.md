# Disaster Recovery

Restore extension-owned durable state from platform backups, then reconcile projections, outboxes and execution receipts before returning to readiness.
