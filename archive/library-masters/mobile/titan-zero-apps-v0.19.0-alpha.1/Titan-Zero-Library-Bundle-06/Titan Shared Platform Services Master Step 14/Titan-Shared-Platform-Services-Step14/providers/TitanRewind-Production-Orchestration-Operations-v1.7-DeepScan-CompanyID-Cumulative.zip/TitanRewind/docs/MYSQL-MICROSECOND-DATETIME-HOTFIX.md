# Titan Rewind v1.0.3 — MySQL Microsecond DATETIME Migration Hotfix

## Live-host failure

Titan Extension Manager 1.7.8 successfully validated, verified, backed up and deployed v1.0.2, then failed during scoped migrations on MySQL with error 1067 for `titan_rewind_source_watermarks.checked_at`.

The failing migration used a required `TIMESTAMP(6)` column. On MySQL configurations that retain legacy implicit TIMESTAMP default behaviour while strict/zero-date SQL modes are enabled, a non-null precision TIMESTAMP can be assigned an implicit zero default and rejected as an invalid default value.

## Fix

All Rewind-owned custom precision timestamp declarations have been converted from Laravel `timestamp(..., 6)` to `dateTime(..., 6)`.

This preserves microsecond precision and the same application-level date/time semantics while avoiding MySQL TIMESTAMP implicit-default behaviour. Standard Laravel `$table->timestamps()` columns remain unchanged.

Affected migration families include foundation events, product timeline/replay, forensics, evidence/recovery, source watermarks/custody/legal holds, resilience/observability/Signal, and forensic data-governance/retention records.

## Retry safety

The migration that failed live already guards added columns with `Schema::hasColumn()` and created tables with `Schema::hasTable()`. Therefore a retry remains safe if MySQL committed earlier DDL statements from the failed migration before the scoped migration runner attempted rollback.

## Verification boundary

This package statically verifies that no Rewind migration retains a precision-qualified `TIMESTAMP`/`TIMESTAMPTZ` declaration. A real MySQL migration is still verified only by the target Titan host when the package is installed.
