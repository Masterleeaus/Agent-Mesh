<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

use App\Extensions\TitanConnect\System\Models\ChannelConnection;

interface CredentialVault
{
    public function credentials(int $companyId, ChannelConnection $connection): array;
}
