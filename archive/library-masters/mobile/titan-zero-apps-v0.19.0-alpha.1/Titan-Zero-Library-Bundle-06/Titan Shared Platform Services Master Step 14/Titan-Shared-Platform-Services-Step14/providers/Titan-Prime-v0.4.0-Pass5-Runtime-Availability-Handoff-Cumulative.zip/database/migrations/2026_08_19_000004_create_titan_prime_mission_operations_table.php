<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_prime_mission_operations')) {
            return;
        }

        Schema::create('titan_prime_mission_operations', static function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('tenant_company_id');
            $table->string('operation_id', 100);
            $table->string('mission_id', 80);
            $table->string('operation_type', 40);
            $table->char('payload_hash', 64);
            $table->json('receipt_json');
            $table->timestamp('expires_at');
            $table->timestamps();

            $table->unique(['tenant_company_id', 'operation_id'], 'tpmop_tenant_operation_uq');
            $table->index(['tenant_company_id', 'mission_id'], 'tpmop_tenant_mission_idx');
            $table->index(['tenant_company_id', 'expires_at'], 'tpmop_tenant_expiry_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_prime_mission_operations');
    }
};
