<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\DecisionIntelligence;

use DateTimeImmutable;
use Throwable;

final class GovernancePolicyComplianceProjector
{
    /** @return array<string,mixed> */
    public function project(array $inspection,array $context=[]):array
    {
        if(($inspection['status']??null)==='NOT_FOUND') return ['schema_version'=>'1.0','status'=>'NOT_FOUND','items'=>[],'stale_count'=>0,'expired_count'=>0,'unavailable_source_count'=>0];
        $now=$this->now($context);$staleAfter=max(1,(int)($context['stale_after_seconds']??900));
        $items=[];$stale=0;$expired=0;$unavailable=0;
        foreach(is_array($inspection['sources']??null)?$inspection['sources']:[] as $sourceKey=>$source){
            if(!is_array($source)) continue;
            $sourceStatus=strtoupper(trim((string)($source['status']??'UNAVAILABLE')));
            if(!in_array($sourceStatus,['HEALTHY','DEGRADED','STALE'],true)) $unavailable++;
            foreach(array_slice(is_array($source['policies']??null)?$source['policies']:[],0,100) as $policy){
                if(!is_array($policy)) continue;
                $policyId=trim((string)($policy['policy_id']??$policy['policy_key']??''));if($policyId==='') continue;
                $status=strtoupper(trim((string)($policy['status']??'UNKNOWN')));if($status==='')$status='UNKNOWN';
                $severity=strtoupper(trim((string)($policy['severity']??'INFO')));if(!in_array($severity,['INFO','LOW','MEDIUM','HIGH','CRITICAL'],true))$severity='INFO';
                $observed=$this->date($policy['observed_at']??null);$expires=$this->date($policy['expires_at']??null);
                $isStale=$observed!==null && ($now->getTimestamp()-$observed->getTimestamp())>$staleAfter;
                $isExpired=$expires!==null && $expires->getTimestamp()<$now->getTimestamp();
                if($isStale)$stale++;if($isExpired)$expired++;
                $items[]=[
                    'source'=>(string)$sourceKey,'policy_id'=>$policyId,'policy_version'=>$policy['policy_version']??null,'status'=>$status,'severity'=>$severity,
                    'reason_codes'=>array_values(is_array($policy['reason_codes']??null)?$policy['reason_codes']:[]),
                    'evidence_refs'=>array_values(is_array($policy['evidence_refs']??null)?$policy['evidence_refs']:[]),
                    'observed_at'=>$policy['observed_at']??null,'expires_at'=>$policy['expires_at']??null,
                    'freshness'=>$isExpired?'EXPIRED':($isStale?'STALE':'CURRENT'),
                    'summary'=>$policy['summary']??null,
                ];
            }
        }
        usort($items,fn(array $a,array $b):int=>$this->priority($b)<=>$this->priority($a) ?: strcmp((string)$a['policy_id'],(string)$b['policy_id']));
        $status='HEALTHY';
        if($items===[]) $status='UNAVAILABLE';
        elseif(array_filter($items,fn(array $row):bool=>in_array($row['status'],['VIOLATED','NON_COMPLIANT','FAILED','BLOCKED','POLICY_BLOCKED'],true))) $status='NON_COMPLIANT';
        elseif($stale>0||$expired>0||$unavailable>0) $status='DEGRADED';
        return ['schema_version'=>'1.0','status'=>$status,'items'=>$items,'stale_count'=>$stale,'expired_count'=>$expired,'unavailable_source_count'=>$unavailable,'observed_at'=>$now->format(DATE_ATOM)];
    }

    private function priority(array $row):int
    {
        $severity=['INFO'=>0,'LOW'=>10,'MEDIUM'=>20,'HIGH'=>30,'CRITICAL'=>40][$row['severity']]??0;
        $blocking=in_array($row['status'],['VIOLATED','NON_COMPLIANT','FAILED','BLOCKED','POLICY_BLOCKED'],true)?100:0;
        $freshness=($row['freshness']==='EXPIRED'?20:($row['freshness']==='STALE'?10:0));
        return $blocking+$severity+$freshness;
    }
    private function now(array $context):DateTimeImmutable{if(is_string($context['now']??null)){try{return new DateTimeImmutable($context['now']);}catch(Throwable){}}return new DateTimeImmutable('now');}
    private function date(mixed $value):?DateTimeImmutable{if(!is_string($value)||trim($value)==='')return null;try{return new DateTimeImmutable($value);}catch(Throwable){return null;}}
}
