<?php

declare(strict_types=1);

function rgAssert(bool $condition, string $message): void {
    if (! $condition) throw new RuntimeException($message);
}
function rgInvalid(callable $fn, string $message): void {
    try { $fn(); } catch (InvalidArgumentException) { return; }
    throw new RuntimeException($message);
}

$required = [
    __DIR__ . '/../System/Data/SignalRegistryIdentity.php',
    __DIR__ . '/../System/Contracts/SignalRegistryAuthorityContract.php',
    __DIR__ . '/../System/Services/SignalRegistryAuthority.php',
    __DIR__ . '/../System/Services/RegistryOwnershipPolicy.php',
];
foreach ($required as $path) {
    rgAssert(is_file($path), 'Registry governance primitive missing: ' . basename($path));
}

require __DIR__ . '/../System/Data/SignalRegistryIdentity.php';
require __DIR__ . '/../System/Contracts/SignalRegistryAuthorityContract.php';
require __DIR__ . '/../System/Services/SignalRegistryAuthority.php';
require __DIR__ . '/../System/Services/RegistryOwnershipPolicy.php';

use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryIdentity;
use App\Extensions\TitanSignalEngine\System\Services\SignalRegistryAuthority;
use App\Extensions\TitanSignalEngine\System\Services\RegistryOwnershipPolicy;

$authority = new SignalRegistryAuthority('registry-test-secret', [
    'crm-service' => [
        'owner_source' => 'titan-crm',
        'permissions' => ['signal.registry.event.manage', 'signal.registry.subscription.manage'],
        'event_type_patterns' => ['crm.*'],
        'subscriber_key_patterns' => ['titan-crm.*'],
    ],
    'operator-service' => [
        'owner_source' => 'titan-signal-engine',
        'permissions' => ['signal.registry.override'],
        'event_type_patterns' => ['*'],
        'subscriber_key_patterns' => ['*'],
    ],
]);
$crm = $authority->issue('crm-service');
$policy = new RegistryOwnershipPolicy($authority);

rgAssert($crm->allowsEventType('crm.customer.created'), 'Registry actor must allow owned event family.');
rgAssert(! $crm->allowsEventType('command.executed'), 'Registry actor must not claim another event family.');
rgAssert($crm->allowsSubscriberKey('titan-crm.outcomes'), 'Registry actor must allow owned subscriber key family.');
rgAssert(! $crm->allowsSubscriberKey('titan-risk.outcomes'), 'Registry actor must not claim another subscriber key family.');

$policy->assertEventRegistration($crm, 'crm.customer.created', 'titan-crm', null);
$policy->assertSubscriberRegistration($crm, 'titan-crm.outcomes', null);
rgInvalid(fn () => $policy->assertEventRegistration($crm, 'command.executed', 'titan-command-bus', null), 'Cross-owner event registration must fail.');
rgInvalid(fn () => $policy->assertSubscriberRegistration($crm, 'titan-risk.outcomes', null), 'Cross-owner subscriber registration must fail.');
rgInvalid(fn () => $policy->assertEventRegistration($crm, 'crm.customer.created', 'titan-crm', 'other-service'), 'Existing event ownership cannot be taken over.');
rgInvalid(fn () => $policy->assertSubscriberRegistration($crm, 'titan-crm.outcomes', 'other-service'), 'Existing subscriber ownership cannot be taken over.');

$forged = new SignalRegistryIdentity(
    'crm-service',
    'titan-crm',
    ['signal.registry.event.manage'],
    ['crm.*'],
    ['titan-crm.*'],
    str_repeat('0', 64),
);
rgInvalid(fn () => $authority->assertTrusted($forged), 'Forged registry attestation must fail.');

$eventContract = file_get_contents(__DIR__ . '/../System/Contracts/EventTypeRegistryContract.php');
$subContract = file_get_contents(__DIR__ . '/../System/Contracts/SignalSubscriptionRegistryContract.php');
rgAssert($eventContract !== false && str_contains($eventContract, 'SignalRegistryIdentity $registrar'), 'Event registry writes must require registrar identity.');
rgAssert($eventContract !== false && str_contains($eventContract, 'function evolve('), 'Event registry must expose explicit schema evolution.');
rgAssert($eventContract !== false && str_contains($eventContract, 'function history('), 'Event registry must expose immutable history.');
rgAssert($subContract !== false && str_contains($subContract, 'SignalRegistryIdentity $registrar'), 'Subscription registry writes must require registrar identity.');
rgAssert($subContract !== false && str_contains($subContract, 'function evolve('), 'Subscription registry must expose explicit version evolution.');
rgAssert($subContract !== false && str_contains($subContract, 'function revalidate('), 'Subscription registry must expose quarantine revalidation.');

$eventRegistry = file_get_contents(__DIR__ . '/../System/Services/EventTypeRegistry.php');
$subscriptionRegistry = file_get_contents(__DIR__ . '/../System/Services/SignalSubscriptionRegistry.php');
rgAssert($eventRegistry !== false && ! str_contains($eventRegistry, 'updateOrCreate('), 'Event registry must not overwrite definitions in place.');
rgAssert($subscriptionRegistry !== false && ! str_contains($subscriptionRegistry, 'updateOrCreate('), 'Subscription registry must not overwrite definitions in place.');
rgAssert($subscriptionRegistry !== false && str_contains($subscriptionRegistry, 'quarantineSafely'), 'Broken subscribers must be quarantined instead of aborting discovery.');


$legacyTypeModel = file_get_contents(__DIR__ . '/../System/Models/SignalType.php');
$legacySubscriptionModel = file_get_contents(__DIR__ . '/../System/Models/SignalSubscription.php');
rgAssert($legacyTypeModel !== false && str_contains($legacyTypeModel, 'static::updating'), 'Legacy event-type rows must be read-only through ORM.');
rgAssert($legacySubscriptionModel !== false && str_contains($legacySubscriptionModel, 'static::updating'), 'Legacy subscription rows must be read-only through ORM.');

fwrite(STDOUT, "registry-governance-behavior: PASS\n");
