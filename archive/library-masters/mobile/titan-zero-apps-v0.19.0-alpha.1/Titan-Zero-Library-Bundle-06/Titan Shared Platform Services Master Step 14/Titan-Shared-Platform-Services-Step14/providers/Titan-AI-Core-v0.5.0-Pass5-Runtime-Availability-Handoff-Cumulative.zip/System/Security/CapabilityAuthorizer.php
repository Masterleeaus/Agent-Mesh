<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Security;

use App\Extensions\TitanAICore\System\DTO\ActorContext;
use App\Extensions\TitanAICore\System\Exceptions\SecurityContextException;

final class CapabilityAuthorizer
{
    public function assertAllowed(ActorContext $actor, string $capability, int $minimumAuthorityLevel = 0): void
    {
        if (!$actor->trusted) {
            throw new SecurityContextException('UNTRUSTED_ACTOR_CONTEXT', 'Actor context was not derived from a trusted principal.');
        }
        if (!$actor->authority->allows($capability)) {
            throw new SecurityContextException('CAPABILITY_DENIED', "Actor lacks required capability: {$capability}");
        }
        if ($actor->authority->level < $minimumAuthorityLevel) {
            throw new SecurityContextException('AUTHORITY_LEVEL_INSUFFICIENT', 'Actor authority level is below the required minimum.');
        }
    }
}
