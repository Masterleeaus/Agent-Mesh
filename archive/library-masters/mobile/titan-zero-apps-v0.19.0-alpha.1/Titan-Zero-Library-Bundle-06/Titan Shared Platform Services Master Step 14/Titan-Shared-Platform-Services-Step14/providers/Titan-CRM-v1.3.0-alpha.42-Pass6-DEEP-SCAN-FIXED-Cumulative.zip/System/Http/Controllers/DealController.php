<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Contracts\DealRepositoryContract;
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use App\Extensions\Crm\System\Http\Requests\{MarkDealLostRequest,MoveDealRequest,StoreDealRequest,UpdateDealRequest};
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class DealController extends Controller
{
    public function __construct(private DealRepositoryContract $deals, private CrmHumanMutationGateway $mutations) {}
    public function index(Request $request) { $records = $this->deals->search((int) $request->user()->id, $request->only(['q','status','pipeline_id','limit'])); return $request->expectsJson() ? response()->json(['data' => $records]) : view('crm::list', ['title' => 'Deals', 'records' => $records]); }
    public function store(StoreDealRequest $request) { $record=$this->mutations->execute($request,'crm.deal.create',$request->validated()); return $request->expectsJson()?response()->json($record,201):redirect()->route('dashboard.user.crm.deals.show',$record['public_id'])->with('status','Deal created.'); }
    public function update(UpdateDealRequest $request,string $deal) { $record=$this->mutations->execute($request,'crm.deal.update',$request->validated()+['public_id'=>$deal]); return $request->expectsJson()?response()->json($record):back()->with('status','Deal updated.'); }
    public function move(MoveDealRequest $request,string $deal) { $record=$this->mutations->execute($request,'crm.deal.move',$request->validated()+['public_id'=>$deal]); return $request->expectsJson()?response()->json($record):back()->with('status','Deal moved.'); }
    public function won(Request $request,string $deal) { $record=$this->mutations->execute($request,'crm.deal.win',['public_id'=>$deal]); return $request->expectsJson()?response()->json($record):back()->with('status','Deal marked won.'); }
    public function lost(MarkDealLostRequest $request,string $deal) { $record=$this->mutations->execute($request,'crm.deal.lose',['public_id'=>$deal,'reason'=>$request->validated('reason')]); return $request->expectsJson()?response()->json($record):back()->with('status','Deal marked lost.'); }
}
