<?php return ['name'=>'CRM','sales'=>'Sales','assistant'=>'CRM Assistant'];
