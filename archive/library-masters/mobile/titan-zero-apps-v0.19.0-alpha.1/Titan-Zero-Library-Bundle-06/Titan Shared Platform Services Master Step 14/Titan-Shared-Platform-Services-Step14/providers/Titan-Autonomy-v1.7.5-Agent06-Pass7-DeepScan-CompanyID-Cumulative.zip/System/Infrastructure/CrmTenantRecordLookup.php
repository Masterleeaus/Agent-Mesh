<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\TenantRecordLookupContract;
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

final class CrmTenantRecordLookup implements TenantRecordLookupContract
{
    private const TABLES = [
        'crm_contacts','crm_companies','crm_work_orders','crm_dispatch_assignments','crm_appointments',
        'crm_proposals','crm_estimates','crm_invoices',
    ];

    public function __construct(private readonly ConnectionInterface $db) {}

    public function find(string $table, int $tenantCompanyId, string $publicId): ?array
    {
        if (!in_array($table, self::TABLES, true)) throw new InvalidArgumentException('UNAPPROVED_POSTCONDITION_TABLE');
        $query = $this->db->table($table)->where('tenant_company_id', $tenantCompanyId)->where('public_id', $publicId);
        try { $query->whereNull('deleted_at'); } catch (\Throwable) {}
        $row = $query->first();
        return $row ? (array)$row : null;
    }
}
