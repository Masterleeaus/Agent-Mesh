<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Models;

use Illuminate\Database\Eloquent\Model;

final class NexusCompilationRecord extends Model
{
    protected $table = 'titan_nexus_compilations';

    protected $guarded = ['id'];

    protected $casts = [
        'tenant_company_id' => 'integer',
        'entity_version' => 'integer',
        'dry_run' => 'boolean',
        'payload' => 'array',
        'input_snapshot' => 'array',
        'compiled_configuration' => 'array',
        'validation_result' => 'array',
        'provisioning_plan' => 'array',
        'diff_summary' => 'array',
    ];
}
