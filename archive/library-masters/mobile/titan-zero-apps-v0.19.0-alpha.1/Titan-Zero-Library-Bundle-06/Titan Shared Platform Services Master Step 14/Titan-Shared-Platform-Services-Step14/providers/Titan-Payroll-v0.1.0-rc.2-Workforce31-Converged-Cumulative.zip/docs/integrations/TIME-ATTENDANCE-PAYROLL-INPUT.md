# Time Attendance payroll input contract

Titan Payroll does **not** query Titan Time & Attendance tables or models. The inspected Time Attendance reference exposes platform descriptors but no callable payroll hand-off API.

Until Time Attendance publishes one, Payroll binds to `titan.time-attendance.payroll-input` only when the host supplies a compatible object with:

```php
approvedPayrollInputs(int $tenantCompanyId, string $periodFrom, string $periodTo, array $workerRefs = []): array
```

The result must contain only approved records, a stable `worker_ref`, a date (`work_date` or `occurred_at`), and ideally a stable `source_revision`. Payroll defensively re-filters tenant-scoped request boundaries, period boundaries, worker refs, and `approved === true`.

Hourly policies that require approved time fail closed when this port is unavailable. Salaried policies may explicitly set the time-input requirement to false.
