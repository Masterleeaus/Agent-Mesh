<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Evidence;
use App\Extensions\TitanRewind\System\Contracts\RewindEvidenceKeyringContract;
use RuntimeException;
final class RotatingOpenSslRewindEvidenceSigner implements RewindEvidenceKeyringContract
{
    /** @var array<string,array<string,mixed>> */ private array $keys=[];
    public function __construct(array $keys, private string $activeKeyId)
    {
        foreach($keys as $key){ if(!is_array($key)) continue; $id=trim((string)($key['key_id']??'')); if($id==='') continue; $this->keys[$id]=$key; }
        if($this->activeKeyId==='' && $this->keys!==[]) $this->activeKeyId=(string)array_key_first($this->keys);
    }
    public function available(): bool { $k=$this->keys[$this->activeKeyId]??null; return extension_loaded('openssl')&&is_array($k)&&is_readable((string)($k['private_key_path']??''))&&is_readable((string)($k['public_key_path']??'')); }
    public function activeKeyId(): string { return $this->activeKeyId; }
    public function sign(string $contentHash): array
    {
        $this->assertHash($contentHash); if(!$this->available()) throw new RuntimeException('Titan Rewind active evidence signing key is unavailable.');
        $k=$this->keys[$this->activeKeyId]; $private=openssl_pkey_get_private((string)file_get_contents((string)$k['private_key_path'])); if($private===false) throw new RuntimeException('Titan Rewind evidence private key is invalid.');
        $signature=''; if(!openssl_sign($contentHash,$signature,$private,OPENSSL_ALGO_SHA256)) throw new RuntimeException('Titan Rewind evidence signing failed.');
        return ['algorithm'=>'openssl-rsa-sha256','key_id'=>$this->activeKeyId,'signature'=>base64_encode($signature)];
    }
    public function verify(string $contentHash,string $signature,string $keyId): bool
    {
        $this->assertHash($contentHash); $k=$this->keys[$keyId]??null; if(!is_array($k)||!is_readable((string)($k['public_key_path']??''))) return false;
        $decoded=base64_decode($signature,true); if($decoded===false) return false; $public=openssl_pkey_get_public((string)file_get_contents((string)$k['public_key_path']));
        return $public!==false&&openssl_verify($contentHash,$decoded,$public,OPENSSL_ALGO_SHA256)===1;
    }
    public function keyMetadata(): array
    {
        $out=[]; foreach($this->keys as $id=>$k){ $pub=(string)($k['public_key_path']??''); $fingerprint=is_readable($pub)?hash('sha256',(string)file_get_contents($pub)):null; $out[$id]=['key_id'=>$id,'algorithm'=>'openssl-rsa-sha256','active'=>$id===$this->activeKeyId,'status'=>$id===$this->activeKeyId?'active':(string)($k['status']??'verify-only'),'public_key_fingerprint'=>$fingerprint]; } ksort($out); return $out;
    }
    private function assertHash(string $h): void { if(preg_match('/^[a-f0-9]{64}$/',$h)!==1) throw new RuntimeException('Titan Rewind evidence content hash is invalid.'); }
}
