# Field/Home Services Product Profile

The active `field_home_services` profile is the Interaction Engine v10.3.1 product surface.

## Canonical vertical slugs

1. `cleaning`
2. `plumbing`
3. `electrical`
4. `hvac`
5. `handyman-property-maintenance`
6. `landscaping-gardening`
7. `pest-control`
8. `locksmith-security`
9. `roofing-guttering`
10. `appliance-equipment-repair`

Vertical packs modify data-driven terminology, question visibility, evidence prompts, suggested services, compliance prompts and workflow selection. They do not add trade-specific branches to `UniversalWizardEngine`.

## Catalogue scope

The source package preserves all 30 wizard definitions and 38 templates for compatibility and regression. Runtime discovery is filtered through `FieldHomeServicesProfile` and `SurfaceWizardPolicy`, so dormant non-target donor resources are not globally exposed.

See `docs/WIZARD-AUDIT-v10.3.md`, `docs/TEMPLATE-AUDIT-v10.3.md`, and `docs/FOUR-PWA-WIZARD-SURFACES.md` for exact classification.
