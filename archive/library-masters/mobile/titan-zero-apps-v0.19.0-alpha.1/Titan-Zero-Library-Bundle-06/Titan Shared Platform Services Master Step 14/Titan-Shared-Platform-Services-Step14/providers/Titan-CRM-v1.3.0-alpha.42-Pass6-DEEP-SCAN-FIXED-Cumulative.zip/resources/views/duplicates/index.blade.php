@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Data Quality','subtitle'=>'Review customer identity conflicts before conversion or merge.','surface'=>'insights'])
<div class="container-fluid py-4">
    @if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif

    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center"><strong>Blocking identity reviews</strong><span class="badge bg-warning text-dark">{{ count($reviews ?? []) }} pending</span></div>
        <div class="card-body">
            @forelse(($reviews ?? []) as $review)
                <div class="border rounded p-3 mb-3">
                    <div class="d-flex justify-content-between gap-3 flex-wrap">
                        <div>
                            <div class="fw-semibold">{{ ucfirst($review['source_type']) }} → {{ ucfirst($review['candidate_type']) }}</div>
                            <div class="small text-muted">Confidence {{ $review['confidence'] }}% · {{ implode(', ', $review['signals'] ?? []) }}</div>
                            <div class="mt-2"><strong>{{ $review['source']['name'] ?? $review['source_public_id'] }}</strong> <span class="text-muted">{{ $review['source']['email'] ?? '' }} {{ $review['source']['phone'] ?? '' }}</span></div>
                            <div><strong>Existing:</strong> {{ $review['candidate']['name'] ?? $review['candidate_public_id'] }} <span class="text-muted">{{ $review['candidate']['email'] ?? '' }} {{ $review['candidate']['phone'] ?? '' }}</span></div>
                        </div>
                        <div class="d-flex gap-2 align-items-start">
                            <form method="post" action="{{ route('dashboard.user.crm.duplicates.reviews.resolve',['review'=>$review['public_id']]) }}">@csrf<input type="hidden" name="decision" value="use_existing"><button class="btn btn-primary btn-sm">Use existing</button></form>
                            <form method="post" action="{{ route('dashboard.user.crm.duplicates.reviews.resolve',['review'=>$review['public_id']]) }}">@csrf<input type="hidden" name="decision" value="dismissed"><button class="btn btn-outline-secondary btn-sm">Not a duplicate</button></form>
                        </div>
                    </div>
                </div>
            @empty
                <div class="text-muted">No blocking identity reviews are waiting.</div>
            @endforelse
        </div>
    </div>

    <div class="d-flex justify-content-between mb-4"><div><p class="text-muted">Potential duplicates are grouped by normalized email and phone.</p></div><form method="get"><select name="resource" class="form-select" onchange="this.form.submit()">@foreach(['contacts','companies','leads'] as $r)<option value="{{ $r }}" @selected($resource===$r)>{{ ucfirst($r) }}</option>@endforeach</select></form></div>
    @forelse($groups as $group)
        <div class="card mb-3"><div class="card-header"><strong>Potential duplicate group</strong></div><div class="card-body">
            <div class="row g-3">@foreach($group as $record)<div class="col-md-6"><div class="border rounded p-3 h-100"><div class="fw-semibold">{{ $record['name'] ?? trim(($record['first_name']??'').' '.($record['last_name']??'')) }}</div><div class="small text-muted">{{ $record['email'] ?? '' }} · {{ $record['phone'] ?? '' }}</div><code>{{ $record['public_id'] }}</code></div></div>@endforeach</div>
            @if(count($group)>=2)
                <form method="post" action="{{ route('dashboard.user.crm.duplicates.merge') }}" class="row g-2 mt-3 crm-merge-form">@csrf<input type="hidden" name="resource" value="{{ $resource }}"><div class="col-md-4"><label class="form-label">Keep</label><select name="winner_public_id" class="form-select">@foreach($group as $record)<option value="{{ $record['public_id'] }}">{{ $record['name'] ?? $record['first_name'] ?? $record['public_id'] }}</option>@endforeach</select></div><div class="col-md-4"><label class="form-label">Merge into kept record</label><select name="loser_public_id" class="form-select">@foreach($group as $record)<option value="{{ $record['public_id'] }}">{{ $record['name'] ?? $record['first_name'] ?? $record['public_id'] }}</option>@endforeach</select></div><div class="col-md-2 d-flex align-items-end"><button type="button" class="btn btn-outline-secondary w-100 crm-preview-merge">Preview</button></div><div class="col-md-2 d-flex align-items-end"><button class="btn btn-primary w-100" onclick="return confirm('Merge these records? A Rewind evidence snapshot will be preserved.')">Merge</button></div><div class="col-12"><div class="small text-muted crm-merge-preview"></div></div></form>
            @endif
        </div></div>
    @empty<div class="alert alert-light">No duplicate groups found for {{ $resource }}.</div>@endforelse
</div>
<script>
document.querySelectorAll('.crm-preview-merge').forEach(function(button){button.addEventListener('click',async function(){const form=button.closest('form');const target=form.querySelector('.crm-merge-preview');const body=new FormData(form);try{const response=await fetch(@json(route('dashboard.user.crm.duplicates.merge.preview')),{method:'POST',headers:{'Accept':'application/json','X-CSRF-TOKEN':body.get('_token')},body:body});const json=await response.json();if(!response.ok)throw new Error(json.message||'Preview failed');const data=json.data||{};target.textContent='Fields to fill: '+Object.keys(data.fields_to_fill||{}).join(', ')+' · Related records affected: '+Object.values(data.relationship_summary||{}).reduce((a,b)=>a+Number(b||0),0)+' · Snapshot '+String(data.before_snapshot_hash||'').slice(0,12)+'…';}catch(error){target.textContent=error.message;}});});
</script>
@endcomponent
@endsection
