<?php
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Contracts\ContactRepositoryContract; use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway; use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class ContactController extends Controller
{
    public function __construct(private ContactRepositoryContract $contacts, private CrmHumanMutationGateway $mutations) {}
    public function index(Request $r){$records=$this->contacts->search((int)$r->user()->id,$r->only(['q','limit']));return $r->expectsJson()?response()->json(['data'=>$records]):view('crm::list',['title'=>'Contacts','records'=>$records]);}
    public function store(Request $r){$data=$r->validate(['company_public_id'=>'nullable|string|max:26','first_name'=>'required|string|max:190','last_name'=>'nullable|string|max:190','email'=>'nullable|email|max:190','phone'=>'nullable|string|max:60','role'=>'nullable|string|max:120','is_primary'=>'nullable|boolean','meta'=>'nullable|array']);return response()->json($this->mutations->execute($r,'crm.contact.create',$data),201);}
    public function update(Request $r,string $contact){$data=$r->validate(['company_public_id'=>'nullable|string|max:26','first_name'=>'required|string|max:190','last_name'=>'nullable|string|max:190','email'=>'nullable|email|max:190','phone'=>'nullable|string|max:60','role'=>'nullable|string|max:120','is_primary'=>'nullable|boolean']);$record=$this->mutations->execute($r,'crm.contact.update',$data+['public_id'=>$contact]);return $r->expectsJson()?response()->json($record):back()->with('status','Contact updated.');}
}
