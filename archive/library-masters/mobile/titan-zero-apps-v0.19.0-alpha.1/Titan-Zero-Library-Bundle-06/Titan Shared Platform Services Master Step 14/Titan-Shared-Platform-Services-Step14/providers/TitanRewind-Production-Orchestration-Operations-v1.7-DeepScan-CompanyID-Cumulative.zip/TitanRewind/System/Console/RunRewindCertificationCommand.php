<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Console;

use App\Extensions\TitanRewind\System\Certification\RewindHostReadinessReport;
use App\Extensions\TitanRewind\System\Contracts\RewindEvidenceSignerContract;
use App\Extensions\TitanRewind\System\Contracts\RewindGovernanceGatewayContract;
use App\Extensions\TitanRewind\System\Contracts\RewindSignalTransportContract;
use Illuminate\Console\Command;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class RunRewindCertificationCommand extends Command
{
    protected $signature = 'titan-rewind:certify {--json : Emit machine-readable JSON only}';
    protected $description = 'Evaluate Titan Rewind readiness against the installed Titan/MagicAI host.';

    public function __construct(
        private RewindHostReadinessReport $report,
        private RewindEvidenceSignerContract $signer,
        private RewindSignalTransportContract $signal,
        private RewindGovernanceGatewayContract $governance,
    ) { parent::__construct(); }

    public function handle(): int
    {
        $checks = [
            'php' => PHP_VERSION_ID >= 80200,
            'laravel' => class_exists(\Illuminate\Foundation\Application::class),
            'database' => $this->tableExists('titan_rewind_trace_events'),
            'migrations' => $this->requiredTablesExist(),
            'queues' => (string) config('queue.default', '') !== '',
            'scheduler' => app()->bound(Schedule::class),
            'signal' => $this->available(fn (): bool => $this->signal->available()),
            'governance' => $this->available(fn (): bool => $this->governance->available()),
            'rewind_source_registry' => class_exists('App\\Support\\Extensions\\RewindSourceRegistry') || app()->bound('App\\Support\\Extensions\\RewindSourceRegistry'),
            'evidence_signing_key' => $this->available(fn (): bool => $this->signer->available()),
        ];
        $result = $this->report->evaluate($checks) + [
            'extension' => 'titan-rewind',
            'version' => '1.0.6',
            'runtime_profile' => 'titan-rewind',
            'checked_at' => now()->toIso8601String(),
        ];
        $json = json_encode($result, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        if ($this->option('json')) $this->line($json); else {
            $this->info($result['ready'] ? 'Titan Rewind host certification checks passed.' : 'Titan Rewind host certification checks are incomplete.');
            $this->line($json);
        }
        return $result['ready'] ? self::SUCCESS : self::FAILURE;
    }

    private function requiredTablesExist(): bool
    {
        foreach (['titan_rewind_trace_events','titan_rewind_trace_index','titan_rewind_evidence_packages','titan_rewind_runtime_state','titan_rewind_legal_holds','titan_rewind_purge_receipts'] as $table) {
            if (!$this->tableExists($table)) return false;
        }
        return true;
    }

    private function tableExists(string $table): bool
    {
        try { return Schema::hasTable($table); } catch (Throwable) { return false; }
    }

    private function available(callable $probe): bool
    {
        try { return (bool) $probe(); } catch (Throwable) { return false; }
    }
}
