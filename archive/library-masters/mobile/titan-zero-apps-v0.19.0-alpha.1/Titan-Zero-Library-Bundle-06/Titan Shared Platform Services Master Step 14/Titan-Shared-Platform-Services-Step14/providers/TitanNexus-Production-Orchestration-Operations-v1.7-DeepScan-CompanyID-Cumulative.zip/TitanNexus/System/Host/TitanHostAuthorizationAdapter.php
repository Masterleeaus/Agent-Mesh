<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Host;

use Throwable;

/** MagicAI-compatible authorization. Super Admin is the only unconditional platform bypass. */
final class TitanHostAuthorizationAdapter
{
    /** @param list<string> $delegatedAdminPermissions */
    public function allows(object $user, string $permission, array $delegatedAdminPermissions = []): bool
    {
        try { if (method_exists($user, 'isSuperAdmin') && $user->isSuperAdmin()) return true; } catch (Throwable) { return false; }
        foreach (['can','checkPermission','hasPermissionTo'] as $method) {
            try { if (method_exists($user, $method) && $user->{$method}($permission)) return true; } catch (Throwable) { return false; }
        }
        try {
            if (method_exists($user, 'isAdmin') && $user->isAdmin()) {
                return in_array($permission, $delegatedAdminPermissions, true);
            }
        } catch (Throwable) { return false; }
        return false;
    }
}
