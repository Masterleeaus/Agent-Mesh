<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_autonomy_capability_states')) {
            Schema::create('titan_autonomy_capability_states', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->string('capability', 120);
                $table->string('workflow_key', 120)->default('');
                $table->string('risk', 16);
                $table->string('current_level', 24)->default('suggest');
                $table->string('next_level', 24)->nullable();
                $table->unsignedInteger('required_success_streak')->default(0);
                $table->unsignedInteger('current_success_streak')->default(0);
                $table->unsignedInteger('highest_success_streak')->default(0);
                $table->unsignedBigInteger('total_successes')->default(0);
                $table->unsignedBigInteger('total_failures')->default(0);
                $table->unsignedBigInteger('total_edits')->default(0);
                $table->unsignedBigInteger('total_rejections')->default(0);
                $table->unsignedBigInteger('total_reversals')->default(0);
                $table->boolean('platform_gate_eligible')->default(false);
                $table->string('maximum_allowed_level', 24)->default('assist');
                $table->json('scope_json')->nullable();
                $table->decimal('ai_confidence', 6, 5)->nullable();
                $table->string('assurance_status', 16)->nullable();
                $table->timestamp('last_success_at')->nullable();
                $table->timestamp('last_failure_at')->nullable();
                $table->timestamps();
                $table->unique(['tenant_company_id', 'capability', 'workflow_key'], 'titan_autonomy_state_scope_unique');
            });
        }

        if (!Schema::hasTable('titan_autonomy_gate_decisions')) {
            Schema::create('titan_autonomy_gate_decisions', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->string('capability', 120)->index();
                $table->string('workflow_key', 120)->default('');
                $table->string('current_level', 24);
                $table->string('requested_level', 24);
                $table->boolean('eligible');
                $table->json('reason_codes_json')->nullable();
                $table->json('evidence_json')->nullable();
                $table->string('policy_version', 64);
                $table->string('correlation_id', 96)->nullable()->index();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('titan_autonomy_handshakes')) {
            Schema::create('titan_autonomy_handshakes', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->string('capability', 120)->index();
                $table->string('workflow_key', 120)->default('');
                $table->string('requested_level', 24);
                $table->json('requested_scope_json');
                $table->string('platform_decision', 16);
                $table->json('platform_reason_codes_json')->nullable();
                $table->timestamp('platform_decided_at')->nullable();
                $table->string('user_decision', 16)->default('pending');
                $table->timestamp('user_decided_at')->nullable();
                $table->string('ai_decision', 16)->default('pending');
                $table->decimal('ai_confidence', 6, 5)->nullable();
                $table->json('ai_reason_codes_json')->nullable();
                $table->timestamp('ai_decided_at')->nullable();
                $table->string('final_decision', 16)->default('pending');
                $table->timestamp('activated_at')->nullable();
                $table->timestamp('review_at')->nullable();
                $table->string('policy_version', 64);
                $table->string('assurance_evaluation_ref', 120)->nullable();
                $table->string('correlation_id', 96)->nullable()->index();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('titan_autonomy_regressions')) {
            Schema::create('titan_autonomy_regressions', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->string('capability', 120)->index();
                $table->string('workflow_key', 120)->default('');
                $table->string('prior_level', 24);
                $table->string('new_level', 24);
                $table->string('cause', 96);
                $table->json('evidence_json')->nullable();
                $table->string('policy_version', 64);
                $table->string('correlation_id', 96)->nullable()->index();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('titan_learning_events')) {
            Schema::create('titan_learning_events', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->string('capability', 120)->index();
                $table->string('workflow_key', 120)->default('');
                $table->string('risk', 16);
                $table->string('autonomy_level', 24);
                $table->json('context_json')->nullable();
                $table->json('proposal_json')->nullable();
                $table->json('user_response_json')->nullable();
                $table->json('final_action_json')->nullable();
                $table->json('outcome_json')->nullable();
                $table->string('learning_label', 32)->index();
                $table->boolean('material_edit')->default(false);
                $table->boolean('success')->default(false);
                $table->boolean('reversed')->default(false);
                $table->decimal('confidence', 6, 5)->nullable();
                $table->string('correlation_id', 96)->nullable()->index();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('titan_learning_outcomes')) {
            Schema::create('titan_learning_outcomes', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('learning_event_id')->index();
                $table->string('signal', 48);
                $table->decimal('score', 8, 5)->nullable();
                $table->json('details_json')->nullable();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('titan_learning_preferences')) {
            Schema::create('titan_learning_preferences', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->string('scope', 16); // user|business
                $table->string('subject_key', 64)->default('business'); // e.g. business or user:<id>
                $table->string('preference_key', 160);
                $table->json('value_json');
                $table->decimal('confidence', 6, 5)->nullable();
                $table->timestamps();
                $table->unique(['tenant_company_id', 'scope', 'subject_key', 'preference_key'], 'titan_learning_pref_unique');
            });
        }

        if (!Schema::hasTable('titan_learning_patterns')) {
            Schema::create('titan_learning_patterns', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index(); // null only for de-identified system patterns
                $table->string('scope', 16); // business|system
                $table->string('capability', 120)->nullable()->index();
                $table->string('pattern_key', 160)->index();
                $table->json('abstracted_pattern_json');
                $table->unsignedBigInteger('sample_count')->default(0);
                $table->decimal('confidence', 6, 5)->nullable();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_learning_patterns');
        Schema::dropIfExists('titan_learning_preferences');
        Schema::dropIfExists('titan_learning_outcomes');
        Schema::dropIfExists('titan_learning_events');
        Schema::dropIfExists('titan_autonomy_regressions');
        Schema::dropIfExists('titan_autonomy_handshakes');
        Schema::dropIfExists('titan_autonomy_gate_decisions');
        Schema::dropIfExists('titan_autonomy_capability_states');
    }
};
