<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Contracts;

use App\Extensions\TitanAICore\System\DTO\GovernancePreflightReport;
use App\Extensions\TitanAICore\System\DTO\GovernancePreflightRequest;

interface GovernancePreflightContract
{
    public function evaluate(GovernancePreflightRequest $request): GovernancePreflightReport;
}
