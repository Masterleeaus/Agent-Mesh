<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/SignalSeverity.php';
require __DIR__ . '/../System/Data/SignalActor.php';
require __DIR__ . '/../System/Data/SignalEnvelope.php';
require __DIR__ . '/../System/Data/SignalArchiveEntry.php';
require __DIR__ . '/../System/Data/SignalHistoryRecord.php';
require __DIR__ . '/../System/Data/SignalHistoryWindow.php';
require __DIR__ . '/../System/Data/RewindCorrelationReceipt.php';
require __DIR__ . '/../System/Services/HistoryCorrelationAssembler.php';

use App\Extensions\TitanSignalEngine\System\Data\RewindCorrelationReceipt;
use App\Extensions\TitanSignalEngine\System\Data\SignalArchiveEntry;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalHistoryRecord;
use App\Extensions\TitanSignalEngine\System\Data\SignalHistoryWindow;
use App\Extensions\TitanSignalEngine\System\Services\HistoryCorrelationAssembler;

function hotColdAssert(bool $condition, string $message): void
{
    if (! $condition) throw new RuntimeException($message);
}

$root = SignalEnvelope::fromArray([
    'event_id' => '0198aaaa-0000-7000-8000-000000000001',
    'event_type' => 'command.requested',
    'tenant_company_id' => 42,
    'source' => 'titan-command-bus',
    'trace_id' => '0198aaaa-0000-7000-8000-000000000010',
    'correlation_id' => '0198aaaa-0000-7000-8000-000000000020',
    'occurred_at' => '2026-08-17T01:00:00+00:00',
]);
$child = $root->child('command.executed', 'titan-command-bus', [], [
    'occurred_at' => '2026-08-17T01:01:00+00:00',
]);

$archiveEntry = new SignalArchiveEntry(
    eventId: $root->eventId,
    batchId: '0198aaaa-0000-7000-8000-000000000099',
    scope: 'tenant',
    tenantCompanyId: 42,
    eventType: $root->eventType,
    traceId: $root->traceId,
    correlationId: $root->correlationId,
    causationId: null,
    rootCausationId: $root->rootCausationId,
    occurredAt: $root->occurredAt->format(DATE_ATOM),
    recordedAt: $root->recordedAt->format(DATE_ATOM),
    archiveDriver: 'laravel-storage:local',
    archiveLocator: 'archive/root.jsonl.gz',
    archiveChecksum: str_repeat('a', 64),
    archiveSequence: 1,
    privacyProjected: false,
    originalChecksum: $root->checksum,
);

$coldRoot = SignalHistoryRecord::cold($root->toArray(), $archiveEntry, true);
$hotChild = SignalHistoryRecord::hot($child->toArray(), true);
$window = new SignalHistoryWindow([$coldRoot, $hotChild], 1, 1, 2, false, []);

hotColdAssert($window->isMixedTier(), 'Window must identify mixed hot/cold history.');
hotColdAssert($window->integrityComplete(), 'Verified mixed history without failures must be integrity-complete.');

$assembler = new HistoryCorrelationAssembler();
$edges = $assembler->edges($window->records);
hotColdAssert(count($edges) === 1, 'Mixed history must reconstruct one causal edge.');
hotColdAssert($edges[0]['parent_storage_tier'] === 'cold', 'Archived parent edge must report cold tier.');
hotColdAssert($edges[0]['child_storage_tier'] === 'hot', 'Hot child edge must report hot tier.');
hotColdAssert($edges[0]['resolved_in_result'] === true, 'Mixed-tier edge must resolve when both records are present.');

$envelopes = $assembler->envelopes($window->records);
hotColdAssert(count($envelopes) === 2, 'Mixed history must convert into analyzer envelopes.');
hotColdAssert($envelopes[0]->eventId === $root->eventId, 'Assembler must retain causal/timestamp ordering.');

$receipt = new RewindCorrelationReceipt(
    scope: 'tenant',
    tenantCompanyId: 42,
    traceId: $root->traceId,
    correlationId: $root->correlationId,
    rootCausationIds: [$root->rootCausationId],
    eventCount: 2,
    hotEventCount: 1,
    coldEventCount: 1,
    coldHistoryComplete: true,
    coldFailureCount: 0,
);
$receiptArray = $receipt->toArray();
hotColdAssert($receiptArray['storage_tier'] === 'mixed', 'Rewind receipt must report mixed storage.');
hotColdAssert($receiptArray['cold_history_complete'] === true, 'Rewind receipt must expose cold-history completeness.');

$degraded = new SignalHistoryWindow([$hotChild], 1, 1, 2, false, [[
    'batch_id' => $archiveEntry->batchId,
    'code' => 'archive_integrity_failed',
]]);
hotColdAssert(! $degraded->integrityComplete(), 'Archive failure must make history integrity incomplete.');
hotColdAssert($degraded->isPartial(), 'Archive failure must mark history window partial even when not limit-truncated.');

fwrite(STDOUT, "hot-cold-correlation-behavior: PASS\n");
