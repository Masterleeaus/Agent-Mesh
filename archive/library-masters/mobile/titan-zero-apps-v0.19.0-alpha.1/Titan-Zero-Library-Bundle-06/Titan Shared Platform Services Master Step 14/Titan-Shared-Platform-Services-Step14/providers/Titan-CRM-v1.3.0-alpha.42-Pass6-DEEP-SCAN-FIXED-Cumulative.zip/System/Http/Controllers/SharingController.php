<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Sharing\CrmRecordShareService; use App\Extensions\Crm\System\Security\CrmPermissionService; use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway; use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class SharingController {
 public function __construct(private CrmHumanMutationGateway $mutations){}
 public function index(Request $request,CrmRecordShareService $shares,CrmPermissionService $permissions){$uid=(int)$request->user()->id;$permissions->authorize($uid,'crm.sharing.manage');return view('crm::sharing.index',['shares'=>$shares->list($uid)]);}
 public function store(Request $request,CrmPermissionService $permissions){$uid=(int)$request->user()->id;$permissions->authorize($uid,'crm.sharing.manage');$d=$request->validate(['subject_type'=>'required|string|max:60','subject_public_id'=>'required|string|size:26','grantee_user_id'=>'required|integer|min:1','permissions'=>'required|array|min:1','expires_at'=>'nullable|date|after:now']);$this->mutations->execute($request,'crm.share.create',$d);return back()->with('status','Record share created.');}
 public function revoke(Request $request,string $share,CrmPermissionService $permissions){$permissions->authorize((int)$request->user()->id,'crm.sharing.manage');$this->mutations->execute($request,'crm.share.revoke',['public_id'=>$share]);return back()->with('status','Record share revoked.');}
}
