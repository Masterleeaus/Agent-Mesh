# CRM Core alpha.29 Commercial Contract Engine Report

## Contract authority

A proposal or estimate begins as a mutable draft. The first governed transition to `sent` captures a canonical `crm.commercial-contract.v1` snapshot containing the commercial document identity, revision identity, customer references, currency and totals, expiry, pricing/tax/terms/service/discount/currency snapshots, and normalized line items. The canonical JSON is SHA-256 hashed and persisted as `issued_snapshot_hash`.

After issuance, the commercial contract snapshot is immutable. A material commercial change requires a new draft revision. Revisions share `revision_root_public_id`, increment `revision_number`, retain `supersedes_public_id`, and atomically mark the predecessor `superseded` when the new revision is issued.

## Acceptance evidence

Acceptance requires an issued snapshot. CRM stores `crm.quote-acceptance.v1` evidence containing the accepted document, exact issued snapshot hash, acceptance time, accountable CRM actor, source surface, customer/user actor classification, customer reference and a one-way session hash when available. The evidence receives its own deterministic SHA-256.

Legacy accepted rows upgraded from alpha.28 are marked `legacy_crm_pre_alpha29`; CRM does not invent a historical customer session or identity reference.

## Document rendering

PDF generation is asynchronous. `crm.document.render.request` creates or reuses a durable render job keyed to the document snapshot, renderer version and template version. `crm:documents:render` claims due jobs, renders from the immutable issued snapshot, stores the artifact, hashes the output and marks the document/job ready. Failed jobs use bounded exponential retry and stale rendering claims can be recovered.

Outbound sales-document email no longer renders PDFs inline. Delivery is deferred until the matching render artifact is ready.

## Boundaries

- CRM Core: quote/estimate commercial state, revisions, acceptance evidence, invoice commercial state and document artifact metadata.
- Titan Field: work execution and job truth.
- Titan Pay: provider/payment execution.
- Titan Ledger: accounting truth.
- Titan Connect: external delivery execution.
