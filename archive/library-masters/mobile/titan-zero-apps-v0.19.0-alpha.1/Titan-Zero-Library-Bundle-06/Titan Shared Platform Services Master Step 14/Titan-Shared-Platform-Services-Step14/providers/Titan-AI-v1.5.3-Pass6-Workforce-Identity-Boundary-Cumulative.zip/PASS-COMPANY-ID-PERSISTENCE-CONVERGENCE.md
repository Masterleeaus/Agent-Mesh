# Titan AI — company_id persistence convergence

Titan AI already uses `company_id` on active runtime/governance persistence. No destructive storage migration is required in this pass. The Blueprint v2.2 manifest retains its protocol-level `tenant_company_id` field only because Blueprint v4.2.1 currently requires it. Workforce-facing identity and runtime persistence remain canonical `company_id`.
