<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Http\Controllers;

use App\Extensions\TitanGovernance\System\Context\TenantCompanyResolver;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceManagerContract;
use App\Extensions\TitanGovernance\System\Host\TitanHostAuthorizationAdapter;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class ReadPlaneController
{
    public function __construct(private readonly GovernanceManagerContract $governance, private readonly TenantCompanyResolver $tenants, private readonly TitanHostAuthorizationAdapter $authorization) {}

    public function signalHeatmap(Request $request): JsonResponse|View
    {
        return $this->respond($request,'Signal Heatmap','Operational telemetry projection; Titan Signal remains the source of truth.',$this->governance->signalHeatmap($this->tenant($request)));
    }

    public function operationalPressure(Request $request): JsonResponse|View
    {
        return $this->respond($request,'Operational Pressure','Deterministic queue, failure, age and saturation pressure projection. This is not Titan Risk.',$this->governance->operationalPressure($this->tenant($request)));
    }

    public function circuitBreakers(Request $request): JsonResponse|View
    {
        return $this->respond($request,'Circuit Breakers','Read-only circuit-breaker state projected from authoritative engine observations.',$this->governance->circuitBreakers($this->tenant($request)));
    }

    public function projectionHistory(Request $request): JsonResponse|View
    {
        $allowed=['source-health','signal-heatmap','operational-pressure','circuit-breaker','trust-map','autonomy-evidence'];
        $type=(string)$request->query('type','source-health');
        abort_unless(in_array($type,$allowed,true),422);
        return $this->respond($request,'Projection History','Bounded Governance-owned projection history.',['type'=>$type,'history'=>$this->governance->projectionHistory($this->tenant($request),$type,50)]);
    }

    private function tenant(Request $request): int
    {
        $user=$request->user();
        abort_unless($user && $this->authorization->allows($user,'titan-governance.view',['titan-governance.view']),403);
        return $this->tenants->resolve($user);
    }

    /** @param array<string,mixed> $payload */
    private function respond(Request $request,string $title,string $description,array $payload): JsonResponse|View
    {
        if($request->expectsJson()) return response()->json($payload);
        return view('titan-governance::read-plane',[
            'title'=>$title,
            'description'=>$description,
            'payload'=>$payload,
        ]);
    }
}
