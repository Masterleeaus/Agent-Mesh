<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Models\RewindSourceWatermark;
use App\Extensions\TitanRewind\System\Reconstruction\RewindSourceAdapterRegistry;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Sources\RewindSourceCompleteness;
use App\Extensions\TitanRewind\System\Sources\RewindHostSourceDiscovery;

final class RewindSourceWatermarkService
{
    public function __construct(private RewindSourceAdapterRegistry $sources, private RewindSourceCompleteness $completeness, private RewindHostSourceDiscovery $discovery) {}

    public function refresh(RewindTraceQuery $query): array
    {
        $this->discovery->discover();
        $watermarks = $this->sources->watermarks($query);
        foreach ($watermarks as $watermark) {
            RewindSourceWatermark::query()->updateOrCreate(
                ['tenant_company_id'=>$query->tenantCompanyId(),'trace_id'=>$query->traceId(),'source_key'=>$watermark['source']],
                ['state'=>$watermark['state'],'observed_through'=>$watermark['observed_through'] ?? null,'source_lag_seconds'=>$watermark['source_lag_seconds'] ?? null,'metadata'=>$watermark['metadata'] ?? [],'checked_at'=>now()],
            );
        }
        return $this->completeness->evaluate($watermarks);
    }

    public function forTrace(RewindTraceQuery $query): array
    {
        $this->discovery->discover();
        $rows = RewindSourceWatermark::query()->where('tenant_company_id',$query->tenantCompanyId())->where('trace_id',$query->traceId())->orderBy('source_key')->lazy(250);
        $items = $rows->map(static fn (RewindSourceWatermark $m): array => [
            'source'=>(string)$m->source_key,'state'=>(string)$m->state,'observed_through'=>$m->observed_through?->toIso8601String(),
            'source_lag_seconds'=>$m->source_lag_seconds,'metadata'=>is_array($m->metadata)?$m->metadata:[],
        ])->all();
        return $this->completeness->evaluate($items);
    }
}
