<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Support;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class LegacyMenuStore
{
    public function available(): bool { return Schema::hasTable('menus'); }
    /** @return array<string,int> */
    public function columns(): array { return array_flip(Schema::getColumnListing('menus')); }
    /** @param array<string,mixed> $identity */
    public function first(array $identity): ?object { $q=DB::table('menus'); foreach($identity as $c=>$v){$q->where($c,$v);} return $q->first(); }
    /** @param array<string,mixed> $identity @param array<string,mixed> $payload */
    public function update(array $identity,array $payload): int { $q=DB::table('menus'); foreach($identity as $c=>$v){$q->where($c,$v);} return $q->update($payload); }
    /** @param array<string,mixed> $payload */
    public function insert(array $payload): bool { return DB::table('menus')->insert($payload); }
}
