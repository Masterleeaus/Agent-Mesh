# Governance Control Centre & Model/Compliance Health Design

## Goal
Turn Titan Governance from a forensic/read-plane foundation into the daily human oversight cockpit without duplicating ownership held by Titan Autonomy, Risk, Assurance, Signal, Shield, Model Council, Knowledge Authority, AI Workforce or authoritative business domains.

## Architecture
Pass 6 is a read-side aggregation layer. `GovernanceControlCentre` reads tenant-scoped snapshots through the existing `GovernanceReadSourceRegistry`, combines them with Governance-owned escalation/decision state, and delegates deterministic projections to focused helpers. No peer-engine tables are queried directly and no peer state is persisted or rewritten.

The control centre exposes only projected management state:
- model transition health and Model Council disagreement visibility;
- policy-version drift and compliance-control status;
- exception expiry and evidence freshness;
- authority-contraction explanations sourced from Autonomy/Governance constraints;
- cross-engine health scorecard;
- ranked Needs Attention items.

## Canonical read-source overlay
A `GovernanceReadSourceContract::snapshot()` may optionally expose a `control_centre` object. Governance accepts only structured fields and ignores unknown executable/provider payloads.

Supported normalized inputs:
- `models`: model/model-transition records with model_id, provider, version, previous_version, status, transition_status, drift_score, observed_at, reference.
- `council`: disagreement_score, material_disagreement, participant_count, status, observed_at, reference.
- `policies`: policy_key, expected_version/current_version, status, observed_at, reference.
- `controls`: control_key, obligation_key, status, evidence_status, expires_at, observed_at, reference.
- `authority_constraints`: capability/agent identifiers, source, disposition, ceiling_score, effective_score, reason_codes, observed_at, expires_at, reference.

Governance may also derive:
- exception expiry from Governance-owned policy decision/result metadata;
- health state from existing `sourceHealth()` output;
- open escalation pressure from Governance-owned escalation rows.

## Model health semantics
Model transition states are normalized to HEALTHY, TRANSITIONING, DEGRADED, FAILED, STALE or UNKNOWN. Drift does not automatically become failure. Model Council disagreement is reported independently from model health; high disagreement lowers confidence/raises attention but never changes Autonomy authority by itself.

## Policy and compliance semantics
Policy drift is deterministic version/state mismatch, not semantic guessing. Compliance controls use explicit source statuses only. Missing optional controls yield visibility degradation, not fabricated compliance. Explicit FAILED/BLOCKED/NON_COMPLIANT control evidence becomes attention-worthy.

## Evidence freshness
Freshness is based only on explicit `observed_at` timestamps. Default thresholds are configurable; malformed timestamps are stale/invalid rather than treated fresh. No timestamp means UNKNOWN freshness.

## Authority contraction explanation
Governance displays why effective authority is below earned/desired authority using structured constraints/reason codes supplied by Autonomy/Governance sources. It never computes or raises earned/effective authority. The presentation is explanatory only.

## Needs Attention
`GovernanceAttentionRanker` converts explicit projected facts into ranked items. Severity order is CRITICAL > HIGH > MEDIUM > LOW, then older first for equal severity. Sources include:
- failed/degraded model transitions;
- material/high Model Council disagreement;
- policy drift;
- failed/non-compliant controls;
- expiring/expired exceptions;
- stale required evidence;
- open circuits/degraded required sources;
- high/critical operational pressure;
- high-risk/open Governance escalations.

Every attention item carries a source, reason code, reference when available, observed/expiry timestamp, and deterministic score. It does not contain generated causal reasoning.

## UI/API
Main tenant dashboard gains:
- Needs Attention summary and ranked list;
- Engine Health Scorecard;
- Model & Council Health;
- Policy / Compliance Controls;
- Authority Contractions;
- Exception & Evidence Freshness.

A read-only `/control-centre` endpoint exposes the normalized snapshot under `titan-governance.view`.

## Error handling
Optional source absence stays visible as NOT_INSTALLED/UNAVAILABLE. Required source failure degrades overall control-centre status. One observer failure must not crash unrelated facets. Identity is tenant-derived server side; no request-supplied tenant authority is trusted.

## Release requirements
- Version: 0.7.0.
- Blueprint: Titan Extension Blueprint v4.2.2.
- PHP 8.3 / Laravel 10.50 / MagicAI >=10.91 / Installer 1.7.8.
- No direct peer-engine DB writes or reads.
- No hidden reasoning/raw prompts/secrets in projected output.
- Full cumulative ZIP with exact integrity map and fresh-extraction certification.
