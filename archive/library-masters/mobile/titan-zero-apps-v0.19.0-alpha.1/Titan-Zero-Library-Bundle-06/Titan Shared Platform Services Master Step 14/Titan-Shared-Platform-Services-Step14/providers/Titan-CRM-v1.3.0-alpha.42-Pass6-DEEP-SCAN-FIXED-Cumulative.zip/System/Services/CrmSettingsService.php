<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;

final class CrmSettingsService
{
    public function __construct(private ConnectionInterface $db) {}

    public function all(int $userId): array
    {
        $stored = $this->db->table('crm_settings')->where('company_id', CrmCompanyScope::companyId($userId))->pluck('value', 'key')->all();
        $settings = config('crm.settings.defaults', []);
        foreach ($stored as $key => $value) {
            $settings[$key] = $value === null ? null : json_decode((string) $value, true);
        }
        return $settings;
    }

    public function get(int $userId, string $key, mixed $default = null): mixed
    {
        $value = $this->db->table('crm_settings')->where('company_id', CrmCompanyScope::companyId($userId))->where('key', $key)->value('value');
        return $value === null ? ($this->all($userId)[$key] ?? $default) : json_decode((string) $value, true);
    }

    public function setMany(int $userId, array $settings): array
    {
        foreach ($settings as $key => $value) {
            $this->db->table('crm_settings')->updateOrInsert(
                ['company_id' => CrmCompanyScope::companyId($userId), 'key' => (string) $key],
                ['user_id' => CrmCompanyScope::actorUserId($userId), 'value' => json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), 'updated_at' => now(), 'created_at' => now()]
            );
        }
        return $this->all($userId);
    }
}
