<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalEventStoreContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalQueryContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Exceptions\SignalIntegrityException;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;

final class SignalQueryService implements SignalQueryContract
{
    public function __construct(
        private readonly SignalEventStoreContract $store,
        private readonly SignalContextValidator $contextValidator,
    ) {
    }

    public function find(string $eventId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT): ?SignalEnvelope
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        $event = $this->store->find($eventId, $tenantCompanyId, $scope);
        return $event === null ? null : $this->envelope($event);
    }

    public function byTrace(string $traceId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        return array_map(fn (SignalEvent $event): SignalEnvelope => $this->envelope($event), $this->store->byTrace($traceId, $tenantCompanyId, $scope, $limit));
    }

    public function byCorrelation(string $correlationId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        return array_map(fn (SignalEvent $event): SignalEnvelope => $this->envelope($event), $this->store->byCorrelation($correlationId, $tenantCompanyId, $scope, $limit));
    }

    public function byRootCausation(string $rootCausationId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 250): array
    {
        $this->contextValidator->assertQueryAllowed($scope, $tenantCompanyId, $context);
        return array_map(fn (SignalEvent $event): SignalEnvelope => $this->envelope($event), $this->store->byRootCausation($rootCausationId, $tenantCompanyId, $scope, $limit));
    }

    private function envelope(SignalEvent $event): SignalEnvelope
    {
        $envelope = SignalEnvelope::fromPersistenceArray(array_replace($event->getAttributes(), [
            'payload' => $event->payload ?? [],
            'metadata' => $event->metadata ?? [],
        ]));
        if (! $envelope->verifyChecksum()) {
            throw new SignalIntegrityException("Signal checksum verification failed for event {$envelope->eventId}.");
        }

        return $envelope;
    }
}
