<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Middleware;

use App\Helpers\Classes\Helper;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class EnsureCrmApiEntitlement
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        abort_unless($user, 401);

        if (method_exists($user, 'isAdmin') && $user->isAdmin()) {
            return $next($request);
        }

        if ((bool) Helper::setting('crm_enabled', true) === false) {
            abort(404);
        }

        if (str_contains($request->path(), '/assistant/') && (bool) Helper::setting('crm_assistant_enabled', true) === false) {
            abort(404);
        }

        $entitlementUser = $user;
        if ($user?->getAttribute('team_manager_id') && $user?->getAttribute('teamManager')) {
            $entitlementUser = $user->getAttribute('teamManager');
        }

        $slug = str_contains($request->path(), '/sales/') ? 'ext_sales_dropdown' : 'ext_crm_dropdown';
        $plan = $entitlementUser?->relationPlan;

        if (! $plan) {
            $free = (array) Helper::setting('free_open_ai_items', []);
            abort_unless(in_array($slug, $free, true), 403);
            return $next($request);
        }

        abort_unless($plan->checkOpenAiItem($slug), 403);

        return $next($request);
    }
}
