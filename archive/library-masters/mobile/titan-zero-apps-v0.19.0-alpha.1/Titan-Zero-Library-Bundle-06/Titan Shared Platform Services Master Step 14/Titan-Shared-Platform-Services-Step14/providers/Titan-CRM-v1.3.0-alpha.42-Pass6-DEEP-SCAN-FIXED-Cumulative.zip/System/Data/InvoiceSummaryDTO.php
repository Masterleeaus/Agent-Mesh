<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Data;

final class InvoiceSummaryDTO
{
    public function __construct(
        public readonly mixed $publicId,
        public readonly mixed $number,
        public readonly mixed $title,
        public readonly mixed $status,
        public readonly mixed $currency,
        public readonly mixed $totalMinor,
        public readonly mixed $paidMinor,
        public readonly mixed $outstandingMinor,
        public readonly mixed $paymentState,
    ) {}

    public function toArray(): array
    {
        return [
            'publicId'=>$this->publicId,
            'number'=>$this->number,
            'title'=>$this->title,
            'status'=>$this->status,
            'currency'=>$this->currency,
            'totalMinor'=>$this->totalMinor,
            'paidMinor'=>$this->paidMinor,
            'outstandingMinor'=>$this->outstandingMinor,
            'paymentState'=>$this->paymentState,
        ];
    }
}
