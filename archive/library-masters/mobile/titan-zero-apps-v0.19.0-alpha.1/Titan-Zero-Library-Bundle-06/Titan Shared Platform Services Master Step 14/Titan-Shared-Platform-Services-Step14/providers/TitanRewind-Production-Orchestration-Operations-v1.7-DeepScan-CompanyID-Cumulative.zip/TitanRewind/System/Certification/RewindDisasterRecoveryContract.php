<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Certification;
final class RewindDisasterRecoveryContract
{
    public function __construct(private int $rpoMinutes=15,private int $rtoMinutes=120){}
    public function evaluate(int $observedRpoMinutes,int $observedRtoMinutes,bool $integrityVerified,bool $sourcesResynchronized): array
    {
        $checks=['rpo'=>$observedRpoMinutes<=$this->rpoMinutes,'rto'=>$observedRtoMinutes<=$this->rtoMinutes,'integrity'=>$integrityVerified,'source_resynchronization'=>$sourcesResynchronized];
        return ['passed'=>!in_array(false,$checks,true),'checks'=>$checks,'targets'=>['rpo_minutes'=>$this->rpoMinutes,'rto_minutes'=>$this->rtoMinutes]];
    }
}
