<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryIdentity;
use App\Extensions\TitanSignalEngine\System\Data\SignalSubscriptionDefinition;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;

interface SignalSubscriptionRegistryContract
{
    public function register(SignalSubscriptionDefinition $definition, SignalRegistryIdentity $registrar, ?string $ownerServiceId = null): void;

    public function evolve(SignalSubscriptionDefinition $definition, SignalRegistryIdentity $registrar, ?string $ownerServiceId = null): void;

    public function find(string $subscriberKey): ?SignalSubscriptionDefinition;

    /** @return list<SignalSubscriptionDefinition> */
    public function history(string $subscriberKey): array;

    /** @return list<SignalSubscriptionDefinition> */
    public function matching(SignalEvent $event): array;

    public function revalidate(string $subscriberKey, SignalRegistryIdentity $registrar): bool;

    public function markUninstalled(string $subscriberKey, SignalRegistryIdentity $registrar): void;
}
