<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalConsoleRedactionInput
{
    /** @param list<array{op:string,path:string,value?:mixed}> $operations */
    public function __construct(
        public array $operations,
        public string $reason,
    ) {
    }

    /** @param array<string,mixed> $input */
    public static function fromArray(array $input): self
    {
        $operation = strtolower(trim((string) ($input['operation'] ?? '')));
        if (! in_array($operation, ['remove', 'replace'], true)) {
            throw new InvalidArgumentException('Console privacy operation must be remove or replace.');
        }

        $path = trim((string) ($input['path'] ?? ''));
        if ($path === '' || strlen($path) > 255) {
            throw new InvalidArgumentException('Console privacy operation requires a bounded field path.');
        }
        $normalized = ltrim($path, '.');
        $protected = [
            'event_id', 'checksum', 'checksum_alg', 'trace_id', 'correlation_id', 'causation_id',
            'root_causation_id', 'scope', 'tenant_company_id', 'recorded_at', 'occurred_at',
        ];
        foreach ($protected as $field) {
            if ($normalized === $field || str_starts_with($normalized, $field . '.')) {
                throw new InvalidArgumentException('Console privacy operations cannot alter Signal identity or integrity fields.');
            }
        }
        if (! str_starts_with($normalized, 'payload.') && ! str_starts_with($normalized, 'metadata.')) {
            throw new InvalidArgumentException('Console privacy operations are limited to payload or metadata fields.');
        }

        $reason = trim((string) ($input['reason'] ?? ''));
        if ($reason === '' || strlen($reason) > 255) {
            throw new InvalidArgumentException('Console privacy operations require a bounded reason.');
        }

        $item = ['op' => $operation, 'path' => $normalized];
        if ($operation === 'replace') {
            if (! array_key_exists('value', $input)) {
                throw new InvalidArgumentException('Replace privacy operation requires a value.');
            }
            $item['value'] = $input['value'];
        }

        return new self([$item], $reason);
    }
}
