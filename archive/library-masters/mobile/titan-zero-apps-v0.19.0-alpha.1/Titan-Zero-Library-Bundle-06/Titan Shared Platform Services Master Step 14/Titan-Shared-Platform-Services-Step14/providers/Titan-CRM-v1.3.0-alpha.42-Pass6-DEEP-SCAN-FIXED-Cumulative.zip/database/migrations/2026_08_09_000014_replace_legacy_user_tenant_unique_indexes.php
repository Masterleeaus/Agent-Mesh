<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Replace uniqueness rules whose 1.1 leading user_id represented the tenant.
 *
 * Legitimate actor/assignee columns are not touched. Unresolved rows left with a
 * NULL tenant_company_id by the 1.2 tenancy migration remain quarantined for
 * review; SQL unique constraints intentionally do not manufacture a tenant.
 */
return new class extends Migration
{
    /** @var array<string,array{old:string,old_columns:array<int,string>,new:string,new_columns:array<int,string>}> */
    private array $indexes = [
        'crm_tags' => ['old'=>'crm_tags_user_id_name_unique','old_columns'=>['user_id','name'],'new'=>'crm_tags_company_name_unique','new_columns'=>['tenant_company_id','name']],
        'crm_taggables' => ['old'=>'crm_taggables_unique','old_columns'=>['user_id','tag_public_id','subject_type','subject_public_id'],'new'=>'crm_taggables_company_unique','new_columns'=>['tenant_company_id','tag_public_id','subject_type','subject_public_id']],
        'crm_custom_fields' => ['old'=>'crm_custom_fields_user_id_subject_type_key_unique','old_columns'=>['user_id','subject_type','key'],'new'=>'crm_custom_fields_company_subject_key_unique','new_columns'=>['tenant_company_id','subject_type','key']],
        'crm_custom_field_values' => ['old'=>'crm_custom_values_unique','old_columns'=>['user_id','field_public_id','subject_type','subject_public_id'],'new'=>'crm_custom_values_company_unique','new_columns'=>['tenant_company_id','field_public_id','subject_type','subject_public_id']],
        'crm_payment_allocations' => ['old'=>'crm_payment_allocation_unique','old_columns'=>['user_id','payment_public_id','invoice_public_id'],'new'=>'crm_payment_allocation_company_unique','new_columns'=>['tenant_company_id','payment_public_id','invoice_public_id']],
        'crm_settings' => ['old'=>'crm_settings_user_id_key_unique','old_columns'=>['user_id','key'],'new'=>'crm_settings_company_key_unique','new_columns'=>['tenant_company_id','key']],
        'crm_merge_log' => ['old'=>'crm_merge_log_user_id_resource_type_loser_public_id_unique','old_columns'=>['user_id','resource_type','loser_public_id'],'new'=>'crm_merge_log_company_resource_loser_unique','new_columns'=>['tenant_company_id','resource_type','loser_public_id']],
        'crm_automation_runs' => ['old'=>'crm_automation_run_unique','old_columns'=>['user_id','rule_public_id','fingerprint'],'new'=>'crm_automation_run_company_unique','new_columns'=>['tenant_company_id','rule_public_id','fingerprint']],
        'crm_import_rows' => ['old'=>'crm_import_row_unique','old_columns'=>['user_id','batch_public_id','row_number'],'new'=>'crm_import_row_company_unique','new_columns'=>['tenant_company_id','batch_public_id','row_number']],
        'crm_email_connections' => ['old'=>'crm_email_connection_unique','old_columns'=>['user_id','provider','account_email'],'new'=>'crm_email_connection_company_unique','new_columns'=>['tenant_company_id','provider','account_email']],
        'crm_email_messages' => ['old'=>'crm_email_external_unique','old_columns'=>['user_id','connection_public_id','external_message_id'],'new'=>'crm_email_external_company_unique','new_columns'=>['tenant_company_id','connection_public_id','external_message_id']],
        'crm_record_shares' => ['old'=>'crm_record_share_unique','old_columns'=>['user_id','subject_type','subject_public_id','grantee_user_id'],'new'=>'crm_record_share_company_unique','new_columns'=>['tenant_company_id','subject_type','subject_public_id','grantee_user_id']],
        'crm_retention_policies' => ['old'=>'crm_retention_policy_unique','old_columns'=>['user_id','resource_type'],'new'=>'crm_retention_policy_company_unique','new_columns'=>['tenant_company_id','resource_type']],
        'crm_chatbot_identities' => ['old'=>'crm_chatbot_identity_customer_unique','old_columns'=>['user_id','chatbot_id','chatbot_customer_id'],'new'=>'crm_chatbot_identity_company_customer_unique','new_columns'=>['tenant_company_id','chatbot_id','chatbot_customer_id']],
        'crm_chatbot_settings' => ['old'=>'crm_chatbot_settings_unique','old_columns'=>['user_id','chatbot_id'],'new'=>'crm_chatbot_settings_company_unique','new_columns'=>['tenant_company_id','chatbot_id']],
        'crm_chatbot_session_grants' => ['old'=>'crm_chatbot_session_grant_unique','old_columns'=>['user_id','chatbot_id','chatbot_customer_id','session_hash'],'new'=>'crm_chatbot_grant_company_session_unique','new_columns'=>['tenant_company_id','chatbot_id','chatbot_customer_id','session_hash']],
        'crm_chatbot_activity_links' => ['old'=>'crm_chatbot_activity_fingerprint_unique','old_columns'=>['user_id','event_fingerprint'],'new'=>'crm_chatbot_activity_company_fingerprint_unique','new_columns'=>['tenant_company_id','event_fingerprint']],
        'crm_mobile_identity_links' => ['old'=>'crm_mobile_identity_unique','old_columns'=>['user_id','surface','external_identity_id'],'new'=>'crm_mobile_identity_company_unique','new_columns'=>['tenant_company_id','surface','external_identity_id']],
        'crm_service_categories' => ['old'=>'crm_service_categories_user_key_unique','old_columns'=>['user_id','key'],'new'=>'crm_service_categories_company_key_unique','new_columns'=>['tenant_company_id','key']],
        'crm_services' => ['old'=>'crm_services_user_key_unique','old_columns'=>['user_id','key'],'new'=>'crm_services_company_key_unique','new_columns'=>['tenant_company_id','key']],
        'crm_service_variants' => ['old'=>'crm_service_variants_unique','old_columns'=>['user_id','service_public_id','key'],'new'=>'crm_service_variants_company_unique','new_columns'=>['tenant_company_id','service_public_id','key']],
        'crm_service_requests' => ['old'=>'crm_service_requests_idempotency_unique','old_columns'=>['user_id','idempotency_key'],'new'=>'crm_service_requests_company_idem_unique','new_columns'=>['tenant_company_id','idempotency_key']],
        'crm_work_orders' => ['old'=>'crm_work_orders_number_unique','old_columns'=>['user_id','number'],'new'=>'crm_work_orders_company_number_unique','new_columns'=>['tenant_company_id','number']],
        'crm_work_order_time_entries' => ['old'=>'crm_work_order_time_idempotency_unique','old_columns'=>['user_id','idempotency_key'],'new'=>'crm_work_order_time_company_idem_unique','new_columns'=>['tenant_company_id','idempotency_key']],
        'crm_appointments' => ['old'=>'crm_appointments_idempotency_unique','old_columns'=>['user_id','idempotency_key'],'new'=>'crm_appointments_company_idem_unique','new_columns'=>['tenant_company_id','idempotency_key']],
        'crm_recurring_occurrences' => ['old'=>'crm_recurring_occurrence_unique','old_columns'=>['user_id','idempotency_key'],'new'=>'crm_recurring_occurrence_company_unique','new_columns'=>['tenant_company_id','idempotency_key']],
        'crm_form_templates' => ['old'=>'crm_form_templates_user_key_unique','old_columns'=>['user_id','key'],'new'=>'crm_form_templates_company_key_unique','new_columns'=>['tenant_company_id','key']],
        'crm_form_template_versions' => ['old'=>'crm_form_template_version_unique','old_columns'=>['user_id','template_public_id','version'],'new'=>'crm_form_template_version_company_unique','new_columns'=>['tenant_company_id','template_public_id','version']],
        'crm_form_fields' => ['old'=>'crm_form_fields_version_key_unique','old_columns'=>['user_id','version_public_id','key'],'new'=>'crm_form_fields_company_version_key_unique','new_columns'=>['tenant_company_id','version_public_id','key']],
        'crm_form_submissions' => ['old'=>'crm_form_submissions_idempotency_unique','old_columns'=>['user_id','idempotency_key'],'new'=>'crm_form_submissions_company_idem_unique','new_columns'=>['tenant_company_id','idempotency_key']],
        'crm_form_responses' => ['old'=>'crm_form_response_unique','old_columns'=>['user_id','submission_public_id','field_public_id'],'new'=>'crm_form_response_company_unique','new_columns'=>['tenant_company_id','submission_public_id','field_public_id']],
        'crm_service_history_events' => ['old'=>'crm_service_history_fingerprint_unique','old_columns'=>['user_id','fingerprint'],'new'=>'crm_service_history_company_fingerprint_unique','new_columns'=>['tenant_company_id','fingerprint']],
        'crm_field_service_profiles' => ['old'=>'crm_field_service_profiles_user_key_unique','old_columns'=>['user_id','profile_key'],'new'=>'crm_field_service_profiles_company_key_unique','new_columns'=>['tenant_company_id','profile_key']],
    ];

    public function up(): void
    {
        foreach ($this->indexes as $table => $index) {
            if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'tenant_company_id')) continue;
            Schema::table($table, function (Blueprint $t) use ($index): void {
                $t->dropUnique($index['old']);
                $t->unique($index['new_columns'], $index['new']);
            });
        }

        // Work orders had two legacy user-scoped unique constraints.
        if (Schema::hasTable('crm_work_orders') && Schema::hasColumn('crm_work_orders', 'tenant_company_id')) {
            Schema::table('crm_work_orders', function (Blueprint $t): void {
                $t->dropUnique('crm_work_orders_idempotency_unique');
                $t->unique(['tenant_company_id','idempotency_key'], 'crm_work_orders_company_idem_unique');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('crm_work_orders')) {
            Schema::table('crm_work_orders', function (Blueprint $t): void {
                $t->dropUnique('crm_work_orders_company_idem_unique');
                $t->unique(['user_id','idempotency_key'], 'crm_work_orders_idempotency_unique');
            });
        }

        foreach (array_reverse($this->indexes, true) as $table => $index) {
            if (! Schema::hasTable($table)) continue;
            Schema::table($table, function (Blueprint $t) use ($index): void {
                $t->dropUnique($index['new']);
                $t->unique($index['old_columns'], $index['old']);
            });
        }
    }
};
