<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/SignalHistoryRecord.php';
require __DIR__ . '/../System/Data/SignalArchiveEntry.php';

use App\Extensions\TitanSignalEngine\System\Data\SignalArchiveEntry;
use App\Extensions\TitanSignalEngine\System\Data\SignalHistoryRecord;

function archiveReadAssert(bool $condition, string $message): void
{
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

$entry = new SignalArchiveEntry(
    eventId: '0198aaaa-bbbb-7ccc-8ddd-eeeeeeeeeeee',
    batchId: '0198ffff-bbbb-7ccc-8ddd-eeeeeeeeeeee',
    scope: 'tenant',
    tenantCompanyId: 42,
    eventType: 'job.completed',
    traceId: '01981111-bbbb-7ccc-8ddd-eeeeeeeeeeee',
    correlationId: '01982222-bbbb-7ccc-8ddd-eeeeeeeeeeee',
    causationId: null,
    rootCausationId: '0198aaaa-bbbb-7ccc-8ddd-eeeeeeeeeeee',
    occurredAt: '2026-08-17T03:45:00+10:00',
    recordedAt: '2026-08-17T03:45:01+10:00',
    archiveDriver: 'laravel-storage:local',
    archiveLocator: 'titan-signal-engine/archive/2026/08/17/batch.jsonl.gz',
    archiveChecksum: str_repeat('a', 64),
    archiveSequence: 1,
    privacyProjected: true,
    originalChecksum: str_repeat('b', 64),
);
archiveReadAssert($entry->tenantCompanyId === 42, 'Archive catalog entry must preserve tenant ownership.');
archiveReadAssert($entry->privacyProjected, 'Archive catalog must preserve privacy projection state.');
archiveReadAssert($entry->archiveSequence === 1, 'Archive catalog must retain deterministic batch sequence.');

$record = SignalHistoryRecord::cold(
    event: ['event_id' => $entry->eventId, 'event_type' => $entry->eventType, 'scope' => 'tenant', 'tenant_company_id' => 42],
    entry: $entry,
    archiveVerified: true,
);
archiveReadAssert($record->storageTier === 'cold', 'Archived history must identify the cold storage tier.');
archiveReadAssert($record->archiveVerified, 'Cold records must expose archive-integrity verification.');
archiveReadAssert($record->canonicalChecksumVerified === false, 'Privacy-projected archives must not claim canonical envelope checksum verification.');
archiveReadAssert($record->event['event_id'] === $entry->eventId, 'History record must preserve immutable event identity.');

fwrite(STDOUT, "archive-read-behavior: PASS\n");
