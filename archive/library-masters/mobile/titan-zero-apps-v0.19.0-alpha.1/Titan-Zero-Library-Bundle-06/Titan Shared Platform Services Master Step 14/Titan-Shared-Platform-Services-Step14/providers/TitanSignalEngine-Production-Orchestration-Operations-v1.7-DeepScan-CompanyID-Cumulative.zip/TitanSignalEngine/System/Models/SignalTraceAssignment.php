<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalTraceAssignment extends Model
{
    protected $table = 'titan_signal_trace_assignments';
    protected $guarded = [];

    protected $casts = [
        'tenant_company_id' => 'integer',
        'tenant_key' => 'integer',
        'profile_version' => 'integer',
        'terminal_seen' => 'boolean',
        'first_event_at' => 'immutable_datetime',
        'last_event_at' => 'immutable_datetime',
        'last_evaluated_at' => 'immutable_datetime',
        'next_evaluation_at' => 'immutable_datetime',
        'fresh_until' => 'immutable_datetime',
        'evaluation_generation' => 'integer',
        'last_event_count' => 'integer',
        'last_sequence_violation_count' => 'integer',
        'last_missing_event_count' => 'integer',
        'last_profile_violation_count' => 'integer',
        'failure_count' => 'integer',
    ];
}
