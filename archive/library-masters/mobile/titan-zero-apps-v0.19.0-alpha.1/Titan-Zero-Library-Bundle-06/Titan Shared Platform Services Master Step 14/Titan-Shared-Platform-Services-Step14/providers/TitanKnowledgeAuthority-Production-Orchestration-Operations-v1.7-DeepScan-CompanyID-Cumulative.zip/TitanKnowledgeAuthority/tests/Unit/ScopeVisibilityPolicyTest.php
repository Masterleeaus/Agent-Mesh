<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Services\KnowledgeScopeVisibilityPolicy;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeAccessContext;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeScopeContext;
use PHPUnit\Framework\TestCase;

final class ScopeVisibilityPolicyTest extends TestCase
{
    public function test_matching_tenant_and_allowed_jurisdiction_are_visible(): void
    {
        $context = KnowledgeAccessContext::trusted(42, ['AU', 'AU-VIC']);
        $policy = new KnowledgeScopeVisibilityPolicy();

        self::assertTrue($policy->canRead($context, KnowledgeScopeContext::platform()));
        self::assertTrue($policy->canRead($context, KnowledgeScopeContext::tenant(42)));
        self::assertTrue($policy->canRead($context, KnowledgeScopeContext::jurisdiction('au-vic')));
    }

    public function test_cross_tenant_and_ungranted_jurisdiction_are_denied(): void
    {
        $context = KnowledgeAccessContext::trusted(42, ['AU-VIC']);
        $policy = new KnowledgeScopeVisibilityPolicy();

        self::assertFalse($policy->canRead($context, KnowledgeScopeContext::tenant(43)));
        self::assertFalse($policy->canRead($context, KnowledgeScopeContext::jurisdiction('AU-NSW')));
    }
}
