# Upgrade

## v0.3.0

Adds evidence, outcome-evidence links and outcome-transition tables through forward-only migrations. Existing canonical v0.2.0 OutcomeRecords remain valid. The legacy scaffold table remains retained and isolated.

The delayed observation scheduler is enabled only when the Wisdom runtime is enabled. Operators must ensure the Laravel scheduler and queue worker infrastructure are active for the `titan-wisdom` queue before expecting delayed observation events.

No migration converts existing outcome payloads into evidence automatically; provenance must be explicit rather than inferred.

## Identity history

v0.1.2 rebased the legacy key `titan-wisdom-engine` to Blueprint canonical key `titan-wisdom`, adopted Installer 1.7.8 root packaging and Manifest v2.2, and added `root_causation_id` compatibility lineage.
