<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\Contracts;
use App\Extensions\TitanAICore\System\DTO\PlanEnvelope;
use App\Extensions\TitanAICore\System\DTO\ValidationReport;
interface PlanValidatorContract { public function validate(PlanEnvelope $plan): ValidationReport; }
