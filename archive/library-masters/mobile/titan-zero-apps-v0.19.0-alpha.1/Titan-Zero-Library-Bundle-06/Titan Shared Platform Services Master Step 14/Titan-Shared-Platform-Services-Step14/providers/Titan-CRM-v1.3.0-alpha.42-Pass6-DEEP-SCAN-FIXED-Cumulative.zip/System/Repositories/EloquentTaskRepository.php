<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Repositories;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Contracts\TaskRepositoryContract; use Illuminate\Database\ConnectionInterface; use Illuminate\Support\Str; use Illuminate\Validation\ValidationException;
final class EloquentTaskRepository implements TaskRepositoryContract {
 public function __construct(private ConnectionInterface $db){}
 public function search(int $userId,array $filters=[]): array { $q=$this->db->table('crm_tasks')->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at'); if($v=$filters['status']??null)$q->where('status',$v); return $q->orderByRaw("CASE priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 WHEN 'normal' THEN 3 ELSE 4 END")->orderBy('due_at')->limit(min((int)($filters['limit']??100),250))->get()->map(fn($r)=>(array)$r)->all(); }
 public function create(int $userId,array $data): array { $id=$this->db->table('crm_tasks')->insertGetId(['public_id'=>(string)Str::ulid(),'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'name'=>(string)$data['name'],'status'=>$data['status']??'open','priority'=>$data['priority']??'normal','description'=>$data['description']??null,'project_public_id'=>$data['project_public_id']??null,'subject_type'=>$data['subject_type']??null,'subject_public_id'=>$data['subject_public_id']??null,'due_at'=>$data['due_at']??null,'assigned_user_id'=>$data['assigned_user_id']??null,'meta'=>json_encode($data['meta']??[]),'created_at'=>now(),'updated_at'=>now()]); return (array)$this->db->table('crm_tasks')->where('id',$id)->first(); }
 public function updateStatus(int $userId,string $publicId,string $status): array { $q=$this->db->table('crm_tasks')->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at'); if(!$q->exists())throw ValidationException::withMessages(['task'=>['Task not found.']]); $q->update(['status'=>$status,'completed_at'=>$status==='done'?now():null,'updated_at'=>now()]); return (array)$this->db->table('crm_tasks')->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->first(); }
}
