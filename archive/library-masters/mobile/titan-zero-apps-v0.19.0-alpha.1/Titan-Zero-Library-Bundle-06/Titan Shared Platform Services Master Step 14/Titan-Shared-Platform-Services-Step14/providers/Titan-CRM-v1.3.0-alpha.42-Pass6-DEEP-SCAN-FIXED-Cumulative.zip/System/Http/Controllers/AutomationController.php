<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Automation\{CrmAutomationActionCatalog,CrmAutomationTriggerCatalog};
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use App\Extensions\Crm\System\Security\CrmPermissionService;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Validation\ValidationException;

final class AutomationController extends Controller
{
    public function __construct(private CrmHumanMutationGateway $mutations) {}

    public function index(Request $request, ConnectionInterface $db, CrmAutomationTriggerCatalog $triggers, CrmAutomationActionCatalog $actions, CrmPermissionService $permissions)
    {
        $uid=(int)$request->user()->id; $permissions->authorize($uid,'crm.automations.manage');
        return view('crm::automation.index',['rules'=>$db->table('crm_automation_rules')->where('company_id',CrmCompanyScope::companyId($uid))->whereNull('deleted_at')->orderByDesc('id')->get(),'triggers'=>$triggers->all(),'actions'=>$actions->all()]);
    }

    public function store(Request $request, CrmAutomationTriggerCatalog $triggers, CrmAutomationActionCatalog $actions, CrmPermissionService $permissions)
    {
        $uid=(int)$request->user()->id; $permissions->authorize($uid,'crm.automations.manage');
        $data=$request->validate(['name'=>'required|string|max:255','trigger_key'=>'required|string|max:80','action_key'=>'nullable|string|max:80','action_arguments_json'=>'nullable|string|max:20000','actions_json'=>'nullable|string|max:50000','conditions_json'=>'nullable|string|max:20000','enabled'=>'nullable|boolean','cooldown_seconds'=>'nullable|integer|min:0|max:2592000']);
        $triggers->assertValid($data['trigger_key']); $conditions=$this->decodeAnyArray($data['conditions_json']??'[]','conditions_json');
        if(trim((string)($data['actions_json']??''))!==''){
            $definitions=$this->decodeAnyArray($data['actions_json'],'actions_json');
            if(!array_is_list($definitions)||$definitions===[])throw ValidationException::withMessages(['actions_json'=>['Provide a JSON list with at least one action.']]);
            foreach($definitions as $definition){if(!is_array($definition))throw ValidationException::withMessages(['actions_json'=>['Each action must be an object.']]);$actions->assertValid((string)($definition['action']??''));}
        } else {
            $actions->assertValid((string)($data['action_key']??''));
            $arguments=$this->decodeObject($data['action_arguments_json']??'{}','action_arguments_json');
            $definitions=[['action'=>$data['action_key'],'arguments'=>$arguments]];
        }
        $this->mutations->execute($request,'crm.automation.create',[
            'name'=>$data['name'],'trigger_key'=>$data['trigger_key'],'conditions'=>$conditions,'actions'=>$definitions,
            'enabled'=>$request->boolean('enabled',true),'cooldown_seconds'=>$data['cooldown_seconds']??0,
        ]);
        return redirect()->route('dashboard.user.crm.automations.index')->with('status','Automation rule created.');
    }

    public function toggle(Request $request,string $rule,CrmPermissionService $permissions)
    {
        $permissions->authorize((int)$request->user()->id,'crm.automations.manage');
        $this->mutations->execute($request,'crm.automation.toggle',['public_id'=>$rule]);
        return back()->with('status','Automation rule updated.');
    }

    private function decodeObject(string $json,string $field): array { $decoded=$this->decodeAnyArray($json,$field);if(array_is_list($decoded)&&$decoded!==[])throw ValidationException::withMessages([$field=>['Provide a JSON object.']]);return $decoded; }
    private function decodeAnyArray(string $json,string $field): array { $decoded=json_decode($json,true);if(!is_array($decoded))throw ValidationException::withMessages([$field=>['Provide valid JSON.']]);return $decoded; }
}
