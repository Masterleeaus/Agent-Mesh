<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Host;

final class NexusMenuRegistrar
{
    public function __construct(private readonly TitanMenuCompatibilityAdapter $adapter) {}

    public function registerNavigation(): void
    {
        $this->adapter->registerAll(self::definitions());
    }

    /** @return list<array<string,mixed>> */
    public static function definitions(): array
    {
        $parentKey = 'titan-nexus';
        $definitions = [self::definition($parentKey, 'Titan Nexus', 'dashboard.user.titan.nexus.index', '/dashboard/user/titan-nexus', null, 60, 'tabler-affiliate')];
        $children = [
            ['overview', 'Overview', 'dashboard.user.titan.nexus.overview', '/dashboard/user/titan-nexus/overview'],
            ['profile', 'Business Profile', 'dashboard.user.titan.nexus.profile', '/dashboard/user/titan-nexus/profile'],
            ['compilations', 'Compilations', 'dashboard.user.titan.nexus.compilations', '/dashboard/user/titan-nexus/compilations'],
            ['validation', 'Validation', 'dashboard.user.titan.nexus.validation', '/dashboard/user/titan-nexus/validation'],
            ['preview', 'Configuration Preview', 'dashboard.user.titan.nexus.preview', '/dashboard/user/titan-nexus/preview'],
            ['history', 'History', 'dashboard.user.titan.nexus.history', '/dashboard/user/titan-nexus/history'],
            ['diff', 'Recompile / Diff', 'dashboard.user.titan.nexus.diff', '/dashboard/user/titan-nexus/diff'],
            ['provisioning', 'Provisioning Plans', 'dashboard.user.titan.nexus.provisioning', '/dashboard/user/titan-nexus/provisioning'],
            ['receipts', 'Provisioning Receipts', 'dashboard.user.titan.nexus.receipts', '/dashboard/user/titan-nexus/receipts'],
        ];
        foreach ($children as $index => [$key, $label, $route, $url]) {
            $definitions[] = self::definition("titan-nexus.{$key}", $label, $route, $url, $parentKey, 61 + $index, 'tabler-circle');
        }
        return $definitions;
    }

    /** @return array<string,mixed> */
    private static function definition(string $key, string $label, string $route, string $url, ?string $parentKey, int $priority, string $icon): array
    {
        return [
            'registry' => 'navigation',
            'key' => $key,
            'label' => $label,
            'route' => $route,
            'parent_key' => $parentKey,
            'priority' => $priority,
            'icon' => $icon,
            'surfaces' => ['command'],
            'legacy_identity' => ['key' => $key],
            'legacy_fallback_identity' => ['route' => $route],
            'legacy_fields' => [
                'name' => $label,
                'title' => $label,
                'label' => $label,
                'route' => $route,
                'url' => $url,
                'icon' => $icon,
            ],
        ];
    }
}
