<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanNexus\Unit;

use App\Extensions\TitanNexus\System\Adapters\Platform\PlatformReadinessAdapter;
use App\Extensions\TitanNexus\System\Contracts\VerticalDefinitionSourceContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Exceptions\NexusValidationException;
use App\Extensions\TitanNexus\System\Services\DeterministicNexusCompiler;
use App\Extensions\TitanNexus\System\Services\NexusManager;
use App\Extensions\TitanNexus\System\Services\SemanticNexusValidator;
use PHPUnit\Framework\TestCase;

final class PreviewTest extends TestCase
{
    public function test_preview_is_dry_run_and_does_not_mutate_draft(): void
    {
        $source = new class implements VerticalDefinitionSourceContract {
            public function resolve(BusinessProfile $profile): VerticalDefinition
            {
                return VerticalDefinition::fromArray([
                    'vertical_id' => $profile->verticalId(),
                    'vertical_version' => $profile->verticalVersion(),
                    'knowledge_snapshot_version' => 'au-vic-2026.08',
                    'sections' => ['operations' => ['recurring' => true]],
                ]);
            }
        };
        $manager = new NexusManager(new DeterministicNexusCompiler('0.4.0'), $source, new SemanticNexusValidator(new PlatformReadinessAdapter()));
        $draft = $manager->newDraft($this->profile(), $this->trace(), '44444444-4444-4444-8444-444444444444');

        $preview = $manager->previewDraft($draft, '4');

        self::assertTrue($preview->dryRun());
        self::assertTrue($preview->canCompile());
        self::assertNotNull($preview->compiledConfiguration());
        self::assertNull($draft->compiledConfiguration());
    }

    public function test_compile_throws_structured_validation_exception_on_error(): void
    {
        $source = new class implements VerticalDefinitionSourceContract {
            public function resolve(BusinessProfile $profile): VerticalDefinition
            {
                return VerticalDefinition::fromArray([
                    'vertical_id' => $profile->verticalId(),
                    'vertical_version' => $profile->verticalVersion(),
                    'knowledge_snapshot_version' => null,
                    'sections' => [],
                    'validation' => ['require_knowledge_snapshot' => true],
                ]);
            }
        };
        $manager = new NexusManager(new DeterministicNexusCompiler('0.4.0'), $source, new SemanticNexusValidator(new PlatformReadinessAdapter()));
        $draft = $manager->newDraft($this->profile(), $this->trace(), '44444444-4444-4444-8444-444444444444');

        $this->expectException(NexusValidationException::class);
        $manager->compileDraft($draft, '4');
    }

    private function profile(): BusinessProfile
    {
        return BusinessProfile::fromArray([
            'tenant_company_id' => 42,
            'profile_version' => '3.0.0',
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'jurisdiction' => ['country_code' => 'AU'],
            'timezone' => 'Australia/Melbourne',
            'sections' => [],
        ]);
    }

    private function trace(): TraceContext
    {
        return TraceContext::fromArray([
            'tenant_company_id' => 42,
            'trace_id' => '11111111-1111-4111-8111-111111111111',
            'correlation_id' => '22222222-2222-4222-8222-222222222222',
            'causation_id' => '33333333-3333-4333-8333-333333333333',
        ]);
    }
}
