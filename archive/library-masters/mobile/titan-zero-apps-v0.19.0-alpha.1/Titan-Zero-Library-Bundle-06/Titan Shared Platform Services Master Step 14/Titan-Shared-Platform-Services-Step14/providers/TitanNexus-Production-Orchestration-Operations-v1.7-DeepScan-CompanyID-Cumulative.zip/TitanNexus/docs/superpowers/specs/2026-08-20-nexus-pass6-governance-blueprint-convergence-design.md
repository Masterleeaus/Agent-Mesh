# Titan Nexus Pass 6 Governance + Blueprint Convergence Design

## Scope
Rebase Titan Nexus onto the Blueprint v2.2 `configuration-orchestrator` profile and make provisioning execution consume Risk, Governance, Assurance, optional Autonomy, Signal, and Rewind public contracts before Command Bus mutation.

## Boundaries
- Nexus owns compilations, configuration history, semantic diffs, and provisioning plans/receipts only.
- No direct imports from or writes to other Titan extensions.
- Required governance dependencies fail closed before mutation.
- Compilation semantics remain unchanged; compiler version stays 0.5.0.
- Historical persistence formats remain readable; v2.2 public contract exports may use canonical schema shapes.

## Execution sequence
For each runnable provisioning operation: Risk -> Governance -> Autonomy when agent-initiated -> Assurance -> Signal preflight -> Rewind preflight -> Command Bus -> Signal outcome -> Rewind outcome. Missing or denied pre-write gates prevent the mutation. Post-write observability failure is recorded as degraded evidence without pretending the mutation failed.

## Contract convergence
The package adopts Installer `extension.json` v1 and canonical `extension.manifest.json` v2.2, includes the Nexus blueprint schemas and required production documentation, and exports canonical schema-shaped artifacts without destructively changing historical stored snapshots.

## Tests
Standalone tests cover gate order, fail-closed behavior, autonomous authority, approval evidence, outcome evidence, canonical contract exports, v2.2 manifest validation, architecture boundaries, and unchanged prior migrations.
