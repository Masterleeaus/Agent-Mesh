# Titan Assets Option A Design

## Goal
Create a production-oriented Titan Assets extension that becomes the authoritative writer for individually tracked tools, equipment, fleet vehicles, maintenance, repairs, warranties, mileage and premises links while preserving existing asset records already stored in `crm_locker_*` tables. Titan Locker remains authoritative only for inventory, stock, purchasing, suppliers and goods movement.

## Host compatibility
- Installer: Titan Extension Manager 1.7.8.
- PHP 8.3 / Laravel 10.50 / MySQL/MariaDB.
- Canonical tenant boundary: `company_id`. Current CRM host scope is resolved through `App\\Extensions\\Crm\\System\\Tenancy\\CrmCompanyScope`; its historical method name is treated as a host compatibility detail, not the Assets persistence vocabulary.
- Reuse CRM permission middleware and existing Locker asset permissions during the ownership transition so current authorised users do not lose access.
- Preserve data on install, upgrade, rollback and uninstall.

## Existing database evidence
The live dump contains a unique-keyed `menus` table with `parent_id`, `key`, `route`, `label`, `icon`, `order`, `is_active`, `extension` and `custom_menu`. Existing asset menu rows are `crm_tools`, `crm_equipment`, `crm_fleet`, `crm_maintenance`, and `crm_customer_assets`, currently parented under `ext_crm_gear`. Asset data already exists in `crm_locker_tools`, `crm_locker_equipment`, `crm_locker_fleet_vehicles`, `crm_locker_maintenance_records`, `crm_locker_asset_events`, and `crm_customer_assets`.

## Domain ownership
Titan Assets owns writes to:
- `crm_locker_tools`
- `crm_locker_equipment`
- `crm_locker_fleet_vehicles`
- `crm_locker_maintenance_records`
- `crm_locker_asset_events`
- new `titan_asset_*` repair, warranty, mileage and premises-link tables.

Titan Locker continues to own inventory/stock/purchasing tables and must stop registering direct asset writers after the convergence upgrade.

## Navigation
Create top-level `titan_assets` / **Assets**, immediately after the existing Gear/Inventory group. Self-heal these children: Overview, Asset Register, Tools, Equipment, Fleet, Customer Assets, Custody & Allocations, Maintenance, Repairs, Repair Templates, Warranties, Mileage, Premises Links, QR / Scan, Settings. Adopt the existing `crm_tools`, `crm_equipment`, `crm_fleet`, `crm_maintenance`, and `crm_customer_assets` rows instead of creating duplicates. Rename the remaining Locker parent from `Gear` to `Inventory & Supplies` when present.

Menu healing runs at boot, validates named routes, repairs parent/route/label/icon/order/ownership/active state, and regenerates `App\\Services\\Common\\MenuService` only when rows changed or a versioned cache marker is stale. Failure must never break application boot.

## UI
Use the existing Titan Locker/CRM interaction-page shell as the visual donor. The Assets page is a focused business-asset control centre with metrics and section-specific tables/forms. Do not copy Worksuite donor layouts or module helpers.

## Donor extraction
Port only useful concepts from Asset, FSMEquipment, FSMEquipmentWarranty, FSMVehicle, FSMRepair and FSMRepairTemplate. Do not import donor module providers, generic host migrations, duplicate repair schemas, legacy `Modules\\` namespaces, `module_path()`, or SupplyChain/WMS/FSMStock inventory ownership.

## Data safety
Core asset tables are ensured non-destructively: create only when absent and add only missing hardening columns. New Titan Assets tables have non-destructive rollback. No migration may drop or rename existing `crm_locker_*` or `crm_customer_assets` tables.
