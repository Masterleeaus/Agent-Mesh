<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\DTO;

final class NormalizedInboundMessage
{
    public function __construct(
        public readonly string $provider,
        public readonly string $providerEventId,
        public readonly string $providerThreadId,
        public readonly ?string $providerMessageId,
        public readonly ?string $senderRef,
        public readonly ?string $recipientRef,
        public readonly ?string $body,
        public readonly string $messageType = 'text',
        public readonly array $attachments = [],
        public readonly array $metadata = [],
        public readonly ?string $providerCreatedAt = null,
    ) {
    }

    public function toArray(): array
    {
        return get_object_vars($this);
    }
}
