<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

enum ProvisioningPlanStatus: string
{
    case Blocked = 'blocked';
    case RequiresApproval = 'requires_approval';
    case Ready = 'ready';
    case Applied = 'applied';
    case PartiallyApplied = 'partially_applied';
    case Failed = 'failed';
}
