<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalArchiveBatch extends Model
{
    protected $table = 'titan_signal_archive_batches';
    protected $guarded = [];
    protected $casts = ['tenant_company_id' => 'integer', 'tenant_key' => 'integer', 'event_count' => 'integer', 'prune_event_count' => 'integer', 'archive_event_count' => 'integer', 'criteria' => 'array', 'archived_at' => 'immutable_datetime', 'verified_at' => 'immutable_datetime', 'pruned_at' => 'immutable_datetime'];
}
