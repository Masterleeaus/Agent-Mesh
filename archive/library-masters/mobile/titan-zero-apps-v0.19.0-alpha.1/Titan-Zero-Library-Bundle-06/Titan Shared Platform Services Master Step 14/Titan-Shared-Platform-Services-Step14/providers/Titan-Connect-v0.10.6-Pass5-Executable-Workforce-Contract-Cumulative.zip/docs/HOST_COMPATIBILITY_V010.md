# Titan Connect v0.10.6 — MagicAI Host Compatibility

## Purpose
v0.10.4 adds live MagicAI database-menu materialization on top of the v0.10 host-compatibility layer.

## Delivered
- Hardened `extension.manifest.json` sidecar with compatibility, dependencies, capabilities, route profiles, `company_id` tenancy, table ownership, queues, lifecycle and test metadata.
- Stable service-provider `registerKey()` returning `titan-connect`.
- Static idempotent `uninstall()` removes only `public/vendor/titan-connect`; database data, credentials and published configuration remain preserved by default.
- Config and asset publishes now include the shared `extension` tag as well as Titan Connect-specific tags.
- Explicit administrator permission catalogue aligned with all Super Admin Channels menu keys and the `titan-connect.admin.channels.*` route family.
- Explicit plan feature catalogue for Titan Connect Core, Channels and Voice. These are entitlements only; runtime `company_id`, membership, channel-role and WorkCore authorization remain independent.
- `HostMenuLifecycle` safely calls MagicAI `MenuService::regenerate()` only when available.
- `titan-connect:host-sync` provides the explicit post-install/post-upgrade host contribution/cache step; ordinary web boot does not regenerate menu caches.
- Older hosts continue to use one central Blueprint-v3 compatibility bridge instead of Titan Connect editing MagicAI core menu files directly.

## Install/upgrade sequence
1. Install/upgrade Titan Connect through the Titan extension manager.
2. Apply normal extension migrations through the host deployment process.
3. Publish extension assets/config through the host installer/shared `extension` tag.
4. Run `php artisan titan-connect:host-sync`.
5. Run `php artisan titan-connect:diagnose`.
6. In staging, run `php artisan titan-connect:certify --queue-probe --broadcast-probe --two-company-probe --strict`.
7. Run the opt-in MySQL feature suite from `docs/HOST_CERTIFICATION.md`.

## Remaining external gate
A standalone ZIP cannot prove the actual host provider map, administrator-role database contents, plan-feature registry, queue worker, broadcaster, theme renderer or live provider credentials. Those remain the live host certification gate.
