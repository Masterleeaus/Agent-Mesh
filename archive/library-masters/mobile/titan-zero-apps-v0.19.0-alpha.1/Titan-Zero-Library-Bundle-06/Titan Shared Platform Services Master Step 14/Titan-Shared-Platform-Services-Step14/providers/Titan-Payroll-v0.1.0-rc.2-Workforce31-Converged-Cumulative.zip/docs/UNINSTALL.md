# Uninstall

Default policy is retain. Destructive data removal requires explicit tenant retention policy and future verified uninstall tooling; Pass 1 does not mutate host tables.
