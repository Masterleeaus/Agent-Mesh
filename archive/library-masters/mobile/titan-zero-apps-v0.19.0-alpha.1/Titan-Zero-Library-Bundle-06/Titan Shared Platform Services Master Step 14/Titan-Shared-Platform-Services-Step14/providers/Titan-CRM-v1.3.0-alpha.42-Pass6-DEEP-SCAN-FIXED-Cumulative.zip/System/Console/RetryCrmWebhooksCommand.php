<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\Integrations\CrmWebhookDispatcher;
use Illuminate\Console\Command;

final class RetryCrmWebhooksCommand extends Command
{
    protected $signature = 'crm:webhooks:retry {--user=} {--limit=100} {--dead-letter=}';
    protected $description = 'Retry due CRM webhook deliveries with bounded exponential backoff.';

    public function handle(CrmWebhookDispatcher $dispatcher): int
    {
        $user = $this->option('user');
        $dead=(string)($this->option('dead-letter')??'');
        if($dead!==''){$dispatcher->requeueDeadLetter($dead,$user!==null?(int)$user:null);$this->info('CRM webhook dead letter requeued: '.$dead);}
        $results = $dispatcher->retryDue($user !== null ? (int)$user : null, (int)$this->option('limit'));
        $delivered = count(array_filter($results, fn(array $r): bool => (bool)($r['ok'] ?? false)));
        $this->info('CRM webhook retries processed: '.count($results).'; delivered: '.$delivered);
        return self::SUCCESS;
    }
}
