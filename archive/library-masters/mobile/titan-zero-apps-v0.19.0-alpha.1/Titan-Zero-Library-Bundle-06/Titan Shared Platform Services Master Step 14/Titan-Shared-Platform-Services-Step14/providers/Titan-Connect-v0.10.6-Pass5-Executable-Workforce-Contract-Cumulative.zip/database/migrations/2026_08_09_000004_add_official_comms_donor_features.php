<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_titan_connect_external_threads')) {
            Schema::table('ext_titan_connect_external_threads', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_connect_external_threads', 'external_contact_id')) {
                    $table->unsignedBigInteger('external_contact_id')->nullable()->index()->after('external_contact_ref');
                }
                if (! Schema::hasColumn('ext_titan_connect_external_threads', 'assigned_user_id')) {
                    $table->unsignedBigInteger('assigned_user_id')->nullable()->index()->after('status');
                }
                if (! Schema::hasColumn('ext_titan_connect_external_threads', 'pinned_rank')) {
                    $table->unsignedInteger('pinned_rank')->default(0)->index()->after('assigned_user_id');
                }
                if (! Schema::hasColumn('ext_titan_connect_external_threads', 'color')) {
                    $table->string('color', 32)->nullable()->after('pinned_rank');
                }
                if (! Schema::hasColumn('ext_titan_connect_external_threads', 'priority')) {
                    $table->string('priority', 16)->default('normal')->index()->after('color');
                }
                if (! Schema::hasColumn('ext_titan_connect_external_threads', 'closed_at')) {
                    $table->timestamp('closed_at')->nullable()->index()->after('last_message_at');
                }
            });
        }

        if (! Schema::hasTable('ext_titan_connect_external_contacts')) {
            Schema::create('ext_titan_connect_external_contacts', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('provider', 40)->index();
                $table->string('external_contact_ref', 191);
                $table->string('display_name')->nullable();
                $table->string('email')->nullable()->index();
                $table->string('phone', 64)->nullable()->index();
                $table->string('avatar', 2048)->nullable();
                $table->string('country', 120)->nullable()->index();
                $table->string('ip_address', 64)->nullable();
                $table->string('linked_entity_type', 120)->nullable();
                $table->string('linked_entity_id', 191)->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->unique(['company_id', 'provider', 'external_contact_ref'], 'tc_external_contact_unique');
                $table->index(['company_id', 'linked_entity_type', 'linked_entity_id'], 'tc_external_contact_link_idx');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_contact_tags')) {
            Schema::create('ext_titan_connect_contact_tags', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('name', 120);
                $table->string('color', 32)->default('#64748b');
                $table->string('background_color', 32)->nullable();
                $table->unsignedBigInteger('created_by')->nullable()->index();
                $table->timestamps();
                $table->unique(['company_id', 'name'], 'tc_contact_tag_company_name_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_external_thread_tags')) {
            Schema::create('ext_titan_connect_external_thread_tags', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->foreignId('external_thread_id')->constrained('ext_titan_connect_external_threads', 'id', 'tc_thread_tags_thread_fk')->cascadeOnDelete();
                $table->foreignId('contact_tag_id')->constrained('ext_titan_connect_contact_tags')->cascadeOnDelete();
                $table->timestamps();
                $table->unique(['external_thread_id', 'contact_tag_id'], 'tc_external_thread_tag_unique');
                $table->index(['company_id', 'external_thread_id'], 'tc_external_thread_tag_company_idx');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_canned_responses')) {
            Schema::create('ext_titan_connect_canned_responses', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('owner_user_id')->nullable()->index();
                $table->string('title', 191);
                $table->longText('content');
                $table->string('shortcut', 64)->nullable();
                $table->boolean('is_company_shared')->default(false)->index();
                $table->timestamps();
                $table->softDeletes();
                $table->index(['company_id', 'owner_user_id', 'updated_at'], 'tc_canned_response_lookup_idx');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_voice_calls')) {
            Schema::create('ext_titan_connect_voice_calls', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->foreignId('channel_connection_id')->nullable()->constrained('ext_titan_connect_channel_connections')->nullOnDelete();
                $table->foreignId('external_thread_id')->nullable()->constrained('ext_titan_connect_external_threads')->nullOnDelete();
                $table->foreignId('conversation_id')->nullable()->constrained('ext_titan_connect_conversations')->nullOnDelete();
                $table->unsignedBigInteger('actor_id')->nullable()->index();
                $table->string('provider', 40)->index();
                $table->string('direction', 16)->default('outbound')->index();
                $table->string('status', 24)->default('starting')->index();
                $table->string('external_session_id', 191)->nullable()->index();
                $table->timestamp('started_at')->nullable();
                $table->timestamp('ended_at')->nullable();
                $table->unsignedInteger('duration_seconds')->default(0);
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->index(['company_id', 'status', 'created_at'], 'tc_voice_call_company_status_idx');
            });
        }

        if (! Schema::hasTable('ext_titan_connect_voice_transcripts')) {
            Schema::create('ext_titan_connect_voice_transcripts', function (Blueprint $table): void {
                $table->id();
                $table->uuid('uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->foreignId('voice_call_id')->constrained('ext_titan_connect_voice_calls')->cascadeOnDelete();
                $table->string('role', 32)->index();
                $table->longText('message');
                $table->timestamp('spoken_at')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->index(['company_id', 'voice_call_id', 'created_at'], 'tc_voice_transcript_order_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_connect_voice_transcripts');
        Schema::dropIfExists('ext_titan_connect_voice_calls');
        Schema::dropIfExists('ext_titan_connect_canned_responses');
        Schema::dropIfExists('ext_titan_connect_external_thread_tags');
        Schema::dropIfExists('ext_titan_connect_contact_tags');
        Schema::dropIfExists('ext_titan_connect_external_contacts');

        if (Schema::hasTable('ext_titan_connect_external_threads')) {
            Schema::table('ext_titan_connect_external_threads', function (Blueprint $table): void {
                foreach (['external_contact_id', 'assigned_user_id', 'pinned_rank', 'color', 'priority', 'closed_at'] as $column) {
                    if (Schema::hasColumn('ext_titan_connect_external_threads', $column)) {
                        $table->dropColumn($column);
                    }
                }
            });
        }
    }
};
