<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Console\Commands;

use App\Extensions\TitanSignalEngine\System\Services\AutomaticTraceEvaluationService;
use Illuminate\Console\Command;

final class EvaluateSignalTraces extends Command
{
    protected $signature = 'titan:signal-traces:evaluate {--limit=250 : Maximum due trace/profile assignments to evaluate}';
    protected $description = 'Evaluate due Titan Signal trace profiles and refresh sequence/completeness projections.';

    public function handle(AutomaticTraceEvaluationService $service): int
    {
        $result = $service->evaluateDue((int) $this->option('limit'));
        $this->line(json_encode($result, JSON_THROW_ON_ERROR));
        return $result['failed'] > 0 ? self::FAILURE : self::SUCCESS;
    }
}
