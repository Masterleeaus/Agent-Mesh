<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Import;
final class CrmImportTransformRegistry
{
    public const TRANSFORMS=['trim','lowercase','uppercase','email','phone','boolean','date','static'];
    public function apply(mixed $value,string $transform,mixed $argument=null): mixed
    { return match($transform){'trim'=>trim((string)$value),'lowercase'=>mb_strtolower(trim((string)$value)),'uppercase'=>mb_strtoupper(trim((string)$value)),'email'=>filter_var(mb_strtolower(trim((string)$value)),FILTER_VALIDATE_EMAIL)?:null,'phone'=>preg_replace('/[^0-9+]+/','',(string)$value),'boolean'=>in_array(mb_strtolower(trim((string)$value)),['1','true','yes','y','on'],true),'date'=>$this->date($value),'static'=>$argument,default=>throw new \InvalidArgumentException("Unsupported import transform: {$transform}")}; }
    private function date(mixed $value): ?string { try{return (new \DateTimeImmutable((string)$value))->format('Y-m-d');}catch(\Throwable){return null;} }
}
