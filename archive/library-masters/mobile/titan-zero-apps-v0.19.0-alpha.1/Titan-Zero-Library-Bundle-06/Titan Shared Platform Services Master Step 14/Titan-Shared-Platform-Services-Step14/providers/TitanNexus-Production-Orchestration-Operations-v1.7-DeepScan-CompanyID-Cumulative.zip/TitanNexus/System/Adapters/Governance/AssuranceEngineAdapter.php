<?php

declare(strict_types=1);
namespace App\Extensions\TitanNexus\System\Adapters\Governance;
use App\Extensions\TitanNexus\System\Contracts\AssuranceGatewayContract;
use App\Extensions\TitanNexus\System\Domain\AssuranceDecision;
use App\Extensions\TitanNexus\System\Domain\AutonomyDecision;
use App\Extensions\TitanNexus\System\Domain\GovernanceDecision;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\RiskDecision;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use Closure; use RuntimeException;
final class AssuranceEngineAdapter implements AssuranceGatewayContract
{
    private readonly ?Closure $gateway; public function __construct(?callable $gateway=null){$this->gateway=$gateway===null?null:Closure::fromCallable($gateway);}
    public function verify(ProvisioningOperation $operation,TraceContext $traceContext,ProvisioningExecutionContext $executionContext,RiskDecision $riskDecision,GovernanceDecision $governanceDecision,?AutonomyDecision $autonomyDecision):AssuranceDecision
    {
        if($this->gateway===null)throw new RuntimeException('Titan Nexus Assurance public gateway is not configured.');
        $result=($this->gateway)(['operation'=>$operation->toContractArray(),'trace_context'=>$traceContext->toArray(),'execution_context'=>$executionContext->toArray(),'risk_decision'=>$riskDecision->toArray(),'governance_decision'=>$governanceDecision->toArray(),'autonomy_decision'=>$autonomyDecision?->toArray()]);
        if(!is_array($result))throw new RuntimeException('Titan Assurance public gateway must return an array decision.');
        return AssuranceDecision::fromArray($result);
    }
}
