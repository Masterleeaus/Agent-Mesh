<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\DTOs;

use App\Extensions\TitanAutonomy\System\Enums\LearningLabel;

final readonly class StateTransitionResult
{
    public function __construct(
        public CapabilityState $state,
        public LearningLabel $learningLabel,
        public bool $qualifying,
    ) {}
}
