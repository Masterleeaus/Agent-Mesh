<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\InteractionEngine;

final class CrmInteractionQuickPromptRegistry
{
    /** @return list<array{label:string,message:string}> */
    public function forPage(string $surface, string $pageTitle='', ?string $recordType=null): array
    {
        $surface = strtolower(trim($surface));
        $title = strtolower(trim($pageTitle));
        $record = strtolower(trim((string) $recordType));
        if ($record !== '') return $this->recordPrompts($record);

        if (str_contains($title, 'customer') || str_contains($title, 'contact') || $surface === 'customers') return $this->map([
            'Add customer' => 'Add a new customer', 'Find customer' => 'Find a customer',
            'Show recent customers' => 'Show my recently active customers', 'Customer history' => 'Show customer activity history',
            'Inactive customers' => 'Show inactive customers',
        ]);
        if (str_contains($title, 'lead') || str_contains($title, 'opportun') || str_contains($title, 'pipeline') || $surface === 'leads') return $this->map([
            'Create lead' => 'Create a new lead', 'Show hot leads' => 'Show my hottest leads',
            'Follow up today' => 'Show leads that need follow up today', 'Qualify leads' => 'Help me qualify current leads',
            'Prepare quote' => 'Prepare a quote for a lead',
        ]);
        if (str_contains($title, 'invoice') || str_contains($title, 'quote') || str_contains($title, 'payment') || str_contains($title, 'bookkeep') || $surface === 'money') return $this->map([
            'Create invoice' => 'Create an invoice', 'Prepare quote' => 'Prepare a quote',
            'Overdue invoices' => 'Show overdue invoices', 'Outstanding receivables' => 'Show outstanding CRM receivables',
            'Quote pipeline' => 'Show quotes waiting for customer action',
        ]);
        if (str_contains($title, 'calendar') || $surface === 'crew') return $this->map([
            'Create calendar event' => 'Create a CRM calendar event', 'Show follow-ups' => 'Show CRM follow-ups due today',
            'Show tasks' => 'Show CRM tasks due today',
        ]);
        if (str_contains($title, 'report') || str_contains($title, 'insight') || str_contains($title, 'presentation') || $surface === 'insights') return $this->map([
            'Pipeline health' => 'Show sales pipeline health', 'Overdue trends' => 'Show overdue invoice trends',
            'Customer activity' => 'Summarize recent customer activity', 'Lead conversion' => 'Show lead conversion performance',
        ]);
        if (str_contains($title, 'automation') || $surface === 'automate') return $this->map([
            'Show automation rules' => 'Show my CRM automation rules', 'What is enabled?' => 'Which CRM automation rules are enabled?',
            'Simulate a rule' => 'Preview what a CRM automation rule would do', 'Show recent runs' => 'Show recent CRM automation activity',
            'Find conflicts' => 'Check CRM automation rules for overlapping triggers',
        ]);
        if ($surface === 'settings') return $this->map([
            'Review settings' => 'Review my CRM settings', 'Show integrations' => 'Show integration status',
            'Privacy settings' => 'Explain privacy and retention settings', 'Command governance' => 'Explain how CRM writes are governed',
            'Automation settings' => 'Show CRM automation settings',
        ]);
        if ($surface === 'work' || str_contains($title, 'project') || str_contains($title, 'task')) return $this->map([
            'Create project' => 'Create a CRM project', 'Create task' => 'Create a CRM task',
            'Tasks due today' => 'Show CRM tasks due today', 'Related customers' => 'Show customers related to these CRM projects',
        ]);

        return $this->map([
            'What needs attention today?' => 'What CRM work needs attention today?',
            'Show overdue invoices' => 'Show overdue invoices', 'Follow up leads' => 'Show leads that need follow up',
            'Pipeline health' => 'Show sales pipeline health',
        ]);
    }

    /** @return list<array{label:string,message:string}> */
    private function recordPrompts(string $record): array
    {
        return match ($record) {
            'job', 'work_order' => $this->map(['Prepare quote' => 'Prepare a quote for this job', 'Create invoice' => 'Create an invoice for this job']),
            'customer', 'company', 'contact' => $this->map(['Update details' => 'Update this customer', 'Show history' => 'Show this customer history', 'Prepare quote' => 'Prepare a quote for this customer', 'Show invoices' => 'Show invoices for this customer']),
            'lead', 'opportunity', 'deal' => $this->map(['Update status' => 'Update this lead or opportunity', 'Follow up' => 'Create a follow-up for this record', 'Prepare quote' => 'Prepare a quote', 'Move stage' => 'Move this opportunity to another stage', 'Mark won' => 'Mark this opportunity won']),
            'invoice' => $this->map(['Send invoice' => 'Send this invoice', 'Send reminder' => 'Send an overdue reminder', 'Explain balance' => 'Explain this invoice balance', 'Show customer' => 'Show the customer for this invoice']),
            'quote', 'estimate' => $this->map(['Explain quote' => 'Explain this quote', 'Create invoice' => 'Create an invoice from this quote', 'Show customer' => 'Show the customer for this quote']),
            default => $this->map(['Update this record' => 'Update this CRM record', 'Show history' => 'Show CRM history for this record', 'What needs attention?' => 'What needs attention for this CRM record?', 'Explain status' => 'Explain the current CRM status']),
        };
    }

    /** @param array<string,string> $items @return list<array{label:string,message:string}> */
    private function map(array $items): array
    {
        $out = [];
        foreach ($items as $label => $message) $out[] = ['label' => $label, 'message' => $message];
        return $out;
    }
}
