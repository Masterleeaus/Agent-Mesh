<?php

declare(strict_types=1);
namespace App\Extensions\TitanNexus\System\Adapters\Governance;
use App\Extensions\TitanNexus\System\Contracts\AutonomyGatewayContract;
use App\Extensions\TitanNexus\System\Domain\AutonomyDecision;
use App\Extensions\TitanNexus\System\Domain\GovernanceDecision;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\RiskDecision;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use Closure; use RuntimeException;
final class AutonomyEngineAdapter implements AutonomyGatewayContract
{
    private readonly ?Closure $gateway; public function __construct(?callable $gateway=null){$this->gateway=$gateway===null?null:Closure::fromCallable($gateway);}
    public function authorize(ProvisioningOperation $operation,TraceContext $traceContext,ProvisioningExecutionContext $executionContext,RiskDecision $riskDecision,GovernanceDecision $governanceDecision):AutonomyDecision
    {
        if($this->gateway===null)throw new RuntimeException('Titan Nexus Autonomy public gateway is not configured for autonomous execution.');
        $result=($this->gateway)(['operation'=>$operation->toContractArray(),'trace_context'=>$traceContext->toArray(),'execution_context'=>$executionContext->toArray(),'risk_decision'=>$riskDecision->toArray(),'governance_decision'=>$governanceDecision->toArray()]);
        if(!is_array($result))throw new RuntimeException('Titan Autonomy public gateway must return an array decision.');
        return AutonomyDecision::fromArray($result);
    }
}
