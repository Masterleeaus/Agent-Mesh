<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\View;

use Illuminate\View\Factory;
use Illuminate\View\View;
use Throwable;

/**
 * Renders Titan Connect content inside MagicAI's real dashboard layout.
 *
 * Titan loads extension routes directly from the extension provider, outside the
 * host routes/web.php wrapper. Rendering panel.layout.app as the root response
 * avoids relying on child-view inheritance state across extension/theme finders.
 */
final class MagicAiDashboardRenderer
{
    public function __construct(private readonly Factory $views)
    {
    }

    /** @param array<string,mixed> $data */
    public function render(string $contentView, array $data = [], ?string $title = null): View
    {
        // Keep the render counter above zero while the content partial renders so
        // @push('css') / @push('script') stacks are not flushed before the host
        // layout consumes them.
        $this->views->incrementRender();

        try {
            $content = $this->views->make($contentView, $data)->render();
        } catch (Throwable $exception) {
            $this->views->decrementRender();
            $this->views->flushState();
            throw $exception;
        }

        $this->views->decrementRender();

        if ($title !== null && $title !== '') {
            $this->views->startSection('title', $title);
        }

        $this->views->startSection('content', $content);

        // The host layout is the root View returned to Laravel. This guarantees
        // navbar/header/titlebar/theme assets render even if a namespaced child
        // view's @extends directive is ignored by a host/compiler combination.
        return $this->views->make('panel.layout.app');
    }
}
