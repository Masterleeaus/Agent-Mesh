<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Tenancy;

/**
 * Backward-compatible class name for the CRM Core company-owned table registry.
 * Every listed table uses company_id as its canonical tenant boundary.
 * Extracted domain tables are intentionally excluded.
 */
final class CrmTenantTableMap
{
    public const TABLES = [
        'crm_companies','crm_contacts','crm_leads','crm_pipelines','crm_pipeline_stages','crm_deals','crm_activities',
        'crm_projects','crm_tasks','crm_events','crm_products','crm_documents','crm_proposals','crm_estimates','crm_invoices',
        'crm_notes','crm_tags','crm_taggables','crm_custom_fields','crm_custom_field_values','crm_sales_document_lines',
        'crm_settings','crm_audit_log','crm_notification_outbox','crm_merge_log','crm_automation_rules','crm_automation_runs',
        'crm_portal_grants','crm_portal_events','crm_portal_comments','crm_import_batches','crm_import_rows','crm_portal_files',
        'crm_api_keys','crm_webhooks','crm_webhook_deliveries','crm_email_connections','crm_email_messages','crm_record_shares',
        'crm_retention_policies','crm_privacy_requests','crm_chatbot_identities','crm_chatbot_settings','crm_chatbot_session_grants',
        'crm_chatbot_activity_links','crm_mobile_identity_links','crm_capability_operations','crm_business_hours','crm_business_locations',
        'crm_business_configuration_drafts','crm_domain_signal_outbox','crm_capability_rate_limits','crm_import_impact_reports',
        'crm_read_projection_state','crm_read_projection_records','crm_customer_identities','crm_external_identities',
        'crm_duplicate_reviews','crm_merge_snapshots','crm_sales_document_render_jobs','crm_invoice_settlement_references',
        'crm_credit_notes','crm_credit_note_lines','crm_receivable_reconciliation_issues','crm_read_projection_dead_letters',
        'crm_read_projection_rebuild_checkpoints','crm_portal_sessions','crm_import_rollback_journal','crm_export_audit_journal',
        'crm_read_projection_search_terms',
    ];
}
