<?php

declare(strict_types=1);

use App\Extensions\Crm\System\Navigation\CrmMenuInstaller;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('menus')) {
            return;
        }

        CrmMenuInstaller::sync();
    }

    public function down(): void
    {
        if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key')) {
            return;
        }

        $addedKeys = [
            'crm_receivables','crm_collections','crm_timesheets','crm_inventory','crm_stock_locations',
            'crm_stock_control','crm_stock_reservations','crm_reorder','crm_suppliers','crm_tools',
            'crm_equipment','crm_fleet','crm_maintenance','crm_chatbot_integration',
        ];

        if (Schema::hasColumn('menus', 'is_active')) {
            $updates = ['is_active' => 0];
            if (Schema::hasColumn('menus', 'updated_at')) {
                $updates['updated_at'] = now();
            }
            DB::table('menus')->whereIn('key', $addedKeys)->update($updates);
        }
    }
};
