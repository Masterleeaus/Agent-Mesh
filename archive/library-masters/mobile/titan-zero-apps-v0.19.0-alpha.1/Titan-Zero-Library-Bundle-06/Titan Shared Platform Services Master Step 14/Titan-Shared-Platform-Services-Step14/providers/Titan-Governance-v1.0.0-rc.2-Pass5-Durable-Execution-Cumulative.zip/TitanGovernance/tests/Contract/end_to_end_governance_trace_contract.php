<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function e2efail(string $m): never { fwrite(STDERR,"FAIL: {$m}\n"); exit(1); }
function e2eok(bool $c,string $m): void { if(!$c)e2efail($m); }
$request=(string)file_get_contents($root.'/System/Actions/GovernanceActionRequest.php');
$receipt=(string)file_get_contents($root.'/System/Actions/GovernanceCommandReceiptValidator.php');
$decision=(string)file_get_contents($root.'/System/DecisionIntelligence/GovernanceDecisionIntelligence.php');
$rewind=(string)file_get_contents($root.'/System/DecisionIntelligence/GovernanceRewindTheater.php');
foreach(['trace_id','correlation_id','causation_id','root_causation_id'] as $id){
 e2eok(str_contains($request,$id),'governed action request preserves '.$id);
}
e2eok(str_contains($receipt,'authoritative_domain_receipt_ref'),'command receipt validator requires authoritative domain receipt reference');
e2eok(str_contains($receipt,'write_verified'),'command receipt validator requires write verification');
e2eok(str_contains($decision,'command_receipt_ref'),'decision intelligence exposes Command Bus receipt');
e2eok(str_contains($decision,'authoritative_receipt_ref'),'decision intelligence exposes authoritative domain receipt');
e2eok(str_contains($rewind,'trace_id'),'Rewind theater preserves trace identity');
e2eok(str_contains($rewind,'correlation_id'),'Rewind theater preserves correlation identity');
e2eok(str_contains($rewind,'rewind'),'Rewind theater remains explicit bridge');
echo "PASS: governance decision-to-receipt-to-evidence trace contract\n";
