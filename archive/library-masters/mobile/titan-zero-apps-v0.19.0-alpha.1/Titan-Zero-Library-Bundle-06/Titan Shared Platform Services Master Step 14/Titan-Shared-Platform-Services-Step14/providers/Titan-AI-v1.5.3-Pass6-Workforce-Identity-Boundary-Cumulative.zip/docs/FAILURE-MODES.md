# Failure modes

Provider failure, missing tenant context, unavailable governance, stale approval and idempotency collision fail closed or return explicit degraded status.
