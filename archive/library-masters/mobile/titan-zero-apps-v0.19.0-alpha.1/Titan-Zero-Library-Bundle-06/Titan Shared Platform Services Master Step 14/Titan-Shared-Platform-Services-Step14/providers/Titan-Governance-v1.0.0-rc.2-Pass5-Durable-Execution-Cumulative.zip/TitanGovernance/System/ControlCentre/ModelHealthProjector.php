<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ControlCentre;

use DateTimeImmutable;
use Throwable;

final class ModelHealthProjector
{
    /** @param array<string,array<string,mixed>> $sourceSnapshots @return array<string,mixed> */
    public function project(array $sourceSnapshots,array $context=[]):array
    {
        $models=[];$council=null;$overall='HEALTHY';
        foreach($sourceSnapshots as $sourceKey=>$source){
            if(!is_array($source))continue;
            $cc=is_array($source['control_centre']??null)?$source['control_centre']:[];
            $rawModels=is_array($cc['models']??null)?$cc['models']:[];
            foreach(array_slice($rawModels,0,200) as $raw){
                if(!is_array($raw))continue;
                $modelId=trim((string)($raw['model_id']??$raw['id']??''));if($modelId==='')continue;
                $observedAt=$raw['observed_at']??$source['observed_at']??null;
                $health=$this->health($raw,$observedAt,$context);
                if(in_array($health,['DEGRADED','FAILED','STALE'],true))$overall='DEGRADED';
                $models[]=[
                    'source'=>(string)$sourceKey,'model_id'=>$modelId,'provider'=>$this->scalar($raw['provider']??null),'version'=>$this->scalar($raw['version']??null),
                    'previous_version'=>$this->scalar($raw['previous_version']??null),'status'=>strtoupper(trim((string)($raw['status']??'UNKNOWN'))),
                    'transition_status'=>strtoupper(trim((string)($raw['transition_status']??'UNKNOWN'))),'health'=>$health,
                    'drift_score'=>$this->number($raw['drift_score']??null),'observed_at'=>$observedAt,'reference'=>$this->scalar($raw['reference']??null),
                ];
            }
            if($council===null && is_array($cc['council']??null)){
                $c=$cc['council'];$score=$this->number($c['disagreement_score']??null);$material=(bool)($c['material_disagreement']??false);
                $level=$score===null?'UNKNOWN':($score>=0.9?'CRITICAL':($score>=0.5?'HIGH':($score>=0.25?'MEDIUM':'LOW')));
                $council=[
                    'source'=>(string)$sourceKey,'status'=>strtoupper(trim((string)($c['status']??'UNKNOWN'))),'disagreement_score'=>$score,
                    'disagreement_level'=>$level,'material_disagreement'=>$material,'participant_count'=>max(0,(int)($c['participant_count']??0)),
                    'observed_at'=>$c['observed_at']??$source['observed_at']??null,'reference'=>$this->scalar($c['reference']??null),'changes_authority'=>false,
                ];
                if($material||in_array($level,['HIGH','CRITICAL'],true))$overall='DEGRADED';
            }
        }
        usort($models,static fn(array $a,array $b):int=>strcmp((string)$a['model_id'],(string)$b['model_id']));
        return ['status'=>$models===[]&&$council===null?'UNAVAILABLE':$overall,'models'=>$models,'council'=>$council??['status'=>'UNAVAILABLE','disagreement_score'=>null,'disagreement_level'=>'UNKNOWN','material_disagreement'=>false,'participant_count'=>0,'observed_at'=>null,'reference'=>null,'changes_authority'=>false]];
    }

    /** @param array<string,mixed> $row */
    private function health(array $row,mixed $observedAt,array $context):string
    {
        if($this->stale($observedAt,$context))return 'STALE';
        $transition=strtoupper(trim((string)($row['transition_status']??'')));
        $status=strtoupper(trim((string)($row['status']??'')));
        if(in_array($transition,['FAILED','ROLLED_BACK','ABORTED'],true)||in_array($status,['FAILED','ERROR','UNAVAILABLE'],true))return 'FAILED';
        if(in_array($transition,['ROLLING_OUT','TRANSITIONING','CANARY','WARMING','PENDING'],true))return 'TRANSITIONING';
        if(in_array($status,['DEGRADED','UNHEALTHY'],true))return 'DEGRADED';
        if(in_array($status,['HEALTHY','READY','ACTIVE'],true))return 'HEALTHY';
        return 'UNKNOWN';
    }

    private function stale(mixed $observedAt,array $context):bool
    {
        if(!is_string($observedAt)||trim($observedAt)==='')return false;
        try{$at=new DateTimeImmutable($observedAt);}catch(Throwable){return true;}
        $now=$this->now($context);$threshold=max(1,(int)($context['fresh_after_seconds']??300));
        return ($now->getTimestamp()-$at->getTimestamp())>$threshold;
    }
    private function now(array $context):DateTimeImmutable{if(is_string($context['now']??null)){try{return new DateTimeImmutable($context['now']);}catch(Throwable){}}return new DateTimeImmutable('now');}
    private function number(mixed $v):?float{return is_numeric($v)?(float)$v:null;}
    private function scalar(mixed $v):?string{return is_scalar($v)&&trim((string)$v)!==''?(string)$v:null;}
}
