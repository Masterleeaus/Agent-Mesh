# Automatic Trace Evaluation

Titan Signal Engine v0.16.0 automatically assigns active trace profiles to matching Signal events and keeps those traces evaluated without requiring an operator to open the trace explorer first.

## Boundary

Signal remains observational. Trace profiles describe expected event families/order; they do not execute or mutate the originating workflow. Automatic evaluation is a recoverable projection and never participates in the immutable event transaction.

## Assignment

Each active `TraceProfile` has `match_event_types`. When omitted, Signal derives the match set from required event types, ordering-rule endpoints, and terminal event types.

A relevant accepted event creates or updates one `titan_signal_trace_assignments` row for:

- trace ID
- tenant/system scope
- profile key/version

The assignment stores terminal-seen state, evaluation freshness, the latest analysis fingerprint, retry timing, and bounded failure metadata.

## Evaluation lifecycle

1. Immutable Signal event commits.
2. Pulse projection remains best-effort.
3. Signal observes the event for matching active trace profiles.
4. Matching assignments are created/reopened.
5. The trace is evaluated using the hot/cold Correlation boundary.
6. Fresh complete-history evaluations are projected to `titan_signal_trace_evaluations`.
7. Incomplete/partial traces receive a bounded future reevaluation time.
8. `titan:signal-traces:evaluate` catches up due assignments every minute.
9. The anomaly scanner runs after trace evaluation.

A terminal, complete, integrity-complete trace closes its assignment. Any later relevant event reopens it and forces reevaluation, supporting offline/late-arriving Signal events.

## Freshness and partial history

Automatic evaluation records `fresh_until`, `history_complete`, and `cold_history_complete`. Sequence/missing-required anomaly rules consume only fresh evaluations. A partial cold-history window cannot be promoted to a complete automatic evaluation.

## Missing required events

Missing required events become an anomaly only after a profile terminal event has been observed. This avoids alerting on ordinary in-progress workflows.

Canonical anomaly type:

- `required_event_missing`

## Repair semantics

Late/offline events can repair an incomplete trace. After reevaluation:

- sequence violations that disappear are automatically resolved;
- missing-required anomalies are automatically resolved once a fresh terminal evaluation contains all required event types;
- resolution reason is `trace_evaluation_recovered`.

The mutable anomaly row remains a read model. Immutable anomaly decision telemetry is handled in Production Hardening Pass 10.

## Scheduler

`php artisan titan:signal-traces:evaluate --limit=250`

The provider schedules this every minute with `onOneServer()` and `withoutOverlapping()` before the anomaly scanner.

## Configuration

See `trace_evaluation_*` and `trace_profile_match_limit` in `config/titan-signal-engine.php`.
