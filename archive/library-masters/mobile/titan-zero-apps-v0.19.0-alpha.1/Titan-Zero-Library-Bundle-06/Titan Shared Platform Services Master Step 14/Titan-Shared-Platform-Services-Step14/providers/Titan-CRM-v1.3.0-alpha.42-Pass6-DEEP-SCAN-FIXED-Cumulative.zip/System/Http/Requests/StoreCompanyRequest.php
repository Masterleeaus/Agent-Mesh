<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
final class StoreCompanyRequest extends FormRequest {
 public function authorize(): bool { return true; }
 public function rules(): array { return ['name'=>['required','string','max:255'],'legal_name'=>['nullable','string','max:255'],'website'=>['nullable','url','max:2048'],'email'=>['nullable','email','max:255','required_without:phone'],'phone'=>['nullable','string','max:60','required_without:email'],'address'=>['nullable','string','max:1000'],'notes'=>['nullable','string','max:5000'],'status'=>['sometimes','in:active,inactive,prospect'],'owner_user_id'=>['nullable','integer','min:1']]; }
}
