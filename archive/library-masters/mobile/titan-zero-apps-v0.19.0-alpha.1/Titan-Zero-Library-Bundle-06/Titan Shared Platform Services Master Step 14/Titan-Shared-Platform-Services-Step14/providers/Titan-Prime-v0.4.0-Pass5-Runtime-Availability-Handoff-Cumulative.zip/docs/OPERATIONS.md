# Operations

Prime v0.4.0 remains synchronous and orchestration-disabled. Queues and automatic downstream execution are not active.

`PrimeManager::health()` now exposes:

- normal scoped liveness/readiness;
- `orchestration_enabled=false`;
- `engine_gateway_ready` — true only when all engine gateways required for future governed delegation report available;
- `execution_ready=false` — Pass 3 still has no Command Bus delegation/execution path;
- `engine_gateways` — per-engine availability snapshots.

An unavailable gateway does not make the Prime domain/persistence control plane unhealthy; it means Prime is not ready for an execution pass.

`php artisan titan:titan-prime:certify --json` verifies the bridge, gateway catalog, all typed gateway bindings, durable repository binding, owned tables/columns and routes. Host certification verifies wiring, not that optional target engines are operational.
