<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalEventLifecycle extends Model
{
    protected $table = 'titan_signal_event_lifecycle';
    protected $guarded = [];
    protected $casts = [
        'tenant_company_id' => 'integer',
        'tenant_key' => 'integer',
        'retain_until' => 'immutable_datetime',
        'legal_hold' => 'boolean',
        'legal_hold_at' => 'immutable_datetime',
        'archived_at' => 'immutable_datetime',
        'pruned_at' => 'immutable_datetime',
        'prune_claimed_at' => 'immutable_datetime',
        'prune_claim_expires_at' => 'immutable_datetime',
    ];
}
