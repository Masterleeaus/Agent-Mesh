<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyControlStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\ControlPlaneAuditSinkContract;

final class PlatformPolicyService
{
    private const LEVELS = ['suggest'=>0,'assist'=>1,'semi_auto'=>2,'auto'=>3,'trusted_auto'=>4];

    public function __construct(
        private readonly AutonomyControlStoreContract $store,
        private readonly string $policyVersion,
        private readonly ?ControlPlaneAuditSinkContract $audit = null,
    ) {}

    public function save(array $requested, ?int $actorUserId = null, ?string $correlationId = null): array
    {
        $mins = (array) ($requested['gate_minimums'] ?? []);
        $gateMinimums = [
            'low' => max(1, (int) ($mins['low'] ?? 1)),
            'medium' => max(2, (int) ($mins['medium'] ?? 2)),
            'high' => max(3, (int) ($mins['high'] ?? 3)),
            'critical' => max(3, (int) ($mins['critical'] ?? 3)),
        ];

        $requestedCeilings = (array) ($requested['maximum_level_by_risk'] ?? []);
        $ceilings = [
            'low' => $this->validLevel($requestedCeilings['low'] ?? 'trusted_auto', 'trusted_auto'),
            'medium' => $this->validLevel($requestedCeilings['medium'] ?? 'trusted_auto', 'trusted_auto'),
            'high' => $this->validLevel($requestedCeilings['high'] ?? 'auto', 'auto'),
            'critical' => $this->validLevel($requestedCeilings['critical'] ?? 'semi_auto', 'semi_auto'),
        ];
        if (!(bool) ($requested['high_trusted_auto_exception'] ?? false) && self::LEVELS[$ceilings['high']] > self::LEVELS['auto']) $ceilings['high'] = 'auto';
        if (!(bool) ($requested['critical_autonomy_exception'] ?? false) && self::LEVELS[$ceilings['critical']] > self::LEVELS['semi_auto']) $ceilings['critical'] = 'semi_auto';

        $policy = [
            'gate_minimums' => $gateMinimums,
            'maximum_level_by_risk' => $ceilings,
            'limits' => [
                'high_trusted_auto_exception' => (bool) ($requested['high_trusted_auto_exception'] ?? false),
                'critical_autonomy_exception' => (bool) ($requested['critical_autonomy_exception'] ?? false),
            ],
            'system_wide_learning_permitted' => (bool) ($requested['system_wide_learning_permitted'] ?? false),
        ];

        $this->store->savePlatformPolicy($policy, $this->policyVersion);
        $this->audit?->record([
            'tenant_company_id' => null,
            'user_id' => $actorUserId,
            'event_type' => 'autonomy.platform_policy_changed',
            'payload' => ['policy' => $policy],
            'policy_version' => $this->policyVersion,
            'correlation_id' => $correlationId,
        ]);
        return $policy;
    }

    private function validLevel(mixed $level, string $fallback): string
    {
        $level = (string) $level;
        return isset(self::LEVELS[$level]) ? $level : $fallback;
    }
}
