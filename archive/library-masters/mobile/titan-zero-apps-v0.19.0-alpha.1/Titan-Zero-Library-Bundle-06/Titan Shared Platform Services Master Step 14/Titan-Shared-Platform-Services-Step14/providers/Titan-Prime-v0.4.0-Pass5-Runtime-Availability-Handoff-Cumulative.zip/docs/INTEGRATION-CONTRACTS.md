# Integration Contracts

## Durable mission store

`PrimeMissionRepositoryContract` remains the authoritative Prime persistence seam:

- `create(PrimeMission $mission, string $operationId): PrimeMissionWriteReceipt`
- `find(int $tenantCompanyId, string $missionId): ?PrimeMissionSnapshot`
- `transition(..., int $expectedVersion, string $operationId): PrimeMissionWriteReceipt`

## External engine bridge

`EngineBridgeContract` is the only Prime-owned bridge port to other Titan engines:

- `dispatch(EngineGatewayRequest $request): EngineGatewayResult`
- `availability(EngineKey $engine): EngineAvailability`

Prime ships `FailClosedEngineBridge` as the default. The service provider binds it only when no bridge is already registered, allowing a trusted integration provider to install a public-contract adapter without modifying Prime.

### Typed gateways

- `AiCoreGatewayContract::plan(...)` → `core.plan`
- `SignalGatewayContract::publish(...)` → `signal.publish`
- `RiskGatewayContract::assess(...)` → `risk.assess`
- `AssuranceGatewayContract::verify(...)` → `assurance.verify`
- `AutonomyGatewayContract::authorize(...)` → `autonomy.authorize`
- `GovernanceGatewayContract::evaluate(...)` → `governance.evaluate`
- `RewindGatewayContract::record(...)` → `rewind.record`
- `WisdomGatewayContract::recordOutcome(...)` → `wisdom.record-outcome`

The logical capability names above are Prime-side contracts. A concrete integration adapter is responsible for mapping them onto the target engine's versioned public interface.

Every call carries complete causal lineage and a caller-owned operation ID. A bridge must return a result for the exact same engine, capability and operation ID or Prime converts it to `failed/bridge_contract_mismatch`.
