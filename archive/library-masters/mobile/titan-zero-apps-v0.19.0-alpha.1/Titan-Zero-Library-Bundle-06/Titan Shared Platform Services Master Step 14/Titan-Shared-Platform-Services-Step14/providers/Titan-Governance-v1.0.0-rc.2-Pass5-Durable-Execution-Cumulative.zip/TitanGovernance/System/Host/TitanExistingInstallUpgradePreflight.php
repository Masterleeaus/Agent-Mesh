<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Host;

final class TitanExistingInstallUpgradePreflight
{
    public function inspect(string $root, array $installedMigrationBasenames = []): array
    {
        $files=glob(rtrim($root,'/').'/database/migrations/*.php')?:[];
        sort($files,SORT_STRING);
        $basenames=array_map('basename',$files);
        $duplicates=array_values(array_keys(array_filter(array_count_values($basenames),static fn(int $n):bool=>$n>1)));
        $installed=array_values(array_intersect($basenames,array_map('basename',$installedMigrationBasenames)));
        $forwardDestructive=[];$missingDown=[];
        foreach ($files as $file) {
            $src=(string)file_get_contents($file);
            if (!str_contains($src,'function down')) $missingDown[]=basename($file);
            $up=preg_split('/public\s+function\s+down\s*\(/',$src,2)[0]??$src;
            if (preg_match('/Schema::drop(?:IfExists)?\s*\(|->dropColumn\s*\(|\bDROP\s+(?:TABLE|COLUMN|DATABASE)\b/i',$up)) $forwardDestructive[]=basename($file);
        }
        return [
            'status'=>($duplicates===[]&&$forwardDestructive===[]&&$missingDown===[])?'PASS':'FAIL',
            'migration_count'=>count($files),
            'migration_basenames'=>$basenames,
            'duplicate_basenames'=>$duplicates,
            'installed_name_collisions'=>$installed,
            'forward_destructive_migrations'=>$forwardDestructive,
            'missing_down'=>$missingDown,
            'new_migrations_added_by_pass8'=>count($files)!==4,
            'preserve_data'=>true,
            'note'=>'Installed-name collisions are host facts for upgrade planning; Pass 8 adds no migration and does not alter historical migration basenames.',
        ];
    }
}
