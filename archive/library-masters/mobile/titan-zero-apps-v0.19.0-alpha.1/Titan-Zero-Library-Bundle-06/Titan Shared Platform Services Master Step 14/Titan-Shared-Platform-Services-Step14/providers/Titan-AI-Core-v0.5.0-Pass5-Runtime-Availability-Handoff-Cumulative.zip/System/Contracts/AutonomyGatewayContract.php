<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Contracts;

use App\Extensions\TitanAICore\System\DTO\GovernanceDecision;
use App\Extensions\TitanAICore\System\DTO\GovernancePreflightRequest;

interface AutonomyGatewayContract
{
    public function evaluate(GovernancePreflightRequest $request): GovernanceDecision;
}
