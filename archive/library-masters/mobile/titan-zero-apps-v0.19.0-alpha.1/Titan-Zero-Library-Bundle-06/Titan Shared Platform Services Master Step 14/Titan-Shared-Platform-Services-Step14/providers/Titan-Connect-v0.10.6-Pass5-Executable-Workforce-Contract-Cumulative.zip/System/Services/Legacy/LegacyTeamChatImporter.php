<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services\Legacy;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

final class LegacyTeamChatImporter
{
    private const SOURCE = 'chatbot-team-chat';

    public function import(): array
    {
        $required = [
            'ext_chatbot_team_conversations',
            'ext_chatbot_team_conversation_participants',
            'ext_chatbot_team_messages',
            'ext_chatbot_team_message_reads',
        ];

        foreach ($required as $table) {
            if (! Schema::hasTable($table)) {
                return ['status' => 'skipped', 'reason' => "Missing legacy table {$table}"];
            }
        }

        return DB::transaction(function (): array {
            $counts = [
                'conversations' => $this->importConversations(),
                'participants' => $this->importParticipants(),
                'messages' => $this->importMessages(),
                'reads' => $this->importReads(),
            ];

            return ['status' => 'ok'] + $counts;
        });
    }

    private function importConversations(): int
    {
        $count = 0;
        app('db')->table('ext_chatbot_team_conversations')->orderBy('id')->chunkById(200, function ($rows) use (&$count): void {
            foreach ($rows as $row) {
                $data = (array) $row;
                $legacyId = (int) $data['id'];
                $existing = app('db')->table('ext_titan_connect_conversations')
                    ->where('legacy_source', self::SOURCE)->where('legacy_id', $legacyId)->first();
                if ($existing) {
                    continue;
                }

                $insert = [
                    'uuid' => $data['uuid'] ?? (string) Str::uuid(),
                    'company_id' => $this->legacyCompanyId($data),
                    'name' => $data['name'] ?? null,
                    'slug' => $data['slug'] ?? null,
                    'type' => $data['type'] ?? 'direct',
                    'avatar' => $data['avatar'] ?? null,
                    'description' => $data['description'] ?? null,
                    'category' => $data['category'] ?? null,
                    'owner_id' => $data['owner_id'] ?? null,
                    'visibility' => (($data['visibility'] ?? 'private') === 'tenant' ? 'company' : ($data['visibility'] ?? 'private')),
                    'posting_policy' => $data['posting_policy'] ?? 'members',
                    'is_announcement' => (bool) ($data['is_announcement'] ?? false),
                    'linked_entity_type' => $data['linked_entity_type'] ?? null,
                    'linked_entity_id' => isset($data['linked_entity_id']) ? (string) $data['linked_entity_id'] : null,
                    'channel_archived_at' => $data['channel_archived_at'] ?? null,
                    'is_archived' => (bool) ($data['is_archived'] ?? false),
                    'version' => (int) ($data['version'] ?? 1),
                    'sync_sequence' => (int) ($data['sync_sequence'] ?? 0),
                    'originating_device_id' => $data['originating_device_id'] ?? null,
                    'created_by' => $data['created_by'] ?? null,
                    'updated_by' => $data['updated_by'] ?? null,
                    'legacy_source' => self::SOURCE,
                    'legacy_id' => $legacyId,
                    'created_at' => $data['created_at'] ?? now(),
                    'updated_at' => $data['updated_at'] ?? now(),
                    'deleted_at' => $data['deleted_at'] ?? null,
                ];
                $this->insertPreservingIdWhenAvailable('ext_titan_connect_conversations', $legacyId, $insert);
                $count++;
            }
        });
        return $count;
    }

    private function importParticipants(): int
    {
        $count = 0;
        app('db')->table('ext_chatbot_team_conversation_participants')->orderBy('id')->chunkById(500, function ($rows) use (&$count): void {
            foreach ($rows as $row) {
                $data = (array) $row;
                $legacyId = (int) $data['id'];
                if (app('db')->table('ext_titan_connect_participants')->where('legacy_source', self::SOURCE)->where('legacy_id', $legacyId)->exists()) {
                    continue;
                }
                $conversationId = $this->canonicalId('ext_titan_connect_conversations', (int) $data['conversation_id']);
                if ($conversationId === null) {
                    continue;
                }
                $insert = [
                    'conversation_id' => $conversationId,
                    'company_id' => $this->legacyCompanyId($data),
                    'user_id' => (int) $data['user_id'],
                    'role' => $data['role'] ?? 'member',
                    'last_read_at' => $data['last_read_at'] ?? null,
                    'joined_at' => $data['joined_at'] ?? null,
                    'left_at' => $data['left_at'] ?? null,
                    'is_muted' => (bool) ($data['is_muted'] ?? false),
                    'is_pinned' => (bool) ($data['is_pinned'] ?? false),
                    'archived_at' => $data['archived_at'] ?? null,
                    'legacy_source' => self::SOURCE,
                    'legacy_id' => $legacyId,
                    'created_at' => $data['created_at'] ?? now(),
                    'updated_at' => $data['updated_at'] ?? now(),
                    'deleted_at' => $data['deleted_at'] ?? null,
                ];
                $this->insertPreservingIdWhenAvailable('ext_titan_connect_participants', $legacyId, $insert);
                $count++;
            }
        });
        return $count;
    }

    private function importMessages(): int
    {
        $count = 0;
        app('db')->table('ext_chatbot_team_messages')->orderBy('id')->chunkById(500, function ($rows) use (&$count): void {
            foreach ($rows as $row) {
                $data = (array) $row;
                $legacyId = (int) $data['id'];
                if (app('db')->table('ext_titan_connect_messages')->where('legacy_source', self::SOURCE)->where('legacy_id', $legacyId)->exists()) {
                    continue;
                }
                $conversationId = $this->canonicalId('ext_titan_connect_conversations', (int) $data['conversation_id']);
                if ($conversationId === null) {
                    continue;
                }
                $replyToId = isset($data['reply_to_id']) ? $this->canonicalId('ext_titan_connect_messages', (int) $data['reply_to_id']) : null;
                $metadata = $data['metadata'] ?? null;
                if ($metadata === null && ! empty($data['attachment_path'])) {
                    $metadata = json_encode(['legacy_attachment' => [
                        'path' => $data['attachment_path'] ?? null,
                        'name' => $data['attachment_name'] ?? null,
                        'type' => $data['attachment_type'] ?? null,
                        'size' => $data['attachment_size'] ?? null,
                    ]], JSON_THROW_ON_ERROR);
                }
                $insert = [
                    'uuid' => $data['uuid'] ?? (string) Str::uuid(),
                    'company_id' => $this->legacyCompanyId($data),
                    'conversation_id' => $conversationId,
                    'user_id' => $data['user_id'] ?? null,
                    'body' => $data['body'] ?? null,
                    'message_type' => $data['message_type'] ?? 'text',
                    'reply_to_id' => $replyToId,
                    'metadata' => $metadata,
                    'version' => (int) ($data['version'] ?? 1),
                    'sync_sequence' => (int) ($data['sync_sequence'] ?? 0),
                    'originating_device_id' => $data['originating_device_id'] ?? null,
                    'edited_at' => $data['edited_at'] ?? null,
                    'created_by' => $data['created_by'] ?? null,
                    'updated_by' => $data['updated_by'] ?? null,
                    'legacy_source' => self::SOURCE,
                    'legacy_id' => $legacyId,
                    'created_at' => $data['created_at'] ?? now(),
                    'updated_at' => $data['updated_at'] ?? now(),
                    'deleted_at' => $data['deleted_at'] ?? null,
                ];
                $this->insertPreservingIdWhenAvailable('ext_titan_connect_messages', $legacyId, $insert);
                $count++;
            }
        });
        return $count;
    }

    private function importReads(): int
    {
        $count = 0;
        app('db')->table('ext_chatbot_team_message_reads')->orderBy('id')->chunkById(500, function ($rows) use (&$count): void {
            foreach ($rows as $row) {
                $data = (array) $row;
                $legacyId = (int) $data['id'];
                if (app('db')->table('ext_titan_connect_message_reads')->where('legacy_source', self::SOURCE)->where('legacy_id', $legacyId)->exists()) {
                    continue;
                }
                $messageId = $this->canonicalId('ext_titan_connect_messages', (int) $data['message_id']);
                if ($messageId === null) {
                    continue;
                }
                $insert = [
                    'message_id' => $messageId,
                    'company_id' => $this->legacyCompanyId($data),
                    'user_id' => (int) $data['user_id'],
                    'read_at' => $data['read_at'] ?? now(),
                    'legacy_source' => self::SOURCE,
                    'legacy_id' => $legacyId,
                    'created_at' => $data['created_at'] ?? now(),
                    'updated_at' => $data['updated_at'] ?? now(),
                ];
                $this->insertPreservingIdWhenAvailable('ext_titan_connect_message_reads', $legacyId, $insert);
                $count++;
            }
        });
        return $count;
    }

    private function legacyCompanyId(array $data): int
    {
        $companyId = $data['company_id'] ?? $data['tenant_id'] ?? null;
        if (! is_numeric($companyId) || (int) $companyId <= 0) {
            throw new \RuntimeException('Legacy Team Chat row is missing a valid company boundary.');
        }

        return (int) $companyId;
    }

    private function canonicalId(string $table, int $legacyId): ?int
    {
        $id = app('db')->table($table)->where('legacy_source', self::SOURCE)->where('legacy_id', $legacyId)->value('id');
        return $id === null ? null : (int) $id;
    }

    private function insertPreservingIdWhenAvailable(string $table, int $legacyId, array $data): void
    {
        if (! app('db')->table($table)->where('id', $legacyId)->exists()) {
            $data = ['id' => $legacyId] + $data;
        }
        app('db')->table($table)->insert($data);
    }
}
