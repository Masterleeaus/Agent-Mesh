<?php

declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Http\Controllers;
use App\Extensions\TitanRewind\System\Services\RewindDeadLetterService;
use App\Extensions\TitanRewind\System\Services\RewindRuntimeStateService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
final class RuntimeController
{
    public function setState(Request $request, RewindRuntimeStateService $runtime): RedirectResponse
    {
        $data=$request->validate(['state'=>'required|string|in:ACTIVE,DEGRADED,MAINTENANCE,DRAINING,DISABLED,UNAVAILABLE,UNINSTALLING','reason'=>'nullable|string|max:2000']);
        $runtime->set((string)$data['state'],$data['reason']??null,auth()->id());
        return back()->with('success','Titan Rewind runtime state updated.');
    }
    public function retryDeadLetter(string $deadLetterUuid, RewindDeadLetterService $deadLetters): RedirectResponse
    {
        $deadLetters->retry($deadLetterUuid);
        return back()->with('success','Titan Rewind dead-letter item requeued.');
    }
}
