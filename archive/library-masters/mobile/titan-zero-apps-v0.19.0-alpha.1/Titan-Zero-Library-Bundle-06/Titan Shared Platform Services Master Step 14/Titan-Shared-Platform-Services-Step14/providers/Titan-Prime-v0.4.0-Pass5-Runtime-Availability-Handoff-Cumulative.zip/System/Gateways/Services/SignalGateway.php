<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Services;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Contracts\SignalGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;
use InvalidArgumentException;

final class SignalGateway extends AbstractEngineGateway implements SignalGatewayContract
{
    public function engine(): EngineKey { return EngineKey::Signal; }

    public function publish(TraceContext $trace, string $signalName, array $payload, string $operationId): EngineGatewayResult
    {
        if (!preg_match('/^[a-z0-9][a-z0-9._:-]*$/', $signalName)) {
            throw new InvalidArgumentException('signalName must use a stable lowercase contract identifier.');
        }
        return $this->dispatch($trace, 'signal.publish', ['signal_name' => $signalName, 'payload' => $payload], $operationId);
    }
}
