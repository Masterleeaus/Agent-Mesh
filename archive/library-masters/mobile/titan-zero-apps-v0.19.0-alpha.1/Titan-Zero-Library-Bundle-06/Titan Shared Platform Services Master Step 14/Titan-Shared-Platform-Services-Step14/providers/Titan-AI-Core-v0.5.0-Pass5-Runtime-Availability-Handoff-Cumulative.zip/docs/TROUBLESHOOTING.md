# Troubleshooting
Run diagnose, host-sync, then certify. A typed plan remains non-executable while the validator reports `DAG_VALIDATOR_NOT_IMPLEMENTED`; this is intentional fail-closed behavior.
