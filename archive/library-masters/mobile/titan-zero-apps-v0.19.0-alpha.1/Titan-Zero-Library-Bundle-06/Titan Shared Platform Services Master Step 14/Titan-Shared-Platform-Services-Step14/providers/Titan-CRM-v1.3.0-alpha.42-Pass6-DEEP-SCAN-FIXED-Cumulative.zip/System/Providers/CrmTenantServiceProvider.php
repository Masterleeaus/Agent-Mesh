<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Providers;

use App\Extensions\Crm\System\Tenancy\{CrmCompanyAuthorizationGateway,CrmCompanyContextResolver,CrmCompanyContextStore,CrmCompanyScope};
use Illuminate\Support\ServiceProvider;

final class CrmTenantServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(CrmCompanyContextStore::class);
        $this->app->singleton(CrmCompanyContextResolver::class);
        $this->app->singleton(CrmCompanyScope::class);
        $this->app->singleton(CrmCompanyAuthorizationGateway::class);
    }
}
