<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models\TeamChat;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use App\Extensions\TitanConnect\System\Models\MessageAttachment;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class TeamMessage extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use HasUuids;
    use SoftDeletes;

    protected $table = 'ext_titan_connect_messages';

    protected $fillable = [
        'uuid', 'company_id', 'conversation_id', 'user_id', 'body', 'message_type',
        'reply_to_id', 'version', 'sync_sequence', 'originating_device_id',
        'edited_at', 'created_by', 'updated_by', 'metadata', 'legacy_source', 'legacy_id',
    ];

    protected $casts = [
        'metadata' => 'array', 'version' => 'integer',
        'sync_sequence' => 'integer', 'edited_at' => 'datetime',
    ];

    public function uniqueIds(): array
    {
        return ['uuid'];
    }

    public function conversation(): BelongsTo
    {
        return $this->belongsTo(TeamConversation::class, 'conversation_id');
    }

    public function reads(): HasMany
    {
        return $this->hasMany(TeamMessageRead::class, 'message_id');
    }

    public function attachments(): HasMany
    {
        return $this->hasMany(MessageAttachment::class, 'message_id');
    }
}
