# Titan CRM Core v1.3.0-alpha.27 — Commercial Domain Boundary

## Changed

- Completed a full post-extraction ownership audit across services, providers, controllers, mobile integrations, CQRS, analytics, automation, Interaction registries, Chatbot, configuration, migrations and tests.
- Removed per-class Field/Locker/Ledger/Pay compatibility alias directories and obsolete external-domain providers/controllers.
- Removed CRM-owned Titan Go Field offline/delta runtime and Field-owned read projections.
- Removed Field-owned analytics and owner/customer mobile augmentation from CRM Core.
- Removed external-domain automation triggers/actions and active Interaction/Global New/quick-prompt/record-action/chain registrations.
- Removed 51 dormant Interaction JSON wizards for extracted domains.
- Replaced the broad Finance Assistant runtime with six CRM-owned deterministic commercial calculation engines.
- Stopped fresh CRM Core installations from creating Titan Pay payment/allocation schema and Field mobile/sync schema.
- Removed obsolete monolith diagnostics and regression scripts for domains CRM no longer owns.
- Rewrote retained historical regression gates to assert the post-split Core contract.

## Compatibility retained

- `CrmExternalDomainCapabilityBridge`
- `CrmCapabilityOwnershipMap`
- guarded compatibility resource/tenant/invariant mappings
- legacy external `crm.*` capability names marked with their true `owning_extension`
- upgrade-only recognition of pre-existing extracted-domain tables

These are compatibility contracts only and are not authoritative CRM writers.

## Capability ownership snapshot

- CRM Core: 106 governed capabilities
- Titan Field compatibility: 54
- Titan Locker compatibility: 49
- Titan Pay compatibility: 11
- Titan Ledger compatibility: 6

Total compatibility-visible governed names: 226.
