<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Extensions\TitanConnect\System\Services\ConversationExportService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class ConversationExportController extends Controller
{
    public function __construct(private readonly CompanyContext $context, private readonly ChannelAccessPolicy $policy, private readonly ConversationExportService $exports, private readonly WorkCoreAuthorizationGateway $workCore) {}

    public function show(Request $request, ExternalThread $thread, string $format): Response
    {
        $companyId = $this->context->companyId($request); $actorId = $this->context->actorId($request);
        abort_unless((int) $thread->company_id === $companyId, 404); abort_unless($this->policy->canView($thread->connection, $actorId), 403);
        if ($thread->linked_entity_type !== null && $thread->linked_entity_id !== null) $this->workCore->assertCanAccess($companyId, $actorId, (string) $thread->linked_entity_type, (string) $thread->linked_entity_id);
        $export = $this->exports->export($companyId, $thread, $format);
        return response($export['content'], 200, ['Content-Type' => $export['mime'], 'Content-Disposition' => 'attachment; filename="titan-connect-'.$thread->uuid.'.'.$export['extension'].'"']);
    }
}
