<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$routes = @file_get_contents($root . '/routes/admin.php') ?: '';
$controller = @file_get_contents($root . '/System/Http/Controllers/AdminController.php') ?: '';
$viewsRoot = $root . '/resources/views/admin-rc8-1';

$pages = [
    'overview' => ['overview', 'Signal Engine Overview'],
    'pulse-health' => ['pulseHealth', 'Pulse and Health'],
    'events-traces' => ['eventsTraces', 'Events and Traces'],
    'anomalies' => ['anomalies', 'Anomalies'],
    'deliveries-dlq' => ['deliveriesDlq', 'Deliveries and DLQ'],
    'lifecycle-archives' => ['lifecycleArchives', 'Lifecycle and Archives'],
    'registries' => ['registries', 'Registries'],
    'diagnostics' => ['diagnostics', 'Diagnostics'],
];

foreach ($pages as $slug => [$method, $title]) {
    $path = $viewsRoot . '/' . $slug . '.blade.php';
    $assert(is_file($path), 'missing rc.8 view: ' . $slug);
    $view = @file_get_contents($path) ?: '';
    $assert(str_starts_with(ltrim($view), "@extends('panel.layout.app')"), $slug . ' must extend panel.layout.app');
    $assert(str_contains($view, $title), $slug . ' missing page title');
    $assert(str_contains($controller, 'function ' . $method . '('), 'controller missing method: ' . $method);
    $assert(! preg_match('/\$errors\s*=/', $view), $slug . ' must not overwrite Laravel shared $errors ViewErrorBag');
}

foreach (['overview','pulse-health','events-traces','anomalies','deliveries-dlq','lifecycle-archives','registries','diagnostics'] as $route) {
    $assert(str_contains($routes, "name('{$route}')"), 'missing child route: ' . $route);
}

$overview = @file_get_contents($viewsRoot . '/overview.blade.php') ?: '';
foreach (['System Status','Runtime','Delivery','Integrity','View details →'] as $needle) $assert(str_contains($overview, $needle), 'overview missing: ' . $needle);
foreach (['events.redact','anomalies.suppress','deliveries.redrive','lifecycle.prune'] as $forbidden) $assert(! str_contains($overview, $forbidden), 'overview must not expose destructive operation: ' . $forbidden);

$filter = @file_get_contents($viewsRoot . '/partials/filter.blade.php') ?: '';
$assert(str_contains($filter, 'data-tse-tenant'), 'compact filter missing conditional tenant field');
$assert(str_contains($filter, "scope.value!=='tenant'"), 'tenant field must hide outside tenant scope');
$assert(! str_contains($filter, 'Rows'), 'compact overview filter should not expose row limit control');

$events = @file_get_contents($viewsRoot . '/events-traces.blade.php') ?: '';
foreach (['events.redact','events.correct','events.legal-hold'] as $needle) $assert(str_contains($events, $needle), 'events page missing governed event operation: ' . $needle);
$anomalies = @file_get_contents($viewsRoot . '/anomalies.blade.php') ?: '';
$assert(str_contains($anomalies, 'anomalies.suppress'), 'anomaly suppression not isolated to anomaly page');
$deliveries = @file_get_contents($viewsRoot . '/deliveries-dlq.blade.php') ?: '';
$assert(str_contains($deliveries, 'deliveries.redrive'), 'DLQ redrive not isolated to delivery page');
$lifecycle = @file_get_contents($viewsRoot . '/lifecycle-archives.blade.php') ?: '';
$assert(str_contains($lifecycle, 'lifecycle.prune'), 'prune action not isolated to lifecycle page');

$registryService = @file_get_contents($root . '/System/Services/SignalRegistryConsoleService.php') ?: '';
foreach (['SignalTypeVersion','SignalSubscriptionRuntime','SignalTraceProfile'] as $needle) $assert(str_contains($registryService, $needle), 'registry console missing authoritative model: ' . $needle);
$assert(str_contains($controller, 'SignalHostCertificationService'), 'diagnostics must use host certification service');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Signal rc.8.1 Super Admin information architecture and Blade shared-state safety contract\n";
