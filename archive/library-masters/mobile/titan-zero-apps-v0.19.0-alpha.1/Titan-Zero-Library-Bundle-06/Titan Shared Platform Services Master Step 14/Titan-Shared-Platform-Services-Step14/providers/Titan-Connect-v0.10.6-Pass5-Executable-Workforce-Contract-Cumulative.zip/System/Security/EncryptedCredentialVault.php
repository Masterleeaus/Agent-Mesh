<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use App\Extensions\TitanConnect\System\Contracts\CredentialVault;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ProviderCredential;
use Illuminate\Support\Facades\Crypt;
use RuntimeException;

final class EncryptedCredentialVault implements CredentialVault
{
    public function __construct(private readonly ConfigCredentialVault $fallback)
    {
    }

    public function credentials(int $companyId, ChannelConnection $connection): array
    {
        if ((int) $connection->company_id !== $companyId) {
            throw new RuntimeException('Channel connection company mismatch.');
        }

        $reference = trim((string) ($connection->credential_reference ?? ''));
        if ($reference !== '') {
            $record = ProviderCredential::query()
                ->where('company_id', $companyId)
                ->where('provider', $connection->provider)
                ->where('reference', $reference)
                ->first();

            if ($record) {
                try {
                    $plaintext = Crypt::decryptString((string) $record->encrypted_payload);
                    $decoded = json_decode($plaintext, true, 512, JSON_THROW_ON_ERROR);
                } catch (\Throwable $e) {
                    throw new RuntimeException('Messaging credential vault entry could not be decrypted.', previous: $e);
                }
                if (! is_array($decoded) || $decoded === []) {
                    throw new RuntimeException('Messaging credential vault entry is empty or invalid.');
                }
                $decoded['_connection_uuid'] = (string) $connection->uuid;
                $decoded['_connection_external_account_id'] = (string) ($connection->external_account_id ?? '');
                $decoded['_connection_settings'] = is_array($connection->settings) ? $connection->settings : [];
                return $decoded;
            }
            if (str_starts_with($reference, 'vault_')) {
                throw new RuntimeException('Messaging credential vault entry could not be found.');
            }
        }

        if ((bool) config('titan-connect.credentials.allow_config_fallback', false)) {
            $decoded = $this->fallback->credentials($companyId, $connection);
            $decoded['_connection_uuid'] = (string) $connection->uuid;
            $decoded['_connection_external_account_id'] = (string) ($connection->external_account_id ?? '');
            $decoded['_connection_settings'] = is_array($connection->settings) ? $connection->settings : [];
            return $decoded;
        }

        throw new RuntimeException('Encrypted messaging credentials are not configured for this channel connection.');
    }
}
