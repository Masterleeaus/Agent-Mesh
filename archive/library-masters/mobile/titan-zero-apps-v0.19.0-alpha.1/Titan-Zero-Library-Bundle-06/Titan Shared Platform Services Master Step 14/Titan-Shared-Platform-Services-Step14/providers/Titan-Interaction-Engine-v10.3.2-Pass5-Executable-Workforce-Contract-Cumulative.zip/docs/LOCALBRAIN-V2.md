# LocalBrain v2

LocalBrain v2 remains an Interaction Engine subsystem for bounded offline/local assistance, especially Titan Go in poor-connectivity conditions.

It supports local field intent recognition, wizard guidance, checklist assistance, context/memory, safe recommendations, temporal reasoning and predictive completion. It does **not** invent authoritative CRM state, mutate remote systems, or elevate capability authority.

When LocalBrain determines that a request requires cloud reasoning or an external capability:

- if connectivity is available, it emits a structured recommendation to escalate to TitanAI;
- if connectivity is unavailable, it emits a deferred cloud-escalation state and continues only with bounded local guidance;
- it never calls TitanAI or a remote provider around the Interaction Engine's authority/capability boundary.

All remote actions still flow through the normal Interaction Engine capability policy, approval and provider routing path.
