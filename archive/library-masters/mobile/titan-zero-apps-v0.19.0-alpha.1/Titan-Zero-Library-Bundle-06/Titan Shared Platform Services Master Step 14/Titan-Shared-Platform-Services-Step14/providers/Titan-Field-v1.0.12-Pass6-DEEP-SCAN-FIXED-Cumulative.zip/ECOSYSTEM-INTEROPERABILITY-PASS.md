# Agent-01 Ecosystem Interoperability Pass

Version: `1.0.9`

This pass makes cross-extension handoffs explicit while preserving domain ownership. Titan AI Workforce coordinates responsibilities and provider selection; Titan Autonomy owns effective authority; each target extension remains the only owner of its domain mutations.

## Peers

- `crm`
- `titan-maps-intelligence`
- `titan-time-attendance`
- `titan-assets`

## Handoffs

- `crm-customer-to-field-work` — inbound with `crm`.
- `maps-to-dispatch` — inbound with `titan-maps-intelligence`.
- `field-to-time-context` — outbound with `titan-time-attendance`.
- `field-to-assets-maintenance` — outbound with `titan-assets`.

## Safety invariants

- `company_id` is the canonical tenant boundary.
- Missing peers/providers degrade capability availability; they never create fake context or authority.
- Signals are observations, never mutation authority.
- Cross-extension writes enter the target domain through its governed command gateway and produce receipts.
- Offline operation never increases authority.
- Workforce identities survive provider removal; work is reassigned or escalated rather than silently orphaned.
