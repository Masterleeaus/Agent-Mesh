<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;
use App\Extensions\TitanAIVision\System\Contracts\VisionProviderContract;
use App\Extensions\TitanAIVision\System\Providers\HostVisionProvider;
use App\Extensions\TitanAIVision\System\Providers\OpenAIResponsesVisionProvider;
use Illuminate\Contracts\Container\Container;
final class VisionProviderRegistry {
    public function __construct(private readonly Container $container,private readonly OpenAIResponsesVisionProvider $openAI){}
    public function resolve():VisionProviderContract{
        $preferred=(string)config('titan-ai-vision.provider','auto');
        if($preferred!=='auto'&&$this->container->bound($preferred))return new HostVisionProvider($this->container,$preferred);
        foreach((array)config('titan-ai-vision.provider_bindings',[]) as $binding)if(is_string($binding)&&$this->container->bound($binding))return new HostVisionProvider($this->container,$binding);
        return $this->openAI;
    }
}
