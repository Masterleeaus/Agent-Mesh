<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

/**
 * Static release/runtime audit for CRM entry surfaces. It does not claim that
 * repositories are mutation-free: repositories are allowed to write only when
 * reached behind CrmCapabilityExecutor. The audit focuses on public/scheduled
 * entry points where a second authority could otherwise emerge.
 */
final class CrmWriteSurfaceAuditor
{
    public const HTTP_EXCEPTIONS = [
        'SettingsController@adminUpdate'=>'Host-global extension enablement flags are platform configuration, not tenant CRM business state.',
        'CrmAssistantController@execute'=>'AI tool router delegates mutations to governed capability execution.',
        'CrmAssistantController@executeWeb'=>'AI tool router delegates mutations to governed capability execution.',
        'InteractionWorkspaceController@chat'=>'Interaction runtime delegates action execution to governed CRM capabilities.',
        'InteractionWorkspaceController@start'=>'Interaction runtime creates transient workflow state, not authoritative CRM domain state.',
        'InteractionWorkspaceController@answer'=>'Interaction runtime updates transient workflow state, not authoritative CRM domain state.',
        'InteractionWorkspaceController@approve'=>'Interaction approval delegates consequential actions to governed CRM capabilities.',
        'DuplicateController@preview'=>'Non-mutating duplicate merge preview exposed as POST for bounded request payloads.',
        'PortalController@verify'=>'Authentication/session verification state only; it establishes identity before CRM business capabilities may execute.',
    ];

    public const CONSOLE_EXCEPTIONS = [
        'AuditCrmCompanyTenancyCommand'=>'read_only_audit',
        'CheckCrmProductionReadinessCommand'=>'read_only_health',
        'CrmDoctorCommand'=>'read_only_diagnostics',
        'CrmMetricsCommand'=>'read_only_metrics',
        'CrmPerformanceCertifyCommand'=>'read_only_performance',
        'CrmRebuildProjectionSearchIndexCommand'=>'disposable_read_model_state',
        'DeliverCrmDomainSignalsCommand'=>'outbox_delivery_state_only',
        'DeliverCrmOutboundEffectsCommand'=>'outbox_delivery_state_only',
        'RenderCrmSalesDocumentsCommand'=>'derived_document_artifact_state',
        'RetryCrmWebhooksCommand'=>'delivery_journal_state_only',
        'RebuildCrmReadProjectionsCommand'=>'disposable_read_model_state',
        'AuditCrmWriteSurfacesCommand'=>'read_only_audit',
        'RunCrmAutomationsCommand'=>'automation_run_journal_plus_governed_action_dispatch',
    ];

    private function methodBody(string $source,string $method): string
    {
        if($source===''||!preg_match('/function\s+'.preg_quote($method,'/').'\s*\([^)]*\)[^{]*\{/s',$source,$match,PREG_OFFSET_CAPTURE))return '';
        $start=$match[0][1]+strlen($match[0][0]);$depth=1;$length=strlen($source);
        for($i=$start;$i<$length;$i++){
            if($source[$i]==='{')$depth++;
            elseif($source[$i]==='}'){$depth--;if($depth===0)return substr($source,$start,$i-$start);}
        }
        return '';
    }

    /** @return array{status:string,http:list<array<string,mixed>>,console:list<array<string,mixed>>,failures:list<array<string,mixed>>} */
    public function audit(?string $root=null): array
    {
        $root=$root?:dirname(__DIR__,2);
        $http=[];$failures=[];
        foreach(['routes/api.php','routes/web.php','routes/admin.php'] as $routeFile){
            $path=$root.'/'.$routeFile;if(!is_file($path))continue;
            foreach(file($path,FILE_IGNORE_NEW_LINES)?:[] as $lineNo=>$line){
                if(!preg_match('/Route::(post|put|patch|delete)\s*\(/i',$line,$verb))continue;
                if(preg_match('/\[([A-Za-z0-9_]+)::class\s*,\s*[\'\"]([^\'\"]+)[\'\"]\]/',$line,$m)){
                    $surface=$m[1].'@'.$m[2];$controller=$root.'/System/Http/Controllers/'.$m[1].'.php';$source=is_file($controller)?(string)file_get_contents($controller):'';
                    $body=$this->methodBody($source,$m[2]);
                    $hasGateway=str_contains($source,'CrmHumanMutationGateway')||str_contains($source,'CrmCommandBusGateway');
                    $governed=$hasGateway && ($body!=='' && (str_contains($body,'->execute(')||str_contains($body,'->request(')));
                    $exception=self::HTTP_EXCEPTIONS[$surface]??null;$ok=$governed||$exception!==null;
                    $entry=['route_file'=>$routeFile,'line'=>$lineNo+1,'verb'=>strtoupper($verb[1]),'surface'=>$surface,'governed'=>$governed,'exception'=>$exception];
                    $http[]=$entry;if(!$ok)$failures[]=$entry;
                    continue;
                }
                // Known forwarding closures are permitted only when they visibly delegate to a governed controller.
                $delegated=str_contains($line,'SalesDocumentController::class')||str_contains($line,'CrmPageController::class');
                $entry=['route_file'=>$routeFile,'line'=>$lineNo+1,'verb'=>strtoupper($verb[1]),'surface'=>'closure','governed'=>$delegated,'exception'=>$delegated?'visible_controller_delegate':null];
                $http[]=$entry;if(!$delegated)$failures[]=$entry;
            }
        }

        $console=[];
        foreach(glob($root.'/System/Console/*Command.php')?:[] as $path){
            $name=basename($path,'.php');$source=(string)file_get_contents($path);
            $governed=str_contains($source,'CrmCommandBusGateway');
            $exception=self::CONSOLE_EXCEPTIONS[$name]??null;
            $mutating=preg_match('/->(?:insert|insertOrIgnore|update|updateOrInsert|delete)\s*\(/',$source)===1 || str_contains($name,'RunCrmRetentionCommand') || str_contains($name,'RunCrmAutomationsCommand');
            $ok=!$mutating||$governed||$exception!==null;
            $entry=['surface'=>$name,'mutating'=>$mutating,'governed'=>$governed,'exception'=>$exception];
            $console[]=$entry;if(!$ok)$failures[]=$entry;
        }
        return ['status'=>$failures===[]?'pass':'fail','http'=>$http,'console'=>$console,'failures'=>$failures];
    }
}
