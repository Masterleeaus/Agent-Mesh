<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Automation;
final class CrmAutomationTriggerCatalog
{
    public const TRIGGERS = ['lead.created','contact.captured','deal.stage_changed','deal.won','task.overdue','invoice.overdue','crm.inactivity'];
    public function all(): array { return self::TRIGGERS; }
    public function assertValid(string $key): void { if (!in_array($key,self::TRIGGERS,true)) throw new \InvalidArgumentException("Unsupported CRM automation trigger: {$key}"); }
}
