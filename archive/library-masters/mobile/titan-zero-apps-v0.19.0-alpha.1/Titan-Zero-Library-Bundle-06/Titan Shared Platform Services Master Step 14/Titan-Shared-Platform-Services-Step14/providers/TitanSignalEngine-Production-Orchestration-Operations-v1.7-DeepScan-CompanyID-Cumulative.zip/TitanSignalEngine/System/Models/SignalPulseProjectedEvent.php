<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalPulseProjectedEvent extends Model
{
    protected $table = 'titan_signal_pulse_projected_events';
    protected $guarded = [];

    protected $casts = [
        'recorded_at' => 'immutable_datetime',
        'projected_at' => 'immutable_datetime',
    ];
}
