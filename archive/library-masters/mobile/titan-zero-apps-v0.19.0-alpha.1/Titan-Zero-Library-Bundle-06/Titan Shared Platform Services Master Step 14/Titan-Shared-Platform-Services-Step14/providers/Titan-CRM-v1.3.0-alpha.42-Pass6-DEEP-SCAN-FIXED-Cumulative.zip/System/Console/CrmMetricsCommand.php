<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\Services\CrmOperationalMetricsService;
use Illuminate\Console\Command;

final class CrmMetricsCommand extends Command
{
    protected $signature='crm:metrics {--tenant= : Optional company_id} {--hours=24 : Observation window} {--json : Emit JSON}';
    protected $description='Read structured Titan CRM operational metrics without mutating state.';

    public function handle(CrmOperationalMetricsService $metrics): int
    {
        $tenant=$this->option('tenant');$tenant=$tenant!==null&&$tenant!==''?(int)$tenant:null;$hours=max(1,(int)$this->option('hours'));
        $data=$metrics->collect($tenant,$hours);
        if($this->option('json')){$this->line((string)json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));return self::SUCCESS;}
        $this->info('Titan CRM operational metrics ('.$hours.'h)');
        foreach($data as $name=>$value){if(in_array($name,['window_hours','company_id'],true))continue;$this->line(str_pad((string)$name,28).' '.json_encode($value,JSON_UNESCAPED_SLASHES));}
        return self::SUCCESS;
    }
}
