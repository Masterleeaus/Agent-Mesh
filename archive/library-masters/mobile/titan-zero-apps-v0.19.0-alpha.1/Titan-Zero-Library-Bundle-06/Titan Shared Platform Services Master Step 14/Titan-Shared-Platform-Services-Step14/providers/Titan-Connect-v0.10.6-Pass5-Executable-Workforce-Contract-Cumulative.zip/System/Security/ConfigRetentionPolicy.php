<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use App\Extensions\TitanConnect\System\Contracts\RetentionPolicy;

final class ConfigRetentionPolicy implements RetentionPolicy
{
    public function daysForCompany(int $companyId): int
    {
        $companyDays = config("titan-connect.retention.companies.{$companyId}.days");
        $days = $companyDays === null
            ? config('titan-connect.retention.default_days', config('titan-connect.retention_days', 365))
            : $companyDays;

        return max(0, (int) $days);
    }
}
