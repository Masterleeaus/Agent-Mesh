<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Data;

final class FieldChangeDTO
{
    public function __construct(
        public readonly mixed $entityType,
        public readonly mixed $entityId,
        public readonly mixed $revision,
        public readonly mixed $record,
    ) {}

    public function toArray(): array
    {
        return [
            'entityType'=>$this->entityType,
            'entityId'=>$this->entityId,
            'revision'=>$this->revision,
            'record'=>$this->record,
        ];
    }
}
