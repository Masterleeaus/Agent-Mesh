# Titan Forge Architecture

Titan Forge is the canonical owner of Titan's `build-generation` domain. Its profile is `builder-generator` and it inherits `titan.production.core.v1`.

## Runtime flow

`BuildContext -> BuildRequest -> BuildSpec -> optional AI Core typed plan -> BuildPlan -> isolated deterministic/AI proposal generator -> ArtifactSet -> validator registry -> Shield -> Risk -> selective Model Council -> Governance boundary -> Command Bus boundary -> release candidate`

Forge owns generation state, generated artifacts while inside its workspace, validation evidence and release-candidate records. It does not own operational business records, workforce authority, Risk, Shield, Governance, Signal, Model Council or Command Bus state.

## Authority boundary

Generated output has `deployment_authority: none`. Forge may create a release candidate but may not install or deploy it directly. Cross-domain writes are permitted only through governed capabilities/Command Bus contracts. Current Governance and Command Bus public contracts are health-only, therefore execution remains fail-closed.

## Causality

Tenant-scoped operations carry `tenant_company_id`, `trace_id`, `correlation_id`, `causation_id`, `root_causation_id`, `operation_id`, actor identity and an idempotency key.

## Current generation modes

Deterministic workforce skeleton generation remains active. Forge now also implements AI Core planning consumption and a sandboxed AI artifact-proposal boundary, so the Manifest declares `ai-enabled`. The currently verified AI Core v0.3.0 still fails closed before usable DAG planning and does not expose an artifact-generation contract; therefore live AI artifact generation is not yet active. `ai-enabled` does not grant Forge model-routing or deployment authority.
