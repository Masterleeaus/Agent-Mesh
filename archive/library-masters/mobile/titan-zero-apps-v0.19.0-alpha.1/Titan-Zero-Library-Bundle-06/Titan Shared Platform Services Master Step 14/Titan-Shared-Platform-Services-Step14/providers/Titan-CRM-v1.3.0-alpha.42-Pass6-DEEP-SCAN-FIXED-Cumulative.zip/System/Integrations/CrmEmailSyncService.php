<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Integrations;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface; use Illuminate\Support\Str;
final class CrmEmailSyncService
{
    public function __construct(private ConnectionInterface $db,private CrmEmailLinker $linker){}
    public function registerConnection(int $userId,array $data): array
    { $id=(string)Str::ulid(); $this->db->table('crm_email_connections')->updateOrInsert(['company_id' => CrmCompanyScope::companyId($userId), 'provider'=>(string)$data['provider'],'account_email'=>strtolower(trim((string)$data['account_email']))],['public_id'=>$id,'user_id'=>CrmCompanyScope::actorUserId($userId),'external_account_id'=>$data['external_account_id']??null,'credentials_reference'=>$data['credentials_reference']??null,'status'=>'connected','settings'=>json_encode((array)($data['settings']??[])),'updated_at'=>now(),'created_at'=>now()]); return (array)$this->db->table('crm_email_connections')->where('company_id', CrmCompanyScope::companyId($userId))->where('provider',$data['provider'])->where('account_email',strtolower(trim($data['account_email'])))->first(); }
    public function ingestMessage(int $userId,string $connectionPublicId,array $message): array
    {
        $external_message_id=(string)($message['external_message_id']??''); if($external_message_id==='')throw new \InvalidArgumentException('external_message_id is required.');
        $existing=$this->db->table('crm_email_messages')->where('company_id', CrmCompanyScope::companyId($userId))->where('connection_public_id',$connectionPublicId)->where('external_message_id',$external_message_id)->first(); if($existing)return (array)$existing;
        $direction=(string)($message['direction']??'inbound'); $candidate=$direction==='inbound'?(string)($message['from_email']??''):(string)((array)($message['to_emails']??[]))[0]??''; $normalized_email=strtolower(trim($candidate)); $link=$this->linker->resolve($userId,$normalized_email); $id=(string)Str::ulid();
        $this->db->table('crm_email_messages')->insert(['public_id'=>$id,'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'connection_public_id'=>$connectionPublicId,'external_message_id'=>$external_message_id,'message_id'=>$message['message_id']??null,'thread_id'=>$message['thread_id']??null,'direction'=>$direction,'from_email'=>$message['from_email']??null,'to_emails'=>json_encode((array)($message['to_emails']??[])),'cc_emails'=>json_encode((array)($message['cc_emails']??[])),'subject'=>$message['subject']??null,'body_text'=>$message['body_text']??null,'normalized_email'=>$normalized_email?:null,'subject_type'=>$link['type']??null,'subject_public_id'=>$link['public_id']??null,'sent_at'=>$message['sent_at']??now(),'metadata'=>json_encode((array)($message['metadata']??[])),'created_at'=>now(),'updated_at'=>now()]);
        return (array)$this->db->table('crm_email_messages')->where('public_id',$id)->first();
    }
}
