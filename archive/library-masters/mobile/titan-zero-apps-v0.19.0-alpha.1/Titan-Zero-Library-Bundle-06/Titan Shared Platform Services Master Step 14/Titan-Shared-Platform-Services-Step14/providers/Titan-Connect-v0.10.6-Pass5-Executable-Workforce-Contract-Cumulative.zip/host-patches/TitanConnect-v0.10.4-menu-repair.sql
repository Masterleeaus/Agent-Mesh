-- Titan Connect v0.10.4 live MagicAI menu repair.
-- Normally migration 2026_08_09_000007_sync_magicai_menu_rows.php performs this automatically.
-- This fallback matches the menu schema supplied from the live Titan Zero host.
START TRANSACTION;

INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`)
VALUES
(NULL,'ext_titan_connect_inbox','titan-connect.inbox.unified',NULL,'Inbox','tabler-inbox',NULL,6,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(NULL,'ext_titan_connect_channels','titan-connect.channels.index',NULL,'Channels','tabler-message-cog',NULL,7,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0)
ON DUPLICATE KEY UPDATE `route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`parent_id`=NULL,`is_active`=1,`updated_at`=NOW();

SET @tc_inbox := (SELECT `id` FROM `menus` WHERE `key`='ext_titan_connect_inbox' LIMIT 1);
SET @tc_channels := (SELECT `id` FROM `menus` WHERE `key`='ext_titan_connect_channels' LIMIT 1);

INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`) VALUES
(@tc_channels,'titan_connect_channel_whatsapp','titan-connect.channels.whatsapp',NULL,'WhatsApp','tabler-brand-whatsapp',NULL,1,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_messenger','titan-connect.channels.messenger',NULL,'Messenger','tabler-brand-messenger',NULL,2,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_instagram','titan-connect.channels.instagram',NULL,'Instagram','tabler-brand-instagram',NULL,3,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_telegram','titan-connect.channels.telegram',NULL,'Telegram','tabler-brand-telegram',NULL,4,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_sms','titan-connect.channels.sms',NULL,'SMS','tabler-message',NULL,5,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_voice','titan-connect.channels.voice',NULL,'Voice','tabler-phone-call',NULL,6,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_channels,'titan_connect_channel_push','titan-connect.channels.push',NULL,'Push / Mobile','tabler-bell-ringing',NULL,7,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_unified','titan-connect.inbox.unified',NULL,'Unified Inbox','tabler-inbox',NULL,1,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_team','titan-connect.inbox.team',NULL,'Team / Internal','tabler-users-group',NULL,2,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_external','titan-connect.inbox.external',NULL,'External / Omnichannel','tabler-world',NULL,3,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_mine','titan-connect.inbox.mine',NULL,'Assigned to Me','tabler-user-check',NULL,4,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_unassigned','titan-connect.inbox.unassigned',NULL,'Unassigned','tabler-user-question',NULL,5,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_needs_human','titan-connect.inbox.needs_human',NULL,'Needs Human','tabler-hand-stop',NULL,6,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0),
(@tc_inbox,'titan_connect_inbox_closed','titan-connect.inbox.closed',NULL,'Closed / Archived','tabler-archive',NULL,7,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0)
ON DUPLICATE KEY UPDATE `parent_id`=VALUES(`parent_id`),`route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`is_active`=1,`updated_at`=NOW();

-- Admin fallback: use the host's existing Settings parent/permission rather than inventing
-- an is_admin column or relying on an unavailable extension registry.
SET @tc_admin_settings := (SELECT `id` FROM `menus` WHERE `key`='settings' LIMIT 1);

INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`)
SELECT @tc_admin_settings,'titan_connect_admin_settings_overview','dashboard.admin.settings.titan-connect.channels.index',NULL,'Titan Connect','tabler-message-cog',NULL,90,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0
WHERE @tc_admin_settings IS NOT NULL
ON DUPLICATE KEY UPDATE `parent_id`=VALUES(`parent_id`),`route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`is_active`=1,`updated_at`=NOW();

INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`)
SELECT @tc_admin_settings,'titan_connect_admin_settings_whatsapp','dashboard.admin.settings.titan-connect.channels.whatsapp',NULL,'Titan Connect — WhatsApp','tabler-brand-whatsapp',NULL,91,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0 WHERE @tc_admin_settings IS NOT NULL
ON DUPLICATE KEY UPDATE `parent_id`=VALUES(`parent_id`),`route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`is_active`=1,`updated_at`=NOW();
INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`)
SELECT @tc_admin_settings,'titan_connect_admin_settings_messenger','dashboard.admin.settings.titan-connect.channels.messenger',NULL,'Titan Connect — Messenger','tabler-brand-messenger',NULL,92,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0 WHERE @tc_admin_settings IS NOT NULL
ON DUPLICATE KEY UPDATE `parent_id`=VALUES(`parent_id`),`route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`is_active`=1,`updated_at`=NOW();
INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`)
SELECT @tc_admin_settings,'titan_connect_admin_settings_instagram','dashboard.admin.settings.titan-connect.channels.instagram',NULL,'Titan Connect — Instagram','tabler-brand-instagram',NULL,93,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0 WHERE @tc_admin_settings IS NOT NULL
ON DUPLICATE KEY UPDATE `parent_id`=VALUES(`parent_id`),`route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`is_active`=1,`updated_at`=NOW();
INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`)
SELECT @tc_admin_settings,'titan_connect_admin_settings_telegram','dashboard.admin.settings.titan-connect.channels.telegram',NULL,'Titan Connect — Telegram','tabler-brand-telegram',NULL,94,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0 WHERE @tc_admin_settings IS NOT NULL
ON DUPLICATE KEY UPDATE `parent_id`=VALUES(`parent_id`),`route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`is_active`=1,`updated_at`=NOW();
INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`)
SELECT @tc_admin_settings,'titan_connect_admin_settings_sms','dashboard.admin.settings.titan-connect.channels.sms',NULL,'Titan Connect — SMS','tabler-message',NULL,95,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0 WHERE @tc_admin_settings IS NOT NULL
ON DUPLICATE KEY UPDATE `parent_id`=VALUES(`parent_id`),`route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`is_active`=1,`updated_at`=NOW();
INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`)
SELECT @tc_admin_settings,'titan_connect_admin_settings_voice','dashboard.admin.settings.titan-connect.channels.voice',NULL,'Titan Connect — Voice','tabler-phone-call',NULL,96,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0 WHERE @tc_admin_settings IS NOT NULL
ON DUPLICATE KEY UPDATE `parent_id`=VALUES(`parent_id`),`route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`is_active`=1,`updated_at`=NOW();
INSERT INTO `menus` (`parent_id`,`key`,`route`,`route_slug`,`label`,`icon`,`svg`,`order`,`is_active`,`params`,`type`,`badge`,`extension`,`bolt_menu`,`bolt_background`,`bolt_foreground`,`letter_icon`,`letter_icon_bg`,`created_at`,`updated_at`,`custom_menu`)
SELECT @tc_admin_settings,'titan_connect_admin_settings_push','dashboard.admin.settings.titan-connect.channels.push',NULL,'Titan Connect — Push / Mobile','tabler-bell-ringing',NULL,97,1,'[]','item',NULL,NULL,0,NULL,NULL,0,NULL,NOW(),NOW(),0 WHERE @tc_admin_settings IS NOT NULL
ON DUPLICATE KEY UPDATE `parent_id`=VALUES(`parent_id`),`route`=VALUES(`route`),`label`=VALUES(`label`),`icon`=VALUES(`icon`),`is_active`=1,`updated_at`=NOW();

COMMIT;
-- Then run: php artisan titan-connect:host-sync
