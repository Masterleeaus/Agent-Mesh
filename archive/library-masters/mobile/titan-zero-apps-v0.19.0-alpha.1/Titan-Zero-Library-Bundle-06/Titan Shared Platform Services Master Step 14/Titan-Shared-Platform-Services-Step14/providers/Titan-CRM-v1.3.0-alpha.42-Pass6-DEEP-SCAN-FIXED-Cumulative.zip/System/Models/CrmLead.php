<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Models;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScoped;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

final class CrmLead extends Model
{
    use CrmCompanyScoped, SoftDeletes;

    protected $table = 'crm_leads';
    protected $guarded = ['id'];
    protected $casts = ['follow_up_at' => 'datetime', 'converted_at' => 'datetime', 'meta' => 'array'];
}
