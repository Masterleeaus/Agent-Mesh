<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Extensions\TitanSignalEngine\System\Data\EventTypeDefinition;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\TraceProfile;
use App\Extensions\TitanSignalEngine\System\Models\SignalCausalEdge;
use App\Extensions\TitanSignalEngine\System\Persistence\SignalEventStore;
use App\Extensions\TitanSignalEngine\System\Services\CorrelationService;
use App\Extensions\TitanSignalEngine\System\Services\EventTypeRegistry;
use App\Extensions\TitanSignalEngine\System\Services\SignalHistoryQueryService;
use App\Extensions\TitanSignalEngine\System\Services\SignalArchiveCatalog;
use App\Extensions\TitanSignalEngine\System\Services\LocalSignalArchiveStore;
use App\Extensions\TitanSignalEngine\System\Services\HistoryCorrelationAssembler;
use App\Extensions\TitanSignalEngine\System\Services\SignalRegistryAuthority;
use App\Extensions\TitanSignalEngine\System\Services\RegistryOwnershipPolicy;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitter;
use App\Extensions\TitanSignalEngine\System\Services\SignalPayloadGuard;
use App\Extensions\TitanSignalEngine\System\Services\SignalQueryService;
use App\Extensions\TitanSignalEngine\System\Services\TraceAnalyzer;
use App\Extensions\TitanSignalEngine\System\Services\TraceProfileRegistry;
use RuntimeException;
use Tests\TestCase;

final class CorrelationRuntimeIntegrationTest extends TestCase
{
    private SignalEmitter $emitter;
    private \App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority $emitterAuthority;
    private CorrelationService $correlation;
    private TraceProfileRegistry $profiles;

    protected function setUp(): void
    {
        parent::setUp();
        foreach (glob(dirname(__DIR__, 2) . '/database/migrations/*.php') ?: [] as $migrationFile) {
            (require $migrationFile)->up();
        }

        $store = new SignalEventStore();
        $this->emitterAuthority = new \App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority('feature-test-secret', [
            'test-service:test-suite:root' => [
                'source' => 'test-suite',
                'source_component' => null,
                'permissions' => ['signal.emit'],
                'event_type_patterns' => ['*'],
            ],
        ]);
        $validator = new SignalContextValidator($this->emitterAuthority);
        $registryAuthority = new SignalRegistryAuthority('feature-registry-secret', [
            'test-registry' => [
                'owner_source' => 'test-suite',
                'permissions' => ['signal.registry.event.manage', 'signal.registry.override'],
                'event_type_patterns' => ['*'],
                'subscriber_key_patterns' => ['*'],
            ],
        ]);
        $registryIdentity = $registryAuthority->issue('test-registry');
        $ownership = new RegistryOwnershipPolicy($registryAuthority);
        $registry = new EventTypeRegistry($ownership);
        $registry->register(EventTypeDefinition::fromArray([
            'event_type' => 'test.signal',
            'current_schema_version' => 1,
            'supported_schema_versions' => [1],
            'category' => 'test',
            'allowed_scopes' => ['tenant'],
            'required_payload_fields' => [],
            'optional_payload_fields' => ['step'],
            'allow_additional_payload_fields' => false,
            'owner_source' => 'test-suite',
            'allowed_severities' => ['info'],
        ]), $registryIdentity);

        $this->emitter = new SignalEmitter($store, $registry, $validator, new SignalPayloadGuard(65536, 8192, []));
        $query = new SignalQueryService($store, $validator);
        $history = new SignalHistoryQueryService($query, $store, new SignalArchiveCatalog(), new LocalSignalArchiveStore(), $validator);
        $this->profiles = new TraceProfileRegistry();
        $this->correlation = new CorrelationService($history, $history, $this->profiles, new TraceAnalyzer(), new HistoryCorrelationAssembler());
    }


    private function emitTrusted(
        \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope|array $signal,
        ?\App\Extensions\TitanSignalEngine\System\Data\SignalContext $context = null,
    ): \App\Extensions\TitanSignalEngine\System\Data\SignalReceipt {
        $source = is_array($signal) ? (string) ($signal['source'] ?? 'test-suite') : $signal->source;
        $component = is_array($signal) ? ($signal['source_component'] ?? null) : $signal->sourceComponent;
        $scope = is_array($signal) ? (string) ($signal['scope'] ?? 'tenant') : $signal->scope;
        $tenant = is_array($signal) ? ($signal['tenant_company_id'] ?? null) : $signal->tenantCompanyId;
        $serviceId = 'test-service:' . $source . ':' . ($component ?? 'root');
        $identity = $this->emitterAuthority->issue($serviceId);
        if ($context === null) {
            $context = $scope === 'system'
                ? \App\Extensions\TitanSignalEngine\System\Data\SignalContext::system('test-system', 'test', ['signal.tenant.emit'], $identity)
                : \App\Extensions\TitanSignalEngine\System\Data\SignalContext::tenantHuman((int) $tenant, 'test-user', 'test-session', 'test', $identity);
        } else {
            $context = new \App\Extensions\TitanSignalEngine\System\Data\SignalContext(
                $context->scope,
                $context->tenantCompanyId,
                $context->actor,
                $context->permissions,
                $identity,
            );
        }

        return $this->emitter->emit($signal, $context);
    }

    private function readContext(int $tenantCompanyId): SignalContext
    {
        return SignalContext::tenantHuman($tenantCompanyId, 'correlation-reader-' . $tenantCompanyId, 'correlation-session-' . $tenantCompanyId, 'test');
    }

    public function test_append_projects_causal_edge_and_correlation_reads_it(): void
    {
        $root = SignalEnvelope::fromArray([
            'event_type' => 'test.signal', 'tenant_company_id' => 1, 'source' => 'test-suite', 'payload' => ['step' => 'root'],
        ]);
        $child = $root->child('test.signal', 'test-suite', ['step' => 'child']);
        $this->emitTrusted($root);
        $this->emitTrusted($child);

        self::assertSame(1, SignalCausalEdge::query()->where('child_event_id', $child->eventId)->count());
        self::assertSame([$root->eventId], array_map(static fn (SignalEnvelope $event): string => $event->eventId, $this->correlation->ancestors($child->eventId, $this->readContext(1), 1)));
        self::assertSame([$child->eventId], array_map(static fn (SignalEnvelope $event): string => $event->eventId, $this->correlation->descendants($root->eventId, $this->readContext(1), 1)));
    }

    public function test_late_parent_arrival_projects_waiting_child_edge(): void
    {
        $parentId = '018f6b4e-2a74-7a70-8000-000000000071';
        $traceId = '018f6b4e-2a74-7a70-8000-000000000072';
        $correlationId = '018f6b4e-2a74-7a70-8000-000000000073';
        $child = SignalEnvelope::fromArray([
            'event_type' => 'test.signal', 'tenant_company_id' => 1, 'source' => 'test-suite',
            'trace_id' => $traceId, 'correlation_id' => $correlationId,
            'causation_id' => $parentId, 'root_causation_id' => $parentId, 'payload' => ['step' => 'child'],
        ]);
        $this->emitTrusted($child);
        self::assertSame(0, SignalCausalEdge::query()->where('child_event_id', $child->eventId)->count());

        $parent = SignalEnvelope::fromArray([
            'event_id' => $parentId, 'event_type' => 'test.signal', 'tenant_company_id' => 1, 'source' => 'test-suite',
            'trace_id' => $traceId, 'correlation_id' => $correlationId, 'root_causation_id' => $parentId, 'payload' => ['step' => 'parent'],
        ]);
        $this->emitTrusted($parent);
        self::assertSame(1, SignalCausalEdge::query()->where('child_event_id', $child->eventId)->where('parent_event_id', $parentId)->count());
    }

    public function test_causal_cycle_is_rejected_when_late_parent_would_close_loop(): void
    {
        $aId = '018f6b4e-2a74-7a70-8000-000000000081';
        $bId = '018f6b4e-2a74-7a70-8000-000000000082';
        $traceId = '018f6b4e-2a74-7a70-8000-000000000083';
        $correlationId = '018f6b4e-2a74-7a70-8000-000000000084';
        $a = SignalEnvelope::fromArray([
            'event_id' => $aId, 'event_type' => 'test.signal', 'tenant_company_id' => 1, 'source' => 'test-suite',
            'trace_id' => $traceId, 'correlation_id' => $correlationId,
            'causation_id' => $bId, 'root_causation_id' => $aId,
        ]);
        $this->emitTrusted($a);

        $b = SignalEnvelope::fromArray([
            'event_id' => $bId, 'event_type' => 'test.signal', 'tenant_company_id' => 1, 'source' => 'test-suite',
            'trace_id' => $traceId, 'correlation_id' => $correlationId,
            'causation_id' => $aId, 'root_causation_id' => $aId,
        ]);

        $this->expectException(RuntimeException::class);
        $this->emitTrusted($b);
    }

    public function test_trace_profile_returns_complete_projection_and_rewind_anchor(): void
    {
        $this->profiles->register(TraceProfile::fromArray([
            'profile_key' => 'test.trace',
            'required_event_types' => ['test.signal'],
        ]));
        $root = SignalEnvelope::fromArray([
            'event_type' => 'test.signal', 'tenant_company_id' => 1, 'source' => 'test-suite',
        ]);
        $this->emitTrusted($root);

        $projection = $this->correlation->trace($root->traceId, $this->readContext(1), 1, SignalEnvelope::SCOPE_TENANT, 'test.trace');

        self::assertSame('complete', $projection['analysis']['status']);
        self::assertSame($root->eventId, $projection['rewind']['root_causation_ids'][0]);
        self::assertSame($root->traceId, $projection['rewind']['trace_id']);
    }

    public function test_correlation_query_cannot_cross_tenant_boundary(): void
    {
        $root = SignalEnvelope::fromArray([
            'event_type' => 'test.signal', 'tenant_company_id' => 1, 'source' => 'test-suite',
        ]);
        $this->emitTrusted($root);

        self::assertSame([], $this->correlation->ancestors($root->eventId, $this->readContext(2), 2));
        self::assertSame([], $this->correlation->descendants($root->eventId, $this->readContext(2), 2));
        self::assertSame(0, $this->correlation->trace($root->traceId, $this->readContext(2), 2)['analysis']['event_count']);
    }
}
