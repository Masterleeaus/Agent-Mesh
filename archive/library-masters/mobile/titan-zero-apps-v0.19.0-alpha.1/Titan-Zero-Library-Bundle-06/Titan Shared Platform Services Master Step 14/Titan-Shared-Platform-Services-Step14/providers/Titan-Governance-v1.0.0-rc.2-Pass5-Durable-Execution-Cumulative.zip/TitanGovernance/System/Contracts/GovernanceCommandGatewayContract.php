<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Contracts;

interface GovernanceCommandGatewayContract
{
    /** @return array<string,mixed> */
    public function health(): array;

    /** @param array<string,mixed> $command @return array<string,mixed> */
    public function dispatch(array $command): array;
}
