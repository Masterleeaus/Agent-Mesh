# Titan Nexus — Upgrade Prompt

## Titan Zero Global Architecture Rules

- Use public contracts/adapters across extension boundaries; do not import peer implementation classes.
- Consequential mutations must pass Risk, Governance, applicable Autonomy, Assurance, Signal/Rewind evidence and Command Bus.
- Never directly write another Titan engine's private tables.
- Durable operations must remain tenant-scoped, traceable and idempotent.
- Pre-write backup, write verification, audit evidence and rollback metadata are mandatory for applied mutations.
- Secret/credential material must not enter compiled configuration, receipts, telemetry or Rewind evidence.
- Preserve installer compatibility, forward-only migrations and host UI conventions.

## Extension Mission

Titan Nexus is Titan Zero's deterministic business configuration compiler, configuration-history authority and governed provisioning orchestrator.

INPUT: Business Profile + exact versioned Vertical Definition + jurisdiction/knowledge/capability readiness.

OUTPUT: validated CompiledTitanConfig, dry-run preview, semantic diff, recompile plan, deterministic provisioning plan and governed mutation receipts.

## Current Build Status — v1.0.0-rc.2

1. ✅ Domain core, immutable BusinessProfile/CompiledTitanConfig and trace lineage.
2. ✅ Deterministic compiler + public Vertical Engine adapter.
3. ✅ Semantic validation + dry-run preview.
4. ✅ Versioned history + semantic diff + recompile planning.
5. ✅ Idempotent provisioning planning + Command Bus boundary.
6. ✅ Risk/Governance/Assurance/Autonomy + Signal/Rewind execution evidence.
7. ✅ Tenant-scoped Nexus Control Centre + Interface Runtime read model.
8. ✅ Host-ready Step-10 packaging/certification framework.
9. ✅ RC2 audit remediation: strict booleans, system Autonomy, authorization wiring, canonical contract ingress, optimistic concurrency, legacy-row quarantine, lifecycle persistence, truthful health, menu boot/uninstall safety, compound-secret rejection, package-certifier hardening and SPDX SBOM.
10. ✅ Production completion Step 4: dependency-aware health and runtime capability readiness for Vertical Engine, Command Bus, Risk, Governance, Assurance, Signal, Rewind, Autonomy, Knowledge Authority and Interface Runtime.
11. ⏳ Production completion Step 5: Installer 1.7.8 fresh-install package preflight is implemented and passing; live `INSTALLER_CERTIFIED` remains `NOT_RUN` until this exact ZIP is executed on the target MagicAI host.

## Promotion Gate

Final `1.0.0` promotion requires live exact-host certification on the target MagicAI/Laravel/Installer 1.7.8 environment plus trusted release signing. Package-side certification alone is not live-host certification.
