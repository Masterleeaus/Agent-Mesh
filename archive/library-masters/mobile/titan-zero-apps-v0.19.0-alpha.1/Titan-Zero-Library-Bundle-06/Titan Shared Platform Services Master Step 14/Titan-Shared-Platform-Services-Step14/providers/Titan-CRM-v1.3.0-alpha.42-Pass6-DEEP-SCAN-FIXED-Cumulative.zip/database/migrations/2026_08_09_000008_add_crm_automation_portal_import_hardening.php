<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('crm_automation_rules')) {
            Schema::create('crm_automation_rules', function (Blueprint $t): void {
                $t->id(); $t->char('public_id', 26)->unique(); $t->unsignedBigInteger('user_id')->index();
                $t->string('name'); $t->boolean('enabled')->default(true)->index(); $t->string('trigger_key', 80)->index();
                $t->json('conditions')->nullable(); $t->json('actions'); $t->unsignedInteger('cooldown_seconds')->default(0);
                $t->string('idempotency_key', 160)->nullable(); $t->timestamps(); $t->softDeletes();
                $t->index(['user_id','enabled','trigger_key'], 'crm_automation_rule_lookup');
            });
        }

        if (! Schema::hasTable('crm_automation_runs')) {
            Schema::create('crm_automation_runs', function (Blueprint $t): void {
                $t->id(); $t->char('public_id', 26)->unique(); $t->unsignedBigInteger('user_id')->index();
                $t->char('rule_public_id', 26)->index(); $t->string('trigger_key', 80)->index();
                $t->string('subject_type', 60)->nullable()->index(); $t->char('subject_public_id', 26)->nullable()->index();
                $t->char('fingerprint', 64); $t->string('idempotency_key', 160)->nullable(); $t->string('status', 30)->default('pending')->index();
                $t->unsignedInteger('attempt_count')->default(0); $t->text('last_error')->nullable(); $t->json('context')->nullable(); $t->json('results')->nullable();
                $t->timestamp('started_at')->nullable(); $t->timestamp('finished_at')->nullable(); $t->timestamps();
                $t->unique(['user_id','rule_public_id','fingerprint'], 'crm_automation_run_unique');
            });
        }

        if (! Schema::hasTable('crm_portal_grants')) {
            Schema::create('crm_portal_grants', function (Blueprint $t): void {
                $t->id(); $t->char('public_id', 26)->unique(); $t->unsignedBigInteger('user_id')->index();
                $t->char('company_public_id', 26)->nullable()->index(); $t->char('contact_public_id', 26)->nullable()->index();
                $t->string('document_type', 30)->nullable()->index(); $t->char('document_public_id', 26)->nullable()->index();
                $t->string('label')->nullable(); $t->string('status', 30)->default('invited')->index();
                $t->char('token_hash', 64)->unique(); $t->string('token_hint', 12); $t->json('scopes');
                $t->timestamp('invited_at')->nullable(); $t->timestamp('activated_at')->nullable(); $t->timestamp('last_accessed_at')->nullable();
                $t->dateTime('expires_at')->index(); $t->timestamp('revoked_at')->nullable()->index(); $t->json('metadata')->nullable(); $t->timestamps();
            });
        }

        if (! Schema::hasTable('crm_portal_events')) {
            Schema::create('crm_portal_events', function (Blueprint $t): void {
                $t->id(); $t->unsignedBigInteger('user_id')->index(); $t->char('portal_grant_public_id', 26)->index();
                $t->string('event_type', 60)->index(); $t->char('ip_hash', 64)->nullable(); $t->string('user_agent_summary', 500)->nullable();
                $t->json('metadata')->nullable(); $t->dateTime('occurred_at')->index();
            });
        }

        if (! Schema::hasTable('crm_portal_comments')) {
            Schema::create('crm_portal_comments', function (Blueprint $t): void {
                $t->id(); $t->char('public_id', 26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->char('portal_grant_public_id', 26)->index();
                $t->string('subject_type', 60)->nullable()->index(); $t->char('subject_public_id', 26)->nullable()->index(); $t->text('body');
                $t->string('author_type', 30)->default('customer'); $t->dateTime('created_at')->index();
            });
        }

        if (! Schema::hasTable('crm_import_batches')) {
            Schema::create('crm_import_batches', function (Blueprint $t): void {
                $t->id(); $t->char('public_id', 26)->unique(); $t->unsignedBigInteger('user_id')->index();
                $t->string('source_type', 60); $t->string('source_filename')->nullable(); $t->json('mapping'); $t->boolean('dry_run')->default(true);
                $t->string('status', 30)->default('pending')->index(); $t->unsignedInteger('total_rows')->default(0); $t->unsignedInteger('accepted_rows')->default(0);
                $t->unsignedInteger('rejected_rows')->default(0); $t->unsignedInteger('created_rows')->default(0); $t->unsignedInteger('updated_rows')->default(0);
                $t->unsignedInteger('duplicate_rows')->default(0); $t->timestamp('started_at')->nullable(); $t->timestamp('finished_at')->nullable();
                $t->timestamp('rolled_back_at')->nullable(); $t->json('summary')->nullable(); $t->timestamps();
            });
        }

        if (! Schema::hasTable('crm_import_rows')) {
            Schema::create('crm_import_rows', function (Blueprint $t): void {
                $t->id(); $t->unsignedBigInteger('user_id')->index(); $t->char('batch_public_id', 26)->index(); $t->unsignedInteger('row_number');
                $t->json('source_payload'); $t->json('mapped_payload')->nullable(); $t->char('fingerprint', 64)->index(); $t->string('status', 30)->default('pending')->index();
                $t->char('result_public_id', 26)->nullable()->index(); $t->json('errors')->nullable(); $t->timestamps();
                $t->unique(['user_id','batch_public_id','row_number'], 'crm_import_row_unique');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('crm_import_rows');
        Schema::dropIfExists('crm_import_batches');
        Schema::dropIfExists('crm_portal_comments');
        Schema::dropIfExists('crm_portal_events');
        Schema::dropIfExists('crm_portal_grants');
        Schema::dropIfExists('crm_automation_runs');
        Schema::dropIfExists('crm_automation_rules');
    }
};
