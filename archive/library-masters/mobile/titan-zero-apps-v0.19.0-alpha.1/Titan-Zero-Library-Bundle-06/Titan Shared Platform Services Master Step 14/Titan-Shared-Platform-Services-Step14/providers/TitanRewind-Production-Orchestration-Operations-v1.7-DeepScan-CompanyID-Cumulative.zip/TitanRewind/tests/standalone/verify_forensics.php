<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$passes = 0;
$check = static function (bool $condition, string $message) use (&$failures, &$passes): void {
    if ($condition) { ++$passes; echo "PASS: {$message}\n"; return; }
    $failures[] = $message; echo "FAIL: {$message}\n";
};

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$check(($manifest['version'] ?? null) === '1.0.6', 'manifest version is 1.0.6');
foreach (['rewind.integrity','rewind.drift','rewind.root_cause','rewind.snapshot.compare','rewind.diagnostics'] as $capability) {
    $check(in_array($capability, $manifest['capabilities'] ?? [], true), "capability {$capability} is declared only after implementation");
}
foreach (['titan_rewind_integrity_checks','titan_rewind_drift_findings'] as $table) {
    $check(in_array($table, $manifest['database']['owned_tables'] ?? [], true), "manifest owns {$table}");
}

$required = [
    '/System/Forensics/RewindIntegrityHasher.php',
    '/System/Forensics/RewindTemporalDiagnostics.php',
    '/System/Forensics/RewindRootCauseAnalyzer.php',
    '/System/Forensics/RewindDriftRules.php',
    '/System/Models/RewindIntegrityCheck.php',
    '/System/Models/RewindDriftFinding.php',
    '/System/Services/RewindIntegrityService.php',
    '/System/Services/RewindDriftService.php',
    '/System/Services/RewindForensicsService.php',
    '/System/Services/RewindSnapshotComparisonService.php',
    '/System/Http/Controllers/ForensicsController.php',
    '/database/migrations/2026_08_15_000004_add_titan_rewind_forensics.php',
];
foreach ($required as $file) $check(is_file($root . $file), "forensics file exists: {$file}");

$pure = [
    '/System/Support/CanonicalJson.php',
    '/System/Forensics/RewindIntegrityHasher.php',
    '/System/Forensics/RewindTemporalDiagnostics.php',
    '/System/Forensics/RewindRootCauseAnalyzer.php',
    '/System/Forensics/RewindDriftRules.php',
];
if (!array_filter($pure, static fn (string $file): bool => !is_file($root . $file))) {
    foreach ($pure as $file) require_once $root . $file;

    $json = new App\Extensions\TitanRewind\System\Support\CanonicalJson();
    $hasher = new App\Extensions\TitanRewind\System\Forensics\RewindIntegrityHasher($json);
    $event = [
        'tenant_company_id'=>7,
        'event_id'=>'00000000-0000-4000-8000-000000000001',
        'trace_id'=>'00000000-0000-4000-8000-000000000099',
        'source_engine'=>'titan-risk',
        'event_type'=>'risk.assessed',
        'sequence'=>2,
        'payload'=>['b'=>2,'a'=>1],
        'occurred_at'=>'2026-08-15T09:00:00.000000+00:00',
        'recorded_at'=>'2026-08-15T09:00:01.000000+00:00',
        'integrity_hash'=>'must-not-affect-content',
        'chain_hash'=>'must-not-affect-content',
    ];
    $hashA = $hasher->contentHash($event);
    $event['payload'] = ['a'=>1,'b'=>2];
    $event['integrity_hash'] = 'changed-local-field';
    $hashB = $hasher->contentHash($event);
    $check($hashA === $hashB, 'canonical content hash ignores local integrity metadata and JSON key order');
    $event['payload']['b'] = 3;
    $check($hashA !== $hasher->contentHash($event), 'canonical content hash changes when event content changes');
    $chain1 = $hasher->chainHash(null, $hashA, '00000000-0000-4000-8000-000000000001', 1);
    $chain2 = $hasher->chainHash($chain1, $hashA, '00000000-0000-4000-8000-000000000002', 2);
    $check(strlen($chain1) === 64 && strlen($chain2) === 64 && $chain1 !== $chain2, 'ingestion chain hash binds previous hash, event id and position');

    $temporal = new App\Extensions\TitanRewind\System\Forensics\RewindTemporalDiagnostics(30);
    $diag = $temporal->analyse([
        ['id'=>1,'event_id'=>'e2','sequence'=>2,'occurred_at'=>'2026-08-15T09:00:20+00:00','recorded_at'=>'2026-08-15T09:00:21+00:00'],
        ['id'=>2,'event_id'=>'e1','sequence'=>1,'occurred_at'=>'2026-08-15T09:00:00+00:00','recorded_at'=>'2026-08-15T09:01:00+00:00'],
        ['id'=>3,'event_id'=>'e3','sequence'=>2,'occurred_at'=>'2026-08-15T09:00:30+00:00','recorded_at'=>'2026-08-15T09:00:29+00:00'],
    ]);
    $check(($diag['out_of_order_arrival_count'] ?? 0) >= 1, 'temporal diagnostics identify late out-of-order arrival');
    $check(($diag['late_event_count'] ?? 0) === 1, 'temporal diagnostics apply configured recording-lag threshold');
    $check(($diag['sequence_collision_count'] ?? 0) === 1, 'temporal diagnostics identify duplicate sequence positions');
    $check(($diag['recorded_before_occurred_count'] ?? 0) === 1, 'temporal diagnostics identify clock-order anomalies');

    $rootCause = new App\Extensions\TitanRewind\System\Forensics\RewindRootCauseAnalyzer();
    $analysis = $rootCause->analyse([
        ['event_id'=>'a','sequence'=>1,'event_type'=>'decision.created','source_engine'=>'titan-ai-core','risk_state'=>[]],
        ['event_id'=>'b','sequence'=>2,'event_type'=>'command.failed','source_engine'=>'titan-command-bus','causation_id'=>'a','risk_state'=>['level'=>'high']],
        ['event_id'=>'c','sequence'=>3,'event_type'=>'recovery.completed','source_engine'=>'titan-command-bus','causation_id'=>'b','risk_state'=>[]],
    ], ['edges'=>[['from'=>'a','to'=>'b'],['from'=>'b','to'=>'c']],'orphans'=>[]], []);
    $check(($analysis['primary']['event_id'] ?? null) === 'b', 'root-cause analysis selects earliest explicit failure event');
    $check(in_array('a', $analysis['primary']['upstream_event_ids'] ?? [], true), 'root-cause analysis reconstructs upstream causation chain');
    $check(($analysis['recovery_detected'] ?? null) === true, 'root-cause analysis detects downstream recovery');

    $rules = new App\Extensions\TitanRewind\System\Forensics\RewindDriftRules();
    $findings = $rules->evaluate(
        ['status'=>'failed','failures_count'=>2,'unsealed_count'=>0],
        ['late_event_count'=>2,'out_of_order_arrival_count'=>1,'sequence_collision_count'=>1,'recorded_before_occurred_count'=>0],
        ['orphans'=>[['event_id'=>'x','missing_causation_id'=>'y']]],
        [['event_id'=>'z','event_type'=>'command.failed','risk_state'=>['level'=>'high']]]
    );
    $types = array_column($findings, 'finding_type');
    foreach (['integrity_failure','late_event_arrival','sequence_collision','causation_orphan','high_risk_failure'] as $type) {
        $check(in_array($type, $types, true), "drift rules emit {$type}");
    }
}

$eventStore = is_file($root . '/System/Services/RewindEventStore.php') ? (string) file_get_contents($root . '/System/Services/RewindEventStore.php') : '';
$check(str_contains($eventStore, 'chain_position'), 'event store assigns ingestion chain positions');
$check(str_contains($eventStore, 'chain_previous_hash'), 'event store persists previous ingestion chain hash');
$check(str_contains($eventStore, 'chain_hash'), 'event store persists ingestion chain hash');
$check(str_contains($eventStore, 'RewindIntegrityHasher'), 'event store uses canonical integrity hasher');

$projector = is_file($root . '/System/Services/RewindTraceProjector.php') ? (string) file_get_contents($root . '/System/Services/RewindTraceProjector.php') : '';
foreach (['late_event_count','out_of_order_arrival_count','sequence_collision_count','causation_orphan_count','forensic_state'] as $field) {
    $check(str_contains($projector, $field), "trace projector materializes {$field}");
}

$reconstruction = is_file($root . '/System/Services/RewindReconstructionService.php') ? (string) file_get_contents($root . '/System/Services/RewindReconstructionService.php') : '';
foreach (['forensics','root_cause','snapshot_comparisons'] as $key) {
    $check(str_contains($reconstruction, "'{$key}'"), "reconstruction returns {$key}");
}
$check(!str_contains($reconstruction, '$dependencies->map'), 'reconstruction respects dependency service array contract');

$routes = is_file($root . '/routes/user.php') ? (string) file_get_contents($root . '/routes/user.php') : '';
$check(str_contains($routes, 'ForensicsController'), 'user routes expose trace integrity/drift actions');
$check(str_contains($routes, '/integrity'), 'user routes expose integrity verification endpoint');
$check(str_contains($routes, '/drift'), 'user routes expose drift scan endpoint');

$provider = is_file($root . '/System/TitanRewindServiceProvider.php') ? (string) file_get_contents($root . '/System/TitanRewindServiceProvider.php') : '';
foreach (['RewindIntegrityService::class','RewindDriftService::class','RewindForensicsService::class','RewindSnapshotComparisonService::class'] as $binding) {
    $check(str_contains($provider, $binding), "provider wires {$binding}");
}


$managerContract = is_file($root . '/System/Contracts/RewindManagerContract.php') ? (string) file_get_contents($root . '/System/Contracts/RewindManagerContract.php') : '';
$manager = is_file($root . '/System/Services/RewindManager.php') ? (string) file_get_contents($root . '/System/Services/RewindManager.php') : '';
foreach (['verifyIntegrity','scanDrift'] as $method) {
    $check(str_contains($managerContract, 'function ' . $method . '('), "public manager contract exposes {$method}");
    $check(str_contains($manager, 'function ' . $method . '('), "manager implements {$method}");
}

$runtime = '';
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/System', FilesystemIterator::SKIP_DOTS));
foreach ($iterator as $file) {
    if ($file->isFile() && $file->getExtension() === 'php') $runtime .= "\n" . file_get_contents($file->getPathname());
}
$check(!str_contains($runtime, 'Modules\\TitanRewind'), 'forensics transplant contains no donor runtime namespace');
$check(!str_contains($runtime, 'eloquent.created: *'), 'forensics transplant does not restore wildcard Eloquent capture');
$check(!preg_match('/\b(?:curl_exec|shell_exec|exec|system|passthru|proc_open)\s*\(/', $runtime), 'forensics transplant introduces no direct external/shell execution');

if ($failures !== []) {
    fwrite(STDERR, "\nFORENSICS VERIFICATION FAILED (" . count($failures) . " failures, {$passes} passes)\n");
    exit(1);
}

echo "\nFORENSICS VERIFICATION PASSED ({$passes} checks)\n";
