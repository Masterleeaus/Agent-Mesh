@php
    $globalNewMenu = (array) ($menu ?? []);
    $globalNewPrimary = $globalNewMenu['primary'] ?? null;
    $globalNewSecondary = array_values((array) ($globalNewMenu['secondary'] ?? []));
    $globalNewActions = array_values(array_filter(array_merge($globalNewPrimary ? [$globalNewPrimary] : [], $globalNewSecondary)));
@endphp
@if($globalNewPrimary)
<div class="d-none" data-crm-global-new data-crm-global-new-primary="{{ $globalNewPrimary['journey'] }}">
    @foreach($globalNewActions as $globalNewIndex => $globalNewAction)
        @php($globalNewFormId = 'crm-global-new-form-'.$globalNewIndex.'-'.substr(sha1((string)$globalNewAction['journey']),0,8))
        <form id="{{ $globalNewFormId }}" data-crm-global-new-form data-crm-global-new-journey="{{ $globalNewAction['journey'] }}" data-crm-global-new-label="{{ $globalNewAction['label'] }}" method="POST" action="{{ route('dashboard.user.crm.interactions.start',$globalNewAction['journey']) }}">
            @csrf
            @foreach((array)($globalNewAction['prefill'] ?? []) as $key=>$value)
                @if(is_scalar($value) && $value !== '')<input type="hidden" name="prefill[{{ $key }}]" value="{{ $value }}">@endif
            @endforeach
        </form>
    @endforeach
</div>

@once
@push('css')
<style>
.crm-global-new-menu{position:fixed;z-index:1085;min-width:240px;max-width:min(340px,calc(100vw - 24px));padding:8px;border:1px solid var(--bs-border-color,rgba(255,255,255,.12));border-radius:14px;background:var(--bs-body-bg,#11151d);box-shadow:0 18px 45px rgba(0,0,0,.32)}
.crm-global-new-menu[hidden]{display:none!important}.crm-global-new-menu button{width:100%;display:flex;align-items:center;justify-content:flex-start;gap:8px;border:0;border-radius:9px;background:transparent;color:inherit;padding:.62rem .72rem;text-align:left}.crm-global-new-menu button:hover,.crm-global-new-menu button:focus{background:var(--bs-tertiary-bg,rgba(255,255,255,.08))}.crm-global-new-caret{margin-inline-start:6px!important;min-width:42px!important;padding-inline:.65rem!important}.crm-global-new-host-primary{white-space:nowrap}
</style>
@endpush

@push('script')
<script>
(() => {
    const root = document.querySelector('[data-crm-global-new]');
    if (!root || root.dataset.crmGlobalNewBooted === '1') return;
    root.dataset.crmGlobalNewBooted = '1';

    const primaryJourney = root.getAttribute('data-crm-global-new-primary');
    const forms = Array.from(root.querySelectorAll('[data-crm-global-new-form]'));
    const primaryForm = forms.find((form) => form.getAttribute('data-crm-global-new-journey') === primaryJourney);
    if (!primaryForm) return;
    const primaryLabel = primaryForm.getAttribute('data-crm-global-new-label') || 'New';

    let hostButton = null;
    let dropdownButton = null;
    let menu = null;

    const cleanText = (node) => (node?.textContent || '').replace(/\s+/g, ' ').trim();
    const isVisible = (node) => !!(node && (node.offsetWidth || node.offsetHeight || node.getClientRects().length));

    const submitForm = (form) => {
        if (!form) return;
        if (typeof form.requestSubmit === 'function') form.requestSubmit();
        else form.submit();
    };

    const closeMenu = () => { if (menu) menu.hidden = true; };

    const buildMenu = () => {
        if (menu) menu.remove();
        menu = document.createElement('div');
        menu.className = 'crm-global-new-menu';
        menu.setAttribute('data-crm-global-new-dropdown', '1');
        menu.hidden = true;
        forms.slice(1).forEach((form) => {
            const item = document.createElement('button');
            item.type = 'button';
            item.textContent = form.getAttribute('data-crm-global-new-label') || 'New';
            item.dataset.crmGlobalNewForm = form.id;
            item.addEventListener('click', () => { closeMenu(); submitForm(form); });
            menu.appendChild(item);
        });
        document.body.appendChild(menu);
    };

    const positionMenu = () => {
        if (!menu || !dropdownButton) return;
        const rect = dropdownButton.getBoundingClientRect();
        const menuWidth = Math.min(340, Math.max(240, menu.offsetWidth || 240));
        const left = Math.max(12, Math.min(window.innerWidth - menuWidth - 12, rect.right - menuWidth));
        menu.style.left = `${left}px`;
        menu.style.top = `${Math.min(window.innerHeight - 20, rect.bottom + 8)}px`;
    };

    const teardownHost = () => {
        if (hostButton) {
            const original = hostButton.getAttribute('data-crm-original-new');
            if (original !== null) hostButton.textContent = original;
            const originalHref = hostButton.getAttribute('data-crm-original-new-href');
            if (originalHref !== null && hostButton.tagName === 'A') hostButton.setAttribute('href', originalHref);
            hostButton.removeAttribute('data-crm-global-new-host');
            hostButton.removeAttribute('data-crm-original-new');
            hostButton.removeAttribute('data-crm-original-new-href');
            hostButton.classList.remove('crm-global-new-host-primary');
        }
        dropdownButton?.remove(); dropdownButton = null;
        menu?.remove(); menu = null;
        hostButton = null;
    };

    const findHostControl = () => {
        const already = document.querySelector('[data-crm-global-new-host="1"]');
        if (already && isVisible(already)) return already;
        return Array.from(document.querySelectorAll('a,button')).find((candidate) => {
            if (!isVisible(candidate)) return false;
            if (candidate.closest('[data-crm-interaction-page]')) return false;
            if (candidate.closest('[data-crm-global-new-dropdown]')) return false;
            return /^(\+\s*)?new$/i.test(cleanText(candidate));
        }) || null;
    };

    const attach = () => {
        const candidate = findHostControl();
        if (!candidate) return;
        if (hostButton && hostButton !== candidate) teardownHost();
        if (candidate.getAttribute('data-crm-global-new-host') === '1' && (forms.length <= 1 || dropdownButton?.isConnected)) return;

        hostButton = candidate;
        hostButton.setAttribute('data-crm-original-new', cleanText(hostButton));
        if (hostButton.tagName === 'A') hostButton.setAttribute('data-crm-original-new-href', hostButton.getAttribute('href') || '');
        hostButton.setAttribute('data-crm-global-new-host', '1');
        hostButton.classList.add('crm-global-new-host-primary');
        hostButton.textContent = `+ ${primaryLabel}`;
        if (hostButton.tagName === 'A') hostButton.setAttribute('href', '#');

        if (forms.length > 1) {
            dropdownButton = hostButton.cloneNode(false);
            dropdownButton.removeAttribute('href');
            dropdownButton.removeAttribute('data-crm-global-new-host');
            dropdownButton.removeAttribute('data-crm-original-new');
            dropdownButton.removeAttribute('data-crm-original-new-href');
            dropdownButton.setAttribute('data-crm-global-new-caret', '1');
            dropdownButton.classList.add('crm-global-new-caret');
            dropdownButton.textContent = '▾';
            dropdownButton.setAttribute('aria-label', 'More new actions');
            if (dropdownButton.tagName === 'BUTTON') dropdownButton.type = 'button';
            hostButton.insertAdjacentElement('afterend', dropdownButton);
            buildMenu();
            dropdownButton.addEventListener('click', (event) => {
                event.preventDefault(); event.stopPropagation();
                menu.hidden = !menu.hidden;
                if (!menu.hidden) positionMenu();
            });
        }
    };

    document.addEventListener('click', (event) => {
        const clickedHost = event.target.closest?.('[data-crm-global-new-host="1"]');
        if (clickedHost) {
            event.preventDefault(); event.stopPropagation();
            if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation();
            submitForm(primaryForm);
            return;
        }
        if (menu && !menu.hidden && !event.target.closest?.('[data-crm-global-new-dropdown]') && !event.target.closest?.('[data-crm-global-new-caret]')) closeMenu();
    }, true);

    window.addEventListener('resize', () => { if (menu && !menu.hidden) positionMenu(); });
    window.addEventListener('scroll', () => { if (menu && !menu.hidden) positionMenu(); }, true);

    attach();
    const observer = new MutationObserver(() => attach());
    observer.observe(document.body, {childList:true, subtree:true});
    window.addEventListener('pagehide', () => { observer.disconnect(); teardownHost(); }, {once:true});
})();
</script>
@endpush
@endonce
@endif
