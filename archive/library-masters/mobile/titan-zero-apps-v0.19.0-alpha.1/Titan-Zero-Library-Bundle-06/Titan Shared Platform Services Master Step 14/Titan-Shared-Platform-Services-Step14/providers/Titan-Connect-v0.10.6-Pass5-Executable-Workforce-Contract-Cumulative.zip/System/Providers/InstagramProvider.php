<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Providers;

use App\Extensions\TitanConnect\System\DTO\ProviderSendResult;

final class InstagramProvider extends MessengerProvider
{
    public function key(): string { return 'instagram'; }

    public function send(array $message, array $credentials): ProviderSendResult
    {
        $token = $this->credential($credentials, 'access_token');
        $accountId = $this->accountIdentity($credentials, 'instagram_account_id', $message);

        $payload = ['recipient' => ['id' => (string) ($message['to'] ?? '')]];
        if (($attachment = $this->firstAttachment($message)) !== null && ! empty($attachment['public_url'])) {
            $payload['message'] = ['attachment' => ['type' => 'image', 'payload' => ['url' => (string) $attachment['public_url']]]];
        } else {
            $payload['message'] = ['text' => (string) ($message['body'] ?? '')];
        }

        $url = $this->graphBase($this->key(), $credentials).'/'.$this->graphVersion($this->key(), $credentials).'/'.$accountId.'/messages';
        $response = $this->requireSuccess($this->http->request('POST', $url, ['bearer' => $token, 'json' => $payload]), 'send');
        $providerId = $response->json('message_id') ?? $response->json('id');
        return new ProviderSendResult('sent', is_scalar($providerId) ? (string) $providerId : null, $response->json);
    }

    public function health(array $credentials): array
    {
        $token = $this->credential($credentials, 'access_token');
        $accountId = $this->accountIdentity($credentials, 'instagram_account_id');
        $url = $this->graphBase($this->key(), $credentials).'/'.$this->graphVersion($this->key(), $credentials).'/'.$accountId;
        $response = $this->http->request('GET', $url, ['bearer' => $token, 'query' => ['fields' => 'id,username']]);
        return ['ok' => $response->isSuccessful(), 'provider' => $this->key(), 'configured' => true, 'http_status' => $response->status, 'account_id' => $response->json('id')];
    }
}
