# Titan CRM Core v1.3.0-alpha.30 — Invoice & Receivables Authority

- CRM invoice issuance now freezes `crm.invoice-contract.v1` evidence and preserves accepted quote/Titan Field lineage.
- Removed CRM-local payment execution and provider-reconciliation services; `crm.payment.*` is Titan Pay compatibility only.
- Added verified Titan Pay settlement references with payload-hash/idempotency replay protection and mismatch review.
- Added CRM-owned credit notes with immutable issue snapshots, void lifecycle, receivable recalculation and refund-due tracking.
- Added authoritative ageing buckets, reconciliation issue review/resolution and expanded invoice CQRS fields.
- Invoice PDFs render from immutable issued snapshots.
- Fresh CRM installs do not create local payment-processing tables; upgrades preserve/backfill legacy payment evidence without deleting it.
- CRM no longer queries Titan Field work-order tables when creating invoices; work-order IDs are lineage references only.
