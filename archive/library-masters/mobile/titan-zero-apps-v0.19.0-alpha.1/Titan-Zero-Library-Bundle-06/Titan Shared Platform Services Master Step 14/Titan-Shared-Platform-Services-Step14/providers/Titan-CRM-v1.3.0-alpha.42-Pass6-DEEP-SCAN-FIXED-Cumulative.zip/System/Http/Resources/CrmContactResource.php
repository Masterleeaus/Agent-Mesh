<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

final class CrmContactResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'public_id' => $this->public_id,
            'customer_unification_id' => $this->customer_unification_id,
            'customer_company_id' => $this->customer_company_id,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'email' => $this->email,
            'phone' => $this->phone,
            'role' => $this->role,
            'is_primary' => $this->is_primary,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
