<?php
declare(strict_types=1);
namespace App\Extensions\TitanCommandBus\System\Contracts;
use App\Extensions\TitanCommandBus\System\DTO\{ApprovalDecision,AssuranceDecision,AutonomyDecision,CommandContext,CommandRequest,GovernanceDecision,RiskDecision};
interface CommandApprovalGateContract {
    public function available(): bool;
    public function verify(CommandContext $context, CommandRequest $request, GovernanceDecision $governance, ?RiskDecision $risk = null, ?AssuranceDecision $assurance = null, ?AutonomyDecision $autonomy = null): ApprovalDecision;
}
