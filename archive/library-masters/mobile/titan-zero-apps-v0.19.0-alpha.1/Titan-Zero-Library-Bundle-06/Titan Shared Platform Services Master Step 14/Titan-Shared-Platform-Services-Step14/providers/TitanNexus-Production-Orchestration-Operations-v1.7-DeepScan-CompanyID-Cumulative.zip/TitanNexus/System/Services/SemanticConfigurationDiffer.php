<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Services;

use App\Extensions\TitanNexus\System\Contracts\ConfigurationDifferContract;
use App\Extensions\TitanNexus\System\Domain\CompiledTitanConfig;
use App\Extensions\TitanNexus\System\Domain\ConfigurationDiff;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeDisposition;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeKind;
use App\Extensions\TitanNexus\System\Domain\SemanticDiffEntry;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use InvalidArgumentException;

final class SemanticConfigurationDiffer implements ConfigurationDifferContract
{
    public function diff(CompiledTitanConfig $current, CompiledTitanConfig $proposed, VerticalDefinition $definition): ConfigurationDiff
    {
        if ($current->tenantCompanyId() !== $proposed->tenantCompanyId()) {
            throw new InvalidArgumentException('Current and proposed configurations must belong to the same tenant.');
        }
        if ($proposed->verticalId() !== $definition->verticalId() || $proposed->verticalVersion() !== $definition->verticalVersion()) {
            throw new InvalidArgumentException('Proposed configuration must match the recompile vertical definition.');
        }

        $currentSemantic = $this->semanticPayload($current);
        $proposedSemantic = $this->semanticPayload($proposed);
        $entries = [];
        $this->compareMaps($currentSemantic, $proposedSemantic, '', $definition->recompilePolicy(), $entries);

        return new ConfigurationDiff($current->outputHash(), $proposed->outputHash(), $entries);
    }

    /** @return array<string, mixed> */
    private function semanticPayload(CompiledTitanConfig $config): array
    {
        return [
            'vertical' => [
                'id' => $config->verticalId(),
                'version' => $config->verticalVersion(),
            ],
            'knowledge' => [
                'snapshot_version' => $config->knowledgeSnapshotVersion(),
            ],
            'sections' => $config->sections(),
        ];
    }

    /**
     * @param array<string|int, mixed> $before
     * @param array<string|int, mixed> $after
     * @param array<string, list<string>> $policy
     * @param list<SemanticDiffEntry> $entries
     */
    private function compareMaps(array $before, array $after, string $prefix, array $policy, array &$entries): void
    {
        $keys = array_values(array_unique(array_merge(array_keys($before), array_keys($after))));
        usort($keys, static fn (string|int $a, string|int $b): int => strcmp((string) $a, (string) $b));

        foreach ($keys as $key) {
            $path = $prefix === '' ? (string) $key : $prefix . '.' . (string) $key;
            $hasBefore = array_key_exists($key, $before);
            $hasAfter = array_key_exists($key, $after);

            if (!$hasBefore) {
                $entries[] = $this->entry($path, SemanticChangeKind::Add, null, $after[$key], $policy);
                continue;
            }
            if (!$hasAfter) {
                $entries[] = $this->entry($path, SemanticChangeKind::Deprecate, $before[$key], null, $policy);
                continue;
            }

            $beforeValue = $before[$key];
            $afterValue = $after[$key];
            $beforeIsMap = is_array($beforeValue) && ($beforeValue === [] || !array_is_list($beforeValue));
            $afterIsMap = is_array($afterValue) && ($afterValue === [] || !array_is_list($afterValue));

            if ($beforeIsMap && $afterIsMap) {
                if ($beforeValue === [] && $afterValue === []) {
                    $entries[] = $this->entry($path, SemanticChangeKind::Unchanged, [], [], $policy);
                    continue;
                }
                $this->compareMaps($beforeValue, $afterValue, $path, $policy, $entries);
                continue;
            }

            $kind = $beforeValue === $afterValue ? SemanticChangeKind::Unchanged : SemanticChangeKind::Modify;
            $entries[] = $this->entry($path, $kind, $beforeValue, $afterValue, $policy);
        }
    }

    /** @param array<string, list<string>> $policy */
    private function entry(string $path, SemanticChangeKind $kind, mixed $before, mixed $after, array $policy): SemanticDiffEntry
    {
        $disposition = SemanticChangeDisposition::Apply;
        $reason = null;
        if ($kind !== SemanticChangeKind::Unchanged) {
            if ($this->matchesAny($path, $policy['blocked_paths'] ?? [])) {
                $disposition = SemanticChangeDisposition::Blocked;
                $reason = 'Vertical recompile policy blocks this path.';
            } elseif ($this->matchesAny($path, $policy['requires_approval_paths'] ?? [])) {
                $disposition = SemanticChangeDisposition::RequiresApproval;
                $reason = 'Vertical recompile policy requires approval for this path.';
            } elseif ($path === 'vertical.id') {
                $disposition = SemanticChangeDisposition::RequiresApproval;
                $reason = 'Changing the business vertical requires explicit approval.';
            }
        }

        return new SemanticDiffEntry($path, $kind, $disposition, $before, $after, $reason);
    }

    /** @param list<string> $rules */
    private function matchesAny(string $path, array $rules): bool
    {
        foreach ($rules as $rule) {
            if ($path === $rule || str_starts_with($path, $rule . '.') || str_starts_with($rule, $path . '.')) {
                return true;
            }
        }
        return false;
    }
}
