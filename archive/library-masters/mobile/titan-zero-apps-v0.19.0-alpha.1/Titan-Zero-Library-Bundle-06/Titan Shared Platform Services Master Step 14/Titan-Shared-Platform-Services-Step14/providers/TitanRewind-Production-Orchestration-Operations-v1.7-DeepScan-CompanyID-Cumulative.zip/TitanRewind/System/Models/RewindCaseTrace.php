<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindCaseTrace extends Model
{
    protected $table = 'titan_rewind_case_traces';
    public $timestamps = false;
    protected $fillable = ['tenant_company_id','case_id','trace_id','relationship_type','added_at'];
    protected $casts = ['tenant_company_id'=>'integer','case_id'=>'integer','added_at'=>'datetime'];
}
