<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\OutcomeObservation;
use App\Extensions\TitanAutonomy\System\Enums\LearningLabel;

final class LearningEventFactory
{
    public function make(
        CapabilityState $state,
        OutcomeObservation $observation,
        LearningLabel $label,
        ?int $userId,
        array $context,
        array $proposal,
        array $finalAction,
        array $outcome,
        float $confidence,
        array $learningScopes = ['user', 'business'],
    ): array {
        return [
            'tenant_company_id' => $state->tenantCompanyId,
            'user_id' => $userId,
            'capability' => $state->capability,
            'workflow_key' => $state->workflowKey,
            'risk' => $state->risk->value,
            'autonomy_level' => $state->currentLevel->key(),
            'context' => $context,
            'proposal' => $proposal,
            'user_response' => [
                'classification' => $observation->userResponse->value,
                'material_edit' => $observation->materialEdit,
            ],
            'final_action' => $finalAction,
            'outcome' => $outcome,
            'learning_label' => $label->value,
            'material_edit' => $observation->materialEdit,
            'success' => $label === LearningLabel::Correct,
            'reversed' => $observation->reversed,
            'confidence' => max(0.0, min(1.0, $confidence)),
            'learning_scopes' => array_values(array_unique($learningScopes)),
            'quality_signals' => [
                'action_selection' => $outcome['action_selection_quality'] ?? null,
                'context_resolution' => $outcome['context_resolution_quality'] ?? null,
                'field_prediction' => $outcome['field_prediction_quality'] ?? null,
                'timing' => $outcome['timing_quality'] ?? null,
                'authority_decision' => $outcome['authority_decision_quality'] ?? null,
                'content_output' => $outcome['content_output_quality'] ?? null,
            ],
        ];
    }
}
