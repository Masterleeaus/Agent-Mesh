<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\{ControlPlaneAuditSinkContract,ExecutionReceiptReconcilerContract,OperationsQueryContract};
use RuntimeException;

final class OperationsRecheckService
{
    public function __construct(
        private readonly OperationsQueryContract $query,
        private readonly ExecutionReceiptReconcilerContract $reconciler,
        private readonly ControlPlaneAuditSinkContract $audit,
        private readonly string $policyVersion,
    ) {}

    public function recheck(int $tenantCompanyId, int $userId, string $correlationId): array
    {
        $receipt = $this->query->receipt($tenantCompanyId, trim($correlationId));
        if ($receipt === null) throw new RuntimeException('EXECUTION_RECEIPT_NOT_FOUND');
        if (($receipt['observation_status'] ?? '') !== 'observing') throw new RuntimeException('EXECUTION_RECEIPT_NOT_OBSERVING');
        $maturesAt = isset($receipt['matures_at']) ? strtotime((string)$receipt['matures_at']) : false;
        if ($maturesAt === false || $maturesAt > time()) throw new RuntimeException('EXECUTION_RECEIPT_NOT_MATURED');
        $result = $this->reconciler->finalizeReceiptDue($tenantCompanyId, trim($correlationId));
        $this->audit->record([
            'tenant_company_id'=>$tenantCompanyId,
            'user_id'=>$userId,
            'event_type'=>'autonomy.operations.recheck',
            'capability'=>$receipt['capability']??null,
            'workflow_key'=>$receipt['workflow_key']??null,
            'correlation_id'=>$receipt['correlation_id']??null,
            'payload'=>['result'=>$result],
            'policy_version'=>$this->policyVersion,
        ]);
        return $result;
    }
}
