<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Models\SignalCausalEdge;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use Illuminate\Support\Facades\Schema;

final class CausalEdgeProjector
{
    public function projectForEvent(SignalEvent $event): void
    {
        if (! Schema::hasTable('titan_signal_causal_edges')) {
            return;
        }

        if ($event->causation_id !== null) {
            /** @var SignalEvent|null $parent */
            $parent = SignalEvent::query()->where('event_id', $event->causation_id)->first();
            if ($parent !== null) {
                $this->persist($parent, $event);
            }
        }

        $chunk = function_exists('config') ? (int) config('titan-signal-engine.causation_repair_chunk', 500) : 500;
        SignalEvent::query()->where('causation_id', $event->event_id)->orderBy('id')->chunkById(max(50, min($chunk, 2000)), function ($children) use ($event): void {
            foreach ($children as $child) {
                $this->persist($event, $child);
            }
        });
    }

    private function persist(SignalEvent $parent, SignalEvent $child): void
    {
        SignalCausalEdge::query()->updateOrCreate(
            ['child_event_id' => (string) $child->event_id],
            [
                'parent_event_id' => (string) $parent->event_id,
                'scope' => (string) $child->scope,
                'tenant_company_id' => $child->tenant_company_id,
                'trace_id' => (string) $child->trace_id,
                'correlation_id' => (string) $child->correlation_id,
                'root_causation_id' => (string) $child->root_causation_id,
            ],
        );
    }
}
