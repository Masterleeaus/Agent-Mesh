<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Contracts\TagRepositoryContract; use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class TagController extends Controller { public function __construct(private TagRepositoryContract $tags, private \App\Extensions\Crm\System\Governance\CrmHumanMutationGateway $mutations){} public function index(Request $r){return response()->json(['data'=>$this->tags->search((int)$r->user()->id,$r->only(['q']))]);} public function store(Request $r){$d=$r->validate(['name'=>'required|string|max:80','color'=>'nullable|string|max:30']);return response()->json($this->mutations->execute($r,'crm.tag.create',$d),201);} public function attach(Request $r,string $tag){$d=$r->validate(['subject_type'=>'required|string|max:60','subject_public_id'=>'required|string|size:26']);$record=$this->mutations->execute($r,'crm.tag.attach',['public_id'=>$tag]+$d);return response()->json($record);} }
