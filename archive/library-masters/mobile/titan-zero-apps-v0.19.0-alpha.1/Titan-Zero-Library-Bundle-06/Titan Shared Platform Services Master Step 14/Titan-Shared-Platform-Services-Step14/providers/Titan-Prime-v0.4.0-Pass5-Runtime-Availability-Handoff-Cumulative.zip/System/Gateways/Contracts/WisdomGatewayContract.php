<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Contracts;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;

interface WisdomGatewayContract extends EngineGatewayContract
{
    /** @param array<string,mixed> $subject */
    public function recordOutcome(TraceContext $trace, array $subject, string $operationId): EngineGatewayResult;
}
