<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;

final class ConsoleBoundaryTest extends TestCase
{
    public function test_console_controllers_do_not_write_signal_tables_directly(): void
    {
        $controller = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Http/Controllers/AdminController.php');
        self::assertStringNotContainsString('DB::table(', $controller);
        self::assertStringNotContainsString('SignalEvent::query()', $controller);
        self::assertStringContainsString('SignalLifecycleContract', $controller);
        self::assertStringContainsString('SignalAnomalyContract', $controller);
    }

    public function test_console_service_does_not_query_raw_signal_event_store_for_dashboards(): void
    {
        $service = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/SignalConsoleService.php');
        self::assertStringNotContainsString('titan_signal_events', $service);
        self::assertStringNotContainsString('SignalEvent::query()', $service);
        self::assertStringContainsString('SignalPulseContract', $service);
        self::assertStringContainsString('SignalCorrelationContract', $service);
    }

    public function test_tenant_dashboard_omits_global_operational_internals(): void
    {
        $service = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/SignalConsoleService.php');
        self::assertStringContainsString('$administrative ? $this->manager->health($context)', $service);
        self::assertStringContainsString('$administrative ? $this->subscriberHealth($request) : []', $service);
    }
}
