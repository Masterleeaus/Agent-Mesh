<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

final class BoundaryTest extends TestCase
{
    public function test_runtime_has_no_external_http_shell_or_wildcard_eloquent_capture(): void
    {
        $root = dirname(__DIR__,2); $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/System')); $code='';
        foreach ($iterator as $file) if ($file->isFile() && $file->getExtension()==='php') $code .= (string) file_get_contents($file->getPathname());
        foreach (['Http::','curl_' . 'exec(','shell_' . 'exec(','exec(','eloquent.created: *','eloquent.updated: *','Modules\\\\TitanRewind'] as $forbidden) self::assertStringNotContainsString($forbidden,$code);
        self::assertStringNotContainsString('allow_authoritative_mutation = true',$code);
    }

    public function test_manifest_advertises_only_implemented_product_core_capabilities(): void
    {
        $root=dirname(__DIR__,2); $manifest=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
        self::assertSame('0.7.0',$manifest['version']);
        self::assertContains('rewind.timeline',$manifest['capabilities']); self::assertContains('rewind.reconstruct',$manifest['capabilities']); self::assertContains('rewind.replay.dry_run',$manifest['capabilities']); self::assertContains('rewind.integrity',$manifest['capabilities']); self::assertContains('rewind.drift',$manifest['capabilities']); self::assertContains('rewind.root_cause',$manifest['capabilities']);
        self::assertContains('rewind.compare',$manifest['capabilities']); self::assertContains('rewind.audit',$manifest['capabilities']); self::assertContains('rewind.recovery.plan',$manifest['capabilities']); self::assertContains('rewind.governance.handoff',$manifest['capabilities']);
        self::assertTrue($manifest['queues']['used']); self::assertSame(['titan-rewind-replay'],$manifest['queues']['queue_names']);
    }
}
