# Titan Signal Engine v0.16.0 — Production Hardening Pass 8

## Automatic Trace Evaluation & Sequence Detection

This pass removes the previous dependency on explicit trace-explorer/profile queries for sequence evaluation.

### Added

- active profile auto-matching by event type
- durable `titan_signal_trace_assignments`
- automatic post-ingestion profile observation/evaluation
- scheduled due-trace reevaluation
- terminal trace evaluation
- late/offline event reopening and repair
- evaluation freshness/history metadata
- automatic missing-required-event anomalies after terminal observation
- automatic sequence/missing-required anomaly resolution on repair
- evaluation health counters
- host integration test for terminal-first / late-parent repair

### Safety

Automatic evaluation is outside the immutable event transaction. Failure to evaluate cannot roll back a valid Signal event. Partial/corrupt cold history never becomes a complete evaluation.
