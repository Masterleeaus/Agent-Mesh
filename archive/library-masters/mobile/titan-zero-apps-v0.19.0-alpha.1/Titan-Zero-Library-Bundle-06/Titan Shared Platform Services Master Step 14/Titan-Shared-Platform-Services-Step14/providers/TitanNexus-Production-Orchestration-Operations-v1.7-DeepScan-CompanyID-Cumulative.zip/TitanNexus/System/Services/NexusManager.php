<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Services;

use App\Extensions\TitanNexus\System\Contracts\CompilationLifecycleRepositoryContract;
use App\Extensions\TitanNexus\System\Contracts\CompilationRepositoryContract;
use App\Extensions\TitanNexus\System\Contracts\ConfigurationDifferContract;
use App\Extensions\TitanNexus\System\Contracts\NexusCompilerContract;
use App\Extensions\TitanNexus\System\Contracts\NexusManagerContract;
use App\Extensions\TitanNexus\System\Contracts\NexusValidatorContract;
use App\Extensions\TitanNexus\System\Contracts\ProvisioningExecutorContract;
use App\Extensions\TitanNexus\System\Contracts\ProvisioningPlannerContract;
use App\Extensions\TitanNexus\System\Contracts\VerticalDefinitionSourceContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompilationLifecycleEvent;
use App\Extensions\TitanNexus\System\Domain\CompilationLifecycleStage;
use App\Extensions\TitanNexus\System\Domain\CompilationPreview;
use App\Extensions\TitanNexus\System\Domain\CompilationStatus;
use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\RecompilePlan;
use App\Extensions\TitanNexus\System\Domain\RuntimeReadinessReport;
use App\Extensions\TitanNexus\System\Domain\ValidationResult;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Exceptions\NexusValidationException;
use LogicException;

final class NexusManager implements NexusManagerContract
{
    public const VERSION = '1.0.0-rc.2';

    private readonly ConfigurationDifferContract $differ;
    private readonly ?ProvisioningPlannerContract $provisioningPlanner;

    public function __construct(
        private readonly NexusCompilerContract $compiler,
        private readonly VerticalDefinitionSourceContract $verticalDefinitions,
        private readonly NexusValidatorContract $validator,
        ?ConfigurationDifferContract $differ = null,
        ?ProvisioningPlannerContract $provisioningPlanner = null,
        private readonly ?ProvisioningExecutorContract $provisioningExecutor = null,
        private readonly ?CompilationRepositoryContract $repository = null,
        private readonly array $dependencyReadiness = [],
        private readonly bool $enabled = true,
        private readonly ?CompilationLifecycleRepositoryContract $lifecycle = null,
        private readonly array $declaredCapabilities = [],
    ) {
        $this->differ = $differ ?? new SemanticConfigurationDiffer();
        $this->provisioningPlanner = $provisioningPlanner;
    }

    public function health(): array
    {
        $dependencies = $this->dependencyReadiness;
        $dependencies += [
            'database' => $this->repository !== null,
            'vertical_engine' => true,
            'command_bus' => $this->provisioningExecutor !== null,
            'risk' => $this->provisioningExecutor !== null,
            'governance' => $this->provisioningExecutor !== null,
            'assurance' => $this->provisioningExecutor !== null,
            'signal' => $this->provisioningExecutor !== null,
            'rewind' => $this->provisioningExecutor !== null,
            'autonomy' => false,
            'knowledge_authority' => false,
            'interface_runtime' => false,
        ];

        $readiness = RuntimeReadinessReport::fromDependencies(
            $dependencies,
            $this->enabled,
            $this->declaredCapabilities,
        )->toArray();

        return [
            'engine' => 'titan-nexus',
            'status' => $readiness['status'],
            'version' => self::VERSION,
            'compiler_version' => $this->compiler->version(),
            'dependencies' => $readiness['dependencies'],
            'missing_dependencies' => $readiness['missing_required_dependencies'],
            'unavailable_dependencies' => $readiness['unavailable_dependencies'],
            'execution_modes' => $readiness['execution_modes'],
            'available_capabilities' => $readiness['available_capabilities'],
            'unavailable_capabilities' => $readiness['unavailable_capabilities'],
            'capability_readiness' => $readiness['capability_readiness'],
        ];
    }

    public function newDraft(BusinessProfile $profile, TraceContext $traceContext, string $compilationUuid): NexusCompilation
    {
        $draft = $this->persist(NexusCompilation::draft($profile, $traceContext, $compilationUuid, $this->compiler->version()));
        $this->recordLifecycle($draft, CompilationLifecycleStage::DraftCreated, [
            'business_profile_hash' => $profile->fingerprint(),
            'profile_version' => $profile->profileVersion(),
            'vertical_id' => $profile->verticalId(),
            'vertical_version' => $profile->verticalVersion(),
        ]);
        return $draft;
    }

    public function validateDraft(NexusCompilation $draft): ValidationResult
    {
        [, $validation] = $this->resolveAndValidate($draft);
        $this->recordValidation($draft, $validation);
        return $validation;
    }

    public function previewDraft(NexusCompilation $draft, string $configurationVersion = '1'): CompilationPreview
    {
        [$definition, $validation] = $this->resolveAndValidate($draft);
        $configuration = null;
        if (!$validation->hasErrors()) {
            $configuration = $this->compiler->compile($draft->businessProfile(), $definition, $configurationVersion);
        }

        return new CompilationPreview(
            $draft,
            $configurationVersion,
            $definition->fingerprint(),
            $validation,
            $configuration,
        );
    }

    public function compileDraft(NexusCompilation $draft, string $configurationVersion = '1'): NexusCompilation
    {
        [$definition, $validation] = $this->resolveAndValidate($draft);
        if ($validation->hasErrors()) {
            $failed = $this->persist($draft->withFailedValidation($validation));
            $this->recordValidation($failed, $validation);
            throw new NexusValidationException($validation);
        }

        $configuration = $this->compiler->compile($draft->businessProfile(), $definition, $configurationVersion);
        $compiled = $this->persist($draft
            ->withValidationResult($validation)
            ->withCompiledConfiguration($configuration));
        $this->recordValidation($compiled, $validation);
        $this->recordLifecycle($compiled, CompilationLifecycleStage::Compiled, [
            'configuration_version' => $configuration->configurationVersion(),
            'output_hash' => $configuration->outputHash(),
            'vertical_definition_hash' => $definition->fingerprint(),
        ]);
        return $compiled;
    }


    public function planProvisioning(NexusCompilation $compiled): NexusCompilation
    {
        $configuration = $compiled->compiledConfiguration();
        if ($compiled->status() !== CompilationStatus::Compiled || $configuration === null) {
            throw new LogicException('Provisioning planning requires a compiled Nexus configuration.');
        }
        $definition = $this->verticalDefinitions->resolve($compiled->businessProfile());
        if ($configuration->sourceVerticalHash() !== null && !hash_equals($configuration->sourceVerticalHash(), $definition->fingerprint())) {
            throw new LogicException('Provisioning planning requires the exact VerticalDefinition that produced the compiled configuration.');
        }
        if ($this->provisioningPlanner === null) {
            throw new LogicException('Titan Nexus provisioning planner is not configured.');
        }
        $planned = $this->persist($compiled->withProvisioningPlan($this->provisioningPlanner->plan($compiled, $definition)));
        $this->recordLifecycle($planned, CompilationLifecycleStage::ProvisioningPlanned, [
            'provisioning_plan' => $planned->provisioningPlan()?->toArray(),
        ]);
        return $planned;
    }

    public function executeProvisioning(
        NexusCompilation $compiled,
        TraceContext $traceContext,
        bool $approvalGranted = false,
        ?ProvisioningExecutionContext $executionContext = null,
    ): NexusCompilation {
        $plan = $compiled->provisioningPlan();
        if ($plan === null) {
            throw new LogicException('Provisioning execution requires an attached provisioning plan.');
        }
        if ($this->provisioningExecutor === null) {
            throw new LogicException('Titan Nexus provisioning executor is not configured.');
        }
        if ($traceContext->tenantCompanyId() !== $compiled->businessProfile()->tenantCompanyId()) {
            throw new \InvalidArgumentException('Provisioning action trace must belong to the compilation tenant.');
        }
        $executed = $this->persist($compiled->withProvisioningPlan(
            $this->provisioningExecutor->execute($plan, $traceContext, $approvalGranted, $executionContext),
        ));
        $executedPlan = $executed->provisioningPlan();
        $this->recordLifecycle($executed, CompilationLifecycleStage::ProvisioningExecuted, [
            'plan_status' => $executedPlan?->status()->value,
            'plan_fingerprint' => $executedPlan?->fingerprint(),
            'receipts' => $executedPlan === null ? [] : array_map(static fn ($receipt): array => $receipt->toArray(), $executedPlan->receipts()),
        ], $traceContext);
        return $executed;
    }

    public function planRecompile(
        NexusCompilation $current,
        BusinessProfile $updatedProfile,
        TraceContext $traceContext,
        string $compilationUuid,
        string $configurationVersion,
    ): RecompilePlan {
        $currentConfig = $current->compiledConfiguration();
        if ($current->status() !== CompilationStatus::Compiled || $currentConfig === null) {
            throw new LogicException('Recompile planning requires a compiled current configuration.');
        }
        $tenant = $current->businessProfile()->tenantCompanyId();
        if ($updatedProfile->tenantCompanyId() !== $tenant || $traceContext->tenantCompanyId() !== $tenant) {
            throw new \InvalidArgumentException('Recompile profile, trace context, and current compilation must belong to the same tenant.');
        }
        if ($compilationUuid === $current->compilationUuid()) {
            throw new \InvalidArgumentException('Recompile child UUID must differ from the parent compilation UUID.');
        }

        $candidate = NexusCompilation::draft(
            $updatedProfile,
            $traceContext,
            $compilationUuid,
            $this->compiler->version(),
            $current->compilationUuid(),
            true,
        );

        [$definition, $validation] = $this->resolveAndValidate($candidate);
        $candidate = $candidate->withValidationResult($validation);
        if ($validation->hasErrors()) {
            $candidate = $this->persist($candidate->withFailedValidation($validation));
            $this->recordValidation($candidate, $validation);
            $plan = new RecompilePlan($current->compilationUuid(), $currentConfig->outputHash(), $candidate, null);
            $this->recordLifecycle($candidate, CompilationLifecycleStage::RecompilePlanned, ['recompile_plan' => $plan->toArray()]);
            return $plan;
        }

        $proposed = $this->compiler->compile($updatedProfile, $definition, $configurationVersion);
        $diff = $this->differ->diff($currentConfig, $proposed, $definition);
        $candidate = $candidate
            ->withCompiledConfiguration($proposed)
            ->withConfigurationDiff($diff);

        $candidate = $this->persist($candidate);
        $this->recordValidation($candidate, $validation);
        $this->recordLifecycle($candidate, CompilationLifecycleStage::Compiled, [
            'configuration_version' => $proposed->configurationVersion(),
            'output_hash' => $proposed->outputHash(),
            'vertical_definition_hash' => $definition->fingerprint(),
        ]);
        $this->recordLifecycle($candidate, CompilationLifecycleStage::DiffCalculated, ['diff' => $diff->toArray()]);
        $plan = new RecompilePlan($current->compilationUuid(), $currentConfig->outputHash(), $candidate, $diff);
        $this->recordLifecycle($candidate, CompilationLifecycleStage::RecompilePlanned, ['recompile_plan' => $plan->toArray()]);
        return $plan;
    }


    private function recordValidation(NexusCompilation $compilation, ValidationResult $validation): void
    {
        $this->recordLifecycle(
            $compilation,
            $validation->hasErrors() ? CompilationLifecycleStage::ValidationFailed : CompilationLifecycleStage::ValidationCompleted,
            ['validation_result' => $validation->toContractArray()],
        );
    }

    /** @param array<string,mixed> $payload */
    private function recordLifecycle(NexusCompilation $compilation, CompilationLifecycleStage $stage, array $payload, ?TraceContext $traceContext = null): void
    {
        if ($this->lifecycle === null) { return; }
        $this->lifecycle->record(CompilationLifecycleEvent::create($compilation, $stage, $payload, $traceContext));
    }

    private function persist(NexusCompilation $compilation): NexusCompilation
    {
        return $this->repository === null ? $compilation : $this->repository->save($compilation);
    }

    /** @return array{0:VerticalDefinition,1:ValidationResult} */
    private function resolveAndValidate(NexusCompilation $draft): array
    {
        $this->assertCompilableDraft($draft);
        $profile = $draft->businessProfile();
        $definition = $this->verticalDefinitions->resolve($profile);
        $validation = $this->validator->validate($profile, $definition);
        return [$definition, $validation];
    }

    private function assertCompilableDraft(NexusCompilation $draft): void
    {
        if ($draft->status() !== CompilationStatus::Draft) {
            throw new LogicException('Only draft compilations can be validated, previewed, or compiled.');
        }
        if ($draft->compilerVersion() !== $this->compiler->version()) {
            throw new LogicException('Draft compiler version does not match the active Nexus compiler.');
        }
    }
}
