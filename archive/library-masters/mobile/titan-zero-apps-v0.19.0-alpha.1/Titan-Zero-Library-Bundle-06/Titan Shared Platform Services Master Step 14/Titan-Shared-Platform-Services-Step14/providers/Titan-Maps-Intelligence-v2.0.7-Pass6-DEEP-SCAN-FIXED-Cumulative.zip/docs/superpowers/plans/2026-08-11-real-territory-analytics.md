# Real Territory Analytics Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Replace generic territory analysis with six distinct evidence-backed geographic analytics engines and graphical result surfaces.

**Architecture:** A deterministic grid/evidence layer feeds six small analyzers. `TerritoryAnalyticsManager` gathers company-scoped Maps evidence, invokes the selected analyzer, persists methodology/version plus cell results, and exposes browser/API/AI read/run surfaces. Existing `territory_analyses` remains the run record for upgrade compatibility.

**Tech Stack:** PHP 8.3, Laravel 10, Eloquent/MySQL, existing Titan graphical map engine, existing Travel Matrix/route evidence.

## Global Constraints
- Root installer manifest remains `schema: titan-extension-v1`.
- Company/tenant scope is mandatory for every persisted analysis and cell.
- Maps must not invent demand, ETA, road distance, supplier access, or branch evidence.
- Density metrics must include an explicit km² denominator.
- Distinct analysis types must use distinct analyzer classes/formulas.
- Existing alpha.14 installer/provider/menu/security fixes must remain intact.

---

### Task 1: Shared grid and pure analyzers
**Files:** Create `Services/TerritoryAnalytics/*Analyzer.php`, `Services/TerritoryGridBuilder.php`; Test `scripts/test_real_territory_analytics_runtime.php`.
- [x] Write runtime tests for six methodologically distinct outputs.
- [x] Run and confirm RED due to missing classes.
- [x] Implement grid builder and analyzers.
- [x] Run and confirm GREEN.

### Task 2: Persistence and orchestration
**Files:** Modify `territory_analyses`; create `territory_analysis_cells`; create `Models/TerritoryAnalysisCell.php`, `Services/TerritoryAnalyticsManager.php`.
- [x] Write architecture verifier for schema/methodology/evidence invariants.
- [x] Run RED.
- [x] Add forward-safe migrations/models/manager.
- [x] Run schema verifier and runtime gates.

### Task 3: Browser/API/AI surfaces
**Files:** Create `TerritoryAnalyticsController`, tools; modify routes, navigation controller/view, capability service, menu definition.
- [x] Add failing route/menu/capability checks.
- [x] Add run/read endpoints and dedicated Branch Coverage / Expansion Opportunities pages.
- [x] Add graphical analytics payload and methodology/result tables.
- [x] Add menu-sync migration.

### Task 4: Configuration and release hardening
**Files:** Modify config, `MapsConfiguration`, manifests, README/CHANGELOG/BUILD_REPORT, master plan.
- [x] Validate grid/cell/expansion weights and limits fail closed.
- [x] Run all inherited verifiers/runtime tests.
- [x] Stage exact `TitanMapsIntelligence/` folder, regenerate hashes, ZIP, re-extract, and rerun full certification.
