# Donor Conversion Map

The original donor is preserved by explicit disposition. Runtime code is adapted in place; unsafe host mutations are archived as evidence.

| Subsystem | Disposition | Rationale |
|---|---|---|
| `.env.example` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `.gitignore` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `AI` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `API` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Actions` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Audit` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Automation` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Bootstrap` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Broadcasting` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `CHANGELOG.md` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Console` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Contracts` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `DataTables` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Database` | `migrate` | Legacy migrations archived; canonical extension-owned migrations replace host-mutating history. |
| `Deployment` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Docs` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Entities` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Events` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Exports` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Filament` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `GraphQL` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Http` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Integrations` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Jobs` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `LICENSE` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Listeners` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Models` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Monitoring` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Notifications` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Observers` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `PASS-01-REPORT.md` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `PAYROLL_DEEP_FIX_PASS46.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `PAYROLL_DEEP_FIX_PASS48.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `PAYROLL_FIX_PASS44.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `PAYROLL_FIX_PASS45.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `PAYROLL_MODULE_RESTORE_PASS36.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `PAYROLL_SQLITE_FIX_PASS47.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `Permissions` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Policies` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Providers` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Registry` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Repositories` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Resources` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `SCAFFOLD_REPORT.md` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Security` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Services` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Storage` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Support` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `System` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Temp` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `Tests` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `UPGRADE_PASS_1_REPORT.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `UPGRADE_PASS_2_REPORT.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `UPGRADE_PASS_4_REPORT.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `UPGRADE_PASS_5_REPORT.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `UPGRADE_PASS_6_REPORT.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `UPGRADE_PASS_7_REPORT.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `UPGRADE_PASS_9_REPORT.md` | `migrate` | Historical donor/provenance artifact; not runtime authority. |
| `Workflows` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `composer.json` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `config` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `contracts` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `database` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `docs` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `extension.json` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `extension.manifest.json` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `manifests` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `resources` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `routes` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `schemas` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `tests` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
| `version.txt` | `adapt` | Preserve mature donor behavior while replacing Worksuite host coupling with Titan contracts. |
