<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

/**
 * Port implemented by Titan Command Bus integration. CRM owns domain execution,
 * while the external implementation owns risk/assurance/autonomy/governance gates.
 */
interface CrmCommandBusPort
{
    public function available(): bool;

    /** @return array<string,mixed> */
    public function dispatch(CrmCommandRequest $request): array;
}
