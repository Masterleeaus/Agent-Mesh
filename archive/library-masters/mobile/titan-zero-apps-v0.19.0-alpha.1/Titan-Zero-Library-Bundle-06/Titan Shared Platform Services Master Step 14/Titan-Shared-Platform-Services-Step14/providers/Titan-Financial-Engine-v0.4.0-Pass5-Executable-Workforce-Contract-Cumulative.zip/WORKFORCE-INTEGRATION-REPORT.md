# Workforce Integration Report

## Scope

Deep-scan migration for **titan-financial-engine 0.4.0** against the Titan Extension Blueprint v4.2.1 / Workforce handoff contract.

## Ownership result

- Canonical tenant boundary: `company_id`.
- Titan AI Workforce remains the only owner of employee identity, organisational role identity, hierarchy, teams, responsibilities, assignments, work items and orchestration.
- Extension domain ownership: authoritative for deterministic pricing calculations, price books, rate cards, margin policies and quote snapshots; not accounting ledger authority.
- Installed capability/provider presence does **not** grant authority.

## Published Workforce surfaces

- Capabilities: 7.
- Non-mutating reads: 7.
- Governed commands: 10.
- Signals: 5.
- Work types: 4.
- Availability states: available, degraded, unavailable, missing_provider, blocked, policy_disabled.

Machine-readable contract: `workforce-integration.json`. Runtime helper: `System/Workforce/WorkforceIntegrationContract.php`.

## Authority and execution

Consequential commands are declared as governed execution surfaces. Workforce orchestration must not call extension UI routes or internal services as an authority shortcut. Reads remain non-mutating. The contract is fail-closed and keeps provider availability separate from authorization, governance, risk and autonomy.

## Compatibility / deep-scan notes

- Calculation/simulation reads are non-mutating.
- Existing direct HTTP mutation routes are legacy/UI surfaces and are not Workforce execution authority; Workforce must submit declared commands through Titan Command Bus.

## Verification added

Run `php tests/Standalone/WorkforceIntegrationContractTest.php`. The test validates canonical tenancy, authority-neutral discovery, read/command separation, fail-closed availability states and positive `company_id` validation.

## Next upgrade — data-access and execution hardening

- Added explicit safety bounds to previously unbounded production read materialization paths where applicable; historical migrations remain frozen.
- Preserved `company_id` as the Workforce-facing tenant boundary and did not expand authority.
- Re-ran Blueprint architecture analysis to distinguish domain code from legitimate infrastructure persistence.

## Pass 5 — Executable Workforce Discovery Contract

- Workforce integration contract upgraded to 1.1 without changing the extension's domain ownership.
- Explicit non-mutating `tools` and `data_sources` are now published for every read surface.
- Every executable command is pinned to provider + provider version and requires canonical `company_id`, causal trace context and an idempotency key.
- Mutations explicitly require governed evidence and an execution receipt, and fail closed when the execution provider is missing or degraded.
- Work types now declare provider pinning and fail-closed unavailability behavior; provider removal cannot mutate Workforce identity.
- Executable contract tests reject unknown commands and incomplete execution context.

