# Titan Nexus Governed Provisioning Plan, Idempotency & Execution Boundary — Design

## Goal

Add a deterministic governed provisioning layer that converts a compiled Nexus candidate into ordered, idempotent Command Bus operations and can execute them only through a configured public gateway. Nexus must never write another engine's tables directly.

## Architecture

`VerticalDefinition` gains optional `provisioning` metadata. It defines path-prefix routes from compiled configuration sections to public mutation capabilities and optional route dependencies. The metadata is normalized and omitted when absent so all previous VerticalDefinition fingerprints remain stable.

`DeterministicProvisioningPlanner` consumes a compiled `NexusCompilation`, its exact `VerticalDefinition`, and either its existing semantic diff or an initial-install synthetic change set. Every non-unchanged semantic change becomes a `ProvisioningOperation` with a deterministic idempotency key derived from tenant, compilation, proposed output hash, path, structural change kind, capability and desired value. Missing or ambiguous route coverage blocks the plan.

Execution is isolated behind `ProvisioningCommandGatewayContract`. `CommandBusProvisioningAdapter` is configuration-driven and contains no direct imports from Command Bus or owning engine implementations. It sends a canonical request that explicitly requires pre-write backup capture and verification, write verification, audit evidence, and rollback metadata. Applied receipts are rejected unless those safety proofs are present.

`GovernedProvisioningExecutor` executes a plan in deterministic dependency order. It refuses blocked plans, refuses approval-required plans until approval is explicitly granted, converts gateway exceptions into failed receipts, skips operations whose dependencies failed, and continues independent operations. The returned immutable plan records receipts and resolves to `applied`, `partially_applied`, or `failed`.

## Provisioning Metadata

A vertical may publish:

```php
'provisioning' => [
    'routes' => [
        'sections.crm' => [
            'capability' => 'crm.configuration.apply',
            'depends_on' => [],
        ],
        'sections.workforce' => [
            'capability' => 'workforce.configuration.apply',
            'depends_on' => ['sections.crm'],
        ],
    ],
],
```

Routes use exact or nearest-ancestor prefix matching. A changed path without an owning route is blocked. Route dependency paths must name configured routes and cycles are rejected when the definition is constructed.

## Mutation Safety Contract

Every executable operation carries `backup_required=true`. The adapter sends:

```text
capture_backup_before_write = true
verify_backup_before_write = true
verify_write_after = true
audit_operation = true
preserve_rollback_metadata = true
```

A gateway response with status `applied` is valid only when it includes a non-empty backup reference, `backup_verified=true`, `write_verified=true`, a non-empty audit reference, and non-empty rollback reference. `already_applied` is valid without creating a new backup because no new mutation occurred, but it must match the exact idempotency key.

## Idempotency

Idempotency keys are deterministic SHA-256 values over canonical operation identity and desired state. Re-running the same plan produces identical operation IDs/idempotency keys. A changed desired value produces a different key. The gateway receives the key and is responsible for durable duplicate suppression at the authoritative mutation boundary.

## Persistence

`NexusCompilation` gains an optional `ProvisioningPlan`, persisted through the existing `provisioning_plan` JSON column. No existing migration is changed and no new schema migration is required.

## Scope Boundaries

Pass 5 may call a configured public Command Bus gateway but must not import or instantiate another Titan engine implementation class, write foreign tables, emit Signals, make Risk decisions, assign Autonomy, or implement rollback execution itself. Risk/Governance/Signal/Rewind integration belongs to Pass 6; Pass 5 only preserves the evidence fields those engines need.

## Testing

Standalone and PHPUnit-compatible tests must prove deterministic operation/idempotency keys, initial and recompile planning, route coverage blocking, dependency ordering/cycle rejection, approval gating, backup proof enforcement, duplicate/already-applied handling, partial failure with dependent skips, persistence round-trip, manifest truthfulness, production-boundary safety, PHP lint, JSON parsing, archive safety, and clean re-extraction verification.
