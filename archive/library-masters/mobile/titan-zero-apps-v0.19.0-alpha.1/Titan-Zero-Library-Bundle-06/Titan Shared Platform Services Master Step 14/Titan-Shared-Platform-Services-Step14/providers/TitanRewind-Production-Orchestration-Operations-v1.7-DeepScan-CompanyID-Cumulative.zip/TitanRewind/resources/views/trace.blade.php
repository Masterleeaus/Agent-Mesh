@extends('panel.layout.app')
@section('title', 'Titan Rewind — Trace')

@section('content')
    <a href="#titan-rewind-content" class="sr-only focus:not-sr-only">{{ __('titan-rewind::rewind.accessibility_skip') }}</a>
    <main id="titan-rewind-content" role="main" class="container py-8 space-y-6">
        <div>
            <h1 class="text-2xl font-semibold">Rewind Trace</h1>
            <code>{{ $reconstruction['trace_id'] }}</code>
        </div>

        @if(session('rewind_status'))
            <div class="rounded border p-3" aria-live="polite">{{ session('rewind_status') }}</div>
        @endif

        <div class="grid gap-4 md:grid-cols-7">
            <div class="rounded border p-3"><strong>{{ $reconstruction['event_count'] }}</strong><div>Events</div></div>
            <div class="rounded border p-3"><strong>{{ count($reconstruction['source_engines']) }}</strong><div>Sources</div></div>
            <div class="rounded border p-3"><strong>{{ count($reconstruction['causation']['edges']) }}</strong><div>Causation links</div></div>
            <div class="rounded border p-3"><strong>{{ count($reconstruction['dependencies']) }}</strong><div>Dependencies</div></div>
            <div class="rounded border p-3"><strong>{{ $reconstruction['forensics']['integrity']['status'] }}</strong><div>Integrity</div></div>
            <div class="rounded border p-3"><strong>{{ $reconstruction['forensics']['status'] }}</strong><div>Forensic state</div></div>
            <div class="rounded border p-3"><strong>{{ $reconstruction['source_completeness']['state'] ?? 'PARTIAL' }}</strong><div>Source completeness</div></div>
        </div>

        <div class="flex flex-wrap gap-2">
            <form method="POST" action="{{ route('dashboard.user.titan.rewind.forensics.integrity', ['traceId'=>$reconstruction['trace_id']]) }}">@csrf<button type="submit" class="rounded border px-4 py-2">Verify integrity</button></form>
            <form method="POST" action="{{ route('dashboard.user.titan.rewind.forensics.drift', ['traceId'=>$reconstruction['trace_id']]) }}">@csrf<button type="submit" class="rounded border px-4 py-2">Scan forensic drift</button></form>
            <form method="POST" action="{{ route('dashboard.user.titan.rewind.replay.store', ['traceId'=>$reconstruction['trace_id']]) }}">@csrf<button type="submit" class="rounded border px-4 py-2">Run mutation-free replay</button></form>
        </div>

        <section class="rounded border p-4 space-y-4">
            <h2 class="text-lg font-semibold">Comparative / counterfactual replay</h2>
            <p class="text-sm opacity-70">These modes compare a sanitized structural projection only. They never mutate production and do not claim that a historical model or policy was actually re-executed.</p>
            <div class="grid gap-4 lg:grid-cols-2">
                <form method="POST" action="{{ route('dashboard.user.titan.rewind.replay.compare',['traceId'=>$reconstruction['trace_id']]) }}" class="rounded border p-3 space-y-2">
                    @csrf<input type="hidden" name="mode" value="current-state" aria-label="mode">
                    <strong>Current-state structural comparison</strong>
                    <input class="w-full rounded border px-2 py-1" name="current_state_event_id" placeholder="Historical event UUID" required aria-label="current state event id">
                    <textarea class="w-full rounded border px-2 py-1 font-mono text-xs" rows="4" name="current_state_override_json" placeholder='{"policy_version":"current-policy"}' required aria-label="current state override json"></textarea>
                    <button class="rounded border px-3 py-1">Compare current-state projection</button>
                </form>
                <form method="POST" action="{{ route('dashboard.user.titan.rewind.replay.compare',['traceId'=>$reconstruction['trace_id']]) }}" class="rounded border p-3 space-y-2">
                    @csrf<input type="hidden" name="mode" value="model-compare" aria-label="mode">
                    <strong>Model comparison</strong>
                    <input class="w-full rounded border px-2 py-1" name="target_model_provider" placeholder="Provider" aria-label="target model provider">
                    <input class="w-full rounded border px-2 py-1" name="target_model_name" placeholder="Model name" aria-label="target model name">
                    <input class="w-full rounded border px-2 py-1" name="target_model_version" placeholder="Version" required aria-label="target model version">
                    <button class="rounded border px-3 py-1">Compare model references</button>
                </form>
                <form method="POST" action="{{ route('dashboard.user.titan.rewind.replay.compare',['traceId'=>$reconstruction['trace_id']]) }}" class="rounded border p-3 space-y-2">
                    @csrf<input type="hidden" name="mode" value="policy-compare" aria-label="mode">
                    <strong>Policy comparison</strong>
                    <input class="w-full rounded border px-2 py-1" name="target_policy_version" placeholder="Target policy version" required aria-label="target policy version">
                    <button class="rounded border px-3 py-1">Compare policy references</button>
                </form>
                <form method="POST" action="{{ route('dashboard.user.titan.rewind.replay.compare',['traceId'=>$reconstruction['trace_id']]) }}" class="rounded border p-3 space-y-2">
                    @csrf<input type="hidden" name="mode" value="knowledge-compare" aria-label="mode">
                    <strong>Knowledge comparison</strong>
                    <input class="w-full rounded border px-2 py-1" name="target_knowledge_version" placeholder="Target knowledge version" required aria-label="target knowledge version">
                    <button class="rounded border px-3 py-1">Compare knowledge references</button>
                </form>
                <form method="POST" action="{{ route('dashboard.user.titan.rewind.replay.compare',['traceId'=>$reconstruction['trace_id']]) }}" class="rounded border p-3 space-y-2">
                    @csrf<input type="hidden" name="mode" value="counterfactual" aria-label="mode">
                    <strong>Counterfactual event projection</strong>
                    <input class="w-full rounded border px-2 py-1" name="counterfactual_event_id" placeholder="Historical event UUID" required aria-label="counterfactual event id">
                    <textarea class="w-full rounded border px-2 py-1 font-mono text-xs" rows="4" name="counterfactual_override_json" placeholder='{"risk_state":{"overall":"low"},"policy_version":"policy-v2"}' required aria-label="counterfactual override json"></textarea>
                    <button class="rounded border px-3 py-1">Run counterfactual diff</button>
                </form>
            </div>
            <a class="inline-block text-sm underline" href="{{ route('dashboard.user.titan.rewind.assistant.index') }}">Open Rewind guided assistant</a>
        </section>

        <section class="rounded border p-4 space-y-4">
            <h2 class="text-lg font-semibold">Evidence & governed recovery</h2>
            <div class="flex flex-wrap gap-2">
                <form method="POST" action="{{ route('dashboard.user.titan.rewind.evidence.store',['traceId'=>$reconstruction['trace_id']]) }}">@csrf<input type="hidden" name="package_type" value="audit" aria-label="package type"><button type="submit" class="rounded border px-4 py-2">Generate audit evidence</button></form>
                <form method="POST" action="{{ route('dashboard.user.titan.rewind.evidence.store',['traceId'=>$reconstruction['trace_id']]) }}">@csrf<input type="hidden" name="package_type" value="compliance" aria-label="package type"><button type="submit" class="rounded border px-4 py-2">Generate compliance bundle</button></form>
            </div>
            <details class="rounded border p-3">
                <summary class="cursor-pointer font-medium">Create governed recovery plan</summary>
                <form class="mt-3 space-y-3" method="POST" action="{{ route('dashboard.user.titan.rewind.recovery.store',['traceId'=>$reconstruction['trace_id']]) }}">
                    @csrf
                    <div><label class="block text-sm font-medium">Compensating capability</label><input class="w-full rounded border px-3 py-2" name="proposed_capability" placeholder="e.g. invoice.compensate" aria-label="proposed capability"></div>
                    <div><label class="block text-sm font-medium">Validated command input JSON</label><textarea class="w-full rounded border px-3 py-2 font-mono text-xs" rows="5" name="command_input_json" placeholder='{"invoice_id": 44}' aria-label="command input json"></textarea></div>
                    <p class="text-sm opacity-70">This creates a proposal only. Rewind does not execute the capability. Governance must authorize it and Titan Command Bus remains the execution owner.</p>
                    <button type="submit" class="rounded border px-4 py-2">Create recovery plan</button>
                </form>
            </details>
            @can('rewind.legal-hold.manage')
                <details class="rounded border p-3">
                    <summary class="cursor-pointer font-medium">Apply legal hold to this trace</summary>
                    <form class="mt-3 space-y-3" method="POST" action="{{ route('dashboard.user.titan.rewind.legal-holds.store') }}">
                        @csrf
                        <input type="hidden" name="scope_type" value="trace" aria-label="scope type">
                        <input type="hidden" name="scope_id" value="{{ $reconstruction['trace_id'] }}" aria-label="scope id">
                        <div><label class="block text-sm font-medium">Authority</label><input class="w-full rounded border px-3 py-2" name="authority" required aria-label="authority"></div>
                        <div><label class="block text-sm font-medium">Reason</label><textarea class="w-full rounded border px-3 py-2" name="reason" required aria-label="reason"></textarea></div>
                        <button type="submit" class="rounded border px-4 py-2">Apply legal hold</button>
                    </form>
                </details>
            @endcan
        </section>

        <section class="rounded border p-4 space-y-2">
            <h2 class="text-lg font-semibold">Temporal diagnostics</h2>
            <div class="grid gap-3 md:grid-cols-4 text-sm">
                <div><strong>{{ $reconstruction['forensics']['temporal']['late_event_count'] }}</strong><div>Late events</div></div>
                <div><strong>{{ $reconstruction['forensics']['temporal']['out_of_order_arrival_count'] }}</strong><div>Out-of-order arrivals</div></div>
                <div><strong>{{ $reconstruction['forensics']['temporal']['sequence_collision_count'] }}</strong><div>Sequence collisions</div></div>
                <div><strong>{{ $reconstruction['forensics']['temporal']['recorded_before_occurred_count'] }}</strong><div>Clock anomalies</div></div>
            </div>
        </section>

        <section class="rounded border p-4 space-y-2">
            <h2 class="text-lg font-semibold">Deterministic root-cause analysis</h2>
            @if($reconstruction['root_cause']['primary'])
                <div><strong>{{ $reconstruction['root_cause']['primary']['event_type'] }}</strong> · {{ $reconstruction['root_cause']['primary']['source_engine'] }}</div>
                <div class="text-sm"><code>{{ $reconstruction['root_cause']['primary']['event_id'] }}</code></div>
                <div class="text-sm">Upstream causation events: {{ count($reconstruction['root_cause']['primary']['upstream_event_ids']) }} · Recovery detected: {{ $reconstruction['root_cause']['recovery_detected'] ? 'yes' : 'no' }}</div>
            @else
                <p>No explicit failure event was identified in this trace.</p>
            @endif
        </section>

        @if($reconstruction['forensics']['open_drift_findings'])
            <section>
                <h2 class="text-lg font-semibold mb-3">Open forensic findings</h2>
                @foreach($reconstruction['forensics']['open_drift_findings'] as $finding)
                    <div class="rounded border p-3 mb-2">
                        <div><strong>{{ strtoupper($finding['severity']) }}</strong> · {{ $finding['finding_type'] }}</div>
                        <div>{{ $finding['summary'] }}</div>
                        @if(!empty($finding['remediation']['recommendation']))<div class="text-sm opacity-70 mt-1">{{ $finding['remediation']['recommendation'] }}</div>@endif
                    </div>
                @endforeach
            </section>
        @endif

        @if($reconstruction['snapshot_comparisons'])
            <section>
                <h2 class="text-lg font-semibold mb-3">Snapshot changes</h2>
                @foreach($reconstruction['snapshot_comparisons'] as $comparison)
                    <div class="rounded border p-3 mb-2">
                        <div><strong>{{ $comparison['entity_type'] }} {{ $comparison['entity_id'] }}</strong></div>
                        <div class="text-sm">Changes: {{ $comparison['diff']['count'] }} · Risk: {{ $comparison['diff']['risk'] }}</div>
                        @if($comparison['diff']['count'] > 0)<pre class="mt-2 overflow-x-auto text-xs">{{ json_encode($comparison['diff'], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre>@endif
                    </div>
                @endforeach
            </section>
        @endif

        <section>
            <h2 class="text-lg font-semibold mb-3">Deterministic timeline</h2>
            @forelse($reconstruction['events'] as $event)
                <div class="rounded border p-3 mb-2">
                    <div><strong>#{{ $event['sequence'] }}</strong> {{ $event['event_type'] }} · {{ $event['source_engine'] }}</div>
                    <div class="text-sm opacity-70">{{ $event['occurred_at'] }} @if($event['tier'] !== null) · Tier {{ $event['tier'] }} @endif @if($event['lane']) · {{ $event['lane'] }} @endif</div>
                    @if(is_array($event['rationale'] ?? null) && !empty($event['rationale']['summary']))<div class="mt-1">{{ $event['rationale']['summary'] }}</div>@endif
                </div>
            @empty
                <p>No events were found for this trace.</p>
            @endforelse
        </section>

        @if($reconstruction['causation']['orphans'])
            <section><h2 class="text-lg font-semibold">Missing causation parents</h2><pre>{{ json_encode($reconstruction['causation']['orphans'], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></section>
        @endif
    </main>
@endsection
