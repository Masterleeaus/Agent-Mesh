<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\GateEvaluation;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\HandshakeDecision;
use App\Extensions\TitanAutonomy\System\Enums\RiskClass;
use App\Extensions\TitanAutonomy\System\Services\LevelActivationService;

function expect(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}

$service = new LevelActivationService();
$base = new CapabilityState(7, 'crm.invoice.issue', 'completed_job_invoice', RiskClass::Medium, AutonomyLevel::Assist, 2, 2, 5, 12);
$gate = new GateEvaluation(true, 2, []);

$denied = $service->activate(
    state: $base,
    requestedLevel: AutonomyLevel::SemiAuto,
    gate: $gate,
    actorCanGrant: true,
    userDecision: HandshakeDecision::Denied,
    aiAssuranceDecision: HandshakeDecision::Approved,
    scope: ['workflow' => 'completed_job_invoice'],
);
expect(!$denied->approved, 'user denial must block next level');
expect($denied->state->currentLevel === AutonomyLevel::Assist, 'denial must preserve level');

$approved = $service->activate(
    state: $base,
    requestedLevel: AutonomyLevel::SemiAuto,
    gate: $gate,
    actorCanGrant: true,
    userDecision: HandshakeDecision::Approved,
    aiAssuranceDecision: HandshakeDecision::Approved,
    scope: ['workflow' => 'completed_job_invoice'],
);
expect($approved->approved, 'eligible explicit user grant must activate next non-trusted level');
expect($approved->state->currentLevel === AutonomyLevel::SemiAuto, 'approved activation must move exactly one level');
expect($approved->state->currentSuccessStreak === 0, 'new level must build fresh evidence');

$autoState = new CapabilityState(7, 'crm.invoice.issue', 'completed_job_invoice', RiskClass::Medium, AutonomyLevel::Auto, 2, 2, 8, 30);
$trustedDenied = $service->activate(
    state: $autoState,
    requestedLevel: AutonomyLevel::TrustedAuto,
    gate: $gate,
    actorCanGrant: true,
    userDecision: HandshakeDecision::Approved,
    aiAssuranceDecision: HandshakeDecision::Denied,
    scope: ['workflow' => 'completed_job_invoice', 'max_total' => 1500],
);
expect(!$trustedDenied->approved, 'AI/Assurance denial must block Trusted Auto');
expect(in_array('AI_ASSURANCE_DENIED', $trustedDenied->reasonCodes, true), 'Trusted Auto denial must preserve reason');

$trustedApproved = $service->activate(
    state: $autoState,
    requestedLevel: AutonomyLevel::TrustedAuto,
    gate: $gate,
    actorCanGrant: true,
    userDecision: HandshakeDecision::Approved,
    aiAssuranceDecision: HandshakeDecision::Approved,
    scope: ['workflow' => 'completed_job_invoice', 'max_total' => 1500],
);
expect($trustedApproved->approved, 'three approvals and bounded scope must activate Trusted Auto');
expect($trustedApproved->state->currentLevel === AutonomyLevel::TrustedAuto, 'Trusted Auto should activate after complete handshake');

$jump = $service->activate(
    state: $base,
    requestedLevel: AutonomyLevel::Auto,
    gate: $gate,
    actorCanGrant: true,
    userDecision: HandshakeDecision::Approved,
    aiAssuranceDecision: HandshakeDecision::Approved,
    scope: ['workflow' => 'completed_job_invoice'],
);
expect(!$jump->approved && in_array('INVALID_NEXT_LEVEL', $jump->reasonCodes, true), 'direct level jumps must be rejected');

echo "OK: LevelActivationSmokeTest\n";
