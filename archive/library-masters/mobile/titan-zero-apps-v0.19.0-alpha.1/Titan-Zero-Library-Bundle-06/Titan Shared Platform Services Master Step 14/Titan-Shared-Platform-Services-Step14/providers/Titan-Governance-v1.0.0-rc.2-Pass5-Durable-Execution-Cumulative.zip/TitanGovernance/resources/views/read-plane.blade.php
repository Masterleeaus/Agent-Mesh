@extends('panel.layout.app')

@section('content')
<div class="container-fluid py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <div><h1 class="h3 mb-1">{{ $title }}</h1><p class="text-muted mb-0">{{ $description }}</p></div>
        <a class="btn btn-outline-secondary" href="{{ route('dashboard.user.titan.governance.index') }}">Governance Overview</a>
    </div>
    <div class="card"><div class="card-body"><pre class="mb-0" style="white-space:pre-wrap">{{ json_encode($payload, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div></div>
</div>
@endsection
