<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use Illuminate\Contracts\Auth\Authenticatable;

final class RewindTenantContextResolver
{
    public function forUser(?Authenticatable $user): ?int
    {
        if ($user === null) {
            return null;
        }

        foreach (['tenantCompanyId', 'getTenantCompanyId'] as $method) {
            if (method_exists($user, $method)) {
                $value = $user->{$method}();
                if (is_numeric($value) && (int) $value > 0) {
                    return (int) $value;
                }
            }
        }

        $value = method_exists($user, 'getAttribute') ? $user->getAttribute('tenant_company_id') : null;
        return is_numeric($value) && (int) $value > 0 ? (int) $value : null;
    }
}
