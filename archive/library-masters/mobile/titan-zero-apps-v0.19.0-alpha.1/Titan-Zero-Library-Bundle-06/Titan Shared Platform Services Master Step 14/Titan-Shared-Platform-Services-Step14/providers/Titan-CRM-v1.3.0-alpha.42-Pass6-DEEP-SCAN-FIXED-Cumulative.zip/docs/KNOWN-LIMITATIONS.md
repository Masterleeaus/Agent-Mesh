# Titan CRM Core Known Limitations — alpha.27

- **Host runtime still requires staging verification.** Static package gates cannot prove the target Laravel container, database credentials, queue workers, scheduler, storage, backup/restore or production traffic behavior.
- **External-domain compatibility names remain.** 120 legacy governed capability names still identify Titan Field/Locker/Ledger/Pay owners. They are routing contracts only and will be retired after all consumers use native destination contracts.
- **Legacy extracted-domain tables may exist on upgraded installations.** Alpha.27 does not destructively remove old data. Destination-engine migration/retirement must be separately verified.
- **Legacy CRM autonomy/learning tables may exist on upgraded installations.** They remain migration evidence until destination import receipts/counts/checksums are verified.
- **Titan Connect provider delivery is deployment dependent.** CRM can queue outbound commercial communication; a real Connect/provider binding is required for delivery truth.
- **TitanAI provider discovery depends on the installed TitanAI runtime contract.** CRM exposes a governed provider, but target-host discovery/execution must be verified in integration testing.
- **CQRS live fallback may still be enabled in some deployments.** High-volume installations should disable OLTP fallback after projection reliability is proven.
- **Production scale is not certified yet.** Customer, pipeline, invoice, projection and import load budgets are scheduled for a later performance-certification pass.
