<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // MySQL DDL can survive a failed migration even when the migration row was
        // never recorded. Repair the exact tables that v0.10.1 could leave partial.
        $this->repairExternalThreadReads();
        $this->repairOutboundDeliveries();
        $this->repairExternalThreadTags();
    }

    public function down(): void
    {
        // This migration repairs constraints/indexes owned by earlier migrations.
        // Their down() methods remain the authoritative destructive rollback path.
    }

    private function repairExternalThreadReads(): void
    {
        $table = 'ext_titan_connect_external_thread_reads';
        if (! Schema::hasTable($table)) {
            return;
        }

        $this->ensureForeignKey($table, 'external_thread_id', 'ext_titan_connect_external_threads', 'tc_ext_reads_thread_fk', 'cascade');
        $this->ensureForeignKey($table, 'last_read_message_id', 'ext_titan_connect_external_messages', 'tc_ext_reads_last_msg_fk', 'set null');
        $this->ensureIndex($table, ['company_id'], false, 'tc_ext_reads_company_idx');
        $this->ensureIndex($table, ['user_id'], false, 'tc_ext_reads_user_idx');
        $this->ensureIndex($table, ['external_thread_id', 'user_id'], true, 'tc_external_thread_reads_unique');
        $this->ensureIndex($table, ['company_id', 'user_id', 'last_read_at'], false, 'tc_external_thread_reads_lookup_idx');
    }

    private function repairOutboundDeliveries(): void
    {
        $table = 'ext_titan_connect_outbound_deliveries';
        if (! Schema::hasTable($table)) {
            return;
        }

        $this->ensureForeignKey($table, 'external_message_id', 'ext_titan_connect_external_messages', 'tc_out_delivery_msg_fk', 'cascade');
        $this->ensureForeignKey($table, 'channel_connection_id', 'ext_titan_connect_channel_connections', 'tc_out_delivery_conn_fk', 'cascade');
        $this->ensureIndex($table, ['uuid'], true, 'tc_out_delivery_uuid_unique');
        $this->ensureIndex($table, ['company_id'], false, 'tc_out_delivery_company_idx');
        $this->ensureIndex($table, ['provider'], false, 'tc_out_delivery_provider_idx');
        $this->ensureIndex($table, ['correlation_id'], false, 'tc_out_delivery_corr_idx');
        $this->ensureIndex($table, ['provider_message_id'], false, 'tc_out_delivery_provider_msg_idx');
        $this->ensureIndex($table, ['status'], false, 'tc_out_delivery_status_idx');
        $this->ensureIndex($table, ['next_attempt_at'], false, 'tc_out_delivery_next_attempt_idx');
        $this->ensureIndex($table, ['company_id', 'idempotency_key'], true, 'tc_outbound_idempotency_unique');
    }

    private function repairExternalThreadTags(): void
    {
        $table = 'ext_titan_connect_external_thread_tags';
        if (! Schema::hasTable($table)) {
            return;
        }

        $this->ensureForeignKey($table, 'external_thread_id', 'ext_titan_connect_external_threads', 'tc_thread_tags_thread_fk', 'cascade');
        $this->ensureForeignKey($table, 'contact_tag_id', 'ext_titan_connect_contact_tags', 'tc_thread_tags_tag_fk', 'cascade');
        $this->ensureIndex($table, ['company_id'], false, 'tc_thread_tags_company_idx');
        $this->ensureIndex($table, ['external_thread_id', 'contact_tag_id'], true, 'tc_external_thread_tag_unique');
        $this->ensureIndex($table, ['company_id', 'external_thread_id'], false, 'tc_external_thread_tag_company_idx');
    }

    private function foreignKeyExists(string $table, string $column, string $referencedTable): bool
    {
        return DB::selectOne(
            'SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE '
            .'WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? '
            .'AND REFERENCED_TABLE_NAME = ? LIMIT 1',
            [$table, $column, $referencedTable],
        ) !== null;
    }

    /** @param list<string> $columns */
    private function indexExistsForColumns(string $table, array $columns, bool $unique): bool
    {
        $rows = DB::select(
            'SELECT INDEX_NAME, NON_UNIQUE, SEQ_IN_INDEX, COLUMN_NAME '
            .'FROM information_schema.STATISTICS '
            .'WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? '
            .'ORDER BY INDEX_NAME, SEQ_IN_INDEX',
            [$table],
        );

        $indexes = [];
        foreach ($rows as $row) {
            $name = (string) $row->INDEX_NAME;
            $indexes[$name]['unique'] = ((int) $row->NON_UNIQUE) === 0;
            $indexes[$name]['columns'][] = (string) $row->COLUMN_NAME;
        }

        foreach ($indexes as $index) {
            if (($index['columns'] ?? []) !== $columns) {
                continue;
            }
            if (! $unique || ($index['unique'] ?? false) === true) {
                return true;
            }
        }

        return false;
    }

    private function ensureForeignKey(
        string $table,
        string $column,
        string $referencedTable,
        string $constraintName,
        string $onDelete,
    ): void {
        if (! Schema::hasColumn($table, $column) || $this->foreignKeyExists($table, $column, $referencedTable)) {
            return;
        }

        Schema::table($table, function (Blueprint $blueprint) use ($column, $referencedTable, $constraintName, $onDelete): void {
            $blueprint->foreign($column, $constraintName)
                ->references('id')
                ->on($referencedTable)
                ->onDelete($onDelete);
        });
    }

    /** @param list<string> $columns */
    private function ensureIndex(string $table, array $columns, bool $unique, string $indexName): void
    {
        foreach ($columns as $column) {
            if (! Schema::hasColumn($table, $column)) {
                return;
            }
        }

        if ($this->indexExistsForColumns($table, $columns, $unique)) {
            return;
        }

        Schema::table($table, function (Blueprint $blueprint) use ($columns, $unique, $indexName): void {
            if ($unique) {
                $blueprint->unique($columns, $indexName);
            } else {
                $blueprint->index($columns, $indexName);
            }
        });
    }
};
