<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Data\SignalActor;
use App\Extensions\TitanSignalEngine\System\Data\SignalConsoleRequest;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use Illuminate\Http\Request;
use InvalidArgumentException;

final class SignalConsoleContextFactory
{
    public function forAdmin(Request $request, SignalConsoleRequest $consoleRequest): SignalContext
    {
        $user = $request->user();
        if ($user === null) {
            throw new InvalidArgumentException('Authenticated admin context is required.');
        }
        $actorId = 'user:' . (string) ($user->getAuthIdentifier() ?? 'unknown');
        $sessionId = $request->hasSession() ? $request->session()->getId() : null;
        $permissions = [
            'signal.system.read',
            'signal.tenant.read',
            'signal.tenant.emit',
            'signal.anomaly.manage',
            'signal.retention.manage',
            'signal.redact',
            'signal.console.manage',
            'signal.health.read',
            'signal.delivery.redrive',
        ];

        if ($consoleRequest->scope === SignalEnvelope::SCOPE_SYSTEM) {
            return new SignalContext(
                SignalEnvelope::SCOPE_SYSTEM,
                null,
                new SignalActor($actorId, 'human', null, 'titan-auth', $sessionId),
                $permissions,
            );
        }

        return new SignalContext(
            SignalEnvelope::SCOPE_TENANT,
            $consoleRequest->tenantCompanyId,
            new SignalActor($actorId, 'human', null, 'titan-auth', $sessionId),
            $permissions,
        );
    }

    public function forTenant(Request $request): SignalContext
    {
        $user = $request->user();
        if ($user === null) {
            throw new InvalidArgumentException('Authenticated tenant context is required.');
        }
        $tenantCompanyId = $this->tenantCompanyId($user);
        $actorId = 'user:' . (string) ($user->getAuthIdentifier() ?? 'unknown');
        $sessionId = $request->hasSession() ? $request->session()->getId() : ('session:' . substr(hash('sha256', $actorId), 0, 24));

        return SignalContext::tenantHuman($tenantCompanyId, $actorId, $sessionId, 'titan-auth');
    }

    private function tenantCompanyId(object $user): int
    {
        foreach (['tenant_company_id', 'company_id'] as $field) {
            $value = $user->{$field} ?? null;
            if (is_numeric($value) && (int) $value > 0) {
                return (int) $value;
            }
        }

        throw new InvalidArgumentException('The authenticated user does not expose a tenant_company_id/company_id required by Signal Console.');
    }
}
