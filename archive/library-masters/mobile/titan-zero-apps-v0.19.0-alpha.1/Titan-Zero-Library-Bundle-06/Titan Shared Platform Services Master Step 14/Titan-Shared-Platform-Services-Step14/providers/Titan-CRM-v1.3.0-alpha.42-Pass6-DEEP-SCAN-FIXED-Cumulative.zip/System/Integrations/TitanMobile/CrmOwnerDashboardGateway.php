<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\TitanMobile;

use App\Extensions\Crm\System\Security\CrmPermissionService;
use App\Extensions\Crm\System\Tenancy\CrmCompanyContextResolver;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\TitanBOS\System\Contracts\OwnerDashboardGateway;
use App\Extensions\TitanBOS\System\Data\OwnerContext;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\ConnectionInterface;

/** CRM customer/sales/commercial projection for Titan BOS. Operational sections remain with their owning extensions. */
final class CrmOwnerDashboardGateway implements OwnerDashboardGateway
{
    public function __construct(
        private OwnerDashboardGateway $inner,
        private ConnectionInterface $db,
        private CrmPermissionService $permissions,
        private CrmCompanyContextResolver $companyContexts,
        private CrmCompanyScope $companyScope,
    ) {}

    public function bootstrap(OwnerContext $context): array
    {
        return $this->withOwner($context, function () use ($context): array {
            $base = $this->inner->bootstrap($context);
            $base['crm'] = $this->decisionDashboard($context);
            return $base;
        });
    }

    public function section(OwnerContext $context, string $section, array $filters=[]): array
    {
        return $this->withOwner($context, function () use ($context, $section, $filters): array {
            $base = $this->inner->section($context, $section, $filters);
            $crm = match ($section) {
                'home', 'today' => $this->decisionDashboard($context),
                'customers' => $this->can($context, 'crm.contacts.view') ? ['customers' => $this->customers()] : ['restricted' => true],
                'sales' => $this->salesSummary($context),
                'money' => $this->moneySummary($context),
                'attention' => [
                    'overdue_invoices' => $this->can($context, 'crm.invoices.view') ? $this->overdueInvoices() : ['restricted' => true],
                    'approvals' => $this->salesSummary($context)['approvals'] ?? ['restricted' => true],
                ],
                default => [],
            };
            if ($crm !== []) {
                $base['crm'] = $crm;
            }
            return $base;
        });
    }

    public function search(OwnerContext $context, string $query, int $limit=20): array
    {
        return $this->withOwner($context, function () use ($context, $query, $limit): array {
            $base = $this->inner->search($context, $query, $limit);
            $tenant = $this->tenant();
            $term = '%' . trim($query) . '%';
            $items = [];
            $resources = [
                ['permission' => 'crm.contacts.view', 'table' => 'crm_contacts', 'type' => 'customer', 'columns' => ['first_name', 'last_name', 'email', 'phone']],
                ['permission' => 'crm.companies.view', 'table' => 'crm_companies', 'type' => 'account_company', 'columns' => ['name', 'email']],
                ['permission' => 'crm.leads.view', 'table' => 'crm_leads', 'type' => 'lead', 'columns' => ['name', 'email', 'company_name']],
                ['permission' => 'crm.deals.view', 'table' => 'crm_deals', 'type' => 'deal', 'columns' => ['name', 'description']],
            ];

            foreach ($resources as $resource) {
                if (! $this->can($context, $resource['permission'])) {
                    continue;
                }
                $q = $this->db->table($resource['table'])
                    ->where('company_id', $tenant)
                    ->whereNull('deleted_at')
                    ->where(function ($where) use ($resource, $term): void {
                        foreach ($resource['columns'] as $column) {
                            $where->orWhere($column, 'like', $term);
                        }
                    });
                foreach ($q->limit($limit)->get() as $row) {
                    $items[] = [
                        'source' => 'crm',
                        'type' => $resource['type'],
                        'id' => $row->public_id ?? $row->id,
                        'title' => $row->name ?? trim(($row->first_name ?? '') . ' ' . ($row->last_name ?? '')),
                        'email' => $row->email ?? null,
                    ];
                }
            }

            $base['crm'] = array_slice($items, 0, max(1, min($limit, 100)));
            return $base;
        });
    }

    private function decisionDashboard(OwnerContext $context): array
    {
        $hasCustomer = $this->can($context, 'crm.contacts.view');
        $sales = $this->salesSummary($context);
        $money = $this->moneySummary($context);

        if (! $hasCustomer && ($sales['restricted'] ?? false) && ($money['restricted'] ?? false)) {
            throw new AuthorizationException('CRM owner dashboard permission denied.');
        }

        return [
            'customers' => $hasCustomer ? $this->customers() : ['restricted' => true],
            'sales' => $sales,
            'money' => $money,
            'attention' => [
                'overdue_invoices' => $this->can($context, 'crm.invoices.view') ? $this->overdueInvoices() : ['restricted' => true],
                'quotes_waiting' => $this->can($context, 'crm.sales.view') ? $this->quotesWaiting() : ['restricted' => true],
            ],
        ];
    }

    private function customers(): array
    {
        return [
            'total' => $this->count('crm_contacts'),
            'new_7d' => $this->db->table('crm_contacts')
                ->where('company_id', $this->tenant())
                ->whereNull('deleted_at')
                ->where('created_at', '>=', now()->subDays(7))
                ->count(),
            'organizations' => $this->count('crm_companies'),
        ];
    }

    private function salesSummary(OwnerContext $context): array
    {
        $allowed = $this->can($context, 'crm.leads.view')
            && $this->can($context, 'crm.deals.view')
            && $this->can($context, 'crm.sales.view');
        if (! $allowed) {
            return ['restricted' => true];
        }

        return [
            'leads' => $this->count('crm_leads'),
            'deals' => $this->count('crm_deals'),
            'quotes_waiting' => count($this->quotesWaiting()),
            'approvals' => ['quotes' => $this->quoteApprovalCount()],
        ];
    }

    private function moneySummary(OwnerContext $context): array
    {
        if (! $this->can($context, 'crm.sales.view') || ! $this->can($context, 'crm.invoices.view')) {
            return ['restricted' => true];
        }
        return $this->money();
    }

    private function money(): array
    {
        $q = $this->db->table('crm_invoices')->where('company_id', $this->tenant())->whereNull('deleted_at');
        return [
            'open' => (clone $q)->whereIn('status', ['issued', 'partially-paid', 'overdue'])->count(),
            'overdue' => (clone $q)->where(function ($where): void {
                $where->where('status', 'overdue')->orWhere(function ($nested): void {
                    $nested->where('due_at', '<', now())->whereNotIn('status', ['paid', 'void', 'cancelled']);
                });
            })->count(),
            'outstanding_minor' => (int) (clone $q)->whereNotIn('status', ['paid', 'void', 'cancelled'])->sum('balance_minor'),
            'payment_states' => (clone $q)->selectRaw('payment_state, count(*) as count')->groupBy('payment_state')->pluck('count', 'payment_state')->all(),
        ];
    }

    private function quoteApprovalCount(): int
    {
        return $this->db->table('crm_proposals')->where('company_id', $this->tenant())->whereNull('deleted_at')->whereIn('status', ['sent', 'pending'])->count()
            + $this->db->table('crm_estimates')->where('company_id', $this->tenant())->whereNull('deleted_at')->whereIn('status', ['sent', 'pending'])->count();
    }

    private function quotesWaiting(int $limit=10): array
    {
        $all = [];
        foreach (['proposals', 'estimates'] as $type) {
            foreach ($this->db->table('crm_' . $type)
                ->where('company_id', $this->tenant())
                ->whereNull('deleted_at')
                ->whereIn('status', ['draft', 'sent', 'pending'])
                ->orderByDesc('id')
                ->limit($limit)
                ->get(['public_id', 'number', 'title', 'status', 'total_minor', 'created_at']) as $row) {
                $all[] = ['type' => $type] + (array) $row;
            }
        }
        return array_slice($all, 0, $limit);
    }

    private function overdueInvoices(int $limit=10): array
    {
        return $this->db->table('crm_invoices')
            ->where('company_id', $this->tenant())
            ->whereNull('deleted_at')
            ->whereNotIn('status', ['paid', 'void', 'cancelled'])
            ->where('due_at', '<', now())
            ->orderBy('due_at')
            ->limit($limit)
            ->get(['public_id', 'number', 'title', 'status', 'balance_minor', 'due_at', 'payment_state'])
            ->map(fn($row) => (array) $row)
            ->all();
    }

    private function count(string $table): int
    {
        return $this->db->table($table)->where('company_id', $this->tenant())->whereNull('deleted_at')->count();
    }

    private function tenant(): int
    {
        return $this->companyScope->current()->companyId;
    }

    private function withOwner(OwnerContext $context, callable $callback): mixed
    {
        if ($context->tenantId <= 0 || $context->userId <= 0) {
            throw new AuthorizationException('Titan BOS company/actor context is invalid.');
        }
        $trusted = $this->companyContexts->fromTrustedPlatform(
            $context->tenantId,
            $context->userId,
            'user',
            roles: [$context->role],
            permissions: $context->permissions,
            sourceSurface: 'owner',
            deviceId: $context->deviceUuid,
            membershipVerified: true,
        );
        return $this->companyScope->runWith($trusted, fn() => $callback());
    }

    private function can(OwnerContext $context, string $permission): bool
    {
        if ($context->can($permission)) {
            return true;
        }
        try {
            return $this->permissions->allows($context->userId, $permission);
        } catch (\Throwable) {
            return false;
        }
    }
}
