@push('css')
<link rel="stylesheet" href="{{ asset('vendor/titan-connect/css/operator-inbox.css') }}">
@endpush

<div class="container-fluid py-6">
<section
    id="titan-connect-unified-inbox"
    class="tc-operator tc-settings"
    data-mode="{{ $mode }}"
    data-inbox-url="{{ route('titan-connect.api.inbox.index') }}"
    data-external-url="{{ route('dashboard.user.titan-connect.inbox.external') }}"
    data-csrf="{{ csrf_token() }}"
>
    <header class="tc-operator__header">
        <div>
            <h1>{{ $mode === 'team' ? __('Team / Internal') : __('Unified Inbox') }}</h1>
            <p>{{ $mode === 'team' ? __('Internal direct, group and business conversations for your company.') : __('Internal and external communication activity in one company-scoped queue.') }}</p>
        </div>
        <div class="tc-operator__header-actions">
            <a class="tc-btn" href="{{ route('dashboard.user.titan-connect.inbox.external') }}">{{ __('External inbox') }}</a>
            <a class="tc-btn tc-btn--ghost" href="{{ route('dashboard.user.titan-connect.channels.index') }}">{{ __('Channels') }}</a>
        </div>
    </header>
    <section class="tc-panel">
        <div class="tc-panel__title"><strong>{{ __('Recent conversations') }}</strong><span data-role="unified-count"></span></div>
        <div data-role="unified-list" class="tc-thread-list__items"><div class="tc-empty">{{ __('Loading inbox…') }}</div></div>
    </section>
    <div class="tc-status" data-role="unified-status" aria-live="polite"></div>
</section>

</div>

@push('script')
<script src="{{ asset('vendor/titan-connect/js/unified-inbox.js') }}" defer></script>
@endpush
