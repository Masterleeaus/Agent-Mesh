<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Http\Controllers;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalAnomalyContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalConsoleContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryRedriveContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalLifecycleContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalConsoleRedactionInput;
use App\Extensions\TitanSignalEngine\System\Data\SignalConsoleRequest;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Services\SignalConsoleContextFactory;
use App\Extensions\TitanSignalEngine\System\Services\SignalConsoleErrorReporter;
use App\Extensions\TitanSignalEngine\System\Services\SignalHostCertificationService;
use App\Extensions\TitanSignalEngine\System\Services\SignalRegistryConsoleService;
use DateTimeImmutable;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use InvalidArgumentException;

final class AdminController
{
    public function __construct(
        private readonly SignalConsoleContract $console,
        private readonly SignalConsoleContextFactory $contexts,
        private readonly SignalAnomalyContract $anomalies,
        private readonly SignalLifecycleContract $lifecycle,
        private readonly SignalDeliveryRedriveContract $redrive,
        private readonly SignalConsoleErrorReporter $errors,
        private readonly SignalRegistryConsoleService $registryConsole,
        private readonly SignalHostCertificationService $hostCertification,
    ) {
    }

    public function __invoke(Request $request): View
    {
        return $this->overview($request);
    }

    public function overview(Request $request): View
    {
        [$spec, $context, $dashboard, $consoleError] = $this->basePage($request);
        return view('titan-signal-engine::admin-rc8-1.overview', compact('dashboard', 'consoleError'));
    }

    public function pulseHealth(Request $request): View
    {
        [$spec, $context, $dashboard, $consoleError] = $this->basePage($request);
        return view('titan-signal-engine::admin-rc8-1.pulse-health', compact('dashboard', 'consoleError'));
    }

    public function eventsTraces(Request $request): View
    {
        [$spec, $context, $dashboard, $consoleError] = $this->basePage($request);
        $detail = null;
        try {
            $detail = $this->detail($request, $spec, $context);
        } catch (\Throwable $exception) {
            $consoleError = $this->errors->report($exception, 'admin.events_traces', $context);
        }
        return view('titan-signal-engine::admin-rc8-1.events-traces', compact('dashboard', 'detail', 'consoleError'));
    }

    public function anomalies(Request $request): View
    {
        [$spec, $context, $dashboard, $consoleError] = $this->basePage($request);
        return view('titan-signal-engine::admin-rc8-1.anomalies', compact('dashboard', 'consoleError'));
    }

    public function deliveriesDlq(Request $request): View
    {
        [$spec, $context, $dashboard, $consoleError] = $this->basePage($request);
        return view('titan-signal-engine::admin-rc8-1.deliveries-dlq', compact('dashboard', 'consoleError'));
    }

    public function lifecycleArchives(Request $request): View
    {
        [$spec, $context, $dashboard, $consoleError] = $this->basePage($request);
        $prunePreview = null;
        try {
            if ($request->boolean('prune_preview')) {
                $prunePreview = $this->lifecycle->previewPrune($spec->tenantCompanyId, $spec->scope, min($spec->limit, 100), $context);
            }
        } catch (\Throwable $exception) {
            $consoleError = $this->errors->report($exception, 'admin.lifecycle_archives', $context);
        }
        return view('titan-signal-engine::admin-rc8-1.lifecycle-archives', compact('dashboard', 'prunePreview', 'consoleError'));
    }

    public function registries(Request $request): View
    {
        [$spec, $context, $dashboard, $consoleError] = $this->basePage($request);
        $registries = ['event_types' => [], 'subscriptions' => [], 'trace_profiles' => []];
        try {
            $registries = $this->registryConsole->snapshot($spec->limit);
        } catch (\Throwable $exception) {
            $consoleError = $this->errors->report($exception, 'admin.registries', $context);
        }
        return view('titan-signal-engine::admin-rc8-1.registries', compact('dashboard', 'registries', 'consoleError'));
    }

    public function diagnostics(Request $request): View
    {
        [$spec, $context, $dashboard, $consoleError] = $this->basePage($request);
        $certification = ['overall' => 'UNAVAILABLE', 'summary' => [], 'checks' => [], 'certified_at' => null];
        try {
            $certification = $this->hostCertification->certify(false, false)->toArray();
        } catch (\Throwable $exception) {
            $consoleError = $this->errors->report($exception, 'admin.diagnostics', $context);
        }
        return view('titan-signal-engine::admin-rc8-1.diagnostics', compact('dashboard', 'certification', 'consoleError'));
    }

    public function acknowledgeAnomaly(Request $request, string $anomalyId): RedirectResponse
    {
        return $this->mutate($request, function (SignalContext $context) use ($request, $anomalyId): void {
            $this->anomalies->acknowledge($anomalyId, trim((string) $request->input('reason')), $context);
        }, 'Anomaly acknowledged.');
    }

    public function resolveAnomaly(Request $request, string $anomalyId): RedirectResponse
    {
        return $this->mutate($request, function (SignalContext $context) use ($request, $anomalyId): void {
            $this->anomalies->resolve($anomalyId, trim((string) $request->input('reason')), $context);
        }, 'Anomaly resolved.');
    }

    public function suppressAnomaly(Request $request, string $anomalyId): RedirectResponse
    {
        return $this->mutate($request, function (SignalContext $context) use ($request, $anomalyId): void {
            $until = new DateTimeImmutable((string) $request->input('until'));
            $this->anomalies->suppress($anomalyId, $until, trim((string) $request->input('reason')), $context);
        }, 'Anomaly suppressed.');
    }

    public function legalHold(Request $request, string $eventId): RedirectResponse
    {
        return $this->mutate($request, function (SignalContext $context) use ($request, $eventId): void {
            $this->lifecycle->setLegalHold($eventId, $request->boolean('hold'), trim((string) $request->input('reason')), $context);
        }, $request->boolean('hold') ? 'Legal hold applied.' : 'Legal hold released.');
    }

    public function redact(Request $request, string $eventId): RedirectResponse
    {
        return $this->mutate($request, function (SignalContext $context) use ($request, $eventId): void {
            $input = SignalConsoleRedactionInput::fromArray($request->only(['operation', 'path', 'value', 'reason']));
            $this->lifecycle->redact($eventId, $input->operations, $input->reason, $context);
        }, 'Privacy redaction overlay applied.');
    }

    public function correct(Request $request, string $eventId): RedirectResponse
    {
        return $this->mutate($request, function (SignalContext $context) use ($request, $eventId): void {
            $input = SignalConsoleRedactionInput::fromArray($request->only(['operation', 'path', 'value', 'reason']));
            $this->lifecycle->correct($eventId, $input->operations, $input->reason, $context);
        }, 'Correction overlay applied.');
    }

    public function redriveDelivery(Request $request, string $deliveryId): RedirectResponse
    {
        return $this->mutate($request, function (SignalContext $context) use ($request, $deliveryId): void {
            $this->redrive->redrive($deliveryId, trim((string) $request->input('reason')), $context);
        }, 'Dead-letter delivery queued for governed redrive.');
    }

    public function prune(Request $request): RedirectResponse
    {
        return $this->mutate($request, function (SignalContext $context) use ($request): void {
            $this->lifecycle->prune(
                trim((string) $request->input('preview_token')),
                trim((string) $request->input('reason')),
                $context,
            );
        }, 'Prune/archive operation completed.');
    }

    /** @return array{0:SignalConsoleRequest,1:SignalContext,2:array<string,mixed>,3:?string} */
    private function basePage(Request $request): array
    {
        $consoleError = null;
        $context = null;
        try {
            $spec = $this->adminSpec($request);
            $context = $this->contexts->forAdmin($request, $spec);
            $dashboard = $this->console->dashboard($spec, $context, true);
        } catch (\Throwable $exception) {
            $spec = SignalConsoleRequest::fromArray(['scope' => SignalEnvelope::SCOPE_SYSTEM, 'window' => '5m', 'limit' => 100]);
            $context = $context ?? $this->contexts->forAdmin($request, $spec);
            $dashboard = $this->fallbackDashboard($spec, true);
            $consoleError = $this->errors->report($exception, 'admin.dashboard', $context);
        }
        return [$spec, $context, $dashboard, $consoleError];
    }

    /** @return array<string,mixed>|null */
    private function detail(Request $request, SignalConsoleRequest $spec, SignalContext $context): ?array
    {
        $traceId = trim((string) $request->query('trace_id', ''));
        if ($traceId !== '') {
            $this->assertUuid($traceId, 'trace_id');
            return ['kind' => 'trace', 'id' => $traceId, 'data' => $this->console->trace($traceId, $spec, $context, $request->query('profile_key'), $request->integer('profile_version') ?: null)];
        }
        $correlationId = trim((string) $request->query('correlation_id', ''));
        if ($correlationId !== '') {
            $this->assertUuid($correlationId, 'correlation_id');
            return ['kind' => 'workflow', 'id' => $correlationId, 'data' => $this->console->workflow($correlationId, $spec, $context)];
        }
        $eventId = trim((string) $request->query('event_id', ''));
        if ($eventId !== '') {
            $this->assertUuid($eventId, 'event_id');
            return ['kind' => 'event', 'id' => $eventId, 'data' => $this->console->event($eventId, $spec, $context)];
        }
        return null;
    }

    private function adminSpec(Request $request): SignalConsoleRequest
    {
        return SignalConsoleRequest::fromArray([
            'scope' => $request->input('scope', SignalEnvelope::SCOPE_SYSTEM),
            'tenant_company_id' => $request->input('tenant_company_id'),
            'window' => $request->input('window', '5m'),
            'limit' => $request->input('limit', 100),
        ]);
    }

    /** @param callable(SignalContext):void $callback */
    private function mutate(Request $request, callable $callback, string $success): RedirectResponse
    {
        try {
            $spec = $this->adminSpec($request);
            $context = $this->contexts->forAdmin($request, $spec);
            $callback($context);
            return back()->with('status', $success);
        } catch (\Throwable $exception) {
            return back()->withInput()->with('error', $this->errors->report($exception, 'admin.mutation', isset($context) ? $context : null));
        }
    }

    /** @return array<string,mixed> */
    private function fallbackDashboard(SignalConsoleRequest $spec, bool $administrative): array
    {
        return [
            'request' => $spec->toArray(),
            'health' => [
                'engine' => 'titan-signal-engine', 'version' => '0.20.0-rc.8.1', 'status' => 'unavailable',
                'delivery' => ['backpressured' => false, 'pending' => 0, 'retry_wait' => 0, 'processing' => 0, 'stale_processing' => 0, 'unresolved_dead_letter' => 0],
                'pulse' => ['status' => 'unknown'], 'anomaly' => ['critical_open' => 0],
                'trace_evaluation' => ['due' => 0], 'lifecycle' => ['legal_holds' => 0],
            ],
            'pulse' => ['metrics' => [], 'latency' => [], 'health' => [], 'sources' => [], 'top_event_types' => []],
            'surface' => [
                'headline' => 'Signal Console unavailable',
                'attention' => ['band' => 'unknown', 'score' => 0],
                'signal_count' => 0, 'error_count' => 0, 'critical_count' => 0,
                'stalled_trace_count' => 0, 'missing_receipt_count' => 0, 'dead_letter_count' => 0,
                'event_rate_per_second' => 0.0, 'health' => ['degraded' => true],
                'top_sources' => [], 'top_event_types' => [],
            ],
            'anomalies' => [],
            'subscriber_health' => $administrative ? [] : [],
            'dead_letters' => [], 'lifecycle' => [], 'archives' => [], 'lifecycle_audit' => [],
        ];
    }

    private function assertUuid(string $value, string $field): void
    {
        if (! preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value)) {
            throw new InvalidArgumentException("Invalid {$field}.");
        }
    }
}
