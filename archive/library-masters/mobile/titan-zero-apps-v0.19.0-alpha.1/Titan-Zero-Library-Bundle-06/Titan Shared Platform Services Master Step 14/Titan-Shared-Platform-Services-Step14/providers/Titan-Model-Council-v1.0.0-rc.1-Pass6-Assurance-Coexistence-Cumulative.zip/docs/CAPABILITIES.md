# Capabilities

## `council.plan`
Proposal-only, online capability. Chooses the minimum deliberation strategy from deterministic request signals plus Risk floor. It does not execute providers or mutate business state.

## `council.deliberate`
Proposal-only, online capability. Runs entitled models through single, lightweight, parallel-consensus, or governed-deliberation strategy. Outputs are advisory artifacts with confidence, disagreement, escalation, billing, tenant and causal metadata.

## Invariants

- Tenant scope is mandatory.
- Model entitlements and credit preflight occur before provider execution.
- Billing follows reserve → execute → settle/release ordering.
- Strong contradiction cannot be hidden by synthesis.
- Manual requests cannot weaken a stronger Risk requirement.
- No capability in this extension performs business mutations.
