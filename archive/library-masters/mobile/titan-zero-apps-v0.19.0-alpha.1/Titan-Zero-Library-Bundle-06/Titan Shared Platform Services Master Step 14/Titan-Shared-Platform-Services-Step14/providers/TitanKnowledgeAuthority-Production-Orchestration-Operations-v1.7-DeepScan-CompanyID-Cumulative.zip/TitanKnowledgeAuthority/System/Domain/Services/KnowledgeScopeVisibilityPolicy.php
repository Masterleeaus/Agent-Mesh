<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Services;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Enums\KnowledgeScopeType;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeAccessContext;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeScopeContext;

final class KnowledgeScopeVisibilityPolicy
{
    public function canRead(KnowledgeAccessContext $context, KnowledgeScopeContext $scope): bool
    {
        return match ($scope->type) {
            KnowledgeScopeType::Platform => true,
            KnowledgeScopeType::Tenant => $scope->tenantCompanyId !== null
                && $context->allowsTenant($scope->tenantCompanyId),
            KnowledgeScopeType::Jurisdiction => $scope->jurisdictionCode !== null
                && $context->allowsJurisdiction($scope->jurisdictionCode),
        };
    }

    public function assertCanRead(KnowledgeAccessContext $context, KnowledgeScopeContext $scope): void
    {
        if (! $this->canRead($context, $scope)) {
            throw new \DomainException('Knowledge scope access denied.');
        }
    }
}
