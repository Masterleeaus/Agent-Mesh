# Pass 8 — Recommendation Hardening & Decision Evidence

Titan Field remains the sole scheduling writer. Pass 8 hardens the read-only recommendation layer only.

## Policy v3

Eligible workers are scored on a transparent 100-point scale: hard-constraint eligibility (15), required skills (20), rolling workload balance (20), worker territory preference (15), route adjacency (15), and customer/location continuity (15). Ineligible workers remain score 0 with the SchedulingKernel rejection reason.

## Evidence

Every recommendation run records an immutable snapshot in `titan_field_recommendation_snapshots`, including policy version, tenant/requester, requested window, normalized context hash, deterministic recommendation hash, full ranked recommendations, top recommendation, trace/correlation identifiers, and source facts used by each score component. The evidence store is append-only and does not assign, reschedule, dispatch, or mutate authoritative work.

## Donor use

The Dispatch donor informed explainable score/reason patterns. Titan Field does not import donor technician, shift, dispatch, service-zone, or scheduling authorities. The canonical SchedulingKernel remains the hard gate and the Pass-5 command gateway remains the only mutation entry point.
