<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Support\CanonicalJson;
use InvalidArgumentException;

final class CompilationLifecycleEvent
{
    /** @param array<string,mixed> $payload */
    private function __construct(
        private readonly string $eventId,
        private readonly int $tenantCompanyId,
        private readonly string $compilationUuid,
        private readonly ?string $parentCompilationUuid,
        private readonly int $entityVersion,
        private readonly CompilationLifecycleStage $stage,
        private readonly TraceContext $traceContext,
        private readonly array $payload,
        private readonly string $payloadHash,
    ) {
        self::assertHash($this->eventId, 'event_id');
        self::assertHash($this->payloadHash, 'payload_hash');
        self::assertUuid($this->compilationUuid, 'compilation_uuid');
        if ($this->parentCompilationUuid !== null) {
            self::assertUuid($this->parentCompilationUuid, 'parent_compilation_uuid');
        }
        if ($this->tenantCompanyId <= 0 || $this->traceContext->tenantCompanyId() !== $this->tenantCompanyId) {
            throw new InvalidArgumentException('Lifecycle event tenant must match its trace context.');
        }
        if ($this->entityVersion < 0) {
            throw new InvalidArgumentException('Lifecycle event entity_version cannot be negative.');
        }
        $actualPayloadHash = hash('sha256', CanonicalJson::encode($this->payload));
        if (!hash_equals($actualPayloadHash, strtolower($this->payloadHash))) {
            throw new InvalidArgumentException('Lifecycle event payload_hash does not match payload content.');
        }
        $expectedEventId = self::deriveEventId(
            $this->tenantCompanyId,
            $this->compilationUuid,
            $this->parentCompilationUuid,
            $this->stage,
            $this->traceContext,
            $actualPayloadHash,
        );
        if (!hash_equals($expectedEventId, strtolower($this->eventId))) {
            throw new InvalidArgumentException('Lifecycle event_id does not match canonical event content.');
        }
    }

    /** @param array<string,mixed> $payload */
    public static function create(
        NexusCompilation $compilation,
        CompilationLifecycleStage $stage,
        array $payload,
        ?TraceContext $traceContext = null,
    ): self {
        $trace = $traceContext ?? $compilation->traceContext();
        if ($trace->tenantCompanyId() !== $compilation->businessProfile()->tenantCompanyId()) {
            throw new InvalidArgumentException('Lifecycle action trace must belong to the compilation tenant.');
        }
        $payloadHash = hash('sha256', CanonicalJson::encode($payload));
        $eventId = self::deriveEventId(
            $compilation->businessProfile()->tenantCompanyId(),
            $compilation->compilationUuid(),
            $compilation->parentCompilationUuid(),
            $stage,
            $trace,
            $payloadHash,
        );
        return new self(
            $eventId,
            $compilation->businessProfile()->tenantCompanyId(),
            $compilation->compilationUuid(),
            $compilation->parentCompilationUuid(),
            $compilation->entityVersion(),
            $stage,
            $trace,
            $payload,
            $payloadHash,
        );
    }

    /** @param array<string,mixed> $data */
    public static function fromPersistence(array $data): self
    {
        $payload = $data['payload'] ?? null;
        if (!is_array($payload)) {
            throw new InvalidArgumentException('Lifecycle event payload must be an object-like array.');
        }
        $stageValue = self::requiredString($data['stage'] ?? null, 'stage');
        $stage = CompilationLifecycleStage::tryFrom($stageValue);
        if ($stage === null) {
            throw new InvalidArgumentException('Lifecycle event stage is invalid.');
        }
        $parent = $data['parent_compilation_uuid'] ?? null;
        if ($parent !== null && !is_string($parent)) {
            throw new InvalidArgumentException('parent_compilation_uuid must be a UUID or null.');
        }
        return new self(
            self::requiredString($data['event_id'] ?? null, 'event_id'),
            self::positiveInt($data['tenant_company_id'] ?? null, 'tenant_company_id'),
            self::requiredString($data['compilation_uuid'] ?? null, 'compilation_uuid'),
            $parent === null || trim($parent) === '' ? null : trim($parent),
            self::nonNegativeInt($data['entity_version'] ?? 0, 'entity_version'),
            $stage,
            TraceContext::fromArray([
                'tenant_company_id' => $data['tenant_company_id'] ?? null,
                'trace_id' => $data['trace_id'] ?? null,
                'correlation_id' => $data['correlation_id'] ?? null,
                'causation_id' => $data['causation_id'] ?? null,
            ]),
            $payload,
            self::requiredString($data['payload_hash'] ?? null, 'payload_hash'),
        );
    }

    public function eventId(): string { return strtolower($this->eventId); }
    public function tenantCompanyId(): int { return $this->tenantCompanyId; }
    public function compilationUuid(): string { return strtolower($this->compilationUuid); }
    public function parentCompilationUuid(): ?string { return $this->parentCompilationUuid === null ? null : strtolower($this->parentCompilationUuid); }
    public function entityVersion(): int { return $this->entityVersion; }
    public function stage(): CompilationLifecycleStage { return $this->stage; }
    public function traceContext(): TraceContext { return $this->traceContext; }
    /** @return array<string,mixed> */ public function payload(): array { return $this->payload; }
    public function payloadHash(): string { return strtolower($this->payloadHash); }

    /** @return array<string,mixed> */
    public function toPersistenceArray(): array
    {
        return [
            'event_id' => $this->eventId(),
            'tenant_company_id' => $this->tenantCompanyId,
            'compilation_uuid' => $this->compilationUuid(),
            'parent_compilation_uuid' => $this->parentCompilationUuid(),
            'entity_version' => $this->entityVersion,
            'stage' => $this->stage->value,
            'trace_id' => $this->traceContext->traceId(),
            'correlation_id' => $this->traceContext->correlationId(),
            'causation_id' => $this->traceContext->causationId(),
            'payload_hash' => $this->payloadHash(),
            'payload' => $this->payload,
        ];
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'event_id' => $this->eventId(),
            'stage' => $this->stage->value,
            'entity_version' => $this->entityVersion,
            'parent_compilation_uuid' => $this->parentCompilationUuid(),
            'payload_hash' => $this->payloadHash(),
            'trace' => $this->traceContext->toArray(),
            'payload' => $this->payload,
        ];
    }

    private static function deriveEventId(int $tenantCompanyId, string $compilationUuid, ?string $parentCompilationUuid, CompilationLifecycleStage $stage, TraceContext $trace, string $payloadHash): string
    {
        return hash('sha256', CanonicalJson::encode([
            'tenant_company_id' => $tenantCompanyId,
            'compilation_uuid' => strtolower($compilationUuid),
            'parent_compilation_uuid' => $parentCompilationUuid === null ? null : strtolower($parentCompilationUuid),
            'stage' => $stage->value,
            'trace_id' => strtolower($trace->traceId()),
            'correlation_id' => strtolower($trace->correlationId()),
            'causation_id' => strtolower($trace->causationId()),
            'payload_hash' => strtolower($payloadHash),
        ]));
    }

    private static function assertUuid(string $value, string $field): void
    {
        if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) !== 1) {
            throw new InvalidArgumentException("{$field} must be a valid UUID.");
        }
    }
    private static function assertHash(string $value, string $field): void
    {
        if (preg_match('/^[0-9a-f]{64}$/i', $value) !== 1) {
            throw new InvalidArgumentException("{$field} must be a SHA-256 hex digest.");
        }
    }
    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') { throw new InvalidArgumentException("{$field} is required."); }
        return trim($value);
    }
    private static function positiveInt(mixed $value, string $field): int
    {
        $resolved = is_int($value) ? $value : (is_string($value) && ctype_digit($value) ? (int)$value : 0);
        if ($resolved <= 0) { throw new InvalidArgumentException("{$field} must be a positive integer."); }
        return $resolved;
    }
    private static function nonNegativeInt(mixed $value, string $field): int
    {
        $resolved = is_int($value) ? $value : (is_string($value) && ctype_digit($value) ? (int)$value : -1);
        if ($resolved < 0) { throw new InvalidArgumentException("{$field} must be a non-negative integer."); }
        return $resolved;
    }
}
