<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);function fail_rt(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function same_rt(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_rt($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
foreach(['/System/DecisionIntelligence/GovernanceRewindTheater.php'] as $f){if(!is_file($root.$f))fail_rt('missing production file '.$f);require_once $root.$f;}
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceRewindTheater;
$theater=new GovernanceRewindTheater();
$ready=$theater->project(['status'=>'HEALTHY','decision_id'=>'gdec-1','decision'=>['trace_id'=>'tr-1','correlation_id'=>'co-1'],'sources'=>['titan-rewind'=>['status'=>'HEALTHY','rewind'=>['status'=>'READY','trace_id'=>'tr-1','segments'=>[['type'=>'signal','reference'=>'sig-1']]]]]]);same_rt('READY',$ready['status'],'healthy rewind projection');same_rt('tr-1',$ready['trace_id'],'trace preserved');same_rt(1,count($ready['reconstruction']['segments']),'segments exposed from Rewind only');
$missing=$theater->project(['status'=>'HEALTHY','decision_id'=>'gdec-1','decision'=>['trace_id'=>'tr-1'],'sources'=>[]]);same_rt('UNAVAILABLE',$missing['status'],'missing Rewind source fails closed');
$invalid=$theater->project(['status'=>'HEALTHY','decision_id'=>'gdec-1','decision'=>[],'sources'=>['titan-rewind'=>['status'=>'INVALID','reason'=>'IDENTITY_MISMATCH','rewind'=>null]]]);same_rt('INVALID',$invalid['status'],'invalid Rewind identity remains invalid');
$notFound=$theater->project(['status'=>'NOT_FOUND','decision_id'=>'x','decision'=>null,'sources'=>[]]);same_rt('NOT_FOUND',$notFound['status'],'missing decision remains not found');
echo "PASS: Governance Rewind Theater\n";
