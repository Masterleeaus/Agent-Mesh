<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\DTO;

final class ProviderHttpResponse
{
    /**
     * @param array<string,mixed> $json
     * @param array<string,mixed> $headers
     */
    public function __construct(
        public readonly int $status,
        public readonly string $body,
        public readonly array $json = [],
        public readonly array $headers = [],
    ) {
    }

    public function isSuccessful(): bool
    {
        return $this->status >= 200 && $this->status < 300;
    }

    public function json(string $key = '', mixed $default = null): mixed
    {
        if ($key === '') {
            return $this->json;
        }

        return data_get($this->json, $key, $default);
    }

    public function header(string $name): ?string
    {
        foreach ($this->headers as $key => $value) {
            if (strcasecmp((string) $key, $name) !== 0) {
                continue;
            }
            if (is_array($value)) {
                return isset($value[0]) ? (string) $value[0] : null;
            }
            return is_scalar($value) ? (string) $value : null;
        }
        return null;
    }
}
