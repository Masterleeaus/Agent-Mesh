<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\View\MagicAiDashboardRenderer;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\View\View;

final class TitanConnectSettingsController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly MagicAiDashboardRenderer $dashboard,
    ) {
    }

    public function index(Request $request): View
    {
        $this->context->companyId($request);

        return $this->dashboard->render(
            'titan-connect::settings.index',
            [],
            __('Titan Connect Settings'),
        );
    }
}
