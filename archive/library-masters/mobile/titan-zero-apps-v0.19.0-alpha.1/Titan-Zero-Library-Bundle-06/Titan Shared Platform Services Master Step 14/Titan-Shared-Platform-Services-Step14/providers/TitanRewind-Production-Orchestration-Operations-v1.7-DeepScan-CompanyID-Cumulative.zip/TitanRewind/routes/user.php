<?php

use App\Extensions\TitanRewind\System\Http\Controllers\AssistantController;
use App\Extensions\TitanRewind\System\Http\Controllers\EvidenceController;
use App\Extensions\TitanRewind\System\Http\Controllers\ForensicsController;
use App\Extensions\TitanRewind\System\Http\Controllers\IndexController;
use App\Extensions\TitanRewind\System\Http\Controllers\LegalHoldController;
use App\Extensions\TitanRewind\System\Http\Controllers\RecoveryController;
use App\Extensions\TitanRewind\System\Http\Controllers\ReplayController;
use App\Extensions\TitanRewind\System\Http\Controllers\TraceController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', IndexController::class)->middleware('titan-rewind.permission:rewind.trace.view')->name('index');
$router->get('/traces', [IndexController::class, 'traces'])->middleware('titan-rewind.permission:rewind.trace.view')->name('traces.index');
$router->get('/cases', [IndexController::class, 'cases'])->middleware('titan-rewind.permission:rewind.trace.view')->name('cases.index');
$router->get('/replays', [IndexController::class, 'replays'])->middleware('titan-rewind.permission:rewind.replay.run')->name('replay.index');
$router->get('/evidence', [IndexController::class, 'evidence'])->middleware('titan-rewind.permission:rewind.trace.view')->name('evidence.index');
$router->get('/recovery', [IndexController::class, 'recovery'])->middleware('titan-rewind.permission:rewind.recovery.propose')->name('recovery.index');
$router->get('/traces/{traceId}', [TraceController::class, 'show'])->where('traceId', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.trace.view')->name('traces.show');
$router->post('/traces/{traceId}/integrity', [ForensicsController::class, 'verify'])->where('traceId', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.integrity.verify')->name('forensics.integrity');
$router->post('/traces/{traceId}/drift', [ForensicsController::class, 'drift'])->where('traceId', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.forensics.view')->name('forensics.drift');
$router->post('/traces/{traceId}/replay', [ReplayController::class, 'store'])->where('traceId', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.replay.run')->name('replay.store');
$router->post('/traces/{traceId}/compare', [ReplayController::class, 'compare'])->where('traceId', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.replay.run')->name('replay.compare');
$router->get('/replay/{runUuid}', [ReplayController::class, 'show'])->where('runUuid', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.replay.run')->name('replay.show');
$router->post('/traces/{traceId}/evidence', [EvidenceController::class, 'store'])->where('traceId', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.evidence.generate')->name('evidence.store');
$router->post('/cases/{caseUuid}/evidence', [EvidenceController::class, 'storeCase'])->where('caseUuid', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.evidence.generate')->name('case.evidence.store');
$router->get('/evidence/{packageUuid}', [EvidenceController::class, 'show'])->where('packageUuid', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.trace.view')->name('evidence.show');
$router->get('/evidence/{packageUuid}/download', [EvidenceController::class, 'download'])->where('packageUuid', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.evidence.export')->name('evidence.download');
$router->post('/traces/{traceId}/recovery', [RecoveryController::class, 'store'])->where('traceId', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.recovery.propose')->name('recovery.store');
$router->get('/recovery/{planUuid}', [RecoveryController::class, 'show'])->where('planUuid', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.recovery.propose')->name('recovery.show');
$router->post('/recovery/{planUuid}/governance', [RecoveryController::class, 'requestApproval'])->where('planUuid', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.recovery.request-approval')->name('recovery.governance.request');
$router->post('/recovery/{planUuid}/governance/refresh', [RecoveryController::class, 'refreshApproval'])->where('planUuid', '[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.recovery.request-approval')->name('recovery.governance.refresh');
$router->post('/legal-holds', [LegalHoldController::class, 'store'])->middleware('titan-rewind.permission:rewind.legal-hold.manage')->name('legal-holds.store');
$router->post('/legal-holds/{holdUuid}/release', [LegalHoldController::class, 'release'])->where('holdUuid','[0-9a-fA-F-]{36}')->middleware('titan-rewind.permission:rewind.legal-hold.manage')->name('legal-holds.release');
$router->get('/assistant', [AssistantController::class, 'index'])->middleware('titan-rewind.permission:rewind.forensics.view')->name('assistant.index');
$router->post('/assistant', [AssistantController::class, 'ask'])->middleware('titan-rewind.permission:rewind.forensics.view')->name('assistant.ask');
