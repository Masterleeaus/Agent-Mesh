# Titan CRM Core Operations Runbook

This runbook covers recovery of CRM Core-owned state and derivative operational queues. Do not bypass Titan Command Bus or reintroduce local ownership of Titan Field, Locker, Pay, Ledger or Autonomy behavior during recovery.

## First response

Run `php artisan crm:production-check --json`, then `php artisan crm:doctor --json`, then `php artisan crm:metrics --json`. Treat **BLOCK** as unsafe for consequential CRM writes, **WARN** as operable with intervention required, and **PASS** as no detected readiness defect.

## Signal outbox

If the **Signal outbox** is stuck, restore the Titan Signal binding first. Inspect pending/retry/claimed/dead-letter rows in `crm_domain_signal_outbox`, then run `php artisan crm:signals:deliver`. Never delete undelivered events to make the queue look healthy; preserve correlation, causation, receipt and Rewind references.

## Projection rebuild

For stale read models, inspect `crm_read_projection_state` and projection dead letters. Replay eligible dead letters with `php artisan crm:projections:dead-letters`, then perform an incremental **Projection rebuild** with `php artisan crm:projections:rebuild --incremental`. A projection is disposable; authoritative CRM tables are not.

## Command Bus

If **Command Bus** is unavailable, keep consequential mutations blocked. Restore the Titan Command Bus binding and rerun `crm:production-check`. Do not enable `CRM_ALLOW_LEGACY_LOCAL_HUMAN_MUTATIONS` as an incident workaround.

## Portal malware scanner

If the **malware scanner** is unavailable, customer uploads remain unavailable/fail-closed. Keep files quarantined, restore the scanner binding, scan again, and release only clean files. Never mark a quarantined or failed file clean manually.

## Webhook backlog

For **Webhook backlog** or dead letters, inspect endpoint health, URL policy, signing secret version, nonce/idempotency state and response errors. Retry only after the cause is fixed using the existing webhook retry command or governed retry capability. Do not reset delivery history.

## Import recovery

For **Import recovery**, inspect the staged impact report and `crm_import_rollback_journal`. Failed or interrupted commits must be reconciled against journaled public IDs and state hashes. Roll back only when the journal proves the created/updated record has not changed since import.

## Document render

For a stuck **Document render**, inspect `crm_sales_document_render_jobs`, storage availability, renderer configuration and source snapshot hash. Run `php artisan crm:documents:render` after remediation. Do not regenerate issued documents from mutable live state.

## Titan Connect

When **Titan Connect** is unavailable, outbound effects remain deferred. Restore the communication binding, then drain the CRM notification/outbound queue. Preserve idempotency keys and provider receipt lineage; never resend by creating a second authoritative CRM command.

## Database migration interruption

Re-run the installer/migration only after checking the failed migration and schema state. CRM migrations are designed to be additive/restartable; do not manually drop authoritative tables. Verify `crm:production-check` and the package verifier after recovery.

## Escalation evidence

Capture the `crm:doctor --json` result, relevant trace/correlation IDs, command receipt IDs, Signal/public outbox IDs, projection/dead-letter IDs and timestamps. This is sufficient operational evidence; do not capture hidden reasoning or secrets.
