<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Certification;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
use Throwable;

final class QueueExecutionProbe
{
    /** @return array{name:string,status:string,message:string} */
    public function run(int $timeout): array
    {
        $connection = (string) config('queue.default', 'sync');
        if ($connection === 'sync') {
            return [
                'name' => 'queue-execution',
                'status' => 'warning',
                'message' => 'Queue connection is sync; an asynchronous worker cannot be certified.',
            ];
        }

        $token = (string) Str::uuid();
        $key = CertificationQueueProbeJob::cacheKey($token);
        $queue = (string) config('titan-connect.certification.queue', config('titan-connect.webhooks.queue', 'default'));
        $timeout = max(1, min($timeout, 60));
        Cache::forget($key);

        try {
            CertificationQueueProbeJob::dispatch($token)->onQueue($queue);
            $deadline = microtime(true) + $timeout;
            do {
                if (Cache::has($key)) {
                    Cache::forget($key);
                    return [
                        'name' => 'queue-execution',
                        'status' => 'ok',
                        'message' => "Queue worker executed the Titan Connect certification job on [{$queue}].",
                    ];
                }
                usleep(250000);
            } while (microtime(true) < $deadline);

            return [
                'name' => 'queue-execution',
                'status' => 'error',
                'message' => "Queue worker did not acknowledge the certification job within {$timeout} seconds.",
            ];
        } catch (Throwable $e) {
            return [
                'name' => 'queue-execution',
                'status' => 'error',
                'message' => 'Queue certification failed: '.$e->getMessage(),
            ];
        } finally {
            Cache::forget($key);
        }
    }
}
