<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\InteractionEngine\System\Capabilities\CapabilityExecutionContext;
use App\Extensions\InteractionEngine\System\Capabilities\CapabilityRouter;
use App\Extensions\InteractionEngine\System\Contracts\InteractionEngineManagerContract;
use App\Extensions\InteractionEngine\System\Wizard\Command\CommandMapper;
use App\Extensions\InteractionEngine\System\Wizard\Storage\WizardSessionStoreInterface;
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\InteractionEngineBridgeContract;

final class InteractionEngineLiveBridge implements InteractionEngineBridgeContract
{
    public function __construct(
        private readonly InteractionEngineManagerContract $manager,
        private readonly CapabilityRouter $router,
        private readonly HostContextBridgeContract $host,
        private readonly ?WizardSessionStoreInterface $sessions = null,
        private readonly ?CommandMapper $commandMapper = null,
    ) {}

    public function prepareJourney(string $capability, ?string $workflowKey, array $context): array
    {
        if (!$this->manager->isEnabled()) {
            return ['ready' => false, 'available' => false, 'session_validated' => false, 'reason_codes' => ['INTERACTION_ENGINE_DISABLED']];
        }

        $correlation = trim((string) ($context['correlation_id'] ?? '')) ?: bin2hex(random_bytes(16));
        $sessionId = trim((string) ($context['session_id'] ?? ''));
        $execution = new CapabilityExecutionContext(
            companyId: (string) $this->host->tenantCompanyId(),
            actorId: (string) $this->host->userId(),
            actorType: 'human',
            roles: array_values(array_filter((array) ($context['roles'] ?? []), 'is_string')),
            scopes: array_values(array_filter((array) ($context['scopes'] ?? $context['delegated_scopes'] ?? []), 'is_string')),
            sourceSurface: 'titan_autonomy',
            correlationId: $correlation,
            interactionId: isset($context['interaction_id']) ? (string) $context['interaction_id'] : null,
            sessionId: $sessionId !== '' ? $sessionId : null,
            deviceId: isset($context['device_id']) ? (string) $context['device_id'] : null,
            idempotencyKey: isset($context['idempotency_key']) ? (string) $context['idempotency_key'] : null,
            approvalEvidence: (array) ($context['approval_evidence'] ?? []),
        );

        $status = $this->router->status($capability, $execution);
        $available = ($status['supported'] ?? false) === true && ($status['availability'] ?? null) === 'available';
        if (!$available) {
            return [
                'ready' => false,
                'available' => false,
                'session_validated' => false,
                'canonical_capability' => (string) ($status['canonical_capability'] ?? $this->router->canonical($capability)),
                'workflow_key' => $workflowKey,
                'correlation_id' => $correlation,
                'reason_codes' => ['INTERACTION_CAPABILITY_UNAVAILABLE'],
                'status' => $status,
            ];
        }

        // Status-only checks may omit a session. Governed mutation execution must
        // require session_validated=true and consume mapped_command, never caller payload.
        if ($sessionId === '') {
            return [
                'ready' => true,
                'available' => true,
                'session_validated' => false,
                'canonical_capability' => (string) ($status['canonical_capability'] ?? $this->router->canonical($capability)),
                'workflow_key' => $workflowKey,
                'correlation_id' => $correlation,
                'reason_codes' => ['INTERACTION_SESSION_REQUIRED_FOR_EXECUTION'],
                'status' => $status,
            ];
        }
        if ($this->sessions === null || $this->commandMapper === null) {
            return ['ready' => false, 'available' => true, 'session_validated' => false, 'reason_codes' => ['INTERACTION_SESSION_RUNTIME_UNAVAILABLE'], 'status' => $status];
        }

        $session = $this->sessions->get($sessionId);
        if ($session === null) return ['ready' => false, 'available' => true, 'session_validated' => false, 'reason_codes' => ['INTERACTION_SESSION_NOT_FOUND'], 'status' => $status];
        $companyId = (string) ($session->context['company_id'] ?? '');
        $userId = (string) ($session->context['user_id'] ?? $session->context['actor_id'] ?? '');
        if ($companyId !== (string) $this->host->tenantCompanyId() || $userId !== (string) $this->host->userId()) {
            return ['ready' => false, 'available' => true, 'session_validated' => false, 'reason_codes' => ['INTERACTION_SESSION_CONTEXT_MISMATCH'], 'status' => $status];
        }
        if (!$session->complete()) return ['ready' => false, 'available' => true, 'session_validated' => false, 'reason_codes' => ['INTERACTION_SESSION_INCOMPLETE'], 'status' => $status];

        $canonical = $this->router->canonical($capability);
        if ($this->router->canonical($session->definition->capability) !== $canonical) {
            return ['ready' => false, 'available' => true, 'session_validated' => false, 'reason_codes' => ['INTERACTION_SESSION_CAPABILITY_MISMATCH'], 'status' => $status];
        }
        $mapped = $this->commandMapper->map($session);
        return [
            'ready' => true,
            'available' => true,
            'session_validated' => true,
            'mapped_command' => $mapped,
            'canonical_capability' => $canonical,
            'workflow_key' => $workflowKey,
            'correlation_id' => (string) ($mapped['metadata']['correlation_id'] ?? $correlation),
            'reason_codes' => [],
            'status' => $status,
        ];
    }
}
