# Troubleshooting

## Certification reports Signal unavailable
Install/rebase the canonical `titan-signal` extension. The runtime bridge also recognizes the historical `TitanSignalEngine` contract during migration, but Blueprint v4.2 dependency identity is `titan-signal`.

## AI Core says provider execution unsupported
Current AI Core v0.2.x publishes health but not the provider execution contract expected by Council. Compatibility execution remains active until Core publishes that boundary.

## Council escalates despite model agreement
Risk is an authority floor. `REQUIRE_APPROVAL`, `REDUCE_AUTHORITY`, or `BLOCK` cannot be overridden by consensus. Strong contradictions and failed validation also escalate.

## A provider repeatedly fails
The provider circuit breaker temporarily opens after the configured failure threshold. It closes after cooldown and permits probing again.

## Installer 1.7.5: MySQL error 1059 on governed validation index

If installation fails while running `2026_08_11_000010_add_governed_validation_fields.php` with MySQL error 1059, use Hotfix 3 or later. The original migration allowed Laravel to infer `titan_model_council_decisions_pre_arbiter_validation_status_index`, which is 65 characters and exceeds MySQL's 64-character identifier limit.

Hotfix 3 uses explicit bounded index names and independently checks/creates indexes after columns. This makes a retry safe when an earlier failed ALTER already created one or more governed-validation columns before the index statement failed.

