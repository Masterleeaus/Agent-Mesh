<?php

declare(strict_types=1);

spl_autoload_register(function(string $class):void{$prefix='App\\Extensions\\TitanAutonomy\\';if(!str_starts_with($class,$prefix))return;$path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($prefix))).'.php';if(is_file($path))require_once $path;});

use App\Extensions\TitanAutonomy\System\Contracts\{ControlPlaneAuditSinkContract,OperationsQueryContract,OperationsReviewStoreContract};
use App\Extensions\TitanAutonomy\System\Services\OperationsReviewService;

$query=new class implements OperationsQueryContract{
 public function receipts(int $tenantCompanyId,array $filters=[],int $limit=100):array{return[];}
 public function receipt(int $tenantCompanyId,string $correlationId):?array{return $tenantCompanyId===42&&$correlationId==='corr-1'?['public_id'=>'E1','tenant_company_id'=>42,'capability'=>'crm.invoice.issue','workflow_key'=>'completed_job_invoice','correlation_id'=>'corr-1']:null;}
 public function feedback(int $tenantCompanyId,string $receiptPublicId,int $limit=100):array{return[];}
};
$store=new class implements OperationsReviewStoreContract{public array $rows=[];public function append(array $review):string{$this->rows[]=$review;return 'V1';}public function forReceipt(int $tenantCompanyId,string $receiptPublicId,int $limit=100):array{return $this->rows;}};
$audit=new class implements ControlPlaneAuditSinkContract{public array $events=[];public function record(array $event):string{$this->events[]=$event;return 'A1';}};
$svc=new OperationsReviewService($query,$store,$audit,'policy-v1');
$result=$svc->record(42,7,'corr-1','acknowledged','Checked with dispatcher; no trust change requested.');
if(($result['review_ref']??null)!=='V1'||count($store->rows)!==1)throw new RuntimeException('Review metadata must be appended separately from autonomy evidence.');
if(($store->rows[0]['tenant_company_id']??null)!==42||($store->rows[0]['user_id']??null)!==7)throw new RuntimeException('Review must remain tenant/user scoped.');
if(count($audit->events)!==1||($audit->events[0]['event_type']??null)!=='autonomy.operations.review')throw new RuntimeException('Operations review must be auditable.');
try{$svc->record(99,7,'corr-1','acknowledged','x');throw new RuntimeException('Cross-tenant review unexpectedly accepted.');}catch(RuntimeException $e){if($e->getMessage()==='Cross-tenant review unexpectedly accepted.')throw $e;}

echo "OK: OperationsReviewServiceSmokeTest\n";
