<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanSignalEngine\System\Data\SignalPrunePreviewToken;
use App\Extensions\TitanSignalEngine\System\Services\PruneCandidateHasher;
use PHPUnit\Framework\TestCase;

final class TransactionalPruningTest extends TestCase
{
    public function test_preview_token_is_tamper_evident_and_bound_to_preview_id(): void
    {
        $previewId = '018f7f47-7c2b-7f3b-8000-111111111111';
        $token = SignalPrunePreviewToken::issue($previewId);
        self::assertSame($previewId, SignalPrunePreviewToken::previewIdFrom($token->plainText));
        self::assertTrue($token->verify($token->plainText));
        self::assertFalse($token->verify($token->plainText . 'x'));
    }

    public function test_candidate_hash_binds_scope_tenant_and_exact_set_not_order(): void
    {
        $hasher = new PruneCandidateHasher();
        $a = $hasher->hash('tenant', 42, ['b', 'a', 'c']);
        self::assertSame($a, $hasher->hash('tenant', 42, ['c', 'b', 'a']));
        self::assertNotSame($a, $hasher->hash('tenant', 43, ['a', 'b', 'c']));
        self::assertNotSame($a, $hasher->hash('tenant', 42, ['a', 'b']));
    }
}
