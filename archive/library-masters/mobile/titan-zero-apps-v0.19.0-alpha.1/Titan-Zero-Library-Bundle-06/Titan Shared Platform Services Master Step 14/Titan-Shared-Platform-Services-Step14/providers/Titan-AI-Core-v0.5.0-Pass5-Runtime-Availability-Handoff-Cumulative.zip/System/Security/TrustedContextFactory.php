<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Security;

use App\Extensions\TitanAICore\System\DTO\RuntimeContext;
use App\Extensions\TitanAICore\System\DTO\TrustedPrincipal;
use App\Extensions\TitanAICore\System\Exceptions\SecurityContextException;

final class TrustedContextFactory
{
    /** @param array<string,mixed> $routingHints */
    public function create(
        TrustedPrincipal $principal,
        string $traceId,
        string $correlationId,
        string $causationId,
        string $rootCausationId,
        string $operationId,
        string $idempotencyKey,
        ?string $claimedTenantCompanyId = null,
        ?string $claimedActorId = null,
        ?string $claimedActorType = null,
        string $privacyClass = 'INTERNAL',
        array $routingHints = [],
    ): RuntimeContext {
        $this->assertClaimMatches('tenant', $claimedTenantCompanyId, $principal->tenantCompanyId);
        $this->assertClaimMatches('actor', $claimedActorId, $principal->actorId);
        $this->assertClaimMatches('actor_type', $claimedActorType, $principal->actorType);

        return new RuntimeContext(
            tenantCompanyId: $principal->tenantCompanyId,
            actor: $principal->toActorContext(),
            traceId: $traceId,
            correlationId: $correlationId,
            causationId: $causationId,
            rootCausationId: $rootCausationId,
            operationId: $operationId,
            idempotencyKey: $idempotencyKey,
            privacyClass: $privacyClass,
            routingHints: $routingHints,
        );
    }

    private function assertClaimMatches(string $kind, ?string $claimed, string $trusted): void
    {
        if ($claimed === null || $claimed === '') {
            return;
        }
        if (hash_equals($trusted, $claimed)) {
            return;
        }

        $code = match ($kind) {
            'tenant' => 'TENANT_SPOOFING_DETECTED',
            'actor' => 'ACTOR_SPOOFING_DETECTED',
            'actor_type' => 'ACTOR_TYPE_SPOOFING_DETECTED',
            default => 'SECURITY_CONTEXT_MISMATCH',
        };

        throw new SecurityContextException($code, 'Untrusted identity claim does not match the authenticated principal.');
    }
}
