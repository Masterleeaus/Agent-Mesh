<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_knowledge_source_versions')) {
            return;
        }

        Schema::table('titan_knowledge_source_versions', function (Blueprint $table): void {
            $table->dropForeign(['source_id']);
        });

        if (! Schema::hasColumn('titan_knowledge_source_versions', 'raw_evidence_storage_ref')) {
            Schema::table('titan_knowledge_source_versions', function (Blueprint $table): void {
                $table->text('raw_evidence_storage_ref')->nullable()->after('content_storage_ref');
            });
        }

        Schema::table('titan_knowledge_source_versions', function (Blueprint $table): void {
            $table->foreign('source_id')
                ->references('id')
                ->on('titan_knowledge_sources')
                ->restrictOnDelete();
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('titan_knowledge_source_versions')) {
            return;
        }

        Schema::table('titan_knowledge_source_versions', function (Blueprint $table): void {
            $table->dropForeign(['source_id']);
        });

        if (Schema::hasColumn('titan_knowledge_source_versions', 'raw_evidence_storage_ref')) {
            Schema::table('titan_knowledge_source_versions', function (Blueprint $table): void {
                $table->dropColumn('raw_evidence_storage_ref');
            });
        }

        Schema::table('titan_knowledge_source_versions', function (Blueprint $table): void {
            $table->foreign('source_id')
                ->references('id')
                ->on('titan_knowledge_sources')
                ->cascadeOnDelete();
        });
    }
};
