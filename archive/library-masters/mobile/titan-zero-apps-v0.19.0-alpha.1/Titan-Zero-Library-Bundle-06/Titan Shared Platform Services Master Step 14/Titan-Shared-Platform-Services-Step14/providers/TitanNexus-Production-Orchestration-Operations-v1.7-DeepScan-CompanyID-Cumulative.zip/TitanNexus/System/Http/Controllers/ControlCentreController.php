<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Http\Controllers;

use App\Extensions\TitanNexus\System\Contracts\NexusControlCentreContract;
use App\Extensions\TitanNexus\System\Contracts\TenantContextResolverContract;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use RuntimeException;

class ControlCentreController
{
    public function __construct(
        private readonly TenantContextResolverContract $tenantContext,
        private readonly NexusControlCentreContract $controlCentre,
    ) {}

    public function overview(Request $request): View { return $this->render($request, 'overview'); }
    public function profile(Request $request): View { return $this->render($request, 'profile'); }
    public function compilations(Request $request): View { return $this->render($request, 'compilations'); }
    public function validation(Request $request): View { return $this->render($request, 'validation'); }
    public function preview(Request $request): View { return $this->render($request, 'preview'); }
    public function history(Request $request): View { return $this->render($request, 'history'); }
    public function diff(Request $request): View { return $this->render($request, 'diff'); }
    public function provisioning(Request $request): View { return $this->render($request, 'provisioning'); }
    public function receipts(Request $request): View { return $this->render($request, 'receipts'); }

    public function detail(Request $request, string $compilationUuid): View
    {
        return $this->render($request, 'compilations', $compilationUuid);
    }

    private function render(Request $request, string $section, ?string $compilationUuid = null): View
    {
        try {
            $tenantCompanyId = $this->tenantContext->resolve($request->user());
            $snapshot = $this->controlCentre->snapshot($tenantCompanyId, $compilationUuid)->toArray();
            return view('titan-nexus::index', [
                'available' => true,
                'section' => $section,
                'snapshot' => $snapshot,
                'message' => null,
            ]);
        } catch (RuntimeException) {
            return view('titan-nexus::index', [
                'available' => false,
                'section' => $section,
                'snapshot' => null,
                'message' => 'Titan Nexus cannot resolve an authorised company context for this session.',
            ]);
        }
    }
}
