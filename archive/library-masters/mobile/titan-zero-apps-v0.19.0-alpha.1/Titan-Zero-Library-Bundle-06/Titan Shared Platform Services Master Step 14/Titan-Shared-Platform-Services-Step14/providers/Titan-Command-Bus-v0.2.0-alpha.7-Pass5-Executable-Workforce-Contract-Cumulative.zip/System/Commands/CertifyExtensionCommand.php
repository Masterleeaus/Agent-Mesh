<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Commands;

use App\Extensions\TitanCommandBus\System\Contracts\CommandBusContract;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;

final class CertifyExtensionCommand extends Command
{
    protected $signature = 'titan:titan-command-bus:certify {--json}';
    protected $description = 'Emit Titan Command Bus host-certification evidence.';

    public function handle(CommandBusContract $bus): int
    {
        $health = $bus->health();
        $evidence = [
            'contract' => 'titan.release-certification.v1',
            'extension' => 'titan-command-bus',
            'version' => '0.2.0-alpha.4',
            'stages' => [
                'MIGRATION_CERTIFIED' => Schema::hasTable('titan_command_receipts') && Schema::hasTable('titan_command_idempotency'),
                'NAVIGATION_CERTIFIED' => Route::has('dashboard.admin.titan.command.bus.index'),
                'RUNTIME_CERTIFIED' => (bool) ($health['readiness'] ?? false),
            ],
            'health' => $health,
        ];
        $json = json_encode($evidence, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $this->line($json);
        return ($evidence['stages']['MIGRATION_CERTIFIED'] && $evidence['stages']['NAVIGATION_CERTIFIED']) ? self::SUCCESS : self::FAILURE;
    }
}
