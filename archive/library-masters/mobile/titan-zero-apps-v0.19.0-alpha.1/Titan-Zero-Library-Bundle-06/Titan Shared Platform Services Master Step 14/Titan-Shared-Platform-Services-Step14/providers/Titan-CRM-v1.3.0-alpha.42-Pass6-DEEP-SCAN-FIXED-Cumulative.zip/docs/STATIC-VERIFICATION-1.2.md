# MagicAI CRM 1.2 Static Verification

## Scope

This report records archive/source verification for the CRM 1.2 development bundle. It does not convert source checks into a claim of live production-host certification.

## Regression suite

The release suite contains the preserved 1.1 regressions plus new 1.2 company-tenancy/Titan platform contracts. Before packaging, the full suite reached **133 passing tests** with no failures. The exact packaged bytes must be re-extracted and rerun before the release artifact is considered complete; the external final report records that final packaged result.

## Source checks reached before packaging

- PHP files checked across the development bundle: **317**
- PHP syntax failures: **0**
- JSON files parsed: **21**
- JSON parse failures: **0**
- JavaScript/MJS files in this development bundle: **0**
- unresolved merge markers: **0**
- active WorkCore runtime references in CRM `System/`, `routes/` and `config/` PHP: **0**
- declared local CRM PHP types inspected for internal imports: **236**
- missing local CRM imports detected: **0**

## Tenant-boundary classification

The final source scan intentionally classifies rather than blindly requiring zero textual hits.

### `where('user_id', ...)`

One runtime query remains intentionally:

- the CRM Chatbot bridge queries **Chatbot 6.5's own `ChatbotCustomer.user_id`** to verify the authoritative Chatbot owner. This is an external Chatbot actor/owner relationship, not CRM tenancy.

CRM-owned business queries use `tenant_company_id`.

### `tenant_id`

Three runtime textual occurrences remain intentionally:

1. Titan Customer v0.13 context compatibility reads the trusted platform context key `tenant_id` supplied by that published contract and immediately resolves it as CRM trusted company scope.
2. an explanatory comment states that this value is trusted platform context, not browser tenant authority.
3. the Interaction Engine bridge strips caller-supplied `tenant_id` before dispatching a CRM capability.

CRM persistence does not use `tenant_id` as its tenant key.

### `company_id`

CRM `company_id` remains the account/customer-company relationship key. The Titan business boundary is `tenant_company_id`. Callers cannot select CRM tenant authority by submitting a CRM account-company identifier.

## WorkCore classification

Active CRM runtime dependencies: **0**.

Textual WorkCore references may remain in:

- historical release/donor documentation;
- `WORKCORE-REMOVAL.md`, which documents removal;
- development plans/tests that explicitly verify WorkCore is absent from runtime.

No WorkCore installation is expected by the 1.2 runtime.

## Migration verification

`tools/verify_crm_migrations.py` reports:

- CRM migrations: **14**
- CRM-owned tables after 1.2: **84**
- migration contract/reversibility verifier: **PASS**

The tenancy table map covers the classified tenant-owned business tables; `crm_tenancy_migration_reviews` is deliberately global diagnostic state and is not a tenant business record.
