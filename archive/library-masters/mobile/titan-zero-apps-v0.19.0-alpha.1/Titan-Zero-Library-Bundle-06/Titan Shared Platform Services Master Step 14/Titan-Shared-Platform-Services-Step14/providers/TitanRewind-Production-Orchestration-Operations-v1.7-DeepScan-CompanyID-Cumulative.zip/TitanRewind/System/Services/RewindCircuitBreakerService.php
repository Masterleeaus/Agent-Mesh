<?php

declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Services;
use App\Extensions\TitanRewind\System\Models\RewindCircuitBreakerState;
use App\Extensions\TitanRewind\System\Resilience\RewindCircuitBreaker;
use RuntimeException;
use Throwable;
final class RewindCircuitBreakerService
{
    public function __construct(private RewindCircuitBreaker $logic) {}
    public function assertAvailable(string $key): void
    {
        $row=RewindCircuitBreakerState::query()->firstOrCreate(['breaker_key'=>$key],['state'=>'CLOSED','failure_count'=>0]);
        $next=$row->next_probe_at?->getTimestamp(); $decision=$this->logic->canAttempt((string)$row->state,$next,time());
        if (($decision['state'] ?? '')==='HALF_OPEN' && $row->state!=='HALF_OPEN') { $row->forceFill(['state'=>'HALF_OPEN'])->save(); }
        if (!($decision['allowed'] ?? false)) throw new RuntimeException("Rewind circuit breaker {$key} is OPEN.");
    }
    public function success(string $key): void
    {
        $state=$this->logic->afterSuccess(); RewindCircuitBreakerState::query()->updateOrCreate(['breaker_key'=>$key],['state'=>$state['state'],'failure_count'=>0,'last_error'=>null,'opened_at'=>null,'next_probe_at'=>null,'last_success_at'=>now()]);
    }
    public function failure(string $key, Throwable $error): void
    {
        $row=RewindCircuitBreakerState::query()->firstOrCreate(['breaker_key'=>$key],['state'=>'CLOSED','failure_count'=>0]);
        $next=$this->logic->afterFailure((string)$row->state,(int)$row->failure_count,time());
        $row->forceFill(['state'=>$next['state'],'failure_count'=>$next['failure_count'],'last_error'=>substr($error->getMessage(),0,2000),'opened_at'=>$next['state']==='OPEN'?($row->opened_at ?? now()):null,'next_probe_at'=>$next['next_probe_at']?now()->setTimestamp($next['next_probe_at']):null])->save();
    }
    public function states(): array { return RewindCircuitBreakerState::query()->orderBy('breaker_key')->cursor()->map(fn($r)=>['key'=>$r->breaker_key,'state'=>$r->state,'failure_count'=>(int)$r->failure_count])->all(); }
}
