<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Adapters\Platform\PlatformReadinessAdapter;
use App\Extensions\TitanNexus\System\Contracts\VerticalDefinitionSourceContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompilationStatus;
use App\Extensions\TitanNexus\System\Domain\RecompilePlanStatus;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Services\DeterministicNexusCompiler;
use App\Extensions\TitanNexus\System\Services\NexusManager;
use App\Extensions\TitanNexus\System\Services\SemanticConfigurationDiffer;
use App\Extensions\TitanNexus\System\Services\SemanticNexusValidator;

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
foreach ([
    '/System/Support/CanonicalJson.php',
    '/System/Support/DeterministicMerge.php',
    '/System/Domain/CompilationStatus.php',
    '/System/Domain/CompilationLifecycleStage.php',
    '/System/Domain/RuntimeReadinessReport.php',
    '/System/Domain/ValidationSeverity.php',
    '/System/Domain/ValidationFinding.php',
    '/System/Domain/ValidationResult.php',
    '/System/Domain/ValueObjects/TraceContext.php',
    '/System/Domain/BusinessProfile.php',
    '/System/Domain/CompiledTitanConfig.php',
    '/System/Domain/VerticalDefinition.php',
    '/System/Domain/SemanticChangeKind.php',
    '/System/Domain/SemanticChangeDisposition.php',
    '/System/Domain/SemanticDiffEntry.php',
    '/System/Domain/ConfigurationDiff.php',
    '/System/Domain/RecompilePlanStatus.php',
    '/System/Domain/RecompilePlan.php',
    '/System/Domain/CompilationPreview.php',
    '/System/Domain/NexusCompilation.php',
    '/System/Contracts/NexusCompilerContract.php',
    '/System/Contracts/ConfigurationDifferContract.php',
    '/System/Contracts/VerticalDefinitionSourceContract.php',
    '/System/Contracts/PlatformReadinessSourceContract.php',
    '/System/Contracts/NexusValidatorContract.php',
    '/System/Contracts/NexusManagerContract.php',
    '/System/Adapters/Platform/PlatformReadinessAdapter.php',
    '/System/Exceptions/NexusValidationException.php',
    '/System/Services/DeterministicNexusCompiler.php',
    '/System/Services/SemanticConfigurationDiffer.php',
    '/System/Services/SemanticNexusValidator.php',
    '/System/Services/NexusManager.php',
] as $file) {
    require_once $root . $file;
}

function rcCheck(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

function expectRcInvalid(callable $callback, string $message): void
{
    try {
        $callback();
    } catch (InvalidArgumentException|LogicException) {
        return;
    }
    fwrite(STDERR, "FAIL: expected tenant/lifecycle rejection: {$message}\n");
    exit(1);
}

function profile(array $sections, int $tenant = 42): BusinessProfile
{
    return BusinessProfile::fromArray([
        'tenant_company_id' => $tenant,
        'profile_version' => '2.0.0',
        'vertical_id' => 'cleaning',
        'vertical_version' => '2026.08',
        'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
        'timezone' => 'Australia/Melbourne',
        'sections' => $sections,
    ]);
}

function trace(int $tenant, string $seed): TraceContext
{
    $a = substr(str_pad($seed, 8, '1'), 0, 8);
    return TraceContext::fromArray([
        'tenant_company_id' => $tenant,
        'trace_id' => $a . '-1111-4111-8111-111111111111',
        'correlation_id' => '22222222-2222-4222-8222-222222222222',
        'causation_id' => '33333333-3333-4333-8333-333333333333',
    ]);
}

$source = new class implements VerticalDefinitionSourceContract {
    public function resolve(BusinessProfile $profile): VerticalDefinition
    {
        return VerticalDefinition::fromArray([
            'vertical_id' => $profile->verticalId(),
            'vertical_version' => $profile->verticalVersion(),
            'knowledge_snapshot_version' => 'au-vic-2026.08',
            'sections' => [
                'billing' => ['currency' => 'AUD', 'tax_mode' => 'exclusive'],
                'compliance' => ['locked' => false],
            ],
            'validation' => ['require_knowledge_snapshot' => true],
            'recompile_policy' => [
                'requires_approval_paths' => ['sections.billing.currency'],
                'blocked_paths' => ['sections.compliance.locked'],
            ],
        ]);
    }
};

$compiler = new DeterministicNexusCompiler('0.5.0');
$manager = new NexusManager(
    $compiler,
    $source,
    new SemanticNexusValidator(new PlatformReadinessAdapter()),
    new SemanticConfigurationDiffer(),
);
$currentDraft = $manager->newDraft(profile(['billing' => ['currency' => 'AUD']]), trace(42, 'aaaaaaaa'), '44444444-4444-4444-8444-444444444444');
$current = $manager->compileDraft($currentDraft, '1');
rcCheck($current->status() === CompilationStatus::Compiled, 'baseline current compilation is compiled');

$approvalPlan = $manager->planRecompile(
    $current,
    profile(['billing' => ['currency' => 'NZD']]),
    trace(42, 'bbbbbbbb'),
    '55555555-5555-4555-8555-555555555555',
    '2',
);
rcCheck($approvalPlan->status() === RecompilePlanStatus::RequiresApproval, 'approval path produces requires_approval plan');
rcCheck($approvalPlan->candidate()->parentCompilationUuid() === $current->compilationUuid(), 'candidate points to exact parent compilation');
rcCheck($approvalPlan->candidate()->dryRun(), 'recompile candidate is a dry run');
rcCheck($approvalPlan->candidate()->configurationDiff()?->requiresApproval() === true, 'candidate carries approval diff');
rcCheck($approvalPlan->currentOutputHash() === $current->compiledConfiguration()?->outputHash(), 'plan anchors current output hash');
rcCheck($current->configurationDiff() === null, 'planning does not mutate current compilation');

$blockedPolicyPlan = $manager->planRecompile(
    $current,
    profile(['billing' => ['currency' => 'AUD'], 'compliance' => ['locked' => true]]),
    trace(42, 'cccccccc'),
    '66666666-6666-4666-8666-666666666666',
    '2',
);
rcCheck($blockedPolicyPlan->status() === RecompilePlanStatus::Blocked, 'blocked diff policy blocks plan');
rcCheck($blockedPolicyPlan->diff()?->hasBlocked() === true, 'blocked plan retains diff evidence');

$blockedValidationPlan = $manager->planRecompile(
    $current,
    profile(['billing' => ['currency' => 'AUD'], 'integration' => ['api_key' => 'forbidden']]),
    trace(42, 'dddddddd'),
    '77777777-7777-4777-8777-777777777777',
    '2',
);
rcCheck($blockedValidationPlan->status() === RecompilePlanStatus::Blocked, 'validation errors block recompile plan');
rcCheck($blockedValidationPlan->diff() === null, 'validation-blocked plan has no semantic diff because no candidate config is compiled');
rcCheck($blockedValidationPlan->candidate()->compiledConfiguration() === null, 'validation-blocked candidate has no compiled output');
rcCheck($blockedValidationPlan->candidate()->validationResult()?->hasErrors() === true, 'validation evidence is retained');

$readyPlan = $manager->planRecompile(
    $current,
    profile(['billing' => ['currency' => 'AUD']]),
    trace(42, 'eeeeeeee'),
    '88888888-8888-4888-8888-888888888888',
    '2',
);
rcCheck($readyPlan->status() === RecompilePlanStatus::Ready, 'unchanged semantic config is ready');
rcCheck($readyPlan->diff()?->hasChanges() === false, 'unchanged config reports no semantic changes');
rcCheck($readyPlan->fingerprint() === App\Extensions\TitanNexus\System\Domain\RecompilePlan::fromArray($readyPlan->toArray(), $readyPlan->candidate())->fingerprint(), 'recompile plan round-trip preserves fingerprint');

expectRcInvalid(static fn () => $manager->planRecompile(
    $current,
    profile(['billing' => ['currency' => 'AUD']], 99),
    trace(99, 'ffffffff'),
    '99999999-9999-4999-8999-999999999999',
    '2',
), 'updated profile cannot escape current tenant');

expectRcInvalid(static fn () => $manager->planRecompile(
    $current,
    profile(['billing' => ['currency' => 'AUD']]),
    trace(42, 'abababab'),
    $current->compilationUuid(),
    '2',
), 'child compilation uuid cannot equal parent');

rcCheck(($manager->health()['status'] ?? null) === 'UNAVAILABLE', 'health reports truthful unavailable status without runtime dependencies');

fwrite(STDOUT, "PASS: Titan Nexus standalone recompile planning checks\n");
