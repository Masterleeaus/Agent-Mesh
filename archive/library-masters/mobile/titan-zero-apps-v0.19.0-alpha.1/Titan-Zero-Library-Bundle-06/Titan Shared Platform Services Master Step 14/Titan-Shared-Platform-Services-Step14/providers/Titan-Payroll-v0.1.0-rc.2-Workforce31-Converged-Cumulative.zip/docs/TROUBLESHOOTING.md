# Troubleshooting

Readiness reports only redacted dependency state. If tenant context, database or governance is unavailable, fail closed for domain writes.
