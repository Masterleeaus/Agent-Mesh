<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Models\KnowledgeSourceVersion;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeAccessContext;
use Illuminate\Database\Eloquent\Builder;
use InvalidArgumentException;

final class EloquentKnowledgeSourceVersionRepository implements KnowledgeSourceVersionRepositoryContract
{
    public function __construct(private readonly KnowledgeSourceScopeQuery $scopeQuery)
    {
    }

    public function findVisibleById(KnowledgeAccessContext $context, int $versionId): ?KnowledgeSourceVersion
    {
        if ($versionId <= 0) {
            throw new InvalidArgumentException('versionId must be a positive integer.');
        }

        return KnowledgeSourceVersion::query()
            ->with(['source.jurisdiction:id,code,name'])
            ->whereKey($versionId)
            ->whereHas('source', function (Builder $sourceQuery) use ($context): void {
                $this->scopeQuery->apply($sourceQuery, $context);
            })
            ->first();
    }
}
