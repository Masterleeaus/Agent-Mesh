<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Support\CrmNormalizer;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class LeadLifecycleService
{
    public function __construct(
        private ConnectionInterface $db,
        private CrmActivityRecorder $activities,
        private CrmIdentityAuthorityService $identity,
        private CrmDuplicateReviewService $duplicateReviews,
        private CrmDuplicateDetector $duplicates,
    ) {}

    public function update(int $userId, string $publicId, int $actorUserId, array $data): array
    {
        $lead = $this->lead($userId, $publicId);
        $allowed = ['name','email','phone','company_name','notes','status','source','owner_user_id','priority','follow_up_at'];
        $updates = array_intersect_key($data, array_flip($allowed));
        if (array_key_exists('email', $updates)) { $updates['normalized_email'] = CrmNormalizer::email($updates['email']); $updates['email'] = $updates['normalized_email']; }
        if (array_key_exists('phone', $updates)) { $updates['normalized_phone'] = CrmNormalizer::phone($updates['phone']); $updates['phone'] = $updates['normalized_phone']; }
        if ($updates !== []) {
            $updates['updated_at'] = now();
            $this->db->table(config('crm.tables.leads'))->where('id', $lead->id)->update($updates);
            $this->activities->record($userId, 'lead', $publicId, 'updated', 'Lead updated', null, null, null, null, $actorUserId, ['fields'=>array_keys($updates)]);
        }
        $current=$this->lead($userId,$publicId);$root=$this->identity->ensureRootForLead($userId,$publicId);
        $this->identity->syncSubjectIdentities($userId,'lead',$publicId,$root,$current->email??null,$current->phone??null);foreach($this->duplicates->leadCandidates($userId,$current->email??null,$current->phone??null) as $candidate)if(isset($candidate['public_id'])&&(string)$candidate['public_id']!==$publicId)$this->duplicateReviews->queueForPair($userId,'lead',$publicId,'lead',(string)$candidate['public_id']);
        return (array)$current;
    }

    public function convert(int $userId, string $publicId, int $actorUserId): array
    {
        return $this->db->transaction(function () use ($userId, $publicId, $actorUserId): array {
            $tenant=CrmCompanyScope::companyId($userId);
            $lead = $this->db->table(config('crm.tables.leads'))->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->lockForUpdate()->first();
            if ($lead === null) throw ValidationException::withMessages(['lead'=>['Lead not found.']]);
            if ($lead->converted_company_id !== null) return $this->snapshot($userId, $publicId);

            $resolution=$this->duplicateReviews->guardLeadConversion($userId,$publicId);
            $root=(string)($lead->customer_unification_id??'');if($root==='')$root=$this->identity->ensureRootForLead($userId,$publicId);
            $company=null;$contact=null;$contactNeedsCompany=false;$reused=false;$decision='create_new';

            if(($resolution['status']??'')==='use_existing'){
                $candidateType=(string)$resolution['candidate_type'];$candidateId=(string)$resolution['candidate_public_id'];$reused=true;$decision='use_existing';
                if($candidateType==='company'){
                    $company=$this->db->table('crm_companies')->where('company_id',$tenant)->where('public_id',$candidateId)->whereNull('deleted_at')->lockForUpdate()->first();
                    if(!$company)throw ValidationException::withMessages(['duplicate_review'=>['Resolved company no longer exists.']]);
                    $root=(string)($company->customer_unification_id??'');if($root==='')$root=$this->identity->ensureRootForCompany($userId,(string)$company->public_id);
                    $contact=$this->matchingContact($tenant,$root,$lead);
                } elseif($candidateType==='contact'){
                    $contact=$this->db->table('crm_contacts')->where('company_id',$tenant)->where('public_id',$candidateId)->whereNull('deleted_at')->lockForUpdate()->first();
                    if(!$contact)throw ValidationException::withMessages(['duplicate_review'=>['Resolved contact no longer exists.']]);
                    $root=(string)($contact->customer_unification_id??'');if($root==='')$root=$this->identity->ensureRootForContact($userId,(string)$contact->public_id,$contact->customer_company_id?(int)$contact->customer_company_id:null);
                    if($contact->customer_company_id){$company=$this->db->table('crm_companies')->where('company_id',$tenant)->where('id',$contact->customer_company_id)->whereNull('deleted_at')->lockForUpdate()->first();if(!$company)$contactNeedsCompany=true;}else{$contactNeedsCompany=true;}
                }
            }

            if(!$company){
                $companyPublicId=(string)Str::ulid();
                $companyId=$this->db->table('crm_companies')->insertGetId([
                    'public_id'=>$companyPublicId,'customer_unification_id'=>$root,'company_id'=>$tenant,'user_id'=>CrmCompanyScope::actorUserId($userId),
                    'name'=>$lead->company_name ?: $lead->name,'legal_name'=>$lead->company_name,'email'=>$lead->email,'normalized_email'=>$lead->normalized_email,
                    'phone'=>$lead->phone,'normalized_phone'=>$lead->normalized_phone,'notes'=>$lead->notes,'status'=>'active','owner_user_id'=>$lead->owner_user_id,'created_at'=>now(),'updated_at'=>now(),
                ]);
                $company=$this->db->table('crm_companies')->where('id',$companyId)->first();
                if($contact && (!$contact->customer_company_id || $contactNeedsCompany)){$this->db->table('crm_contacts')->where('id',$contact->id)->update(['customer_company_id'=>$companyId,'customer_unification_id'=>$root,'updated_at'=>now()]);$contact=$this->db->table('crm_contacts')->where('id',$contact->id)->first();}
            }
            $companyPublicId=(string)$company->public_id;$companyId=(int)$company->id;

            if(!$contact && ($lead->email || $lead->phone)){
                $contactPublicId=(string)Str::ulid();
                $contactId=$this->db->table('crm_contacts')->insertGetId([
                    'public_id'=>$contactPublicId,'customer_unification_id'=>$root,'company_id'=>$tenant,'user_id'=>CrmCompanyScope::actorUserId($userId),'customer_company_id'=>$companyId,
                    'first_name'=>$lead->name,'email'=>$lead->email,'normalized_email'=>$lead->normalized_email,'phone'=>$lead->phone,'normalized_phone'=>$lead->normalized_phone,
                    'is_primary'=>true,'created_at'=>now(),'updated_at'=>now(),
                ]);
                $contact=$this->db->table('crm_contacts')->where('id',$contactId)->first();
            }
            $contactPublicId=$contact?(string)$contact->public_id:null;

            $this->db->table('crm_leads')->where('id',$lead->id)->update(['customer_unification_id'=>$root,'status'=>'converted','converted_company_id'=>$companyId,'converted_company_public_id'=>$companyPublicId,'converted_contact_public_id'=>$contactPublicId,'converted_customer_unification_id'=>$root,'converted_at'=>now(),'updated_at'=>now()]);
            $this->identity->syncSubjectIdentities($userId,'lead',$publicId,$root,$lead->email??null,$lead->phone??null);
            $this->identity->syncSubjectIdentities($userId,'company',$companyPublicId,$root,$company->email??$lead->email??null,$company->phone??$lead->phone??null);
            if($contact)$this->identity->syncSubjectIdentities($userId,'contact',$contactPublicId,$root,$contact->email??$lead->email??null,$contact->phone??$lead->phone??null);

            $copied=$this->copySubjectMetadata($tenant,$publicId,$companyPublicId,$contactPublicId);
            $conversion_map=[
                'version'=>'2.0','lead_public_id'=>$publicId,'customer_unification_id'=>$root,'decision'=>$decision,'reused_existing'=>$reused,
                'company'=>['public_id'=>$companyPublicId,'fields'=>['company_name|name'=>'name','email'=>'email','phone'=>'phone','notes'=>'notes','owner_user_id'=>'owner_user_id']],
                'contact'=>$contactPublicId?['public_id'=>$contactPublicId,'fields'=>['name'=>'first_name','email'=>'email','phone'=>'phone']]:null,
                'copied_notes'=>$copied['notes'],'scalar_lead_note'=>$copied['scalar_lead_note'],'copied_tags'=>$copied['tags'],'copied_custom_fields'=>$copied['custom_fields'],'custom_field_mappings'=>$copied['custom_field_mappings'],'converted_at'=>now()->toIso8601String(),
            ];
            $this->db->table('crm_leads')->where('id',$lead->id)->update(['conversion_map'=>json_encode($conversion_map,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),'updated_at'=>now()]);
            $this->activities->record($userId,'lead',$publicId,'converted','Lead converted',null,null,null,now()->toDateTimeString(),$actorUserId,['company_public_id'=>$companyPublicId,'contact_public_id'=>$contactPublicId,'customer_unification_id'=>$root,'decision'=>$decision]);
            $result=$this->snapshot($userId,$publicId);$result['company_public_id']=$companyPublicId;$result['contact_public_id']=$contactPublicId;$result['customer_unification_id']=$root;return $result;
        },3);
    }

    private function matchingContact(int $tenant,string $root,object $lead): ?object
    {
        $q=$this->db->table('crm_contacts')->where('company_id',$tenant)->where('customer_unification_id',$root)->whereNull('deleted_at');
        if($lead->normalized_email||$lead->normalized_phone)$q->where(function($x)use($lead){if($lead->normalized_email)$x->orWhere('normalized_email',$lead->normalized_email);if($lead->normalized_phone)$x->orWhere('normalized_phone',$lead->normalized_phone);});
        return $q->first();
    }

    private function copySubjectMetadata(int $tenant,string $leadId,string $companyId,?string $contactId): array
    {
        $targets=array_values(array_filter([
            ['type'=>'company','id'=>$companyId],
            $contactId?['type'=>'contact','id'=>$contactId]:null,
        ]));
        $result=['notes'=>0,'scalar_lead_note'=>0,'tags'=>0,'custom_fields'=>0,'custom_field_mappings'=>[]];

        if($this->db->getSchemaBuilder()->hasTable('crm_notes')){
            $lead=$this->db->table('crm_leads')->where('company_id',$tenant)->where('public_id',$leadId)->first();
            $scalarNote=trim((string)($lead->notes??''));
            if($scalarNote!==''){
                foreach($targets as $target){
                    $this->db->table('crm_notes')->insert([
                        'public_id'=>(string)Str::ulid(),'company_id'=>$tenant,'user_id'=>$lead->user_id,
                        'subject_type'=>$target['type'],'subject_public_id'=>$target['id'],'body'=>$scalarNote,
                        'is_pinned'=>false,'created_by_user_id'=>$lead->user_id,'created_at'=>now(),'updated_at'=>now(),
                    ]);
                    $result['notes']++;$result['scalar_lead_note']++;
                }
            }
            foreach($this->db->table('crm_notes')->where('company_id',$tenant)->where('subject_type','lead')->where('subject_public_id',$leadId)->whereNull('deleted_at')->get() as $row){
                foreach($targets as $target){
                    $this->db->table('crm_notes')->insert([
                        'public_id'=>(string)Str::ulid(),'company_id'=>$tenant,'user_id'=>$row->user_id,
                        'subject_type'=>$target['type'],'subject_public_id'=>$target['id'],'body'=>$row->body,
                        'is_pinned'=>$row->is_pinned,'created_by_user_id'=>$row->created_by_user_id,
                        'created_at'=>now(),'updated_at'=>now(),
                    ]);
                    $result['notes']++;
                }
            }
        }

        if($this->db->getSchemaBuilder()->hasTable('crm_taggables')){
            foreach($this->db->table('crm_taggables')->where('company_id',$tenant)->where('subject_type','lead')->where('subject_public_id',$leadId)->get() as $row){
                foreach($targets as $target){
                    $result['tags']+=$this->db->table('crm_taggables')->insertOrIgnore([
                        'company_id'=>$tenant,'user_id'=>$row->user_id,'tag_public_id'=>$row->tag_public_id,
                        'subject_type'=>$target['type'],'subject_public_id'=>$target['id'],'created_at'=>now(),
                    ]);
                }
            }
        }

        if($this->db->getSchemaBuilder()->hasTable('crm_custom_fields') && $this->db->getSchemaBuilder()->hasTable('crm_custom_field_values')){
            foreach($this->db->table('crm_custom_field_values')->where('company_id',$tenant)->where('subject_type','lead')->where('subject_public_id',$leadId)->get() as $valueRow){
                $sourceField=$this->db->table('crm_custom_fields')->where('company_id',$tenant)->where('public_id',$valueRow->field_public_id)->where('subject_type','lead')->whereNull('deleted_at')->first();
                if(!$sourceField)continue;
                foreach($targets as $target){
                    $targetField=$this->targetCustomField($tenant,$sourceField,$target['type']);
                    $inserted=$this->db->table('crm_custom_field_values')->insertOrIgnore([
                        'company_id'=>$tenant,'user_id'=>$valueRow->user_id,
                        'field_public_id'=>$targetField['public_id'],'subject_type'=>$target['type'],'subject_public_id'=>$target['id'],
                        'value'=>$valueRow->value,'created_at'=>now(),'updated_at'=>now(),
                    ]);
                    $result['custom_fields']+=$inserted;
                    $result['custom_field_mappings'][]=[
                        'source_field_public_id'=>(string)$sourceField->public_id,
                        'source_key'=>(string)$sourceField->key,
                        'target_subject_type'=>$target['type'],
                        'target_field_public_id'=>$targetField['public_id'],
                        'target_created'=>$targetField['created'],
                        'value_copied'=>$inserted===1,
                    ];
                }
            }
        }
        return $result;
    }

    private function targetCustomField(int $tenant,object $sourceField,string $targetType): array
    {
        $existing=$this->db->table('crm_custom_fields')->where('company_id',$tenant)->where('subject_type',$targetType)->where('key',(string)$sourceField->key)->whereNull('deleted_at')->first();
        if($existing)return ['public_id'=>(string)$existing->public_id,'created'=>false];
        $publicId=(string)Str::ulid();
        $this->db->table('crm_custom_fields')->insert([
            'public_id'=>$publicId,'company_id'=>$tenant,'user_id'=>$sourceField->user_id,
            'subject_type'=>$targetType,'name'=>$sourceField->name,'key'=>$sourceField->key,
            'field_type'=>$sourceField->field_type,'is_required'=>$sourceField->is_required,'sort_order'=>$sourceField->sort_order,
            'options'=>$sourceField->options,'created_at'=>now(),'updated_at'=>now(),
        ]);
        return ['public_id'=>$publicId,'created'=>true];
    }

    private function lead(int $userId,string $publicId): object{$lead=$this->db->table(config('crm.tables.leads'))->where('company_id',CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at')->first();if($lead===null)throw ValidationException::withMessages(['lead'=>['Lead not found.']]);return $lead;}
    private function snapshot(int $userId,string $publicId): array{return (array)$this->lead($userId,$publicId);}
}
