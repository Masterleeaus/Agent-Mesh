<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Middleware;

use App\Extensions\Crm\System\Integrations\CrmApiKeyService;
use App\Extensions\Crm\System\Tenancy\{CrmCompanyContextResolver,CrmCompanyScope};
use Closure;
use Illuminate\Http\Request;

final class AuthenticateCrmApiKey
{
    public function __construct(
        private CrmApiKeyService $keys,
        private CrmCompanyContextResolver $contexts,
        private CrmCompanyScope $companyScope,
    ) {}

    public function handle(Request $request,Closure $next,?string $scope=null)
    {
        $secret=(string)($request->bearerToken() ?: $request->header('X-CRM-Key',''));
        abort_if($secret==='',401,'CRM API key required.');
        $key=$this->keys->resolve($secret,$scope,$request->ip());
        $companyId=(int)($key['company_id']??0);
        abort_if($companyId<=0,401,'CRM API key has no company context.');

        $request->attributes->set('crm_api_user_id',(int)$key['user_id']);
        $request->attributes->set('crm_api_scopes',$key['scopes']);
        $request->attributes->set('crm_api_key_public_id',$key['public_id']);
        $request->attributes->set('company_id',$companyId);

        // The hash-authenticated API-key row is the trusted tenant source. The
        // historical issuer user_id is actor provenance, never tenant authority.
        $context=$this->contexts->fromTrustedPlatform(
            $companyId,
            (int)$key['user_id'],
            'api_key',
            permissions:(array)$key['scopes'],
            sourceSurface:'api',
            membershipVerified:true,
        );
        return $this->companyScope->runWith($context,fn()=>$next($request));
    }
}
