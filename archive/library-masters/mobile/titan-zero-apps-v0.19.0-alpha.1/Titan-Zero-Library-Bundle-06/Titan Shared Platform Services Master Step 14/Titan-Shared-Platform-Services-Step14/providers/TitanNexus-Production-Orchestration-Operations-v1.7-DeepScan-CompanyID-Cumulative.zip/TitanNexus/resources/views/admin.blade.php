@extends('panel.layout.app')

@section('content')
<div class="container-fluid py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
        <div><h1 class="mb-1">Titan Nexus — Admin Diagnostics</h1><p class="text-muted mb-0">Read-only runtime and tenant-context diagnostics. Provisioning mutations remain behind Risk, Governance, Assurance, Autonomy and Command Bus.</p></div>
        <a class="btn btn-primary btn-sm" href="{{ route('dashboard.user.titan.nexus.overview') }}">Open Control Centre</a>
    </div>
    <div class="card mb-4"><div class="card-header"><h2 class="card-title mb-0">Runtime health</h2></div><div class="card-body">
        <div class="row g-3 mb-3">
            <div class="col-md-3"><div class="border rounded p-3"><div class="text-muted small">Status</div><strong>{{ $health['status'] ?? 'UNKNOWN' }}</strong></div></div>
            <div class="col-md-3"><div class="border rounded p-3"><div class="text-muted small">Available capabilities</div><strong>{{ count($health['available_capabilities'] ?? []) }}</strong></div></div>
            <div class="col-md-3"><div class="border rounded p-3"><div class="text-muted small">Unavailable capabilities</div><strong>{{ count($health['unavailable_capabilities'] ?? []) }}</strong></div></div>
            <div class="col-md-3"><div class="border rounded p-3"><div class="text-muted small">Human execution</div><strong>{{ ($health['execution_modes']['human'] ?? false) ? 'READY' : 'UNAVAILABLE' }}</strong></div></div>
        </div>
        <h3 class="h5">Execution modes</h3><pre class="text-wrap">{{ json_encode($health['execution_modes'] ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) }}</pre>
        <h3 class="h5">Dependencies</h3><pre class="text-wrap">{{ json_encode($health['dependencies'] ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) }}</pre>
        <h3 class="h5">Available capabilities</h3><pre class="text-wrap">{{ json_encode($health['available_capabilities'] ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) }}</pre>
        <h3 class="h5">Unavailable capabilities</h3><pre class="mb-0 text-wrap">{{ json_encode($health['unavailable_capabilities'] ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) }}</pre>
    </div></div>
    @if($message)<div class="alert alert-warning">{{ $message }}</div>@elseif($snapshot)
        <div class="card"><div class="card-header"><h2 class="card-title mb-0">Current authorised tenant</h2></div><div class="card-body"><p class="mb-1"><strong>Company:</strong> #{{ $snapshot['tenant_company_id'] }}</p><p class="mb-0"><strong>Compilations:</strong> {{ $snapshot['summary']['total_compilations'] ?? 0 }} · <strong>Provisioning:</strong> {{ $snapshot['summary']['provisioning']['status'] ?? 'Not planned' }}</p></div></div>
    @endif
</div>
@endsection
