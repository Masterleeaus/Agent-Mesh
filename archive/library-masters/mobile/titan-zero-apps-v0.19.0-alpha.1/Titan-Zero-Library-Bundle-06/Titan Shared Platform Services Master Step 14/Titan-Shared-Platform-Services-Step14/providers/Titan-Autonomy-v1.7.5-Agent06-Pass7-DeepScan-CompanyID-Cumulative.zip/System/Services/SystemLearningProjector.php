<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

/**
 * Produces a deliberately narrow, abstracted record for optional system-wide learning.
 * It never copies the raw tenant event. New fields must be explicitly allow-listed.
 */
final class SystemLearningProjector
{
    private const ROOT_ALLOWLIST = [
        'capability',
        'workflow_key',
        'risk',
        'learning_label',
        'reason_codes',
        'tool_key',
        'error_code',
    ];

    private const DIMENSION_ALLOWLIST = [
        'vertical',
        'workflow_family',
        'risk_band',
        'value_band',
        'exception_type',
        'integration_type',
        'model_family',
    ];

    public function project(array $event): array
    {
        $projected = [];
        foreach (self::ROOT_ALLOWLIST as $key) {
            if (array_key_exists($key, $event)) {
                $projected[$key] = $event[$key];
            }
        }

        $dimensions = [];
        foreach ((array) ($event['context_dimensions'] ?? []) as $key => $value) {
            if (in_array((string) $key, self::DIMENSION_ALLOWLIST, true) && (is_scalar($value) || $value === null)) {
                $dimensions[(string) $key] = $value;
            }
        }
        if ($dimensions !== []) {
            $projected['context_dimensions'] = $dimensions;
        }

        return $projected;
    }
}
