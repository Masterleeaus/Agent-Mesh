<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalDelivery extends Model
{
    protected $table = 'titan_signal_deliveries';
    protected $guarded = [];

    protected $casts = [
        'tenant_company_id' => 'integer',
        'schema_version' => 'integer',
        'attempt_count' => 'integer',
        'available_at' => 'immutable_datetime',
        'queued_at' => 'immutable_datetime',
        'reserved_at' => 'immutable_datetime',
        'lease_expires_at' => 'immutable_datetime',
        'processing_started_at' => 'immutable_datetime',
        'claim_version' => 'integer',
        'delivered_at' => 'immutable_datetime',
        'dead_lettered_at' => 'immutable_datetime',
        'dead_letter_resolved_at' => 'immutable_datetime',
        'redrive_count' => 'integer',
        'last_redriven_at' => 'immutable_datetime',
    ];
}
