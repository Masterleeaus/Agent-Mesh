# Titan MCP 1.5.8 Build Verification

Release focus: direct runtime binding of Super Admin Overview cards to host semantic theme variables.

Verification gates:

- Installer 1.7.8 flat-root manifest contract.
- Super Admin shared-menu synchronization on Website1408 host schema.
- Literal menu labels without ampersands.
- Active host theme owns card background, foreground and border through `--card-background`, `--card-foreground` and `--card-border` runtime variables.
- MCP keeps the semantic utility classes for compatibility but does not depend on Tailwind compiling extension-only utilities.
- MCP stylesheet contains no fixed light/dark colours and no `color-mix()` synthesis.
- Native site-theme Overview cards load through the CSP-safe external stylesheet route.
- Direct Overview navigation to all MCP administration surfaces.
- Livewire ExtendBlade-compatible templates.
- Existing MCP tool, ticket, backup, authorization and transport regressions.
- Full PHP lint, JSON parsing and package integrity verification.
