<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ControlCentre;

use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceReadSourceRegistry;
use Throwable;

final class ControlCentreSourceReader
{
    public function __construct(private readonly GovernanceReadSourceRegistry $sources) {}

    /** @return array<string,array<string,mixed>> */
    public function all(int $tenantCompanyId, array $context = []): array
    {
        $rows=[];
        foreach($this->sources->all() as $key=>$source){
            try{
                $snapshot=$source->snapshot($tenantCompanyId,$context);
                if(isset($snapshot['tenant_company_id']) && (int)$snapshot['tenant_company_id']!==$tenantCompanyId){
                    $rows[$key]=['source'=>$key,'required'=>$source->required(),'status'=>'INVALID','reason'=>'IDENTITY_MISMATCH','observed_at'=>$snapshot['observed_at']??null,'control_centre'=>[]];
                    continue;
                }
                $status=strtoupper(trim((string)($snapshot['status']??'UNAVAILABLE')));
                $rows[$key]=[
                    'source'=>$key,
                    'required'=>$source->required(),
                    'status'=>$status===''?'UNAVAILABLE':$status,
                    'reason'=>$snapshot['reason']??null,
                    'observed_at'=>$snapshot['observed_at']??null,
                    'control_centre'=>is_array($snapshot['control_centre']??null)?$snapshot['control_centre']:[],
                ];
            }catch(Throwable){
                $rows[$key]=['source'=>$key,'required'=>$source->required(),'status'=>'UNAVAILABLE','reason'=>'SOURCE_READ_FAILED','observed_at'=>null,'control_centre'=>[]];
            }
        }
        return $rows;
    }
}
