<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_model_council_decisions')) { return; }
        Schema::create('titan_model_council_decisions', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
            $table->uuid('trace_id')->nullable()->index();
            $table->uuid('correlation_id')->nullable()->index();
            $table->string('type', 120)->default('record')->index();
            $table->string('status', 40)->default('scaffold')->index();
            $table->json('payload')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_model_council_decisions');
    }
};
