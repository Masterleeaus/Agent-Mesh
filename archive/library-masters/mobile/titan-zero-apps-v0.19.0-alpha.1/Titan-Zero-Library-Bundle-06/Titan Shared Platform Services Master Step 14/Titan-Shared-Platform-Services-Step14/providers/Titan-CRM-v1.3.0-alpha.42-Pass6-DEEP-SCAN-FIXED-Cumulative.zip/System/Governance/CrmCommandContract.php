<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

final class CrmCommandContract
{
    public const VERSION = 3;
    public const COMPENSATION_NONE = 'not_required';
    public const COMPENSATION_AVAILABLE = 'available';
    public const COMPENSATION_EXTERNAL = 'external_owner';

    /** @return array<string,mixed> */
    public static function requestEnvelope(CrmCommandRequest $request): array
    {
        return [
            'command_contract_version'=>self::VERSION,
            'command_id'=>$request->commandId,
            'company_id'=>$request->companyId,
            'actor'=>[
                'user_id'=>$request->actorUserId,
                'type'=>$request->actorType,
            ],
            'capability'=>$request->capability,
            'source'=>$request->source,
            'trace_id'=>$request->traceId,
            'correlation_id'=>$request->correlationId,
            'causation_id'=>$request->causationId,
            'idempotency_key'=>$request->idempotencyKey,
            'expected_entity_version'=>$request->expectedEntityVersion,
        ];
    }
}
