<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\DTOs;

final readonly class GovernedCapabilityCommand
{
    public function __construct(
        public string $capability,
        public array $payload,
        public ?string $workflowKey = null,
        public ?string $correlationId = null,
        public ?string $interactionId = null,
        public ?string $sessionId = null,
        public ?string $idempotencyKey = null,
        public bool $trustedInteractionMapped = false,
    ) {}
}
