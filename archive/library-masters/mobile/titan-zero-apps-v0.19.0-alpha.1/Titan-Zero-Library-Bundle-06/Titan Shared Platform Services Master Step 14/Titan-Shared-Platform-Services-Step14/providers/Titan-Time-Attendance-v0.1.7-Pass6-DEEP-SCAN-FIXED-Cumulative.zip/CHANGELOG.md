# 0.1.5 — Agent-01 Pass 3

- Added canonical cross-extension execution envelope, correlation/causation, idempotency scope, authority/provenance/evidence traceability, duplicate suppression and deferred unknown-outcome semantics.

# Changelog

## 0.1.1 - 2026-08-15

- Added extension-owned Titan/MagicAI user navigation for Time & Attendance.
- Added Blueprint-v3 MenuContributionRegistry / generic ContributionRegistry registration.
- Added idempotent `menus` table synchronization that preserves existing administrator order/enabled state.
- Added safe MagicAI `MenuService::regenerate()` cache invalidation when navigation changes.
- Added `titan-time-attendance:host-sync` for explicit post-install/upgrade menu repair.
- Kept menu access outside MagicAI plan gating; extension permission checks remain authoritative.


## 0.1.0 — Final Production-Integration Release

- Aligned the root package contract with Titan Custom Extension Manager 1.6.9: `integrity.files`, dependency arrays, scoped root `publishes`, exact provider identity and flat-root archive policy.
- Added a standalone exact-ZIP release verifier with path/traversal/symlink/case-collision checks, 250x archive expansion protection and packaged-byte integrity validation.
- Added retained-data reinstall guards to the original extension-owned create migrations so ordinary retain-on-uninstall/reinstall cycles do not attempt to recreate existing tables.
- Added leased Signal outbox delivery with transactionally claimed rows, unique claim tokens, stale-worker recovery and compare-and-finalize semantics.
- Added bounded exponential retry and `dead_letter` handling for persistent Signal delivery failures.
- Removed persisted raw Signal delivery exception messages; durable diagnostics retain exception class only.
- Added multi-node scheduler protection using `withoutOverlapping` and `onOneServer`.
- Added final upgrade, rollback, disable, uninstall and retained-data lifecycle documentation.
- Preserved the fail-closed boundary for peer Titan engines that do not expose compatible callable runtime contracts instead of fabricating integration APIs.
- Added Pass-5 release and Signal-delivery regression gates.

## 0.1.0-alpha.4 — Fourth-Pass Hardening + Rewind Integration

- Added verified Titan Rewind v0.3 read-only source-adapter integration using `RewindManagerContract::registerSourceAdapter()`.
- Added privacy-minimised Rewind projection of Signal outbox records and governed command receipts.
- Added provider-neutral Governance, Wisdom and Vertical export registry while keeping scaffold-only engines out of active dependency claims.
- Added full package integrity verification to installer preflight and runtime health diagnostics.
- Removed the authenticated user Workforce-manifest route and its now-dead controller; Workforce discovery remains server-side.
- Replaced controller-level direct permission checks with the canonical extension permission service for `view-all` and `record-others`.
- Hardened uninstall to remove the published extension config only while retaining operational/audit data.
- Reorganised documentation and removed internal agent-planning residue from the distributable.
- Added Pass-4 architecture, Rewind projection, platform-export and package-integrity tests.
- Re-ran fourth-pass security, tenancy, dead-code, migration ownership, legacy-reference and installer-drift scans.

## 0.1.0-alpha.3 — AI Workforce + Operational Intelligence

- Added trusted extension-owned Workforce execution context and real read/write tool gateway.
- Routed all Workforce writes through the governed Time Command Bus path; model payloads cannot override tenant, actor or trusted lineage.
- Added fail-closed Risk, Assurance and Autonomy ports plus explicit Suggest/Assist preparation semantics.
- Added deterministic proactive attention detection and durable finding open/reopen/resolve lifecycle.
- Added tenant-idempotent Signal-triggered Workforce workflow receipts.
- Activated Time & Attendance Setup and Attendance Verification Policy proposal wizards backed by governed policy capability.
- Added five tool/capability-backed generative surface descriptors.
- Expanded Workforce manifest with real write tools, skills, prompts, workflows, wizards and surfaces while preserving extension ownership.
- Added least-privilege `time.policy.read`, governed `time.policy.update`, `time.attention.read` and `time.workflow.read` capabilities.
- Hardened Titan Go offline ingestion with required device sequence, server-side attendance re-verification and canonical verification receipt linkage.
- Fixed the offline HTTP validator so `device_id` and `device_sequence` are preserved into the governed command path.
- Bounded proactive detector queries with the configured scan limit and reused canonical offline-rejection deduplication identity.
- Added tenant-pseudonymous device identity and keyed/HMAC-minimised location, QR-token and IP evidence by default.
- Removed duplicate offline UUID/timestamp validation and eliminated predictable privacy-hash fallback keys; installer preflight now requires a configured host `APP_KEY`.
- Added proactive tenant-partitioned queue job and scheduled attention scanning.
- Preserved Pass-2 Command Bus, CRM canonical reference, Signal outbox and tenant-isolation architecture.
- Removed premature Rewind/Wisdom/Governance/Vertical/Titan-AI dependency claims that had no Alpha.3 runtime port, keeping installer metadata truthful.

## 0.1.0-alpha.2 — Governed Platform Wiring

- Routed extension mutations through `TimeCommandBusGateway`.
- Added immutable command requests carrying tenant, actor, permission, risk, approval and lineage metadata.
- Added tenant-scoped idempotent command receipts with pre-execution reservation and row locking.
- Made AI/non-human writes fail closed without Titan Command Bus while retaining an explicitly configured human web fallback.
- Added CRM capability-based authority checks for canonical work-order and service-location public references.
- Added canonical public reference fields without importing or writing CRM persistence.
- Added tenant-partitioned Signal queue jobs, retry/backoff and deduplication race handling.
- Added current Titan AI Workforce role `tier` metadata and governance metadata.
- Hardened geofence/QR canonical service-location binding.
- Added Pass-2 governance migration with explicit MySQL-safe index names and reversible indexes/columns.
- Expanded installer preflight and package verification.
- Fixed a syntax defect detected by the full PHP lint gate in `TimeEntryController`.

## 0.1.0-alpha.1 — Conversion Foundation

- Converted the Timesheet family into the initial Titan Time & Attendance native extension.
- Added canonical `tenant_company_id` owned data model.
- Added time entries, timers, weekly submissions/review, costing, attendance verification and offline ingestion.
- Absorbed geofence, dynamic/static QR and IP attendance as verification strategies rather than separate extensions.
- Added tenant-owned IP rules and rejected bare site-ID attendance assertions.
- Added replay-safe privacy-minimised offline event ingestion.
- Added transactional signal outbox foundation.
- Added extension-owned AI Workforce manager, specialists, operational agent, skills, prompts, tools, workflows and planned setup wizards.
- Added Titan installer preflight, health and retain-on-uninstall contracts.

## 0.1.3 — Workforce / Blueprint v4.2.1 convergence
- Canonical Manifest v2.2 metadata.
- Role-neutral Titan AI Workforce integration contract; Workforce remains identity/role/work-item owner.
- Canonical active tenancy is `company_id`; legacy tenant key limited to compatibility/migration paths.
- Governed execution, provider provenance, fail-closed availability semantics and contract regression test.
