<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Repositories;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Contracts\PipelineRepositoryContract;
use App\Extensions\Crm\System\Services\DefaultSalesPipelineProvisioner;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class EloquentPipelineRepository implements PipelineRepositoryContract
{
    public function __construct(private ConnectionInterface $db, private DefaultSalesPipelineProvisioner $defaults) {}
    public function list(int $userId): array
    {
        $this->defaults->ensure($userId);
        return $this->db->table(config('crm.tables.pipelines'))->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at')->orderByDesc('is_default')->orderBy('name')->get()->map(fn($r)=>(array)$r)->all();
    }
    public function create(int $userId,array $data): array
    {
        $stages=$data['stages']??DefaultSalesPipelineProvisioner::STAGES; $this->validateStages($stages);
        return $this->db->transaction(function() use($userId,$data,$stages): array {
            $publicId=(string)Str::ulid();
            $id=$this->db->table(config('crm.tables.pipelines'))->insertGetId(['public_id'=>$publicId,'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'key'=>$data['key']??Str::slug($data['name']),'name'=>$data['name'],'is_default'=>(bool)($data['is_default']??false),'is_active'=>true,'created_at'=>now(),'updated_at'=>now()]);
            foreach($stages as $i=>$stage){$this->db->table(config('crm.tables.stages'))->insert(['public_id'=>(string)Str::ulid(),'company_id'=>CrmCompanyScope::companyId($userId),'pipeline_id'=>$id,'key'=>$stage['key']??Str::slug($stage['name']),'name'=>$stage['name'],'color'=>$stage['color']??'#2563eb','position'=>$i,'probability'=>(int)($stage['probability']??0),'is_closed'=>(bool)($stage['is_closed']??false),'is_won'=>(bool)($stage['is_won']??false),'is_active'=>true,'created_at'=>now(),'updated_at'=>now()]);}
            return $this->board($userId,$publicId);
        },3);
    }
    public function board(int $userId,string $publicId): array
    {
        $tenant=CrmCompanyScope::companyId($userId);$pipeline=$this->db->table(config('crm.tables.pipelines'))->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->first();
        if(!$pipeline) throw ValidationException::withMessages(['pipeline'=>['Pipeline not found.']]);
        $result=(array)$pipeline;$stages=$this->db->table(config('crm.tables.stages'))->where('company_id',$tenant)->where('pipeline_id',$pipeline->id)->whereNull('deleted_at')->orderBy('position')->get()->map(fn($r)=>(array)$r)->all();
        $aggregateRows=$this->db->table(config('crm.tables.deals'))->where('company_id',$tenant)->where('pipeline_id',$pipeline->id)->whereNull('deleted_at')->selectRaw('stage_id, COUNT(*) AS deal_count, COALESCE(SUM(value_minor),0) AS total_value_minor')->groupBy('stage_id')->get();$stageStats=[];foreach($aggregateRows as $row)$stageStats[(int)$row->stage_id]=['deal_count'=>(int)$row->deal_count,'total_value_minor'=>(int)$row->total_value_minor];
        $detailLimit=max(100,min(10000,(int)config('crm.performance.pipeline_board_deal_limit',2000)));$detailRows=$this->db->table(config('crm.tables.deals'))->where('company_id',$tenant)->where('pipeline_id',$pipeline->id)->whereNull('deleted_at')->orderBy('stage_id')->orderBy('position')->orderBy('id')->limit($detailLimit)->get();$dealsByStage=[];foreach($detailRows as $row)$dealsByStage[(int)$row->stage_id][]=(array)$row;
        $truncated=false;foreach($stages as &$stage){$id=(int)$stage['id'];$stage['deals']=$dealsByStage[$id]??[];$stage['deal_count']=(int)($stageStats[$id]['deal_count']??0);$stage['total_value_minor']=(int)($stageStats[$id]['total_value_minor']??0);$stage['deals_truncated']=count($stage['deals'])<$stage['deal_count'];$truncated=$truncated||$stage['deals_truncated'];}
        unset($stage);$result['stages']=$stages;$result['deal_detail_limit']=$detailLimit;$result['deals_truncated']=$truncated;return $result;
    }
    private function validateStages(array $stages): void
    {
        if(count($stages)<2||count($stages)>30) throw ValidationException::withMessages(['stages'=>['A pipeline requires 2 to 30 stages.']]);
        $keys=[];$won=0;$lost=0; foreach($stages as $i=>$stage){$name=trim((string)($stage['name']??''));$key=trim((string)($stage['key']??Str::slug($name)));$p=(int)($stage['probability']??0); if($name===''||$key==='') throw ValidationException::withMessages(["stages.$i.name"=>['Name and stable key are required.']]); if($p<0||$p>100) throw ValidationException::withMessages(["stages.$i.probability"=>['Probability must be between 0 and 100.']]); if(isset($keys[$key])) throw ValidationException::withMessages(["stages.$i.key"=>['Stage keys must be unique.']]);$closed=(bool)($stage['is_closed']??false);$isWon=(bool)($stage['is_won']??false);if($isWon&&!$closed) throw ValidationException::withMessages(["stages.$i.is_won"=>['Won stage must be closed.']]);$won+=$isWon?1:0;$lost+=($closed&&!$isWon)?1:0;$keys[$key]=true;} if($won<1||$lost<1) throw ValidationException::withMessages(['stages'=>['A pipeline requires won and lost closed stages.']]);
    }
}
