# Titan Model Council — Upgrade Prompt

# Titan Zero Global Architecture Rules

This extension is part of the governed Titan Zero architecture. Preserve these boundaries:

- AI intelligence never directly mutates authoritative business state when a governed capability/Command Bus path exists.
- Intelligence, risk, assurance, autonomy, approval and execution remain separate concerns.
- Every significant action emits structured Signal telemetry and a traceable receipt.
- Use tenant_company_id, trace_id, correlation_id and causation_id on durable cross-extension records/events.
- Do not store unrestricted hidden model reasoning; store structured decision rationale, reason codes, policy/evidence references and outcomes.
- Offline operation may reduce authority but must never increase it.
- External side effects must be idempotent.
- Preserve installer compatibility and existing working host UI conventions.
- Prefer shared contracts/adapters over importing another extension's internal implementation classes.

## Extension Mission

MISSION: Heavily modify and reuse the supplied existing Model Council extension instead of replacing its working deliberation service.

OWN: optional multi-model proposer/critic/verifier/arbiter deliberation, disagreement measurement, structured recommendation, policy-based activation and model-transition comparison.

DO NOT route every action through Council; it is a selective governance amplifier.

NEXT BUILD:
1. Preserve and namespace the existing ModelCouncilService and response model/controller logic.
2. Add governed CouncilRequest/CouncilDecision public contract.
3. Wrap legacy service behind CouncilGateway rather than allowing new callers to depend on legacy internals.
4. Add policy activation for uncertainty, high financial impact, conflicting evidence, low Assurance, model transitions and complex plan validation.
5. Record participants/model versions/disagreement/confidence/final arbiter/reason codes.
6. Integrate through adapters with AI Core, Assurance, Risk, Signal and Rewind; boot even if optional peers are absent.
7. Migrate legacy extension identity/routes/config progressively and preserve data.

## Universal Acceptance

- Installer/manifest validation passes.
- PHP syntax checks pass.
- Tenant boundaries are explicit.
- Cross-engine calls use public contracts/adapters.
- Significant states are traceable.
- No high-risk or authoritative mutation bypass is introduced.
