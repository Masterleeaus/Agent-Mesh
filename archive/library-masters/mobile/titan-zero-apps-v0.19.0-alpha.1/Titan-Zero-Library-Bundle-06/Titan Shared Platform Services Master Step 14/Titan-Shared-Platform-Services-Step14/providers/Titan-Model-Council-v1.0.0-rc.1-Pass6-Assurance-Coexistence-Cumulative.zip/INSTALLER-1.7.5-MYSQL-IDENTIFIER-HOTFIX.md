# Installer 1.7.5 — MySQL Identifier Hotfix 3

## Live failure

Installer 1.7.5 reached scoped migration execution and MySQL rejected the inferred index name:

`titan_model_council_decisions_pre_arbiter_validation_status_index`

The name is 65 characters; MySQL identifiers are limited to 64 characters.

## Root-cause fix

Migration `2026_08_11_000010_add_governed_validation_fields.php` now uses explicit short index names:

- `tmc_dec_prearbiter_status_idx`
- `tmc_dec_final_validation_idx`
- `tmc_dec_validation_source_idx`

No Council runtime service, route, controller, provider adapter, billing logic, Risk logic, Shield logic, or UI behavior changed.

## Retry safety

The live installer report shows migration rollback was attempted with no rollback errors. Existing Council migrations also guard table/column creation, so retained forward-only shared/audit fields do not cause duplicate-column creation on retry.

## Regression coverage

- `tests/pass6_mysql_identifier_runner.php` locks the three explicit governed-validation index names.
- `tests/pass6_mysql_migration_identifier_audit_runner.php` scans all extension migrations for inferred/explicit MySQL identifiers exceeding 64 characters.
