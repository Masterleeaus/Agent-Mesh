# Data Ownership

This extension owns only its declared `crm` domain state. It does not own Titan AI Workforce employees, organisational roles, hierarchy, teams, responsibilities, assignments or work items.
