# Titan Rewind Evidence Signing-Key Rotation

Configure `TITAN_REWIND_EVIDENCE_KEYS_JSON` as an array of key descriptors containing `key_id`, `public_key_path`, optional `private_key_path`, and optional status. Set `TITAN_REWIND_EVIDENCE_ACTIVE_KEY_ID` to the key allowed to sign new packages.

Rotation procedure:

1. Add the new public/private descriptor without removing the old public key.
2. Change `TITAN_REWIND_EVIDENCE_ACTIVE_KEY_ID` to the new key ID.
3. Generate/verify a new evidence package.
4. Confirm `titan_rewind_signing_keys` reports the new key active and old key verify-only.
5. Keep old public keys available for at least the maximum retained evidence lifetime.
6. Remove old private keys from the host when policy permits; never remove a historical public key while evidence signed by it must remain verifiable.

Rewind stores only fingerprints/lifecycle metadata, never private key material.
