# Signal Events

## wisdom.outcome.observation_due.v1

The delayed observation queue emits a normalized application event with:

- `tenant_company_id`
- `outcome_id`
- `trace_id`
- `correlation_id`
- `causation_id`
- `root_causation_id`
- `source_component`
- `expected_resolution_at`
- stable `idempotency_key`

The job is intentionally non-mutating. Signal/observer adapters may use the event to collect or request evidence, but actual evidence attachment and outcome resolution must return through the governed public capabilities. Cross-extension integration uses adapters/contracts rather than importing Titan Signal internals.
