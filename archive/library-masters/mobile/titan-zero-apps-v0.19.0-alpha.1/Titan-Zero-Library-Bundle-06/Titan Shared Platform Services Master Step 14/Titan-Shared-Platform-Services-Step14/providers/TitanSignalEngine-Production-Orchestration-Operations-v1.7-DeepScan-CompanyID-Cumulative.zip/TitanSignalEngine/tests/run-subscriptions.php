<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/SignalSubscriptionDefinition.php';
require __DIR__ . '/../System/Data/SignalRetryPolicy.php';

use App\Extensions\TitanSignalEngine\System\Data\SignalRetryPolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalSubscriptionDefinition;

function pass4Assert(bool $condition, string $message): void {
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

$subscription = SignalSubscriptionDefinition::fromArray([
    'subscriber_key' => 'titan-risk',
    'handler_class' => 'App\\Titan\\Risk\\SignalSubscriber',
    'event_patterns' => ['command.*', 'job.completed'],
    'accepted_schema_versions' => [1, 2],
    'scopes' => ['tenant'],
    'categories' => ['operations', 'risk'],
    'verticals' => ['cleaning'],
    'queue' => 'titan-signal-engine',
    'max_attempts' => 4,
    'backoff_seconds' => [1, 5, 30],
]);

pass4Assert($subscription->matches('command.executed', 1, 'tenant', 'risk', 'cleaning'), 'Prefix event pattern must match.');
pass4Assert($subscription->matches('job.completed', 2, 'tenant', 'operations', 'cleaning'), 'Exact event pattern must match.');
pass4Assert(! $subscription->matches('job.completed', 3, 'tenant', 'operations', 'cleaning'), 'Unsupported schema version must not match.');
pass4Assert(! $subscription->matches('command.executed', 1, 'system', 'risk', 'cleaning'), 'Scope filter must be enforced.');
pass4Assert(! $subscription->matches('command.executed', 1, 'tenant', 'finance', 'cleaning'), 'Category filter must be enforced.');
pass4Assert(! $subscription->matches('command.executed', 1, 'tenant', 'risk', 'plumbing'), 'Vertical filter must be enforced.');

$wildcardRejected = false;
try {
    SignalSubscriptionDefinition::fromArray([
        'subscriber_key' => 'unsafe',
        'handler_class' => 'Unsafe',
        'event_patterns' => ['*'],
        'accepted_schema_versions' => [1],
    ]);
} catch (InvalidArgumentException) {
    $wildcardRejected = true;
}
pass4Assert($wildcardRejected, 'Unrestricted wildcard subscriptions must be rejected.');

$policy = new SignalRetryPolicy(4, [1, 5, 30]);
pass4Assert($policy->shouldRetry(1), 'Attempt 1 failure should retry.');
pass4Assert($policy->delaySecondsForAttempt(1) === 1, 'First retry delay must be 1 second.');
pass4Assert($policy->delaySecondsForAttempt(2) === 5, 'Second retry delay must be 5 seconds.');
pass4Assert($policy->delaySecondsForAttempt(3) === 30, 'Third retry delay must be 30 seconds.');
pass4Assert(! $policy->shouldRetry(4), 'Attempt at max_attempts must dead-letter.');

$metaPrefix = SignalSubscriptionDefinition::fromArray([
    'subscriber_key' => 'meta-prefix',
    'handler_class' => 'App\\MetaPrefix',
    'event_patterns' => ['signal.*'],
    'accepted_schema_versions' => [1],
]);
pass4Assert(! $metaPrefix->matches('signal.subscription.failed', 1, 'system', 'operations', null), 'Failure telemetry must not be inherited through broad prefix subscriptions.');
$metaExact = SignalSubscriptionDefinition::fromArray([
    'subscriber_key' => 'meta-exact',
    'handler_class' => 'App\\MetaExact',
    'event_patterns' => ['signal.subscription.failed'],
    'accepted_schema_versions' => [1],
]);
pass4Assert($metaExact->matches('signal.subscription.failed', 1, 'system', 'operations', null), 'Explicit failure telemetry subscription must be allowed.');

fwrite(STDOUT, "subscription-behavior: PASS\n");
