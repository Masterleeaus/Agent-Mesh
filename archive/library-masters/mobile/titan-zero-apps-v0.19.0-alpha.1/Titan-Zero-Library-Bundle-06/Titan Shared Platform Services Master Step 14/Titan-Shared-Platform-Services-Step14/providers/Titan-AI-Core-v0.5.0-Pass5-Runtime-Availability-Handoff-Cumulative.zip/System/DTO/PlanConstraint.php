<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class PlanConstraint { public function __construct(public string $key, public mixed $value) {} public function toArray(): array { return ['key'=>$this->key,'value'=>$this->value]; } }
