# Titan Model Council v1.0.0-rc.1

Titan Model Council is Titan Zero's governed multi-model deliberation layer. It preserves the proven parallel-consensus engine while adding selective activation, adversarial governed deliberation, risk-aware authority controls, assurance, Shield validation, causal Signal telemetry, auditable billing, and tamper-evident decision receipts.

## Active strategies

- `single_model` — selective-activation bypass when Council depth is unnecessary.
- `lightweight_council` — two-model verification floor for monitored/medium-risk work.
- `parallel_consensus` — parallel multi-model synthesis with agreement/disagreement analysis.
- `governed_deliberation` — Proposer → Critic → Verifier → Shield → Arbiter → Shield.

Council outputs are advisory. Consensus never grants mutation authority. Titan Risk remains an authority floor and may require Assurance, approval, reduced authority, or a block.

## Production hardening in rc.1

- Titan Signal Engine v0.20-compatible emission using attested emitter identity + trusted `SignalContext`.
- Titan Shield v0.5 `ShieldManagerContract::evaluateInspection()` integration with legacy inspection fallback.
- Titan Assurance v2.2 evidence-assessment boundary with fail-closed behaviour when Assurance is required.
- SHA-256 canonical decision receipts that store participant output hashes rather than hidden reasoning.
- receipt-table health/certification checks.
- provider circuit breaker, bounded provider timeouts, partial-provider tolerance, and adaptive quorum.
- Installer 1.7.8 + Blueprint v4.2 schema 2.2 contracts.
- host-safe MagicAI `panel.layout.app` views.

## Provider execution boundary

The Council continues to isolate direct provider compatibility behind `GovernedProviderRuntimeContract`. AI Core is preferred, but Council will not invent an execution API: it switches only when an executable AI Core runtime contract is configured and available. Until then the legacy provider adapter remains explicit and circuit-breaker protected.

## Signal identity transition

Blueprint v4.2 currently requires the canonical dependency key `titan-signal >=1.0`, while the current Signal release candidate still identifies as `titan-signal-engine`. Council's runtime adapter understands the current v0.20 namespace and contract, but installer-level canonical identity convergence remains an ecosystem promotion prerequisite.

## Release status

Version: `1.0.0-rc.1`  
Package stage: `development` until the exact ZIP completes live-host certification and approved signing. The release-candidate version does not claim production certification by itself.

See `PASS-6-PRODUCTION-HARDENING-RC.md`, `docs/INTEGRATION-CONTRACTS.md`, and `docs/OPERATIONS.md` for exact boundaries.

## Super Admin control plane (Hotfix 5)

The native Super Admin surface now provides Overview, Settings, Strategies & Activation, Providers & Models, Integrations, Billing & Limits, and Diagnostics & Audit. Settings are stored in `titan_model_council_settings` and applied as runtime policy overrides on subsequent requests. Provider credentials remain host-managed and Council remains advisory-only.
