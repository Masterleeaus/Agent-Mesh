<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\Contracts;
use App\Extensions\TitanAICore\System\DTO\ExecutionIntent;
use App\Extensions\TitanAICore\System\DTO\PlanEnvelope;
use App\Extensions\TitanAICore\System\DTO\RuntimeContext;
interface OrchestratorContract { public function createPlan(ExecutionIntent $intent, RuntimeContext $context): PlanEnvelope; }
