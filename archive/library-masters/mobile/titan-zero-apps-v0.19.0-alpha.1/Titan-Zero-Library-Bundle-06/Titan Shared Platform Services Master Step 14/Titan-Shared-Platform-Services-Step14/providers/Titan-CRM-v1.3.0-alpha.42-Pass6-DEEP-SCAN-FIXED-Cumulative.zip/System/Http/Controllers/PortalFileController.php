<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Portal\{CrmPortalFileService,CrmPortalGrantService};
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Storage;

final class PortalFileController extends Controller
{
    public function index(Request $request,string $token,CrmPortalGrantService $grants,CrmPortalFileService $files)
    {
        $grant=$grants->resolve($token,$request); $grants->requireVerifiedSession($grant,$request); abort_unless($grants->allows($grant,'files.view')||$grants->allows($grant,'files.upload'),403);
        return view('crm::portal.files',['grant'=>$grant,'token'=>$token,'files'=>$files->list($grant)]);
    }
    public function store(Request $request,string $token,CrmPortalGrantService $grants,CrmPortalFileService $files)
    {
        $grant=$grants->resolve($token,$request); $grants->requireVerifiedSession($grant,$request); abort_unless($grants->allows($grant,'files.upload'),403);
        $request->validate(['file'=>'required|file']); $files->store($grant,$request->file('file'));
        return back()->with('status','File uploaded securely.');
    }
    public function download(Request $request,string $token,string $file,CrmPortalGrantService $grants,CrmPortalFileService $files)
    {
        $grant=$grants->resolve($token,$request); $grants->requireVerifiedSession($grant,$request); abort_unless($grants->allows($grant,'files.download'),403);
        $record=$files->resolve($grant,$file);
        $safeName=str_replace(["\r","\n",'\"'],['_','_','_'],(string)$record['original_name']);
        return Storage::disk((string)$record['disk'])->download((string)$record['storage_key'],$safeName,[
            'Content-Type'=>(string)$record['mime_type'],
            'Content-Disposition'=>'attachment; filename=\"'.$safeName.'\"',
            'X-Content-Type-Options'=>'nosniff',
            'Cache-Control'=>'private, no-store, max-age=0',
            'Content-Security-Policy'=>"default-src 'none'; sandbox",
        ]);
    }
}
