# CRM Core Autonomy De-ownership — alpha.26

CRM Core no longer owns autonomy, learning, proactive intelligence, autonomous planning, or autonomous execution.

## CRM Core keeps

- customer, organisation, contact, lead, deal, quote, estimate, invoice and commercial relationship truth;
- governed CRM capabilities and authoritative command receipts;
- Signal outbox events and Rewind references;
- one thin `CrmAutonomyDecisionPort` used by Interaction/AI execution policy;
- approval-only fail-closed behavior when Titan Autonomy is not bound.

## Removed from CRM Core

- `System/Domains/Autonomy/**`;
- CRM Autonomy controllers and views;
- local autonomy/learning/recommendation AI tools;
- local autonomy evidence persistence from Assistant and Interaction runtimes;
- proactive autonomy execution from `crm:automations:run`;
- the four old autonomy/learning migrations from the active migration set;
- obsolete autonomy-specific verifier scripts and implementation docs.

Fresh CRM installations therefore do not create the old autonomy/learning tables.

## Existing installations

No alpha.26 migration drops historical autonomy/learning data. The cleanup migration only disables old CRM Autonomy menu entries. If legacy tables already exist, `crm:production-check` reports them as a migration warning.

Do **not** drop those tables until the receiving engines have returned verified import receipts and record counts.

## Four consolidated destinations

1. **Titan Autonomy** — authority levels/gates, controls, handshakes, scope, simulations, regressions and authority evidence policy.
2. **Titan AI Core** — autonomous/cross-domain planning and plan-step structures.
3. **Titan AI Workforce** — proactive observation, recommendations, plan execution and operational exception handling.
4. **Titan Wisdom** — outcome learning, learning preferences/patterns, training statistics and evidence classification.

Risk, Assurance, Command Bus, Signal, Rewind, Governance, Interaction, Vertical and Foresight remain independent platform engines. CRM-derived implementation is not copied into them; they integrate through typed contracts/events.

See `CRM-AUTONOMY-CONSOLIDATION-MAP.json` for the exact class/table allocation.
