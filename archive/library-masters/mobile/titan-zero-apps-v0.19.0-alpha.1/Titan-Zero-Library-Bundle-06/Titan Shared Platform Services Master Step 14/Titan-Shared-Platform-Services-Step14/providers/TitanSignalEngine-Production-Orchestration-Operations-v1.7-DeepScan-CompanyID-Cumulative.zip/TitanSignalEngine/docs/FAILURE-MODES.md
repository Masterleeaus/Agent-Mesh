# Failure Modes

| Failure | Detection | Classification | Recovery |
|---|---|---|---|
| Database unavailable | readiness | terminal until dependency restored | restore DB; do not fabricate events |
| Invalid/unauthorized context | validation | permanent | fix caller identity/permission |
| Payload/schema invalid | registry/guard | permanent | correct event definition/payload |
| Queue unavailable | delivery ledger/backlog | retryable | recover pending deliveries |
| Subscriber failure | per-subscriber ledger/DLQ | retryable then attention | fix subscriber; redrive is planned hardening |
| Pulse projection failure | projection freshness/log | retryable | catch-up projector |
| Anomaly scanner failure | scan state/schedule | retryable | rerun scan |
| Archive write/verify failure | archive batch status | permanent for prune attempt | retain hot events; repair storage |
| Backpressure | health/Pulse | degraded | throttle emitters and drain backlog |
| Missing app key | provider boot | permanent configuration failure | configure host app key |

No failure mode may silently bypass tenant isolation, integrity validation, archive verification or governance.

## Subscriber worker crash / duplicate execution

A worker crash after a subscriber side effect but before ledger completion can cause a later retry. This is expected under at-least-once delivery. Lease CAS prevents stale workers from overwriting current delivery state, while subscribers must use the stable `signal-delivery:<delivery_id>` idempotency key for consequential side effects.

## Prune/archive interruption

If archive creation fails before verification, the batch becomes retryable and candidate claims are released. If an archive is verified but the hot-delete transaction fails, the batch remains `verified_unpruned`; retrying the same preview resumes finalization without treating the archive as missing. Expired execution leases permit worker recovery while candidate claims remain protected.


## Stale tenant/source Pulse projection

A healthy projection for another tenant/source must never mask a stale requested scope. Freshness is evaluated from `titan_signal_pulse_projection_freshness` for the exact tenant/system and source dimension. A stale scope degrades only that operational view; platform readiness uses its separate platform row.

## Historical incident retention

Resolved dead letters and resolved critical anomalies remain visible in bounded 30-day historical counters but do not determine current engine degradation. Current status is driven by active backpressure, recent DLQ activity, current critical anomalies, and current Pulse projection freshness.
