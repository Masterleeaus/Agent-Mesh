# Platform Integrations

Titan Time & Attendance owns its domain. Peer Titan engines remain independent authorities and are consumed only through explicit contracts/adapters.

## Concrete extension contributions / adapters

### Titan CRM
Optional. Canonical work-order and service-location public references are validated through the CRM authority adapter. No CRM tables or models are written by this extension.

### Titan Signal
The extension owns a transactional outbox and a tenant-partitioned leased delivery worker. Its default delivery port publishes the canonical `titan.signal` Laravel event envelope with stable event/deduplication identity. The transport is explicitly at-least-once; consumers must deduplicate by stable identity.

### Titan AI Workforce
Discovers `resources/workforce/workforce-manifest.json`. Titan Workforce does not own duplicate role definitions. Managers, specialists, agents, skills, tools, prompts, workflows, wizards and surfaces remain source-owned by this extension.

### Titan Rewind v0.3+
The verified Rewind v0.3 contract exposes `RewindManagerContract::registerSourceAdapter()`. When present, `TimeRewindIntegration` registers a read-only `titan-time-attendance` source adapter. It projects Signal-outbox records and governed command receipts into Rewind records while excluding raw location, QR secrets, IP addresses and free-text notes.

## Fail-closed peer ports

### Titan Command Bus
AI/non-human writes require the Time Command Bus port. If the host has not supplied a compatible binding, the deferred port rejects execution. The extension does not fabricate a Command Bus adapter for peer versions that do not expose a stable callable dispatch API. Configured human-local fallback is limited to explicitly human web sources.

### Titan Risk / Titan Assurance
The Workforce decision gate owns Time-specific `TimeRiskPort` and `TimeAssurancePort` contracts. Default implementations are deferred/fail-closed for execution paths that require those evaluations. A host may bind compatible engine adapters when the owning engine exposes the required callable contract. Human approval never substitutes for a mandatory platform safety gate.

### Titan Autonomy
The default Time Autonomy port is configuration-backed and can only reduce/gate authority. It cannot self-promote an agent, clear Risk/Assurance failures or bypass mandatory human approval.

## Export-only future boundaries

`TimePlatformExportRegistry` exposes provider-neutral descriptors for:

- **Governance:** capability permission, risk, approval, idempotency and Command-Bus requirements.
- **Wisdom:** observable outcome Signals, calibration dimensions and privacy constraints.
- **Vertical Engine:** time/attendance capabilities, verification methods, policy overlay keys and Workforce/wizard/surface assets.

Governance, Wisdom and Vertical Engine are not advertised as active runtime ingestion integrations while their owning engine packages lack compatible consumer contracts. These exports allow later wiring without transferring domain ownership.
