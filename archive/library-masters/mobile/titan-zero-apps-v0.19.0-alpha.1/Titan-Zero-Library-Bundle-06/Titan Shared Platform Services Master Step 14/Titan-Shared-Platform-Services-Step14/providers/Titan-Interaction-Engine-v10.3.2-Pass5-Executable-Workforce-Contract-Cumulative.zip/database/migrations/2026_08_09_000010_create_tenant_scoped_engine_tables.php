<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Forward upgrade bridge for installations that already ran the pre-extension
 * generic table migrations. Legacy generic rows are deliberately not copied:
 * most do not contain a trustworthy company_id and auto-attribution would risk
 * cross-company data exposure. They remain untouched for explicit/manual
 * reconciliation while all new runtime writes use the prefixed tenant tables.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('interaction_queued_commands')) {
            Schema::create('interaction_queued_commands', function (Blueprint $table): void {
                $table->id();
                $table->string('company_id', 191)->index();
                $table->string('capability');
                $table->json('payload');
                $table->json('metadata')->nullable();
                $table->enum('status', ['pending', 'synced', 'failed'])->default('pending');
                $table->integer('attempts')->default(0);
                $table->text('error')->nullable();
                $table->timestamp('created_at')->useCurrent();
                $table->timestamp('updated_at')->nullable();
                $table->timestamp('synced_at')->nullable();
                $table->timestamp('failed_at')->nullable();
                $table->index(['company_id', 'status', 'created_at'], 'interaction_queue_company_status_created_idx');
                $table->index('capability');
            });
        }

        $this->createJsonLogTable('interaction_episodic_memory', 'event', 'timestamp', true);
        $this->createJsonLogTable('interaction_semantic_memory', 'fact', 'created_at');
        $this->createJsonLogTable('interaction_audit_logs', 'entry', 'created_at');
        $this->createJsonLogTable('interaction_governance_logs', 'event', 'created_at');

        if (!Schema::hasTable('interaction_user_actions')) {
            Schema::create('interaction_user_actions', function (Blueprint $table): void {
                $table->id();
                $table->string('company_id', 191)->index();
                $table->unsignedBigInteger('user_id');
                $table->string('action');
                $table->json('context')->nullable();
                $table->timestamp('created_at')->useCurrent();
                $table->index(['company_id', 'user_id', 'created_at'], 'interaction_actions_company_user_created_idx');
            });
        }

        if (!Schema::hasTable('interaction_user_preferences')) {
            Schema::create('interaction_user_preferences', function (Blueprint $table): void {
                $table->id();
                $table->string('company_id', 191)->index();
                $table->unsignedBigInteger('user_id');
                $table->string('key');
                $table->json('value')->nullable();
                $table->timestamp('updated_at')->useCurrent();
                $table->unique(['company_id', 'user_id', 'key'], 'interaction_preferences_company_user_key_uq');
            });
        }
    }

    public function down(): void
    {
        // Forward-only safety migration. Extension uninstall retains tenant data.
    }

    private function createJsonLogTable(string $name, string $jsonColumn, string $timestampColumn, bool $timestampIndex = false): void
    {
        if (Schema::hasTable($name)) {
            return;
        }

        Schema::create($name, function (Blueprint $table) use ($jsonColumn, $timestampColumn, $timestampIndex): void {
            $table->id();
            $table->string('company_id', 191)->index();
            $table->json($jsonColumn);
            $table->timestamp($timestampColumn)->useCurrent();
            if ($timestampIndex) {
                $table->index(['company_id', $timestampColumn], 'interaction_episodic_company_timestamp_idx');
            }
        });
    }
};
