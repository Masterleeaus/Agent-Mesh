<?php
declare(strict_types=1);
spl_autoload_register(function(string $class):void{ $p='App\\Extensions\\TitanAutonomy\\'; if(!str_starts_with($class,$p))return; $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($path))require_once $path; });
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Services\AssuranceAssessmentRequestService;
$host=new class implements HostContextBridgeContract {public function tenantCompanyId():int{return 42;}public function userId():int{return 7;}public function can(string $p):bool{return $p==='titan.autonomy.manage';}public function isSuperAdmin():bool{return false;}};
$engine=new class {public array $create=[];public array $lock=[]; public function createRun(array $packet,array $options=[]):object{$this->create=[$packet,$options];return (object)['id'=>12,'uuid'=>'u12','status'=>'collecting_evidence'];} public function lockEvidence(int $id,array $packet):object{$this->lock=[$id,$packet];return (object)['id'=>$id,'uuid'=>'u12','status'=>'pending'];}};
$s=new AssuranceAssessmentRequestService($engine,$host,'policy-v13');
$r=$s->request('crm.invoice.issue','completed_job_invoice',['success_streak'=>3,'scope'=>['max_total'=>1500]],'medium','corr-1');
if(($r['status']??null)!=='pending')throw new RuntimeException('requested run must remain pending; Autonomy must not invent/start an Assurance panel');
if(($engine->create[1]['source_type']??null)!=='titan_autonomy')throw new RuntimeException('Assurance source_type required');
if(($engine->create[1]['decision_type']??null)!=='autonomy_trusted_auto')throw new RuntimeException('Assurance decision_type required');
if(($engine->lock[1]['tenant_company_id']??null)!==42)throw new RuntimeException('evidence must carry trusted tenant boundary');
echo "OK: LiveAssuranceRequestSmokeTest\n";
