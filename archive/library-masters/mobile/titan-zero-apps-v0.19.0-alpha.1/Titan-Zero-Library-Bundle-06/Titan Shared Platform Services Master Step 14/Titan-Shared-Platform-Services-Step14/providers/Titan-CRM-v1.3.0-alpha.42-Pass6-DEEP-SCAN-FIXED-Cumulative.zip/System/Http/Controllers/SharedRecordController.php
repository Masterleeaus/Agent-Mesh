<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Governance\CrmCommandBusGateway;
use App\Extensions\Crm\System\Sharing\{CrmRecordShareService,CrmSharedRecordAccessService};
use App\Extensions\Crm\System\Tenancy\{CrmCompanyContextResolver,CrmCompanyScope};
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Symfony\Component\HttpKernel\Exception\ServiceUnavailableHttpException;

final class SharedRecordController extends Controller
{
    public function __construct(private readonly CrmCommandBusGateway $commands) {}

    public function index(Request $request, CrmRecordShareService $shares)
    {
        return view('crm::sharing.received', ['shares'=>$shares->received((int)$request->user()->id)]);
    }

    public function show(Request $request, string $subjectType, string $subjectPublicId, CrmSharedRecordAccessService $access)
    {
        $resolved=$access->resolve((int)$request->user()->id,$subjectType,$subjectPublicId,'view');
        return view('crm::sharing.shared-record', ['subjectType'=>$subjectType]+$resolved);
    }

    public function comment(
        Request $request,
        string $subjectType,
        string $subjectPublicId,
        CrmRecordShareService $shares,
        CrmSharedRecordAccessService $access,
        CrmCompanyContextResolver $contexts,
        CrmCompanyScope $scope,
    ) {
        $actorId=(int)$request->user()->id;
        $resolved=$access->resolve($actorId,$subjectType,$subjectPublicId,'view');
        $grant=$resolved['grant'];
        abort_unless($shares->allows($grant, 'comment'), 403);
        $data=$request->validate(['body'=>'required|string|max:5000']);
        $tenant=(int)($grant['company_id']??0);
        $trusted=$contexts->fromTrustedPlatform(
            $tenant,$actorId,'shared_user',permissions:['crm.activities.create'],sourceSurface:'crm_shared_record',membershipVerified:true
        );
        $envelope=$scope->runWith($trusted,fn()=>$this->commands->request('crm.shared.comment.create',[
            'subject_type'=>$subjectType,'subject_public_id'=>$subjectPublicId,'body'=>$data['body'],
            'share_public_id'=>(string)($grant['public_id']??''),
            'idempotency_key'=>'shared-comment:'.hash('sha256',(string)($grant['public_id']??'').'|'.$actorId.'|'.$data['body']),
        ],'crm_shared_record'));
        if(($envelope['executed']??false)!==true) throw new ServiceUnavailableHttpException(5,'Shared-record comment is awaiting governed execution.');
        return back()->with('status','Comment added to the shared CRM record.');
    }
}
