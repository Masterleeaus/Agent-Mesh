<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Http\Middleware;

use App\Extensions\TitanAICore\System\Contracts\TrustedPrincipalResolverContract;
use App\Extensions\TitanAICore\System\Exceptions\SecurityContextException;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class ResolveTrustedCoreContext
{
    public function __construct(private readonly TrustedPrincipalResolverContract $resolver) {}

    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        if (!is_object($user)) {
            abort(401, 'Authentication required.');
        }

        try {
            $principal = $this->resolver->resolve($user);
            $this->rejectIdentityOverride($request, 'tenant_company_id', $principal->tenantCompanyId, 'TENANT_SPOOFING_DETECTED');
            $this->rejectIdentityOverride($request, 'actor_id', $principal->actorId, 'ACTOR_SPOOFING_DETECTED');
            $this->rejectIdentityOverride($request, 'actor_type', $principal->actorType, 'ACTOR_TYPE_SPOOFING_DETECTED');
            $request->attributes->set('titan_ai_core.principal', $principal);
        } catch (SecurityContextException $exception) {
            abort(403, $exception->securityCode);
        }

        return $next($request);
    }

    private function rejectIdentityOverride(Request $request, string $key, string $trustedValue, string $code): void
    {
        $claimed = $request->input($key);
        if ($claimed === null || $claimed === '') {
            return;
        }
        if (is_scalar($claimed) && hash_equals($trustedValue, (string) $claimed)) {
            return;
        }
        throw new SecurityContextException($code, 'Request identity override does not match trusted host context.');
    }
}
