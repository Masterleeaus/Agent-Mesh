<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_events') || Schema::hasColumn('titan_signal_events', 'emitter_id')) {
            return;
        }

        Schema::table('titan_signal_events', static function (Blueprint $table): void {
            $table->string('emitter_id', 160)->nullable()->after('source_component');
            $table->index(['emitter_id', 'occurred_at'], 'titan_signal_events_emitter_occurred_idx');
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('titan_signal_events') || ! Schema::hasColumn('titan_signal_events', 'emitter_id')) {
            return;
        }

        Schema::table('titan_signal_events', static function (Blueprint $table): void {
            $table->dropIndex('titan_signal_events_emitter_occurred_idx');
            $table->dropColumn('emitter_id');
        });
    }
};
