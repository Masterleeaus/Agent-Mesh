<?php

declare(strict_types=1);
$root=dirname(__DIR__);
require_once $root.'/System/Host/TitanProviderBootPreflight.php';
use App\Extensions\TitanGovernance\System\Host\TitanProviderBootPreflight;
$result=(new TitanProviderBootPreflight())->inspect($root);
echo json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES).PHP_EOL;
exit(($result['status']??'FAIL')==='PASS'?0:1);
