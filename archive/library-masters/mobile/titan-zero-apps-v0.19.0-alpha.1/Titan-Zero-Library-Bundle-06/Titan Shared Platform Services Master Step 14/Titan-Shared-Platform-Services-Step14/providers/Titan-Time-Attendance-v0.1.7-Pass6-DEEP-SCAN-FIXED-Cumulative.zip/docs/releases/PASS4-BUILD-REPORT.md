# Titan Time & Attendance v0.1.0-alpha.4 — Pass 4 Build Report

## Scope

Pass 4 is the mandatory fourth-pass hardening, drift, security and documentation sweep. It preserves the Alpha.3 operational Time & Attendance and AI Workforce runtime while tightening authorization, package integrity, governance ordering and cross-engine boundaries.

## Implemented

### Rewind integration

- Added a real optional integration with Titan Rewind v0.3 through its verified `RewindManagerContract` and `RewindSourceAdapterContract` interfaces.
- Registers `titan-time-attendance` as a read-only reconstruction source when the compatible Rewind runtime is actually installed and bound.
- Projects tenant/trace-scoped Signal outbox and Command receipt history into Rewind event records.
- Preserves correlation, causation, capability, risk, approval and safe actor provenance.
- Excludes raw location coordinates, QR tokens, IP addresses, review notes and arbitrary result payloads from Rewind reconstruction.
- Missing or incompatible Rewind fails closed without affecting the Time & Attendance domain runtime.

### Governance ordering

- High/Critical Workforce actions now pass Titan Risk and Titan Assurance before they may enter a human-approval queue.
- Human approval is not treated as a substitute for platform Risk/Assurance evaluation.
- Suggest and Assist remain proposal-only and do not require execution-engine availability simply to prepare advice.

### Platform export boundaries

- Added provider-neutral Governance, Wisdom and Vertical export descriptors for future owning-engine consumption.
- The currently available Governance, Wisdom and Vertical packages expose health-only scaffolds, so Alpha.4 does not claim active runtime integration with them.
- No duplicate Governance, Wisdom or Vertical engine logic is embedded in this extension.

### HTTP and authorization hardening

- Removed the authenticated HTTP route that exposed the complete Workforce manifest, prompts and tool metadata.
- Removed the now-dead `WorkforceManifestController`.
- Titan Workforce discovery remains server-side through the extension-owned Workforce contribution.
- Normalized Time Entry view-all and record-others checks through `TimeAttendancePermissionService` rather than controller-local authorization calls.
- Dashboard access is explicitly authorized.

### Installer and lifecycle hardening

- Added `PackageIntegrityVerifier` and wired it into preflight and health diagnostics.
- Integrity validation checks the exact package file set and both independent SHA-256 inventories.
- Uninstall removes only the extension-owned published configuration and retains operational/audit data.
- Disable remains non-destructive.
- Titan Rewind is advertised only as an optional dependency with the consumed `rewind.reconstruct` capability.

### Documentation cleanup

- Removed internal implementation-planning scratchpads from the distributable package.
- Reorganized documentation into architecture, installer/lifecycle, integrations, security/privacy, Workforce and release-report sections.
- Added a documentation index and updated README/CHANGELOG for Alpha.4.

## Fourth-pass drift and security sweep

The release gate checks:

- every extension model remains tenant-scoped by `tenant_company_id`;
- no legacy `Modules\\`, FSMCore, FieldManager, CRMCore, WorkDo/Worksuite/Nwidart or `auth:sanctum` runtime references remain;
- no `loginUsingId`, `dd`, `dump` or `var_dump` production paths remain;
- no HTTP controller bypasses the extension permission service for the normalized permission paths;
- no Workforce manifest HTTP exposure remains;
- no foreign/shared database tables are created, altered or dropped;
- all migrations are reversible;
- no generated MySQL identifier exceeds 64 characters;
- no duplicate named PHP FQCN exists;
- no package junk paths or generic `extension` publish tag exist.

## Release verification

The Alpha.4 release gate is designed to run on the frozen package and again from a fresh extraction of the final ZIP. It covers:

- 11 standalone architecture/unit contract tests;
- full PHP syntax scan;
- JSON parsing;
- Workforce manifest/role contract validation;
- migration ownership, rollback and identifier checks;
- duplicate FQCN detection;
- package path/junk scan;
- exact `extension.json` and `FILE-SHA256.json` integrity verification;
- `bin/verify.php` package contract verification;
- ZIP CRC and safe-path validation.

The exact ZIP SHA-256 and Alpha.3→Alpha.4 archive delta are intentionally recorded in the external release handoff rather than embedded here, avoiding self-referential package metadata.

## Runtime certification boundary

This pass certifies the standalone extension package and the cross-extension contracts that can be inspected from supplied Titan packages. It does not claim a live install against the production Titan Zero Laravel/MySQL/queue runtime. Live provider boot, migrations, authenticated host requests, queue workers and installed-engine interoperability remain the final host-level certification gate.
