<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\ReadModels;

interface CrmReadStorePort
{
    /** @return list<array<string,mixed>> */
    public function query(int $companyId,string $projectionName,string $projectionVersion,array $filters=[],?string $resourcePublicId=null,int $limit=20): array;

    /** @param list<array<string,mixed>> $records @return array<string,mixed> */
    public function replaceProjection(int $companyId,array $definition,array $records,?string $projectedThroughSignalId=null,?string $sourceMaxUpdatedAt=null): array;

    /** @return array<string,mixed> */
    public function upsertResource(int $companyId,array $definition,string $resourcePublicId,array $payload,?string $projectedThroughSignalId=null): array;

    /** Bulk projection write: one indexed existence check + one state update per batch, never one COUNT(*) per resource. @param list<array<string,mixed>> $records @return array<string,mixed> */
    public function upsertResources(int $companyId,array $definition,array $records,?string $projectedThroughSignalId=null): array;

    public function deleteResource(int $companyId,string $projectionName,string $projectionVersion,string $resourcePublicId,?string $projectedThroughSignalId=null): void;

    /** @return list<array<string,mixed>> */
    public function status(int $companyId,?string $projectionName=null): array;

    public function markStale(int $companyId,string $projectionName,string $projectionVersion,?string $reason=null): void;
}
