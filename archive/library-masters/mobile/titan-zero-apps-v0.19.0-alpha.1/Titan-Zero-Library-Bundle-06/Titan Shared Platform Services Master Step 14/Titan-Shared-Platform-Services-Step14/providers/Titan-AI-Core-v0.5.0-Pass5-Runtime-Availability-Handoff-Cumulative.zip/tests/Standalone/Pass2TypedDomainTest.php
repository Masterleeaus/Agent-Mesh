<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$required = [
    'System/DTO/ExecutionIntent.php',
    'System/DTO/RuntimeContext.php',
    'System/DTO/AuthorityContext.php',
    'System/DTO/ActorContext.php',
    'System/DTO/PlanConstraint.php',
    'System/DTO/PlanDependency.php',
    'System/DTO/PlanInput.php',
    'System/DTO/PlanOutput.php',
    'System/DTO/RetryPolicy.php',
    'System/DTO/WorkforceAssignment.php',
    'System/DTO/PlanStep.php',
    'System/DTO/ValidationIssue.php',
    'System/DTO/ValidationReport.php',
    'System/Services/CanonicalPlanHasher.php',
];
foreach ($required as $rel) {
    if (!is_file($root . '/' . $rel)) {
        fwrite(STDERR, "Missing Pass 2 file: {$rel}\n");
        exit(1);
    }
    require_once $root . '/' . $rel;
}
require_once $root . '/System/DTO/PlanEnvelope.php';

use App\Extensions\TitanAICore\System\DTO\ActorContext;
use App\Extensions\TitanAICore\System\DTO\ExecutionIntent;
use App\Extensions\TitanAICore\System\DTO\PlanConstraint;
use App\Extensions\TitanAICore\System\DTO\PlanDependency;
use App\Extensions\TitanAICore\System\DTO\PlanEnvelope;
use App\Extensions\TitanAICore\System\DTO\PlanInput;
use App\Extensions\TitanAICore\System\DTO\PlanOutput;
use App\Extensions\TitanAICore\System\DTO\PlanStep;
use App\Extensions\TitanAICore\System\DTO\RetryPolicy;
use App\Extensions\TitanAICore\System\DTO\RuntimeContext;
use App\Extensions\TitanAICore\System\DTO\ValidationIssue;
use App\Extensions\TitanAICore\System\DTO\ValidationReport;
use App\Extensions\TitanAICore\System\DTO\WorkforceAssignment;
use App\Extensions\TitanAICore\System\Services\CanonicalPlanHasher;

$actor = new ActorContext('user-1', 'human', 'tenant-1', ['ai.core.plan.create'], 2, true);
$runtime = new RuntimeContext('tenant-1', $actor, 'trace-1', 'corr-1', 'cause-1', 'root-1', 'op-1', 'idem-1', 'CONFIDENTIAL', ['cloud' => false]);
$intent = new ExecutionIntent('complete_job', 'Complete job 42 safely', ['job_id' => '42']);
$step1 = new PlanStep('lookup-job', 'Lookup job', 'crm.job.read', [], [new PlanInput('job_id', 'string', 'intent.job_id')], [], [new PlanOutput('job', 'object')], 10, new RetryPolicy(1, 'none', 0), null, null, []);
$step2 = new PlanStep('complete-job', 'Complete job', 'crm.job.complete', [new PlanDependency('lookup-job', 'hard')], [new PlanInput('job', 'object', 'step.lookup-job.job')], [], [new PlanOutput('receipt', 'object')], 30, new RetryPolicy(3, 'exponential', 250), new WorkforceAssignment('manager', 'operations', 1), 'MEDIUM', ['job_completion_policy']);
$plan = new PlanEnvelope('plan-1', $runtime, $intent, [$step1, $step2], [new PlanConstraint('max_duration_seconds', 3600)], '1.0', '1.0', '0.3.0');

if ($plan->tenantCompanyId() !== 'tenant-1') { fwrite(STDERR, "tenant mismatch\n"); exit(1); }
if ($plan->steps[1]->dependsOn[0]->stepId !== 'lookup-job') { fwrite(STDERR, "dependency mismatch\n"); exit(1); }
if ($plan->steps[1]->requiredInputs[0]->source !== 'step.lookup-job.job' || $plan->steps[1]->optionalInputs !== []) { fwrite(STDERR, "required/optional input split missing\n"); exit(1); }
if ($plan->toArray()['runtime_context']['actor']['actor_type'] !== 'human') { fwrite(STDERR, "actor serialization mismatch\n"); exit(1); }
$hash1 = (new CanonicalPlanHasher())->hash($plan);
$hash2 = (new CanonicalPlanHasher())->hash($plan);
if ($hash1 !== $hash2 || strlen($hash1) !== 64) { fwrite(STDERR, "plan hash is not deterministic\n"); exit(1); }
$report = new ValidationReport(false, false, [new ValidationIssue('error','DAG_NOT_VALIDATED','Plan DAG has not passed deterministic validation', null)], [], []);
if ($report->valid || $report->executable || $report->errors[0]->code !== 'DAG_NOT_VALIDATED') { fwrite(STDERR, "validation report mismatch\n"); exit(1); }
if ($plan->planSchemaVersion !== '1.0' || $plan->schemaVersion !== '1.0') { fwrite(STDERR, "schema versions missing\n"); exit(1); }
if ($runtime->idempotencyKey !== 'idem-1' || $runtime->rootCausationId !== 'root-1') { fwrite(STDERR, "causal/idempotency context missing\n"); exit(1); }

fwrite(STDOUT, "Pass 2 typed domain test: PASS\n");
