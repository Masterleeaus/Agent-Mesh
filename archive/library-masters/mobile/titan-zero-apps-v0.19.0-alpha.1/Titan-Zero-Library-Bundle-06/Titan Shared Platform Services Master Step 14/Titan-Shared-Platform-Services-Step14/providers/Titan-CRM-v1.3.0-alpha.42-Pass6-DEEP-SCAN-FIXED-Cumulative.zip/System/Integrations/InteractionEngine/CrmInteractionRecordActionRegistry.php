<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\InteractionEngine;

/** Explicit record-scoped actions for records CRM Core actually owns. */
final class CrmInteractionRecordActionRegistry
{
    /** @var array<string,list<array{journey:string,label:string,keywords:list<string>,required_context:list<string>}>> */
    private const ACTIONS = [
        'customer'=>[
            ['journey'=>'update-customer','label'=>'Update Customer','keywords'=>['update customer','edit customer','change customer','change details','update details','address','phone','email'],'required_context'=>['public_id']],
        ],
        'contact'=>[
            ['journey'=>'update-contact','label'=>'Update Contact','keywords'=>['update contact','edit contact','change contact','change details','address','phone','email'],'required_context'=>['public_id']],
        ],
        'lead'=>[
            ['journey'=>'update-lead','label'=>'Update Lead','keywords'=>['update lead','edit lead','change lead','change status','assign lead'],'required_context'=>['public_id']],
            ['journey'=>'convert-lead','label'=>'Convert Lead','keywords'=>['convert lead','make customer','turn into customer','qualify lead'],'required_context'=>['public_id']],
        ],
        'opportunity'=>[
            ['journey'=>'update-opportunity','label'=>'Update Opportunity','keywords'=>['update opportunity','edit opportunity','change opportunity','change value'],'required_context'=>['public_id']],
            ['journey'=>'move-opportunity','label'=>'Move Opportunity','keywords'=>['move opportunity','move stage','change stage','pipeline stage'],'required_context'=>['public_id']],
            ['journey'=>'win-opportunity','label'=>'Mark Won','keywords'=>['mark won','won deal','win opportunity','close won'],'required_context'=>['public_id']],
            ['journey'=>'lose-opportunity','label'=>'Mark Lost','keywords'=>['mark lost','lost deal','lose opportunity','close lost'],'required_context'=>['public_id']],
        ],
        'quote'=>[
            ['journey'=>'accept-quote','label'=>'Accept Quote','keywords'=>['accept quote','approve quote','quote accepted'],'required_context'=>['public_id']],
            ['journey'=>'transition-quote','label'=>'Change Quote Status','keywords'=>['send quote','void quote','reject quote','expire quote','change quote status'],'required_context'=>['public_id','type']],
        ],
        'invoice'=>[
            ['journey'=>'send-invoice','label'=>'Send Invoice','keywords'=>['send invoice','email invoice'],'required_context'=>['public_id']],
            ['journey'=>'send-invoice-reminder','label'=>'Send Reminder','keywords'=>['remind customer','send reminder','overdue reminder'],'required_context'=>['public_id']],
            ['journey'=>'transition-invoice','label'=>'Change Invoice Status','keywords'=>['issue invoice','send invoice','void invoice','change invoice status'],'required_context'=>['public_id']],
        ],
    ];

    public function __construct(private readonly CrmInteractionJourneyRegistry $journeys) {}

    /** @return list<array<string,mixed>> */
    public function forRecord(string $recordType,array $context=[]): array
    {
        $recordType=$this->normaliseType($recordType);$out=[];
        foreach(self::ACTIONS[$recordType]??[] as $action){
            if(!$this->journeys->has($action['journey']))continue;
            $missing=array_values(array_filter($action['required_context'],static fn(string $key):bool=>!isset($context[$key])||$context[$key]===''));
            $out[]=$action+['record_type'=>$recordType,'definition'=>$this->journeys->get($action['journey']),'available'=>$missing===[],'missing_context'=>$missing,'prefill'=>$this->prefill($context)];
        }
        return $out;
    }

    /** @return array<string,mixed>|null */
    public function resolve(string $message,array $context): ?array
    {
        $type=$this->normaliseType((string)($context['record_type']??''));if($type==='')return null;
        $text=mb_strtolower(trim($message));$best=null;$score=0;
        foreach($this->forRecord($type,$context) as $action){
            if(($action['available']??false)!==true)continue;$candidate=0;
            foreach($action['keywords'] as $phrase)if(str_contains($text,mb_strtolower($phrase)))$candidate+=max(1,count(explode(' ',$phrase)));
            if($candidate>$score){$score=$candidate;$best=$action;}
        }
        return $best===null?null:$best+['confidence'=>min(1.0,$score/3)];
    }

    /** @return array<string,mixed> */
    private function prefill(array $context): array
    {
        $values=$context;unset($values['record_type']);
        return $values;
    }

    private function normaliseType(string $type): string
    {
        return match(strtolower(trim($type))){
            'company','account','customer_company'=>'customer','deal'=>'opportunity','proposal','estimate'=>'quote',
            default=>strtolower(trim($type)),
        };
    }
}
