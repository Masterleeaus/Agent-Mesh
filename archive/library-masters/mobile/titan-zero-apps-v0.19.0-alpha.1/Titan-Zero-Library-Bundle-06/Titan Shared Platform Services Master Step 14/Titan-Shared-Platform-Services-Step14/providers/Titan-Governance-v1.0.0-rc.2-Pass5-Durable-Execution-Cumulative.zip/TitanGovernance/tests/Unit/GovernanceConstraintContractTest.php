<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\Tests\Unit;

use PHPUnit\Framework\TestCase;

final class GovernanceConstraintContractTest extends TestCase
{
    public function test_example_constraint_can_only_contract_authority(): void
    {
        $data=json_decode((string)file_get_contents(dirname(__DIR__,2).'/examples/governance-authority-constraint.json'),true,512,JSON_THROW_ON_ERROR);
        self::assertSame('titan-governance',$data['source']); self::assertContains($data['disposition'],['PASS','CONTRACT','REQUIRE_APPROVAL','HOLD','DENY']);
        self::assertLessThanOrEqual(100,$data['ceiling_score']); self::assertNotEmpty($data['reason_codes']);
    }
}
