# Titan Connect v0.10.4 — Live MagicAI Menu Materialization

## Why v0.10.2 installed without menu links

The live Titan Zero SQL supplied after installation confirms that MagicAI renders structural navigation from its shared `menus` table. Titan Connect v0.10.2 registered semantic navigation only through optional Blueprint-v3 registries. On this host those registries do not materialize rows into `menus`, so the routes were installed but the sidebar had no Titan Connect records to render.

## v0.10.4 fix

Migration `2026_08_09_000007_sync_magicai_menu_rows.php` invokes `MagicAiMenuSynchronizer` and writes the extension-owned structural rows into the real `menus` table idempotently.

User navigation is materialized as two roots:

- Inbox (order 6)
  - Unified Inbox
  - Team / Internal
  - External / Omnichannel
  - Assigned to Me
  - Unassigned
  - Needs Human
  - Closed / Archived
- Channels (order 7)
  - WhatsApp
  - Messenger
  - Instagram
  - Telegram
  - SMS
  - Voice
  - Push / Mobile

Each child resolves and stores the numeric `parent_id` of its parent key.

## Super Admin compatibility

The supplied host `menus` schema has no persisted `is_admin` field. MagicAI administrator authorization is also derived from existing static admin menu keys and route patterns. v0.10.4 therefore does not mutate the shared menu schema and does not invent a new permission model.

For database-only compatibility, Titan Connect settings entries are added below the host's existing `settings` root and use the `dashboard.admin.settings.titan-connect.channels.*` route family. The routes themselves use `web`, `auth`, and `admin` middleware. This keeps the host's existing Settings administrator permission authoritative.

Blueprint-v3 registry registration remains available for hosts that expose those registries.

## Cache handling

After menu synchronization Titan Connect calls `App\Services\Common\MenuService::regenerate()` when the host exposes it. `php artisan titan-connect:host-sync` can be rerun safely at any time and rematerializes missing rows before cache regeneration.

## Notification badge safety

The shared `menus.badge` field is not used for company/user unread counts. MagicAI caches structural navigation globally, so persisting a per-user unread count there could expose one company's state to another. Titan Connect retains its authenticated company + actor scoped badge API and browser badge client instead.

## Manual recovery fallback

If an operator needs to repair menu rows outside the extension migration, `host-patches/TitanConnect-v0.10.4-menu-repair.sql` contains an idempotent SQL fallback matching the supplied live schema. Run `php artisan titan-connect:host-sync` after applying it.
