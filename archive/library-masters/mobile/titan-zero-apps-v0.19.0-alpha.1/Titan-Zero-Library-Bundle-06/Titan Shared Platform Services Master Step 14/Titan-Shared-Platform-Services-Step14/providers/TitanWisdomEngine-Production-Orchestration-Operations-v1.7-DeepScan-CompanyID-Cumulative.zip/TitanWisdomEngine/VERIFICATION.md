# Titan Wisdom v0.3.0 Verification

## Fresh behavioral verification

Executed standalone smoke suites:

- `tests/Smoke/OutcomeDomainSmoke.php` — PASS, including governed insert, tenant propagation, lifecycle invariants, idempotent duplicate return, collision rejection, governance denial, and JSON-object serialization for empty `context_versions`.
- `tests/Smoke/EvidenceResolutionSmoke.php` — PASS, including self-report authority rejection, validated external evidence, idempotent attachment, evidence reuse across related outcomes, authoritative resolution, optimistic version increment, transition provenance, governance provenance separation, duplicate resolution and terminal-work exclusion.
- `tests/Smoke/RevisionDelayedObservationSmoke.php` — PASS, including append-only contradiction, revision lineage, original-record immutability, overdue scan, complete tenant/causal context and stable observation idempotency.
- `tests/Smoke/DeliveryContractSmoke.php` — PASS, including `ShouldQueue` + `ShouldBeUnique`, dedicated queue, dispatch kill switch, every-five-minute schedule, overlap protection and one-server scheduling.
- `tests/Smoke/CertificationDisableSafetySmoke.php` — PASS; intentionally disabled runtime routes do not create false certification failure.

## Contract/schema verification

Actual PHP-produced instances validated against the shipped Draft 2020-12 JSON Schemas:

- canonical `EvidenceReference` — PASS
- evidence attachment receipt — PASS
- outcome resolution receipt — PASS
- `wisdom.outcome.observation_due.v1` payload — PASS

All 10 Wisdom JSON Schema documents pass Draft 2020-12 meta-schema validation.

A contract edge case discovered during verification was corrected: an empty `context_versions` map now emits/persists JSON `{}` rather than `[]`. The existing v0.2 idempotency fingerprint representation was intentionally left unchanged to preserve retry compatibility with earlier records.

## Source/package verification

- PHP lint: 79/79 packaged PHP source/test files PASS.
- JSON parse: 15/15 JSON documents PASS.
- Blueprint v4.2 canonical Manifest v2.2 validation: PASS (`titan-wisdom` 0.3.0, `intelligence-engine`).
- Blueprint architecture scan with warnings-as-errors: PASS (`critical=0 warnings=0 info=0`).
- Blueprint package secret/filesystem scan: PASS.
- Blueprint MySQL strict-mode migration scan: PASS.
- Blueprint migration stability scan: PASS.
- Blueprint v4.2 production gate with warnings-as-errors: PASS.

## Final Installer 1.7.8 frozen-package gate

- Root integrity inventory: 112/112 regular package files covered; only root `extension.json` is self-excluded as required.
- `validate_manifest.py --production --canonical --check-files`: PASS.
- Installer 1.7.8 flat-root ZIP integrity/path verifier: PASS.
- ZIP traversal entries: 0.
- ZIP symlinks: 0.

The archive SHA-256 is computed externally after the ZIP is frozen, because embedding an archive hash inside that same archive would be recursively unstable.

## Not claimed

- Live MagicAI/Laravel host install/upgrade/uninstall certification is not performed in this workspace.
- PHPUnit is not installed globally or package-locally; PHPUnit test classes ship with the package but only the standalone smoke scripts above are claimed as executed here.
- Attribution, pattern learning and calibration feedback are not implemented in v0.3.0.
- `OutcomeObservationDue` is an extension-owned application event. A Signal adapter can bridge it to Titan Signal without importing Signal internals; direct live Signal-host certification is not claimed in this pass.
