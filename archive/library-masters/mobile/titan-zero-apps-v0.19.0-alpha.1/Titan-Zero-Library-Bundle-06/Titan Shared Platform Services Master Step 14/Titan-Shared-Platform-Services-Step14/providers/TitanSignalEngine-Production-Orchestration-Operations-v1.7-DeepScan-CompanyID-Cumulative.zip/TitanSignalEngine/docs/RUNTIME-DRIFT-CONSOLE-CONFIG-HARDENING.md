# Runtime Drift, Console & Configuration Hardening

Titan Signal Engine v0.19.0 hardens the runtime/package contract without changing immutable event semantics.

## Console error boundary

HTTP controllers never return raw exception messages. `SignalConsoleErrorReporter` emits a short `SIG-…` reference to the user and sends the full exception plus bounded operation/context metadata to Laravel logging. This prevents SQL paths, driver details, storage locators, or internal exception text from becoming tenant-visible.

## Historical migration reproducibility

Historical migration `2026_08_11_000004_harden_titan_signal_foundation.php` is self-contained. It must not import `SignalEnvelope` or any other evolving Signal runtime class. Its canonical JSON ordering, SHA-256 checksum, timestamp normalization and legacy idempotency fingerprint are frozen inside the migration so a fresh installation years later executes the historical transformation that was originally intended.

## Navigation contributions

The extension manifest declares Blueprint contribution-registry entries for `navigation.user` and `navigation.admin`. Contributors return named routes plus permission hints; they never hard-code URLs. The host remains authoritative for actual menu placement and must register only enabled extensions and routes that exist.

## Configuration contract

Configuration exists only when runtime code consumes it. v0.19.0 removes decorative keys and wires retained controls including queue name, delivery recovery limit, rollout stage, registry scan/history bounds, and causation-repair chunk size.

## Bounded operational reads

Console, registry, archive rebuild, anomaly, delivery recovery, Pulse and automatic-evaluation scans use explicit limits, cursors, or chunks. Lifecycle operations intentionally retain buffered `get()` snapshots where exact candidate locking is required; those reads are already constrained by explicit candidate IDs or caller limits and are not converted merely to satisfy a heuristic scanner.
