<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalRedactionOverlay
{
    /** @param list<array{op:string,path:string,value?:mixed}> $operations */
    public function __construct(public array $operations)
    {
        foreach ($operations as $operation) {
            $op = $operation['op'] ?? null;
            $path = $operation['path'] ?? null;
            if (! in_array($op, ['remove', 'replace'], true) || ! is_string($path) || $path === '') {
                throw new InvalidArgumentException('Redaction operations require remove|replace and a non-empty path.');
            }
            if (! str_starts_with($path, 'payload.') && ! str_starts_with($path, 'metadata.')) {
                throw new InvalidArgumentException('Redaction paths are limited to payload.* or metadata.* fields.');
            }
            if ($op === 'replace' && ! array_key_exists('value', $operation)) {
                throw new InvalidArgumentException('Replace redaction operations require a value.');
            }
        }
    }

    /** @param array<string,mixed> $event @return array<string,mixed> */
    public function apply(array $event): array
    {
        foreach ($this->operations as $operation) {
            $segments = explode('.', $operation['path']);
            $this->applyOperation($event, $segments, $operation);
        }
        return $event;
    }

    /** @param array<string,mixed> $target @param list<string> $segments @param array{op:string,path:string,value?:mixed} $operation */
    private function applyOperation(array &$target, array $segments, array $operation): void
    {
        $key = array_shift($segments);
        if ($key === null || $key === '') {
            return;
        }
        if ($segments === []) {
            if ($operation['op'] === 'remove') {
                unset($target[$key]);
            } else {
                $target[$key] = $operation['value'];
            }
            return;
        }
        if (! isset($target[$key]) || ! is_array($target[$key])) {
            if ($operation['op'] === 'replace') {
                $target[$key] = [];
            } else {
                return;
            }
        }
        /** @var array<string,mixed> $child */
        $child = $target[$key];
        $this->applyOperation($child, $segments, $operation);
        $target[$key] = $child;
    }
}
