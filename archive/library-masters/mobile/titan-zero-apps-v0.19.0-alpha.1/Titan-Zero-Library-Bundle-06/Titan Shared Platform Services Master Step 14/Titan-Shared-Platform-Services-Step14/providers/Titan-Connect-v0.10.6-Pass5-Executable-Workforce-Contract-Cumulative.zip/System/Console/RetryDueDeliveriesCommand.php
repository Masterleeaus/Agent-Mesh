<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Console;

use App\Extensions\TitanConnect\System\Delivery\OutboundDeliveryService;
use App\Extensions\TitanConnect\System\Models\OutboundDelivery;
use Illuminate\Console\Command;

final class RetryDueDeliveriesCommand extends Command
{
    protected $signature = 'titan-connect:retry-deliveries {--limit=100 : Maximum deliveries to attempt in one run}';
    protected $description = 'Attempt queued or failed Titan Connect deliveries whose retry time is due.';

    public function handle(OutboundDeliveryService $deliveryService): int
    {
        $limit = min(1000, max(1, (int) $this->option('limit')));
        $deliveries = OutboundDelivery::query()
            ->whereIn('status', ['queued', 'failed', 'sending'])
            ->where(function ($query): void {
                $query->whereNull('next_attempt_at')->orWhere('next_attempt_at', '<=', now());
            })
            ->orderBy('id')
            ->limit($limit)
            ->limit(5000)->get();

        $attempted = 0;
        $failed = 0;
        foreach ($deliveries as $delivery) {
            try {
                $before = (int) $delivery->attempt_count;
                $result = $deliveryService->attempt($delivery);
                if ((int) $result->attempt_count > $before) {
                    $attempted++;
                }
                if ($result->status === 'failed') {
                    $failed++;
                }
            } catch (\Throwable $e) {
                $failed++;
                $this->error(sprintf('Delivery %s failed: %s', $delivery->uuid, $e->getMessage()));
            }
        }

        $this->info(sprintf('Titan Connect retry pass: %d attempted, %d currently failed.', $attempted, $failed));
        return self::SUCCESS;
    }
}
