<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Services;

use App\Extensions\TitanNexus\System\Contracts\AssuranceGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\AutonomyGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\GovernanceGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\ProvisioningCommandGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\ProvisioningExecutorContract;
use App\Extensions\TitanNexus\System\Contracts\RewindGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\RiskGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\SignalGatewayContract;
use App\Extensions\TitanNexus\System\Domain\AssuranceDecision;
use App\Extensions\TitanNexus\System\Domain\AutonomyDecision;
use App\Extensions\TitanNexus\System\Domain\GovernanceDecision;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlan;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlanStatus;
use App\Extensions\TitanNexus\System\Domain\ProvisioningReceipt;
use App\Extensions\TitanNexus\System\Domain\ProvisioningReceiptStatus;
use App\Extensions\TitanNexus\System\Domain\RiskDecision;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use InvalidArgumentException;
use LogicException;
use RuntimeException;
use Throwable;

final class GovernedProvisioningExecutor implements ProvisioningExecutorContract
{
    public function __construct(
        private readonly ProvisioningCommandGatewayContract $gateway,
        private readonly ?RiskGatewayContract $risk = null,
        private readonly ?GovernanceGatewayContract $governance = null,
        private readonly ?AssuranceGatewayContract $assurance = null,
        private readonly ?SignalGatewayContract $signal = null,
        private readonly ?RewindGatewayContract $rewind = null,
        private readonly ?AutonomyGatewayContract $autonomy = null,
    ) {
    }

    public function execute(
        ProvisioningPlan $plan,
        TraceContext $traceContext,
        bool $approvalGranted = false,
        ?ProvisioningExecutionContext $executionContext = null,
    ): ProvisioningPlan {
        if ($plan->tenantCompanyId() !== $traceContext->tenantCompanyId()) {
            throw new InvalidArgumentException('Provisioning plan and trace context must belong to the same tenant.');
        }
        if ($plan->executed()) {
            throw new LogicException('Provisioning plan has already been executed.');
        }
        if ($plan->status() === ProvisioningPlanStatus::Blocked) {
            throw new LogicException('Blocked provisioning plans cannot execute.');
        }

        $executionContext ??= ProvisioningExecutionContext::human(
            $plan->tenantCompanyId(),
            'legacy-caller',
            $approvalGranted ? 'legacy-explicit-approval' : null,
        );
        if ($executionContext->tenantCompanyId() !== $plan->tenantCompanyId()) {
            throw new InvalidArgumentException('Provisioning execution context must belong to the same tenant as the plan.');
        }
        if ($plan->status() === ProvisioningPlanStatus::RequiresApproval && !$executionContext->hasApprovalEvidence()) {
            throw new LogicException('Provisioning plan requires explicit approval evidence before execution.');
        }

        $receipts = [];
        $receiptByOperation = [];
        foreach ($plan->operations() as $operation) {
            $dependencyFailed = false;
            foreach ($operation->dependsOnOperationIds() as $dependencyId) {
                if (!isset($receiptByOperation[$dependencyId]) || !$receiptByOperation[$dependencyId]->successful()) {
                    $dependencyFailed = true;
                    break;
                }
            }
            if ($dependencyFailed) {
                $receipt = ProvisioningReceipt::skippedDependency($operation, 'A required provisioning dependency did not complete successfully.');
                $receipt = $this->observeNonMutation($receipt, $operation, $traceContext, $executionContext, 'nexus.operation.skipped');
            } else {
                $receipt = $this->executeOperation($operation, $traceContext, $executionContext);
            }
            $receipts[] = $receipt;
            $receiptByOperation[$operation->operationId()] = $receipt;
        }
        return $plan->withReceipts($receipts);
    }

    private function executeOperation(
        ProvisioningOperation $operation,
        TraceContext $traceContext,
        ProvisioningExecutionContext $executionContext,
    ): ProvisioningReceipt {
        $evidence = ['execution_context' => $executionContext->toArray()];
        try {
            $risk = $this->requiredRisk()->evaluate($operation, $traceContext, $executionContext);
            $evidence += $this->riskEvidence($risk);
            if (!$risk->allowed()) {
                return $this->blockedReceipt($operation, $traceContext, $executionContext, $evidence, 'risk', $risk->reason() ?? 'Risk denied provisioning operation.');
            }

            $governance = $this->requiredGovernance()->authorize($operation, $traceContext, $executionContext, $risk);
            $evidence += $this->governanceEvidence($governance);
            if (!$governance->allowed()) {
                return $this->blockedReceipt($operation, $traceContext, $executionContext, $evidence, 'governance', $governance->reason() ?? 'Governance denied provisioning operation.');
            }
            if ($operation->disposition() === \App\Extensions\TitanNexus\System\Domain\SemanticChangeDisposition::RequiresApproval
                && !$governance->approvalRequired()) {
                return $this->blockedReceipt($operation, $traceContext, $executionContext, $evidence, 'approval', 'Governance cannot downgrade an operation whose semantic disposition requires approval.');
            }
            if ($governance->approvalRequired()) {
                if (!$executionContext->hasApprovalEvidence() || $governance->approvalReference() === null
                    || !hash_equals($executionContext->approvalReference() ?? '', $governance->approvalReference())) {
                    return $this->blockedReceipt($operation, $traceContext, $executionContext, $evidence, 'approval', 'Governance approval evidence is missing or does not match the execution context.');
                }
            }

            $autonomy = null;
            if ($executionContext->autonomous()) {
                $autonomy = $this->requiredAutonomy()->authorize($operation, $traceContext, $executionContext, $risk, $governance);
                $evidence += $this->autonomyEvidence($autonomy);
                if (!$autonomy->allowed()) {
                    return $this->blockedReceipt($operation, $traceContext, $executionContext, $evidence, 'autonomy', $autonomy->reason() ?? 'Autonomy denied provisioning operation.');
                }
            }

            $assurance = $this->requiredAssurance()->verify($operation, $traceContext, $executionContext, $risk, $governance, $autonomy);
            $evidence += $this->assuranceEvidence($assurance);
            if (!$assurance->allowed() || !$this->assuranceSatisfies($risk, $assurance)) {
                return $this->blockedReceipt($operation, $traceContext, $executionContext, $evidence, 'assurance', $assurance->reason() ?? 'Assurance evidence did not satisfy the required level.');
            }

            $evidence['pre_signal_reference'] = $this->requiredSignal()->emit('nexus.operation.authorized', $operation, $traceContext, $executionContext, $evidence);
            $evidence['pre_rewind_reference'] = $this->requiredRewind()->record('nexus.operation.prepared', $operation, $traceContext, $executionContext, $evidence);

            $receipt = $this->gateway->execute($operation, $traceContext);
            $event = match ($receipt->status()) {
                ProvisioningReceiptStatus::Applied => 'nexus.operation.applied',
                ProvisioningReceiptStatus::AlreadyApplied => 'nexus.operation.already_applied',
                ProvisioningReceiptStatus::SkippedDependency => 'nexus.operation.skipped',
                ProvisioningReceiptStatus::Failed => 'nexus.operation.failed',
            };
            $evidence['post_observability_complete'] = true;
            $postErrors = [];
            try {
                $evidence['outcome_signal_reference'] = $this->requiredSignal()->emit($event, $operation, $traceContext, $executionContext, $evidence + ['mutation_receipt' => $receipt->toArray()]);
            } catch (Throwable $exception) {
                $evidence['post_observability_complete'] = false;
                $postErrors[] = 'signal:' . $exception::class;
            }
            try {
                $evidence['outcome_rewind_reference'] = $this->requiredRewind()->record($event, $operation, $traceContext, $executionContext, $evidence + ['mutation_receipt' => $receipt->toArray()]);
            } catch (Throwable $exception) {
                $evidence['post_observability_complete'] = false;
                $postErrors[] = 'rewind:' . $exception::class;
            }
            if ($postErrors !== []) {
                $evidence['post_observability_errors'] = $postErrors;
            }
            $metadata = $receipt->metadata();
            $metadata['governance'] = $evidence;
            return $receipt->withMetadata($metadata);
        } catch (Throwable $exception) {
            $evidence['failure_stage'] = $evidence['failure_stage'] ?? 'governance_dependency';
            $evidence['failure_class'] = $exception::class;
            $receipt = ProvisioningReceipt::failed($operation, 'Governed provisioning failed closed: ' . $exception::class);
            $metadata = $receipt->metadata();
            $metadata['governance'] = $evidence;
            return $receipt->withMetadata($metadata);
        }
    }

    /** @param array<string,mixed> $evidence */
    private function blockedReceipt(ProvisioningOperation $operation, TraceContext $traceContext, ProvisioningExecutionContext $executionContext, array $evidence, string $stage, string $message): ProvisioningReceipt
    {
        $evidence['failure_stage'] = $stage;
        $evidence['post_observability_complete'] = true;
        try { $evidence['outcome_signal_reference'] = $this->requiredSignal()->emit('nexus.operation.blocked', $operation, $traceContext, $executionContext, $evidence); }
        catch (Throwable $exception) { $evidence['post_observability_complete'] = false; $evidence['signal_error'] = $exception::class; }
        try { $evidence['outcome_rewind_reference'] = $this->requiredRewind()->record('nexus.operation.blocked', $operation, $traceContext, $executionContext, $evidence); }
        catch (Throwable $exception) { $evidence['post_observability_complete'] = false; $evidence['rewind_error'] = $exception::class; }
        return ProvisioningReceipt::failed($operation, $message)->withMetadata(['governance' => $evidence]);
    }

    private function observeNonMutation(ProvisioningReceipt $receipt, ProvisioningOperation $operation, TraceContext $traceContext, ProvisioningExecutionContext $executionContext, string $event): ProvisioningReceipt
    {
        $evidence = ['execution_context' => $executionContext->toArray(), 'post_observability_complete' => true];
        try { $evidence['outcome_signal_reference'] = $this->requiredSignal()->emit($event, $operation, $traceContext, $executionContext, $evidence); }
        catch (Throwable $exception) { $evidence['post_observability_complete'] = false; $evidence['signal_error'] = $exception::class; }
        try { $evidence['outcome_rewind_reference'] = $this->requiredRewind()->record($event, $operation, $traceContext, $executionContext, $evidence); }
        catch (Throwable $exception) { $evidence['post_observability_complete'] = false; $evidence['rewind_error'] = $exception::class; }
        return $receipt->withMetadata(['governance' => $evidence]);
    }

    /** @return array<string,mixed> */ private function riskEvidence(RiskDecision $d): array { return ['risk_decision_reference'=>$d->decisionReference(),'risk_class'=>$d->riskClass(),'required_assurance'=>$d->requiredAssurance()]; }
    /** @return array<string,mixed> */ private function governanceEvidence(GovernanceDecision $d): array { return ['governance_decision_reference'=>$d->decisionReference(),'governance_approval_required'=>$d->approvalRequired(),'approval_reference'=>$d->approvalReference()]; }
    /** @return array<string,mixed> */ private function autonomyEvidence(AutonomyDecision $d): array { return ['autonomy_decision_reference'=>$d->decisionReference(),'autonomy_authority_level'=>$d->authorityLevel()]; }
    /** @return array<string,mixed> */ private function assuranceEvidence(AssuranceDecision $d): array { return ['assurance_evidence_reference'=>$d->evidenceReference(),'assurance_level'=>$d->assuranceLevel()]; }

    private function assuranceSatisfies(RiskDecision $risk, AssuranceDecision $assurance): bool
    {
        if ($risk->requiredAssurance() === 'policy') { return true; }
        $rank = ['NONE'=>0,'RED'=>1,'AMBER'=>2,'GREEN'=>3,'policy'=>4];
        return ($rank[$assurance->assuranceLevel()] ?? -1) >= ($rank[$risk->requiredAssurance()] ?? 99);
    }

    private function requiredRisk(): RiskGatewayContract { return $this->risk ?? throw new RuntimeException('Titan Nexus Risk gateway is required for provisioning execution.'); }
    private function requiredGovernance(): GovernanceGatewayContract { return $this->governance ?? throw new RuntimeException('Titan Nexus Governance gateway is required for provisioning execution.'); }
    private function requiredAssurance(): AssuranceGatewayContract { return $this->assurance ?? throw new RuntimeException('Titan Nexus Assurance gateway is required for provisioning execution.'); }
    private function requiredSignal(): SignalGatewayContract { return $this->signal ?? throw new RuntimeException('Titan Nexus Signal gateway is required for provisioning execution.'); }
    private function requiredRewind(): RewindGatewayContract { return $this->rewind ?? throw new RuntimeException('Titan Nexus Rewind gateway is required for provisioning execution.'); }
    private function requiredAutonomy(): AutonomyGatewayContract { return $this->autonomy ?? throw new RuntimeException('Titan Nexus Autonomy gateway is required for autonomous provisioning execution.'); }
}
