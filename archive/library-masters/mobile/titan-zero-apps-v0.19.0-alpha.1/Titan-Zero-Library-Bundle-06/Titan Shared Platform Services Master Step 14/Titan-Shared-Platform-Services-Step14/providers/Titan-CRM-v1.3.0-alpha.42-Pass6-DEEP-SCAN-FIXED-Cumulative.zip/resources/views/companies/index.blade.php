@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Customers','subtitle'=>'Organisations and customer accounts.','surface'=>'customers','journey'=>'new-customer','secondaryJourneys'=>['new-contact']])
<form class="mb-3"><div class="input-group"><input class="form-control" name="q" value="{{ $q }}" placeholder="Search customers"><button class="btn btn-outline-secondary">Search</button></div></form>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Status</th></tr></thead><tbody>@forelse($companies as $company)<tr><td><a href="{{ route('dashboard.user.crm.companies.show',$company['public_id']) }}" class="fw-semibold">{{ $company['name'] }}</a></td><td>{{ $company['email'] ?? '—' }}</td><td>{{ $company['phone'] ?? '—' }}</td><td>{{ ucfirst($company['status'] ?? 'active') }}</td></tr>@empty<tr><td colspan="4" class="text-muted">No customers found.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
