# Failure Modes

- Missing tenant context: deny.
- Governance unavailable for writes: deny.
- Communications unavailable: record unavailable state; do not impersonate delivery.
- Time Attendance unavailable: hourly authoritative-time operations fail closed; configured salaried flows may proceed without time evidence.
- Kill switch: deny mutating operations and report DISABLED.
