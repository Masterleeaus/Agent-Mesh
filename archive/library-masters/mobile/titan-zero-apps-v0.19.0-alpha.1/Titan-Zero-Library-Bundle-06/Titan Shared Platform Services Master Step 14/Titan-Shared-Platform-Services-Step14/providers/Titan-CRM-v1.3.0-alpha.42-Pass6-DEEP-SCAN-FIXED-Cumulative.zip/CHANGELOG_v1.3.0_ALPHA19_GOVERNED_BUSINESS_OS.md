# CRM 1.3.0-alpha.19 — Governed Business OS Boundary

Alpha.19 preserves the existing CRM, Field Services, Pay, Locker, bookkeeping, mobile, assistant, Interaction Engine and installer code while hardening CRM as Titan's authoritative operational source of truth.

## Governed mutation boundary

- Adds `CrmCommandBusPort`, `CrmCommandRequest` and `CrmCommandBusGateway`.
- TitanAI, Interaction Engine and Chatbot AI mutations now request CRM capabilities through the Command Bus gateway instead of directly mutating CRM repositories/services.
- Titan owner actions enter the same gateway. A configurable owner/admin/web compatibility fallback remains available for trusted human surfaces when the standalone Titan Command Bus engine is not installed.
- AI, Chatbot and Interaction Engine writes do **not** use the compatibility fallback; without an external Command Bus binding they return a structured `awaiting_command_bus` result and do not mutate CRM.
- Legacy CRM Assistant success evidence is recorded only after an authoritative CRM execution receipt exists.

## Canonical tenant + trace context

- Retains the existing fail-closed `tenant_company_id` resolver and tenant isolation.
- Adds `trace_id` and `causation_id` alongside the existing `correlation_id`.
- Governed command and receipt structures carry tenant, actor, trace, correlation and causation references.

## Capability contract v2

Every manifest capability is enriched with:

- capability name and owning extension
- input/output contract metadata
- risk profile
- autonomy requirement
- evidence requirements
- offline policy
- reversibility
- idempotency strategy
- concurrency policy
- Command Bus / Signal / Rewind governance flags

The actual capability list remains derived from the existing CRM implementation rather than replacing it with a new generic CRUD layer.

## Domain safety + optimistic concurrency

- Adds additive `entity_version` columns to important authoritative aggregates.
- Adds stale-write rejection when callers provide `expected_version`.
- Adds invariant guards for terminal work-order dispatch/rescheduling, invalid invoice/payment states and appointment overlap detection.
- Existing repositories and domain services remain authoritative and continue to enforce their own lifecycle rules.

## Authoritative receipts, Signal and Rewind

- Every governed write executed by `CrmCapabilityExecutor` now returns an authoritative command receipt.
- Receipts contain command/receipt IDs, entity versions, state hashes, trace/correlation/causation IDs and a structured `rewind_reference`.
- The idempotency ledger persists the receipt so duplicate command retries replay the original authoritative result instead of re-running the mutation.
- Adds the transactional `crm_domain_signal_outbox` for durable CRM domain events consumed by Titan Signal.
- Signal outbox failure is fail-closed by default so a governed mutation cannot silently succeed without an observable event record.

## Safe AI read model

- Adds `crm.ai.context.read` and `CrmAiReadModelService`.
- AI/Workforce consumers receive bounded, normalized, tenant-scoped CRM context instead of arbitrary table/database access.
- Internal numeric IDs, tenant/user ownership columns and secret/token/password fields are removed from record payloads.
- Public IDs and `entity_version` remain available where present for safe reference and stale-context checks.

## Preserved compatibility

- No destructive replacement of existing CRM schemas, UI, routes, services or installers.
- The alpha.18 host panel-layout fallback remains intact.
- Existing `tenant_company_id` semantics remain authoritative; `user_id` and customer/company IDs are not promoted into tenant authority.
- The external Titan Command Bus implementation is intentionally **not** fabricated inside CRM. The CRM exposes a port that the platform Command Bus extension must bind.
