<?php

declare(strict_types=1);

$root = dirname(__DIR__);
function advcheck(bool $ok, string $message): void { if (!$ok) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } }
function advthrows(callable $fn, string $message): void { try { $fn(); } catch (Throwable) { return; } advcheck(false, $message); }

foreach ([
    '/System/Support/CanonicalJson.php','/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php',
    '/System/Domain/SemanticChangeKind.php','/System/Domain/SemanticChangeDisposition.php','/System/Domain/ProvisioningReceiptStatus.php',
    '/System/Domain/ProvisioningOperation.php','/System/Domain/ProvisioningReceipt.php','/System/Domain/ProvisioningPlanStatus.php','/System/Domain/ProvisioningPlan.php',
    '/System/Domain/RiskDecision.php','/System/Domain/GovernanceDecision.php','/System/Domain/AssuranceDecision.php','/System/Domain/AutonomyDecision.php',
    '/System/Domain/ProvisioningExecutionContext.php','/System/Domain/VerticalDefinition.php','/System/Domain/ValueObjects/TraceContext.php',
    '/System/Contracts/ProvisioningCommandGatewayContract.php','/System/Contracts/ProvisioningExecutorContract.php','/System/Contracts/RiskGatewayContract.php',
    '/System/Contracts/GovernanceGatewayContract.php','/System/Contracts/AssuranceGatewayContract.php','/System/Contracts/AutonomyGatewayContract.php',
    '/System/Contracts/SignalGatewayContract.php','/System/Contracts/RewindGatewayContract.php','/System/Services/GovernedProvisioningExecutor.php',
    '/System/Host/NexusMenuRegistrar.php',
] as $file) { require_once $root.$file; }

use App\Extensions\TitanNexus\System\Support\StrictBoolean;
use App\Extensions\TitanNexus\System\Support\SecretFieldGuard;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeKind;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeDisposition;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningReceipt;
use App\Extensions\TitanNexus\System\Domain\ProvisioningReceiptStatus;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlan;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\RiskDecision;
use App\Extensions\TitanNexus\System\Domain\GovernanceDecision;
use App\Extensions\TitanNexus\System\Domain\AssuranceDecision;
use App\Extensions\TitanNexus\System\Domain\AutonomyDecision;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Contracts\ProvisioningCommandGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\RiskGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\GovernanceGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\AssuranceGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\AutonomyGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\SignalGatewayContract;
use App\Extensions\TitanNexus\System\Contracts\RewindGatewayContract;
use App\Extensions\TitanNexus\System\Services\GovernedProvisioningExecutor;
use App\Extensions\TitanNexus\System\Host\NexusMenuRegistrar;

// Strict booleans: only explicit bool/0/1 forms are accepted.
foreach (['yes','no','on','off','','00','TRUEE',2,-1,0.0,1.0,null,[]] as $value) {
    advthrows(static fn () => StrictBoolean::parse($value, 'attack'), 'ambiguous boolean must fail closed: '.var_export($value,true));
}
advcheck(StrictBoolean::parse(' FALSE ', 'attack') === false, 'trimmed FALSE remains false');
advcheck(StrictBoolean::parse('1', 'attack') === true, 'string 1 remains true');

// Secrets: snake/kebab/camel/Pascal variants must all be recognized recursively.
foreach (['db_password','db-password','dbPassword','refreshToken','clientSecret','apiKey','privateKey','accessToken','Authorization'] as $key) {
    advcheck(SecretFieldGuard::isSecretLike($key), "secret-like key must be blocked: {$key}");
}
advcheck(SecretFieldGuard::containsSecretLikeKey(['outer'=>['clientSecret'=>'x']]), 'nested camelCase secret must be detected');

// Canonical contract tampering: definition_hash cannot bless changed content.
$definition = VerticalDefinition::fromArray([
    'vertical_id'=>'cleaning','vertical_version'=>'1','sections'=>['crm'=>['enabled'=>true]],
    'provisioning'=>['routes'=>['sections.crm'=>['capability'=>'crm.configuration.apply','depends_on'=>[]]]],
]);
$canonical = $definition->toContractArray();
$tampered = $canonical;
$tampered['defaults']['crm']['enabled'] = false;
advthrows(static fn () => VerticalDefinition::fromArray($tampered), 'tampered canonical VerticalDefinition hash must be rejected');

// Idempotency: canonical operation/idempotency digests cannot be forged.
$op = new ProvisioningOperation(42,'44444444-4444-4444-8444-444444444444',str_repeat('a',64),'sections.crm.enabled',SemanticChangeKind::Modify,SemanticChangeDisposition::Apply,'crm.configuration.apply','sections.crm',false,true,[]);
$raw = $op->toArray();
$raw['idempotency_key'] = str_repeat('f',64);
advthrows(static fn () => ProvisioningOperation::fromArray($raw), 'forged idempotency key must be rejected');

// Receipts: applied requires hard evidence; already_applied requires durable evidence; secrets remain forbidden.
advthrows(static fn () => ProvisioningReceipt::fromArray([
    'operation_id'=>$op->operationId(),'idempotency_key'=>$op->idempotencyKey(),'status'=>'applied',
    'backup_reference'=>'b','backup_verified'=>true,'write_verified'=>true,'audit_reference'=>'a','rollback_reference'=>null,
]), 'applied receipt missing rollback evidence must fail');
advthrows(static fn () => ProvisioningReceipt::fromArray([
    'operation_id'=>$op->operationId(),'idempotency_key'=>$op->idempotencyKey(),'status'=>'already_applied',
]), 'already_applied receipt without durable idempotency evidence must fail');
advthrows(static fn () => new ProvisioningReceipt($op->operationId(),$op->idempotencyKey(),ProvisioningReceiptStatus::Failed,metadata:['outer'=>['refreshToken'=>'secret']]), 'nested receipt secrets must fail');

// Dependencies: unknown/self/cycle routes fail before a provisioning plan can exist.
advthrows(static fn () => VerticalDefinition::fromArray([
    'vertical_id'=>'x','vertical_version'=>'1','sections'=>[],
    'provisioning'=>['routes'=>['sections.a'=>['capability'=>'a.apply','depends_on'=>['sections.missing']]]],
]), 'unknown route dependency must fail');
advthrows(static fn () => VerticalDefinition::fromArray([
    'vertical_id'=>'x','vertical_version'=>'1','sections'=>[],
    'provisioning'=>['routes'=>[
        'sections.a'=>['capability'=>'a.apply','depends_on'=>['sections.b']],
        'sections.b'=>['capability'=>'b.apply','depends_on'=>['sections.a']],
    ]],
]), 'cyclic route dependencies must fail');

// Tenant mismatch must stop before any command mutation.
$trace = TraceContext::fromArray(['tenant_company_id'=>42,'trace_id'=>'11111111-1111-4111-8111-111111111111','correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>'33333333-3333-4333-8333-333333333333']);
$plan = new ProvisioningPlan(42,'44444444-4444-4444-8444-444444444444',str_repeat('a',64),null,[$op]);
$commandCalls = 0;
$gateway = new class($commandCalls) implements ProvisioningCommandGatewayContract {
    public function __construct(private int &$calls) {}
    public function execute(ProvisioningOperation $operation, TraceContext $traceContext): ProvisioningReceipt { $this->calls++; return ProvisioningReceipt::failed($operation,'should not execute'); }
};
$risk = new class implements RiskGatewayContract { public function evaluate(ProvisioningOperation $o,TraceContext $t,ProvisioningExecutionContext $c): RiskDecision{return new RiskDecision(true,'risk:ok','LOW','RED');} };
$gov = new class implements GovernanceGatewayContract { public function authorize(ProvisioningOperation $o,TraceContext $t,ProvisioningExecutionContext $c,RiskDecision $r): GovernanceDecision{return new GovernanceDecision(true,'gov:ok',false);} };
$ass = new class implements AssuranceGatewayContract { public function verify(ProvisioningOperation $o,TraceContext $t,ProvisioningExecutionContext $c,RiskDecision $r,GovernanceDecision $g,?AutonomyDecision $a): AssuranceDecision{return new AssuranceDecision(true,'ass:ok','GREEN');} };
$auto = new class implements AutonomyGatewayContract { public function authorize(ProvisioningOperation $o,TraceContext $t,ProvisioningExecutionContext $c,RiskDecision $r,GovernanceDecision $g): AutonomyDecision{return new AutonomyDecision(true,'auto:ok','Semi-Auto');} };
$signal = new class implements SignalGatewayContract { public function emit(string $event,ProvisioningOperation $o,TraceContext $t,ProvisioningExecutionContext $c,array $e=[]): string{return 'signal:ok';} };
$rewind = new class implements RewindGatewayContract { public function record(string $event,ProvisioningOperation $o,TraceContext $t,ProvisioningExecutionContext $c,array $e=[]): string{return 'rewind:ok';} };
$executor = new GovernedProvisioningExecutor($gateway,$risk,$gov,$ass,$signal,$rewind,$auto);
$wrongTrace = TraceContext::fromArray(['tenant_company_id'=>99,'trace_id'=>'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','correlation_id'=>'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','causation_id'=>'cccccccc-cccc-4ccc-8ccc-cccccccccccc']);
advthrows(static fn () => $executor->execute($plan,$wrongTrace,false,ProvisioningExecutionContext::human(42,'user:1')), 'cross-tenant plan execution must fail');
advcheck($commandCalls===0,'cross-tenant attack must not call Command Bus');

// Approval downgrade attack: a requires_approval operation must not execute if governance tries to downgrade it.
$approvalOp = new ProvisioningOperation(42,'55555555-5555-4555-8555-555555555555',str_repeat('b',64),'sections.crm.mode',SemanticChangeKind::Modify,SemanticChangeDisposition::RequiresApproval,'crm.configuration.apply','sections.crm','old','new',[],'Owner approval required');
$approvalPlan = new ProvisioningPlan(42,'55555555-5555-4555-8555-555555555555',str_repeat('b',64),null,[$approvalOp]);
$approvalCalls = 0;
$approvalGateway = new class($approvalCalls) implements ProvisioningCommandGatewayContract {
    public function __construct(private int &$calls) {}
    public function execute(ProvisioningOperation $operation, TraceContext $traceContext): ProvisioningReceipt { $this->calls++; return ProvisioningReceipt::failed($operation,'mutation reached'); }
};
$executor2 = new GovernedProvisioningExecutor($approvalGateway,$risk,$gov,$ass,$signal,$rewind,$auto);
$result = $executor2->execute($approvalPlan,$trace,false,ProvisioningExecutionContext::human(42,'user:1','approval:bogus'));
advcheck($approvalCalls===0,'requires_approval disposition cannot be downgraded by governance');
advcheck($result->status()->value==='failed','approval downgrade attack must fail closed');

// Autonomous paths require a grant; system factory must support approval evidence without losing autonomy grant.
advthrows(static fn () => ProvisioningExecutionContext::fromArray(['tenant_company_id'=>42,'initiator_type'=>'system','initiator_reference'=>'system:nexus']), 'system context without autonomy grant must fail');
$system = ProvisioningExecutionContext::system(42,'system:nexus','autonomy:grant','approval:owner');
advcheck($system->autonomous() && $system->approvalReference()==='approval:owner' && $system->autonomyGrantReference()==='autonomy:grant','system context carries both autonomy and approval evidence');

// Menu identities must remain unique and provider must isolate navigation errors.
$defs = NexusMenuRegistrar::definitions();
$keys=[];$routes=[];
foreach($defs as $def){ $key=$def['legacy_identity']['key']??null; $route=$def['legacy_fallback_identity']['route']??null; advcheck(is_string($key)&&!isset($keys[$key]),'legacy menu key identities must be unique'); $keys[$key]=true; advcheck(is_string($route)&&!isset($routes[$route]),'legacy menu fallback route identities must be unique'); $routes[$route]=true; }
$provider=(string)file_get_contents($root.'/System/TitanNexusServiceProvider.php');
advcheck(str_contains($provider,'try { $this->registerNavigation(); } catch (Throwable)'), 'provider boot must isolate menu registration failures');

// Concurrency guard must be DB-enforced and repository must compare-and-swap entity_version.
$migration=(string)file_get_contents($root.'/database/migrations/2026_08_21_000004_add_nexus_compilation_concurrency_guards.php');
$repo=(string)file_get_contents($root.'/System/Repositories/EloquentCompilationRepository.php');
advcheck(str_contains($migration,"unique(['tenant_company_id', 'compilation_uuid']"),'tenant+compilation identity must be DB-unique');
advcheck(str_contains($repo,"->where('entity_version', \$expectedVersion)") && str_contains($repo,'Concurrent Nexus compilation update conflict'),'repository must use optimistic compare-and-swap');

fwrite(STDOUT,"PASS: Titan Nexus RC2 deep adversarial safety checks\n");
