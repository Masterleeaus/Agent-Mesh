<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;

final class DomainPersistenceBoundaryTest extends TestCase
{
    public function test_pass2_does_not_activate_external_acquisition_or_mutating_capabilities(): void
    {
        $root = dirname(__DIR__, 2);
        $manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);

        self::assertFalse($manifest['queues']['used']);
        self::assertSame([], $manifest['external_hosts']);
        self::assertSame([], $manifest['schedules']);
        self::assertNotContains('knowledge.resolve', $manifest['capabilities']);
        self::assertNotContains('knowledge.refresh', $manifest['capabilities']);
    }
}
