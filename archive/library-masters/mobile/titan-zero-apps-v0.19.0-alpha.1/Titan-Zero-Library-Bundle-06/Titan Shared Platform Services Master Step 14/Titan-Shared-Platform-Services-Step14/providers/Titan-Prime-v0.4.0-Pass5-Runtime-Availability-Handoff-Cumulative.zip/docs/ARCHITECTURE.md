# Titan Prime Architecture

Titan Prime uses Blueprint v4.2's `strategic-orchestrator` profile. v0.4.0 owns strategic domain primitives, durable Prime mission state, and a public gateway boundary for consulting other Titan engines.

Mission persistence remains behind `PrimeMissionRepositoryContract` with tenant-scoped extension-owned Eloquent models, durable operation receipts and optimistic compare-and-swap state transitions.

## Engine gateway boundary

Prime does not import another Titan extension's implementation classes. Instead it owns typed gateway ports and a single `EngineBridgeContract`. The default `FailClosedEngineBridge` reports every external engine as unavailable. A trusted integration provider may replace that bridge with an adapter to the target engine's public contract/capability registry.

Every gateway request contains:

- canonical engine identity;
- stable capability identifier;
- caller-owned operation ID;
- `tenant_company_id`;
- `trace_id`;
- `correlation_id`;
- `causation_id`;
- `root_causation_id`;
- contract version;
- bounded payload.

Gateway results are one of `succeeded`, `denied`, `escalated`, `unavailable`, or `failed`. Only `succeeded` can permit a later orchestration layer to continue. Bridge exceptions and response-identity mismatches fail closed.

v0.4.0 still does not compose engine decisions or execute downstream mutations. Consequential execution remains a future Command Bus pass.
