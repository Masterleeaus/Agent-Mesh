# Titan Nexus Domain Core Design

## Goal

Turn Titan Nexus from a health-check scaffold into a versioned, tenant-safe domain foundation for future deterministic business compilation without implementing provisioning or cross-engine mutation yet.

## Scope

Pass 1 adds immutable domain objects for business profile input, trace context, compiled configuration snapshots, and the compilation aggregate; tenant-scoped persistence contracts and an Eloquent adapter; a forward-only migration that evolves the scaffold table; provider bindings; truthful capability/version metadata; and real unit/architecture tests.

Pass 1 does **not** implement Vertical Engine resolution, compilation rules, preview/diff execution, Command Bus provisioning, Risk decisions, Signals, Knowledge Authority queries, or UI workflows. Those remain later passes.

## Architecture

The domain layer has no Laravel dependency. It owns immutable values and validation rules. Persistence is hidden behind `CompilationRepositoryContract`, whose read methods require `tenant_company_id` so unscoped lookup is not part of the public API. The Eloquent record is an infrastructure adapter and is not exposed through `NexusManagerContract`.

The existing initial migration remains untouched. A second forward-only migration adds versioning, causation, snapshots, hashes, dry-run state, and compilation identity fields so already-installed scaffold instances can upgrade safely.

## Core Types

- `TraceContext`: `trace_id`, `correlation_id`, `causation_id`, `tenant_company_id`; UUID and tenant validation.
- `BusinessProfile`: canonical input envelope with profile version, vertical identity/version, jurisdiction, timezone, and bounded configuration sections.
- `CompiledTitanConfig`: immutable versioned compilation output snapshot with deterministic hashes and configuration sections.
- `CompilationStatus`: explicit lifecycle enum for domain state.
- `NexusCompilation`: aggregate linking profile input, trace context, compilation identity, status, and optional compiled output.
- `CompilationRepositoryContract`: tenant-scoped persistence API.

## Tenant Safety

Tenant ownership is mandatory in new domain objects and repository operations. Legacy scaffold rows can remain nullable at database level for upgrade compatibility, but new domain construction rejects non-positive tenant identifiers. Repository lookup always filters by both tenant and compilation UUID.

## Traceability

Every new compilation aggregate carries all four canonical identifiers: `trace_id`, `correlation_id`, `causation_id`, and `tenant_company_id`. No hidden chain-of-thought is stored. Snapshot fields are structured inputs, outputs, validation summaries, provisioning plans, and diffs only.

## Testing

Pure domain behavior is tested without Laravel. PHPUnit tests are namespaced under `Tests\\Extensions\\TitanNexus` to avoid collisions with other Titan extensions. A standalone PHP harness verifies the same critical domain rules in environments where the host test runner is unavailable. Architecture tests inspect package source for forbidden direct cross-extension database access patterns.

## Compatibility

PHP 8.2+ and Laravel 10+ remain the compatibility floor. Existing provider key, routes, views, table name, and installer lifecycle are preserved. The package version advances to 0.2.0.
