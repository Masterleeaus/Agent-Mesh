# Schedule menu canonicalization hotfix

The supplied host DB contains both `crm_calendar` and `crm_schedule` under the Crew parent. The legacy Calendar row opens `dashboard.user.crm.calendar.index`, while the canonical Schedule row opens the Field scheduling surface.

Titan Field 1.0.6 makes `crm_schedule` the only visible scheduling/calendar row. The obsolete `crm_calendar` row is rewritten to the current Schedule route and deactivated. In staged mode, the Crew parent also points to the read-only Titan Field month calendar; after authoritative activation it is restored to `dashboard.user.crm.field-services.schedule`.
