<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_events')) {
            return;
        }

        Schema::table('titan_signal_events', function (Blueprint $table): void {
            if (! Schema::hasColumn('titan_signal_events', 'envelope_version')) $table->string('envelope_version', 10)->default('1.0');
            if (! Schema::hasColumn('titan_signal_events', 'root_causation_id')) $table->uuid('root_causation_id')->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'actor_identity_provider')) $table->string('actor_identity_provider', 80)->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'actor_session_id')) $table->string('actor_session_id', 191)->nullable();
            if (! Schema::hasColumn('titan_signal_events', 'checksum_alg')) $table->string('checksum_alg', 20)->default('sha256');
            if (! Schema::hasColumn('titan_signal_events', 'idempotency_expires_at')) $table->timestampTz('idempotency_expires_at')->nullable();
        });

        if (! Schema::hasTable('titan_signal_idempotency_keys')) {
            Schema::create('titan_signal_idempotency_keys', function (Blueprint $table): void {
                $table->id();
                $table->char('deduplication_key', 64)->unique('tsi_dedup_uq');
                $table->uuid('event_id')->index();
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
                $table->string('source', 120);
                $table->string('idempotency_key', 191);
                $table->char('request_fingerprint', 64);
                $table->timestampTz('expires_at')->index();
                $table->timestamps();
            });
        }

        // v0.2.1 expands the canonical checksum envelope. Recalculate only checksum
        // metadata while preserving the historical event content itself.
        DB::table('titan_signal_events')
            ->orderBy('id')
            ->chunkById(200, function ($rows): void {
                foreach ($rows as $row) {
                    $root = $this->resolveRoot($row);
                    $payload = $this->jsonArray($row->payload ?? null);
                    $metadata = $this->jsonArray($row->metadata ?? null);
                    $checksum = $this->checksumForRow($row, $root, $payload, $metadata);
                    $updates = [
                        'envelope_version' => '1.0',
                        'root_causation_id' => $root,
                        'checksum_alg' => 'sha256',
                        'checksum' => $checksum,
                    ];

                    $expiresAt = $this->idempotencyExpiryFor($row);
                    if ($expiresAt !== null) {
                        $updates['idempotency_expires_at'] = $expiresAt;
                        DB::table('titan_signal_idempotency_keys')->updateOrInsert(
                            ['deduplication_key' => $row->deduplication_key],
                            [
                                'event_id' => $row->event_id,
                                'scope' => $row->scope,
                                'tenant_company_id' => $row->tenant_company_id,
                                'source' => $row->source,
                                'idempotency_key' => $row->idempotency_key,
                                'request_fingerprint' => $this->idempotencyFingerprintForRow($row, $payload),
                                'expires_at' => $expiresAt,
                                'created_at' => $row->recorded_at ?? $row->created_at ?? now(),
                                'updated_at' => now(),
                            ],
                        );
                    }

                    DB::table('titan_signal_events')->where('id', $row->id)->update($updates);
                }
            });

        Schema::table('titan_signal_events', function (Blueprint $table): void {
            if (Schema::hasIndex('titan_signal_events', 'tse_dedup_uq')) {
                $table->dropUnique('tse_dedup_uq');
            }
            if (! Schema::hasIndex('titan_signal_events', 'tse_causation_idx')) $table->index(['causation_id'], 'tse_causation_idx');
            if (! Schema::hasIndex('titan_signal_events', 'tse_root_time_idx')) $table->index(['root_causation_id', 'occurred_at'], 'tse_root_time_idx');
            if (! Schema::hasIndex('titan_signal_events', 'tse_trace_time_idx')) $table->index(['trace_id', 'occurred_at'], 'tse_trace_time_idx');
            if (! Schema::hasIndex('titan_signal_events', 'tse_corr_time_idx')) $table->index(['correlation_id', 'occurred_at'], 'tse_corr_time_idx');
            if (! Schema::hasIndex('titan_signal_events', 'tse_actor_session_idx')) $table->index(['tenant_company_id', 'actor_session_id', 'occurred_at'], 'tse_actor_session_idx');
        });
    }

    public function down(): void
    {
        if (Schema::hasTable('titan_signal_idempotency_keys')) {
            Schema::drop('titan_signal_idempotency_keys');
        }
        if (! Schema::hasTable('titan_signal_events')) {
            return;
        }

        Schema::table('titan_signal_events', function (Blueprint $table): void {
            foreach (['tse_causation_idx', 'tse_root_time_idx', 'tse_trace_time_idx', 'tse_corr_time_idx', 'tse_actor_session_idx'] as $index) {
                if (Schema::hasIndex('titan_signal_events', $index)) {
                    $table->dropIndex($index);
                }
            }
        });

        Schema::table('titan_signal_events', function (Blueprint $table): void {
            foreach (['envelope_version', 'root_causation_id', 'actor_identity_provider', 'actor_session_id', 'checksum_alg', 'idempotency_expires_at'] as $column) {
                if (Schema::hasColumn('titan_signal_events', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }

    private function resolveRoot(object $row): string
    {
        $root = (string) $row->event_id;
        $parentId = $row->causation_id ?? null;
        $visited = [$root => true];
        $depth = 0;

        while ($parentId !== null && $parentId !== '' && $depth < 256) {
            $parentId = (string) $parentId;
            if (isset($visited[$parentId])) {
                throw new \RuntimeException("Signal causal cycle detected while upgrading event {$row->event_id}.");
            }
            $visited[$parentId] = true;

            $parent = DB::table('titan_signal_events')
                ->select(['event_id', 'causation_id', 'tenant_company_id', 'scope'])
                ->where('event_id', $parentId)
                ->first();
            if ($parent === null) {
                // Preserve the missing parent identity so Correlation can flag the gap later.
                return $parentId;
            }
            if ((string) $parent->scope !== (string) $row->scope
                || (int) ($parent->tenant_company_id ?? 0) !== (int) ($row->tenant_company_id ?? 0)) {
                throw new \RuntimeException("Cross-tenant/scope causation detected while upgrading event {$row->event_id}.");
            }

            $root = (string) $parent->event_id;
            $parentId = $parent->causation_id ?? null;
            ++$depth;
        }

        if ($depth >= 256 && $parentId !== null) {
            throw new \RuntimeException("Signal causal chain exceeded 256 levels while upgrading event {$row->event_id}.");
        }

        return $root;
    }

    /** @return array<string,mixed> */
    private function jsonArray(mixed $value): array
    {
        if (is_array($value)) {
            return $value;
        }
        if ($value === null || $value === '') {
            return [];
        }
        if (is_string($value)) {
            $decoded = json_decode($value, true);
            return is_array($decoded) ? $decoded : [];
        }

        return [];
    }


    /** @param array<string,mixed> $payload @param array<string,mixed> $metadata */
    private function checksumForRow(object $row, string $root, array $payload, array $metadata): string
    {
        $scope = (string) ($row->scope ?? (($row->tenant_company_id ?? null) === null ? 'system' : 'tenant'));
        $tenant = $row->tenant_company_id === null ? null : (int) $row->tenant_company_id;
        $actor = null;
        if (($row->actor_id ?? null) !== null || ($row->actor_type ?? null) !== null) {
            $actor = [
                'id' => (string) ($row->actor_id ?? ''),
                'type' => strtolower((string) ($row->actor_type ?? '')),
                'tenant_company_id' => $scope === 'tenant' ? $tenant : null,
                'identity_provider' => $row->actor_identity_provider ?? null,
                'session_id' => $row->actor_session_id ?? null,
            ];
        }

        $data = [
            'event_id' => (string) $row->event_id,
            'event_type' => (string) ($row->event_type ?? $row->type ?? 'legacy.record'),
            'occurred_at' => $this->dateAtom($row->occurred_at ?? $row->created_at ?? 'now'),
            'recorded_at' => $this->dateAtom($row->recorded_at ?? $row->created_at ?? 'now'),
            'envelope_version' => '1.0',
            'scope' => $scope,
            'tenant_company_id' => $tenant,
            'actor' => $actor,
            'trace_id' => (string) $row->trace_id,
            'correlation_id' => (string) $row->correlation_id,
            'causation_id' => ($row->causation_id ?? null) === null ? null : (string) $row->causation_id,
            'root_causation_id' => $root,
            'source' => (string) ($row->source ?? 'legacy:titan-signal-engine'),
            'source_component' => ($row->source_component ?? null) === null ? null : (string) $row->source_component,
            'schema_version' => max(1, (int) ($row->schema_version ?? 1)),
            'payload' => $payload,
            'metadata' => $metadata,
            'severity' => strtolower((string) ($row->severity ?? 'info')),
            'category' => ($row->category ?? null) === null ? null : (string) $row->category,
            'idempotency_key' => ($row->idempotency_key ?? null) === null ? null : (string) $row->idempotency_key,
            'vertical_key' => ($row->vertical_key ?? null) === null ? null : (string) $row->vertical_key,
            'checksum_alg' => 'sha256',
        ];

        return $this->canonicalHash($data);
    }

    /** @param array<string,mixed> $payload */
    private function idempotencyFingerprintForRow(object $row, array $payload): string
    {
        return $this->canonicalHash([
            'event_type' => (string) ($row->event_type ?? $row->type ?? 'legacy.record'),
            'scope' => (string) ($row->scope ?? (($row->tenant_company_id ?? null) === null ? 'system' : 'tenant')),
            'tenant_company_id' => $row->tenant_company_id === null ? null : (int) $row->tenant_company_id,
            'source' => (string) ($row->source ?? 'legacy:titan-signal-engine'),
            'emitter_id' => null,
            'schema_version' => max(1, (int) ($row->schema_version ?? 1)),
            'payload' => $payload,
            'vertical_key' => ($row->vertical_key ?? null) === null ? null : (string) $row->vertical_key,
        ]);
    }

    /** @param array<string,mixed> $data */
    private function canonicalHash(array $data): string
    {
        $this->ksortRecursive($data);
        return hash('sha256', json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION));
    }

    /** @param array<mixed> $value */
    private function ksortRecursive(array &$value): void
    {
        foreach ($value as &$item) {
            if (is_array($item)) $this->ksortRecursive($item);
        }
        unset($item);
        ksort($value);
    }

    private function dateAtom(mixed $value): string
    {
        return (new DateTimeImmutable((string) $value))->setTimezone(new DateTimeZone('UTC'))->format(DATE_ATOM);
    }

    private function idempotencyExpiryFor(object $row): ?string
    {
        if (($row->deduplication_key ?? null) === null || ($row->idempotency_key ?? null) === null) {
            return null;
        }

        $base = new DateTimeImmutable((string) ($row->recorded_at ?? $row->created_at ?? 'now'));
        $expires = $base->modify('+24 hours');
        if ($expires <= new DateTimeImmutable('now')) {
            return null;
        }

        return $expires->format('Y-m-d H:i:sP');
    }
};
