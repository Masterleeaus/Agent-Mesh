# Titan Signal Engine — Production Host Certification

The cumulative release candidate contains all implementation and standalone verification work, but final production certification must run inside the real Titan Laravel/MySQL host.

## Required staging command

```bash
php artisan titan:signal:certify --strict --probe-writes --output=titan-signal-engine/certification/host.json
```

A production candidate is acceptable only when the generated report has:

```json
{"overall":"PASS"}
```

`WARN`, `FAIL`, or `SKIP` must be reviewed before production rollout. `--probe-writes` is required for final certification so archive storage is actually exercised.

## Required host PHPUnit run

Run the host's normal test command against the extension test namespace, including all `tests/Feature/*RuntimeIntegrationTest.php` files. The final host gate must cover:

- fresh install and full migration chain;
- upgrade from retained historical package baselines;
- immutable event update/delete rejection;
- tenant and emitter spoof rejection;
- registry ownership and broken-handler quarantine;
- two-worker delivery lease races;
- crash/reclaim and DLQ redrive;
- hot/cold archive reads;
- transactional prune preview/claim/finalize;
- automatic trace evaluation and late-event repair;
- Pulse scoped freshness and per-command latency;
- immutable anomaly lifecycle decisions;
- console route/permission boundaries.

## Queue and scheduler validation

Production certification requires a durable asynchronous queue driver. `sync` is not accepted under `--strict`.

Confirm a worker is consuming the configured queue:

```bash
php artisan queue:work --queue=titan-signal-engine --tries=1
```

Confirm the Laravel scheduler is running and that these Signal commands are registered:

- `titan:signal-deliveries:recover`
- `titan:signal-pulse:project`
- `titan:signal-health:refresh`
- `titan:signal-traces:evaluate`
- `titan:signal-anomalies:scan`
- `titan:signal-housekeeping`

## Installer 1.7.8

The root `extension.json` uses the Installer 1.7.8 `titan-extension-v1` package contract. Validate install, disable, re-enable and uninstall-with-data-retention in staging before production promotion.

## Release status rule

The package may be described as an **RC** after local/Blueprint verification. It must not be described as **production-host certified** until the real host command and integration suite pass on the supported Titan environment.

## Navigation certification

The host run must report `runtime.navigation: PASS`. Signal verifies the `titan_signal_pulse` user row and `titan_signal_engine_admin` Super Admin row in MagicAI's `menus` table, including routes, active state, plan-gating state, parent placement, explicit admin discriminator when available and Website1408 Super Admin order band.
