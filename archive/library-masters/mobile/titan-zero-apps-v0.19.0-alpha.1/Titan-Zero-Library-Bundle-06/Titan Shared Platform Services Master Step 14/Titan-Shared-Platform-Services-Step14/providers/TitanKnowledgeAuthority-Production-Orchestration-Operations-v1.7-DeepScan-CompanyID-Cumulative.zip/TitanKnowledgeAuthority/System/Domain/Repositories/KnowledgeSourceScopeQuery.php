<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeAccessContext;
use Illuminate\Database\Eloquent\Builder;

final class KnowledgeSourceScopeQuery
{
    /**
     * Apply the only supported read visibility rule to a KnowledgeSource query.
     * Legacy/malformed scopes are excluded by construction.
     *
     * @param Builder<\App\Extensions\TitanKnowledgeAuthority\System\Domain\Models\KnowledgeSource> $query
     * @return Builder<\App\Extensions\TitanKnowledgeAuthority\System\Domain\Models\KnowledgeSource>
     */
    public function apply(Builder $query, KnowledgeAccessContext $context): Builder
    {
        $jurisdictions = $context->jurisdictions();

        return $query->where(function (Builder $visibility) use ($context, $jurisdictions): void {
            $visibility->where(function (Builder $platform): void {
                $platform->where('scope_type', 'platform')
                    ->whereNull('tenant_company_id')
                    ->whereNull('jurisdiction_id');
            });

            if ($context->tenantCompanyId !== null) {
                $visibility->orWhere(function (Builder $tenant) use ($context): void {
                    $tenant->where('scope_type', 'tenant')
                        ->where('tenant_company_id', $context->tenantCompanyId);
                });
            }

            if ($jurisdictions !== []) {
                $visibility->orWhere(function (Builder $jurisdiction) use ($jurisdictions): void {
                    $jurisdiction->where('scope_type', 'jurisdiction')
                        ->whereNull('tenant_company_id')
                        ->whereNotNull('jurisdiction_id')
                        ->whereHas('jurisdiction', static function (Builder $jurisdictionQuery) use ($jurisdictions): void {
                            $jurisdictionQuery->whereIn('code', $jurisdictions);
                        });
                });
            }
        });
    }
}
