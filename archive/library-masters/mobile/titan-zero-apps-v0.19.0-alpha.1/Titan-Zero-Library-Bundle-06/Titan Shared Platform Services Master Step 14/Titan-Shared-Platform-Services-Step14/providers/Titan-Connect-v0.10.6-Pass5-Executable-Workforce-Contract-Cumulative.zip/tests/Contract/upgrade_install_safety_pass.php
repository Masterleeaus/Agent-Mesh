<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$checks = 0;
$failures = [];
$check = static function (bool $condition, string $label) use (&$checks, &$failures): void {
    $checks++;
    if (! $condition) {
        $failures[] = $label;
    }
};

$migration = file_get_contents($root.'/database/migrations/2026_08_09_000007_sync_magicai_menu_rows.php');
$sync = file_get_contents($root.'/System/Navigation/MagicAiMenuSynchronizer.php');
$provider = file_get_contents($root.'/System/TitanConnectServiceProvider.php');

$check(is_string($migration), 'upgrade migration readable');
$check(! str_contains($migration, 'App\\Extensions\\TitanConnect\\'), 'upgrade migration does not import Titan Connect runtime classes');
$check(! str_contains($migration, 'MagicAiMenuSynchronizer'), 'upgrade migration does not resolve synchronizer through possibly stale provider state');
$check(! str_contains($migration, 'TitanConnectNavigation'), 'upgrade migration does not call possibly stale navigation API');
$check(str_contains($migration, "Schema::hasTable('menus')"), 'upgrade migration directly guards the host menus table');
$check(str_contains($migration, "app('db')->table('menus')"), 'upgrade migration directly materializes host menu rows');
$check(str_contains($migration, "'ext_titan_connect_inbox'"), 'upgrade migration contains Inbox root definition');
$check(str_contains($migration, "'ext_titan_connect_channels'"), 'upgrade migration contains Channels root definition');
$check(str_contains($migration, "'settings'"), 'upgrade migration uses existing Settings admin parent');
$check(str_contains($migration, 'regenerate'), 'upgrade migration invalidates MagicAI menu cache when host service exists');

// Runtime synchronizer may remain for post-install host sync, but it must not require a method
// added after v0.10.2 on the already-resolved TitanConnectNavigation singleton.
$check(! str_contains($sync, '$this->navigation->liveHostAdmin()'), 'runtime synchronizer tolerates navigation instances loaded from the previous release');
$check(str_contains($provider, 'HostNavigationRegistrar'), 'provider still supports normal post-upgrade contribution registration');

if ($failures !== []) {
    fwrite(STDERR, "Titan Connect upgrade-install safety: FAILED\n");
    foreach ($failures as $failure) {
        fwrite(STDERR, " - {$failure}\n");
    }
    fwrite(STDERR, sprintf("%d/%d checks passed\n", $checks - count($failures), $checks));
    exit(1);
}

fwrite(STDOUT, sprintf("Titan Connect upgrade-install safety: %d/%d passed\n", $checks, $checks));
