# Chatbot 6.5 Source Certification

## Status
**IMPLEMENTED source-contract certification; live host execution UNVERIFIED.**

The CRM test fixture pins the exact `Titan-Chatbot-v6.5.0-production-ready.zip` source using SHA-256 for `extension.json`, OpenAI/Anthropic/Gemini generators, and Chatbot/ChatbotCustomer/ChatbotConversation models.

CRM's generator decorators match those parent classes, and the compatibility gate accepts 6.4.x/6.5.x while rejecting major 7 until tested. Public CRM tool execution re-resolves the authoritative Chatbot record, maps its owner through trusted company membership, verifies customer/session identity, binds `tenant_company_id`, and then runs the CRM tool policy. A browser-supplied company is not tenant authority.

The retained native generator-decoration path is backwards compatibility. The strategic path remains Chatbot → TitanAI → governed CRM tools.
