# Titan Rewind Performance and SLO Contract

## Release budgets

Titan Rewind v1.0.6 keeps at most 5,000 trace events in any in-memory reconstruction window and streams larger traces. The package-level memory budget is 256 MiB. The synthetic reconstruction/streaming certification budget is 5,000 ms p95 for a 5,000-event bounded analysis window; HTTP p95 target is 500 ms for bounded catalogue/read endpoints and command admission p95 target is 1,000 ms before asynchronous work is queued.

Evidence export is streamed and does not decode the complete persisted evidence payload before sending it. Timeline APIs are cursor bounded; retention is batch bounded; integrity verification iterates the event chain.

## Certification workload

`tests/standalone/verify_large_trace_performance.php` generates 100,000 events lazily, consumes them through a 5,000-event `RewindStreamWindow`, and verifies that all 100,000 events are observed while only 5,000 are retained. The release run on 17 August 2026 retained 5,000/100,000 events with approximately 4 MiB additional peak allocated memory and completed the synthetic stream in approximately 12 ms in the packaging environment.

These measurements certify the extension's bounded algorithms, not the latency of a particular production database, PHP-FPM pool, queue backend, storage device, or MagicAI deployment. `php artisan titan-rewind:certify --json` must be run in the target host and host-level load testing remains a deployment gate.

## Failure threshold

A release fails package certification if the synthetic gate exceeds 256 MiB additional peak memory, retains more than 5,000 events, takes more than 5,000 ms for the certification stream, reintroduces a Blueprint architecture warning, or exposes a non-streamed evidence download path.
