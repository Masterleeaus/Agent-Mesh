<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Webhooks;

use App\Extensions\TitanConnect\System\Attachments\InboundAttachmentIngestService;
use App\Extensions\TitanConnect\System\Contracts\CredentialVault;
use App\Extensions\TitanConnect\System\Contracts\MessagingProvider;
use App\Extensions\TitanConnect\System\DTO\NormalizedDeliveryReceipt;
use App\Extensions\TitanConnect\System\Delivery\OutboundDeliveryService;
use App\Extensions\TitanConnect\System\Events\InboundMessageReceived;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ExternalMessage;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use App\Extensions\TitanConnect\System\Models\WebhookEvent;
use App\Extensions\TitanConnect\System\Providers\ProviderRegistry;
use App\Extensions\TitanConnect\System\Services\ExternalContactService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

final class InboundWebhookService
{
    public function __construct(
        private readonly ProviderRegistry $providers,
        private readonly CredentialVault $vault,
        private readonly OutboundDeliveryService $delivery,
        private readonly InboundAttachmentIngestService $attachments,
        private readonly ExternalContactService $contacts,
    ) {
    }

    public function assertVerified(ChannelConnection $connection, array $headers, string $body): void
    {
        if ($connection->status !== 'active') {
            throw new AccessDeniedHttpException('Messaging channel is inactive.');
        }

        $provider = $this->providers->get((string) $connection->provider);
        if (! $provider->supportsInbound()) {
            throw new BadRequestHttpException('Provider does not support inbound webhooks.');
        }
        $credentials = $this->vault->credentials((int) $connection->company_id, $connection);
        if (! $provider->verifyWebhook($headers, $body, $credentials)) {
            throw new AccessDeniedHttpException('Invalid webhook signature.');
        }
    }

    public function handle(ChannelConnection $connection, array $headers, string $body): array
    {
        $this->assertVerified($connection, $headers, $body);
        $provider = $this->providers->get((string) $connection->provider);
        $credentials = $this->vault->credentials((int) $connection->company_id, $connection);
        $payload = $this->decodePayload($body);
        $events = $provider->splitWebhookPayload($payload);
        if ($events === []) {
            return ['status' => 'ignored', 'event_count' => 0];
        }

        $results = [];
        foreach ($provider->splitWebhookPayload($payload) as $eventPayload) {
            if (! is_array($eventPayload) || $eventPayload === []) {
                continue;
            }
            $results[] = $this->processEvent($connection, $provider, $eventPayload, $headers, $credentials);
        }

        if ($results === []) {
            return ['status' => 'ignored', 'event_count' => 0];
        }
        if (count($results) === 1) {
            return $results[0];
        }

        return [
            'status' => 'processed',
            'kind' => 'batch',
            'event_count' => count($results),
            'events' => $results,
        ];
    }

    private function processEvent(
        ChannelConnection $connection,
        MessagingProvider $provider,
        array $payload,
        array $headers,
        array $credentials,
    ): array {
        $encoded = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $payloadHash = hash('sha256', is_string($encoded) ? $encoded : serialize($payload));
        $isReceipt = $this->looksLikeReceipt($payload);
        $normalized = null;

        if ($isReceipt) {
            $receipt = $provider->normalizeDeliveryReceipt($payload);
            $providerEventId = $this->receiptEventId($receipt, $payloadHash);
        } else {
            $normalized = $provider->normalizeInbound($payload, $headers);
            $providerEventId = trim($normalized->providerEventId) !== ''
                ? trim($normalized->providerEventId)
                : $payloadHash;
        }

        $webhook = WebhookEvent::query()->firstOrCreate(
            [
                'company_id' => $connection->company_id,
                'channel_connection_id' => $connection->id,
                'provider' => $connection->provider,
                'provider_event_id' => $providerEventId,
            ],
            [
                'event_type' => $isReceipt ? 'delivery.receipt' : 'message.received',
                'payload_hash' => $payloadHash,
                'status' => 'received',
            ],
        );

        $retryingFailedEvent = false;
        if (! $webhook->wasRecentlyCreated) {
            if ($webhook->status === 'processed') {
                return ['status' => 'duplicate', 'provider_event_id' => $providerEventId];
            }
            if ($webhook->status !== 'failed') {
                return ['status' => 'duplicate', 'provider_event_id' => $providerEventId, 'processing' => true];
            }
            $retryingFailedEvent = true;
            $webhook->forceFill(['status' => 'received', 'failure_reason' => null, 'processed_at' => null])->save();
        }

        try {
            if ($isReceipt) {
                $delivery = $this->delivery->applyReceipt($connection, $receipt);
                $webhook->forceFill(['status' => 'processed', 'processed_at' => now()])->save();
                return [
                    'status' => 'processed',
                    'kind' => 'delivery',
                    'provider_event_id' => $providerEventId,
                    'delivery_id' => $delivery?->id,
                ];
            }

            if ($normalized === null || trim($normalized->providerThreadId) === '') {
                throw new BadRequestHttpException('Inbound message does not contain a resolvable thread identifier.');
            }

            $contact = $this->contacts->resolve((int) $connection->company_id, (string) $connection->provider, $normalized->senderRef, [
                'contact' => is_array($normalized->metadata['contact'] ?? null) ? $normalized->metadata['contact'] : [],
            ]);

            [$thread, $message] = DB::transaction(function () use ($connection, $normalized, $contact): array {
                $thread = ExternalThread::query()->firstOrCreate(
                    [
                        'channel_connection_id' => $connection->id,
                        'provider_thread_id' => $normalized->providerThreadId,
                    ],
                    [
                        'uuid' => (string) Str::uuid(),
                        'company_id' => $connection->company_id,
                        'provider' => $connection->provider,
                        'external_contact_ref' => $normalized->senderRef,
                        'external_contact_id' => $contact?->id,
                        'display_name' => $contact?->display_name,
                        'status' => 'open',
                        'metadata' => [],
                        'last_message_at' => now(),
                    ],
                );
                if ((int) $thread->company_id !== (int) $connection->company_id) {
                    throw new AccessDeniedHttpException('Inbound thread company mismatch.');
                }

                $identity = $normalized->providerMessageId !== null && $normalized->providerMessageId !== ''
                    ? ['company_id' => $connection->company_id, 'provider' => $connection->provider, 'provider_message_id' => $normalized->providerMessageId]
                    : ['uuid' => (string) Str::uuid()];

                $message = ExternalMessage::query()->firstOrCreate($identity, [
                    'uuid' => (string) Str::uuid(),
                    'company_id' => $connection->company_id,
                    'external_thread_id' => $thread->id,
                    'provider' => $connection->provider,
                    'direction' => 'inbound',
                    'sender_ref' => $normalized->senderRef,
                    'recipient_ref' => $normalized->recipientRef,
                    'body' => $normalized->body,
                    'message_type' => $normalized->messageType,
                    'status' => 'received',
                    'metadata' => [
                        'attachments' => $normalized->attachments,
                        'provider_event_id' => $normalized->providerEventId,
                    ],
                    'provider_created_at' => $this->providerTimestamp($normalized->providerCreatedAt),
                ]);

                $thread->forceFill([
                    'external_contact_ref' => $thread->external_contact_ref ?: $normalized->senderRef,
                    'external_contact_id' => $thread->external_contact_id ?: $contact?->id,
                    'display_name' => $thread->display_name ?: $contact?->display_name,
                    'last_message_at' => now(),
                ])->save();

                return [$thread, $message];
            });

            $ingested = $this->attachments->ingestForExternalMessage($connection, $message, $normalized->attachments);
            if ($ingested !== []) {
                $metadata = is_array($message->metadata) ? $message->metadata : [];
                $metadata['attachment_uuids'] = array_values(array_map(static fn ($attachment): string => (string) $attachment->uuid, $ingested));
                $message->forceFill(['metadata' => $metadata])->save();
            }

            $connection->forceFill(['last_inbound_at' => now()])->save();
            $webhook->forceFill(['status' => 'processed', 'processed_at' => now()])->save();
            if ($message->wasRecentlyCreated || $retryingFailedEvent) {
                event(new InboundMessageReceived($thread, $message->fresh()));
            }

            return [
                'status' => 'processed',
                'kind' => 'message',
                'provider_event_id' => $providerEventId,
                'thread_uuid' => $thread->uuid,
                'message_uuid' => $message->uuid,
                'attachment_count' => count($ingested),
            ];
        } catch (\Throwable $e) {
            $webhook->forceFill(['status' => 'failed', 'failure_reason' => mb_substr($e->getMessage(), 0, 4000), 'processed_at' => now()])->save();
            throw $e;
        }
    }

    private function receiptEventId(NormalizedDeliveryReceipt $receipt, string $payloadHash): string
    {
        $providerMessageId = trim((string) ($receipt->providerMessageId ?? ''));
        if ($providerMessageId === '') {
            return 'delivery:'.$payloadHash;
        }

        $status = preg_replace('/[^a-z0-9_.-]+/i', '-', strtolower(trim($receipt->status))) ?: 'unknown';
        return 'delivery:'.$providerMessageId.':'.$status.':'.substr($payloadHash, 0, 16);
    }

    private function decodePayload(string $body): array
    {
        $decoded = json_decode($body, true);
        if (is_array($decoded)) {
            return $decoded;
        }
        parse_str($body, $form);
        if (is_array($form) && $form !== []) {
            return $form;
        }
        throw new BadRequestHttpException('Webhook payload is not valid JSON or form data.');
    }

    private function providerTimestamp(?string $value): mixed
    {
        if ($value === null || trim($value) === '') {
            return null;
        }
        try {
            if (ctype_digit(trim($value))) {
                return \Carbon\Carbon::createFromTimestamp((int) trim($value));
            }
            return \Carbon\Carbon::parse($value);
        } catch (\Throwable) {
            return null;
        }
    }

    private function looksLikeReceipt(array $payload): bool
    {
        return isset($payload['status'])
            || isset($payload['MessageStatus'])
            || isset($payload['SmsStatus'])
            || isset($payload['delivery'])
            || isset($payload['read'])
            || isset($payload['entry'][0]['messaging'][0]['delivery'])
            || isset($payload['entry'][0]['messaging'][0]['read'])
            || isset($payload['entry'][0]['changes'][0]['value']['statuses'][0]);
    }
}
