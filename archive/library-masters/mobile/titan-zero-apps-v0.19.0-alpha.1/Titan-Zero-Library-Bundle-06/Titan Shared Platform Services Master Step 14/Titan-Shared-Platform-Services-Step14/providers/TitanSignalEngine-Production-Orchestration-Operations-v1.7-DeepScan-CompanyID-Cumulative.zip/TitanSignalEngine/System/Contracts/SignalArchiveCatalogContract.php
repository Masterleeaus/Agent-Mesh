<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalArchiveEntry;

interface SignalArchiveCatalogContract
{
    /** @param list<SignalArchiveEntry> $entries */
    public function record(array $entries): void;

    public function find(string $eventId, ?int $tenantCompanyId, string $scope): ?SignalArchiveEntry;

    /** @return list<SignalArchiveEntry> */
    public function byTrace(string $traceId, ?int $tenantCompanyId, string $scope, int $limit): array;

    /** @return list<SignalArchiveEntry> */
    public function byCorrelation(string $correlationId, ?int $tenantCompanyId, string $scope, int $limit): array;

    /** @return list<SignalArchiveEntry> */
    public function byCausation(string $causationId, ?int $tenantCompanyId, string $scope, int $limit): array;

    public function countByTrace(string $traceId, ?int $tenantCompanyId, string $scope): int;

    public function countByCorrelation(string $correlationId, ?int $tenantCompanyId, string $scope): int;

    /** @return list<SignalArchiveEntry> */
    public function byRootCausation(string $rootCausationId, ?int $tenantCompanyId, string $scope, int $limit): array;

    /** @return array<string,mixed>|null */
    public function batchMetadata(string $batchId, ?int $tenantCompanyId, string $scope): ?array;
}
