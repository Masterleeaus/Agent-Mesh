<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Attachments\AttachmentUploadService;
use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Models\MessageAttachment;
use App\Extensions\TitanConnect\System\Services\MessagingAuditService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;

final class AttachmentController extends Controller
{
    public function __construct(private readonly CompanyContext $context)
    {
    }

    public function store(Request $request, AttachmentUploadService $uploads, MessagingAuditService $audit): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $request->validate(['file' => ['required', 'file']]);
        $attachment = $uploads->stage($companyId, $request->file('file'));

        $audit->record($companyId, $actorId, 'attachment.staged', 'attachment', (string) $attachment->uuid, null, [
            'mime_type' => $attachment->mime_type,
            'size_bytes' => (int) $attachment->size_bytes,
            'scan_status' => $attachment->scan_status,
        ]);

        return response()->json([
            'uuid' => $attachment->uuid,
            'original_name' => $attachment->original_name,
            'mime_type' => $attachment->mime_type,
            'size_bytes' => (int) $attachment->size_bytes,
            'sha256' => $attachment->sha256,
            'scan_status' => $attachment->scan_status,
            'expires_at' => $attachment->expires_at,
        ], 201);
    }

    public function providerDownload(int $companyId, MessageAttachment $attachment): StreamedResponse
    {
        abort_if((int) $attachment->company_id !== $companyId, 404);
        abort_unless($attachment->scan_status === 'clean', 404);
        abort_if($attachment->expires_at && $attachment->expires_at->isPast(), 410);
        $disk = Storage::disk((string) $attachment->storage_disk);
        abort_unless($disk->exists((string) $attachment->storage_path), 404);

        return $disk->download(
            (string) $attachment->storage_path,
            $attachment->original_name ?: basename((string) $attachment->storage_path),
            [
                'Content-Type' => (string) $attachment->mime_type,
                'Cache-Control' => 'private, max-age=300',
                'X-Content-Type-Options' => 'nosniff',
            ],
        );
    }
}
