# Workforce Integration Report — Titan-AI-Core

## Result

This pass makes **Titan-AI-Core** a subordinate runtime/provider to Titan AI Workforce. Workforce is the sole active owner of employee identity, organisational roles, hierarchy, teams, responsibilities, assignments, work items and organisational orchestration. The extension publishes runtime/domain execution surfaces only.

## Canonical tenancy

New Workforce-facing contracts use `company_id`. Existing tenant_company_id persistence is a documented storage compatibility path only; new Workforce integration uses company_id and must not infer authority from installation.

## Published surfaces

- Capabilities: ai.plan.create, ai.plan.validate, ai.plan.simulate, ai.model.route, ai.provider.route, ai.command.prepare
- Tools: ai.plan.validate, ai.plan.simulate, ai.model.profile.read, ai.runtime.status
- Commands: ai.command.dispatch-via-command-bus
- Reads: ai.plan.read, ai.model.profile.read, ai.runtime.status
- Signals: ai.plan.created, ai.plan.validated, ai.model.route.selected, ai.runtime.degraded
- Work types: ai.plan, ai.model-route, ai.execution-preflight

## Safety invariants

Installation never grants authority. Availability, authorization, governance, risk and autonomy remain separate decisions. Missing provider/configuration fails closed. Side effects must use the Command Bus or the platform's canonical governed execution boundary. Reads are non-mutating. Provider disable/removal/upgrade does not mutate Workforce employee identity or grant fallback authority.

## Availability states

`available`, `degraded`, `unavailable`, `missing_provider`, `blocked`, `policy_disabled`.

## Verification

See `tests/workforce_integration_contract_runner.php` and the batch report for fresh extracted-package pass counts.
