# Capabilities

`command.dispatch` is the native execution capability. `command.receipt.read` and `command.health` are read-only capabilities. Domain capabilities are registered at runtime through CommandAdapterRegistryContract and remain owned by their originating extensions.
