<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindIntegrityCheck extends Model
{
    protected $table = 'titan_rewind_integrity_checks';
    protected $fillable = [
        'check_uuid','tenant_company_id','trace_id','check_type','status','checked_by_id','events_checked','failures_count',
        'unsealed_count','result','started_at','finished_at',
    ];
    protected $casts = [
        'tenant_company_id'=>'integer','checked_by_id'=>'integer','events_checked'=>'integer','failures_count'=>'integer','unsealed_count'=>'integer',
        'result'=>'array','started_at'=>'datetime','finished_at'=>'datetime',
    ];
}
