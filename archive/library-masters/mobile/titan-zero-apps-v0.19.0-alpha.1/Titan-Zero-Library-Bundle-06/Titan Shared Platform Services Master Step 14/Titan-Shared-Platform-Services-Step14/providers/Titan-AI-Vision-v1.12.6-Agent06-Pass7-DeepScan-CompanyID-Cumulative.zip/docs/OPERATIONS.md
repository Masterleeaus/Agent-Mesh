# Operations

Monitor provider availability, evidence persistence, review backlog, workflow proposal backlog and provider error rate. The extension degrades safely when an external vision provider is unavailable.
