<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Contracts;

interface PrimeManagerContract
{
    /** @return array<string,mixed> */
    public function health(?int $tenantCompanyId = null, ?string $sourceComponent = null): array;
}
