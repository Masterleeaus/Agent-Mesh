# Joint Pass 13 — Titan Field Capacity Pressure Evidence

Titan Maps Intelligence exposes read-only, non-authoritative **capacity pressure** evidence to Titan Field through `FieldSpatialPeerGateway::capacityPressureEvidence()`.

Maps receives bounded demand points from Field and may contribute:

- nearest on-duty worker travel matrix distance/time;
- provider/cache **freshness** (`fresh`, `stale`, estimate, or none);
- existing **territory** evaluation coverage when matching evidence already exists;
- demand points for which no fresh nearby worker evidence is available.

The returned `capacity_adjustment_seconds` is the sum of nearest-worker one-way travel proxies for evaluated demand points. It is advisory spatial pressure only, not a route plan, staffing commitment, assignment, schedule or promise of arrival.

Maps does not query Titan Field operational tables, does not calculate Field capacity, and performs no Field write. Titan Field remains the operational authority and decides how explicit spatial evidence affects a read-only forecast.
