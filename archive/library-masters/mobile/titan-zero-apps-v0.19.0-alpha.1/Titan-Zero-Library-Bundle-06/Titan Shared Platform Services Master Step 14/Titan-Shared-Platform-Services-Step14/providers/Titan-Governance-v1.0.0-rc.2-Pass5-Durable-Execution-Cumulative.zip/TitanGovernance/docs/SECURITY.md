# Security

## Action boundary

Governance write actions are authenticated, permission checked, CSRF protected and rate limited. The route or menu location is never treated as authorization.

Trusted fields are reconstructed server-side. `GovernanceActionRequest` rejects client-supplied tenant, actor, roles, permissions, trace, correlation, causation, root-causation and Governance-decision fields.

## Tenant isolation

Every decision, escalation lookup and transition is scoped by `tenant_company_id`. Tenant resolution returns an integer and follows the host-compatible order: native company ID, collision-safe team scope, then collision-safe personal scope.

## Least privilege

- Queue visibility: `titan-governance.escalations.view`.
- General governed action: `titan-governance.escalations.act`.
- Exception grant: both general action permission and `titan-governance.exceptions.grant`.

## Mutation safety

Governance never falls back to direct cross-domain writes when Titan Command Bus is unavailable. The local escalation target can mutate only Governance-owned escalation state and is intended for Command Bus registration, not direct controller invocation.

`APPLIED` is not trusted unless the Command Bus supplies a matching Governance decision reference, durable command receipt, authoritative domain receipt, adapter identity and independent `write_verified=true` proof.

## Idempotency and concurrency

Actions use tenant-scoped operation IDs and semantic payload hashes. Fresh transport trace IDs do not change semantic identity. Conflicting operation reuse is rejected. Escalation transitions require the expected entity version.

## Data minimization

Reason codes and evidence references are bounded and normalized. Arbitrary hidden reasoning, provider secrets and unrestricted source payloads are not stored in the action ledger.
