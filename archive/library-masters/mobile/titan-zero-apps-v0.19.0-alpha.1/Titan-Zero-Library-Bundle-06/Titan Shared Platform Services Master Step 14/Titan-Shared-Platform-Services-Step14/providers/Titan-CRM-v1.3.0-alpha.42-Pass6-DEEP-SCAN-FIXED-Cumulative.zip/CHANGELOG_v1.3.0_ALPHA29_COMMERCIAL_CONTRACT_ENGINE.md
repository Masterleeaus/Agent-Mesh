# Titan CRM Core v1.3.0-alpha.29 — Commercial Contract Engine

## Added

- Immutable `crm.commercial-contract.v1` issued snapshots for proposals and estimates.
- Deterministic issued snapshot SHA-256 separate from mutable operational state hashes.
- Quote/estimate revision roots, revision numbers, predecessor/successor references and supersession lifecycle.
- Governed quote withdrawal, revision creation and revision-history reads.
- Forensic `crm.quote-acceptance.v1` evidence bound to the exact issued snapshot hash.
- Customer-vs-user acceptance attribution, actor/reference evidence and hashed session linkage.
- Durable `crm_sales_document_render_jobs` queue with retry, stale-claim recovery, renderer/template versions and output hashes.
- `crm:documents:render` worker command.
- Governed document render request/status capabilities.
- Asynchronous PDF delivery integration: outbound email waits for a ready immutable artifact rather than rendering inside delivery execution.

## Hardened

- Quotes/estimates are created as drafts and may be issued only once per revision.
- Issued revisions cannot be modified/reissued; a new revision record is required.
- Issuing a revision atomically supersedes its predecessor and advances predecessor entity version when supported.
- Expired quotes cannot be accepted.
- Accepted and superseded contracts are terminal.
- Public PDF downloads only serve completed render artifacts.
- Legacy alpha.28 issued/accepted records are conservatively backfilled from stored CRM state; legacy acceptance evidence is explicitly marked `legacy_crm_pre_alpha29` rather than fabricating customer-session evidence.

## Ownership

CRM Core owns the commercial contract state, issuance evidence, revisions and document-render job metadata. Titan Pay remains payment execution authority; Titan Ledger remains accounting authority; Titan Field remains operational job authority.
