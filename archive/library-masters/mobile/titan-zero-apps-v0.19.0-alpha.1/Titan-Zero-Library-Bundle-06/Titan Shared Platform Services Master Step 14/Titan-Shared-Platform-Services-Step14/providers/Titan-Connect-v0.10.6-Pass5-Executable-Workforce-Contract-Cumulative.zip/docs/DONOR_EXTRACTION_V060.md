# Titan Connect v0.6.0 — Official Communications Donor Extraction

## Scope

Seven official Chatbot communications extensions were scanned and used as donor implementations:

| Donor | Files scanned | Promoted capability |
|---|---:|---|
| Chatbot Agent | 27 | Operator inbox UX/behaviour, filters, contact context, tags, internal notes, canned replies, exports, AI rewrite patterns |
| Chatbot Instagram | 19 | Meta OAuth/account discovery and provider setup UX patterns |
| Chatbot Messenger | 14 | Meta/Messenger setup UX and provider icon; backend send/webhook logic was weaker than Titan Connect and was not duplicated |
| Chatbot Telegram | 13 | Bot validation and automatic `setWebhook` onboarding |
| Chatbot Voice Call | 12 | OpenAI Realtime and ElevenLabs voice-session lifecycle, transcripts, microphone/audio/waveform browser flow |
| Chatbot Voice | 57 | ElevenLabs agent and text/URL/file knowledge orchestration behind a host integration contract |
| Chatbot WhatsApp | 12 | Twilio WhatsApp sender/address/status transport behaviour |

The donor archives are **not** installed or booted by Titan Connect. Their useful behaviour was refactored into Titan Connect-native models, contracts, services, providers, controllers, routes and assets.

## Promoted into active Titan Connect runtime

### Operator workspace

Adapted from Chatbot Agent:

- provider/status/assignment/unassigned/priority/date/search/unread filters;
- pinned conversations and open/close state;
- assignment with same-company user validation;
- customer contact context;
- WorkCore authorization rechecks on linked-thread list, mutation and export paths;
- company-scoped contact tags;
- internal notes that never enter provider delivery;
- personal/company-shared canned responses;
- JSON/CSV/TXT exports and optional host PDF export;
- AI rewrite variants: improve, lengthen and grammar correction;
- notification/unread count;
- responsive operator inbox view and browser client.

Canonical implementation:

- `System/Services/OperatorInboxService.php`
- `System/Services/ExternalThreadManagementService.php`
- `System/Services/ConversationExportService.php`
- `System/Services/ExternalContactService.php`
- `System/Integration/MagicAiReplyAssistant.php`
- `resources/views/inbox/index.blade.php`
- `resources/assets/js/operator-inbox.js`

### Secure Meta onboarding

Adapted from the Instagram donor's Meta helper/OAuth flow:

- Messenger and Instagram OAuth start/callback;
- encrypted state bound to `company_id`, actor, provider, nonce and expiry;
- Page/account discovery;
- Instagram business-account discovery;
- provider connection creation/update;
- page/access token written only into Titan Connect's encrypted provider vault;
- access tokens and app secrets are never returned to the browser.

Canonical implementation: `System/Onboarding/MetaOAuthService.php`.

Instagram publishing/carousel/analytics code was intentionally **not** moved into Titan Connect because that is Titan Social publishing functionality rather than communications transport.

### Telegram onboarding

Adapted from the Telegram donor:

- validates the bot with `getMe`;
- creates/updates a company-scoped Telegram connection;
- generates a webhook secret;
- registers Titan Connect's callback with Telegram `setWebhook`;
- encrypts the bot token and webhook secret.

Canonical implementation: `System/Onboarding/TelegramWebhookRegistrar.php`.

### Twilio WhatsApp

Adapted from `Twillio/TwilioWhatsappService.php`:

- `whatsapp:` sender/recipient normalization;
- Twilio REST message creation;
- Basic-auth API key/account credential handling;
- media URL and status-callback handling;
- Twilio message status/receipt normalization;
- authenticated inbound media download.

This is **not** a second WhatsApp provider. Titan Connect retains one canonical `whatsapp` provider and selects `transport=meta|twilio` from the secured connection configuration.

Canonical implementation: `System/Providers/WhatsAppTwilioTransport.php` and `System/Providers/WhatsAppProvider.php`.

### Voice communications

Adapted from Chatbot Voice Call:

- company-scoped voice call and transcript records;
- OpenAI Realtime short-lived client credentials;
- ElevenLabs signed URL/agent sessions;
- microphone permission/audio capture;
- PCM16 streaming;
- server VAD/transcription events;
- assistant audio playback;
- user/assistant transcript persistence;
- waveform visualization;
- call lifecycle, duration and audit records;
- canonical voice-call start/end timeline events inside linked conversations;
- calls linked to an external thread or internal conversation;
- refreshable short-lived browser session credentials.

Canonical implementation:

- `System/Voice/VoiceSessionManager.php`
- `System/Voice/OpenAiRealtimeVoiceGateway.php`
- `System/Voice/ElevenLabsVoiceGateway.php`
- `System/Providers/VoiceProvider.php`
- `resources/assets/js/voice-call-client.js`

Billing/credit ownership was **not copied** from the Chatbot donor. Titan Connect records communications usage; plan/credit charging remains a host/Titan billing concern.

### Optional ElevenLabs voice-agent integration

Adapted from Chatbot Voice:

- create/update/delete an ElevenLabs agent;
- list voices;
- attach text, URL or file knowledge;
- remove knowledge documents.

The integration is behind `VoiceAgentGateway`. Its default is fail-closed/null because a host-level ElevenLabs service may use platform credentials. A Titan host can explicitly bind `MagicAiElevenLabsVoiceAgentGateway` when that credential ownership is intended.

The donor's recursive website crawler was rejected. Titan Connect never performs unrestricted recursive URL fetching for voice knowledge.

### Provider setup workspace

Adapted from the donors' channel-card/setup patterns:

- one operator-facing **Connect channel** workspace;
- Messenger/Instagram Meta OAuth launch cards;
- Telegram bot validation + automatic webhook registration;
- WhatsApp Meta/Twilio setup;
- OpenAI Realtime/ElevenLabs voice setup;
- credentials are submitted directly to Titan Connect secure onboarding/vault endpoints and are never rendered back after storage.

### Reused visual assets

Provider SVGs were promoted into `resources/assets/icons/` for WhatsApp, Messenger, Instagram and Telegram. Raw donor Blade/service-provider trees are not shipped.

## Deliberately rejected donor code

The following code was inspected but not transplanted as active runtime:

- Ably realtime integration — Titan Connect already owns persistence-first realtime/broadcast fallback;
- donor webhook controllers — Titan Connect's signature validation, replay protection and idempotency are stronger;
- provider-specific Chatbot conversation services — duplicated AI/history logic belongs behind the Chatbot bridge;
- user-ID-scoped donor persistence/authorization — incompatible with the `company_id` security boundary;
- donor migrations/service providers — canonical `ext_titan_connect_*` schema remains authoritative;
- raw browser-posted provider secrets/tokens — replaced with encrypted vault writes;
- unrestricted recursive URL crawler — rejected for SSRF/private-network risk;
- Instagram publishing and analytics — useful code, but product ownership is Titan Social, not Titan Connect.

## Security invariant

Every promoted persistent feature uses `company_id` as its sole tenant boundary. The only historical `tenant_id` read permitted in active-source compatibility code remains the legacy Chatbot Team Chat importer, which always writes canonical `company_id`.
