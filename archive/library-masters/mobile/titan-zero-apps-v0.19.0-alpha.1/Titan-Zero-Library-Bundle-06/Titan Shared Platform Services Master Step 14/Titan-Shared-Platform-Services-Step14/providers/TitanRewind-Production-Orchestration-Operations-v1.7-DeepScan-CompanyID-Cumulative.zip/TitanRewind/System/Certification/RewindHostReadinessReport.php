<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Certification;
final class RewindHostReadinessReport
{
    public function evaluate(array $checks): array
    {
        $required=['php','laravel','database','migrations','queues','scheduler','signal','governance','rewind_source_registry','evidence_signing_key'];
        $result=[];foreach($required as $key)$result[$key]=(bool)($checks[$key]??false);
        return ['ready'=>!in_array(false,$result,true),'checks'=>$result,'unavailable'=>array_keys(array_filter($result,static fn(bool $v):bool=>!$v))];
    }
}
