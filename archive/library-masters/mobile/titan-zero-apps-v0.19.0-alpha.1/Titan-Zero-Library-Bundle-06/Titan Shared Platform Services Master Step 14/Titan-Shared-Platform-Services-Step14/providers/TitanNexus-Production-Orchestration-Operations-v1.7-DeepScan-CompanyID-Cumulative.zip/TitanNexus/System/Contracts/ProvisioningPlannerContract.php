<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Contracts;

use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlan;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;

interface ProvisioningPlannerContract
{
    public function plan(NexusCompilation $compilation, VerticalDefinition $definition): ProvisioningPlan;
}
