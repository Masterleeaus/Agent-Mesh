# Titan Nexus Fresh Install Preflight

Step 5 adds a deterministic fresh-install preflight for the live Titan Extension Installer 1.7.6 host while retaining package compatibility with 1.7.8. It proves the package/install tree is internally installable before the exact MagicAI host is touched, while preserving the hard boundary that only a real host run may set `INSTALLER_CERTIFIED=PASS`.

## Preflight checks

The preflight validates:

- Installer 1.7.6/1.7.8 `extension.json` compatibility fields (`name`, `type`, `description`, `support_telegram`) plus Titan schema, slug, canonical `TitanNexus` folder, provider and version.
- Exact `integrity.files` coverage of every regular package file except `extension.json`.
- `TitanNexusServiceProvider` namespace, extension interfaces, registration key and register/boot/uninstall lifecycle entrypoints.
- Strictly ordered migration filenames, unique migration timestamps, `up()`/`down()` entrypoints and MySQL strict-mode timestamp compatibility.
- User/admin routes, Control Centre controllers/middleware, required named routes and `panel.layout.app` rendering contract.
- Config merge/publish wiring.
- Titan Interface Contribution v1.1 identity and read-only action boundary.
- Nexus menu registrar plus modern/legacy navigation compatibility wiring.

Run against an extracted extension directory:

```bash
php tools/fresh_install_preflight.php --root=/path/to/TitanNexus
```

Optionally supply facts captured from the actual target host:

```bash
php tools/fresh_install_preflight.php \
  --root=/path/to/TitanNexus \
  --host-facts=/path/to/host-facts.json
```

Host facts use:

```json
{
  "php": "8.3.33",
  "laravel": "10.50.2",
  "database": "mysql",
  "installer": "1.7.6"
}
```

A successful preflight means the package contract is ready to attempt a fresh install. It **does not** prove database migration, Laravel provider boot, routes, menus, permissions or runtime behavior on the live MagicAI host.

## Live certification sequence

Print the exact host acceptance sequence with:

```bash
php tools/exact_host_certification.php --print-sequence
```

The live certification ladder remains:

`PACKAGE_CERTIFIED → INSTALLER_CERTIFIED → MIGRATION_CERTIFIED → BOOT_CERTIFIED → NAVIGATION_CERTIFIED → AUTHORIZATION_CERTIFIED → RUNTIME_CERTIFIED → UPGRADE_CERTIFIED → UNINSTALL_CERTIFIED`

Until the exact package is executed on the target MagicAI/Titan host, `INSTALLER_CERTIFIED` and later stages remain `NOT_RUN`.

## Installer 1.7.6 root-manifest compatibility

The live Installer 1.7.6 validator requires legacy MagicAI fields (`name`, `type`, `description`, `support_telegram`) at the root of `extension.json`. Nexus H1 keeps those fields alongside the Titan installer identity fields so Installer 1.7.6 can validate the package while `extension.manifest.json` remains the canonical Titan v2.2 capability manifest.
