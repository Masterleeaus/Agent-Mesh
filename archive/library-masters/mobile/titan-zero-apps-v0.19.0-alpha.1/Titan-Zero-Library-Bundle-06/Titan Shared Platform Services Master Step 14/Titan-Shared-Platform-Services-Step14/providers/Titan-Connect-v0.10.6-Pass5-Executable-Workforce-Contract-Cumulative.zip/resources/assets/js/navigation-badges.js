(() => {
  if (window.__titanConnectNavigationBadgesLoaded) return;
  window.__titanConnectNavigationBadgesLoaded = true;
  const endpoint = window.TitanConnectNavigationBadgeUrl || document.querySelector('[data-titan-connect-inbox-header]')?.dataset.badgeEndpoint;
  if (!endpoint) return;

  const text = count => count > 99 ? '99+' : String(Math.max(0, Number(count || 0)));
  const apply = (selector, count) => {
    document.querySelectorAll(selector).forEach((node) => {
      let badge = node.matches('[data-titan-connect-inbox-badge]') ? node : node.querySelector('[data-titan-connect-inbox-badge], .tc-nav-badge');
      if (!badge) {
        badge = document.createElement('span');
        badge.className = 'tc-nav-badge';
        badge.setAttribute('data-titan-connect-inbox-badge', '');
        node.appendChild(badge);
      }
      badge.textContent = text(count);
      badge.hidden = Number(count || 0) < 1;
    });
  };
  const ensureMenuTargets = () => {
    document.querySelectorAll('[data-name="titan-connect-inbox-parent"], .titan-connect-inbox-parent').forEach((node) => node.setAttribute('data-titan-connect-inbox-menu', ''));
  };
  const refresh = async () => {
    if (document.visibilityState === 'hidden') return;
    try {
      const response = await fetch(endpoint, {credentials:'same-origin', headers:{Accept:'application/json'}});
      if (!response.ok) return;
      const payload = await response.json();
      const data = payload.data || {};
      ensureMenuTargets();
      apply('[data-titan-connect-inbox-header]', data.total);
      apply('[data-titan-connect-inbox-menu]', data.total);
      apply('[data-name="titan-connect-inbox-needs-human"]', data.needs_human);
    } catch (_) {}
  };
  refresh();
  window.setInterval(refresh, 15000);
  document.addEventListener('visibilitychange', refresh);
})();
