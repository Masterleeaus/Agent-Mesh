<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_knowledge_claims')) {
            Schema::create('titan_knowledge_claims', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('source_version_id')->constrained('titan_knowledge_source_versions')->cascadeOnDelete();
                $table->foreignId('section_id')->nullable()->constrained('titan_knowledge_sections')->nullOnDelete();
                $table->string('claim_key', 190);
                $table->string('claim_type', 120)->default('assertion')->index();
                $table->longText('statement');
                $table->string('authority_class', 80)->default('unknown')->index();
                $table->unsignedSmallInteger('authority_rank')->nullable()->index();
                $table->char('evidence_hash', 64)->nullable()->index();
                $table->string('status', 40)->default('active')->index();
                $table->timestamp('effective_from')->nullable()->index();
                $table->timestamp('effective_until')->nullable()->index();
                $table->json('metadata')->nullable();
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
                $table->uuid('trace_id')->nullable()->index();
                $table->uuid('correlation_id')->nullable()->index();
                $table->uuid('causation_id')->nullable()->index();
                $table->timestamps();
                $table->unique(['source_version_id', 'claim_key'], 'tka_claims_version_key_unique');
            });
        }

        if (! Schema::hasTable('titan_knowledge_applicability')) {
            Schema::create('titan_knowledge_applicability', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('claim_id')->constrained('titan_knowledge_claims')->cascadeOnDelete();
                $table->foreignId('jurisdiction_id')->nullable()->constrained('titan_knowledge_jurisdictions')->nullOnDelete();
                $table->string('vertical_key', 190)->nullable()->index();
                $table->string('workflow_key', 190)->nullable()->index();
                $table->string('business_type', 190)->nullable()->index();
                $table->boolean('applies')->default(true)->index();
                $table->unsignedSmallInteger('specificity')->default(0)->index();
                $table->json('conditions')->nullable();
                $table->boolean('deterministic')->default(true);
                $table->string('status', 40)->default('active')->index();
                $table->timestamp('effective_from')->nullable()->index();
                $table->timestamp('effective_until')->nullable()->index();
                $table->json('metadata')->nullable();
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
                $table->uuid('trace_id')->nullable()->index();
                $table->uuid('correlation_id')->nullable()->index();
                $table->uuid('causation_id')->nullable()->index();
                $table->timestamps();
                $table->index(['claim_id', 'jurisdiction_id', 'status'], 'tka_applicability_claim_jurisdiction_status');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_knowledge_applicability');
        Schema::dropIfExists('titan_knowledge_claims');
    }
};
