# Known Limitations — Titan Interaction Engine v10.3.1 / Phase 6.1

## Host certification

- Full MagicAI/Titan host boot, `artisan route:list`, real migration execution/pretend, service-container resolution and end-to-end provider transactions are **UNVERIFIED** in this standalone archive environment.
- Archive-level source/contract verification must not be represented as live-host certification.

## Provider availability

- **CRM — SCAFFOLDED / UNVERIFIED live execution.** The provider, descriptors, read contract and company-context boundary are implemented. The supplied CRM 1.1 source does not expose the required public Phase-6 company-scoped execution gateway, so mutations fail closed until the host binds one.
- **Titan Builder — PARTIAL.** The supplied Builder v1.0 contracts verify preview and publisher/rollback paths. Broader application, brand, navigation, feature and theme provisioning requires a public provisioning gateway. The verified `Publisher` contract accepts an integer company ID, so the compatibility adapter deliberately refuses non-numeric `company_id` values rather than coercing them.
- **Chatbot — SCAFFOLDED / UNVERIFIED live provisioning.** Capability ownership and routing are implemented, but no suitable public company-scoped provisioning gateway was verified in the supplied Chatbot build.
- **Titan Connect — PARTIAL.** The supplied `MessagingToolGateway` supports selected outbound sends. Connection/OAuth start and status remain unavailable. Its verified compatibility contract uses integer company/actor IDs, so non-numeric identifiers fail closed in the current adapter.
- **Mobile Core — SCAFFOLDED / UNVERIFIED live company readiness.** The supplied `MobileCapabilityRegistry` is a global installed-capability registry, not a company-scoped application-readiness gateway. Phase 6 intentionally does not adapt it as `mobile.application.readiness`.
- **TitanAI — SCAFFOLDED / UNVERIFIED live configuration.** Governed AI-configuration descriptors exist, but no verified company-scoped configuration gateway was found in the supplied runtime.

## Journeys and product scope

- Implemented generic journeys currently include business initial onboarding, customer onboarding, service booking and field-job completion. New staff, location, service, channel and AI-configuration journeys remain future composition work.
- Staff onboarding exposes LMS/induction extension points only; Phase 6 does not implement a full LMS.
- Dormant non-Field/Home-Service donor wizard/template resources remain for regression and migration evidence but are not exposed by the active `field_home_services` product profile.

## Migration compatibility

- Deprecated capability aliases remain temporarily for old callers, but authorization and execution always use the canonical capability. Existing approvals signed against an old alias are **not rewritten** and should be re-approved against the canonical capability.
- The old field-services execute API no longer accepts `approved_action_ids` as authorization. Callers must use the dedicated approval endpoint to obtain server-signed approval evidence before execution.
