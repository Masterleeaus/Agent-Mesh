# Security model

## Company authority

`company_id` is the canonical TitanAI security boundary. The host/source adapter must prove the principal belongs to that company before constructing runtime context. Company-owned records are addressed by company plus object identity.

## Principal versus actor

The principal is the authority used for host permissions and provider accounting. The actor describes who/what is actually performing the interaction, such as a user or autonomous workflow. Do not conflate the two for background automation or external customer surfaces.

## Request-controlled configuration blocked

Runtime payloads cannot define provider endpoint, provider API key/authorization, raw provider tool schema or assistant deployment definition.

## Trusted tools

Dynamic tools are contributed server-side. TitanAI filters them by source policy, company/user context and permissions, then re-authorizes before execution. A source adapter must pass only TitanAI-authorized schemas to the underlying model/provider.

## Business-action source gate

Deterministic business intents are not enough to authorize execution. The source policy must also allow business actions. This prevents workflow-builder/Copilot language such as “add a create invoice step” from executing an invoice.

## Provider network and credentials

TitanAI's built-in provider path permits configured HTTPS allow-listed hosts only and rejects caller-provided credentials/endpoints. MagicAI credentials remain server-side.

## Governed memory

Bundled governed-memory JSON is not application-layer encrypted. Do not store sensitive personal memory unless an encrypted/vault-backed repository is supplied by the deployment.
