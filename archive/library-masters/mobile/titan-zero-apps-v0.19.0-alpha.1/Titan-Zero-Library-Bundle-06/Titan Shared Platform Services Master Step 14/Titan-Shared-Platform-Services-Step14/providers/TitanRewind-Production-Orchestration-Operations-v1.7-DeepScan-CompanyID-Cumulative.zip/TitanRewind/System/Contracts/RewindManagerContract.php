<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Contracts;

use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use App\Extensions\TitanRewind\System\Models\RewindGovernanceReceipt;
use App\Extensions\TitanRewind\System\Models\RewindIntegrityCheck;
use App\Extensions\TitanRewind\System\Models\RewindRecoveryPlan;
use App\Extensions\TitanRewind\System\Models\RewindLegalHold;
use App\Extensions\TitanRewind\System\Models\RewindReplayRun;
use App\Extensions\TitanRewind\System\Contracts\RewindHistoricalArtifactResolverContract;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;

interface RewindManagerContract
{
    public function health(): array;
    public function liveness(): array;
    public function readiness(): array;
    public function foundation(): array;
    public function registerSourceAdapter(RewindSourceAdapterContract $adapter): void;
    public function discoverHostSources(): array;
    public function historicalArtifact(string $kind,string $version,array $context=[]): array;
    public function discoverHistoricalArtifactResolvers(): array;
    public function retentionPreview(int $tenantCompanyId,?string $class=null): array;
    public function runRetention(int $tenantCompanyId,string $class,?int $actorId=null,int $batchSize=250): array;
    public function registerHistoricalArtifactResolver(RewindHistoricalArtifactResolverContract $resolver): void;
    public function reconstruct(RewindTraceQuery $query): array;
    public function queueDryRun(RewindTraceQuery $query, ?int $requestedById = null, array $input = []): RewindReplayRun;
    public function queueComparison(RewindTraceQuery $query, string $mode, ?int $requestedById = null, array $input = []): RewindReplayRun;
    public function assistant(string $message, array $context = []): array;
    public function analytics(int $tenantCompanyId): array;
    public function toolCatalogue(): array;
    public function verifyIntegrity(RewindTraceQuery $query, ?int $checkedById = null): RewindIntegrityCheck;
    public function scanDrift(RewindTraceQuery $query, ?int $actorId = null): array;
    public function generateEvidence(RewindTraceQuery $query, string $type = 'audit', ?int $caseId = null, ?int $actorId = null): RewindEvidencePackage;
    public function generateCaseEvidence(int $tenantCompanyId, string $caseUuid, string $type = 'audit', ?int $actorId = null): RewindEvidencePackage;
    public function createRecoveryPlan(RewindTraceQuery $query, ?int $caseId = null, ?int $actorId = null, array $options = []): RewindRecoveryPlan;
    public function governanceAvailable(): bool;
    public function requestRecoveryApproval(RewindRecoveryPlan $plan, ?int $actorId = null): RewindGovernanceReceipt;
    public function sourceCompleteness(RewindTraceQuery $query): array;
    public function applyLegalHold(int $tenantCompanyId, string $scopeType, string $scopeId, string $authority, string $reason, ?int $actorId = null): RewindLegalHold;
    public function releaseLegalHold(int $tenantCompanyId, string $holdUuid, string $reason, ?int $actorId = null): RewindLegalHold;
    public function runtimeState(): array;
    public function setRuntimeState(string $state, ?string $reason = null, ?int $actorId = null): array;
    public function retryDeadLetter(string $deadLetterUuid): array;
}
