# CRM 1.3.0-alpha.8 — Menu Icon Compatibility Hotfix

- Fixed a live MagicAI navbar crash caused by unsupported Blade icon component `tabler-arrows-transfer-up-down`.
- Added a host-safe CRM menu icon allowlist and fallback in `CrmMenuInstaller`, preventing unsupported Tabler icon names from being persisted by CRM menu sync.
- Added migration `000023` to resync and repair existing CRM menu rows on upgrade.
- Preserves all alpha.7 Titan Hub/Go/BOS and AI Financial Assistant functionality.
