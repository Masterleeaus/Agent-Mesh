# Titan CRM Core v1.3.0-alpha.36 — Installer Hotfix 2

## Production failure reproduced

Installer 1.7.8 reached extension-scoped migration execution and failed in:

`database/migrations/2026_08_16_000037_add_customer_identity_authority.php`

Laravel 10 Query Builder `each()` delegates to chunking and requires an explicit ordering. One existing-company root hydration query called `each()` without `orderBy()`, producing:

`You must specify an orderBy clause when using this function.`

## Fix

The affected query now adds deterministic `orderBy('id')` before `select(...)->each(...)`.

A new `tests/MigrationDeterministicIterationTest.php` regression contract scans CRM migrations and fails if Query Builder `each()` is used without deterministic ordering while excluding already-materialized Collection iteration such as `pluck(...)->each(...)`.

## Partial migration recovery

The failed `000037` migration is restart-safe for this failure mode:

- table creation uses `Schema::hasTable()` guards;
- added columns use `Schema::hasColumn()` guards;
- identity-root backfills target null values;
- identity ledger writes use `insertOrIgnore()`;
- the corrected hydration pass is read-only.

This allows Installer 1.7.8 to retry after its recorded-migration rollback without requiring manual cleanup of guarded partial DDL that MySQL may have committed before the exception.
