<?php

declare(strict_types=1);

$path = __DIR__ . '/../System/Http/Controllers/Compatibility/ModelCouncilController.php';
if (! is_file($path)) {
    fwrite(STDERR, "FAIL: hardened compatibility controller is missing\n");
    exit(1);
}

$source = file_get_contents($path);
$required = [
    "->where('user_id', \$actorId)",
    'AcceptedResponseScope::forMessage',
    "->where('user_openai_chat_id', \$scope['user_openai_chat_id'])",
    "->where('shared_uuid', \$scope['shared_uuid'])",
    'DB::transaction',
    'lockForUpdate()',
];

foreach ($required as $needle) {
    if (! str_contains($source, $needle)) {
        fwrite(STDERR, "FAIL: controller missing protection: {$needle}\n");
        exit(1);
    }
}

if (str_contains($source, "where('shared_uuid', \$message->shared_uuid)")) {
    fwrite(STDERR, "FAIL: legacy unsafe deletion pattern still present in active controller\n");
    exit(1);
}

echo "pass1 controller security source checks passed\n";
