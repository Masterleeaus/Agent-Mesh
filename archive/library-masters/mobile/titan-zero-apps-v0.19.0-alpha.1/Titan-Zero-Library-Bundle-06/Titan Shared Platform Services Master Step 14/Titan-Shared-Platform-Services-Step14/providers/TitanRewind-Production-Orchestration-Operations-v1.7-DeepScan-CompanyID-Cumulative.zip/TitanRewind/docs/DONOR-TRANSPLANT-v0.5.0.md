# Titan Rewind v0.5.0 — Donor Transplant Pass 3

This pass extracts the donor's evidence-package, compliance-export and recovery-planning concepts onto the canonical v0.4 tenant/trace/causation/forensics architecture.

## Retained and modernized

- evidence packages and portable audit bundles
- compliance JSON export
- recovery/correction plan structure
- ordered recovery steps
- external approval/authority receipt persistence
- user evidence and recovery surfaces
- admin evidence/recovery operating summary

## Replaced rather than copied

- donor case evidence lookups are replaced by explicit case-to-trace links
- donor snapshot lookup by case ID is rejected
- donor duplicate approval systems are replaced by one external Governance gateway boundary
- donor correction/execution services are not transplanted
- direct Eloquent business-model mutation is not transplanted
- donor evidence hashing is replaced with canonical reproducible evidence hashing

## Authority boundary

Rewind may reconstruct, verify, package evidence, plan recovery and submit an explicit compensating capability for external Governance authorization. It cannot approve itself and cannot execute the resulting business mutation. Titan Command Bus remains the declared execution owner.

The default Governance gateway is fail-closed because no concrete Titan Governance package contract was available in the supplied/current source set. This is an intentional safety implementation, not a simulated integration.
