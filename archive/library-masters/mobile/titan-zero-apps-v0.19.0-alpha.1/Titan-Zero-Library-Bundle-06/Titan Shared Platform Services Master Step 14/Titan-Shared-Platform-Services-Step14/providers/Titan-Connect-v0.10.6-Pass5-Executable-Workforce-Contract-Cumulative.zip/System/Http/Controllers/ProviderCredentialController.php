<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ProviderCredential;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Extensions\TitanConnect\System\Services\MessagingAuditService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class ProviderCredentialController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly ChannelAccessPolicy $policy,
        private readonly MessagingAuditService $audit,
    ) {
    }

    public function store(Request $request, ChannelConnection $connection): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->assertManage($connection, $companyId, $actorId);

        $data = $request->validate([
            'credentials' => ['required', 'array', 'min:1'],
        ]);
        $credentials = $data['credentials'];
        $reference = trim((string) ($connection->credential_reference ?? ''));
        if ($reference === '' || ! str_starts_with($reference, 'vault_')) {
            $reference = 'vault_'.Str::lower((string) Str::ulid());
        }
        $encrypted = Crypt::encryptString(json_encode($credentials, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));

        DB::transaction(function () use ($companyId, $actorId, $connection, $reference, $encrypted): void {
            $record = ProviderCredential::query()->firstOrNew([
                'company_id' => $companyId,
                'provider' => $connection->provider,
                'reference' => $reference,
            ]);
            if (! $record->exists) {
                $record->uuid = (string) Str::uuid();
                $record->created_by = $actorId;
            }
            $record->encrypted_payload = $encrypted;
            $record->key_version = max(1, (int) $record->key_version + 1);
            $record->updated_by = $actorId;
            $record->save();

            $connectionChanges = ['credential_reference' => $reference];
            if ($connection->status === 'paused') {
                $connectionChanges['status'] = 'active';
            }
            $connection->forceFill($connectionChanges)->save();
        });

        $this->audit->record($companyId, $actorId, 'channel-credentials.rotated', 'channel-connection', (string) $connection->uuid, null, [
            'provider' => (string) $connection->provider,
            'credential_reference_hash' => hash('sha256', $reference),
        ]);

        return response()->json([
            'status' => 'stored',
            'connection_uuid' => (string) $connection->uuid,
            'provider' => (string) $connection->provider,
        ]);
    }

    public function destroy(Request $request, ChannelConnection $connection): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->assertManage($connection, $companyId, $actorId);
        $reference = trim((string) ($connection->credential_reference ?? ''));

        DB::transaction(function () use ($companyId, $connection, $reference): void {
            if ($reference !== '') {
                ProviderCredential::query()
                    ->where('company_id', $companyId)
                    ->where('provider', $connection->provider)
                    ->where('reference', $reference)
                    ->delete();
            }
            $connection->forceFill(['credential_reference' => null, 'status' => 'paused'])->save();
        });

        $this->audit->record($companyId, $actorId, 'channel-credentials.removed', 'channel-connection', (string) $connection->uuid, null, [
            'provider' => (string) $connection->provider,
        ]);

        return response()->json(['status' => 'removed', 'connection_uuid' => (string) $connection->uuid]);
    }

    private function assertManage(ChannelConnection $connection, int $companyId, int $actorId): void
    {
        abort_unless((int) $connection->company_id === $companyId, 404);
        abort_unless($this->policy->canManage($connection, $actorId), 403);
    }
}
