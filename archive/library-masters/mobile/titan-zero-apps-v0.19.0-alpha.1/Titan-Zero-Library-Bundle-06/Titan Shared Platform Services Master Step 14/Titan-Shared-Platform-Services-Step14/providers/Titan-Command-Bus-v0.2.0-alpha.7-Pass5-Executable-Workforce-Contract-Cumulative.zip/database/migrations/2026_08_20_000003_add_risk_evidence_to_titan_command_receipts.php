<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_command_receipts')) {
            return;
        }

        Schema::table('titan_command_receipts', function (Blueprint $table): void {
            if (! Schema::hasColumn('titan_command_receipts', 'risk_reference')) {
                $table->string('risk_reference', 191)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_command_receipts', 'risk_score')) {
                $table->decimal('risk_score', 6, 5)->nullable()->index();
            }
        });
    }

    public function down(): void
    {
        // Risk evidence is audit provenance and is intentionally retained on downgrade.
    }
};
