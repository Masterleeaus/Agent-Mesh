<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Import\{CrmCsvImportService,CrmImportBatchService};
use App\Extensions\Crm\System\Security\CrmPermissionService;
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use App\Extensions\Crm\System\Services\CrmExportService;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Validation\ValidationException;

final class ImportExportController extends Controller
{
    public function __construct(private CrmImportBatchService $batches, private CrmCsvImportService $csv, private CrmExportService $exporter, private CrmPermissionService $permissions, private ConnectionInterface $db, private CrmHumanMutationGateway $mutations) {}
    public function index(Request $request)
    { $uid=(int)$request->user()->id;$this->permissions->authorize($uid,'crm.import');return view('crm::import-export.index',['types'=>['companies','contacts','leads','deals','activities'],'batches'=>$this->db->table('crm_import_batches')->where('company_id',CrmCompanyScope::companyId($uid))->orderByDesc('id')->limit(50)->get()]); }
    public function import(Request $request)
    {
        $uid=(int)$request->user()->id;$this->permissions->authorize($uid,'crm.import');$data=$request->validate(['type'=>'required|in:companies,contacts,leads','records_json'=>'required|string|max:2000000','dry_run'=>'nullable|boolean']);$records=json_decode($data['records_json'],true);if(!is_array($records))throw ValidationException::withMessages(['records_json'=>['Provide a JSON array of CRM records.']]);
        $fields=match($data['type']){'companies'=>['name','website','email','phone'],'contacts'=>['first_name','last_name','email','phone','company_public_id'],'leads'=>['name','email','phone','company_name','source','status'],};$mapping=array_combine($fields,$fields);$batch=$this->mutations->execute($request,'crm.import.execute',['source_type'=>$data['type'],'source_filename'=>'browser-json','mapping'=>$mapping,'rows'=>$records,'dry_run'=>$request->boolean('dry_run',true)]);return back()->with('status',($batch['dry_run']?'Dry run completed':'Import staged for explicit approval').': '.$batch['accepted_rows'].' accepted, '.$batch['rejected_rows'].' rejected.');
    }

    public function csvImport(Request $request)
    {
        $uid=(int)$request->user()->id;$this->permissions->authorize($uid,'crm.import');
        $data=$request->validate(['type'=>'required|in:companies,contacts,leads','file'=>'required|file|max:5120','mapping_json'=>'nullable|string|max:20000','dry_run'=>'nullable|boolean']);
        $fields=match($data['type']){'companies'=>['name','website','email','phone'],'contacts'=>['first_name','last_name','email','phone','company_public_id'],'leads'=>['name','email','phone','company_name','source','status'],};
        $mapping=$data['mapping_json']?json_decode($data['mapping_json'],true):array_combine($fields,$fields); if(!is_array($mapping))throw ValidationException::withMessages(['mapping_json'=>['Provide a JSON mapping object.']]);
        $preview=$this->csv->preview($request->file('file')->getRealPath(),$mapping); $rows=$preview['rows']; $identity=$rows?array_combine(array_keys($rows[0]),array_keys($rows[0])):[];
        $batch=$this->mutations->execute($request,'crm.import.execute',['source_type'=>$data['type'],'source_filename'=>$request->file('file')->getClientOriginalName(),'mapping'=>$identity,'rows'=>$rows,'dry_run'=>$request->boolean('dry_run',true)]);
        return back()->with('status','CSV '.($batch['dry_run']?'dry run completed':'import staged for explicit approval').': '.$batch['accepted_rows'].' accepted, '.$batch['rejected_rows'].' rejected.');
    }

    public function commit(Request $request,string $batch)
    { $uid=(int)$request->user()->id;$this->permissions->authorize($uid,'crm.import');$data=$request->validate(['impact_hash'=>'required|string|size:64']);$result=$this->mutations->execute($request,'crm.import.commit',['batch_public_id'=>$batch,'impact_hash'=>$data['impact_hash']]);return back()->with('status','Import committed: '.($result['created_rows']??0).' record(s) created.'); }

    public function rollback(Request $request,string $batch)
    { $uid=(int)$request->user()->id;$this->permissions->authorize($uid,'crm.import');$this->mutations->execute($request,'crm.import.rollback',['batch_public_id'=>$batch]);return back()->with('status','Import batch rolled back.'); }
    public function export(Request $request)
    { $uid=(int)$request->user()->id;$this->permissions->authorize($uid,'crm.export');$data=$request->validate(['type'=>'required|in:companies,contacts,leads,deals,activities']);$package=$this->exporter->export($uid,$data['type']);$payload=json_encode($package,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);return response($payload,200,['Content-Type'=>'application/json','Content-Disposition'=>'attachment; filename="crm-'.$data['type'].'.json"','X-Content-Type-Options'=>'nosniff','Cache-Control'=>'private, no-store']); }
}
