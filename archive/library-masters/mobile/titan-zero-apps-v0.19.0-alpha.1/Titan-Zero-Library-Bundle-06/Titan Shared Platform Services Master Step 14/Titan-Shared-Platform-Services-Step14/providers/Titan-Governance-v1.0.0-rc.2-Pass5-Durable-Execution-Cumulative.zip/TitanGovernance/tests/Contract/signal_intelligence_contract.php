<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);

function fail_signal(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function assert_signal(bool $condition, string $message): void { if (!$condition) fail_signal($message); }
function same_signal(mixed $expected, mixed $actual, string $message): void { if ($expected !== $actual) fail_signal($message . ' expected=' . var_export($expected, true) . ' actual=' . var_export($actual, true)); }

$required = [
    '/System/ReadPlane/SignalHeatmapProjector.php',
    '/System/ReadPlane/OperationalPressureDetector.php',
    '/System/ReadPlane/CircuitBreakerProjector.php',
];
foreach ($required as $file) {
    assert_signal(is_file($root.$file), 'missing production file '.$file);
    require_once $root.$file;
}

use App\Extensions\TitanGovernance\System\ReadPlane\CircuitBreakerProjector;
use App\Extensions\TitanGovernance\System\ReadPlane\OperationalPressureDetector;
use App\Extensions\TitanGovernance\System\ReadPlane\SignalHeatmapProjector;

$signalSnapshot = [
    'source' => 'titan-signal',
    'status' => 'HEALTHY',
    'observed_at' => '2026-08-20T17:45:00+10:00',
    'signals' => [
        ['event_type'=>'crm.queue.backlog.v1','source_component'=>'crm','category'=>'queue','severity'=>'warning','observed_at'=>'2026-08-20T17:44:00+10:00'],
        ['event_type'=>'crm.queue.backlog.v1','source_component'=>'crm','category'=>'queue','severity'=>'critical','observed_at'=>'2026-08-20T17:44:30+10:00'],
        ['event_type'=>'workforce.task.failed.v1','source_component'=>'titan-ai-workforce','category'=>'execution','severity'=>'error','observed_at'=>'2026-08-20T17:43:00+10:00'],
        ['event_type'=>'signal.info.v1','source_component'=>'titan-signal','category'=>'telemetry','severity'=>'info','observed_at'=>'2026-08-20T17:42:00+10:00','payload'=>['secret'=>'must-not-cross']],
    ],
    'operational_pressure' => [
        ['source_component'=>'crm','queue_depth'=>31,'oldest_age_seconds'=>1100,'failure_rate_pct'=>12.0,'blocked_count'=>6,'saturation_pct'=>92.0],
        ['source_component'=>'titan-signal','queue_depth'=>1,'oldest_age_seconds'=>20,'failure_rate_pct'=>0.0,'blocked_count'=>0,'saturation_pct'=>15.0],
    ],
    'circuit_breakers' => [
        ['breaker_key'=>'crm-provider','source_component'=>'crm','state'=>'OPEN','reason_code'=>'FAILURE_THRESHOLD','opened_at'=>'2026-08-20T17:40:00+10:00','retry_after'=>'2026-08-20T17:50:00+10:00','secret'=>'drop-me'],
        ['breaker_key'=>'signal-delivery','source_component'=>'titan-signal','state'=>'CLOSED','reason_code'=>null],
    ],
];

$heatmap = (new SignalHeatmapProjector())->project($signalSnapshot);
same_signal('HEALTHY', $heatmap['source_status'], 'source status must propagate');
same_signal(4, $heatmap['total_signals'], 'signal count must be preserved');
same_signal('crm', $heatmap['cells'][0]['source_component'], 'highest-pressure component should sort first');
same_signal(2, $heatmap['cells'][0]['total'], 'crm component count');
same_signal(1, $heatmap['cells'][0]['critical'], 'critical count');
assert_signal(!array_key_exists('payload', $heatmap['recent'][0]), 'arbitrary signal payload must not cross read-plane boundary');

$pressure = (new OperationalPressureDetector())->detect($signalSnapshot['operational_pressure']);
same_signal('CRITICAL', $pressure['items'][0]['pressure_band'], 'high queue/age/failure/saturation should be critical pressure');
assert_signal($pressure['items'][0]['pressure_score'] <= 100, 'pressure score must be bounded');
same_signal('NORMAL', $pressure['items'][1]['pressure_band'], 'healthy component should remain normal');
assert_signal(in_array('QUEUE_DEPTH_HIGH', $pressure['items'][0]['reason_codes'], true), 'pressure reasons must be explicit');

$breakers = (new CircuitBreakerProjector())->project($signalSnapshot);
same_signal(1, $breakers['open_count'], 'one open breaker expected');
same_signal('OPEN', $breakers['items'][0]['state'], 'open breaker sorts first');
assert_signal(!array_key_exists('secret', $breakers['items'][0]), 'breaker arbitrary fields must not cross boundary');

echo "PASS: Governance signal intelligence contract\n";
