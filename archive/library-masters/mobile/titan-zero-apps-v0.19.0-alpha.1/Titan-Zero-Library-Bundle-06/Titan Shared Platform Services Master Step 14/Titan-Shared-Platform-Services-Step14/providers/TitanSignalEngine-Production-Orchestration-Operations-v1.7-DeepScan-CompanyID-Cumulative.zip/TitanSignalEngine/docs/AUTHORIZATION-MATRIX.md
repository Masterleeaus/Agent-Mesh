# Authorization Matrix

| Actor/context | Read tenant | Read system | Emit tenant | Registry manage | Console manage | Anomaly manage | Retention/redaction |
|---|---|---|---|---|---|---|---|
| Tenant human | own tenant with `signal.tenant.read` | denied | only through trusted emitter + permission | denied | denied | denied | denied |
| Tenant service/agent | own tenant with permission | denied | trusted emitter + tenant context | only through owned `SignalRegistryIdentity` namespace | policy | policy | denied by default |
| Platform admin/system | explicit scope/permission | `signal.system.read` | registered system emitter | explicit registry actor; override only when separately configured | `signal.console.manage` | `signal.anomaly.manage` | explicit retention/redaction permissions |
| Anonymous/contextless | denied | denied | denied | denied | denied | denied | denied |

Object-level tenant checks remain mandatory even behind authenticated routes.

## Additional governed operations

| Operation | Permission | Additional boundary |
|---|---|---|
| Delivery redrive | `signal.delivery.redrive` | Same tenant/system boundary as original delivery; subscriber must be installed/enabled; governed reason required |


## Anomaly lifecycle audit

`signal.anomaly.manage` permits governed acknowledge/suppress/resolve transitions only within the caller's authorized tenant/system scope. The trusted actor is copied into the immutable decision event; callers cannot supply a different audit actor or emitter identity.
