<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Navigation;

use App\Extensions\TitanConnect\System\Host\HostMenuLifecycle;
use Illuminate\Contracts\Container\Container;
use ReflectionMethod;
use Throwable;

final class HostNavigationRegistrar
{
    private const USER_REGISTRY = \App\Support\Extensions\MenuContributionRegistry::class;
    private const CONTRIBUTION_REGISTRY = \App\Support\Extensions\ContributionRegistry::class;

    public function __construct(
        private readonly Container $container,
        private readonly TitanConnectNavigation $navigation,
        private readonly HostMenuLifecycle $menuLifecycle,
    ) {
    }

    public function register(bool $regenerateCaches = false): void
    {
        $this->registerContribution(self::USER_REGISTRY, 'navigation.user', $this->navigation->user());
        $this->registerContribution(self::CONTRIBUTION_REGISTRY, 'navigation.admin', $this->navigation->admin());

        if ($regenerateCaches) {
            $this->menuLifecycle->regenerate();
        }
    }

    /** @param array<int,array<string,mixed>> $items */
    private function registerContribution(string $registryClass, string $channel, array $items): void
    {
        if (! class_exists($registryClass)) {
            return;
        }

        try {
            $registry = $this->container->make($registryClass);
            foreach (['register', 'contribute', 'add'] as $method) {
                if (! method_exists($registry, $method)) {
                    continue;
                }
                $this->invoke($registry, $method, $channel, $items);
                return;
            }
        } catch (Throwable $exception) {
            // Navigation is an optional host contribution. Never break extension boot because a
            // host registry has a different revision; the packaged compatibility guide covers it.
            if (function_exists('report')) {
                report($exception);
            }
        }
    }

    /** @param array<int,array<string,mixed>> $items */
    private function invoke(object $registry, string $method, string $channel, array $items): void
    {
        $reflection = new ReflectionMethod($registry, $method);
        $parameters = $reflection->getParameters();
        $count = count($parameters);

        if ($count <= 1) {
            $registry->{$method}($items);
            return;
        }

        if ($count === 2) {
            $first = strtolower($parameters[0]->getName());
            if (str_contains($first, 'channel') || str_contains($first, 'surface') || str_contains($first, 'type')) {
                $registry->{$method}($channel, $items);
                return;
            }
            $registry->{$method}('titan-connect', $items);
            return;
        }

        $registry->{$method}($channel, 'titan-connect', $items);
    }
}
