# Titan Autonomy Engine v1.6.0 — operations + closed-loop delegated autonomy

Titan Autonomy v1.3 extends the v1.2 host control plane with **verified live adapters** for the Titan components available in the supplied source set. The governing rule remains fail-closed: if a live dependency is missing, incompatible or cannot prove its state, autonomy does not invent a replacement path.

## Verified host baselines

This package was wired against these supplied Titan sources:

- MagicAI CRM **1.3.0-alpha.14**
- Titan Interaction Engine **10.4.0**
- TitanAI Runtime **1.5.2**
- Titan AI Assurance / ModelCouncil **1.9.0**

Titan Rewind was searched for in the supplied full-site and library source set, but no verified Rewind API was available. The existing additive `UnavailableRewindBridge` therefore remains the safe fallback. Canonical Autonomy audit records still persist even when Rewind correlation is unavailable.

## Live tenancy bridge

When CRM is installed, Autonomy resolves the tenant through:

`App\Extensions\Crm\System\Tenancy\CrmCompanyScope::tenantCompanyId()`

This is the trusted server-side source for CRM-backed autonomy and maps to Autonomy's canonical `tenant_company_id`.

ModelCouncil currently calls its own internal tenant field `company_id`. Autonomy translates the already-trusted CRM tenant identifier only at that subsystem boundary. This does **not** change CRM tenancy and does not authorize a request-supplied `company_id` or `tenant_company_id`.

## Governed live CRM capabilities

The live registry only exposes capabilities actually published by CRM alpha.14:

- `crm.customer.create`
- `crm.work_order.create`
- `crm.work_order.assign`
- `crm.work_order.reschedule`
- `crm.work_order.cancel`
- `crm.appointment.create`
- `crm.staff.schedule`
- `crm.quote.create`
- `crm.quote.approve`
- `crm.quote.transition`
- `crm.invoice.create`
- `crm.invoice.issue`
- `crm.invoice.transition`
- `crm.payment.record`
- `crm.payment.reconcile`

Important compatibility corrections:

- CRM publishes **`crm.invoice.issue`**, not `crm.invoice.send`.
- In CRM alpha.14, `crm.invoice.issue` creates a draft invoice and transitions it to `issued`; it is not merely a guessed "send existing invoice" operation.
- CRM alpha.14 does **not** publish `crm.work_order.complete`, so Autonomy does not advertise or execute it even though an older Interaction policy entry exists.

Where CRM publishes an Interaction journey, the registry records its verified journey key. Capabilities without a published first-party journey remain registered for evidence/policy purposes but cannot use the live autonomous execution path until a valid completed Interaction session can be produced.

## Live Interaction Engine + CommandBus execution

Auto and Trusted Auto execution now requires a real completed Interaction Engine wizard session.

The live flow is:

1. Resolve authenticated user and CRM tenant on the server.
2. Verify the Autonomy capability/workflow state belongs to that tenant.
3. Verify the capability exists in the live CRM registry and the risk class matches.
4. Load the Interaction Engine session.
5. Require the session to be complete and owned by the same trusted tenant/actor.
6. Require the session's canonical capability to match the requested capability.
7. Rebuild the command using Interaction Engine `CommandMapper`.
8. Ignore the caller's business payload and dispatch the server-mapped payload.
9. Re-check current Autonomy ceiling, scope, permission and Assurance state.
10. Dispatch through the real Interaction Engine `CommandBus`.

Request-supplied tenant IDs, actor IDs and approval objects are stripped. A caller cannot use Autonomy as a parallel write path around Interaction Engine.

### Existing Interaction approval policy still applies

Interaction Engine 10.4.0 now recognises verified Titan Autonomy delegation as a first-class bounded authority source on explicitly opted-in capabilities. Titan Autonomy still **does not forge an `ApprovalSigner` signature or impersonate a human**. Human approval remains valid, while fresh-auth/payment-sensitive capabilities remain non-delegable unless governed policy explicitly changes that boundary.

## Live Assurance / third handshake

Trusted Auto requires more than an LLM confidence statement.

The v1.3 third handshake requires all of the following:

- a live TitanAI runtime is present;
- a structured Assurance run exists for the exact tenant/capability/workflow;
- Assurance resolves to a permitted GREEN/assured state;
- deterministic reliability evaluation passes current evidence thresholds;
- confidence meets the configured minimum (default `0.85`);
- platform gate, user approval, bounded scope and current risk ceiling also pass.

TitanAI runtime presence is a required reliability signal but **TitanAI cannot mint the approval**. The deterministic evaluator and Assurance evidence remain independent checks.

### Requesting an Assurance assessment

When an Auto capability is otherwise eligible for Trusted Auto, the tenant UI can request a live Assurance assessment. Autonomy creates an Assurance run and locks the evidence packet through the verified ModelCouncil `AssuranceEngine` contract.

The supplied Assurance API requires a configured panel to start evaluation, and no canonical default panel was verified. Autonomy therefore does not invent one. It creates and locks the evidence, then waits for Assurance's configured panel/review process to advance the run.

## Tenant UI

Default route prefix: `dashboard/titan-autonomy` (configurable).

The **Autonomy Learning** area shows capability/workflow risk, current authority, next gate, streaks, lifetime outcomes, confidence/Assurance state, bounded scope, learning history, handshakes, regressions and host-bridge health.

Authorized users can enable only the server-derived next gate, lower autonomy, reset capability training, request a Trusted Auto Assurance assessment, change learning settings, clear learned preferences and export their tenant learning dataset.

## Super Admin policy

Platform safety floors remain:

- LOW: 1 qualifying consecutive success
- MEDIUM: 2
- HIGH: 3
- CRITICAL: 3

Tenant policy can only become stricter. High-risk Trusted Auto and Critical authority above Semi-Auto require explicit governed platform exceptions. A ceiling change never activates autonomy by itself.

## Audit and Rewind

Autonomy continues to persist its own canonical audit events for gate decisions, handshakes, regressions, learning outcomes, activations, manual downgrades, training resets, preference deletion, learning-setting changes and platform-policy changes.

When a verified Rewind adapter becomes available, these records can be correlated into the wider Titan timeline. Missing Rewind never removes or weakens Autonomy's own audit evidence.

## Installer rule

The service provider loads configuration, migrations, routes and views but does **not** query autonomy tables during provider boot. This preserves Titan's provider-before-migrations install lifecycle.

## v1.4 delegated authority

Titan Autonomy now issues short-lived, HMAC-signed delegated-authority envelopes for eligible Auto/Trusted Auto execution. The envelope contains only bounded authority metadata (tenant, capability, workflow, scope hash, policy fingerprint, session/correlation bindings and expiry) and is revalidated by Interaction Engine against current autonomy state before execution.

Delegated execution is presented to Interaction Engine as a **system actor**, never as a human actor. This prevents an autonomous request from satisfying `UserOnly` policy via a forged human identity. Human approvals remain valid and are not removed. Fresh-auth and payment-sensitive capabilities remain non-delegable unless a future governed policy explicitly changes that rule.


## v1.5 closed-loop execution reconciliation

A successful CommandBus dispatch is **not** treated as proof that Titan made the correct decision. Auto and Trusted Auto executions now create a tenant-scoped observation receipt and enter a reconciliation window before any positive trust evidence can be awarded.

Positive evidence can mature only when all of the following remain true:

1. the action was dispatched through a completed, tenant-matching Interaction Engine session;
2. the exact server-mapped command is correlated to the receipt;
3. a deterministic CRM postcondition verifies the persisted tenant-owned record;
4. a fresh tenant-explicit Assurance result is GREEN;
5. no negative feedback, reversal, material correction or incident has finalized the receipt.

Default observation windows are 15 minutes for Low risk, 60 minutes for Medium risk and 240 minutes for High risk. Critical risk does not auto-mature positive evidence.

The scheduled reconciler does not impersonate a logged-in user. It uses a tenant-explicit Assurance bridge scoped only by the receipt's trusted `tenant_company_id`. Missing scheduled Assurance or postcondition infrastructure fails closed and cannot create positive evidence.

Negative outcome feedback is intentionally one-way. Authorized user/API feedback may report `materially_corrected`, `reversed`, `failed`, `rejected` or `exception`, but it cannot submit `approved_unchanged`, `correct` or any other positive label. Positive evidence is minted only by server reconciliation.

Execution receipts sanitize credential-shaped fields before persistence. Reconciliation, feedback, learning, regressions and gate recalculation share the same correlation ID so an auditor can reconstruct the autonomous action lifecycle.


## v1.6 operations / exception centre

The tenant-facing Autonomy Operations area projects canonical execution receipts into an actionable operational queue. It highlights actions still observing, mature receipts due for reconciliation, Critical actions awaiting human verification, postcondition failures, Assurance AMBER/RED, reversals, material corrections, exceptions and capability regressions.

Managers may record append-only operational review metadata, submit the existing negative-only outcome feedback, or request an immediate recheck only after the original maturation window has elapsed. Recheck uses the same persisted postcondition and tenant-explicit Assurance path as the scheduled reconciler. It cannot mint success, shorten a trust window, promote autonomy or override a negative result.

Operational review records are intentionally separate from learning evidence and do not modify success streaks, gate eligibility, handshakes, scope or current autonomy level.
