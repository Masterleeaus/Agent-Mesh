# Payroll Runbook

1. Confirm Payroll readiness: DB healthy; required Time Attendance binding available for hourly payroll; Command Bus/Risk/Assurance available for governed/AI writes.
2. Create/import the deterministic run snapshot and confirm calculation/config/source versions.
3. Prepare the run. Hourly runs block if approved time or stable source revision is absent.
4. Review variances/reconciliation and resolve exceptions through governed proposals/adjustments.
5. Submit for approval; authorized approver approves or rejects with reason.
6. Finalize once only. Finalization locks the immutable snapshot/hash and materializes payslips in bounded 500-row batches.
7. Request communications/accounting/payment outputs. Treat `prepared`/`exported` as distinct from `transmitted`/`paid`.
8. Reconcile provider outcomes and lock the period when complete.

On dependency failure, do not retry without bound. Follow returned `attention_required`, DEGRADED or BLOCKED state and restore the missing dependency or escalate.
