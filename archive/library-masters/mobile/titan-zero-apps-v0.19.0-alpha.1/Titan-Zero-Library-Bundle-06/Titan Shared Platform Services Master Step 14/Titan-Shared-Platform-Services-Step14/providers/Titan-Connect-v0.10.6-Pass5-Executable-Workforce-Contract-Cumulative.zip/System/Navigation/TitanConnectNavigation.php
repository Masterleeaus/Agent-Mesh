<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Navigation;

final class TitanConnectNavigation
{
    /** @return array<int,array<string,mixed>> */
    public function user(): array
    {
        $items = [];

        $inbox = $this->item(
            null,
            'ext_titan_connect_inbox',
            'dashboard.user.titan-connect.inbox.unified',
            'Inbox',
            'tabler-inbox',
            6,
            ['dashboard.user.titan-connect.inbox.*'],
        );
        $inbox['badge'] = null;
        $inbox['badge_route'] = 'titan-connect.api.navigation.badges';
        $inbox['badge_key'] = 'total';
        $inbox['badge_refresh_ms'] = 15000;
        $inbox['data-name'] = 'titan-connect-inbox-parent';
        $inbox['class'] = 'titan-connect-inbox-parent';
        $items[] = $inbox;

        $inboxModes = [
            'unified' => ['key' => 'titan_connect_inbox_unified', 'label' => 'Unified Inbox', 'icon' => 'tabler-inbox'],
            'team' => ['key' => 'titan_connect_inbox_team', 'label' => 'Team / Internal', 'icon' => 'tabler-users-group'],
            'external' => ['key' => 'titan_connect_inbox_external', 'label' => 'External / Omnichannel', 'icon' => 'tabler-world'],
            'mine' => ['key' => 'titan_connect_inbox_mine', 'label' => 'Assigned to Me', 'icon' => 'tabler-user-check'],
            'unassigned' => ['key' => 'titan_connect_inbox_unassigned', 'label' => 'Unassigned', 'icon' => 'tabler-user-question'],
            'needs_human' => ['key' => 'titan_connect_inbox_needs_human', 'label' => 'Needs Human', 'icon' => 'tabler-hand-stop'],
            'closed' => ['key' => 'titan_connect_inbox_closed', 'label' => 'Closed / Archived', 'icon' => 'tabler-archive'],
        ];
        $order = 1;
        foreach ($inboxModes as $mode => $definition) {
            $child = $this->item(
                'ext_titan_connect_inbox',
                $definition['key'],
                'dashboard.user.titan-connect.inbox.'.$mode,
                $definition['label'],
                $definition['icon'],
                $order++,
                ['dashboard.user.titan-connect.inbox.'.$mode],
            );
            if ($mode === 'needs_human') {
                $child['badge_route'] = 'titan-connect.api.navigation.badges';
                $child['badge_key'] = 'needs_human';
                $child['data-name'] = 'titan-connect-inbox-needs-human';
            }
            $items[] = $child;
        }

        $channelsParent = $this->item(
            null,
            'ext_titan_connect_channels',
            'dashboard.user.titan-connect.channels.index',
            'Channels',
            'tabler-message-cog',
            7,
            ['dashboard.user.titan-connect.channels.*'],
        );
        $items[] = $channelsParent;

        // Use icons already proven by the installed Titan/MagicAI navbar component set.
        $channels = [
            'whatsapp' => ['key' => 'titan_connect_channel_whatsapp', 'label' => 'WhatsApp', 'icon' => 'tabler-message'],
            'messenger' => ['key' => 'titan_connect_channel_messenger', 'label' => 'Messenger', 'icon' => 'tabler-message'],
            'instagram' => ['key' => 'titan_connect_channel_instagram', 'label' => 'Instagram', 'icon' => 'tabler-photo'],
            'telegram' => ['key' => 'titan_connect_channel_telegram', 'label' => 'Telegram', 'icon' => 'tabler-message'],
            'sms' => ['key' => 'titan_connect_channel_sms', 'label' => 'SMS', 'icon' => 'tabler-message'],
            'voice' => ['key' => 'titan_connect_channel_voice', 'label' => 'Voice', 'icon' => 'tabler-phone-call'],
            'push' => ['key' => 'titan_connect_channel_push', 'label' => 'Push / Mobile', 'icon' => 'tabler-bell-ringing'],
        ];
        $order = 1;
        foreach ($channels as $provider => $definition) {
            $channel = $this->item(
                'ext_titan_connect_channels',
                $definition['key'],
                'dashboard.user.titan-connect.channels.'.$provider,
                $definition['label'],
                $definition['icon'],
                $order++,
                ['dashboard.user.titan-connect.channels.'.$provider],
            );
            $items[] = $channel;
        }

        return $items;
    }

    /** @return array<int,array<string,mixed>> */
    public function admin(): array
    {
        $items = [];
        $parent = $this->item(null, 'admin_titan_connect_channels', 'titan-connect.admin.channels.index', 'Titan Connect', 'tabler-message-cog', 60, ['titan-connect.admin.channels.*']);
        $parent['is_admin'] = true;
        $parent['permission_key'] = 'admin_titan_connect_channels';
        $items[] = $parent;

        $overview = $this->item('admin_titan_connect_channels', 'admin_titan_connect_channels_overview', 'titan-connect.admin.channels.index', 'Overview / Diagnostics', 'tabler-layout-dashboard', 1, ['titan-connect.admin.channels.*']);
        $overview['is_admin'] = true;
        $overview['permission_key'] = 'admin_titan_connect_channels_overview';
        $items[] = $overview;

        $providers = [
            'whatsapp' => ['WhatsApp', 'tabler-message'],
            'messenger' => ['Messenger', 'tabler-message'],
            'instagram' => ['Instagram', 'tabler-photo'],
            'telegram' => ['Telegram', 'tabler-message'],
            'sms' => ['SMS', 'tabler-message'],
            'voice' => ['Voice', 'tabler-phone-call'],
            'push' => ['Push / Mobile', 'tabler-bell-ringing'],
        ];
        $order = 2;
        foreach ($providers as $provider => [$label, $icon]) {
            $item = $this->item(
                'admin_titan_connect_channels',
                'admin_titan_connect_channel_'.$provider,
                'titan-connect.admin.channels.'.$provider,
                $label,
                $icon,
                $order++,
                ['titan-connect.admin.channels.'.$provider],
            );
            $item['is_admin'] = true;
            $item['permission_key'] = 'admin_titan_connect_channel_'.$provider;
            $items[] = $item;
        }

        return $items;
    }

    /** @return array<int,array<string,mixed>> */
    public function liveHostAdmin(): array
    {
        $overview = $this->item(
            'settings',
            'titan_connect_admin_settings',
            'dashboard.admin.settings.titan-connect.channels.index',
            'Titan Connect',
            'tabler-message-cog',
            90,
            ['dashboard.admin.settings.titan-connect.channels.*'],
        );
        $overview['is_admin'] = true;
        $overview['permission_key'] = 'settings';

        return [$overview];
    }

    /** @return array<string,mixed> */
    private function item(?string $parentKey, string $key, string $route, string $label, string $icon, int $order, array $active, array $params = []): array
    {
        return [
            'parent_key' => $parentKey,
            'key' => $key,
            'route' => $route,
            'route_slug' => null,
            'label' => $label,
            'icon' => $icon,
            'order' => $order,
            'is_active' => true,
            'params' => $params,
            'type' => 'item',
            'badge' => null,
            'extension' => false,
            'is_admin' => false,
            'active_condition' => $active,
            'show_condition' => true,
        ];
    }
}
