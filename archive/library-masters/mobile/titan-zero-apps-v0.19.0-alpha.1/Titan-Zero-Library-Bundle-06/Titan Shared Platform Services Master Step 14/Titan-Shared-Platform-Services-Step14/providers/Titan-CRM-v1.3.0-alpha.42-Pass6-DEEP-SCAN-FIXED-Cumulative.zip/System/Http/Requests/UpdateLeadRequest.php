<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
final class UpdateLeadRequest extends FormRequest {
 public function authorize(): bool { return true; }
 public function rules(): array { return ['name'=>['sometimes','required','string','max:190'],'email'=>['sometimes','nullable','email','max:190'],'phone'=>['sometimes','nullable','string','max:60'],'company_name'=>['sometimes','nullable','string','max:190'],'notes'=>['sometimes','nullable','string','max:5000'],'status'=>['sometimes','string','max:40'],'source'=>['sometimes','nullable','string','max:80'],'owner_user_id'=>['sometimes','nullable','integer','min:1'],'priority'=>['sometimes','integer','between:0,100'],'follow_up_at'=>['sometimes','nullable','date']]; }
}
