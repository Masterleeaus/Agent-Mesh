<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Adapters\CommandBus;

use App\Extensions\TitanNexus\System\Contracts\ProvisioningCommandGatewayContract;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningReceipt;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use Closure;
use InvalidArgumentException;
use RuntimeException;

final class CommandBusProvisioningAdapter implements ProvisioningCommandGatewayContract
{
    private readonly ?Closure $gateway;

    public function __construct(?callable $gateway = null)
    {
        $this->gateway = $gateway === null ? null : Closure::fromCallable($gateway);
    }

    public function execute(ProvisioningOperation $operation, TraceContext $traceContext): ProvisioningReceipt
    {
        if ($operation->tenantCompanyId() !== $traceContext->tenantCompanyId()) {
            throw new InvalidArgumentException('Provisioning operation and trace context must belong to the same tenant.');
        }
        if ($this->gateway === null) {
            throw new RuntimeException('Titan Nexus Command Bus public provisioning gateway is not configured.');
        }
        $request = [
            'tenant_company_id' => $operation->tenantCompanyId(),
            'compilation_uuid' => $operation->compilationUuid(),
            'operation_id' => $operation->operationId(),
            'idempotency_key' => $operation->idempotencyKey(),
            'capability' => $operation->capability(),
            'path' => $operation->path(),
            'change_kind' => $operation->kind()->value,
            'before' => $operation->before(),
            'desired_state' => $operation->after(),
            'trace_context' => $traceContext->toArray(),
            'mutation_safety' => [
                'capture_backup_before_write' => true,
                'verify_backup_before_write' => true,
                'verify_write_after' => true,
                'audit_operation' => true,
                'preserve_rollback_metadata' => true,
            ],
        ];
        $result = ($this->gateway)($operation->capability(), $request);
        if (!is_array($result)) {
            throw new RuntimeException('Command Bus provisioning gateway must return an array receipt.');
        }
        $receipt = ProvisioningReceipt::fromArray($result);
        if (!hash_equals($operation->operationId(), $receipt->operationId())
            || !hash_equals($operation->idempotencyKey(), $receipt->idempotencyKey())) {
            throw new RuntimeException('Command Bus provisioning receipt does not match the requested operation/idempotency key.');
        }
        return $receipt;
    }
}
