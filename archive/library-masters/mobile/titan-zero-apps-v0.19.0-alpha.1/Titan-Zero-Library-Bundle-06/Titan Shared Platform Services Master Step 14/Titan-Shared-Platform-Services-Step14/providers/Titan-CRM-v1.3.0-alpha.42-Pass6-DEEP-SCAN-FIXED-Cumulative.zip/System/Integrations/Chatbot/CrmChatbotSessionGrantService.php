<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\Chatbot;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class CrmChatbotSessionGrantService
{
    public function __construct(private ConnectionInterface $db) {}

    public function issueVerifiedGrant(
        int $userId,
        int $chatbotId,
        int $chatbotCustomerId,
        string $contactPublicId,
        string $sessionId,
        ?int $ttlMinutes = null,
    ): array {
        if ($userId <= 0 || $chatbotId <= 0 || $chatbotCustomerId <= 0 || $contactPublicId === '' || $sessionId === '') {
            throw new InvalidArgumentException('A complete verified Chatbot session context is required.');
        }

        $sessionHash = hash('sha256', $sessionId);
        $ttl = max(1, min($ttlMinutes ?? (int) config('crm.chatbot.private_session_ttl_minutes', 30), 240));
        $now = now();
        $expires = $now->copy()->addMinutes($ttl);

        $query = $this->db->table('crm_chatbot_session_grants')
            ->where('company_id', CrmCompanyScope::companyId($userId))
            ->where('chatbot_id', $chatbotId)
            ->where('chatbot_customer_id', $chatbotCustomerId)
            ->where('session_hash', $sessionHash);
        $existing = $query->first();

        $payload = [
            'crm_contact_public_id' => $contactPublicId,
            'issued_at' => $now,
            'expires_at' => $expires,
            'revoked_at' => null,
            'metadata' => json_encode(['assurance' => 'titan-customer-magic-link']),
            'updated_at' => $now,
        ];

        if ($existing) {
            $query->update($payload);
        } else {
            $this->db->table('crm_chatbot_session_grants')->insert([
                'public_id' => (string) Str::ulid(),
                'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),
                'chatbot_id' => $chatbotId,
                'chatbot_customer_id' => $chatbotCustomerId,
                'session_hash' => $sessionHash,
                'created_at' => $now,
            ] + $payload);
        }

        return (array) $query->first();
    }

    public function active(
        int $userId,
        int $chatbotId,
        int $chatbotCustomerId,
        string $contactPublicId,
        string $sessionId,
    ): bool {
        if ($userId <= 0 || $chatbotId <= 0 || $chatbotCustomerId <= 0 || $contactPublicId === '' || $sessionId === '') {
            return false;
        }

        return $this->db->table('crm_chatbot_session_grants')
            ->where('company_id', CrmCompanyScope::companyId($userId))
            ->where('chatbot_id', $chatbotId)
            ->where('chatbot_customer_id', $chatbotCustomerId)
            ->where('crm_contact_public_id', $contactPublicId)
            ->where('session_hash', hash('sha256', $sessionId))
            ->whereNull('revoked_at')
            ->where('expires_at', '>', now())
            ->exists();
    }

    public function revokeForCustomer(int $userId, int $chatbotId, int $chatbotCustomerId): int
    {
        return $this->db->table('crm_chatbot_session_grants')
            ->where('company_id', CrmCompanyScope::companyId($userId))
            ->where('chatbot_id', $chatbotId)
            ->where('chatbot_customer_id', $chatbotCustomerId)
            ->whereNull('revoked_at')
            ->update(['revoked_at' => now(), 'updated_at' => now()]);
    }
}
