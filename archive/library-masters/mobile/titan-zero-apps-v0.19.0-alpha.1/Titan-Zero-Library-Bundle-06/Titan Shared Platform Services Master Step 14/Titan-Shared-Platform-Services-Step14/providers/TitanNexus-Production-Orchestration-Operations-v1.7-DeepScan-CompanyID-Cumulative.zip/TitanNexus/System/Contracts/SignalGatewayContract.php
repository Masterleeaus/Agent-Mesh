<?php

declare(strict_types=1);
namespace App\Extensions\TitanNexus\System\Contracts;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
interface SignalGatewayContract { /** @param array<string,mixed> $evidence */ public function emit(string $event, ProvisioningOperation $operation, TraceContext $traceContext, ProvisioningExecutionContext $executionContext, array $evidence = []): string; }
