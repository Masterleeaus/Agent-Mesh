<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Services;

use Illuminate\Contracts\Foundation\Application;
use Throwable;

final class HostMenuLifecycle
{
    private const MENU_SERVICE = 'App\\Services\\Common\\MenuService';

    public function __construct(private readonly Application $app) {}

    /** @return array{available:bool,regenerated:bool} */
    public function regenerate(): array
    {
        if (! class_exists(self::MENU_SERVICE)) {
            return ['available' => false, 'regenerated' => false];
        }

        try {
            $menu = $this->app->make(self::MENU_SERVICE);
            if (! method_exists($menu, 'regenerate')) {
                return ['available' => true, 'regenerated' => false];
            }

            $menu->regenerate();
            return ['available' => true, 'regenerated' => true];
        } catch (Throwable) {
            return ['available' => true, 'regenerated' => false];
        }
    }
}
