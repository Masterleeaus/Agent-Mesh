# Security, Tenancy and Privacy

## Tenant authority

`PayrollCompanyContext` derives `tenant_company_id` from the authenticated actor. Mutation controllers strip caller `tenant_company_id`, `company_id`, `user_id` and `employee_id` authority fields before execution. Employee self-service derives employee identity from the authenticated actor.

## Authorization and governance

Host authorization supports Super Admin bypass plus bounded compatibility with host `can`, `checkPermission`, `hasPermissionTo` and delegated `isAdmin`. High/critical financial mutations require Risk and Assurance approval. AI/Workforce writes additionally require the real Command Bus and fail closed if governance is unavailable.

## Sensitive data

Bank details, tax identifiers, full payslip bodies/documents, API keys, secrets and access tokens are denied from logs, Signal payloads, Rewind facts, AI prompts and serialized privacy DTOs. Employee preference values are protected through the extension's encrypted-value boundary. Payslip grants bind tenant + authenticated employee + payslip + expiry/version.

## Pass-4 review

Blueprint architecture scan: 0 critical findings, 49 review warnings before final packaging. Warnings are raw-DB/unbounded-query heuristics on explicitly reviewed live repositories. Bounded collection reads exist for Workforce (max 50), self service, Rewind (500), and finalization run-item materialization (500-row `chunkById`). Menu DB access targets the non-tenant host menu registry only. Receipt-store opaque-key behavior is documented in Data Ownership.
