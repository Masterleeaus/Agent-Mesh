<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use Illuminate\Support\Facades\Gate;
use RuntimeException;

final class LaravelAuthHostContextBridge implements HostContextBridgeContract
{
    public function tenantCompanyId(): int
    {
        $user = auth()->user();
        if ($user === null) {
            throw new RuntimeException('AUTHENTICATED_USER_REQUIRED');
        }

        $value = method_exists($user, 'getAttribute')
            ? $user->getAttribute('tenant_company_id')
            : ($user->tenant_company_id ?? null);

        if (!is_numeric($value) || (int) $value <= 0) {
            throw new RuntimeException('TENANT_COMPANY_CONTEXT_UNAVAILABLE');
        }

        return (int) $value;
    }

    public function userId(): int
    {
        $user = auth()->user();
        if ($user === null) {
            throw new RuntimeException('AUTHENTICATED_USER_REQUIRED');
        }

        $value = method_exists($user, 'getAuthIdentifier') ? $user->getAuthIdentifier() : ($user->id ?? null);
        if (!is_numeric($value) || (int) $value <= 0) {
            throw new RuntimeException('AUTHENTICATED_USER_ID_UNAVAILABLE');
        }

        return (int) $value;
    }

    public function can(string $permission): bool
    {
        $user = auth()->user();
        if ($user === null) return false;

        if (method_exists($user, 'can')) {
            return (bool) $user->can($permission);
        }

        return Gate::allows($permission);
    }

    public function isSuperAdmin(): bool
    {
        return $this->can('titan.autonomy.admin');
    }
}
