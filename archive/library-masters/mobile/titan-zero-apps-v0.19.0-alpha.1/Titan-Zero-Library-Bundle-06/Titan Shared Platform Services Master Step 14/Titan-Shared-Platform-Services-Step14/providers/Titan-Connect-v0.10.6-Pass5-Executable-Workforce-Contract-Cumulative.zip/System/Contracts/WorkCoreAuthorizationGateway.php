<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

interface WorkCoreAuthorizationGateway
{
    public function assertCanAccess(int $companyId, int $actorId, string $entityType, string $entityId): void;
}
