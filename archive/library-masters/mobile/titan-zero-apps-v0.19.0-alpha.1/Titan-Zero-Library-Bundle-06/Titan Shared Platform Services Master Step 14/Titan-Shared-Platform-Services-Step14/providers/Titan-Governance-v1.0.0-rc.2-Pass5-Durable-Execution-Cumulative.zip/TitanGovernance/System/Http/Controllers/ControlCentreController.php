<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Http\Controllers;

use App\Extensions\TitanGovernance\System\Context\TenantCompanyResolver;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceManagerContract;
use App\Extensions\TitanGovernance\System\Host\TitanHostAuthorizationAdapter;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class ControlCentreController
{
    public function __construct(
        private readonly GovernanceManagerContract $governance,
        private readonly TenantCompanyResolver $tenants,
        private readonly TitanHostAuthorizationAdapter $authorization,
    ) {}

    public function __invoke(Request $request): JsonResponse|View
    {
        $user=$request->user();
        abort_unless($user&&$this->authorization->allows($user,'titan-governance.view',['titan-governance.view']),403);
        $tenantCompanyId=$this->tenants->resolve($user);
        $snapshot=$this->governance->controlCentre($tenantCompanyId);
        if($request->expectsJson()) return response()->json($snapshot);
        return view('titan-governance::control-centre',[
            'tenantCompanyId'=>$tenantCompanyId,
            'snapshot'=>$snapshot,
        ]);
    }
}
