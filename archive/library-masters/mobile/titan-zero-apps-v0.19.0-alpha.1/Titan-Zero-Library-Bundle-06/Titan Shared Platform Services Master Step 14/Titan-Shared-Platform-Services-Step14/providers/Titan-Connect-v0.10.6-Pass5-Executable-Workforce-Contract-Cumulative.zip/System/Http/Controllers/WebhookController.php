<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CredentialVault;
use App\Extensions\TitanConnect\System\Jobs\ProcessInboundWebhookJob;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Providers\ProviderRegistry;
use App\Extensions\TitanConnect\System\Webhooks\InboundWebhookService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

final class WebhookController extends Controller
{
    public function verify(
        Request $request,
        string $provider,
        ChannelConnection $connection,
        ProviderRegistry $providers,
        CredentialVault $vault,
    ): Response {
        abort_unless(hash_equals((string) $connection->provider, strtolower(trim($provider))), 404);
        abort_unless($connection->status === 'active', 403);

        $adapter = $providers->get((string) $connection->provider);
        abort_unless($adapter->supportsInbound(), 404);
        $credentials = $vault->credentials((int) $connection->company_id, $connection);
        $challenge = $adapter->verifyWebhookChallenge($request->query(), $credentials);
        abort_if($challenge === null, 403, 'Webhook verification failed.');

        return response((string) $challenge, 200)->header('Content-Type', 'text/plain; charset=UTF-8');
    }

    public function handle(Request $request, string $provider, ChannelConnection $connection, InboundWebhookService $service): JsonResponse
    {
        abort_unless(hash_equals((string) $connection->provider, strtolower(trim($provider))), 404);
        $headers = $request->headers->all();
        $body = (string) $request->getContent();
        $service->assertVerified($connection, $headers, $body);

        if ((bool) config('titan-connect.webhooks.async_after_response', true)) {
            ProcessInboundWebhookJob::dispatch(
                (int) $connection->company_id,
                (string) $connection->uuid,
                (string) $connection->provider,
                $headers,
                $body,
            )->afterResponse();
            return response()->json(['status' => 'accepted'], 200);
        }

        return response()->json($service->handle($connection, $headers, $body), 200);
    }
}
