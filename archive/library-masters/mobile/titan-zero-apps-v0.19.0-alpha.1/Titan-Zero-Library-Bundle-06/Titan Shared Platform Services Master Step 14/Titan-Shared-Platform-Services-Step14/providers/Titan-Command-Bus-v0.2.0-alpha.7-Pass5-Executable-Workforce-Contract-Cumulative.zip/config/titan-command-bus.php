<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'kill_switch' => false,
    'queue' => 'titan-command-bus',
    'tenant_key' => 'company_id',
    'legacy_tenant_key' => 'tenant_company_id',
    'require_signal' => true,
    'require_risk' => true,
    'require_assurance' => true,
    'require_autonomy' => true,
    'require_approval_verification' => true,
    'require_lifecycle' => true,
    'allow_offline_revalidation' => true,
    'max_payload_bytes' => 65536,
];
