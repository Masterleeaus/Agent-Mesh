<?php

declare(strict_types=1);
$root = dirname(__DIR__, 2);
$health = (string) file_get_contents($root . '/System/Services/HealthCheck.php');
$runtime = (string) file_get_contents($root . '/System/Services/RuntimeManager.php');
foreach ([
    'risk_gateway_bound', 'assurance_gateway_bound', 'autonomy_gateway_bound',
    'command_bus_gateway_bound', 'governance_preflight_bound', 'command_bus_boundary_bound',
] as $needle) {
    if (!str_contains($health, $needle)) { fwrite(STDERR, "health check missing {$needle}\n"); exit(1); }
}
if (!str_contains($runtime, "'governance_preflight' => 'fail_closed_boundary_ready'") ||
    !str_contains($runtime, "'command_bus_mutation' => 'disabled_fail_closed'")) {
    fwrite(STDERR, "runtime status does not expose Pass 4 governance boundary\n"); exit(1);
}
fwrite(STDOUT, "Pass 4 health contract test: PASS\n");
