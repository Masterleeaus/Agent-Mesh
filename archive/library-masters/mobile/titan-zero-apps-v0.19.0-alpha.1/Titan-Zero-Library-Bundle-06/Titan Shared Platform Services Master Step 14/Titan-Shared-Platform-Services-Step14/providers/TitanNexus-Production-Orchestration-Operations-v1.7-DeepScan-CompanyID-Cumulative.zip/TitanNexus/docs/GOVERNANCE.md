# Governance

Provisioning order is Risk → Governance → Autonomy when autonomous → Assurance → Signal/Rewind preflight → Command Bus → Signal/Rewind outcome. Approval-required changes require explicit approval evidence. Offline operation never increases authority.
