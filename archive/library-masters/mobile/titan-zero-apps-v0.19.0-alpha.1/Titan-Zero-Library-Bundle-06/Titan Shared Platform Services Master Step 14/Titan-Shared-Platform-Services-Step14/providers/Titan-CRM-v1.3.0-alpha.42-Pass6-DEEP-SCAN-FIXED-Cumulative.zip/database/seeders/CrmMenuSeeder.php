<?php

declare(strict_types=1);

namespace App\Extensions\Crm\Database\Seeders;

use App\Extensions\Crm\System\Navigation\CrmMenuInstaller;
use Illuminate\Database\Seeder;

final class CrmMenuSeeder extends Seeder
{
    public function run(): void
    {
        CrmMenuInstaller::sync();
    }
}
