<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

interface CompanyActorDirectory
{
    /** @param array<int> $userIds */
    public function assertUsersBelongToCompany(int $companyId, array $userIds): void;
}
