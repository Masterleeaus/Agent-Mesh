<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Contracts;

interface GovernanceEscalationStoreContract
{
    /** @return list<array<string,mixed>> */
    public function queue(int $tenantCompanyId,int $limit=50): array;

    /** @return array<string,mixed>|null */
    public function find(int $tenantCompanyId,string $escalationId): ?array;

    /** @return array<string,mixed> */
    public function applyTransition(int $tenantCompanyId,string $escalationId,int $expectedVersion,string $nextStatus,string $resolutionAction,string $decisionId,string $commandReceiptRef): array;
}
