<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
require_once $root.'/System/DTO/CommandContext.php';
require_once $root.'/System/DTO/CommandReceipt.php';
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandReceipt;
$ctx=CommandContext::forCompany(77,'agent','wf-7','titan-ai-workforce');
if($ctx->companyId!==77||$ctx->tenantCompanyId!==77) throw new RuntimeException('company/legacy alias convergence failed');
$a=$ctx->toAuditArray();
if(($a['company_id']??null)!==77||array_key_exists('tenant_company_id',$a)) throw new RuntimeException('audit envelope not canonical');
$r=new CommandReceipt(str_repeat('a',64),'idem',str_repeat('b',64),77,'svc','agent','wf-7','ledger.journal.post','blocked','t','c','x','r',false,reasonCode:'policy_disabled');
$ra=$r->toArray();
if(($ra['company_id']??null)!==77) throw new RuntimeException('receipt company_id missing');
if(($ra['tenant_company_id']??null)!==77) throw new RuntimeException('legacy receipt alias missing');
$store=file_get_contents($root.'/System/Infrastructure/Persistence/DatabaseCommandReceiptStore.php');
if(!str_contains($store,"->where('company_id', \$context->companyId)")) throw new RuntimeException('receipt store query not canonical');
if(!str_contains($store,"'company_id' => \$receipt->companyId")) throw new RuntimeException('receipt store canonical write missing');
$manifest=json_decode(file_get_contents($root.'/extension.manifest.json'),true,flags:JSON_THROW_ON_ERROR);
if(($manifest['data']['tenant_key']??null)!=='company_id') throw new RuntimeException('manifest data tenant key not canonical');
if(($manifest['data_governance']['tenant_key']??null)!=='company_id') throw new RuntimeException('manifest governance tenant key not canonical');
echo "PASS CanonicalCompanyTenancyTest
";
