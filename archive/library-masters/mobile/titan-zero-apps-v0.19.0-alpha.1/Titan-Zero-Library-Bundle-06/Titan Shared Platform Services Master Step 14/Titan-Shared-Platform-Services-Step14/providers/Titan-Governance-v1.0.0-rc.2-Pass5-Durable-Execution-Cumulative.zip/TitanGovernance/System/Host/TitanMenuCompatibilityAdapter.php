<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Host;

use Illuminate\Support\Facades\Schema;
use Throwable;

/** Modern navigation registry first; MagicAI menus-table fallback. */
final class TitanMenuCompatibilityAdapter
{
    /** @param list<array<string,mixed>> $definitions */
    public function registerAll(array $definitions): void
    {
        if (app()->bound('MenuContributionRegistry')) {
            try {
                $registry = app('MenuContributionRegistry');
                if (method_exists($registry, 'register')) {
                    foreach ($definitions as $definition) {
                        $registry->register($definition);
                    }
                    return;
                }
            } catch (Throwable) {
                // Fall through to the MagicAI menus-table self-heal.
            }
        }

        $this->legacyUpsertPreserveAdminState($definitions);
    }

    /** @param list<array<string,mixed>> $definitions */
    public function removeAll(array $definitions): void
    {
        if (app()->bound('MenuContributionRegistry')) {
            try {
                $registry = app('MenuContributionRegistry');
                if (method_exists($registry, 'unregister')) {
                    foreach (array_reverse($definitions) as $definition) {
                        $registry->unregister((string) ($definition['key'] ?? ''));
                    }
                }
            } catch (Throwable) {}
        }

        if (!Schema::hasTable('menus')) return;
        try {
            $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
            foreach (array_reverse($definitions) as $definition) {
                if (($definition['legacy_enabled'] ?? true) === false) continue;
                $identity = $this->resolveLegacyIdentity($definition, $columns);
                if ($identity === []) continue;
                $query = LegacyMenuRow::query();
                foreach ($identity as $key => $value) $query->where($key, $value);
                $query->delete();
            }
            $this->regenerate();
        } catch (Throwable) {}
    }

    /** @param list<array<string,mixed>> $definitions */
    private function legacyUpsertPreserveAdminState(array $definitions): void
    {
        if (!Schema::hasTable('menus')) return;

        try {
            $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
            $parentIds = [];

            foreach ($definitions as $definition) {
                if (($definition['legacy_enabled'] ?? true) === false) continue;
                $identity = $this->resolveLegacyIdentity($definition, $columns);
                if ($identity === []) continue;

                $payload = $this->filterColumns($definition['legacy_fields'] ?? [], $columns);
                foreach (['order', 'sort', 'position', 'enabled', 'status', 'is_active'] as $field) {
                    unset($payload[$field]);
                }

                $parentKey = $definition['parent_key'] ?? null;
                if (is_string($parentKey) && isset($parentIds[$parentKey]) && isset($columns['parent_id'])) {
                    $payload['parent_id'] = $parentIds[$parentKey];
                }

                $query = LegacyMenuRow::query();
                foreach ($identity as $key => $value) $query->where($key, $value);
                $existing = $query->first();
                $id = null;

                if ($existing !== null) {
                    if ($payload !== []) $query->update($payload);
                    $id = isset($existing->id) ? (int) $existing->id : null;
                } else {
                    $row = array_merge($identity, $payload);
                    $id = isset($columns['id']) ? (int) LegacyMenuRow::query()->insertGetId($row) : null;
                    if (!isset($columns['id'])) LegacyMenuRow::query()->insert($row);
                }

                if (isset($definition['key']) && is_string($definition['key']) && $id !== null) {
                    $parentIds[$definition['key']] = $id;
                }
            }

            $this->regenerate();
        } catch (Throwable) {
            // Navigation self-heal must never prevent extension boot.
        }
    }

    /** @param array<string,mixed> $definition @param array<string,bool> $columns @return array<string,mixed> */
    private function resolveLegacyIdentity(array $definition, array $columns): array
    {
        $identity = $this->filterColumns($definition['legacy_identity'] ?? [], $columns);
        return $identity !== [] ? $identity : $this->filterColumns($definition['legacy_fallback_identity'] ?? [], $columns);
    }

    /** @param array<string,mixed> $values @param array<string,bool> $columns @return array<string,mixed> */
    private function filterColumns(array $values, array $columns): array
    {
        return array_filter(
            $values,
            static fn (mixed $value, string $key): bool => isset($columns[$key]) && $value !== null && $value !== '',
            ARRAY_FILTER_USE_BOTH
        );
    }

    private function regenerate(): void
    {
        $serviceClass = 'App\\Services\\Common\\MenuService';
        if (!class_exists($serviceClass)) return;
        try {
            $service = app($serviceClass);
            if (method_exists($service, 'regenerate')) $service->regenerate();
        } catch (Throwable) {}
    }
}
