<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalPulseProjectionFreshness extends Model
{
    protected $table = 'titan_signal_pulse_projection_freshness';
    protected $guarded = [];
    protected $casts = [
        'tenant_company_id' => 'integer',
        'tenant_key' => 'integer',
        'projected_count' => 'integer',
        'last_recorded_at' => 'immutable_datetime',
        'last_ingested_recorded_at' => 'immutable_datetime',
        'last_projected_at' => 'immutable_datetime',
    ];
}
