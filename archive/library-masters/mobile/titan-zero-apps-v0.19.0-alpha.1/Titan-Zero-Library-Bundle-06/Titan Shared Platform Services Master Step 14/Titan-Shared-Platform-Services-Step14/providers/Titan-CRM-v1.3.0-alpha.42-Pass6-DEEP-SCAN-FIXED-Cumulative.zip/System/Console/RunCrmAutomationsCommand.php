<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\Automation\CrmAutomationScheduler;
use Illuminate\Console\Command;
use Illuminate\Database\ConnectionInterface;

final class RunCrmAutomationsCommand extends Command
{
    protected $signature = 'crm:automations:run {--user=}';
    protected $description = 'Run due governed CRM automation rules. Proactive/autonomous execution belongs to Titan AI Workforce and Titan Autonomy.';

    public function handle(CrmAutomationScheduler $scheduler,ConnectionInterface $db): int
    {
        if($this->option('user'))$ids=[(int)$this->option('user')];
        else $ids=$db->table('crm_automation_rules')->where('enabled',true)->distinct()->pluck('user_id')->map(fn($v)=>(int)$v)->filter(fn($v)=>$v>0)->values()->all();
        $automationCount=0;
        foreach($ids as $id)$automationCount+=count($scheduler->runForUser($id));
        $this->info("CRM governed automation runs processed: {$automationCount}");
        return self::SUCCESS;
    }
}
