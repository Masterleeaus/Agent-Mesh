<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Bridges\FailClosedEngineBridge;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayRequest;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineCallStatus;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

final class EngineGatewayContractTest extends TestCase
{
    public function test_default_bridge_fails_closed_without_granting_success(): void
    {
        $request = new EngineGatewayRequest(
            EngineKey::Risk,
            'risk.assess',
            'op-risk-1',
            new TraceContext(7, 'trace-1', 'corr-1', 'cause-1', 'root-1'),
            ['mission_id' => 'mission-1'],
        );

        $result = (new FailClosedEngineBridge())->dispatch($request);

        self::assertSame(EngineCallStatus::Unavailable, $result->status);
        self::assertFalse($result->isSuccess());
        self::assertFalse($result->permitsContinuation());
        self::assertContains('engine_bridge_unbound', $result->reasonCodes);
    }

    public function test_gateway_request_rejects_secret_like_payload_fields(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('forbidden field');

        new EngineGatewayRequest(
            EngineKey::AiCore,
            'core.plan',
            'op-ai-1',
            new TraceContext(7, 'trace-1', 'corr-1'),
            ['nested' => ['authorization' => 'secret']],
        );
    }

    public function test_engine_keys_use_canonical_titan_authority_ids(): void
    {
        self::assertSame('titan-risk', EngineKey::Risk->value);
        self::assertSame('titan-autonomy', EngineKey::Autonomy->value);
        self::assertSame('titan-assurance', EngineKey::Assurance->value);
        self::assertSame('titan-governance', EngineKey::Governance->value);
        self::assertSame('titan-signal', EngineKey::Signal->value);
        self::assertSame('titan-rewind', EngineKey::Rewind->value);
        self::assertSame('titan-wisdom', EngineKey::Wisdom->value);
        self::assertSame('titan-ai-core', EngineKey::AiCore->value);
    }
}
