# Titan CRM v1.3.0-alpha.21 Integrity & Governance Hardening Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Harden alpha.20 against cross-tenant reference mistakes, provider-payment replay, AI data leakage, Signal loss/duplication, automation governance bypass, stale-write ambiguity and unsafe imports.

**Architecture:** Add focused governance services around the existing capability executor rather than rewriting domain repositories. Persist transactional outbox metadata in CRM, but keep external Signal/Command Bus authority outside CRM. Preserve backward-compatible human routes while all AI/automation mutations use the governed gateway.

**Tech Stack:** PHP 8.2+/Laravel extension architecture, Illuminate DB/Schema, existing static verifier suite.

## Global Constraints
- Preserve working extension code and installer compatibility.
- Do not duplicate Titan Risk, Autonomy, Signal, Rewind or Command Bus engines.
- tenant_company_id is the canonical tenant boundary.
- AI must not directly mutate authoritative CRM state.
- External side effects remain idempotent and post-commit.
- No unrestricted hidden chain-of-thought storage.

---

### Task 1: Alpha.21 regression gate
**Files:** Create `bin/verify-v130-alpha21-integrity-governance.php`; modify `bin/verify.php`.
- [ ] Write alpha.21 static verifier for all new files/schema/contracts.
- [ ] Run it and confirm failure before implementation.
- [ ] Add it to the master verifier after implementation.

### Task 2: Schema hardening
**Files:** Create `database/migrations/2026_08_11_000031_harden_crm_integrity_governance.php`.
- [ ] Add Signal dedup/retry/dead-letter metadata and indexes.
- [ ] Add receipt duration/affected/integrity/remediation columns to capability operations.
- [ ] Add AI/read-model version audit fields where needed.
- [ ] Add provider payment replay support/index safeguards.
- [ ] Add rate-limit and import-report persistence tables.

### Task 3: Explicit AI projections
**Files:** Create `System/ReadModels/CrmAiProjectionRegistry.php`; modify `CrmAiReadModelService.php` and provider.
- [ ] Define named, versioned projection field lists.
- [ ] Reject unknown projection/version combinations.
- [ ] Select only declared fields from tenant-scoped tables.
- [ ] Remove tenant/internal relationship identifiers from envelopes.

### Task 4: Tenant reference guard + invariants
**Files:** Create `System/Governance/CrmTenantReferenceGuard.php`; modify executor/invariant service/provider.
- [ ] Map known public-id relationship keys to tenant-owned tables.
- [ ] Reject references that do not exist in the active tenant.
- [ ] Emit structured invariant violation records into Signal outbox for guarded failures.

### Task 5: Payment provider replay safety
**Files:** Modify `SalesPaymentService.php`, `PaymentReconciliationService.php`.
- [ ] Normalize provider/provider_reference inputs.
- [ ] Return original payment when exact provider replay occurs.
- [ ] Reject reused provider reference with mismatched invoice/amount/currency.

### Task 6: Receipt + concurrency v2
**Files:** Create `System/Governance/CrmConcurrencyException.php`; modify receipt factory, executor, operation store, concurrency guard.
- [ ] Measure command execution duration.
- [ ] Calculate affected_count and receipt_integrity_hash.
- [ ] Return version_hint.
- [ ] Throw structured concurrency exception containing expected/current version and state hash.

### Task 7: Signal delivery reliability
**Files:** Create `System/Governance/CrmDomainSignalDispatcher.php`, `System/Console/DeliverCrmDomainSignalsCommand.php`; modify publisher/provider/service provider/config.
- [ ] Generate deterministic event_dedup_key.
- [ ] Claim due rows atomically.
- [ ] Mark delivered/retry/dead-letter with exponential backoff.
- [ ] Register CLI command.

### Task 8: Automation governance
**Files:** Modify `CrmAutomationEngine.php`, service provider/config.
- [ ] Convert automation actions into CRM capability requests through `CrmCommandBusGateway`.
- [ ] Carry causation/idempotency context.
- [ ] Enforce recursion depth/chain fingerprint.
- [ ] Support simulation without mutation.

### Task 9: AI/Chatbot write rate limiting
**Files:** Create `System/Governance/CrmCapabilityRateLimiter.php`; modify command gateway/provider/config.
- [ ] Apply only to AI/chatbot/automation sources by default.
- [ ] Bucket by tenant + actor/source + capability.
- [ ] Return explicit retry-after information on limit breach.

### Task 10: Import integrity v2
**Files:** Create `System/Import/CrmImportRelationshipValidator.php`; modify `CrmImportBatchService.php`; add capability/read route if existing patterns permit.
- [ ] Build impact summary for dry run.
- [ ] Validate public-id relationships tenant-locally.
- [ ] Execute actual batch domain mutations inside one transaction.
- [ ] Persist report for seven-day retrieval.

### Task 11: Release metadata and verification
**Files:** Update changelog/report, `extension.json`, `extension.manifest.json`, `FILE-SHA256.json`.
- [ ] Run alpha.21 verifier.
- [ ] Run full master verifier.
- [ ] Run full PHP syntax scan.
- [ ] Regenerate integrity manifests.
- [ ] Package ZIP and verify from clean extraction.
