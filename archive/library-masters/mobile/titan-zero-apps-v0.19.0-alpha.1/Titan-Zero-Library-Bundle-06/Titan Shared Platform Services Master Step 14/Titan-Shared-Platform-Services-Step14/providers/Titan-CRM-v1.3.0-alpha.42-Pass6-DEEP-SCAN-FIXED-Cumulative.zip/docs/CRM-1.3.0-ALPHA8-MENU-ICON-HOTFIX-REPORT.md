# CRM 1.3.0-alpha.8 Menu Icon Hotfix

## Root cause
MagicAI renders the `menus.icon` value as a Blade component. CRM alpha.7 persisted `tabler-arrows-transfer-up-down` for Import / Export, but that component is unavailable on the live Titan Zero host, causing navbar rendering to fail globally.

## Fix
- Replaced the unsupported Import / Export icon in current and legacy CRM menu definitions.
- Added a host-safe icon allowlist to `CrmMenuInstaller`.
- Unsupported future CRM icon names fall back to `tabler-folders`, which is already used successfully by the live Titan/MagicAI menu stack.
- Added migration `2026_08_09_000023_alpha8_repair_crm_menu_icons.php` so existing persisted menu rows are repaired automatically during upgrade.

## Safety
The migration intentionally does not restore unsafe icons in `down()`, because reintroducing an unsupported component can crash the navbar.
