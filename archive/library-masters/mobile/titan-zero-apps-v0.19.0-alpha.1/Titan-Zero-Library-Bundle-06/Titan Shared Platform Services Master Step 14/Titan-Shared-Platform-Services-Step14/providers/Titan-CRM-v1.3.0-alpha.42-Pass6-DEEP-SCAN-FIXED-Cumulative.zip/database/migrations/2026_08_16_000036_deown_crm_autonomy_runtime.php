<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // CRM Core no longer owns autonomy UI/runtime. Existing autonomy/learning
        // data tables are intentionally retained until receiving-engine import
        // receipts are verified; this migration performs no destructive data drop.
        if (Schema::hasTable('menus') && Schema::hasColumn('menus','key') && Schema::hasColumn('menus','is_active')) {
            DB::table('menus')->whereIn('key',['crm_autonomy_learning','crm_autonomy_control'])->update([
                'is_active'=>0,
                'updated_at'=>now(),
            ]);
        }
    }

    public function down(): void
    {
        // De-ownership is intentionally not reversed. Re-enabling CRM-owned
        // autonomy would recreate a competing authority engine.
    }
};
