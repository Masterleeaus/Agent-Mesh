# Titan CRM 1.3.0-alpha.20 — Outbound Effect Safety Report

## Why this pass exists

Alpha.19 governed AI-originated CRM writes, but invoice email delivery still performed an external provider call inside the same database transaction that created the authoritative command receipt. A provider could succeed and the database transaction could later fail, allowing a retry to send a duplicate communication.

Alpha.20 separates **authoritative CRM truth** from **real-world communication execution**.

## Final flow

For `crm.invoice.send` and `crm.invoice.reminder.send`:

1. Command Bus/CRM capability authorization resolves `tenant_company_id` and trace context.
2. CRM validates the invoice lifecycle, recipient, invariants, expected version and command idempotency.
3. CRM inserts one tenant/idempotency-scoped communication intent in `crm_notification_outbox` inside the authoritative transaction.
4. CRM creates the command receipt and attaches its command/receipt/trace IDs to the outbox row.
5. Titan Signal receives the CRM command event through `crm_domain_signal_outbox`.
6. The transaction commits.
7. A post-commit delivery worker claims the intent.
8. `CrmCommunicationExecutionPort` executes the actual channel/provider operation. Titan Connect is the intended integrated implementation.
9. Provider outcome is persisted as delivered/deferred/failed with provider receipt metadata.
10. A communication lifecycle Signal event records the real-world effect result.

## Safety properties

- No Laravel mail/provider call remains in `SalesDocumentDeliveryService`.
- Duplicate governed commands generate one communication intent per tenant/idempotency key.
- Terminal delivered effects are not re-sent by the CRM worker.
- Provider success is never inferred from command acceptance.
- Trace/correlation/causation survive from CRM command to external-effect outcome.
- Titan Connect can replace the compatibility adapter through a single port binding.

## Compatibility

Existing sales email/reminder views and PDF generation are preserved inside `CrmLegacyMailCommunicationAdapter`. Standalone deployments can opt into that adapter, while governed Titan deployments can bind Titan Connect.

The default driver is `deferred`, deliberately preferring a queued truthful state over an ungoverned provider send when Titan Connect is absent.

## Remaining cross-extension work

Exactly-once provider delivery across a process crash requires the bound communication provider/Titan Connect adapter to honor the supplied outbound-effect idempotency key or provide equivalent provider-side deduplication. The CRM layer now supplies and persists that key; it does not pretend Laravel mail itself provides provider-level exactly-once semantics.
