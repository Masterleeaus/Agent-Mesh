# Titan Connect v0.7.0 Production Readiness

v0.7 does not add another communications channel. It hardens the existing v0.6 runtime for day-to-day operation and real-host certification.

## Company-aware rate limits

Authenticated mutation-heavy endpoints use `EnforceCompanyRateLimit`. Keys are derived from the configured bucket plus authenticated `company_id` and actor ID. The browser cannot choose either boundary value. Default buckets are `send`, `admin`, `upload`, `ai` and `voice`; all are configurable under `titan-connect.rate_limits`.

Public provider webhooks are intentionally not behind this authenticated limiter. Their trust controls remain signature verification, connection-derived company scope, replay protection and persisted idempotency.

## Connection diagnostics

Owners/admins can inspect manageable connections without receiving provider credentials. Diagnostics include connection status, whether encrypted credentials are configured, active member count, queued deliveries, failed deliveries in the past day, failed webhooks in the past day and last health/inbound/outbound timestamps.

The inbox connection manager and `/dashboard/titan-connect/settings` consume these company-scoped diagnostics.

## Voice runtime

Migration `000005` adds nullable `client_event_id` to voice transcripts with a company/call/event unique key. Browser transcript events now send stable client event IDs so reconnect/replay is idempotent. Ended calls reject new transcript/session activity, duplicate active calls for the same actor/context are blocked, and the browser exposes elapsed time, mute/unmute and idempotent end handling.

## Host readiness

`php artisan titan-connect:diagnose` checks deployment prerequisites and never prints provider secrets. Use `--json` for CI/staging automation.
