<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers\TeamChat;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversationParticipant;
use App\Extensions\TitanConnect\System\Security\ConversationAccess;
use App\Extensions\TitanConnect\System\Services\TeamChat\TeamMembershipService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class TeamMembershipController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly ConversationAccess $access,
    ) {
    }

    public function store(Request $request, TeamConversation $conversation, TeamMembershipService $service): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->access->assertMember($conversation, $companyId, $actorId);
        $data = $request->validate(['user_id' => ['required', 'integer'], 'role' => ['nullable', 'in:admin,moderator,member']]);
        return response()->json($service->add($conversation, $actorId, (int) $data['user_id'], $data['role'] ?? 'member'), 201);
    }

    public function update(Request $request, TeamConversation $conversation, TeamConversationParticipant $participant, TeamMembershipService $service): JsonResponse
    {
        $actorId = $this->context->actorId($request);
        $this->access->assertMember($conversation, $this->context->companyId($request), $actorId);
        $data = $request->validate(['role' => ['required', 'in:admin,moderator,member']]);
        return response()->json($service->changeRole($conversation, $actorId, $participant, $data['role']));
    }

    public function destroy(Request $request, TeamConversation $conversation, TeamConversationParticipant $participant, TeamMembershipService $service): JsonResponse
    {
        $actorId = $this->context->actorId($request);
        $this->access->assertMember($conversation, $this->context->companyId($request), $actorId);
        $service->remove($conversation, $actorId, $participant);
        return response()->json(['status' => 'success']);
    }
}
