<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Retention;
use App\Extensions\TitanRewind\System\Models\RewindCase;
use App\Extensions\TitanRewind\System\Models\RewindCaseTrace;
use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use App\Extensions\TitanRewind\System\Models\RewindLegalHold;
final class RewindLegalHoldGuard
{
 public function assertPurgeAllowed(int $tenantCompanyId,string $scopeType,string $scopeId): void
 {
  $base=RewindLegalHold::query()->where('tenant_company_id',$tenantCompanyId)->where('status','active')->where(static function($q):void{$q->whereNull('expires_at')->orWhere('expires_at','>',now());});
  $blocked=(clone $base)->where('scope_type',$scopeType)->where('scope_id',$scopeId)->exists()||(clone $base)->where('scope_type','tenant-investigation')->exists();
  if($scopeType==='trace'){
   $caseIds=RewindCaseTrace::query()->where('tenant_company_id',$tenantCompanyId)->where('trace_id',$scopeId)->pluck('case_id')->all();
   $primary=RewindCase::query()->where('tenant_company_id',$tenantCompanyId)->where('primary_trace_id',$scopeId)->pluck('id')->all();
   $caseIds=array_values(array_unique(array_merge($caseIds,$primary)));
   if($caseIds!==[]){$caseUuids=RewindCase::query()->where('tenant_company_id',$tenantCompanyId)->whereIn('id',$caseIds)->pluck('case_uuid');if($caseUuids->isNotEmpty()&&(clone $base)->where('scope_type','case')->whereIn('scope_id',$caseUuids)->exists())$blocked=true;}
   $packages=RewindEvidencePackage::query()->where('tenant_company_id',$tenantCompanyId)->where('trace_id',$scopeId)->pluck('package_uuid');
   if($packages->isNotEmpty()&&(clone $base)->where('scope_type','evidence-package')->whereIn('scope_id',$packages)->exists())$blocked=true;
  }
  if($scopeType==='evidence-package'){
   $package=RewindEvidencePackage::query()->where('tenant_company_id',$tenantCompanyId)->where('package_uuid',$scopeId)->first();
   if($package&&$package->trace_id){$trace=(string)$package->trace_id;if((clone $base)->where('scope_type','trace')->where('scope_id',$trace)->exists())$blocked=true;
    $caseIds=array_values(array_unique(array_merge(RewindCaseTrace::query()->where('tenant_company_id',$tenantCompanyId)->where('trace_id',$trace)->pluck('case_id')->all(),RewindCase::query()->where('tenant_company_id',$tenantCompanyId)->where('primary_trace_id',$trace)->pluck('id')->all())));
    if($caseIds!==[]){$caseUuids=RewindCase::query()->where('tenant_company_id',$tenantCompanyId)->whereIn('id',$caseIds)->pluck('case_uuid');if($caseUuids->isNotEmpty()&&(clone $base)->where('scope_type','case')->whereIn('scope_id',$caseUuids)->exists())$blocked=true;}
   }
  }
  if($blocked)throw new RewindLegalHoldException('Titan Rewind purge blocked by active legal hold.');
 }
}
