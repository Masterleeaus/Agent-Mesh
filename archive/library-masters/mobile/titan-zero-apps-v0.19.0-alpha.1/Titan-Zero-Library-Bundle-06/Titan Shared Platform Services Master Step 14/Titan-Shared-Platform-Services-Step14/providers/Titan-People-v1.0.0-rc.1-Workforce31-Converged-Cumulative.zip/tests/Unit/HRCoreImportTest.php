<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$files = ['System/Import/HRCoreImportReport.php','System/Import/HRCoreLegacyImportService.php'];
foreach ($files as $file) $t->assert(is_file($root.'/'.$file), "missing {$file}");
if (is_file($root.'/'.$files[0]) && is_file($root.'/'.$files[1])) {
    foreach ($files as $file) require_once $root.'/'.$file;
    $service = new App\Extensions\TitanPeople\System\Import\HRCoreLegacyImportService();
    $source = [
        'employees' => [['id' => 1, 'name' => 'A']],
        'departments' => [['id' => 10, 'name' => 'Ops']],
        'designations' => [['id' => 11, 'name' => 'Lead']],
        'teams' => [['id' => 12, 'name' => 'Field']],
        'lifecycle' => [['id' => 13, 'user_id' => 1, 'state' => 'active']],
        'attendance' => [['id' => 90]],
        'shifts' => [['id' => 91]],
        'expenses' => [['id' => 92]],
        'bank_accounts' => [['id' => 93]],
    ];
    try {
        $service->import($source, []);
        $t->assert(false, 'legacy import without explicit tenant mapping must fail');
    } catch (InvalidArgumentException) {
        $t->assert(true, 'legacy import requires mapping');
    }
    $report = $service->import($source, ['tenant_company_id' => 77, 'source' => 'HRCore']);
    $t->same(77, $report->tenantCompanyId, 'import tenant');
    $t->assert(in_array('attendance', $report->excludedSlices, true), 'attendance must be excluded');
    $t->assert(in_array('shifts', $report->excludedSlices, true), 'shifts must be excluded');
    $t->assert(in_array('expenses', $report->excludedSlices, true), 'expenses must be excluded');
    $t->assert(in_array('bank_accounts', $report->excludedSlices, true), 'bank accounts must be excluded');
    $again = $service->import($source, ['tenant_company_id' => 77, 'source' => 'HRCore']);
    $t->same($report->idempotencyKey, $again->idempotencyKey, 'legacy import idempotency');
}
$t->finish('HRCore legacy import boundary');
