<?php

declare(strict_types=1);
$tt=__DIR__; $package=dirname(dirname($tt)); $fail=[];
function v4(bool $ok,string $label):void{global $fail; echo ($ok?'PASS: ':'FAIL: ').$label."\n"; if(!$ok)$fail[]=$label;}
function files4(string $root,string $suffix):array{$out=[];$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));foreach($it as $f)if($f->isFile()&&str_ends_with($f->getFilename(),$suffix))$out[]=$f->getPathname();sort($out);return $out;}
function rel4(string $p,string $root):string{return str_replace('\\','/',substr($p,strlen(rtrim($root,DIRECTORY_SEPARATOR))+1));}
function lint4(string $p):bool{$o=[];exec(escapeshellarg(PHP_BINARY).' -l '.escapeshellarg($p).' 2>&1',$o,$c);return $c===0;}

passthru(escapeshellarg(PHP_BINARY).' '.escapeshellarg($package.'/TitanZeroAssurance/Tests/run.php'),$c1);v4($c1===0,'Pass 1 assurance suite');
passthru(escapeshellarg(PHP_BINARY).' '.escapeshellarg($package.'/QualityControl/Tests/Pass2CanonicalQualityTest.php'),$c2);v4($c2===0,'Pass 2 quality suite');
passthru(escapeshellarg(PHP_BINARY).' '.escapeshellarg($package.'/feedback/CustomerFeedback/Tests/Pass3FeedbackConvergenceTest.php'),$c3);v4($c3===0,'Pass 3 feedback suite');
passthru(escapeshellarg(PHP_BINARY).' '.escapeshellarg($tt.'/Tests/Pass4EvidenceConvergenceTest.php'),$c4);v4($c4===0,'Pass 4 evidence convergence suite');

$focusFail=[];foreach(files4($tt,'.php') as $p)if(!lint4($p))$focusFail[]=rel4($p,$package);v4($focusFail===[],'all TitanTrust PHP lints cleanly');foreach($focusFail as $p)echo "  $p\n";
$baseline=is_file($package.'/TitanZeroAssurance/PASS5_LEGACY_PHP_LINT_BASELINE.txt')?$package.'/TitanZeroAssurance/PASS5_LEGACY_PHP_LINT_BASELINE.txt':$tt.'/PASS4_LEGACY_PHP_LINT_BASELINE.txt';$expected=array_values(array_filter(array_map('trim',file($baseline)?:[])));sort($expected);$actual=[];$php=files4($package,'.php');foreach($php as $p)if(!lint4($p))$actual[]=rel4($p,$package);sort($actual);v4($actual===$expected,'whole-package lint matches exact Pass 4 legacy baseline');
$jsonFail=[];$json=files4($package,'.json');foreach($json as $p){try{json_decode((string)file_get_contents($p),true,512,JSON_THROW_ON_ERROR);}catch(Throwable $e){$jsonFail[]=rel4($p,$package);}}v4($jsonFail===[],'all JSON files parse');
$o=[];exec('unzip -tqq '.escapeshellarg($package.'/LegacyDonors/TitanTrust-Nested-Pass3-Source.zip').' 2>&1',$o,$zc);v4($zc===0,'nested TitanTrust donor archive integrity');
$runtime='';foreach(files4($tt,'.php') as $p){if(str_contains(str_replace('\\','/',$p),'/Tests/') || str_starts_with(basename($p),'VERIFY_PASS'))continue;$runtime.=(string)file_get_contents($p);}v4(!str_contains($runtime,'tenant_company_id'),'TitanTrust introduces no tenant_company_id');v4(!preg_match('/company[_ ]?id\s*\?\?\s*\$?(?:user|userId)/i',$runtime),'TitanTrust has no user-id-as-company fallback');
echo "\nSUMMARY\nPHP files: ".count($php)."\nLegacy PHP failures: ".count($actual)."\nJSON files: ".count($json)."\n";
if($fail){echo 'PASS4_VERIFY: FAIL ('.count($fail).")\n";exit(1);}echo "PASS4_VERIFY: PASS\n";
