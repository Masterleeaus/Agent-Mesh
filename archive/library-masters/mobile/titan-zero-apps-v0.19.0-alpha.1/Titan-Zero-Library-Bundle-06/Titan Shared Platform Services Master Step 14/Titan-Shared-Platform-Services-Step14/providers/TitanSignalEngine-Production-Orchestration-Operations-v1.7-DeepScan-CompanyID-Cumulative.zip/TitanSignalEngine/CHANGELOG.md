## Persistent orchestration v1.5

- Added durable outbox, lease recovery, deduplication, retry/dead-letter/redrive, provider deferral and health telemetry for Workforce handoffs.


## Runtime hardening pass
- Added container-bound Workforce loop runtime with fail-closed provider health aggregation.
- Enforced canonical `company_id` plus full causal context on cross-extension handoffs.
- Added provider/version pinning and authority-neutral handoff envelopes.
- Enforced outcome lineage and execution receipts.
- Quarantined raw host-menu database access as legacy navigation compatibility only.

## 0.20.0-rc.8.1 — Blade Shared Error-Bag Hotfix

- Fixes `Call to a member function any() on int` in MagicAI `panel.layout.app` caused by the rc.8 Overview assigning the numeric Signal error count to Laravel's shared `$errors` ViewErrorBag variable.
- Renames the Signal metric local to `$errorCount`.
- Uses a fresh `admin-rc8-1` Blade namespace to prevent stale compiled rc.8 child templates from replaying the bad assignment.
- Adds regression coverage across all eight Super Admin pages preventing future `$errors` assignment collisions.
- No migration or runtime contract changes.

## 0.20.0-rc.8 — Super Admin Console Information Architecture and Card UI

- Converts Signal Engine into a Super Admin dropdown parent with eight child surfaces: Overview, Pulse and Health, Events and Traces, Anomalies, Deliveries and DLQ, Lifecycle and Archives, Registries, and Diagnostics.
- Adds a compact scope/window filter that only exposes tenant company ID in tenant scope.
- Moves destructive controls off the overview and onto their governed operational pages.
- Adds authoritative registry read models and live host-certification diagnostics without bypassing Signal contracts.
- Self-heals all child `menus.parent_id` relationships and certifies the parent plus eight children.
- Uses host-safe menu labels without ampersands to avoid Website1408 `&amp;` rendering.

## 0.20.0-rc.7 — Blade Compiled-Cache Isolation Hotfix

- Keeps Signal Engine in Super Admin only.
- Renders through versioned `admin-rc7` / `index-rc7` Blade source paths so stale compiled rc.5 views cannot be reused.
- Target-cleans only legacy Signal compiled views that still contain `layouts.app`; does not globally clear Titan compiled views.
- No database migration or Signal runtime semantics change.

## 0.20.0-rc.6 — Super Admin Placement & MagicAI Blade Layout Hotfix

- Moves Signal Engine operational navigation out of the ordinary user sidebar and into Super Admin only.
- Removes the stale `titan_signal_pulse` host menu row on upgrade/self-heal.
- Repairs the Super Admin row into Website1408's 900+ band with the proven host extension marker.
- Converts all Signal Blade views from missing `<x-layouts.app>` to `@extends('panel.layout.app')`.
- Extends host certification to require the Super Admin menu row and no longer require a user menu row.

## 0.20.0-rc.6 — Self-Healing Host Navigation Hotfix

- Fixed installed Signal Engine exposing no navigation because rc.4 declared navigation classes/Blueprint contributions but never registered them with the host.
- Added modern `MenuContributionRegistry` / `ContributionRegistry` registration for user and Super Admin surfaces.
- Added idempotent MagicAI/Website1408 `menus` table self-healing with `extension = NULL`, active-state preservation, Super Admin 900+ order-band repair and `MenuService::regenerate()` cache refresh.
- Added migration 20 so already-installed rc.4 hosts receive durable menu rows during upgrade, plus `php artisan titan:signal:host-sync` for explicit repair.
- Added host certification failure when required Signal menu rows are missing, inactive, plan-gated, routed incorrectly or outside the Super Admin order band.

## 0.20.0-rc.4 — Migration Index Collision Hotfix

- Removed redundant migration-13 `tsd_subscriber_status_idx` creation; migration 6 already owns the covering `(subscriber_key, status, available_at)` index.
- Removed migration-13 rollback of that foundational index so rolling back migration 13 cannot delete migration 6 schema.
- Added whole-chain duplicate index-name regression coverage.
- Fixes Installer 1.7.8 migration failure `SQLSTATE[42000] 1061 Duplicate key name tsd_subscriber_status_idx` observed after 12 recorded migrations.

## 0.20.0-rc.3 — MySQL Strict Timestamp Migration Compatibility Hotfix

- Replaced 25 required application `TIMESTAMP` columns without explicit defaults with `DATETIME` across migrations 7–18.
- Fixes Installer 1.7.8 migration failure `SQLSTATE[42000] 1067 Invalid default value for projected_at` observed on the production host.
- Added a migration-contract regression test preventing future required implicit-default `TIMESTAMP` columns.
- No runtime event, capability, queue, retention, or API behavior changes.

## 0.20.0-rc.2 — Installer 1.7.8 Provider Contract Namespace Hotfix

- Corrected service-provider imports to the Marketplace contract namespace used by Titan Installer 1.7.8 / MagicAI host.
- Added deployment-stage provider-load regression test reproducing Installer `require_once` behavior.
- No database schema or capability behavior changes.

## 0.20.0-rc.1 — Production Host Certification RC

- Added Installer 1.7.8 root manifest contract and live `titan:signal:certify` host certification.
- Added machine-readable release-candidate certification status and host runbook.
- Production-host certification remains pending until executed on the supported Laravel/MySQL host.

# Changelog

## 0.19.0 — Production Hardening Pass 11: Runtime Drift, Console & Configuration Hardening

- Sanitized Signal Console exceptions into user-safe reference codes with server-side structured logging.
- Decoupled historical foundation migration checksum/idempotency backfills from current runtime classes.
- Added Blueprint user/admin navigation contributions for Signal & Pulse.
- Removed decorative configuration and wired retained queue/recovery/rollout/bounding settings into runtime behavior.
- Reworked bounded console/registry/anomaly/archive/correlation reads to use cursors/chunks where appropriate.
- Reduced Blueprint architecture review warnings while retaining bounded transactional lifecycle snapshots.

## 0.18.0 — Production Hardening Pass 10: Immutable Anomaly Decisions & Operational Audit

- Added immutable `signal.anomaly.acknowledged`, `.suppressed`, `.resolved`, and `.reopened` events.
- Added anomaly decision generations, `last_decision_event_id`, and transactional fail-closed lifecycle auditing.
- Added governed reason capture for acknowledgement and automatic reason codes for trace recovery/recurrence.
- Added `signal.anomaly.manage` Blueprint capability contract and versioned event schemas.
- Added standalone and host-runtime regression coverage for anomaly decision audit behavior.

## 0.17.0 — Production Hardening Pass 9: Pulse, Health & Backpressure Correctness

- Added tenant/system/source-specific Pulse projection freshness.
- Added per-command execution receipt pairing and latency projections for traces containing multiple commands.
- Added scheduled/cached operational health snapshots separating current degradation from bounded 30-day incident history.
- Updated readiness and global health to consume maintained projections instead of repeated growing global scans.
- Added explicit current-pressure and historical-incident sections to backpressure snapshots.

## 0.16.0 — Production Hardening Pass 8: Automatic Trace Evaluation & Sequence Detection

- Added durable automatic trace/profile assignments and active profile event matching.
- Added post-ingestion plus scheduled trace evaluation with late/offline repair.
- Added evaluation freshness/history completeness metadata.
- Added terminal-only missing-required-event anomaly detection and automatic recovery resolution.
- Added `titan:signal-traces:evaluate` clustered-safe scheduler.

## 0.15.0 — Production Hardening Pass 7: Hot/Cold Correlation & Rewind Continuity

- Made Correlation/Rewind history-tier aware using verified archive catalog entries plus hot events.
- Added cold causation lookup/index and mixed-tier ancestor/descendant reconstruction.
- Added storage-tier edge metadata, hot/cold event counts and Rewind storage/integrity receipts.
- Added partial-history protection when a required archive batch is unavailable or fails integrity verification.
- Added host and standalone mixed-tier regression coverage.

## 0.14.0 — Production Hardening Pass 6: Transactional Pruning & Streaming Archives

- Replaced boolean prune confirmation with persisted exact-set preview manifests and one-time preview tokens.
- Added SHA-256 candidate-set hashes, atomic lifecycle claims, preview execution leases and resumable verified-unpruned batches.
- Added bounded-memory gzip archive write/read paths using Laravel storage streams and temporary files.
- Enforced exact approved-set deletion counts and honored retention classes where archive is not required.
- Added prune claim/preview housekeeping and additive transactional-pruning migration.

## 0.13.0 — Production Hardening Pass 5: Archive Read & Cold History

- Added verified archive read, metadata, batch, event and bounded stream APIs.
- Added `titan_signal_archive_catalog` with tenant-safe event/trace/correlation/root-causation indexes.
- Added `SignalHistoryQueryContract` for governed hot/cold history retrieval.
- Added cold lifecycle/event inspection and archive-driver continuity across configuration changes.
- Added `titan:signal-archive:catalog` for idempotent catalog rebuild of verified pre-v0.13 archives.

## 0.12.0 — Production Hardening Pass 4: DLQ Recovery & Backpressure Repair

- Added governed single/batch dead-letter redrive with immutable redrive audit records.
- Added registry revision/cache coherence for long-running workers.
- Split current/recent delivery pressure from unresolved and resolved historical DLQ counts.
- Scoped backpressure-aware source throttling by tenant/source and added delivery source projections.
- Added console/CLI recovery controls and `signal.subscription.redriven` telemetry.

## 0.11.0 — Production Hardening Pass 3: Atomic Subscriber Delivery

- Added atomic compare-and-set delivery leases with worker identity, expiry, and claim generations.
- Stale/expired workers can no longer overwrite delivered, retry, or dead-letter state.
- Added queue execution tokens, crash-safe expired-lease recovery, and stable subscriber idempotency keys.
- Added additive delivery-lease migration and concurrency regression coverage.

## 0.10.0 — Production Hardening Pass 2: Registry Governance

- Added host-attested registry identities and ownership policy.
- Replaced mutable event-type registration with immutable versioned definitions.
- Replaced mutable subscription registration with immutable versioned definitions plus runtime quarantine state.
- Added authenticated event-family/subscriber-key ownership, explicit evolution APIs, history APIs, uninstall/revalidation lifecycle, and legacy backfill.
- Broken subscriber handlers are quarantined and skipped rather than throwing through Signal ingestion.


## 0.9.1 — Blueprint v4 Signal alignment

- Upgraded `extension.manifest.json` to production schema 2.0.
- Declared `titan-governed-engine` runtime profile.
- Added versioned capability contract schemas.
- Added liveness/readiness health and trace-context adapters.
- Named and clustered-safe scheduled tasks.
- Added Blueprint-required operations/security/DR/governance documentation.
- Added localization catalog and supply-chain metadata generation hooks.

## 0.9.0

- Added trusted execution context and host-attested emitter identity.
