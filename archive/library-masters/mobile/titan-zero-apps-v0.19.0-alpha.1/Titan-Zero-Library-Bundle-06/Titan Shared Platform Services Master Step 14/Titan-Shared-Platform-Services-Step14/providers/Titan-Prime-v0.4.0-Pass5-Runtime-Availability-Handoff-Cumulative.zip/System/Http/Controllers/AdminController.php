<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Http\Controllers;

use Illuminate\Contracts\View\View;

final class AdminController
{
    public function __invoke(): View
    {
        return view('titan-prime::admin');
    }
}
