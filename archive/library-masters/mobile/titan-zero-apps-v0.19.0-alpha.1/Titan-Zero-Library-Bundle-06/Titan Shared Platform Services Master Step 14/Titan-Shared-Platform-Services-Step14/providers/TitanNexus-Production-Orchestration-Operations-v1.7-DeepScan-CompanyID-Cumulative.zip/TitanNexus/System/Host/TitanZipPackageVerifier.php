<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Host;

use RuntimeException;

final class TitanZipPackageVerifier
{
    /** @return array{valid:bool,errors:list<string>,entries:int,integrity_files:int} */
    public static function verify(string $package): array
    {
        $errors = [];
        if (!is_file($package)) {
            return ['valid' => false, 'errors' => ['package file does not exist'], 'entries' => 0, 'integrity_files' => 0];
        }
        if (strtolower(pathinfo($package, PATHINFO_EXTENSION)) !== 'zip') {
            return ['valid' => false, 'errors' => ['package must use .zip extension'], 'entries' => 0, 'integrity_files' => 0];
        }

        $blob = file_get_contents($package);
        if (!is_string($blob) || strlen($blob) < 22 || substr($blob, 0, 2) !== 'PK') {
            return ['valid' => false, 'errors' => ['invalid ZIP signature'], 'entries' => 0, 'integrity_files' => 0];
        }

        try {
            $entries = self::readEntries($blob);
        } catch (RuntimeException $e) {
            return ['valid' => false, 'errors' => [$e->getMessage()], 'entries' => 0, 'integrity_files' => 0];
        }

        foreach (['extension.json', 'extension.manifest.json'] as $required) {
            if (!array_key_exists($required, $entries)) {
                $errors[] = "required flat-root entry missing: {$required}";
            }
        }

        $integrityCount = 0;
        if (isset($entries['extension.json'])) {
            try {
                $extension = json_decode($entries['extension.json'], true, 512, JSON_THROW_ON_ERROR);
                $expected = $extension['integrity']['files'] ?? null;
                if (!is_array($expected)) {
                    $errors[] = 'extension.json integrity.files must be an object';
                } else {
                    $actual = [];
                    foreach ($entries as $path => $contents) {
                        if ($path === 'extension.json' || str_ends_with($path, '/')) {
                            continue;
                        }
                        $actual[$path] = hash('sha256', $contents);
                    }
                    ksort($actual, SORT_STRING);
                    ksort($expected, SORT_STRING);
                    $integrityCount = count($expected);
                    if ($expected !== $actual) {
                        $errors[] = 'Installer integrity.files does not exactly match ZIP contents';
                    }
                }
            } catch (\JsonException) {
                $errors[] = 'extension.json is not valid JSON';
            }
        }

        return [
            'valid' => $errors === [],
            'errors' => $errors,
            'entries' => count($entries),
            'integrity_files' => $integrityCount,
        ];
    }

    /** @return array<string,string> */
    private static function readEntries(string $blob): array
    {
        $length = strlen($blob);
        $tailStart = max(0, $length - 65557);
        $tail = substr($blob, $tailStart);
        $relativeEocd = strrpos($tail, "PK\x05\x06");
        if ($relativeEocd === false) {
            throw new RuntimeException('ZIP end-of-central-directory record missing');
        }
        $eocd = $tailStart + $relativeEocd;
        if ($eocd + 22 > $length) {
            throw new RuntimeException('truncated ZIP end-of-central-directory record');
        }
        $meta = unpack('vdisk/vcd_disk/vdisk_entries/ventries/Vcd_size/Vcd_offset/vcomment_len', substr($blob, $eocd + 4, 18));
        if (!is_array($meta) || $meta['disk'] !== 0 || $meta['cd_disk'] !== 0 || $meta['disk_entries'] !== $meta['entries']) {
            throw new RuntimeException('multi-disk ZIP packages are not supported');
        }
        if ($meta['cd_offset'] + $meta['cd_size'] > $length) {
            throw new RuntimeException('ZIP central directory is out of bounds');
        }

        $cursor = (int) $meta['cd_offset'];
        $entries = [];
        for ($i = 0; $i < (int) $meta['entries']; $i++) {
            if (substr($blob, $cursor, 4) !== "PK\x01\x02" || $cursor + 46 > $length) {
                throw new RuntimeException('invalid ZIP central-directory entry');
            }
            $head = unpack(
                'vversion_made/vversion_needed/vflags/vmethod/vmtime/vmdate/Vcrc/Vcompressed/Vuncompressed/vname_len/vextra_len/vcomment_len/vdisk_start/vinternal/Vexternal/Vlocal_offset',
                substr($blob, $cursor + 4, 42)
            );
            if (!is_array($head)) {
                throw new RuntimeException('unable to decode ZIP central-directory entry');
            }
            $nameStart = $cursor + 46;
            $name = substr($blob, $nameStart, (int) $head['name_len']);
            if ($name === '' || str_contains($name, "\0") || str_starts_with($name, '/') || str_contains($name, '\\')) {
                throw new RuntimeException('unsafe ZIP entry path');
            }
            $parts = explode('/', $name);
            if (in_array('..', $parts, true) || in_array('.', $parts, true)) {
                throw new RuntimeException("unsafe ZIP entry path: {$name}");
            }
            if (array_key_exists($name, $entries)) {
                throw new RuntimeException("duplicate ZIP entry: {$name}");
            }
            if (((int) $head['flags'] & 0x0001) !== 0) {
                throw new RuntimeException("encrypted ZIP entry is not supported: {$name}");
            }

            $cursor += 46 + (int) $head['name_len'] + (int) $head['extra_len'] + (int) $head['comment_len'];
            if (str_ends_with($name, '/')) {
                $entries[$name] = '';
                continue;
            }

            $local = (int) $head['local_offset'];
            if ($local + 30 > $length || substr($blob, $local, 4) !== "PK\x03\x04") {
                throw new RuntimeException("invalid local ZIP header for {$name}");
            }
            $localHead = unpack('vversion/vflags/vmethod/vmtime/vmdate/Vcrc/Vcompressed/Vuncompressed/vname_len/vextra_len', substr($blob, $local + 4, 26));
            if (!is_array($localHead)) {
                throw new RuntimeException("unable to decode local ZIP header for {$name}");
            }
            $dataStart = $local + 30 + (int) $localHead['name_len'] + (int) $localHead['extra_len'];
            $compressed = substr($blob, $dataStart, (int) $head['compressed']);
            if (strlen($compressed) !== (int) $head['compressed']) {
                throw new RuntimeException("truncated ZIP entry: {$name}");
            }
            $method = (int) $head['method'];
            if ($method === 0) {
                $contents = $compressed;
            } elseif ($method === 8) {
                $inflated = gzinflate($compressed);
                if (!is_string($inflated)) {
                    throw new RuntimeException("unable to inflate ZIP entry: {$name}");
                }
                $contents = $inflated;
            } else {
                throw new RuntimeException("unsupported ZIP compression method {$method}: {$name}");
            }
            if (strlen($contents) !== (int) $head['uncompressed']) {
                throw new RuntimeException("ZIP size mismatch: {$name}");
            }
            $crc = sprintf('%u', crc32($contents));
            $expectedCrc = sprintf('%u', (int) $head['crc']);
            if ($crc !== $expectedCrc) {
                throw new RuntimeException("ZIP CRC mismatch: {$name}");
            }
            $entries[$name] = $contents;
        }

        return $entries;
    }
}
