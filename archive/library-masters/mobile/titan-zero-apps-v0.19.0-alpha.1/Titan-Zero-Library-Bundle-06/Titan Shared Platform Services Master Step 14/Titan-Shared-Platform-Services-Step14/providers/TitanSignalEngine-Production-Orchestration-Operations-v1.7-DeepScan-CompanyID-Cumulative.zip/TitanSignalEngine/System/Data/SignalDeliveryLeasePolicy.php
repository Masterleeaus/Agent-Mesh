<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use DateTimeImmutable;
use InvalidArgumentException;

final readonly class SignalDeliveryLeasePolicy
{
    public function __construct(public int $ttlSeconds = 120)
    {
        if ($this->ttlSeconds < 30 || $this->ttlSeconds > 7200) {
            throw new InvalidArgumentException('Delivery lease TTL must be between 30 and 7200 seconds.');
        }
    }

    public function issue(string $deliveryId, string $workerId, DateTimeImmutable $now, int $claimVersion): SignalDeliveryLease
    {
        if ($deliveryId === '' || $workerId === '' || $claimVersion < 1) {
            throw new InvalidArgumentException('Delivery lease requires delivery, worker, and positive claim version.');
        }

        return new SignalDeliveryLease(
            $deliveryId,
            $this->newToken(),
            $workerId,
            $claimVersion,
            $now,
            $now->modify('+' . $this->ttlSeconds . ' seconds'),
        );
    }

    public function isActive(SignalDeliveryLease $lease, DateTimeImmutable $now): bool
    {
        return $now < $lease->expiresAt;
    }

    public function canFinalize(SignalDeliveryLease $lease, string $token, int $claimVersion, DateTimeImmutable $now): bool
    {
        return hash_equals($lease->token, $token)
            && $lease->claimVersion === $claimVersion
            && $this->isActive($lease, $now);
    }

    public function subscriberIdempotencyKey(string $deliveryId): string
    {
        if ($deliveryId === '') {
            throw new InvalidArgumentException('Delivery id is required.');
        }
        return 'signal-delivery:' . $deliveryId;
    }

    public function newToken(): string
    {
        $milliseconds = (int) floor(microtime(true) * 1000);
        $timeHex = str_pad(dechex($milliseconds), 12, '0', STR_PAD_LEFT);
        $random = bin2hex(random_bytes(10));
        $hex = $timeHex . $random;
        $hex[12] = '7';
        $variant = hexdec($hex[16]);
        $hex[16] = dechex(($variant & 0x3) | 0x8);
        return sprintf('%s-%s-%s-%s-%s', substr($hex, 0, 8), substr($hex, 8, 4), substr($hex, 12, 4), substr($hex, 16, 4), substr($hex, 20, 12));
    }
}
