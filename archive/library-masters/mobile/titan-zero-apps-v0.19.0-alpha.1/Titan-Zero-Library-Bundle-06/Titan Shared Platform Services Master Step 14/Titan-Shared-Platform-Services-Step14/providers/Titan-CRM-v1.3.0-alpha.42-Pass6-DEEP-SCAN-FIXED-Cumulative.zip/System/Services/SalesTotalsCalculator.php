<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Services;
use InvalidArgumentException;
final class SalesTotalsCalculator {
 public function calculate(array $lines): array {
  if($lines===[]) throw new InvalidArgumentException('At least one sales line is required.');
  $out=[];$subtotal=0;$tax=0;
  foreach($lines as $i=>$line){if(!is_array($line))throw new InvalidArgumentException("Sales line {$i} must be an object.");$qty=(int)($line['quantity_milli']??1000);$unit=(int)($line['unit_price_minor']??0);$rate=(int)($line['tax_rate_bps']??0);if($qty<1||$unit<0||$rate<0||$rate>10000)throw new InvalidArgumentException("Sales line {$i} has invalid quantity, price or tax rate.");$lineSubtotal=intdiv($qty*$unit,1000);$lineTax=intdiv(($lineSubtotal*$rate)+5000,10000);$lineTotal=$lineSubtotal+$lineTax;$subtotal+=$lineSubtotal;$tax+=$lineTax;$out[]=['description'=>trim((string)($line['description']??'Item')),'quantity_milli'=>$qty,'unit_price_minor'=>$unit,'tax_rate_bps'=>$rate,'line_subtotal_minor'=>$lineSubtotal,'line_tax_minor'=>$lineTax,'line_total_minor'=>$lineTotal,'meta'=>$line['meta']??[]];}
  return ['lines'=>$out,'subtotal_minor'=>$subtotal,'tax_minor'=>$tax,'total_minor'=>$subtotal+$tax];
 }
}
