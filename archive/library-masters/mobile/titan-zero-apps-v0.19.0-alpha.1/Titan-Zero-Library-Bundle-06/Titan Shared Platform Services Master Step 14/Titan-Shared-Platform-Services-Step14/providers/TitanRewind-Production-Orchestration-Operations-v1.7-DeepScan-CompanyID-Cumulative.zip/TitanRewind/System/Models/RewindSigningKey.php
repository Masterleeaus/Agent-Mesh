<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Models;
use Illuminate\Database\Eloquent\Model;
final class RewindSigningKey extends Model
{
 protected $table='titan_rewind_signing_keys';protected $fillable=['key_id','algorithm','status','public_key_fingerprint','activated_at','retired_at','last_used_at'];protected $casts=['activated_at'=>'datetime','retired_at'=>'datetime','last_used_at'=>'datetime'];
}
