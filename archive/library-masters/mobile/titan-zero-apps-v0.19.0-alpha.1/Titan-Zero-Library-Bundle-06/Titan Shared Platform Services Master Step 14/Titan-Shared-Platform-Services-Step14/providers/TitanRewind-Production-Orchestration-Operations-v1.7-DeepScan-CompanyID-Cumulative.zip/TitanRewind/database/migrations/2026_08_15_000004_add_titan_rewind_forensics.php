<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_rewind_trace_events')) {
            Schema::table('titan_rewind_trace_events', function (Blueprint $table): void {
                if (!Schema::hasColumn('titan_rewind_trace_events', 'canonical_hash')) $table->char('canonical_hash', 64)->nullable()->index();
                if (!Schema::hasColumn('titan_rewind_trace_events', 'chain_position')) $table->unsignedBigInteger('chain_position')->nullable()->index();
                if (!Schema::hasColumn('titan_rewind_trace_events', 'chain_previous_hash')) $table->char('chain_previous_hash', 64)->nullable();
                if (!Schema::hasColumn('titan_rewind_trace_events', 'chain_hash')) $table->char('chain_hash', 64)->nullable()->index();
                if (!Schema::hasColumn('titan_rewind_trace_events', 'integrity_checked_at')) $table->dateTime('integrity_checked_at', 6)->nullable()->index();
            });

            Schema::table('titan_rewind_trace_events', static function (Blueprint $table): void {
                $table->unique(['tenant_company_id', 'trace_id', 'chain_position'], 'trw_evt_tenant_trace_chain_pos');
            });
        }

        if (Schema::hasTable('titan_rewind_trace_index')) {
            Schema::table('titan_rewind_trace_index', function (Blueprint $table): void {
                if (!Schema::hasColumn('titan_rewind_trace_index', 'late_event_count')) $table->unsignedInteger('late_event_count')->default(0);
                if (!Schema::hasColumn('titan_rewind_trace_index', 'out_of_order_arrival_count')) $table->unsignedInteger('out_of_order_arrival_count')->default(0);
                if (!Schema::hasColumn('titan_rewind_trace_index', 'sequence_collision_count')) $table->unsignedInteger('sequence_collision_count')->default(0);
                if (!Schema::hasColumn('titan_rewind_trace_index', 'causation_orphan_count')) $table->unsignedInteger('causation_orphan_count')->default(0);
                if (!Schema::hasColumn('titan_rewind_trace_index', 'forensic_state')) $table->string('forensic_state', 40)->default('unknown')->index();
                if (!Schema::hasColumn('titan_rewind_trace_index', 'last_integrity_check_at')) $table->dateTime('last_integrity_check_at', 6)->nullable()->index();
                if (!Schema::hasColumn('titan_rewind_trace_index', 'open_drift_count')) $table->unsignedInteger('open_drift_count')->default(0);
            });
        }

        if (!Schema::hasTable('titan_rewind_integrity_checks')) {
            Schema::create('titan_rewind_integrity_checks', function (Blueprint $table): void {
                $table->id();
                $table->uuid('check_uuid')->unique();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->uuid('trace_id')->index();
                $table->string('check_type', 60)->default('event_chain');
                $table->string('status', 30)->default('running')->index();
                $table->unsignedBigInteger('checked_by_id')->nullable()->index();
                $table->unsignedBigInteger('events_checked')->default(0);
                $table->unsignedInteger('failures_count')->default(0);
                $table->unsignedInteger('unsealed_count')->default(0);
                $table->json('result')->nullable();
                $table->dateTime('started_at', 6)->nullable();
                $table->dateTime('finished_at', 6)->nullable();
                $table->timestamps();
                $table->index(['tenant_company_id', 'trace_id', 'created_at'], 'trw_integrity_tenant_trace_time');
            });
        }

        if (!Schema::hasTable('titan_rewind_drift_findings')) {
            Schema::create('titan_rewind_drift_findings', function (Blueprint $table): void {
                $table->id();
                $table->uuid('finding_uuid')->unique();
                $table->char('finding_key', 64)->unique();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->uuid('trace_id')->index();
                $table->uuid('event_id')->nullable()->index();
                $table->string('finding_type', 80)->index();
                $table->string('severity', 30)->default('medium')->index();
                $table->string('status', 30)->default('open')->index();
                $table->text('summary');
                $table->json('evidence')->nullable();
                $table->json('remediation')->nullable();
                $table->dateTime('detected_at', 6)->index();
                $table->dateTime('last_seen_at', 6)->nullable()->index();
                $table->dateTime('resolved_at', 6)->nullable();
                $table->unsignedBigInteger('resolved_by_id')->nullable();
                $table->timestamps();
                $table->index(['tenant_company_id', 'trace_id', 'status', 'severity'], 'trw_drift_tenant_trace_status');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_rewind_drift_findings');
        Schema::dropIfExists('titan_rewind_integrity_checks');

        if (Schema::hasTable('titan_rewind_trace_index')) {
            $columns = array_values(array_filter([
                'late_event_count','out_of_order_arrival_count','sequence_collision_count','causation_orphan_count',
                'forensic_state','last_integrity_check_at','open_drift_count',
            ], static fn (string $column): bool => Schema::hasColumn('titan_rewind_trace_index', $column)));
            if ($columns !== []) Schema::table('titan_rewind_trace_index', static function (Blueprint $table) use ($columns): void { $table->dropColumn($columns); });
        }

        if (Schema::hasTable('titan_rewind_trace_events')) {
            try {
                Schema::table('titan_rewind_trace_events', static function (Blueprint $table): void { $table->dropUnique('trw_evt_tenant_trace_chain_pos'); });
            } catch (\Throwable) {
            }
            $columns = array_values(array_filter([
                'canonical_hash','chain_position','chain_previous_hash','chain_hash','integrity_checked_at',
            ], static fn (string $column): bool => Schema::hasColumn('titan_rewind_trace_events', $column)));
            if ($columns !== []) Schema::table('titan_rewind_trace_events', static function (Blueprint $table) use ($columns): void { $table->dropColumn($columns); });
        }
    }
};
