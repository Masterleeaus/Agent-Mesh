<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Certification;

use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ExternalContact;
use Illuminate\Support\Str;
use Throwable;

final class CompanyIsolationProbe
{
    /** @return array{name:string,status:string,message:string} */
    public function run(): array
    {
        $connection = app('db')->connection();
        $base = random_int(2_000_000_000, 3_000_000_000);
        $companyA = $base;
        $companyB = $base + 1;

        $connection->beginTransaction();
        try {
            $channelA = ChannelConnection::query()->create([
                'uuid' => (string) Str::uuid(),
                'company_id' => $companyA,
                'provider' => 'certification',
                'display_name' => 'Certification A',
                'external_account_id' => 'cert-a-'.Str::uuid(),
                'status' => 'paused',
                'settings' => [],
            ]);
            $channelB = ChannelConnection::query()->create([
                'uuid' => (string) Str::uuid(),
                'company_id' => $companyB,
                'provider' => 'certification',
                'display_name' => 'Certification B',
                'external_account_id' => 'cert-b-'.Str::uuid(),
                'status' => 'paused',
                'settings' => [],
            ]);
            $contactA = ExternalContact::query()->create([
                'uuid' => (string) Str::uuid(),
                'company_id' => $companyA,
                'provider' => 'certification',
                'external_contact_ref' => 'contact-a-'.Str::uuid(),
                'display_name' => 'Certification A',
                'metadata' => [],
            ]);
            $contactB = ExternalContact::query()->create([
                'uuid' => (string) Str::uuid(),
                'company_id' => $companyB,
                'provider' => 'certification',
                'external_contact_ref' => 'contact-b-'.Str::uuid(),
                'display_name' => 'Certification B',
                'metadata' => [],
            ]);

            $isolated = ChannelConnection::query()->forCompany($companyA)->whereKey($channelA->getKey())->exists()
                && ! ChannelConnection::query()->forCompany($companyA)->whereKey($channelB->getKey())->exists()
                && ExternalContact::query()->forCompany($companyA)->whereKey($contactA->getKey())->exists()
                && ! ExternalContact::query()->forCompany($companyA)->whereKey($contactB->getKey())->exists();

            return [
                'name' => 'two-company-isolation',
                'status' => $isolated ? 'ok' : 'error',
                'message' => $isolated
                    ? 'Rollback-only live DB probe confirmed representative company scopes do not cross.'
                    : 'Representative company scopes crossed during the live DB probe.',
            ];
        } catch (Throwable $e) {
            return [
                'name' => 'two-company-isolation',
                'status' => 'error',
                'message' => 'Two-company certification probe failed: '.$e->getMessage(),
            ];
        } finally {
            if ($connection->transactionLevel() > 0) {
                $connection->rollBack();
            }
        }
    }
}
