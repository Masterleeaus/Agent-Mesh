<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class CrmMergeService
{
    private const TABLES=['companies'=>'crm_companies','contacts'=>'crm_contacts','leads'=>'crm_leads'];
    public function __construct(private ConnectionInterface $db,private CrmAuditRecorder $audit){}

    public function candidates(int $userId,string $resource): array
    {
        $table=self::TABLES[$resource]??throw ValidationException::withMessages(['resource'=>['Unsupported duplicate resource.']]);
        return $this->db->table($table)->where('company_id',CrmCompanyScope::companyId($userId))->whereNull('deleted_at')->where(fn($q)=>$q->whereNotNull('normalized_email')->orWhereNotNull('normalized_phone'))->get()->groupBy(fn($row)=>($row->normalized_email?:'-').'|'.($row->normalized_phone?:'-'))->filter(fn($group)=>$group->count()>1)->map(fn($group)=>$group->map(fn($row)=>(array)$row)->all())->values()->all();
    }

    public function preview(int $userId,string $resource,string $winnerPublicId,string $loserPublicId): array
    {
        [$table,$winner,$loser]=$this->pair($userId,$resource,$winnerPublicId,$loserPublicId,false);$patch=$this->patch((array)$winner,(array)$loser);
        $summary=$this->relationshipSummary(CrmCompanyScope::companyId($userId),$resource,$winner,$loser);
        return ['resource'=>$resource,'winner_public_id'=>$winnerPublicId,'loser_public_id'=>$loserPublicId,'fields_to_fill'=>$patch,'relationship_summary'=>$summary,'before_snapshot_hash'=>$this->hash(['winner'=>(array)$winner,'loser'=>(array)$loser,'relationships'=>$summary]),'rollback_reference'=>'crm-merge-preview:'.$winnerPublicId.':'.$loserPublicId,'requires_confirmation'=>true];
    }

    public function merge(int $userId,int $actorUserId,string $resource,string $winnerPublicId,string $loserPublicId): array
    {
        if($winnerPublicId===$loserPublicId)throw ValidationException::withMessages(['merge'=>['Winner and duplicate must differ.']]);
        return $this->db->transaction(function()use($userId,$actorUserId,$resource,$winnerPublicId,$loserPublicId):array{
            [$table,$winner,$loser]=$this->pair($userId,$resource,$winnerPublicId,$loserPublicId,true);$tenant=CrmCompanyScope::companyId($userId);$winnerData=(array)$winner;$loserData=(array)$loser;$patch=$this->patch($winnerData,$loserData);$summary=$this->relationshipSummary($tenant,$resource,$winner,$loser);
            $beforeHash=$this->hash(['winner'=>$winnerData,'loser'=>$loserData,'relationships'=>$summary]);$snapshotId=(string)Str::ulid();$rollbackReference='rewind:crm-merge:'.$snapshotId;
            $this->db->table('crm_merge_snapshots')->insert(['public_id'=>$snapshotId,'company_id'=>$tenant,'resource_type'=>$resource,'winner_public_id'=>$winnerPublicId,'loser_public_id'=>$loserPublicId,'winner_before'=>json_encode($winnerData),'loser_before'=>json_encode($loserData),'relationship_summary'=>json_encode($summary),'before_snapshot_hash'=>$beforeHash,'rollback_reference'=>$rollbackReference,'actor_user_id'=>$actorUserId,'created_at'=>now(),'updated_at'=>now()]);
            if($resource==='companies'){
                $this->db->table('crm_contacts')->where('company_id',$tenant)->where('customer_company_id',$loser->id)->update(['customer_company_id'=>$winner->id,'customer_unification_id'=>$winner->customer_unification_id??$loser->customer_unification_id,'updated_at'=>now()]);
                $this->db->table('crm_deals')->where('company_id',$tenant)->where('customer_company_id',$loser->id)->update(['customer_company_id'=>$winner->id,'updated_at'=>now()]);
                foreach(['proposals','estimates','invoices'] as $type)$this->db->table('crm_'.$type)->where('company_id',$tenant)->where('company_public_id',$loserPublicId)->update(['company_public_id'=>$winnerPublicId,'updated_at'=>now()]);
                $this->db->table('crm_projects')->where('company_id',$tenant)->where('company_public_id',$loserPublicId)->update(['company_public_id'=>$winnerPublicId,'updated_at'=>now()]);
            }elseif($resource==='contacts'){
                $this->db->table('crm_deals')->where('company_id',$tenant)->where('contact_id',$loser->id)->update(['contact_id'=>$winner->id,'updated_at'=>now()]);
                foreach(['proposals','estimates','invoices'] as $type)$this->db->table('crm_'.$type)->where('company_id',$tenant)->where('contact_public_id',$loserPublicId)->update(['contact_public_id'=>$winnerPublicId,'updated_at'=>now()]);
            }
            $winnerRoot=(string)($winner->customer_unification_id??'');$loserRoot=(string)($loser->customer_unification_id??'');
            if($winnerRoot!==''&&$loserRoot!==''&&$winnerRoot!==$loserRoot)$this->consolidateRoots($tenant,$winnerRoot,$loserRoot);
            if($patch!==[])$this->db->table($table)->where('id',$winner->id)->update($patch+['updated_at'=>now()]);
            foreach(['crm_activities','crm_notes','crm_taggables','crm_custom_field_values'] as $subjectTable)if($this->db->getSchemaBuilder()->hasTable($subjectTable)&&$this->db->getSchemaBuilder()->hasColumn($subjectTable,'subject_public_id'))$this->db->table($subjectTable)->where('company_id',$tenant)->where('subject_public_id',$loserPublicId)->update(['subject_public_id'=>$winnerPublicId]);
            $loserUpdate=['deleted_at'=>now(),'updated_at'=>now()];if(isset($winnerRoot)&&$winnerRoot!=='')$loserUpdate['customer_unification_id']=$winnerRoot;$this->db->table($table)->where('id',$loser->id)->update($loserUpdate);
            $after=(array)$this->db->table($table)->where('id',$winner->id)->first();$afterHash=$this->hash($after);
            $this->db->table('crm_merge_snapshots')->where('public_id',$snapshotId)->update(['after_snapshot_hash'=>$afterHash,'merged_at'=>now(),'updated_at'=>now()]);
            $this->db->table('crm_merge_log')->insert(['public_id'=>(string)Str::ulid(),'company_id'=>$tenant,'user_id'=>CrmCompanyScope::actorUserId($userId),'actor_user_id'=>$actorUserId,'resource_type'=>$resource,'winner_public_id'=>$winnerPublicId,'loser_public_id'=>$loserPublicId,'merged_fields'=>json_encode(array_keys($patch)),'snapshot_public_id'=>$snapshotId,'rollback_reference'=>$rollbackReference,'before_snapshot_hash'=>$beforeHash,'after_snapshot_hash'=>$afterHash,'merged_at'=>now()]);
            $this->audit->record($userId,$actorUserId,$resource.'.merged',$this->singularResource($resource),$winnerPublicId,$winnerData,$after,['loser_public_id'=>$loserPublicId,'rollback_reference'=>$rollbackReference,'snapshot_public_id'=>$snapshotId]);
            $singular=$this->singularResource($resource);$this->db->table('crm_duplicate_reviews')->where('company_id',$tenant)->where(function($q)use($singular,$winnerPublicId,$loserPublicId){$q->where(fn($x)=>$x->where('source_type',$singular)->where('source_public_id',$loserPublicId)->where('candidate_public_id',$winnerPublicId))->orWhere(fn($x)=>$x->where('candidate_type',$singular)->where('candidate_public_id',$loserPublicId)->where('source_public_id',$winnerPublicId));})->update(['status'=>'merged','resolution'=>json_encode(['rollback_reference'=>$rollbackReference,'snapshot_public_id'=>$snapshotId]),'resolved_by_user_id'=>$actorUserId,'resolved_at'=>now(),'updated_at'=>now()]);
            return $after+['merge_snapshot_public_id'=>$snapshotId,'rollback_reference'=>$rollbackReference,'before_snapshot_hash'=>$beforeHash,'after_snapshot_hash'=>$afterHash];
        },3);
    }

    private function pair(int $userId,string $resource,string $winnerPublicId,string $loserPublicId,bool $lock): array
    {
        $table=self::TABLES[$resource]??throw ValidationException::withMessages(['resource'=>['Unsupported duplicate resource.']]);$tenant=CrmCompanyScope::companyId($userId);
        $w=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$winnerPublicId)->whereNull('deleted_at');$l=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$loserPublicId)->whereNull('deleted_at');if($lock){$w->lockForUpdate();$l->lockForUpdate();}$winner=$w->first();$loser=$l->first();if(!$winner||!$loser)throw ValidationException::withMessages(['merge'=>['Both records must exist in this CRM account.']]);return[$table,$winner,$loser];
    }
    private function patch(array $winner,array $loser): array{$patch=[];foreach($loser as $k=>$v){if(in_array($k,['id','public_id','company_id','user_id','customer_unification_id','created_at','updated_at','deleted_at','entity_version'],true))continue;if(($winner[$k]??null)===null||($winner[$k]??null)==='')if($v!==null&&$v!=='')$patch[$k]=$v;}return$patch;}
    private function relationshipSummary(int $tenant,string $resource,object $winner,object $loser): array
    {
        $s=[];if($resource==='companies'){$s['contacts']=$this->db->table('crm_contacts')->where('company_id',$tenant)->where('customer_company_id',$loser->id)->count();$s['deals']=$this->db->table('crm_deals')->where('company_id',$tenant)->where('customer_company_id',$loser->id)->count();foreach(['proposals','estimates','invoices'] as $t)$s[$t]=$this->db->table('crm_'.$t)->where('company_id',$tenant)->where('company_public_id',$loser->public_id)->count();$s['projects']=$this->db->table('crm_projects')->where('company_id',$tenant)->where('company_public_id',$loser->public_id)->count();}elseif($resource==='contacts'){$s['deals']=$this->db->table('crm_deals')->where('company_id',$tenant)->where('contact_id',$loser->id)->count();foreach(['proposals','estimates','invoices'] as $t)$s[$t]=$this->db->table('crm_'.$t)->where('company_id',$tenant)->where('contact_public_id',$loser->public_id)->count();}$loserRoot=(string)($loser->customer_unification_id??'');if($loserRoot!==''&&$this->db->getSchemaBuilder()->hasTable('crm_customer_identities'))$s['identity_records']=$this->db->table('crm_customer_identities')->where('company_id',$tenant)->where('customer_unification_id',$loserRoot)->count();if($loserRoot!==''&&$this->db->getSchemaBuilder()->hasTable('crm_external_identities'))$s['external_identities']=$this->db->table('crm_external_identities')->where('company_id',$tenant)->where('customer_unification_id',$loserRoot)->count();return$s;
    }
    private function singularResource(string $resource): string { return ['companies'=>'company','contacts'=>'contact','leads'=>'lead'][$resource]??$resource; }
    private function consolidateRoots(int $tenant,string $winnerRoot,string $loserRoot): void
    {
        foreach(['crm_customer_identities','crm_external_identities'] as $table)if($this->db->getSchemaBuilder()->hasTable($table))$this->db->table($table)->where('company_id',$tenant)->where('customer_unification_id',$loserRoot)->update(['customer_unification_id'=>$winnerRoot,'updated_at'=>now()]);
        foreach(['crm_contacts','crm_leads'] as $table)if($this->db->getSchemaBuilder()->hasColumn($table,'customer_unification_id'))$this->db->table($table)->where('company_id',$tenant)->where('customer_unification_id',$loserRoot)->update(['customer_unification_id'=>$winnerRoot,'updated_at'=>now()]);
        if($this->db->getSchemaBuilder()->hasColumn('crm_leads','converted_customer_unification_id'))$this->db->table('crm_leads')->where('company_id',$tenant)->where('converted_customer_unification_id',$loserRoot)->update(['converted_customer_unification_id'=>$winnerRoot,'updated_at'=>now()]);
    }
    private function hash(array $state): string{return hash('sha256',json_encode($state,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));}
}
