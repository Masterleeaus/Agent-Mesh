# Disaster Recovery

Target RPO 60 minutes and RTO 240 minutes for extension-owned durable state. Restore only extension-owned tables/files, then reconcile source evidence and verify finalized snapshot hashes before re-enabling mutations.
