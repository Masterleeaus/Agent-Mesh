<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Support;

final class RedactedPayload
{
    private const REDACTED = '[REDACTED]';

    /** @param array<string|int,mixed> $payload @return array<string|int,mixed> */
    public static function apply(array $payload): array
    {
        $result = [];
        foreach ($payload as $key => $value) {
            if (is_string($key) && self::isSensitiveKey($key)) {
                $result[$key] = self::REDACTED;
                continue;
            }
            $result[$key] = is_array($value) ? self::apply($value) : $value;
        }
        return $result;
    }

    private static function isSensitiveKey(string $key): bool
    {
        return SecretFieldGuard::isSecretLike($key) || strtolower(trim($key)) === 'signature';
    }
}
