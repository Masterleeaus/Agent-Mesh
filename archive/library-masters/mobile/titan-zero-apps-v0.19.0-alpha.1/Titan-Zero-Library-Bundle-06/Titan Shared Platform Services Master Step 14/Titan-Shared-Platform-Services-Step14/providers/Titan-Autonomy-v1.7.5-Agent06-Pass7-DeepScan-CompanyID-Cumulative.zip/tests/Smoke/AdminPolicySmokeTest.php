<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyControlStoreContract;
use App\Extensions\TitanAutonomy\System\Services\PlatformPolicyService;

function acheck(bool $condition, string $message): void { if (!$condition) throw new RuntimeException($message); }

$store = new class implements AutonomyControlStoreContract {
    public array $policy=[];
    public function saveLearningSettings(int $tenantCompanyId, array $settings, string $policyVersion): void {}
    public function resetCapabilityLearning(int $tenantCompanyId, string $capability, string $workflowKey, string $targetLevel, string $policyVersion): void {}
    public function clearPreferences(int $tenantCompanyId, ?int $userId=null): int { return 0; }
    public function lowerCapabilityLevel(int $tenantCompanyId, string $capability, string $workflowKey, string $targetLevel, string $cause, string $policyVersion): void {}
    public function savePlatformPolicy(array $policy, string $policyVersion): void { $this->policy=$policy; }
    public function saveTenantPolicy(int $tenantCompanyId, array $policy, string $policyVersion): void {}
};
$service = new PlatformPolicyService($store, 'v1.3');
$policy = $service->save([
    'gate_minimums'=>['low'=>0,'medium'=>1,'high'=>2,'critical'=>1],
    'maximum_level_by_risk'=>['low'=>'trusted_auto','medium'=>'trusted_auto','high'=>'trusted_auto','critical'=>'trusted_auto'],
    'high_trusted_auto_exception'=>false,
    'critical_autonomy_exception'=>false,
    'system_wide_learning_permitted'=>true,
]);
acheck($policy['gate_minimums']['low']===1, 'platform low minimum cannot be below 1');
acheck($policy['gate_minimums']['medium']===2, 'platform medium minimum cannot be below 2');
acheck($policy['gate_minimums']['high']===3, 'platform high minimum cannot be below 3');
acheck($policy['maximum_level_by_risk']['high']==='auto', 'high Trusted Auto requires explicit platform exception');
acheck($policy['maximum_level_by_risk']['critical']==='semi_auto', 'critical high autonomy requires explicit platform exception');

$exception = $service->save([
    'gate_minimums'=>['low'=>2,'medium'=>4,'high'=>6,'critical'=>6],
    'maximum_level_by_risk'=>['high'=>'trusted_auto','critical'=>'auto'],
    'high_trusted_auto_exception'=>true,
    'critical_autonomy_exception'=>true,
]);
acheck($exception['gate_minimums']['medium']===4, 'platform may set stricter gate evidence');
acheck($exception['maximum_level_by_risk']['high']==='trusted_auto', 'explicit governed high-risk exception may allow Trusted Auto');
acheck($exception['maximum_level_by_risk']['critical']==='auto', 'explicit governed critical exception may raise ceiling');

$routes = file_get_contents(dirname(__DIR__,2).'/routes/web.php');
acheck(str_contains($routes, "Route::get('/admin'"), 'Super Admin policy screen route required');
acheck(is_file(dirname(__DIR__,2).'/resources/views/autonomy/admin.blade.php'), 'Super Admin policy view required');

echo "OK: AdminPolicySmokeTest\n";
