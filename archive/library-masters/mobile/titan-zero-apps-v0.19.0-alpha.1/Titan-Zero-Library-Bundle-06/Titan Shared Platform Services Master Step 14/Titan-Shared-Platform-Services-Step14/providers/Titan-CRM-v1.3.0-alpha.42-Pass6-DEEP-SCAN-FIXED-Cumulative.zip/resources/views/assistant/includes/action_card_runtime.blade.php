{{-- MagicAI injects the base64url action payload through the rendered `data-actions` attribute. --}}
<script>
(() => {
    const register = () => {
        if (!window.Alpine || window.__crmAssistantActionCardRegistered) return;
        window.__crmAssistantActionCardRegistered = true;

        Alpine.data('crmAssistantActionCard', () => ({
            actions: [],
            state: 'pending',
            init() {
                this.actions = this.decodeActions(this.$el.dataset.actions || '');
                this.render();
            },
            decodeActions(value) {
                if (!value) return [];
                try {
                    const padded = value.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(value.length / 4) * 4, '=');
                    return JSON.parse(decodeURIComponent(escape(atob(padded))));
                } catch (_) {
                    return [];
                }
            },
            render() {
                const root = this.$el;
                root.replaceChildren();
                root.classList.add('rounded-xl', 'border', 'border-foreground/10', 'bg-background', 'p-4', 'shadow-sm');

                const title = document.createElement('div');
                title.className = 'text-sm font-semibold';
                title.textContent = this.actions.length === 1 ? 'CRM action requires approval' : `${this.actions.length} CRM actions require approval`;
                root.appendChild(title);

                this.actions.forEach((action, index) => {
                    const row = document.createElement('div');
                    row.className = 'mt-3 rounded-lg border border-foreground/10 p-3';
                    const label = document.createElement('div');
                    label.className = 'text-sm font-medium';
                    label.textContent = action.label || action.tool || 'CRM action';
                    const summary = document.createElement('div');
                    summary.className = 'mt-1 text-xs opacity-70';
                    summary.textContent = action.summary || '';
                    const buttons = document.createElement('div');
                    buttons.className = 'mt-3 flex gap-2';
                    const approve = document.createElement('button');
                    approve.type = 'button';
                    approve.className = 'rounded-lg bg-primary px-3 py-2 text-xs text-primary-foreground';
                    approve.textContent = 'Approve';
                    approve.addEventListener('click', () => this.execute(index, action, approve, reject, summary));
                    const reject = document.createElement('button');
                    reject.type = 'button';
                    reject.className = 'rounded-lg border border-foreground/15 px-3 py-2 text-xs';
                    reject.textContent = 'Reject';
                    reject.addEventListener('click', () => {
                        approve.disabled = true;
                        reject.disabled = true;
                        summary.textContent = 'Rejected. No CRM change was made.';
                    });
                    buttons.append(approve, reject);
                    row.append(label, summary, buttons);
                    root.appendChild(row);
                });
            },
            async execute(index, action, approve, reject, summary) {
                approve.disabled = true;
                reject.disabled = true;
                summary.textContent = 'Executing approved CRM action…';
                try {
                    const response = await fetch(@json(route('dashboard.user.crm.ai.actions.execute')), {
                        method: 'POST',
                        credentials: 'same-origin',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content || '',
                        },
                        body: JSON.stringify({tool: action.tool, arguments: action.arguments || {}}),
                    });
                    const payload = await response.json();
                    if (!response.ok) throw new Error(payload.message || 'CRM action failed.');
                    summary.textContent = 'Approved and completed.';
                    approve.textContent = 'Completed';
                } catch (error) {
                    summary.textContent = error?.message || 'CRM action failed.';
                    approve.disabled = false;
                    reject.disabled = false;
                }
            },
        }));
    };

    document.addEventListener('alpine:init', register);
    if (window.Alpine) register();
})();
</script>
