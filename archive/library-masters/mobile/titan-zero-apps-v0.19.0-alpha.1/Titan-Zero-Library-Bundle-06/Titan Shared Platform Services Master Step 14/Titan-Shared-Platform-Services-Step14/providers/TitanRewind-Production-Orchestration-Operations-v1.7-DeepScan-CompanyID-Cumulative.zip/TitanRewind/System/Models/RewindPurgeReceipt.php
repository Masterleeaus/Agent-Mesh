<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Models;
use Illuminate\Database\Eloquent\Model;
final class RewindPurgeReceipt extends Model
{
 protected $table='titan_rewind_purge_receipts';protected $fillable=['receipt_uuid','run_uuid','tenant_company_id','table_name','retention_class','from_id','to_id','rows_deleted','rows_held','batch_hash','metadata','purged_at'];protected $casts=['tenant_company_id'=>'integer','from_id'=>'integer','to_id'=>'integer','rows_deleted'=>'integer','rows_held'=>'integer','metadata'=>'array','purged_at'=>'datetime'];
}
