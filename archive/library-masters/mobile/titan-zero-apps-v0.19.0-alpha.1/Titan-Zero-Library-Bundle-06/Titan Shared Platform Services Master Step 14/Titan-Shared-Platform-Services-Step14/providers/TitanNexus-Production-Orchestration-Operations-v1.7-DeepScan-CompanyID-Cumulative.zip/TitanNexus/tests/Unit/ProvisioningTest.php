<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanNexus\Unit;

use App\Extensions\TitanNexus\System\Adapters\CommandBus\CommandBusProvisioningAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\AssuranceEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\AutonomyEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\GovernanceEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\RiskEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Observability\RewindEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Observability\SignalEngineAdapter;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompiledTitanConfig;
use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlanStatus;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Services\DeterministicProvisioningPlanner;
use App\Extensions\TitanNexus\System\Services\GovernedProvisioningExecutor;
use PHPUnit\Framework\TestCase;

final class ProvisioningTest extends TestCase
{
    public function test_plan_is_deterministic_and_dependency_ordered(): void
    {
        [$compilation, $definition] = $this->fixture();
        $planner = new DeterministicProvisioningPlanner();

        $first = $planner->plan($compilation, $definition);
        $second = $planner->plan($compilation, $definition);

        self::assertSame(ProvisioningPlanStatus::Ready, $first->status());
        self::assertSame($first->fingerprint(), $second->fingerprint());
        self::assertSame('sections.crm', $first->operations()[0]->path());
        self::assertSame([$first->operations()[0]->operationId()], $first->operations()[1]->dependsOnOperationIds());
        self::assertTrue($first->operations()[0]->backupRequired());
    }

    public function test_applied_gateway_receipt_requires_backup_write_audit_and_rollback_evidence(): void
    {
        [$compilation, $definition] = $this->fixture();
        $plan = (new DeterministicProvisioningPlanner())->plan($compilation, $definition);
        $adapter = new CommandBusProvisioningAdapter(static fn (string $capability, array $request): array => [
            'operation_id' => $request['operation_id'],
            'idempotency_key' => $request['idempotency_key'],
            'status' => 'applied',
            'backup_reference' => 'backup:' . $request['operation_id'],
            'backup_verified' => true,
            'write_verified' => true,
            'audit_reference' => 'audit:' . $request['operation_id'],
            'rollback_reference' => 'rollback:' . $request['operation_id'],
        ]);

        $executed = $this->executor($adapter)->execute($plan, $this->trace());
        self::assertSame(ProvisioningPlanStatus::Applied, $executed->status());
        self::assertCount(2, $executed->receipts());
    }

    /** @return array{0:NexusCompilation,1:VerticalDefinition} */
    private function fixture(): array
    {
        $profile = BusinessProfile::fromArray([
            'tenant_company_id' => 42,
            'profile_version' => '1',
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'jurisdiction' => ['country_code' => 'AU'],
            'timezone' => 'Australia/Melbourne',
            'sections' => ['crm' => ['enabled' => true], 'workforce' => ['roles' => ['cleaner']]],
        ]);
        $definition = VerticalDefinition::fromArray([
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'sections' => [],
            'provisioning' => ['routes' => [
                'sections.crm' => ['capability' => 'crm.configuration.apply', 'depends_on' => []],
                'sections.workforce' => ['capability' => 'workforce.configuration.apply', 'depends_on' => ['sections.crm']],
            ]],
        ]);
        $config = new CompiledTitanConfig(42, '1', '0.5.0', 'cleaning', '2026.08', null, $profile->fingerprint(), $definition->fingerprint(), $profile->sections());
        $compilation = NexusCompilation::draft($profile, $this->trace(), '44444444-4444-4444-8444-444444444444', '0.5.0')->withCompiledConfiguration($config);
        return [$compilation, $definition];
    }


    private function executor(CommandBusProvisioningAdapter $adapter): GovernedProvisioningExecutor
    {
        return new GovernedProvisioningExecutor(
            $adapter,
            new RiskEngineAdapter(static fn (array $request): array => ['allowed'=>true,'decision_reference'=>'risk:test','risk_class'=>'MEDIUM','required_assurance'=>'AMBER']),
            new GovernanceEngineAdapter(static fn (array $request): array => ['allowed'=>true,'decision_reference'=>'gov:test','approval_required'=>false]),
            new AssuranceEngineAdapter(static fn (array $request): array => ['allowed'=>true,'evidence_reference'=>'assurance:test','assurance_level'=>'AMBER']),
            new SignalEngineAdapter(static fn (string $event, array $request): array => ['signal_reference'=>'signal:'.$event]),
            new RewindEngineAdapter(static fn (string $event, array $request): array => ['rewind_reference'=>'rewind:'.$event]),
            new AutonomyEngineAdapter(static fn (array $request): array => ['allowed'=>true,'decision_reference'=>'autonomy:test','authority_level'=>'Semi-Auto']),
        );
    }

    private function trace(): TraceContext
    {
        return TraceContext::fromArray([
            'tenant_company_id' => 42,
            'trace_id' => '11111111-1111-4111-8111-111111111111',
            'correlation_id' => '22222222-2222-4222-8222-222222222222',
            'causation_id' => '33333333-3333-4333-8333-333333333333',
        ]);
    }
}
