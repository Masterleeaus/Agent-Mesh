<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Forensics;

final class RewindRootCauseAnalyzer
{
    public function analyse(array $orderedEvents, array $causation, array $dependencies): array
    {
        $parents = [];
        foreach (($causation['edges'] ?? []) as $edge) {
            $from = (string) ($edge['from'] ?? '');
            $to = (string) ($edge['to'] ?? '');
            if ($from !== '' && $to !== '') $parents[$to][] = $from;
        }

        $failures = [];
        foreach ($orderedEvents as $event) {
            if ($this->isFailure($event)) $failures[] = $event;
        }

        $primary = $failures[0] ?? null;
        $primaryResult = null;
        if ($primary !== null) {
            $id = (string) ($primary['event_id'] ?? '');
            $upstream = $this->walkParents($id, $parents);
            $primaryResult = [
                'event_id' => $id,
                'event_type' => $primary['event_type'] ?? null,
                'source_engine' => $primary['source_engine'] ?? null,
                'sequence' => $primary['sequence'] ?? null,
                'risk_level' => $this->riskLevel($primary),
                'risk_state' => is_array($primary['risk_state'] ?? null) ? $primary['risk_state'] : [],
                'capability_name' => $primary['capability_name'] ?? null,
                'capability_version' => $primary['capability_version'] ?? null,
                'decision_id' => $primary['decision_id'] ?? null,
                'upstream_event_ids' => $upstream,
                'evidence_refs' => $primary['evidence_refs'] ?? [],
                'rationale' => $primary['rationale'] ?? [],
            ];
        }

        $recovery = false;
        if ($primary !== null) {
            $primarySequence = (int) ($primary['sequence'] ?? 0);
            foreach ($orderedEvents as $event) {
                if ((int) ($event['sequence'] ?? 0) < $primarySequence) continue;
                $type = strtolower((string) ($event['event_type'] ?? ''));
                if (str_contains($type, 'recover') || str_contains($type, 'compensat') || str_contains($type, 'rollback')) {
                    $recovery = true;
                    break;
                }
            }
        }

        return [
            'status' => $primaryResult === null ? 'no_explicit_failure' : 'failure_identified',
            'primary' => $primaryResult,
            'failure_event_ids' => array_values(array_filter(array_map(static fn (array $e): ?string => $e['event_id'] ?? null, $failures))),
            'recovery_detected' => $recovery,
            'causation_orphan_count' => count($causation['orphans'] ?? []),
            'dependency_count' => count($dependencies),
            'method' => 'deterministic_failure_and_causation_analysis',
        ];
    }

    private function isFailure(array $event): bool
    {
        $type = strtolower((string) ($event['event_type'] ?? ''));
        foreach (['.failed','failed','.failure','error','.rejected','rejected','.denied','denied','timeout','timed_out'] as $needle) {
            if (str_contains($type, $needle)) return true;
        }
        return in_array($this->riskLevel($event), ['critical'], true) && (str_contains($type, 'command') || str_contains($type, 'decision'));
    }

    private function riskLevel(array $event): string
    {
        $risk = is_array($event['risk_state'] ?? null) ? $event['risk_state'] : [];
        foreach (['level','risk_level','overall','severity'] as $key) {
            if (isset($risk[$key]) && is_scalar($risk[$key])) return strtolower(trim((string) $risk[$key]));
        }
        return 'unknown';
    }

    private function walkParents(string $eventId, array $parents): array
    {
        $seen = [];
        $queue = $parents[$eventId] ?? [];
        while ($queue !== []) {
            $parent = array_shift($queue);
            if (isset($seen[$parent])) continue;
            $seen[$parent] = true;
            foreach ($parents[$parent] ?? [] as $ancestor) $queue[] = $ancestor;
        }
        return array_keys($seen);
    }
}
