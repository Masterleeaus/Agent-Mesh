# Governance

Signal observes and records; it does not grant authority.

- Risk determines risk.
- Assurance evaluates evidence.
- Autonomy determines independent authority.
- Governance owns policy/approval.
- Command Bus performs governed capabilities.
- Domain extensions own business truth.
- Signal records the resulting observations and receipts.
- Rewind/Wisdom may consume Signal history.

High-risk Signal lifecycle actions require explicit permissions and governed reasons. Offline operation never increases authority.
