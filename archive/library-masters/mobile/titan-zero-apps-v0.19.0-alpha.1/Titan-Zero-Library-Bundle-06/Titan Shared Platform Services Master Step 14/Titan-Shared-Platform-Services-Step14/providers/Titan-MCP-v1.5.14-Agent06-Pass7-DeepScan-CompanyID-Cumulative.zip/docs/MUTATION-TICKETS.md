# Coordinated Mutation Tickets

Titan MCP 1.5 retains the two-phase approval protocol introduced in 1.4 and strengthens its client evidence contract.

1. Call `titan_mutation_prepare` with the exact intended mutation tool and exact argument object.
2. Titan re-applies the intended capability/write-safety policy, validates repository/SQL/Artisan preconditions, creates the exact filesystem/database recovery snapshot(s), verifies them, and stores a sealed short-lived ticket.
3. The preparation result now includes `approval_evidence` (`titan-mcp-approval-evidence/1`): ticket ID, tool, argument SHA-256, exact-argument binding proof, targets, backup domains, verified pre-approval backup evidence, preparation/expiry times, and the exact commit descriptor.
4. Backup domains are derived from the recovery evidence that Titan actually created; they are not copied from the caller's requested coverage.
5. The client reviews this evidence and obtains explicit human approval.
6. Call `titan_mutation_commit` with only the ticket ID. No mutation arguments are accepted at commit time.
7. Titan re-verifies ticket integrity, ownership, expiry, canonical argument binding and every pre-approval backup, atomically consumes the ticket, re-applies original capability gates, then executes the exact stored canonical tool call.
8. The underlying mutation tool still creates its normal immediate pre-write backup and audit receipt. Commit returns `post_commit_evidence` (`titan-mcp-post-commit-evidence/1`) including committed state, result SHA-256, preparation backup evidence, mutation backup evidence, and ticket ID.
9. Use `titan_mutation_status` to inspect redacted lifecycle state. Raw stored arguments are never returned by the status tool.

Tickets are single-use, actor-bound and short-lived. A failed commit is terminal; retry requires a fresh prepare so approval always corresponds to current recovery evidence and current preconditions.
