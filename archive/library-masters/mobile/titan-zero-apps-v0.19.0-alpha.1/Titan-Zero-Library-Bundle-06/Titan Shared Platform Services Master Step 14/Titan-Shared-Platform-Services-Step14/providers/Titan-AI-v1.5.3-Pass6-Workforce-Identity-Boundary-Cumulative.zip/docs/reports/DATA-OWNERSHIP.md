# Titan AI Data Ownership

TitanAI owns only governance/runtime configuration records. Every owned record is bounded by the canonical MagicAI `company_id`:

- `titan_ai_approval_requests`
- `titan_ai_action_receipts`
- `titan_ai_governed_memories`
- `titan_ai_persona_assignments`
- `titan_ai_governed_skills`
- `titan_ai_tool_permissions`
- `titan_ai_skill_evaluations`

It does not own customers, jobs, bookings, schedules, quotes, invoices, payments, inventory, workers or other WorkCore operational records. It does not own Chatbot conversations or presentation records. Normal uninstall retains the tables above; data deletion must be an explicit administrative lifecycle decision.

## Boundary

`company_id` is the only tenant key used by TitanAI runtime persistence. Existing pre-v1.3.0 TitanAI tables are upgraded by the forward migration documented in `../COMPANY-BOUNDARY.md`.
