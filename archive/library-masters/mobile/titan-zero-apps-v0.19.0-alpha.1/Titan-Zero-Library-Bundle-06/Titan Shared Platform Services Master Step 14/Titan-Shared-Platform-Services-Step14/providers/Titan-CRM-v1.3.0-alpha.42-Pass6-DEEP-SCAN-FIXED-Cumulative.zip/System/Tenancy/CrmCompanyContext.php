<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Tenancy;

final readonly class CrmCompanyContext
{
    public function __construct(
        public int $companyId,
        public ?int $actorUserId,
        public string $actorType = 'user',
        public array $roles = [],
        public array $permissions = [],
        public bool $authenticatedCompanyMembership = false,
        public string $correlationId = '',
        public string $sourceSurface = 'crm',
        public ?string $deviceId = null,
        public string $traceId = '',
        public ?string $causationId = null,
    ) {
        if ($companyId <= 0) {
            throw new \InvalidArgumentException('company_id must be a positive integer.');
        }
        if ($actorUserId !== null && $actorUserId <= 0) {
            throw new \InvalidArgumentException('actor_user_id must be a positive integer when present.');
        }
    }

    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'actor_user_id' => $this->actorUserId,
            'actor_type' => $this->actorType,
            'roles' => $this->roles,
            'permissions' => $this->permissions,
            'authenticated_company_membership' => $this->authenticatedCompanyMembership,
            'trace_id' => $this->traceId !== '' ? $this->traceId : $this->correlationId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'source_surface' => $this->sourceSurface,
            'device_id' => $this->deviceId,
        ];
    }
}
