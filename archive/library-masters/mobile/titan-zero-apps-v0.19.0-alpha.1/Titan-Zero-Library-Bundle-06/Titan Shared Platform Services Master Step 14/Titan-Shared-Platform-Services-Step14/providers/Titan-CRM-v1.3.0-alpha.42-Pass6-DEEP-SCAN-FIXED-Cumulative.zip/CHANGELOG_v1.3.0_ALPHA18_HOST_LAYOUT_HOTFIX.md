# CRM 1.3.0-alpha.18 — Host Panel Layout Runtime Hotfix

- Fixes live HTTP 500: `View [panel.layout.app] not found` observed on CRM Leads.
- Root cause: 56 CRM internal views intentionally inherit MagicAI's shared `panel.layout.app`, but the installed host had not registered a view-finder location that resolved that alias for the CRM request.
- `CrmServiceProvider::boot()` now calls `ensureHostPanelViewFallback()` before loading CRM views/routes.
- If `panel.layout.app` already resolves, CRM changes nothing.
- Otherwise, if MagicAI's standard `resources/views/default/panel/layout/app.blade.php` exists, CRM appends `resources/views/default` to Laravel's view finder.
- The fallback is appended rather than prepended, so any already-registered active-theme view location keeps precedence.
- No MagicAI core file is copied, overwritten or published.
- Fix applies to all 56 CRM views sharing the panel layout, not Leads only.
- Adds alpha.18 regression gate preventing removal/order regression of the fallback.
