<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

interface ExtensionHealth
{
    /** @return array{status:string,checks:array<string,string>,observed_at:string} */
    public function snapshot(): array;

    /** @return array{status:string,checks:array<string,string>,observed_at:string} */
    public function liveness(): array;

    /** @return array{status:string,checks:array<string,string>,observed_at:string} */
    public function readiness(): array;
}
