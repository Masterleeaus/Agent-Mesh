<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalArchiveStoreContract;
use App\Extensions\TitanSignalEngine\System\Exceptions\SignalIntegrityException;
use Generator;
use Illuminate\Support\Facades\Storage;
use RuntimeException;

final class LocalSignalArchiveStore implements SignalArchiveStoreContract
{
    public function archive(string $batchId, array $events, array $criteria = []): array
    {
        return $this->archiveStream($batchId, $events, count($events), $criteria);
    }

    public function archiveStream(string $batchId, iterable $events, int $expectedEventCount, array $criteria = []): array
    {
        if ($expectedEventCount < 1) throw new RuntimeException('Cannot archive an empty Signal batch.');
        $tmp = tempnam(sys_get_temp_dir(), 'titan-signal-archive-');
        if ($tmp === false) throw new RuntimeException('Unable to allocate Signal archive temporary file.');
        $gz = null;
        try {
            $gz = gzopen($tmp, 'wb6');
            if ($gz === false) throw new RuntimeException('Unable to open Signal archive gzip stream.');
            $manifest = json_encode([
                'batch_id' => $batchId,
                'criteria' => $criteria,
                'event_count' => $expectedEventCount,
            ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
            if (gzwrite($gz, $manifest . "\n") === false) throw new RuntimeException('Unable to write Signal archive manifest.');
            $count = 0;
            foreach ($events as $event) {
                if (! is_array($event)) throw new RuntimeException('Signal archive stream accepts event arrays only.');
                $line = json_encode($event, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
                if (gzwrite($gz, $line) === false) throw new RuntimeException('Unable to write Signal archive event line.');
                $count++;
            }
            gzclose($gz);
            $gz = null;
            if ($count !== $expectedEventCount) {
                throw new SignalIntegrityException("Signal archive stream count mismatch: expected {$expectedEventCount}, wrote {$count}.");
            }
            $maxBytes = max(1048576, (int) config('titan-signal-engine.archive_max_compressed_bytes', 134217728));
            $size = filesize($tmp);
            if ($size === false || $size > $maxBytes) throw new RuntimeException('Signal archive exceeds the configured compressed archive ceiling.');
            $checksum = hash_file('sha256', $tmp);
            if ($checksum === false) throw new RuntimeException('Signal archive checksum calculation failed.');

            $diskName = (string) config('titan-signal-engine.archive_disk', 'local');
            $path = trim((string) config('titan-signal-engine.archive_path', 'titan-signal-engine/archive'), '/');
            $locator = $path . '/' . gmdate('Y/m/d') . '/' . $batchId . '.jsonl.gz';
            $stream = fopen($tmp, 'rb');
            if ($stream === false) throw new RuntimeException('Unable to reopen Signal archive temporary file.');
            try {
                if (! Storage::disk($diskName)->put($locator, $stream)) throw new RuntimeException('Signal archive stream write failed.');
            } finally {
                fclose($stream);
            }
            return ['driver' => 'laravel-storage:' . $diskName, 'locator' => $locator, 'checksum' => $checksum, 'event_count' => $count];
        } finally {
            if (is_resource($gz)) gzclose($gz);
            @unlink($tmp);
        }
    }

    public function verify(string $locator, string $checksum, ?string $driver = null): bool
    {
        try {
            $tmp = $this->materializeVerified($locator, $checksum, $driver);
            @unlink($tmp);
            return true;
        } catch (SignalIntegrityException|RuntimeException) {
            return false;
        }
    }

    public function metadata(string $locator, string $checksum, ?string $driver = null): array
    {
        $tmp = $this->materializeVerified($locator, $checksum, $driver);
        try {
            $gz = gzopen($tmp, 'rb');
            if ($gz === false) throw new SignalIntegrityException('Signal archive gzip payload cannot be decoded.');
            try {
                $manifest = gzgets($gz);
                if ($manifest === false) throw new SignalIntegrityException('Signal archive manifest is missing.');
            } finally {
                gzclose($gz);
            }
            $decoded = json_decode(rtrim($manifest, "\r\n"), true, 512, JSON_THROW_ON_ERROR);
            if (! is_array($decoded) || ! isset($decoded['batch_id'], $decoded['event_count'])) throw new SignalIntegrityException('Signal archive manifest is malformed.');
            return ['batch_id' => (string) $decoded['batch_id'], 'criteria' => is_array($decoded['criteria'] ?? null) ? $decoded['criteria'] : [], 'event_count' => (int) $decoded['event_count']];
        } finally {
            @unlink($tmp);
        }
    }

    public function readEvent(string $locator, string $checksum, string $eventId, ?int $sequence = null, ?string $driver = null): ?array
    {
        $target = $sequence !== null && $sequence > 0 ? $sequence : null;
        $start = $target ?? 1;
        $limit = $target === null ? (int) config('titan-signal-engine.archive_query_limit', 1000) : 1;
        foreach ($this->stream($locator, $checksum, $start, $limit, $driver) as $seq => $event) {
            if (($event['event_id'] ?? null) === $eventId) return $event;
            if ($target !== null) return null;
        }
        return null;
    }

    public function readBatch(string $locator, string $checksum, int $limit = 1000, ?string $driver = null): array
    {
        $events = [];
        foreach ($this->stream($locator, $checksum, 1, $limit, $driver) as $event) $events[] = $event;
        return $events;
    }

    public function stream(string $locator, string $checksum, int $startSequence = 1, ?int $limit = null, ?string $driver = null): iterable
    {
        $startSequence = max(1, $startSequence);
        $maxLimit = max(1, (int) config('titan-signal-engine.archive_query_limit', 1000));
        $boundedLimit = max(1, min($limit ?? $maxLimit, $maxLimit));
        return $this->streamVerified($locator, $checksum, $startSequence, $boundedLimit, $driver);
    }

    /** @return Generator<int,array<string,mixed>,void,void> */
    private function streamVerified(string $locator, string $checksum, int $startSequence, int $limit, ?string $driver): Generator
    {
        $tmp = $this->materializeVerified($locator, $checksum, $driver);
        $gz = null;
        try {
            $gz = gzopen($tmp, 'rb');
            if ($gz === false) throw new SignalIntegrityException('Signal archive gzip payload cannot be decoded.');
            $manifest = gzgets($gz);
            if ($manifest === false) throw new SignalIntegrityException('Signal archive manifest is missing.');
            $manifestDecoded = json_decode(rtrim($manifest, "\r\n"), true, 512, JSON_THROW_ON_ERROR);
            if (! is_array($manifestDecoded) || ! isset($manifestDecoded['event_count'])) throw new SignalIntegrityException('Signal archive manifest is malformed.');
            $maxUncompressed = max(1048576, (int) config('titan-signal-engine.archive_max_uncompressed_bytes', 100663296));
            $bytes = strlen($manifest);
            $sequence = 0;
            $yielded = 0;
            while (! gzeof($gz) && $yielded < $limit) {
                $line = gzgets($gz);
                if ($line === false) break;
                $bytes += strlen($line);
                if ($bytes > $maxUncompressed) throw new RuntimeException('Signal archive exceeds the configured uncompressed read ceiling.');
                $line = rtrim($line, "\r\n");
                if ($line === '') continue;
                $sequence++;
                if ($sequence < $startSequence) continue;
                yield $sequence => $this->normalizeEventLine($line);
                $yielded++;
            }
        } finally {
            if (is_resource($gz)) gzclose($gz);
            @unlink($tmp);
        }
    }

    private function materializeVerified(string $locator, string $checksum, ?string $driver = null): string
    {
        if (! preg_match('/^[a-f0-9]{64}$/', $checksum)) throw new SignalIntegrityException('Signal archive checksum format is invalid.');
        $disk = Storage::disk($this->diskName($driver));
        if (! $disk->exists($locator)) throw new RuntimeException('Signal archive object does not exist.');
        $maxBytes = max(1048576, (int) config('titan-signal-engine.archive_max_compressed_bytes', 134217728));
        if (method_exists($disk, 'size') && (int) $disk->size($locator) > $maxBytes) throw new RuntimeException('Signal archive exceeds the configured compressed read ceiling.');
        $source = $disk->readStream($locator);
        if (! is_resource($source)) throw new RuntimeException('Signal archive object cannot be opened as a stream.');
        $tmp = tempnam(sys_get_temp_dir(), 'titan-signal-read-');
        if ($tmp === false) { fclose($source); throw new RuntimeException('Unable to allocate Signal archive read buffer.'); }
        $target = fopen($tmp, 'wb');
        if ($target === false) { fclose($source); @unlink($tmp); throw new RuntimeException('Unable to open Signal archive read buffer.'); }
        $hash = hash_init('sha256');
        $bytes = 0;
        try {
            while (! feof($source)) {
                $chunk = fread($source, 1024 * 1024);
                if ($chunk === false) throw new RuntimeException('Signal archive stream read failed.');
                if ($chunk === '') continue;
                $bytes += strlen($chunk);
                if ($bytes > $maxBytes) throw new RuntimeException('Signal archive exceeds the configured compressed read ceiling.');
                hash_update($hash, $chunk);
                if (fwrite($target, $chunk) !== strlen($chunk)) throw new RuntimeException('Signal archive temporary write failed.');
            }
        } catch (\Throwable $e) {
            fclose($source); fclose($target); @unlink($tmp); throw $e;
        }
        fclose($source); fclose($target);
        if (! hash_equals($checksum, hash_final($hash))) { @unlink($tmp); throw new SignalIntegrityException('Signal archive checksum verification failed during read.'); }
        return $tmp;
    }

    private function diskName(?string $driver): string
    {
        if ($driver === null || $driver === '') return (string) config('titan-signal-engine.archive_disk', 'local');
        $prefix = 'laravel-storage:';
        if (! str_starts_with($driver, $prefix)) throw new RuntimeException('Unsupported Signal archive driver: ' . $driver);
        $disk = substr($driver, strlen($prefix));
        if ($disk === '') throw new RuntimeException('Signal archive driver is missing its Laravel disk name.');
        return $disk;
    }

    /** @return array<string,mixed> */
    private function normalizeEventLine(string $line): array
    {
        $decoded = json_decode($line, true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($decoded)) throw new SignalIntegrityException('Signal archive event line is malformed.');
        if (isset($decoded['projected_event'])) {
            if (! is_array($decoded['projected_event'])) throw new SignalIntegrityException('Signal archive privacy projection is malformed.');
            return $decoded['projected_event'];
        }
        return $decoded;
    }
}
