# CRM 1.3.0-alpha.9 — Route Cache / Menu Link Compatibility Hotfix

## Live symptom

CRM sidebar links opened in a new tab and produced malformed URLs such as:

`/dashboard/admin/dashboard.user.crm.companies.index`

## Root cause

MagicAI menu records correctly store Laravel named routes such as `dashboard.user.crm.companies.index`.
The shared navbar checks `Route::has($href)` before converting that route name to a real URL. When the host route cache predates CRM installation or upgrade, Laravel's cached route collection can omit extension routes and `loadRoutesFrom()` will not add them. MagicAI therefore treats the unresolved route name as an external href, opens it in a new tab, and the browser resolves it relative to the current URL.

## Fix

`CrmServiceProvider` now keeps normal Laravel `loadRoutesFrom()` registration and adds a cache-safe sentinel fallback for CRM web, Sales, API, admin and Customer Hub route files. If the expected named route is missing from the live route collection, CRM requires its route file directly before navigation renders.

Named routes remain the canonical menu values. CRM does not hard-code dashboard URLs into the `menus` table.

## Safety

- No business-data migration is required.
- No CRM menu route values need rewriting.
- Existing menu hierarchy, plan keys and active-route families are preserved.
- The fallback only loads a route file when one of its sentinel routes is absent.
- All alpha.8 icon compatibility protection remains active.
