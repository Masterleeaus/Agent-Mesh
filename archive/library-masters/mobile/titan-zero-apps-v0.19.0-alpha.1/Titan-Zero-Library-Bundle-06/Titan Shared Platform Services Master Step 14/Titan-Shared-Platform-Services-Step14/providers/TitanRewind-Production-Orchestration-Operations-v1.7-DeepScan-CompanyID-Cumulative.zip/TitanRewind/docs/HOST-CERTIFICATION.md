# Titan Rewind Exact-Host Certification

Package-level Blueprint v4.1 certification is necessary but not sufficient to prove a particular MagicAI/Titan installation. Run this command inside the target application after installing/upgrading the extension:

```bash
php artisan titan-rewind:certify --json
```

The command fails closed unless PHP 8.2+, Laravel, the Rewind migrations/tables, queue configuration, scheduler binding, Titan Signal transport, Titan Governance gateway, the host-owned `RewindSourceRegistry`, and an available evidence signing key are present.

After the command passes, the deployment operator must also run migrations in a staging clone, start replay and Signal queue workers, exercise the scheduler, generate/verify/download signed evidence, test a legal hold against retention, reconstruct a known multi-source trace, and perform upgrade/disable/uninstall lifecycle checks according to the site's data-retention policy.

The isolated extension build environment used for v1.0.6 does not contain the user's complete MagicAI host, vendor tree, database, queue backend, scheduler or live Titan engine bindings. Therefore exact-host upgrade/uninstall/runtime certification is recorded as `NOT_EXECUTED` in `HOST-CERTIFICATION-STATUS.json`; no PASS result is fabricated.
