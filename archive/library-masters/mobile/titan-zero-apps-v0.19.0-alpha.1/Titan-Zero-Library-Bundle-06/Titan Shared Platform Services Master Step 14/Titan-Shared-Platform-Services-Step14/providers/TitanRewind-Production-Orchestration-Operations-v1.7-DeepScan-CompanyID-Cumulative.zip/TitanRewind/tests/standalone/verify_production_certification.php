<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);$checks=0;$fails=[];
function cert(bool $v,string $m):void{global $checks,$fails;$checks++;if(!$v){$fails[]=$m;fwrite(STDERR,"FAIL: {$m}\n");}}
function text(string $p):string{return is_file($p)?(file_get_contents($p)?:''):'';}
$required=[
'System/Streaming/RewindTraceStream.php','System/Streaming/RewindStreamWindow.php','System/Certification/RewindPerformanceBudget.php',
'System/Certification/RewindFaultMatrix.php','System/Certification/RewindDisasterRecoveryContract.php','System/Certification/RewindHostReadinessReport.php',
'System/SupplyChain/RewindBuildProvenance.php','System/SupplyChain/RewindSbomGenerator.php','System/SupplyChain/RewindPackageSignatureVerifier.php',
'System/Services/RewindEvidenceStreamService.php','System/Console/RunRewindCertificationCommand.php',
'schemas/capabilities/trace-read.input.json','schemas/capabilities/trace-read.output.json','schemas/capabilities/reconstruct.input.json','schemas/capabilities/reconstruct.output.json',
'schemas/capabilities/integrity-verify.input.json','schemas/capabilities/integrity-verify.output.json','schemas/capabilities/replay.input.json','schemas/capabilities/replay.output.json',
'schemas/capabilities/compare.input.json','schemas/capabilities/compare.output.json','schemas/capabilities/evidence-generate.input.json','schemas/capabilities/evidence-generate.output.json',
'schemas/capabilities/evidence-export.input.json','schemas/capabilities/evidence-export.output.json','schemas/capabilities/recovery-propose.input.json','schemas/capabilities/recovery-propose.output.json',
'schemas/capabilities/recovery-approval.input.json','schemas/capabilities/recovery-approval.output.json','schemas/capabilities/legal-hold.input.json','schemas/capabilities/legal-hold.output.json',
'resources/lang/en/rewind.php','docs/PERFORMANCE-SLO.md','docs/ACCESSIBILITY.md','docs/LOCALIZATION.md','docs/HOST-CERTIFICATION.md','docs/SUPPLY-CHAIN.md','docs/PRODUCTION-CERTIFICATION-v1.0.6.md',
'docs/SBOM.spdx.json','docs/BUILD-PROVENANCE.json','docs/PACKAGE-SIGNING.md','docs/HOST-CERTIFICATION-STATUS.json',
'tests/standalone/verify_large_trace_performance.php','tests/standalone/verify_fault_injection.php','tests/standalone/verify_concurrency.php','tests/standalone/verify_disaster_recovery.php','tests/standalone/verify_accessibility_localization.php','tests/standalone/verify_supply_chain.php'
];foreach($required as $f)cert(is_file($root.'/'.$f),'required '.$f);
$manifest=json_decode(text($root.'/extension.manifest.json'),true);cert(is_array($manifest),'manifest parses');
cert(in_array(($manifest['schema_version']??null),['2.0','2.1','2.2'],true),'manifest schema 2.x');cert(($manifest['version']??null)==='1.0.6','manifest version 1.0.6');cert(($manifest['runtime_profile']??null)==='titan-rewind','runtime profile titan-rewind');
foreach(['capability_contracts','health','observability','resilience','authorization','concurrency','versioning','performance','slos','supply_chain','rollout','disaster_recovery','secrets','titan_governance','verification','ui','documentation','rewind','rewind_sources'] as $k)cert(array_key_exists($k,$manifest),'manifest section '.$k);
foreach(['performance','fault_injection','large_trace_streaming','concurrency','architecture','tenant_isolation','authorization','evidence_signature','legal_hold','retention_purge'] as $k)cert(($manifest['verification'][$k]??false)===true,'verification '.$k);
cert(($manifest['performance']['streaming_required']??false)===true,'streaming required');cert(($manifest['performance']['max_trace_events_in_memory']??0)===5000,'memory trace cap 5000');
cert(($manifest['rewind']['authoritative_mutation']??true)===false,'rewind remains non-authoritative');cert(($manifest['rewind']['replay_mutation_policy']??null)==='deny','replay mutation denied');

if(is_file($root.'/System/Streaming/RewindStreamWindow.php')){
 require_once $root.'/System/Streaming/RewindStreamWindow.php';
 $c='App\\Extensions\\TitanRewind\\System\\Streaming\\RewindStreamWindow';
 $w=new $c(3);$r=$w->consume((function(){for($i=1;$i<=10;$i++)yield ['sequence'=>$i];})());
 cert(count($r['items']??[])===3,'stream window bounds in-memory items');cert(($r['truncated']??false)===true,'stream window reports truncation');cert(($r['observed_count']??0)===10,'stream window observes full stream');
}
if(is_file($root.'/System/Certification/RewindPerformanceBudget.php')){
 require_once $root.'/System/Certification/RewindPerformanceBudget.php';$c='App\\Extensions\\TitanRewind\\System\\Certification\\RewindPerformanceBudget';$b=new $c(256,5000,5000);$r=$b->evaluate(['peak_memory_mb'=>128,'max_events_in_memory'=>4999,'reconstruction_p95_ms'=>4200]);cert(($r['passed']??false)===true,'performance budget accepts bounded run');$r=$b->evaluate(['peak_memory_mb'=>300,'max_events_in_memory'=>5001,'reconstruction_p95_ms'=>6000]);cert(($r['passed']??true)===false,'performance budget rejects breach');
}
if(is_file($root.'/System/Certification/RewindFaultMatrix.php')){
 require_once $root.'/System/Certification/RewindFaultMatrix.php';$c='App\\Extensions\\TitanRewind\\System\\Certification\\RewindFaultMatrix';$m=new $c();$cases=$m->cases();foreach(['source_timeout','queue_unavailable','signal_circuit_open','integrity_mismatch','replay_boundary_violation','signing_key_unavailable'] as $name)cert(isset($cases[$name]),'fault case '.$name);cert(($cases['integrity_mismatch']['retryable']??true)===false,'integrity mismatch permanent');
}
if(is_file($root.'/System/Certification/RewindDisasterRecoveryContract.php')){
 require_once $root.'/System/Certification/RewindDisasterRecoveryContract.php';$c='App\\Extensions\\TitanRewind\\System\\Certification\\RewindDisasterRecoveryContract';$d=new $c(15,120);$r=$d->evaluate(10,90,true,true);cert(($r['passed']??false)===true,'DR accepts within RPO/RTO and verification');$r=$d->evaluate(20,90,true,true);cert(($r['passed']??true)===false,'DR rejects RPO breach');
}
$services=['RewindTimelineService.php','RewindReconstructionService.php','RewindSnapshotComparisonService.php','RewindTraceProjector.php','RewindDriftService.php','RewindIntegrityService.php','RewindEvidencePackageService.php','RewindDependencyService.php','RewindSourceWatermarkService.php'];
foreach($services as $f){$t=text($root.'/System/Services/'.$f);cert(!str_contains($t,'->'.'get()'),'no whole-query get in '.$f);}
$views='';foreach(glob($root.'/resources/views/**/*.blade.php')?:[] as $f)$views.=text($f);cert(!str_contains($views,'<html lang=""'),'views do not ship empty lang');
foreach(['docs/SBOM.spdx.json','docs/BUILD-PROVENANCE.json'] as $f){$j=json_decode(text($root.'/'.$f),true);cert(is_array($j),'valid json '.$f);}
cert(str_contains(text($root.'/docs/DISASTER-RECOVERY.md'),'RPO'),'DR doc states RPO');cert(str_contains(text($root.'/docs/DISASTER-RECOVERY.md'),'RTO'),'DR doc states RTO');

$ec=text($root.'/System/Http/Controllers/EvidenceController.php');cert(str_contains($ec,'RewindEvidenceStreamService'),'evidence controller uses streaming service');cert(str_contains($ec,'StreamedResponse'),'evidence download is streamed');
$provider=text($root.'/System/TitanRewindServiceProvider.php');cert(str_contains($provider,'RunRewindCertificationCommand'),'provider registers certification command');
$status=json_decode(text($root.'/docs/HOST-CERTIFICATION-STATUS.json'),true);cert(is_array($status),'host certification status parses');cert(($status['exact_host_runtime']['status']??null)==='NOT_EXECUTED','exact host runtime truthfully not executed');
$report=text($root.'/BUILD_REPORT.md');cert(str_contains($report,'1.0.6'),'build report 1.0.6');cert(str_contains($report,'Pass 8'),'build report Pass 8');
printf("Production certification checks: %d/%d PASS\n",$checks-count($fails),$checks);if($fails)exit(1);
