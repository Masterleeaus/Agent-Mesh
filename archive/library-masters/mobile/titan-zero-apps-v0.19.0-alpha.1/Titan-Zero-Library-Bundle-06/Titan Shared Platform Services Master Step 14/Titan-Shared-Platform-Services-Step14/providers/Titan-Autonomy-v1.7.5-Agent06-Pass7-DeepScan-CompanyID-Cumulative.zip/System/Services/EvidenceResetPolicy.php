<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;

final class EvidenceResetPolicy
{
    /**
     * The persistence layer must first recalculate remaining valid evidence.
     * This helper guarantees a reset can never preserve authority above what
     * that remaining evidence still supports.
     */
    public function effectiveLevelAfterReset(
        AutonomyLevel $current,
        AutonomyLevel $highestLevelSupportedByRemainingEvidence,
    ): AutonomyLevel {
        return $highestLevelSupportedByRemainingEvidence->value < $current->value
            ? $highestLevelSupportedByRemainingEvidence
            : $current;
    }

    public function gateEligibleAfterReset(bool $remainingEvidenceSupportsNextGate): bool
    {
        return $remainingEvidenceSupportsNextGate;
    }
}
