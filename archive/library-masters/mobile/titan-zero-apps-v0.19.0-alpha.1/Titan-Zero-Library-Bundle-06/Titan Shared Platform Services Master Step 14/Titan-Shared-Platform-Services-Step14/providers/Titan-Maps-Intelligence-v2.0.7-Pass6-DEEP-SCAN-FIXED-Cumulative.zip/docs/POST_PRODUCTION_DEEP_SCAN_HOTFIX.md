# Post-Production Deep Scan Hotfix 2.0.1

This hotfix follows the 16/16 joint production-candidate build and a second privacy, security, offline and package scan.

## Confirmed defects fixed

1. **Offline GPS idempotency unified by `client_sample_id`.** Live-eligible, historical and debounced samples retain deterministic replay classification.
2. **Historical/debounced samples cannot trigger retroactive geofences.** `geofence_eligible` is persisted and enforced by immediate and scheduled geofence paths.
3. **Team live-location scope requires current consent and on-duty state.**
4. **Worker-location authorization now checks the current user.** `Gate::has()` is no longer confused with user authorization.
5. **Check-in API/page/map history all honor current consent plus `share_history_until`.**
6. **Generic Locations surfaces and KPIs exclude worker GPS projections.**
7. **Live position surfaces enforce freshness consistently, including the Titan Field peer.**
8. **Retention pruning is scheduled hourly.**
9. **Unregistered consequential permissions fail closed.** Only read-only permissions retain the tenant-scoped host-portability fallback.
10. **Debounced offline samples get durable, non-geofence evidence receipts.**
11. **Package schema contract includes explicit offline classification and geofence eligibility provenance.**

Historical WorkCore-named candidate schema/adapter contracts remain only for backwards-compatible discovery/candidate integration; Titan Field remains the preferred operational peer.

Package verification is not a claim that a live Laravel/MySQL installation was executed.
