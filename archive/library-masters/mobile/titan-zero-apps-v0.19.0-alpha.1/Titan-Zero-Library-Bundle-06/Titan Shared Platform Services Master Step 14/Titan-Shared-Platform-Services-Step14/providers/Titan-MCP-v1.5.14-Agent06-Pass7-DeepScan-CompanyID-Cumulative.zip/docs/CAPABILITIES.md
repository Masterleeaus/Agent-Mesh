# Capabilities

The canonical catalogue exposes 34 tools across project, repository, schema/database, runtime/logs, backup/recovery and command categories, plus the `titan_start_plan` prompt.

Read capabilities are distinct from repository/database/command write capabilities. Destructive repository/database/command permissions are separately required. The Tool Catalogue admin page shows the current catalogue and deterministic contract hash.


### Coding write tools
- `titan_repository_replace` — exact text replacement with occurrence and SHA checks; verified backup before write.
- `titan_repository_batch_write` — coordinated multi-file commit; one verified backup covers every target scope before the first write and the entire batch compensates on failure.
- `titan_repository_mkdir` — governed directory creation with pre-write recovery scope.


## Coordinated mutation protocol
- `titan_mutation_prepare` — validates intent and creates verified pre-approval recovery backup(s).
- `titan_mutation_commit` — consumes the single-use ticket and executes the exact stored mutation.
- `titan_mutation_status` — returns redacted ticket lifecycle/evidence.
