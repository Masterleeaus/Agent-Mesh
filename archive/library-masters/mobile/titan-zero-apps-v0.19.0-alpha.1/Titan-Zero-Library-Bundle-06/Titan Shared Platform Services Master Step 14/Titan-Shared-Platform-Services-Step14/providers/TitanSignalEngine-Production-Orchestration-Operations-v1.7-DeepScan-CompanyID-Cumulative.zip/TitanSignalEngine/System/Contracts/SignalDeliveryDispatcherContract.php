<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryReceipt;
use Throwable;

interface SignalDeliveryDispatcherContract
{
    public function deliver(string $deliveryId, ?string $executionToken = null, ?string $workerId = null): SignalDeliveryReceipt;

    public function transportFailed(string $deliveryId, Throwable $exception, ?string $executionToken = null): SignalDeliveryReceipt;
}
