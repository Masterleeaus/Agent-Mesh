<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Http\Controllers;

use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Services\RewindReconstructionService;
use App\Extensions\TitanRewind\System\Services\RewindTenantContextResolver;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

final class TraceController
{
    public function __construct(private RewindTenantContextResolver $tenants, private RewindReconstructionService $reconstruction) {}

    public function show(Request $request, string $traceId): View
    {
        $tenant = $this->tenants->forUser($request->user());
        abort_if($tenant === null, 403, 'Titan Rewind could not resolve an explicit tenant company for this account.');
        $query = RewindTraceQuery::fromArray(['tenant_company_id'=>$tenant,'trace_id'=>$traceId]);
        $reconstruction = $this->reconstruction->reconstruct($query, true);
        abort_if(($reconstruction['event_count'] ?? 0) < 1, 404, 'Titan Rewind trace not found for this tenant.');
        return view('titan-rewind::trace', ['reconstruction'=>$reconstruction]);
    }
}
