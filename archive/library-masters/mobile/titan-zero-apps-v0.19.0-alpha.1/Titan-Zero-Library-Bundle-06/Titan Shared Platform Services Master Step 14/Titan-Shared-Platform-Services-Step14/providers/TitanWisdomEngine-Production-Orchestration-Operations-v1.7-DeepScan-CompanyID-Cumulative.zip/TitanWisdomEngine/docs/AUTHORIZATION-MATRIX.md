# Authorization Matrix

| Surface / operation | Minimum access | Governance rule |
|---|---|---|
| User status | authenticated tenant user | read-only; no mutation decision required |
| Admin status | host admin middleware | read-only; no mutation decision required |
| Future outcome record | governed capability + tenant object authorization | fresh scoped `ALLOW` required |
| Future evidence attach | governed capability + tenant object authorization | fresh scoped `ALLOW` required |
| Future outcome revision | governed capability + tenant object authorization | fresh scoped `ALLOW` required |
| Future attribution calculation | Wisdom-owned service contract | fresh scoped `ALLOW` required |
| Future calibration emission | Wisdom-owned service contract | fresh scoped `ALLOW` required |
| Future learning-candidate proposal | Wisdom-owned service contract | fresh scoped `ALLOW` required |
| Learning-candidate promotion | never owned by Wisdom | always denied locally |
| Autonomy grant | never owned by Wisdom | always denied locally |
| Cross-domain write | never owned by Wisdom | always denied locally |
