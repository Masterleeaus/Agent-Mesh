<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$passes = 0;

$check = static function (bool $condition, string $message) use (&$failures, &$passes): void {
    if ($condition) {
        ++$passes;
        echo "PASS: {$message}\n";
        return;
    }

    $failures[] = $message;
    echo "FAIL: {$message}\n";
};

$throws = static function (callable $callback, string $expectedClass) use ($check): void {
    try {
        $callback();
        $check(false, "throws {$expectedClass}");
    } catch (Throwable $e) {
        $check($e instanceof $expectedClass, "throws {$expectedClass}");
    }
};

$manifestPath = $root . '/extension.manifest.json';
$manifest = json_decode((string) file_get_contents($manifestPath), true, 512, JSON_THROW_ON_ERROR);

$check(($manifest['version'] ?? null) === '1.0.6', 'manifest version is 1.0.6');
$check(($manifest['queues']['used'] ?? null) === true, 'manifest declares the wired replay queue');
$capabilities = $manifest['capabilities'] ?? [];
$check(in_array('titan-rewind', $capabilities, true), 'base Titan Rewind capability is declared');
$check(in_array('rewind.health', $capabilities, true), 'health capability is declared');
$check(in_array('rewind.foundation', $capabilities, true), 'foundation capability is declared');
$check(in_array('rewind.compare', $capabilities, true), 'implemented rewind.compare capability is advertised');

$ownedTables = $manifest['database']['owned_tables'] ?? [];
foreach (['titan_rewind_snapshots', 'titan_rewind_trace_events', 'titan_rewind_trace_index', 'titan_rewind_cases', 'titan_rewind_case_traces', 'titan_rewind_timeline_entries', 'titan_rewind_dependencies', 'titan_rewind_replay_runs'] as $table) {
    $check(in_array($table, $ownedTables, true), "manifest owns {$table}");
}

$requiredFiles = [
    '/System/Reconstruction/RewindTraceQuery.php',
    '/System/Reconstruction/RewindEventRecord.php',
    '/System/Contracts/RewindSourceAdapterContract.php',
    '/System/Navigation/TitanRewindNavigation.php',
    '/System/Navigation/NavigationRegistrar.php',
    '/database/migrations/2026_08_11_000002_add_titan_rewind_foundation.php',
];
foreach ($requiredFiles as $file) {
    $check(is_file($root . $file), "foundation file exists: {$file}");
}

require_once $root . '/System/Reconstruction/RewindTraceQuery.php';
require_once $root . '/System/Reconstruction/RewindEventRecord.php';
require_once $root . '/System/Navigation/TitanRewindNavigation.php';

use App\Extensions\TitanRewind\System\Navigation\TitanRewindNavigation;
use App\Extensions\TitanRewind\System\Reconstruction\RewindEventRecord;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;

$traceId = '3d6f0a0f-4fca-4f82-92ff-8ec45137eaea';
$correlationId = 'a9fb85f0-a87b-41b4-b126-9f3fd5c35b15';
$causationId = '147f30d2-9063-47f4-a364-d5db39d04527';
$eventId = 'a2147528-b293-4419-b706-c858b46039fc';

$query = RewindTraceQuery::fromArray([
    'tenant_company_id' => 42,
    'trace_id' => $traceId,
    'correlation_id' => $correlationId,
]);
$check($query->tenantCompanyId() === 42, 'trace query requires explicit tenant company');
$check($query->traceId() === $traceId, 'trace query preserves trace id');
$check($query->correlationId() === $correlationId, 'trace query preserves correlation id');

$throws(static fn () => RewindTraceQuery::fromArray([
    'tenant_company_id' => 0,
    'trace_id' => $traceId,
]), InvalidArgumentException::class);
$throws(static fn () => RewindTraceQuery::fromArray([
    'tenant_company_id' => 42,
    'trace_id' => 'not-a-uuid',
]), InvalidArgumentException::class);

$record = RewindEventRecord::fromArray([
    'tenant_company_id' => 42,
    'event_id' => $eventId,
    'trace_id' => $traceId,
    'correlation_id' => $correlationId,
    'causation_id' => $causationId,
    'source_engine' => 'titan-signal-engine',
    'source_record_id' => 'signal:1001',
    'event_type' => 'command.completed',
    'sequence' => 7,
    'occurred_at' => '2026-08-11T09:25:00.123456+00:00',
    'tier' => 4,
    'lane' => 'execution',
    'reason_codes' => ['policy.allowed', 'risk.accepted'],
    'evidence_refs' => [['type' => 'signal', 'id' => 'signal:1001']],
    'rationale' => ['summary' => 'Command completed after governed approval.'],
    'payload' => ['receipt_id' => 'cmd_123'],
]);
$serialized = $record->toArray();
$check($serialized['tenant_company_id'] === 42, 'event record preserves tenant boundary');
$check($serialized['causation_id'] === $causationId, 'event record preserves causation id');
$check($serialized['sequence'] === 7, 'event record preserves deterministic sequence');
$check($serialized['rationale']['summary'] === 'Command completed after governed approval.', 'event record permits structured rationale');

$throws(static fn () => RewindEventRecord::fromArray([
    'tenant_company_id' => 42,
    'event_id' => $eventId,
    'trace_id' => $traceId,
    'source_engine' => 'titan-ai-core',
    'event_type' => 'decision.created',
    'sequence' => 1,
    'occurred_at' => '2026-08-11T09:20:00+00:00',
    'payload' => ['chain_of_thought' => 'private hidden reasoning'],
]), InvalidArgumentException::class);

$throws(static fn () => RewindEventRecord::fromArray([
    'tenant_company_id' => 42,
    'event_id' => $eventId,
    'trace_id' => $traceId,
    'source_engine' => 'titan-ai-core',
    'event_type' => 'decision.created',
    'sequence' => 1,
    'occurred_at' => '2026-08-11T09:20:00+00:00',
    'rationale' => ['nested' => ['reasoning_content' => 'hidden']],
]), InvalidArgumentException::class);

$userNavigationA = TitanRewindNavigation::user();
$userNavigationB = TitanRewindNavigation::user();
$adminNavigation = TitanRewindNavigation::admin();
$check($userNavigationA === $userNavigationB, 'user navigation is deterministic');
$check(count($userNavigationA) === 8, 'user navigation exposes one stable Rewind parent plus seven child links');
$check(($userNavigationA[0]['key'] ?? null) === 'titan_rewind', 'user navigation key is stable');
$check(($userNavigationA[0]['route'] ?? null) === 'dashboard.user.titan.rewind.index', 'user navigation route exists by contract');
$check(($adminNavigation[0]['route'] ?? null) === 'dashboard.admin.titan.rewind.index', 'admin navigation route exists by contract');

$migration = (string) file_get_contents($root . '/database/migrations/2026_08_11_000002_add_titan_rewind_foundation.php');
foreach (['tenant_company_id', 'trace_id', 'correlation_id', 'causation_id', 'event_id', 'source_engine', 'source_record_id', 'sequence', 'occurred_at', 'integrity_hash', 'rationale'] as $field) {
    $check(str_contains($migration, "'{$field}'"), "foundation migration declares {$field}");
}
$check(str_contains($migration, "->unsignedBigInteger('tenant_company_id')->index()"), 'normalized trace events require non-null tenant company');

$systemFiles = [];
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/System'));
foreach ($iterator as $file) {
    if ($file->isFile() && $file->getExtension() === 'php') {
        $systemFiles[] = $file->getPathname();
    }
}
$systemCode = implode("\n", array_map(static fn (string $file): string => (string) file_get_contents($file), $systemFiles));
foreach (['Http::', 'curl_' . 'exec(', 'shell_' . 'exec(', 'exec(', 'eloquent.created: *', 'eloquent.updated: *'] as $forbidden) {
    $check(!str_contains($systemCode, $forbidden), "System layer avoids unsafe/external side effect pattern {$forbidden}");
}
$check(!str_contains($systemCode, 'Modules\\'), 'native Rewind runtime does not import donor module namespaces');

$allTests = '';
$testIterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/tests'));
foreach ($testIterator as $file) {
    if ($file->isFile() && $file->getExtension() === 'php') {
        $allTests .= (string) file_get_contents($file->getPathname());
    }
}
$placeholderNeedle = 'assertTrue' . '(true)';
$check(!str_contains($allTests, $placeholderNeedle), 'placeholder always-true tests are removed');

if ($failures !== []) {
    fwrite(STDERR, "\nFOUNDATION VERIFICATION FAILED (" . count($failures) . " failures, {$passes} passes)\n");
    exit(1);
}

echo "\nFOUNDATION VERIFICATION PASSED ({$passes} checks)\n";
