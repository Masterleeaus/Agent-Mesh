<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Http\Controllers;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Services\AutonomyDashboardService;
use App\Extensions\TitanAutonomy\System\Services\GateReviewService;
use Illuminate\Support\Facades\View;
use Illuminate\View\View as ViewContract;

final class AutonomyDashboardController
{
    public function __construct(
        private readonly HostContextBridgeContract $context,
        private readonly AutonomyQueryContract $query,
        private readonly AutonomyDashboardService $dashboard,
        private readonly GateReviewService $gateReview,
    ) {}

    public function index(): ViewContract
    {
        $this->authorise('titan.autonomy.view');
        $tenantCompanyId = $this->context->tenantCompanyId();

        return view('titan-autonomy::autonomy.index', [
            'layout' => $this->layout(),
            'overview' => $this->dashboard->tenantOverview($tenantCompanyId),
        ]);
    }

    public function capability(string $capability, ?string $workflowKey = ''): ViewContract
    {
        $this->authorise('titan.autonomy.view');
        $tenantCompanyId = $this->context->tenantCompanyId();
        $workflowKey = $workflowKey ?? '';
        $state = $this->query->capabilityState($tenantCompanyId, $capability, $workflowKey);
        abort_if($state === null, 404);

        $review = $this->gateReview->review($tenantCompanyId, $capability, $workflowKey);
        return view('titan-autonomy::autonomy.capability', [
            'layout' => $this->layout(),
            'state' => $state,
            'gate' => $review['gate'],
            'events' => $this->query->learningEvents($tenantCompanyId, $capability, $workflowKey, 50),
            'handshakes' => $this->query->handshakes($tenantCompanyId, $capability, $workflowKey, 25),
            'regressions' => $this->query->regressions($tenantCompanyId, $capability, $workflowKey, 25),
        ]);
    }

    public function learning(): ViewContract
    {
        $this->authorise('titan.learning.view');
        $tenantCompanyId = $this->context->tenantCompanyId();

        return view('titan-autonomy::autonomy.learning', [
            'layout' => $this->layout(),
            'settings' => $this->query->learningSettings($tenantCompanyId),
            'events' => $this->query->learningEvents($tenantCompanyId, limit: 100),
            'preferences' => $this->query->learningPreferences($tenantCompanyId, $this->context->userId()),
            'platformPolicy' => $this->query->platformPolicy() ?? [],
        ]);
    }

    private function authorise(string $permission): void
    {
        abort_unless($this->context->can($permission), 403);
    }

    private function layout(): string
    {
        $configured = (string) config('titan-autonomy.view_layout', 'panel.layout.app');
        return View::exists($configured) ? $configured : 'titan-autonomy::autonomy.layout';
    }
}
