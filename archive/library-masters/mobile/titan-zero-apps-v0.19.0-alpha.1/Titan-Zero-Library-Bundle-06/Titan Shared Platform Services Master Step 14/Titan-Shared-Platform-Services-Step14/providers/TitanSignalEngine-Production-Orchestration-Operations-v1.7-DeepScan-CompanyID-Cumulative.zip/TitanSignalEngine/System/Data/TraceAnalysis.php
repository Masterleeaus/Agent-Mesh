<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

final readonly class TraceAnalysis
{
    /**
     * @param list<SignalEnvelope> $orderedEvents
     * @param list<string> $missingEventTypes
     * @param array<string,string> $missingParentEventIds child_event_id => missing_parent_event_id
     * @param list<array{before:string,after:string,reason:string}> $sequenceViolations
     * @param list<string> $causalCycleEventIds
     * @param list<array<string,mixed>> $profileViolations
     */
    public function __construct(
        public string $status,
        public array $orderedEvents,
        public array $missingEventTypes,
        public array $missingParentEventIds,
        public array $sequenceViolations,
        public array $causalCycleEventIds,
        public array $profileViolations,
        public ?string $profileKey,
        public ?int $profileVersion,
    ) {
    }

    public function isComplete(): bool
    {
        return $this->status === 'complete';
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'status' => $this->status,
            'profile_key' => $this->profileKey,
            'profile_version' => $this->profileVersion,
            'event_count' => count($this->orderedEvents),
            'missing_event_types' => $this->missingEventTypes,
            'missing_parent_event_ids' => $this->missingParentEventIds,
            'sequence_violations' => $this->sequenceViolations,
            'causal_cycle_event_ids' => $this->causalCycleEventIds,
            'profile_violations' => $this->profileViolations,
        ];
    }
}
