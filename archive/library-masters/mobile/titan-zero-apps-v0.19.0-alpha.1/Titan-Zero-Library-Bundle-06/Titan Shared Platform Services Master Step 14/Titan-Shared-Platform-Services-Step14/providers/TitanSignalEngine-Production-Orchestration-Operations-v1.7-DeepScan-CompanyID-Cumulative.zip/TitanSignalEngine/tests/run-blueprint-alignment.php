<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);

$fail = static function (string $message): never {
    fwrite(STDERR, "FAIL: {$message}\n");
    exit(1);
};
$assert = static function (bool $condition, string $message) use ($fail): void {
    if (! $condition) {
        $fail($message);
    }
};

$assert(($manifest['schema_version'] ?? null) === '2.2', 'manifest must use canonical Blueprint schema 2.2');
$assert(($manifest['runtime_profile'] ?? null) === 'titan-governed-engine', 'Signal must declare titan-governed-engine runtime profile');
$assert(($manifest['observability']['signal_events'] ?? null) === true, 'Signal observability.signal_events must be true');
$assert(($manifest['supply_chain']['signature_required'] ?? null) === true, 'governed engine production packages must require signing');
$assert(($manifest['health']['liveness'] ?? null) === true && ($manifest['health']['readiness'] ?? null) === true, 'liveness/readiness declarations required');
$assert(count($manifest['capability_contracts'] ?? []) >= 6, 'Signal must ship versioned capability contracts');

foreach (($manifest['schedules'] ?? []) as $schedule) {
    $assert(isset($schedule['key'], $schedule['frequency'], $schedule['on_one_server'], $schedule['without_overlapping']), 'every schedule must use Blueprint v4 schedule shape');
    $assert($schedule['without_overlapping'] === true, 'every schedule must prevent overlap');
}

foreach ([
    'System/Contracts/ExtensionHealth.php',
    'System/Health/TitanSignalEngineHealthCheck.php',
    'System/Observability/TraceContext.php',
    'docs/ARCHITECTURE.md',
    'docs/CAPABILITIES.md',
    'docs/OPERATIONS.md',
    'docs/SECURITY.md',
    'docs/DATA-OWNERSHIP.md',
    'docs/UPGRADE.md',
    'docs/UNINSTALL.md',
    'docs/TROUBLESHOOTING.md',
    'docs/INTEGRATION-CONTRACTS.md',
    'docs/SIGNAL-EVENTS.md',
    'docs/GOVERNANCE.md',
    'docs/FAILURE-MODES.md',
    'docs/AUTHORIZATION-MATRIX.md',
    'docs/DISASTER-RECOVERY.md',
    'resources/lang/en/messages.php',
] as $required) {
    $assert(is_file($root . '/' . $required), "missing Blueprint v4 governed-engine file: {$required}");
}

$provider = (string) file_get_contents($root . '/System/TitanSignalEngineServiceProvider.php');
$assert(str_contains($provider, 'loadTranslationsFrom'), 'provider must load localization resources');
$assert(str_contains($provider, 'TitanSignalEngineHealthCheck'), 'provider must bind governed-engine health check');
$assert(substr_count($provider, '->onOneServer()') >= 5, 'all Signal schedules must use onOneServer');

fwrite(STDOUT, "PASS: Blueprint v4 Signal alignment contract\n");
