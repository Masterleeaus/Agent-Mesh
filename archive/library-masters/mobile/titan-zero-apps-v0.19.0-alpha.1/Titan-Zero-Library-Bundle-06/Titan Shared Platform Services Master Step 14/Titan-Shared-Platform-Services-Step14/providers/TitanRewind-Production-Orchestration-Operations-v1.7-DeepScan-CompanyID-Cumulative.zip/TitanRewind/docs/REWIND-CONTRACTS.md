# Rewind Contracts

Titan Rewind is a forensic read model. It never owns authoritative business mutation.

Canonical trace identity: `tenant_company_id`, `trace_id`, `correlation_id`, `causation_id`. Deterministic order is `sequence`, `occurred_at`, `event_id`.

Source adapters remain read-only. Watermark-capable adapters additionally implement `RewindSourceWatermarkProviderContract` and report one of `COMPLETE`, `PARTIAL`, `STALE`, `UNAVAILABLE`, with observed-through and lag metadata. Adapters without a watermark contract are treated as `PARTIAL` rather than silently complete.

Replay mutation policy is permanently `deny`. Current-state and counterfactual comparison modify only sanitized Rewind projections and record `decision_reexecution_performed=false` until a governed historical execution runtime exists.
