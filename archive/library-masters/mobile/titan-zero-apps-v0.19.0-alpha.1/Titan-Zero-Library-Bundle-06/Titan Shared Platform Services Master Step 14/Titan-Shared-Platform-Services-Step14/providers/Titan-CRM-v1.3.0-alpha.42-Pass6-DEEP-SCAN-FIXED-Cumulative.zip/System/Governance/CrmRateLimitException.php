<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

use RuntimeException;

final class CrmRateLimitException extends RuntimeException
{
    public function __construct(public readonly int $retryAfterSeconds)
    { parent::__construct("CRM governed capability rate limit exceeded; retry_after_seconds={$retryAfterSeconds}."); }
}
