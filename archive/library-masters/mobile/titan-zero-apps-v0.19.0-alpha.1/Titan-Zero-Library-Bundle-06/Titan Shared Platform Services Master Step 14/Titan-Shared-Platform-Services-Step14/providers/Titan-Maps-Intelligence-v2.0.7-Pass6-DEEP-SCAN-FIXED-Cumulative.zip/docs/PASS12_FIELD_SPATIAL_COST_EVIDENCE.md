# Pass 12 — Titan Field Spatial Cost Evidence

Titan Maps Intelligence exposes **read-only spatial evidence** to Titan Field through `FieldSpatialPeerGateway::workOrderCostEvidence()`.

The peer verifies the tenant-scoped Field job reference, then returns the latest persisted route/ETA snapshot and territory evaluation when available. Evidence can include road/straight-line distance, duration, traffic delay, freshness, service-area coverage, and persisted geographic pricing signals.

All returned pricing signals remain advisory. The payload explicitly reports `authoritative: false` and `financial_authority: false`. Titan Maps Intelligence **does not calculate profit**, does not calculate an invoice or quoted revenue, and **does not write financial** or work-order state.

Titan Field decides whether explicit Field-owned labour or vehicle cost rates can convert travel evidence into a cost. Maps pricing hints are never auto-applied by this peer contract.
