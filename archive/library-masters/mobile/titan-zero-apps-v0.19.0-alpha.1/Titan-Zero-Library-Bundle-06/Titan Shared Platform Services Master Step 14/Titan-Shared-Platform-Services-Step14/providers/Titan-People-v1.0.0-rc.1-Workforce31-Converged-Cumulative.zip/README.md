# Titan People

Titan People is Titan Zero's canonical human worker and employment domain. Version `1.0.0-rc.1` is the cumulative Pass 5 production-hardening release candidate. It retains the verified People domain, self-service workspace and governed AI/Signal integrations from Passes 1–4, and adds bounded production dispatch, stronger tenant mutation scoping, private-storage root enforcement and operational recovery runbooks.

## Domain authority

Titan People owns worker/employment profile facts, organisation and reporting relationships, lifecycle/history, leave/absence policy and balances, holiday calendars, People-owned HR documents, emergency contacts and policy acknowledgement facts.

It does **not** own attendance/check-in/break/log/regularization data, shift execution, expenses, payroll bank/disbursement data, credentials, recruitment pipelines, performance reviews or onboarding orchestration.

## Production release candidate

- Durable tenant-scoped Signal outbox and host-pluggable delivery dispatcher.
- Privacy-minimized Rewind source facts with opaque/source references only.
- Four extension-owned People AI Workforce roles with deterministic anomaly/reminder detectors.
- State-changing Workforce proposal tools route through Command Bus and cannot self-approve.
- Typed Time Attendance, Payroll, Credentials, Recruit, Performance, Onboarding and Communications boundaries.
- Deterministic proactive Workforce tasks with idempotency and escalation.

## Pass 4 invariants

- No AI silent termination, suspension, leave-balance mutation or authority escalation.
- No peer-extension private table reads/writes.
- No private People document bytes, names, email, phone, emergency-contact bodies or bank/payment data in Signal/Rewind payloads.
- External Signal/Communications/Workforce runtimes fail closed when unavailable.
- Cross-domain mutations remain tenant-scoped, governed and receipt-bearing.
