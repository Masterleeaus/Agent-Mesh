<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers\TeamChat;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Events\TeamChat\TeamConversationUpdated;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use App\Extensions\TitanConnect\System\Policies\TeamChat\TeamConversationPolicy;
use App\Extensions\TitanConnect\System\Realtime\SafeRealtimeDispatcher;
use App\Extensions\TitanConnect\System\Security\ConversationAccess;
use App\Extensions\TitanConnect\System\Services\TeamChat\TeamConversationService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class TeamConversationController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly ConversationAccess $access,
        private readonly SafeRealtimeDispatcher $realtime,
    ) {
    }

    public function index(Request $request): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $conversations = TeamConversation::query()
            ->where('company_id', $companyId)
            ->whereIn('type', ['direct', 'group'])
            ->whereHas('participants', fn ($query) => $query
                ->where('company_id', $companyId)->where('user_id', $actorId)->whereNull('left_at')->whereNull('archived_at'))
            ->with(['participants' => fn ($query) => $query->where('company_id', $companyId)->whereNull('left_at'), 'latestMessage'])
            ->latest('updated_at')
            ->paginate(min(max((int) $request->integer('per_page', 30), 1), 100));

        return response()->json($conversations);
    }

    public function store(Request $request, TeamConversationService $service): JsonResponse
    {
        $data = $request->validate([
            'type' => ['required', 'in:direct,group'],
            'name' => ['nullable', 'string', 'max:255', 'required_if:type,group'],
            'user_ids' => ['required', 'array', 'min:1'],
            'user_ids.*' => ['integer', 'distinct'],
            'device_id' => ['nullable', 'string', 'max:191'],
        ]);

        $conversation = $service->create(
            $this->context->companyId($request),
            $this->context->actorId($request),
            $data['type'],
            $data['name'] ?? null,
            $data['user_ids'],
            $data['device_id'] ?? null,
        );

        return response()->json($conversation, $conversation->wasRecentlyCreated ? 201 : 200);
    }

    public function update(Request $request, TeamConversation $conversation, TeamConversationPolicy $policy): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->access->assertMember($conversation, $companyId, $actorId);
        abort_unless($conversation->type === 'group' && $policy->canManage($conversation, $actorId), 403);

        $data = $request->validate([
            'name' => ['sometimes', 'required', 'string', 'max:255'],
            'description' => ['sometimes', 'nullable', 'string', 'max:2000'],
            'avatar' => ['sometimes', 'nullable', 'string', 'max:2048'],
        ]);

        $conversation->fill($data);
        $conversation->updated_by = $actorId;
        $conversation->version = ((int) $conversation->version) + 1;
        $conversation->save();
        $this->realtime->dispatch(new TeamConversationUpdated($conversation, 'metadata-updated', $actorId));

        return response()->json($conversation->fresh(['participants']));
    }

    public function show(Request $request, TeamConversation $conversation): JsonResponse
    {
        $this->access->assertMember($conversation, $this->context->companyId($request), $this->context->actorId($request));
        return response()->json($conversation->load(['participants', 'messages.reads']));
    }

    public function leave(Request $request, TeamConversation $conversation, TeamConversationService $service): JsonResponse
    {
        $actorId = $this->context->actorId($request);
        $this->access->assertMember($conversation, $this->context->companyId($request), $actorId);
        $service->leave($conversation, $actorId);
        return response()->json(['status' => 'success']);
    }

    public function archive(Request $request, TeamConversation $conversation, TeamConversationService $service): JsonResponse
    {
        $actorId = $this->context->actorId($request);
        $this->access->assertMember($conversation, $this->context->companyId($request), $actorId);
        $data = $request->validate(['archived' => ['required', 'boolean']]);
        $service->archiveForUser($conversation, $actorId, (bool) $data['archived']);
        return response()->json(['status' => 'success']);
    }
}
