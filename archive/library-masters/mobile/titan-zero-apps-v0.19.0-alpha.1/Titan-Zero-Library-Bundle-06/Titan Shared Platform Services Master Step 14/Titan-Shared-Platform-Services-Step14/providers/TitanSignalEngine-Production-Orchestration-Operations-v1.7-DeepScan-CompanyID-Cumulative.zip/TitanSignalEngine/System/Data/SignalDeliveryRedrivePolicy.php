<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

final readonly class SignalDeliveryRedrivePolicy
{
    public function canRedrive(string $status): bool
    {
        return $status === 'dead_letter';
    }

    public function nextAttemptCount(): int
    {
        return 0;
    }

    public function reasonHash(string $reason): string
    {
        return hash('sha256', trim($reason));
    }
}
