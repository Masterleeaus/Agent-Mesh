<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;
use Illuminate\Database\Eloquent\Builder; use Illuminate\Database\Eloquent\Model;
final class TimeSubmissionItem extends Model {protected $table='ext_titan_time_submission_items';protected $fillable=['tenant_company_id','submission_id','time_entry_id'];public function scopeForCompany(Builder $query,int $tenantCompanyId): Builder{return $query->where('tenant_company_id',$tenantCompanyId);}}
