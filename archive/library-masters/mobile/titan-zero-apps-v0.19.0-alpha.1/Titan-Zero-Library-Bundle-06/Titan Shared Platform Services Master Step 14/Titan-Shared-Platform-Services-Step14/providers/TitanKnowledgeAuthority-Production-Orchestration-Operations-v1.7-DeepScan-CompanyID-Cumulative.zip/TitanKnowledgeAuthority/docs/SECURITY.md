# Security
Knowledge Authority is fail-closed at authority and tenancy boundaries. Cross-domain writes are forbidden; LLMs may not assign source authority or resolve equal-rank conflicts; offline operation may not increase authority.

Tenant and jurisdiction visibility must originate from a host-bound `KnowledgeAccessContextResolverContract`. Missing context causes failure, not platform-wide fallback. Canonical predicates deny cross-tenant or ungranted-jurisdiction records.

## Immutable-version write controls
Pass 4 adds a transactionally serialized writer around `KnowledgeSourceVersion`. The visible source row is locked before duplicate/lineage decisions. Duplicate content is idempotent. Existing duplicate/latest versions must carry tenant lineage matching the source. New content gets a service-generated sequence/key and can only supersede the current latest version. An optional predecessor precondition detects stale callers. Tenant ownership is copied from the trusted source record, never from append input. Model update/delete hooks reject ordinary Eloquent mutation, and the parent source FK no longer cascades deletion into immutable versions.

Remote acquisition remains disabled, so no HTTP/SSRF/credential path is active yet.
