# Titan Model Council — Super Admin Control Plane Hotfix 5

## Root cause

The previous host-navigation hotfix created one user menu row and one Super Admin menu row, but the native Titanized extension exposed only an operational summary page. The donor settings view remained archived under `resources/views/legacy` and no native settings persistence or child navigation was wired.

## Fix

- Added a native Super Admin control plane with Overview, Settings, Strategies & Activation, Providers & Models, Integrations, Billing & Limits, and Diagnostics & Audit surfaces.
- Added extension-owned `titan_model_council_settings` persistence.
- Persisted settings overlay runtime configuration on subsequent requests.
- Added admin controls for Council enablement, model limits, synthesis preference, selective activation, governed mode, Risk, Shield, Assurance, contradiction ceiling, quorum, provider timeouts/circuit breaker and billing reservation ceilings.
- Added child host-menu rows under `titan_model_council_admin` with boot-time self-heal and uninstall cleanup.
- Preserved the existing tenant-user Model Council link as a non-admin surface.
- Intentional disabled peer engines report `DISABLED`, not `DEGRADED`.

## Authority boundary

These controls alter Model Council policy only. They do not grant Council mutation/execution authority, alter provider credentials, or override Titan Risk/Governance/Command Bus authority.
