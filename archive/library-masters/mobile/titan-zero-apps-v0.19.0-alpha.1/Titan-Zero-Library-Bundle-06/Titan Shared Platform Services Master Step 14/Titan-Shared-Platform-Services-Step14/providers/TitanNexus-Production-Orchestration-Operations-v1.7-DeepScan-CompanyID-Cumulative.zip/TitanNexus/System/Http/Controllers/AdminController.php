<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Http\Controllers;

use App\Extensions\TitanNexus\System\Contracts\NexusControlCentreContract;
use App\Extensions\TitanNexus\System\Contracts\NexusManagerContract;
use App\Extensions\TitanNexus\System\Contracts\TenantContextResolverContract;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use RuntimeException;

final class AdminController
{
    public function __construct(
        private readonly TenantContextResolverContract $tenantContext,
        private readonly NexusControlCentreContract $controlCentre,
        private readonly NexusManagerContract $manager,
    ) {}

    public function __invoke(Request $request): View
    {
        $snapshot = null;
        $message = null;
        try {
            $tenantCompanyId = $this->tenantContext->resolve($request->user());
            $snapshot = $this->controlCentre->snapshot($tenantCompanyId)->toArray();
        } catch (RuntimeException) {
            $message = 'No authorised tenant context is available for tenant-specific Nexus diagnostics.';
        }

        return view('titan-nexus::admin', [
            'health' => $this->manager->health(),
            'snapshot' => $snapshot,
            'message' => $message,
        ]);
    }
}
