<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Services;

use App\Extensions\TitanPrime\System\Gateways\Contracts\EngineBridgeContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\EngineGatewayCatalogContract;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineAvailability;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;
use Throwable;

final class EngineGatewayCatalog implements EngineGatewayCatalogContract
{
    /** @var list<EngineKey> */
    private const REQUIRED_FOR_EXECUTION = [
        EngineKey::AiCore,
        EngineKey::Signal,
        EngineKey::Risk,
        EngineKey::Assurance,
        EngineKey::Autonomy,
        EngineKey::Governance,
        EngineKey::Rewind,
    ];

    public function __construct(private readonly EngineBridgeContract $bridge) {}

    public function snapshot(): array
    {
        $snapshot = [];
        foreach (EngineKey::cases() as $engine) {
            try {
                $availability = $this->bridge->availability($engine);
                if ($availability->engine !== $engine) {
                    $availability = new EngineAvailability($engine, false, 'bridge_contract_mismatch');
                }
            } catch (Throwable) {
                $availability = new EngineAvailability($engine, false, 'bridge_availability_failed');
            }
            $snapshot[$engine->value] = $availability->toArray();
        }
        return $snapshot;
    }

    public function allRequiredForExecutionAvailable(): bool
    {
        $snapshot = $this->snapshot();
        foreach (self::REQUIRED_FOR_EXECUTION as $engine) {
            if (($snapshot[$engine->value]['available'] ?? false) !== true) {
                return false;
            }
        }
        return true;
    }
}
