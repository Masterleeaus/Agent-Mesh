<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class RewindGovernanceReceipt extends Model
{
    protected $table = 'titan_rewind_governance_receipts';
    protected $fillable = [
        'receipt_uuid','tenant_company_id','recovery_plan_id','external_request_id','authority','status','request_payload_hash','evidence_package_uuid',
        'decision','receipt','requested_at','decided_at',
    ];
    protected $casts = [
        'tenant_company_id'=>'integer','recovery_plan_id'=>'integer','decision'=>'array','receipt'=>'array','requested_at'=>'datetime','decided_at'=>'datetime',
    ];

    public function recoveryPlan(): BelongsTo { return $this->belongsTo(RewindRecoveryPlan::class, 'recovery_plan_id'); }
}
