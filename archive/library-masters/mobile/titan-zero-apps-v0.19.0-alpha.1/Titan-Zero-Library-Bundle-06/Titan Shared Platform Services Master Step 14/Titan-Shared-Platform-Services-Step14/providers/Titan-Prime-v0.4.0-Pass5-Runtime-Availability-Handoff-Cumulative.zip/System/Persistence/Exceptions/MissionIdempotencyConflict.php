<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Persistence\Exceptions;

use RuntimeException;

final class MissionIdempotencyConflict extends RuntimeException
{
    public static function forOperation(string $operationId): self
    {
        return new self(sprintf('Prime operation [%s] was already used with a different payload.', $operationId));
    }
}
