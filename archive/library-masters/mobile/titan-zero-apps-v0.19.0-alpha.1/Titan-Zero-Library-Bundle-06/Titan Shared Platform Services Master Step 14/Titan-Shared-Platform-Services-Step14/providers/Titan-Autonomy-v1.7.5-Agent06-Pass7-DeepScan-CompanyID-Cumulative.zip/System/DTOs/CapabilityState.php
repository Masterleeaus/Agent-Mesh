<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\DTOs;

use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\RiskClass;

final readonly class CapabilityState
{
    public function __construct(
        public int $tenantCompanyId,
        public string $capability,
        public string $workflowKey,
        public RiskClass $risk,
        public AutonomyLevel $currentLevel,
        public int $requiredSuccessStreak,
        public int $currentSuccessStreak = 0,
        public int $highestSuccessStreak = 0,
        public int $totalSuccesses = 0,
        public int $totalFailures = 0,
        public int $totalEdits = 0,
        public int $totalRejections = 0,
        public int $totalReversals = 0,
        public bool $platformGateEligible = false,
        public array $scope = [],
        public ?string $lastSuccessAt = null,
        public ?string $lastFailureAt = null,
    ) {}
}
