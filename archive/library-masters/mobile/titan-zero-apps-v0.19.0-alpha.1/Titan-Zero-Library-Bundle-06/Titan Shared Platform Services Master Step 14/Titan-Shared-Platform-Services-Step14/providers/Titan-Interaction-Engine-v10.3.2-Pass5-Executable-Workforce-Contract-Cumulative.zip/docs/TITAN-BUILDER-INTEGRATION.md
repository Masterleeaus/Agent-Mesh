# Titan Builder Integration

Builder owns application definitions, branding, navigation, features, themes, previews, validation, publishing and rollback. Interaction Engine never edits Builder persistence directly.

Phase 6 adapts only public contracts verified in the supplied Titan Builder v1.0 source. The compatibility adapter can use `PreviewRenderer` and `Publisher`/rollback where present; broader application, brand, navigation, feature and theme provisioning remains unavailable until Builder publishes/binds the appropriate provisioning gateway.

The verified `Publisher` contract uses an integer `companyId`. Interaction Engine's canonical tenant is an opaque/string `company_id`, so the compatibility adapter executes publish/rollback only when that value is safely numeric. It does not coerce arbitrary company identifiers. A future Builder provisioning gateway should accept the platform company identifier explicitly.
