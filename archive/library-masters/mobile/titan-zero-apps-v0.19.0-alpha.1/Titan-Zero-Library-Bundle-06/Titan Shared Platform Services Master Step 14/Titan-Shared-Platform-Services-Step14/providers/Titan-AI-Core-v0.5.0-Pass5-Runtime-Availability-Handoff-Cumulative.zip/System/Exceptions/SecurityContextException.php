<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Exceptions;

use RuntimeException;

final class SecurityContextException extends RuntimeException
{
    public function __construct(
        public readonly string $securityCode,
        string $message,
    ) {
        parent::__construct($message);
    }
}
