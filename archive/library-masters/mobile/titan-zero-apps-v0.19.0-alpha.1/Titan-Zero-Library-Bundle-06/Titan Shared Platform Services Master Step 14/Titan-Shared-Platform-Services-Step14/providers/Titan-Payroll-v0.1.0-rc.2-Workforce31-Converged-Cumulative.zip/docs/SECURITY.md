# Security

Tenant scope is actor-derived. Payroll protected fields are encrypted at rest. Logs and diagnostics must never contain raw banking, tax identifiers, full payslips or secrets.
