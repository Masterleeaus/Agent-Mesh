# Conversion Map — cumulative through 0.1.0

## Source corpus used for this extension

| Donor | Files | PHP files | Legacy migrations | Contribution |
|---|---:|---:|---:|---|
| Timesheet | 186 | 164 | 7 | Primary timesheet/timer/submission/costing architecture |
| FSMTimesheet | 19 | 18 | 1 | Work-order and duration concepts |
| SiteAttendance | 51 | 18 | 3 | Site-context concepts |
| GeofenceSystem | 36 | 23 | 5 | Radius/location verification |
| DynamicQrAttendance | 27 | 10 | 0 | Dynamic QR concepts |
| QRAttendance | 40 | 27 | 5 | Static QR concepts |
| OfflineTracking | 25 | 11 | 0 | Offline evidence/sync concepts |
| IpAddressAttendance | 42 | 27 | 5 | Trusted-network verification |

The legacy migrations are **not** copied blindly. Several donors modify shared tables; Titan Time & Attendance instead owns isolated `ext_titan_time_*` tables.

## Implemented in alpha.1

### Native extension conversion
- `titan-extension-v1` identity
- exact folder/provider/register-key contract
- extension sidecar manifest
- scoped config publication
- preflight + health services
- config-gated disable
- retain-on-uninstall lifecycle
- reversible extension-owned migrations

### Domain runtime
- time entries
- timer start/stop
- timer stop → transactional time-entry creation
- work-order/project/task reference fields
- weekly submission and review
- costing calculation
- Signal outbox foundation

### Attendance verification
- geofence verification
- dynamic QR verification
- static QR fallback
- trusted IP verification using tenant-owned rules
- site/evidence mismatch rejection
- bare site-ID assertion rejection
- minimised verification evidence
- raw IP/token suppression in persisted evidence

### Offline
- tenant + source-event idempotency
- replay detection
- replay-content mismatch rejection
- bounded event types
- minimised telemetry payload
- raw QR/IP values replaced by hashes
- offline sync signal creation

### AI Workforce
- Time & Attendance Manager
- Timesheet Auditor
- Attendance Exception Specialist
- Workforce Presence Agent
- extension-owned manifest
- 9 implemented read tools
- skills and prompts
- weekly review and attendance-exception workflows
- configuration wizards declared as `planned`, not executable

### Authorization hardening
- self-service time reads by default
- explicit permission required to view all tenant workers
- explicit permission required to record time for another worker
- explicit review permission required for approval/rejection

## Deliberately deferred to later passes

The following legacy capabilities are not advertised as active in alpha.1 until they are ported and governed:

- time-entry edit/delete
- policy mutation
- formal attendance exception-resolution mutation
- full reporting/export suite
- legacy UI parity and richer generative surfaces
- Command Bus execution adapter
- Signal Engine delivery adapter/worker
- Risk/Shield/Rewind/Wisdom integration adapters
- CRM work-order/site reference validation adapter
- Titan Go offline contract integration
- production host permission-registration validation
- real Laravel/database installer execution

This prevents the extension and its copilots from claiming capabilities that do not yet exist.

## Pass 2 convergence — governed Titan wiring

- Legacy direct controller writes → `TimeCommandBusGateway` + extension capability executor.
- Caller/retry ambiguity → tenant-scoped command receipts and idempotency row locks.
- Legacy integer job/site references → optional canonical CRM `work_order_public_id` / `service_location_public_id`.
- Cross-extension ORM coupling → CRM capability adapter only.
- Local outbox only → tenant-partitioned `titan.signal` queue delivery.
- Generic role metadata → current Titan Workforce Tier 1/2 role definitions.
- Unscoped Signal retries → immutable tenant-carrying queue jobs.


## Pass 3 convergence — executable AI Workforce + proactive operations

- Static Workforce profiles → trusted `TimeWorkforceExecutionContext` plus bounded read/write `TimeWorkforceToolGateway`.
- Decorative agent capability claims → 18 real tools mapped to 14 active extension capabilities and seven validated skills.
- Generic AI writes → autonomy/risk/assurance decision gate plus authoritative Command Bus mutation gateway.
- Model-supplied lineage → rejected; tenant, actor, trace, correlation, causation and idempotency come from trusted runtime context.
- Passive dashboards → deterministic `TimeAttentionDetector` + durable attention finding lifecycle and five generative surface descriptors.
- Poll-only exception handling → Signal-triggered, tenant-idempotent Workforce workflow receipts.
- Planned configuration JSON → two active proposal-first wizards compiled by `TimeWizardRegistry` and finalized through governed `time.policy.update`.
- Basic offline storage → device-sequence replay protection, tenant-pseudonymous device identity and server-side attendance re-verification.
- Plain privacy digests → tenant-keyed HMAC minimisation for location, QR-token and IP evidence; missing host `APP_KEY` fails closed.
- Legacy integer-only cross-domain references → canonical CRM work-order/service-location public references retained and authority-checked.
- Premature dependency claims → installer metadata limited to implemented CRM, Workforce, Signal, Command Bus, Risk, Assurance and Autonomy ports/contributions.

### Still deferred after Pass 3

- richer time-entry correction/edit/delete workflows and compensating actions
- formal attendance-exception resolution mutation and approval UX
- full reporting/export suite and payroll hand-off contracts
- deeper Rewind/Wisdom/Governance/Vertical integrations (not advertised as live dependencies yet)
- production host permission bootstrap/registry verification
- live Laravel/MySQL migration/rollback/reinstall execution
- real queue-worker, Signal, Command Bus, CRM, Risk and Assurance integration tests against the target Titan Zero host
- final production performance/concurrency/adversarial hardening
