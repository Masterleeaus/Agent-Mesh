<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

final class ProviderCredential extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use HasUuids;

    protected $table = 'ext_titan_connect_provider_credentials';

    protected $fillable = [
        'uuid', 'company_id', 'provider', 'reference', 'encrypted_payload',
        'key_version', 'created_by', 'updated_by',
    ];

    protected $hidden = ['encrypted_payload'];

    protected $casts = [
        'company_id' => 'integer',
        'key_version' => 'integer',
        'created_by' => 'integer',
        'updated_by' => 'integer',
    ];

    public function uniqueIds(): array
    {
        return ['uuid'];
    }
}
