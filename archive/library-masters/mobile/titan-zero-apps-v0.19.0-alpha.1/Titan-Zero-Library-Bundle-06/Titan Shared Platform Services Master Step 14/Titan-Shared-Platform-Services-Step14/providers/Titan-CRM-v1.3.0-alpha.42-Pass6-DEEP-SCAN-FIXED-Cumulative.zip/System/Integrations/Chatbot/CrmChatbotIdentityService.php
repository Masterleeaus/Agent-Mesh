<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\Chatbot;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use App\Extensions\Crm\System\Contracts\{ContactRepositoryContract, LeadRepositoryContract};
use App\Extensions\Crm\System\Support\CrmNormalizer;
use App\Extensions\Crm\System\Services\CrmIdentityAuthorityService;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

final class CrmChatbotIdentityService
{
    public function __construct(
        private ConnectionInterface $db,
        private ContactRepositoryContract $contacts,
        private LeadRepositoryContract $leads,
        private CrmChatbotSettingsService $settings,
        private CrmIdentityAuthorityService $identityAuthority,
    ) {}

    public function syncCustomer(object $customer): array
    {
        $customerOwnerUserId = (int) $customer->getAttribute('user_id');
        $chatbotId = (int) $customer->getAttribute('chatbot_id');
        $userId = $this->trustedChatbotOwnerUserId($chatbotId, $customerOwnerUserId);
        $customerId = (int) $customer->getKey();
        $session = (string) ($customer->getAttribute('session_id') ?? '');
        if ($chatbotId <= 0 || $customerId <= 0 || $session === '') return ['identity_state'=>'anonymous','identity_confidence'=>0];

        $cfg = $this->settings->forChatbot($userId, $chatbotId);
        $email = CrmNormalizer::email($customer->getAttribute('email'));
        $phone = CrmNormalizer::phone($customer->getAttribute('phone'));
        $name = trim((string) ($customer->getAttribute('name') ?? ''));
        $channel = (string) ($customer->getAttribute('chatbot_channel') ?? 'frame');
        $sessionHash = hash('sha256', $session);

        $existing = $this->db->table('crm_chatbot_identities')
            ->where('company_id', CrmCompanyScope::companyId($userId))->where('chatbot_id',$chatbotId)->where('chatbot_customer_id',$customerId)->first();

        $contact = $this->matchContact($userId, $email, $phone);
        $createdContact = false;
        if (! $contact && (bool)($cfg['capture_contacts'] ?? true) && ($email || $phone)) {
            [$first,$last] = $this->splitName($name, $email);
            $contact = $this->contacts->create($userId, [
                'first_name'=>$first, 'last_name'=>$last, 'email'=>$email, 'phone'=>$phone,
                'meta'=>['source'=>'chatbot','chatbot_id'=>$chatbotId,'channel'=>$channel],
            ]);
            $createdContact = true;
        }

        $state = 'anonymous'; $confidence = 0;
        if ($email || $phone) { $state = 'captured'; $confidence = 40; }
        if ($contact) { $state = $createdContact ? 'captured' : 'matched'; $confidence = $createdContact ? 55 : 70; }
        if ($existing && $existing->verified_at) {
            $state = 'verified';
            $confidence = 100;
        }

        $leadPublicId = $existing?->crm_lead_public_id;
        if (! $leadPublicId && (bool)($cfg['create_lead_on_capture'] ?? true) && ($email || $phone)) {
            $lead = $this->findLead($userId,$email,$phone);
            if (! $lead) {
                $lead = $this->leads->create($userId, (int)($cfg['default_owner_user_id'] ?? $userId), [
                    'name'=>$this->displayName($name,$email,$phone), 'email'=>$email, 'phone'=>$phone,
                    'status'=>'new', 'source'=>'chatbot', 'owner_user_id'=>(int)($cfg['default_owner_user_id'] ?? $userId),
                    'notes'=>'Captured from Chatbot '.$chatbotId.' via '.$channel,
                ]);
            }
            $leadPublicId = $lead['public_id'] ?? null;
        }

        $companyPublicId = $contact ? $this->companyPublicIdForContact($userId, $contact) : null;
        $payload = [
            'crm_contact_public_id'=>$contact['public_id'] ?? $existing?->crm_contact_public_id,
            'crm_company_public_id'=>$companyPublicId ?? $existing?->crm_company_public_id,
            'crm_lead_public_id'=>$leadPublicId,
            'session_hash'=>$sessionHash,
            'channel'=>$channel,
            'identity_state'=>$state,
            'identity_confidence'=>$confidence,
            'verified_at'=>$state === 'verified' ? ($existing?->verified_at ?? now()) : null,
            'normalized_email'=>$email,
            'normalized_phone'=>$phone,
            'last_seen_at'=>now(),
            'metadata'=>json_encode(['chatbot_customer_name'=>$name]),
            'updated_at'=>now(),
        ];

        if ($existing) {
            $this->db->table('crm_chatbot_identities')->where('id',$existing->id)->update($payload);
        } else {
            $this->db->table('crm_chatbot_identities')->insert([
                'public_id'=>(string) Str::ulid(), 'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId), 'chatbot_id'=>$chatbotId,
                'chatbot_customer_id'=>$customerId, 'first_seen_at'=>now(), 'created_at'=>now(),
            ] + $payload);
        }
        if($contact && !empty($contact['public_id'])){
            $root=$this->identityAuthority->ensureRootForContact($userId,(string)$contact['public_id'],isset($contact['customer_company_id'])&&$contact['customer_company_id']?(int)$contact['customer_company_id']:null);
            $this->identityAuthority->linkExternalIdentity($userId,$root,'chatbot',(string)$chatbotId.':'.(string)$customerId,'contact',(string)$contact['public_id'],['channel'=>$channel,'verified'=>$state==='verified']);
        }
        return $this->byCustomer($userId,$chatbotId,$customerId) ?? $payload;
    }

    public function resolveForConversation(object $conversation): ?array
    {
        $customerId = (int) ($conversation->getAttribute('chatbot_customer_id') ?? 0);
        $chatbotId = (int) ($conversation->getAttribute('chatbot_id') ?? 0);
        if ($customerId <= 0 || $chatbotId <= 0 || ! class_exists(\App\Extensions\Chatbot\System\Models\ChatbotCustomer::class)) return null;
        $customer = \App\Extensions\Chatbot\System\Models\ChatbotCustomer::query()->whereKey($customerId)->where('chatbot_id',$chatbotId)->first();
        return $customer ? $this->syncCustomer($customer) : null;
    }

    public function byCustomer(int $userId,int $chatbotId,int $customerId): ?array
    {
        $row=$this->db->table('crm_chatbot_identities')->where('company_id', CrmCompanyScope::companyId($userId))->where('chatbot_id',$chatbotId)->where('chatbot_customer_id',$customerId)->first();
        return $row ? (array)$row : null;
    }

    private function matchContact(int $userId, ?string $email, ?string $phone): ?array
    {
        if (! $email && ! $phone) return null;
        $resolved=$this->identityAuthority->resolveByIdentity($userId,$email,$phone);
        if(($resolved['ambiguous']??false)||count($resolved['roots']??[])!==1)return null;
        $root=(string)$resolved['roots'][0]['customer_unification_id'];
        $row=$this->db->table(config('crm.tables.contacts'))->where('company_id', CrmCompanyScope::companyId($userId))->where('customer_unification_id',$root)->whereNull('deleted_at')->orderByDesc('is_primary')->orderBy('id')->first();
        return $row?(array)$row:null;
    }

    private function findLead(int $userId, ?string $email, ?string $phone): ?array
    {
        if (! $email && ! $phone) return null;
        $q=$this->db->table(config('crm.tables.leads'))->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at')->whereNotIn('status',['converted','lost']);
        $q->where(function($w) use($email,$phone): void { if($email)$w->orWhere('normalized_email',$email); if($phone)$w->orWhere('normalized_phone',$phone); });
        $row=$q->first(); return $row?(array)$row:null;
    }

    private function companyPublicIdForContact(int $userId,array $contact): ?string
    {
        $id=$contact['customer_company_id']??null; if(!$id)return null;
        return $this->db->table(config('crm.tables.companies'))->where('company_id', CrmCompanyScope::companyId($userId))->where('id',$id)->whereNull('deleted_at')->value('public_id');
    }

    private function trustedChatbotOwnerUserId(int $chatbotId, int $customerOwnerUserId): int
    {
        if ($chatbotId <= 0 || ! class_exists(\App\Extensions\Chatbot\System\Models\Chatbot::class)) {
            throw new \RuntimeException('CRM Chatbot company context cannot be resolved without the authoritative Chatbot record.');
        }
        $chatbot = \App\Extensions\Chatbot\System\Models\Chatbot::query()->whereKey($chatbotId)->first();
        $ownerUserId = (int) ($chatbot?->getAttribute('user_id') ?? 0);
        if ($ownerUserId <= 0 || ($customerOwnerUserId > 0 && $customerOwnerUserId !== $ownerUserId)) {
            throw new \RuntimeException('CRM Chatbot customer does not belong to the authoritative Chatbot owner.');
        }
        // This maps the authoritative Chatbot owner through trusted host company membership.
        CrmCompanyScope::companyId($ownerUserId);
        return $ownerUserId;
    }

    private function splitName(string $name, ?string $email): array
    {
        if ($name==='' || mb_strtolower($name)==='anonymous user') $name=$email?explode('@',$email,2)[0]:'Chatbot Customer';
        $parts=preg_split('/\s+/',trim($name),2) ?: [$name]; return [$parts[0] ?: 'Chatbot Customer',$parts[1]??null];
    }
    private function displayName(string $name,?string $email,?string $phone): string
    { if($name!==''&&mb_strtolower($name)!=='anonymous user')return $name; return $email?explode('@',$email,2)[0]:($phone?:'Chatbot enquiry'); }
}
