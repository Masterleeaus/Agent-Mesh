# Installer 1.7.3 MySQL Migration Hotfix 2.0.2

- Replaces the overlength `maps_field_route_optimisation_proposals_field_route_public_id_index` with explicit short index names.
- Makes `2026_08_18_000800_create_maps_field_route_optimisation_proposals.php` create-or-repair rather than returning when a table exists.
- Repairs indexes by ordered column set, so a retry is safe when the failed MySQL `Schema::create()` already left the table and earlier indexes behind.
- Adds a package-wide regression scanner enforcing MySQL's 64-character identifier limit.
