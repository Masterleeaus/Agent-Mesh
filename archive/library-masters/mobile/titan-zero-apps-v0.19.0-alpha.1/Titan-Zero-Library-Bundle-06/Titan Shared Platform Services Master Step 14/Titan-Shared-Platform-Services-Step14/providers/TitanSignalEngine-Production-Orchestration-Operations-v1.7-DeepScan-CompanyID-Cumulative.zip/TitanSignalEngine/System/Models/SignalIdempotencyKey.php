<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalIdempotencyKey extends Model
{
    protected $table = 'titan_signal_idempotency_keys';
    protected $guarded = [];

    protected $casts = [
        'tenant_company_id' => 'integer',
        'expires_at' => 'immutable_datetime',
    ];
}
