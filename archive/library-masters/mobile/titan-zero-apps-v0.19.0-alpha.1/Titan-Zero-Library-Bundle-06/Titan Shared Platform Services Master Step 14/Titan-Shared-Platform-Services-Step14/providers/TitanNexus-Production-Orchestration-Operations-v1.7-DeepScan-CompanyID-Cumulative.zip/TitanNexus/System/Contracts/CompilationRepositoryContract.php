<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Contracts;

use App\Extensions\TitanNexus\System\Domain\NexusCompilation;

interface CompilationRepositoryContract
{
    public function save(NexusCompilation $compilation): NexusCompilation;

    public function findForTenant(int $tenantCompanyId, string $compilationUuid): ?NexusCompilation;

    /** @return list<NexusCompilation> */
    public function latestForTenant(int $tenantCompanyId, int $limit = 25): array;

    /** @return list<NexusCompilation> */
    public function lineageForTenant(int $tenantCompanyId, string $compilationUuid, int $limit = 25): array;
}
