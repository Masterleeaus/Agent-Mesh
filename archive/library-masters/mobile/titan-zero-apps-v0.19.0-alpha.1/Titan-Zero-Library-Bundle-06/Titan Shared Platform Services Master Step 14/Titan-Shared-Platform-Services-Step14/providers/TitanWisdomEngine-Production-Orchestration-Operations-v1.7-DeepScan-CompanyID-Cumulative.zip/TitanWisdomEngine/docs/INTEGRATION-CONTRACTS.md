# Integration Contracts

Cross-engine integration must use public capability contracts/adapters rather than another extension's internal namespace.

Active schema-backed contracts:

- `wisdom.outcome.record`: `wisdom-outcome-record-input.schema.json` -> `wisdom-outcome-record-receipt.schema.json`
- `wisdom.evidence.attach`: `wisdom-evidence-attach-input.schema.json` -> `wisdom-evidence-attach-receipt.schema.json`
- `wisdom.outcome.resolve`: `wisdom-outcome-resolve-input.schema.json` -> `wisdom-outcome-resolve-receipt.schema.json`
- `wisdom.outcome.revise`: `wisdom-outcome-revise-input.schema.json` -> `wisdom-outcome-record-receipt.schema.json`
- delayed observation event: `wisdom-outcome-observation-due.schema.json`

Signal integrations normalize source events into EvidenceReference drafts and submit them through `wisdom.evidence.attach`; Wisdom does not import Titan Signal implementation classes. Governance output is similarly adapted into the local immutable GovernanceDecision contract.
