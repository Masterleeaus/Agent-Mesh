# Titan Installer Contract
Release: `0.5.0-alpha.4` — Installer 1.7.6 compatibility hotfix H1

The live Titan host reports Extension Manager build `1.7.6`. That validator still requires marketplace identity fields in the root `extension.json`, including a valid `name`, while Titan's newer package contract also uses schema/slug/folder/provider/integrity metadata.

This package therefore uses a backward-compatible root manifest containing both sets:

- current-host identity: `name`, `type`, `version`, `description`, `support_telegram`
- Titan package identity: `schema`, `slug`, `folder`, `provider`
- Installer 1.7.6 install metadata: `migrations`, `dependencies`, `optional_dependencies`, `requires`, `publishes`
- exact package integrity: `integrity.files`

The canonical rich architecture remains in `extension.manifest.json` schema `2.2`. No Knowledge Authority runtime capability or data model is downgraded by this compatibility shim.

## Compatibility priority

The live Installer 1.7.6 contract is authoritative for H1 because that is the installer actually executing the package. A strict Installer 1.7.8 validator that demands an exactly six-field root manifest is intentionally not the target of this hotfix; when the host itself is upgraded, the root manifest can return to the minimal 1.7.8 shape without changing the sidecar or runtime code.
