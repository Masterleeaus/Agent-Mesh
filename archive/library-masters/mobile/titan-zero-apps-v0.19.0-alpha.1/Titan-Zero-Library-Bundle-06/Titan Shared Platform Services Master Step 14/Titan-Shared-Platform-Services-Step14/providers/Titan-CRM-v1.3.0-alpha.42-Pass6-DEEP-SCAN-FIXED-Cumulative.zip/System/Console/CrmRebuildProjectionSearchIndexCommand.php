<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\ReadModels\CrmProjectionSearchIndexer;
use Illuminate\Console\Command;

final class CrmRebuildProjectionSearchIndexCommand extends Command
{
    protected $signature='crm:projections:search-index {company_id : Canonical tenant company ID} {--projection= : Optional projection name} {--batch=500 : Projection-row batch size}';
    protected $description='Rebuild the disposable CRM projection search-term index without reading authoritative CRM tables.';
    public function handle(CrmProjectionSearchIndexer $indexer): int{$tenant=(int)$this->argument('company_id');if($tenant<1){$this->error('company_id must be a positive integer.');return self::FAILURE;}$result=$indexer->reindexExisting($tenant,trim((string)$this->option('projection'))?:null,(int)$this->option('batch'));$this->line(json_encode($result,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));return self::SUCCESS;}
}
