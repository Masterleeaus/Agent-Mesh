# Titan Nexus Control Centre Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a tenant-scoped, read-first Nexus Control Centre with Blueprint v2.2 interface contribution and MagicAI-compatible routes/views without adding a new mutation path.

**Architecture:** A pure read-model service consumes `CompilationRepositoryContract`, redacts historical payloads, and produces a deterministic Control Centre snapshot. Controllers resolve tenant context through a public/configurable resolver and render named read-only sections. Titan Interface Runtime receives declarative read-model contributions only.

**Tech Stack:** PHP 8.2+, Laravel 10, Blade, Titan Extension Manifest v2.2, Titan Interface Contribution v1.1.

**Spec:** `docs/superpowers/specs/2026-08-20-nexus-control-centre-design.md`

## Global Constraints
- Keep compiler semantics at version `0.5.0`.
- Nexus runtime becomes `0.8.0`.
- Preserve all three existing migrations byte-for-byte.
- No controller or Control Centre service may directly query another engine or mutate authoritative state.
- All compilation reads require a positive `tenant_company_id`.
- Control Centre history and lineage are bounded to 50 records.
- Historical payload rendering must be recursively redacted.
- Views must use `panel.layout.app` and named routes.
- Interface contribution must contain no mutating action.

---

### Task 1: Tenant context and redacted read model
**Files:**
- Create: `System/Contracts/TenantContextResolverContract.php`
- Create: `System/Contracts/NexusControlCentreContract.php`
- Create: `System/Support/RedactedPayload.php`
- Create: `System/Host/HostTenantContextResolver.php`
- Create: `System/Domain/ControlCentreSnapshot.php`
- Create: `System/Services/NexusControlCentreService.php`
- Test: `tests/standalone-control-centre-check.php`

**Interfaces:**
- Consumes: `CompilationRepositoryContract::latestForTenant()`, `findForTenant()`, `lineageForTenant()`.
- Produces: `TenantContextResolverContract::resolve(?object $user): int` and `NexusControlCentreContract::snapshot(int $tenantCompanyId, ?string $compilationUuid = null): ControlCentreSnapshot`.

- [ ] Write a standalone test proving tenant resolution, redaction, tenant-scoped history, selected detail, empty states, and derived summaries.
- [ ] Run the test and confirm it fails because the Pass-7 classes are absent.
- [ ] Implement the minimal contracts/value object/support/service needed by the test.
- [ ] Run the standalone test and confirm it passes.

### Task 2: Controllers, routes and host views
**Files:**
- Create: `System/Http/Controllers/ControlCentreController.php`
- Modify: `System/Http/Controllers/AdminController.php`
- Modify: `routes/user.php`
- Modify: `routes/admin.php`
- Replace: `resources/views/index.blade.php`
- Replace: `resources/views/admin.blade.php`
- Create: `resources/views/partials/control-centre-nav.blade.php`
- Test: `tests/standalone-control-centre-package-check.php`

**Interfaces:**
- Consumes: `TenantContextResolverContract`, `NexusControlCentreContract`.
- Produces: named routes for overview/profile/compilations/validation/preview/history/diff/provisioning/receipts/detail.

- [ ] Write static package checks for named routes, `panel.layout.app`, tenant-safe controller dependencies, and absence of direct database access.
- [ ] Run the test and confirm it fails before route/controller/view implementation.
- [ ] Implement controllers/routes/views using only the read-model contracts.
- [ ] Run the package check and confirm it passes.

### Task 3: Blueprint interface contribution and runtime metadata
**Files:**
- Create: `resources/interface/interface-manifest.json`
- Modify: `extension.manifest.json`
- Modify: `config/titan-nexus.php`
- Modify: `System/TitanNexusServiceProvider.php`
- Modify: `System/Services/NexusManager.php`
- Modify: `README.md`
- Modify: `CHANGELOG.md`

**Interfaces:**
- Consumes: Titan Interface Contribution v1.1 and manifest v2.2.
- Produces: `interface_contribution` declaration and `nexus.control-centre` capability.

- [ ] Add a read-only interface contribution for Nexus compilation/profile/validation/configuration/diff/provisioning views.
- [ ] Bind Control Centre and tenant resolver contracts in the provider.
- [ ] Advance runtime metadata to `0.8.0` while retaining compiler version `0.5.0`.
- [ ] Validate manifest and interface contribution against the merged Blueprint schemas.

### Task 4: Full compatibility and packaging verification
**Files:**
- Modify: `tests/standalone-package-check.php`
- Modify: `extension.json` integrity map after all source changes.

**Interfaces:**
- Consumes: all earlier Pass-7 files.
- Produces: Installer 1.7.8 flat-root cumulative ZIP.

- [ ] Run all standalone suites.
- [ ] Lint every PHP file and parse every JSON file.
- [ ] Run Blueprint manifest, interface, package and architecture validation.
- [ ] Verify the three parent migrations are byte-identical.
- [ ] Regenerate `extension.json` `integrity.files` excluding only `extension.json`.
- [ ] Build the flat-root cumulative ZIP, re-extract it cleanly, and rerun all release gates on the exact packaged bytes.
