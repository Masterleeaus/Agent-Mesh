<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Onboarding;

use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ProviderCredential;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

final class ProviderCredentialStore
{
    public function store(int $companyId, int $actorId, ChannelConnection $connection, array $credentials, bool $activate = true): string
    {
        if ((int) $connection->company_id !== $companyId || $credentials === []) throw new RuntimeException('Invalid provider credential scope.');
        $reference = trim((string) ($connection->credential_reference ?? ''));
        if ($reference === '' || ! str_starts_with($reference, 'vault_')) $reference = 'vault_'.Str::lower((string) Str::ulid());
        $encrypted = Crypt::encryptString(json_encode($credentials, JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES));
        DB::transaction(function () use ($companyId,$actorId,$connection,$reference,$encrypted,$activate): void {
            $record = ProviderCredential::query()->firstOrNew(['company_id' => $companyId, 'provider' => $connection->provider, 'reference' => $reference]);
            if (! $record->exists) { $record->uuid = (string) Str::uuid(); $record->created_by = $actorId; }
            $record->encrypted_payload = $encrypted; $record->key_version = max(1, (int) $record->key_version + 1); $record->updated_by = $actorId; $record->save();
            $changes = ['credential_reference' => $reference]; if ($activate) $changes['status'] = 'active'; $connection->forceFill($changes)->save();
        });
        return $reference;
    }
}
