<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Health;

use App\Extensions\TitanSignalEngine\System\Contracts\ExtensionHealth;
use App\Extensions\TitanSignalEngine\System\Services\SignalOperationalHealthService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Throwable;

final class TitanSignalEngineHealthCheck implements ExtensionHealth
{
    public function __construct(private readonly ?SignalOperationalHealthService $operationalHealth = null) {}

    public function snapshot(): array
    {
        $readiness = $this->readiness();
        $liveness = $this->liveness();
        return ['status' => $readiness['status'] === 'HEALTHY' ? $liveness['status'] : $readiness['status'], 'checks' => array_merge($liveness['checks'], $readiness['checks']), 'observed_at' => now()->toIso8601String()];
    }

    public function liveness(): array
    {
        $enabled = (bool) config('titan-signal-engine.enabled', true);
        $state = strtoupper((string) config('titan-signal-engine.runtime_state', 'ACTIVE'));
        $rolloutStage = strtoupper((string) config('titan-signal-engine.rollout_stage', 'INTERNAL'));
        $status = match (true) { ! $enabled, $state === 'DISABLED' => 'DISABLED', $state === 'MAINTENANCE' => 'MAINTENANCE', $state === 'DRAINING' => 'DRAINING', default => 'HEALTHY' };
        return ['status' => $status, 'checks' => ['extension' => $enabled ? 'HEALTHY' : 'DISABLED', 'runtime_state' => $state, 'rollout_stage' => $rolloutStage], 'observed_at' => now()->toIso8601String()];
    }

    public function readiness(): array
    {
        $live = $this->liveness();
        if ($live['status'] !== 'HEALTHY') return $live;
        $checks = [];
        $status = 'HEALTHY';
        try { DB::connection()->getPdo(); $checks['database'] = 'HEALTHY'; } catch (Throwable) { $checks['database'] = 'UNAVAILABLE'; $status = 'UNAVAILABLE'; }
        try { Storage::disk((string) config('titan-signal-engine.archive_disk', 'local')); $checks['archive_storage'] = 'HEALTHY'; } catch (Throwable) { $checks['archive_storage'] = 'UNAVAILABLE'; $status = 'UNAVAILABLE'; }

        $operational = $this->operationalHealth?->snapshot();
        $current = is_array($operational) ? (array) ($operational['current'] ?? []) : [];
        $checks['delivery_backlog'] = (bool) ($current['backpressured'] ?? false) ? 'DEGRADED' : 'HEALTHY';
        $pulseStatus = (string) ($current['pulse_projection_status'] ?? 'idle');
        $checks['pulse_projection'] = $pulseStatus === 'degraded' ? 'DEGRADED' : ($pulseStatus === 'not_initialized' ? 'UNKNOWN' : 'HEALTHY');
        if ($status === 'HEALTHY' && (in_array('DEGRADED', $checks, true))) $status = 'DEGRADED';
        return ['status' => $status, 'checks' => $checks, 'observed_at' => now()->toIso8601String()];
    }
}
