# CRM Alpha.7 Mobile + Financial AI Integration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build CRM 1.3.0-alpha.7 by integrating Titan Hub/Titan Go/Titan BOS clean mobile identities and absorbing Titan Financial Engine v0.4.1 into CRM as deterministic, AI-guided contextual financial assistants, with Quote/Estimate as the first embedded workflow.

**Architecture:** Financial calculations live under `System/Domains/FinanceAssistants` and are deterministic fixed-point services copied/adapted from Titan Financial Engine; no standalone Financial Engine provider, dashboard, tables, or runtime dependency is retained. CRM/MagicAI/TitanAI provide the conversational guidance layer: AI gathers context, explains and recommends inputs, calls read-only deterministic finance capabilities, and uses existing approval-governed CRM write capabilities for any document mutation. Mobile identity changes are a selective merge into the current alpha.6 tree so newer Pay/Locker/navigation/runtime fixes remain authoritative.

**Tech Stack:** PHP 8.3, Laravel 10.50, MagicAI v11 extension conventions, MySQL, Blade, Titan capability registry/TitanAI bridge, fixed-point decimal arithmetic.

## Global Constraints

- CRM tenant authority remains `tenant_company_id`.
- CRM `company_id` remains a customer/account relationship and must not become tenancy.
- `user_id` remains actor/provenance/assignee where legitimate.
- No WorkCore runtime dependency.
- No Titan Financial Engine runtime dependency after integration.
- Titan Mobile compatibility floor becomes `>=0.20 <1.0`.
- Mobile technical identities are `TitanHub`, `TitanGo`, and `TitanBOS`; legacy `TitanCustomer`, `TitanFieldOffline`, and `TitanOwnerPWA` references are forbidden in active Titan Mobile integration code.
- User-facing navigation uses `Leads`, not `Sales` or `New Work` as the parent for lead/quote acquisition work.
- User-facing customer surface is `Customer Hub`, linked to Titan Hub; internal legacy portal table names may remain for migration safety.
- AI may interpret intent, gather CRM context, recommend values, explain results, and propose changes, but financial arithmetic is always produced by deterministic calculator services.
- Deterministic finance capabilities are read-only calculations and never require approval; applying a quote/invoice/job mutation continues through existing write capability approval/idempotency rules.
- CRM buttons must remain theme-controlled; do not introduce hard-coded colour palettes.
- No new schema is required for this pass unless a later implementation check proves unavoidable.

---

### Task 1: Clean Titan Mobile identities

**Files:**
- Modify: `System/Integrations/TitanMobile/CrmCustomerOperationsGateway.php`
- Modify: `System/Integrations/TitanMobile/CrmFieldOfflineSourceGateway.php`
- Modify: `System/Integrations/TitanMobile/CrmMobileIdentityResolver.php`
- Modify: `System/Integrations/TitanMobile/CrmOwnerActionGateway.php`
- Modify: `System/Integrations/TitanMobile/CrmOwnerDashboardGateway.php`
- Modify: `System/Integrations/TitanMobile/CrmTitanMobileIntegrationRegistrar.php`
- Modify: `extension.manifest.json`
- Create: `tests/TitanMobileCleanIdentityTest.php`

**Interfaces:**
- Consumes: current alpha.6 Titan Mobile gateway behavior.
- Produces: the same behavior using `App\\Extensions\\TitanHub`, `App\\Extensions\\TitanGo`, and `App\\Extensions\\TitanBOS` contracts with manifest compatibility `>=0.20 <1.0`.

- [ ] **Step 1: Write the failing identity regression test** asserting the six active integration files contain the clean namespaces and no legacy namespace strings.
- [ ] **Step 2: Run the test and verify it fails** against alpha.6 because legacy namespaces are still present.
- [ ] **Step 3: Apply only the six isolated identity substitutions** proven by the CRM(2).zip three-way scan; do not copy donor release metadata or older files wholesale.
- [ ] **Step 4: Update only the Titan Mobile compatibility floor** in the current `extension.manifest.json` to `>=0.20 <1.0`.
- [ ] **Step 5: Run the identity test and PHP lint** and verify all six files are green.

### Task 2: Port the deterministic financial calculation kernel

**Files:**
- Create: `System/Domains/FinanceAssistants/Calculating/Contracts/CalculatingEngine.php`
- Create: `System/Domains/FinanceAssistants/Calculating/DTO/CalculationContext.php`
- Create: `System/Domains/FinanceAssistants/Calculating/DTO/CalculationResult.php`
- Create: `System/Domains/FinanceAssistants/Calculating/Support/Decimal.php`
- Create: `System/Domains/FinanceAssistants/Calculating/Engines/*.php` for all 17 donor engines
- Create: `System/Domains/FinanceAssistants/Calculating/Services/CalculatingEngineService.php`
- Create: `System/Domains/FinanceAssistants/Support/FinanceAssistantCatalog.php`
- Create: `System/Domains/FinanceAssistants/Support/AssistantInputAdapter.php`
- Test: `tests/FinanceAssistantKernelTest.php`

**Interfaces:**
- Consumes: structured scalar/array inputs and optional prior calculation state.
- Produces: deterministic `CalculationResult` values for `pricing`, `quote_estimate`, `labour_rate`, `job_costing`, `margin_profitability`, `discount_promotion`, `tax`, `inventory_materials_cost`, `asset_fleet_equipment_cost`, `procurement_landed_cost`, `recurring_pricing`, `payment_settlement_cost`, `commission_incentive`, `finance_instalment`, `forecast_cash_flow`, `break_even_scenario`, and `formula_rules`.

- [ ] **Step 1: Write failing kernel tests** that require all 17 engine keys and verify representative fixed-point results for target-margin pricing, GST inclusive/exclusive, quote subtotal, material pack rounding, margin, instalment, and break-even calculations.
- [ ] **Step 2: Run the kernel test and verify it fails** because the CRM-native finance namespace does not exist.
- [ ] **Step 3: Port only the donor calculating kernel and human assistant definitions**, changing namespaces to `App\\Extensions\\Crm\\System\\Domains\\FinanceAssistants`; do not port Financial Engine models, migrations, routes, standalone dashboards, settings tables, promotion CRUD, or providers.
- [ ] **Step 4: Register all 17 engine classes in `FinanceAssistantCatalog`/`CalculatingEngineService`** and preserve deterministic fixed-point arithmetic.
- [ ] **Step 5: Run the kernel tests and PHP lint** and verify no `TitanFinancialEngine` runtime namespace remains in the ported classes.

### Task 3: Build CRM financial context and AI guidance contracts

**Files:**
- Create: `System/Domains/FinanceAssistants/FinanceAssistantService.php`
- Create: `System/Domains/FinanceAssistants/FinanceAssistantContextService.php`
- Create: `System/Domains/FinanceAssistants/FinanceAssistantAiGuidance.php`
- Create: `System/Domains/FinanceAssistants/QuoteAssistantContextBuilder.php`
- Modify: `System/CrmServiceProvider.php`
- Test: `tests/FinanceAssistantAiGuidanceTest.php`

**Interfaces:**
- `FinanceAssistantService::calculate(int $userId, string $assistant, array $inputs, array $context = []): array`
- `FinanceAssistantContextService::context(int $userId, string $surface, array $references = []): array`
- `FinanceAssistantAiGuidance::prompt(string $assistant, array $businessContext, array $currentInputs = []): string`
- `QuoteAssistantContextBuilder::build(int $userId, array $references = []): array`

- [ ] **Step 1: Write failing tests** requiring deterministic calculation envelopes to include assistant metadata, inputs, results, warnings and provenance, and requiring the AI prompt to explicitly state that AI must not perform authoritative arithmetic.
- [ ] **Step 2: Run and verify RED** because the services do not exist.
- [ ] **Step 3: Implement `FinanceAssistantService`** as the single CRM-native calculation façade over the 17 engines.
- [ ] **Step 4: Implement contextual data collection** using existing CRM tables/services for quote/job/customer context; missing data must be represented as missing rather than guessed.
- [ ] **Step 5: Implement AI guidance prompt construction** instructing AI to interpret intent, explain choices, request missing values, call deterministic finance capabilities for arithmetic, and use approved CRM writes only when the user accepts a proposal.
- [ ] **Step 6: Register the new services after core CRM dependencies** so Titan provider-stage installation cannot eagerly resolve database-heavy services.
- [ ] **Step 7: Run tests and lint**.

### Task 4: Expose governed finance capabilities to TitanAI and CRM Assistant

**Files:**
- Modify: `System/Capabilities/CrmCapabilityManifest.php`
- Modify: `System/Providers/CrmFinanceLockerServiceProvider.php`
- Modify: `System/Integrations/TitanAI/CrmTitanAIToolProvider.php`
- Modify: `System/AI/CrmAssistantExecutionService.php`
- Modify: `System/Services/CrmAssistantChatService.php`
- Test: `bin/verify-v130-alpha7-finance-ai.php`

**Interfaces:**
- Produces read-only capability IDs `crm.finance.<engine>.calculate` for all 17 calculators.
- AI write path remains existing `crm.quote.prepare` or normal sales-document create/update approval path; finance calculator capabilities never write records.

- [ ] **Step 1: Write a failing capability verifier** requiring all 17 calculator capabilities, bindings, TitanAI exposure, and finance instructions in the MagicAI CRM Assistant prompt.
- [ ] **Step 2: Run and verify RED** because the capability IDs are absent.
- [ ] **Step 3: Add 17 read-only capability definitions** under a finance permission appropriate to existing CRM finance visibility.
- [ ] **Step 4: Bind the capabilities lazily** to `FinanceAssistantService::calculate()` in `CrmFinanceLockerServiceProvider` so provider boot does not instantiate calculator context services eagerly.
- [ ] **Step 5: Add the finance calculation tools to `CrmTitanAIToolProvider::READS`** so TitanAI can call them without approval.
- [ ] **Step 6: Add legacy MagicAI assistant execution aliases** for the finance calculators and extend the system prompt with deterministic-finance rules and contextual assistant behavior.
- [ ] **Step 7: Run the capability verifier, provider-stage verifier and lint**.

### Task 5: Embed AI-guided finance into Quote/Estimate creation

**Files:**
- Create: `System/Http/Controllers/FinanceAssistantController.php`
- Modify: `System/Http/Controllers/CrmPageController.php`
- Modify: `routes/web.php`
- Modify: `resources/views/sales/create.blade.php`
- Create: `resources/views/finance-assistants/quote-panel.blade.php`
- Test: `bin/verify-v130-alpha7-quote-assistant.php`

**Interfaces:**
- GET/POST contextual assistant endpoints operate within the authenticated CRM tenant.
- Quote create screen receives `financeAssistants` and `financeContext` from CRM services.
- The embedded panel supports quote estimate, pricing, margin, discount, GST, labour and materials calculations and can copy/apply suggested sell values into unsaved form lines client-side; persistence still occurs only when the normal quote form is submitted.

- [ ] **Step 1: Write a failing quote integration verifier** requiring the contextual panel, route/controller, seven quote-relevant assistants, AI-guidance copy, deterministic calculate endpoint and theme-controlled buttons.
- [ ] **Step 2: Run and verify RED**.
- [ ] **Step 3: Add tenant-authenticated calculation endpoint** validating assistant key and structured inputs before calling `FinanceAssistantService`.
- [ ] **Step 4: Pass quote context into `salesCreate()`** including any selected customer/work-order/service references supplied by query parameters.
- [ ] **Step 5: Build the embedded Financial AI panel** with plain-language guidance, “Use current CRM costs” defaults, calculator controls/results, and an explicit “Apply suggestion” action that changes only the unsaved form.
- [ ] **Step 6: Add an “Ask AI” affordance** that opens the CRM/MagicAI assistant with a finance/quote scope and contextual prompt seed; do not fake an AI response locally.
- [ ] **Step 7: Ensure all action styling uses theme classes only** and run verifier/lint.

### Task 6: Add contextual finance entry points across Work, Money, Crew and Gear

**Files:**
- Modify: `System/Domains/FinanceAssistants/Support/FinanceAssistantCatalog.php`
- Modify: relevant existing Work/Locker/Bookkeeping views without restructuring their domain controllers
- Test: `bin/verify-v130-alpha7-contextual-finance.php`

**Interfaces:**
- Context map:
  - Leads/Quotes: quote, pricing, margin, discount, GST, labour, materials
  - Work: job costing, profitability, labour, materials, asset/equipment cost
  - Money: GST, payment settlement cost, instalment, cash flow, break-even
  - Crew: labour rate, commission/incentive
  - Gear: materials cost, landed cost, asset/fleet/equipment cost
  - Recurring Work: recurring pricing

- [ ] **Step 1: Write a failing contextual-placement verifier** requiring the catalog surface map and contextual links/panels in at least Work, Bookkeeping/Pay and Locker screens.
- [ ] **Step 2: Run and verify RED**.
- [ ] **Step 3: Implement the surface map** in the catalog so AI and UI share one source of truth.
- [ ] **Step 4: Add lightweight theme-controlled assistant entry points** to existing Work, Money/Bookkeeping and Gear/Locker screens; avoid creating 17 sidebar children.
- [ ] **Step 5: Run the verifier and lint**.

### Task 7: Apply approved product terminology

**Files:**
- Modify: `System/Navigation/CrmMenuDefinition.php`
- Modify: `System/Navigation/CrmMenuInstaller.php`
- Modify: customer-hub/portal views and relevant documentation strings
- Modify: mobile integration wording where current product names are shown
- Test: `bin/verify-v130-alpha7-product-terminology.php`

**Interfaces:**
- Top-level acquisition parent label is `Leads`.
- User-facing customer self-service/relationship label is `Customer Hub` and references Titan Hub as the linked mobile app/PWA.
- Internal legacy portal routes/tables may retain identifiers for backwards compatibility.

- [ ] **Step 1: Write a failing terminology verifier** requiring `Leads` and `Customer Hub` and forbidding `New Work` in active navigation plus `Customer Portal` in the customer-hub management UI.
- [ ] **Step 2: Run and verify RED** where alpha.6 still uses older labels.
- [ ] **Step 3: Update menu labels and customer-hub wording without renaming stable DB tables/routes**.
- [ ] **Step 4: Run the verifier and lint**.

### Task 8: Release hardening and package CRM 1.3.0-alpha.7

**Files:**
- Modify: `extension.json`
- Modify: `extension.manifest.json`
- Modify: `CHANGELOG.md`
- Create: `CHANGELOG_v1.3.0_ALPHA7_MOBILE_FINANCIAL_AI.md`
- Modify: `README.md`
- Modify: `bin/verify.php`
- Regenerate: `FILE-SHA256.json`

**Interfaces:**
- Produces the flat Titan installer ZIP `MagicAI-CRM-1.3.0-alpha.7-Titan-Installer-Ready.zip`.

- [ ] **Step 1: Set release metadata to `1.3.0-alpha.7`** and document the mobile identity and native Financial AI integration.
- [ ] **Step 2: Add all alpha.7 regression gates to the master verifier**.
- [ ] **Step 3: Run all PHP lint, JSON parsing, migration reversibility, provider-stage, MySQL/restartability, Pay/Locker/Bookkeeping, alpha.6 navigation/runtime, mobile identity and alpha.7 finance-AI gates**.
- [ ] **Step 4: Verify active runtime contains zero `App\\Extensions\\TitanFinancialEngine` and zero legacy Titan Mobile namespace references in active integration code**.
- [ ] **Step 5: Regenerate `FILE-SHA256.json` only after the source tree is frozen**.
- [ ] **Step 6: Run the master Titan installer verifier against the frozen tree**.
- [ ] **Step 7: Build the flat ZIP and fresh-extract it**.
- [ ] **Step 8: Re-run archive safety, PHP/JSON checks and the master verifier on the extracted ZIP**.
- [ ] **Step 9: Produce upgrade report and SHA-256 checksum**.
