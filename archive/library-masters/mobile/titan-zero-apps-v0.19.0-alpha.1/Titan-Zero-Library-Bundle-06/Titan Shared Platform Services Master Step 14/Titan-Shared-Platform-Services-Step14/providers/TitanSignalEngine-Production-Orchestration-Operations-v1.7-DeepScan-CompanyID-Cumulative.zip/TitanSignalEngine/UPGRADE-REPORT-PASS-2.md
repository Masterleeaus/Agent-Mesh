# Titan Signal Engine — Pass 2 / v0.2.1 Foundation Hardening

## Purpose

Prove and harden the v0.2.0 foundation before Correlation, subscriptions and Pulse depend on the envelope/storage contract.

## Implemented

1. Envelope format versioning (`1.0`).
2. UUIDv7 generation for new canonical IDs with legacy UUID compatibility.
3. Root causation identity and indexed root-chain retrieval.
4. Structured actor representation, identity provider and session identity.
5. Trusted SignalContext with tenant/actor anti-spoofing and system-read permissions.
6. Explicit SHA-256 checksum algorithm plus runtime verification.
7. Global severity enum/weights.
8. Event Type Registry with persisted definitions and ingest-time schema/scope/source/payload validation.
9. Independent payload and metadata limits plus hidden-reasoning-key guard.
10. TTL-based idempotency leases, request-fingerprint collision protection and original-event duplicate receipts.
11. Store-level causation boundary validation for tenant/scope/trace/correlation/root, including late parent arrival.
12. Logged immutable update/delete rejection.
13. Query-layer tamper rejection.
14. Additive migrations for registry/idempotency/hardening fields and indexes.
15. Compatibility checksum/root backfill for prior events.
16. Standalone behavior suite plus host-Laravel integration test definitions.

## Deliberately deferred

Correlation graph edges, trace profiles, queues/subscriptions, Pulse, anomaly detection, retention/archive/redaction and console UI remain later passes.
