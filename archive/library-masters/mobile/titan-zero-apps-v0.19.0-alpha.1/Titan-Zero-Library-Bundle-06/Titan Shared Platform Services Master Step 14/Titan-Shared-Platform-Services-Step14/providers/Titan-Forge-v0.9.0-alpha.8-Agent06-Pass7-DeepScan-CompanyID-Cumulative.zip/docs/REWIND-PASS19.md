# Titan Forge Pass 19 — Titan Rewind deterministic reconstruction

## Contract

Forge implements Blueprint v4.2.1's host-owned `App\Support\Extensions\RewindSourceAdapter` and contributes `titan-forge.rewind-source` to `titan.rewind.sources.v1`. The contribution is `authority_neutral: true` and `write_policy: read-only`.

Forge does not import `App\Extensions\TitanRewind` internals and does not write Rewind-owned persistence. The current Titan Rewind v1.0.6 signed artifact identity was observed during contract discovery, but its ZIP was not available for direct inspection in this pass; the integration therefore targets the canonical Blueprint v4.2.1 host contract rather than private Rewind implementation classes.

## Evidence projected

The source exposes bounded durable facts for build state, plans, artifact receipts, validation runs, Shield, Risk, governed Model Council decisions, Governance state, release candidates and Forge receipts. Child evidence inherits the build's actor/correlation/causation/root-causation/operation lineage.

It never exports raw build instructions, generated artifact content, validation message bodies, Council participant responses/final-answer text, credentials or hidden reasoning. Peer-owned evidence is referenced by stable IDs and SHA-256 hashes where available.

## Ordering and integrity

Forge-owned database reads are tenant + trace scoped and cursor-backed. Facts are emitted in deterministic evidence-phase order. `ForgeRewindProjector` enforces strictly increasing source sequences and streams canonical events rather than materializing the source trace to sort it.

Each event has a canonical source hash, deterministic event UUID, `previous_hash` and canonical SHA-256 `integrity_hash`. `ForgeReconstructionService` recomputes every event hash and verifies the chain; it does not trust a supplied integrity value blindly.

## Completeness versus reproducibility

`watermark()` streams the current source and may report `COMPLETE` when all Forge evidence visible for the trace was read and hashed. That does **not** mean historical point-in-time replay is fully reproducible.

Forge currently declares `supports_as_of=false`. The build record can change over its lifecycle, so Forge cannot truthfully reconstruct what that mutable row looked like at an arbitrary past timestamp. Non-null `asOf` requests fail closed. Reconstruction therefore reports `PARTIALLY_REPRODUCIBLE` until an immutable lifecycle-history source exists.

## Authority boundary

Rewind reconstruction is forensic/read-only. It cannot approve, install, release, roll back or mutate generated packages. Forge retains `deployment_authority: none`; Governance and Command Bus remain the approval/execution boundaries.

## Certification scope

This pass is statically/package certified against Blueprint v4.2.1 and Forge's standalone tests. No live deployed MagicAI/Titan host certification is claimed.
