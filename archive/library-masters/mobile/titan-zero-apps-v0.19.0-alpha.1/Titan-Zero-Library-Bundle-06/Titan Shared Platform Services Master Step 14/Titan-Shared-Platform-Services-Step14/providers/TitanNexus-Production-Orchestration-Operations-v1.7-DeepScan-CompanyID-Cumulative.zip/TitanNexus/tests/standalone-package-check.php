<?php

declare(strict_types=1);

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }

function failCheck(string $message): never
{
    fwrite(STDERR, "FAIL: {$message}\n");
    exit(1);
}

function requireFileContains(string $root, string $relative, array $needles): void
{
    $path = $root . '/' . $relative;
    if (!is_file($path)) {
        failCheck("missing {$relative}");
    }
    $contents = file_get_contents($path);
    if (!is_string($contents)) {
        failCheck("cannot read {$relative}");
    }
    foreach ($needles as $needle) {
        if (!str_contains($contents, $needle)) {
            failCheck("{$relative} missing required token: {$needle}");
        }
    }
}

requireFileContains($root, 'System/Contracts/CompilationRepositoryContract.php', [
    'findForTenant(int $tenantCompanyId, string $compilationUuid)',
    'latestForTenant(int $tenantCompanyId, int $limit = 25)',
    'lineageForTenant(int $tenantCompanyId, string $compilationUuid, int $limit = 25)',
]);
requireFileContains($root, 'System/Repositories/EloquentCompilationRepository.php', [
    "where('tenant_company_id', \$tenantCompanyId)",
    "where('compilation_uuid', \$compilationUuid)",
    'lineageForTenant(',
]);
requireFileContains($root, 'database/migrations/2026_08_11_000002_upgrade_titan_nexus_compilations_for_domain_core.php', [
    "'causation_id'", "'compilation_uuid'", "'input_snapshot'", "'compiled_configuration'", "'validation_result'", "'provisioning_plan'", "'input_hash'", "'output_hash'",
]);
requireFileContains($root, 'database/migrations/2026_08_17_000003_add_vertical_definition_hash_to_titan_nexus_compilations.php', ["'vertical_definition_hash'"]);

requireFileContains($root, 'System/Domain/VerticalDefinition.php', [
    'provisioningPolicy()', 'normalizeProvisioning(', 'assertAcyclicProvisioningRoutes(', "'routes'",
]);
requireFileContains($root, 'System/Domain/ProvisioningOperation.php', [
    'idempotencyKey()', 'operationId()', 'backupRequired()', "'backup_required' => true",
]);
requireFileContains($root, 'System/Domain/ProvisioningPlan.php', [
    'ProvisioningPlanStatus::Blocked', 'ProvisioningPlanStatus::RequiresApproval', 'ProvisioningPlanStatus::PartiallyApplied', 'withReceipts(', 'fingerprint()',
]);
requireFileContains($root, 'System/Domain/ProvisioningReceipt.php', [
    'backupVerified', 'writeVerified', 'auditReference', 'rollbackReference',
]);
requireFileContains($root, 'System/Services/DeterministicProvisioningPlanner.php', [
    'resolveRoutePath(', 'topologicalSort(', 'nexus.unrouted', 'sourceVerticalHash()',
]);
requireFileContains($root, 'System/Adapters/CommandBus/CommandBusProvisioningAdapter.php', [
    "'capture_backup_before_write' => true",
    "'verify_backup_before_write' => true",
    "'verify_write_after' => true",
    "'audit_operation' => true",
    "'preserve_rollback_metadata' => true",
]);
requireFileContains($root, 'System/Services/GovernedProvisioningExecutor.php', [
    'approvalGranted', 'skippedDependency(', 'ProvisioningReceipt::failed', 'withReceipts(',
]);
requireFileContains($root, 'System/Domain/NexusCompilation.php', [
    'withProvisioningPlan(', 'provisioningPlan()', "'provisioning_plan' => \$this->provisioningPlan?->toArray()", "'domain_version' => 4",
]);
requireFileContains($root, 'System/Services/NexusManager.php', [
    'planProvisioning(', 'executeProvisioning(', 'RuntimeReadinessReport::fromDependencies(', 'ProvisioningPlannerContract', 'ProvisioningExecutorContract',
]);
requireFileContains($root, 'System/TitanNexusServiceProvider.php', [
    'ProvisioningPlannerContract::class', 'DeterministicProvisioningPlanner::class',
    'ProvisioningCommandGatewayContract::class', 'CommandBusProvisioningAdapter',
    'ProvisioningExecutorContract::class', 'GovernedProvisioningExecutor::class',
    'titan-nexus.command_bus.public_contract', 'titan-nexus.command_bus.execute_method',
    'RiskGatewayContract::class', 'GovernanceGatewayContract::class', 'AssuranceGatewayContract::class',
    'SignalGatewayContract::class', 'RewindGatewayContract::class', 'AutonomyGatewayContract::class',
    'NexusControlCentreContract::class', 'NexusControlCentreService::class', 'TenantContextResolverContract::class', 'HostTenantContextResolver',
]);
requireFileContains($root, 'config/titan-nexus.php', [
    "'version' => '1.0.0-rc.2'", "'compiler_version' => '0.5.0'", "'command_bus'", "'execute_method' => 'executeForNexus'",
    "'risk'", "'governance'", "'assurance'", "'signal'", "'rewind'", "'autonomy'",
]);

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
if (($manifest['version'] ?? null) !== '1.0.0-rc.2') {
    failCheck('manifest version must be 1.0.0-rc.2');
}
if (($manifest['schema_version'] ?? null) !== '2.2') {
    failCheck('manifest schema_version must be 2.2');
}
if (($manifest['architecture']['profile'] ?? null) !== 'configuration-orchestrator') {
    failCheck('manifest architecture profile must be configuration-orchestrator');
}
if (($manifest['interface_contribution']['contract_version'] ?? null) !== '1.1' || ($manifest['interface_contribution']['manifest'] ?? null) !== 'resources/interface/interface-manifest.json') {
    failCheck('manifest must advertise Interface Runtime v1.1 Control Centre contribution');
}
if (($manifest['queues']['used'] ?? null) !== false) {
    failCheck('queue usage must remain false until queue jobs exist');
}
$capabilities = $manifest['capabilities'] ?? [];
foreach ([
    'titan-nexus', 'nexus.domain-core', 'nexus.compile', 'nexus.vertical-engine-adapter', 'nexus.validate', 'nexus.preview',
    'nexus.platform-readiness-adapter', 'nexus.compile.diff', 'nexus.recompile.plan', 'nexus.history.lineage',
    'nexus.provision.plan', 'nexus.provision.execute', 'nexus.command-bus-adapter', 'nexus.provision.idempotency', 'nexus.provision.receipts',
    'nexus.risk.evaluate', 'nexus.governance.authorize', 'nexus.assurance.verify', 'nexus.autonomy.authorize',
    'nexus.signal.emit', 'nexus.rewind.evidence', 'nexus.contracts.v2.2', 'nexus.control-centre', 'nexus.interface.read-model', 'nexus.host-ready', 'nexus.runtime-readiness',
] as $implemented) {
    if (!in_array($implemented, $capabilities, true)) {
        failCheck("manifest missing implemented capability {$implemented}");
    }
}
foreach (['nexus.rewind.rollback'] as $unimplemented) {
    if (in_array($unimplemented, $capabilities, true)) {
        failCheck("manifest advertises future capability {$unimplemented}");
    }
}

$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/System'));
foreach ($iterator as $file) {
    if (!$file->isFile() || $file->getExtension() !== 'php') {
        continue;
    }
    $contents = (string) file_get_contents($file->getPathname());
    if (preg_match('/App\\\\Extensions\\\\(?!TitanNexus)/', $contents) === 1) {
        failCheck('direct cross-extension implementation import found in ' . $file->getPathname());
    }
    if (preg_match('/Illuminate\\\\Support\\\\Facades\\\\DB|\bDB::|Schema::table\s*\(/', $contents) === 1) {
        failCheck('direct database mutation boundary found in production System code: ' . $file->getPathname());
    }
}

fwrite(STDOUT, "PASS: Titan Nexus standalone package checks\n");
