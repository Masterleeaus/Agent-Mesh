<?php

declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Models;
use Illuminate\Database\Eloquent\Model;
final class RewindDeadLetter extends Model
{
    protected $table='titan_rewind_dead_letters';
    protected $fillable=['dead_letter_uuid','tenant_company_id','queue_name','job_type','operation_id','status','classification','attempts','payload','error_class','error_message','failed_at','retried_at','resolved_at'];
    protected $casts=['tenant_company_id'=>'integer','attempts'=>'integer','payload'=>'array','failed_at'=>'datetime','retried_at'=>'datetime','resolved_at'=>'datetime'];
}
