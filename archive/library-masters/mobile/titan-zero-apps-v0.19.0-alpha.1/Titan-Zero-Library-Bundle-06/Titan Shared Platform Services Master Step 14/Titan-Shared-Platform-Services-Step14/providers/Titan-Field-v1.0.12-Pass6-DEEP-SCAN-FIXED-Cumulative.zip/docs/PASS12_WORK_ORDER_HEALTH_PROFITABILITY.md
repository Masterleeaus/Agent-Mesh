# Pass 12 — Work-Order Health, Profitability + Spatial Cost Intelligence

Titan Field remains the sole operational and financial authority. Pass 12 adds a **read-only** health projection over retained Field records; it creates no profit ledger and writes no invoice, quote, time, material, route or Maps state.

## Authoritative Field facts

The projection reads existing `crm_work_orders`, work-order service lines, time entries, materials, appointments, worker profiles and unresolved operational exceptions. Quoted revenue is taken from explicit work-order quote metadata first, then existing work-order service lines, then the service catalogue price as a bounded fallback. Planned labour comes from scheduled appointments/work-order windows or service default duration. Actual labour comes only from recorded time entries.

Cost rates are never guessed. Labour cost is calculated only when an explicit Field cost rate exists in work-order or worker-profile metadata (`hourly_cost_rate_minor`, `labour_cost_rate_minor`, `labor_cost_rate_minor`, or `cost_rate_minor`). Materials without an authoritative unit cost make material cost coverage incomplete. Incomplete cost coverage makes `forecast_final_cost_minor` and projected margin `null` rather than fabricating a value.

## Spatial evidence boundary

`SpatialIntelligenceGateway::workOrderCostEvidence()` provides travel distance/time and territory/pricing-signal evidence. Titan Maps Intelligence is preferred when active; retained Field route-stop data is the standalone fallback. Maps never calculates Titan Field profit and never writes financial state.

Field may convert spatial facts into a cost only when Field already owns an explicit rate: assigned-worker cost rate for travel time and optional work-order `travel_cost_per_km_minor` / `vehicle_cost_per_km_minor` for distance. Maps geographic pricing hints remain advisory and are **not applied** to revenue, invoices or margin automatically.

## Health states

- `healthy`: complete projection with no material overrun or low-margin warning.
- `warning`: over planned hours, projected margin below 15%, or a high/warning operational exception.
- `critical`: projected over-budget, negative projected margin, >25% labour overrun, or critical/urgent exception.
- `unknown`: quote or forecast cost cannot be proven from authoritative data.

This is decision support, not accounting authority.
