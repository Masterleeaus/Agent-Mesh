<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class PlanInput {
    public function __construct(public string $key, public string $type, public string $source) {}
    public function toArray(): array { return ['key'=>$this->key,'type'=>$this->type,'source'=>$this->source]; }
}
