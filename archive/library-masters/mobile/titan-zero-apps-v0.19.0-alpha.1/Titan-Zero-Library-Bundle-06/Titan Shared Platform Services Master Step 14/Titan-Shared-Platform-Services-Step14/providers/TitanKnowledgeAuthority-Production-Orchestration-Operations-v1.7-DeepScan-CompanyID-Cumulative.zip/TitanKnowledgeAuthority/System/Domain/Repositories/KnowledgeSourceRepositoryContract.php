<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Models\KnowledgeSource;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeAccessContext;

interface KnowledgeSourceRepositoryContract
{
    public function findVisibleByKey(KnowledgeAccessContext $context, string $sourceKey): ?KnowledgeSource;
}
