<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ControlCentre;

final class EngineHealthScorecard
{
    /** @param array<string,mixed> $sourceHealth @return array<string,mixed> */
    public function project(array $sourceHealth):array
    {
        $items=[];$points=[];$requiredUnavailable=0;$optionalMissing=0;$degraded=0;
        $sources=is_array($sourceHealth['sources']??null)?$sourceHealth['sources']:[];
        foreach($sources as $key=>$row){
            if(!is_array($row))continue;$status=strtoupper(trim((string)($row['status']??'UNAVAILABLE')));$required=(bool)($row['required']??false);
            if(!$required&&$status==='NOT_INSTALLED'){$optionalMissing++;$score=null;}
            else{$score=$this->score($status);$points[]=$score;}
            if($required&&in_array($status,['UNAVAILABLE','ERROR','NOT_INSTALLED','INVALID'],true))$requiredUnavailable++;
            if(!in_array($status,['HEALTHY','READY','DISABLED','NOT_INSTALLED'],true))$degraded++;
            $items[]=['source'=>(string)$key,'status'=>$status,'required'=>$required,'score'=>$score,'observed_at'=>$row['observed_at']??null,'reason'=>$row['reason']??null];
        }
        $scorePct=$points===[]?null:round(array_sum($points)/count($points),1);
        $declared=strtoupper(trim((string)($sourceHealth['status']??'UNKNOWN')));
        $status=$requiredUnavailable>0?'UNAVAILABLE':($declared==='HEALTHY'&&$degraded===0?'HEALTHY':($declared==='UNAVAILABLE'?'UNAVAILABLE':($items===[]?'UNAVAILABLE':'DEGRADED')));
        return ['status'=>$status,'score_pct'=>$scorePct,'required_unavailable'=>$requiredUnavailable,'optional_not_installed'=>$optionalMissing,'degraded_count'=>$degraded,'items'=>$items,'observed_at'=>$sourceHealth['observed_at']??null];
    }

    private function score(string $status):float
    {
        return match($status){'HEALTHY','READY','DISABLED'=>100.0,'STALE'=>60.0,'DEGRADED'=>50.0,'UNKNOWN'=>25.0,default=>0.0};
    }
}
