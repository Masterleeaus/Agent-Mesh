<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\ControlPlaneAuditSinkContract;
use App\Extensions\TitanAutonomy\System\Services\RewindCorrelationService;
use Illuminate\Support\Facades\DB;

final class DatabaseControlPlaneAuditSink implements ControlPlaneAuditSinkContract
{
    public function __construct(private readonly RewindCorrelationService $rewind) {}

    public function record(array $event): string
    {
        $id = (int) app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_control_events')->insertGetId([
            'tenant_company_id' => $event['tenant_company_id'] ?? null,
            'user_id' => $event['user_id'] ?? null,
            'event_type' => (string) $event['event_type'],
            'capability' => $event['capability'] ?? null,
            'workflow_key' => $event['workflow_key'] ?? null,
            'payload_json' => json_encode($event['payload'] ?? [], JSON_THROW_ON_ERROR),
            'policy_version' => (string) ($event['policy_version'] ?? 'unknown'),
            'correlation_id' => $event['correlation_id'] ?? null,
            'rewind_ref' => null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $rewindRef = $this->rewind->record((string) $event['event_type'], [
            'control_event_id' => $id,
            'tenant_company_id' => $event['tenant_company_id'] ?? null,
            'user_id' => $event['user_id'] ?? null,
            'capability' => $event['capability'] ?? null,
            'workflow_key' => $event['workflow_key'] ?? null,
            'payload' => $event['payload'] ?? [],
            'policy_version' => $event['policy_version'] ?? 'unknown',
            'correlation_id' => $event['correlation_id'] ?? null,
        ]);
        if ($rewindRef !== null) {
            app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_control_events')->where('id', $id)->update(['rewind_ref' => $rewindRef, 'updated_at' => now()]);
        }

        return (string) $id;
    }
}
