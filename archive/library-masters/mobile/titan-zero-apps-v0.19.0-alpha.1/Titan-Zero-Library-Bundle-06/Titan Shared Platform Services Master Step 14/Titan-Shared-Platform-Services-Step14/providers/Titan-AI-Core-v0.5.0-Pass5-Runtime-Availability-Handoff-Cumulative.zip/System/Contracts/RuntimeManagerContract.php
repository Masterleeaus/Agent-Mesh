<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Contracts;

interface RuntimeManagerContract
{
    /** @return array<string, mixed> */
    public function status(): array;
}
