# Signal Delivery Concurrency

Titan Signal delivery is **at-least-once**. Pass 3 hardens the delivery ledger so only one active worker owns a delivery at a time while retaining crash recovery.

## Lease model

A worker claims a delivery with an atomic compare-and-set update. The claim records:

- `lease_token` — unique execution/attempt ownership token.
- `lease_owner` — worker identity.
- `lease_expires_at` — bounded ownership expiry.
- `processing_started_at` — attempt start.
- `claim_version` — monotonically increasing ownership generation.
- `attempt_count` — processing attempts.

Only a row still in `processing` with the matching token, owner, claim version, and an unexpired lease may transition to `delivered`, `retry_wait`, or `dead_letter`.

If a worker crashes, its lease expires. Recovery atomically releases the expired lease and requeues the same immutable delivery. A stale worker that returns after expiry cannot overwrite the new owner's state.

## Subscriber idempotency

Exactly-once side effects are not claimed. A worker may perform a subscriber side effect and crash before the delivery ledger records success. A later worker will retry.

Every subscriber receives a stable idempotency key:

`signal-delivery:<delivery_id>`

The key remains the same across retries and lease generations. Subscribers that perform consequential writes must use it as their idempotency anchor.

`SignalDeliveryContext` also exposes the current `leaseToken`, `workerId`, and numeric `attempt` for diagnostics. These are attempt-specific and must not replace the stable delivery idempotency key.

## Lease duration

`delivery_lease_seconds` provides the baseline lease duration. The dispatcher raises the effective lease to at least the subscriber timeout plus `delivery_lease_grace_seconds`, bounded to 7,200 seconds.

Queue timeout callbacks carry the same execution token as the worker. A late failure callback cannot mutate a delivery that another worker has already reclaimed.

## Recovery

`titan:signal-deliveries:recover` handles:

- due `pending` / `retry_wait` rows;
- stale `queued` rows;
- expired `processing` leases;
- legacy processing rows that predate lease ownership.

Active, unexpired processing leases are never reset by recovery.
