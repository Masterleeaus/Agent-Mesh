# Data Ownership

AI Core owns orchestration plan records and model capability profiles only.

## Tenant-owned records

`titan_ai_core_plans` is tenant-owned through `tenant_company_id`. Pass 3 repositories never infer tenant ownership from plan payload data; they receive trusted `RuntimeContext` and force that tenant onto writes.

Plan audit persistence now includes trusted actor provenance:

- `actor_id`
- `actor_type`
- `authority_level`
- `principal_source`

## Model profiles

`titan_ai_core_model_profiles` supports tenant-scoped and global profiles. Global profiles use a deterministic global scope key. Tenant code does not receive global profiles unless explicit global fallback is enabled.

AI Core does not own business-domain records, Risk decisions, Assurance evidence, Autonomy policy, Workforce workers, Signal truth, Knowledge sources, Wisdom learning data or Rewind state.
