# Upgrade

v0.5.0 is a forward-compatible cumulative upgrade from v0.4.0.

Pass 4 adds Core-side contracts, DTOs, fail-closed adapters and services for Risk/Assurance/Autonomy preflight, human approval state and Command Bus-only mutation delegation. It does not add or alter database tables.

Existing plans, model profiles and trusted actor audit fields are preserved. No business-domain table is modified. Uninstall continues to preserve AI Core-owned database data by default.

Execution remains disabled after upgrade; installing v0.5.0 does not activate Command Bus mutations.
