# Onboarding Capability Mapping

Destination ownership is data-driven in `resources/wizards/field_home_services_onboarding.json`.

Typical routing:
- company/profile/hours/services/territory/booking/workforce/compliance → CRM
- brand/app/features/navigation/theme → Titan Builder
- chatbot identity/knowledge/experience → Chatbot
- connection tasks/messages → Titan Connect
- notifications/mobile readiness → Mobile Core
- AI authority/preferences → TitanAI
- final journey activation → Interaction Engine

A single answer may intentionally fan out to several owners. Example: `business.verticals` informs CRM business profile, Builder app configuration and Chatbot identity defaults. Raw credentials are never destinations.
