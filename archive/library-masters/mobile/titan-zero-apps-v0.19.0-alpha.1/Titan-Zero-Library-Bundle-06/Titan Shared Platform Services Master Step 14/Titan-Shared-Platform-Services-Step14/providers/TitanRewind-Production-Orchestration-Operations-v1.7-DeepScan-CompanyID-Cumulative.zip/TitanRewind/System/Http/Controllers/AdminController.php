<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Http\Controllers;

use App\Extensions\TitanRewind\System\Models\RewindCase;
use App\Extensions\TitanRewind\System\Models\RewindCustodyEvent;
use App\Extensions\TitanRewind\System\Models\RewindLegalHold;
use App\Extensions\TitanRewind\System\Models\RewindSourceWatermark;
use App\Extensions\TitanRewind\System\Models\RewindDriftFinding;
use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use App\Extensions\TitanRewind\System\Models\RewindRecoveryPlan;
use App\Extensions\TitanRewind\System\Models\RewindGovernanceReceipt;
use App\Extensions\TitanRewind\System\Models\RewindIntegrityCheck;
use App\Extensions\TitanRewind\System\Models\RewindReplayRun;
use App\Extensions\TitanRewind\System\Models\RewindTraceEvent;
use App\Extensions\TitanRewind\System\Models\RewindTraceIndex;
use App\Extensions\TitanRewind\System\Models\RewindDeadLetter;
use App\Extensions\TitanRewind\System\Models\RewindSignalOutbox;
use App\Extensions\TitanRewind\System\Models\RewindObservabilityEvent;
use App\Extensions\TitanRewind\System\Models\RewindPurgeRun;
use App\Extensions\TitanRewind\System\Models\RewindPurgeReceipt;
use App\Extensions\TitanRewind\System\Models\RewindSigningKey;
use App\Extensions\TitanRewind\System\Models\RewindHistoricalArtifact;
use App\Extensions\TitanRewind\System\Health\RewindHealthCheck;
use App\Extensions\TitanRewind\System\Services\RewindRuntimeStateService;
use App\Extensions\TitanRewind\System\Services\RewindCircuitBreakerService;
use Illuminate\Contracts\View\View;

final class AdminController
{
    public function __invoke(RewindHealthCheck $health, RewindRuntimeStateService $runtime, RewindCircuitBreakerService $breakers): View
    {
        return view('titan-rewind::admin', [
            'health'=>$health->snapshot(),
            'runtimeState'=>$runtime->current()->value(),
            'circuitBreakers'=>$breakers->states(),
            'attentionDeadLetterCount'=>RewindDeadLetter::query()->where('status','attention')->count(),
            'pendingSignalCount'=>RewindSignalOutbox::query()->whereIn('status',['pending','retry','attention'])->count(),
            'observabilityEventCount'=>RewindObservabilityEvent::query()->count(),
            'recentDeadLetters'=>RewindDeadLetter::query()->latest('failed_at')->limit(20)->lazy(250),
            'traceCount'=>RewindTraceIndex::query()->count(),
            'eventCount'=>RewindTraceEvent::query()->count(),
            'caseCount'=>RewindCase::query()->count(),
            'criticalTraceCount'=>RewindTraceIndex::query()->where('forensic_state','critical')->count(),
            'reviewTraceCount'=>RewindTraceIndex::query()->where('forensic_state','review')->count(),
            'openDriftCount'=>RewindDriftFinding::query()->where('status','open')->count(),
            'failedIntegrityCount'=>RewindIntegrityCheck::query()->where('status','failed')->count(),
            'queuedReplayCount'=>RewindReplayRun::query()->whereIn('status',['queued','running'])->count(),
            'failedReplayCount'=>RewindReplayRun::query()->where('status','failed')->count(),
            'evidencePackageCount'=>RewindEvidencePackage::query()->count(),
            'evidenceReviewCount'=>RewindEvidencePackage::query()->where('status','review_required')->count(),
            'recoveryPlanCount'=>RewindRecoveryPlan::query()->count(),
            'pendingGovernanceCount'=>RewindRecoveryPlan::query()->where('status','approval_pending')->count(),
            'governanceReceiptCount'=>RewindGovernanceReceipt::query()->count(),
            'custodyEventCount'=>RewindCustodyEvent::query()->count(),
            'activeLegalHoldCount'=>RewindLegalHold::query()->where('status','active')->count(),
            'partialSourceWatermarkCount'=>RewindSourceWatermark::query()->where('state','!=','COMPLETE')->count(),
            'historicalArtifactCount'=>RewindHistoricalArtifact::query()->count(),
            'signingKeyCount'=>RewindSigningKey::query()->count(),
            'activeSigningKeyCount'=>RewindSigningKey::query()->where('status','active')->count(),
            'purgeRunCount'=>RewindPurgeRun::query()->count(),
            'purgeReceiptCount'=>RewindPurgeReceipt::query()->count(),
            'recentReplays'=>RewindReplayRun::query()->latest()->limit(20)->lazy(250),
            'recentIntegrityChecks'=>RewindIntegrityCheck::query()->latest()->limit(20)->lazy(250),
            'recentDriftFindings'=>RewindDriftFinding::query()->where('status','open')->latest('last_seen_at')->limit(20)->lazy(250),
            'recentEvidencePackages'=>RewindEvidencePackage::query()->latest()->limit(20)->lazy(250),
            'recentRecoveryPlans'=>RewindRecoveryPlan::query()->latest()->limit(20)->lazy(250),
            'recentPurgeRuns'=>RewindPurgeRun::query()->latest('started_at')->limit(20)->lazy(250),
            'signingKeys'=>RewindSigningKey::query()->orderByDesc('status')->orderBy('key_id')->lazy(250),
        ]);
    }
}
