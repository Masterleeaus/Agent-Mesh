<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanKnowledgeAuthority\System\Services\KnowledgeAuthority;
use PHPUnit\Framework\TestCase;

final class ScaffoldContractTest extends TestCase
{
    public function test_health_reports_truthful_immutable_version_foundation_state(): void
    {
        $health = (new KnowledgeAuthority())->health();

        self::assertSame('titan-knowledge-authority', $health['engine']);
        self::assertSame('immutable-version-foundation', $health['status']);
        self::assertTrue($health['scope_context_ready']);
        self::assertTrue($health['immutable_version_writer_ready']);
        self::assertFalse($health['public_catalog_reads_enabled']);
        self::assertSame('0.5.0-alpha.4', $health['version']);
        self::assertTrue($health['domain_model_ready']);
        self::assertFalse($health['refresh_enabled']);
    }
}
