<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyControlStoreContract;
use Illuminate\Support\Facades\DB;

final class DatabaseAutonomyControlStore implements AutonomyControlStoreContract
{
    public function saveLearningSettings(int $tenantCompanyId, array $settings, string $policyVersion): void
    {
        app(\Illuminate\Database\DatabaseManager::class)->table('titan_learning_settings')->updateOrInsert(
            ['tenant_company_id' => $tenantCompanyId],
            [
                'user_learning' => (bool) ($settings['user'] ?? false),
                'business_learning' => (bool) ($settings['business'] ?? false),
                'system_wide_learning' => (bool) ($settings['system'] ?? false),
                'learning_event_retention_days' => $settings['learning_event_retention_days'] ?? null,
                'autonomy_evidence_retention_days' => $settings['autonomy_evidence_retention_days'] ?? null,
                'policy_version' => $policyVersion,
                'updated_at' => now(),
                'created_at' => now(),
            ],
        );
    }

    public function resetCapabilityLearning(int $tenantCompanyId, string $capability, string $workflowKey, string $targetLevel, string $policyVersion): void
    {
        app(\Illuminate\Database\DatabaseManager::class)->transaction(function () use ($tenantCompanyId, $capability, $workflowKey, $targetLevel): void {
            $eventIds = app(\Illuminate\Database\DatabaseManager::class)->table('titan_learning_events')
                ->where('tenant_company_id', $tenantCompanyId)
                ->where('capability', $capability)
                ->where('workflow_key', $workflowKey)
                ->pluck('id')->all();
            if ($eventIds !== []) app(\Illuminate\Database\DatabaseManager::class)->table('titan_learning_outcomes')->whereIn('learning_event_id', $eventIds)->delete();
            app(\Illuminate\Database\DatabaseManager::class)->table('titan_learning_events')->where('tenant_company_id', $tenantCompanyId)->where('capability', $capability)->where('workflow_key', $workflowKey)->delete();
            app(\Illuminate\Database\DatabaseManager::class)->table('titan_capability_training_stats')->where('tenant_company_id', $tenantCompanyId)->where('capability', $capability)->where('workflow_key', $workflowKey)->delete();

            app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_capability_states')
                ->where('tenant_company_id', $tenantCompanyId)
                ->where('capability', $capability)
                ->where('workflow_key', $workflowKey)
                ->update([
                    'current_level' => $targetLevel,
                    'next_level' => $this->nextLevel($targetLevel),
                    'current_success_streak' => 0,
                    'highest_success_streak' => 0,
                    'total_successes' => 0,
                    'total_failures' => 0,
                    'total_edits' => 0,
                    'total_rejections' => 0,
                    'total_reversals' => 0,
                    'platform_gate_eligible' => false,
                    'scope_json' => null,
                    'ai_confidence' => null,
                    'assurance_status' => null,
                    'last_success_at' => null,
                    'last_failure_at' => null,
                    'updated_at' => now(),
                ]);
        });
    }

    public function clearPreferences(int $tenantCompanyId, ?int $userId = null): int
    {
        $query = app(\Illuminate\Database\DatabaseManager::class)->table('titan_learning_preferences')->where('tenant_company_id', $tenantCompanyId);
        if ($userId !== null) $query->where('user_id', $userId);
        return $query->delete();
    }

    public function lowerCapabilityLevel(int $tenantCompanyId, string $capability, string $workflowKey, string $targetLevel, string $cause, string $policyVersion): void
    {
        app(\Illuminate\Database\DatabaseManager::class)->transaction(function () use ($tenantCompanyId, $capability, $workflowKey, $targetLevel, $cause, $policyVersion): void {
            $row = app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_capability_states')
                ->where('tenant_company_id', $tenantCompanyId)->where('capability', $capability)->where('workflow_key', $workflowKey)->lockForUpdate()->first();
            if ($row === null) return;
            $prior = (string) $row->current_level;
            app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_capability_states')->where('id', $row->id)->update([
                'current_level' => $targetLevel,
                'next_level' => $this->nextLevel($targetLevel),
                'current_success_streak' => 0,
                'platform_gate_eligible' => false,
                'scope_json' => in_array($targetLevel, ['suggest', 'assist'], true) ? null : $row->scope_json,
                'updated_at' => now(),
            ]);
            app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_regressions')->insert([
                'tenant_company_id' => $tenantCompanyId,
                'capability' => $capability,
                'workflow_key' => $workflowKey,
                'prior_level' => $prior,
                'new_level' => $targetLevel,
                'cause' => $cause,
                'evidence_json' => json_encode(['manual' => true], JSON_THROW_ON_ERROR),
                'policy_version' => $policyVersion,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        });
    }

    public function savePlatformPolicy(array $policy, string $policyVersion): void
    {
        $this->savePolicy('platform', 'global', null, $policy, $policyVersion);
    }

    public function saveTenantPolicy(int $tenantCompanyId, array $policy, string $policyVersion): void
    {
        $this->savePolicy('tenant', 'tenant:' . $tenantCompanyId, $tenantCompanyId, $policy, $policyVersion);
    }

    private function savePolicy(string $scopeType, string $scopeKey, ?int $tenantCompanyId, array $policy, string $policyVersion): void
    {
        app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_policies')->updateOrInsert(
            ['scope_type' => $scopeType, 'scope_key' => $scopeKey],
            [
                'tenant_company_id' => $tenantCompanyId,
                'gate_minimums_json' => json_encode($policy['gate_minimums'] ?? [], JSON_THROW_ON_ERROR),
                'maximum_level_by_risk_json' => json_encode($policy['maximum_level_by_risk'] ?? [], JSON_THROW_ON_ERROR),
                'limits_json' => json_encode($policy['limits'] ?? [], JSON_THROW_ON_ERROR),
                'system_wide_learning_permitted' => (bool) ($policy['system_wide_learning_permitted'] ?? false),
                'policy_version' => $policyVersion,
                'active' => true,
                'updated_at' => now(),
                'created_at' => now(),
            ],
        );
    }

    private function nextLevel(string $level): ?string
    {
        return match ($level) {
            'suggest' => 'assist',
            'assist' => 'semi_auto',
            'semi_auto' => 'auto',
            'auto' => 'trusted_auto',
            default => null,
        };
    }
}
