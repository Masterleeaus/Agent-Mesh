<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\ReadModels;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use Throwable;

final class CrmProjectionDeadLetterStore
{
    public function __construct(private readonly ConnectionInterface $db) {}

    public function recordFailure(array $event,Throwable $error,?string $projectionName=null,?string $projectionVersion=null): void
    {
        if(!$this->ready())return;$tenant=(int)($event['company_id']??0);if($tenant<1)return;$signal=trim((string)($event['public_id']??''));
        $q=$this->db->table('crm_read_projection_dead_letters')->where('company_id',$tenant)->where('signal_public_id',$signal!==''?$signal:null)->where('projection_name',$projectionName);
        $existing=$q->first();$attempt=(int)($existing->attempt_count??0)+1;$max=max(1,(int)config('crm.read_store.projection_dead_letters.max_attempts',8));$retryable=$attempt<$max;$delay=min(3600,max(5,(int)config('crm.read_store.projection_dead_letters.retry_base_seconds',30))*(2**max(0,$attempt-1)));
        $row=['projection_version'=>$projectionVersion,'event_payload'=>json_encode($event,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),'error_class'=>$error::class,'last_error'=>substr($error->getMessage(),0,4000),'attempt_count'=>$attempt,'retryable'=>$retryable,'next_retry_at'=>$retryable?now()->addSeconds($delay):null,'resolved_at'=>null,'updated_at'=>now()];
        if($existing)$q->update($row);else $this->db->table('crm_read_projection_dead_letters')->insert(['public_id'=>(string)Str::ulid(),'company_id'=>$tenant,'signal_public_id'=>$signal!==''?$signal:null,'projection_name'=>$projectionName]+$row+['created_at'=>now()]);
    }

    public function search(int $companyId,array $filters=[]): array
    {if(!$this->ready())return [];$q=$this->db->table('crm_read_projection_dead_letters')->where('company_id',$companyId);if(isset($filters['resolved']))$filters['resolved']?$q->whereNotNull('resolved_at'):$q->whereNull('resolved_at');if(isset($filters['retryable']))$q->where('retryable',(bool)$filters['retryable']);return $q->orderByDesc('id')->limit(max(1,min(200,(int)($filters['limit']??50))))->get()->map(fn($r)=>(array)$r)->all();}
    public function due(int $limit=50): array{if(!$this->ready())return [];$q=$this->db->table('crm_read_projection_dead_letters')->whereNull('resolved_at')->where('retryable',true)->where(fn($x)=>$x->whereNull('next_retry_at')->orWhere('next_retry_at','<=',now()));return $q->orderBy('id')->limit(max(1,min(200,$limit)))->get()->map(fn($r)=>(array)$r)->all();}
    public function markResolved(string $publicId): void{if($this->ready())$this->db->table('crm_read_projection_dead_letters')->where('public_id',$publicId)->update(['resolved_at'=>now(),'retryable'=>false,'next_retry_at'=>null,'updated_at'=>now()]);}
    public function requestRetry(int $companyId,string $publicId): array{if(!$this->ready())return ['status'=>'unavailable'];$row=$this->db->table('crm_read_projection_dead_letters')->where('company_id',$companyId)->where('public_id',$publicId)->first();if(!$row)return ['status'=>'not_found'];$this->db->table('crm_read_projection_dead_letters')->where('id',$row->id)->update(['retryable'=>true,'next_retry_at'=>now(),'resolved_at'=>null,'updated_at'=>now()]);return ['status'=>'retry_requested','public_id'=>$publicId];}
    private function ready(): bool{try{return $this->db->getSchemaBuilder()->hasTable('crm_read_projection_dead_letters');}catch(\Throwable){return false;}}
}
