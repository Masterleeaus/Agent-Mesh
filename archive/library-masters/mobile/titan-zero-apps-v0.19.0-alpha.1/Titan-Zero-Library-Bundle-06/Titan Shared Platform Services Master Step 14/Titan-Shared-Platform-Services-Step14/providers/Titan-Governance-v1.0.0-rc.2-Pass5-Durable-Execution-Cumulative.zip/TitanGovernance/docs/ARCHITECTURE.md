# Titan Governance Architecture

Primary profile: `governance-engine`. Canonical engine domain: `governance-control-plane`.

Titan Governance may observe Risk, Assurance, Autonomy, Signal, Rewind, Knowledge Authority, Shield, Model Council and AI Workforce through public contracts/adapters. It may create Governance-owned policy decisions, upper-bound authority constraints, escalations and projections. It may never write another engine's canonical tables directly.

Consequential cross-domain state changes flow through Titan Command Bus. Governance can contract authority (`CONTRACT`, `REQUIRE_APPROVAL`, `HOLD`, `DENY`) but can never increase desired, earned or effective authority. Titan Autonomy remains the source of effective authority.
