@push('css')
<link rel="stylesheet" href="{{ asset('vendor/titan-connect/css/voice-call.css') }}">
@endpush

<div class="container-fluid py-6">
<div class="titan-connect-voice" data-titan-connect-voice-call="{{ $call->uuid }}">
    <header class="tc-voice-header">
        <div>
            <strong>{{ __('Titan Connect Voice') }}</strong>
            <div class="tc-voice-meta"><span class="tc-voice-status" data-role="status">{{ $call->status }}</span><span data-role="elapsed">00:00</span></div>
        </div>
        <div class="tc-voice-actions">
            <button type="button" data-action="mute">{{ __('Mute') }}</button>
            <button type="button" data-action="end-call">{{ __('End call') }}</button>
        </div>
    </header>
    <div class="tc-voice-waveform" data-role="waveform" aria-label="{{ __('Voice activity') }}"></div>
    <div class="tc-voice-transcript" data-role="transcript">
        @foreach($call->transcripts as $item)
            <div class="tc-voice-line tc-voice-line--{{ $item->role }}"><strong>{{ $item->role }}</strong> {{ $item->message }}</div>
        @endforeach
    </div>
</div>
<script>
window.TitanConnectVoiceBoot = {
    callUuid: @json($call->uuid),
    sessionUrl: @json(route('titan-connect.api.voice.session', ['call' => $call->uuid])),
    transcriptUrl: @json(route('titan-connect.api.voice.transcript', ['call' => $call->uuid])),
    endUrl: @json(route('titan-connect.api.voice.end', ['call' => $call->uuid])),
    csrf: @json(csrf_token())
};
</script>

</div>

@push('script')
<script src="{{ asset('vendor/titan-connect/js/voice-call-client.js') }}"></script>
@endpush
