# Integration Contracts

All external integrations are container-configured public contracts. Default methods are `evaluateForNexus`, `authorizeForNexus`, `verifyForNexus`, `emitForNexus`, `recordForNexus`, `executeForNexus`, and `resolveForNexus`. No other extension implementation class is imported. Canonical Nexus artifacts are defined under `schemas/nexus/`.
