@extends('panel.layout.app')

@section('content')
    <div class="container-fluid py-6">
        <h1>Titan Prime</h1>
        <p>Strategic domain core installed. Runtime orchestration remains disabled until governed engine adapters and the Command Bus execution path are installed.</p>
    </div>
@endsection
