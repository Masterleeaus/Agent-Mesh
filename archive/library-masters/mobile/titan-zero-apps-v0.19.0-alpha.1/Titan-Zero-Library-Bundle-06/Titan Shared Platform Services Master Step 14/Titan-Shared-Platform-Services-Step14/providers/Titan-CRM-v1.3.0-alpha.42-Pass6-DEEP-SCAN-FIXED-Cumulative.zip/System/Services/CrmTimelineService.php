<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;

final class CrmTimelineService
{
    public function __construct(private ConnectionInterface $db,private CrmSubjectReferenceValidator $subjects){}
    public function forSubject(int $userId,string $subjectType,string $subjectPublicId,int $limit=100): array
    {
        $this->subjects->require($userId,$subjectType,$subjectPublicId);$limit=max(1,min($limit,250));$tenant=CrmCompanyScope::companyId($userId);$sourceLimit=max($limit,min(500,(int)config('crm.performance.timeline_source_limit',250)));
        $activities=$this->db->table(config('crm.tables.activities'))->where('company_id',$tenant)->where('subject_type',$subjectType)->where('subject_public_id',$subjectPublicId)->orderByDesc('occurred_at')->orderByDesc('id')->limit($sourceLimit)->get()->map(fn($r)=>['kind'=>'activity','occurred_at'=>$r->occurred_at??$r->created_at,'record'=>(array)$r]);
        $notes=$this->db->table('crm_notes')->where('company_id',$tenant)->where('subject_type',$subjectType)->where('subject_public_id',$subjectPublicId)->whereNull('deleted_at')->orderByDesc('created_at')->orderByDesc('id')->limit($sourceLimit)->get()->map(fn($r)=>['kind'=>'note','occurred_at'=>$r->created_at,'record'=>(array)$r]);
        $emails=$this->db->table('crm_email_messages')->where('company_id',$tenant)->where('subject_type',$subjectType)->where('subject_public_id',$subjectPublicId)->orderByDesc('sent_at')->orderByDesc('id')->limit($sourceLimit)->get()->map(fn($r)=>['kind'=>'email','occurred_at'=>$r->sent_at??$r->created_at,'record'=>(array)$r]);
        return $activities->concat($notes)->concat($emails)->sortByDesc('occurred_at')->take($limit)->values()->all();
    }
}
