<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanAutonomy\System\Services\LearningScopePolicy;
use PHPUnit\Framework\TestCase;

final class LearningScopePolicyTest extends TestCase
{
    public function test_system_wide_learning_disabled_never_emits_shared_learning(): void
    {
        $policy = new LearningScopePolicy();
        self::assertFalse($policy->systemWideEnabled(['user' => true, 'business' => true, 'system' => false], true));
        self::assertFalse($policy->systemWideEnabled(['user' => true, 'business' => true, 'system' => true], false));
        self::assertTrue($policy->systemWideEnabled(['user' => true, 'business' => true, 'system' => true], true));
    }
}
