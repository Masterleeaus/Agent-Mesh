<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Models\RewindCustodyEvent;
use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use App\Extensions\TitanRewind\System\Security\RewindAuthorization;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class RewindCustodyService
{
    public function __construct(private RewindAuthorization $authorization) {}

    public function record(RewindEvidencePackage $package, string $action, ?int $actorId = null, ?string $reason = null, array $metadata = []): RewindCustodyEvent
    {
        $tenant = (int) $package->tenant_company_id;
        $this->authorization->assertTenantMatch($tenant, (int) $package->tenant_company_id);
        $action = strtolower(trim($action));
        if (!in_array($action,['generated','viewed','downloaded','exported','verified','signature_verified','superseded','legal_hold_applied','legal_hold_released','purge_blocked','purge_executed'],true)) {
            throw new InvalidArgumentException('Unsupported Titan Rewind custody action.');
        }
        return RewindCustodyEvent::query()->create([
            'event_uuid'=>(string) Str::uuid(),'tenant_company_id'=>$tenant,'package_uuid'=>(string) $package->package_uuid,
            'action'=>$action,'actor_id'=>$actorId,'reason'=>$reason,'metadata'=>$metadata,'occurred_at'=>now(),
        ]);
    }
}
