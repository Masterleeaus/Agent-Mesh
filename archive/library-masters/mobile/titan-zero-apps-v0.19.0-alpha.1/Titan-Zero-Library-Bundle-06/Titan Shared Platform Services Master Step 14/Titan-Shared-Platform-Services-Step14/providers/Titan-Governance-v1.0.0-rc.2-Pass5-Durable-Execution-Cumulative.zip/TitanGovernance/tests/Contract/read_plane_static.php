<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
$provider=(string)file_get_contents($root.'/System/TitanGovernanceServiceProvider.php');
$manager=(string)file_get_contents($root.'/System/Contracts/GovernanceManagerContract.php');
$view=(string)file_get_contents($root.'/resources/views/index.blade.php');
$manifest=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
$errors=[];
if(!str_contains($provider,'GovernanceReadSourceRegistry'))$errors[]='provider does not wire read source registry';
if(!str_contains($manager,'trustMap'))$errors[]='manager contract missing trustMap';
if(!str_contains($manager,'sourceHealth'))$errors[]='manager contract missing sourceHealth';
if(!str_contains($view,'effective_authority_score'))$errors[]='user UI missing live authority score rendering';
if(!in_array('governance.trust-map.read',$manifest['capabilities']??[],true))$errors[]='manifest missing trust-map read capability';
if(!in_array('governance.source-health.read',$manifest['capabilities']??[],true))$errors[]='manifest missing source-health read capability';
if($errors){fwrite(STDERR,'FAIL: '.implode(', ',$errors)."\n");exit(1);} echo "PASS: Governance read plane static wiring\n";
