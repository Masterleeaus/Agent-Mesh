<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

final class OperationalHealthClassifier
{
    /** @param array<string,mixed> $current @param array<string,mixed> $historical @return array<string,mixed> */
    public static function classify(array $current, array $historical): array
    {
        $degraded = (bool) ($current['backpressured'] ?? false)
            || (int) ($current['recent_dead_letter'] ?? 0) > 0
            || (int) ($current['critical_open'] ?? 0) > 0
            || in_array((string) ($current['pulse_projection_status'] ?? 'healthy'), ['degraded', 'unavailable'], true);

        return [
            'status' => $degraded ? 'degraded' : 'healthy',
            'current' => $current,
            'historical_incidents' => $historical,
        ];
    }
}
