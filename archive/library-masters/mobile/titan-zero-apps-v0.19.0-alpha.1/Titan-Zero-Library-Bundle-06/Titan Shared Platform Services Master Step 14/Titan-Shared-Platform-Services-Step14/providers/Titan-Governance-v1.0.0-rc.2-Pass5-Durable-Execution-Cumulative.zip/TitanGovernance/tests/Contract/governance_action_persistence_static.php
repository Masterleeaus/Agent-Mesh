<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
$errors=[];
$files=[
 '/System/Contracts/GovernanceActionDecisionStoreContract.php',
 '/System/Models/GovernancePolicyDecision.php',
 '/System/Actions/GovernanceActionRepository.php',
 '/database/migrations/2026_08_20_000004_add_governed_action_metadata.php',
];
foreach($files as $file) if(!is_file($root.$file))$errors[]='missing '.$file;
if($errors){fwrite(STDERR,"FAIL: ".implode(', ',$errors)."\n");exit(1);}
$migration=(string)file_get_contents($root.'/database/migrations/2026_08_20_000004_add_governed_action_metadata.php');
$model=(string)file_get_contents($root.'/System/Models/GovernancePolicyDecision.php');
$repo=(string)file_get_contents($root.'/System/Actions/GovernanceActionRepository.php');
foreach(['operation_id','subject_type','subject_id','action','payload_hash','command_status','command_receipt_ref','authoritative_receipt_ref','write_verified','result_payload'] as $col) if(!str_contains($migration,$col))$errors[]='migration missing '.$col;
if(!str_contains($migration,'tgov_policy_tenant_operation_uq'))$errors[]='tenant+operation unique idempotency index missing';
if(!str_contains($model,"protected \$table='titan_governance_policy_decisions'"))$errors[]='policy decision model table mismatch';
if(str_contains($repo,'DB'.'::table'))$errors[]='action repository bypasses owned Eloquent model boundary';
foreach(['claim','finalize','findDecision'] as $method) if(!str_contains($repo,'function '.$method.'('))$errors[]='repository missing '.$method;
if($errors){fwrite(STDERR,"FAIL: ".implode(', ',$errors)."\n");exit(1);}echo "PASS: Governance action persistence static contract\n";
