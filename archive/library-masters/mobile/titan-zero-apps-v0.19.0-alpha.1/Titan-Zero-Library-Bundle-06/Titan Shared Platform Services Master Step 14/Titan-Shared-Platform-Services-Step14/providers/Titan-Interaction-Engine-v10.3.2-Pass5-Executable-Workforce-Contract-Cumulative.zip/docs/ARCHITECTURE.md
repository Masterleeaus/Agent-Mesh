# Architecture — v10.3.1 Phase 6.1

TitanAI understands/structures natural language candidates. Interaction Engine owns deterministic interaction/wizard/journey state, authority, approvals and governed routing. CRM owns authoritative business state. Builder owns app/UI configuration. Chatbot owns chatbot configuration. Connect owns transport/credentials. Mobile Core owns mobile shared infrastructure. Hub/Go/Command/Onboarding are thin consuming surfaces.

`company_id` is the platform tenant. Provider payload data cannot override trusted `CapabilityExecutionContext`.

External mutations follow: request → canonical capability/alias resolution → authority/approval → provider availability → provider execution → structured `CapabilityResult`. Provider failure preserves wizard/session state.
