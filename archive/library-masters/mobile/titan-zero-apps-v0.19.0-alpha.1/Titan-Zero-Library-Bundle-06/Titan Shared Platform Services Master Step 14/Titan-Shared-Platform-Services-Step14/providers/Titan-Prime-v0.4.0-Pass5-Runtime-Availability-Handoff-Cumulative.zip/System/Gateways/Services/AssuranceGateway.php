<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Services;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Contracts\AssuranceGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;

final class AssuranceGateway extends AbstractEngineGateway implements AssuranceGatewayContract
{
    public function engine(): EngineKey { return EngineKey::Assurance; }

    public function verify(TraceContext $trace, array $subject, string $operationId): EngineGatewayResult
    {
        return $this->dispatch($trace, 'assurance.verify', ['subject' => $subject], $operationId);
    }
}
