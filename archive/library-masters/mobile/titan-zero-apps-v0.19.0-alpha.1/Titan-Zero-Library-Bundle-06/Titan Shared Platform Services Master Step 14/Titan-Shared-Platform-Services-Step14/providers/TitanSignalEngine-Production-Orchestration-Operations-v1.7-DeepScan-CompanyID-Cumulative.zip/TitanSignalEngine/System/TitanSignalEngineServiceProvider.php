<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanSignalEngine\System\Contracts\EventTypeRegistryContract;
use App\Extensions\TitanSignalEngine\System\Contracts\ExtensionHealth;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterAuthorityContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalRegistryAuthorityContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryDispatcherContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryLeaseManagerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryRedriveContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliverySchedulerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalSubscriptionRegistryContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEventStoreContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalManagerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalPulseContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalPulseProjectorContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalCorrelationContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalAnomalyContract;
use App\Extensions\TitanSignalEngine\System\Contracts\TraceProfileRegistryContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalQueryContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalArchiveStoreContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalArchiveCatalogContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalHistoryQueryContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalHistoryTraversalContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalLifecycleContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalLifecycleProjectorContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalSourceRateLimiterContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalConsoleContract;
use App\Extensions\TitanSignalEngine\System\Persistence\SignalEventStore;
use App\Extensions\TitanSignalEngine\System\Services\EventTypeRegistry;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority;
use App\Extensions\TitanSignalEngine\System\Services\SignalRegistryAuthority;
use App\Extensions\TitanSignalEngine\System\Services\RegistryOwnershipPolicy;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitter;
use App\Extensions\TitanSignalEngine\System\Services\SignalDeliveryDispatcher;
use App\Extensions\TitanSignalEngine\System\Services\SignalDeliveryLeaseManager;
use App\Extensions\TitanSignalEngine\System\Services\SignalDeliveryRedriveService;
use App\Extensions\TitanSignalEngine\System\Services\SignalDeliveryScheduler;
use App\Extensions\TitanSignalEngine\System\Services\SignalSubscriptionFailureReporter;
use App\Extensions\TitanSignalEngine\System\Services\SignalSubscriptionRegistry;
use App\Extensions\TitanSignalEngine\System\Services\SignalSubscriptionRegistryRevision;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryLeasePolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryRedrivePolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryCachePolicy;
use App\Extensions\TitanSignalEngine\System\Console\Commands\RecoverSignalDeliveries;
use App\Extensions\TitanSignalEngine\System\Console\Commands\RedriveSignalDeliveries;
use App\Extensions\TitanSignalEngine\System\Console\Commands\ProjectSignalPulse;
use App\Extensions\TitanSignalEngine\System\Console\Commands\ScanSignalAnomalies;
use App\Extensions\TitanSignalEngine\System\Console\Commands\EvaluateSignalTraces;
use App\Extensions\TitanSignalEngine\System\Console\Commands\RunSignalHousekeeping;
use App\Extensions\TitanSignalEngine\System\Console\Commands\RefreshSignalHealth;
use App\Extensions\TitanSignalEngine\System\Console\Commands\RebuildSignalArchiveCatalog;
use App\Extensions\TitanSignalEngine\System\Console\Commands\CertifySignalHost;
use App\Extensions\TitanSignalEngine\System\Console\Commands\SyncSignalMenuCommand;
use App\Extensions\TitanSignalEngine\System\Navigation\HostNavigationRegistrar;
use App\Extensions\TitanSignalEngine\System\Navigation\LegacyMenuStore;
use App\Extensions\TitanSignalEngine\System\Navigation\SignalAdminNavigation;
use App\Extensions\TitanSignalEngine\System\Services\SignalManager;
use App\Extensions\TitanSignalEngine\System\Services\PulseAttentionScorer;
use App\Extensions\TitanSignalEngine\System\Services\PulseProjector;
use App\Extensions\TitanSignalEngine\System\Services\PulseQueryService;
use App\Extensions\TitanSignalEngine\System\Services\PulseSurfaceBuilder;
use App\Extensions\TitanSignalEngine\System\Services\SignalOperationalHealthService;
use App\Extensions\TitanSignalEngine\System\Services\AnomalyRuleEvaluator;
use App\Extensions\TitanSignalEngine\System\Services\AnomalyDetectionService;
use App\Extensions\TitanSignalEngine\System\Services\TraceEvaluationProjector;
use App\Extensions\TitanSignalEngine\System\Services\AutomaticTraceEvaluationService;
use App\Extensions\TitanSignalEngine\System\Data\AnomalyThresholds;
use App\Extensions\TitanSignalEngine\System\Data\TraceEvaluationPolicy;
use App\Extensions\TitanSignalEngine\System\Services\SignalPayloadGuard;
use App\Extensions\TitanSignalEngine\System\Services\SignalQueryService;
use App\Extensions\TitanSignalEngine\System\Services\CorrelationService;
use App\Extensions\TitanSignalEngine\System\Services\HistoryCorrelationAssembler;
use App\Extensions\TitanSignalEngine\System\Services\CausalEdgeProjector;
use App\Extensions\TitanSignalEngine\System\Services\TraceAnalyzer;
use App\Extensions\TitanSignalEngine\System\Services\TraceProfileRegistry;
use App\Extensions\TitanSignalEngine\System\Services\LocalSignalArchiveStore;
use App\Extensions\TitanSignalEngine\System\Services\SignalArchiveCatalog;
use App\Extensions\TitanSignalEngine\System\Services\SignalArchiveCatalogRebuilder;
use App\Extensions\TitanSignalEngine\System\Services\SignalHistoryQueryService;
use App\Extensions\TitanSignalEngine\System\Services\RetentionPolicyResolver;
use App\Extensions\TitanSignalEngine\System\Services\SignalLifecycleProjector;
use App\Extensions\TitanSignalEngine\System\Services\SignalLifecycleService;
use App\Extensions\TitanSignalEngine\System\Services\PruneCandidateHasher;
use App\Extensions\TitanSignalEngine\System\Services\SignalBackpressureMonitor;
use App\Extensions\TitanSignalEngine\System\Services\SourceRateLimitPolicy;
use App\Extensions\TitanSignalEngine\System\Services\SignalSourceRateLimiter;
use App\Extensions\TitanSignalEngine\System\Services\SignalHousekeepingService;
use App\Extensions\TitanSignalEngine\System\Services\SignalConsoleService;
use App\Extensions\TitanSignalEngine\System\Services\SignalConsoleContextFactory;
use App\Extensions\TitanSignalEngine\System\Services\SignalConsoleErrorReporter;
use App\Extensions\TitanSignalEngine\System\Services\SignalHostCertificationService;
use App\Extensions\TitanSignalEngine\System\Health\TitanSignalEngineHealthCheck;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

final class TitanSignalEngineServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->app->singleton(\App\Extensions\TitanSignalEngine\System\Workforce\CrossExtensionOrchestrator::class, static fn (): \App\Extensions\TitanSignalEngine\System\Workforce\CrossExtensionOrchestrator => new \App\Extensions\TitanSignalEngine\System\Workforce\CrossExtensionOrchestrator('TitanSignalEngine'));
        $this->app->singleton(\App\Extensions\TitanSignalEngine\System\Workforce\WorkforceLoopRuntime::class, static fn (): \App\Extensions\TitanSignalEngine\System\Workforce\WorkforceLoopRuntime => \App\Extensions\TitanSignalEngine\System\Workforce\WorkforceLoopRuntime::fromContractFile(__DIR__ . '/../workforce-integration.json'));
        $this->app->singleton(\App\Extensions\TitanSignalEngine\System\Workforce\ProviderDiscovery::class, fn (): \App\Extensions\TitanSignalEngine\System\Workforce\ProviderDiscovery => \App\Extensions\TitanSignalEngine\System\Workforce\ProviderDiscovery::fromContractFile($this->app, __DIR__ . '/../workforce-integration.json'));

        $this->app->singleton(\App\Extensions\TitanSignalEngine\System\Workforce\DurableHandoffStoreContract::class, static fn (): \App\Extensions\TitanSignalEngine\System\Workforce\DurableHandoffStoreContract => new \App\Extensions\TitanSignalEngine\Persistence\Workforce\DatabaseDurableHandoffStore());
        $this->app->singleton(\App\Extensions\TitanSignalEngine\System\Workforce\PersistentOrchestrationRuntime::class, static fn ($app): \App\Extensions\TitanSignalEngine\System\Workforce\PersistentOrchestrationRuntime => new \App\Extensions\TitanSignalEngine\System\Workforce\PersistentOrchestrationRuntime($app->make(\App\Extensions\TitanSignalEngine\System\Workforce\CrossExtensionOrchestrator::class), $app->make(\App\Extensions\TitanSignalEngine\System\Workforce\DurableHandoffStoreContract::class)));
        $this->app->singleton(\App\Extensions\TitanSignalEngine\System\Workforce\OrchestrationOperations::class, static fn ($app): \App\Extensions\TitanSignalEngine\System\Workforce\OrchestrationOperations => new \App\Extensions\TitanSignalEngine\System\Workforce\OrchestrationOperations($app->make(\App\Extensions\TitanSignalEngine\System\Workforce\PersistentOrchestrationRuntime::class), $app->make(\App\Extensions\TitanSignalEngine\System\Workforce\DurableHandoffStoreContract::class)));
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-signal-engine.php', 'titan-signal-engine');

        $this->app->singleton(SignalEmitterAuthority::class, static function (): SignalEmitterAuthority {
            $appKey = trim((string) config('app.key', ''));
            if ($appKey === '') {
                throw new \RuntimeException('Titan Signal trusted emitter attestation requires a configured Laravel app.key.');
            }
            return new SignalEmitterAuthority(
                hash('sha256', 'titan-signal-emitter|' . $appKey),
                (array) config('titan-signal-engine.trusted_emitters', []),
            );
        });
        $this->app->alias(SignalEmitterAuthority::class, SignalEmitterAuthorityContract::class);
        $this->app->singleton(SignalRegistryAuthority::class, static function (): SignalRegistryAuthority {
            $appKey = trim((string) config('app.key', ''));
            if ($appKey === '') {
                throw new \RuntimeException('Titan Signal registry attestation requires a configured Laravel app.key.');
            }
            return new SignalRegistryAuthority(
                hash('sha256', 'titan-signal-registry|' . $appKey),
                (array) config('titan-signal-engine.registry_actors', []),
            );
        });
        $this->app->alias(SignalRegistryAuthority::class, SignalRegistryAuthorityContract::class);
        $this->app->singleton(RegistryOwnershipPolicy::class, static fn ($app): RegistryOwnershipPolicy => new RegistryOwnershipPolicy($app->make(SignalRegistryAuthorityContract::class)));
        $this->app->singleton(SignalContextValidator::class, static fn ($app): SignalContextValidator => new SignalContextValidator($app->make(SignalEmitterAuthorityContract::class)));
        $this->app->singleton(SignalPayloadGuard::class, static function (): SignalPayloadGuard {
            return new SignalPayloadGuard(
                (int) config('titan-signal-engine.max_payload_bytes', 65536),
                (int) config('titan-signal-engine.max_metadata_bytes', 8192),
                (array) config('titan-signal-engine.prohibited_reasoning_keys', []),
            );
        });
        $this->app->singleton(EventTypeRegistryContract::class, EventTypeRegistry::class);
        $this->app->singleton(SignalSubscriptionRegistryRevision::class);
        $this->app->singleton(SignalRegistryCachePolicy::class, static fn (): SignalRegistryCachePolicy => new SignalRegistryCachePolicy((int) config('titan-signal-engine.subscription_registry_cache_ttl_seconds', 5)));
        $this->app->singleton(SignalSubscriptionRegistryContract::class, SignalSubscriptionRegistry::class);
        $this->app->singleton(SignalDeliveryLeasePolicy::class, static fn (): SignalDeliveryLeasePolicy => new SignalDeliveryLeasePolicy((int) config('titan-signal-engine.delivery_lease_seconds', 120)));
        $this->app->singleton(SignalDeliveryLeaseManagerContract::class, SignalDeliveryLeaseManager::class);
        $this->app->singleton(SignalDeliveryRedrivePolicy::class);
        $this->app->singleton(SignalDeliverySchedulerContract::class, static fn ($app) => new SignalDeliveryScheduler(
            $app->make(SignalSubscriptionRegistryContract::class),
            $app->make(SignalDeliveryLeaseManagerContract::class),
            (string) config('titan-signal-engine.queue', 'titan-signal-engine'),
        ));
        $this->app->singleton(SignalSubscriptionFailureReporter::class);
        $this->app->singleton(SignalDeliveryDispatcherContract::class, SignalDeliveryDispatcher::class);
        $this->app->singleton(SignalDeliveryRedriveContract::class, SignalDeliveryRedriveService::class);
        $this->app->singleton(SignalEventStoreContract::class, SignalEventStore::class);
        $this->app->singleton(RetentionPolicyResolver::class);
        $this->app->singleton(SignalLifecycleProjectorContract::class, SignalLifecycleProjector::class);
        $this->app->singleton(SignalArchiveStoreContract::class, LocalSignalArchiveStore::class);
        $this->app->singleton(SignalArchiveCatalogContract::class, SignalArchiveCatalog::class);
        $this->app->singleton(SignalHistoryQueryService::class);
        $this->app->singleton(SignalHistoryQueryContract::class, static fn ($app) => $app->make(SignalHistoryQueryService::class));
        $this->app->singleton(SignalHistoryTraversalContract::class, static fn ($app) => $app->make(SignalHistoryQueryService::class));
        $this->app->singleton(SignalArchiveCatalogRebuilder::class);
        $this->app->singleton(PruneCandidateHasher::class);
        $this->app->singleton(SignalLifecycleContract::class, SignalLifecycleService::class);
        $this->app->singleton(SignalBackpressureMonitor::class);
        $this->app->singleton(SourceRateLimitPolicy::class, static function (): SourceRateLimitPolicy {
            return new SourceRateLimitPolicy(
                (int) config('titan-signal-engine.rate_limit_per_source_per_minute', 10000),
                (int) config('titan-signal-engine.rate_limit_system_source_per_minute', 600000),
                (float) config('titan-signal-engine.backpressure_rate_limit_multiplier', 0.5),
            );
        });
        $this->app->singleton(SignalSourceRateLimiterContract::class, SignalSourceRateLimiter::class);
        $this->app->singleton(SignalHousekeepingService::class);
        $this->app->singleton(SignalConsoleContextFactory::class);
        $this->app->singleton(SignalConsoleErrorReporter::class);
        $this->app->singleton(SignalConsoleContract::class, SignalConsoleService::class);
        $this->app->singleton(SignalEmitterContract::class, SignalEmitter::class);
        $this->app->singleton(SignalQueryContract::class, SignalQueryService::class);
        $this->app->singleton(CausalEdgeProjector::class);
        $this->app->singleton(TraceAnalyzer::class);
        $this->app->singleton(HistoryCorrelationAssembler::class);
        $this->app->singleton(TraceEvaluationProjector::class);
        $this->app->singleton(TraceProfileRegistryContract::class, TraceProfileRegistry::class);
        $this->app->singleton(SignalCorrelationContract::class, CorrelationService::class);
        $this->app->singleton(TraceEvaluationPolicy::class, static fn (): TraceEvaluationPolicy => new TraceEvaluationPolicy(
            (int) config('titan-signal-engine.trace_evaluation_partial_retry_seconds', 60),
            (int) config('titan-signal-engine.trace_evaluation_open_retry_seconds', 300),
            (int) config('titan-signal-engine.trace_evaluation_terminal_delay_seconds', 5),
            (int) config('titan-signal-engine.trace_evaluation_invalid_retry_seconds', 900),
        ));
        $this->app->singleton(AutomaticTraceEvaluationService::class);
        $this->app->singleton(PulseAttentionScorer::class);
        $this->app->singleton(PulseSurfaceBuilder::class);
        $this->app->singleton(SignalOperationalHealthService::class);
        $this->app->singleton(SignalPulseProjectorContract::class, PulseProjector::class);
        $this->app->singleton(SignalPulseContract::class, PulseQueryService::class);
        $this->app->singleton(AnomalyThresholds::class, static function (): AnomalyThresholds {
            return new AnomalyThresholds(
                (int) config('titan-signal-engine.anomaly_repeated_failure_count_5m', 5),
                (int) config('titan-signal-engine.anomaly_execution_loop_count', 10),
                (int) config('titan-signal-engine.anomaly_retry_wait_count', 10),
                (int) config('titan-signal-engine.anomaly_dead_letter_count', 1),
                (int) config('titan-signal-engine.anomaly_stalled_trace_count', 1),
                (int) config('titan-signal-engine.anomaly_missing_receipt_count', 1),
                (int) config('titan-signal-engine.anomaly_override_count_1h', 5),
                (int) config('titan-signal-engine.anomaly_sequence_violation_count', 1),
                (int) config('titan-signal-engine.anomaly_unresolved_causation_count', 1),
                (float) config('titan-signal-engine.anomaly_volume_collapse_ratio', 0.20),
                (float) config('titan-signal-engine.anomaly_minimum_baseline_events_per_5m', 10.0),
            );
        });
        $this->app->singleton(AnomalyRuleEvaluator::class);
        $this->app->singleton(SignalAnomalyContract::class, AnomalyDetectionService::class);
        $this->app->singleton(ExtensionHealth::class, TitanSignalEngineHealthCheck::class);
        $this->app->singleton(SignalAdminNavigation::class);
        $this->app->singleton(LegacyMenuStore::class);
        $this->app->singleton(HostNavigationRegistrar::class);
        $this->app->singleton(SignalHostCertificationService::class);
        $this->app->singleton(SignalManagerContract::class, SignalManager::class);
    }

    public function boot(Kernel $kernel): void
    {
        $this->loadTranslationsFrom(__DIR__ . '/../resources/lang', 'titan-signal-engine');
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-signal-engine');
        $this->purgeLegacyCompiledSignalViews();
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->publishes([__DIR__ . '/../config/titan-signal-engine.php' => config_path('titan-signal-engine.php')], 'extension');
        $this->registerRoutes();

        // Register after host boot so modern contribution registries and the legacy
        // MagicAI/Website1408 menus table are both available. The database sync is
        // idempotent and fails open for navigation only.
        $this->app->booted(function (): void {
            try {
                $navigation = $this->app->make(HostNavigationRegistrar::class);
                $navigation->registerContributions();
                $navigation->syncHostMenus();
            } catch (\Throwable) {
                // Navigation compatibility must never prevent Signal Engine boot.
            }
        });

        if ($this->app->runningInConsole()) {
            $this->commands([RecoverSignalDeliveries::class, RedriveSignalDeliveries::class, ProjectSignalPulse::class, RefreshSignalHealth::class, EvaluateSignalTraces::class, ScanSignalAnomalies::class, RunSignalHousekeeping::class, RebuildSignalArchiveCatalog::class, CertifySignalHost::class, SyncSignalMenuCommand::class]);
            $this->app->booted(function (): void {
                /** @var Schedule $schedule */
                $schedule = $this->app->make(Schedule::class);
                $schedule->command('titan:signal-deliveries:recover --limit=' . max(1, min((int) config('titan-signal-engine.delivery_recovery_limit', 250), 1000)))
                    ->everyMinute()
                    ->withoutOverlapping(5)
                    ->onOneServer()
                    ->name('signal-delivery-recovery');
                $schedule->command('titan:signal-pulse:project --limit=1000')
                    ->everyMinute()
                    ->withoutOverlapping(5)
                    ->onOneServer()
                    ->name('signal-pulse-projection');
                $schedule->command('titan:signal-health:refresh')
                    ->everyMinute()
                    ->withoutOverlapping(5)
                    ->onOneServer()
                    ->name('signal-health-refresh');
                $schedule->command('titan:signal-traces:evaluate --limit=250')
                    ->everyMinute()
                    ->withoutOverlapping(5)
                    ->onOneServer()
                    ->name('signal-trace-evaluation');
                $schedule->command('titan:signal-anomalies:scan --limit=100')
                    ->everyMinute()
                    ->withoutOverlapping(5)
                    ->onOneServer()
                    ->name('signal-anomaly-scan');
                $schedule->command('titan:signal-housekeeping --limit=5000')
                    ->dailyAt('02:30')
                    ->withoutOverlapping(60)
                    ->onOneServer()
                    ->name('signal-housekeeping');
            });
        }
    }

    public function registerKey(): string
    {
        return 'titan-signal-engine';
    }

    public static function uninstall(): void
    {
        File::delete(config_path('titan-signal-engine.php'));

        try {
            if (Schema::hasTable('menus') && Schema::hasColumn('menus', 'key')) {
                DB::table('menus')->whereIn('key', [
                    'titan_signal_pulse',
                    'titan_signal_engine_admin',
                    'titan_signal_engine_overview',
                    'titan_signal_engine_pulse_health',
                    'titan_signal_engine_events_traces',
                    'titan_signal_engine_anomalies',
                    'titan_signal_engine_deliveries_dlq',
                    'titan_signal_engine_lifecycle_archives',
                    'titan_signal_engine_registries',
                    'titan_signal_engine_diagnostics',
                ])->delete();
            }
            $menuService = 'App\\Services\\Common\\MenuService';
            if (class_exists($menuService) && method_exists($menuService, 'regenerate')) {
                try {
                    app($menuService)->regenerate();
                } catch (\Throwable) {
                    $menuService::regenerate();
                }
            }
        } catch (\Throwable) {
            // Signal business/audit data is retained; menu cleanup must not block uninstall.
        }
    }


    /**
     * Remove only stale Signal compiled views produced before rc.7 switched to
     * versioned view source paths. We intentionally do not call `view:clear`
     * because an extension must not invalidate every compiled host view.
     */
    private function purgeLegacyCompiledSignalViews(): void
    {
        try {
            $compiler = $this->app->make('blade.compiler');
            if (! is_object($compiler) || ! method_exists($compiler, 'getCompiledPath')) {
                return;
            }

            foreach ([
                __DIR__ . '/../resources/views/admin.blade.php',
                __DIR__ . '/../resources/views/index.blade.php',
            ] as $legacyView) {
                $compiledPath = $compiler->getCompiledPath($legacyView);
                if (! is_string($compiledPath) || $compiledPath === '' || ! File::exists($compiledPath)) {
                    continue;
                }

                $compiledContents = File::get($compiledPath);
                if (str_contains($compiledContents, 'layouts.app')) {
                    File::delete($compiledPath);
                }
            }
        } catch (\Throwable) {
            // Cache cleanup is compatibility-only. Versioned rc.7 view paths
            // guarantee rendering correctness even if the cache is read-only.
        }
    }

    private function registerRoutes(): void
    {
        /** @var Router $router */
        $router = $this->app['router'];
        $router->group(['middleware' => ['web', 'auth'], 'prefix' => 'dashboard/user/titan-signal-engine', 'as' => 'dashboard.user.titan.signal.engine.'], static function (Router $router): void {
            require __DIR__ . '/../routes/user.php';
        });
        $router->group(['middleware' => ['web', 'auth', 'admin'], 'prefix' => 'dashboard/admin/titan-signal-engine', 'as' => 'dashboard.admin.titan.signal.engine.'], static function (Router $router): void {
            require __DIR__ . '/../routes/admin.php';
        });
    }
}
