<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\DTO;

final readonly class GovernancePreflightRequest
{
    public function __construct(
        public string $planId,
        public string $stepId,
        public string $tenantCompanyId,
        public string $actorId,
        public string $actorType,
        public int $authorityLevel,
        public string $capability,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $rootCausationId,
        public array $evidenceRefs = [],
        public array $context = [],
    ) {}
}
