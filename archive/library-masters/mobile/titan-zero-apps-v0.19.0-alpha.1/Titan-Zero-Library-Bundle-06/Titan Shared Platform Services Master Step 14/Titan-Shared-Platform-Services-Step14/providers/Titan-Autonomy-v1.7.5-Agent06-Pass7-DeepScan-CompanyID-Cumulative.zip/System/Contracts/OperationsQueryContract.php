<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface OperationsQueryContract
{
    /** @return list<array<string,mixed>> */
    public function receipts(int $tenantCompanyId, array $filters = [], int $limit = 100): array;
    public function receipt(int $tenantCompanyId, string $correlationId): ?array;
    /** @return list<array<string,mixed>> */
    public function feedback(int $tenantCompanyId, string $receiptPublicId, int $limit = 100): array;
}
