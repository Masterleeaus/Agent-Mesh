# Workforce Integration Report — Titan-AI-Runtime

## Result

This pass makes **Titan-AI-Runtime** a subordinate runtime/provider to Titan AI Workforce. Workforce is the sole active owner of employee identity, organisational roles, hierarchy, teams, responsibilities, assignments, work items and organisational orchestration. The extension publishes runtime/domain execution surfaces only.

## Canonical tenancy

New Workforce-facing contracts use `company_id`. Tier-1 manager and Tier-2 specialist classes are retained as migration/reference code only and removed from the active runtime registry. Tier-3 classes are runtime executors, not Workforce employees.

## Published surfaces

- Capabilities: ai.runtime.inference, ai.runtime.executor.atomic, ai.runtime.context, ai.runtime.provider-gateway, ai.runtime.streaming
- Tools: ai.runtime.status, ai.runtime.resolve-provider, ai.runtime.resolve-model, ai.runtime.execute-capability
- Commands: ai.runtime.execute-governed-capability
- Reads: ai.runtime.status, ai.runtime.model-catalog, ai.runtime.provider-availability
- Signals: ai.runtime.execution.started, ai.runtime.execution.completed, ai.runtime.execution.failed, ai.runtime.provider.degraded
- Work types: ai.inference, ai.capability-execution, ai.context-assembly

## Safety invariants

Installation never grants authority. Availability, authorization, governance, risk and autonomy remain separate decisions. Missing provider/configuration fails closed. Side effects must use the Command Bus or the platform's canonical governed execution boundary. Reads are non-mutating. Provider disable/removal/upgrade does not mutate Workforce employee identity or grant fallback authority.

## Availability states

`available`, `degraded`, `unavailable`, `missing_provider`, `blocked`, `policy_disabled`.

## Verification

See `tests/workforce_integration_contract_runner.php` and the batch report for fresh extracted-package pass counts.
