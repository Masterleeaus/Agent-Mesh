<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface BookingReadPort{public function find(int $companyId,string $bookingRef):?array;public function page(int $companyId,int $limit=25,?string $cursor=null):array;}
