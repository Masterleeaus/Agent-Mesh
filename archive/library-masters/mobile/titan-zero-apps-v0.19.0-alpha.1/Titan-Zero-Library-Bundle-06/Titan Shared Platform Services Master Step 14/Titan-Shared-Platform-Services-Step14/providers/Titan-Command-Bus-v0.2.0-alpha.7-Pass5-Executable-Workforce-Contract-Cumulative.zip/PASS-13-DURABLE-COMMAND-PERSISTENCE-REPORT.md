# Titan Command Bus Pass 13 — Durable Command Persistence

Version: `0.2.0-alpha.6`

Pass 13 adds a durable execution lifecycle without replacing the existing immutable receipt or idempotency stores.

## Durable tables

- `titan_commands`: one tenant-bound current-state record per canonical command operation.
- `titan_command_attempts`: append-only sequenced lifecycle records.
- Existing `titan_command_receipts`: retained as immutable execution evidence.
- Existing `titan_command_idempotency`: retained as the duplicate-execution lock and replay index.

## Lifecycle

`RECEIVED → PREFLIGHT → GOVERNED → AUTHORIZED → EXECUTING → COMPLETED`

Alternative terminal states are `REFUSED` and `FAILED`. Idempotent replay creates a `REPLAYED` observation without changing the original command's terminal state.

## Safety properties

- lifecycle storage is required by default;
- lifecycle unavailability fails closed before adapter execution;
- raw command payloads are not written to lifecycle tables;
- exception messages are not written to lifecycle tables;
- transition sequencing is serialized with row locking and a tenant/command/sequence uniqueness constraint;
- downgrade/uninstall intentionally preserves lifecycle/audit evidence.

## Additional replay correction

Pass 13 also fixes a durable-idempotency defect found during lifecycle testing: previously any stored receipt could replay as `already_applied`, including blocked or failed commands. Replays now preserve blocked/failed terminal status and only a genuinely applied original command returns `already_applied`.
