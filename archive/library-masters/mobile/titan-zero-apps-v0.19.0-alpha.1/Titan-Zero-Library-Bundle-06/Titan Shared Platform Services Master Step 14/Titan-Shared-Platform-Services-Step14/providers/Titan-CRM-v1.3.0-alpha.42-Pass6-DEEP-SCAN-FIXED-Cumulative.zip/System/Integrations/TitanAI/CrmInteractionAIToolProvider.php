<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\TitanAI;

use App\Extensions\Crm\System\Integrations\InteractionEngine\CrmConversationalInteractionService;
use App\Extensions\Crm\System\Integrations\InteractionEngine\CrmInteractionBulkPlanner;
use App\Extensions\Crm\System\Tenancy\CrmCompanyContext;

/**
 * CRM-owned Interaction tools only. Autonomy, planning, proactive execution and
 * learning tools are exposed by their owning Titan extensions, not by CRM Core.
 */
final class CrmInteractionAIToolProvider
{
    public function __construct(
        private CrmConversationalInteractionService $interactions,
        private CrmInteractionBulkPlanner $bulk,
    ) {}

    /** @return array<string,array<string,mixed>> */
    public function all(): array
    {
        return [
            'crm.interaction.resolve'=>$this->d('read',false,'Resolve a plain-language CRM request to the most relevant Interaction Engine journey.'),
            'crm.interaction.start'=>$this->d('read',false,'Start a governed CRM Interaction Engine journey without mutating the business record.'),
            'crm.interaction.answer'=>$this->d('write',true,'Fill the current Interaction Engine wizard step from conversationally gathered facts; final execution remains authority controlled.'),
            'crm.interaction.execute'=>$this->d('write',true,'Request completion of an Interaction Engine session; approval-required actions are never self-approved by AI.'),
            'crm.interaction.chain.plan'=>$this->d('read',false,'Plan one of the explicit CRM multi-step business chains without executing it.'),
            'crm.interaction.chain.continue'=>$this->d('write',true,'Continue an explicit CRM chain after a completed step and start the next governed journey.'),
            'crm.interaction.bulk.preview'=>$this->d('read',false,'Preview a tenant-scoped bulk CRM action against an explicit selection without mutating records.'),
            'crm.interaction.bulk.execute'=>$this->d('write',true,'Execute the exact previously reviewed bulk selection only when explicit confirmation is supplied.'),
        ];
    }

    /** @return array<string,mixed> */
    public function execute(string $tool,array $payload,CrmCompanyContext $context): array
    {
        return match($tool){
            'crm.interaction.resolve'=>$this->interactions->resolveIntent((string)($payload['message']??''),isset($payload['surface'])?(string)$payload['surface']:null),
            'crm.interaction.start'=>$this->interactions->start((string)($payload['journey']??''),$context,(array)($payload['context']??[])),
            'crm.interaction.answer'=>$this->interactions->answer((string)($payload['session_id']??''),(array)($payload['data']??[]),$context),
            'crm.interaction.execute'=>$this->interactions->execute((string)($payload['session_id']??''),$context),
            'crm.interaction.chain.plan'=>$this->interactions->planChain((string)($payload['chain']??''),(array)($payload['context']??[])),
            'crm.interaction.chain.continue'=>$this->interactions->continueChain((string)($payload['chain']??''),(int)($payload['completed_step']??0),(array)($payload['completed_result']??[]),(array)($payload['context']??[]),$context,(bool)($payload['start_next']??true)),
            'crm.interaction.bulk.preview'=>$this->bulk->preview($context,(string)($payload['resource']??''),(string)($payload['action']??''),(array)($payload['public_ids']??[]),(array)($payload['arguments']??[])),
            'crm.interaction.bulk.execute'=>$this->bulk->execute($context,(string)($payload['resource']??''),(string)($payload['action']??''),(array)($payload['public_ids']??[]),(array)($payload['arguments']??[]),(bool)($payload['confirmed']??false)),
            default=>throw new \InvalidArgumentException("Unknown CRM interaction AI tool: {$tool}"),
        };
    }

    /** @return array<string,mixed> */
    private function d(string $mode,bool $approval,string $description): array
    {
        return ['id'=>'','name'=>'','operation'=>'','mode'=>$mode,'permissions'=>['crm.interaction.use'],'requires_approval'=>$approval,'idempotent'=>false,'description'=>$description,'input_schema'=>['type'=>'object','additionalProperties'=>true]];
    }
}
