# Operations

## Health

`ExtensionHealth` exposes independent liveness/readiness and the combined snapshot. Readiness checks database access, archive-storage availability, delivery backpressure and Pulse projection freshness. Status values are `HEALTHY`, `DEGRADED`, `UNAVAILABLE`, `DISABLED`, `MAINTENANCE` and `DRAINING`.

## Scheduled work

- `signal-delivery-recovery` — every minute.
- `signal-pulse-projection` — every minute.
- `signal-health-refresh` — every minute, after Pulse projection.
- `signal-anomaly-scan` — every minute.
- `signal-housekeeping` — daily at 02:30.

All schedules are named, `withoutOverlapping()` and `onOneServer()`.

## Operator commands

- `titan:signal-deliveries:recover`
- `titan:signal-deliveries:redrive --reason=...`
- `titan:signal-pulse:project`
- `titan:signal-health:refresh`
- `titan:signal-anomalies:scan`
- `titan:signal-housekeeping`

Monitor ingestion latency, delivery backlog, Pulse freshness, anomaly scan coverage, archive verification, and unresolved dead letters.

## Delivery leases

Subscriber workers claim delivery rows with expiring compare-and-set leases. `titan:signal-deliveries:recover` may requeue only due rows, stale queued rows, or expired processing leases. Active processing leases must never be reset manually. See `DELIVERY-CONCURRENCY.md`.


## Dead-letter recovery

Use governed redrive only after the subscriber fault is repaired. Redrive preserves `delivery_id` and the stable subscriber idempotency key, appends an immutable audit record, and starts a fresh bounded retry cycle. Historical resolved DLQs remain queryable but are excluded from current backpressure scoring. See `DELIVERY-RECOVERY.md`.

## Transactional pruning

Never prune by recalculating candidates at execution time. Generate a prune preview in the admin console/API, preserve the returned preview token, and confirm that exact preview with a governed reason before expiry. A candidate-set change invalidates the preview. Verified-but-unpruned batches are resumable with the same token. See `TRANSACTIONAL-PRUNING.md`.

Archive streaming uses temporary disk for bounded-memory gzip verification. Monitor host temporary-disk capacity together with archive storage availability.
## Automatic trace evaluation

Run `php artisan titan:signal-traces:evaluate --limit=250` to process due trace/profile assignments. The extension schedules this every minute on one server without overlap, before anomaly scanning. Monitor `health.trace_evaluation.due`, `stale`, and `last_evaluated_at`.



## Pulse and operational health correctness

Pulse freshness is scoped. Tenant dashboards read only their tenant freshness row; system dashboards read system freshness; platform readiness uses the maintained platform projection. Source summaries include source-specific projection freshness. Global operational health is refreshed once per minute into `titan_signal_operational_health_snapshots`, separating current degradation from bounded historical incidents.

Command execution latency is measured from `titan_signal_pulse_command_receipts`, one row per `command.executed`. Receipts prefer direct causation pairing and use the latest unmatched preceding command in the same trace only as an explicit fallback.
