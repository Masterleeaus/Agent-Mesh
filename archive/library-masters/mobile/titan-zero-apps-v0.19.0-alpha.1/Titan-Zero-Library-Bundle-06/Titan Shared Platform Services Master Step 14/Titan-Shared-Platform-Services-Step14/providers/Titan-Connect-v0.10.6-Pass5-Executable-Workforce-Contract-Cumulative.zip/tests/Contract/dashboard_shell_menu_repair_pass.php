<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$passes = [];
$failures = [];
$read = static fn (string $path): string => is_file($root.'/'.$path) ? (string) file_get_contents($root.'/'.$path) : '';
$check = static function (bool $condition, string $label) use (&$passes, &$failures): void {
    if ($condition) { $passes[] = $label; } else { $failures[] = $label; }
};

$web = $read('routes/web.php');
$provider = $read('System/TitanConnectServiceProvider.php');
$navigation = $read('System/Navigation/TitanConnectNavigation.php');
$sync = $read('System/Navigation/MagicAiMenuSynchronizer.php');
$repair = $read('database/migrations/2026_08_10_000008_repair_magicai_dashboard_navigation.php');

$fullPageViews = [
    'resources/views/channels/index.blade.php',
    'resources/views/channels/show.blade.php',
    'resources/views/settings/index.blade.php',
    'resources/views/inbox/index.blade.php',
    'resources/views/inbox/unified.blade.php',
    'resources/views/admin/channels.blade.php',
    'resources/views/voice/call.blade.php',
];
$dashboardRenderer = $read('System/View/MagicAiDashboardRenderer.php');
foreach ($fullPageViews as $viewPath) {
    $view = $read($viewPath);
    $check(!str_contains($view, "@extends('panel.layout.app')"), 'SHELL '.$viewPath.' is a content partial rather than owning the host layout');
    $check(!str_contains($view, "@section('content')"), 'SHELL '.$viewPath.' leaves content section ownership to root renderer');
    $check(str_contains($view, "@push('css')"), 'SHELL '.$viewPath.' pushes Titan Connect styles through host layout');
}
$check(str_contains($dashboardRenderer, "make('panel.layout.app')"), 'SHELL root renderer returns MagicAI panel layout directly');
$check(str_contains($dashboardRenderer, "startSection('content'"), 'SHELL root renderer injects Titan Connect content section');
$check(str_contains($dashboardRenderer, 'incrementRender()') && str_contains($dashboardRenderer, 'decrementRender()'), 'SHELL root renderer preserves Blade push stacks while partial renders');


foreach ([
    'resources/views/inbox/index.blade.php',
    'resources/views/inbox/unified.blade.php',
    'resources/views/channels/show.blade.php',
    'resources/views/settings/index.blade.php',
    'resources/views/voice/call.blade.php',
] as $viewPath) {
    $view = $read($viewPath);
    $check(str_contains($view, "@push('script')"), 'SHELL '.$viewPath.' pushes Titan Connect scripts through host layout');
}

$check(str_contains($web, "->prefix('dashboard/user/titan-connect')"), 'ROUTES canonical user prefix is dashboard/user/titan-connect');
$check(str_contains($web, "->as('dashboard.user.titan-connect.')"), 'ROUTES canonical user names use dashboard.user.titan-connect');
foreach (['inbox.unified','inbox.team','inbox.external','inbox.mine','inbox.unassigned','inbox.needs_human','inbox.closed','channels.index','channels.whatsapp','channels.messenger','channels.instagram','channels.telegram','channels.sms','channels.voice','channels.push'] as $routeName) {
    $check(str_contains($web.$navigation.$repair, 'dashboard.user.titan-connect.'.$routeName), 'ROUTES/menu includes canonical '.$routeName);
}
$check(str_contains($web, "->prefix('dashboard/titan-connect')"), 'ROUTES legacy dashboard/titan-connect compatibility remains available');

$check(str_contains($navigation, "'dashboard.user.titan-connect.channels.index'"), 'NAV user Channels root uses dashboard.user route');
$check(str_contains($navigation, "'dashboard.user.titan-connect.inbox.unified'"), 'NAV user Inbox root uses dashboard.user route');
$check(!preg_match("/'ext_titan_connect_(?:channels|inbox)'[^\n]+?'titan-connect\./", $navigation), 'NAV user roots no longer target legacy route names');

$check($repair !== '', 'REPAIR new v0.10.5 dashboard navigation migration exists');
$check(str_contains($repair, "Schema::hasTable('menus')") && str_contains($repair, "app('db')->table('menus')"), 'REPAIR migration targets live MagicAI menus table');
$check(str_contains($repair, "Schema::hasColumn('menus', 'is_admin')") || str_contains($repair, "'is_admin'"), 'REPAIR migration adapts to is_admin-capable hosts');
$check(str_contains($repair, "'extension' => null"), 'REPAIR keeps legacy extension-plan flag neutral for normal user visibility');
$check(str_contains($repair, "'titan_connect_admin_settings'"), 'REPAIR older host gets single Titan Connect Settings fallback');
$check(str_contains($repair, "'order'=>6") && str_contains($repair, "'order'=>7"), 'REPAIR keeps Inbox and Channels before live host admin_label order 30');
foreach (['titan_connect_admin_settings_whatsapp','titan_connect_admin_settings_messenger','titan_connect_admin_settings_instagram','titan_connect_admin_settings_telegram','titan_connect_admin_settings_sms','titan_connect_admin_settings_voice','titan_connect_admin_settings_push'] as $obsolete) {
    $check(str_contains($repair, $obsolete), 'REPAIR knows obsolete admin child '.$obsolete.' for cleanup');
}
$check(str_contains($repair, 'whereIn') && (str_contains($repair, "'is_active' => 0") || str_contains($repair, 'delete()')), 'REPAIR deactivates/removes obsolete v0.10.4 admin provider children');
$check(!str_contains($repair, 'App\\Extensions\\TitanConnect\\'), 'REPAIR migration remains safe from in-request stale Titan Connect classes');

$check(str_contains($sync, "Schema::hasColumn('menus', 'is_admin')") || str_contains($sync, "isset(\$columns['is_admin'])"), 'SYNC distinguishes modern is_admin hosts from old shared-menu hosts');
$check(str_contains($sync, "'titan_connect_admin_settings'") && str_contains($sync, 'liveHostAdminDefinitions'), 'SYNC old host fallback is one admin Settings entry');
$check(str_contains($sync, 'OBSOLETE_OLD_HOST_ADMIN_KEYS') && str_contains($sync, 'removeOldHostAdminFallback'), 'SYNC removes v0.10.4 per-provider Super Admin fallback rows');
$check(str_contains($sync, "'extension' => null"), 'SYNC does not apply unknown MagicAI plan gating to user navigation');
$check(str_contains($navigation, "'extension' => false") && str_contains($navigation, "'is_admin' => false"), 'NAV user contributions are explicitly non-admin and non-plan-gated');
$check(str_contains($sync, 'safeIcon') || str_contains($sync, 'HOST_SAFE_ICONS'), 'SYNC sanitizes menu icons against host-safe set');

$consolePos = strpos($provider, 'if ($this->app->runningInConsole())');
$assetPublishPos = strpos($provider, "'titan-connect-assets'");
$publishesPos = strpos($provider, '$this->publishes');
$check($publishesPos !== false && $consolePos !== false && $publishesPos < $consolePos, 'ASSETS publish paths register before runningInConsole guard');
$check($assetPublishPos !== false && $consolePos !== false && $assetPublishPos < $consolePos, 'ASSETS web installer can discover titan-connect-assets publish group');

foreach ($passes as $label) echo "PASS: {$label}\n";
foreach ($failures as $label) echo "FAIL: {$label}\n";
printf("dashboard-shell-menu-repair contract suite: %d passed, %d failed\n", count($passes), count($failures));
exit($failures === [] ? 0 : 1);
