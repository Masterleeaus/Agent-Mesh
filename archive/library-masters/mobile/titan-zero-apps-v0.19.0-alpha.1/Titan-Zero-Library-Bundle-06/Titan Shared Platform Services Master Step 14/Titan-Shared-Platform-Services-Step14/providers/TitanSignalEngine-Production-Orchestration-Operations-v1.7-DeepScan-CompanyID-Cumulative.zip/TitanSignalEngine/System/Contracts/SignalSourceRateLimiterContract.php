<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;

interface SignalSourceRateLimiterContract
{
    public function assertAllowed(SignalEnvelope $signal): void;
}
