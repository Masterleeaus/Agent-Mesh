<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_knowledge_jurisdictions')) {
            Schema::create('titan_knowledge_jurisdictions', function (Blueprint $table): void {
                $table->id();
                $table->string('code', 120)->unique();
                $table->string('name', 190);
                $table->string('type', 60)->default('other')->index();
                $table->foreignId('parent_id')->nullable()->constrained('titan_knowledge_jurisdictions')->nullOnDelete();
                $table->char('country_code', 2)->nullable()->index();
                $table->string('status', 40)->default('active')->index();
                $table->timestamp('effective_from')->nullable()->index();
                $table->timestamp('effective_until')->nullable()->index();
                $table->json('aliases')->nullable();
                $table->json('metadata')->nullable();
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
                $table->uuid('trace_id')->nullable()->index();
                $table->uuid('correlation_id')->nullable()->index();
                $table->uuid('causation_id')->nullable()->index();
                $table->timestamps();
            });
        }

        if (Schema::hasTable('titan_knowledge_sources') && ! Schema::hasColumn('titan_knowledge_sources', 'source_key')) {
            Schema::table('titan_knowledge_sources', function (Blueprint $table): void {
                $table->string('source_key', 190)->nullable()->after('id');
                $table->string('scope_type', 40)->default('legacy')->after('source_key')->index();
                $table->string('scope_key', 190)->default('legacy')->after('scope_type')->index();
                $table->foreignId('jurisdiction_id')->nullable()->after('tenant_company_id')->constrained('titan_knowledge_jurisdictions')->nullOnDelete();
                $table->string('authority_class', 80)->default('unknown')->after('jurisdiction_id')->index();
                $table->unsignedSmallInteger('authority_rank')->nullable()->after('authority_class')->index();
                $table->string('publisher', 190)->nullable()->after('authority_rank');
                $table->text('canonical_uri')->nullable()->after('publisher');
                $table->string('retrieval_method', 80)->default('legacy')->after('canonical_uri')->index();
                $table->boolean('official_source')->default(false)->after('retrieval_method')->index();
                $table->json('access_policy')->nullable()->after('official_source');
                $table->json('provenance')->nullable()->after('access_policy');
                $table->timestamp('published_at')->nullable()->after('provenance');
                $table->timestamp('last_checked_at')->nullable()->after('published_at')->index();
                $table->timestamp('last_changed_at')->nullable()->after('last_checked_at')->index();
                $table->timestamp('next_refresh_at')->nullable()->after('last_changed_at')->index();
                $table->timestamp('stale_after')->nullable()->after('next_refresh_at')->index();
                $table->unique(['scope_key', 'source_key'], 'tka_sources_scope_source_unique');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('titan_knowledge_sources') && Schema::hasColumn('titan_knowledge_sources', 'source_key')) {
            Schema::table('titan_knowledge_sources', function (Blueprint $table): void {
                $table->dropUnique('tka_sources_scope_source_unique');
                $table->dropForeign(['jurisdiction_id']);
                $table->dropColumn([
                    'source_key', 'scope_type', 'scope_key', 'jurisdiction_id', 'authority_class', 'authority_rank',
                    'publisher', 'canonical_uri', 'retrieval_method', 'official_source', 'access_policy', 'provenance',
                    'published_at', 'last_checked_at', 'last_changed_at', 'next_refresh_at', 'stale_after',
                ]);
            });
        }

        Schema::dropIfExists('titan_knowledge_jurisdictions');
    }
};
