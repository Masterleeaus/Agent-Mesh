<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use DateTimeImmutable;

final readonly class SignalReceipt
{
    public function __construct(
        public string $eventId,
        public DateTimeImmutable $recordedAt,
        public bool $duplicate = false,
        public ?string $originalEventId = null,
    ) {
    }

    /** @return array{event_id:string,recorded_at:string,duplicate:bool,original_event_id:?string} */
    public function toArray(): array
    {
        return [
            'event_id' => $this->eventId,
            'recorded_at' => $this->recordedAt->format(DATE_ATOM),
            'duplicate' => $this->duplicate,
            'original_event_id' => $this->originalEventId,
        ];
    }
}
