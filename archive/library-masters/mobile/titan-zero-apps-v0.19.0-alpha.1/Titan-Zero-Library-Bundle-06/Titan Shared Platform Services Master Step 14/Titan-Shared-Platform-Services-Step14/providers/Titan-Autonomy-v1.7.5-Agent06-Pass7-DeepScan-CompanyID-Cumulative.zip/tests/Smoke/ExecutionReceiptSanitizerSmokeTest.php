<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\Services\ExecutionReceiptSanitizer;

$s = new ExecutionReceiptSanitizer();
$out = $s->sanitize([
    'title' => 'Invoice',
    'api_key' => 'private-value',
    'nested' => ['authorization' => 'Bearer private-value', 'normal' => 42],
    'password' => 'private-value',
]);
if (($out['title'] ?? null) !== 'Invoice' || ($out['nested']['normal'] ?? null) !== 42) throw new RuntimeException('Non-sensitive business fields must remain.');
if (($out['api_key'] ?? null) !== '[REDACTED]' || ($out['password'] ?? null) !== '[REDACTED]' || ($out['nested']['authorization'] ?? null) !== '[REDACTED]') {
    throw new RuntimeException('Credential-like execution receipt fields must be redacted.');
}

echo "OK: ExecutionReceiptSanitizerSmokeTest\n";
