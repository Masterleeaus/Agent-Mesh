<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Contracts;

use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompilationPreview;
use App\Extensions\TitanNexus\System\Domain\NexusCompilation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\RecompilePlan;
use App\Extensions\TitanNexus\System\Domain\ValidationResult;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;

interface NexusManagerContract
{
    /** @return array<string, mixed> */
    public function health(): array;

    public function newDraft(BusinessProfile $profile, TraceContext $traceContext, string $compilationUuid): NexusCompilation;

    public function validateDraft(NexusCompilation $draft): ValidationResult;

    public function previewDraft(NexusCompilation $draft, string $configurationVersion = '1'): CompilationPreview;

    public function compileDraft(NexusCompilation $draft, string $configurationVersion = '1'): NexusCompilation;


    public function planProvisioning(NexusCompilation $compiled): NexusCompilation;

    public function executeProvisioning(
        NexusCompilation $compiled,
        TraceContext $traceContext,
        bool $approvalGranted = false,
        ?ProvisioningExecutionContext $executionContext = null,
    ): NexusCompilation;

    public function planRecompile(
        NexusCompilation $current,
        BusinessProfile $updatedProfile,
        TraceContext $traceContext,
        string $compilationUuid,
        string $configurationVersion,
    ): RecompilePlan;
}
