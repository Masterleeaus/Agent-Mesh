<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Providers;

use App\Extensions\Crm\System\Integrations\Chatbot\{CrmChatbotCompatibility,CrmChatbotIdentityService,CrmChatbotIntegrationRegistrar,CrmChatbotSessionGrantService,CrmChatbotSettingsService,CrmChatbotToolPolicy,CrmChatbotToolService};
use App\Extensions\Crm\System\Integrations\InteractionEngine\{CrmConversationalInteractionService,CrmInteractionAuthorityPolicy,CrmInteractionCapabilityHandler,CrmInteractionIntegrationRegistrar,CrmInteractionJourneyRegistry,CrmInteractionPresentationAdapter,CrmInteractionSurfaceService};
use App\Extensions\Crm\System\Integrations\TitanAI\{CrmInteractionAIToolProvider,CrmTitanAIIntegrationRegistrar,CrmTitanAIToolProvider};
use App\Extensions\Crm\System\Integrations\TitanMobile\{CrmMobileIdentityResolver,CrmTitanMobileIntegrationRegistrar};
use App\Extensions\Crm\System\Integrations\TitanAutonomy\{CrmAutonomyDecisionPort,CrmDeferredAutonomyDecisionPort};
use Illuminate\Support\ServiceProvider;

final class CrmTitanIntegrationServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        if (!$this->app->bound(CrmAutonomyDecisionPort::class)) {
            $this->app->singleton(CrmAutonomyDecisionPort::class, CrmDeferredAutonomyDecisionPort::class);
        }
        foreach ([
            CrmChatbotCompatibility::class, CrmChatbotSettingsService::class, CrmChatbotIdentityService::class,
            CrmChatbotSessionGrantService::class, CrmChatbotToolPolicy::class, CrmChatbotToolService::class,
            CrmChatbotIntegrationRegistrar::class, CrmMobileIdentityResolver::class, CrmTitanMobileIntegrationRegistrar::class,
            CrmTitanAIToolProvider::class, CrmInteractionAIToolProvider::class, CrmTitanAIIntegrationRegistrar::class,
            CrmConversationalInteractionService::class, CrmInteractionAuthorityPolicy::class, CrmInteractionCapabilityHandler::class, CrmInteractionJourneyRegistry::class, CrmInteractionPresentationAdapter::class, CrmInteractionSurfaceService::class, CrmInteractionIntegrationRegistrar::class,
        ] as $service) {
            $this->app->singleton($service);
        }
    }

    public function boot(): void
    {
        $this->app->booted(function (): void {
            foreach ([CrmChatbotIntegrationRegistrar::class, CrmTitanMobileIntegrationRegistrar::class, CrmTitanAIIntegrationRegistrar::class, CrmInteractionIntegrationRegistrar::class] as $registrar) {
                try { $this->app->make($registrar)->register(); } catch (\Throwable $e) { report($e); }
            }
        });
    }
}
