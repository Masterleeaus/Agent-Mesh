<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Extensions\TitanSignalEngine\System\Data\EventTypeDefinition;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Persistence\SignalEventStore;
use App\Extensions\TitanSignalEngine\System\Services\EventTypeRegistry;
use App\Extensions\TitanSignalEngine\System\Services\SignalRegistryAuthority;
use App\Extensions\TitanSignalEngine\System\Services\RegistryOwnershipPolicy;
use App\Extensions\TitanSignalEngine\System\Services\LocalSignalArchiveStore;
use App\Extensions\TitanSignalEngine\System\Services\SignalArchiveCatalog;
use App\Extensions\TitanSignalEngine\System\Services\SignalHistoryQueryService;
use App\Extensions\TitanSignalEngine\System\Services\SignalQueryService;
use App\Extensions\TitanSignalEngine\System\Services\RetentionPolicyResolver;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitter;
use App\Extensions\TitanSignalEngine\System\Services\SignalLifecycleProjector;
use App\Extensions\TitanSignalEngine\System\Services\SignalLifecycleService;
use App\Extensions\TitanSignalEngine\System\Services\PruneCandidateHasher;
use App\Extensions\TitanSignalEngine\System\Services\SignalPayloadGuard;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

final class LifecycleRuntimeIntegrationTest extends TestCase
{
    private SignalEmitter $emitter;
    private \App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority $emitterAuthority;
    private SignalLifecycleService $lifecycle;

    protected function setUp(): void
    {
        parent::setUp();
        foreach (glob(dirname(__DIR__, 2) . '/database/migrations/*.php') ?: [] as $migrationFile) {
            $migration = require $migrationFile;
            $migration->up();
        }
        Storage::fake('local');
        config()->set('titan-signal-engine.archive_disk', 'local');
        config()->set('titan-signal-engine.prune_batch_limit', 100);

        $store = new SignalEventStore();
        $this->emitterAuthority = new \App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority('feature-test-secret', [
            'test-service:test-suite:root' => [
                'source' => 'test-suite',
                'source_component' => null,
                'permissions' => ['signal.emit'],
                'event_type_patterns' => ['*'],
            ],
        ]);
        $validator = new SignalContextValidator($this->emitterAuthority);
        $registryAuthority = new SignalRegistryAuthority('feature-registry-secret', [
            'test-registry' => [
                'owner_source' => 'test-suite',
                'permissions' => ['signal.registry.event.manage', 'signal.registry.override'],
                'event_type_patterns' => ['*'],
                'subscriber_key_patterns' => ['*'],
            ],
        ]);
        $registryIdentity = $registryAuthority->issue('test-registry');
        $ownership = new RegistryOwnershipPolicy($registryAuthority);
        $registry = new EventTypeRegistry($ownership);
        $registry->register(EventTypeDefinition::fromArray([
            'event_type' => 'test.lifecycle',
            'current_schema_version' => 1,
            'supported_schema_versions' => [1],
            'category' => 'operations',
            'allowed_scopes' => ['tenant'],
            'required_payload_fields' => ['customer'],
            'optional_payload_fields' => [],
            'allow_additional_payload_fields' => false,
            'owner_source' => 'test-suite',
            'allowed_severities' => ['info'],
        ]), $registryIdentity);
        $projector = new SignalLifecycleProjector(new RetentionPolicyResolver());
        $this->emitter = new SignalEmitter($store, $registry, $validator, new SignalPayloadGuard(65536, 8192, []), null, null, $projector);
        $archiveStore = new LocalSignalArchiveStore();
        $archiveCatalog = new SignalArchiveCatalog();
        $history = new SignalHistoryQueryService(new SignalQueryService($store, $validator), $archiveCatalog, $archiveStore, $validator);
        $this->lifecycle = new SignalLifecycleService($store, $validator, $archiveStore, $archiveCatalog, $history, new PruneCandidateHasher());
    }


    private function emitTrusted(
        \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope|array $signal,
        ?\App\Extensions\TitanSignalEngine\System\Data\SignalContext $context = null,
    ): \App\Extensions\TitanSignalEngine\System\Data\SignalReceipt {
        $source = is_array($signal) ? (string) ($signal['source'] ?? 'test-suite') : $signal->source;
        $component = is_array($signal) ? ($signal['source_component'] ?? null) : $signal->sourceComponent;
        $scope = is_array($signal) ? (string) ($signal['scope'] ?? 'tenant') : $signal->scope;
        $tenant = is_array($signal) ? ($signal['tenant_company_id'] ?? null) : $signal->tenantCompanyId;
        $serviceId = 'test-service:' . $source . ':' . ($component ?? 'root');
        $identity = $this->emitterAuthority->issue($serviceId);
        if ($context === null) {
            $context = $scope === 'system'
                ? \App\Extensions\TitanSignalEngine\System\Data\SignalContext::system('test-system', 'test', ['signal.tenant.emit'], $identity)
                : \App\Extensions\TitanSignalEngine\System\Data\SignalContext::tenantHuman((int) $tenant, 'test-user', 'test-session', 'test', $identity);
        } else {
            $context = new \App\Extensions\TitanSignalEngine\System\Data\SignalContext(
                $context->scope,
                $context->tenantCompanyId,
                $context->actor,
                $context->permissions,
                $identity,
            );
        }

        return $this->emitter->emit($signal, $context);
    }

    public function test_redaction_projects_privacy_safe_view_without_mutating_event(): void
    {
        $receipt = $this->emitTrusted([
            'event_type' => 'test.lifecycle', 'tenant_company_id' => 7, 'source' => 'test-suite',
            'payload' => ['customer' => ['name' => 'Jane', 'email' => 'secret@example.com']],
        ]);
        $context = new SignalContext('tenant', 7, new \App\Extensions\TitanSignalEngine\System\Data\SignalActor('usr_7', 'human', 7, 'titan-auth', 'session_7'), ['signal.redact']);
        $originalChecksum = DB::table('titan_signal_events')->where('event_id', $receipt->eventId)->value('checksum');
        $this->lifecycle->redact($receipt->eventId, [['op' => 'remove', 'path' => 'payload.customer.email']], 'privacy request', $context);
        $view = $this->lifecycle->view($receipt->eventId, $context, 7, 'tenant');
        self::assertArrayNotHasKey('email', $view['event']['payload']['customer']);
        self::assertSame($originalChecksum, DB::table('titan_signal_events')->where('event_id', $receipt->eventId)->value('checksum'));
    }

    public function test_legal_hold_blocks_prune_and_verified_archive_precedes_delete(): void
    {
        $receipt = $this->emitTrusted([
            'event_type' => 'test.lifecycle', 'tenant_company_id' => 7, 'source' => 'test-suite',
            'payload' => ['customer' => ['name' => 'Jane', 'email' => 'secret@example.com']],
        ]);
        DB::table('titan_signal_event_lifecycle')->where('event_id', $receipt->eventId)->update(['retain_until' => now()->subDay()]);
        $context = new SignalContext('tenant', 7, new \App\Extensions\TitanSignalEngine\System\Data\SignalActor('usr_7', 'human', 7, 'titan-auth', 'session_7'), ['signal.retention.manage']);

        $this->lifecycle->setLegalHold($receipt->eventId, true, 'investigation', $context);
        self::assertSame(0, $this->lifecycle->previewPrune(7, 'tenant', 10, $context)['candidate_count']);
        $this->lifecycle->setLegalHold($receipt->eventId, false, 'investigation complete', $context);
        $preview = $this->lifecycle->previewPrune(7, 'tenant', 10, $context);
        self::assertSame(1, $preview['candidate_count']);

        $result = $this->lifecycle->prune($preview['preview_token'], 'retention expiry', $context);
        self::assertSame(1, $result['pruned']);
        self::assertFalse(DB::table('titan_signal_events')->where('event_id', $receipt->eventId)->exists());
        self::assertTrue(DB::table('titan_signal_archive_batches')->where('batch_id', $result['batch_id'])->where('status', 'pruned')->exists());
        self::assertTrue(DB::table('titan_signal_lifecycle_audit')->where('batch_id', $result['batch_id'])->where('action', 'events.pruned')->exists());
    }

    public function test_prune_requires_valid_preview_token(): void
    {
        $context = new SignalContext('tenant', 7, new \App\Extensions\TitanSignalEngine\System\Data\SignalActor('usr_7', 'human', 7, 'titan-auth', 'session_7'), ['signal.retention.manage']);
        $this->expectException(\InvalidArgumentException::class);
        $this->lifecycle->prune('not-a-preview-token', 'retention expiry', $context);
    }

    public function test_preview_is_invalidated_if_candidate_set_changes_before_confirmation(): void
    {
        $receipt = $this->emitTrusted([
            'event_type' => 'test.lifecycle', 'tenant_company_id' => 7, 'source' => 'test-suite',
            'payload' => ['customer' => ['name' => 'Jane']],
        ]);
        DB::table('titan_signal_event_lifecycle')->where('event_id', $receipt->eventId)->update(['retain_until' => now()->subDay()]);
        $context = new SignalContext('tenant', 7, new \App\Extensions\TitanSignalEngine\System\Data\SignalActor('usr_7', 'human', 7, 'titan-auth', 'session_7'), ['signal.retention.manage']);
        $preview = $this->lifecycle->previewPrune(7, 'tenant', 10, $context);
        $this->lifecycle->setLegalHold($receipt->eventId, true, 'new investigation', $context);
        $this->expectException(\InvalidArgumentException::class);
        $this->lifecycle->prune($preview['preview_token'], 'retention expiry', $context);
    }
    public function test_pruned_event_remains_governedly_readable_from_verified_archive(): void
    {
        $receipt = $this->emitTrusted([
            'event_type' => 'test.lifecycle', 'tenant_company_id' => 7, 'source' => 'test-suite',
            'payload' => ['customer' => ['name' => 'Jane', 'email' => 'secret@example.com']],
        ]);
        DB::table('titan_signal_event_lifecycle')->where('event_id', $receipt->eventId)->update(['retain_until' => now()->subDay()]);
        $manage = new SignalContext('tenant', 7, new \App\Extensions\TitanSignalEngine\System\Data\SignalActor('usr_7', 'human', 7, 'titan-auth', 'session_7'), ['signal.retention.manage']);
        $preview = $this->lifecycle->previewPrune(7, 'tenant', 10, $manage);
        $this->lifecycle->prune($preview['preview_token'], 'retention expiry', $manage);

        self::assertFalse(DB::table('titan_signal_events')->where('event_id', $receipt->eventId)->exists());
        self::assertTrue(DB::table('titan_signal_archive_catalog')->where('event_id', $receipt->eventId)->exists());

        $view = $this->lifecycle->view($receipt->eventId, SignalContext::tenantHuman(7, 'reader-7', 'sess-7', 'test'), 7, 'tenant');
        self::assertNotNull($view);
        self::assertSame('cold', $view['projection']['storage_tier']);
        self::assertTrue($view['projection']['archive_verified']);
        self::assertSame($receipt->eventId, $view['event']['event_id']);
    }

    public function test_no_archive_retention_class_prunes_without_creating_cold_catalog_entry(): void
    {
        $receipt = $this->emitTrusted([
            'event_type' => 'test.lifecycle', 'tenant_company_id' => 7, 'source' => 'test-suite',
            'payload' => ['customer' => ['name' => 'Debug']],
        ]);
        DB::table('titan_signal_event_lifecycle')->where('event_id', $receipt->eventId)->update([
            'retention_class' => 'debug', 'retain_until' => now()->subDay(),
        ]);
        $context = new SignalContext('tenant', 7, new \App\Extensions\TitanSignalEngine\System\Data\SignalActor('usr_7', 'human', 7, 'titan-auth', 'session_7'), ['signal.retention.manage']);
        $preview = $this->lifecycle->previewPrune(7, 'tenant', 10, $context);
        $result = $this->lifecycle->prune($preview['preview_token'], 'debug retention expiry', $context);

        self::assertSame(1, $result['pruned']);
        self::assertSame(0, $result['archived']);
        self::assertFalse(DB::table('titan_signal_archive_catalog')->where('event_id', $receipt->eventId)->exists());
        self::assertTrue(DB::table('titan_signal_archive_batches')->where('batch_id', $result['batch_id'])->where('archive_driver', 'none')->where('status', 'pruned')->exists());
    }

    public function test_live_preview_execution_lease_rejects_second_executor(): void
    {
        $receipt = $this->emitTrusted([
            'event_type' => 'test.lifecycle', 'tenant_company_id' => 7, 'source' => 'test-suite',
            'payload' => ['customer' => ['name' => 'Lease']],
        ]);
        DB::table('titan_signal_event_lifecycle')->where('event_id', $receipt->eventId)->update(['retain_until' => now()->subDay()]);
        $context = new SignalContext('tenant', 7, new \App\Extensions\TitanSignalEngine\System\Data\SignalActor('usr_7', 'human', 7, 'titan-auth', 'session_7'), ['signal.retention.manage']);
        $preview = $this->lifecycle->previewPrune(7, 'tenant', 10, $context);
        DB::table('titan_signal_prune_previews')->where('preview_id', $preview['preview_id'])->update([
            'status' => 'claimed', 'execution_token' => hash('sha256', 'other-worker'), 'execution_started_at' => now(), 'execution_expires_at' => now()->addMinutes(5),
        ]);
        $this->expectException(\InvalidArgumentException::class);
        $this->lifecycle->prune($preview['preview_token'], 'retention expiry', $context);
    }

}
