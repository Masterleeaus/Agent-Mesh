# CRM 1.3.0-alpha.37 Menu Self-Healing Report

## Live symptom

After alpha.36 installed successfully, the host sidebar still displayed the pre-restructure CRM tree: Customers contained Support and Reviews/Recovery, and old top-level Work / Leads / Money groups retained payment and receivables links. Many of those links no longer belonged to CRM Core and did not resolve correctly.

## Root cause

Alpha.36 updated `CrmMenuInstaller`, including the retired-key registry, but did not add a new migration that invoked the synchronizer. Long-lived hosts had already recorded migrations `000021` through `000024`, so Laravel correctly skipped them and the revised menu synchronizer never ran during upgrade.

## Correction

- Added migration `000046_resync_crm_core_menu.php` after canonical company-tenancy migration `000045`.
- `000046` always calls `CrmMenuInstaller::sync()` when the host `menus` table is available.
- Existing menu rows are updated in place by stable keys, children are reparented to the canonical groups, and retired historical keys are deactivated.
- Added `MenuResyncMigrationTest.php` to prevent a future menu-definition-only release from omitting the forward trigger.
- Added `MenuRouteContractTest.php` to certify all canonical menu route names against `routes/web.php`.

## Canonical user menu

- Overview
- Customers: Companies, Contacts, Customer Hub, Sharing
- Sales: Leads, Opportunities, Pipelines, Quotes, Estimates
- Projects: Projects, Tasks, Calendar
- Commercial: Invoices
- Insights: Reports, Presentations, Data Quality
- Automate: CRM Assistant, Automations, Integrations, Chatbot Integration
- Settings: Settings, Fields and Tags, Import / Export, Privacy and Retention

Extracted Field, Locker, Ledger/finance, Titan Pay and historical autonomy links are not CRM Core navigation.
