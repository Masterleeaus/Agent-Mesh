<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Http\Controllers;

use App\Extensions\TitanAICore\System\Contracts\HealthCheckContract;
use App\Extensions\TitanAICore\System\Contracts\HostLayoutResolverContract;
use App\Extensions\TitanAICore\System\Contracts\RuntimeManagerContract;
use Illuminate\Contracts\View\View;

final class AdminController
{
    public function __invoke(
        RuntimeManagerContract $runtime,
        HealthCheckContract $health,
        HostLayoutResolverContract $layouts,
    ): View {
        return view('titan-ai-core::admin', [
            'runtime' => $runtime->status(),
            'health' => $health->check(),
            'hostLayout' => $layouts->resolve(),
        ]);
    }
}
