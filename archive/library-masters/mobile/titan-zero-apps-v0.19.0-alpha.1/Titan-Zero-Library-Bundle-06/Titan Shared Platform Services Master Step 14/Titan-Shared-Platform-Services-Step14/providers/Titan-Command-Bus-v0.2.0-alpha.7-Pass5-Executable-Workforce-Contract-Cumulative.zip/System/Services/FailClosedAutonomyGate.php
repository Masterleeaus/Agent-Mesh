<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Services;

use App\Extensions\TitanCommandBus\System\Contracts\CommandAutonomyGateContract;
use App\Extensions\TitanCommandBus\System\DTO\AssuranceDecision;
use App\Extensions\TitanCommandBus\System\DTO\AutonomyDecision;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use App\Extensions\TitanCommandBus\System\DTO\RiskDecision;

final class FailClosedAutonomyGate implements CommandAutonomyGateContract
{
    public function available(): bool
    {
        return false;
    }

    public function resolve(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null, ?AssuranceDecision $assurance = null): AutonomyDecision
    {
        return AutonomyDecision::unavailable();
    }
}
