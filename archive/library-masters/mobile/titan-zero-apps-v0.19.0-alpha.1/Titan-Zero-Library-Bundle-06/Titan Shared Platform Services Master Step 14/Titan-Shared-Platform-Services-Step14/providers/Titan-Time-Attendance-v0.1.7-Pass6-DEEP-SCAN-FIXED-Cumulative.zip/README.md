# Titan Time & Attendance

Titan-native conversion of the Timesheet and attendance module family into one authoritative Titan Zero extension.

## 0.1.1 menu hotfix — Titan/MagicAI navigation integration

This cumulative release preserves the completed five-pass conversion and adds the missing Titan/MagicAI sidebar integration discovered during live installation on Titan Extension Manager 1.7.8.

Final-pass additions include:

- Titan Custom Extension Manager **1.7.8** manifest compatibility, including dependency objects with `slug` and bare SHA-256 values in `integrity.files`
- extension-owned `Time & Attendance` sidebar contribution through Titan menu registries
- idempotent MagicAI `menus` compatibility sync with administrator order/enabled-state preservation
- `titan-time-attendance:host-sync` recovery command and MagicAI menu-cache regeneration
- retained-data reinstall-safe base migrations for non-destructive uninstall/reinstall cycles
- leased Signal outbox delivery with transactional `lockForUpdate` claiming, unique claim tokens and stale-worker lease recovery
- bounded exponential Signal retry with dead-lettering rather than infinite retry loops
- exception-class-only persisted delivery diagnostics; raw exception messages are not stored
- multi-node scheduler safety through `withoutOverlapping` and `onOneServer`
- exact packaged-byte release verifier including traversal, symlink, case-collision, wrapper, provider-identity, integrity and 250x archive-expansion checks
- final upgrade/rollback/disable/uninstall lifecycle documentation and host-verification boundary

The release remains deliberately fail-closed where a peer Titan engine does not expose a compatible callable runtime contract. No synthetic Command Bus, Risk, Assurance, Governance or other peer API is fabricated merely to claim integration.

## Core domain capabilities

- tenant-scoped time-entry creation and reads
- running timers with transactional stop → time-entry conversion
- weekly timesheet submission and permission-gated approval/rejection
- cost calculation foundation
- geofence attendance verification
- dynamic and static QR verification
- tenant-owned trusted-IP verification
- explicit rejection of bare site-ID presence assertions
- privacy-minimised attendance verification evidence
- replay-safe offline attendance ingestion and reconciliation
- governed time/attendance policy reads and updates
- proactive attention findings and workflow inspection

## Donor modules

The conversion draws from **Timesheet** as the primary backbone plus FSMTimesheet, SiteAttendance, GeofenceSystem, DynamicQrAttendance, QRAttendance, OfflineTracking and IpAddressAttendance. The legacy modules are not installed alongside this extension; useful behavior is converged into this single authority.

## Data authority

All extension-owned persisted records use `tenant_company_id` and `ext_titan_time_*` tables. The extension does not mutate legacy shared `users`, `sites`, `attendances`, CRM records or other foreign-owned tables.

CRM remains authoritative for work orders and service locations. When a canonical CRM public reference is supplied, the extension resolves it through CRM's governed capability executor and fails closed if CRM authority is required but unavailable.

## AI Workforce ownership

Agent definitions live in `resources/workforce/workforce-manifest.json` and remain owned by this extension. Titan Workforce discovers the manifest; it should not maintain duplicate role definitions.

Current extension-owned roles:

- **Time & Attendance Manager** — Tier 1
- **Timesheet Auditor** — Tier 2
- **Attendance Exception Specialist** — Tier 2
- **Workforce Presence Agent** — Tier 2

The manifest also exports skills, prompts, 18 bounded tools, active proposal wizards, Signal workflows and generative surfaces. Read tools re-check the underlying human principal's extension permission. Write tools use trusted Workforce context, role/capability/risk gates and Command Bus governance; model input cannot supply tenant identity, actor identity or authoritative trace/idempotency fields.

## Proactive intelligence

`TimeAttentionDetector` is intentionally read-only against authoritative time/attendance records. `TimeAttentionService` persists only derived attention findings and emits Signals when findings are created or reopened. When an underlying condition clears, the finding is resolved rather than left permanently actionable.

The scheduled `titan-time-attendance:scan-attention` command discovers applicable tenants and dispatches tenant-specific `DetectTimeAttentionJob` work to the `titan-time-attendance` queue.

## Signal workflows and delivery

The extension consumes selected canonical `titan.signal` envelopes and creates idempotent Workforce workflow receipts for failed attendance verification, overdue timers, submissions ready for review and rejected offline attendance evidence.

Outbound Signal transport is **at-least-once** with stable event/deduplication identity. Outbox rows are tenant-partitioned and leased before delivery. Crashed workers leave recoverable leases; bounded retries eventually dead-letter persistent failures instead of looping forever. Signal processing never directly mutates authoritative time records.

## Offline / Titan Go contract

Offline attendance events require both `source_event_id` and a monotonic `device_sequence`. The extension maintains two replay guards:

- `tenant_company_id + source_event_id`
- `tenant_company_id + pseudonymous device_id + device_sequence`

Offline presence evidence is re-run through the canonical `AttendanceVerificationService` on the server before it becomes verified evidence. The reconciliation record stores the canonical verification-log ID. Raw QR tokens and IP addresses are not persisted. Raw coordinates are disabled by default; when disabled, location evidence is HMAC-minimised with a tenant-derived key. Device identifiers are also tenant-pseudonymised before persistence.

## Verification

Run the cumulative standalone package gates:

```bash
php tests/Architecture/pass2_contract_test.php
php tests/Architecture/pass3_contract_test.php
php tests/Architecture/pass4_contract_test.php
php tests/Architecture/pass5_release_contract_test.php
php tests/Architecture/installer_1_7_8_integrity_contract_test.php
php tests/Architecture/menu_navigation_contract_test.php
php tests/Unit/workforce_decision_policy_test.php
php tests/Unit/workflow_signal_boundary_test.php
php tests/Unit/wizard_registry_contract_test.php
php tests/Unit/rewind_record_projector_test.php
php tests/Unit/platform_export_registry_test.php
php tests/Unit/package_integrity_verifier_test.php
php tests/Unit/signal_delivery_policy_test.php
php bin/verify.php
```

For a built release ZIP also run:

```bash
php bin/verify-release.php /path/to/Titan-Time-Attendance-v0.1.1-Installer-1.7.8-Menu-Hotfix-Cumulative.zip
```

See `docs/README.md`, `docs/releases/PASS5-FINAL-RELEASE-REPORT.md`, `docs/architecture/ARCHITECTURE.md` and `docs/installer/UPGRADE-ROLLBACK-UNINSTALL.md`.

## Host navigation

Titan Time & Attendance contributes a `Time & Attendance` user-sidebar entry to current Titan/MagicAI hosts. It registers through the Blueprint-v3 contribution registries when available and also performs an idempotent compatibility sync into MagicAI's `menus` table. If a host cache remains stale after upgrade, run `php artisan titan-time-attendance:host-sync`.
