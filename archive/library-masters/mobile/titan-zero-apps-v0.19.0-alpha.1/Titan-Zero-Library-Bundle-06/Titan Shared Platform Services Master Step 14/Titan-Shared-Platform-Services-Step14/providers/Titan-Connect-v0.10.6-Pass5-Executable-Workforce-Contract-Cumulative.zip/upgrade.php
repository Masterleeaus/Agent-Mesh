<?php

declare(strict_types=1);

// Host installer remains authoritative. Legacy Chatbot Team Chat import is deliberately
// operator-invoked after canonical Titan Connect migrations are applied.
return [
    'extension' => 'titan-connect',
    'version' => '0.10.6',
    'strategy' => 'additive-migrations',
    'preserve_existing_data' => true,
    'legacy_import_command' => 'titan-connect:import-legacy-team-chat',
    'automatic_legacy_import' => false,
    'manual_host_sync_command' => 'titan-connect:host-sync',
    'clear_cache' => true,
];
