# Reconciliation

Reconciliation compares deterministic payroll outputs against approved source/provider evidence and records provenance (`tenant_company_id`, run, source revision). Outcomes classify missing, mismatched, duplicate and unresolved evidence.

A discrepancy never rewrites finalized money automatically. The reconciliation coordinator creates a governed resolution proposal or adjustment path; approved actions use the normal Command Bus/Risk/Assurance policy. Reconciliation lifecycle facts emitted to Signals/Rewind are privacy-minimized and contain identifiers/status/version/hash metadata rather than raw bank, tax or payslip data.
