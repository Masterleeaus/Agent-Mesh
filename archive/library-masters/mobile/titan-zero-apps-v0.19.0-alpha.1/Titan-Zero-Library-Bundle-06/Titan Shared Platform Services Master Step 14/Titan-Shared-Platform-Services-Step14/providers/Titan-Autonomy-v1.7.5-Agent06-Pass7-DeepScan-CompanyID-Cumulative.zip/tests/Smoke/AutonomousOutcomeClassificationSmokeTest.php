<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\Enums\LearningLabel;
use App\Extensions\TitanAutonomy\System\Enums\UserResponseClass;
use App\Extensions\TitanAutonomy\System\Services\SuccessStreakService;

$svc = new SuccessStreakService();
$r = $svc->apply(1, UserResponseClass::AutonomousVerified, true, true, false, false);
if ($r['streak'] !== 2 || $r['label'] !== LearningLabel::Correct || $r['qualifying'] !== true) {
    throw new RuntimeException('A deterministically verified autonomous outcome must count as a qualifying correct action.');
}
$r = $svc->apply(2, UserResponseClass::AutonomousIncorrect, false, true, false, false);
if ($r['streak'] !== 0 || $r['label'] !== LearningLabel::Incorrect || $r['qualifying'] !== false) {
    throw new RuntimeException('A verified incorrect autonomous outcome must reset the streak and remain negative evidence.');
}

echo "OK: AutonomousOutcomeClassificationSmokeTest\n";
