<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$check = static function (bool $ok, string $message) use (&$errors): void {
    if (! $ok) {
        $errors[] = $message;
    }
};

$raw = @file_get_contents($root . '/extension.json');
$check(is_string($raw) && $raw !== '', 'root extension.json missing');
$check(! str_starts_with((string) $raw, "\xEF\xBB\xBF"), 'extension.json contains UTF-8 BOM');
$manifest = json_decode((string) $raw, true);
$check(is_array($manifest), 'extension.json invalid JSON');

$expected = [
    'schema' => 'titan-extension-v1',
    'slug' => 'titan-rewind',
    'version' => '1.0.6',
    'folder' => 'TitanRewind',
    'provider' => 'App\\Extensions\\TitanRewind\\System\\TitanRewindServiceProvider',
    'migrations' => true,
];
foreach ($expected as $key => $value) {
    $check(($manifest[$key] ?? null) === $value, "manifest {$key} mismatch");
}

$check(($manifest['requires']['php'] ?? null) === '>=8.2', 'requires.php mismatch');
$check(is_string($manifest['requires']['magicai'] ?? null) && $manifest['requires']['magicai'] !== '', 'requires.magicai missing');
$check(is_string($manifest['requires']['laravel'] ?? null) && $manifest['requires']['laravel'] !== '', 'requires.laravel missing');
$check(is_bool($manifest['uninstall']['preserve_data'] ?? null), 'uninstall.preserve_data missing');
$check(! is_file($root . '/FILE-SHA256.json'), 'redundant FILE-SHA256.json must not be packaged');

$providerPath = $root . '/System/TitanRewindServiceProvider.php';
$provider = is_file($providerPath) ? (string) file_get_contents($providerPath) : '';
$check($provider !== '', 'provider file missing');
$check(str_contains($provider, 'namespace App\\Extensions\\TitanRewind\\System;'), 'provider namespace mismatch');
$check(str_contains($provider, 'class TitanRewindServiceProvider'), 'provider class mismatch');
$check(str_contains($provider, "'titan-rewind-config'"), 'provider publish tag mismatch');
$check(! str_contains($provider, "], 'extension');"), 'generic extension publish tag remains');

$integrity = $manifest['integrity']['files'] ?? null;
$check(is_array($integrity), 'integrity.files missing');
if (is_array($integrity)) {
    foreach ($integrity as $path => $hash) {
        $check(is_string($path) && $path !== '' && ! str_starts_with($path, '/'), "invalid integrity path {$path}");
        $check(is_string($hash) && preg_match('/^[a-f0-9]{64}$/', $hash) === 1, "invalid integrity hash {$path}");
        $file = $root . '/' . $path;
        $check(is_file($file), "integrity file missing {$path}");
        if (is_file($file) && is_string($hash)) {
            $check(hash_file('sha256', $file) === $hash, "integrity mismatch {$path}");
        }
    }

    $expectedFiles = [];
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
    foreach ($iterator as $file) {
        if (! $file->isFile() || $file->isLink()) {
            continue;
        }
        $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
        if ($relative === 'extension.json') {
            continue;
        }
        $expectedFiles[] = $relative;
    }
    sort($expectedFiles, SORT_STRING);
    $actualFiles = array_keys($integrity);
    sort($actualFiles, SORT_STRING);
    $check($actualFiles === $expectedFiles, 'integrity.files does not exactly match packaged file set');
}

if ($errors !== []) {
    fwrite(STDERR, implode(PHP_EOL, $errors) . PHP_EOL);
    exit(1);
}

echo 'Titan Installer 1.7.8 contract: PASS' . PHP_EOL;
