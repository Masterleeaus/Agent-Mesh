# Operations and diagnostics

## Disable

Set:

`TITAN_AI_ENABLED=false`

This blocks new runtime and governed execution while preserving code and company-scoped data.

`TITAN_AI_GOVERNANCE_ENABLED=false` independently blocks governed state-changing actions.

## Company-scoped memory maintenance

Run governed-memory decay for one company with:

`php artisan titan-ai:memory-decay --company=<company_id>`

Omitting `--company` is reserved for an intentional system-wide maintenance run.

## Diagnostics

Resolve `App\Extensions\TitanAI\System\Diagnostics\TitanAIDiagnosticsService` to inspect:

- runtime enabled state;
- worker registry health;
- configured provider and credential availability;
- WorkCore availability;
- mapped WorkCore operations;
- rollback mapping count;
- governance enabled state.

Diagnostics must not expose API keys or authorization headers.

## Failure behavior

Provider and integration errors surface as controlled runtime failures rather than silently falling through to unrelated providers. Governed WorkCore execution remains retryable where the approval/idempotency state machine permits it.

## Logging

Do not log full `TitanAIRequest` payloads, credentials, authorization headers, or sensitive WorkCore payloads. Use run UUID, company-safe identifiers, operation IDs and sanitized error categories for production telemetry.
