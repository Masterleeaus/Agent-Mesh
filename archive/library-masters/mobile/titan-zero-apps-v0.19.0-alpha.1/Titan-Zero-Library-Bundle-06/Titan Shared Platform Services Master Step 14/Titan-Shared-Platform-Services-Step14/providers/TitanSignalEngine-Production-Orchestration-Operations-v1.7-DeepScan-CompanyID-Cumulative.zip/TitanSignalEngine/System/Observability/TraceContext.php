<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Observability;

use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;

final readonly class TraceContext
{
    public function __construct(
        public ?int $tenantCompanyId,
        public string $traceId,
        public string $correlationId,
        public ?string $causationId,
        public ?string $rootCausationId,
        public ?string $emitterId,
        public string $extensionKey,
    ) {
    }

    public static function fromEnvelope(SignalEnvelope $envelope): self
    {
        return new self(
            $envelope->tenantCompanyId,
            $envelope->traceId,
            $envelope->correlationId,
            $envelope->causationId,
            $envelope->rootCausationId,
            $envelope->emitterId,
            $envelope->source,
        );
    }

    /** @return array<string, int|string|null> */
    public function toLogContext(): array
    {
        return [
            'extension_key' => $this->extensionKey,
            'tenant_company_id' => $this->tenantCompanyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
            'emitter_id' => $this->emitterId,
        ];
    }
}
