<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\Services;
use App\Extensions\TitanAICore\System\DTO\PlanEnvelope;
final class CanonicalPlanHasher {
    public function hash(PlanEnvelope $plan): string { return hash('sha256', json_encode($this->canonicalize($plan->toArray()), JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)); }
    private function canonicalize(mixed $v): mixed { if (!is_array($v)) return $v; if (array_is_list($v)) return array_map(fn($x)=>$this->canonicalize($x),$v); ksort($v,SORT_STRING); foreach($v as $k=>$x)$v[$k]=$this->canonicalize($x); return $v; }
}
