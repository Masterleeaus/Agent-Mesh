# Pass 15 — Route Optimisation Proposals + AI Workforce

Titan Field remains the authoritative writer for routes, dispatch, appointments and work orders.
Titan Maps Intelligence may calculate a route optimisation **proposal** only. A proposal is stored as decision evidence and has no authority to resequence Field route stops.

## Proposal lifecycle

1. `request_optimisation_proposal` loads the current tenant-scoped Field route, stops, geocoded service locations and appointment windows.
2. The optional Maps peer receives a bounded read-only payload and returns an explainable proposal with baseline/proposed order, distance/time deltas, algorithm, matrix provenance, warnings and window violations.
3. Field records the proposal in `titan_field_route_optimisation_proposals` with input/proposal hashes and an expiry.
4. `accept_optimisation_proposal` is a governance decision only; it does not change route order.
5. `reject_optimisation_proposal` records the decision and optional reason.
6. `apply_optimisation_proposal` requires an accepted, unexpired proposal and verifies that the route stop order still exactly matches the proposal baseline. If the route changed, the proposal becomes `stale` and cannot be applied.
7. Successful apply calls the existing `RouteService::resequence()` through the Field command gateway, so Field remains the single authoritative writer and emits normal Signals/receipts.

Maps absence is fail-closed for optimisation proposals. Field does not invent a second optimiser in the fallback gateway.

## AI Workforce Manifest 2.0

Titan Field publishes `resources/workforce/workforce-manifest.json` as extension-owned Workforce Manifest 2.0 data. It defines:

- Tier 1 `field-dispatch-manager`
- Tier 2 `field-operations-specialist`
- Tier 3 `field-operations-action-worker`

Activation is never automatic. AI Workforce must activate an exact `owner_extension=titan-field + role_definition_id` from the installed manifest. No role, title, maturity state or substitution can increase its earned autonomy.

Read/recommend tools may create Workforce tasks and recommendations. Mutating tools are declared `command_bus` only and require execution receipts; proposal acceptance/application remains human/policy governed through Titan Field capabilities. Titan Autonomy, Risk, Assurance, Signal and Rewind remain external authorities.
