<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers\TeamChat;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use App\Extensions\TitanConnect\System\Policies\TeamChat\TeamConversationPolicy;
use App\Extensions\TitanConnect\System\Security\ConversationAccess;
use App\Extensions\TitanConnect\System\Services\TeamChat\BusinessChannelService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class BusinessChannelController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly ConversationAccess $access,
    ) {
    }

    public function index(Request $request): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $channels = TeamConversation::query()
            ->where('company_id', $companyId)
            ->where('type', 'channel')
            ->where(function ($query) use ($companyId, $actorId): void {
                $query->whereIn('visibility', ['company', 'public'])
                    ->orWhereHas('participants', fn ($participants) => $participants
                        ->where('company_id', $companyId)->where('user_id', $actorId)->whereNull('left_at'));
            })
            ->with(['participants' => fn ($query) => $query->where('company_id', $companyId)->whereNull('left_at'), 'latestMessage'])
            ->latest('updated_at')
            ->paginate(min(max((int) $request->integer('per_page', 30), 1), 100));

        return response()->json($channels);
    }

    public function store(Request $request, BusinessChannelService $service): JsonResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'slug' => ['nullable', 'string', 'max:191'],
            'description' => ['nullable', 'string', 'max:2000'],
            'category' => ['nullable', 'string', 'max:120'],
            'visibility' => ['nullable', 'in:private,company,public'],
            'posting_policy' => ['nullable', 'in:members,moderators,owners'],
            'is_announcement' => ['nullable', 'boolean'],
            'linked_entity_type' => ['nullable', 'string', 'max:120', 'required_with:linked_entity_id'],
            'linked_entity_id' => ['nullable', 'string', 'max:191', 'required_with:linked_entity_type'],
            'user_ids' => ['nullable', 'array'],
            'user_ids.*' => ['integer', 'distinct'],
            'device_id' => ['nullable', 'string', 'max:191'],
        ]);

        return response()->json($service->create(
            $this->context->companyId($request),
            $this->context->actorId($request),
            $data,
            $data['device_id'] ?? null,
        ), 201);
    }

    public function update(Request $request, TeamConversation $conversation, TeamConversationPolicy $policy, BusinessChannelService $service): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->access->assertMember($conversation, $companyId, $actorId);
        abort_unless($conversation->isChannel() && $policy->canManage($conversation, $actorId), 403);
        $data = $request->validate([
            'name' => ['sometimes', 'required', 'string', 'max:255'],
            'slug' => ['sometimes', 'required', 'string', 'max:191'],
            'description' => ['sometimes', 'nullable', 'string', 'max:2000'],
            'category' => ['sometimes', 'nullable', 'string', 'max:120'],
            'visibility' => ['sometimes', 'in:private,company,public'],
            'posting_policy' => ['sometimes', 'in:members,moderators,owners'],
            'is_announcement' => ['sometimes', 'boolean'],
            'linked_entity_type' => ['sometimes', 'nullable', 'string', 'max:120'],
            'linked_entity_id' => ['sometimes', 'nullable', 'string', 'max:191'],
        ]);
        return response()->json($service->update($conversation, $actorId, $data));
    }

    public function join(Request $request, TeamConversation $conversation, BusinessChannelService $service): JsonResponse
    {
        $this->access->assertCompany($conversation, $this->context->companyId($request));
        abort_unless($conversation->isChannel(), 404);
        return response()->json($service->joinPublic($conversation, $this->context->actorId($request)), 201);
    }

    public function archive(Request $request, TeamConversation $conversation, TeamConversationPolicy $policy, BusinessChannelService $service): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->access->assertMember($conversation, $companyId, $actorId);
        abort_unless($conversation->isChannel() && $policy->canManage($conversation, $actorId), 403);
        $data = $request->validate(['archived' => ['required', 'boolean']]);
        return response()->json($service->archive($conversation, $actorId, (bool) $data['archived']));
    }
}
