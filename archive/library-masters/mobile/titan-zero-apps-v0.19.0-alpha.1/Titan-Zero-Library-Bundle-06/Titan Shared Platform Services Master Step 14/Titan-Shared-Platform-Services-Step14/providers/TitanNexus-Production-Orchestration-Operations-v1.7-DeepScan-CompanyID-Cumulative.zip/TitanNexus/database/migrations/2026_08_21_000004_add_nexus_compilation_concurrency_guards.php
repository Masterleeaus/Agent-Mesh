<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    private const TABLE = 'titan_nexus_compilations';
    private const UNIQUE = 'titan_nexus_tenant_compilation_unique';

    public function up(): void
    {
        if (!Schema::hasTable(self::TABLE)) {
            return;
        }

        if (!Schema::hasColumn(self::TABLE, 'entity_version')) {
            Schema::table(self::TABLE, static function (Blueprint $table): void {
                $table->unsignedBigInteger('entity_version')->default(1)->index();
            });
        }

        $duplicatesExist = Schema::getConnection()->table(self::TABLE)
            ->select(['tenant_company_id', 'compilation_uuid'])
            ->whereNotNull('tenant_company_id')
            ->whereNotNull('compilation_uuid')
            ->groupBy('tenant_company_id', 'compilation_uuid')
            ->havingRaw('COUNT(*) > 1')
            ->limit(1)
            ->exists();

        if ($duplicatesExist) {
            throw new \RuntimeException('Titan Nexus cannot add the tenant/compilation unique constraint while duplicate compilation identities exist. Repair duplicates before retrying the migration.');
        }

        Schema::table(self::TABLE, static function (Blueprint $table): void {
            $table->unique(['tenant_company_id', 'compilation_uuid'], self::UNIQUE);
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable(self::TABLE)) {
            return;
        }

        Schema::table(self::TABLE, static function (Blueprint $table): void {
            $table->dropUnique(self::UNIQUE);
        });

        if (Schema::hasColumn(self::TABLE, 'entity_version')) {
            Schema::table(self::TABLE, static function (Blueprint $table): void {
                $table->dropColumn('entity_version');
            });
        }
    }
};
