<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Contracts\{CustomFieldRepositoryContract, TagRepositoryContract};
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class MetadataController extends Controller
{
    public function __construct(private TagRepositoryContract $tags, private CustomFieldRepositoryContract $fields, private CrmHumanMutationGateway $mutations) {}
    public function index(Request $request) { return view('crm::metadata.index', ['tags'=>$this->tags->search((int)$request->user()->id), 'fields'=>$this->fields->definitions((int)$request->user()->id)]); }
    public function tagStore(Request $request) { $data=$request->validate(['name'=>'required|string|max:80','color'=>'nullable|string|max:30']); $this->mutations->execute($request,'crm.tag.create',$data); return back()->with('status','Tag saved.'); }
    public function fieldStore(Request $request) { $data=$request->validate(['subject_type'=>'required|string|in:company,contact,lead,deal,project,task','name'=>'required|string|max:120','key'=>'nullable|string|max:120','field_type'=>'required|string|in:text,textarea,number,date,boolean,select','is_required'=>'nullable|boolean','sort_order'=>'nullable|integer|min:0|max:1000']); $this->mutations->execute($request,'crm.custom_field.create',$data); return back()->with('status','Custom field saved.'); }
}
