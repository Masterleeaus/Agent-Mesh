<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Services;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Exceptions\SourceVersionConflictException;
use InvalidArgumentException;

final class SourceVersionTenantLineagePolicy
{
    public function assertConsistent(?int $sourceTenantCompanyId, ?int $versionTenantCompanyId): void
    {
        if ($sourceTenantCompanyId !== null && $sourceTenantCompanyId <= 0) {
            throw new InvalidArgumentException('source tenant_company_id must be positive when present.');
        }
        if ($versionTenantCompanyId !== null && $versionTenantCompanyId <= 0) {
            throw new InvalidArgumentException('version tenant_company_id must be positive when present.');
        }
        if ($sourceTenantCompanyId !== $versionTenantCompanyId) {
            throw new SourceVersionConflictException('Knowledge source/version tenant lineage is inconsistent.');
        }
    }
}
