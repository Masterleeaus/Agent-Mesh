<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Contracts;

use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;

interface RewindSourceWatermarkProviderContract
{
    /** @return array{state:string,observed_through:?string,source_lag_seconds:?int,metadata?:array<string,mixed>} */
    public function watermark(RewindTraceQuery $query): array;
}
