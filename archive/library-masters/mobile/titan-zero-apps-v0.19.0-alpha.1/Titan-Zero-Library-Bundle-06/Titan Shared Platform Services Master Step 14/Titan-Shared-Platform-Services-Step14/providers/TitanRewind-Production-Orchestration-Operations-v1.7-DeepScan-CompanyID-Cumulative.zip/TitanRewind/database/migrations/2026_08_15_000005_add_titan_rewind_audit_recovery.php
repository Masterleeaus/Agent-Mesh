<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_rewind_evidence_packages')) {
            Schema::create('titan_rewind_evidence_packages', function (Blueprint $table): void {
                $table->id();
                $table->uuid('package_uuid')->unique();
                $table->char('package_key',64)->unique();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->string('scope_type',30)->index();
                $table->string('scope_id',191)->index();
                $table->unsignedBigInteger('case_id')->nullable()->index();
                $table->uuid('trace_id')->nullable()->index();
                $table->string('package_type',40)->default('audit')->index();
                $table->string('status',40)->default('ready')->index();
                $table->char('content_hash',64)->index();
                $table->json('manifest');
                $table->longText('payload_json');
                $table->uuid('integrity_check_uuid')->nullable()->index();
                $table->dateTime('generated_at',6)->index();
                $table->unsignedBigInteger('generated_by_id')->nullable()->index();
                $table->uuid('supersedes_package_uuid')->nullable()->index();
                $table->timestamps();
                $table->index(['tenant_company_id','scope_type','scope_id','package_type'],'trw_evidence_scope_type');
                $table->index(['tenant_company_id','trace_id','package_type','created_at'],'trw_evidence_tenant_trace_type');
                $table->index(['tenant_company_id','case_id','package_type'],'trw_evidence_tenant_case_type');
            });
        }

        if (!Schema::hasTable('titan_rewind_recovery_plans')) {
            Schema::create('titan_rewind_recovery_plans', function (Blueprint $table): void {
                $table->id();
                $table->uuid('plan_uuid')->unique();
                $table->char('plan_key',64)->unique();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('case_id')->nullable()->index();
                $table->uuid('trace_id')->index();
                $table->uuid('root_cause_event_id')->nullable()->index();
                $table->string('status',40)->default('draft')->index();
                $table->string('risk_level',30)->default('medium')->index();
                $table->string('strategy',100);
                $table->string('proposed_capability',120)->nullable()->index();
                $table->json('command_input')->nullable();
                $table->json('plan');
                $table->char('plan_hash',64)->index();
                $table->json('blockers')->nullable();
                $table->unsignedBigInteger('requested_by_id')->nullable()->index();
                $table->string('governance_request_id',191)->nullable()->index();
                $table->string('governance_status',40)->nullable()->index();
                $table->dateTime('approved_at',6)->nullable();
                $table->timestamps();
                $table->index(['tenant_company_id','trace_id','status','created_at'],'trw_recovery_tenant_trace_status');
            });
        }

        if (!Schema::hasTable('titan_rewind_recovery_steps')) {
            Schema::create('titan_rewind_recovery_steps', function (Blueprint $table): void {
                $table->id();
                $table->uuid('step_uuid')->unique();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('recovery_plan_id')->index();
                $table->unsignedInteger('step_order');
                $table->string('step_type',100)->index();
                $table->string('status',40)->default('proposed')->index();
                $table->string('execution_owner',100);
                $table->boolean('requires_human')->default(false);
                $table->json('input')->nullable();
                $table->json('success_evidence')->nullable();
                $table->json('result')->nullable();
                $table->timestamps();
                $table->unique(['recovery_plan_id','step_order'],'trw_recovery_step_order');
                $table->index(['tenant_company_id','recovery_plan_id','status'],'trw_recovery_step_status');
            });
        }

        if (!Schema::hasTable('titan_rewind_governance_receipts')) {
            Schema::create('titan_rewind_governance_receipts', function (Blueprint $table): void {
                $table->id();
                $table->uuid('receipt_uuid')->unique();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->unsignedBigInteger('recovery_plan_id')->index();
                $table->string('external_request_id',191);
                $table->string('authority',100)->default('titan-governance')->index();
                $table->string('status',40)->index();
                $table->char('request_payload_hash',64)->index();
                $table->uuid('evidence_package_uuid')->nullable()->index();
                $table->json('decision')->nullable();
                $table->json('receipt')->nullable();
                $table->dateTime('requested_at',6)->nullable();
                $table->dateTime('decided_at',6)->nullable();
                $table->timestamps();
                $table->unique(['tenant_company_id','external_request_id'],'trw_governance_external_request');
                $table->index(['tenant_company_id','recovery_plan_id','status'],'trw_governance_plan_status');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_rewind_governance_receipts');
        Schema::dropIfExists('titan_rewind_recovery_steps');
        Schema::dropIfExists('titan_rewind_recovery_plans');
        Schema::dropIfExists('titan_rewind_evidence_packages');
    }
};
