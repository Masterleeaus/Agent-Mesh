<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Security;

final class TenantScopeKey
{
    public static function forTenant(string $tenantCompanyId): string
    {
        return hash('sha256', 'tenant:' . $tenantCompanyId);
    }

    public static function global(): string
    {
        return hash('sha256', 'global');
    }
}
