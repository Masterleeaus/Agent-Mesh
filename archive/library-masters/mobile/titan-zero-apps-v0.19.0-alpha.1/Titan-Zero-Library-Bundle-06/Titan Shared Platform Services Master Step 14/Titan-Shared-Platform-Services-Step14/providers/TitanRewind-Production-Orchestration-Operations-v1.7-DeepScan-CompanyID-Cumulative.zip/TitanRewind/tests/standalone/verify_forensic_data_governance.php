<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$checks=[];$fails=[];
function ok(bool $v,string $m):void{global $checks,$fails;$checks[]=$m;if(!$v)$fails[]=$m;}
function txt(string $p):string{return file_get_contents($p)?:'';}

$required=[
'System/Sources/RewindHostSourceAdapter.php','System/Sources/RewindHostSourceDiscovery.php','System/Artifacts/RewindHistoricalArtifactArchive.php',
'System/Evidence/RotatingOpenSslRewindEvidenceSigner.php','System/Services/RewindSigningKeyService.php','System/Retention/RewindRetentionPolicy.php',
'System/Services/RewindRetentionService.php','System/Models/RewindHistoricalArtifact.php','System/Models/RewindSigningKey.php','System/Models/RewindPurgeRun.php','System/Models/RewindPurgeReceipt.php',
'database/migrations/2026_08_16_000009_add_forensic_data_governance.php'
];
foreach($required as $f) ok(is_file($root.'/'.$f),'required file '.$f);

require_once $root.'/System/Reconstruction/RewindTraceQuery.php';
require_once $root.'/System/Support/CanonicalJson.php';
require_once $root.'/System/Support/RewindPayloadSanitizer.php';
require_once $root.'/System/Reconstruction/RewindEventRecord.php';
require_once $root.'/System/Contracts/RewindSourceAdapterContract.php';
require_once $root.'/System/Contracts/RewindSourceWatermarkProviderContract.php';
require_once $root.'/System/Sources/RewindHostSourceAdapter.php';
require_once $root.'/System/Contracts/RewindEvidenceSignerContract.php';
require_once $root.'/System/Contracts/RewindEvidenceKeyringContract.php';
require_once $root.'/System/Evidence/RotatingOpenSslRewindEvidenceSigner.php';
require_once $root.'/System/Retention/RewindRetentionPolicy.php';
require_once $root.'/System/Sources/RewindSourceCompleteness.php';
require_once $root.'/System/Contracts/RewindHistoricalArtifactResolverContract.php';
require_once $root.'/System/Artifacts/RewindHostArtifactResolver.php';

use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Sources\RewindHostSourceAdapter;
use App\Extensions\TitanRewind\System\Evidence\RotatingOpenSslRewindEvidenceSigner;
use App\Extensions\TitanRewind\System\Retention\RewindRetentionPolicy;
use App\Extensions\TitanRewind\System\Sources\RewindSourceCompleteness;
use App\Extensions\TitanRewind\System\Artifacts\RewindHostArtifactResolver;

$q=RewindTraceQuery::fromArray(['tenant_company_id'=>7,'trace_id'=>'11111111-1111-4111-8111-111111111111']);
$host=new class {
 public function sourceKey():string{return 'titan-signal';}
 public function watermark(int $tenant,string $trace):array{return ['state'=>'COMPLETE','observed_through'=>'2026-08-16T12:00:00+00:00','cursor'=>'abc','source_lag_ms'=>1500,'authenticity_state'=>'VERIFIED'];}
 public function records(int $tenant,string $trace,?string $asOf=null):iterable{yield ['tenant_company_id'=>$tenant,'event_id'=>'22222222-2222-4222-8222-222222222222','trace_id'=>$trace,'correlation_id'=>null,'causation_id'=>null,'source_engine'=>'titan-signal','source_record_id'=>'sig-1','event_type'=>'signal.test.v1','sequence'=>1,'occurred_at'=>'2026-08-16T12:00:00+00:00','recorded_at'=>'2026-08-16T12:00:01+00:00','payload'=>['ok'=>true]];}
};
$a=new RewindHostSourceAdapter($host);
ok($a->key()==='titan-signal','host adapter key');
$wm=$a->watermark($q); ok($wm['state']==='COMPLETE','watermark state'); ok($wm['source_lag_seconds']===2,'watermark lag rounds up'); ok(($wm['metadata']['authenticity_state']??null)==='VERIFIED','watermark authenticity');
$records=iterator_to_array($a->records($q)); ok(count($records)===1,'host records normalized'); ok($records[0]->tenantCompanyId()===7,'host tenant enforced');
$badHost=new class {public function sourceKey():string{return 'bad';} public function watermark(int $t,string $x):array{return ['state'=>'COMPLETE'];} public function records(int $t,string $x,?string $a=null):iterable{yield ['tenant_company_id'=>999,'event_id'=>'33333333-3333-4333-8333-333333333333','trace_id'=>$x,'source_engine'=>'bad','event_type'=>'bad','sequence'=>1,'occurred_at'=>'2026-08-16T12:00:00+00:00'];}};
try{iterator_to_array((new RewindHostSourceAdapter($badHost))->records($q));ok(false,'cross tenant rejected');}catch(Throwable){ok(true,'cross tenant rejected');}

if(extension_loaded('openssl')){
 function kp(string $id):array{$r=openssl_pkey_new(['private_key_bits'=>2048,'private_key_type'=>OPENSSL_KEYTYPE_RSA]);openssl_pkey_export($r,$priv);$d=openssl_pkey_get_details($r);$base=sys_get_temp_dir().'/trw-'.$id.'-'.bin2hex(random_bytes(3));file_put_contents($base.'.priv',$priv);file_put_contents($base.'.pub',$d['key']);return ['key_id'=>$id,'private_key_path'=>$base.'.priv','public_key_path'=>$base.'.pub','status'=>'active'];}
 $k1=kp('k1');$k2=kp('k2');
 $s1=new RotatingOpenSslRewindEvidenceSigner([$k1,$k2],'k1');$hash=str_repeat('a',64);$sig1=$s1->sign($hash);ok($sig1['key_id']==='k1','active key signs');ok($s1->verify($hash,$sig1['signature'],'k1'),'active signature verifies');
 $s2=new RotatingOpenSslRewindEvidenceSigner([$k1,$k2],'k2');$sig2=$s2->sign($hash);ok($sig2['key_id']==='k2','rotated key signs');ok($s2->verify($hash,$sig1['signature'],'k1'),'retired public key verifies old signature');ok($s2->verify($hash,$sig2['signature'],'k2'),'new signature verifies');
 $meta=$s2->keyMetadata();ok(count($meta)===2,'keyring metadata count');ok(($meta['k2']['active']??false)===true,'keyring active metadata');
}

$complete=new RewindSourceCompleteness(60);
$now=(new DateTimeImmutable('now',new DateTimeZone('UTC')))->format(DATE_ATOM);
$cs=$complete->evaluate([['source'=>'titan-signal','state'=>'COMPLETE','observed_through'=>$now,'metadata'=>['authenticity_state'=>'VERIFIED']]]);
ok(($cs['complete_for_audit']??false)===true,'fresh verified source qualifies for audit');
$old=(new DateTimeImmutable('now',new DateTimeZone('UTC')))->sub(new DateInterval('PT120S'))->format(DATE_ATOM);
$stale=$complete->evaluate([['source'=>'titan-signal','state'=>'COMPLETE','observed_through'=>$old,'metadata'=>['authenticity_state'=>'VERIFIED']]]);
ok(($stale['state']??'')==='STALE','stale source is downgraded');ok(($stale['complete_for_audit']??true)===false,'stale source blocks audit completeness');
$unknown=$complete->evaluate([['source'=>'titan-signal','state'=>'COMPLETE','observed_through'=>$now,'metadata'=>['authenticity_state'=>'UNKNOWN']]]);
ok(($unknown['complete_for_audit']??true)===false,'unverified source authenticity blocks audit completeness');
$har=new RewindHostArtifactResolver(new class {public function artifactKind():string{return 'policy';} public function resolve(string $v,array $c=[]):?array{return ['artifact_id'=>'policy.main','version'=>$v,'content'=>['rule'=>'x']];}});
ok($har->kind()==='policy','host artifact resolver kind');ok(($har->resolve('v1')['version']??null)==='v1','host artifact resolver delegates immutable version');

$p=new RewindRetentionPolicy(['ephemeral'=>30,'operational'=>90,'forensic'=>365,'evidence'=>2555]);
ok($p->days('ephemeral')===30,'ephemeral retention');ok($p->days('evidence')===2555,'evidence retention');ok($p->classFor('titan_rewind_replay_runs')==='ephemeral','replay retention class');ok($p->classFor('titan_rewind_integrity_checks')==='operational','integrity retention class');ok($p->classFor('titan_rewind_snapshots')==='forensic','snapshot retention class');ok($p->classFor('titan_rewind_evidence_packages')==='evidence','evidence retention class');ok($p->classFor('titan_rewind_custody_events')==='preserve','custody preserved');ok($p->classFor('titan_rewind_legal_holds')==='preserve','holds preserved');

$m=txt($root.'/database/migrations/2026_08_16_000009_add_forensic_data_governance.php');
foreach(['titan_rewind_historical_artifacts','titan_rewind_signing_keys','titan_rewind_purge_runs','titan_rewind_purge_receipts'] as $t)ok(str_contains($m,$t),'migration '.$t);
ok(str_contains($m,'artifact_payload'),'encrypted artifact payload column');ok(str_contains($m,'content_hash'),'artifact content hash');ok(str_contains($m,'cursor_id'),'resumable purge cursor');

$provider=txt($root.'/System/TitanRewindServiceProvider.php');
foreach(['RewindHostSourceDiscovery','RewindHistoricalArtifactArchive','RewindRetentionService','RewindSigningKeyService','RotatingOpenSslRewindEvidenceSigner'] as $x)ok(str_contains($provider,$x),'provider '.$x);
ok(!str_contains($provider,'new OpenSslRewindEvidenceSigner('),'legacy single-key signer not instantiated');
$manager=txt($root.'/System/Services/RewindManager.php');
foreach(['retentionPreview','runRetention','historicalArtifact','discoverHostSources'] as $x)ok(str_contains($manager,$x),'manager '.$x);
$manifest=json_decode(txt($root.'/extension.manifest.json'),true);ok(($manifest['version']??'')==='1.0.6','manifest v1.0.6');
foreach(['rewind.source-discovery','rewind.artifact.archive','rewind.retention','rewind.purge.receipts','rewind.evidence.key-rotation'] as $cap)ok(in_array($cap,$manifest['capabilities']??[],true),'capability '.$cap);
foreach(['titan_rewind_historical_artifacts','titan_rewind_signing_keys','titan_rewind_purge_runs','titan_rewind_purge_receipts'] as $t)ok(in_array($t,$manifest['database']['owned_tables']??[],true),'owned table '.$t);
$config=txt($root.'/config/titan-rewind.php');ok(str_contains($config,"'classes'"),'retention classes config');ok(str_contains($config,'TITAN_REWIND_EVIDENCE_KEYS_JSON'),'keyring env config');
$archive=txt($root.'/System/Artifacts/RewindHistoricalArtifactArchive.php');ok(str_contains($archive,'RewindPayloadSanitizer'),'artifact sanitization');ok(str_contains($archive,"'encrypted:array'" ) || str_contains(txt($root.'/System/Models/RewindHistoricalArtifact.php'),"'encrypted:array'"),'artifact encrypted cast');
$ret=txt($root.'/System/Services/RewindRetentionService.php');ok(str_contains($ret,'RewindLegalHoldGuard'),'retention hold guard');ok(str_contains($ret,'cursor_id'),'resumable retention');ok(str_contains($ret,'RewindPurgeReceipt'),'purge receipts');ok(!str_contains($ret,'truncate('),'no bulk truncate');
$cust=txt($root.'/System/Services/RewindCustodyService.php');ok(str_contains($cust,"'signature_verified'"),'signature verification custody');ok(str_contains($cust,"'purge_blocked'"),'purge blocked custody action');

printf("Forensic data governance checks: %d/%d PASS\n",count($checks)-count($fails),count($checks));
if($fails){foreach($fails as $f)fwrite(STDERR,"FAIL: $f\n");exit(1);} 
