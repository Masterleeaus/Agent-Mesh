# Governance Contract

1. Governance policy definitions and human decisions are immutable/versioned; runtime projections are mutable and quarantine is separate.
2. Every policy decision records structured reason codes, evidence references, policy version, actor and causal context. Hidden chain-of-thought is not stored.
3. Governance authority constraints are upper bounds only.
4. `HOLD` and `DENY` can force execution authority downward; `REQUIRE_APPROVAL` is never equivalent to `ALLOW`.
5. Governance never mints earned/effective authority. Titan Autonomy remains the effective-authority source.
6. Risk, Assurance, Autonomy, Signal, Rewind, Knowledge, Workforce and business truth remain separate sources; Governance may cache/project observations without becoming their source of truth.
7. `APPROVE`, `REJECT`, `HOLD`, `EXCEPTION`, and `ESCALATE` create a Governance decision first and then leave Governance through Titan Command Bus only.
8. Governance never reports an action `APPLIED` without a valid Command Bus receipt plus authoritative domain receipt and independent write verification.
9. Governance-owned escalation transitions use optimistic version checks. Stale versions fail closed.
10. Operation IDs are tenant-scoped idempotency identities. Same semantic action may retry; conflicting reuse is rejected.
11. A missing/unhealthy Command Bus bridge blocks execution and leaves escalation state unchanged.
12. The local `GovernanceEscalationTarget` is a Command Bus target, not a controller/service bypass.
