# Observation → Knowledge → Outcome Loop Integration

This extension participates as **observation-source** under `titan.observation-knowledge-outcome-loop.v1`.

## Invariants

- `company_id` is the canonical company boundary for all new integration metadata. Existing `tenant_company_id` persistence/runtime fields are legacy compatibility only and must not become a new authority source.
- Titan AI Workforce owns employee identity, organisational role identity, work items and orchestration.
- Signals/observations are authority-neutral. They may trigger Workforce work but never grant permission or become business truth by themselves.
- Executable work pins provider identity/version. Missing provider, missing causal context or disabled policy fails closed.
- Reads are non-mutating. Side effects require the governed execution boundary, idempotency and an execution receipt.
- Every loop handoff carries `trace_id`, `correlation_id`, `causation_id`, and `root_causation_id`.
- Provider disable/upgrade/removal cannot silently mutate Workforce role identity or raise fallback authority.

## Loop role

Produces: authority-neutral observations, anomaly triggers, causal trace context.

Consumes: governed emission requests.

Expected downstream: titan-ai-workforce, titan-knowledge-authority, titan-rewind.
