# Titan Forge Operations

## Queue

Deterministic skeleton builds use the `titan-forge` queue. `GenerateSkeletonTeam` is unique per tenant/idempotency key, allows three attempts, has a 120-second timeout and a one-hour uniqueness window. Host queue reservation semantics provide the worker claim boundary; Forge additionally protects business idempotency in durable storage.

## Workspace

Generation is confined to `storage/app/titan-forge/workspaces/<tenant_company_id>/<operation_id>/`. Safe relative paths, atomic writes, traversal rejection, symlink rejection, case-collision rejection and file/size ceilings apply.

## Health

The health endpoint reports liveness, readiness, operational health, queue state, local validation capability and peer-gateway availability. Missing release authorities degrade/hold release progression; they are never interpreted as approval.


## Governed Council role-model policy

Pass 18 requires host-controlled assignments for `proposer`, `critic`, `verifier` and `arbiter`. Configure all four `TITAN_FORGE_COUNCIL_*_MODEL` values or configure none; partial configuration is invalid and at least three distinct models are required. These settings are policy, not per-request routing. Dynamic routing authority remains outside Forge.


## Rewind source operations

`titan-forge.rewind-source` reads Forge-owned history by `tenant_company_id + trace_id` using cursor-backed queries. Projection and watermark aggregation stream records and reject non-monotonic source ordering. The watermark distinguishes current source completeness from historical reproducibility. `as_of` requests fail closed until Forge has an immutable lifecycle-history source capable of truthful point-in-time reads.

## Rollout

Use the extension enable flag/kill switch and staged rollout states `DISABLED -> INTERNAL -> CANARY -> TENANT_COHORT -> GENERAL`. This development release is not a signed production release.

## Verification

Before distribution: lint PHP, parse JSON, run Forge standalone suites, validate both manifests against Blueprint v4.2.1, verify event-schema references, scan archive paths/secrets, verify checksums and clean-extract the final ZIP before re-running the same gates.
