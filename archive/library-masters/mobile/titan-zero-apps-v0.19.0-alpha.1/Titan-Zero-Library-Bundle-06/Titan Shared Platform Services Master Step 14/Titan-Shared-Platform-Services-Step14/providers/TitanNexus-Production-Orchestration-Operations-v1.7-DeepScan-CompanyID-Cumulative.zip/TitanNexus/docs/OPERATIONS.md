# Operations

Keep required public governance contracts bound before enabling provisioning. Treat DEGRADED health as non-authoritative for new mutations. Monitor blocked/failed operations, idempotency duplicates, lineage integrity, and incomplete post-write observability evidence.


## Runtime readiness interpretation

- `UNAVAILABLE`: database or Vertical Engine core is unavailable; do not start new compile lifecycle work.
- `DEGRADED`: compile/history remain usable but governed provisioning execution is unavailable because one or more required execution dependencies are missing.
- `HEALTHY`: core plus required human-execution stack is available. Conditional Autonomy/Knowledge Authority and optional Interface Runtime are evaluated separately in `execution_modes`.
- `DISABLED`: Nexus is administratively disabled and advertises no runtime-available capabilities.

Use `capability_readiness` rather than inferring usability from the package manifest alone.
