# Titan Governance v1.0.0-rc.1 — Exact Host Certification Checklist

Target observed host: MagicAI/Titan Extension Manager **1.7.6**, PHP **8.3.33**, Laravel **10.50.2**, MySQL.

Package/static certification never substitutes for these live stages:

1. **INSTALLER_CERTIFIED** — upload the exact RC ZIP and confirm validation/extraction succeeds, including legacy root name/type/description/support_telegram and integrity verification.
2. **MIGRATION_CERTIFIED** — verify all four historical Governance migrations are either already recorded or execute restartably without duplicate/destructive data effects.
3. **BOOT_CERTIFIED** — provider registers/boots with required dependencies installed; optional observers may degrade but not crash boot.
4. **NAVIGATION_CERTIFIED** — user/admin Governance links render with Tabler icons and valid named routes; legacy menu repair does not create duplicates.
5. **AUTHORIZATION_CERTIFIED** — ordinary user, tenant admin, platform admin and super-admin behavior matches host permissions; cross-company access is denied.
6. **RUNTIME_CERTIFIED** — Trust Map, Signal, Control Centre, Workforce Oversight, Decision Intelligence and Rewind views use real adapters with tenant isolation.
7. **UPGRADE_CERTIFIED** — upgrade from the installed prior Governance version preserves Governance-owned rows and historical decision/evidence references.
8. **UNINSTALL_CERTIFIED** — uninstall removes published config only and preserves Governance data as declared by `uninstall.preserve_data=true`.

Do not mark a stage PASS without exact-host evidence. `tools/exact_host_certification.php` defaults every live stage to `NOT_RUN`.
## H2 live retry note
Confirm migration 000004 completes with short explicit indexes (including `tgov_policy_auth_receipt_idx`) and that retry does not fail if prior partial columns remain.

