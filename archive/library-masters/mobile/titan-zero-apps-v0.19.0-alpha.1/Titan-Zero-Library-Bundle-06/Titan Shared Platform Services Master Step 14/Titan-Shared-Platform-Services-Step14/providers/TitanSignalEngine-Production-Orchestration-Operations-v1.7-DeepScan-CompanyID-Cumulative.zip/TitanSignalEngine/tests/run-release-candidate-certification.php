<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$require = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$rootManifest = json_decode((string) file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);

$require(($rootManifest['schema'] ?? null) === 'titan-extension-v1', 'Installer 1.7.8 root manifest schema missing.');
$require(($rootManifest['slug'] ?? null) === 'titan-signal-engine', 'Installer root manifest slug missing.');
$require(($rootManifest['folder'] ?? null) === 'TitanSignalEngine', 'Installer root manifest folder missing.');
$require(($rootManifest['provider'] ?? null) === 'App\\Extensions\\TitanSignalEngine\\System\\TitanSignalEngineServiceProvider', 'Installer root provider missing.');
$require(($rootManifest['migrations'] ?? null) === true, 'Installer root migrations flag missing.');
$require(($rootManifest['uninstall']['preserve_data'] ?? null) === true, 'Installer root preserve-data policy missing.');

$require(is_file($root . '/System/Services/SignalHostCertificationService.php'), 'Host certification service missing.');
$require(is_file($root . '/System/Console/Commands/CertifySignalHost.php'), 'Host certification command missing.');
$require(is_file($root . '/System/Data/SignalCertificationReport.php'), 'Certification report model missing.');
$require(is_file($root . '/docs/PRODUCTION-HOST-CERTIFICATION.md'), 'Host certification runbook missing.');
$require(is_file($root . '/RELEASE-CANDIDATE-CERTIFICATION.json'), 'Release candidate certification status missing.');

$provider = (string) file_get_contents($root . '/System/TitanSignalEngineServiceProvider.php');
$require(str_contains($provider, 'CertifySignalHost::class'), 'Certification command is not registered.');

$rc = is_file($root . '/RELEASE-CANDIDATE-CERTIFICATION.json')
    ? json_decode((string) file_get_contents($root . '/RELEASE-CANDIDATE-CERTIFICATION.json'), true, 512, JSON_THROW_ON_ERROR)
    : [];
$hostStatus = (string) ($rc['host_runtime']['status'] ?? '');
$require(in_array($hostStatus, ['PENDING_HOST_EXECUTION', 'PARTIAL_HOST_EVIDENCE_PENDING_RETRY', 'PENDING_HOST_NAVIGATION_RETRY', 'PENDING_HOST_SUPER_ADMIN_BLADE_RETRY', 'PENDING_HOST_RC7_BLADE_RENDER_RETRY', 'PENDING_HOST_RC8_INSTALL_AND_CERTIFICATION', 'PENDING_HOST_RC8_1_INSTALL_AND_CERTIFICATION'], true), 'RC status must remain pending until full host certification passes.');
$require(($rc['production_certified'] ?? null) === false, 'RC must not falsely claim production certification.');
$require(($rc['local_certification']['status'] ?? null) === 'PASS', 'Local RC certification should be recorded as PASS after local gates.');

if ($failures !== []) {
    fwrite(STDERR, "release-candidate-certification: FAIL\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "release-candidate-certification: PASS\n";
