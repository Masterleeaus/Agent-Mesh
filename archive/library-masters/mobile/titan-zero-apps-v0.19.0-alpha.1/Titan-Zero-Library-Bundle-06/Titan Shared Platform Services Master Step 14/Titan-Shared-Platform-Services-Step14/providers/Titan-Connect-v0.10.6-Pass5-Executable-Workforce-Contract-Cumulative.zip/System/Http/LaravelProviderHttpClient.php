<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http;

use App\Extensions\TitanConnect\System\Contracts\ProviderHttpClient;
use App\Extensions\TitanConnect\System\DTO\ProviderHttpResponse;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Http;
use RuntimeException;

final class LaravelProviderHttpClient implements ProviderHttpClient
{
    public function request(string $method, string $url, array $options = []): ProviderHttpResponse
    {
        $method = strtoupper(trim($method));
        $url = trim($url);
        if ($url === '' || ! str_starts_with(strtolower($url), 'https://')) {
            throw new RuntimeException('Provider HTTP requests require an HTTPS URL.');
        }

        $timeout = max(1, (int) ($options['timeout'] ?? config('titan-connect.http.timeout_seconds', 15)));
        $connectTimeout = max(1, (int) ($options['connect_timeout'] ?? config('titan-connect.http.connect_timeout_seconds', 5)));
        $headers = (array) ($options['headers'] ?? []);
        $headers['User-Agent'] = $headers['User-Agent'] ?? (string) config('titan-connect.http.user_agent', 'TitanConnect/0.3');

        $pending = Http::acceptJson()
            ->withHeaders($headers)
            ->timeout($timeout)
            ->connectTimeout($connectTimeout)
            ->withoutRedirecting();

        $bearer = trim((string) ($options['bearer'] ?? ''));
        if ($bearer !== '') {
            $pending = $pending->withToken($bearer);
        }

        $basic = $options['basic_auth'] ?? null;
        if (is_array($basic) && isset($basic[0], $basic[1])) {
            $pending = $pending->withBasicAuth((string) $basic[0], (string) $basic[1]);
        }

        $query = is_array($options['query'] ?? null) ? $options['query'] : [];
        if ($query !== []) {
            $pending = $pending->withOptions(['query' => $query]);
        }

        $requestOptions = [];
        if (array_key_exists('json', $options)) {
            $requestOptions['json'] = is_array($options['json']) ? $options['json'] : [];
        } elseif (array_key_exists('form', $options)) {
            $pending = $pending->asForm();
            $requestOptions['form_params'] = is_array($options['form']) ? $options['form'] : [];
        }

        try {
            $response = $pending->send($method, $url, $requestOptions);
        } catch (ConnectionException) {
            // Provider URLs can contain transport secrets (for example Telegram bot tokens).
            // Do not persist the underlying exception message/URL into delivery errors or logs.
            throw new RuntimeException('Provider HTTP connection failed.');
        }

        $json = $response->json();
        return new ProviderHttpResponse(
            $response->status(),
            (string) $response->body(),
            is_array($json) ? $json : [],
            $response->headers(),
        );
    }
}
