# Authorization Matrix

Runtime authorization is capability- and company-scoped. Installation or capability discovery never implies permission or authority.
