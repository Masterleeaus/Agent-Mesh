# Titan Rewind v1.0.5 — MagicAI/Titan Host Authorization Bridge

## Live failure

After v1.0.4 installed and the menu self-healed, the host returned HTTP 403 with `Titan Rewind permission denied: rewind.trace.view`.

## Cause

The original Rewind middleware delegated only to Laravel/Spatie `$user->can()`. The target MagicAI host represents platform authority through `users.type` and host methods such as `isSuperAdmin()`, `isAdmin()` and `checkPermission()`. Super Admin is a direct bypass in the host.

## Compatibility policy

- Super Admin: full Rewind permission bypass.
- Explicit custom permission: accepted from `can()`, `checkPermission()` or `hasPermissionTo()`.
- Delegated Admin: read/diagnostic fallback only (`trace.view`, `forensics.view`, `integrity.verify`).
- Ordinary user: explicit Rewind grant required.

This bridge does not bypass `tenant_company_id` object scoping and does not grant delegated admins sensitive evidence, recovery, legal-hold or Rewind administration actions.
