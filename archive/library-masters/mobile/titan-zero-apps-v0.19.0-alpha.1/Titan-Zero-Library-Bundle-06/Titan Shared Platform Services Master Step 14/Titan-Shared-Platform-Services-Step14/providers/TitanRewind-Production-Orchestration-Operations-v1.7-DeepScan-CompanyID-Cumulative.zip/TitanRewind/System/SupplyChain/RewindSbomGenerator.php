<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\SupplyChain;
final class RewindSbomGenerator
{
    public function generate(string $version,array $files,array $packages=[]): array
    {
        sort($files,SORT_STRING);usort($packages,static fn(array $a,array $b):int=>strcmp((string)($a['name']??''),(string)($b['name']??'')));
        return [
            'spdxVersion'=>'SPDX-2.3','dataLicense'=>'CC0-1.0','SPDXID'=>'SPDXRef-DOCUMENT',
            'name'=>'Titan Rewind '.$version,'documentNamespace'=>'urn:titan:rewind:sbom:'.hash('sha256',$version.'|'.implode('|',$files)),
            'creationInfo'=>['created'=>(new \DateTimeImmutable('now',new \DateTimeZone('UTC')))->format(DATE_ATOM),'creators'=>['Tool: TitanRewind/RewindSbomGenerator']],
            'packages'=>array_merge([['name'=>'titan-rewind','SPDXID'=>'SPDXRef-Package-TitanRewind','versionInfo'=>$version,'downloadLocation'=>'NOASSERTION','filesAnalyzed'=>true]],$packages),
            'files'=>array_map(static fn(string $f):array=>['fileName'=>$f,'SPDXID'=>'SPDXRef-File-'.substr(hash('sha256',$f),0,24)],$files),
        ];
    }
}
