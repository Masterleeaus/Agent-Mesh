<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$migrations = glob($root.'/database/migrations/*.php') ?: [];
sort($migrations);

$definitions = [];
$duplicates = [];
$redundantPrefixes = [];

foreach ($migrations as $migration) {
    $source = file_get_contents($migration);
    if ($source === false) {
        fwrite(STDERR, "FAIL migration-index chain compatibility\nCannot read {$migration}\n");
        exit(1);
    }

    if (! preg_match_all('/\\$table->(index|unique)\\(\\s*(\\[[^\\)]*?\\]|[\'\"][^\'\"]+[\'\"])\\s*,\\s*[\'\"]([^\'\"]+)[\'\"]\\s*\\)/s', $source, $matches, PREG_OFFSET_CAPTURE)) {
        continue;
    }

    foreach ($matches[0] as $i => $fullMatch) {
        $offset = $fullMatch[1];
        $prefix = substr($source, 0, $offset);
        preg_match_all('/Schema::(?:create|table)\\(\\s*[\'\"]([^\'\"]+)[\'\"]/', $prefix, $tableMatches);
        $table = $tableMatches[1] === [] ? null : end($tableMatches[1]);
        if (! is_string($table) || $table === '') {
            continue;
        }

        $kind = $matches[1][$i][0];
        $columnExpression = $matches[2][$i][0];
        $name = $matches[3][$i][0];
        preg_match_all('/[\'\"]([^\'\"]+)[\'\"]/', $columnExpression, $columnMatches);
        $columns = $columnMatches[1];

        $entry = [
            'table' => $table,
            'name' => $name,
            'kind' => $kind,
            'columns' => $columns,
            'migration' => basename($migration),
            'line' => substr_count(substr($source, 0, $offset), "\n") + 1,
        ];

        $key = $table.'|'.$name;
        if (isset($definitions[$key])) {
            $first = $definitions[$key];
            $duplicates[] = sprintf(
                '%s.%s first=%s:%d (%s) repeated=%s:%d (%s)',
                $table,
                $name,
                $first['migration'],
                $first['line'],
                implode(',', $first['columns']),
                $entry['migration'],
                $entry['line'],
                implode(',', $entry['columns'])
            );
        } else {
            $definitions[$key] = $entry;
        }
    }
}

$indexesByTable = [];
foreach ($definitions as $entry) {
    if ($entry['kind'] === 'index') {
        $indexesByTable[$entry['table']][] = $entry;
    }
}

foreach ($indexesByTable as $table => $indexes) {
    foreach ($indexes as $a) {
        foreach ($indexes as $b) {
            if ($a['name'] === $b['name'] || count($a['columns']) >= count($b['columns'])) {
                continue;
            }
            if ($a['columns'] !== array_slice($b['columns'], 0, count($a['columns']))) {
                continue;
            }
            $redundantPrefixes[] = sprintf(
                '%s.%s (%s) is a left-prefix of %s (%s)',
                $table,
                $a['name'],
                implode(',', $a['columns']),
                $b['name'],
                implode(',', $b['columns'])
            );
        }
    }
}

if ($duplicates !== [] || $redundantPrefixes !== []) {
    fwrite(STDERR, "FAIL migration-index chain compatibility\n");
    if ($duplicates !== []) {
        fwrite(STDERR, "Duplicate key names:\n - ".implode("\n - ", $duplicates)."\n");
    }
    if ($redundantPrefixes !== []) {
        fwrite(STDERR, "Redundant left-prefix indexes:\n - ".implode("\n - ", array_unique($redundantPrefixes))."\n");
    }
    exit(1);
}

fwrite(STDOUT, "PASS migration-index chain compatibility\n");
