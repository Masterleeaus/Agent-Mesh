# Titan Rewind Resilience

## Retry classification

`RewindFailureClassifier` separates permanent failures from retryable failures. Invalid input, authorization/integrity violations and `REPLAY_BOUNDARY_VIOLATION` are permanent. Transient runtime/provider failures are retryable. Cancellation is tracked separately.

Replay and Signal delivery jobs use bounded retries with exponential-style backoff (`5s`, `30s`, `120s`). They never recursively dispatch unbounded retry chains.

## Attention Required / dead letter

Exhausted jobs are persisted to `titan_rewind_dead_letters` with tenant, queue, job type, operation identifier, sanitized recovery payload, classification, attempts, exception class/message and failure time. Supported replay and Signal dead letters can be explicitly requeued by a Rewind administrator. Retried/resolved state is preserved rather than deleting the failure evidence.

## Backpressure

`RewindQueueAdmissionService` enforces soft and hard backlog thresholds before accepting new replay work. Soft pressure allows work but reports degraded state. Hard pressure rejects new work with an explicit `hard_backpressure` reason. Draining, maintenance and disabled states also reject new work.

Signal production is observational and therefore never blocks the underlying forensic operation: if Signal delivery cannot be admitted, the outbox row is retained in Attention Required for operator recovery.

## Circuit breakers

External Titan Signal and Titan Governance calls are guarded by persisted circuit breaker state in `titan_rewind_circuit_breakers`. States are `CLOSED`, `OPEN`, and `HALF_OPEN`. Repeated failures open the circuit; after the configured reset interval exactly one recovery path may probe in `HALF_OPEN`. Success resets the breaker; a failed probe reopens it.

## Failure containment

Rewind remains read-only toward authoritative business state. Runtime resilience cannot expand Rewind authority: replay mutation remains denied, recovery remains a proposal until Governance authorizes it, and domain execution remains owned by Titan Command Bus/domain capability owners.
