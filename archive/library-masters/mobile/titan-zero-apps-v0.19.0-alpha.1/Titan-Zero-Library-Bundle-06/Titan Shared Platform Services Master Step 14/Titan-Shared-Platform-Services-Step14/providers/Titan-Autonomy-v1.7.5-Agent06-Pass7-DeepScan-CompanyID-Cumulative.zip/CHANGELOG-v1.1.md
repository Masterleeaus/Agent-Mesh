# Titan Autonomy Engine v1.1.0

## Added

- Executable capability state-transition pipeline.
- Exact one-level activation enforcement and fresh evidence after promotion.
- Persisted Trusted Auto grant orchestration with three-way handshake inputs.
- Fail-closed execution authority and bounded-scope checks.
- Capability-local automatic regression for reversals, Assurance RED and material corrections.
- Runtime outcome orchestration with learning and gate decision audit events.
- Platform/tenant policy merge that prevents tenant weakening of safety minimums or ceilings.
- Allow-list-only system learning projection.
- Laravel database adapters for autonomy state, learning events and audit records.
- `titan_autonomy_policies`, `titan_learning_settings`, and `titan_capability_training_stats` schema.
- Learning-scope metadata on tenant learning events.
- Five self-contained smoke test suites for runtime behavior.

## Preserved

- Interaction Engine + CommandBus remain the only governed execution path.
- TitanAI cannot mint approval, alter evidence, bypass policy or directly mutate governed records.
- Critical-risk default ceiling remains Semi-Auto.
- High-risk default ceiling remains Auto.
- System-wide learning remains disabled by default.
