<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalConsoleRequest
{
    private const WINDOWS = ['5m', '1h', '24h', '7d'];

    public function __construct(
        public string $scope,
        public ?int $tenantCompanyId,
        public string $window,
        public int $limit,
    ) {
    }

    /** @param array<string,mixed> $input */
    public static function fromArray(array $input): self
    {
        $scope = strtolower(trim((string) ($input['scope'] ?? SignalEnvelope::SCOPE_TENANT)));
        if (! in_array($scope, [SignalEnvelope::SCOPE_TENANT, SignalEnvelope::SCOPE_SYSTEM], true)) {
            throw new InvalidArgumentException('Signal console scope must be tenant or system.');
        }

        $tenant = $input['tenant_company_id'] ?? null;
        $tenant = $tenant === null || $tenant === '' ? null : (int) $tenant;
        if ($scope === SignalEnvelope::SCOPE_TENANT && ($tenant === null || $tenant < 1)) {
            throw new InvalidArgumentException('Tenant Signal console requests require tenant_company_id.');
        }
        if ($scope === SignalEnvelope::SCOPE_SYSTEM) {
            $tenant = null;
        }

        $window = strtolower(trim((string) ($input['window'] ?? '5m')));
        if (! in_array($window, self::WINDOWS, true)) {
            throw new InvalidArgumentException('Unsupported Signal console window.');
        }

        $limit = max(1, min((int) ($input['limit'] ?? 100), 250));

        return new self($scope, $tenant, $window, $limit);
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'scope' => $this->scope,
            'tenant_company_id' => $this->tenantCompanyId,
            'window' => $this->window,
            'limit' => $this->limit,
        ];
    }
}
