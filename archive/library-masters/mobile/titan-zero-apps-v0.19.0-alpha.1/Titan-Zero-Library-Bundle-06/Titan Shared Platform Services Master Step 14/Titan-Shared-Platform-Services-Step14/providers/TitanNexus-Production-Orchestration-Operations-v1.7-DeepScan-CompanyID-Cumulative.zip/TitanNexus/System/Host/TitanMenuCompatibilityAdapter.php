<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Host;

use Illuminate\Support\Facades\Schema;
use Throwable;

/** Modern registry first; MagicAI menus-table fallback. Self-heal must preserve administrator order/state and never make provider boot fatal. */
final class TitanMenuCompatibilityAdapter
{
    /** @param list<array<string,mixed>> $definitions */
    public function registerAll(array $definitions): void
    {
        if (app()->bound('MenuContributionRegistry')) {
            try {
                $registry = app('MenuContributionRegistry');
                if (method_exists($registry, 'register')) {
                    foreach ($definitions as $definition) { $registry->register($definition); }
                    return;
                }
            } catch (Throwable) {
                // Fall through to legacy self-heal rather than failing provider boot.
            }
        }
        $this->legacyUpsertPreserveAdminState($definitions);
    }

    /** @param list<array<string,mixed>> $definitions */
    public function removeAll(array $definitions): void
    {
        if (app()->bound('MenuContributionRegistry')) {
            try {
                $registry = app('MenuContributionRegistry');
                if (method_exists($registry, 'unregister')) {
                    foreach (array_reverse($definitions) as $definition) { $registry->unregister((string)($definition['key'] ?? '')); }
                }
            } catch (Throwable) {}
        }
        if (!Schema::hasTable('menus')) return;
        try {
            $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
            foreach (array_reverse($definitions) as $definition) {
                $identity = $this->resolveLegacyIdentity($definition, $columns);
                if ($identity === []) continue;
                $query = app('db')->table('menus');
                foreach ($identity as $key => $value) { $query->where($key, $value); }
                $query->delete();
            }
            $this->regenerate();
        } catch (Throwable) {}
    }

    /** @param list<array<string,mixed>> $definitions */
    private function legacyUpsertPreserveAdminState(array $definitions): void
    {
        if (!Schema::hasTable('menus')) return;
        try {
            $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
            $parentIds = [];
            foreach ($definitions as $definition) {
                $identity = $this->resolveLegacyIdentity($definition, $columns);
                if ($identity === []) continue;
                $payload = $this->filterColumns($definition['legacy_fields'] ?? [], $columns);
                foreach (['order','sort','position','enabled','status','is_active'] as $field) unset($payload[$field]);
                $parentKey = $definition['parent_key'] ?? null;
                if (is_string($parentKey) && isset($parentIds[$parentKey]) && isset($columns['parent_id'])) $payload['parent_id']=$parentIds[$parentKey];
                $query = app('db')->table('menus');
                foreach ($identity as $key => $value) $query->where($key,$value);
                $existing=$query->first(); $id=null;
                if ($existing!==null) { if($payload!==[])$query->update($payload); $id=isset($existing->id)?(int)$existing->id:null; }
                else { $row=array_merge($identity,$payload); if(isset($columns['id']))$id=(int)app('db')->table('menus')->insertGetId($row); else app('db')->table('menus')->insert($row); }
                if(isset($definition['key'])&&is_string($definition['key'])&&$id!==null)$parentIds[$definition['key']]=$id;
            }
            $this->regenerate();
        } catch (Throwable) {}
    }

    /** @param array<string,mixed> $definition @param array<string,bool> $columns @return array<string,mixed> */
    private function resolveLegacyIdentity(array $definition, array $columns): array
    {
        $identity=$this->filterColumns($definition['legacy_identity']??[],$columns);
        return $identity!==[]?$identity:$this->filterColumns($definition['legacy_fallback_identity']??[],$columns);
    }

    /** @param array<string,mixed> $values @param array<string,bool> $columns @return array<string,mixed> */
    private function filterColumns(array $values,array $columns): array
    {
        return array_filter($values,static fn(mixed $value,string $key):bool=>isset($columns[$key])&&$value!==null,ARRAY_FILTER_USE_BOTH);
    }

    private function regenerate(): void
    {
        $class='App\Services\Common\MenuService'; if(!class_exists($class))return;
        try { $service=app($class); if(method_exists($service,'regenerate'))$service->regenerate(); } catch(Throwable) {}
    }
}
