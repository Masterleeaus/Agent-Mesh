<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        foreach (['titan_prime_missions', 'titan_prime_mission_operations'] as $tableName) {
            if (! Schema::hasTable($tableName) || ! Schema::hasColumn($tableName, 'tenant_company_id')) continue;
            if (! Schema::hasColumn($tableName, 'company_id')) {
                Schema::table($tableName, function (Blueprint $table): void { $table->unsignedBigInteger('company_id')->nullable()->index(); });
            }
            DB::table($tableName)->whereNull('company_id')->whereNotNull('tenant_company_id')
                ->update(['company_id' => DB::raw('tenant_company_id')]);
        }
    }
    public function down(): void
    {
        foreach (['titan_prime_missions', 'titan_prime_mission_operations'] as $tableName) {
            if (Schema::hasTable($tableName) && Schema::hasColumn($tableName, 'company_id')) {
                Schema::table($tableName, function (Blueprint $table): void { $table->dropColumn('company_id'); });
            }
        }
    }
};
