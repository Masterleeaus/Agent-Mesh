<div class="space-y-4">
    <h1>Titan Knowledge Authority</h1>
    <p><strong>Immutable version foundation:</strong> v0.5.0-alpha.4 adds transactional append-only source-version writes, deterministic sequencing, hash deduplication and supersession safeguards.</p>
    <p>Public catalog reads and remote refresh remain disabled. Trusted host context is required for internal catalog reads and immutable version appends.</p>
</div>
