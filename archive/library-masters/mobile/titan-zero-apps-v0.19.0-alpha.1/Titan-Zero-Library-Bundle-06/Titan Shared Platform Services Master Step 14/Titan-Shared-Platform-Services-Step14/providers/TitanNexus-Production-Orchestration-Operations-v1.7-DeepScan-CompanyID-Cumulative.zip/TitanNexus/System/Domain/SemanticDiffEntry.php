<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\CanonicalJson;
use InvalidArgumentException;

final class SemanticDiffEntry
{
    public function __construct(
        private readonly string $path,
        private readonly SemanticChangeKind $kind,
        private readonly SemanticChangeDisposition $disposition,
        private readonly mixed $before,
        private readonly mixed $after,
        private readonly ?string $reason = null,
    ) {
        $trimmed = trim($this->path);
        if ($trimmed === '' || strlen($trimmed) > 512) {
            throw new InvalidArgumentException('diff path must be between 1 and 512 characters.');
        }
        if ($this->reason !== null && (trim($this->reason) === '' || strlen($this->reason) > 1024)) {
            throw new InvalidArgumentException('diff reason must be null or between 1 and 1024 characters.');
        }
        CanonicalJson::encode($this->before);
        CanonicalJson::encode($this->after);
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $path = $data['path'] ?? null;
        $kind = $data['kind'] ?? null;
        $disposition = $data['disposition'] ?? null;
        $reason = $data['reason'] ?? null;

        if (!is_string($path) || !is_string($kind) || !is_string($disposition)
            || SemanticChangeKind::tryFrom($kind) === null
            || SemanticChangeDisposition::tryFrom($disposition) === null) {
            throw new InvalidArgumentException('Stored semantic diff entry is invalid.');
        }
        if ($reason !== null && !is_string($reason)) {
            throw new InvalidArgumentException('Stored semantic diff reason is invalid.');
        }

        return new self(
            trim($path),
            SemanticChangeKind::from($kind),
            SemanticChangeDisposition::from($disposition),
            $data['before'] ?? null,
            $data['after'] ?? null,
            $reason === null ? null : trim($reason),
        );
    }

    public function path(): string { return $this->path; }
    public function kind(): SemanticChangeKind { return $this->kind; }
    public function disposition(): SemanticChangeDisposition { return $this->disposition; }
    public function before(): mixed { return $this->before; }
    public function after(): mixed { return $this->after; }
    public function reason(): ?string { return $this->reason; }

    /** @return array<string,mixed> */
    public function toContractArray(): array
    {
        return [
            'path' => $this->path,
            'change_kind' => $this->kind->value,
            'governance_disposition' => $this->disposition->value,
            'before' => $this->before,
            'after' => $this->after,
            'reason' => $this->reason,
        ];
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        $data = [
            'path' => $this->path,
            'kind' => $this->kind->value,
            'disposition' => $this->disposition->value,
            'before' => $this->before,
            'after' => $this->after,
        ];
        if ($this->reason !== null) {
            $data['reason'] = $this->reason;
        }
        return $data;
    }
}
