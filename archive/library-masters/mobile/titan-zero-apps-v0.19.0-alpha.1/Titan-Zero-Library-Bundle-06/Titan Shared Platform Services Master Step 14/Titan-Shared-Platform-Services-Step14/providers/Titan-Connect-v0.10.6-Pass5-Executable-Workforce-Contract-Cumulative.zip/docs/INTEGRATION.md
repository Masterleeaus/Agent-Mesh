# Titan Connect v0.10.6 Integration Guide

## Host contracts

Titan Connect keeps WorkCore, Chatbot, TitanAI/Interaction and TitanMobileCore behind explicit contracts/events rather than importing their internals.

- **WorkCore** — linked entity access must be explicitly authorized; missing authorization fails closed.
- **Chatbot** — receives inbound and human-handoff events with explicit company identity.
- **TitanMobileCore** — receives push delivery events; device/subscription ownership remains MobileCore.
- **TitanAI/Interaction** — governed messaging tools can read/send without receiving provider credentials.

## Operator inbox

Web UI: `/dashboard/titan-connect/inbox`.

The operator API supports company/member-scoped inbox filtering, unread notifications, assignment, pin/close, presentation changes, internal notes, tags, canned responses, exports and AI rewrite actions. Internal notes are stored canonically with `direction=internal` and are never delivered to external providers.

## Meta OAuth — Messenger / Instagram

Set platform application values:

- `TITAN_CONNECT_META_APP_ID`
- `TITAN_CONNECT_META_APP_SECRET`
- optional Graph/dialog/version overrides.

Start through `/dashboard/titan-connect/onboarding/meta/{provider}` where provider is `messenger` or `instagram`. OAuth state is encrypted and bound to the authenticated company and actor. Discovered page/account access credentials are written to the encrypted Titan Connect vault.

## Telegram onboarding

POST the bot token to `titan-connect.api.onboarding.telegram`. Titan Connect validates the bot, creates a secret token and calls Telegram `setWebhook` using the canonical Titan Connect webhook route. The token and webhook secret are then encrypted in the company credential vault.

## WhatsApp transports

Provider key remains `whatsapp`.

- default: `settings.transport=meta` — Meta WhatsApp Cloud API;
- optional: `settings.transport=twilio` — Twilio WhatsApp REST transport.

Twilio credentials are provisioned through the normal encrypted credential endpoint (`account_sid`, `auth_token` or API-key pair, `from`, optional status callback). Titan Connect keeps its existing signature validation, replay protection, idempotency and delivery state machine.

## Voice sessions

Create a normal company-owned `voice` channel connection. Connection settings choose `engine=openai_realtime|elevenlabs`; provider credentials are stored in the vault.

Voice endpoints support call start, short-lived client-session renewal, transcript persistence and call end. Calls may be linked to an external thread or an internal conversation. The browser client handles microphone input, audio streaming/playback, transcripts and waveform rendering.

### OpenAI Realtime

Credential payload contains `api_key` (or `openai_api_key`) and optional model/voice overrides. Titan Connect requests a short-lived browser credential; the long-lived API key is not returned to the browser.

### ElevenLabs

Credential payload contains `agent_id` and either `api_key` for signed-URL generation or a pre-provisioned signed URL where appropriate.

### Optional voice-agent authoring

`VoiceAgentGateway` defaults to a null/fail-closed implementation. A host may explicitly bind `MagicAiElevenLabsVoiceAgentGateway` through `TITAN_CONNECT_VOICE_AGENT_GATEWAY_CLASS` when platform-level ElevenLabs agent/knowledge ownership is intended.

## Reply assistant

`ReplyAssistant` defaults to `MagicAiReplyAssistant` and supports `improve`, `lengthen`, `fix_grammar`. Override with `TITAN_CONNECT_REPLY_ASSISTANT_CLASS`. Provider/AI credentials are never returned to the operator browser.

## Assets

Publish `titan-connect-assets`; the complete asset tree is installed under `public/vendor/titan-connect`, including team-chat, operator inbox, voice client, CSS and provider icons.

## v0.9 production-readiness integration

- Authenticated mutation rate limits are configured under `titan-connect.rate_limits` and keyed internally by company + actor.
- Owners/admins can use `/dashboard/titan-connect/settings` for safe connection diagnostics and health operations.
- Run `php artisan titan-connect:diagnose` after deployment and after changing queue/cache/broadcast/storage/scanner infrastructure.
- Voice transcript clients may send `client_event_id`; duplicate company/call/event IDs are idempotent.
- Public provider webhooks remain outside authenticated rate limiting and continue to rely on provider signature + replay/idempotency controls.


## Navigation integration

Titan Connect contributes a top-level **Channels** parent and a separate top-level **Inbox** parent through the Titan Blueprint-v3 navigation registries when available. Channel children use dedicated named routes for WhatsApp, Messenger, Instagram, Telegram, SMS, Voice and Push / Mobile. Inbox children use dedicated named routes for Unified, Team/Internal, External, Assigned to Me, Unassigned, Needs Human and Closed/Archived.

Dynamic Inbox badges are loaded from the authenticated `titan-connect.api.navigation.badges` endpoint using the current `company_id` + actor ID. Do not place user-specific badge values into MagicAI's globally cached structural menu catalogue. See `docs/NAVIGATION_MENU_V090.md` and `host-patches/README.md`.
