<div class="space-y-4">
    <h1>Titan Knowledge Authority — Administration</h1>
    <p>v0.5.0-alpha.4 adds immutable, transactional source-version append semantics on top of trusted access-context and repository scope boundaries. No source scraping, external retrieval, recurring refresh, destructive knowledge controls or cross-domain side effects are active.</p>
</div>
