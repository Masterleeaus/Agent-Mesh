# Titan CRM v1.3.0-alpha.22 CQRS Read Store Implementation Plan

**Goal:** Add a portable, rebuildable CQRS projection boundary and signed Titan Go delta synchronization without changing CRM authoritative write ownership.

**Architecture:** CRM mutations stay on OLTP tables. Committed transactional outbox events update a local disposable read store through `CrmReadStorePort`; AI/dashboard consumers query that store. Titan Go uses a tenant/worker-bound HMAC cursor over a durable change feed.

## Tasks

- [x] Add alpha.22 failing regression gate.
- [x] Add read projection state/record and mobile change-feed migration.
- [x] Add `CrmReadStorePort` and SQL implementation.
- [x] Centralize versioned projection definitions.
- [x] Add deterministic projection builder/rebuild command.
- [x] Move named AI projections to read store.
- [x] Add owner-dashboard projection capability path.
- [x] Project committed outbox events locally without blocking Titan Signal.
- [x] Add signed Titan Go `sync_token` and delta change feed.
- [x] Preserve legacy Titan Go cursor transition behavior.
- [x] Add targeted source/read-store indexes.
- [x] Run cumulative verifier and full PHP lint; clean-extraction verification is the final packaging gate.
- [x] Regenerate production integrity manifests after source tree freeze.
