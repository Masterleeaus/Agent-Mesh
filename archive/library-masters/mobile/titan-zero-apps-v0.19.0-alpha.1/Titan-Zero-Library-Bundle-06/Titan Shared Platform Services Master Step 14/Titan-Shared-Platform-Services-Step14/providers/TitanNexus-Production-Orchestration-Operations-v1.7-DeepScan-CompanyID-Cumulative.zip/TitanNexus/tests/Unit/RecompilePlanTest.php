<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanNexus\Unit;

use App\Extensions\TitanNexus\System\Adapters\Platform\PlatformReadinessAdapter;
use App\Extensions\TitanNexus\System\Contracts\VerticalDefinitionSourceContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\RecompilePlanStatus;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Services\DeterministicNexusCompiler;
use App\Extensions\TitanNexus\System\Services\NexusManager;
use App\Extensions\TitanNexus\System\Services\SemanticConfigurationDiffer;
use App\Extensions\TitanNexus\System\Services\SemanticNexusValidator;
use PHPUnit\Framework\TestCase;

final class RecompilePlanTest extends TestCase
{
    public function test_plan_links_parent_and_requires_approval_without_mutating_current(): void
    {
        $source = new class implements VerticalDefinitionSourceContract {
            public function resolve(BusinessProfile $profile): VerticalDefinition
            {
                return VerticalDefinition::fromArray([
                    'vertical_id' => $profile->verticalId(),
                    'vertical_version' => $profile->verticalVersion(),
                    'sections' => ['billing' => ['currency' => 'AUD']],
                    'recompile_policy' => ['requires_approval_paths' => ['sections.billing.currency']],
                ]);
            }
        };
        $manager = new NexusManager(
            new DeterministicNexusCompiler('0.5.0'),
            $source,
            new SemanticNexusValidator(new PlatformReadinessAdapter()),
            new SemanticConfigurationDiffer(),
        );

        $currentDraft = $manager->newDraft($this->profile('AUD'), $this->trace('11111111-1111-4111-8111-111111111111'), '44444444-4444-4444-8444-444444444444');
        $current = $manager->compileDraft($currentDraft, '1');
        $plan = $manager->planRecompile(
            $current,
            $this->profile('NZD'),
            $this->trace('55555555-5555-4555-8555-555555555555'),
            '66666666-6666-4666-8666-666666666666',
            '2',
        );

        self::assertSame(RecompilePlanStatus::RequiresApproval, $plan->status());
        self::assertSame($current->compilationUuid(), $plan->candidate()->parentCompilationUuid());
        self::assertTrue($plan->candidate()->dryRun());
        self::assertNull($current->configurationDiff());
    }

    private function profile(string $currency): BusinessProfile
    {
        return BusinessProfile::fromArray([
            'tenant_company_id' => 42,
            'profile_version' => '1.0.0',
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'jurisdiction' => ['country_code' => 'AU'],
            'timezone' => 'Australia/Melbourne',
            'sections' => ['billing' => ['currency' => $currency]],
        ]);
    }

    private function trace(string $traceId): TraceContext
    {
        return TraceContext::fromArray([
            'tenant_company_id' => 42,
            'trace_id' => $traceId,
            'correlation_id' => '22222222-2222-4222-8222-222222222222',
            'causation_id' => '33333333-3333-4333-8333-333333333333',
        ]);
    }
}
