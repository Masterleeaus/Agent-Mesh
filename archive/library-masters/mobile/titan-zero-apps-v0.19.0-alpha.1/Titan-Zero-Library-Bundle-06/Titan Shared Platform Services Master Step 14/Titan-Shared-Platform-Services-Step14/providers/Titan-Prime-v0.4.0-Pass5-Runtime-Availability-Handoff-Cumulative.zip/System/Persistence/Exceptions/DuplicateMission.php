<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Persistence\Exceptions;

use RuntimeException;

final class DuplicateMission extends RuntimeException
{
    public static function forTenant(int $tenantCompanyId, string $missionId): self
    {
        return new self(sprintf('Prime mission [%s] already exists for tenant [%d].', $missionId, $tenantCompanyId));
    }
}
