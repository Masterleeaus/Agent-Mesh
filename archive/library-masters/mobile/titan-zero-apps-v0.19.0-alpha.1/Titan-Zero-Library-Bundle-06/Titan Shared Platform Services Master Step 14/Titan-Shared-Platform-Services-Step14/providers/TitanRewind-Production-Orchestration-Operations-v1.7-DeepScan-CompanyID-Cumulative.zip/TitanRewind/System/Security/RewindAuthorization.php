<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Security;

use RuntimeException;
use Throwable;

final class RewindAuthorization
{
    public function assertTenantMatch(int $expectedTenantCompanyId, int $actualTenantCompanyId): void
    {
        if ($expectedTenantCompanyId < 1 || $actualTenantCompanyId < 1 || $expectedTenantCompanyId !== $actualTenantCompanyId) {
            throw new RuntimeException('Titan Rewind object is outside the active tenant boundary.');
        }
    }

    public function assertActorPermission(mixed $actor, string $permission): void
    {
        $permission = trim($permission);
        if ($actor === null || $permission === '') {
            throw new RuntimeException('Titan Rewind authorization denied.');
        }

        // MagicAI/Titan host authority uses a direct Super Admin bypass rather
        // than per-user Spatie role assignments. Respect that host contract.
        if ($this->actorBooleanMethod($actor, 'isSuperAdmin') === true) {
            return;
        }

        // Prefer explicit Titan/Rewind grants whenever the host exposes them.
        foreach (['can', 'checkPermission', 'hasPermissionTo'] as $method) {
            if ($this->actorPermissionMethod($actor, $method, $permission) === true) {
                return;
            }
        }

        // Current MagicAI deployments model delegated platform administrators
        // through users.type/isAdmin(), while custom Titan permissions may not
        // be assigned to individual users. Grant only the safe diagnostic subset.
        if ($this->actorBooleanMethod($actor, 'isAdmin') === true
            && in_array($permission, RewindPermissions::delegatedAdminFallback(), true)) {
            return;
        }

        throw new RuntimeException("Titan Rewind permission denied: {$permission}");
    }

    private function actorBooleanMethod(mixed $actor, string $method): ?bool
    {
        if (!is_object($actor) || !method_exists($actor, $method)) return null;
        try {
            return $actor->{$method}() === true;
        } catch (Throwable) {
            return null;
        }
    }

    private function actorPermissionMethod(mixed $actor, string $method, string $permission): ?bool
    {
        if (!is_object($actor) || !method_exists($actor, $method)) return null;
        try {
            return $actor->{$method}($permission) === true;
        } catch (Throwable) {
            return null;
        }
    }
}
