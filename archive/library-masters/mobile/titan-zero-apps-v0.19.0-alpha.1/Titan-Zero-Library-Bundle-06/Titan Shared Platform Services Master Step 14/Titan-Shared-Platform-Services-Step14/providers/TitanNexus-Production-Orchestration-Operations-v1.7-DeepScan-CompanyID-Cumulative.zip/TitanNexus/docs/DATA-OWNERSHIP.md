# Data Ownership

Nexus owns compilation snapshots, configuration lineage, validation/diff artifacts, provisioning plans and provisioning receipts. `tenant_company_id` is mandatory for tenant-owned state. Nexus does not own downstream domain records and does not write foreign extension tables.
