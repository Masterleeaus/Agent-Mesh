@extends('panel.layout.app')
@section('title', 'Titan Rewind — Recovery')

@section('content')
    <a href="#titan-rewind-content" class="sr-only focus:not-sr-only">{{ __('titan-rewind::rewind.accessibility_skip') }}</a>
    <main id="titan-rewind-content" role="main" class="container py-8 space-y-6">
        <div>
            <h1 class="text-2xl font-semibold">Rewind Recovery Plan</h1>
            <code>{{ $plan->plan_uuid }}</code>
            <p class="text-sm opacity-70">{{ $plan->strategy }} · risk {{ $plan->risk_level }} · {{ $plan->status }}</p>
        </div>
        @if(session('rewind_status'))<div class="rounded border p-3" aria-live="polite">{{ session('rewind_status') }}</div>@endif
        <div class="grid gap-4 md:grid-cols-4">
            <div class="rounded border p-3"><strong>{{ $plan->plan['submission_ready'] ? 'yes' : 'no' }}</strong><div>Submission ready</div></div>
            <div class="rounded border p-3"><strong>{{ $plan->plan['requires_governance'] ? 'required' : 'no' }}</strong><div>Governance</div></div>
            <div class="rounded border p-3"><strong>{{ $governanceAvailable ? 'connected' : 'not bound' }}</strong><div>Governance gateway</div></div>
            <div class="rounded border p-3"><strong>Command Bus</strong><div>Execution owner</div></div>
        </div>
        @if($plan->blockers)
            <section class="rounded border p-4"><h2 class="text-lg font-semibold mb-2">Blockers</h2><ul class="list-disc pl-5">@foreach($plan->blockers as $blocker)<li>{{ $blocker }}</li>@endforeach</ul></section>
        @endif
        <section>
            <h2 class="text-lg font-semibold mb-3">Ordered recovery steps</h2>
            @foreach($plan->steps as $step)
                <div class="rounded border p-3 mb-2">
                    <div><strong>#{{ $step->step_order }} {{ $step->step_type }}</strong> · {{ $step->status }}</div>
                    <div class="text-sm">Owner: {{ $step->execution_owner }} · Human authorization: {{ $step->requires_human ? 'required' : 'not inherently required' }}</div>
                    <pre class="mt-2 overflow-x-auto text-xs">{{ json_encode(['input'=>$step->input,'success_evidence'=>$step->success_evidence], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre>
                </div>
            @endforeach
        </section>
        <section class="rounded border p-4 space-y-3">
            <h2 class="text-lg font-semibold">Governance handoff</h2>
            <p>Rewind cannot approve its own recovery. Titan Governance must return a decision receipt before any compensating command can be authorized, and Titan Command Bus remains the execution owner.</p>
            @if($governanceAvailable && $plan->plan['submission_ready'])
                <form method="POST" action="{{ route('dashboard.user.titan.rewind.recovery.governance.request',['planUuid'=>$plan->plan_uuid]) }}">@csrf<button type="submit" class="rounded border px-4 py-2">Request Governance approval</button></form>
            @else
                <p class="text-sm opacity-70">@if(!$governanceAvailable) No Titan Governance adapter is currently bound to Rewind. No approval request will be fabricated. @else Resolve the plan blockers before requesting approval. @endif</p>
            @endif
            @if($plan->governanceReceipts->isNotEmpty())
                <div class="space-y-2">@foreach($plan->governanceReceipts as $receipt)<div class="rounded border p-3"><strong>{{ $receipt->authority }}</strong> · {{ $receipt->status }} · {{ $receipt->external_request_id }}</div>@endforeach</div>
                @if($governanceAvailable)<form method="POST" action="{{ route('dashboard.user.titan.rewind.recovery.governance.refresh',['planUuid'=>$plan->plan_uuid]) }}">@csrf<button type="submit" class="rounded border px-4 py-2">Refresh Governance decision</button></form>@endif
            @endif
        </section>
        <section class="rounded border p-4"><strong>Plan SHA-256</strong><div class="break-all"><code>{{ $plan->plan_hash }}</code></div></section>
    </main>
@endsection
