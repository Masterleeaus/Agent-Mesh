<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class SignalPulseTraceEventCount extends Model
{
    protected $table = 'titan_signal_pulse_trace_event_counts';
    protected $guarded = [];
    protected $casts = [
        'tenant_company_id' => 'integer',
        'tenant_key' => 'integer',
        'event_count' => 'integer',
        'first_occurred_at' => 'immutable_datetime',
        'last_occurred_at' => 'immutable_datetime',
    ];
}
