<?php

declare(strict_types=1);

function rcheck(bool $condition, string $message): void { if (!$condition) throw new RuntimeException($message); }

$root = dirname(__DIR__, 2);
$route = $root . '/routes/web.php';
rcheck(is_file($route), 'tenant route file must exist');
$text = file_get_contents($route);
rcheck(str_contains($text, "middleware(config('titan-autonomy.route_middleware'"), 'routes must use configurable authenticated middleware');
rcheck(str_contains($text, "name('titan-autonomy.'"), 'routes must use isolated names');
rcheck(str_contains($text, "Route::get('/learning/export'"), 'learning export route required');
rcheck(str_contains($text, "Route::post('/capabilities/{capability}/grant-next'"), 'explicit next-gate action required');
rcheck(str_contains($text, "Route::post('/capabilities/{capability}/reset-learning'"), 'scoped learning reset route required');
rcheck(str_contains($text, "Route::post('/capabilities/{capability}/request-assurance'"), 'live Trusted Auto Assurance assessment route required');
rcheck(str_contains($text, "Route::post('/executions/{correlationId}/feedback'"), 'closed-loop negative execution feedback route required');

$action = file_get_contents($root . '/System/Http/Controllers/AutonomyActionController.php');
rcheck(!preg_match('/input\([\'\"]tenant_company_id/', $action), 'controller must not accept tenant_company_id from request input');
rcheck(str_contains($action, '->tenantCompanyId()'), 'controller must resolve tenant from host context');
rcheck(str_contains($action, "'titan.autonomy.manage'"), 'autonomy mutations require permission');
rcheck(str_contains($action, "'titan.learning.manage'"), 'learning mutations require permission');


$feedback = file_get_contents($root . '/System/Http/Controllers/AutonomyExecutionFeedbackController.php');
rcheck(!preg_match('/input\([\'"]tenant_company_id/', $feedback), 'execution feedback must not accept tenant_company_id from request input');
rcheck(str_contains($feedback, '->tenantCompanyId()'), 'execution feedback must derive tenant from trusted host context');
rcheck(str_contains($feedback, 'materially_corrected,reversed,failed,rejected,exception'), 'feedback route must be negative-only and unable to mint positive success evidence');
rcheck(!str_contains($feedback, 'approved_unchanged'), 'feedback controller must never accept a forged positive approval');

foreach (['resources/views/autonomy/index.blade.php','resources/views/autonomy/capability.blade.php','resources/views/autonomy/learning.blade.php'] as $view) {
    rcheck(is_file($root . '/' . $view), "missing view: {$view}");
}

echo "OK: RouteSurfaceSmokeTest\n";
