<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\ExecutionPostconditionVerifierContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\GovernedCapabilityCommand;

final class UnavailableExecutionPostconditionVerifier implements ExecutionPostconditionVerifierContract
{
    public function verify(CapabilityState $state, GovernedCapabilityCommand $command, array $commandResult, array $context = []): array
    {
        return ['status'=>'unavailable','confidence'=>0.0,'reason_codes'=>['POSTCONDITION_VERIFIER_UNAVAILABLE'],'facts'=>[]];
    }
}
