<?php

declare(strict_types=1);

namespace App\Extensions\TitanAI\System\Providers;

use Throwable;

final class ConfigCredentialResolver implements CredentialResolverContract
{
    public function resolve(string $providerId): ?string
    {
        $value = config('titan-ai.providers.'.$providerId.'.api_key');
        if (is_scalar($value) && trim((string) $value) !== '') {
            return trim((string) $value);
        }

        // Reuse the base MagicAI OpenAI credential server-side when TitanAI has no
        // dedicated key. The credential never enters a runtime request or browser payload.
        if ($providerId === 'openai' && class_exists(\App\Helpers\Classes\ApiHelper::class)) {
            try {
                $hostKey = \App\Helpers\Classes\ApiHelper::setOpenAiKey();
                if (is_scalar($hostKey) && trim((string) $hostKey) !== '') {
                    return trim((string) $hostKey);
                }
            } catch (Throwable) {
            }
        }

        return null;
    }
}
