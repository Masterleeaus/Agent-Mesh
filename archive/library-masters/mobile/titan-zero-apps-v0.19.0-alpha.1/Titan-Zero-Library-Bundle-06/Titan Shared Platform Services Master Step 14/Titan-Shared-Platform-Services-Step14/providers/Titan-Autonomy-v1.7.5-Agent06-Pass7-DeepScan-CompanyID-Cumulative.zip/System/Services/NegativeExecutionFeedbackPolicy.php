<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use InvalidArgumentException;

final class NegativeExecutionFeedbackPolicy
{
    private const ALLOWED = ['materially_corrected', 'reversed', 'failed', 'rejected', 'exception'];

    public function assertAllowed(string $classification): void
    {
        if (!in_array($classification, self::ALLOWED, true)) {
            throw new InvalidArgumentException('ONLY_NEGATIVE_EXECUTION_FEEDBACK_IS_ACCEPTED');
        }
    }

    /** @return list<string> */
    public function allowed(): array { return self::ALLOWED; }
}
