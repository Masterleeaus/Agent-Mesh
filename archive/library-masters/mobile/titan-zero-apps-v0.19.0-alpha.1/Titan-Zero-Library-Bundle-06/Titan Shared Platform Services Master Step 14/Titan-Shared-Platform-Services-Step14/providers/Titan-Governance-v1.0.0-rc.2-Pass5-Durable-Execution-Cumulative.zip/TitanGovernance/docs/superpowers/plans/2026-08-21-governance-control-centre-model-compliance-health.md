# Governance Control Centre & Model/Compliance Health Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the tenant-scoped Governance Control Centre with model/council health, policy/compliance drift, authority-contraction explanations, freshness/exception monitoring, cross-engine scorecard and deterministic Needs Attention ranking.

**Architecture:** Add a read-only `System/ControlCentre` subsystem that consumes existing Governance read adapters plus Governance-owned decision/escalation stores. Each projector is deterministic and source-truth-preserving; `GovernanceControlCentre` composes the result for the manager/controller/UI.

**Tech Stack:** PHP 8.3, Laravel 10.50, MagicAI >=10.91, Blueprint v4.2.2, Installer 1.7.8.

**Spec:** `docs/superpowers/specs/2026-08-21-governance-control-centre-model-compliance-health-design.md`

## Global Constraints
- Titan Autonomy remains sole owner of earned/effective authority.
- Titan Governance may constrain/explain authority but must never mint or raise authority.
- No peer-engine table access; all cross-engine reads use `GovernanceReadSourceContract`.
- Missing or malformed evidence fails visibly; no fabricated healthy/compliant state.
- No raw prompts, credentials, provider payloads or hidden reasoning in output.
- `tenant_company_id` comes from trusted host context only.
- Pass 6 remains read-only apart from Governance-owned state established in prior passes.

---

### Task 1: Control-centre source normalization and freshness
**Files:**
- Create: `System/ControlCentre/ControlCentreSourceReader.php`
- Create: `System/ControlCentre/EvidenceFreshnessProjector.php`
- Test: `tests/Contract/control_centre_source_contract.php`

**Interfaces:**
- Consumes: `GovernanceReadSourceRegistry::get()/all()` and `GovernanceReadSourceContract::snapshot()`.
- Produces: `ControlCentreSourceReader::snapshot(int,string,array): array` and `EvidenceFreshnessProjector::project(array,array): array`.

- [ ] Write a failing standalone test proving source failures are isolated, tenant identity mismatch is INVALID, missing timestamps are UNKNOWN and old timestamps are STALE.
- [ ] Run the test and confirm RED because production classes are absent.
- [ ] Implement the two focused classes with bounded arrays and exception isolation.
- [ ] Re-run and confirm GREEN.

### Task 2: Model transition health and Model Council disagreement
**Files:**
- Create: `System/ControlCentre/ModelHealthProjector.php`
- Test: `tests/Contract/model_health_contract.php`

**Interfaces:**
- Consumes: normalized `control_centre.models` and `control_centre.council` snapshots.
- Produces: `ModelHealthProjector::project(array $sourceSnapshots,array $context=[]): array`.

- [ ] Write RED tests for healthy/degraded/failed transitions, drift visibility and independent council disagreement classification.
- [ ] Implement deterministic normalization; do not turn disagreement into authority.
- [ ] Run GREEN tests.

### Task 3: Policy drift, compliance controls and exception expiry
**Files:**
- Create: `System/ControlCentre/PolicyComplianceHealthProjector.php`
- Test: `tests/Contract/control_compliance_health_contract.php`

**Interfaces:**
- Consumes: normalized policy/control records plus recent Governance decisions.
- Produces: `PolicyComplianceHealthProjector::project(array $sourceSnapshots,array $recentDecisions,array $context=[]): array`.

- [ ] Write RED tests for version drift, explicit non-compliance, optional-source absence, expiring exception and expired exception.
- [ ] Implement deterministic status mapping and expiry windows.
- [ ] Run GREEN tests.

### Task 4: Authority contraction explanations and engine scorecard
**Files:**
- Create: `System/ControlCentre/AuthorityContractionProjector.php`
- Create: `System/ControlCentre/EngineHealthScorecard.php`
- Test: `tests/Contract/control_centre_authority_health_contract.php`

**Interfaces:**
- Consumes: Autonomy/control-centre authority constraints and existing source-health snapshot.
- Produces: explanatory contractions and weighted/readable engine scorecard with no authority mutation.

- [ ] Write RED tests proving contractions preserve source scores/reason codes and scorecard cannot report HEALTHY when a required source is unavailable.
- [ ] Implement projectors.
- [ ] Run GREEN tests.

### Task 5: Needs Attention ranking and Control Centre composer
**Files:**
- Create: `System/ControlCentre/GovernanceAttentionRanker.php`
- Create: `System/ControlCentre/GovernanceControlCentre.php`
- Test: `tests/Contract/control_centre_contract.php`

**Interfaces:**
- Consumes: Tasks 1-4, Governance decision store, escalation store, read plane and signal intelligence.
- Produces: `GovernanceControlCentre::snapshot(int,array): array` with `status`, `needs_attention`, `engine_health`, `model_health`, `policy_compliance`, `authority_contractions`, `freshness`.

- [ ] Write RED test for deterministic attention ordering and facet failure isolation.
- [ ] Implement composer/ranker.
- [ ] Run GREEN tests.

### Task 6: Service/provider/controller/routes/UI wiring
**Files:**
- Modify: `System/Contracts/GovernanceManagerContract.php`
- Modify: `System/Services/GovernanceManager.php`
- Modify: `System/TitanGovernanceServiceProvider.php`
- Create: `System/Http/Controllers/ControlCentreController.php`
- Modify: `System/Http/Controllers/IndexController.php`
- Modify: `routes/user.php`
- Modify: `resources/views/index.blade.php`
- Test: `tests/Contract/pass6_wiring_static.php`

**Interfaces:**
- Adds `GovernanceManagerContract::controlCentre(int,array): array`.
- Adds authenticated GET `control-centre` route under tenant Governance routes.

- [ ] Write RED static wiring test.
- [ ] Bind Pass 6 classes and add manager/controller route.
- [ ] Render all control-centre facets using host `panel.layout.app`, escaped Blade only.
- [ ] Run GREEN test.

### Task 7: Manifest, schemas, documentation and release contract
**Files:**
- Modify: `extension.json`
- Modify: `extension.manifest.json`
- Modify: `config/titan-governance.php`
- Create: `schemas/capabilities/control-centre.output.json`
- Create: `PASS6-CONTROL-CENTRE-REPORT.md`
- Modify: `README.md`, `CHANGELOG.md`, `BLUEPRINT-v4.2-ALIGNMENT-REPORT.md`, `bin/verify.php`
- Test: `tests/Contract/pass6_release_contract.php`

**Interfaces:**
- Adds read-only capability `governance.control-centre.read`.
- Version becomes 0.7.0.

- [ ] Write RED release contract for version, capability/schema/docs/verifier and security boundaries.
- [ ] Update metadata/docs/verifier.
- [ ] Run GREEN release contract.

### Task 8: Cumulative verification and packaging
**Files:**
- Regenerate: `SBOM.cdx.json`, `BUILD-PROVENANCE.json`, `PACKAGE-FILES.sha256`, root `extension.json` integrity map.
- Produce: `Titan-Governance-v0.7.0-Pass6-Control-Centre-Model-Compliance-Health-Cumulative.zip` and certification JSON/SHA256.

**Interfaces:**
- Final artifact must be flat-root Installer 1.7.8 package.

- [ ] Run all standalone contract tests.
- [ ] Run all PHP lint and JSON parse checks.
- [ ] Run Blueprint v4.2.2 manifest/package/architecture/MySQL/migration gates.
- [ ] Regenerate SBOM/provenance/inventories and installer integrity.
- [ ] Build ZIP, fresh-extract, rerun all gates from packaged bytes.
- [ ] Generate machine-readable certification with host certification explicitly NOT_RUN.
