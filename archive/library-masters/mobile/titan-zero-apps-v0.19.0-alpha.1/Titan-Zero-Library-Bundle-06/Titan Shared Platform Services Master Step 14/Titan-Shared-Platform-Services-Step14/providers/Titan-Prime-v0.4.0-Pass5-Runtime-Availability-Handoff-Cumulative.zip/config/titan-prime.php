<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'queue' => 'titan-prime',
    'tenant_key' => 'company_id',
    'legacy_tenant_key' => 'tenant_company_id',
    'idempotency_ttl_seconds' => 86400,
    'engine_gateways' => [
        'default_policy' => 'fail-closed',
        'orchestration_enabled' => false,
        'bridge_contract' => App\Extensions\TitanPrime\System\Gateways\Contracts\EngineBridgeContract::class,
    ],
];
