<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssurance\System\Services\Assurance\Integration;

use App\Extensions\TitanAutonomy\System\Contracts\TenantAssuranceBridgeContract;

final class TitanAutonomyTenantAssuranceBridge implements TenantAssuranceBridgeContract
{
    public function __construct(
        private readonly LatestEvidenceAssessmentResolver $resolver,
        private readonly AutonomyAssuranceProjectionService $projection,
    ) {
    }

    public function evaluateForTenant(
        int $tenantCompanyId,
        string $capability,
        ?string $workflowKey,
        array $context,
    ): array {
        if ($tenantCompanyId <= 0) {
            return $this->projection->unavailable('INVALID_TRUSTED_TENANT');
        }

        $assessment = $this->resolver->resolve((string) $tenantCompanyId, $capability, $workflowKey, $context);
        if ($assessment === null) {
            return $this->projection->unavailable('EVIDENCE_ASSURANCE_ASSESSMENT_REQUIRED');
        }

        return $this->projection->project($this->resolver->toProjectionInput($assessment));
    }
}
