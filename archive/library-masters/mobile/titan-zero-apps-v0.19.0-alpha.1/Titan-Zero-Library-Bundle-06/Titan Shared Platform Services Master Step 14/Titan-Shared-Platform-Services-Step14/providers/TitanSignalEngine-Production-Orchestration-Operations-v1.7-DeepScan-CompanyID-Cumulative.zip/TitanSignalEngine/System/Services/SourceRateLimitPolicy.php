<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Data\SignalRateLimitDecision;
use InvalidArgumentException;

final readonly class SourceRateLimitPolicy
{
    public function __construct(
        private int $defaultPerMinute,
        private int $systemPerMinute,
        private float $degradedMultiplier,
    ) {
        if ($defaultPerMinute < 1 || $systemPerMinute < 1 || $degradedMultiplier <= 0 || $degradedMultiplier > 1) {
            throw new InvalidArgumentException('Invalid source rate-limit policy.');
        }
    }

    public function decide(string $scope, int $observedCount, bool $backpressured): SignalRateLimitDecision
    {
        if (! in_array($scope, ['tenant', 'system'], true) || $observedCount < 0) {
            throw new InvalidArgumentException('Invalid source rate-limit inputs.');
        }
        $base = $scope === 'system' ? $this->systemPerMinute : $this->defaultPerMinute;
        $effective = $backpressured ? max(1, (int) floor($base * $this->degradedMultiplier)) : $base;
        return new SignalRateLimitDecision($observedCount < $effective, $effective, $observedCount, $backpressured);
    }
}
