<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\GateEvaluation;
use App\Extensions\TitanAutonomy\System\DTOs\LevelActivationResult;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\HandshakeDecision;

final class LevelActivationService
{
    public function activate(
        CapabilityState $state,
        AutonomyLevel $requestedLevel,
        GateEvaluation $gate,
        bool $actorCanGrant,
        HandshakeDecision $userDecision,
        HandshakeDecision $aiAssuranceDecision,
        array $scope,
    ): LevelActivationResult {
        $reasons = [];

        if ($requestedLevel !== $state->currentLevel->next()) {
            $reasons[] = 'INVALID_NEXT_LEVEL';
        }
        if (!$gate->eligible) {
            $reasons[] = 'PLATFORM_GATE_DENIED';
            $reasons = array_merge($reasons, $gate->reasonCodes);
        }
        if (!$actorCanGrant) {
            $reasons[] = 'ACTOR_NOT_AUTHORISED';
        }
        if ($userDecision !== HandshakeDecision::Approved) {
            $reasons[] = $userDecision === HandshakeDecision::Pending ? 'USER_APPROVAL_PENDING' : 'USER_DENIED';
        }

        if ($requestedLevel->value >= AutonomyLevel::SemiAuto->value && $scope === []) {
            $reasons[] = 'BOUNDED_SCOPE_REQUIRED';
        }

        if ($requestedLevel === AutonomyLevel::TrustedAuto) {
            if ($aiAssuranceDecision !== HandshakeDecision::Approved) {
                $reasons[] = $aiAssuranceDecision === HandshakeDecision::Pending
                    ? 'AI_ASSURANCE_PENDING'
                    : 'AI_ASSURANCE_DENIED';
            }
        }

        $reasons = array_values(array_unique($reasons));
        if ($reasons !== []) {
            return new LevelActivationResult(false, $state, $reasons);
        }

        $activated = new CapabilityState(
            tenantCompanyId: $state->tenantCompanyId,
            capability: $state->capability,
            workflowKey: $state->workflowKey,
            risk: $state->risk,
            currentLevel: $requestedLevel,
            requiredSuccessStreak: $state->requiredSuccessStreak,
            currentSuccessStreak: 0,
            highestSuccessStreak: $state->highestSuccessStreak,
            totalSuccesses: $state->totalSuccesses,
            totalFailures: $state->totalFailures,
            totalEdits: $state->totalEdits,
            totalRejections: $state->totalRejections,
            totalReversals: $state->totalReversals,
            platformGateEligible: false,
            scope: $scope,
            lastSuccessAt: $state->lastSuccessAt,
            lastFailureAt: $state->lastFailureAt,
        );

        return new LevelActivationResult(true, $activated, []);
    }
}
