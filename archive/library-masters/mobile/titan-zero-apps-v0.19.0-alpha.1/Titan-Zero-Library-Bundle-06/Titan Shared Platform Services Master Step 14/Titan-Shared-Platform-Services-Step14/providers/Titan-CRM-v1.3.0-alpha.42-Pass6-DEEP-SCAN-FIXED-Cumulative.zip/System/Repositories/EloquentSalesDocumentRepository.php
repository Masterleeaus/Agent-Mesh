<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Repositories;

use App\Extensions\Crm\System\Contracts\SalesDocumentRepositoryContract;
use App\Extensions\Crm\System\Services\{SalesDocumentContractSnapshotService,SalesDocumentLifecycleService,SalesTotalsCalculator};
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use DomainException;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class EloquentSalesDocumentRepository implements SalesDocumentRepositoryContract
{
    private const TYPES=['proposals','estimates','invoices'];

    public function __construct(
        private readonly ConnectionInterface $db,
        private readonly SalesDocumentLifecycleService $lifecycle,
        private readonly SalesTotalsCalculator $totals,
        private readonly SalesDocumentContractSnapshotService $contractSnapshots,
    ) {}

    private function table(string $type): string
    {
        if(!in_array($type,self::TYPES,true))throw new InvalidArgumentException('Unsupported sales document type.');
        return 'crm_'.$type;
    }

    public function search(int $userId,string $type,array $filters=[]): array
    {
        $q=$this->db->table($this->table($type))->where('company_id',CrmCompanyScope::companyId($userId))->whereNull('deleted_at');
        if($v=$filters['status']??null)$q->where('status',$v);
        if(isset($filters['revision_root_public_id']))$q->where('revision_root_public_id',(string)$filters['revision_root_public_id']);
        return $q->orderByDesc('id')->limit(min((int)($filters['limit']??100),250))->get()->map(fn($r)=>(array)$r)->all();
    }

    public function create(int $userId,string $type,array $data): array
    {
        $table=$this->table($type);
        return $this->db->transaction(function()use($userId,$type,$data,$table):array{
            if($type==='invoices')$data=$this->prepareInvoiceData($userId,$data);
            $calc=null;
            if(isset($data['lines']))$calc=$this->totals->calculate((array)$data['lines']);
            $subtotal=(int)($calc['subtotal_minor']??$data['subtotal_minor']??0);
            $tax=(int)($calc['tax_minor']??$data['tax_minor']??0);
            $total=(int)($calc['total_minor']??$data['total_minor']??($subtotal+$tax));
            $status=$data['status']??'draft';
            if(in_array($type,['proposals','estimates'],true)&&$status!=='draft')throw new DomainException('Quotes and estimates must be created as drafts and issued through a lifecycle transition.');
            if($type==='invoices'&&$status!=='draft')throw new DomainException('Invoices must be created as drafts and issued through crm.invoice.issue.');
            $publicId=(string)Str::ulid();
            $currency=strtoupper((string)($data['currency']??'AUD'));
            $payload=[
                'public_id'=>$publicId,'company_id'=>CrmCompanyScope::companyId($userId),'user_id'=>CrmCompanyScope::actorUserId($userId),
                'company_public_id'=>$data['company_public_id']??null,'contact_public_id'=>$data['contact_public_id']??null,'number'=>$data['number']??null,
                'title'=>$data['title']??ucfirst(rtrim($type,'s')),'status'=>$status,'currency'=>$currency,'subtotal_minor'=>$subtotal,'tax_minor'=>$tax,'total_minor'=>$total,
                'balance_minor'=>$type==='invoices'?$total:0,'due_at'=>$data['due_at']??null,'meta'=>$this->json($data['meta']??[]),'created_at'=>now(),'updated_at'=>now(),
            ];
            if(in_array($type,['proposals','estimates'],true)){
                $payload+=[
                    'expires_at'=>$data['expires_at']??null,'snapshot_version'=>(string)($data['snapshot_version']??'2.0'),
                    'pricing_rules_version'=>$data['pricing_rules_version']??(($data['pricing_rule_snapshot']??[])!==[]?'snapshot-'.substr(hash('sha256',$this->json($data['pricing_rule_snapshot'])),0,16):'manual-v1'),'pricing_rule_snapshot'=>$this->json($data['pricing_rule_snapshot']??[]),
                    'tax_rule_snapshot'=>$this->json($data['tax_rule_snapshot']??[]),'terms_snapshot'=>$this->json($data['terms_snapshot']??[]),
                    'service_definition_snapshot'=>$this->json($data['service_definition_snapshot']??[]),'discount_snapshot'=>$this->json($data['discount_snapshot']??[]),
                    'currency_snapshot'=>$this->json($data['currency_snapshot']??['currency'=>$currency]),'line_item_snapshot'=>$this->json($calc['lines']??[]),
                    'revision_root_public_id'=>$data['revision_root_public_id']??$publicId,'revision_number'=>(int)($data['revision_number']??1),
                    'supersedes_public_id'=>$data['supersedes_public_id']??null,'document_generation_status'=>'none',
                ];
            }
            if($type==='invoices'){
                $payload+=[
                    'source_quote_public_id'=>$data['source_quote_public_id']??null,'source_quote_snapshot_hash'=>$data['source_quote_snapshot_hash']??null,
                    'source_quote_revision_root_public_id'=>$data['source_quote_revision_root_public_id']??null,
                    'source_work_order_public_id'=>$data['source_work_order_public_id']??($data['work_order_public_id']??null),
                    'invoice_contract_version'=>'1.0','credited_minor'=>0,'refunded_minor'=>0,'receivable_state'=>'draft',
                    'lineage_meta'=>$this->json((array)($data['lineage_meta']??[])),'document_generation_status'=>'none',
                ];
            }
            $payload['snapshot_hash']=$this->stateHash($payload);
            $id=$this->db->table($table)->insertGetId($payload);
            if($calc!==null){
                foreach($calc['lines'] as $i=>$line){
                    $this->db->table('crm_sales_document_lines')->insert([
                        'company_id'=>CrmCompanyScope::companyId($userId),'user_id'=>CrmCompanyScope::actorUserId($userId),'document_type'=>$type,'document_public_id'=>$publicId,
                        'sequence'=>$i+1,'description'=>$line['description'],'quantity_milli'=>$line['quantity_milli'],'unit_price_minor'=>$line['unit_price_minor'],'tax_rate_bps'=>$line['tax_rate_bps'],
                        'line_subtotal_minor'=>$line['line_subtotal_minor'],'line_tax_minor'=>$line['line_tax_minor'],'line_total_minor'=>$line['line_total_minor'],'meta'=>$this->json($line['meta']??[]),'created_at'=>now(),'updated_at'=>now(),
                    ]);
                }
            }
            return $this->withLines($userId,$type,(array)$this->db->table($table)->where('id',$id)->first());
        });
    }

    public function transition(int $userId,string $type,string $publicId,string $toStatus,array $context=[]): array
    {
        $table=$this->table($type);
        return $this->db->transaction(function()use($userId,$type,$publicId,$toStatus,$context,$table):array{
            $tenant=CrmCompanyScope::companyId($userId);
            $row=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->lockForUpdate()->first();
            if(!$row)abort(404,'Sales document not found.');
            $from=(string)$row->status;
            $this->lifecycle->assertNotExpired($type,$row,$toStatus);
            $this->lifecycle->assertTransition($type,$from,$toStatus);
            $update=['status'=>$toStatus,'updated_at'=>now()];
            $supersededPredecessor=null;
            if($type==='invoices'&&$toStatus==='sent')$update['sent_at']=now();
            elseif($type==='invoices'&&$toStatus==='viewed')$update['viewed_at']=now();
            elseif($col=$this->lifecycle->timestampColumn($toStatus))$update[$col]=now();

            if(in_array($type,['proposals','estimates'],true)){
                if($toStatus==='sent'){
                    if(!empty($row->issued_snapshot_hash))throw new DomainException('An issued commercial snapshot is immutable; create a revision instead of reissuing this record.');
                    $contract=$this->contractSnapshots->build($tenant,$type,$row);
                    $update['issued_snapshot']=$this->json($contract['snapshot']);
                    $update['issued_snapshot_hash']=$contract['hash'];
                    $update['line_item_snapshot']=$this->json($contract['lines']);
                    $update['snapshot_version']='2.0';
                    $update['document_generation_status']='none';
                    $update['document_generation_error']=null;
                    $supersededPredecessor=$this->supersedePredecessorIfRequired($tenant,$type,$row,$publicId);
                }
                if($toStatus==='accepted'){
                    if(empty($row->issued_snapshot_hash))throw new DomainException('A quote cannot be accepted without an immutable issued snapshot.');
                    $evidence=$this->acceptanceEvidence($userId,$publicId,(string)$row->issued_snapshot_hash,$context);
                    $update['accepted_by_actor_id']=CrmCompanyScope::actorUserId($userId);
                    $update['accepted_via']=$evidence['source'];
                    $update['accepted_actor_type']=$evidence['actor_type'];
                    $update['accepted_actor_reference']=$evidence['actor_reference'];
                    $update['acceptance_session_id']=$evidence['session_hash'];
                    $update['acceptance_evidence']=$this->json($evidence);
                    $update['acceptance_hash']=$this->contractSnapshots->hashEvidence($evidence);
                }
            }

            if($type==='invoices'){
                if($toStatus==='issued'){
                    if(!empty($row->issued_snapshot_hash))throw new DomainException('An issued invoice contract is immutable and cannot be reissued.');
                    $contract=$this->contractSnapshots->build($tenant,'invoices',$row);
                    $update['issued_snapshot']=$this->json($contract['snapshot']);$update['issued_snapshot_hash']=$contract['hash'];$update['invoice_contract_version']='1.0';$update['receivable_state']='open';
                }
                if($toStatus==='void'){
                    if((int)($row->paid_minor??0)>0||(int)($row->credited_minor??0)>0||(int)($row->refunded_minor??0)>0)throw new DomainException('An invoice with settlement or credit activity cannot be voided; use a credit/refund correction path.');
                    $update['balance_minor']=0;$update['payment_state']='unpaid';$update['receivable_state']='void';$update['void_reason']=$context['reason']??null;$update['voided_by_user_id']=CrmCompanyScope::actorUserId($userId);
                }
            }
            $update['snapshot_hash']=$this->stateHash(array_merge((array)$row,$update));
            $this->db->table($table)->where('id',$row->id)->update($update);
            $result=$this->withLines($userId,$type,(array)$this->db->table($table)->where('id',$row->id)->first());
            if($supersededPredecessor!==null)$result['superseded_predecessor_public_id']=$supersededPredecessor;
            return $result;
        });
    }

    private function supersedePredecessorIfRequired(int $tenant,string $type,object $row,string $currentPublicId): ?string
    {
        $previous=trim((string)($row->supersedes_public_id??''));if($previous==='')return null;
        $table='crm_'.$type;
        $source=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$previous)->whereNull('deleted_at')->lockForUpdate()->first();
        if(!$source)throw new DomainException('The revision predecessor no longer exists.');
        if((string)$source->status==='accepted')throw new DomainException('Accepted quotes cannot be superseded.');
        if((string)$source->status==='superseded'&&$source->superseded_by_public_id!==$currentPublicId)throw new DomainException('The predecessor has already been superseded by another revision.');
        if((string)$source->status!=='superseded'){
            $now=now();$update=['status'=>'superseded','superseded_by_public_id'=>$currentPublicId,'superseded_at'=>$now,'updated_at'=>$now];
            if(property_exists($source,'entity_version'))$update['entity_version']=(int)$source->entity_version+1;
            $update['snapshot_hash']=$this->stateHash(array_merge((array)$source,$update));
            $this->db->table($table)->where('id',$source->id)->update($update);
        }
        return $previous;
    }

    private function acceptanceEvidence(int $userId,string $publicId,string $issuedHash,array $context): array
    {
        $session=(string)($context['acceptance_session_id']??$context['session_id']??($context['_context']['session_id']??''));
        return [
            'schema'=>'crm.quote-acceptance.v1','document_public_id'=>$publicId,'issued_snapshot_hash'=>$issuedHash,
            'accepted_at'=>now()->toIso8601String(),'actor_user_id'=>CrmCompanyScope::actorUserId($userId),
            'source'=>(string)($context['accepted_via']??$context['source']??($context['_context']['source']??'governed_crm')),
            'actor_type'=>(string)($context['accepted_actor_type']??(in_array((string)($context['accepted_via']??''),['customer_portal','titan_hub'],true)?'customer':'user')),
            'actor_reference'=>$context['accepted_actor_reference']??$context['customer_identity_reference']??null,
            'session_hash'=>$session!==''?hash('sha256',$session):null,
            'portal_grant_public_id'=>$context['portal_grant_public_id']??null,
            'customer_identity_reference'=>$context['customer_identity_reference']??null,
        ];
    }

    private function withLines(int $userId,string $type,array $record): array
    {
        $record['lines']=$this->db->table('crm_sales_document_lines')->where('company_id',CrmCompanyScope::companyId($userId))->where('document_type',$type)->where('document_public_id',$record['public_id'])->orderBy('sequence')->get()->map(fn($r)=>(array)$r)->all();
        return $record;
    }

    private function prepareInvoiceData(int $userId,array $data): array
    {
        $tenant=CrmCompanyScope::companyId($userId);$quoteId=trim((string)($data['source_quote_public_id']??''));
        if($quoteId==='')return $data;
        $found=null;$foundType=null;
        foreach(['estimates','proposals'] as $quoteType){$row=$this->db->table('crm_'.$quoteType)->where('company_id',$tenant)->where('public_id',$quoteId)->whereNull('deleted_at')->first();if($row){$found=$row;$foundType=$quoteType;break;}}
        if(!$found)throw new DomainException('Source quote does not exist in the active tenant.');
        if((string)$found->status!=='accepted')throw new DomainException('Invoices linked to a quote require an accepted quote revision.');
        if(empty($found->issued_snapshot_hash))throw new DomainException('Source quote is missing immutable issued contract evidence.');
        $data['company_public_id']=$data['company_public_id']??$found->company_public_id;$data['contact_public_id']=$data['contact_public_id']??$found->contact_public_id;$data['currency']=$data['currency']??$found->currency;
        $data['source_quote_snapshot_hash']=(string)$found->issued_snapshot_hash;$data['source_quote_revision_root_public_id']=(string)($found->revision_root_public_id?:$found->public_id);
        $data['lineage_meta']=array_merge((array)($data['lineage_meta']??[]),['source_quote_type'=>$foundType,'source_quote_revision_number'=>(int)($found->revision_number??1)]);
        if(!isset($data['lines']))$data['lines']=$this->db->table('crm_sales_document_lines')->where('company_id',$tenant)->where('document_type',$foundType)->where('document_public_id',$quoteId)->orderBy('sequence')->get()->map(fn($l)=>['description'=>$l->description,'quantity_milli'=>(int)$l->quantity_milli,'unit_price_minor'=>(int)$l->unit_price_minor,'tax_rate_bps'=>(int)$l->tax_rate_bps,'meta'=>$this->decodeJson($l->meta??null)])->all();
        return $data;
    }

    private function decodeJson(mixed $value): mixed { if(is_array($value)||$value===null)return $value;if(is_string($value)){ $decoded=json_decode($value,true);if(json_last_error()===JSON_ERROR_NONE)return $decoded;}return $value; }

    private function stateHash(array $payload): string { unset($payload['snapshot_hash']);return hash('sha256',(string)json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)); }
    private function json(mixed $v): string { return (string)json_encode($v,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR); }
}
