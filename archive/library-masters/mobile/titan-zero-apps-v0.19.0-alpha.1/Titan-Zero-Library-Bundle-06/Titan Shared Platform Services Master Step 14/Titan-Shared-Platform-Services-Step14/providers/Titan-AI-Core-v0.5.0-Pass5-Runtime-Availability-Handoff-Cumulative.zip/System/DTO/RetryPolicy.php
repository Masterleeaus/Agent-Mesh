<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class RetryPolicy { public function __construct(public int $maxAttempts = 1, public string $backoff = 'none', public int $baseDelayMs = 0) { if ($maxAttempts < 1) throw new \InvalidArgumentException('maxAttempts must be >= 1'); } public function toArray(): array { return ['max_attempts'=>$this->maxAttempts,'backoff'=>$this->backoff,'base_delay_ms'=>$this->baseDelayMs]; } }
