<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\Governance\CrmCommandBusGateway;
use App\Extensions\Crm\System\Tenancy\{CrmCompanyContext,CrmCompanyScope};
use Illuminate\Console\Command;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

final class RunCrmRetentionCommand extends Command
{
    protected $signature = 'crm:retention:run {--company=} {--resource=} {--limit=100} {--confirm-destructive}';
    protected $description = 'Review or request governed execution of due CRM retention policies.';

    public function handle(CrmCommandBusGateway $commands,CrmCompanyScope $scope,ConnectionInterface $db): int
    {
        $query=$db->table('crm_retention_policies')->where('enabled',true);
        if($this->option('company')!==null)$query->where('company_id',(int)$this->option('company'));
        if($this->option('resource')!==null)$query->where('resource_type',(string)$this->option('resource'));
        $policies=$query->orderBy('company_id')->orderBy('resource_type')->get(['company_id','user_id','resource_type','action']);
        $total=0;
        foreach($policies as $policy){
            $correlation=(string)Str::uuid();
            $context=new CrmCompanyContext(
                companyId:(int)$policy->company_id,
                actorUserId:(int)$policy->user_id,
                actorType:'user',
                roles:['system_retention'],
                permissions:['crm.privacy.manage'],
                authenticatedCompanyMembership:true,
                correlationId:$correlation,
                sourceSurface:'scheduler',
                traceId:$correlation,
                causationId:null,
            );
            $envelope=$scope->runWith($context,fn()=> $commands->request('crm.retention.execute',[
                'resource_type'=>(string)$policy->resource_type,
                'limit'=>(int)$this->option('limit'),
                'confirmed'=>(bool)$this->option('confirm-destructive'),
                'idempotency_key'=>'retention:'.(int)$policy->company_id.':'.(string)$policy->resource_type.':'.now()->format('Y-m-d'),
            ],'scheduler'));
            $result=(array)($envelope['result']??[]);
            $processed=(int)($result['processed']??0);$total+=$processed;
            $this->line((int)$policy->company_id.':'.(string)$policy->resource_type.' status='.(string)($envelope['status']??'unknown').' processed='.$processed);
        }
        $this->info("CRM retention records processed through governed execution: {$total}");
        return self::SUCCESS;
    }
}
