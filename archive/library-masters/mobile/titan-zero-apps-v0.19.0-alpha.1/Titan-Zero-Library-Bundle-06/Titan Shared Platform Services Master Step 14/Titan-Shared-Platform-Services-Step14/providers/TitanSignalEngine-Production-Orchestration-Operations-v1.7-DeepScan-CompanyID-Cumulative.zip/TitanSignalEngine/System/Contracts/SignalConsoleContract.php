<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalConsoleRequest;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;

interface SignalConsoleContract
{
    /** @return array<string,mixed> */
    public function surface(SignalConsoleRequest $request, SignalContext $context): array;

    /** @return array<string,mixed> */
    public function dashboard(SignalConsoleRequest $request, SignalContext $context, bool $administrative = false): array;

    /** @return array<string,mixed> */
    public function trace(string $traceId, SignalConsoleRequest $request, SignalContext $context, ?string $profileKey = null, ?int $profileVersion = null): array;

    /** @return array<string,mixed> */
    public function workflow(string $correlationId, SignalConsoleRequest $request, SignalContext $context): array;

    /** @return array<string,mixed>|null */
    public function event(string $eventId, SignalConsoleRequest $request, SignalContext $context): ?array;
}
