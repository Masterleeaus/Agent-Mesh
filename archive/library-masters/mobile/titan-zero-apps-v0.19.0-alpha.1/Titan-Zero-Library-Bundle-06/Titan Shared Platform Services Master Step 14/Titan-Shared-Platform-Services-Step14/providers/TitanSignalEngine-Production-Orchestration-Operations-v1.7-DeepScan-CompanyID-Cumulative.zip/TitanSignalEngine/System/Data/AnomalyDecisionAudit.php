<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use DateTimeInterface;
use InvalidArgumentException;

final readonly class AnomalyDecisionAudit
{
    /** @param array<string,mixed> $payload */
    private function __construct(
        public string $action,
        public string $eventType,
        public array $payload,
        public string $idempotencyKey,
    ) {
    }

    public static function make(
        string $action,
        string $anomalyId,
        string $anomalyType,
        string $subjectType,
        string $subjectId,
        string $reason,
        string $actorId,
        string $actorType,
        int $decisionVersion,
        DateTimeInterface $decidedAt,
        ?DateTimeInterface $suppressionUntil = null,
        ?string $evidenceReference = null,
    ): self {
        $action = strtolower(trim($action));
        if (! in_array($action, ['acknowledged', 'suppressed', 'resolved', 'reopened'], true)) {
            throw new InvalidArgumentException('Unsupported Signal anomaly lifecycle action.');
        }
        foreach (['anomaly_id' => $anomalyId, 'anomaly_type' => $anomalyType, 'subject_type' => $subjectType, 'subject_id' => $subjectId, 'reason' => $reason, 'actor_id' => $actorId, 'actor_type' => $actorType] as $name => $value) {
            if (trim($value) === '') throw new InvalidArgumentException("Anomaly audit {$name} must not be empty.");
        }
        if ($decisionVersion < 1) throw new InvalidArgumentException('Anomaly decision version must be positive.');
        if ($action === 'suppressed' && $suppressionUntil === null) {
            throw new InvalidArgumentException('Suppressed anomaly audit requires suppression_until.');
        }
        if ($action !== 'suppressed' && $suppressionUntil !== null) {
            throw new InvalidArgumentException('suppression_until is only valid for suppressed anomaly audit events.');
        }

        $payload = [
            'anomaly_id' => $anomalyId,
            'anomaly_type' => $anomalyType,
            'subject_type' => $subjectType,
            'subject_id' => $subjectId,
            'decision_version' => $decisionVersion,
            'reason' => trim($reason),
            'actor_id' => $actorId,
            'actor_type' => $actorType,
            'decided_at' => $decidedAt->format(DATE_ATOM),
            'evidence_reference' => $evidenceReference,
            'suppression_until' => $suppressionUntil?->format(DATE_ATOM),
        ];

        return new self(
            $action,
            'signal.anomaly.' . $action,
            $payload,
            'anomaly-decision:' . $anomalyId . ':' . $decisionVersion . ':' . $action,
        );
    }

    /** @param array<string,mixed> $evidence */
    public static function evidenceReference(array $evidence): string
    {
        $normalized = self::normalize($evidence);
        return 'sha256:' . hash('sha256', json_encode($normalized, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    private static function normalize(mixed $value): mixed
    {
        if (! is_array($value)) return $value;
        if (! array_is_list($value)) ksort($value);
        foreach ($value as $key => $item) $value[$key] = self::normalize($item);
        return $value;
    }
}
