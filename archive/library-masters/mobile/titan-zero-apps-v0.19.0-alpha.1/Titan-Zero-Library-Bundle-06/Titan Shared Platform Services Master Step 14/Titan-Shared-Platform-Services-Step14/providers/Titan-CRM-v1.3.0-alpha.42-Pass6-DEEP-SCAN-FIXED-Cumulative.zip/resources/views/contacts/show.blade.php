@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',[
    'title'=>trim(($contact['first_name'] ?? '').' '.($contact['last_name'] ?? '')),
    'subtitle'=>$contact['role'] ?? 'Contact',
    'surface'=>'customers',
    'journey'=>'new-job',
    'secondaryJourneys'=>['new-quote','new-support-case'],
    'recordType'=>'contact',
    'context'=>array_filter(['record_type'=>'contact','public_id'=>$contact['public_id'],'contact_public_id'=>$contact['public_id'],'company_public_id'=>$company['public_id'] ?? null]),
])
<div class="d-flex justify-content-between align-items-center mb-4"><a href="{{ route('dashboard.user.crm.contacts.index') }}" class="small">← Contacts</a><a class="btn btn-outline-primary" href="{{ route('dashboard.user.crm.timeline.show',['contact',$contact['public_id']]) }}">Timeline</a></div>
@if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif
<div class="row g-4">
    <div class="col-lg-5"><div class="card mb-4"><div class="card-body"><dl class="mb-0"><dt>Email</dt><dd>{{ $contact['email'] ?? '—' }}</dd><dt>Phone</dt><dd>{{ $contact['phone'] ?? '—' }}</dd><dt>Company</dt><dd>@if($company)<a href="{{ route('dashboard.user.crm.companies.show',$company['public_id']) }}">{{ $company['name'] }}</a>@else — @endif</dd></dl></div></div>
        <div class="card"><div class="card-header"><strong>Edit contact</strong></div><div class="card-body"><form method="post" action="{{ route('dashboard.user.crm.contacts.update',$contact['public_id']) }}" class="row g-3">@csrf @method('PATCH')<div class="col-md-6"><label class="form-label">First name</label><input class="form-control" name="first_name" required value="{{ $contact['first_name'] }}"></div><div class="col-md-6"><label class="form-label">Last name</label><input class="form-control" name="last_name" value="{{ $contact['last_name'] ?? '' }}"></div><div class="col-12"><label class="form-label">Role</label><input class="form-control" name="role" value="{{ $contact['role'] ?? '' }}"></div><div class="col-12"><label class="form-label">Email</label><input class="form-control" type="email" name="email" value="{{ $contact['email'] ?? '' }}"></div><div class="col-12"><label class="form-label">Phone</label><input class="form-control" name="phone" value="{{ $contact['phone'] ?? '' }}"></div><div class="col-12"><div class="form-check"><input type="hidden" name="is_primary" value="0"><input class="form-check-input" type="checkbox" name="is_primary" value="1" id="isPrimary" @checked($contact['is_primary'] ?? false)><label class="form-check-label" for="isPrimary">Primary contact</label></div></div><div class="col-12"><button class="btn btn-primary">Save contact</button></div></form></div></div>
    </div>
    <div class="col-lg-7"><div class="card"><div class="card-header"><strong>Recent timeline</strong></div><ul class="list-group list-group-flush">@forelse(array_slice($timeline,0,12) as $item)<li class="list-group-item"><span class="badge text-bg-light">{{ ucfirst($item['kind']) }}</span> {{ $item['record']['summary'] ?? $item['record']['body'] ?? $item['record']['description'] ?? '' }}<div class="small text-muted">{{ $item['occurred_at'] }}</div></li>@empty<li class="list-group-item text-muted">No timeline entries.</li>@endforelse</ul></div></div>
</div>
@endcomponent
@endsection
