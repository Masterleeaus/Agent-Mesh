<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalActor
{
    public function __construct(
        public string $id,
        public string $type,
        public ?int $tenantCompanyId = null,
        public ?string $identityProvider = null,
        public ?string $sessionId = null,
    ) {
        if (trim($this->id) === '' || strlen($this->id) > 191) {
            throw new InvalidArgumentException('Signal actor id must be 1-191 characters.');
        }
        if ($this->type === '' || strlen($this->type) > 80 || ! preg_match('/^[a-z0-9._-]+$/', $this->type)) {
            throw new InvalidArgumentException('Signal actor type must be a non-empty lowercase slug.');
        }
        if ($this->identityProvider !== null && (trim($this->identityProvider) === '' || strlen($this->identityProvider) > 80)) {
            throw new InvalidArgumentException('Signal actor identity provider must be 1-80 characters when present.');
        }
        if ($this->sessionId !== null && (trim($this->sessionId) === '' || strlen($this->sessionId) > 191)) {
            throw new InvalidArgumentException('Signal actor session id must be 1-191 characters when present.');
        }
        if ($this->tenantCompanyId !== null && $this->tenantCompanyId < 1) {
            throw new InvalidArgumentException('Signal actor tenant_company_id must be a positive integer.');
        }
    }

    /** @param array<string,mixed> $data */
    public static function fromArray(array $data): self
    {
        $id = trim((string) ($data['id'] ?? ''));
        $type = strtolower(trim((string) ($data['type'] ?? '')));
        $tenant = $data['tenant_company_id'] ?? null;
        $tenant = $tenant === null || $tenant === '' ? null : (int) $tenant;
        $provider = self::nullableString($data['identity_provider'] ?? null, 80);
        $session = self::nullableString($data['session_id'] ?? null, 191);

        return new self($id, $type, $tenant, $provider, $session);
    }

    /** @return array{id:string,type:string,tenant_company_id:?int,identity_provider:?string,session_id:?string} */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'type' => $this->type,
            'tenant_company_id' => $this->tenantCompanyId,
            'identity_provider' => $this->identityProvider,
            'session_id' => $this->sessionId,
        ];
    }

    private static function nullableString(mixed $value, int $max): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        $value = trim((string) $value);
        if ($value === '' || strlen($value) > $max) {
            throw new InvalidArgumentException('Invalid signal actor string field.');
        }

        return $value;
    }
}
