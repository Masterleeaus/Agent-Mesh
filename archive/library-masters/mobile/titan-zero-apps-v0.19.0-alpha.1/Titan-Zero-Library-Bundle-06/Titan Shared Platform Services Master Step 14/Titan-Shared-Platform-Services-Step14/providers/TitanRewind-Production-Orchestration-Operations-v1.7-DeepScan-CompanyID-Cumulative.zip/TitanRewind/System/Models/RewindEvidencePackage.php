<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindEvidencePackage extends Model
{
    protected $table = 'titan_rewind_evidence_packages';
    protected $fillable = [
        'package_uuid','package_key','tenant_company_id','scope_type','scope_id','case_id','trace_id','package_type','status','source_completeness','content_hash','signature_algorithm','signature_key_id','signature','signed_at',
        'manifest','payload_json','integrity_check_uuid','generated_at','generated_by_id','supersedes_package_uuid',
    ];
    protected $casts = [
        'tenant_company_id'=>'integer','case_id'=>'integer','manifest'=>'array','generated_at'=>'datetime','generated_by_id'=>'integer','signed_at'=>'datetime',
    ];
}
