<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use Illuminate\Validation\ValidationException;

final class SensitivePayloadGuard
{
    private const SENSITIVE_KEYS = [
        'secret', 'token', 'access_token', 'refresh_token', 'password', 'authorization',
        'credential', 'credentials', 'api_key', 'api_key_secret', 'apikey', 'bot_token',
        'auth_token', 'app_secret', 'webhook_secret', 'private_key', 'client_secret',
    ];

    public function assertSafe(array $payload, string $field = 'metadata'): void
    {
        $path = $this->findSensitivePath($payload);
        if ($path !== null) {
            throw ValidationException::withMessages([
                $field => sprintf('Sensitive credential material is not allowed in %s [%s].', $field, $path),
            ]);
        }
    }

    private function findSensitivePath(array $payload, string $prefix = ''): ?string
    {
        foreach ($payload as $key => $value) {
            $name = strtolower(str_replace('-', '_', (string) $key));
            $path = $prefix === '' ? (string) $key : $prefix.'.'.$key;
            foreach (self::SENSITIVE_KEYS as $needle) {
                if ($name === $needle || str_contains($name, $needle)) {
                    return $path;
                }
            }
            if (is_array($value)) {
                $nested = $this->findSensitivePath($value, $path);
                if ($nested !== null) {
                    return $nested;
                }
            }
        }
        return null;
    }
}
