<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$provider = @file_get_contents($root . '/System/TitanSignalEngineServiceProvider.php') ?: '';
$registrar = @file_get_contents($root . '/System/Navigation/HostNavigationRegistrar.php') ?: '';
$manifest = json_decode(@file_get_contents($root . '/extension.manifest.json') ?: '{}', true) ?: [];
$adminView = @file_get_contents($root . '/resources/views/admin.blade.php') ?: '';
$userView = @file_get_contents($root . '/resources/views/index.blade.php') ?: '';

$assert(! str_contains($adminView, '<x-layouts.app>'), 'admin view still uses missing x-layouts.app component');
$assert(! str_contains($userView, '<x-layouts.app>'), 'user view still uses missing x-layouts.app component');
$assert(str_starts_with(ltrim($adminView), "@extends('panel.layout.app')"), 'admin view must extend panel.layout.app');
$assert(str_starts_with(ltrim($userView), "@extends('panel.layout.app')"), 'user view must extend panel.layout.app for host-safe direct access');
$assert(str_contains($adminView, "@section('content')"), 'admin view missing content section');
$assert(str_contains($adminView, '@endsection'), 'admin view missing endsection');

$navigation = is_array($manifest['navigation'] ?? null) ? $manifest['navigation'] : [];
$userNavigation = is_array($navigation['user'] ?? null) ? $navigation['user'] : [];
$adminNavigation = is_array($navigation['admin'] ?? null) ? $navigation['admin'] : [];
$assert($userNavigation === [], 'Signal Engine must not advertise a user navigation contribution');
$assert($adminNavigation !== [], 'Signal Engine must advertise Super Admin navigation');

$assert(! str_contains($registrar, "'navigation.user'"), 'host registrar must not register Signal into the user menu');
$assert(str_contains($registrar, "'navigation.admin'"), 'host registrar missing admin contribution');
$assert(str_contains($registrar, "'extension' => '1'"), 'legacy Super Admin row must use host-compatible extension marker');
$assert(str_contains($provider, "'titan_signal_pulse'"), 'provider uninstall should still clean legacy user menu key');

$migrationFiles = glob($root . '/database/migrations/*super_admin*') ?: [];
$assert($migrationFiles !== [], 'missing rc.6 Super Admin placement migration');
if ($migrationFiles !== []) {
    $migration = @file_get_contents(end($migrationFiles)) ?: '';
    $assert(str_contains($migration, "where('key', 'titan_signal_pulse')->delete()"), 'upgrade migration must remove stale user menu row');
    $assert(str_contains($migration, "'titan_signal_engine_admin'"), 'upgrade migration must repair Super Admin row');
    $assert(str_contains($migration, "'extension' => '1'"), 'upgrade migration must use host-compatible Super Admin extension marker');
    $assert(str_contains($migration, "'order' => 995"), 'Super Admin row must remain in 900+ band');
}

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Signal Super Admin placement and Blade host compatibility\n";
