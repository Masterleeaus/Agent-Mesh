<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use RegexIterator;

final class BoundaryTest extends TestCase
{
    public function test_system_layer_has_no_direct_imports_from_other_titan_extensions(): void
    {
        $system = realpath(__DIR__ . '/../../System');
        self::assertNotFalse($system);

        $files = new RegexIterator(
            new RecursiveIteratorIterator(new RecursiveDirectoryIterator($system)),
            '/\.php$/i'
        );

        foreach ($files as $file) {
            $contents = file_get_contents($file->getPathname());
            self::assertIsString($contents);
            self::assertDoesNotMatchRegularExpression(
                '/use\s+App\\\\Extensions\\\\(?!TitanPrime\\\\)[A-Za-z0-9_]+\\\\/m',
                $contents,
                sprintf('Cross-extension implementation import found in %s', $file->getPathname())
            );
        }
    }

    public function test_domain_layer_does_not_use_laravel_or_database_facades(): void
    {
        $domain = realpath(__DIR__ . '/../../System/Domain');
        self::assertNotFalse($domain);

        $files = new RegexIterator(
            new RecursiveIteratorIterator(new RecursiveDirectoryIterator($domain)),
            '/\.php$/i'
        );

        foreach ($files as $file) {
            $contents = file_get_contents($file->getPathname());
            self::assertIsString($contents);
            self::assertStringNotContainsString('Illuminate\\', $contents);
            self::assertStringNotContainsString('DB::', $contents);
            self::assertStringNotContainsString('Schema::', $contents);
        }
    }
}
