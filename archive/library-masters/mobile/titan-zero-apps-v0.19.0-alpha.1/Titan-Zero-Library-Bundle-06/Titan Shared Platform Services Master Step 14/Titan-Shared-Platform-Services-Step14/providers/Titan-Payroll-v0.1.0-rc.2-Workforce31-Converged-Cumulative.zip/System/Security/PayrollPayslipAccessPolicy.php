<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Security;
final class PayrollPayslipAccessPolicy
{
    public function assertRecordAccess(int $tenantCompanyId,int $actorUserId,array|object $record):void
    {
        $tenant=(int)$this->value($record,'tenant_company_id');$worker=(string)$this->value($record,'worker_ref');
        if($tenant!==$tenantCompanyId)throw new \DomainException('Payslip tenant mismatch.');
        if(!in_array($worker,['user:'.$actorUserId,'worker:'.$actorUserId],true))throw new \DomainException('Payslip belongs to a different employee.');
    }
    public function assertGrant(array $claims,int $tenantCompanyId,int $actorUserId,int|string $payslipId,\DateTimeInterface $now):void
    {
        if((int)($claims['tenant_company_id']??0)!==$tenantCompanyId)throw new \DomainException('Payslip grant tenant mismatch.');
        if((int)($claims['employee_id']??0)!==$actorUserId)throw new \DomainException('Payslip grant employee mismatch.');
        if((string)($claims['payslip_id']??'')!==(string)$payslipId)throw new \DomainException('Payslip grant record mismatch.');
        $expires=(string)($claims['expires_at']??'');if($expires===''||new \DateTimeImmutable($expires)<=$now)throw new \DomainException('Payslip grant expired.');
        if(trim((string)($claims['jti']??''))==='')throw new \DomainException('Payslip grant identifier missing.');
    }
    private function value(array|object $record,string $key):mixed{return is_array($record)?($record[$key]??null):($record->{$key}??null);}
}
