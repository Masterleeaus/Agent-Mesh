# Titan Forge Changelog

## 0.9.0-alpha.1 — Rewind deterministic reconstruction

- Added Blueprint v4.2.1-native `titan-forge.rewind-source` contribution using the host-owned `RewindSourceAdapter` contract.
- Added tenant/trace-scoped Forge history reader with cursor-backed reads for build, plan, artifact, validation, Shield, Risk, Council, Governance, release-candidate and receipt evidence.
- Added deterministic streaming projection into canonical Rewind events with stable UUIDs, bounded payloads, SHA-256 source/integrity hashes and `previous_hash` chaining.
- Added reconstruction service that independently recomputes event integrity and reports source completeness separately from historical reproducibility.
- Added full build causal lineage to child forensic evidence without copying instructions, artifact contents, Council transcripts/final text or hidden reasoning.
- Declared `supports_as_of=false` truthfully because mutable Forge build rows do not yet support exact historical point-in-time reconstruction; current reconstruction is `PARTIALLY_REPRODUCIBLE`.
- Added authority-neutral/read-only `rewind-source` manifest contribution and optional Titan Rewind `>=1.0.0` dependency.
- Hardened long-trace behavior with streaming projection/watermark aggregation and wide deterministic sequence ranges.
- Preserved `deployment_authority: none`; Rewind reconstruction cannot mutate Forge or domain state.

## 0.8.0-alpha.1 — Selective governed Model Council review

- Upgraded Forge from Council activation assessment to Titan Model Council v0.7 governed deliberation for high/critical-risk release candidates.
- Added bounded Council release-review packets with no build instructions, request inputs or artifact contents.
- Added host-policy-controlled four-role model assignments with at least three distinct models; Forge does not perform dynamic model routing.
- Added sanitized Council review normalization: decision ID, confidence, participant count, final-answer hash, role-model hash, escalation and advisory execution authority only.
- Added durable `council.deliberation` Forge receipts using the existing `titan_forge_receipts` store; full Council transcripts remain Council-owned.
- Added fail-closed handling for unavailable governed deliberation, missing role-model policy, rejected/failed/escalated outcomes and any Council result claiming mutation authority.
- Raised optional `titan-model-council` compatibility floor to `>=0.7.0` and added `forge.council.deliberate`.
- Preserved `deployment_authority: none`; Model Council evidence never substitutes for Titan Governance or Command Bus authority.

## 0.7.0-alpha.1 — AI Core planning and sandboxed AI generation boundary

- Added Titan AI Core typed planning consumer and exact trusted-context verification.
- Added immutable AI plan provenance persistence.
- Added sandbox-only AI artifact proposal generation boundary with model/plan/hash provenance.
- Added AI generation-manifest provenance and hidden-reasoning rejection.
- Added optional `titan-ai-core >=0.3.0` dependency and Blueprint `ai-enabled` modifier.
- Preserved zero direct provider calls and `deployment_authority: none`.
- Current AI Core v0.3.0 remains planning-blocked by its own DAG validator and exposes no artifact-generation contract, so live AI generation remains fail-closed.

## 0.6.1-alpha.1 — Blueprint v4.2 rebase

- Rebased the governance sidecar to Titan Manifest v2.2 and the `builder-generator` production profile.
- Aligned the Installer 1.7.8 root manifest with the canonical Blueprint schema.
- Added `root_causation_id` through build context, queued payloads, durable build state and Signal envelopes.
- Added canonical Signal event schemas and `signal-aware` architecture metadata.
- Added production-inheritance metadata for health, observability, authorization, concurrency, resilience, rollout, disaster recovery, supply chain, service identity and navigation.
- Added the production documentation set required by Blueprint v4.2.
- Preserved the existing fail-closed Governance and Command Bus boundaries and `deployment_authority: none`.
- This release does not add AI generation, production signing or live-host certification.

## 0.6.0-alpha.1

- Added Signal, Risk and Shield adapters, selective Model Council activation assessment and persisted governed release candidates.
- Added fail-closed Governance and Command Bus release boundaries.

## Agent-06 Workforce Provider Migration

- Added fail-closed `workforce-integration.json` using canonical `company_id`.
- Workforce identity/roles/hierarchy remain owned by Titan AI Workforce; provider capabilities remain extension-owned.
- Converged package/manifest metadata toward Titan Extension Blueprint v4.2.1.

## 0.9.0-alpha.8 — Agent-06 Upgrade Pass 2
- Workforce provider contract v1.1 with per-capability operational policy metadata.
- Command-bus/receipt enforcement metadata for state-changing Workforce actions.
- Explicit provider health, degradation, idempotency, offline and provenance requirements.
- Standalone schema/contract consistency verification.
