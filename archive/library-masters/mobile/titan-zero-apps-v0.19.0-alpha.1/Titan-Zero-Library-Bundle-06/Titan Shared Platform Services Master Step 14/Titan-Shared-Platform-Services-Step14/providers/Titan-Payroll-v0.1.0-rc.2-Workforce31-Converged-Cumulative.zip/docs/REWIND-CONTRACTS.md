# Rewind Source Contract

`PayrollRewindSourceAdapter` contributes versioned source facts and watermarks. It never owns replay execution or stores a second copy of Rewind state. Sensitive payroll documents and raw banking/tax identifiers are excluded.
