<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Automation;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;

final class CrmAutomationScheduler
{
    public function __construct(private ConnectionInterface $db, private CrmAutomationEngine $engine) {}
    public function runForUser(int $userId): array
    {
        $results=[]; $now=now();
        foreach ($this->db->table('crm_tasks')->where('company_id', CrmCompanyScope::companyId($userId))->whereNotIn('status',['completed','cancelled'])->whereNotNull('due_at')->where('due_at','<',$now)->limit(200)->get() as $task) {
            $results=array_merge($results,$this->engine->dispatch($userId,'task.overdue',['subject_type'=>'task','subject_public_id'=>$task->public_id,'idempotency_key'=>'task.overdue:'.$task->public_id.':'.$now->format('Y-m-d')]));
        }
        foreach ($this->db->table('crm_invoices')->where('company_id', CrmCompanyScope::companyId($userId))->whereNotIn('status',['paid','voided'])->whereNotNull('due_at')->where('due_at','<',$now)->limit(200)->get() as $invoice) {
            $results=array_merge($results,$this->engine->dispatch($userId,'invoice.overdue',['subject_type'=>'invoice','subject_public_id'=>$invoice->public_id,'idempotency_key'=>'invoice.overdue:'.$invoice->public_id.':'.$now->format('Y-m-d')]));
        }
        return $results;
    }
}
