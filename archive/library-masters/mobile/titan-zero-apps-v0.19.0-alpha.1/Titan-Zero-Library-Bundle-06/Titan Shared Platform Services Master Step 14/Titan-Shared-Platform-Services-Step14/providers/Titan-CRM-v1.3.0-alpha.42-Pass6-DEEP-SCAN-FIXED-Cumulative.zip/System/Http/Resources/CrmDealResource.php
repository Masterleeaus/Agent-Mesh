<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

final class CrmDealResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'public_id' => $this->public_id,
            'name' => $this->name,
            'description' => $this->description,
            'customer_company_id' => $this->customer_company_id,
            'contact_id' => $this->contact_id,
            'pipeline_id' => $this->pipeline_id,
            'stage_id' => $this->stage_id,
            'value_minor' => $this->value_minor,
            'currency' => $this->currency,
            'status' => $this->status,
            'owner_user_id' => $this->owner_user_id,
            'probability' => $this->probability,
            'position' => $this->position,
            'expected_close_date' => $this->expected_close_date,
            'closed_at' => $this->closed_at,
            'lost_reason' => $this->lost_reason,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
