<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

use App\Extensions\Crm\System\Tenancy\CrmCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use RuntimeException;

/** Durable transactional outbox consumed asynchronously by Titan Signal. */
final class CrmDomainSignalPublisher
{
    public function __construct(private readonly ConnectionInterface $db) {}

    public function newMutationReference(): string { return (string)Str::ulid(); }

    public function recordMutation(string $capability,array $result,array $receipt,CrmCompanyContext $context,?string $reservedPublicId=null): string
    {
        $this->requireOutbox();
        $eventType='crm.capability.'.str_replace(['crm.','.'],['','_'],$capability).'.executed';
        $dedup=$this->dedup([$context->companyId,$eventType,$receipt['receipt_id']??null,$receipt['resource_type']??null,$receipt['resource_id']??null]);
        return $this->insert([
            'public_id'=>$reservedPublicId,
            'company_id'=>$context->companyId,'event_type'=>$eventType,
            'aggregate_type'=>$receipt['resource_type']??null,'aggregate_id'=>$receipt['resource_id']??null,
            'capability'=>$capability,'receipt_id'=>$receipt['receipt_id']??null,
            'trace_id'=>$receipt['trace_id']??$context->correlationId,'correlation_id'=>$receipt['correlation_id']??$context->correlationId,'causation_id'=>$receipt['causation_id']??$context->causationId,
            'payload'=>['receipt'=>$receipt,'result'=>$result],
        ],$dedup);
    }

    /** @param array<string,mixed> $intent @param array<string,mixed> $provider */
    public function recordExternalEffectLifecycle(array $intent,string $state,array $provider=[]): string
    {
        if(!$this->tableReady())return '';
        $tenant=(int)($intent['company_id']??0);if($tenant<1)return '';
        $template=(string)($intent['template_key']??'communication');
        $capability=$template==='crm_invoice_reminder'?'crm.invoice.reminder.send':($template==='crm_sales_document'?'crm.invoice.send':null);
        $trace=(string)($intent['trace_id']??$intent['correlation_id']??'');if($trace==='')$trace=(string)Str::uuid();
        $eventType='crm.communication.'.strtolower($state);
        $dedup=$this->dedup([$tenant,$eventType,$intent['public_id']??null,$provider['provider_message_id']??null,$provider['status']??null]);
        return $this->insert([
            'company_id'=>$tenant,'event_type'=>$eventType,
            'aggregate_type'=>$intent['subject_type']??'communication','aggregate_id'=>$intent['subject_public_id']??($intent['public_id']??null),
            'capability'=>$capability,'receipt_id'=>$intent['receipt_id']??null,
            'trace_id'=>$trace,'correlation_id'=>$intent['correlation_id']??null,'causation_id'=>$intent['causation_id']??null,
            'payload'=>['intent_public_id'=>$intent['public_id']??null,'state'=>$state,'provider'=>$provider],
        ],$dedup);
    }

    /** Persist rejected/invariant/concurrency observations after the failed CRM transaction has rolled back. */
    public function recordRejection(string $capability,array $error,CrmCompanyContext $context,?string $commandId=null): string
    {
        if(!$this->tableReady())return '';
        $eventType=isset($error['invariant_id'])?'crm.domain.invariant.violation':'crm.capability.rejected';
        $reason=(string)($error['message']??$error['reason']??'rejected');
        $dedup=$this->dedup([$context->companyId,$eventType,$commandId,$capability,$reason,$error['current_version']??null]);
        return $this->insert([
            'company_id'=>$context->companyId,'event_type'=>$eventType,'aggregate_type'=>$error['resource_type']??null,'aggregate_id'=>$error['resource_id']??null,
            'capability'=>$capability,'receipt_id'=>null,
            'trace_id'=>$context->traceId!==''?$context->traceId:$context->correlationId,'correlation_id'=>$context->correlationId,'causation_id'=>$context->causationId,
            'payload'=>['command_id'=>$commandId,'capability'=>$capability,'error'=>$error],
        ],$dedup);
    }

    /** @param array<string,mixed> $row */
    private function insert(array $row,string $eventDedupKey): string
    {
        $publicId=trim((string)($row['public_id']??''));if($publicId==='')$publicId=(string)Str::ulid();$now=now();
        $insert=[
            'public_id'=>$publicId,'company_id'=>$row['company_id'],'event_type'=>$row['event_type'],
            'aggregate_type'=>$row['aggregate_type']??null,'aggregate_id'=>$row['aggregate_id']??null,'capability'=>$row['capability']??null,'receipt_id'=>$row['receipt_id']??null,
            'trace_id'=>$row['trace_id'],'correlation_id'=>$row['correlation_id']??null,'causation_id'=>$row['causation_id']??null,
            'status'=>'pending','payload'=>json_encode($row['payload']??[],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),
            'occurred_at'=>$now,'dispatched_at'=>null,'created_at'=>$now,'updated_at'=>$now,
        ];
        $this->putIfColumn($insert,'event_dedup_key',$eventDedupKey);
        $this->putIfColumn($insert,'attempt_count',0);
        $this->putIfColumn($insert,'available_at',$now);
        $inserted=$this->db->table('crm_domain_signal_outbox')->insertOrIgnore($insert);
        if($inserted===1)return $publicId;
        if($this->hasColumn('event_dedup_key')){
            $existing=$this->db->table('crm_domain_signal_outbox')->where('company_id',(int)$row['company_id'])->where('event_dedup_key',$eventDedupKey)->value('public_id');
            if(is_string($existing)&&$existing!=='')return $existing;
        }
        return '';
    }

    private function requireOutbox(): void
    {
        if($this->tableReady())return;
        if((bool)config('crm.governance.require_signal_outbox',true))throw new RuntimeException('CRM Signal outbox is unavailable; refusing unobservable governed mutation.');
    }
    private function tableReady(): bool
    { try{return $this->db->getSchemaBuilder()->hasTable('crm_domain_signal_outbox');}catch(\Throwable){return false;} }
    private function hasColumn(string $column): bool
    { try{return $this->db->getSchemaBuilder()->hasColumn('crm_domain_signal_outbox',$column);}catch(\Throwable){return false;} }
    private function putIfColumn(array &$row,string $column,mixed $value): void
    { if($this->hasColumn($column))$row[$column]=$value; }
    private function dedup(array $parts): string
    { return hash('sha256',json_encode($parts,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)); }
}
