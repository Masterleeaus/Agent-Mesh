<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
foreach(['ReceiptRegistry','InMemoryReceiptRegistry','ProviderHealthGate','GovernedCommandEnvelope','ExecutionCoordinator'] as $f) require $root.'/System/Workforce/'.$f.'.php';
$ns='App\Extensions\TitanShield\System\Workforce\\';
$regClass='App\Extensions\TitanShield\System\Workforce\InMemoryReceiptRegistry'; $healthClass='App\Extensions\TitanShield\System\Workforce\ProviderHealthGate'; $coordClass='App\Extensions\TitanShield\System\Workforce\ExecutionCoordinator';
$reg=new $regClass(); $health=(new $healthClass())->evaluate(['provider_present'=>true,'version_match'=>true,'contract_parseable'=>true,'dependencies_ready'=>true]);
$req=['company_id'=>'c1','correlation_id'=>'x1','idempotency_key'=>'i1','provider'=>'titan-shield','provider_version'=>'1','capability_id'=>'cap'];
$coord=new $coordClass($reg); $r=$coord->authorize($req,$health,['decision'=>'allow'],true);
if(($r['decision']??'')!=='allow'){fwrite(STDERR,'execution gate failed'.PHP_EOL);exit(1);}
$bad=(new $healthClass())->evaluate(['provider_present'=>false]); if(($bad['decision']??'')!=='deny'){fwrite(STDERR,'health fail-open'.PHP_EOL);exit(1);}
$m=json_decode(file_get_contents($root.'/workforce-integration.json'),true,512,JSON_THROW_ON_ERROR); if(($m['schema_version']??'')!=='1.2'||($m['live_execution_protocol']['mutation_requires_adapter_ready']??false)!==true){fwrite(STDERR,'manifest invalid'.PHP_EOL);exit(1);}
echo 'PASS4_LIVE_EXECUTION: PASS'.PHP_EOL;
