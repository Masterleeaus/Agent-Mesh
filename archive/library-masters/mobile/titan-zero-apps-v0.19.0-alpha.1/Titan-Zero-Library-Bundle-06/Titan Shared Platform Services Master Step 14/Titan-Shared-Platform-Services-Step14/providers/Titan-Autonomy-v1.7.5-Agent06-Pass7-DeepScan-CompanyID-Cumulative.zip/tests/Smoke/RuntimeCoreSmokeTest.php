<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\OutcomeObservation;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\RiskClass;
use App\Extensions\TitanAutonomy\System\Enums\UserResponseClass;
use App\Extensions\TitanAutonomy\System\Services\CapabilityStateTransitionService;
use App\Extensions\TitanAutonomy\System\Services\ScopeEvaluator;

function check(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}

$state = new CapabilityState(
    tenantCompanyId: 7,
    capability: 'crm.invoice.issue',
    workflowKey: 'completed_job_invoice',
    risk: RiskClass::Medium,
    currentLevel: AutonomyLevel::Assist,
    requiredSuccessStreak: 2,
    currentSuccessStreak: 1,
    highestSuccessStreak: 4,
    totalSuccesses: 9,
);

$transition = (new CapabilityStateTransitionService())->recordOutcome(
    $state,
    new OutcomeObservation(
        userResponse: UserResponseClass::ApprovedUnchanged,
        executionSucceeded: true,
        reversed: false,
        unresolvedAssuranceIncident: false,
    ),
);

check($transition->state->currentSuccessStreak === 2, 'qualifying outcome must increment streak');
check($transition->state->totalSuccesses === 10, 'qualifying outcome must increment total successes');
check($transition->state->currentLevel === AutonomyLevel::Assist, 'evidence must never silently promote current level');

$corrected = (new CapabilityStateTransitionService())->recordOutcome(
    $transition->state,
    new OutcomeObservation(
        userResponse: UserResponseClass::ApprovedMaterialEdit,
        executionSucceeded: true,
        reversed: false,
        unresolvedAssuranceIncident: false,
        materialEdit: true,
    ),
);
check($corrected->state->currentSuccessStreak === 0, 'material correction must reset streak');
check($corrected->state->totalEdits === 1, 'material correction must increment edit count');

$scope = (new ScopeEvaluator())->evaluate(
    ['workflow' => 'completed_job_invoice', 'max_total' => 1500, 'requires_no_dispute' => true],
    ['workflow' => 'completed_job_invoice', 'total' => 1499, 'has_dispute' => false],
);
check($scope->allowed, 'in-scope action should be allowed');

$out = (new ScopeEvaluator())->evaluate(
    ['workflow' => 'completed_job_invoice', 'max_total' => 1500, 'requires_no_dispute' => true],
    ['workflow' => 'completed_job_invoice', 'total' => 1800, 'has_dispute' => false],
);
check(!$out->allowed && in_array('MAX_TOTAL_EXCEEDED', $out->reasonCodes, true), 'out-of-scope value must be denied');

echo "OK: RuntimeCoreSmokeTest\n";
