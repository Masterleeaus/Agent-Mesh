<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Models\RewindSnapshot;
use App\Extensions\TitanRewind\System\Reconstruction\RewindDiffService;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;

final class RewindSnapshotComparisonService
{
    public function __construct(private RewindDiffService $diff) {}

    public function forTrace(RewindTraceQuery $query): array
    {
        $pairs=[];
        $snapshots=RewindSnapshot::query()
            ->where('tenant_company_id',$query->tenantCompanyId())
            ->where('trace_id',$query->traceId())
            ->whereNotNull('entity_type')->whereNotNull('entity_id')
            ->orderBy('captured_at')->orderBy('id')->cursor();

        foreach($snapshots as $snapshot){
            $key=(string)$snapshot->entity_type.':'.(string)$snapshot->entity_id;
            if(!isset($pairs[$key])){$pairs[$key]=[null,$snapshot];continue;}
            $pairs[$key]=[$pairs[$key][1],$snapshot];
        }

        $comparisons=[];
        foreach($pairs as $key=>[$previous,$current]){
            if($previous===null||$current===null)continue;
            $comparisons[]=[
                'entity_key'=>$key,'entity_type'=>$current->entity_type,'entity_id'=>$current->entity_id,
                'previous_snapshot_uuid'=>$previous->snapshot_uuid,'current_snapshot_uuid'=>$current->snapshot_uuid,
                'previous_event_id'=>$previous->event_id,'current_event_id'=>$current->event_id,
                'previous_captured_at'=>$previous->captured_at,'current_captured_at'=>$current->captured_at,
                'diff'=>$this->diff->compare($previous->payload??[],$current->payload??[]),
            ];
        }
        return $comparisons;
    }
}
