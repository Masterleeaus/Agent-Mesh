<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_nexus_compilations')
            || Schema::hasColumn('titan_nexus_compilations', 'vertical_definition_hash')) {
            return;
        }

        Schema::table('titan_nexus_compilations', static function (Blueprint $table): void {
            $table->string('vertical_definition_hash', 64)->nullable()->index();
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('titan_nexus_compilations')
            || !Schema::hasColumn('titan_nexus_compilations', 'vertical_definition_hash')) {
            return;
        }

        Schema::table('titan_nexus_compilations', static function (Blueprint $table): void {
            $table->dropColumn('vertical_definition_hash');
        });
    }
};
