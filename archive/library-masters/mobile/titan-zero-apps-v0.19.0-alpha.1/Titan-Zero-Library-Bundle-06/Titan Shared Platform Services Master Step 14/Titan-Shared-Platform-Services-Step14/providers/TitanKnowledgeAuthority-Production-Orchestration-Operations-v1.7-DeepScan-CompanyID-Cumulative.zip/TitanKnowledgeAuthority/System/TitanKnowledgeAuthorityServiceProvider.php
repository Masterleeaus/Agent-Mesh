<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanKnowledgeAuthority\System\Contracts\KnowledgeAccessContextResolverContract;
use App\Extensions\TitanKnowledgeAuthority\System\Contracts\KnowledgeAuthorityContract;
use App\Extensions\TitanKnowledgeAuthority\System\Contracts\KnowledgeCatalogReadContract;
use App\Extensions\TitanKnowledgeAuthority\System\Contracts\KnowledgeSourceVersionWriteContract;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories\EloquentKnowledgeSourceRepository;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories\EloquentKnowledgeSourceVersionRepository;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories\KnowledgeSourceRepositoryContract;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories\KnowledgeSourceScopeQuery;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories\KnowledgeSourceVersionRepositoryContract;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Services\SourceVersionLineagePolicy;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Services\SourceVersionTenantLineagePolicy;
use App\Extensions\TitanKnowledgeAuthority\System\Services\FailClosedKnowledgeAccessContextResolver;
use App\Extensions\TitanKnowledgeAuthority\System\Services\KnowledgeAuthority;
use App\Extensions\TitanKnowledgeAuthority\System\Services\KnowledgeCatalogReadService;
use App\Extensions\TitanKnowledgeAuthority\System\Services\KnowledgeSourceVersionWriteService;
use App\Extensions\TitanKnowledgeAuthority\System\Support\HostNavigationRegistrar;
use App\Extensions\TitanKnowledgeAuthority\System\Support\LegacyMenuStore;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

final class TitanKnowledgeAuthorityServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->app->singleton(\App\Extensions\TitanKnowledgeAuthority\System\Workforce\CrossExtensionOrchestrator::class, static fn (): \App\Extensions\TitanKnowledgeAuthority\System\Workforce\CrossExtensionOrchestrator => new \App\Extensions\TitanKnowledgeAuthority\System\Workforce\CrossExtensionOrchestrator('TitanKnowledgeAuthority'));
        $this->app->singleton(\App\Extensions\TitanKnowledgeAuthority\System\Workforce\WorkforceLoopRuntime::class, static fn (): \App\Extensions\TitanKnowledgeAuthority\System\Workforce\WorkforceLoopRuntime => \App\Extensions\TitanKnowledgeAuthority\System\Workforce\WorkforceLoopRuntime::fromContractFile(__DIR__ . '/../workforce-integration.json'));
        $this->app->singleton(\App\Extensions\TitanKnowledgeAuthority\System\Workforce\ProviderDiscovery::class, fn (): \App\Extensions\TitanKnowledgeAuthority\System\Workforce\ProviderDiscovery => \App\Extensions\TitanKnowledgeAuthority\System\Workforce\ProviderDiscovery::fromContractFile($this->app, __DIR__ . '/../workforce-integration.json'));

        $this->app->singleton(\App\Extensions\TitanKnowledgeAuthority\System\Workforce\DurableHandoffStoreContract::class, static fn (): \App\Extensions\TitanKnowledgeAuthority\System\Workforce\DurableHandoffStoreContract => new \App\Extensions\TitanKnowledgeAuthority\Persistence\Workforce\DatabaseDurableHandoffStore());
        $this->app->singleton(\App\Extensions\TitanKnowledgeAuthority\System\Workforce\PersistentOrchestrationRuntime::class, static fn ($app): \App\Extensions\TitanKnowledgeAuthority\System\Workforce\PersistentOrchestrationRuntime => new \App\Extensions\TitanKnowledgeAuthority\System\Workforce\PersistentOrchestrationRuntime($app->make(\App\Extensions\TitanKnowledgeAuthority\System\Workforce\CrossExtensionOrchestrator::class), $app->make(\App\Extensions\TitanKnowledgeAuthority\System\Workforce\DurableHandoffStoreContract::class)));
        $this->app->singleton(\App\Extensions\TitanKnowledgeAuthority\System\Workforce\OrchestrationOperations::class, static fn ($app): \App\Extensions\TitanKnowledgeAuthority\System\Workforce\OrchestrationOperations => new \App\Extensions\TitanKnowledgeAuthority\System\Workforce\OrchestrationOperations($app->make(\App\Extensions\TitanKnowledgeAuthority\System\Workforce\PersistentOrchestrationRuntime::class), $app->make(\App\Extensions\TitanKnowledgeAuthority\System\Workforce\DurableHandoffStoreContract::class)));
        $config = __DIR__ . '/../config/titan-knowledge-authority.php';
        if (is_file($config)) {
            $this->mergeConfigFrom($config, 'titan-knowledge-authority');
        }

        $this->app->singleton(LegacyMenuStore::class);
        $this->app->singleton(KnowledgeAuthorityContract::class, KnowledgeAuthority::class);

        // The host may bind a trusted resolver before this provider registers.
        // Never replace it, and never fall back to request-supplied tenant scope.
        if (! $this->app->bound(KnowledgeAccessContextResolverContract::class)) {
            $this->app->singleton(
                KnowledgeAccessContextResolverContract::class,
                FailClosedKnowledgeAccessContextResolver::class,
            );
        }

        $this->app->singleton(KnowledgeSourceScopeQuery::class);
        $this->app->singleton(SourceVersionLineagePolicy::class);
        $this->app->singleton(SourceVersionTenantLineagePolicy::class);
        $this->app->singleton(KnowledgeSourceRepositoryContract::class, EloquentKnowledgeSourceRepository::class);
        $this->app->singleton(KnowledgeSourceVersionRepositoryContract::class, EloquentKnowledgeSourceVersionRepository::class);
        $this->app->singleton(KnowledgeCatalogReadContract::class, KnowledgeCatalogReadService::class);
        $this->app->singleton(KnowledgeSourceVersionWriteContract::class, KnowledgeSourceVersionWriteService::class);
    }

    public function boot(): void
    {
        $views = __DIR__ . '/../resources/views';
        if (is_dir($views)) {
            $this->loadViewsFrom($views, 'titan-knowledge-authority');
        }

        $migrations = __DIR__ . '/../database/migrations';
        if (is_dir($migrations)) {
            $this->loadMigrationsFrom($migrations);
        }

        $config = __DIR__ . '/../config/titan-knowledge-authority.php';
        if (is_file($config)) {
            $this->publishes([
                $config => config_path('titan-knowledge-authority.php'),
            ], 'titan-knowledge-authority-config');
        }

        $this->registerRoutes();
        (new HostNavigationRegistrar($this->app, $this->app->make(LegacyMenuStore::class)))->register();
    }

    public function registerKey(): string
    {
        return 'titan-knowledge-authority';
    }

    public static function uninstall(): void
    {
        File::delete(config_path('titan-knowledge-authority.php'));
    }

    private function registerRoutes(): void
    {
        /** @var Router $router */
        $router = $this->app['router'];

        $userRoutes = __DIR__ . '/../routes/user.php';
        if (is_file($userRoutes)) {
            $router->group([
                'middleware' => ['web', 'auth'],
                'prefix' => 'dashboard/user/titan-knowledge-authority',
                'as' => 'dashboard.user.titan.knowledge.authority.',
            ], static function (Router $router) use ($userRoutes): void {
                require $userRoutes;
            });
        }

        $adminRoutes = __DIR__ . '/../routes/admin.php';
        if (is_file($adminRoutes)) {
            $router->group([
                'middleware' => ['web', 'auth', 'admin'],
                'prefix' => 'dashboard/admin/titan-knowledge-authority',
                'as' => 'dashboard.admin.titan.knowledge.authority.',
            ], static function (Router $router) use ($adminRoutes): void {
                require $adminRoutes;
            });
        }
    }
}
