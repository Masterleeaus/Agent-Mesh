<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function dpfail(string $m): never { fwrite(STDERR,"FAIL: {$m}\n"); exit(1); }
function dpok(bool $c,string $m): void { if(!$c)dpfail($m); }
$installer=json_decode((string)file_get_contents($root.'/extension.json'),true,512,JSON_THROW_ON_ERROR);
$sidecar=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
$hard=[]; foreach(($installer['dependencies']??[]) as $d){ if(is_array($d)&&isset($d['slug']))$hard[(string)$d['slug']]=$d['version']??null; }
$optional=[]; foreach(($installer['optional_dependencies']??[]) as $d){ if(is_array($d)&&isset($d['slug']))$optional[(string)$d['slug']]=$d['version']??null; }
dpok(!isset($hard['titan-signal']),'Titan Signal must not block Installer 1.7.6 installation');
dpok(!isset($hard['titan-command-bus']),'Titan Command Bus must not block Installer 1.7.6 installation');
dpok(($optional['titan-signal']??null)==='>=0.2.0','Titan Signal floor must remain declared as optional installer peer');
dpok(($optional['titan-command-bus']??null)==='>=0.2.0-alpha.1','Titan Command Bus floor must remain declared as optional installer peer');
dpok(($hard['titan-autonomy']??null)==='>=0.1','Titan Autonomy remains the hard installer authority dependency');
$runtime=[]; foreach(($sidecar['dependencies']['required']??[]) as $d){ if(is_array($d)&&isset($d['key']))$runtime[(string)$d['key']]=$d['version']??null; }
dpok(($runtime['titan-signal']??null)==='>=0.2.0','Signal remains runtime-required in canonical sidecar');
dpok(($runtime['titan-command-bus']??null)==='>=0.2.0-alpha.1','Command Bus remains runtime-required in canonical sidecar');
dpok(($runtime['titan-autonomy']??null)==='>=0.1','Autonomy remains runtime-required in canonical sidecar');
$config=(string)file_get_contents($root.'/config/titan-governance.php');
dpok(str_contains($config,"'required_dependencies' => ['titan-signal', 'titan-command-bus', 'titan-autonomy']"),'runtime-required dependency list must remain fail-closed');
$provider=(string)file_get_contents($root.'/System/TitanGovernanceServiceProvider.php');
dpok(str_contains($provider,'UnavailableGovernanceCommandGateway'),'missing Command Bus must retain fail-closed gateway');
dpok(str_contains($provider,'UnavailableGovernanceReadSource'),'missing required read peers must retain unavailable source adapters');
echo "PASS: Installer 1.7.6 dependency policy contract\n";
