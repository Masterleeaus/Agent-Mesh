<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class TraceProfile
{
    /**
     * @param list<string> $requiredEventTypes
     * @param list<array{before:string,after:string}> $orderingRules
     * @param list<string> $terminalEventTypes
     * @param list<string> $matchEventTypes
     */
    private function __construct(
        public string $profileKey,
        public int $version,
        public array $requiredEventTypes,
        public array $orderingRules,
        public array $terminalEventTypes,
        public array $matchEventTypes,
        public string $status,
        public ?string $description,
    ) {
    }

    /** @param array<string,mixed> $data */
    public static function fromArray(array $data): self
    {
        $profileKey = trim((string) ($data['profile_key'] ?? ''));
        if ($profileKey === '' || strlen($profileKey) > 160) {
            throw new InvalidArgumentException('Trace profile_key is required and must not exceed 160 characters.');
        }

        $version = (int) ($data['version'] ?? 1);
        if ($version < 1) {
            throw new InvalidArgumentException('Trace profile version must be positive.');
        }

        $required = self::stringList($data['required_event_types'] ?? [], 'required_event_types');
        $terminal = self::stringList($data['terminal_event_types'] ?? [], 'terminal_event_types');
        $ordering = [];
        foreach ((array) ($data['ordering_rules'] ?? []) as $index => $rule) {
            if (! is_array($rule)) {
                throw new InvalidArgumentException("Trace ordering rule {$index} must be an array.");
            }
            $before = trim((string) ($rule['before'] ?? ''));
            $after = trim((string) ($rule['after'] ?? ''));
            if ($before === '' || $after === '' || $before === $after) {
                throw new InvalidArgumentException("Trace ordering rule {$index} requires distinct before/after event types.");
            }
            $ordering[] = ['before' => $before, 'after' => $after];
        }

        $derivedMatch = $required;
        foreach ($ordering as $rule) {
            $derivedMatch[] = $rule['before'];
            $derivedMatch[] = $rule['after'];
        }
        array_push($derivedMatch, ...$terminal);
        $derivedMatch = array_values(array_unique($derivedMatch));
        $match = array_key_exists('match_event_types', $data) && is_array($data['match_event_types'])
            ? self::stringList($data['match_event_types'], 'match_event_types')
            : $derivedMatch;

        $status = strtolower(trim((string) ($data['status'] ?? 'active')));
        if (! in_array($status, ['active', 'deprecated', 'disabled'], true)) {
            throw new InvalidArgumentException('Trace profile status must be active, deprecated, or disabled.');
        }

        $description = isset($data['description']) ? trim((string) $data['description']) : null;
        if ($description === '') {
            $description = null;
        }

        return new self($profileKey, $version, $required, $ordering, $terminal, $match, $status, $description);
    }


    public function matchesEventType(string $eventType): bool
    {
        return in_array(trim($eventType), $this->matchEventTypes, true);
    }

    public function isTerminalEventType(string $eventType): bool
    {
        return in_array(trim($eventType), $this->terminalEventTypes, true);
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'profile_key' => $this->profileKey,
            'version' => $this->version,
            'required_event_types' => $this->requiredEventTypes,
            'ordering_rules' => $this->orderingRules,
            'terminal_event_types' => $this->terminalEventTypes,
            'match_event_types' => $this->matchEventTypes,
            'status' => $this->status,
            'description' => $this->description,
        ];
    }

    /** @return list<string> */
    private static function stringList(mixed $value, string $field): array
    {
        if (! is_array($value)) {
            throw new InvalidArgumentException("{$field} must be an array.");
        }
        $result = [];
        foreach ($value as $item) {
            $item = trim((string) $item);
            if ($item === '') {
                throw new InvalidArgumentException("{$field} cannot contain empty values.");
            }
            $result[$item] = true;
        }
        return array_keys($result);
    }
}
