<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_event_lifecycle')) {
            Schema::create('titan_signal_event_lifecycle', function (Blueprint $table): void {
                $table->id();
                $table->uuid('event_id')->unique('tsel_event_uq');
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->string('retention_class', 40);
                $table->timestamp('retain_until')->nullable();
                $table->boolean('legal_hold')->default(false);
                $table->timestamp('legal_hold_at')->nullable();
                $table->string('legal_hold_by', 191)->nullable();
                $table->string('legal_hold_reason', 255)->nullable();
                $table->uuid('archive_batch_id')->nullable();
                $table->timestamp('archived_at')->nullable();
                $table->timestamp('pruned_at')->nullable();
                $table->timestamps();
                $table->index(['scope', 'tenant_key', 'retention_class', 'retain_until'], 'tsel_retention_idx');
                $table->index(['legal_hold', 'retain_until'], 'tsel_hold_idx');
                $table->index(['archive_batch_id'], 'tsel_archive_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_event_overlays')) {
            Schema::create('titan_signal_event_overlays', function (Blueprint $table): void {
                $table->id();
                $table->uuid('overlay_id')->unique('tseo_overlay_uq');
                $table->uuid('event_id');
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->string('overlay_type', 24);
                $table->json('operations');
                $table->string('reason', 255);
                $table->string('actor_id', 191);
                $table->dateTime('applied_at');
                $table->timestamps();
                $table->index(['event_id', 'applied_at'], 'tseo_event_idx');
                $table->index(['scope', 'tenant_key', 'overlay_type', 'applied_at'], 'tseo_scope_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_archive_batches')) {
            Schema::create('titan_signal_archive_batches', function (Blueprint $table): void {
                $table->id();
                $table->uuid('batch_id')->unique('tsab_batch_uq');
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->string('status', 24);
                $table->string('archive_driver', 80);
                $table->string('archive_locator', 1024)->nullable();
                $table->char('archive_checksum', 64)->nullable();
                $table->unsignedBigInteger('event_count')->default(0);
                $table->json('criteria')->nullable();
                $table->timestamp('archived_at')->nullable();
                $table->timestamp('verified_at')->nullable();
                $table->timestamps();
                $table->index(['scope', 'tenant_key', 'status', 'archived_at'], 'tsab_scope_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_lifecycle_audit')) {
            Schema::create('titan_signal_lifecycle_audit', function (Blueprint $table): void {
                $table->id();
                $table->uuid('action_id')->unique('tsla_action_uq');
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->unsignedBigInteger('tenant_key')->default(0);
                $table->string('action', 80);
                $table->uuid('target_event_id')->nullable();
                $table->uuid('batch_id')->nullable();
                $table->string('actor_id', 191);
                $table->string('reason', 255);
                $table->json('details')->nullable();
                $table->dateTime('occurred_at');
                $table->timestamps();
                $table->index(['scope', 'tenant_key', 'occurred_at'], 'tsla_scope_idx');
                $table->index(['target_event_id', 'occurred_at'], 'tsla_event_idx');
                $table->index(['batch_id', 'occurred_at'], 'tsla_batch_idx');
            });
        }


        if (Schema::hasTable('titan_signal_events') && Schema::hasTable('titan_signal_event_lifecycle')) {
            DB::table('titan_signal_events')->orderBy('id')->chunkById(500, function ($rows): void {
                foreach ($rows as $row) {
                    $category = strtolower((string) ($row->category ?? ''));
                    $severity = strtolower((string) ($row->severity ?? 'info'));
                    $class = 'operational';
                    $days = 730;
                    if ($severity === 'debug') { $class = 'debug'; $days = 30; }
                    elseif (in_array($category, ['governance', 'security', 'compliance', 'risk', 'audit'], true) || in_array($severity, ['critical', 'fatal'], true)) { $class = 'audit'; $days = 2555; }
                    elseif (in_array($category, ['telemetry', 'metrics', 'diagnostics'], true)) { $class = 'telemetry'; $days = 90; }
                    $recorded = new DateTimeImmutable((string) ($row->recorded_at ?? $row->created_at ?? 'now'), new DateTimeZone('UTC'));
                    DB::table('titan_signal_event_lifecycle')->insertOrIgnore([
                        'event_id' => (string) $row->event_id,
                        'scope' => (string) ($row->scope ?? ($row->tenant_company_id === null ? 'system' : 'tenant')),
                        'tenant_company_id' => $row->tenant_company_id,
                        'tenant_key' => (int) ($row->tenant_company_id ?? 0),
                        'retention_class' => $class,
                        'retain_until' => $recorded->modify('+' . $days . ' days')->format('Y-m-d H:i:s'),
                        'legal_hold' => false,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_lifecycle_audit');
        Schema::dropIfExists('titan_signal_archive_batches');
        Schema::dropIfExists('titan_signal_event_overlays');
        Schema::dropIfExists('titan_signal_event_lifecycle');
    }
};
