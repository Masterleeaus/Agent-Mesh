<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Data;

final class WorkOrderSummaryDTO
{
    public function __construct(
        public readonly mixed $publicId,
        public readonly mixed $number,
        public readonly mixed $title,
        public readonly mixed $status,
        public readonly mixed $priority,
        public readonly mixed $assignedUserId,
        public readonly mixed $scheduledStart,
    ) {}

    public function toArray(): array
    {
        return [
            'publicId'=>$this->publicId,
            'number'=>$this->number,
            'title'=>$this->title,
            'status'=>$this->status,
            'priority'=>$this->priority,
            'assignedUserId'=>$this->assignedUserId,
            'scheduledStart'=>$this->scheduledStart,
        ];
    }
}
