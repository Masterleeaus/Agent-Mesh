<?php

declare(strict_types=1);

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
$required = [
    '/System/Domain/ProvisioningExecutionContext.php',
    '/System/Domain/RiskDecision.php',
    '/System/Domain/GovernanceDecision.php',
    '/System/Domain/AutonomyDecision.php',
    '/System/Domain/AssuranceDecision.php',
    '/System/Contracts/RiskGatewayContract.php',
    '/System/Contracts/GovernanceGatewayContract.php',
    '/System/Contracts/AutonomyGatewayContract.php',
    '/System/Contracts/AssuranceGatewayContract.php',
    '/System/Contracts/SignalGatewayContract.php',
    '/System/Contracts/RewindGatewayContract.php',
    '/System/Adapters/Governance/RiskEngineAdapter.php',
    '/System/Adapters/Governance/GovernanceEngineAdapter.php',
    '/System/Adapters/Governance/AutonomyEngineAdapter.php',
    '/System/Adapters/Governance/AssuranceEngineAdapter.php',
    '/System/Adapters/Observability/SignalEngineAdapter.php',
    '/System/Adapters/Observability/RewindEngineAdapter.php',
];
foreach ($required as $file) {
    if (!is_file($root . $file)) {
        fwrite(STDERR, "FAIL: missing Pass 6 production file {$file}\n");
        exit(1);
    }
}

foreach ([
    '/System/Support/CanonicalJson.php',
    '/System/Domain/SemanticChangeKind.php',
    '/System/Domain/SemanticChangeDisposition.php',
    '/System/Domain/ProvisioningPlanStatus.php',
    '/System/Domain/ProvisioningReceiptStatus.php',
    '/System/Domain/ValueObjects/TraceContext.php',
    '/System/Domain/ProvisioningOperation.php',
    '/System/Domain/ProvisioningReceipt.php',
    '/System/Domain/ProvisioningPlan.php',
    '/System/Domain/ProvisioningExecutionContext.php',
    '/System/Domain/RiskDecision.php',
    '/System/Domain/GovernanceDecision.php',
    '/System/Domain/AutonomyDecision.php',
    '/System/Domain/AssuranceDecision.php',
    '/System/Contracts/ProvisioningCommandGatewayContract.php',
    '/System/Contracts/ProvisioningExecutorContract.php',
    '/System/Contracts/RiskGatewayContract.php',
    '/System/Contracts/GovernanceGatewayContract.php',
    '/System/Contracts/AutonomyGatewayContract.php',
    '/System/Contracts/AssuranceGatewayContract.php',
    '/System/Contracts/SignalGatewayContract.php',
    '/System/Contracts/RewindGatewayContract.php',
    '/System/Adapters/CommandBus/CommandBusProvisioningAdapter.php',
    '/System/Adapters/Governance/RiskEngineAdapter.php',
    '/System/Adapters/Governance/GovernanceEngineAdapter.php',
    '/System/Adapters/Governance/AutonomyEngineAdapter.php',
    '/System/Adapters/Governance/AssuranceEngineAdapter.php',
    '/System/Adapters/Observability/SignalEngineAdapter.php',
    '/System/Adapters/Observability/RewindEngineAdapter.php',
    '/System/Services/GovernedProvisioningExecutor.php',
] as $file) {
    require_once $root . $file;
}

use App\Extensions\TitanNexus\System\Adapters\CommandBus\CommandBusProvisioningAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\AssuranceEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\AutonomyEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\GovernanceEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Governance\RiskEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Observability\RewindEngineAdapter;
use App\Extensions\TitanNexus\System\Adapters\Observability\SignalEngineAdapter;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlan;
use App\Extensions\TitanNexus\System\Domain\ProvisioningPlanStatus;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeDisposition;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeKind;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Services\GovernedProvisioningExecutor;

function p6check(bool $condition, string $message): void { if (!$condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } }
function p6trace(): TraceContext { return TraceContext::fromArray(['tenant_company_id'=>42,'trace_id'=>'11111111-1111-4111-8111-111111111111','correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>'33333333-3333-4333-8333-333333333333']); }
function p6plan(SemanticChangeDisposition $disposition = SemanticChangeDisposition::Apply): ProvisioningPlan {
    $op = new ProvisioningOperation(42,'44444444-4444-4444-8444-444444444444',str_repeat('a',64),'sections.crm.enabled',SemanticChangeKind::Modify,$disposition,'crm.configuration.apply','sections.crm',false,true,[],$disposition===SemanticChangeDisposition::RequiresApproval?'Owner approval required.':null);
    return new ProvisioningPlan(42,'44444444-4444-4444-8444-444444444444',str_repeat('a',64),null,[$op]);
}
function p6executor(array &$order, bool $riskAllowed=true, bool $governanceAllowed=true, bool $autonomyAllowed=true, bool $assuranceAllowed=true): GovernedProvisioningExecutor {
    $risk = new RiskEngineAdapter(static function(array $request) use (&$order,$riskAllowed): array { $order[]='risk'; return ['allowed'=>$riskAllowed,'decision_reference'=>'risk:1','risk_class'=>'MEDIUM','required_assurance'=>'AMBER','reason'=>$riskAllowed?null:'risk denied']; });
    $gov = new GovernanceEngineAdapter(static function(array $request) use (&$order,$governanceAllowed): array { $order[]='governance'; return ['allowed'=>$governanceAllowed,'decision_reference'=>'gov:1','approval_required'=>($request['operation']['governance_disposition']??'')==='requires_approval','approval_reference'=>$request['execution_context']['approval_reference']??null,'reason'=>$governanceAllowed?null:'governance denied']; });
    $auto = new AutonomyEngineAdapter(static function(array $request) use (&$order,$autonomyAllowed): array { $order[]='autonomy'; return ['allowed'=>$autonomyAllowed,'decision_reference'=>'autonomy:1','authority_level'=>'Semi-Auto','reason'=>$autonomyAllowed?null:'autonomy denied']; });
    $assurance = new AssuranceEngineAdapter(static function(array $request) use (&$order,$assuranceAllowed): array { $order[]='assurance'; return ['allowed'=>$assuranceAllowed,'evidence_reference'=>'assurance:1','assurance_level'=>'AMBER','reason'=>$assuranceAllowed?null:'assurance denied']; });
    $signal = new SignalEngineAdapter(static function(string $event,array $request) use (&$order): array { $order[]='signal:'.$event; return ['signal_reference'=>'signal:'.$event]; });
    $rewind = new RewindEngineAdapter(static function(string $event,array $request) use (&$order): array { $order[]='rewind:'.$event; return ['rewind_reference'=>'rewind:'.$event]; });
    $command = new CommandBusProvisioningAdapter(static function(string $capability,array $request) use (&$order): array { $order[]='command'; return ['operation_id'=>$request['operation_id'],'idempotency_key'=>$request['idempotency_key'],'status'=>'applied','backup_reference'=>'backup:1','backup_verified'=>true,'write_verified'=>true,'audit_reference'=>'audit:1','rollback_reference'=>'rollback:1']; });
    return new GovernedProvisioningExecutor($command,$risk,$gov,$assurance,$signal,$rewind,$auto);
}

$order=[];
$ctx=ProvisioningExecutionContext::human(42,'user:7','approval:owner-7');
$executed=p6executor($order)->execute(p6plan(SemanticChangeDisposition::RequiresApproval),p6trace(),true,$ctx);
p6check($executed->status()===ProvisioningPlanStatus::Applied,'fully governed operation applies');
p6check($order===['risk','governance','assurance','signal:nexus.operation.authorized','rewind:nexus.operation.prepared','command','signal:nexus.operation.applied','rewind:nexus.operation.applied'],'gate and evidence order is deterministic for human execution');
$meta=$executed->receipts()[0]->metadata();
p6check(($meta['governance']['risk_decision_reference']??null)==='risk:1','receipt retains risk decision evidence');
p6check(($meta['governance']['governance_decision_reference']??null)==='gov:1','receipt retains governance decision evidence');
p6check(($meta['governance']['assurance_evidence_reference']??null)==='assurance:1','receipt retains assurance evidence');
p6check(($meta['governance']['pre_signal_reference']??null)==='signal:nexus.operation.authorized','receipt retains pre-mutation Signal evidence');
p6check(($meta['governance']['pre_rewind_reference']??null)==='rewind:nexus.operation.prepared','receipt retains pre-mutation Rewind evidence');

$order=[];
$denied=p6executor($order,false)->execute(p6plan(),p6trace(),false,ProvisioningExecutionContext::human(42,'user:7'));
p6check($denied->status()===ProvisioningPlanStatus::Failed,'risk denial fails plan');
p6check(!in_array('command',$order,true),'risk denial prevents Command Bus mutation');

$order=[];
$agent=ProvisioningExecutionContext::agent(42,'agent:scheduler','autonomy-grant:1');
$autoDenied=p6executor($order,true,true,false)->execute(p6plan(),p6trace(),false,$agent);
p6check($autoDenied->status()===ProvisioningPlanStatus::Failed,'autonomy denial fails autonomous execution');
p6check($order===['risk','governance','autonomy','signal:nexus.operation.blocked','rewind:nexus.operation.blocked'],'autonomy denial is governed and observable without mutation');

$order=[];
$agentApplied=p6executor($order)->execute(p6plan(),p6trace(),false,$agent);
p6check(in_array('autonomy',$order,true),'agent initiated operation requires autonomy gate');
p6check(($agentApplied->receipts()[0]->metadata()['governance']['autonomy_decision_reference']??null)==='autonomy:1','autonomy evidence is retained');

$order=[];
$assuranceDenied=p6executor($order,true,true,true,false)->execute(p6plan(),p6trace(),false,ProvisioningExecutionContext::human(42,'user:7'));
p6check($assuranceDenied->status()===ProvisioningPlanStatus::Failed,'assurance denial fails plan');
p6check(!in_array('command',$order,true),'assurance denial prevents mutation');

fwrite(STDOUT,"PASS: Titan Nexus standalone governed execution checks\n");
