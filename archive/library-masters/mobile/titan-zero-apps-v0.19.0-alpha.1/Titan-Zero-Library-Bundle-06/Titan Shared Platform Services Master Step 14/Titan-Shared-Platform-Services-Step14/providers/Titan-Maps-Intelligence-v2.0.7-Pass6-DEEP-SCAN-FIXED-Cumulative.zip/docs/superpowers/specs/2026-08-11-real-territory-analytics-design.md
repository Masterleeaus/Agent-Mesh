# Titan Maps Intelligence Pass 15 — Real Territory Analytics Design

## Goal
Replace the generic territory-analysis summary with six methodologically distinct, evidence-backed analytics engines: provider coverage, competitor density, supplier access, service gaps, branch coverage, and expansion opportunity.

## Authority boundary
Maps owns geographic observations, cell-level calculations, travel evidence, and analytical scores. CRM/WorkCore remains authoritative for jobs, demand, customers, branches, staffing and commercial decisions. Maps may use company-scoped canonical job/branch locations as observed demand/coverage evidence but must mark demand unavailable when no job evidence exists.

## Shared evidence model
Each analysis run stores analysis type, methodology key/version, explicit area denominator, input summary, source coverage, confidence, findings and generated metrics. Optional cell rows store the geographic cell key, centre/bounds, area, raw counts, derived metrics and confidence so graphical overlays can be reconstructed later.

## Engines
1. Provider Coverage v2: covered-cell ratio, provider density per km², internal-location coverage and uncovered cells.
2. Competitor Density v2: competitor count / explicit km², per-cell competitor density and high-density cells.
3. Supplier Access v2: nearest supplier access grouped into <=15, <=30, <=45, >45 minute or unavailable bands using matrix/route evidence where available; no ETA is invented.
4. Service Gap v2: combines observed job concentration with low internal/provider coverage. If no job-demand evidence exists, demand is marked unavailable and the engine does not fabricate demand.
5. Branch Coverage v1: assigns cells to nearest branch by road/ETA evidence where available, otherwise explicit straight-line proximity, and reports overlap/unassigned cells.
6. Expansion Opportunity v1: configurable weighted score using observed demand, coverage gap, competitor pressure, supplier access and branch distance; unavailable inputs reduce evidence completeness rather than being treated as favourable.

## Grid
For bounded analyses, a deterministic rectangular grid is created from the requested/search bounds. Maximum cells are configuration-limited. Cell area is derived from latitude-aware dimensions and every density metric uses an explicit square-kilometre denominator.

## UI
Existing Territory Analysis, Provider Coverage, Competitor Density, Supplier Coverage and Service Gaps pages become mode-specific. Add Branch Coverage and Expansion Opportunities pages. Pages show methodology/version, evidence completeness, headline metrics, recent runs and graphical cell overlays.

## Testing
Pure runtime tests prove formulas differ by mode, competitor density uses area, supplier bands do not invent ETA, service gaps preserve demand-unavailable state, and expansion scoring penalizes unknown evidence. Architecture tests enforce separate analyzer classes, persisted methodology/version and dedicated routes/menu entries.
