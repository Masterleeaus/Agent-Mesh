<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Automation\Events;
final class CrmAutomationTriggered
{
    public function __construct(public readonly int $userId, public readonly string $triggerKey, public readonly array $context = []) {}
}
