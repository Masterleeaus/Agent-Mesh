# Titan Wisdom Architecture

Titan Wisdom is the canonical `outcome-learning` owner in `titan.engine.ownership.v1`. It uses the Blueprint `intelligence-engine` profile and `signal-aware` modifier.

## Current pipeline

`source operation -> OutcomeRecord -> delayed observation -> EvidenceReference(s) -> governed resolution -> transition snapshot -> optional later revision/contradiction`

### Durable ownership

- `titan_wisdom_outcome_records`: current canonical OutcomeRecord projections plus append-only revision records.
- `titan_wisdom_evidence_references`: raw evidence provenance and validation status.
- `titan_wisdom_outcome_evidence`: tenant-scoped evidence/outcome relationships.
- `titan_wisdom_outcome_transitions`: append-only pending/observing-to-terminal transition snapshots.
- `titan_wisdom_outcomes`: legacy scaffold seam only.

## Truth boundary

Evidence and interpretation remain separate. Self-report is not equivalent to validation. Conclusive outcome resolution requires independently validated authoritative evidence. Contradictory evidence is retained and produces new lineage rather than rewriting history.

## Delayed observation

A one-server overlap-protected schedule scans overdue unresolved outcomes every five minutes. Jobs are unique by stable idempotency key and use the dedicated `titan-wisdom` queue. The worker emits observation-due context only; it cannot resolve or revise outcomes.

## Still absent

Attribution, pattern learning, calibration feedback and learning-candidate generation are not yet active capabilities.
