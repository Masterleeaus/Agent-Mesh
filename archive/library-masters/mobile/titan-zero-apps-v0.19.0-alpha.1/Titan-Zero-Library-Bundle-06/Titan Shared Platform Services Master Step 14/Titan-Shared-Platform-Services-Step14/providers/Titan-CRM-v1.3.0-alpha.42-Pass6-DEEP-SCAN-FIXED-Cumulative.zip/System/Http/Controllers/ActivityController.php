<?php
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Contracts\ActivityRepositoryContract; use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway; use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class ActivityController extends Controller
{
    public function __construct(private ActivityRepositoryContract $activities, private CrmHumanMutationGateway $mutations) {}
    public function index(Request $r){$data=$r->validate(['subject_type'=>'required|string|max:40','subject_public_id'=>'required|string|max:26','limit'=>'nullable|integer|min:1|max:250']);return response()->json(['data'=>$this->activities->forSubject((int)$r->user()->id,$data['subject_type'],$data['subject_public_id'],(int)($data['limit']??100))]);}
    public function store(Request $r){$data=$r->validate(['subject_type'=>'required|string|max:40','subject_public_id'=>'required|string|max:26','type'=>'nullable|string|max:32','title'=>'nullable|string|max:255','body'=>'nullable|string','direction'=>'nullable|in:inbound,outbound,internal','scheduled_at'=>'nullable|date','completed_at'=>'nullable|date','metadata'=>'nullable|array']);return response()->json($this->mutations->execute($r,'crm.activity.create',$data),201);}
}
