<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\DTO;

final readonly class AssuranceDecision
{
    /**
     * @param list<string> $evidenceReferences
     */
    public function __construct(
        public bool $allowed,
        public ?string $reference,
        public ?string $assuranceLevel = null,
        public array $evidenceReferences = [],
        public ?string $reasonCode = null,
    ) {}
}
