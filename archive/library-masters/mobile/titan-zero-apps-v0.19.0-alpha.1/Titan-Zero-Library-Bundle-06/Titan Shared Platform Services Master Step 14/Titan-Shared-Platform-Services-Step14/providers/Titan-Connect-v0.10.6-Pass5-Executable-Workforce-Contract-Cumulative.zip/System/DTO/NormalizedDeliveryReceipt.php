<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\DTO;

final class NormalizedDeliveryReceipt
{
    public function __construct(
        public readonly string $provider,
        public readonly ?string $providerMessageId,
        public readonly string $status,
        public readonly array $metadata = [],
    ) {
    }
}
