<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\TitanMobile;

use App\Extensions\Crm\System\Governance\CrmCommandBusGateway;
use App\Extensions\Crm\System\Tenancy\CrmCompanyContextResolver;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\TitanHub\System\Contracts\CustomerOperationsGateway;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\ConnectionInterface;

/**
 * CRM-owned customer/commercial decorator for Titan Hub.
 *
 * Field operations (services, service requests, work orders, bookings,
 * support and service locations) are delegated unchanged to Titan Hub/Titan Field.
 */
final class CrmCustomerOperationsGateway implements CustomerOperationsGateway
{
    public function __construct(
        private CustomerOperationsGateway $inner,
        private CrmMobileIdentityResolver $identities,
        private ConnectionInterface $db,
        private CrmCommandBusGateway $commands,
        private CrmCompanyContextResolver $companyContexts,
        private CrmCompanyScope $companyScope,
    ) {}

    public function home(array $context): array
    {
        return $this->withCustomerCompany($context, function () use ($context): array {
            $base = $this->inner->home($context);
            $base['crm'] = $this->homeSummary($context);
            return $base;
        });
    }

    public function homeSummary(array $context): array
    {
        return $this->withCustomerCompany($context, function () use ($context): array {
            $identity = $this->identities->resolveCustomer($context);
            if (! $identity) {
                return ['identity' => ['state' => 'unmatched', 'verified' => false]];
            }

            return [
                'identity' => ['state' => $identity['identity_state'], 'verified' => $identity['verified']],
                'profile' => $identity['contact'],
                'company' => $identity['company'],
                'quotes_count' => count($this->crmQuotes($identity, [])),
                'invoices_count' => $identity['verified'] ? count($this->crmInvoices($identity, [])) : null,
                'projects_count' => $identity['verified'] ? count($this->projects($identity, 100)) : null,
            ];
        });
    }

    // Titan Field/Titan Hub own these operational surfaces. CRM Core does not decorate them.
    public function services(array $context, array $filters=[]): array { return $this->inner->services($context, $filters); }
    public function serviceRequests(array $context, array $filters=[]): array { return $this->inner->serviceRequests($context, $filters); }
    public function serviceRequest(array $context, string $id): ?array { return $this->inner->serviceRequest($context, $id); }
    public function createServiceRequest(array $context, array $payload): array { return $this->inner->createServiceRequest($context, $payload); }
    public function jobs(array $context, array $filters=[]): array { return $this->inner->jobs($context, $filters); }
    public function job(array $context, string $id): ?array { return $this->inner->job($context, $id); }
    public function workOrders(array $context, array $filters=[]): array { return $this->inner->workOrders($context, $filters); }
    public function workOrder(array $context, string $id): ?array { return $this->inner->workOrder($context, $id); }
    public function bookings(array $context, array $filters=[]): array { return $this->inner->bookings($context, $filters); }
    public function requestBookingChange(array $context, string $id, array $payload): array { return $this->inner->requestBookingChange($context, $id, $payload); }
    public function support(array $context, array $filters=[]): array { return $this->inner->support($context, $filters); }
    public function locations(array $context, array $filters=[]): array { return $this->inner->locations($context, $filters); }

    public function quotes(array $context, array $filters=[]): array
    {
        return $this->withCustomerCompany($context, function () use ($context, $filters): array {
            $base = $this->inner->quotes($context, $filters);
            $identity = $this->identities->resolveCustomer($context);
            return $identity ? array_merge($base, $this->crmQuotes($identity, $filters)) : $base;
        });
    }

    public function quote(array $context, string $id): ?array
    {
        return $this->withCustomerCompany($context, function () use ($context, $id): ?array {
            $identity = $this->identities->resolveCustomer($context);
            $reference = $identity ? $this->crmQuoteReference($identity, $id) : null;
            if (! $reference) {
                return $this->inner->quote($context, $id);
            }

            [$type, $publicId] = $reference;
            $row = $this->db->table('crm_' . $type)
                ->where('company_id', $identity['company_id'])
                ->where('public_id', $publicId)
                ->where('contact_public_id', $identity['crm_contact_public_id'])
                ->whereNull('deleted_at')
                ->first();

            return $row ? $this->formatQuote($type, (array) $row) : null;
        });
    }

    public function approveQuote(array $context, string $id, array $payload=[]): array
    {
        return $this->withCustomerCompany($context, function () use ($context, $id, $payload): array {
            $identity = $this->identities->resolveCustomer($context);
            $reference = $identity ? $this->crmQuoteReference($identity, $id) : null;
            if (! $reference) {
                return $this->inner->approveQuote($context, $id, $payload);
            }
            if (! $identity['verified']) {
                throw new AuthorizationException('Verified customer identity is required.');
            }

            [$type, $publicId] = $reference;
            $this->assertOwnsSales($identity, $type, $publicId);
            $command = $this->commands->request('crm.quote.approve', [
                'type' => $type,
                'public_id' => $publicId,
                'idempotency_key' => $payload['idempotency_key'] ?? ('titan-hub:quote-accept:' . $publicId),
                'accepted_via' => 'titan_hub',
                'accepted_actor_type' => 'customer',
                'accepted_actor_reference' => $identity['customer_unification_id'] ?? ($identity['contact_public_id'] ?? $identity['company_public_id'] ?? null),
                'acceptance_session_id' => $payload['session_id'] ?? ($context['session_id'] ?? null),
                'customer_identity_reference' => $identity['customer_unification_id'] ?? ($identity['contact_public_id'] ?? $identity['company_public_id'] ?? null),
            ], 'titan_hub');

            return $this->commandResult($command, 'quote') + [
                'source' => 'crm',
                'kind' => rtrim($type, 's'),
                'id' => $this->externalId($type, $publicId),
                'record_id' => $publicId,
            ];
        });
    }

    public function invoices(array $context, array $filters=[]): array
    {
        return $this->withCustomerCompany($context, function () use ($context, $filters): array {
            $base = $this->inner->invoices($context, $filters);
            $identity = $this->identities->resolveCustomer($context);
            if (! $identity) {
                return $base;
            }
            if ((bool) config('crm.titan_mobile.require_verified_financial_identity', true) && ! $identity['verified']) {
                return $base;
            }
            return array_merge($base, $this->crmInvoices($identity, $filters));
        });
    }

    public function invoice(array $context, string $id): ?array
    {
        return $this->withCustomerCompany($context, function () use ($context, $id): ?array {
            $identity = $this->identities->resolveCustomer($context);
            if (! $identity) {
                return $this->inner->invoice($context, $id);
            }
            if ((bool) config('crm.titan_mobile.require_verified_financial_identity', true) && ! $identity['verified']) {
                throw new AuthorizationException('Verified customer identity is required.');
            }

            $publicId = $this->stripPrefix($id, 'crm:invoice:');
            $row = $this->db->table('crm_invoices')
                ->where('company_id', $identity['company_id'])
                ->where('public_id', $publicId)
                ->where('contact_public_id', $identity['crm_contact_public_id'])
                ->whereNull('deleted_at')
                ->first();
            if ($row) {
                return $this->formatInvoice((array) $row);
            }

            return str_starts_with($id, 'crm:invoice:') ? null : $this->inner->invoice($context, $id);
        });
    }

    public function documents(array $context, array $filters=[]): array
    {
        return $this->withCustomerCompany($context, function () use ($context, $filters): array {
            $base = $this->inner->documents($context, $filters);
            $identity = $this->identities->resolveCustomer($context);
            if (! $identity) {
                return $base;
            }

            $documents = [];
            foreach ($this->crmQuotes($identity, $filters) as $row) {
                $documents[] = [
                    'source' => 'crm', 'kind' => $row['kind'], 'id' => $row['id'],
                    'record_id' => $row['record_id'], 'title' => $row['title'],
                    'status' => $row['status'], 'created_at' => $row['created_at'] ?? null,
                ];
            }
            if ($identity['verified']) {
                foreach ($this->crmInvoices($identity, $filters) as $row) {
                    $documents[] = [
                        'source' => 'crm', 'kind' => 'invoice', 'id' => $row['id'],
                        'record_id' => $row['record_id'], 'title' => $row['title'],
                        'status' => $row['status'], 'created_at' => $row['created_at'] ?? null,
                    ];
                }
            }

            return array_merge($base, $documents);
        });
    }

    public function profile(array $context): array
    {
        return $this->withCustomerCompany($context, function () use ($context): array {
            $identity = $this->identities->resolveCustomer($context);
            return $identity ? [
                'identity_state' => $identity['identity_state'],
                'verified' => $identity['verified'],
                'contact' => $identity['contact'],
                'company' => $identity['company'],
            ] : [];
        });
    }

    private function commandResult(array $command, string $kind): array
    {
        $executed = ($command['executed'] ?? false) === true && ($command['authoritative'] ?? false) === true;
        return [
            'ok' => $executed,
            'status' => $executed ? 'applied' : (string) ($command['status'] ?? 'awaiting_command_bus'),
            'kind' => $kind,
            'authoritative' => $executed,
            'result' => $command['result'] ?? null,
            'receipt' => $command['receipt'] ?? null,
        ];
    }

    private function withCustomerCompany(array $context, callable $callback): mixed
    {
        $companyId = (int) ($context['tenant_id'] ?? 0);
        if ($companyId <= 0) {
            throw new AuthorizationException('Trusted Titan Hub company context is missing.');
        }
        $trusted = $this->companyContexts->fromTrustedPlatform(
            $companyId,
            null,
            'customer',
            permissions: ['crm.customer.operations'],
            sourceSurface: 'customer',
            membershipVerified: true,
        );
        return $this->companyScope->runWith($trusted, fn() => $callback());
    }

    private function crmQuotes(array $identity, array $filters): array
    {
        $items = [];
        foreach (['proposals', 'estimates'] as $type) {
            foreach ($this->scopedSales($identity, $type, $filters) as $row) {
                $items[] = $this->formatQuote($type, $row);
            }
        }
        return $items;
    }

    private function formatQuote(string $type, array $row): array
    {
        return [
            'source' => 'crm',
            'kind' => rtrim($type, 's'),
            'id' => $this->externalId($type, (string) $row['public_id']),
            'record_id' => $row['public_id'],
            'number' => $row['number'] ?? null,
            'title' => $row['title'],
            'status' => $row['status'],
            'currency' => $row['currency'],
            'total_minor' => (int) $row['total_minor'],
            'due_at' => $row['due_at'] ?? null,
            'created_at' => $row['created_at'] ?? null,
        ];
    }

    private function crmInvoices(array $identity, array $filters): array
    {
        return array_map(fn(array $row) => $this->formatInvoice($row), $this->scopedSales($identity, 'invoices', $filters));
    }

    private function formatInvoice(array $row): array
    {
        return $row + [
            'source' => 'crm',
            'kind' => 'invoice',
            'id' => $this->externalId('invoices', (string) $row['public_id']),
            'record_id' => $row['public_id'],
        ];
    }

    private function scopedSales(array $identity, string $type, array $filters=[]): array
    {
        $query = $this->db->table('crm_' . $type)
            ->where('company_id', $identity['company_id'])
            ->where('contact_public_id', $identity['crm_contact_public_id'])
            ->whereNull('deleted_at');
        if (! empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }
        return $query->orderByDesc('id')->limit($this->limit($filters))->get()->map(fn($row) => (array) $row)->all();
    }

    private function projects(array $identity, int $limit): array
    {
        return $this->db->table('crm_projects')
            ->where('company_id', $identity['company_id'])
            ->where('contact_public_id', $identity['crm_contact_public_id'])
            ->whereNull('deleted_at')
            ->orderByDesc('id')
            ->limit($limit)
            ->get()
            ->map(fn($row) => (array) $row)
            ->all();
    }

    private function crmQuoteReference(array $identity, string $id): ?array
    {
        if (preg_match('/^crm:(proposal|estimate):(.+)$/', $id, $match)) {
            return [$match[1] === 'proposal' ? 'proposals' : 'estimates', $match[2]];
        }
        foreach (['proposals', 'estimates'] as $type) {
            if ($this->db->table('crm_' . $type)
                ->where('company_id', $identity['company_id'])
                ->where('contact_public_id', $identity['crm_contact_public_id'])
                ->where('public_id', $id)
                ->whereNull('deleted_at')
                ->exists()) {
                return [$type, $id];
            }
        }
        return null;
    }

    private function assertOwnsSales(array $identity, string $type, string $id): void
    {
        if (! $this->db->table('crm_' . $type)
            ->where('company_id', $identity['company_id'])
            ->where('contact_public_id', $identity['crm_contact_public_id'])
            ->where('public_id', $id)
            ->whereNull('deleted_at')
            ->exists()) {
            throw new AuthorizationException('Quote is not available to this customer.');
        }
    }

    private function externalId(string $type, string $id): string
    {
        return match ($type) {
            'proposals' => 'crm:proposal:',
            'estimates' => 'crm:estimate:',
            'invoices' => 'crm:invoice:',
            default => 'crm:' . rtrim($type, 's') . ':',
        } . $id;
    }

    private function stripPrefix(string $id, string $prefix): string
    {
        return str_starts_with($id, $prefix) ? substr($id, strlen($prefix)) : $id;
    }

    private function limit(array $filters): int
    {
        return min(max((int) ($filters['limit'] ?? 50), 1), 100);
    }
}
