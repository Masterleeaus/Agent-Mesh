<?php

declare(strict_types=1);

namespace Tests\Feature;

use PHPUnit\Framework\TestCase;

final class CapabilityIsolationTest extends TestCase
{
    public function test_success_for_one_capability_does_not_mutate_another_capability_state(): void
    {
        $state = [
            'appointment.reminder.send' => ['streak' => 0],
            'crm.invoice.issue' => ['streak' => 0],
        ];
        $state['appointment.reminder.send']['streak']++;

        self::assertSame(1, $state['appointment.reminder.send']['streak']);
        self::assertSame(0, $state['crm.invoice.issue']['streak']);
    }
}
