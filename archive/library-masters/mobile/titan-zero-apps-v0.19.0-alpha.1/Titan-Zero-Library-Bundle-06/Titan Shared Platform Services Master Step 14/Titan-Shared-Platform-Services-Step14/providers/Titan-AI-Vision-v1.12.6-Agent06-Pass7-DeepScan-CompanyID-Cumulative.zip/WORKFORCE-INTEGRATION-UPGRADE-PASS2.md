# Agent-06 Upgrade Pass 2 — Operational Workforce Provider Contract v1.1

Version: `1.12.6`

## Upgrade
- Promoted `workforce-integration.json` from schema 1.0 to 1.1.
- Added one machine-readable execution contract for every published capability.
- Classified each capability as read-only, proposal-only or command-bus-only.
- Added explicit risk, offline, reversibility, idempotency, retry, provenance and deterministic-degradation semantics.
- State-changing commands require fresh Titan Autonomy evaluation and execution receipts.
- Added provider-health semantics that default unavailable and fail closed.
- Added central Workforce work-item context requirements while preserving Titan AI Workforce ownership of employee identity, hierarchy and work items.
- Added contract-level Signal declarations without pretending runtime signal wiring exists before a binding is installed.
- Added a standalone v1.1 verifier.

## Tenancy and authority
Runtime provider contracts use canonical `company_id`. Installation, role maturity, hierarchy, delegation, substitution or provider presence cannot raise effective authority. Titan Autonomy remains the runtime authority owner.
