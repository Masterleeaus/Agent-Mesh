# Troubleshooting

Run `php artisan titan:titan-prime:certify --json` to check PHP/Laravel compatibility, provider loading, storage, MySQL connectivity, manifest parsing, owned table presence and Prime routes. A failed check is evidence of the specific host integration problem; it does not authorize Prime to repair or bypass host controls automatically.
