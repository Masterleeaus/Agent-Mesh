<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$migration = (string) file_get_contents($root.'/database/migrations/2026_08_20_000004_add_governed_action_metadata.php');

function mrfail(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function mrok(bool $condition, string $message): void { if (!$condition) mrfail($message); }

// Live Installer 1.7.6 / MySQL 1059 reproduction: Laravel's implicit name is 65 chars.
$bad = 'titan_governance_policy_decisions_authoritative_receipt_ref_index';
mrok(strlen($bad) === 65, 'regression fixture must reproduce the 65-character MySQL identifier');
mrok(!str_contains($migration, "authoritative_receipt_ref',191)->nullable()->index()"), 'authoritative receipt column must not rely on the overlong implicit index name');
mrok(str_contains($migration, "'tgov_policy_auth_receipt_idx'"), 'migration must use a short explicit authoritative receipt index name');
mrok(strlen('tgov_policy_auth_receipt_idx') <= 64, 'explicit authoritative receipt index must fit MySQL identifier limit');

// The failed fourth migration may have added the column before its index command failed.
mrok(str_contains($migration, "Schema::hasIndex('titan_governance_policy_decisions',['authoritative_receipt_ref'])"), 'retry must detect an already-present authoritative receipt index by columns');
mrok(str_contains($migration, "Schema::hasIndex('titan_governance_policy_decisions',['tenant_company_id','operation_id'],'unique')"), 'retry must guard the operation id unique index');

// All new single-column indexes in 000004 must be explicit and guarded so any later partial DDL failure is restartable.
foreach ([
    'subject_type', 'subject_id', 'action', 'payload_hash', 'command_status',
    'command_receipt_ref', 'authoritative_receipt_ref', 'write_verified',
] as $column) {
    mrok(str_contains($migration, "Schema::hasIndex('titan_governance_policy_decisions',['{$column}'])"), "policy decision index {$column} must be restart-guarded");
}
foreach (['version', 'resolution_action', 'last_decision_id', 'last_command_receipt_ref'] as $column) {
    mrok(str_contains($migration, "Schema::hasIndex('titan_governance_escalations',['{$column}'])"), "escalation index {$column} must be restart-guarded");
}

// Down path must tolerate partial state instead of assuming every column/index exists.
mrok(str_contains($migration, "Schema::hasIndex('titan_governance_policy_decisions',['tenant_company_id','operation_id'],'unique')"), 'down/up must safely inspect unique index state');
mrok(str_contains($migration, '$policyColumns = array_values(array_filter('), 'down path must drop only policy columns that actually exist');
mrok(str_contains($migration, '$escalationColumns = array_values(array_filter('), 'down path must drop only escalation columns that actually exist');


$verify = (string) file_get_contents($root.'/bin/verify.php');
mrok(str_contains($verify, 'tgov_policy_auth_receipt_idx'), 'self verifier must cover H2 safe MySQL index');
mrok(str_contains($verify, 'migration 000004 restartability'), 'self verifier must cover H2 restartability');

$preflight = (string) file_get_contents($root.'/System/Host/TitanFreshInstallPreflight.php');
mrok(str_contains($preflight, "mysql_identifier_safety"), 'fresh-install preflight must expose MySQL identifier safety');
mrok(str_contains($preflight, "migration_000004_restartable"), 'fresh-install preflight must expose 000004 restartability');

echo "PASS: Installer 1.7.6 MySQL migration restart contract\n";
