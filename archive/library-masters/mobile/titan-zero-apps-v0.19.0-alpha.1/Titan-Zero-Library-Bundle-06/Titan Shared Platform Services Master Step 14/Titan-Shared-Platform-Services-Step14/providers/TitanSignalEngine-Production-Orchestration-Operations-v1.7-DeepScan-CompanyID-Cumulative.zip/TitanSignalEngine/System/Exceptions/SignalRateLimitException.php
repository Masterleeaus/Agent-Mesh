<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Exceptions;

use RuntimeException;

final class SignalRateLimitException extends RuntimeException
{
    public function __construct(string $message, public readonly int $retryAfterSeconds = 60)
    {
        parent::__construct($message, 429);
    }
}
