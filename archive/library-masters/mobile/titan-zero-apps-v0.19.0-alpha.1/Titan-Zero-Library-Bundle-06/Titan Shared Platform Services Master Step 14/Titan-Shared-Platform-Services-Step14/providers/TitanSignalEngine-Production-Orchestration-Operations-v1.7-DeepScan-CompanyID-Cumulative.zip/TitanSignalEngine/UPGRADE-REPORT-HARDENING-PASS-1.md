# Production Hardening Pass 1 — Trusted Execution Context & Tenant Boundary Lockdown

## Baseline

Titan Signal Engine v0.8.0 cumulative Pass 8.

## Changes

- Removed nullable/default SignalContext authorization from public emit/query/correlation/Pulse/anomaly/lifecycle contracts.
- Added `SignalEmitterIdentity` and `SignalEmitterAuthority`.
- Trusted emitter definitions bind service ID to source, source component, permissions and event-type families.
- Emitter grants are HMAC-attested using a key derived from Laravel `app.key`.
- New emissions persist checksum-covered `emitter_id`.
- Source and source-component claims are validated then overwritten from the trusted grant.
- Contextless tenant reads are rejected.
- Global Signal health now requires `signal.health.read`.
- Added additive nullable `emitter_id` migration; historical events retain checksum compatibility.
- Signal subscription-failure and anomaly telemetry now use dedicated internal emitter grants.
- Added standalone regression runner covering contextless reads, tenant mismatch, source spoofing, event-family authorization and forged emitter attestation.

## Deferred to later hardening passes

Registry ownership/versioning, atomic delivery leases, DLQ redrive, archive reads, transactional prune manifests and remaining production-host concurrency/load validation are deliberately unchanged here.
