<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
$errors=[];
$registrar=$root.'/System/Host/GovernanceMenuRegistrar.php';
if(!is_file($registrar)) $errors[]='GovernanceMenuRegistrar missing';
$provider=(string)file_get_contents($root.'/System/TitanGovernanceServiceProvider.php');
$adapter=(string)file_get_contents($root.'/System/Host/TitanMenuCompatibilityAdapter.php');
if(!str_contains($provider,'GovernanceMenuRegistrar::class')) $errors[]='provider does not bind GovernanceMenuRegistrar';
if(!str_contains($provider,"try { \$this->registerNavigation(); } catch (Throwable)")) $errors[]='navigation is not registered synchronously during provider boot';
if(str_contains($provider,'$this->app->booted(fn () => $this->registerNavigation())')) $errors[]='deferred booted navigation callback remains';
if(!str_contains($adapter,"app()->bound('MenuContributionRegistry')")) $errors[]='exact MenuContributionRegistry compatibility binding missing';
foreach(['App\\Support\\Extensions\\MenuContributionRegistry','App\\Support\\Extensions\\ContributionRegistry'] as $b){
    if(str_contains($adapter,$b)) $errors[]='broad/guessed registry binding remains: '.$b;
}
if(is_file($registrar)){
    $r=(string)file_get_contents($registrar);
    foreach([
        'Titan Governance',
        'Overview',
        'Control Centre',
        'Escalations',
        'Signal Heatmap',
        'Operational Pressure',
        'Circuit Breakers',
        'Workforce Oversight',
        'dashboard.user.titan.governance.index',
        'dashboard.user.titan.governance.control-centre',
        'dashboard.user.titan.governance.escalations.queue',
        'dashboard.user.titan.governance.signal-heatmap',
        'dashboard.user.titan.governance.operational-pressure',
        'dashboard.user.titan.governance.circuit-breakers',
        'dashboard.user.titan.governance.workforce-oversight',
        "'legacy_identity' => ['key' => \$key]",
        "'legacy_fallback_identity' => ['route' => \$route]",
        "'parent_key' => \$parentKey",
    ] as $needle){ if(!str_contains($r,$needle)) $errors[]='registrar missing '.$needle; }
    if(str_contains($r,'fa-solid ')||str_contains($r,'fa-regular ')) $errors[]='Font Awesome class used in MagicAI menu icon';
}
if($errors){fwrite(STDERR,"FAIL: ".implode('; ',$errors)."\n");exit(1);}echo "PASS: Installer 1.7.6 Governance menu visibility contract\n";
