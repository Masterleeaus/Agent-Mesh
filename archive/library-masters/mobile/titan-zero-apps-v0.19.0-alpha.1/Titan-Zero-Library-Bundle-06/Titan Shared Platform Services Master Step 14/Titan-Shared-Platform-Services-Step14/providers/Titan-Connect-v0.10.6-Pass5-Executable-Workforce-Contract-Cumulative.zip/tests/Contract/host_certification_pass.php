<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$passes = [];
$read = static fn (string $path): string => is_file($root.'/'.$path) ? (string) file_get_contents($root.'/'.$path) : '';
$check = static function (bool $condition, string $name) use (&$passes, &$failures): void {
    if ($condition) $passes[] = $name; else $failures[] = $name;
};

$contract = $read('System/Contracts/CompanyOwnedModel.php');
$trait = $read('System/Models/Concerns/BelongsToCompany.php');
$middleware = $read('System/Http/Middleware/EnsureCompanyRouteBindings.php');
$apiRoutes = $read('routes/api.php');
$webRoutes = $read('routes/web.php');
$job = $read('System/Jobs/ProcessInboundWebhookJob.php');
$webhookController = $read('System/Http/Controllers/WebhookController.php');
$delivery = $read('System/Delivery/OutboundDeliveryService.php');
$upload = $read('System/Attachments/AttachmentUploadService.php');
$ingest = $read('System/Attachments/InboundAttachmentIngestService.php');
$attachmentController = $read('System/Http/Controllers/AttachmentController.php');
$hostTest = $read('tests/Feature/HostCertification/CompanyBoundaryTest.php');
$hostDoc = $read('docs/HOST_CERTIFICATION.md');
$rateMiddleware = $read('System/Http/Middleware/EnforceCompanyRateLimit.php');
$diagnoseCommand = $read('System/Console/DiagnoseTitanConnectCommand.php');
$voiceHardening = $read('database/migrations/2026_08_09_000005_harden_voice_runtime.php');
$diagnosticsController = $read('System/Http/Controllers/DiagnosticsController.php');

$check(str_contains($contract, 'interface CompanyOwnedModel') && str_contains($contract, 'companyId(): int'), 'MODEL CompanyOwnedModel contract exists');
$check(str_contains($trait, 'trait BelongsToCompany') && str_contains($trait, 'scopeForCompany') && str_contains($trait, 'company_id cannot be changed'), 'MODEL company trait provides scope and immutable boundary');

$modelPaths = array_merge(glob($root.'/System/Models/*.php') ?: [], glob($root.'/System/Models/TeamChat/*.php') ?: []);
foreach ($modelPaths as $path) {
    $source = (string) file_get_contents($path);
    if (!str_contains($source, "'company_id'")) continue;
    $relative = str_replace($root.'/', '', $path);
    $check(str_contains($source, 'implements CompanyOwnedModel') && str_contains($source, 'use BelongsToCompany;'), 'MODEL company-owned invariant: '.$relative);
}

$check(str_contains($middleware, 'EnsureCompanyRouteBindings') && str_contains($middleware, 'CompanyOwnedModel') && str_contains($middleware, 'abort(404)'), 'ROUTING central cross-company binding middleware exists');
$check(str_contains($apiRoutes, 'EnsureCompanyRouteBindings::class') && str_contains($webRoutes, 'EnsureCompanyRouteBindings::class'), 'ROUTING authenticated API and web groups use company binding middleware');

$check(str_contains($job, 'public readonly int $companyId') && str_contains($job, 'public readonly string $connectionUuid') && str_contains($job, 'public readonly string $provider'), 'QUEUE webhook job serializes company + UUID + provider identity');
$check(str_contains($job, '->forCompany($this->companyId)') && str_contains($job, "where('uuid', \$this->connectionUuid)") && str_contains($job, "where('provider', strtolower(trim(\$this->provider)))"), 'QUEUE webhook job re-resolves exact company connection');
$check(str_contains($webhookController, 'new ProcessInboundWebhookJob(') || str_contains($webhookController, 'ProcessInboundWebhookJob::dispatch('), 'QUEUE webhook controller dispatches scoped job');
$check(str_contains($webhookController, '(int) $connection->company_id') && str_contains($webhookController, '(string) $connection->uuid') && str_contains($webhookController, '(string) $connection->provider'), 'QUEUE dispatch includes company/UUID/provider');
$check(str_contains($delivery, "where('company_id', (int) \$delivery->company_id)") && str_contains($delivery, 'lockForUpdate'), 'DELIVERY row claim is company scoped');

$check(str_contains($upload, "'titan-connect/company/%d/") || str_contains($upload, 'titan-connect/company/%d/'), 'STORAGE staff uploads are company namespaced');
$check(str_contains($ingest, "'titan-connect/company/%d/") || str_contains($ingest, 'titan-connect/company/%d/'), 'STORAGE inbound media is company namespaced');
$check(str_contains($attachmentController, '(int) $attachment->company_id !== $companyId'), 'STORAGE provider download enforces signed company ownership');

$check(str_contains($hostTest, 'class CompanyBoundaryTest') && str_contains($hostTest, 'company_id') && str_contains($hostTest, 'getStatusCode'), 'HOST executable Laravel company-boundary feature test is shipped');
$check(str_contains($hostDoc, 'MySQL') && str_contains($hostDoc, 'php artisan test') && str_contains($hostDoc, 'company_id'), 'HOST certification runbook documents MySQL/Laravel execution');
$check(str_contains($rateMiddleware, 'companyId') && str_contains($rateMiddleware, 'actorId') && str_contains($rateMiddleware, 'RateLimiter'), 'HOST authenticated rate limits are company/actor scoped');
$check(str_contains($diagnosticsController, 'canManage') && str_contains($diagnosticsController, 'companyId'), 'HOST diagnostics are company scoped and management protected');
$check(str_contains($voiceHardening, 'client_event_id') && str_contains($voiceHardening, 'tc_voice_transcript_event_unique'), 'HOST voice transcript idempotency schema is shipped');
$check(str_contains($diagnoseCommand, 'titan-connect:diagnose') && str_contains($diagnoseCommand, 'HostReadinessService'), 'HOST readiness command is shipped');

foreach ($passes as $pass) echo "PASS {$pass}\n";
if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL {$failure}\n");
    fwrite(STDERR, sprintf("\n%d failed; %d passed.\n", count($failures), count($passes)));
    exit(1);
}

echo sprintf("\nOK Titan Connect host-certification contract suite: %d passed.\n", count($passes));
