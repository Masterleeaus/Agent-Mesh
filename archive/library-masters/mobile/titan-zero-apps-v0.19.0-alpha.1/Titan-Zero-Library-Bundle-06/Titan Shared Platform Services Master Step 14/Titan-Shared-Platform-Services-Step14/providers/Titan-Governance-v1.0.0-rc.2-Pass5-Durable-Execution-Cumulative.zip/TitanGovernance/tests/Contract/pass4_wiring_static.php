<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);$errors=[];
foreach(['/System/Http/Controllers/GovernanceActionController.php','/System/Actions/GovernanceActionService.php','/System/Escalation/GovernanceEscalationTarget.php'] as $f)if(!is_file($root.$f))$errors[]='missing '.$f;
$provider=(string)file_get_contents($root.'/System/TitanGovernanceServiceProvider.php');$contract=(string)file_get_contents($root.'/System/Contracts/GovernanceManagerContract.php');$manager=(string)file_get_contents($root.'/System/Services/GovernanceManager.php');$routes=(string)file_get_contents($root.'/routes/user.php');$view=(string)file_get_contents($root.'/resources/views/index.blade.php');$config=(string)file_get_contents($root.'/config/titan-governance.php');$manifest=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
foreach(['GovernanceCommandGatewayContract','GovernanceActionDecisionStoreContract','GovernanceEscalationStoreContract','GovernanceActionService','GovernanceEscalationTarget'] as $n)if(!str_contains($provider,$n))$errors[]='provider missing '.$n;
foreach(['escalationQueue','performEscalationAction'] as $n)if(!str_contains($contract,$n)||!str_contains($manager,$n))$errors[]='manager missing '.$n;
foreach(['escalations','actions'] as $n)if(!str_contains($routes,$n))$errors[]='route missing '.$n;
foreach(['Escalation Queue','APPROVE','REJECT','HOLD','ESCALATE'] as $n)if(!str_contains($view,$n))$errors[]='view missing '.$n;
if(!str_contains($config,'command_gateway_class'))$errors[]='config missing command gateway class binding';
foreach(['titan-governance.escalations.act','titan-governance.exceptions.grant'] as $p)if(!in_array($p,$manifest['permissions']??[],true))$errors[]='manifest permission missing '.$p;
foreach(['governance.escalation.queue.read','governance.escalation.approve','governance.escalation.reject','governance.escalation.hold','governance.escalation.exception','governance.escalation.escalate'] as $c)if(!in_array($c,$manifest['capabilities']??[],true))$errors[]='manifest capability missing '.$c;
if($errors){fwrite(STDERR,"FAIL: ".implode(', ',$errors)."\n");exit(1);}echo "PASS: Governance Pass 4 wiring\n";
