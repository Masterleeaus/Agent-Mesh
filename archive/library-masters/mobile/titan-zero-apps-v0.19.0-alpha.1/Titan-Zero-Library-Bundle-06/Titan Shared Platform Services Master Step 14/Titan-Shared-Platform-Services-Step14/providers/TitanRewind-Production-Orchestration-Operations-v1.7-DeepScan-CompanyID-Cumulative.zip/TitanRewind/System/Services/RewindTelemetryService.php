<?php

declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Services;
use App\Extensions\TitanRewind\System\Models\RewindObservabilityEvent;
use App\Extensions\TitanRewind\System\Observability\RewindTelemetryRecord;
use App\Extensions\TitanRewind\System\Observability\RewindTraceContext;
use Illuminate\Support\Facades\Log;
use Throwable;
final class RewindTelemetryService
{
    public function metric(string $name, int|float $value, string $unit, RewindTraceContext $context, array $attributes=[]): void { $this->persist(RewindTelemetryRecord::metric($name,$value,$unit,$context,$attributes)); }
    public function span(string $name, int|float $durationMs, string $status, RewindTraceContext $context, array $attributes=[]): void { $this->persist(RewindTelemetryRecord::span($name,$durationMs,$status,$context,$attributes)); }
    public function log(string $name, string $level, RewindTraceContext $context, array $attributes=[]): void { $this->persist(RewindTelemetryRecord::log($name,$level,$context,$attributes)); }
    public function persist(array $record): void
    {
        $payload=$record; $payload['occurred_at']=now();
        try { RewindObservabilityEvent::query()->create($payload); } catch (Throwable $e) { Log::warning('Titan Rewind telemetry persistence failed',['exception'=>$e::class,'message'=>$e->getMessage()]); }
        $level=strtolower((string)($record['level'] ?? 'info')); if (!in_array($level,['debug','info','notice','warning','error','critical'],true)) $level='info';
        Log::log($level,(string)($record['name'] ?? 'rewind.telemetry'),$record);
    }
}
