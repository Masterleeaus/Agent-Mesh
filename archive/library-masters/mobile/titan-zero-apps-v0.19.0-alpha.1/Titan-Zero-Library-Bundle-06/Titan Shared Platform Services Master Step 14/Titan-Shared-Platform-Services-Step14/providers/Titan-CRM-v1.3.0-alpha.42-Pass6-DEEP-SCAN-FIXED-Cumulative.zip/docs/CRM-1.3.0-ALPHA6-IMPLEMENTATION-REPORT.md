# CRM 1.3.0-alpha.6 Implementation Report

## Purpose
Make CRM behave like the core Titan business operating surface rather than a single nested CRM module, while fixing the live runtime schema error reported on `crm_activities.deleted_at`.

## Runtime defect root cause
`crm_activities` was created without a `deleted_at` column and migration 000002 intentionally hardened the activity stream without adding soft deletes. Three read paths nonetheless applied `whereNull('deleted_at')`, causing MySQL 1054 at runtime.

Fixed read paths:
- `System/Services/CrmViewDataService.php`
- `System/Services/CrmTimelineService.php`
- `System/Integrations/Chatbot/CrmChatbotToolService.php`

A related contacts-list query was also corrected from actor `c.user_id` filtering to `c.tenant_company_id`.

## Navigation architecture
Top-level order:
1. Overview
2. Customers
3. Sales
4. Work
5. Money
6. Crew
7. Gear
8. Insights
9. Automate
10. Settings

### Customers
Companies, Contacts, Customer Portal, Support, Reviews & Recovery, Sharing.

### Sales
Leads, Deals, Pipelines, Proposals, Estimates.

### Work
Work Overview, Service Requests, Work Orders, Projects, Tasks, Recurring Work, Services & Catalogue, Service Locations, Forms, Service Areas, Vertical Profiles.

### Money
Invoices, Payments, Titan Pay, Bookkeeping.

### Crew
Schedule, Dispatch, Calendar.

### Gear
Locker Overview, Purchase Orders, Goods Receipts, Stock Counts, Stock Transfers, Customer Assets.

### Insights
Reports, Presentations, Data Quality.

### Automate
CRM Assistant, Automations, Integrations.

### Settings
CRM Settings, Fields & Tags, Import / Export, Privacy & Retention.

## Menu persistence
The previous package had a `CrmMenuSeeder`, but Titan's custom extension flow guarantees extension migrations, not application seeders. Alpha.6 introduces:
- `System/Navigation/CrmMenuInstaller.php`
- `database/migrations/2026_08_09_000021_alpha6_sync_crm_core_menu.php`

The installer reads the actual host `menus` column list and writes only supported columns. It updates existing keys instead of creating duplicate navigation rows. The old Dashboard child is disabled because Overview is now a top-level item.

Rollback restores the alpha.5 CRM/Sales parent structure and disables alpha.6-only menu rows.

## Theme behaviour
CRM views no longer use fixed `success`, `danger`, `warning`, `info`, `dark` or `light` button palette classes. Actions use theme-controlled primary/outline treatments. The standalone portal button no longer embeds a fixed hexadecimal background.

## Verification intent
Alpha.6 adds static regression gates for runtime/schema consistency, route-backed menu definitions, adaptive menu registration and theme-controlled button styling. All inherited provider-stage, MySQL identifier, timestamp, restartability, Locker/Pay/Bookkeeping and package integrity gates remain mandatory.
