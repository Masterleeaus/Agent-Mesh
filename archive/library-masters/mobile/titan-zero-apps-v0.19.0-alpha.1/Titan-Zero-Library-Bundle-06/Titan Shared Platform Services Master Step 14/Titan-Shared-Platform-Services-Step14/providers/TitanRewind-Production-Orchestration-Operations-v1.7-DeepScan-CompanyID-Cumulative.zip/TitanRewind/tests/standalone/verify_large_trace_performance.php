<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);require_once $root.'/System/Streaming/RewindStreamWindow.php';require_once $root.'/System/Certification/RewindPerformanceBudget.php';
use App\Extensions\TitanRewind\System\Streaming\RewindStreamWindow;use App\Extensions\TitanRewind\System\Certification\RewindPerformanceBudget;
$before=memory_get_usage(true);$start=hrtime(true);$window=new RewindStreamWindow(5000);$result=$window->consume((function(){for($i=1;$i<=100000;$i++)yield ['sequence'=>$i,'event_id'=>sprintf('%08d',$i)];})());$elapsed=(hrtime(true)-$start)/1e6;$delta=max(0,(memory_get_peak_usage(true)-$before)/(1024*1024));
$checks=[count($result['items'])===5000,$result['observed_count']===100000,$result['truncated']===true,$delta<256,$elapsed<5000];
$budget=(new RewindPerformanceBudget(256,5000,5000))->evaluate(['peak_memory_mb'=>$delta,'max_events_in_memory'=>count($result['items']),'reconstruction_p95_ms'=>$elapsed]);$checks[]=($budget['passed']??false)===true;
if(in_array(false,$checks,true)){fwrite(STDERR,json_encode(['memory_mb'=>$delta,'elapsed_ms'=>$elapsed,'result'=>$result,'budget'=>$budget],JSON_PRETTY_PRINT)."\n");exit(1);}printf("Large trace performance: 6/6 PASS; events=100000 retained=5000 peak_delta_mb=%.2f elapsed_ms=%.2f\n",$delta,$elapsed);
