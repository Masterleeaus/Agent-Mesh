# CRM alpha.30 Invoice & Receivables Authority Report

## Authority boundary
CRM owns invoice contracts, amount owed, credit notes, receivable balances, ageing and reconciliation evidence. Titan Pay owns payment/refund execution and provider-side state. Titan Ledger owns accounting truth.

## Settlement evidence
`crm.invoice.settlement.record_verified` accepts only explicitly verified Titan Pay outcomes, requires stable idempotency, hashes the canonical payload, and records provider/external references. Conflicting or impossible outcomes create durable reconciliation issues rather than silently changing receivable truth.

## Credit notes and refunds due
Issued credit notes reduce the net charge. If cash received exceeds the post-credit charge, CRM records `refund_due_minor` and surfaces it operationally; Titan Pay performs the refund and returns a verified refund reference.

## Lineage
Invoices may preserve an accepted quote revision/hash and an opaque Titan Field work-order reference. CRM does not query Titan Field tables to determine billability.

## Upgrade safety
Legacy CRM payment/allocation rows are preserved. Where present they are backfilled as `legacy-crm` settlement evidence. Fresh installs do not recreate local payment-processing authority.
