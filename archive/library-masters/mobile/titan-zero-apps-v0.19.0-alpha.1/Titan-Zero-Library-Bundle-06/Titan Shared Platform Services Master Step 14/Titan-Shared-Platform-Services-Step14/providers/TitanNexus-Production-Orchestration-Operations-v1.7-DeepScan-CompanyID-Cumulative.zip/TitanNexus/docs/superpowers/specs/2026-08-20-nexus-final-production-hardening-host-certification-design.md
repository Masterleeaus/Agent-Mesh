# Titan Nexus Final Production Hardening & Host Certification Design

## Goal
Prepare Titan Nexus for production promotion by closing host compatibility, navigation, authorization, installer verification, exact-host certification, and release provenance gaps without changing deterministic compiler semantics or bypassing governed provisioning.

## Release policy
The package may advance to `1.0.0-rc.1` when package-level certification passes. Promotion to final `1.0.0` requires live exact-host certification of Installer 1.7.8 migration, boot, navigation, authorization, runtime, upgrade, disable, and uninstall stages on the target MagicAI host.

## Architecture
- Preserve `configuration-orchestrator` / `configuration-compiler` manifest v2.2 profile.
- Add host adapters under the Nexus namespace; no direct imports from other Titan extension implementations.
- Register Nexus navigation through `MenuContributionRegistry` when available, with the Step-10 MagicAI menus-table/MenuService fallback isolated inside the host compatibility adapter.
- Preserve tenant-scoped read models and the governed Command Bus mutation path.
- Add machine-readable exact-host profile and certification report artifacts.
- Provide deterministic package certification scripts that can run outside Laravel and a live-host harness that refuses to claim stages it did not execute.

## Navigation
Register one Titan Nexus parent plus nine user child destinations: Overview, Business Profile, Compilations, Validation, Configuration Preview, History, Recompile / Diff, Provisioning Plans, Provisioning Receipts. Existing host order/enabled state must be preserved on self-heal.

## Authorization
Super Admin remains the unconditional host bypass. Delegated admins require bounded permissions. Admin diagnostics remain protected by the host `admin` middleware. Authenticated tenant users may access the read-only Control Centre only through the existing tenant-context resolver; no mutation route is added.

## Certification
Package certification checks flat ZIP root, exact Installer 1.7.8 integrity map, manifest v2.2, Interface v1.1, MySQL migration compatibility, route/view/menu contract, provider registration bindings, architecture boundaries, tenant-scoped reads, and immutable historical migrations.

Live exact-host stages are: PACKAGE_CERTIFIED, INSTALLER_CERTIFIED, MIGRATION_CERTIFIED, BOOT_CERTIFIED, NAVIGATION_CERTIFIED, AUTHORIZATION_CERTIFIED, RUNTIME_CERTIFIED, UPGRADE_CERTIFIED, UNINSTALL_CERTIFIED. Only PACKAGE_CERTIFIED may be marked PASS in this environment.

## Versioning
Nexus runtime becomes `1.0.0-rc.1`; deterministic compiler remains `0.5.0` because compiler semantics are unchanged.
