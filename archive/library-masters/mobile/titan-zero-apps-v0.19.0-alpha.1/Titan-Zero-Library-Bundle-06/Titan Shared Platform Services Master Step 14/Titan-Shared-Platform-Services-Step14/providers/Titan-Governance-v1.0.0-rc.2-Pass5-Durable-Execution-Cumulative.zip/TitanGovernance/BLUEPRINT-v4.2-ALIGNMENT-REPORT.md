# Titan Governance v1.0.0-rc.1 — Blueprint v4.2.2 + Live Installer 1.7.6 Alignment

Blueprint v4.2.2 remains the architecture/sidecar baseline. The root manifest additionally retains the observed MagicAI Installer 1.7.6 host-facing legacy fields. Where a strict Blueprint-only root schema rejects those extra host fields, the combined host manifest contract is authoritative for this live-target RC while Blueprint architecture/MySQL/package scans remain mandatory.


Titan Governance remains a Manifest 2.2 `governance-engine` with `signal-aware`, `autonomy-aware`, and `regulated` modifiers and canonical ownership of the `governance-control-plane` family only.

## Pass 4 alignment

- Human Governance decisions are persisted as Governance-owned control-plane truth.
- Titan Command Bus remains canonical owner of governed mutation and the only outbound action path.
- Governance does not claim CRM/business truth or Risk/Assurance/Autonomy/Signal/Workforce ownership.
- The Governance action gateway defaults fail closed and never guesses Command Bus internal classes.
- APPLIED results require Command Bus receipt, authoritative domain receipt and `write_verified=true`.
- Tenant/actor/causal authority is server mapped; client authority injection is rejected.
- Semantic idempotency is tenant + operation scoped and excludes fresh transport traces.
- Escalation transitions are optimistic-concurrency protected and mutate only Governance-owned state.
- Exceptions require a distinct permission in addition to general escalation action permission.
- Action POST routes inherit `web + auth` CSRF protection and add explicit request throttling.
- Authority upper-bound rules remain unchanged: Governance cannot raise Titan Autonomy's earned/effective authority.

## Certification truth

Package/source verification can be certified in isolation. Actual provider boot, MySQL migration execution, authenticated route behavior, real Command Bus gateway binding/target registration, Signal/Autonomy adapters and browser UI require the deployed MagicAI/Titan host and remain `NOT_RUN` until tested there.

## Pass 5 — Decision Intelligence alignment

- Governance remains the owner only of Governance policy decisions/control-plane projections.
- Cross-engine decision evidence is read through explicit adapters and sanitized before aggregation.
- Risk/Assurance/Autonomy/Signal/Rewind/Command Bus ownership is preserved.
- Rewind Theater never reconstructs Rewind state locally.
- Delta Viewer reports differences, not inferred causality.
- `tenant_company_id` is now resolved only from explicit tenant/company context; user/team-derived synthetic tenant IDs were removed.

## Pass 5 certification baseline

- Executable certification standard: **Titan Extension Blueprint v4.2.2 — Deep-Scan Remediated Cumulative**.
- Blueprint package SHA-256: `567167d6e69200620aaf01ebd591372a08acb6bfde278dbe613e76bc7c159515`.
- Pass 5 is certified against the v4.2.2 canonical Manifest 2.2 validator, production source gates, architecture scanner, MySQL migration scanner, frozen-migration stability scanner and Installer 1.7.8 ZIP verifier.
- Exact MagicAI/Titan host certification remains separate and is not inferred from package/source success.
## Pass 6 — Control Centre alignment

- Certification baseline remains **Titan Extension Blueprint v4.2.2 — Deep-Scan Remediated Cumulative**.
- The new `governance.control-centre.read` capability is read-only and tenant-scoped.
- All cross-engine health/model/policy/control observations enter through `GovernanceReadSourceContract`; no peer-engine tables are read or written.
- Model Council disagreement is visibility only and cannot alter authority.
- Authority contractions are explanatory projections; Titan Autonomy remains sole earned/effective authority owner.
- Missing optional evidence degrades visibility rather than fabricating compliance.
- Needs Attention ranking is deterministic and does not assert hidden causal reasoning.


## Pass 7 — Human Oversight + Workforce Operating View alignment
- Blueprint baseline: Titan Extension Blueprint v4.2.2 Deep-Scan Remediated.
- Titan AI Workforce remains the source of truth for organisation, tasks, queues, reviews, handoffs, staffing, performance and operational incidents.
- Titan Autonomy remains the sole effective-authority source.
- Governance consumes Workforce through the optional `titan-ai-workforce` read adapter only.
- Workforce hierarchy, maturity, title and performance cannot mint or raise authority.
- New capabilities `governance.workforce-oversight.read` and `governance.human-oversight.read` are `read_only` and do not require Command Bus execution.
