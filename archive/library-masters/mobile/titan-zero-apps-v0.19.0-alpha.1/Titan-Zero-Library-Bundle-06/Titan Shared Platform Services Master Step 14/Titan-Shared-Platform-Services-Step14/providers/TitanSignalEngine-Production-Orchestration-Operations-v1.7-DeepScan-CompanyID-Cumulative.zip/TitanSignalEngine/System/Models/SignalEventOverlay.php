<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Models;

use Illuminate\Database\Eloquent\Model;
use RuntimeException;

final class SignalEventOverlay extends Model
{
    protected $table = 'titan_signal_event_overlays';
    protected $guarded = [];
    protected $casts = ['tenant_company_id' => 'integer', 'tenant_key' => 'integer', 'operations' => 'array', 'applied_at' => 'immutable_datetime'];

    protected static function booted(): void
    {
        static::updating(static fn (): never => throw new RuntimeException('Signal event overlays are immutable.'));
        static::deleting(static fn (): never => throw new RuntimeException('Signal event overlays are immutable.'));
    }
}
