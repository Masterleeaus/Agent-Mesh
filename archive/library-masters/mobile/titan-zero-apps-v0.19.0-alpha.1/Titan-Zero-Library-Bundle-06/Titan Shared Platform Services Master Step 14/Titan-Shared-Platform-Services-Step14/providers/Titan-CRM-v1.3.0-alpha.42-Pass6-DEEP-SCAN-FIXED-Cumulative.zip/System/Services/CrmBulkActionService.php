<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Validation\ValidationException;

final class CrmBulkActionService
{
    private const TABLES = ['leads' => 'crm_leads', 'deals' => 'crm_deals', 'tasks' => 'crm_tasks', 'contacts' => 'crm_contacts', 'companies' => 'crm_companies'];
    private const ACTION_MATRIX = [
        'leads' => ['archive','set_status','set_owner'],
        'deals' => ['archive','set_status','set_owner'],
        'tasks' => ['archive','set_status'],
        'contacts' => ['archive'],
        'companies' => ['archive','set_status','set_owner'],
    ];

    public function __construct(private ConnectionInterface $db, private CrmAuditRecorder $audit) {}

    /** @return array<string,mixed> */
    public function preview(int $userId, string $resource, string $action, array $publicIds, array $arguments = []): array
    {
        [$table, $matched] = $this->selection($userId, $resource, $action, $publicIds);
        $this->updatePayload($action, $arguments, false); // validates arguments without mutating anything

        return [
            'resource' => $resource,
            'action' => $action,
            'matched_count' => count($matched),
            'public_ids' => $matched,
            'proposed_update' => $this->previewUpdate($action, $arguments),
            'table' => $table,
            'execution' => 'preview_only',
        ];
    }

    /** @return array<string,mixed> */
    public function execute(int $userId, int $actorUserId, string $resource, string $action, array $publicIds, array $arguments = []): array
    {
        [$table, $matched] = $this->selection($userId, $resource, $action, $publicIds);
        $update = $this->updatePayload($action, $arguments, true);
        $count = $this->db->table($table)
            ->where('company_id', CrmCompanyScope::companyId($userId))
            ->whereIn('public_id', $matched)
            ->update($update);
        $this->audit->record($userId, $actorUserId, 'bulk.' . $resource . '.' . $action, $resource, null, null, ['public_ids' => $matched, 'update' => $update]);

        return ['resource' => $resource, 'action' => $action, 'updated' => $count, 'public_ids' => $matched];
    }

    /** @return array{0:string,1:array<int,string>} */
    private function selection(int $userId, string $resource, string $action, array $publicIds): array
    {
        if (! isset(self::TABLES[$resource])) {
            throw ValidationException::withMessages(['resource' => ['Unsupported CRM bulk resource.']]);
        }
        if (! in_array($action, self::ACTION_MATRIX[$resource], true)) {
            throw ValidationException::withMessages(['action' => ['This bulk action is not valid for the selected CRM resource.']]);
        }
        $publicIds = array_values(array_unique(array_filter(array_map(static fn($id) => trim((string)$id), $publicIds))));
        if ($publicIds === [] || count($publicIds) > 100) {
            throw ValidationException::withMessages(['ids' => ['Select between 1 and 100 records.']]);
        }

        $table = self::TABLES[$resource];
        $matched = $this->db->table($table)
            ->where('company_id', CrmCompanyScope::companyId($userId))
            ->whereIn('public_id', $publicIds)
            ->whereNull('deleted_at')
            ->pluck('public_id')->map(static fn($id) => (string)$id)->all();
        if (count($matched) !== count($publicIds)) {
            throw ValidationException::withMessages(['ids' => ['One or more selected records are unavailable.']]);
        }

        return [$table, $matched];
    }

    /** @return array<string,mixed> */
    private function updatePayload(string $action, array $arguments, bool $timestamps): array
    {
        $update = match ($action) {
            'archive' => ['deleted_at' => $timestamps ? now() : '__NOW__'],
            'set_status' => ['status' => (string) ($arguments['status'] ?? throw ValidationException::withMessages(['status' => ['Status is required.']]))],
            'set_owner' => ['owner_user_id' => (int) ($arguments['owner_user_id'] ?? throw ValidationException::withMessages(['owner_user_id' => ['Owner is required.']]))],
            default => throw ValidationException::withMessages(['action' => ['Unsupported CRM bulk action.']]),
        };
        if ($timestamps) $update['updated_at'] = now();
        return $update;
    }

    /** @return array<string,mixed> */
    private function previewUpdate(string $action, array $arguments): array
    {
        return match ($action) {
            'archive' => ['archived' => true],
            'set_status' => ['status' => (string)$arguments['status']],
            'set_owner' => ['owner_user_id' => (int)$arguments['owner_user_id']],
            default => [],
        };
    }
}
