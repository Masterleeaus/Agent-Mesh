@php($launcherJourney = $journey ?? null)
@if($launcherJourney)
<div class="d-flex flex-wrap gap-2 align-items-center">
    @include('crm::components.interaction-primary-action',['journey'=>$launcherJourney['key'],'label'=>$launcherJourney['newLabel'],'prefill'=>(array)($prefill ?? [])])
    @if(!empty($launcherJourney['advancedRoute']) && Route::has($launcherJourney['advancedRoute']))
        <a class="btn btn-outline-secondary" href="{{ route('dashboard.user.crm.interactions.advanced',$launcherJourney['key']) }}">Advanced form</a>
    @endif
</div>
@endif
