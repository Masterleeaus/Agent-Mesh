# Pass 4 Security Audit

## Checks

- Actor-derived `tenant_company_id`; caller tenant identifiers stripped/denied as authority.
- Tenant scoping reviewed on canonical business repositories.
- No state-changing GET routes.
- No direct Time Attendance table access.
- High/critical writes fail closed without Risk + Assurance; AI additionally requires Command Bus.
- Finalized snapshots immutable; corrections use adjustments/proposals.
- Sensitive-field denylist covers bank/account/routing/BSB/tax/payslip/secret/token/API-key variants.
- Signal/Rewind projectors expose minimized facts only.
- Payslip employee access is actor-bound and expiring/versioned.
- Package verifier rejects symlinks, unsafe paths, hash drift, undeclared files, common secrets/junk and case collisions.

## Architecture warning adjudication

Blueprint scan before final package: **0 critical / 49 warnings**. Warnings are heuristic review flags, not suppressed:

- `PayrollMenuRegistrar`: raw DB targets host `menus` only for documented self-heal fallback; not company business data.
- `DatabasePayrollCommandReceiptStore`: lookup by global opaque SHA-256 receipt key includes tenant/capability/idempotency in key derivation; row also has canonical tenant and compound unique key.
- `PayrollMutationService`, reconciliation, Signal outbox, Workforce, Rewind and run guard: all tenant-owned queries include `tenant_company_id` and canonical `ext_titan_payroll_*` tables.
- Scanner `unbounded_get` flags in self-service/Workforce are false-positive pattern limitations because the builders call explicit `limit(...)` before `get(...)`.
- Rewind pages are capped at 500; finalization run-item materialization was changed under RED/GREEN test to `chunkById(500)`.

No critical blocker remains in the hostless source audit. Exact-host authorization/runtime/upgrade/uninstall certification remains pending.
