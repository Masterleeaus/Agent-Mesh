<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Services;
use App\Extensions\TitanRewind\System\Models\RewindPurgeReceipt;
use App\Extensions\TitanRewind\System\Models\RewindPurgeRun;
use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use App\Extensions\TitanRewind\System\Retention\RewindLegalHoldGuard;
use App\Extensions\TitanRewind\System\Retention\RewindRetentionPolicy;
use App\Extensions\TitanRewind\System\Retention\RewindLegalHoldException;
use App\Extensions\TitanRewind\System\Support\CanonicalJson;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Throwable;
final class RewindRetentionService
{
    private const TABLES=[
        'titan_rewind_replay_runs'=>['time'=>'created_at','terminal'=>null],
        'titan_rewind_observability_events'=>['time'=>'occurred_at','terminal'=>null],
        'titan_rewind_signal_outbox'=>['time'=>'created_at','terminal'=>['status'=>['published','dead_letter']]],
        'titan_rewind_dead_letters'=>['time'=>'failed_at','terminal'=>['status'=>['resolved']]],
        'titan_rewind_integrity_checks'=>['time'=>'completed_at','terminal'=>['status'=>['passed','partial','failed','empty']]],
        'titan_rewind_drift_findings'=>['time'=>'resolved_at','terminal'=>['status'=>['resolved']]],
        'titan_rewind_timeline_entries'=>['time'=>'occurred_at','terminal'=>null],
        'titan_rewind_snapshots'=>['time'=>'created_at','terminal'=>null],
        'titan_rewind_dependencies'=>['time'=>'created_at','terminal'=>null],
        'titan_rewind_historical_artifacts'=>['time'=>'captured_at','terminal'=>null],
        'titan_rewind_evidence_packages'=>['time'=>'generated_at','terminal'=>null],
    ];
    public function __construct(private RewindRetentionPolicy $policy,private RewindLegalHoldGuard $holds,private CanonicalJson $canonical,private RewindCustodyService $custody,private ConnectionInterface $db){}
    public function preview(int $tenantCompanyId,?string $class=null): array
    {
        $out=[];foreach(self::TABLES as $table=>$cfg){$rc=$this->policy->classFor($table);if($rc==='preserve'||($class!==null&&$class!==$rc)||!Schema::hasTable($table))continue;$cut=$this->policy->cutoff($rc);$q=$this->db->table($table)->where('tenant_company_id',$tenantCompanyId)->whereNotNull($cfg['time'])->where($cfg['time'],'<',$cut?->format('Y-m-d H:i:s'));$this->terminal($q,$cfg['terminal']);$out[$table]=['retention_class'=>$rc,'cutoff'=>$cut?->format(DATE_ATOM),'eligible'=>(int)$q->count()];}ksort($out);return $out;
    }
    public function run(int $tenantCompanyId,string $class,?int $actorId=null,int $batchSize=250): RewindPurgeRun
    {
        $batchSize=max(1,min(1000,$batchSize));$this->policy->days($class);
        $activeKey=hash('sha256',$tenantCompanyId.'|'.$class);
        $run=RewindPurgeRun::query()->where('active_key',$activeKey)->where('status','running')->orderByDesc('id')->first();
        if(!$run)$run=RewindPurgeRun::query()->create(['run_uuid'=>(string)Str::uuid(),'active_key'=>$activeKey,'tenant_company_id'=>$tenantCompanyId,'retention_class'=>$class,'status'=>'running','cursor_id'=>0,'rows_deleted'=>0,'rows_held'=>0,'requested_by_id'=>$actorId,'started_at'=>now()]);
        try{$this->advance($run,$batchSize);$run->last_error=null;$run->save();}catch(Throwable $e){$run->forceFill(['status'=>'failed','active_key'=>null,'last_error'=>mb_substr($e->getMessage(),0,4000)])->save();throw $e;}return $run->refresh();
    }
    private function advance(RewindPurgeRun $run,int $batchSize): void
    {
        $tables=array_values(array_filter(array_keys(self::TABLES),fn($t)=>$this->policy->classFor($t)===$run->retention_class&&Schema::hasTable($t)));sort($tables,SORT_STRING);
        $start=$run->cursor_table===null?0:max(0,array_search($run->cursor_table,$tables,true)===false?0:(int)array_search($run->cursor_table,$tables,true));
        for($i=$start;$i<count($tables);$i++){
            $table=$tables[$i];$cfg=self::TABLES[$table];$cursor=$run->cursor_table===$table?(int)$run->cursor_id:0;$cut=$this->policy->cutoff($run->retention_class);
            $q=$this->db->table($table)->where('tenant_company_id',$run->tenant_company_id)->where('id','>',$cursor)->whereNotNull($cfg['time'])->where($cfg['time'],'<',$cut?->format('Y-m-d H:i:s'))->orderBy('id')->limit($batchSize);$this->terminal($q,$cfg['terminal']);$rows=$q->cursor()->all();
            if($rows===[]){$run->forceFill(['cursor_table'=>$i+1<count($tables)?$tables[$i+1]:null,'cursor_id'=>0])->save();continue;}
            $from=(int)$rows[0]->id;$to=(int)$rows[array_key_last($rows)]->id;
            $this->db->transaction(function() use($rows,$table,$run,$from,$to): void {
                $delete=[];$held=0;
                foreach($rows as $row){$scope=null;try{$scope=$this->scope($table,$row);$this->holds->assertPurgeAllowed((int)$run->tenant_company_id,$scope['type'],$scope['id']);if(!$this->referenceSafe($table,$row)){ $held++; continue; }if($scope['type']==='evidence-package'){ $pkg=RewindEvidencePackage::query()->where('tenant_company_id',$run->tenant_company_id)->where('package_uuid',$scope['id'])->first(); if($pkg)$this->custody->record($pkg,'purge_executed',$run->requested_by_id,'retention-policy',['run_uuid'=>$run->run_uuid]); }$delete[]=(int)$row->id;}catch(RewindLegalHoldException){$held++;if($scope&&$scope['type']==='evidence-package'){ $pkg=RewindEvidencePackage::query()->where('tenant_company_id',$run->tenant_company_id)->where('package_uuid',$scope['id'])->first(); if($pkg)$this->custody->record($pkg,'purge_blocked',$run->requested_by_id,'active-legal-hold',['run_uuid'=>$run->run_uuid]); }}}
                if($delete!==[])$this->db->table($table)->whereIn('id',$delete)->delete();
                $receiptData=['run_uuid'=>$run->run_uuid,'tenant_company_id'=>(int)$run->tenant_company_id,'table_name'=>$table,'retention_class'=>$run->retention_class,'from_id'=>$from,'to_id'=>$to,'rows_deleted'=>count($delete),'rows_held'=>$held];
                RewindPurgeReceipt::query()->create($receiptData+['receipt_uuid'=>(string)Str::uuid(),'batch_hash'=>hash('sha256',$this->canonical->encode($receiptData)),'metadata'=>['deleted_ids_hash'=>hash('sha256',$this->canonical->encode($delete))],'purged_at'=>now()]);
                $run->forceFill(['cursor_table'=>$table,'cursor_id'=>$to,'rows_deleted'=>(int)$run->rows_deleted+count($delete),'rows_held'=>(int)$run->rows_held+$held])->save();
            },3);
            if(count($rows)>=$batchSize)return;
        }
        $run->forceFill(['status'=>'completed','active_key'=>null,'cursor_table'=>null,'cursor_id'=>0,'completed_at'=>now()])->save();
    }

    private function referenceSafe(string $table, object $row): bool
    {
        if ($table === 'titan_rewind_evidence_packages' && isset($row->package_uuid)) {
            return !$this->db->table('titan_rewind_governance_receipts')->where('tenant_company_id',(int)$row->tenant_company_id)->where('evidence_package_uuid',(string)$row->package_uuid)->exists();
        }
        return true;
    }

    private function terminal($q,?array $terminal): void { if(!$terminal)return;foreach($terminal as $field=>$values)$q->whereIn($field,$values); }
    private function scope(string $table,object $row): array
    {
        if(isset($row->package_uuid)&&$table==='titan_rewind_evidence_packages')return ['type'=>'evidence-package','id'=>(string)$row->package_uuid];
        if(isset($row->trace_id)&&is_string($row->trace_id)&&$row->trace_id!=='')return ['type'=>'trace','id'=>$row->trace_id];
        return ['type'=>'tenant-investigation','id'=>'tenant:'.(int)$row->tenant_company_id];
    }
}
