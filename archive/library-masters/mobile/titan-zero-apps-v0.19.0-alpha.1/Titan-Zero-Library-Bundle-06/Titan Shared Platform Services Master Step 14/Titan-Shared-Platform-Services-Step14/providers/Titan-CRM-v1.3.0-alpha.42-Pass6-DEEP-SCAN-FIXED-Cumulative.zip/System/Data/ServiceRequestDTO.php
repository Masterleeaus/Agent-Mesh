<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Data;

final class ServiceRequestDTO
{
    public function __construct(
        public readonly mixed $publicId,
        public readonly mixed $title,
        public readonly mixed $status,
        public readonly mixed $priority,
        public readonly mixed $contactPublicId,
        public readonly mixed $locationPublicId,
    ) {}

    public function toArray(): array
    {
        return [
            'publicId'=>$this->publicId,
            'title'=>$this->title,
            'status'=>$this->status,
            'priority'=>$this->priority,
            'contactPublicId'=>$this->contactPublicId,
            'locationPublicId'=>$this->locationPublicId,
        ];
    }
}
