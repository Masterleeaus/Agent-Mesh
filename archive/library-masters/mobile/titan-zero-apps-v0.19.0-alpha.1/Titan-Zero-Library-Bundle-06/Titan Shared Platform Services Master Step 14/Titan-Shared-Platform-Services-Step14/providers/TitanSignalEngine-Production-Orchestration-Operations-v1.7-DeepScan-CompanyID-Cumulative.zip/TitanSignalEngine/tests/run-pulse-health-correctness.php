<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/PulseProjectionFreshness.php';
require __DIR__ . '/../System/Data/CommandReceiptPairing.php';
require __DIR__ . '/../System/Data/OperationalHealthClassifier.php';

use App\Extensions\TitanSignalEngine\System\Data\CommandReceiptPairing;
use App\Extensions\TitanSignalEngine\System\Data\OperationalHealthClassifier;
use App\Extensions\TitanSignalEngine\System\Data\PulseProjectionFreshness;

function phAssert(bool $condition, string $message): void {
    if (! $condition) throw new RuntimeException($message);
}

$now = new DateTimeImmutable('2026-08-18T01:30:00+00:00');
$fresh = PulseProjectionFreshness::evaluate(
    new DateTimeImmutable('2026-08-18T01:29:55+00:00'),
    new DateTimeImmutable('2026-08-18T01:29:50+00:00'),
    new DateTimeImmutable('2026-08-18T01:29:50+00:00'),
    $now,
    300,
);
phAssert($fresh['status'] === 'healthy', 'Recent scoped projection must be healthy.');
phAssert($fresh['projection_backlog_seconds'] === 0, 'Caught-up projection must have zero backlog even when the system is otherwise idle.');

$stale = PulseProjectionFreshness::evaluate(
    new DateTimeImmutable('2026-08-18T01:00:00+00:00'),
    new DateTimeImmutable('2026-08-18T00:59:00+00:00'),
    new DateTimeImmutable('2026-08-18T01:10:00+00:00'),
    $now,
    300,
);
phAssert($stale['status'] === 'degraded', 'A scoped ingestion watermark ahead of its projected watermark must degrade independently of another tenant.');

$pair = CommandReceiptPairing::pair(
    'cmd-2',
    new DateTimeImmutable('2026-08-18T01:00:02+00:00'),
    'receipt-2',
    new DateTimeImmutable('2026-08-18T01:00:05.250000+00:00'),
    'direct_causation',
);
phAssert($pair['latency_ms'] === 3250, 'Command latency must be calculated per command/receipt pair.');
phAssert($pair['pairing_method'] === 'direct_causation', 'Pairing method must remain explicit.');

$health = OperationalHealthClassifier::classify([
    'backpressured' => false,
    'recent_dead_letter' => 0,
    'critical_open' => 0,
    'pulse_projection_status' => 'healthy',
], [
    'resolved_dead_letter_30d' => 12,
    'resolved_critical_anomaly_30d' => 2,
]);
phAssert($health['status'] === 'healthy', 'Historical incidents must not degrade current health.');
phAssert($health['historical_incidents']['resolved_dead_letter_30d'] === 12, 'Historical incidents must remain visible.');

$current = OperationalHealthClassifier::classify([
    'backpressured' => false,
    'recent_dead_letter' => 1,
    'critical_open' => 0,
    'pulse_projection_status' => 'healthy',
], []);
phAssert($current['status'] === 'degraded', 'Current dead-letter activity must degrade health.');

fwrite(STDOUT, "pulse-health-correctness: PASS\n");
