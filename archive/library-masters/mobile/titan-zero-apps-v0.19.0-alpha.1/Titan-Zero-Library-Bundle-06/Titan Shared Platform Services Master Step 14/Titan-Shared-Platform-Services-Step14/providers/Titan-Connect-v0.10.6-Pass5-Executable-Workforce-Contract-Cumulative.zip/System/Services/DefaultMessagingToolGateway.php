<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Contracts\MessagingToolGateway;
use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Delivery\OutboundDeliveryService;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Extensions\TitanConnect\System\Security\ConversationAccess;
use App\Extensions\TitanConnect\System\Services\TeamChat\TeamConversationService;
use App\Extensions\TitanConnect\System\Services\TeamChat\TeamMessageService;
use Illuminate\Database\Eloquent\ModelNotFoundException;

final class DefaultMessagingToolGateway implements MessagingToolGateway
{
    public function __construct(
        private readonly ConversationAccess $conversationAccess,
        private readonly TeamConversationService $conversations,
        private readonly TeamMessageService $messages,
        private readonly ChannelAccessPolicy $channelPolicy,
        private readonly WorkCoreAuthorizationGateway $workCore,
        private readonly OutboundDeliveryService $delivery,
    ) {
    }

    public function messagesRead(int $companyId, int $actorId, string $conversationUuid, int $limit = 50): array
    {
        $conversation = $this->conversation($companyId, $conversationUuid);
        $this->conversationAccess->assertMember($conversation, $companyId, $actorId);
        return $conversation->messages()->where('company_id', $companyId)->latest('created_at')
            ->limit(min(max($limit, 1), 100))->get()->reverse()->values()->toArray();
    }

    public function messagesSend(int $companyId, int $actorId, string $conversationUuid, string $body, ?string $idempotencyUuid = null): array
    {
        $conversation = $this->conversation($companyId, $conversationUuid);
        $this->conversationAccess->assertMember($conversation, $companyId, $actorId);
        return $this->messages->send($conversation, $companyId, $actorId, $body, $idempotencyUuid)->toArray();
    }

    public function conversationCreate(int $companyId, int $actorId, string $type, ?string $name, array $userIds): array
    {
        return $this->conversations->create($companyId, $actorId, $type, $name, $userIds)->toArray();
    }

    public function conversationReply(int $companyId, int $actorId, string $conversationUuid, string $body, ?string $idempotencyUuid = null): array
    {
        return $this->messagesSend($companyId, $actorId, $conversationUuid, $body, $idempotencyUuid);
    }

    public function externalSend(int $companyId, int $actorId, string $connectionUuid, string $threadUuid, string $recipient, string $body, string $idempotencyKey): array
    {
        $connection = ChannelConnection::query()->where('company_id', $companyId)->where('uuid', $connectionUuid)->first();
        $thread = ExternalThread::query()->where('company_id', $companyId)->where('uuid', $threadUuid)->first();
        if (! $connection || ! $thread || (int) $thread->channel_connection_id !== (int) $connection->id) {
            throw (new ModelNotFoundException())->setModel(ExternalThread::class, [$threadUuid]);
        }
        abort_unless($this->channelPolicy->canSend($connection, $actorId), 403);
        if ($thread->linked_entity_type !== null && $thread->linked_entity_id !== null) {
            $this->workCore->assertCanAccess($companyId, $actorId, (string) $thread->linked_entity_type, (string) $thread->linked_entity_id);
        }
        return $this->delivery->send($companyId, $actorId, $connection, $thread, $recipient, $body, $idempotencyKey, ['initiator' => 'messaging-tool'])->toArray();
    }

    private function conversation(int $companyId, string $uuid): TeamConversation
    {
        return TeamConversation::query()->where('company_id', $companyId)->where('uuid', $uuid)->firstOrFail();
    }
}
