<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Http\Controllers\Admin;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskControlCentreContract;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

final class RiskControlCentreController
{
    public function __invoke(Request $request, RiskControlCentreContract $controlCentre): View
    {
        $validated = $request->validate([
            'tenant_company_id' => ['nullable', 'integer', 'min:1'],
            'capability' => ['nullable', 'string', 'max:160'],
        ]);
        $tenantCompanyId = isset($validated['tenant_company_id']) ? (int) $validated['tenant_company_id'] : null;
        $capability = isset($validated['capability']) && trim((string) $validated['capability']) !== '' ? trim((string) $validated['capability']) : null;
        $snapshot = $tenantCompanyId === null ? null : $controlCentre->snapshot($tenantCompanyId, $capability);

        return view('titan-risk-engine::admin.control-centre', [
            'snapshot' => $snapshot,
            'tenantCompanyId' => $tenantCompanyId,
            'capability' => $capability,
        ]);
    }
}
