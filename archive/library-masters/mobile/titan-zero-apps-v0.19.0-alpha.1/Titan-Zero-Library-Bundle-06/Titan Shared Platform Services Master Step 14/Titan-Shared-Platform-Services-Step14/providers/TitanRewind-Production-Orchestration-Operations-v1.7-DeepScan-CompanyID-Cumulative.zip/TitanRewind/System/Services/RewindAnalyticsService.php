<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Models\RewindCase;
use App\Extensions\TitanRewind\System\Models\RewindDriftFinding;
use App\Extensions\TitanRewind\System\Models\RewindEvidencePackage;
use App\Extensions\TitanRewind\System\Models\RewindGovernanceReceipt;
use App\Extensions\TitanRewind\System\Models\RewindIntegrityCheck;
use App\Extensions\TitanRewind\System\Models\RewindRecoveryPlan;
use App\Extensions\TitanRewind\System\Models\RewindReplayRun;
use App\Extensions\TitanRewind\System\Models\RewindTraceEvent;
use App\Extensions\TitanRewind\System\Models\RewindTraceIndex;

final class RewindAnalyticsService
{
    public function dashboard(int $tenantCompanyId): array
    {
        return [
            'events'=>RewindTraceEvent::query()->where('tenant_company_id',$tenantCompanyId)->count(),
            'traces'=>RewindTraceIndex::query()->where('tenant_company_id',$tenantCompanyId)->count(),
            'critical_traces'=>RewindTraceIndex::query()->where('tenant_company_id',$tenantCompanyId)->where('forensic_state','critical')->count(),
            'review_traces'=>RewindTraceIndex::query()->where('tenant_company_id',$tenantCompanyId)->where('forensic_state','review')->count(),
            'open_cases'=>RewindCase::query()->where('tenant_company_id',$tenantCompanyId)->whereNotIn('status',['closed','resolved'])->count(),
            'open_drift'=>RewindDriftFinding::query()->where('tenant_company_id',$tenantCompanyId)->where('status','open')->count(),
            'failed_integrity_checks'=>RewindIntegrityCheck::query()->where('tenant_company_id',$tenantCompanyId)->where('status','failed')->count(),
            'replay_runs'=>RewindReplayRun::query()->where('tenant_company_id',$tenantCompanyId)->count(),
            'comparison_runs'=>RewindReplayRun::query()->where('tenant_company_id',$tenantCompanyId)->whereIn('mode',['counterfactual','model-compare','policy-compare','knowledge-compare'])->count(),
            'evidence_packages'=>RewindEvidencePackage::query()->where('tenant_company_id',$tenantCompanyId)->count(),
            'recovery_plans'=>RewindRecoveryPlan::query()->where('tenant_company_id',$tenantCompanyId)->count(),
            'pending_governance'=>RewindGovernanceReceipt::query()->where('tenant_company_id',$tenantCompanyId)->whereIn('status',['requested','pending','review'])->count(),
        ];
    }
}
