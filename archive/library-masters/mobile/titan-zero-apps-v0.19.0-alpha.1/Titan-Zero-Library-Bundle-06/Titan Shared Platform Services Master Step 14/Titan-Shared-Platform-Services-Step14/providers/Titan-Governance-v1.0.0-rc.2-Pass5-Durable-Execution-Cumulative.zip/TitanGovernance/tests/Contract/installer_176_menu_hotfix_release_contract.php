<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);$errors=[];
$installer=json_decode((string)file_get_contents($root.'/extension.json'),true,512,JSON_THROW_ON_ERROR);
$sidecar=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
if(($installer['version']??null)!=='1.0.0-rc.2')$errors[]='installer version not 1.0.0-rc.2';
if(($sidecar['version']??null)!=='1.0.0-rc.2')$errors[]='sidecar version not 1.0.0-rc.2';
if(!is_file($root.'/HOTFIX-H3-INSTALLER-1.7.6-MENU-NAVIGATION.md'))$errors[]='H3 report missing';
$nav=$sidecar['navigation']['user']??[];
$routes=array_values(array_filter(array_map(static fn($r)=>is_array($r)?($r['route']??null):null,$nav), 'is_string'));
foreach([
 'dashboard.user.titan.governance.index',
 'dashboard.user.titan.governance.overview',
 'dashboard.user.titan.governance.control-centre',
 'dashboard.user.titan.governance.escalations.queue',
 'dashboard.user.titan.governance.signal-heatmap',
 'dashboard.user.titan.governance.operational-pressure',
 'dashboard.user.titan.governance.circuit-breakers',
 'dashboard.user.titan.governance.workforce-oversight',
] as $route) if(!in_array($route,$routes,true))$errors[]='sidecar navigation missing '.$route;
$pre=(string)file_get_contents($root.'/System/Host/TitanProviderBootPreflight.php');
foreach(['GovernanceMenuRegistrar.php','navigation_registrar','navigation_sync_boot','menu_browser_views'] as $needle)if(!str_contains($pre,$needle))$errors[]='provider preflight missing '.$needle;
$verify=(string)file_get_contents($root.'/bin/verify.php');
if(!str_contains($verify,"'1.0.0-rc.2'"))$errors[]='self verifier not targeting rc.2';
if($errors){fwrite(STDERR,'FAIL: '.implode('; ',$errors)."\n");exit(1);}echo "PASS: Installer 1.7.6 menu hotfix release contract\n";
