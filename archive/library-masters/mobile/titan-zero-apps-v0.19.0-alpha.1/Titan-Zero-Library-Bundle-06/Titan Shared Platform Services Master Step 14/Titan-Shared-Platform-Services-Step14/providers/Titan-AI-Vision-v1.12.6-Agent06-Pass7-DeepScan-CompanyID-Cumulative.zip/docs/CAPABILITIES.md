# Capabilities

`vision.analysis`, `vision.evidence`, `vision.annotations`, `vision.evidence-review`, `vision.workflow-proposal`, `vision.completion-assurance`, `vision.mobile-capture`.

## v1.3 evidence intelligence
- `vision.before-after-comparison`: pair comparable before/after evidence and persist deterministic comparability scores.
- `vision.evidence-timeline`: retrieve user-scoped visual evidence history by operational context.
- `vision.assurance-readiness`: compute non-authoritative evidence readiness packages for Titan Assurance.

## Longitudinal evidence continuity

`vision.evidence-continuity`, `vision.historical-baseline`, and `vision.repeat-visit-history` link new evidence to prior explicitly verified evidence for the same asset or property area. Verification is human-controlled and does not convert Vision inference into business truth.

## Longitudinal change detection
Titan AI Vision can compare a current visit with its explicitly verified historical baseline and persist reviewable visual change records using seven canonical states: `new`, `resolved`, `improved`, `worsened`, `unchanged`, `uncertain`, and `not_comparable`. These remain advisory visual inference.
