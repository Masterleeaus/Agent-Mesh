<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\TraceProfile;
use App\Extensions\TitanSignalEngine\System\Services\TraceAnalyzer;
use PHPUnit\Framework\TestCase;

final class TraceAnalyzerTest extends TestCase
{
    public function test_causation_orders_trace_ahead_of_misleading_timestamps(): void
    {
        $root = SignalEnvelope::fromArray([
            'event_type' => 'command.requested',
            'tenant_company_id' => 1,
            'source' => 'test',
            'occurred_at' => '2026-08-12T10:00:00Z',
        ]);
        $risk = $root->child('risk.assessed', 'test', [], ['occurred_at' => '2026-08-12T10:05:00Z']);
        $executed = $risk->child('command.executed', 'test', [], ['occurred_at' => '2026-08-12T09:55:00Z']);

        $profile = TraceProfile::fromArray([
            'profile_key' => 'test.command',
            'required_event_types' => ['command.requested', 'risk.assessed', 'command.executed'],
            'ordering_rules' => [
                ['before' => 'command.requested', 'after' => 'risk.assessed'],
                ['before' => 'risk.assessed', 'after' => 'command.executed'],
            ],
        ]);

        $analysis = (new TraceAnalyzer())->analyze([$executed, $root, $risk], $profile);

        self::assertSame('complete', $analysis->status);
        self::assertSame(
            ['command.requested', 'risk.assessed', 'command.executed'],
            array_map(static fn (SignalEnvelope $event): string => $event->eventType, $analysis->orderedEvents),
        );
    }

    public function test_missing_parent_and_missing_required_type_make_trace_incomplete(): void
    {
        $event = SignalEnvelope::fromArray([
            'event_type' => 'command.executed',
            'tenant_company_id' => 1,
            'source' => 'test',
            'causation_id' => '018f6b4e-2a74-7a70-8000-000000000099',
            'root_causation_id' => '018f6b4e-2a74-7a70-8000-000000000099',
        ]);
        $profile = TraceProfile::fromArray([
            'profile_key' => 'test.command',
            'required_event_types' => ['command.requested', 'command.executed'],
        ]);

        $analysis = (new TraceAnalyzer())->analyze([$event], $profile);

        self::assertSame('incomplete', $analysis->status);
        self::assertContains('command.requested', $analysis->missingEventTypes);
        self::assertSame($event->causationId, $analysis->missingParentEventIds[$event->eventId]);
    }
    public function test_profile_with_terminal_rule_is_incomplete_until_a_terminal_event_exists(): void
    {
        $root = SignalEnvelope::fromArray([
            'event_type' => 'command.requested',
            'tenant_company_id' => 1,
            'source' => 'test',
        ]);
        $profile = TraceProfile::fromArray([
            'profile_key' => 'terminal.command',
            'required_event_types' => ['command.requested'],
            'terminal_event_types' => ['execution.receipt', 'command.failed'],
        ]);

        $analysis = (new TraceAnalyzer())->analyze([$root], $profile);

        self::assertSame('incomplete', $analysis->status);
        self::assertSame('terminal_event_missing', $analysis->profileViolations[0]['code']);
    }

}
