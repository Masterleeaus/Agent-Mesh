# Upgrade

## v1.0.0-rc.2

Pass 8 adds host compatibility adapters, navigation self-healing, exact-host certification artifacts and release provenance. It requires no database migration and does not change deterministic compiler semantics.

Upgrading from v0.8.0 preserves all compilation rows and migrations. After upgrade, verify the Titan Nexus parent plus nine child routes, then execute the exact-host certification ladder in `docs/HOST-CERTIFICATION.md`. Do not promote the package to final v1.0.0 until all live host stages pass.

Titan Nexus uses forward-only, expand/migrate/contract-compatible upgrades. Existing migrations are immutable historical artifacts.

## v0.8.0

Pass 7 adds the Control Centre and does not require a database migration. It adds tenant-context/read-model contracts, host-compatible Blade routes/views, recursive presentation-time redaction, and a Titan Interface Contribution v1.1 declaration. The Nexus runtime advances to 0.8.0 while deterministic compiler semantics remain 0.5.0.

Upgrading from v0.7.0 preserves all compilation rows and provisioning evidence. The Control Centre reads existing snapshots through the tenant-scoped repository and redacts secret-like historical keys before rendering.

If the host user model does not expose `company_id` or `tenant_company_id`, configure `titan-nexus.tenant_context.public_contract` and `resolve_method` to a host-owned tenant-context adapter before enabling the Control Centre for users.

## v0.7.0

v0.7.0 rebased packaging onto Installer 1.7.8 and canonical manifest v2.2 and added Risk/Governance/Assurance/Autonomy/Signal/Rewind integration without changing compiler semantics.
