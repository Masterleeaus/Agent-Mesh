<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

use App\Extensions\TitanConnect\System\DTO\ProviderHttpResponse;

interface ProviderHttpClient
{
    /**
     * @param array{
     *   headers?:array<string,string>,
     *   bearer?:string,
     *   basic_auth?:array{0:string,1:string},
     *   json?:array,
     *   form?:array,
     *   query?:array,
     *   timeout?:int,
     *   connect_timeout?:int
     * } $options
     */
    public function request(string $method, string $url, array $options = []): ProviderHttpResponse;
}
