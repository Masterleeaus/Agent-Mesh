<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Signals;

final readonly class RewindPeopleSourceContributor
{
    public function __construct(private PeopleSignalSanitizer $sanitizer) {}

    /** @return array<string,mixed> */
    public function contribute(PeopleOutboxEvent $event): array
    {
        return [
            'tenant_company_id' => $event->tenantCompanyId,
            'fact_type' => $event->eventType,
            'aggregate_ref' => $event->aggregateRef,
            'source_event_ref' => $event->eventId,
            'occurred_at' => $event->occurredAt,
            'trace_id' => $event->traceId,
            'correlation_id' => $event->correlationId,
            'causation_id' => $event->causationId,
            'facts' => $this->sanitizer->sanitize($event->payload),
        ];
    }
}
