# Titan Rewind Observability

Titan Rewind records operational telemetry without making it authoritative business state. Every trace-scoped record carries `tenant_company_id`, `trace_id`, `correlation_id`, optional `causation_id`, and `extension_key=titan-rewind`.

## Health

`RewindHealthCheck` exposes independent liveness and readiness snapshots. Liveness proves the extension process can respond. Readiness checks runtime state, database access, evidence signing, Governance availability, Signal transport availability, replay backlog, dead-letter attention, and open circuit breakers. Aggregate states are `HEALTHY`, `DEGRADED`, `UNAVAILABLE`, `DISABLED`, `MAINTENANCE`, or `DRAINING`.

## Structured telemetry

`RewindTelemetryService` writes sanitized metric, span, and log records to `titan_rewind_observability_events` and mirrors structured logs through Laravel logging. Passwords, tokens, secrets, credentials, signatures, card data, cookies and session identifiers are removed from telemetry attributes before persistence.

Initial metrics/spans include replay queueing/execution, integrity failures, drift findings, evidence generation, recovery proposals, legal holds, Governance requests, Signal publication, and dead-letter escalation. These records are operational diagnostics only and never replace canonical Rewind trace events.

## Titan Signal

Significant Rewind state transitions are first written to `titan_rewind_signal_outbox`. `PublishRewindSignalJob` delivers the versioned envelope through `RewindSignalTransportContract`. If the host has not bound a Signal transport, the outbox remains inspectable and delivery eventually enters Attention Required rather than silently disappearing.

Versioned events emitted by this release include:

- `rewind.replay.queued.v1`
- `rewind.replay.completed.v1`
- `rewind.replay.failed.v1`
- `rewind.integrity.verified.v1`
- `rewind.integrity.failed.v1`
- `rewind.drift.detected.v1`
- `rewind.evidence.generated.v1`
- `rewind.recovery.proposed.v1`
- `rewind.governance.receipt.observed.v1`
- `rewind.legal_hold.applied.v1`

Signal events are observations. They do not become a second source of business truth.
