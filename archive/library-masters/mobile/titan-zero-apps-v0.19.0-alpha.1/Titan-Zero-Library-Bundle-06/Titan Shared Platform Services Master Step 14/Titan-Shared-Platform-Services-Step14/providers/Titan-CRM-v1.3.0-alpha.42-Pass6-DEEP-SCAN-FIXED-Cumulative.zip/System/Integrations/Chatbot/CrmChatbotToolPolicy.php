<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\Chatbot;

use Illuminate\Auth\Access\AuthorizationException;

final class CrmChatbotToolPolicy
{
    /** Public/intake field-service tools expose no existing customer records. */
    private const PUBLIC_FIELD_SERVICE = [
    ];

    /** Private CRM/customer history always requires a current Titan Customer verification grant. */
    private const PRIVATE_VERIFIED = [
        'crm_update_my_details',
        'crm_get_my_proposals',
        'crm_get_my_estimates',
        'crm_get_my_invoices',
        'crm_get_my_projects',
        'crm_get_my_recent_activity',
    ];

    private const FINANCIAL = [
        'crm_get_my_proposals',
        'crm_get_my_estimates',
        'crm_get_my_invoices',
    ];

    /** These tools need a CRM contact link, although not all expose private data. */
    private const IDENTITY_REQUIRED = [
        'crm_update_my_details',
        'crm_request_callback',
        'crm_get_my_proposals',
        'crm_get_my_estimates',
        'crm_get_my_invoices',
        'crm_get_my_projects',
        'crm_get_my_recent_activity',
    ];

    public function __construct(
        private CrmChatbotSettingsService $settings,
        private CrmChatbotSessionGrantService $sessionGrants,
    ) {}

    public function enabled(object $chatbot): bool
    {
        $cfg = $this->settings->forChatbot((int) $chatbot->getAttribute('user_id'), (int) $chatbot->getKey());
        return (bool) ($cfg['enabled'] ?? false);
    }

    /** @return list<string> */
    public function allowedTools(object $chatbot): array
    {
        $cfg = $this->settings->forChatbot((int) $chatbot->getAttribute('user_id'), (int) $chatbot->getKey());
        $defaults = CrmChatbotToolService::TOOL_NAMES;
        $configured = $cfg['allowed_tools'] ?? null;

        // null means inherit defaults; an explicit [] deliberately disables every CRM tool.
        return $configured === null
            ? $defaults
            : array_values(array_intersect($defaults, (array) $configured));
    }

    public function hasActiveVerifiedSession(object $chatbot, object $conversation, ?array $identity): bool
    {
        if (! $identity || empty($identity['crm_contact_public_id'])) return false;

        return $this->sessionGrants->active(
            (int) $chatbot->getAttribute('user_id'),
            (int) $chatbot->getKey(),
            (int) ($identity['chatbot_customer_id'] ?? $conversation->getAttribute('chatbot_customer_id') ?? 0),
            (string) $identity['crm_contact_public_id'],
            (string) ($conversation->getAttribute('session_id') ?? ''),
        );
    }

    public function authorize(object $chatbot, object $conversation, string $tool, ?array $identity): void
    {
        if (! in_array($tool, $this->allowedTools($chatbot), true)) {
            throw new AuthorizationException('CRM chatbot tool is not enabled.');
        }

        if (in_array($tool, self::IDENTITY_REQUIRED, true)
            && (! $identity || empty($identity['crm_contact_public_id']))) {
            throw new AuthorizationException('Customer identity is not linked to CRM.');
        }

        $activeVerifiedSession = $this->hasActiveVerifiedSession($chatbot, $conversation, $identity);
        if (in_array($tool, self::PRIVATE_VERIFIED, true) && ! $activeVerifiedSession) {
            throw new AuthorizationException('A current verified Titan Customer session is required for private CRM information.');
        }

        if (in_array($tool, self::FINANCIAL, true)) {
            $cfg = $this->settings->forChatbot((int) $chatbot->getAttribute('user_id'), (int) $chatbot->getKey());
            if (! ($cfg['allow_financial_reads'] ?? true)) {
                throw new AuthorizationException('Financial CRM reads are disabled for this chatbot.');
            }
            if (($cfg['require_verified_financial_identity'] ?? true) && ! $activeVerifiedSession) {
                throw new AuthorizationException('A current verified Titan Customer session is required for financial information.');
            }
        }
    }
}
