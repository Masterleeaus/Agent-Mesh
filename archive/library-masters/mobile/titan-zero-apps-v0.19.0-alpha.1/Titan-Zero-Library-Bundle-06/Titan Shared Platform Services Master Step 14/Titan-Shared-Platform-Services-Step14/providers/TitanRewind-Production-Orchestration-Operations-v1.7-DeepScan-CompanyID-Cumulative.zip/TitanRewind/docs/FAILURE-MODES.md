# Failure modes

Implemented v0.7 behavior:

- **Source unavailable/stale/unwatermarked:** evidence cannot claim complete source coverage.
- **Integrity mismatch:** evidence readiness is withheld and compliant export cannot verify the package.
- **Replay mutation attempt:** the rejecting gateway throws a replay boundary violation.
- **Historical artifact unavailable:** comparison reports `ARTIFACT_UNAVAILABLE`; no current artifact is substituted silently.
- **Signing key unavailable:** evidence generation fails closed before creating a new signed package.
- **Invalid/cross-tenant legal-hold scope:** hold creation is rejected.
- **Active legal hold:** `RewindLegalHoldGuard` blocks purge when invoked by a deletion workflow.

DLQ/backpressure/circuit-breaker/maintenance behavior is part of the next runtime-resilience pass and is not claimed here.
