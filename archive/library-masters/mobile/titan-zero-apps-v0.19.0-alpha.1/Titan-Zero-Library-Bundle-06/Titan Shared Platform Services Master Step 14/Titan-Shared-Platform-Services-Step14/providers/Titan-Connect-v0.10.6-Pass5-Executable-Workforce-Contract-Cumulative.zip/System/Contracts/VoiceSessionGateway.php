<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\VoiceCall;

interface VoiceSessionGateway
{
    /** @return array<string,mixed> */
    public function start(VoiceCall $call, ChannelConnection $connection, array $credentials): array;
}
