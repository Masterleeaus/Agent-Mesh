# Titan Connect ↔ CRM Outbound Communication Contract

## Ownership

CRM owns authoritative business state and the durable intent that a communication should occur. Titan Connect owns canonical channel/provider execution in an integrated Titan deployment.

## CRM port

`App\Extensions\Crm\System\Integrations\TitanConnect\CrmCommunicationExecutionPort`

```php
public function deliver(array $intent): array;
```

The intent contains, where applicable:

- `public_id` — CRM outbox reference
- `tenant_company_id`
- `user_id` — accountable actor reference
- `channel`
- `recipient`
- `template_key`
- `subject_type`
- `subject_public_id`
- `payload`
- `idempotency_key`
- `trace_id`
- `correlation_id`
- `causation_id`
- `command_id`
- `receipt_id`

## Required provider outcome

The adapter returns a structured result containing:

- `status`: `delivered`, `sent`, `deferred`, or `failed`
- `provider`
- `provider_message_id` where available
- `provider_status`
- `retryable`
- `reason`/`error` when unsuccessful

## Idempotency rule

The adapter must use the supplied `idempotency_key` as its provider-side or adapter-side deduplication key wherever the channel/provider supports one. Returning success for a duplicate request must reference the original provider outcome rather than causing a second real-world send.

## Truth rule

A CRM command receipt with `effect_status=queued` means CRM accepted the communication intent. Only a provider outcome recorded as delivered/sent is delivery evidence. AI/Workforce consumers must not convert queued acceptance into a claim that the customer received the communication.

## Fallback

`CrmDeferredCommunicationExecutionPort` is the safe default when Titan Connect is absent. `CrmLegacyMailCommunicationAdapter` is an explicit standalone compatibility adapter and does not claim provider-level exactly-once guarantees beyond CRM's durable intent deduplication.
