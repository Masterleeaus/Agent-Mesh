<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanRewind\System\Forensics\RewindIntegrityHasher;
use App\Extensions\TitanRewind\System\Forensics\RewindRootCauseAnalyzer;
use App\Extensions\TitanRewind\System\Forensics\RewindTemporalDiagnostics;
use App\Extensions\TitanRewind\System\Support\CanonicalJson;
use PHPUnit\Framework\TestCase;

final class ForensicsContractTest extends TestCase
{
    public function test_integrity_hash_is_content_stable_but_content_sensitive(): void
    {
        $hasher = new RewindIntegrityHasher(new CanonicalJson());
        $event = ['event_id'=>'e1','trace_id'=>'t1','occurred_at'=>'2026-08-15T09:00:00+00:00','payload'=>['b'=>2,'a'=>1],'integrity_hash'=>'local'];
        $first = $hasher->contentHash($event);
        $event['payload'] = ['a'=>1,'b'=>2];
        $event['integrity_hash'] = 'different-local';
        self::assertSame($first, $hasher->contentHash($event));
        $event['payload']['b'] = 3;
        self::assertNotSame($first, $hasher->contentHash($event));
    }

    public function test_temporal_diagnostics_detect_out_of_order_arrival(): void
    {
        $diagnostics = (new RewindTemporalDiagnostics(30))->analyse([
            ['id'=>1,'event_id'=>'e2','sequence'=>2,'occurred_at'=>'2026-08-15T09:00:20+00:00','recorded_at'=>'2026-08-15T09:00:21+00:00'],
            ['id'=>2,'event_id'=>'e1','sequence'=>1,'occurred_at'=>'2026-08-15T09:00:00+00:00','recorded_at'=>'2026-08-15T09:01:00+00:00'],
        ]);
        self::assertSame(1, $diagnostics['out_of_order_arrival_count']);
        self::assertSame(1, $diagnostics['late_event_count']);
    }

    public function test_root_cause_prefers_first_explicit_failure_and_walks_upstream(): void
    {
        $analysis = (new RewindRootCauseAnalyzer())->analyse([
            ['event_id'=>'a','sequence'=>1,'event_type'=>'decision.created','source_engine'=>'titan-ai-core'],
            ['event_id'=>'b','sequence'=>2,'event_type'=>'command.failed','source_engine'=>'titan-command-bus','causation_id'=>'a'],
        ], ['edges'=>[['from'=>'a','to'=>'b']],'orphans'=>[]], []);
        self::assertSame('b', $analysis['primary']['event_id']);
        self::assertContains('a', $analysis['primary']['upstream_event_ids']);
    }
}
