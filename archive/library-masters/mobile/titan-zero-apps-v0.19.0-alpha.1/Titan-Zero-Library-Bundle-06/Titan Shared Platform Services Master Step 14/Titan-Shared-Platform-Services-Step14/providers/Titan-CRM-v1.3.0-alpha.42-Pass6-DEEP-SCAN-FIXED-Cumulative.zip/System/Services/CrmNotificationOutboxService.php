<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use InvalidArgumentException;

/** Durable, tenant-scoped communication intent store. */
final class CrmNotificationOutboxService
{
    public function __construct(private ConnectionInterface $db) {}

    public function enqueue(int $userId,string $channel,string $templateKey,?string $recipient,array $payload=[],?string $subjectType=null,?string $subjectPublicId=null):array
    {
        return $this->insertIntent($userId,$channel,$templateKey,$recipient,$payload,$subjectType,$subjectPublicId,null,[]);
    }

    /**
     * Enqueue exactly one externally visible effect for a governed command.
     * @param array<string,mixed> $trace
     */
    public function enqueueGoverned(int $userId,string $channel,string $templateKey,?string $recipient,array $payload,?string $subjectType,?string $subjectPublicId,string $idempotencyKey,array $trace=[]):array
    {
        $idempotencyKey=trim($idempotencyKey);
        if($idempotencyKey==='')throw new InvalidArgumentException('Governed outbound effect requires an idempotency_key.');
        if(strlen($idempotencyKey)>120)throw new InvalidArgumentException('Outbound effect idempotency_key exceeds 120 characters.');
        return $this->insertIntent($userId,$channel,$templateKey,$recipient,$payload,$subjectType,$subjectPublicId,$idempotencyKey,$trace);
    }

    /** @return list<array<string,mixed>> */
    public function pending(int $userId,int $limit=100):array
    {
        return $this->db->table('crm_notification_outbox')->where('company_id',CrmCompanyScope::companyId($userId))
            ->orderByDesc('id')->limit(min(max($limit,1),250))->get()->map(fn($r)=>(array)$r)->all();
    }

    /**
     * Atomically claim due effects. Terminal ['sent','delivered'] rows are never eligible.
     * @return list<array<string,mixed>>
     */
    public function claimDue(int $userId,int $limit=25):array
    {
        $tenant=CrmCompanyScope::companyId($userId);
        $limit=min(max($limit,1),100);
        $maxAttempts=max(1,(int)config('crm.governance.outbound_effects.max_attempts',5));
        $lease=max(30,(int)config('crm.governance.outbound_effects.claim_timeout_seconds',300));
        $stale=now()->subSeconds($lease);

        $candidates=$this->db->table('crm_notification_outbox')->where('company_id',$tenant)
            ->where('attempts','<',$maxAttempts)
            ->where(function($q)use($stale):void{
                $q->where(function($qq):void{
                    $qq->whereIn('status',['pending','failed'])->where(fn($due)=>$due->whereNull('available_at')->orWhere('available_at','<=',now()));
                })->orWhere(function($qq)use($stale):void{
                    $qq->where('status','processing')->whereNotNull('claimed_at')->where('claimed_at','<',$stale);
                });
            })
            ->orderBy('id')->limit($limit)->get();

        $claimed=[];
        foreach($candidates as $candidate){
            $id=(int)$candidate->id;
            $updated=$this->db->table('crm_notification_outbox')->where('company_id',$tenant)->where('id',$id)
                ->where('attempts','<',$maxAttempts)
                ->where(function($q)use($stale):void{
                    $q->whereIn('status',['pending','failed'])->orWhere(function($qq)use($stale):void{
                        $qq->where('status','processing')->whereNotNull('claimed_at')->where('claimed_at','<',$stale);
                    });
                })
                ->update([
                    'status'=>'processing','claimed_at'=>now(),'last_attempt_at'=>now(),
                    'attempts'=>$this->db->raw('attempts + 1'),'updated_at'=>now(),
                ]);
            if($updated!==1)continue;
            $row=$this->db->table('crm_notification_outbox')->where('company_id',$tenant)->where('id',$id)->first();
            if($row)$claimed[]=(array)$row;
        }
        return $claimed;
    }

    public function markDelivered(int $userId,string $publicId,array $provider=[]):array
    {
        $row=$this->findRequired($userId,$publicId);
        if(in_array((string)($row['status']??''),['sent','delivered'],true))return $row;
        $update=[
            'status'=>'delivered','provider'=>$provider['provider']??null,
            'provider_message_id'=>$provider['provider_message_id']??null,
            'provider_status'=>$provider['provider_status']??$provider['status']??'delivered',
            'last_error'=>null,'sent_at'=>now(),'claimed_at'=>null,'updated_at'=>now(),
        ];
        $this->db->table('crm_notification_outbox')->where('company_id',CrmCompanyScope::companyId($userId))->where('public_id',$publicId)
            ->whereNotIn('status',['sent','delivered'])->update($this->existingColumns($update));
        return $this->findRequired($userId,$publicId);
    }

    public function markFailed(int $userId,string $publicId,string $error,array $provider=[]):array
    {
        $row=$this->findRequired($userId,$publicId);
        if(in_array((string)($row['status']??''),['sent','delivered'],true))return $row;
        $attempts=(int)($row['attempts']??0);
        $max=max(1,(int)config('crm.governance.outbound_effects.max_attempts',5));
        $base=max(10,(int)config('crm.governance.outbound_effects.retry_base_seconds',60));
        $delay=$base*(2**max(0,min($attempts-1,6)));
        $retryable=(bool)($provider['retryable']??true);
        $update=[
            'status'=>'failed','provider'=>$provider['provider']??($row['provider']??null),
            'provider_message_id'=>$provider['provider_message_id']??($row['provider_message_id']??null),
            'provider_status'=>$provider['provider_status']??$provider['status']??'failed',
            'last_error'=>mb_substr($error,0,10000),'available_at'=>$retryable&&$attempts<$max?now()->addSeconds($delay):null,
            'claimed_at'=>null,'updated_at'=>now(),
        ];
        if(!$retryable)$update['attempts']=$max;
        $this->db->table('crm_notification_outbox')->where('company_id',CrmCompanyScope::companyId($userId))->where('public_id',$publicId)
            ->whereNotIn('status',['sent','delivered'])->update($this->existingColumns($update));
        return $this->findRequired($userId,$publicId);
    }

    public function markDeferred(int $userId,string $publicId,array $provider=[]):array
    {
        $row=$this->findRequired($userId,$publicId);
        if(in_array((string)($row['status']??''),['sent','delivered'],true))return $row;
        $delay=max(30,(int)config('crm.governance.outbound_effects.deferred_retry_seconds',300));
        $update=[
            'status'=>'pending','provider'=>$provider['provider']??($row['provider']??null),
            'provider_status'=>$provider['provider_status']??'deferred','available_at'=>now()->addSeconds($delay),
            'claimed_at'=>null,'updated_at'=>now(),
        ];
        $this->db->table('crm_notification_outbox')->where('company_id',CrmCompanyScope::companyId($userId))->where('public_id',$publicId)
            ->whereNotIn('status',['sent','delivered'])->update($this->existingColumns($update));
        return $this->findRequired($userId,$publicId);
    }

    /** @param array<string,mixed> $receipt */
    public function attachGovernance(int $userId,string $publicId,array $receipt):array
    {
        $update=[
            'trace_id'=>$receipt['trace_id']??null,'correlation_id'=>$receipt['correlation_id']??null,
            'causation_id'=>$receipt['causation_id']??null,'command_id'=>$receipt['command_id']??null,
            'receipt_id'=>$receipt['receipt_id']??null,'updated_at'=>now(),
        ];
        $this->db->table('crm_notification_outbox')->where('company_id',CrmCompanyScope::companyId($userId))->where('public_id',$publicId)
            ->update($this->existingColumns($update));
        return $this->findRequired($userId,$publicId);
    }

    /** Backwards-compatible status helper used by older CRM notification flows. */
    public function mark(int $userId,string $publicId,string $status,?string $error=null):array
    {
        if(!in_array($status,['pending','processing','sent','failed','delivered'],true))throw ValidationException::withMessages(['status'=>['Invalid notification status.']]);
        if($status==='delivered'||$status==='sent')return $this->markDelivered($userId,$publicId,['provider_status'=>$status]);
        if($status==='failed')return $this->markFailed($userId,$publicId,(string)$error);
        $query=$this->db->table('crm_notification_outbox')->where('company_id',CrmCompanyScope::companyId($userId))->where('public_id',$publicId);
        if(!$query->exists())throw ValidationException::withMessages(['notification'=>['Notification not found.']]);
        $query->update(['status'=>$status,'last_error'=>$error,'updated_at'=>now()]);
        return (array)$query->first();
    }

    /** @return array<string,mixed> */
    public function find(int $userId,string $publicId):array
    {
        $row=$this->db->table('crm_notification_outbox')->where('company_id',CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->first();
        return $row?(array)$row:[];
    }

    /** @param array<string,mixed> $trace */
    private function insertIntent(int $userId,string $channel,string $templateKey,?string $recipient,array $payload,?string $subjectType,?string $subjectPublicId,?string $idempotencyKey,array $trace):array
    {
        $tenant=CrmCompanyScope::companyId($userId);
        if($idempotencyKey!==null){
            $existing=$this->db->table('crm_notification_outbox')->where('company_id',$tenant)->where('idempotency_key',$idempotencyKey)->first();
            if($existing)return (array)$existing;
        }

        $row=[
            'public_id'=>(string)Str::ulid(),'company_id'=>$tenant,'user_id'=>CrmCompanyScope::actorUserId($userId),
            'channel'=>$channel,'recipient'=>$recipient,'template_key'=>$templateKey,'subject_type'=>$subjectType,'subject_public_id'=>$subjectPublicId,
            'payload'=>json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),'status'=>'pending','attempts'=>0,
            'last_error'=>null,'available_at'=>now(),'sent_at'=>null,'created_at'=>now(),'updated_at'=>now(),
        ];
        if($idempotencyKey!==null)$row['idempotency_key']=$idempotencyKey;
        foreach(['trace_id','correlation_id','causation_id','command_id','receipt_id'] as $field){if(array_key_exists($field,$trace))$row[$field]=$trace[$field];}
        $row=$this->existingColumns($row);

        $inserted=$this->db->table('crm_notification_outbox')->insertOrIgnore($row);
        if($inserted===1)return (array)$this->db->table('crm_notification_outbox')->where('company_id',$tenant)->where('public_id',$row['public_id'])->first();
        if($idempotencyKey!==null){
            $existing=$this->db->table('crm_notification_outbox')->where('company_id',$tenant)->where('idempotency_key',$idempotencyKey)->first();
            if($existing)return (array)$existing;
        }
        throw new \RuntimeException('Unable to persist CRM outbound communication intent.');
    }

    /** @return array<string,mixed> */
    private function findRequired(int $userId,string $publicId):array
    {
        $row=$this->find($userId,$publicId);
        if($row===[])throw ValidationException::withMessages(['notification'=>['Notification not found.']]);
        return $row;
    }

    /** @param array<string,mixed> $data @return array<string,mixed> */
    private function existingColumns(array $data):array
    {
        try{
            $columns=$this->db->getSchemaBuilder()->getColumnListing('crm_notification_outbox');
            return array_intersect_key($data,array_flip($columns));
        }catch(\Throwable){return $data;}
    }
}
