# Failure Modes

## Security context

- `TENANT_CONTEXT_UNRESOLVED`
- `ACTOR_ID_UNRESOLVED`
- `TENANT_SPOOFING_DETECTED`
- `ACTOR_SPOOFING_DETECTED`
- `ACTOR_TYPE_SPOOFING_DETECTED`
- `CROSS_TENANT_ACCESS_DENIED`
- `UNTRUSTED_ACTOR_CONTEXT`
- `TENANT_CONTEXT_MISMATCH`
- `CAPABILITY_DENIED`
- `AUTHORITY_LEVEL_INSUFFICIENT`

## Governance / mutation boundary

- `RISK_GATEWAY_UNAVAILABLE`
- `ASSURANCE_GATEWAY_UNAVAILABLE`
- `AUTONOMY_GATEWAY_UNAVAILABLE`
- `EXECUTION_DISABLED`
- `GOVERNANCE_NOT_APPROVED`
- `COMMAND_BUS_UNAVAILABLE`

Governance denials and missing governance engines do not crash Core. They produce a non-executable `PENDING_REVIEW`/blocked result. Security failures remain terminal for the submitted context and are never converted into provider retries.

A correctly trusted and governance-capable plan still cannot execute until deterministic DAG validation and later governed-execution passes are implemented.
