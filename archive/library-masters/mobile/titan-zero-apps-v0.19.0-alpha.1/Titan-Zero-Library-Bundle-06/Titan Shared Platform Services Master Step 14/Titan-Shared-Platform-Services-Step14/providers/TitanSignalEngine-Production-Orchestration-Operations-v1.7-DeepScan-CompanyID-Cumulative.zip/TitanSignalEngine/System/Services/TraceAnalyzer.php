<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\TraceAnalysis;
use App\Extensions\TitanSignalEngine\System\Data\TraceProfile;

final class TraceAnalyzer
{
    /** @param list<SignalEnvelope> $events */
    public function analyze(array $events, ?TraceProfile $profile): TraceAnalysis
    {
        $byId = $this->index($events);
        $missingParents = [];
        foreach ($events as $event) {
            if ($event->causationId !== null && ! isset($byId[$event->causationId])) {
                $missingParents[$event->eventId] = $event->causationId;
            }
        }

        [$ordered, $cycles] = $this->topologicalOrder($events);
        $missingTypes = [];
        $violations = [];
        $profileViolations = [];

        if ($profile !== null) {
            $present = [];
            foreach ($events as $event) {
                $present[$event->eventType] = true;
            }
            foreach ($profile->requiredEventTypes as $eventType) {
                if (! isset($present[$eventType])) {
                    $missingTypes[] = $eventType;
                }
            }

            $position = [];
            foreach ($ordered as $index => $event) {
                $position[$event->eventType] ??= $index;
            }
            foreach ($profile->orderingRules as $rule) {
                if (! isset($position[$rule['before']], $position[$rule['after']])) {
                    continue;
                }
                if ($position[$rule['before']] >= $position[$rule['after']]) {
                    $violations[] = [
                        'before' => $rule['before'],
                        'after' => $rule['after'],
                        'reason' => 'causal_order_violation',
                    ];
                }
            }

            if ($profile->terminalEventTypes !== []) {
                $terminalSatisfied = false;
                foreach ($profile->terminalEventTypes as $terminalType) {
                    if (isset($present[$terminalType])) {
                        $terminalSatisfied = true;
                        break;
                    }
                }
                if (! $terminalSatisfied) {
                    $profileViolations[] = [
                        'code' => 'terminal_event_missing',
                        'expected_any_of' => $profile->terminalEventTypes,
                    ];
                }
            }
        }

        $status = 'unprofiled';
        if ($cycles !== []) {
            $status = 'invalid';
        } elseif ($missingParents !== [] || $missingTypes !== [] || $violations !== [] || $profileViolations !== []) {
            $status = 'incomplete';
        } elseif ($profile !== null) {
            $status = 'complete';
        }

        return new TraceAnalysis(
            $status,
            $ordered,
            $missingTypes,
            $missingParents,
            $violations,
            $cycles,
            $profileViolations,
            $profile?->profileKey,
            $profile?->version,
        );
    }

    /** @param list<SignalEnvelope> $events @return list<SignalEnvelope> */
    public function ancestors(string $eventId, array $events, int $maxDepth = 100): array
    {
        $byId = $this->index($events);
        $result = [];
        $seen = [];
        $current = $byId[$eventId] ?? null;
        for ($depth = 0; $current !== null && $current->causationId !== null && $depth < max(1, $maxDepth); $depth++) {
            $parent = $byId[$current->causationId] ?? null;
            if ($parent === null || isset($seen[$parent->eventId])) {
                break;
            }
            $seen[$parent->eventId] = true;
            $result[] = $parent;
            $current = $parent;
        }
        return $result;
    }

    /** @param list<SignalEnvelope> $events @return list<SignalEnvelope> */
    public function descendants(string $eventId, array $events, int $maxDepth = 100): array
    {
        $children = [];
        foreach ($events as $event) {
            if ($event->causationId !== null) {
                $children[$event->causationId][] = $event;
            }
        }
        foreach ($children as &$siblings) {
            usort($siblings, fn (SignalEnvelope $a, SignalEnvelope $b): int => $this->compareChronology($a, $b));
        }
        unset($siblings);

        $result = [];
        $seen = [$eventId => true];
        $queue = [[$eventId, 0]];
        while ($queue !== []) {
            [$parentId, $depth] = array_shift($queue);
            if ($depth >= max(1, $maxDepth)) {
                continue;
            }
            foreach ($children[$parentId] ?? [] as $child) {
                if (isset($seen[$child->eventId])) {
                    continue;
                }
                $seen[$child->eventId] = true;
                $result[] = $child;
                $queue[] = [$child->eventId, $depth + 1];
            }
        }
        return $result;
    }

    /** @param list<SignalEnvelope> $events @return array{0:list<SignalEnvelope>,1:list<string>} */
    private function topologicalOrder(array $events): array
    {
        $byId = $this->index($events);
        $indegree = [];
        $children = [];
        foreach ($events as $event) {
            $indegree[$event->eventId] = 0;
        }
        foreach ($events as $event) {
            if ($event->causationId !== null && isset($byId[$event->causationId])) {
                $indegree[$event->eventId]++;
                $children[$event->causationId][] = $event->eventId;
            }
        }

        $ready = [];
        foreach ($events as $event) {
            if (($indegree[$event->eventId] ?? 0) === 0) {
                $ready[] = $event;
            }
        }
        usort($ready, fn (SignalEnvelope $a, SignalEnvelope $b): int => $this->compareChronology($a, $b));

        $ordered = [];
        while ($ready !== []) {
            /** @var SignalEnvelope $event */
            $event = array_shift($ready);
            $ordered[] = $event;
            foreach ($children[$event->eventId] ?? [] as $childId) {
                $indegree[$childId]--;
                if ($indegree[$childId] === 0) {
                    $ready[] = $byId[$childId];
                    usort($ready, fn (SignalEnvelope $a, SignalEnvelope $b): int => $this->compareChronology($a, $b));
                }
            }
        }

        $cycles = [];
        if (count($ordered) !== count($events)) {
            $orderedIds = array_fill_keys(array_map(static fn (SignalEnvelope $event): string => $event->eventId, $ordered), true);
            foreach ($events as $event) {
                if (! isset($orderedIds[$event->eventId])) {
                    $cycles[] = $event->eventId;
                }
            }
            sort($cycles);
            $remaining = array_values(array_filter($events, static fn (SignalEnvelope $event): bool => in_array($event->eventId, $cycles, true)));
            usort($remaining, fn (SignalEnvelope $a, SignalEnvelope $b): int => $this->compareChronology($a, $b));
            array_push($ordered, ...$remaining);
        }

        return [$ordered, $cycles];
    }

    /** @param list<SignalEnvelope> $events @return array<string,SignalEnvelope> */
    private function index(array $events): array
    {
        $result = [];
        foreach ($events as $event) {
            $result[$event->eventId] = $event;
        }
        return $result;
    }

    private function compareChronology(SignalEnvelope $a, SignalEnvelope $b): int
    {
        $occurred = $a->occurredAt <=> $b->occurredAt;
        if ($occurred !== 0) {
            return $occurred;
        }
        $recorded = $a->recordedAt <=> $b->recordedAt;
        return $recorded !== 0 ? $recorded : strcmp($a->eventId, $b->eventId);
    }
}
