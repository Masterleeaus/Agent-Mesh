# Production Orchestration Operations v1.6

This pass adds production controls to the durable Workforce handoff outbox: bounded batch dispatch, company-scoped dead-letter inspection/redrive, expired lease recovery, exponential retry backoff, stalled-work health counts, and delivered-record retention pruning. `company_id` remains the canonical tenant boundary. Provider outages remain fail-closed and authority is never increased by retry or failover.
