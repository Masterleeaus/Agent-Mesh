# Uninstall

Uninstall preserves extension-owned durable data by default and removes only the published `config/titan-wisdom.php` file. Governed tenant retention or deletion is a separate explicit operation.
