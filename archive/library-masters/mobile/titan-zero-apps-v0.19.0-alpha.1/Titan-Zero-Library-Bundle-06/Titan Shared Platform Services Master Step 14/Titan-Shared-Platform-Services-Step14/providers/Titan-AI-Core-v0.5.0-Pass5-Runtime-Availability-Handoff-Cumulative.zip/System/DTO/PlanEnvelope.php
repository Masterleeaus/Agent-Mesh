<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class PlanEnvelope {
    /** @param array<int,PlanStep> $steps @param array<int,PlanConstraint> $constraints */
    public function __construct(public string $planId, public RuntimeContext $runtimeContext, public ExecutionIntent $intent, public array $steps = [], public array $constraints = [], public string $schemaVersion = '1.0', public string $planSchemaVersion = '1.0', public string $runtimeVersion = '0.5.0') {}
    public function tenantCompanyId(): string { return $this->runtimeContext->tenantCompanyId; }
    public function toArray(): array { return ['plan_id'=>$this->planId,'runtime_context'=>$this->runtimeContext->toArray(),'intent'=>$this->intent->toArray(),'steps'=>array_map(fn(PlanStep $v)=>$v->toArray(),$this->steps),'constraints'=>array_map(fn(PlanConstraint $v)=>$v->toArray(),$this->constraints),'schema_version'=>$this->schemaVersion,'plan_schema_version'=>$this->planSchemaVersion,'runtime_version'=>$this->runtimeVersion]; }
}
