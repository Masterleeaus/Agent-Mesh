# Titan AI Core — Pass 5 runtime availability compatibility

This pass makes runtime availability machine-readable for Titan AI Workforce without removing legacy status fields.

Canonical states: `available`, `degraded`, `unavailable`, `missing_provider`, `blocked`, `policy_disabled`. Provider/model versions are reported only when actually known; an unknown version is never invented. Installation or availability never grants authority. `company_id` remains the canonical company boundary; any legacy tenant key remains compatibility-only.
