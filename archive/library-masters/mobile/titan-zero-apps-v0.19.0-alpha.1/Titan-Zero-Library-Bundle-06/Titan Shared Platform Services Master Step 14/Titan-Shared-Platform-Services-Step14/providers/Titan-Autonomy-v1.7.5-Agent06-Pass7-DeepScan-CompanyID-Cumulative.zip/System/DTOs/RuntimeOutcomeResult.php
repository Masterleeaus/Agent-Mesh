<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\DTOs;

final readonly class RuntimeOutcomeResult
{
    public function __construct(
        public CapabilityState $state,
        public ?GateEvaluation $gate,
        public ?string $learningReference,
        public ?string $gateAuditReference = null,
        public ?string $regressionAuditReference = null,
    ) {}
}
