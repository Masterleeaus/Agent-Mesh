<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Entities;

use App\Extensions\TitanPrime\System\Domain\Enums\PrimeApprovalStatus;
use InvalidArgumentException;

final readonly class PrimeApproval
{
    public function __construct(
        public string $approvalId,
        public string $missionId,
        public PrimeApprovalStatus $status,
        public ?string $authority = null,
        public ?string $actorId = null,
        public ?string $reasonCode = null,
        public ?string $decidedAt = null,
    ) {
        if (trim($approvalId) === '' || trim($missionId) === '') {
            throw new InvalidArgumentException('Approval id and mission id are required.');
        }
    }
}
