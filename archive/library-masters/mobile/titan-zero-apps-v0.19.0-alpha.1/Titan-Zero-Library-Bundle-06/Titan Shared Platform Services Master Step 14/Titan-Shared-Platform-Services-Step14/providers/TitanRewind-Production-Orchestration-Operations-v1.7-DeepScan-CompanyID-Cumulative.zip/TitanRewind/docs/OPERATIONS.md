# Titan Rewind Operations

Configure a readable RSA evidence keyring, run queue workers for `titan-rewind-replay` and `titan-rewind-signal`, keep the scheduler active for bounded retention, register read-only host Rewind source adapters, and bind real Titan Signal/Governance adapters. Watermark-unaware or unauthenticated sources make audits partial by design.

Use liveness/readiness for service monitoring. Runtime states `ACTIVE`, `DEGRADED`, `MAINTENANCE`, `DRAINING`, `DISABLED` and `UNINSTALLING` control admission; draining rejects new replay work but permits in-flight completion. Dead-letter items are operator-visible and supported jobs have explicit retry paths.

Before production deployment, run `php artisan titan-rewind:certify --json` in the exact MagicAI/Titan host and complete `docs/HOST-CERTIFICATION.md`. Package-profile validation is not a substitute for verifying the site's database, queue backend, scheduler, theme or live Titan adapters.
