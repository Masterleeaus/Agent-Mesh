<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('titan_ai_core_plans')) {
            return;
        }

        Schema::table('titan_ai_core_plans', function (Blueprint $table): void {
            if (!Schema::hasColumn('titan_ai_core_plans', 'actor_id')) {
                $table->string('actor_id', 191)->nullable()->after('tenant_company_id')->index();
            }
            if (!Schema::hasColumn('titan_ai_core_plans', 'actor_type')) {
                $table->string('actor_type', 64)->nullable()->after('actor_id');
            }
            if (!Schema::hasColumn('titan_ai_core_plans', 'authority_level')) {
                $table->unsignedSmallInteger('authority_level')->default(0)->after('actor_type');
            }
            if (!Schema::hasColumn('titan_ai_core_plans', 'principal_source')) {
                $table->string('principal_source', 96)->nullable()->after('authority_level');
            }
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('titan_ai_core_plans')) {
            return;
        }

        Schema::table('titan_ai_core_plans', function (Blueprint $table): void {
            foreach (['actor_id', 'actor_type', 'authority_level', 'principal_source'] as $column) {
                if (Schema::hasColumn('titan_ai_core_plans', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
