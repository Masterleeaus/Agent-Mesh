# Extension Manifest Contract

Titan Maps Intelligence uses the live Titan Extension Manager manifest as the authoritative install contract and retains the hardened Blueprint v3.1 sidecar for architecture metadata.

## Titan installer `extension.json`

The compatibility manifest contains exactly `name`, `type`, `version`, `description`, and `support_telegram`.

Current release: `2.0.0-alpha.3`; type: `extension`.

## Hardened `extension.manifest.json`

- Key: `titan-maps-intelligence`
- Folder: `TitanMapsIntelligence`
- Namespace: `App\Extensions\TitanMapsIntelligence`
- Provider: `App\Extensions\TitanMapsIntelligence\System\TitanMapsIntelligenceServiceProvider`
- Family: `vertical-suite`
- Tenant key: `company_id`
- Credential storage: `credential-vault`
- Queue tenant context required: `true`
- Current external host: `places.googleapis.com`

## Route declarations

Pass 3 declares four mounted roots:

1. authenticated user — `dashboard/user/titan-maps-intelligence`
2. admin — `dashboard/admin/titan-maps-intelligence`
3. authenticated API — `api/titan/maps-intelligence`
4. internal — `internal/titan/maps-intelligence`

Blueprint v3.1 has no separate `api` profile enum, so the Sanctum-protected API correctly uses the `authenticated-user` manifest profile while the provider applies API-specific middleware at runtime.

## Permissions

The existing discovery permissions remain and Pass 3 adds `titan-maps-intelligence.admin.access` for platform administration. Every current API action has explicit route-level permission middleware in addition to controller/service authorization.

## Capabilities

The twelve existing discovery/governance capabilities remain unchanged:

1. search businesses
2. read search
3. cancel search
4. export search
5. list candidates
6. match candidate
7. classify candidate
8. approve candidate
9. reject candidate
10. promote candidate
11. analyse territory
12. read provider usage

## Database declaration

All 13 persistent Maps tables remain extension-owned with `database.migrations: true`. `CompanyScopedModel` is abstract and owns no table. Pass 3 makes persistent tenant ownership immutable after creation.

## Lifecycle

`registerKey()` returns `titan-maps-intelligence`. `uninstall()` remains idempotent and retains tenant data because migrations are forward-only.
