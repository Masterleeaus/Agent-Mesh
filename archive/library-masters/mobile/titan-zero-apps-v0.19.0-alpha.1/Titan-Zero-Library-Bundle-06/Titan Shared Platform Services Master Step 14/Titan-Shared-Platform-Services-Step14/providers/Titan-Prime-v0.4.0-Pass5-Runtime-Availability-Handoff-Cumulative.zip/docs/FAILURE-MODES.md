# Failure Modes

Prime fails closed on:

- invalid mission lifecycle transitions;
- invalid tenant, mission or causal identifiers;
- stale mission version/status;
- duplicate mission identity or conflicting idempotency payload;
- corrupt persisted Prime state;
- risk-budget violations;
- unbound external engine bridge;
- unavailable target engine;
- external bridge exception;
- engine/capability/operation response mismatch;
- forbidden secret-like gateway payload fields;
- explicit downstream denial or escalation.

Raw downstream exception messages are not copied into Prime gateway results. Exception class may be retained as non-secret diagnostic metadata.

No gateway failure may cause a direct foreign write, an authority increase, or a bypass of the required governance chain.
