# Titan Model Council v0.5.0 — Pass 4

- Integrated the actual Titan Risk Engine v0.2.0 `RiskManagerContract::assess(RiskContext)`.
- Added preflight and postflight Council risk assessments.
- Risk decisions can increase Council depth and cannot be downgraded by manual strategy selection.
- Persisted Risk score, level, decision, policy version, reason codes, and pre/postflight receipts.
- Added optional peer declarations for Titan AI Core and Titan Risk Engine.
- Added an AI Core runtime probe that truthfully detects that AI Core v0.2.0 publishes health only and therefore cannot yet own provider execution.
- Retained legacy provider execution as an explicit compatibility fallback until AI Core publishes an execution contract.
- No unrestricted chain-of-thought is persisted.
