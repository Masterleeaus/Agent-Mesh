<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Escalation;

final class GovernanceEscalationPriority
{
    /** @param list<array<string,mixed>> $rows @return list<array<string,mixed>> */
    public function sort(array $rows): array
    {
        foreach($rows as &$row)$row['priority_score']=$this->score($row);
        unset($row);
        usort($rows,static function(array $a,array $b):int{
            $risk=((float)($b['risk_score']??0))<=>((float)($a['risk_score']??0)); if($risk!==0)return $risk;
            $urg=((int)($b['urgency']??0))<=>((int)($a['urgency']??0)); if($urg!==0)return $urg;
            return strcmp((string)($a['opened_at']??''),(string)($b['opened_at']??''));
        });
        return $rows;
    }

    /** @param array<string,mixed> $row */
    public function score(array $row): int
    {
        $risk=max(0.0,min(100.0,(float)($row['risk_score']??0)));
        $urgency=max(0,min(100,(int)($row['urgency']??0)));
        return (int)round($risk*1_000_000)+($urgency*100);
    }
}
