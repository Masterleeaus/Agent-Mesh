<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyAuditSinkContract;
use App\Extensions\TitanAutonomy\System\Services\RewindCorrelationService;
use Illuminate\Support\Facades\DB;

final class DatabaseAutonomyAuditSink implements AutonomyAuditSinkContract
{
    public function __construct(private readonly ?RewindCorrelationService $rewind = null) {}
    public function recordGateDecision(array $event): string
    {
        $id = (int) app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_gate_decisions')->insertGetId([
            'tenant_company_id' => $event['tenant_company_id'],
            'user_id' => $event['user_id'] ?? null,
            'capability' => $event['capability'],
            'workflow_key' => $event['workflow_key'] ?? '',
            'current_level' => $event['current_level'],
            'requested_level' => $event['requested_level'],
            'eligible' => (bool) $event['eligible'],
            'reason_codes_json' => $this->json($event['reason_codes'] ?? []),
            'evidence_json' => $this->json($event['evidence'] ?? []),
            'policy_version' => $event['policy_version'],
            'correlation_id' => $event['correlation_id'] ?? null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $this->rewind?->record('autonomy.gate_decision', ['gate_decision_id' => $id] + $event);
        return (string) $id;
    }

    public function recordHandshake(array $event): string
    {
        $now = now();
        $id = (int) app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_handshakes')->insertGetId([
            'tenant_company_id' => $event['tenant_company_id'],
            'user_id' => $event['user_id'] ?? null,
            'capability' => $event['capability'],
            'workflow_key' => $event['workflow_key'] ?? '',
            'requested_level' => $event['requested_level'],
            'requested_scope_json' => $this->json($event['requested_scope'] ?? []),
            'platform_decision' => $event['platform_decision'],
            'platform_reason_codes_json' => $this->json($event['platform_reason_codes'] ?? []),
            'platform_decided_at' => $now,
            'user_decision' => $event['user_decision'],
            'user_decided_at' => $event['user_decision'] === 'pending' ? null : $now,
            'ai_decision' => $event['ai_decision'],
            'ai_confidence' => $event['ai_confidence'] ?? null,
            'ai_reason_codes_json' => $this->json($event['ai_reason_codes'] ?? []),
            'ai_decided_at' => $event['ai_decision'] === 'pending' ? null : $now,
            'final_decision' => $event['final_decision'],
            'activated_at' => $event['final_decision'] === 'approved' ? $now : null,
            'review_at' => $event['review_at'] ?? null,
            'policy_version' => $event['policy_version'],
            'assurance_evaluation_ref' => $event['assurance_evaluation_ref'] ?? null,
            'correlation_id' => $event['correlation_id'] ?? null,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        $this->rewind?->record('autonomy.handshake', ['handshake_id' => $id] + $event);
        return (string) $id;
    }

    public function recordRegression(array $event): string
    {
        $id = (int) app(\Illuminate\Database\DatabaseManager::class)->table('titan_autonomy_regressions')->insertGetId([
            'tenant_company_id' => $event['tenant_company_id'],
            'capability' => $event['capability'],
            'workflow_key' => $event['workflow_key'] ?? '',
            'prior_level' => $event['prior_level'],
            'new_level' => $event['new_level'],
            'cause' => $event['cause'],
            'evidence_json' => $this->json($event['evidence'] ?? []),
            'policy_version' => $event['policy_version'],
            'correlation_id' => $event['correlation_id'] ?? null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $this->rewind?->record('autonomy.regression', ['regression_id' => $id] + $event);
        return (string) $id;
    }

    private function json(mixed $value): string
    {
        return json_encode($value, JSON_THROW_ON_ERROR);
    }
}
