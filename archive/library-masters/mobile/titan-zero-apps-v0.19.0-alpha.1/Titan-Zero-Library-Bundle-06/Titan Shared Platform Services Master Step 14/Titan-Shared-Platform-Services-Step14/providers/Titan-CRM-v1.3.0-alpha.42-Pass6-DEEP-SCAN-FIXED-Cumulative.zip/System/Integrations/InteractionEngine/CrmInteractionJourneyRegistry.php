<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\InteractionEngine;

/**
 * CRM-owned semantic journey catalogue. Interaction Engine owns wizard state,
 * validation, authority and execution; CRM describes the action vocabulary,
 * page placement and the temporary advanced/legacy fallback.
 */
final class CrmInteractionJourneyRegistry
{
    /** @return array<string,array<string,mixed>> */
    public function definitions(): array
    {
        return [
            // Customers and leads.
            'new-customer'=>$this->d('new-customer','New Customer','crm_new_customer_v1','crm.customer.create','customers','New Customer','dashboard.user.crm.contacts.index'),
            'new-contact'=>$this->d('new-contact','New Contact','crm_new_contact_v1','crm.contact.create','customers','New Contact','dashboard.user.crm.contacts.index'),
            'new-lead'=>$this->d('new-lead','New Lead','crm_new_lead_v1','crm.lead.create','leads','New Lead','dashboard.user.crm.leads.index'),
            'new-opportunity'=>$this->d('new-opportunity','New Opportunity','crm_new_opportunity_v1','crm.deal.create','leads','New Opportunity','dashboard.user.crm.deals.index'),
            'new-pipeline'=>$this->d('new-pipeline','New Pipeline','crm_new_pipeline_v1','crm.pipeline.create','leads','New Pipeline','dashboard.user.crm.pipelines.index'),
            'new-quote'=>$this->d('new-quote','New Quote','crm_create_quote_v1','crm.quote.create','leads','New Quote','dashboard.user.sales.documents.create',['advanced_params'=>['type'=>'proposals']]),
            'new-estimate'=>$this->d('new-estimate','New Estimate','crm_new_estimate_v1','crm.estimate.create','leads','New Estimate','dashboard.user.sales.documents.create',['advanced_params'=>['type'=>'estimates']]),

            // Work and crew.
            'new-project'=>$this->d('new-project','New Project','crm_new_project_v1','crm.project.create','work','New Project','dashboard.user.crm.projects.index'),
            'new-task'=>$this->d('new-task','New Task','crm_new_task_v1','crm.task.create','work','New Task','dashboard.user.crm.tasks.index'),
            'new-calendar-event'=>$this->d('new-calendar-event','New Calendar Event','crm_new_calendar_event_v1','crm.calendar.create','crew','New Event','dashboard.user.crm.calendar.index'),
            'new-hub-access'=>$this->d('new-hub-access','New Customer Hub Access','crm_new_hub_access_v1','crm.portal.grant.create','customers','New Hub Access','dashboard.user.crm.portal.index'),

            // Money.
            'new-invoice'=>$this->d('new-invoice','New Invoice','crm_create_invoice_v1','crm.invoice.create','money','New Invoice','dashboard.user.sales.documents.create',['advanced_params'=>['type'=>'invoices']]),

            // Automation.
            'new-tag'=>$this->d('new-tag','New Tag','crm_new_tag_v1','crm.tag.create','settings','New Tag','dashboard.user.crm.metadata.index'),
            'new-custom-field'=>$this->d('new-custom-field','New Custom Field','crm_new_custom_field_v1','crm.custom_field.create','settings','New Custom Field','dashboard.user.crm.metadata.index'),
            'new-api-key'=>$this->d('new-api-key','New API Key','crm_new_api_key_v1','crm.api_key.create','automate','New API Key','dashboard.user.crm.integrations.index'),
            'new-webhook'=>$this->d('new-webhook','New Webhook','crm_new_webhook_v1','crm.webhook.create','automate','New Webhook','dashboard.user.crm.integrations.index'),
            'new-share'=>$this->d('new-share','New Share','crm_new_share_v1','crm.share.create','customers','New Share','dashboard.user.crm.sharing.index'),
            'new-automation'=>$this->d('new-automation','New Automation','crm_new_automation_v1','crm.automation.create','automate','New Automation','dashboard.user.crm.automations.index'),

            // Titan Gear / Locker.


            // Alpha.12 record-scoped ongoing actions.
            'update-customer'=>$this->d('update-customer','Update Customer','crm_update_customer_v1','crm.customer.update','customers','Update Customer',metadata:['record_type'=>'customer','required_context'=>['public_id']]),
            'update-contact'=>$this->d('update-contact','Update Contact','crm_update_contact_v1','crm.contact.update','customers','Update Contact',metadata:['record_type'=>'contact','required_context'=>['public_id']]),
            'update-lead'=>$this->d('update-lead','Update Lead','crm_update_lead_v1','crm.lead.update','leads','Update Lead',metadata:['record_type'=>'lead','required_context'=>['public_id']]),
            'convert-lead'=>$this->d('convert-lead','Convert Lead','crm_convert_lead_v1','crm.lead.convert','leads','Convert Lead',metadata:['record_type'=>'lead','required_context'=>['public_id']]),
            'update-opportunity'=>$this->d('update-opportunity','Update Opportunity','crm_update_opportunity_v1','crm.deal.update','leads','Update Opportunity',metadata:['record_type'=>'opportunity','required_context'=>['public_id']]),
            'move-opportunity'=>$this->d('move-opportunity','Move Opportunity','crm_move_opportunity_v1','crm.deal.move','leads','Move Opportunity',metadata:['record_type'=>'opportunity','required_context'=>['public_id']]),
            'win-opportunity'=>$this->d('win-opportunity','Mark Opportunity Won','crm_win_opportunity_v1','crm.deal.win','leads','Mark Won',metadata:['record_type'=>'opportunity','required_context'=>['public_id']]),
            'lose-opportunity'=>$this->d('lose-opportunity','Mark Opportunity Lost','crm_lose_opportunity_v1','crm.deal.lose','leads','Mark Lost',metadata:['record_type'=>'opportunity','required_context'=>['public_id']]),
            'accept-quote'=>$this->d('accept-quote','Accept Quote','crm_accept_quote_v1','crm.quote.approve','leads','Accept Quote',metadata:['record_type'=>'quote','required_context'=>['public_id']]),
            'transition-quote'=>$this->d('transition-quote','Change Quote Status','crm_transition_quote_v1','crm.quote.transition','leads','Change Status',metadata:['record_type'=>'quote','required_context'=>['public_id','type']]),
            'transition-invoice'=>$this->d('transition-invoice','Change Invoice Status','crm_transition_invoice_v1','crm.invoice.transition','money','Change Status',metadata:['record_type'=>'invoice','required_context'=>['public_id']]),
            'send-invoice'=>$this->d('send-invoice','Send Invoice','crm_send_invoice_v1','crm.invoice.send','money','Send Invoice',metadata:['record_type'=>'invoice','required_context'=>['public_id']]),
            'send-invoice-reminder'=>$this->d('send-invoice-reminder','Send Invoice Reminder','crm_send_invoice_reminder_v1','crm.invoice.reminder.send','money','Send Reminder',metadata:['record_type'=>'invoice','required_context'=>['public_id']]),
        ];
    }

    public function has(string $key): bool { return isset($this->definitions()[$key]); }

    /** @return array<string,mixed> */
    public function get(string $key): array
    {
        $definition=$this->definitions()[$key]??null;
        if($definition===null)throw new \InvalidArgumentException("Unknown CRM interaction journey: {$key}");
        return $definition;
    }

    /** @return list<array<string,mixed>> */
    public function forSurface(string $surface): array
    {
        return array_values(array_filter($this->definitions(),static fn(array $d):bool=>$d['surface']===$surface));
    }

    /** @return array<string,mixed>|null */
    public function byWizard(string $wizard): ?array
    {
        foreach($this->definitions() as $definition)if($definition['wizard']===$wizard)return $definition;
        return null;
    }

    /** @return array<string,mixed> */
    private function d(string $key,string $name,string $wizard,string $capability,string $surface,string $newLabel,?string $advancedRoute=null,array $metadata=[]): array
    {
        return compact('key','name','wizard','capability','surface','newLabel','advancedRoute','metadata');
    }
}
