# Disaster Recovery

Prime-owned strategic records are part of extension durable-state backups. Target RPO is 60 minutes and target RTO is 240 minutes. Restore the host database first, confirm `titan_prime_missions`, run migrations, run Prime host certification, and reconcile restored mission lineage before any future mission runner is re-enabled.
