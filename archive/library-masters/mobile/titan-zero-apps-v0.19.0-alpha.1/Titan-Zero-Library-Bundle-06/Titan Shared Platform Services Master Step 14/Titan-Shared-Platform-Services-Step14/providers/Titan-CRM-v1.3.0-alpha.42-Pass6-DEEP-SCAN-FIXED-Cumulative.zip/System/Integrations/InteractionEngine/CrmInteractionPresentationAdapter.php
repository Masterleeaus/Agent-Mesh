<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\InteractionEngine;

/** Presentation-only adapter. It never mutates sessions or business records. */
final class CrmInteractionPresentationAdapter
{
    /** @return array<string,mixed> */
    public function present(object $session,array $payload,?array $journey): array
    {
        $vm=(array)($payload['view_model']??[]);
        $step=$vm['step']??null;
        $count=method_exists($session->definition,'stepCount')?$session->definition->stepCount():0;
        $index=(int)($vm['step_index']??$session->stepIndex??0);
        return [
            'title'=>$journey['name']??$session->definition->name,
            'surface'=>$journey['surface']??'all',
            'step'=>$step,
            'step_index'=>$index,
            'step_count'=>$count,
            'progress'=>$count>0?min(100,(int)round(($index/$count)*100)):100,
            'review_ready'=>$step===null || $index >= $count,
            'advanced_available'=>!empty($journey['advancedRoute']),
            'capability'=>$session->definition->capability,
        ];
    }
}
