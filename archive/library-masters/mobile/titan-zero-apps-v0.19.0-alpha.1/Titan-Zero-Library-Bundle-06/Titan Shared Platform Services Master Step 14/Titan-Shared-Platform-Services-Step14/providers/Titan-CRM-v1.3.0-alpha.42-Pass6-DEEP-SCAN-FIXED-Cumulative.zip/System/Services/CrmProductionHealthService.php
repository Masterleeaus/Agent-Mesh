<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Capabilities\CrmCapabilityOwnershipMap;
use App\Extensions\Crm\System\Governance\{CrmCommandBusPort,CrmSignalDeliveryPort,CrmWriteSurfaceAuditor};
use App\Extensions\Crm\System\Portal\{CrmPortalFileScanner,NullCrmPortalFileScanner};
use App\Extensions\Crm\System\Integrations\TitanAutonomy\{CrmAutonomyDecisionPort,CrmDeferredAutonomyDecisionPort};
use App\Extensions\Crm\System\ReadModels\CrmReadProjectionRegistry;
use Illuminate\Database\ConnectionInterface;

/**
 * Lightweight production-readiness probe. It intentionally does not mutate state.
 * Blockers indicate a configuration/schema condition that makes authoritative CRM unsafe.
 */
final class CrmProductionHealthService
{
    public function __construct(
        private readonly ConnectionInterface $db,
        private readonly CrmCapabilityOwnershipMap $ownership,
        private readonly CrmCommandBusPort $commandBus,
        private readonly CrmSignalDeliveryPort $signalDelivery,
        private readonly CrmPortalFileScanner $portalScanner,
        private readonly CrmAutonomyDecisionPort $autonomy,
        private readonly CrmWriteSurfaceAuditor $writeSurfaces,
        private readonly CrmReadProjectionRegistry $projectionRegistry,
        private readonly CrmOperationalMetricsService $metrics,
    ) {}

    /** @return array{status:string,blockers:array<int,string>,warnings:array<int,string>,checks:array<string,mixed>} */
    public function inspect(): array
    {
        $blockers=[];$warnings=[];$checks=[];
        $schema=$this->db->getSchemaBuilder();

        $operationalMetrics=$this->metrics->collect(null,(int)config('crm.observability.window_hours',24));
        $checks['operational_metrics']=$operationalMetrics;
        $commandP95=(int)($operationalMetrics['command_operations']['latency_ms']['p95']??0);
        if($commandP95>(int)config('crm.observability.command_latency_warn_ms',1500))$warnings[]="CRM command p95 latency is {$commandP95}ms, above the configured warning threshold.";
        $signalBacklog=(int)($operationalMetrics['signal_outbox']['backlog_total']??0);
        if($signalBacklog>(int)config('crm.observability.signal_backlog_warn',100))$warnings[]="CRM Signal outbox backlog is {$signalBacklog}.";
        $projectionDead=(int)($operationalMetrics['projection_health']['dead_letters']??0);
        if($projectionDead>=(int)config('crm.observability.projection_dead_letters_warn',1)&&$projectionDead>0)$warnings[]="CRM projection dead-letter backlog is {$projectionDead}.";
        $webhookDead=(int)($operationalMetrics['webhooks']['statuses']['dead_letter']??0);
        if($webhookDead>=(int)config('crm.observability.webhook_dead_letters_warn',1)&&$webhookDead>0)$warnings[]="CRM webhook dead-letter backlog is {$webhookDead}.";
        $importFailures=(int)($operationalMetrics['imports']['statuses']['failed']??0)+(int)($operationalMetrics['imports']['statuses']['validation_failed']??0);
        if($importFailures>=(int)config('crm.observability.import_failures_warn',1)&&$importFailures>0)$warnings[]="CRM import failure/validation backlog is {$importFailures}.";
        $portalQuarantine=(int)($operationalMetrics['portal']['quarantined_files']??0)+(int)($operationalMetrics['portal']['scan_failed_files']??0)+(int)($operationalMetrics['portal']['infected_files']??0);
        if($portalQuarantine>=(int)config('crm.observability.portal_quarantine_warn',1)&&$portalQuarantine>0)$warnings[]="CRM portal quarantine backlog is {$portalQuarantine}.";
        $outboundBacklog=(int)($operationalMetrics['outbound_effects']['backlog_total']??0);
        if($outboundBacklog>(int)config('crm.observability.outbound_backlog_warn',100))$warnings[]="CRM outbound-effect backlog is {$outboundBacklog}.";

        $writeAudit=$this->writeSurfaces->audit();
        $checks['write_surface_audit']=['ok'=>$writeAudit['status']==='pass','http_count'=>count($writeAudit['http']),'console_count'=>count($writeAudit['console']),'failures'=>$writeAudit['failures']];
        if((bool)config('crm.governance.write_surface_audit_required',true)&&$writeAudit['status']!=='pass')$blockers[]='CRM write-surface governance audit failed; one or more public/scheduled mutations bypass Command Bus governance.';

        $requiredTables=(array)config('crm.production.required_tables',[
            'crm_companies','crm_contacts','crm_leads','crm_deals','crm_proposals','crm_estimates','crm_invoices',
            'crm_capability_operations','crm_domain_signal_outbox','crm_read_projection_records','crm_invoice_settlement_references','crm_credit_notes','crm_receivable_reconciliation_issues',
        ]);
        $missing=[];
        foreach($requiredTables as $table){ if(!$schema->hasTable((string)$table))$missing[]=(string)$table; }
        $checks['required_tables']=['ok'=>$missing===[],'missing'=>$missing];
        if($missing!==[])$blockers[]='Missing required CRM tables: '.implode(', ',$missing);

        $commandColumns=['command_contract_version','request_envelope','expected_entity_version','affected_resources','invariant_results','external_effect_references','compensation_state','signal_references'];
        $missingCommandColumns=[];
        if($schema->hasTable('crm_capability_operations'))foreach($commandColumns as $column)if(!$schema->hasColumn('crm_capability_operations',$column))$missingCommandColumns[]=$column;
        $checks['command_contract_v3_schema']=['ok'=>$missingCommandColumns===[],'missing_columns'=>$missingCommandColumns];
        if($missingCommandColumns!==[])$blockers[]='CRM Command Contract v3 schema is incomplete: '.implode(', ',$missingCommandColumns);

        $missingRoots=[];
        foreach(['crm_companies','crm_contacts','crm_leads'] as $table){if($schema->hasTable($table)&&$schema->hasColumn($table,'customer_unification_id')){$count=(int)$this->db->table($table)->whereNull('customer_unification_id')->whereNull('deleted_at')->count();if($count>0)$missingRoots[$table]=$count;}}
        $checks['customer_identity_roots']=['ok'=>$missingRoots===[],'missing_counts'=>$missingRoots];
        if($missingRoots!==[])$blockers[]='Customer identity root backfill is incomplete: '.json_encode($missingRoots);
        $pendingDuplicateReviews=0;if($schema->hasTable('crm_duplicate_reviews'))$pendingDuplicateReviews=(int)$this->db->table('crm_duplicate_reviews')->where('status','pending')->where('blocking',true)->count();
        $checks['blocking_duplicate_reviews']=$pendingDuplicateReviews;
        if($pendingDuplicateReviews>0)$warnings[]="{$pendingDuplicateReviews} blocking customer identity review(s) require resolution before affected lead conversions can proceed.";

        $missingCommercialSnapshots=[];$missingAcceptanceEvidence=[];
        foreach(['crm_proposals','crm_estimates'] as $table){
            if(!$schema->hasTable($table)||!$schema->hasColumn($table,'issued_snapshot_hash'))continue;
            $missing=(int)$this->db->table($table)->where(function($q):void{$q->whereNotNull('issued_at')->orWhereIn('status',['sent','accepted','rejected','expired','superseded']);})->whereNull('issued_snapshot_hash')->whereNull('deleted_at')->count();
            if($missing>0)$missingCommercialSnapshots[$table]=$missing;
            $accept=(int)$this->db->table($table)->where('status','accepted')->whereNull('acceptance_hash')->whereNull('deleted_at')->count();
            if($accept>0)$missingAcceptanceEvidence[$table]=$accept;
        }
        $checks['commercial_contract_snapshots']=['ok'=>$missingCommercialSnapshots===[],'missing_counts'=>$missingCommercialSnapshots];
        $checks['commercial_acceptance_evidence']=['ok'=>$missingAcceptanceEvidence===[],'missing_counts'=>$missingAcceptanceEvidence];
        if($missingCommercialSnapshots!==[])$blockers[]='Commercial contract snapshot backfill is incomplete: '.json_encode($missingCommercialSnapshots);
        if($missingAcceptanceEvidence!==[])$blockers[]='Accepted quote evidence backfill is incomplete: '.json_encode($missingAcceptanceEvidence);
        $missingInvoiceSnapshots=0;
        if($schema->hasTable('crm_invoices')&&$schema->hasColumn('crm_invoices','issued_snapshot_hash'))$missingInvoiceSnapshots=(int)$this->db->table('crm_invoices')->whereNull('deleted_at')->whereIn('status',['issued','sent','viewed','paid'])->whereNull('issued_snapshot_hash')->count();
        $checks['invoice_contract_snapshots']=['ok'=>$missingInvoiceSnapshots===0,'missing_count'=>$missingInvoiceSnapshots];
        if($missingInvoiceSnapshots>0)$blockers[]="{$missingInvoiceSnapshots} issued invoice(s) are missing immutable contract snapshots.";
        $openReconciliationIssues=0;
        if($schema->hasTable('crm_receivable_reconciliation_issues'))$openReconciliationIssues=(int)$this->db->table('crm_receivable_reconciliation_issues')->where('status','open')->count();
        $checks['receivable_reconciliation_issues']=$openReconciliationIssues;
        if($openReconciliationIssues>0)$warnings[]="{$openReconciliationIssues} receivable reconciliation mismatch issue(s) require review.";
        $refundDueCount=0;$refundDueByCurrency=[];
        if($schema->hasTable('crm_invoices')&&$schema->hasColumn('crm_invoices','refund_due_minor')){
            $refundRows=$this->db->table('crm_invoices')->whereNull('deleted_at')->where('refund_due_minor','>',0)->selectRaw('currency, COUNT(*) AS invoice_count, COALESCE(SUM(refund_due_minor),0) AS refund_due_minor')->groupBy('currency')->get();
            foreach($refundRows as $refundRow){$currency=strtoupper((string)$refundRow->currency);$refundDueCount+=(int)$refundRow->invoice_count;$refundDueByCurrency[$currency]=(int)$refundRow->refund_due_minor;}
        }
        $checks['refunds_due_to_customers']=['count'=>$refundDueCount,'total_minor_by_currency'=>$refundDueByCurrency];
        if($refundDueCount>0)$warnings[]="{$refundDueCount} invoice(s) have customer refunds due through Titan Pay: ".json_encode($refundDueByCurrency);
        $checks['titan_pay_boundary']=['local_payment_tables_required'=>false,'settlement_reference_table'=>$schema->hasTable('crm_invoice_settlement_references'),'credit_notes'=>$schema->hasTable('crm_credit_notes')];

        $renderBacklog=['requested'=>0,'rendering'=>0,'failed'=>0];
        if($schema->hasTable('crm_sales_document_render_jobs'))foreach(array_keys($renderBacklog) as $state)$renderBacklog[$state]=(int)$this->db->table('crm_sales_document_render_jobs')->where('status',$state)->count();
        $checks['document_render_backlog']=$renderBacklog;
        if($renderBacklog['failed']>0)$warnings[]=$renderBacklog['failed'].' CRM document render job(s) are failed and require retry/remediation.';

        $scannerRequired=(bool)config('crm.portal.files.require_scanner',true);
        $scannerAvailable=!($this->portalScanner instanceof NullCrmPortalFileScanner);
        $checks['portal_scanner_required']=$scannerRequired;
        $checks['portal_scanner_available']=$scannerAvailable;
        if(!$scannerRequired)$blockers[]='Portal malware scanning is not fail-closed.';
        if($scannerRequired&&!$scannerAvailable)$blockers[]='Portal malware scanner is not bound; customer file uploads are intentionally unavailable.';
        $portalSessionSchema=$schema->hasTable('crm_portal_sessions');
        $checks['portal_session_security']=$portalSessionSchema;
        if(!$portalSessionSchema)$blockers[]='CRM portal session-binding schema is missing.';
        $quarantinedFiles=0;if($schema->hasTable('crm_portal_files'))$quarantinedFiles=(int)$this->db->table('crm_portal_files')->whereIn('status',['quarantined','scan_failed','infected'])->count();
        $checks['portal_quarantine_backlog']=$quarantinedFiles;if($quarantinedFiles>0)$warnings[]=$quarantinedFiles.' CRM portal file(s) remain quarantined or failed scanning.';

        $indefiniteApiKeys=0;if($schema->hasTable('crm_api_keys'))$indefiniteApiKeys=(int)$this->db->table('crm_api_keys')->whereNull('revoked_at')->whereNull('expires_at')->count();
        $checks['api_keys_without_expiry']=$indefiniteApiKeys;if((bool)config('crm.api_keys.require_expiry',true)&&$indefiniteApiKeys>0)$blockers[]=$indefiniteApiKeys.' active CRM API key(s) have no expiry.';
        $webhookDeadLetters=0;if($schema->hasTable('crm_webhook_deliveries'))$webhookDeadLetters=(int)$this->db->table('crm_webhook_deliveries')->where('status','dead_letter')->count();
        $checks['webhook_dead_letters']=$webhookDeadLetters;if($webhookDeadLetters>0)$warnings[]=$webhookDeadLetters.' CRM webhook delivery/dead-letter record(s) require review.';
        $stagedImports=0;if($schema->hasTable('crm_import_batches'))$stagedImports=(int)$this->db->table('crm_import_batches')->where('status','ready_to_commit')->count();
        $checks['staged_imports_waiting_approval']=$stagedImports;if($stagedImports>0)$warnings[]=$stagedImports.' staged CRM import(s) are waiting for explicit impact-hash approval.';
        $checks['import_rollback_journal']=$schema->hasTable('crm_import_rollback_journal');
        if(!$checks['import_rollback_journal'])$blockers[]='CRM import rollback journal schema is missing.';

        $strictHostGates=(bool)config('crm.permissions.strict_host_gates',false);
        $checks['strict_host_permission_gates']=$strictHostGates;
        if(!$strictHostGates)$blockers[]='Production CRM requires strict CRM host permission gates; set crm.permissions.strict_host_gates=true only after CRM Gates are registered by the host.';

        $liveFallback=(bool)config('crm.read_store.fallback_to_live',false);
        $checks['ai_read_store_live_fallback']=$liveFallback;
        if($liveFallback)$warnings[]='CQRS read-store live fallback is enabled; AI/dashboard reads may hit OLTP.';

        $projectionFreshness=['stale'=>0,'obsolete'=>0,'max_lag_seconds'=>0];
        if($schema->hasTable('crm_read_projection_state')){
            $rows=$this->db->table('crm_read_projection_state')->get();
            foreach($rows as $row){$lag=0;$obsolete=false;try{$def=$this->projectionRegistry->resolve((string)$row->projection_name);$obsolete=(string)$row->projection_version!==(string)$def['projection_version'];$table=(string)($def['table']??'');if($table!==''&&$schema->hasTable($table)&&$schema->hasColumn($table,'updated_at')){$latest=$this->db->table($table)->where('company_id',(int)$row->company_id)->max('updated_at');$last=$row->last_projected_at??$row->rebuilt_at??null;if($latest!==null){$sourceTs=strtotime((string)$latest);$lastTs=$last?strtotime((string)$last):false;$lag=$lastTs===false?PHP_INT_MAX:max(0,$sourceTs-$lastTs);}}}catch(\Throwable){$obsolete=true;$lag=PHP_INT_MAX;}$projectionFreshness['max_lag_seconds']=max($projectionFreshness['max_lag_seconds'],$lag);$sla=(int)($row->freshness_sla_seconds??300);if($obsolete){$projectionFreshness['obsolete']++;continue;}if((string)($row->status??'stale')!=='ready'||$lag>$sla)$projectionFreshness['stale']++;}
            if($rows->count()===0)$warnings[]='CRM read projections have not been built yet.';
        }
        $checks['projection_freshness']=$projectionFreshness;
        if($projectionFreshness['stale']>0)$warnings[]=$projectionFreshness['stale'].' CRM read projection state(s) are stale or outside freshness SLA.';
        $projectionDeadLetters=0;if($schema->hasTable('crm_read_projection_dead_letters'))$projectionDeadLetters=(int)$this->db->table('crm_read_projection_dead_letters')->whereNull('resolved_at')->count();
        $checks['projection_dead_letters']=$projectionDeadLetters;if($projectionDeadLetters>0)$warnings[]=$projectionDeadLetters.' CRM projection dead-letter event(s) require replay or review.';
        $checks['search_driver']=(string)config('crm.search.driver','sql');

        $checks['external_domains']=[];
        foreach(['titan-field','titan-locker','titan-ledger','titan-pay'] as $owner){
            $provider=$this->ownership->providerClass($owner);
            $checks['external_domains'][$owner]=['installed'=>$provider!==null&&class_exists($provider),'provider'=>$provider];
        }

        $legacyHuman=(bool)config('crm.governance.allow_legacy_local_human_mutations',false);
        $checks['command_bus_strict_mode']=!$legacyHuman;
        if($legacyHuman)$blockers[]='Legacy local human mutation fallback is enabled; production CRM Core must use governed Command Bus execution.';

        $commandBusAvailable=$this->commandBus->available();
        $checks['command_bus_available']=$commandBusAvailable;
        if((bool)config('crm.production.require_command_bus',true)&&!$commandBusAvailable)$blockers[]='Titan Command Bus is not bound; authoritative CRM writes are intentionally unavailable.';

        $signalAvailable=$this->signalDelivery->available();
        $checks['signal_delivery_available']=$signalAvailable;
        if((bool)config('crm.production.require_signal_delivery',true)&&!$signalAvailable)$blockers[]='Titan Signal delivery port is not bound; CRM domain events cannot leave the transactional outbox.';

        $legacyAutonomyTables=[];
        foreach(['crm_autonomy_platform_settings','crm_autonomy_capability_states','crm_autonomy_evidence_events','crm_autonomy_handshakes','crm_autonomy_regressions','crm_autonomy_controls','crm_autonomy_plans','crm_autonomy_plan_steps','crm_autonomy_exceptions','crm_autonomy_run_ledger','crm_autonomy_simulations','crm_learning_events','crm_learning_preferences','crm_learning_patterns','crm_capability_training_stats','crm_operational_recommendations'] as $table){if($schema->hasTable($table))$legacyAutonomyTables[]=$table;}
        $checks['legacy_autonomy_tables']=$legacyAutonomyTables;
        if($legacyAutonomyTables!==[])$warnings[]='Legacy CRM autonomy/learning tables remain for migration evidence; do not drop them until destination-engine import receipts are verified.';

        $autonomyBound=!($this->autonomy instanceof CrmDeferredAutonomyDecisionPort);
        $checks['titan_autonomy_bound']=$autonomyBound;
        if(!$autonomyBound)$warnings[]='Titan Autonomy is not bound; AI/agent CRM execution fails closed to human approval.';

        $communication=(string)config('crm.governance.communication_driver','deferred');
        $checks['communication_driver']=$communication;
        if($communication==='deferred')$warnings[]='Titan Connect is not bound; outbound communication will remain deferred.';

        $status=$blockers!==[]?'blocked':($warnings!==[]?'ready_with_warnings':'ready');
        $severity=$status==='blocked'?'BLOCK':($status==='ready_with_warnings'?'WARN':'PASS');
        return ['status'=>$status,'severity'=>$severity,'blockers'=>$blockers,'warnings'=>$warnings,'checks'=>$checks];
    }
}
