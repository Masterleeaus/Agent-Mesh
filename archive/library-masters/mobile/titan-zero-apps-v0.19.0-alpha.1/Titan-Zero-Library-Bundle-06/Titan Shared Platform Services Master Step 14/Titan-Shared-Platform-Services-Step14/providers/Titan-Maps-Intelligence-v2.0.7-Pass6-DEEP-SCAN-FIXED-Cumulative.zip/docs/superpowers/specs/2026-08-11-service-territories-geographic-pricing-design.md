# Titan Maps Pass 14 — Service Territories & Geographic Pricing Signals

## Goal
Give Titan Zero a graphical, tenant-safe service-area system that can answer whether a job/property is covered, which branch owns it, what travel zone applies, and which neutral geographic pricing signals CRM/quoting may consume.

## Authority boundary
Titan Maps owns geographic definitions, membership evidence, travel-zone evidence, and neutral pricing signals. CRM remains authoritative for jobs/customers/quotes and final pricing. Maps MUST NOT mutate quote/invoice totals or claim a signal was applied.

## Territory definitions
A service territory is company-scoped and may be `include`, `exclude`, or `travel_zone`. Supported match modes are `circle`, `polygon`, `postcode`, `suburb`, `road_distance`, and `drive_time`. Circle/polygon shapes are visually drawn on the existing map. Locality rules are exact normalized text rules; no fake postcode polygon is generated. Travel zones are anchored to a canonical branch location and evaluated using provider-derived route evidence when available.

Each territory has priority, optional branch reference, service/category keys, active dates, and optional pricing-hint configuration. Higher priority wins within the same effect, but any matching exclusion blocks normal coverage.

## Evaluation
Evaluation accepts target coordinates plus optional suburb/postcode/service key. Geometry/locality matches are deterministic. Travel-zone rules call durable routing from the branch anchor to the target and preserve route provenance (`provider_route`, stale snapshot, or estimate). Straight-line fallback may support distance-only evidence, but drive-time membership remains unknown if ETA is unavailable.

## Pricing signals
Maps emits immutable geographic signal records such as `inside_primary_area`, `outside_service_area`, `excluded_area`, `remote_distance_band`, `drive_time_band`, `branch_affinity`, and configured `surcharge_hint`. A surcharge hint carries `fixed` or `percent`, value, currency where relevant, and source territory. It is advisory only and must include `authoritative=false` and `application_status=not_applied`.

## UI
Territories & Coverage gains Service Areas, Travel Zones, and Geographic Pricing. Service Areas supports draw circle/polygon plus locality rules. Travel Zones supports branch anchor + max road distance or drive time. Geographic Pricing evaluates a target and shows coverage, branch, travel evidence, and neutral signal cards.

## Safety
All persistence is company-scoped. Branch references are validated against canonical `MapLocation` records. Unknown/foreign references fail closed. No route/provider error is converted into a fake ETA. No pricing signal writes to CRM or billing.
