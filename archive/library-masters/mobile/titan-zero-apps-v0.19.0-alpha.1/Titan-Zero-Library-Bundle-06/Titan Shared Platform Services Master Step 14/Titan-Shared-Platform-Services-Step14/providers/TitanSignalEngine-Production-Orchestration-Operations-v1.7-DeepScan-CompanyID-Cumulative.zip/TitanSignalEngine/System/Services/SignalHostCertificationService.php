<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\ExtensionHealth;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalAnomalyContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalArchiveCatalogContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalArchiveStoreContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalCorrelationContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryDispatcherContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryLeaseManagerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliverySchedulerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterAuthorityContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEventStoreContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalHistoryQueryContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalLifecycleContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalManagerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalPulseContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalQueryContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalRegistryAuthorityContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalSubscriptionRegistryContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalCertificationReport;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Throwable;

final class SignalHostCertificationService
{
    private const REQUIRED_ROUTES = [
        'dashboard.admin.titan.signal.engine.index',
        'dashboard.admin.titan.signal.engine.overview',
        'dashboard.admin.titan.signal.engine.pulse-health',
        'dashboard.admin.titan.signal.engine.events-traces',
        'dashboard.admin.titan.signal.engine.anomalies',
        'dashboard.admin.titan.signal.engine.deliveries-dlq',
        'dashboard.admin.titan.signal.engine.lifecycle-archives',
        'dashboard.admin.titan.signal.engine.registries',
        'dashboard.admin.titan.signal.engine.diagnostics',
    ];

    private const REQUIRED_MENU_ROWS = [
        'titan_signal_engine_admin' => [
            'route' => 'dashboard.admin.titan.signal.engine.index',
            'admin' => true,
            'extension' => '1',
            'parent_key' => null,
        ],
        'titan_signal_engine_overview' => ['route' => 'dashboard.admin.titan.signal.engine.overview', 'admin' => true, 'extension' => '1', 'parent_key' => 'titan_signal_engine_admin'],
        'titan_signal_engine_pulse_health' => ['route' => 'dashboard.admin.titan.signal.engine.pulse-health', 'admin' => true, 'extension' => '1', 'parent_key' => 'titan_signal_engine_admin'],
        'titan_signal_engine_events_traces' => ['route' => 'dashboard.admin.titan.signal.engine.events-traces', 'admin' => true, 'extension' => '1', 'parent_key' => 'titan_signal_engine_admin'],
        'titan_signal_engine_anomalies' => ['route' => 'dashboard.admin.titan.signal.engine.anomalies', 'admin' => true, 'extension' => '1', 'parent_key' => 'titan_signal_engine_admin'],
        'titan_signal_engine_deliveries_dlq' => ['route' => 'dashboard.admin.titan.signal.engine.deliveries-dlq', 'admin' => true, 'extension' => '1', 'parent_key' => 'titan_signal_engine_admin'],
        'titan_signal_engine_lifecycle_archives' => ['route' => 'dashboard.admin.titan.signal.engine.lifecycle-archives', 'admin' => true, 'extension' => '1', 'parent_key' => 'titan_signal_engine_admin'],
        'titan_signal_engine_registries' => ['route' => 'dashboard.admin.titan.signal.engine.registries', 'admin' => true, 'extension' => '1', 'parent_key' => 'titan_signal_engine_admin'],
        'titan_signal_engine_diagnostics' => ['route' => 'dashboard.admin.titan.signal.engine.diagnostics', 'admin' => true, 'extension' => '1', 'parent_key' => 'titan_signal_engine_admin'],
    ];

    private const REQUIRED_SCHEDULE_COMMANDS = [
        'titan:signal-deliveries:recover',
        'titan:signal-pulse:project',
        'titan:signal-health:refresh',
        'titan:signal-traces:evaluate',
        'titan:signal-anomalies:scan',
        'titan:signal-housekeeping',
    ];

    private const CRITICAL_COLUMNS = [
        'titan_signal_events' => ['event_id', 'event_type', 'tenant_company_id', 'trace_id', 'correlation_id', 'causation_id', 'root_causation_id', 'emitter_id', 'checksum', 'checksum_alg'],
        'titan_signal_deliveries' => ['delivery_id', 'event_id', 'subscriber_key', 'status', 'lease_token', 'lease_owner', 'lease_expires_at', 'claim_version', 'redrive_count'],
        'titan_signal_archive_catalog' => ['event_id', 'batch_id', 'scope', 'tenant_key', 'trace_id', 'correlation_id', 'causation_id', 'root_causation_id', 'archive_locator', 'archive_checksum'],
        'titan_signal_prune_previews' => ['preview_id', 'candidate_hash', 'token_hash', 'status', 'execution_token', 'execution_expires_at'],
        'titan_signal_pulse_projection_freshness' => ['scope', 'tenant_key', 'dimension', 'dimension_value', 'last_ingested_at', 'last_projected_at'],
        'titan_signal_pulse_command_receipts' => ['command_event_id', 'receipt_event_id', 'trace_id', 'pairing_method', 'latency_ms'],
        'titan_signal_anomalies' => ['anomaly_id', 'status', 'decision_version', 'last_decision_event_id'],
    ];

    private const CRITICAL_INDEXES = [
        'titan_signal_events' => ['tse_event_id_uq', 'tse_dedup_uq', 'tse_tenant_trace_idx', 'tse_tenant_corr_idx'],
        'titan_signal_deliveries' => ['tsd_status_lease_expiry_idx', 'tsd_delivery_claim_idx'],
        'titan_signal_archive_catalog' => ['tsac_event_uq', 'tsac_trace_idx', 'tsac_corr_idx', 'tsac_cause_idx'],
        'titan_signal_prune_previews' => ['tspp_preview_uq', 'tspp_scope_status_idx'],
        'titan_signal_pulse_command_receipts' => ['tspcrp_command_uq', 'tspcrp_receipt_uq', 'tspcrp_trace_idx'],
    ];

    private const REQUIRED_BINDINGS = [
        SignalEmitterAuthorityContract::class,
        SignalRegistryAuthorityContract::class,
        SignalEventStoreContract::class,
        SignalEmitterContract::class,
        SignalQueryContract::class,
        SignalHistoryQueryContract::class,
        SignalCorrelationContract::class,
        SignalSubscriptionRegistryContract::class,
        SignalDeliverySchedulerContract::class,
        SignalDeliveryDispatcherContract::class,
        SignalDeliveryLeaseManagerContract::class,
        SignalPulseContract::class,
        SignalAnomalyContract::class,
        SignalLifecycleContract::class,
        SignalArchiveStoreContract::class,
        SignalArchiveCatalogContract::class,
        ExtensionHealth::class,
        SignalManagerContract::class,
    ];

    public function __construct(
        private readonly Application $app,
        private readonly ExtensionHealth $health,
    ) {}

    public function certify(bool $probeWrites = false, bool $strictProduction = false): SignalCertificationReport
    {
        $report = new SignalCertificationReport();
        $this->checkRuntime($report);
        $this->checkPackageContract($report);
        $this->checkDatabase($report, $strictProduction);
        $this->checkSchema($report);
        $this->checkBindings($report);
        $this->checkRoutes($report);
        $this->checkNavigation($report);
        $this->checkSchedules($report);
        $this->checkQueue($report, $strictProduction);
        $this->checkArchiveStorage($report, $probeWrites);
        $this->checkHealth($report);
        return $report;
    }

    private function checkRuntime(SignalCertificationReport $report): void
    {
        $report->add('runtime.php', version_compare(PHP_VERSION, '8.2.0', '>=') ? 'PASS' : 'FAIL', 'PHP version compatibility.', ['version' => PHP_VERSION, 'required' => '>=8.2']);
        $laravel = (string) $this->app->version();
        $major = (int) explode('.', $laravel)[0];
        $report->add('runtime.laravel', $major === 10 ? 'PASS' : 'FAIL', 'Laravel major version compatibility.', ['version' => $laravel, 'required' => '^10.0']);
        $appKey = trim((string) config('app.key', ''));
        $report->add('runtime.app_key', $appKey !== '' ? 'PASS' : 'FAIL', 'Laravel app key required for trusted emitter and registry attestation.');
    }

    private function checkPackageContract(SignalCertificationReport $report): void
    {
        $root = dirname(__DIR__, 2);
        try {
            $installer = json_decode((string) file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);
            $manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
            $ok = ($installer['schema'] ?? null) === 'titan-extension-v1'
                && ($installer['slug'] ?? null) === 'titan-signal-engine'
                && ($installer['folder'] ?? null) === 'TitanSignalEngine'
                && ($installer['provider'] ?? null) === 'App\\Extensions\\TitanSignalEngine\\System\\TitanSignalEngineServiceProvider'
                && ($installer['migrations'] ?? null) === true
                && ($installer['uninstall']['preserve_data'] ?? null) === true
                && ($manifest['runtime_profile'] ?? null) === 'titan-governed-engine';
            $report->add('package.manifests', $ok ? 'PASS' : 'FAIL', 'Installer 1.7.8 and Blueprint v4 package contracts.', ['version' => $manifest['version'] ?? null]);
        } catch (Throwable $e) {
            $report->add('package.manifests', 'FAIL', 'Unable to parse extension manifests.', ['error_class' => $e::class]);
        }
    }

    private function checkDatabase(SignalCertificationReport $report, bool $strictProduction): void
    {
        try {
            $connection = DB::connection();
            $connection->getPdo();
            $driver = $connection->getDriverName();
            $report->add('database.connection', 'PASS', 'Database connection is available.', ['driver' => $driver]);
            $report->add('database.driver', $driver === 'mysql' ? 'PASS' : ($strictProduction ? 'FAIL' : 'WARN'), 'Production certification target is MySQL.', ['driver' => $driver, 'required' => 'mysql']);
            if ($driver === 'mysql') {
                $versionRow = $connection->selectOne('SELECT VERSION() AS version');
                $modeRow = $connection->selectOne('SELECT @@SESSION.sql_mode AS sql_mode');
                $version = (string) ($versionRow->version ?? 'unknown');
                $sqlMode = strtoupper((string) ($modeRow->sql_mode ?? ''));
                $strict = str_contains($sqlMode, 'STRICT_TRANS_TABLES') || str_contains($sqlMode, 'STRICT_ALL_TABLES');
                $report->add('database.mysql_version', 'PASS', 'MySQL server version discovered.', ['version' => $version]);
                $report->add('database.strict_mode', $strict ? 'PASS' : ($strictProduction ? 'FAIL' : 'WARN'), 'MySQL strict mode should be enabled.', ['sql_mode' => $sqlMode]);
            }
        } catch (Throwable $e) {
            $report->add('database.connection', 'FAIL', 'Database connection failed.', ['error_class' => $e::class]);
        }
    }

    private function checkSchema(SignalCertificationReport $report): void
    {
        $root = dirname(__DIR__, 2);
        try {
            $manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
            $owned = array_values((array) ($manifest['database']['owned_tables'] ?? []));
            $missing = array_values(array_filter($owned, static fn (string $table): bool => ! Schema::hasTable($table)));
            $report->add('schema.owned_tables', $missing === [] ? 'PASS' : 'FAIL', 'Owned Signal tables are installed.', ['expected' => count($owned), 'missing' => $missing]);

            $missingColumns = [];
            foreach (self::CRITICAL_COLUMNS as $table => $columns) {
                if (! Schema::hasTable($table)) continue;
                foreach ($columns as $column) if (! Schema::hasColumn($table, $column)) $missingColumns[] = $table . '.' . $column;
            }
            $report->add('schema.critical_columns', $missingColumns === [] ? 'PASS' : 'FAIL', 'Critical post-hardening columns are present.', ['missing' => $missingColumns]);

            $missingIndexes = [];
            foreach (self::CRITICAL_INDEXES as $table => $indexes) {
                if (! Schema::hasTable($table)) continue;
                foreach ($indexes as $index) {
                    try { if (! Schema::hasIndex($table, $index)) $missingIndexes[] = $table . '.' . $index; }
                    catch (Throwable) { $missingIndexes[] = $table . '.' . $index . ':unverifiable'; }
                }
            }
            $report->add('schema.critical_indexes', $missingIndexes === [] ? 'PASS' : 'FAIL', 'Critical query/concurrency indexes are present.', ['missing' => $missingIndexes]);

            if (Schema::hasTable('migrations')) {
                $expectedMigrations = array_map(static fn (string $path): string => pathinfo($path, PATHINFO_FILENAME), glob($root . '/database/migrations/*.php') ?: []);
                $applied = DB::table('migrations')->whereIn('migration', $expectedMigrations)->pluck('migration')->all();
                $missingMigrations = array_values(array_diff($expectedMigrations, $applied));
                $report->add('schema.migrations_applied', $missingMigrations === [] ? 'PASS' : 'FAIL', 'All packaged Signal migrations are recorded as applied.', ['expected' => count($expectedMigrations), 'missing' => $missingMigrations]);
            } else {
                $report->add('schema.migrations_applied', 'FAIL', 'Laravel migrations table is missing.');
            }
        } catch (Throwable $e) {
            $report->add('schema.inspect', 'FAIL', 'Schema inspection failed.', ['error_class' => $e::class]);
        }
    }

    private function checkBindings(SignalCertificationReport $report): void
    {
        $missing = [];
        $failed = [];
        foreach (self::REQUIRED_BINDINGS as $binding) {
            if (! $this->app->bound($binding)) { $missing[] = $binding; continue; }
            try { $this->app->make($binding); } catch (Throwable $e) { $failed[$binding] = $e::class; }
        }
        $report->add('runtime.bindings', $missing === [] && $failed === [] ? 'PASS' : 'FAIL', 'Required Signal service bindings resolve.', ['missing' => $missing, 'failed' => $failed]);
    }

    private function checkRoutes(SignalCertificationReport $report): void
    {
        $missing = array_values(array_filter(self::REQUIRED_ROUTES, static fn (string $route): bool => ! Route::has($route)));
        $report->add('runtime.routes', $missing === [] ? 'PASS' : 'FAIL', 'Signal Super Admin routes are registered.', ['missing' => $missing]);
    }

    private function checkNavigation(SignalCertificationReport $report): void
    {
        try {
            if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key')) {
                $report->add('runtime.navigation', 'FAIL', 'MagicAI/Titan menus table is unavailable.');
                return;
            }

            $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
            $missing = [];
            $invalid = [];
            foreach (self::REQUIRED_MENU_ROWS as $key => $expected) {
                $row = DB::table('menus')->where('key', $key)->orderBy('id')->first();
                $rowCount = (int) DB::table('menus')->where('key', $key)->count();
                if ($row === null) {
                    $missing[] = $key;
                    continue;
                }
                if ($rowCount > 1) {
                    $invalid[$key][] = 'duplicate_rows';
                }

                if ((string) ($row->route ?? '') !== (string) $expected['route']) {
                    $invalid[$key][] = 'route';
                }
                if (isset($columns['is_active']) && (int) ($row->is_active ?? 0) !== 1) {
                    $invalid[$key][] = 'inactive';
                }
                if (isset($columns['extension']) && (string) ($row->extension ?? '') !== (string) ($expected['extension'] ?? '')) {
                    $invalid[$key][] = 'extension_marker';
                }
                if (isset($columns['parent_id'])) {
                    $parentKey = $expected['parent_key'] ?? null;
                    if ($parentKey === null) {
                        if (($row->parent_id ?? null) !== null) $invalid[$key][] = 'unexpected_parent';
                    } else {
                        $expectedParentId = DB::table('menus')->where('key', $parentKey)->orderBy('id')->value('id');
                        if ($expectedParentId === null || (int) ($row->parent_id ?? 0) !== (int) $expectedParentId) {
                            $invalid[$key][] = 'parent_relationship';
                        }
                    }
                }
                if (isset($columns['is_admin'])) {
                    $expectedAdmin = ($expected['admin'] ?? false) ? 1 : 0;
                    if ((int) ($row->is_admin ?? -1) !== $expectedAdmin) {
                        $invalid[$key][] = 'admin_discriminator';
                    }
                }
                if (($expected['admin'] ?? false) && isset($columns['order']) && (int) ($row->order ?? 0) < 900) {
                    $invalid[$key][] = 'admin_order_band';
                }
            }

            $report->add(
                'runtime.navigation',
                $missing === [] && $invalid === [] ? 'PASS' : 'FAIL',
                'Signal Super Admin parent and eight child menu rows are registered and host-compatible.',
                ['missing' => $missing, 'invalid' => $invalid],
            );
        } catch (Throwable $e) {
            $report->add('runtime.navigation', 'FAIL', 'Unable to inspect Signal host navigation.', ['error_class' => $e::class]);
        }
    }

    private function checkSchedules(SignalCertificationReport $report): void
    {
        try {
            /** @var Schedule $schedule */
            $schedule = $this->app->make(Schedule::class);
            $commands = [];
            foreach ($schedule->events() as $event) {
                $command = property_exists($event, 'command') ? (string) $event->command : '';
                if ($command !== '') $commands[] = $command;
            }
            $missing = [];
            foreach (self::REQUIRED_SCHEDULE_COMMANDS as $required) {
                if (! array_filter($commands, static fn (string $command): bool => str_contains($command, $required))) $missing[] = $required;
            }
            $report->add('runtime.schedules', $missing === [] ? 'PASS' : 'FAIL', 'Required scheduled Signal jobs are registered.', ['missing' => $missing]);
        } catch (Throwable $e) {
            $report->add('runtime.schedules', 'FAIL', 'Unable to inspect scheduler.', ['error_class' => $e::class]);
        }
    }

    private function checkQueue(SignalCertificationReport $report, bool $strictProduction): void
    {
        $driver = (string) config('queue.default', '');
        $bad = $driver === '' || $driver === 'sync';
        $report->add('runtime.queue_driver', $bad ? ($strictProduction ? 'FAIL' : 'WARN') : 'PASS', 'Production Signal delivery requires a durable asynchronous queue driver.', ['driver' => $driver]);
        $queue = trim((string) config('titan-signal-engine.queue', ''));
        $report->add('runtime.signal_queue', $queue !== '' ? 'PASS' : 'FAIL', 'Signal delivery queue name is configured.', ['queue' => $queue]);
    }

    private function checkArchiveStorage(SignalCertificationReport $report, bool $probeWrites): void
    {
        $diskName = (string) config('titan-signal-engine.archive_disk', 'local');
        try {
            $disk = Storage::disk($diskName);
            if (! $probeWrites) {
                $report->add('runtime.archive_storage', 'SKIP', 'Archive disk resolved; write/delete probe was not requested.', ['disk' => $diskName]);
                return;
            }
            $path = trim((string) config('titan-signal-engine.archive_path', 'titan-signal-engine/archive'), '/') . '/.certification-' . bin2hex(random_bytes(8)) . '.probe';
            $written = $disk->put($path, 'titan-signal-certification');
            $exists = $written && $disk->exists($path);
            if ($exists) $disk->delete($path);
            $report->add('runtime.archive_storage', $exists ? 'PASS' : 'FAIL', 'Archive disk write/read/delete probe.', ['disk' => $diskName]);
        } catch (Throwable $e) {
            $report->add('runtime.archive_storage', 'FAIL', 'Archive storage probe failed.', ['disk' => $diskName, 'error_class' => $e::class]);
        }
    }

    private function checkHealth(SignalCertificationReport $report): void
    {
        try {
            $snapshot = $this->health->snapshot();
            $status = strtoupper((string) ($snapshot['status'] ?? 'UNKNOWN'));
            $result = in_array($status, ['HEALTHY'], true) ? 'PASS' : (in_array($status, ['DEGRADED'], true) ? 'WARN' : 'FAIL');
            $report->add('runtime.health', $result, 'Signal governed health snapshot.', ['status' => $status, 'checks' => $snapshot['checks'] ?? []]);
        } catch (Throwable $e) {
            $report->add('runtime.health', 'FAIL', 'Signal health snapshot failed.', ['error_class' => $e::class]);
        }
    }
}
