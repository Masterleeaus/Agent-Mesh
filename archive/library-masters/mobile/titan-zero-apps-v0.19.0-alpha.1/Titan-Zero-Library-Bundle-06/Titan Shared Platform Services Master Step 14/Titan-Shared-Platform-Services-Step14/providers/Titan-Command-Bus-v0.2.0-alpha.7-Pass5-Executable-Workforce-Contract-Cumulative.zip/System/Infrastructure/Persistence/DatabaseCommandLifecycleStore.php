<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Infrastructure\Persistence;

use App\Extensions\TitanCommandBus\System\Contracts\CommandLifecycleStoreContract;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use App\Extensions\TitanCommandBus\System\Services\CommandLifecycleState;
use Illuminate\Database\DatabaseManager;
use Illuminate\Support\Facades\Schema;
use RuntimeException;

final class DatabaseCommandLifecycleStore implements CommandLifecycleStoreContract
{
    public function __construct(private readonly DatabaseManager $db) {}

    public function available(): bool
    {
        return Schema::hasTable('titan_commands') && Schema::hasTable('titan_command_attempts');
    }

    public function begin(CommandContext $context, CommandRequest $request, string $operationId, string $requestHash): void
    {
        if (! $this->available()) {
            throw new RuntimeException('Command lifecycle persistence is unavailable.');
        }

        $this->db->transaction(function () use ($context, $request, $operationId, $requestHash): void {
            $this->db->table('titan_commands')->insert([
                'company_id' => $context->companyId,
                'tenant_company_id' => $context->companyId,
                'command_id' => $operationId,
                'idempotency_key' => $request->idempotencyKey,
                'request_hash' => $requestHash,
                'capability' => $request->capability,
                'trace_id' => $request->traceId,
                'correlation_id' => $request->correlationId,
                'causation_id' => $request->causationId,
                'root_causation_id' => $request->rootCausationId,
                'actor_type' => $context->actorType,
                'actor_id' => $context->actorId === null ? null : (string) $context->actorId,
                'service_id' => $context->serviceId,
                'prepared_offline' => $request->preparedOffline,
                'expected_entity_version' => is_scalar($request->expectedEntityVersion) ? (string) $request->expectedEntityVersion : null,
                'status' => CommandLifecycleState::RECEIVED,
                'last_sequence' => 1,
                'received_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $this->insertAttempt($context, $request, $operationId, 1, CommandLifecycleState::RECEIVED, null, []);
        });
    }

    public function transition(CommandContext $context, CommandRequest $request, string $operationId, string $state, ?string $reasonCode = null, array $evidence = []): void
    {
        if (! $this->available()) {
            throw new RuntimeException('Command lifecycle persistence is unavailable.');
        }

        $this->db->transaction(function () use ($context, $request, $operationId, $state, $reasonCode, $evidence): void {
            $row = $this->db->table('titan_commands')
                ->where('company_id', $context->companyId)
                ->where('command_id', $operationId)
                ->lockForUpdate()
                ->first();
            if ($row === null) {
                throw new RuntimeException('Command lifecycle row is missing.');
            }

            $sequence = ((int) $row->last_sequence) + 1;
            $updates = [
                'status' => $state,
                'last_sequence' => $sequence,
                'updated_at' => now(),
            ];
            if ($state === CommandLifecycleState::COMPLETED) {
                $updates['completed_at'] = now();
            } elseif ($state === CommandLifecycleState::REFUSED) {
                $updates['refused_at'] = now();
            } elseif ($state === CommandLifecycleState::FAILED) {
                $updates['failed_at'] = now();
            }

            $this->db->table('titan_commands')
                ->where('company_id', $context->companyId)
                ->where('command_id', $operationId)
                ->update($updates);

            $this->insertAttempt($context, $request, $operationId, $sequence, $state, $reasonCode, $evidence);
        });
    }

    public function observe(CommandContext $context, CommandRequest $request, string $operationId, string $state, ?string $reasonCode = null, array $evidence = []): void
    {
        if (! $this->available()) {
            return;
        }

        $this->db->transaction(function () use ($context, $request, $operationId, $state, $reasonCode, $evidence): void {
            $row = $this->db->table('titan_commands')
                ->where('company_id', $context->companyId)
                ->where('command_id', $operationId)
                ->lockForUpdate()
                ->first();
            if ($row === null) {
                return;
            }

            $sequence = ((int) $row->last_sequence) + 1;
            $this->db->table('titan_commands')
                ->where('company_id', $context->companyId)
                ->where('command_id', $operationId)
                ->update(['last_sequence' => $sequence, 'updated_at' => now()]);
            $this->insertAttempt($context, $request, $operationId, $sequence, $state, $reasonCode, $evidence);
        });
    }

    public function health(): array
    {
        return [
            'commands_table' => Schema::hasTable('titan_commands'),
            'attempts_table' => Schema::hasTable('titan_command_attempts'),
        ];
    }

    private function insertAttempt(CommandContext $context, CommandRequest $request, string $operationId, int $sequence, string $state, ?string $reasonCode, array $evidence): void
    {
        $this->db->table('titan_command_attempts')->insert([
            'company_id' => $context->companyId,
                'tenant_company_id' => $context->companyId,
            'command_id' => $operationId,
            'sequence' => $sequence,
            'state' => $state,
            'reason_code' => $reasonCode,
            'trace_id' => $request->traceId,
            'correlation_id' => $request->correlationId,
            'causation_id' => $request->causationId,
            'root_causation_id' => $request->rootCausationId,
            'evidence' => json_encode($this->safeEvidence($evidence), JSON_THROW_ON_ERROR),
            'occurred_at' => now(),
            'created_at' => now(),
        ]);
    }

    private function safeEvidence(array $evidence): array
    {
        $allowed = ['risk_reference', 'assurance_reference', 'autonomy_reference', 'governance_reference', 'approval_reference', 'adapter', 'domain_receipt_reference'];
        return array_intersect_key($evidence, array_flip($allowed));
    }
}
