# CRM 1.3.0-alpha.11 — Interaction-First Implementation Report

## Goal

Make Titan Interaction Engine the default structured interaction runtime across CRM while retaining CRM as the authoritative record/service layer and TitanAI/MagicAI as conversational guidance and orchestration.

## Runtime boundary

```text
Titan Zero / TitanAI conversation
        ↓
CRM conversational interaction resolver
        ↓
Titan Interaction Engine session / wizard / authority
        ↓
Governed CRM capability
        ↓
CRM service / repository
        ↓
crm_* authoritative data
```

Financial calculations remain:

```text
AI guidance → Interaction Engine → deterministic CRM Financial Assistant / sales calculator → governed CRM write
```

## Shared interaction UI

New shared components:

- `resources/views/components/interaction-page-shell.blade.php`
- `resources/views/components/interaction-ai-bar.blade.php`
- `resources/views/components/interaction-primary-action.blade.php`
- `resources/views/components/interaction-launcher.blade.php`
- `resources/views/interaction/session.blade.php`

The shell provides a consistent title, context, AI command bar, primary New action and secondary journey actions.

## Interaction Engine integration

Key integration classes:

- `CrmInteractionJourneyRegistry`
- `CrmInteractionSurfaceService`
- `CrmInteractionIntegrationRegistrar`
- `CrmInteractionCapabilityHandler`
- `CrmInteractionPresentationAdapter`
- `CrmConversationalInteractionService`
- `CrmInteractionAuthorityPolicy`
- `CrmInteractionAIToolProvider`

The CRM provider registers its capability and journey contributions only when Interaction Engine is available. Mature direct forms remain available as Advanced fallback where configured.

## Authority

AI can resolve intent, start sessions and answer steps. It does not contain `ApprovalSigner` and cannot self-approve approval-required workflows.

The human Interaction workspace signs approval and dispatches through Interaction Engine `CommandBus` only after an explicit approval action.

Autonomous operation is configuration-bounded and cannot override the always-approval capability set.

## Contract correction

CRM-owned Interaction Engine definitions replace mismatched donor payloads for Customer, Job, Quote and Invoice.

This prevents:

- missing required work-order `title`
- customer/account identity ambiguity
- internal-ID/public-ID drift
- free-form quote/invoice totals bypassing CRM deterministic line calculations

## Context propagation

Page context is carried into journey starts using declared wizard fields only. Tenant, actor and other trusted identity fields are stripped from user-supplied prefill and are supplied from CRM's trusted tenant context instead.

## Regression gates

Alpha.11 adds dedicated gates for:

- Interaction Engine compatibility contract
- UI shell
- conversational AI boundary
- New-action coverage
- domain capability coverage
- renderer/Advanced fallback
- authority modes
- primary journey contracts
- business journeys
- context prefill
- menu-linked page consistency
- detail-page consistency
- auxiliary journeys
- internal shell coverage

All inherited alpha.2-alpha.10 provider, MySQL, Locker, Mobile and Financial AI gates remain part of the master verification chain.
