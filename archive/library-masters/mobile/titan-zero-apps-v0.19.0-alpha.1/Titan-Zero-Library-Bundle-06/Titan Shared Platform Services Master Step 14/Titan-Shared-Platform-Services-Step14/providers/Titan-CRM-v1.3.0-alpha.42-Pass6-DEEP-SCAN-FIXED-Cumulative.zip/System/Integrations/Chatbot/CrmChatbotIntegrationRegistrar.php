<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Integrations\Chatbot;
use App\Extensions\Crm\System\Integrations\Chatbot\Generators\{CrmOpenAIGenerator,CrmAnthropicGenerator,CrmGeminiGenerator};
use Illuminate\Contracts\Foundation\Application;
final class CrmChatbotIntegrationRegistrar
{
    public function __construct(private Application $app,private CrmChatbotCompatibility $compatibility) {}
    public function register(): void
    {
        if(!$this->compatibility->supported())return;
        $this->app->bind(\App\Extensions\Chatbot\System\Generators\OpenAIGenerator::class,CrmOpenAIGenerator::class);
        $this->app->bind(\App\Extensions\Chatbot\System\Generators\AnthropicGenerator::class,CrmAnthropicGenerator::class);
        $this->app->bind(\App\Extensions\Chatbot\System\Generators\GeminiGenerator::class,CrmGeminiGenerator::class);
        \App\Extensions\Chatbot\System\Models\ChatbotCustomer::observe(CrmChatbotCustomerObserver::class);
        \App\Extensions\Chatbot\System\Models\ChatbotConversation::observe(CrmChatbotConversationObserver::class);
    }
}
