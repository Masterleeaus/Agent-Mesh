<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\DTO;

final readonly class ActorContext
{
    /** @var array<int,string> */
    public array $permissions;
    public AuthorityContext $authority;

    /** @param array<int,string> $permissions */
    public function __construct(
        public string $actorId,
        public string $actorType,
        public string $tenantCompanyId,
        array $permissions = [],
        public int $authorityLevel = 0,
        public bool $trusted = false,
        string $authoritySource = 'unverified',
    ) {
        $this->permissions = array_values(array_unique($permissions));
        $this->authority = new AuthorityContext(
            level: $authorityLevel,
            permissions: $this->permissions,
            source: $authoritySource,
        );
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'actor_id' => $this->actorId,
            'actor_type' => $this->actorType,
            'tenant_company_id' => $this->tenantCompanyId,
            'permissions' => $this->permissions,
            'authority_level' => $this->authorityLevel,
            'trusted' => $this->trusted,
            'authority' => $this->authority->toArray(),
        ];
    }
}
