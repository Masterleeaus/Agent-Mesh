<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

final class KnowledgeJurisdiction extends Model
{
    protected $table = 'titan_knowledge_jurisdictions';
    protected $guarded = ['id'];
    protected $casts = [
        'aliases' => 'array',
        'metadata' => 'array',
        'effective_from' => 'immutable_datetime',
        'effective_until' => 'immutable_datetime',
    ];

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id');
    }

    public function applicability(): HasMany
    {
        return $this->hasMany(KnowledgeApplicability::class, 'jurisdiction_id');
    }
}
