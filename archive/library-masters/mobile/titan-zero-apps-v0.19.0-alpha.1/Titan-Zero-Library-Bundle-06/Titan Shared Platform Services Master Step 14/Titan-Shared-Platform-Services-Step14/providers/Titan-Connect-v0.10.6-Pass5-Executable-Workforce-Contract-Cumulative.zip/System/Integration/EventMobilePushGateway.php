<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Integration;

use App\Extensions\TitanConnect\System\Contracts\MobilePushGateway;
use Illuminate\Support\Facades\Event;

final class EventMobilePushGateway implements MobilePushGateway
{
    public function send(int $companyId, array $recipientUserIds, array $notification): array
    {
        if (! $this->configured()) {
            return ['status' => 'not-configured', 'company_id' => $companyId, 'recipients' => count($recipientUserIds)];
        }

        $responses = event('titan-connect.mobile.push', [$companyId, $recipientUserIds, $notification]) ?: [];
        foreach ($responses as $response) {
            if (is_array($response)) {
                return $response;
            }
        }

        return ['status' => 'queued', 'company_id' => $companyId, 'recipients' => count($recipientUserIds)];
    }

    public function configured(): bool
    {
        return Event::hasListeners('titan-connect.mobile.push');
    }
}
