<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface OperationsReviewStoreContract
{
    public function append(array $review): string;
    /** @return list<array<string,mixed>> */
    public function forReceipt(int $tenantCompanyId, string $receiptPublicId, int $limit = 100): array;
}
