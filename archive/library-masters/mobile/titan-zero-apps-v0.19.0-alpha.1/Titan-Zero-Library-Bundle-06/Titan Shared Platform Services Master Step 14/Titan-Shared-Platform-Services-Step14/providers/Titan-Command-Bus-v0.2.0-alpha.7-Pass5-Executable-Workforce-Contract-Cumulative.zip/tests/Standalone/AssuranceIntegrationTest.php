<?php
declare(strict_types=1);

$GLOBALS['tcb_test_config'] = [
    'titan-command-bus.enabled' => true,
    'titan-command-bus.require_lifecycle' => false,
    'titan-command-bus.kill_switch' => false,
    'titan-command-bus.max_payload_bytes' => 65536,
    'titan-command-bus.allow_offline_revalidation' => true,
    'titan-command-bus.require_signal' => true,
    'titan-command-bus.require_risk' => true,
    'titan-command-bus.require_assurance' => true,
    'titan-command-bus.require_autonomy' => false,
];
if (!function_exists('config')) {
    function config(string $key, mixed $default = null): mixed { return $GLOBALS['tcb_test_config'][$key] ?? $default; }
}

$root=dirname(__DIR__,2);
foreach ([
    'System/DTO/CommandContext.php','System/DTO/CommandRequest.php','System/DTO/RiskDecision.php','System/DTO/AssuranceDecision.php','System/DTO/GovernanceDecision.php','System/DTO/CommandExecutionResult.php','System/DTO/CommandReceipt.php',
    'System/Contracts/CommandAdapterContract.php','System/Contracts/CommandAdapterRegistryContract.php','System/Contracts/CommandRiskGateContract.php','System/Contracts/CommandAssuranceGateContract.php','System/Contracts/CommandGovernanceGateContract.php','System/Contracts/CommandReceiptStoreContract.php','System/Contracts/CommandSignalEmitterContract.php','System/Contracts/CommandBusContract.php',
    'System/Contracts/CommandLifecycleStoreContract.php','System/Services/CommandLifecycleState.php','System/Services/CommandBus.php',
] as $rel) require_once $root.'/'.$rel;

use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterRegistryContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAssuranceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandRiskGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandGovernanceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandReceiptStoreContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandSignalEmitterContract;
use App\Extensions\TitanCommandBus\System\DTO\AssuranceDecision;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandExecutionResult;
use App\Extensions\TitanCommandBus\System\DTO\CommandReceipt;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use App\Extensions\TitanCommandBus\System\DTO\GovernanceDecision;
use App\Extensions\TitanCommandBus\System\DTO\RiskDecision;
use App\Extensions\TitanCommandBus\System\Services\CommandBus;

final class AssuranceTestAdapter implements CommandAdapterContract {
    public int $calls=0;
    public function capability(): string { return 'crm.invoice.create'; }
    public function execute(CommandContext $context, CommandRequest $request, string $operationId): CommandExecutionResult {
        $this->calls++;
        return new CommandExecutionResult('crm:invoice:101', true, 101, 'invoice', 7);
    }
}
final class AssuranceTestRegistry implements CommandAdapterRegistryContract {
    public function __construct(public AssuranceTestAdapter $adapter) {}
    public function register(CommandAdapterContract $adapter): void {}
    public function has(string $capability): bool { return $capability===$this->adapter->capability(); }
    public function forCapability(string $capability): ?CommandAdapterContract { return $this->has($capability)?$this->adapter:null; }
    public function count(): int { return 1; }
}
final class AssuranceTestRisk implements CommandRiskGateContract {
    public int $calls=0;
    public function available(): bool { return true; }
    public function assess(CommandContext $context, CommandRequest $request): RiskDecision {
        $this->calls++;
        return new RiskDecision(true,'risk:assessment:10','HIGH',0.72,['evidence_required']);
    }
}
final class AssuranceTestGate implements CommandAssuranceGateContract {
    public int $calls=0;
    public function __construct(public bool $isAvailable, public string $mode='allow') {}
    public function available(): bool { return $this->isAvailable; }
    public function assess(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null): AssuranceDecision {
        $this->calls++;
        return match($this->mode) {
            'deny' => new AssuranceDecision(false,'assurance:assessment:deny','BLOCKING',['missing_required_evidence'],'ASSURANCE_DENIED'),
            'malformed' => new AssuranceDecision(true,null,'POLICY',[]),
            default => new AssuranceDecision(true,'assurance:assessment:10','POLICY',['checklist:44','evidence:photo:2']),
        };
    }
}
final class AssuranceTestGovernance implements CommandGovernanceGateContract {
    public int $calls=0;
    public ?string $lastAssuranceReference=null;
    public function available(): bool { return true; }
    public function evaluate(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null, ?AssuranceDecision $assurance = null, ?\App\Extensions\TitanCommandBus\System\DTO\AutonomyDecision $autonomy = null): GovernanceDecision {
        $this->calls++;
        $this->lastAssuranceReference=$assurance?->reference;
        return new GovernanceDecision(true,'gov:decision:10',null,'approval:10');
    }
}
final class AssuranceTestStore implements CommandReceiptStoreContract {
    public array $claims=[];
    private function key(CommandContext $c, CommandRequest $r): string { return $c->tenantCompanyId.'|'.$r->idempotencyKey; }
    public function existing(CommandContext $context, CommandRequest $request): ?array { return $this->claims[$this->key($context,$request)] ?? null; }
    public function claim(CommandContext $context, CommandRequest $request, string $operationId, string $requestHash): bool {
        $k=$this->key($context,$request); if(isset($this->claims[$k])) return false;
        $this->claims[$k]=['request_hash'=>$requestHash,'operation_id'=>$operationId,'status'=>'processing','receipt'=>null]; return true;
    }
    public function complete(CommandReceipt $receipt): void {
        $k=$receipt->tenantCompanyId.'|'.$receipt->idempotencyKey;
        $this->claims[$k]['status']=$receipt->status; $this->claims[$k]['receipt']=$receipt->toArray();
    }
    public function health(): array { return ['receipts_table'=>true,'idempotency_table'=>true]; }
}
final class AssuranceTestSignals implements CommandSignalEmitterContract {
    public array $events=[];
    public function available(): bool { return true; }
    public function emit(string $type, array $payload): void { $this->events[$type]=$payload; }
}

$ctx=new CommandContext(42,'agent','ar-agent','titan-workforce');
$adapter=new AssuranceTestAdapter();
$registry=new AssuranceTestRegistry($adapter);
$risk=new AssuranceTestRisk();
$signals=new AssuranceTestSignals();

$assurance=new AssuranceTestGate(false);
$gov=new AssuranceTestGovernance();
$bus=new CommandBus($registry,$risk,$assurance,$gov,new AssuranceTestStore(),$signals);
$blocked=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>5000],'assurance-unavailable','t1','c1','cause1','root1'));
if($blocked->status!=='blocked'||$blocked->reasonCode!=='ASSURANCE_UNAVAILABLE'||$adapter->calls!==0||$gov->calls!==0||$risk->calls!==1) throw new RuntimeException('assurance unavailable must fail closed after risk but before governance and adapter execution');

$gov=new AssuranceTestGovernance();
$bus=new CommandBus($registry,$risk,new AssuranceTestGate(true,'malformed'),$gov,new AssuranceTestStore(),$signals);
$malformed=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>5000],'assurance-malformed','tm','cm','causem','rootm'));
if($malformed->status!=='blocked'||$malformed->reasonCode!=='ASSURANCE_DECISION_INVALID'||$gov->calls!==0||$adapter->calls!==0) throw new RuntimeException('malformed allowed assurance decision without durable reference must fail closed');

$gov=new AssuranceTestGovernance();
$denyGate=new AssuranceTestGate(true,'deny');
$bus=new CommandBus($registry,$risk,$denyGate,$gov,new AssuranceTestStore(),$signals);
$denied=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>5000],'assurance-denied','t2','c2','cause2','root2'));
if($denied->status!=='blocked'||$denied->reasonCode!=='ASSURANCE_DENIED'||$denied->assuranceReference!=='assurance:assessment:deny'||$denied->assuranceLevel!=='BLOCKING'||$adapter->calls!==0||$gov->calls!==0) throw new RuntimeException('assurance denial must be durable and stop before governance');

$adapter2=new AssuranceTestAdapter();
$registry2=new AssuranceTestRegistry($adapter2);
$allowGate=new AssuranceTestGate(true,'allow');
$gov=new AssuranceTestGovernance();
$signals=new AssuranceTestSignals();
$bus=new CommandBus($registry2,$risk,$allowGate,$gov,new AssuranceTestStore(),$signals);
$applied=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>5000],'assurance-allow','t3','c3','cause3','root3'));
if($applied->status!=='applied'||$applied->assuranceReference!=='assurance:assessment:10'||$applied->assuranceLevel!=='POLICY'||$applied->assuranceEvidence!==['checklist:44','evidence:photo:2']||$gov->calls!==1||$gov->lastAssuranceReference!=='assurance:assessment:10'||$adapter2->calls!==1) throw new RuntimeException('assurance evidence must flow into successful governed receipt and governance');
if(($signals->events['command.completed']['assurance_reference']??null)!=='assurance:assessment:10'||($signals->events['command.completed']['assurance_level']??null)!=='POLICY') throw new RuntimeException('assurance evidence must propagate into command outcome Signal telemetry');

$health=$bus->health();
if(($health['dependencies']['assurance']??null)!==true) throw new RuntimeException('health must report assurance dependency readiness');

echo "PASS AssuranceIntegrationTest\n";
