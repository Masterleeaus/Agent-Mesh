# Historical WorkCore Integration

**HISTORICAL_DOC only.** v10.3.0 has no active WorkCore runtime/config/manifest dependency. See `WORKCORE-REMOVAL.md` and `CRM-INTEGRATION.md` for the Phase 6 architecture.
