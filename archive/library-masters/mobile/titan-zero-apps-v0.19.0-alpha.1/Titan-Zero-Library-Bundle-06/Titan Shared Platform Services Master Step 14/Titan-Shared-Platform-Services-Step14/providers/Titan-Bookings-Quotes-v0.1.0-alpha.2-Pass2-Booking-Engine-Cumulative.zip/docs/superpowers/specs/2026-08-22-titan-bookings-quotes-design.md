# Titan Bookings & Quotes Design

## Goal
Create one canonical Titan front-office commercial extension from the BookingModule, Quoting Wizard, Quotes, QuoteEngine, FSMSales and agreement donors without importing their overlapping ownership boundaries.

## Architecture
Titan Bookings & Quotes owns service requests/bookings and commercial quote records. CRM remains customer authority; Scheduling/Workforce remain worker and dispatch authority; Finance/Invoicing remains invoice authority; Titan Go remains field execution authority. Cross-extension behavior uses typed ports, governed commands and durable privacy-minimized Signals rather than peer private-table access.

## Canonical lifecycle
Enquiry → service request/booking → scope → quote draft/version → sent → accepted/rejected/expired → booking confirmation → scheduling handoff → job handoff → variation/requote → invoice handoff.

## Canonical owned aggregates
- Booking: public ID, company boundary, customer reference, service/site facts, requested windows, lifecycle/version, commercial linkage.
- Quote: public ID/number, booking/customer references, version, status, validity, currency, totals and immutable pricing snapshot.
- Quote line: service/product reference, description snapshot, quantity, unit, unit price, discount/tax snapshot and total.
- Acceptance: quote/version, actor/customer reference, acceptance evidence, timestamp and idempotency key.
- Variation: booking/job reference, quote lineage, reason, commercial delta and approval state.
- Durable outbox: tenant/company-scoped facts for booking/quote transitions and handoffs.

## Authority boundaries
`company_id` is the sole canonical Titan tenant/company boundary for new code. Donor `tenant_company_id` patterns are not carried into this new extension. No direct ownership of CRM customers, workers, shifts, payroll, invoices, payments or job execution. No direct peer private-table reads/writes.

## Surfaces
Titan Zero: Bookings, Quotes, Quote Builder, Approvals/Expiring, Commercial Timeline and settings.
Titan Hub: request/booking journey, quote view, accept/reject, variation approval and status.
Titan Go: read-only commercial/job handoff context required for field execution.
API: versioned opaque-ID endpoints with bounded pagination and actor-derived authority.

## AI/automation
Workforce-compatible roles inspect bookings/quotes, detect stale quotes, missing scope, expiring approvals, conversion leakage and handoff failures. AI proposes actions; governed writes use Command Bus and cannot self-approve.

## Donor reuse policy
Reuse algorithms, validation ideas, UI patterns and test cases where safe. Do not copy donor tables wholesale. BookingModule scheduling/dispatch logic becomes typed handoff behavior because Scheduling/Workforce own dispatch. FSMSales invoice generation becomes an invoice-request port because Finance owns invoices. Agreements/recurring donors inform later commercial terms but do not become duplicate sales/accounting authorities.

## Release strategy
Eight cumulative passes:
1. Foundation, donor normalization and authority contracts.
2. Canonical booking engine.
3. Quote/pricing/versioning engine.
4. Titan Hub approval and customer journeys.
5. Scheduling/job/invoice/payment integration ports.
6. Workforce intelligence, Signals and proactive responsibilities.
7. Titan Zero operational UI and versioned API.
8. Deep hardening, migration/import tooling and production certification.
