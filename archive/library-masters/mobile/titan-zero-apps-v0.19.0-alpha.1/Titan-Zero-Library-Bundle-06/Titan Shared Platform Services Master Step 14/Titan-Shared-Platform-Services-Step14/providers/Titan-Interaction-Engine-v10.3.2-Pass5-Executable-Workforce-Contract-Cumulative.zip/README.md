# Titan Interaction Engine v10.3.2 — Phase 6

Titan Interaction Engine is Titan Zero's **Field/Home Services** structured-interaction layer. It owns wizards, journeys, interaction state, validation, authority, approvals, LocalBrain/offline guidance, capability routing, onboarding orchestration and cross-surface presentation. It does **not** own CRM business records, app-builder persistence, chatbot persistence, communication credentials, devices or TitanAI provider configuration.

## Locked platform boundary

`company_id` is the canonical Titan business tenant. `actor_id` identifies the person/system actor; `source_surface` identifies Hub, Go, Command, Onboarding, Chatbot, API or system context. `tenant_id` remains only a temporary compatibility mirror in legacy storage/payload paths and never establishes tenant authority.

Phase 6 removes active WorkCore runtime/configuration coupling. Business operations route to the **CRM capability provider**. App/UI provisioning routes to **Titan Builder**. Chatbot setup routes to **Chatbot**. Communications route to **Titan Connect**. Mobile readiness/configuration routes to **Mobile Core**. AI configuration routes to **TitanAI**. Missing providers fail closed.

## Capability router

The governed path is:

```text
intent / wizard / journey
        ↓
CapabilityRegistry
        ↓
authority + approval
        ↓
CapabilityRouter
        ↓
owning provider gateway
        ↓
CRM / Builder / Chatbot / Connect / Mobile / TitanAI
```

Capabilities distinguish declared, supported, available, authorized and executable state. Unknown or unbound capabilities are unavailable; provider reflection/model mutation is not used.

## Field/Home Services profile

The active `field_home_services` profile uses exactly ten canonical verticals:

`cleaning`, `plumbing`, `electrical`, `hvac`, `handyman-property-maintenance`, `landscaping-gardening`, `pest-control`, `locksmith-security`, `roofing-guttering`, `appliance-equipment-repair`.

The source package preserves **30 wizard definitions** and **38 templates** for compatibility/regression. The active profile exposes **13 wizards** and **16 templates**; non-target donor definitions remain dormant and are not globally exposed.

## Four PWA surfaces

- **Titan Hub:** customer onboarding/service booking.
- **Titan Go:** field completion, materials, variations, incident/inspection/evidence workflows with offline support.
- **Titan Command:** owner/manager operational wizards and approvals.
- **Titan Onboarding:** privileged company setup/provisioning journey.

All consume the same WizardSession/interaction protocol. A surface is presentation context, **not authorization**.

## Titan Onboarding

`field_home_services_onboarding_v1` preserves the **121-entry source catalogue**, **116 runtime questions**, **16 sections** and five explicit admin/platform exclusions. Question definitions are data-driven and include destination provider/capability/group metadata.

The flow is:

```text
answers → validate/branch → compile server plan → preview → approve →
dependency-aware provider execution → readiness aggregate → activation last
```

Plans are company-scoped and server-side. Secure tasks retain only connection status/opaque reference metadata. Activation is explicit, approval-required, fresh-auth protected and last.

## LocalBrain and offline

LocalBrain v2 remains inside Interaction Engine for bounded local guidance, intent/entity assistance, memory/reranking, temporal reasoning and Titan Go poor-connectivity continuation. It never fabricates authoritative remote state. Capability descriptors own `offline_local`, `offline_queueable` or `online_required` classification; clients cannot elevate that classification.

## Engine library

The 80-engine contract/implementation architecture remains preserved across executive, cognitive, memory, learning, planning, human interaction, AI infrastructure and business intelligence domains.

## Current external provider status

- CRM provider: capability contract/catalogue implemented; current companion CRM lacks the required public company-scoped gateway, so execution is fail-closed until bound.
- Builder provider: partial verified adapter for published preview/publish/rollback contracts; broader provisioning remains gateway-dependent.
- Chatbot provider: contract/catalogue implemented; public provisioning gateway binding remains unverified.
- Connect provider: partial verified adapter for published messaging gateway; connection/OAuth start remains unavailable unless a gateway is bound.
- Mobile provider: capability contract/catalogue implemented; the supplied global Mobile capability registry is not company-scoped, so readiness and provisioning remain fail-closed until a verified `company_id` gateway is bound.
- TitanAI provider: configuration capability contract/catalogue implemented; public configuration gateway remains unverified.

Core Interaction Engine still boots if any optional provider is absent.

## Verification

```bash
php bin/verify.php
npm test
```

See `docs/KNOWN-LIMITATIONS.md` for host-certification limits and `docs/UPGRADE-10.2-TO-10.3.md` for migration guidance.

## Template discovery and retained catalogue

The retained compatibility catalogue contains **29 ready templates** and 9 draft templates (38 total). The active Field/Home Services product profile exposes only the relevant subset, while the remaining donor templates stay dormant for migration/regression purposes. Ready assurance workflows include **Incident Response** and Inspection / Corrective Action.

Authenticated template discovery remains available through the existing API compatibility route:

```text
GET  /templates
```

Template availability is still capability-aware: a template can be engine-ready while its owning CRM/Builder/Chatbot/Connect/Mobile/TitanAI capability remains unavailable until the corresponding provider is installed and verified.

## Phase 6.1 settings surfaces

v10.3.2 adds Super Admin platform settings, company owner/admin Interaction defaults and per-user preferences. See `docs/SETTINGS.md`. These settings are scoped separately and do not bypass capability authority or duplicate CRM/Builder/Chatbot/Connect/Mobile/TitanAI configuration ownership.


## v10.3.2 installer/admin fix

See `docs/UPGRADE-10.3.1-TO-10.3.2.md` for the provider clean-boot fix, Super Admin navigation and security-readiness behavior.
