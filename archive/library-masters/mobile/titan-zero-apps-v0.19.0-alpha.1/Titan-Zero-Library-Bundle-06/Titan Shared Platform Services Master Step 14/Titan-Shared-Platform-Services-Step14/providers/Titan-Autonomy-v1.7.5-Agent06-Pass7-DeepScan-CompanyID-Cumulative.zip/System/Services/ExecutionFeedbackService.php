<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\{AutonomyQueryContract,ExecutionReceiptStoreContract};
use App\Extensions\TitanAutonomy\System\DTOs\{CapabilityState,EvidenceSnapshot,OutcomeObservation};
use App\Extensions\TitanAutonomy\System\Enums\{AutonomyLevel,RiskClass,UserResponseClass};
use InvalidArgumentException;
use RuntimeException;

final class ExecutionFeedbackService
{
    public function __construct(
        private readonly ExecutionReceiptStoreContract $receipts,
        private readonly AutonomyQueryContract $query,
        private readonly AutonomyRuntimeService $runtime,
        private readonly string $policyVersion,
        private readonly NegativeExecutionFeedbackPolicy $policy = new NegativeExecutionFeedbackPolicy(),
        private readonly ExecutionReceiptSanitizer $sanitizer = new ExecutionReceiptSanitizer(),
    ) {}

    public function record(int $tenantCompanyId, int $userId, string $correlationId, string $classification, array $details = []): array
    {
        $this->policy->assertAllowed($classification);
        $receipt = $this->receipts->findByCorrelation($tenantCompanyId, trim($correlationId));
        if ($receipt === null) throw new RuntimeException('EXECUTION_RECEIPT_NOT_FOUND');
        if ((int)($receipt['tenant_company_id'] ?? 0) !== $tenantCompanyId) throw new RuntimeException('EXECUTION_RECEIPT_TENANT_MISMATCH');

        $targetLabel = $this->labelFor($classification);
        if (($receipt['observation_status'] ?? '') === 'finalized' && ($receipt['final_label'] ?? null) === $targetLabel) {
            return ['duplicate'=>true,'learning_label'=>$targetLabel,'receipt_id'=>$receipt['public_id']??null];
        }

        $stateRow = $this->query->capabilityState($tenantCompanyId, (string)$receipt['capability'], (string)($receipt['workflow_key'] ?? ''));
        if ($stateRow === null) throw new RuntimeException('CAPABILITY_STATE_NOT_FOUND');
        $state = $this->hydrateState($stateRow);

        $feedbackRef = $this->receipts->appendFeedback((string)$receipt['public_id'], [
            'tenant_company_id'=>$tenantCompanyId,
            'user_id'=>$userId,
            'source'=>'authorised_user',
            'classification'=>$classification,
            'material_edit'=>$classification==='materially_corrected',
            'details'=>$this->sanitizer->sanitize($details),
            'policy_version'=>$this->policyVersion,
        ]);

        [$response,$executionSucceeded,$reversed,$incident,$materialEdit,$regressionCause] = $this->observationFor($classification);
        $settings = $this->query->learningSettings($tenantCompanyId);
        $assuranceAtExecution = (array)($receipt['assurance_at_execution'] ?? []);
        $evidence = new EvidenceSnapshot(
            currentSuccessStreak:$state->currentSuccessStreak,
            totalSuccesses:$state->totalSuccesses,
            totalFailures:$state->totalFailures,
            totalEdits:$state->totalEdits,
            totalRejections:$state->totalRejections,
            totalReversals:$state->totalReversals,
            hasUnresolvedIncident:$incident,
            assuranceAmber:strtoupper((string)($assuranceAtExecution['status']??''))==='AMBER',
            assuranceRed:false,
        );
        $context=(array)($receipt['context']??[]);
        $context['correlation_id']=(string)($receipt['correlation_id']??$correlationId);
        $outcome=[
            'correlation_id'=>(string)($receipt['correlation_id']??$correlationId),
            'feedback_ref'=>$feedbackRef,
            'feedback_classification'=>$classification,
            'feedback_details'=>$this->sanitizer->sanitize($details),
            'original_command_status'=>$receipt['command_status']??null,
            'original_command_result'=>$receipt['command_result']??null,
        ];
        $runtime=$this->runtime->recordOutcome(
            $state,
            new OutcomeObservation($response,$executionSucceeded,$reversed,$incident,$materialEdit,false,$regressionCause),
            $evidence,
            $userId,
            $context,
            (array)($receipt['command_payload']??[]),
            (array)($details['corrected_action']??$receipt['command_payload']??[]),
            $outcome,
            max(0.0,min(1.0,(float)($assuranceAtExecution['confidence']??0.0))),
            [
                'user'=>(bool)($settings['user_learning']??true),
                'business'=>(bool)($settings['business_learning']??true),
                'system'=>(bool)($settings['system_wide_learning']??false),
            ],
        );

        $this->receipts->finalize((string)$receipt['public_id'], [
            'final_label'=>$targetLabel,
            'feedback_ref'=>$feedbackRef,
            'learning_ref'=>$runtime->learningReference,
            'gate_ref'=>$runtime->gateAuditReference,
            'regression_ref'=>$runtime->regressionAuditReference,
            'finalized_at'=>gmdate('Y-m-d H:i:s'),
        ]);

        return [
            'duplicate'=>false,
            'receipt_id'=>$receipt['public_id']??null,
            'feedback_ref'=>$feedbackRef,
            'learning_label'=>$targetLabel,
            'current_level'=>$runtime->state->currentLevel->key(),
            'regression_ref'=>$runtime->regressionAuditReference,
        ];
    }

    private function observationFor(string $classification): array
    {
        return match($classification) {
            'materially_corrected' => [UserResponseClass::ApprovedMaterialEdit,true,false,false,true,'material_correction'],
            'reversed' => [UserResponseClass::Reversed,true,true,false,false,'reversal'],
            'failed' => [UserResponseClass::Failed,false,false,false,false,null],
            'rejected' => [UserResponseClass::Rejected,true,false,false,false,null],
            'exception' => [UserResponseClass::Exception,true,false,true,false,null],
            default => throw new InvalidArgumentException('UNSUPPORTED_EXECUTION_FEEDBACK'),
        };
    }

    private function labelFor(string $classification): string
    {
        return match($classification) {
            'materially_corrected'=>'materially_corrected',
            'reversed'=>'reversed',
            'failed'=>'failed',
            'rejected'=>'rejected',
            'exception'=>'exception',
            default=>throw new InvalidArgumentException('UNSUPPORTED_EXECUTION_FEEDBACK'),
        };
    }

    private function hydrateState(array $row): CapabilityState
    {
        $level=match((string)($row['current_level']??'suggest')){'assist'=>AutonomyLevel::Assist,'semi_auto'=>AutonomyLevel::SemiAuto,'auto'=>AutonomyLevel::Auto,'trusted_auto'=>AutonomyLevel::TrustedAuto,default=>AutonomyLevel::Suggest};
        return new CapabilityState(
            (int)$row['tenant_company_id'],(string)$row['capability'],(string)($row['workflow_key']??''),RiskClass::from((string)$row['risk']),$level,
            (int)($row['required_success_streak']??0),(int)($row['current_success_streak']??0),(int)($row['highest_success_streak']??0),(int)($row['total_successes']??0),(int)($row['total_failures']??0),(int)($row['total_edits']??0),(int)($row['total_rejections']??0),(int)($row['total_reversals']??0),(bool)($row['platform_gate_eligible']??false),is_array($row['scope']??null)?$row['scope']:[],
            isset($row['last_success_at'])&&$row['last_success_at']!==null?(string)$row['last_success_at']:null,
            isset($row['last_failure_at'])&&$row['last_failure_at']!==null?(string)$row['last_failure_at']:null,
        );
    }
}
