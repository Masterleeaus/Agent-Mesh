<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Data;

final class ServiceDTO
{
    public function __construct(
        public readonly mixed $publicId,
        public readonly mixed $name,
        public readonly mixed $description,
        public readonly mixed $active,
        public readonly mixed $defaultDurationMinutes,
        public readonly mixed $priceMinor,
        public readonly mixed $currency,
    ) {}

    public function toArray(): array
    {
        return [
            'publicId'=>$this->publicId,
            'name'=>$this->name,
            'description'=>$this->description,
            'active'=>$this->active,
            'defaultDurationMinutes'=>$this->defaultDurationMinutes,
            'priceMinor'=>$this->priceMinor,
            'currency'=>$this->currency,
        ];
    }
}
