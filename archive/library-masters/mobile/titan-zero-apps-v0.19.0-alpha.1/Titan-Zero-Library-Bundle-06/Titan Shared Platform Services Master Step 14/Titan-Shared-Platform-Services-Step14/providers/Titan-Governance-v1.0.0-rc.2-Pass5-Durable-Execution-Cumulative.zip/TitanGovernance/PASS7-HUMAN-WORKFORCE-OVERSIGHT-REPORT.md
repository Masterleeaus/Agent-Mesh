# Titan Governance v0.8.0 — Pass 7 Human Oversight + Workforce Operating View

## Result
Pass 7 adds a read-only Governance operating projection over Titan AI Workforce. Titan AI Workforce remains authoritative for organisation, tasks, queues, reviews, handoffs, staffing, performance and operational incidents. Titan Autonomy remains authoritative for desired, earned and effective authority.

## Implemented
- Canonical `titan-ai-workforce` Control Room normalization through `WorkforceOversightProjector`.
- Organisation graph, manager queues, approvals, handoffs, performance and outcome references.
- Hard override of hierarchy/maturity authority implications: `authority_inherited=false`, `maturity_changes_authority=false`, `can_raise_authority=false`.
- Deterministic approval/handoff ageing and manager workload through `HumanOversightProjector`.
- Workforce-linked Governance intervention history.
- Needs Attention convergence for overdue approvals, aged/escalated handoffs and queue pressure with structured drill-down metadata.
- Authenticated read-only Human Oversight & Workforce Blade surface.
- New read capabilities `governance.workforce-oversight.read` and `governance.human-oversight.read`.

## Explicit non-responsibilities
Governance does not write Workforce tables, activate staff, reassign tasks, approve Workforce reviews, perform handoffs, calculate Workforce performance, or alter Autonomy because of hierarchy, maturity, job title or performance.

## Reference alignment
Implementation was checked against Titan AI Workforce v0.21.0-alpha.21 Pass 15 Control Room/resilience architecture and Titan Extension Blueprint v4.2.2. The live adapter remains host supplied through `TITAN_GOVERNANCE_WORKFORCE_SOURCE_CLASS`.
