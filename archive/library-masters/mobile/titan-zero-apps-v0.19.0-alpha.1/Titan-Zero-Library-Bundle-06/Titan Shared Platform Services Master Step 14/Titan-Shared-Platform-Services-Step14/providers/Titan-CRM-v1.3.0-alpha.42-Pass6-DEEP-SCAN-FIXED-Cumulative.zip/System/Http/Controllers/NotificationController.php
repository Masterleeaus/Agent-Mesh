<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Services\CrmNotificationOutboxService;
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class NotificationController extends Controller {
 public function __construct(private CrmNotificationOutboxService $outbox,private CrmHumanMutationGateway $mutations){}
 public function index(Request $request){return response()->json(['data'=>$this->outbox->pending((int)$request->user()->id,(int)$request->integer('limit',100))]);}
 public function store(Request $request){$d=$request->validate(['channel'=>'required|in:email,in_app,webhook','recipient'=>'nullable|string|max:255','template_key'=>'required|string|max:120','subject_type'=>'nullable|string|max:60','subject_public_id'=>'nullable|string|size:26','payload'=>'nullable|array']);return response()->json(['data'=>$this->mutations->execute($request,'crm.notification.queue',$d)],201);}
}
