<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\TraceProfile;

interface TraceProfileRegistryContract
{
    public function register(TraceProfile $profile): void;

    public function find(string $profileKey, ?int $version = null): ?TraceProfile;

    /** @return list<TraceProfile> */
    public function matchingEventType(string $eventType, int $limit = 64): array;
}
