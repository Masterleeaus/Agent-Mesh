<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Forensics;

use App\Extensions\TitanRewind\System\Support\CanonicalJson;
use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;

final class RewindIntegrityHasher
{
    private const LOCAL_FIELDS = [
        'id','record_uuid','created_at','updated_at','recorded_at','integrity_checked_at',
        'canonical_hash','integrity_hash','chain_position','chain_previous_hash','chain_hash',
    ];

    public function __construct(private CanonicalJson $canonicalJson) {}

    public function contentHash(array $event): string
    {
        return hash('sha256', $this->canonicalJson->encode($this->contentMaterial($event)));
    }

    public function contentMaterial(array $event): array
    {
        foreach (self::LOCAL_FIELDS as $field) unset($event[$field]);

        foreach ($event as $key => $value) {
            if ($value instanceof DateTimeInterface) {
                $event[$key] = (new DateTimeImmutable($value->format(DateTimeInterface::ATOM)))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s.u\Z');
                continue;
            }
            if ($key === 'occurred_at' && is_scalar($value) && trim((string) $value) !== '') {
                try {
                    $event[$key] = (new DateTimeImmutable((string) $value))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s.u\Z');
                } catch (\Throwable) {
                }
            }
        }

        return $event;
    }

    public function chainHash(?string $previousChainHash, string $contentHash, string $eventId, int $position): string
    {
        return hash('sha256', $this->canonicalJson->encode([
            'position' => $position,
            'event_id' => $eventId,
            'content_hash' => strtolower($contentHash),
            'previous_chain_hash' => $previousChainHash === null ? null : strtolower($previousChainHash),
        ]));
    }
}
