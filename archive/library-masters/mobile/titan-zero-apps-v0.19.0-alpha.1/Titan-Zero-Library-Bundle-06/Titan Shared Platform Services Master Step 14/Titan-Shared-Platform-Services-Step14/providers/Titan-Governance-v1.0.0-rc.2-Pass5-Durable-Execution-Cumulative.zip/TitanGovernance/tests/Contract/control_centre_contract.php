<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);function fail_cc(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function same_cc(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_cc($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}function ok_cc(bool $c,string $m):void{if(!$c)fail_cc($m);}
$files=[
 '/System/Contracts/GovernanceReadSourceContract.php','/System/Contracts/GovernanceDecisionReadStoreContract.php','/System/Contracts/GovernanceEscalationStoreContract.php',
 '/System/ReadPlane/GovernanceReadSourceRegistry.php','/System/ReadPlane/SignalHeatmapProjector.php','/System/ReadPlane/OperationalPressureDetector.php','/System/ReadPlane/CircuitBreakerProjector.php','/System/ReadPlane/GovernanceSignalIntelligence.php',
 '/System/ControlCentre/ControlCentreSourceReader.php','/System/ControlCentre/EvidenceFreshnessProjector.php','/System/ControlCentre/ModelHealthProjector.php','/System/ControlCentre/PolicyComplianceHealthProjector.php','/System/ControlCentre/AuthorityContractionProjector.php','/System/ControlCentre/EngineHealthScorecard.php','/System/ControlCentre/GovernanceAttentionRanker.php','/System/ControlCentre/GovernanceControlCentre.php',
];foreach($files as $f){if(!is_file($root.$f))fail_cc('missing '.$f);require_once $root.$f;}
use App\Extensions\TitanGovernance\System\Contracts\GovernanceReadSourceContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceDecisionReadStoreContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceEscalationStoreContract;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceReadSourceRegistry;
use App\Extensions\TitanGovernance\System\ReadPlane\SignalHeatmapProjector;
use App\Extensions\TitanGovernance\System\ReadPlane\OperationalPressureDetector;
use App\Extensions\TitanGovernance\System\ReadPlane\CircuitBreakerProjector;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceSignalIntelligence;
use App\Extensions\TitanGovernance\System\ControlCentre\ControlCentreSourceReader;
use App\Extensions\TitanGovernance\System\ControlCentre\EvidenceFreshnessProjector;
use App\Extensions\TitanGovernance\System\ControlCentre\ModelHealthProjector;
use App\Extensions\TitanGovernance\System\ControlCentre\PolicyComplianceHealthProjector;
use App\Extensions\TitanGovernance\System\ControlCentre\AuthorityContractionProjector;
use App\Extensions\TitanGovernance\System\ControlCentre\EngineHealthScorecard;
use App\Extensions\TitanGovernance\System\ControlCentre\GovernanceAttentionRanker;
use App\Extensions\TitanGovernance\System\ControlCentre\GovernanceControlCentre;
final class CcSource implements GovernanceReadSourceContract{public function __construct(private string $key,private bool $required,private array $snapshot){}public function key():string{return $this->key;}public function required():bool{return $this->required;}public function snapshot(int $tenantCompanyId,array $context=[]):array{return $this->snapshot+['tenant_company_id'=>$tenantCompanyId];}}
final class CcDecisions implements GovernanceDecisionReadStoreContract{public function find(int $tenantCompanyId,string $decisionId):?array{return null;}public function recent(int $tenantCompanyId,int $limit=50):array{return [['decision_id'=>'ex-old','action'=>'EXCEPTION','decided_at'=>'2026-08-20T01:00:00+10:00','result_payload'=>['expires_at'=>'2026-08-21T02:00:00+10:00'],'reason_codes'=>['TEMP']]];}}
final class CcEscalations implements GovernanceEscalationStoreContract{public function queue(int $tenantCompanyId,int $limit=50):array{return [['escalation_id'=>'esc-1','tenant_company_id'=>$tenantCompanyId,'subject_type'=>'invoice','subject_id'=>'INV-9','risk_score'=>91.0,'urgency'=>90,'status'=>'OPEN','opened_at'=>'2026-08-21T01:30:00+10:00','reason_codes'=>['RISK_HIGH']]];}public function find(int $tenantCompanyId,string $escalationId):?array{return null;}public function applyTransition(int $tenantCompanyId,string $escalationId,int $expectedVersion,string $nextStatus,string $resolutionAction,string $decisionId,string $commandReceiptRef):array{throw new RuntimeException('read only test');}}
$registry=new GovernanceReadSourceRegistry();
$registry->register(new CcSource('titan-signal',true,['status'=>'HEALTHY','observed_at'=>'2026-08-21T02:48:00+10:00','signals'=>[],'operational_pressure'=>[['source_component'=>'jobs','queue_depth'=>40,'oldest_age_seconds'=>1000,'failure_rate_pct'=>12,'blocked_count'=>6,'saturation_pct'=>95,'observed_at'=>'2026-08-21T02:48:00+10:00']],'circuit_breakers'=>[['breaker_key'=>'crm-write','source_component'=>'crm','state'=>'OPEN','reason_code'=>'DOWNSTREAM_FAILURE','opened_at'=>'2026-08-21T02:30:00+10:00','observed_at'=>'2026-08-21T02:48:00+10:00']],'control_centre'=>[]]));
$registry->register(new CcSource('titan-autonomy',true,['status'=>'HEALTHY','observed_at'=>'2026-08-21T02:48:00+10:00','control_centre'=>['authority_constraints'=>[['agent_id'=>'invoice-agent','capability'=>'crm.invoice.create','desired_score'=>80,'earned_score'=>70,'effective_score'=>30,'ceiling_score'=>30,'disposition'=>'REQUIRE_APPROVAL','reason_codes'=>['HIGH_RISK'],'observed_at'=>'2026-08-21T02:48:00+10:00']]]]));
$registry->register(new CcSource('titan-model-council',false,['status'=>'HEALTHY','observed_at'=>'2026-08-21T02:47:00+10:00','control_centre'=>['models'=>[['model_id'=>'broken','status'=>'FAILED','transition_status'=>'FAILED','observed_at'=>'2026-08-21T02:20:00+10:00','reference'=>'m:1']],'council'=>['disagreement_score'=>0.82,'material_disagreement'=>true,'participant_count'=>4,'status'=>'HEALTHY','observed_at'=>'2026-08-21T02:47:00+10:00']]]));
$registry->register(new CcSource('titan-assurance',false,['status'=>'HEALTHY','observed_at'=>'2026-08-21T02:47:00+10:00','control_centre'=>['policies'=>[['policy_key'=>'p1','expected_version'=>'2','current_version'=>'1','status'=>'ACTIVE','observed_at'=>'2026-08-21T02:47:00+10:00']],'controls'=>[['control_key'=>'c1','status'=>'NON_COMPLIANT','evidence_status'=>'CURRENT','observed_at'=>'2026-08-21T02:47:00+10:00','reference'=>'c:1']]]]));
$signal=new GovernanceSignalIntelligence($registry,new SignalHeatmapProjector(),new OperationalPressureDetector(),new CircuitBreakerProjector());
$centre=new GovernanceControlCentre(new ControlCentreSourceReader($registry),new EvidenceFreshnessProjector(),new ModelHealthProjector(),new PolicyComplianceHealthProjector(),new AuthorityContractionProjector(),new EngineHealthScorecard(),new GovernanceAttentionRanker(),new CcDecisions(),new CcEscalations(),$signal);
$r=$centre->snapshot(42,['now'=>'2026-08-21T02:50:00+10:00','fresh_after_seconds'=>300,'exception_expiring_seconds'=>3600]);
same_cc(42,$r['tenant_company_id'],'tenant identity');same_cc('NON_COMPLIANT',$r['status'],'explicit non-compliance should surface overall');ok_cc(($r['needs_attention']['critical_count']??0)>=3,'critical attention should include failed control/model/expired exception or risk escalation');
same_cc('NON_COMPLIANT',$r['policy_compliance']['status'],'policy compliance facet');same_cc('DEGRADED',$r['model_health']['status'],'failed model/council disagreement facet');same_cc(0,$r['engine_health']['required_unavailable'],'signal/autonomy are healthy so required unavailable must be zero');
echo "PASS: Governance control centre contract\n";
