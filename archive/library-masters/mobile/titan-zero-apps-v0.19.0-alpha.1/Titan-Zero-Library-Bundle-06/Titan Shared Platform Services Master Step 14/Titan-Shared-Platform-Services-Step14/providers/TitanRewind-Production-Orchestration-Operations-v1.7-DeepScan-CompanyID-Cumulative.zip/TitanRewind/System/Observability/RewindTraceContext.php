<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Observability;

use InvalidArgumentException;

final readonly class RewindTraceContext
{
    public function __construct(private int $tenantCompanyId, private string $traceId, private string $correlationId, private ?string $causationId = null, private string $extensionKey = 'titan-rewind')
    {
        if ($tenantCompanyId < 1 || trim($traceId)==='' || trim($correlationId)==='') throw new InvalidArgumentException('Tenant, trace and correlation context are required.');
    }
    public static function fromArray(array $data): self { return new self((int)($data['tenant_company_id']??0),(string)($data['trace_id']??''),(string)($data['correlation_id']??$data['trace_id']??''),isset($data['causation_id'])?(string)$data['causation_id']:null); }
    public function tenantCompanyId(): int { return $this->tenantCompanyId; }
    public function traceId(): string { return $this->traceId; }
    public function correlationId(): string { return $this->correlationId; }
    public function causationId(): ?string { return $this->causationId; }
    public function extensionKey(): string { return $this->extensionKey; }
    public function toArray(): array { return ['tenant_company_id'=>$this->tenantCompanyId,'trace_id'=>$this->traceId,'correlation_id'=>$this->correlationId,'causation_id'=>$this->causationId,'extension_key'=>$this->extensionKey]; }
}
