<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

use App\Extensions\Crm\System\ReadModels\{CrmProjectionEventProjector,CrmProjectionDeadLetterStore};
use Illuminate\Database\ConnectionInterface;
use Throwable;

/** Post-commit Signal dispatcher. CRM owns durable delivery state; Titan Signal owns event ingestion. */
final class CrmDomainSignalDispatcher
{
    public function __construct(private readonly ConnectionInterface $db,private readonly CrmSignalDeliveryPort $port,private readonly CrmProjectionEventProjector $projector,private readonly CrmProjectionDeadLetterStore $projectionDeadLetters) {}

    /** @return list<array<string,mixed>> */
    public function claimDue(int $limit=50): array
    {
        if(!$this->db->getSchemaBuilder()->hasTable('crm_domain_signal_outbox'))return [];
        $limit=max(1,min(500,$limit));
        $timeout=max(30,(int)config('crm.governance.signal_delivery.claim_timeout_seconds',300));
        return $this->db->transaction(function()use($limit,$timeout):array{
            $rows=$this->db->table('crm_domain_signal_outbox')
                ->whereNull('dead_lettered_at')
                ->where(function($q){$q->whereIn('status',['pending','retry'])->orWhere(function($q){$q->where('status','claimed')->where('claimed_at','<',now()->subSeconds(max(30,(int)config('crm.governance.signal_delivery.claim_timeout_seconds',300))));});})
                ->where(function($q){$q->whereNull('available_at')->orWhere('available_at','<=',now());})
                ->orderBy('id')->lockForUpdate()->limit($limit)->get();
            $out=[];
            foreach($rows as $row){
                $this->db->table('crm_domain_signal_outbox')->where('id',$row->id)->update(['status'=>'claimed','claimed_at'=>now(),'last_attempt_at'=>now(),'attempt_count'=>(int)$row->attempt_count+1,'updated_at'=>now()]);
                $fresh=$this->db->table('crm_domain_signal_outbox')->where('id',$row->id)->first();
                if($fresh)$out[]=(array)$fresh;
            }
            return $out;
        });
    }

    public function deliverDue(int $limit=50): array
    {
        $summary=['claimed'=>0,'projected'=>0,'projection_failed'=>0,'delivered'=>0,'retry'=>0,'dead_letter'=>0];
        foreach($this->claimDue($limit) as $event){
            $summary['claimed']++;
            // event_dedup_key is the stable delivery identity shared with Titan Signal.
            if(trim((string)($event['event_dedup_key']??''))===''){
                $this->markRetry((string)$event['public_id'],'Signal event is missing event_dedup_key.');$summary['retry']++;continue;
            }
            try{
                $projection=$this->projector->projectEvent($event);
                $summary['projected']+=(int)($projection['projected']??0);
            }catch(Throwable $projectionError){
                // Read projections are disposable and rebuildable; never block authoritative Signal delivery.
                $this->projectionDeadLetters->recordFailure($event,$projectionError);
                $summary['projection_failed']++;
            }
            try{
                $result=$this->port->deliver($event);
                $state=strtolower((string)($result['status']??''));
                if(in_array($state,['accepted','delivered','ok'],true)){$this->markDelivered((string)$event['public_id'],$result);$summary['delivered']++;continue;}
                $this->markRetry((string)$event['public_id'],(string)($result['reason']??'Titan Signal deferred delivery.'));
                $summary['retry']++;
            }catch(Throwable $e){
                if($this->markRetry((string)$event['public_id'],$e->getMessage()))$summary['retry']++;else $summary['dead_letter']++;
            }
        }
        return $summary;
    }

    public function markDelivered(string $publicId,array $providerReceipt=[]): void
    {
        $this->db->table('crm_domain_signal_outbox')->where('public_id',$publicId)->update([
            'status'=>'delivered','provider_receipt'=>json_encode($providerReceipt,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
            'dispatched_at'=>now(),'claimed_at'=>null,'last_error'=>null,'updated_at'=>now(),
        ]);
    }

    /** Return true when scheduled for retry; false when dead-lettered. */
    public function markRetry(string $publicId,string $error): bool
    {
        $row=$this->db->table('crm_domain_signal_outbox')->where('public_id',$publicId)->first();
        if(!$row)return false;
        $attempt=(int)($row->attempt_count??0);$max=max(1,(int)config('crm.governance.signal_delivery.max_attempts',8));
        if($attempt>=$max){
            $this->db->table('crm_domain_signal_outbox')->where('public_id',$publicId)->update(['status'=>'dead_letter','dead_lettered_at'=>now(),'claimed_at'=>null,'last_error'=>substr($error,0,4000),'updated_at'=>now()]);
            return false;
        }
        $base=max(1,(int)config('crm.governance.signal_delivery.retry_base_seconds',30));
        $delay=min(3600,$base*(2**max(0,$attempt-1)));
        $this->db->table('crm_domain_signal_outbox')->where('public_id',$publicId)->update(['status'=>'retry','available_at'=>now()->addSeconds($delay),'claimed_at'=>null,'last_error'=>substr($error,0,4000),'updated_at'=>now()]);
        return true;
    }
}
