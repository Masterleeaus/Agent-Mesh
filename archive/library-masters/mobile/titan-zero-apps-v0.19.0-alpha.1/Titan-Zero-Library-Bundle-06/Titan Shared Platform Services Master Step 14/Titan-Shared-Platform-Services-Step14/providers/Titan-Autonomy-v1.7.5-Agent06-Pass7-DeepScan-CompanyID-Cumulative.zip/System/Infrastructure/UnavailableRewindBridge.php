<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\RewindBridgeContract;

final class UnavailableRewindBridge implements RewindBridgeContract
{
    public function available(): bool
    {
        return false;
    }

    public function record(string $eventType, array $payload): ?string
    {
        return null;
    }
}
