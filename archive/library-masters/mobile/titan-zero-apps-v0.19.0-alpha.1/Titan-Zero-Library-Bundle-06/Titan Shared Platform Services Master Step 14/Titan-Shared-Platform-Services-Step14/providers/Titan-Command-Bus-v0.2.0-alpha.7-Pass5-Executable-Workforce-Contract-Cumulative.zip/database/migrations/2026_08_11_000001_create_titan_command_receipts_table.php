<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_command_receipts')) { return; }
        Schema::create('titan_command_receipts', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('tenant_company_id')->index();
            $table->string('trace_id', 191)->nullable()->index();
            $table->string('correlation_id', 191)->nullable()->index();
            $table->string('type', 120)->default('record')->index();
            $table->string('status', 40)->default('scaffold')->index();
            $table->json('payload')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_command_receipts');
    }
};
