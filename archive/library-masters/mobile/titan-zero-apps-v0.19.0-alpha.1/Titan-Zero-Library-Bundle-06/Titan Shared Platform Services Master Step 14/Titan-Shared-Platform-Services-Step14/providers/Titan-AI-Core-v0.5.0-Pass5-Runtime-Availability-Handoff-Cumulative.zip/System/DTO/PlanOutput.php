<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class PlanOutput { public function __construct(public string $key, public string $type) {} public function toArray(): array { return ['key'=>$this->key,'type'=>$this->type]; } }
