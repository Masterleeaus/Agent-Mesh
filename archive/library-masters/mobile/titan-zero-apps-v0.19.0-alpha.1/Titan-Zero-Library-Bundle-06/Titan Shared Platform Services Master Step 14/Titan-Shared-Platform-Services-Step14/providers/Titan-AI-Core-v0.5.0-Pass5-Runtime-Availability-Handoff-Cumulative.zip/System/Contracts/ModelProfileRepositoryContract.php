<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Contracts;

interface ModelProfileRepositoryContract
{
    /** @return array<int,array<string,mixed>> */
    public function listForTenant(string $tenantCompanyId, bool $allowGlobalFallback = false, int $limit = 250): array;
}
