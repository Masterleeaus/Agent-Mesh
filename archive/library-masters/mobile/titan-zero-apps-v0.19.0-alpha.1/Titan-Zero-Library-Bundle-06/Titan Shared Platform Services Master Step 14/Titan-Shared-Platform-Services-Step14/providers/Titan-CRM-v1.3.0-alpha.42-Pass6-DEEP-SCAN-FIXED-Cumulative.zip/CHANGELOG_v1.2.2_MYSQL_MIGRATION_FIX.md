# MagicAI CRM 1.2.2 — MySQL Migration Compatibility Fix

## Reported failure

Migration `2026_08_09_000008_add_crm_automation_portal_import_hardening.php` failed while creating `crm_portal_grants` with MySQL error 1067: `Invalid default value for expires_at`.

## Root cause

The migration declared required dates as `TIMESTAMP NOT NULL` without an explicit default. On MySQL/MariaDB configurations with legacy TIMESTAMP default behaviour and strict zero-date enforcement, the server can synthesize an implicit zero-date default for a required TIMESTAMP that is not the automatic first timestamp column. Strict mode rejects that DDL.

## Fix

Required application-supplied time values now use `DATETIME NOT NULL`. Nullable event/state timestamps remain nullable TIMESTAMPs. No required expiry/schedule value was weakened to nullable and no fake `CURRENT_TIMESTAMP` default was introduced.

The compatibility rule was applied to all CRM migrations containing required TIMESTAMP columns without explicit defaults, preventing the install from progressing past `expires_at` only to fail later on another required timestamp.

## Failed-install recovery

The failed migration may already have created `crm_automation_rules` and `crm_automation_runs`. Migration 000008 is now restart-safe: it checks for each CRM-owned table before creating it. This allows 1.2.2 to resume from the failed 1.2.1 state without requiring destructive manual cleanup.

## Regression gates

- `bin/verify-mysql-time-columns.php`
- `bin/verify-migration-000008-restartability.php`

Both are executed by `bin/verify.php`.
