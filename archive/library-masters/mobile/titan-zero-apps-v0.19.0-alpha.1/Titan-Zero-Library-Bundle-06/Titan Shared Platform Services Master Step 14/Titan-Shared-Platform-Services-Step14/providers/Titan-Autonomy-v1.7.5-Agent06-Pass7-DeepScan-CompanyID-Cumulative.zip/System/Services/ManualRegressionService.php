<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyControlStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\ControlPlaneAuditSinkContract;

final class ManualRegressionService
{
    private const LEVELS = ['suggest' => 0, 'assist' => 1, 'semi_auto' => 2, 'auto' => 3, 'trusted_auto' => 4];

    public function __construct(
        private readonly AutonomyControlStoreContract $store,
        private readonly string $policyVersion,
        private readonly ?ControlPlaneAuditSinkContract $audit = null,
    ) {}

    public function lower(
        int $tenantCompanyId,
        string $capability,
        string $workflowKey,
        string $currentLevel,
        string $targetLevel,
        string $cause = 'user_requested',
        ?int $actorUserId = null,
        ?string $correlationId = null,
    ): bool {
        if (!isset(self::LEVELS[$currentLevel], self::LEVELS[$targetLevel])) return false;
        if (self::LEVELS[$targetLevel] >= self::LEVELS[$currentLevel]) return false;
        $this->store->lowerCapabilityLevel($tenantCompanyId, $capability, $workflowKey, $targetLevel, $cause, $this->policyVersion);
        $this->audit?->record([
            'tenant_company_id' => $tenantCompanyId,
            'user_id' => $actorUserId,
            'event_type' => 'autonomy.manual_regression',
            'capability' => $capability,
            'workflow_key' => $workflowKey,
            'payload' => ['prior_level' => $currentLevel, 'new_level' => $targetLevel, 'cause' => $cause],
            'policy_version' => $this->policyVersion,
            'correlation_id' => $correlationId,
        ]);
        return true;
    }
}
