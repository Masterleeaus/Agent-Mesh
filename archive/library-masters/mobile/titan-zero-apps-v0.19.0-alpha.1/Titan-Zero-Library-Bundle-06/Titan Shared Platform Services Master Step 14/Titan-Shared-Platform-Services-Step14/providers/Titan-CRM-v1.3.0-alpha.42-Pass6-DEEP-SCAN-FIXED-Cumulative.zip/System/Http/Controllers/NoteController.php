<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Contracts\NoteRepositoryContract; use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class NoteController extends Controller { public function __construct(private NoteRepositoryContract $notes, private \App\Extensions\Crm\System\Governance\CrmHumanMutationGateway $mutations){} public function index(Request $r){return response()->json(['data'=>$this->notes->search((int)$r->user()->id,$r->only(['subject_type','subject_public_id','limit']))]);} public function store(Request $r){$d=$r->validate(['subject_type'=>'required|string|max:60','subject_public_id'=>'required|string|size:26','body'=>'required|string|max:20000','is_pinned'=>'nullable|boolean']); return response()->json($this->mutations->execute($r,'crm.note.create',$d),201);} }
