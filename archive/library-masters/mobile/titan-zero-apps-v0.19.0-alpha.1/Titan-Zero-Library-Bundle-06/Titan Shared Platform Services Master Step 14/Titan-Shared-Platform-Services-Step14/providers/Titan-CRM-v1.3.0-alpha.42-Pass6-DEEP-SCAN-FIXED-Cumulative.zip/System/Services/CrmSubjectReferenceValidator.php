<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Validation\ValidationException;

final class CrmSubjectReferenceValidator
{
    private const TABLES = [
        'company'=>'companies', 'contact'=>'contacts', 'lead'=>'leads', 'deal'=>'deals', 'project'=>'projects', 'task'=>'tasks',
    ];

    public function __construct(private ConnectionInterface $db) {}

    public function require(int $userId, string $type, string $publicId): void
    {
        $key = self::TABLES[$type] ?? null;
        if ($key === null) {
            throw ValidationException::withMessages(['subject_type'=>['Unsupported CRM activity subject type.']]);
        }
        $table = config('crm.tables.' . $key);
        $query = $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id', $publicId);
        if (in_array($key, ['companies','contacts','leads','deals'], true)) $query->whereNull('deleted_at');
        if (! $query->exists()) {
            throw ValidationException::withMessages(['subject_public_id'=>['The selected CRM subject is not available.']]);
        }
    }
}
