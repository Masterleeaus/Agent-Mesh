# Titan AI Convergence Report

| Existing component | Existing owner/namespace | Final destination | Decision | Compatibility action |
|---|---|---|---|---|
| Five-tier runtime contracts/DTOs | `App\\Extensions\\TitanAI...` | `System/TitanAI` | Preserve | Native PSR-4 |
| Tier 0-4 workers/tools | `App\\Services\\AI...` | `System/AI` | Promote | Namespace rewritten under TitanAI |
| CleaningAIWorkerRegistry | global AI namespace | `TitanAIWorkerRegistry` | Replace | Legacy worker IDs mapped as aliases |
| Governance | fake `TitanAIGovernance` extension | `System/Governance` | Merge | One TitanAI lifecycle |
| Embedded WorkCore runtime | `App\\Domains\\WorkCore...` | external canonical WorkCore | Remove | Neutral host bridge |
| Chatbot deployment model import | Chatbot extension | optional resolver binding | Remove coupling | `titan.ai.assistant_deployment_source` |
| Skills extension implementation | separate embedded extension | external/optional | Remove implementation | Bundled signed skill data retained only |
| Memory extension implementation | separate embedded extension | external/optional | Remove | Neutral memory context contract retained |
| ModelCouncil/MultiModel/provider packages | separate embedded extensions | external/optional | Remove | Provider/model routing boundaries retained internally |
| Messaging channels | separate embedded extensions | external/optional | Remove | Channels consume TitanAI runtime contract |
| Reviews/shared/temp/file chat/voice/customer tags | separate embedded extensions | external/optional | Remove | No nested extension identities |
| Extraction classmaps | bootstrap files | removed | Remove | Standard MagicAI `App\\` PSR-4 only |
