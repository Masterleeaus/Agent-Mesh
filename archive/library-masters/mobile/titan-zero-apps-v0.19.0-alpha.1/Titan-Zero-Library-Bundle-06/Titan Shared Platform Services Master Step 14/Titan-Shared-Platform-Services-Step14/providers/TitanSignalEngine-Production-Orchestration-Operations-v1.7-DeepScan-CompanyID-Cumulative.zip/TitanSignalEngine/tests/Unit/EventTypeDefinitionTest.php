<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanSignalEngine\System\Data\EventTypeDefinition;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

final class EventTypeDefinitionTest extends TestCase
{
    public function test_registry_definition_enforces_required_fields_scope_source_and_schema(): void
    {
        $definition = EventTypeDefinition::fromArray([
            'event_type' => 'command.requested',
            'current_schema_version' => 1,
            'supported_schema_versions' => [1],
            'category' => 'command',
            'allowed_scopes' => ['tenant'],
            'required_payload_fields' => ['command_id'],
            'optional_payload_fields' => ['capability'],
            'allow_additional_payload_fields' => false,
            'owner_source' => 'titan-command-bus',
        ]);

        $signal = SignalEnvelope::fromArray([
            'event_type' => 'command.requested',
            'tenant_company_id' => 10,
            'source' => 'titan-command-bus',
            'payload' => ['command_id' => 'cmd_1'],
        ]);

        $definition->validate($signal);
        self::addToAssertionCount(1);
    }

    public function test_registry_definition_rejects_unregistered_payload_field(): void
    {
        $definition = EventTypeDefinition::fromArray([
            'event_type' => 'command.requested',
            'allowed_scopes' => ['tenant'],
            'required_payload_fields' => ['command_id'],
            'allow_additional_payload_fields' => false,
            'owner_source' => 'titan-command-bus',
        ]);

        $signal = SignalEnvelope::fromArray([
            'event_type' => 'command.requested',
            'tenant_company_id' => 10,
            'source' => 'titan-command-bus',
            'payload' => ['command_id' => 'cmd_1', 'unexpected' => true],
        ]);

        $this->expectException(InvalidArgumentException::class);
        $definition->validate($signal);
    }
}
