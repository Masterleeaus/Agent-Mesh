<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Certification;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;

final class CertificationQueueProbeJob implements ShouldQueue
{
    use Dispatchable;
    use InteractsWithQueue;
    use Queueable;
    use SerializesModels;

    public function __construct(public readonly string $token)
    {
    }

    public function handle(): void
    {
        Cache::put(self::cacheKey($this->token), now()->toIso8601String(), now()->addMinute());
    }

    public static function cacheKey(string $token): string
    {
        return 'titan-connect:certification:queue:'.hash('sha256', $token);
    }
}
