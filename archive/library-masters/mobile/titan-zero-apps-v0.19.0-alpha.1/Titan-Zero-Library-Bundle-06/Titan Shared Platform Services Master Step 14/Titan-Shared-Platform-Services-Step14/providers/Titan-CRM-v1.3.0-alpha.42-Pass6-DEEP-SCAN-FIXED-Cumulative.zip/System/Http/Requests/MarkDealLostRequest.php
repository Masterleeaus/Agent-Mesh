<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
final class MarkDealLostRequest extends FormRequest {
 public function authorize(): bool { return true; }
 public function rules(): array { return ['reason'=>['required','string','max:2000']]; }
}
