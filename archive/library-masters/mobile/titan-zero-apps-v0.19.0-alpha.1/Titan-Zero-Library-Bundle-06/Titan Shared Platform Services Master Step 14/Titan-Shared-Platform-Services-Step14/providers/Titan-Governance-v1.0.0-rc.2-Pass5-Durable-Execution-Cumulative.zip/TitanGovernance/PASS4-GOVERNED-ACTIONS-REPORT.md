# Titan Governance v0.5.0 — Pass 4 Governed Actions & Escalation Queue

## Scope

Pass 4 activates the first Governance write-side workflow while preserving the platform rule that consequential execution leaves Governance through Titan Command Bus.

## Implemented

- tenant-scoped escalation inbox;
- deterministic priority: risk DESC → urgency DESC → oldest first;
- APPROVE, REJECT, HOLD, EXCEPTION and ESCALATE;
- immutable Governance policy decision reference before dispatch;
- tenant-scoped operation idempotency and semantic payload hash;
- transient Command Bus retry using the same decision/operation;
- idempotency collision rejection;
- fail-closed configurable Command Bus gateway;
- truthful Command Bus receipt validation;
- Governance-owned escalation target with optimistic versioning;
- dedicated action/exception permissions;
- CSRF-protected + throttled POST routes;
- actual action-gateway readiness in Governance health;
- strict-types tenant resolver correction.

## Deliberate integration boundary

The package does not fabricate a concrete Command Bus adapter because the Command Bus public runtime is independently versioned. The live host must bind `GovernanceCommandGatewayContract` to its installed Command Bus and register `GovernanceEscalationTarget` as the handler/adapter for Governance escalation capabilities. Until then actions fail closed.

## Receipt truth

`APPLIED` is accepted only with a matching Governance decision reference, Command Bus receipt, authoritative domain receipt, adapter identity and `write_verified=true`. Early blocked/failed Command Bus responses may lack a Governance echo and remain truthful failures rather than being rewritten into false success.

## Certification boundary

Static/package verification is performed from exact packaged bytes. Live host certification remains separate and must prove migrations, provider boot, route/auth behavior and real Command Bus dispatch/target execution.
