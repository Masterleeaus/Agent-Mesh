<?php

declare(strict_types=1);

$rewindEvidenceKeys = json_decode((string) env('TITAN_REWIND_EVIDENCE_KEYS_JSON', '[]'), true);
if (!is_array($rewindEvidenceKeys)) $rewindEvidenceKeys = [];
if ($rewindEvidenceKeys === [] && env('TITAN_REWIND_EVIDENCE_PUBLIC_KEY_PATH')) {
    $rewindEvidenceKeys[] = [
        'key_id' => (string) env('TITAN_REWIND_EVIDENCE_KEY_ID', 'titan-rewind-default'),
        'private_key_path' => env('TITAN_REWIND_EVIDENCE_PRIVATE_KEY_PATH'),
        'public_key_path' => env('TITAN_REWIND_EVIDENCE_PUBLIC_KEY_PATH'),
        'status' => 'active',
    ];
}

return [
    'enabled' => true,
    'authoritative_mutation' => false,
    'replay_mutation' => false,
    'replay' => [
        'mutation_policy' => 'deny',
        'network_policy' => env('TITAN_REWIND_REPLAY_NETWORK_POLICY', 'recorded-only'),
        'virtual_clock' => true,
        'deterministic_seed' => true,
    ],
    'queues' => [
        'replay' => env('TITAN_REWIND_REPLAY_QUEUE', 'titan-rewind-replay'),
        'signal' => env('TITAN_REWIND_SIGNAL_QUEUE', 'titan-rewind-signal'),
    ],
    'backpressure' => [
        'soft_backlog' => max(1, (int) env('TITAN_REWIND_SOFT_BACKLOG', 100)),
        'hard_backlog' => max(2, (int) env('TITAN_REWIND_HARD_BACKLOG', 500)),
    ],
    'dead_letter' => [
        'degraded_threshold' => max(0, (int) env('TITAN_REWIND_DEAD_LETTER_DEGRADED_THRESHOLD', 0)),
    ],
    'circuit_breaker' => [
        'failure_threshold' => max(1, (int) env('TITAN_REWIND_CIRCUIT_FAILURE_THRESHOLD', 5)),
        'reset_seconds' => max(5, (int) env('TITAN_REWIND_CIRCUIT_RESET_SECONDS', 60)),
    ],
    'observability' => [
        'persist' => true,
        'structured_logs' => true,
    ],
    'signal' => [
        'outbox_enabled' => true,
        'transport_required_for_readiness' => false,
    ],
    'runtime' => [
        'default_state' => 'ACTIVE',
        'draining' => ['accept_new_work' => false, 'allow_in_flight_completion' => true],
    ],
    'evidence' => [
        'signature_required' => true,
        'signature_method' => 'openssl-rsa-sha256',
        'private_key_path' => env('TITAN_REWIND_EVIDENCE_PRIVATE_KEY_PATH'),
        'public_key_path' => env('TITAN_REWIND_EVIDENCE_PUBLIC_KEY_PATH'),
        'key_id' => env('TITAN_REWIND_EVIDENCE_KEY_ID', 'titan-rewind-default'),
        'keyring' => [
            'active_key_id' => env('TITAN_REWIND_EVIDENCE_ACTIVE_KEY_ID', env('TITAN_REWIND_EVIDENCE_KEY_ID', 'titan-rewind-default')),
            'keys' => $rewindEvidenceKeys,
        ],
        'chain_of_custody' => true,
    ],
    'retention' => [
        'legal_hold_aware' => true,
        'classes' => [
            'ephemeral' => max(1, (int) env('TITAN_REWIND_RETENTION_EPHEMERAL_DAYS', 30)),
            'operational' => max(1, (int) env('TITAN_REWIND_RETENTION_OPERATIONAL_DAYS', 90)),
            'forensic' => max(1, (int) env('TITAN_REWIND_RETENTION_FORENSIC_DAYS', 365)),
            'evidence' => max(1, (int) env('TITAN_REWIND_RETENTION_EVIDENCE_DAYS', 2555)),
        ],
        'batch_size' => max(1, min(1000, (int) env('TITAN_REWIND_RETENTION_BATCH_SIZE', 250))),
        'schedule_enabled' => (bool) env('TITAN_REWIND_RETENTION_SCHEDULE_ENABLED', true),
        'schedule_at' => env('TITAN_REWIND_RETENTION_SCHEDULE_AT', '03:40'),
    ],
    'source_freshness' => [
        'max_age_seconds' => max(30, (int) env('TITAN_REWIND_SOURCE_MAX_AGE_SECONDS', 900)),
    ],
    'forensics' => [
        'late_event_threshold_seconds' => max(0, (int) env('TITAN_REWIND_LATE_EVENT_THRESHOLD_SECONDS', 300)),
    ],
    'limits' => [
        'timeline_entries' => 2000,
        'dependencies_per_trace' => 1000,
        'max_trace_events_in_memory' => 5000,
    ],
    'redacted_keys' => [
        'password','password_confirmation','remember_token','token','access_token','refresh_token','secret','client_secret',
        'api_key','apikey','private_key','card_number','cvv','authorization','cookie','session_id','signature',
    ],
];
