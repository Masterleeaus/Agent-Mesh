<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$adminController = file_get_contents($root . '/System/Http/Controllers/AdminController.php');
$indexController = file_get_contents($root . '/System/Http/Controllers/IndexController.php');
$adminViews = glob($root . '/resources/views/admin-rc8-1/*.blade.php') ?: [];
$indexView = $root . '/resources/views/index-rc7.blade.php';

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$assert(str_contains($adminController, "view('titan-signal-engine::admin-rc8-1."), 'admin controller must use versioned admin-rc8-1 hotfix view paths');
$assert(count($adminViews) === 8, 'rc.8.1 must ship exactly eight versioned admin hotfix page views');
foreach ($adminViews as $adminView) {
    $text = file_get_contents($adminView);
    $assert(str_contains($text, "@extends('panel.layout.app')"), basename($adminView) . ' must extend MagicAI panel.layout.app');
    $assert(! str_contains($text, '<x-layouts.app'), basename($adminView) . ' must not use x-layouts.app');
}

$assert(str_contains($indexController, "view('titan-signal-engine::index-rc7'"), 'tenant controller must retain versioned index-rc7 view path');
$assert(is_file($indexView), 'versioned index-rc7 Blade view missing');
if (is_file($indexView)) {
    $text = file_get_contents($indexView);
    $assert(str_contains($text, "@extends('panel.layout.app')"), 'index-rc7 view must extend MagicAI panel.layout.app');
    $assert(! str_contains($text, '<x-layouts.app'), 'index-rc7 view must not use x-layouts.app');
}

$provider = file_get_contents($root . '/System/TitanSignalEngineServiceProvider.php');
$assert(str_contains($provider, 'purgeLegacyCompiledSignalViews();'), 'provider must invoke targeted legacy Signal compiled-view purge');
$assert(str_contains($provider, 'getCompiledPath'), 'provider purge must resolve Laravel compiled view paths');
$assert(str_contains($provider, 'str_contains($compiledContents, \'layouts.app\')'), 'provider purge must identify stale layouts.app compiled views');
$assert(! str_contains($provider, "Artisan::call('view:clear')"), 'Signal must not clear every host compiled view globally');

if ($failures !== []) {
    fwrite(STDERR, "Blade compiled-cache isolation regression FAILED\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "Blade compiled-cache isolation regression PASS\n";
