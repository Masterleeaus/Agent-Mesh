# Pass 2 Verification

Canonical booking engine uses `company_id`, opaque booking public IDs, optimistic versions, company-scoped idempotency, append-only lifecycle events and separate requested windows. It deliberately does not own schedules, assignments, workers, invoices or payments.

Legacy BookingModule import is explicit mapping only. Rows without an explicit `company_id` fail closed rather than guessing tenant ownership.
