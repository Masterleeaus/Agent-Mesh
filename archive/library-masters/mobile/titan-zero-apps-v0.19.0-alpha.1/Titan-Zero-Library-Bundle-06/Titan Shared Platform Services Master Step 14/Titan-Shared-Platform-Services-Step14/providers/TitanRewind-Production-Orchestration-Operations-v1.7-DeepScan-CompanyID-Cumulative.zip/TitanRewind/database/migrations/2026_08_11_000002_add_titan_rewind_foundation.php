<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_rewind_snapshots')) {
            Schema::table('titan_rewind_snapshots', function (Blueprint $table): void {
                if (!Schema::hasColumn('titan_rewind_snapshots', 'snapshot_uuid')) {
                    $table->uuid('snapshot_uuid')->nullable()->unique();
                }
                if (!Schema::hasColumn('titan_rewind_snapshots', 'causation_id')) {
                    $table->uuid('causation_id')->nullable()->index();
                }
                if (!Schema::hasColumn('titan_rewind_snapshots', 'occurred_at')) {
                    $table->dateTime('occurred_at', 6)->nullable()->index();
                }
                if (!Schema::hasColumn('titan_rewind_snapshots', 'reconstruction_version')) {
                    $table->unsignedSmallInteger('reconstruction_version')->default(1);
                }
                if (!Schema::hasColumn('titan_rewind_snapshots', 'source_hash')) {
                    $table->char('source_hash', 64)->nullable();
                }
                if (!Schema::hasColumn('titan_rewind_snapshots', 'integrity_hash')) {
                    $table->char('integrity_hash', 64)->nullable()->index();
                }
                if (!Schema::hasColumn('titan_rewind_snapshots', 'metadata')) {
                    $table->json('metadata')->nullable();
                }
            });
        }

        if (!Schema::hasTable('titan_rewind_trace_events')) {
            Schema::create('titan_rewind_trace_events', function (Blueprint $table): void {
                $table->id();
                $table->uuid('record_uuid')->unique();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->uuid('event_id')->unique();
                $table->uuid('trace_id')->index();
                $table->uuid('correlation_id')->nullable()->index();
                $table->uuid('causation_id')->nullable()->index();
                $table->string('source_engine', 80)->index();
                $table->string('source_record_id', 191)->nullable()->index();
                $table->string('event_type', 120)->index();
                $table->unsignedBigInteger('sequence')->default(0)->index();
                $table->unsignedTinyInteger('tier')->nullable()->index();
                $table->string('lane', 80)->nullable()->index();
                $table->string('actor_type', 60)->nullable();
                $table->string('actor_id', 191)->nullable();
                $table->string('decision_id', 128)->nullable()->index();
                $table->string('policy_version', 120)->nullable();
                $table->string('guide_version', 120)->nullable();
                $table->string('knowledge_version', 120)->nullable();
                $table->string('model_provider', 80)->nullable();
                $table->string('model_name', 120)->nullable();
                $table->string('model_version', 120)->nullable();
                $table->string('capability_name', 160)->nullable();
                $table->string('capability_version', 80)->nullable();
                $table->json('reason_codes')->nullable();
                $table->json('evidence_refs')->nullable();
                $table->json('rationale')->nullable();
                $table->json('risk_state')->nullable();
                $table->json('assurance_state')->nullable();
                $table->json('autonomy_state')->nullable();
                $table->json('governance_state')->nullable();
                $table->json('payload')->nullable();
                $table->dateTime('occurred_at', 6)->index();
                $table->dateTime('recorded_at', 6)->nullable()->index();
                $table->char('source_hash', 64)->nullable();
                $table->char('previous_hash', 64)->nullable();
                $table->char('integrity_hash', 64)->nullable()->index();
                $table->unsignedSmallInteger('schema_version')->default(1);
                $table->timestamps();

                $table->index(['tenant_company_id', 'trace_id', 'occurred_at'], 'trw_evt_tenant_trace_time');
                $table->index(['tenant_company_id', 'correlation_id'], 'trw_evt_tenant_corr');
            });
        }

        if (!Schema::hasTable('titan_rewind_trace_index')) {
            Schema::create('titan_rewind_trace_index', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->uuid('trace_id');
                $table->uuid('correlation_id')->nullable()->index();
                $table->dateTime('first_event_at', 6)->nullable()->index();
                $table->dateTime('last_event_at', 6)->nullable()->index();
                $table->unsignedBigInteger('event_count')->default(0);
                $table->unsignedInteger('source_count')->default(0);
                $table->unsignedInteger('decision_count')->default(0);
                $table->unsignedInteger('mutation_count')->default(0);
                $table->unsignedInteger('outcome_count')->default(0);
                $table->boolean('has_recovery')->default(false)->index();
                $table->boolean('has_compensation')->default(false)->index();
                $table->string('reconstruction_status', 40)->default('pending')->index();
                $table->string('integrity_state', 40)->default('unknown')->index();
                $table->json('source_engines')->nullable();
                $table->json('policy_versions')->nullable();
                $table->json('guide_versions')->nullable();
                $table->json('model_versions')->nullable();
                $table->uuid('latest_event_id')->nullable();
                $table->dateTime('materialized_at', 6)->nullable()->index();
                $table->unsignedSmallInteger('reconstruction_version')->default(1);
                $table->timestamps();

                $table->unique(['tenant_company_id', 'trace_id'], 'trw_idx_tenant_trace_unique');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_rewind_trace_index');
        Schema::dropIfExists('titan_rewind_trace_events');

        if (Schema::hasTable('titan_rewind_snapshots')) {
            $columns = [
                'snapshot_uuid',
                'causation_id',
                'occurred_at',
                'reconstruction_version',
                'source_hash',
                'integrity_hash',
                'metadata',
            ];

            $existing = array_values(array_filter(
                $columns,
                static fn (string $column): bool => Schema::hasColumn('titan_rewind_snapshots', $column)
            ));

            if ($existing !== []) {
                Schema::table('titan_rewind_snapshots', static function (Blueprint $table) use ($existing): void {
                    $table->dropColumn($existing);
                });
            }
        }
    }
};
