<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Onboarding;

use App\Extensions\TitanConnect\System\Contracts\ProviderHttpClient;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ChannelConnectionMember;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;
use RuntimeException;

final class MetaOAuthService
{
    public function __construct(private readonly ProviderHttpClient $http, private readonly ProviderCredentialStore $credentials) {}

    public function authorizationUrl(int $companyId, int $actorId, string $provider, string $redirectUri): string
    {
        $provider = $this->provider($provider); $appId = trim((string) config('titan-connect.providers.meta.app_id', ''));
        if ($appId === '') throw new RuntimeException('Meta app ID is not configured.');
        $state = Crypt::encryptString(json_encode(['company_id'=>$companyId,'actor_id'=>$actorId,'provider'=>$provider,'nonce'=>(string) Str::uuid(),'expires_at'=>time()+600], JSON_THROW_ON_ERROR));
        $scopes = $provider === 'instagram'
            ? ['pages_show_list','pages_messaging','instagram_basic','instagram_manage_messages']
            : ['pages_show_list','pages_messaging'];
        return rtrim((string) config('titan-connect.providers.meta.dialog_base_url', 'https://www.facebook.com'), '/').'/'.trim((string) config('titan-connect.providers.meta.oauth_version', 'v25.0'), '/').'/dialog/oauth?'.http_build_query([
            'client_id'=>$appId,'redirect_uri'=>$redirectUri,'state'=>$state,'response_type'=>'code','scope'=>implode(',', $scopes),
        ]);
    }

    public function complete(int $companyId, int $actorId, string $provider, string $code, string $state, string $redirectUri): ChannelConnection
    {
        $provider = $this->provider($provider); $payload = $this->state($state);
        if ((int) ($payload['company_id'] ?? 0) !== $companyId || (int) ($payload['actor_id'] ?? 0) !== $actorId || ($payload['provider'] ?? null) !== $provider || (int) ($payload['expires_at'] ?? 0) < time()) {
            throw new RuntimeException('Meta OAuth state is invalid or expired.');
        }
        $appId = trim((string) config('titan-connect.providers.meta.app_id', '')); $appSecret = trim((string) config('titan-connect.providers.meta.app_secret', ''));
        if ($appId === '' || $appSecret === '') throw new RuntimeException('Meta OAuth application credentials are not configured.');
        $graph = rtrim((string) config('titan-connect.providers.meta.graph_base_url', 'https://graph.facebook.com'), '/'); $version = trim((string) config('titan-connect.providers.meta.graph_version', 'v25.0'), '/');
        $tokenResponse = $this->http->request('GET', $graph.'/'.$version.'/oauth/access_token', ['query'=>['client_id'=>$appId,'client_secret'=>$appSecret,'redirect_uri'=>$redirectUri,'code'=>$code]]);
        if (! $tokenResponse->isSuccessful()) throw new RuntimeException('Meta OAuth token exchange failed.');
        $userToken = trim((string) $tokenResponse->json('access_token')); if ($userToken === '') throw new RuntimeException('Meta OAuth access token was missing.');
        $accounts = $this->http->request('GET', $graph.'/'.$version.'/me/accounts', ['bearer'=>$userToken,'query'=>['fields'=>'id,name,access_token,instagram_business_account{id,username,name,profile_picture_url}']]);
        if (! $accounts->isSuccessful()) throw new RuntimeException('Meta account discovery failed.');
        $pages = $accounts->json('data', []); if (! is_array($pages)) $pages = [];
        $selected = null;
        foreach ($pages as $page) {
            if (! is_array($page)) continue;
            if ($provider === 'instagram' && ! is_array($page['instagram_business_account'] ?? null)) continue;
            $selected = $page; break;
        }
        if (! is_array($selected)) throw new RuntimeException('No compatible Meta business account was found.');
        $pageToken = trim((string) ($selected['access_token'] ?? '')); if ($pageToken === '') throw new RuntimeException('Meta page access token was missing.');
        $instagram = is_array($selected['instagram_business_account'] ?? null) ? $selected['instagram_business_account'] : [];
        $externalId = $provider === 'instagram' ? trim((string) ($instagram['id'] ?? '')) : trim((string) ($selected['id'] ?? ''));
        if ($externalId === '') throw new RuntimeException('Meta external account ID was missing.');
        $display = $provider === 'instagram' ? (string) ($instagram['username'] ?? $instagram['name'] ?? 'Instagram') : (string) ($selected['name'] ?? 'Messenger');
        $connection = ChannelConnection::query()->firstOrNew(['company_id'=>$companyId,'provider'=>$provider,'external_account_id'=>$externalId]);
        if (! $connection->exists) { $connection->uuid=(string) Str::uuid(); $connection->status='paused'; }
        $connection->display_name=$display; $connection->settings=['onboarding'=>'meta_oauth','page_id'=>$selected['id'] ?? null,'username'=>$instagram['username'] ?? null,'profile_picture_url'=>$instagram['profile_picture_url'] ?? null]; $connection->save();
        ChannelConnectionMember::query()->updateOrCreate(['channel_connection_id'=>$connection->id,'company_id'=>$companyId,'user_id'=>$actorId], ['role'=>'owner','joined_at'=>now(),'left_at'=>null]);
        $verifyToken = Str::random(48);
        $creds=['access_token'=>$pageToken,'app_secret'=>$appSecret,'verify_token'=>$verifyToken,'page_id'=>(string) ($selected['id'] ?? '')];
        if ($provider === 'instagram') $creds['instagram_account_id']=$externalId;
        $this->credentials->store($companyId,$actorId,$connection,$creds,true);
        return $connection->fresh('members');
    }

    private function provider(string $provider): string
    {
        $provider = strtolower(trim($provider)); if (! in_array($provider,['instagram','messenger'],true)) throw new RuntimeException('Unsupported Meta onboarding provider.'); return $provider;
    }

    private function state(string $state): array
    {
        try { $decoded = json_decode(Crypt::decryptString($state), true, 512, JSON_THROW_ON_ERROR); }
        catch (\Throwable $e) { throw new RuntimeException('Meta OAuth state could not be verified.', previous:$e); }
        return is_array($decoded) ? $decoded : [];
    }
}
