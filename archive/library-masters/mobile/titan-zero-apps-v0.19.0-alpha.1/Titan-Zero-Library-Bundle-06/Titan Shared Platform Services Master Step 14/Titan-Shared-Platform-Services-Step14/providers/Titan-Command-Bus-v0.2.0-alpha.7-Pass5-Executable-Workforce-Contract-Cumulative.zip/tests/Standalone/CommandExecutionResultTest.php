<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
require_once $root.'/System/DTO/CommandExecutionResult.php';
use App\Extensions\TitanCommandBus\System\DTO\CommandExecutionResult;

$ok=new CommandExecutionResult('crm:invoice:1', true, 1, 'invoice', 2);
if (!$ok->writeVerified) throw new RuntimeException('verified result failed');

$threw=false;
try {
    new CommandExecutionResult('crm:invoice:2', false);
} catch (InvalidArgumentException) {
    $threw=true;
}
if (!$threw) throw new RuntimeException('unverified applied result must be rejected');

echo "PASS CommandExecutionResultTest\n";
