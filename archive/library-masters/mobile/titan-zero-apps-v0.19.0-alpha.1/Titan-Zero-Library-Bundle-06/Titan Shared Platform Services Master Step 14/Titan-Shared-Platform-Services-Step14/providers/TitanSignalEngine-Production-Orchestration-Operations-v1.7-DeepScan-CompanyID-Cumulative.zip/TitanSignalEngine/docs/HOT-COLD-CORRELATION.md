# Hot/Cold Correlation & Rewind Continuity

Titan Signal Engine v0.15.0 reconstructs causal history without assuming every event still lives in the hot `titan_signal_events` table.

## Storage model

- **Hot:** canonical immutable event row is present.
- **Cold:** event has been governedly archived, SHA-256 verified and indexed in `titan_signal_archive_catalog`.
- **Mixed:** one trace/workflow contains both tiers.

The archive catalog is the durable cold causal tombstone. It retains event, trace, correlation, causation and root-causation identity even after hot causal-edge projections are pruned.

## Traversal

- Ancestors follow each event's immutable `causation_id` and can move hot → cold or cold → hot.
- Descendants query hot events plus cold catalog rows by `causation_id`.
- Trace/workflow reconstruction merges bounded hot and cold windows, verifies every archive before use and runs the existing causal analyzer over the merged event set.
- Mixed edges include parent/child storage tiers and `resolved_in_result`.

## Integrity semantics

Cold archive bytes are never trusted without the archive SHA-256 check. If a catalogued batch is missing, corrupt or does not contain an expected event, correlation does not silently omit the evidence and call the trace complete. It returns a partial history with bounded failure codes and `cold_history_complete=false`.

Privacy-projected archives may have `canonical_checksum_verified=false` while still having `archive_verified=true`; causal identity fields are protected from privacy overlays and remain usable for reconstruction.

## Rewind receipts

Receipts include:

- total event count
- hot event count
- cold event count
- `storage_tier` = `hot`, `cold` or `mixed`
- `cold_history_complete`
- cold failure count

This allows Rewind to distinguish a complete mixed-tier history from a best-effort partial reconstruction.

## Intentional no-archive pruning

Retention classes with `archiveRequired=false` intentionally remove recoverable event content. Signal does not create a fake cold event for these classes. If surviving events reference such a pruned parent, the normal analyzer reports missing causation/incomplete history. This preserves honesty about what can and cannot be rewound.
