<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;

final class CrmOptimisticConcurrencyGuard
{
    public function __construct(
        private readonly ConnectionInterface $db,
        private readonly CrmCompanyScope $scope,
        private readonly CrmCapabilityResourceMap $resources,
    ) {}

    /** @return array<string,mixed>|null */
    public function snapshot(string $capability,array $input): ?array
    {
        $target=$this->resources->before($capability,$input);
        if($target===null||!$this->tableReady($target['table']))return null;
        $row=$this->db->table($target['table'])->where('company_id',$this->scope->current()->companyId)
            ->where('public_id',$target['public_id'])->when($this->hasColumn($target['table'],'deleted_at'),fn($q)=>$q->whereNull('deleted_at'))
            ->lockForUpdate()->first();
        if(!$row)return null;
        $state=(array)$row;$version=(int)($state['entity_version']??1);$hash=$this->hash($state);
        $expectedVersion=$input['expected_entity_version']??$input['expected_version']??$input['_context']['expected_entity_version']??$input['_context']['expected_version']??null;
        if($expectedVersion!==null && (int)$expectedVersion!==$version){
            throw new CrmConcurrencyException((int)$expectedVersion,$version,$hash,true,'Fetch the latest CRM state, review the changed fields, and retry using current_version.');
        }
        return $target+['entity_version'=>$version,'state_hash'=>$hash,'state'=>$state];
    }

    /** @return array<string,mixed>|null */
    public function advance(string $capability,array $input,array $result,?array $before): ?array
    {
        $target=$this->resources->after($capability,$input,$result,$before);
        if($target===null||!$this->tableReady($target['table']))return null;
        if($before!==null && $this->hasColumn($target['table'],'entity_version')){
            $current=(int)($before['entity_version']??1);
            $updated=$this->db->table($target['table'])->where('company_id',$this->scope->current()->companyId)
                ->where('public_id',$target['public_id'])->where('entity_version',$current)->update(['entity_version'=>$current+1]);
            if($updated!==1){
                $latest=$this->db->table($target['table'])->where('company_id',$this->scope->current()->companyId)->where('public_id',$target['public_id'])->first();
                $state=$latest?(array)$latest:[];$latestVersion=(int)($state['entity_version']??$current);
                throw new CrmConcurrencyException($current,$latestVersion,$state!==[]?$this->hash($state):null,true,'Reload the latest entity state before retrying the mutation.');
            }
        }
        $row=$this->db->table($target['table'])->where('company_id',$this->scope->current()->companyId)
            ->where('public_id',$target['public_id'])->when($this->hasColumn($target['table'],'deleted_at'),fn($q)=>$q->whereNull('deleted_at'))->first();
        if(!$row)return null;
        $state=(array)$row;
        return $target+['entity_version'=>(int)($state['entity_version']??1),'state_hash'=>$this->hash($state),'state'=>$state];
    }

    private function tableReady(string $table): bool
    { try{return $this->db->getSchemaBuilder()->hasTable($table)&&$this->hasColumn($table,'company_id')&&$this->hasColumn($table,'public_id');}catch(\Throwable){return false;} }
    private function hasColumn(string $table,string $column): bool
    { try{return $this->db->getSchemaBuilder()->hasColumn($table,$column);}catch(\Throwable){return false;} }
    private function hash(array $state): string
    { ksort($state);return hash('sha256',json_encode($state,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)); }
}
