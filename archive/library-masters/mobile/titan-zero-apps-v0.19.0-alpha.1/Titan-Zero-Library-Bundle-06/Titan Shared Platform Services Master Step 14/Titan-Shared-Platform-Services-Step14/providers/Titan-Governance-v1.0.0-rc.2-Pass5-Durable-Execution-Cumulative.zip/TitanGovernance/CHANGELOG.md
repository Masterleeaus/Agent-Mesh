# Changelog

## 1.0.0-rc.2 H3 — MagicAI Menu Navigation

- Adds a synchronous self-healing parent/child Governance menu registrar compatible with MagicAI Installer 1.7.6 host navigation.
- Adds visible child links for Overview, Control Centre, Escalations, Signal Heatmap, Operational Pressure, Circuit Breakers and Workforce Oversight.
- Uses Tabler icons and exact `MenuContributionRegistry` detection with a `menus` table fallback.
- Adds browser pages for read-plane and escalation routes while preserving JSON API responses.
- Adds a unique Overview route and parent/child `parent_id` repair for legacy menu tables.
- No migrations or governance mutation semantics changed.

## 1.0.0-rc.1 H2 — Installer 1.7.6 MySQL Migration Restartability

- Fixes live MySQL error 1059 caused by Laravel's 65-character implicit index name for `authoritative_receipt_ref`.
- Uses short explicit index names for every index introduced by migration 000004.
- Guards each index/unique creation with `Schema::hasIndex(...)` so retry is safe after partial MySQL DDL.
- Hardens `down()` to remove only columns/indexes that actually exist.
- Adds Governance-specific fresh-install checks for MySQL identifier safety and 000004 restartability.
- Preserves migrations 000001–000003 byte-for-byte and adds no fifth migration.

## 1.0.0-rc.1 H1 — Installer 1.7.6 Dependency Compatibility

- Reclassifies `titan-signal >=0.2.0` and `titan-command-bus >=0.2.0-alpha.1` as optional installer peers so their absence does not block package validation/installation.
- Preserves both peers as runtime-required in the canonical sidecar/config; Governance remains DEGRADED and consequential command dispatch fails closed until trusted adapters are bound.
- Keeps `titan-autonomy >=0.1` as the hard installer dependency because Titan Autonomy remains the authority source.
- Adds a permanent regression for the live `Unsatisfied extension dependencies` Installer 1.7.6 failure.

## 1.0.0-rc.1 — Pass 8 Final Convergence & Installer 1.7.6 Compatibility
- Restored live Installer 1.7.6 root manifest fields: name/type/description/support_telegram.
- Added dual-host manifest, fresh-install, upgrade, provider-boot and exact-host preflights.
- Added final route/menu/permission/capability/dependency/migration/performance/trace inventories and operator runbooks.
- Added no migration and no new business mutation.

## 0.7.0 — Pass 6 Governance Control Centre
- Added deterministic Needs Attention ranking across model, policy, control, exception, engine, authority, freshness, pressure, circuit and escalation evidence.
- Added cross-engine health scorecard and model/Model Council health projection.
- Added policy-version drift, compliance-control state and exception-expiry projection.
- Added authority-contraction explanations that preserve Autonomy source values and cannot raise authority.
- Added explicit evidence freshness classification and fail-visible source identity/availability handling.
- Added authenticated read-only `governance.control-centre.read` endpoint and dashboard cockpit.
- Added Pass 6 RED/GREEN contract, wiring and release regression suites.

## 0.5.0
- Added tenant-scoped Governance Escalation Queue ordered by risk, urgency and age.
- Added Command-Bus-only APPROVE, REJECT, HOLD, EXCEPTION and ESCALATE actions.
- Added server-owned tenant/actor/causal context and rejection of client authority injection.
- Added semantic idempotency hashing that deliberately excludes fresh transport trace IDs and canonicalizes reason/evidence ordering.
- Added durable tenant + operation ID collision protection and retry-safe transient Command Bus redispatch.
- Added truthful command receipt validation and authoritative receipt/write-verification requirements for APPLIED results.
- Added optimistic escalation versioning and Governance-owned Command Bus target.
- Added action permissions, CSRF-safe POST routes and 30/minute action throttling.
- Added actual Governance→Command Bus gateway readiness to health output.
- Fixed strict-types tenant resolver to return canonical integer company scope.
- Added Pass 4 action, persistence, queue, wiring and release regression suites.

## 0.4.0
- Added Signal Heatmap and normalized recent Signal projection.
- Added deterministic operational-pressure/bottleneck detection with explicit reason codes.
- Added circuit-breaker visibility.
- Added durable, deduplicated Governance projection history using the existing projection/cache table.
- Added source-health history and recent incident-rate summary.
- Added authenticated read endpoints for Signal intelligence and history.
- Added `titan:titan-governance:refresh-projections --tenant=<id>`.
- Added projection persistence failure isolation; live reads remain independent.
- Added Pass 3 RED/GREEN regression tests and Blueprint v4.2 capability contracts.

## 0.3.0
- Added the tenant-scoped Governance Read Plane.
- Added explicit read-source contract/registry and fail-closed source adapter loading.
- Added live Titan Autonomy Trust Map projection with canonical continuous authority bands.
- Added source-order/range integrity detection without rewriting authoritative Autonomy values.
- Added structured autonomy evidence projection with hidden reasoning excluded.
- Added source staleness and required/optional health aggregation.
- Added Trust Map, evidence and source-health dashboard rendering.
- Added `governance.trust-map.read`, `governance.autonomy-evidence.read` and `governance.source-health.read` capability contracts.
- Added standalone RED/GREEN contract tests for the read plane.
- Removed the inherited raw-DB menu fallback warning by isolating legacy MagicAI menu persistence behind a dedicated host compatibility model.

## 0.2.0
- Rebased package onto Titan Extension Blueprint v4.2.0 and Installer 1.7.8.
- Flat-root package, root `titan-extension-v1` manifest and Manifest v2.2.
- Canonical `governance-engine` / `governance-control-plane` ownership.
- Added four-ID causal context, upper-bound Governance constraint factory and versioned control-plane definitions.
- Added host-compatible authorization, navigation, health and certification command.
- Added additive Governance policy/constraint/escalation persistence and projection hardening.
- Replaced `<x-layouts.app>` with MagicAI panel layout views.

## 0.6.0 — Pass 5 Decision Intelligence

- Added Decision Timeline, Delta Viewer, Policy & Compliance aggregation and Rewind Theater bridge.
- Added a separate decision-evidence adapter registry and recursive sensitive-evidence sanitizer.
- Added recent decision navigation and detailed decision evidence UI.
- Added four read-only capability contracts for decision intelligence.
- Hardened tenant resolution so Governance never fabricates tenant IDs from user/team identities.

## 0.8.0 — Pass 7 Human Oversight + Workforce Operating View
- Added read-only Titan AI Workforce operating projection and human oversight view.
- Added deterministic approval/handoff ageing, operator workload and intervention history.
- Added Workforce attention drill-down metadata.
- Explicitly prevents hierarchy, maturity and performance from increasing Autonomy.

## Workforce Runtime Integration Pass 2 — 2026-08-22
- Added deterministic runtime discovery/provider fingerprint contract.
- Added fail-closed request/decision/response envelopes, idempotency, audit and health semantics.
- Added executable runtime descriptor regression coverage without granting authority on registration.
