# Authorization Matrix

- Tenant user: read/analyse own tenant evidence when permission granted.
- Reviewer: review evidence/annotations within the same tenant.
- Route: creates proposal/workflow request only.
- Admin: diagnostics/configuration only.
- No role may use Vision inference as authority to mutate another domain directly.
