<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\InteractionEngine\System\Authority\CapabilityPolicy;
use App\Extensions\InteractionEngine\System\Authority\DelegatedAuthorityDecision;
use App\Extensions\InteractionEngine\System\Contracts\DelegatedAuthorityVerifierInterface;
use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Services\DelegatedAuthorityEnvelopeService;
use App\Extensions\TitanAutonomy\System\Services\GateReviewService;

final class InteractionDelegatedAuthorityVerifier implements DelegatedAuthorityVerifierInterface
{
    private const LEVELS = ['suggest'=>0,'assist'=>1,'semi_auto'=>2,'auto'=>3,'trusted_auto'=>4];

    public function __construct(
        private readonly DelegatedAuthorityEnvelopeService $tokens,
        private readonly AutonomyQueryContract $query,
        private readonly GateReviewService $gateReview,
        private readonly HostContextBridgeContract $host,
    ) {}

    public function verify(string $capability, array $payload, CapabilityPolicy $policy): DelegatedAuthorityDecision
    {
        if (property_exists($policy, 'delegatedAuthorityAllowed') && !$policy->delegatedAuthorityAllowed) {
            return DelegatedAuthorityDecision::deny('DELEGATED_AUTHORITY_NOT_PERMITTED');
        }

        $claims = $this->tokens->verify((array) ($payload['_delegated_authority'] ?? []));
        if ($claims === null) return DelegatedAuthorityDecision::deny('DELEGATED_AUTHORITY_SIGNATURE_INVALID');

        $context = (array) ($payload['_context'] ?? []);
        $tenantCompanyId = $this->host->tenantCompanyId();
        $workflowKey = (string) ($claims['workflow_key'] ?? '');
        $checks = [
            [(int) ($claims['tenant_company_id'] ?? 0) === $tenantCompanyId, 'DELEGATED_TENANT_MISMATCH'],
            [(string) ($context['company_id'] ?? '') === (string) $tenantCompanyId, 'DELEGATED_CONTEXT_TENANT_MISMATCH'],
            [!isset($context['tenant_id']) || (string) $context['tenant_id'] === (string) $tenantCompanyId, 'DELEGATED_LEGACY_TENANT_MISMATCH'],
            [(string) ($claims['capability'] ?? '') === $capability, 'DELEGATED_CAPABILITY_MISMATCH'],
            [(string) ($context['autonomy_workflow_key'] ?? '') === $workflowKey, 'DELEGATED_WORKFLOW_MISMATCH'],
            [(string) ($context['session_id'] ?? '') === (string) ($claims['session_id'] ?? ''), 'DELEGATED_SESSION_MISMATCH'],
            [(string) ($context['correlation_id'] ?? '') === (string) ($claims['correlation_id'] ?? ''), 'DELEGATED_CORRELATION_MISMATCH'],
        ];
        $claimInteraction = trim((string) ($claims['interaction_id'] ?? ''));
        if ($claimInteraction !== '') {
            $checks[] = [(string) ($context['interaction_id'] ?? '') === $claimInteraction, 'DELEGATED_INTERACTION_MISMATCH'];
        }
        foreach ($checks as [$ok, $reason]) if (!$ok) return DelegatedAuthorityDecision::deny($reason);

        $row = $this->query->capabilityState($tenantCompanyId, $capability, $workflowKey);
        if ($row === null) return DelegatedAuthorityDecision::deny('DELEGATED_CAPABILITY_STATE_NOT_FOUND');
        $level = (string) ($row['current_level'] ?? 'suggest');
        if (!in_array($level, ['auto','trusted_auto'], true)) return DelegatedAuthorityDecision::deny('DELEGATED_LEVEL_NOT_ACTIVE');
        if ($level !== (string) ($claims['autonomy_level'] ?? '')) return DelegatedAuthorityDecision::deny('DELEGATED_LEVEL_CHANGED');

        $scope = is_array($row['scope'] ?? null) ? $row['scope'] : [];
        if ($scope === [] || $this->tokens->scopeHash($scope) !== (string) ($claims['scope_hash'] ?? '')) {
            return DelegatedAuthorityDecision::deny('DELEGATED_SCOPE_CHANGED');
        }

        $effectivePolicy = $this->gateReview->effectivePolicyForTenant($tenantCompanyId);
        if ($this->tokens->policyFingerprint($effectivePolicy) !== (string) ($claims['policy_fingerprint'] ?? '')) {
            return DelegatedAuthorityDecision::deny('DELEGATED_POLICY_CHANGED');
        }
        $risk = (string) ($row['risk'] ?? 'critical');
        $ceiling = (string) (($effectivePolicy['maximum_level_by_risk'][$risk] ?? 'assist'));
        if ((self::LEVELS[$level] ?? 99) > (self::LEVELS[$ceiling] ?? 1)) {
            return DelegatedAuthorityDecision::deny('DELEGATED_POLICY_CEILING_EXCEEDED');
        }

        if ($level === 'trusted_auto' && !$this->trustedHandshakeStillValid($tenantCompanyId, $capability, $workflowKey, $scope)) {
            return DelegatedAuthorityDecision::deny('DELEGATED_TRUSTED_AUTO_HANDSHAKE_INVALID');
        }

        return DelegatedAuthorityDecision::allow(
            grantId: (string) $claims['grant_id'],
            autonomyLevel: $level,
            grantedScopes: array_values(array_filter((array) ($claims['granted_scopes'] ?? []), 'is_string')),
            metadata: [
                'workflow_key' => $workflowKey,
                'policy_version' => $this->tokens->policyVersion(),
                'session_id' => (string) $claims['session_id'],
                'correlation_id' => (string) $claims['correlation_id'],
            ],
        );
    }

    private function trustedHandshakeStillValid(int $tenantCompanyId, string $capability, string $workflowKey, array $scope): bool
    {
        foreach ($this->query->handshakes($tenantCompanyId, $capability, $workflowKey, 25) as $handshake) {
            if ((string) ($handshake['requested_level'] ?? '') !== 'trusted_auto') continue;
            if ((string) ($handshake['platform_decision'] ?? '') !== 'approved') continue;
            if ((string) ($handshake['user_decision'] ?? '') !== 'approved') continue;
            if ((string) ($handshake['ai_decision'] ?? '') !== 'approved') continue;
            if ((string) ($handshake['final_decision'] ?? '') !== 'approved') continue;
            if ((string) ($handshake['policy_version'] ?? '') !== $this->tokens->policyVersion()) continue;
            $requestedScope = is_array($handshake['requested_scope'] ?? null) ? $handshake['requested_scope'] : [];
            if ($this->tokens->scopeHash($requestedScope) !== $this->tokens->scopeHash($scope)) continue;
            return true;
        }
        return false;
    }
}
