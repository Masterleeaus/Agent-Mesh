<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

enum SemanticChangeDisposition: string
{
    case Apply = 'apply';
    case RequiresApproval = 'requires_approval';
    case Blocked = 'blocked';
}
