<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Contracts;

use App\Extensions\TitanCommandBus\System\DTO\AssuranceDecision;
use App\Extensions\TitanCommandBus\System\DTO\AutonomyDecision;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use App\Extensions\TitanCommandBus\System\DTO\GovernanceDecision;
use App\Extensions\TitanCommandBus\System\DTO\RiskDecision;

interface CommandGovernanceGateContract
{
    public function available(): bool;
    public function evaluate(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null, ?AssuranceDecision $assurance = null, ?AutonomyDecision $autonomy = null): GovernanceDecision;
}
