# Business Configuration Capabilities

## Status
**IMPLEMENTED service/capability layer; Titan Onboarding PWA NOT IMPLEMENTED.**

Governed capabilities cover business profile, hours, services, locations, service areas, booking rules, pricing, staff invitation/role handoff, field rules, notification defaults and invoice settings.

`ConfigurationDraftService` supports:

```text
conversational/onboarding answers
  -> draft configuration
  -> validation
  -> preview
  -> explicit approval
  -> CRM capability/domain service
  -> authoritative CRM materialisation
```

Onboarding callers do not need table names. Business hours support day, multiple windows, closed days, explicit IANA timezone, holiday behavior, after-hours and emergency availability. The generic model does not hard-code Australia.

Service catalogue records support category/name/description/active/default duration/pricing strategy/tax behavior/booking availability/required skills/field requirements/evidence requirements/form references/emergency flag/recurring eligibility without embedding vertical-specific logic in the generic model.
