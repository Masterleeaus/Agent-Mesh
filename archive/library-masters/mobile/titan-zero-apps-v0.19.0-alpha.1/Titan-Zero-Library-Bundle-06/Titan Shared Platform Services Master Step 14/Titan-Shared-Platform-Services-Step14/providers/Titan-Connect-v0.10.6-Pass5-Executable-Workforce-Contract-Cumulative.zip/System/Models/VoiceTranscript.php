<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class VoiceTranscript extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use HasUuids;

    protected $table = 'ext_titan_connect_voice_transcripts';
    protected $fillable = ['uuid', 'company_id', 'voice_call_id', 'client_event_id', 'role', 'message', 'spoken_at', 'metadata'];
    protected $casts = ['spoken_at' => 'datetime', 'metadata' => 'array'];

    public function uniqueIds(): array { return ['uuid']; }
    public function call(): BelongsTo { return $this->belongsTo(VoiceCall::class, 'voice_call_id'); }
    public function getRouteKeyName(): string { return 'uuid'; }

}
