# Titan Governance v1.0.0-rc.1

> **Installer 1.7.6 H2 compatibility:** H1 keeps Titan Signal/Command Bus non-blocking at install time; H2 repairs the live MySQL 1059 failure in migration 000004 with short explicit index names and restart-safe partial-DDL guards. Missing runtime peers still degrade/fail closed.

Final Governance control-plane release candidate. Root manifest is intentionally compatible with the observed MagicAI Installer 1.7.6 legacy-field validation while the canonical architectural contract remains Manifest v2.2. See `PASS8-FINAL-CONVERGENCE-REPORT.md` and `release/OPERATOR-RUNBOOK.md`.


Titan Governance is Titan's canonical `governance-control-plane` owner. It owns versioned governance policy decisions, upper-bound authority constraints, escalation state and Governance projections. Titan Command Bus remains the only cross-domain mutation path; Governance never directly mutates CRM, Autonomy, Risk, Assurance, Workforce or other foreign business state.

## Pass 4 — implemented

- Everything from v0.4.0 Signal Intelligence & Durable Projections.
- Tenant-scoped escalation queue ordered by risk descending, urgency descending, then oldest first.
- Human governance actions: `APPROVE`, `REJECT`, `HOLD`, `EXCEPTION`, and `ESCALATE`.
- Server-owned tenant, actor and causal identity. Client attempts to supply trusted identity fields are rejected.
- Durable `tenant_company_id + operation_id` idempotency with semantic SHA-256 payload identity.
- Retry-safe transient Command Bus failures: the same operation may redispatch after a transport/unavailable failure without minting a second Governance decision.
- Conflicting reuse of an operation ID is rejected.
- Command Bus is the only outbound action path and ships fail-closed until a real host bridge is bound.
- Truthful Command Bus receipt normalization. `APPLIED` requires Governance decision echo, Command Bus receipt, authoritative domain receipt, adapter identity and `write_verified=true`.
- Governance-owned escalation target supports optimistic version checks and can only be invoked through the Command Bus integration boundary.
- Explicit permissions for queue viewing, governed actions and exceptions.
- CSRF-protected web actions plus `30/minute` action-route throttling.
- Governance health reports both installed Command Bus dependency state and actual Governance→Command Bus gateway readiness.
- Fixed inherited strict-types tenant resolution so the canonical company boundary is returned as `int`.

## Host integration required for live actions

Set `TITAN_GOVERNANCE_COMMAND_GATEWAY_CLASS` to a host class implementing:

`App\\Extensions\\TitanGovernance\\System\\Contracts\\GovernanceCommandGatewayContract`

That adapter must dispatch through the installed Titan Command Bus public execution API. The host Command Bus/domain registry must also expose `GovernanceEscalationTarget` as the implementation for the `governance.escalation.*` capabilities. Do not bind the gateway to a direct controller/service mutation path.

If no valid bridge is bound, governed actions fail closed with `COMMAND_BUS_UNAVAILABLE` and escalation state is unchanged.

See `docs/INTEGRATION-CONTRACTS.md`, `docs/GOVERNANCE.md`, `docs/AUTHORIZATION-MATRIX.md`, and `PASS4-GOVERNED-ACTIONS-REPORT.md`.

## v0.6.0 Decision Intelligence

Governance can now inspect a tenant-scoped decision as a structured evidence chain. `GovernanceDecisionEvidenceSourceContract` adapters supply bounded peer-engine evidence for the Decision Timeline, Policy & Compliance view and Rewind Theater. The Delta Viewer compares Governance-owned decision records without asserting causality. Raw prompts, hidden reasoning, credentials, tokens and provider raw responses are removed at the evidence boundary.

Configure historical evidence adapters with `TITAN_GOVERNANCE_COMMAND_BUS_EVIDENCE_CLASS`, `TITAN_GOVERNANCE_AUTONOMY_EVIDENCE_CLASS`, `TITAN_GOVERNANCE_SIGNAL_EVIDENCE_CLASS`, and the optional peer evidence class settings in `config/titan-governance.php`. Unbound adapters remain explicitly unavailable; Governance does not fabricate evidence.
## v0.7.0 Pass 6 — Governance Control Centre

The tenant Governance dashboard now includes a deterministic Needs Attention queue, cross-engine health scorecard, model transition and Model Council disagreement health, policy/compliance drift, exception expiry, evidence freshness, and authority-contraction explanations. All peer-engine state remains read-only and adapter-supplied; Governance never raises Titan Autonomy authority.

Configure adapter classes under `read_sources` in `config/titan-governance.php`. Sources may optionally expose a structured `control_centre` overlay containing `models`, `council`, `policies`, `controls`, and `authority_constraints`. Unknown/raw provider payloads are not required or rendered.

See `PASS6-CONTROL-CENTRE-REPORT.md`.


## v0.8.0 — Human Oversight & Workforce
The Governance Control Centre can consume the optional Titan AI Workforce read adapter and surface organisation state, manager queues, waiting approvals, handoffs, operator workload and Workforce-linked Governance interventions. This is a read projection only: Titan AI Workforce owns Workforce state and Titan Autonomy owns authority.

## v1.0.0-rc.2 H3 — MagicAI navigation

H3 repairs live MagicAI/Titan Extension Manager 1.7.6 navigation after the H2 package installed without menu links. Governance now contributes a Titan Governance parent with Overview, Control Centre, Escalations, Signal Heatmap, Operational Pressure, Circuit Breakers and Workforce Oversight children. Legacy host menu rows self-heal synchronously at provider boot; normal browser requests render Blade pages while JSON clients retain the read APIs.
