# Titan CRM Governed Business OS Boundary — Design

## Goal

Upgrade the existing MagicAI CRM extension in place so CRM remains Titan's authoritative operational source of truth while all AI-originated mutations are requested through Titan Command Bus and all consequential CRM mutations produce traceable, idempotent, reconstructable receipts and domain signals.

## Existing system preserved

The current extension already contains mature CRM, field-service, scheduling, sales, invoice/payment, bookkeeping, Pay, Locker, mobile, Interaction Engine, Chatbot, TitanAI, installer, migration, UI and tenancy code. Those implementations remain authoritative domain services. The upgrade adds adapters and contracts around them rather than replacing them.

## Approaches considered

1. **Destructive rewrite around new Titan engines** — rejected. It would duplicate existing domain logic, create migration risk and violate the requirement to preserve working code.
2. **Keep current CRM and merely document external governance** — rejected. The legacy AI assistant would still mutate CRM directly and capability contracts would remain incomplete.
3. **Adapter-first governed boundary (selected)** — preserve existing domain services, strengthen the capability layer, add a Command Bus port, transactional signal/receipt records, optimistic concurrency and normalized AI read models. Existing human UI remains compatible while AI paths no longer bypass governance.

## Architecture

### 1. Authoritative CRM domain

Existing repositories and domain services continue to own customers, leads, organizations, jobs/work orders, services, quotes, appointments, invoices, payments, assets, scheduling and operational state. `tenant_company_id` remains the canonical tenant boundary; `company_id` continues to mean CRM customer/account company and `user_id` remains actor/legacy ownership metadata.

### 2. Governed capability adapter

`CrmCapabilityManifest` remains the machine-readable inventory of actual CRM operations. Every returned capability definition is enriched with:

- capability name
- owning extension
- input/output contract
- risk profile
- autonomy requirement
- evidence requirements
- offline policy
- reversibility
- idempotency strategy
- concurrency policy

The final capability list continues to be derived from functionality that already exists in this extension.

### 3. Command Bus boundary

A CRM-owned `CrmCommandBusPort` contract is introduced. CRM does not implement Titan-wide risk/autonomy/assurance reasoning. The default bridge can preserve trusted human/local compatibility, but AI-originated mutations are not executed locally when an external Command Bus adapter is absent; they are returned as structured pending command requests instead.

Legacy CRM assistant mutation tools are changed to request commands through this boundary rather than calling repositories directly. Read-only assistant tools remain unchanged.

### 4. Trace context

`CrmCompanyContext` carries `trace_id`, `correlation_id` and `causation_id`. These identifiers flow through capability operations, receipts, signal records and Rewind references.

### 5. Invariants and optimistic concurrency

Important mutable entities receive an additive `entity_version` column. Governed updates targeting an existing entity can supply `expected_version`; stale versions are rejected before mutation. Successful governed writes atomically advance the version.

A focused invariant guard prevents impossible high-value states at the capability boundary, while existing domain-specific status policies remain the primary lifecycle rules.

### 6. Command receipts and Rewind references

Every successful governed write returns an authoritative receipt containing tenant, capability, command/receipt IDs, trace IDs, resource reference, before/after version and state hashes. The operation ledger stores the same receipt so idempotent replay returns the original authoritative outcome rather than re-running the mutation.

Rewind data is structured metadata only; unrestricted hidden reasoning is never persisted.

### 7. Titan Signal outbox

A transactional CRM domain-signal outbox is introduced. Every successful governed mutation writes a structured event in the same database transaction as the mutation/receipt. This prevents invisible state changes and allows Titan Signal to consume events without coupling CRM to a specific Signal implementation.

### 8. AI read models

A normalized read-model service exposes selected authoritative operational context for AI/Workforce consumers. It strips internal tenancy/user ownership fields, reports `entity_version`, and returns bounded normalized context rather than exposing raw unrestricted table access.

### 9. Compatibility and installer safety

All schema changes are additive. Existing routes, views, providers, domain services and menu behavior are preserved. Legacy autonomy code is retained for compatibility but is no longer treated as the authoritative Titan autonomy decision layer for the new governed command path.

## Error handling

- Missing tenant context: fail closed.
- Missing idempotency key on governed writes: reject.
- Reused idempotency key with different payload: reject.
- Stale `expected_version`: reject with deterministic conflict details.
- Invalid lifecycle/invariant: reject before authoritative mutation.
- External Command Bus unavailable for AI-originated mutation: return a structured pending request; do not mutate CRM.
- Signal delivery unavailable: mutation still records the durable transactional outbox event for later dispatch.

## Testing

Static verification scripts will assert the new contracts, migration safety and removal of direct legacy assistant writes. PHP lint will run across all PHP files. Existing CRM verification scripts will run to detect regressions. The distributable zip will be regenerated with updated SHA-256 inventory.
