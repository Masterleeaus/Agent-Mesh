<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\Crm\System\AI\CrmAssistantChatService as LegacyCrmAssistantChatService;
use App\Extensions\Crm\System\Listeners\ContactCapturedListener;
use App\Extensions\Crm\System\Security\CrmPermissionService;
use App\Extensions\Crm\System\Automation\{CrmAutomationActionCatalog, CrmAutomationConditionEvaluator, CrmAutomationEngine, CrmAutomationScheduler, CrmAutomationTriggerCatalog};
use App\Extensions\Crm\System\Portal\{CrmPortalFileScanner, NullCrmPortalFileScanner, CrmPortalFileService, CrmPortalGrantService, CrmPortalScopeCatalog};
use App\Extensions\Crm\System\Import\{CrmCsvImportService, CrmImportBatchService, CrmImportMapper, CrmImportTransformRegistry, CrmImportRelationshipValidator};
use App\Extensions\Crm\System\Integrations\{CrmApiKeyService, CrmEmailLinker, CrmEmailSyncService, CrmOutboundUrlPolicy, CrmWebhookDispatcher, CrmWebhookService};
use App\Extensions\Crm\System\Integrations\Chatbot\{CrmChatbotCompatibility, CrmChatbotIdentityService, CrmChatbotIntegrationRegistrar, CrmChatbotSessionGrantService, CrmChatbotSettingsService, CrmChatbotToolPolicy, CrmChatbotToolService};
use App\Extensions\Crm\System\Integrations\TitanMobile\{CrmMobileIdentityResolver, CrmTitanMobileIntegrationRegistrar};
use App\Extensions\Crm\System\Privacy\{CrmPrivacyService, CrmRetentionService};
use App\Extensions\Crm\System\Sharing\{CrmRecordShareService, CrmSharedRecordAccessService};
use App\Extensions\Crm\System\AI\{CrmAssistantContextBuilder, CrmRecordReferenceResolver};
use App\Extensions\Crm\System\Console\{AuditCrmCompanyTenancyCommand, RunCrmAutomationsCommand, RetryCrmWebhooksCommand, RunCrmRetentionCommand, DeliverCrmOutboundEffectsCommand, DeliverCrmDomainSignalsCommand, RebuildCrmReadProjectionsCommand, CheckCrmProductionReadinessCommand, RenderCrmSalesDocumentsCommand, AuditCrmWriteSurfacesCommand, ReplayCrmProjectionDeadLettersCommand, CrmSearchCommand, CrmDoctorCommand, CrmMetricsCommand, CrmPerformanceCertifyCommand, CrmRebuildProjectionSearchIndexCommand};
use App\Extensions\Crm\System\Providers\{CrmTenantServiceProvider,CrmCapabilityServiceProvider,CrmCoreDomainServiceProvider,CrmExternalDomainCompatibilityProvider,CrmTitanIntegrationServiceProvider};
use App\Extensions\Crm\System\Automation\Events\CrmAutomationTriggered;
use App\Extensions\Crm\System\Automation\Listeners\RunCrmAutomationTrigger;
use App\Extensions\Crm\System\Services\CrmOperationalMetricsService;
use App\Extensions\Crm\System\Services\CrmAssistantChatService;
use App\Extensions\Crm\System\Contracts\{
    ActivityRepositoryContract,
    CompanyRepositoryContract,
    ContactRepositoryContract,
    CrmAssistantChatServiceContract,
    DealRepositoryContract,
    LeadRepositoryContract,
    PipelineRepositoryContract,
    ProjectRepositoryContract,
    TaskRepositoryContract,
    CalendarRepositoryContract,
    SalesDocumentRepositoryContract,
    NoteRepositoryContract,
    TagRepositoryContract,
    CustomFieldRepositoryContract
};
use App\Extensions\Crm\System\Repositories\{
    EloquentActivityRepository,
    EloquentCompanyRepository,
    EloquentContactRepository,
    EloquentDealRepository,
    EloquentLeadRepository,
    EloquentPipelineRepository,
    EloquentProjectRepository,
    EloquentTaskRepository,
    EloquentCalendarRepository,
    EloquentSalesDocumentRepository,
    EloquentNoteRepository,
    EloquentTagRepository,
    EloquentCustomFieldRepository
};
use App\Extensions\Crm\System\Services\{
    CrmActivityRecorder,
    CrmDuplicateDetector,
    CrmSubjectReferenceValidator,
    DefaultSalesPipelineProvisioner,
    LeadLifecycleService,
    CrmDashboardService,
    CrmTimelineService,
    SalesDocumentLifecycleService,
    SalesTotalsCalculator,
    CrmViewDataService,
    CrmPresentationService,
    CrmSettingsService,
    CrmAuditRecorder,
    LeadQualificationService,
    CrmNotificationOutboxService,
    CrmAnalyticsService,
    CrmBulkActionService,
    CrmMergeService,
    CrmHostSettingsService,
    CrmNotificationDeliveryService,
    SalesDocumentPdfService,
    SalesDocumentDeliveryService,
    SalesDocumentContractSnapshotService,
    SalesDocumentRevisionService,
    SalesDocumentRenderQueueService,
    CrmDuplicateScoreService,
    CrmIdentityAuthorityService,
    CrmDuplicateReviewService,
    CrmProductionHealthService,
    CrmInvoiceSettlementReferenceService,
    CrmCreditNoteService,
    CrmReceivablesService,
    CrmPerformanceAuditService
};
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

final class CrmServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/crm.php', 'crm');
        if (! (bool) config('crm.enabled', true)) {
            return;
        }

        $this->app->bind(CompanyRepositoryContract::class, EloquentCompanyRepository::class);
        $this->app->bind(ContactRepositoryContract::class, EloquentContactRepository::class);
        $this->app->bind(LeadRepositoryContract::class, EloquentLeadRepository::class);
        $this->app->bind(DealRepositoryContract::class, EloquentDealRepository::class);
        $this->app->bind(PipelineRepositoryContract::class, EloquentPipelineRepository::class);
        $this->app->bind(ActivityRepositoryContract::class, EloquentActivityRepository::class);
        $this->app->bind(ProjectRepositoryContract::class, EloquentProjectRepository::class);
        $this->app->bind(TaskRepositoryContract::class, EloquentTaskRepository::class);
        $this->app->bind(CalendarRepositoryContract::class, EloquentCalendarRepository::class);
        $this->app->bind(SalesDocumentRepositoryContract::class, EloquentSalesDocumentRepository::class);
        $this->app->bind(NoteRepositoryContract::class, EloquentNoteRepository::class);
        $this->app->bind(TagRepositoryContract::class, EloquentTagRepository::class);
        $this->app->bind(CustomFieldRepositoryContract::class, EloquentCustomFieldRepository::class);


        $this->app->singleton(CrmDuplicateDetector::class);
        $this->app->singleton(CrmActivityRecorder::class);
        $this->app->singleton(CrmSubjectReferenceValidator::class);
        $this->app->singleton(DefaultSalesPipelineProvisioner::class);
        $this->app->singleton(LeadLifecycleService::class);
        $this->app->singleton(CrmDashboardService::class);
        $this->app->singleton(CrmTimelineService::class);
        $this->app->singleton(SalesDocumentLifecycleService::class);
        $this->app->singleton(SalesTotalsCalculator::class);
        $this->app->singleton(CrmViewDataService::class);
        $this->app->singleton(CrmPresentationService::class);
        $this->app->singleton(CrmSettingsService::class);
        $this->app->singleton(CrmAuditRecorder::class);
        $this->app->singleton(LeadQualificationService::class);
        $this->app->singleton(CrmNotificationOutboxService::class);
        $this->app->singleton(CrmAnalyticsService::class);
        $this->app->singleton(CrmBulkActionService::class);
        $this->app->singleton(CrmMergeService::class);
        $this->app->singleton(CrmHostSettingsService::class);
        $this->app->singleton(CrmNotificationDeliveryService::class);
        $this->app->singleton(SalesDocumentPdfService::class);
        $this->app->singleton(SalesDocumentDeliveryService::class);
        $this->app->singleton(SalesDocumentContractSnapshotService::class);
        $this->app->singleton(SalesDocumentRevisionService::class);
        $this->app->singleton(SalesDocumentRenderQueueService::class);
        $this->app->singleton(CrmInvoiceSettlementReferenceService::class);
        $this->app->singleton(CrmCreditNoteService::class);
        $this->app->singleton(CrmReceivablesService::class);
        $this->app->singleton(CrmPermissionService::class);
        $this->app->singleton(CrmAutomationTriggerCatalog::class);
        $this->app->singleton(CrmAutomationConditionEvaluator::class);
        $this->app->singleton(CrmAutomationActionCatalog::class);
        $this->app->singleton(CrmAutomationEngine::class);
        $this->app->singleton(CrmAutomationScheduler::class);
        $this->app->bind(CrmPortalFileScanner::class, NullCrmPortalFileScanner::class);
        $this->app->singleton(CrmPortalScopeCatalog::class);
        $this->app->singleton(CrmPortalGrantService::class);
        $this->app->singleton(CrmPortalFileService::class);
        $this->app->singleton(CrmImportMapper::class);
        $this->app->singleton(CrmImportBatchService::class);
        $this->app->singleton(CrmImportTransformRegistry::class);
        $this->app->singleton(CrmCsvImportService::class);
        $this->app->singleton(CrmImportRelationshipValidator::class);
        $this->app->singleton(CrmApiKeyService::class);
        $this->app->singleton(CrmOutboundUrlPolicy::class);
        $this->app->singleton(CrmWebhookService::class);
        $this->app->singleton(CrmWebhookDispatcher::class);
        $this->app->singleton(CrmEmailLinker::class);
        $this->app->singleton(CrmEmailSyncService::class);
        $this->app->singleton(CrmRecordShareService::class);
        $this->app->singleton(CrmSharedRecordAccessService::class);
        $this->app->singleton(CrmPrivacyService::class);
        $this->app->singleton(CrmRetentionService::class);
        $this->app->singleton(CrmDuplicateScoreService::class);
        $this->app->singleton(CrmIdentityAuthorityService::class);
        $this->app->singleton(CrmDuplicateReviewService::class);
        $this->app->singleton(CrmOperationalMetricsService::class);
        $this->app->singleton(CrmProductionHealthService::class);
        $this->app->singleton(CrmPerformanceAuditService::class);
        $this->app->singleton(CrmRecordReferenceResolver::class);
        $this->app->singleton(CrmAssistantContextBuilder::class);
        $this->app->singleton(CrmAssistantChatService::class);
        $this->app->singleton(CrmHumanMutationGateway::class);
        $this->app->singleton(CrmAssistantChatServiceContract::class, LegacyCrmAssistantChatService::class);

        // Register focused providers only after all root CRM contracts/services are bound.
        // Titan installs extensions into an already-booted Laravel application, so Application::register()
        // may boot these providers immediately. Keeping this block last prevents install-time dependency races.
        $this->app->register(CrmTenantServiceProvider::class);
        $this->app->register(CrmCapabilityServiceProvider::class);
        $this->app->register(CrmCoreDomainServiceProvider::class);
        $this->app->register(CrmExternalDomainCompatibilityProvider::class);
        $this->app->register(CrmTitanIntegrationServiceProvider::class);
    }

    public function boot(): void
    {
        if (! (bool) config('crm.enabled', true)) {
            return;
        }
        $this->ensureHostPanelViewFallback();
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'crm');
        $this->loadTranslationsFrom(__DIR__ . '/../resources/lang', 'crm');
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $webRoutes = __DIR__ . '/../routes/web.php';
        $apiRoutes = __DIR__ . '/../routes/api.php';
        $adminRoutes = __DIR__ . '/../routes/admin.php';
        $portalRoutes = __DIR__ . '/../routes/portal.php';

        // Use Laravel's normal package route loader first. On Titan hosts with a route cache
        // created before CRM was installed/upgraded, loadRoutesFrom() intentionally skips the
        // file. The sentinel fallback below then registers only when the cached collection is
        // missing one or more CRM route families. This keeps MagicAI navbar Route::has() checks
        // true and prevents internal route names being rendered as external/new-tab URLs.
        $this->loadRoutesFrom($webRoutes);
        $this->loadRoutesFrom($apiRoutes);
        $this->loadRoutesFrom($adminRoutes);
        $this->loadRoutesFrom($portalRoutes);
        $this->ensureRouteFileLoaded($webRoutes, ['dashboard.user.crm.companies.index', 'dashboard.user.sales.invoices.index']);
        $this->ensureRouteFileLoaded($apiRoutes, ['api.crm.dashboard']);
        $this->ensureRouteFileLoaded($adminRoutes, ['dashboard.admin.crm.settings']);
        $this->ensureRouteFileLoaded($portalRoutes, ['crm.portal.show']);
        if ($this->app->runningInConsole()) { $this->commands([AuditCrmCompanyTenancyCommand::class, RunCrmAutomationsCommand::class, RetryCrmWebhooksCommand::class, RunCrmRetentionCommand::class, DeliverCrmOutboundEffectsCommand::class, DeliverCrmDomainSignalsCommand::class, RebuildCrmReadProjectionsCommand::class, CheckCrmProductionReadinessCommand::class, RenderCrmSalesDocumentsCommand::class, AuditCrmWriteSurfacesCommand::class, ReplayCrmProjectionDeadLettersCommand::class, CrmSearchCommand::class, CrmDoctorCommand::class, CrmMetricsCommand::class, CrmPerformanceCertifyCommand::class, CrmRebuildProjectionSearchIndexCommand::class]); }
        Event::listen(CrmAutomationTriggered::class, RunCrmAutomationTrigger::class);
        if (class_exists(\App\Events\ContactCapturedEvent::class)) {
            Event::listen(\App\Events\ContactCapturedEvent::class, ContactCapturedListener::class);
        }
        $this->publishes([__DIR__ . '/../config/crm.php' => config_path('crm.php')], 'crm-config');
    }

    private function ensureHostPanelViewFallback(): void
    {
        if (! $this->app->bound('view')) {
            return;
        }

        $factory = $this->app->make('view');
        if ($factory->exists('panel.layout.app')) {
            return;
        }

        $fallbackRoot = resource_path('views/default');
        $fallbackLayout = $fallbackRoot . '/panel/layout/app.blade.php';
        if (! is_file($fallbackLayout) || ! method_exists($factory, 'getFinder')) {
            return;
        }

        $finder = $factory->getFinder();
        if (! method_exists($finder, 'addLocation')) {
            return;
        }

        $paths = method_exists($finder, 'getPaths') ? $finder->getPaths() : [];
        if (! in_array($fallbackRoot, $paths, true)) {
            $finder->addLocation($fallbackRoot);
        }
    }

    /** @param array<int,string> $sentinelRouteNames */
    private function ensureRouteFileLoaded(string $path, array $sentinelRouteNames): void
    {
        foreach ($sentinelRouteNames as $routeName) {
            if (! Route::has($routeName)) {
                require $path;
                return;
            }
        }
    }

    public function registerKey(): string
    {
        return 'crm';
    }

    public static function uninstall(): void
    {
        // CRM data is retained by default for safe upgrades/reinstalls.
    }
}
