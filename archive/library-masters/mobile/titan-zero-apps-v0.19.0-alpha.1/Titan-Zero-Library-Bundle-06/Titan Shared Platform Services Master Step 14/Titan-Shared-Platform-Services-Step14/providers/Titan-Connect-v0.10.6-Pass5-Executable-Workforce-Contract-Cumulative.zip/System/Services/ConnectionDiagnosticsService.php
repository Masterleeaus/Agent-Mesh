<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\OutboundDelivery;
use App\Extensions\TitanConnect\System\Models\ProviderCredential;
use App\Extensions\TitanConnect\System\Models\WebhookEvent;

final class ConnectionDiagnosticsService
{
    /** @return array<string,mixed> */
    public function inspect(ChannelConnection $connection): array
    {
        $companyId = (int) $connection->company_id;
        $connectionId = (int) $connection->id;
        $since = now()->subDay();

        $queuedDeliveries = OutboundDelivery::query()
            ->forCompany($companyId)
            ->where('channel_connection_id', $connectionId)
            ->whereIn('status', ['queued', 'sending'])
            ->count();
        $failedDeliveries = OutboundDelivery::query()
            ->forCompany($companyId)
            ->where('channel_connection_id', $connectionId)
            ->where('status', 'failed')
            ->where('updated_at', '>=', $since)
            ->count();
        $failedWebhooks = WebhookEvent::query()
            ->forCompany($companyId)
            ->where('channel_connection_id', $connectionId)
            ->where('status', 'failed')
            ->where('updated_at', '>=', $since)
            ->count();
        $credentialConfigured = ProviderCredential::query()
            ->forCompany($companyId)
            ->where('channel_connection_id', $connectionId)
            ->exists();

        return [
            'company_id' => $companyId,
            'connection_uuid' => (string) $connection->uuid,
            'provider' => (string) $connection->provider,
            'display_name' => (string) ($connection->display_name ?: ucfirst((string) $connection->provider)),
            'status' => (string) $connection->status,
            'credential_state' => $credentialConfigured ? 'configured' : 'missing',
            'member_count' => $connection->members()->where('company_id', $companyId)->whereNull('left_at')->count(),
            'queued_deliveries' => $queuedDeliveries,
            'failed_deliveries' => $failedDeliveries,
            'failed_webhooks' => $failedWebhooks,
            'last_health_checked_at' => $connection->last_health_checked_at?->toIso8601String(),
            'last_inbound_at' => $connection->last_inbound_at?->toIso8601String(),
            'last_outbound_at' => $connection->last_outbound_at?->toIso8601String(),
            'observed_at' => now()->toIso8601String(),
        ];
    }
}
