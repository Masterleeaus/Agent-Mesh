<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers\TeamChat;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamMessage;
use App\Extensions\TitanConnect\System\Security\ConversationAccess;
use App\Extensions\TitanConnect\System\Services\TeamChat\TeamMessageService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class TeamMessageController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly ConversationAccess $access,
    ) {
    }

    public function index(Request $request, TeamConversation $conversation): JsonResponse
    {
        $this->access->assertMember($conversation, $this->context->companyId($request), $this->context->actorId($request));
        $messages = $conversation->messages()->with('reads')->oldest('created_at')
            ->paginate(min(max((int) $request->integer('per_page', 50), 1), 100));
        return response()->json($messages);
    }

    public function store(Request $request, TeamConversation $conversation, TeamMessageService $service): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->access->assertMember($conversation, $companyId, $actorId);
        $data = $request->validate([
            'body' => ['required', 'string', 'max:20000'],
            'local_uuid' => ['nullable', 'uuid'],
            'device_id' => ['nullable', 'string', 'max:191'],
        ]);
        $message = $service->send($conversation, $companyId, $actorId, $data['body'], $data['local_uuid'] ?? null, $data['device_id'] ?? null);
        return response()->json($message, $message->wasRecentlyCreated ? 201 : 200);
    }

    public function read(Request $request, TeamMessage $message, TeamMessageService $service): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->access->assertMember($message->conversation, $companyId, $actorId);
        return response()->json($service->markRead($message, $companyId, $actorId));
    }
}
