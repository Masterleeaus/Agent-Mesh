<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_nexus_compilations')) {
            return;
        }

        $this->addColumnIfMissing('compilation_uuid', static fn (Blueprint $table) => $table->uuid('compilation_uuid')->nullable()->index());
        $this->addColumnIfMissing('parent_compilation_uuid', static fn (Blueprint $table) => $table->uuid('parent_compilation_uuid')->nullable()->index());
        $this->addColumnIfMissing('causation_id', static fn (Blueprint $table) => $table->uuid('causation_id')->nullable()->index());
        $this->addColumnIfMissing('configuration_version', static fn (Blueprint $table) => $table->string('configuration_version', 80)->nullable());
        $this->addColumnIfMissing('compiler_version', static fn (Blueprint $table) => $table->string('compiler_version', 80)->nullable());
        $this->addColumnIfMissing('vertical_id', static fn (Blueprint $table) => $table->string('vertical_id', 120)->nullable()->index());
        $this->addColumnIfMissing('vertical_version', static fn (Blueprint $table) => $table->string('vertical_version', 80)->nullable());
        $this->addColumnIfMissing('business_profile_version', static fn (Blueprint $table) => $table->string('business_profile_version', 80)->nullable());
        $this->addColumnIfMissing('knowledge_snapshot_version', static fn (Blueprint $table) => $table->string('knowledge_snapshot_version', 120)->nullable());
        $this->addColumnIfMissing('input_hash', static fn (Blueprint $table) => $table->string('input_hash', 64)->nullable()->index());
        $this->addColumnIfMissing('output_hash', static fn (Blueprint $table) => $table->string('output_hash', 64)->nullable()->index());
        $this->addColumnIfMissing('dry_run', static fn (Blueprint $table) => $table->boolean('dry_run')->default(false)->index());
        $this->addColumnIfMissing('input_snapshot', static fn (Blueprint $table) => $table->json('input_snapshot')->nullable());
        $this->addColumnIfMissing('compiled_configuration', static fn (Blueprint $table) => $table->json('compiled_configuration')->nullable());
        $this->addColumnIfMissing('validation_result', static fn (Blueprint $table) => $table->json('validation_result')->nullable());
        $this->addColumnIfMissing('provisioning_plan', static fn (Blueprint $table) => $table->json('provisioning_plan')->nullable());
        $this->addColumnIfMissing('diff_summary', static fn (Blueprint $table) => $table->json('diff_summary')->nullable());
        $this->addColumnIfMissing('requested_by', static fn (Blueprint $table) => $table->unsignedBigInteger('requested_by')->nullable()->index());
    }

    public function down(): void
    {
        if (!Schema::hasTable('titan_nexus_compilations')) {
            return;
        }

        $columns = [
            'compilation_uuid',
            'parent_compilation_uuid',
            'causation_id',
            'configuration_version',
            'compiler_version',
            'vertical_id',
            'vertical_version',
            'business_profile_version',
            'knowledge_snapshot_version',
            'input_hash',
            'output_hash',
            'dry_run',
            'input_snapshot',
            'compiled_configuration',
            'validation_result',
            'provisioning_plan',
            'diff_summary',
            'requested_by',
        ];

        $existing = array_values(array_filter(
            $columns,
            static fn (string $column): bool => Schema::hasColumn('titan_nexus_compilations', $column),
        ));

        if ($existing !== []) {
            Schema::table('titan_nexus_compilations', static function (Blueprint $table) use ($existing): void {
                $table->dropColumn($existing);
            });
        }
    }

    /** @param callable(Blueprint): mixed $definition */
    private function addColumnIfMissing(string $column, callable $definition): void
    {
        if (Schema::hasColumn('titan_nexus_compilations', $column)) {
            return;
        }

        Schema::table('titan_nexus_compilations', static function (Blueprint $table) use ($definition): void {
            $definition($table);
        });
    }
};
