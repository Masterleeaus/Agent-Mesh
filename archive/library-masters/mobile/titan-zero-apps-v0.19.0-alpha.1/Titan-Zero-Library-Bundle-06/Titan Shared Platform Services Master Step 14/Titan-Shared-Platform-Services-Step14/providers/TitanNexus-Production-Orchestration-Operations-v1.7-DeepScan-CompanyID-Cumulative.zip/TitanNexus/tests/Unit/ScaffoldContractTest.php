<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanNexus\Unit;

use App\Extensions\TitanNexus\System\Adapters\Platform\PlatformReadinessAdapter;
use App\Extensions\TitanNexus\System\Contracts\VerticalDefinitionSourceContract;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\CompilationStatus;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanNexus\System\Services\DeterministicNexusCompiler;
use App\Extensions\TitanNexus\System\Services\NexusManager;
use App\Extensions\TitanNexus\System\Services\SemanticNexusValidator;
use PHPUnit\Framework\TestCase;

final class ScaffoldContractTest extends TestCase
{
    public function test_manager_reports_governed_provisioning_version(): void
    {
        $manager = $this->manager();

        self::assertSame([
            'engine' => 'titan-nexus',
            'status' => 'control-centre-ready',
            'version' => '1.0.0-rc.2',
            'compiler_version' => '0.5.0',
        ], $manager->health());
    }

    public function test_manager_creates_tenant_bound_draft(): void
    {
        $profile = $this->profile();
        $trace = TraceContext::fromArray([
            'tenant_company_id' => 7,
            'trace_id' => '11111111-1111-4111-8111-111111111111',
            'correlation_id' => '22222222-2222-4222-8222-222222222222',
            'causation_id' => '33333333-3333-4333-8333-333333333333',
        ]);

        $draft = $this->manager()->newDraft($profile, $trace, '44444444-4444-4444-8444-444444444444');

        self::assertSame(CompilationStatus::Draft, $draft->status());
        self::assertSame(7, $draft->traceContext()->tenantCompanyId());
    }

    private function manager(): NexusManager
    {
        $source = new class implements VerticalDefinitionSourceContract {
            public function resolve(BusinessProfile $profile): VerticalDefinition
            {
                return VerticalDefinition::fromArray([
                    'vertical_id' => $profile->verticalId(),
                    'vertical_version' => $profile->verticalVersion(),
                    'knowledge_snapshot_version' => null,
                    'sections' => [],
                ]);
            }
        };

        return new NexusManager(
            new DeterministicNexusCompiler('0.5.0'),
            $source,
            new SemanticNexusValidator(new PlatformReadinessAdapter()),
        );
    }

    private function profile(): BusinessProfile
    {
        return BusinessProfile::fromArray([
            'tenant_company_id' => 7,
            'profile_version' => '1.0.0',
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
            'timezone' => 'Australia/Melbourne',
            'sections' => [],
        ]);
    }
}
