<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Infrastructure\ModelCouncilAssuranceBridge;
use RuntimeException;

final class AssuranceAssessmentRequestService
{
    public function __construct(
        private readonly ?object $engine,
        private readonly HostContextBridgeContract $host,
        private readonly string $policyVersion,
    ) {}

    public function request(
        string $capability,
        ?string $workflowKey,
        array $evidence,
        string $risk,
        ?string $correlationId = null,
    ): array {
        if (!$this->host->can('titan.autonomy.manage')) throw new RuntimeException('AUTONOMY_MANAGE_PERMISSION_REQUIRED');
        if ($this->engine === null || !method_exists($this->engine, 'createRun') || !method_exists($this->engine, 'lockEvidence')) {
            throw new RuntimeException('ASSURANCE_ENGINE_API_UNAVAILABLE');
        }

        $tenant = $this->host->tenantCompanyId();
        $sourceId = ModelCouncilAssuranceBridge::sourceId($capability, $workflowKey);
        $safeEvidence = $evidence;
        unset($safeEvidence['company_id'], $safeEvidence['tenant_id'], $safeEvidence['tenant_company_id'], $safeEvidence['user_id'], $safeEvidence['actor_id']);
        $safeEvidence = ['tenant_company_id' => $tenant] + $safeEvidence;

        $decisionPacket = [
            'decision' => 'autonomy_trusted_auto',
            'capability' => $capability,
            'workflow_key' => $workflowKey ?: null,
            'requested_level' => 'trusted_auto',
            'risk' => strtolower(trim($risk)),
            'validation_context' => [
                'tenant_company_id' => $tenant,
                'actor_user_id' => $this->host->userId(),
                'correlation_id' => $correlationId,
            ],
        ];
        $idempotency = 'autonomy:' . substr(hash('sha256', $tenant . '|' . $sourceId . '|' . $this->policyVersion . '|' . json_encode($safeEvidence)), 0, 48);

        $run = $this->engine->createRun($decisionPacket, [
            'idempotency_key' => $idempotency,
            'source_type' => 'titan_autonomy',
            'source_id' => $sourceId,
            'decision_type' => 'autonomy_trusted_auto',
            'policy_version' => $this->policyVersion,
        ]);
        if (isset($run->company_id) && (string) $run->company_id !== (string) $tenant) {
            throw new RuntimeException('ASSURANCE_TENANT_CONTEXT_MISMATCH');
        }
        $runId = (int) ($run->id ?? 0);
        if ($runId <= 0) throw new RuntimeException('ASSURANCE_RUN_ID_UNAVAILABLE');

        $locked = $this->engine->lockEvidence($runId, $safeEvidence + [
            'capability' => $capability,
            'workflow_key' => $workflowKey ?: null,
            'risk' => strtolower(trim($risk)),
            'policy_version' => $this->policyVersion,
            'correlation_id' => $correlationId,
        ]);

        return [
            'requested' => true,
            'status' => (string) ($locked->status ?? 'pending'),
            'run_id' => (int) ($locked->id ?? $runId),
            'evaluation_ref' => (string) ($locked->uuid ?? $run->uuid ?? $runId),
            'source_id' => $sourceId,
            'message' => 'Assurance evidence is locked. A configured Assurance panel or review process must complete the assessment before Trusted Auto can be granted.',
        ];
    }
}
