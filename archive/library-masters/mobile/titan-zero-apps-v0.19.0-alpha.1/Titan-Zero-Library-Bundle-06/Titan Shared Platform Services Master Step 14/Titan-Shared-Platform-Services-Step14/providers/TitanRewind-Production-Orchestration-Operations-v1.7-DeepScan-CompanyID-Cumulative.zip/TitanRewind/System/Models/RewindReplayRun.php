<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindReplayRun extends Model
{
    protected $table = 'titan_rewind_replay_runs';
    protected $fillable = [
        'run_uuid','operation_id','tenant_company_id','case_id','trace_id','correlation_id','mode','status','target_environment','requested_by_id',
        'mutation_policy','network_policy','deterministic_seed','reproducibility','result_hash','decision_reexecution_performed',
        'input','result','error_text','started_at','finished_at',
    ];
    protected $casts = [
        'tenant_company_id'=>'integer','case_id'=>'integer','requested_by_id'=>'integer','decision_reexecution_performed'=>'boolean','input'=>'array','result'=>'array',
        'started_at'=>'datetime','finished_at'=>'datetime',
    ];
}
