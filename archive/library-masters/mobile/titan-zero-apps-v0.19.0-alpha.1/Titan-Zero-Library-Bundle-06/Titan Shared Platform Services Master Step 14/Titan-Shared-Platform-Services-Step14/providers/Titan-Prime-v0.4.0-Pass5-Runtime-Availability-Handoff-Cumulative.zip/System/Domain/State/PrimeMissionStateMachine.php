<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\State;

use App\Extensions\TitanPrime\System\Domain\Enums\PrimeMissionStatus;

final class PrimeMissionStateMachine
{
    /** @var array<string,list<PrimeMissionStatus>> */
    private const TRANSITIONS = [
        'draft' => [PrimeMissionStatus::Assessing, PrimeMissionStatus::Cancelled, PrimeMissionStatus::Superseded],
        'assessing' => [PrimeMissionStatus::Planned, PrimeMissionStatus::Blocked, PrimeMissionStatus::Failed, PrimeMissionStatus::Cancelled, PrimeMissionStatus::Superseded],
        'planned' => [PrimeMissionStatus::AwaitingApproval, PrimeMissionStatus::Approved, PrimeMissionStatus::Assessing, PrimeMissionStatus::Cancelled, PrimeMissionStatus::Superseded],
        'awaiting_approval' => [PrimeMissionStatus::Approved, PrimeMissionStatus::Rejected, PrimeMissionStatus::Cancelled, PrimeMissionStatus::Superseded],
        'approved' => [PrimeMissionStatus::Delegating, PrimeMissionStatus::Running, PrimeMissionStatus::Cancelled, PrimeMissionStatus::Superseded],
        'delegating' => [PrimeMissionStatus::Running, PrimeMissionStatus::Blocked, PrimeMissionStatus::Failed, PrimeMissionStatus::Cancelled],
        'running' => [PrimeMissionStatus::Observing, PrimeMissionStatus::Paused, PrimeMissionStatus::Blocked, PrimeMissionStatus::Failed, PrimeMissionStatus::Cancelled],
        'observing' => [PrimeMissionStatus::Evaluating, PrimeMissionStatus::Running, PrimeMissionStatus::Paused, PrimeMissionStatus::Failed, PrimeMissionStatus::Cancelled],
        'evaluating' => [PrimeMissionStatus::Completed, PrimeMissionStatus::Running, PrimeMissionStatus::Blocked, PrimeMissionStatus::Failed, PrimeMissionStatus::Cancelled],
        'paused' => [PrimeMissionStatus::Running, PrimeMissionStatus::Cancelled, PrimeMissionStatus::Failed, PrimeMissionStatus::Superseded],
        'blocked' => [PrimeMissionStatus::Assessing, PrimeMissionStatus::Planned, PrimeMissionStatus::Delegating, PrimeMissionStatus::Running, PrimeMissionStatus::Cancelled, PrimeMissionStatus::Failed, PrimeMissionStatus::Superseded],
    ];

    public function canTransition(PrimeMissionStatus $from, PrimeMissionStatus $to): bool
    {
        if ($from === $to || $from->isTerminal()) {
            return false;
        }

        return in_array($to, self::TRANSITIONS[$from->value] ?? [], true);
    }

    /** @return list<PrimeMissionStatus> */
    public function allowedFrom(PrimeMissionStatus $from): array
    {
        return self::TRANSITIONS[$from->value] ?? [];
    }
}
