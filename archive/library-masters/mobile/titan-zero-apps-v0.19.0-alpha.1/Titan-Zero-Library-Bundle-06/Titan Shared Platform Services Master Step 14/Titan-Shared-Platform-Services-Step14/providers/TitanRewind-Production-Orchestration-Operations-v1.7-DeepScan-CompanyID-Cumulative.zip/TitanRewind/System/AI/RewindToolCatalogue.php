<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\AI;

final class RewindToolCatalogue
{
    public function all(): array
    {
        return [
            $this->tool('rewind.reconstruct_trace','Reconstruct a tenant-scoped Titan decision trace.', 'read', ['trace_id'=>['type'=>'string','format'=>'uuid']]),
            $this->tool('rewind.compare_trace','Run a mutation-free structural counterfactual/model/policy/knowledge comparison.', 'read', [
                'trace_id'=>['type'=>'string','format'=>'uuid'],
                'mode'=>['type'=>'string','enum'=>['counterfactual','model-compare','policy-compare','knowledge-compare']],
                'comparison_input'=>['type'=>'object'],
            ]),
            $this->tool('rewind.verify_integrity','Verify the Rewind integrity chain for a tenant-scoped trace.', 'read', ['trace_id'=>['type'=>'string','format'=>'uuid']]),
            $this->tool('rewind.generate_evidence','Generate a deterministic Rewind audit/compliance evidence package.', 'read', ['trace_id'=>['type'=>'string','format'=>'uuid'],'package_type'=>['type'=>'string','enum'=>['audit','compliance','forensic','incident','dispute']]]),
            $this->tool('rewind.propose_recovery','Create a governed recovery proposal. Rewind never executes the business mutation.', 'proposal', ['trace_id'=>['type'=>'string','format'=>'uuid'],'proposed_capability'=>['type'=>'string'],'command_input'=>['type'=>'object']]),
        ];
    }

    public function byId(string $id): ?array
    {
        foreach ($this->all() as $tool) if ($tool['id'] === $id) return $tool;
        return null;
    }

    private function tool(string $id, string $description, string $effect, array $properties): array
    {
        return [
            'id'=>$id,
            'description'=>$description,
            'effect'=>$effect,
            'tenant_context'=>'runtime-only',
            'authoritative_mutation'=>false,
            'input_schema'=>['type'=>'object','additionalProperties'=>false,'properties'=>$properties],
        ];
    }
}
