<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Services\{CrmExportService,CrmForecastService};
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class CrmDataController extends Controller
{
    public function __construct(
        private CrmForecastService $forecast,
        private CrmExportService $exporter,
        private CrmHumanMutationGateway $mutations,
    ) {}

    public function forecast(Request $request)
    {
        return response()->json(['data' => $this->forecast->summarize((int) $request->user()->id)]);
    }

    public function import(Request $request)
    {
        $data = $request->validate([
            'type' => ['required', 'in:companies,contacts,leads,deals'],
            'records' => ['required', 'array', 'min:1'],
        ]);
        $keys = array_values(array_unique(array_merge(...array_map(static fn(array $row): array => array_keys($row), $data['records']))));
        $mapping = array_combine($keys, $keys) ?: [];
        $result = $this->mutations->execute($request,'crm.import.execute',[
            'source_type'=>$data['type'],'source_filename'=>'api-json','mapping'=>$mapping,'rows'=>$data['records'],'dry_run'=>false,
        ]);
        return response()->json($result, 201);
    }

    public function commitImport(Request $request,string $batch)
    {
        $data=$request->validate(['impact_hash'=>['required','string','size:64']]);
        return response()->json($this->mutations->execute($request,'crm.import.commit',['batch_public_id'=>$batch,'impact_hash'=>$data['impact_hash']]));
    }

    public function export(Request $request)
    {
        $data = $request->validate(['type' => ['required', 'in:companies,contacts,leads,deals,activities']]);
        return response()->json($this->exporter->export((int)$request->user()->id,$data['type']));
    }
}
