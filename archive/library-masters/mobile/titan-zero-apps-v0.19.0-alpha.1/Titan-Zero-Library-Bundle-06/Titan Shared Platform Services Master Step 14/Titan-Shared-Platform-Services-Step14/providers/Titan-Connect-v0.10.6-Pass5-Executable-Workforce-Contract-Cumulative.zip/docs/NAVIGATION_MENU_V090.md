# Titan Connect v0.9.0 — Navigation, Channels and Inbox Menus

## User navigation

Titan Connect contributes two independent top-level navigation domains.

### Channels

- WhatsApp
- Messenger
- Instagram
- Telegram
- SMS
- Voice
- Push / Mobile

Each child has its own named route and opens a company-scoped provider settings/diagnostics surface. Connection credentials are never rendered back to the browser.

### Inbox

The Inbox parent has a company/actor-scoped asynchronous badge and these children:

- Unified Inbox
- Team / Internal
- External / Omnichannel
- Assigned to Me
- Unassigned
- Needs Human
- Closed / Archived

The parent badge reports unread communication state. `Needs Human` also receives its own action badge when the host renderer supports Titan Connect badge metadata. Badge data is loaded from `titan-connect.api.navigation.badges` and is never stored in MagicAI's globally cached structural menu catalogue.

## Host registration

Blueprint-v3 hosts are supported directly:

- `App\Support\Extensions\MenuContributionRegistry` receives user navigation.
- `App\Support\Extensions\ContributionRegistry` receives `navigation.admin` definitions.

`HostNavigationRegistrar` adapts the common one-, two- and three-argument registry method shapes (`register`, `contribute`, or `add`) and fails open for navigation only: a host registry mismatch cannot break Titan Connect runtime boot.

Older MagicAI builds that still expose only the central `MenuService` must apply the single contribution-registry host patch used by the wider Titan suite. See `host-patches/README.md`.

## Super Admin

The admin navigation contributes a **Channels** parent with Overview / Diagnostics plus one child per provider. These surfaces intentionally do not expose company credential values or company conversations; business-level settings remain company owned.

## Badge rendering

Titan Connect ships the official-extension-style partial:

`resources/views/header/inbox-notification.blade.php`

and browser asset:

`resources/assets/js/navigation-badges.js`

The script polls every 15 seconds while the page is visible and updates header/menu targets tagged with `data-name="titan-connect-inbox-parent"`. Counts above 99 render as `99+`.

## Security invariants

- `company_id` is the sole active company boundary.
- Company identity comes only from the authenticated user context.
- Badge queries include the actor ID and preserve WorkCore linked-entity authorization.
- No company selector is accepted from menu URLs, query strings, headers or payloads.
- Dynamic badges are never placed in the globally cached menu definition.
