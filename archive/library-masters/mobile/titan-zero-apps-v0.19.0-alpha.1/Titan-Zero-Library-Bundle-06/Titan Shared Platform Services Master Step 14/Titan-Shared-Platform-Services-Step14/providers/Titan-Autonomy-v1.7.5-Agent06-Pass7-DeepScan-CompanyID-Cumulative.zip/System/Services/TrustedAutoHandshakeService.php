<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\DTOs\HandshakeEvaluation;
use App\Extensions\TitanAutonomy\System\Enums\HandshakeDecision;

final class TrustedAutoHandshakeService
{
    public function evaluate(
        HandshakeDecision $platform,
        HandshakeDecision $user,
        HandshakeDecision $aiAssurance,
        array $scope,
    ): HandshakeEvaluation {
        if ($scope === []) {
            $aiAssurance = HandshakeDecision::Denied;
        }
        return new HandshakeEvaluation($platform, $user, $aiAssurance, $scope);
    }
}
