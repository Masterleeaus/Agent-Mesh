<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class BulkController extends Controller {
 public function __construct(private CrmHumanMutationGateway $mutations){}
 public function execute(Request $request,string $resource,string $action){$d=$request->validate(['ids'=>'required|array|min:1|max:100','ids.*'=>'string|size:26','status'=>'nullable|string|max:40','owner_user_id'=>'nullable|integer']);$result=$this->mutations->execute($request,'crm.bulk.execute',$d+['resource'=>$resource,'action'=>$action]);return $request->expectsJson()?response()->json(['data'=>$result]):back()->with('status',((int)($result['updated']??0)).' CRM records updated.');}
}
