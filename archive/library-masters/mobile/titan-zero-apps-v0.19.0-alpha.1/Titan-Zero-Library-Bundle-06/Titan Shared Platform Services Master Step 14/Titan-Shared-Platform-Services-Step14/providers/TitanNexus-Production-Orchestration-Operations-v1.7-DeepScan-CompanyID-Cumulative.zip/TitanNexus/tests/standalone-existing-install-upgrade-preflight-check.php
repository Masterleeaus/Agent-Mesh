<?php

declare(strict_types=1);

$root = dirname(__DIR__);
require_once $root . '/System/Host/TitanInstallerManifestContract.php';
require_once $root . '/System/Host/TitanPackageIntegrityBuilder.php';
require_once $root . '/System/Host/TitanMySqlMigrationCompatibility.php';
require_once $root . '/System/Host/TitanFreshInstallPreflight.php';
require_once $root . '/System/Host/NexusMenuRegistrar.php';
require_once $root . '/System/Host/TitanExistingInstallUpgradePreflight.php';

use App\Extensions\TitanNexus\System\Host\TitanExistingInstallUpgradePreflight;

function ok(bool $value, string $message): void { if (!$value) { throw new RuntimeException($message); } }

$package = TitanExistingInstallUpgradePreflight::verifyDirectory($root);
ok(($package['status'] ?? null) === 'PASS', 'package upgrade preflight must pass');
ok(($package['checks']['migration_chain'] ?? false) === true, 'migration chain check');
ok(($package['checks']['route_names_unique'] ?? false) === true, 'route names unique');
ok(($package['checks']['menu_identities_unique'] ?? false) === true, 'menu identities unique');
ok(($package['checks']['provider_bindings_unique'] ?? false) === true, 'provider bindings unique');

$rc1 = [
    'installed_version' => '1.0.0-rc.1',
    'applied_migrations' => [
        '2026_08_11_000001_create_titan_nexus_compilations_table',
        '2026_08_11_000002_upgrade_titan_nexus_compilations_for_domain_core',
        '2026_08_17_000003_add_vertical_definition_hash_to_titan_nexus_compilations',
    ],
    'compilation_table_exists' => true,
    'lifecycle_table_exists' => false,
    'duplicate_compilation_identities' => 0,
    'duplicate_menu_keys' => 0,
    'duplicate_route_names' => 0,
    'duplicate_service_bindings' => 0,
];
$upgrade = TitanExistingInstallUpgradePreflight::evaluateInstalledState($root, $rc1);
ok(($upgrade['compatible'] ?? false) === true, 'RC1 must be upgrade-compatible');
ok(($upgrade['pending_migrations'] ?? []) === [
    '2026_08_21_000004_add_nexus_compilation_concurrency_guards',
    '2026_08_21_000005_create_titan_nexus_compilation_events_table',
    '2026_08_22_000900_create_workforce_orchestration_handoffs_table',
], 'RC1 must have 000004 + 000005 + persistent orchestration migration pending');

$dupe = $rc1;
$dupe['duplicate_compilation_identities'] = 2;
$blocked = TitanExistingInstallUpgradePreflight::evaluateInstalledState($root, $dupe);
ok(($blocked['compatible'] ?? true) === false, 'duplicate compilation identities must block upgrade');
ok(in_array('duplicate_compilation_identities', $blocked['reasons'] ?? [], true), 'duplicate reason required');

$unknown = $rc1;
$unknown['applied_migrations'][] = '2026_08_99_999999_unknown_nexus_migration';
$blockedUnknown = TitanExistingInstallUpgradePreflight::evaluateInstalledState($root, $unknown);
ok(($blockedUnknown['compatible'] ?? true) === false, 'unknown applied migration must block upgrade');

$future = $rc1;
$future['installed_version'] = '2.0.0';
$blockedFuture = TitanExistingInstallUpgradePreflight::evaluateInstalledState($root, $future);
ok(($blockedFuture['compatible'] ?? true) === false, 'future version must block downgrade');

echo "standalone-existing-install-upgrade-preflight-check: PASS\n";
