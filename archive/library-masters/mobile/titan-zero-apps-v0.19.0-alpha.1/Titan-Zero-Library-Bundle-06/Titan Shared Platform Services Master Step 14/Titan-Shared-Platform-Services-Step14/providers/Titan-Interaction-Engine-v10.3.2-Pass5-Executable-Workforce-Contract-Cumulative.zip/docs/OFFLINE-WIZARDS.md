# Offline Wizards

Capability descriptors own offline classification: `offline_local`, `offline_queueable`, or `online_required`.

Titan Go may continue local wizard state and queue only server-designated queueable actions. Online-required actions move the session to `awaiting_online` without pretending execution. Durable outbox records remain company scoped and replay with trusted actor/device/idempotency context. CRM remains authoritative after sync.
