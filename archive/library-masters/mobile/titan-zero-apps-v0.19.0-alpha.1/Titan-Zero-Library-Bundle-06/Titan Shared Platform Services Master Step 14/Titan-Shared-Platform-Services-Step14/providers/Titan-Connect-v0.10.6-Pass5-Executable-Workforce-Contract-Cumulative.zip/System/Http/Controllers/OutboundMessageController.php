<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Delivery\OutboundDeliveryService;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use App\Extensions\TitanConnect\System\Models\OutboundDelivery;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class OutboundMessageController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly WorkCoreAuthorizationGateway $workCore,
        private readonly ChannelAccessPolicy $channelPolicy,
    ) {
    }

    public function store(Request $request, ChannelConnection $connection, ExternalThread $thread, OutboundDeliveryService $service): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $this->assertScope($companyId, $actorId, $connection, $thread);
        abort_unless($this->channelPolicy->canSend($connection, $actorId), 403);
        $data = $request->validate([
            'to' => ['nullable', 'string', 'max:191'],
            'body' => ['nullable', 'string', 'max:20000'],
            'idempotency_key' => ['required', 'string', 'max:191'],
            'metadata' => ['nullable', 'array'],
            'metadata.attachments' => ['sometimes', 'array', 'max:10'],
            'metadata.attachments.*' => ['array'],
            'metadata.template' => ['sometimes', 'array'],
        ]);
        $body = trim((string) ($data['body'] ?? ''));
        $hasAttachments = is_array(data_get($data, 'metadata.attachments')) && data_get($data, 'metadata.attachments') !== [];
        $hasTemplate = is_array(data_get($data, 'metadata.template')) && data_get($data, 'metadata.template') !== [];
        abort_if($body === '' && ! $hasAttachments && ! $hasTemplate, 422, 'A message body, attachment or provider template is required.');
        $recipient = trim((string) ($data['to'] ?? $thread->external_contact_ref ?? ''));
        abort_if($recipient === '', 422, 'A recipient is required.');
        $delivery = $service->send($companyId, $actorId, $connection, $thread, $recipient, $body, $data['idempotency_key'], $data['metadata'] ?? []);
        return response()->json($delivery->load('message'), $delivery->wasRecentlyCreated ? 201 : 200);
    }

    public function retry(Request $request, OutboundDelivery $delivery, OutboundDeliveryService $service): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        abort_unless((int) $delivery->company_id === $companyId, 404);
        abort_unless($this->channelPolicy->canSend($delivery->connection, $actorId), 403);
        $thread = $delivery->message->thread;
        $this->assertLinked($companyId, $actorId, $thread);
        $scheduled = $service->retry($delivery);
        return response()->json($service->attempt($scheduled, true));
    }

    public function cancel(Request $request, OutboundDelivery $delivery, OutboundDeliveryService $service): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        abort_unless((int) $delivery->company_id === $companyId, 404);
        abort_unless($this->channelPolicy->canSend($delivery->connection, $actorId), 403);
        $this->assertLinked($companyId, $actorId, $delivery->message->thread);
        return response()->json($service->cancel($delivery));
    }

    private function assertScope(int $companyId, int $actorId, ChannelConnection $connection, ExternalThread $thread): void
    {
        abort_unless((int) $connection->company_id === $companyId, 404);
        abort_unless((int) $thread->company_id === $companyId && (int) $thread->channel_connection_id === (int) $connection->id, 404);
        $this->assertLinked($companyId, $actorId, $thread);
    }

    private function assertLinked(int $companyId, int $actorId, ExternalThread $thread): void
    {
        if ($thread->linked_entity_type !== null && $thread->linked_entity_id !== null) {
            $this->workCore->assertCanAccess($companyId, $actorId, (string) $thread->linked_entity_type, (string) $thread->linked_entity_id);
        }
    }
}
