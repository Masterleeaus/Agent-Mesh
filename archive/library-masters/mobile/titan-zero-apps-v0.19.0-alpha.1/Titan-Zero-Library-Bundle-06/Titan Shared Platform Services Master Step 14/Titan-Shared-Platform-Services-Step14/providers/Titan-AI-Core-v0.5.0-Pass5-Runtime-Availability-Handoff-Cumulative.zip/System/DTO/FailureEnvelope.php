<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class FailureEnvelope { public function __construct(public string $classification, public string $code, public string $message, public bool $retryable = false, public ?string $stepId = null) {} }
