# Titan Field Ownership

Titan Field is the authoritative writer for service requests, work orders, appointments, SchedulingKernel, dispatch, recurring service occurrences, field forms/submissions, field evidence, service areas, support/reviews/recovery, customer field assets and field-service vertical profiles.

Historical `crm_*` table names are retained intentionally during extraction to preserve installed data. A table prefix is not an ownership claim.

## Runtime boundary

Titan Field domain/application code consumes Field-owned contracts. CRM implementation dependencies are permitted only in `System/Infrastructure/Compatibility/Crm` while the extraction bridge is active.

The bridge currently supplies tenant context, audit publication, legacy automation publication and host-enable checks. Permission ownership moved to Titan Field in Pass 5; legacy CRM field permission strings are aliases only. Replacing a bridge implementation must not require changes to Titan Field domain services.

## Navigation ownership

Titan Field owns the extracted field/home-service menu surfaces and preserves the CRM-era Laravel named routes so existing plans, active-route logic, bookmarks and installed menu rows remain compatible. The registrar may reuse shared host parent families (`Customers`, `Work`, `Crew`, `Gear`) but only manages Titan Field child surfaces. Existing matching child rows are adopted by route instead of duplicated.

CRM Core must not reintroduce a second implementation or writer for these field-service surfaces.

## Pass 4 — governed capabilities and Signal ownership

Titan Field now owns the canonical governed capability catalogue (`titan.field.*`) and the durable Signal envelope/receipt record for its authoritative mutations. Historical `crm.*` capability names remain compatibility aliases only. `titan_field_signal_outbox` is Titan Field-owned retained audit/replay evidence. CRM automation publication remains transitional and is not the authoritative event record.


## Pass 5 — command and permission ownership

Titan Field owns the canonical mutation entrypoint (`FieldCommandGateway`) and retained `titan_field_command_receipts`. Existing domain services remain the authoritative writers; the gateway governs access to them rather than creating a second implementation. Legacy `crm.*` capability IDs resolve additively to canonical `titan.field.*` definitions.

Titan Field also owns its permission catalogue. Historical `crm.field_services.*`, `crm.work_orders.*`, `crm.dispatch.*` and related field permission strings remain compatibility aliases so existing routes and host Gate registrations survive extraction. CRM Core must not become the authority for new Titan Field permissions.

## Joint Pass 11 spatial peer boundary
Titan Field owns operational truth (appointments, dispatch, work orders, Field routes). Titan Maps Intelligence owns spatial truth when installed (GPS history, geofence/route/ETA evidence, map runtime). Field consumes Maps through `SpatialIntelligenceGateway`; Maps may not directly mutate Field operational tables.


## Joint Pass 12 profitability boundary
Titan Field owns work-order operational health and profitability interpretation. Titan Maps Intelligence may provide read-only route, ETA, territory and advisory geographic-pricing evidence, but it is not invoice, quote, revenue or cost authority. Field applies travel cost only from explicit Field-owned rates; missing rates remain unknown.

## Titan Go offline authority

Titan Field owns offline operational reconciliation and receipts. Titan Go is a client/queue, not a writer. Titan Maps Intelligence owns high-frequency spatial history when active; Field's location table is fallback/compatibility evidence only.


## Pass 15 — optimisation and Workforce ownership

Titan Maps Intelligence owns route-optimisation computation and immutable spatial proposal evidence; it does not own Field route mutation. Titan Field owns the proposal review lifecycle and is the only authority permitted to apply an accepted order through `RouteService` / `FieldCommandGateway`. Titan Field also owns its Workforce Manifest 2.0 role definitions. Central AI Workforce owns staff-instance lifecycle, while Risk, Autonomy and Assurance remain external authorities; Field roles cannot self-hire, self-activate or raise their own authority.
