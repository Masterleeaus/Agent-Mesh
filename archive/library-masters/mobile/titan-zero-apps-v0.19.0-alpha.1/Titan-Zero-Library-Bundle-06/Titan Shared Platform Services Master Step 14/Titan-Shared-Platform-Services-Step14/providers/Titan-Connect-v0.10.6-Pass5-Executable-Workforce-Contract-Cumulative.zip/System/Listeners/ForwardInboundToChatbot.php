<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Listeners;

use App\Extensions\TitanConnect\System\Contracts\ChatbotMessagingBridge;
use App\Extensions\TitanConnect\System\Events\InboundMessageReceived;

final class ForwardInboundToChatbot
{
    public function __construct(private readonly ChatbotMessagingBridge $bridge)
    {
    }

    public function handle(InboundMessageReceived $event): void
    {
        $this->bridge->onInboundMessage((int) $event->thread->company_id, $event->thread, $event->message);
    }
}
