# Titan Signal Engine v0.13.0 — Production Hardening Pass 5

## Scope
Archive Read Contract & Cold-Storage Retrieval.

## Added
- portable verified archive metadata/event/batch/stream read methods;
- persisted `titan_signal_archive_catalog` discovery index;
- governed `SignalHistoryQueryContract` for hot/cold history;
- cold lifecycle/event inspector fallback;
- archive driver continuity and bounded read ceilings;
- idempotent catalog rebuild command for pre-v0.13 verified archives;
- privacy-aware integrity reporting that does not confuse archive verification with canonical checksum verification.

## Boundary
This pass does not implement mixed-tier causal-edge traversal. That remains Production Hardening Pass 7.
