<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Host;

use Illuminate\Contracts\Container\Container;
use Throwable;

final class HostMenuLifecycle
{
    private const MENU_SERVICE = \App\Services\Common\MenuService::class;

    public function __construct(private readonly Container $container)
    {
    }

    public function regenerate(): bool
    {
        if (! class_exists(self::MENU_SERVICE)) {
            return false;
        }

        try {
            $menuService = $this->container->make(self::MENU_SERVICE);
            if (! method_exists($menuService, 'regenerate')) {
                return false;
            }

            $menuService->regenerate();
            return true;
        } catch (Throwable $exception) {
            if (function_exists('report')) {
                report($exception);
            }

            return false;
        }
    }
}
