<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Console\Commands;

use App\Extensions\TitanSignalEngine\System\Services\SignalOperationalHealthService;
use Illuminate\Console\Command;

final class RefreshSignalHealth extends Command
{
    protected $signature = 'titan:signal-health:refresh';
    protected $description = 'Refresh the bounded Titan Signal operational health snapshot.';

    public function handle(SignalOperationalHealthService $health): int
    {
        $this->line(json_encode($health->refresh(), JSON_THROW_ON_ERROR));
        return self::SUCCESS;
    }
}
