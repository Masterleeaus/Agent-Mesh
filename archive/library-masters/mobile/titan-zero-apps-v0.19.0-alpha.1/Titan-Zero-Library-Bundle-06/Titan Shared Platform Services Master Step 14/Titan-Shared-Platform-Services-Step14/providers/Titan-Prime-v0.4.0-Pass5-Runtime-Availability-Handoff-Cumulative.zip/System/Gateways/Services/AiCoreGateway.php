<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Services;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Contracts\AiCoreGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;

final class AiCoreGateway extends AbstractEngineGateway implements AiCoreGatewayContract
{
    public function engine(): EngineKey { return EngineKey::AiCore; }

    public function plan(TraceContext $trace, array $mission, string $operationId): EngineGatewayResult
    {
        return $this->dispatch($trace, 'core.plan', ['mission' => $mission], $operationId);
    }
}
