# Titan Governance v1.0.0-rc.2 — H3 MagicAI Menu Navigation Hotfix

## Live symptom
Titan Governance v1.0.0-rc.1 H2 installed successfully on MagicAI / Titan Extension Manager 1.7.6 but contributed no visible menu links.

## Root cause
Governance used a broad, single-row compatibility adapter and deferred navigation registration through an application `booted` callback. That did not match the proven MagicAI host navigation pattern used by working Titan extensions. It also had no parent/child registrar and several intended child endpoints returned JSON only.

## Fix
- Added `GovernanceMenuRegistrar` using one `Titan Governance` parent and child links for Overview, Control Centre, Escalations, Signal Heatmap, Operational Pressure, Circuit Breakers and Workforce Oversight.
- Uses Tabler component icons only.
- Registers navigation synchronously during provider boot with fail-open isolation.
- Restricts modern navigation integration to the exact `MenuContributionRegistry` binding; otherwise falls back to the host `menus` table.
- Legacy fallback resolves by `key` when available and by route otherwise, preserves administrator order/state, repairs child `parent_id`, and regenerates host menus.
- Adds browser Blade responses for Control Centre, Escalations and read-plane screens while preserving JSON responses for API clients.
- Adds a unique `/overview` route so parent and Overview child do not collide on hosts without a `key` menu column.
- Keeps the platform-admin menu contribution modern-registry-only to avoid leaking an admin row into legacy tenant navigation when the host table lacks permission/surface columns.

## Database and runtime scope
No Governance migration changes. No domain mutation changes. H2 MySQL restartability and H1 dependency compatibility are preserved.
