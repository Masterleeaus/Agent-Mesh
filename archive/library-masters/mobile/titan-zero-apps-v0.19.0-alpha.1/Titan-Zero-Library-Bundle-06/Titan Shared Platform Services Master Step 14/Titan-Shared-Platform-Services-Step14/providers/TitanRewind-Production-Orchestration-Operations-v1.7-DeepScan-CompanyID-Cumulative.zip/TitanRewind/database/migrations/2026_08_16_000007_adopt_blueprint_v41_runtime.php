<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('titan_rewind_evidence_packages', function (Blueprint $table): void {
            if (!Schema::hasColumn('titan_rewind_evidence_packages','signature_algorithm')) $table->string('signature_algorithm',60)->nullable()->after('content_hash');
            if (!Schema::hasColumn('titan_rewind_evidence_packages','signature_key_id')) $table->string('signature_key_id',191)->nullable()->index()->after('signature_algorithm');
            if (!Schema::hasColumn('titan_rewind_evidence_packages','signature')) $table->longText('signature')->nullable()->after('signature_key_id');
            if (!Schema::hasColumn('titan_rewind_evidence_packages','signed_at')) $table->dateTime('signed_at',6)->nullable()->index()->after('signature');
            if (!Schema::hasColumn('titan_rewind_evidence_packages','source_completeness')) $table->string('source_completeness',30)->default('PARTIAL')->index()->after('status');
        });
        if (!Schema::hasTable('titan_rewind_source_watermarks')) Schema::create('titan_rewind_source_watermarks', function (Blueprint $table): void {
            $table->id(); $table->unsignedBigInteger('tenant_company_id')->index(); $table->uuid('trace_id')->index(); $table->string('source_key',120);
            $table->string('state',30)->default('PARTIAL')->index(); $table->dateTime('observed_through',6)->nullable()->index(); $table->unsignedBigInteger('source_lag_seconds')->nullable();
            $table->json('metadata')->nullable(); $table->dateTime('checked_at',6)->index(); $table->timestamps();
            $table->unique(['tenant_company_id','trace_id','source_key'],'trw_source_watermark_unique');
        });
        if (!Schema::hasTable('titan_rewind_custody_events')) Schema::create('titan_rewind_custody_events', function (Blueprint $table): void {
            $table->id(); $table->uuid('event_uuid')->unique(); $table->unsignedBigInteger('tenant_company_id')->index(); $table->uuid('package_uuid')->index();
            $table->string('action',50)->index(); $table->unsignedBigInteger('actor_id')->nullable()->index(); $table->text('reason')->nullable(); $table->json('metadata')->nullable();
            $table->dateTime('occurred_at',6)->index(); $table->timestamps();
        });
        if (!Schema::hasTable('titan_rewind_legal_holds')) Schema::create('titan_rewind_legal_holds', function (Blueprint $table): void {
            $table->id(); $table->uuid('hold_uuid')->unique(); $table->unsignedBigInteger('tenant_company_id')->index(); $table->string('scope_type',40)->index(); $table->string('scope_id',191)->index();
            $table->string('status',30)->default('active')->index(); $table->string('authority',191); $table->text('reason'); $table->unsignedBigInteger('applied_by_id')->nullable()->index();
            $table->dateTime('applied_at',6)->index(); $table->dateTime('review_at',6)->nullable(); $table->dateTime('expires_at',6)->nullable(); $table->unsignedBigInteger('released_by_id')->nullable()->index();
            $table->dateTime('released_at',6)->nullable(); $table->text('release_reason')->nullable(); $table->timestamps();
            $table->index(['tenant_company_id','scope_type','scope_id','status'],'trw_hold_scope_status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_rewind_legal_holds'); Schema::dropIfExists('titan_rewind_custody_events'); Schema::dropIfExists('titan_rewind_source_watermarks');
        foreach (['signature_algorithm','signature_key_id','signature','signed_at','source_completeness'] as $column) {
            if (Schema::hasColumn('titan_rewind_evidence_packages',$column)) Schema::table('titan_rewind_evidence_packages', static fn (Blueprint $table) => $table->dropColumn($column));
        }
    }
};
