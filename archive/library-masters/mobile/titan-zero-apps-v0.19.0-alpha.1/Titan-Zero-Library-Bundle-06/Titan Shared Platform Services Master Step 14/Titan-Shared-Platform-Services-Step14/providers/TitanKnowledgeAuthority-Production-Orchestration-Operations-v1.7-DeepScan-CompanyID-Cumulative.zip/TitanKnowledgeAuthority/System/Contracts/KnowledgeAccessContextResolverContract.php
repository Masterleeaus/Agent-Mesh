<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Contracts;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeAccessContext;

interface KnowledgeAccessContextResolverContract
{
    /**
     * Resolve access only from trusted host-authenticated context.
     * Implementations must not accept tenant or jurisdiction scope from caller input.
     */
    public function current(): KnowledgeAccessContext;
}
