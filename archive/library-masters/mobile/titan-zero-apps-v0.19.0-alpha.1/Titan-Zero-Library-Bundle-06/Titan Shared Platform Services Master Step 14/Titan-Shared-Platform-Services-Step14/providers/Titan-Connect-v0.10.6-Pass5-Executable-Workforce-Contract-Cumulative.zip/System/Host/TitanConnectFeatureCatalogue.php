<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Host;

final class TitanConnectFeatureCatalogue
{
    /**
     * Plan entitlements describe purchased product capability only.
     * Actor/company authorization remains independently enforced by Titan Connect.
     *
     * @return array<int,array{key:string,label:string,route_prefixes:array<int,string>}>
     */
    public function all(): array
    {
        return [
            [
                'key' => 'ext_titan_connect_core',
                'label' => 'Titan Connect Core',
                'route_prefixes' => ['dashboard.user.titan-connect.inbox.', 'titan-connect.inbox.', 'titan-connect.team.', 'titan-connect.api.inbox.', 'titan-connect.api.operator.'],
            ],
            [
                'key' => 'ext_titan_connect_channels',
                'label' => 'Titan Connect Channels',
                'route_prefixes' => ['dashboard.user.titan-connect.channels.', 'titan-connect.channels.', 'titan-connect.api.connections.', 'titan-connect.api.external-messages.'],
            ],
            [
                'key' => 'ext_titan_connect_voice',
                'label' => 'Titan Connect Voice',
                'route_prefixes' => ['dashboard.user.titan-connect.voice.', 'titan-connect.voice.', 'titan-connect.api.voice.'],
            ],
        ];
    }

    /** @return array<int,string> */
    public function keys(): array
    {
        return array_column($this->all(), 'key');
    }
}
