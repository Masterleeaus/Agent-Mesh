# Field/Home Services Profile

Canonical slugs: cleaning; plumbing; electrical; hvac; handyman-property-maintenance; landscaping-gardening; pest-control; locksmith-security; roofing-guttering; appliance-equipment-repair.

Vertical packs are data under `resources/verticals/field-home-services`. They may change terminology, suggested services, evidence/checklists and compliance prompts. They do not change UniversalWizardEngine logic.
