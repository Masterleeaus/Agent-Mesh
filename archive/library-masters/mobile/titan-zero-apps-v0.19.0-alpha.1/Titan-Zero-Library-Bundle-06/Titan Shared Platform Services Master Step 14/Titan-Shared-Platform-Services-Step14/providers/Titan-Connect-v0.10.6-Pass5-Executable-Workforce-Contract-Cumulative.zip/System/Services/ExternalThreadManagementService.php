<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Contracts\CompanyActorDirectory;
use App\Extensions\TitanConnect\System\Models\ContactTag;
use App\Extensions\TitanConnect\System\Models\ExternalMessage;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

final class ExternalThreadManagementService
{
    public function __construct(
        private readonly CompanyActorDirectory $actors,
        private readonly MessagingAuditService $audit,
    ) {}

    public function assign(int $companyId, int $actorId, ExternalThread $thread, ?int $assigneeId): ExternalThread
    {
        $this->assertCompany($thread, $companyId);
        if ($assigneeId !== null) $this->actors->assertUsersBelongToCompany($companyId, [$assigneeId]);
        $thread->forceFill(['assigned_user_id' => $assigneeId])->save();
        $this->audit->record($companyId, $actorId, 'external-thread.assigned', 'external-thread', $thread->uuid, null, ['assigned_user_id' => $assigneeId]);
        return $thread->fresh();
    }

    public function pin(int $companyId, int $actorId, ExternalThread $thread, bool $pinned): ExternalThread
    {
        $this->assertCompany($thread, $companyId);
        $rank = 0;
        if ($pinned) {
            $rank = (int) ExternalThread::query()->forCompany($companyId)->max('pinned_rank') + 1;
        }
        $thread->forceFill(['pinned_rank' => $rank])->save();
        $this->audit->record($companyId, $actorId, $pinned ? 'external-thread.pinned' : 'external-thread.unpinned', 'external-thread', $thread->uuid);
        return $thread->fresh();
    }

    public function close(int $companyId, int $actorId, ExternalThread $thread, bool $closed): ExternalThread
    {
        $this->assertCompany($thread, $companyId);
        $thread->forceFill(['status' => $closed ? 'closed' : 'open', 'closed_at' => $closed ? now() : null])->save();
        $this->audit->record($companyId, $actorId, $closed ? 'external-thread.closed' : 'external-thread.reopened', 'external-thread', $thread->uuid);
        return $thread->fresh();
    }

    public function updatePresentation(int $companyId, int $actorId, ExternalThread $thread, array $changes): ExternalThread
    {
        $this->assertCompany($thread, $companyId);
        $allowed = array_intersect_key($changes, array_flip(['display_name', 'color', 'priority']));
        if (isset($allowed['priority']) && ! in_array($allowed['priority'], ['low', 'normal', 'high', 'urgent'], true)) {
            throw new RuntimeException('Invalid thread priority.');
        }
        $thread->fill($allowed)->save();
        $this->audit->record($companyId, $actorId, 'external-thread.updated', 'external-thread', $thread->uuid, null, ['fields' => array_keys($allowed)]);
        return $thread->fresh();
    }

    public function internalNote(int $companyId, int $actorId, ExternalThread $thread, string $note): ExternalMessage
    {
        $this->assertCompany($thread, $companyId);
        $note = trim($note);
        if ($note === '') throw new RuntimeException('Internal note is required.');
        $message = ExternalMessage::query()->create([
            'uuid' => (string) Str::uuid(), 'company_id' => $companyId, 'external_thread_id' => $thread->id,
            'provider' => $thread->provider, 'direction' => 'internal', 'sender_ref' => 'user:'.$actorId,
            'recipient_ref' => null, 'body' => $note, 'message_type' => 'note', 'status' => 'stored',
            'metadata' => ['is_internal_note' => true, 'actor_id' => $actorId],
        ]);
        $this->audit->record($companyId, $actorId, 'external-thread.note.created', 'external-thread', $thread->uuid, null, ['message_uuid' => $message->uuid]);
        return $message;
    }

    /** @param array<int,int> $tagIds */
    public function syncTags(int $companyId, int $actorId, ExternalThread $thread, array $tagIds): ExternalThread
    {
        $this->assertCompany($thread, $companyId);
        $ids = array_values(array_unique(array_filter(array_map('intval', $tagIds), fn (int $id): bool => $id > 0)));
        $found = ContactTag::query()->forCompany($companyId)->whereIn('id', $ids)->pluck('id')->map(fn ($id) => (int) $id)->all();
        sort($found); sort($ids);
        if ($found !== $ids) throw new RuntimeException('One or more tags are outside the active company.');
        DB::transaction(function () use ($thread, $companyId, $ids): void {
            $sync = [];
            foreach ($ids as $id) $sync[$id] = ['company_id' => $companyId];
            $thread->tags()->sync($sync);
        });
        $this->audit->record($companyId, $actorId, 'external-thread.tags.updated', 'external-thread', $thread->uuid, null, ['tag_ids' => $ids]);
        return $thread->fresh('tags');
    }

    private function assertCompany(ExternalThread $thread, int $companyId): void
    {
        if ((int) $thread->company_id !== $companyId) throw new RuntimeException('External thread company mismatch.');
    }
}
