<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$passes = [];
$failures = [];
$read = static fn (string $path): string => is_file($root.'/'.$path) ? (string) file_get_contents($root.'/'.$path) : '';
$check = static function (bool $condition, string $label) use (&$passes, &$failures): void {
    if ($condition) { $passes[] = $label; } else { $failures[] = $label; }
};

$provider = $read('System/TitanConnectServiceProvider.php');
$sidecarRaw = $read('extension.manifest.json');
$sidecar = $sidecarRaw !== '' ? json_decode($sidecarRaw, true) : null;
$hostManifest = $read('System/Host/TitanConnectHostManifest.php');
$permissions = $read('System/Host/TitanConnectPermissionCatalogue.php');
$features = $read('System/Host/TitanConnectFeatureCatalogue.php');
$menuLifecycle = $read('System/Host/HostMenuLifecycle.php');
$navigation = $read('System/Navigation/TitanConnectNavigation.php');
$registrar = $read('System/Navigation/HostNavigationRegistrar.php');
$hostPatch = $read('host-patches/README.md');
$hostFeature = $read('tests/Feature/HostCertification/CompanyBoundaryTest.php');

$check(is_array($sidecar), 'SIDE-CAR hardened extension.manifest.json exists and parses');
if (is_array($sidecar)) {
    foreach (['identity','compatibility','dependencies','capabilities','routes','tenancy','data','queues','lifecycle','tests'] as $section) {
        $check(array_key_exists($section, $sidecar), 'SIDE-CAR declares '.$section);
    }
    $check(($sidecar['tenancy']['key'] ?? null) === 'company_id', 'SIDE-CAR declares company_id tenancy');
    $check(($sidecar['lifecycle']['preserve_data_on_uninstall'] ?? null) === true, 'SIDE-CAR preserves data on uninstall');
}

$check(str_contains($provider, 'public static function registerKey(): string'), 'LIFECYCLE stable registerKey method exists');
$check(str_contains($provider, "return 'titan-connect';"), 'LIFECYCLE registerKey returns titan-connect');
$check(str_contains($provider, 'public static function uninstall(): void'), 'LIFECYCLE idempotent uninstall hook exists');
$check(str_contains($provider, "'extension'"), 'LIFECYCLE config/assets publish under shared extension tag');
$check(!preg_match('/public function boot\(\).*Http::|public function boot\(\).*curl_/s', $provider), 'LIFECYCLE boot contains no direct network send');
$check(!str_contains($provider, 'Artisan::call(\'migrate'), 'LIFECYCLE boot does not run migrations');

$check(str_contains($hostManifest, 'final class TitanConnectHostManifest'), 'HOST manifest service exists');
$check(str_contains($hostManifest, 'company_id'), 'HOST manifest service declares company boundary');
$check(str_contains($permissions, 'final class TitanConnectPermissionCatalogue'), 'PERMISSIONS explicit admin permission catalogue exists');
$check(str_contains($features, 'final class TitanConnectFeatureCatalogue'), 'FEATURES explicit plan feature catalogue exists');

foreach (['admin_titan_connect_channels','admin_titan_connect_channels_overview','admin_titan_connect_channel_whatsapp','admin_titan_connect_channel_messenger','admin_titan_connect_channel_instagram','admin_titan_connect_channel_telegram','admin_titan_connect_channel_sms','admin_titan_connect_channel_voice','admin_titan_connect_channel_push'] as $key) {
    $check(str_contains($permissions, $key), 'PERMISSIONS includes '.$key);
}
$check(str_contains($permissions, 'titan-connect.admin.channels.*'), 'PERMISSIONS covers admin route family');
foreach (['ext_titan_connect_core','ext_titan_connect_channels','ext_titan_connect_voice'] as $key) {
    $check(str_contains($features, $key), 'FEATURES includes '.$key);
}
$check(!str_contains($features, 'company_id =') && !str_contains($features, 'actorId'), 'FEATURES catalogue is entitlement metadata, not company authorization');

$check(str_contains($menuLifecycle, 'App\\Services\\Common\\MenuService'), 'MENU lifecycle recognizes MagicAI MenuService');
$check(str_contains($menuLifecycle, 'regenerate'), 'MENU lifecycle guards cache regeneration');
$check(str_contains($registrar, 'HostMenuLifecycle'), 'MENU registrar invokes host menu lifecycle helper');
$check(str_contains($hostPatch, 'MenuContributionRegistry') && str_contains($hostPatch, 'ContributionRegistry'), 'HOST PATCH documents central contribution registries');
$check(str_contains($hostPatch, 'permissions') && str_contains($hostPatch, 'entitlement'), 'HOST PATCH documents permissions and entitlements');
$check(str_contains($navigation, 'badge_route') && str_contains($navigation, 'badge_refresh_ms'), 'MENU dynamic badge remains outside structural static value');


$check(str_contains($hostFeature, 'titan-connect:host-sync'), 'HOST FEATURE verifies host-sync command registration');
$check(str_contains($hostFeature, "Route::has('titan-connect.inbox.unified')") && str_contains($hostFeature, "Route::has('titan-connect.admin.channels.index')"), 'HOST FEATURE verifies user and admin route registration');
$check(str_contains($hostFeature, "TitanConnectServiceProvider::registerKey()"), 'HOST FEATURE verifies provider registration key');

foreach ($passes as $label) echo "PASS: {$label}\n";
foreach ($failures as $label) echo "FAIL: {$label}\n";
printf("host-compatibility contract suite: %d passed, %d failed\n", count($passes), count($failures));
exit($failures === [] ? 0 : 1);
