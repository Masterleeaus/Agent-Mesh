<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\SupplyChain;
final class RewindPackageSignatureVerifier
{
    public function verifyDigest(string $sha256,string $signatureBase64,string $publicKeyPem): bool
    {
        if(!extension_loaded('openssl')||!preg_match('/^[a-f0-9]{64}$/i',$sha256))return false;
        $sig=base64_decode($signatureBase64,true);if($sig===false)return false;
        $key=openssl_pkey_get_public($publicKeyPem);if($key===false)return false;
        return openssl_verify(strtolower($sha256),$sig,$key,OPENSSL_ALGO_SHA256)===1;
    }
}
