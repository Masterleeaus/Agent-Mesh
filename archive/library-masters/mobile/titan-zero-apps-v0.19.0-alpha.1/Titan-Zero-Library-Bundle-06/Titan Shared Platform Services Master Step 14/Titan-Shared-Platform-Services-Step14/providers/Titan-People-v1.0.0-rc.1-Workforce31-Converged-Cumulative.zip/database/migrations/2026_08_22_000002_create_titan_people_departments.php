<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('titan_people_departments')) return;
        Schema::create('titan_people_departments', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('tenant_company_id');
            $table->uuid('public_id');
            $table->unsignedBigInteger('parent_id')->nullable();
            $table->string('name');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->unique(['tenant_company_id', 'public_id'], 'tp_dept_tenant_public_uq');
            $table->index(['tenant_company_id', 'parent_id'], 'tp_dept_tenant_parent_idx');
        });
    }

    public function down(): void { Schema::dropIfExists('titan_people_departments'); }
};
