<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Providers;

use App\Extensions\TitanConnect\System\Contracts\ProviderHttpClient;
use App\Extensions\TitanConnect\System\DTO\ProviderSendResult;
use RuntimeException;

final class VoiceProvider extends AbstractMessagingProvider
{
    public function __construct(ProviderHttpClient $http)
    {
        parent::__construct($http);
    }
    public function key(): string { return 'voice'; }
    public function capabilities(): array { return ['voice_calls','transcripts','openai_realtime','elevenlabs']; }
    public function supportsInbound(): bool { return false; }
    public function supportsOutbound(): bool { return false; }
    public function verifyWebhook(array $headers, string $body, array $credentials): bool { return false; }
    public function send(array $message, array $credentials): ProviderSendResult { throw new RuntimeException('Voice connections use the voice session API, not message send.'); }
    public function health(array $credentials): array
    {
        $settings = is_array($credentials['_connection_settings'] ?? null) ? $credentials['_connection_settings'] : [];
        $engine = strtolower((string) ($settings['engine'] ?? $credentials['engine'] ?? 'openai_realtime'));
        $configured = $engine === 'elevenlabs' ? ! empty($credentials['agent_id']) : (! empty($credentials['api_key']) || ! empty($credentials['openai_api_key']));
        return ['ok'=>$configured,'provider'=>'voice','engine'=>$engine,'configured'=>$configured];
    }
}
