# Titan People architecture

Titan People is the canonical `business-domain` owner for tenant-scoped worker identity, organisation and employment facts. Host authentication remains external; People resolves authenticated subjects through `PeopleIdentityPort` and never stores People state on the host `users` table. Cross-domain writes are command-bus-only, and Pass 1 exposes no AI mutation tools.

## Pass 2 employment, documents and leave

Employment lifecycle mutations are represented by `EmploymentLifecycleCommand` and executed through `EmploymentLifecycleCommandService`. Production resolution injects `DatabaseEmploymentLifecycleStore`, which derives current state/version from tenant-scoped append-only `titan_people_employment_events` and uses optimistic entity versions plus unique tenant/worker idempotency keys.

Sensitive People data is separated from the worker directory. `titan_people_worker_profiles` and `titan_people_emergency_contacts` carry private profile facts. HR document metadata/revisions are stored separately from bytes; `PeopleDocumentStoragePort` is bound to a private Laravel filesystem adapter and deliberately exposes no public-URL method.

Leave accounting uses `titan_people_leave_ledger` as the authoritative append-only source. `titan_people_leave_balances` is a performance cache only and must reconcile to the ledger. Holiday applicability is a People read concern and does not grant scheduling authority.
