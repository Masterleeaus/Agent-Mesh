<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects;

final readonly class KnowledgeSourceVersionAppendResult
{
    public function __construct(
        public int $versionId,
        public int $versionSequence,
        public string $versionKey,
        public string $contentHash,
        public bool $created,
    ) {
    }

    public function status(): string
    {
        return $this->created ? 'created' : 'unchanged';
    }
}
