<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Commands;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceCommandGatewayContract;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\GovernanceDecisionEvidenceRegistry;
use App\Extensions\TitanGovernance\System\DecisionIntelligence\UnavailableDecisionEvidenceSource;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class CertifyExtensionCommand extends Command
{
    protected $signature = 'titan:titan-governance:certify {--json : Emit JSON evidence only}';
    protected $description = 'Run non-destructive Titan Governance host certification checks.';

    public function handle(): int
    {
        $checks=[]; $record=static function(string $name,bool $passed,string $detail='') use (&$checks):void{$checks[]=['check'=>$name,'passed'=>$passed,'detail'=>$detail];};
        $record('php', PHP_VERSION_ID >= 80300, PHP_VERSION);
        $record('laravel', str_starts_with((string) app()->version(), '10.50'), (string) app()->version());
        $record('provider_binding', app()->providerIsLoaded(\App\Extensions\TitanGovernance\System\TitanGovernanceServiceProvider::class));
        try { DB::connection()->getPdo(); $record('database', DB::connection()->getDriverName()==='mysql', DB::connection()->getDriverName()); }
        catch (Throwable) { $record('database', false, 'database unavailable'); }
        foreach (['titan_governance_views','titan_governance_policy_decisions','titan_governance_authority_constraints','titan_governance_escalations'] as $table) $record('table:'.$table, Schema::hasTable($table));
        foreach (['dashboard.user.titan.governance.index','dashboard.user.titan.governance.signal-heatmap','dashboard.user.titan.governance.operational-pressure','dashboard.user.titan.governance.circuit-breakers','dashboard.user.titan.governance.projection-history','dashboard.user.titan.governance.escalations.queue','dashboard.user.titan.governance.escalations.actions.execute','dashboard.user.titan.governance.decisions.show','dashboard.user.titan.governance.decisions.timeline','dashboard.user.titan.governance.decisions.rewind','dashboard.user.titan.governance.decisions.compliance','dashboard.user.titan.governance.decisions.delta','dashboard.admin.titan.governance.index'] as $route) $record('route:'.$route, Route::has($route));
        $manifestPath=dirname(__DIR__,2).'/extension.manifest.json'; $installerPath=dirname(__DIR__,2).'/extension.json';
        $manifest=is_file($manifestPath)?json_decode((string)file_get_contents($manifestPath),true):null; $installer=is_file($installerPath)?json_decode((string)file_get_contents($installerPath),true):null;
        $record('manifest', is_array($manifest) && ($manifest['schema_version']??null)==='2.2', $manifestPath);
        $record('manifest_version_match', is_array($manifest) && is_array($installer) && is_string($manifest['version']??null) && ($manifest['version']??null)===($installer['version']??null), (string)($manifest['version']??''));
        try {
            /** @var GovernanceDecisionEvidenceRegistry $evidenceRegistry */
            $evidenceRegistry=app(GovernanceDecisionEvidenceRegistry::class);
            foreach(['titan-command-bus','titan-autonomy','titan-signal'] as $key){
                $source=$evidenceRegistry->get($key);
                $record('decision_evidence_adapter:'.$key, $source!==null && !$source instanceof UnavailableDecisionEvidenceSource, $source?->key()??'missing');
            }
        } catch (Throwable) { foreach(['titan-command-bus','titan-autonomy','titan-signal'] as $key) $record('decision_evidence_adapter:'.$key,false,'registry unavailable'); }
        $record('projection_fingerprint', Schema::hasColumn('titan_governance_views','projection_fingerprint'));
        foreach (['operation_id','payload_hash','command_status','command_receipt_ref','authoritative_receipt_ref','write_verified'] as $column) $record('policy_decision_column:'.$column, Schema::hasColumn('titan_governance_policy_decisions',$column));
        foreach (['version','resolution_action','last_decision_id','last_command_receipt_ref'] as $column) $record('escalation_column:'.$column, Schema::hasColumn('titan_governance_escalations',$column));
        try {
            /** @var GovernanceCommandGatewayContract $gateway */
            $gateway=app(GovernanceCommandGatewayContract::class);
            $gatewayHealth=$gateway->health();
            $gatewayStatus=strtoupper(trim((string)($gatewayHealth['status']??'UNAVAILABLE')));
            $record('command_gateway', in_array($gatewayStatus,['HEALTHY','READY'],true), $gatewayStatus);
        } catch (Throwable) { $record('command_gateway', false, 'gateway unavailable'); }
        $passed=collect($checks)->every(static fn(array $c):bool=>$c['passed']===true);
        $evidence=['schema_version'=>'1.0','extension'=>'titan-governance','host_certified'=>$passed,'checked_at'=>now()->toIso8601String(),'checks'=>$checks];
        $json=json_encode($evidence,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);
        if($this->option('json')) $this->line((string)$json); else { $this->line($passed?'Host certification PASS':'Host certification FAILED'); $this->line((string)$json); }
        return $passed?self::SUCCESS:self::FAILURE;
    }
}
