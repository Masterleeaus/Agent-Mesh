<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);function fail_p5r(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function ok_p5r(bool $c,string $m):void{if(!$c)fail_p5r($m);}
$manifest=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true);$installer=json_decode((string)file_get_contents($root.'/extension.json'),true);if(!is_array($manifest)||!is_array($installer))fail_p5r('manifest parse');
ok_p5r(version_compare((string)($manifest['version']??'0.0.0'),'0.6.0','>='),'manifest version must inherit Pass 5 at >=0.6.0');ok_p5r(version_compare((string)($installer['version']??'0.0.0'),'0.6.0','>='),'installer version must inherit Pass 5 at >=0.6.0');
$required=['governance.decision-timeline.read','governance.decision-delta.read','governance.compliance.read','governance.rewind-theater.read'];foreach($required as $cap)ok_p5r(in_array($cap,$manifest['capabilities']??[],true),'missing capability '.$cap);
$ids=array_column($manifest['capability_contracts']??[],'id');foreach($required as $cap)ok_p5r(in_array($cap,$ids,true),'missing capability contract '.$cap);
foreach(['schemas/capabilities/decision-timeline.output.json','schemas/capabilities/decision-delta.input.json','schemas/capabilities/decision-delta.output.json','schemas/capabilities/compliance.output.json','schemas/capabilities/rewind-theater.output.json','resources/views/decision.blade.php','PASS5-DECISION-INTELLIGENCE-REPORT.md'] as $f)ok_p5r(is_file($root.'/'.$f),'missing release file '.$f);
$view=(string)file_get_contents($root.'/resources/views/decision.blade.php');ok_p5r(str_contains($view,"@extends('panel.layout.app')"),'decision view must use host panel layout');ok_p5r(!str_contains($view,'{!!'),'decision view must not render raw Blade HTML');ok_p5r(!str_contains(strtolower($view),'chain_of_thought'),'decision view must not expose hidden reasoning fields');
$routes=(string)file_get_contents($root.'/routes/user.php');ok_p5r(str_contains($routes,"->post('/decisions/delta'"),'delta route must stay POST');
$tenant=(string)file_get_contents($root.'/System/Context/TenantCompanyResolver.php');ok_p5r(!str_contains($tenant,'* 2'),'tenant resolver must not fabricate company IDs from team/user IDs');
$verify=(string)file_get_contents($root.'/bin/verify.php');ok_p5r(str_contains($verify,'governance.decision-timeline.read'),'bundled verifier must retain Pass 5 capability checks');
echo "PASS: Governance Pass 5 release contract\n";
