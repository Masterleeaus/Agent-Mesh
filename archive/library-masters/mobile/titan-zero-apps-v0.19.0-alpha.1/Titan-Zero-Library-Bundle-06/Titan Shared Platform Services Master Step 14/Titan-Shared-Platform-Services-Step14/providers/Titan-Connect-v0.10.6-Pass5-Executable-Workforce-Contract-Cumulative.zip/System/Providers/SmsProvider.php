<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Providers;

use App\Extensions\TitanConnect\System\DTO\NormalizedDeliveryReceipt;
use App\Extensions\TitanConnect\System\DTO\NormalizedInboundMessage;
use App\Extensions\TitanConnect\System\DTO\ProviderSendResult;
use App\Extensions\TitanConnect\System\DTO\ProviderMediaDescriptor;
use RuntimeException;

final class SmsProvider extends AbstractMessagingProvider
{
    public function key(): string { return 'sms'; }
    public function capabilities(): array { return ['sms', 'mms', 'delivery_receipts']; }

    public function verifyWebhook(array $headers, string $body, array $credentials): bool
    {
        $driver = strtolower((string) ($credentials['driver'] ?? config('titan-connect.providers.sms.driver', 'twilio')));
        if ($driver === 'twilio' && ($signature = $this->header($headers, 'x-twilio-signature')) !== null) {
            $token = trim((string) ($credentials['auth_token'] ?? ''));
            $url = trim((string) ($credentials['webhook_url'] ?? ''));
            if ($token === '' || $url === '') {
                return false;
            }
            parse_str($body, $params);
            if (! is_array($params)) {
                return false;
            }
            ksort($params, SORT_STRING);
            $data = $url;
            foreach ($params as $key => $value) {
                if (is_array($value)) {
                    foreach ($value as $item) {
                        $data .= (string) $key.(string) $item;
                    }
                } else {
                    $data .= (string) $key.(string) $value;
                }
            }
            $expected = base64_encode(hash_hmac('sha1', $data, $token, true));
            return hash_equals($expected, trim($signature));
        }

        return $this->verifyHmac(
            $headers,
            $body,
            (string) ($credentials['webhook_secret'] ?? ''),
            (string) ($credentials['signature_header'] ?? 'x-titan-connect-signature'),
        );
    }

    public function send(array $message, array $credentials): ProviderSendResult
    {
        $driver = strtolower((string) ($credentials['driver'] ?? config('titan-connect.providers.sms.driver', 'twilio')));
        if ($driver !== 'twilio') {
            throw new RuntimeException("Unsupported Titan Connect SMS driver [{$driver}]. Bind another MessagingProvider or use the twilio driver.");
        }

        $accountSid = $this->credential($credentials, 'account_sid');
        $username = trim((string) ($credentials['api_key_sid'] ?? $accountSid));
        $password = trim((string) ($credentials['api_key_secret'] ?? $credentials['auth_token'] ?? ''));
        if ($password === '') {
            throw new RuntimeException('Missing required sms credential [api_key_secret or auth_token].');
        }
        $from = $this->accountIdentity($credentials, 'from', $message);

        $form = ['To' => (string) ($message['to'] ?? ''), 'From' => $from, 'Body' => (string) ($message['body'] ?? '')];
        $attachment = $this->firstAttachment($message);
        if ($attachment !== null && ! empty($attachment['public_url'])) {
            $form['MediaUrl'] = (string) $attachment['public_url'];
        }
        if (! empty($credentials['status_callback'])) {
            $form['StatusCallback'] = (string) $credentials['status_callback'];
        }

        $base = rtrim((string) ($credentials['api_base_url'] ?? config('titan-connect.providers.sms.twilio.api_base_url', 'https://api.twilio.com/2010-04-01')), '/');
        $response = $this->requireSuccess($this->http->request('POST', $base.'/Accounts/'.$accountSid.'/Messages.json', [
            'basic_auth' => [$username, $password],
            'form' => $form,
        ]), 'send');

        $providerId = $response->json('sid');
        $status = strtolower((string) $response->json('status', 'queued'));
        if (! in_array($status, ['queued', 'sending', 'sent', 'delivered', 'read', 'failed'], true)) {
            $status = 'queued';
        }
        return new ProviderSendResult($status, is_scalar($providerId) ? (string) $providerId : null, $response->json);
    }

    public function health(array $credentials): array
    {
        $accountSid = $this->credential($credentials, 'account_sid');
        $username = trim((string) ($credentials['api_key_sid'] ?? $accountSid));
        $password = trim((string) ($credentials['api_key_secret'] ?? $credentials['auth_token'] ?? ''));
        if ($password === '') {
            throw new RuntimeException('Missing required sms credential [api_key_secret or auth_token].');
        }
        $base = rtrim((string) ($credentials['api_base_url'] ?? config('titan-connect.providers.sms.twilio.api_base_url', 'https://api.twilio.com/2010-04-01')), '/');
        $response = $this->http->request('GET', $base.'/Accounts/'.$accountSid.'.json', ['basic_auth' => [$username, $password]]);
        return ['ok' => $response->isSuccessful(), 'provider' => $this->key(), 'driver' => 'twilio', 'configured' => true, 'http_status' => $response->status, 'account_sid' => $response->json('sid')];
    }

    public function resolveInboundMedia(array $attachment, array $credentials): ?ProviderMediaDescriptor
    {
        $url = trim((string) ($attachment['public_url'] ?? $attachment['url'] ?? ''));
        if ($url === '') {
            return null;
        }
        $driver = strtolower((string) ($credentials['driver'] ?? config('titan-connect.providers.sms.driver', 'twilio')));
        if ($driver !== 'twilio') {
            return parent::resolveInboundMedia($attachment, $credentials);
        }
        $accountSid = $this->credential($credentials, 'account_sid');
        $username = trim((string) ($credentials['api_key_sid'] ?? $accountSid));
        $password = trim((string) ($credentials['api_key_secret'] ?? $credentials['auth_token'] ?? ''));
        if ($password === '') {
            throw new RuntimeException('Missing required sms credential [api_key_secret or auth_token].');
        }
        return new ProviderMediaDescriptor(
            $url,
            ['basic_auth' => [$username, $password]],
            null,
            isset($attachment['mime_type']) ? (string) $attachment['mime_type'] : null,
            null,
            null,
            ['provider' => $this->key(), 'driver' => 'twilio'],
        );
    }

    public function normalizeInbound(array $payload, array $headers = []): NormalizedInboundMessage
    {
        $eventId = (string) ($payload['event_id'] ?? $payload['MessageSid'] ?? $payload['message_sid'] ?? $payload['id'] ?? '');
        $messageId = $payload['MessageSid'] ?? $payload['message_sid'] ?? $payload['id'] ?? null;
        $sender = $payload['From'] ?? $payload['from'] ?? null;
        $recipient = $payload['To'] ?? $payload['to'] ?? null;
        $body = $payload['Body'] ?? $payload['body'] ?? $payload['text'] ?? null;
        $attachments = [];
        $numMedia = max(0, (int) ($payload['NumMedia'] ?? 0));
        for ($i = 0; $i < $numMedia; $i++) {
            $url = $payload['MediaUrl'.$i] ?? null;
            if ($url) {
                $attachments[] = ['public_url' => (string) $url, 'mime_type' => $payload['MediaContentType'.$i] ?? null, 'type' => 'mms'];
            }
        }
        return new NormalizedInboundMessage(
            $this->key(), $eventId, (string) ($sender ?? $eventId),
            $messageId === null ? null : (string) $messageId,
            $sender === null ? null : (string) $sender,
            $recipient === null ? null : (string) $recipient,
            $body === null ? null : (string) $body,
            $attachments === [] ? 'text' : 'attachment', $attachments, ['raw' => $payload],
        );
    }

    public function normalizeDeliveryReceipt(array $payload): NormalizedDeliveryReceipt
    {
        $messageId = $payload['MessageSid'] ?? $payload['message_id'] ?? $payload['id'] ?? null;
        $status = $payload['MessageStatus'] ?? $payload['SmsStatus'] ?? $payload['status'] ?? 'unknown';
        return new NormalizedDeliveryReceipt($this->key(), $messageId === null ? null : (string) $messageId, strtolower((string) $status), []);
    }
}
