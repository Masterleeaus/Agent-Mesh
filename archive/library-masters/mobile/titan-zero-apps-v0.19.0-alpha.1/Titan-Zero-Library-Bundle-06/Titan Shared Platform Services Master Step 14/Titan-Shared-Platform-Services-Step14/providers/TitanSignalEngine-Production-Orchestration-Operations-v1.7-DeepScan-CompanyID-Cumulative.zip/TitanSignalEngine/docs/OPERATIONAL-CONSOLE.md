# Titan Signal/Pulse Operational Console — v0.20.0-rc.8.1

## Purpose

The console is a projection surface over Signal's existing contracts. It is not a second event store and it does not bypass governance.


## Super Admin information architecture

Signal Engine is a Super Admin dropdown parent with eight child surfaces:

1. Overview
2. Pulse and Health
3. Events and Traces
4. Anomalies
5. Deliveries and DLQ
6. Lifecycle and Archives
7. Registries
8. Diagnostics

The Overview is status-first and contains no destructive controls. Tenant company ID is exposed only when tenant scope is selected. Destructive or governed actions remain on the relevant child page and continue to delegate to the existing Signal contracts.

## Security tiers

### Tenant console

Tenant users receive read-only access to their own:

- Pulse surface and latency/health projections
- open anomaly feed
- trace/workflow reconstruction
- privacy-projected individual event view

The tenant ID is derived from the authenticated user. A `tenant_company_id` supplied in the query string is ignored by the tenant controller.

Tenant users do not receive global engine counts, subscriber internals, archive batches, lifecycle audit history or lifecycle mutation controls.

### Admin console

The host `auth` + `admin` middleware protects the administrative surface. Admins may select either system scope or an explicit tenant scope.

Administrative mutations are delegated to existing governed contracts:

- anomaly acknowledge/resolve/suppress → `SignalAnomalyContract`
- event redaction/correction/legal hold/prune → `SignalLifecycleContract`

Controllers do not write Signal-owned tables directly.

## Operational surfaces

- attention band + score
- signal/error/critical throughput
- stalled traces and missing execution receipts
- dead-letter delivery pressure
- P50/P95/P99 latency
- top sources and event types
- subscriber status/delivery counts
- anomaly feed
- trace timeline and causal edges
- workflow reconstruction
- event privacy projection
- lifecycle counts
- archive batches
- lifecycle audit trail

## Pruning guardrail

The console supports preview first. Confirmation then calls the existing lifecycle pipeline:

`preview → explicit confirmation → archive → checksum verification → lifecycle audit → hot-event prune`

The UI cannot skip archive verification or mutate the immutable event row.

## Generative UI surface

`SignalConsoleContract::surface()` returns a compact, tenant-safe read model designed for Titan Zero/Prime surfaces. It contains Pulse attention/operational counts and at most five prioritized anomalies. It does not include raw subscriber configuration, lifecycle controls or hidden AI reasoning.
