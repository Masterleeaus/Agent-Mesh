# Pass 1 Build Report — Titan Time & Attendance 0.1.0-alpha.1

## Goal

Convert the first recommended workforce module family into a native Titan Zero extension without installing overlapping legacy attendance packages.

## Architecture decision

`Timesheet` is the backbone. Attendance packages are verification providers/concept donors inside the same domain authority rather than separate extensions.

## Security corrections made during conversion

1. Removed caller-controlled IP allowlists. Trusted IP rules are now tenant-owned records.
2. Bare `site_id` is not accepted as proof of presence.
3. Geofence and QR evidence reject conflicting site context.
4. Offline QR tokens and IP addresses are not persisted raw.
5. Offline retries use tenant-scoped idempotency and reject conflicting replay content.
6. Tenant-wide time reads require an explicit permission.
7. Recording time for another worker requires an explicit permission.
8. Timesheet review requires an explicit review permission.
9. No legacy shared-table migration is carried into the extension.

## Workforce contribution

The package owns four initial roles:

- Time & Attendance Manager
- Timesheet Auditor
- Attendance Exception Specialist
- Workforce Presence Agent

The manifest also declares skills, prompts, two workflows and nine bounded read tools. Setup/policy wizards are present as planned definitions only until their governed write capabilities are implemented.

## Local verification boundary

Pass 1 includes architecture, pure domain, runtime-contract, security/offline, workforce-tool, authorization and installer-lifecycle tests plus full PHP/JSON/package scans. These are static/local package gates.

A real Titan Zero Laravel host with its database, middleware, Marketplace provider discovery and permission registry is not present in this workspace. Live host installation therefore remains a later runtime gate and must not be inferred from static package verification.

## Next pass

Pass 2 should concentrate on governed permission registration, Command Bus mutation adapters, Signal Engine delivery, CRM reference adapters and stronger runtime/tenant integration tests.
