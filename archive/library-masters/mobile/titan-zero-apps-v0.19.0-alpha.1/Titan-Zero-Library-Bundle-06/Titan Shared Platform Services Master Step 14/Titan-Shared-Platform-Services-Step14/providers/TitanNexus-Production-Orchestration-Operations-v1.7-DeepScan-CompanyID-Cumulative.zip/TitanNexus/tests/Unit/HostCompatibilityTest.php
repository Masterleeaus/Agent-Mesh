<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanNexus\Unit;

use App\Extensions\TitanNexus\System\Host\TitanHostAuthorizationAdapter;
use App\Extensions\TitanNexus\System\Host\TitanInstallerManifestContract;
use App\Extensions\TitanNexus\System\Host\TitanMySqlMigrationCompatibility;
use PHPUnit\Framework\TestCase;

final class HostCompatibilityTest extends TestCase
{
    public function test_installer_manifest_contract_rejects_unsupported_root_fields(): void
    {
        $valid = ['schema'=>'titan-extension-v1','slug'=>'titan-nexus','folder'=>'TitanNexus','provider'=>'Provider','version'=>'1.0.0-rc.2','name'=>'Titan Nexus','type'=>'extension','description'=>'Compatibility test','support_telegram'=>''];
        self::assertSame([], TitanInstallerManifestContract::validate($valid));
        self::assertNotSame([], TitanInstallerManifestContract::validate($valid + ['unexpected_field'=>'unsupported']));
    }

    public function test_mysql_scanner_rejects_precision_timestamp(): void
    {
        self::assertSame(['checked_at'], TitanMySqlMigrationCompatibility::unsafePrecisionTimestamps("<?php \\$table->timestamp('checked_at', 6);"));
        self::assertSame([], TitanMySqlMigrationCompatibility::unsafePrecisionTimestamps("<?php \\$table->dateTime('checked_at', 6);"));
    }

    public function test_super_admin_is_unconditional_host_bypass(): void
    {
        $user = new class { public function isSuperAdmin(): bool { return true; } };
        self::assertTrue((new TitanHostAuthorizationAdapter())->allows($user, 'nexus.admin'));
    }
}
