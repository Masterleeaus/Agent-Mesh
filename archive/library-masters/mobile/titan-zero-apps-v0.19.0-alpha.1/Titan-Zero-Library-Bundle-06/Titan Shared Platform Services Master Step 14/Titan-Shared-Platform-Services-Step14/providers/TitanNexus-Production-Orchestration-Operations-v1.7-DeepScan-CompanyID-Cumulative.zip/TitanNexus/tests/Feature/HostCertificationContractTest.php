<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanNexus\Feature;

use App\Extensions\TitanNexus\System\Host\NexusMenuRegistrar;
use PHPUnit\Framework\TestCase;

final class HostCertificationContractTest extends TestCase
{
    public function test_navigation_declares_one_parent_and_nine_children(): void
    {
        $definitions = NexusMenuRegistrar::definitions();
        self::assertCount(10, $definitions);
        self::assertSame('Titan Nexus', $definitions[0]['label']);
        self::assertNull($definitions[0]['parent_key']);
        foreach ($definitions as $definition) {
            self::assertIsString($definition['icon']);
            self::assertStringStartsWith('tabler-', $definition['icon']);
            self::assertStringNotContainsString(' ', $definition['icon']);
            self::assertSame($definition['icon'], $definition['legacy_fields']['icon']);
        }
        foreach (array_slice($definitions, 1) as $definition) {
            self::assertSame('titan-nexus', $definition['parent_key']);
        }
    }

    public function test_embedded_certification_template_does_not_claim_live_host_stages(): void
    {
        $report = json_decode((string) file_get_contents(dirname(__DIR__, 2) . '/certification/host-certification-report.template.json'), true, 512, JSON_THROW_ON_ERROR);
        self::assertSame('NOT_RUN', $report['overall_status']);
        foreach ($report['stages'] as $stage) {
            self::assertSame('NOT_RUN', $stage['status']);
        }
    }
}
