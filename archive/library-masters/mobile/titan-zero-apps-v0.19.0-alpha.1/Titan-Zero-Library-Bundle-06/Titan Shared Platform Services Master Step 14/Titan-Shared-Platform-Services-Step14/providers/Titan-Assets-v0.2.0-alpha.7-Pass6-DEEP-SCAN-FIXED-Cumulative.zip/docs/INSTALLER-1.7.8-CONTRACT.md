# Installer 1.7.8 package contract

The failed 0.1.0-alpha.1 package used a dependency map. Titan Extension Manager 1.7.8 validates each required dependency as an object with `slug` and `version`.

Titan Assets 0.2.0-alpha.2 therefore declares:

```json
"dependencies": [
  {"slug": "crm", "version": ">=1.3.0-alpha.17"}
],
"optional_dependencies": []
```

The archive is flat-root: `extension.json`, `System/`, `database/`, `routes/`, `resources/`, and other extension files live directly at ZIP root. The `folder` field tells the installer to deploy them under `app/Extensions/TitanAssets`.

Every packaged regular file except `extension.json` is covered by the root direct `integrity` SHA-256 map. The package contains no historical Assets migration basename found in the supplied live DB dump.
