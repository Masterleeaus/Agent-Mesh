# Persistent Orchestration Pass v1.5 — TitanWisdomEngine

This pass adds an extension-owned durable orchestration outbox for cross-extension handoffs while preserving Titan AI Workforce as the sole owner of work identity and authority.

## Runtime guarantees

- `company_id` is the canonical tenant boundary.
- `(company_id, idempotency_key)` is unique, preventing duplicate execution records.
- Handoffs transition through `pending`, `in_flight`, `retry`, `deferred`, `delivered`, and `dead_letter`.
- Expired leases are recoverable by another worker.
- Provider absence/degradation fails closed and defers without consuming retry budget.
- Retry exhaustion enters dead-letter; redrive is explicit and resets attempts.
- Execution receipts preserve trace/correlation/causation lineage.
- Health telemetry exposes orchestration queue counts without granting authority.

## Persistence

The extension owns its own orchestration table to avoid cross-extension migration collisions. The table stores the original signed/hashed handoff envelope as JSON plus lifecycle metadata; it does not create Workforce employees, roles, responsibilities, authority, or work items.
