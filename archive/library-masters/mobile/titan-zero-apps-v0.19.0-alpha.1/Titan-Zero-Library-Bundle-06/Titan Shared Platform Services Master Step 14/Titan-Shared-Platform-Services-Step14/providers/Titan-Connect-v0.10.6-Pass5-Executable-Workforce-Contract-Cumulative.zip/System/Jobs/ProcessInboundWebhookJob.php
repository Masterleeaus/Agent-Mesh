<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Jobs;

use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Webhooks\InboundWebhookService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

final class ProcessInboundWebhookJob implements ShouldQueue
{
    use Dispatchable;
    use InteractsWithQueue;
    use Queueable;
    use SerializesModels;

    public int $tries = 3;

    /** @var array<int,int> */
    public array $backoff = [5, 30, 120];

    public function __construct(
        public readonly int $companyId,
        public readonly string $connectionUuid,
        public readonly string $provider,
        public readonly array $headers,
        public readonly string $body,
    ) {
        $this->onQueue((string) config('titan-connect.webhooks.queue', 'default'));
    }

    public function handle(InboundWebhookService $service): void
    {
        // Jobs serialized by pre-v0.5 releases do not contain the company/UUID/provider tuple.
        // Fail them closed instead of falling back to the old numeric connection-id boundary.
        if (! isset($this->companyId, $this->connectionUuid, $this->provider)
            || $this->companyId <= 0
            || trim($this->connectionUuid) === ''
            || trim($this->provider) === '') {
            return;
        }

        $connection = ChannelConnection::query()
            ->forCompany($this->companyId)
            ->where('uuid', $this->connectionUuid)
            ->where('provider', strtolower(trim($this->provider)))
            ->first();

        if (! $connection || $connection->status !== 'active') {
            return;
        }

        $service->handle($connection, $this->headers, $this->body);
    }
}
