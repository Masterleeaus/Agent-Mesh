@extends('panel.layout.app')
@section('content')
@php($listJourney = ($title ?? '') === 'Deals' ? 'new-opportunity' : (($title ?? '') === 'Pipelines' ? 'new-pipeline' : null))
@php($listTitle = ($title ?? 'Records') === 'Deals' ? 'Opportunities' : ($title ?? 'Records'))
@component('crm::components.interaction-page-shell',['title'=>$listTitle,'subtitle'=>'Browse and manage CRM records.','surface'=>'leads','journey'=>$listJourney])
<div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Name</th><th>Status</th><th>Details</th></tr></thead><tbody>@forelse($records as $record)<tr><td>{{ $record['name'] ?? $record['title'] ?? $record['key'] ?? $record['public_id'] ?? 'Record' }}</td><td>{{ ucfirst((string)($record['status'] ?? ($record['is_active'] ?? true ? 'active' : 'inactive'))) }}</td><td class="small text-muted">{{ $record['currency'] ?? '' }} @if(isset($record['value_minor'])){{ number_format($record['value_minor']/100,2) }}@endif</td></tr>@empty<tr><td colspan="3" class="text-muted">No records found.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
