<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Import;
final class CrmCsvImportService
{
    public function __construct(private CrmImportTransformRegistry $transforms){}
    public function preview(string $path,array $mapping,int $maxRecords=0): array
    { $max_records=$maxRecords>0?$maxRecords:(int)config('crm.import.max_records',1000); $h=fopen($path,'rb'); if($h===false)throw new \RuntimeException('CSV file could not be opened.'); $headers=fgetcsv($h); if(!is_array($headers))throw new \RuntimeException('CSV header row is missing.'); $headers=array_map(fn($v)=>trim($this->toUtf8((string)$v)),$headers); $rows=[];$n=0;
      while(($values=fgetcsv($h))!==false && $n<$max_records){$n++;$source=[];foreach($headers as $i=>$header)$source[$header]=$this->neutralizeFormula($this->toUtf8((string)($values[$i]??'')));$out=[];foreach($mapping as $target=>$spec){if(is_string($spec)){$out[$target]=$source[$spec]??null;continue;}$src=(string)($spec['source']??'');$value=$source[$src]??null;foreach((array)($spec['transforms']??[]) as $transform){$key=is_array($transform)?(string)($transform['key']??''):(string)$transform;$arg=is_array($transform)?($transform['value']??null):null;$value=$this->transforms->apply($value,$key,$arg);} $out[$target]=$value;} $rows[]=$out;} fclose($h); return ['headers'=>$headers,'rows'=>$rows,'truncated'=>$n >= $max_records,'encoding'=>'UTF-8']; }
    public function neutralizeFormula(string $value): string { return preg_match('/^[=+\-@]/',$value) ? "'".$value : $value; }
    private function toUtf8(string $value): string { if(mb_check_encoding($value,'UTF-8'))return $value; return mb_convert_encoding($value,'UTF-8','UTF-8, Windows-1252, ISO-8859-1'); }
}
