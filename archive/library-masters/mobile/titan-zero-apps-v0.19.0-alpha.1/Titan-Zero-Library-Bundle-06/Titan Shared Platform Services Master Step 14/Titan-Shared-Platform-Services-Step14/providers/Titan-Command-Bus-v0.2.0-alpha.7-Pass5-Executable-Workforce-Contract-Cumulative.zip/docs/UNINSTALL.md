# Uninstall

Uninstall removes only the published Command Bus config. Command receipts and idempotency/audit state are preserved by default. Destructive audit deletion is intentionally not performed by provider uninstall.
