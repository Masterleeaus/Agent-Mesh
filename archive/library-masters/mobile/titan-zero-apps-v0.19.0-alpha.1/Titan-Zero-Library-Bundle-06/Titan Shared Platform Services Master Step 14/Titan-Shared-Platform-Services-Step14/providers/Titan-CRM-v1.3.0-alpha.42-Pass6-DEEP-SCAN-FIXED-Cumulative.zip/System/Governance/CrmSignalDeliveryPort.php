<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

interface CrmSignalDeliveryPort
{
    public function available(): bool;
    /** @param array<string,mixed> $event @return array<string,mixed> */
    public function deliver(array $event): array;
}
