# Titan Governance Pass 4 Governed Actions & Escalation Queue Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a tenant-scoped escalation inbox and Command-Bus-only human governance actions with durable idempotency and truthful receipts.

**Architecture:** Governance records immutable policy decisions and exposes a stable outbound Command Bus gateway plus inbound local action target. Foreign/domain mutation never occurs inside Governance; absent Command Bus integration fails closed.

**Tech Stack:** PHP 8.3, Laravel 10.50, Eloquent, Blade, Titan Extension Blueprint v4.2 Manifest 2.2.

**Spec:** `docs/superpowers/specs/2026-08-20-governed-actions-escalation-queue-design.md`

## Global Constraints

- `tenant_company_id` remains authoritative tenant boundary.
- Titan Command Bus remains canonical owner of governed mutation.
- Governance may not increase earned/effective Autonomy.
- Every action carries trace, correlation, causation, and root-causation lineage.
- No hidden chain-of-thought storage.
- New behavior is test-first and final claims require fresh exact-ZIP verification.

---

### Task 1: Action request and Command Bus boundary

**Files:**
- Create: `System/Contracts/GovernanceCommandGatewayContract.php`
- Create: `System/Actions/GovernanceActionRequest.php`
- Create: `System/Actions/UnavailableGovernanceCommandGateway.php`
- Test: `tests/Contract/governance_action_request_contract.php`

**Interfaces:**
- Consumes: server-mapped tenant/actor/action context.
- Produces: canonical command envelope and fail-closed gateway result.

- [x] Write failing contract test for allowed actions, required reason codes, forbidden client tenant/actor keys, payload hashing, and unavailable gateway.
- [x] Run test and confirm RED due to missing classes.
- [x] Implement minimal immutable request and gateway contract/default.
- [x] Run test and confirm GREEN.

### Task 2: Durable idempotent policy decision ledger

**Files:**
- Create: `database/migrations/2026_08_20_000004_add_governed_action_metadata.php`
- Create: `System/Models/GovernancePolicyDecision.php`
- Create: `System/Actions/GovernanceActionRepository.php`
- Test: `tests/Contract/governance_action_persistence_static.php`

**Interfaces:**
- Consumes: `GovernanceActionRequest`.
- Produces: claimed/replayed/conflicted policy-decision record.

- [x] Write failing static/pure contract test proving tenant+operation uniqueness and receipt metadata fields.
- [x] Run and confirm RED.
- [x] Implement migration/model/repository with canonical payload hash collision semantics.
- [x] Run and confirm GREEN.

### Task 3: Escalation inbox and ordering

**Files:**
- Create: `System/Models/GovernanceEscalation.php`
- Create: `System/Escalation/GovernanceEscalationRepository.php`
- Test: `tests/Contract/escalation_queue_contract.php`

**Interfaces:**
- Consumes: tenant-scoped escalation rows.
- Produces: queue sorted by risk DESC, urgency DESC, opened_at ASC.

- [x] Write failing queue-order/state contract test.
- [x] Run and confirm RED.
- [x] Implement model/repository and deterministic priority score/ordering description.
- [x] Run and confirm GREEN.

### Task 4: Governed action service and receipt truthfulness

**Files:**
- Create: `System/Actions/GovernanceActionService.php`
- Create: `System/Actions/GovernanceCommandReceiptValidator.php`
- Create: `System/Escalation/GovernanceEscalationTarget.php`
- Test: `tests/Contract/governed_action_service_contract.php`

**Interfaces:**
- Consumes: validated request, decision repository, outbound Command Bus gateway.
- Produces: `RECORDED`, `BLOCKED`, `APPLIED`, `REPLAYED`, or `IDEMPOTENCY_CONFLICT` result with durable references.

- [x] Write failing service test covering unavailable bus, applied receipt validation, replay, collision, and stale/mismatched target transition.
- [x] Run and confirm RED.
- [x] Implement minimal service/receipt validator/target.
- [x] Run and confirm GREEN.

### Task 5: HTTP/UI/manager wiring

**Files:**
- Create: `System/Http/Controllers/GovernanceActionController.php`
- Modify: `System/Contracts/GovernanceManagerContract.php`
- Modify: `System/Services/GovernanceManager.php`
- Modify: `System/TitanGovernanceServiceProvider.php`
- Modify: `routes/user.php`
- Modify: `routes/admin.php`
- Modify: `resources/views/index.blade.php`
- Test: `tests/Contract/pass4_wiring_static.php`

**Interfaces:**
- Consumes: authenticated host user and server-resolved tenant.
- Produces: queue reads and CSRF-protected POST action routes.

- [x] Write failing wiring/authorization/route test.
- [x] Run and confirm RED.
- [x] Wire services, manager methods, controllers, routes, permissions, and action UI.
- [x] Run and confirm GREEN.

### Task 6: Manifest, schemas, docs, release verification

**Files:**
- Modify: `extension.json`
- Modify: `extension.manifest.json`
- Create: action capability/event schemas.
- Modify: README/CHANGELOG/Blueprint alignment/capability/security/integration docs.
- Test: final package verification suite.

**Interfaces:**
- Produces: v0.5.0 cumulative installer package.

- [x] Add capability contracts for queue read and five Command-Bus-only actions.
- [x] Add explicit permissions and ownership declarations without changing foreign engine ownership.
- [x] Run all standalone tests, PHP/JSON validation, Blueprint validator/scanners, MySQL/migration checks.
- [x] Regenerate integrity map, build flat ZIP, re-extract it, and rerun exact-byte gates.
