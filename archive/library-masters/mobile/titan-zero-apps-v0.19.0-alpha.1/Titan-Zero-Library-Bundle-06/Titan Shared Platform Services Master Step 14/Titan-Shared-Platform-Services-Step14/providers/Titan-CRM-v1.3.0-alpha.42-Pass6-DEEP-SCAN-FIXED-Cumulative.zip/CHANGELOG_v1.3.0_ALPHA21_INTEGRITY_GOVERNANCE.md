# CRM 1.3.0-alpha.21 — Integrity & Governance Hardening

## Scope

Alpha.21 hardens confirmed security, integrity and governance gaps found during the post-alpha.20 review. It preserves the existing CRM/Field/Pay/Locker/Bookkeeping surfaces and does not prematurely extract domains in this release.

## Added

- Versioned, named AI read projections with explicit selected output fields.
- Fail-closed tenant-reference validation for governed write inputs.
- Provider payment replay fingerprinting and deterministic duplicate handling.
- Command receipt v2 metrics: duration, affected count, version hint and integrity hash.
- Structured optimistic-concurrency exceptions with current version/state hash and remediation guidance.
- Deterministic Titan Signal event deduplication plus durable delivery claim/retry/dead-letter state.
- `crm:signals:deliver` post-commit Signal delivery worker and replaceable Titan Signal port.
- Durable tenant/source/actor/capability write rate limiting for AI, chatbot and automation callers.
- Staged import relationship validation, durable impact reports (`crm.import.report`) and atomic authoritative batch writes.
- Governed automation action routing through `CrmCommandBusGateway`, including simulation, recursion depth and chain identity.
- Governed automation capabilities for notification queueing, webhook dispatch and review requests.

## Fixed

- Automation rules can no longer directly write tasks, notes, leads, work orders, support cases or review requests through repositories/services.
- Cross-tenant public-ID/user references supplied to governed mutations are rejected before domain mutation, with capability-aware handling for overlapping Field/Locker field names.
- Work-order assignment rejects overlapping worker appointments; invoice creation/issuance rejects cancelled work orders.
- Replayed provider payment transactions cannot be silently attached to a different invoice/amount/currency.
- AI read projections no longer expose tenant IDs or internal relationship ID fields.
- Stale write errors now carry actionable concurrency context.
- Signal outbox events have stable dedup identities and delivery failures are retained for retry/dead-letter handling.
- Non-transient governed command rejections are persisted only after the authoritative mutation transaction has rolled back.
- Import domain writes no longer partially commit when one row fails in an authoritative batch.

## Preserved / intentionally unchanged

- Transactional Signal outbox insertion remains in the same transaction as the CRM mutation; only external Signal delivery occurs after commit.
- Existing alpha.20 Titan Connect outbound-effect boundary is preserved.
- Existing overpayment/negative-payment protection, chatbot grant expiry, AI tool allowlisting, cross-tenant merge protection and fleet odometer monotonicity were already present and were not duplicated.
- Locker, bookkeeping and field-service extraction are deferred to later compatibility-led architecture passes.
