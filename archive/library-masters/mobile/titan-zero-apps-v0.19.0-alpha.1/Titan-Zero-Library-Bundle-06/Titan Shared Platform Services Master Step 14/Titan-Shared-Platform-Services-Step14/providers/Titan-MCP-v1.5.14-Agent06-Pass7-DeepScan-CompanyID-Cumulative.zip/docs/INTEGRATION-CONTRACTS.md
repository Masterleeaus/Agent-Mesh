# Integration contracts

The extension integrates with the host through Installer 1.7.8 provider discovery, Laravel routes/views/migrations, Spatie permissions, the `menus` table / `MenuService::regenerate()` fallback and optional modern navigation contribution registries.

No extension-local Composer install is required. The MCP wire protocol is implemented inside the extension and reports protocol `2025-03-26`.
