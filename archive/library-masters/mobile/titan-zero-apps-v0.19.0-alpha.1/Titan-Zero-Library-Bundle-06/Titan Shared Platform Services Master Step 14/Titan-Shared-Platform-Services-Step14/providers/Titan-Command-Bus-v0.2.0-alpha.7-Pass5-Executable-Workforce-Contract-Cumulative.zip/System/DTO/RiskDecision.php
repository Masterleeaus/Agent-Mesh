<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\DTO;

final readonly class RiskDecision
{
    /**
     * @param list<string> $requiredControls
     */
    public function __construct(
        public bool $allowed,
        public ?string $reference,
        public ?string $riskClass = null,
        public ?float $riskScore = null,
        public array $requiredControls = [],
        public ?string $reasonCode = null,
    ) {
        if ($riskScore !== null && ($riskScore < 0.0 || $riskScore > 1.0)) {
            throw new \InvalidArgumentException('risk_score must be between 0 and 1.');
        }
    }

    public static function unavailable(): self
    {
        return new self(false, null, null, null, [], 'RISK_UNAVAILABLE');
    }
}
