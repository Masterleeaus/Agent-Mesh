# Upgrade

Migrations are forward-only and additive. Upgrade order for Blueprint v4.2 deployments: install/upgrade canonical `titan-signal` first, then Titan Model Council, then run `php artisan migrate` through the host extension installer and `php artisan titan:titan-model-council:certify --json`.

The v0.7.0 rebase changes package metadata from the legacy five-field manifest to Installer 1.7.8 `titan-extension-v1` plus Blueprint schema 2.2. Existing Council records are retained. Legacy source remains archived byte-for-byte for migration forensics.
