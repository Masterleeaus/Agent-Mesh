# Canonical Manifest v2.2 / Installer 1.7.8 Convergence

This pass converges the package to the Blueprint v4.2.1 dual-manifest contract: root `extension.json` is the strict Installer 1.7.8 `titan-extension-v1` manifest with integrity, while `extension.manifest.json` is canonical Blueprint Manifest v2.2.

The pass changes package metadata/contracts and certification wiring only; it does not perform the separate additive tenant-storage migration planned for the next pass. Historical migrations remain frozen.

Blueprint v4.2.1 currently requires `tenant_company_id` in its canonical v2.2 production-core manifest protocol. That protocol field is not treated here as permission to rewrite established runtime storage automatically. Runtime storage migration must be explicit, additive, reversible where possible, and regression-tested.
