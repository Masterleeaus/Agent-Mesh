# Titan Wisdom Engine v0.3.0

Titan Wisdom is Titan's canonical outcome-learning and calibration-feedback engine. It turns validated real-world consequences into governed retrospective intelligence while preserving tenant isolation, causal lineage, evidence provenance and authority boundaries.

## Current state

v0.3.0 adds the complete evidence + delayed outcome resolution layer on top of the canonical OutcomeRecord domain.

Operational capabilities:

- `titan-wisdom`
- `wisdom.health.read`
- `wisdom.readiness.read`
- `wisdom.outcome.record`
- `wisdom.evidence.attach`
- `wisdom.outcome.resolve`
- `wisdom.outcome.revise`

Attribution, learning-pattern synthesis and calibration feedback remain intentionally unavailable until later passes.

## Evidence is separate from interpretation

Evidence is stored in `titan_wisdom_evidence_references` and linked to outcomes through `titan_wisdom_outcome_evidence`. Evidence validation states are `claimed`, `observed`, `validated`, `rejected`, and `superseded`. Relationships are `supports`, `contradicts`, and `context`.

AI/agent self-report may be retained as a claim, but it cannot self-validate as authoritative truth. `authoritative_for_fact=true` requires independently validated evidence with validator provenance.

## Delayed outcomes

Overdue unresolved outcomes are scanned every five minutes and dispatched to the dedicated `titan-wisdom` queue. Queue payloads carry immutable tenant and full causal trace identifiers plus a stable idempotency key. The queued job emits `wisdom.outcome.observation_due.v1`; it does not resolve outcomes or fabricate governance.

Actual terminal resolution requires a fresh governance `ALLOW` for `wisdom.outcome.resolve` plus validated authoritative supporting evidence already linked to the same tenant outcome. Optimistic compare-and-swap increments `record_version` and writes an append-only snapshot to `titan_wisdom_outcome_transitions`.

## Revisions and contradictions

Later evidence never rewrites a previously resolved record. `wisdom.outcome.revise` creates a new append-only OutcomeRecord with `revises_outcome_id` pointing to the prior record. A `contradicted` revision specifically requires validated authoritative evidence linked as `contradicts`.

## Canonical identity

- installer slug / extension key: `titan-wisdom`
- folder: `TitanWisdomEngine`
- primary profile: `intelligence-engine`
- modifier: `signal-aware`
- production core: `titan.production.core.v1`
- tenant key: `tenant_company_id`

## Host certification

```bash
php artisan titan:titan-wisdom:certify --json
```

The command is non-destructive and remains available while the runtime is disabled. A disabled runtime is not considered unhealthy merely because its routes and scheduler are intentionally absent.

## Delayed observation dispatch

Manual dispatch:

```bash
php artisan titan:wisdom:dispatch-due-outcomes --limit=250
```

Disable only delayed observation dispatch with `TITAN_WISDOM_OBSERVATION_DISPATCH_ENABLED=false`. Disable the whole runtime with `TITAN_WISDOM_ENGINE_ENABLED=false`. Neither setting deletes durable Wisdom data.
