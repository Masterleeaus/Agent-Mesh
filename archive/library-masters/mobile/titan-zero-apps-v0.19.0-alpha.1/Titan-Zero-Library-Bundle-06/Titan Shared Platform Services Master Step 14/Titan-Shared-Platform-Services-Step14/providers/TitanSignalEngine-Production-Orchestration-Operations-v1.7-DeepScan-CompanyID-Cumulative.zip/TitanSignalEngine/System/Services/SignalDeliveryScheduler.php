<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryLeaseManagerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliverySchedulerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalSubscriptionRegistryContract;
use App\Extensions\TitanSignalEngine\System\Jobs\DeliverSignalToSubscriber;
use App\Extensions\TitanSignalEngine\System\Models\SignalDelivery;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class SignalDeliveryScheduler implements SignalDeliverySchedulerContract
{
    private readonly string $defaultQueue;

    public function __construct(
        private readonly SignalSubscriptionRegistryContract $subscriptions,
        private readonly SignalDeliveryLeaseManagerContract $leases,
        ?string $defaultQueue = null,
    ) {
        $queue = trim((string) ($defaultQueue ?? 'titan-signal-engine'));
        $this->defaultQueue = $queue !== '' ? $queue : 'titan-signal-engine';
    }

    public function projectForEvent(SignalEvent $event): int
    {
        if (! Schema::hasTable('titan_signal_deliveries')) {
            return 0;
        }
        $created = 0;
        foreach ($this->subscriptions->matching($event) as $subscription) {
            if ((string) $event->event_type === 'signal.subscription.failed'
                && (string) data_get($event->payload, 'subscriber_key') === $subscription->subscriberKey) {
                continue;
            }

            /** @var SignalDelivery $delivery */
            $delivery = SignalDelivery::query()->firstOrCreate(
                [
                    'event_id' => (string) $event->event_id,
                    'subscriber_key' => $subscription->subscriberKey,
                ],
                [
                    'delivery_id' => self::uuid7(),
                    'scope' => (string) $event->scope,
                    'tenant_company_id' => $event->tenant_company_id,
                    'event_type' => (string) $event->event_type,
                    'schema_version' => (int) $event->schema_version,
                    'source' => (string) $event->source,
                    'source_component' => $event->source_component === null ? null : (string) $event->source_component,
                    'queue' => $this->queueFor($subscription->queue),
                    'status' => 'pending',
                    'attempt_count' => 0,
                    'claim_version' => 0,
                    'available_at' => now(),
                ],
            );

            if ($delivery->wasRecentlyCreated) {
                $created++;
            }
            if (in_array((string) $delivery->status, ['pending', 'retry_wait'], true)) {
                $this->enqueueAfterCommit((string) $delivery->delivery_id, 0);
            }
        }
        return $created;
    }

    public function enqueue(string $deliveryId, int $delaySeconds = 0): void
    {
        if (! Schema::hasTable('titan_signal_deliveries')) {
            return;
        }
        /** @var SignalDelivery|null $delivery */
        $delivery = SignalDelivery::query()->where('delivery_id', $deliveryId)->first();
        if ($delivery === null || in_array((string) $delivery->status, ['delivered', 'dead_letter', 'processing'], true)) {
            return;
        }

        $subscription = $this->subscriptions->find((string) $delivery->subscriber_key);
        if ($subscription === null || $subscription->status === 'disabled') {
            return;
        }
        if ($subscription->status === 'paused') {
            SignalDelivery::query()
                ->where('delivery_id', $deliveryId)
                ->whereNotIn('status', ['delivered', 'dead_letter', 'processing'])
                ->update([
                    'status' => 'retry_wait',
                    'available_at' => now()->addMinutes(5),
                    'updated_at' => now(),
                ]);
            return;
        }

        $delaySeconds = max(0, min($delaySeconds, 86400));
        $queueClaim = SignalDelivery::query()->where('delivery_id', $deliveryId);
        if ((string) $delivery->status === 'queued') {
            $staleSeconds = function_exists('config') ? (int) config('titan-signal-engine.delivery_stale_seconds', 300) : 300;
            $queueClaim->where('status', 'queued')
                ->where(function ($query) use ($staleSeconds): void {
                    $query->whereNull('queued_at')->orWhere('queued_at', '<=', now()->subSeconds(max(30, $staleSeconds)));
                });
        } else {
            $queueClaim->whereIn('status', ['pending', 'retry_wait']);
        }

        $updated = $queueClaim->update([
            'status' => 'queued',
            'queued_at' => now(),
            'available_at' => now()->addSeconds($delaySeconds),
            'reserved_at' => null,
            'lease_token' => null,
            'lease_owner' => null,
            'lease_expires_at' => null,
            'updated_at' => now(),
        ]);

        if ($updated !== 1) {
            return;
        }

        try {
            DeliverSignalToSubscriber::dispatch(
                $deliveryId,
                $subscription->timeoutSeconds,
            )->onQueue($this->queueFor($subscription->queue))->delay(now()->addSeconds($delaySeconds));
        } catch (Throwable $exception) {
            SignalDelivery::query()
                ->where('delivery_id', $deliveryId)
                ->where('status', 'queued')
                ->whereNull('lease_token')
                ->update([
                    'status' => 'pending',
                    'last_error_class' => $exception::class,
                    'last_error' => $this->safeErrorReference($exception),
                    'updated_at' => now(),
                ]);
            Log::error('signal.delivery_enqueue_failed', [
                'delivery_id' => $deliveryId,
                'subscriber_key' => $delivery->subscriber_key,
                'error_class' => $exception::class,
            ]);
        }
    }

    public function recoverDue(int $limit = 100): int
    {
        if (! Schema::hasTable('titan_signal_deliveries')) {
            return 0;
        }
        $limit = max(1, min($limit, 1000));
        $staleSeconds = function_exists('config') ? (int) config('titan-signal-engine.delivery_stale_seconds', 300) : 300;
        $staleBefore = now()->subSeconds(max(30, $staleSeconds));

        $rows = SignalDelivery::query()
            ->where(function ($query) use ($staleBefore): void {
                $query->where(function ($query): void {
                    $query->whereIn('status', ['pending', 'retry_wait'])
                        ->where(function ($query): void {
                            $query->whereNull('available_at')->orWhere('available_at', '<=', now());
                        });
                })->orWhere(function ($query) use ($staleBefore): void {
                    $query->where('status', 'queued')
                        ->where(function ($query) use ($staleBefore): void {
                            $query->whereNull('queued_at')->orWhere('queued_at', '<=', $staleBefore);
                        });
                })->orWhere(function ($query) use ($staleBefore): void {
                    $query->where('status', 'processing')
                        ->where(function ($query) use ($staleBefore): void {
                            $query->where('lease_expires_at', '<=', now())
                                ->orWhere(function ($query) use ($staleBefore): void {
                                    $query->whereNull('lease_expires_at')
                                        ->where(function ($query) use ($staleBefore): void {
                                            $query->whereNull('reserved_at')->orWhere('reserved_at', '<=', $staleBefore);
                                        });
                                });
                        });
                });
            })
            ->orderBy('id')
            ->limit($limit)
            ->cursor();

        $recovered = 0;
        foreach ($rows as $row) {
            if ((string) $row->status === 'processing' && ! $this->leases->releaseExpired((string) $row->delivery_id)) {
                continue;
            }
            $this->enqueue((string) $row->delivery_id, 0);
            $recovered++;
        }
        return $recovered;
    }

    private function enqueueAfterCommit(string $deliveryId, int $delaySeconds): void
    {
        if (DB::transactionLevel() > 0) {
            DB::afterCommit(function () use ($deliveryId, $delaySeconds): void {
                $this->enqueue($deliveryId, $delaySeconds);
            });
            return;
        }
        $this->enqueue($deliveryId, $delaySeconds);
    }


    private function queueFor(?string $queue): string
    {
        $queue = trim((string) $queue);
        return $queue !== '' ? $queue : $this->defaultQueue;
    }

    private function safeErrorReference(Throwable $exception): string
    {
        return 'enqueue_failed:' . substr(hash('sha256', $exception::class . '|' . $exception->getMessage()), 0, 20);
    }

    private static function uuid7(): string
    {
        $milliseconds = (int) floor(microtime(true) * 1000);
        $timeHex = str_pad(dechex($milliseconds), 12, '0', STR_PAD_LEFT);
        $random = bin2hex(random_bytes(10));
        $hex = $timeHex . $random;
        $hex[12] = '7';
        $variant = hexdec($hex[16]);
        $hex[16] = dechex(($variant & 0x3) | 0x8);
        return sprintf('%s-%s-%s-%s-%s', substr($hex, 0, 8), substr($hex, 8, 4), substr($hex, 12, 4), substr($hex, 16, 4), substr($hex, 20, 12));
    }
}
