<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ControlCentre;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceDecisionReadStoreContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceEscalationStoreContract;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceSignalIntelligence;
use DateTimeImmutable;
use Throwable;

final class GovernanceControlCentre
{
    public function __construct(
        private readonly ControlCentreSourceReader $sources,
        private readonly EvidenceFreshnessProjector $freshness,
        private readonly ModelHealthProjector $models,
        private readonly PolicyComplianceHealthProjector $policyCompliance,
        private readonly AuthorityContractionProjector $authority,
        private readonly EngineHealthScorecard $engineHealth,
        private readonly GovernanceAttentionRanker $attention,
        private readonly GovernanceDecisionReadStoreContract $decisions,
        private readonly GovernanceEscalationStoreContract $escalations,
        private readonly GovernanceSignalIntelligence $signal,
        private readonly ?WorkforceOversightProjector $workforceProjector = null,
        private readonly ?HumanOversightProjector $humanProjector = null,
    ) {}

    /** @return array<string,mixed> */
    public function snapshot(int $tenantCompanyId,array $context=[]):array
    {
        $sourceSnapshots=$this->sources->all($tenantCompanyId,$context);
        $recent=$this->safeDecisions($tenantCompanyId);
        $escalations=$this->safeEscalations($tenantCompanyId);
        $signal=$this->signal->snapshot($tenantCompanyId,$context);
        $workforce=$this->workforceProjector?->project($sourceSnapshots,$context) ?? ['status'=>'NOT_INSTALLED','members'=>[],'relationships'=>[],'queues'=>[],'approvals'=>[],'handoffs'=>[],'performance'=>[],'outcome_refs'=>[],'summary'=>[],'can_raise_authority'=>false,'authority_changed'=>false];
        $human=$this->humanProjector?->project($workforce,$recent,$context) ?? ['status'=>$workforce['status']??'NOT_INSTALLED','approvals'=>[],'handoffs'=>[],'operator_workload'=>[],'intervention_history'=>[],'summary'=>[],'can_raise_authority'=>false,'authority_changed'=>false];
        $modelHealth=$this->models->project($sourceSnapshots,$context);
        $policyCompliance=$this->policyCompliance->project($sourceSnapshots,$recent,$context);
        $authority=$this->authority->project($sourceSnapshots);
        $sourceHealth=$this->sourceHealth($tenantCompanyId,$sourceSnapshots,$context);
        $engineHealth=$this->engineHealth->project($sourceHealth);
        $freshnessRecords=[];
        foreach($sourceSnapshots as $key=>$row)$freshnessRecords[]=['source'=>(string)$key,'required'=>(bool)($row['required']??false),'observed_at'=>$row['observed_at']??null];
        foreach($modelHealth['models']??[] as $row)if(is_array($row))$freshnessRecords[]=['source'=>'model:'.($row['model_id']??'unknown'),'required'=>false,'observed_at'=>$row['observed_at']??null];
        foreach($policyCompliance['controls']??[] as $row)if(is_array($row))$freshnessRecords[]=['source'=>'control:'.($row['control_key']??'unknown'),'required'=>false,'observed_at'=>$row['observed_at']??null];
        $freshness=$this->freshness->project($freshnessRecords,$context);
        $needsAttention=$this->attention->rank($modelHealth,$policyCompliance,$engineHealth,$authority,$freshness,$signal,$escalations,$workforce,$human);
        $status=$this->overall($policyCompliance,$engineHealth,$modelHealth,$needsAttention);
        return [
            'schema_version'=>'1.0','status'=>$status,'tenant_company_id'=>$tenantCompanyId,'observed_at'=>$this->now($context)->format(DATE_ATOM),
            'needs_attention'=>$needsAttention,'engine_health'=>$engineHealth,'model_health'=>$modelHealth,'policy_compliance'=>$policyCompliance,
            'authority_contractions'=>$authority,'evidence_freshness'=>$freshness,'signal_intelligence'=>$signal,'escalations'=>$escalations,
            'workforce_oversight'=>$workforce,'human_oversight'=>$human,
        ];
    }

    /** @param array<string,array<string,mixed>> $sources @return array<string,mixed> */
    private function sourceHealth(int $tenantCompanyId,array $sources,array $context):array
    {
        $rows=[];$status='HEALTHY';
        foreach($sources as $key=>$row){
            $s=strtoupper((string)($row['status']??'UNAVAILABLE'));$required=(bool)($row['required']??false);
            $rows[$key]=['status'=>$s,'required'=>$required,'observed_at'=>$row['observed_at']??null,'reason'=>$row['reason']??null];
            if($required&&in_array($s,['UNAVAILABLE','ERROR','NOT_INSTALLED','INVALID'],true))$status='UNAVAILABLE';
            elseif($status==='HEALTHY'&&!in_array($s,['HEALTHY','DISABLED'],true))$status='DEGRADED';
        }
        return ['status'=>$status,'tenant_company_id'=>$tenantCompanyId,'sources'=>$rows,'observed_at'=>$this->now($context)->format(DATE_ATOM)];
    }
    /** @return list<array<string,mixed>> */
    private function safeDecisions(int $tenantCompanyId):array{try{return $this->decisions->recent($tenantCompanyId,100);}catch(Throwable){return [];}}
    /** @return list<array<string,mixed>> */
    private function safeEscalations(int $tenantCompanyId):array{try{return $this->escalations->queue($tenantCompanyId,100);}catch(Throwable){return [];}}
    /** @param array<string,mixed> $policy @param array<string,mixed> $engine @param array<string,mixed> $models @param array<string,mixed> $attention */
    private function overall(array $policy,array $engine,array $models,array $attention):string
    {
        if(($policy['status']??null)==='NON_COMPLIANT')return 'NON_COMPLIANT';
        if(($engine['status']??null)==='UNAVAILABLE')return 'UNAVAILABLE';
        if(($attention['critical_count']??0)>0||in_array($policy['status']??null,['DEGRADED','UNAVAILABLE'],true)||in_array($models['status']??null,['DEGRADED','UNAVAILABLE'],true)||($engine['status']??null)==='DEGRADED')return 'DEGRADED';
        return 'HEALTHY';
    }
    private function now(array $context):DateTimeImmutable{if(is_string($context['now']??null)){try{return new DateTimeImmutable($context['now']);}catch(Throwable){}}return new DateTimeImmutable('now');}
}
