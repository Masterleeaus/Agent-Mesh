<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use Illuminate\Database\ConnectionInterface;

final class SalesDocumentContractSnapshotService
{
    public function __construct(private readonly ConnectionInterface $db) {}

    /** @return array{snapshot:array<string,mixed>,hash:string,lines:array<int,array<string,mixed>>} */
    public function build(int $companyId, string $type, object|array $row): array
    {
        $record=is_array($row)?$row:(array)$row;
        $publicId=(string)($record['public_id']??'');
        $lines=$this->db->table('crm_sales_document_lines')
            ->where('company_id',$companyId)
            ->where('document_type',$type)
            ->where('document_public_id',$publicId)
            ->orderBy('sequence')->get()->map(fn($r)=>$this->normalizeLine((array)$r))->all();

        $snapshot=[
            'schema'=>$type==='invoices'?'crm.invoice-contract.v1':'crm.commercial-contract.v1',
            'document_type'=>$type,
            'document_public_id'=>$publicId,
            'revision_root_public_id'=>(string)($record['revision_root_public_id']??$publicId),
            'revision_number'=>(int)($record['revision_number']??1),
            'number'=>$record['number']??null,
            'title'=>$record['title']??null,
            'company_public_id'=>$record['company_public_id']??null,
            'contact_public_id'=>$record['contact_public_id']??null,
            'currency'=>strtoupper((string)($record['currency']??'AUD')),
            'subtotal_minor'=>(int)($record['subtotal_minor']??0),
            'tax_minor'=>(int)($record['tax_minor']??0),
            'total_minor'=>(int)($record['total_minor']??0),
            'expires_at'=>$record['expires_at']??null,
            'pricing_rules_version'=>$record['pricing_rules_version']??null,
            'pricing_rule_snapshot'=>$this->decode($record['pricing_rule_snapshot']??null),
            'tax_rule_snapshot'=>$this->decode($record['tax_rule_snapshot']??null),
            'terms_snapshot'=>$this->decode($record['terms_snapshot']??null),
            'service_definition_snapshot'=>$this->decode($record['service_definition_snapshot']??null),
            'discount_snapshot'=>$this->decode($record['discount_snapshot']??null),
            'currency_snapshot'=>$this->decode($record['currency_snapshot']??null),
            'due_at'=>$record['due_at']??null,
            'source_quote_public_id'=>$record['source_quote_public_id']??null,
            'source_quote_snapshot_hash'=>$record['source_quote_snapshot_hash']??null,
            'source_quote_revision_root_public_id'=>$record['source_quote_revision_root_public_id']??null,
            'source_work_order_public_id'=>$record['source_work_order_public_id']??($record['work_order_public_id']??null),
            'lines'=>$lines,
        ];
        $snapshot=$this->canonicalize($snapshot);
        return ['snapshot'=>$snapshot,'hash'=>hash('sha256',$this->encode($snapshot)),'lines'=>$lines];
    }

    public function hashEvidence(array $evidence): string
    {
        return hash('sha256',$this->encode($this->canonicalize($evidence)));
    }

    private function normalizeLine(array $line): array
    {
        return $this->canonicalize([
            'sequence'=>(int)($line['sequence']??0),
            'description'=>(string)($line['description']??''),
            'quantity_milli'=>(int)($line['quantity_milli']??0),
            'unit_price_minor'=>(int)($line['unit_price_minor']??0),
            'tax_rate_bps'=>(int)($line['tax_rate_bps']??0),
            'line_subtotal_minor'=>(int)($line['line_subtotal_minor']??0),
            'line_tax_minor'=>(int)($line['line_tax_minor']??0),
            'line_total_minor'=>(int)($line['line_total_minor']??0),
            'meta'=>$this->decode($line['meta']??null),
        ]);
    }

    private function decode(mixed $value): mixed
    {
        if(is_array($value)||$value===null)return $value;
        if(is_object($value))return (array)$value;
        if(is_string($value)&&$value!==''){
            $decoded=json_decode($value,true);
            if(json_last_error()===JSON_ERROR_NONE)return $decoded;
        }
        return $value;
    }

    private function canonicalize(mixed $value): mixed
    {
        if(!is_array($value))return $value;
        if(array_is_list($value))return array_map(fn($v)=>$this->canonicalize($v),$value);
        ksort($value,SORT_STRING);
        foreach($value as $k=>$v)$value[$k]=$this->canonicalize($v);
        return $value;
    }

    private function encode(array $value): string
    {
        return (string)json_encode($value,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION|JSON_THROW_ON_ERROR);
    }
}
