<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** @var array<int,string> */
    private const OBSOLETE_ADMIN_KEYS = [
        'titan_connect_admin_settings_overview',
        'titan_connect_admin_settings_whatsapp',
        'titan_connect_admin_settings_messenger',
        'titan_connect_admin_settings_instagram',
        'titan_connect_admin_settings_telegram',
        'titan_connect_admin_settings_sms',
        'titan_connect_admin_settings_voice',
        'titan_connect_admin_settings_push',
    ];

    /** @var array<int,string> */
    private const HOST_SAFE_ICONS = [
        'tabler-layout-dashboard', 'tabler-inbox', 'tabler-message-cog', 'tabler-message',
        'tabler-photo', 'tabler-phone-call', 'tabler-bell-ringing', 'tabler-users-group',
        'tabler-world', 'tabler-user-check', 'tabler-user-question', 'tabler-hand-stop',
        'tabler-archive', 'tabler-settings', 'tabler-folders',
    ];

    /**
     * This migration is intentionally self-contained. Titan upgrades execute inside the same
     * already-booted PHP request, so no newly deployed Titan Connect runtime class is resolved.
     */
    public function up(): void
    {
        if (! Schema::hasTable('menus')) {
            return;
        }

        $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
        if (! isset($columns['key'])) {
            return;
        }

        $hasAdminColumn = Schema::hasColumn('menus', 'is_admin');

        // Remove the v0.10.4 provider-by-provider Super Admin fallback. Older MagicAI hosts
        // should expose a single Titan Connect entry under Settings, not operational Channels.
        DB::table('menus')->whereIn('key', self::OBSOLETE_ADMIN_KEYS)->delete();

        $this->sync($this->userDefinitions(), $columns, $hasAdminColumn ? 0 : null);

        if ($hasAdminColumn) {
            $this->sync($this->adminDefinitions(), $columns, 1);
        } else {
            $settingsId = DB::table('menus')->where('key', 'settings')->value('id');
            if (is_numeric($settingsId)) {
                $this->upsert([
                    'key' => 'titan_connect_admin_settings',
                    'route' => 'dashboard.admin.settings.titan-connect.channels.index',
                    'label' => 'Titan Connect',
                    'icon' => 'tabler-message-cog',
                    'order' => 90,
                ], (int) $settingsId, $columns, null);
            }
        }

        $this->regenerateMenuCache();
    }

    public function down(): void
    {
        // Do not resurrect the broken v0.10.4 admin/provider menu structure on rollback.
        // Keep the user navigation rows intact because they may pre-date this repair release.
        if (! Schema::hasTable('menus')) {
            return;
        }

        DB::table('menus')->where('key', 'titan_connect_admin_settings')->delete();
        $this->regenerateMenuCache();
    }

    /** @param array<int,array<string,mixed>> $definitions @param array<string,bool> $columns */
    private function sync(array $definitions, array $columns, ?int $isAdmin): void
    {
        $roots = array_values(array_filter($definitions, static fn (array $item): bool => ($item['parent_key'] ?? null) === null));
        $children = array_values(array_filter($definitions, static fn (array $item): bool => ($item['parent_key'] ?? null) !== null));

        foreach (array_merge($roots, $children) as $definition) {
            $parentId = null;
            $parentKey = $definition['parent_key'] ?? null;
            if (is_string($parentKey) && $parentKey !== '') {
                $value = DB::table('menus')->where('key', $parentKey)->value('id');
                if (! is_numeric($value)) {
                    continue;
                }
                $parentId = (int) $value;
            }
            $this->upsert($definition, $parentId, $columns, $isAdmin);
        }
    }

    /** @param array<string,mixed> $definition @param array<string,bool> $columns */
    private function upsert(array $definition, ?int $parentId, array $columns, ?int $isAdmin): void
    {
        $key = (string) ($definition['key'] ?? '');
        if ($key === '') {
            return;
        }

        $now = function_exists('now') ? now() : date('Y-m-d H:i:s');
        $row = [
            'parent_id' => $parentId,
            'route' => $definition['route'] ?? null,
            'route_slug' => null,
            'label' => $definition['label'] ?? $key,
            'icon' => $this->safeIcon((string) ($definition['icon'] ?? '')),
            'svg' => null,
            'order' => (int) ($definition['order'] ?? 0),
            'is_active' => 1,
            'params' => '[]',
            'type' => 'item',
            'badge' => null,
            // Titan Connect is not yet a native MagicAI plan-catalogue key. Setting this to
            // "1" makes Super Admin see the link via bypass while normal subscribers can lose it.
            'extension' => null,
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
            'custom_menu' => 0,
            'is_admin' => $isAdmin,
            'updated_at' => $now,
        ];
        $row = array_intersect_key($row, $columns);
        if ($isAdmin === null) {
            unset($row['is_admin']);
        }

        $query = DB::table('menus')->where('key', $key);
        if ($query->exists()) {
            // v0.10.4 needs route/order/parent repair, so these extension-owned structural
            // values are deliberately updated rather than preserving the broken placement.
            $query->update($row);
            return;
        }

        $insert = ['key' => $key] + $row;
        if (isset($columns['created_at'])) {
            $insert['created_at'] = $now;
        }
        DB::table('menus')->insert(array_intersect_key($insert, $columns));
    }

    /** @return array<int,array<string,mixed>> */
    private function userDefinitions(): array
    {
        return [
            ['parent_key'=>null,'key'=>'ext_titan_connect_inbox','route'=>'dashboard.user.titan-connect.inbox.unified','label'=>'Inbox','icon'=>'tabler-inbox','order'=>6],
            ['parent_key'=>'ext_titan_connect_inbox','key'=>'titan_connect_inbox_unified','route'=>'dashboard.user.titan-connect.inbox.unified','label'=>'Unified Inbox','icon'=>'tabler-inbox','order'=>1],
            ['parent_key'=>'ext_titan_connect_inbox','key'=>'titan_connect_inbox_team','route'=>'dashboard.user.titan-connect.inbox.team','label'=>'Team / Internal','icon'=>'tabler-users-group','order'=>2],
            ['parent_key'=>'ext_titan_connect_inbox','key'=>'titan_connect_inbox_external','route'=>'dashboard.user.titan-connect.inbox.external','label'=>'External / Omnichannel','icon'=>'tabler-world','order'=>3],
            ['parent_key'=>'ext_titan_connect_inbox','key'=>'titan_connect_inbox_mine','route'=>'dashboard.user.titan-connect.inbox.mine','label'=>'Assigned to Me','icon'=>'tabler-user-check','order'=>4],
            ['parent_key'=>'ext_titan_connect_inbox','key'=>'titan_connect_inbox_unassigned','route'=>'dashboard.user.titan-connect.inbox.unassigned','label'=>'Unassigned','icon'=>'tabler-user-question','order'=>5],
            ['parent_key'=>'ext_titan_connect_inbox','key'=>'titan_connect_inbox_needs_human','route'=>'dashboard.user.titan-connect.inbox.needs_human','label'=>'Needs Human','icon'=>'tabler-hand-stop','order'=>6],
            ['parent_key'=>'ext_titan_connect_inbox','key'=>'titan_connect_inbox_closed','route'=>'dashboard.user.titan-connect.inbox.closed','label'=>'Closed / Archived','icon'=>'tabler-archive','order'=>7],

            ['parent_key'=>null,'key'=>'ext_titan_connect_channels','route'=>'dashboard.user.titan-connect.channels.index','label'=>'Channels','icon'=>'tabler-message-cog','order'=>7],
            ['parent_key'=>'ext_titan_connect_channels','key'=>'titan_connect_channel_whatsapp','route'=>'dashboard.user.titan-connect.channels.whatsapp','label'=>'WhatsApp','icon'=>'tabler-message','order'=>1],
            ['parent_key'=>'ext_titan_connect_channels','key'=>'titan_connect_channel_messenger','route'=>'dashboard.user.titan-connect.channels.messenger','label'=>'Messenger','icon'=>'tabler-message','order'=>2],
            ['parent_key'=>'ext_titan_connect_channels','key'=>'titan_connect_channel_instagram','route'=>'dashboard.user.titan-connect.channels.instagram','label'=>'Instagram','icon'=>'tabler-photo','order'=>3],
            ['parent_key'=>'ext_titan_connect_channels','key'=>'titan_connect_channel_telegram','route'=>'dashboard.user.titan-connect.channels.telegram','label'=>'Telegram','icon'=>'tabler-message','order'=>4],
            ['parent_key'=>'ext_titan_connect_channels','key'=>'titan_connect_channel_sms','route'=>'dashboard.user.titan-connect.channels.sms','label'=>'SMS','icon'=>'tabler-message','order'=>5],
            ['parent_key'=>'ext_titan_connect_channels','key'=>'titan_connect_channel_voice','route'=>'dashboard.user.titan-connect.channels.voice','label'=>'Voice','icon'=>'tabler-phone-call','order'=>6],
            ['parent_key'=>'ext_titan_connect_channels','key'=>'titan_connect_channel_push','route'=>'dashboard.user.titan-connect.channels.push','label'=>'Push / Mobile','icon'=>'tabler-bell-ringing','order'=>7],
        ];
    }

    /** @return array<int,array<string,mixed>> */
    private function adminDefinitions(): array
    {
        return [
            ['parent_key'=>null,'key'=>'admin_titan_connect_channels','route'=>'titan-connect.admin.channels.index','label'=>'Titan Connect','icon'=>'tabler-message-cog','order'=>60],
            ['parent_key'=>'admin_titan_connect_channels','key'=>'admin_titan_connect_channels_overview','route'=>'titan-connect.admin.channels.index','label'=>'Overview / Diagnostics','icon'=>'tabler-layout-dashboard','order'=>1],
            ['parent_key'=>'admin_titan_connect_channels','key'=>'admin_titan_connect_channel_whatsapp','route'=>'titan-connect.admin.channels.whatsapp','label'=>'WhatsApp','icon'=>'tabler-message','order'=>2],
            ['parent_key'=>'admin_titan_connect_channels','key'=>'admin_titan_connect_channel_messenger','route'=>'titan-connect.admin.channels.messenger','label'=>'Messenger','icon'=>'tabler-message','order'=>3],
            ['parent_key'=>'admin_titan_connect_channels','key'=>'admin_titan_connect_channel_instagram','route'=>'titan-connect.admin.channels.instagram','label'=>'Instagram','icon'=>'tabler-photo','order'=>4],
            ['parent_key'=>'admin_titan_connect_channels','key'=>'admin_titan_connect_channel_telegram','route'=>'titan-connect.admin.channels.telegram','label'=>'Telegram','icon'=>'tabler-message','order'=>5],
            ['parent_key'=>'admin_titan_connect_channels','key'=>'admin_titan_connect_channel_sms','route'=>'titan-connect.admin.channels.sms','label'=>'SMS','icon'=>'tabler-message','order'=>6],
            ['parent_key'=>'admin_titan_connect_channels','key'=>'admin_titan_connect_channel_voice','route'=>'titan-connect.admin.channels.voice','label'=>'Voice','icon'=>'tabler-phone-call','order'=>7],
            ['parent_key'=>'admin_titan_connect_channels','key'=>'admin_titan_connect_channel_push','route'=>'titan-connect.admin.channels.push','label'=>'Push / Mobile','icon'=>'tabler-bell-ringing','order'=>8],
        ];
    }

    private function safeIcon(string $icon): string
    {
        return in_array($icon, self::HOST_SAFE_ICONS, true) ? $icon : 'tabler-folders';
    }

    private function regenerateMenuCache(): void
    {
        $menuService = 'App\\Services\\Common\\MenuService';
        if (! class_exists($menuService) || ! function_exists('app')) {
            return;
        }

        try {
            $service = app($menuService);
            if (is_object($service) && method_exists($service, 'regenerate')) {
                $service->regenerate();
            }
        } catch (\Throwable $exception) {
            if (function_exists('report')) {
                report($exception);
            }
        }
    }
};
