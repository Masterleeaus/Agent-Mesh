# Titan CRM 1.3.0-alpha.21 — Integrity & Governance Report

## Objective

Strengthen Titan CRM as authoritative business state while closing confirmed mutation, replay, observability and automation-governance gaps without replacing useful existing functionality.

## Review findings validated against alpha.20

Several externally reported blockers were already implemented in alpha.20: explicit AI tool allowlists, expiring chatbot verification grants, negative/overpayment rejection, tenant-scoped payment allocation, cross-tenant merge prevention, recurring occurrence idempotency, monotonic fleet odometers, command idempotency payload fingerprints, entity version receipts, state-derived receipt hashes, recipient email validation and deferred communication delivery truth.

Alpha.21 therefore implements only confirmed gaps rather than adding duplicate controls.

## Architecture delivered

### 1. AI projection boundary

`CrmAiProjectionRegistry` defines versioned named projections. AI callers can request stable shapes such as customer summary, timeline, sales pipeline, job details, schedule context, invoice context and receivables context. The projection path selects only declared columns, strips internal relationship identifiers and does not expose `tenant_company_id`.

### 2. Tenant reference guard

`CrmTenantReferenceGuard` validates public-ID and user relationships against the current canonical `tenant_company_id` before governed mutation. Cross-tenant and missing references fail closed with the same not-found behavior. Ambiguous field names such as `location_public_id` are resolved by capability domain so Field and Locker references are not conflated.

### 3. Provider payment replay safety

Provider transaction identity is normalized and fingerprinted. Exact webhook/provider replay can return the original result; a reused provider transaction with different invoice, amount or currency is rejected.

### 4. Domain invariant hardening

`crm.work_order.assign` rejects overlapping worker appointments (while allowing the same work order's own appointment), and invoice create/issue rejects cancelled work orders. Invariant rejections are emitted after rollback as structured governance observations.

### 5. Receipt and concurrency v2

Receipts now include measured `command_duration_ms`, `affected_count`, `version_hint` and `receipt_integrity_hash`. Optimistic concurrency failures expose expected/current version, current state hash, retryability and remediation guidance.

### 6. Signal delivery reliability

CRM mutation + Signal outbox row remain atomic. Each event receives a deterministic `event_dedup_key`. Post-commit delivery uses a claim/retry/dead-letter lifecycle with exponential backoff through `CrmSignalDeliveryPort`; Titan Signal remains the external ingestion owner.

### 7. Automation governance

The legacy automation engine no longer executes domain services/repositories directly. Rule actions are translated to governed capability requests through `CrmCommandBusGateway`. Simulation returns planned commands without writes. Every action receives deterministic idempotency, `automation_chain_id` and `automation_depth`; recursion is bounded.

### 8. AI/chatbot/automation command rate limiting

A durable per-tenant, source, actor and capability limiter protects governed write entrypoints from command spam. Financial, communication, create and default buckets have distinct limits.

### 9. Import integrity v2

Imports are staged and relationship-validated first. A seven-day impact report records insert intent and constraint/relationship violations and is available through the governed `crm.import.report` capability. Non-dry-run authoritative rows execute in one database transaction, preventing half-imported batches when a domain write fails.

## Boundary decisions

Alpha.21 does not introduce Elasticsearch, a second ledger authority, or domain extraction. CQRS/read-store migration and Locker/Ledger/Field extraction require compatibility contracts and are scheduled as later architecture passes. This avoids replacing stable operational code before governed boundaries are ready.

## Acceptance contract

Alpha.21 is acceptable when:

- governed writes validate tenant references before mutation;
- provider transaction replay cannot duplicate or redirect payment state;
- AI projections expose explicit versioned fields only;
- automation cannot bypass Command Bus governance;
- command receipts expose execution/version/integrity evidence;
- stale writes expose actionable current-state information;
- Signal events are deduplicated and retained through delivery failure;
- AI/chatbot/automation writes are rate limited;
- authoritative import batches commit atomically;
- alpha.1-alpha.20 regression gates remain green.
