# Pass 11 — Titan Field Peer Bridge

Titan Maps Intelligence remains the spatial authority for worker GPS history, route/ETA evidence, geofences, route plans and provider-backed spatial calculations. Titan Field remains the operational authority for appointments, work orders, dispatch and Field routes.

## Optional peer contract

`FieldSpatialPeerGateway` exposes a bounded spatial API to Titan Field: health, latest worker positions, route/travel evidence, consent-bound worker location ingestion, graphical map payloads and map UI configuration.

`FieldSpatialPeerService` reads Maps-owned tracking/location stores and delegates routing to `RouteCalculationService`, location ingestion to `WorkerTrackingService`, and map rendering data to `MapViewDataService`. Field-team payloads include the existing live-refresh endpoint.

## Preferred Titan Field adapters

When `App\\Extensions\\TitanField\\System\\TitanFieldServiceProvider` is installed, Maps prefers:

- `TitanFieldReferenceGateway`
- `TitanFieldDispatchEvidenceGateway`
- `TitanFieldWorkerQualificationGateway`
- `TitanFieldDispatchAssignmentGateway`

The adapters read historical Field `crm_*` tables through the canonical tenant boundary. The dispatch assignment adapter never inserts into Field tables; it resolves Field's command gateway lazily and calls `titan.field.dispatch|assign_dispatch`.

When Titan Field is absent, the previous WorkCore/CRM/host bridges remain available so Maps still boots independently.

## No circular dependency

Maps contains no compile-time `use App\\Extensions\\TitanField...` dependency. Field presence is detected by string class/interface names at runtime. Titan Field applies the same rule in the opposite direction.
