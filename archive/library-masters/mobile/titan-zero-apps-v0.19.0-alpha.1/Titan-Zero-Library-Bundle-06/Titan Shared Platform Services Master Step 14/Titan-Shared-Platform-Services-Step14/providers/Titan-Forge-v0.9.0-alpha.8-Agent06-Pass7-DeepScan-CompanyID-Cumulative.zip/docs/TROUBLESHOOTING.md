# Titan Forge Troubleshooting

- **Build remains approval_required:** inspect Risk, Shield, Model Council, Governance and Command Bus gateway availability/reason codes. Missing Governance/Command Bus callable contracts intentionally hold execution.
- **Validation fails:** inspect persisted validation findings; correct the generated artifact and create a new validated candidate rather than bypassing validators.
- **Duplicate idempotency error:** the same tenant/idempotency key is bound to a different BuildSpec. Use the original payload or a new key.
- **Workspace path rejected:** only safe relative paths beneath the operation workspace are permitted.
- **Signal unavailable:** build generation can report degraded state, but canonical release evidence should not be treated as fully governed until Signal requirements are satisfied.
- **Manifest validation fails:** run the Blueprint v4.2 canonical validator and fix the source manifest/package; do not hand-edit final integrity hashes.
