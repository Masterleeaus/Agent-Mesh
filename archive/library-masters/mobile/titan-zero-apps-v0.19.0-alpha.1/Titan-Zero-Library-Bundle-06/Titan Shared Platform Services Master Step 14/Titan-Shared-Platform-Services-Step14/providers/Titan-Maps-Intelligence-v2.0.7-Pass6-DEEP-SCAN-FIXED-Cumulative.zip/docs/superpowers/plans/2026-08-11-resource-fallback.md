# Governed Resource Fallback Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Add an auditable contractor/supplier fallback pipeline that exhausts internal and approved-network options before Maps Discovery and requires human approval before CRM promotion.

**Architecture:** A `ResourceFallbackService` orchestrates existing Dispatch Intelligence, canonical Maps locations, Travel Matrix, Discovery Search, Candidate Review and Candidate Promotion services. Three new company-scoped tables persist request state, candidate evidence and human decisions; browser/API/AI surfaces expose the same guarded lifecycle.

**Tech Stack:** PHP 8.3, Laravel 10, Eloquent, existing Titan Maps graphical map engine, Travel Matrix, Discovery, candidate lifecycle and Titan capability registry.

## Global Constraints
- Preserve `titan-extension-v1` as the authoritative root installer manifest.
- Do not auto-create CRM supplier/contractor records.
- Do not auto-assign external resources.
- Straight-line fallback never becomes road ETA.
- Missing evidence remains unknown.
- All persistent records are company-scoped.

---

### Task 1: Pure fallback scoring and state contract
**Files:**
- Create: `DTO/ResourceFallbackScoreResult.php`
- Create: `Services/ResourceFallbackScoreService.php`
- Create: `scripts/test_resource_fallback_runtime.php`

**Interfaces:**
- Consumes candidate fit/travel/data evidence arrays.
- Produces deterministic total score, evidence, explanations and eligibility.

- [x] Write failing runtime test for source-order, unknown evidence, and road/ETA provenance.
- [x] Run it and verify failure because the scorer does not exist.
- [x] Implement the minimal scorer.
- [x] Run the runtime test and verify PASS.

### Task 2: Persistent fallback domain
**Files:**
- Create three migrations for requests/candidates/decisions.
- Create `Models/ResourceFallbackRequest.php`.
- Create `Models/ResourceFallbackCandidate.php`.
- Create `Models/ResourceFallbackDecision.php`.
- Modify `database/schema-contract.json` and migration smoke/verification files.

**Interfaces:**
- Request has many candidates/decisions.
- Candidate optionally links to `DiscoveryCandidate`.

- [x] Write architecture verifier assertions for all tables/models/tenant keys.
- [x] Verify RED.
- [x] Implement migrations/models/relations.
- [x] Verify schema/migration gates PASS.

### Task 3: Sourcing orchestration
**Files:**
- Create `Services/ResourceFallbackService.php`.
- Create `Services/ResourceFallbackCandidateEnricher.php`.

**Interfaces:**
- `start(resourceType, jobPublicId?, coordinates?, serviceKey?, query?, options): ResourceFallbackRequest`
- `refresh(ResourceFallbackRequest): ResourceFallbackRequest`
- `decide(ResourceFallbackRequest, candidateId, decision, reason?): ResourceFallbackDecision`
- `promote(ResourceFallbackRequest, candidateId, acceptedFields, execution): array`

- [x] Write failing architecture/runtime checks for internal -> approved network -> discovery order.
- [x] Verify RED.
- [x] Implement orchestration using existing dispatch, nearest-resource, discovery, review and promotion services.
- [x] Verify the workflow tests PASS.

### Task 4: HTTP, browser UI and graphical map
**Files:**
- Create `Http/Controllers/ResourceFallbackController.php`.
- Create request classes for start/decision/promotion.
- Create `resources/views/user/resource-fallback.blade.php`.
- Modify `routes/api.php`, `routes/user.php`, `Http/Controllers/UserNavigationController.php`.

**Interfaces:**
- Browser and API expose identical lifecycle actions.

- [x] Write route/navigation verifier assertions.
- [x] Verify RED.
- [x] Add routes/controller/view and graphical candidate markers.
- [x] Verify route/navigation checks PASS.

### Task 5: Menu, AI capabilities and release metadata
**Files:**
- Modify `System/Navigation/MapsMenuDefinition.php`.
- Create menu sync migration.
- Create four tool classes.
- Modify `Services/MapsCapabilityService.php`.
- Modify manifests/config/docs/version metadata.

**Interfaces:**
- Four fallback capabilities map to start/read/decide/promote permissions and tools.

- [x] Add failing capability/menu parity assertions.
- [x] Verify RED.
- [x] Register permissions/capabilities/menu migration.
- [x] Verify parity PASS.

### Task 6: Full regression and installer packaging
- [x] Run every standalone verifier/runtime script.
- [x] Run PHP/JS/JSON syntax checks.
- [x] Stage exact `TitanMapsIntelligence/` folder.
- [x] Regenerate inventory and SHA-256 manifest.
- [x] Validate hardened sidecar and secret/filesystem scan independently of root manifest.
- [x] Build flat-root alpha.16 ZIP.
- [x] Re-extract final ZIP and rerun all verification against packaged bytes.
