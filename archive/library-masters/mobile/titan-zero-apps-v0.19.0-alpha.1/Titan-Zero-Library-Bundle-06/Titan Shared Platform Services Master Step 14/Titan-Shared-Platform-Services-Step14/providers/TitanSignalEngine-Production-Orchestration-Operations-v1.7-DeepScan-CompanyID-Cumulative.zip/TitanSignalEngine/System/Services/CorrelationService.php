<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalCorrelationContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalHistoryQueryContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalHistoryTraversalContract;
use App\Extensions\TitanSignalEngine\System\Contracts\TraceProfileRegistryContract;
use App\Extensions\TitanSignalEngine\System\Data\RewindCorrelationReceipt;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalHistoryRecord;
use App\Extensions\TitanSignalEngine\System\Data\SignalHistoryWindow;
use InvalidArgumentException;

final class CorrelationService implements SignalCorrelationContract
{
    public function __construct(
        private readonly SignalHistoryQueryContract $history,
        private readonly SignalHistoryTraversalContract $traversal,
        private readonly TraceProfileRegistryContract $profiles,
        private readonly TraceAnalyzer $analyzer,
        private readonly HistoryCorrelationAssembler $assembler,
        private readonly ?TraceEvaluationProjector $evaluationProjector = null,
    ) {
    }

    public function ancestors(string $eventId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $maxDepth = 100): array
    {
        $anchor = $this->history->find($eventId, $context, $tenantCompanyId, $scope);
        if ($anchor === null) return [];

        $result = [];
        $seen = [$eventId => true];
        $current = $anchor;
        $maxDepth = $this->boundedDepth($maxDepth);
        for ($depth = 0; $depth < $maxDepth; $depth++) {
            $parentId = $this->causationId($current);
            if ($parentId === null || isset($seen[$parentId])) break;
            $parent = $this->history->find($parentId, $context, $tenantCompanyId, $scope);
            if ($parent === null) break;
            $seen[$parentId] = true;
            $result[] = $this->assembler->envelopes([$parent])[0];
            $current = $parent;
        }
        return $result;
    }

    public function descendants(string $eventId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $maxDepth = 100): array
    {
        $anchor = $this->history->find($eventId, $context, $tenantCompanyId, $scope);
        if ($anchor === null) return [];

        $maxDepth = $this->boundedDepth($maxDepth);
        $maxEvents = $this->maxResultLimit();
        $seen = [$eventId => true];
        $result = [];
        $frontier = [$eventId];

        for ($depth = 0; $depth < $maxDepth && $frontier !== [] && count($result) < $maxEvents; $depth++) {
            $next = [];
            $levelRecords = [];
            foreach ($frontier as $parentId) {
                foreach ($this->history->childrenOf($parentId, $context, $tenantCompanyId, $scope, $maxEvents) as $child) {
                    $childId = (string) ($child->event['event_id'] ?? '');
                    if ($childId === '' || isset($seen[$childId])) continue;
                    $seen[$childId] = true;
                    $levelRecords[] = $child;
                }
            }
            $level = $this->assembler->envelopes($levelRecords);
            foreach ($level as $child) {
                if (count($result) >= $maxEvents) break;
                $result[] = $child;
                $next[] = $child->eventId;
            }
            $frontier = $next;
        }
        return $result;
    }

    public function trace(string $traceId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, ?string $profileKey = null, ?int $profileVersion = null, int $limit = 1000): array
    {
        $window = $this->traversal->traceWindow($traceId, $context, $tenantCompanyId, $scope, $this->boundedLimit($limit));
        $events = $this->assembler->envelopes($window->records);
        $profile = null;
        if ($profileKey !== null) {
            $profile = $this->profiles->find($profileKey, $profileVersion);
            if ($profile === null) throw new InvalidArgumentException("Unknown Signal trace profile {$profileKey}.");
        }

        $analysis = $this->analyzer->analyze($events, $profile);
        $ordered = $analysis->orderedEvents;
        $analysisArray = $this->partialAwareAnalysis($analysis->toArray(), $window);
        $correlationIds = array_values(array_unique(array_map(static fn (SignalEnvelope $event): string => $event->correlationId, $ordered)));
        $roots = $this->rootIds($ordered);

        if (! $window->isPartial() && $profile !== null) {
            $this->evaluationProjector?->project(
                $traceId,
                count($correlationIds) === 1 ? $correlationIds[0] : null,
                $scope,
                $tenantCompanyId,
                $analysis,
            );
        }

        $receipt = $this->receipt(
            $scope,
            $tenantCompanyId,
            $traceId,
            count($correlationIds) === 1 ? $correlationIds[0] : null,
            $roots,
            $window,
        );

        return [
            'trace_id' => $traceId,
            'scope' => $scope,
            'tenant_company_id' => $tenantCompanyId,
            'profile' => $profile?->toArray(),
            ...$window->toArray(),
            'analysis' => $analysisArray,
            'events' => array_map(static fn (SignalEnvelope $event): array => $event->toArray(), $ordered),
            'event_storage' => $this->assembler->storageIndex($window->records),
            'edges' => $this->assembler->edges($window->records),
            'rewind' => $receipt->toArray(),
        ];
    }

    public function workflow(string $correlationId, SignalContext $context, ?int $tenantCompanyId = null, string $scope = SignalEnvelope::SCOPE_TENANT, int $limit = 1000): array
    {
        $window = $this->traversal->correlationWindow($correlationId, $context, $tenantCompanyId, $scope, $this->boundedLimit($limit));
        $events = $this->assembler->envelopes($window->records);
        $analysis = $this->analyzer->analyze($events, null);
        $ordered = $analysis->orderedEvents;

        $recordsById = [];
        foreach ($window->records as $record) $recordsById[(string) $record->event['event_id']] = $record;
        $grouped = [];
        foreach ($ordered as $event) $grouped[$event->traceId][] = $event;

        $traces = [];
        foreach ($grouped as $traceId => $traceEvents) {
            $traceAnalysis = $this->analyzer->analyze($traceEvents, null);
            $hot = 0;
            $cold = 0;
            foreach ($traceEvents as $event) {
                $tier = $recordsById[$event->eventId]->storageTier ?? 'hot';
                $tier === 'cold' ? $cold++ : $hot++;
            }
            $traces[] = [
                'trace_id' => $traceId,
                'event_count' => count($traceEvents),
                'hot_event_count' => $hot,
                'cold_event_count' => $cold,
                'storage_tier' => $hot > 0 && $cold > 0 ? 'mixed' : ($cold > 0 ? 'cold' : 'hot'),
                'root_causation_ids' => $this->rootIds($traceEvents),
                'analysis' => $traceAnalysis->toArray(),
            ];
        }

        $workflowAnalysis = $this->partialAwareAnalysis($analysis->toArray(), $window);
        $receipt = $this->receipt(
            $scope,
            $tenantCompanyId,
            count($traces) === 1 ? (string) $traces[0]['trace_id'] : null,
            $correlationId,
            $this->rootIds($ordered),
            $window,
        );

        return [
            'correlation_id' => $correlationId,
            'scope' => $scope,
            'tenant_company_id' => $tenantCompanyId,
            ...$window->toArray(),
            'trace_count' => count($traces),
            'analysis' => $workflowAnalysis,
            'traces' => $traces,
            'events' => array_map(static fn (SignalEnvelope $event): array => $event->toArray(), $ordered),
            'event_storage' => $this->assembler->storageIndex($window->records),
            'edges' => $this->assembler->edges($window->records),
            'rewind' => $receipt->toArray(),
        ];
    }

    /** @param array<string,mixed> $analysis */
    private function partialAwareAnalysis(array $analysis, SignalHistoryWindow $window): array
    {
        if ($window->isPartial() && ($analysis['status'] ?? '') !== 'invalid') $analysis['status'] = 'partial';
        $analysis['history_complete'] = ! $window->isPartial();
        $analysis['cold_history_complete'] = $window->integrityComplete();
        $analysis['cold_failure_count'] = count($window->coldFailures);
        return $analysis;
    }

    /** @param list<SignalEnvelope> $events @return list<string> */
    private function rootIds(array $events): array
    {
        $roots = [];
        foreach ($events as $event) $roots[$event->rootCausationId] = true;
        return array_keys($roots);
    }

    private function receipt(string $scope, ?int $tenantCompanyId, ?string $traceId, ?string $correlationId, array $roots, SignalHistoryWindow $window): RewindCorrelationReceipt
    {
        return new RewindCorrelationReceipt(
            $scope,
            $tenantCompanyId,
            $traceId,
            $correlationId,
            $roots,
            $window->totalEventCount,
            $window->hotEventCount,
            $window->coldEventCount,
            $window->integrityComplete(),
            count($window->coldFailures),
        );
    }

    private function causationId(SignalHistoryRecord $record): ?string
    {
        $value = $record->event['causation_id'] ?? null;
        return $value === null || $value === '' ? null : (string) $value;
    }

    private function boundedDepth(int $depth): int
    {
        $max = function_exists('config') ? (int) config('titan-signal-engine.max_causal_depth', 256) : 256;
        return max(1, min($depth, max(1, $max)));
    }

    private function boundedLimit(int $limit): int
    {
        return max(1, min($limit, $this->maxResultLimit()));
    }

    private function maxResultLimit(): int
    {
        return function_exists('config') ? max(1, (int) config('titan-signal-engine.max_graph_query_limit', 5000)) : 5000;
    }
}
