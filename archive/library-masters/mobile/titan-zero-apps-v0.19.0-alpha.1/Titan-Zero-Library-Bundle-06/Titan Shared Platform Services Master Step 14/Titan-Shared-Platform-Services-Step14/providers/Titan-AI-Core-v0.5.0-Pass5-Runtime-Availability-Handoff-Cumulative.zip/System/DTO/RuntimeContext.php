<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class RuntimeContext {
    /** @param array<string,mixed> $routingHints */
    public function __construct(public string $tenantCompanyId, public ActorContext $actor, public string $traceId, public string $correlationId, public string $causationId, public string $rootCausationId, public string $operationId, public string $idempotencyKey, public string $privacyClass = 'INTERNAL', public array $routingHints = []) {}
    public function toArray(): array { return ['tenant_company_id'=>$this->tenantCompanyId,'actor'=>$this->actor->toArray(),'trace_id'=>$this->traceId,'correlation_id'=>$this->correlationId,'causation_id'=>$this->causationId,'root_causation_id'=>$this->rootCausationId,'operation_id'=>$this->operationId,'idempotency_key'=>$this->idempotencyKey,'privacy_class'=>$this->privacyClass,'routing_hints'=>$this->routingHints]; }
}
