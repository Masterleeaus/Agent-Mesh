# Titan Pulse Metrics v0.5.0

Pulse is an eventually consistent operational read model derived from immutable Signal events. Dashboard/read queries use rollups and trace projections; they do not scan `titan_signal_events`.

## Windows and rollups

| Pulse window | Rollup granularity | Intended use |
|---|---|---|
| `5m` | minute | near-real-time operational pulse |
| `1h` | minute | short incident/activity view |
| `24h` | hour | daily operating view |
| `7d` | day | weekly trend view |

Buckets are UTC. Window edges have the precision of the selected rollup granularity, so Pulse is an operational aggregate rather than a forensic event counter. Exact reconstruction remains the responsibility of Signal Query/Correlation.

## Metrics

- `event_count`: all projected immutable events in the selected window.
- `event_rate_per_second`: `event_count / window_seconds`.
- `command_count`: events whose type begins with `command.`.
- `command_rate_per_second`: `command_count / window_seconds`.
- `error_count`: events with severity `ERROR`, `CRITICAL`, or `FATAL`.
- `critical_count`: events with severity `CRITICAL` or `FATAL`.
- `error_rate`: `error_count / event_count` when events exist.
- `risk_count`: category `risk` or event type beginning `risk.`.
- `governance_count`: category `governance` or event type beginning `governance.`.
- `assurance_count`: category `assurance`, `quality`, or `compliance`, or a `shield.` event.
- `autonomy_count`: category `autonomy` or event type beginning `autonomy.`.
- `subscription_failure_count`: immutable `signal.subscription.failed` events.
- `dead_letter_count`: current subscriber deliveries in terminal dead-letter state.
- `stalled_trace_count`: traces whose latest event is in the configured watched intermediate-event list, have not reached a configured terminal event, and have been inactive longer than `pulse_stalled_after_seconds` while remaining inside the stall horizon.
- `missing_receipt_count`: traces with `command.executed` but no `execution.receipt` after `pulse_missing_receipt_after_seconds`.

## Latency

Pulse stores trace-level projections and samples them without reading the raw event table.

- `trace_ms`: first-to-last `occurred_at` duration for traces that reached a configured terminal event.
- `command_receipt_ms`: `command.executed.occurred_at` to `execution.receipt.occurred_at`.
- P50/P95/P99 use deterministic nearest-rank percentiles.
- Samples are bounded by `pulse_latency_sample_limit` (default 5,000) to protect the operational query path.

Because the timestamps use event occurrence time rather than ingestion order, late Titan Go/offline synchronization does not inflate workflow latency merely because data arrived late.

## Attention score

The attention score is a deterministic prioritisation read model, not a Risk/Governance decision. It uses explicit reason codes from critical/error signals, dead letters, stalled traces, missing receipts, and subscription failures. Score is capped at 100 and mapped to `low`, `medium`, `high`, or `critical`.

Signal/Pulse does not authorize remediation. Other Titan engines decide whether to alert, reduce autonomy, block a command, or request human intervention.

## Projection recovery

Normal emission attempts Pulse projection after the immutable event transaction commits. Projection failure does not roll back the signal. Missed events are recovered with:

```text
titan:signal-pulse:project --limit=1000
```

The command runs every minute by default. `titan_signal_pulse_projected_events.event_id` makes replay idempotent.
