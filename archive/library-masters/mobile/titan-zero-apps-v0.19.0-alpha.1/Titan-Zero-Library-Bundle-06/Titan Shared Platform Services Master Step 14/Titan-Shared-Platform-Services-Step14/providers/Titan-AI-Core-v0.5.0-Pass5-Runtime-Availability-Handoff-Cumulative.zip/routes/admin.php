<?php

declare(strict_types=1);

use App\Extensions\TitanAICore\System\Http\Controllers\AdminController;
use App\Extensions\TitanAICore\System\Http\Controllers\HealthController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', AdminController::class)
    ->middleware('titan-ai-core.capability:ai.core.admin')
    ->name('index');
$router->get('/health', HealthController::class)
    ->middleware('titan-ai-core.capability:ai.core.health.read')
    ->name('health');
