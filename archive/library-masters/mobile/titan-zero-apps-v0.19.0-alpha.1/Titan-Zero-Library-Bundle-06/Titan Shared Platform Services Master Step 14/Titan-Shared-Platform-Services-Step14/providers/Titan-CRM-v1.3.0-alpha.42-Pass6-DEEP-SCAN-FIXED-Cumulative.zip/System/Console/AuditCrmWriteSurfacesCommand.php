<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\Governance\CrmWriteSurfaceAuditor;
use Illuminate\Console\Command;

final class AuditCrmWriteSurfacesCommand extends Command
{
    protected $signature='crm:governance:audit-writes {--json}';
    protected $description='Audit CRM HTTP and console write surfaces for Command Bus governance or explicit non-business exceptions.';

    public function handle(CrmWriteSurfaceAuditor $auditor): int
    {
        $report=$auditor->audit();
        if($this->option('json')){$this->line(json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR));}
        else{
            $this->info('CRM write-surface audit: '.strtoupper($report['status']));
            $this->line('HTTP mutation surfaces: '.count($report['http']));
            $this->line('Console surfaces: '.count($report['console']));
            foreach($report['failures'] as $failure)$this->error('Ungoverned: '.($failure['surface']??'unknown'));
        }
        return $report['status']==='pass'?self::SUCCESS:self::FAILURE;
    }
}
