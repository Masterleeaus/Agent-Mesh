# Failure Modes

Titan Autonomy v1.7.0 production contract. Runtime tenant boundary is `company_id`; Blueprint legacy manifest compatibility metadata is not a runtime tenant authority source.
