# Titan Prime v0.4.0 — Engine Gateway Layer

Titan Prime is Titan's governed strategic orchestrator. v0.4.0 adds typed engine gateway boundaries on top of the durable mission store without enabling autonomous orchestration, queues, model execution, or foreign-domain mutation.

## Implemented in this pass

- Prime-owned `EngineBridgeContract` as the single integration seam for external Titan engines
- default `FailClosedEngineBridge`; an unbound engine is unavailable, never implicitly approved
- typed gateways for Titan AI Core, Signal, Risk, Assurance, Autonomy, Governance, Rewind and Wisdom
- canonical engine identities aligned to Titan authority ownership (`titan-risk`, `titan-autonomy`, `titan-assurance`, `titan-governance`, `titan-signal`)
- caller-owned operation IDs on every engine request
- complete tenant/trace/correlation/causation/root-causation context on every request
- contract-versioned gateway request envelopes
- explicit gateway outcomes: `succeeded`, `denied`, `escalated`, `unavailable`, `failed`
- downstream exceptions converted to fail-closed results without leaking raw exception messages
- response identity validation so a bridge cannot return a receipt for a different engine/capability/operation
- recursive rejection of password/token/secret/authorization/signature fields at the Prime gateway boundary
- engine availability catalogue for health/readiness visibility
- service-provider bindings for all gateway contracts while allowing a host/integration provider to replace the bridge
- expanded host certification for gateway contract bindings
- Blueprint v4.2 / Manifest 2.2 / Installer 1.7.8 compliance retained

## Current capabilities

- `titan-prime`
- `prime.domain`
- `prime.mission.lifecycle`
- `prime.mission.persistence`
- `prime.mission.idempotency`
- `prime.mission.optimistic-locking`
- `prime.engine-gateway`
- `prime.engine-gateway.fail-closed`
- `prime.gateway.ai-core`
- `prime.gateway.signal`
- `prime.gateway.risk`
- `prime.gateway.assurance`
- `prime.gateway.autonomy`
- `prime.gateway.governance`
- `prime.gateway.rewind`
- `prime.gateway.wisdom`

## Important boundary

The gateway layer does **not** mean Prime is executing through these engines yet. The default bridge is deliberately unavailable. A trusted host/integration provider must bind `EngineBridgeContract` to public engine contracts before calls can succeed.

Prime still does not advertise autonomous planning, queue execution, Command Bus mutation, Nexus/Forge/Workforce commissioning, or automatic Signal event emission.

## Next pass

Build governed delegation: compose Risk → Assurance → Autonomy → Governance decisions and submit only approved delegation intents to the Command Bus boundary, with durable receipts and no authority inflation.
