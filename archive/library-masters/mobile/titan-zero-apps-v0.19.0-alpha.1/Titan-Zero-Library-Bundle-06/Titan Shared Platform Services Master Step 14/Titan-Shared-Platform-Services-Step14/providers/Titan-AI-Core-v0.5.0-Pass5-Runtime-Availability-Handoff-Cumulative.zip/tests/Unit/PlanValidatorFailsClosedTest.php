<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\Tests\Unit;
use App\Extensions\TitanAICore\System\DTO\ActorContext;
use App\Extensions\TitanAICore\System\DTO\ExecutionIntent;
use App\Extensions\TitanAICore\System\DTO\PlanEnvelope;
use App\Extensions\TitanAICore\System\DTO\RuntimeContext;
use App\Extensions\TitanAICore\System\Services\PlanValidator;
use PHPUnit\Framework\TestCase;
final class PlanValidatorFailsClosedTest extends TestCase {
    public function test_typed_validator_fails_closed_with_constructive_report(): void {
        $actor=new ActorContext('test','human','tenant',[],0,true);
        $ctx=new RuntimeContext('tenant',$actor,'trace','corr','cause','root','op','idem');
        $plan=new PlanEnvelope('plan',$ctx,new ExecutionIntent('test','test'));
        $result=(new PlanValidator())->validate($plan);
        self::assertFalse($result->valid); self::assertFalse($result->executable); self::assertSame('DAG_VALIDATOR_NOT_IMPLEMENTED',$result->errors[0]->code);
    }
}
