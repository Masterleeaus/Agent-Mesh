<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\Services\NegativeExecutionFeedbackPolicy;

$p = new NegativeExecutionFeedbackPolicy();
foreach (['approved_unchanged','autonomous_verified','correct'] as $forged) {
    try {$p->assertAllowed($forged); throw new RuntimeException('Positive client feedback must not be accepted: '.$forged);} catch (InvalidArgumentException $e) {}
}
foreach (['materially_corrected','reversed','failed','rejected','exception'] as $negative) {
    $p->assertAllowed($negative);
}

echo "OK: NegativeExecutionFeedbackSmokeTest\n";
