<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Repositories;

use App\Extensions\TitanAICore\System\Contracts\PlanRepositoryContract;
use App\Extensions\TitanAICore\System\DTO\PlanEnvelope;
use App\Extensions\TitanAICore\System\DTO\RuntimeContext;
use App\Extensions\TitanAICore\System\Security\TenantRuntimeGuard;
use Illuminate\Database\ConnectionInterface;

final class DatabasePlanRepository implements PlanRepositoryContract
{
    public function __construct(
        private readonly ConnectionInterface $database,
        private readonly TenantRuntimeGuard $tenantGuard,
    ) {}

    public function findForTenant(string $tenantCompanyId, string $planId): ?array
    {
        $row = $this->database->table('titan_ai_core_plans')
            ->where(function ($query) use ($tenantCompanyId): void {
                $query->where('company_id', $tenantCompanyId)->orWhere('tenant_company_id', $tenantCompanyId);
            })
            ->where('plan_id', $planId)
            ->first();

        return $row === null ? null : (array) $row;
    }

    public function storeForTenant(RuntimeContext $runtimeContext, PlanEnvelope $plan, string $status = 'draft'): void
    {
        $this->tenantGuard->assertTenant($plan->tenantCompanyId(), $runtimeContext);
        $now = date('Y-m-d H:i:s');
        $payload = $plan->toArray();

        $this->database->table('titan_ai_core_plans')->updateOrInsert(
            [
                'company_id' => $runtimeContext->tenantCompanyId,
                'plan_id' => $plan->planId,
            ],
            [
                'tenant_company_id' => $runtimeContext->tenantCompanyId,
                'company_id' => $runtimeContext->tenantCompanyId,
                'actor_id' => $runtimeContext->actor->actorId,
                'actor_type' => $runtimeContext->actor->actorType,
                'authority_level' => $runtimeContext->actor->authority->level,
                'principal_source' => $runtimeContext->actor->authority->source,
                'operation_id' => $runtimeContext->operationId,
                'trace_id' => $runtimeContext->traceId,
                'correlation_id' => $runtimeContext->correlationId,
                'causation_id' => $runtimeContext->causationId,
                'root_causation_id' => $runtimeContext->rootCausationId,
                'idempotency_key' => $runtimeContext->idempotencyKey,
                'intent' => json_encode($plan->intent->toArray(), JSON_THROW_ON_ERROR),
                'status' => $status,
                'plan' => json_encode($payload, JSON_THROW_ON_ERROR),
                'schema_version' => $plan->schemaVersion,
                'plan_schema_version' => $plan->planSchemaVersion,
                'runtime_version' => $plan->runtimeVersion,
                'updated_at' => $now,
                'created_at' => $now,
            ]
        );
    }
}
