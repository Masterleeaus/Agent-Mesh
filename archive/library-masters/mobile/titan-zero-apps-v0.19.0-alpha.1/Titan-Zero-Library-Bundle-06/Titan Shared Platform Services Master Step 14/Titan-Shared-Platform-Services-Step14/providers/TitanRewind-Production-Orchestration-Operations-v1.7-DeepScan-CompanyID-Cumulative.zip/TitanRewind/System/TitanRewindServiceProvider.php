<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanRewind\System\Contracts\RewindGovernanceGatewayContract;
use App\Extensions\TitanRewind\System\Contracts\RewindSignalTransportContract;
use App\Extensions\TitanRewind\System\Signal\UnavailableRewindSignalTransport;
use App\Extensions\TitanRewind\System\Runtime\RewindFailureClassifier;
use App\Extensions\TitanRewind\System\Resilience\RewindCircuitBreaker;
use App\Extensions\TitanRewind\System\Health\RewindHealthCheck;
use App\Extensions\TitanRewind\System\Services\RewindRuntimeStateService;
use App\Extensions\TitanRewind\System\Services\RewindTelemetryService;
use App\Extensions\TitanRewind\System\Services\RewindDeadLetterService;
use App\Extensions\TitanRewind\System\Services\RewindCircuitBreakerService;
use App\Extensions\TitanRewind\System\Services\RewindSignalOutboxService;
use App\Extensions\TitanRewind\System\Services\RewindQueueAdmissionService;
use App\Extensions\TitanRewind\System\Contracts\RewindEvidenceSignerContract;
use App\Extensions\TitanRewind\System\Contracts\RewindEvidenceKeyringContract;
use App\Extensions\TitanRewind\System\Evidence\RotatingOpenSslRewindEvidenceSigner;
use App\Extensions\TitanRewind\System\Sources\RewindHostSourceDiscovery;
use App\Extensions\TitanRewind\System\Artifacts\RewindHistoricalArtifactArchive;
use App\Extensions\TitanRewind\System\Artifacts\RewindHostArtifactDiscovery;
use App\Extensions\TitanRewind\System\Retention\RewindRetentionPolicy;
use App\Extensions\TitanRewind\System\Services\RewindRetentionService;
use App\Extensions\TitanRewind\System\Services\RewindSigningKeyService;
use App\Extensions\TitanRewind\System\Console\RunRewindRetentionCommand;
use App\Extensions\TitanRewind\System\Console\RunRewindCertificationCommand;
use App\Extensions\TitanRewind\System\Certification\RewindHostReadinessReport;
use App\Extensions\TitanRewind\System\Certification\RewindPerformanceBudget;
use App\Extensions\TitanRewind\System\Certification\RewindFaultMatrix;
use App\Extensions\TitanRewind\System\Certification\RewindDisasterRecoveryContract;
use App\Extensions\TitanRewind\System\Streaming\RewindTraceStream;
use App\Extensions\TitanRewind\System\Services\RewindEvidenceStreamService;
use Illuminate\Console\Scheduling\Schedule;
use App\Extensions\TitanRewind\System\Http\Middleware\RequireRewindPermission;
use App\Extensions\TitanRewind\System\Security\RewindAuthorization;
use App\Extensions\TitanRewind\System\Sources\RewindSourceCompleteness;
use App\Extensions\TitanRewind\System\Services\RewindCustodyService;
use App\Extensions\TitanRewind\System\Services\RewindLegalHoldService;
use App\Extensions\TitanRewind\System\Services\RewindSourceWatermarkService;
use App\Extensions\TitanRewind\System\Retention\RewindLegalHoldGuard;
use App\Extensions\TitanRewind\System\Contracts\RewindManagerContract;
use App\Extensions\TitanRewind\System\Forensics\RewindDriftRules;
use App\Extensions\TitanRewind\System\Forensics\RewindIntegrityHasher;
use App\Extensions\TitanRewind\System\Forensics\RewindRootCauseAnalyzer;
use App\Extensions\TitanRewind\System\Forensics\RewindTemporalDiagnostics;
use App\Extensions\TitanRewind\System\Audit\RewindEvidenceAssembler;
use App\Extensions\TitanRewind\System\AI\RewindToolCatalogue;
use App\Extensions\TitanRewind\System\Replay\RewindArtifactResolverRegistry;
use App\Extensions\TitanRewind\System\Replay\RewindStructuralComparisonEngine;
use App\Extensions\TitanRewind\System\Replay\RejectingReplayCommandGateway;
use App\Extensions\TitanRewind\System\Governance\FailClosedRewindGovernanceGateway;
use App\Extensions\TitanRewind\System\Recovery\RewindRecoveryPlanner;
use App\Extensions\TitanRewind\System\Navigation\NavigationRegistrar;
use App\Extensions\TitanRewind\System\Reconstruction\RewindDependencyExtractor;
use App\Extensions\TitanRewind\System\Reconstruction\RewindDiffService;
use App\Extensions\TitanRewind\System\Reconstruction\RewindSourceAdapterRegistry;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTimelineAssembler;
use App\Extensions\TitanRewind\System\Services\RewindCaseService;
use App\Extensions\TitanRewind\System\Services\RewindAssistantService;
use App\Extensions\TitanRewind\System\Services\RewindAnalyticsService;
use App\Extensions\TitanRewind\System\Services\RewindDependencyService;
use App\Extensions\TitanRewind\System\Services\RewindDriftService;
use App\Extensions\TitanRewind\System\Services\RewindEventStore;
use App\Extensions\TitanRewind\System\Services\RewindEvidencePackageService;
use App\Extensions\TitanRewind\System\Services\RewindComplianceExportService;
use App\Extensions\TitanRewind\System\Services\RewindRecoveryPlanService;
use App\Extensions\TitanRewind\System\Services\RewindGovernanceService;
use App\Extensions\TitanRewind\System\Services\RewindForensicsService;
use App\Extensions\TitanRewind\System\Services\RewindIntegrityService;
use App\Extensions\TitanRewind\System\Services\RewindManager;
use App\Extensions\TitanRewind\System\Services\RewindReconstructionService;
use App\Extensions\TitanRewind\System\Services\RewindReplayService;
use App\Extensions\TitanRewind\System\Services\RewindSnapshotComparisonService;
use App\Extensions\TitanRewind\System\Services\RewindSnapshotService;
use App\Extensions\TitanRewind\System\Services\RewindTenantContextResolver;
use App\Extensions\TitanRewind\System\Services\RewindTimelineService;
use App\Extensions\TitanRewind\System\Services\RewindTraceProjector;
use App\Extensions\TitanRewind\System\Support\CanonicalJson;
use App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

final class TitanRewindServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->app->singleton(\App\Extensions\TitanRewind\System\Workforce\CrossExtensionOrchestrator::class, static fn (): \App\Extensions\TitanRewind\System\Workforce\CrossExtensionOrchestrator => new \App\Extensions\TitanRewind\System\Workforce\CrossExtensionOrchestrator('TitanRewind'));
        $this->app->singleton(\App\Extensions\TitanRewind\System\Workforce\WorkforceLoopRuntime::class, static fn (): \App\Extensions\TitanRewind\System\Workforce\WorkforceLoopRuntime => \App\Extensions\TitanRewind\System\Workforce\WorkforceLoopRuntime::fromContractFile(__DIR__ . '/../workforce-integration.json'));
        $this->app->singleton(\App\Extensions\TitanRewind\System\Workforce\ProviderDiscovery::class, fn (): \App\Extensions\TitanRewind\System\Workforce\ProviderDiscovery => \App\Extensions\TitanRewind\System\Workforce\ProviderDiscovery::fromContractFile($this->app, __DIR__ . '/../workforce-integration.json'));

        $this->app->singleton(\App\Extensions\TitanRewind\System\Workforce\DurableHandoffStoreContract::class, static fn (): \App\Extensions\TitanRewind\System\Workforce\DurableHandoffStoreContract => new \App\Extensions\TitanRewind\Persistence\Workforce\DatabaseDurableHandoffStore());
        $this->app->singleton(\App\Extensions\TitanRewind\System\Workforce\PersistentOrchestrationRuntime::class, static fn ($app): \App\Extensions\TitanRewind\System\Workforce\PersistentOrchestrationRuntime => new \App\Extensions\TitanRewind\System\Workforce\PersistentOrchestrationRuntime($app->make(\App\Extensions\TitanRewind\System\Workforce\CrossExtensionOrchestrator::class), $app->make(\App\Extensions\TitanRewind\System\Workforce\DurableHandoffStoreContract::class)));
        $this->app->singleton(\App\Extensions\TitanRewind\System\Workforce\OrchestrationOperations::class, static fn ($app): \App\Extensions\TitanRewind\System\Workforce\OrchestrationOperations => new \App\Extensions\TitanRewind\System\Workforce\OrchestrationOperations($app->make(\App\Extensions\TitanRewind\System\Workforce\PersistentOrchestrationRuntime::class), $app->make(\App\Extensions\TitanRewind\System\Workforce\DurableHandoffStoreContract::class)));
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-rewind.php', 'titan-rewind');
        $this->app->singleton(RewindPayloadSanitizer::class, fn () => new RewindPayloadSanitizer((array) config('titan-rewind.redacted_keys', [])));
        $this->app->singleton(RewindTemporalDiagnostics::class, fn () => new RewindTemporalDiagnostics((int) config('titan-rewind.forensics.late_event_threshold_seconds', 300)));
        if (!$this->app->bound(RewindGovernanceGatewayContract::class)) {
            $this->app->singleton(RewindGovernanceGatewayContract::class, FailClosedRewindGovernanceGateway::class);
        }
        if (!$this->app->bound(RewindSignalTransportContract::class)) {
            $this->app->singleton(RewindSignalTransportContract::class, UnavailableRewindSignalTransport::class);
        }
        $this->app->singleton(RewindFailureClassifier::class);
        $this->app->singleton(RewindCircuitBreaker::class, fn () => new RewindCircuitBreaker(
            (int) config('titan-rewind.circuit_breaker.failure_threshold', 5),
            (int) config('titan-rewind.circuit_breaker.reset_seconds', 60),
        ));
        if (!$this->app->bound(RewindEvidenceKeyringContract::class)) {
            $this->app->singleton(RewindEvidenceKeyringContract::class, fn () => new RotatingOpenSslRewindEvidenceSigner(
                (array) config('titan-rewind.evidence.keyring.keys', []),
                (string) config('titan-rewind.evidence.keyring.active_key_id', 'titan-rewind-default'),
            ));
        }
        if (!$this->app->bound(RewindEvidenceSignerContract::class)) {
            $this->app->singleton(RewindEvidenceSignerContract::class, fn ($app) => $app->make(RewindEvidenceKeyringContract::class));
        }
        $this->app->singleton(RewindRetentionPolicy::class, fn () => new RewindRetentionPolicy((array) config('titan-rewind.retention.classes', [])));
        $this->app->singleton(RewindSourceCompleteness::class, fn () => new RewindSourceCompleteness((int) config('titan-rewind.source_freshness.max_age_seconds', 900)));
        foreach ([
            CanonicalJson::class, RewindIntegrityHasher::class, RewindRootCauseAnalyzer::class, RewindDriftRules::class, RewindEvidenceAssembler::class, RewindRecoveryPlanner::class, RewindTimelineAssembler::class, RewindDiffService::class, RewindDependencyExtractor::class,
            RewindSourceAdapterRegistry::class, RewindHostSourceDiscovery::class, RewindTraceStream::class, RewindHostReadinessReport::class, RewindPerformanceBudget::class, RewindFaultMatrix::class, RewindDisasterRecoveryContract::class, RewindSourceWatermarkService::class, RewindHostArtifactDiscovery::class, RewindHistoricalArtifactArchive::class, RewindSigningKeyService::class, RewindRetentionService::class, RewindRuntimeStateService::class, RewindTelemetryService::class, RewindDeadLetterService::class, RewindCircuitBreakerService::class, RewindSignalOutboxService::class, RewindQueueAdmissionService::class, RewindHealthCheck::class, RewindArtifactResolverRegistry::class, RewindStructuralComparisonEngine::class, RejectingReplayCommandGateway::class, RewindToolCatalogue::class, RewindTenantContextResolver::class, RewindAuthorization::class, RewindLegalHoldGuard::class, RewindCustodyService::class, RewindLegalHoldService::class, RewindTraceProjector::class, RewindCaseService::class, RewindAssistantService::class, RewindAnalyticsService::class,
            RewindTimelineService::class, RewindSnapshotService::class, RewindSnapshotComparisonService::class, RewindDependencyService::class, RewindIntegrityService::class, RewindDriftService::class, RewindForensicsService::class, RewindEventStore::class,
            RewindReconstructionService::class, RewindReplayService::class, RewindEvidencePackageService::class, RewindEvidenceStreamService::class, RewindComplianceExportService::class, RewindRecoveryPlanService::class, RewindGovernanceService::class,
        ] as $service) $this->app->singleton($service);
        $this->app->singleton(RewindManagerContract::class, RewindManager::class);
        if ($this->app->runningInConsole()) $this->commands([RunRewindRetentionCommand::class, RunRewindCertificationCommand::class]);
    }

    public function boot(): void
    {
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-rewind');
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->publishes([__DIR__ . '/../config/titan-rewind.php' => config_path('titan-rewind.php')], 'titan-rewind-config');
        /** @var Router $router */
        $router = $this->app['router'];
        $router->aliasMiddleware('titan-rewind.permission', RequireRewindPermission::class);
        $this->registerRoutes();
        NavigationRegistrar::register($this->app);
        if ((bool) config('titan-rewind.retention.schedule_enabled', true)) {
            $this->app->booted(function (): void {
                if (!$this->app->bound(Schedule::class)) return;
                $this->app->make(Schedule::class)->command('titan-rewind:retention')->dailyAt((string) config('titan-rewind.retention.schedule_at','03:40'))->onOneServer()->withoutOverlapping(180);
            });
        }
    }

    public function registerKey(): string { return 'titan-rewind'; }

    public static function uninstall(): void { File::delete(config_path('titan-rewind.php')); }

    private function registerRoutes(): void
    {
        /** @var Router $router */
        $router = $this->app['router'];
        $router->group(['middleware'=>['web','auth'],'prefix'=>'dashboard/user/titan-rewind','as'=>'dashboard.user.titan.rewind.'], static function (Router $router): void { require __DIR__ . '/../routes/user.php'; });
        $router->group(['middleware'=>['web','auth','admin'],'prefix'=>'dashboard/admin/titan-rewind','as'=>'dashboard.admin.titan.rewind.'], static function (Router $router): void { require __DIR__ . '/../routes/admin.php'; });
    }
}
