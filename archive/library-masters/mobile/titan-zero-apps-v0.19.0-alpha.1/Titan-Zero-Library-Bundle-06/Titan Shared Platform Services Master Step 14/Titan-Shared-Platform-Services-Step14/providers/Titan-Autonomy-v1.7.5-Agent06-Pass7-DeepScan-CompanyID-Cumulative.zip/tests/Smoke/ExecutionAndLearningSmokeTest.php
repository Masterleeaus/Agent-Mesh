<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\RiskClass;
use App\Extensions\TitanAutonomy\System\Services\ExecutionAuthorityGuard;
use App\Extensions\TitanAutonomy\System\Services\SystemLearningProjector;

function must(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}

$guard = new ExecutionAuthorityGuard();
$auto = new CapabilityState(
    tenantCompanyId: 7,
    capability: 'crm.invoice.issue',
    workflowKey: 'completed_job_invoice',
    risk: RiskClass::Medium,
    currentLevel: AutonomyLevel::Auto,
    requiredSuccessStreak: 2,
    scope: [
        'workflow' => 'completed_job_invoice',
        'max_total' => 1500,
        'requires_no_dispute' => true,
        'requires_job_completed' => true,
    ],
);

$allowed = $guard->evaluate($auto, [
    'workflow' => 'completed_job_invoice',
    'total' => 900,
    'has_dispute' => false,
    'job_completed' => true,
], actorPermissionValid: true, interactionReady: true, integrationHealthy: true, assuranceStatus: 'GREEN');
must($allowed->allowed, 'healthy in-scope Auto execution should pass authority guard');

$blocked = $guard->evaluate($auto, [
    'workflow' => 'completed_job_invoice',
    'total' => 1900,
    'has_dispute' => false,
    'job_completed' => true,
], actorPermissionValid: true, interactionReady: true, integrationHealthy: true, assuranceStatus: 'GREEN');
must(!$blocked->allowed && in_array('MAX_TOTAL_EXCEEDED', $blocked->reasonCodes, true), 'scope drift must block autonomous execution');

$red = $guard->evaluate($auto, [
    'workflow' => 'completed_job_invoice',
    'total' => 900,
    'has_dispute' => false,
    'job_completed' => true,
], actorPermissionValid: true, interactionReady: true, integrationHealthy: true, assuranceStatus: 'RED');
must(!$red->allowed && in_array('ASSURANCE_RED', $red->reasonCodes, true), 'Assurance RED must block autonomous execution');

$suggest = new CapabilityState(7, 'crm.invoice.issue', 'completed_job_invoice', RiskClass::Medium, AutonomyLevel::Suggest, 2);
$noAuthority = $guard->evaluate($suggest, ['workflow' => 'completed_job_invoice'], true, true, true, 'GREEN');
must(!$noAuthority->allowed && in_array('LEVEL_CANNOT_EXECUTE', $noAuthority->reasonCodes, true), 'Suggest may never execute governed actions');


$ceilingBlocked = $guard->evaluate($auto, [
    'workflow' => 'completed_job_invoice',
    'total' => 900,
    'has_dispute' => false,
    'job_completed' => true,
], actorPermissionValid: true, interactionReady: true, integrationHealthy: true, assuranceStatus: 'GREEN', maximumAllowedLevel: AutonomyLevel::SemiAuto);
must(!$ceilingBlocked->allowed && in_array('POLICY_CEILING_EXCEEDED', $ceilingBlocked->reasonCodes, true), 'current policy ceiling must block stale higher authority before execution');

$projected = (new SystemLearningProjector())->project([
    'tenant_company_id' => 7,
    'user_id' => 99,
    'customer_name' => 'Private Customer',
    'message' => 'raw private text',
    'capability' => 'crm.invoice.issue',
    'workflow_key' => 'completed_job_invoice',
    'risk' => 'medium',
    'learning_label' => 'materially_corrected',
    'reason_codes' => ['MISSING_VARIATION'],
    'tool_key' => 'crm.invoice.issue',
    'error_code' => null,
    'context_dimensions' => ['vertical' => 'plumbing', 'value_band' => '500_1500'],
]);
must(!array_key_exists('tenant_company_id', $projected), 'system projection must not contain tenant id');
must(!array_key_exists('customer_name', $projected), 'system projection must not contain raw private customer data');
must(($projected['context_dimensions']['vertical'] ?? null) === 'plumbing', 'approved abstract dimensions should remain');

echo "OK: ExecutionAndLearningSmokeTest\n";
