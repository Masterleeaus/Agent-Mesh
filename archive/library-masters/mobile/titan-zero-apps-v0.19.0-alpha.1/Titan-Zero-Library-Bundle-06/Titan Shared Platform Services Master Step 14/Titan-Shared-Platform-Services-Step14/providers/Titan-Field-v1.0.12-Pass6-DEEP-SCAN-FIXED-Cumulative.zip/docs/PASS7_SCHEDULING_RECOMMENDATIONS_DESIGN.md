# Pass 7 — Scheduling Kernel v2 + Explainable Technician Matching

Titan Field keeps `SchedulingKernel` as the deterministic hard-constraint authority. Candidate workers must pass tenant membership, active worker status, availability/time-off, blackout policies, required skills, overlap/travel buffer, daily capacity and configured service-area constraints before they can be recommended.

`TechnicianRecommendationService` is a read-only, non-authoritative layer. Eligible workers receive a bounded 0–100 score with explicit components for skills, remaining capacity, service-area fit, deterministic travel proximity and customer/location continuity. Ineligible workers receive score 0 and the hard-kernel rejection reason. Choosing a recommendation does not mutate state; assignments still flow through the governed command gateway.

The initial travel estimator is deliberately offline/deterministic Haversine distance with a conservative urban duration estimate. A future routing provider can replace it behind the same service without changing recommendation consumers.
