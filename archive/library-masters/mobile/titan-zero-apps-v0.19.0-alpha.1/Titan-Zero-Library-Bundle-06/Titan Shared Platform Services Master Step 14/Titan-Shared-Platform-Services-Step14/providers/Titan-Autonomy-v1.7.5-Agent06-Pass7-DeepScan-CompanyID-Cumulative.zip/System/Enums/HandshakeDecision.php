<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Enums;

enum HandshakeDecision: string
{
    case Approved = 'approved';
    case Denied = 'denied';
    case Pending = 'pending';
}
