# Titan CRM Core Production Hardening Design

## Objective
Make the extracted Titan CRM Core independently deployable and safe to operate as the authoritative customer/sales/commercial state owner without reclaiming Titan Field, Locker, Ledger, Pay, or Titan Autonomy ownership.

## Boundary
CRM Core owns customers, organisations, contacts, leads, deals, pipelines, projects/tasks/calendar, quotes, estimates, invoices, commercial history, portal grants, CRM metadata, imports/exports, integrations, and normalized read projections. Extracted operational domains remain optional dependencies and are resolved only through explicit compatibility bridges.

## Mutation Architecture
Authoritative web, portal, chatbot-settings, import, sharing, and integration mutations enter the governed Command Bus gateway. Production defaults disable local human mutation fallback. Command Bus absence therefore blocks writes rather than silently bypassing governance.

## Security
Tenant isolation remains fail-closed through `tenant_company_id`. Portal uploads require a real malware scanner in production. API-key rotation/revocation is auditable. Webhook deliveries use timestamped signed payloads plus deterministic idempotency metadata. Customer portal grants are bounded and token material is stored hash-only.

## Commercial Integrity
Lead conversion persists forensic mapping. Quotes/estimates capture pricing, tax and terms snapshots and explicit expiry. Expired quotes cannot be accepted. Generic payment mutation routes remain closed; payment writes use the dedicated governed payment capability.

## Deployment
CRM Core boots without extracted domains, exposes only Core menu routes, and uses a split-aware production verifier. `crm:production-check` blocks write-enabled production when Command Bus, Signal delivery, required schema, mobile sync secret, or malware scanner bindings are missing.

## Verification
The release package must pass extraction-boundary checks, the alpha.25 production contract, standalone deterministic tests, exact SHA-256 inventory validation, and syntax lint for every PHP source file from a clean ZIP extraction.
