# Pass 9 — SLA and Operational Exceptions

Titan Field owns an append-safe operational exception queue. Automatic detection is deliberately limited to evidence-backed signals available in the current domain: late appointments, probable no-shows, and service-request SLA risk. Other supported types can be opened explicitly by governed system/user flows when evidence exists.

Lifecycle: open → acknowledged/assigned → resolved → closed. All state changes are tenant-scoped, transactionally recorded in exception history, and emitted to the Titan Field Signal outbox. Corrective work-order, scheduling, or dispatch mutations remain separate governed commands.
