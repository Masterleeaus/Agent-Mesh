<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\CanonicalJson;
use InvalidArgumentException;

final class CompiledTitanConfig
{
    /** @param array<string, mixed> $sections */
    public function __construct(
        private readonly int $tenantCompanyId,
        private readonly string $configurationVersion,
        private readonly string $compilerVersion,
        private readonly string $verticalId,
        private readonly string $verticalVersion,
        private readonly ?string $knowledgeSnapshotVersion,
        private readonly string $sourceProfileHash,
        private readonly ?string $sourceVerticalHash,
        private readonly array $sections,
    ) {
        if ($this->tenantCompanyId <= 0) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }

        self::assertRequired($this->configurationVersion, 'configuration_version', 80);
        self::assertRequired($this->compilerVersion, 'compiler_version', 80);
        self::assertRequired($this->verticalId, 'vertical_id', 120);
        self::assertRequired($this->verticalVersion, 'vertical_version', 80);

        if ($this->knowledgeSnapshotVersion !== null) {
            self::assertRequired($this->knowledgeSnapshotVersion, 'knowledge_snapshot_version', 120);
        }

        if (preg_match('/^[0-9a-f]{64}$/i', $this->sourceProfileHash) !== 1) {
            throw new InvalidArgumentException('source_profile_hash must be a SHA-256 hex digest.');
        }

        if ($this->sourceVerticalHash !== null && preg_match('/^[0-9a-f]{64}$/i', $this->sourceVerticalHash) !== 1) {
            throw new InvalidArgumentException('source_vertical_hash must be null or a SHA-256 hex digest.');
        }
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $sections = $data['sections'] ?? [];
        if (!is_array($sections)) {
            throw new InvalidArgumentException('sections must be an object-like array.');
        }

        $knowledgeVersion = $data['knowledge_snapshot_version'] ?? null;
        if ($knowledgeVersion !== null && !is_string($knowledgeVersion)) {
            throw new InvalidArgumentException('knowledge_snapshot_version must be null or a string.');
        }

        $instance = new self(
            self::positiveInt($data['tenant_company_id'] ?? null, 'tenant_company_id'),
            self::requiredString($data['configuration_version'] ?? null, 'configuration_version'),
            self::requiredString($data['compiler_version'] ?? null, 'compiler_version'),
            self::requiredString($data['vertical_id'] ?? null, 'vertical_id'),
            self::requiredString($data['vertical_version'] ?? null, 'vertical_version'),
            $knowledgeVersion === null ? null : trim($knowledgeVersion),
            self::requiredString($data['source_profile_hash'] ?? null, 'source_profile_hash'),
            isset($data['source_vertical_hash']) ? self::requiredString($data['source_vertical_hash'], 'source_vertical_hash') : (isset($data['vertical_definition_hash']) ? self::requiredString($data['vertical_definition_hash'], 'vertical_definition_hash') : null),
            $sections,
        );

        $providedHash = $data['output_hash'] ?? null;
        if ($providedHash !== null && (!is_string($providedHash) || !hash_equals(strtolower($providedHash), $instance->outputHash()))) {
            throw new InvalidArgumentException('output_hash does not match the canonical compiled configuration.');
        }

        return $instance;
    }

    public function tenantCompanyId(): int
    {
        return $this->tenantCompanyId;
    }

    public function configurationVersion(): string
    {
        return $this->configurationVersion;
    }

    public function compilerVersion(): string
    {
        return $this->compilerVersion;
    }

    public function verticalId(): string
    {
        return $this->verticalId;
    }

    public function verticalVersion(): string
    {
        return $this->verticalVersion;
    }

    public function knowledgeSnapshotVersion(): ?string
    {
        return $this->knowledgeSnapshotVersion;
    }

    public function sourceProfileHash(): string
    {
        return $this->sourceProfileHash;
    }

    public function sourceVerticalHash(): ?string
    {
        return $this->sourceVerticalHash;
    }

    /** @return array<string, mixed> */
    public function sections(): array
    {
        return $this->sections;
    }

    public function outputHash(): string
    {
        return hash('sha256', CanonicalJson::encode($this->withoutOutputHash()));
    }

    /** @return array<string,mixed> */
    public function toContractArray(): array
    {
        if ($this->sourceVerticalHash === null) {
            throw new InvalidArgumentException('Blueprint v2.2 compiled-config export requires vertical_definition_hash provenance.');
        }
        return [
            'tenant_company_id' => $this->tenantCompanyId,
            'configuration_version' => $this->configurationVersion,
            'compiler_version' => $this->compilerVersion,
            'vertical_id' => $this->verticalId,
            'vertical_version' => $this->verticalVersion,
            'knowledge_snapshot_version' => $this->knowledgeSnapshotVersion,
            'source_profile_hash' => strtolower($this->sourceProfileHash),
            'vertical_definition_hash' => strtolower($this->sourceVerticalHash),
            'sections' => $this->sections,
            'output_hash' => $this->outputHash(),
        ];
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return $this->withoutOutputHash() + ['output_hash' => $this->outputHash()];
    }

    /** @return array<string, mixed> */
    private function withoutOutputHash(): array
    {
        $data = [
            'tenant_company_id' => $this->tenantCompanyId,
            'configuration_version' => $this->configurationVersion,
            'compiler_version' => $this->compilerVersion,
            'vertical_id' => $this->verticalId,
            'vertical_version' => $this->verticalVersion,
            'knowledge_snapshot_version' => $this->knowledgeSnapshotVersion,
            'source_profile_hash' => strtolower($this->sourceProfileHash),
            'sections' => $this->sections,
        ];

        if ($this->sourceVerticalHash !== null) {
            $data['source_vertical_hash'] = strtolower($this->sourceVerticalHash);
        }

        return $data;
    }

    private static function assertRequired(string $value, string $field, int $maxLength): void
    {
        if ($value === '' || strlen($value) > $maxLength) {
            throw new InvalidArgumentException("{$field} must be between 1 and {$maxLength} characters.");
        }
    }

    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') {
            throw new InvalidArgumentException("{$field} is required.");
        }

        return trim($value);
    }

    private static function positiveInt(mixed $value, string $field): int
    {
        if (is_int($value)) {
            $resolved = $value;
        } elseif (is_string($value) && ctype_digit($value)) {
            $resolved = (int) $value;
        } else {
            throw new InvalidArgumentException("{$field} must be a positive integer.");
        }

        if ($resolved <= 0) {
            throw new InvalidArgumentException("{$field} must be a positive integer.");
        }

        return $resolved;
    }
}
