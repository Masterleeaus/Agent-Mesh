# Titan Governance Capabilities

## Read-only tenant capabilities

- `governance.trust-map.read` — desired/earned/effective authority projection from Titan Autonomy.
- `governance.autonomy-evidence.read` — structured authority evidence feed.
- `governance.source-health.read` — current required/optional read-source status.
- `governance.signal-heatmap.read` — normalized Signal intensity by component/category/severity.
- `governance.operational-pressure.read` — transparent bottleneck/pressure projection.
- `governance.circuit-breaker.read` — observed circuit-breaker state.
- `governance.projection-history.read` — retained Governance projection history.
- `governance.escalation.queue.read` — active escalation queue ordered by risk, urgency and age.

## Governed action capabilities

- `governance.escalation.approve`
- `governance.escalation.reject`
- `governance.escalation.hold`
- `governance.escalation.exception`
- `governance.escalation.escalate`

These capabilities mutate only Governance-owned escalation state and still execute through Titan Command Bus. They do not authorize direct mutation of another engine's authoritative domain state.

Permissions are `titan-governance.escalations.view`, `titan-governance.escalations.act`, and the additional `titan-governance.exceptions.grant` for exceptions.
