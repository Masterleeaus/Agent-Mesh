<?php

declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Services;
use App\Extensions\TitanRewind\System\Models\RewindReplayRun;
use App\Extensions\TitanRewind\System\Models\RewindSignalOutbox;
use App\Extensions\TitanRewind\System\Runtime\RewindQueueAdmission;
use RuntimeException;
final class RewindQueueAdmissionService
{
    public function __construct(private RewindRuntimeStateService $runtimeState) {}
    public function decision(string $queue): array
    {
        $signalQueue=(string)config('titan-rewind.queues.signal','titan-rewind-signal');
        $backlog=$queue===$signalQueue ? RewindSignalOutbox::query()->whereIn('status',['pending','retry','attention'])->count() : RewindReplayRun::query()->whereIn('status',['queued','running'])->count();
        $soft=max(1,(int)config('titan-rewind.backpressure.soft_backlog',100)); $hard=max($soft+1,(int)config('titan-rewind.backpressure.hard_backlog',500));
        $logic=new RewindQueueAdmission($soft,$hard);
        return $logic->evaluate($this->runtimeState->current()->value(),$backlog)+['queue'=>$queue];
    }
    public function assertCanAccept(string $queue): array { $d=$this->decision($queue); if (!($d['allowed']??false)) throw new RuntimeException('Titan Rewind queue admission rejected work: '.($d['reason']??'unknown')); return $d; }
}
