<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Models;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Enums\AuthorityClass;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

final class KnowledgeClaim extends Model
{
    protected $table = 'titan_knowledge_claims';
    protected $guarded = ['id'];
    protected $casts = [
        'authority_class' => AuthorityClass::class,
        'metadata' => 'array',
        'effective_from' => 'immutable_datetime',
        'effective_until' => 'immutable_datetime',
    ];

    public function sourceVersion(): BelongsTo
    {
        return $this->belongsTo(KnowledgeSourceVersion::class, 'source_version_id');
    }

    public function section(): BelongsTo
    {
        return $this->belongsTo(KnowledgeSection::class, 'section_id');
    }

    public function applicability(): HasMany
    {
        return $this->hasMany(KnowledgeApplicability::class, 'claim_id');
    }
}
