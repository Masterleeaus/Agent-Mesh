<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);$provider=(string)file_get_contents($root.'/System/TitanAutonomyServiceProvider.php');
foreach([
 'DelegatedAuthorityEnvelopeService',
 'InteractionDelegatedAuthorityVerifier',
 'DelegatedAuthorityVerifierInterface',
 "config('app.key')",
 'delegation: $app->make(DelegatedAuthorityEnvelopeService::class)',
] as $needle){if(!str_contains($provider,$needle))throw new RuntimeException('provider missing delegated authority wiring: '.$needle);}
echo "OK: DelegatedProviderBindingSmokeTest\n";
