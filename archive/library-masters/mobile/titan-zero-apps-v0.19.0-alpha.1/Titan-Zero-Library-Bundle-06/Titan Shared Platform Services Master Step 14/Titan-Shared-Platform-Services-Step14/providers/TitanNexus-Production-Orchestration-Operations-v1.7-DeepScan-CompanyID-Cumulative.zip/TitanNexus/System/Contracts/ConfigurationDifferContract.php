<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Contracts;

use App\Extensions\TitanNexus\System\Domain\CompiledTitanConfig;
use App\Extensions\TitanNexus\System\Domain\ConfigurationDiff;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;

interface ConfigurationDifferContract
{
    public function diff(CompiledTitanConfig $current, CompiledTitanConfig $proposed, VerticalDefinition $definition): ConfigurationDiff;
}
