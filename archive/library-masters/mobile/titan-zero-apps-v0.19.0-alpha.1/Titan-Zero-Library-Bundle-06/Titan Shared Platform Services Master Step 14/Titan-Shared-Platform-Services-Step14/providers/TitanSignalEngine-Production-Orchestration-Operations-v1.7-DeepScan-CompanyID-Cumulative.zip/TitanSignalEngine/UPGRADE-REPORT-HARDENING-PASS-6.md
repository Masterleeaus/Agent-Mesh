# Titan Signal Engine v0.14.0 — Production Hardening Pass 6

## Scope
Transactional Pruning & Streaming Archives.

## Added
- persisted `titan_signal_prune_previews` exact-set manifests;
- one-time preview confirmation tokens and SHA-256 candidate hashes;
- atomic per-event prune claims and claim expiry;
- preview execution leases for concurrent-request exclusion;
- resumable `verified_unpruned` archive state;
- exact approved-set deletion count verification;
- bounded-memory streamed archive writes and reads;
- no-archive retention-class support;
- prune-preview/claim housekeeping;
- additive archive batch state fields for preview, prune count, archive count, failure and completion tracking.

## Compatibility
The lifecycle prune API intentionally changes from boolean confirmation to a preview token. Callers must perform `previewPrune()` and pass the returned `preview_token` to `prune()`.

## Boundary
Mixed hot/cold causal traversal remains Production Hardening Pass 7.
