# Authorization matrix

- Super Admin: extension administration and all explicitly enabled MCP capabilities.
- Admin: Overview and Tool Catalogue by default; Settings and mutation capabilities require explicit grants.
- Ordinary authenticated user: no MCP access unless explicitly granted `titan.mcp.access` plus the per-tool capability.
- Destructive operations: require the corresponding destructive capability and global destructive switch.
- Token scope: when enabled, `mcp:use` is additionally required and never substitutes for Titan permissions.
