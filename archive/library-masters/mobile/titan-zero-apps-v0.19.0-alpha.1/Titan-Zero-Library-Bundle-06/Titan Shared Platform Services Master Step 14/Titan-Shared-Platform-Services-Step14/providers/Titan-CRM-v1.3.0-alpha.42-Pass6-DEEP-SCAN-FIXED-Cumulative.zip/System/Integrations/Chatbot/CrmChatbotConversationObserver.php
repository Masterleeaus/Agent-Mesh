<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Integrations\Chatbot;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Services\CrmActivityRecorder;
use Illuminate\Database\ConnectionInterface;
final class CrmChatbotConversationObserver
{
    public function __construct(private CrmChatbotIdentityService $identities,private CrmChatbotSettingsService $settings,private CrmActivityRecorder $activities,private ConnectionInterface $db) {}
    public function created(object $conversation): void { $this->record($conversation,'conversation_started','Chatbot conversation started'); }
    public function updated(object $conversation): void { if($conversation->wasChanged('connect_agent_at') && $conversation->getAttribute('connect_agent_at')) $this->record($conversation,'human_handoff','Human handoff requested'); }
    private function record(object $conversation,string $type,string $title): void
    {
        try {
            $identity=$this->identities->resolveForConversation($conversation); if(!$identity||empty($identity['crm_contact_public_id']))return;
            $cfg=$this->settings->forChatbot((int)$identity['user_id'],(int)$identity['chatbot_id']); if(!($cfg['record_activity']??true))return;
            $conversationId=(int)$conversation->getKey(); $fingerprint=hash('sha256',implode('|',[$identity['user_id'],$identity['chatbot_id'],$conversationId,$type]));
            if($this->db->table('crm_chatbot_activity_links')->where('company_id', CrmCompanyScope::companyId((int)$identity['user_id']))->where('event_fingerprint',$fingerprint)->exists())return;
            $activity=$this->activities->record((int)$identity['user_id'],'contact',(string)$identity['crm_contact_public_id'],$type,$title,null,'inbound',null,null,(int)$identity['user_id'],['channel'=>$identity['channel']??null,'chatbot_id'=>$identity['chatbot_id'],'conversation_id'=>$conversationId]);
            $this->db->table('crm_chatbot_activity_links')->insert(['company_id'=>CrmCompanyScope::companyId((int)$identity['user_id']),'user_id'=>CrmCompanyScope::actorUserId((int)$identity['user_id']),'chatbot_id'=>$identity['chatbot_id'],'chatbot_conversation_id'=>$conversationId,'crm_contact_public_id'=>$identity['crm_contact_public_id'],'crm_activity_public_id'=>$activity['public_id']??null,'event_type'=>$type,'event_fingerprint'=>$fingerprint,'occurred_at'=>now(),'created_at'=>now(),'updated_at'=>now()]);
        } catch(\Throwable $e){ report($e); }
    }
}
