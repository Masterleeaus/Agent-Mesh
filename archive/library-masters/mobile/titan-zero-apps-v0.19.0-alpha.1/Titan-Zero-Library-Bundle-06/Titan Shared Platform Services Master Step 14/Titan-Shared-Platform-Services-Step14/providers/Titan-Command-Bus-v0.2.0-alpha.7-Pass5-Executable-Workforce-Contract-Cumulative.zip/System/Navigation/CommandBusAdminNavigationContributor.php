<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Navigation;

final class CommandBusAdminNavigationContributor
{
    public static function items(): array
    {
        return [[
            'label' => 'Titan Command Bus',
            'route' => 'dashboard.admin.titan.command.bus.index',
            'permission' => null,
            'icon' => 'tabler-circle',
            'order' => 80,
            'enabled' => true,
            'visibility' => 'platform-admin',
        ]];
    }

    public function contribute(): array { return self::items(); }
}
