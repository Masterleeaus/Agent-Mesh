<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Extensions\TitanConnect\System\Services\ExternalThreadManagementService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class ExternalThreadController extends Controller
{
    public function __construct(private readonly CompanyContext $context, private readonly ChannelAccessPolicy $policy, private readonly ExternalThreadManagementService $threads, private readonly WorkCoreAuthorizationGateway $workCore) {}

    public function assign(Request $request, ExternalThread $thread): JsonResponse
    {
        [$companyId,$actorId] = $this->scope($request, $thread, true);
        $data = $request->validate(['assigned_user_id' => ['nullable','integer','min:1']]);
        return response()->json($this->threads->assign($companyId, $actorId, $thread, isset($data['assigned_user_id']) ? (int) $data['assigned_user_id'] : null));
    }

    public function pin(Request $request, ExternalThread $thread): JsonResponse
    {
        [$companyId,$actorId] = $this->scope($request, $thread, false);
        $data = $request->validate(['pinned' => ['required','boolean']]);
        return response()->json($this->threads->pin($companyId, $actorId, $thread, (bool) $data['pinned']));
    }

    public function close(Request $request, ExternalThread $thread): JsonResponse
    {
        [$companyId,$actorId] = $this->scope($request, $thread, true);
        $data = $request->validate(['closed' => ['required','boolean']]);
        return response()->json($this->threads->close($companyId, $actorId, $thread, (bool) $data['closed']));
    }

    public function update(Request $request, ExternalThread $thread): JsonResponse
    {
        [$companyId,$actorId] = $this->scope($request, $thread, true);
        $data = $request->validate(['display_name' => ['sometimes','nullable','string','max:255'], 'color' => ['sometimes','nullable','string','max:32'], 'priority' => ['sometimes','in:low,normal,high,urgent']]);
        return response()->json($this->threads->updatePresentation($companyId, $actorId, $thread, $data));
    }

    public function note(Request $request, ExternalThread $thread): JsonResponse
    {
        [$companyId,$actorId] = $this->scope($request, $thread, false, true);
        $data = $request->validate(['note' => ['required','string','max:10000']]);
        return response()->json($this->threads->internalNote($companyId, $actorId, $thread, $data['note']), 201);
    }

    public function tags(Request $request, ExternalThread $thread): JsonResponse
    {
        [$companyId,$actorId] = $this->scope($request, $thread, true);
        $data = $request->validate(['tag_ids' => ['sometimes','array'], 'tag_ids.*' => ['integer','min:1']]);
        return response()->json($this->threads->syncTags($companyId, $actorId, $thread, $data['tag_ids'] ?? []));
    }

    private function scope(Request $request, ExternalThread $thread, bool $moderate = false, bool $send = false): array
    {
        $companyId = $this->context->companyId($request); $actorId = $this->context->actorId($request);
        abort_unless((int) $thread->company_id === $companyId, 404);
        if ($thread->linked_entity_type !== null && $thread->linked_entity_id !== null) {
            $this->workCore->assertCanAccess($companyId, $actorId, (string) $thread->linked_entity_type, (string) $thread->linked_entity_id);
        }
        $allowed = $moderate ? $this->policy->canModerate($thread->connection, $actorId) : ($send ? $this->policy->canSend($thread->connection, $actorId) : $this->policy->canView($thread->connection, $actorId));
        abort_unless($allowed, 403);
        return [$companyId,$actorId];
    }
}
