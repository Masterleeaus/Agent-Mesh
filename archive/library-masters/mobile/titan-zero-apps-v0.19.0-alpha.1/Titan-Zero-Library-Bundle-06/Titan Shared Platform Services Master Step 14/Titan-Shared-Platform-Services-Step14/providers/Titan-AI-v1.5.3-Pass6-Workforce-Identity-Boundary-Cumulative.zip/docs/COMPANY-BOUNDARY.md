# Company ID boundary

Titan AI Runtime uses **`company_id` as its single tenant boundary**. There is no runtime fallback to `tenant_id`.

## Canonical rules

- The authenticated MagicAI user supplies `company_id` through trusted host context.
- `TitanAIRequest` requires a positive integer `companyId` and exposes it internally as `company_id`.
- Runtime orchestration refuses business execution when `company_id` is missing or less than 1.
- Governance approvals, action receipts, rollback, governed memory, personas, skills, tool permissions and skill evaluations are all scoped by `company_id`.
- WorkCore calls receive the same `company_id` inside trusted `_governance` metadata.
- Retained Tier-3 WorkCore workers use `WorkerExecutionContext::companyId` and propagate that value to both `_titan_ai` and `_governance` metadata.
- Governance controllers resolve only `user->company_id`; they do not fall back to a second tenant identifier.
- Maintenance may operate across all companies only when invoked as an internal system-wide process. The CLI option for a single company is `--company=<id>`.

## Existing v1.2.0 installations

Migration `2026_08_09_000120_migrate_company_id_tenant_boundary.php` upgrades TitanAI-owned tables that still use the legacy `tenant_id` column.

The migration:

1. detects each TitanAI-owned table;
2. refuses an ambiguous schema containing both boundary columns;
3. validates every legacy value as a positive numeric company ID;
4. creates an indexed `unsignedBigInteger company_id` column;
5. copies only validated positive company IDs into the new boundary column;
6. verifies that no record is left without `company_id`;
7. drops the legacy boundary column and makes `company_id` non-null;
8. leaves already-converted tables unchanged.

The migration is intentionally forward-only. It does not recreate the legacy boundary on rollback.

## Integration requirement

Presentation surfaces such as Chatbot, AI Chat Pro, Titan Mobile and Titan Flow must resolve the active company from authenticated host state before constructing `TitanAIRequest`. A caller-supplied company identifier from an untrusted request body must not be accepted without host membership/authorization validation.

## Object access rule

Knowing an object UUID or numeric ID is never sufficient for access. Company-owned records must be queried using both the object identifier and `company_id` whenever a specific object is read, mutated, approved, executed or rolled back.
