<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalHistoryWindow
{
    /**
     * @param list<SignalHistoryRecord> $records
     * @param list<array{batch_id:string,code:string}> $coldFailures
     */
    public function __construct(
        public array $records,
        public int $hotEventCount,
        public int $coldEventCount,
        public int $totalEventCount,
        public bool $truncated,
        public array $coldFailures,
    ) {
        if ($this->hotEventCount < 0 || $this->coldEventCount < 0 || $this->totalEventCount < 0) {
            throw new InvalidArgumentException('Signal history counts cannot be negative.');
        }
        if ($this->totalEventCount < ($this->hotEventCount + $this->coldEventCount)) {
            throw new InvalidArgumentException('Signal history total count cannot be lower than hot+cold counts.');
        }
        foreach ($this->records as $record) {
            if (! $record instanceof SignalHistoryRecord) {
                throw new InvalidArgumentException('Signal history windows accept SignalHistoryRecord values only.');
            }
        }
    }

    public function returnedEventCount(): int
    {
        return count($this->records);
    }

    public function integrityComplete(): bool
    {
        return $this->coldFailures === [];
    }

    public function isPartial(): bool
    {
        return $this->truncated || ! $this->integrityComplete() || $this->returnedEventCount() < $this->totalEventCount;
    }

    public function isMixedTier(): bool
    {
        return $this->hotEventCount > 0 && $this->coldEventCount > 0;
    }

    public function storageTier(): string
    {
        if ($this->isMixedTier()) return 'mixed';
        if ($this->coldEventCount > 0) return 'cold';
        return 'hot';
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'returned_event_count' => $this->returnedEventCount(),
            'total_event_count' => $this->totalEventCount,
            'hot_event_count' => $this->hotEventCount,
            'cold_event_count' => $this->coldEventCount,
            'storage_tier' => $this->storageTier(),
            'truncated' => $this->truncated,
            'partial' => $this->isPartial(),
            'cold_history_complete' => $this->integrityComplete(),
            'cold_failure_count' => count($this->coldFailures),
            'cold_failures' => $this->coldFailures,
        ];
    }
}
