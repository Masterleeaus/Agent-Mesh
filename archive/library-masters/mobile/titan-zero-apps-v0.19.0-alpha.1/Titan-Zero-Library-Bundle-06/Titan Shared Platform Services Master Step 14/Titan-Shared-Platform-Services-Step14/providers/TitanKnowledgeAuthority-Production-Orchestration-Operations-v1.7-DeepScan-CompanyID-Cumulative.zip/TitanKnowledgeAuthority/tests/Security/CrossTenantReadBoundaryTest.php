<?php

declare(strict_types=1);

namespace Tests\Security;

use App\Extensions\TitanKnowledgeAuthority\System\Domain\Services\KnowledgeScopeVisibilityPolicy;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeAccessContext;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeScopeContext;
use PHPUnit\Framework\TestCase;

final class CrossTenantReadBoundaryTest extends TestCase
{
    public function test_tenant_context_fails_closed_for_another_tenant(): void
    {
        $policy = new KnowledgeScopeVisibilityPolicy();
        $context = KnowledgeAccessContext::trusted(123, []);

        self::assertTrue($policy->canRead($context, KnowledgeScopeContext::tenant(123)));
        self::assertFalse($policy->canRead($context, KnowledgeScopeContext::tenant(124)));
        self::assertFalse($policy->canRead($context, KnowledgeScopeContext::jurisdiction('AU-VIC')));
    }
}
