# Trusted Execution Context — v0.9.0

## Security boundary

Signal now treats three identities separately:

1. **Actor** — the human, AI agent, system actor or integration that caused the action.
2. **Tenant/system scope** — the authority boundary under which the action occurred.
3. **Emitter** — the Titan service/component that actually submitted the event to Signal.

A caller-provided `source` string is never sufficient proof of emitter identity.

## Emission

Every call to `SignalEmitterContract::emit()` requires a `SignalContext`. An emitting context must carry a host-attested `SignalEmitterIdentity` issued by `SignalEmitterAuthority` from an allowlisted service definition.

Signal verifies:

- the emitter attestation;
- `signal.emit` permission;
- allowed event-type family;
- tenant/system scope;
- actor claims;
- claimed `source`, `source_component` and `emitter_id` against the grant.

After verification, Signal derives the authoritative source fields from the emitter grant and persists `emitter_id` inside the checksum-covered envelope.

## Reads

The public Query, Correlation, Pulse, Anomaly and Lifecycle read contracts require a non-null `SignalContext`.

- tenant contexts may read only their own tenant;
- system-scope reads require `signal.system.read`;
- system-to-tenant reads require `signal.tenant.read`;
- global engine health requires `signal.health.read`.

## Compatibility

Existing historical events are not rewritten. The `emitter_id` column is nullable so pre-v0.9.0 history remains valid, and checksum verification omits `emitter_id` when it is absent. Every newly accepted event receives an attested emitter ID.

## In-process trust limit

Titan extensions execute inside the same Laravel/PHP process and are not OS-level sandboxes. Emitter attestation is therefore a capability/configuration boundary against caller-supplied identity and accidental cross-component spoofing; it is not presented as process isolation against arbitrary malicious PHP with host-level access.
