# Titan Field Donor / Provenance Register

## Pass 1

No `FieldCore.zip` or `Titan Operations Team.zip` runtime code is merged in Pass 1. They remain donor sources for later selective extraction passes.

The 10 canonical vertical profile JSON resources in `resources/field-services/verticals/` were restored from the current Titan CRM lineage (`Titan-CRM-Core-v1.3.0-alpha.32`) because Titan Field alpha.1 referenced these resources but omitted them from its extracted package. They are domain data/configuration from Titan Field's direct predecessor, not a new third-party runtime dependency.

The menu self-healing implementation follows the proven host-compatibility behavior already used by Titan CRM: adaptive menu schema writes, named-route preservation, stale-route-cache recovery and non-fatal MagicAI menu cache regeneration. Titan Field owns its implementation and extends it with route-based adoption so historical CRM child keys are preserved when present.

Future donor extraction must continue to document source, license/provenance and whether code was directly adapted or cleanly reimplemented.
