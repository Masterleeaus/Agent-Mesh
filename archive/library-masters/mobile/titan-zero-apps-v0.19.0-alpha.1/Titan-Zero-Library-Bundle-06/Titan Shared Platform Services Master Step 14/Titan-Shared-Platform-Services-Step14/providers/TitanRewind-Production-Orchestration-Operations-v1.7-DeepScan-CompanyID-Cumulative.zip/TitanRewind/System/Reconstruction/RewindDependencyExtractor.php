<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Reconstruction;

final class RewindDependencyExtractor
{
    public function extract(array $payload, ?string $defaultSourceType = null, ?string $defaultSourceId = null): array
    {
        $result = [];
        foreach ((array) ($payload['dependencies'] ?? []) as $dependency) {
            if (!is_array($dependency)) {
                continue;
            }

            $targetType = trim((string) ($dependency['target_entity_type'] ?? ''));
            if ($targetType === '') {
                continue;
            }

            $result[] = [
                'source_entity_type' => trim((string) ($dependency['source_entity_type'] ?? $defaultSourceType ?? 'unknown')) ?: 'unknown',
                'source_entity_id' => $this->nullableString($dependency['source_entity_id'] ?? $defaultSourceId),
                'target_entity_type' => $targetType,
                'target_entity_id' => $this->nullableString($dependency['target_entity_id'] ?? null),
                'relationship_type' => trim((string) ($dependency['relationship_type'] ?? 'related')) ?: 'related',
                'risk_level' => trim((string) ($dependency['risk_level'] ?? 'unknown')) ?: 'unknown',
                'metadata' => is_array($dependency['metadata'] ?? null)
                    ? $dependency['metadata']
                    : (is_array($dependency['meta_json'] ?? null) ? $dependency['meta_json'] : []),
            ];
        }

        return $result;
    }

    private function nullableString(mixed $value): ?string
    {
        if ($value === null) {
            return null;
        }
        $string = trim((string) $value);
        return $string === '' ? null : $string;
    }
}
