# Pass 4 — TitanTrust Evidence Repair & Convergence

TitanTrust is the canonical `evidence_assurance` runtime. The duplicate nested TitanTrust tree is quarantined in `LegacyDonors/TitanTrust-Nested-Pass3-Source.zip`.

## Canonical boundary
- `company_id` is the sole company boundary.
- Titan Zero `ExecutionContextStore` is preferred for background/agent execution; authenticated `company_id` is the web fallback.
- Missing company context fails closed. User IDs are actor/uploader attribution only, never company identity.

## Evidence convergence
`EvidenceRefFactory` maps uploaded evidence, client sign-offs, incidents and attendance/presence to `Modules\TitanZeroAssurance\ValueObjects\EvidenceRef`, retaining hashes, file IDs, job IDs and trust metadata.

## Repairs
- Rebuilt corrupt capture/evidence/incident controller sections.
- Uploads now create `WorkEvidenceItem` records, not orphan files.
- Evidence readiness uses canonical `evidence_type`.
- Public sign-off explicitly bypasses the authenticated company global scope only for high-entropy token lookup.
- Canonical route prefix/name drift repaired.
