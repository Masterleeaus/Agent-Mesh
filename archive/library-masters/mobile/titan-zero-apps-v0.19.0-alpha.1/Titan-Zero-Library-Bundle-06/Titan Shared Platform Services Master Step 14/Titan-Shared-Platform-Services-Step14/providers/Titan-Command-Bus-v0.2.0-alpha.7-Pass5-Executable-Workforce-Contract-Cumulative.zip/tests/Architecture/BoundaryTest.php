<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;

final class BoundaryTest extends TestCase
{
    public function test_manifest_forbids_direct_foreign_writes_and_owns_only_governed_mutation(): void
    {
        $root = dirname(__DIR__, 2);
        $manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);

        self::assertSame('forbidden', $manifest['authority']['cross_domain_write_policy']);
        self::assertSame(['governed-mutation'], $manifest['authority']['owns']);
        self::assertFalse($manifest['command_bus']['direct_foreign_writes']);
        self::assertTrue($manifest['command_bus']['domain_adapter_only']);
        self::assertTrue($manifest['command_bus']['recursive_dispatch_forbidden']);
    }
}
