<?php

declare(strict_types=1);
namespace Tests\Unit;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeSourceVersionAppendRequest; use DateTimeImmutable; use InvalidArgumentException; use PHPUnit\Framework\TestCase;
final class SourceVersionAppendRequestTest extends TestCase { public function test_hashes_are_normalized():void{$r=new KnowledgeSourceVersionAppendRequest(9,str_repeat('A',64),str_repeat('B',64),new DateTimeImmutable('2026-08-21T00:00:00Z'),['publisher'=>'Example']);self::assertSame(str_repeat('a',64),$r->contentHash);self::assertSame(str_repeat('b',64),$r->rawEvidenceHash);} public function test_invalid_effective_window_is_rejected():void{$this->expectException(InvalidArgumentException::class);new KnowledgeSourceVersionAppendRequest(9,str_repeat('a',64),str_repeat('b',64),new DateTimeImmutable('2026-08-21T00:00:00Z'),[],effectiveFrom:new DateTimeImmutable('2026-08-22T00:00:00Z'),effectiveUntil:new DateTimeImmutable('2026-08-21T00:00:00Z'));} }
