<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Host\TitanInstallerManifestContract;
use App\Extensions\TitanNexus\System\Host\TitanMySqlMigrationCompatibility;
use App\Extensions\TitanNexus\System\Host\TitanPackageIntegrityBuilder;

$root = $argv[1] ?? dirname(__DIR__);
$root = realpath($root) ?: $root;
require_once $root . '/System/Host/TitanInstallerManifestContract.php';
require_once $root . '/System/Host/TitanPackageIntegrityBuilder.php';
require_once $root . '/System/Host/TitanMySqlMigrationCompatibility.php';

$errors = [];
$extensionPath = $root . '/extension.json';
$manifestPath = $root . '/extension.manifest.json';
if (!is_file($extensionPath) || !is_file($manifestPath)) {
    $errors[] = 'extension.json and extension.manifest.json are required at the flat package root';
} else {
    $extension = json_decode((string) file_get_contents($extensionPath), true, 512, JSON_THROW_ON_ERROR);
    foreach (TitanInstallerManifestContract::validate($extension, true) as $error) {
        $errors[] = $error;
    }
    $expected = $extension['integrity']['files'] ?? [];
    $actual = TitanPackageIntegrityBuilder::build($root);
    if ($expected !== $actual) {
        $errors[] = 'Installer integrity.files does not exactly match package contents';
    }
    $manifest = json_decode((string) file_get_contents($manifestPath), true, 512, JSON_THROW_ON_ERROR);
    if (($manifest['schema_version'] ?? null) !== '2.2') {
        $errors[] = 'extension.manifest.json must use schema_version 2.2';
    }
    if (($manifest['architecture']['profile'] ?? null) !== 'configuration-orchestrator') {
        $errors[] = 'architecture.profile must be configuration-orchestrator';
    }
}

foreach (glob($root . '/database/migrations/*.php') ?: [] as $migration) {
    $unsafe = TitanMySqlMigrationCompatibility::unsafePrecisionTimestamps((string) file_get_contents($migration));
    if ($unsafe !== []) {
        $errors[] = basename($migration) . ' contains unsafe precision timestamp fields: ' . implode(', ', $unsafe);
    }
}

$routes = (string) @file_get_contents($root . '/routes/user.php');
foreach (['overview','profile','compilations','validation','preview','history','diff','provisioning','receipts','detail'] as $route) {
    if (!str_contains($routes, "->name('{$route}')")) {
        $errors[] = "missing user route {$route}";
    }
}
$view = (string) @file_get_contents($root . '/resources/views/index.blade.php');
if (!str_contains($view, "@extends('panel.layout.app')")) {
    $errors[] = 'Control Centre must extend panel.layout.app';
}

$result = [
    'status' => $errors === [] ? 'PASS' : 'FAIL',
    'root' => $root,
    'errors' => $errors,
    'checks' => [
        'flat_root' => is_file($extensionPath),
        'installer_integrity' => $errors === [] || !in_array('Installer integrity.files does not exactly match package contents', $errors, true),
        'manifest_v2_2' => true,
        'mysql_migration_compatibility' => !array_filter($errors, static fn (string $e): bool => str_contains($e, 'unsafe precision timestamp')),
        'control_centre_routes' => !array_filter($errors, static fn (string $e): bool => str_starts_with($e, 'missing user route')),
        'magicai_layout' => !in_array('Control Centre must extend panel.layout.app', $errors, true),
    ],
];
echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . PHP_EOL;
exit($errors === [] ? 0 : 1);
