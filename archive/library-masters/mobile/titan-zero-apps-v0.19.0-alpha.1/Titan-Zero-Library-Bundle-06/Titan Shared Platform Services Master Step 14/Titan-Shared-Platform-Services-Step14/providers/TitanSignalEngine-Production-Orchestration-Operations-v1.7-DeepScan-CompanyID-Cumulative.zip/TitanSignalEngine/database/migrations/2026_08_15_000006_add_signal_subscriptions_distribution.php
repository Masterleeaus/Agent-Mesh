<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_subscriptions')) {
            Schema::create('titan_signal_subscriptions', function (Blueprint $table): void {
                $table->id();
                $table->string('subscriber_key', 160)->unique('tss_subscriber_uq');
                $table->string('handler_class', 255);
                $table->json('event_patterns');
                $table->json('accepted_schema_versions');
                $table->json('scopes');
                $table->json('categories')->nullable();
                $table->json('verticals')->nullable();
                $table->string('queue', 120)->default('titan-signal-engine');
                $table->unsignedSmallInteger('max_attempts')->default(5);
                $table->json('backoff_seconds');
                $table->unsignedSmallInteger('timeout_seconds')->default(30);
                $table->string('status', 20)->default('active');
                $table->timestamps();
                $table->index(['status', 'subscriber_key'], 'tss_status_key_idx');
            });
        }

        if (! Schema::hasTable('titan_signal_deliveries')) {
            Schema::create('titan_signal_deliveries', function (Blueprint $table): void {
                $table->id();
                $table->uuid('delivery_id')->unique('tsd_delivery_uq');
                $table->uuid('event_id');
                $table->string('subscriber_key', 160);
                $table->string('scope', 20);
                $table->unsignedBigInteger('tenant_company_id')->nullable();
                $table->string('event_type', 160);
                $table->unsignedInteger('schema_version');
                $table->string('queue', 120)->default('titan-signal-engine');
                $table->string('status', 24)->default('pending');
                $table->unsignedSmallInteger('attempt_count')->default(0);
                $table->timestamp('available_at')->nullable();
                $table->timestamp('queued_at')->nullable();
                $table->timestamp('reserved_at')->nullable();
                $table->timestamp('delivered_at')->nullable();
                $table->timestamp('dead_lettered_at')->nullable();
                $table->string('last_error_class', 255)->nullable();
                $table->text('last_error')->nullable();
                $table->timestamps();

                $table->unique(['event_id', 'subscriber_key'], 'tsd_event_subscriber_uq');
                $table->index(['status', 'available_at'], 'tsd_status_available_idx');
                $table->index(['subscriber_key', 'status', 'available_at'], 'tsd_subscriber_status_idx');
                $table->index(['tenant_company_id', 'status', 'created_at'], 'tsd_tenant_status_idx');
                $table->index(['event_id', 'status'], 'tsd_event_status_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_signal_deliveries');
        Schema::dropIfExists('titan_signal_subscriptions');
    }
};
