<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

use Illuminate\Http\Request;

interface CompanyContext
{
    public function companyId(Request $request): int;
    public function actorId(Request $request): int;
}
