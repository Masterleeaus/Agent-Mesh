# Titan Signal Engine v0.5.0 — Pass 5 Pulse

Implemented pre-aggregated operational awareness without making Pulse an authorization or alert-policy engine.

## Added

- `SignalPulseContract`
- `SignalPulseProjectorContract`
- minute/hour/day tenant/system rollups
- idempotent projected-event ledger
- trace metrics projection
- P50/P95/P99 trace and command-receipt latency
- missing execution-receipt detection
- configurable stalled-trace candidates
- source and event-type summaries
- current distribution/dead-letter pressure
- deterministic attention score and reason codes
- compact Zero/Prime-ready Pulse surface read model
- recoverable projection command and scheduler

## Reliability model

Signal persistence remains authoritative. Pulse projection happens after event commit, and projection failure is logged rather than failing ingestion. The catch-up command replays unprojected immutable events safely.

## Out of scope

- anomaly alerts/ML
- direct PagerDuty/Slack integration
- retention/pruning
- full Signal/Pulse console
