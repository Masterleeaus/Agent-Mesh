<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /** @var list<string> */
    private array $tables = [
        'ext_titan_connect_conversations',
        'ext_titan_connect_participants',
        'ext_titan_connect_messages',
        'ext_titan_connect_message_reads',
        'ext_titan_connect_channel_connections',
        'ext_titan_connect_channel_members',
        'ext_titan_connect_external_threads',
        'ext_titan_connect_external_messages',
        'ext_titan_connect_external_thread_reads',
        'ext_titan_connect_outbound_deliveries',
        'ext_titan_connect_webhook_events',
        'ext_titan_connect_attachments',
        'ext_titan_connect_audit_logs',
        'ext_titan_connect_provider_credentials',
    ];

    public function up(): void
    {
        foreach ($this->tables as $table) {
            if (! Schema::hasTable($table) || Schema::hasColumn($table, 'company_id') || ! Schema::hasColumn($table, 'tenant_id')) {
                continue;
            }

            Schema::table($table, static function (Blueprint $blueprint): void {
                $blueprint->renameColumn('tenant_id', 'company_id');
            });
        }

        if (Schema::hasTable('ext_titan_connect_conversations')) {
            DB::table('ext_titan_connect_conversations')->where('visibility', 'tenant')->update(['visibility' => 'company']);
        }
    }

    public function down(): void
    {
        foreach (array_reverse($this->tables) as $table) {
            if (! Schema::hasTable($table) || Schema::hasColumn($table, 'tenant_id') || ! Schema::hasColumn($table, 'company_id')) {
                continue;
            }

            Schema::table($table, static function (Blueprint $blueprint): void {
                $blueprint->renameColumn('company_id', 'tenant_id');
            });
        }

        if (Schema::hasTable('ext_titan_connect_conversations')) {
            DB::table('ext_titan_connect_conversations')->where('visibility', 'company')->update(['visibility' => 'tenant']);
        }
    }
};
