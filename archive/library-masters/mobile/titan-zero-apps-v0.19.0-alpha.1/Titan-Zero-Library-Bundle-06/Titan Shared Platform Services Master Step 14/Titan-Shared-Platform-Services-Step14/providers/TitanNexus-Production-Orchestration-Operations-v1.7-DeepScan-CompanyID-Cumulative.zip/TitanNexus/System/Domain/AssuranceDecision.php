<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\StrictBoolean;
use InvalidArgumentException;

final class AssuranceDecision
{
    public function __construct(private readonly bool $allowed,private readonly string $evidenceReference,private readonly string $assuranceLevel,private readonly ?string $reason=null)
    {
        self::assertText($this->evidenceReference,'evidence_reference'); if(!in_array($this->assuranceLevel,['NONE','RED','AMBER','GREEN','policy'],true))throw new InvalidArgumentException('assurance_level is invalid.'); if($this->reason!==null)self::assertText($this->reason,'reason',1000);
    }
    /** @param array<string,mixed> $data */ public static function fromArray(array $data):self{return new self(StrictBoolean::parse($data['allowed'] ?? false, 'allowed'),self::required($data['evidence_reference']??null,'evidence_reference'),self::required($data['assurance_level']??null,'assurance_level'),self::nullable($data['reason']??null));}
    public function allowed():bool{return $this->allowed;} public function evidenceReference():string{return $this->evidenceReference;} public function assuranceLevel():string{return $this->assuranceLevel;} public function reason():?string{return $this->reason;}
    /** @return array<string,mixed> */ public function toArray():array{return ['allowed'=>$this->allowed,'evidence_reference'=>$this->evidenceReference,'assurance_level'=>$this->assuranceLevel,'reason'=>$this->reason];}
    private static function required(mixed $v,string $f):string{if(!is_string($v)||trim($v)==='')throw new InvalidArgumentException("{$f} is required.");return trim($v);} private static function nullable(mixed $v):?string{if($v===null)return null;if(!is_string($v))throw new InvalidArgumentException('reason must be string or null.');return trim($v);} private static function assertText(string $v,string $f,int $m=300):void{if(trim($v)===''||strlen($v)>$m)throw new InvalidArgumentException("{$f} is invalid.");}
}
