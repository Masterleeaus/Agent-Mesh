<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Host;

use JsonException;

final class TitanFreshInstallPreflight
{
    private const EXPECTED_SCHEMA = 'titan-extension-v1';
    private const EXPECTED_SLUG = 'titan-nexus';
    private const EXPECTED_FOLDER = 'TitanNexus';
    private const EXPECTED_PROVIDER = 'App\\Extensions\\TitanNexus\\System\\TitanNexusServiceProvider';

    /**
     * @return array{status:string,errors:list<string>,checks:array<string,bool>,migration_count:int}
     */
    public static function verifyDirectory(string $root): array
    {
        $root = realpath($root) ?: rtrim($root, '/\\');
        $errors = [];
        $checks = [
            'installer_manifest' => false,
            'installer_integrity' => false,
            'provider_identity' => false,
            'migration_sequence' => false,
            'routes_and_views' => false,
            'config_publish' => false,
            'interface_manifest' => false,
            'navigation_wiring' => false,
        ];

        $extension = self::jsonFile($root . '/extension.json', 'extension.json', $errors);
        if ($extension !== null) {
            $manifestErrors = TitanInstallerManifestContract::validate($extension, true);
            foreach ($manifestErrors as $error) {
                $errors[] = 'installer_manifest: ' . $error;
            }
            foreach ([
                'schema' => self::EXPECTED_SCHEMA,
                'slug' => self::EXPECTED_SLUG,
                'folder' => self::EXPECTED_FOLDER,
                'provider' => self::EXPECTED_PROVIDER,
            ] as $field => $expected) {
                if (($extension[$field] ?? null) !== $expected) {
                    $errors[] = "installer_manifest: {$field} must equal {$expected}";
                }
            }
            $checks['installer_manifest'] = !self::hasPrefix($errors, 'installer_manifest:');

            $expectedIntegrity = $extension['integrity']['files'] ?? null;
            if (!is_array($expectedIntegrity)) {
                $errors[] = 'installer_integrity: extension.json integrity.files must be an object';
            } else {
                $actualIntegrity = TitanPackageIntegrityBuilder::build($root);
                ksort($expectedIntegrity, SORT_STRING);
                if ($expectedIntegrity !== $actualIntegrity) {
                    $errors[] = 'installer_integrity: integrity.files does not exactly match install tree';
                }
            }
            $checks['installer_integrity'] = !self::hasPrefix($errors, 'installer_integrity:');
        }

        self::verifyProvider($root, $errors);
        $checks['provider_identity'] = !self::hasPrefix($errors, 'provider_identity:');

        $migrationCount = self::verifyMigrations($root, $errors);
        $checks['migration_sequence'] = !self::hasPrefix($errors, 'migration_sequence:');

        self::verifyRoutesAndViews($root, $errors);
        $checks['routes_and_views'] = !self::hasPrefix($errors, 'routes_and_views:');

        self::verifyConfigPublish($root, $errors);
        $checks['config_publish'] = !self::hasPrefix($errors, 'config_publish:');

        self::verifyInterfaceManifest($root, $errors);
        $checks['interface_manifest'] = !self::hasPrefix($errors, 'interface_manifest:');

        self::verifyNavigation($root, $errors);
        $checks['navigation_wiring'] = !self::hasPrefix($errors, 'navigation_wiring:');

        return [
            'status' => $errors === [] ? 'PASS' : 'FAIL',
            'errors' => $errors,
            'checks' => $checks,
            'migration_count' => $migrationCount,
        ];
    }

    /**
     * Compare discovered host facts with the exact host profile required for live certification.
     * This is compatibility preflight only; it never grants INSTALLER_CERTIFIED.
     *
     * @param array{php?:mixed,laravel?:mixed,database?:mixed,installer?:mixed} $facts
     * @return array{compatible:bool,reasons:list<string>,expected:array<string,string>,actual:array<string,string|null>}
     */
    public static function evaluateHostFacts(array $facts): array
    {
        $expected = [
            'php' => '8.3',
            'laravel' => '10.50.x',
            'database' => 'mysql',
            'installer' => '1.7.6|1.7.8',
        ];
        $actual = [];
        foreach (array_keys($expected) as $key) {
            $value = $facts[$key] ?? null;
            $actual[$key] = is_string($value) && trim($value) !== '' ? trim($value) : null;
        }

        $reasons = [];
        if ($actual['php'] === null || preg_match('/^8\.3(?:\.|$)/', $actual['php']) !== 1) {
            $reasons[] = 'php_version_mismatch';
        }
        if ($actual['laravel'] === null || preg_match('/^10\.50(?:\.|$)/', $actual['laravel']) !== 1) {
            $reasons[] = 'laravel_version_mismatch';
        }
        if ($actual['database'] === null || strtolower($actual['database']) !== 'mysql') {
            $reasons[] = 'database_driver_mismatch';
        }
        if (!in_array($actual['installer'], ['1.7.6', '1.7.8'], true)) {
            $reasons[] = 'installer_version_mismatch';
        }

        return [
            'compatible' => $reasons === [],
            'reasons' => $reasons,
            'expected' => $expected,
            'actual' => $actual,
        ];
    }

    /** @param list<string> $errors */
    private static function verifyProvider(string $root, array &$errors): void
    {
        $path = $root . '/System/TitanNexusServiceProvider.php';
        if (!is_file($path)) {
            $errors[] = 'provider_identity: provider file missing';
            return;
        }
        $source = (string) file_get_contents($path);
        foreach ([
            'namespace App\\Extensions\\TitanNexus\\System;',
            'final class TitanNexusServiceProvider extends ServiceProvider',
            'ExtensionRegisterKeyProviderInterface',
            'UninstallExtensionServiceProviderInterface',
            "public function registerKey(): string { return 'titan-nexus'; }",
            'public function register(): void',
            'public function boot(',
            'public static function uninstall(): void',
        ] as $token) {
            if (!str_contains($source, $token)) {
                $errors[] = "provider_identity: provider missing {$token}";
            }
        }
    }

    /** @param list<string> $errors */
    private static function verifyMigrations(string $root, array &$errors): int
    {
        $files = glob($root . '/database/migrations/*.php') ?: [];
        sort($files, SORT_STRING);
        $prefixes = [];
        $previous = null;
        foreach ($files as $file) {
            $name = basename($file);
            if (preg_match('/^(\d{4}_\d{2}_\d{2}_\d{6})_[a-z0-9_]+\.php$/', $name, $match) !== 1) {
                $errors[] = "migration_sequence: invalid migration filename {$name}";
                continue;
            }
            $prefix = $match[1];
            if (isset($prefixes[$prefix])) {
                $errors[] = "migration_sequence: duplicate migration timestamp {$prefix}";
            }
            $prefixes[$prefix] = true;
            if ($previous !== null && strcmp($previous, $prefix) >= 0) {
                $errors[] = "migration_sequence: migrations are not strictly ordered at {$name}";
            }
            $previous = $prefix;

            $source = (string) file_get_contents($file);
            foreach (['extends Migration', 'public function up(): void', 'public function down(): void'] as $token) {
                if (!str_contains($source, $token)) {
                    $errors[] = "migration_sequence: {$name} missing {$token}";
                }
            }
            $unsafe = TitanMySqlMigrationCompatibility::unsafePrecisionTimestamps($source);
            if ($unsafe !== []) {
                $errors[] = "migration_sequence: {$name} has MySQL-unsafe precision timestamp fields";
            }
        }
        if ($files === []) {
            $errors[] = 'migration_sequence: no migrations found';
        }
        return count($files);
    }

    /** @param list<string> $errors */
    private static function verifyRoutesAndViews(string $root, array &$errors): void
    {
        foreach ([
            'routes/user.php',
            'routes/admin.php',
            'System/Http/Controllers/ControlCentreController.php',
            'System/Http/Controllers/AdminController.php',
            'System/Http/Middleware/TitanNexusAuthorizationMiddleware.php',
            'resources/views/index.blade.php',
            'resources/views/admin.blade.php',
            'resources/views/partials/control-centre-nav.blade.php',
        ] as $relative) {
            if (!is_file($root . '/' . $relative)) {
                $errors[] = "routes_and_views: missing {$relative}";
            }
        }
        $routes = (string) @file_get_contents($root . '/routes/user.php');
        foreach (['index','overview','profile','compilations','detail','validation','preview','history','diff','provisioning','receipts'] as $name) {
            if (!str_contains($routes, "->name('{$name}')")) {
                $errors[] = "routes_and_views: missing named route {$name}";
            }
        }
        $view = (string) @file_get_contents($root . '/resources/views/index.blade.php');
        if (!str_contains($view, "@extends('panel.layout.app')")) {
            $errors[] = 'routes_and_views: Control Centre must extend panel.layout.app';
        }
    }

    /** @param list<string> $errors */
    private static function verifyConfigPublish(string $root, array &$errors): void
    {
        if (!is_file($root . '/config/titan-nexus.php')) {
            $errors[] = 'config_publish: config/titan-nexus.php missing';
        }
        $provider = (string) @file_get_contents($root . '/System/TitanNexusServiceProvider.php');
        foreach (["mergeConfigFrom(__DIR__ . '/../config/titan-nexus.php', 'titan-nexus')", "config_path('titan-nexus.php')", "'extension'"] as $token) {
            if (!str_contains($provider, $token)) {
                $errors[] = "config_publish: provider missing {$token}";
            }
        }
    }

    /** @param list<string> $errors */
    private static function verifyInterfaceManifest(string $root, array &$errors): void
    {
        $manifest = self::jsonFile($root . '/resources/interface/interface-manifest.json', 'interface manifest', $errors, 'interface_manifest:');
        if ($manifest === null) {
            return;
        }
        if (($manifest['schema_version'] ?? null) !== '1.1') {
            $errors[] = 'interface_manifest: schema_version must be 1.1';
        }
        if (($manifest['extension_key'] ?? null) !== self::EXPECTED_SLUG) {
            $errors[] = 'interface_manifest: extension_key must be titan-nexus';
        }
        if (($manifest['actions'] ?? []) !== []) {
            $errors[] = 'interface_manifest: Step-5 Control Centre contribution must remain read-only';
        }
    }

    /** @param list<string> $errors */
    private static function verifyNavigation(string $root, array &$errors): void
    {
        foreach (['System/Host/NexusMenuRegistrar.php', 'System/Host/TitanMenuCompatibilityAdapter.php'] as $relative) {
            if (!is_file($root . '/' . $relative)) {
                $errors[] = "navigation_wiring: missing {$relative}";
            }
        }
        $provider = (string) @file_get_contents($root . '/System/TitanNexusServiceProvider.php');
        if (!str_contains($provider, 'registerNavigation')) {
            $errors[] = 'navigation_wiring: provider does not register navigation';
        }
        $registrar = (string) @file_get_contents($root . '/System/Host/NexusMenuRegistrar.php');
        foreach (['Titan Nexus', 'dashboard.user.titan.nexus.overview', 'dashboard.user.titan.nexus.receipts'] as $token) {
            if (!str_contains($registrar, $token)) {
                $errors[] = "navigation_wiring: menu registrar missing {$token}";
            }
        }
    }

    /**
     * @param list<string> $errors
     * @return array<string,mixed>|null
     */
    private static function jsonFile(string $path, string $label, array &$errors, string $prefix = ''): ?array
    {
        if (!is_file($path)) {
            $errors[] = $prefix . "{$label} missing";
            return null;
        }
        try {
            $value = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            $errors[] = $prefix . "{$label} is invalid JSON";
            return null;
        }
        if (!is_array($value)) {
            $errors[] = $prefix . "{$label} must decode to an object";
            return null;
        }
        return $value;
    }

    /** @param list<string> $errors */
    private static function hasPrefix(array $errors, string $prefix): bool
    {
        foreach ($errors as $error) {
            if (str_starts_with($error, $prefix)) {
                return true;
            }
        }
        return false;
    }
}
