<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanNexus\Unit;

use App\Extensions\TitanNexus\System\Domain\CompiledTitanConfig;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeDisposition;
use App\Extensions\TitanNexus\System\Domain\SemanticChangeKind;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Services\SemanticConfigurationDiffer;
use PHPUnit\Framework\TestCase;

final class SemanticDiffTest extends TestCase
{
    public function test_diff_is_deterministic_and_policy_aware(): void
    {
        $current = $this->config(['billing' => ['currency' => 'AUD'], 'roles' => ['cleaner', 'supervisor']], '1');
        $proposed = $this->config(['billing' => ['currency' => 'NZD'], 'roles' => ['cleaner']], '2');
        $definition = VerticalDefinition::fromArray([
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'sections' => [],
            'recompile_policy' => ['requires_approval_paths' => ['sections.billing']],
        ]);

        $diff = (new SemanticConfigurationDiffer())->diff($current, $proposed, $definition);
        $entries = [];
        foreach ($diff->entries() as $entry) {
            $entries[$entry->path()] = $entry;
        }

        self::assertSame(SemanticChangeKind::Modify, $entries['sections.billing.currency']->kind());
        self::assertSame(SemanticChangeDisposition::RequiresApproval, $entries['sections.billing.currency']->disposition());
        self::assertSame(SemanticChangeKind::Modify, $entries['sections.roles']->kind());
        self::assertSame($diff->fingerprint(), (new SemanticConfigurationDiffer())->diff($current, $proposed, $definition)->fingerprint());
    }

    /** @param array<string, mixed> $sections */
    private function config(array $sections, string $version): CompiledTitanConfig
    {
        return CompiledTitanConfig::fromArray([
            'tenant_company_id' => 42,
            'configuration_version' => $version,
            'compiler_version' => '0.5.0',
            'vertical_id' => 'cleaning',
            'vertical_version' => '2026.08',
            'knowledge_snapshot_version' => null,
            'source_profile_hash' => str_repeat('a', 64),
            'source_vertical_hash' => str_repeat('b', 64),
            'sections' => $sections,
        ]);
    }
}
