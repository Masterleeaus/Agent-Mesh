<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\AssuranceBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\CommandBusBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\InteractionEngineBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\RewindBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\TitanAiRuntimeBridgeContract;
use App\Extensions\TitanAutonomy\System\Infrastructure\CrmCompanyHostContextBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableAssuranceBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableCommandBusBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableInteractionEngineBridge;
use App\Extensions\TitanAutonomy\System\Infrastructure\UnavailableTitanAiRuntimeBridge;

final class HostBridgeStatusService
{
    public function __construct(
        private readonly AssuranceBridgeContract $assurance,
        private readonly InteractionEngineBridgeContract $interaction,
        private readonly CommandBusBridgeContract $commandBus,
        private readonly RewindBridgeContract $rewind,
        private readonly ?TitanAiRuntimeBridgeContract $titanAi = null,
        private readonly ?HostContextBridgeContract $host = null,
    ) {}

    public function status(): array
    {
        $titanAi = $this->titanAi?->status() ?? (new UnavailableTitanAiRuntimeBridge())->status();
        return [
            'crm_tenancy' => [
                'available' => $this->host instanceof CrmCompanyHostContextBridge,
                'class' => ($this->host !== null ? $this->host::class : null),
                'canonical_field' => 'tenant_company_id',
            ],
            'titan_ai_runtime' => [
                'available' => (bool) ($titanAi['available'] ?? false),
                'class' => $titanAi['class'] ?? ($this->titanAi !== null ? $this->titanAi::class : null),
                'approval_authority' => false,
            ],
            'assurance' => [
                'available' => !$this->assurance instanceof UnavailableAssuranceBridge,
                'class' => $this->assurance::class,
            ],
            'interaction_engine' => [
                'available' => !$this->interaction instanceof UnavailableInteractionEngineBridge,
                'class' => $this->interaction::class,
            ],
            'command_bus' => [
                'available' => !$this->commandBus instanceof UnavailableCommandBusBridge,
                'class' => $this->commandBus::class,
            ],
            'rewind' => [
                'available' => $this->rewind->available(),
                'class' => $this->rewind::class,
            ],
        ];
    }
}
