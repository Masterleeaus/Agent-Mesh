<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface ExecutionReceiptStoreContract
{
    /** Persist a tenant-private execution observation receipt and return its public id. */
    public function create(array $receipt): string;

    public function findByCorrelation(int $tenantCompanyId, string $correlationId): ?array;

    /** @return list<array<string,mixed>> */
    public function due(int $limit = 100): array;

    public function finalize(string $publicId, array $fields): void;

    public function appendFeedback(string $publicId, array $feedback): string;
}
