<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\TitanConnect;

/**
 * CRM-side port for canonical outbound communication execution.
 * Titan Connect should bind this interface in the integrated platform.
 */
interface CrmCommunicationExecutionPort
{
    /**
     * @param array<string,mixed> $intent
     * @return array<string,mixed> Structured provider outcome.
     */
    public function deliver(array $intent): array;
}
