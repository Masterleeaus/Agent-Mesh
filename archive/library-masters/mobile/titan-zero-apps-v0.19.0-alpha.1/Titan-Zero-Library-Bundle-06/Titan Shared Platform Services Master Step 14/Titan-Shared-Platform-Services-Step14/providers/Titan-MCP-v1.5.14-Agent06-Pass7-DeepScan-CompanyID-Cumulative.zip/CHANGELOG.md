# 1.5.8

- Bind Titan MCP card background, foreground and border directly to the host semantic CSS variables (`--card-background`, `--card-foreground`, `--card-border`) with host `--background`, `--foreground` and `--border` fallbacks.
- Preserve external stylesheet delivery while removing dependence on Tailwind utility generation for extension card colours.

# 1.5.7

- Titan MCP Overview card colours are now owned entirely by the active host theme.
- Removed MCP `color-mix`, background, border-colour and `!important` overrides that were masking `bg-card-background`, `text-card-foreground` and `border-card-border`.
- External stylesheet now supplies structure/elevation only; the dashboard theme remains appearance authority.

# 1.5.6

- Fixes Titan MCP Overview card surfaces not appearing on production hosts where inline styles are blocked/ignored.
- Moves Overview card CSS into `resources/assets/css/admin-overview.css`.
- Serves the stylesheet through an authenticated same-origin Super Admin route with `text/css` and `nosniff`.
- Loads the stylesheet with a versioned `<link rel="stylesheet">` so upgrades bypass stale browser caches.
- Uses scoped, theme-inheriting `currentColor`/`color-mix()` surfaces so dark/light/custom host themes remain authoritative without hard-coded colours.
- Adds a permanent external-stylesheet delivery regression test and rewrites older card tests to reject inline-style dependence.

# 1.5.5

- Replaced the flat Bootstrap-only Overview panels with host-theme `lqd-card` cards plus Bootstrap fallback classes.
- Added visible card elevation and explicit action buttons for all six Super Admin administration areas.
- Preserved theme ownership of colours and appearance; no inline styles or hard-coded colour values were introduced.
- Added a screenshot-driven regression test that requires host-theme card classes, elevation and visible card actions.

# 1.5.3

- Rebuilt the Super Admin Overview as a native site-theme card control centre using existing Bootstrap/Tabler-compatible host classes only; no custom colours or inline CSS.
- Added direct overview cards for Tool Catalogue, Runtime Health, Backups and Recovery, Audit Ledger, Access and Permissions, and Settings.
- Removed ampersands from Titan MCP menu labels so shared-menu escaping cannot display `&amp;` in navigation.
- Added an upgrade resync migration and regression coverage for the themed overview and literal menu labels.

# 1.5.1

- Moved Titan MCP navigation to fail-closed Super Admin-only surfaces on hosts without an explicit `menus.is_admin` discriminator.
- Removed all Titan MCP grants from the ordinary `admin` role on upgrade and made management controllers require Super Admin identity/role.
- Removes stale Titan MCP rows from the shared user menu and regenerates the host menu cache on upgrade.
- Reworked all Titan MCP admin Blade control structures for Livewire ExtendBlade compatibility, including Tool Catalogue, Backups, Runtime, Audit, Permissions, Overview and Settings.
- Added regression coverage for Super Admin navigation isolation and Blade compilation-safe templates.

# 1.5.0

- Added `titan-mcp-client-contract/1` initialization metadata with an exact catalogue contract hash, two-phase ticket capability, mutation argument preservation requirement and server write ceilings.
- Added `titan-mcp-tool-policy/1` metadata to all 34 tools with deterministic client classification, ticketability, preferred mutation flow, backup domains and post-write verification expectations.
- Corrected standard MCP destructive annotations so additive repository writes are not mislabeled destructive while genuinely destructive operations remain escalated.
- Expanded mutation preparation with `titan-mcp-approval-evidence/1`, deriving recovery domains from actual verified backup manifests and proving exact argument binding.
- Expanded commit with `titan-mcp-post-commit-evidence/1`, including server committed state, result SHA-256 and both preparation/mutation recovery evidence.
- Added client-policy/evidence regression coverage for Codee v2.3.4 convergence.

# 1.4.0

- Added actor-bound, sealed, short-lived two-phase mutation tickets for Codee/approval-centric MCP clients.
- Added `titan_mutation_prepare`, `titan_mutation_commit`, and `titan_mutation_status`; canonical catalogue now exposes 34 tools.
- Preparation validates optimistic concurrency/replace occurrence/batch/SQL/Artisan preconditions before creating verified pre-approval recovery backups.
- Commit accepts only the ticket id, atomically consumes it, re-verifies backup evidence and permissions, and executes the exact stored arguments.
- Added mutation-ticket TTL settings and lifecycle audit evidence.

# Titan MCP Changelog

## 1.2.0 — Operations console & expanded read-only tooling

- Expanded admin navigation to Overview, Tool Catalogue, Runtime Health, Backups & Recovery, Audit Ledger, Access & Permissions, and Settings.
- Expanded the canonical MCP catalogue from 21 to 28 tools.
- Added read-only configuration search, migration status, queue status, scheduler listing, MCP permission summary, audit integrity status, and backup inventory tools.
- Added upgrade-safe permissions for the new admin surfaces.


## 1.1.0 — Extension conversion
- Converted the root-level Titan MCP integration into a real Installer 1.7.8 Titan extension.
- Added extension-owned JSON-RPC/Streamable HTTP transport with 21 governed tools and the `titan_start_plan` prompt.
- Added three-level admin navigation and extension-owned settings/status UI.
- Added missing RepositoryTools and BackupTools handlers that were referenced by the old catalogue but absent from the upload delta.
- Removed runtime dependency on the former root `php-mcp/laravel` adapter.
- Preserved backup-before-write, exact database restore, mutation locking, fail-closed audit integrity and destructive capability gates.

## Agent-06 Workforce Provider Migration

- Added fail-closed `workforce-integration.json` using canonical `company_id`.
- Workforce identity/roles/hierarchy remain owned by Titan AI Workforce; provider capabilities remain extension-owned.
- Converged package/manifest metadata toward Titan Extension Blueprint v4.2.1.

## 1.5.14 — Agent-06 Upgrade Pass 2
- Workforce provider contract v1.1 with per-capability operational policy metadata.
- Command-bus/receipt enforcement metadata for state-changing Workforce actions.
- Explicit provider health, degradation, idempotency, offline and provenance requirements.
- Standalone schema/contract consistency verification.
