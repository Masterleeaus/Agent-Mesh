# Titan CRM Core v1.3.0-alpha.34 — Observability, Reliability & Operations

## Added
- `CrmOperationalMetricsService` deriving structured metrics from durable CRM command, Signal, projection, outbound, import, portal, webhook and document-render journals.
- `php artisan crm:metrics` for JSON/human-readable operational telemetry.
- `php artisan crm:doctor` for PASS/WARN/BLOCK diagnosis plus remediation and runbook guidance.
- Durable duplicate replay counters on `crm_capability_operations`.
- Configurable observability thresholds and operational recovery runbook.

## Hardened
- `crm:production-check` now exposes a stable `severity` of PASS, WARN or BLOCK and fails the process only for BLOCK conditions.
- Production health consumes operational metrics and warns on latency/backlog/dead-letter/quarantine thresholds.
- Duplicate idempotent command replays are measurable without creating a second command record.
- Operational recovery guidance explicitly preserves Command Bus, Signal, Rewind, tenant and extracted-domain authority boundaries.
