<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /** @var list<string> */
    private array $versionedTables = [
        'crm_companies','crm_contacts','crm_leads','crm_deals','crm_service_requests','crm_work_orders',
        'crm_appointments','crm_proposals','crm_estimates','crm_invoices','crm_payments','crm_customer_assets',
        'crm_projects','crm_tasks','crm_reviews','crm_support_tickets','crm_activities','crm_notes',
    ];

    public function up(): void
    {
        foreach ($this->versionedTables as $table) {
            if (! Schema::hasTable($table) || Schema::hasColumn($table,'entity_version')) continue;
            Schema::table($table, function (Blueprint $t): void {
                $t->unsignedBigInteger('entity_version')->default(1);
            });
        }

        if (Schema::hasTable('crm_capability_operations')) {
            Schema::table('crm_capability_operations', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_capability_operations','command_id')) $t->string('command_id',80)->nullable()->index();
                if (! Schema::hasColumn('crm_capability_operations','receipt_id')) $t->string('receipt_id',80)->nullable()->index();
                if (! Schema::hasColumn('crm_capability_operations','trace_id')) $t->string('trace_id',80)->nullable()->index();
                if (! Schema::hasColumn('crm_capability_operations','causation_id')) $t->string('causation_id',80)->nullable()->index();
                if (! Schema::hasColumn('crm_capability_operations','before_state_hash')) $t->char('before_state_hash',64)->nullable();
                if (! Schema::hasColumn('crm_capability_operations','after_state_hash')) $t->char('after_state_hash',64)->nullable();
                if (! Schema::hasColumn('crm_capability_operations','entity_version_before')) $t->unsignedBigInteger('entity_version_before')->nullable();
                if (! Schema::hasColumn('crm_capability_operations','entity_version_after')) $t->unsignedBigInteger('entity_version_after')->nullable();
                if (! Schema::hasColumn('crm_capability_operations','rewind_reference')) $t->json('rewind_reference')->nullable();
            });
        }

        if (! Schema::hasTable('crm_domain_signal_outbox')) {
            Schema::create('crm_domain_signal_outbox', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id',26)->unique();
                $t->unsignedBigInteger('tenant_company_id')->index();
                $t->string('event_type',180)->index();
                $t->string('aggregate_type',100)->nullable()->index();
                $t->string('aggregate_id',190)->nullable()->index();
                $t->string('capability',180)->nullable()->index();
                $t->string('receipt_id',80)->nullable()->index();
                $t->string('trace_id',80)->index();
                $t->string('correlation_id',80)->nullable()->index();
                $t->string('causation_id',80)->nullable()->index();
                $t->string('status',30)->default('pending')->index();
                $t->json('payload');
                $t->timestamp('occurred_at')->nullable()->index();
                $t->timestamp('dispatched_at')->nullable();
                $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('crm_domain_signal_outbox');

        if (Schema::hasTable('crm_capability_operations')) {
            foreach (['rewind_reference','entity_version_after','entity_version_before','after_state_hash','before_state_hash','causation_id','trace_id','receipt_id','command_id'] as $column) {
                if (Schema::hasColumn('crm_capability_operations',$column)) {
                    Schema::table('crm_capability_operations', fn(Blueprint $t) => $t->dropColumn($column));
                }
            }
        }

        foreach (array_reverse($this->versionedTables) as $table) {
            if (Schema::hasTable($table) && Schema::hasColumn($table,'entity_version')) {
                Schema::table($table, fn(Blueprint $t) => $t->dropColumn('entity_version'));
            }
        }
    }
};
