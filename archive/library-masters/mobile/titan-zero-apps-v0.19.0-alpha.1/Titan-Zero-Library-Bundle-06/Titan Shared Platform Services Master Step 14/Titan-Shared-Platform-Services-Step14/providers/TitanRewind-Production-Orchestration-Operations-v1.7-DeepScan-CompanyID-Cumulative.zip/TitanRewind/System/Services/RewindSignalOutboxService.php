<?php

declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Services;
use App\Extensions\TitanRewind\System\Jobs\PublishRewindSignalJob;
use App\Extensions\TitanRewind\System\Models\RewindSignalOutbox;
use App\Extensions\TitanRewind\System\Observability\RewindTraceContext;
use App\Extensions\TitanRewind\System\Signal\RewindSignalEnvelope;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Throwable;
final class RewindSignalOutboxService
{
    public function __construct(private RewindQueueAdmissionService $admission, private RewindDeadLetterService $deadLetters) {}
    public function emit(string $eventType, RewindTraceContext $context, array $payload=[], string $severity='INFO'): ?RewindSignalOutbox
    {
        try {
        $event=RewindSignalEnvelope::make($eventType,$context,$payload,$severity);
        $row=RewindSignalOutbox::query()->create(['outbox_uuid'=>(string)Str::uuid(),'event_id'=>$event['event_id'],'tenant_company_id'=>$context->tenantCompanyId(),'trace_id'=>$context->traceId(),'correlation_id'=>$context->correlationId(),'causation_id'=>$context->causationId(),'event_type'=>$eventType,'severity'=>$event['severity'],'payload'=>$event,'status'=>'pending','attempts'=>0,'available_at'=>now()]);
        $queue=(string)config('titan-rewind.queues.signal','titan-rewind-signal');
        $decision=$this->admission->decision($queue);
        if ($decision['allowed'] ?? false) {
            PublishRewindSignalJob::dispatch($row->id,$row->tenant_company_id)->onQueue($queue);
        } else {
            $reason='Signal delivery deferred by '.($decision['reason'] ?? 'backpressure');
            $row->forceFill(['status'=>'attention','last_error'=>$reason])->save();
            $this->deadLetters->record($queue, PublishRewindSignalJob::class,$context->tenantCompanyId(),(string)$row->event_id,['outbox_id'=>$row->id,'event_type'=>$row->event_type],new \RuntimeException($reason),0);
        }
        return $row;
        } catch (Throwable $e) {
            Log::warning('Titan Rewind Signal outbox emission failed',['event_type'=>$eventType,'exception'=>$e::class,'message'=>$e->getMessage()]);
            return null;
        }
    }
}
