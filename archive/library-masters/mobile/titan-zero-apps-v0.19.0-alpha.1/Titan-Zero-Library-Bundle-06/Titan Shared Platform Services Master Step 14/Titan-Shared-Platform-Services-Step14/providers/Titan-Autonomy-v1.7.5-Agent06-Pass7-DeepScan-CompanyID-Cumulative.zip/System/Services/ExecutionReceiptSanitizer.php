<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

final class ExecutionReceiptSanitizer
{
    private const SENSITIVE = '/(?:password|passwd|secret|token|api[_-]?key|authorization|credential|private[_-]?key|access[_-]?key|refresh[_-]?token)/i';

    public function sanitize(mixed $value): mixed
    {
        if (!is_array($value)) return $value;
        $out = [];
        foreach ($value as $key => $item) {
            $name = is_string($key) ? $key : (string) $key;
            if (preg_match(self::SENSITIVE, $name) === 1) {
                $out[$key] = '[REDACTED]';
                continue;
            }
            $out[$key] = is_array($item) ? $this->sanitize($item) : $item;
        }
        return $out;
    }
}
