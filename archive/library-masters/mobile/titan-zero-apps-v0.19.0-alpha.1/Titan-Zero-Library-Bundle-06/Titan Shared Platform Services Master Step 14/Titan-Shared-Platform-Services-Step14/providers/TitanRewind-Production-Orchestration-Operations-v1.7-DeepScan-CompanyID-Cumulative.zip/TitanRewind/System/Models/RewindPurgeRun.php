<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Models;
use Illuminate\Database\Eloquent\Model;
final class RewindPurgeRun extends Model
{
 protected $table='titan_rewind_purge_runs';protected $fillable=['run_uuid','active_key','tenant_company_id','retention_class','status','cursor_table','cursor_id','rows_deleted','rows_held','requested_by_id','started_at','completed_at','last_error'];protected $casts=['tenant_company_id'=>'integer','cursor_id'=>'integer','rows_deleted'=>'integer','rows_held'=>'integer','requested_by_id'=>'integer','started_at'=>'datetime','completed_at'=>'datetime'];
}
