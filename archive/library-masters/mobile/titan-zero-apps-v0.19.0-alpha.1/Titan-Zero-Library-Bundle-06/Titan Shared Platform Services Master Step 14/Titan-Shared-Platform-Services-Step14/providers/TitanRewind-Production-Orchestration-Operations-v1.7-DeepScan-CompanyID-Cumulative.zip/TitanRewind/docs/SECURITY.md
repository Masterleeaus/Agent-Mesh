# Titan Rewind Security

- canonical tenant boundary: `tenant_company_id`;
- fail-closed ten-permission RBAC middleware;
- tenant-scoped object queries and legal-hold object validation;
- recursive credential/private-reasoning sanitization;
- no authoritative domain mutation;
- hard rejecting replay command gateway;
- RSA-SHA256 evidence signing; private signing key is never persisted in Rewind data;
- evidence custody journal and legal holds;
- unsigned or signature-invalid packages fail verification/export.
