# Titan Forge v0.9.0-alpha.1 Release Notes

Formal roadmap Pass 19 adds a Blueprint v4.2.1-native Titan Rewind source contribution and deterministic reconstruction evidence.

Key properties:

- read-only `titan-forge.rewind-source` contribution;
- tenant/trace-scoped cursor-backed history reads;
- streamed deterministic projection and watermark aggregation;
- bounded evidence only, with peer content referenced by IDs/hashes;
- canonical SHA-256 event/source/integrity hashing and chain verification;
- complete causal lineage including `root_causation_id`;
- `supports_as_of=false` and `PARTIALLY_REPRODUCIBLE` rather than a false historical-replay claim;
- no new migration;
- `deployment_authority: none` remains unchanged.

This is a development-stage cumulative package. It is not a signed production release and no live-host certification is claimed.
