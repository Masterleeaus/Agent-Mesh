# Upgrade 1.1 → 1.2

## Before upgrade
1. Back up the application database and CRM extension directory.
2. Confirm the host has a deterministic authenticated user → business-company membership source. Configure `crm.tenancy.membership_table`/columns or a custom resolver where required.
3. Stage the upgrade on a copy of production data.

## Apply
1. Install/replace the extension package using the normal MagicAI extension lifecycle without deleting CRM data.
2. Run `php artisan optimize:clear`.
3. Run `php artisan migrate --pretend` and review SQL.
4. Run migrations. `000013` adds/backfills `tenant_company_id` only when membership is deterministic; ambiguous rows stay unresolved. `000014` replaces legacy tenant-proxy unique constraints.
5. Run `php artisan crm:titan-company-tenancy:audit`.
6. Resolve every unresolved/conflicting tenancy review before enabling production CRM/Titan traffic.
7. Run `php artisan route:list` and CRM/full test suites.
8. Exercise cross-company negative tests in staging with real memberships.

## Compatibility
Existing CRM data/tables and legitimate user actor fields are preserved. Chatbot 6.4.x remains supported while 6.5.x is source-certified. Titan Go v0.13 legacy mutation names remain aliases. Legacy Mobile capability names remain advertised as transitional aliases.

## Rollback
Application code can be rolled back independently if 1.2 migrations have not run. If schema rollback is required, use a database backup/rehearsed rollback plan. `000014` can restore legacy user-scoped unique rules and `000013` can remove new contract tables/columns, but rolling tenancy backwards after new multi-company data exists may collapse namespaces and must not be done blindly. Financial/payment reconciliation changes require special review before rollback.
