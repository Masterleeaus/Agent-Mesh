<?php

declare(strict_types=1);

namespace App\Extensions\InteractionEngine\System\Tenancy;

interface TenantContextResolverContract
{
    /** Resolve the authenticated actor's canonical Titan company_id from trusted host identity only. */
    public function companyId(mixed $authenticatedUser): string;

    public function companyIdFromRequest(mixed $request): string;

    /** @deprecated v10.3 compatibility alias. Use companyId(). */
    public function tenantId(mixed $authenticatedUser): string;

    /** @deprecated v10.3 compatibility alias. Use companyIdFromRequest(). */
    public function tenantIdFromRequest(mixed $request): string;
}
