<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyAuditSinkContract;
use App\Extensions\TitanAutonomy\System\Contracts\CapabilityStateStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\LearningSinkContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\EvidenceSnapshot;
use App\Extensions\TitanAutonomy\System\DTOs\OutcomeObservation;
use App\Extensions\TitanAutonomy\System\DTOs\RuntimeOutcomeResult;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\LearningLabel;

final class AutonomyRuntimeService
{
    public function __construct(
        private readonly CapabilityStateStoreContract $stateStore,
        private readonly LearningSinkContract $learningSink,
        private readonly AutonomyAuditSinkContract $auditSink,
        private readonly GateEvaluator $gateEvaluator,
        private readonly string $policyVersion,
        private readonly CapabilityStateTransitionService $transitions = new CapabilityStateTransitionService(),
        private readonly RegressionService $regressions = new RegressionService(),
        private readonly LearningEventFactory $learningEvents = new LearningEventFactory(),
    ) {}

    public function recordOutcome(
        CapabilityState $state,
        OutcomeObservation $observation,
        EvidenceSnapshot $evidence,
        ?int $userId,
        array $context,
        array $proposal,
        array $finalAction,
        array $outcome,
        float $confidence,
        array $learningSettings = ['user' => true, 'business' => true, 'system' => false],
    ): RuntimeOutcomeResult {
        $transition = $this->transitions->recordOutcome($state, $observation);
        $nextState = $transition->state;
        $regressionRef = null;

        $cause = $this->regressionCause($transition->learningLabel, $observation, $evidence);
        if ($cause !== null && $state->currentLevel !== AutonomyLevel::Suggest) {
            $target = $this->regressions->target($state->currentLevel, $cause);
            if ($target !== $state->currentLevel) {
                $nextState = $this->withLevel($nextState, $target);
                $regressionRef = $this->auditSink->recordRegression([
                    'tenant_company_id' => $state->tenantCompanyId,
                    'capability' => $state->capability,
                    'workflow_key' => $state->workflowKey,
                    'prior_level' => $state->currentLevel->key(),
                    'new_level' => $target->key(),
                    'cause' => $cause,
                    'evidence' => [
                        'learning_label' => $transition->learningLabel->value,
                        'reversed' => $observation->reversed,
                        'assurance_red' => $evidence->assuranceRed,
                    ],
                    'policy_version' => $this->policyVersion,
                ]);
            }
        }

        $learningScopes = [];
        if (($learningSettings['user'] ?? false) === true) $learningScopes[] = 'user';
        if (($learningSettings['business'] ?? false) === true) $learningScopes[] = 'business';
        $learningRef = null;
        if ($learningScopes !== []) {
            $learningEvent = $this->learningEvents->make(
                $state,
                $observation,
                $transition->learningLabel,
                $userId,
                $context,
                $proposal,
                $finalAction,
                $outcome,
                $confidence,
                $learningScopes,
            );
            $learningEvent['policy_version'] = $this->policyVersion;
            $learningEvent['correlation_id'] = $context['correlation_id'] ?? $outcome['correlation_id'] ?? null;
            $learningRef = $this->learningSink->record($learningEvent);
        }

        $gate = null;
        $gateRef = null;
        $nextLevel = $nextState->currentLevel->next();
        if ($nextLevel !== null) {
            $gateEvidence = $this->evidenceWithStreak($evidence, $nextState->currentSuccessStreak);
            $gate = $this->gateEvaluator->evaluate(
                $nextState->risk,
                $nextState->currentLevel,
                $nextLevel,
                $gateEvidence,
            );
            $nextState = $this->withEligibility($nextState, $gate->eligible, $gate->requiredSuccessStreak);
            $gateRef = $this->auditSink->recordGateDecision([
                'tenant_company_id' => $nextState->tenantCompanyId,
                'user_id' => $userId,
                'capability' => $nextState->capability,
                'workflow_key' => $nextState->workflowKey,
                'current_level' => $nextState->currentLevel->key(),
                'requested_level' => $nextLevel->key(),
                'eligible' => $gate->eligible,
                'reason_codes' => $gate->reasonCodes,
                'evidence' => [
                    'current_success_streak' => $nextState->currentSuccessStreak,
                    'highest_success_streak' => $nextState->highestSuccessStreak,
                    'total_successes' => $nextState->totalSuccesses,
                    'total_failures' => $nextState->totalFailures,
                    'total_edits' => $nextState->totalEdits,
                    'total_rejections' => $nextState->totalRejections,
                    'total_reversals' => $nextState->totalReversals,
                ],
                'policy_version' => $this->policyVersion,
            ]);
        } else {
            $nextState = $this->withEligibility($nextState, false, $nextState->requiredSuccessStreak);
        }

        $this->stateStore->save($nextState);

        return new RuntimeOutcomeResult($nextState, $gate, $learningRef, $gateRef, $regressionRef);
    }

    private function regressionCause(LearningLabel $label, OutcomeObservation $observation, EvidenceSnapshot $evidence): ?string
    {
        if ($observation->regressionCause !== null && $observation->regressionCause !== '') return $observation->regressionCause;
        if ($evidence->assuranceRed) return 'assurance_red';
        if ($observation->reversed || $label === LearningLabel::Reversed) return 'reversal';
        if ($label === LearningLabel::MateriallyCorrected) return 'material_correction';
        return null;
    }

    private function withLevel(CapabilityState $state, AutonomyLevel $level): CapabilityState
    {
        return new CapabilityState(
            tenantCompanyId: $state->tenantCompanyId,
            capability: $state->capability,
            workflowKey: $state->workflowKey,
            risk: $state->risk,
            currentLevel: $level,
            requiredSuccessStreak: $state->requiredSuccessStreak,
            currentSuccessStreak: 0,
            highestSuccessStreak: $state->highestSuccessStreak,
            totalSuccesses: $state->totalSuccesses,
            totalFailures: $state->totalFailures,
            totalEdits: $state->totalEdits,
            totalRejections: $state->totalRejections,
            totalReversals: $state->totalReversals,
            platformGateEligible: false,
            scope: $state->scope,
            lastSuccessAt: $state->lastSuccessAt,
            lastFailureAt: $state->lastFailureAt,
        );
    }

    private function withEligibility(CapabilityState $state, bool $eligible, int $required): CapabilityState
    {
        return new CapabilityState(
            tenantCompanyId: $state->tenantCompanyId,
            capability: $state->capability,
            workflowKey: $state->workflowKey,
            risk: $state->risk,
            currentLevel: $state->currentLevel,
            requiredSuccessStreak: $required,
            currentSuccessStreak: $state->currentSuccessStreak,
            highestSuccessStreak: $state->highestSuccessStreak,
            totalSuccesses: $state->totalSuccesses,
            totalFailures: $state->totalFailures,
            totalEdits: $state->totalEdits,
            totalRejections: $state->totalRejections,
            totalReversals: $state->totalReversals,
            platformGateEligible: $eligible,
            scope: $state->scope,
            lastSuccessAt: $state->lastSuccessAt,
            lastFailureAt: $state->lastFailureAt,
        );
    }

    private function evidenceWithStreak(EvidenceSnapshot $evidence, int $streak): EvidenceSnapshot
    {
        return new EvidenceSnapshot(
            currentSuccessStreak: $streak,
            totalSuccesses: $evidence->totalSuccesses,
            totalFailures: $evidence->totalFailures,
            totalEdits: $evidence->totalEdits,
            totalRejections: $evidence->totalRejections,
            totalReversals: $evidence->totalReversals,
            sampleRequirementsSatisfied: $evidence->sampleRequirementsSatisfied,
            failureRateWithinLimit: $evidence->failureRateWithinLimit,
            reversalRateWithinLimit: $evidence->reversalRateWithinLimit,
            correctionRateWithinLimit: $evidence->correctionRateWithinLimit,
            contextConfidenceSatisfied: $evidence->contextConfidenceSatisfied,
            dataSourcesAvailable: $evidence->dataSourcesAvailable,
            scopeValid: $evidence->scopeValid,
            hasUnresolvedIncident: $evidence->hasUnresolvedIncident,
            integrationHealthy: $evidence->integrationHealthy,
            permissionsValid: $evidence->permissionsValid,
            safetySuspended: $evidence->safetySuspended,
            autonomyHold: $evidence->autonomyHold,
            assuranceAmber: $evidence->assuranceAmber,
            assuranceRed: $evidence->assuranceRed,
        );
    }
}
