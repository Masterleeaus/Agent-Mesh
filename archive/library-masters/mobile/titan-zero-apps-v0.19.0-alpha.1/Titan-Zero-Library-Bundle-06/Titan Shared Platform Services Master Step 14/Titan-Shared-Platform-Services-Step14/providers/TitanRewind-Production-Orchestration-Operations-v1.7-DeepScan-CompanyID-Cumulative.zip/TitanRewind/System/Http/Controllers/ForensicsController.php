<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Http\Controllers;

use App\Extensions\TitanRewind\System\Models\RewindTraceEvent;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use App\Extensions\TitanRewind\System\Services\RewindDriftService;
use App\Extensions\TitanRewind\System\Services\RewindIntegrityService;
use App\Extensions\TitanRewind\System\Services\RewindTenantContextResolver;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

final class ForensicsController
{
    public function __construct(
        private RewindTenantContextResolver $tenants,
        private RewindIntegrityService $integrity,
        private RewindDriftService $drift,
    ) {}

    public function verify(Request $request, string $traceId): RedirectResponse
    {
        $query = $this->query($request, $traceId);
        $actorId = $request->user()?->getAuthIdentifier();
        $check = $this->integrity->verifyTrace($query, is_numeric($actorId) ? (int) $actorId : null);

        return redirect()->route('dashboard.user.titan.rewind.traces.show', ['traceId'=>$traceId])
            ->with('rewind_status', sprintf('Integrity check %s: %s (%d failures, %d unsealed).', $check->check_uuid, $check->status, $check->failures_count, $check->unsealed_count));
    }

    public function drift(Request $request, string $traceId): RedirectResponse
    {
        $query = $this->query($request, $traceId);
        $actorId = $request->user()?->getAuthIdentifier();
        $scan = $this->drift->scanTrace($query, is_numeric($actorId) ? (int) $actorId : null);

        return redirect()->route('dashboard.user.titan.rewind.traces.show', ['traceId'=>$traceId])
            ->with('rewind_status', sprintf('Drift scan complete: %d open finding(s), forensic state %s.', $scan['open_finding_count'], $scan['status']));
    }

    private function query(Request $request, string $traceId): RewindTraceQuery
    {
        $tenant = $this->tenants->forUser($request->user());
        abort_if($tenant === null, 403, 'Titan Rewind could not resolve an explicit tenant company for this account.');
        abort_unless(RewindTraceEvent::query()->where('tenant_company_id',$tenant)->where('trace_id',$traceId)->exists(), 404, 'Titan Rewind trace not found for this tenant.');
        return RewindTraceQuery::fromArray(['tenant_company_id'=>$tenant,'trace_id'=>$traceId]);
    }
}
