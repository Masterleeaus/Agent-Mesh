# Authorization Matrix

Super Admin is the sole unconditional bypass. Payroll reads/writes require tenant scope plus explicit host permission/capability. Delegated Admin access is bounded to Payroll permissions. AI writes require Command Bus execution receipts.
