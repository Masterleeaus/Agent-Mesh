<?php

declare(strict_types=1);

use App\Extensions\Crm\System\Navigation\CrmMenuInstaller;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('menus')) {
            return;
        }
        CrmMenuInstaller::sync();
    }

    public function down(): void
    {
        // Keep host-safe icons on rollback; reverting to an unsupported icon can crash navbar rendering.
    }
};
