<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Console;
use App\Extensions\TitanRewind\System\Services\RewindRetentionService;
use Illuminate\Console\Command;
use App\Extensions\TitanRewind\System\Models\RewindTraceIndex;
final class RunRewindRetentionCommand extends Command
{
 protected $signature='titan-rewind:retention {--tenant=} {--class=} {--batch=}';
 protected $description='Run one resumable Titan Rewind retention batch per selected tenant/class.';
 public function handle(RewindRetentionService $retention): int
 {
  $class=$this->option('class');$classes=$class?[strtolower((string)$class)]:['ephemeral','operational','forensic','evidence'];$batch=(int)($this->option('batch')?:config('titan-rewind.retention.batch_size',250));
  $tenant=$this->option('tenant');$tenants=$tenant!==null?[(int)$tenant]:RewindTraceIndex::query()->where('tenant_company_id','>',0)->distinct()->orderBy('tenant_company_id')->pluck('tenant_company_id')->map(fn($v)=>(int)$v)->all();
  foreach($tenants as $tenantId){if($tenantId<1)continue;foreach($classes as $retentionClass){$run=$retention->run($tenantId,$retentionClass,null,$batch);$this->line(sprintf('tenant=%d class=%s run=%s status=%s deleted=%d held=%d',$tenantId,$retentionClass,$run->run_uuid,$run->status,$run->rows_deleted,$run->rows_held));}}
  return self::SUCCESS;
 }
}
