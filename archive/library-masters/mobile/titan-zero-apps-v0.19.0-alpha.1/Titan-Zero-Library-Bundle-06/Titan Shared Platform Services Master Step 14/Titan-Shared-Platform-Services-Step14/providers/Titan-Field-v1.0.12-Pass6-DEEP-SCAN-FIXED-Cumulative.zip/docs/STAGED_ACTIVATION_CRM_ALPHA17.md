# Titan Field staged activation on CRM alpha.17

Titan Field 1.0.4 supports **installation** on CRM 1.3.0-alpha.17+ but supports **authoritative runtime activation** only on CRM 1.3.0-alpha.24+.

## CRM alpha.17 through alpha.23

Titan Field:

- loads its additive/restartable migrations;
- loads its view namespace;
- does not bind `FieldCommandGateway`;
- does not bind CRM compatibility adapters or Field domain services;
- exposes only one bounded read-only browser route: `dashboard.user.titan-field.schedule`;
- repoints only the existing `crm_schedule` menu row to that read-only route and renames `Calendar` to `Schedule`;
- does not expose Field mutation/API routes or modify other Field navigation;
- does not contribute AI Workforce roles;
- does not register Titan Go offline replay;
- does not schedule Field jobs.

This prevents CRM and Titan Field from becoming simultaneous authoritative writers.

## CRM alpha.24 or newer

On a subsequent Laravel application boot, the activation gate reads the CRM version from the `extensions` registry. Once it satisfies the extraction boundary, Titan Field registers its normal runtime and self-heals its existing menu identities.

No reinstall is required solely to cross the activation boundary.

## Titan Maps peer behavior

Titan Maps uses the bound Titan Field `FieldCommandGateway` as its peer-activation signal. A staged/dormant Field installation therefore remains invisible as an authoritative Field peer until activation is safe.
