@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>$pipeline['name'],'subtitle'=>'Move opportunities between validated pipeline stages.','surface'=>'leads','journey'=>'new-opportunity','secondaryJourneys'=>['new-pipeline']])
<div class="mb-3"><a href="{{ route('dashboard.user.crm.pipelines.index') }}" class="small">← Pipelines</a></div>
<div class="d-flex gap-3 overflow-auto pb-3" id="crm-pipeline-board">@foreach($pipeline['stages'] as $stage)<div class="card flex-shrink-0 crm-stage" style="width:320px" data-stage="{{ $stage['public_id'] }}"><div class="card-header d-flex justify-content-between"><strong>{{ $stage['name'] }}</strong><span>{{ $stage['deal_count'] }}</span></div><div class="card-body bg-light min-vh-25" data-drop-zone="{{ $stage['public_id'] }}">@forelse($stage['deals'] as $deal)<div class="card mb-2 crm-deal-card" draggable="true" data-deal="{{ $deal['public_id'] }}"><div class="card-body"><a href="{{ route('dashboard.user.crm.deals.show',$deal['public_id']) }}" class="fw-semibold text-decoration-none text-reset">{{ $deal['title'] }}</a><div class="small text-muted">{{ $deal['currency'] ?? 'AUD' }} {{ number_format(($deal['value_minor'] ?? 0)/100,2) }} · {{ $deal['probability'] ?? $stage['probability'] }}%</div></div></div>@empty<div class="text-muted small crm-empty">Drop deals here.</div>@endforelse</div><div class="card-footer small text-muted">{{ number_format(($stage['total_value_minor'] ?? 0)/100,2) }} total</div></div>@endforeach</div>
<script>
(() => {
 const csrf = @json(csrf_token());
 let dragged = null;
 document.querySelectorAll('.crm-deal-card').forEach(card => card.addEventListener('dragstart', () => dragged = card.dataset.deal));
 document.querySelectorAll('[data-drop-zone]').forEach(zone => {
   zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('border','border-primary'); });
   zone.addEventListener('dragleave', () => zone.classList.remove('border','border-primary'));
   zone.addEventListener('drop', async e => {
     e.preventDefault(); zone.classList.remove('border','border-primary'); if (!dragged) return;
     const response = await fetch(`{{ url('dashboard/user/crm/deals') }}/${dragged}/move`, {method:'POST', headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-TOKEN':csrf}, body:JSON.stringify({stage_public_id:zone.dataset.dropZone})});
     if (!response.ok) { alert('Deal could not be moved.'); return; }
     window.location.reload();
   });
 });
})();
</script>
@endcomponent
@endsection
