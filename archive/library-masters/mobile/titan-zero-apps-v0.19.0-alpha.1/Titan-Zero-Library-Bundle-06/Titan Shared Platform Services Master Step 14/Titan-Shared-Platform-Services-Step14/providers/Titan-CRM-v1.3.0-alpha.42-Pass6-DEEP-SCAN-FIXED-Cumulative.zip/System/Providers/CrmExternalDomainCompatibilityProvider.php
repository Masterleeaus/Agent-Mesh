<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Providers;

use App\Extensions\Crm\System\Capabilities\CrmCapabilityOwnershipMap;
use App\Extensions\Crm\System\Integrations\ExternalDomains\CrmExternalDomainCapabilityBridge;
use Illuminate\Support\ServiceProvider;

final class CrmExternalDomainCompatibilityProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(CrmCapabilityOwnershipMap::class);
        $this->app->singleton(CrmExternalDomainCapabilityBridge::class);
    }
}
