# Titan Maps Intelligence v2.0.0-beta.1 Hardening Design

## Goal
Harden alpha.17 for beta by closing verified security, governance, provider-cost, determinism, freshness and scalability gaps while preserving all working spatial functionality and installer compatibility.

## Scope
### Beta.1 implementation
1. Provider quota circuit breaker and health controls.
2. Server-side geofence reconciliation proof and scheduled processing; clients cannot authoritatively emit transitions.
3. Per-geofence hysteresis/dwell configuration and confidence output.
4. GPS anomaly scoring, stricter rate/device protections, stale-position/privacy controls and retention policy tiers.
5. Dispatch scoring profiles persisted per tenant/vertical, with governed update/read capabilities and temporal/fatigue/familiarity inputs.
6. Deterministic territory resolution: exclusion enforcement, priority -> primary branch -> nearest branch -> stable ID, matched rule chain, overlap/conflict detection and dry-run validation.
7. ETA valid-until/freshness contract and auto-refresh policy before recommendations; route history filters.
8. Route optimisation complexity controls: exact small-plan optimisation, heuristic large-plan optimisation, timeout/best-found metadata and Signal.
9. Capability/provider timeouts and clearer provider failure evidence.
10. Candidate/address dedupe foundations, business-status filtering and normalized geocode cache keys.
11. Analytics background-job/cache contract and stale analytics versioning.
12. Redis-first cache abstraction for route/matrix/capability runtime metadata with DB fallback Signal, without making Redis mandatory for installation.
13. Resource fallback review timeout/escalation and promotion approval evidence.
14. Public-map response redaction contract; tenant IDs never returned to unauthenticated public map consumers.

### Preserved existing protections verified in alpha.17
- server-derived worker identity
- tracking consent and on-duty enforcement
- stale/future GPS timestamp rejection
- accuracy threshold enforcement
- minimum ping and movement thresholds
- geofence transition idempotency
- Risk denial enforcement
- Autonomy governance
- Command Bus authoritative CRM assignment
- offline policy enforcement
- service-area exclusion enforcement

### Post-beta roadmap, not partially implemented in beta.1
- turn-by-turn voice navigation
- weather-adjusted ETA
- EV/fuel/parking/rest-stop routing suggestions
- full heatmap UI suite and historical replay controls
- customer-location history UI
- predictive demand/ETA ML through Wisdom
- indoor/floorplan mapping
- autonomous territory rebalancing suggestions
- multi-geofence workflow choreography

## Architecture
Beta.1 remains adapter-first. Maps owns spatial state/evidence only. CRM remains authoritative for jobs, customers, assignments and pricing. Consequential cross-extension mutation continues through Command Bus. Optional Titan engines remain optional host integrations and missing integrations fail closed only where the capability requires them.

Provider-cost enforcement occurs before external provider calls. Cache use never fabricates freshness. Server-side geofence reconciliation consumes append-only raw GPS pings; client enter/exit messages have no authoritative path.

Dispatch scoring configuration is stored as Maps-owned policy state keyed by tenant + optional vertical, but actual job assignment remains CRM-owned. Territory resolution produces a complete rule chain for Assurance/Rewind.

## Testing
Every new behavior gets a failing standalone/runtime verifier before implementation, then inherited alpha.17 scripts are rerun. Final certification uses an exact `TitanMapsIntelligence/` extraction of the downloadable ZIP.
