<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use InvalidArgumentException;

final class ProvisioningExecutionContext
{
    public function __construct(
        private readonly int $tenantCompanyId,
        private readonly string $initiatorType,
        private readonly string $initiatorReference,
        private readonly ?string $approvalReference = null,
        private readonly ?string $autonomyGrantReference = null,
    ) {
        if ($this->tenantCompanyId <= 0) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }
        if (!in_array($this->initiatorType, ['human', 'agent', 'system'], true)) {
            throw new InvalidArgumentException('initiator_type must be human, agent, or system.');
        }
        self::assertReference($this->initiatorReference, 'initiator_reference');
        if ($this->approvalReference !== null) { self::assertReference($this->approvalReference, 'approval_reference'); }
        if ($this->autonomyGrantReference !== null) { self::assertReference($this->autonomyGrantReference, 'autonomy_grant_reference'); }
        if ($this->initiatorType !== 'human' && $this->autonomyGrantReference === null) {
            throw new InvalidArgumentException('Agent or system initiated provisioning requires autonomy_grant_reference.');
        }
    }

    public static function human(int $tenantCompanyId, string $initiatorReference, ?string $approvalReference = null): self
    {
        return new self($tenantCompanyId, 'human', $initiatorReference, $approvalReference);
    }

    public static function agent(int $tenantCompanyId, string $initiatorReference, string $autonomyGrantReference, ?string $approvalReference = null): self
    {
        return new self($tenantCompanyId, 'agent', $initiatorReference, $approvalReference, $autonomyGrantReference);
    }

    public static function system(
        int $tenantCompanyId,
        string $initiatorReference,
        ?string $autonomyGrantReference = null,
        ?string $approvalReference = null,
    ): self {
        return new self($tenantCompanyId, 'system', $initiatorReference, $approvalReference, $autonomyGrantReference);
    }

    /** @param array<string,mixed> $data */
    public static function fromArray(array $data): self
    {
        return new self(
            self::positiveInt($data['tenant_company_id'] ?? null),
            self::requiredString($data['initiator_type'] ?? null, 'initiator_type'),
            self::requiredString($data['initiator_reference'] ?? null, 'initiator_reference'),
            self::nullableString($data['approval_reference'] ?? null),
            self::nullableString($data['autonomy_grant_reference'] ?? null),
        );
    }

    public function tenantCompanyId(): int { return $this->tenantCompanyId; }
    public function initiatorType(): string { return $this->initiatorType; }
    public function initiatorReference(): string { return $this->initiatorReference; }
    public function approvalReference(): ?string { return $this->approvalReference; }
    public function autonomyGrantReference(): ?string { return $this->autonomyGrantReference; }
    public function autonomous(): bool { return $this->initiatorType !== 'human'; }
    public function hasApprovalEvidence(): bool { return $this->approvalReference !== null; }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'tenant_company_id' => $this->tenantCompanyId,
            'initiator_type' => $this->initiatorType,
            'initiator_reference' => $this->initiatorReference,
            'approval_reference' => $this->approvalReference,
            'autonomy_grant_reference' => $this->autonomyGrantReference,
        ];
    }

    private static function assertReference(string $value, string $field): void
    {
        if (trim($value) === '' || strlen($value) > 300) { throw new InvalidArgumentException("{$field} is invalid."); }
    }
    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') { throw new InvalidArgumentException("{$field} is required."); }
        return trim($value);
    }
    private static function nullableString(mixed $value): ?string
    {
        if ($value === null) { return null; }
        if (!is_string($value) || trim($value) === '') { throw new InvalidArgumentException('Optional execution references must be non-empty strings or null.'); }
        return trim($value);
    }
    private static function positiveInt(mixed $value): int
    {
        $resolved = is_int($value) ? $value : (is_string($value) && ctype_digit($value) ? (int)$value : 0);
        if ($resolved <= 0) { throw new InvalidArgumentException('tenant_company_id must be a positive integer.'); }
        return $resolved;
    }
}
