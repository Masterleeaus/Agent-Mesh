<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Integrations;
use App\Extensions\TitanPeople\System\Governance\GovernedPeopleCommandExecutor;use App\Extensions\TitanPeople\System\Queries\PeopleReadRepository;
final readonly class PeopleIntegrationGateway implements TimeAttendancePeoplePort,PayrollPeoplePort,CredentialsPeoplePort,RecruitPeopleIngressPort,PerformancePeoplePort,OnboardingPeoplePort
{
    public function __construct(private PeopleReadRepository $read,private GovernedPeopleCommandExecutor $commands){}
    public function workerEligibility(int $tenantCompanyId,string $workerRef):array{$row=$this->read->workerByPublicId($tenantCompanyId,$workerRef);$worker=$row['worker'];return ['worker_ref'=>(string)$worker->public_id,'employment_status'=>(string)$worker->employment_status,'eligible'=>in_array((string)$worker->employment_status,['active','probation','leave'],true)];}
    public function employmentFacts(int $tenantCompanyId,string $workerRef):array{$row=$this->read->workerByPublicId($tenantCompanyId,$workerRef);$w=$row['worker'];$r=$row['relationship'];return ['worker_ref'=>(string)$w->public_id,'employment_status'=>(string)$w->employment_status,'employee_number'=>(string)$w->employee_number,'relationship_ref'=>$r?->public_id,'employment_type'=>$r?->employment_type,'starts_on'=>$r?->starts_on,'ends_on'=>$r?->ends_on];}
    public function workerIdentity(int $tenantCompanyId,string $workerRef):array{$row=$this->read->workerByPublicId($tenantCompanyId,$workerRef);$w=$row['worker'];return ['worker_ref'=>(string)$w->public_id,'employee_number'=>(string)$w->employee_number,'employment_status'=>(string)$w->employment_status];}
    public function workerOrganisationReference(int $tenantCompanyId,string $workerRef):array{$this->read->workerByPublicId($tenantCompanyId,$workerRef);return ['worker_ref'=>$workerRef,'tenant_company_id'=>$tenantCompanyId];}
    public function requestWorkerCreation(int $tenantCompanyId,array $hiredCandidateFacts,array $context):array{$context['tenant_company_id']=$tenantCompanyId;return $this->commands->execute('people.worker.create.from-hire',$hiredCandidateFacts,$context,true);}
    public function submitAcknowledgement(int $tenantCompanyId,string $workerRef,array $facts,array $context):array{$context['tenant_company_id']=$tenantCompanyId;return $this->commands->execute('people.policy.acknowledge',['worker_ref'=>$workerRef,'facts'=>$facts],$context,true);}
}
