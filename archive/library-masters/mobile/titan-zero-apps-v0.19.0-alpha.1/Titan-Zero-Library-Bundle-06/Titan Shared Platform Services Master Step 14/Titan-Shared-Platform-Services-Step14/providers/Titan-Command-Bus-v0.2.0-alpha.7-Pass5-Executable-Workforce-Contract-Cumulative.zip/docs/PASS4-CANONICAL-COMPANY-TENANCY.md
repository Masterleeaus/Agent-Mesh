# Pass 4 — Canonical Company Tenancy

Command Bus now treats `company_id` as the sole authoritative runtime company boundary. The historical `tenant_company_id` columns/fields remain only as non-authoritative compatibility aliases during upgrade convergence. Runtime reads query `company_id`; writes dual-write the legacy alias so pre-Pass4 readers can continue during the compatibility window.

The convergence migration is non-destructive: it adds/backfills `company_id` and canonical uniqueness indexes without removing audit evidence or the legacy columns. Future major releases may retire the aliases after host migration evidence confirms no remaining consumers.
