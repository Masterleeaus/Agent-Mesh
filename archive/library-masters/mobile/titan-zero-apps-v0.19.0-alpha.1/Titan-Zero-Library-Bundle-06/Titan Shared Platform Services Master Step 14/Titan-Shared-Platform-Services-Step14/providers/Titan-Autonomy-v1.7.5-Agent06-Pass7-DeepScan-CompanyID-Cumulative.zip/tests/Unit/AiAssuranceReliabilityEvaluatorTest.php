<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanAutonomy\System\Enums\HandshakeDecision;
use App\Extensions\TitanAutonomy\System\Services\AiAssuranceReliabilityEvaluator;
use PHPUnit\Framework\TestCase;

final class AiAssuranceReliabilityEvaluatorTest extends TestCase
{
    public function test_structured_reliability_can_refuse_increased_autonomy(): void
    {
        $result = (new AiAssuranceReliabilityEvaluator())->evaluate([
            'sufficient_history' => true,
            'recent_reliability_ok' => false,
            'correction_rate_ok' => false,
            'failure_rate_ok' => true,
            'reversal_rate_ok' => true,
            'context_stable' => true,
            'data_complete' => true,
            'integrations_healthy' => true,
            'tool_model_reliable' => true,
            'in_distribution' => true,
            'ambiguity_acceptable' => true,
            'assurance_status' => 'GREEN',
            'confidence' => 0.61,
            'confidence_threshold_met' => false,
        ]);
        self::assertSame(HandshakeDecision::Denied, $result['decision']);
        self::assertContains('RECENT_MATERIAL_CORRECTIONS', $result['reason_codes']);
    }
}
