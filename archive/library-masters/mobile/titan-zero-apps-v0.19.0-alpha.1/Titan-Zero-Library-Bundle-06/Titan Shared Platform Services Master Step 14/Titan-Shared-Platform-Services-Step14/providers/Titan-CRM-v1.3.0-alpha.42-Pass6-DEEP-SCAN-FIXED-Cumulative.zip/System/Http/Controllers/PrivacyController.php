<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Privacy\{CrmPrivacyService,CrmRetentionService};
use App\Extensions\Crm\System\Security\CrmPermissionService;
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class PrivacyController extends Controller
{
    public function __construct(private readonly CrmHumanMutationGateway $mutations) {}

    public function index(Request $request,CrmPrivacyService $privacy,CrmRetentionService $retention,CrmPermissionService $permissions)
    {
        $uid=(int)$request->user()->id;$permissions->authorize($uid,'crm.privacy.manage');
        return view('crm::privacy.index',['requests'=>$privacy->list($uid),'policies'=>$retention->policies($uid)]);
    }

    public function request(Request $request,CrmPermissionService $permissions)
    {
        $uid=(int)$request->user()->id;$permissions->authorize($uid,'crm.privacy.manage');
        $d=$request->validate(['request_type'=>'required|in:export,anonymize,delete','subject_type'=>'required|in:contact,lead,company','subject_public_id'=>'nullable|string|size:26','subject_email'=>'nullable|email|max:320','dry_run'=>'nullable|boolean']);
        $this->mutations->execute($request,'crm.privacy.request',$d);
        return back()->with('status','Privacy request recorded.');
    }

    public function retention(Request $request,CrmPermissionService $permissions)
    {
        $uid=(int)$request->user()->id;$permissions->authorize($uid,'crm.privacy.manage');
        $d=$request->validate(['resource_type'=>'required|in:contacts,leads,activities,email_messages','retention_days'=>'required|integer|min:30|max:36500','action'=>'required|in:review,anonymize,delete']);
        $this->mutations->execute($request,'crm.retention.policy.update',$d);
        return back()->with('status','Retention policy saved.');
    }
}
