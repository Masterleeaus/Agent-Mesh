# Disaster Recovery

Target RPO: 60 minutes. Target RTO: 240 minutes.

Backup extension-owned decision, participant, billing-reservation and compatibility-response tables. After restore: verify tenant keys, decision↔participant references, reservation terminal states, output hashes, migration level, and Signal readiness. Reconcile in-flight/non-terminal reservations to an attention-required state before accepting new governed work. Provider responses are external and must not be replayed as mutations.
