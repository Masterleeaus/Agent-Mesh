<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Contracts\CalendarRepositoryContract; use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class CalendarController {
 public function __construct(private CalendarRepositoryContract $calendar, private \App\Extensions\Crm\System\Governance\CrmHumanMutationGateway $mutations){}
 public function index(Request $r){$records=$this->calendar->search((int)$r->user()->id,$r->only(['from','to','limit']));return $r->expectsJson()?response()->json(['data'=>$records]):view('crm::calendar.index',['events'=>$records]);}
 public function store(Request $r){$d=$r->validate(['name'=>'required|string|max:255','starts_at'=>'required|date','ends_at'=>'nullable|date|after_or_equal:starts_at','all_day'=>'sometimes|boolean','status'=>'nullable|string|max:40','location'=>'nullable|string|max:255','description'=>'nullable|string|max:10000','subject_type'=>'nullable|string|max:60','subject_public_id'=>'nullable|string|size:26','external_provider'=>'nullable|string|max:60','external_event_id'=>'nullable|string|max:255','meta'=>'nullable|array']);$record=$this->mutations->execute($r,'crm.calendar.create',$d);return $r->expectsJson()?response()->json($record,201):back()->with('status','Calendar event created.');}
}
