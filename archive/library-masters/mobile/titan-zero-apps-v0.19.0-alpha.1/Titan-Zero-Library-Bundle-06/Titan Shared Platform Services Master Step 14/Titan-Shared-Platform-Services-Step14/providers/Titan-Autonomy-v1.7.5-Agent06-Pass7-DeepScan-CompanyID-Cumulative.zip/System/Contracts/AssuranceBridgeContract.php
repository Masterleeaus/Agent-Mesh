<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface AssuranceBridgeContract
{
    /** Return structured status, confidence, reason_codes and evaluation reference. */
    public function evaluate(string $capability, ?string $workflowKey, array $context): array;
}
