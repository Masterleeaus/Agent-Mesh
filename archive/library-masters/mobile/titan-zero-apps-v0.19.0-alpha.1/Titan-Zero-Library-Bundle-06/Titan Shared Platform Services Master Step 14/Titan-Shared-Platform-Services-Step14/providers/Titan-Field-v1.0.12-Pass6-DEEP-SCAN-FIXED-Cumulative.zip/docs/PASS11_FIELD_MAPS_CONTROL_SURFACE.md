# Pass 11 — Titan Maps Peer Bridge & Field Control Surface

Titan Field remains the authoritative writer for appointments, dispatch, routes and work orders. Titan Maps Intelligence is an optional spatial peer.

## Runtime boundary

- `SpatialIntelligenceGateway` is the only Field domain dependency for live position, travel estimates and graphical map payloads.
- `OptionalTitanMapsSpatialIntelligenceGateway` resolves `App\\Extensions\\TitanMapsIntelligence\\Contracts\\FieldSpatialPeerGateway` lazily by string and uses it only when installed and healthy.
- `FallbackSpatialIntelligenceGateway` preserves standalone Field behavior using retained Field location pings and deterministic Haversine travel estimates.
- High-frequency GPS writes prefer Maps when its peer contract is present. Field does not silently fall back after a Maps identity/permission rejection.
- The retained `titan_field_worker_location_pings` table remains upgrade/fallback compatibility storage and is not the preferred GPS history while Maps is active.

## Field Control

`Field Control` is a read projection combining worker lanes, appointments, dispatch, route/ETA overlays, operational exceptions and the Maps graphical map payload. Drag/drop, move and resize requests call `titan.field.scheduling|reschedule_appointment`; `AppointmentService::reschedule()` invokes `SchedulingKernel` before committing and emits `field.appointment.rescheduled`.

The Maps engine is loaded only when the Maps asset route exists and graphical maps are enabled. Otherwise the surface renders retained Field position evidence without breaking standalone boot.

## Ownership

Field operational data is never written directly by Maps. Maps provides spatial evidence/proposals. Consequential operational changes continue through the Field governed command gateway.
