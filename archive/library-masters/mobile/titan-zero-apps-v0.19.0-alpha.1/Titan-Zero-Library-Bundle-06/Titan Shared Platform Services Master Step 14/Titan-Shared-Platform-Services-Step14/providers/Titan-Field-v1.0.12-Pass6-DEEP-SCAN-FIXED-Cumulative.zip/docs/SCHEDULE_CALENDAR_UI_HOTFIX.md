# Schedule calendar UI hotfix

Titan Field 1.0.5 replaces the former table-only Schedule surface with a real month calendar.

## UI
- Monday-to-Sunday month grid.
- Appointment cards inside date cells.
- Previous, Today and Next month navigation.
- Selected-day agenda with time, appointment, worker and status.
- Existing Field Control remains available for governed worker-lane moves and resizing.

## Navigation
`crm_schedule` is canonically labelled **Schedule**. Menu health now checks child labels as well as route, parent and active state, so an adopted CRM row still labelled `Calendar` is repaired to `Schedule` on Field menu synchronisation.

## Staged activation
On CRM alpha.17-alpha.23 Titan Field remains dormant as an operational writer, but exposes this one read-only Schedule calendar and repoints only the existing `crm_schedule` row to it. Scheduling mutations, Field Control, Titan Go replay, Workforce and all other Field runtime surfaces remain disabled. At CRM alpha.24+ the normal authoritative Schedule route takes over automatically.
