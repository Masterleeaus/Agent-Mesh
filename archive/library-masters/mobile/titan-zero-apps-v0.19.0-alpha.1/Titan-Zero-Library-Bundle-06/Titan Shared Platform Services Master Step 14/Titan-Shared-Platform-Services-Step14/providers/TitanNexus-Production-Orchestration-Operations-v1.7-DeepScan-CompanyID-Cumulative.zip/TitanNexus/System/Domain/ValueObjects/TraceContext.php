<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain\ValueObjects;

use InvalidArgumentException;

final class TraceContext
{
    public function __construct(
        private readonly int $tenantCompanyId,
        private readonly string $traceId,
        private readonly string $correlationId,
        private readonly string $causationId,
    ) {
        if ($this->tenantCompanyId <= 0) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }

        self::assertUuid($this->traceId, 'trace_id');
        self::assertUuid($this->correlationId, 'correlation_id');
        self::assertUuid($this->causationId, 'causation_id');
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        return new self(
            self::positiveInt($data['tenant_company_id'] ?? null, 'tenant_company_id'),
            self::requiredString($data['trace_id'] ?? null, 'trace_id'),
            self::requiredString($data['correlation_id'] ?? null, 'correlation_id'),
            self::requiredString($data['causation_id'] ?? null, 'causation_id'),
        );
    }

    public function tenantCompanyId(): int
    {
        return $this->tenantCompanyId;
    }

    public function traceId(): string
    {
        return $this->traceId;
    }

    public function correlationId(): string
    {
        return $this->correlationId;
    }

    public function causationId(): string
    {
        return $this->causationId;
    }

    /** @return array{tenant_company_id:int, trace_id:string, correlation_id:string, causation_id:string} */
    public function toArray(): array
    {
        return [
            'tenant_company_id' => $this->tenantCompanyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
        ];
    }

    private static function assertUuid(string $value, string $field): void
    {
        if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) !== 1) {
            throw new InvalidArgumentException("{$field} must be a valid RFC 4122/9562 UUID.");
        }
    }

    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') {
            throw new InvalidArgumentException("{$field} is required.");
        }

        return trim($value);
    }

    private static function positiveInt(mixed $value, string $field): int
    {
        if (is_int($value)) {
            $resolved = $value;
        } elseif (is_string($value) && ctype_digit($value)) {
            $resolved = (int) $value;
        } else {
            throw new InvalidArgumentException("{$field} must be a positive integer.");
        }

        if ($resolved <= 0) {
            throw new InvalidArgumentException("{$field} must be a positive integer.");
        }

        return $resolved;
    }
}
