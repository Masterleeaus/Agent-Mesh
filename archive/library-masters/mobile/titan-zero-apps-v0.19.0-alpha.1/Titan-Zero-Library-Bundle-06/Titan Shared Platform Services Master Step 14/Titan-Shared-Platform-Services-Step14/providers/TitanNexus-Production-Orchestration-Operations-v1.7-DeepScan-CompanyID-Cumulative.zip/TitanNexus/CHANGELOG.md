## Persistent orchestration v1.5

- Added durable outbox, lease recovery, deduplication, retry/dead-letter/redrive, provider deferral and health telemetry for Workforce handoffs.


## Runtime hardening pass
- Added container-bound Workforce loop runtime with fail-closed provider health aggregation.
- Enforced canonical `company_id` plus full causal context on cross-extension handoffs.
- Added provider/version pinning and authority-neutral handoff envelopes.
- Enforced outcome lineage and execution receipts.
- Quarantined raw host-menu database access as legacy navigation compatibility only.

# Changelog

## 1.0.0-rc.2 Pass7-H1 — Installer 1.7.6 Manifest Compatibility

- Restores the legacy MagicAI custom-extension manifest fields required by live Installer 1.7.6: `name`, `type`, `description`, and `support_telegram`.
- Updates `TitanInstallerManifestContract` so legacy installer fields are required/allowed instead of incorrectly rejected as unsupported.
- Accepts the observed live host profile PHP 8.3.33 / Laravel 10.50.2 / MySQL / Installer 1.7.6 while retaining Installer 1.7.8 compatibility.
- Adds a permanent regression reproducing install `01M0GR9Z95Z34RZQBF1WMN8021` validation failure (`extension.json` missing valid `name`).


## 1.0.0-rc.2
- Pass 7 preparation adds provider/container boot preflight with recursive constructor-contract binding verification, boot-resource checks, navigation-failure isolation and Interface Runtime wiring checks.
- Removed the unused HTTP Kernel injection from `TitanNexusServiceProvider::boot()` and added an app-scoped route-registration guard so repeated provider boot cannot duplicate Nexus route groups.
- Adds machine-readable provider-boot preflight schema/example and CLI while keeping live `BOOT_CERTIFIED` explicitly unclaimed until the exact package boots on the MagicAI/Titan host.
- Step 5 adds deterministic Installer 1.7.8 fresh-install preflight covering installer identity/integrity, provider lifecycle entrypoints, migration order/MySQL strict-mode compatibility, routes/views, config publishing, Interface Runtime contribution and navigation wiring.
- Adds exact host-fact compatibility evaluation and exposes the complete live-host acceptance sequence through `tools/exact_host_certification.php --print-sequence` without falsely promoting preflight evidence to `INSTALLER_CERTIFIED`.
- Fixed external exact-host certification output to conform to the bundled strict report schema (`host_profile`, SHA, status and stages only).
- Step 4 adds a shared runtime dependency/capability readiness projection covering database, Vertical Engine, Command Bus, Risk, Governance, Assurance, Signal, Rewind, Autonomy, Knowledge Authority and Interface Runtime.
- Health now distinguishes `HEALTHY`, `DEGRADED`, `UNAVAILABLE` and `DISABLED`, reports configured/bound/callable/available dependency state, and separates missing required dependencies from unavailable conditional/optional integrations.
- Adds runtime `available_capabilities`, `unavailable_capabilities`, per-capability requirements/reasons and compile/history/human/autonomous/knowledge-gated/Interface Runtime execution-mode readiness.
- Provider readiness checks configured public contracts for actual container binding and configured method callability instead of treating a configured contract name as sufficient.
- Adds `nexus.runtime-readiness`, canonical readiness schema/documentation, Knowledge Authority and Interface Runtime readiness configuration, and admin diagnostics for dependency/capability availability.
- Step 3 durable compilation lifecycle adds an append-only tenant-scoped lifecycle journal alongside the current compilation aggregate.
- Persists deterministic lifecycle evidence for draft creation, validation success/failure, compilation, semantic diff, recompile planning, provisioning planning, and receipt-bearing provisioning execution.
- Adds trace/correlation/causation lineage to every lifecycle event, deterministic idempotent event IDs, bounded tenant-scoped lifecycle reads, and Control Centre lifecycle timeline exposure.
- Adds forward migration `2026_08_21_000005_create_titan_nexus_compilation_events_table.php`; all prior migrations remain unchanged.
- Step 2 adversarial-safety hardening adds a dedicated fail-closed regression suite covering strict booleans, approval policy, autonomous execution, secret-key variants, idempotency tampering, concurrency guards, tenant mismatches, malformed canonical contracts, receipt evidence, dependency cycles and menu failure isolation.
- Fixed camelCase/PascalCase secret-key normalization so values such as `dbPassword`, `refreshToken`, `clientSecret`, `apiKey` and `privateKey` cannot bypass semantic or receipt secret guards.
- Canonical Vertical Definition ingress now verifies `definition_hash` against normalized definition content and rejects tampered definitions that reuse stale provenance hashes.
- A semantic `requires_approval` disposition is now non-downgradable: Governance may strengthen approval requirements but cannot clear a required approval gate.
- System execution contexts can now carry both an Autonomy grant and explicit approval evidence when autonomous work requires owner/governance approval.
- Remediated the v1.0.0-rc.1 deep-audit release blockers without changing deterministic compiler semantics (`0.5.0`).
- Replaced permissive PHP boolean coercion at governance/mutation boundaries with strict boolean parsing; string `"false"` can no longer become `true`.
- Requires Titan Autonomy evidence for both agent- and system-initiated provisioning.
- Wired `titan-nexus.view` through user Control Centre middleware, the host authorization adapter, manifest permissions, menu contributions and Interface Runtime read surfaces.
- Added bidirectional canonical v2.2 ingress for Vertical Definition, Compiled Configuration and Validation Result contracts.
- Added forward migration `2026_08_21_000004_add_nexus_compilation_concurrency_guards.php` with tenant+compilation uniqueness and `entity_version` optimistic concurrency.
- Made repository hydration tolerant of legacy scaffold/corrupt rows so one unreadable row cannot crash tenant history.
- Wired Nexus Manager lifecycle persistence into the compilation repository and made health reflect actual database/runtime-contract readiness.
- Removed the legacy menu parent/Overview identity collision, isolated modern menu-registry failures from provider boot, and remove Nexus-owned legacy menu rows on uninstall.
- Expanded secret detection to compound names and rejects secret-like provisioning receipt metadata before persistence/Signal/Rewind emission.
- Hardened sealed-package certification so arbitrary/non-ZIP files cannot receive `PACKAGE_CERTIFIED=PASS`.
- Replaced the mislabeled empty SBOM with an SPDX-2.3 dependency document; removed stale queue configuration and the unreferenced legacy `IndexController`.
- Runtime is `1.0.0-rc.2`; exact-host Installer/MagicAI live stages remain required before final `1.0.0` promotion.

## 1.0.0-rc.1
- Completed Pass 8 package-side production hardening and exact-host certification preparation.
- Added canonical Step-10 installer, integrity, MySQL, authorization and menu compatibility adapters under the Nexus namespace.
- Added one Titan Nexus parent plus nine Control Centre child menu definitions with modern registry preference and isolated MagicAI legacy fallback.
- Added exact-host profile, host-certification report schema/template, package verifier, live-host certification sequence generator and certification runbook.
- Added `nexus.host-ready` without falsely advertising live `nexus.host-certified`.
- Preserved compiler semantics at 0.5.0 and all historical migrations unchanged.
- Runtime is a release candidate until Installer 1.7.8/MagicAI live-host stages are actually executed.

## 0.8.0
- Added the tenant-scoped Titan Nexus Control Centre with Overview, Business Profile, Compilations, Validation, Configuration Preview, History, Recompile/Diff, Provisioning Plans and Provisioning Receipts.
- Added `NexusControlCentreContract`, deterministic read models, bounded history/lineage and tenant-safe compilation selection.
- Added `TenantContextResolverContract` with fail-closed configurable host resolution using `company_id` / `tenant_company_id` attributes by default.
- Added presentation-time recursive historical secret redaction.
- Replaced scaffold Blade pages with MagicAI-compatible `panel.layout.app` Control Centre/admin diagnostics.
- Added a read-only Titan Interface Runtime v1.1 contribution with no mutating actions.

## 0.7.0
- Rebased Titan Nexus onto Blueprint v2.2 `configuration-orchestrator`.
- Added Risk, Governance, Assurance, optional Autonomy, Signal and Rewind public execution gates.
- Added canonical Nexus schema exports while preserving historical persistence compatibility.

## Pass 6 preparation — Existing-install upgrade preflight
- Added package-side existing-install upgrade preflight and installed-state compatibility evaluator.
- RC1 → RC2 preflight requires the three RC1 migrations as an exact prefix and identifies `000004` + `000005` as the expected pending migrations.
- Blocks unknown/out-of-order migration state, duplicate compilation identities, duplicate menu/route/service registrations, future-version downgrade attempts, and lifecycle table/migration mismatches.
- Does not claim live `UPGRADE_CERTIFIED`; live MagicAI/Titan host execution remains required.
