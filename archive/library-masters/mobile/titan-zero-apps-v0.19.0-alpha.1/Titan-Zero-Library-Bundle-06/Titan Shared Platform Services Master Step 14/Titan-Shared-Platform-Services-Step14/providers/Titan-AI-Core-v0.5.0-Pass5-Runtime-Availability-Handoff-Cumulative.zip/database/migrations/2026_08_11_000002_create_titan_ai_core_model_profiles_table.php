<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('titan_ai_core_model_profiles')) {
            return;
        }

        Schema::create('titan_ai_core_model_profiles', function (Blueprint $table): void {
            $table->id();
            $table->string('tenant_company_id', 191)->nullable()->index();

            // Fixed deterministic scope key avoids both MySQL NULL uniqueness ambiguity
            // and an oversized utf8mb4 composite key. Future repositories must set this
            // to SHA-256("global") or SHA-256(canonical tenant_company_id).
            $table->char('profile_scope_key', 64);
            $table->string('provider', 64);
            $table->string('model', 128);
            $table->string('model_version', 64)->default('unknown');
            $table->string('capability', 128)->index();
            $table->string('risk_ceiling', 32)->default('low');
            $table->json('calibration')->nullable();
            $table->string('rollout_state', 32)->default('candidate');
            $table->timestamps();

            $table->unique(
                ['profile_scope_key', 'provider', 'model', 'model_version', 'capability'],
                'taicore_model_profile_unique'
            );
        });
    }

    public function down(): void
    {
        // Explicit migration rollback is supported. Extension uninstall retains data.
        Schema::dropIfExists('titan_ai_core_model_profiles');
    }
};
