# Titan CRM Core 1.3.0-alpha.26 — Autonomy De-ownership

- Removed CRM-owned autonomy runtime, controllers, views and active schema migrations.
- Removed CRM-local autonomy, learning, recommendation and planning AI tools.
- Removed proactive autonomy execution from the CRM automation command.
- Removed CRM-local autonomy evidence recording from Assistant and Interaction paths.
- Added `CrmAutonomyDecisionPort` with a fail-closed deferred implementation.
- Added external integration contracts for Titan Autonomy, Titan AI Core, Titan AI Workforce and Titan Wisdom.
- Added legacy-table production warnings and a non-destructive menu cleanup migration.
- Added four-way migration/consolidation map and agent handoff packages.
