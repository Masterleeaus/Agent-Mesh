<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Services;

use App\Extensions\TitanKnowledgeAuthority\System\Contracts\KnowledgeAccessContextResolverContract;
use App\Extensions\TitanKnowledgeAuthority\System\Contracts\KnowledgeSourceVersionWriteContract;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Enums\KnowledgeScopeType;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Enums\KnowledgeSourceStatus;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Models\KnowledgeSource;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Models\KnowledgeSourceVersion;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Repositories\KnowledgeSourceScopeQuery;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Services\SourceVersionLineagePolicy;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\Services\SourceVersionTenantLineagePolicy;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeSourceVersionAppendRequest;
use App\Extensions\TitanKnowledgeAuthority\System\Domain\ValueObjects\KnowledgeSourceVersionAppendResult;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use LogicException;

final class KnowledgeSourceVersionWriteService implements KnowledgeSourceVersionWriteContract
{
    public function __construct(
        private readonly KnowledgeAccessContextResolverContract $accessContextResolver,
        private readonly KnowledgeSourceScopeQuery $scopeQuery,
        private readonly SourceVersionLineagePolicy $lineagePolicy,
        private readonly SourceVersionTenantLineagePolicy $tenantLineagePolicy,
    ) {
    }

    public function append(KnowledgeSourceVersionAppendRequest $request): KnowledgeSourceVersionAppendResult
    {
        $context = $this->accessContextResolver->current();

        return DB::transaction(function () use ($context, $request): KnowledgeSourceVersionAppendResult {
            /** @var Builder<KnowledgeSource> $sourceQuery */
            $sourceQuery = KnowledgeSource::query()->whereKey($request->sourceId);
            $this->scopeQuery->apply($sourceQuery, $context);

            /** @var KnowledgeSource $source */
            $source = $sourceQuery->lockForUpdate()->firstOrFail();
            $this->assertCanonicalWritableSource($source);
            $sourceTenantCompanyId = $source->tenant_company_id === null ? null : (int) $source->tenant_company_id;

            /** @var KnowledgeSourceVersion|null $duplicate */
            $duplicate = KnowledgeSourceVersion::query()
                ->where('source_id', $source->getKey())
                ->where('content_hash', $request->contentHash)
                ->first();

            if ($duplicate !== null) {
                $this->tenantLineagePolicy->assertConsistent(
                    $sourceTenantCompanyId,
                    $duplicate->tenant_company_id === null ? null : (int) $duplicate->tenant_company_id,
                );

                return new KnowledgeSourceVersionAppendResult(
                    versionId: (int) $duplicate->getKey(),
                    versionSequence: (int) $duplicate->version_sequence,
                    versionKey: (string) $duplicate->version_key,
                    contentHash: (string) $duplicate->content_hash,
                    created: false,
                );
            }

            /** @var KnowledgeSourceVersion|null $latest */
            $latest = KnowledgeSourceVersion::query()
                ->where('source_id', $source->getKey())
                ->orderByDesc('version_sequence')
                ->first();

            if ($latest !== null) {
                $this->tenantLineagePolicy->assertConsistent(
                    $sourceTenantCompanyId,
                    $latest->tenant_company_id === null ? null : (int) $latest->tenant_company_id,
                );
            }

            $supersedesVersionId = $this->lineagePolicy->assertExpectedPrevious(
                $latest === null ? null : (int) $latest->getKey(),
                $request->expectedSupersedesVersionId,
            );
            $sequence = $this->lineagePolicy->nextSequence($latest === null ? null : (int) $latest->version_sequence);
            $versionKey = $this->lineagePolicy->versionKey($sequence);

            $version = new KnowledgeSourceVersion();
            $version->forceFill([
                'source_id' => (int) $source->getKey(),
                'version_sequence' => $sequence,
                'version_key' => $versionKey,
                'content_hash' => $request->contentHash,
                'raw_evidence_hash' => $request->rawEvidenceHash,
                'content_type' => $request->contentType,
                'content_storage_ref' => $request->contentStorageRef,
                'raw_evidence_storage_ref' => $request->rawEvidenceStorageRef,
                'retrieved_at' => $request->retrievedAt,
                'published_at' => $request->publishedAt,
                'effective_from' => $request->effectiveFrom,
                'effective_until' => $request->effectiveUntil,
                'supersedes_version_id' => $supersedesVersionId,
                'etag' => $request->etag,
                'last_modified' => $request->lastModified,
                'immutable' => true,
                'provenance' => $request->provenance,
                'metadata' => $request->metadata,
                'tenant_company_id' => $sourceTenantCompanyId,
                'trace_id' => $request->traceId,
                'correlation_id' => $request->correlationId,
                'causation_id' => $request->causationId,
            ]);
            $version->save();

            return new KnowledgeSourceVersionAppendResult(
                versionId: (int) $version->getKey(),
                versionSequence: $sequence,
                versionKey: $versionKey,
                contentHash: $request->contentHash,
                created: true,
            );
        }, 3);
    }

    private function assertCanonicalWritableSource(KnowledgeSource $source): void
    {
        $scope = (string) ($source->scope_type ?? '');
        $status = $source->status instanceof KnowledgeSourceStatus
            ? $source->status
            : KnowledgeSourceStatus::tryFrom((string) $source->status);

        if ($status !== KnowledgeSourceStatus::Active) {
            throw new LogicException('Only active canonical knowledge sources may receive new immutable versions.');
        }
        if ($source->source_key === null || trim((string) $source->source_key) === '') {
            throw new LogicException('Knowledge source must have a canonical source_key before versioning.');
        }
        if ($scope === KnowledgeScopeType::Tenant->value && $source->tenant_company_id === null) {
            throw new LogicException('Tenant-scoped knowledge source is missing tenant_company_id.');
        }
        if ($scope === KnowledgeScopeType::Tenant->value && $source->jurisdiction_id !== null) {
            throw new LogicException('Tenant-scoped knowledge source cannot also own jurisdiction scope.');
        }
        if ($scope === KnowledgeScopeType::Jurisdiction->value && $source->jurisdiction_id === null) {
            throw new LogicException('Jurisdiction-scoped knowledge source is missing jurisdiction_id.');
        }
        if ($scope === KnowledgeScopeType::Jurisdiction->value && $source->tenant_company_id !== null) {
            throw new LogicException('Jurisdiction-scoped knowledge source cannot carry tenant_company_id.');
        }
        if ($scope === KnowledgeScopeType::Platform->value && ($source->tenant_company_id !== null || $source->jurisdiction_id !== null)) {
            throw new LogicException('Platform-scoped knowledge source cannot carry tenant or jurisdiction ownership.');
        }
        if (! in_array($scope, [KnowledgeScopeType::Platform->value, KnowledgeScopeType::Jurisdiction->value, KnowledgeScopeType::Tenant->value], true)) {
            throw new LogicException('Legacy or malformed knowledge source scope cannot receive canonical versions.');
        }
    }
}
