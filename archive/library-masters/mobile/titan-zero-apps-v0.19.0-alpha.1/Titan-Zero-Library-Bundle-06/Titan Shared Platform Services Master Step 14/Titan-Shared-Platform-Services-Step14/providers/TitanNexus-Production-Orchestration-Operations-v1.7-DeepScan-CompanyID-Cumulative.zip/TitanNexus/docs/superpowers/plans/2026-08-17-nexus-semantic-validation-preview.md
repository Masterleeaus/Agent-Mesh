# Titan Nexus Semantic Validation & Dry-Run Preview Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add deterministic semantic validation, capability readiness checks, and non-mutating dry-run previews to Titan Nexus.

**Architecture:** Validation is implemented with immutable domain findings/results and a pure validator. Host capability readiness is consumed only through a public contract adapter. Nexus Manager enforces validation before compilation and derives previews entirely in memory.

**Tech Stack:** PHP 8.2+, Laravel 10 service provider/Eloquent integration, JSON manifests, standalone PHP verification scripts, PHPUnit-compatible tests.

## Global Constraints

- Preserve all v0.3.0 useful code and forward-only migrations.
- Do not provision or mutate CRM, Workforce, PWAs, Risk, Governance, Signal, Rewind, or Command Bus.
- Do not import another Titan extension's implementation namespace.
- Validation errors block compilation; warnings do not.
- Preview is always dry-run and side-effect-free.
- Existing vertical definitions without validation metadata must keep identical fingerprints.
- Existing persisted compilations without validation results must remain readable.

---

### Task 1: Immutable validation domain

**Files:**
- Create: `System/Domain/ValidationSeverity.php`
- Create: `System/Domain/ValidationFinding.php`
- Create: `System/Domain/ValidationResult.php`
- Test: `tests/Unit/ValidationTest.php`
- Test: `tests/standalone-validation-check.php`

**Interfaces:**
- Produces: deterministic finding/result objects with `toArray()`, `fromArray()`, `hasErrors()`, and `fingerprint()`.

- [x] **Step 1: Write failing tests** for deterministic ordering, error/warning classification, and round-trip serialization.
- [x] **Step 2: Run `php tests/standalone-validation-check.php`** and verify it fails because production validation classes are absent.
- [x] **Step 3: Implement the three validation domain classes** with input validation and canonical ordering.
- [x] **Step 4: Re-run standalone validation test** and require PASS.

### Task 2: Vertical validation metadata and readiness boundary

**Files:**
- Modify: `System/Domain/VerticalDefinition.php`
- Create: `System/Contracts/PlatformReadinessSourceContract.php`
- Create: `System/Adapters/Platform/PlatformReadinessAdapter.php`
- Create: `System/Contracts/NexusValidatorContract.php`
- Create: `System/Services/SemanticNexusValidator.php`
- Modify: `config/titan-nexus.php`
- Test: `tests/Unit/ValidationTest.php`
- Test: `tests/standalone-validation-check.php`

**Interfaces:**
- Consumes: `BusinessProfile`, `VerticalDefinition`, requested capability keys.
- Produces: `ValidationResult SemanticNexusValidator::validate(BusinessProfile, VerticalDefinition)`.

- [x] **Step 1: Extend failing tests** for required/recommended paths, readiness, knowledge snapshots, and secret material.
- [x] **Step 2: Run standalone validation test** and verify expected RED failures.
- [x] **Step 3: Add optional validated vertical rules and readiness adapter** while preserving old definition fingerprints when rules are empty.
- [x] **Step 4: Implement semantic validator** with fail-closed structured findings.
- [x] **Step 5: Re-run validation and existing compiler tests** and require PASS.

### Task 3: Validation-aware compilation aggregate

**Files:**
- Modify: `System/Domain/NexusCompilation.php`
- Create: `System/Exceptions/NexusValidationException.php`
- Test: `tests/Unit/DomainCoreTest.php`
- Test: `tests/standalone-domain-check.php`

**Interfaces:**
- Produces: immutable `withValidationResult()`, `validationResult()`, and persisted `validation_result`.

- [x] **Step 1: Write failing aggregate tests** proving validation survives compile transitions and persistence arrays.
- [x] **Step 2: Run standalone domain check** and verify RED.
- [x] **Step 3: Add optional validation state** without changing existing lifecycle statuses.
- [x] **Step 4: Re-run domain and compiler tests** and require PASS.

### Task 4: Dry-run preview and manager enforcement

**Files:**
- Create: `System/Domain/CompilationPreview.php`
- Modify: `System/Contracts/NexusManagerContract.php`
- Modify: `System/Services/NexusManager.php`
- Modify: `System/TitanNexusServiceProvider.php`
- Test: `tests/Unit/PreviewTest.php`
- Test: `tests/standalone-preview-check.php`
- Modify: `tests/standalone-manager-check.php`

**Interfaces:**
- Produces: `validateDraft()`, validation-gated `compileDraft()`, and `previewDraft()`.

- [x] **Step 1: Write failing preview/manager tests** for blocked preview, ready preview, warnings, and compile rejection.
- [x] **Step 2: Run preview/manager scripts** and verify RED.
- [x] **Step 3: Implement `CompilationPreview` and manager validation gate** without persistence or provisioning side effects.
- [x] **Step 4: Wire validator/readiness contracts in provider** using configured public contract or static capabilities.
- [x] **Step 5: Re-run standalone manager/preview/compiler tests** and require PASS.

### Task 5: Package truthfulness and cumulative verification

**Files:**
- Modify: `extension.json`
- Modify: `extension.manifest.json`
- Modify: `README.md`
- Modify: `resources/views/index.blade.php`
- Modify: `resources/views/admin.blade.php`
- Modify: `tests/Feature/ExtensionBootTest.php`
- Modify: `tests/Architecture/BoundaryTest.php`
- Modify: `tests/Unit/ScaffoldContractTest.php`
- Modify: `tests/standalone-package-check.php`

**Interfaces:**
- Produces: truthful v0.4.0 package metadata for `nexus.validate` and `nexus.preview`; `nexus.provision` remains absent.

- [x] **Step 1: Update package tests first** to expect v0.4.0 validation/preview capabilities and readiness bindings.
- [x] **Step 2: Run package check** and verify RED against v0.3.0 metadata.
- [x] **Step 3: Update package metadata/docs/views and stale tests** to the v0.4.0 implementation.
- [x] **Step 4: Run all standalone scripts, PHP lint, JSON parsing, static boundary/safety scans, and original migration hash comparison.**
- [x] **Step 5: Build the cumulative ZIP, re-extract it, rerun verification, compute SHA-256, and report CODEE artifact metadata.**
