# Titan CRM Core v1.3.0-alpha.31 — Command Contract v3

- Standardizes all governed CRM writes on command contract v3.
- Carries command, tenant, actor, capability, trace/correlation/causation, idempotency and expected entity-version metadata.
- Expands durable receipts with affected resources, invariant results, external-effect references, compensation state, remediation, Rewind and exact Signal outbox references.
- Adds durable operation-store envelope/evidence columns.
- Adds `crm:governance:audit-writes` and production-health enforcement for HTTP/console mutation surfaces.
- Routes privacy requests, retention-policy changes and destructive retention execution through Command Bus governance.
- Preserves explicit non-business exceptions only for host-global settings, derived read/document state, delivery journals and automation run journals.
