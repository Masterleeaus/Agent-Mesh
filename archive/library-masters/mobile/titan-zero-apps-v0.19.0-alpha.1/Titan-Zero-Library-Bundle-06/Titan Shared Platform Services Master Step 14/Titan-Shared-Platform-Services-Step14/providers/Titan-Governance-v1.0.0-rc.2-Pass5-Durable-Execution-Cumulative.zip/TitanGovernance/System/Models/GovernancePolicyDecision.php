<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Models;

use Illuminate\Database\Eloquent\Model;

final class GovernancePolicyDecision extends Model
{
    protected $table='titan_governance_policy_decisions';
    protected $guarded=[];
    protected $casts=[
        'reason_codes'=>'array',
        'evidence_refs'=>'array',
        'result_payload'=>'array',
        'write_verified'=>'boolean',
        'decided_at'=>'datetime',
    ];
}
