<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryRedriveContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliverySchedulerContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterAuthorityContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalEmitterContract;
use App\Extensions\TitanSignalEngine\System\Contracts\SignalSubscriptionRegistryContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryReceipt;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryRedrivePolicy;
use App\Extensions\TitanSignalEngine\System\Models\SignalDelivery;
use App\Extensions\TitanSignalEngine\System\Models\SignalDeliveryRedrive;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

final class SignalDeliveryRedriveService implements SignalDeliveryRedriveContract
{
    public function __construct(
        private readonly SignalDeliverySchedulerContract $scheduler,
        private readonly SignalSubscriptionRegistryContract $subscriptions,
        private readonly SignalEmitterContract $emitter,
        private readonly SignalEmitterAuthorityContract $emitterAuthority,
        private readonly SignalContextValidator $contexts,
        private readonly SignalDeliveryRedrivePolicy $policy,
    ) {
    }

    public function redrive(string $deliveryId, string $reason, SignalContext $context): SignalDeliveryReceipt
    {
        $deliveryId = trim($deliveryId);
        $reason = trim($reason);
        if ($deliveryId === '' || $reason === '' || strlen($reason) > 500) {
            throw new InvalidArgumentException('Signal delivery redrive requires a delivery id and a reason up to 500 characters.');
        }
        if (! $context->hasPermission('signal.delivery.redrive')) {
            throw new InvalidArgumentException('Signal delivery redrive requires signal.delivery.redrive permission.');
        }
        if (! Schema::hasTable('titan_signal_deliveries') || ! Schema::hasTable('titan_signal_delivery_redrives')) {
            throw new RuntimeException('Signal delivery redrive storage is not installed.');
        }

        /** @var SignalDelivery|null $existing */
        $existing = SignalDelivery::query()->where('delivery_id', $deliveryId)->first();
        if ($existing === null) throw new RuntimeException('Signal delivery does not exist.');
        $this->contexts->assertQueryAllowed((string) $existing->scope, $existing->tenant_company_id === null ? null : (int) $existing->tenant_company_id, $context);
        if (! $this->policy->canRedrive((string) $existing->status)) {
            throw new InvalidArgumentException('Only dead-letter deliveries may be redriven.');
        }

        $subscription = $this->subscriptions->find((string) $existing->subscriber_key);
        if ($subscription === null || $subscription->status === 'disabled') {
            throw new InvalidArgumentException('Dead-letter delivery cannot be redriven until its subscriber is installed and enabled.');
        }

        /** @var SignalDelivery $fresh */
        $fresh = DB::transaction(function () use ($deliveryId, $reason, $context): SignalDelivery {
            /** @var SignalDelivery|null $locked */
            $locked = SignalDelivery::query()->where('delivery_id', $deliveryId)->lockForUpdate()->first();
            if ($locked === null) throw new RuntimeException('Signal delivery does not exist.');
            if (! $this->policy->canRedrive((string) $locked->status)) {
                throw new InvalidArgumentException('Signal delivery is no longer in dead-letter state.');
            }

            $nextRedrive = (int) ($locked->redrive_count ?? 0) + 1;
            $now = now();
            $updated = SignalDelivery::query()
                ->where('delivery_id', $deliveryId)
                ->where('status', 'dead_letter')
                ->update([
                    'status' => 'retry_wait',
                    'attempt_count' => $this->policy->nextAttemptCount(),
                    'available_at' => $now,
                    'queued_at' => null,
                    'reserved_at' => null,
                    'lease_token' => null,
                    'lease_owner' => null,
                    'lease_expires_at' => null,
                    'processing_started_at' => null,
                    'dead_letter_resolved_at' => $now,
                    'redrive_count' => $nextRedrive,
                    'last_redriven_at' => $now,
                    'last_redriven_by' => substr($context->actor->id, 0, 191),
                    'last_redrive_reason_hash' => $this->policy->reasonHash($reason),
                    'updated_at' => $now,
                ]);
            if ($updated !== 1) {
                throw new RuntimeException('Signal dead-letter delivery changed before it could be redriven.');
            }

            SignalDeliveryRedrive::query()->create([
                'redrive_id' => self::uuid7(),
                'delivery_id' => (string) $locked->delivery_id,
                'event_id' => (string) $locked->event_id,
                'subscriber_key' => (string) $locked->subscriber_key,
                'scope' => (string) $locked->scope,
                'tenant_company_id' => $locked->tenant_company_id,
                'redrive_count' => $nextRedrive,
                'failed_attempt_count' => (int) $locked->attempt_count,
                'dead_lettered_at' => $locked->dead_lettered_at,
                'error_class' => $locked->last_error_class === null ? null : substr((string) $locked->last_error_class, 0, 255),
                'error_reference' => $locked->last_error === null ? null : substr((string) $locked->last_error, 0, 2000),
                'actor_id' => substr($context->actor->id, 0, 191),
                'actor_type' => substr($context->actor->type, 0, 32),
                'reason' => $reason,
                'reason_hash' => $this->policy->reasonHash($reason),
                'requested_at' => $now,
            ]);

            /** @var SignalDelivery $result */
            $result = SignalDelivery::query()->where('delivery_id', $deliveryId)->firstOrFail();
            return $result;
        }, 3);

        $this->scheduler->enqueue($deliveryId, 0);
        $this->reportRedrive($fresh, $reason, $context);

        /** @var SignalDelivery $after */
        $after = SignalDelivery::query()->where('delivery_id', $deliveryId)->firstOrFail();
        return $this->receipt($after);
    }

    public function redriveBatch(
        string $scope,
        ?int $tenantCompanyId,
        ?string $subscriberKey,
        int $limit,
        string $reason,
        SignalContext $context,
    ): array {
        $scope = trim($scope);
        $reason = trim($reason);
        if ($reason === '' || strlen($reason) > 500) {
            throw new InvalidArgumentException('Signal delivery batch redrive requires a reason up to 500 characters.');
        }
        $subscriberKey = $subscriberKey === null ? null : trim($subscriberKey);
        $limit = max(1, min($limit, (int) config('titan-signal-engine.delivery_redrive_batch_limit', 250)));
        $this->contexts->assertQueryAllowed($scope, $tenantCompanyId, $context);
        if (! $context->hasPermission('signal.delivery.redrive')) {
            throw new InvalidArgumentException('Signal delivery redrive requires signal.delivery.redrive permission.');
        }

        $query = SignalDelivery::query()->where('status', 'dead_letter')->where('scope', $scope);
        $scope === 'tenant' ? $query->where('tenant_company_id', $tenantCompanyId) : $query->whereNull('tenant_company_id');
        if ($subscriberKey !== null && $subscriberKey !== '') $query->where('subscriber_key', $subscriberKey);

        $ids = $query->orderBy('dead_lettered_at')->orderBy('id')->limit($limit)->pluck('delivery_id')->map(static fn ($id): string => (string) $id)->all();
        $redriven = [];
        $skipped = 0;
        foreach ($ids as $id) {
            try {
                $this->redrive($id, $reason, $context);
                $redriven[] = $id;
            } catch (Throwable $exception) {
                $skipped++;
                Log::warning('signal.delivery_redrive_skipped', ['delivery_id' => $id, 'error_class' => $exception::class]);
            }
        }

        return ['selected' => count($ids), 'redriven' => count($redriven), 'skipped' => $skipped, 'delivery_ids' => $redriven];
    }

    private function reportRedrive(SignalDelivery $delivery, string $reason, SignalContext $actorContext): void
    {
        try {
            /** @var SignalEvent|null $sourceEvent */
            $sourceEvent = SignalEvent::query()->where('event_id', $delivery->event_id)->first();
            $auditContext = new SignalContext(
                $actorContext->scope,
                $actorContext->tenantCompanyId,
                $actorContext->actor,
                array_values(array_unique([...$actorContext->permissions, 'signal.tenant.emit'])),
                $this->emitterAuthority->issue('titan-signal-engine:delivery-recovery'),
            );

            $signal = [
                'event_type' => 'signal.subscription.redriven',
                'scope' => (string) $delivery->scope,
                'tenant_company_id' => $delivery->tenant_company_id,
                'schema_version' => 1,
                'severity' => 'info',
                'category' => 'operations',
                'vertical_key' => $sourceEvent?->vertical_key,
                'idempotency_key' => 'redrive:' . $delivery->delivery_id . ':' . $delivery->redrive_count,
                'payload' => [
                    'delivery_id' => (string) $delivery->delivery_id,
                    'event_id' => (string) $delivery->event_id,
                    'subscriber_key' => (string) $delivery->subscriber_key,
                    'redrive_count' => (int) $delivery->redrive_count,
                    'reason_hash' => $this->policy->reasonHash($reason),
                ],
            ];
            if ($sourceEvent !== null) {
                $signal['trace_id'] = (string) $sourceEvent->trace_id;
                $signal['correlation_id'] = (string) $sourceEvent->correlation_id;
                $signal['causation_id'] = (string) $sourceEvent->event_id;
                $signal['root_causation_id'] = (string) ($sourceEvent->root_causation_id ?: $sourceEvent->event_id);
            }
            $this->emitter->emit($signal, $auditContext);
        } catch (Throwable $exception) {
            Log::error('signal.delivery_redrive_signal_failed', [
                'delivery_id' => $delivery->delivery_id,
                'redrive_count' => $delivery->redrive_count,
                'error_class' => $exception::class,
            ]);
        }
    }

    private function receipt(SignalDelivery $delivery): SignalDeliveryReceipt
    {
        $next = $delivery->available_at === null ? null : $this->toImmutable($delivery->available_at);
        return new SignalDeliveryReceipt(
            (string) $delivery->delivery_id,
            (string) $delivery->event_id,
            (string) $delivery->subscriber_key,
            (string) $delivery->status,
            (int) $delivery->attempt_count,
            $next,
            $delivery->last_error === null ? null : (string) $delivery->last_error,
        );
    }

    private function toImmutable(mixed $value): DateTimeImmutable
    {
        if ($value instanceof DateTimeInterface) return new DateTimeImmutable($value->format(DATE_ATOM));
        return new DateTimeImmutable((string) $value, new DateTimeZone('UTC'));
    }

    private static function uuid7(): string
    {
        $milliseconds = (int) floor(microtime(true) * 1000);
        $timeHex = str_pad(dechex($milliseconds), 12, '0', STR_PAD_LEFT);
        $random = bin2hex(random_bytes(10));
        $hex = $timeHex . $random;
        $hex[12] = '7';
        $variant = hexdec($hex[16]);
        $hex[16] = dechex(($variant & 0x3) | 0x8);
        return sprintf('%s-%s-%s-%s-%s', substr($hex, 0, 8), substr($hex, 8, 4), substr($hex, 12, 4), substr($hex, 16, 4), substr($hex, 20, 12));
    }
}
