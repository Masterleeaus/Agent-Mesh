<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Streaming;
final class RewindStreamWindow
{
    public function __construct(private int $maxItems = 5000)
    {
        if ($maxItems < 1) throw new \InvalidArgumentException('maxItems must be positive');
    }
    public function consume(iterable $stream): array
    {
        $items=[];$observed=0;
        foreach($stream as $item){$observed++;if(count($items)<$this->maxItems)$items[]=$item;}
        return ['items'=>$items,'observed_count'=>$observed,'truncated'=>$observed>count($items),'max_items'=>$this->maxItems];
    }
}
