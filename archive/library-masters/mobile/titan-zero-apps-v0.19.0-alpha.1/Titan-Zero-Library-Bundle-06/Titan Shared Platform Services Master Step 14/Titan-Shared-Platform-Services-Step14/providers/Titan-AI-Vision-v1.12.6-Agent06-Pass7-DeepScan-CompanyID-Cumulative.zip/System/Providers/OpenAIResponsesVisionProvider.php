<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Providers;
use App\Extensions\TitanAIVision\System\Contracts\VisionProviderContract;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
final class OpenAIResponsesVisionProvider implements VisionProviderContract {
    public function key():string{return 'openai-responses';}
    public function analyse(string $prompt,array $images,array $context=[]):array{
        $apiKey=$this->apiKey();if($apiKey==='')throw new \RuntimeException('OpenAI API key is not configured.');
        $content=[['type'=>'input_text','text'=>$prompt]];
        foreach($images as $source){$url=$this->imageInput((string)$source);if($url!==null)$content[]=['type'=>'input_image','image_url'=>$url,'detail'=>config('titan-ai-vision.openai_detail','high')];}
        if(count($content)===1)throw new \InvalidArgumentException('No usable image inputs were supplied.');
        $payload=['model'=>config('titan-ai-vision.openai_model','gpt-5-mini'),'input'=>[['role'=>'user','content'=>$content]],'text'=>['format'=>['type'=>'json_object']]];
        $response=Http::withToken($apiKey)->acceptJson()->timeout(180)->post('https://api.openai.com/v1/responses',$payload);
        if(!$response->successful())throw new \RuntimeException('OpenAI vision request failed with HTTP '.$response->status().'.');
        $json=$response->json();return ['provider'=>$this->key(),'model'=>$json['model']??$payload['model'],'request_id'=>$response->header('x-request-id'),'text'=>$this->extractOutputText((array)$json),'raw'=>$json];
    }
    private function apiKey():string{
        try{if(class_exists(\App\Helpers\Classes\ApiHelper::class)){$key=\App\Helpers\Classes\ApiHelper::setOpenAiKey();if(is_string($key)&&trim($key)!=='')return trim($key);}}catch(\Throwable){}
        return (string)(config('openai.api_key')?:config('titan-ai-vision.openai_api_key',''));
    }
    private function imageInput(string $source):?string{
        if(Str::startsWith($source,['https://','http://','data:image/']))return $source;$candidate=ltrim((string)(parse_url($source,PHP_URL_PATH)?:$source),'/');
        foreach([$source,public_path($candidate),base_path($candidate),storage_path('app/'.$candidate)] as $path){if(is_string($path)&&is_file($path)&&is_readable($path)){$bytes=file_get_contents($path);if($bytes===false)return null;$mime=mime_content_type($path)?:'image/jpeg';if(!Str::startsWith($mime,'image/'))return null;return 'data:'.$mime.';base64,'.base64_encode($bytes);}}
        return null;
    }
    private function extractOutputText(array $json):string{$chunks=[];foreach(($json['output']??[]) as $item){foreach(($item['content']??[]) as $content){if(($content['type']??'')==='output_text'&&isset($content['text']))$chunks[]=(string)$content['text'];}}return trim(implode("\n",$chunks));}
}
