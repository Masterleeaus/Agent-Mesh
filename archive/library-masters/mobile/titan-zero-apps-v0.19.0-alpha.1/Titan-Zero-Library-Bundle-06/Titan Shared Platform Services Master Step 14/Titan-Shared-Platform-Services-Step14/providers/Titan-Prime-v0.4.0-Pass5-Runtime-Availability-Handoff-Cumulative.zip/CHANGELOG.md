# Changelog

## 0.4.0

- Added the Prime Engine Gateway Layer for AI Core, Signal, Risk, Assurance, Autonomy, Governance, Rewind and Wisdom.
- Added `EngineBridgeContract` as a Prime-owned integration port and `FailClosedEngineBridge` as the safe default.
- Added canonical engine request/result envelopes carrying tenant and complete causal context plus caller-owned operation IDs.
- Added explicit succeeded/denied/escalated/unavailable/failed result states; only succeeded permits continuation.
- Added gateway response identity checks and exception redaction.
- Added recursive secret-like payload-field rejection at the gateway boundary.
- Added engine availability catalog and surfaced execution-gateway readiness in Prime health.
- Added host-overridable service bindings for all typed gateways.
- Added optional dependency declarations for Titan AI Core and Titan Governance.
- Expanded certification and architecture tests for gateway bindings and no cross-extension implementation imports.
- Kept orchestration, queues, automatic Signal events and foreign-domain mutation disabled.

## 0.3.0

- Added the durable tenant-scoped Prime mission store.
- Added `PrimeMissionRepositoryContract` and extension-owned Eloquent persistence adapters.
- Added forward-only mission schema upgrades for mission identity, objective/budget state, initiator identity, versioning and record format.
- Added `titan_prime_mission_operations` for idempotency receipts and payload collision detection.
- Added optimistic compare-and-swap transitions using expected mission status plus `lock_version`.
- Added deterministic SHA-256 operation fingerprints and original-receipt replay semantics.
- Added 24-hour idempotency expiry and explicit operation receipt retention.
- Added mission reconstitution and persistence snapshot/write-receipt value objects.
- Expanded host certification to verify persistence binding, tables and required columns.
- Preserved the v4.2 strategic-orchestrator profile and kept orchestration/queues disabled.

## 0.2.1

- Aligned package manifests to Titan Extension Blueprint v4.2 Manifest 2.2 and Installer 1.7.8.
- Declared the `strategic-orchestrator` profile with `ai-enabled`, `autonomy-aware` and `signal-aware` modifiers.
- Added scoped health and host certification contracts without enabling orchestration.
- Added complete root causal lineage to the domain trace contract.
- Added a forward-only causal-lineage migration.
- Added canonical governance, service identity, navigation, production-core and operational documentation declarations.
