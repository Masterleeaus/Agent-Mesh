# Data Ownership

Titan Payroll owns only tables prefixed `ext_titan_payroll_`. All tenant-owned tables carry `tenant_company_id` indexes and compound uniqueness/indexes appropriate to their business key. Payroll does not mutate host user, company, menu-schema, Time Attendance, Communications, Rewind or accounting/payment provider data.

The `menus` table is a controlled compatibility exception: `PayrollMenuRegistrar` may self-heal Titan Payroll menu rows when the host contribution registry is unavailable. It preserves existing rows and host ordering/activation fields rather than treating menus as payroll business data.

Command receipts use an opaque globally unique `receipt_key = sha256(tenant_company_id|capability|idempotency_key)`. The row also stores/indexes `tenant_company_id` and has a tenant/capability/idempotency unique key. Receipt lookup by the opaque key therefore does not create a caller-controlled tenant bypass.

External-system identifiers and revisions are stored as references/provenance only. Payroll does not copy authoritative Time Attendance raw records or provider secrets into its domain tables.
