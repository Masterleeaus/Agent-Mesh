<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Contracts;

interface TenantAssuranceBridgeContract
{
    /**
     * Evaluate Assurance for a server-trusted tenant boundary.
     *
     * This contract exists for background reconciliation where no authenticated
     * user session is available. Implementations MUST scope all reads to the
     * supplied tenantCompanyId and MUST NOT infer tenancy from request data.
     */
    public function evaluateForTenant(
        int $tenantCompanyId,
        string $capability,
        ?string $workflowKey,
        array $context,
    ): array;
}
