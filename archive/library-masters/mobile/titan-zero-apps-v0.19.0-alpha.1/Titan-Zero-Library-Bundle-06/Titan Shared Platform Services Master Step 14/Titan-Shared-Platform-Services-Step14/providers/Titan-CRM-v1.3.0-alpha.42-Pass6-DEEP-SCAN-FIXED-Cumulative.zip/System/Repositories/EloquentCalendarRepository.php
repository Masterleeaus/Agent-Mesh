<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Repositories;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Contracts\CalendarRepositoryContract; use Illuminate\Database\ConnectionInterface; use Illuminate\Support\Str;
final class EloquentCalendarRepository implements CalendarRepositoryContract {
 public function __construct(private ConnectionInterface $db){}
 public function search(int $userId,array $filters=[]): array { $q=$this->db->table('crm_events')->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at'); if($from=$filters['from']??null)$q->where('starts_at','>=',$from); if($to=$filters['to']??null)$q->where('starts_at','<=',$to); return $q->orderBy('starts_at')->limit(min((int)($filters['limit']??250),500))->get()->map(fn($r)=>(array)$r)->all(); }
 public function create(int $userId,array $data): array { $id=$this->db->table('crm_events')->insertGetId(['public_id'=>(string)Str::ulid(),'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'name'=>(string)$data['name'],'status'=>$data['status']??'scheduled','starts_at'=>$data['starts_at'],'ends_at'=>$data['ends_at']??null,'all_day'=>(bool)($data['all_day']??false),'subject_type'=>$data['subject_type']??null,'subject_public_id'=>$data['subject_public_id']??null,'location'=>$data['location']??null,'description'=>$data['description']??null,'external_provider'=>$data['external_provider']??null,'external_event_id'=>$data['external_event_id']??null,'meta'=>json_encode($data['meta']??[]),'created_at'=>now(),'updated_at'=>now()]); return (array)$this->db->table('crm_events')->where('id',$id)->first(); }
}
