# Signal Events

All durable Signal events use the canonical versioned envelope and include trace/correlation/causation context where applicable.

## Signal-owned bootstrap events

| Event | Schema | Producer | Scope | Classification | Purpose |
|---|---:|---|---|---|---|
| `signal.engine.started` | 1 | Signal Engine | system | INTERNAL | Engine-start observation (`schemas/events/signal.engine.started.v1.json`) |
| `signal.security.context_rejected` | 1 | Signal Engine | system | CONFIDENTIAL | Rejected trusted-context attempt (`schemas/events/signal.security.context_rejected.v1.json`) |
| `signal.subscription.failed` | 1 | subscription dispatcher | tenant/system | CONFIDENTIAL | Subscriber delivery exhausted/failure (`schemas/events/signal.subscription.failed.v1.json`) |
| `signal.anomaly.detected` | 1 | anomaly engine | tenant/system | CONFIDENTIAL | New/reopened deterministic anomaly (`schemas/events/signal.anomaly.detected.v1.json`) |
| `signal.anomaly.acknowledged` | 1 | anomaly engine | tenant/system | CONFIDENTIAL | Immutable acknowledgement decision (`schemas/events/signal.anomaly.acknowledged.v1.json`) |
| `signal.anomaly.suppressed` | 1 | anomaly engine | tenant/system | CONFIDENTIAL | Immutable suppression decision (`schemas/events/signal.anomaly.suppressed.v1.json`) |
| `signal.anomaly.resolved` | 1 | anomaly engine | tenant/system | CONFIDENTIAL | Immutable resolution decision (`schemas/events/signal.anomaly.resolved.v1.json`) |
| `signal.anomaly.reopened` | 1 | anomaly engine | tenant/system | CONFIDENTIAL | Immutable recurrence/reopen decision (`schemas/events/signal.anomaly.reopened.v1.json`) |

Other extensions own and register their own domain event definitions. Signal validates and stores them but does not become the semantic owner.

The canonical trace fields are `trace_id`, `correlation_id`, `causation_id` and `root_causation_id`; `emitter_id` records the trusted emitting component. Payloads must contain business/operational evidence, not hidden chain-of-thought.

## Delivery recovery telemetry

`signal.subscription.redriven` is emitted after a governed redrive request is durably recorded. Its payload contains the original delivery/event/subscriber identities, the redrive generation and a SHA-256 reason hash. The authoritative redrive audit is also retained in `titan_signal_delivery_redrives`.
