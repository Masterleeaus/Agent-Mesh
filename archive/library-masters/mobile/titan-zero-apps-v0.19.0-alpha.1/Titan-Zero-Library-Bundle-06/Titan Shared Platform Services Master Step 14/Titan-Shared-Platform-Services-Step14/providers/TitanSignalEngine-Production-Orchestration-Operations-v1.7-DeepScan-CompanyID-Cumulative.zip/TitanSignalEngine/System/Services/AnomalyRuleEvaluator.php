<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Data\AnomalyFinding;
use App\Extensions\TitanSignalEngine\System\Data\AnomalyThresholds;

final class AnomalyRuleEvaluator
{
    public function __construct(private readonly AnomalyThresholds $thresholds)
    {
    }

    /** @param array<string,mixed> $metrics @return list<AnomalyFinding> */
    public function evaluate(array $metrics): array
    {
        $findings = [];

        $errors = max(0, (int) ($metrics['error_count_5m'] ?? 0));
        if ($errors >= $this->thresholds->repeatedFailureCount5m) {
            $ratio = $errors / max(1, $this->thresholds->repeatedFailureCount5m);
            $findings[] = $this->finding(
                'repeated_failures',
                $ratio >= 4 ? 'critical' : 'high',
                min(100, 55 + (int) round(($ratio - 1) * 15)),
                min(0.99, 0.70 + (($ratio - 1) * 0.08)),
                'source',
                (string) ($metrics['source'] ?? '__all__'),
                ['error_count_5m' => $errors, 'threshold' => $this->thresholds->repeatedFailureCount5m],
            );
        }

        $loopCount = max(0, (int) ($metrics['loop_event_count'] ?? 0));
        if ($loopCount >= $this->thresholds->executionLoopCount) {
            $ratio = $loopCount / max(1, $this->thresholds->executionLoopCount);
            $findings[] = $this->finding(
                'execution_loop',
                $ratio >= 3 ? 'critical' : 'high',
                min(100, 65 + (int) round(($ratio - 1) * 20)),
                min(0.99, 0.80 + (($ratio - 1) * 0.08)),
                'trace_event_type',
                (string) ($metrics['trace_id'] ?? 'unknown') . ':' . (string) ($metrics['event_type'] ?? 'unknown'),
                ['trace_id' => $metrics['trace_id'] ?? null, 'event_type' => $metrics['event_type'] ?? null, 'event_count' => $loopCount, 'threshold' => $this->thresholds->executionLoopCount],
            );
        }

        $retryWait = max(0, (int) ($metrics['retry_wait_count'] ?? 0));
        $deadLetters = max(0, (int) ($metrics['dead_letter_count'] ?? 0));
        if ($retryWait >= $this->thresholds->retryWaitCount || $deadLetters >= $this->thresholds->deadLetterCount) {
            $critical = $deadLetters >= max(3, $this->thresholds->deadLetterCount * 3) || $retryWait >= $this->thresholds->retryWaitCount * 5;
            $findings[] = $this->finding(
                'queue_retry_spike',
                $critical ? 'critical' : 'high',
                min(100, 60 + min(30, $retryWait) + min(20, $deadLetters * 5)),
                min(0.99, 0.78 + min(0.20, ($retryWait / max(1, $this->thresholds->retryWaitCount)) * 0.08 + $deadLetters * 0.02)),
                'delivery_queue',
                (string) ($metrics['queue'] ?? 'titan-signal-engine'),
                ['retry_wait_count' => $retryWait, 'dead_letter_count' => $deadLetters, 'retry_threshold' => $this->thresholds->retryWaitCount],
            );
        }

        $stalled = max(0, (int) ($metrics['stalled_trace_count'] ?? 0));
        if ($stalled >= $this->thresholds->stalledTraceCount) {
            $findings[] = $this->finding(
                'stalled_workflow',
                $stalled >= 10 ? 'critical' : 'high',
                min(100, 55 + $stalled * 5),
                min(0.98, 0.76 + min(0.20, $stalled * 0.02)),
                'scope',
                (string) ($metrics['scope_subject'] ?? '__scope__'),
                ['stalled_trace_count' => $stalled, 'threshold' => $this->thresholds->stalledTraceCount],
            );
        }

        $missingReceipts = max(0, (int) ($metrics['missing_receipt_count'] ?? 0));
        if ($missingReceipts >= $this->thresholds->missingReceiptCount) {
            $findings[] = $this->finding(
                'missing_receipt',
                $missingReceipts >= 5 ? 'critical' : 'high',
                min(100, 65 + $missingReceipts * 6),
                min(0.99, 0.86 + min(0.12, $missingReceipts * 0.02)),
                'scope',
                (string) ($metrics['scope_subject'] ?? '__scope__'),
                ['missing_receipt_count' => $missingReceipts, 'threshold' => $this->thresholds->missingReceiptCount],
            );
        }

        $overrides = max(0, (int) ($metrics['override_count_1h'] ?? 0));
        if ($overrides >= $this->thresholds->overrideCount1h) {
            $findings[] = $this->finding(
                'override_spike',
                $overrides >= $this->thresholds->overrideCount1h * 4 ? 'critical' : 'high',
                min(100, 50 + $overrides * 5),
                min(0.97, 0.72 + min(0.22, $overrides * 0.015)),
                'scope',
                (string) ($metrics['scope_subject'] ?? '__scope__'),
                ['override_count_1h' => $overrides, 'threshold' => $this->thresholds->overrideCount1h],
            );
        }

        $baselineReady = (bool) ($metrics['baseline_ready'] ?? false);
        $baseline = max(0.0, (float) ($metrics['baseline_events_per_5m'] ?? 0.0));
        $current = max(0, (int) ($metrics['events_last_5m'] ?? 0));
        if ($baselineReady && $baseline >= $this->thresholds->minimumBaselineEventsPer5m) {
            $ratio = $baseline > 0.0 ? $current / $baseline : 1.0;
            if ($ratio <= $this->thresholds->volumeCollapseRatio) {
                $drop = max(0.0, 1.0 - $ratio);
                $findings[] = $this->finding(
                    'event_volume_collapse',
                    $ratio <= 0.05 ? 'critical' : 'high',
                    min(100, 55 + (int) round($drop * 45)),
                    min(0.98, 0.75 + $drop * 0.20),
                    'scope',
                    (string) ($metrics['scope_subject'] ?? '__scope__'),
                    ['events_last_5m' => $current, 'baseline_events_per_5m' => round($baseline, 3), 'ratio' => round($ratio, 4), 'threshold_ratio' => $this->thresholds->volumeCollapseRatio],
                );
            }
        }

        $sequenceViolations = max(0, (int) ($metrics['sequence_violation_count'] ?? 0));
        if ($sequenceViolations >= $this->thresholds->sequenceViolationCount) {
            $findings[] = $this->finding(
                'sequence_violation',
                $sequenceViolations >= 3 ? 'critical' : 'high',
                min(100, 70 + $sequenceViolations * 8),
                min(0.99, 0.90 + min(0.08, $sequenceViolations * 0.02)),
                'trace',
                (string) ($metrics['trace_id'] ?? 'unknown'),
                ['trace_id' => $metrics['trace_id'] ?? null, 'sequence_violation_count' => $sequenceViolations],
            );
        }

        $missingRequired = max(0, (int) ($metrics['missing_required_event_count'] ?? 0));
        if ($missingRequired > 0) {
            $findings[] = $this->finding(
                'required_event_missing',
                $missingRequired >= 3 ? 'critical' : 'high',
                min(100, 68 + $missingRequired * 8),
                min(0.99, 0.88 + min(0.09, $missingRequired * 0.025)),
                'trace',
                (string) ($metrics['trace_id'] ?? 'unknown'),
                ['trace_id' => $metrics['trace_id'] ?? null, 'missing_required_event_count' => $missingRequired],
            );
        }

        $unresolved = max(0, (int) ($metrics['unresolved_causation_count'] ?? 0));
        if ($unresolved >= $this->thresholds->unresolvedCausationCount) {
            $findings[] = $this->finding(
                'trace_integrity',
                $unresolved >= 3 ? 'critical' : 'high',
                min(100, 75 + $unresolved * 7),
                min(0.99, 0.92 + min(0.06, $unresolved * 0.02)),
                'trace',
                (string) ($metrics['trace_id'] ?? 'unknown'),
                ['trace_id' => $metrics['trace_id'] ?? null, 'unresolved_causation_count' => $unresolved],
            );
        }

        return $findings;
    }

    /** @param array<string,mixed> $evidence */
    private function finding(string $type, string $severity, int $score, float $confidence, string $subjectType, string $subjectId, array $evidence): AnomalyFinding
    {
        return new AnomalyFinding($type, $severity, max(0, min(100, $score)), max(0.0, min(1.0, $confidence)), $subjectType, $subjectId, $evidence);
    }
}
