<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Services;

use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterRegistryContract;

final class CommandAdapterRegistry implements CommandAdapterRegistryContract
{
    /** @var array<string,CommandAdapterContract> */
    private array $adapters = [];

    public function register(CommandAdapterContract $adapter): void
    {
        $key = $adapter->capability();
        if ($key === '') {
            throw new \InvalidArgumentException('Command adapter capability cannot be empty.');
        }
        if (isset($this->adapters[$key])) {
            throw new \LogicException('Command adapter already registered: ' . $key);
        }
        $this->adapters[$key] = $adapter;
    }

    public function has(string $capability): bool
    {
        return isset($this->adapters[$capability]);
    }

    public function forCapability(string $capability): ?CommandAdapterContract
    {
        return $this->adapters[$capability] ?? null;
    }

    public function count(): int
    {
        return count($this->adapters);
    }
}
