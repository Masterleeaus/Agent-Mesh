# Blueprint v4 Deep-Scan Findings

Baseline compared: Titan Signal Engine v0.9.0 Hardening Pass 1.
Blueprint: Titan Extension Blueprint v4.0 Step03 AI Workforce Contract Baseline.

## Validator result after alignment

- Production manifest validation: PASS (`schema_version=2.0`, `runtime_profile=titan-governed-engine`).
- Package secret/filesystem scan: PASS.
- Architecture scan: 0 critical, 70 warnings.
  - 42 `raw_db` review warnings.
  - 28 `unbounded_get` performance warnings.
  - 11 warnings are test code.
  - 12 warnings are historical migrations.
  - 47 warnings are runtime code.

## Runtime warning disposition

### Unbounded query warnings (28)

These are not treated as harmless. They are retained as explicit production-hardening work. Concentrated files:

- `SignalEventStore.php` — graph/event materialization.
- `SignalSubscriptionRegistry.php` — registry cache/read.
- `SignalDeliveryScheduler.php` — delivery recovery.
- `PulseQueryService.php`, `PulseProjector.php` — rollup/metric reads.
- `CausalEdgeProjector.php` — late-parent repair.
- `SignalManager.php`, `SignalBackpressureMonitor.php` — global health/count paths.
- `SignalLifecycleService.php` — lifecycle candidate/materialization paths.
- `SignalConsoleService.php` — archive/audit/subscriber console lists.
- `AnomalyDetectionService.php` — fleet/subject reads.

They map to the existing Production Hardening plan (registry, delivery concurrency/backpressure, lifecycle/archive, Pulse/health, console/performance and final host-scale validation).

### Raw DB warnings (19 runtime)

Raw access is expected only for Signal-owned infrastructure tables, projection upserts, housekeeping and the tightly isolated physical prune path. It must not become a bypass around tenant authorization or domain ownership.

The governed lifecycle service remains the only allowed physical delete path for `titan_signal_events`. Pulse/anomaly/housekeeping raw access is projection infrastructure and remains subject to the later tenancy/performance review.

## Blueprint gaps closed in v0.9.1

- Manifest schema 2.0.
- `titan-governed-engine` runtime profile.
- Blueprint schedule declaration shape.
- One-server/non-overlapping schedule runtime behavior.
- Capability contracts + input/output schemas.
- Canonical Signal envelope schema and Signal-owned event schemas.
- Liveness/readiness contract and implementation.
- Trace/log context adapter.
- SLO, resilience, rollout, DR, supply-chain and governance declarations.
- Required operations/security/data/governance documentation.
- Localization resources and provider registration.
- SBOM/provenance generation.

## Deliberately not claimed complete

- Detached production package signature: required by manifest, but no release private key was supplied.
- Exact-host PHPUnit/Laravel integration execution.
- Larastan level 8 run against the exact host/dependencies.
- Resolution of the 47 runtime architecture warnings.
- Production load/chaos/concurrency testing.

Those remain release gates rather than documentation claims.
