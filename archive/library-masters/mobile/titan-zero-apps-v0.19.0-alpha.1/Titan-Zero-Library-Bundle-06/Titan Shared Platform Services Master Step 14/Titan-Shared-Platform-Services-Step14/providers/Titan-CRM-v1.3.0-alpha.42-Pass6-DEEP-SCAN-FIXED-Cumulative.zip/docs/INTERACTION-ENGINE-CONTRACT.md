# Interaction Engine Contract

## Status
**IMPLEMENTED at source integration level.** `CrmInteractionIntegrationRegistrar` registers CRM's explicit capability names with the Interaction Engine `CapabilityRegistry` when that runtime is installed. `CrmInteractionCapabilityHandler` strips caller tenant identifiers and invokes the CRM capability executor under already trusted CRM company context.

The Interaction Engine owns intent, workflow, authority/approval orchestration and cognitive events. CRM owns business validation, authoritative state, transactions and persistence. This is not a renamed unlimited WorkCore adapter: only registered CRM capabilities can execute.
