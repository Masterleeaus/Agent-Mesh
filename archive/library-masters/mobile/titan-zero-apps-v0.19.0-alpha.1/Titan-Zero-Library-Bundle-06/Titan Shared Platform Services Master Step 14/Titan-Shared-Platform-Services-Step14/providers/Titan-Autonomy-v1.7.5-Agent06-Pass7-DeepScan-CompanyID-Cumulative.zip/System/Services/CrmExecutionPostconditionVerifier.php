<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\ExecutionPostconditionVerifierContract;
use App\Extensions\TitanAutonomy\System\Contracts\TenantRecordLookupContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\GovernedCapabilityCommand;

final class CrmExecutionPostconditionVerifier implements ExecutionPostconditionVerifierContract
{
    /** @var array<string,list<string>> */
    private const MATERIAL_FIELDS = [
        'crm.customer.create' => ['company_public_id','first_name','last_name','email','phone'],
        'crm.work_order.create' => ['company_public_id','contact_public_id','location_public_id','service_public_id','title','status','priority','assigned_user_id','scheduled_start','scheduled_end'],
        'crm.work_order.assign' => ['work_order_public_id','worker_user_id','scheduled_start','scheduled_end'],
        'crm.work_order.reschedule' => ['work_order_public_id','assigned_user_id','scheduled_start','scheduled_end','timezone'],
        'crm.work_order.cancel' => ['status'],
        'crm.appointment.create' => ['work_order_public_id','service_request_public_id','location_public_id','assigned_user_id','scheduled_start','scheduled_end','timezone','status'],
        'crm.quote.create' => ['company_public_id','contact_public_id','status','currency','total_minor','due_at'],
        'crm.quote.approve' => ['status'],
        'crm.quote.transition' => ['status'],
        'crm.invoice.create' => ['company_public_id','contact_public_id','status','currency','total_minor','due_at'],
        'crm.invoice.issue' => ['company_public_id','contact_public_id','status','currency','total_minor','due_at'],
        'crm.invoice.transition' => ['status'],
    ];

    public function __construct(private readonly TenantRecordLookupContract $records) {}

    public function verify(CapabilityState $state, GovernedCapabilityCommand $command, array $commandResult, array $context = []): array
    {
        $profile = $this->recordProfile($command);
        if ($profile === null) return $this->result('unavailable', ['POSTCONDITION_VERIFIER_NOT_AVAILABLE']);

        $businessResult = $this->businessResult($commandResult);
        $publicId = trim((string) ($businessResult['public_id'] ?? $businessResult['id'] ?? $profile['public_id'] ?? ''));
        if ($publicId === '') return $this->result('failed', ['EXECUTED_RESOURCE_ID_MISSING']);

        $row = $this->records->find($profile['table'], $state->tenantCompanyId, $publicId);
        if ($row === null) return $this->result('failed', ['PERSISTED_RESOURCE_NOT_FOUND']);
        if (isset($row['tenant_company_id']) && (int) $row['tenant_company_id'] !== $state->tenantCompanyId) {
            return $this->result('failed', ['PERSISTED_RESOURCE_TENANT_MISMATCH']);
        }

        $expected = $this->expectedFields($command, $businessResult, $profile);
        $reasons = [];
        foreach ((self::MATERIAL_FIELDS[$command->capability] ?? []) as $field) {
            if (!array_key_exists($field, $expected)) continue;
            if (!$this->equivalent($expected[$field], $row[$field] ?? null)) $reasons[] = 'MATERIAL_FIELD_MISMATCH:' . $field;
        }
        if ($reasons !== []) return $this->result('failed', $reasons, ['table'=>$profile['table'],'public_id'=>$publicId]);

        return $this->result('verified', [], [
            'table' => $profile['table'],
            'public_id' => $publicId,
            'material_fields_checked' => array_values(array_intersect(array_keys($expected), self::MATERIAL_FIELDS[$command->capability] ?? [])),
        ], 0.99);
    }

    private function recordProfile(GovernedCapabilityCommand $command): ?array
    {
        $p = $command->payload;
        return match ($command->capability) {
            'crm.customer.create' => ['table' => (($p['customer_type'] ?? '') === 'business' ? 'crm_companies' : 'crm_contacts')],
            'crm.work_order.create', 'crm.work_order.cancel' => ['table' => 'crm_work_orders'],
            'crm.work_order.assign' => ['table' => 'crm_dispatch_assignments'],
            'crm.work_order.reschedule', 'crm.appointment.create' => ['table' => 'crm_appointments'],
            'crm.quote.create', 'crm.quote.approve', 'crm.quote.transition' => ['table' => 'crm_' . $this->quoteType($p)],
            'crm.invoice.create', 'crm.invoice.issue', 'crm.invoice.transition' => ['table' => 'crm_invoices'],
            default => null,
        };
    }

    private function quoteType(array $payload): string
    {
        $type = (string) ($payload['type'] ?? 'proposals');
        return in_array($type, ['proposals','estimates'], true) ? $type : 'proposals';
    }

    private function businessResult(array $result): array
    {
        $cursor = $result;
        for ($i = 0; $i < 4; $i++) {
            if (isset($cursor['result']) && is_array($cursor['result'])) { $cursor = $cursor['result']; continue; }
            if (isset($cursor['data']) && is_array($cursor['data'])) { $cursor = $cursor['data']; continue; }
            break;
        }
        return $cursor;
    }

    private function expectedFields(GovernedCapabilityCommand $command, array $businessResult, array $profile): array
    {
        $p = $command->payload;
        $expected = [];
        foreach (self::MATERIAL_FIELDS[$command->capability] ?? [] as $field) {
            if (array_key_exists($field, $p)) $expected[$field] = $p[$field];
            elseif (array_key_exists($field, $businessResult)) $expected[$field] = $businessResult[$field];
        }
        $expected['status'] = match ($command->capability) {
            'crm.work_order.cancel' => 'cancelled',
            'crm.quote.approve' => 'accepted',
            'crm.quote.transition', 'crm.invoice.transition' => $p['status'] ?? ($expected['status'] ?? null),
            'crm.invoice.issue' => 'issued',
            'crm.invoice.create' => (($p['issue_now'] ?? $p['send_to_customer'] ?? false) ? 'issued' : ($p['status'] ?? 'draft')),
            'crm.quote.create' => $p['status'] ?? 'draft',
            'crm.appointment.create', 'crm.work_order.reschedule' => $p['status'] ?? 'scheduled',
            default => $expected['status'] ?? null,
        };
        if ($expected['status'] === null) unset($expected['status']);
        return $expected;
    }

    private function equivalent(mixed $expected, mixed $actual): bool
    {
        if ($expected === null && $actual === null) return true;
        if (is_bool($expected)) return (bool) $actual === $expected;
        if (is_numeric($expected) && is_numeric($actual)) return (string) (0 + $expected) === (string) (0 + $actual);
        return trim((string) $expected) === trim((string) $actual);
    }

    private function result(string $status, array $reasons = [], array $facts = [], float $confidence = 0.0): array
    {
        return ['status'=>$status,'confidence'=>$confidence,'reason_codes'=>array_values(array_unique($reasons)),'facts'=>$facts];
    }
}
