<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Contracts\CustomFieldRepositoryContract; use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway; use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class CustomFieldController extends Controller {
 public function __construct(private CustomFieldRepositoryContract $fields,private CrmHumanMutationGateway $mutations){}
 public function index(Request $r){return response()->json(['data'=>$this->fields->definitions((int)$r->user()->id,$r->only(['subject_type']))]);}
 public function store(Request $r){$d=$r->validate(['subject_type'=>'required|string|max:60','name'=>'required|string|max:120','key'=>'nullable|string|max:120','field_type'=>'nullable|in:text,number,date,boolean,select,multiselect,json','is_required'=>'nullable|boolean','sort_order'=>'nullable|integer','options'=>'nullable|array']);return response()->json($this->mutations->execute($r,'crm.custom_field.create',$d),201);}
 public function setValue(Request $r,string $field){$d=$r->validate(['subject_type'=>'required|string|max:60','subject_public_id'=>'required|string|size:26','value'=>'nullable']);return response()->json($this->mutations->execute($r,'crm.custom_field.value.set',$d+['field_public_id'=>$field]));}
}
