<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\DecisionIntelligence;

use App\Extensions\TitanGovernance\System\Contracts\GovernanceDecisionEvidenceSourceContract;
use InvalidArgumentException;

final class GovernanceDecisionEvidenceRegistry
{
    /** @var array<string,GovernanceDecisionEvidenceSourceContract> */
    private array $sources = [];

    public function register(GovernanceDecisionEvidenceSourceContract $source): void
    {
        $key=trim($source->key());
        if($key==='') throw new InvalidArgumentException('Governance decision evidence source key cannot be empty.');
        if(isset($this->sources[$key])) throw new InvalidArgumentException("Governance decision evidence source [{$key}] is already registered.");
        $this->sources[$key]=$source;
    }

    public function get(string $key): ?GovernanceDecisionEvidenceSourceContract { return $this->sources[$key]??null; }
    /** @return array<string,GovernanceDecisionEvidenceSourceContract> */
    public function all(): array { return $this->sources; }
}
