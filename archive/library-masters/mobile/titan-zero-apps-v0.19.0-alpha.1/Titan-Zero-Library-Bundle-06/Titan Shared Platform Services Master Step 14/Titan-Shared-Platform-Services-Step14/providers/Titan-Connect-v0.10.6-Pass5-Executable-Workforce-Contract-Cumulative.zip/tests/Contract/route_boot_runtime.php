<?php

declare(strict_types=1);

namespace TitanConnectRouteBootTest {
    final class Registrar
    {
        public function middleware(mixed $middleware): self { return $this; }
        public function prefix(string $prefix): self { return $this; }
        public function as(string $name): self { return $this; }
        public function name(string $name): self { return $this; }
        public function group(callable $callback): self { $callback(); return $this; }
    }
}

namespace Illuminate\Support\Facades {
    use TitanConnectRouteBootTest\Registrar;

    final class Route
    {
        public static function middleware(mixed $middleware): Registrar { return new Registrar(); }
        public static function get(string $uri, mixed $action): Registrar { return new Registrar(); }
        public static function post(string $uri, mixed $action): Registrar { return new Registrar(); }
        public static function patch(string $uri, mixed $action): Registrar { return new Registrar(); }
        public static function put(string $uri, mixed $action): Registrar { return new Registrar(); }
        public static function delete(string $uri, mixed $action): Registrar { return new Registrar(); }
    }
}

namespace {
    $root = dirname(__DIR__, 2);
    require $root.'/routes/api.php';
    echo "OK Titan Connect API route boot runtime passed.\n";
}
