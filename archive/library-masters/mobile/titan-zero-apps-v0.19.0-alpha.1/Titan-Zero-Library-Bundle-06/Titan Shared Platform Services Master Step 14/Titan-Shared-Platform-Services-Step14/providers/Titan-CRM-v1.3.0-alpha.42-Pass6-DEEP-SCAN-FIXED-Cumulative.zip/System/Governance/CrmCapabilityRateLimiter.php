<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

/** Durable per-tenant/source/actor/capability limiter for AI-originated writes. */
final class CrmCapabilityRateLimiter
{
    public function __construct(private readonly ConnectionInterface $db,private readonly CrmCompanyScope $scope) {}

    public function assertAllowed(string $source,string $capability,?int $actorUserId): void
    {
        $sources=(array)config('crm.governance.rate_limits.sources',['ai','chatbot','automation']);
        if(!in_array($source,$sources,true))return;
        if(!$this->db->getSchemaBuilder()->hasTable('crm_capability_rate_limits'))return;

        $limit=$this->limitFor($capability);
        if($limit<1)return;
        $now=now();$window=$now->copy()->startOfMinute();
        $actorKey=$actorUserId&&$actorUserId>0?'user:'.$actorUserId:'source:'.$source;
        $tenant=$this->scope->current()->companyId;
        $bucketKey=hash('sha256',$tenant.'|'.$actorKey.'|'.$source.'|'.$capability.'|'.$window->format('YmdHi'));
        $row=[
            'public_id'=>(string)Str::ulid(),'company_id'=>$tenant,'bucket_key'=>$bucketKey,'actor_key'=>$actorKey,
            'source'=>$source,'capability'=>$capability,'window_started_at'=>$window,'hit_count'=>0,
            'expires_at'=>$window->copy()->addMinutes(2),'created_at'=>$now,'updated_at'=>$now,
        ];
        $this->db->table('crm_capability_rate_limits')->insertOrIgnore($row);
        $this->db->table('crm_capability_rate_limits')->where('company_id',$tenant)->where('bucket_key',$bucketKey)->increment('hit_count',1,['updated_at'=>$now]);
        $hits=(int)$this->db->table('crm_capability_rate_limits')->where('company_id',$tenant)->where('bucket_key',$bucketKey)->value('hit_count');
        if($hits>$limit){
            $retry_after_seconds=max(1,60-(int)$now->format('s'));
            throw new CrmRateLimitException($retry_after_seconds);
        }
    }

    private function limitFor(string $capability): int
    {
        $cfg=(array)config('crm.governance.rate_limits',[]);
        if(str_contains($capability,'payment')||str_contains($capability,'refund'))return (int)($cfg['financial_per_minute']??10);
        if(str_contains($capability,'send')||str_contains($capability,'notification'))return (int)($cfg['communication_per_minute']??20);
        if(str_ends_with($capability,'.create'))return (int)($cfg['create_per_minute']??30);
        return (int)($cfg['default_per_minute']??60);
    }
}
