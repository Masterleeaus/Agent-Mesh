<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Services;

use App\Extensions\TitanPrime\System\Domain\ValueObjects\TraceContext;
use App\Extensions\TitanPrime\System\Gateways\Contracts\EngineBridgeContract;
use App\Extensions\TitanPrime\System\Gateways\Contracts\EngineGatewayContract;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineAvailability;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayRequest;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;
use Throwable;

abstract class AbstractEngineGateway implements EngineGatewayContract
{
    public function __construct(protected readonly EngineBridgeContract $bridge) {}

    final public function availability(): EngineAvailability
    {
        try {
            $availability = $this->bridge->availability($this->engine());
            if ($availability->engine !== $this->engine()) {
                return new EngineAvailability($this->engine(), false, 'bridge_contract_mismatch');
            }
            return $availability;
        } catch (Throwable) {
            return new EngineAvailability($this->engine(), false, 'bridge_availability_failed');
        }
    }

    /** @param array<string,mixed> $payload */
    final protected function dispatch(TraceContext $trace, string $capability, array $payload, string $operationId): EngineGatewayResult
    {
        $request = new EngineGatewayRequest(
            engine: $this->engine(),
            capability: $capability,
            operationId: $operationId,
            trace: $trace,
            payload: $payload,
        );

        try {
            $result = $this->bridge->dispatch($request);
        } catch (Throwable $throwable) {
            return EngineGatewayResult::failed(
                $request,
                ['engine_bridge_exception'],
                ['exception_class' => $throwable::class],
            );
        }

        if ($result->engine !== $request->engine || $result->capability !== $request->capability || $result->operationId !== $request->operationId) {
            return EngineGatewayResult::failed($request, ['bridge_contract_mismatch']);
        }

        return $result;
    }
}
