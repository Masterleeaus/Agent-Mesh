<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\DecisionIntelligence;

final class GovernanceDeltaViewer
{
    /** @var array<string,true> */
    private array $ignored;

    public function __construct(private readonly int $maxDepth=6,private readonly int $maxFields=250,private readonly int $maxStringLength=1024,array $ignoredFields=['observed_at','captured_at','generated_at','refreshed_at'])
    {
        $this->ignored=array_fill_keys($ignoredFields,true);
    }

    /** @return array<string,mixed> */
    public function compare(array $left,array $right):array
    {
        [$a,$truncatedA]=$this->flatten($left);[$b,$truncatedB]=$this->flatten($right);
        $paths=array_values(array_unique(array_merge(array_keys($a),array_keys($b))));sort($paths,SORT_STRING);
        $added=[];$removed=[];$changed=[];$unchanged=0;
        foreach($paths as $path){
            $hasA=array_key_exists($path,$a);$hasB=array_key_exists($path,$b);
            if(!$hasA){$added[]=$path;continue;} if(!$hasB){$removed[]=$path;continue;}
            if($a[$path]!==$b[$path]){
                $record=['path'=>$path,'old'=>$this->bounded($a[$path]),'new'=>$this->bounded($b[$path])];
                if(is_string($a[$path]) && strlen($a[$path])>$this->maxStringLength){$record['old_hash']=hash('sha256',$a[$path]);$record['values_truncated']=true;}
                if(is_string($b[$path]) && strlen($b[$path])>$this->maxStringLength){$record['new_hash']=hash('sha256',$b[$path]);$record['values_truncated']=true;}
                $changed[]=$record;
            }else{$unchanged++;}
        }
        return ['schema_version'=>'1.0','added_paths'=>$added,'removed_paths'=>$removed,'changed'=>$changed,'unchanged_count'=>$unchanged,'truncated'=>$truncatedA||$truncatedB];
    }

    /** @return array{0:array<string,mixed>,1:bool} */
    private function flatten(array $input):array
    {
        $out=[];$truncated=false;$count=0;
        $walk=function(array $value,string $prefix,int $depth) use (&$walk,&$out,&$truncated,&$count):void{
            if($depth>$this->maxDepth){$truncated=true;return;}
            foreach($value as $key=>$item){
                if($count >= $this->maxFields){$truncated=true;return;}
                $segment=(string)$key;
                if(isset($this->ignored[$segment])) continue;
                $path=$prefix===''?$segment:$prefix.'.'.$segment;
                if(is_array($item)){
                    if($item===[]){$out[$path]=[];$count++;continue;}
                    $walk($item,$path,$depth+1);continue;
                }
                $out[$path]=$item;$count++;
            }
        };
        $walk($input,'',0);ksort($out,SORT_STRING);return [$out,$truncated];
    }

    private function bounded(mixed $value):mixed
    {
        if(is_string($value)) return substr($value,0,$this->maxStringLength);
        if(is_int($value)||is_float($value)||is_bool($value)||$value===null) return $value;
        return (string)$value;
    }
}
