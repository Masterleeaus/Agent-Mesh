<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Navigation;

final class SignalAdminNavigation
{
    /** @return list<array<string,mixed>> */
    public function items(): array
    {
        $parent = [
            'parent_key' => null,
            'key' => 'titan_signal_engine_admin',
            'route' => 'dashboard.admin.titan.signal.engine.index',
            'route_slug' => null,
            'label' => 'Signal Engine',
            'icon' => 'tabler-heart-rate-monitor',
            'svg' => null,
            'order' => 995,
            'priority' => 995,
            'is_active' => true,
            'params' => [],
            'type' => 'item',
            'badge' => null,
            'extension' => '1',
            'active_condition' => ['dashboard.admin.titan.signal.engine.*'],
            'show_condition' => true,
            'is_admin' => true,
            'data-name' => 'titan_signal_engine_admin',
            'read_only' => false,
        ];

        $children = [
            ['overview', 'Overview', 'dashboard.admin.titan.signal.engine.overview', 'tabler-layout-dashboard'],
            ['pulse_health', 'Pulse and Health', 'dashboard.admin.titan.signal.engine.pulse-health', 'tabler-activity-heartbeat'],
            ['events_traces', 'Events and Traces', 'dashboard.admin.titan.signal.engine.events-traces', 'tabler-route'],
            ['anomalies', 'Anomalies', 'dashboard.admin.titan.signal.engine.anomalies', 'tabler-alert-triangle'],
            ['deliveries_dlq', 'Deliveries and DLQ', 'dashboard.admin.titan.signal.engine.deliveries-dlq', 'tabler-package-export'],
            ['lifecycle_archives', 'Lifecycle and Archives', 'dashboard.admin.titan.signal.engine.lifecycle-archives', 'tabler-archive'],
            ['registries', 'Registries', 'dashboard.admin.titan.signal.engine.registries', 'tabler-list-details'],
            ['diagnostics', 'Diagnostics', 'dashboard.admin.titan.signal.engine.diagnostics', 'tabler-stethoscope'],
        ];

        $items = [$parent];
        foreach ($children as $index => [$suffix, $label, $route, $icon]) {
            $items[] = [
                'parent_key' => 'titan_signal_engine_admin',
                'key' => 'titan_signal_engine_' . $suffix,
                'route' => $route,
                'route_slug' => null,
                'label' => $label,
                'icon' => $icon,
                'svg' => null,
                'order' => 996 + $index,
                'priority' => 996 + $index,
                'is_active' => true,
                'params' => [],
                'type' => 'item',
                'badge' => null,
                'extension' => '1',
                'active_condition' => [$route],
                'show_condition' => true,
                'is_admin' => true,
                'data-name' => 'titan_signal_engine_' . $suffix,
                'read_only' => false,
            ];
        }

        return $items;
    }

    /** @return list<array<string,mixed>> */
    public function __invoke(): array
    {
        return $this->items();
    }
}
