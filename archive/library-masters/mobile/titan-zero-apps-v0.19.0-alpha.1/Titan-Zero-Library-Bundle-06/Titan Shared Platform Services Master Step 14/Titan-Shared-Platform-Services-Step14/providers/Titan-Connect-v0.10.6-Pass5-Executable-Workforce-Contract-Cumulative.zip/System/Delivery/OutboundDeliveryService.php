<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Delivery;

use App\Extensions\TitanConnect\System\Attachments\OutboundAttachmentResolver;
use App\Extensions\TitanConnect\System\Contracts\CredentialVault;
use App\Extensions\TitanConnect\System\DTO\NormalizedDeliveryReceipt;
use App\Extensions\TitanConnect\System\Events\ExternalMessageStatusChanged;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ExternalMessage;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use App\Extensions\TitanConnect\System\Models\OutboundDelivery;
use App\Extensions\TitanConnect\System\Providers\ProviderRegistry;
use App\Extensions\TitanConnect\System\Security\SensitivePayloadGuard;
use App\Extensions\TitanConnect\System\Services\MessagingAuditService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

final class OutboundDeliveryService
{
    private const ALLOWED_STATUSES = ['queued', 'sending', 'sent', 'delivered', 'read', 'failed', 'cancelled'];

    public function __construct(
        private readonly ProviderRegistry $providers,
        private readonly CredentialVault $vault,
        private readonly MessagingAuditService $audit,
        private readonly OutboundAttachmentResolver $attachments,
        private readonly SensitivePayloadGuard $sensitive,
        private readonly int $maxAttempts = 5,
    ) {
    }

    public function send(
        int $companyId,
        int $actorId,
        ChannelConnection $connection,
        ExternalThread $thread,
        string $recipient,
        string $body,
        string $idempotencyKey,
        array $metadata = [],
    ): OutboundDelivery {
        $this->assertScope($companyId, $connection, $thread);
        $this->sensitive->assertSafe($metadata, 'metadata');
        $idempotencyKey = trim($idempotencyKey);
        if ($idempotencyKey === '') {
            throw new RuntimeException('Outbound idempotency key is required.');
        }

        $existing = OutboundDelivery::query()->where('company_id', $companyId)->where('idempotency_key', $idempotencyKey)->first();
        if ($existing) {
            return $existing;
        }

        $delivery = DB::transaction(function () use ($companyId, $actorId, $connection, $thread, $recipient, $body, $idempotencyKey, $metadata): OutboundDelivery {
            $correlationId = (string) Str::uuid();
            $message = ExternalMessage::query()->create([
                'uuid' => (string) Str::uuid(),
                'company_id' => $companyId,
                'external_thread_id' => $thread->id,
                'provider' => $connection->provider,
                'direction' => 'outbound',
                'sender_ref' => $connection->external_account_id,
                'recipient_ref' => $recipient,
                'body' => trim($body),
                'message_type' => $this->messageType($metadata),
                'status' => 'queued',
                'correlation_id' => $correlationId,
                'metadata' => $metadata + ['actor_id' => $actorId],
            ]);

            return OutboundDelivery::query()->create([
                'uuid' => (string) Str::uuid(),
                'company_id' => $companyId,
                'external_message_id' => $message->id,
                'channel_connection_id' => $connection->id,
                'provider' => $connection->provider,
                'idempotency_key' => $idempotencyKey,
                'correlation_id' => $correlationId,
                'status' => 'queued',
                'attempt_count' => 0,
            ]);
        });

        $this->audit->record($companyId, $actorId, 'external-message.queued', 'delivery', $delivery->uuid, (string) $delivery->correlation_id, [
            'provider' => $connection->provider,
            'thread_uuid' => $thread->uuid,
        ]);

        return $this->attempt($delivery);
    }

    public function retry(OutboundDelivery $delivery): OutboundDelivery
    {
        if ($delivery->status === 'cancelled' || in_array($delivery->status, ['sent', 'delivered', 'read'], true)) {
            return $delivery;
        }
        if ((int) $delivery->attempt_count >= $this->maxAttempts) {
            return $this->transition($delivery, 'failed', ['last_error' => 'Maximum delivery attempts reached.', 'next_attempt_at' => null]);
        }

        $delaySeconds = min(900, 2 ** max(0, (int) $delivery->attempt_count) * 5);
        $delivery->forceFill(['status' => 'queued', 'next_attempt_at' => now()->addSeconds($delaySeconds)])->save();
        return $delivery->fresh();
    }

    public function attempt(OutboundDelivery $delivery, bool $ignoreSchedule = false): OutboundDelivery
    {
        [$delivery, $claimed, $previousStatus] = $this->claimForAttempt($delivery, $ignoreSchedule);
        if ($previousStatus !== null && $previousStatus !== (string) $delivery->status) {
            $this->announceTransition($delivery, $previousStatus);
        }
        if (! $claimed) {
            return $delivery;
        }

        $connection = $delivery->connection;
        $message = $delivery->message;
        if ((int) $connection->company_id !== (int) $delivery->company_id || (int) $message->company_id !== (int) $delivery->company_id) {
            throw new RuntimeException('Outbound delivery company scope is invalid.');
        }

        try {
            $provider = $this->providers->get((string) $delivery->provider);
            if (! $provider->supportsOutbound()) {
                throw new RuntimeException("Provider {$delivery->provider} does not support outbound messaging.");
            }
            $credentials = $this->vault->credentials((int) $delivery->company_id, $connection);
            $providerMetadata = $this->attachments->resolveForProvider((int) $delivery->company_id, $message, $message->metadata ?? []);
            $result = $provider->send([
                'company_id' => (int) $delivery->company_id,
                'connection_uuid' => (string) $connection->uuid,
                'thread_uuid' => (string) $message->thread->uuid,
                'to' => $message->recipient_ref,
                'from' => $connection->external_account_id,
                'body' => $message->body,
                'message_type' => $message->message_type,
                'correlation_id' => $delivery->correlation_id,
                'idempotency_key' => $delivery->idempotency_key,
                'metadata' => $providerMetadata,
            ], $credentials);

            $status = $this->normalizeProviderSendStatus($result->status);
            if ($status === 'failed') {
                throw new RuntimeException('Provider reported outbound delivery failure.');
            }
            $delivery = $this->transition($delivery, $status, [
                'provider_message_id' => $result->providerMessageId,
                'provider_response' => $this->redactResponse($result->response),
                'next_attempt_at' => null,
                'sent_at' => in_array($status, ['sent', 'delivered', 'read'], true) ? now() : null,
                'delivered_at' => in_array($status, ['delivered', 'read'], true) ? now() : null,
                'read_at' => $status === 'read' ? now() : null,
            ]);
            $message->forceFill(['provider_message_id' => $result->providerMessageId, 'status' => $status])->save();
            $connection->forceFill(['last_outbound_at' => now()])->save();
            return $delivery;
        } catch (\Throwable $e) {
            $attemptCount = (int) $delivery->attempt_count;
            $next = $attemptCount < $this->maxAttempts ? now()->addSeconds(min(900, (2 ** max(0, $attemptCount - 1)) * 5)) : null;
            $delivery = $this->transition($delivery, 'failed', [
                'last_error' => mb_substr($e->getMessage(), 0, 4000),
                'next_attempt_at' => $next,
            ]);
            $message->forceFill(['status' => 'failed'])->save();
            return $delivery;
        }
    }

    /** @return array{0:OutboundDelivery,1:bool,2:?string} */
    private function claimForAttempt(OutboundDelivery $delivery, bool $ignoreSchedule): array
    {
        return DB::transaction(function () use ($delivery, $ignoreSchedule): array {
            $locked = OutboundDelivery::query()
                ->where('company_id', (int) $delivery->company_id)
                ->whereKey($delivery->getKey())
                ->lockForUpdate()
                ->firstOrFail();
            $previous = (string) $locked->status;
            $now = now();

            if ($previous === 'sending') {
                if ($locked->next_attempt_at === null || $locked->next_attempt_at->isFuture()) {
                    return [$locked, false, null];
                }
            } elseif (! in_array($previous, ['queued', 'failed'], true)) {
                return [$locked, false, null];
            }

            if ($previous !== 'sending' && ! $ignoreSchedule && $locked->next_attempt_at && $locked->next_attempt_at->isFuture()) {
                return [$locked, false, null];
            }

            if ((int) $locked->attempt_count >= $this->maxAttempts) {
                if ($previous !== 'failed' || $locked->next_attempt_at !== null) {
                    $locked->forceFill([
                        'status' => 'failed',
                        'last_error' => 'Maximum delivery attempts reached.',
                        'next_attempt_at' => null,
                    ])->save();
                    return [$locked->fresh(), false, $previous];
                }
                return [$locked, false, null];
            }

            $leaseSeconds = max(30, (int) config('titan-connect.delivery.attempt_lease_seconds', 300));
            $locked->forceFill([
                'status' => 'sending',
                'attempt_count' => ((int) $locked->attempt_count) + 1,
                'next_attempt_at' => $now->copy()->addSeconds($leaseSeconds),
                'last_error' => null,
            ])->save();

            return [$locked->fresh(), true, $previous];
        });
    }

    public function applyReceipt(ChannelConnection $connection, NormalizedDeliveryReceipt $receipt): ?OutboundDelivery
    {
        if ($receipt->providerMessageId === null || $receipt->providerMessageId === '') {
            return $this->applyWatermarkReceipt($connection, $receipt);
        }
        $delivery = OutboundDelivery::query()
            ->where('company_id', $connection->company_id)
            ->where('channel_connection_id', $connection->id)
            ->where('provider_message_id', $receipt->providerMessageId)
            ->first();
        if (! $delivery) {
            return null;
        }

        $status = $this->normalizeReceiptStatus($receipt->status);
        $changes = [];
        if ($status === 'delivered') {
            $changes['delivered_at'] = now();
        } elseif ($status === 'read') {
            $changes['delivered_at'] = $delivery->delivered_at ?: now();
            $changes['read_at'] = now();
        }
        $delivery = $this->transition($delivery, $status, $changes);
        $delivery->message->forceFill(['status' => $status])->save();
        return $delivery;
    }

    private function applyWatermarkReceipt(ChannelConnection $connection, NormalizedDeliveryReceipt $receipt): ?OutboundDelivery
    {
        $status = $this->normalizeReceiptStatus($receipt->status);
        if (! in_array($status, ['delivered', 'read'], true)) {
            return null;
        }

        $watermark = $receipt->metadata['watermark'] ?? null;
        if (! is_numeric($watermark)) {
            return null;
        }
        $raw = (float) $watermark;
        $seconds = $raw > 100000000000 ? $raw / 1000 : $raw;
        try {
            $cutoff = \Carbon\Carbon::createFromTimestampUTC((int) floor($seconds));
        } catch (\Throwable) {
            return null;
        }

        $threads = ExternalThread::query()
            ->where('company_id', $connection->company_id)
            ->where('channel_connection_id', $connection->id);
        $senderRef = trim((string) ($receipt->metadata['sender_ref'] ?? ''));
        if ($senderRef !== '') {
            $threads->where('external_contact_ref', $senderRef);
        }
        $threadIds = $threads->pluck('id');
        if ($threadIds->isEmpty()) {
            return null;
        }

        $deliveries = OutboundDelivery::query()
            ->where('company_id', $connection->company_id)
            ->where('channel_connection_id', $connection->id)
            ->whereIn('status', $status === 'read' ? ['sent', 'delivered'] : ['sent'])
            ->whereNotNull('sent_at')
            ->where('sent_at', '<=', $cutoff)
            ->whereHas('message', static function ($query) use ($threadIds): void {
                $query->whereIn('external_thread_id', $threadIds->all());
            })
            ->orderBy('id')
            ->limit(5000)->get();

        $last = null;
        foreach ($deliveries as $delivery) {
            $changes = $status === 'read'
                ? ['delivered_at' => $delivery->delivered_at ?: now(), 'read_at' => now()]
                : ['delivered_at' => now()];
            $last = $this->transition($delivery, $status, $changes);
            $last->message->forceFill(['status' => $status])->save();
        }

        return $last;
    }

    public function cancel(OutboundDelivery $delivery): OutboundDelivery
    {
        if (in_array($delivery->status, ['sent', 'delivered', 'read'], true)) {
            throw new RuntimeException('A sent delivery cannot be cancelled.');
        }
        return $this->transition($delivery, 'cancelled', ['next_attempt_at' => null]);
    }

    private function assertScope(int $companyId, ChannelConnection $connection, ExternalThread $thread): void
    {
        if ((int) $connection->company_id !== $companyId || (int) $thread->company_id !== $companyId || (int) $thread->channel_connection_id !== (int) $connection->id) {
            throw new RuntimeException('Outbound messaging scope mismatch.');
        }
        if ($connection->status !== 'active') {
            throw new RuntimeException('Messaging channel is not active.');
        }
    }

    private function transition(OutboundDelivery $delivery, string $status, array $changes = []): OutboundDelivery
    {
        if (! in_array($status, self::ALLOWED_STATUSES, true)) {
            throw new RuntimeException("Invalid outbound delivery status [{$status}].");
        }
        $previous = (string) $delivery->status;
        $delivery->forceFill(['status' => $status] + $changes)->save();
        $delivery = $delivery->fresh();
        if ($previous !== $status) {
            $this->announceTransition($delivery, $previous);
        }
        return $delivery;
    }

    private function announceTransition(OutboundDelivery $delivery, string $previous): void
    {
        $actorId = data_get($delivery->message?->metadata, 'actor_id');
        $this->audit->record((int) $delivery->company_id, is_numeric($actorId) ? (int) $actorId : null, 'external-delivery.status', 'delivery', $delivery->uuid, (string) $delivery->correlation_id, [
            'provider' => $delivery->provider,
            'from' => $previous,
            'to' => (string) $delivery->status,
        ]);
        event(new ExternalMessageStatusChanged($delivery->fresh(), $previous));
    }

    private function messageType(array $metadata): string
    {
        if (is_array($metadata['template'] ?? null) && $metadata['template'] !== []) {
            return 'template';
        }
        if (is_array($metadata['attachments'] ?? null) && $metadata['attachments'] !== []) {
            return 'attachment';
        }
        return 'text';
    }

    private function normalizeProviderSendStatus(string $status): string
    {
        return match (strtolower(trim($status))) {
            'queued', 'accepted', 'sending', 'submitted' => 'sent',
            'sent' => 'sent',
            'delivered' => 'delivered',
            'read', 'seen' => 'read',
            'failed', 'undelivered', 'rejected', 'not-configured' => 'failed',
            default => 'sent',
        };
    }

    private function normalizeReceiptStatus(string $status): string
    {
        return match (strtolower($status)) {
            'queued', 'accepted', 'sending' => 'sending',
            'sent', 'submitted' => 'sent',
            'delivered' => 'delivered',
            'read', 'seen' => 'read',
            'failed', 'undelivered', 'rejected' => 'failed',
            default => 'sent',
        };
    }

    private function redactResponse(array $response): array
    {
        foreach ($response as $key => $value) {
            $response[$key] = $this->redactProviderValue((string) $key, $value);
        }
        return $response;
    }

    private function redactProviderValue(string $key, mixed $value): mixed
    {
        $normalized = strtolower(str_replace('-', '_', $key));
        foreach (['token', 'access_token', 'refresh_token', 'secret', 'app_secret', 'password', 'authorization', 'credentials', 'auth_token', 'api_key_secret', 'bot_token', 'webhook_secret'] as $sensitive) {
            if ($normalized === $sensitive || str_ends_with($normalized, '_'.$sensitive)) {
                return '[redacted]';
            }
        }
        if (is_array($value)) {
            foreach ($value as $nestedKey => $nestedValue) {
                $value[$nestedKey] = $this->redactProviderValue((string) $nestedKey, $nestedValue);
            }
        }
        return $value;
    }
}
