<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Contracts\WorkCoreAuthorizationGateway;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation;
use App\Extensions\TitanConnect\System\Models\VoiceCall;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Extensions\TitanConnect\System\Security\ConversationAccess;
use App\Extensions\TitanConnect\System\Voice\VoiceSessionManager;
use App\Extensions\TitanConnect\System\View\MagicAiDashboardRenderer;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use RuntimeException;

final class VoiceCallController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly ChannelAccessPolicy $channels,
        private readonly ConversationAccess $conversations,
        private readonly WorkCoreAuthorizationGateway $workCore,
        private readonly VoiceSessionManager $sessions,
        private readonly MagicAiDashboardRenderer $dashboard,
    ) {}

    public function start(Request $request, ChannelConnection $connection): JsonResponse
    {
        $companyId=$this->context->companyId($request); $actorId=$this->context->actorId($request);
        abort_unless((int)$connection->company_id===$companyId && $connection->provider==='voice',404);
        abort_unless($this->channels->canSend($connection,$actorId),403);
        $data=$request->validate(['external_thread_uuid'=>['nullable','uuid'],'conversation_uuid'=>['nullable','uuid'],'direction'=>['sometimes','in:inbound,outbound']]);
        abort_if(!empty($data['external_thread_uuid']) && !empty($data['conversation_uuid']),422,'Choose one voice-call context.');
        $thread=null; $conversation=null;
        if (!empty($data['external_thread_uuid'])) {
            $thread=ExternalThread::query()->forCompany($companyId)->where('uuid',$data['external_thread_uuid'])->firstOrFail();
            abort_unless($this->channels->canView($thread->connection,$actorId),403);
            if ($thread->linked_entity_type && $thread->linked_entity_id) $this->workCore->assertCanAccess($companyId,$actorId,(string)$thread->linked_entity_type,(string)$thread->linked_entity_id);
        }
        if (!empty($data['conversation_uuid'])) {
            $conversation=TeamConversation::query()->forCompany($companyId)->where('uuid',$data['conversation_uuid'])->firstOrFail(); $this->conversations->assertMember($conversation,$companyId,$actorId);
        }
        try { $result=$this->sessions->start($companyId,$actorId,$connection,$thread,$conversation,$data['direction'] ?? 'outbound'); }
        catch (RuntimeException $e) { return response()->json(['status'=>'error','message'=>$e->getMessage()],422); }
        return response()->json(['call_uuid'=>$result['call']->uuid,'status'=>$result['call']->status,'session'=>$result['session']],201);
    }

    public function session(Request $request, VoiceCall $call): JsonResponse
    {
        [$companyId] = $this->scope($request, $call);
        try { return response()->json(['session' => $this->sessions->clientSession($companyId, $call)]); }
        catch (RuntimeException $e) { return response()->json(['status'=>'error','message'=>$e->getMessage()],422); }
    }

    public function transcript(Request $request, VoiceCall $call): JsonResponse
    {
        [$companyId,$actorId]=$this->scope($request,$call); $data=$request->validate(['role'=>['required','in:user,assistant,human_agent,system'],'message'=>['required','string','max:50000'],'client_event_id'=>['nullable','string','max:191']]);
        try { $item=$this->sessions->transcript($companyId,$actorId,$call,$data['role'],$data['message'],$data['client_event_id'] ?? null); }
        catch (RuntimeException $e) { return response()->json(['status'=>'error','message'=>$e->getMessage()],422); }
        return response()->json($item,201);
    }

    public function end(Request $request, VoiceCall $call): JsonResponse
    {
        [$companyId,$actorId]=$this->scope($request,$call); return response()->json($this->sessions->end($companyId,$actorId,$call));
    }

    public function show(Request $request, VoiceCall $call): View
    {
        $this->scope($request,$call); return $this->dashboard->render('titan-connect::voice.call',['call'=>$call->load('transcripts')], __('Voice Call'));
    }

    private function scope(Request $request, VoiceCall $call): array
    {
        $companyId=$this->context->companyId($request); $actorId=$this->context->actorId($request); abort_unless((int)$call->company_id===$companyId,404);
        $connection=$call->connection; abort_unless($connection && (int)$connection->company_id===$companyId && $this->channels->canView($connection,$actorId),403); return [$companyId,$actorId];
    }
}
