# Integration contracts

Titan AI is a runtime consumer of Titan AI Workforce organisational identity. It does not create competing employee or team identity. Runtime mutations remain governed and tenant-scoped.
