# Titan Time & Attendance v0.1.0-alpha.3 — Pass 3 Build Report

## Pass objective

Make the extension-owned AI Workforce executable and proactive without creating a second time/attendance authority, allowing model-controlled identity/lineage, or bypassing Titan governance.

## Implemented

### Trusted Workforce execution

- Added `TimeWorkforceExecutionContext` with resolved tenant, human principal, extension-owned role, risk ceiling, autonomy level, capability allow-list, execution mode and trusted lineage.
- Added `TimeWorkforceToolGateway` for bounded read/write tools.
- Model payloads are rejected if they attempt to supply tenant/company identity, actor identity, source, trace, correlation, causation, idempotency or internal context.
- Read tools re-check the underlying human principal's extension permission.
- Write tools route through `TimeCommandBusGateway`; AI/non-human direct-local fallback remains prohibited.

### Risk / Assurance / Autonomy

- Added `TimeRiskPort`, `TimeAssurancePort` and `TimeAutonomyPort` contracts.
- Default Risk/Assurance ports fail closed whenever those gates are required and no external engine binding exists.
- Added explicit autonomy progression: Suggest, Assist, Semi-Auto, Auto and Trusted Auto.
- Suggest/Assist prepare rather than dispatch governed writes.
- Autonomy cannot self-promote, exceed the extension-owned role risk ceiling or bypass mandatory human approval.

### Workforce roles, skills, tools and prompts

The extension remains authoritative for four roles:

1. Time & Attendance Manager — Tier 1
2. Timesheet Auditor — Tier 2
3. Attendance Exception Specialist — Tier 2
4. Workforce Presence Agent — Tier 2

The Workforce manifest now contains 14 active capabilities, 18 bounded tools, seven skills, five executable prompt definitions, four Signal workflows, two active proposal wizards and five generative surfaces. Runtime validation rejects role/tool/capability drift, missing parent managers, skill/tool capability mismatch, empty prompts, invalid workflow roles and invalid wizard/surface references.

### Proactive attention engine

Added deterministic read-only detection for:

- overdue running timers
- failed attendance verification
- rejected or stuck offline evidence
- long time entries
- overlapping persisted time intervals
- multiple simultaneous running timers
- stale weekly submissions

`TimeAttentionService` owns derived finding records only. Findings reopen when a condition returns and resolve when the underlying condition clears. New/reopened findings emit domain Signals using stable deduplication identity. Detector reads are bounded by the configured tenant scan limit.

### Signal-triggered Workforce workflows

Added tenant-idempotent workflow receipts for:

- `attendance.verification.failed`
- `time.timer.overdue`
- `time.submission.ready_for_review`
- `attendance.offline.rejected`

The global Signal listener ignores irrelevant/non-array envelopes before tenant validation. Workflow receipt creation never directly edits authoritative time/attendance records.

### Wizards and generative surfaces

Activated two proposal-first configuration wizards:

- Time & Attendance Setup
- Attendance Verification Policy

`TimeWizardRegistry::compileProposal()` allow-lists wizard fields, rejects unsupported verification methods, validates threshold ranges and returns a governed `time.policy.update` proposal requiring human approval.

Added five tool/capability-backed generative surface descriptors:

- overview
- Needs Attention
- submission review
- attendance exception
- active presence

### Titan Go / offline hardening

- Require UUID `source_event_id`, `device_id`, non-negative monotonic `device_sequence` and device-recorded timestamp at HTTP and service boundaries.
- Preserve source-event idempotency and add tenant + pseudonymous-device + sequence replay protection.
- Device IDs are HMAC-pseudonymised before persistence.
- Raw QR tokens and IP addresses are never persisted; evidence digests use tenant-keyed HMACs.
- Coordinates are HMAC-minimised by default; raw coordinate storage remains explicit policy opt-in.
- Offline presence evidence is server-reverified through `AttendanceVerificationService` before becoming verified evidence.
- Offline records retain canonical verification-log receipt identity and explicit reconciliation status.
- Verification exceptions persist a generic reason code rather than raw exception text.
- Privacy hashing has no predictable fallback key; a missing host `APP_KEY` fails closed and is now an installer-preflight failure.

## Database

Pass 3 adds two reversible extension-owned migrations:

- `2026_08_15_000006_add_ext_titan_time_attention.php`
- `2026_08_15_000007_add_ext_titan_time_workflow_runs.php`

New owned tables:

- `ext_titan_time_attention_findings`
- `ext_titan_time_workflow_runs`

Migration `000006` also adds interval, attention-threshold and offline replay/reconciliation fields to existing **extension-owned** tables. All new index/constraint names are explicit and within MySQL's 64-character identifier limit. No foreign/shared table is created or altered.

## Installer and dependency truthfulness

Alpha.3 optional dependency metadata is intentionally limited to integrations that have an executable contribution or runtime port in this release:

- CRM
- Titan AI Workforce
- Titan Signal
- Titan Command Bus
- Titan Risk
- Titan Assurance
- Titan Autonomy

Rewind, Wisdom, Governance, Vertical and direct Titan-AI runtime dependencies are not advertised until their later-pass runtime contracts exist.

Preflight now verifies PHP/extension requirements, a configured host `APP_KEY`, manifests, Pass-2/Pass-3 migrations, provider, Signal/attention jobs, Workforce gateway/validator and wizard/surface registries.

## Preserved boundaries

- `tenant_company_id` remains the extension persistence boundary.
- CRM remains authoritative for work orders and service locations.
- Titan Workforce remains the central discovery/orchestration layer; role definitions remain extension-owned.
- Command Bus remains the authoritative AI/non-human mutation path.
- Signal remains the cross-system event plane.
- Risk, Assurance and Autonomy remain external engines consumed through ports rather than duplicated here.
- Rewind/Wisdom/Governance/Vertical integration remains later-pass work and is not falsely advertised as live.

## Pre-package verification

Fresh working-tree checks executed before integrity freeze:

- standalone behavioral/architecture tests: **7 / 7 PASS**
- PHP syntax: **91 / 91 PASS** at the pre-document freeze checkpoint
- JSON parse: **6 / 6 PASS**
- duplicate concrete PHP FQCNs: **0**
- foreign/shared schema mutations: **0**
- explicit MySQL index/constraint identifiers over 64 characters: **0**
- dangerous `loginUsingId`, `dd`, `dump`, `var_dump` and debug-route findings in runtime: **0**
- active legacy donor namespace findings: **0**
- sidecar / Workforce / CapabilityCatalog capability drift: **0**
- Workforce tool-registry drift: **0**

The final cumulative ZIP is independently re-extracted and verified after integrity regeneration. The external ZIP SHA-256 is supplied alongside the release artifact rather than embedded recursively inside the package.

## Runtime certification boundary

This build environment does not contain the target Titan Zero Laravel/MySQL installation. Therefore this report does **not** claim live provider boot, real migration/rollback/reinstall, authenticated host middleware, real queue workers or live Command Bus/Signal/CRM/Risk/Assurance execution. Those remain production integration gates for later passes.
