<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Contracts\ChatbotMessagingBridge;
use App\Extensions\TitanConnect\System\Models\ExternalThread;
use RuntimeException;

final class ExternalHandoffService
{
    private const STATES = ['ai', 'pending_human', 'human', 'resolved'];

    public function __construct(
        private readonly ChatbotMessagingBridge $chatbot,
        private readonly MessagingAuditService $audit,
    ) {
    }

    public function setState(int $companyId, int $actorId, ExternalThread $thread, string $state): ExternalThread
    {
        if ((int) $thread->company_id !== $companyId) {
            throw new RuntimeException('External handoff company scope mismatch.');
        }
        $state = strtolower(trim($state));
        if (! in_array($state, self::STATES, true)) {
            throw new RuntimeException("Invalid external handoff state [{$state}].");
        }

        $metadata = is_array($thread->metadata) ? $thread->metadata : [];
        $previous = (string) ($metadata['handoff_state'] ?? 'ai');
        $metadata['handoff_state'] = $state;
        $metadata['handoff_actor_id'] = $actorId;
        $metadata['handoff_changed_at'] = now()->toIso8601String();
        $thread->forceFill([
            'metadata' => $metadata,
            'status' => $state === 'resolved' ? 'resolved' : 'open',
        ])->save();

        $this->audit->record($companyId, $actorId, 'external-thread.handoff', 'external-thread', (string) $thread->uuid, null, [
            'provider' => (string) $thread->provider,
            'from' => $previous,
            'to' => $state,
        ]);
        $thread = $thread->fresh();
        $this->chatbot->onHumanHandoffChanged($companyId, $thread, $state, $actorId);

        return $thread;
    }
}
