<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\CanonicalJson;
use InvalidArgumentException;

final class CompilationPreview
{
    public function __construct(
        private readonly NexusCompilation $draft,
        private readonly string $configurationVersion,
        private readonly string $sourceVerticalHash,
        private readonly ValidationResult $validationResult,
        private readonly ?CompiledTitanConfig $compiledConfiguration,
    ) {
        if ($this->draft->status() !== CompilationStatus::Draft) {
            throw new InvalidArgumentException('Compilation preview requires a draft compilation.');
        }
        if ($this->configurationVersion === '' || strlen($this->configurationVersion) > 80) {
            throw new InvalidArgumentException('configuration_version must be between 1 and 80 characters.');
        }
        if (preg_match('/^[0-9a-f]{64}$/i', $this->sourceVerticalHash) !== 1) {
            throw new InvalidArgumentException('source_vertical_hash must be a SHA-256 hex digest.');
        }
        if ($this->validationResult->hasErrors() && $this->compiledConfiguration !== null) {
            throw new InvalidArgumentException('Blocked preview cannot contain compiled configuration.');
        }
        if (!$this->validationResult->hasErrors() && $this->compiledConfiguration === null) {
            throw new InvalidArgumentException('Valid preview must contain compiled configuration.');
        }
        if ($this->compiledConfiguration !== null) {
            if ($this->compiledConfiguration->tenantCompanyId() !== $this->draft->businessProfile()->tenantCompanyId()) {
                throw new InvalidArgumentException('Preview configuration must belong to the draft tenant.');
            }
            if ($this->compiledConfiguration->configurationVersion() !== $this->configurationVersion) {
                throw new InvalidArgumentException('Preview configuration version must match requested version.');
            }
            if ($this->compiledConfiguration->compilerVersion() !== $this->draft->compilerVersion()) {
                throw new InvalidArgumentException('Preview compiler version must match the draft compiler version.');
            }
            if ($this->compiledConfiguration->sourceVerticalHash() === null
                || !hash_equals(strtolower($this->sourceVerticalHash), strtolower($this->compiledConfiguration->sourceVerticalHash()))) {
                throw new InvalidArgumentException('Preview configuration must reference the exact vertical definition hash.');
            }
        }
    }

    public function dryRun(): bool
    {
        return true;
    }

    public function canCompile(): bool
    {
        return !$this->validationResult->hasErrors() && $this->compiledConfiguration !== null;
    }

    public function validationResult(): ValidationResult
    {
        return $this->validationResult;
    }

    public function compiledConfiguration(): ?CompiledTitanConfig
    {
        return $this->compiledConfiguration;
    }

    public function fingerprint(): string
    {
        return hash('sha256', CanonicalJson::encode($this->withoutFingerprint()));
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return $this->withoutFingerprint() + ['preview_fingerprint' => $this->fingerprint()];
    }

    /** @return array<string, mixed> */
    private function withoutFingerprint(): array
    {
        $profile = $this->draft->businessProfile();
        $config = $this->compiledConfiguration;

        return [
            'dry_run' => true,
            'can_compile' => $this->canCompile(),
            'compilation_uuid' => $this->draft->compilationUuid(),
            'tenant_company_id' => $profile->tenantCompanyId(),
            'vertical_id' => $profile->verticalId(),
            'vertical_version' => $profile->verticalVersion(),
            'configuration_version' => $this->configurationVersion,
            'compiler_version' => $this->draft->compilerVersion(),
            'input_hash' => $profile->fingerprint(),
            'source_vertical_hash' => strtolower($this->sourceVerticalHash),
            'output_hash' => $config?->outputHash(),
            'validation' => $this->validationResult->toArray(),
            'section_summary' => $this->sectionSummary($config?->sections() ?? []),
            'compiled_configuration' => $config?->toArray(),
        ];
    }

    /**
     * @param array<string|int, mixed> $sections
     * @return list<array{name:string,kind:string,item_count:int}>
     */
    private function sectionSummary(array $sections): array
    {
        $summary = [];
        foreach ($sections as $name => $value) {
            $kind = 'scalar';
            $count = 1;
            if (is_array($value)) {
                $kind = array_is_list($value) ? 'list' : 'map';
                $count = count($value);
            }
            $summary[] = [
                'name' => (string) $name,
                'kind' => $kind,
                'item_count' => $count,
            ];
        }
        usort($summary, static fn (array $a, array $b): int => strcmp($a['name'], $b['name']));
        return $summary;
    }
}
