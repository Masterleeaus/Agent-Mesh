<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\ValueObjects;

use InvalidArgumentException;

final readonly class PrimeBudget
{
    public function __construct(
        public int $maxCostMinor = 0,
        public int $maxTokens = 0,
        public int $maxRuntimeSeconds = 0,
        public int $maxDelegations = 0,
        public int $maxParallelDelegations = 0,
        public float $maxRiskScore = 0.0,
        public int $maxExternalActions = 0,
    ) {
        foreach ([
            'maxCostMinor' => $maxCostMinor,
            'maxTokens' => $maxTokens,
            'maxRuntimeSeconds' => $maxRuntimeSeconds,
            'maxDelegations' => $maxDelegations,
            'maxParallelDelegations' => $maxParallelDelegations,
            'maxExternalActions' => $maxExternalActions,
        ] as $name => $value) {
            if ($value < 0) {
                throw new InvalidArgumentException(sprintf('%s must be zero or greater.', $name));
            }
        }

        if ($maxRiskScore < 0.0 || $maxRiskScore > 1.0) {
            throw new InvalidArgumentException('maxRiskScore must be between 0.0 and 1.0.');
        }

        if ($maxDelegations > 0 && $maxParallelDelegations > $maxDelegations) {
            throw new InvalidArgumentException('maxParallelDelegations cannot exceed maxDelegations.');
        }
    }

    public function allowsRisk(float $score): bool
    {
        return $score >= 0.0 && $score <= $this->maxRiskScore;
    }

    /** @return array<string,int|float> */
    public function toArray(): array
    {
        return [
            'max_cost_minor' => $this->maxCostMinor,
            'max_tokens' => $this->maxTokens,
            'max_runtime_seconds' => $this->maxRuntimeSeconds,
            'max_delegations' => $this->maxDelegations,
            'max_parallel_delegations' => $this->maxParallelDelegations,
            'max_risk_score' => $this->maxRiskScore,
            'max_external_actions' => $this->maxExternalActions,
        ];
    }
}
