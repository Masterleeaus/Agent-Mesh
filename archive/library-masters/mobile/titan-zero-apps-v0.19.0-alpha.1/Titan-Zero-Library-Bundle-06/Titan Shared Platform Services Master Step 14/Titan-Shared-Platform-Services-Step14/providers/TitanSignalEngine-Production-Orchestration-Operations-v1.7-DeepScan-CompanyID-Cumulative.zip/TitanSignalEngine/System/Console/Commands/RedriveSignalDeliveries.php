<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Console\Commands;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalDeliveryRedriveContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalActor;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use Illuminate\Console\Command;
use InvalidArgumentException;

final class RedriveSignalDeliveries extends Command
{
    protected $signature = 'titan:signal-deliveries:redrive
        {--delivery= : Redrive one dead-letter delivery id}
        {--scope=system : system or tenant}
        {--tenant= : Tenant company id for tenant scope}
        {--subscriber= : Optional subscriber key filter}
        {--limit=100 : Maximum dead letters to redrive}
        {--reason= : Required governed reason}';

    protected $description = 'Governedly redrive one or more Titan Signal dead-letter deliveries.';

    public function handle(SignalDeliveryRedriveContract $redrive): int
    {
        $reason = trim((string) $this->option('reason'));
        if ($reason === '') {
            $this->error('--reason is required.');
            return self::FAILURE;
        }

        $scope = trim((string) $this->option('scope'));
        $tenant = $this->option('tenant');
        $tenantId = $tenant === null || $tenant === '' ? null : (int) $tenant;
        if ($scope === 'tenant' && ($tenantId === null || $tenantId < 1)) {
            $this->error('--tenant is required for tenant scope.');
            return self::FAILURE;
        }
        if (! in_array($scope, ['system', 'tenant'], true)) throw new InvalidArgumentException('Scope must be system or tenant.');

        $context = new SignalContext(
            $scope,
            $scope === 'tenant' ? $tenantId : null,
            new SignalActor('cli:titan-signal-delivery-redrive', 'system', $scope === 'tenant' ? $tenantId : null, 'titan-cli', null),
            ['signal.delivery.redrive', 'signal.system.read', 'signal.tenant.read', 'signal.tenant.emit'],
        );

        $deliveryId = trim((string) $this->option('delivery'));
        if ($deliveryId !== '') {
            $receipt = $redrive->redrive($deliveryId, $reason, $context);
            $this->info(sprintf('Redrive queued: %s (%s)', $receipt->deliveryId, $receipt->status));
            return self::SUCCESS;
        }

        $result = $redrive->redriveBatch(
            $scope,
            $scope === 'tenant' ? $tenantId : null,
            (($value = trim((string) $this->option('subscriber'))) === '' ? null : $value),
            (int) $this->option('limit'),
            $reason,
            $context,
        );
        $this->info(sprintf('Selected %d; redriven %d; skipped %d.', $result['selected'], $result['redriven'], $result['skipped']));
        return self::SUCCESS;
    }
}
