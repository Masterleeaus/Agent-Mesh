<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

interface MobilePushGateway
{
    public function send(int $companyId, array $recipientUserIds, array $notification): array;
}
