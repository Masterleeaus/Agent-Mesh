<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\TraceProfileRegistryContract;
use App\Extensions\TitanSignalEngine\System\Data\TraceProfile;
use App\Extensions\TitanSignalEngine\System\Models\SignalTraceProfile;
use Illuminate\Support\Facades\Schema;
use RuntimeException;

final class TraceProfileRegistry implements TraceProfileRegistryContract
{
    public function register(TraceProfile $profile): void
    {
        if (! Schema::hasTable('titan_signal_trace_profiles')) {
            throw new RuntimeException('Signal trace profile registry table is not installed.');
        }

        /** @var SignalTraceProfile|null $existing */
        $existing = SignalTraceProfile::query()
            ->where('profile_key', $profile->profileKey)
            ->where('version', $profile->version)
            ->first();
        if ($existing !== null) {
            $stored = TraceProfile::fromArray([
                ...$existing->getAttributes(),
                'required_event_types' => $existing->required_event_types ?? [],
                'ordering_rules' => $existing->ordering_rules ?? [],
                'terminal_event_types' => $existing->terminal_event_types ?? [],
                'match_event_types' => $existing->match_event_types ?? null,
            ]);
            if ($stored->toArray() !== $profile->toArray()) {
                throw new RuntimeException('Signal trace profile versions are immutable; register a new version instead.');
            }
            return;
        }

        SignalTraceProfile::query()->create($profile->toArray());
    }

    public function find(string $profileKey, ?int $version = null): ?TraceProfile
    {
        if (! Schema::hasTable('titan_signal_trace_profiles')) {
            return $this->configured($profileKey, $version);
        }

        $query = SignalTraceProfile::query()->where('profile_key', trim($profileKey))->where('status', 'active');
        if ($version !== null) {
            $query->where('version', $version);
        } else {
            $query->orderByDesc('version');
        }
        /** @var SignalTraceProfile|null $row */
        $row = $query->first();
        if ($row === null) {
            return $this->configured($profileKey, $version);
        }

        return TraceProfile::fromArray([
            ...$row->getAttributes(),
            'required_event_types' => $row->required_event_types ?? [],
            'ordering_rules' => $row->ordering_rules ?? [],
            'terminal_event_types' => $row->terminal_event_types ?? [],
            'match_event_types' => $row->match_event_types ?? null,
        ]);
    }


    /** @return list<TraceProfile> */
    public function matchingEventType(string $eventType, int $limit = 64): array
    {
        $eventType = trim($eventType);
        if ($eventType === '') return [];
        $limit = max(1, min($limit, 256));
        $result = [];
        $seen = [];

        if (Schema::hasTable('titan_signal_trace_profiles')) {
            $rows = SignalTraceProfile::query()
                ->where('status', 'active')
                ->orderBy('profile_key')
                ->orderByDesc('version')
                ->limit(max($limit * 4, $limit))
                ->cursor();
            foreach ($rows as $row) {
                $key = (string) $row->profile_key;
                if (isset($seen[$key])) continue;
                $profile = TraceProfile::fromArray([
                    ...$row->getAttributes(),
                    'required_event_types' => $row->required_event_types ?? [],
                    'ordering_rules' => $row->ordering_rules ?? [],
                    'terminal_event_types' => $row->terminal_event_types ?? [],
                    'match_event_types' => $row->match_event_types ?? null,
                ]);
                $seen[$key] = true;
                if ($profile->matchesEventType($eventType)) {
                    $result[] = $profile;
                    if (count($result) >= $limit) return $result;
                }
            }
        }

        // Config is a bootstrap fallback only for profile keys that do not yet
        // have an active persisted definition. Persisted governance wins.
        $profiles = function_exists('config') ? (array) config('titan-signal-engine.trace_profiles', []) : [];
        foreach ($profiles as $key => $definition) {
            if (isset($seen[(string) $key]) || ! is_array($definition)) continue;
            $profile = TraceProfile::fromArray(['profile_key' => (string) $key, ...$definition]);
            if ($profile->status === 'active' && $profile->matchesEventType($eventType)) {
                $result[] = $profile;
                if (count($result) >= $limit) break;
            }
        }
        return $result;
    }

    private function configured(string $profileKey, ?int $version): ?TraceProfile
    {
        $profiles = function_exists('config') ? (array) config('titan-signal-engine.trace_profiles', []) : [];
        $definition = $profiles[$profileKey] ?? null;
        if (! is_array($definition)) {
            return null;
        }
        $profile = TraceProfile::fromArray(['profile_key' => $profileKey, ...$definition]);
        return $version === null || $profile->version === $version ? $profile : null;
    }
}
