# Titan Installer Contract

Titan Time & Attendance is packaged as a flat-root `titan-extension-v1` extension.

## Identity

- Folder: `TitanTimeAttendance`
- Provider: `App\Extensions\TitanTimeAttendance\System\TitanTimeAttendanceServiceProvider`
- Register key: `titan-time-attendance`
- Version: `0.1.1`
- Tenant persistence key: `tenant_company_id`

## Compatibility and preflight

The package targets Titan Custom Extension Manager **1.7.8** and declares PHP `>=8.2`, MagicAI `>=11.0` and Titan Platform `>=1.0`. Preflight checks JSON, PDO and mbstring support; a configured `APP_KEY` required for privacy HMACs; root/sidecar/Workforce manifests; exact provider identity; the current migration set; Workforce gateway; Signal/attention queue jobs; release verifier; and complete package integrity.

## Lifecycle

- Migrations create or alter extension-owned `ext_titan_time_*` tables only.
- Disable is configuration-driven and stops extension boot without deleting business/audit data.
- Health validates owned tables, manifests and key runtime components; optional Titan-engine readiness is reported separately.
- Uninstall defaults to **retain**.
- Upgrades use forward-only, reversible extension-owned migrations.

## Queue and schedules

- Queue: `titan-time-attendance`
- `titan-time-attendance:deliver-signals` — every minute
- `titan-time-attendance:scan-attention` — every five minutes
- Both paths dispatch tenant-specific jobs; workers carry explicit tenant context and do not perform a global cross-tenant business-data batch.

## Governance

Write capabilities carry explicit permission, risk, approval, idempotency and lineage metadata. Human local web writes may use the extension executor only when explicitly enabled. Non-human/AI writes cannot use this fallback and fail closed until a Titan Command Bus binding is available.

The extension-owned Workforce gateway additionally validates trusted role/tool/capability access, role risk ceiling, underlying human-principal permission and autonomy state. Suggest/Assist produce prepared work rather than silently dispatching mutations. Mandatory human approval cannot be bypassed by Autonomy, Risk or Assurance responses.

Optional peer declarations express integration points, not a claim that every peer currently exposes a compatible callable API. CRM, Workforce, Signal and Rewind have concrete adapters/contributions in this extension. Command Bus, Risk and Assurance remain fail-closed through Time-specific ports when no compatible host binding is supplied. Governance, Wisdom and Vertical remain export-only boundaries until their owning engines expose ingestion contracts.

## CRM authority

The package does not import CRM models or write CRM tables. It consumes `crm.work_order.read` and `crm.location.read` through CRM's capability executor when canonical public references are supplied. Supplied canonical references fail closed when CRM is unavailable under the default policy.

## Offline authority

Titan Go/offline ingestion uses source-event idempotency plus tenant/device/sequence replay protection. The persisted device identifier is tenant-pseudonymous. Offline presence evidence is server-reverified by the canonical attendance verification service and links to its verification receipt. QR, IP and location evidence are HMAC-minimised by default rather than persisted raw.

## Workforce discovery

`resources/workforce/workforce-manifest.json` remains the source of truth for extension-owned roles, skills, tools, prompts, workflows, wizards and surfaces. Titan Workforce discovers that manifest; it does not own duplicate role definitions. The four current roles validate against the current Titan AI Workforce `RoleDefinition` schema.

## Integrity

Release packaging writes the Titan 1.7.8 SHA-256 map at `extension.json.integrity.files`, covering every packaged regular file except self-referential `extension.json`. `FILE-SHA256.json` independently inventories every non-control package file. No signing key is embedded or fabricated.

## Host verification boundary

Package verification proves archive structure, manifests, hashes, syntax and isolated architecture contracts. Actual Laravel provider boot, MySQL migration execution/rollback, queue workers, authenticated middleware, Command Bus binding, Signal runtime and live CRM/Titan-engine execution still require the target Titan Zero host.
