# Upgrade
Upgrades use forward-only-compatible migrations. Pass 2 added the normalized durable domain; Pass 3 tightened the runtime scope boundary; Pass 4 hardens immutable source-version lifecycle semantics.

Pass 4 replaces the `titan_knowledge_source_versions.source_id` cascade-on-delete foreign key with a restricted-delete foreign key. Existing versions and identifiers are not rewritten. Rollback restores the previous cascade contract, but production rollback should be governed because doing so re-opens the historical parent-cascade behavior.

Legacy source rows remain retained but excluded from canonical scoped repositories until a later governed backfill classifies them.
