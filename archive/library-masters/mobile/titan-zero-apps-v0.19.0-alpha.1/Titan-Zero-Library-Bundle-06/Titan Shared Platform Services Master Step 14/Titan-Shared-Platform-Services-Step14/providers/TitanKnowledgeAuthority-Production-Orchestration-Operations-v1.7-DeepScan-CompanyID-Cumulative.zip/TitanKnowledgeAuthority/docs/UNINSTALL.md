# Uninstall
The marketplace uninstall hook removes extension-owned published configuration only. Durable knowledge data is retained by default so uninstalling code cannot silently destroy provenance or audit history.
