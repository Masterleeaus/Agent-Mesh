@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Presentations','subtitle'=>'Executive snapshots and presentation-ready business summaries.','surface'=>'insights'] )<div class="container-fluid py-4"><p class="text-muted">Generated {{ $presentation['generated_at'] }}</p><div class="row g-4">@foreach($presentation['slides'] as $slide)<div class="col-lg-4"><div class="card h-100"><div class="card-header"><strong>{{ $slide['title'] }}</strong></div><div class="card-body"><pre class="small mb-0">{{ json_encode($slide['data'], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div></div></div>@endforeach</div></div>@endcomponent
@endsection
