@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>$lead['name'],'subtitle'=>($lead['company_name'] ?? 'Individual lead').' · '.ucfirst($lead['status'] ?? 'new'),'surface'=>'leads','journey'=>'new-opportunity','secondaryJourneys'=>['new-quote'],'recordType'=>'lead','context'=>array_filter(['record_type'=>'lead','public_id'=>$lead['public_id'],'lead_public_id'=>$lead['public_id'],'company_public_id'=>$lead['company_public_id'] ?? null,'contact_public_id'=>$lead['contact_public_id'] ?? null])])
    <div class="d-flex justify-content-between align-items-center mb-4"><a href="{{ route('dashboard.user.crm.leads.index') }}" class="small">← Leads</a><div class="text-end"><span class="fw-semibold">{{ $lead['lead_score'] ?? 0 }}/100</span> <span class="badge text-bg-primary">{{ ucfirst($lead['qualification_status'] ?? 'unqualified') }}</span></div></div>
    @if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif
    <div class="row g-4"><div class="col-lg-5">
        <div class="card mb-4"><div class="card-header"><strong>Lead details</strong></div><div class="card-body"><form method="post" action="{{ route('dashboard.user.crm.leads.update',$lead['public_id']) }}" class="row g-3">@csrf @method('PATCH')
            <div class="col-12"><label class="form-label">Name</label><input name="name" class="form-control" value="{{ $lead['name'] }}"></div>
            <div class="col-md-6"><label class="form-label">Email</label><input name="email" class="form-control" value="{{ $lead['email'] }}"></div><div class="col-md-6"><label class="form-label">Phone</label><input name="phone" class="form-control" value="{{ $lead['phone'] }}"></div>
            <div class="col-12"><label class="form-label">Company</label><input name="company_name" class="form-control" value="{{ $lead['company_name'] }}"></div>
            <div class="col-md-6"><label class="form-label">Status</label><select name="status" class="form-select">@foreach(['new','contacted','working','lost'] as $s)<option value="{{ $s }}" @selected(($lead['status']??'')===$s)>{{ ucfirst($s) }}</option>@endforeach</select></div>
            <div class="col-md-6"><label class="form-label">Follow-up</label><input name="follow_up_at" class="form-control" type="datetime-local" value="{{ $lead['follow_up_at'] ? date('Y-m-d\TH:i',strtotime($lead['follow_up_at'])) : '' }}"></div>
            <div class="col-12"><label class="form-label">Notes</label><textarea name="notes" class="form-control" rows="4">{{ $lead['notes'] }}</textarea></div><div class="col-12"><button class="btn btn-primary">Save lead</button></div>
        </form></div></div>
    </div><div class="col-lg-7">
        <div class="card mb-4"><div class="card-header"><strong>Qualification</strong></div><div class="card-body"><form method="post" action="{{ route('dashboard.user.crm.leads.qualify',$lead['public_id']) }}" class="row g-3">@csrf
            <div class="col-md-4"><label class="form-label">Score</label><input name="lead_score" type="number" min="0" max="100" class="form-control" value="{{ $lead['lead_score'] ?? 0 }}"></div>
            <div class="col-md-4"><label class="form-label">Qualification</label><select name="qualification_status" class="form-select">@foreach(['unqualified','nurture','qualified','disqualified'] as $s)<option value="{{ $s }}" @selected(($lead['qualification_status']??'')===$s)>{{ ucfirst($s) }}</option>@endforeach</select></div>
            <div class="col-md-4"><label class="form-label">Next follow-up</label><input name="next_follow_up_at" type="datetime-local" class="form-control" value="{{ $lead['next_follow_up_at'] ? date('Y-m-d\TH:i',strtotime($lead['next_follow_up_at'])) : '' }}"></div>
            <div class="col-12"><button class="btn btn-outline-primary">Update qualification</button></div>
        </form></div></div>
        @if(($lead['status'] ?? '') !== 'converted')<div class="card border-primary"><div class="card-body d-flex justify-content-between align-items-center"><div><strong>Convert lead</strong><div class="text-muted small">Creates a CRM company and primary contact while preserving this lead's history.</div></div><form method="post" action="{{ route('dashboard.user.crm.leads.convert',$lead['public_id']) }}">@csrf<button class="btn btn-primary" onclick="return confirm('Convert this lead?')">Convert</button></form></div></div>@endif
    </div></div>
@endcomponent
@endsection
