<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Realtime;

final class SafeRealtimeDispatcher
{
    public function dispatch(object $event): bool
    {
        try {
            event($event);
            return true;
        } catch (\Throwable $e) {
            if (function_exists('report')) {
                report($e);
            }
            return false;
        }
    }
}
