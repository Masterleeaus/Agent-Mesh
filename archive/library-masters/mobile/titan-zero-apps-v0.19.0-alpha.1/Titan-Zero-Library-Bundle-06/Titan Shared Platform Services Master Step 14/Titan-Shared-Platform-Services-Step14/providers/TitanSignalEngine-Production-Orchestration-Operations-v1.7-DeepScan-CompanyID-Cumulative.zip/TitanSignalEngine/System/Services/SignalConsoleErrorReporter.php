<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use Illuminate\Support\Facades\Log;
use Throwable;

final class SignalConsoleErrorReporter
{
    public function report(Throwable $exception, string $operation, ?SignalContext $context = null): string
    {
        $reference = 'SIG-' . strtoupper(substr(hash('sha256', $operation . '|' . $exception::class . '|' . microtime(true) . '|' . bin2hex(random_bytes(8))), 0, 12));

        Log::error('titan_signal.console_operation_failed', [
            'reference' => $reference,
            'operation' => $operation,
            'exception_class' => $exception::class,
            'scope' => $context?->scope,
            'tenant_company_id' => $context?->tenantCompanyId,
            'actor_id' => $context?->actor->id,
            // Laravel's logger serializes the exception for restricted server logs.
            'exception' => $exception,
        ]);

        return "Signal Console request failed. Reference: {$reference}";
    }
}
