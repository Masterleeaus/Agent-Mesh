<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$passes = 0;
$check = static function (bool $condition, string $message) use (&$failures, &$passes): void {
    if ($condition) { ++$passes; echo "PASS: {$message}\n"; return; }
    $failures[] = $message; echo "FAIL: {$message}\n";
};

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$check(($manifest['version'] ?? null) === '1.0.6', 'manifest version is 1.0.6');
foreach (['rewind.timeline','rewind.reconstruct','rewind.case','rewind.snapshot','rewind.dependencies','rewind.replay.dry_run'] as $capability) {
    $check(in_array($capability, $manifest['capabilities'] ?? [], true), "capability {$capability} is truthfully declared");
}
$check(($manifest['queues']['used'] ?? null) === true, 'manifest declares replay queue usage');
$check(in_array('titan-rewind-replay', $manifest['queues']['queue_names'] ?? [], true), 'replay queue is named');
foreach (['titan_rewind_cases','titan_rewind_case_traces','titan_rewind_timeline_entries','titan_rewind_dependencies','titan_rewind_replay_runs'] as $table) {
    $check(in_array($table, $manifest['database']['owned_tables'] ?? [], true), "manifest owns {$table}");
}

$required = [
    '/System/Models/RewindTraceEvent.php',
    '/System/Models/RewindTraceIndex.php',
    '/System/Models/RewindCase.php',
    '/System/Models/RewindCaseTrace.php',
    '/System/Models/RewindTimelineEntry.php',
    '/System/Models/RewindSnapshot.php',
    '/System/Models/RewindDependency.php',
    '/System/Models/RewindReplayRun.php',
    '/System/Services/RewindEventStore.php',
    '/System/Services/RewindCaseService.php',
    '/System/Services/RewindTimelineService.php',
    '/System/Services/RewindSnapshotService.php',
    '/System/Services/RewindDependencyService.php',
    '/System/Services/RewindReplayService.php',
    '/System/Services/RewindReconstructionService.php',
    '/System/Services/RewindTraceProjector.php',
    '/System/Support/RewindPayloadSanitizer.php',
    '/System/Reconstruction/RewindTimelineAssembler.php',
    '/System/Reconstruction/RewindDiffService.php',
    '/System/Reconstruction/RewindDependencyExtractor.php',
    '/System/Jobs/RunReplaySimulationJob.php',
    '/System/Http/Controllers/TraceController.php',
    '/System/Http/Controllers/ReplayController.php',
    '/database/migrations/2026_08_12_000003_add_titan_rewind_product_core.php',
];
foreach ($required as $file) $check(is_file($root . $file), "product-core file exists: {$file}");

$pureFiles = [
    '/System/Support/RewindPayloadSanitizer.php',
    '/System/Reconstruction/RewindTimelineAssembler.php',
    '/System/Reconstruction/RewindDiffService.php',
    '/System/Reconstruction/RewindDependencyExtractor.php',
];
if (!array_filter($pureFiles, static fn (string $file): bool => !is_file($root . $file))) {
    foreach ($pureFiles as $file) require_once $root . $file;

    $sanitizer = new App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer(['password','token','secret','api_key']);
    $clean = $sanitizer->sanitize(['customer'=>['name'=>'A','token'=>'abc'], 'password'=>'x']);
    $check(($clean['customer']['token'] ?? null) === '[REDACTED]', 'snapshot sanitizer redacts nested secrets');
    $check(($clean['password'] ?? null) === '[REDACTED]', 'snapshot sanitizer redacts top-level secrets');
    try {
        $sanitizer->sanitize(['nested'=>['chain_of_thought'=>'private']]);
        $check(false, 'snapshot sanitizer rejects hidden reasoning');
    } catch (InvalidArgumentException) {
        $check(true, 'snapshot sanitizer rejects hidden reasoning');
    }

    $assembler = new App\Extensions\TitanRewind\System\Reconstruction\RewindTimelineAssembler();
    $events = [
        ['event_id'=>'00000000-0000-4000-8000-000000000003','sequence'=>2,'occurred_at'=>'2026-08-12T10:00:00.000002+00:00','source_engine'=>'risk','event_type'=>'risk.assessed'],
        ['event_id'=>'00000000-0000-4000-8000-000000000001','sequence'=>1,'occurred_at'=>'2026-08-12T10:00:00.000001+00:00','source_engine'=>'core','event_type'=>'decision.created'],
        ['event_id'=>'00000000-0000-4000-8000-000000000002','sequence'=>2,'occurred_at'=>'2026-08-12T10:00:00.000001+00:00','source_engine'=>'knowledge','event_type'=>'knowledge.read'],
    ];
    $ordered = $assembler->order($events);
    $check(array_column($ordered, 'event_id') === [
        '00000000-0000-4000-8000-000000000001',
        '00000000-0000-4000-8000-000000000002',
        '00000000-0000-4000-8000-000000000003',
    ], 'timeline assembly is deterministic by sequence/time/event id');

    $diff = new App\Extensions\TitanRewind\System\Reconstruction\RewindDiffService();
    $comparison = $diff->compare(['a'=>1,'nested'=>['x'=>1]], ['a'=>2,'nested'=>['x'=>2],'b'=>3]);
    $check(($comparison['count'] ?? 0) >= 3, 'recursive diff identifies added and modified state');
    $check(($comparison['risk'] ?? null) === 'low', 'non-sensitive recursive diff is low risk');

    $extractor = new App\Extensions\TitanRewind\System\Reconstruction\RewindDependencyExtractor();
    $deps = $extractor->extract([
        'dependencies'=>[
            ['target_entity_type'=>'invoice','target_entity_id'=>'9','relationship_type'=>'generated'],
            ['relationship_type'=>'invalid'],
        ],
    ], 'job', '7');
    $check(count($deps) === 1, 'dependency extractor ignores invalid dependency entries');
    $check(($deps[0]['source_entity_type'] ?? null) === 'job', 'dependency extractor supplies source entity defaults');
}

$provider = (string) file_get_contents($root . '/System/TitanRewindServiceProvider.php');
foreach (['RewindEventStore::class','RewindCaseService::class','RewindTimelineService::class','RewindSnapshotService::class','RewindDependencyService::class','RewindReplayService::class','RewindReconstructionService::class'] as $binding) {
    $check(str_contains($provider, $binding), "provider wires {$binding}");
}
$check(!str_contains($provider, 'eloquent.created: *'), 'provider does not install global Eloquent capture');

$migrationPath = $root . '/database/migrations/2026_08_12_000003_add_titan_rewind_product_core.php';
if (is_file($migrationPath)) {
    $migration = (string) file_get_contents($migrationPath);
    $check(str_contains($migration, "unsignedBigInteger('tenant_company_id')"), 'product tables use tenant_company_id');
    $check(!preg_match("/->(?:unsignedBigInteger|string)\('company_id'/", $migration), 'product migration does not introduce legacy company_id');
    $check(str_contains($migration, "'entity_type'"), 'snapshot compatibility adds entity identity');
    $check(str_contains($migration, "'state_hash'"), 'snapshot compatibility adds state hash');
}

$routes = (string) file_get_contents($root . '/routes/user.php');
$check(str_contains($routes, "TraceController"), 'user routes expose trace reconstruction');
$check(str_contains($routes, "ReplayController"), 'user routes expose dry-run replay');

if ($failures !== []) {
    fwrite(STDERR, "\nPRODUCT CORE VERIFICATION FAILED (" . count($failures) . " failures, {$passes} passes)\n");
    exit(1);
}

echo "\nPRODUCT CORE VERIFICATION PASSED ({$passes} checks)\n";
