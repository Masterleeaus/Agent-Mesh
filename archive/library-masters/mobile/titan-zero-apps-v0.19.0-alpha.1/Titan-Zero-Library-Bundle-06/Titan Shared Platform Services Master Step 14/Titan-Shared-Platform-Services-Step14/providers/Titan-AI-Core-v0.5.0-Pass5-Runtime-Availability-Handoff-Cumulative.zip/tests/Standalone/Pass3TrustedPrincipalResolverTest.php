<?php

declare(strict_types=1);
$root = dirname(__DIR__, 2);
foreach ([
    'System/DTO/AuthorityContext.php',
    'System/DTO/ActorContext.php',
    'System/DTO/TrustedPrincipal.php',
    'System/Exceptions/SecurityContextException.php',
    'System/Contracts/TrustedPrincipalResolverContract.php',
    'System/Security/HostTrustedPrincipalResolver.php',
] as $relative) require_once $root . '/' . $relative;

use App\Extensions\TitanAICore\System\Exceptions\SecurityContextException;
use App\Extensions\TitanAICore\System\Security\HostTrustedPrincipalResolver;

final class FakePrincipal {
    public function getAuthIdentifier(): int { return 77; }
    public function getAttribute(string $key): mixed {
        return match($key) {
            'tenant_company_id' => 'company-77',
            'actor_type' => 'human',
            'authority_level' => 3,
            default => null,
        };
    }
    public function can(string $capability): bool { return in_array($capability, ['ai.core.read','ai.core.plan.create'], true); }
}
final class MissingTenantPrincipal {
    public function getAuthIdentifier(): int { return 99; }
    public function getAttribute(string $key): mixed { return null; }
    public function can(string $capability): bool { return true; }
}

$resolver = new HostTrustedPrincipalResolver();
$p = $resolver->resolve(new FakePrincipal());
if ($p->actorId !== '77' || $p->tenantCompanyId !== 'company-77' || $p->actorType !== 'human' || $p->authorityLevel !== 3) {
    fwrite(STDERR, "trusted principal fields were not resolved from host principal\n"); exit(1);
}
if (!in_array('ai.core.read', $p->permissions, true) || in_array('ai.core.admin', $p->permissions, true)) {
    fwrite(STDERR, "permission resolution is not fail-closed\n"); exit(1);
}
try {
    $resolver->resolve(new MissingTenantPrincipal());
    fwrite(STDERR, "principal without tenant was accepted\n"); exit(1);
} catch (SecurityContextException $e) {
    if ($e->securityCode !== 'TENANT_CONTEXT_UNRESOLVED') { fwrite(STDERR, "wrong missing tenant code\n"); exit(1); }
}
fwrite(STDOUT, "Pass 3 trusted principal resolver test: PASS\n");
