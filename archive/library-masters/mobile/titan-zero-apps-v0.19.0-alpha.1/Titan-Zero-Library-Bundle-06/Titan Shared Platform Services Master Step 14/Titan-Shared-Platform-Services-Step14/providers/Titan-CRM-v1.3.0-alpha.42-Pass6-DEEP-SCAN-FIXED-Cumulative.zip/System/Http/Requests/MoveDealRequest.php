<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
final class MoveDealRequest extends FormRequest {
 public function authorize(): bool { return true; }
 public function rules(): array { return ['stage_public_id'=>['required','string','size:26'],'probability'=>['nullable','integer','between:0,100'],'position'=>['sometimes','integer','min:0']]; }
}
