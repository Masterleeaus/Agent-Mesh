<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\View\MagicAiDashboardRenderer;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

final class InboxNavigationController extends Controller
{
    private const MODES = ['unified', 'team', 'external', 'mine', 'unassigned', 'needs_human', 'closed'];

    public function __construct(
        private readonly CompanyContext $context,
        private readonly MagicAiDashboardRenderer $dashboard,
    ) {
    }

    public function root(Request $request): RedirectResponse
    {
        $this->context->companyId($request);
        return redirect()->route('dashboard.user.titan-connect.inbox.unified');
    }

    public function show(Request $request, string $mode): View
    {
        $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $mode = strtolower(trim($mode));
        abort_unless(in_array($mode, self::MODES, true), 404);

        if (in_array($mode, ['unified', 'team'], true)) {
            return $this->dashboard->render('titan-connect::inbox.unified', ['mode' => $mode], $mode === 'team' ? __('Team / Internal') : __('Unified Inbox'));
        }

        $filters = match ($mode) {
            'mine' => ['assigned_user_id' => $actorId, 'status' => 'open'],
            'unassigned' => ['unassigned' => true, 'status' => 'open'],
            'needs_human' => ['handoff_state' => 'pending_human', 'status' => 'open'],
            'closed' => ['status' => 'closed'],
            default => [],
        };

        return $this->dashboard->render('titan-connect::inbox.index', [
            'mode' => $mode,
            'initialFilters' => $filters,
        ], __('Inbox'));
    }
}
