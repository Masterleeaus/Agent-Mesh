<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Http\Controllers;
use App\Extensions\Crm\System\Services\{CrmMergeService,CrmDuplicateReviewService};
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class DuplicateController extends Controller {
 public function __construct(private CrmMergeService $merge,private CrmDuplicateReviewService $reviews,private CrmHumanMutationGateway $mutations){}
 public function index(Request $request){$resource=(string)$request->query('resource','contacts');$data=['resource'=>$resource,'groups'=>$this->merge->candidates((int)$request->user()->id,$resource),'reviews'=>$this->reviews->search((int)$request->user()->id,['status'=>'pending','limit'=>100])];return $request->expectsJson()?response()->json(['data'=>$data]):view('crm::duplicates.index',$data);}
 public function preview(Request $request){$d=$request->validate(['resource'=>'required|in:companies,contacts,leads','winner_public_id'=>'required|string|size:26','loser_public_id'=>'required|string|size:26']);return response()->json(['data'=>$this->merge->preview((int)$request->user()->id,$d['resource'],$d['winner_public_id'],$d['loser_public_id'])]);}
 public function merge(Request $request){$d=$request->validate(['resource'=>'required|in:companies,contacts,leads','winner_public_id'=>'required|string|size:26','loser_public_id'=>'required|string|size:26']);$record=$this->mutations->execute($request,'crm.record.merge',$d);return $request->expectsJson()?response()->json(['data'=>$record]):back()->with('status','Duplicate records merged with Rewind evidence.');}
 public function resolveReview(Request $request,string $review){$d=$request->validate(['decision'=>'required|in:use_existing,dismissed','reason'=>'nullable|string|max:1000']);$record=$this->mutations->execute($request,'crm.duplicate.review.resolve',['public_id'=>$review,'decision'=>$d['decision'],'resolution'=>['reason'=>$d['reason']??null]]);return $request->expectsJson()?response()->json(['data'=>$record]):back()->with('status','Duplicate review resolved.');}
}
