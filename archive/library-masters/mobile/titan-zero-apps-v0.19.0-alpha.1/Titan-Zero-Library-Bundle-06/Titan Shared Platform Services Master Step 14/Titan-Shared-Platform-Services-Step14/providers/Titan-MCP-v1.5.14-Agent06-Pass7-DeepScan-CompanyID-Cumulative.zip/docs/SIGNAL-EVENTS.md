# Signal events

Titan MCP preserves trace/correlation/request identifiers in operation metadata and audit evidence. The extension does not require Titan Signal Engine to function; Signal integration is optional and must not increase mutation authority.
