<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Contracts;

interface CommandSignalEmitterContract
{
    public function available(): bool;
    public function emit(string $type, array $payload): void;
}
