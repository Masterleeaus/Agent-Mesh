# Interaction Engine Settings — v10.3.2

Phase 6.1/6.2 provide three intentionally separate settings scopes plus clean-boot security readiness and Super Admin navigation.

## Super Admin / platform


Super Admin navigation:

- **Interaction Engine → Overview**
- **Interaction Engine → Settings**

Routes:

- `GET /dashboard/admin/interaction-engine`
- `GET /dashboard/admin/interaction-engine/settings`
- `POST /dashboard/admin/interaction-engine/settings`

The existing MagicAI `admin` middleware protects both routes. Editable values are allowlisted and stored in `interaction_platform_settings`:

- engine enabled
- default presentation renderer
- LocalBrain enabled
- LocalBrain minimum confidence
- offline workflow support
- definition cache TTL
- fresh-authentication window
- sync batch size

Approval and outbox secrets are **status-only**. The screen never returns or persists secret values. A missing approval secret no longer prevents provider boot; approval-required actions remain disabled until `INTERACTION_APPROVAL_SECRET` is at least 16 characters. A missing outbox secret likewise leaves the provider bootable while encrypted offline queueing remains disabled.

The settings page also reports health and the current capability-provider support counts for CRM, Builder, Chatbot, Connect, Mobile and TitanAI.

## Company owner/admin

Routes:

- `GET /dashboard/user/interaction-engine/settings`
- `POST /dashboard/user/interaction-engine/settings/company`

Company writes require `owner` or `admin`. Values are scoped by canonical `company_id` in `interaction_company_settings`:

- company default renderer
- company interaction style
- LocalBrain availability
- offline workflow availability
- offline behavior
- progress visibility

These settings do **not** replace capability authority, AI authority, CRM business settings, Builder app settings, Chatbot settings or Connect credentials. Those remain governed configuration journeys owned by their respective extensions.

## Personal user preferences

Routes:

- `POST /dashboard/user/interaction-engine/settings/preferences`
- `GET /api/interaction-engine/v1/settings`
- `POST /api/interaction-engine/v1/settings/preferences`

Every authenticated actor may change only their own preferences under `company_id + user_id` in `interaction_user_preferences`:

- interaction style
- guidance detail
- local guidance preference
- offline preference
- progress visibility

A user cannot submit `company_id`, tenant identity, roles or authority values through the settings policy.

## PWA consumption

The settings API returns an `effective` presentation snapshot. Wizard API responses also include `presentation_preferences`, so Hub, Go, Command and Onboarding can consume one preference contract rather than maintaining separate settings engines.

Company-level API updates use:

- `POST /api/interaction-engine/v1/settings/company`

and remain owner/admin restricted.

## Runtime application

Persisted settings actively affect:

- `ExtensionState` engine enable/disable checks
- definition cache TTL
- company offline workflow behavior
- offline sync batch size
- company LocalBrain availability
- LocalBrain escalation confidence threshold
- PWA/wizard presentation preferences
- fresh-authentication policy defaults on container/provider boot

The fresh-authentication policy is registered during Laravel container boot; long-running workers should be reloaded after changing that value.
