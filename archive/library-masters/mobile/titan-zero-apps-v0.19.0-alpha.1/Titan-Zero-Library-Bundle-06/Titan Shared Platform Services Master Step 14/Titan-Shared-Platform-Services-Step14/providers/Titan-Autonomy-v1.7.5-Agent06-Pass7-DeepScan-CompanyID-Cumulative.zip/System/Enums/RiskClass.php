<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Enums;

enum RiskClass: string
{
    case Low = 'low';
    case Medium = 'medium';
    case High = 'high';
    case Critical = 'critical';
}
