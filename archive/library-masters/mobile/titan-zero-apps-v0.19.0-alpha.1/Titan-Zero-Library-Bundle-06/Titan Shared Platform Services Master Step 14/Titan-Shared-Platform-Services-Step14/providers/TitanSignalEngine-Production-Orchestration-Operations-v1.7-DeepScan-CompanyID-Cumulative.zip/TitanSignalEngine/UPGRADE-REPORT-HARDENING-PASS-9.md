# Titan Signal Engine v0.17.0 — Production Hardening Pass 9

Pass 9 corrects Pulse projection freshness, command/receipt latency, global operational health and backpressure semantics.

## Added

- scoped/source Pulse freshness projection;
- per-command receipt latency projection;
- operational health snapshot projection and scheduler;
- current-vs-historical health classification;
- host and standalone regression coverage;
- additive migration `2026_08_18_000018_harden_pulse_health_correctness.php`.

## Upgrade notes

The new freshness projection starts warming as events are projected after upgrade. Existing immutable events and legacy Pulse rollups remain valid. The legacy one-command-per-trace latency fields are retained for compatibility but are not authoritative once `titan_signal_pulse_command_receipts` exists.
