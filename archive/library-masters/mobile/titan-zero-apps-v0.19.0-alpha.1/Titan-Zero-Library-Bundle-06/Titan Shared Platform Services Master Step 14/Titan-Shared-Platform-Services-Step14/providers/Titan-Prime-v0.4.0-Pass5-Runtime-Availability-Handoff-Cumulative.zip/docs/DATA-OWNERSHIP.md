# Data Ownership

Prime canonically owns only Prime strategic state: missions, objectives, proposals, decisions, checkpoints, delegation intent and outcomes.

v0.3.0 owns these physical tables:

- `titan_prime_missions` — durable Prime mission state
- `titan_prime_mission_operations` — tenant-scoped idempotency receipts for Prime mission writes

The mission operation table is operational metadata, not a business-domain source of truth. Its receipts expire after the configured idempotency TTL.

Prime must not become the source of truth for CRM, workforce, finance, scheduling or other business-domain entities, and it must not own Risk, Assurance, Autonomy, Command Bus, Signal, Rewind, Wisdom, Knowledge Authority or Model Council state.
