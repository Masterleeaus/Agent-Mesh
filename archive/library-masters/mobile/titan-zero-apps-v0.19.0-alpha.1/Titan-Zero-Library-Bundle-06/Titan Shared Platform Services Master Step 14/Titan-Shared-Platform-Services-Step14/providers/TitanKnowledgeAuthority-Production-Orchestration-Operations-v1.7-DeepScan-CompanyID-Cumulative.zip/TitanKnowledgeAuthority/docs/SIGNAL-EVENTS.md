# Signal Events
No Signal events are emitted in this pass. Future observations may include source checked, refresh failed, stale source, version created/superseded, claim changed, contradiction detected/resolved, applicability changed, and compliance drift detected. Signal observations must never directly mutate business state.
