<?php

declare(strict_types=1);
$root=dirname(__DIR__);
require_once $root.'/System/Host/TitanExistingInstallUpgradePreflight.php';
use App\Extensions\TitanGovernance\System\Host\TitanExistingInstallUpgradePreflight;
$installed=[];
if(isset($argv[1])){
 $raw=is_file($argv[1])?(string)file_get_contents($argv[1]):$argv[1];
 $decoded=json_decode($raw,true); if(is_array($decoded))$installed=$decoded;
}
$result=(new TitanExistingInstallUpgradePreflight())->inspect($root,$installed);
echo json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES).PHP_EOL;
exit(($result['status']??'FAIL')==='PASS'?0:1);
