<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Controllers;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Policies\ChannelAccessPolicy;
use App\Extensions\TitanConnect\System\Services\ConnectionDiagnosticsService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class DiagnosticsController extends Controller
{
    public function __construct(
        private readonly CompanyContext $context,
        private readonly ChannelAccessPolicy $policy,
    ) {
    }

    public function index(Request $request, ConnectionDiagnosticsService $diagnostics): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $connections = ChannelConnection::query()
            ->forCompany($companyId)
            ->whereHas('members', fn ($query) => $query->where('company_id', $companyId)->where('user_id', $actorId)->whereNull('left_at')->whereIn('role', ['owner', 'admin']))
            ->orderBy('provider')->orderBy('display_name')->limit(5000)->get();

        return response()->json(['data' => $connections->map(fn (ChannelConnection $connection) => $diagnostics->inspect($connection))->values()]);
    }

    public function show(Request $request, ChannelConnection $connection, ConnectionDiagnosticsService $diagnostics): JsonResponse
    {
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        abort_unless((int) $connection->company_id === $companyId, 404);
        abort_unless($this->policy->canManage($connection, $actorId), 403);

        return response()->json(['data' => $diagnostics->inspect($connection)]);
    }
}
