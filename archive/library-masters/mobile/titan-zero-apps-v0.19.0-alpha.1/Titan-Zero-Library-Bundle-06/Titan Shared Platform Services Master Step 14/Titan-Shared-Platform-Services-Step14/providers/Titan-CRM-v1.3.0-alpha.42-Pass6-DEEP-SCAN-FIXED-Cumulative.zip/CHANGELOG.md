# 1.3.0-alpha.40 — Agent-01 Pass 3

- Added canonical cross-extension execution envelope, correlation/causation, idempotency scope, authority/provenance/evidence traceability, duplicate suppression and deferred unknown-outcome semantics.

## v1.3.0-alpha.36 — Installer Hotfix 2

Fixes Laravel 10 migration failure in customer identity authority backfill by adding deterministic ordering before Query Builder `each()`. Adds a permanent migration iteration regression contract and documents restart-safe recovery after a partially applied MySQL migration. See `CHANGELOG_v1.3.0_ALPHA36_INSTALLER_HOTFIX2.md`.

## v1.3.0-alpha.36 — Canonical Company Tenancy & Self-Healing Hardening

CRM Core now uses `company_id` as its canonical tenant boundary. Contact/deal customer relationships move to `customer_company_id`; pipeline stages are company-scoped; company-level upserts no longer split identity by actor; fresh installs guard extracted payment tables; 40 obsolete CRM navigation keys self-retire; and production readiness blocks until strict host CRM Gates are configured. See `CHANGELOG_v1.3.0_ALPHA36_CANONICAL_COMPANY_TENANCY.md`.

## v1.3.0-alpha.35 — Performance & Scale Certification

Evidence-driven scale hardening: batched projection writes, indexed projection search, bounded timeline/pipeline/detail reads, SQL forecast/analytics/receivables aggregation, batched import staging, composite indexes, package synthetic 10k/100k/1m working-set benchmark, and read-only installed-host performance certification tooling. No partitioning introduced.

## v1.3.0-alpha.34 — Observability, Reliability & Operations

Structured operational metrics, PASS/WARN/BLOCK production health, `crm:doctor`, durable duplicate replay telemetry and recovery runbooks over existing CRM journals/outboxes.

## v1.3.0-alpha.32 — Read Architecture & Search v2

Projection-only AI/search reads, versioned CQRS definitions, incremental checkpoints, projection dead letters and freshness SLAs.

# Titan CRM Core v1.3.0-alpha.29 — Commercial Contract Engine

## Added
- Immutable issued proposal/estimate commercial snapshots with deterministic SHA-256 contract hashes.
- Revision roots/numbers, predecessor/successor lineage and governed supersession.
- Forensic acceptance evidence bound to the exact issued snapshot.
- Durable asynchronous PDF render queue, worker command, retries and output hashes.
- Governed quote revise/withdraw/revision-history and document render request/status capabilities.

## Hardened
- Issued quote/estimate commercial state cannot be reissued in-place; material changes require a new revision.
- Outbound sales-document email waits for a ready immutable render artifact rather than rendering synchronously.
- Pre-alpha.29 issued/accepted records are conservatively backfilled and legacy acceptance is explicitly identified rather than fabricated.

---

# Titan CRM Core v1.3.0-alpha.28 — Customer & Organisation Authority v2

## Added
- Stable `customer_unification_id` roots for companies, contacts, and leads.
- Tenant-scoped normalized email/phone identity ledger.
- External identity ledger for Chatbot, Titan Hub/Mobile, email and other configured channels.
- Blocking duplicate-review workflow with operator resolution and evidence fingerprints.
- Duplicate decisions automatically reopen when material identity evidence changes.
- Non-mutating merge preview and immutable merge evidence with Rewind rollback references.
- Governed identity resolve/link, duplicate review search/resolve and merge-preview capabilities.
- `organization_summary` CQRS projection and root identifiers in bounded customer projections.
- Production health checks for missing identity roots and unresolved blocking duplicate reviews.

## Lead conversion hardening
- Strong identity matches are reviewed before conversion instead of silently creating duplicate customers.
- Resolved `use_existing` decisions reuse the authoritative customer root.
- Lead notes and tags are preserved.
- Custom fields are mapped by semantic field key into target-specific company/contact definitions.
- `conversion_map` records exact source/target field lineage, customer root, reuse decision and copied metadata.

## Fixed
- Missing email/phone values no longer count as duplicate-score matches.
- Ambiguous Chatbot/email identity matches fail closed instead of selecting the first row.
- Contacts pointing at deleted organisations are repaired during governed lead conversion.

---

# Titan CRM Core Changelog

## 1.3.0-alpha.27 — Commercial Domain Boundary

- Completed post-extraction commercial-domain boundary audit.
- Removed active Field/Locker/Ledger/Pay/FinanceAssistant runtime residue and dormant external Interaction definitions.
- CRM Core now advertises customer/sales/commercial behavior only; legacy external capabilities are centralized compatibility routes with explicit external ownership.
- Fresh CRM Core installs no longer create Titan Pay payment/allocation tables or Titan Field mobile/sync tables.
- See `CHANGELOG_v1.3.0_ALPHA27_COMMERCIAL_DOMAIN_BOUNDARY.md` and `docs/CRM-CORE-ALPHA27-DOMAIN-BOUNDARY-AUDIT.md`.

## 1.3.0-alpha.26 — Autonomy De-ownership

CRM Core no longer owns autonomy, learning, proactive execution or cross-domain planning. Runtime ownership is consolidated into Titan Autonomy, Titan AI Core, Titan AI Workforce and Titan Wisdom; CRM keeps only a fail-closed external authority port.

# CRM 1.3.0-alpha.23 — Scheduling, Jobs & Field Integrity

Centralizes field scheduling constraints in a canonical SchedulingKernel, requires deterministic evidence/form snapshots before governed work-order completion, hardens recurring occurrence generation with a locked watermark, derives idempotent labour invoice lines from field time entries, and routes Titan Go reconnect mutations through the same governed CRM Command Bus capabilities used online. Field child mutations now advance the work-order aggregate revision, offline evidence must be SHA-256-backed, dispatch catch-up follows legal lifecycle steps, and same-state retries are true no-ops.

# CRM 1.3.0-alpha.22 — CQRS Read Store + Titan Go Delta Sync

Adds a portable CQRS projection store for AI/selected dashboard reads, event-driven projection refresh, deterministic rebuild/status capabilities and signed tenant/worker Titan Go delta-sync tokens with tombstones while preserving CRM as authoritative operational truth.

# CRM 1.3.0-alpha.21 — Integrity & Governance Hardening

Adds explicit AI read projections, tenant-reference guards, provider-payment replay safety, receipt/concurrency v2, reliable deduplicated Signal delivery, governed automation routing, write rate limiting and staged atomic import integrity while preserving the alpha.20 Titan Connect boundary.

# CRM 1.3.0-alpha.20 — Outbound Effect Safety + Titan Connect Boundary

Moves invoice email/reminder provider calls out of authoritative CRM transactions, adds a tenant-idempotent traced communication outbox, provider/delivery receipts, bounded post-commit delivery, and a replaceable Titan Connect execution port. CRM command acceptance is now explicitly distinct from real-world delivery.

# CRM 1.3.0-alpha.19 — Governed Business OS Boundary

Makes CRM the authoritative operational truth behind a governed Command Bus boundary, adds traceable authoritative receipts, optimistic entity versions, invariant checks, a transactional Titan Signal outbox, Rewind references, and a bounded tenant-scoped AI read model while preserving existing CRM functionality and installer compatibility.

# CRM 1.3.0-alpha.18 — Host Panel Layout Runtime Hotfix

Fixes the live `View [panel.layout.app] not found` HTTP 500 by adding a non-overriding MagicAI default panel-view fallback in the CRM provider, covering all 56 CRM views that inherit the host dashboard shell without modifying MagicAI core.

# CRM 1.3.0-alpha.17 — Context-Aware Global + New

Repurposes MagicAI's existing top-right `+ New` control on CRM operations pages into a permission-filtered primary Interaction Engine journey plus related dropdown actions, with record-aware prefill and no MagicAI core modification.

# CRM 1.3.0-alpha.16 — Autonomous Operations Control + Contextual Titan Command Bar

Alpha.16 adds the large page-aware Titan command bar, quick prompts on all internal operations pages, Autonomy Control Center, bounded cross-domain plans, Exception Inbox, simulation, scoped pause controls and run ledger.

# CRM 1.3.0-alpha.15 — Proactive Intelligence + Earned Autonomy

Adds the five-position **Suggest → Assist → Semi-Auto → Auto → Trusted Auto** slider backed by capability/workflow-specific evidence gates, consecutive-success streaks, platform risk ceilings, three-way Platform + User + TitanAI/Assurance approval for Auto/Trusted Auto, automatic regression, Titan Learning, proactive operational recommendations and closed-loop Auto execution through Interaction Engine/CommandBus only when the exact workflow has earned authority.

# CRM 1.3.0-alpha.14 — Operations Assistant + AI-First Page Layout

Replaces the empty/info-only CRM Assistant page with MagicAI's host-native CRM chat container, aligns the Assistant URL with `/dashboard/user/crm/assistant`, wires the canonical Operations Assistant prompt/service to Titan's CRM operations and Interaction Engine, and moves the shared Titan Zero chatbot bar above the bold page title on every internal CRM page.

# CRM 1.3.0-alpha.13 — Forecast Runtime Contract Hotfix

Fixes the CRM Overview and Reports HTTP 500 caused by `CrmViewDataService` calling undefined `CrmForecastService::summary()`. Both callers now use the canonical `summarize()` API. Adds a release regression gate for the forecast contract.

# CRM 1.3.0-alpha.12 — Conversational Operations

CRM Interaction-first workflows now extend beyond creation into existing-record updates, lifecycle actions, explicit multi-step business chains and preview-first bulk operations. Titan Zero can act contextually on the record being viewed, and allowlisted autonomous workflows dispatch through Interaction Engine CommandBus after validation. Approval-required actions cannot be self-approved by AI. Bulk operations require an explicit tenant-scoped selection, preview and confirmation.

# CRM 1.3.0-alpha.11 — Interaction-First Business OS

## Interaction Engine becomes the primary CRM interaction layer

CRM now treats Titan Interaction Engine `>=10.3.1 <11.0` as the primary structured interaction runtime for create workflows while CRM remains the authoritative business-record system.

Every major internal CRM page uses one shared interaction shell with:

- page title and context
- contextual Titan Zero AI command bar
- a standard `New ...` action where the page owns a creatable business record
- consistent list/manage content
- Interaction Engine wizard execution
- Advanced-form fallback where a mature direct form already exists

## Conversational execution

Titan Zero can resolve a plain-English request to a CRM journey, start an Interaction Engine session, prefill known page/record context, answer wizard steps and prepare governed execution.

AI does not bypass Interaction Engine authority. Approval-required actions cannot be self-approved by the conversational AI service.

Authority modes are:

- `assist`
- `approval`
- `autonomous`

The autonomous mode is bounded by an explicit capability allowlist. High-consequence actions such as jobs, quotes, invoices, payments, bookkeeping transactions, purchasing and stock-control mutations remain approval-gated by default.

## CRM-owned primary journeys

The Interaction Engine donor wizards for customer/job/quote/invoice did not exactly match CRM service contracts, so alpha.11 supplies CRM-owned definitions for:

- New Customer
- New Job
- New Quote
- New Invoice

The definitions use CRM public IDs, required work-order fields and deterministic sales `lines` payloads. Financial totals are still calculated by CRM's deterministic sales/Financial Assistant services rather than by AI.

## Journey coverage

Interaction journeys now cover core business creation across:

- Customers and contacts
- Leads, opportunities and pipelines
- Quotes and estimates
- Jobs, service requests, projects and tasks
- Calendar events, appointments and dispatch assignments
- Time entries
- Services, service locations and recurring work
- Forms, customer assets and service areas
- Support cases and Customer Hub access
- Invoices, payments and bookkeeping transactions
- Automations
- Inventory, locations, reservations and reorder rules
- Suppliers and purchasing
- Goods receipts, stock counts and stock transfers
- Tools, equipment, vehicles and maintenance
- Tags and custom fields
- API keys and webhooks
- CRM record sharing

## Consistent page UX

Default inline create forms have been removed from major list/manage pages. Creation now starts from the standard New action or Titan Zero conversation.

Record details and Advanced forms retain the same AI command surface and pass record context such as customer, contact, job and financial-document public IDs into new Interaction sessions.

Customer-facing Customer Hub pages and generated PDF/email output remain outside the internal CRM AI shell.

## Compatibility

- CRM tenancy remains `tenant_company_id`.
- CRM `company_id` remains customer/account relationship data.
- WorkCore remains donor-only and is not a runtime dependency.
- Standalone Titan Financial Engine remains unnecessary.
- Existing alpha.10 navigation, alpha.9 route-cache recovery and alpha.8 icon safety are preserved.
- Titan Hub, Titan Go and Titan BOS clean identities remain preserved.

# CRM 1.3.0-alpha.10 — Core Menu Completeness

- Renames the CRM settings child to **Settings**.
- Removes ampersands from CRM menu labels so MagicAI themes do not render encoded menu text.
- Expands the core business sidebar with Receivables, Collections, Timesheets, Inventory, Stock Locations, Stock Control, Stock Reservations, Reorder, Suppliers, Tools, Equipment, Fleet Manager, Maintenance and Chatbot Integration.
- Adds dedicated Gear UI routes for Purchase Orders, Goods Receipts, Stock Counts and Stock Transfers instead of using JSON read endpoints as menu destinations.
- Adds Stock Locations management and a Goods Receipts list to the Gear UI.
- Calls MagicAI `MenuService::regenerate()` after CRM menu sync so upgraded navigation is visible immediately.
- Preserves alpha.9 route-cache recovery, alpha.8 icon safety, Titan Mobile identities and all Financial AI functionality.

# CRM 1.3.0-alpha.9 — Route Cache / Menu Link Hotfix

- Repairs CRM named routes when Titan/MagicAI is running a route cache generated before CRM installation/update.
- Restores normal same-tab internal navigation without hard-coding dashboard URLs.
- Preserves alpha.8 icon compatibility and all alpha.7 Mobile + Financial AI functionality.

# CRM 1.3.0-alpha.8 — Menu Icon Compatibility Hotfix

- Repairs unsupported CRM menu icon components on Titan/MagicAI hosts.
- Preserves alpha.7 Mobile Suite + AI Financial Assistants.

# CRM 1.3.0-alpha.7 — Mobile Suite & AI Financial Assistants

## Titan Mobile clean identities

CRM now targets the clean mobile-suite technical contracts:

- `TitanHub` — customer app / Customer Hub
- `TitanGo` — field/worker app
- `TitanBOS` — owner/business app

Legacy runtime contract references to `TitanCustomer`, `TitanFieldOffline` and `TitanOwnerPWA` were removed from the active Titan Mobile integration layer. Titan Mobile compatibility is now `>=0.20 <1.0`.

## CRM-native Financial Assistants

The deterministic Titan Financial Engine has been absorbed into CRM. CRM does not depend on the standalone Financial Engine extension at runtime.

Seventeen deterministic calculators are available:

1. Formula Rules
2. Labour Rate
3. Procurement / Landed Cost
4. Inventory / Materials Cost
5. Asset / Fleet / Equipment Cost
6. Job Costing
7. Pricing
8. Quote & Estimate
9. Discount / Promotion
10. Margin & Profitability
11. Tax / GST
12. Recurring Pricing
13. Payment / Settlement Cost
14. Commission / Incentive
15. Finance / Instalment
16. Cash Flow Forecast
17. Break-Even Scenario

All authoritative financial arithmetic stays in deterministic CRM calculators using the donor engine's fixed-point/decimal rules.

## AI guidance boundary

MagicAI/TitanAI is the guidance and orchestration layer. It may:

- interpret plain-English intent
- inspect permitted CRM context
- gather known customer/job/material/time facts
- identify missing inputs
- ask follow-up questions
- compare scenarios
- explain margin, tax and cost drivers
- recommend values

AI must not invent authoritative financial results. Tax/GST, price, margin, labour, material, landed-cost, instalment, cash-flow and break-even numbers are produced by the deterministic calculators.

Read-only calculations can be returned directly. Applying recommendations to CRM records remains a governed write and follows the existing approval flow.

## Embedded Quote / Estimate Assistant

Quote and estimate creation now includes an embedded **Financial AI Assistant**. It can use known CRM/Gear job-material context, recorded job time, labour/material/equipment/travel/other cost inputs, target margin and GST rate to produce:

- cost base
- suggested pre-tax sell price
- margin check
- GST/tax amount
- customer total

The result can be applied to the first unsaved quote line only; the normal CRM form must still be reviewed and saved by the user.

The same panel links into the CRM Assistant with a finance-specific scope so AI can help gather missing facts and explain the result.

## Contextual assistants

Financial AI entry points now appear contextually rather than as 17 permanent menu items:

- **Leads / Quotes:** Quote, Pricing, Margin, Discount, GST, Labour, Materials
- **Work:** Job Costing, Profitability, Labour, Materials, Asset/Fleet/Equipment
- **Money:** GST, Payment Fees, Instalments, Cash Flow, Break-Even
- **Crew:** Labour Rate, Commission/Incentive
- **Gear:** Materials Cost, Landed Cost, Asset/Fleet/Equipment Cost

## Field & home service terminology

Current user-facing navigation now uses:

- Sales → **Leads**
- Deals → **Opportunities**
- Proposals → **Quotes**
- Work Orders → **Jobs**
- Customer Portal → **Customer Hub**

Stable route/table identifiers are intentionally retained where renaming them would create migration risk. Migration `000022` refreshes existing host menu rows during upgrade.

## Safety / compatibility

- Tenant boundary remains `tenant_company_id`.
- CRM `company_id` remains the customer/account company relationship.
- AI financial calculation capabilities are read-only.
- No `TitanFinancialEngine` runtime dependency remains.
- No legacy Titan Mobile technical namespace remains in active Titan Mobile integration code.
- Existing alpha.3 provider-stage protection and alpha.4/alpha.5/alpha.6 MySQL/restartability protections are preserved.

---

# CRM 1.3.0-alpha.6 — Core Navigation, Theme Integration & Runtime Schema Hotfix

## Runtime fixes
- Removed invalid `deleted_at` filtering from `crm_activities` reads in the dashboard overview, timeline service, and Chatbot activity projection. `crm_activities` is an immutable activity stream and does not define a `deleted_at` column.
- Corrected the contacts list tenant filter from actor `user_id` to the CRM business boundary `tenant_company_id`.

## Core business navigation
CRM is now presented as the Titan business core instead of one oversized CRM dropdown.

Top-level user navigation order:
1. Overview
2. Customers
3. Sales
4. Work
5. Money
6. Crew
7. Gear
8. Insights
9. Automate
10. Settings

The existing `ext_crm_dropdown` and `ext_sales_dropdown` keys are retained and relabelled to **Customers** and **Money** so current host/plan integrations do not lose those established keys.

Menu registration now runs in an additive migration through an adaptive `CrmMenuInstaller`, because Titan executes extension migrations during installation whereas the old `CrmMenuSeeder` was not guaranteed to run. The installer only writes menu columns that exist on the host and reuses existing child keys so upgrades move links rather than duplicate them.

## Theme integration
- Removed fixed success/danger/warning/info button palette classes from CRM Blade views.
- Primary actions now use the host theme's primary button treatment.
- Secondary/destructive actions use theme-controlled outline styling plus confirmation/state semantics instead of fixed colours.
- Removed the standalone customer portal's hard-coded dark button background; portal buttons now inherit their surrounding theme/text treatment.

## Regression gates
Added:
- `bin/verify-v130-alpha6-runtime-schema.php`
- `bin/verify-v130-alpha6-navigation.php`
- `bin/verify-v130-alpha6-theme-buttons.php`

These prevent recurrence of the missing `deleted_at` query, actor/tenant contact scoping bug, missing domain menu parents, invalid menu routes, duplicate legacy Dashboard link, and hard-coded CRM button palette classes.

# CRM 1.3.0-alpha.5 — Locker Purchasing & Stock Control

## Added
- CRM-native supplier enrichment and supplier quality/delivery/service ratings.
- Purchase orders with draft, submitted, approved, partially received, received and cancelled lifecycle states.
- Integer-minor-unit purchase totals with separate GST calculation.
- Partial and full goods receipt linked to purchase-order lines.
- Goods receipt posts immutable Locker stock receipt movements with supplier, PO and receipt provenance.
- Stock counts/cycle counts with expected quantity snapshots, physical counts, variance capture and optional adjustment posting.
- Requested → in-transit → received stock transfer workflow; dispatch removes source stock and receipt adds destination stock.
- Reorder-suggestion → draft purchase-order handoff grouped by preferred supplier and delivery location.
- Supplier, purchasing, stock-count and transfer owner/API surfaces and governed CRM capabilities.

## Safety
- Nine new supply-chain tables use `tenant_company_id`.
- Every new table creation is restart-safe with `Schema::hasTable()`.
- New MySQL index names are explicit and <=64 characters.
- New required date-times use DATETIME semantics rather than implicit-default TIMESTAMP.
- Purchase orders, receipts, counts and transfers support retry/idempotency where appropriate.
- Duplicate receipt/count/transfer lines are rejected at the domain-service layer.
- No WorkCore runtime/provider/table dependency was introduced.

## Accounting boundary
Goods receipt records inventory purchase cost but does not automatically create a cash-bookkeeping expense. Supplier payment/settlement remains a future Pay/Bookkeeping event, avoiding accidental accrual accounting in CRM Simple Bookkeeping.


---

# CRM 1.3.0-alpha.4 — MySQL Migration Recovery + WorkCore Donor Intelligence

## Installer / migration fixes

- Repaired MySQL error 1059 caused by Laravel's generated index name `crm_service_recovery_cases_rebooking_service_request_public_id_index` exceeding MySQL's 64-character identifier limit.
- The service-recovery rebooking index now uses the explicit name `crm_recovery_rebook_req_idx`.
- Made all 29 table creations in migration `2026_08_09_000011_add_field_service_domains.php` restart-safe with `Schema::hasTable()` guards.
- Added targeted partial-DDL recovery for `crm_service_recovery_cases`: if the table exists from the failed alpha.3 run but the short index is absent, the migration creates the index through `information_schema.statistics` detection.
- Added permanent regression gates for MySQL identifier lengths, migration 000011 restartability and partial-index recovery.

## WorkCore donor code adapted into CRM

The following domain-pure WorkCore algorithms were transplanted into CRM namespaces. No WorkCore provider, tenancy resolver, runtime dependency, `tz_*` table or `tm_*` table is used.

### Titan Pay

- Integer minor-unit `Money` and validated `CurrencyCode` value objects.
- Bank-deposit-to-receivable ranking with explainable confidence scoring for exact amount, near amount, payment reference, payer hint, timing and duplicate evidence.
- Collection suppression decisions for paid, disputed, payment-plan, pending-payment-claim, paused, voided, credited and active promise-to-pay cases.
- Job profitability calculation covering revenue, labour, materials, other direct costs, total cost, profit and margin basis points.
- Governed calculation capabilities:
  - `crm.pay.reconciliation.rank`
  - `crm.pay.collection.suppression.evaluate`
  - `crm.pay.job_profitability.calculate`

### Titan Locker

- WorkCore-derived inventory quantity policy adapted to Locker reservation semantics.
- WorkCore-derived stock movement policy adapted to CRM Locker movement names and location rules.
- Allocation and stock movement services now consume those focused policies rather than duplicating validation logic.

## Scope

Alpha.4 deliberately does not add the schema-heavy WorkCore purchasing/PO/stock-count donor modules. Those are reserved for the next pass after the repaired live migration chain is confirmed on the Titan host.

---

# CRM 1.3.0-alpha.3 — Titan Installer Provider Hotfix

## Fixed

- Fixed Titan Extension Manager provider-stage failure when CRM is registered into an already-booted Laravel application.
- Root CRM repository contracts are now bound before focused subproviders are registered.
- `CrmFinanceLockerServiceProvider` no longer eagerly constructs Pay/Locker/Bookkeeping domain services during `boot()`. Capability handlers resolve their domain services lazily when invoked.
- Added `bin/verify-provider-install-safety.php` to prevent regression of provider registration order or eager `JobBillingService` resolution.

## Root cause

Titan Extension Manager loads the extension provider before running migrations. In an already-booted Laravel application, `Application::register()` can immediately boot a newly registered provider. CRM alpha.2 registered `CrmFinanceLockerServiceProvider` before binding `SalesDocumentRepositoryContract`; the subprovider booted immediately and attempted to construct `JobBillingService`, producing a `BindingResolutionException`.

## Database impact

None. The reported alpha.2 failure occurred at the provider stage before migration execution. This hotfix adds no migration and changes no data schema.

---

# CRM 1.3.0-alpha.2 — Titan Locker Operations

- Activated stock reservations, availability, fulfil/release and reorder suggestions.
- Added audited tool custody and fleet operations.
- Added due/overdue/cancel/next-service maintenance workflows.
- Hardened all negative stock movement paths to respect active reservations.
- Routed allocation fulfilment through work-order materials to preserve Pay/job-cost projection.

# MagicAI CRM 1.3.0-alpha.1 — Pay, Locker and Simple Bookkeeping Phase 1

This alpha begins the CRM 1.3 domain expansion while preserving CRM as the single installable business core.

## Added: Simple Bookkeeping

- Tenant-scoped income and expense categories.
- Manual income and expense records using integer minor-unit money values.
- Australian GST inclusive, exclusive and GST-free calculations with 10% default.
- Cash-basis bookkeeping overview, GST summary, P&L and cash movement reporting.
- Existing CRM payment allocations are recognized as sales cash receipts rather than duplicated into bookkeeping rows.
- Completed Pay refunds reduce recognized cash-basis revenue and GST collected.
- Australian July-to-June financial-year helper.

## Added: Titan Pay domain family

- Payment-rail preferences and ordering for Cash, PayID, bank transfer and card.
- Invoice-bound payment intents and hash-only secure checkout-link tokens.
- Titan Collect cases, reminders/events, promise-to-pay fields and AR aging.
- Schema foundations for deposits, payment plans/installments, refunds, disputes and receipts.
- Job billing service that projects CRM work-order services and Locker material consumption into draft CRM invoices using source keys to prevent duplicate lines.
- Existing CRM invoices, payments and allocations remain authoritative commercial/payment records.

## Added: Titan Locker domain family

- Inventory/consumables/parts with SKU, barcode/QR, cost, sale price and costing-method metadata.
- Warehouse, van, site and technician/worker stock locations.
- Stock receipt, adjustment, consumption, disposal and transfer movement ledger.
- Negative-stock protection with item-level database locking for concurrent consumption/transfer operations.
- Job material consumption linked to existing CRM work orders and `crm_work_order_materials`.
- Suppliers, stock allocations, reorder-rule schema and costing metadata.
- Tools, equipment, fleet vehicles, maintenance records and asset lifecycle events.
- Asset acquisition/current-value, warranty, service and depreciation metadata foundations.

## Cross-domain loop

`Titan Go job → Locker consumption → CRM work-order material → Pay draft invoice → CRM payment/allocation → Bookkeeping/reporting`

All new business-owned data uses `tenant_company_id`. CRM customer/account `company_id` remains separate and user IDs remain actor/assignee/provenance identifiers.

## Installer/database hardening

- Four additive/reversible migrations: `000015` through `000018`.
- Twenty-four new CRM-owned tables are company-tenant scoped and guarded for restart-safe creation.
- Cross-domain alterations are guarded with table/column existence checks.
- New required operational times use MySQL strict-mode-safe date/datetime patterns rather than implicit-default required timestamps.
- New static verification gates cover domain presence, migration safety, capability bindings and GST calculations.

## Alpha scope intentionally not complete

The following domain-family areas are represented by schema/foundations but are not yet full end-user workflows in alpha.1:

- live ZeroPay/PayID/bank provider orchestration and public Titan Hub checkout completion flow
- deposit application workflow
- payment-plan collection engine
- full refund/dispute provider workflows and receipt delivery
- Locker allocation/reservation workflow
- reorder suggestion/purchasing workflow
- tool checkout/return/custody workflow
- detailed fleet assignment workflow
- authoritative FIFO/LIFO/weighted-average cost-layer engine
- depreciation calculation/posting engine

Those are follow-on CRM 1.3 implementation slices rather than separate extensions.

---

# MagicAI CRM 1.2.2 — MySQL Migration Compatibility Hotfix

- Replaces required application-supplied `TIMESTAMP NOT NULL` migration columns with `DATETIME NOT NULL` so MySQL/MariaDB installations using legacy timestamp-default behaviour plus strict/NO_ZERO_DATE modes do not synthesize an invalid zero-date default.
- Fixes the reported `crm_portal_grants.expires_at` install failure without making expiry nullable or assigning a misleading default.
- Applies the same compatibility rule to later required CRM time columns so installation does not simply fail at the next migration.
- Makes migration `2026_08_09_000008_add_crm_automation_portal_import_hardening.php` restart-safe after partial MySQL DDL execution by skipping CRM-owned tables already created by the failed attempt.
- Adds regression gates for required time-column compatibility and migration-000008 restartability.

## Recovery from failed 1.2.1 install

Reinstall/upgrade with 1.2.2. Do not manually delete `crm_automation_rules` or `crm_automation_runs`: the patched migration detects and preserves those successfully-created tables, then resumes with the remaining tables.

---

# MagicAI CRM 1.2.1 — Titan Installer Packaging

- Preserves the official MagicAI CRM identity: `crm` / `Crm` / `App\Extensions\Crm\System\CrmServiceProvider`.
- Normalizes the root package manifest to `titan-extension-v1`.
- Aligns release metadata to semantic version `1.2.1`.
- Replaces the shared `extension` publish tag with `crm-config`.
- Adds current Titan platform requirements and a production SHA-256 integrity map.
- Regenerates package file integrity metadata and installer verification.
- Does not activate or alter CRM business-domain behavior as part of this packaging pass.

# Changelog

## v1.3.0-alpha.29 — Commercial Contract Engine

- Added immutable issued quote/estimate snapshots, revision/supersession chains and forensic acceptance evidence.
- Added durable asynchronous commercial-document rendering and governed render request/status capabilities.
- Backfills pre-alpha.29 issued/accepted commercial records conservatively without inventing customer-session evidence.


## 1.2.0 — Company Tenancy + Titan Platform Integration + Field/Home Services Contracts
- Replaced CRM tenant authority with `tenant_company_id`; CRM account `company_id` remains separate and actor user IDs remain people.
- Added deterministic 1.1 tenancy backfill/review audit plus migration of legacy user-scoped unique constraints.
- Added fail-closed company context, scoping and authorization gateway.
- Implemented exact Titan Go v0.13 offline source contract including `snapshot()`, idempotency and revision conflicts.
- Added Titan Hub and Titan Command gateways/actions with customer/worker/company isolation.
- Added governed CRM capability registry, TitanAI tool provider and Interaction Engine handler.
- Source-certified Chatbot 6.5 while retaining 6.4 compatibility.
- Added draft/approval/materialisation business configuration capabilities for future Titan Onboarding.
- Completed the ten canonical Field/Home Services vertical packs and retained valid additional packs.
- Confirmed WorkCore is not part of the target runtime architecture.

## 1.1.0-rc1 — Field & Home Services operational CRM
- Made CRM the standalone operational authority for field/home-service workflows; WorkCore remains donor source only.
- Added 30 CRM-native field-service persistence tables across catalogue, locations, service requests, customer assets, work orders, scheduling, dispatch, recurring services, forms, evidence, service areas, support, reviews/recovery, history and installed vertical profiles.
- Added work-order lifecycle governance, required-task/form completion gates, time/material capture and private tenant-validated evidence storage.
- Added appointment and dispatch lifecycles plus CRM-authoritative Titan Go mutations for CRM-owned work orders with fallback delegation for legacy/non-CRM entities.
- Added recurring service agreements, activation/pause lifecycle, idempotent occurrence generation and `crm:field-services:generate-recurring`.
- Added postcode/radius/polygon serviceability, support tickets, reviews, low-rating recovery and rebooking.
- Added WorkCore-derived CRM-native profiles for field-services core, Cleaning, Plumbing, Electrical, Gardening, Handyman and Pressure Washing.
- Added idempotent vertical-profile installation with namespaced service keys so multiple verticals can coexist without catalogue collisions while preserving user pricing on re-apply.
- Expanded Chatbot customer-safe tools, Titan Customer/Owner surfaces and AI Agent field-service tools.
- Added field-service automation triggers/actions and field-service analytics.
- Added operational browser surfaces for verticals, work-order detail, task/time/material/evidence capture, form publishing and service-area management.
- Preserved zero `App\\Domains\\WorkCore` and zero `tz_*` runtime dependencies.

## 1.0.0-rc1 — Chatbot 6.4 + Titan Mobile 0.4.0 integration
- Added optional Chatbot 6.4 compatibility detection and fail-closed generator decoration for OpenAI, Anthropic and Gemini.
- Added a separate customer-safe CRM Chatbot tool catalogue with per-chatbot enablement and explicit per-tool selection.
- Added Chatbot customer identity synchronization, optional CRM contact/lead creation, channel attribution and selected conversation lifecycle projection.
- Added short-lived, hash-bound CRM Chatbot session grants issued only from currently verified Titan Customer sessions for private CRM reads and profile mutation.
- Added additive Titan Customer gateway decoration for CRM proposals, estimates, invoices and documents while preserving existing mobile data sources.
- Added permission-filtered Titan Owner CRM dashboard/search slices.
- Added read-only Titan Go CRM context enrichment while delegating all offline mutations and revision authority unchanged.
- Added per-chatbot CRM integration settings UI.
- Added source-contract certification against Chatbot 6.4 and Titan Mobile Ecosystem 0.4.0.
- Added regression coverage preventing matched-but-unverified visitors from reading private CRM data.
- Preserved zero WorkCore runtime dependency and avoided edits to MagicAI, Chatbot and Titan Mobile source.

## 0.9.0 — Huge integrations, privacy and hardening pass
- Added private customer-portal file exchange with hash journaling, MIME/size policy and pluggable malware-scanner hook.
- Added hash-only scoped API keys with expiry/revocation and redacted management responses.
- Added encrypted-secret HMAC webhooks, public-destination policy, DNS revalidation, redirect blocking, retry backoff and dead-letter state.
- Added email connection/message sync foundations using opaque credential references and CRM subject linking.
- Added actionable record sharing for grantees with scoped view/comment grants.
- Added encrypted privacy request plans/results and dry-run-first anonymize/delete workflows.
- Added retention policies with explicit confirmation for destructive actions and bounded maintenance commands.
- Added safe CSV mapping/transforms and spreadsheet-formula neutralisation.
- Added richer automation conditions/webhook actions and advanced source conversion, stage velocity, stale pipeline and sales-cycle analytics.
- Added granular route permission coverage across browser and internal API surfaces.
- No WorkCore runtime dependency was introduced.

## 0.8.0 — Huge pre-install capability pass
- Added standalone `AIAgentToolCrm` companion extension matching MagicAI Marketplace identity.
- Added permission catalog/service and permission-filtered AI tool execution.
- Added automation rules/runs with idempotent trigger fingerprints and scheduled overdue checks.
- Added hashed, expiring, revocable customer portal grants with scoped access events.
- Added import batch/row journal and rollback foundation.
- Added deterministic duplicate confidence scoring.
- Added richer CRM Assistant context builder and record reference resolver.
- No WorkCore runtime dependency was introduced.

# CRM Extension Changelog

## 0.7.0 — MagicAI 11 host-certified integration pass

- Certified exact provider, CRM Assistant service/signature, chat view, menu routes, entitlement hooks and contact-capture event against the supplied MagicAI 11.00 host source.
- Added CRM/Sales browser plan enforcement through MagicAI `CheckTemplateTypeAndPlan`.
- Added Passport API CRM/Sales entitlement middleware.
- Added direct-route enforcement for `crm_enabled`, `crm_assistant_enabled` and `crm_presentations_enabled`.
- Added admin host-settings bridge and migration for the three MagicAI CRM feature flags.
- Added exact MagicAI `<<<ACTIONS>>>...<<<END_ACTIONS>>>` assistant mutation proposal protocol and `crmAssistantActionCard` Alpine approval runtime.
- Added editable company/contact detail workflows and metadata management UI.
- Added proposal/estimate/invoice PDF generation and email-with-PDF delivery.
- Added notification outbox delivery foundation for email and in-app notifications.
- Added static host certification tooling and documented the MagicAI Marketplace archive layout.
- Corrected Marketplace packaging so extension files live at ZIP root; previous `Crm/`-wrapped archives were suitable for manual parent-folder extraction but not MagicAI's actual marketplace extraction logic.

## 0.4.0

- Added tenant-scoped notes, tags and custom fields.
- Added unified CRM timeline and dashboard/follow-up metrics.
- Added controlled proposal, estimate, invoice and payment lifecycles.
- Added deterministic sales-document line totals using integer minor units.
- Added partial payment allocation and invoice balance tracking.
- Expanded conservative CRM Assistant tool metadata with dashboard/timeline/sales reads and note creation.
- Preserved exact MagicAI CRM technical identity and standalone `crm_*` persistence.

## 0.3.0

- Added typed CRM models, validation, resources, forecast, bounded import/export, projects, tasks, calendar and sales-document foundations.

## 0.6.0 — Huge parity and hardening pass
- Added exact MagicAI v11 CRM Assistant service and chat-area view compatibility.
- Added ContactCapturedEvent listener integration.
- Added lead qualification/scoring and conversion UI.
- Added duplicate review/merge, merge logs, audit records and bounded bulk actions.
- Added CRM settings, notification outbox and analytics.
- Added functional project/task/calendar UI.
- Added drag/drop pipeline movement and deal close controls.
- Added sales lifecycle action controls and report trend/funnel views.
- Added browser import/export and expanded Assistant tools.

## 1.3.0-alpha.30 — Invoice & Receivables Authority
CRM now owns receivable truth without owning payment execution: immutable invoice contracts, quote/Field lineage, verified Titan Pay settlement references, credit notes, refund-due tracking, ageing and reconciliation issues.

## 1.3.0-alpha.31 — Command Contract v3
- Added command/receipt v3 evidence and exact Signal references.
- Added automated write-surface governance auditing.
- Governed privacy and retention mutation paths.

## 1.3.0-alpha.38 — Workforce / Blueprint v4.2.1 convergence
- Canonical Manifest v2.2 metadata.
- Role-neutral Titan AI Workforce integration contract; Workforce remains identity/role/work-item owner.
- Canonical active tenancy is `company_id`; legacy tenant key limited to compatibility/migration paths.
- Governed execution, provider provenance, fail-closed availability semantics and contract regression test.
