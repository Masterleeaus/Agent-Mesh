<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

final class CrmAuditRecorder
{
    public function __construct(private ConnectionInterface $db) {}

    public function record(int $userId, ?int $actorUserId, string $action, ?string $subjectType = null, ?string $subjectPublicId = null, ?array $before = null, ?array $after = null, array $context = []): void
    {
        $this->db->table('crm_audit_log')->insert([
            'public_id' => (string) Str::ulid(), 'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId), 'actor_user_id' => $actorUserId,
            'action' => $action, 'subject_type' => $subjectType, 'subject_public_id' => $subjectPublicId,
            'before' => $before === null ? null : json_encode($before), 'after' => $after === null ? null : json_encode($after),
            'context' => $context === [] ? null : json_encode($context), 'occurred_at' => now(),
        ]);
    }

    public function forSubject(int $userId, string $subjectType, string $subjectPublicId, int $limit = 100): array
    {
        return $this->db->table('crm_audit_log')->where('company_id', CrmCompanyScope::companyId($userId))->where('subject_type', $subjectType)->where('subject_public_id', $subjectPublicId)
            ->orderByDesc('id')->limit(min($limit, 250))->get()->map(fn ($row) => (array) $row)->all();
    }
}
