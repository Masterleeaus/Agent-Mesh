# Titan Autonomy Engine v1.6.0

## Autonomy Operations / Exception Centre

- Added tenant-facing Autonomy Operations queue over canonical execution receipts.
- Added deterministic operational status/priority classification for observing, mature-due, human-verification, postcondition failure, Assurance AMBER/RED, reversal, material correction, execution failure, exception, inconclusive and verified-correct outcomes.
- Added receipt detail view with execution, postcondition, Assurance, trust-state, feedback and regression evidence.
- Added due-only manual recheck that reuses the canonical reconciliation pipeline; it cannot shorten maturation windows or force a positive result.
- Added append-only manager review/acknowledgement records that do not alter learning evidence, streaks, gates, scope or autonomy level.
- Added negative-only outcome reporting directly from the operations detail surface.
- Added audit events for operations review and manual recheck, with normal optional Rewind correlation.
- Added tenant-safe operations query/read models. Request-supplied tenant identifiers remain prohibited.

## Persistence

- Added `titan_autonomy_execution_reviews` for operational review metadata only.

## Agent-06 Workforce Provider Migration

- Added fail-closed `workforce-integration.json` using canonical `company_id`.
- Workforce identity/roles/hierarchy remain owned by Titan AI Workforce; provider capabilities remain extension-owned.
- Converged package/manifest metadata toward Titan Extension Blueprint v4.2.1.
