# Titan Forge Governance

Local generated-code validation is necessary but not sufficient for release authority.

Release-candidate flow is `local validation -> Shield -> Risk -> selective Model Council -> Governance -> Command Bus`. A blocking validation/Shield result or Risk `DENY` rejects a candidate. Missing authorities, approval-required Risk directives, or unsatisfied high-risk Council deliberation hold the candidate.

Titan Model Council v0.7 governed deliberation is advisory evidence only. A completed non-escalated Council result may satisfy the Council portion of the high/critical-risk gate, but Titan Governance remains the policy/approval authority and Command Bus remains mutation/execution authority. Council rejection, escalation, failure, missing configuration or authority overreach keeps the candidate blocked.

Every release candidate records a stable artifact digest, validation fingerprint, gate fingerprint, reason codes, causal lineage and `deployment_authority: none`. Required Council reviews additionally persist a Forge `council.deliberation` receipt containing only sanitized decision evidence and hashes; Council-owned participant/final-answer text is not copied into Forge.

Titan Rewind is a forensic/read-model consumer only. Forge's `rewind-source` contribution exposes bounded hashes and state through the host-owned read-only adapter; it grants no mutation, approval or deployment capability. Reconstructed evidence may explain what Forge recorded, but it can never authorize a release or replay a mutation.
