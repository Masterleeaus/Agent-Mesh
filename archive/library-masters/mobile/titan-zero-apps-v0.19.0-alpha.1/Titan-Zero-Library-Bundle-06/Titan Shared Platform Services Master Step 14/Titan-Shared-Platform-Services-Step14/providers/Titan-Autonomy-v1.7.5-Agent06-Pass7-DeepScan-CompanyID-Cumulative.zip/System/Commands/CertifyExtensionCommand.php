<?php
declare(strict_types=1);
namespace App\Extensions\TitanAutonomy\System\Commands;
use Illuminate\Console\Command;
final class CertifyExtensionCommand extends Command
{
    protected $signature = 'titan:titan-autonomy:certify';
    protected $description = 'Run Titan Autonomy extension certification.';
    public function handle(): int
    {
        $manifest = dirname(__DIR__, 2) . '/extension.manifest.json';
        if (!is_file($manifest)) { $this->error('extension.manifest.json missing'); return self::FAILURE; }
        json_decode((string) file_get_contents($manifest), true, 512, JSON_THROW_ON_ERROR);
        $this->info('TITAN_AUTONOMY_CERTIFY: PASS');
        return self::SUCCESS;
    }
}
