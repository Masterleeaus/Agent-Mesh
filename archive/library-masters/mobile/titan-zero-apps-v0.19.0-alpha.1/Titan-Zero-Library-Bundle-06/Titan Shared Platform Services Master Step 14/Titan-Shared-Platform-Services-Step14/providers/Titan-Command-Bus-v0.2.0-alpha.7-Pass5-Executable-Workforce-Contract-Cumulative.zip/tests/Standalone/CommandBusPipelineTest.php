<?php
declare(strict_types=1);

$GLOBALS['tcb_test_config'] = [
    'titan-command-bus.enabled' => true,
    'titan-command-bus.require_lifecycle' => false,
    'titan-command-bus.kill_switch' => false,
    'titan-command-bus.max_payload_bytes' => 65536,
    'titan-command-bus.allow_offline_revalidation' => true,
    'titan-command-bus.require_signal' => true,
    'titan-command-bus.require_risk' => true,
    'titan-command-bus.require_assurance' => true,
    'titan-command-bus.require_autonomy' => false,
];
if (!function_exists('config')) {
    function config(string $key, mixed $default = null): mixed { return $GLOBALS['tcb_test_config'][$key] ?? $default; }
}

$root=dirname(__DIR__,2);
foreach ([
    'System/DTO/CommandContext.php','System/DTO/CommandRequest.php','System/DTO/RiskDecision.php','System/DTO/AssuranceDecision.php','System/DTO/GovernanceDecision.php','System/DTO/CommandExecutionResult.php','System/DTO/CommandReceipt.php',
    'System/Contracts/CommandAdapterContract.php','System/Contracts/CommandAdapterRegistryContract.php','System/Contracts/CommandRiskGateContract.php','System/Contracts/CommandAssuranceGateContract.php','System/Contracts/CommandGovernanceGateContract.php','System/Contracts/CommandReceiptStoreContract.php','System/Contracts/CommandSignalEmitterContract.php','System/Contracts/CommandBusContract.php',
    'System/Contracts/CommandLifecycleStoreContract.php','System/Services/CommandLifecycleState.php','System/Services/CommandBus.php',
] as $rel) require_once $root.'/'.$rel;

use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterRegistryContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAssuranceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandRiskGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandGovernanceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandReceiptStoreContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandSignalEmitterContract;
use App\Extensions\TitanCommandBus\System\DTO\AssuranceDecision;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandExecutionResult;
use App\Extensions\TitanCommandBus\System\DTO\CommandReceipt;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use App\Extensions\TitanCommandBus\System\DTO\GovernanceDecision;
use App\Extensions\TitanCommandBus\System\DTO\RiskDecision;
use App\Extensions\TitanCommandBus\System\Services\CommandBus;

final class FakeAdapter implements CommandAdapterContract {
    public int $calls=0;
    public function capability(): string { return 'crm.invoice.create'; }
    public function execute(CommandContext $context, CommandRequest $request, string $operationId): CommandExecutionResult {
        $this->calls++;
        return new CommandExecutionResult('crm:invoice:77', true, 77, 'invoice', 1);
    }
}
final class FakeRegistry implements CommandAdapterRegistryContract {
    public function __construct(public FakeAdapter $adapter) {}
    public function register(CommandAdapterContract $adapter): void {}
    public function has(string $capability): bool { return $capability===$this->adapter->capability(); }
    public function forCapability(string $capability): ?CommandAdapterContract { return $this->has($capability)?$this->adapter:null; }
    public function count(): int { return 1; }
}
final class FakeRisk implements CommandRiskGateContract {
    public function __construct(public bool $isAvailable=true, public bool $allow=true) {}
    public function available(): bool { return $this->isAvailable; }
    public function assess(CommandContext $context, CommandRequest $request): RiskDecision {
        return $this->allow ? new RiskDecision(true,'risk:1','LOW',0.15) : new RiskDecision(false,'risk:2','HIGH',0.91,[],'RISK_DENIED');
    }
}
final class FakeAssurance implements CommandAssuranceGateContract {
    public function available(): bool { return true; }
    public function assess(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null): AssuranceDecision {
        return new AssuranceDecision(true,'assurance:1','POLICY',['evidence:1']);
    }
}
final class FakeGovernance implements CommandGovernanceGateContract {
    public function __construct(public bool $isAvailable, public bool $allow=true) {}
    public function available(): bool { return $this->isAvailable; }
    public function evaluate(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null, ?AssuranceDecision $assurance = null, ?\App\Extensions\TitanCommandBus\System\DTO\AutonomyDecision $autonomy = null): GovernanceDecision {
        return $this->allow ? new GovernanceDecision(true,'gov:1','LOW',null,false) : new GovernanceDecision(false,'gov:2','HIGH',null,false,'GOVERNANCE_DENIED');
    }
}
final class FakeStore implements CommandReceiptStoreContract {
    public array $claims=[]; public array $receipts=[];
    private function key(CommandContext $c, CommandRequest $r): string { return $c->tenantCompanyId.'|'.$r->idempotencyKey; }
    public function existing(CommandContext $context, CommandRequest $request): ?array { return $this->claims[$this->key($context,$request)] ?? null; }
    public function claim(CommandContext $context, CommandRequest $request, string $operationId, string $requestHash): bool {
        $k=$this->key($context,$request); if(isset($this->claims[$k])) return false;
        $this->claims[$k]=['request_hash'=>$requestHash,'operation_id'=>$operationId,'status'=>'processing','receipt'=>null]; return true;
    }
    public function complete(CommandReceipt $receipt): void {
        $this->receipts[]=$receipt; $k=$receipt->tenantCompanyId.'|'.$receipt->idempotencyKey;
        $this->claims[$k]['status']=$receipt->status; $this->claims[$k]['receipt']=$receipt->toArray();
    }
    public function health(): array { return ['receipts_table'=>true,'idempotency_table'=>true]; }
}
final class FakeSignals implements CommandSignalEmitterContract {
    public array $events=[];
    public function __construct(public bool $isAvailable=true) {}
    public function available(): bool { return $this->isAvailable; }
    public function emit(string $type, array $payload): void { $this->events[]=$type; }
}

$ctx=new CommandContext(42,'human',7,'titan-command');
$req=new CommandRequest('crm.invoice.create',['amount'=>100],'idem-1','trace','corr','cause','root');
$adapter=new FakeAdapter(); $registry=new FakeRegistry($adapter); $signals=new FakeSignals();

$store=new FakeStore(); $bus=new CommandBus($registry,new FakeRisk(true),new FakeAssurance(),new FakeGovernance(false),$store,$signals);
$r=$bus->dispatch($ctx,$req);
if($r->status!=='blocked'||$r->reasonCode!=='GOVERNANCE_UNAVAILABLE'||$r->freshGovernance!==false||$adapter->calls!==0) throw new RuntimeException('fail-closed governance test failed');

$store=new FakeStore(); $bus=new CommandBus($registry,new FakeRisk(true),new FakeAssurance(),new FakeGovernance(true),$store,$signals);
$r=$bus->dispatch($ctx,$req);
if($r->status!=='applied'||$r->freshGovernance!==true||$r->governanceReference!=='gov:1'||$r->domainReceiptReference!=='crm:invoice:77'||$adapter->calls!==1) throw new RuntimeException('applied pipeline failed');
$replay=$bus->dispatch($ctx,$req);
if($replay->status!=='already_applied'||!$replay->replayed||$replay->freshGovernance!==false||$adapter->calls!==1) throw new RuntimeException('idempotent replay failed');
$conflict=new CommandRequest('crm.invoice.create',['amount'=>101],'idem-1','trace2','corr2','cause2','root2');
$bad=$bus->dispatch($ctx,$conflict);
if($bad->status!=='blocked'||$bad->reasonCode!=='IDEMPOTENCY_KEY_PAYLOAD_MISMATCH'||$adapter->calls!==1) throw new RuntimeException('idempotency collision failed');

echo "PASS CommandBusPipelineTest\n";
