<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Bridges;

use App\Extensions\TitanPrime\System\Gateways\Contracts\EngineBridgeContract;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineAvailability;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayRequest;
use App\Extensions\TitanPrime\System\Gateways\Data\EngineGatewayResult;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;

final class FailClosedEngineBridge implements EngineBridgeContract
{
    public function dispatch(EngineGatewayRequest $request): EngineGatewayResult
    {
        return EngineGatewayResult::unavailable($request, ['engine_bridge_unbound']);
    }

    public function availability(EngineKey $engine): EngineAvailability
    {
        return new EngineAvailability($engine, false, 'engine_bridge_unbound');
    }
}
