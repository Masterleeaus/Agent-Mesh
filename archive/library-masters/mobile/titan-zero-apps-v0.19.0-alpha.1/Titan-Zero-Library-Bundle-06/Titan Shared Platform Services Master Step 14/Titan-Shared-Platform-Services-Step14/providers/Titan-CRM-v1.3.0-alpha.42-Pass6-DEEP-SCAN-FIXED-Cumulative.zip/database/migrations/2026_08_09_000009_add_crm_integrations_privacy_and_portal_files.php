<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('crm_portal_files', function (Blueprint $t): void {
            $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index();
            $t->char('portal_grant_public_id',26)->index(); $t->string('disk',60); $t->string('storage_key',500)->unique();
            $t->string('original_name',500); $t->string('mime_type',160); $t->unsignedBigInteger('size_bytes'); $t->char('sha256',64)->index();
            $t->string('status',30)->default('available')->index(); $t->string('uploaded_by_type',30)->default('customer');
            $t->json('metadata')->nullable(); $t->dateTime('uploaded_at')->index(); $t->timestamp('deleted_at')->nullable()->index(); $t->timestamps();
            $t->index(['user_id','portal_grant_public_id','status'],'crm_portal_file_lookup');
        });

        Schema::create('crm_api_keys', function (Blueprint $t): void {
            $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->string('label',120);
            $t->char('key_hash',64)->unique(); $t->string('key_hint',16); $t->json('scopes'); $t->timestamp('last_used_at')->nullable()->index();
            $t->timestamp('expires_at')->nullable()->index(); $t->timestamp('revoked_at')->nullable()->index(); $t->json('metadata')->nullable(); $t->timestamps();
        });

        Schema::create('crm_webhooks', function (Blueprint $t): void {
            $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->string('name',120);
            $t->string('url',1000); $t->text('secret_ciphertext'); $t->json('events'); $t->boolean('enabled')->default(true)->index();
            $t->timestamp('last_success_at')->nullable(); $t->timestamp('last_failure_at')->nullable(); $t->unsignedInteger('failure_count')->default(0); $t->timestamps();
        });
        Schema::create('crm_webhook_deliveries', function (Blueprint $t): void {
            $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->char('webhook_public_id',26)->index();
            $t->string('event_key',100)->index(); $t->char('event_id',26)->nullable()->index(); $t->json('payload'); $t->string('status',30)->default('pending')->index();
            $t->unsignedInteger('attempt_count')->default(0); $t->unsignedSmallInteger('http_status')->nullable(); $t->text('last_error')->nullable();
            $t->timestamp('available_at')->nullable()->index(); $t->timestamp('delivered_at')->nullable(); $t->timestamps();
        });

        Schema::create('crm_email_connections', function (Blueprint $t): void {
            $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->string('provider',60)->index();
            $t->string('account_email',320); $t->string('external_account_id')->nullable(); $t->string('credentials_reference')->nullable();
            $t->string('status',30)->default('connected')->index(); $t->string('sync_cursor',1000)->nullable(); $t->timestamp('last_synced_at')->nullable();
            $t->json('settings')->nullable(); $t->timestamps(); $t->unique(['user_id','provider','account_email'],'crm_email_connection_unique');
        });
        Schema::create('crm_email_messages', function (Blueprint $t): void {
            $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->char('connection_public_id',26)->index();
            $t->string('external_message_id',500); $t->string('message_id',500)->nullable()->index(); $t->string('thread_id',500)->nullable()->index();
            $t->string('direction',20)->index(); $t->string('from_email',320)->nullable()->index(); $t->json('to_emails')->nullable(); $t->json('cc_emails')->nullable();
            $t->string('subject',1000)->nullable(); $t->longText('body_text')->nullable(); $t->string('normalized_email',320)->nullable()->index();
            $t->string('subject_type',60)->nullable()->index(); $t->char('subject_public_id',26)->nullable()->index(); $t->timestamp('sent_at')->nullable()->index();
            $t->json('metadata')->nullable(); $t->timestamp('deleted_at')->nullable()->index(); $t->timestamps(); $t->unique(['user_id','connection_public_id','external_message_id'],'crm_email_external_unique');
        });

        Schema::create('crm_record_shares', function (Blueprint $t): void {
            $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->string('subject_type',60)->index();
            $t->char('subject_public_id',26)->index(); $t->unsignedBigInteger('grantee_user_id')->index(); $t->json('permissions');
            $t->timestamp('expires_at')->nullable()->index(); $t->timestamp('revoked_at')->nullable()->index(); $t->timestamps();
            $t->unique(['user_id','subject_type','subject_public_id','grantee_user_id'],'crm_record_share_unique');
        });

        Schema::create('crm_retention_policies', function (Blueprint $t): void {
            $t->id(); $t->unsignedBigInteger('user_id')->index(); $t->string('resource_type',60); $t->unsignedInteger('retention_days');
            $t->string('action',30)->default('review'); $t->boolean('enabled')->default(true)->index(); $t->timestamps();
            $t->unique(['user_id','resource_type'],'crm_retention_policy_unique');
        });
        Schema::create('crm_privacy_requests', function (Blueprint $t): void {
            $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->string('request_type',30)->index();
            $t->string('subject_type',60)->index(); $t->char('subject_public_id',26)->nullable()->index(); $t->string('subject_email',320)->nullable()->index();
            $t->boolean('dry_run')->default(true); $t->string('status',30)->default('pending')->index(); $t->longText('plan')->nullable(); $t->longText('result')->nullable();
            $t->unsignedBigInteger('requested_by_user_id')->nullable()->index(); $t->dateTime('requested_at')->index(); $t->timestamp('completed_at')->nullable(); $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach ([
            'crm_privacy_requests','crm_retention_policies','crm_record_shares','crm_email_messages','crm_email_connections',
            'crm_webhook_deliveries','crm_webhooks','crm_api_keys','crm_portal_files'
        ] as $table) Schema::dropIfExists($table);
    }
};
