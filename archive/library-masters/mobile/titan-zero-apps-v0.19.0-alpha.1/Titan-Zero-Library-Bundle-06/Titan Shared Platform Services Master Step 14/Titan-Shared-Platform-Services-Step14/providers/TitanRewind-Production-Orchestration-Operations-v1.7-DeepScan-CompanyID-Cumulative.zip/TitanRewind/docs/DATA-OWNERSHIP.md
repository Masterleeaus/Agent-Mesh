# Data ownership

Rewind owns forensic read models only: normalized trace events, trace indexes, source watermarks, cases/case links, snapshots, dependency edges, replay runs/results, integrity checks, drift findings, signed evidence packages, custody events, recovery proposals/steps, Governance receipts and legal holds.

It does **not** own customers, jobs, invoices, payments, source-engine canonical ledgers, Governance decisions or Command Bus/domain mutations. Rewind references those records by stable IDs/hashes.

Sensitive payload JSON is sanitized before persistence. Hidden chain-of-thought/private reasoning is prohibited; store structured rationale, reason codes and evidence references instead. Database/filesystem encryption-at-rest certification and automated purge receipts remain later Blueprint v4.1 hardening requirements.
