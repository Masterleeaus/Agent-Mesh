# Upgrade 10.3.0 → 10.3.1

1. Install the v10.3.1 extension over the existing `InteractionEngine` folder using the Titan installer.
2. Run normal extension migrations. The additive migration creates:
   - `interaction_platform_settings`
   - `interaction_company_settings`
3. Existing `interaction_user_preferences` data is preserved and reused.
4. No CRM, Builder, Chatbot, Connect, Mobile or TitanAI business records are copied into Interaction Engine tables.
5. Existing wizard sessions, onboarding plans, memory, queues and company-owned Interaction data are preserved.
6. Configure/review platform settings at `/dashboard/admin/interaction-engine/settings`.
7. Company owners/admins can review defaults at `/dashboard/user/interaction-engine/settings`.
8. Reload long-running Laravel workers after changing boot-time authority defaults such as fresh-authentication duration.

Rollback to 10.3.0 can leave the two new settings tables in place; 10.3.0 does not depend on them. Do not drop them if you intend to reinstall 10.3.1 and preserve settings.
