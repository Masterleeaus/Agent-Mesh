<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$passes = [];

$check = static function (bool $condition, string $label) use (&$failures, &$passes): void {
    if ($condition) {
        $passes[] = $label;
        return;
    }
    $failures[] = $label;
};

$read = static function (string $relative) use ($root): string {
    $path = $root.'/'.$relative;
    return is_file($path) ? (string) file_get_contents($path) : '';
};

$required = [
    'extension.json',
    'extension.manifest.json',
    'README.md',
    'docs/AGENT_DEVELOPMENT_PROMPT.md',
    'System/TitanConnectServiceProvider.php',
    'database/migrations/2026_08_09_000001_create_titan_connect_core_tables.php',
    'database/migrations/2026_08_09_000002_add_integration_runtime.php',
    'database/migrations/2026_08_09_000003_migrate_tenant_boundary_to_company.php',
    'database/migrations/2026_08_09_000004_add_official_comms_donor_features.php',
    'database/migrations/2026_08_09_000005_harden_voice_runtime.php',
    'database/migrations/2026_08_09_000006_repair_partial_mysql_install.php',
    'database/migrations/2026_08_09_000007_sync_magicai_menu_rows.php',
    'database/migrations/2026_08_10_000008_repair_magicai_dashboard_navigation.php',
    'routes/web.php',
    'routes/api.php',
    'routes/channels.php',
    'System/Contracts/CompanyContext.php',
    'System/Contracts/CompanyActorDirectory.php',
    'System/Security/AuthenticatedCompanyContext.php',
    'System/Security/DatabaseCompanyActorDirectory.php',
    'System/Contracts/MessagingProvider.php',
    'System/Contracts/CredentialVault.php',
    'System/Contracts/WorkCoreAuthorizationGateway.php',
    'System/Providers/ProviderRegistry.php',
    'System/Policies/ChannelAccessPolicy.php',
    'System/Http/Controllers/ChannelConnectionController.php',
    'System/Webhooks/InboundWebhookService.php',
    'System/Delivery/OutboundDeliveryService.php',
    'System/Services/Legacy/LegacyTeamChatImporter.php',
    'System/Inbox/UnifiedInboxService.php',
    'System/Services/DefaultMessagingToolGateway.php',
    'System/Services/OperatorInboxService.php',
    'System/Services/ExternalThreadManagementService.php',
    'System/Onboarding/MetaOAuthService.php',
    'System/Onboarding/TelegramWebhookRegistrar.php',
    'System/Providers/WhatsAppTwilioTransport.php',
    'System/Providers/VoiceProvider.php',
    'System/Voice/VoiceSessionManager.php',
    'System/Voice/OpenAiRealtimeVoiceGateway.php',
    'System/Voice/ElevenLabsVoiceGateway.php',
    'resources/views/inbox/index.blade.php',
    'resources/assets/js/operator-inbox.js',
    'resources/assets/js/voice-call-client.js',
    'resources/assets/js/settings.js',
    'resources/views/settings/index.blade.php',
    'System/Http/Middleware/EnforceCompanyRateLimit.php',
    'System/Services/ConnectionDiagnosticsService.php',
    'System/Services/HostReadinessService.php',
    'System/Http/Controllers/DiagnosticsController.php',
    'System/Console/DiagnoseTitanConnectCommand.php',
    'tests/Contract/production_readiness_pass.php',
    'tests/Contract/runtime_certification_pass.php',
    'System/Console/CertifyTitanConnectCommand.php',
    'System/Services/HostCertificationService.php',
    'System/Services/IntegrationReadinessService.php',
    'System/Certification/CertificationQueueProbeJob.php',
    'System/Certification/QueueExecutionProbe.php',
    'System/Certification/CertificationBroadcastProbe.php',
    'System/Certification/BroadcastExecutionProbe.php',
    'System/Certification/CompanyIsolationProbe.php',
    'docs/RUNTIME_CERTIFICATION_V080.md',
    'docs/DONOR_EXTRACTION_V060.md',
    'System/Contracts/MessagingToolGateway.php',
    'System/Contracts/ChatbotMessagingBridge.php',
    'System/Attachments/AttachmentValidator.php',
    'System/Attachments/AttachmentUploadService.php',
    'System/Attachments/OutboundAttachmentResolver.php',
    'System/Security/SensitivePayloadGuard.php',
    'System/Http/Controllers/AttachmentController.php',
    'System/Jobs/ProcessInboundWebhookJob.php',
    'System/Console/RetryDueDeliveriesCommand.php',
    'System/Services/MessagingAuditService.php',
    'System/Listeners/ForwardInboundToChatbot.php',
    'System/Listeners/PushTeamMessage.php',
    'System/Services/ChannelHealthService.php',
    'System/Console/ImportLegacyTeamChatCommand.php',
    'System/Realtime/SafeRealtimeDispatcher.php',
    'System/Contracts/RetentionPolicy.php',
    'System/Security/ConfigRetentionPolicy.php',
    'System/Contracts/MessagingPrivacyHook.php',
    'System/Security/NullMessagingPrivacyHook.php',
    'System/Services/MessagingPrivacyService.php',
    'docs/MIGRATION.md',
    'docs/DONOR_CLASSIFICATION.md',
    'docs/DEVELOPMENT_REPORT.md',
    'docs/INTEGRATION.md',
    'docs/COMPANY_BOUNDARY.md',
    'docs/PRODUCTION_READINESS_V070.md',
    'docs/NAVIGATION_MENU_V090.md',
    'System/Navigation/TitanConnectNavigation.php',
    'System/Navigation/HostNavigationRegistrar.php',
    'System/Navigation/MagicAiMenuSynchronizer.php',
    'System/Services/InboxBadgeService.php',
    'System/Http/Controllers/NavigationController.php',
    'System/Http/Controllers/InboxNavigationController.php',
    'System/Http/Controllers/ChannelSettingsController.php',
    'System/Http/Controllers/AdminChannelSettingsController.php',
    'resources/views/channels/index.blade.php',
    'resources/views/channels/show.blade.php',
    'resources/views/inbox/unified.blade.php',
    'resources/views/header/inbox-notification.blade.php',
    'resources/views/admin/channels.blade.php',
    'resources/assets/js/channel-settings.js',
    'resources/assets/js/unified-inbox.js',
    'resources/assets/js/navigation-badges.js',
    'tests/Contract/navigation_menu_pass.php',
    'host-patches/README.md',
    'System/Host/TitanConnectHostManifest.php',
    'System/Host/TitanConnectPermissionCatalogue.php',
    'System/Host/TitanConnectFeatureCatalogue.php',
    'System/Host/HostMenuLifecycle.php',
    'System/Console/SyncTitanConnectHostCommand.php',
    'tests/Contract/host_compatibility_pass.php',
    'tests/Contract/route_boot_scope_pass.php',
    'tests/Contract/route_boot_runtime.php',
    'tests/Contract/mysql_migration_identifier_pass.php',
    'tests/Contract/live_host_menu_pass.php',
    'tests/Contract/upgrade_install_safety_pass.php',
    'tests/Contract/dashboard_shell_menu_repair_pass.php',
    'tests/Contract/provider_inheritance_runtime_pass.php',
    'System/View/MagicAiDashboardRenderer.php',
    'System/Http/Controllers/TitanConnectSettingsController.php',
    'tests/Contract/dashboard_root_render_pass.php',
    'tests/Contract/dashboard_renderer_runtime.php',
    'docs/LIVE_DASHBOARD_RENDER_V0106.md',
    'docs/LIVE_HOST_MENU_V0104.md',
    'docs/DASHBOARD_SHELL_MENU_V0105.md',
    'host-patches/TitanConnect-v0.10.4-menu-repair.sql',
    'host-patches/TitanConnect-v0.10.5-dashboard-menu-repair.sql',
    'docs/HOST_COMPATIBILITY_V010.md',
];

foreach ($required as $file) {
    $check(file_exists($root.'/'.$file), 'required file: '.$file);
}

$manifest = json_decode($read('extension.json'), true);
$check(is_array($manifest), 'extension.json is valid JSON');
$check(($manifest['schema'] ?? null) === 'titan-extension-v1', 'manifest schema is titan-extension-v1');
$check(($manifest['slug'] ?? null) === 'titan-connect', 'manifest slug is titan-connect');
$check(($manifest['folder'] ?? null) === 'TitanConnect', 'manifest folder resolves to TitanConnect');
$check(($manifest['migrations'] ?? null) === true, 'manifest declares migrations');
$check(($manifest['provider'] ?? null) === 'App\\Extensions\\TitanConnect\\System\\TitanConnectServiceProvider', 'manifest provider identity preserved');
$check(($manifest['version'] ?? null) === '0.10.6', 'manifest version upgraded to 0.10.6');
$check(!is_dir($root.'/docs/superpowers'), 'production package excludes internal planning files');

$navigation = $read('System/Navigation/TitanConnectNavigation.php');
foreach (['whatsapp','messenger','instagram','telegram','sms','voice','push'] as $provider) {
    $check(str_contains($navigation, 'titan_connect_channel_'.$provider), 'navigation includes channel child '.$provider);
}
foreach (['unified','team','external','mine','unassigned','needs_human','closed'] as $mode) {
    $check(str_contains($navigation, 'titan_connect_inbox_'.$mode), 'navigation includes inbox child '.$mode);
}
$check(str_contains($navigation, 'ext_titan_connect_channels') && str_contains($navigation, 'ext_titan_connect_inbox'), 'navigation includes separate Channels and Inbox parents');
$check(str_contains($read('routes/api.php'), 'navigation/badges'), 'navigation badge API is packaged');
$apiRoutes = $read('routes/api.php');
$check(!str_contains($apiRoutes, '$rate ='), 'API routes do not depend on uncaptured closure-scoped rate helper');
$check(str_contains($apiRoutes, "EnforceCompanyRateLimit::class.':upload'") && str_contains($apiRoutes, "EnforceCompanyRateLimit::class.':send'"), 'API rate-limit middleware is directly resolvable during route boot');
$check(str_contains($read('System/Services/InboxBadgeService.php'), 'companyId') && str_contains($read('System/Services/InboxBadgeService.php'), 'actorId'), 'navigation badge service is company + actor scoped');

$liveMenuSync = $read('System/Navigation/MagicAiMenuSynchronizer.php');
$liveMenuMigration = $read('database/migrations/2026_08_09_000007_sync_magicai_menu_rows.php');
$webRoutes = $read('routes/web.php');
$check(str_contains($liveMenuSync, "Schema::hasTable('menus')") && str_contains($liveMenuSync, "app('db')->table('menus')"), 'v0.10.4 materializes navigation into the real MagicAI menus table');
$check(str_contains($liveMenuSync, "'extension' => null") && str_contains($liveMenuSync, "'badge' => null"), 'v0.10.4 DB fallback avoids unknown extension gating and shared unread counts');
$check(str_contains($liveMenuSync.$navigation, 'ext_titan_connect_channels') && str_contains($liveMenuSync.$navigation, 'ext_titan_connect_inbox'), 'v0.10.4 DB fallback includes Channels and Inbox roots');
$check(str_contains($navigation, 'liveHostAdmin') && str_contains($navigation, "'settings'") && str_contains($navigation, 'dashboard.admin.settings.titan-connect.channels.'), 'v0.10.4 admin DB fallback uses the existing Settings permission family');
$check(!str_contains($liveMenuSync, "Schema::table('menus'") && !str_contains($liveMenuMigration, "Schema::table('menus'"), 'v0.10.4 does not mutate the shared MagicAI menu schema');
$check(!str_contains($liveMenuMigration, 'App\\Extensions\\TitanConnect\\') && str_contains($liveMenuMigration, 'DB' . "::table('menus')") && str_contains($read('System/Console/SyncTitanConnectHostCommand.php'), 'MagicAiMenuSynchronizer'), 'v0.10.4 install migration is upgrade-safe and post-install host-sync remains available');
$check((str_contains($webRoutes, "'updateUserActivity', 'admin'") || str_contains($webRoutes, "'auth', 'admin'")) && str_contains($webRoutes, 'dashboard.admin.settings.titan-connect.channels.index'), 'v0.10.4 admin settings routes use admin middleware and host Settings route family');
$check(str_contains($read('System/Services/HostReadinessService.php'), 'navigation-menu'), 'v0.10.4 host diagnostics verify menu materialization');

$dashboardRepair = $read('database/migrations/2026_08_10_000008_repair_magicai_dashboard_navigation.php');
$dashboardContract = $read('tests/Contract/dashboard_shell_menu_repair_pass.php');
$providerRuntimeContract = $read('tests/Contract/provider_inheritance_runtime_pass.php');
$voiceProvider = $read('System/Providers/VoiceProvider.php');
$check(str_contains($dashboardRepair, 'dashboard.user.titan-connect.inbox.unified') && str_contains($dashboardRepair, 'dashboard.user.titan-connect.channels.index'), 'v0.10.5 repairs user Inbox/Channels routes into normal dashboard navigation');
$check(str_contains($webRoutes, "->prefix('dashboard/user/titan-connect')") && str_contains($webRoutes, "->as('dashboard.user.titan-connect.')"), 'v0.10.5 canonical user dashboard route family is packaged');
$dashboardRenderer = $read('System/View/MagicAiDashboardRenderer.php');
$dashboardRootContract = $read('tests/Contract/dashboard_root_render_pass.php');
$dashboardRuntimeContract = $read('tests/Contract/dashboard_renderer_runtime.php');
$check(str_contains($dashboardRenderer, "make('panel.layout.app')") && str_contains($dashboardRenderer, "startSection('content'"), 'v0.10.6 renders MagicAI panel layout as the root response');
$check(!str_contains($read('resources/views/channels/show.blade.php'), "@extends('panel.layout.app')") && !str_contains($read('resources/views/inbox/index.blade.php'), "@extends('panel.layout.app')"), 'v0.10.6 Titan Connect full-page content is rendered as partials inside host root layout');
$check(str_contains($webRoutes, 'ViewSharedMiddleware::class') && str_contains($webRoutes, 'NewExtensionInstalled::class') && str_contains($webRoutes, "'updateUserActivity'"), 'v0.10.6 provider-loaded routes mirror MagicAI dashboard wrapper middleware');
$check(($manifest['publishes'] ?? null) === ['titan-connect-assets', 'titan-connect-config'], 'v0.10.6 installer manifest explicitly publishes Titan Connect assets and config');
$check(str_contains($dashboardRootContract, 'dashboard root-render contract') && str_contains($dashboardRuntimeContract, 'dashboard renderer runtime'), 'v0.10.6 deterministic dashboard renderer regressions are packaged');
$serviceProviderForDashboard = $read('System/TitanConnectServiceProvider.php');
$check(str_contains($serviceProviderForDashboard, "'titan-connect-assets'") && strpos($serviceProviderForDashboard, "'titan-connect-assets'") < strpos($serviceProviderForDashboard, 'runningInConsole'), 'v0.10.5 web installer can discover Titan Connect published assets');
$check(!str_contains($voiceProvider, 'private readonly ProviderHttpClient $http') && str_contains($voiceProvider, 'parent::__construct($http)'), 'v0.10.5 VoiceProvider preserves inherited protected HTTP client visibility');
$check(str_contains($dashboardContract, 'dashboard-shell-menu-repair contract suite') && str_contains($providerRuntimeContract, 'Complete provider inheritance graph'), 'v0.10.5 live dashboard and PHP 8.3 provider regressions are packaged');


$sidecar = json_decode($read('extension.manifest.json'), true);
$check(is_array($sidecar), 'v0.10 hardened sidecar manifest parses');
$check(($sidecar['tenancy']['key'] ?? null) === 'company_id', 'v0.10 sidecar declares company_id boundary');
$check(($sidecar['lifecycle']['preserve_data_on_uninstall'] ?? null) === true, 'v0.10 sidecar preserves data on uninstall');
$serviceProvider = $read('System/TitanConnectServiceProvider.php');
$check(str_contains($serviceProvider, 'public static function registerKey(): string') && str_contains($serviceProvider, "return 'titan-connect';"), 'v0.10 stable provider registration key is packaged');
$check(str_contains($serviceProvider, 'public static function uninstall(): void'), 'v0.10 data-preserving uninstall hook is packaged');
$check(substr_count($serviceProvider, "'extension'") >= 2, 'v0.10 shared extension publish tags are packaged');
$permissionCatalogue = $read('System/Host/TitanConnectPermissionCatalogue.php');
$featureCatalogue = $read('System/Host/TitanConnectFeatureCatalogue.php');
$check(str_contains($permissionCatalogue, 'admin_titan_connect_channels') && str_contains($permissionCatalogue, 'titan-connect.admin.channels.*'), 'v0.10 admin permission catalogue is packaged');
$check(str_contains($featureCatalogue, 'ext_titan_connect_core') && str_contains($featureCatalogue, 'ext_titan_connect_channels') && str_contains($featureCatalogue, 'ext_titan_connect_voice'), 'v0.10 plan feature catalogue is packaged');
$check(str_contains($read('System/Console/SyncTitanConnectHostCommand.php'), 'titan-connect:host-sync'), 'v0.10 explicit host sync command is packaged');
$check(str_contains($read('upgrade.php'), "'version' => '0.10.6'") && str_contains($read('upgrade.php'), 'manual_host_sync_command') && str_contains($read('upgrade.php'), 'titan-connect:host-sync'), 'v0.10 upgrade metadata is current and keeps host-sync out of same-request automatic execution');

$mysqlRepair = $read('database/migrations/2026_08_09_000006_repair_partial_mysql_install.php');
foreach (['tc_ext_reads_thread_fk', 'tc_ext_reads_last_msg_fk', 'tc_out_delivery_msg_fk', 'tc_out_delivery_conn_fk', 'tc_thread_tags_thread_fk'] as $constraint) {
    $check(str_contains($read('database/migrations/2026_08_09_000001_create_titan_connect_core_tables.php').$read('database/migrations/2026_08_09_000004_add_official_comms_donor_features.php'), $constraint), 'v0.10.4 short MySQL foreign key is packaged: '.$constraint);
}
$check(str_contains($mysqlRepair, 'information_schema.KEY_COLUMN_USAGE') && str_contains($mysqlRepair, 'information_schema.STATISTICS'), 'v0.10.4 partial-install repair inspects MySQL foreign keys and indexes');
$check(str_contains($mysqlRepair, 'ext_titan_connect_external_thread_reads') && str_contains($mysqlRepair, 'ext_titan_connect_external_thread_tags'), 'v0.10.4 partial-install repair covers failed DDL tables');

$activePhp = [];
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($iterator as $file) {
    if (!$file->isFile() || $file->getExtension() !== 'php') {
        continue;
    }
    $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
    if (str_starts_with($relative, 'donor/') || str_starts_with($relative, 'tests/donor/') || str_starts_with($relative, 'tools/') || str_starts_with($relative, 'database/legacy-migrations/')) {
        continue;
    }
    $activePhp[$relative] = (string) file_get_contents($file->getPathname());
}

foreach ($activePhp as $relative => $source) {
    $check(!str_contains($source, 'namespace App\\Extensions\\Chatbot'), 'active namespace is TitanConnect: '.$relative);
    $check(!str_contains($source, 'namespace App\\Domains\\TitanAI'), 'active namespace is not TitanAI donor: '.$relative);
    $check(!preg_match('/App\\\\Extensions\\\\Chatbot(?:Whatsapp|Messenger|Instagram|Telegram|Agent|Review)?\\\\/', $source), 'no active Chatbot extension dependency: '.$relative);
}

$modelFiles = glob($root.'/System/Models/*.php') ?: [];
$modelFiles = array_merge($modelFiles, glob($root.'/System/Models/TeamChat/*.php') ?: []);
foreach ($modelFiles as $path) {
    $source = (string) file_get_contents($path);
    $check(!str_contains($source, "protected \$table = 'ext_chatbot_"), 'canonical model table ownership: '.basename($path));
}

$allActive = implode("\n", $activePhp);
$check(!preg_match('/company_id\s*\?\?\s*\$?\w*->getAuthIdentifier\s*\(/', $allActive), 'no user-id company fallback');
$check(!str_contains($allActive, "ext_chatbot_messaging_outbound"), 'no active donor messaging table ownership');

$migration = $read('database/migrations/2026_08_09_000001_create_titan_connect_core_tables.php');
foreach ([
    'ext_titan_connect_conversations',
    'ext_titan_connect_participants',
    'ext_titan_connect_messages',
    'ext_titan_connect_message_reads',
    'ext_titan_connect_channel_connections',
    'ext_titan_connect_channel_members',
    'ext_titan_connect_external_threads',
    'ext_titan_connect_external_messages',
    'ext_titan_connect_external_thread_reads',
    'ext_titan_connect_outbound_deliveries',
    'ext_titan_connect_webhook_events',
    'ext_titan_connect_attachments',
    'ext_titan_connect_audit_logs',
] as $table) {
    $check(str_contains($migration, $table), 'canonical migration includes '.$table);
}
$check(str_contains($migration, 'idempotency_key'), 'outbound idempotency key is persisted');
$check(str_contains($migration, 'provider_event_id'), 'webhook provider event id is persisted');
$check(str_contains($migration, 'correlation_id'), 'correlation id is persisted');
$check(!str_contains($migration, "'credentials'"), 'canonical schema does not persist raw credentials');
$check(str_contains($migration, "unsignedBigInteger('company_id')") && !str_contains($migration, "unsignedBigInteger('tenant_id')"), 'fresh schema uses company_id as canonical boundary');
$companyUpgrade = $read('database/migrations/2026_08_09_000003_migrate_tenant_boundary_to_company.php');
$check(str_contains($companyUpgrade, "renameColumn('tenant_id', 'company_id')"), 'v0.3 boundary migration preserves rows while renaming tenant_id to company_id');
$credentialMigration = $read('database/migrations/2026_08_09_000002_add_integration_runtime.php');
$check(str_contains($credentialMigration, 'ext_titan_connect_provider_credentials'), 'integration migration includes encrypted provider credential table');
$check(str_contains($credentialMigration, 'encrypted_payload'), 'provider credentials are stored as encrypted payloads');
$check(str_contains($credentialMigration, "unsignedBigInteger('company_id')") && !str_contains($credentialMigration, "unsignedBigInteger('tenant_id')"), 'credential vault is company scoped');

$productionReadiness = $read('tests/Contract/production_readiness_pass.php');
$rateMiddleware = $read('System/Http/Middleware/EnforceCompanyRateLimit.php');
$diagnostics = $read('System/Services/ConnectionDiagnosticsService.php');
$voiceHardening = $read('database/migrations/2026_08_09_000005_harden_voice_runtime.php');
$check(str_contains($rateMiddleware, 'companyId') && str_contains($rateMiddleware, 'actorId') && str_contains($rateMiddleware, 'Retry-After'), 'v0.7 company-aware authenticated rate limiting is packaged');
$check(str_contains($diagnostics, 'queued_deliveries') && str_contains($diagnostics, 'failed_webhooks') && !str_contains($diagnostics, 'access_token'), 'v0.7 safe connection diagnostics are packaged');
$check(str_contains($voiceHardening, 'client_event_id') && str_contains($voiceHardening, 'unique'), 'v0.7 voice transcript idempotency migration is packaged');
$check(str_contains($productionReadiness, 'production-readiness contract suite'), 'v0.7 production readiness contract is packaged');
$runtimeCertification = $read('tests/Contract/runtime_certification_pass.php');
$certifyCommand = $read('System/Console/CertifyTitanConnectCommand.php');
$hostCertification = $read('System/Services/HostCertificationService.php');
$check(str_contains($certifyCommand, 'titan-connect:certify') && str_contains($certifyCommand, '--two-company-probe'), 'v0.8 executable host certification command is packaged');
$check(str_contains($hostCertification, 'IntegrationReadinessService') && str_contains($hostCertification, 'CompanyIsolationProbe'), 'v0.8 host certification orchestrator is packaged');
$check(str_contains($runtimeCertification, 'runtime-certification contract suite'), 'v0.8 runtime certification contract is packaged');

$donorMigration = $read('database/migrations/2026_08_09_000004_add_official_comms_donor_features.php');
$check(str_contains($donorMigration, 'ext_titan_connect_external_contacts') && str_contains($donorMigration, 'ext_titan_connect_voice_calls'), 'v0.6 donor schema is packaged');
$check(str_contains($donorMigration, "unsignedBigInteger('company_id')") && !str_contains($donorMigration, "unsignedBigInteger('tenant_id')"), 'v0.6 donor schema is company scoped');

$registry = $read('System/Providers/ProviderRegistry.php');
foreach (['WhatsAppProvider', 'MessengerProvider', 'InstagramProvider', 'TelegramProvider', 'SmsProvider', 'PushProvider', 'VoiceProvider'] as $class) {
    $check(str_contains($registry, 'new '.$class.'('), 'provider registry includes '.$class);
}

$webhook = $read('System/Webhooks/InboundWebhookService.php');
$check(str_contains($webhook, 'verifyWebhook'), 'webhook verifies provider signature');
$check(str_contains($webhook, 'provider_event_id'), 'webhook records provider event id');
$check(str_contains($webhook, 'payload_hash'), 'webhook records deterministic payload hash');
$check(str_contains($webhook, 'firstOrCreate'), 'webhook processing is idempotent');

$delivery = $read('System/Delivery/OutboundDeliveryService.php');
$check(str_contains($delivery, 'idempotency_key'), 'outbound delivery uses idempotency key');
$check(str_contains($delivery, 'next_attempt_at'), 'outbound delivery persists retry schedule');
$check(str_contains($delivery, 'maxAttempts'), 'outbound delivery has bounded retries');

$importer = $read('System/Services/Legacy/LegacyTeamChatImporter.php');
foreach (['ext_chatbot_team_conversations', 'ext_chatbot_team_conversation_participants', 'ext_chatbot_team_messages', 'ext_chatbot_team_message_reads'] as $legacyTable) {
    $check(str_contains($importer, $legacyTable), 'legacy importer reads '.$legacyTable);
}
$check(str_contains($importer, 'ext_titan_connect_conversations'), 'legacy importer writes canonical conversations');

$provider = $read('System/TitanConnectServiceProvider.php');
$check(str_contains($provider, 'loadMigrationsFrom'), 'service provider loads canonical migrations');
$check(str_contains($provider, "routes/web.php"), 'service provider loads web routes');
$check(str_contains($provider, "routes/api.php"), 'service provider loads api routes');
$check(!str_contains($provider, 'donor/'), 'service provider never boots donor tree');
$companyContext = $read('System/Security/AuthenticatedCompanyContext.php');
$check(str_contains($companyContext, '$companyId = $user->company_id;') && !str_contains($companyContext, 'tenant_id'), 'authenticated company context resolves only users.company_id');
$companyDirectory = $read('System/Security/DatabaseCompanyActorDirectory.php');
$check(str_contains($companyDirectory, "Schema::hasColumn('users', 'company_id')") && !str_contains($companyDirectory, "'tenant_id'"), 'participant directory requires users.company_id');
$companyOwnedContract = $read('System/Contracts/CompanyOwnedModel.php');
$companyConcern = $read('System/Models/Concerns/BelongsToCompany.php');
$companyBindingMiddleware = $read('System/Http/Middleware/EnsureCompanyRouteBindings.php');
$check(str_contains($companyOwnedContract, 'interface CompanyOwnedModel') && str_contains($companyConcern, 'scopeForCompany'), 'company-owned model contract and canonical scope exist');
$check(str_contains($companyConcern, 'company_id cannot be changed'), 'persisted company boundary is immutable');
$check(str_contains($companyBindingMiddleware, 'CompanyOwnedModel') && str_contains($companyBindingMiddleware, 'abort(404)'), 'authenticated route binding middleware rejects cross-company models');

$routes = $read('routes/web.php')."\n".$read('routes/api.php');
foreach (['InboxController', 'ChannelConnectionController', 'ChannelHealthController', 'WebhookController', 'OutboundMessageController', 'TeamConversationController', 'TeamMessageController'] as $controller) {
    $check(str_contains($routes, $controller), 'routes expose '.$controller);
}
$channelRoutes = $read('routes/channels.php');
$check(str_contains($channelRoutes, 'titan-connect.company.{companyId}.conversation.{uuid}') && !str_contains($channelRoutes, 'titan-connect.tenant.'), 'realtime channels are company scoped');
$check(str_contains($routes, 'companies/{companyId}/attachments/{attachment}/provider'), 'signed provider attachment route carries company boundary');
$check(substr_count($routes, 'EnsureCompanyRouteBindings::class') >= 2, 'authenticated web and API routes centralize company-bound model enforcement');
$check(str_contains($routes, 'OperatorInboxController') && str_contains($routes, 'ProviderOnboardingController') && str_contains($routes, 'VoiceCallController'), 'v0.6 operator/onboarding/voice routes are active');
$webhookJob = $read('System/Jobs/ProcessInboundWebhookJob.php');
$check(str_contains($webhookJob, 'public readonly int $companyId') && str_contains($webhookJob, 'public readonly string $connectionUuid') && str_contains($webhookJob, '->forCompany($this->companyId)'), 'queued inbound work re-resolves company + connection UUID');
$attachmentUpload = $read('System/Attachments/AttachmentUploadService.php');
$attachmentIngest = $read('System/Attachments/InboundAttachmentIngestService.php');
$check(str_contains($attachmentUpload, 'titan-connect/company/%d/') && str_contains($attachmentIngest, 'titan-connect/company/%d/'), 'new attachment storage is physically company namespaced');
$check(is_file($root.'/tests/Feature/HostCertification/CompanyBoundaryTest.php') && is_file($root.'/docs/HOST_CERTIFICATION.md'), 'host Laravel/MySQL certification harness is packaged');

$teamMessage = $read('System/Models/TeamChat/TeamMessage.php');
$check(!str_contains($teamMessage, "'attachment_path'") && str_contains($teamMessage, 'attachments()'), 'internal messages use canonical attachment relation');

$webhookMigration = $read('database/migrations/2026_08_09_000001_create_titan_connect_core_tables.php');
$check(str_contains($webhookMigration, "['company_id', 'channel_connection_id', 'provider', 'provider_event_id']"), 'webhook replay key is connection scoped');

$waProvider = $read('System/Providers/WhatsAppProvider.php');
$check(str_contains($waProvider, 'normalizeDeliveryReceipt') && str_contains($waProvider, 'statuses.0'), 'WhatsApp delivery receipts are normalized');

$realtime = $read('System/Realtime/SafeRealtimeDispatcher.php');
$check(str_contains($realtime, 'try') && str_contains($realtime, 'catch'), 'realtime dispatch has graceful fallback');
$teamMessageService = $read('System/Services/TeamChat/TeamMessageService.php');
$check(str_contains($teamMessageService, 'SafeRealtimeDispatcher'), 'team message service uses safe realtime dispatch');

$auditSources = $read('System/Services/TeamChat/TeamMessageService.php')."\n".$read('System/Delivery/OutboundDeliveryService.php')."\n".$read('System/Http/Controllers/ChannelConnectionController.php');
$check(substr_count($auditSources, 'MessagingAuditService') >= 3, 'staff messaging and channel mutations are audit wired');

$privacy = $read('System/Services/MessagingPrivacyService.php');
$check(str_contains($privacy, 'exportActor') && str_contains($privacy, 'requestActorDeletion'), 'privacy export/delete hooks exist');
$chatbotContract = $read('System/Contracts/ChatbotMessagingBridge.php');
$check(substr_count($chatbotContract, 'int $companyId') >= 2, 'Chatbot bridge receives explicit company boundary');
$retention = $read('System/Security/ConfigRetentionPolicy.php');
$check(str_contains($retention, 'retention.companies') && str_contains($retention, 'retention.default_days'), 'retention is company configurable');

foreach ($activePhp as $relative => $source) {
    $tmp = tempnam(sys_get_temp_dir(), 'tc-lint-');
    file_put_contents($tmp, $source);
    exec('php -l '.escapeshellarg($tmp).' 2>&1', $output, $status);
    @unlink($tmp);
    $check($status === 0, 'PHP syntax: '.$relative.($status === 0 ? '' : ' :: '.implode(' ', $output)));
    $output = [];
}

foreach ($passes as $pass) {
    echo "PASS {$pass}\n";
}

if ($failures !== []) {
    foreach ($failures as $failure) {
        fwrite(STDERR, "FAIL {$failure}\n");
    }
    fwrite(STDERR, sprintf("\n%d checks failed; %d passed.\n", count($failures), count($passes)));
    exit(1);
}

echo sprintf("\nOK TitanConnect: %d checks passed.\n", count($passes));
