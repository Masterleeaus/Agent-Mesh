<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Navigation;

use Illuminate\Contracts\Container\Container;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class MagicAiMenuSynchronizer
{
    private const MENU_SERVICE = 'App\\Services\\Common\\MenuService';

    /**
     * Synchronise Rewind navigation into the legacy/current MagicAI menus table.
     *
     * Registry contributions remain the preferred path. This is an idempotent
     * compatibility/self-heal path for hosts whose navigation is still driven
     * by database rows plus MenuService caches.
     *
     * @return array{available:bool,user:bool,admin:bool,changed:bool,regenerated:bool}
     */
    public static function sync(Container $container): array
    {
        $result = [
            'available' => false,
            'user' => false,
            'admin' => false,
            'changed' => false,
            'regenerated' => false,
        ];

        try {
            if (!Schema::hasTable('menus')) {
                return $result;
            }

            $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
            if (!isset($columns['key'], $columns['route'])) {
                return $result;
            }

            $result['available'] = true;

            foreach (TitanRewindNavigation::user() as $definition) {
                $changed = self::upsert($definition, $columns, false);
                $result['user'] = true;
                $result['changed'] = $result['changed'] || $changed;
            }

            // Some MagicAI/Titan hosts use a shared menu table with no admin
            // discriminator. Do not leak an admin route into user navigation.
            if (isset($columns['is_admin'])) {
                foreach (TitanRewindNavigation::admin() as $definition) {
                    $changed = self::upsert($definition, $columns, true);
                    $result['admin'] = true;
                    $result['changed'] = $result['changed'] || $changed;
                }
            }

            if ($result['changed']) {
                $result['regenerated'] = self::regenerate($container);
            }
        } catch (Throwable) {
            // Navigation compatibility must never prevent Titan Rewind boot.
            return $result;
        }

        return $result;
    }

    /**
     * @param array<string,mixed> $definition
     * @param array<string,bool> $columns
     */
    private static function upsert(array $definition, array $columns, bool $isAdmin): bool
    {
        $key = (string) ($definition['key'] ?? '');
        $route = (string) ($definition['route'] ?? '');
        if ($key === '' || $route === '') {
            return false;
        }

        // The host `menus` table is platform navigation metadata, not tenant business state.
        $table = Schema::getConnection()->table('menus');
        $existing = $table->where('key', $key)->first();

        $parentKey = trim((string) ($definition['parent_key'] ?? ''));
        $parentId = null;
        if ($parentKey !== '' && isset($columns['parent_id'])) {
            $parentId = Schema::getConnection()->table('menus')->where('key', $parentKey)->value('id');
            if ($parentId === null) {
                return false;
            }
        }

        $vendor = self::filterColumns([
            'parent_id' => $parentId,
            'route' => $route,
            'route_slug' => null,
            'label' => (string) ($definition['label'] ?? 'Titan Rewind'),
            'icon' => (string) ($definition['icon'] ?? 'tabler-history-toggle'),
            'svg' => null,
            'params' => '[]',
            'type' => (string) ($definition['type'] ?? 'item'),
            'badge' => null,
            // A NULL database marker avoids an undocumented MarketplaceHelper
            // visibility rule hiding custom Titan extensions on legacy hosts.
            'extension' => null,
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
            'custom_menu' => 0,
            'is_admin' => $isAdmin ? 1 : 0,
        ], $columns);

        if ($existing === null) {
            $insert = $vendor;
            $insert['key'] = $key;
            if (isset($columns['order'])) $insert['order'] = (int) ($definition['order'] ?? 88);
            if (isset($columns['is_active'])) $insert['is_active'] = 1;
            if (isset($columns['created_at'])) $insert['created_at'] = now();
            if (isset($columns['updated_at'])) $insert['updated_at'] = now();
            Schema::getConnection()->table('menus')->insert($insert);
            return true;
        }

        $updates = [];
        foreach ($vendor as $column => $desired) {
            $current = $existing->{$column} ?? null;
            if (!self::equivalent($current, $desired)) {
                $updates[$column] = $desired;
            }
        }

        if ($updates === []) {
            return false;
        }

        // Preserve administrator-controlled order and enabled/disabled state.
        if (isset($columns['updated_at'])) $updates['updated_at'] = now();
        Schema::getConnection()->table('menus')->where('key', $key)->update($updates);
        return true;
    }

    /**
     * @param array<string,mixed> $values
     * @param array<string,bool> $columns
     * @return array<string,mixed>
     */
    private static function filterColumns(array $values, array $columns): array
    {
        return array_filter(
            $values,
            static fn (string $column): bool => isset($columns[$column]),
            ARRAY_FILTER_USE_KEY,
        );
    }

    private static function equivalent(mixed $current, mixed $desired): bool
    {
        if ($current === null || $desired === null) {
            return $current === $desired;
        }

        return (string) $current === (string) $desired;
    }

    private static function regenerate(Container $container): bool
    {
        if (!class_exists(self::MENU_SERVICE)) {
            return false;
        }

        try {
            $service = $container->make(self::MENU_SERVICE);
            if (method_exists($service, 'regenerate')) {
                $service->regenerate();
                return true;
            }
        } catch (Throwable) {
            return false;
        }

        return false;
    }
}
