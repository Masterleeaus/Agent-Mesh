# AI Workforce

Titan Payroll publishes Workforce schema 2.0 roles for Payroll Manager, Payroll Compliance Specialist, Payroll Reconciliation Specialist and Payroll Forecasting Agent. Role definitions, allowed tools, workflows and wizards live under `resources/workforce/`.

Read tools are tenant-scoped and bounded. Write tools map to named Payroll capabilities and route through `PayrollCommandBusGateway`; AI cannot bypass Command Bus, Risk or Assurance. Deterministic payroll/tax/compliance code owns monetary truth. Agents may inspect, explain, forecast, detect variance, create governed proposals and escalate; they may not invent rates, tax rules, approvals, payment success or compliance certification.

Autonomy is an external decision source, not an internal authority replacement. Missing Autonomy does not convert an AI suggestion into permission to mutate financial state.
