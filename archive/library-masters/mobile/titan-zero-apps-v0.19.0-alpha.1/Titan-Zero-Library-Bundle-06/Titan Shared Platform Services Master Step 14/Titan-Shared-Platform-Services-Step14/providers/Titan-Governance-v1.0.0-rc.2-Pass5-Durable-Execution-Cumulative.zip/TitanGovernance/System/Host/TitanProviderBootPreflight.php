<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Host;

final class TitanProviderBootPreflight
{
    public function inspect(string $root): array
    {
        $provider=$root.'/System/TitanGovernanceServiceProvider.php';
        $src=is_file($provider)?(string)file_get_contents($provider):'';
        $registrar=$root.'/System/Host/GovernanceMenuRegistrar.php';
        $registrarSrc=is_file($registrar)?(string)file_get_contents($registrar):'';
        $checks=[
            'provider_entrypoints'=>str_contains($src,'final class TitanGovernanceServiceProvider extends ServiceProvider')
                &&str_contains($src,'public function register(): void')
                &&str_contains($src,'public function boot(): void')
                &&str_contains($src,'public function registerKey(): string')
                &&str_contains($src,'public static function uninstall(): void'),
            'register_key'=>str_contains($src,"return 'titan-governance'"),
            'migration_loader'=>str_contains($src,'loadMigrationsFrom'),
            'scoped_config_publish'=>str_contains($src,"'titan-governance-config'"),
            'authenticated_user_routes'=>str_contains($src,"['web','auth']"),
            'admin_routes'=>str_contains($src,"['web','auth','admin']"),
            'navigation_isolated'=>str_contains($src,'private function registerNavigation(): void')&&str_contains($src,'catch (Throwable)'),
            'navigation_registrar'=>is_file($registrar)&&str_contains($registrarSrc,'final class GovernanceMenuRegistrar')&&str_contains($registrarSrc,'registerAll'),
            'navigation_sync_boot'=>str_contains($src,'try { $this->registerNavigation(); } catch (Throwable)')&&!str_contains($src,'$this->app->booted(fn () => $this->registerNavigation())'),
            'menu_browser_views'=>is_file($root.'/resources/views/control-centre.blade.php')&&is_file($root.'/resources/views/read-plane.blade.php')&&is_file($root.'/resources/views/escalations.blade.php'),
            'resources'=>is_file($root.'/config/titan-governance.php')&&is_file($root.'/routes/user.php')&&is_file($root.'/routes/admin.php')&&is_file($root.'/resources/views/index.blade.php')&&is_file($root.'/System/Host/GovernanceMenuRegistrar.php'),
        ];
        $failed=array_keys(array_filter($checks,static fn(bool $v):bool=>!$v));
        return ['status'=>$failed===[]?'PASS':'FAIL','failed_checks'=>$failed,'checks'=>$checks,'live_boot_certified'=>false];
    }
}
