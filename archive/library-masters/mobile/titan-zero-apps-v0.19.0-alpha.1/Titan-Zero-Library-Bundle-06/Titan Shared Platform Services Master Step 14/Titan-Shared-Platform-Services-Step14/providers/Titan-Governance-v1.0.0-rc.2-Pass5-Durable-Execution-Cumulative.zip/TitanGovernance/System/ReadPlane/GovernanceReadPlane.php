<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ReadPlane;

use DateTimeImmutable;
use Throwable;

final class GovernanceReadPlane
{
    public function __construct(
        private readonly GovernanceReadSourceRegistry $sources,
        private readonly TrustMapProjector $trustMap,
    ) {}

    /** @return array<string,mixed> */
    public function trustMap(int $tenantCompanyId, array $context = []): array
    {
        $source = $this->sources->get('titan-autonomy');
        if ($source === null) {
            return ['schema_version'=>'1.0','source'=>'titan-autonomy','source_status'=>'UNAVAILABLE','observed_at'=>null,'entries'=>[],'invalid_entries'=>0];
        }

        try {
            $snapshot = $source->snapshot($tenantCompanyId, $context);
            if (($snapshot['status'] ?? null) === 'HEALTHY' && $this->isStale($snapshot['observed_at'] ?? null, $context)) $snapshot['status'] = 'STALE';
            return $this->trustMap->project($snapshot);
        } catch (Throwable) {
            return ['schema_version'=>'1.0','source'=>'titan-autonomy','source_status'=>'UNAVAILABLE','observed_at'=>null,'entries'=>[],'invalid_entries'=>0,'reason'=>'SOURCE_READ_FAILED'];
        }
    }

    /** @return array<string,mixed> */
    public function autonomyEvidence(int $tenantCompanyId, array $context = []): array
    {
        $map = $this->trustMap($tenantCompanyId, $context);
        $evidence = [];
        foreach ($map['entries'] as $entry) {
            foreach (($entry['evidence'] ?? []) as $item) {
                if (!is_array($item)) continue;
                $evidence[] = array_merge([
                    'agent_id' => $entry['agent_id'] ?? '',
                    'capability' => $entry['capability'] ?? '',
                    'capability_variant' => $entry['capability_variant'] ?? 'standard',
                    'workflow' => $entry['workflow'] ?? null,
                    'context' => $entry['context'] ?? null,
                ], $item);
            }
        }

        usort($evidence, static fn (array $a, array $b): int => strcmp((string)($b['observed_at'] ?? ''), (string)($a['observed_at'] ?? '')));
        return [
            'schema_version' => '1.0',
            'source' => 'titan-autonomy',
            'source_status' => $map['source_status'],
            'tenant_company_id' => $tenantCompanyId,
            'evidence' => $evidence,
            'observed_at' => $map['observed_at'] ?? null,
        ];
    }

    /** @return array<string,mixed> */
    public function sourceHealth(int $tenantCompanyId, array $context = []): array
    {
        $rows = [];
        $overall = 'HEALTHY';

        foreach ($this->sources->all() as $key => $source) {
            try {
                $snapshot = $source->snapshot($tenantCompanyId, $context);
                $status = strtoupper((string)($snapshot['status'] ?? 'UNAVAILABLE'));
                $observedAt = $snapshot['observed_at'] ?? null;
                $reason = $snapshot['reason'] ?? null;
                if ($status === 'HEALTHY' && $this->isStale($observedAt, $context)) $status = 'STALE';
            } catch (Throwable) {
                $status = 'UNAVAILABLE';
                $observedAt = null;
                $reason = 'SOURCE_READ_FAILED';
            }

            $rows[$key] = [
                'status' => $status,
                'required' => $source->required(),
                'observed_at' => $observedAt,
                'reason' => $reason,
            ];

            if ($source->required() && in_array($status, ['UNAVAILABLE','ERROR','NOT_INSTALLED'], true)) $overall = 'UNAVAILABLE';
            elseif ($overall === 'HEALTHY' && !in_array($status, ['HEALTHY','DISABLED'], true)) $overall = 'DEGRADED';
        }

        return ['status' => $overall, 'tenant_company_id' => $tenantCompanyId, 'sources' => $rows, 'observed_at' => $this->now($context)->format(DATE_ATOM)];
    }

    private function isStale(mixed $observedAt, array $context): bool
    {
        if (!is_string($observedAt) || trim($observedAt) === '') return false;
        try { $observed = new DateTimeImmutable($observedAt); } catch (Throwable) { return true; }
        $staleAfter = max(1, (int)($context['stale_after_seconds'] ?? 300));
        return ($this->now($context)->getTimestamp() - $observed->getTimestamp()) > $staleAfter;
    }

    private function now(array $context): DateTimeImmutable
    {
        $value = $context['now'] ?? null;
        if (is_string($value) && trim($value) !== '') {
            try { return new DateTimeImmutable($value); } catch (Throwable) {}
        }
        return new DateTimeImmutable('now');
    }
}
