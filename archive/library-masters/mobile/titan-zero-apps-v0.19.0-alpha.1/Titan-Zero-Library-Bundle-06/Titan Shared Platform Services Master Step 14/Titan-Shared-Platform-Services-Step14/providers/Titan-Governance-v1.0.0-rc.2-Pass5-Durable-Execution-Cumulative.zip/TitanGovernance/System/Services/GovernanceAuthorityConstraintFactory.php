<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Services;

use InvalidArgumentException;

final class GovernanceAuthorityConstraintFactory
{
    private const DISPOSITIONS = ['PASS','CONTRACT','REQUIRE_APPROVAL','HOLD','DENY'];

    public function make(array $autonomyKey, string $disposition, ?float $ceilingScore, array $reasonCodes, array $evidenceRefs, string $policyVersion, string $traceId): array
    {
        if (!in_array($disposition, self::DISPOSITIONS, true)) throw new InvalidArgumentException('Invalid governance disposition.');
        if ($ceilingScore !== null && ($ceilingScore < 0 || $ceilingScore > 100)) throw new InvalidArgumentException('ceiling_score must be between 0 and 100.');
        if ($reasonCodes === []) throw new InvalidArgumentException('At least one reason code is required.');
        if (($disposition === 'HOLD' || $disposition === 'DENY') && $ceilingScore !== null && $ceilingScore > 0) $ceilingScore = 0.0;

        return [
            'schema_version' => '1.0',
            'constraint_id' => 'gov-' . bin2hex(random_bytes(16)),
            'autonomy_key' => $autonomyKey,
            'source' => 'titan-governance',
            'disposition' => $disposition,
            'ceiling_score' => $ceilingScore,
            'reason_codes' => array_values(array_unique(array_map('strval', $reasonCodes))),
            'evidence_refs' => array_values(array_unique(array_map('strval', $evidenceRefs))),
            'policy_version' => $policyVersion,
            'evaluated_at' => now()->toIso8601String(),
            'expires_at' => null,
            'trace_id' => $traceId,
        ];
    }
}
