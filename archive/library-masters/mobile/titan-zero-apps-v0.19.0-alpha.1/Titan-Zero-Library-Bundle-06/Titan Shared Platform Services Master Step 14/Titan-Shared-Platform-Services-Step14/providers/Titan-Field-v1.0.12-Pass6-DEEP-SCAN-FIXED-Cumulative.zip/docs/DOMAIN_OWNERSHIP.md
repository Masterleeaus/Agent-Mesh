# Titan Field Ownership

Titan Field is the authoritative writer for service requests, work orders, appointments, SchedulingKernel, dispatch, recurring service occurrences, field forms/submissions, field evidence, service areas, support/reviews/recovery, customer field assets and field-service vertical profiles.

Historical `crm_*` table names are retained intentionally during extraction to preserve installed data. A table prefix is not an ownership claim.

## Runtime boundary

Titan Field domain/application code consumes Field-owned contracts. CRM implementation dependencies are permitted only in `System/Infrastructure/Compatibility/Crm` while the extraction bridge is active.

The bridge currently supplies tenant context, audit publication, legacy automation publication and host-enable checks. Permission ownership moved to Titan Field in Pass 5; legacy CRM field permission strings are aliases only. Replacing a bridge implementation must not require changes to Titan Field domain services.

## Navigation ownership

Titan Field owns the extracted field/home-service menu surfaces and preserves the CRM-era Laravel named routes so existing plans, active-route logic, bookmarks and installed menu rows remain compatible. The registrar may reuse shared host parent families (`Customers`, `Work`, `Crew`, `Gear`) but only manages Titan Field child surfaces. Existing matching child rows are adopted by route instead of duplicated.

CRM Core must not reintroduce a second implementation or writer for these field-service surfaces.

## Pass 4 — governed capabilities and Signal ownership

Titan Field owns canonical `titan.field.*` capability definitions and the retained `titan_field_signal_outbox`. Legacy `crm.*` capability aliases and CRM automation events remain compatibility surfaces only; they do not replace the Titan Field transactional Signal record.


## Pass 5 — command and permission ownership

Titan Field owns the canonical mutation entrypoint (`FieldCommandGateway`) and retained `titan_field_command_receipts`. Existing domain services remain the authoritative writers; the gateway governs access to them rather than creating a second implementation. Legacy `crm.*` capability IDs resolve additively to canonical `titan.field.*` definitions.

Titan Field also owns its permission catalogue. Historical `crm.field_services.*`, `crm.work_orders.*`, `crm.dispatch.*` and related field permission strings remain compatibility aliases so existing routes and host Gate registrations survive extraction. CRM Core must not become the authority for new Titan Field permissions.
