<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$checks = 0;
$check = static function (bool $condition, string $message) use (&$failures, &$checks): void {
    $checks++;
    if (!$condition) $failures[] = $message;
};

$sync = $root . '/System/Navigation/MagicAiMenuSynchronizer.php';
$provider = file_get_contents($root . '/System/TitanRewindServiceProvider.php');
$registrar = file_get_contents($root . '/System/Navigation/NavigationRegistrar.php');
$nav = file_get_contents($root . '/System/Navigation/TitanRewindNavigation.php');
require_once $root . '/System/Navigation/TitanRewindNavigation.php';
$userNav = \App\Extensions\TitanRewind\System\Navigation\TitanRewindNavigation::user();

$check(is_file($sync), 'MagicAiMenuSynchronizer exists');
$syncText = is_file($sync) ? (string) file_get_contents($sync) : '';
$check(str_contains($syncText, "Schema::hasTable('menus')"), 'menu sync checks menus table availability');
$check(str_contains($syncText, "Schema::getColumnListing('menus')"), 'menu sync adapts to host menu columns');
$check(str_contains($syncText, "->table('menus')"), 'menu sync targets MagicAI menus table');
$check(str_contains($syncText, 'MenuService'), 'menu sync supports MagicAI MenuService cache regeneration');
$check(str_contains($syncText, "'is_admin'"), 'menu sync detects optional is_admin column');
$check(str_contains($syncText, 'updateOrInsert') || str_contains($syncText, 'update('), 'menu sync performs idempotent repair');
$check(str_contains($registrar, 'MagicAiMenuSynchronizer::sync'), 'navigation registrar invokes DB fallback/self-heal');
$check(str_contains($provider, 'NavigationRegistrar::register($this->app);'), 'provider invokes navigation registrar after routes');
$check(($userNav[0]['route'] ?? null) === 'dashboard.user.titan.rewind.index', 'user navigation parent targets Rewind overview route');
$check(($userNav[0]['active_condition'] ?? null) === ['dashboard.user.titan.rewind.*'], 'user navigation parent uses host-compatible active condition array');
$check(str_contains($nav, "'extension' => true"), 'user navigation uses host-compatible extension marker');
$check(str_contains($nav, "'is_active' => true"), 'user navigation declares active state');
$check(str_contains($nav, "'params' => []"), 'user navigation declares params array');

if ($failures) {
    fwrite(STDERR, "Menu self-heal verification failed ({$checks} checks):\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

echo "Menu self-heal verification PASS ({$checks}/{$checks})\n";
