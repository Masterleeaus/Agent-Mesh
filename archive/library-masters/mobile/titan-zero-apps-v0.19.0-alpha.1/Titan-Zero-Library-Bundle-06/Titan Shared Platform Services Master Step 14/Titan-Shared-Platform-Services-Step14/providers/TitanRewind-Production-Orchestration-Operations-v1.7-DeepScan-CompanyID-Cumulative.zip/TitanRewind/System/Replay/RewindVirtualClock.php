<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Replay;
use DateTimeImmutable;
use DateTimeZone;
final class RewindVirtualClock
{
    private DateTimeImmutable $current;
    public function __construct(string|DateTimeImmutable $anchor)
    {
        $this->current=$anchor instanceof DateTimeImmutable?$anchor->setTimezone(new DateTimeZone('UTC')):(new DateTimeImmutable($anchor))->setTimezone(new DateTimeZone('UTC'));
    }
    public function now(): DateTimeImmutable{return $this->current;}
    public function advanceMilliseconds(int $milliseconds): DateTimeImmutable
    {
        if($milliseconds<0)throw new \InvalidArgumentException('Virtual clock cannot move backwards.');
        if($milliseconds===0)return $this->current;
        $seconds=intdiv($milliseconds,1000);$micros=($milliseconds%1000)*1000;
        if($seconds>0)$this->current=$this->current->modify('+'.$seconds.' seconds');
        if($micros>0)$this->current=$this->current->modify('+'.$micros.' microseconds');
        return $this->current;
    }
    public function iso8601(): string{return $this->current->format('Y-m-d\TH:i:s.u\Z');}
}
