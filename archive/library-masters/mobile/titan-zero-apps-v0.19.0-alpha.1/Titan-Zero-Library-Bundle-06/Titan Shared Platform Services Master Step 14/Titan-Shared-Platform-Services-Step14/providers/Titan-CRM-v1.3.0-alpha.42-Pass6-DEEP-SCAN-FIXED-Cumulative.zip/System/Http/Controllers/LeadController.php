<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Contracts\LeadRepositoryContract;
use App\Extensions\Crm\System\Http\Requests\{StoreLeadRequest,UpdateLeadRequest};
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class LeadController extends Controller
{
    public function __construct(private LeadRepositoryContract $leads, private CrmHumanMutationGateway $mutations) {}

    public function index(Request $request)
    {
        $filters = $request->only(['q','status','qualification_status','follow_up_due','limit']);
        $records = $this->leads->search((int) $request->user()->id, $filters);
        return $request->expectsJson() ? response()->json(['data' => $records]) : view('crm::leads.index', ['leads' => $records, 'filters' => $filters]);
    }

    public function show(Request $request, string $lead)
    {
        $record = $this->leads->find((int) $request->user()->id, $lead);
        return $request->expectsJson() ? response()->json(['data' => $record]) : view('crm::leads.show', ['lead' => $record]);
    }

    public function store(StoreLeadRequest $request)
    {
        $record = $this->mutations->execute($request, 'crm.lead.create', $request->validated());
        return $request->expectsJson() ? response()->json($record, 201) : redirect()->route('dashboard.user.crm.leads.show', $record['public_id'])->with('status', 'Lead created.');
    }

    public function update(UpdateLeadRequest $request, string $lead)
    {
        $record = $this->mutations->execute($request, 'crm.lead.update', $request->validated()+['public_id'=>$lead]);
        return $request->expectsJson() ? response()->json($record) : back()->with('status', 'Lead updated.');
    }

    public function qualify(Request $request, string $lead)
    {
        $data = $request->validate(['lead_score' => 'nullable|integer|min:0|max:100', 'qualification_status' => 'nullable|in:unqualified,nurture,qualified,disqualified', 'next_follow_up_at' => 'nullable|date', 'last_contacted_at' => 'nullable|date']);
        $record = $this->mutations->execute($request, 'crm.lead.qualify', $data+['public_id'=>$lead]);
        return $request->expectsJson() ? response()->json(['data' => $record]) : back()->with('status', 'Lead qualification updated.');
    }

    public function convert(Request $request, string $lead)
    {
        $record = $this->mutations->execute($request, 'crm.lead.convert', ['public_id'=>$lead]);
        return $request->expectsJson() ? response()->json($record) : redirect()->route('dashboard.user.crm.companies.show', $record['company_public_id'])->with('status', 'Lead converted to company/contact.');
    }
}
