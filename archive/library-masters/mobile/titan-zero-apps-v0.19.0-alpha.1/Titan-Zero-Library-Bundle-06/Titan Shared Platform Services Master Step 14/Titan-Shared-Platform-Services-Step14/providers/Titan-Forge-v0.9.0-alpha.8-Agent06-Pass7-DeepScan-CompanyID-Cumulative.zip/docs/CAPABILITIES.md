# Titan Forge Capabilities

Active capabilities in v0.9.0-alpha.1:

- `forge.build.register` — register an idempotent tenant-scoped build.
- `forge.build.inspect` — inspect tenant-scoped build state/history.
- `forge.scaffold.workforce` — generate the bounded deterministic Workforce skeleton.
- `forge.validate.workforce` — validate role composition/entitlement constraints.
- `forge.sandbox.workspace` — create and manage isolated build workspaces.
- `forge.validate.artifacts` — validate ArtifactSet integrity and policy.
- `forge.validate.generated-code` — run bounded JSON/PHP/static artifact checks.
- `forge.signal.lifecycle` — emit Forge lifecycle facts through Titan Signal when available.
- `forge.risk.assess` — request release-candidate risk assessment through Titan Risk.
- `forge.shield.governance-response` — submit structured validation findings to Titan Shield.
- `forge.council.activation-assess` — inspect/selective activation metadata for compatibility.
- `forge.council.deliberate` — request bounded governed Model Council deliberation for high/critical-risk release evidence; advisory only.
- `forge.release.candidate` — persist an immutable-digest release candidate.
- `forge.release.governance-gate` — evaluate release readiness without granting deployment authority.
- `forge.rewind.source` — expose bounded, hashed, read-only Forge reconstruction evidence through the Blueprint v4.2.1 Rewind source registry; current `as_of` historical reads fail closed.

Not active: AI code generation, arbitrary process execution, direct installation/deployment, or unrestricted production mutation.

## AI Core consumer capabilities (v0.7)

- `forge.ai.plan.consume` — consumes typed AI Core plan envelopes, validates context and maps usable plans into Forge BuildPlan.
- `forge.ai.artifact.sandbox` — accepts governed AI artifact proposals through a Forge gateway and writes them only into the isolated Forge workspace with provenance.

These capabilities do not grant model-provider routing or deployment authority.
