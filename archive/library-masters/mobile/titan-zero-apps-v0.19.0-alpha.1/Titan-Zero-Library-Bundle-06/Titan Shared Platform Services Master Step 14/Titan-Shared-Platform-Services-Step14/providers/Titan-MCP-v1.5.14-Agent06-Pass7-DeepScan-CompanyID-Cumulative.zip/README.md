# Titan MCP

Titan MCP is the Titan Zero system-engine extension that exposes a governed Model Context Protocol endpoint for project intelligence, extension inspection, repository maintenance, database diagnostics/mutations, runtime diagnostics, backup verification/rollback and tightly allowlisted Artisan operations.

It is installed through Titan Extension Manager 1.7.8 under `app/Extensions/TitanMcp`. The extension is self-contained at application level: it does not require the former root `TitanMcpServiceProvider` or `php-mcp/laravel` path package. The MCP transport is owned by the extension.

Admin navigation: **Titan MCP → Overview / Tool Catalogue / Runtime Health / Backups and Recovery / Audit Ledger / Access and Permissions / Settings**. The transport defaults to `/mcp/titan` and is protected by Titan authentication, capability checks, CORS policy and layered throttles.

Every write-capable operation follows the Titan recovery invariant: authorize → lock → verified backup → write → verify → tamper-evident audit, with rollback metadata and compensation on commit/audit failure.


## Agent clients

Titan MCP 1.5.8 is tuned for ChatGPT remote MCP and Codee Chrome clients. The Super Admin Overview binds card background, foreground and border directly to the active Titan/MagicAI semantic CSS variables, while retaining the host semantic utility classes as a compatibility layer. This avoids relying on Tailwind to compile extension-only utility usage. Codee should prefer `titan_mutation_prepare` → evidence review → human approval → `titan_mutation_commit`. Version 1.5 publishes a machine-readable `titan-mcp-client-contract/1` during initialization and a `titan-mcp-tool-policy/1` for every tool, so trusted clients can classify tools without guessing from names. Preparation returns approval evidence derived from the actual verified backup manifests and commit returns post-commit evidence. ChatGPT may continue direct mutation tools when its client supplies write approval. Use the canonical `/mcp/titan` endpoint with Titan API bearer authentication. Coding agents should inspect before editing, pass `expectedSha256` for optimistic concurrency, prefer `titan_repository_replace` for small exact edits, and use `titan_repository_batch_write` for coordinated multi-file changes. Codee Chrome origins must be explicitly allowlisted as `chrome-extension://<32-character-extension-id>`.
