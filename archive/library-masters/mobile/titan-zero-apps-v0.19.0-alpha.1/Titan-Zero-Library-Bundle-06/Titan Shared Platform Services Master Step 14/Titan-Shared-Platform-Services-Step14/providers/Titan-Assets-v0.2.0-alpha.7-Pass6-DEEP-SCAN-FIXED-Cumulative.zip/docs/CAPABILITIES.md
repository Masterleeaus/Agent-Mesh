# Titan Assets Capabilities

See `resources/workforce/workforce-integration.json` and `CAPABILITIES.json` where present. Reads are non-mutating. Side effects require the governed extension execution boundary / Command Bus.
