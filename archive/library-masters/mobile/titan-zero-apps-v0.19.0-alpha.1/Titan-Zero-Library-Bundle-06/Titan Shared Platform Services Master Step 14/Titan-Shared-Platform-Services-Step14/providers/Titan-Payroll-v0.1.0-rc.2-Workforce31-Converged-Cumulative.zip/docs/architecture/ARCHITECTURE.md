# Architecture

## Runtime shape

Titan Payroll boots through `App\Extensions\TitanPayroll\System\TitanPayrollServiceProvider`. Live code is intentionally concentrated in `System/`, `Services/`, `Contracts/` and `Support/`; unreachable Worksuite-era controllers, providers, Filament/GraphQL layers, jobs/listeners/observers and host-coupled scaffolds were removed in Pass 4.

The runtime layers are: authenticated tenant context and authorization; governed mutation gateway; deterministic payroll calculation/domain services; canonical `ext_titan_payroll_*` persistence; typed external ports for Time Attendance, Communications, Command Bus, Risk, Assurance, Autonomy, Rewind and output targets; Workforce schema 2.0 tools/workflows; web/API workspaces and navigation.

## Invariants

- `tenant_company_id` is actor-derived and is applied to every tenant-owned read/write.
- Financial state changes are idempotent and high/critical writes require Risk + Assurance; AI writes require Command Bus and cannot take the local-human fallback.
- Finalized runs are immutable. Corrections are adjustments/reconciliation proposals.
- Time Attendance is consumed only through its typed approved-input port.
- Rewind and Signals receive privacy-minimized facts, never bank/tax/full-payslip payloads.
- Communications owns provider delivery; Payroll only requests and records delivery intent/status.
- No state-changing GET route is allowed.

## Failure model

Database loss is BLOCKED/UNAVAILABLE for financial writes. Optional integration loss is surfaced as DEGRADED and fail-closed where correctness requires the integration. Provider/network retries are bounded; exhaustion moves work to `attention_required` rather than looping indefinitely.
