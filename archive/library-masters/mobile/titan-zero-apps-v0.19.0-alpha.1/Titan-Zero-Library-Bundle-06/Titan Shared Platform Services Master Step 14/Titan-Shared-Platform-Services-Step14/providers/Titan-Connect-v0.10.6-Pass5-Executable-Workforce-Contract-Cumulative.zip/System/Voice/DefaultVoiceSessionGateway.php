<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Voice;

use App\Extensions\TitanConnect\System\Contracts\VoiceSessionGateway;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\VoiceCall;
use RuntimeException;

final class DefaultVoiceSessionGateway implements VoiceSessionGateway
{
    public function __construct(private readonly OpenAiRealtimeVoiceGateway $openAi, private readonly ElevenLabsVoiceGateway $elevenLabs) {}

    public function start(VoiceCall $call, ChannelConnection $connection, array $credentials): array
    {
        $settings = is_array($connection->settings) ? $connection->settings : [];
        $engine = strtolower(trim((string) ($settings['engine'] ?? $credentials['engine'] ?? 'openai_realtime')));
        return match ($engine) {
            'openai', 'openai_realtime' => $this->openAi->start($credentials),
            'elevenlabs', 'eleven_labs' => $this->elevenLabs->start($credentials),
            default => throw new RuntimeException('Unsupported voice session engine.'),
        };
    }
}
