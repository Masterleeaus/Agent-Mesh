# Existing Model Council reuse

The complete supplied original Model Council source remains preserved byte-for-byte in `legacy-source/` for audit and rollback comparison.

As of Titan Model Council v0.3.0, the working engine has also been copied into the active Titan namespace under `System/Compatibility/Legacy/` with only compatibility-focused changes:

1. namespace migration into Titan Model Council,
2. response-model namespace migration,
3. registration-key compatibility with `titan-model-council`, and
4. a hardened response-acceptance controller replacing the unsafe legacy mutation path.

The original source under `legacy-source/` is not auto-loaded. It is retained strictly as preservation evidence/reference.
