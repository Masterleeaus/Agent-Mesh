<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Health;

use InvalidArgumentException;

final readonly class RewindHealthSnapshot
{
    public function __construct(private string $status, private array $checks, private string $observedAt)
    {
        if (!in_array($status,['HEALTHY','DEGRADED','UNAVAILABLE','DISABLED','MAINTENANCE','DRAINING'],true)) throw new InvalidArgumentException('Invalid Rewind health status.');
    }
    public function toArray(): array { return ['status'=>$this->status,'checks'=>$this->checks,'observed_at'=>$this->observedAt]; }
}
