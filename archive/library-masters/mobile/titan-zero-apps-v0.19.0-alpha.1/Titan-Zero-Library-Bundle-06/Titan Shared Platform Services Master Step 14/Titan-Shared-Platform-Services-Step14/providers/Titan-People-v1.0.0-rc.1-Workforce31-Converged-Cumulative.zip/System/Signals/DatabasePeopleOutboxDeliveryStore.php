<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Signals;

use App\Extensions\TitanPeople\System\Models\PeopleSignalOutboxRecord;

final class DatabasePeopleOutboxDeliveryStore implements PeopleOutboxDeliveryStore
{
    /** @return list<PeopleOutboxEvent> */
    public function pending(int $limit): array
    {
        $rows = PeopleSignalOutboxRecord::query()
            ->whereNull('published_at')
            ->orderBy('id')
            ->limit(max(1, min($limit, 250)))
            ->cursor();

        $events = [];
        foreach ($rows as $row) {
            $events[] = PeopleOutboxEvent::make(
                (int) $row->tenant_company_id,
                (string) $row->event_type,
                (string) $row->aggregate_ref,
                (array) $row->payload,
                (string) $row->trace_id,
                (string) $row->correlation_id,
                (string) $row->causation_id,
                (string) $row->idempotency_key,
                (string) $row->occurred_at
            );
        }

        return $events;
    }

    public function markPublished(int $tenantCompanyId, string $eventId, string $receiptId): void
    {
        PeopleSignalOutboxRecord::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->where('event_id', $eventId)
            ->whereNull('published_at')
            ->update([
                'published_at' => now(),
                'delivery_receipt_id' => $receiptId,
                'last_error' => null,
            ]);
    }

    public function markFailed(int $tenantCompanyId, string $eventId, string $error): void
    {
        PeopleSignalOutboxRecord::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->where('event_id', $eventId)
            ->whereNull('published_at')
            ->increment('attempts', 1, ['last_error' => $error]);
    }
}
