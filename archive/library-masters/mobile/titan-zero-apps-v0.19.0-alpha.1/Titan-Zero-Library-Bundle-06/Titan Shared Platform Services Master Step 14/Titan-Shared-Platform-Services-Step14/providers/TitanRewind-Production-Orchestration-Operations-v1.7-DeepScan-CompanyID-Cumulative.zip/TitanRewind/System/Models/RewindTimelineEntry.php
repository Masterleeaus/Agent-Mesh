<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindTimelineEntry extends Model
{
    protected $table = 'titan_rewind_timeline_entries';
    protected $fillable = [
        'entry_uuid','tenant_company_id','case_id','event_id','trace_id','correlation_id','causation_id','source_engine','event_type',
        'sequence','tier','lane','title','summary','risk_level','metadata','occurred_at',
    ];
    protected $casts = ['tenant_company_id'=>'integer','case_id'=>'integer','sequence'=>'integer','tier'=>'integer','metadata'=>'array','occurred_at'=>'datetime'];
}
