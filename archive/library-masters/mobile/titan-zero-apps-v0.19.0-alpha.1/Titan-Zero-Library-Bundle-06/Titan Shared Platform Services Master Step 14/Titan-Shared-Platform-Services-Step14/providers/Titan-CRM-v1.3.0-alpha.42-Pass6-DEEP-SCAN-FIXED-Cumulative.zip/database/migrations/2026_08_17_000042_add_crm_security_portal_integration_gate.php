<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('crm_portal_grants')) Schema::table('crm_portal_grants', function (Blueprint $t): void {
            if (! Schema::hasColumn('crm_portal_grants','identity_verification_hash')) $t->char('identity_verification_hash',64)->nullable();
            if (! Schema::hasColumn('crm_portal_grants','identity_verification_hint')) $t->string('identity_verification_hint',16)->nullable();
            if (! Schema::hasColumn('crm_portal_grants','identity_verification_expires_at')) $t->dateTime('identity_verification_expires_at')->nullable()->index('crm_portal_verify_exp_idx');
            if (! Schema::hasColumn('crm_portal_grants','identity_verification_attempts')) $t->unsignedSmallInteger('identity_verification_attempts')->default(0);
            if (! Schema::hasColumn('crm_portal_grants','identity_locked_at')) $t->dateTime('identity_locked_at')->nullable();
        });

        if (! Schema::hasTable('crm_portal_sessions')) {
            Schema::create('crm_portal_sessions', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('tenant_company_id')->index(); $t->unsignedBigInteger('user_id')->index();
                $t->char('portal_grant_public_id',26)->index(); $t->char('session_hash',64); $t->char('ip_hash',64)->nullable(); $t->char('user_agent_hash',64)->nullable();
                $t->string('identity_method',40)->nullable(); $t->dateTime('identity_verified_at')->nullable()->index(); $t->dateTime('last_seen_at')->nullable()->index();
                $t->dateTime('expires_at')->index(); $t->dateTime('revoked_at')->nullable()->index(); $t->json('metadata')->nullable(); $t->timestamps();
                $t->unique(['portal_grant_public_id','session_hash'],'crm_portal_session_unique');
            });
        }

        if (Schema::hasTable('crm_portal_files')) Schema::table('crm_portal_files', function (Blueprint $t): void {
            if (! Schema::hasColumn('crm_portal_files','quarantine_storage_key')) $t->string('quarantine_storage_key',500)->nullable()->index('crm_portal_quarantine_idx');
            if (! Schema::hasColumn('crm_portal_files','scan_status')) $t->string('scan_status',30)->default('pending')->index();
            if (! Schema::hasColumn('crm_portal_files','scan_engine')) $t->string('scan_engine',120)->nullable();
            if (! Schema::hasColumn('crm_portal_files','scanned_at')) $t->dateTime('scanned_at')->nullable()->index();
        });

        if (Schema::hasTable('crm_api_keys')) Schema::table('crm_api_keys', function (Blueprint $t): void {
            if (! Schema::hasColumn('crm_api_keys','allowed_ip_cidrs')) $t->json('allowed_ip_cidrs')->nullable();
            if (! Schema::hasColumn('crm_api_keys','not_before_at')) $t->dateTime('not_before_at')->nullable()->index('crm_api_not_before_idx');
            if (! Schema::hasColumn('crm_api_keys','rotation_family_public_id')) $t->char('rotation_family_public_id',26)->nullable()->index('crm_api_rotation_family_idx');
        });

        if (Schema::hasTable('crm_webhooks')) Schema::table('crm_webhooks', function (Blueprint $t): void {
            if (! Schema::hasColumn('crm_webhooks','secret_version')) $t->unsignedInteger('secret_version')->default(1);
            if (! Schema::hasColumn('crm_webhooks','previous_secret_ciphertext')) $t->text('previous_secret_ciphertext')->nullable();
            if (! Schema::hasColumn('crm_webhooks','previous_secret_version')) $t->unsignedInteger('previous_secret_version')->nullable();
            if (! Schema::hasColumn('crm_webhooks','previous_secret_expires_at')) $t->dateTime('previous_secret_expires_at')->nullable()->index('crm_webhook_prev_secret_idx');
            if (! Schema::hasColumn('crm_webhooks','secret_rotated_at')) $t->dateTime('secret_rotated_at')->nullable();
        });
        if (Schema::hasTable('crm_webhook_deliveries')) Schema::table('crm_webhook_deliveries', function (Blueprint $t): void {
            if (! Schema::hasColumn('crm_webhook_deliveries','nonce')) $t->char('nonce',32)->nullable()->unique('crm_webhook_nonce_unique');
            if (! Schema::hasColumn('crm_webhook_deliveries','secret_version')) $t->unsignedInteger('secret_version')->default(1);
            if (! Schema::hasColumn('crm_webhook_deliveries','dead_lettered_at')) $t->dateTime('dead_lettered_at')->nullable()->index('crm_webhook_dead_at_idx');
            if (! Schema::hasColumn('crm_webhook_deliveries','response_hash')) $t->char('response_hash',64)->nullable();
            if (! Schema::hasColumn('crm_webhook_deliveries','manual_retry_count')) $t->unsignedInteger('manual_retry_count')->default(0);
        });

        if (Schema::hasTable('crm_import_batches')) Schema::table('crm_import_batches', function (Blueprint $t): void {
            if (! Schema::hasColumn('crm_import_batches','impact_hash')) $t->char('impact_hash',64)->nullable()->index('crm_import_impact_hash_idx');
            if (! Schema::hasColumn('crm_import_batches','confirmed_impact_hash')) $t->char('confirmed_impact_hash',64)->nullable();
            if (! Schema::hasColumn('crm_import_batches','committed_at')) $t->dateTime('committed_at')->nullable()->index('crm_import_committed_idx');
        });
        if (! Schema::hasTable('crm_import_rollback_journal')) {
            Schema::create('crm_import_rollback_journal', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('tenant_company_id')->index(); $t->unsignedBigInteger('user_id')->index();
                $t->char('batch_public_id',26)->index(); $t->string('resource_type',60)->index(); $t->char('resource_public_id',26)->index();
                $t->string('operation',30)->default('created'); $t->char('before_hash',64)->nullable(); $t->longText('before_snapshot')->nullable();
                $t->char('after_hash',64)->nullable(); $t->longText('after_snapshot')->nullable(); $t->string('rollback_status',30)->default('pending')->index();
                $t->dateTime('rolled_back_at')->nullable(); $t->text('last_error')->nullable(); $t->timestamps();
                $t->unique(['tenant_company_id','batch_public_id','resource_public_id'],'crm_import_rollback_unique');
            });
        }
        // Legacy indefinite API keys are bounded on upgrade; legacy portal sessions cannot be identity-verified, so links are revoked and must be reissued.
        if (Schema::hasTable('crm_api_keys')) {
            DB::table('crm_api_keys')->whereNull('expires_at')->whereNull('revoked_at')->update(['expires_at'=>now()->addDays(90),'updated_at'=>now()]);
            DB::table('crm_api_keys')->whereNull('rotation_family_public_id')->update(['rotation_family_public_id'=>DB::raw('public_id'),'updated_at'=>now()]);
        }
        if (Schema::hasTable('crm_portal_grants')) {
            DB::table('crm_portal_grants')->whereNull('revoked_at')->whereIn('status',['invited','active'])->update(['status'=>'revoked','revoked_at'=>now(),'updated_at'=>now()]);
        }
        if (Schema::hasTable('crm_portal_files')) {
            DB::table('crm_portal_files')->where('status','available')->where('scan_status','pending')->update(['status'=>'quarantined','scan_status'=>'legacy_unverified','updated_at'=>now()]);
        }

        if (! Schema::hasTable('crm_export_audit_journal')) {
            Schema::create('crm_export_audit_journal', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('tenant_company_id')->index(); $t->unsignedBigInteger('user_id')->index();
                $t->string('resource_type',60)->index(); $t->unsignedInteger('record_count')->default(0); $t->char('sha256',64); $t->json('export_manifest');
                $t->dateTime('exported_at')->index(); $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        // Security audit evidence and rotation lineage are intentionally retained on rollback.
    }
};
