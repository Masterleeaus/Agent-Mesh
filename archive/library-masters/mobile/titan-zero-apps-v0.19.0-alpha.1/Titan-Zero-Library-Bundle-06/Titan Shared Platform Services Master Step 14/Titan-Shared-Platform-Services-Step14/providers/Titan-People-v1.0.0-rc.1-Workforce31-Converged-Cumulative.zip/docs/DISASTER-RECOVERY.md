# Disaster recovery

Back up extension-owned `titan_people_*` tables and the configured private `private/titan-people/` document root as one tenant-aware logical domain.

Restore order:

1. Restore database tables without reopening People writes.
2. Restore private document objects and verify sampled revision SHA-256 values.
3. Validate tenant indexes, immutable employment-event uniqueness, leave-ledger/cache reconciliation and outbox idempotency uniqueness.
4. Resume outbox delivery; unpublished rows are replayable until an external receipt is persisted.
5. Run `titan-people:host-sync`, then smoke-test two tenant contexts before reopening writes.

Target RPO is 60 minutes and target RTO is 240 minutes until exact-host production evidence establishes stronger objectives.
