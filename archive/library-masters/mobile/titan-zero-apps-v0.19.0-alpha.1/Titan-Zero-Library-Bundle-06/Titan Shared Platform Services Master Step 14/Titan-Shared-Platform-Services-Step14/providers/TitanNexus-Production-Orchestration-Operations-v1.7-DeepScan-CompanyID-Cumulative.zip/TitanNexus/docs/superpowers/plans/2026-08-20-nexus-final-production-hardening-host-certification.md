# Titan Nexus Final Production Hardening & Host Certification Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Produce a host-ready Titan Nexus `1.0.0-rc.1` cumulative package with Step-10 host adapters, deterministic package certification, menu projection, machine-readable host certification evidence, and no false live-host certification claims.

**Architecture:** Host compatibility is isolated under `System/Host`; core compiler/provisioning domain behavior is unchanged. Menu registration uses the modern registry first and a narrowly scoped MagicAI fallback. Certification artifacts distinguish package evidence from live host evidence.

**Tech Stack:** PHP 8.2+/8.3 target, Laravel 10, MagicAI 10+, Installer 1.7.8, MySQL strict mode, JSON Schema, standalone PHP verification.

**Spec:** `docs/superpowers/specs/2026-08-20-nexus-final-production-hardening-host-certification-design.md`

## Global Constraints
- Manifest schema remains `2.2` and architecture profile remains `configuration-orchestrator`.
- Compiler version remains exactly `0.5.0`.
- No direct foreign Titan-engine table writes.
- Existing three migrations remain byte-identical.
- Installer ZIP root is flat.
- `integrity.files` covers every regular packaged file except `extension.json`.
- Live host stages remain `NOT_RUN` unless executed against the exact target host.

---

### Task 1: Host compatibility contracts
**Files:** Create `System/Host/TitanInstallerManifestContract.php`, `TitanHostAuthorizationAdapter.php`, `TitanMySqlMigrationCompatibility.php`, `TitanPackageIntegrityBuilder.php`; test `tests/standalone-host-certification-check.php`.

- [ ] Write failing standalone assertions for the five host compatibility contracts and exact host profile.
- [ ] Run the standalone test and confirm failure because the classes/artifacts do not exist.
- [ ] Implement the minimal host compatibility contracts copied/adapted from the canonical Blueprint Step-10 rules.
- [ ] Re-run and confirm the host-contract section passes.

### Task 2: Navigation self-healing
**Files:** Create `System/Host/TitanMenuCompatibilityAdapter.php`, `System/Host/NexusMenuRegistrar.php`; modify `System/TitanNexusServiceProvider.php`; test `tests/standalone-host-certification-check.php`.

- [ ] Add failing assertions for one parent and nine named user children, modern registry preference, legacy MagicAI fallback, and preservation of order/enabled state.
- [ ] Run and confirm failure.
- [ ] Implement menu definitions and boot-time registration through the compatibility adapter.
- [ ] Re-run and confirm navigation contract passes.

### Task 3: Exact-host evidence artifacts
**Files:** Create `certification/exact-host-profile.v1.json`, `certification/host-certification-report.json`, `certification/host-certification-report.schema.json`, `tools/verify_nexus_package.php`, `tools/exact_host_certification.php`, `docs/HOST-CERTIFICATION.md`.

- [ ] Add failing assertions for the nine-stage certification ladder and live-stage `NOT_RUN` policy.
- [ ] Run and confirm failure.
- [ ] Implement machine-readable profile/report and verification tools.
- [ ] Re-run and confirm certification artifact checks pass.

### Task 4: Release metadata and package hardening
**Files:** Modify `config/titan-nexus.php`, `System/Services/NexusManager.php`, `extension.manifest.json`, `extension.json`, `README.md`, `CHANGELOG.md`, package tests.

- [ ] Update tests to require `1.0.0-rc.1`, host-ready capability, and compiler `0.5.0` invariance.
- [ ] Run affected tests and confirm expected version failures.
- [ ] Update runtime metadata/documentation without changing compiler semantics.
- [ ] Run all standalone tests, PHP lint, JSON parse, Blueprint manifest/interface/package/architecture verification, MySQL migration scan, and migration byte-comparison.
- [ ] Rebuild Installer 1.7.8 integrity map, create flat cumulative ZIP, clean re-extract, and repeat all verification against exact packaged bytes.
