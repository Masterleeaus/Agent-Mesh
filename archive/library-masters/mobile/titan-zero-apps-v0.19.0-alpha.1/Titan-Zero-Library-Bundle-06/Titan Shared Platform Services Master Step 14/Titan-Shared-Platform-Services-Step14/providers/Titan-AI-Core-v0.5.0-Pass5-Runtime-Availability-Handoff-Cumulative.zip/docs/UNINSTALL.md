# Uninstall
Uninstall removes published extension configuration only. Extension-owned database state is retained by default.
