# Installation

## Package location

Extract the `TitanAI` directory to:

`app/Extensions/TitanAI`

The folder and namespace are case-sensitive on Linux.

## MagicAI registration

Registration key:

`titan-ai`

Provider:

`App\Extensions\TitanAI\System\TitanAIServiceProvider`

If the target MagicAI host still uses `MarketplaceServiceProvider::$extensionProviders`, add:

```php
'titan-ai' => \App\Extensions\TitanAI\System\TitanAIServiceProvider::class,
```

If the host already discovers validated `extension.manifest.json` providers, no static provider-map change is required.

## Configuration

The service provider publishes these files under the shared `extension` publish tag:

- `config/titan-ai.php`
- `config/titan-ai-governance.php`

Run the host's normal extension install/publish and migration workflow. TitanAI migrations are forward-safe and guard table/column creation. v1.3.0 also converts legacy TitanAI `tenant_id` columns to the canonical `company_id` boundary after validating their values.

## Required host validation before production traffic

Because the supplied build inputs did not include a complete target MagicAI application, perform these checks in the deployment host before enabling traffic:

1. confirm the marketplace lifecycle interface namespaces used by `TitanAIServiceProvider`;
2. confirm provider discovery/registration;
3. run `php artisan migrate` in a staging database;
4. resolve `TitanAIRuntimeContract` from the Laravel container;
5. confirm governance routes and host abilities;
6. bind canonical WorkCore if business actions are required;
7. verify the authenticated host user exposes a valid `company_id`;
8. run one cross-company isolation test and one governed write/approval test.

Do not treat `compatibility.magicai: "*"` as a compatibility guarantee; it deliberately means the exact host version has not yet been supplied for certification.
