# Phase 6.1 — Settings Surfaces

- Added Super Admin Interaction Engine settings screen.
- Added company owner/admin Interaction settings screen.
- Added personal user preferences screen/API.
- Added PWA settings API and effective presentation preferences.
- Added platform and company settings persistence tables.
- Applied persisted settings to engine enablement, cache TTL, offline behavior, sync batching and LocalBrain availability/confidence.
- Preserved `company_id` as tenant boundary.
- Kept capability authority and external-domain configuration out of direct settings CRUD.
- Secrets remain status-only and are never persisted through settings forms.
