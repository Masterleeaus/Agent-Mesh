# CRM 1.3.0-alpha.17 — Context-Aware Global + New

- Repurposes MagicAI's existing top-right `+ New` control on internal CRM operations pages without modifying MagicAI core files.
- Uses the page's declared Interaction Engine journey as the primary action when present.
- Adds related page/domain actions in a dropdown, filtered by the authenticated user's CRM capability permission.
- Customers: Customer, Contact, Support Case and Customer Hub access.
- Leads: Lead, Opportunity, Quote, Estimate and Pipeline.
- Work: Job, Service Request, Project, Task, Recurring Work and Service Location.
- Money: Invoice, Quote, Estimate, Payment and Bookkeeping Transaction.
- Crew: Appointment, Dispatch Assignment, Calendar Event and Time Entry.
- Gear: Inventory Item, Supplier, Purchase Order, Tool, Equipment, Vehicle and Maintenance.
- Automate: Automation, API Key and Webhook.
- Settings: Custom Field and Tag.
- Detail pages carry existing customer/job/lead/document context into related create journeys.
- The host adapter discovers only the shell-level `New`/`+ New` control outside CRM page content and leaves local buttons untouched as compatibility fallbacks.
- Every action remains a CSRF-protected POST into `dashboard.user.crm.interactions.start`; there is no direct capability/CommandBus browser path.
