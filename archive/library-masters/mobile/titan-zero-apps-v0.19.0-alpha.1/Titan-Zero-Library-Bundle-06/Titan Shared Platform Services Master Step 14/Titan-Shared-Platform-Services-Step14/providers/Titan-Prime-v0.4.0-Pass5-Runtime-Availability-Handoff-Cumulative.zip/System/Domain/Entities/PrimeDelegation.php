<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Entities;

use App\Extensions\TitanPrime\System\Domain\Enums\PrimeDelegationStatus;
use InvalidArgumentException;

final readonly class PrimeDelegation
{
    /** @param array<string,mixed> $input */
    public function __construct(
        public string $delegationId,
        public string $missionId,
        public string $targetEngine,
        public string $capability,
        public string $idempotencyKey,
        public array $input = [],
        public PrimeDelegationStatus $status = PrimeDelegationStatus::Proposed,
    ) {
        foreach ([
            'delegation id' => $delegationId,
            'mission id' => $missionId,
            'target engine' => $targetEngine,
            'capability' => $capability,
            'idempotency key' => $idempotencyKey,
        ] as $name => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException(sprintf('%s is required.', ucfirst($name)));
            }
        }
    }
}
