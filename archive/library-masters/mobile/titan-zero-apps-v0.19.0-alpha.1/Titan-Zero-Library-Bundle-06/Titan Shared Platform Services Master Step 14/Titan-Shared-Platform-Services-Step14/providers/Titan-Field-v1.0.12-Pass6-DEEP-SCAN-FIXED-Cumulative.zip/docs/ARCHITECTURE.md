# Titan Field Architecture

Canonical profile: `business-domain`. Domain state remains extension-owned; Titan AI Workforce owns staff identity, roles, hierarchy, assignments and work items. Workforce interactions are authority-neutral until independently authorized/governed.
