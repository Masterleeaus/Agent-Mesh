<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$passes = [];
$read = static fn (string $path): string => is_file($root.'/'.$path) ? (string) file_get_contents($root.'/'.$path) : '';
$check = static function (bool $condition, string $name) use (&$passes, &$failures): void {
    if ($condition) {
        $passes[] = $name;
    } else {
        $failures[] = $name;
    }
};

$company = $read('System/Security/AuthenticatedCompanyContext.php');
$directory = $read('System/Security/DatabaseCompanyActorDirectory.php');
$teamPolicy = $read('System/Policies/TeamChat/TeamConversationPolicy.php');
$conversationService = $read('System/Services/TeamChat/TeamConversationService.php');
$businessChannels = $read('System/Services/TeamChat/BusinessChannelService.php');
$messages = $read('System/Services/TeamChat/TeamMessageService.php');
$channelPolicy = $read('System/Policies/ChannelAccessPolicy.php');
$webhooks = $read('System/Webhooks/InboundWebhookService.php');
$delivery = $read('System/Delivery/OutboundDeliveryService.php');
$registry = $read('System/Providers/ProviderRegistry.php');
$health = $read('System/Services/ChannelHealthService.php');
$provider = $read('System/TitanConnectServiceProvider.php');
$connection = $read('System/Models/ChannelConnection.php');
$workCore = $read('System/Security/DenyAllWorkCoreAuthorizationGateway.php');
$attachments = $read('System/Attachments/AttachmentValidator.php');
$privacy = $read('System/Services/MessagingPrivacyService.php');
$realtime = $read('System/Realtime/SafeRealtimeDispatcher.php');
$migration = $read('database/migrations/2026_08_09_000001_create_titan_connect_core_tables.php');

$check(str_contains($company, '$companyId = $user->company_id;') && !str_contains($company, 'tenant_id') && !str_contains($company, '?? $user->getAuthIdentifier'), 'FEATURE company context resolves only authenticated company_id and fails closed');
$check(str_contains($directory, "Schema::hasColumn('users', 'company_id')") && str_contains($directory, "where('company_id', \$companyId)") && str_contains($directory, 'outside the active company'), 'FEATURE cross-company participant denial is enforced');
$check(str_contains($teamPolicy, "['owner', 'admin']") || str_contains($teamPolicy, "'owner', 'admin'"), 'UNIT internal owner/admin management role gate exists');
$check(str_contains($conversationService, "role when 'admin'") && str_contains($conversationService, "role' => 'owner'"), 'FEATURE group ownership transfers on owner leave');
$check(str_contains($businessChannels, 'assertLinkedEntity') && str_contains($businessChannels, 'assertUsersBelongToCompany'), 'FEATURE channel joins recheck company and WorkCore-linked access');
$check(str_contains($messages, 'firstOrCreate') && str_contains($messages, 'TeamMessageReadEvent'), 'FEATURE read receipts are idempotent');
$check(str_contains($channelPolicy, "'moderator'") && str_contains($channelPolicy, "'viewer'"), 'UNIT external channel role capabilities are explicit');
$check(str_contains($webhooks, 'verifyWebhook') && str_contains($webhooks, 'firstOrCreate'), 'FEATURE webhook signature verification and idempotency exist');
$check(str_contains($migration, "['company_id', 'channel_connection_id', 'provider', 'provider_event_id']"), 'FEATURE webhook replay key is channel-connection scoped');
$check(str_contains($delivery, "where('idempotency_key', \$idempotencyKey)") && str_contains($delivery, 'maxAttempts'), 'FEATURE outbound idempotency and bounded retry exist');
$check(str_contains($delivery, 'next_attempt_at') && str_contains($delivery, '2 **'), 'UNIT bounded exponential retry metadata exists');
foreach (['WhatsAppProvider', 'MessengerProvider', 'InstagramProvider', 'TelegramProvider', 'SmsProvider', 'PushProvider'] as $class) {
    $check(str_contains($registry, 'new '.$class.'('), 'UNIT provider registry includes '.$class);
}
$check(str_contains($health, 'health(') && str_contains($health, 'last_health_checked_at'), 'FEATURE provider health hook updates connection health timestamp');
$check(str_contains($provider, 'ChatbotMessagingBridge::class') && str_contains($provider, 'EventChatbotMessagingBridge::class'), 'BOUNDARY Chatbot bridge is interface-bound');
$check(str_contains($provider, 'MobilePushGateway::class') && str_contains($provider, 'EventMobilePushGateway::class'), 'BOUNDARY Mobile push is interface-bound without device registry ownership');
$check(str_contains($workCore, 'throw new AccessDeniedHttpException'), 'BOUNDARY linked WorkCore authorization fails closed by default');
$check(str_contains($connection, "protected \$hidden = ['credential_reference']"), 'SECURITY credential references are hidden from public model serialization');
$check(str_contains($attachments, 'max_bytes') && str_contains($attachments, 'allowed_mime_types') && str_contains($attachments, 'scanMetadata'), 'SECURITY attachment size/type/scanner hooks exist');
$check(str_contains($privacy, 'exportActor') && str_contains($privacy, 'requestActorDeletion'), 'PRIVACY export and deletion-request hooks exist');
$check(str_contains($realtime, 'catch (\\Throwable') && str_contains($realtime, 'return false'), 'RESILIENCE realtime failure falls back without rolling back persisted messaging');
$check(!str_contains($provider, 'donor/'), 'PACKAGING runtime provider does not boot donor trees');

foreach ($passes as $pass) {
    echo "PASS {$pass}\n";
}
if ($failures !== []) {
    foreach ($failures as $failure) {
        fwrite(STDERR, "FAIL {$failure}\n");
    }
    fwrite(STDERR, sprintf("\n%d failed; %d passed.\n", count($failures), count($passes)));
    exit(1);
}

echo sprintf("\nOK Titan Connect contract suite: %d passed.\n", count($passes));
