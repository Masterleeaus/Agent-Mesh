<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanRewind\System\Replay\RejectingReplayCommandGateway;
use App\Extensions\TitanRewind\System\Replay\RewindArtifactResolverRegistry;
use App\Extensions\TitanRewind\System\Replay\RewindReplayRequest;
use App\Extensions\TitanRewind\System\Replay\RewindStructuralComparisonEngine;
use App\Extensions\TitanRewind\System\Reconstruction\RewindDiffService;
use App\Extensions\TitanRewind\System\Support\CanonicalJson;
use App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer;
use LogicException;
use PHPUnit\Framework\TestCase;

final class ComparativeReplayContractTest extends TestCase
{
    public function test_model_comparison_is_structural_deterministic_and_non_mutating(): void
    {
        $request = RewindReplayRequest::fromArray([
            'mode'=>'model-compare','target_model'=>['provider'=>'p2','model'=>'m2','version'=>'2'],
        ], new RewindPayloadSanitizer([]));
        $engine = new RewindStructuralComparisonEngine(new CanonicalJson(), new RewindDiffService(), new RewindArtifactResolverRegistry(), new RejectingReplayCommandGateway());
        $result = $engine->compare([
            'tenant_company_id'=>4,'trace_id'=>'11111111-1111-4111-8111-111111111111','event_count'=>1,
            'events'=>[['event_id'=>'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','sequence'=>1,'event_type'=>'decision.created','source_engine'=>'core','model_provider'=>'p1','model_name'=>'m1','model_version'=>'1']],
            'forensics'=>['integrity'=>['status'=>'passed']],
        ], $request);
        self::assertFalse($result['mutation_attempted']);
        self::assertFalse($result['decision_reexecution_performed']);
        self::assertSame('m2',$result['candidate']['events'][0]['model_name']);
        self::assertMatchesRegularExpression('/^[a-f0-9]{64}$/',$result['result_hash']);
    }

    public function test_replay_command_gateway_always_rejects_authoritative_execution(): void
    {
        $this->expectException(LogicException::class);
        (new RejectingReplayCommandGateway())->dispatch('invoice.update',['invoice_id'=>8]);
    }
}
