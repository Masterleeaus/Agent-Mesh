<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_commands')) {
            Schema::create('titan_commands', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->string('command_id', 64);
                $table->string('idempotency_key', 191)->index();
                $table->string('request_hash', 64);
                $table->string('capability', 191)->index();
                $table->string('trace_id', 191)->nullable()->index();
                $table->string('correlation_id', 191)->nullable()->index();
                $table->string('causation_id', 191)->nullable()->index();
                $table->string('root_causation_id', 191)->nullable()->index();
                $table->string('actor_type', 64)->nullable();
                $table->string('actor_id', 191)->nullable()->index();
                $table->string('service_id', 191)->nullable()->index();
                $table->boolean('prepared_offline')->default(false);
                $table->string('expected_entity_version', 191)->nullable();
                $table->string('status', 32)->index();
                $table->unsignedInteger('last_sequence')->default(1);
                $table->timestamp('received_at')->nullable();
                $table->timestamp('completed_at')->nullable();
                $table->timestamp('refused_at')->nullable();
                $table->timestamp('failed_at')->nullable();
                $table->timestamps();
                $table->unique(['tenant_company_id', 'command_id'], 'tcb_commands_tenant_command_unique');
            });
        }

        if (! Schema::hasTable('titan_command_attempts')) {
            Schema::create('titan_command_attempts', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->string('command_id', 64)->index();
                $table->unsignedInteger('sequence');
                $table->string('state', 32)->index();
                $table->string('reason_code', 191)->nullable()->index();
                $table->string('trace_id', 191)->nullable()->index();
                $table->string('correlation_id', 191)->nullable()->index();
                $table->string('causation_id', 191)->nullable()->index();
                $table->string('root_causation_id', 191)->nullable()->index();
                $table->json('evidence')->nullable();
                $table->timestamp('occurred_at');
                $table->timestamp('created_at')->nullable();
                $table->unique(['tenant_company_id', 'command_id', 'sequence'], 'tcb_attempts_tenant_command_sequence_unique');
            });
        }
    }

    public function down(): void
    {
        // Command lifecycle and audit evidence are intentionally retained on extension downgrade/uninstall.
    }
};
