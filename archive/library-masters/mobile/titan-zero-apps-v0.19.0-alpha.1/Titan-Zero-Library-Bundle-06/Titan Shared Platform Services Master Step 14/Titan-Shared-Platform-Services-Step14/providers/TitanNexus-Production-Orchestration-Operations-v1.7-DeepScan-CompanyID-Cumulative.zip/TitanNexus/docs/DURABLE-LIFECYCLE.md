# Durable Compilation Lifecycle

Titan Nexus maintains two complementary persistence models:

1. `titan_nexus_compilations` stores the current immutable-domain snapshot for each compilation identity with optimistic `entity_version` updates.
2. `titan_nexus_compilation_events` stores append-only lifecycle evidence.

## Lifecycle stages

- `draft_created`
- `validation_completed`
- `validation_failed`
- `compiled`
- `diff_calculated`
- `recompile_planned`
- `provisioning_planned`
- `provisioning_executed`

Every lifecycle event carries `tenant_company_id`, compilation UUID, optional parent compilation UUID, entity version context, `trace_id`, `correlation_id`, `causation_id`, canonical payload hash and deterministic event ID. Identical retries resolve to the same event ID and do not create duplicate history.

Lifecycle reads are always tenant + compilation scoped and bounded. Corrupt legacy event rows are retained in storage but quarantined from runtime read models. The Control Centre exposes the selected compilation's redacted lifecycle timeline.

The lifecycle journal never writes foreign-engine state; provisioning mutations remain Command Bus owned and only their Nexus receipt evidence is journaled.
