<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Integration;

use App\Extensions\TitanConnect\System\Contracts\ReplyAssistant;
use RuntimeException;
use Throwable;

final class MagicAiReplyAssistant implements ReplyAssistant
{
    /** @var array<string,array{system:string,prompt:string}> */
    private const VARIANTS = [
        'improve' => [
            'system' => 'You enhance customer support responses so they are clearer, empathetic, and easy to read. Keep the original intent and respond using the same language as the input.',
            'prompt' => 'Polish this support response so it sounds a bit better while keeping the same meaning:',
        ],
        'lengthen' => [
            'system' => 'You expand customer support responses with helpful, relevant detail. Keep a friendly tone and respond using the same language as the input.',
            'prompt' => 'Add a bit more helpful detail to this support response while staying on topic:',
        ],
        'fix_grammar' => [
            'system' => 'You correct grammar, spelling, and punctuation for customer support responses. Return only the corrected message in the same language as the input.',
            'prompt' => 'Fix grammar mistakes, typos, and punctuation in this support response without changing the intent:',
        ],
    ];

    public function rewrite(int $companyId, int $actorId, string $message, string $variant): string
    {
        $message = trim($message); $variant = strtolower(trim($variant));
        if ($companyId < 1 || $actorId < 1 || $message === '' || ! isset(self::VARIANTS[$variant])) throw new RuntimeException('Invalid support rewrite request.');
        if (! class_exists('App\\Domains\\Entity\\Facades\\Entity') || ! class_exists('App\\Helpers\\Classes\\ApiHelper') || ! class_exists('OpenAI\\Laravel\\Facades\\OpenAI')) {
            throw new RuntimeException('MagicAI reply assistant integration is unavailable.');
        }
        try {
            $driver = \App\Domains\Entity\Facades\Entity::driver();
            $driver->redirectIfNoCreditBalance();
            \App\Helpers\Classes\ApiHelper::setOpenAiKey();
            $prompts = self::VARIANTS[$variant];
            $completion = \OpenAI\Laravel\Facades\OpenAI::chat()->create([
                'model' => $driver->enum()->value,
                'messages' => [
                    ['role' => 'system', 'content' => $prompts['system']],
                    ['role' => 'user', 'content' => $prompts['prompt']."\n\n".$message],
                ],
            ]);
            $result = trim((string) ($completion->choices[0]->message->content ?? ''));
            if ($result === '') throw new RuntimeException('AI rewrite returned an empty response.');
            if (class_exists('App\\Models\\Usage')) {
                $driver->input($result)->calculateCredit()->decreaseCredit();
                \App\Models\Usage::getSingle()->updateWordCounts($driver->calculate());
            }
            return $result;
        } catch (Throwable $e) {
            throw new RuntimeException('Unable to rewrite the support response.', previous: $e);
        }
    }
}
