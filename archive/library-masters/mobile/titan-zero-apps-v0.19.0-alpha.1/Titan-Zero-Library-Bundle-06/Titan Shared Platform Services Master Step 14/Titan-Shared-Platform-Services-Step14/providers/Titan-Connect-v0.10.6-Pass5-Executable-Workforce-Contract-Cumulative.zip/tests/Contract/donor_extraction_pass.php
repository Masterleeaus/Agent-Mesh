<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$passes = [];
$failures = [];
$read = static fn (string $path): string => is_file($root.'/'.$path) ? (string) file_get_contents($root.'/'.$path) : '';
$check = static function (bool $condition, string $name) use (&$passes, &$failures): void {
    if ($condition) $passes[] = $name; else $failures[] = $name;
};

$migration = $read('database/migrations/2026_08_09_000004_add_official_comms_donor_features.php');
$routes = $read('routes/api.php')."\n".$read('routes/web.php');
$provider = $read('System/TitanConnectServiceProvider.php');
$registry = $read('System/Providers/ProviderRegistry.php');
$wa = $read('System/Providers/WhatsAppProvider.php');
$twilio = $read('System/Providers/WhatsAppTwilioTransport.php');
$metaOAuth = $read('System/Onboarding/MetaOAuthService.php');
$telegramOnboarding = $read('System/Onboarding/TelegramWebhookRegistrar.php');
$operator = $read('System/Services/OperatorInboxService.php');
$threadService = $read('System/Services/ExternalThreadManagementService.php');
$export = $read('System/Services/ConversationExportService.php');
$rewrite = $read('System/Integration/MagicAiReplyAssistant.php');
$voiceManager = $read('System/Voice/VoiceSessionManager.php');
$openAiVoice = $read('System/Voice/OpenAiRealtimeVoiceGateway.php');
$elevenVoice = $read('System/Voice/ElevenLabsVoiceGateway.php');
$voiceAgent = $read('System/Voice/VoiceAgentService.php');
$voiceJs = $read('resources/assets/js/voice-call-client.js');
$inboxView = $read('resources/views/inbox/index.blade.php');
$threadController = $read('System/Http/Controllers/ExternalThreadController.php');
$exportController = $read('System/Http/Controllers/ConversationExportController.php');

$check(str_contains($migration, 'ext_titan_connect_external_contacts') && str_contains($migration, 'ext_titan_connect_contact_tags'), 'DONOR operator contact/tag schema exists');
$check(str_contains($migration, 'ext_titan_connect_canned_responses') && str_contains($migration, 'assigned_user_id') && str_contains($migration, 'pinned_rank'), 'DONOR canned response and operator thread fields exist');
$check(str_contains($migration, 'ext_titan_connect_voice_calls') && str_contains($migration, 'ext_titan_connect_voice_transcripts'), 'DONOR voice call/transcript schema exists');
$check(is_file($root.'/System/Models/ExternalContact.php') && is_file($root.'/System/Models/ContactTag.php') && is_file($root.'/System/Models/CannedResponse.php'), 'DONOR company-owned operator models exist');
$check(str_contains($operator, 'unread') && str_contains($operator, 'assigned_user_id') && str_contains($operator, 'pinned_rank'), 'DONOR inbox filters assignment/unread/pinning');
$check(str_contains($threadService, 'internal') && str_contains($threadService, 'note') && str_contains($threadService, 'assigned_user_id'), 'DONOR thread service supports notes and assignment');
$check(str_contains($export, 'csv') && str_contains($export, 'json') && str_contains($export, 'text'), 'DONOR conversation exports include CSV/JSON/text');
$check(str_contains($rewrite, 'improve') && str_contains($rewrite, 'lengthen') && str_contains($rewrite, 'fix_grammar'), 'DONOR support reply rewrite variants preserved');
$check(str_contains($metaOAuth, 'oauth') && str_contains($metaOAuth, 'instagram') && str_contains($metaOAuth, 'Crypt'), 'DONOR secure Meta/Instagram OAuth onboarding exists');
$check(str_contains($telegramOnboarding, 'setWebhook') && str_contains($telegramOnboarding, 'secret_token'), 'DONOR Telegram automatic webhook registration exists');
$check(str_contains($wa, 'WhatsAppTwilioTransport') && str_contains($wa, "transport"), 'DONOR WhatsApp transport selector exists');
$check(str_contains($twilio, 'api.twilio.com') && str_contains($twilio, 'whatsapp:'), 'DONOR Twilio WhatsApp direct HTTP transport exists');
$check(str_contains($voiceManager, 'VoiceCall') && str_contains($voiceManager, 'VoiceTranscript'), 'DONOR voice call lifecycle manager exists');
$check(str_contains($openAiVoice, 'realtime/client_secrets'), 'DONOR OpenAI Realtime ephemeral credential flow exists');
$check(str_contains($elevenVoice, 'signed') && str_contains($elevenVoice, 'agent_id'), 'DONOR ElevenLabs voice session flow exists');
$check(str_contains($voiceAgent, 'knowledge') && !str_contains($voiceAgent, 'file_get_contents'), 'DONOR voice-agent knowledge orchestration excludes unsafe crawler');
$check(str_contains($voiceJs, 'getUserMedia') && str_contains($voiceJs, 'AudioContext') && str_contains($voiceJs, 'transcript') && str_contains($voiceJs, 'waveform'), 'DONOR browser voice/audio/transcript client extracted');
$check(str_contains($inboxView, 'canned') && str_contains($inboxView, 'internal') && str_contains($inboxView, 'tag'), 'DONOR operator inbox UX includes canned replies/notes/tags');
$check(str_contains($operator, 'WorkCoreAuthorizationGateway') && str_contains($threadController, 'WorkCoreAuthorizationGateway') && str_contains($exportController, 'WorkCoreAuthorizationGateway'), 'DONOR operator reads/mutations/exports retain WorkCore authorization');
$check(str_contains($inboxView, 'Meta OAuth') && str_contains($inboxView, 'Telegram') && str_contains($inboxView, 'Twilio WhatsApp') && str_contains($inboxView, 'OpenAI Realtime') && str_contains($inboxView, 'ElevenLabs'), 'DONOR provider onboarding UX is integrated');
$check(str_contains($voiceManager, 'voice_call_started') && str_contains($voiceManager, 'voice_call_ended'), 'DONOR voice-call lifecycle is promoted into canonical communication timeline');
$check(str_contains($routes, 'ProviderOnboardingController') && str_contains($routes, 'VoiceCallController') && str_contains($routes, 'OperatorInboxController'), 'DONOR APIs/routes are integrated into Titan Connect');
$check(str_contains($provider, 'ReplyAssistant') && str_contains($provider, 'VoiceSessionGateway') && str_contains($provider, 'VoiceAgentGateway'), 'DONOR host integration contracts are container-bound');
$check(str_contains($registry, 'WhatsAppProvider'), 'DONOR provider registry retains one canonical WhatsApp provider');
$check(!is_dir($root.'/donors') && !is_dir($root.'/System/Services/ChatbotAgent') && !str_contains($provider, 'Ably'), 'DONOR raw extensions/Ably are not active runtime');

foreach ($passes as $pass) echo "PASS {$pass}\n";
if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL {$failure}\n");
    fwrite(STDERR, sprintf("\n%d failed; %d passed.\n", count($failures), count($passes)));
    exit(1);
}

echo sprintf("\nOK Titan Connect donor-extraction contract suite: %d passed.\n", count($passes));
