<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if(!Schema::hasTable('crm_capability_operations'))return;
        Schema::table('crm_capability_operations',function(Blueprint $t):void{
            if(!Schema::hasColumn('crm_capability_operations','duplicate_replay_count'))$t->unsignedInteger('duplicate_replay_count')->default(0);
            if(!Schema::hasColumn('crm_capability_operations','last_replayed_at'))$t->timestamp('last_replayed_at')->nullable()->index('crm_cap_ops_last_replay_idx');
        });
    }
    public function down(): void
    {
        if(!Schema::hasTable('crm_capability_operations'))return;
        foreach(['last_replayed_at','duplicate_replay_count'] as $column)if(Schema::hasColumn('crm_capability_operations',$column))Schema::table('crm_capability_operations',fn(Blueprint $t)=>$t->dropColumn($column));
    }
};
