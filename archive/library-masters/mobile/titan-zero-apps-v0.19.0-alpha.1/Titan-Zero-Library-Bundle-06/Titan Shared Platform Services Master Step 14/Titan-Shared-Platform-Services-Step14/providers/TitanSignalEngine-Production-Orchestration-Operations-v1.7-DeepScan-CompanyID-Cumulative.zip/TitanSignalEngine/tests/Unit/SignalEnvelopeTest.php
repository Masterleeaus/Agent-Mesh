<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

final class SignalEnvelopeTest extends TestCase
{
    public function test_tenant_signal_generates_canonical_identifiers(): void
    {
        $signal = SignalEnvelope::fromArray([
            'event_type' => 'crm.customer.created',
            'tenant_company_id' => 42,
            'source' => 'titan-crm',
            'payload' => ['customer_id' => 7],
        ]);

        self::assertSame('tenant', $signal->scope);
        self::assertSame(42, $signal->tenantCompanyId);
        self::assertNotSame('', $signal->eventId);
        self::assertNotSame('', $signal->traceId);
        self::assertNotSame('', $signal->correlationId);
        self::assertSame(64, strlen($signal->checksum));
    }

    public function test_tenant_scope_requires_tenant_company_id(): void
    {
        $this->expectException(InvalidArgumentException::class);

        SignalEnvelope::fromArray([
            'event_type' => 'crm.customer.created',
            'source' => 'titan-crm',
        ]);
    }

    public function test_system_scope_rejects_tenant_company_id(): void
    {
        $this->expectException(InvalidArgumentException::class);

        SignalEnvelope::fromArray([
            'event_type' => 'signal.engine.started',
            'scope' => 'system',
            'tenant_company_id' => 1,
            'source' => 'titan-signal-engine',
        ]);
    }

    public function test_child_signal_cannot_escape_parent_tenant_or_trace_boundary(): void
    {
        $parent = SignalEnvelope::fromArray([
            'event_type' => 'command.requested',
            'tenant_company_id' => 99,
            'source' => 'titan-command-bus',
        ]);

        $this->expectException(InvalidArgumentException::class);
        $parent->child('risk.assessed', 'titan-risk-engine', [], ['tenant_company_id' => 100]);
    }

    public function test_child_signal_propagates_context_and_causation(): void
    {
        $parent = SignalEnvelope::fromArray([
            'event_type' => 'command.requested',
            'tenant_company_id' => 99,
            'source' => 'titan-command-bus',
            'actor_type' => 'ai_agent',
            'actor_id' => 'agent-7',
            'vertical_key' => 'cleaning',
        ]);

        $child = $parent->child('risk.assessed', 'titan-risk-engine', ['risk' => 'low']);

        self::assertSame($parent->traceId, $child->traceId);
        self::assertSame($parent->correlationId, $child->correlationId);
        self::assertSame($parent->eventId, $child->causationId);
        self::assertSame($parent->tenantCompanyId, $child->tenantCompanyId);
        self::assertSame('titan-risk-engine', $child->source);
    }
}
