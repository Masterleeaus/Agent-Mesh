# Security and Privacy

## Security controls

- fail-closed required host contract resolution;
- four explicit route security profiles;
- server-derived company context;
- client `company_id` / `tenant_id` override rejection;
- explicit route permission checks plus service-level checks;
- company-safe route-model resolution;
- immutable tenant ownership on persistent Maps models;
- company-scoped queue execution context and explicit queue query predicates;
- separate admin authorization from ordinary company permissions;
- fail-closed internal/service route authorization;
- per-company Vault references;
- HTTPS-only provider transport with declared host allowlist;
- bounded timeout/retry/radius/result counts;
- safe stable errors without provider response-body leakage;
- suppression/do-not-reintroduce records;
- no direct ungoverned WorkCore writes.

## Privacy classes

The extension may process public business information and, in later passes, field-worker location data. Public availability does not remove privacy, contractual, marketing or retention obligations. Define a valid purpose before collecting or promoting data.

## Contact governance

Discovery does not authorise outreach. Do not automatically message, call or market to candidates. Separate operational provider sourcing from marketing campaigns and apply applicable Australian privacy, spam, telemarketing, suppression and retention obligations.

## Raw payloads

Provider raw payloads are not stored by default. Any later raw retention must use encrypted private storage, explicit expiry/terms metadata and `raw-data.read` authorization.

## Threats considered

- cross-company route IDs;
- forged company identifiers;
- tenant reassignment after record creation;
- user/agent permission escalation;
- admin/company privilege confusion;
- unauthenticated internal endpoints;
- queue execution under stale/ambient tenant state;
- secret leakage;
- provider-host substitution;
- unbounded provider cost;
- duplicate merge errors;
- stale observations presented as live.
