<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function fail_si(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);} function same_si(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_si($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
foreach([
 '/System/Contracts/GovernanceReadSourceContract.php',
 '/System/ReadPlane/GovernanceReadSourceRegistry.php',
 '/System/ReadPlane/SignalHeatmapProjector.php',
 '/System/ReadPlane/OperationalPressureDetector.php',
 '/System/ReadPlane/CircuitBreakerProjector.php',
 '/System/ReadPlane/GovernanceSignalIntelligence.php',
] as $file){if(!is_file($root.$file))fail_si('missing '.$file);require_once $root.$file;}

use App\Extensions\TitanGovernance\System\Contracts\GovernanceReadSourceContract;
use App\Extensions\TitanGovernance\System\ReadPlane\CircuitBreakerProjector;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceReadSourceRegistry;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceSignalIntelligence;
use App\Extensions\TitanGovernance\System\ReadPlane\OperationalPressureDetector;
use App\Extensions\TitanGovernance\System\ReadPlane\SignalHeatmapProjector;

final class SIContractSignalSource implements GovernanceReadSourceContract{
 public function key():string{return 'titan-signal';} public function required():bool{return true;}
 public function snapshot(int $tenantCompanyId,array $context=[]):array{return ['source'=>'titan-signal','status'=>'HEALTHY','observed_at'=>'2026-08-20T17:00:00+10:00','signals'=>[],'operational_pressure'=>[['source_component'=>'crm','queue_depth'=>30]],'circuit_breakers'=>[]];}
}
$r=new GovernanceReadSourceRegistry();$r->register(new SIContractSignalSource());
$s=new GovernanceSignalIntelligence($r,new SignalHeatmapProjector(),new OperationalPressureDetector(),new CircuitBreakerProjector());
$fresh=$s->snapshot(42,['now'=>'2026-08-20T17:01:00+10:00','stale_after_seconds'=>300]);
same_si('HEALTHY',$fresh['source_status'],'fresh Signal source should remain healthy');
same_si('ELEVATED',$fresh['operational_pressure']['items'][0]['pressure_band'],'queue pressure must be detected');
$stale=$s->snapshot(42,['now'=>'2026-08-20T17:10:00+10:00','stale_after_seconds'=>300]);
same_si('STALE',$stale['source_status'],'stale Signal source must be explicit');
same_si('STALE',$stale['heatmap']['source_status'],'staleness must propagate into Signal views');

echo "PASS: Governance Signal intelligence service contract\n";
