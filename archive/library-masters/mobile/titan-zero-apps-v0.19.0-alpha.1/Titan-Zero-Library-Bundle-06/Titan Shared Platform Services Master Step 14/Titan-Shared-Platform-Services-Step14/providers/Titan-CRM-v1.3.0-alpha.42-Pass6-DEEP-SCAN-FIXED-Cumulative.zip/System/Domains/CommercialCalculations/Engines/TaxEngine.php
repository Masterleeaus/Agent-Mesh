<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Domains\CommercialCalculations\Engines;

use App\Extensions\Crm\System\Domains\CommercialCalculations\DTO\CalculationContext;
use App\Extensions\Crm\System\Domains\CommercialCalculations\DTO\CalculationResult;
use App\Extensions\Crm\System\Domains\CommercialCalculations\Support\Decimal;

final class TaxEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'tax'; }
    public function priority(): int { return 90; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $subtotal = $this->decimal($context, $state, 'subtotal', '0');
        $rate = $this->decimal($context, $state, 'tax_rate_percent', '0');
        $inclusive = (bool) $this->value($context, $state, 'tax_inclusive', false);

        if ($inclusive) {
            $divisor = Decimal::from('1')->add($rate->div(100));
            $exclusive = $subtotal->div($divisor);
            $tax = $subtotal->sub($exclusive);
            $total = $subtotal;
        } else {
            $tax = $this->percentOf($subtotal, $rate);
            $exclusive = $subtotal;
            $total = $subtotal->add($tax);
        }

        return $this->result(['taxable_subtotal' => $exclusive, 'tax_amount' => $tax, 'total' => $total], ['subtotal' => $subtotal, 'tax_rate_percent' => $rate, 'tax_inclusive' => $inclusive]);
    }
}
