# Titan Connect v0.10.5 — Dashboard Shell, Navigation and PHP 8.3 Runtime Repair

## Live symptoms repaired

- Inbox and Channels appeared in the Super Admin navigation instead of the normal company/user dashboard.
- Channel pages rendered as raw standalone HTML without the MagicAI panel shell or Titan Connect assets.
- PHP 8.3 raised a fatal error because `VoiceProvider` redeclared inherited `$http` as private.

## Navigation repair

Migration `2026_08_10_000008_repair_magicai_dashboard_navigation.php` repairs already-installed v0.10.4 menu rows. It is self-contained for Titan's in-request upgrade lifecycle.

- User Inbox and Channels use canonical `dashboard.user.titan-connect.*` route names.
- On legacy shared `menus` hosts, both roots use user-section order values 6 and 7 and remain outside the legacy extension-plan gate.
- The old provider-by-provider Super Admin fallback rows are removed.
- Legacy hosts retain one Titan Connect entry under the existing Super Admin Settings parent.
- Hosts with a real `is_admin` menu column keep separately marked admin navigation.
- Menu cache regeneration is best-effort and non-fatal.

## Native MagicAI panel shell

Full-page Titan Connect views now extend `panel.layout.app`, define the host `content` section, and push CSS/JS through the host layout stacks. The service provider registers publishable assets during web-based installer requests, not only console boots.

## PHP 8.3 provider inheritance

`AbstractMessagingProvider` owns `protected readonly ProviderHttpClient $http`. `VoiceProvider` no longer redeclares the property. Its constructor delegates to `parent::__construct($http)`.

The provider runtime contract loads the complete provider inheritance graph under the active PHP runtime to catch visibility/signature fatals that `php -l` alone cannot detect.
