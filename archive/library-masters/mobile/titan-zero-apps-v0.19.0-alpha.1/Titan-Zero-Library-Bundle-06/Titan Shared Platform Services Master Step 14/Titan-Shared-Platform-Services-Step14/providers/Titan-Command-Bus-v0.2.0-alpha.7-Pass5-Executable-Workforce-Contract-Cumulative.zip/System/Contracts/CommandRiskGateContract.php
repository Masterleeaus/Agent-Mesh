<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Contracts;

use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use App\Extensions\TitanCommandBus\System\DTO\RiskDecision;

interface CommandRiskGateContract
{
    public function available(): bool;
    public function assess(CommandContext $context, CommandRequest $request): RiskDecision;
}
