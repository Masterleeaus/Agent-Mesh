# Security

Signal is fail-closed around tenant and emitter identity.

- Tenant-sensitive public contracts require `SignalContext`.
- New emissions require a host-attested `SignalEmitterIdentity`.
- Registry writes require a separate host-attested `SignalRegistryIdentity`; event families and subscriber keys are owner-scoped.
- Event/subscription definition history is append-only; runtime quarantine state is stored separately.
- Missing subscriber handlers are quarantined and skipped, preventing a broken consumer definition from blocking event ingestion.
- `tenant_company_id` is the tenant boundary; customer `company_id`/`user_id` are not substitutes.
- Actor identity and emitter/service identity are separate.
- Event payload and metadata size are bounded.
- Hidden model reasoning/scratchpad keys are rejected.
- Authorization/token/secret/password/signature fields are redaction targets.
- System reads require explicit system permission.
- Immutable events cannot be edited through the ORM.
- Physical pruning is isolated to the governed lifecycle service and requires archive verification.

Registry ownership is now hardened. The production-hardening plan continues with atomic delivery leasing, DLQ/cache/backpressure repair, and hot/cold reconstruction before final 1.0 readiness.

## Delivery recovery controls

Dead-letter redrive is permissioned by `signal.delivery.redrive`, enforces the original delivery tenant/system boundary, refuses disabled/missing subscribers, and preserves the stable delivery identity/idempotency key. Registry cache revisions are host-owned and cannot be supplied by subscribers.

## Destructive retention authorization

A retention permission alone is insufficient to delete hot events. Physical pruning also requires a one-time preview token whose SHA-256 hash is stored server-side and whose preview manifest binds tenant, scope and the exact event set. Tokens are never persisted in plaintext.
