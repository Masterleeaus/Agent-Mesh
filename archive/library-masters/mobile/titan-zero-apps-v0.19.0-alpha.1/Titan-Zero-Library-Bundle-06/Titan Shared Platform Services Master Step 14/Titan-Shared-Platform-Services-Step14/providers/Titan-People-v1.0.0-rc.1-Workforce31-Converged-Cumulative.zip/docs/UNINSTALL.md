# Uninstall

The default uninstall policy is **retain**.

`TitanPeopleServiceProvider::uninstall()` removes the published Titan People configuration file only. People records, lifecycle history, leave ledgers, outbox evidence and private HR documents are retained because employment/HR facts can have legal and operational retention requirements.

A data purge is deliberately not performed by uninstall. Any future purge must be an explicit governed operation that checks retention obligations, legal hold and tenant authority before deleting People-owned records or `private/titan-people/` objects.
