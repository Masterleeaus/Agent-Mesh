@extends('panel.layout.app')
@section('content')
@php
    $req=$dashboard['request'] ?? [];
    $surface=$dashboard['surface'] ?? [];
    $health=$dashboard['health'] ?? [];
    $signals=(int)($surface['signal_count'] ?? 0);
    $errorCount=(int)($surface['error_count'] ?? 0);
    $errorRate=$signals>0 ? ($errorCount/$signals)*100 : 0;
    $delivery=(array)($health['delivery'] ?? $health['backpressure'] ?? []);
    $lifecycle=(array)($dashboard['lifecycle'] ?? []);
    $traceEval=(array)($health['trace_evaluation'] ?? []);
    $archives=(array)($dashboard['archives'] ?? []);
    $archiveHealthy=count($archives)===0 ? 'IDLE' : (!empty($archives[0]['verified_at']) ? 'HEALTHY' : strtoupper((string)($archives[0]['status'] ?? 'ATTENTION')));
    $filterQuery=array_filter(['scope'=>$req['scope']??'system','tenant_company_id'=>$req['tenant_company_id']??null,'window'=>$req['window']??'5m','limit'=>$req['limit']??100],static fn($v)=>$v!==null&&$v!=='');
    $pageTitle='Signal Engine Overview';
    $pageSubtitle='v0.20.0-rc.8.1 · operational status first, governed controls on dedicated child pages';
    $activePage='overview';
@endphp
@include('titan-signal-engine::admin-rc8-1.partials.styles')
<div class="tse-wrap">
    @include('titan-signal-engine::admin-rc8-1.partials.header')
    @include('titan-signal-engine::admin-rc8-1.partials.alerts')
    @include('titan-signal-engine::admin-rc8-1.partials.filter')

    <div class="tse-grid-4 tse-section">
        <section class="tse-card">
            <h2>System Status</h2>
            <div class="tse-kpis">
                <div class="tse-kpi"><div class="tse-kpi-label">Health</div><div class="tse-value-sm">{{ strtoupper((string)($health['status'] ?? 'unknown')) }}</div></div>
                <div class="tse-kpi"><div class="tse-kpi-label">Attention</div><div class="tse-value-sm">{{ strtoupper((string)($surface['attention']['band'] ?? 'unknown')) }}</div><div class="tse-muted">score {{ $surface['attention']['score'] ?? 0 }}</div></div>
                <div class="tse-kpi"><div class="tse-kpi-label">Signals</div><div class="tse-value">{{ number_format($signals) }}</div></div>
                <div class="tse-kpi"><div class="tse-kpi-label">Error rate</div><div class="tse-value">{{ number_format($errorRate,2) }}%</div></div>
            </div>
            <a class="tse-link" href="{{ route('dashboard.admin.titan.signal.engine.pulse-health',$filterQuery) }}">View details →</a>
        </section>

        <section class="tse-card">
            <h2>Runtime</h2>
            <div class="tse-kpis">
                <div class="tse-kpi"><div class="tse-kpi-label">Event rate</div><div class="tse-value">{{ number_format((float)($surface['event_rate_per_second'] ?? 0),3) }}/s</div></div>
                <div class="tse-kpi"><div class="tse-kpi-label">Projection freshness</div><div class="tse-value-sm">{{ strtoupper((string)($health['pulse']['status'] ?? 'unknown')) }}</div><div class="tse-muted">{{ isset($health['pulse']['last_projection_age_seconds']) ? $health['pulse']['last_projection_age_seconds'].'s age' : 'no age sample' }}</div></div>
                <div class="tse-kpi"><div class="tse-kpi-label">P95 latency</div><div class="tse-value">{{ $dashboard['pulse']['latency']['p95_ms'] ?? $dashboard['pulse']['latency']['p95'] ?? '—' }}</div></div>
                <div class="tse-kpi"><div class="tse-kpi-label">Stalled traces</div><div class="tse-value">{{ number_format((int)($surface['stalled_trace_count'] ?? 0)) }}</div><div class="tse-muted">{{ number_format((int)($surface['missing_receipt_count'] ?? 0)) }} missing receipts</div></div>
            </div>
            <a class="tse-link" href="{{ route('dashboard.admin.titan.signal.engine.events-traces',$filterQuery) }}">View details →</a>
        </section>

        <section class="tse-card">
            <h2>Delivery</h2>
            <div class="tse-kpis">
                <div class="tse-kpi"><div class="tse-kpi-label">Subscribers</div><div class="tse-value">{{ number_format(count($dashboard['subscriber_health'] ?? [])) }}</div></div>
                <div class="tse-kpi"><div class="tse-kpi-label">Pending / retrying</div><div class="tse-value">{{ number_format((int)($delivery['pending'] ?? 0)+(int)($delivery['retry_wait'] ?? 0)) }}</div></div>
                <div class="tse-kpi"><div class="tse-kpi-label">Dead letters</div><div class="tse-value">{{ number_format((int)($surface['dead_letter_count'] ?? $delivery['unresolved_dead_letter'] ?? 0)) }}</div></div>
                <div class="tse-kpi"><div class="tse-kpi-label">Backpressure</div><div class="tse-value-sm">{{ !empty($delivery['backpressured']) ? 'ACTIVE' : 'CLEAR' }}</div></div>
            </div>
            <a class="tse-link" href="{{ route('dashboard.admin.titan.signal.engine.deliveries-dlq',$filterQuery) }}">View details →</a>
        </section>

        <section class="tse-card">
            <h2>Integrity</h2>
            <div class="tse-kpis">
                <div class="tse-kpi"><div class="tse-kpi-label">Open anomalies</div><div class="tse-value">{{ number_format(count($dashboard['anomalies'] ?? [])) }}</div></div>
                <div class="tse-kpi"><div class="tse-kpi-label">Lifecycle holds</div><div class="tse-value">{{ number_format((int)($lifecycle['legal_holds'] ?? 0)) }}</div></div>
                <div class="tse-kpi"><div class="tse-kpi-label">Archive health</div><div class="tse-value-sm">{{ $archiveHealthy }}</div></div>
                <div class="tse-kpi"><div class="tse-kpi-label">Trace evaluations due</div><div class="tse-value">{{ number_format((int)($traceEval['due'] ?? 0)) }}</div></div>
            </div>
            <a class="tse-link" href="{{ route('dashboard.admin.titan.signal.engine.lifecycle-archives',$filterQuery) }}">View details →</a>
        </section>
    </div>
</div>
@endsection
