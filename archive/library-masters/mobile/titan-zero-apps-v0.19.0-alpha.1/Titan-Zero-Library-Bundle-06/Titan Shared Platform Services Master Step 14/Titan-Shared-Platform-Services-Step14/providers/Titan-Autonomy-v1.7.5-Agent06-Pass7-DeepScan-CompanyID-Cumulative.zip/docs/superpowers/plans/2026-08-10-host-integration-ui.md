# Titan Autonomy Host Integration + UI Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn Titan Autonomy v1.1 runtime core into an installer-ready v1.2 control plane with tenant/Super Admin UI, safe data portability/reset operations, and fail-closed host bridge integration.

**Architecture:** Keep autonomy policy/runtime ownership inside TitanAutonomy. Add server-derived host context, read/query repositories, command services and Blade routes/views. Optional TitanAI/Assurance/Interaction/CommandBus/Rewind integrations are exposed through contracts with explicit unavailable adapters so missing host APIs never become permissive fallbacks.

**Tech Stack:** PHP 8.2+, Laravel 10, Blade, DB facade, Titan extension manifests/migrations.

## Global Constraints

- Tenancy is established only from authenticated server-side context; request/query/body tenant IDs never establish tenancy.
- CRM-backed autonomy uses `tenant_company_id`.
- Autonomy escalation remains capability/workflow specific, evidence-gated, one level at a time, and never silent.
- Trusted Auto requires Platform + authorised user + TitanAI/Assurance approval and bounded scope.
- Tenant policy may only be stricter than platform policy.
- System-wide learning is off by default and raw tenant data is never copied into shared learning.
- Missing optional host bridges fail closed.
- Installer boot must not query newly created extension tables.

---

### Task 1: Host context and bridge status

**Files:**
- Create: `System/Contracts/HostContextBridgeContract.php`
- Create: `System/Contracts/RewindBridgeContract.php`
- Create: `System/Infrastructure/LaravelAuthHostContextBridge.php`
- Create: `System/Infrastructure/UnavailableAssuranceBridge.php`
- Create: `System/Infrastructure/UnavailableInteractionEngineBridge.php`
- Create: `System/Infrastructure/UnavailableCommandBusBridge.php`
- Create: `System/Infrastructure/UnavailableRewindBridge.php`
- Create: `System/Services/HostBridgeStatusService.php`
- Test: `tests/Smoke/HostBridgeSecuritySmokeTest.php`

**Interfaces:**
- Produces `HostContextBridgeContract::tenantCompanyId(): int`, `userId(): int`, `can(string): bool`, `isSuperAdmin(): bool`.
- Produces fail-closed optional bridge defaults and status inspection.

- [ ] Write security smoke test proving tenant context is server-derived and unavailable bridges deny execution/evaluation.
- [ ] Run test and verify RED.
- [ ] Implement contracts/adapters/status service.
- [ ] Run test and verify GREEN.

### Task 2: Query repositories and control-plane services

**Files:**
- Create: `System/Contracts/AutonomyQueryContract.php`
- Create: `System/Infrastructure/DatabaseAutonomyQuery.php`
- Create: `System/Services/AutonomyDashboardService.php`
- Create: `System/Services/LearningSettingsService.php`
- Create: `System/Services/LearningExportService.php`
- Create: `System/Services/LearningResetService.php`
- Create: `System/Services/ManualRegressionService.php`
- Test: `tests/Smoke/ControlPlaneServiceSmokeTest.php`

**Interfaces:**
- Query only within a supplied server-derived `tenant_company_id`.
- Reset clears selected evidence/preferences and downgrades only the selected capability/workflow when evidence no longer supports authority.
- Manual regression can lower but never raise autonomy.

- [ ] Write failing service smoke tests for scoped listing/export/reset/regression invariants.
- [ ] Run RED.
- [ ] Implement minimal repositories/services.
- [ ] Run GREEN.

### Task 3: Gate review and Trusted Auto orchestration

**Files:**
- Create: `System/Services/GateReviewService.php`
- Create: `System/Services/TrustedAutoReviewService.php`
- Test: `tests/Smoke/GateReviewSmokeTest.php`

**Interfaces:**
- `GateReviewService` reconstructs current capability state and gate evidence from persisted state.
- `TrustedAutoReviewService` consumes structured Assurance bridge output and delegates final activation to `AutonomyGrantService`.
- Missing/invalid Assurance response denies Trusted Auto.

- [ ] Write failing tests for explicit user decision, structured Assurance denial, and bounded scope.
- [ ] Run RED.
- [ ] Implement services.
- [ ] Run GREEN.

### Task 4: Tenant HTTP control plane and UI

**Files:**
- Create: `routes/web.php`
- Create: `System/Http/Controllers/AutonomyDashboardController.php`
- Create: `System/Http/Controllers/AutonomyActionController.php`
- Create: `resources/views/autonomy/index.blade.php`
- Create: `resources/views/autonomy/capability.blade.php`
- Create: `resources/views/autonomy/learning.blade.php`
- Test: `tests/Smoke/RouteSurfaceSmokeTest.php`

**Interfaces:**
- GET dashboard/capability/learning pages.
- POST lower-level, reset, learning settings, next-gate review/activation.
- GET JSON learning export.
- All mutation routes require authenticated context plus named capabilities.

- [ ] Write failing route-surface test verifying no tenant id input is accepted and CSRF/middleware declarations exist.
- [ ] Run RED.
- [ ] Implement routes/controllers/views.
- [ ] Run GREEN.

### Task 5: Super Admin policy UI

**Files:**
- Create: `System/Http/Controllers/AutonomyAdminController.php`
- Create: `resources/views/autonomy/admin.blade.php`
- Create: `System/Services/PlatformPolicyService.php`
- Test: `tests/Smoke/AdminPolicySmokeTest.php`

**Interfaces:**
- Only `isSuperAdmin()` plus `titan.autonomy.policy.manage` may mutate platform policy.
- Gate minimums cannot drop below 1/2/3 platform safety defaults for low/medium/high.
- Critical ceiling defaults to Semi-Auto and explicit override remains governed.

- [ ] Write failing policy security tests.
- [ ] Run RED.
- [ ] Implement controller/service/view.
- [ ] Run GREEN.

### Task 6: Rewind correlation and provider/manifest integration

**Files:**
- Modify: `System/TitanAutonomyServiceProvider.php`
- Modify: `extension.json`
- Modify: `extension.manifest.json`
- Create: `database/migrations/2026_08_10_000200_add_titan_autonomy_control_plane.php`
- Create: `System/Services/RewindCorrelationService.php`
- Modify: `README.md`
- Create: `CHANGELOG-v1.2.md`
- Test: `tests/Smoke/ProviderIntegrationSmokeTest.php`

**Interfaces:**
- Provider loads views/routes/migrations without querying tables at boot.
- Manifest advertises routes/UI contributions and v1.2 capabilities.
- Rewind bridge records autonomy activation/regression/reset/settings events when available; otherwise audit persistence remains canonical.

- [ ] Write failing provider/manifest test.
- [ ] Run RED.
- [ ] Implement provider/migration/docs/metadata.
- [ ] Run GREEN.

### Task 7: Package verification

- [ ] Run every smoke/unit/feature test individually.
- [ ] Run `php -l` over all PHP files.
- [ ] Validate JSON manifests.
- [ ] Recompute `extension.json.integrity.files` after all edits.
- [ ] Build ZIP with root folder exactly `TitanAutonomy/`.
- [ ] Verify ZIP paths, hashes, no secrets, and SHA-256.
