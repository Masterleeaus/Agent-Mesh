<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use InvalidArgumentException;

final class ValidationFinding
{
    public function __construct(
        private readonly string $code,
        private readonly ValidationSeverity $severity,
        private readonly string $path,
        private readonly string $message,
        private readonly string $source,
    ) {
        self::assertToken($this->code, 'code', 160, '/^[a-z0-9][a-z0-9._-]*$/');
        self::assertText($this->path, 'path', 512, true);
        self::assertText($this->message, 'message', 1000, false);
        self::assertToken($this->source, 'source', 160, '/^[a-z0-9][a-z0-9._-]*$/');
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $severity = $data['severity'] ?? null;
        if (!is_string($severity) || ValidationSeverity::tryFrom($severity) === null) {
            throw new InvalidArgumentException('severity must be error, warning, or info.');
        }

        $source = $data['source'] ?? null;
        if ($source === null && isset($data['metadata']) && is_array($data['metadata'])) {
            $source = $data['metadata']['source'] ?? null;
        }
        return new self(
            self::requiredString($data['code'] ?? null, 'code'),
            ValidationSeverity::from($severity),
            self::stringValue($data['path'] ?? '', 'path'),
            self::requiredString($data['message'] ?? null, 'message'),
            self::requiredString($source, 'source'),
        );
    }

    public function code(): string { return $this->code; }
    public function severity(): ValidationSeverity { return $this->severity; }
    public function path(): string { return $this->path; }
    public function message(): string { return $this->message; }
    public function source(): string { return $this->source; }

    /** @return array<string,mixed> */
    public function toContractArray(): array
    {
        return [
            'code' => $this->code,
            'severity' => $this->severity->value,
            'path' => $this->path,
            'message' => $this->message,
            'metadata' => ['source' => $this->source],
        ];
    }

    /** @return array<string, string> */
    public function toArray(): array
    {
        return [
            'code' => $this->code,
            'severity' => $this->severity->value,
            'path' => $this->path,
            'message' => $this->message,
            'source' => $this->source,
        ];
    }

    public function sortKey(): string
    {
        return sprintf('%d|%s|%s|%s|%s', $this->severity->rank(), $this->code, $this->path, $this->source, $this->message);
    }

    private static function assertToken(string $value, string $field, int $maxLength, string $pattern): void
    {
        if ($value === '' || strlen($value) > $maxLength || preg_match($pattern, $value) !== 1) {
            throw new InvalidArgumentException("{$field} is invalid.");
        }
    }

    private static function assertText(string $value, string $field, int $maxLength, bool $allowEmpty): void
    {
        if ((!$allowEmpty && $value === '') || strlen($value) > $maxLength) {
            throw new InvalidArgumentException("{$field} is invalid.");
        }
    }

    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') {
            throw new InvalidArgumentException("{$field} is required.");
        }

        return trim($value);
    }

    private static function stringValue(mixed $value, string $field): string
    {
        if (!is_string($value)) {
            throw new InvalidArgumentException("{$field} must be a string.");
        }

        return trim($value);
    }
}
