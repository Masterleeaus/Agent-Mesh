<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_learning_events') && !Schema::hasColumn('titan_learning_events', 'learning_scopes_json')) {
            Schema::table('titan_learning_events', function (Blueprint $table): void {
                $table->json('learning_scopes_json')->nullable()->after('learning_label');
                $table->string('policy_version', 64)->nullable()->after('confidence');
            });
        }

        if (!Schema::hasTable('titan_autonomy_policies')) {
            Schema::create('titan_autonomy_policies', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->string('scope_type', 16); // platform|tenant
                $table->string('scope_key', 64)->default('global');
                $table->unsignedBigInteger('tenant_company_id')->nullable()->index();
                $table->json('gate_minimums_json');
                $table->json('maximum_level_by_risk_json');
                $table->json('limits_json')->nullable();
                $table->boolean('system_wide_learning_permitted')->default(false);
                $table->string('policy_version', 64);
                $table->boolean('active')->default(true);
                $table->timestamps();
                $table->unique(['scope_type', 'scope_key'], 'titan_autonomy_policy_scope_unique');
            });
        }

        if (!Schema::hasTable('titan_learning_settings')) {
            Schema::create('titan_learning_settings', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('tenant_company_id')->unique();
                $table->boolean('user_learning')->default(true);
                $table->boolean('business_learning')->default(true);
                $table->boolean('system_wide_learning')->default(false);
                $table->unsignedInteger('learning_event_retention_days')->nullable();
                $table->unsignedInteger('autonomy_evidence_retention_days')->nullable();
                $table->string('policy_version', 64);
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('titan_capability_training_stats')) {
            Schema::create('titan_capability_training_stats', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('tenant_company_id')->index();
                $table->string('learning_scope', 16); // user|business
                $table->string('subject_key', 64); // business|user:<id>
                $table->string('capability', 120)->index();
                $table->string('workflow_key', 120)->default('');
                $table->string('autonomy_level', 24);
                $table->unsignedBigInteger('sample_count')->default(0);
                $table->unsignedBigInteger('qualifying_success_count')->default(0);
                $table->unsignedBigInteger('correction_count')->default(0);
                $table->unsignedBigInteger('rejection_count')->default(0);
                $table->unsignedBigInteger('failure_count')->default(0);
                $table->unsignedBigInteger('reversal_count')->default(0);
                $table->decimal('action_selection_score', 7, 5)->nullable();
                $table->decimal('context_resolution_score', 7, 5)->nullable();
                $table->decimal('field_prediction_score', 7, 5)->nullable();
                $table->decimal('timing_score', 7, 5)->nullable();
                $table->decimal('authority_decision_score', 7, 5)->nullable();
                $table->decimal('content_output_score', 7, 5)->nullable();
                $table->timestamp('last_event_at')->nullable();
                $table->timestamps();
                $table->unique(
                    ['tenant_company_id', 'learning_scope', 'subject_key', 'capability', 'workflow_key', 'autonomy_level'],
                    'titan_capability_training_stats_scope_unique'
                );
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_capability_training_stats');
        if (Schema::hasTable('titan_learning_events') && Schema::hasColumn('titan_learning_events', 'learning_scopes_json')) {
            Schema::table('titan_learning_events', function (Blueprint $table): void {
                $table->dropColumn(['learning_scopes_json', 'policy_version']);
            });
        }
        Schema::dropIfExists('titan_learning_settings');
        Schema::dropIfExists('titan_autonomy_policies');
    }
};
