# Titan CRM Core Integration Boundary — alpha.27

CRM Core exposes governed customer/sales/commercial contracts to Titan surfaces without embedding or reclaiming external domain runtimes.

| Integration | CRM Core role | Boundary |
|---|---|---|
| Titan Hub | commercial/customer decorator | CRM profile/customer context, quotes, invoices and commercial documents; Field operations delegate outward |
| Titan Command | commercial owner-dashboard decorator | customers, leads/deals, quote approvals and invoice/receivables attention only |
| Titan Go / Titan Field | external owner | Titan Field owns jobs, scheduling, dispatch, offline mutation reconciliation and mobile delta state |
| TitanAI | Core tool provider | only CRM-owned active tools are advertised; writes stay governed |
| Interaction Engine | Core journey/action provider | only CRM-owned journeys/actions are advertised |
| Chatbot | Core customer/sales tool provider | no Field/Locker/Ledger/Pay action ownership |
| Titan Connect | outbound execution owner | CRM queues communication intent; Connect/provider receipt is delivery truth |
| Titan Command Bus | write governance owner | consequential CRM mutations enter through governed gateways |
| Titan Signal | event delivery owner | CRM commits transactional outbox rows; Signal delivery happens after commit |
| Titan Rewind | reconstruction owner | CRM receipts expose structured Rewind references |
| Titan Autonomy | authority owner | CRM asks through `CrmAutonomyDecisionPort`; missing engine means approval-only |
| Titan Field / Locker / Ledger / Pay | domain owners | legacy `crm.*` names are compatibility routing contracts only |

All CRM adapters consume trusted tenant context. No adapter accepts arbitrary browser tenant identity as authority.

## Compatibility rule

`CrmCapabilityOwnershipMap` and `CrmExternalDomainCapabilityBridge` are the only intentional legacy-domain routing layer. CRM Core does not keep per-class external-domain implementations or advertise their actions in active UI/AI registries.
