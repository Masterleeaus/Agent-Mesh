<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Exceptions;

use RuntimeException;

final class SourceVersionConflictException extends RuntimeException
{
}
