# Titan Signal Engine v0.18.0 — Production Hardening Pass 10

Pass 10 makes anomaly lifecycle decisions immutable and auditable. Acknowledge, suppress, resolve, and automatic reopen/recovery transitions now produce versioned Signal events in the same transaction as the mutable anomaly projection.

## Added

- `AnomalyDecisionAudit` immutable decision primitive
- anomaly `decision_version`, `last_decision_event_id`, `last_decision_at`
- four package-owned lifecycle event schemas
- `signal.anomaly.manage` Blueprint capability contract
- governed acknowledgement reason
- transactional fail-closed decision emission
- automatic reopen/trace-recovery decision audit
- standalone and Laravel host tests

## Boundary

The anomaly row remains a convenient mutable current-state projection. Immutable Signal events are the durable audit history and are never edited to match later decisions.
