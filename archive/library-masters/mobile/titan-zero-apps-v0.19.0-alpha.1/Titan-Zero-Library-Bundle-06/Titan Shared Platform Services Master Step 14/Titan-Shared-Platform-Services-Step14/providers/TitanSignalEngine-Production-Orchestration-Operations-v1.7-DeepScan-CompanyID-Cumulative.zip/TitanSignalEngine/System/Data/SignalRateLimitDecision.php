<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

final readonly class SignalRateLimitDecision
{
    public function __construct(
        public bool $allowed,
        public int $effectiveLimit,
        public int $observedCount,
        public bool $backpressureApplied,
    ) {
    }
}
