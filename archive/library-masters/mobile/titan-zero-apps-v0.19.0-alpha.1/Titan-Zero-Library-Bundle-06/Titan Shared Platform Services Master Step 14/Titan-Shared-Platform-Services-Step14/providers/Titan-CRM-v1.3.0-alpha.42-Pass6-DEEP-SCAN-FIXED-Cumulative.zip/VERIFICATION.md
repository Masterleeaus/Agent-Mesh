# Titan CRM Core v1.3.0-alpha.36 Verification

`php bin/verify.php` is the package release gate. It verifies:

- the post-split extraction contract
- alpha.25 production-hardening contract
- alpha.26 autonomy-deownership contract
- alpha.27 commercial-domain-boundary contract
- retained deterministic historical/Core regression gates
- standalone tests
- exact integrity inventory
- full PHP syntax

`php artisan crm:production-check` is the target-host production gate. Package verification does not substitute for real Laravel/MySQL boot, migrations, Command Bus, Signal, malware scanner, backup/restore, concurrency and load verification on the deployment host.

The final release must be unzipped into an empty directory and `php bin/verify.php` rerun against that exact extracted archive before delivery.

## Alpha.28
Run `php bin/verify-v130-alpha28-customer-authority.php` to validate the customer/organisation authority contract in addition to the master verifier.

## Alpha.29

`bin/verify-v130-alpha29-commercial-contracts.php` verifies immutable commercial snapshots, revision/supersession lifecycle, acceptance evidence, asynchronous document rendering, legacy backfill markers and release metadata. The master `bin/verify.php` includes this gate for alpha.29 and later.

## Alpha.30

`php bin/verify-v130-alpha30-invoice-receivables.php` verifies invoice contract lineage, Titan Pay de-ownership, settlement evidence, credit-note authority, ageing, reconciliation and production-health coverage. The master verifier includes this gate in cumulative package verification.


## Alpha.31
Run `php bin/verify-v130-alpha31-command-contract-v3.php` and `php artisan crm:governance:audit-writes`. The final ZIP must then pass `php bin/verify.php` from a clean extraction.


Alpha.32 operational checks: `crm:projections:rebuild`, `crm:projections:dead-letters`, and `crm:search`; AI OLTP fallback must remain disabled.

## Alpha.34 observability/reliability verification
`bin/verify-v130-alpha34-observability-reliability.php` verifies metrics/doctor commands, operational thresholds, duplicate replay durability, PASS/WARN/BLOCK health semantics, write-auditor classification and the operations runbook.


## Alpha.35 performance/scale verification
`php bin/verify-v130-alpha35-performance-scale.php` verifies the index migration, bulk projection writes, indexed projection search, bounded pipeline/timeline/detail reads, SQL aggregates, batched import staging, performance certification command and report. `php bin/benchmark-v130-alpha35-scale.php` is a dependency-free synthetic bounded-working-set check for logical 10k/100k/1m scales. Real database certification requires `php artisan crm:performance:certify <company_id> --iterations=5 --json` on the installed host.

## Alpha.36 canonical company tenancy verification

`php bin/verify-v130-alpha36-company-tenancy.php` verifies `company_id` runtime tenancy, `customer_company_id` relationship separation, company-scoped pipeline stages, company-level upsert identity, retired-menu self-healing, the fresh-install payment-table guard, the forward canonical-tenancy migration and the strict-host-permission production gate. Historical migrations may still contain `tenant_company_id`; authoritative runtime code may not.
