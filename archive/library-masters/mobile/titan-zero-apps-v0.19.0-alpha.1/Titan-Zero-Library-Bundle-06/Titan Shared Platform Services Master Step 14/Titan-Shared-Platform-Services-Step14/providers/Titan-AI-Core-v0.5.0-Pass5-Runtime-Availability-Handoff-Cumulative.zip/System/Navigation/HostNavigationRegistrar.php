<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Navigation;

use Illuminate\Contracts\Foundation\Application;
use ReflectionMethod;
use Throwable;

final class HostNavigationRegistrar
{
    private const USER_REGISTRY = 'App\\Support\\Extensions\\MenuContributionRegistry';
    private const GENERIC_REGISTRY = 'App\\Support\\Extensions\\ContributionRegistry';

    public function __construct(private readonly Application $app) {}

    /** @return array<string,bool> */
    public function registerAll(): array
    {
        return [
            'navigation.user' => $this->registerChannel('navigation.user', TitanAICoreNavigation::user(), self::USER_REGISTRY),
            'navigation.admin' => $this->registerChannel('navigation.admin', TitanAICoreNavigation::admin(), self::GENERIC_REGISTRY),
        ];
    }

    /** @param array<int,array<string,mixed>> $definitions */
    private function registerChannel(string $channel, array $definitions, string $registryClass): bool
    {
        if (! class_exists($registryClass)) {
            return false;
        }

        try {
            $registry = $this->app->make($registryClass);
            foreach (['register', 'contribute', 'add'] as $method) {
                if (! method_exists($registry, $method)) {
                    continue;
                }

                $this->invokeRegistry($registry, $method, $channel, $definitions);
                return true;
            }
        } catch (Throwable) {
            // Navigation compatibility is deliberately fail-open: a registry mismatch
            // must not break the AI Core runtime. Diagnose/host-sync exposes the state.
            return false;
        }

        return false;
    }

    /** @param array<int,array<string,mixed>> $definitions */
    private function invokeRegistry(object $registry, string $method, string $channel, array $definitions): void
    {
        $reflection = new ReflectionMethod($registry, $method);
        $count = $reflection->getNumberOfParameters();

        if ($count <= 1) {
            $registry->{$method}($definitions);
            return;
        }

        if ($count === 2) {
            $first = strtolower($reflection->getParameters()[0]->getName());
            if (str_contains($first, 'channel') || str_contains($first, 'surface')) {
                $registry->{$method}($channel, $definitions);
                return;
            }

            $registry->{$method}('titan-ai-core', $definitions);
            return;
        }

        $registry->{$method}($channel, 'titan-ai-core', $definitions);
    }
}
