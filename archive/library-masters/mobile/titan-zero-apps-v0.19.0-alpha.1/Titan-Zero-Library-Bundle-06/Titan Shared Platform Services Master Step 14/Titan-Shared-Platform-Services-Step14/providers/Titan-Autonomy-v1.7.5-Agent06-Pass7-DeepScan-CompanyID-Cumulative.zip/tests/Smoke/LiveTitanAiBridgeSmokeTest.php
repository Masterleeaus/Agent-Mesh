<?php
declare(strict_types=1);
spl_autoload_register(function(string $class):void{ $p='App\\Extensions\\TitanAutonomy\\'; if(!str_starts_with($class,$p))return; $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($path))require_once $path; });
use App\Extensions\TitanAutonomy\System\Infrastructure\{TitanAiRuntimeLiveBridge,UnavailableTitanAiRuntimeBridge};
$live=new TitanAiRuntimeLiveBridge(new stdClass());
if(($live->status()['available']??false)!==true)throw new RuntimeException('bound TitanAI runtime must report available');
$down=new UnavailableTitanAiRuntimeBridge();
if(($down->status()['available']??true)!==false)throw new RuntimeException('missing TitanAI must fail closed');
echo "OK: LiveTitanAiBridgeSmokeTest\n";
