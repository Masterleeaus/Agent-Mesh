<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Host;

use Illuminate\Database\Eloquent\Model;

/**
 * Compatibility-only host menu row.
 *
 * This model never represents Governance-owned persistence. It exists solely
 * to keep the legacy MagicAI navigation fallback behind an explicit host seam.
 */
final class LegacyMenuRow extends Model
{
    protected $table = 'menus';
    public $timestamps = false;
    protected $guarded = [];
}
