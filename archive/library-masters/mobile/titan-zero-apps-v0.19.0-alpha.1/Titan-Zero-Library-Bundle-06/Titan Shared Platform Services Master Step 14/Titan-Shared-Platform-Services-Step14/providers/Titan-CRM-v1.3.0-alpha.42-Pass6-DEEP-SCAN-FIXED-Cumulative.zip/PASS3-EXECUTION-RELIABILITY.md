# Pass 3 — Execution Reliability & Traceability

Version: 1.3.0-alpha.40

This pass introduces the canonical `titan.ecosystem.execution-envelope.v1` contract for cross-extension execution.

- `company_id` remains the sole tenant boundary.
- Correlation, causation, provider provenance and idempotency are mandatory across extension boundaries.
- Titan AI Workforce remains owner of staff identity and responsibility assignment.
- Titan Autonomy remains owner of effective authority decisions.
- Target domains remain systems of record for mutations.
- Retries reuse the same idempotency key; duplicates return the original receipt without re-execution.
- Unknown outcomes resolve to `deferred`, never fabricated success.
- Evidence references are supported without embedding secrets.
- Offline or missing-provider operation never raises authority.

Runtime support is provided by `System/Integration/EcosystemExecutionEnvelope.php`, with an executable contract test under `tests/`.
