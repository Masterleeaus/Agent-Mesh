# Titan Governance v1.0.0-rc.1 — Pass 8 H2 Installer 1.7.6 MySQL Migration Restartability Hotfix

## Triggering live failure

Installer 1.7.6 validated, deployed and loaded the Governance provider, then failed while running migration `2026_08_20_000004_add_governed_action_metadata.php` with MySQL error 1059 because Laravel generated the implicit index name `titan_governance_policy_decisions_authoritative_receipt_ref_index` (65 characters). MySQL permits at most 64 characters for identifiers.

The installer reported that three earlier Governance migrations had been recorded before the fourth migration failed, then attempted migration rollback with no rollback errors. Because MySQL DDL may commit individual ALTER operations before a migration is recorded, H2 treats migration 000004 as potentially partially applied on retry.

## Fix

- Preserve migration basenames and keep the package at four migrations.
- Modify only migration 000004, which did not complete/record successfully on the triggering host.
- Remove implicit `->index()` generation from every column added by 000004.
- Add explicit short index names; the previously failing index is now `tgov_policy_auth_receipt_idx`.
- Guard every 000004 index with `Schema::hasIndex(...)` so an already-created index is not duplicated.
- Guard the tenant + operation unique index by columns/type.
- Make `down()` remove only columns/indexes that actually exist.
- Extend the live fresh-install preflight with `mysql_identifier_safety` and `migration_000004_restartable` checks.

## Safety boundary

Migrations 000001–000003 remain byte-identical to H1. H2 adds no fifth migration, changes no business mutation behavior, and does not claim the live migration stage passed until this exact H2 ZIP is retried on the host.
