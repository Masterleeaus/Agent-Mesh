# Titan Prime — Upgrade Prompt

# Titan Zero Global Architecture Rules

This extension is part of the governed Titan Zero architecture. Preserve these boundaries:

- AI intelligence never directly mutates authoritative business state when a governed capability/Command Bus path exists.
- Intelligence, risk, assurance, autonomy, approval and execution remain separate concerns.
- Every significant action emits structured Signal telemetry and a traceable receipt.
- Use tenant_company_id, trace_id, correlation_id and causation_id on durable cross-extension records/events.
- Do not store unrestricted hidden model reasoning; store structured decision rationale, reason codes, policy/evidence references and outcomes.
- Offline operation may reduce authority but must never increase it.
- External side effects must be idempotent.
- Preserve installer compatibility and existing working host UI conventions.
- Prefer shared contracts/adapters over importing another extension's internal implementation classes.

## Extension Mission

MISSION: Build Titan Prime as the renamed Nova: Titan's highest-level strategic operator.

Prime may identify opportunities, propose launches, commission Nexus compilations, commission Forge builds, request Workforce structures, monitor outcomes and recommend changes.

Prime MUST NOT bypass Runtime, Risk, Assurance, Autonomy, Command Bus or authoritative domain boundaries.

NEXT BUILD:
1. Strategic Mission/Objective/Proposal contracts.
2. Long-running mission state with explicit checkpoints and approvals.
3. Delegate operational work through Titan AI Core/Workforce rather than direct tools.
4. Consume Wisdom outcomes and Signal health.
5. Cost/risk budgets per mission.
6. Human approval for production-generating or high-consequence missions.
7. Full Rewind traceability.

## Universal Acceptance

- Installer/manifest validation passes.
- PHP syntax checks pass.
- Tenant boundaries are explicit.
- Cross-engine calls use public contracts/adapters.
- Significant states are traceable.
- No high-risk or authoritative mutation bypass is introduced.
## Current Baseline (v0.4.0)

- Domain Core and durable tenant-scoped mission store are implemented.
- Typed fail-closed gateway contracts now exist for AI Core, Signal, Risk, Assurance, Autonomy, Governance, Rewind and Wisdom.
- The default engine bridge is deliberately unavailable until a trusted host/public-contract adapter is bound.
- Orchestration, queues, Command Bus delegation and autonomous execution remain disabled.
- Next functional pass: governed delegation and decision-chain composition without authority inflation.

