# Titan Bookings & Quotes Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a single production-grade Titan Bookings & Quotes extension from the Front Office donor bundle.

**Architecture:** Rebuild donor capabilities behind canonical booking and quote aggregates using `company_id` as the sole tenant boundary. Cross-extension behavior is port/Signal/Command-Bus based; the extension never becomes CRM, Scheduling, Workforce, Finance, Payments or field-execution authority.

**Tech Stack:** PHP 8.3, Laravel 10, Blade, JSON manifests, Titan Extension Installer 1.7.8, Blueprint Manifest 2.2, Workforce Manifest 2.0.

**Spec:** `docs/superpowers/specs/2026-08-22-titan-bookings-quotes-design.md`

## Global Constraints
- `company_id` is the sole canonical company/tenant boundary in all new contracts, persistence, authorization and queries.
- No direct peer-extension private-table access.
- No state-changing GET routes.
- Public/API identity uses opaque public IDs, never sequential internal IDs.
- Every state-changing command is idempotent and optimistic-concurrency safe.
- AI cannot self-approve and all governed mutations route through Command Bus/authority ports.
- Donor import is explicit, mapped, resumable and never an automatic host-table rewrite.
- Every pass produces a cumulative flat-root Installer 1.7.8 ZIP and is freshly extracted/reverified before completion.

---

### Task 1: Pass 1 — Foundation, Donor Normalization & Authority
**Files:** Create extension shell, Manifest 2.2, provider, config, canonical contracts, donor inventory, ownership matrix, Workforce Manifest 2.0, tests.
**Interfaces:** Produces `BookingReadPort`, `BookingCommandPort`, `QuoteReadPort`, `QuoteCommandPort`, `CustomerReferencePort`, `SchedulingHandoffPort`, `InvoiceHandoffPort`, `PaymentIntentPort`, `GovernanceAuthorityPort`, `CommandBusPort`.
- [ ] Write failing architecture tests requiring `company_id`, deny-by-default authorization, no donor peer-table ownership and typed ports.
- [ ] Run tests and confirm RED for missing extension foundation.
- [ ] Implement flat-root extension shell, provider, manifests, ownership docs and typed ports.
- [ ] Add explicit donor inventory mapping BookingModule/Quotes/Quoting Wizard/QuoteEngine/FSMSales/agreement donors to keep/adapt/retire decisions.
- [ ] Run cumulative tests, PHP lint, JSON parse and manifest checks until GREEN.
- [ ] Seal and freshly verify `Titan-Bookings-Quotes-v0.1.0-alpha.1-Pass1-Foundation-Cumulative.zip`.

### Task 2: Pass 2 — Canonical Booking Engine
**Files:** Create booking models/migrations, lifecycle state machine, idempotent commands, availability requirement DTOs, import adapter and tests.
**Interfaces:** Produces `BookingLifecycleService::execute(BookingCommand): BookingReceipt` and booking read projections.
- [ ] Write RED tests for company isolation, lifecycle legality, idempotency, stale-version rejection and no scheduling ownership.
- [ ] Implement `titan_bq_bookings`, booking scope/site/request-window tables and append-only lifecycle events using `company_id`.
- [ ] Implement explicit mapped BookingModule importer that refuses ambiguous company ownership.
- [ ] Verify booking transitions and importer replay safety.
- [ ] Seal/freshly verify cumulative alpha.2 ZIP.

### Task 3: Pass 3 — Quote, Pricing & Versioning Engine
**Files:** Create quote/version/line/acceptance models and migrations, money/value objects, pricing snapshot service, expiry service and tests.
**Interfaces:** Produces immutable quote versions and `QuoteLifecycleService`.
- [ ] Write RED tests for deterministic totals, immutable sent versions, acceptance idempotency, expiry and stale-version rejection.
- [ ] Implement quote numbering scoped by `company_id`, immutable pricing snapshots and version lineage.
- [ ] Adapt safe Quoting Wizard/QuoteEngine calculation concepts without inheriting duplicate donor storage.
- [ ] Implement variation/requote lineage without invoice ownership.
- [ ] Seal/freshly verify cumulative alpha.3 ZIP.

### Task 4: Pass 4 — Titan Hub Customer Journeys
**Files:** Create Hub controllers/routes/views/API resources, signed/opaque customer access contracts, acceptance evidence service and tests.
**Interfaces:** Customer actor can request service, inspect quote, accept/reject and approve variations within derived authority.
- [ ] Write RED tests for IDOR, cross-company access, replayed acceptance, expired quotes and caller-supplied authority.
- [ ] Implement actor-derived customer access and quote acceptance/rejection.
- [ ] Implement booking/status and variation approval journeys.
- [ ] Ensure no customer endpoint can set company/customer authority fields.
- [ ] Seal/freshly verify cumulative alpha.4 ZIP.

### Task 5: Pass 5 — Scheduling, Job, Invoice & Payment Handoffs
**Files:** Implement typed outbound ports/adapters, handoff receipts, idempotency registry, retryable outbox events and tests.
**Interfaces:** `SchedulingHandoffPort`, `JobHandoffPort`, `InvoiceHandoffPort`, `PaymentIntentPort`; no peer private-table access.
- [ ] Write RED contract tests proving missing peers fail closed and duplicate handoffs do not duplicate external work.
- [ ] Convert BookingModule dispatch/schedule ownership into scheduling requirement handoffs.
- [ ] Convert FSMSales auto-invoice concepts into governed invoice-request handoffs.
- [ ] Add deposit/payment-intent request contracts without owning payment ledger/card data.
- [ ] Seal/freshly verify cumulative alpha.5 ZIP.

### Task 6: Pass 6 — Workforce Intelligence, Signals & Proactive Responsibilities
**Files:** Add durable outbox, Signal/Rewind contributor, deterministic detectors, Workforce roles/tools/responsibilities and tests.
**Interfaces:** Privacy-minimized facts plus governed proposals only.
- [ ] Write RED tests for privacy allowlists, no self-approval, deterministic detectors and proactive-task idempotency.
- [ ] Implement stale-quote, expiring-quote, missing-scope, booking-conversion and failed-handoff detectors.
- [ ] Add Workforce roles for Front Office Manager, Booking Coordinator, Estimator/Quote Specialist and Conversion Analyst.
- [ ] Route every mutation through Command Bus/governance authority.
- [ ] Seal/freshly verify cumulative alpha.6 ZIP.

### Task 7: Pass 7 — Titan Zero Operational UI & Versioned API
**Files:** Create Bookings/Quotes/Builder/Approvals/Timeline/settings surfaces, navigation, `/api/v1/titan-bookings-quotes`, query repositories and tests.
**Interfaces:** Bounded opaque-ID read/write API with exact-host authorization middleware.
- [ ] Write RED tests for required surfaces, menu entries, pagination ≤100, IDOR and management-field protection.
- [ ] Implement operational screens and quote builder using canonical domain services.
- [ ] Implement versioned API with actor-derived company context.
- [ ] Add host menu repair command without taking ownership of administrator ordering/enabled state.
- [ ] Seal/freshly verify cumulative rc.0 ZIP.

### Task 8: Pass 8 — Deep Hardening, Import & Production Certification
**Files:** Add hardening tests, indexes, operational commands, upgrade/uninstall/DR docs, provenance/SBOM/integrity and certification report.
**Interfaces:** Final release candidate with explicit exact-host evidence.
- [ ] Write RED tests for query bounds, tenant-scoped mutations, private evidence storage, outbox overlap safety and import resumability.
- [ ] Deep scan for debug/process execution, unsafe SQL, state-changing GET, mass-assignable `company_id`, unbounded reads and peer private-table access.
- [ ] Optimize indexes for company/status/date/public-ID/idempotency access paths.
- [ ] Add resumable donor import with dry-run and reconciliation report.
- [ ] Run cumulative tests, all PHP lint, JSON schemas, Blueprint/Installer gates and ZIP integrity.
- [ ] Fresh-extract exact final ZIP and rerun all available gates.
- [ ] Run exact-host INSTALLER→MIGRATION→BOOT→NAVIGATION→AUTHORIZATION→RUNTIME→UPGRADE→UNINSTALL when a host is mounted; otherwise report those stages `NOT_RUN`.
- [ ] Seal `Titan-Bookings-Quotes-v1.0.0-rc.1-Pass8-Production-Certification-Cumulative.zip`.
