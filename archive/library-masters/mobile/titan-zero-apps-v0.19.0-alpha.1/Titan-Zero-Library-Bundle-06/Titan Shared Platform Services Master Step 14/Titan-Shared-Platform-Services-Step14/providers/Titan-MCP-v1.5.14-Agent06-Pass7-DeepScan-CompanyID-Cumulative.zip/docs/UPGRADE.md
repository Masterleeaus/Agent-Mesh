# Upgrade

Upgrades are forward-only. Replace the extension through Titan Extension Manager using a newer package with the same `titan-mcp` registration key and `TitanMcp` folder. Migrations are idempotent against shared permission/menu tables. Existing recovery data and settings are preserved.
