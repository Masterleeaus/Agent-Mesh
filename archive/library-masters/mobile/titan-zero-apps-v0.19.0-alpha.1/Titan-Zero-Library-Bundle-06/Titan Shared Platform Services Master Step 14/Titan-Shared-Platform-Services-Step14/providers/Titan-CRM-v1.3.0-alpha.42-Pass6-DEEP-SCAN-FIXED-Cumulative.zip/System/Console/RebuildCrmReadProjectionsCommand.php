<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\ReadModels\CrmProjectionBuilder;
use Illuminate\Console\Command;

final class RebuildCrmReadProjectionsCommand extends Command
{
    protected $signature='crm:projections:rebuild {company_id : Canonical tenant company ID} {--projection= : Optional single projection name} {--incremental : Process from a durable numeric checkpoint} {--until-complete : Continue incremental batches until the projection is complete} {--batch= : Incremental batch size}';
    protected $description='Rebuild disposable CRM CQRS projections with bounded memory and durable incremental checkpoints.';
    public function handle(CrmProjectionBuilder $builder): int
    {
        $tenant=(int)$this->argument('company_id');if($tenant<1){$this->error('company_id must be a positive integer.');return self::FAILURE;}$projection=trim((string)$this->option('projection'));$batch=$this->option('batch')!==null?(int)$this->option('batch'):null;
        if((bool)$this->option('incremental')){if($projection===''){$this->error('--incremental requires --projection.');return self::FAILURE;}$result=$builder->rebuildProjectionIncremental($tenant,$projection,$batch);if((bool)$this->option('until-complete')){while(!($result['completed']??true)){$result=$builder->rebuildProjectionIncremental($tenant,$projection,$batch);}}}
        else{$result=$builder->rebuild($tenant,$projection!==''?$projection:null);}
        $this->line(json_encode($result,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));return self::SUCCESS;
    }
}
