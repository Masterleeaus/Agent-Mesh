# Pass 3 Verification — Self-Service, Operational UI & Host-Compatible APIs

Pass 3 turns the People foundation into real authenticated browser and API surfaces without expanding People into attendance, scheduling, finance, payroll, credentials, recruiting, performance or onboarding ownership.

## TDD evidence

Five focused Pass 3 suites were observed RED before implementation for operational surfaces, authenticated self-service, bounded/versioned APIs, tenant/opaque-ID read boundaries and completed navigation. A sixth adversarial management-edit test was then observed RED for host-owned/authority fields before the management policy was hardened.

## Implemented surface

- Overview, People Directory, Person detail/edit, Organisation, Leave & Absence, Holidays, Lifecycle and My Profile browser surfaces.
- All browser/API requests run through the Step 10 compatible `TitanHostAuthorizationAdapter` and a trusted authenticated People execution context.
- Self-service derives the worker from `PeopleIdentityPort`; caller-supplied worker/tenant IDs are never accepted as authority.
- Generic person edits cannot write lifecycle state, organisation authority, leave balances, tenant/worker identifiers, passwords or avatars.
- API family is `/api/v1/titan-people`, uses opaque People public IDs and bounded pagination (default 25, max 100).
- Navigation has the People parent plus seven real children and retains `titan-people:host-sync` repair/cache regeneration.

## Pre-package acceptance evidence

- Cumulative executable suite: 24/24 test files PASS before release sealing.
- PHP lint and JSON parse are clean on the working tree.
- No state-changing GET routes.
- No `auth:sanctum` or `auth:api` dependency remains in People routes.
- No new migration/table ownership was added in Pass 3.
- No attendance/shift/expense/payroll-bank persistence was introduced.

## Host certification ladder

This package is statically package-verified only. A live MagicAI/Titan host is not mounted in this environment, so INSTALLER, MIGRATION, BOOT, NAVIGATION, AUTHORIZATION, RUNTIME, UPGRADE and UNINSTALL remain `NOT_RUN` until executed on the exact host.
