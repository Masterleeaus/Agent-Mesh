<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyControlStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\ControlPlaneAuditSinkContract;

final class LearningResetService
{
    public function __construct(
        private readonly AutonomyControlStoreContract $store,
        private readonly string $policyVersion,
        private readonly ?ControlPlaneAuditSinkContract $audit = null,
    ) {}

    public function resetCapability(
        int $tenantCompanyId,
        string $capability,
        string $workflowKey,
        string $targetLevel = 'suggest',
        ?int $actorUserId = null,
        ?string $correlationId = null,
    ): void {
        if (!in_array($targetLevel, ['suggest', 'assist'], true)) $targetLevel = 'suggest';
        $this->store->resetCapabilityLearning($tenantCompanyId, $capability, $workflowKey, $targetLevel, $this->policyVersion);
        $this->audit?->record([
            'tenant_company_id' => $tenantCompanyId,
            'user_id' => $actorUserId,
            'event_type' => 'learning.capability_reset',
            'capability' => $capability,
            'workflow_key' => $workflowKey,
            'payload' => ['target_level' => $targetLevel, 'evidence_cleared' => true],
            'policy_version' => $this->policyVersion,
            'correlation_id' => $correlationId,
        ]);
    }

    public function clearPreferences(int $tenantCompanyId, ?int $userId = null, ?int $actorUserId = null, ?string $correlationId = null): int
    {
        $deleted = $this->store->clearPreferences($tenantCompanyId, $userId);
        $this->audit?->record([
            'tenant_company_id' => $tenantCompanyId,
            'user_id' => $actorUserId,
            'event_type' => 'learning.preferences_cleared',
            'payload' => ['subject_user_id' => $userId, 'deleted_count' => $deleted],
            'policy_version' => $this->policyVersion,
            'correlation_id' => $correlationId,
        ]);
        return $deleted;
    }
}
