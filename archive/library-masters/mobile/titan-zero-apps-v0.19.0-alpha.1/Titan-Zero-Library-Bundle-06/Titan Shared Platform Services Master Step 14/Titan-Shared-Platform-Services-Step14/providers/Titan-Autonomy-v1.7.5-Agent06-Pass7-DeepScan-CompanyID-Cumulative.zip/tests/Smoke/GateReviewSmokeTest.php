<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\Extensions\\TitanAutonomy\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $path = dirname(__DIR__, 2) . '/' . $relative . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanAutonomy\System\Contracts\AssuranceBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\AutonomyAuditSinkContract;
use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;
use App\Extensions\TitanAutonomy\System\Contracts\CapabilityStateStoreContract;
use App\Extensions\TitanAutonomy\System\Contracts\TitanAiRuntimeBridgeContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\HandshakeDecision;
use App\Extensions\TitanAutonomy\System\Services\AutonomyGrantService;
use App\Extensions\TitanAutonomy\System\Services\GateReviewService;
use App\Extensions\TitanAutonomy\System\Services\TrustedAutoReviewService;

function gcheck(bool $condition, string $message): void { if (!$condition) throw new RuntimeException($message); }

$query = new class implements AutonomyQueryContract {
    public function capabilityStates(int $tenantCompanyId): array { return []; }
    public function capabilityState(int $tenantCompanyId, string $capability, string $workflowKey): ?array { return [
        'tenant_company_id'=>$tenantCompanyId,'capability'=>$capability,'workflow_key'=>$workflowKey,'risk'=>'medium',
        'current_level'=>'auto','next_level'=>'trusted_auto','required_success_streak'=>2,'current_success_streak'=>2,
        'highest_success_streak'=>6,'total_successes'=>18,'total_failures'=>1,'total_edits'=>1,'total_rejections'=>0,'total_reversals'=>0,
        'platform_gate_eligible'=>true,'maximum_allowed_level'=>'trusted_auto','scope'=>['workflow'=>'completed_job_invoice'],
    ]; }
    public function learningEvents(int $tenantCompanyId, ?string $capability=null, ?string $workflowKey=null, int $limit=1000): array { return []; }
    public function learningPreferences(int $tenantCompanyId, ?int $userId=null): array { return []; }
    public function learningSettings(int $tenantCompanyId): array { return []; }
    public function tenantPolicy(int $tenantCompanyId): ?array { return null; }
    public function platformPolicy(): ?array { return null; }
    public function handshakes(int $tenantCompanyId, ?string $capability=null, ?string $workflowKey=null, int $limit=100): array { return []; }
    public function regressions(int $tenantCompanyId, ?string $capability=null, ?string $workflowKey=null, int $limit=100): array { return []; }
};
$store = new class implements CapabilityStateStoreContract { public ?CapabilityState $saved=null; public function save(CapabilityState $state): void {$this->saved=$state;} };
$audit = new class implements AutonomyAuditSinkContract {
    public array $handshakes=[];
    public function recordGateDecision(array $event): string { return 'gate-1'; }
    public function recordHandshake(array $event): string { $this->handshakes[]=$event; return 'hs-'.count($this->handshakes); }
    public function recordRegression(array $event): string { return 'reg-1'; }
};
$grant = new AutonomyGrantService($store, $audit, 'v1.3');
$gateReview = new GateReviewService($query);

$denyingAssurance = new class implements AssuranceBridgeContract { public function evaluate(string $capability, ?string $workflowKey, array $context): array { return ['status'=>'AMBER','decision'=>'denied','confidence'=>0.61,'reason_codes'=>['RECENT_MATERIAL_CORRECTIONS'],'evaluation_ref'=>'assure-1']; } };
$trusted = new TrustedAutoReviewService($query, $gateReview, $grant, $denyingAssurance);
$denied = $trusted->reviewAndGrant(7,'crm.invoice.issue','completed_job_invoice',42,true,HandshakeDecision::Approved,['workflow'=>'completed_job_invoice','max_total'=>1500]);
gcheck(!$denied->approved, 'AI/Assurance denial must block Trusted Auto');
gcheck($store->saved === null, 'denied Trusted Auto must not persist promotion');

$greenAssurance = new class implements AssuranceBridgeContract { public function evaluate(string $capability, ?string $workflowKey, array $context): array { return ['status'=>'GREEN','decision'=>'approved','confidence'=>0.96,'reason_codes'=>['SUFFICIENT_HISTORY','STABLE_CONTEXT'],'evaluation_ref'=>'assure-2']; } };
$trustedNoAi = new TrustedAutoReviewService($query, $gateReview, $grant, $greenAssurance);
$noAi = $trustedNoAi->reviewAndGrant(7,'crm.invoice.issue','completed_job_invoice',42,true,HandshakeDecision::Approved,['workflow'=>'completed_job_invoice','max_total'=>1500]);
gcheck(!$noAi->approved, 'Trusted Auto must fail closed when the TitanAI runtime is unavailable');

$liveTitanAi = new class implements TitanAiRuntimeBridgeContract { public function status(): array { return ['available'=>true,'reason_codes'=>[],'class'=>'fake-runtime']; } };
$trusted2 = new TrustedAutoReviewService($query, $gateReview, $grant, $greenAssurance, $liveTitanAi);
$emptyScope = $trusted2->reviewAndGrant(7,'crm.invoice.issue','completed_job_invoice',42,true,HandshakeDecision::Approved,[]);
gcheck(!$emptyScope->approved, 'Trusted Auto must require bounded scope');

$approved = $trusted2->reviewAndGrant(7,'crm.invoice.issue','completed_job_invoice',42,true,HandshakeDecision::Approved,['workflow'=>'completed_job_invoice','max_total'=>1500,'requires_no_dispute'=>true]);
gcheck($approved->approved, 'three-way approval with bounded scope must grant Trusted Auto');
gcheck($store->saved?->currentLevel === AutonomyLevel::TrustedAuto, 'approved grant must persist Trusted Auto state');
gcheck(($audit->handshakes[array_key_last($audit->handshakes)]['ai_decision'] ?? null) === 'approved', 'handshake must persist AI decision');


$strictQuery = new class implements AutonomyQueryContract {
    public function capabilityStates(int $tenantCompanyId): array { return []; }
    public function capabilityState(int $tenantCompanyId, string $capability, string $workflowKey): ?array { return [
        'tenant_company_id'=>$tenantCompanyId,'capability'=>$capability,'workflow_key'=>$workflowKey,'risk'=>'medium',
        'current_level'=>'assist','next_level'=>'semi_auto','required_success_streak'=>2,'current_success_streak'=>2,
        'highest_success_streak'=>2,'total_successes'=>2,'total_failures'=>0,'total_edits'=>0,'total_rejections'=>0,'total_reversals'=>0,
        'platform_gate_eligible'=>true,'maximum_allowed_level'=>'trusted_auto','scope'=>[],
    ]; }
    public function learningEvents(int $tenantCompanyId, ?string $capability=null, ?string $workflowKey=null, int $limit=1000): array { return []; }
    public function learningPreferences(int $tenantCompanyId, ?int $userId=null): array { return []; }
    public function learningSettings(int $tenantCompanyId): array { return []; }
    public function tenantPolicy(int $tenantCompanyId): ?array { return null; }
    public function platformPolicy(): ?array { return ['gate_minimums'=>['low'=>1,'medium'=>3,'high'=>3,'critical'=>3], 'maximum_level_by_risk'=>['low'=>'trusted_auto','medium'=>'trusted_auto','high'=>'auto','critical'=>'semi_auto'], 'system_wide_learning_permitted'=>false]; }
    public function handshakes(int $tenantCompanyId, ?string $capability=null, ?string $workflowKey=null, int $limit=100): array { return []; }
    public function regressions(int $tenantCompanyId, ?string $capability=null, ?string $workflowKey=null, int $limit=100): array { return []; }
};
$strictReview = (new GateReviewService($strictQuery))->review(7,'crm.invoice.issue','completed_job_invoice');
gcheck(!$strictReview['gate']->eligible, 'stricter current platform policy must invalidate stale persisted eligibility');
gcheck(in_array('SUCCESS_STREAK_INSUFFICIENT_CURRENT_POLICY', $strictReview['gate']->reasonCodes, true), 'gate review must explain current-policy streak denial');

echo "OK: GateReviewSmokeTest\n";
