<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Reconstruction;

use DateTimeImmutable;
use DateTimeZone;

final class RewindTimelineAssembler
{
    public function order(array $events): array
    {
        usort($events, function (array $left, array $right): int {
            $sequence = ((int) ($left['sequence'] ?? 0)) <=> ((int) ($right['sequence'] ?? 0));
            if ($sequence !== 0) {
                return $sequence;
            }

            $time = strcmp($this->timeKey($left['occurred_at'] ?? null), $this->timeKey($right['occurred_at'] ?? null));
            if ($time !== 0) {
                return $time;
            }

            return strcmp((string) ($left['event_id'] ?? ''), (string) ($right['event_id'] ?? ''));
        });

        return array_values($events);
    }

    public function causation(array $orderedEvents): array
    {
        $ids = [];
        foreach ($orderedEvents as $event) {
            if (!empty($event['event_id'])) {
                $ids[(string) $event['event_id']] = true;
            }
        }

        $edges = [];
        $orphans = [];
        foreach ($orderedEvents as $event) {
            $child = (string) ($event['event_id'] ?? '');
            $parent = trim((string) ($event['causation_id'] ?? ''));
            if ($child === '' || $parent === '') {
                continue;
            }

            if (isset($ids[$parent])) {
                $edges[] = ['from' => $parent, 'to' => $child];
            } else {
                $orphans[] = ['event_id' => $child, 'missing_causation_id' => $parent];
            }
        }

        return ['edges' => $edges, 'orphans' => $orphans];
    }

    private function timeKey(mixed $value): string
    {
        $raw = trim((string) $value);
        if ($raw === '') {
            return '9999-12-31T23:59:59.999999Z';
        }

        try {
            return (new DateTimeImmutable($raw))
                ->setTimezone(new DateTimeZone('UTC'))
                ->format('Y-m-d\\TH:i:s.u\\Z');
        } catch (\Throwable) {
            return $raw;
        }
    }
}
