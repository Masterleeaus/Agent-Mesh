# Titan Model Council — Blueprint v4.2 Rebase Report

Baseline: Titan Model Council v0.6.0 Pass 5. Canonical standard: Titan Extension Blueprint v4.2.0.

## Deep-scan findings

1. Legacy root manifest was incompatible with Installer 1.7.8.
2. Sidecar was schema 1.0 and contained an unsupported custom `governed_deliberation` field.
3. Billing and credential-storage manifest values were outside Blueprint enums.
4. Optional dependencies used obsolete string form.
5. Active repositories bypassed domain persistence through raw `DB::table()` access.
6. A compatibility poll used an unbounded collection query.
7. Canonical Signal causal context lacked `root_causation_id` persistence.
8. Blueprint already registers `titan-model-council` as canonical owner of `model-deliberation`, but had no specialized Model Council template.
9. The currently available historical Signal package uses slug `titan-signal-engine`; Blueprint v4.2 canonical identity is `titan-signal`. Runtime compatibility supports both contract namespaces, but canonical installation requires a rebased `titan-signal`.
10. Current AI Core v0.2 exposes health only, so provider execution cannot honestly be claimed as AI-Core-owned yet.

## Rebase actions

The package now uses schema 2.2, governance-engine + ai-enabled + signal-aware architecture, canonical Signal dependency, typed capability/event schemas, extension-local certification, Eloquent-owned persistence, causal Signal emission, explicit compatibility write policy, and development-stage supply-chain evidence. Legacy source remains forensic-only and unchanged.

## Release status

This package may be locally package-verified after the supplied Blueprint validators pass. It is **not host-certified or production-signed** without running the certification command in the target MagicAI host and applying the required signing workflow.
