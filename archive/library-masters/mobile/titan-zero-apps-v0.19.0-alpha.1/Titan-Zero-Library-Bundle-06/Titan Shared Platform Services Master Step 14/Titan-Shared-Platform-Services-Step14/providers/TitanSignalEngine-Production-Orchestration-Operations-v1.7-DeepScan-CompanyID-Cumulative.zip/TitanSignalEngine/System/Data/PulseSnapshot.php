<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use DateTimeImmutable;

final readonly class PulseSnapshot
{
    /**
     * @param array<string,int|float|null> $metrics
     * @param array<string,mixed> $latency
     * @param array<string,mixed> $health
     * @param list<array<string,mixed>> $sources
     * @param list<array<string,mixed>> $topEventTypes
     */
    public function __construct(
        public string $scope,
        public ?int $tenantCompanyId,
        public PulseWindow $window,
        public DateTimeImmutable $generatedAt,
        public array $metrics,
        public array $latency,
        public array $health,
        public PulseAttentionScore $attention,
        public array $sources,
        public array $topEventTypes,
    ) {
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'scope' => $this->scope,
            'tenant_company_id' => $this->tenantCompanyId,
            'window' => [
                'key' => $this->window->key,
                'seconds' => $this->window->seconds,
                'granularity' => $this->window->granularity,
                'start' => $this->window->start->format(DATE_ATOM),
                'end' => $this->window->end->format(DATE_ATOM),
            ],
            'generated_at' => $this->generatedAt->format(DATE_ATOM),
            'metrics' => $this->metrics,
            'latency' => $this->latency,
            'health' => $this->health,
            'attention' => $this->attention->toArray(),
            'sources' => $this->sources,
            'top_event_types' => $this->topEventTypes,
        ];
    }
}
