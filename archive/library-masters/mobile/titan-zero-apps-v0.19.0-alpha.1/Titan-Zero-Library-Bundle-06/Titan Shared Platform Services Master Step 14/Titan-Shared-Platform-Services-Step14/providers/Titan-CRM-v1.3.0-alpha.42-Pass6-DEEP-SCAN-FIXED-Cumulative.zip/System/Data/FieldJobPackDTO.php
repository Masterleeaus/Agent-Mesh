<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Data;

final class FieldJobPackDTO
{
    public function __construct(
        public readonly mixed $worker,
        public readonly mixed $workOrder,
        public readonly mixed $customer,
        public readonly mixed $location,
        public readonly mixed $tasks,
        public readonly mixed $forms,
        public readonly mixed $evidenceRequirements,
        public readonly mixed $service,
        public readonly mixed $revision,
    ) {}

    public function toArray(): array
    {
        return [
            'worker'=>$this->worker,
            'workOrder'=>$this->workOrder,
            'customer'=>$this->customer,
            'location'=>$this->location,
            'tasks'=>$this->tasks,
            'forms'=>$this->forms,
            'evidenceRequirements'=>$this->evidenceRequirements,
            'service'=>$this->service,
            'revision'=>$this->revision,
        ];
    }
}
