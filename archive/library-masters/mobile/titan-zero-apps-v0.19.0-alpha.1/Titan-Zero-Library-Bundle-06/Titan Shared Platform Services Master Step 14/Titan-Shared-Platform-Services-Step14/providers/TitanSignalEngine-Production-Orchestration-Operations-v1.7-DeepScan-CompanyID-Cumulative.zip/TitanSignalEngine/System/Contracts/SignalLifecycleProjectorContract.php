<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;

interface SignalLifecycleProjectorContract
{
    public function project(SignalEvent $event): void;
}
