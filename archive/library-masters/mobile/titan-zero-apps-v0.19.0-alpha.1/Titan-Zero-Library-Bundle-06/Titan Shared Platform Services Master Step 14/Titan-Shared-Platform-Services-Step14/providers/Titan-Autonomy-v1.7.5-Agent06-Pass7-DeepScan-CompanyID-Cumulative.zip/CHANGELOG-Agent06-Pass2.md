## 1.7.5 — Agent-06 Upgrade Pass 2
- Workforce provider contract v1.1 with per-capability operational policy metadata.
- Command-bus/receipt enforcement metadata for state-changing Workforce actions.
- Explicit provider health, degradation, idempotency, offline and provenance requirements.
- Standalone schema/contract consistency verification.
