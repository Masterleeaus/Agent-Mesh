<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_command_receipts')) {
            // v0.1 scaffold used UUID-only columns, but Titan causal IDs are contract strings
            // (UUID/ULID/provider trace forms). Normalize without changing their meaning.
            if (Schema::hasColumn('titan_command_receipts', 'trace_id') && Schema::hasColumn('titan_command_receipts', 'correlation_id')) {
                Schema::table('titan_command_receipts', function (Blueprint $table): void {
                    $table->string('trace_id', 191)->nullable()->change();
                    $table->string('correlation_id', 191)->nullable()->change();
                });
            }
            Schema::table('titan_command_receipts', function (Blueprint $table): void {
                $columns = [
                    'command_id' => fn () => $table->string('command_id', 64)->nullable()->index(),
                    'idempotency_key' => fn () => $table->string('idempotency_key', 191)->nullable()->index(),
                    'request_hash' => fn () => $table->string('request_hash', 64)->nullable(),
                    'causation_id' => fn () => $table->string('causation_id', 191)->nullable()->index(),
                    'root_causation_id' => fn () => $table->string('root_causation_id', 191)->nullable()->index(),
                    'actor_type' => fn () => $table->string('actor_type', 64)->nullable(),
                    'actor_id' => fn () => $table->string('actor_id', 191)->nullable()->index(),
                    'service_id' => fn () => $table->string('service_id', 191)->nullable()->index(),
                    'capability' => fn () => $table->string('capability', 191)->nullable()->index(),
                    'reason_code' => fn () => $table->string('reason_code', 191)->nullable()->index(),
                    'risk_class' => fn () => $table->string('risk_class', 32)->nullable(),
                    'governance_reference' => fn () => $table->string('governance_reference', 191)->nullable(),
                    'approval_reference' => fn () => $table->string('approval_reference', 191)->nullable(),
                    'adapter' => fn () => $table->string('adapter', 255)->nullable(),
                    'domain_receipt_reference' => fn () => $table->string('domain_receipt_reference', 255)->nullable(),
                    'write_verified' => fn () => $table->boolean('write_verified')->nullable(),
                    'expected_entity_version' => fn () => $table->string('expected_entity_version', 191)->nullable(),
                    'result_entity_type' => fn () => $table->string('result_entity_type', 191)->nullable(),
                    'result_entity_id' => fn () => $table->string('result_entity_id', 191)->nullable(),
                    'result_entity_version' => fn () => $table->string('result_entity_version', 191)->nullable(),
                    'replayed' => fn () => $table->boolean('replayed')->default(false),
                    'executed_at' => fn () => $table->timestamp('executed_at')->nullable(),
                ];
                foreach ($columns as $name => $definition) {
                    if (! Schema::hasColumn('titan_command_receipts', $name)) {
                        $definition();
                    }
                }
            });
        }

        if (! Schema::hasTable('titan_command_idempotency')) {
            Schema::create('titan_command_idempotency', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('tenant_company_id');
                $table->string('idempotency_key', 191);
                $table->string('request_hash', 64);
                $table->string('command_id', 64)->index();
                $table->string('status', 32)->default('processing')->index();
                $table->unsignedBigInteger('receipt_id')->nullable()->index();
                $table->timestamp('claimed_at');
                $table->timestamp('expires_at')->nullable()->index();
                $table->timestamps();
                $table->unique(['tenant_company_id', 'idempotency_key'], 'tcb_tenant_idem_uq');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_command_idempotency');
        // Receipt hardening columns are intentionally retained to avoid destructive downgrade of audit evidence.
    }
};
