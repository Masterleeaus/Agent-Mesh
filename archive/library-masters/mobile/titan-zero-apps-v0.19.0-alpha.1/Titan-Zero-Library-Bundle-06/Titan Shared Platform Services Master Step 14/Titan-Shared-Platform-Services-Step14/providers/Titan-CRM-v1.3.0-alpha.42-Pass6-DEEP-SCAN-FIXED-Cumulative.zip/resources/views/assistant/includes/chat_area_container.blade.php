{{-- Exact MagicAI v11 CRM Assistant view namespace expected by AIChatController. --}}
@include('panel.user.openai_chat.components.chat_area_container')
<template id="crm-assistant-action-card-template">
    <div class="crm-assistant-action-card rounded-xl border border-foreground/10 bg-background p-4 shadow-sm">
        <div class="text-sm font-semibold" data-crm-action-title>CRM action</div>
        <div class="mt-1 text-xs opacity-70" data-crm-action-summary></div>
        <div class="mt-3 flex gap-2" data-crm-action-buttons></div>
    </div>
</template>

@include('crm::assistant.includes.action_card_runtime')
