<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Data/SignalEnvelope.php';
require_once __DIR__ . '/../System/Data/SignalSeverity.php';
require_once __DIR__ . '/../System/Data/SignalActor.php';
require_once __DIR__ . '/../System/Data/SignalContext.php';
require_once __DIR__ . '/../System/Data/SignalConsoleRequest.php';
require_once __DIR__ . '/../System/Data/SignalConsoleRedactionInput.php';

use App\Extensions\TitanSignalEngine\System\Data\SignalConsoleRequest;
use App\Extensions\TitanSignalEngine\System\Data\SignalConsoleRedactionInput;

$assert = static function (bool $condition, string $message): void {
    if (! $condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
};

$request = SignalConsoleRequest::fromArray([
    'scope' => 'tenant',
    'tenant_company_id' => 42,
    'window' => '1h',
    'limit' => 99999,
]);
$assert($request->scope === 'tenant', 'tenant scope preserved');
$assert($request->tenantCompanyId === 42, 'tenant id normalized');
$assert($request->window === '1h', 'window normalized');
$assert($request->limit === 250, 'console list limit bounded');

$system = SignalConsoleRequest::fromArray(['scope' => 'system', 'window' => '24h']);
$assert($system->tenantCompanyId === null, 'system request strips tenant id');

$thrown = false;
try {
    SignalConsoleRequest::fromArray(['scope' => 'tenant']);
} catch (InvalidArgumentException) {
    $thrown = true;
}
$assert($thrown, 'tenant console request requires tenant id');

$redaction = SignalConsoleRedactionInput::fromArray([
    'operation' => 'remove',
    'path' => 'payload.customer.email',
    'reason' => 'Privacy request',
]);
$assert($redaction->operations[0]['op'] === 'remove', 'remove operation normalized');
$assert($redaction->operations[0]['path'] === 'payload.customer.email', 'redaction path normalized');

$replace = SignalConsoleRedactionInput::fromArray([
    'operation' => 'replace',
    'path' => 'payload.customer.name',
    'value' => 'REDACTED',
    'reason' => 'Correction',
]);
$assert($replace->operations[0]['value'] === 'REDACTED', 'replace value retained');

$thrown = false;
try {
    SignalConsoleRedactionInput::fromArray([
        'operation' => 'remove',
        'path' => 'checksum',
        'reason' => 'bad',
    ]);
} catch (InvalidArgumentException) {
    $thrown = true;
}
$assert($thrown, 'console redaction cannot target envelope integrity fields');

fwrite(STDOUT, "Operational console behavior checks: PASS\n");
