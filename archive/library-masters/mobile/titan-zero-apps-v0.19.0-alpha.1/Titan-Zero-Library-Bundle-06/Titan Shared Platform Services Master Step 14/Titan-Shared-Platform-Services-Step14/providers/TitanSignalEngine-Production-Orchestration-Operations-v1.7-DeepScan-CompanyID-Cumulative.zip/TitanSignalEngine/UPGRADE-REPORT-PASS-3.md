# Titan Signal Engine v0.3.0 — Pass 3 Correlation Engine

## Added

- `signal.correlate` runtime capability
- `SignalCorrelationContract`
- `CorrelationService`
- `TraceProfileRegistryContract` + persisted/versioned trace profiles
- `TraceAnalyzer` with causal topological ordering
- required-event completeness rules
- sequence-integrity rules
- terminal-event completeness rules
- missing-parent detection
- causal-cycle detection
- ancestry and descendant traversal
- multi-trace workflow reconstruction by correlation ID
- Rewind-ready correlation receipts
- `titan_signal_causal_edges` read projection
- late/offline parent edge repair without event mutation
- v0.2.1-to-v0.3.0 causal-edge backfill migration
- separate bounded graph query limit (default 5,000 events)
- returned/total event counts and `truncated` / `partial` projection state
- governed-command v1 trace profile seed

## Ordering semantics

1. causation edges
2. `occurred_at`
3. `recorded_at`
4. event ID tie-breaker

This prevents delayed/offline synchronization from corrupting reconstruction merely because database insertion order differs from event causation.

## Scope boundaries

Signal validates a workflow; it does not own workflow state. Trace profiles define what a known workflow should look like. Originating engines remain authoritative for their domain behavior.

Cross-tenant causation/correlation remains unsupported. Graph reads use the same tenant/system authorization boundary as the event query layer.

## Donor extraction

Concepts from the uploaded legacy `titan_signal` donor were selectively rewritten. See `DONOR-EXTRACTION-PASS-3.md`.
