<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_prime_missions')) {
            return;
        }

        $addCausation = !Schema::hasColumn('titan_prime_missions', 'causation_id');
        $addRoot = !Schema::hasColumn('titan_prime_missions', 'root_causation_id');
        if (!$addCausation && !$addRoot) {
            return;
        }

        Schema::table('titan_prime_missions', function (Blueprint $table) use ($addCausation, $addRoot): void {
            if ($addCausation) {
                $table->uuid('causation_id')->nullable()->after('correlation_id')->index();
            }
            if ($addRoot) {
                $table->uuid('root_causation_id')->nullable()->after('causation_id')->index();
            }
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('titan_prime_missions')) {
            return;
        }

        $drop = [];
        foreach (['causation_id', 'root_causation_id'] as $column) {
            if (Schema::hasColumn('titan_prime_missions', $column)) {
                $drop[] = $column;
            }
        }
        if ($drop === []) {
            return;
        }

        Schema::table('titan_prime_missions', static function (Blueprint $table) use ($drop): void {
            $table->dropColumn($drop);
        });
    }
};
