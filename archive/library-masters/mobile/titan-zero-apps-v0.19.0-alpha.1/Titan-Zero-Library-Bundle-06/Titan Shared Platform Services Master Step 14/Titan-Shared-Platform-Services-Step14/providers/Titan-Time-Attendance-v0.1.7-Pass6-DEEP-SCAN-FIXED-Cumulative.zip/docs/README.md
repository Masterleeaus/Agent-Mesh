# Titan Time & Attendance Documentation

## Product and architecture
- `architecture/ARCHITECTURE.md` — domain ownership, data flow, governance, offline and extension boundaries.
- `architecture/CONVERSION-MAP.md` — donor-module convergence and provenance map.
- `workforce/AI-WORKFORCE.md` — extension-owned Manager/Specialist/Agent hierarchy, tools, skills and autonomy rules.

## Integrations and lifecycle
- `integrations/PLATFORM-INTEGRATIONS.md` — CRM, Command Bus, Signal, Risk, Assurance, Autonomy, Rewind and future-engine export boundaries.
- `installer/TITAN-INSTALLER-CONTRACT.md` — Titan Custom Extension Manager 1.6.9 package requirements.
- `installer/LIFECYCLE.md` — enable, disable, upgrade and uninstall behavior.
- `installer/UPGRADE-ROLLBACK-UNINSTALL.md` — retained-data upgrades, rollback limits, reinstall safety and Signal-delivery lifecycle.

## Security
- `security/SECURITY-TENANCY-PRIVACY.md` — tenant boundary, authorization, evidence minimisation, offline replay and AI execution security.

## Release evidence
- `releases/PASS1-BUILD-REPORT.md`
- `releases/PASS2-BUILD-REPORT.md`
- `releases/PASS3-BUILD-REPORT.md`
- `releases/PASS4-BUILD-REPORT.md`
- `releases/PASS5-FINAL-RELEASE-REPORT.md`
