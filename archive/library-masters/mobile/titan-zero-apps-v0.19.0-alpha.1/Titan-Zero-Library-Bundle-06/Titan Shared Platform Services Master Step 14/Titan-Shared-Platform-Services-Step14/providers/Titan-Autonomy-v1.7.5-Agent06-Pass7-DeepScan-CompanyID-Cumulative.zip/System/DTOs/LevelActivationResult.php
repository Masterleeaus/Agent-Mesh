<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\DTOs;

final readonly class LevelActivationResult
{
    public function __construct(
        public bool $approved,
        public CapabilityState $state,
        public array $reasonCodes = [],
    ) {}
}
