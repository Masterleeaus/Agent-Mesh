<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Contracts\AttachmentSecurityScanner;
use App\Extensions\TitanConnect\System\Contracts\MessagingPrivacyHook;
use App\Extensions\TitanConnect\System\Contracts\ReplyAssistant;
use App\Extensions\TitanConnect\System\Contracts\VoiceAgentGateway;
use App\Extensions\TitanConnect\System\Contracts\VoiceSessionGateway;
use Illuminate\Contracts\Container\Container;
use Illuminate\Support\Facades\Event;
use Throwable;

final class IntegrationReadinessService
{
    public function __construct(private readonly Container $app)
    {
    }

    /** @return array<int,array{name:string,status:string,message:string}> */
    public function checks(): array
    {
        $checks = [];
        $checks[] = $this->listenerCheck('workcore-bridge', 'titan-connect.workcore.authorize', 'WorkCore authorization listener');
        $checks[] = $this->listenerPairCheck('chatbot-bridge', ['titan-connect.chatbot.inbound', 'titan-connect.chatbot.handoff'], 'Chatbot inbound + handoff listeners');
        $checks[] = $this->listenerCheck('mobile-push-bridge', 'titan-connect.mobile.push', 'TitanMobileCore push listener');
        $checks[] = $this->bindingCheck('attachment-scanner', AttachmentSecurityScanner::class, ['PendingAttachmentSecurityScanner']);
        $checks[] = $this->bindingCheck('privacy-hook', MessagingPrivacyHook::class, ['NullMessagingPrivacyHook']);
        $checks[] = $this->bindingCheck('reply-assistant', ReplyAssistant::class, []);
        $checks[] = $this->bindingCheck('voice-session', VoiceSessionGateway::class, []);
        $checks[] = $this->bindingCheck('voice-agent', VoiceAgentGateway::class, ['NullVoiceAgentGateway']);
        return $checks;
    }

    /** @return array{name:string,status:string,message:string} */
    private function listenerCheck(string $name, string $event, string $label): array
    {
        $configured = Event::hasListeners($event);
        return [
            'name' => $name,
            'status' => $configured ? 'ok' : 'warning',
            'message' => $configured ? $label.' detected.' : $label.' is not registered; that integration will fail closed or be unavailable.',
        ];
    }

    /** @param array<int,string> $events @return array{name:string,status:string,message:string} */
    private function listenerPairCheck(string $name, array $events, string $label): array
    {
        $missing = array_values(array_filter($events, static fn (string $event): bool => ! Event::hasListeners($event)));
        return [
            'name' => $name,
            'status' => $missing === [] ? 'ok' : 'warning',
            'message' => $missing === [] ? $label.' detected.' : $label.' incomplete; missing '.implode(', ', $missing).'.',
        ];
    }

    /** @param array<int,string> $warningClassFragments @return array{name:string,status:string,message:string} */
    private function bindingCheck(string $name, string $contract, array $warningClassFragments): array
    {
        try {
            $resolved = $this->app->make($contract);
            $class = $resolved::class;
            foreach ($warningClassFragments as $fragment) {
                if (str_contains($class, $fragment)) {
                    return ['name' => $name, 'status' => 'warning', 'message' => 'Binding uses fallback adapter: '.$class.'.'];
                }
            }
            return ['name' => $name, 'status' => 'ok', 'message' => 'Binding resolved: '.$class.'.'];
        } catch (Throwable $e) {
            return ['name' => $name, 'status' => 'error', 'message' => 'Binding failed: '.$e->getMessage()];
        }
    }
}
