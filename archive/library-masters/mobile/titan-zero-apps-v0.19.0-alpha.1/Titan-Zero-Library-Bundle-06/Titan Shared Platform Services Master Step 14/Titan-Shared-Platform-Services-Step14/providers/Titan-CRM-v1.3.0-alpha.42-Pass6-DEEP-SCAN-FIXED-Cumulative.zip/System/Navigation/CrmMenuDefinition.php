<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Navigation;

/**
 * CRM Core navigation only. Extracted domains (Field, Locker, Ledger, Pay)
 * register their own surfaces and must never be re-advertised by CRM Core.
 */
final class CrmMenuDefinition
{
    public static function all(): array
    {
        return [
            ['key'=>'ext_crm_home','label'=>'Overview','route'=>'dashboard.user.crm.index','order'=>3,'icon'=>'tabler-layout-dashboard','children'=>[]],
            ['key'=>'ext_crm_dropdown','label'=>'Customers','route'=>'dashboard.user.crm.companies.index','order'=>4,'icon'=>'tabler-users','children'=>[
                ['key'=>'crm_companies','label'=>'Companies','route'=>'dashboard.user.crm.companies.index','icon'=>'tabler-building'],
                ['key'=>'crm_contacts','label'=>'Contacts','route'=>'dashboard.user.crm.contacts.index','icon'=>'tabler-address-book'],
                ['key'=>'crm_portal','label'=>'Customer Hub','route'=>'dashboard.user.crm.portal.index','icon'=>'tabler-world'],
                ['key'=>'crm_sharing','label'=>'Sharing','route'=>'dashboard.user.crm.sharing.index','icon'=>'tabler-share'],
            ]],
            ['key'=>'ext_crm_sales','label'=>'Sales','route'=>'dashboard.user.crm.leads.index','order'=>5,'icon'=>'tabler-trending-up','children'=>[
                ['key'=>'crm_leads','label'=>'Leads','route'=>'dashboard.user.crm.leads.index','icon'=>'tabler-user-plus'],
                ['key'=>'crm_deals','label'=>'Opportunities','route'=>'dashboard.user.crm.deals.index','icon'=>'tabler-briefcase-2'],
                ['key'=>'crm_pipelines','label'=>'Pipelines','route'=>'dashboard.user.crm.pipelines.index','icon'=>'tabler-columns'],
                ['key'=>'crm_sales_proposals','label'=>'Quotes','route'=>'dashboard.user.sales.proposals.index','icon'=>'tabler-file-description'],
                ['key'=>'crm_sales_estimates','label'=>'Estimates','route'=>'dashboard.user.sales.estimates.index','icon'=>'tabler-calculator'],
            ]],
            ['key'=>'ext_crm_work','label'=>'Projects','route'=>'dashboard.user.crm.projects.index','order'=>6,'icon'=>'tabler-folders','children'=>[
                ['key'=>'crm_projects','label'=>'Projects','route'=>'dashboard.user.crm.projects.index','icon'=>'tabler-folders'],
                ['key'=>'crm_tasks','label'=>'Tasks','route'=>'dashboard.user.crm.tasks.index','icon'=>'tabler-checkbox'],
                ['key'=>'crm_calendar','label'=>'Calendar','route'=>'dashboard.user.crm.calendar.index','icon'=>'tabler-calendar'],
            ]],
            ['key'=>'ext_sales_dropdown','label'=>'Commercial','route'=>'dashboard.user.sales.invoices.index','order'=>7,'icon'=>'tabler-cash','children'=>[
                ['key'=>'crm_sales_invoices','label'=>'Invoices','route'=>'dashboard.user.sales.invoices.index','icon'=>'tabler-file-invoice'],
            ]],
            ['key'=>'ext_crm_insights','label'=>'Insights','route'=>'dashboard.user.crm.reports.index','order'=>8,'icon'=>'tabler-chart-bar','children'=>[
                ['key'=>'crm_reports','label'=>'Reports','route'=>'dashboard.user.crm.reports.index','icon'=>'tabler-chart-bar'],
                ['key'=>'crm_presentations','label'=>'Presentations','route'=>'dashboard.user.crm.presentations.index','icon'=>'tabler-presentation'],
                ['key'=>'crm_duplicates','label'=>'Data Quality','route'=>'dashboard.user.crm.duplicates.index','icon'=>'tabler-checklist'],
            ]],
            ['key'=>'ext_crm_automate','label'=>'Automate','route'=>'dashboard.user.crm.ai.index','order'=>9,'icon'=>'tabler-robot','children'=>[
                ['key'=>'crm_assistant','label'=>'CRM Assistant','route'=>'dashboard.user.crm.ai.index','icon'=>'tabler-sparkles'],
                ['key'=>'crm_automations','label'=>'Automations','route'=>'dashboard.user.crm.automations.index','icon'=>'tabler-bolt'],
                ['key'=>'crm_integrations','label'=>'Integrations','route'=>'dashboard.user.crm.integrations.index','icon'=>'tabler-plug-connected'],
                ['key'=>'crm_chatbot_integration','label'=>'Chatbot Integration','route'=>'dashboard.user.crm.chatbot-integration.index','icon'=>'tabler-message-cog'],
            ]],
            ['key'=>'ext_crm_settings','label'=>'Settings','route'=>'dashboard.user.crm.settings.index','order'=>10,'icon'=>'tabler-settings','children'=>[
                ['key'=>'crm_settings','label'=>'Settings','route'=>'dashboard.user.crm.settings.index','icon'=>'tabler-settings'],
                ['key'=>'crm_metadata','label'=>'Fields and Tags','route'=>'dashboard.user.crm.metadata.index','icon'=>'tabler-category'],
                ['key'=>'crm_import_export','label'=>'Import / Export','route'=>'dashboard.user.crm.import-export.index','icon'=>'tabler-folders'],
                ['key'=>'crm_privacy','label'=>'Privacy and Retention','route'=>'dashboard.user.crm.privacy.index','icon'=>'tabler-shield-lock'],
            ]],
        ];
    }

    public static function legacy(): array
    {
        return [
            ['key'=>'ext_crm_dropdown','label'=>'CRM','route'=>'dashboard.user.crm.index','order'=>4,'icon'=>'tabler-address-book','children'=>[
                ['key'=>'crm_dashboard','label'=>'Dashboard','route'=>'dashboard.user.crm.index','icon'=>'tabler-layout-dashboard'],
                ['key'=>'crm_assistant','label'=>'CRM Assistant','route'=>'dashboard.user.crm.ai.index','icon'=>'tabler-sparkles'],
                ['key'=>'crm_contacts','label'=>'Contacts','route'=>'dashboard.user.crm.contacts.index','icon'=>'tabler-address-book'],
                ['key'=>'crm_companies','label'=>'Companies','route'=>'dashboard.user.crm.companies.index','icon'=>'tabler-building'],
                ['key'=>'crm_leads','label'=>'Leads','route'=>'dashboard.user.crm.leads.index','icon'=>'tabler-user-plus'],
                ['key'=>'crm_deals','label'=>'Deals','route'=>'dashboard.user.crm.deals.index','icon'=>'tabler-briefcase-2'],
                ['key'=>'crm_projects','label'=>'Projects','route'=>'dashboard.user.crm.projects.index','icon'=>'tabler-folders'],
                ['key'=>'crm_tasks','label'=>'Tasks','route'=>'dashboard.user.crm.tasks.index','icon'=>'tabler-checkbox'],
                ['key'=>'crm_calendar','label'=>'Calendar','route'=>'dashboard.user.crm.calendar.index','icon'=>'tabler-calendar'],
                ['key'=>'crm_reports','label'=>'Reports','route'=>'dashboard.user.crm.reports.index','icon'=>'tabler-report-analytics'],
                ['key'=>'crm_automations','label'=>'Automations','route'=>'dashboard.user.crm.automations.index','icon'=>'tabler-bolt'],
                ['key'=>'crm_portal','label'=>'Customer Portal','route'=>'dashboard.user.crm.portal.index','icon'=>'tabler-world'],
                ['key'=>'crm_import_export','label'=>'Import / Export','route'=>'dashboard.user.crm.import-export.index','icon'=>'tabler-folders'],
                ['key'=>'crm_duplicates','label'=>'Duplicates','route'=>'dashboard.user.crm.duplicates.index','icon'=>'tabler-copy-check'],
            ]],
            ['key'=>'ext_sales_dropdown','label'=>'Sales','route'=>'dashboard.user.sales.invoices.index','order'=>5,'icon'=>'tabler-cash','children'=>[
                ['key'=>'crm_sales_invoices','label'=>'Invoices','route'=>'dashboard.user.sales.invoices.index','icon'=>'tabler-file-invoice'],
                ['key'=>'crm_sales_proposals','label'=>'Proposals','route'=>'dashboard.user.sales.proposals.index','icon'=>'tabler-file-description'],
                ['key'=>'crm_sales_estimates','label'=>'Estimates','route'=>'dashboard.user.sales.estimates.index','icon'=>'tabler-calculator'],
            ]],
        ];
    }
}
