<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\TitanAutonomy\System\Contracts\InteractionEngineBridgeContract;

final class UnavailableInteractionEngineBridge implements InteractionEngineBridgeContract
{
    public function prepareJourney(string $capability, ?string $workflowKey, array $context): array
    {
        return [
            'ready' => false,
            'reason_codes' => ['INTERACTION_ENGINE_BRIDGE_UNAVAILABLE'],
            'available' => false,
        ];
    }
}
