<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Gateways\Contracts;

use App\Extensions\TitanPrime\System\Gateways\Data\EngineAvailability;
use App\Extensions\TitanPrime\System\Gateways\Enums\EngineKey;

interface EngineGatewayContract
{
    public function engine(): EngineKey;

    public function availability(): EngineAvailability;
}
