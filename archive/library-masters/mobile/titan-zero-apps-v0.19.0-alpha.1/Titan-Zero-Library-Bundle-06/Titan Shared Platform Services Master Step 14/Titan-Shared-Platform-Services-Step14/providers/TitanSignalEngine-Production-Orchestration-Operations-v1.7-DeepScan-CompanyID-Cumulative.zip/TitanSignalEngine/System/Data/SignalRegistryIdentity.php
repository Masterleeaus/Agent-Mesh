<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalRegistryIdentity
{
    /**
     * @param list<string> $permissions
     * @param list<string> $eventTypePatterns
     * @param list<string> $subscriberKeyPatterns
     */
    public function __construct(
        public string $serviceId,
        public string $ownerSource,
        public array $permissions,
        public array $eventTypePatterns,
        public array $subscriberKeyPatterns,
        public string $attestation,
    ) {
        if (trim($this->serviceId) === '' || trim($this->ownerSource) === '') {
            throw new InvalidArgumentException('Signal registry identity requires service_id and owner_source.');
        }
        if ($this->permissions === [] || $this->attestation === '') {
            throw new InvalidArgumentException('Signal registry identity requires permissions and host attestation.');
        }
        foreach (array_merge($this->eventTypePatterns, $this->subscriberKeyPatterns) as $pattern) {
            if (trim($pattern) === '' || ($pattern !== '*' && str_contains(substr($pattern, 0, -1), '*'))) {
                throw new InvalidArgumentException('Signal registry patterns support exact values, prefix.* or *.');
            }
        }
    }

    public function hasPermission(string $permission): bool
    {
        return in_array($permission, $this->permissions, true);
    }

    public function allowsEventType(string $eventType): bool
    {
        return $this->matches($eventType, $this->eventTypePatterns);
    }

    public function allowsSubscriberKey(string $subscriberKey): bool
    {
        return $this->matches($subscriberKey, $this->subscriberKeyPatterns);
    }

    /** @return array<string,mixed> */
    public function attestationPayload(): array
    {
        return [
            'service_id' => $this->serviceId,
            'owner_source' => $this->ownerSource,
            'permissions' => array_values($this->permissions),
            'event_type_patterns' => array_values($this->eventTypePatterns),
            'subscriber_key_patterns' => array_values($this->subscriberKeyPatterns),
        ];
    }

    private function matches(string $value, array $patterns): bool
    {
        foreach ($patterns as $pattern) {
            if ($pattern === '*' || $pattern === $value) return true;
            if (str_ends_with($pattern, '.*') && str_starts_with($value, substr($pattern, 0, -1))) return true;
        }
        return false;
    }
}
