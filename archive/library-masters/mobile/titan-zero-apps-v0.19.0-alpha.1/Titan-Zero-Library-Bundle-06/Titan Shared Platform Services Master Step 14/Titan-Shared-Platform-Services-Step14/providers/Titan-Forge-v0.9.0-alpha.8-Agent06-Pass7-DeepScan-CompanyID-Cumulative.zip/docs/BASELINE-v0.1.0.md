# Titan Forge v0.1.0 Baseline Freeze

Source artifact: `Titan-Forge-v0.1.0-Scaffold(1).zip`

SHA-256: `a392c71b49080aad8393d79f6e8c4851c9fdf5626ac2b4df86926512b6d4bca0`

Observed source files: 18.

This release preserves the supplied scaffold as the donor baseline. The original legacy MagicAI `extension.json` is retained under `docs/reference/`, and the complete donor file hash inventory is retained in `docs/reference/V0.1.0-FILES.sha256`.

## Pass 1 preservation decision

- Preserve the existing namespace, provider identity, routes, views, migration, service contract and ForgeManager scaffold.
- Preserve the richer sidecar manifest, but align its version/compatibility and remove unimplemented capability claims.
- Do not introduce the Forge build domain, AI generation, sandboxing, Command Bus, Risk, Shield, Governance, Rewind or release execution in this installer-only pass.
- Do not alter the existing database schema in this pass; tenancy/trace schema hardening starts in the next cumulative release.
