<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;

interface SignalPulseProjectorContract
{
    public function project(SignalEvent $event): bool;

    /** @return array{scanned:int,projected:int,skipped:int,failed:int} */
    public function catchUp(int $limit = 1000): array;
}
