# CRM Alpha.17 Context-Aware Global New Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Repurpose MagicAI's existing top-right `+ New` control on CRM operations pages into a context-aware primary creation action plus dropdown, backed exclusively by governed CRM Interaction Engine journeys.

**Architecture:** CRM owns a `CrmGlobalNewMenuRegistry` that resolves primary/secondary journey actions from the current surface, page title, record type and context. The shared CRM page shell renders hidden CSRF-protected journey forms plus a small browser adapter that identifies the host top-right `+ New` control outside the CRM page, changes its primary label/action, and attaches a dropdown of authorised journey actions. The host core is not modified.

**Tech Stack:** PHP 8.2+, Laravel 10, Blade, Bootstrap-compatible host DOM, vanilla JavaScript, Titan Interaction Engine >=10.3.1 <11.0.

## Global Constraints

- Preserve the certified alpha.16 ZIP and work only in the alpha.17 extraction.
- No MagicAI core files in the extension installer.
- All create actions use `dashboard.user.crm.interactions.start` POST routes with CSRF.
- Context/prefill must pass through the existing Interaction Workspace declared-prefill filter and trusted tenant resolver.
- Only journeys whose capability permission is granted to the current authenticated user may be surfaced.
- Primary click performs the most likely action; dropdown exposes related actions.
- Record pages may expose record-contextual create actions without granting new authority.
- Existing in-page New buttons remain as a compatibility fallback in alpha.17, but may be visually de-emphasised once the host adapter successfully attaches.
- No create action may bypass Interaction Engine, CommandBus, autonomy, approval or CRM permission checks.

---

### Task 1: Global New menu registry and permission filter

**Files:**
- Create: `System/Integrations/InteractionEngine/CrmGlobalNewMenuRegistry.php`
- Test: `bin/verify-v130-alpha17-global-new.php`

**Interfaces:**
- Consumes: `CrmInteractionJourneyRegistry`, `CrmCapabilityManifest`, `CrmPermissionService`.
- Produces: `forPage(int $userId, string $surface, string $pageTitle, ?string $recordType, array $context): array{primary:?array,secondary:list<array>}`.

- [ ] Write failing verifier requiring registry, page mappings, permission checks and record-context mappings.
- [ ] Run verifier and confirm RED.
- [ ] Implement registry with Customers, Leads, Work, Money, Crew, Gear, Automate, Settings and record-detail mappings.
- [ ] Re-run verifier and confirm GREEN for registry slice.

### Task 2: Host global New adapter

**Files:**
- Create: `resources/views/components/global-new-adapter.blade.php`
- Modify: `resources/views/components/interaction-page-shell.blade.php`
- Test: `bin/verify-v130-alpha17-global-new.php`

**Interfaces:**
- Consumes: menu array from `CrmGlobalNewMenuRegistry` and existing journey start route.
- Produces: hidden journey forms plus `data-crm-global-new-*` markup and a MutationObserver-based host adapter.

- [ ] Extend verifier to require CSRF POST forms, host-button isolation, primary action, dropdown and no hard-coded MagicAI-core mutation.
- [ ] Run verifier and confirm RED.
- [ ] Render the adapter from the shared shell after page context is resolved.
- [ ] Implement host control discovery by selecting visible `New`/`+ New` controls outside `[data-crm-interaction-page]`, with MutationObserver for late-rendered headers.
- [ ] Make primary host click submit the primary hidden journey form and add a dropdown toggle for secondary journeys.
- [ ] Preserve original host state and restore it on adapter teardown/navigation where applicable.
- [ ] Re-run verifier and confirm GREEN.

### Task 3: Context mappings and fallback behavior

**Files:**
- Modify: `System/Integrations/InteractionEngine/CrmGlobalNewMenuRegistry.php`
- Modify: `resources/views/components/interaction-page-shell.blade.php`
- Test: `bin/verify-v130-alpha17-global-new.php`

**Interfaces:**
- List pages map to primary create actions; detail pages carry existing `context` into related create journeys.

- [ ] Verify exact mappings: Customers→Customer/Contact/Support; Leads→Lead/Opportunity/Quote/Estimate/Pipeline; Work→Job/Service Request/Project/Task/Recurring Work/Location; Money→Invoice/Quote/Estimate/Payment/Bookkeeping; Crew→Appointment/Dispatch/Event/Time; Gear→Inventory/Supplier/PO/Tool/Equipment/Vehicle/Maintenance; Automate→Automation/API Key/Webhook; Settings→Custom Field/Tag.
- [ ] Verify customer record pages include Job/Quote/Invoice/Contact; job record pages include Quote/Invoice/Time/Appointment where supported.
- [ ] Keep in-page action block rendered as fallback; attach `data-crm-local-new-fallback` so later releases can hide it only after confirmed host attachment.
- [ ] Re-run alpha.17 verifier.

### Task 4: Release regression and certification

**Files:**
- Modify: `extension.json`
- Modify: `extension.manifest.json`
- Modify: `bin/verify.php`
- Create: `CHANGELOG_v1.3.0_ALPHA17_CONTEXTUAL_GLOBAL_NEW.md`
- Update integrity inventories.

**Interfaces:**
- Produces flat Titan installer ZIP for `1.3.0-alpha.17`.

- [ ] Add alpha.17 verifier to master verifier.
- [ ] Run alpha.17 gate and inherited master verifier before hash freeze.
- [ ] Bump release metadata to alpha.17.
- [ ] PHP lint every PHP file, parse every JSON file, verify all migrations reversible.
- [ ] Regenerate production integrity map and exact SHA inventory.
- [ ] Run master verifier on frozen source.
- [ ] Build flat ZIP without outer `Crm/` wrapper.
- [ ] Fresh-extract exact ZIP and rerun master verifier, PHP lint, JSON validation, migration reversibility, unsafe path/case collision/junk checks and ZIP compressed-data test.
