# Blueprint v4.1 and Titan Installer 1.7.8 Manifest Compatibility

Titan Rewind v1.0.6 intentionally carries two manifest layers:

1. `extension.json` — the installer-facing Titan Custom Extension Manager contract (`schema: titan-extension-v1`).
2. `extension.manifest.json` — the richer Blueprint v4.1 runtime/governance contract (`schema_version: 2.0`, `runtime_profile: titan-rewind`).

The Blueprint v4.1 package's legacy `extension.json` validator still models the older five-field MagicAI presentation manifest. That validator cannot validate the current Installer 1.7.8 root manifest because the real installer requires Titan fields such as `schema`, `slug`, `folder` and `provider`.

For v1.0.6 release gating:

- Installer-facing `extension.json` is validated against the current Titan `titan-extension-v1` contract.
- `extension.manifest.json` is independently validated against Blueprint v4.1's schema-v2 production schema.
- Blueprint package security scan and architecture scan still run over the complete extension.

This is a validator-contract mismatch in Blueprint v4.1, not permission to weaken either layer. A future Blueprint revision should accept/validate `titan-extension-v1` as its current installer manifest while retaining the schema-v2 sidecar.
