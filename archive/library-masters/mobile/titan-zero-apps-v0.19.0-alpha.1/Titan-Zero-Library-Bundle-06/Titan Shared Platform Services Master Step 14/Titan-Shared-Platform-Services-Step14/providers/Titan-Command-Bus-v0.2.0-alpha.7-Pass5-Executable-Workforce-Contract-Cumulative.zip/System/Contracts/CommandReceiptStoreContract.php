<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Contracts;

use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandReceipt;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;

interface CommandReceiptStoreContract
{
    public function existing(CommandContext $context, CommandRequest $request): ?array;
    public function claim(CommandContext $context, CommandRequest $request, string $operationId, string $requestHash): bool;
    public function complete(CommandReceipt $receipt): void;
    public function health(): array;
}
