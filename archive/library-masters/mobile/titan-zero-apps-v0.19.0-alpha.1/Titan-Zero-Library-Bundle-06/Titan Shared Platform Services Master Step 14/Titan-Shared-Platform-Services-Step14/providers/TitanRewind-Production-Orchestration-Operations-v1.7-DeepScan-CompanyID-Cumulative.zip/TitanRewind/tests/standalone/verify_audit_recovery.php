<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$checks = 0;
$failures = [];

$assert = static function (bool $condition, string $message) use (&$checks, &$failures): void {
    ++$checks;
    if (!$condition) {
        $failures[] = $message;
        fwrite(STDERR, "FAIL: {$message}\n");
    }
};

$required = [
    'System/Audit/RewindEvidenceAssembler.php',
    'System/Recovery/RewindRecoveryPlanner.php',
    'System/Contracts/RewindGovernanceGatewayContract.php',
    'System/Governance/FailClosedRewindGovernanceGateway.php',
    'System/Services/RewindEvidencePackageService.php',
    'System/Services/RewindComplianceExportService.php',
    'System/Services/RewindRecoveryPlanService.php',
    'System/Services/RewindGovernanceService.php',
    'System/Models/RewindEvidencePackage.php',
    'System/Models/RewindRecoveryPlan.php',
    'System/Models/RewindRecoveryStep.php',
    'System/Models/RewindGovernanceReceipt.php',
    'System/Http/Controllers/EvidenceController.php',
    'System/Http/Controllers/RecoveryController.php',
    'database/migrations/2026_08_15_000005_add_titan_rewind_audit_recovery.php',
    'resources/views/evidence.blade.php',
    'resources/views/recovery.blade.php',
];
foreach ($required as $file) {
    $assert(is_file($root . '/' . $file), "required Pass 3 file exists: {$file}");
}

require_once $root . '/System/Support/CanonicalJson.php';
if (is_file($root . '/System/Audit/RewindEvidenceAssembler.php')) require_once $root . '/System/Audit/RewindEvidenceAssembler.php';
if (is_file($root . '/System/Recovery/RewindRecoveryPlanner.php')) require_once $root . '/System/Recovery/RewindRecoveryPlanner.php';
if (is_file($root . '/System/Contracts/RewindGovernanceGatewayContract.php')) require_once $root . '/System/Contracts/RewindGovernanceGatewayContract.php';
if (is_file($root . '/System/Governance/FailClosedRewindGovernanceGateway.php')) require_once $root . '/System/Governance/FailClosedRewindGovernanceGateway.php';

if (class_exists(App\Extensions\TitanRewind\System\Audit\RewindEvidenceAssembler::class)) {
    $canonical = new App\Extensions\TitanRewind\System\Support\CanonicalJson();
    $assembler = new App\Extensions\TitanRewind\System\Audit\RewindEvidenceAssembler($canonical);
    $assembled = $assembler->assemble(
        packageType: 'compliance',
        trace: [
            'tenant_company_id'=>7,
            'trace_id'=>'11111111-1111-4111-8111-111111111111',
            'event_count'=>2,
            'events'=>[['event_id'=>'a'],['event_id'=>'b']],
            'dependencies'=>[['dependency_key'=>'d1']],
            'snapshot_comparisons'=>[['entity_type'=>'Invoice','entity_id'=>'44','diff'=>['count'=>1,'risk'=>'high']]],
            'forensics'=>['status'=>'review','integrity'=>['status'=>'passed']],
            'root_cause'=>['primary'=>['event_id'=>'a']],
            'mutation_allowed'=>false,
        ],
        case: ['case_uuid'=>'22222222-2222-4222-8222-222222222222'],
        snapshots: [['snapshot_uuid'=>'33333333-3333-4333-8333-333333333333']],
        integrityChecks: [['status'=>'passed']],
        driftFindings: [['finding_type'=>'sequence_collision']],
        recoveryPlans: [],
        governanceReceipts: [],
        generatedAt: '2026-08-15T20:00:00+10:00',
        generatedById: 9,
    );
    $assert(($assembled['manifest']['hash_algorithm'] ?? null) === 'sha256', 'evidence manifest uses sha256');
    $assert(($assembled['manifest']['event_count'] ?? null) === 2, 'evidence manifest counts trace events');
    $assert(($assembled['manifest']['snapshot_count'] ?? null) === 1, 'evidence manifest counts snapshots');
    $assert(($assembled['payload']['authoritative_mutation'] ?? true) === false, 'evidence payload declares no authoritative mutation');
    $assert(($assembled['payload']['hidden_chain_of_thought_included'] ?? true) === false, 'evidence payload excludes hidden chain-of-thought');
    $assert(preg_match('/^[a-f0-9]{64}$/', (string) ($assembled['content_hash'] ?? '')) === 1, 'evidence package has canonical sha256 content hash');

    $same = $assembler->assemble('compliance', $assembled['payload']['trace'], $assembled['payload']['case'], $assembled['payload']['snapshots'], $assembled['payload']['integrity_checks'], $assembled['payload']['drift_findings'], [], [], '2026-08-15T20:00:00+10:00', 9);
    $assert($same['content_hash'] === $assembled['content_hash'], 'evidence hash is deterministic for identical content');
}

if (class_exists(App\Extensions\TitanRewind\System\Recovery\RewindRecoveryPlanner::class)) {
    $planner = new App\Extensions\TitanRewind\System\Recovery\RewindRecoveryPlanner();
    $trace = [
        'tenant_company_id'=>7,
        'trace_id'=>'11111111-1111-4111-8111-111111111111',
        'event_count'=>3,
        'forensics'=>['integrity'=>['status'=>'passed'],'status'=>'review','open_drift_findings'=>[]],
        'root_cause'=>['primary'=>['event_id'=>'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','event_type'=>'invoice.failed','source_engine'=>'crm','capability_name'=>'invoice.update','risk_state'=>['overall'=>'high']]],
        'snapshot_comparisons'=>[[
            'entity_type'=>'Invoice','entity_id'=>'44',
            'diff'=>['count'=>2,'risk'=>'high','changes'=>[['path'=>'status','type'=>'modified','before'=>'paid','after'=>'void']]],
        ]],
    ];
    $plan = $planner->build($trace, ['proposed_capability'=>'invoice.compensate','command_input'=>['invoice_id'=>44]]);
    $assert(($plan['requires_governance'] ?? false) === true, 'recovery plans always require governance');
    $assert(($plan['safe_to_auto_apply'] ?? true) === false, 'recovery plan forbids blind auto-apply');
    $assert(($plan['authoritative_mutation'] ?? true) === false, 'Rewind recovery planner never owns authoritative mutation');
    $assert(($plan['submission_ready'] ?? false) === true, 'recovery plan is submission-ready with verified evidence and explicit capability');
    $assert(($plan['execution_owner'] ?? '') === 'titan-command-bus', 'recovery execution owner is Titan Command Bus');
    $assert(count($plan['steps'] ?? []) >= 4, 'recovery plan produces ordered verification/command/outcome/audit steps');
    $assert(($plan['steps'][0]['step_type'] ?? '') === 'verify_evidence_integrity', 'recovery begins by verifying evidence integrity');

    $blocked = $planner->build(array_replace_recursive($trace, ['forensics'=>['integrity'=>['status'=>'failed']]]), ['proposed_capability'=>'invoice.compensate']);
    $assert(($blocked['submission_ready'] ?? true) === false, 'failed integrity blocks governed command submission');
    $assert(in_array('integrity_failed', $blocked['blockers'] ?? [], true), 'failed integrity is explicit recovery blocker');

    $manual = $planner->build($trace, []);
    $assert(($manual['submission_ready'] ?? true) === false, 'missing compensating capability prevents command submission');
    $assert(in_array('compensating_capability_required', $manual['blockers'] ?? [], true), 'missing capability is explicit recovery blocker');

    $invalidCapabilityThrew = false;
    try { $planner->build($trace, ['proposed_capability'=>'../../invoice']); } catch (InvalidArgumentException) { $invalidCapabilityThrew = true; }
    $assert($invalidCapabilityThrew, 'recovery planner rejects malformed compensating capability identifiers');

    $noBasis = $planner->build([
        'tenant_company_id'=>7,'trace_id'=>'11111111-1111-4111-8111-111111111111','event_count'=>1,
        'forensics'=>['integrity'=>['status'=>'passed'],'open_drift_findings'=>[]],
        'root_cause'=>['primary'=>null],'snapshot_comparisons'=>[],
    ], ['proposed_capability'=>'invoice.compensate']);
    $assert(($noBasis['submission_ready'] ?? true) === false, 'recovery without root cause, drift, or snapshot change is blocked');
    $assert(in_array('recovery_basis_not_identified', $noBasis['blockers'] ?? [], true), 'missing recovery basis is an explicit blocker');

    $noChangeSnapshot = $planner->build([
        'tenant_company_id'=>7,'trace_id'=>'11111111-1111-4111-8111-111111111111','event_count'=>1,
        'forensics'=>['integrity'=>['status'=>'passed'],'open_drift_findings'=>[]],
        'root_cause'=>['primary'=>['status'=>'none']],
        'snapshot_comparisons'=>[['entity_type'=>'invoice','entity_id'=>'44','diff'=>['count'=>0,'changes'=>[]]]],
    ], ['proposed_capability'=>'invoice.compensate']);
    $assert(($noChangeSnapshot['submission_ready'] ?? true) === false, 'empty root-cause marker and zero-change snapshot do not establish recovery basis');
    $assert(in_array('recovery_basis_not_identified', $noChangeSnapshot['blockers'] ?? [], true), 'zero-change snapshot retains recovery-basis blocker');
}

if (class_exists(App\Extensions\TitanRewind\System\Governance\FailClosedRewindGovernanceGateway::class)) {
    $gateway = new App\Extensions\TitanRewind\System\Governance\FailClosedRewindGovernanceGateway();
    $assert($gateway->available() === false, 'default governance gateway fails closed');
    $threw = false;
    try { $gateway->requestApproval(['tenant_company_id'=>7]); } catch (LogicException) { $threw = true; }
    $assert($threw, 'default governance gateway refuses approval requests rather than fabricating approval');
}


$providerCode = (string) file_get_contents($root . '/System/TitanRewindServiceProvider.php');
foreach (['RewindEvidencePackageService::class','RewindComplianceExportService::class','RewindRecoveryPlanService::class','RewindGovernanceService::class','RewindEvidenceAssembler::class','RewindRecoveryPlanner::class'] as $needle) {
    $assert(str_contains($providerCode, $needle), "provider wires {$needle}");
}
$routes = (string) file_get_contents($root . '/routes/user.php');
foreach (['evidence.store','evidence.show','evidence.download','recovery.store','recovery.show','recovery.governance.request','recovery.governance.refresh'] as $routeName) {
    $assert(str_contains($routes, "name('{$routeName}')"), "user routes expose {$routeName}");
}
$managerContract = (string) file_get_contents($root . '/System/Contracts/RewindManagerContract.php');
foreach (['generateEvidence','createRecoveryPlan','governanceAvailable','requestRecoveryApproval'] as $method) {
    $assert(str_contains($managerContract, "function {$method}"), "public manager contract exposes {$method}");
}
$migration = (string) file_get_contents($root . '/database/migrations/2026_08_15_000005_add_titan_rewind_audit_recovery.php');
$assert(!preg_match("/->(?:unsignedBigInteger|string|uuid)\('company_id'/", $migration), 'Pass 3 migration does not introduce legacy company_id');
foreach (['titan_rewind_evidence_packages','titan_rewind_recovery_plans','titan_rewind_recovery_steps','titan_rewind_governance_receipts'] as $table) {
    $assert(str_contains($migration, "Schema::create('{$table}'"), "Pass 3 migration creates {$table}");
}
$assert(!is_file($root . '/System/Services/RewindSafeExecutionService.php'), 'donor fake execution service is not transplanted');
$assert(!is_file($root . '/System/Services/RewindEvidenceService.php'), 'duplicate unwired evidence service is absent');
$assert(!is_file($root . '/System/Services/RewindRecoveryService.php'), 'duplicate unwired recovery service is absent');
$governanceService = (string) file_get_contents($root . '/System/Services/RewindGovernanceService.php');
$assert(str_contains($governanceService, 'evidence_content_hash'), 'Governance handoff is bound to an evidence content hash');
$assert(str_contains($governanceService, 'evidence_package_uuid'), 'Governance handoff records the evidence package UUID');
$receiptModel = (string) file_get_contents($root . '/System/Models/RewindGovernanceReceipt.php');
$assert(str_contains($receiptModel, "'evidence_package_uuid'"), 'Governance receipt model persists its exact evidence package UUID');
$assert(str_contains($migration, "uuid('evidence_package_uuid')"), 'Governance receipt schema persists its exact evidence package UUID');
$assert(str_contains($managerContract, 'generateCaseEvidence'), 'public manager contract exposes case-wide evidence generation');
$assert(str_contains($routes, "name('case.evidence.store')"), 'user routes expose case-wide evidence generation');
$assert(str_contains($governanceService, "integrity_state'] ?? null) !== 'passed'") && str_contains($governanceService, '!$this->evidence->verify($evidence)'), 'Governance handoff requires fresh fully verified evidence');
$assert(str_contains($governanceService, 'Governance refresh returned a different request identifier'), 'Governance refresh cannot switch request identity');
$assert(str_contains($governanceService, 'already belongs to another Rewind recovery plan'), 'Governance request IDs cannot be reassigned across recovery plans');
$evidenceServiceCode = (string) file_get_contents($root . '/System/Services/RewindEvidencePackageService.php');
$assert(str_contains($evidenceServiceCode, "manifest['content_hash']"), 'Evidence verification binds manifest hash to persisted content hash');
$gatewayContract = (string) file_get_contents($root . '/System/Contracts/RewindGovernanceGatewayContract.php');
$assert(str_contains($gatewayContract, 'verifyReceipt'), 'Governance gateway contract requires final receipt verification');
$assert(!str_contains($gatewayContract, 'public function approve'), 'Rewind Governance gateway does not expose a self-approval method');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$assert(($manifest['version'] ?? null) === '1.0.6', 'manifest version is 1.0.6');
foreach (['rewind.audit','rewind.evidence','rewind.compliance.export','rewind.recovery.plan','rewind.governance.handoff'] as $capability) {
    $assert(in_array($capability, $manifest['capabilities'] ?? [], true), "manifest advertises implemented capability {$capability}");
}
foreach (['titan_rewind_evidence_packages','titan_rewind_recovery_plans','titan_rewind_recovery_steps','titan_rewind_governance_receipts'] as $table) {
    $assert(in_array($table, $manifest['database']['owned_tables'] ?? [], true), "manifest declares owned table {$table}");
}

$productionPhp = '';
foreach (['System','routes','config','database'] as $directory) {
    $path = $root . '/' . $directory;
    if (!is_dir($path)) continue;
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path));
    foreach ($iterator as $file) {
        if ($file->isFile() && $file->getExtension() === 'php') $productionPhp .= "\n" . file_get_contents($file->getPathname());
    }
}
$forbiddenPlaceholderA = 'Current state validation ' . 'placeholder passed';
$forbiddenPlaceholderB = 'Manual/safe metadata correction step ' . 'marked complete';
$assert(!str_contains($productionPhp, $forbiddenPlaceholderA), 'donor placeholder execution text is absent');
$assert(!str_contains($productionPhp, $forbiddenPlaceholderB), 'donor fake-completion execution text is absent');
$assert(!str_contains($productionPhp, 'Modules\\TitanRewind'), 'no donor Nwidart runtime namespace remains');
$wildcardPattern = '/eloquent\.(created|updated|deleted|restored):\s*' . '\*/i';
$assert(!preg_match($wildcardPattern, $productionPhp), 'no wildcard Eloquent capture added');
$assert(!preg_match('/DB::table\([^\)]*(invoice|customer|job|payment)|\b(invoice|customer|job|payment)\b[^\n]{0,120}->(delete|update|save)\(/is', $productionPhp), 'no obvious authoritative business mutation added');

if ($failures !== []) {
    fwrite(STDERR, sprintf("%d/%d checks failed.\n", count($failures), $checks));
    exit(1);
}

echo "Audit/recovery verifier: {$checks}/{$checks} PASS\n";
