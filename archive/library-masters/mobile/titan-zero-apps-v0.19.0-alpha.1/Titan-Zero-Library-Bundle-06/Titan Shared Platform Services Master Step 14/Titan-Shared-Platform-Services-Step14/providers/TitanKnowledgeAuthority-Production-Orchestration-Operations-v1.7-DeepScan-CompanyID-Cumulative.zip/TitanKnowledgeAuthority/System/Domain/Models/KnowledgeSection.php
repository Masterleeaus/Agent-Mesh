<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

final class KnowledgeSection extends Model
{
    protected $table = 'titan_knowledge_sections';
    protected $guarded = ['id'];
    protected $casts = ['metadata' => 'array'];

    public function document(): BelongsTo
    {
        return $this->belongsTo(KnowledgeDocument::class, 'document_id');
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_section_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_section_id');
    }

    public function claims(): HasMany
    {
        return $this->hasMany(KnowledgeClaim::class, 'section_id');
    }
}
