# Signal Engine host navigation integration

Titan Signal Engine v0.20.0-rc.8.1 treats the operational console as **Super Admin infrastructure**.

## Super Admin

- key: `titan_signal_engine_admin`
- label: **Signal Engine**
- route: `dashboard.admin.titan.signal.engine.index`
- order: `995`
- Website1408 extension marker: `1`
- `is_admin=1` when that column exists

The provider registers `navigation.admin` through the modern contribution registry when available, then idempotently self-heals the shared MagicAI `menus` table and calls `MenuService::regenerate()`.

## User surface

The rc.5 `titan_signal_pulse` sidebar row is removed during rc.6 upgrade and every subsequent host-sync. The governed tenant read-only route remains available for future embedding/direct use but is intentionally not advertised as a normal user-menu destination.

## Repair command

```bash
php artisan titan:signal:host-sync
```

## Blade compatibility

MagicAI 10.91 / Laravel 10 uses `panel.layout.app`; Signal views must not use `<x-layouts.app>`.
