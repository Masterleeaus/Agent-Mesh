<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Enums;

enum PrimeProposalStatus: string
{
    case Draft = 'draft';
    case Ready = 'ready';
    case Accepted = 'accepted';
    case Rejected = 'rejected';
    case Superseded = 'superseded';
}
