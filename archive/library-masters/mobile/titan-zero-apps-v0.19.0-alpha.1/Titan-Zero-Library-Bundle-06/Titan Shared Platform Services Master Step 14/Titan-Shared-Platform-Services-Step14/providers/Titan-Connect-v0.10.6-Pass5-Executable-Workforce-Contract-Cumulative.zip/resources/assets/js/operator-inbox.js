(() => {
  'use strict';
  const root = document.getElementById('titan-connect-operator');
  if (!root) return;

  const state = { threads: [], selected: null, tags: [], canned: [], diagnostics: [] };
  const $ = (selector) => root.querySelector(selector);
  const $$ = (selector) => [...root.querySelectorAll(selector)];
  const csrf = root.dataset.csrf || '';

  const request = async (url, options = {}) => {
    const headers = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest', ...(options.headers || {}) };
    if (options.method && options.method !== 'GET') {
      headers['Content-Type'] = headers['Content-Type'] || 'application/json';
      if (csrf) headers['X-CSRF-TOKEN'] = csrf;
    }
    const response = await fetch(url, { credentials: 'same-origin', ...options, headers });
    if (!response.ok) {
      let message = `Request failed (${response.status})`;
      try { const body = await response.json(); message = body.message || body.error || message; } catch (_) {}
      throw new Error(message);
    }
    if ((response.headers.get('content-type') || '').includes('application/json')) return response.json();
    return response;
  };

  const status = (message = '', error = false) => {
    const el = $('[data-role="status"]');
    el.textContent = message;
    el.classList.toggle('tc-status--error', error);
  };

  const filters = () => {
    const params = new URLSearchParams();
    $$('[data-filter]').forEach((el) => {
      const key = el.dataset.filter;
      const value = el.type === 'checkbox' ? (el.checked ? '1' : '') : el.value.trim();
      if (value) params.set(key, value);
    });
    return params;
  };

  const loadThreads = async () => {
    try {
      const payload = await request(`${root.dataset.indexUrl}?${filters().toString()}`);
      state.threads = payload.data || [];
      renderThreads();
    } catch (e) { status(e.message, true); }
  };

  const renderThreads = () => {
    const list = $('[data-role="thread-list"]');
    list.replaceChildren();
    $('[data-role="thread-count"]').textContent = state.threads.length ? String(state.threads.length) : '';
    $('[data-role="empty"]').hidden = state.threads.length !== 0;
    state.threads.forEach((thread) => {
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'tc-thread';
      if (state.selected?.uuid === thread.uuid) button.classList.add('is-active');
      const title = document.createElement('strong'); title.textContent = thread.display_name || thread.external_contact_ref || thread.provider || 'Conversation';
      const preview = document.createElement('span'); preview.className = 'tc-thread__preview'; preview.textContent = thread.preview || thread.latest_message?.body || '';
      const meta = document.createElement('small'); meta.textContent = `${thread.provider || ''}${thread.unread_count ? ` • ${thread.unread_count} unread` : ''}${thread.priority && thread.priority !== 'normal' ? ` • ${thread.priority}` : ''}`;
      button.append(title, preview, meta); button.addEventListener('click', () => selectThread(thread)); list.append(button);
    });
  };

  const selectThread = async (thread) => {
    state.selected = thread; renderThreads(); setControls(true);
    $('[data-role="conversation-name"]').textContent = thread.display_name || thread.external_contact_ref || 'Conversation';
    $('[data-role="conversation-meta"]').textContent = `${thread.provider || ''} · ${thread.status || 'open'}`;
    $('[data-action="pin"]').textContent = thread.pinned_rank ? 'Unpin' : 'Pin';
    $('[data-action="close"]').textContent = thread.closed_at || thread.status === 'closed' ? 'Reopen' : 'Close';
    renderContact(thread); renderThreadTags(thread.tags || []);
    $('[data-role="edit-name"]').value = thread.display_name || '';
    $('[data-role="edit-assignee"]').value = thread.assigned_user_id || '';
    $('[data-role="edit-priority"]').value = thread.priority || 'normal';
    $('[data-role="edit-color"]').value = /^#[0-9a-f]{6}$/i.test(thread.color || '') ? thread.color : '#64748b';
    await Promise.all([loadMessages(thread.uuid), markRead(thread.uuid)]);
  };

  const setControls = (enabled) => {
    $$('[data-action="voice-call"],[data-action="pin"],[data-action="close"],[data-action="canned"],[data-action="internal-note"],[data-action="tags"],[data-action="send"],[data-action="save-thread"],[data-rewrite],[data-export]').forEach((el) => { el.disabled = !enabled; });
    $('[data-role="composer"]').disabled = !enabled;
  };

  const loadMessages = async (uuid) => {
    const box = $('[data-role="messages"]'); box.textContent = 'Loading…';
    try {
      const payload = await request(`${root.dataset.threadBase}/${uuid}/messages`);
      box.replaceChildren();
      (payload.data || []).forEach((message) => {
        const row = document.createElement('article');
        row.className = `tc-message tc-message--${message.direction || 'inbound'}${message.message_type === 'note' ? ' tc-message--note' : ''}`;
        const body = document.createElement('div'); body.textContent = message.body || '';
        const meta = document.createElement('small'); meta.textContent = `${message.message_type === 'note' ? 'Internal note' : (message.direction || '')} · ${message.created_at || ''}`;
        row.append(body, meta);
        (message.attachments || []).forEach((attachment) => { const a = document.createElement('div'); a.className='tc-attachment'; a.textContent = attachment.original_name || attachment.mime_type || 'Attachment'; row.append(a); });
        box.append(row);
      });
      box.scrollTop = box.scrollHeight;
    } catch (e) { box.textContent = e.message; status(e.message, true); }
  };

  const markRead = async (uuid) => { try { await request(`${root.dataset.readBase}/${uuid}/read`, { method: 'POST', body: '{}' }); loadUnread(); } catch (_) {} };
  const loadUnread = async () => {
    try { const payload = await request(root.dataset.notificationUrl); const badge=$('[data-role="unread-badge"]'); badge.textContent=payload.count || 0; badge.hidden=!payload.count; } catch (_) {}
  };

  const mutateThread = async (path, body) => {
    if (!state.selected) return;
    try {
      const suffix = path ? `/${path}` : '';
      const result = await request(`${root.dataset.threadBase}/${state.selected.uuid}${suffix}`, { method: 'PATCH', body: JSON.stringify(body) });
      Object.assign(state.selected, result); status('Updated.'); await loadThreads();
    } catch (e) { status(e.message, true); }
  };

  const send = async () => {
    if (!state.selected) return; const composer=$('[data-role="composer"]'); const body=composer.value.trim(); if (!body) return;
    const connection = state.selected.connection_uuid || state.selected.connection?.uuid;
    if (!connection) return status('Connection identity is unavailable.', true);
    try {
      status('Sending…');
      await request(`${root.dataset.sendBase}/${connection}/threads/${state.selected.uuid}/messages`, { method:'POST', body: JSON.stringify({ body, idempotency_key: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}` }) });
      composer.value=''; status('Sent.'); await loadMessages(state.selected.uuid); await loadThreads();
    } catch (e) { status(e.message, true); }
  };

  const internalNote = async () => {
    if (!state.selected) return; const note = window.prompt('Internal note (not sent to customer):'); if (!note?.trim()) return;
    try { await request(`${root.dataset.threadBase}/${state.selected.uuid}/notes`, { method:'POST', body: JSON.stringify({ note: note.trim() }) }); status('Internal note added.'); await loadMessages(state.selected.uuid); } catch (e) { status(e.message, true); }
  };

  const rewrite = async (variant) => {
    const composer=$('[data-role="composer"]'); if (!composer.value.trim()) return;
    try { status('Rewriting…'); const payload=await request(root.dataset.rewriteUrl,{method:'POST',body:JSON.stringify({message:composer.value,variant})}); composer.value=payload.result || composer.value; status('Draft updated.'); } catch(e){ status(e.message,true); }
  };

  const openCanned = async () => {
    const dialog=$('[data-dialog="canned"]'); await loadCanned(); renderCanned(); dialog.showModal();
  };
  const loadCanned = async (query='') => { const payload=await request(`${root.dataset.cannedUrl}${query ? `?search=${encodeURIComponent(query)}` : ''}`); state.canned=payload.data || []; };
  const renderCanned = () => {
    const list=$('[data-role="canned-list"]'); list.replaceChildren(); state.canned.forEach((item)=>{ const b=document.createElement('button'); b.type='button'; b.className='tc-dialog-item'; const s=document.createElement('strong');s.textContent=item.title; const c=document.createElement('span');c.textContent=item.content;b.append(s,c);b.onclick=()=>{$('[data-role="composer"]').value=item.content;$('[data-dialog="canned"]').close();};list.append(b); });
  };

  const loadTags = async () => { const payload=await request(root.dataset.tagsUrl); state.tags=payload.data || []; };
  const openTags = async () => { await loadTags(); const current=new Set((state.selected?.tags || []).map(t=>Number(t.id))); const list=$('[data-role="tag-list"]'); list.replaceChildren(); state.tags.forEach((tag)=>{ const label=document.createElement('label'); label.className='tc-dialog-check'; const input=document.createElement('input');input.type='checkbox';input.value=tag.id;input.checked=current.has(Number(tag.id));label.append(input,document.createTextNode(` ${tag.name}`));list.append(label); }); $('[data-dialog="tags"]').showModal(); };
  const saveTags = async () => { if(!state.selected)return; const ids=$$('[data-role="tag-list"] input:checked').map(i=>Number(i.value)); try{ const result=await request(`${root.dataset.threadBase}/${state.selected.uuid}/tags`,{method:'PUT',body:JSON.stringify({tag_ids:ids})}); state.selected.tags=result.tags || []; renderThreadTags(state.selected.tags); $('[data-dialog="tags"]').close(); status('Tags updated.'); }catch(e){status(e.message,true);} };
  const renderThreadTags = (tags) => { const box=$('[data-role="thread-tags"]'); box.replaceChildren(); (tags||[]).forEach((tag)=>{const s=document.createElement('span');s.className='tc-tag';s.textContent=tag.name;box.append(s);}); };

  const renderContact = (thread) => {
    const box=$('[data-role="contact-card"]'); box.replaceChildren(); const contact=thread.contact || {};
    [['Name',contact.display_name || thread.display_name],['Channel',thread.provider],['Reference',thread.external_contact_ref],['Email',contact.email],['Phone',contact.phone],['Country',contact.country],['Assigned user',thread.assigned_user_id],['Priority',thread.priority]].forEach(([label,value])=>{ if(value===null||value===undefined||value==='')return; const row=document.createElement('div'); row.className='tc-contact-row'; const k=document.createElement('small');k.textContent=label; const v=document.createElement('span');v.textContent=String(value); row.append(k,v); box.append(row); });
  };

  const saveThread = async () => {
    if (!state.selected) return;
    const assigneeRaw = $('[data-role="edit-assignee"]').value.trim();
    try {
      await mutateThread('', { display_name: $('[data-role="edit-name"]').value.trim() || null, priority: $('[data-role="edit-priority"]').value, color: $('[data-role="edit-color"]').value });
      const result = await request(`${root.dataset.threadBase}/${state.selected.uuid}/assign`, { method:'PATCH', body:JSON.stringify({assigned_user_id: assigneeRaw ? Number(assigneeRaw) : null}) });
      Object.assign(state.selected, result); renderContact(state.selected); status('Conversation details saved.'); await loadThreads();
    } catch (e) { status(e.message, true); }
  };

  const exportThread = (format) => { if(state.selected) window.location.href=`${root.dataset.threadBase}/${state.selected.uuid}/export/${encodeURIComponent(format)}`; };


  const loadConnectionDiagnostics = async () => {
    const box=$('[data-role="connection-list"]'); if(!box)return;
    try { const payload=await request(root.dataset.diagnosticsUrl); state.diagnostics=payload.data||[]; renderConnectionDiagnostics(); }
    catch(e){ box.innerHTML='<div class="tc-empty">Connection diagnostics unavailable.</div>'; connectionStatus(e.message,true); }
  };

  const renderConnectionDiagnostics = () => {
    const box=$('[data-role="connection-list"]'); if(!box)return; box.replaceChildren();
    if(!state.diagnostics.length){box.innerHTML='<div class="tc-empty">No manageable connections yet.</div>';return;}
    state.diagnostics.forEach(item=>{
      const row=document.createElement('article');row.className='tc-connection-row';
      const info=document.createElement('div'); const title=document.createElement('strong'); title.textContent=item.display_name||item.provider; const meta=document.createElement('small');meta.textContent=`${item.provider} · ${item.status} · credentials ${item.credential_state}`; info.append(title,meta);
      const counters=document.createElement('div');counters.className='tc-connection-row__counters';counters.textContent=`queued ${item.queued_deliveries||0} · failed ${item.failed_deliveries||0} · webhook errors ${item.failed_webhooks||0}`;
      const actions=document.createElement('div');actions.className='tc-inline-actions';
      const health=document.createElement('button');health.type='button';health.className='tc-btn tc-btn--ghost';health.textContent='Check health';health.onclick=async()=>{try{connectionStatus('Checking provider health…');await request(`${root.dataset.sendBase}/${item.connection_uuid}/health`);await loadConnectionDiagnostics();connectionStatus('Provider health checked.');}catch(e){connectionStatus(e.message,true);}};
      const toggle=document.createElement('button');toggle.type='button';toggle.className='tc-btn tc-btn--ghost';toggle.textContent=item.status==='active'?'Pause':'Activate';toggle.onclick=async()=>{try{const next=item.status==='active'?'paused':'active';connectionStatus(`Setting ${item.display_name||item.provider} ${next}…`);await request(`${root.dataset.sendBase}/${item.connection_uuid}`,{method:'PATCH',body:JSON.stringify({status:next})});await loadConnectionDiagnostics();connectionStatus(`Connection ${next}.`);}catch(e){connectionStatus(e.message,true);}};
      actions.append(health,toggle); row.append(info,counters,actions); box.append(row);
    });
  };

  const connectionStatus = (message='', error=false) => { const el=$('[data-role="connection-status"]'); el.textContent=message; el.classList.toggle('tc-status--error',error); };
  const showSetup = (name) => { $$('[data-setup-form]').forEach(f=>{f.hidden=f.dataset.setupForm!==name;}); connectionStatus(''); };
  const createConnection = async (provider, displayName, externalAccountId, settings, credentials) => {
    const created = await request(root.dataset.connectionsUrl, { method:'POST', body:JSON.stringify({provider,display_name:displayName,external_account_id:externalAccountId||null,settings}) });
    const resolvedCredentials = typeof credentials === 'function' ? credentials(created) : credentials;
    if (resolvedCredentials && Object.keys(resolvedCredentials).length) {
      await request(`${root.dataset.sendBase}/${created.uuid}/credentials`, { method:'PUT', body:JSON.stringify({credentials:resolvedCredentials}) });
    }
    return created;
  };

  const connectTelegram = async (form) => {
    const data=new FormData(form); connectionStatus('Connecting Telegram…');
    try { await request(root.dataset.telegramOnboardingUrl,{method:'POST',body:JSON.stringify({bot_token:data.get('bot_token'),display_name:data.get('display_name')||null})}); form.reset(); connectionStatus('Telegram connected.'); await loadThreads(); }
    catch(e){connectionStatus(e.message,true);}
  };

  const connectWhatsApp = async (form) => {
    const d=new FormData(form); const transport=String(d.get('transport')||'meta'); connectionStatus('Connecting WhatsApp…');
    const creds = transport==='twilio'
      ? {transport:'twilio',account_sid:String(d.get('account_sid')||''),auth_token:String(d.get('auth_token')||''),from:String(d.get('from')||''),status_callback:String(d.get('status_callback')||'')}
      : {transport:'meta',phone_number_id:String(d.get('phone_number_id')||''),access_token:String(d.get('access_token')||''),app_secret:String(d.get('app_secret')||''),verify_token:String(d.get('verify_token')||'')};
    try {
      const credentialFactory = transport === 'twilio' ? (created) => ({...creds, status_callback: creds.status_callback || `${window.location.origin}/api/titan-connect/webhooks/whatsapp/${created.uuid}`}) : creds;
      await createConnection('whatsapp',String(d.get('display_name')||'WhatsApp'),String(d.get('external_account_id')||''),{transport},credentialFactory); form.reset(); connectionStatus('WhatsApp connected.');
    }
    catch(e){connectionStatus(e.message,true);}
  };

  const connectVoice = async (form) => {
    const d=new FormData(form); const engine=String(d.get('engine')||'openai_realtime'); connectionStatus('Creating voice connection…');
    const creds = engine==='elevenlabs'
      ? {engine:'elevenlabs',api_key:String(d.get('elevenlabs_api_key')||''),agent_id:String(d.get('agent_id')||'')}
      : {engine:'openai_realtime',openai_api_key:String(d.get('openai_api_key')||''),voice:String(d.get('voice')||'')};
    try { await createConnection('voice',String(d.get('display_name')||'Voice'),null,{engine},creds); form.reset(); connectionStatus('Voice connection created.'); }
    catch(e){connectionStatus(e.message,true);}
  };

  const startVoiceCall = async () => {
    if (!state.selected) return;
    try {
      status('Starting voice call…');
      const connections = await request(root.dataset.connectionsListUrl);
      const voice = (Array.isArray(connections) ? connections : connections.data || []).find(c => c.provider === 'voice' && c.status === 'active');
      if (!voice) throw new Error('Create and activate a voice connection first.');
      const payload = await request(`${root.dataset.sendBase}/${voice.uuid}/voice-calls`, {method:'POST',body:JSON.stringify({external_thread_uuid:state.selected.uuid,direction:'outbound'})});
      status('Voice call started.');
      window.open(`${root.dataset.voiceShowBase}/${payload.call_uuid}`, '_blank', 'noopener');
      await loadMessages(state.selected.uuid); await loadThreads();
    } catch (e) { status(e.message, true); }
  };

  let filterTimer;
  $$('[data-filter]').forEach((el)=>el.addEventListener(el.type==='search'?'input':'change',()=>{clearTimeout(filterTimer);filterTimer=setTimeout(loadThreads,200);}));
  $('[data-action="connections"]').onclick=()=>{ $('[data-dialog="connections"]').showModal(); showSetup(''); loadConnectionDiagnostics(); };
  $('[data-action="refresh-connections"]')?.addEventListener('click',loadConnectionDiagnostics);
  $$('[data-setup]').forEach(b=>b.onclick=()=>showSetup(b.dataset.setup));
  $('[data-setup-form="telegram"]').addEventListener('submit',e=>{e.preventDefault();connectTelegram(e.currentTarget);});
  $('[data-setup-form="whatsapp"]').addEventListener('submit',e=>{e.preventDefault();connectWhatsApp(e.currentTarget);});
  $('[data-setup-form="voice"]').addEventListener('submit',e=>{e.preventDefault();connectVoice(e.currentTarget);});
  $('[data-setup-form="whatsapp"] [name="transport"]').addEventListener('change',e=>{ $$('[data-whatsapp-fields]').forEach(el=>el.hidden=el.dataset.whatsappFields!==e.target.value); });
  $('[data-setup-form="voice"] [name="engine"]').addEventListener('change',e=>{ $$('[data-voice-fields]').forEach(el=>el.hidden=el.dataset.voiceFields!==e.target.value); });
  $('[data-action="refresh"]').onclick=()=>{loadThreads();loadUnread();};
  $('[data-action="send"]').onclick=send;
  $('[data-action="voice-call"]').onclick=startVoiceCall;
  $('[data-role="composer"]').addEventListener('keydown',(e)=>{ if((e.ctrlKey||e.metaKey)&&e.key==='Enter'){e.preventDefault();send();} });
  $('[data-action="internal-note"]').onclick=internalNote;
  $('[data-action="canned"]').onclick=openCanned;
  $('[data-action="tags"]').onclick=openTags;
  $('[data-action="save-thread"]').onclick=saveThread;
  $('[data-action="save-tags"]').onclick=saveTags;
  $('[data-action="pin"]').onclick=()=>mutateThread('pin',{pinned:!Boolean(state.selected?.pinned_rank)});
  $('[data-action="close"]').onclick=()=>mutateThread('close',{closed:!(state.selected?.closed_at || state.selected?.status==='closed')});
  $$('[data-rewrite]').forEach((b)=>b.onclick=()=>rewrite(b.dataset.rewrite));
  $$('[data-export]').forEach((b)=>b.onclick=()=>exportThread(b.dataset.export));
  $('[data-role="canned-search"]').addEventListener('input',async(e)=>{await loadCanned(e.target.value);renderCanned();});

  const applyInitialFilters = () => {
    let initial = {};
    try { initial = JSON.parse(root.dataset.initialFilters || '{}'); } catch (_) { initial = {}; }
    Object.entries(initial).forEach(([key, value]) => {
      const el = $(`[data-filter="${key}"]`);
      if (!el) return;
      if (el.type === 'checkbox') el.checked = Boolean(value); else el.value = String(value ?? '');
    });
  };

  applyInitialFilters(); setControls(false); loadThreads(); loadUnread();
})();
