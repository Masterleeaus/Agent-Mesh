# Titan Connect v0.10.6 — Live MagicAI Dashboard Rendering Repair

## Reported live symptom

After v0.10.5 installed, Titan Connect routes and menu links worked but Unified Inbox and channel settings pages rendered as naked HTML: no MagicAI sidebar, header, titlebar, dashboard spacing, theme styles, or Titan Connect assets.

## Host-grounded root causes

The current Titan Zero/MagicAI host wraps its normal `routes/web.php` routes with `web`, `ViewSharedMiddleware`, and `NewExtensionInstalled`, then applies authenticated dashboard middleware in its panel routes. Titan Connect loads its own route files directly from `TitanConnectServiceProvider`, so it does not automatically inherit that outer host wrapper.

v0.10.5 also relied on namespaced child Blade views using `@extends('panel.layout.app')`. Although that is the correct MagicAI layout name, the live result proved that child inheritance was not a sufficiently deterministic integration boundary for this extension route path.

Finally, the Titan Extension Manager publishes only tags explicitly declared by the extension manifest during its publishing stage. v0.10.5 registered `titan-connect-assets` in the service provider but did not declare the tag in `extension.json`, so installation could complete without immediately materialising `public/vendor/titan-connect` assets.

## v0.10.6 repair

### Root-response dashboard renderer

`System/View/MagicAiDashboardRenderer.php` now renders Titan Connect page content first as a partial, injects it into the Blade `content` section, and returns `panel.layout.app` itself as the root Laravel View.

This makes MagicAI's dashboard shell the actual response root instead of depending on a namespaced child view's `@extends` directive.

The renderer keeps Laravel's view render counter above zero while the content partial renders so Titan Connect `@push('css')` and `@push('script')` stacks survive until the host layout consumes them.

### Host middleware parity

Titan Connect web/dashboard routes explicitly include:

- `web`
- `App\Http\Middleware\ViewSharedMiddleware`
- `App\Domains\Marketplace\Http\Middleware\NewExtensionInstalled`
- `auth`
- `updateUserActivity`
- Titan Connect company binding middleware where applicable

Admin routes additionally retain `admin`.

### Explicit installer publishing

`extension.json` now declares:

```json
"publishes": [
  "titan-connect-assets",
  "titan-connect-config"
]
```

This matches the current Titan Extension Manager's publishing contract.

## Boundaries preserved

This repair changes presentation and host route integration only. It does not change provider credentials, communication ownership, authorization semantics, or the `company_id` tenant boundary.

## Regression coverage

v0.10.6 adds:

- `tests/Contract/dashboard_root_render_pass.php`
- `tests/Contract/dashboard_renderer_runtime.php`

The runtime test executes the root renderer against a controlled Laravel-View-compatible stub and verifies that:

- the returned root view is `panel.layout.app`;
- Titan content is inserted into `content`;
- title is inserted into `title`;
- CSS and script stacks survive content rendering;
- the render counter remains balanced.
