<?php

declare(strict_types=1);

require __DIR__ . '/../System/Data/TraceProfile.php';
require __DIR__ . '/../System/Data/TraceEvaluationPolicy.php';

use App\Extensions\TitanSignalEngine\System\Data\TraceEvaluationPolicy;
use App\Extensions\TitanSignalEngine\System\Data\TraceProfile;

function automaticTraceAssert(bool $condition, string $message): void
{
    if (! $condition) throw new RuntimeException($message);
}

$profile = TraceProfile::fromArray([
    'profile_key' => 'governed.command',
    'version' => 2,
    'required_event_types' => ['command.requested', 'risk.assessed', 'command.executed'],
    'ordering_rules' => [
        ['before' => 'command.requested', 'after' => 'risk.assessed'],
        ['before' => 'risk.assessed', 'after' => 'command.executed'],
    ],
    'terminal_event_types' => ['execution.receipt'],
]);

automaticTraceAssert($profile->matchesEventType('command.requested'), 'Required event type must auto-match the trace profile.');
automaticTraceAssert($profile->matchesEventType('execution.receipt'), 'Terminal event type must auto-match the trace profile.');
automaticTraceAssert($profile->matchesEventType('risk.assessed'), 'Ordering/required event type must auto-match the trace profile.');
automaticTraceAssert(! $profile->matchesEventType('crm.customer.created'), 'Unrelated event type must not auto-assign the profile.');

automaticTraceAssert($profile->matchEventTypes === [
    'command.requested', 'risk.assessed', 'command.executed', 'execution.receipt'
], 'Derived match-event list must be stable and deduplicated.');

$policy = new TraceEvaluationPolicy(60, 300, 5, 900);
automaticTraceAssert($policy->delaySeconds('incomplete', false, false) === 300, 'Open incomplete traces must use the open reevaluation interval.');
automaticTraceAssert($policy->delaySeconds('complete', true, false) === 0, 'Terminal complete traces must close rather than schedule another evaluation.');
automaticTraceAssert($policy->delaySeconds('partial', true, true) === 60, 'Partial history must retry quickly even after a terminal event.');
automaticTraceAssert($policy->delaySeconds('invalid', false, false) === 900, 'Invalid traces must use the bounded invalid retry interval.');
automaticTraceAssert($policy->isTerminalClosed('complete', true, false), 'Complete terminal traces must be eligible for closed assignment state.');
automaticTraceAssert(! $policy->isTerminalClosed('complete', true, true), 'Partial cold history must never close an assignment as complete.');


$providerSource = (string) file_get_contents(__DIR__ . '/../System/TitanSignalEngineServiceProvider.php');
$emitterSource = (string) file_get_contents(__DIR__ . '/../System/Services/SignalEmitter.php');
$anomalySource = (string) file_get_contents(__DIR__ . '/../System/Services/AnomalyDetectionService.php');
automaticTraceAssert(str_contains($providerSource, 'titan:signal-traces:evaluate --limit=250'), 'Provider must schedule automatic trace evaluation.');
automaticTraceAssert(str_contains($providerSource, "->name('signal-trace-evaluation')"), 'Trace evaluation schedule must be named for clustered locking.');
automaticTraceAssert(str_contains($emitterSource, '! $receipt->duplicate') && str_contains($emitterSource, '$this->traceEvaluator->observe($persistedEvent)'), 'Only newly accepted events may trigger automatic trace observation.');
automaticTraceAssert(str_contains($anomalySource, 'required_event_missing') && str_contains($anomalySource, 'trace_evaluation_recovered'), 'Anomaly engine must detect missing required events and resolve repaired trace anomalies.');

fwrite(STDOUT, "automatic-trace-evaluation-behavior: PASS\n");
