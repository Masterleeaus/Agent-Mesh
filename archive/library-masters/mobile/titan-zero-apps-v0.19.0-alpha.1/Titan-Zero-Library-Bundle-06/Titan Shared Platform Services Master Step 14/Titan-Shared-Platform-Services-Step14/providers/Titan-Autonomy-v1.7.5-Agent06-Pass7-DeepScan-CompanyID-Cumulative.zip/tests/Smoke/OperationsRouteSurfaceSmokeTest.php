<?php

declare(strict_types=1);

function ochk(bool $v,string $m):void{if(!$v)throw new RuntimeException($m);} $root=dirname(__DIR__,2);
$route=file_get_contents($root.'/routes/web.php');
ochk(str_contains($route,"Route::get('/operations'"),'operations queue route required');
ochk(str_contains($route,"Route::get('/operations/{correlationId}'"),'operations detail route required');
ochk(str_contains($route,"Route::post('/operations/{correlationId}/recheck'"),'due-only recheck route required');
ochk(str_contains($route,"Route::post('/operations/{correlationId}/review'"),'manager review route required');
$controller=$root.'/System/Http/Controllers/AutonomyOperationsController.php';ochk(is_file($controller),'operations controller required');$text=file_get_contents($controller);
ochk(!preg_match('/input\([\'\"]tenant_company_id/',$text),'operations controller must never accept tenant id from request');
ochk(str_contains($text,'->tenantCompanyId()'),'operations controller must derive tenant from host context');
ochk(str_contains($text,"'titan.autonomy.view'"),'operations reads require autonomy view permission');
ochk(str_contains($text,"'titan.autonomy.manage'"),'operations interventions require manage permission');
foreach(['resources/views/autonomy/operations/index.blade.php','resources/views/autonomy/operations/show.blade.php'] as $view)ochk(is_file($root.'/'.$view),"missing operations view {$view}");
$show=@file_get_contents($root.'/resources/views/autonomy/operations/show.blade.php')?:'';
ochk(!str_contains($show,'approved_unchanged'),'operations UI must not offer positive feedback controls');
ochk(str_contains($show,'materially_corrected')&&str_contains($show,'reversed'),'operations UI should expose only negative outcome corrections');

echo "OK: OperationsRouteSurfaceSmokeTest\n";
