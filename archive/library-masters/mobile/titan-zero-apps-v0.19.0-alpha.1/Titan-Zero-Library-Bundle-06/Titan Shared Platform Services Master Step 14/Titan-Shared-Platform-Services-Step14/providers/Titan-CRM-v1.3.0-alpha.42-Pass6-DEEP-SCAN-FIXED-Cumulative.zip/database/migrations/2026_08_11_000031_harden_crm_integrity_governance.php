<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('crm_domain_signal_outbox')) {
            Schema::table('crm_domain_signal_outbox', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_domain_signal_outbox','event_dedup_key')) $t->char('event_dedup_key',64)->nullable();
                if (! Schema::hasColumn('crm_domain_signal_outbox','attempt_count')) $t->unsignedInteger('attempt_count')->default(0);
                if (! Schema::hasColumn('crm_domain_signal_outbox','available_at')) $t->timestamp('available_at')->nullable()->index();
                if (! Schema::hasColumn('crm_domain_signal_outbox','claimed_at')) $t->timestamp('claimed_at')->nullable()->index();
                if (! Schema::hasColumn('crm_domain_signal_outbox','last_attempt_at')) $t->timestamp('last_attempt_at')->nullable();
                if (! Schema::hasColumn('crm_domain_signal_outbox','last_error')) $t->text('last_error')->nullable();
                if (! Schema::hasColumn('crm_domain_signal_outbox','dead_lettered_at')) $t->timestamp('dead_lettered_at')->nullable()->index();
                if (! Schema::hasColumn('crm_domain_signal_outbox','provider_receipt')) $t->json('provider_receipt')->nullable();
            });
            try {
                Schema::table('crm_domain_signal_outbox', fn (Blueprint $t) => $t->unique(['tenant_company_id','event_dedup_key'],'crm_signal_tenant_dedup_uq'));
            } catch (\Throwable) {}
            try {
                Schema::table('crm_domain_signal_outbox', fn (Blueprint $t) => $t->index(['status','available_at','created_at'],'crm_signal_delivery_idx'));
            } catch (\Throwable) {}
        }

        if (Schema::hasTable('crm_capability_operations')) {
            Schema::table('crm_capability_operations', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_capability_operations','command_duration_ms')) $t->unsignedBigInteger('command_duration_ms')->nullable();
                if (! Schema::hasColumn('crm_capability_operations','affected_count')) $t->unsignedInteger('affected_count')->nullable();
                if (! Schema::hasColumn('crm_capability_operations','receipt_integrity_hash')) $t->char('receipt_integrity_hash',64)->nullable();
                if (! Schema::hasColumn('crm_capability_operations','remediation_suggestion')) $t->text('remediation_suggestion')->nullable();
            });
        }

        if (Schema::hasTable('crm_payments')) {
            Schema::table('crm_payments', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_payments','provider_payload_hash')) $t->char('provider_payload_hash',64)->nullable()->index();
            });
        }

        if (! Schema::hasTable('crm_capability_rate_limits')) {
            Schema::create('crm_capability_rate_limits', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id',26)->unique();
                $t->unsignedBigInteger('tenant_company_id')->index();
                $t->char('bucket_key',64);
                $t->string('actor_key',190)->index();
                $t->string('source',40)->index();
                $t->string('capability',180)->index();
                $t->dateTime('window_started_at')->index();
                $t->unsignedInteger('hit_count')->default(0);
                $t->dateTime('expires_at')->index();
                $t->timestamps();
                $t->unique(['tenant_company_id','bucket_key'],'crm_cap_rate_tenant_bucket_uq');
            });
        }

        if (! Schema::hasTable('crm_import_impact_reports')) {
            Schema::create('crm_import_impact_reports', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id',26)->unique();
                $t->unsignedBigInteger('tenant_company_id')->index();
                $t->char('batch_public_id',26)->index();
                $t->string('source_type',60)->index();
                $t->string('status',30)->default('ready')->index();
                $t->json('impact_report');
                $t->json('relationship_errors')->nullable();
                $t->dateTime('expires_at')->index();
                $t->timestamps();
                $t->unique(['tenant_company_id','batch_public_id'],'crm_import_report_tenant_batch_uq');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('crm_import_impact_reports');
        Schema::dropIfExists('crm_capability_rate_limits');

        if (Schema::hasTable('crm_payments') && Schema::hasColumn('crm_payments','provider_payload_hash')) {
            Schema::table('crm_payments', fn (Blueprint $t) => $t->dropColumn('provider_payload_hash'));
        }

        if (Schema::hasTable('crm_capability_operations')) {
            foreach (['remediation_suggestion','receipt_integrity_hash','affected_count','command_duration_ms'] as $column) {
                if (Schema::hasColumn('crm_capability_operations',$column)) Schema::table('crm_capability_operations', fn (Blueprint $t) => $t->dropColumn($column));
            }
        }

        if (Schema::hasTable('crm_domain_signal_outbox')) {
            try { Schema::table('crm_domain_signal_outbox', fn (Blueprint $t) => $t->dropUnique('crm_signal_tenant_dedup_uq')); } catch (\Throwable) {}
            try { Schema::table('crm_domain_signal_outbox', fn (Blueprint $t) => $t->dropIndex('crm_signal_delivery_idx')); } catch (\Throwable) {}
            foreach (['provider_receipt','dead_lettered_at','last_error','last_attempt_at','claimed_at','available_at','attempt_count','event_dedup_key'] as $column) {
                if (Schema::hasColumn('crm_domain_signal_outbox',$column)) Schema::table('crm_domain_signal_outbox', fn (Blueprint $t) => $t->dropColumn($column));
            }
        }
    }
};
