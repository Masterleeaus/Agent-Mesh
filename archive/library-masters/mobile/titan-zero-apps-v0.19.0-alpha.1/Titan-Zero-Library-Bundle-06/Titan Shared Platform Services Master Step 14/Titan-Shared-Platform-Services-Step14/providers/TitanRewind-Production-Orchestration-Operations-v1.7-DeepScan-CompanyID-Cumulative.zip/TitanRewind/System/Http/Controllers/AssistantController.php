<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Http\Controllers;

use App\Extensions\TitanRewind\System\AI\RewindToolCatalogue;
use App\Extensions\TitanRewind\System\Services\RewindAssistantService;
use App\Extensions\TitanRewind\System\Services\RewindTenantContextResolver;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

final class AssistantController
{
    public function __construct(
        private RewindTenantContextResolver $tenants,
        private RewindAssistantService $assistant,
        private RewindToolCatalogue $tools,
    ) {}

    public function index(Request $request): View
    {
        $tenant = $this->tenants->forUser($request->user());
        abort_if($tenant === null, 403, 'Titan Rewind could not resolve an explicit tenant company for this account.');
        return view('titan-rewind::assistant', ['response'=>null,'tools'=>$this->tools->all()]);
    }

    public function ask(Request $request): View
    {
        $tenant = $this->tenants->forUser($request->user());
        abort_if($tenant === null, 403, 'Titan Rewind could not resolve an explicit tenant company for this account.');
        $message = trim((string)$request->input('message',''));
        abort_if($message === '', 422, 'A Rewind assistant question is required.');
        $context = [
            'trace_id'=>trim((string)$request->input('trace_id','')) ?: null,
            'case_uuid'=>trim((string)$request->input('case_uuid','')) ?: null,
        ];
        return view('titan-rewind::assistant', ['response'=>$this->assistant->route($message, array_filter($context)),'tools'=>$this->tools->all()]);
    }
}
