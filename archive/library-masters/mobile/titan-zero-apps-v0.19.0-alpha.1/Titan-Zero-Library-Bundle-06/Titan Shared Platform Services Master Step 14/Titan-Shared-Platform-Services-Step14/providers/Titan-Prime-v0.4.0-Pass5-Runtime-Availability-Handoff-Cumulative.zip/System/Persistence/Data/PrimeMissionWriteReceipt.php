<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Persistence\Data;

use InvalidArgumentException;

final readonly class PrimeMissionWriteReceipt
{
    public function __construct(
        public int $tenantCompanyId,
        public string $operationId,
        public string $missionId,
        public string $operationType,
        public int $version,
        public string $status,
        public string $payloadHash,
        public bool $replayed = false,
    ) {
        if ($tenantCompanyId < 1 || $version < 1) {
            throw new InvalidArgumentException('Receipt tenant and version must be positive.');
        }
        foreach ([$operationId, $missionId, $operationType, $status, $payloadHash] as $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException('Receipt identifiers and status must not be empty.');
            }
        }
    }

    public function asReplay(): self
    {
        return new self(
            tenantCompanyId: $this->tenantCompanyId,
            operationId: $this->operationId,
            missionId: $this->missionId,
            operationType: $this->operationType,
            version: $this->version,
            status: $this->status,
            payloadHash: $this->payloadHash,
            replayed: true,
        );
    }

    /** @return array<string,int|string|bool> */
    public function toArray(): array
    {
        return [
            'tenant_company_id' => $this->tenantCompanyId,
            'operation_id' => $this->operationId,
            'mission_id' => $this->missionId,
            'operation_type' => $this->operationType,
            'version' => $this->version,
            'status' => $this->status,
            'payload_hash' => $this->payloadHash,
            'replayed' => $this->replayed,
        ];
    }

    /** @param array<string,mixed> $data */
    public static function fromArray(array $data): self
    {
        return new self(
            tenantCompanyId: (int) $data['tenant_company_id'],
            operationId: (string) $data['operation_id'],
            missionId: (string) $data['mission_id'],
            operationType: (string) $data['operation_type'],
            version: (int) $data['version'],
            status: (string) $data['status'],
            payloadHash: (string) $data['payload_hash'],
            replayed: (bool) ($data['replayed'] ?? false),
        );
    }
}
