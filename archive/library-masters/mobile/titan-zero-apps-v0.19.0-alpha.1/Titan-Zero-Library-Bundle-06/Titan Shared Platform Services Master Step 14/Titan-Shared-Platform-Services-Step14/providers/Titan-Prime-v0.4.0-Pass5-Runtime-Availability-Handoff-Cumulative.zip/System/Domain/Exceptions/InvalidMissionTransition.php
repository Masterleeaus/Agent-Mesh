<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\Exceptions;

use DomainException;

final class InvalidMissionTransition extends DomainException
{
    public static function between(string $from, string $to): self
    {
        return new self(sprintf('Titan Prime mission cannot transition from [%s] to [%s].', $from, $to));
    }
}
