# Titan Autonomy Operations / Exception Centre Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a tenant-safe operations/exception queue for autonomous execution receipts without creating any authority or positive-learning bypass.

**Architecture:** Build read projections and a deterministic operations classifier over v1.5 canonical receipts. Add an append-only review store and a due-only single-receipt reconciliation path. UI actions are limited to review acknowledgement, mature recheck, and the existing negative-only feedback path.

**Tech Stack:** PHP 8.3, Laravel 10, Blade, Titan Autonomy v1.5 contracts, Titan Interaction/CRM/Assurance live bridges.

## Global Constraints
- Canonical tenant boundary is `tenant_company_id` from trusted server context.
- No client may mint positive learning evidence or promote autonomy.
- Recheck must enforce the existing maturation window and all normal reconciliation checks.
- Critical actions never auto-mature positive evidence.
- Existing negative-feedback allowlist remains unchanged.
- Existing routes and control-plane permissions remain compatible.

---

### Task 1: Operations classifier and query projection
**Files:** Create `System/Services/OperationsStatusClassifier.php`; modify `System/Contracts/AutonomyQueryContract.php` and `System/Infrastructure/DatabaseAutonomyQuery.php`; add smoke test.
**Produces:** deterministic status/priority/actions and tenant-scoped receipt queries.
- [ ] Write failing status/query smoke test.
- [ ] Verify RED.
- [ ] Implement minimal classifier/query methods.
- [ ] Verify GREEN.

### Task 2: Manager review metadata
**Files:** Add migration `database/migrations/2026_08_11_000400_add_titan_autonomy_operations_reviews.php`; create contract/store/service; add smoke test.
**Produces:** append-only review/acknowledgement records that do not touch learning/trust state.
- [ ] Write failing review isolation test.
- [ ] Verify RED.
- [ ] Implement table/store/service.
- [ ] Verify GREEN.

### Task 3: Due-only single receipt reconciliation
**Files:** Extend `ExecutionReceiptStoreContract`, `ExecutionReconciliationContract`, `DatabaseExecutionReceiptStore`, `ExecutionReconciliationService`; create `OperationsRecheckService`; add smoke test.
**Produces:** `finalizeReceiptDue(tenant, correlation)` with strict tenant + maturation enforcement.
- [ ] Write failing early-recheck/tenant-isolation tests.
- [ ] Verify RED.
- [ ] Implement due-only path reusing canonical reconciliation logic.
- [ ] Verify GREEN.

### Task 4: Operations service, controller, routes and UI
**Files:** Create `AutonomyOperationsService`, `AutonomyOperationsController`, queue/detail Blade views; modify routes/navigation/layout/index.
**Produces:** operational queue/detail with safe actions only.
- [ ] Write failing route/surface smoke test.
- [ ] Verify RED.
- [ ] Implement server-side filters, summary, queue/detail and forms.
- [ ] Verify GREEN.

### Task 5: Audit, release metadata and regression verification
**Files:** service provider bindings; changelog/readme/config/manifest/integrity as required.
**Produces:** v1.6 installer-ready package.
- [ ] Run all v1.5 regression tests plus new v1.6 tests.
- [ ] Run PHP/JSON/secret/filesystem/manifest validation.
- [ ] Regenerate package integrity data.
- [ ] Build final ZIP, re-extract, rerun packaged-byte tests and integrity verification.
