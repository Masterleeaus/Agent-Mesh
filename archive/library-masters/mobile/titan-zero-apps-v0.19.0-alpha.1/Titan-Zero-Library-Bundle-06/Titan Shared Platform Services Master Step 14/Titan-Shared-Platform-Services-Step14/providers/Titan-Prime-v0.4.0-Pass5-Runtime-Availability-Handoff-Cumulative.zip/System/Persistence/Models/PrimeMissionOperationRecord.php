<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Persistence\Models;

use Illuminate\Database\Eloquent\Model;
use App\Extensions\TitanPrime\System\Persistence\Models\Concerns\HasCanonicalCompanyIdCompatibility;

final class PrimeMissionOperationRecord extends Model
{
    use HasCanonicalCompanyIdCompatibility;

    protected $table = 'titan_prime_mission_operations';

    protected $guarded = [];

    protected $casts = [
        'company_id' => 'integer',
        'tenant_company_id' => 'integer',
        'receipt_json' => 'array',
        'expires_at' => 'datetime',
    ];
}
