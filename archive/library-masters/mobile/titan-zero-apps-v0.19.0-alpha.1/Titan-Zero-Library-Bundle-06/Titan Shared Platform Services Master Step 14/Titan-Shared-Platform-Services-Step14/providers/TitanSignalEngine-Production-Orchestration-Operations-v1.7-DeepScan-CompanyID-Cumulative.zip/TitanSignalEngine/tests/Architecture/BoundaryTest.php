<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use SplFileInfo;

final class BoundaryTest extends TestCase
{
    public function test_engine_does_not_import_other_titan_extension_internals(): void
    {
        $root = dirname(__DIR__, 2) . '/System';
        $violations = [];
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));

        /** @var SplFileInfo $file */
        foreach ($files as $file) {
            if (! $file->isFile() || $file->getExtension() !== 'php') {
                continue;
            }
            $contents = (string) file_get_contents($file->getPathname());
            if (preg_match('/App\\\\Extensions\\\\(?!TitanSignalEngine\\\\)[A-Za-z0-9_]+\\\\/', $contents)) {
                $violations[] = $file->getPathname();
            }
        }

        self::assertSame([], $violations, 'Signal Engine must depend on contracts/events, not another Titan extension internal namespace.');
    }

    public function test_signal_event_model_blocks_mutation_paths(): void
    {
        $model = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Models/SignalEvent.php');

        self::assertStringContainsString('static::updating', $model);
        self::assertStringContainsString('static::deleting', $model);
        self::assertStringContainsString('ImmutableSignalEventException', $model);
    }

    public function test_signal_event_model_contains_no_hidden_reasoning_fields(): void
    {
        $model = strtolower((string) file_get_contents(dirname(__DIR__, 2) . '/System/Models/SignalEvent.php'));
        foreach (['chain_of_thought', 'hidden_reasoning', 'reasoning_trace', 'scratchpad', 'internal_monologue'] as $prohibited) {
            self::assertStringNotContainsString($prohibited, $model);
        }
    }

    public function test_correlation_engine_does_not_reintroduce_legacy_donor_runtime_tables_or_namespaces(): void
    {
        $root = dirname(__DIR__, 2) . '/System';
        $violations = [];
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));

        /** @var SplFileInfo $file */
        foreach ($files as $file) {
            if (! $file->isFile() || $file->getExtension() !== 'php') {
                continue;
            }
            $contents = (string) file_get_contents($file->getPathname());
            foreach (['App\\Titan\\Signals', 'tz_signals', 'tz_processes', 'tz_process_states', 'tz_signal_queue', 'tz_approval_queue'] as $legacy) {
                if (str_contains($contents, $legacy)) {
                    $violations[] = $file->getPathname() . ':' . $legacy;
                }
            }
        }

        self::assertSame([], $violations, 'Donor concepts may be rewritten, but legacy donor runtime coupling must not be reintroduced.');
    }

    public function test_signal_provider_registers_event_type_registry_and_security_guards(): void
    {
        $provider = (string) file_get_contents(dirname(__DIR__, 2) . '/System/TitanSignalEngineServiceProvider.php');
        self::assertStringContainsString('EventTypeRegistryContract::class', $provider);
        self::assertStringContainsString('SignalEmitterAuthority::class', $provider);
        self::assertStringContainsString('SignalEmitterAuthorityContract::class', $provider);
        self::assertStringContainsString('SignalRegistryAuthorityContract::class', $provider);
        self::assertStringContainsString('RegistryOwnershipPolicy::class', $provider);
        self::assertStringContainsString('SignalContextValidator::class', $provider);
        self::assertStringContainsString('SignalPayloadGuard::class', $provider);
        self::assertStringContainsString('SignalCorrelationContract::class', $provider);
        self::assertStringContainsString('TraceProfileRegistryContract::class', $provider);
        self::assertStringContainsString('SignalSubscriptionRegistryContract::class', $provider);
        self::assertStringContainsString('SignalDeliverySchedulerContract::class', $provider);
        self::assertStringContainsString('SignalDeliveryDispatcherContract::class', $provider);
        self::assertStringContainsString('SignalDeliveryLeaseManagerContract::class', $provider);
        self::assertStringContainsString('SignalPulseProjectorContract::class', $provider);
        self::assertStringContainsString('SignalPulseContract::class', $provider);
        self::assertStringContainsString('SignalAnomalyContract::class', $provider);
        self::assertStringContainsString('SignalLifecycleContract::class', $provider);
        self::assertStringContainsString('SignalArchiveStoreContract::class', $provider);
        self::assertStringContainsString('SignalSourceRateLimiterContract::class', $provider);
    }


    public function test_public_signal_contracts_require_trusted_context(): void
    {
        foreach ([
            'SignalEmitterContract.php',
            'SignalQueryContract.php',
            'SignalCorrelationContract.php',
            'SignalPulseContract.php',
            'SignalAnomalyContract.php',
            'SignalLifecycleContract.php',
            'SignalManagerContract.php',
        ] as $contractFile) {
            $contract = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Contracts/' . $contractFile);
            self::assertStringNotContainsString('?SignalContext', $contract, $contractFile . ' must not expose nullable SignalContext authorization.');
            self::assertStringNotContainsString('$context = null', $contract, $contractFile . ' must not expose contextless authorization defaults.');
        }
    }

    public function test_new_signal_events_carry_trusted_emitter_identity(): void
    {
        $validator = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/SignalContextValidator.php');
        $envelope = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Data/SignalEnvelope.php');
        self::assertStringContainsString("\$input['emitter_id'] = \$context->emitter->serviceId", $validator);
        self::assertStringContainsString("'emitter_id' => \$this->emitterId", $envelope);
        self::assertStringContainsString('SignalEmitterAuthority', $validator);
    }

    public function test_anomaly_engine_reads_projections_not_raw_signal_history(): void
    {
        $service = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/AnomalyDetectionService.php');
        self::assertStringNotContainsString('SignalEvent::', $service);
        self::assertStringNotContainsString('titan_signal_events', $service);
        self::assertStringContainsString('SignalPulseRollup::', $service);
        self::assertStringContainsString('SignalPulseTraceMetric::', $service);
    }

    public function test_pulse_query_does_not_scan_raw_signal_event_table(): void
    {
        $service = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/PulseQueryService.php');
        self::assertStringNotContainsString('SignalEvent::', $service);
        self::assertStringNotContainsString('titan_signal_events', $service);
    }


    public function test_only_governed_lifecycle_service_physically_prunes_signal_events(): void
    {
        $root = dirname(__DIR__, 2) . '/System';
        $violations = [];
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));
        /** @var SplFileInfo $file */
        foreach ($files as $file) {
            if (! $file->isFile() || $file->getExtension() !== 'php') continue;
            $contents = (string) file_get_contents($file->getPathname());
            if (str_contains($contents, "DB::table('titan_signal_events')") && str_contains($contents, '->delete()') && ! str_ends_with($file->getPathname(), 'SignalLifecycleService.php')) {
                $violations[] = $file->getPathname();
            }
        }
        self::assertSame([], $violations, 'Physical event pruning must be isolated to the governed lifecycle service.');
    }

    public function test_archive_is_verified_before_event_pruning(): void
    {
        $service = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/SignalLifecycleService.php');
        $verify = strpos($service, '$this->archiveStore->verify');
        $delete = strpos($service, "DB::table('titan_signal_events')->whereIn('event_id', $eventIds)->delete()");
        self::assertNotFalse($verify);
        self::assertNotFalse($delete);
        self::assertLessThan($delete, $verify);
    }

    public function test_pruning_is_bound_to_exact_preview_manifest_and_execution_lease(): void
    {
        $service = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/SignalLifecycleService.php');
        foreach (['SignalPrunePreviewToken::previewIdFrom', 'candidate_hash', 'lockForUpdate()', 'prune_claim_token', 'execution_token', 'archiveStream(', 'verified_unpruned'] as $required) {
            self::assertStringContainsString($required, $service);
        }
        self::assertStringContainsString('$deleted !== count($eventIds)', $service);
        $contract = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Contracts/SignalLifecycleContract.php');
        self::assertStringNotContainsString('bool $confirmed', $contract);
    }

    public function test_archive_io_is_bounded_memory_streaming(): void
    {
        $store = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/LocalSignalArchiveStore.php');
        self::assertStringContainsString('archiveStream(', $store);
        self::assertStringContainsString('readStream($locator)', $store);
        self::assertStringContainsString('tempnam(', $store);
        self::assertStringNotContainsString('gzencode(', $store);
        self::assertStringNotContainsString('->get($locator)', $store);
    }

    public function test_privacy_overlays_do_not_update_immutable_event_rows(): void
    {
        $service = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/SignalLifecycleService.php');
        self::assertStringContainsString('SignalEventOverlay::query()->create', $service);
        self::assertStringNotContainsString("DB::table('titan_signal_events')->where('event_id', $eventId)->update", $service);
    }


    public function test_delivery_dispatcher_uses_atomic_lease_manager_for_terminal_transitions(): void
    {
        $dispatcher = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/SignalDeliveryDispatcher.php');
        self::assertStringContainsString('$this->leases->claim(', $dispatcher);
        self::assertStringContainsString('$this->leases->markDelivered(', $dispatcher);
        self::assertStringContainsString('$this->leases->markRetry(', $dispatcher);
        self::assertStringContainsString('$this->leases->markDeadLetter(', $dispatcher);
        self::assertStringNotContainsString("\$delivery->status = 'processing'", $dispatcher);
        self::assertStringNotContainsString("\$delivery->status = 'delivered'", $dispatcher);
        self::assertStringNotContainsString("\$delivery->status = 'dead_letter'", $dispatcher);
    }

    public function test_delivery_lease_claim_uses_compare_and_set_ownership_fields(): void
    {
        $manager = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/SignalDeliveryLeaseManager.php');
        foreach (['lease_token', 'lease_owner', 'lease_expires_at', 'claim_version', "DB::raw('claim_version + 1')"] as $required) {
            self::assertStringContainsString($required, $manager);
        }
        self::assertStringContainsString("->where('lease_token', \$lease->token)", $manager);
        self::assertStringContainsString("->where('claim_version', \$lease->claimVersion)", $manager);
    }

}
