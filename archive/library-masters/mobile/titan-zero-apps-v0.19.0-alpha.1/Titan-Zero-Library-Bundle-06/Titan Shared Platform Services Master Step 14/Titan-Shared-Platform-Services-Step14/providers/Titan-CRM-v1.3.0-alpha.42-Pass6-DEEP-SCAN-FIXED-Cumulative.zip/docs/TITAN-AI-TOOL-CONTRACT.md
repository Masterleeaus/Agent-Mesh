# TitanAI CRM Tool Contract

## Status
**IMPLEMENTED provider; PARTIAL runtime auto-discovery with the exact TitanAI v1.2 reference.**

`CrmTitanAIToolProvider` exposes governed definitions only. Reads include customer/service/work-order/appointment/dispatch/quote/invoice operations. Writes include customer creation, service-request creation, work-order creation/update, appointment creation, quote preparation and support creation.

Writes flow through trusted `CrmCompanyContext` → authorization → fixed capability dispatch → validation/domain service → idempotency receipt where applicable → audit. Raw Eloquent/database access is not exposed to TitanAI.

The CRM registrar tags the provider and can merge definitions into the TitanAI capability configuration. The exact TitanAI v1.2 source supplied for certification does not define a generic third-party tool-provider discovery/execution interface, so automatic end-to-end discovery cannot be truthfully marked complete until TitanAI consumes that tag/hook (or a later runtime contract is supplied).
