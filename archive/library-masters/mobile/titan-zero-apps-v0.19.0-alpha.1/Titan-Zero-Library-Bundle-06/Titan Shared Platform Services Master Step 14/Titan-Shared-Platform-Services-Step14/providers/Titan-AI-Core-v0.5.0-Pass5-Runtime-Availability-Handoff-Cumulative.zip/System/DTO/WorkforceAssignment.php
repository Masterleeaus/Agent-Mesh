<?php
declare(strict_types=1);
namespace App\Extensions\TitanAICore\System\DTO;
final readonly class WorkforceAssignment { public function __construct(public string $role, public string $skill, public int $minimumAuthority = 0) {} public function toArray(): array { return ['role'=>$this->role,'skill'=>$this->skill,'minimum_authority'=>$this->minimumAuthority]; } }
