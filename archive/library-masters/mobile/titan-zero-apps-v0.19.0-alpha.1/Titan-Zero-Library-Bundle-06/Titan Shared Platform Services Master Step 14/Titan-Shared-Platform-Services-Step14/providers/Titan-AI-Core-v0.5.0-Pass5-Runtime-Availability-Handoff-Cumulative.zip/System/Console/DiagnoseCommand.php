<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Console;

use App\Extensions\TitanAICore\System\Contracts\HealthCheckContract;
use Illuminate\Console\Command;

final class DiagnoseCommand extends Command
{
    protected $signature = 'titan-ai-core:diagnose {--json : Output JSON only}';
    protected $description = 'Diagnose Titan AI Core host wiring, routes, views, bindings and database readiness.';

    public function handle(HealthCheckContract $health): int
    {
        $result = $health->check();

        if ((bool) $this->option('json')) {
            $this->line((string) json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        } else {
            $this->info('Titan AI Core ' . ($result['version'] ?? 'unknown') . ' — ' . ($result['status'] ?? 'unknown'));
            foreach (($result['checks'] ?? []) as $name => $ok) {
                $this->line(sprintf('%s %s', $ok ? '[OK]' : '[--]', $name));
            }
        }

        return ($result['status'] ?? null) === 'HEALTHY' ? self::SUCCESS : self::FAILURE;
    }
}
