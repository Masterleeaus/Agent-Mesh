<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$migrationDir = $root . '/database/migrations';
$failures = [];
$checked = 0;
foreach (glob($migrationDir . '/*.php') ?: [] as $file) {
    $checked++;
    $source = (string) file_get_contents($file);
    if (preg_match('/->timestamp\s*\(\s*[\'\"][^\'\"]+[\'\"]\s*,\s*[1-9][0-9]*\s*\)/', $source, $m)) {
        $failures[] = basename($file) . ': precision-qualified TIMESTAMP remains (' . $m[0] . ')';
    }
    if (preg_match('/->timestampTz\s*\(\s*[\'\"][^\'\"]+[\'\"]\s*,\s*[1-9][0-9]*\s*\)/', $source, $m)) {
        $failures[] = basename($file) . ': precision-qualified TIMESTAMPTZ remains (' . $m[0] . ')';
    }
}
if ($checked === 0) {
    $failures[] = 'No migrations found.';
}
if ($failures !== []) {
    fwrite(STDERR, "MySQL timestamp compatibility: FAIL\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}
echo "MySQL timestamp compatibility: PASS ({$checked} migrations; custom microsecond fields use DATETIME precision)\n";
