# Titan Field Transitional Dependency / Donor Inventory


## Pass 3 — tenant/reference integrity boundary

`FieldReferenceIntegrity` is the single fail-closed validation layer for field-domain relationships. It only consumes the Field-owned `FieldTenantContext` plus the database connection; it does not import CRM implementation classes.

`FieldTenantContext::userBelongsToTenant()` was added so arbitrary owner/manager user references can be verified without reintroducing CRM tenancy code into the domain. `CrmFieldTenantContext` delegates that membership decision to CRM's existing company-context resolver inside the compatibility boundary.

Worker assignment is stricter than generic membership: scheduling, dispatch, work-order assignment and time entry require an active `crm_field_worker_profiles` row scoped to the current tenant.

## Pass 2 — explicit compatibility boundary

Titan Field remains compatible with the installed CRM extraction source, but domain/runtime code no longer imports CRM implementation classes directly.

The only allowed implementation coupling is isolated under:

`System/Infrastructure/Compatibility/Crm`

### Field-owned contracts

- `FieldTenantContext` — resolves canonical `tenant_company_id` and actor identity.
- `FieldAuditPort` — records mutation/audit evidence without exposing the CRM recorder to the domain.
- `FieldAutomationPort` — publishes compatibility automation events without exposing CRM event classes.
- `FieldHostGate` — preserves the installed CRM host-enable gate behind a Field interface.
- `FieldPermissionGate` — route-facing Field interface. Pass 5 now binds it to the Field-owned permission service; the CRM adapter remains available only as a compatibility artifact.

### CRM compatibility adapters

- `CrmFieldTenantContext`
- `CrmFieldAuditAdapter`
- `CrmFieldAutomationAdapter`
- `CrmFieldHostGate`
- `CrmFieldPermissionGate`

Routes use Titan Field-owned middleware wrappers. Historical Laravel route names remain `dashboard.user.crm.field-services.*`, preserving installed menu rows, active-state behaviour and host plan/entitlement compatibility.

Titan Field also owns the `titan-field.*` configuration namespace. During the extraction bridge, `config/titan-field.php` inherits existing `crm.*` values so upgrades preserve business behaviour without leaving CRM configuration references scattered through the domain.

## Deferred boundary replacements

Pass 4 adds the Titan-owned governed capability catalogue and transactional Signal/outbox/receipt boundary. CRM audit and automation adapters remain deliberate compatibility infrastructure for existing consumers; the Titan Field outbox is authoritative for Signal publication. Pass 5 adds the governed command gateway/alias bridge and moves field permission ownership out of the current CRM permission catalogue.

## Donor extraction targets

`FieldCore.zip` and `Titan Operations Team.zip` remain donor sources only. Later passes may selectively adapt recurrence, availability, scheduling intelligence, SLA/exception, routing/location, UI, profitability/capacity, mobile and optimization concepts. Duplicate donor writers remain rejected.


## Pass 5 — command / permission dependency change

The newer inspected CRM Core permission catalogue no longer declares the extracted field-specific permission names. Titan Field therefore must not send `crm.field_services.manage`, `crm.work_orders.manage`, `crm.dispatch.manage`, and related aliases to `CrmPermissionService` as if CRM still owned them. `FieldPermissionCatalog` now owns the canonical permissions and maps those historical names as compatibility aliases.

`FieldCommandGateway`, `FieldCommandAuthorizer`, and `FieldCommandRouter` are Field-owned contracts. No command gateway class imports CRM implementation namespaces. Titan Command Bus and other governed clients can later adapt to this stable boundary rather than dispatching CRM field aliases directly.
