# Titan Autonomy Engine v1.4.0

## Delegated autonomous authority

- Added `DelegatedAuthorityEnvelopeService` for short-lived, purpose-derived HMAC authority envelopes.
- Bound delegated grants to `tenant_company_id`, capability, workflow, active autonomy level, scope hash, current policy fingerprint, Interaction session, interaction/correlation IDs and expiry.
- Added `InteractionDelegatedAuthorityVerifier` that re-reads current capability state and policy before Interaction Engine may accept a grant.
- Trusted Auto delegation now requires a current persisted three-way handshake: Platform + Authorised User + TitanAI/Assurance.
- Scope changes, policy changes, autonomy regression and expired grants invalidate delegation without relying on client state.
- Autonomous CommandBus dispatch is now a `system` actor with no inherited human roles; server-side host user identity is retained only for audit/correlation.
- Client-supplied delegated authority, tenant IDs, workflow keys and actor roles are stripped and replaced with server-derived values.
- Governed execution issues delegated authority only after current Assurance, risk ceiling, scope and completed Interaction-session checks pass.
- Added cross-extension delegated-authority integration coverage against Interaction Engine 10.4.0.

## Security invariants

- No delegation token can mint or elevate its own underlying autonomy grant.
- No raw trusted scope is placed in the signed envelope; a canonical scope hash is used.
- No human approval is fabricated.
- Missing verifier, missing delegation service, malformed signature, stale policy/state or missing Trusted Auto handshake fails closed.
