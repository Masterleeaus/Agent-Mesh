# Installer 1.7.4 Archive Shape Hotfix

The v1.0.0-rc.1 cumulative package originally contained two files named `extension.json`:

- `extension.json` — the active Titan Model Council package manifest.
- `legacy-source/extension.json` — a byte-preserved donor manifest retained for migration provenance.

Titan Extension Manager Installer 1.7.4 recursively counts files with the exact basename `extension.json` and rejects packages unless exactly one exists at archive root or one top-level folder deep.

This packaging-only hotfix renames the archived donor file to `legacy-source/extension-json.legacy.txt`. Its bytes and SHA-256 are unchanged. `legacy-source/LEGACY-FILE-MAP.json` records the original path, archived path, hash and preservation status.

No active PHP, route, migration, provider, billing, tenancy, Risk, Shield, Assurance, Signal, Council or UI implementation changed in this hotfix.

## Runtime dependency convergence

The Installer 1.7.4 root manifest now requires the currently installable Signal package identity `titan-signal-engine >=0.20.0-rc.7`. The Blueprint 4.2 sidecar (`extension.manifest.json`) continues to declare the future canonical `titan-signal >=1.0` dependency. This intentionally separates current host installability from future canonical identity convergence.

## Installer 1.7.5 follow-up

The live Installer 1.7.5 validator additionally requires six non-empty strings in root `extension.json`: `schema`, `slug`, `name`, `version`, `folder`, and `provider`. The previous hotfix package omitted `name`, so validation stopped with `extension.json is missing a valid 'name' value.` Hotfix 2 adds `name: "Titan Model Council"` and retains the archive-shape fix.
