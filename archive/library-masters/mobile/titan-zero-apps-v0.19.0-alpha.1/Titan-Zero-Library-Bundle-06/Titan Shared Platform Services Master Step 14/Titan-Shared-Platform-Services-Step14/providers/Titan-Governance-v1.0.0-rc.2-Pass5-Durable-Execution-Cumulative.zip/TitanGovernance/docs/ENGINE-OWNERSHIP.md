# Engine Ownership

This extension must preserve the ownership boundaries declared in `extension.manifest.json`.

- Do not duplicate authoritative responsibilities owned by another Titan engine.
- Cross-domain writes must follow declared capability/Command Bus boundaries when governed.
- Compatibility adapters may read legacy state during convergence but must not create a second permanent write authority.
