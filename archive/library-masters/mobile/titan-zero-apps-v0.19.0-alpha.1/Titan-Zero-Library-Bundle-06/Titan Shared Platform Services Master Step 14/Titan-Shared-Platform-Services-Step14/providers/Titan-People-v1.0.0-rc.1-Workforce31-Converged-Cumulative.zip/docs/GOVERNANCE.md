# Governance

Command Bus, Risk, Assurance and Autonomy remain external Titan authorities. Titan People owns its domain facts and Workforce definitions, but cannot manufacture authority for itself.

`GovernedPeopleCommandExecutor` requires tenant, actor, idempotency and trace/correlation/causation context. AI/governance-required mutations fail closed when authority is unavailable, denied or lacks an authoritative receipt.

Pass 4 adds deterministic People detectors and proactive task planning. Findings are recommendations only (`autoMutate=false`, `requiresHumanReview=true`). `PeopleWorkforceProposalService` rejects AI self-approval and executes an approved proposal only through the governed Command Bus boundary. Proactive task idempotency is deterministic by tenant + finding + worker reference + time bucket, with high/critical findings escalating to the People manager.
