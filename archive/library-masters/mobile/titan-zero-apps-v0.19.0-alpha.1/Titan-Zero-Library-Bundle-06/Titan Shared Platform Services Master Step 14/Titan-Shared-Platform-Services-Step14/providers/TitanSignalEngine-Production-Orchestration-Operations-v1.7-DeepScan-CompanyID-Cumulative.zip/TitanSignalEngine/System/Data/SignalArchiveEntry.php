<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalArchiveEntry
{
    public function __construct(
        public string $eventId,
        public string $batchId,
        public string $scope,
        public ?int $tenantCompanyId,
        public string $eventType,
        public string $traceId,
        public string $correlationId,
        public ?string $causationId,
        public string $rootCausationId,
        public string $occurredAt,
        public string $recordedAt,
        public string $archiveDriver,
        public string $archiveLocator,
        public string $archiveChecksum,
        public int $archiveSequence,
        public bool $privacyProjected,
        public string $originalChecksum,
    ) {
        if ($this->eventId === '' || $this->batchId === '' || $this->archiveLocator === '') {
            throw new InvalidArgumentException('Signal archive catalog identities must not be empty.');
        }
        if (! in_array($this->scope, ['tenant', 'system'], true)) {
            throw new InvalidArgumentException('Signal archive catalog scope is invalid.');
        }
        if ($this->scope === 'tenant' && $this->tenantCompanyId === null) {
            throw new InvalidArgumentException('Tenant archive catalog entries require tenant_company_id.');
        }
        if ($this->scope === 'system' && $this->tenantCompanyId !== null) {
            throw new InvalidArgumentException('System archive catalog entries cannot carry tenant_company_id.');
        }
        if ($this->archiveSequence < 1) {
            throw new InvalidArgumentException('Signal archive sequence must start at one.');
        }
        if (! preg_match('/^[a-f0-9]{64}$/', $this->archiveChecksum)) {
            throw new InvalidArgumentException('Signal archive checksum must be lowercase SHA-256 hex.');
        }
        if (! preg_match('/^[a-f0-9]{64}$/', $this->originalChecksum)) {
            throw new InvalidArgumentException('Signal original checksum reference must be lowercase SHA-256 hex.');
        }
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'event_id' => $this->eventId,
            'batch_id' => $this->batchId,
            'scope' => $this->scope,
            'tenant_company_id' => $this->tenantCompanyId,
            'event_type' => $this->eventType,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
            'occurred_at' => $this->occurredAt,
            'recorded_at' => $this->recordedAt,
            'archive_driver' => $this->archiveDriver,
            'archive_locator' => $this->archiveLocator,
            'archive_checksum' => $this->archiveChecksum,
            'archive_sequence' => $this->archiveSequence,
            'privacy_projected' => $this->privacyProjected,
            'original_checksum' => $this->originalChecksum,
        ];
    }
}
