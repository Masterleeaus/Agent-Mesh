<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use DateInterval;
use DateTimeImmutable;
use InvalidArgumentException;

final readonly class PulseWindow
{
    public function __construct(
        public string $key,
        public int $seconds,
        public string $granularity,
        public DateTimeImmutable $start,
        public DateTimeImmutable $end,
    ) {
        if (! in_array($granularity, ['minute', 'hour', 'day'], true)) {
            throw new InvalidArgumentException('Pulse granularity must be minute, hour, or day.');
        }
        if ($seconds < 1 || $start >= $end) {
            throw new InvalidArgumentException('Pulse window must have a positive duration.');
        }
    }

    public static function fromKey(string $key, ?DateTimeImmutable $now = null): self
    {
        $now ??= new DateTimeImmutable('now');
        [$seconds, $granularity] = match ($key) {
            '5m' => [300, 'minute'],
            '1h' => [3600, 'minute'],
            '24h' => [86400, 'hour'],
            '7d' => [604800, 'day'],
            default => throw new InvalidArgumentException('Pulse window must be one of: 5m, 1h, 24h, 7d.'),
        };

        return new self(
            $key,
            $seconds,
            $granularity,
            $now->sub(new DateInterval('PT' . $seconds . 'S')),
            $now,
        );
    }
}
