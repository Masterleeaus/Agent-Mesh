<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Recovery;

use App\Extensions\TitanRewind\System\Support\CanonicalJson;

final class RewindRecoveryPlanner
{
    public function build(array $trace, array $request = []): array
    {
        $integrity = strtolower(trim((string) ($trace['forensics']['integrity']['status'] ?? 'unknown')));
        $capability = trim((string) ($request['proposed_capability'] ?? ''));
        if ($capability !== '' && preg_match('/^[a-z0-9][a-z0-9._:-]{0,119}$/', $capability) !== 1) throw new \InvalidArgumentException('Malformed compensating capability identifier.');
        $commandInput = is_array($request['command_input'] ?? null) ? $request['command_input'] : [];
        $root = is_array($trace['root_cause']['primary'] ?? null) ? $trace['root_cause']['primary'] : [];
        $risk = $this->risk($trace, $root);
        $target = $this->target($trace['snapshot_comparisons'] ?? []);
        $blockers = [];

        if ($integrity !== 'passed') $blockers[] = $integrity === 'failed' ? 'integrity_failed' : 'integrity_not_verified';
        if ($capability === '') $blockers[] = 'compensating_capability_required';
        if ((int) ($trace['tenant_company_id'] ?? 0) < 1) $blockers[] = 'tenant_context_required';
        if (trim((string) ($trace['trace_id'] ?? '')) === '') $blockers[] = 'trace_identity_required';
        if ((int) ($trace['event_count'] ?? 0) < 1) $blockers[] = 'trace_evidence_required';
        $hasRootCause = trim((string) ($root['event_id'] ?? '')) !== '' || trim((string) ($root['event_type'] ?? '')) !== '';
        $hasSnapshotChange = false;
        foreach ($trace['snapshot_comparisons'] ?? [] as $comparison) {
            if (is_array($comparison) && (int) ($comparison['diff']['count'] ?? 0) > 0) { $hasSnapshotChange = true; break; }
        }
        $hasRecoveryBasis = $hasRootCause || $hasSnapshotChange || !empty($trace['forensics']['open_drift_findings'] ?? []);
        if (!$hasRecoveryBasis) $blockers[] = 'recovery_basis_not_identified';

        $steps = [
            $this->step(1, 'verify_evidence_integrity', 'titan-rewind', false,
                ['trace_id'=>$trace['trace_id'] ?? null],
                ['integrity_status'=>'passed'],
                'Require a passing Rewind integrity result before corrective submission.'),
            $this->step(2, 'verify_current_authoritative_state', 'authoritative-domain-read-model', false,
                ['target_type'=>$target['entity_type'],'target_id'=>$target['entity_id'],'tenant_company_id'=>$trace['tenant_company_id'] ?? null],
                ['fresh_authoritative_state'=>true,'tenant_boundary_verified'=>true],
                'Read fresh authoritative state inside the same tenant immediately before correction.'),
            $this->step(3, 'compare_current_to_audited_state', 'titan-rewind', false,
                ['target_type'=>$target['entity_type'],'target_id'=>$target['entity_id'],'snapshot_comparisons'=>$trace['snapshot_comparisons'] ?? []],
                ['comparison_reviewed'=>true,'newer_valid_state_preserved'=>true],
                'Compare current state with audited snapshots without blind overwrite.'),
            $this->step(4, 'request_governance_approval', 'titan-governance', in_array($risk,['high','critical'],true),
                ['proposed_capability'=>$capability !== '' ? $capability : null,'command_input'=>$commandInput,'risk_level'=>$risk],
                ['governance_receipt'=>true],
                'Request Titan Governance authority for the explicit compensating capability.'),
            $this->step(5, 'submit_authorized_command', 'titan-command-bus', false,
                ['proposed_capability'=>$capability !== '' ? $capability : null,'command_input'=>$commandInput],
                ['command_bus_receipt'=>true],
                'After external Governance approval, submit through Titan Command Bus; Rewind never executes the mutation.'),
            $this->step(6, 'verify_outcome', 'titan-rewind', false,
                ['target_type'=>$target['entity_type'],'target_id'=>$target['entity_id']],
                ['outcome_signal_observed'=>true,'authoritative_state_rechecked'=>true],
                'Observe resulting state and Signals and compare them with the intended recovery outcome.'),
            $this->step(7, 'append_recovery_audit', 'titan-rewind', false,
                ['trace_id'=>$trace['trace_id'] ?? null],
                ['governance_receipt_recorded'=>true,'command_receipt_recorded'=>true,'outcome_recorded'=>true],
                'Append authorization, command receipt and outcome as immutable Rewind evidence.'),
        ];

        $plan = [
            'schema_version'=>1,
            'tenant_company_id'=>(int) ($trace['tenant_company_id'] ?? 0),
            'trace_id'=>(string) ($trace['trace_id'] ?? ''),
            'case_id'=>$request['case_id'] ?? null,
            'root_cause_event_id'=>$root['event_id'] ?? null,
            'root_cause_event_type'=>$root['event_type'] ?? null,
            'risk_level'=>$risk,
            'strategy'=>'governed_correction_not_blind_rollback',
            'proposed_capability'=>$capability !== '' ? $capability : null,
            'command_input'=>$commandInput,
            'requires_governance'=>true,
            'safe_to_auto_apply'=>false,
            'authoritative_mutation'=>false,
            'execution_owner'=>'titan-command-bus',
            'submission_ready'=>$blockers === [],
            'blockers'=>array_values(array_unique($blockers)),
            'steps'=>$steps,
        ];
        $plan['proposal_hash'] = hash('sha256', (new CanonicalJson())->encode($plan));
        return $plan;
    }

    private function step(int $order, string $type, string $owner, bool $requiresHuman, array $input, array $successEvidence, string $instruction): array
    {
        return [
            'step_order'=>$order,
            'step_type'=>$type,
            'execution_owner'=>$owner,
            'requires_human'=>$requiresHuman,
            'instruction'=>$instruction,
            'input'=>$input,
            'success_evidence'=>$successEvidence,
            'rewind_executes'=>false,
            'authoritative_mutation'=>false,
        ];
    }

    private function risk(array $trace, array $root): string
    {
        $rank = ['unknown'=>0,'low'=>1,'medium'=>2,'high'=>3,'critical'=>4];
        $selected = 'medium';
        $candidates = [$root['risk_level'] ?? null];
        $rootRisk = is_array($root['risk_state'] ?? null) ? $root['risk_state'] : [];
        foreach (['level','risk_level','overall','severity'] as $field) if (isset($rootRisk[$field])) { $candidates[] = $rootRisk[$field]; break; }
        foreach ($trace['snapshot_comparisons'] ?? [] as $comparison) if (is_array($comparison)) $candidates[] = $comparison['diff']['risk'] ?? null;
        foreach ($candidates as $candidate) {
            $candidate = strtolower(trim((string) $candidate));
            if (($rank[$candidate] ?? -1) > ($rank[$selected] ?? 2)) $selected = $candidate;
        }
        return in_array($selected, ['low','medium','high','critical'], true) ? $selected : 'medium';
    }

    private function target(mixed $comparisons): array
    {
        if (!is_array($comparisons)) return ['entity_type'=>null,'entity_id'=>null];
        foreach (array_reverse($comparisons) as $comparison) {
            if (!is_array($comparison)) continue;
            $type = trim((string) ($comparison['entity_type'] ?? ''));
            $id = trim((string) ($comparison['entity_id'] ?? ''));
            if ($type !== '' || $id !== '') return ['entity_type'=>$type ?: null,'entity_id'=>$id ?: null];
        }
        return ['entity_type'=>null,'entity_id'=>null];
    }
}
