# Authorization Matrix

| Surface | Principal | Tenant scope | Mutation authority |
|---|---|---|---|
| User overview | authenticated tenant user | required | none |
| `council.plan` | authenticated tenant user with Council entitlement | required | proposal only |
| `council.deliberate` | authenticated tenant user with Council/model entitlement | required | proposal only |
| Admin overview | platform admin | platform/admin route policy | none |
| Legacy accept-response | authenticated owning user | tenant + user + chat + shared UUID | compatibility message preference only |

No Council capability grants authority over business records.
