<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Console;

use App\Extensions\Crm\System\Services\CrmPerformanceAuditService;
use Illuminate\Console\Command;

final class CrmPerformanceCertifyCommand extends Command
{
    protected $signature='crm:performance:certify {company_id : Canonical tenant company ID} {--iterations=3 : Read-only timing repetitions, 1-10} {--json : Emit machine-readable JSON}';
    protected $description='Run read-only CRM host-runtime performance/index certification for one tenant.';
    public function handle(CrmPerformanceAuditService $audit): int{$tenant=(int)$this->argument('company_id');if($tenant<1){$this->error('company_id must be a positive integer.');return self::FAILURE;}$result=$audit->certify($tenant,(int)$this->option('iterations'));if((bool)$this->option('json')){$this->line(json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));}else{$this->info('CRM performance certification: '.$result['status']);$this->line('Scale band: '.$result['scale_band']);foreach($result['query_timings'] as $name=>$timing)$this->line(sprintf('%s p50=%sms p95=%sms',$name,(string)($timing['p50_ms']??'n/a'),(string)($timing['p95_ms']??'n/a')));foreach($result['warnings'] as $warning)$this->warn($warning);foreach($result['blocks'] as $block)$this->error($block);}return $result['status']==='BLOCK'?self::FAILURE:self::SUCCESS;}
}
