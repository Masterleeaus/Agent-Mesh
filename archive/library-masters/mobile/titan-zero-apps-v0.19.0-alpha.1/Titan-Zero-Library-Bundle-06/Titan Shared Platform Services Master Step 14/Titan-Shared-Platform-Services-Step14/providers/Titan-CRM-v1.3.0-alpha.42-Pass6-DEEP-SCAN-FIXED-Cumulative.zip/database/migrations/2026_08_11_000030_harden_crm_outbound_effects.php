<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('crm_notification_outbox')) return;

        Schema::table('crm_notification_outbox', function (Blueprint $t): void {
            if (! Schema::hasColumn('crm_notification_outbox','idempotency_key')) $t->string('idempotency_key',120)->nullable();
            if (! Schema::hasColumn('crm_notification_outbox','trace_id')) $t->string('trace_id',80)->nullable()->index();
            if (! Schema::hasColumn('crm_notification_outbox','correlation_id')) $t->string('correlation_id',80)->nullable()->index();
            if (! Schema::hasColumn('crm_notification_outbox','causation_id')) $t->string('causation_id',80)->nullable()->index();
            if (! Schema::hasColumn('crm_notification_outbox','command_id')) $t->string('command_id',80)->nullable()->index();
            if (! Schema::hasColumn('crm_notification_outbox','receipt_id')) $t->string('receipt_id',80)->nullable()->index();
            if (! Schema::hasColumn('crm_notification_outbox','provider')) $t->string('provider',80)->nullable()->index();
            if (! Schema::hasColumn('crm_notification_outbox','provider_message_id')) $t->string('provider_message_id',190)->nullable()->index();
            if (! Schema::hasColumn('crm_notification_outbox','provider_status')) $t->string('provider_status',60)->nullable()->index();
            if (! Schema::hasColumn('crm_notification_outbox','claimed_at')) $t->timestamp('claimed_at')->nullable()->index();
            if (! Schema::hasColumn('crm_notification_outbox','last_attempt_at')) $t->timestamp('last_attempt_at')->nullable();
        });

        $this->addTenantIdempotencyIndex();
    }

    public function down(): void
    {
        if (! Schema::hasTable('crm_notification_outbox')) return;

        try {
            Schema::table('crm_notification_outbox', function (Blueprint $t): void {
                $t->dropUnique('crm_notif_tenant_idem_uq');
            });
        } catch (\Throwable) {
            // Restartable rollback: the index may already be absent.
        }

        foreach (['last_attempt_at','claimed_at','provider_status','provider_message_id','provider','receipt_id','command_id','causation_id','correlation_id','trace_id','idempotency_key'] as $column) {
            if (Schema::hasColumn('crm_notification_outbox',$column)) {
                Schema::table('crm_notification_outbox', fn (Blueprint $t) => $t->dropColumn($column));
            }
        }
    }

    private function addTenantIdempotencyIndex(): void
    {
        if (! Schema::hasColumn('crm_notification_outbox','tenant_company_id') || ! Schema::hasColumn('crm_notification_outbox','idempotency_key')) return;
        try {
            Schema::table('crm_notification_outbox', function (Blueprint $t): void {
                $t->unique(['tenant_company_id','idempotency_key'],'crm_notif_tenant_idem_uq');
            });
        } catch (\Throwable) {
            // Restartable migration: the bounded unique index may already exist.
        }
    }
};
