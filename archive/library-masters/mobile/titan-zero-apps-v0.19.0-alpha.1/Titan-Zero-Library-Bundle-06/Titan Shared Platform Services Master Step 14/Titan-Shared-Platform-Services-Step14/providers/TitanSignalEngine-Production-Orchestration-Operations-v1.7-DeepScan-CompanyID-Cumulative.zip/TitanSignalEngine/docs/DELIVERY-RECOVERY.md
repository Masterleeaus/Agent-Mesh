# Delivery Recovery, Registry Cache Coherence & Backpressure

Titan Signal delivery remains **at-least-once**. Hardening Pass 4 adds governed recovery around that guarantee without rewriting immutable source events.

## Dead-letter redrive

Only a delivery in `dead_letter` state may be redriven. The caller must have `signal.delivery.redrive`, satisfy the original delivery's tenant/system boundary, provide a governed reason, and the subscriber must currently be installed and enabled.

Redrive:

1. atomically locks the dead-letter row;
2. appends an immutable `titan_signal_delivery_redrives` audit record;
3. marks the dead-letter incident resolved;
4. increments `redrive_count`;
5. resets only the retry-attempt cycle to zero;
6. preserves the original `delivery_id`, `event_id`, subscriber and historical dead-letter timestamps;
7. requeues the same delivery through the normal lease/CAS scheduler;
8. emits best-effort immutable `signal.subscription.redriven` telemetry.

The stable subscriber idempotency key remains `signal-delivery:<delivery_id>` across every redrive generation.

### Operator command

```bash
titan:signal-deliveries:redrive --delivery=<uuid> --scope=tenant --tenant=42 --reason="subscriber repaired"
```

Batch recovery is bounded and may optionally filter by subscriber.

## Registry cache coherence

Subscription definitions remain immutable/versioned. `titan_signal_subscription_registry_state` carries a monotonically increasing shared revision. Registry definition/runtime changes bump this revision and invalidate the shared cache key.

Long-running workers compare their loaded revision with the shared revision and also refresh after a short TTL. This prevents a queue worker from retaining an old subscription definition indefinitely even when the cache driver is process-local.

## Backpressure semantics

Backpressure is based on **current throughput pressure**, not retained historical incidents.

Current pressure score includes:

- pending deliveries;
- retry-wait deliveries;
- processing deliveries;
- additional weight for stale processing leases;
- additional weight for dead letters created in the recent DLQ window.

The following are reported separately and do not inflate current pressure by themselves:

- all unresolved dead letters;
- resolved historical dead letters retained for audit.

Source rate limiting requests a pressure snapshot scoped to the event's tenant/system boundary and source/component, preventing one tenant/source backlog from automatically throttling unrelated tenants.
