<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Repositories;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Contracts\NoteRepositoryContract; use App\Extensions\Crm\System\Services\CrmSubjectReferenceValidator; use Illuminate\Database\ConnectionInterface; use Illuminate\Support\Str;
final class EloquentNoteRepository implements NoteRepositoryContract {
 public function __construct(private ConnectionInterface $db,private CrmSubjectReferenceValidator $subjects){}
 public function search(int $userId,array $filters=[]): array { if(($filters['subject_type']??null)&&($filters['subject_public_id']??null))$this->subjects->require($userId,(string)$filters['subject_type'],(string)$filters['subject_public_id']); $q=$this->db->table('crm_notes')->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at'); if($v=$filters['subject_type']??null)$q->where('subject_type',$v); if($v=$filters['subject_public_id']??null)$q->where('subject_public_id',$v); return $q->orderByDesc('id')->limit(min((int)($filters['limit']??100),250))->get()->map(fn($r)=>(array)$r)->all(); }
 public function create(int $userId,int $actorUserId,array $data): array { $this->subjects->require($userId,(string)$data['subject_type'],(string)$data['subject_public_id']); $id=$this->db->table('crm_notes')->insertGetId(['public_id'=>(string)Str::ulid(),'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'subject_type'=>(string)$data['subject_type'],'subject_public_id'=>(string)$data['subject_public_id'],'body'=>(string)$data['body'],'is_pinned'=>(bool)($data['is_pinned']??false),'created_by_user_id'=>$actorUserId,'created_at'=>now(),'updated_at'=>now()]); return (array)$this->db->table('crm_notes')->where('id',$id)->first(); }
}
