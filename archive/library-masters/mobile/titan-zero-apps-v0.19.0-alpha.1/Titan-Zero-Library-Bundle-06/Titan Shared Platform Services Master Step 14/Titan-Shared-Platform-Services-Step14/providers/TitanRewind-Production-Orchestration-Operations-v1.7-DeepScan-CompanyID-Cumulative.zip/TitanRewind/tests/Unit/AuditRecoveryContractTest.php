<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanRewind\System\Audit\RewindEvidenceAssembler;
use App\Extensions\TitanRewind\System\Governance\FailClosedRewindGovernanceGateway;
use App\Extensions\TitanRewind\System\Recovery\RewindRecoveryPlanner;
use App\Extensions\TitanRewind\System\Support\CanonicalJson;
use LogicException;
use PHPUnit\Framework\TestCase;

final class AuditRecoveryContractTest extends TestCase
{
    public function test_evidence_package_is_deterministically_hashed_and_non_mutating(): void
    {
        $assembler = new RewindEvidenceAssembler(new CanonicalJson());
        $result = $assembler->assemble('audit', [
            'tenant_company_id'=>4,'trace_id'=>'t-1','event_count'=>1,'events'=>[['event_id'=>'e-1']],
            'forensics'=>['integrity'=>['status'=>'passed']],'mutation_allowed'=>false,
        ], null, [], [], [], [], [], '2026-08-15T20:00:00+10:00', 8);
        self::assertMatchesRegularExpression('/^[a-f0-9]{64}$/', $result['content_hash']);
        self::assertFalse($result['payload']['authoritative_mutation']);
        self::assertFalse($result['payload']['hidden_chain_of_thought_included']);
    }

    public function test_recovery_plan_delegates_authoritative_execution_to_command_bus(): void
    {
        $plan = (new RewindRecoveryPlanner())->build([
            'tenant_company_id'=>4,'trace_id'=>'t-1','event_count'=>1,
            'forensics'=>['integrity'=>['status'=>'passed'],'open_drift_findings'=>[]],
            'root_cause'=>['primary'=>['event_id'=>'e-1','risk_level'=>'high']],
            'snapshot_comparisons'=>[],
        ], ['proposed_capability'=>'invoice.compensate','command_input'=>['invoice_id'=>9]]);
        self::assertTrue($plan['requires_governance']);
        self::assertFalse($plan['authoritative_mutation']);
        self::assertSame('titan-command-bus', $plan['execution_owner']);
        self::assertTrue($plan['submission_ready']);
    }

    public function test_default_governance_gateway_fails_closed(): void
    {
        $gateway = new FailClosedRewindGovernanceGateway();
        self::assertFalse($gateway->available());
        $this->expectException(LogicException::class);
        $gateway->requestApproval(['tenant_company_id'=>4]);
    }
}
