<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Support\CrmNormalizer;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class CrmIdentityAuthorityService
{
    public function __construct(private ConnectionInterface $db) {}

    public function ensureRootForCompany(int $userId, string $companyPublicId): string
    {
        $tenant=CrmCompanyScope::companyId($userId);
        return $this->db->transaction(function() use($tenant,$companyPublicId): string {
            $row=$this->db->table('crm_companies')->where('company_id',$tenant)->where('public_id',$companyPublicId)->whereNull('deleted_at')->lockForUpdate()->first();
            if(!$row) throw ValidationException::withMessages(['company_public_id'=>['CRM company not found.']]);
            $root=(string)($row->customer_unification_id??'');
            if($root===''){ $root=(string)Str::ulid(); $this->db->table('crm_companies')->where('id',$row->id)->update(['customer_unification_id'=>$root,'updated_at'=>now()]); }
            return $root;
        },3);
    }

    public function ensureRootForContact(int $userId, string $contactPublicId, ?int $companyId=null): string
    {
        $tenant=CrmCompanyScope::companyId($userId);
        return $this->db->transaction(function() use($tenant,$contactPublicId,$companyId): string {
            $row=$this->db->table('crm_contacts')->where('company_id',$tenant)->where('public_id',$contactPublicId)->whereNull('deleted_at')->lockForUpdate()->first();
            if(!$row) throw ValidationException::withMessages(['contact_public_id'=>['CRM contact not found.']]);
            $companyId=$companyId??($row->customer_company_id? (int)$row->customer_company_id:null); $root='';
            if($companyId){ $root=(string)($this->db->table('crm_companies')->where('company_id',$tenant)->where('id',$companyId)->whereNull('deleted_at')->value('customer_unification_id')??''); }
            if($root==='') $root=(string)($row->customer_unification_id??'');
            if($root==='') $root=(string)Str::ulid();
            if((string)($row->customer_unification_id??'')!==$root) $this->db->table('crm_contacts')->where('id',$row->id)->update(['customer_unification_id'=>$root,'updated_at'=>now()]);
            return $root;
        },3);
    }

    public function ensureRootForLead(int $userId, string $leadPublicId): string
    {
        $tenant=CrmCompanyScope::companyId($userId);
        $row=$this->db->table('crm_leads')->where('company_id',$tenant)->where('public_id',$leadPublicId)->whereNull('deleted_at')->first();
        if(!$row) throw ValidationException::withMessages(['lead'=>['Lead not found.']]);
        $root=(string)($row->customer_unification_id??'');
        if($root===''){ $root=(string)Str::ulid(); $this->db->table('crm_leads')->where('id',$row->id)->update(['customer_unification_id'=>$root,'updated_at'=>now()]); }
        return $root;
    }

    public function syncSubjectIdentities(int $userId,string $subjectType,string $subjectPublicId,string $root,?string $email,?string $phone): void
    {
        $tenant=CrmCompanyScope::companyId($userId); $now=now();
        $values=['email'=>CrmNormalizer::email($email),'phone'=>CrmNormalizer::phone($phone)];
        foreach($values as $type=>$value){
            $this->db->table('crm_customer_identities')->where('company_id',$tenant)->where('subject_type',$subjectType)->where('subject_public_id',$subjectPublicId)->where('identity_type',$type)->when($value!==null,fn($q)=>$q->where('normalized_value','!=',$value))->delete();
            if($value===null) continue;
            $identity=$this->db->table('crm_customer_identities')->where('company_id',$tenant)->where('subject_type',$subjectType)->where('subject_public_id',$subjectPublicId)->where('identity_type',$type)->where('normalized_value',$value)->first();
            if($identity){
                $this->db->table('crm_customer_identities')->where('id',$identity->id)->update(['customer_unification_id'=>$root,'source'=>'crm','is_primary'=>true,'metadata'=>json_encode(['normalizer_version'=>'1.0']),'updated_at'=>$now]);
            }else{
                $this->db->table('crm_customer_identities')->insert(['public_id'=>(string)Str::ulid(),'company_id'=>$tenant,'customer_unification_id'=>$root,'subject_type'=>$subjectType,'subject_public_id'=>$subjectPublicId,'identity_type'=>$type,'normalized_value'=>$value,'source'=>'crm','is_primary'=>true,'metadata'=>json_encode(['normalizer_version'=>'1.0']),'created_at'=>$now,'updated_at'=>$now]);
            }
        }
    }

    public function resolveByIdentity(int $userId,?string $email=null,?string $phone=null,?string $provider=null,?string $externalIdentityId=null): array
    {
        $tenant=CrmCompanyScope::companyId($userId); $matches=[];
        foreach(['email'=>CrmNormalizer::email($email),'phone'=>CrmNormalizer::phone($phone)] as $type=>$value){
            if($value===null) continue;
            foreach($this->db->table('crm_customer_identities')->where('company_id',$tenant)->where('identity_type',$type)->where('normalized_value',$value)->get() as $row){
                $matches[]=['customer_unification_id'=>$row->customer_unification_id,'identity_type'=>$type,'normalized_value'=>$value,'subject_type'=>$row->subject_type,'subject_public_id'=>$row->subject_public_id,'source'=>'crm'];
            }
        }
        if(trim((string)$provider)!==''&&trim((string)$externalIdentityId)!==''){
            $row=$this->db->table('crm_external_identities')->where('company_id',$tenant)->where('provider',strtolower(trim((string)$provider)))->where('external_identity_id',trim((string)$externalIdentityId))->first();
            if($row)$matches[]=['customer_unification_id'=>$row->customer_unification_id,'identity_type'=>'external','normalized_value'=>$row->external_identity_id,'subject_type'=>$row->subject_type,'subject_public_id'=>$row->subject_public_id,'source'=>$row->provider];
        }
        $roots=[]; foreach($matches as $match){$roots[$match['customer_unification_id']][]=$match;}
        return ['matches'=>$matches,'roots'=>array_map(fn($id,$items)=>['customer_unification_id'=>$id,'matches'=>$items],array_keys($roots),array_values($roots)),'ambiguous'=>count($roots)>1];
    }

    public function linkExternalIdentity(int $userId,string $root,string $provider,string $externalIdentityId,?string $subjectType=null,?string $subjectPublicId=null,array $metadata=[]): array
    {
        $tenant=CrmCompanyScope::companyId($userId); $provider=strtolower(trim($provider)); $externalIdentityId=trim($externalIdentityId);
        if($provider===''||$externalIdentityId==='') throw ValidationException::withMessages(['external_identity'=>['Provider and external identity are required.']]);
        $allowed=(array)config('crm.identity.external_identity_providers',[]);if($allowed!==[]&&!in_array($provider,$allowed,true))throw ValidationException::withMessages(['provider'=>['External identity provider is not enabled for CRM.']]);
        if(!$this->rootExists($tenant,$root)) throw ValidationException::withMessages(['customer_unification_id'=>['Customer identity root not found in this tenant.']]);
        if($subjectType!==null&&$subjectPublicId!==null){$subjectRoot=$this->subjectRoot($tenant,$subjectType,$subjectPublicId);if($subjectRoot===null)throw ValidationException::withMessages(['subject_public_id'=>['External identity subject not found in this tenant.']]);if($subjectRoot!==$root)throw ValidationException::withMessages(['customer_unification_id'=>['External identity subject belongs to a different customer root.']]);}
        $existing=$this->db->table('crm_external_identities')->where('company_id',$tenant)->where('provider',$provider)->where('external_identity_id',$externalIdentityId)->first();
        if($existing && (string)$existing->customer_unification_id!==$root) throw ValidationException::withMessages(['external_identity'=>['External identity is already linked to another customer root.']]);
        if(!$existing){$id=(string)Str::ulid();$this->db->table('crm_external_identities')->insert(['public_id'=>$id,'company_id'=>$tenant,'customer_unification_id'=>$root,'provider'=>$provider,'external_identity_id'=>$externalIdentityId,'subject_type'=>$subjectType,'subject_public_id'=>$subjectPublicId,'metadata'=>json_encode($metadata),'created_at'=>now(),'updated_at'=>now()]);}
        else {$id=(string)$existing->public_id;$this->db->table('crm_external_identities')->where('id',$existing->id)->update(['subject_type'=>$subjectType??$existing->subject_type,'subject_public_id'=>$subjectPublicId??$existing->subject_public_id,'metadata'=>json_encode($metadata),'updated_at'=>now()]);}
        return (array)$this->db->table('crm_external_identities')->where('company_id',$tenant)->where('public_id',$id)->first();
    }

    private function subjectRoot(int $tenant,string $type,string $publicId): ?string
    {
        $table=['company'=>'crm_companies','contact'=>'crm_contacts','lead'=>'crm_leads'][$type]??null;if($table===null)return null;
        $value=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->value('customer_unification_id');return $value? (string)$value:null;
    }

    private function rootExists(int $tenant,string $root): bool
    {
        foreach(['crm_companies','crm_contacts','crm_leads'] as $table) if($this->db->table($table)->where('company_id',$tenant)->where('customer_unification_id',$root)->exists()) return true;
        return false;
    }
}
