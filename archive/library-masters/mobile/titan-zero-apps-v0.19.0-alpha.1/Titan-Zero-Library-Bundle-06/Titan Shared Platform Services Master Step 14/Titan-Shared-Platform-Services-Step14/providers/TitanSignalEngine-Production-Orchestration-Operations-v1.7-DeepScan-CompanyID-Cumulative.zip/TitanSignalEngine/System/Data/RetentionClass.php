<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

enum RetentionClass: string
{
    case CriticalAudit = 'critical_audit';
    case Audit = 'audit';
    case Operational = 'operational';
    case Telemetry = 'telemetry';
    case Debug = 'debug';
}
