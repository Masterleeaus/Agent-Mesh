# Titan Signal Engine — Upgrade Prompt

# Titan Zero Global Architecture Rules

This extension is part of the governed Titan Zero architecture. Preserve these boundaries:

- AI intelligence never directly mutates authoritative business state when a governed capability/Command Bus path exists.
- Intelligence, risk, assurance, autonomy, approval and execution remain separate concerns.
- Every significant action emits structured Signal telemetry and a traceable receipt.
- Use tenant_company_id, trace_id, correlation_id and causation_id on durable cross-extension records/events.
- Do not store unrestricted hidden model reasoning; store structured decision rationale, reason codes, policy/evidence references and outcomes.
- Offline operation may reduce authority but must never increase it.
- External side effects must be idempotent.
- Preserve installer compatibility and existing working host UI conventions.
- Prefer shared contracts/adapters over importing another extension's internal implementation classes.

## Extension Mission

MISSION: Build Titan Signal Engine as the independent nervous system observing every Titan extension.

OWN: canonical event ingestion, trace correlation, Pulse health metrics, throughput, bottleneck detection, anomaly detection, governance telemetry and subscriptions.

DO NOT OWN: business decisions, approvals, Risk decisions, Rewind presentation.

NEXT BUILD:
1. Canonical SignalEvent envelope with event_id/type/time/tenant/actor/trace/correlation/causation/source/schema_version.
2. Durable append-oriented event store and indexed correlation lookups.
3. Pulse aggregation for workload, flow, assurance, risk, SLA, exceptions, integrations and autonomy.
4. Detectors for loops, repeated failures, queue spikes, missing receipts, excessive overrides and stalled workflows.
5. Subscription interface and graceful operation when optional consumers are missing.
6. Retention/archival policy and tenant isolation.
7. Tests proving events are immutable, correlated and safely replayable.

## Universal Acceptance

- Installer/manifest validation passes.
- PHP syntax checks pass.
- Tenant boundaries are explicit.
- Cross-engine calls use public contracts/adapters.
- Significant states are traceable.
- No high-risk or authoritative mutation bypass is introduced.
