# Titan CRM Core — Current Upgrade Summary

## Current release

**Version:** `1.3.0-alpha.27`  
**Role:** authoritative customer, sales and commercial CRM Core

Alpha.27 completes the first production boundary audit after extracting Titan Field, Titan Locker, Titan Ledger, Titan Pay and CRM-local autonomy/intelligence responsibilities.

## What changed in alpha.27

- removed per-class external-domain compatibility aliases and obsolete providers/controllers
- removed CRM-owned Titan Go Field/offline/delta runtime
- removed Field-owned projections, analytics and owner/customer dashboard augmentation
- removed external-domain Chatbot tools and CRM automation triggers/actions
- removed external-domain Interaction journeys, Global New actions, quick prompts, record actions and chains
- removed 51 dormant external-domain Interaction JSON wizards
- removed obsolete Finance Assistant UI/runtime and retained six deterministic commercial calculators under `CommercialCalculations`
- stopped fresh CRM Core installs from creating Titan Field mobile/sync schema and Titan Pay payment/allocation schema
- removed obsolete monolith diagnostics, outdated deployment guides and extracted-domain documentation
- updated compatibility metadata to distinguish 106 CRM-owned governed capabilities from 120 external compatibility names

## Core authority

CRM Core owns customer and commercial truth:

- customers, organisations and contacts
- leads, deals and pipelines
- CRM activities and metadata
- CRM coordination projects/tasks/calendar
- commercial service/catalogue definitions
- quotes, estimates and invoices
- receivables business state
- portal/import/integration metadata
- CRM CQRS/read models
- governed commercial calculations

## External owners

- Titan Field — field operations and Titan Go
- Titan Locker — inventory/purchasing/fleet
- Titan Ledger — accounting
- Titan Pay — provider payment operations
- Titan Autonomy — autonomous authority
- Titan AI Core — planning
- Titan AI Workforce — proactive execution
- Titan Wisdom — learning

## Compatibility

Legacy external `crm.*` names remain temporarily routable through `CrmExternalDomainCapabilityBridge` and are classified by `CrmCapabilityOwnershipMap`. They are not CRM writers.

## Verification

Package verification:

```bash
php bin/verify.php
```

Target-host readiness:

```bash
php artisan crm:production-check
```

A package verification pass does not replace staging database, backup/restore, queue, scheduler, dependency-binding and load verification on the real host.

## Next pass

**alpha.28 — Customer & Organisation Authority v2**

Focus: customer unification, normalized identities, duplicate review, merge lineage and forensic lead conversion mapping.
