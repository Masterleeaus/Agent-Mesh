<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    private const TABLE = 'titan_nexus_compilation_events';

    public function up(): void
    {
        if (Schema::hasTable(self::TABLE)) { return; }
        Schema::create(self::TABLE, static function (Blueprint $table): void {
            $table->bigIncrements('id');
            $table->char('event_id', 64)->unique();
            $table->unsignedBigInteger('tenant_company_id')->index();
            $table->uuid('compilation_uuid');
            $table->uuid('parent_compilation_uuid')->nullable();
            $table->unsignedBigInteger('entity_version')->default(0);
            $table->string('stage', 64);
            $table->uuid('trace_id');
            $table->uuid('correlation_id');
            $table->uuid('causation_id');
            $table->char('payload_hash', 64);
            $table->json('payload');
            $table->timestamp('occurred_at')->useCurrent();
            $table->index(['tenant_company_id', 'compilation_uuid', 'id'], 'titan_nexus_lifecycle_lookup');
            $table->index(['tenant_company_id', 'parent_compilation_uuid'], 'titan_nexus_lifecycle_parent');
            $table->index(['stage', 'occurred_at'], 'titan_nexus_lifecycle_stage');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists(self::TABLE);
    }
};
