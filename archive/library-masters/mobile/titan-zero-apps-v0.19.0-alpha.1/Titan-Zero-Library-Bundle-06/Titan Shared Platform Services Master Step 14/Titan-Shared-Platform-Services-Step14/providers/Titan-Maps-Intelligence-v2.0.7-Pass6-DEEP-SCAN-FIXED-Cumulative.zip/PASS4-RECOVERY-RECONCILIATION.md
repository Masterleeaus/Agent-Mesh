# Pass 4 — Recovery, Reconciliation & Stuck Work

Version: `2.0.7`

This pass adds the shared `titan.ecosystem.recovery-reconciliation.v1` contract. Cross-extension retry preserves the original idempotency key and rechecks authority. Retry exhaustion enters dead-letter rather than disappearing. Partial success is not completion: the receipt is compared with target-domain state and any repair must use the governed command gateway. Unknown outcomes and permanent failures become `attention_required`. Stale workers cannot commit after lease loss or claim-generation change. Titan AI Workforce may verify outcomes and escalate work, but does not mutate target-domain state or own extension-local state.
