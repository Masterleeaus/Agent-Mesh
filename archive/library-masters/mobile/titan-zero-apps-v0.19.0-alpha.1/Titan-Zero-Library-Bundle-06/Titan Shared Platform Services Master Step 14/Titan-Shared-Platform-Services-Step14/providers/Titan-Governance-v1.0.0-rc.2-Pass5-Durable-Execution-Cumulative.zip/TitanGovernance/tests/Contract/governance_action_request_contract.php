<?php

declare(strict_types=1);

$root=dirname(__DIR__,2);
function fail_ga(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);} 
function assert_ga(bool $c,string $m):void{if(!$c)fail_ga($m);} 
function same_ga(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_ga($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}

foreach([
 '/System/Contracts/GovernanceCommandGatewayContract.php',
 '/System/Actions/GovernanceActionRequest.php',
 '/System/Actions/UnavailableGovernanceCommandGateway.php',
] as $file){if(!is_file($root.$file))fail_ga('missing '.$file);require_once $root.$file;}

use App\Extensions\TitanGovernance\System\Actions\GovernanceActionRequest;
use App\Extensions\TitanGovernance\System\Actions\UnavailableGovernanceCommandGateway;

$causal=['trace_id'=>'trace-1','correlation_id'=>'corr-1','causation_id'=>'cause-1','root_causation_id'=>'root-1'];
$request=GovernanceActionRequest::fromClient([
 'operation_id'=>'op-12345678',
 'action'=>'approve',
 'escalation_id'=>'esc-123',
 'expected_version'=>2,
 'reason_codes'=>['HUMAN_REVIEW_COMPLETE'],
 'evidence_refs'=>['rewind://trace/abc'],
],42,'user:7',$causal);

same_ga('APPROVE',$request->action,'action normalized');
same_ga('governance.escalation.approve',$request->capability(),'capability mapping');
same_ga(42,$request->tenantCompanyId,'server tenant retained');
same_ga('user:7',$request->actorId,'server actor retained');
assert_ga(strlen($request->payloadHash())===64,'canonical payload hash must be sha256');

$retryCausal=['trace_id'=>'trace-2','correlation_id'=>'corr-2','causation_id'=>'cause-2','root_causation_id'=>'root-2'];
$retryRequest=GovernanceActionRequest::fromClient([
 'operation_id'=>'op-12345678','action'=>'approve','escalation_id'=>'esc-123','expected_version'=>2,
 'reason_codes'=>['HUMAN_REVIEW_COMPLETE'],'evidence_refs'=>['rewind://trace/abc'],
],42,'user:7',$retryCausal);
same_ga($request->payloadHash(),$retryRequest->payloadHash(),'idempotency hash must ignore fresh transport trace IDs');
$reordered=GovernanceActionRequest::fromClient([
 'operation_id'=>'op-87654321','action'=>'approve','escalation_id'=>'esc-123','expected_version'=>2,
 'reason_codes'=>['B','A'],'evidence_refs'=>['evidence://2','evidence://1'],
],42,'user:7',$causal);
$ordered=GovernanceActionRequest::fromClient([
 'operation_id'=>'op-87654321','action'=>'approve','escalation_id'=>'esc-123','expected_version'=>2,
 'reason_codes'=>['A','B'],'evidence_refs'=>['evidence://1','evidence://2'],
],42,'user:7',$retryCausal);
same_ga($reordered->payloadHash(),$ordered->payloadHash(),'reason/evidence ordering must not change semantic idempotency hash');
$envelope=$request->commandEnvelope('gdec-001');
same_ga(42,$envelope['context']['tenant_company_id'],'command tenant');
same_ga('user:7',$envelope['context']['actor_id'],'command actor');
same_ga('gdec-001',$envelope['governance']['decision_ref'],'governance decision reference');
same_ga('APPROVE',$envelope['payload']['action'],'action payload');
same_ga(2,$envelope['payload']['expected_version'],'optimistic version');

$thrown=false;
try{GovernanceActionRequest::fromClient([
 'operation_id'=>'op-23456789','action'=>'reject','escalation_id'=>'esc-1','reason_codes'=>['X'],'tenant_company_id'=>999,
],42,'user:7',$causal);}catch(InvalidArgumentException){$thrown=true;}
assert_ga($thrown,'client tenant override must be rejected');

$thrown=false;
try{GovernanceActionRequest::fromClient([
 'operation_id'=>'op-34567890','action'=>'approve','escalation_id'=>'esc-1','reason_codes'=>[],
],42,'user:7',$causal);}catch(InvalidArgumentException){$thrown=true;}
assert_ga($thrown,'reason codes are required');


$thrown=false;
try{GovernanceActionRequest::fromClient([
 'operation_id'=>'op-45678901','action'=>'approve','escalation_id'=>'esc-1','reason_codes'=>array_fill(0,33,'R'),
],42,'user:7',$causal);}catch(InvalidArgumentException){$thrown=true;}
assert_ga($thrown,'reason code list must be bounded');

$thrown=false;
try{GovernanceActionRequest::fromClient([
 'operation_id'=>'op-56789012','action'=>'approve','escalation_id'=>'esc-1','reason_codes'=>['R'],'evidence_refs'=>array_map(fn($i)=>'evidence://'.$i,range(1,65)),
],42,'user:7',$causal);}catch(InvalidArgumentException){$thrown=true;}
assert_ga($thrown,'evidence reference list must be bounded');

$gateway=new UnavailableGovernanceCommandGateway();
$result=$gateway->dispatch($envelope);
same_ga('UNAVAILABLE',$result['status'],'default gateway must fail closed');
same_ga('COMMAND_BUS_UNAVAILABLE',$result['reason_code'],'explicit unavailable reason');

echo "PASS: Governance action request and Command Bus boundary\n";
