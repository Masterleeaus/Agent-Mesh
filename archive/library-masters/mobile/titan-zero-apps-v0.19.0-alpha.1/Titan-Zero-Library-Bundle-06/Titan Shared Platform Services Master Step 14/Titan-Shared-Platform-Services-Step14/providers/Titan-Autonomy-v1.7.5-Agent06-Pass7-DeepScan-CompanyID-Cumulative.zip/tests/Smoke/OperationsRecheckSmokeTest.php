<?php

declare(strict_types=1);

spl_autoload_register(function(string $class):void{$prefix='App\\Extensions\\TitanAutonomy\\';if(!str_starts_with($class,$prefix))return;$path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($prefix))).'.php';if(is_file($path))require_once $path;});

use App\Extensions\TitanAutonomy\System\Contracts\{ControlPlaneAuditSinkContract,ExecutionReceiptReconcilerContract,OperationsQueryContract};
use App\Extensions\TitanAutonomy\System\Services\OperationsRecheckService;

$query=new class implements OperationsQueryContract{
 public array $row=[];
 public function receipts(int $tenantCompanyId,array $filters=[],int $limit=100):array{return[];}
 public function receipt(int $tenantCompanyId,string $correlationId):?array{return (int)($this->row['tenant_company_id']??0)===$tenantCompanyId&&($this->row['correlation_id']??'')===$correlationId?$this->row:null;}
 public function feedback(int $tenantCompanyId,string $receiptPublicId,int $limit=100):array{return[];}
};
$reconciler=new class implements ExecutionReceiptReconcilerContract{public int $calls=0;public function finalizeReceiptDue(int $tenantCompanyId,string $correlationId):array{$this->calls++;return ['status'=>'finalized','correlation_id'=>$correlationId];}};
$audit=new class implements ControlPlaneAuditSinkContract{public array $events=[];public function record(array $event):string{$this->events[]=$event;return 'A1';}};
$svc=new OperationsRecheckService($query,$reconciler,$audit,'policy-v1');
$query->row=['tenant_company_id'=>42,'correlation_id'=>'corr-1','observation_status'=>'observing','matures_at'=>gmdate('Y-m-d H:i:s',time()+3600),'capability'=>'crm.invoice.issue','workflow_key'=>'completed_job_invoice'];
try{$svc->recheck(42,7,'corr-1');throw new RuntimeException('Early recheck unexpectedly accepted.');}catch(RuntimeException $e){if($e->getMessage()==='Early recheck unexpectedly accepted.')throw $e;}
if($reconciler->calls!==0)throw new RuntimeException('Early recheck must not invoke reconciliation.');
$query->row['matures_at']=gmdate('Y-m-d H:i:s',time()-1);
$result=$svc->recheck(42,7,'corr-1');
if($reconciler->calls!==1||($result['status']??null)!=='finalized')throw new RuntimeException('Mature tenant-owned receipt must be recheckable exactly once through canonical reconciler.');
if(($audit->events[0]['event_type']??null)!=='autonomy.operations.recheck')throw new RuntimeException('Manual recheck must be auditable.');

echo "OK: OperationsRecheckSmokeTest\n";
