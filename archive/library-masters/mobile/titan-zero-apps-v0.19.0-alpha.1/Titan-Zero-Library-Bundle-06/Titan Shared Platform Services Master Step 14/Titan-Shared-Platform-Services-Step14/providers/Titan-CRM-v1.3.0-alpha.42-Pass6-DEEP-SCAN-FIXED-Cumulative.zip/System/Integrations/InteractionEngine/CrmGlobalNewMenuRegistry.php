<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\InteractionEngine;

use App\Extensions\Crm\System\Capabilities\CrmCapabilityManifest;
use App\Extensions\Crm\System\Security\CrmPermissionService;

/**
 * Builds the CRM-owned context menu that adapts MagicAI's global + New control.
 * This registry only describes Interaction Engine journeys. It never executes a
 * CRM capability itself.
 */
final class CrmGlobalNewMenuRegistry
{
    public function __construct(
        private CrmInteractionJourneyRegistry $journeys,
        private CrmCapabilityManifest $capabilities,
        private CrmPermissionService $permissions,
    ) {}

    /**
     * @param array<string,mixed> $context
     * @return array{primary:?array<string,mixed>,secondary:list<array<string,mixed>>}
     */
    public function forPage(
        int $userId,
        string $surface,
        string $pageTitle = '',
        ?string $recordType = null,
        array $context = [],
        ?string $declaredPrimaryKey = null,
    ): array {
        $surface = strtolower(trim($surface));
        $title = strtolower(trim($pageTitle));
        $recordType = strtolower(trim((string) $recordType));

        $keys = [];
        if ($declaredPrimaryKey !== null && $declaredPrimaryKey !== '') {
            $keys[] = $declaredPrimaryKey;
        }

        foreach ($this->contextKeys($surface, $title, $recordType) as $key) {
            if (! in_array($key, $keys, true)) $keys[] = $key;
        }

        $actions = [];
        foreach ($keys as $key) {
            $action = $this->action($userId, $key, $context);
            if ($action !== null) $actions[] = $action;
        }

        return [
            'primary' => $actions[0] ?? null,
            'secondary' => array_values(array_slice($actions, 1)),
        ];
    }

    /** @return list<string> */
    private function contextKeys(string $surface, string $title, string $recordType): array
    {
        if ($recordType !== '') {
            return $this->recordKeys($recordType);
        }

        if (str_contains($title, 'contact')) {
            return ['new-contact', 'new-customer', 'new-quote'];
        }
        if (str_contains($title, 'customer hub')) {
            return ['new-hub-access', 'new-customer', 'new-contact'];
        }
        if ($surface === 'customers' || str_contains($title, 'customer') || str_contains($title, 'compan')) {
            return ['new-customer', 'new-contact', 'new-hub-access'];
        }
        if (str_contains($title, 'pipeline')) {
            return ['new-pipeline', 'new-lead', 'new-opportunity', 'new-quote'];
        }
        if (str_contains($title, 'opportun') || str_contains($title, 'deal')) {
            return ['new-opportunity', 'new-lead', 'new-quote', 'new-estimate', 'new-pipeline'];
        }
        if ($surface === 'leads' || str_contains($title, 'lead')) {
            return ['new-lead', 'new-opportunity', 'new-quote', 'new-estimate', 'new-pipeline'];
        }
        if (str_contains($title, 'project')) {
            return ['new-project', 'new-task', 'new-quote'];
        }
        if (str_contains($title, 'task')) {
            return ['new-task', 'new-project'];
        }
        if (str_contains($title, 'calendar') || $surface === 'crew') {
            return ['new-calendar-event', 'new-task'];
        }
        if ($surface === 'work') {
            return ['new-project', 'new-task', 'new-calendar-event'];
        }
        if (str_contains($title, 'quote') || str_contains($title, 'estimate')) {
            return ['new-quote', 'new-estimate', 'new-invoice'];
        }
        if ($surface === 'money' || str_contains($title, 'invoice') || str_contains($title, 'money') || str_contains($title, 'payment') || str_contains($title, 'bookkeep')) {
            return ['new-invoice', 'new-quote', 'new-estimate'];
        }
        if (str_contains($title, 'integration')) {
            return ['new-api-key', 'new-webhook', 'new-automation'];
        }
        if ($surface === 'automate' || str_contains($title, 'automation')) {
            return ['new-automation', 'new-api-key', 'new-webhook'];
        }
        if (str_contains($title, 'field') || str_contains($title, 'tag')) {
            return ['new-custom-field', 'new-tag'];
        }
        if ($surface === 'settings') {
            return ['new-custom-field', 'new-tag'];
        }

        return [];
    }

    /** @return list<string> */
    private function recordKeys(string $recordType): array
    {
        return match ($recordType) {
            'customer', 'company' => ['new-quote', 'new-invoice', 'new-contact'],
            'contact' => ['new-quote', 'new-invoice'],
            'job', 'work_order' => ['new-quote', 'new-invoice'],
            'lead' => ['new-opportunity', 'new-quote', 'new-task'],
            'opportunity', 'deal' => ['new-quote', 'new-estimate', 'new-task'],
            'invoice' => ['new-invoice', 'new-quote'],
            'quote', 'estimate' => ['new-invoice', 'new-quote'],
            default => [],
        };
    }

    /** @param array<string,mixed> $context @return array<string,mixed>|null */
    private function action(int $userId, string $key, array $context): ?array
    {
        if (! $this->journeys->has($key)) return null;
        $journey = $this->journeys->get($key);
        $definition = $this->capabilities->definitions()[$journey['capability']] ?? null;
        if (! is_array($definition)) return null;
        $permission = (string) ($definition['permission'] ?? '');
        if ($permission === '' || ! $this->permissions->allows($userId, $permission)) return null;

        $defaults = (array) (($journey['metadata']['defaults'] ?? []));
        $prefill = array_merge($defaults, $context);

        return [
            'journey' => $journey['key'],
            'label' => $journey['newLabel'],
            'capability' => $journey['capability'],
            'permission' => $permission,
            'prefill' => $prefill,
        ];
    }
}
