<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$route = file_get_contents($root.'/routes/api.php');
if ($route === false) {
    fwrite(STDERR, "FAIL unable to read routes/api.php\n");
    exit(1);
}

$checks = [
    'route file must not define a closure-scoped $rate helper' => !str_contains($route, '$rate ='),
    'upload middleware must be directly resolvable during route boot' => str_contains($route, "EnforceCompanyRateLimit::class.':upload'"),
    'send middleware must be directly resolvable during route boot' => str_contains($route, "EnforceCompanyRateLimit::class.':send'"),
    'admin middleware must be directly resolvable during route boot' => str_contains($route, "EnforceCompanyRateLimit::class.':admin'"),
    'voice middleware must be directly resolvable during route boot' => str_contains($route, "EnforceCompanyRateLimit::class.':voice'"),
    'ai middleware must be directly resolvable during route boot' => str_contains($route, "EnforceCompanyRateLimit::class.':ai'"),
];

$failed = [];
foreach ($checks as $name => $ok) {
    if (!$ok) {
        $failed[] = $name;
    }
}

if ($failed !== []) {
    foreach ($failed as $name) {
        fwrite(STDERR, "FAIL {$name}\n");
    }
    exit(1);
}

echo 'OK Titan Connect route boot scope regression: '.count($checks)." passed.\n";
