<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Services\{CrmAnalyticsService, CrmDashboardService, CrmTimelineService};
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class ReportController extends Controller
{
    public function __construct(private CrmDashboardService $dashboard, private CrmTimelineService $timeline, private CrmAnalyticsService $analytics) {}
    public function dashboard(Request $request) { return response()->json(['data' => $this->dashboard->summary((int) $request->user()->id)]); }
    public function analytics(Request $request) { return response()->json(['data' => $this->analytics->snapshot((int) $request->user()->id)]); }
    public function timeline(Request $request, string $subjectType, string $subjectPublicId) { return response()->json(['data' => $this->timeline->forSubject((int) $request->user()->id, $subjectType, $subjectPublicId, (int) $request->integer('limit', 100))]); }
}
