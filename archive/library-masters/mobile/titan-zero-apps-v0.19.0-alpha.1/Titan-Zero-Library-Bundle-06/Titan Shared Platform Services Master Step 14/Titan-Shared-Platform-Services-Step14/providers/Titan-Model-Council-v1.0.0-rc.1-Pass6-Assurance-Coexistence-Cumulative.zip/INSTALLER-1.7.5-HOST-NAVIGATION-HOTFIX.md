# Installer 1.7.5 Host Navigation Hotfix 4

## Live-host symptom

Titan Model Council installed successfully but produced no visible dashboard or Super Admin menu links.

## Root cause

The Blueprint sidecar declared `navigation.user` and `navigation.admin`, and the routes/views were present, but the active service provider never registered those declarations with MagicAI/Website1408's runtime navigation system. The host's proven compatibility surface is the database-backed `menus` table plus `App\Services\Common\MenuService::regenerate()`, with newer hosts optionally exposing contribution registries.

## Fix

- Added `System/Navigation/ModelCouncilNavigation.php` with distinct tenant-user and Super Admin definitions.
- Added `System/Navigation/HostNavigationRegistrar.php` that registers modern contributions and idempotently self-heals the host `menus` table.
- Added a narrow Eloquent `HostMenuRecord` compatibility model so active Council system code does not use raw database table access.
- Added migration `2026_08_20_000013_register_model_council_host_navigation.php` so upgrading an already-installed Council immediately creates/repairs both menu rows and regenerates the menu cache.
- Added provider boot self-heal so later host/menu changes are repaired without requiring a new migration.
- Added uninstall cleanup for the two Council-owned navigation keys.

## Menu keys

| Surface | Key | Route |
|---|---|---|
| Tenant user | `titan_model_council` | `dashboard.user.titan.model.council.index` |
| Super Admin | `titan_model_council_admin` | `dashboard.admin.titan.model.council.index` |

Navigation registration is fail-open: an unavailable host menu surface cannot prevent Model Council from booting.
