<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('crm_read_projection_state')) {
            Schema::table('crm_read_projection_state', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_read_projection_state','schema_version')) $t->unsignedInteger('schema_version')->default(1)->after('projection_version');
                if (! Schema::hasColumn('crm_read_projection_state','definition_hash')) $t->char('definition_hash',64)->nullable()->after('schema_version');
                if (! Schema::hasColumn('crm_read_projection_state','checkpoint_cursor')) $t->unsignedBigInteger('checkpoint_cursor')->default(0)->after('record_count');
                if (! Schema::hasColumn('crm_read_projection_state','last_projected_at')) $t->dateTime('last_projected_at')->nullable()->after('source_max_updated_at');
                if (! Schema::hasColumn('crm_read_projection_state','lag_seconds')) $t->unsignedInteger('lag_seconds')->default(0)->after('last_projected_at');
                if (! Schema::hasColumn('crm_read_projection_state','freshness_sla_seconds')) $t->unsignedInteger('freshness_sla_seconds')->default(300)->after('lag_seconds');
            });
        }

        if (! Schema::hasTable('crm_read_projection_dead_letters')) {
            Schema::create('crm_read_projection_dead_letters', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id',26)->unique();
                $t->unsignedBigInteger('tenant_company_id')->index();
                $t->char('signal_public_id',26)->nullable()->index();
                $t->string('projection_name',80)->nullable();
                $t->string('projection_version',20)->nullable();
                $t->json('event_payload');
                $t->string('error_class',255)->nullable();
                $t->text('last_error');
                $t->unsignedInteger('attempt_count')->default(1);
                $t->boolean('retryable')->default(true)->index();
                $t->dateTime('next_retry_at')->nullable()->index();
                $t->dateTime('resolved_at')->nullable()->index();
                $t->timestamps();
                $t->unique(['tenant_company_id','signal_public_id','projection_name'],'crm_proj_dead_tenant_signal_uq');
                $t->index(['retryable','resolved_at','next_retry_at'],'crm_proj_dead_due_idx');
            });
        }

        if (! Schema::hasTable('crm_read_projection_rebuild_checkpoints')) {
            Schema::create('crm_read_projection_rebuild_checkpoints', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id',26)->unique();
                $t->unsignedBigInteger('tenant_company_id')->index();
                $t->string('projection_name',80);
                $t->string('projection_version',20);
                $t->unsignedBigInteger('checkpoint_cursor')->default(0);
                $t->unsignedInteger('batch_size')->default(500);
                $t->unsignedBigInteger('processed_count')->default(0);
                $t->string('status',24)->default('in_progress')->index();
                $t->dateTime('started_at')->nullable();
                $t->dateTime('completed_at')->nullable();
                $t->text('last_error')->nullable();
                $t->timestamps();
                $t->unique(['tenant_company_id','projection_name','projection_version'],'crm_proj_rebuild_checkpoint_uq');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('crm_read_projection_rebuild_checkpoints');
        Schema::dropIfExists('crm_read_projection_dead_letters');
        if (Schema::hasTable('crm_read_projection_state')) {
            Schema::table('crm_read_projection_state', function (Blueprint $t): void {
                foreach (['schema_version','definition_hash','checkpoint_cursor','last_projected_at','lag_seconds','freshness_sla_seconds'] as $column) {
                    if (Schema::hasColumn('crm_read_projection_state',$column)) $t->dropColumn($column);
                }
            });
        }
    }
};
