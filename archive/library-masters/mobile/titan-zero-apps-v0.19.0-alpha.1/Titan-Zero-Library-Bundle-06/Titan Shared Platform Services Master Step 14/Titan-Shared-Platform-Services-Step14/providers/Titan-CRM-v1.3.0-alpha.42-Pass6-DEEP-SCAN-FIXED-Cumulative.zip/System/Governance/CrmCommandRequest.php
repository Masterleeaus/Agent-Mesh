<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

use App\Extensions\Crm\System\Tenancy\CrmCompanyContext;
use Illuminate\Support\Str;

final readonly class CrmCommandRequest
{
    public function __construct(
        public int $contractVersion,
        public string $commandId,
        public string $capability,
        public array $input,
        public int $companyId,
        public ?int $actorUserId,
        public string $actorType,
        public string $source,
        public string $traceId,
        public string $correlationId,
        public ?string $causationId,
        public string $idempotencyKey,
        public ?int $expectedEntityVersion,
    ) {}

    public static function fromContext(string $capability,array $input,CrmCompanyContext $context,string $source): self
    {
        $idempotencyKey=trim((string)($input['idempotency_key']??$input['_context']['idempotency_key']??''));
        if($idempotencyKey==='')$idempotencyKey=(string)Str::uuid();
        $traceId=self::boundedId((string)($input['_context']['trace_id']??'')) ?: ($context->traceId!==''?$context->traceId:($context->correlationId!==''?$context->correlationId:(string)Str::uuid()));
        $correlationId=self::boundedId((string)($input['_context']['correlation_id']??'')) ?: ($context->correlationId!==''?$context->correlationId:(string)Str::uuid());
        $causationId=self::boundedId((string)($input['_context']['causation_id']??'')) ?: $context->causationId;
        $commandId=self::boundedId((string)($input['_context']['command_id']??$input['command_id']??''));
        if($commandId==='')$commandId=(string)Str::uuid();
        $expected=$input['expected_entity_version']??$input['expected_version']??$input['_context']['expected_entity_version']??$input['_context']['expected_version']??null;
        $expected=is_numeric($expected)&&((int)$expected)>0?(int)$expected:null;
        $contractVersion=(int)($input['_context']['command_contract_version']??$input['command_contract_version']??CrmCommandContract::VERSION);
        if($contractVersion<CrmCommandContract::VERSION)$contractVersion=CrmCommandContract::VERSION;

        return new self(
            contractVersion:$contractVersion,
            commandId:$commandId,
            capability:$capability,
            input:$input+['idempotency_key'=>$idempotencyKey],
            companyId:$context->companyId,
            actorUserId:$context->actorUserId,
            actorType:$context->actorType,
            source:$source,
            traceId:$traceId,
            correlationId:$correlationId,
            causationId:$causationId,
            idempotencyKey:$idempotencyKey,
            expectedEntityVersion:$expected,
        );
    }


    private static function boundedId(string $value): string
    {
        $value=trim($value);
        if($value==='')return '';
        return substr($value,0,80);
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'command_contract_version'=>$this->contractVersion,
            'command_id'=>$this->commandId,
            'capability'=>$this->capability,
            'input'=>$this->input,
            'company_id'=>$this->companyId,
            'actor_user_id'=>$this->actorUserId,
            'actor_type'=>$this->actorType,
            'source'=>$this->source,
            'trace_id'=>$this->traceId,
            'correlation_id'=>$this->correlationId,
            'causation_id'=>$this->causationId,
            'idempotency_key'=>$this->idempotencyKey,
            'expected_entity_version'=>$this->expectedEntityVersion,
        ];
    }
}
