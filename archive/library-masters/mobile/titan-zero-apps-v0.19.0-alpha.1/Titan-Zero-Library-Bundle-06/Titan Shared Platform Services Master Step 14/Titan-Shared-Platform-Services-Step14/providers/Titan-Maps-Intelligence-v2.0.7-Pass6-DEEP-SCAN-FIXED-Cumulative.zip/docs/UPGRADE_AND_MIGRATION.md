# Upgrade and Migration Guide

## Versioning

Use semantic extension versions. Database migrations are append-only. Never edit a migration already applied to customer databases.

## Provider additions

A new provider should add an adapter, company connection configuration, capability declaration, normaliser tests, terms checklist, and usage mapping. Existing canonical records should not be rewritten merely because a provider is added.

## Schema changes

- add nullable columns first
- backfill through company-scoped queue jobs
- add constraints only after verification
- preserve field observations and promotion lineage
- target the verified Titan Zero host baseline: MySQL on Laravel 10.50.x

## Replacing host adapters

Adapters may change internally if their contracts remain stable. During migration, verify active-company enforcement and compare WorkCore command/event output before enabling the new adapter.

## Removing a provider

Disable company connections, allow queued runs to reach a terminal state, retain permitted lineage, apply provider retention rules, and remove the registry factory in a later version.

## Pass 2 legacy/manual table handling

The Pass 2 create migrations are schema-idempotent: if an owned table already exists, that table is retained rather than dropped or recreated. This protects pre-v2 data, but it also means an incompatible hand-created schema is not silently rewritten. Before migrating a database that already contains any Maps-owned table:

1. take a database backup;
2. compare existing columns with `database/schema-contract.json`;
3. ensure parent tables used by tenant-scoped foreign keys have the required `(company_id, id)` unique key;
4. reconcile any mismatch in a reviewed, company-safe migration before running the remaining extension migrations;
5. never repair a mismatch by dropping customer data during package install.

Clean installs require no reconciliation.
