<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\Tests\Architecture;

use PHPUnit\Framework\TestCase;

final class BoundaryTest extends TestCase
{
    public function test_core_does_not_claim_domain_mutation_ownership(): void
    {
        $manifest = json_decode((string) file_get_contents(__DIR__ . '/../../extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
        self::assertNotContains('command.execute', $manifest['capabilities'] ?? []);
        self::assertNotContains('risk.assess', $manifest['capabilities'] ?? []);
        self::assertNotContains('signal.ingest', $manifest['capabilities'] ?? []);
    }
}
