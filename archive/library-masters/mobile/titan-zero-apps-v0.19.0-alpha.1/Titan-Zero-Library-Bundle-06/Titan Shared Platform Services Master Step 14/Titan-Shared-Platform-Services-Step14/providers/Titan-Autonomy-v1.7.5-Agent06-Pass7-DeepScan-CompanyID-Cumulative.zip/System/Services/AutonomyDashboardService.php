<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;

final class AutonomyDashboardService
{
    public function __construct(private readonly AutonomyQueryContract $query, private readonly HostBridgeStatusService $bridges) {}

    public function tenantOverview(int $tenantCompanyId): array
    {
        $states = $this->query->capabilityStates($tenantCompanyId);
        $totals = ['capabilities' => count($states), 'eligible' => 0, 'trusted_auto' => 0, 'regressions' => 0];
        foreach ($states as $state) {
            if ((bool) ($state['platform_gate_eligible'] ?? false)) $totals['eligible']++;
            if (($state['current_level'] ?? null) === 'trusted_auto') $totals['trusted_auto']++;
        }
        $totals['regressions'] = count($this->query->regressions($tenantCompanyId, limit: 1000));
        return [
            'totals' => $totals,
            'states' => $states,
            'learning_settings' => $this->query->learningSettings($tenantCompanyId),
            'bridges' => $this->bridges->status(),
        ];
    }
}
