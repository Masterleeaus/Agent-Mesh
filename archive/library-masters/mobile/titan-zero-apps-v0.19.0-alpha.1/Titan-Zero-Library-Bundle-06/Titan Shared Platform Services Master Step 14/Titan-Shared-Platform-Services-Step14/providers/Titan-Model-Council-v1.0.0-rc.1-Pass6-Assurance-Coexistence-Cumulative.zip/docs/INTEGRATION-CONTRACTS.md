# Integration Contracts

## Required canonical dependency: Titan Signal
Blueprint key: `titan-signal >=1.0`.

Current runtime compatibility additionally supports Titan Signal Engine v0.20 (`titan-signal-engine`) via:

- `SignalEmitterContract::emit(SignalEnvelope|array, SignalContext)`
- `SignalEmitterAuthorityContract::issue('titan-model-council')`
- trusted `SignalContext::tenantHuman(...)`

Council registers its trusted emitter/event definitions through runtime configuration only. It does not write Signal-owned registry tables directly.

**Transition note:** Blueprint and the currently shipped Signal RC use different package identities. The runtime bridge is compatible, but installer identity convergence is required before canonical production promotion.

## Optional: Titan Risk Engine
Council calls the published Risk assessment contract before and after deliberation. Risk decisions establish a minimum Council depth and authority floor. Manual Council settings cannot weaken `REQUIRE_ASSURANCE`, `REQUIRE_APPROVAL`, `REDUCE_AUTHORITY`, or `BLOCK`.

## Optional: Titan Shield v0.5+
Preferred path: `ShieldManagerContract::evaluateInspection()` with tenant + complete causal context. Council preserves older `InspectionEngineContract` compatibility. Local structural validation is never represented as external factual verification.

## Optional: Titan Assurance v2.2+
Council uses `EvidenceAssuranceEngine::assess(array)` when available. Evidence contains model/output hashes and final-output hashes rather than hidden reasoning. Required Assurance is fail-closed to escalation when unavailable, failed, or non-GREEN.

## Optional: Titan AI Core
Council owns no fake provider API. `GovernedProviderRuntimeContract` is the stable boundary. AI Core becomes provider/billing authority only after an executable published contract is configured and available; otherwise explicit legacy provider compatibility remains active.

## Rewind receipt boundary
Council owns `titan_model_council_receipts`. The receipt is canonicalized and SHA-256 hashed and contains tenant/causal identity, strategy, authority, risk/Assurance/Shield/billing summaries and participant output hashes. Direct Rewind writes are intentionally absent until a verified public Rewind write contract is available.

## Legacy AI Chat compatibility
The shared `user_openai_chat_messages` write remains an explicit versioned compatibility contract only, with tenant/user/chat ownership scope. Model Council does not claim ownership of the host chat domain.
