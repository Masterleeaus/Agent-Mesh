<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

use App\Extensions\TitanConnect\System\DTO\NormalizedDeliveryReceipt;
use App\Extensions\TitanConnect\System\DTO\NormalizedInboundMessage;
use App\Extensions\TitanConnect\System\DTO\ProviderSendResult;
use App\Extensions\TitanConnect\System\DTO\ProviderMediaDescriptor;

interface MessagingProvider
{
    public function key(): string;
    public function capabilities(): array;
    public function supportsInbound(): bool;
    public function supportsOutbound(): bool;
    public function verifyWebhook(array $headers, string $body, array $credentials): bool;
    public function verifyWebhookChallenge(array $query, array $credentials): ?string;
    /** @return array<int,array<string,mixed>> */
    public function splitWebhookPayload(array $payload): array;
    public function normalizeInbound(array $payload, array $headers = []): NormalizedInboundMessage;
    public function normalizeDeliveryReceipt(array $payload): NormalizedDeliveryReceipt;
    public function resolveInboundMedia(array $attachment, array $credentials): ?ProviderMediaDescriptor;
    public function send(array $message, array $credentials): ProviderSendResult;
    public function health(array $credentials): array;
}
