<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalPulseProjectorContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalSeverity;
use App\Extensions\TitanSignalEngine\System\Data\CommandReceiptPairing;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseProjectedEvent;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseRollup;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseTraceMetric;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseTraceEventCount;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseCausationRef;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseProjectionFreshness;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseCommandReceipt;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class PulseProjector implements SignalPulseProjectorContract
{
    public function project(SignalEvent $event): bool
    {
        $this->observeIngestionFreshness($event);
        return DB::transaction(function () use ($event): bool {
            $recorded = $this->date($event->recorded_at);
            $inserted = DB::table('titan_signal_pulse_projected_events')->insertOrIgnore([
                'event_id' => (string) $event->event_id,
                'recorded_at' => $recorded->format('Y-m-d H:i:s'),
                'projected_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            if ($inserted === 0) {
                return false;
            }

            $occurred = $this->date($event->occurred_at);
            foreach (['minute', 'hour', 'day'] as $granularity) {
                $bucket = $this->bucketStart($occurred, $granularity);
                foreach ($this->dimensions($event) as [$dimension, $value]) {
                    $this->updateRollup($event, $granularity, $bucket, $dimension, $value, $occurred);
                }
            }
            $this->updateTraceMetric($event, $occurred, $recorded);
            $this->updateTraceEventCount($event, $occurred);
            $this->updateCausationProjection($event, $occurred);
            $this->updateProjectionFreshness($event, $recorded);
            $this->updateCommandReceiptProjection($event, $occurred);

            return true;
        });
    }

    public function catchUp(int $limit = 1000): array
    {
        $limit = max(1, min($limit, (int) config('titan-signal-engine.pulse_catchup_limit', 5000)));
        $events = SignalEvent::query()
            ->whereNotExists(function ($query): void {
                $query->selectRaw('1')->from('titan_signal_pulse_projected_events as pulse_projected')
                    ->whereColumn('pulse_projected.event_id', 'titan_signal_events.event_id');
            })
            ->orderBy('id')
            ->limit($limit)
            ->cursor();

        $result = ['scanned' => 0, 'projected' => 0, 'skipped' => 0, 'failed' => 0];
        foreach ($events as $event) {
            $result['scanned']++;
            try {
                $this->project($event) ? $result['projected']++ : $result['skipped']++;
            } catch (Throwable) {
                $result['failed']++;
            }
        }
        return $result;
    }

    /** @return list<array{0:string,1:string}> */
    private function dimensions(SignalEvent $event): array
    {
        $rows = [
            ['all', '__all__'],
            ['source', (string) ($event->source ?: 'unknown')],
            ['event_type', (string) $event->event_type],
            ['category', (string) ($event->category ?: 'uncategorized')],
            ['severity', (string) ($event->severity ?: 'info')],
        ];
        if ($event->vertical_key !== null && $event->vertical_key !== '') {
            $rows[] = ['vertical', (string) $event->vertical_key];
        }
        return $rows;
    }

    private function updateRollup(SignalEvent $event, string $granularity, DateTimeImmutable $bucket, string $dimension, string $value, DateTimeImmutable $occurred): void
    {
        $tenantKey = (int) ($event->tenant_company_id ?? 0);
        $criteria = [
            'granularity' => $granularity,
            'bucket_start' => $bucket->format('Y-m-d H:i:s'),
            'scope' => (string) $event->scope,
            'tenant_key' => $tenantKey,
            'dimension' => $dimension,
            'dimension_value' => $value,
        ];
        DB::table('titan_signal_pulse_rollups')->insertOrIgnore(array_merge($criteria, [
            'tenant_company_id' => $event->tenant_company_id,
            'event_count' => 0,
            'severity_weight_sum' => 0,
            'max_severity_weight' => 0,
            'error_count' => 0,
            'critical_count' => 0,
            'command_count' => 0,
            'risk_count' => 0,
            'governance_count' => 0,
            'assurance_count' => 0,
            'autonomy_count' => 0,
            'subscription_failure_count' => 0,
            'first_event_at' => $occurred->format('Y-m-d H:i:s'),
            'last_event_at' => $occurred->format('Y-m-d H:i:s'),
            'created_at' => now(),
            'updated_at' => now(),
        ]));

        $row = SignalPulseRollup::query()->where($criteria)->lockForUpdate()->firstOrFail();
        $weight = SignalSeverity::fromName((string) ($event->severity ?: 'info'))->weight();
        $row->event_count++;
        $row->severity_weight_sum += $weight;
        $row->max_severity_weight = max((int) $row->max_severity_weight, $weight);
        $row->error_count += $weight >= SignalSeverity::ERROR->weight() ? 1 : 0;
        $row->critical_count += $weight >= SignalSeverity::CRITICAL->weight() ? 1 : 0;
        $type = (string) $event->event_type;
        $category = (string) ($event->category ?: '');
        $row->command_count += str_starts_with($type, 'command.') ? 1 : 0;
        $row->risk_count += ($category === 'risk' || str_starts_with($type, 'risk.')) ? 1 : 0;
        $row->governance_count += ($category === 'governance' || str_starts_with($type, 'governance.')) ? 1 : 0;
        $row->assurance_count += (in_array($category, ['assurance', 'quality', 'compliance'], true) || str_starts_with($type, 'shield.')) ? 1 : 0;
        $row->autonomy_count += ($category === 'autonomy' || str_starts_with($type, 'autonomy.')) ? 1 : 0;
        $row->subscription_failure_count += $type === 'signal.subscription.failed' ? 1 : 0;
        $first = $this->date($row->first_event_at);
        $last = $this->date($row->last_event_at);
        $row->first_event_at = $occurred < $first ? $occurred : $first;
        $row->last_event_at = $occurred > $last ? $occurred : $last;
        $row->save();
    }

    private function updateTraceMetric(SignalEvent $event, DateTimeImmutable $occurred, DateTimeImmutable $recorded): void
    {
        $tenantKey = (int) ($event->tenant_company_id ?? 0);
        $criteria = ['trace_id' => (string) $event->trace_id, 'scope' => (string) $event->scope, 'tenant_key' => $tenantKey];
        DB::table('titan_signal_pulse_trace_metrics')->insertOrIgnore(array_merge($criteria, [
            'correlation_id' => (string) $event->correlation_id,
            'root_causation_id' => $event->root_causation_id,
            'tenant_company_id' => $event->tenant_company_id,
            'first_occurred_at' => $occurred->format('Y-m-d H:i:s'),
            'last_occurred_at' => $occurred->format('Y-m-d H:i:s'),
            'first_recorded_at' => $recorded->format('Y-m-d H:i:s'),
            'last_recorded_at' => $recorded->format('Y-m-d H:i:s'),
            'event_count' => 0,
            'max_severity_weight' => 0,
            'duration_ms' => 0,
            'last_event_type' => (string) $event->event_type,
            'terminal_seen' => false,
            'created_at' => now(),
            'updated_at' => now(),
        ]));
        $row = SignalPulseTraceMetric::query()->where($criteria)->lockForUpdate()->firstOrFail();
        $row->event_count++;
        $row->max_severity_weight = max((int) $row->max_severity_weight, SignalSeverity::fromName((string) ($event->severity ?: 'info'))->weight());

        $firstOccurred = $this->date($row->first_occurred_at);
        $lastOccurred = $this->date($row->last_occurred_at);
        if ($occurred < $firstOccurred) {
            $row->first_occurred_at = $occurred;
            $firstOccurred = $occurred;
        }
        if ($occurred >= $lastOccurred) {
            $row->last_occurred_at = $occurred;
            $row->last_event_type = (string) $event->event_type;
            $lastOccurred = $occurred;
        }
        $firstRecorded = $this->date($row->first_recorded_at);
        $lastRecorded = $this->date($row->last_recorded_at);
        if ($recorded < $firstRecorded) {
            $row->first_recorded_at = $recorded;
        }
        if ($recorded > $lastRecorded) {
            $row->last_recorded_at = $recorded;
        }
        $row->duration_ms = max(0, (int) round(($lastOccurred->format('U.u') - $firstOccurred->format('U.u')) * 1000));

        $type = (string) $event->event_type;
        if ($type === 'command.executed') {
            $row->command_executed_at = $occurred;
        }
        if ($type === 'execution.receipt') {
            $row->execution_receipt_at = $occurred;
        }
        if ($row->command_executed_at !== null && $row->execution_receipt_at !== null) {
            $commandAt = $this->date($row->command_executed_at);
            $receiptAt = $this->date($row->execution_receipt_at);
            $row->command_latency_ms = max(0, (int) round(($receiptAt->format('U.u') - $commandAt->format('U.u')) * 1000));
        }
        $terminalTypes = (array) config('titan-signal-engine.pulse_terminal_event_types', ['execution.receipt']);
        if (in_array($type, $terminalTypes, true)) {
            $row->terminal_seen = true;
        }
        $row->save();
    }

    private function updateTraceEventCount(SignalEvent $event, DateTimeImmutable $occurred): void
    {
        if (! Schema::hasTable('titan_signal_pulse_trace_event_counts')) {
            return;
        }
        $tenantKey = (int) ($event->tenant_company_id ?? 0);
        $criteria = [
            'trace_id' => (string) $event->trace_id,
            'event_type' => (string) $event->event_type,
            'scope' => (string) $event->scope,
            'tenant_key' => $tenantKey,
        ];
        DB::table('titan_signal_pulse_trace_event_counts')->insertOrIgnore(array_merge($criteria, [
            'tenant_company_id' => $event->tenant_company_id,
            'event_count' => 0,
            'first_occurred_at' => $occurred->format('Y-m-d H:i:s'),
            'last_occurred_at' => $occurred->format('Y-m-d H:i:s'),
            'created_at' => now(),
            'updated_at' => now(),
        ]));
        $row = SignalPulseTraceEventCount::query()->where($criteria)->lockForUpdate()->firstOrFail();
        $row->event_count++;
        $first = $this->date($row->first_occurred_at);
        $last = $this->date($row->last_occurred_at);
        $row->first_occurred_at = $occurred < $first ? $occurred : $first;
        $row->last_occurred_at = $occurred > $last ? $occurred : $last;
        $row->save();
    }

    private function updateCausationProjection(SignalEvent $event, DateTimeImmutable $occurred): void
    {
        if (! Schema::hasTable('titan_signal_pulse_causation_refs')) {
            return;
        }

        if ($event->causation_id !== null) {
            $resolved = Schema::hasTable('titan_signal_causal_edges') && DB::table('titan_signal_causal_edges')
                ->where('child_event_id', (string) $event->event_id)
                ->where('parent_event_id', (string) $event->causation_id)
                ->exists();
            SignalPulseCausationRef::query()->updateOrCreate(
                ['child_event_id' => (string) $event->event_id],
                [
                    'parent_event_id' => (string) $event->causation_id,
                    'trace_id' => (string) $event->trace_id,
                    'scope' => (string) $event->scope,
                    'tenant_company_id' => $event->tenant_company_id,
                    'tenant_key' => (int) ($event->tenant_company_id ?? 0),
                    'resolved' => $resolved,
                    'occurred_at' => $occurred,
                    'resolved_at' => $resolved ? now() : null,
                ],
            );
        }

        $chunk = max(50, min((int) config('titan-signal-engine.causation_repair_chunk', 500), 2000));
        SignalPulseCausationRef::query()->where('parent_event_id', (string) $event->event_id)->where('resolved', false)->orderBy('id')->chunkById($chunk, function ($waitingRows) use ($event): void {
            foreach ($waitingRows as $waiting) {
                $resolved = Schema::hasTable('titan_signal_causal_edges') && DB::table('titan_signal_causal_edges')
                    ->where('child_event_id', (string) $waiting->child_event_id)
                    ->where('parent_event_id', (string) $event->event_id)
                    ->exists();
                if ($resolved) {
                    $waiting->resolved = true;
                    $waiting->resolved_at = now();
                    $waiting->save();
                }
            }
        });
    }

    private function observeIngestionFreshness(SignalEvent $event): void
    {
        if (! Schema::hasTable('titan_signal_pulse_projection_freshness')) return;
        $recorded = $this->date($event->recorded_at);
        $tenantKey = (int) ($event->tenant_company_id ?? 0);
        $keys = [
            ['platform', 0, null, 'all', '__all__'],
            [(string) $event->scope, $tenantKey, $event->tenant_company_id, 'all', '__all__'],
            [(string) $event->scope, $tenantKey, $event->tenant_company_id, 'source', (string) ($event->source ?: 'unknown')],
        ];
        if ($event->source_component !== null && $event->source_component !== '') $keys[] = [(string) $event->scope, $tenantKey, $event->tenant_company_id, 'source_component', (string) $event->source_component];
        foreach ($keys as [$scope, $key, $tenantId, $dimension, $value]) {
            $criteria = ['scope' => $scope, 'tenant_key' => $key, 'dimension' => $dimension, 'dimension_value' => $value];
            DB::table('titan_signal_pulse_projection_freshness')->insertOrIgnore(array_merge($criteria, [
                'tenant_company_id' => $tenantId,
                'last_ingested_event_id' => (string) $event->event_id,
                'last_ingested_recorded_at' => $recorded->format('Y-m-d H:i:s'),
                'projected_count' => 0, 'created_at' => now(), 'updated_at' => now(),
            ]));
            $row = SignalPulseProjectionFreshness::query()->where($criteria)->firstOrFail();
            $last = $row->last_ingested_recorded_at === null ? null : $this->date($row->last_ingested_recorded_at);
            if ($last === null || $recorded >= $last) {
                $row->last_ingested_event_id = (string) $event->event_id;
                $row->last_ingested_recorded_at = $recorded;
                $row->save();
            }
        }
    }

    private function updateProjectionFreshness(SignalEvent $event, DateTimeImmutable $recorded): void
    {
        if (! Schema::hasTable('titan_signal_pulse_projection_freshness')) return;
        $projectedAt = now();
        $tenantKey = (int) ($event->tenant_company_id ?? 0);
        $keys = [
            ['platform', 0, null, 'all', '__all__'],
            [(string) $event->scope, $tenantKey, $event->tenant_company_id, 'all', '__all__'],
            [(string) $event->scope, $tenantKey, $event->tenant_company_id, 'source', (string) ($event->source ?: 'unknown')],
        ];
        if ($event->source_component !== null && $event->source_component !== '') {
            $keys[] = [(string) $event->scope, $tenantKey, $event->tenant_company_id, 'source_component', (string) $event->source_component];
        }
        foreach ($keys as [$scope, $key, $tenantId, $dimension, $value]) {
            $criteria = ['scope' => $scope, 'tenant_key' => $key, 'dimension' => $dimension, 'dimension_value' => $value];
            DB::table('titan_signal_pulse_projection_freshness')->insertOrIgnore(array_merge($criteria, [
                'tenant_company_id' => $tenantId, 'last_event_id' => (string) $event->event_id,
                'last_recorded_at' => $recorded->format('Y-m-d H:i:s'), 'last_projected_at' => $projectedAt,
                'last_ingested_event_id' => (string) $event->event_id, 'last_ingested_recorded_at' => $recorded->format('Y-m-d H:i:s'),
                'projected_count' => 0, 'created_at' => $projectedAt, 'updated_at' => $projectedAt,
            ]));
            $row = SignalPulseProjectionFreshness::query()->where($criteria)->lockForUpdate()->firstOrFail();
            $row->projected_count = (int) $row->projected_count + 1;
            $lastRecorded = $row->last_recorded_at === null ? null : $this->date($row->last_recorded_at);
            if ($lastRecorded === null || $recorded >= $lastRecorded) {
                $row->last_event_id = (string) $event->event_id;
                $row->last_recorded_at = $recorded;
            }
            $row->last_projected_at = $projectedAt;
            $row->save();
        }
    }

    private function updateCommandReceiptProjection(SignalEvent $event, DateTimeImmutable $occurred): void
    {
        if (! Schema::hasTable('titan_signal_pulse_command_receipts')) return;
        $type = (string) $event->event_type;
        $tenantKey = (int) ($event->tenant_company_id ?? 0);
        if ($type === 'command.executed') {
            $pair = SignalPulseCommandReceipt::query()->firstOrCreate(['command_event_id' => (string) $event->event_id], [
                'trace_id' => (string) $event->trace_id, 'correlation_id' => (string) $event->correlation_id,
                'scope' => (string) $event->scope, 'tenant_company_id' => $event->tenant_company_id, 'tenant_key' => $tenantKey,
                'source' => $event->source, 'source_component' => $event->source_component, 'command_occurred_at' => $occurred,
            ]);
            // Offline delivery can place the receipt in the hot store before the command.
            if ($pair->receipt_event_id === null) {
                $receipt = SignalEvent::query()->where('event_type', 'execution.receipt')->where('causation_id', (string) $event->event_id)
                    ->where('scope', (string) $event->scope)->where('tenant_company_id', $event->tenant_company_id)
                    ->orderBy('occurred_at')->first();
                if ($receipt !== null) {
                    $receiptAt = $this->date($receipt->occurred_at);
                    $paired = CommandReceiptPairing::pair((string) $event->event_id, $occurred, (string) $receipt->event_id, $receiptAt, 'direct_causation');
                    $pair->receipt_event_id = $paired['receipt_event_id'];
                    $pair->receipt_occurred_at = $receiptAt;
                    $pair->latency_ms = $paired['latency_ms'];
                    $pair->pairing_method = $paired['pairing_method'];
                    $pair->save();
                }
            }
            return;
        }
        if ($type !== 'execution.receipt') return;

        $query = SignalPulseCommandReceipt::query()->where('scope', (string) $event->scope)->where('tenant_key', $tenantKey)->whereNull('receipt_event_id');
        $pair = null;
        $method = null;
        if ($event->causation_id !== null) {
            $pair = (clone $query)->where('command_event_id', (string) $event->causation_id)->lockForUpdate()->first();
            if ($pair !== null) $method = 'direct_causation';
        }
        if ($pair === null) {
            $pair = (clone $query)->where('trace_id', (string) $event->trace_id)->where('command_occurred_at', '<=', $occurred)
                ->orderByDesc('command_occurred_at')->orderByDesc('id')->lockForUpdate()->first();
            if ($pair !== null) $method = 'trace_unmatched';
        }
        if ($pair === null || $method === null) return;
        $commandAt = $this->date($pair->command_occurred_at);
        $paired = CommandReceiptPairing::pair((string) $pair->command_event_id, $commandAt, (string) $event->event_id, $occurred, $method);
        $pair->receipt_event_id = $paired['receipt_event_id'];
        $pair->receipt_occurred_at = $occurred;
        $pair->latency_ms = $paired['latency_ms'];
        $pair->pairing_method = $paired['pairing_method'];
        $pair->save();
    }

    private function bucketStart(DateTimeImmutable $time, string $granularity): DateTimeImmutable
    {
        return match ($granularity) {
            'minute' => $time->setTime((int) $time->format('H'), (int) $time->format('i'), 0),
            'hour' => $time->setTime((int) $time->format('H'), 0, 0),
            'day' => $time->setTime(0, 0, 0),
        };
    }

    private function date(mixed $value): DateTimeImmutable
    {
        if ($value instanceof \DateTimeInterface) {
            return (new DateTimeImmutable($value->format(DATE_ATOM)))->setTimezone(new DateTimeZone('UTC'));
        }
        return (new DateTimeImmutable((string) $value))->setTimezone(new DateTimeZone('UTC'));
    }
}
