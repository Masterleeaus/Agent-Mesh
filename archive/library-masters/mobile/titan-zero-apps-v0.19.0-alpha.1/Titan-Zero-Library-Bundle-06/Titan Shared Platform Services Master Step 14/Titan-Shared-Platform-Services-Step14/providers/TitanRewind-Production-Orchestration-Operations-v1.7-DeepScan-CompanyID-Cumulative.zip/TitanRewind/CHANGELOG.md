## Persistent orchestration v1.5

- Added durable outbox, lease recovery, deduplication, retry/dead-letter/redrive, provider deferral and health telemetry for Workforce handoffs.


## Runtime hardening pass
- Added container-bound Workforce loop runtime with fail-closed provider health aggregation.
- Enforced canonical `company_id` plus full causal context on cross-extension handoffs.
- Added provider/version pinning and authority-neutral handoff envelopes.
- Enforced outcome lineage and execution receipts.
- Quarantined raw host-menu database access as legacy navigation compatibility only.

# Changelog


## 1.0.6 — MagicAI Host View & Full Navigation Hotfix

- Replaced unavailable `<x-layouts.app>` across all seven Rewind Blade views with the verified MagicAI `panel.layout.app` layout contract.
- Added a permanent host-view compatibility verifier covering all shipped Blade surfaces.
- Expanded user navigation from one parent link to seven child destinations: Overview, Traces, Cases, Replay Runs, Evidence Vault, Recovery Plans and Forensic Assistant.
- Added real catalogue routes for traces, cases, replay runs, evidence and recovery rather than invalid static detail links requiring UUIDs.
- Upgraded MagicAI `menus` table self-heal to resolve `parent_key` into the actual parent `menus.id`, preserving administrator order/enabled state.
- Preserved v1.0.5 host authorization bridge, v1.0.4 menu cache repair, v1.0.3 MySQL `DATETIME(6)` compatibility and all Pass 8 forensic/runtime boundaries.

## 1.0.5 — MagicAI Host Authorization Bridge Hotfix

- Fix live-host `403 Titan Rewind permission denied: rewind.trace.view` after successful install and menu self-heal.
- Respect MagicAI/Titan `isSuperAdmin()` as the host's direct platform-authority bypass.
- Accept explicit Rewind grants from `can()`, `checkPermission()` and `hasPermissionTo()` host APIs.
- Add a narrow delegated-admin compatibility fallback for trace view, forensics view and integrity verification only.
- Keep replay, evidence, recovery, legal-hold and Rewind admin permissions explicit for delegated admins.
- Preserve tenant/object isolation and ordinary-user fail-closed behaviour.
- Add a dedicated host authorization bridge regression gate.

## 1.0.4 — MagicAI/Titan Menu Self-Heal Hotfix

- Preserve modern `MenuContributionRegistry` / `ContributionRegistry` navigation contributions.
- Add idempotent fallback synchronisation into MagicAI's `menus` table for hosts without those registries.
- Repair missing/stale user menu route, label, icon and menu metadata without overwriting administrator-controlled order or disabled state.
- Synchronise Super Admin menu rows only when the host table exposes an `is_admin` discriminator, preventing admin-route leakage into shared user navigation.
- Regenerate `App\Services\Common\MenuService` caches only when a database menu row is created or repaired.
- Normalize contribution definitions to the host menu contract (`active_condition` array, `params`, `is_active`, `show_condition`, extension marker).
- No Rewind forensic, replay, evidence, governance, retention or migration semantics changed.

## 1.0.3 — MySQL Microsecond DATETIME Migration Hotfix

- Fix live Installer 1.7.8 MySQL error `1067 Invalid default value for checked_at`.
- Convert all custom precision-qualified Rewind migration timestamps from `TIMESTAMP(6)` to `DATETIME(6)`.
- Preserve microsecond precision while avoiding legacy MySQL TIMESTAMP implicit-default rules under strict SQL modes.
- Add a standalone migration compatibility gate forbidding precision-qualified TIMESTAMP columns in Rewind migrations.
- Keep standard Laravel `created_at` / `updated_at` columns unchanged.
- No Rewind forensic, replay, governance, evidence or retention semantics changed.


## 1.0.2 — Titan Installer 1.7.8 Integrity Hotfix

- Removed redundant `FILE-SHA256.json` from the installable ZIP after the live 1.7.8 verifier proved every non-manifest file must appear in `extension.json.integrity.files`.
- Regenerated the installer integrity map against the exact flat-root archive contents.
- Hardened the installer contract test to require `archive regular files - {extension.json} == integrity.files`.
- Preserved Blueprint v4.1 schema-v2 runtime profile and all Pass 8 Rewind behavior.

## 1.0.1 — Titan Installer 1.7.8 Hotfix

- Added root `titan-extension-v1` installer manifest with slug/folder/provider/migrations/dependency/platform metadata.
- Repacked release at a flat ZIP root instead of an outer `TitanRewind/` wrapper.
- Replaced the generic `extension` publish tag with `titan-rewind-config`.
- Added exact installer integrity map and independent package hash inventory.
- Preserved Blueprint v4.1 schema-v2 runtime profile in `extension.manifest.json`.
- No Rewind domain/runtime behavior changed by this packaging hotfix.

## 1.0.0 — Production Profile Candidate

- Activated Blueprint v4.1 manifest schema 2.0 and `runtime_profile: titan-rewind`.
- Eliminated Blueprint architecture scan warnings by converting whole-trace reads to bounded cursor/stream processing and reviewed model/connection paths.
- Added deterministic trace streaming/pagination, bounded reconstruction windows and streamed signed evidence downloads.
- Added virtual-clock/deterministic-seed replay certification, performance/fault/concurrency/DR gates, accessibility/localization structure and exact-host readiness command.
- Added SPDX SBOM, build provenance, public release verification key and external RSA-SHA256 package signing workflow.
- Package-level lifecycle verification passes; exact MagicAI/Titan host runtime/upgrade/uninstall certification remains explicitly `NOT_EXECUTED` until run in the target installation.

## 0.9.0 — Forensic Data Governance

- Added lazy Blueprint host-source discovery and strict tenant/trace normalization enforcement.
- Added source watermark freshness and authenticity requirements for audit completeness.
- Added host-tagged/direct historical artifact resolver integration plus encrypted canonical artifact archiving.
- Replaced the configured single signing key with a rotating RSA-SHA256 keyring while retaining historical public-key verification.
- Added signing-key lifecycle/fingerprint metadata without persisting private key material.
- Hardened legal holds with expiry/review validation and trace/case/evidence/tenant cascade during retention.
- Added configurable retention classes, scheduled one-server execution, resumable active-run cursors and bounded purge batches.
- Added atomic purge receipts and custody actions; evidence referenced by Governance receipts is protected from automated purge.
- Added Super Admin retention/signing-key operational visibility and machine-readable retention/purge/key schemas.
- Kept Blueprint schema v1 intentionally; final schema-v2 `titan-rewind` activation remains reserved for Pass 8 certification.

## 0.8.0 — Runtime Resilience & Observability

- Added independent liveness/readiness, runtime states, Signal outbox, structured telemetry, replay/Signal retry, dead-letter recovery, backpressure and persisted circuit breakers.
- Added Super Admin operational controls and Blueprint health/Signal contracts.
- Preserved pre-certification schema v1 until remaining production gates are proven.

## 0.7.0 — Blueprint v4.1 Prerequisites

- Added the ten canonical Titan Rewind permissions and fail-closed permission middleware.
- Added tenant/object authorization guards for forensic operations.
- Added RSA-SHA256 evidence signing and signature verification with configured key identity.
- Added evidence chain-of-custody journaling for generation, viewing, verification, download/export, supersession and legal-hold events.
- Added legal holds for traces, cases, evidence packages and tenant investigations, plus a purge guard.
- Added durable source watermarks and source-completeness aggregation with COMPLETE/PARTIAL/STALE/UNAVAILABLE states.
- Added current-state structural comparison while preserving the hard no-production-mutation replay boundary.
- Added Blueprint v4.1 Rewind capability/interchange schemas and production contract documentation.
- Preserved schema version 1.0 for this release intentionally; final schema-v2 `runtime_profile: titan-rewind` certification remains deferred until all Blueprint v4.1 production verification requirements are actually proven.

## 0.6.0 — Comparative Replay & Product Surface

- Added structural counterfactual, model, policy and knowledge comparisons.
- Added deterministic comparison hashes, historical-artifact resolution reporting, guided assistant surfaces and Rewind analytics.
- Enforced a rejecting replay command gateway and explicit `decision_reexecution_performed = false` semantics.

## 0.5.0 — Audit & Recovery

- Added signed-ready evidence package foundations, compliance export, recovery proposals and external Governance receipt handling.
- Kept authoritative execution outside Rewind and behind Governance + Command Bus boundaries.
