<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\ExecutionAuthorityDecision;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;

final class ExecutionAuthorityGuard
{
    public function __construct(private readonly ScopeEvaluator $scopeEvaluator = new ScopeEvaluator()) {}

    public function evaluate(
        CapabilityState $state,
        array $context,
        bool $actorPermissionValid,
        bool $interactionReady,
        bool $integrationHealthy,
        string $assuranceStatus,
        bool $explicitApprovalSatisfied = false,
        ?AutonomyLevel $maximumAllowedLevel = null,
    ): ExecutionAuthorityDecision {
        $reasons = [];

        if ($maximumAllowedLevel !== null && $state->currentLevel->value > $maximumAllowedLevel->value) {
            $reasons[] = 'POLICY_CEILING_EXCEEDED';
        }

        if ($state->currentLevel === AutonomyLevel::Suggest) {
            $reasons[] = 'LEVEL_CANNOT_EXECUTE';
        }
        if ($state->currentLevel === AutonomyLevel::Assist && !$explicitApprovalSatisfied) {
            $reasons[] = 'EXPLICIT_APPROVAL_REQUIRED';
        }
        if (!$actorPermissionValid) {
            $reasons[] = 'PERMISSIONS_INVALID';
        }
        if (!$interactionReady) {
            $reasons[] = 'INTERACTION_ENGINE_NOT_READY';
        }
        if (!$integrationHealthy) {
            $reasons[] = 'INTEGRATION_UNHEALTHY';
        }

        $assurance = strtoupper($assuranceStatus);
        if ($assurance === 'RED') {
            $reasons[] = 'ASSURANCE_RED';
        }
        if ($assurance === 'AMBER' && $state->currentLevel->value >= AutonomyLevel::Auto->value) {
            $reasons[] = 'ASSURANCE_AMBER_REQUIRES_REVIEW';
        }

        if ($state->currentLevel->value >= AutonomyLevel::SemiAuto->value) {
            if ($state->scope === []) {
                $reasons[] = 'AUTONOMY_SCOPE_MISSING';
            } else {
                $scope = $this->scopeEvaluator->evaluate($state->scope, $context);
                $reasons = array_merge($reasons, $scope->reasonCodes);
            }
        }

        return new ExecutionAuthorityDecision($reasons === [], array_values(array_unique($reasons)));
    }
}
