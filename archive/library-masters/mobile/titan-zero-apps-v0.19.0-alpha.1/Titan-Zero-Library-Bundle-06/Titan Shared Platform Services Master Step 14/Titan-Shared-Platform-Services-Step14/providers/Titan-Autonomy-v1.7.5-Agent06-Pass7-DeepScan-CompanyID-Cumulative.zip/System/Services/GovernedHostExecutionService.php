<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Services;

use App\Extensions\TitanAutonomy\System\Contracts\AssuranceBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\CommandBusBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\InteractionEngineBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\ExecutionReconciliationContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\DTOs\GovernedCapabilityCommand;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;

final class GovernedHostExecutionService
{
    private const DEFAULT_MINS = ['low' => 1, 'medium' => 2, 'high' => 3, 'critical' => 3];
    private const DEFAULT_CEILINGS = ['low' => 'trusted_auto', 'medium' => 'trusted_auto', 'high' => 'auto', 'critical' => 'semi_auto'];

    public function __construct(
        private readonly HostContextBridgeContract $host,
        private readonly LiveGovernedCapabilityRegistry $registry,
        private readonly ExecutionAuthorityGuard $authority,
        private readonly InteractionEngineBridgeContract $interaction,
        private readonly CommandBusBridgeContract $commandBus,
        private readonly AssuranceBridgeContract $assurance,
        private readonly ?GateReviewService $gateReview = null,
        private readonly ?DelegatedAuthorityEnvelopeService $delegation = null,
        private readonly ?ExecutionReconciliationContract $reconciliation = null,
    ) {}

    public function execute(
        CapabilityState $state,
        GovernedCapabilityCommand $command,
        array $context,
        bool $explicitApprovalSatisfied = false,
        array $serverApprovalEvidence = [],
    ): array {
        $reasons = [];
        if ($state->tenantCompanyId !== $this->host->tenantCompanyId()) $reasons[] = 'TENANT_CONTEXT_MISMATCH';
        if ($state->capability !== $command->capability) $reasons[] = 'CAPABILITY_STATE_MISMATCH';
        if ($state->workflowKey !== '' && ($command->workflowKey ?? '') !== $state->workflowKey) $reasons[] = 'WORKFLOW_STATE_MISMATCH';
        if (!$this->registry->has($command->capability)) $reasons[] = 'UNVERIFIED_OR_UNGOVERNED_HOST_CAPABILITY';
        if ($reasons !== []) return $this->denied($reasons);

        $profile = $this->registry->profile($command->capability);
        if ($profile['risk'] !== $state->risk->value) $reasons[] = 'RISK_PROFILE_MISMATCH';
        if ($state->currentLevel->value >= AutonomyLevel::Auto->value && $this->reconciliation === null) {
            $reasons[] = 'OUTCOME_RECONCILIATION_UNAVAILABLE';
        }
        if ($reasons !== []) return $this->denied($reasons);

        $interactionContext = $context + [
            'correlation_id' => $command->correlationId,
            'interaction_id' => $command->interactionId,
            'session_id' => $command->sessionId,
            'idempotency_key' => $command->idempotencyKey,
            'approval_evidence' => $serverApprovalEvidence,
        ];
        $journey = $this->interaction->prepareJourney($command->capability, $command->workflowKey, $interactionContext);
        if (($journey['session_validated'] ?? false) !== true || !is_array($journey['mapped_command'] ?? null)) {
            return $this->denied(array_values(array_unique(array_merge($reasons, (array) ($journey['reason_codes'] ?? []), ['INTERACTION_SESSION_NOT_VALIDATED']))), $journey);
        }
        $mapped = (array) $journey['mapped_command'];
        if ((string) ($mapped['capability'] ?? '') !== $command->capability) {
            return $this->denied(['INTERACTION_MAPPED_CAPABILITY_MISMATCH'], $journey);
        }
        $metadata = (array) ($mapped['metadata'] ?? []);
        $executionCommand = new GovernedCapabilityCommand(
            capability: $command->capability,
            payload: (array) ($mapped['payload'] ?? []),
            workflowKey: $command->workflowKey,
            correlationId: (string) ($metadata['correlation_id'] ?? $command->correlationId ?? ''),
            interactionId: $command->interactionId,
            sessionId: (string) ($metadata['session_id'] ?? $command->sessionId ?? ''),
            idempotencyKey: (string) ($metadata['idempotency_key'] ?? $command->idempotencyKey ?? ''),
            trustedInteractionMapped: true,
        );

        $assurance = $this->assurance->evaluate($command->capability, $command->workflowKey, [
            'tenant_company_id' => $state->tenantCompanyId,
            'current_level' => $state->currentLevel->key(),
            'scope' => $state->scope,
            'execution_context' => $context,
        ]);

        $decision = $this->authority->evaluate(
            state: $state,
            context: $context,
            actorPermissionValid: $this->host->can((string) $profile['permission']),
            interactionReady: (bool) ($journey['ready'] ?? false),
            integrationHealthy: (bool) ($journey['available'] ?? false),
            assuranceStatus: (string) ($assurance['status'] ?? 'RED'),
            explicitApprovalSatisfied: $explicitApprovalSatisfied,
            maximumAllowedLevel: $this->maximumAllowedLevel($state),
        );
        $reasons = array_values(array_unique(array_merge($reasons, $decision->reasonCodes)));
        if (!$decision->allowed || $reasons !== []) return $this->denied($reasons, $journey, $assurance);

        $delegatedAuthority = [];
        if ($state->currentLevel->value >= AutonomyLevel::Auto->value) {
            if ($this->delegation === null) {
                return $this->denied(['DELEGATION_ENVELOPE_UNAVAILABLE'], $journey, $assurance);
            }
            try {
                $delegatedAuthority = $this->delegation->issue(
                    state: $state,
                    effectivePolicy: $this->effectivePolicy($state),
                    issuingUserId: $this->host->userId(),
                    sessionId: (string) ($executionCommand->sessionId ?? ''),
                    interactionId: $executionCommand->interactionId,
                    correlationId: $executionCommand->correlationId,
                    grantedScopes: [(string) $profile['permission']],
                );
            } catch (\Throwable) {
                return $this->denied(['DELEGATION_ENVELOPE_ISSUE_FAILED'], $journey, $assurance);
            }
        }

        $result = $this->commandBus->dispatch($executionCommand, [
            'roles' => array_values(array_filter((array) ($context['roles'] ?? []), 'is_string')),
            'scopes' => array_values(array_filter((array) ($context['scopes'] ?? []), 'is_string')),
            'approval_evidence' => $serverApprovalEvidence,
            'correlation_id' => $command->correlationId ?? ($journey['correlation_id'] ?? null),
            'idempotency_key' => $command->idempotencyKey,
            'autonomy_level' => $state->currentLevel->key(),
            'workflow_key' => $state->workflowKey,
            'delegated_authority' => $delegatedAuthority,
        ]);

        $status = is_array($result) ? (string) ($result['status'] ?? '') : '';
        $executed = in_array($status, ['executed', 'ok'], true);
        $outcomeTracking = null;
        $trackingReasons = [];
        if ($state->currentLevel->value >= AutonomyLevel::Auto->value && $this->reconciliation !== null) {
            try {
                $outcomeTracking = $this->reconciliation->capture(
                    $state,
                    $executionCommand,
                    $context + ['correlation_id' => $executionCommand->correlationId],
                    is_array($result) ? $result : ['status' => $status, 'result' => $result],
                    $assurance,
                    $this->host->userId(),
                );
            } catch (\Throwable) {
                $outcomeTracking = ['status' => 'failed'];
                $trackingReasons[] = 'OUTCOME_RECONCILIATION_CAPTURE_FAILED';
            }
        }
        return [
            'executed' => $executed,
            'status' => $status !== '' ? $status : 'unknown',
            'result' => $result,
            'reason_codes' => array_values(array_unique(array_merge($executed ? [] : ['COMMAND_BUS_DID_NOT_EXECUTE'], $trackingReasons))),
            'interaction' => $journey,
            'assurance' => $assurance,
            'outcome_tracking' => $outcomeTracking,
        ];
    }

    private function maximumAllowedLevel(CapabilityState $state): AutonomyLevel
    {
        $policy = $this->effectivePolicy($state);
        $ceilings = array_merge(self::DEFAULT_CEILINGS, (array) ($policy['maximum_level_by_risk'] ?? []));
        return match ((string) ($ceilings[$state->risk->value] ?? 'assist')) {
            'suggest' => AutonomyLevel::Suggest,
            'assist' => AutonomyLevel::Assist,
            'semi_auto' => AutonomyLevel::SemiAuto,
            'auto' => AutonomyLevel::Auto,
            'trusted_auto' => AutonomyLevel::TrustedAuto,
            default => AutonomyLevel::Assist,
        };
    }

    private function effectivePolicy(CapabilityState $state): array
    {
        if ($this->gateReview !== null) {
            return $this->gateReview->effectivePolicyForTenant($state->tenantCompanyId);
        }
        return [
            'gate_minimums' => self::DEFAULT_MINS,
            'maximum_level_by_risk' => self::DEFAULT_CEILINGS,
            'system_wide_learning' => false,
        ];
    }

    private function denied(array $reasons, array $interaction = [], array $assurance = []): array
    {
        return ['executed' => false, 'status' => 'denied', 'reason_codes' => array_values(array_unique($reasons)), 'interaction' => $interaction, 'assurance' => $assurance];
    }
}
