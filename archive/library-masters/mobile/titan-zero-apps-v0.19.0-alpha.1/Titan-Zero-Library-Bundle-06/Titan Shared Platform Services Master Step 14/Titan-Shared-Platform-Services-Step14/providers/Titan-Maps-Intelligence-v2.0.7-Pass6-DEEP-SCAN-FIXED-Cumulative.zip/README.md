# Titan Maps Intelligence

Titan Maps Intelligence is Titan Zero's company-scoped geographic intelligence extension. The current v2 baseline provides governed Google Places business discovery, candidate classification/matching/promotion, provenance, exports, territory summaries, AI capability registration and hardened tenant/route security.

## Current implementation — 2.0.0 / Titan Field Route Optimisation Proposals

Implemented now:

- Google Places business/place discovery with company-scoped provider connections.
- Radius/category/open-now/rating filtering and provider pagination.
- Candidate classification, review, duplicate matching and governed WorkCore promotion.
- Field-level provenance, provider usage metering and suppression handling.
- CSV, JSON and XLSX export through a host private-export abstraction.
- Forty-four governed Titan Maps capabilities: all alpha.17 capabilities remain compatible; the 8 canonical spatial contracts (`location.geocode`, `territory.lookup`, `territory.validate`, `route.estimate`, `route.compare`, `job.travel_context`, `service_area.check`, `nearby.search`) are layered over the existing domain services.
- Hardened MagicAI blueprint manifest pair and lifecycle provider location.
- Thirty-nine owned company-scoped tables across 53 forward-only migrations, including beta quota, scoring and geocode-retry state.
- Authenticated user, admin, API and fail-closed internal route profiles.
- Explicit API action permissions and separate Maps admin authorization.
- Company-safe route-model resolution and rejection of client tenant overrides.
- Immutable `company_id` after record creation.
- Queue tenant context around all existing discovery queue work.

Implemented through Pass 17 now includes live worker GPS, native graphical geofencing, graphical operational maps, provider-derived road routing, durable route/ETA snapshots, cached travel matrices, nearest-resource ranking, multi-stop route planning, explainable human-approved dispatch recommendations, graphical service territories, branch travel zones and advisory geographic pricing signals. Pass 15 adds methodologically distinct provider-coverage, competitor-density, supplier-access, service-gap, branch-coverage and expansion-opportunity analytics with persisted cell evidence. Pass 16 adds governed contractor/supplier fallback with internal-first escalation, approved-network review, Titan Gear shortage lineage, Maps Discovery fallback, travel evidence, human review and explicit promotion. Pass 17 integrates the entire capability surface with canonical Titan spatial contracts, traceable governance receipts, optional Risk/Assurance/Autonomy/Command Bus/Signal/Rewind/Knowledge adapters, and an offline-safe Titan Go capability manifest. Remaining later-pass work focuses on operational UI hardening, menu/admin completion, capability refinements and observability.

Beta.1 adds provider quota/health circuit breakers, server geofence reconciliation, per-geofence confidence controls, stronger worker privacy/retention/anomaly handling, tenant/vertical dispatch scoring, deterministic territory conflict resolution, ETA freshness, bounded route optimisation, queued analytics snapshots, geocode retry/backoff, fallback review deadlines and five new governed operational-control capabilities. See `docs/audits/2026-08-12-beta1-hardening-disposition.md` for the exact implemented/deferred audit matrix.



## beta.1.8 Blade compiler compatibility hotfix

Live Titan Zero / Livewire verification of beta.1.7 exposed a host-compiler incompatibility with inline Blade `@php(...)` directives. The compiled view omitted the expected PHP closing boundary before following HTML, causing `syntax error, unexpected token "class"`. Beta.1.8 removes every inline `@php(...)` directive from shipped Blade views and uses explicit `@php ... @endphp` blocks instead. A package regression script now rejects any future inline `@php(...)` directive. All beta.1.7 distinct navigation workspaces are retained unchanged. No schema, migration, route, permission, capability or menu-key change is introduced.


## beta.1.7 distinct navigation workspace compatibility

The user menu routes remain stable, but each Maps workspace now renders route-relevant content instead of falling through to one generic page shell. The five parent workspaces expose focused quick links and configuration facts; specialist pages receive relevant KPI subsets and page-specific tables/empty states; analytics, dispatch, geofencing, travel and fallback workflows retain their existing governed forms and execution boundaries. Resource Fallback remains a dedicated page.

No database, route name, capability, permission or menu-key change is introduced.

## beta.1.6 host-theme readable KPI card compatibility

Live dark-theme verification of beta.1.5 exposed two presentation regressions: KPI labels inherited a host secondary token that rendered too dark on the active Titan Zero theme, and the six-colour per-card accent rotation visually overpowered the host theme. Beta.1.6 makes the host theme authoritative: labels use `--tblr-body-color` with controlled opacity, all KPI cards use the host card surface and border tokens, and values/rails use the host `--tblr-primary` accent only. The decorative accent is reduced to a subtle primary tint, card heights remain consistent, and the beta.1.4 responsive grid is retained. No schema, route, capability, permission or menu changes are introduced.

## beta.1.5 theme-aware KPI card compatibility

The shared Maps KPI metrics now render as dedicated theme-aware stat cards rather than relying on the host's generic `.card` surface alone. Each card uses Titan/Tabler host CSS variables for its surface, border, accent, value colour and subtle tint, with deterministic primary/info/success/warning/danger/purple accent rotation and fallbacks to the host primary colour. The Maps stylesheet now loads on every shared Maps navigation page, not only pages with a graphical map payload, so Live Map, Locations, Team Map, Dispatch Intelligence, Geofences and the remaining Maps screens stay visually consistent. The beta.1.4 responsive grid remains unchanged. No schema, route, capability, permission or menu changes are introduced.

## beta.1.4 responsive KPI layout compatibility

The shared Maps navigation KPI strip previously used Bootstrap `col-lg` auto-width columns for 13 metrics. On tablet/desktop layouts this forced all cards into one row and compressed labels to near-character width. KPI cards now use explicit responsive widths (`col-6 col-md-4 col-lg-3 col-xxl-2`), include safe normal word wrapping, and carry regression-test hooks. Existing Maps JS/CSS asset URLs are cache-busted to beta.1.4. No schema, route, capability, permission or menu changes are introduced by this hotfix.

## beta.1.3 MySQL migration compatibility

The live Titan installer exposed a MySQL legacy `TIMESTAMP` default edge case while creating `maps_location_pings`: two required bare timestamps caused the second column (`received_at`) to receive an invalid implicit zero-date default under the host SQL mode. Required application/event times now use non-null `DATETIME`; nullable timestamps remain nullable `TIMESTAMP`s. The migration verifier rejects recurrence of this pattern.

## Route roots

```text
/dashboard/user/titan-maps-intelligence
/dashboard/admin/titan-maps-intelligence
/api/titan/maps-intelligence
/internal/titan/maps-intelligence
```

The internal route profile intentionally exposes no endpoint yet and fails closed unless the host binds service-identity verification.

## Package contract

Canonical provider:

```text
App\Extensions\TitanMapsIntelligence\System\TitanMapsIntelligenceServiceProvider
```

`extension.json` is the authoritative Titan Extension Manager manifest (`schema: titan-extension-v1`). `extension.manifest.json` remains the hardened architecture sidecar. A compatibility alias remains at the historic root provider path for pre-v2 host mappings.

## Requirements

- PHP 8.2/8.3
- Laravel 10.x host
- MagicAI host compatible with the hardened extension lifecycle interfaces
- authenticated company context; Maps registers extension-owned `titan.maps.company` and a non-overriding legacy `titan.company` fallback for stale beta.1 route caches
- Sanctum for API authentication
- host admin middleware + `titan-maps-intelligence.admin.access` Gate ability
- queue worker
- Titan Vault-compatible credential resolver
- audit/capability/private-export host adapters
- WorkCore adapters when candidate matching/promotion is enabled

## Verification

From the extension root:

```bash
php scripts/verify.php
php scripts/verify_migrations.php
php scripts/verify_security.php
```

The live Titan installer manifest is verified with `scripts/verify.php`. The hardened Blueprint sidecar (`extension.manifest.json`) is validated separately against its schema, and the Blueprint filesystem/secret scanner is run without replacing the live `titan-extension-v1` root manifest.

Run Laravel-host/MySQL feature tests after installing into the target MagicAI/Titan test host.

## Beta.1 hardening controls

Provider calls are quota-guarded and health-tracked; routing/planning freshness and timeouts are explicit; geofence transitions are reconciled server-side; dispatch weights can be configured per tenant/vertical; territory conflicts are deterministic; analytics are queued/cached; and offline `route.estimate` is blocked. The capability surface is 44 definitions and retains the alpha.17 governed execution model.

## Governed spatial intelligence (alpha.17)

Pass 17 preserves all existing Maps functionality and adds the platform-wide governance layer described in `docs/GOVERNED_SPATIAL_INTELLIGENCE.md`. The extension now exposes 39 capability definitions with complete risk/autonomy/evidence/offline/reversibility/idempotency metadata. Eight canonical spatial capability IDs sit over the existing domain services while all legacy IDs remain registered for compatibility.

Risk, Assurance, Autonomy, Command Bus, Signal, Rewind and Knowledge Authority are optional adapter contracts rather than installer-time hard dependencies. Missing engines do not fabricate approval; consequential AI/system mutations fail closed when required governance is unavailable. CRM job assignment is routed through the Command Bus adapter instead of a direct CRM service call. Titan Go can read an offline capability manifest whose policy can only preserve or reduce authority.

## Credentials

Do not place Google API keys in this package. `maps_provider_connections.credential_reference` must contain an opaque Titan Vault reference.

## Configuration-driven algorithms (v2.0.0-alpha.5)

Ranking and candidate matching are now controlled by validated `config/titan_maps_intelligence.php` settings. Weight sets must contain the supported signal keys and sum to `1.0`; invalid result/radius caps, provider timeout/retry settings, matching thresholds or unsafe Google provider configuration fail closed during extension boot/provider resolution. `configuration_version` is written into search/match audit metadata so scoring-policy changes can be traced later.

The Field & Home navigation hierarchy is implemented through the extension-owned adaptive menu synchronizer and documented in `docs/NAVIGATION_PLAN.md`; no MagicAI core navigation edits are required.


## Provider-neutral geocoding and routing (v2.0.0-alpha.5)

Pass 5 adds vendor-neutral `GeocodingProvider`, `RoutingProvider`, and `TrafficProvider` contracts, separate registries, Google Geocoding API v4 and Google Routes API v2 adapters, traffic-aware/static duration separation, route-matrix normalization, and usage-unit recording. These are infrastructure capabilities for later location/dispatch passes; public route/AI endpoints are intentionally deferred until their domain services are complete.

## Canonical WorkCore location references (v2.0.0-alpha.6.2)

Pass 6 adds `map_locations` as the single persistent geographic projection for operational WorkCore references. A location is unique by `company_id + reference_type + public_reference_id` and stores only coordinates, source/precision, provider provenance, freshness timestamps, and optional reverse-geocode metadata. Supported reference types are `job`, `property`, `branch`, `worker`, `supplier`, and `contractor`.

`FieldReferenceGateway` resolves the authorized WorkCore reference before any geocode/write occurs. Missing, deleted, inactive, or foreign-company references are rejected. Forward geocoding uses the WorkCore-provided postal address ephemerally and stores only a SHA-256 address fingerprint plus provider-formatted address; reverse geocoding is metadata only and never overwrites authoritative customer/property data. Source-aware freshness rules are configured under `location_freshness`.

## Host adapter portability (alpha.6.2)

Titan Maps Intelligence no longer requires `App\Titan\Maps\*` adapter classes to exist during extension installation. The service provider prefers compatible host adapters when present and otherwise binds extension-local safe fallbacks. WorkCore-dependent actions fail closed until a WorkCore adapter is available; provider credentials can use `env://VARIABLE_NAME` when a Titan Vault Maps adapter is not installed.
## Navigation visibility (alpha.6.3)

This release synchronizes Maps navigation into the host MagicAI `menus` table through an adaptive extension-owned installer. It reads the live table columns, writes only supported fields, uses Laravel named routes, restricts icons to host-proven components, and calls `App\Services\Common\MenuService::regenerate()` when available.

Company navigation:

- **Field Operations** — Live Map, Locations, Team Map, Dispatch Intelligence, Resource Fallback, Geofences, Check-ins
- **Location Intelligence** — Overview, Business Discovery, Candidates, Suppliers, Contractors, Competitors, Nearby Services
- **Territories and Coverage** — Overview, Territory Analysis, Service Areas, Travel Zones, Geographic Pricing, Provider Coverage, Competitor Density, Supplier Coverage, Service Gaps, Branch Coverage, Expansion Opportunities
- **Travel and Routing** — Overview, Route Calculator, Travel Matrix, Route Planner, Traffic and ETA
- **Maps and Location** — Overview, Providers, Routing, Location Tracking, Privacy and Retention, Usage and Limits

Admin-capable hosts receive **Titan Maps Intelligence** with Dashboard, Provider Health, API Usage and Diagnostics. Hosts without an explicit `is_admin` menu column receive a single admin entry under the existing Settings parent, matching the current Titan fallback pattern.

The menu migration is additive/idempotent and is designed to run when upgrading an already-installed alpha.6.2 package.


## Live worker location (alpha.7)

Titan Go/PWA can now publish authenticated on-duty worker GPS samples through the Maps API. Workers first establish server-side tracking consent/duty state, then publish latitude/longitude, accuracy, capture time and optional motion metadata. Accepted samples update the worker's canonical `map_locations` projection and append to `maps_location_pings` history. Stale/future/low-accuracy/off-duty/non-consented samples are rejected, and minimum-time/minimum-movement debounce prevents excessive GPS writes.

Field Operations now includes **Team Map** and **Check-ins**. Historical GPS retention is controlled by `worker_tracking.retention_days` and can be enforced with `php artisan titan-maps:prune-location-pings`.

## Graphical maps (alpha.8)

Titan Maps now contains a real interactive graphical map renderer. The map is extension-owned and does not require a third-party JavaScript mapping library at runtime. It supports drag/pan, zoom, fit-to-data, raster basemap tiles, interactive pins/popups, route polylines, territory polygons, radius circles and responsive mobile layouts.

Graphical surfaces include **Field Operations > Live Map**, **Locations**, **Team Map**, **Check-ins**, Location Intelligence views, Territory/Coverage views and Travel/Routing views. Team Map refreshes accepted worker positions automatically through the authenticated company-scoped web endpoint. Check-ins can display worker GPS trails.

The Route Calculator now accepts origin/destination coordinates and draws the provider-returned road route on the map, with road distance, travel duration, traffic delay and provider provenance.

The default tile template is `https://tile.openstreetmap.org/{z}/{x}/{y}.png` with visible OpenStreetMap attribution. For production SaaS volume, set `TITAN_MAPS_TILE_URL` and `TITAN_MAPS_TILE_ATTRIBUTION` to a tile service or self-hosted endpoint appropriate for the deployment. The renderer performs normal viewport loading only; it does not implement tile bulk-download/offline prefetch.

## Native graphical geofencing (alpha.9)
Field Operations now includes a Geofences workspace. Users can draw circles by dragging from a centre point or polygons by clicking map vertices, optionally attach them to a Titan job/property/branch/worker/supplier/contractor reference, and configure dwell time. Accepted Titan Go worker pings are evaluated with GPS accuracy, hysteresis and consecutive-sample filtering. Job/property arrival/departure events are confirmation-gated by default rather than silently mutating operational state.


## Durable road routing and ETA provenance (alpha.10)

Pass 10 promotes routing from an ephemeral provider response into a durable, auditable domain. Every calculation records a company-scoped `maps_route_snapshots` record plus a linked `maps_eta_snapshots` record. Provider success stores road distance, route geometry, provider identity, calculated time, freshness threshold, static duration, traffic-aware duration and traffic delay.

Fallback behavior is deliberately conservative:

1. **provider route** — road distance and ETA are provider-derived and marked fresh at calculation time;
2. **last valid snapshot** — when the provider is unavailable, Titan may serve the most recent matching provider snapshot within the configured maximum age, but marks the route/ETA as stale and preserves the original calculation time;
3. **straight-line estimate** — when no valid provider snapshot exists, Titan returns only Haversine straight-line distance. `road_distance_metres` and ETA remain `null`; no live ETA is fabricated.

The route API/UI exposes `distance_basis`, `eta_basis`, `traffic_basis`, `freshness_status`, provider error code and source snapshot identity. Travel pages render fresh routes normally, stale routes as a distinct dashed route, and straight-line estimates as a separate estimate style. Route history remains tenant-scoped and permission-gated.

## Multi-stop route planning and optimisation (alpha.12)

Route Planner sequences depot, job, supplier, contractor, break and custom stops using the existing provider-neutral travel matrix. Locked stops retain their position, appointment windows influence ordering, and unavoidable window conflicts remain visible in the resulting schedule.

Each reroute is an immutable optimisation revision with its trigger (`initial`, `manual`, `emergency_insert`, `stop_completed`, `stop_cancelled`, `stop_reopened` or AI-tool request), matrix provenance, before/after distance/time metrics and savings. When matrix ETA is unavailable, Titan can still sequence by straight-line distance but deliberately leaves time savings unavailable.

The graphical planner can optionally request provider road geometry for a limited number of segments. Otherwise it draws dashed sequence connectors and labels them as non-road geometry.

## Travel matrix and nearest-resource intelligence (alpha.11)

Travel Matrix is now an operational graphical workflow rather than a placeholder. Titan can compare one or many origins and destinations through the provider-neutral route-matrix layer, persist the resulting cells, reuse fresh identical matrices to protect quota, and preserve provider/freshness provenance.

The Field & Home nearest-resource workflow accepts an origin and ranks on-duty workers, canonical suppliers and canonical contractors. Provider ETA is the primary sort when available; road distance is the secondary signal. If the provider is unavailable, Titan uses a clearly marked stale matching matrix when allowed, otherwise it falls back to straight-line distance and keeps ETA unavailable.

The graphical Travel Matrix view shows ranked resource pins and dashed comparison connectors. Those connectors are not claimed to be road-route geometry because a route matrix returns travel cost rather than per-cell polylines. Pass 13 adds job-specific dispatch suitability (skills, certification, workload and continuity) on top of this geographic ranking.


## Governed contractor/supplier resource fallback (alpha.16)

Pass 16 adds **Field Operations → Resource Fallback**. Contractor requests tied to a mapped job first reuse Dispatch Intelligence to prove whether suitable internal capacity exists. If no internal resource qualifies, Titan ranks already-approved contractor/supplier network records by travel evidence. Only when that approved network is exhausted can Maps launch a new Places discovery search.

Supplier fallback can carry `operational_need_type=inventory_shortage` and a Titan Gear shortage public ID, with explicit target coordinates supplied by the calling Gear/operations workflow. The shortage ID is retained as audit lineage; Maps does not assume or mutate Titan Gear inventory tables. Discovery can optionally request businesses that are open now.

Discovery candidates are enriched with provider/stale ETA or road-distance evidence where available and with straight-line distance stored separately. Service/category evidence remains unknown when it cannot be proven. Human approval is required before a new discovery candidate can enter the existing promotion workflow, and promotion remains fail-closed when no compatible CRM/operations promotion adapter is installed. Approved-network resources already exist operationally and are never re-promoted. No external resource is automatically assigned to a job.

The fallback audit trail links the operational need to the internal-capacity result, approved-network stage, discovery search ID, human decision and promotion result without logging precise target coordinates.

## Real territory analytics (alpha.15)

Pass 15 replaces the previous generic territory summary with six distinct evidence-backed methodologies: provider coverage by geographic cells, competitor density per explicit km², supplier access by travel-time bands, service-gap analysis from observed job demand plus coverage, branch coverage, and weighted expansion opportunity. Every persisted run records its methodology key/version, analysed area, source/input summary, findings, confidence and per-cell evidence.

Demand, ETA and road evidence remain conservative: if canonical job locations are absent, demand is reported as unavailable; if routing cannot provide a supplier ETA, supplier access is placed in the unavailable band rather than guessed. Expansion opportunity reduces evidence completeness when required inputs are missing. Branch coverage currently labels its branch-proximity basis explicitly when only straight-line proximity is available.

Dedicated **Branch Coverage** and **Expansion Opportunities** pages join the existing Provider Coverage, Competitor Density, Supplier Coverage and Service Gaps pages. The map renders persisted analysis-cell overlays so a historical run can be reconstructed without recalculating it in the browser.

## Service territories and geographic pricing signals (alpha.14)

Pass 14 adds company-scoped service territories with graphical circle/polygon geometry, exact postcode/suburb rules, inclusion/exclusion effects and priority ordering. Branch-centred travel zones can qualify by provider-derived road distance or drive time using the durable routing layer; straight-line fallback never satisfies a road-distance or drive-time band.

Geographic evaluations persist coverage, exclusion, primary/travel territory, branch affinity, route provenance and emitted pricing signals. Pricing hints are advisory only: every signal is stored with `authoritative=false` and `application_status=not_applied`. Maps exposes the `GeographicPricingSignalProvider` contract so CRM/quoting can consume geographic evidence without Maps mutating quotes, invoices or customer prices.

Territories and Coverage now includes **Service Areas**, **Travel Zones** and **Geographic Pricing**. The graphical editor can draw radius/polygon areas; postcode/suburb rules remain exact text rules rather than synthetic polygons.


## Titan Field peer bridge — beta.1.9
When Titan Field is active, Maps exposes a bounded `FieldSpatialPeerGateway` and prefers Titan Field reference/evidence/qualification/assignment adapters. Maps remains independently bootable: Field discovery is runtime-only and Field assignment is accepted only through the bound Field governed command gateway.


## Titan Field spatial cost evidence — beta.1.10
`FieldSpatialPeerGateway::workOrderCostEvidence()` returns tenant-verified, read-only route/ETA and territory evidence for a Titan Field work order. The payload may include persisted geographic pricing signals, but they remain advisory (`authoritative: false`, `financial_authority: false`). Maps never calculates Field profit and never writes Field financial state.


## Titan Field capacity pressure evidence — beta.1.11

`FieldSpatialPeerGateway::capacityPressureEvidence()` accepts bounded demand-point coordinates supplied by Titan Field and returns read-only nearest-worker travel-matrix pressure, provider/cache freshness, uncovered-demand counts and any existing territory evaluation evidence. The returned travel adjustment is advisory and non-authoritative; Maps does not calculate Field staffing capacity and cannot assign or reschedule Field work.

## Joint Pass 14 — delayed GPS / Titan Go replay

Maps now accepts bounded offline worker-location batches while preserving capture timestamps, accuracy, consent and retention. Stale samples are historical evidence only; they cannot replace a live marker or retroactively fire geofence transitions. See `docs/PASS14_OFFLINE_WORKER_LOCATION_SYNC.md`.


## Joint Pass 15 — Field route optimisation proposals

Maps now exposes `routeOptimizationProposal()` through the optional Titan Field peer contract. It uses the existing travel-matrix and route-plan optimiser stack to produce an explainable, immutable proposal containing baseline/proposed stop order, distance/time changes, schedule/window evidence, constraints, algorithm/provider/fallback provenance, warnings, hashes and expiry. The proposal is explicitly `read_only` / `no_field_write`; Maps contains no Field command/write path for applying it. Titan Field separately records, reviews and—only after governance—applies an accepted proposal.
