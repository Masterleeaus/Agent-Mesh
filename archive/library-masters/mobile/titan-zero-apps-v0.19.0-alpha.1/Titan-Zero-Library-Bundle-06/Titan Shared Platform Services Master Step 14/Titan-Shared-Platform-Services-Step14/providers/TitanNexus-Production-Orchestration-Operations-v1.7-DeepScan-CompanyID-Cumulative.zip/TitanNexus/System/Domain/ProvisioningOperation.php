<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\CanonicalJson;
use InvalidArgumentException;

final class ProvisioningOperation
{
    /** @param list<string> $dependsOnOperationIds */
    public function __construct(
        private readonly int $tenantCompanyId,
        private readonly string $compilationUuid,
        private readonly string $proposedOutputHash,
        private readonly string $path,
        private readonly SemanticChangeKind $kind,
        private readonly SemanticChangeDisposition $disposition,
        private readonly string $capability,
        private readonly ?string $routePath,
        private readonly mixed $before,
        private readonly mixed $after,
        private readonly array $dependsOnOperationIds = [],
        private readonly ?string $reason = null,
    ) {
        if ($this->tenantCompanyId <= 0) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }
        self::assertUuid($this->compilationUuid, 'compilation_uuid');
        self::assertHash($this->proposedOutputHash, 'proposed_output_hash');
        self::assertPath($this->path, 'path');
        if ($this->routePath !== null) {
            self::assertPath($this->routePath, 'route_path');
        }
        if (preg_match('/^[A-Za-z0-9_.:-]{1,180}$/', $this->capability) !== 1) {
            throw new InvalidArgumentException('capability is invalid.');
        }
        if ($this->reason !== null && (trim($this->reason) === '' || strlen($this->reason) > 1000)) {
            throw new InvalidArgumentException('reason must be null or between 1 and 1000 characters.');
        }
        $dependencies = [];
        foreach ($this->dependsOnOperationIds as $id) {
            if (!is_string($id)) {
                throw new InvalidArgumentException('depends_on_operation_ids must contain SHA-256 strings.');
            }
            self::assertHash($id, 'depends_on_operation_id');
            $dependencies[] = strtolower($id);
        }
        if (count(array_unique($dependencies)) !== count($dependencies)) {
            throw new InvalidArgumentException('depends_on_operation_ids must be unique.');
        }
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $kind = SemanticChangeKind::tryFrom(self::requiredString($data['kind'] ?? null, 'kind'));
        $disposition = SemanticChangeDisposition::tryFrom(self::requiredString($data['disposition'] ?? null, 'disposition'));
        if ($kind === null || $disposition === null) {
            throw new InvalidArgumentException('Provisioning operation kind/disposition is invalid.');
        }
        $depends = $data['depends_on_operation_ids'] ?? [];
        if (!is_array($depends) || !array_is_list($depends)) {
            throw new InvalidArgumentException('depends_on_operation_ids must be a list.');
        }
        $route = $data['route_path'] ?? null;
        if ($route !== null && !is_string($route)) {
            throw new InvalidArgumentException('route_path must be null or string.');
        }
        $reason = $data['reason'] ?? null;
        if ($reason !== null && !is_string($reason)) {
            throw new InvalidArgumentException('reason must be null or string.');
        }
        $instance = new self(
            self::positiveInt($data['tenant_company_id'] ?? null),
            self::requiredString($data['compilation_uuid'] ?? null, 'compilation_uuid'),
            self::requiredString($data['proposed_output_hash'] ?? null, 'proposed_output_hash'),
            self::requiredString($data['path'] ?? null, 'path'),
            $kind,
            $disposition,
            self::requiredString($data['capability'] ?? null, 'capability'),
            $route === null ? null : trim($route),
            $data['before'] ?? null,
            $data['after'] ?? null,
            array_values($depends),
            $reason,
        );
        foreach (['operation_id' => $instance->operationId(), 'idempotency_key' => $instance->idempotencyKey()] as $field => $expected) {
            if (isset($data[$field]) && (!is_string($data[$field]) || !hash_equals(strtolower($data[$field]), $expected))) {
                throw new InvalidArgumentException("{$field} does not match canonical operation data.");
            }
        }
        if (array_key_exists('backup_required', $data) && $data['backup_required'] !== true) {
            throw new InvalidArgumentException('backup_required must be true for every provisioning mutation.');
        }
        return $instance;
    }

    public function tenantCompanyId(): int { return $this->tenantCompanyId; }
    public function compilationUuid(): string { return $this->compilationUuid; }
    public function proposedOutputHash(): string { return strtolower($this->proposedOutputHash); }
    public function path(): string { return $this->path; }
    public function kind(): SemanticChangeKind { return $this->kind; }
    public function disposition(): SemanticChangeDisposition { return $this->disposition; }
    public function capability(): string { return $this->capability; }
    public function routePath(): ?string { return $this->routePath; }
    public function before(): mixed { return $this->before; }
    public function after(): mixed { return $this->after; }
    /** @return list<string> */
    public function dependsOnOperationIds(): array { return array_values($this->dependsOnOperationIds); }
    public function reason(): ?string { return $this->reason; }
    public function backupRequired(): bool { return true; }

    public function operationId(): string
    {
        return hash('sha256', CanonicalJson::encode([
            'tenant_company_id' => $this->tenantCompanyId,
            'compilation_uuid' => strtolower($this->compilationUuid),
            'path' => $this->path,
            'kind' => $this->kind->value,
            'capability' => $this->capability,
            'route_path' => $this->routePath,
        ]));
    }

    public function idempotencyKey(): string
    {
        return hash('sha256', CanonicalJson::encode([
            'operation_id' => $this->operationId(),
            'proposed_output_hash' => strtolower($this->proposedOutputHash),
            'after' => $this->after,
        ]));
    }

    /** @return array<string, mixed> */
    public function toContractArray(): array
    {
        return [
            'operation_id' => $this->operationId(),
            'idempotency_key' => $this->idempotencyKey(),
            'path' => $this->path,
            'capability' => $this->capability,
            'change_kind' => $this->kind->value,
            'governance_disposition' => $this->disposition->value,
            'dependencies' => array_values($this->dependsOnOperationIds),
            'before' => $this->before,
            'desired' => $this->after,
            'backup_required' => true,
            'reversible' => true,
        ];
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'tenant_company_id' => $this->tenantCompanyId,
            'compilation_uuid' => strtolower($this->compilationUuid),
            'proposed_output_hash' => strtolower($this->proposedOutputHash),
            'operation_id' => $this->operationId(),
            'idempotency_key' => $this->idempotencyKey(),
            'path' => $this->path,
            'kind' => $this->kind->value,
            'disposition' => $this->disposition->value,
            'capability' => $this->capability,
            'route_path' => $this->routePath,
            'before' => $this->before,
            'after' => $this->after,
            'depends_on_operation_ids' => array_values($this->dependsOnOperationIds),
            'backup_required' => true,
            'reason' => $this->reason,
        ];
    }

    private static function assertUuid(string $value, string $field): void
    {
        if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) !== 1) {
            throw new InvalidArgumentException("{$field} must be a UUID.");
        }
    }
    private static function assertHash(string $value, string $field): void
    {
        if (preg_match('/^[0-9a-f]{64}$/i', $value) !== 1) {
            throw new InvalidArgumentException("{$field} must be a SHA-256 hex digest.");
        }
    }
    private static function assertPath(string $value, string $field): void
    {
        if (preg_match('/^[A-Za-z0-9_.-]{1,512}$/', $value) !== 1) {
            throw new InvalidArgumentException("{$field} is invalid.");
        }
    }
    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') {
            throw new InvalidArgumentException("{$field} is required.");
        }
        return trim($value);
    }
    private static function positiveInt(mixed $value): int
    {
        $resolved = is_int($value) ? $value : (is_string($value) && ctype_digit($value) ? (int) $value : 0);
        if ($resolved <= 0) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }
        return $resolved;
    }
}
