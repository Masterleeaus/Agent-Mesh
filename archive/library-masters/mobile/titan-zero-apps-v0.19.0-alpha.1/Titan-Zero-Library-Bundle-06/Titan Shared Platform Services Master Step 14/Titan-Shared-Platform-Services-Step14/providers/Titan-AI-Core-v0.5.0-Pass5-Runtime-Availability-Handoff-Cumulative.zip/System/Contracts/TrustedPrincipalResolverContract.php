<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Contracts;

use App\Extensions\TitanAICore\System\DTO\TrustedPrincipal;

interface TrustedPrincipalResolverContract
{
    public function resolve(object $principal): TrustedPrincipal;
}
