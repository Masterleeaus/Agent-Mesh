<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Http\Controllers;

use App\Extensions\TitanRewind\System\Services\RewindLegalHoldService;
use App\Extensions\TitanRewind\System\Services\RewindTenantContextResolver;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

final class LegalHoldController
{
    public function __construct(private RewindTenantContextResolver $tenants, private RewindLegalHoldService $holds) {}

    public function store(Request $request): RedirectResponse
    {
        $tenant = $this->tenant($request); $actor = $request->user()?->getAuthIdentifier();
        $hold = $this->holds->apply($tenant,(string)$request->input('scope_type'),(string)$request->input('scope_id'),(string)$request->input('authority'),(string)$request->input('reason'),is_numeric($actor)?(int)$actor:null);
        return back()->with('success', 'Legal hold applied: '.$hold->hold_uuid);
    }

    public function release(Request $request, string $holdUuid): RedirectResponse
    {
        $tenant = $this->tenant($request); $actor = $request->user()?->getAuthIdentifier();
        $this->holds->release($tenant,$holdUuid,(string)$request->input('reason'),is_numeric($actor)?(int)$actor:null);
        return back()->with('success','Legal hold released.');
    }

    private function tenant(Request $request): int
    {
        $tenant = $this->tenants->forUser($request->user());
        abort_if($tenant === null,403,'Titan Rewind could not resolve an explicit tenant company for this account.');
        return $tenant;
    }
}
