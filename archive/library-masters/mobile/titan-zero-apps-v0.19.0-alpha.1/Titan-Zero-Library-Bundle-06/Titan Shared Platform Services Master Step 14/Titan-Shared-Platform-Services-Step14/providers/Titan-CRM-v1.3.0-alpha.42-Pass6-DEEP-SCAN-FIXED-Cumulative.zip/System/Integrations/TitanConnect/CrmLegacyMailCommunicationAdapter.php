<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\TitanConnect;

use App\Extensions\Crm\System\Services\{CrmViewDataService,SalesDocumentRenderQueueService};
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\ValidationException;

/**
 * Explicit standalone compatibility adapter.
 * Canonical integrated deployments should bind Titan Connect instead.
 * Sales-document delivery never renders synchronously: it waits for the durable render queue.
 */
final class CrmLegacyMailCommunicationAdapter implements CrmCommunicationExecutionPort
{
    public function __construct(
        private readonly CrmViewDataService $views,
        private readonly SalesDocumentRenderQueueService $renders,
    ) {}

    public function deliver(array $intent): array
    {
        $channel=(string)($intent['channel']??'');$recipient=trim((string)($intent['recipient']??''));
        if($channel!=='email')return ['status'=>'deferred','provider'=>'legacy_crm_mail','provider_status'=>'unsupported_channel','retryable'=>false];
        if(!filter_var($recipient,FILTER_VALIDATE_EMAIL))throw ValidationException::withMessages(['email'=>['Enter a valid email address.']]);

        $payload=$this->payload($intent['payload']??[]);$template=(string)($intent['template_key']??'');$userId=(int)($intent['user_id']??0);
        if($userId<1)throw new \InvalidArgumentException('Outbound communication intent requires an accountable user_id.');

        if(in_array($template,['crm_sales_document','crm_invoice_reminder'],true)){
            $type=(string)($payload['type']??'invoices');$publicId=trim((string)($payload['document_public_id']??''));
            if(!in_array($type,['proposals','estimates','invoices'],true)||$publicId==='')throw new \InvalidArgumentException('Sales-document communication intent is incomplete.');
            $artifact=$this->renders->artifact($userId,$type,$publicId);
            if($artifact===[]){
                return ['status'=>'deferred','provider'=>'legacy_crm_mail','provider_status'=>'awaiting_document_render','retryable'=>true,'render_job_public_id'=>$payload['render_job_public_id']??null];
            }
            $data=$this->views->salesDocument($userId,$type,$publicId);$doc=(array)($data['document']??[]);
            $pdf=(string)$artifact['bytes'];$filename=(string)$artifact['filename'];
            if($template==='crm_invoice_reminder'){
                Mail::send('crm::sales.reminder-email',['type'=>'invoices']+$data,function($message)use($recipient,$doc,$pdf,$filename):void{
                    $label=(string)($doc['number']??$doc['public_id']??'invoice');$message->to($recipient)->subject('Payment reminder: '.$label)->attachData($pdf,$filename,['mime'=>'application/pdf']);
                });
            }else{
                Mail::send('crm::sales.email',['type'=>$type]+$data,function($message)use($recipient,$doc,$pdf,$filename):void{
                    $message->to($recipient)->subject((string)($doc['title']??'CRM sales document'))->attachData($pdf,$filename,['mime'=>'application/pdf']);
                });
            }
            return ['status'=>'delivered','provider'=>'legacy_crm_mail','provider_message_id'=>null,'provider_status'=>'sent','retryable'=>false,'document_hash'=>$artifact['output_hash']??null];
        }

        $body=(string)($payload['body']??'You have a CRM notification.');$subject=(string)($payload['subject']??'CRM notification');
        Mail::raw($body,fn($message)=>$message->to($recipient)->subject($subject));
        return ['status'=>'delivered','provider'=>'legacy_crm_mail','provider_message_id'=>null,'provider_status'=>'sent','retryable'=>false];
    }

    /** @return array<string,mixed> */
    private function payload(mixed $payload):array
    {
        if(is_array($payload))return $payload;if(!is_string($payload)||$payload==='')return [];
        $decoded=json_decode($payload,true);return is_array($decoded)?$decoded:[];
    }
}
