# Capabilities

v0.4.0 advertises the existing Prime domain/durable-store capabilities plus:

- `prime.engine-gateway` — typed external-engine boundary and request/result envelopes
- `prime.engine-gateway.fail-closed` — missing, mismatched or failing bridges never imply approval
- `prime.gateway.ai-core` — typed planning request boundary for Titan AI Core
- `prime.gateway.signal` — typed Signal publication boundary; no automatic emission yet
- `prime.gateway.risk` — typed risk assessment boundary
- `prime.gateway.assurance` — typed assurance verification boundary
- `prime.gateway.autonomy` — typed effective-authority decision boundary
- `prime.gateway.governance` — typed governance constraint boundary
- `prime.gateway.rewind` — typed strategic receipt/evidence recording boundary
- `prime.gateway.wisdom` — typed outcome feedback boundary

A gateway capability means the contract/adaptor seam exists. It does not claim the target engine is installed, available, or being invoked automatically.

The package still does not advertise autonomous orchestration, queue execution, Command Bus mutation, Nexus/Forge/Workforce commissioning or model execution.
