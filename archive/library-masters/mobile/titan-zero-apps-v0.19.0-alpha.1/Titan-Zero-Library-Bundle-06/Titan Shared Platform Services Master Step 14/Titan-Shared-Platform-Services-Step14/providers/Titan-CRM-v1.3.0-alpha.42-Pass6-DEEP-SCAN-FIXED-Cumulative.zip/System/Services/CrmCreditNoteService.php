<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use DomainException;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class CrmCreditNoteService
{
    public function __construct(private readonly ConnectionInterface $db,private readonly SalesTotalsCalculator $totals,private readonly CrmReceivablesService $receivables) {}

    public function create(int $actorUserId,string $invoicePublicId,array $input): array
    {
        $tenant=CrmCompanyScope::companyId($actorUserId);
        return $this->db->transaction(function()use($actorUserId,$invoicePublicId,$input,$tenant):array{
            $invoice=$this->invoice($tenant,$invoicePublicId,true);
            if(in_array(strtolower((string)$invoice->status),['draft','void'],true))throw new DomainException('Credit notes require an issued receivable.');
            $calc=$this->totals->calculate((array)($input['lines']??[]));
            if($calc['total_minor']<1)throw new DomainException('Credit note total must be positive.');
            $alreadyCredited=(int)$this->db->table('crm_credit_notes')->where('company_id',$tenant)->where('invoice_public_id',$invoicePublicId)->where('status','issued')->whereNull('deleted_at')->sum('total_minor');
            if($calc['total_minor']>((int)$invoice->total_minor-$alreadyCredited))throw new DomainException('Credit note cannot exceed the remaining uncredited invoice total.');
            $publicId=(string)Str::ulid();
            $payload=['public_id'=>$publicId,'company_id'=>$tenant,'user_id'=>CrmCompanyScope::actorUserId($actorUserId),'invoice_public_id'=>$invoicePublicId,'number'=>$input['number']??null,'status'=>'draft','currency'=>(string)$invoice->currency,'subtotal_minor'=>$calc['subtotal_minor'],'tax_minor'=>$calc['tax_minor'],'total_minor'=>$calc['total_minor'],'reason'=>$input['reason']??null,'meta'=>json_encode((array)($input['meta']??[])),'created_at'=>now(),'updated_at'=>now()];
            $payload['snapshot_hash']=$this->hash($payload);$this->db->table('crm_credit_notes')->insert($payload);
            foreach($calc['lines'] as $i=>$line)$this->db->table('crm_credit_note_lines')->insert(['public_id'=>(string)Str::ulid(),'company_id'=>$tenant,'user_id'=>CrmCompanyScope::actorUserId($actorUserId),'credit_note_public_id'=>$publicId,'sequence'=>$i+1,'description'=>$line['description'],'quantity_milli'=>$line['quantity_milli'],'unit_price_minor'=>$line['unit_price_minor'],'tax_rate_bps'=>$line['tax_rate_bps'],'line_subtotal_minor'=>$line['line_subtotal_minor'],'line_tax_minor'=>$line['line_tax_minor'],'line_total_minor'=>$line['line_total_minor'],'meta'=>json_encode($line['meta']??[]),'created_at'=>now(),'updated_at'=>now()]);
            return $this->read($actorUserId,$publicId);
        });
    }

    public function issue(int $actorUserId,string $publicId): array
    {
        $tenant=CrmCompanyScope::companyId($actorUserId);
        return $this->db->transaction(function()use($actorUserId,$publicId,$tenant):array{
            $note=$this->db->table('crm_credit_notes')->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->lockForUpdate()->first();if(!$note)throw new InvalidArgumentException('Credit note not found.');
            if((string)$note->status!=='draft')throw new DomainException('Only draft credit notes can be issued.');
            $invoice=$this->invoice($tenant,(string)$note->invoice_public_id,true);
            $alreadyCredited=(int)$this->db->table('crm_credit_notes')->where('company_id',$tenant)->where('invoice_public_id',$note->invoice_public_id)->where('status','issued')->whereNull('deleted_at')->sum('total_minor');
            if((int)$note->total_minor>((int)$invoice->total_minor-$alreadyCredited))throw new DomainException('Credit note exceeds the remaining uncredited invoice total.');
            $lines=$this->lines($tenant,$publicId);$snapshot=['schema'=>'crm.credit-note.v1','credit_note_public_id'=>$publicId,'invoice_public_id'=>$note->invoice_public_id,'currency'=>$note->currency,'subtotal_minor'=>(int)$note->subtotal_minor,'tax_minor'=>(int)$note->tax_minor,'total_minor'=>(int)$note->total_minor,'reason'=>$note->reason,'lines'=>$lines];$encoded=json_encode($snapshot,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);$hash=hash('sha256',(string)$encoded);
            $this->db->table('crm_credit_notes')->where('id',$note->id)->update(['status'=>'issued','issued_snapshot'=>$encoded,'issued_snapshot_hash'=>$hash,'issued_at'=>now(),'snapshot_hash'=>$hash,'updated_at'=>now()]);
            $invoice=$this->receivables->recalculateInvoice($actorUserId,(string)$note->invoice_public_id);$invoice=$this->advanceInvoiceVersion($tenant,(string)$note->invoice_public_id,$invoice);
            return ['public_id'=>$publicId,'credit_note'=>$this->read($actorUserId,$publicId),'invoice'=>$invoice];
        });
    }

    public function void(int $actorUserId,string $publicId,string $reason=''): array
    {
        $tenant=CrmCompanyScope::companyId($actorUserId);
        return $this->db->transaction(function()use($actorUserId,$publicId,$reason,$tenant):array{
            $note=$this->db->table('crm_credit_notes')->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->lockForUpdate()->first();if(!$note)throw new InvalidArgumentException('Credit note not found.');
            if(!in_array((string)$note->status,['draft','issued'],true))throw new DomainException('Credit note is already terminal.');
            $this->db->table('crm_credit_notes')->where('id',$note->id)->update(['status'=>'void','voided_at'=>now(),'voided_by_user_id'=>CrmCompanyScope::actorUserId($actorUserId),'meta'=>json_encode(['void_reason'=>$reason]),'updated_at'=>now()]);
            $invoice=$this->receivables->recalculateInvoice($actorUserId,(string)$note->invoice_public_id);$invoice=$this->advanceInvoiceVersion($tenant,(string)$note->invoice_public_id,$invoice);
            return ['public_id'=>$publicId,'credit_note'=>$this->read($actorUserId,$publicId),'invoice'=>$invoice];
        });
    }

    public function read(int $actorUserId,string $publicId): array
    {
        $tenant=CrmCompanyScope::companyId($actorUserId);$row=$this->db->table('crm_credit_notes')->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->first();if(!$row)throw new InvalidArgumentException('Credit note not found.');$out=(array)$row;$out['lines']=$this->lines($tenant,$publicId);return $out;
    }

    private function advanceInvoiceVersion(int $tenant,string $invoicePublicId,array $invoice): array { if(array_key_exists('entity_version',$invoice)){$this->db->table('crm_invoices')->where('company_id',$tenant)->where('public_id',$invoicePublicId)->increment('entity_version');$fresh=$this->db->table('crm_invoices')->where('company_id',$tenant)->where('public_id',$invoicePublicId)->first();return $fresh?(array)$fresh:$invoice;}return $invoice; }
    private function invoice(int $tenant,string $publicId,bool $lock=false): object { $q=$this->db->table('crm_invoices')->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at');if($lock)$q->lockForUpdate();$row=$q->first();if(!$row)throw new InvalidArgumentException('CRM invoice not found.');return $row; }
    private function lines(int $tenant,string $publicId): array{return $this->db->table('crm_credit_note_lines')->where('company_id',$tenant)->where('credit_note_public_id',$publicId)->orderBy('sequence')->get()->map(fn($r)=>(array)$r)->all();}
    private function hash(array $payload):string{unset($payload['snapshot_hash']);return hash('sha256',(string)json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));}
}
