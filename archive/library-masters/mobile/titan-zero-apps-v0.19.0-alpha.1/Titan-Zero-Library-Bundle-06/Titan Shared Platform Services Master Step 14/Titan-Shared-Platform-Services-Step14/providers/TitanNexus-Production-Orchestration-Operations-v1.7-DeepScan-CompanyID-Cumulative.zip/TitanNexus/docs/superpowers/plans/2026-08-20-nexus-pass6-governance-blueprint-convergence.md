# Titan Nexus Pass 6 Governance + Blueprint Convergence Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans and test-driven-development. Steps use checkbox syntax for tracking.

**Goal:** Make Nexus v0.7.0 a canonical Blueprint v2.2 configuration orchestrator with fail-closed governed provisioning and Signal/Rewind evidence.

**Architecture:** Preserve deterministic compile/diff/plan behavior. Add public gateway adapters for governance engines and wrap Command Bus execution in a deterministic gate/evidence sequence. Add canonical contract export methods while preserving persisted snapshot compatibility.

**Tech Stack:** PHP 8.2+, Laravel 10, MagicAI 10+, JSON Schema 2020-12.

## Global Constraints
- No cross-extension implementation imports.
- No direct foreign database writes.
- Compiler version remains 0.5.0.
- Existing migrations remain byte-identical.
- Required governance gateways fail closed before mutation.

### Task 1: Governance execution domain and adapters
- [ ] Write failing standalone governance test.
- [ ] Add execution context and decision value objects.
- [ ] Add Risk/Governance/Autonomy/Assurance/Signal/Rewind gateway contracts and adapters.
- [ ] Upgrade governed executor and verify red-green behavior.

### Task 2: Canonical contract exports
- [ ] Add failing contract export tests against blueprint field names.
- [ ] Add canonical export methods for diff, validation, vertical, recompile, provisioning plan and receipts.
- [ ] Preserve existing persistence serialization.

### Task 3: Blueprint v2.2 package convergence
- [ ] Replace legacy installer manifest with Installer v1 shape.
- [ ] Replace sidecar with canonical v2.2 configuration-orchestrator manifest.
- [ ] Add Nexus schemas and required production documentation.
- [ ] Update provider/config for public governance gateways.

### Task 4: Verification and cumulative package
- [ ] Run every standalone suite and PHP lint.
- [ ] Run canonical blueprint manifest validator and architecture/package scanners.
- [ ] Verify prior migrations are byte-identical.
- [ ] Build cumulative ZIP, re-extract, and rerun verification.
