<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Governance;

/** Safe default. Titan Command Bus may rebind CrmCommandBusPort at runtime. */
final class CrmDeferredCommandBusPort implements CrmCommandBusPort
{
    public function available(): bool { return false; }

    public function dispatch(CrmCommandRequest $request): array
    {
        return [
            'status'=>'awaiting_command_bus',
            'executed'=>false,
            'command_request'=>$request->toArray(),
            'reason_code'=>'TITAN_COMMAND_BUS_UNAVAILABLE',
        ];
    }
}
