<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Models\RewindCaseTrace;
use App\Extensions\TitanRewind\System\Models\RewindTimelineEntry;
use App\Extensions\TitanRewind\System\Models\RewindTraceEvent;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;
use Illuminate\Support\Str;

final class RewindTimelineService
{
    public function materializeEvent(RewindTraceEvent $event): RewindTimelineEntry
    {
        $caseId = RewindCaseTrace::query()
            ->where('tenant_company_id', $event->tenant_company_id)
            ->where('trace_id', $event->trace_id)
            ->value('case_id');

        $existing = RewindTimelineEntry::query()
            ->where('tenant_company_id', $event->tenant_company_id)
            ->where('event_id', $event->event_id)
            ->first();

        $values = [
            'case_id' => $caseId,
            'trace_id' => $event->trace_id,
            'correlation_id' => $event->correlation_id,
            'causation_id' => $event->causation_id,
            'source_engine' => $event->source_engine,
            'event_type' => $event->event_type,
            'sequence' => $event->sequence,
            'tier' => $event->tier,
            'lane' => $event->lane,
            'title' => $this->title($event),
            'summary' => $this->summary($event),
            'risk_level' => $this->riskLevel($event),
            'metadata' => array_filter([
                'actor_type' => $event->actor_type,
                'actor_id' => $event->actor_id,
                'decision_id' => $event->decision_id,
                'policy_version' => $event->policy_version,
                'guide_version' => $event->guide_version,
                'knowledge_version' => $event->knowledge_version,
                'model_provider' => $event->model_provider,
                'model_name' => $event->model_name,
                'model_version' => $event->model_version,
                'capability_name' => $event->capability_name,
                'capability_version' => $event->capability_version,
                'evidence_refs' => $event->evidence_refs,
            ], static fn ($value) => $value !== null && $value !== [] && $value !== ''),
            'occurred_at' => $event->occurred_at,
        ];

        if ($existing) {
            $existing->fill($values)->save();
            return $existing->refresh();
        }

        return RewindTimelineEntry::query()->create(array_merge([
            'entry_uuid' => (string) Str::uuid(),
            'tenant_company_id' => $event->tenant_company_id,
            'event_id' => $event->event_id,
        ], $values));
    }

    public function materializeTrace(RewindTraceQuery $query): int
    {
        $count = 0;
        $events = RewindTraceEvent::query()
            ->where('tenant_company_id', $query->tenantCompanyId())
            ->where('trace_id', $query->traceId())
            ->orderBy('sequence')->orderBy('occurred_at')->orderBy('event_id')->cursor();
        foreach ($events as $event) { $this->materializeEvent($event); ++$count; }
        return $count;
    }

    public function forTrace(RewindTraceQuery $query, int $limit = 500)
    {
        return RewindTimelineEntry::query()
            ->where('tenant_company_id', $query->tenantCompanyId())
            ->where('trace_id', $query->traceId())
            ->orderBy('sequence')->orderBy('occurred_at')->orderBy('event_id')
            ->limit(max(1, min($limit, 2000)))->lazy(250);
    }

    private function title(RewindTraceEvent $event): string
    {
        $eventType = ucwords(str_replace(['.', '_', '-'], ' ', $event->event_type));
        return trim($eventType . ' · ' . $event->source_engine);
    }

    private function summary(RewindTraceEvent $event): string
    {
        $rationale = $event->rationale ?? [];
        if (is_string($rationale['summary'] ?? null) && trim($rationale['summary']) !== '') return trim($rationale['summary']);
        $payload = $event->payload ?? [];
        if (is_string($payload['summary'] ?? null) && trim($payload['summary']) !== '') return trim($payload['summary']);
        return sprintf('%s recorded %s.', $event->source_engine, $event->event_type);
    }

    private function riskLevel(RewindTraceEvent $event): string
    {
        $risk = $event->risk_state ?? [];
        foreach (['level','risk_level','overall','severity'] as $key) {
            if (isset($risk[$key]) && is_scalar($risk[$key])) return strtolower(trim((string) $risk[$key])) ?: 'unknown';
        }
        return 'unknown';
    }
}
