# Titan Interaction Engine v10.3.1 — Phase 6.1 Settings Report

## Release classification

**Archive/source verified; integrated MagicAI/Titan host UI certification remains UNVERIFIED.**

Phase 6.1 adds separated settings surfaces without changing the Phase 6 domain-ownership architecture or the canonical `company_id` tenant boundary.

## IMPLEMENTED — Super Admin settings

Routes under the existing MagicAI `web + auth + admin` route profile:

- `GET /dashboard/admin/interaction-engine/settings`
- `POST /dashboard/admin/interaction-engine/settings`

Platform settings are allowlisted and persisted in `interaction_platform_settings`:

- engine enabled/disabled
- default renderer
- LocalBrain enabled/disabled
- LocalBrain minimum confidence
- offline workflow enablement
- definition cache TTL
- fresh-authentication window
- offline sync batch size

The Super Admin screen also exposes:

- health/readiness checks
- capability-provider support counts
- extension version
- approval/outbox secret **configured/not configured** status

It never renders or accepts approval/outbox secret values.

## IMPLEMENTED — Company owner/admin settings

Routes:

- `GET /dashboard/user/interaction-engine/settings`
- `POST /dashboard/user/interaction-engine/settings/company`

Company writes are explicitly limited to actors with `owner` or `admin` roles. Settings are persisted in `interaction_company_settings` using canonical `company_id`:

- default renderer
- interaction style
- company LocalBrain availability
- company offline workflow availability
- offline behavior
- default progress visibility

Company settings deliberately do not expose direct authority-level mutation or external-extension domain CRUD. CRM, Builder, Chatbot, Connect, Mobile and TitanAI configuration remain governed capability/journey operations.

## IMPLEMENTED — Personal user preferences

Routes:

- `POST /dashboard/user/interaction-engine/settings/preferences`
- `GET /api/interaction-engine/v1/settings`
- `POST /api/interaction-engine/v1/settings/preferences`

Personal preferences remain scoped by `company_id + user_id` in the existing `interaction_user_preferences` table:

- interaction style
- guidance detail
- local guidance preference
- offline preference
- progress visibility

`company_id`, roles, authority, scopes and secret fields are not accepted by the personal settings allowlist.

## IMPLEMENTED — PWA settings contract

API:

- `GET /api/interaction-engine/v1/settings`
- `POST /api/interaction-engine/v1/settings/company` — owner/admin only
- `POST /api/interaction-engine/v1/settings/preferences`

The response separates:

- personal preferences
- effective presentation preferences
- company settings only when the actor can manage the company
- available onboarding/configuration journeys only when company-management authority exists

Wizard API responses now include `presentation_preferences`, allowing Hub, Go, Command and Onboarding to consume one settings contract.

## IMPLEMENTED — Runtime application

Persisted settings are connected to runtime behavior:

- `ExtensionState` consults persisted platform enablement dynamically.
- Interaction definition cache TTL uses persisted platform settings.
- Wizard and legacy interaction offline behavior honor company settings.
- Offline sync limits processing to the configured batch size.
- Local Intelligence HTTP processing fails closed when LocalBrain is disabled for the company.
- LocalBrain cloud-escalation confidence uses the configured minimum-confidence threshold.
- Wizard/PWA output includes effective company + personal presentation preferences.
- Fresh-authentication policy duration is read from persisted platform settings during service-container policy registration.

Settings reads fail safely to file/environment configuration if the database or settings tables are not yet available during first boot. Settings writes fail clearly until migrations have run.

## DATABASE

New additive/reversible tables:

- `interaction_platform_settings`
- `interaction_company_settings`

Existing table reused:

- `interaction_user_preferences`

No CRM, Builder, Chatbot, Connect, Mobile or TitanAI records are copied into Interaction Engine persistence.

## SECURITY

- `company_id` remains the canonical business tenant.
- Super Admin routes use the host `admin` middleware.
- Company writes require owner/admin roles in addition to authentication.
- Personal writes target only the current authenticated user.
- Caller-supplied `company_id` is ignored by settings policy and trusted tenant resolution comes from the authenticated actor.
- Capability authority cannot be edited through direct settings CRUD.
- Approval/outbox secrets are status-only.
- No provider/API credentials are accepted by settings forms.

## VERIFICATION

Fresh working-tree verification on v10.3.1:

- Main Interaction Engine verifier: PASS
- Phase 6.1 settings checks: **33/33**
- Core tests: **26/26**
- Template catalogue: **10/10**
- Assurance: **9/9**
- Historical workflow regression: **8/8**
- LocalBrain v2: **8/8**
- Phase 4 company/capability: **14/14**
- Phase 5 onboarding runtime: **7/7**
- Phase 5.1 hardening: **18/18**
- Phase 5.1 engine completeness: **10/10**
- Phase 6 provider routing: **24/24**
- Phase 6 surface security: **11/11**
- Phase 6 generated UI: **20/20**
- Phase 6 Titan Go offline: **10/10**
- Phase 6 secure connections: **12/12**
- Phase 6 inventory: **8/8**
- TypeScript/Node: **8/8**
- PHP lint: **448 files**
- JSON parse: **102 files**
- JavaScript syntax: **2 files**
- Migration `down()` presence: **19/19**
- Active TODO/FIXME: **0**
- Merge markers: **0**
- Settings secret input fields: **0**

## PARTIAL / UNVERIFIED

- No full MagicAI/Titan host is available in this package, so Laravel route boot, rendered dashboard layout integration, actual database migration execution and browser form submission remain host verification items.
- No verified MagicAI menu-registration contract was supplied with this package. The settings pages have stable routes but are not claimed to be automatically inserted into MagicAI navigation menus.
- Fresh-authentication duration is registered into capability policies during container/provider boot; reload long-running workers after changing it.
- External provider configuration remains capability/journey-driven and follows the Phase 6 provider availability limitations.
