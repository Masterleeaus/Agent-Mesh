<?php

declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Models;
use Illuminate\Database\Eloquent\Model;
final class RewindSignalOutbox extends Model
{
    protected $table='titan_rewind_signal_outbox';
    protected $fillable=['outbox_uuid','event_id','tenant_company_id','trace_id','correlation_id','causation_id','event_type','severity','payload','status','attempts','available_at','published_at','last_error'];
    protected $casts=['tenant_company_id'=>'integer','attempts'=>'integer','payload'=>'array','available_at'=>'datetime','published_at'=>'datetime'];
}
