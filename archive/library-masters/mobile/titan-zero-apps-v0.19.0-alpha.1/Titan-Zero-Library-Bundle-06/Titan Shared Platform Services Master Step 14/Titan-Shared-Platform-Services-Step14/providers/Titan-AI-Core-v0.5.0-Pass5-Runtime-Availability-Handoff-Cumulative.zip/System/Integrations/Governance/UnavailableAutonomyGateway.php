<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Integrations\Governance;

use App\Extensions\TitanAICore\System\Contracts\AutonomyGatewayContract;
use App\Extensions\TitanAICore\System\DTO\GovernanceDecision;
use App\Extensions\TitanAICore\System\DTO\GovernancePreflightRequest;

final class UnavailableAutonomyGateway implements AutonomyGatewayContract
{
    public function evaluate(GovernancePreflightRequest $request): GovernanceDecision
    {
        return GovernanceDecision::defer('autonomy', 'AUTONOMY_GATEWAY_UNAVAILABLE', 'Titan Autonomy is not connected; execution remains blocked.');
    }
}
