<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Models;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScoped;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class CrmDeal extends Model
{
    use CrmCompanyScoped, SoftDeletes;

    protected $table = 'crm_deals';
    protected $guarded = ['id'];
    protected $casts = ['expected_close_date' => 'date', 'closed_at' => 'datetime', 'metadata' => 'array'];

    public function pipeline(): BelongsTo { return $this->belongsTo(CrmPipeline::class, 'pipeline_id'); }
    public function stage(): BelongsTo { return $this->belongsTo(CrmPipelineStage::class, 'stage_id'); }
    public function company(): BelongsTo { return $this->belongsTo(CrmCompany::class, 'customer_company_id'); }
    public function contact(): BelongsTo { return $this->belongsTo(CrmContact::class, 'contact_id'); }
}
