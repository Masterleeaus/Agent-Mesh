<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Infrastructure;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use Closure;
use RuntimeException;

final class CrmCompanyHostContextBridge implements HostContextBridgeContract
{
    private readonly Closure $authResolver;

    public function __construct(?callable $authResolver = null)
    {
        $this->authResolver = $authResolver instanceof Closure
            ? $authResolver
            : Closure::fromCallable($authResolver ?? static fn () => auth()->user());
    }

    public function tenantCompanyId(): int
    {
        $user = ($this->authResolver)();
        if ($user === null) throw new RuntimeException('AUTHENTICATED_USER_REQUIRED');
        if (!class_exists(CrmCompanyScope::class)) throw new RuntimeException('CRM_COMPANY_SCOPE_UNAVAILABLE');

        $tenant = CrmCompanyScope::tenantCompanyId($this->userId());
        if ($tenant <= 0) throw new RuntimeException('TENANT_COMPANY_CONTEXT_UNAVAILABLE');
        return $tenant;
    }

    public function userId(): int
    {
        $user = ($this->authResolver)();
        if ($user === null) throw new RuntimeException('AUTHENTICATED_USER_REQUIRED');
        $value = method_exists($user, 'getAuthIdentifier') ? $user->getAuthIdentifier() : ($user->id ?? null);
        if (!is_numeric($value) || (int) $value <= 0) throw new RuntimeException('AUTHENTICATED_USER_ID_UNAVAILABLE');
        return (int) $value;
    }

    public function can(string $permission): bool
    {
        $user = ($this->authResolver)();
        if ($user === null) return false;
        return method_exists($user, 'can') ? (bool) $user->can($permission) : false;
    }

    public function isSuperAdmin(): bool
    {
        $user = ($this->authResolver)();
        if ($user === null) return false;
        if (method_exists($user, 'isSuperAdmin') && $user->isSuperAdmin()) return true;
        return $this->can('titan.autonomy.admin');
    }
}
