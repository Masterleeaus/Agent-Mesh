# Build Report

Current distributable target: **Titan Interaction Engine v10.3.1 Phase 6.1**. See the final release report and `KNOWN-LIMITATIONS.md` for provider/host certification status.
