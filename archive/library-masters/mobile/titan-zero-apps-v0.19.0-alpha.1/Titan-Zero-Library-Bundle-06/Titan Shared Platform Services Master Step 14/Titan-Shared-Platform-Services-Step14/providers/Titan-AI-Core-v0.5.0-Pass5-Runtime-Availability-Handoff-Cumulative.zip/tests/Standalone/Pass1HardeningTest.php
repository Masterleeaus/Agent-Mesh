<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$passes = 0;

$assert = static function (bool $condition, string $message) use (&$failures, &$passes): void {
    if ($condition) {
        $passes++;
        return;
    }
    $failures[] = $message;
};

$read = static fn (string $path): string => is_file($path) ? (string) file_get_contents($path) : '';

$extension = json_decode($read($root . '/extension.json'), true) ?: [];
$manifest = json_decode($read($root . '/extension.manifest.json'), true) ?: [];
$modelMigration = $read($root . '/database/migrations/2026_08_11_000002_create_titan_ai_core_model_profiles_table.php');
$upgradeMigration = $read($root . '/database/migrations/2026_08_11_000003_harden_titan_ai_core_model_profiles_table.php');
$plansMigration = $read($root . '/database/migrations/2026_08_11_000001_create_titan_ai_core_plans_table.php');
$userView = $read($root . '/resources/views/index.blade.php');
$adminView = $read($root . '/resources/views/admin.blade.php');
$featureTest = $read($root . '/tests/Feature/ExtensionBootTest.php');

$extensionVersion = (string) ($extension['version'] ?? '');
$manifestVersion = (string) ($manifest['version'] ?? '');
$assert($extensionVersion !== '' && $extensionVersion === $manifestVersion, 'extension.json and extension.manifest.json versions must match');
$assert(version_compare($manifestVersion, '0.2.0', '>='), 'extension version must retain Pass 1 hardening baseline');
$capabilities = $manifest['capabilities'] ?? [];
$assert(!in_array('ai.plan.simulate', $capabilities, true), 'manifest must not advertise unimplemented simulation capability');
$assert(!in_array('ai.model.route', $capabilities, true), 'manifest must not advertise unimplemented model routing capability');
$assert(($manifest['queues']['used'] ?? null) === false, 'manifest must not claim active queue usage before jobs exist');

$navigation = $manifest['navigation'] ?? [];
$assert(!empty($navigation['user']), 'manifest must declare navigation.user');
$assert(!empty($navigation['admin']), 'manifest must declare navigation.admin');

$assert(is_file($root . '/System/Navigation/TitanAICoreNavigation.php'), 'TitanAICoreNavigation must exist');
$assert(is_file($root . '/System/Navigation/HostNavigationRegistrar.php'), 'HostNavigationRegistrar must exist');
$assert(is_file($root . '/System/Services/HostMenuLifecycle.php'), 'HostMenuLifecycle must exist');

$assert(str_contains($modelMigration, "char('profile_scope_key', 64)"), 'model profile migration must use a fixed 64-char scope key');
$assert(!str_contains($modelMigration, "['tenant_company_id', 'provider', 'model', 'model_version', 'capability']"), 'unsafe nullable oversized composite unique index must be removed');
$assert(str_contains($modelMigration, 'taicore_model_profile_unique'), 'model profile migration must define compact uniqueness');
$assert($upgradeMigration !== '', 'forward upgrade migration for existing v0.1 model profile tables must exist');
$assert(str_contains($upgradeMigration, 'taicore_model_capability_unique'), 'upgrade migration must remove the v0.1 composite index');
$assert(str_contains($upgradeMigration, 'profile_scope_key'), 'upgrade migration must add/backfill profile_scope_key');

$assert(str_contains($plansMigration, "dropIfExists('titan_ai_core_plans')"), 'plans migration down() must support explicit rollback');
$assert(str_contains($modelMigration, "dropIfExists('titan_ai_core_model_profiles')"), 'model profiles migration down() must support explicit rollback');

$assert(str_contains($userView, '@extends($hostLayout'), 'user view must use resolved host layout');
$assert(str_contains($adminView, '@extends($hostLayout'), 'admin view must use resolved host layout');
$assert(is_file($root . '/resources/views/layouts/standalone.blade.php'), 'standalone fallback layout must exist');
$assert(is_file($root . '/System/Contracts/HostLayoutResolverContract.php'), 'HostLayoutResolverContract must exist');
$assert(is_file($root . '/System/Services/HostLayoutResolver.php'), 'HostLayoutResolver must exist');

$assert(is_file($root . '/System/Contracts/HealthCheckContract.php'), 'HealthCheckContract must exist');
$assert(is_file($root . '/System/Services/HealthCheck.php'), 'HealthCheck service must exist');
$assert(is_file($root . '/System/Console/DiagnoseCommand.php'), 'diagnose command must exist');
$assert(is_file($root . '/System/Console/HostSyncCommand.php'), 'host-sync command must exist');

$assert(str_contains($featureTest, 'use Tests\\TestCase;'), 'feature boot test must use host Laravel TestCase');
$assert(str_contains($featureTest, "dashboard.user.titan.ai.core.index"), 'feature boot test must assert user route registration');
$assert(str_contains($featureTest, "titan-ai-core::index"), 'feature boot test must assert namespaced view loading');

if ($failures !== []) {
    fwrite(STDERR, "Pass 1 hardening test: FAIL\n");
    foreach ($failures as $failure) {
        fwrite(STDERR, " - {$failure}\n");
    }
    fwrite(STDERR, sprintf("%d passed, %d failed\n", $passes, count($failures)));
    exit(1);
}

fwrite(STDOUT, sprintf("Pass 1 hardening test: PASS (%d assertions)\n", $passes));
