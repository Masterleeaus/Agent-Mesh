<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Voice;

use App\Extensions\TitanConnect\System\Contracts\VoiceAgentGateway;
use RuntimeException;

final class VoiceAgentService
{
    public function __construct(private readonly VoiceAgentGateway $gateway) {}
    public function create(string $name, string $welcomeMessage, string $instructions, ?string $language = null, ?string $voiceId = null): array
    {
        $agent=['first_message'=>$welcomeMessage,'prompt'=>['prompt'=>$instructions]]; if ($language && $language!=='auto') $agent['language']=$language; $tts=[]; if ($voiceId) $tts['voice_id']=$voiceId;
        return $this->gateway->create(['name'=>$name,'conversation_config'=>['agent'=>$agent,'tts'=>$tts]]);
    }
    public function update(string $agentId, array $conversationConfig, ?string $name = null): array { return $this->gateway->update($agentId,['conversation_config'=>$conversationConfig,'name'=>$name]); }
    public function delete(string $agentId): void { $this->gateway->delete($agentId); }
    public function voices(): array { return $this->gateway->voices(); }
    public function addKnowledge(string $type, mixed $content, ?string $name = null): array
    {
        $type=strtolower(trim($type)); if (! in_array($type,['text','url','file'],true)) throw new RuntimeException('Unsupported voice knowledge type.');
        // Deliberately no direct recursive crawler: URL/file knowledge is delegated to the configured provider/host gateway.
        return $this->gateway->addKnowledge($type,$content,$name);
    }
    public function removeKnowledge(string $documentId): void { $this->gateway->removeKnowledge($documentId); }
}
