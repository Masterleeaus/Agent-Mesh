<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Models;

use Illuminate\Database\Eloquent\Model;
use App\Extensions\TitanModelCouncil\System\Models\Concerns\HasCanonicalCompanyIdCompatibility;

final class CouncilParticipantRecord extends Model
{
    use HasCanonicalCompanyIdCompatibility;

    protected $table = 'titan_model_council_participants';
    protected $guarded = [];

    protected $casts = [
        'company_id' => 'integer',
        'company_id' => 'integer',
            'tenant_company_id' => 'integer',
        'decision_id' => 'integer',
        'credits' => 'integer',
        'metadata' => 'array',
    ];
}
