<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'tenant_key' => 'tenant_company_id',
    'permissions' => ['view' => 'titan-governance.view', 'admin' => 'titan-governance.admin'],
    'command_gateway_class' => env('TITAN_GOVERNANCE_COMMAND_GATEWAY_CLASS'),
    'control_centre_fresh_after_seconds' => 300,
    'control_centre_exception_expiring_seconds' => 86400,
    'workforce_approval_warning_seconds' => 3600,
    'workforce_approval_critical_seconds' => 14400,
    'required_dependencies' => ['titan-signal', 'titan-command-bus', 'titan-autonomy'],
    'optional_observers' => ['titan-risk','titan-assurance','titan-rewind','titan-wisdom','titan-knowledge-authority','titan-shield','titan-model-council','titan-ai-workforce'],
    'decision_evidence_sources' => [
        'titan-command-bus' => ['required' => true, 'class' => env('TITAN_GOVERNANCE_COMMAND_BUS_EVIDENCE_CLASS')],
        'titan-autonomy' => ['required' => true, 'class' => env('TITAN_GOVERNANCE_AUTONOMY_EVIDENCE_CLASS')],
        'titan-signal' => ['required' => true, 'class' => env('TITAN_GOVERNANCE_SIGNAL_EVIDENCE_CLASS')],
        'titan-risk' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_RISK_EVIDENCE_CLASS')],
        'titan-assurance' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_ASSURANCE_EVIDENCE_CLASS')],
        'titan-rewind' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_REWIND_EVIDENCE_CLASS')],
        'titan-knowledge-authority' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_KNOWLEDGE_EVIDENCE_CLASS')],
        'titan-shield' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_SHIELD_EVIDENCE_CLASS')],
        'titan-model-council' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_MODEL_COUNCIL_EVIDENCE_CLASS')],
        'titan-ai-workforce' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_WORKFORCE_EVIDENCE_CLASS')],
    ],

    'read_sources' => [
        'titan-autonomy' => ['required' => true, 'class' => env('TITAN_GOVERNANCE_AUTONOMY_SOURCE_CLASS')],
        'titan-signal' => ['required' => true, 'class' => env('TITAN_GOVERNANCE_SIGNAL_SOURCE_CLASS')],
        'titan-risk' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_RISK_SOURCE_CLASS')],
        'titan-assurance' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_ASSURANCE_SOURCE_CLASS')],
        'titan-rewind' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_REWIND_SOURCE_CLASS')],
        'titan-wisdom' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_WISDOM_SOURCE_CLASS')],
        'titan-knowledge-authority' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_KNOWLEDGE_SOURCE_CLASS')],
        'titan-shield' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_SHIELD_SOURCE_CLASS')],
        'titan-model-council' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_MODEL_COUNCIL_SOURCE_CLASS')],
        'titan-ai-workforce' => ['required' => false, 'class' => env('TITAN_GOVERNANCE_WORKFORCE_SOURCE_CLASS')],
    ],
];
