<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\ReadModels;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

/** Rebuilds disposable read projections from authoritative CRM state. */
final class CrmProjectionBuilder
{
    public function __construct(private readonly ConnectionInterface $db,private readonly CrmReadProjectionRegistry $registry,private readonly CrmReadStorePort $readStore) {}

    public function rebuild(int $companyId,?string $projectionName=null,?string $projectedThroughSignalId=null): array
    {$names=$projectionName!==null&&trim($projectionName)!==''?[trim($projectionName)]:$this->registry->names();$results=[];foreach($names as $name)$results[$name]=$this->rebuildProjection($companyId,$name,$projectedThroughSignalId);return ['company_id'=>$companyId,'rebuilt'=>$results,'count'=>count($results)];}

    public function rebuildProjection(int $companyId,string $projectionName,?string $projectedThroughSignalId=null): array
    {
        if($companyId<1)throw new InvalidArgumentException('company_id is required for CRM projection rebuild.');$definition=$this->registry->resolve($projectionName);
        $records=isset($definition['aggregate'])?$this->aggregate($companyId,(string)$definition['aggregate']):$this->sourceRecords($companyId,$definition);$sourceMax=null;
        foreach($records as $record){$candidate=$record['updated_at']??$record['generated_at']??null;if($candidate!==null&&($sourceMax===null||(string)$candidate>$sourceMax))$sourceMax=(string)$candidate;}
        return $this->readStore->replaceProjection($companyId,$definition,$records,$projectedThroughSignalId,$sourceMax)+['projected_through_signal_id'=>$projectedThroughSignalId,'source_max_updated_at'=>$sourceMax,'mode'=>'full'];
    }

    /** Incrementally rebuild a table-backed projection from a durable numeric-id checkpoint. */
    public function rebuildProjectionIncremental(int $companyId,string $projectionName,?int $batchSize=null): array
    {
        if($companyId<1)throw new InvalidArgumentException('company_id is required for CRM projection rebuild.');$definition=$this->registry->resolve($projectionName);
        if(isset($definition['aggregate']))return $this->rebuildProjection($companyId,$projectionName)+['incremental_supported'=>false];
        $table=(string)($definition['table']??'');if($table===''||!$this->db->getSchemaBuilder()->hasTable($table))return ['company_id'=>$companyId,'projection_name'=>$projectionName,'completed'=>true,'processed'=>0,'reason'=>'source_table_unavailable'];
        if(!$this->db->getSchemaBuilder()->hasTable('crm_read_projection_rebuild_checkpoints')||!$this->hasColumn($table,'id'))return $this->rebuildProjection($companyId,$projectionName)+['incremental_supported'=>false];
        $batch_size=max(25,min(5000,$batchSize??(int)config('crm.read_store.incremental_batch_size',500)));$checkpoint=$this->checkpoint($companyId,$definition,$batch_size);$cursor=(int)$checkpoint['checkpoint_cursor'];
        $fields=$this->existingFields($table,(array)$definition['fields']);if(!in_array('public_id',$fields,true))return ['company_id'=>$companyId,'projection_name'=>$projectionName,'completed'=>true,'processed'=>0,'reason'=>'public_id_unavailable'];
        $query=$this->db->table($table)->where('company_id',$companyId)->where('id','>',$cursor)->orderBy('id')->limit($batch_size);if($this->hasColumn($table,'deleted_at'))$query->whereNull('deleted_at');$select=array_values(array_unique(array_merge(['id'],$fields)));$rows=$query->get($select);$processed=0;$last=$cursor;$batch=[];
        if($cursor===0&&(int)$checkpoint['processed_count']===0)$this->readStore->replaceProjection($companyId,$definition,[]);
        foreach($rows as $row){$a=(array)$row;$last=max($last,(int)($a['id']??0));unset($a['id']);$resource=trim((string)($a['public_id']??''));if($resource==='')continue;$a['public_id']=$resource;$batch[]=$a;$processed++;}
        if($batch!==[])$this->readStore->upsertResources($companyId,$definition,$batch);
        $completed=count($rows)<$batch_size;$this->db->table('crm_read_projection_rebuild_checkpoints')->where('id',$checkpoint['id'])->update(['checkpoint_cursor'=>$last,'processed_count'=>(int)$checkpoint['processed_count']+$processed,'batch_size'=>$batch_size,'status'=>$completed?'completed':'in_progress','completed_at'=>$completed?now():null,'last_error'=>null,'updated_at'=>now()]);
        return ['company_id'=>$companyId,'projection_name'=>$projectionName,'projection_version'=>$definition['projection_version'],'checkpoint_cursor'=>$last,'batch_size'=>$batch_size,'processed'=>$processed,'completed'=>$completed,'mode'=>'incremental'];
    }

    private function checkpoint(int $companyId,array $definition,int $batch_size): array
    {
        $q=$this->db->table('crm_read_projection_rebuild_checkpoints')->where('company_id',$companyId)->where('projection_name',$definition['projection_name'])->where('projection_version',$definition['projection_version']);$row=$q->first();
        if(!$row){$id=$this->db->table('crm_read_projection_rebuild_checkpoints')->insertGetId(['public_id'=>(string)Str::ulid(),'company_id'=>$companyId,'projection_name'=>$definition['projection_name'],'projection_version'=>$definition['projection_version'],'checkpoint_cursor'=>0,'batch_size'=>$batch_size,'processed_count'=>0,'status'=>'in_progress','started_at'=>now(),'created_at'=>now(),'updated_at'=>now()]);$row=$this->db->table('crm_read_projection_rebuild_checkpoints')->where('id',$id)->first();}
        elseif((string)$row->status==='completed'){$q->update(['checkpoint_cursor'=>0,'processed_count'=>0,'batch_size'=>$batch_size,'status'=>'in_progress','started_at'=>now(),'completed_at'=>null,'last_error'=>null,'updated_at'=>now()]);$row=$q->first();}
        return (array)$row;
    }

    private function sourceRecords(int $companyId,array $definition): array
    {$table=(string)($definition['table']??'');if($table===''||!$this->db->getSchemaBuilder()->hasTable($table))return [];$fields=$this->existingFields($table,(array)$definition['fields']);if($fields===[]||!in_array('public_id',$fields,true))return [];$q=$this->db->table($table)->where('company_id',$companyId);if($this->hasColumn($table,'deleted_at'))$q->whereNull('deleted_at');$limit=max(100,min(50000,(int)config('crm.read_store.rebuild_record_limit',20000)));$count=(int)(clone $q)->count();if($count>$limit)throw new \RuntimeException("Projection {$definition['projection_name']} has {$count} source rows; use crm:projections:rebuild --projection={$definition['projection_name']} --incremental --until-complete to avoid an unbounded full rebuild.");$sort=(string)($definition['sort_field']??'updated_at');if($this->hasColumn($table,$sort))$q->orderBy($sort);elseif($this->hasColumn($table,'id'))$q->orderBy('id');return $q->get($fields)->map(fn($r)=>(array)$r)->all();}

    private function aggregate(int $companyId,string $aggregate): array
    {if($aggregate==='owner_dashboard'){$openDeals=$this->count('crm_deals',$companyId,fn($q)=>$q->where('status','open'));$pipelineValue=$this->sum('crm_deals',$companyId,'value_minor',fn($q)=>$q->where('status','open'));return [['public_id'=>'summary','open_deals'=>$openDeals,'pipeline_value_minor'=>$pipelineValue,'follow_ups_due'=>$this->count('crm_leads',$companyId,fn($q)=>$q->whereNotNull('follow_up_at')->where('follow_up_at','<=',now())->whereNotIn('status',['converted','lost'])),'overdue_invoices'=>$this->count('crm_invoices',$companyId,fn($q)=>$q->where('due_at','<',now())->whereNotIn('status',['paid','void','voided','cancelled'])),'generated_at'=>now()->toDateTimeString()]];}if($aggregate==='tenant_summary'){$tables=['customers'=>'crm_contacts','organizations'=>'crm_companies','leads'=>'crm_leads','deals'=>'crm_deals','invoices'=>'crm_invoices','projects'=>'crm_projects','tasks'=>'crm_tasks'];$record=['public_id'=>'summary','generated_at'=>now()->toDateTimeString()];foreach($tables as $key=>$table)$record[$key]=$this->count($table,$companyId);return [$record];}throw new InvalidArgumentException('Unsupported CRM aggregate projection.');}
    private function count(string $table,int $companyId,?callable $scope=null): int{if(!$this->db->getSchemaBuilder()->hasTable($table))return 0;$q=$this->db->table($table)->where('company_id',$companyId);if($this->hasColumn($table,'deleted_at'))$q->whereNull('deleted_at');if($scope)$scope($q);return (int)$q->count();}
    private function sum(string $table,int $companyId,string $column,?callable $scope=null): int{if(!$this->db->getSchemaBuilder()->hasTable($table)||!$this->hasColumn($table,$column))return 0;$q=$this->db->table($table)->where('company_id',$companyId);if($this->hasColumn($table,'deleted_at'))$q->whereNull('deleted_at');if($scope)$scope($q);return (int)$q->sum($column);}
    private function existingFields(string $table,array $fields): array{return array_values(array_filter(array_map('strval',$fields),fn(string $f)=>$f!==''&&$this->hasColumn($table,$f)));}
    private function hasColumn(string $table,string $column): bool{try{return $this->db->getSchemaBuilder()->hasColumn($table,$column);}catch(\Throwable){return false;}}
}
