<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('crm_read_projection_state')) {
            Schema::create('crm_read_projection_state', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id',26)->unique();
                $t->unsignedBigInteger('tenant_company_id')->index();
                $t->string('projection_name',80);
                $t->string('projection_version',20);
                $t->string('status',24)->default('stale')->index();
                $t->unsignedBigInteger('record_count')->default(0);
                $t->char('projected_through_signal_id',26)->nullable()->index();
                $t->dateTime('source_max_updated_at')->nullable()->index();
                $t->dateTime('rebuilt_at')->nullable()->index();
                $t->dateTime('stale_at')->nullable()->index();
                $t->unsignedInteger('stale_after_seconds')->default(300);
                $t->text('last_error')->nullable();
                $t->timestamps();
                $t->unique(['tenant_company_id','projection_name','projection_version'],'crm_projection_state_tenant_name_version_uq');
                $t->index(['tenant_company_id','status','updated_at'],'crm_projection_state_tenant_status_idx');
            });
        }

        if (! Schema::hasTable('crm_read_projection_records')) {
            Schema::create('crm_read_projection_records', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id',26)->unique();
                $t->unsignedBigInteger('tenant_company_id')->index();
                $t->string('projection_name',80);
                $t->string('projection_version',20);
                $t->string('resource_public_id',100);
                $t->unsignedBigInteger('entity_version')->nullable();
                $t->dateTime('sort_at')->nullable()->index();
                $t->dateTime('source_updated_at')->nullable()->index();
                $t->char('payload_hash',64)->index();
                $t->json('payload');
                $t->timestamps();
                $t->unique(['tenant_company_id','projection_name','projection_version','resource_public_id'],'crm_projection_record_tenant_resource_uq');
                $t->index(['tenant_company_id','projection_name','projection_version','sort_at'],'crm_projection_record_query_idx');
            });
        }

        // Query-path indexes used by CRM Core CQRS and commercial reads.
        if (Schema::hasTable('crm_activities')) {
            try { Schema::table('crm_activities', fn (Blueprint $t) => $t->index(['tenant_company_id','subject_public_id','occurred_at'],'crm_activity_tenant_subject_time_idx')); } catch (\Throwable) {}
        }
        if (Schema::hasTable('crm_invoices')) {
            try { Schema::table('crm_invoices', fn (Blueprint $t) => $t->index(['tenant_company_id','status','due_at'],'crm_invoice_tenant_status_due_idx')); } catch (\Throwable) {}
            try { Schema::table('crm_invoices', fn (Blueprint $t) => $t->index(['tenant_company_id','payment_state','due_at'],'crm_invoice_tenant_payment_due_idx')); } catch (\Throwable) {}
        }

    }

    public function down(): void
    {
        Schema::dropIfExists('crm_read_projection_records');
        Schema::dropIfExists('crm_read_projection_state');
    }
};
