<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('crm_read_projection_search_terms')) {
            Schema::create('crm_read_projection_search_terms', function (Blueprint $t): void {
                $t->id();
                $t->unsignedBigInteger('tenant_company_id');
                $t->string('projection_name',80);
                $t->string('projection_version',20);
                $t->string('resource_public_id',100);
                $t->string('term',191);
                $t->unsignedSmallInteger('weight')->default(1);
                $t->timestamps();
                $t->unique(['tenant_company_id','projection_name','projection_version','resource_public_id','term'],'crm_projection_term_resource_uq');
                $t->index(['tenant_company_id','term','projection_name','projection_version'],'crm_projection_term_lookup_idx');
                $t->index(['tenant_company_id','projection_name','projection_version','resource_public_id'],'crm_projection_term_resource_idx');
            });
        }

        $addIndex = static function (string $table,array $columns,string $name): void {
            if (! Schema::hasTable($table)) return;
            foreach ($columns as $column) if (! Schema::hasColumn($table,$column)) return;
            try { Schema::table($table,fn(Blueprint $t)=>$t->index($columns,$name)); } catch (\Throwable) {}
        };

        // Large-tenant list/detail and dashboard paths.
        $addIndex('crm_companies',['tenant_company_id','deleted_at','name','id'],'crm_company_list_idx');
        $addIndex('crm_contacts',['tenant_company_id','deleted_at','first_name','id'],'crm_contact_list_idx');
        $addIndex('crm_contacts',['tenant_company_id','company_id','deleted_at','is_primary','first_name','id'],'crm_contact_company_list_idx');
        $addIndex('crm_leads',['tenant_company_id','deleted_at','status','follow_up_at','id'],'crm_lead_followup_idx');
        $addIndex('crm_leads',['tenant_company_id','deleted_at','status','next_follow_up_at','id'],'crm_lead_next_followup_idx');
        $addIndex('crm_leads',['tenant_company_id','deleted_at','created_at','id'],'crm_lead_created_idx');
        $addIndex('crm_deals',['tenant_company_id','pipeline_id','stage_id','deleted_at','position','id'],'crm_deal_pipeline_stage_pos_idx');
        $addIndex('crm_deals',['tenant_company_id','status','deleted_at','updated_at','id'],'crm_deal_status_updated_idx');
        $addIndex('crm_deals',['tenant_company_id','status','closed_at','id'],'crm_deal_closed_idx');
        $addIndex('crm_deals',['tenant_company_id','company_id','deleted_at','updated_at','id'],'crm_deal_company_updated_idx');

        // Million-event/customer timeline paths: every source is tenant + subject + time bounded.
        $addIndex('crm_activities',['tenant_company_id','subject_type','subject_public_id','occurred_at','id'],'crm_timeline_activity_idx');
        $addIndex('crm_notes',['tenant_company_id','subject_type','subject_public_id','created_at','id'],'crm_timeline_note_idx');
        $addIndex('crm_email_messages',['tenant_company_id','subject_type','subject_public_id','sent_at','id'],'crm_timeline_email_idx');

        // Receivables, import commit, queues and operational metrics.
        $addIndex('crm_invoices',['tenant_company_id','deleted_at','due_at','currency','balance_minor'],'crm_invoice_aging_idx');
        $addIndex('crm_import_rows',['tenant_company_id','batch_public_id','status','row_number','id'],'crm_import_commit_idx');
        $addIndex('crm_domain_signal_outbox',['tenant_company_id','status','available_at','id'],'crm_signal_tenant_delivery_idx');
        $addIndex('crm_capability_operations',['tenant_company_id','status','created_at','id'],'crm_operation_metrics_idx');
        $addIndex('crm_webhook_deliveries',['tenant_company_id','status','next_retry_at','id'],'crm_webhook_retry_idx');
        $addIndex('crm_portal_files',['tenant_company_id','status','scan_status','id'],'crm_portal_file_health_idx');
        $addIndex('crm_read_projection_records',['tenant_company_id','projection_name','projection_version','id'],'crm_projection_batch_scan_idx');
    }

    public function down(): void
    {
        // Performance indexes are intentionally retained on rollback. The search-term table is
        // disposable read-model state and can be safely rebuilt, but retaining it avoids a
        // surprise full reindex during application rollback.
    }
};
