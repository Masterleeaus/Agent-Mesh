<?php

declare(strict_types=1);

use App\Extensions\TitanConnect\System\Http\Controllers\AttachmentController;
use App\Extensions\TitanConnect\System\Http\Controllers\CannedResponseController;
use App\Extensions\TitanConnect\System\Http\Controllers\ChannelConnectionController;
use App\Extensions\TitanConnect\System\Http\Controllers\ChannelHealthController;
use App\Extensions\TitanConnect\System\Http\Controllers\ContactTagController;
use App\Extensions\TitanConnect\System\Http\Controllers\ConversationExportController;
use App\Extensions\TitanConnect\System\Http\Controllers\DiagnosticsController;
use App\Extensions\TitanConnect\System\Http\Controllers\ExternalHandoffController;
use App\Extensions\TitanConnect\System\Http\Controllers\ExternalThreadController;
use App\Extensions\TitanConnect\System\Http\Controllers\InboxController;
use App\Extensions\TitanConnect\System\Http\Controllers\NavigationController;
use App\Extensions\TitanConnect\System\Http\Controllers\OperatorInboxController;
use App\Extensions\TitanConnect\System\Http\Controllers\OutboundMessageController;
use App\Extensions\TitanConnect\System\Http\Controllers\ProviderCredentialController;
use App\Extensions\TitanConnect\System\Http\Controllers\ProviderOnboardingController;
use App\Extensions\TitanConnect\System\Http\Controllers\ReplyRewriteController;
use App\Extensions\TitanConnect\System\Http\Controllers\VoiceCallController;
use App\Extensions\TitanConnect\System\Http\Controllers\WebhookController;
use App\Extensions\TitanConnect\System\Http\Middleware\EnsureCompanyRouteBindings;
use App\Extensions\TitanConnect\System\Http\Middleware\EnforceCompanyRateLimit;
use Illuminate\Support\Facades\Route;

Route::middleware('api')->prefix('api/titan-connect')->as('titan-connect.api.')->group(function (): void {
    Route::get('webhooks/{provider}/{connection}', [WebhookController::class, 'verify'])->name('webhooks.verify');
    Route::post('webhooks/{provider}/{connection}', [WebhookController::class, 'handle'])->name('webhooks.handle');
    Route::get('companies/{companyId}/attachments/{attachment}/provider', [AttachmentController::class, 'providerDownload'])->middleware('signed')->name('attachments.provider');

    Route::middleware(['auth', EnsureCompanyRouteBindings::class])->group(function (): void {
        Route::post('attachments', [AttachmentController::class, 'store'])->middleware(EnforceCompanyRateLimit::class.':upload')->name('attachments.store');
        Route::get('inbox', [InboxController::class, 'index'])->name('inbox.index');
        Route::get('navigation/badges', [NavigationController::class, 'badges'])->name('navigation.badges');
        Route::post('external-threads/{thread}/read', [InboxController::class, 'markExternalRead'])->name('external-threads.read');
        Route::patch('external-threads/{thread}/handoff', [ExternalHandoffController::class, 'update'])->name('external-threads.handoff');

        Route::get('operator/inbox', [OperatorInboxController::class, 'index'])->name('operator.index');
        Route::get('operator/notification', [OperatorInboxController::class, 'notification'])->name('operator.notification');
        Route::get('operator/threads/{thread}/messages', [OperatorInboxController::class, 'messages'])->name('operator.messages');
        Route::patch('operator/threads/{thread}/assign', [ExternalThreadController::class, 'assign'])->name('operator.assign');
        Route::patch('operator/threads/{thread}/pin', [ExternalThreadController::class, 'pin'])->name('operator.pin');
        Route::patch('operator/threads/{thread}/close', [ExternalThreadController::class, 'close'])->name('operator.close');
        Route::patch('operator/threads/{thread}', [ExternalThreadController::class, 'update'])->name('operator.update');
        Route::post('operator/threads/{thread}/notes', [ExternalThreadController::class, 'note'])->name('operator.notes.store');
        Route::put('operator/threads/{thread}/tags', [ExternalThreadController::class, 'tags'])->name('operator.tags.update');
        Route::get('operator/threads/{thread}/export/{format}', [ConversationExportController::class, 'show'])->name('operator.export');

        Route::get('tags', [ContactTagController::class, 'index'])->name('tags.index');
        Route::post('tags', [ContactTagController::class, 'store'])->name('tags.store');
        Route::delete('tags/{tag}', [ContactTagController::class, 'destroy'])->name('tags.destroy');

        Route::get('canned-responses', [CannedResponseController::class, 'index'])->name('canned.index');
        Route::post('canned-responses', [CannedResponseController::class, 'store'])->name('canned.store');
        Route::patch('canned-responses/{responseItem}', [CannedResponseController::class, 'update'])->name('canned.update');
        Route::delete('canned-responses/{responseItem}', [CannedResponseController::class, 'destroy'])->name('canned.destroy');
        Route::post('reply/rewrite', [ReplyRewriteController::class, 'store'])->middleware(EnforceCompanyRateLimit::class.':ai')->name('reply.rewrite');

        Route::get('diagnostics', [DiagnosticsController::class, 'index'])->name('diagnostics.index');
        Route::get('diagnostics/{connection}', [DiagnosticsController::class, 'show'])->name('diagnostics.show');
        Route::get('connections', [ChannelConnectionController::class, 'index'])->name('connections.index');
        Route::post('connections', [ChannelConnectionController::class, 'store'])->middleware(EnforceCompanyRateLimit::class.':admin')->name('connections.store');
        Route::patch('connections/{connection}', [ChannelConnectionController::class, 'update'])->middleware(EnforceCompanyRateLimit::class.':admin')->name('connections.update');
        Route::post('connections/{connection}/members', [ChannelConnectionController::class, 'addMember'])->middleware(EnforceCompanyRateLimit::class.':admin')->name('connections.members.store');
        Route::delete('connections/{connection}/members/{member}', [ChannelConnectionController::class, 'removeMember'])->middleware(EnforceCompanyRateLimit::class.':admin')->name('connections.members.destroy');
        Route::get('connections/{connection}/health', [ChannelHealthController::class, 'show'])->name('connections.health');
        Route::put('connections/{connection}/credentials', [ProviderCredentialController::class, 'store'])->middleware(EnforceCompanyRateLimit::class.':admin')->name('connections.credentials.store');
        Route::delete('connections/{connection}/credentials', [ProviderCredentialController::class, 'destroy'])->middleware(EnforceCompanyRateLimit::class.':admin')->name('connections.credentials.destroy');
        Route::post('onboarding/telegram', [ProviderOnboardingController::class, 'telegram'])->middleware(EnforceCompanyRateLimit::class.':admin')->name('onboarding.telegram');

        Route::post('connections/{connection}/threads/{thread}/messages', [OutboundMessageController::class, 'store'])->middleware(EnforceCompanyRateLimit::class.':send')->name('external-messages.store');
        Route::post('deliveries/{delivery}/retry', [OutboundMessageController::class, 'retry'])->middleware(EnforceCompanyRateLimit::class.':send')->name('deliveries.retry');
        Route::post('deliveries/{delivery}/cancel', [OutboundMessageController::class, 'cancel'])->name('deliveries.cancel');

        Route::post('connections/{connection}/voice-calls', [VoiceCallController::class, 'start'])->middleware(EnforceCompanyRateLimit::class.':voice')->name('voice.start');
        Route::post('voice-calls/{call}/session', [VoiceCallController::class, 'session'])->middleware(EnforceCompanyRateLimit::class.':voice')->name('voice.session');
        Route::post('voice-calls/{call}/transcript', [VoiceCallController::class, 'transcript'])->middleware(EnforceCompanyRateLimit::class.':voice')->name('voice.transcript');
        Route::post('voice-calls/{call}/end', [VoiceCallController::class, 'end'])->middleware(EnforceCompanyRateLimit::class.':voice')->name('voice.end');
    });
});
