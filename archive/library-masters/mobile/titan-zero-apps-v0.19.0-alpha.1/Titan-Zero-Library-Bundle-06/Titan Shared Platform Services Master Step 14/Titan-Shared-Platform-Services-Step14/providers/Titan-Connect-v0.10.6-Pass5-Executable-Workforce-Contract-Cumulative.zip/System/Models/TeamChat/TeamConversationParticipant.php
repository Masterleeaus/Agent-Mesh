<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Models\TeamChat;

use App\Extensions\TitanConnect\System\Contracts\CompanyOwnedModel;
use App\Extensions\TitanConnect\System\Models\Concerns\BelongsToCompany;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class TeamConversationParticipant extends Model implements CompanyOwnedModel
{
    use BelongsToCompany;
    use SoftDeletes;

    protected $table = 'ext_titan_connect_participants';

    protected $fillable = [
        'conversation_id', 'company_id', 'user_id', 'role', 'last_read_at',
        'joined_at', 'left_at', 'is_muted', 'is_pinned', 'archived_at', 'legacy_source', 'legacy_id',
    ];

    protected $casts = [
        'last_read_at' => 'datetime', 'joined_at' => 'datetime', 'left_at' => 'datetime',
        'archived_at' => 'datetime', 'is_muted' => 'boolean', 'is_pinned' => 'boolean',
    ];

    public function conversation(): BelongsTo
    {
        return $this->belongsTo(TeamConversation::class, 'conversation_id');
    }
}
