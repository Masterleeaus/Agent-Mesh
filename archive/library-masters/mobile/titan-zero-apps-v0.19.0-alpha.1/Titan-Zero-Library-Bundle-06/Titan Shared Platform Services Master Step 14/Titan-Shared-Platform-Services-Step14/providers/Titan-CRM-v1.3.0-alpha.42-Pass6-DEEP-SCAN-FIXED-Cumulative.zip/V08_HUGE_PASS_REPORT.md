# CRM v0.8.0 Huge Pre-Install Pass

## Purpose

Advance the recreated MagicAI CRM as far as practical before runtime installation. This pass targets the largest remaining architectural gaps while preserving MagicAI host upgrade compatibility and a zero-WorkCore-runtime-dependency boundary.

## Delivered

### AI Agent CRM companion

Recreated MagicAI's separately registered `ai-agent-tool-crm` technical identity with a standalone provider and tool catalogue. Every tool carries an input schema, CRM permission, risk level and confirmation requirement. Read tools are low-risk; writes are confirmation-gated. High-consequence lifecycle operations remain excluded from the generic agent surface.

### Granular permissions

Added explicit CRM permission vocabulary covering contacts, companies, leads, deals, activities, projects, tasks, calendar, Sales, import/export, settings, automations, portal, audit, notifications, metadata and duplicate merging. Route middleware and AI tool execution use the same permission service.

### Automation engine

Added user-scoped automation rules, idempotent run fingerprints, trigger/action catalogues, run journals and a scheduled command. Lifecycle triggers currently include lead creation, MagicAI contact capture, deal stage changes, won deals, overdue tasks and overdue invoices. Safe actions include task creation, notes, notification queueing and lead-status updates.

### Customer portal

Added random 32-byte portal grants with SHA-256 token hashes at rest, token hints, scopes, expiry, revocation, activation/access events and throttled public routes. Scoped capabilities can view Sales documents, comment, and accept sent proposals/estimates. Acceptance delegates to the normal CRM Sales lifecycle service rather than directly mutating storage. `files.upload` is reserved as a scope foundation; attachment upload transport is not implemented in this pre-install release.

### Import journal and rollback

Added import batches/rows, dry-run mode, mapping, row fingerprints, accepted/rejected results and rollback of records created by a real import batch. Current journaled types are companies, contacts and leads.

### Dedupe and Assistant context

Added confidence-based duplicate scoring using normalized email/phone plus fuzzy name similarity. Expanded Assistant context now includes dashboard state, follow-ups, recent activity, effective permissions and optional CRM record context.

## MagicAI host compatibility

The supplied MagicAI 11 host explicitly registers both:

- `crm` → `App\Extensions\Crm\System\CrmServiceProvider`
- `ai-agent-tool-crm` → `App\Extensions\AIAgentToolCrm\System\AIAgentToolCrmServiceProvider`

The CRM preserves the exact MagicAI Assistant service/view contracts, CRM/Sales entitlement families, menu route names and `ContactCapturedEvent` compatibility established in v0.7.

## Donor boundary

WorkCore was used only to extract mature architectural patterns such as read/write AI tool separation, scoped portal grants, expiry/revocation/access auditing and governed mutations. Runtime PHP/JSON contains no `App\Domains\WorkCore` references and no `tz_*` table dependency.

## Honest qualification

This release can be source-, package- and static-host-certified without installation. It is not Laravel-runtime/database certified until the user is ready to install into a runnable MagicAI environment and execute migrations, routes, browser workflows, mail/PDF delivery and AI Agent runtime calls.
