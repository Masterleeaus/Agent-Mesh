<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function fail_gas(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);}function assert_gas(bool $c,string $m):void{if(!$c)fail_gas($m);}function same_gas(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_gas($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
foreach([
 '/System/Contracts/GovernanceCommandGatewayContract.php','/System/Contracts/GovernanceActionDecisionStoreContract.php','/System/Contracts/GovernanceEscalationStoreContract.php',
 '/System/Actions/GovernanceActionRequest.php','/System/Actions/UnavailableGovernanceCommandGateway.php','/System/Actions/GovernanceCommandReceiptValidator.php','/System/Actions/GovernanceActionService.php','/System/Escalation/GovernanceEscalationTarget.php',
] as $file){if(!is_file($root.$file))fail_gas('missing '.$file);require_once $root.$file;}

use App\Extensions\TitanGovernance\System\Actions\GovernanceActionRequest;
use App\Extensions\TitanGovernance\System\Actions\GovernanceActionService;
use App\Extensions\TitanGovernance\System\Actions\GovernanceCommandReceiptValidator;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceActionDecisionStoreContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceCommandGatewayContract;
use App\Extensions\TitanGovernance\System\Contracts\GovernanceEscalationStoreContract;
use App\Extensions\TitanGovernance\System\Escalation\GovernanceEscalationTarget;

final class GASDecisionStore implements GovernanceActionDecisionStoreContract{
 public array $byOp=[]; public array $byId=[];
 public function claim(GovernanceActionRequest $r):array{
  $k=$r->tenantCompanyId.'|'.$r->operationId;
  if(isset($this->byOp[$k])){ $x=$this->byOp[$k]; if($x['payload_hash']!==$r->payloadHash())return ['status'=>'IDEMPOTENCY_CONFLICT','decision_id'=>$x['decision_id'],'reason_code'=>'OPERATION_ID_PAYLOAD_CONFLICT']; return ['status'=>'REPLAYED','decision_id'=>$x['decision_id'],'command_status'=>$x['command_status'],'result'=>$x['result_payload']]; }
  $id='gdec-'.(count($this->byOp)+1);$x=['decision_id'=>$id,'tenant_company_id'=>$r->tenantCompanyId,'operation_id'=>$r->operationId,'subject_id'=>$r->escalationId,'action'=>$r->action,'payload_hash'=>$r->payloadHash(),'command_status'=>'PENDING_DISPATCH','result_payload'=>[]];$this->byOp[$k]=$x;$this->byId[$id]=$x;return ['status'=>'CLAIMED','decision_id'=>$id,'command_status'=>'PENDING_DISPATCH'];
 }
 public function finalize(string $decisionId,array $result):array{foreach($this->byOp as $k=>$x)if($x['decision_id']===$decisionId){$x['command_status']=$result['status'];$x['result_payload']=$result;$this->byOp[$k]=$x;$this->byId[$decisionId]=$x;return $x;}throw new RuntimeException('missing');}
 public function findDecision(string $decisionId):?array{return $this->byId[$decisionId]??null;}
}
final class GASGateway implements GovernanceCommandGatewayContract{public int $calls=0;public function __construct(public array $response){}public function health():array{return ['status'=>strtoupper((string)($this->response['status']??''))==='UNAVAILABLE'?'UNAVAILABLE':'HEALTHY'];}public function dispatch(array $command):array{$this->calls++;$r=$this->response;$r['operation_id']=$command['operation_id'];if(!array_key_exists('governance_decision_ref',$r))$r['governance_decision_ref']=$command['governance']['decision_ref'];return $r;}}
final class GASEscalationStore implements GovernanceEscalationStoreContract{
 public array $row=['escalation_id'=>'esc-123','tenant_company_id'=>42,'status'=>'OPEN','version'=>2,'risk_score'=>80.0,'urgency'=>90,'opened_at'=>'2026-08-20T10:00:00+10:00'];
 public function queue(int $tenantCompanyId,int $limit=50):array{return [$this->row];}public function find(int $tenantCompanyId,string $escalationId):?array{return $tenantCompanyId===(int)$this->row['tenant_company_id']&&$escalationId===$this->row['escalation_id']?$this->row:null;}
 public function applyTransition(int $tenantCompanyId,string $escalationId,int $expectedVersion,string $nextStatus,string $resolutionAction,string $decisionId,string $commandReceiptRef):array{if($expectedVersion!==$this->row['version'])throw new RuntimeException('ESCALATION_VERSION_CONFLICT');$this->row['status']=$nextStatus;$this->row['resolution_action']=$resolutionAction;$this->row['last_decision_id']=$decisionId;$this->row['last_command_receipt_ref']=$commandReceiptRef?:null;$this->row['version']++;return $this->row;}
}

$causal=['trace_id'=>'t1','correlation_id'=>'c1','causation_id'=>'z1','root_causation_id'=>'r1'];
$client=['operation_id'=>'operation-0001','action'=>'APPROVE','escalation_id'=>'esc-123','expected_version'=>2,'reason_codes'=>['HUMAN_REVIEW_COMPLETE'],'evidence_refs'=>['rewind://abc']];
$request=GovernanceActionRequest::fromClient($client,42,'user:7',$causal);

$store=new GASDecisionStore();$unavailable=new GASGateway(['status'=>'UNAVAILABLE','reason_code'=>'COMMAND_BUS_UNAVAILABLE']);$service=new GovernanceActionService($store,$unavailable,new GovernanceCommandReceiptValidator());
$blocked=$service->execute($request);same_gas('BLOCKED',$blocked['status'],'unavailable Command Bus must block');same_gas(1,$unavailable->calls,'unavailable gateway called once');
$unavailable->response=['status'=>'APPLIED','command_receipt_ref'=>'cmd://receipt/retry','authoritative_domain_receipt_ref'=>'governance://escalations/esc-123/versions/3','write_verified'=>true,'adapter'=>'titan-governance.escalation-target'];
$retried=$service->execute($request);same_gas('APPLIED',$retried['status'],'retryable Command Bus outage must redispatch same operation');same_gas(2,$unavailable->calls,'retryable replay must redispatch exactly once');same_gas('cmd://receipt/retry',$retried['command_receipt_ref'],'retried receipt retained');
$replay=$service->execute($request);same_gas('REPLAYED',$replay['status'],'completed same request must replay recorded result');same_gas(2,$unavailable->calls,'completed replay must not redispatch');

$store2=new GASDecisionStore();$goodGateway=new GASGateway(['status'=>'APPLIED','command_receipt_ref'=>'cmd://receipt/1','authoritative_domain_receipt_ref'=>'governance://escalations/esc-123/versions/3','write_verified'=>true,'adapter'=>'titan-governance.escalation-target']);$goodService=new GovernanceActionService($store2,$goodGateway,new GovernanceCommandReceiptValidator());
$applied=$goodService->execute($request);same_gas('APPLIED',$applied['status'],'verified applied receipt accepted');same_gas('cmd://receipt/1',$applied['command_receipt_ref'],'receipt reference retained');

$storeBlocked=new GASDecisionStore();$blockedGateway=new GASGateway(['status'=>'BLOCKED','reason_code'=>'RISK_DENIED','governance_decision_ref'=>null]);$blockedEarly=(new GovernanceActionService($storeBlocked,$blockedGateway,new GovernanceCommandReceiptValidator()))->execute($request);same_gas('BLOCKED',$blockedEarly['status'],'early Command Bus refusal without governance echo must remain truthful');same_gas('RISK_DENIED',$blockedEarly['reason_code'],'early refusal reason retained');

$store3=new GASDecisionStore();$badGateway=new GASGateway(['status'=>'APPLIED','command_receipt_ref'=>'cmd://receipt/2','write_verified'=>true,'adapter'=>'titan-governance.escalation-target']);$bad=(new GovernanceActionService($store3,$badGateway,new GovernanceCommandReceiptValidator()))->execute($request);same_gas('FAILED',$bad['status'],'applied without authoritative domain receipt must be invalid');same_gas('COMMAND_RECEIPT_INVALID',$bad['reason_code'],'invalid receipt reason');

$conflictClient=$client;$conflictClient['reason_codes']=['DIFFERENT_REASON'];$conflict=GovernanceActionRequest::fromClient($conflictClient,42,'user:7',$causal);$conflictResult=$goodService->execute($conflict);same_gas('IDEMPOTENCY_CONFLICT',$conflictResult['status'],'same operation with different payload rejected');same_gas(1,$goodGateway->calls,'collision must not redispatch');

$targetStore=new GASEscalationStore();$targetDecisions=new GASDecisionStore();$claim=$targetDecisions->claim($request);$decisionId=$claim['decision_id'];$target=new GovernanceEscalationTarget($targetStore,$targetDecisions);$envelope=$request->commandEnvelope($decisionId);$targetResult=$target->apply($envelope,['command_execution_ref'=>'cmdexec-1']);same_gas('APPLIED',$targetResult['status'],'target applies valid transition');same_gas('APPROVED',$targetStore->row['status'],'approve transition state');same_gas(3,$targetStore->row['version'],'version increment');assert_gas($targetResult['write_verified']===true,'target must independently verify write');

$stale=$target->apply($envelope,['command_execution_ref'=>'cmdexec-2']);same_gas('BLOCKED',$stale['status'],'stale version must block');same_gas('ESCALATION_VERSION_CONFLICT',$stale['reason_code'],'stale reason explicit');

echo "PASS: Governance governed action service contract\n";
