<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function fail_csrc(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);} function ok_csrc(bool $c,string $m):void{if(!$c)fail_csrc($m);} function same_csrc(mixed $e,mixed $a,string $m):void{if($e!==$a)fail_csrc($m.' expected='.var_export($e,true).' actual='.var_export($a,true));}
foreach(['/System/Contracts/GovernanceReadSourceContract.php','/System/ReadPlane/GovernanceReadSourceRegistry.php','/System/ControlCentre/ControlCentreSourceReader.php','/System/ControlCentre/EvidenceFreshnessProjector.php'] as $f){if(!is_file($root.$f))fail_csrc('missing '.$f);require_once $root.$f;}

use App\Extensions\TitanGovernance\System\Contracts\GovernanceReadSourceContract;
use App\Extensions\TitanGovernance\System\ReadPlane\GovernanceReadSourceRegistry;
use App\Extensions\TitanGovernance\System\ControlCentre\ControlCentreSourceReader;
use App\Extensions\TitanGovernance\System\ControlCentre\EvidenceFreshnessProjector;

final class CsrcHealthy implements GovernanceReadSourceContract{public function __construct(private string $key,private bool $required,private array $payload){} public function key():string{return $this->key;}public function required():bool{return $this->required;}public function snapshot(int $tenantCompanyId,array $context=[]):array{return $this->payload+['tenant_company_id'=>$tenantCompanyId];}}
final class CsrcWrongTenant implements GovernanceReadSourceContract{public function key():string{return 'wrong';}public function required():bool{return false;}public function snapshot(int $tenantCompanyId,array $context=[]):array{return ['status'=>'HEALTHY','tenant_company_id'=>$tenantCompanyId+1,'observed_at'=>'2026-08-21T02:00:00+10:00','control_centre'=>[]];}}
final class CsrcThrows implements GovernanceReadSourceContract{public function key():string{return 'throws';}public function required():bool{return false;}public function snapshot(int $tenantCompanyId,array $context=[]):array{throw new RuntimeException('boom');}}
$r=new GovernanceReadSourceRegistry();
$r->register(new CsrcHealthy('good',true,['status'=>'HEALTHY','observed_at'=>'2026-08-21T02:00:00+10:00','control_centre'=>['models'=>[['model_id'=>'m1']]] ]));
$r->register(new CsrcWrongTenant());$r->register(new CsrcThrows());
$reader=new ControlCentreSourceReader($r);
$s=$reader->all(42,['now'=>'2026-08-21T02:02:00+10:00']);
same_csrc('HEALTHY',$s['good']['status'],'healthy source');same_csrc('INVALID',$s['wrong']['status'],'wrong tenant must be invalid');same_csrc('IDENTITY_MISMATCH',$s['wrong']['reason'],'identity mismatch reason');same_csrc('UNAVAILABLE',$s['throws']['status'],'throw isolated');same_csrc('SOURCE_READ_FAILED',$s['throws']['reason'],'throw reason');
$f=new EvidenceFreshnessProjector();
$rows=$f->project([
 ['source'=>'fresh','required'=>true,'observed_at'=>'2026-08-21T02:01:30+10:00'],
 ['source'=>'stale','required'=>true,'observed_at'=>'2026-08-21T01:00:00+10:00'],
 ['source'=>'unknown','required'=>false,'observed_at'=>null],
 ['source'=>'bad','required'=>false,'observed_at'=>'not-a-date'],
],['now'=>'2026-08-21T02:02:00+10:00','fresh_after_seconds'=>300]);
$by=[];foreach($rows['items'] as $row)$by[$row['source']]=$row;
same_csrc('FRESH',$by['fresh']['freshness'],'freshness fresh');same_csrc('STALE',$by['stale']['freshness'],'freshness stale');same_csrc('UNKNOWN',$by['unknown']['freshness'],'missing timestamp unknown');same_csrc('INVALID',$by['bad']['freshness'],'malformed timestamp invalid');same_csrc('DEGRADED',$rows['status'],'required stale evidence degrades freshness');
echo "PASS: Governance control centre source/freshness contract\n";
