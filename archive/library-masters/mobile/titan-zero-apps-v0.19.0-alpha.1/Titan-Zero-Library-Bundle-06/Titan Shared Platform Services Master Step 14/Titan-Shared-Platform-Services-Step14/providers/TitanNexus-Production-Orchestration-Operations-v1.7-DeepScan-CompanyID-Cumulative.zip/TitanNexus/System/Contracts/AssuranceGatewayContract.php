<?php

declare(strict_types=1);
namespace App\Extensions\TitanNexus\System\Contracts;
use App\Extensions\TitanNexus\System\Domain\AssuranceDecision;
use App\Extensions\TitanNexus\System\Domain\AutonomyDecision;
use App\Extensions\TitanNexus\System\Domain\GovernanceDecision;
use App\Extensions\TitanNexus\System\Domain\ProvisioningExecutionContext;
use App\Extensions\TitanNexus\System\Domain\ProvisioningOperation;
use App\Extensions\TitanNexus\System\Domain\RiskDecision;
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
interface AssuranceGatewayContract { public function verify(ProvisioningOperation $operation, TraceContext $traceContext, ProvisioningExecutionContext $executionContext, RiskDecision $riskDecision, GovernanceDecision $governanceDecision, ?AutonomyDecision $autonomyDecision): AssuranceDecision; }
