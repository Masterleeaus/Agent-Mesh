<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix='App\\Extensions\\TitanAutonomy\\'; if(!str_starts_with($class,$prefix))return;
    $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($prefix))).'.php'; if(is_file($path))require_once $path;
});

use App\Extensions\TitanAutonomy\System\Contracts\{AutonomyAuditSinkContract,AutonomyQueryContract,CapabilityStateStoreContract,ExecutionReceiptStoreContract,LearningSinkContract};
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Services\{AutonomyRuntimeService,ExecutionFeedbackService,GateEvaluator};

$stateStore=new class implements CapabilityStateStoreContract{public ?CapabilityState $saved=null;public function save(CapabilityState $s):void{$this->saved=$s;}};
$learning=new class implements LearningSinkContract{public array $events=[];public function record(array $e):string{$this->events[]=$e;return 'L'.count($this->events);}};
$audit=new class implements AutonomyAuditSinkContract{public array $reg=[];public function recordGateDecision(array $d):string{return 'G1';}public function recordHandshake(array $h):string{return 'H1';}public function recordRegression(array $r):string{$this->reg[]=$r;return 'R'.count($this->reg);}};
$runtime=new AutonomyRuntimeService($stateStore,$learning,$audit,new GateEvaluator(['low'=>1,'medium'=>2,'high'=>3,'critical'=>3],['low'=>'trusted_auto','medium'=>'trusted_auto','high'=>'auto','critical'=>'semi_auto']),'test-policy');
$query=new class implements AutonomyQueryContract{
 public array $row=['tenant_company_id'=>42,'capability'=>'crm.invoice.issue','workflow_key'=>'completed_job_invoice','risk'=>'medium','current_level'=>'trusted_auto','required_success_streak'=>2,'current_success_streak'=>2,'highest_success_streak'=>5,'total_successes'=>20,'total_failures'=>0,'total_edits'=>0,'total_rejections'=>0,'total_reversals'=>0,'platform_gate_eligible'=>false,'scope'=>['max_total'=>1500]];
 public function capabilityStates(int $t):array{return[$this->row];}public function capabilityState(int $t,string $c,string $w):?array{return $this->row;}public function learningEvents(int $t,?string $c=null,?string $w=null,int $l=1000):array{return [];}public function learningPreferences(int $t,?int $u=null):array{return [];}public function learningSettings(int $t):array{return ['user_learning'=>true,'business_learning'=>true,'system_wide_learning'=>false];}public function tenantPolicy(int $t):?array{return null;}public function platformPolicy():?array{return null;}public function handshakes(int $t,?string $c=null,?string $w=null,int $l=100):array{return [];}public function regressions(int $t,?string $c=null,?string $w=null,int $l=100):array{return [];} };
$receipts=new class implements ExecutionReceiptStoreContract{
 public array $row=['public_id'=>'E1','tenant_company_id'=>42,'user_id'=>7,'capability'=>'crm.invoice.issue','workflow_key'=>'completed_job_invoice','risk'=>'medium','autonomy_level'=>'trusted_auto','correlation_id'=>'corr-f','command_payload'=>['total_minor'=>50000],'command_result'=>['status'=>'executed'],'context'=>['workflow'=>'completed_job_invoice'],'observation_status'=>'finalized','final_label'=>'correct'];
 public int $feedback=0; public function create(array $r):string{return'E2';}public function findByCorrelation(int $t,string $c):?array{return $t===42&&$c==='corr-f'?$this->row:null;}public function due(int $l=100):array{return [];}public function finalize(string $id,array $f):void{$this->row=array_merge($this->row,$f,['observation_status'=>'finalized']);}public function appendFeedback(string $id,array $f):string{$this->feedback++;return'F'.$this->feedback;}
};
$svc=new ExecutionFeedbackService($receipts,$query,$runtime,'test-policy');
try{$svc->record(42,7,'corr-f','approved_unchanged',[]);throw new RuntimeException('forged positive feedback was accepted');}catch(InvalidArgumentException $e){}
$r=$svc->record(42,7,'corr-f','reversed',['reason'=>'wrong invoice']);
if(($r['learning_label']??null)!=='reversed'||$stateStore->saved?->currentLevel!==AutonomyLevel::SemiAuto||$receipts->feedback!==1)throw new RuntimeException('reversal must create negative learning and severe capability-local regression');
$before=count($learning->events);$r=$svc->record(42,7,'corr-f','reversed',['reason'=>'duplicate click']);
if(($r['duplicate']??false)!==true||count($learning->events)!==$before||$receipts->feedback!==1)throw new RuntimeException('duplicate same negative classification must not double count evidence');

echo "OK: ExecutionFeedbackServiceSmokeTest\n";
