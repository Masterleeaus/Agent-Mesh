@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',[
    'title'=>$company['name'],
    'subtitle'=>trim(($company['email'] ?? '').(($company['phone'] ?? null) ? ' · '.$company['phone'] : '')),
    'surface'=>'customers',
    'journey'=>'new-contact',
    'secondaryJourneys'=>['new-job','new-quote'],
    'recordType'=>'customer',
    'context'=>['record_type'=>'customer','public_id'=>$company['public_id'],'customer_kind'=>'business','company_public_id'=>$company['public_id']],
])
<div class="d-flex justify-content-between align-items-center mb-4">
    <a href="{{ route('dashboard.user.crm.companies.index') }}" class="small">← Customers</a>
    <a class="btn btn-outline-primary" href="{{ route('dashboard.user.crm.timeline.show',['company',$company['public_id']]) }}">Timeline</a>
</div>
@if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif
<div class="row g-4">
    <div class="col-lg-4">
        <div class="card mb-4"><div class="card-header"><strong>Customer details</strong></div><div class="card-body"><dl class="mb-0"><dt>Status</dt><dd>{{ ucfirst($company['status'] ?? 'active') }}</dd><dt>Website</dt><dd>{{ $company['website'] ?? '—' }}</dd><dt>Address</dt><dd>{{ $company['address'] ?? '—' }}</dd></dl></div></div>
        <div class="card"><div class="card-header"><strong>Edit customer</strong></div><div class="card-body"><form method="post" action="{{ route('dashboard.user.crm.companies.update',$company['public_id']) }}" class="row g-3">@csrf @method('PATCH')<div class="col-12"><label class="form-label">Name</label><input class="form-control" name="name" required value="{{ $company['name'] }}"></div><div class="col-12"><label class="form-label">Legal name</label><input class="form-control" name="legal_name" value="{{ $company['legal_name'] ?? '' }}"></div><div class="col-12"><label class="form-label">Email</label><input class="form-control" type="email" name="email" value="{{ $company['email'] ?? '' }}"></div><div class="col-12"><label class="form-label">Phone</label><input class="form-control" name="phone" value="{{ $company['phone'] ?? '' }}"></div><div class="col-12"><label class="form-label">Website</label><input class="form-control" name="website" value="{{ $company['website'] ?? '' }}"></div><div class="col-12"><button class="btn btn-primary">Save customer</button></div></form></div></div>
    </div>
    <div class="col-lg-8">
        <div class="card mb-4"><div class="card-header"><strong>Contacts</strong></div><div class="table-responsive"><table class="table mb-0"><tbody>@forelse($contacts as $contact)<tr><td><a href="{{ route('dashboard.user.crm.contacts.show',$contact['public_id']) }}">{{ trim(($contact['first_name'] ?? '').' '.($contact['last_name'] ?? '')) }}</a></td><td>{{ $contact['email'] ?? '—' }}</td><td>{{ $contact['role'] ?? '—' }}</td></tr>@empty<tr><td class="text-muted">No contacts.</td></tr>@endforelse</tbody></table></div></div>
        <div class="card"><div class="card-header"><strong>Opportunities</strong></div><div class="table-responsive"><table class="table mb-0"><tbody>@forelse($deals as $deal)<tr><td><a href="{{ route('dashboard.user.crm.deals.show',$deal['public_id']) }}">{{ $deal['title'] }}</a></td><td>{{ ucfirst($deal['status']) }}</td><td class="text-end">{{ $deal['currency'] ?? 'AUD' }} {{ number_format(($deal['value_minor'] ?? 0)/100,2) }}</td></tr>@empty<tr><td class="text-muted">No opportunities.</td></tr>@endforelse</tbody></table></div></div>
    </div>
</div>
@endcomponent
@endsection
