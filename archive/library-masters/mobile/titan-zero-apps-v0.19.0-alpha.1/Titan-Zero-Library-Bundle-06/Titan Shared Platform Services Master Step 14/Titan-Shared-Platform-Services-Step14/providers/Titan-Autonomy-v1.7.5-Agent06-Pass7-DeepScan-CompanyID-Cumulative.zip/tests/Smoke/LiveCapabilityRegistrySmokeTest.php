<?php
declare(strict_types=1);
spl_autoload_register(function(string $class):void{ $p='App\\Extensions\\TitanAutonomy\\'; if(!str_starts_with($class,$p))return; $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($path))require_once $path; });
use App\Extensions\TitanAutonomy\System\Services\LiveGovernedCapabilityRegistry;
$r=new LiveGovernedCapabilityRegistry();
foreach(['crm.customer.create','crm.work_order.create','crm.work_order.assign','crm.work_order.reschedule','crm.invoice.create','crm.invoice.issue','crm.quote.create','crm.payment.record'] as $c){if(!$r->has($c))throw new RuntimeException("missing verified capability $c");}
if($r->has('crm.invoice.send'))throw new RuntimeException('must not expose guessed crm.invoice.send when installed CRM publishes crm.invoice.issue');
if($r->has('crm.work_order.complete'))throw new RuntimeException('must not expose stale Interaction-only action absent from CRM alpha.14');
if(($r->profile('crm.payment.record')['risk']??null)!=='critical')throw new RuntimeException('money-record capability must be critical');
if(($r->profile('crm.invoice.create')['journey_key']??null)!=='new-invoice')throw new RuntimeException('invoice create must use verified CRM new-invoice journey');
if(array_key_exists('journey_key',$r->profile('crm.invoice.issue')) && $r->profile('crm.invoice.issue')['journey_key']!==null)throw new RuntimeException('invoice issue has no published CRM Interaction journey in alpha.14');
if(($r->profile('crm.work_order.assign')['journey_key']??null)!=='new-dispatch-assignment')throw new RuntimeException('dispatch assignment must use verified CRM journey');
echo "OK: LiveCapabilityRegistrySmokeTest\n";
