<?php

declare(strict_types=1);

use App\Extensions\TitanNexus\System\Adapters\Platform\PlatformReadinessAdapter;
use App\Extensions\TitanNexus\System\Domain\BusinessProfile;
use App\Extensions\TitanNexus\System\Domain\ValidationFinding;
use App\Extensions\TitanNexus\System\Domain\ValidationResult;
use App\Extensions\TitanNexus\System\Domain\ValidationSeverity;
use App\Extensions\TitanNexus\System\Domain\VerticalDefinition;
use App\Extensions\TitanNexus\System\Services\SemanticNexusValidator;

$root = dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { if (is_file($root.$support)) require_once $root.$support; }
$files = [
    '/System/Support/CanonicalJson.php',
    '/System/Domain/BusinessProfile.php',
    '/System/Domain/ValidationSeverity.php',
    '/System/Domain/ValidationFinding.php',
    '/System/Domain/ValidationResult.php',
    '/System/Domain/VerticalDefinition.php',
    '/System/Contracts/PlatformReadinessSourceContract.php',
    '/System/Contracts/NexusValidatorContract.php',
    '/System/Adapters/Platform/PlatformReadinessAdapter.php',
    '/System/Services/SemanticNexusValidator.php',
];
foreach ($files as $file) {
    $path = $root . $file;
    if (!is_file($path)) {
        fwrite(STDERR, "FAIL: missing validation production class file {$file}\n");
        exit(1);
    }
    require_once $path;
}

function validationCheck(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

$findingA = new ValidationFinding('profile.required', ValidationSeverity::Error, 'sections.workforce.roles', 'Required profile value is missing.', 'nexus.semantic');
$findingB = new ValidationFinding('profile.recommended', ValidationSeverity::Warning, 'sections.operations.service_area', 'Recommended profile value is missing.', 'nexus.semantic');
$resultA = ValidationResult::fromFindings([$findingB, $findingA]);
$resultB = ValidationResult::fromFindings([$findingA, $findingB]);
validationCheck($resultA->fingerprint() === $resultB->fingerprint(), 'validation result must be deterministic regardless of insertion order');
validationCheck($resultA->hasErrors(), 'error finding must block validation');
validationCheck(count($resultA->warnings()) === 1, 'warning classification must be retained');
validationCheck(ValidationResult::fromArray($resultA->toArray())->fingerprint() === $resultA->fingerprint(), 'validation result must round-trip');

$profile = BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '3.0.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['country_code' => 'AU', 'region' => 'VIC'],
    'timezone' => 'Australia/Melbourne',
    'sections' => [
        'workforce' => ['roles' => ['cleaner']],
        'integrations' => ['api_key' => 'must-not-be-here'],
    ],
]);
$definition = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => null,
    'sections' => ['operations' => ['recurring' => true]],
    'validation' => [
        'required_profile_paths' => ['sections.workforce.roles', 'sections.billing.currency'],
        'recommended_profile_paths' => ['sections.operations.service_area'],
        'required_platform_capabilities' => ['crm.customer.read', 'workforce.worker.read'],
        'require_knowledge_snapshot' => true,
    ],
]);
$readiness = new PlatformReadinessAdapter(null, ['crm.customer.read']);
$validator = new SemanticNexusValidator($readiness);
$validation = $validator->validate($profile, $definition);
$codes = array_map(static fn (array $finding): string => $finding['code'], $validation->toArray()['findings']);
validationCheck(in_array('profile.required', $codes, true), 'missing required profile path must be an error');
validationCheck(in_array('profile.recommended', $codes, true), 'missing recommended profile path must be a warning');
validationCheck(in_array('platform.capability.missing', $codes, true), 'missing platform capability must be an error');
validationCheck(in_array('knowledge.snapshot.required', $codes, true), 'required knowledge snapshot must be enforced');
validationCheck(in_array('secret.material.forbidden', $codes, true), 'secret material must be rejected from profile sections');
validationCheck($validation->hasErrors(), 'semantic errors must block validation');

$definitionNoValidationA = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => ['operations' => ['recurring' => true]],
]);
$definitionNoValidationB = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => ['operations' => ['recurring' => true]],
    'validation' => [],
]);
validationCheck($definitionNoValidationA->fingerprint() === $definitionNoValidationB->fingerprint(), 'empty validation metadata must not change Pass-2 vertical fingerprint');

$validationOrderA = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => [],
    'validation' => [
        'required_profile_paths' => ['sections.workforce.roles', 'sections.billing.currency'],
        'recommended_profile_paths' => ['sections.operations.service_area', 'sections.operations.hours'],
        'required_platform_capabilities' => ['workforce.worker.read', 'crm.customer.read'],
        'require_knowledge_snapshot' => true,
    ],
]);
$validationOrderB = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => [],
    'validation' => [
        'require_knowledge_snapshot' => true,
        'required_platform_capabilities' => ['crm.customer.read', 'workforce.worker.read'],
        'recommended_profile_paths' => ['sections.operations.hours', 'sections.operations.service_area'],
        'required_profile_paths' => ['sections.billing.currency', 'sections.workforce.roles'],
    ],
]);
validationCheck($validationOrderA->fingerprint() === $validationOrderB->fingerprint(), 'validation rule ordering must not change vertical definition fingerprint');

$readinessFailure = new PlatformReadinessAdapter(static function (array $capabilities): array {
    throw new RuntimeException('registry unavailable');
}, []);
$validatorFailure = new SemanticNexusValidator($readinessFailure);
$failureDefinition = VerticalDefinition::fromArray([
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'knowledge_snapshot_version' => 'au-vic-2026.08',
    'sections' => [],
    'validation' => ['required_platform_capabilities' => ['crm.customer.read']],
]);
$failureProfile = BusinessProfile::fromArray([
    'tenant_company_id' => 42,
    'profile_version' => '3.0.0',
    'vertical_id' => 'cleaning',
    'vertical_version' => '2026.08',
    'jurisdiction' => ['country_code' => 'AU'],
    'timezone' => 'Australia/Melbourne',
    'sections' => [],
]);
$failureResult = $validatorFailure->validate($failureProfile, $failureDefinition);
validationCheck(in_array('platform.readiness.unavailable', array_column($failureResult->toArray()['findings'], 'code'), true), 'readiness source exception must fail closed as a structured error');

fwrite(STDOUT, "PASS: Titan Nexus standalone validation checks\n");
