# Registry Governance

Titan Signal treats event-type and subscription registries as privileged control-plane state.

## Identity and ownership

Registry writes require a host-attested `SignalRegistryIdentity` issued through `SignalRegistryAuthorityContract`.

A registry identity contains:

- stable service ID
- canonical owner source
- registry permissions
- allowed event-type families
- allowed subscriber-key families
- host attestation

Normal registrars may modify only their own namespaces. A separately configured `signal.registry.override` actor may perform governed recovery, but no wildcard override actor ships by default.

## Event type definitions

`titan_signal_type_versions` is append-only. Each `(event_type, definition_version)` is immutable.

- `register()` creates version 1 only.
- `evolve()` creates the next version.
- current schema versions cannot move backwards.
- previously supported event schema versions cannot be silently removed.
- `owner_source` cannot change across definition versions.
- ownership is recorded separately from the registrar that performed the change.

The original `titan_signal_types` table remains a legacy compatibility source and migration donor; new writes use the versioned registry.

## Subscription definitions

`titan_signal_subscription_versions` stores immutable subscriber definitions. Runtime state is deliberately separate in `titan_signal_subscription_runtime`.

Runtime state can be:

- active
- paused
- disabled
- quarantined

Lifecycle state is independently tracked as installed/uninstalled.

A missing or invalid handler is quarantined and skipped. Discovery never throws merely because one stored subscriber definition is broken. This prevents subscription drift from rolling back otherwise valid Signal ingestion.

`revalidate()` can restore a quarantined subscriber after its handler is repaired. `markUninstalled()` disables delivery without deleting definition history.

## Legacy ownership claims

Pass 2 backfills legacy definitions with `legacy:*` owner IDs. The first authenticated evolution may claim a legacy definition only through an identity that controls the relevant event/subscriber namespace. After claim, ordinary cross-owner takeover is rejected.
