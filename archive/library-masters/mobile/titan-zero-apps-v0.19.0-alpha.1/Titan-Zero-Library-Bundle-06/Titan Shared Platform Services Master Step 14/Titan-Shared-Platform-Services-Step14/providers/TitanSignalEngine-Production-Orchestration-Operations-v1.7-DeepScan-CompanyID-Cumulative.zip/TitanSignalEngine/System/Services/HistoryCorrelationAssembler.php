<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Data\SignalHistoryRecord;
use InvalidArgumentException;

final class HistoryCorrelationAssembler
{
    /** @param list<SignalHistoryRecord> $records @return list<SignalEnvelope> */
    public function envelopes(array $records): array
    {
        $envelopes = [];
        foreach ($records as $record) {
            if (! $record instanceof SignalHistoryRecord) {
                throw new InvalidArgumentException('Correlation history requires SignalHistoryRecord values.');
            }
            $envelopes[] = SignalEnvelope::fromPersistenceArray($record->event);
        }
        return $this->causalOrder($envelopes);
    }

    /**
     * @param list<SignalHistoryRecord> $records
     * @return list<array{parent_event_id:string,child_event_id:string,parent_storage_tier:?string,child_storage_tier:string,resolved_in_result:bool}>
     */
    public function edges(array $records): array
    {
        $tierById = [];
        $events = [];
        foreach ($records as $record) {
            if (! $record instanceof SignalHistoryRecord) {
                throw new InvalidArgumentException('Correlation history requires SignalHistoryRecord values.');
            }
            $eventId = (string) ($record->event['event_id'] ?? '');
            if ($eventId === '') continue;
            $tierById[$eventId] = $record->storageTier;
            $events[] = $record;
        }

        $edges = [];
        foreach ($events as $record) {
            $childId = (string) ($record->event['event_id'] ?? '');
            $parentId = isset($record->event['causation_id']) && $record->event['causation_id'] !== null
                ? (string) $record->event['causation_id']
                : '';
            if ($childId === '' || $parentId === '') continue;
            $edges[] = [
                'parent_event_id' => $parentId,
                'child_event_id' => $childId,
                'parent_storage_tier' => $tierById[$parentId] ?? null,
                'child_storage_tier' => $record->storageTier,
                'resolved_in_result' => isset($tierById[$parentId]),
            ];
        }

        usort($edges, static fn (array $a, array $b): int => strcmp($a['child_event_id'], $b['child_event_id']));
        return $edges;
    }

    /** @param list<SignalHistoryRecord> $records @return array<string,array<string,mixed>> */
    public function storageIndex(array $records): array
    {
        $index = [];
        foreach ($records as $record) {
            if (! $record instanceof SignalHistoryRecord) {
                throw new InvalidArgumentException('Correlation history requires SignalHistoryRecord values.');
            }
            $eventId = (string) ($record->event['event_id'] ?? '');
            if ($eventId === '') continue;
            $index[$eventId] = [
                'storage_tier' => $record->storageTier,
                'archive_verified' => $record->archiveVerified,
                'canonical_checksum_verified' => $record->canonicalChecksumVerified,
                'privacy_projected' => $record->archive?->privacyProjected ?? false,
                'archive_batch_id' => $record->archive?->batchId,
            ];
        }
        return $index;
    }

    /** @param list<SignalEnvelope> $events @return list<SignalEnvelope> */
    private function causalOrder(array $events): array
    {
        $byId = [];
        foreach ($events as $event) $byId[$event->eventId] = $event;

        $children = [];
        $indegree = [];
        foreach ($events as $event) $indegree[$event->eventId] = 0;
        foreach ($events as $event) {
            if ($event->causationId !== null && isset($byId[$event->causationId])) {
                $children[$event->causationId][] = $event->eventId;
                $indegree[$event->eventId]++;
            }
        }

        $queue = [];
        foreach ($events as $event) if (($indegree[$event->eventId] ?? 0) === 0) $queue[] = $event;
        $sort = static function (SignalEnvelope $a, SignalEnvelope $b): int {
            $occurred = $a->occurredAt <=> $b->occurredAt;
            if ($occurred !== 0) return $occurred;
            $recorded = $a->recordedAt <=> $b->recordedAt;
            return $recorded !== 0 ? $recorded : strcmp($a->eventId, $b->eventId);
        };
        usort($queue, $sort);

        $ordered = [];
        while ($queue !== []) {
            /** @var SignalEnvelope $next */
            $next = array_shift($queue);
            $ordered[] = $next;
            foreach ($children[$next->eventId] ?? [] as $childId) {
                $indegree[$childId]--;
                if ($indegree[$childId] === 0) {
                    $queue[] = $byId[$childId];
                    usort($queue, $sort);
                }
            }
        }

        if (count($ordered) !== count($events)) {
            $remaining = array_filter($events, static fn (SignalEnvelope $event): bool => ! in_array($event, $ordered, true));
            usort($remaining, $sort);
            array_push($ordered, ...$remaining);
        }

        return $ordered;
    }
}
