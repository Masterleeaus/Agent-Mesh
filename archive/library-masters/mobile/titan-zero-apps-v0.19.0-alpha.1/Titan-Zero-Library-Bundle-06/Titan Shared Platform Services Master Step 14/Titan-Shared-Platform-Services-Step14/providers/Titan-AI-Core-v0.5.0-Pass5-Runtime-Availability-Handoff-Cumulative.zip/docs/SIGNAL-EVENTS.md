# Signal Events

v0.4.0 propagates trace, correlation, causation and root-causation identifiers through the typed runtime context, but emits no operational plan lifecycle Signals yet. Signal emission begins in the dedicated observability pass after governed execution foundations exist.
