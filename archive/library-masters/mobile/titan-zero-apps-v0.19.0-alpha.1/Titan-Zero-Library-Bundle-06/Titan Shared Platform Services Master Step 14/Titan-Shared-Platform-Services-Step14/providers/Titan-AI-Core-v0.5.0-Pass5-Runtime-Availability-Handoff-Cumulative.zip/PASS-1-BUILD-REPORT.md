# Titan AI Core v0.2.0 — Pass 1 Build Report

## Scope

Installer and host hardening only. This release intentionally does not implement AI execution authority.

## Implemented

1. Fixed model-profile uniqueness for utf8mb4/MySQL and nullable global scope ambiguity, including a forward repair migration for existing v0.1.0 tables.
2. Added explicit migration rollback support while preserving retain-on-uninstall behavior.
3. Added honest capability/queue metadata so unimplemented systems are not advertised as live.
4. Added Blueprint-v3 navigation definitions and adaptive host registry integration.
5. Added explicit host-sync/menu cache lifecycle command.
6. Added host-layout resolver plus a standalone fallback layout.
7. Added runtime health service, admin health endpoint and diagnostic command.
8. Upgraded the feature boot test to use the host Laravel TestCase and assert bindings/routes/views.
9. Added a standalone package hardening regression gate.

## Deliberate boundaries

- Plan validation remains fail-closed.
- No command/domain mutation path exists.
- No queue jobs exist or are advertised as active.
- No model routing or simulation capability is advertised as implemented.
- Navigation compatibility can fail without preventing runtime boot.

## Next

v0.3.0 — typed execution intent, plan, step, constraint, validation, simulation, delegation, receipt and failure envelopes.
