# Titan Nexus Runtime Readiness

Titan Nexus separates **packaged capabilities** from **runtime-available capabilities**.

`extension.manifest.json.capabilities` declares code/contracts shipped by the extension. `NexusManager::health()` projects which of those capabilities are usable in the current host based on dependency readiness.

## Dependency policy

| Dependency | Requirement | Health tier | Effect when unavailable |
|---|---|---|---|
| Database | required | core | `UNAVAILABLE`; durable compile/history unavailable |
| Titan Vertical Engine | required | core | `UNAVAILABLE`; compile/validate/preview unavailable |
| Titan Command Bus | required | execution | `DEGRADED`; provisioning execution unavailable |
| Titan Risk | required | execution | `DEGRADED`; provisioning execution unavailable |
| Titan Governance | required | execution | `DEGRADED`; provisioning execution unavailable |
| Titan Assurance | required | execution | `DEGRADED`; provisioning execution unavailable |
| Titan Signal | required | execution | `DEGRADED`; governed execution unavailable |
| Titan Rewind | required | execution | `DEGRADED`; governed execution unavailable |
| Titan Autonomy | conditional | conditional | human execution remains available; agent/system execution unavailable |
| Titan Knowledge Authority | conditional | conditional | non-knowledge-gated compilation remains available; knowledge-gated mode unavailable |
| Titan Interface Runtime | optional | optional | Nexus host routes remain available; Interface Runtime read-model integration unavailable |

## Health statuses

- `HEALTHY` — core and required human-execution dependencies are available.
- `DEGRADED` — core compile/history is available but one or more required execution dependencies are unavailable.
- `UNAVAILABLE` — database or Vertical Engine core readiness is unavailable.
- `DISABLED` — Nexus is disabled in configuration; no runtime capabilities are advertised as available.

Conditional/optional integrations remain visible in `unavailable_dependencies` but do not downgrade an otherwise healthy human-execution runtime.

## Runtime capability projection

Health includes:

- `dependencies` — configured/bound/callable/available state plus requirement/tier and reason;
- `missing_dependencies` — unavailable **required** dependencies only;
- `unavailable_dependencies` — all unavailable required, conditional and optional dependencies;
- `available_capabilities` — packaged capabilities whose runtime requirements are currently satisfied;
- `unavailable_capabilities` — capability → missing dependency list;
- `capability_readiness` — full capability requirement projection;
- `execution_modes` — compile, history, human, autonomous, knowledge-gated and Interface Runtime readiness.

A configured public contract is not considered available merely because its name is present. Required callable gateways must be bound, resolvable and expose the configured method.

## Configuration

Runtime probes use public-contract configuration under `config/titan-nexus.php`. No peer implementation class is imported.

Knowledge Authority and Interface Runtime are binding-only readiness probes in this pass because Nexus does not own those runtimes. Their contracts remain optional/conditional and host-configurable.
