<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_prime_missions')) {
            return;
        }

        $columns = [
            'mission_id' => fn (Blueprint $table) => $table->string('mission_id', 80)->nullable()->after('tenant_company_id'),
            'objective_type' => fn (Blueprint $table) => $table->string('objective_type', 120)->nullable()->after('type'),
            'objective_json' => fn (Blueprint $table) => $table->json('objective_json')->nullable()->after('objective_type'),
            'budget_json' => fn (Blueprint $table) => $table->json('budget_json')->nullable()->after('objective_json'),
            'initiated_by_type' => fn (Blueprint $table) => $table->string('initiated_by_type', 80)->nullable()->after('budget_json'),
            'initiated_by_id' => fn (Blueprint $table) => $table->string('initiated_by_id', 191)->nullable()->after('initiated_by_type'),
            'lock_version' => fn (Blueprint $table) => $table->unsignedBigInteger('lock_version')->default(1)->after('initiated_by_id'),
            'record_format' => fn (Blueprint $table) => $table->string('record_format', 32)->default('legacy-v1')->after('lock_version'),
        ];

        foreach ($columns as $name => $definition) {
            if (!Schema::hasColumn('titan_prime_missions', $name)) {
                Schema::table('titan_prime_missions', $definition);
            }
        }

        Schema::table('titan_prime_missions', static function (Blueprint $table): void {
            $table->unique(['tenant_company_id', 'mission_id'], 'tpm_tenant_mission_uq');
            $table->index(['tenant_company_id', 'status'], 'tpm_tenant_status_idx');
            $table->index(['tenant_company_id', 'objective_type'], 'tpm_tenant_objective_idx');
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('titan_prime_missions')) {
            return;
        }

        Schema::table('titan_prime_missions', static function (Blueprint $table): void {
            $table->dropUnique('tpm_tenant_mission_uq');
            $table->dropIndex('tpm_tenant_status_idx');
            $table->dropIndex('tpm_tenant_objective_idx');
            $table->dropColumn([
                'mission_id',
                'objective_type',
                'objective_json',
                'budget_json',
                'initiated_by_type',
                'initiated_by_id',
                'lock_version',
                'record_format',
            ]);
        });
    }
};
