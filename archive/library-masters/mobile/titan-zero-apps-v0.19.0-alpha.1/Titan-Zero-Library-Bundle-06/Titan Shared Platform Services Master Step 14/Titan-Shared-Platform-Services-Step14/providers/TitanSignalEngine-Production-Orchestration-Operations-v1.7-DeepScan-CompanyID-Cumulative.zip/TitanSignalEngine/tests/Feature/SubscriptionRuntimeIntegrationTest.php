<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalSubscriberContract;
use App\Extensions\TitanSignalEngine\System\Data\EventTypeDefinition;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalSubscriptionDefinition;
use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryIdentity;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryLeasePolicy;
use App\Extensions\TitanSignalEngine\System\Data\SignalDeliveryLease;
use App\Extensions\TitanSignalEngine\System\Models\SignalDelivery;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use App\Extensions\TitanSignalEngine\System\Persistence\SignalEventStore;
use App\Extensions\TitanSignalEngine\System\Services\EventTypeRegistry;
use App\Extensions\TitanSignalEngine\System\Services\SignalRegistryAuthority;
use App\Extensions\TitanSignalEngine\System\Services\RegistryOwnershipPolicy;
use App\Extensions\TitanSignalEngine\System\Services\SignalContextValidator;
use App\Extensions\TitanSignalEngine\System\Services\SignalDeliveryDispatcher;
use App\Extensions\TitanSignalEngine\System\Services\SignalDeliveryLeaseManager;
use App\Extensions\TitanSignalEngine\System\Services\SignalDeliveryScheduler;
use App\Extensions\TitanSignalEngine\System\Services\SignalEmitter;
use App\Extensions\TitanSignalEngine\System\Services\SignalPayloadGuard;
use App\Extensions\TitanSignalEngine\System\Services\SignalSubscriptionFailureReporter;
use App\Extensions\TitanSignalEngine\System\Services\SignalSubscriptionRegistry;
use Illuminate\Support\Facades\Queue;
use RuntimeException;
use Tests\TestCase;

final class RecordingSignalSubscriber implements SignalSubscriberContract
{
    /** @var list<string> */
    public static array $deliveries = [];

    public function handle(SignalEvent $event, SignalDeliveryContext $delivery): void
    {
        self::$deliveries[] = $delivery->deliveryId . ':' . $event->event_id;
    }
}

final class CrashAfterEffectSignalSubscriber implements SignalSubscriberContract
{
    /** @var list<string> */
    public static array $idempotencyKeys = [];

    public function handle(SignalEvent $event, SignalDeliveryContext $delivery): void
    {
        self::$idempotencyKeys[] = $delivery->idempotencyKey;
        throw new RuntimeException('Simulated crash after subscriber side effect.');
    }
}

final class FailingSignalSubscriber implements SignalSubscriberContract
{
    public function handle(SignalEvent $event, SignalDeliveryContext $delivery): void
    {
        throw new RuntimeException('Deliberate subscriber failure.');
    }
}

final class SubscriptionRuntimeIntegrationTest extends TestCase
{
    private SignalEmitter $emitter;
    private \App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority $emitterAuthority;
    private SignalDeliveryDispatcher $dispatcher;
    private SignalSubscriptionRegistry $subscriptions;
    private SignalRegistryIdentity $registryIdentity;
    private SignalDeliveryLeaseManager $leaseManager;

    protected function setUp(): void
    {
        parent::setUp();
        foreach (glob(dirname(__DIR__, 2) . '/database/migrations/*.php') ?: [] as $migrationFile) {
            (require $migrationFile)->up();
        }
        Queue::fake();
        RecordingSignalSubscriber::$deliveries = [];
        CrashAfterEffectSignalSubscriber::$idempotencyKeys = [];

        $registryAuthority = new SignalRegistryAuthority('feature-registry-secret', [
            'test-registry' => [
                'owner_source' => 'test-suite',
                'permissions' => ['signal.registry.event.manage', 'signal.registry.subscription.manage', 'signal.registry.override'],
                'event_type_patterns' => ['*'],
                'subscriber_key_patterns' => ['*'],
            ],
        ]);
        $this->registryIdentity = $registryAuthority->issue('test-registry');
        $ownership = new RegistryOwnershipPolicy($registryAuthority);
        $eventTypes = new EventTypeRegistry($ownership);
        $eventTypes->register(EventTypeDefinition::fromArray([
            'event_type' => 'test.signal',
            'current_schema_version' => 1,
            'supported_schema_versions' => [1],
            'category' => 'test',
            'allowed_scopes' => ['tenant'],
            'required_payload_fields' => ['value'],
            'optional_payload_fields' => [],
            'allow_additional_payload_fields' => false,
            'owner_source' => 'test-suite',
            'allowed_severities' => ['info'],
        ]), $this->registryIdentity);
        $eventTypes->register(EventTypeDefinition::fromArray([
            'event_type' => 'signal.subscription.failed',
            'current_schema_version' => 1,
            'supported_schema_versions' => [1],
            'category' => 'operations',
            'allowed_scopes' => ['tenant', 'system'],
            'required_payload_fields' => ['delivery_id', 'event_id', 'subscriber_key', 'attempt_count', 'error_class'],
            'optional_payload_fields' => [],
            'allow_additional_payload_fields' => false,
            'owner_source' => 'titan-signal-engine',
            'allowed_severities' => ['error'],
        ]), $this->registryIdentity);

        $this->subscriptions = new SignalSubscriptionRegistry($ownership, new \App\Extensions\TitanSignalEngine\System\Services\SignalSubscriptionRegistryRevision(), new \App\Extensions\TitanSignalEngine\System\Data\SignalRegistryCachePolicy(1));
        $this->subscriptions->register(SignalSubscriptionDefinition::fromArray([
            'subscriber_key' => 'test.recording',
            'handler_class' => RecordingSignalSubscriber::class,
            'event_patterns' => ['test.signal'],
            'accepted_schema_versions' => [1],
            'scopes' => ['tenant'],
            'max_attempts' => 2,
            'backoff_seconds' => [0],
        ]), $this->registryIdentity);
        $this->subscriptions->register(SignalSubscriptionDefinition::fromArray([
            'subscriber_key' => 'test.failing',
            'handler_class' => FailingSignalSubscriber::class,
            'event_patterns' => ['test.signal'],
            'accepted_schema_versions' => [1],
            'scopes' => ['tenant'],
            'max_attempts' => 2,
            'backoff_seconds' => [0],
        ]), $this->registryIdentity);

        $this->emitterAuthority = new \App\Extensions\TitanSignalEngine\System\Services\SignalEmitterAuthority('feature-test-secret', [
            'test-service:test-suite:root' => [
                'source' => 'test-suite', 'source_component' => null,
                'permissions' => ['signal.emit'], 'event_type_patterns' => ['*'],
            ],
            'titan-signal-engine:subscription-dispatcher' => [
                'source' => 'titan-signal-engine', 'source_component' => 'subscription-dispatcher',
                'permissions' => ['signal.emit'], 'event_type_patterns' => ['signal.subscription.failed'],
            ],
        ]);
        $leaseManager = new SignalDeliveryLeaseManager(new SignalDeliveryLeasePolicy(120));
        $this->leaseManager = $leaseManager;
        $scheduler = new SignalDeliveryScheduler($this->subscriptions, $leaseManager);
        $this->emitter = new SignalEmitter(
            new SignalEventStore(),
            $eventTypes,
            new SignalContextValidator($this->emitterAuthority),
            new SignalPayloadGuard(65536, 8192, []),
            $scheduler,
        );
        $reporter = new SignalSubscriptionFailureReporter($this->emitter, $this->emitterAuthority);
        $this->dispatcher = new SignalDeliveryDispatcher($this->subscriptions, $scheduler, $reporter, $leaseManager);
    }


    private function emitTrusted(
        \App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope|array $signal,
        ?\App\Extensions\TitanSignalEngine\System\Data\SignalContext $context = null,
    ): \App\Extensions\TitanSignalEngine\System\Data\SignalReceipt {
        $source = is_array($signal) ? (string) ($signal['source'] ?? 'test-suite') : $signal->source;
        $component = is_array($signal) ? ($signal['source_component'] ?? null) : $signal->sourceComponent;
        $scope = is_array($signal) ? (string) ($signal['scope'] ?? 'tenant') : $signal->scope;
        $tenant = is_array($signal) ? ($signal['tenant_company_id'] ?? null) : $signal->tenantCompanyId;
        $serviceId = 'test-service:' . $source . ':' . ($component ?? 'root');
        $identity = $this->emitterAuthority->issue($serviceId);
        if ($context === null) {
            $context = $scope === 'system'
                ? \App\Extensions\TitanSignalEngine\System\Data\SignalContext::system('test-system', 'test', ['signal.tenant.emit'], $identity)
                : \App\Extensions\TitanSignalEngine\System\Data\SignalContext::tenantHuman((int) $tenant, 'test-user', 'test-session', 'test', $identity);
        } else {
            $context = new \App\Extensions\TitanSignalEngine\System\Data\SignalContext(
                $context->scope,
                $context->tenantCompanyId,
                $context->actor,
                $context->permissions,
                $identity,
            );
        }

        return $this->emitter->emit($signal, $context);
    }

    public function test_each_subscriber_gets_independent_delivery_and_failure_is_isolated(): void
    {
        $receipt = $this->emitTrusted([
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'payload' => ['value' => 1],
        ]);

        self::assertSame(2, SignalDelivery::query()->where('event_id', $receipt->eventId)->count());

        $good = SignalDelivery::query()->where('event_id', $receipt->eventId)->where('subscriber_key', 'test.recording')->firstOrFail();
        $bad = SignalDelivery::query()->where('event_id', $receipt->eventId)->where('subscriber_key', 'test.failing')->firstOrFail();

        self::assertSame('delivered', $this->dispatcher->deliver((string) $good->delivery_id)->status);
        self::assertCount(1, RecordingSignalSubscriber::$deliveries);

        $this->dispatcher->deliver((string) $bad->delivery_id);
        $final = $this->dispatcher->deliver((string) $bad->delivery_id);
        self::assertSame('dead_letter', $final->status);
        self::assertSame('delivered', SignalDelivery::query()->where('delivery_id', $good->delivery_id)->value('status'));
        self::assertSame(1, SignalEvent::query()->where('event_type', 'signal.subscription.failed')->count());
    }

    public function test_duplicate_ingestion_does_not_duplicate_delivery_rows(): void
    {
        $input = [
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'idempotency_key' => 'subscriber-dedupe',
            'payload' => ['value' => 1],
        ];
        $first = $this->emitTrusted($input);
        $second = $this->emitTrusted($input);

        self::assertTrue($second->duplicate);
        self::assertSame($first->eventId, $second->eventId);
        self::assertSame(2, SignalDelivery::query()->where('event_id', $first->eventId)->count());
    }

    public function test_incompatible_schema_subscription_does_not_receive_event(): void
    {
        $this->subscriptions->register(SignalSubscriptionDefinition::fromArray([
            'subscriber_key' => 'test.schema2',
            'handler_class' => RecordingSignalSubscriber::class,
            'event_patterns' => ['test.signal'],
            'accepted_schema_versions' => [2],
            'scopes' => ['tenant'],
        ]), $this->registryIdentity);

        $receipt = $this->emitTrusted([
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'schema_version' => 1,
            'payload' => ['value' => 2],
        ]);

        self::assertSame(0, SignalDelivery::query()->where('event_id', $receipt->eventId)->where('subscriber_key', 'test.schema2')->count());
    }

    public function test_delivery_claim_is_atomic_and_stale_worker_cannot_finalize(): void
    {
        $receipt = $this->emitTrusted([
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'payload' => ['value' => 41],
        ]);

        $delivery = SignalDelivery::query()
            ->where('event_id', $receipt->eventId)
            ->where('subscriber_key', 'test.recording')
            ->firstOrFail();

        $tokenA = $this->leaseManager->newExecutionToken();
        $leaseA = $this->leaseManager->claim((string) $delivery->delivery_id, $tokenA, 'worker-a', 120);
        self::assertNotNull($leaseA);

        $tokenB = $this->leaseManager->newExecutionToken();
        self::assertNull($this->leaseManager->claim((string) $delivery->delivery_id, $tokenB, 'worker-b', 120));

        $fresh = SignalDelivery::query()->where('delivery_id', $delivery->delivery_id)->firstOrFail();
        self::assertSame('processing', $fresh->status);
        self::assertSame('worker-a', $fresh->lease_owner);
        self::assertSame(1, (int) $fresh->attempt_count);
        self::assertSame(1, (int) $fresh->claim_version);

        $stale = new SignalDeliveryLease(
            $leaseA->deliveryId,
            $tokenB,
            'worker-b',
            $leaseA->claimVersion,
            $leaseA->claimedAt,
            $leaseA->expiresAt,
        );
        self::assertFalse($this->leaseManager->markDelivered($stale));
        self::assertTrue($this->leaseManager->markDelivered($leaseA));
        self::assertSame('delivered', SignalDelivery::query()->where('delivery_id', $delivery->delivery_id)->value('status'));
    }

    public function test_expired_processing_lease_can_be_recovered_and_reclaimed(): void
    {
        $receipt = $this->emitTrusted([
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'payload' => ['value' => 42],
        ]);
        $delivery = SignalDelivery::query()
            ->where('event_id', $receipt->eventId)
            ->where('subscriber_key', 'test.recording')
            ->firstOrFail();

        $leaseA = $this->leaseManager->claim(
            (string) $delivery->delivery_id,
            $this->leaseManager->newExecutionToken(),
            'worker-a',
            120,
        );
        self::assertNotNull($leaseA);

        SignalDelivery::query()->where('delivery_id', $delivery->delivery_id)->update(['lease_expires_at' => now()->subSecond()]);
        self::assertTrue($this->leaseManager->releaseExpired((string) $delivery->delivery_id));

        $leaseB = $this->leaseManager->claim(
            (string) $delivery->delivery_id,
            $this->leaseManager->newExecutionToken(),
            'worker-b',
            120,
        );
        self::assertNotNull($leaseB);
        self::assertSame('worker-b', $leaseB->workerId);
        self::assertSame(2, $leaseB->claimVersion);
        self::assertFalse($this->leaseManager->markDelivered($leaseA));
    }

    public function test_retry_attempts_expose_stable_subscriber_idempotency_key(): void
    {
        $this->subscriptions->register(SignalSubscriptionDefinition::fromArray([
            'subscriber_key' => 'test.crash-after-effect',
            'handler_class' => CrashAfterEffectSignalSubscriber::class,
            'event_patterns' => ['test.signal'],
            'accepted_schema_versions' => [1],
            'scopes' => ['tenant'],
            'max_attempts' => 2,
            'backoff_seconds' => [0],
        ]), $this->registryIdentity);

        $receipt = $this->emitTrusted([
            'event_type' => 'test.signal',
            'tenant_company_id' => 1,
            'source' => 'test-suite',
            'payload' => ['value' => 43],
        ]);
        $delivery = SignalDelivery::query()
            ->where('event_id', $receipt->eventId)
            ->where('subscriber_key', 'test.crash-after-effect')
            ->firstOrFail();

        $this->dispatcher->deliver((string) $delivery->delivery_id);
        $this->dispatcher->deliver((string) $delivery->delivery_id);

        self::assertCount(2, CrashAfterEffectSignalSubscriber::$idempotencyKeys);
        self::assertSame(CrashAfterEffectSignalSubscriber::$idempotencyKeys[0], CrashAfterEffectSignalSubscriber::$idempotencyKeys[1]);
        self::assertSame('signal-delivery:' . $delivery->delivery_id, CrashAfterEffectSignalSubscriber::$idempotencyKeys[0]);
    }

}
