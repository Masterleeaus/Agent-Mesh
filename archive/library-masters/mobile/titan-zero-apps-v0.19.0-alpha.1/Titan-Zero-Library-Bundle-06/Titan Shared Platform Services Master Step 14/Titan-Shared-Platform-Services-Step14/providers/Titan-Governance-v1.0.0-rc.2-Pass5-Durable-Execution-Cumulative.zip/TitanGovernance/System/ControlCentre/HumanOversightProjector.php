<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\ControlCentre;

use DateTimeImmutable;
use Throwable;

final class HumanOversightProjector
{
    /** @param array<string,mixed> $workforce @param list<array<string,mixed>> $decisions @return array<string,mixed> */
    public function project(array $workforce,array $decisions,array $context=[]):array
    {
        $now=$this->now($context);$warning=max(300,(int)($context['approval_warning_seconds']??3600));$critical=max($warning,(int)($context['approval_critical_seconds']??14400));
        $approvals=[];$workload=[];$taskIds=[];
        foreach(array_slice(is_array($workforce['approvals']??null)?$workforce['approvals']:[],0,250) as $row){if(!is_array($row))continue;$task=(string)($row['task_id']??'');if($task!=='')$taskIds[$task]=true;$observed=$this->timeValue($row['submitted_at']??$row['updated_at']??$row['created_at']??null);$age=$observed?max(0,$now->getTimestamp()-$observed->getTimestamp()):null;$ageStatus=$age===null?'UNKNOWN':($age>=$critical?'OVERDUE':($age>=$warning?'AGING':'CURRENT'));$managerKey=(string)($row['manager_id']??'unassigned');
            $approvals[]=$row+['age_seconds'=>$age,'age_status'=>$ageStatus,'observed_at'=>$row['submitted_at']??$row['updated_at']??$row['created_at']??null,'can_change_authority'=>false];
            if(!isset($workload[$managerKey]))$workload[$managerKey]=['manager_id'=>$row['manager_id']??null,'manager'=>$row['manager']??null,'open_approvals'=>0,'overdue_approvals'=>0,'aging_approvals'=>0,'escalated_approvals'=>0];
            $workload[$managerKey]['open_approvals']++;if($ageStatus==='OVERDUE')$workload[$managerKey]['overdue_approvals']++;elseif($ageStatus==='AGING')$workload[$managerKey]['aging_approvals']++;if(strtoupper((string)($row['status']??''))==='ESCALATED')$workload[$managerKey]['escalated_approvals']++;
        }
        foreach(array_slice(is_array($workforce['queues']??null)?$workforce['queues']:[],0,200) as $queue){if(!is_array($queue))continue;$managerKey=(string)($queue['manager_id']??'unassigned');if(!isset($workload[$managerKey]))$workload[$managerKey]=['manager_id'=>$queue['manager_id']??null,'manager'=>$queue['manager']??null,'open_approvals'=>0,'overdue_approvals'=>0,'aging_approvals'=>0,'escalated_approvals'=>0];$health=is_array($queue['health']??null)?$queue['health']:[];$workload[$managerKey]['queue_depth']=(int)($health['queue_depth']??0);$workload[$managerKey]['review_count']=(int)($health['review_count']??0);$workload[$managerKey]['overdue_work']=(int)($health['overdue_count']??0);$workload[$managerKey]['pressure']=$health['pressure']??'UNKNOWN';}
        $handoffs=[];$handoffIds=[];foreach(array_slice(is_array($workforce['handoffs']??null)?$workforce['handoffs']:[],0,250) as $row){if(!is_array($row))continue;$id=(string)($row['handoff_id']??'');if($id!=='')$handoffIds[$id]=true;$task=(string)($row['task_id']??'');if($task!=='')$taskIds[$task]=true;$observed=$this->timeValue($row['updated_at']??$row['created_at']??null);$age=$observed?max(0,$now->getTimestamp()-$observed->getTimestamp()):null;$ageStatus=$age===null?'UNKNOWN':($age>=$critical?'OVERDUE':($age>=$warning?'AGING':'CURRENT'));$handoffs[]=$row+['age_seconds'=>$age,'age_status'=>$ageStatus,'observed_at'=>$row['updated_at']??$row['created_at']??null,'can_change_authority'=>false];}
        $operatorWorkload=array_values($workload);usort($operatorWorkload,static fn(array $a,array $b):int=>($b['overdue_approvals']<=>$a['overdue_approvals'])?:($b['open_approvals']<=>$a['open_approvals'])?:strcmp((string)($a['manager']??''),(string)($b['manager']??'')));
        $interventions=[];foreach(array_slice($decisions,0,250) as $row){if(!is_array($row))continue;$type=strtolower((string)($row['subject_type']??''));$id=(string)($row['subject_id']??'');$linked=str_contains($type,'workforce')||str_contains($type,'task')||str_contains($type,'handoff')||str_contains($type,'staffing')||isset($taskIds[$id])||isset($handoffIds[$id]);if(!$linked)continue;$interventions[]=['decision_id'=>$row['decision_id']??null,'subject_type'=>$row['subject_type']??null,'subject_id'=>$row['subject_id']??null,'action'=>$row['action']??$row['disposition']??null,'actor_id'=>$row['actor_id']??null,'decided_at'=>$row['decided_at']??null,'reason_codes'=>is_array($row['reason_codes']??null)?array_values(array_slice($row['reason_codes'],0,20)):[]];}
        return ['schema_version'=>'1.0','status'=>$workforce['status']??'UNAVAILABLE','approvals'=>$approvals,'handoffs'=>$handoffs,'operator_workload'=>$operatorWorkload,'intervention_history'=>array_slice($interventions,0,100),'summary'=>['waiting_approvals'=>count($approvals),'aging_approvals'=>count(array_filter($approvals,static fn(array $r):bool=>$r['age_status']==='AGING')),'overdue_approvals'=>count(array_filter($approvals,static fn(array $r):bool=>$r['age_status']==='OVERDUE')),'open_handoffs'=>count($handoffs),'overdue_handoffs'=>count(array_filter($handoffs,static fn(array $r):bool=>$r['age_status']==='OVERDUE')),'interventions'=>count($interventions)],'can_raise_authority'=>false,'authority_changed'=>false];
    }
    private function now(array $context):DateTimeImmutable{if(is_string($context['now']??null)){try{return new DateTimeImmutable($context['now']);}catch(Throwable){}}return new DateTimeImmutable('now');}
    private function timeValue(mixed $v):?DateTimeImmutable{if(!is_string($v)||trim($v)==='')return null;try{return new DateTimeImmutable($v);}catch(Throwable){return null;}}
}
