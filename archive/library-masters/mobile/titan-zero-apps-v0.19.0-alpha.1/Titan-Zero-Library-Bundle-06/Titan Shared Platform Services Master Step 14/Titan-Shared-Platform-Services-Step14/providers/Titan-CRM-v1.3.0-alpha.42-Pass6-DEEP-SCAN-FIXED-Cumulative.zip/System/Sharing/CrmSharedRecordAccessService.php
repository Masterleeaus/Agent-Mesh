<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Sharing;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

final class CrmSharedRecordAccessService
{
    private const TABLES = [
        'company'=>'crm_companies','contact'=>'crm_contacts','lead'=>'crm_leads','deal'=>'crm_deals','project'=>'crm_projects','task'=>'crm_tasks',
    ];

    public function __construct(private ConnectionInterface $db, private CrmRecordShareService $shares) {}

    /** @return array{grant:array,record:array} */
    public function resolve(int $granteeUserId, string $subjectType, string $subjectPublicId, string $permission='view'): array
    {
        $grant = $this->shares->resolveGrant($granteeUserId,$subjectType,$subjectPublicId,$permission);
        $table = self::TABLES[$subjectType] ?? null;
        if ($table === null) throw new NotFoundHttpException();
        $row = $this->db->table($table)->where('company_id', (int)($grant['company_id'] ?? CrmCompanyScope::companyId((int)$grant['user_id'])))->where('public_id',$subjectPublicId)->whereNull('deleted_at')->first();
        if (! $row) throw new NotFoundHttpException();
        return ['grant'=>$grant,'record'=>(array)$row];
    }
}
