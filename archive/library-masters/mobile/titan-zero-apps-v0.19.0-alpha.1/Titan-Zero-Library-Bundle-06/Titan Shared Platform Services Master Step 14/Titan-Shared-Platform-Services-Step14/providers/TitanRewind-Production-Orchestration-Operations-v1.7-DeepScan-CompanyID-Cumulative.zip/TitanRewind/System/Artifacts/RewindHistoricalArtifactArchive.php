<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Artifacts;
use App\Extensions\TitanRewind\System\Models\RewindHistoricalArtifact;
use App\Extensions\TitanRewind\System\Replay\RewindArtifactResolverRegistry;
use App\Extensions\TitanRewind\System\Support\CanonicalJson;
use App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer;
use Illuminate\Support\Str;
use InvalidArgumentException;
final class RewindHistoricalArtifactArchive
{
 public function __construct(private RewindArtifactResolverRegistry $resolvers,private CanonicalJson $canonical,private RewindPayloadSanitizer $sanitizer,private RewindHostArtifactDiscovery $discovery){}
 public function resolveAndArchive(string $kind,string $version,array $context=[]): array
 {
  $this->discovery->discover();
  $kind=strtolower(trim($kind));$version=trim($version);if($kind===''||$version==='')throw new InvalidArgumentException('Historical artifact kind and version are required.');
  $tenant=isset($context['tenant_company_id'])?(int)$context['tenant_company_id']:null;$trace=isset($context['trace_id'])?(string)$context['trace_id']:null;
  $cached=RewindHistoricalArtifact::query()->where('kind',$kind)->where('version',$version)->when($tenant,fn($q)=>$q->where('tenant_company_id',$tenant))->when($trace,fn($q)=>$q->where('trace_id',$trace))->orderByDesc('id')->first();
  if($cached) return ['status'=>'RESOLVED_ARCHIVED','artifact'=>$cached->artifact_payload,'content_hash'=>$cached->content_hash,'artifact_uuid'=>$cached->artifact_uuid,'authenticity_state'=>$cached->authenticity_state];
  $resolved=$this->resolvers->resolve($kind,$version,$context);if($resolved===null)return ['status'=>'ARTIFACT_UNAVAILABLE','artifact'=>null,'content_hash'=>null];
  $payload=$this->sanitizer->sanitize($resolved);$provided=strtolower((string)($resolved['content_hash']??''));unset($payload['content_hash']);$hash=hash('sha256',$this->canonical->encode($payload));if($provided!==''&&!hash_equals($provided,$hash))throw new InvalidArgumentException('Historical artifact content hash verification failed.');
  $row=RewindHistoricalArtifact::query()->firstOrCreate(['tenant_company_id'=>$tenant,'trace_id'=>$trace,'kind'=>$kind,'version'=>$version,'content_hash'=>$hash],['artifact_uuid'=>(string)Str::uuid(),'source_key'=>(string)($resolved['source_key']??$kind),'authenticity_state'=>(string)($resolved['authenticity_state']??'UNKNOWN'),'artifact_payload'=>$payload,'metadata'=>['resolver_kind'=>$kind],'captured_at'=>now(),'last_verified_at'=>now()]);
  return ['status'=>'RESOLVED_ARCHIVED','artifact'=>$row->artifact_payload,'content_hash'=>$row->content_hash,'artifact_uuid'=>$row->artifact_uuid,'authenticity_state'=>$row->authenticity_state];
 }
}
