<?php

declare(strict_types=1);

namespace App\Extensions\TitanKnowledgeAuthority\System\Domain\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class KnowledgeApplicability extends Model
{
    protected $table = 'titan_knowledge_applicability';
    protected $guarded = ['id'];
    protected $casts = [
        'applies' => 'boolean',
        'deterministic' => 'boolean',
        'conditions' => 'array',
        'metadata' => 'array',
        'effective_from' => 'immutable_datetime',
        'effective_until' => 'immutable_datetime',
    ];

    public function claim(): BelongsTo
    {
        return $this->belongsTo(KnowledgeClaim::class, 'claim_id');
    }

    public function jurisdiction(): BelongsTo
    {
        return $this->belongsTo(KnowledgeJurisdiction::class, 'jurisdiction_id');
    }
}
