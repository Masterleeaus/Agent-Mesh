# Titan AI Core v0.5.0 — Pass 4 Governance Adapters & Command Bus Boundary

Titan AI Core is Titan Zero's canonical `orchestration-planning` owner. v0.5.0 cumulatively includes Pass 1 host/installer hardening, Pass 2 typed planning contracts, Pass 3 trusted tenant/actor/authority enforcement, and Pass 4 fail-closed governance/Command Bus boundaries.

## Pass 4 delivered

- typed Risk, Assurance and Autonomy gateway contracts
- fail-closed unavailable gateway adapters that return `DEFER` rather than silently allowing execution
- `GovernancePreflightCoordinator` collecting all three engine decisions
- structured `ALLOW`, `DENY`, `REQUIRE_APPROVAL`, `REQUIRE_EVIDENCE` and `DEFER` outcomes
- `PENDING_REVIEW` denial/escalation state instead of runtime crashes
- typed human `ApprovalState` with pending/approved/denied states
- typed Command Bus request/receipt contracts carrying tenant, actor, plan, step and full causal context
- `CommandBusMutationBoundary` that blocks execution while Core execution is disabled
- governance approval required before any Command Bus dispatch
- default Command Bus adapter fails closed when the external bus is unavailable
- health/runtime visibility for governance and mutation boundary wiring
- Blueprint implementation evidence updated to `governance_preflight=true` while `governed_execution=false`

## Security invariants

1. A plan/request cannot choose its tenant, actor ID or actor type.
2. The authenticated host principal is the only trusted source for runtime identity.
3. A plan actor's tenant must equal the runtime tenant before DAG validation occurs.
4. Core-owned plan reads/writes are tenant scoped.
5. A tenant may not use another tenant's model profile.
6. Global model profiles are not eligible unless global fallback is explicitly permitted.
7. Capability checks fail closed when the host does not authorize the capability.
8. No consequential mutation is enabled; governance boundaries are operational but governed execution remains disabled.

## Execution remains fail-closed

The orchestration contract remains:

- `implementation_state: contract-only`
- `execution_enabled: false`

A valid trusted security context can now be evaluated through fail-closed Risk/Assurance/Autonomy preflight contracts. The default adapters defer when those engines are unavailable, and Command Bus dispatch remains disabled. Deterministic DAG validation, simulation, real engine adapters, model routing and governed execution remain later passes.

## Commands

```bash
php artisan titan-ai-core:host-sync
php artisan titan-ai-core:diagnose
php artisan titan:titan-ai-core:certify --json
```

## Ownership boundary

AI Core owns Tier 0 plan contracts, orchestration-planning semantics, trusted orchestration context and future model-routing policy. It does not own Risk, Assurance, Autonomy, Command Bus execution, AI Workforce runtime, Model Council deliberation, Knowledge Authority, Signal truth, Rewind, Wisdom, Governance policy or business-domain state.

## Next pass

Pass 5: deterministic DAG validator and constructive plan validation — cycle detection, dependency validation, topological ordering, data-flow checks and actionable validation feedback.
