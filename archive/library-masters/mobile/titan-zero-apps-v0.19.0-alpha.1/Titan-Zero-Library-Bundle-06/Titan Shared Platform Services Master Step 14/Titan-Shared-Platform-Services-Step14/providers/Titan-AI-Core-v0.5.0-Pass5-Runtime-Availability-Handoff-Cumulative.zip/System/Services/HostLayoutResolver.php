<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Services;

use App\Extensions\TitanAICore\System\Contracts\HostLayoutResolverContract;
use Illuminate\Contracts\View\Factory as ViewFactory;

final class HostLayoutResolver implements HostLayoutResolverContract
{
    public function __construct(private readonly ViewFactory $views) {}

    public function resolve(): string
    {
        $candidates = config('titan-ai-core.host_layout_candidates', []);
        if (! is_array($candidates)) {
            $candidates = [];
        }

        foreach ($candidates as $candidate) {
            if (is_string($candidate) && $candidate !== '' && $this->views->exists($candidate)) {
                return $candidate;
            }
        }

        return 'titan-ai-core::layouts.standalone';
    }
}
