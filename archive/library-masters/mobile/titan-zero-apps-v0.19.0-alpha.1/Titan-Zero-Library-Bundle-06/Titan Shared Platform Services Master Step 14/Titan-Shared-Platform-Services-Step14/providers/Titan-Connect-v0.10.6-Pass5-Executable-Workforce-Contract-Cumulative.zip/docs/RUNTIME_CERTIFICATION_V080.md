# Titan Connect v0.8 Runtime Certification

v0.8 adds an executable certification layer for the installed Titan Zero/MagicAI host. It supplements the existing static package verifier and opt-in Laravel/MySQL feature tests.

## Command

```bash
php artisan titan-connect:certify
```

The default run is read-only. It reports database/schema readiness, cache/queue/broadcast configuration, attachment storage/scanner state, and host bridge/binding readiness without exposing provider credentials.

### Runtime probes

```bash
php artisan titan-connect:certify \
  --queue-probe \
  --broadcast-probe \
  --two-company-probe \
  --timeout=15 \
  --output=storage/logs/titan-connect-certification.json
```

- Queue probe: dispatches a cache-only job and waits for a real worker acknowledgement.
- Broadcast probe: publishes to an isolated `titan-connect.certification.*` channel. It proves broadcaster publication, not browser/mobile receipt.
- Two-company probe: creates representative company A/B records inside one DB transaction, tests `forCompany()` isolation in both directions, then always rolls back.
- `--strict`: warnings fail certification.
- `--json`: machine-readable stdout.
- `--output=`: saves the credential-free JSON report for release evidence.

No provider message, webhook, OAuth action, SMS, social send, or voice call is triggered by these probes.

## Host bridge readiness

The report identifies whether the host has listeners/bindings for WorkCore authorization, Chatbot inbound/handoff, TitanMobileCore push, attachment scanning, privacy handling, reply assistance, voice sessions, and optional voice-agent authoring. Missing optional adapters are warnings; broken bindings are errors.

## Production certification sequence

1. Run migrations in a production-equivalent staging clone.
2. Run `TITAN_CONNECT_HOST_CERTIFICATION=1 php artisan test App/Extensions/TitanConnect/tests/Feature/HostCertification/CompanyBoundaryTest.php`.
3. Start the real queue worker and realtime broadcaster.
4. Run `php artisan titan-connect:certify --queue-probe --broadcast-probe --two-company-probe --strict --output=storage/logs/titan-connect-certification.json`.
5. Complete provider sandbox and browser/mobile realtime smoke tests separately.
