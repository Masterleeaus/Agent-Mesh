<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use Illuminate\Database\ConnectionInterface;
use Throwable;

/** Read-only host-runtime performance certification. No synthetic rows are written. */
final class CrmPerformanceAuditService
{
    /** @var array<string,list<string>> */
    private const INDEX_EXPECTATIONS=[
        'crm_companies'=>['company_id','deleted_at','name'],
        'crm_contacts'=>['company_id','customer_company_id','deleted_at'],
        'crm_leads'=>['company_id','deleted_at','status'],
        'crm_deals'=>['company_id','pipeline_id','stage_id'],
        'crm_activities'=>['company_id','subject_type','subject_public_id','occurred_at'],
        'crm_invoices'=>['company_id','deleted_at','due_at'],
        'crm_import_rows'=>['company_id','batch_public_id','status','row_number'],
        'crm_read_projection_records'=>['company_id','projection_name','projection_version'],
        'crm_read_projection_search_terms'=>['company_id','term'],
    ];
    public function __construct(private readonly ConnectionInterface $db) {}

    /** @return array<string,mixed> */
    public function certify(int $companyId,int $iterations=3): array
    {
        $iterations=max(1,min(10,$iterations));$started=microtime(true);$row_counts=$this->rowCounts($companyId);$index_coverage=$this->indexCoverage();$query_timings=$this->queryTimings($companyId,$iterations);$memory_peak_bytes=memory_get_peak_usage(true);
        $warnMs=max(10,(int)config('crm.performance.query_warn_ms',250));$blockMs=max($warnMs,(int)config('crm.performance.query_block_ms',2000));$memoryWarn=max(16,(int)config('crm.performance.memory_warn_mb',128))*1024*1024;$warnings=[];$blocks=[];
        foreach($index_coverage as $table=>$coverage)if(($coverage['status']??'unknown')==='missing')$warnings[]="Missing expected composite index on {$table}.";
        foreach($query_timings as $name=>$timing){$p95=(float)($timing['p95_ms']??0);if($p95>$blockMs)$blocks[]="{$name} p95 {$p95}ms exceeds {$blockMs}ms block budget.";elseif($p95>$warnMs)$warnings[]="{$name} p95 {$p95}ms exceeds {$warnMs}ms warning budget.";}
        if($memory_peak_bytes>$memoryWarn)$warnings[]='Peak certification memory exceeded configured warning budget.';
        if(!($this->tableReady('crm_read_projection_search_terms')))$blocks[]='Projection search-term table is unavailable.';
        $status=$blocks!==[]?'BLOCK':($warnings!==[]?'WARN':'PASS');
        return ['status'=>$status,'company_id'=>$companyId,'driver'=>$this->db->getDriverName(),'row_counts'=>$row_counts,'scale_band'=>$this->scaleBand($row_counts),'index_coverage'=>$index_coverage,'query_timings'=>$query_timings,'iterations'=>$iterations,'memory_peak_bytes'=>$memory_peak_bytes,'warnings'=>$warnings,'blocks'=>$blocks,'duration_ms'=>round((microtime(true)-$started)*1000,2),'authoritative_mutations'=>false];
    }

    /** @return array<string,int|null> */
    private function rowCounts(int $tenant): array
    {
        $tables=['crm_companies','crm_contacts','crm_leads','crm_deals','crm_activities','crm_invoices','crm_read_projection_records'];$out=[];foreach($tables as $table){if(!$this->tableReady($table)){$out[$table]=null;continue;}try{$out[$table]=(int)$this->db->table($table)->where('company_id',$tenant)->count();}catch(Throwable){$out[$table]=null;}}return $out;
    }
    /** @return array<string,array<string,mixed>> */
    private function indexCoverage(): array
    {
        $driver=$this->db->getDriverName();$out=[];foreach(self::INDEX_EXPECTATIONS as $table=>$expected){if(!$this->tableReady($table)){$out[$table]=['status'=>'missing_table','expected'=>$expected];continue;}if($driver!=='mysql'){$out[$table]=['status'=>'unknown','expected'=>$expected,'reason'=>'index introspection implemented for MySQL'];continue;}try{$rows=$this->db->select('SHOW INDEX FROM `'.str_replace('`','',$table).'`');$indexes=[];foreach($rows as $row){$a=(array)$row;$name=(string)($a['Key_name']??$a['key_name']??'');$seq=(int)($a['Seq_in_index']??$a['seq_in_index']??0);$column=(string)($a['Column_name']??$a['column_name']??'');if($name!==''&&$seq>0)$indexes[$name][$seq]=$column;}foreach($indexes as &$columns){ksort($columns);$columns=array_values($columns);}unset($columns);$matched=null;foreach($indexes as $name=>$columns)if(array_slice($columns,0,count($expected))===$expected){$matched=$name;break;}$out[$table]=['status'=>$matched!==null?'covered':'missing','expected'=>$expected,'matched_index'=>$matched,'indexes'=>$indexes];}catch(Throwable $e){$out[$table]=['status'=>'unknown','expected'=>$expected,'reason'=>$e->getMessage()];}}return $out;
    }
    /** @return array<string,array<string,mixed>> */
    private function queryTimings(int $tenant,int $iterations): array
    {
        $checks=[];
        if($this->tableReady('crm_companies'))$checks['customer_list']=fn()=> $this->db->table('crm_companies')->where('company_id',$tenant)->whereNull('deleted_at')->orderBy('name')->limit(100)->get(['id','public_id','name']);
        if($this->tableReady('crm_deals'))$checks['open_pipeline']=fn()=> $this->db->table('crm_deals')->where('company_id',$tenant)->whereNull('deleted_at')->where('status','open')->orderByDesc('updated_at')->limit(100)->get(['id','public_id','value_minor','probability']);
        if($this->tableReady('crm_activities'))$checks['recent_activity']=fn()=> $this->db->table('crm_activities')->where('company_id',$tenant)->orderByDesc('occurred_at')->limit(100)->get(['id','public_id','occurred_at']);
        if($this->tableReady('crm_read_projection_records'))$checks['projection_latest']=fn()=> $this->db->table('crm_read_projection_records')->where('company_id',$tenant)->orderByDesc('sort_at')->limit(100)->get(['id','projection_name','resource_public_id']);
        $out=[];foreach($checks as $name=>$check){$samples=[];for($i=0;$i<$iterations;$i++){$t=microtime(true);try{$check();$samples[]=round((microtime(true)-$t)*1000,3);}catch(Throwable $e){$out[$name]=['status'=>'error','error'=>$e->getMessage(),'p50_ms'=>null,'p95_ms'=>null];continue 2;}}sort($samples);$out[$name]=['status'=>'ok','samples_ms'=>$samples,'p50_ms'=>$this->percentile($samples,.50),'p95_ms'=>$this->percentile($samples,.95)];}return $out;
    }
    private function percentile(array $samples,float $p): float{if($samples===[])return 0.0;$index=(int)ceil($p*count($samples))-1;return (float)$samples[max(0,min(count($samples)-1,$index))];}
    private function scaleBand(array $counts): string{$max=0;foreach($counts as $count)if(is_int($count))$max=max($max,$count);return $max>=1000000?'million_plus':($max>=100000?'hundred_thousand_plus':($max>=10000?'ten_thousand_plus':'small'));}
    private function tableReady(string $table): bool{try{return $this->db->getSchemaBuilder()->hasTable($table);}catch(Throwable){return false;}}
}
