# Phase 5.1 Hardening

Phase 5.1 fixes release-blocking defects found in the Phase 5 deep audit. `company_id` is the canonical company/tenant boundary throughout runtime and core persistence; `tenant_id` is retained only as a temporary compatibility alias where older installations may still contain it.

## Security and execution fixes

- Replaced the request-memory wizard outbox with a durable encrypted company-scoped outbox store and sync replay path.
- Rebuilds actor authority from the current authenticated user at execution time; compiled plans no longer persist executable roles/user authority.
- Wizard approvals are cryptographically signed using trusted current-actor identity.
- Fresh-auth checks fail closed unless a trusted re-authentication timestamp is available.
- Onboarding compilation is restricted to the declared field/home-services onboarding schema and drops undeclared or secret material.
- Wizard start/list authorization enforces declared roles.
- Onboarding execution is company-scoped, idempotent, and activation is blocked until prerequisite actions are successfully complete.
- Branch conditions and structured onboarding field validation are enforced.
- Legacy interaction conditions and `required_if` rules are executable, and runs are not marked complete before command acceptance/durable queueing.
- WorkCore capability services must implement an explicit capability-service contract; arbitrary host classes are not duck-typed as executable.
- Trusted command idempotency keys propagate into WorkCore dispatch.
- Health reports onboarding execution readiness separately from catalogue health.

## Persistence

Fresh schemas use `company_id` as the canonical ownership column for interaction runs, answers, events, cognitive events, and LocalBrain memory. Upgrade migration `2026_08_09_000014_add_company_id_to_legacy_core_tables.php` adds/backfills `company_id` from the existing compatibility alias without destructive rollback.

The durable wizard outbox is stored in `interaction_wizard_outbox` and is owned by this extension.

## Engine completeness fixes

The audit identified demo/no-op implementations behind production engine interfaces. Phase 5.1 removes or replaces the most material cases:

- memory consolidation now removes exact duplicate company-scoped memories;
- BusinessBuilder emits field/home-services blueprints rather than placeholder services;
- AutomationEngine uses addressable scheduled/triggered state;
- LearningEngine versions learned state and records retraining;
- RetryEngine produces deterministic retry scheduling metadata;
- ExecutionEngine fails closed for unregistered executors;
- DialogueEngine produces local input-aware responses;
- FinancialInsightEngine requires an authoritative finance provider rather than fabricating figures;
- MonitoringEngine reports actual PHP/runtime metrics;
- dead generalized multi-vertical command paths and the fake CRM create handler were removed from production source.

## Remaining host integration gate

Field/home-services onboarding actions remain fail-closed until their canonical WorkCore application services/actions are mapped and verified in a connected WorkCore host. Phase 5.1 does not invent those host mappings.
