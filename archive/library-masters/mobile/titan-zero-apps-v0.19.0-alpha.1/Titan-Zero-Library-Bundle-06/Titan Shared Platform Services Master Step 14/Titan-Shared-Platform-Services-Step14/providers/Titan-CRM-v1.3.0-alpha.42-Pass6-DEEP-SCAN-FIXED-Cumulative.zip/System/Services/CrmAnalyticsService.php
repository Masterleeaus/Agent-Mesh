<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Services;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;

final class CrmAnalyticsService
{
    public function __construct(private ConnectionInterface $db,private CrmDashboardService $dashboard) {}
    public function snapshot(int $userId): array
    {
        $sales=[];foreach(['proposals','estimates','invoices'] as $type){$row=$this->db->table('crm_'.$type)->where('company_id',CrmCompanyScope::companyId($userId))->whereNull('deleted_at')->selectRaw('COUNT(*) AS total_count, COALESCE(SUM(total_minor),0) AS total_minor')->first();$sales[$type]=['count'=>(int)($row->total_count??0),'total_minor'=>(int)($row->total_minor??0)];}
        return ['summary'=>$this->dashboard->summary($userId),'monthly'=>$this->monthlySeries($userId),'lead_funnel'=>$this->db->table('crm_leads')->where('company_id',CrmCompanyScope::companyId($userId))->whereNull('deleted_at')->selectRaw('qualification_status, COUNT(*) as total')->groupBy('qualification_status')->get()->map(fn($r)=>(array)$r)->all(),'sales'=>$sales,'source_conversion'=>$this->sourceConversion($userId),'stage_velocity'=>$this->stageVelocity($userId),'stale_pipeline'=>$this->stalePipeline($userId),'sales_cycle_days'=>$this->salesCycleDays($userId)];
    }

    public function monthlySeries(int $userId): array
    {
        $tenant=CrmCompanyScope::companyId($userId);$first=now()->startOfMonth()->subMonths(5);$last=now()->endOfMonth();$months=[];for($i=0;$i<6;$i++){$m=$first->copy()->addMonths($i)->format('Y-m');$months[$m]=['month'=>$m,'leads_created'=>0,'deals_created'=>0,'deals_won'=>0,'won_value_minor'=>0];}
        $leadExpr=$this->monthExpression('created_at');$dealCreatedExpr=$this->monthExpression('created_at');$dealWonExpr=$this->monthExpression('closed_at');
        foreach($this->db->table('crm_leads')->where('company_id',$tenant)->whereBetween('created_at',[$first,$last])->selectRaw("{$leadExpr} AS month, COUNT(*) AS total")->groupBy('month')->get() as $row)if(isset($months[(string)$row->month]))$months[(string)$row->month]['leads_created']=(int)$row->total;
        foreach($this->db->table('crm_deals')->where('company_id',$tenant)->whereBetween('created_at',[$first,$last])->selectRaw("{$dealCreatedExpr} AS month, COUNT(*) AS total")->groupBy('month')->get() as $row)if(isset($months[(string)$row->month]))$months[(string)$row->month]['deals_created']=(int)$row->total;
        foreach($this->db->table('crm_deals')->where('company_id',$tenant)->where('status','won')->whereBetween('closed_at',[$first,$last])->selectRaw("{$dealWonExpr} AS month, COUNT(*) AS total, COALESCE(SUM(value_minor),0) AS value_minor")->groupBy('month')->get() as $row)if(isset($months[(string)$row->month])){$months[(string)$row->month]['deals_won']=(int)$row->total;$months[(string)$row->month]['won_value_minor']=(int)$row->value_minor;}
        return array_values($months);
    }

    public function sourceConversion(int $userId): array
    {
        $rows=$this->db->table('crm_leads')->where('company_id',CrmCompanyScope::companyId($userId))->whereNull('deleted_at')->selectRaw("COALESCE(NULLIF(TRIM(source),''),'unknown') AS source, COUNT(*) AS leads, SUM(CASE WHEN converted_at IS NOT NULL THEN 1 ELSE 0 END) AS converted")->groupBy('source')->get();
        return $rows->map(function($r):array{$leads=(int)$r->leads;$converted=(int)$r->converted;return ['source'=>(string)$r->source,'leads'=>$leads,'converted'=>$converted,'conversion_rate'=>$leads?round($converted/$leads*100,1):0.0];})->all();
    }
    public function stalePipeline(int $userId,int $days=14): array
    {return $this->db->table('crm_deals')->where('company_id',CrmCompanyScope::companyId($userId))->whereNull('deleted_at')->where('status','open')->where('updated_at','<',now()->subDays(max(1,$days)))->orderBy('updated_at')->limit(100)->get(['public_id','name','value_minor','currency','probability','updated_at'])->map(fn($r)=>(array)$r)->all();}
    public function salesCycleDays(int $userId): ?float
    {$rows=$this->db->table('crm_deals')->where('company_id',CrmCompanyScope::companyId($userId))->where('status','won')->whereNotNull('closed_at')->whereNull('deleted_at')->orderByDesc('closed_at')->limit(1000)->get(['created_at','closed_at']);if($rows->isEmpty())return null;$days=$rows->map(fn($r)=>max(0,Carbon::parse($r->created_at)->diffInSeconds(Carbon::parse($r->closed_at))/86400));return round((float)$days->avg(),1);}
    public function stageVelocity(int $userId): array
    {$rows=$this->db->table('crm_activities')->where('company_id',CrmCompanyScope::companyId($userId))->where('subject_type','deal')->where('type','stage_changed')->whereNotNull('subject_public_id')->orderByDesc('id')->limit(5000)->get(['subject_public_id','metadata','occurred_at','created_at'])->sortBy(fn($r)=>(string)$r->subject_public_id.'|'.(string)($r->occurred_at??$r->created_at));$byDeal=[];foreach($rows as $r)$byDeal[$r->subject_public_id][]=$r;$stats=[];foreach($byDeal as $events){$previous=null;foreach($events as $e){$meta=json_decode((string)($e->metadata??'{}'),true)?:[];$stage=(string)($meta['stage_public_id']??'unknown');$at=Carbon::parse($e->occurred_at??$e->created_at);if($previous){$hours=$previous->diffInSeconds($at)/3600;$stats[$stage]??=['stage_public_id'=>$stage,'transitions'=>0,'total_hours'=>0.0];$stats[$stage]['transitions']++;$stats[$stage]['total_hours']+=$hours;}$previous=$at;}}foreach($stats as &$s){$s['average_hours']=round($s['total_hours']/max(1,$s['transitions']),1);unset($s['total_hours']);}unset($s);return array_values($stats);}
    private function monthExpression(string $column): string{return match($this->db->getDriverName()){'pgsql'=>"TO_CHAR({$column}, 'YYYY-MM')",'sqlite'=>"strftime('%Y-%m', {$column})",default=>"DATE_FORMAT({$column}, '%Y-%m')"};}
}
