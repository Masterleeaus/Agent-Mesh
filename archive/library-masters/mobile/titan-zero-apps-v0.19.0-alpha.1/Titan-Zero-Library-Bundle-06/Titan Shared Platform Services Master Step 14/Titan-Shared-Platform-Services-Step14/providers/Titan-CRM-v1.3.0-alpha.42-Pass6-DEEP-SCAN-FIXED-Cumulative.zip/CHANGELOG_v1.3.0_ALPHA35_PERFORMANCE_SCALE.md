# Titan CRM Core v1.3.0-alpha.35 — Performance & Scale Certification

## Added
- `crm_read_projection_search_terms` disposable indexed search table and composite scale indexes.
- `CrmProjectionSearchIndexer` and `crm:projections:search-index`.
- `CrmPerformanceAuditService` and read-only `crm:performance:certify`.
- dependency-free `bin/benchmark-v130-alpha35-scale.php` for bounded working-set checks at logical 10k/100k/1m scale.
- alpha.35 performance/scale certification report.

## Optimized
- Projection rebuilds now batch upserts and update state once per batch.
- SQL projection search uses indexed candidates instead of recent-row scanning.
- Pipeline board removes per-stage deal queries and bounds detail rows.
- Customer timeline bounds each source window before merge/sort.
- Forecast, analytics, dashboard and receivables calculations use SQL aggregation where appropriate.
- Import staging uses batch inserts while governed authoritative commit remains per-record.
- Company detail, portal file and production-health reads avoid unbounded row materialisation.

## Fixed
- External API customer/contact search and pagination now pass repository-supported `q` and `limit` filters.
- Full projection rebuilds above configured limits no longer silently truncate; operators are directed to incremental `--until-complete`.

## Architecture
No table partitioning was introduced. Performance commands and projection search state are read-only/disposable and do not change CRM domain authority.
