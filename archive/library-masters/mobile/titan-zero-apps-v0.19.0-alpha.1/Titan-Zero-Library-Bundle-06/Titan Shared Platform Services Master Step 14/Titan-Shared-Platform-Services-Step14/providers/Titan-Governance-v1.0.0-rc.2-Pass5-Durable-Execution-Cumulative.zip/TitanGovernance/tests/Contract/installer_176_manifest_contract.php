<?php

declare(strict_types=1);

$root=dirname(__DIR__,2);
$manifest=json_decode((string)file_get_contents($root.'/extension.json'),true,512,JSON_THROW_ON_ERROR);

function fail176(string $m): never { fwrite(STDERR,"FAIL: {$m}\n"); exit(1); }
function assert176(bool $c,string $m): void { if(!$c) fail176($m); }

assert176(($manifest['name']??null)==='Titan Governance','Installer 1.7.6 requires root name');
assert176(($manifest['type']??null)==='extension','Installer 1.7.6 requires type=extension');
assert176(is_string($manifest['description']??null)&&trim((string)$manifest['description'])!=='','Installer 1.7.6 requires non-empty description');
assert176(array_key_exists('support_telegram',$manifest)&&is_string($manifest['support_telegram']),'Installer 1.7.6 requires string support_telegram');
assert176(($manifest['schema']??null)==='titan-extension-v1','Titan installer schema retained');
assert176(($manifest['slug']??null)==='titan-governance','slug retained');
assert176(($manifest['folder']??null)==='TitanGovernance','folder retained');
assert176(($manifest['provider']??null)==='App\\Extensions\\TitanGovernance\\System\\TitanGovernanceServiceProvider','provider retained');
assert176(isset($manifest['integrity']['files'])&&is_array($manifest['integrity']['files']),'integrity map retained');

echo "PASS: Installer 1.7.6 + Titan root manifest compatibility\n";
