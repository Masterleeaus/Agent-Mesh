@push('css')
<link rel="stylesheet" href="{{ asset('vendor/titan-connect/css/operator-inbox.css') }}">
@endpush

<div class="container-fluid py-6">
<section
    id="titan-connect-settings"
    class="tc-operator tc-settings"
    data-diagnostics-url="{{ route('titan-connect.api.diagnostics.index') }}"
    data-diagnostics-base="{{ url('/api/titan-connect/diagnostics') }}"
    data-connections-base="{{ url('/api/titan-connect/connections') }}"
    data-csrf="{{ csrf_token() }}"
>
    <header class="tc-operator__header">
        <div>
            <h1>{{ __('Titan Connect Settings') }}</h1>
            <p>{{ __('Connection diagnostics and deployment readiness. Provider secrets remain in the encrypted company vault.') }}</p>
        </div>
        <div class="tc-operator__header-actions"><a class="tc-btn" href="{{ route('dashboard.user.titan-connect.inbox.index') }}">{{ __('Back to inbox') }}</a><button class="tc-btn tc-btn--primary" type="button" data-action="refresh-diagnostics">{{ __('Refresh diagnostics') }}</button></div>
    </header>

    <div class="tc-settings__notice">
        <strong>{{ __('Host readiness') }}</strong>
        <span>{{ __('Run') }} <code>php artisan titan-connect:diagnose</code> {{ __('from the Titan Zero host to verify MySQL, company schema, queue/cache, broadcast, storage and scanner bindings.') }}</span>
    </div>

    <section class="tc-panel">
        <div class="tc-panel__title"><strong>{{ __('Connection diagnostics') }}</strong></div>
        <div data-role="settings-diagnostics" class="tc-diagnostic-grid"><div class="tc-empty">{{ __('Loading diagnostics…') }}</div></div>
    </section>
    <div class="tc-status" data-role="settings-status" aria-live="polite"></div>
</section>

</div>

@push('script')
<script src="{{ asset('vendor/titan-connect/js/settings.js') }}" defer></script>
@endpush
