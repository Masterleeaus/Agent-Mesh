<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Adapters\Platform;

use App\Extensions\TitanNexus\System\Contracts\PlatformReadinessSourceContract;
use InvalidArgumentException;
use RuntimeException;

final class PlatformReadinessAdapter implements PlatformReadinessSourceContract
{
    /** @var list<string> */
    private readonly array $staticCapabilities;

    /**
     * @param (callable(list<string>): array<mixed>)|null $resolver
     * @param list<string> $staticCapabilities
     */
    public function __construct(
        private readonly mixed $resolver = null,
        array $staticCapabilities = [],
    ) {
        if ($this->resolver !== null && !is_callable($this->resolver)) {
            throw new InvalidArgumentException('Platform readiness resolver must be callable or null.');
        }

        $normalized = [];
        foreach ($staticCapabilities as $capability) {
            $normalized[] = self::capabilityKey($capability);
        }
        $normalized = array_values(array_unique($normalized));
        sort($normalized, SORT_STRING);
        $this->staticCapabilities = $normalized;
    }

    public function check(array $capabilities): array
    {
        $requested = [];
        foreach ($capabilities as $capability) {
            $requested[] = self::capabilityKey($capability);
        }
        $requested = array_values(array_unique($requested));
        sort($requested, SORT_STRING);

        if ($requested === []) {
            return [];
        }

        if ($this->resolver === null) {
            $result = [];
            foreach ($requested as $capability) {
                $result[$capability] = in_array($capability, $this->staticCapabilities, true);
            }
            return $result;
        }

        $raw = ($this->resolver)($requested);
        if (!is_array($raw)) {
            throw new RuntimeException('Platform readiness resolver must return an array.');
        }

        $available = [];
        if (array_is_list($raw)) {
            foreach ($raw as $capability) {
                $available[self::capabilityKey($capability)] = true;
            }
        } else {
            foreach ($raw as $capability => $ready) {
                if (!is_string($capability) || !is_bool($ready)) {
                    throw new RuntimeException('Platform readiness map must contain string capability keys and boolean readiness values.');
                }
                $available[self::capabilityKey($capability)] = $ready;
            }
        }

        $result = [];
        foreach ($requested as $capability) {
            $result[$capability] = $available[$capability] ?? false;
        }
        return $result;
    }

    private static function capabilityKey(mixed $value): string
    {
        if (!is_string($value)) {
            throw new InvalidArgumentException('Platform capability keys must be strings.');
        }
        $value = trim($value);
        if ($value === '' || strlen($value) > 160 || preg_match('/^[a-z0-9][a-z0-9._:-]*$/', $value) !== 1) {
            throw new InvalidArgumentException('Platform capability key is invalid.');
        }
        return $value;
    }
}
