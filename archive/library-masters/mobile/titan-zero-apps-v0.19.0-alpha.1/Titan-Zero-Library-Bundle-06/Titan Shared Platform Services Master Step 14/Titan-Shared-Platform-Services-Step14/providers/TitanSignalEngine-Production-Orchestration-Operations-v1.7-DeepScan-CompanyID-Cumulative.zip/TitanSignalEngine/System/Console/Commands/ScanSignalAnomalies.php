<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Console\Commands;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalAnomalyContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalContext;
use App\Extensions\TitanSignalEngine\System\Data\SignalEnvelope;
use App\Extensions\TitanSignalEngine\System\Models\SignalPulseRollup;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

final class ScanSignalAnomalies extends Command
{
    protected $signature = 'titan:signal-anomalies:scan {--limit=100 : Maximum tenant scopes to scan per run}';
    protected $description = 'Evaluate rule-based Signal anomalies from Pulse and Correlation projections.';

    public function __construct(private readonly SignalAnomalyContract $anomalies)
    {
        parent::__construct();
    }

    public function handle(): int
    {
        if (! Schema::hasTable('titan_signal_pulse_rollups')) {
            $this->components->info('Titan Signal anomaly scan skipped: Pulse projections are not initialized.');
            return self::SUCCESS;
        }

        $limit = max(1, min((int) $this->option('limit'), 1000));
        $context = SignalContext::system('titan-signal-anomaly-scanner', 'system', [
            'signal.system.read',
            'signal.tenant.read',
            'signal.tenant.emit',
        ]);

        $cursor = 0;
        if (Schema::hasTable('titan_signal_anomaly_scan_state')) {
            $cursor = (int) (DB::table('titan_signal_anomaly_scan_state')->where('scan_key', 'tenant-round-robin')->value('cursor_tenant_company_id') ?? 0);
        }
        $tenantIds = $this->tenantBatch($cursor, $limit);
        if ($tenantIds->isEmpty() && $cursor > 0) {
            $cursor = 0;
            $tenantIds = $this->tenantBatch(0, $limit);
        }

        $scanned = 0;
        $findings = 0;
        foreach ($tenantIds as $tenantId) {
            $findings += count($this->anomalies->scan($context, (int) $tenantId, SignalEnvelope::SCOPE_TENANT));
            $scanned++;
            $cursor = (int) $tenantId;
        }
        if (Schema::hasTable('titan_signal_anomaly_scan_state')) {
            DB::table('titan_signal_anomaly_scan_state')->updateOrInsert(
                ['scan_key' => 'tenant-round-robin'],
                ['cursor_tenant_company_id' => $cursor, 'last_completed_at' => now(), 'created_at' => now(), 'updated_at' => now()],
            );
        }

        $hasSystem = SignalPulseRollup::query()->where('scope', SignalEnvelope::SCOPE_SYSTEM)->exists();
        if ($hasSystem) {
            $findings += count($this->anomalies->scan($context, null, SignalEnvelope::SCOPE_SYSTEM));
            $scanned++;
        }

        $this->components->info("Titan Signal anomaly scan complete: {$scanned} scopes, {$findings} active detections.");
        return self::SUCCESS;
    }

    private function tenantBatch(int $afterTenantId, int $limit)
    {
        return SignalPulseRollup::query()
            ->where('scope', SignalEnvelope::SCOPE_TENANT)
            ->where('tenant_key', '>', max(0, $afterTenantId))
            ->select('tenant_key')
            ->distinct()
            ->orderBy('tenant_key')
            ->limit($limit)
            ->pluck('tenant_key');
    }
}
