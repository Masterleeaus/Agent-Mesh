<?php
declare(strict_types=1);

$GLOBALS['tcb_test_config'] = [
    'titan-command-bus.enabled' => true,
    'titan-command-bus.require_lifecycle' => false,
    'titan-command-bus.kill_switch' => false,
    'titan-command-bus.max_payload_bytes' => 65536,
    'titan-command-bus.allow_offline_revalidation' => true,
    'titan-command-bus.require_signal' => true,
    'titan-command-bus.require_risk' => true,
    'titan-command-bus.require_assurance' => true,
    'titan-command-bus.require_autonomy' => false,
];
if (!function_exists('config')) {
    function config(string $key, mixed $default = null): mixed { return $GLOBALS['tcb_test_config'][$key] ?? $default; }
}

$root=dirname(__DIR__,2);
foreach ([
    'System/DTO/CommandContext.php','System/DTO/CommandRequest.php','System/DTO/RiskDecision.php','System/DTO/AssuranceDecision.php','System/DTO/GovernanceDecision.php','System/DTO/CommandExecutionResult.php','System/DTO/CommandReceipt.php',
    'System/Contracts/CommandAdapterContract.php','System/Contracts/CommandAdapterRegistryContract.php','System/Contracts/CommandRiskGateContract.php','System/Contracts/CommandAssuranceGateContract.php','System/Contracts/CommandGovernanceGateContract.php','System/Contracts/CommandReceiptStoreContract.php','System/Contracts/CommandSignalEmitterContract.php','System/Contracts/CommandBusContract.php',
    'System/Contracts/CommandLifecycleStoreContract.php','System/Services/CommandLifecycleState.php','System/Services/CommandBus.php',
] as $rel) require_once $root.'/'.$rel;

use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterRegistryContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAssuranceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandRiskGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandGovernanceGateContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandReceiptStoreContract;
use App\Extensions\TitanCommandBus\System\Contracts\CommandSignalEmitterContract;
use App\Extensions\TitanCommandBus\System\DTO\AssuranceDecision;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandExecutionResult;
use App\Extensions\TitanCommandBus\System\DTO\CommandReceipt;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use App\Extensions\TitanCommandBus\System\DTO\GovernanceDecision;
use App\Extensions\TitanCommandBus\System\DTO\RiskDecision;
use App\Extensions\TitanCommandBus\System\Services\CommandBus;

final class RiskTestAdapter implements CommandAdapterContract {
    public int $calls=0;
    public function capability(): string { return 'crm.invoice.create'; }
    public function execute(CommandContext $context, CommandRequest $request, string $operationId): CommandExecutionResult {
        $this->calls++;
        return new CommandExecutionResult('crm:invoice:91', true, 91, 'invoice', 4);
    }
}
final class RiskTestRegistry implements CommandAdapterRegistryContract {
    public function __construct(public RiskTestAdapter $adapter) {}
    public function register(CommandAdapterContract $adapter): void {}
    public function has(string $capability): bool { return $capability===$this->adapter->capability(); }
    public function forCapability(string $capability): ?CommandAdapterContract { return $this->has($capability)?$this->adapter:null; }
    public function count(): int { return 1; }
}
final class RiskTestRisk implements CommandRiskGateContract {
    public int $calls=0;
    public function __construct(public bool $isAvailable, public bool $allow=true) {}
    public function available(): bool { return $this->isAvailable; }
    public function assess(CommandContext $context, CommandRequest $request): RiskDecision {
        $this->calls++;
        return $this->allow
            ? new RiskDecision(true, 'risk:assessment:1', 'HIGH', 0.81, ['human_confirmation'])
            : new RiskDecision(false, 'risk:assessment:2', 'CRITICAL', 0.97, ['manual_review'], 'RISK_DENIED');
    }
}

final class RiskTestMalformedRisk implements CommandRiskGateContract {
    public function available(): bool { return true; }
    public function assess(CommandContext $context, CommandRequest $request): RiskDecision {
        return new RiskDecision(true, 'risk:malformed', null, 0.20);
    }
}
final class RiskTestAssurance implements CommandAssuranceGateContract {
    public function available(): bool { return true; }
    public function assess(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null): AssuranceDecision {
        return new AssuranceDecision(true,'assurance:risk-test','POLICY',['evidence:risk-test']);
    }
}
final class RiskTestGovernance implements CommandGovernanceGateContract {
    public int $calls=0;
    public ?string $lastRiskReference=null;
    public function available(): bool { return true; }
    public function evaluate(CommandContext $context, CommandRequest $request, ?RiskDecision $risk = null, ?AssuranceDecision $assurance = null, ?\App\Extensions\TitanCommandBus\System\DTO\AutonomyDecision $autonomy = null): GovernanceDecision {
        $this->calls++;
        $this->lastRiskReference=$risk?->reference;
        return new GovernanceDecision(true,'gov:decision:1',null,'approval:1');
    }
}
final class RiskTestStore implements CommandReceiptStoreContract {
    public array $claims=[];
    private function key(CommandContext $c, CommandRequest $r): string { return $c->tenantCompanyId.'|'.$r->idempotencyKey; }
    public function existing(CommandContext $context, CommandRequest $request): ?array { return $this->claims[$this->key($context,$request)] ?? null; }
    public function claim(CommandContext $context, CommandRequest $request, string $operationId, string $requestHash): bool {
        $k=$this->key($context,$request); if(isset($this->claims[$k])) return false;
        $this->claims[$k]=['request_hash'=>$requestHash,'operation_id'=>$operationId,'status'=>'processing','receipt'=>null]; return true;
    }
    public function complete(CommandReceipt $receipt): void {
        $k=$receipt->tenantCompanyId.'|'.$receipt->idempotencyKey;
        $this->claims[$k]['status']=$receipt->status; $this->claims[$k]['receipt']=$receipt->toArray();
    }
    public function health(): array { return ['receipts_table'=>true,'idempotency_table'=>true]; }
}
final class RiskTestSignals implements CommandSignalEmitterContract {
    public array $events=[];
    public function available(): bool { return true; }
    public function emit(string $type, array $payload): void { $this->events[$type]=$payload; }
}

$ctx=new CommandContext(42,'agent','ar-agent','titan-workforce');
$adapter=new RiskTestAdapter();
$registry=new RiskTestRegistry($adapter);
$gov=new RiskTestGovernance();
$signals=new RiskTestSignals();

$risk=new RiskTestRisk(false);
$bus=new CommandBus($registry,$risk,new RiskTestAssurance(),$gov,new RiskTestStore(),$signals);
$blocked=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>5000],'risk-unavailable','t1','c1','cause1','root1'));
if($blocked->status!=='blocked'||$blocked->reasonCode!=='RISK_UNAVAILABLE'||$adapter->calls!==0||$gov->calls!==0) throw new RuntimeException('risk unavailable must fail closed before governance and adapter execution');

$gov=new RiskTestGovernance();
$bus=new CommandBus($registry,new RiskTestMalformedRisk(),new RiskTestAssurance(),$gov,new RiskTestStore(),$signals);
$malformed=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>5000],'risk-malformed','tm','cm','causem','rootm'));
if($malformed->status!=='blocked'||$malformed->reasonCode!=='RISK_DECISION_INVALID'||$gov->calls!==0||$adapter->calls!==0) throw new RuntimeException('malformed allowed risk decision without class must fail closed');

$risk=new RiskTestRisk(true,false);
$gov=new RiskTestGovernance();
$bus=new CommandBus($registry,$risk,new RiskTestAssurance(),$gov,new RiskTestStore(),$signals);
$denied=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>5000],'risk-denied','t2','c2','cause2','root2'));
if($denied->status!=='blocked'||$denied->reasonCode!=='RISK_DENIED'||$denied->riskReference!=='risk:assessment:2'||$denied->riskClass!=='CRITICAL'||$denied->riskScore!==0.97||$adapter->calls!==0||$gov->calls!==0) throw new RuntimeException('risk denial must be durable and stop before governance');

$risk=new RiskTestRisk(true,true);
$gov=new RiskTestGovernance();
$bus=new CommandBus($registry,$risk,new RiskTestAssurance(),$gov,new RiskTestStore(),$signals);
$applied=$bus->dispatch($ctx,new CommandRequest('crm.invoice.create',['amount'=>5000],'risk-allow','t3','c3','cause3','root3'));
if($applied->status!=='applied'||$applied->riskReference!=='risk:assessment:1'||$applied->riskClass!=='HIGH'||$applied->riskScore!==0.81||$gov->calls!==1||$gov->lastRiskReference!=='risk:assessment:1'||$adapter->calls!==1) throw new RuntimeException('risk evidence must flow into successful governed receipt');
if(($signals->events['command.completed']['risk_reference']??null)!=='risk:assessment:1'||($signals->events['command.completed']['risk_class']??null)!=='HIGH') throw new RuntimeException('risk evidence must propagate into command outcome Signal telemetry');

$health=$bus->health();
if(($health['dependencies']['risk']??null)!==true) throw new RuntimeException('health must report risk dependency readiness');

echo "PASS RiskIntegrationTest\n";
