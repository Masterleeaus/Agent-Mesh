# Titan Command Bus v0.2.0-alpha.1 — Blueprint v4.2.0 Rebase Report

## Result

The v0.1.0 scaffold has been rebased to Titan Extension Blueprint v4.2.0 as a canonical `system-engine` with the `command-bus-core` and `signal-aware` modifiers.

## Critical corrections from v0.1.0

- Removed the outer `TitanCommandBus/` installer wrapper; release ZIP is flat-root.
- Replaced the legacy five-field root manifest with `titan-extension-v1`.
- Upgraded the rich sidecar to Blueprint schema `2.2` and production-core inheritance.
- Replaced the global `extension` publish tag with `titan-command-bus-config`.
- Removed the ordinary tenant-user Command Bus UI; retained an admin operations surface only.
- Replaced placeholder-only runtime with canonical command/context/decision/result/receipt DTOs and a real dispatch pipeline.
- Added trusted server-side tenant/actor context separation; the command payload cannot provide `tenant_company_id` or trusted actor authority.
- Added database-backed, tenant-scoped idempotency claims with unique collision protection.
- Added deterministic adapter registry and explicit authoritative-domain receipt/write verification.
- Added fail-closed governance and Signal defaults.
- Added optimistic entity-version field support and mandatory online revalidation policy for prepared-offline commands.
- Added causal Signal events for request, completion, refusal and failure.
- Added a canonical certification command and Super Admin navigation contribution.
- Preserved command receipts/idempotency evidence on uninstall.

## Blueprint-specific authority model

Command Bus is the canonical owner of `governed-mutation` but does not own foreign business records. It may write only its declared internal execution state (`titan_command_receipts`, `titan_command_idempotency`). Cross-domain writes are adapter-only and remain forbidden to Command Bus core.

`governance.command_bus = self` is a narrow self-boundary exception. Recursive self-dispatch is forbidden.

## Receipt truthfulness

Applied mutations require fresh governance, a governance reference, a domain adapter, an authoritative domain receipt reference and `write_verified=true`. Early refusals and idempotent replays do not falsely claim that a fresh governance evaluation occurred.

## Development-stage limitations

- No live Titan Zero/MagicAI Laravel host was supplied for database migration execution, route cache, menu rendering, browser, queue or end-to-end adapter tests.
- Titan Governance/Assurance/Risk/Autonomy bridges are intentionally not guessed; the default governance bridge is unavailable and therefore blocks execution.
- Titan Signal transport is intentionally not guessed; the default emitter is unavailable and `require_signal=true` blocks mutation until a trusted bridge is bound.
- No domain adapters ship in the core package.
- Larastan level 8 was not executed because the host dependency tree was not supplied.
- No production signing key was supplied; the package is unsigned and must not be represented as production-signed or host-certified.
