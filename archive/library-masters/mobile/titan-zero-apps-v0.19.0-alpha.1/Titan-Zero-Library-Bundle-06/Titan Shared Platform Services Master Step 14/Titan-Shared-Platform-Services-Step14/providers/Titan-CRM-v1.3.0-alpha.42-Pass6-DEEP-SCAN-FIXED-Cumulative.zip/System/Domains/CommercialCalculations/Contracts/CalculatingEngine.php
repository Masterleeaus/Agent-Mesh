<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Domains\CommercialCalculations\Contracts;

use App\Extensions\Crm\System\Domains\CommercialCalculations\DTO\CalculationContext;
use App\Extensions\Crm\System\Domains\CommercialCalculations\DTO\CalculationResult;

interface CalculatingEngine
{
    public function key(): string;
    public function priority(): int;
    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult;
}
