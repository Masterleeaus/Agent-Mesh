<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Tenancy;

use Closure;
use Illuminate\Database\Query\Builder;
use RuntimeException;

final class CrmCompanyScope
{
    public function __construct(
        private readonly CrmCompanyContextStore $store,
        private readonly CrmCompanyContextResolver $resolver,
    ) {}

    public static function companyId(?int $legacyActorUserId = null): int
    {
        /** @var self $scope */
        $scope = app(self::class);
        return $scope->resolveCompanyId($legacyActorUserId);
    }

    public static function actorUserId(?int $fallback = null): ?int
    {
        /** @var self $scope */
        $scope = app(self::class);
        $current = $scope->store->current();
        if ($current?->actorUserId) return $current->actorUserId;
        $authId = auth()->id();
        if ($authId !== null) return (int) $authId;
        return $fallback !== null && $fallback > 0 ? $fallback : null;
    }

    public static function query(Builder $query, ?int $legacyActorUserId = null, string $column = 'company_id'): Builder
    {
        return $query->where($column, self::companyId($legacyActorUserId));
    }

    public function current(): CrmCompanyContext
    {
        $context = $this->store->current();
        if ($context) return $context;
        $context = $this->resolver->resolveAuthenticated();
        $this->store->push($context);
        return $context;
    }

    public function runWith(CrmCompanyContext $context, Closure $callback): mixed
    {
        $this->store->push($context);
        try { return $callback($context); }
        finally { $this->store->pop(); }
    }

    private function resolveCompanyId(?int $legacyActorUserId): int
    {
        if ($context = $this->store->current()) return $context->companyId;
        if (auth()->check()) return $this->current()->companyId;
        if ($legacyActorUserId !== null && $legacyActorUserId > 0) return $this->resolver->companyIdForActorId($legacyActorUserId);
        throw new RuntimeException('CRM company_id is unavailable; refusing unscoped CRM access.');
    }
}
