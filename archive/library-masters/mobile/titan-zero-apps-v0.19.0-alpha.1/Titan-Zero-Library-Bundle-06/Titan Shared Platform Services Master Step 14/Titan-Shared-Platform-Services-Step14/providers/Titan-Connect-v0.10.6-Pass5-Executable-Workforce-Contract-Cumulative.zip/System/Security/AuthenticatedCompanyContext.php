<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Security;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

final class AuthenticatedCompanyContext implements CompanyContext
{
    public function companyId(Request $request): int
    {
        $user = $request->user();
        if ($user === null) {
            throw new AuthenticationException('Authentication is required for Titan Connect.');
        }

        $companyId = $user->company_id;
        if (! is_numeric($companyId) || (int) $companyId <= 0) {
            throw new AccessDeniedHttpException('No authenticated company context is available.');
        }

        return (int) $companyId;
    }

    public function actorId(Request $request): int
    {
        $user = $request->user();
        if ($user === null) {
            throw new AuthenticationException('Authentication is required for Titan Connect.');
        }

        $actorId = $user->getAuthIdentifier();
        if (! is_numeric($actorId) || (int) $actorId <= 0) {
            throw new AccessDeniedHttpException('No authenticated actor is available.');
        }

        return (int) $actorId;
    }
}
