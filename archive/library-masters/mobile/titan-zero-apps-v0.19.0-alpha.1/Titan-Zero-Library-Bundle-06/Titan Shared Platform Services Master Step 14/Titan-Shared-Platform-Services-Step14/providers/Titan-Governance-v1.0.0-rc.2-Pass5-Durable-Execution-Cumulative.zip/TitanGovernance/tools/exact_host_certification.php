<?php

declare(strict_types=1);
$root=dirname(__DIR__);
require_once $root.'/System/Host/TitanExactHostCertification.php';
use App\Extensions\TitanGovernance\System\Host\TitanExactHostCertification;
$sha=$argv[1]??'NOT_BUILT';
$evidence=[];
if(isset($argv[2])){$raw=is_file($argv[2])?(string)file_get_contents($argv[2]):$argv[2];$decoded=json_decode($raw,true);if(is_array($decoded))$evidence=$decoded;}
$result=(new TitanExactHostCertification())->report($sha,$evidence);
echo json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES).PHP_EOL;
