<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

final class RewindCase extends Model
{
    protected $table = 'titan_rewind_cases';
    protected $fillable = [
        'case_uuid','tenant_company_id','case_key','title','status','severity','source_type','source_id','primary_trace_id',
        'entity_type','entity_id','detected_at','metadata','resolved_at','resolved_by_type','resolved_by_id',
    ];
    protected $casts = ['tenant_company_id'=>'integer','metadata'=>'array','detected_at'=>'datetime','resolved_at'=>'datetime'];

    public function traces(): HasMany
    {
        return $this->hasMany(RewindCaseTrace::class, 'case_id');
    }
}
