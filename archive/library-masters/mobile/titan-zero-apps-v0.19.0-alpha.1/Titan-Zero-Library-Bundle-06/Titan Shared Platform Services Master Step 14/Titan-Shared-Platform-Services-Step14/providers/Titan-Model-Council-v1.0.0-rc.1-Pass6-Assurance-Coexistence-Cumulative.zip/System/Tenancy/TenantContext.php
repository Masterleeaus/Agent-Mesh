<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Tenancy;

use InvalidArgumentException;

final readonly class TenantContext
{
    public function __construct(public int $tenantCompanyId)
    {
        if ($tenantCompanyId < 1) {
            throw new InvalidArgumentException('tenant_company_id must be positive.');
        }
    }
}
