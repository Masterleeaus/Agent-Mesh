# Titan Forge v0.8 — Verified Peer Contract Matrix

| Engine | Verified package | Public contract used by Forge | Forge v0.8 treatment |
|---|---|---|---|
| Titan AI Core | v0.3.0 Pass 2 Typed Core Domain, Blueprint v4.2 | `OrchestratorContract::createPlan(...)`, `PlanValidatorContract::validate(...)` | Typed planning consumer remains fail-closed while AI Core reports `DAG_VALIDATOR_NOT_IMPLEMENTED`; no direct model fallback. |
| Titan Signal | v0.2.0 Pass 1 Foundation | `SignalEmitterContract::emit(...)` | Forge lifecycle facts with complete causal lineage. |
| Titan Risk | v0.2.1 Pass 2A | `RiskGateContract::evaluate(...)` | Deny rejects; approval/hold blocks; high/critical triggers Council. |
| Titan Shield | v0.3.0 Inspection Foundation | `ShieldManagerContract::determineGovernanceResponse(...)` | Governs Forge static-validation findings. |
| Titan Model Council | v0.7.0 Blueprint v4.2 Rebase | `CouncilGatewayContract::decideActivation(...)` and `runGoverned(...)` | Real bounded governed deliberation for high/critical candidates; sanitized receipt only; advisory authority only. |
| Titan Governance | verified Forge boundary remains fail-closed pending callable release-decision adapter | Forge governance gateway | No fabricated approval. |
| Titan Command Bus | verified Forge boundary remains fail-closed pending callable release-dispatch adapter | Forge command gateway | No direct install/deploy fallback. |

## Council compatibility floor

Forge v0.8 declares `titan-model-council >=0.7.0` as an optional peer. It remains optional because low/medium generation can exist without it, but high/critical candidates fail closed when governed deliberation is unavailable or not configured.
