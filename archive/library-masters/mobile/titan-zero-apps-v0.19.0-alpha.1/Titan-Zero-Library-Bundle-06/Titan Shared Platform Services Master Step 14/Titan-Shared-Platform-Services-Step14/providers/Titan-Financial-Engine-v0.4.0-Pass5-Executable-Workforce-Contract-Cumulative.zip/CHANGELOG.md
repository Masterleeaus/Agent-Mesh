# Changelog

## 0.4.0 — Financial Assistants

- Renamed the company-user parent menu from **Financial** to **Financial Assistants**.
- Renamed the launcher child to **All Assistants**.
- Added icons to every company-user and Super Admin Financial navigation item.
- Added a clickable workspace route for each of the 17 financial engines.
- Reframed engine names as plain-English assistants for easier discovery.
- Added category-grouped assistant launcher cards with distinct icons and Open Assistant actions.
- Added guided forms and formatted results for all 17 assistants.
- Added simplified adapters for Materials Cost, Cash Flow Forecast and safe Formula Rules.
- Preserved fixed-point arithmetic, engine enable/disable governance and calculation audit traces.
- Added an upgrade migration that refreshes already-installed v0.3.x MagicAI menu rows and cache state.

## 0.3.0 — Navigation & Settings

- Added real Financial parent/child navigation definitions for company users.
- Added Titan Financial Engine Super Admin navigation definitions.
- Added Blueprint/Titan user/admin contribution-registry adapter.
- Added host-schema-defensive MagicAI `menus` database synchronisation for user navigation.
- Added admin database synchronisation only where `is_admin` is explicitly supported.
- Added MagicAI menu cache regeneration and uninstall cleanup.
- Added company and platform Financial Settings persistence and UI.
- Added global engine enable/disable controls and audit-persistence governance.
- Wired company defaults into Quote Builder currency, tax, validity and Good/Better/Best margins.
- Added atomic configurable quote numbering.
- Wired approval, hard-floor and max-discount settings into quote governance.
- Wired Jobs/Titan Gear/Titan Pay switches into handoff generation.
- Fixed company/platform Settings route separation.
- Removed binary-float comparisons from settings validation.

## 0.2.0 — Commercial Layer

- Added Price Books, Rate Cards, Margin Policies and Good/Better/Best Quote Builder.
- Added live quote simulation, versioned quotes and Jobs/Gear/Pay handoff payloads.

## 0.1.0 — Calculation Kernel

- Added fixed-point Decimal arithmetic, calculation pipeline/audit ledger and 17 registered engines.
- Migrated Discount Manager into Promotions & Discounts.
