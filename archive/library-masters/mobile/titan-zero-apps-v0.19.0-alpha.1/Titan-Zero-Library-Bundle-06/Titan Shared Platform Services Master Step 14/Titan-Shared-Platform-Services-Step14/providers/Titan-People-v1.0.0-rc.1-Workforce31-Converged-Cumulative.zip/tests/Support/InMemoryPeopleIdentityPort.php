<?php

declare(strict_types=1);

namespace TitanPeopleTests\Support;

use App\Extensions\TitanPeople\System\Contracts\PeopleIdentityPort;
use App\Extensions\TitanPeople\System\Contracts\WorkerIdentity;
use RuntimeException;

final class InMemoryPeopleIdentityPort implements PeopleIdentityPort
{
    /** @var array<string,WorkerIdentity> */
    private array $workers = [];

    /** @param list<WorkerIdentity> $workers */
    public function __construct(array $workers)
    {
        foreach ($workers as $worker) {
            $this->workers[$worker->tenantCompanyId.'|'.$worker->subject] = $worker;
        }
    }

    public function resolveWorker(int $tenantCompanyId, string|int $subject): WorkerIdentity
    {
        $key = $tenantCompanyId.'|'.(string) $subject;
        return $this->workers[$key] ?? throw new RuntimeException('Worker identity not found for authenticated tenant context.');
    }
}
