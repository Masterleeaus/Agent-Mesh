<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindTraceEvent extends Model
{
    protected $table = 'titan_rewind_trace_events';

    protected $fillable = [
        'record_uuid','tenant_company_id','event_id','trace_id','correlation_id','causation_id','source_engine','source_record_id',
        'event_type','sequence','tier','lane','actor_type','actor_id','decision_id','policy_version','guide_version','knowledge_version',
        'model_provider','model_name','model_version','capability_name','capability_version','reason_codes','evidence_refs','rationale',
        'risk_state','assurance_state','autonomy_state','governance_state','payload','occurred_at','recorded_at','source_hash','previous_hash',
        'integrity_hash','canonical_hash','chain_position','chain_previous_hash','chain_hash','integrity_checked_at','schema_version',
    ];

    protected $casts = [
        'tenant_company_id'=>'integer','sequence'=>'integer','tier'=>'integer','chain_position'=>'integer','schema_version'=>'integer',
        'reason_codes'=>'array','evidence_refs'=>'array','rationale'=>'array','risk_state'=>'array','assurance_state'=>'array',
        'autonomy_state'=>'array','governance_state'=>'array','payload'=>'array','occurred_at'=>'datetime','recorded_at'=>'datetime','integrity_checked_at'=>'datetime',
    ];
}
