<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Http\Controllers;

use App\Extensions\Crm\System\Services\{CrmHostSettingsService, CrmSettingsService};
use App\Extensions\Crm\System\Governance\CrmHumanMutationGateway;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class SettingsController extends Controller
{
    public function __construct(
        private CrmSettingsService $settings,
        private CrmHostSettingsService $hostSettings,
        private CrmHumanMutationGateway $mutations,
    ) {}

    public function index(Request $request)
    {
        $data = ['settings' => $this->settings->all((int) $request->user()->id)];
        return $request->expectsJson() ? response()->json($data) : view('crm::admin.settings', $data + ['hostSettings' => $this->hostSettings->all(), 'adminMode' => false]);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'default_currency' => 'nullable|string|size:3',
            'default_pipeline_public_id' => 'nullable|string|size:26',
            'lead_follow_up_days' => 'nullable|integer|min:1|max:365',
            'auto_capture_contacts' => 'sometimes|boolean',
            'create_lead_on_capture' => 'sometimes|boolean',
            'notifications_enabled' => 'sometimes|boolean',
            'notification_channel' => 'nullable|string|in:email,in_app,webhook',
        ]);
        $saved = $this->mutations->execute($request,'crm.settings.update',$data);
        return $request->expectsJson() ? response()->json(['data' => $saved]) : back()->with('status', 'CRM settings saved.');
    }

    public function adminIndex(Request $request)
    {
        $data = [
            'settings' => $this->settings->all((int) $request->user()->id),
            'hostSettings' => $this->hostSettings->all(),
            'adminMode' => true,
        ];
        return $request->expectsJson() ? response()->json($data) : view('crm::admin.settings', $data);
    }

    public function adminUpdate(Request $request)
    {
        $data = $request->validate([
            'crm_enabled' => 'required|boolean',
            'crm_assistant_enabled' => 'required|boolean',
            'crm_presentations_enabled' => 'required|boolean',
        ]);
        $saved = $this->hostSettings->update($data);
        return $request->expectsJson() ? response()->json(['data' => $saved]) : back()->with('status', 'MagicAI CRM host settings saved.');
    }
}
