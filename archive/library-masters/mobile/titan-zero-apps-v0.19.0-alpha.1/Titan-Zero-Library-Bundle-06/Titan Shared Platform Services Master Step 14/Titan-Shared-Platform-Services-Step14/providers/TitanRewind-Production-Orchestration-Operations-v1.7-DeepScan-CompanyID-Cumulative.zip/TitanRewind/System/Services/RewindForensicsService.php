<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Services;

use App\Extensions\TitanRewind\System\Forensics\RewindRootCauseAnalyzer;
use App\Extensions\TitanRewind\System\Forensics\RewindTemporalDiagnostics;
use App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery;

final class RewindForensicsService
{
    public function __construct(
        private RewindIntegrityService $integrity,
        private RewindTemporalDiagnostics $temporal,
        private RewindRootCauseAnalyzer $rootCause,
        private RewindDriftService $drift,
    ) {}

    public function diagnose(RewindTraceQuery $query, array $orderedEvents, array $causation, array $dependencies): array
    {
        $integrity = $this->integrity->inspectTrace($query);
        $temporal = $this->temporal->analyse($orderedEvents);
        $rootCause = $this->rootCause->analyse($orderedEvents, $causation, $dependencies);
        $openFindings = $this->drift->openForTrace($query);

        return [
            'status'=>$this->status($integrity, $temporal, $causation, $openFindings),
            'integrity'=>$integrity,
            'temporal'=>$temporal,
            'root_cause'=>$rootCause,
            'open_drift_findings'=>$openFindings,
            'latest_integrity_check'=>$this->integrity->latest($query)?->toArray(),
        ];
    }

    private function status(array $integrity, array $temporal, array $causation, array $openFindings): string
    {
        if (($integrity['status'] ?? null) === 'failed') return 'critical';
        foreach ($openFindings as $finding) if (($finding['severity'] ?? null) === 'critical') return 'critical';
        if ($openFindings !== []) return 'review';
        if (($integrity['status'] ?? null) === 'partial') return 'review';
        if ((int) ($temporal['sequence_collision_count'] ?? 0) > 0 || count($causation['orphans'] ?? []) > 0) return 'review';
        if (($temporal['status'] ?? null) === 'review') return 'review';
        return 'clear';
    }
}
