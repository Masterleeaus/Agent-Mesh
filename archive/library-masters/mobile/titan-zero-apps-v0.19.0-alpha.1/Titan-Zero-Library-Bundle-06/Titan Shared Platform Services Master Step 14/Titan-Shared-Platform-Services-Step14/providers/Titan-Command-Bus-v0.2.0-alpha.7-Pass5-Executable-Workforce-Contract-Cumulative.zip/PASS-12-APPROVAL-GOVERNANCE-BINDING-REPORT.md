# Pass 12 — Approval Engine / Governance Approval Binding

Status: PASS

Adds a separate fail-closed approval-verification boundary after Governance and before adapter execution. Governance owns approval policy; Command Bus verifies the resulting approval artifact is bound to tenant + capability + exact request hash, unexpired, and allowed. Approval cannot elevate Risk, Assurance, Autonomy, or Governance decisions.

Refusal codes: `APPROVAL_UNAVAILABLE`, `APPROVAL_DENIED`, `APPROVAL_SCOPE_MISMATCH`, `APPROVAL_EXPIRED`.
