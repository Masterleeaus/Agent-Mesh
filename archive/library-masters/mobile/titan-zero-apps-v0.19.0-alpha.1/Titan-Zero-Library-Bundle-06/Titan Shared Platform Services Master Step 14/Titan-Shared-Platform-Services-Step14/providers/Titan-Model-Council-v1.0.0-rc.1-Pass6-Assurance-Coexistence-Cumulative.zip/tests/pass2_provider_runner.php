<?php

declare(strict_types=1);

$providerPath = __DIR__ . '/../System/TitanModelCouncilServiceProvider.php';
$source = file_get_contents($providerPath);
$required = [
    'LegacyCouncilAdapter::class',
    "MarketplaceHelper::isRegistered('ai-chat-pro')",
    "MarketplaceHelper::isRegistered('model-council')",
    "MarketplaceHelper::isRegistered('multi-model')",
    "'prefix' => 'dashboard/user/multimodel'",
    "routes/compatibility.php",
    "loadTranslationsFrom",
];
foreach ($required as $needle) {
    if (! str_contains($source, $needle)) {
        fwrite(STDERR, "FAIL: provider missing compatibility behavior: {$needle}\n");
        exit(1);
    }
}
echo "pass2 provider checks passed\n";
