# Titan CRM Core Production Hardening Alpha.25 Implementation Plan

> **For agentic workers:** Execute this plan test-first. Preserve the extracted-domain strangler boundary and existing tenant data.

**Goal:** Make Titan CRM Core independently deployable and materially safer for production while keeping it authoritative only for customer/sales/commercial CRM state.

**Architecture:** CRM Core boots without Titan Field, Locker, Ledger, or Pay. Historical `crm.*` external-domain capability names remain compatibility contracts but resolve lazily to installed domain extensions instead of making CRM Core register or instantiate their implementations. Core commercial writes use the governed command path; portal, API-key, webhook and sales-contract state fail closed and remain tenant-scoped.

**Tech Stack:** PHP 8.2+, Laravel 10 / MagicAI 11, MySQL, Titan extension installer.

## Global Constraints
- Preserve `tenant_company_id` as the canonical tenant key.
- Do not rename or destructively move historical `crm_*` tables.
- Do not copy Titan Field/Locker/Ledger/Pay implementation code back into CRM Core.
- AI/external mutations remain Command Bus governed.
- Production human web writes fail closed when Titan Command Bus is unavailable; the legacy local-human fallback is disabled by default.
- Every new write path must remain idempotency-capable and receipt/Signal compatible.
- Portal file scanning fails closed by default.
- New migrations must be restartable and safe on upgraded and fresh installs.

---

### Task 1: Split-aware boot independence
- Add a production regression gate proving the root provider does not register extracted-domain providers.
- Introduce a core-domain provider for business configuration and read-only finance helper services retained by CRM Core.
- Introduce an external-domain compatibility bridge/provider that resolves Titan Field/Locker/Ledger/Pay lazily.
- Remove extracted-domain service dependencies from `CrmCapabilityExecutor`.

### Task 2: Correct capability ownership
- Mark each capability with its true owning extension.
- Keep legacy `crm.*` names as compatibility contracts.
- Return an actionable missing-extension result instead of causing container boot failure.

### Task 3: Govern core human mutations
- Add `CrmHumanMutationGateway` over `CrmCommandBusGateway`.
- Route company/contact/lead/deal/sales-document authoritative mutations through it.
- Preserve existing JSON/redirect response shapes.

### Task 4: Commercial contract integrity
- Add lead conversion mapping/provenance fields.
- Add quote/estimate expiry and pricing/tax/terms snapshot fields.
- Add governed `crm.quote.expire` capability and reject acceptance after expiry.

### Task 5: Security hardening
- Require portal file scanning by default.
- Add API-key revocation reason and rotation lineage.
- Add webhook delivery idempotency key plus timestamped signature headers suitable for receiver replay protection.

### Task 6: Production observability and installer verification
- Add a production readiness/health service and CLI command.
- Replace the monolith-era master verifier with a split-aware CRM Core verifier.
- Update manifests/docs/agent prompt/CODEE metadata and regenerate exact file hashes.
- Verify the final ZIP from a clean extraction.

## Completion Status

All six tasks implemented for alpha.25. Final release verification is performed by `bin/verify.php` and `crm:production-check`.
