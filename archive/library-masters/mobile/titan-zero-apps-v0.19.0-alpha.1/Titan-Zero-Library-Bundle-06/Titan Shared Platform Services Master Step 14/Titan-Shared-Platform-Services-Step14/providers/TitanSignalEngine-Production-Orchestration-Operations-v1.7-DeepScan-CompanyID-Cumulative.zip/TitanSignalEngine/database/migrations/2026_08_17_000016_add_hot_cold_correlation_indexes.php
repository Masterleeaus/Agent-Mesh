<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_signal_archive_catalog')) return;
        Schema::table('titan_signal_archive_catalog', function (Blueprint $table): void {
            $table->index(['scope', 'tenant_key', 'causation_id', 'occurred_at'], 'tsac_cause_idx');
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('titan_signal_archive_catalog')) return;
        Schema::table('titan_signal_archive_catalog', function (Blueprint $table): void {
            $table->dropIndex('tsac_cause_idx');
        });
    }
};
