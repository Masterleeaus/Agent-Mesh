<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Identity;

use App\Extensions\TitanPeople\System\Contracts\PeopleIdentityPort;
use App\Extensions\TitanPeople\System\Contracts\WorkerIdentity;
use App\Extensions\TitanPeople\System\Models\Worker;
use RuntimeException;

final class DatabasePeopleIdentityPort implements PeopleIdentityPort
{
    public function resolveWorker(int $tenantCompanyId, string|int $subject): WorkerIdentity
    {
        if ($tenantCompanyId <= 0 || (string) $subject === '') {
            throw new RuntimeException('Tenant and subject are required for worker resolution.');
        }

        $rows = Worker::query()
            ->where('tenant_company_id', $tenantCompanyId)
            ->where('external_subject', (string) $subject)
            ->limit(2)
            ->get(['id', 'tenant_company_id', 'external_subject', 'public_id']);

        if ($rows->count() !== 1) {
            throw new RuntimeException('Worker identity resolution failed closed.');
        }

        /** @var Worker $worker */
        $worker = $rows->first();

        return new WorkerIdentity(
            workerId: (int) $worker->getKey(),
            tenantCompanyId: (int) $worker->getAttribute('tenant_company_id'),
            subject: (string) $worker->getAttribute('external_subject'),
            publicId: (string) $worker->getAttribute('public_id'),
        );
    }
}
