<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Contracts;

use App\Extensions\TitanConnect\System\Models\ExternalMessage;
use App\Extensions\TitanConnect\System\Models\ExternalThread;

interface ChatbotMessagingBridge
{
    public function onInboundMessage(int $companyId, ExternalThread $thread, ExternalMessage $message): void;
    public function onHumanHandoffChanged(int $companyId, ExternalThread $thread, string $state, ?int $actorId = null): void;
}
