# Titan Field 1.0.0

Authoritative field-operations engine for service requests, work orders, scheduling, dispatch, recurring work, field forms, evidence and Titan Go execution.

This cumulative release continues the strangler-safe extraction from Titan CRM. Historical `crm_*` field-service tables and CRM-era field/home-service **Laravel named routes** are deliberately retained for upgrade compatibility; ownership of the field domain remains Titan Field.

## Pass 1 — baseline/P0 hardening

- Retained historical field data during rollback/uninstall.
- Restored all 10 canonical field/home-service vertical profiles.
- Added self-healing legacy CRM field menu registration and stale-route-cache recovery.
- Strengthened package verification and migration restartability.

## Pass 2 — Field-owned ports and domain boundaries

Titan Field domain services, controller and routes no longer import CRM implementation classes directly.

Field-owned contracts now cover:

- canonical tenant/actor context;
- audit recording;
- automation publication;
- host-enable gating;
- permission gating.

CRM compatibility is isolated under `System/Infrastructure/Compatibility/Crm`. Routes use Titan Field middleware wrappers while preserving the existing `dashboard.user.crm.field-services.*` names and existing CRM permission strings. Runtime settings now use the `titan-field.*` namespace, with compatibility defaults inherited from installed CRM settings.

## Pass 3 — Tenant & Reference Integrity

All mutation paths now share a central `FieldReferenceIntegrity` gate. Supplied public IDs must resolve inside the active `tenant_company_id`; contact/company, location/customer, asset/location/customer, work-order and appointment relationships are checked for internal consistency. Worker assignment/time recording requires an active tenant-scoped `crm_field_worker_profiles` record. Owner/manager user references are verified through the Field tenancy port, with the CRM membership resolver isolated inside the compatibility adapter. Dispatch entering `in_progress` now updates dispatch + work-order state transactionally instead of swallowing a failed work-order transition.

Titan CRM Core `>=1.3.0-alpha.24` remains an explicit compatibility dependency for tenant context, audit, legacy automation and host-enable bridging. Permission ownership is now Titan Field-native; historical CRM field permission names remain aliases rather than CRM-owned definitions.

See `DOMAIN_OWNERSHIP.md`, `docs/DEPENDENCY_INVENTORY.md`, `docs/MENU_COMPATIBILITY.md`, `docs/DONOR_PROVENANCE.md` and `AGENT_UPGRADE_PROMPT.md`.

## Pass 4 — Governed capabilities and transactional Signals

Release `1.0.0-alpha.5` introduces a governed capability catalogue with canonical `titan.field.*` IDs and preserved `crm.*` aliases. Every definition declares its input/output contract, risk, autonomy, evidence, offline, reversibility and idempotency policy.

Important lifecycle mutations now persist a Titan Signal-compatible envelope to `titan_field_signal_outbox` inside the same database transaction as the authoritative write. Envelopes always carry `tenant_company_id`, `trace_id`, `correlation_id`, `causation_id`, an idempotency key and a structured `titan.field.signal.receipt.v1` receipt. External Titan Signal delivery is intentionally decoupled from this pass; the retained outbox is the canonical publication boundary. Legacy CRM automation events remain compatibility-only until consumers migrate.


## Pass 5 — Governed command gateway + compatibility aliases

Release `1.0.0-alpha.6` introduces `FieldCommandGateway` with the `GovernedFieldCommandGateway` implementation. Browser mutations now enter this boundary before domain services execute. The gateway resolves canonical `titan.field.*` IDs and historical `crm.*` capability aliases through the governed capability registry, verifies the capability is enabled and mutation-capable, authorizes the Field-owned permission, requires idempotency when declared by the manifest, and routes only approved operations to existing authoritative Titan Field services.

Completed commands persist `titan.field.command.receipt.v1` in retained `titan_field_command_receipts` with tenant, actor, requested/canonical capability, operation, permission, source, trace/correlation/causation IDs, request hash and a bounded idempotency hash. Matching retries replay the completed receipt; reuse of the same idempotency key with a different payload fails closed. The command receipt and database mutation share the outer transaction. Evidence uploads also have outer-transaction compensation so a receipt failure cannot leave a newly stored file orphaned.

Field permission ownership is now explicit. `FieldPermissionCatalog` maps historical route permissions such as `crm.work_orders.manage` and `crm.dispatch.manage` to canonical Titan Field permissions. Host Gates are honored when defined; hardened hosts can enable strict fail-closed gate registration. The old CRM permission adapter remains injectable only for compatibility and is no longer the canonical Field route/command authorizer.

### Pass 6 scheduling policy
Titan Field supports advanced recurrence rules plus normalized worker availability and business/service/service-area/postcode/worker blackout windows. Existing agreements remain compatible through cadence/interval fallback and existing weekly worker JSON remains a fallback when normalized rules are absent.

### Pass 7 scheduling intelligence
Titan Field now keeps `SchedulingKernel` as the deterministic hard-constraint authority and adds a read-only `TechnicianRecommendationService` that ranks only eligible workers. Recommendations expose bounded scores and explicit components for required skills, remaining daily capacity, service-area fit, deterministic travel proximity and prior customer/location continuity. Assignments remain authoritative only through the governed command gateway.

### Pass 8 recommendation decision evidence
Technician recommendations now use policy `titan.field.recommendation.v3` with transparent workload, territory, route-fit and continuity facts. Each run records immutable decision evidence in `titan_field_recommendation_snapshots`; recommendations remain non-authoritative and cannot assign work.

## Pass 9 — SLA + Operational Exceptions
Titan Field v1.0.0-alpha.10 adds the governed operational exception queue, SLA deadlines, deduplicated detection, lifecycle history, Signals, menu/UI and command-gateway mutations.


## Pass 10 — Routes, Route Stops & Live Worker Position
Titan Field now owns day routes and ordered stops. Live worker location is consent-bound, active-shift-only telemetry with bounded retention. Route ordering is operational sequencing only; optimization is explicitly not claimed.


## Pass 11 — Titan Maps peer bridge + Field Control
Titan Field consumes Titan Maps Intelligence through the optional `SpatialIntelligenceGateway`, preserving standalone fallback behavior. Field Control combines worker lanes, live positions, routes/ETA and operational exceptions while all schedule mutations still re-enter the governed command gateway and `SchedulingKernel`.



## Pass 13 — Capacity forecasting + predictive operations

Titan Field now exposes a read-only **Capacity Forecast** under Crew. It calculates daily worker/team availability from existing worker policy, time-off, blackouts and bookings, then compares remaining capacity with unscheduled work and unresolved demand. Skill and service-area pressure are explicit evidence, not automatic scheduling decisions. When Titan Maps Intelligence is active, Field adds nearest-worker travel-matrix, ETA freshness and territory pressure through the optional peer contract; Maps remains non-authoritative and any operational change must still pass the governed command gateway and `SchedulingKernel`.

## Pass 12 — Work-order health, profitability + spatial cost intelligence
Titan Field adds a read-only work-order health projection over existing authoritative work-order service lines, time entries, materials, appointments, worker profiles and operational exceptions. Missing cost rates remain unknown; forecast cost and projected margin are never fabricated. Maps contributes only distance/time/territory evidence. Explicit Field-owned labour/vehicle rates may convert those spatial facts into estimated travel cost; Maps advisory pricing hints are never auto-applied.

## Joint Pass 14 — Titan Go offline runtime

Titan Field now exposes a device-bound offline reconciliation API for Titan Go. Offline mutations replay through the same governed command gateway used online, with durable receipts and optimistic entity-version conflict handling. Maps Intelligence remains the preferred delayed-GPS authority when installed; Field retains a bounded privacy-preserving fallback. See `docs/PASS14_TITAN_GO_OFFLINE_RUNTIME.md`.


## Joint Pass 15 — governed route optimisation proposals + AI Workforce

Titan Maps Intelligence can now return explainable route-order optimisation **proposals** through the optional spatial peer contract. Titan Field records the proposal evidence, locks it to the current route baseline, and separates request, human accept/reject, and governed apply. Applying an accepted proposal re-enters the existing Field route writer and Signal/receipt path; stale, expired, or changed-baseline proposals fail closed. Maps never writes Field route state directly.

Titan Field also publishes `resources/workforce/workforce-manifest.json` using Workforce Manifest 2.0. It contributes three extension-owned roles (`field-dispatch-manager`, `field-operations-specialist`, `field-operations-action-worker`) with explicit tier/risk/autonomy boundaries. AI Workforce may read, analyse and recommend; mutating tools are Command-Bus/governance-bound and no role can self-activate or increase its own authority.

The supplied host DB snapshot is recorded in `docs/PASS15_HOST_DB_RECONCILIATION.md`: existing Crew/Maps menu rows are adopted rather than duplicated, and Pass-15 tables/migrations remain restartable for a host where Titan Field has not yet been registered.
