<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $ok, string $message) use (&$failures): void { if (! $ok) $failures[] = $message; };
$contents = static fn(string $relative): string => (string) @file_get_contents($root . '/' . $relative);
$json = static function (string $relative) use ($root, &$failures): array {
    try { return json_decode((string) file_get_contents($root . '/' . $relative), true, 512, JSON_THROW_ON_ERROR) ?: []; }
    catch (Throwable) { $failures[] = 'invalid JSON: ' . $relative; return []; }
};

$extension = $json('extension.json');
$sidecar = $json('extension.manifest.json');
$workforce = $json('resources/workforce/workforce-manifest.json');

$assert(($extension['version'] ?? '') === '0.1.7', 'final extension version must be 0.1.2');
$assert(($sidecar['version'] ?? '') === '0.1.7', 'final sidecar version must be 0.1.2');
$assert(($workforce['extension']['version'] ?? '') === '0.1.7', 'final Workforce version must be 0.1.2');
$assert(isset($extension['integrity']['files']) && is_array($extension['integrity']['files']), 'Installer 1.7.8 requires extension.json integrity.files');
$assert(! isset($extension['publishes']), 'Installer 1.7.8 canonical root manifest must not carry non-schema publishes metadata');
$assert(! isset($extension['publish_tags']), 'legacy publish_tags key must be removed');
$assert(($extension['schema'] ?? '') === 'titan-extension-v1', 'installer schema drift');
$assert(($extension['folder'] ?? '') === 'TitanTimeAttendance', 'folder identity drift');
$assert(($extension['provider'] ?? '') === 'App\\Extensions\\TitanTimeAttendance\\System\\TitanTimeAttendanceServiceProvider', 'provider identity drift');

foreach ([
    'System/Governance/SignalDeliveryPolicy.php',
    'database/migrations/2026_08_15_000008_harden_ext_titan_time_signal_delivery.php',
    'bin/verify-release.php',
    'docs/releases/PASS5-FINAL-RELEASE-REPORT.md',
    'docs/installer/UPGRADE-ROLLBACK-UNINSTALL.md',
] as $relative) $assert(is_file($root.'/'.$relative), 'missing Pass-5 release file: '.$relative);

$dispatcher = $contents('System/Governance/TimeSignalOutboxDispatcher.php');
foreach (['lockForUpdate','claimed_at','lease_expires_at','dead_lettered_at','SignalDeliveryPolicy'] as $needle) {
    $assert(str_contains($dispatcher, $needle), 'signal dispatcher missing production delivery control: '.$needle);
}
$assert(! str_contains($dispatcher, '$exception->getMessage()'), 'signal dispatcher persists raw exception messages');

$command = $contents('System/Console/Commands/DeliverTimeSignalsCommand.php');
$assert(str_contains($command, "'delivering'"), 'signal command does not recover stale delivering rows');
$assert(str_contains($command, 'lease_expires_at'), 'signal command does not consider expired delivery leases');

foreach ([
    'database/migrations/2026_08_13_000001_create_ext_titan_time_core.php',
    'database/migrations/2026_08_13_000002_create_ext_titan_time_approvals.php',
    'database/migrations/2026_08_13_000003_create_ext_titan_time_verification.php',
    'database/migrations/2026_08_13_000004_create_ext_titan_time_offline_and_outbox.php',
] as $baseMigration) {
    $assert(str_contains($contents($baseMigration), 'Schema::hasTable'), 'base migration is not retained-data reinstall safe: '.$baseMigration);
}

$migration = $contents('database/migrations/2026_08_15_000008_harden_ext_titan_time_signal_delivery.php');
foreach (['claimed_at','lease_expires_at','dead_lettered_at','function down'] as $needle) {
    $assert(str_contains($migration, $needle), 'signal hardening migration missing '.$needle);
}

$preflight = $contents('System/Installer/TimeAttendancePreflight.php');
foreach (['integrity.files','0.1.7'] as $needle) {
    $assert(str_contains($preflight, $needle), 'preflight missing final installer check: '.$needle);
}

$health = $contents('System/Health/TimeAttendanceHealthCheck.php');
foreach (['signal_dead_letters','signal_stale_leases'] as $needle) {
    $assert(str_contains($health, $needle), 'health check missing production signal diagnostic: '.$needle);
}

$provider = $contents('System/TitanTimeAttendanceServiceProvider.php');
$assert(str_contains($provider, "onOneServer()"), 'scheduled jobs are not protected against multi-node duplicate scheduling');

if ($failures !== []) {
    fwrite(STDERR, "Pass 5 release contract: FAIL\n- ".implode("\n- ",$failures)."\n");
    exit(1);
}
echo "Pass 5 release contract: PASS\n";
