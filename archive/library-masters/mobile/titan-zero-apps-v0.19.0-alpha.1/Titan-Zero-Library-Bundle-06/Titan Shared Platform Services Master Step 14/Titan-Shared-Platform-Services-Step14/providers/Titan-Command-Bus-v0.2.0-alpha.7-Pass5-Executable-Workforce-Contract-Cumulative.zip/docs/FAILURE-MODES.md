# Failure Modes

Unknown capability, unavailable required Signal transport, unavailable Risk, explicit Risk denial, malformed Risk evidence, unavailable Governance, disabled/kill-switch state, oversized payload, conflicting idempotency reuse and in-flight duplicate claims fail closed. Adapter exceptions become failed receipts and never expose raw exception text to callers.

Risk-specific reason codes introduced in Pass 9:
- `RISK_UNAVAILABLE`
- `RISK_DENIED` (or the authoritative Titan Risk reason code)
- `RISK_DECISION_INVALID`


## Pass 10 — Assurance / Shield boundary
Mutation dispatch now requires an authoritative Assurance/Shield decision after Titan Risk and before Governance. The default bridge is fail-closed; no local assurance or Shield policy is inferred. Accepted evidence is durable and is passed into Governance, receipts, and outcome Signals.
