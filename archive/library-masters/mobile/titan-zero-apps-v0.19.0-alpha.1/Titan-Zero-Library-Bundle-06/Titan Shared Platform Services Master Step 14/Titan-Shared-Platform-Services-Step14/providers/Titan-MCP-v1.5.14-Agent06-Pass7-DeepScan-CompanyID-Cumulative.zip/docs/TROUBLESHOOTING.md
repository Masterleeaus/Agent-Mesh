# Troubleshooting

If the menu is missing, confirm the provider is registered and the two extension migrations ran; the boot synchronizer repairs missing/drifted menu rows. If the transport is unavailable, confirm `TITAN_MCP_ENABLED`, API authentication, CORS origins and route prefix. If writes are denied, inspect write/destructive gates, storage-encryption attestation, permissions, audit integrity and backup-tool readiness.
