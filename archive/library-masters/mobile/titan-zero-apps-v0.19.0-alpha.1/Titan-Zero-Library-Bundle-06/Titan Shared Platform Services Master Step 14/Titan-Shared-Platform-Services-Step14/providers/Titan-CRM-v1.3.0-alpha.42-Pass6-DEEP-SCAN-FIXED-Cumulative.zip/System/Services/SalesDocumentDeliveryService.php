<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Services;

use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Prepares durable outbound sales-document intents only.
 * Provider execution happens after commit through CrmCommunicationExecutionPort.
 */
final class SalesDocumentDeliveryService
{
    public function __construct(private readonly CrmNotificationOutboxService $outbox) {}

    /** @param array<string,mixed> $governance */
    public function sendEmail(int $userId,string $type,string $publicId,string $recipient,?string $idempotencyKey=null,array $governance=[]):array
    {
        if(!in_array($type,['proposals','estimates','invoices'],true)){
            throw ValidationException::withMessages(['type'=>['Only proposals, estimates and invoices can be emailed.']]);
        }
        if(!filter_var($recipient,FILTER_VALIDATE_EMAIL)){
            throw ValidationException::withMessages(['email'=>['Enter a valid email address.']]);
        }
        $idempotencyKey=$this->effectKey($idempotencyKey,'sales_document',$type,$publicId,$recipient);
        $intent=$this->outbox->enqueueGoverned(
            $userId,'email','crm_sales_document',$recipient,
            ['type'=>$type,'document_public_id'=>$publicId,'render_job_public_id'=>$governance['render_job_public_id']??null],
            'sales_document',$publicId,$idempotencyKey,$governance
        );
        return $this->queuedResult($intent);
    }

    /** @param array<string,mixed> $governance */
    public function sendReminderEmail(int $userId,string $publicId,string $recipient,?string $idempotencyKey=null,array $governance=[]):array
    {
        if(!filter_var($recipient,FILTER_VALIDATE_EMAIL)){
            throw ValidationException::withMessages(['email'=>['Enter a valid email address.']]);
        }
        $idempotencyKey=$this->effectKey($idempotencyKey,'invoice_reminder','invoices',$publicId,$recipient);
        $intent=$this->outbox->enqueueGoverned(
            $userId,'email','crm_invoice_reminder',$recipient,
            ['type'=>'invoices','document_public_id'=>$publicId,'render_job_public_id'=>$governance['render_job_public_id']??null],
            'sales_document',$publicId,$idempotencyKey,$governance
        );
        return $this->queuedResult($intent);
    }

    private function effectKey(?string $key,string $purpose,string $type,string $publicId,string $recipient):string
    {
        $key=trim((string)$key);
        if($key!=='')return substr($key,0,120);
        // Compatibility callers that bypass the governed capability surface still enqueue safely,
        // but only Command Bus/capability callers receive stable replay semantics.
        return substr('compat:'.$purpose.':'.$type.':'.$publicId.':'.hash('sha256',$recipient).':'.(string)Str::uuid(),0,120);
    }

    /** @param array<string,mixed> $intent @return array<string,mixed> */
    private function queuedResult(array $intent):array
    {
        return [
            'outbox_public_id'=>$intent['public_id']??null,
            'effect_status'=>(string)($intent['status']??'pending')==='delivered'?'delivered':'queued',
            'delivery_status'=>$intent['status']??'pending',
            'provider'=>$intent['provider']??null,
            'provider_message_id'=>$intent['provider_message_id']??null,
            'provider_status'=>$intent['provider_status']??null,
            'delivery_receipt_required'=>true,
        ];
    }
}
