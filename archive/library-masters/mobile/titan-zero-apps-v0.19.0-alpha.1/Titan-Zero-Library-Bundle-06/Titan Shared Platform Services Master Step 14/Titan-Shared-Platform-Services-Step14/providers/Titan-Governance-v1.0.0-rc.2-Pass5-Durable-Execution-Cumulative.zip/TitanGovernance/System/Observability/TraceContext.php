<?php

declare(strict_types=1);

namespace App\Extensions\TitanGovernance\System\Observability;

final readonly class TraceContext
{
    public function __construct(
        public string $tenantCompanyId,
        public string $traceId,
        public string $correlationId,
        public ?string $causationId,
        public string $rootCausationId,
        public string $extensionKey = 'titan-governance',
    ) {}
}
