<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Broadcast;

Broadcast::channel('titan-connect.company.{companyId}.conversation.{uuid}', function ($user, int $companyId, string $uuid): bool {
    $userCompanyId = $user->company_id ?? null;
    if (! is_numeric($userCompanyId) || (int) $userCompanyId !== $companyId) {
        return false;
    }

    return \App\Extensions\TitanConnect\System\Models\TeamChat\TeamConversation::query()
        ->where('company_id', $companyId)
        ->where('uuid', $uuid)
        ->whereHas('participants', static fn ($query) => $query
            ->where('company_id', $companyId)
            ->where('user_id', (int) $user->getAuthIdentifier())
            ->whereNull('left_at'))
        ->exists();
});
