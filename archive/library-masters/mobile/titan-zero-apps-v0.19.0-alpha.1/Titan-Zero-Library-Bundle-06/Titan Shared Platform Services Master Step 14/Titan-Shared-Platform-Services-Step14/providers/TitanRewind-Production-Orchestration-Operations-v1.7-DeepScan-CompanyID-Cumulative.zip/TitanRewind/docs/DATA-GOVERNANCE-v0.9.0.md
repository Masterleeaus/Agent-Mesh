# Titan Rewind v0.9.0 — Forensic Data Governance

## Purpose

Pass 7 hardens Rewind evidence across its full lifecycle: source acquisition, historical artifact preservation, evidence signing, custody, legal hold, retention and deletion proof. Rewind remains a forensic read model and never becomes an authoritative business writer.

## Source acquisition

Titan Rewind consumes the Blueprint v4.1 host-owned `App\Support\Extensions\RewindSourceRegistry` when the host registers it as a shared service. Producing engines register host-owned source adapters; Rewind wraps them through `RewindHostSourceAdapter` without importing the producing extension's internal classes.

Every host source must return normalized tenant-scoped records and a watermark. Rewind rejects records that escape the requested `tenant_company_id` or `trace_id`. Audit completeness requires source state `COMPLETE`, a fresh `observed_through` timestamp, and verified/authentic source metadata.

## Historical artifact preservation

Policy, model, knowledge and other historical resolvers can be registered through Rewind's resolver API or as host container tag `titan.rewind.artifact-resolvers`. Resolved artifacts are sanitized, canonically hashed and archived in `titan_rewind_historical_artifacts` using Laravel's encrypted array cast. A supplied resolver hash must match Rewind's canonical artifact hash or resolution fails.

Archived content can satisfy later replay even when the original resolver no longer serves that version. Missing artifacts remain explicitly `ARTIFACT_UNAVAILABLE`; Rewind never fabricates historical content.

## Signing-key lifecycle

Evidence signing uses a rotating RSA-SHA256 keyring. One key is active for signing while prior public keys remain available as `verify-only` keys so historical signatures continue to validate after rotation. Private key material is never stored in Rewind tables.

Key metadata retained by Rewind contains only key ID, algorithm, public-key fingerprint, lifecycle status and usage timestamps. Configure the keyring with `TITAN_REWIND_EVIDENCE_KEYS_JSON` and select the signing key using `TITAN_REWIND_EVIDENCE_ACTIVE_KEY_ID`.

## Legal holds

Legal holds may target a trace, case, evidence package or the tenant investigation scope. Holds cascade during purge evaluation: a case hold blocks its linked/primary traces; an evidence-package hold blocks the corresponding trace data; a trace/case hold blocks deletion of evidence linked to that trace. Expired holds no longer block retention, and explicit release requires a reason.

## Retention classes

Default classes are configurable:

- `ephemeral`: 30 days — replay/operational transient records.
- `operational`: 90 days — derived timelines, integrity results and resolved drift state.
- `forensic`: 365 days — rebuildable forensic projections such as snapshots/dependencies.
- `evidence`: 2555 days — evidence packages and archived historical artifacts.
- `preserve`: no automated purge — trace event ledger, custody, legal holds, signing-key metadata, Governance/recovery authority records and purge proof.

Core normalized trace events are preserved by default. Retention removes rebuildable/projection data first rather than destroying Rewind's canonical forensic history.

## Resumable purge

`titan-rewind:retention` processes bounded batches and checkpoints `cursor_table` + `cursor_id`. Each tenant/retention-class pair has one active-run key. The scheduled run uses Laravel `onOneServer()` and `withoutOverlapping()`.

For each batch, legal-hold checks, evidence custody updates, deletion, purge receipt creation and cursor advancement execute inside one database transaction. A deletion cannot commit without its corresponding receipt and checkpoint.

Evidence packages referenced by Titan Governance receipts are not automatically purged even when aged past their retention cutoff.

## Purge receipts

Every processed batch creates `titan_rewind_purge_receipts` with row range, deletion/hold counts, a canonical batch hash and a hash of deleted row IDs. Purge runs and receipts are themselves preservation-class records.

## Remaining certification work

v0.9.0 deliberately remains manifest schema v1. Pass 8 must still replace full-trace in-memory reads with bounded streaming/cursors, run performance/concurrency/chaos/DR/accessibility/localization/supply-chain checks, verify the exact MagicAI host and only then activate Blueprint v4.1 schema v2 `runtime_profile: titan-rewind`.
