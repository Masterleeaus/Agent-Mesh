<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Listeners;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use App\Extensions\Crm\System\Contracts\{ContactRepositoryContract, LeadRepositoryContract};
use App\Extensions\Crm\System\Services\{CrmAuditRecorder, CrmSettingsService};
use App\Extensions\Crm\System\Support\CrmNormalizer;
use App\Extensions\Crm\System\Automation\Events\CrmAutomationTriggered;
use Illuminate\Database\ConnectionInterface;

final class ContactCapturedListener
{
    public function __construct(
        private ConnectionInterface $db,
        private ContactRepositoryContract $contacts,
        private LeadRepositoryContract $leads,
        private CrmSettingsService $settings,
        private CrmAuditRecorder $audit,
    ) {}

    public function handle(object $event): void
    {
        $userId = (int) ($event->userId ?? 0);
        if ($userId <= 0 || ! (bool) $this->settings->get($userId, 'auto_capture_contacts', true)) return;
        $email = CrmNormalizer::email($event->email ?? null);
        $phone = CrmNormalizer::phone($event->phone ?? null);
        if ($email === null && $phone === null) return;
        $exists = $this->db->table(config('crm.tables.contacts'))->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at')
            ->where(function ($q) use ($email, $phone): void {
                if ($email !== null) $q->orWhere('normalized_email', $email);
                if ($phone !== null) $q->orWhere('normalized_phone', $phone);
            })->first();
        if (! $exists) {
            $parts = preg_split('/\s+/', trim((string) ($event->name ?? ''))) ?: [];
            $first = array_shift($parts) ?: 'Contact';
            $contact = $this->contacts->create($userId, ['first_name' => $first, 'last_name' => $parts === [] ? null : implode(' ', $parts), 'email' => $email, 'phone' => $phone, 'meta' => ['source' => (string) ($event->source ?? 'unknown')]]);
            $this->audit->record($userId, $userId, 'contact.captured', 'contact', (string) ($contact['public_id'] ?? ''), null, $contact, ['source' => (string) ($event->source ?? 'unknown')]);
            event(new CrmAutomationTriggered($userId,'contact.captured',['subject_type'=>'contact','subject_public_id'=>(string)($contact['public_id']??''),'source'=>(string)($event->source??'unknown'),'idempotency_key'=>'contact.captured:'.(string)($contact['public_id']??'')]));
        }
        if ((bool) $this->settings->get($userId, 'create_lead_on_capture', true)) {
            $leadExists = $this->db->table(config('crm.tables.leads'))->where('company_id', CrmCompanyScope::companyId($userId))->whereNull('deleted_at')->where(function ($q) use ($email, $phone): void {
                if ($email !== null) $q->orWhere('normalized_email', $email);
                if ($phone !== null) $q->orWhere('normalized_phone', $phone);
            })->exists();
            if (! $leadExists) $this->leads->create($userId, $userId, ['name' => (string) ($event->name ?? 'Captured contact'), 'email' => $email, 'phone' => $phone, 'source' => (string) ($event->source ?? 'unknown')]);
        }
    }

    public function __invoke(object $event): void { $this->handle($event); }
}
