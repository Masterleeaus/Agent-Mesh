# Authorization matrix

All consequential operations require authenticated, tenant-scoped authorization plus the applicable governance/approval decision.
