# Disaster Recovery

Back up extension-owned evidence tables and referenced evidence objects. Target RPO 60 minutes, RTO 240 minutes. Reconcile evidence hashes and workflow proposals after restore.
