<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Enums;

enum AutonomyLevel: int
{
    case Suggest = 0;
    case Assist = 1;
    case SemiAuto = 2;
    case Auto = 3;
    case TrustedAuto = 4;

    public function key(): string
    {
        return match ($this) {
            self::Suggest => 'suggest',
            self::Assist => 'assist',
            self::SemiAuto => 'semi_auto',
            self::Auto => 'auto',
            self::TrustedAuto => 'trusted_auto',
        };
    }

    public function next(): ?self
    {
        return match ($this) {
            self::Suggest => self::Assist,
            self::Assist => self::SemiAuto,
            self::SemiAuto => self::Auto,
            self::Auto => self::TrustedAuto,
            self::TrustedAuto => null,
        };
    }
}
