<?php
declare(strict_types=1);
namespace App\Extensions\TitanRewind\System\Services;
use App\Extensions\TitanRewind\System\Contracts\RewindEvidenceKeyringContract;
use App\Extensions\TitanRewind\System\Models\RewindSigningKey;
final class RewindSigningKeyService
{
 public function __construct(private RewindEvidenceKeyringContract $keyring){}
 public function synchronize(): array
 {
  $seen=[];foreach($this->keyring->keyMetadata() as $id=>$meta){$seen[]=$id;$row=RewindSigningKey::query()->firstOrNew(['key_id'=>$id]);$wasActive=$row->exists&&$row->status==='active';$active=(bool)($meta['active']??false);$row->fill(['algorithm'=>(string)($meta['algorithm']??'openssl-rsa-sha256'),'status'=>$active?'active':'verify-only','public_key_fingerprint'=>$meta['public_key_fingerprint']??null]);if($active&&!$row->activated_at)$row->activated_at=now();if(!$active&&$wasActive&&!$row->retired_at)$row->retired_at=now();$row->save();}
  return $seen;
 }
 public function recordUse(string $keyId): void { RewindSigningKey::query()->where('key_id',$keyId)->update(['last_used_at'=>now()]); }
}
