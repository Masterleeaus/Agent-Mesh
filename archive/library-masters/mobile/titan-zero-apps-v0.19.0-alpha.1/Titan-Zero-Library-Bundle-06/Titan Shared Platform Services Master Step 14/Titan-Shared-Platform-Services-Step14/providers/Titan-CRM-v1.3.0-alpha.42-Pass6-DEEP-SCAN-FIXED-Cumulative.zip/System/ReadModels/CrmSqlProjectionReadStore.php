<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\ReadModels;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use RuntimeException;

/** Portable SQL-backed CQRS read store. It never writes authoritative CRM domain tables. */
final class CrmSqlProjectionReadStore implements CrmReadStorePort
{
    public function __construct(private readonly ConnectionInterface $db,private readonly CrmReadProjectionRegistry $registry,private readonly CrmProjectionSearchIndexer $searchIndexer) {}

    public function query(int $companyId,string $projectionName,string $projectionVersion,array $filters=[],?string $resourcePublicId=null,int $limit=20): array
    {
        $this->requireTables();$limit=max(1,min(100,(int)$limit));
        $q=$this->db->table('crm_read_projection_records')->where('company_id',$companyId)->where('projection_name',$projectionName)->where('projection_version',$projectionVersion);
        if($resourcePublicId!==null&&trim($resourcePublicId)!=='')$q->where('resource_public_id',trim($resourcePublicId));
        $scanLimit=max($limit,min(2000,(int)config('crm.read_store.filter_scan_limit',500)));$rows=$q->orderByDesc('sort_at')->orderByDesc('id')->limit($scanLimit)->get();$records=[];
        foreach($rows as $row){$payload=$this->decode($row->payload??null);if(!$this->matches($payload,$filters))continue;$records[]=$payload;if(count($records)>=$limit)break;}return $records;
    }

    public function replaceProjection(int $companyId,array $definition,array $records,?string $projectedThroughSignalId=null,?string $sourceMaxUpdatedAt=null): array
    {
        $this->requireTables();$name=(string)$definition['projection_name'];$version=(string)$definition['projection_version'];$batchSize=max(50,min(2000,(int)config('crm.performance.projection_write_batch_size',500)));
        return $this->db->transaction(function()use($companyId,$definition,$records,$projectedThroughSignalId,$sourceMaxUpdatedAt,$name,$version,$batchSize):array{
            $this->db->table('crm_read_projection_records')->where('company_id',$companyId)->where('projection_name',$name)->where('projection_version',$version)->delete();
            $valid=[];foreach($records as $record){if(!is_array($record))continue;$resourceId=trim((string)($record['public_id']??''));if($resourceId==='')continue;$valid[]=$record;}
            $now=now();foreach(array_chunk($valid,$batchSize) as $chunk){$rows=[];foreach($chunk as $record){$resourceId=(string)$record['public_id'];$rows[]=['public_id'=>(string)Str::ulid()]+$this->recordPayload($companyId,$definition,$resourceId,$record)+['created_at'=>$now,'updated_at'=>$now];}if($rows!==[])$this->db->table('crm_read_projection_records')->insert($rows);}
            $this->searchIndexer->replaceProjection($companyId,$definition,$valid);
            $state=$this->statePayload($companyId,$definition,count($valid),$projectedThroughSignalId,$sourceMaxUpdatedAt,'ready',null);$this->upsertState($companyId,$definition,$state);return $state;
        },3);
    }

    public function upsertResource(int $companyId,array $definition,string $resourcePublicId,array $payload,?string $projectedThroughSignalId=null): array
    {$resourcePublicId=trim($resourcePublicId);if($resourcePublicId==='')throw new RuntimeException('Projection resource_public_id is required.');$payload['public_id']=$payload['public_id']??$resourcePublicId;return $this->upsertResources($companyId,$definition,[$payload],$projectedThroughSignalId);}

    public function upsertResources(int $companyId,array $definition,array $records,?string $projectedThroughSignalId=null): array
    {
        $this->requireTables();$name=(string)$definition['projection_name'];$version=(string)$definition['projection_version'];$batchSize=max(50,min(2000,(int)config('crm.performance.projection_write_batch_size',500)));$valid=[];$ids=[];$sourceMax=null;
        foreach($records as $record){if(!is_array($record))continue;$resourceId=trim((string)($record['public_id']??''));if($resourceId==='')continue;$record['public_id']=$resourceId;$valid[]=$record;$ids[]=$resourceId;$candidate=$record['updated_at']??$record['generated_at']??null;if($candidate!==null&&($sourceMax===null||(string)$candidate>$sourceMax))$sourceMax=(string)$candidate;}
        if($valid===[]){$state=$this->db->table('crm_read_projection_state')->where('company_id',$companyId)->where('projection_name',$name)->where('projection_version',$version)->first();return $state?(array)$state:$this->statePayload($companyId,$definition,0,$projectedThroughSignalId,$sourceMax,'ready',null);}
        return $this->db->transaction(function()use($companyId,$definition,$valid,$ids,$projectedThroughSignalId,$sourceMax,$name,$version,$batchSize):array{
            $stateRow=$this->db->table('crm_read_projection_state')->where('company_id',$companyId)->where('projection_name',$name)->where('projection_version',$version)->first();$existingIds=[];foreach(array_chunk(array_values(array_unique($ids)),500) as $idChunk){foreach($this->db->table('crm_read_projection_records')->where('company_id',$companyId)->where('projection_name',$name)->where('projection_version',$version)->whereIn('resource_public_id',$idChunk)->pluck('resource_public_id')->all() as $existing)$existingIds[(string)$existing]=true;}
            $now=now();foreach(array_chunk($valid,$batchSize) as $chunk){$rows=[];foreach($chunk as $record){$resourceId=(string)$record['public_id'];$rows[]=['public_id'=>(string)Str::ulid()]+$this->recordPayload($companyId,$definition,$resourceId,$record)+['created_at'=>$now,'updated_at'=>$now];}if($rows!==[])$this->db->table('crm_read_projection_records')->upsert($rows,['company_id','projection_name','projection_version','resource_public_id'],['entity_version','sort_at','source_updated_at','payload_hash','payload','updated_at']);}
            $this->searchIndexer->indexResources($companyId,$definition,$valid);
            $newCount=count(array_filter(array_unique($ids),fn(string $id)=>!isset($existingIds[$id])));$recordCount=$stateRow?((int)$stateRow->record_count+$newCount):(int)$this->db->table('crm_read_projection_records')->where('company_id',$companyId)->where('projection_name',$name)->where('projection_version',$version)->count();
            $state=$this->statePayload($companyId,$definition,$recordCount,$projectedThroughSignalId,$sourceMax,'ready',null);$this->upsertState($companyId,$definition,$state);return $state;
        },3);
    }

    public function deleteResource(int $companyId,string $projectionName,string $projectionVersion,string $resourcePublicId,?string $projectedThroughSignalId=null): void
    {
        $this->requireTables();$this->db->table('crm_read_projection_records')->where('company_id',$companyId)->where('projection_name',$projectionName)->where('projection_version',$projectionVersion)->where('resource_public_id',$resourcePublicId)->delete();$this->searchIndexer->deleteResource($companyId,$projectionName,$projectionVersion,$resourcePublicId);
        $row=$this->db->table('crm_read_projection_state')->where('company_id',$companyId)->where('projection_name',$projectionName)->where('projection_version',$projectionVersion)->first();if($row)$this->db->table('crm_read_projection_state')->where('id',$row->id)->update(['record_count'=>max(0,(int)$row->record_count-1),'projected_through_signal_id'=>$projectedThroughSignalId,'last_projected_at'=>now(),'lag_seconds'=>0,'updated_at'=>now()]);
    }

    public function status(int $companyId,?string $projectionName=null): array
    {
        $this->requireTables();$q=$this->db->table('crm_read_projection_state')->where('company_id',$companyId);if($projectionName!==null&&trim($projectionName)!=='')$q->where('projection_name',trim($projectionName));
        return $q->orderBy('projection_name')->orderByDesc('id')->get()->map(function($row):array{
            $a=(array)$row;$last=$a['last_projected_at']??$a['rebuilt_at']??null;$sla=(int)($a['freshness_sla_seconds']??$a['stale_after_seconds']??300);$lag=0;
            try{$current=$this->registry->resolve((string)$a['projection_name']);$a['is_obsolete_version']=(string)$a['projection_version']!==(string)$current['projection_version'];$a['definition_matches']=hash_equals((string)($a['definition_hash']??''),(string)$current['definition_hash']);$table=(string)($current['table']??'');if($table!==''&&$this->db->getSchemaBuilder()->hasTable($table)&&$this->db->getSchemaBuilder()->hasColumn($table,'updated_at')){$latest=$this->db->table($table)->where('company_id',$companyId)->max('updated_at');if($latest!==null){$lastTs=$last!==null?Carbon::parse((string)$last):null;$sourceTs=Carbon::parse((string)$latest);$lag=$lastTs===null?PHP_INT_MAX:($sourceTs->gt($lastTs)?$lastTs->diffInSeconds($sourceTs):0);}}}catch(\Throwable){$a['is_obsolete_version']=true;$a['definition_matches']=false;$lag=PHP_INT_MAX;}
            $a['is_stale']=($a['status']??'stale')!=='ready'||$lag>$sla||!$a['definition_matches']||$a['is_obsolete_version'];return $a;
        })->all();
    }

    public function markStale(int $companyId,string $projectionName,string $projectionVersion,?string $reason=null): void
    {if(!$this->tablesReady())return;$row=$this->db->table('crm_read_projection_state')->where('company_id',$companyId)->where('projection_name',$projectionName)->where('projection_version',$projectionVersion)->first();if($row)$this->db->table('crm_read_projection_state')->where('id',$row->id)->update(['status'=>'stale','stale_at'=>now(),'last_error'=>$reason,'updated_at'=>now()]);}

    private function recordPayload(int $companyId,array $definition,string $resourceId,array $payload): array{$encoded=json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);$sortField=(string)($definition['sort_field']??'updated_at');return ['company_id'=>$companyId,'projection_name'=>$definition['projection_name'],'projection_version'=>$definition['projection_version'],'resource_public_id'=>$resourceId,'entity_version'=>isset($payload['entity_version'])?(int)$payload['entity_version']:null,'sort_at'=>$payload[$sortField]??$payload['updated_at']??$payload['created_at']??now(),'source_updated_at'=>$payload['updated_at']??null,'payload_hash'=>hash('sha256',$encoded),'payload'=>$encoded];}
    private function statePayload(int $companyId,array $definition,int $count,?string $signalId,mixed $sourceMax,string $status,?string $error): array{return ['company_id'=>$companyId,'projection_name'=>$definition['projection_name'],'projection_version'=>$definition['projection_version'],'schema_version'=>(int)($definition['schema_version']??1),'definition_hash'=>(string)($definition['definition_hash']??''),'status'=>$status,'record_count'=>$count,'projected_through_signal_id'=>$signalId,'source_max_updated_at'=>$sourceMax,'last_projected_at'=>now(),'lag_seconds'=>0,'freshness_sla_seconds'=>max(30,(int)($definition['freshness_sla_seconds']??config('crm.read_store.stale_after_seconds',300))),'rebuilt_at'=>now(),'stale_at'=>null,'stale_after_seconds'=>max(30,(int)config('crm.read_store.stale_after_seconds',300)),'last_error'=>$error];}
    private function upsertState(int $companyId,array $definition,array $state): void{$q=$this->db->table('crm_read_projection_state')->where('company_id',$companyId)->where('projection_name',$definition['projection_name'])->where('projection_version',$definition['projection_version']);$existing=$q->first();if($existing)$q->update($state+['updated_at'=>now()]);else $this->db->table('crm_read_projection_state')->insert(['public_id'=>(string)Str::ulid()]+$state+['created_at'=>now(),'updated_at'=>now()]);}
    private function matches(array $payload,array $filters): bool{foreach($filters as $field=>$expected){if(!is_string($field)||!is_scalar($expected))continue;if(!array_key_exists($field,$payload)||(string)$payload[$field]!== (string)$expected)return false;}return true;}
    private function decode(mixed $payload): array{if(is_array($payload))return $payload;if(!is_string($payload)||$payload==='')return [];return json_decode($payload,true)?:[];}
    private function requireTables(): void{if(!$this->tablesReady())throw new RuntimeException('CRM CQRS read-store tables are unavailable. Run CRM migrations.');}
    private function tablesReady(): bool{try{return $this->db->getSchemaBuilder()->hasTable('crm_read_projection_state')&&$this->db->getSchemaBuilder()->hasTable('crm_read_projection_records');}catch(\Throwable){return false;}}
}
