<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Console;
use App\Extensions\Crm\System\ReadModels\CrmSearchPort;
use Illuminate\Console\Command;
final class CrmSearchCommand extends Command
{
    protected $signature='crm:search {company_id} {query} {--projection=*} {--limit=25}';
    protected $description='Search normalized CRM read projections using the configured CRM search adapter.';
    public function handle(CrmSearchPort $search): int{$tenant=(int)$this->argument('company_id');if($tenant<1){$this->error('company_id must be positive.');return self::FAILURE;}$this->line(json_encode($search->search($tenant,(string)$this->argument('query'),(array)$this->option('projection'),(int)$this->option('limit')),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));return self::SUCCESS;}
}
