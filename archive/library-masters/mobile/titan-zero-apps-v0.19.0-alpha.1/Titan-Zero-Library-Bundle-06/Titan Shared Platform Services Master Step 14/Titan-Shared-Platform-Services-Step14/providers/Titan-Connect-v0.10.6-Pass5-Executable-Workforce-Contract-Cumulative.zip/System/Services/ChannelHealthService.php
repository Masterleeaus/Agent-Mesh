<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Services;

use App\Extensions\TitanConnect\System\Contracts\CredentialVault;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Providers\ProviderRegistry;

final class ChannelHealthService
{
    public function __construct(
        private readonly ProviderRegistry $providers,
        private readonly CredentialVault $vault,
    ) {
    }

    public function check(ChannelConnection $connection): array
    {
        $provider = $this->providers->get((string) $connection->provider);
        $credentials = $this->vault->credentials((int) $connection->company_id, $connection);
        $credentials['_connection_external_account_id'] = (string) ($connection->external_account_id ?? '');
        $health = $provider->health($credentials);
        $connection->forceFill(['last_health_checked_at' => now()])->save();

        return [
            'connection_uuid' => (string) $connection->uuid,
            'provider' => (string) $connection->provider,
            'status' => (string) $connection->status,
            'health' => $health,
        ];
    }
}
