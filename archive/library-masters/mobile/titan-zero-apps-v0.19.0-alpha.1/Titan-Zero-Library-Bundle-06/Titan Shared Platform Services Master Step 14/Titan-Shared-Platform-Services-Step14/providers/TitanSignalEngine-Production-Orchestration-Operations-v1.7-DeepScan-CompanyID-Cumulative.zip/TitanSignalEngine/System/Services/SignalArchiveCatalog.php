<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Services;

use App\Extensions\TitanSignalEngine\System\Contracts\SignalArchiveCatalogContract;
use App\Extensions\TitanSignalEngine\System\Data\SignalArchiveEntry;
use App\Extensions\TitanSignalEngine\System\Models\SignalArchiveBatch;
use App\Extensions\TitanSignalEngine\System\Models\SignalArchiveCatalogRow;
use App\Extensions\TitanSignalEngine\System\Models\SignalEvent;
use Illuminate\Support\Facades\DB;
use RuntimeException;

final class SignalArchiveCatalog implements SignalArchiveCatalogContract
{
    public function record(array $entries): void
    {
        if ($entries === []) return;
        $rows = [];
        $now = now();
        foreach ($entries as $entry) {
            if (! $entry instanceof SignalArchiveEntry) {
                throw new RuntimeException('Signal archive catalog accepts SignalArchiveEntry values only.');
            }
            $existing = SignalArchiveCatalogRow::query()->where('event_id', $entry->eventId)->first();
            if ($existing !== null) {
                if ((string) $existing->batch_id !== $entry->batchId
                    || (string) $existing->archive_locator !== $entry->archiveLocator
                    || (string) $existing->archive_checksum !== $entry->archiveChecksum
                    || (int) $existing->archive_sequence !== $entry->archiveSequence) {
                    throw new RuntimeException('Signal archive catalog event identity already points to a different archive location.');
                }
                continue;
            }
            $rows[] = [
                'event_id' => $entry->eventId,
                'batch_id' => $entry->batchId,
                'scope' => $entry->scope,
                'tenant_company_id' => $entry->tenantCompanyId,
                'tenant_key' => (int) ($entry->tenantCompanyId ?? 0),
                'event_type' => $entry->eventType,
                'trace_id' => $entry->traceId,
                'correlation_id' => $entry->correlationId,
                'causation_id' => $entry->causationId,
                'root_causation_id' => $entry->rootCausationId,
                'occurred_at' => $entry->occurredAt,
                'recorded_at' => $entry->recordedAt,
                'archive_driver' => $entry->archiveDriver,
                'archive_locator' => $entry->archiveLocator,
                'archive_checksum' => $entry->archiveChecksum,
                'archive_sequence' => $entry->archiveSequence,
                'privacy_projected' => $entry->privacyProjected,
                'original_checksum' => $entry->originalChecksum,
                'created_at' => $now,
                'updated_at' => $now,
            ];
        }
        if ($rows !== []) DB::table('titan_signal_archive_catalog')->insert($rows);
    }

    public function find(string $eventId, ?int $tenantCompanyId, string $scope): ?SignalArchiveEntry
    {
        $row = $this->coldOnly(SignalArchiveCatalogRow::query()->inScope($scope, $tenantCompanyId))->where('event_id', $eventId)->first();
        return $row === null ? null : $this->entry($row);
    }

    public function byTrace(string $traceId, ?int $tenantCompanyId, string $scope, int $limit): array
    {
        return $this->list('trace_id', $traceId, $tenantCompanyId, $scope, $limit);
    }

    public function byCorrelation(string $correlationId, ?int $tenantCompanyId, string $scope, int $limit): array
    {
        return $this->list('correlation_id', $correlationId, $tenantCompanyId, $scope, $limit);
    }

    public function byCausation(string $causationId, ?int $tenantCompanyId, string $scope, int $limit): array
    {
        return $this->list('causation_id', $causationId, $tenantCompanyId, $scope, $limit);
    }

    public function countByTrace(string $traceId, ?int $tenantCompanyId, string $scope): int
    {
        return $this->coldOnly(SignalArchiveCatalogRow::query()->inScope($scope, $tenantCompanyId))->where('trace_id', $traceId)->count();
    }

    public function countByCorrelation(string $correlationId, ?int $tenantCompanyId, string $scope): int
    {
        return $this->coldOnly(SignalArchiveCatalogRow::query()->inScope($scope, $tenantCompanyId))->where('correlation_id', $correlationId)->count();
    }

    public function byRootCausation(string $rootCausationId, ?int $tenantCompanyId, string $scope, int $limit): array
    {
        return $this->list('root_causation_id', $rootCausationId, $tenantCompanyId, $scope, $limit);
    }

    public function batchMetadata(string $batchId, ?int $tenantCompanyId, string $scope): ?array
    {
        $query = SignalArchiveBatch::query()->where('batch_id', $batchId)->where('scope', $scope);
        $scope === 'tenant' ? $query->where('tenant_company_id', $tenantCompanyId) : $query->whereNull('tenant_company_id');
        $batch = $query->first();
        if ($batch === null) return null;
        return [
            'batch_id' => (string) $batch->batch_id,
            'status' => (string) $batch->status,
            'archive_driver' => (string) $batch->archive_driver,
            'archive_locator' => $batch->archive_locator === null ? null : (string) $batch->archive_locator,
            'archive_checksum' => $batch->archive_checksum === null ? null : (string) $batch->archive_checksum,
            'event_count' => (int) $batch->event_count,
            'criteria' => (array) ($batch->criteria ?? []),
            'archived_at' => $batch->archived_at?->toAtomString(),
            'verified_at' => $batch->verified_at?->toAtomString(),
        ];
    }

    /** @return list<SignalArchiveEntry> */
    private function list(string $column, string $value, ?int $tenantCompanyId, string $scope, int $limit): array
    {
        $limit = max(1, min($limit, (int) config('titan-signal-engine.archive_query_limit', 1000)));
        return $this->coldOnly(SignalArchiveCatalogRow::query()->inScope($scope, $tenantCompanyId))
            ->where($column, $value)
            ->orderBy('occurred_at')
            ->orderBy('event_id')
            ->limit($limit)
            ->cursor()
            ->map(fn (SignalArchiveCatalogRow $row): SignalArchiveEntry => $this->entry($row))
            ->all();
    }

    private function coldOnly($query)
    {
        return $query->whereNotIn('event_id', SignalEvent::query()->select('event_id'));
    }

    private function entry(SignalArchiveCatalogRow $row): SignalArchiveEntry
    {
        return new SignalArchiveEntry(
            eventId: (string) $row->event_id,
            batchId: (string) $row->batch_id,
            scope: (string) $row->scope,
            tenantCompanyId: $row->tenant_company_id === null ? null : (int) $row->tenant_company_id,
            eventType: (string) $row->event_type,
            traceId: (string) $row->trace_id,
            correlationId: (string) $row->correlation_id,
            causationId: $row->causation_id === null ? null : (string) $row->causation_id,
            rootCausationId: (string) $row->root_causation_id,
            occurredAt: $row->occurred_at->toAtomString(),
            recordedAt: $row->recorded_at->toAtomString(),
            archiveDriver: (string) $row->archive_driver,
            archiveLocator: (string) $row->archive_locator,
            archiveChecksum: (string) $row->archive_checksum,
            archiveSequence: (int) $row->archive_sequence,
            privacyProjected: (bool) $row->privacy_projected,
            originalChecksum: (string) $row->original_checksum,
        );
    }
}
