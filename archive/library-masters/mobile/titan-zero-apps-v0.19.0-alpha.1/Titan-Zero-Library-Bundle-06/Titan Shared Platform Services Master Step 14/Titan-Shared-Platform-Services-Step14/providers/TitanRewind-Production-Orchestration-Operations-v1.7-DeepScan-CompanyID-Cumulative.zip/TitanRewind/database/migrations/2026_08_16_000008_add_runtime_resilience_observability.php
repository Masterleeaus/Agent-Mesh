<?php

declare(strict_types=1);
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('titan_rewind_runtime_state')) Schema::create('titan_rewind_runtime_state', function(Blueprint $table): void {
            $table->id(); $table->string('scope_key',80)->unique(); $table->string('state',30)->default('ACTIVE')->index(); $table->text('reason')->nullable(); $table->unsignedBigInteger('updated_by_id')->nullable()->index(); $table->timestamps();
        });
        if (!Schema::hasTable('titan_rewind_dead_letters')) Schema::create('titan_rewind_dead_letters', function(Blueprint $table): void {
            $table->id(); $table->uuid('dead_letter_uuid')->unique(); $table->unsignedBigInteger('tenant_company_id')->nullable()->index(); $table->string('queue_name',120)->index(); $table->string('job_type',191)->index(); $table->uuid('operation_id')->nullable()->index(); $table->string('status',30)->default('attention')->index(); $table->string('classification',30)->index(); $table->unsignedInteger('attempts')->default(0); $table->json('payload')->nullable(); $table->string('error_class',191); $table->text('error_message'); $table->dateTime('failed_at',6)->index(); $table->dateTime('retried_at',6)->nullable(); $table->dateTime('resolved_at',6)->nullable(); $table->timestamps();
        });
        if (!Schema::hasTable('titan_rewind_circuit_breakers')) Schema::create('titan_rewind_circuit_breakers', function(Blueprint $table): void {
            $table->id(); $table->string('breaker_key',120)->unique(); $table->string('state',20)->default('CLOSED')->index(); $table->unsignedInteger('failure_count')->default(0); $table->text('last_error')->nullable(); $table->dateTime('opened_at',6)->nullable(); $table->dateTime('next_probe_at',6)->nullable()->index(); $table->dateTime('last_success_at',6)->nullable(); $table->timestamps();
        });
        if (!Schema::hasTable('titan_rewind_observability_events')) Schema::create('titan_rewind_observability_events', function(Blueprint $table): void {
            $table->id(); $table->unsignedBigInteger('tenant_company_id')->nullable()->index(); $table->uuid('trace_id')->nullable()->index(); $table->uuid('correlation_id')->nullable()->index(); $table->uuid('causation_id')->nullable()->index(); $table->string('kind',20)->index(); $table->string('name',160)->index(); $table->string('level',20)->default('INFO')->index(); $table->decimal('value',20,6)->nullable(); $table->string('unit',40)->nullable(); $table->string('status',40)->nullable()->index(); $table->decimal('duration_ms',20,3)->nullable(); $table->json('attributes')->nullable(); $table->dateTime('occurred_at',6)->index(); $table->index(['tenant_company_id','name','occurred_at'],'trw_obs_tenant_name_time');
        });
        if (!Schema::hasTable('titan_rewind_signal_outbox')) Schema::create('titan_rewind_signal_outbox', function(Blueprint $table): void {
            $table->id(); $table->uuid('outbox_uuid')->unique(); $table->uuid('event_id')->unique(); $table->unsignedBigInteger('tenant_company_id')->index(); $table->uuid('trace_id')->index(); $table->uuid('correlation_id')->index(); $table->uuid('causation_id')->nullable()->index(); $table->string('event_type',160)->index(); $table->string('severity',20)->default('INFO')->index(); $table->json('payload'); $table->string('status',30)->default('pending')->index(); $table->unsignedInteger('attempts')->default(0); $table->dateTime('available_at',6)->nullable()->index(); $table->dateTime('published_at',6)->nullable(); $table->text('last_error')->nullable(); $table->timestamps(); $table->index(['status','available_at'],'trw_signal_delivery');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('titan_rewind_signal_outbox'); Schema::dropIfExists('titan_rewind_observability_events'); Schema::dropIfExists('titan_rewind_circuit_breakers'); Schema::dropIfExists('titan_rewind_dead_letters'); Schema::dropIfExists('titan_rewind_runtime_state');
    }
};
