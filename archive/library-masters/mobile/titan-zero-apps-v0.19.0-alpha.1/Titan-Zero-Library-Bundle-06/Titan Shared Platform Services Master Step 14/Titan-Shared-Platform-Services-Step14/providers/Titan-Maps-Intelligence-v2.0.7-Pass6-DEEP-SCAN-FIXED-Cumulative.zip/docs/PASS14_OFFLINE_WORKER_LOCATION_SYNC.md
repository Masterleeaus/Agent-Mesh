# Joint Pass 14 — Offline Worker Location Sync

Titan Maps Intelligence owns spatial replay when paired with Titan Field/Titan Go. Delayed GPS batches are authenticated to the current worker identity, device-bound, idempotent by `client_sample_id`, bounded in size/age and revalidated against the worker's current tracking consent and on-duty state.

## Fresh versus historical replay

A replayed sample can update live position only when it is within `maximumCaptureAgeSeconds` and newer than the worker's current latest sample. Those samples pass through the existing `WorkerTrackingService`, preserving normal accuracy/freshness/geofence rules.

Older but retention-valid samples are stored with `offline_sync=true` and `historical_only=true`; they do **not** update the current `MapLocation`, and do **not** create retroactive geofence arrival/departure events. This prevents a reconnecting phone from moving the live marker backwards in time.

Samples captured before the current `status_changed_at` consent/on-duty state are rejected fail-closed. Coordinate bounds, GPS accuracy, future skew and maximum offline age are validated inside the service as well as the HTTP controller, so Titan Field peer calls cannot bypass validation.

`retention_expires_at` is carried per sample and the normal pruning service honours it. No new spatial authority is introduced in Titan Field.
