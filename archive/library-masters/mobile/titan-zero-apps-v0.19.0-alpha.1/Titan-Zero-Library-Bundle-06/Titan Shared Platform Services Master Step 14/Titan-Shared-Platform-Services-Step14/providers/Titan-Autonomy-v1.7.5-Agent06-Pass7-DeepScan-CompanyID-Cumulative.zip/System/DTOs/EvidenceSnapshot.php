<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\DTOs;

final readonly class EvidenceSnapshot
{
    public function __construct(
        public int $currentSuccessStreak,
        public int $totalSuccesses = 0,
        public int $totalFailures = 0,
        public int $totalEdits = 0,
        public int $totalRejections = 0,
        public int $totalReversals = 0,
        public bool $sampleRequirementsSatisfied = true,
        public bool $failureRateWithinLimit = true,
        public bool $reversalRateWithinLimit = true,
        public bool $correctionRateWithinLimit = true,
        public bool $contextConfidenceSatisfied = true,
        public bool $dataSourcesAvailable = true,
        public bool $scopeValid = true,
        public bool $hasUnresolvedIncident = false,
        public bool $integrationHealthy = true,
        public bool $permissionsValid = true,
        public bool $safetySuspended = false,
        public bool $autonomyHold = false,
        public bool $assuranceAmber = false,
        public bool $assuranceRed = false,
    ) {}
}
