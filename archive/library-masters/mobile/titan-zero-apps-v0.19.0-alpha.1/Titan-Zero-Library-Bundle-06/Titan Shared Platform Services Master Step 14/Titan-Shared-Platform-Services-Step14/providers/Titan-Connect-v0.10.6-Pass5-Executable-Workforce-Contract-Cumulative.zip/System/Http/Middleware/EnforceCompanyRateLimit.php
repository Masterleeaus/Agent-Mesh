<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Http\Middleware;

use App\Extensions\TitanConnect\System\Contracts\CompanyContext;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use RuntimeException;
use Symfony\Component\HttpFoundation\Response;

final class EnforceCompanyRateLimit
{
    public function __construct(private readonly CompanyContext $context)
    {
    }

    public function handle(Request $request, Closure $next, string $bucket): Response
    {
        $definition = config('titan-connect.rate_limits.'.$bucket);
        if (! is_array($definition)) {
            throw new RuntimeException('Unknown Titan Connect rate-limit bucket: '.$bucket);
        }

        $maxAttempts = max(1, (int) ($definition['attempts'] ?? 1));
        $decaySeconds = max(1, (int) ($definition['decay_seconds'] ?? 60));
        $companyId = $this->context->companyId($request);
        $actorId = $this->context->actorId($request);
        $key = sprintf('titan-connect:%s:company:%d:actor:%d', $bucket, $companyId, $actorId);

        if (RateLimiter::tooManyAttempts($key, $maxAttempts)) {
            $retryAfter = max(1, RateLimiter::availableIn($key));
            return response()->json([
                'status' => 'error',
                'message' => 'Too many Titan Connect requests. Try again shortly.',
                'retry_after' => $retryAfter,
            ], 429)->withHeaders([
                'Retry-After' => (string) $retryAfter,
                'X-RateLimit-Limit' => (string) $maxAttempts,
                'X-RateLimit-Remaining' => '0',
            ]);
        }

        RateLimiter::hit($key, $decaySeconds);
        $response = $next($request);
        $response->headers->set('X-RateLimit-Limit', (string) $maxAttempts);
        $response->headers->set('X-RateLimit-Remaining', (string) max(0, RateLimiter::remaining($key, $maxAttempts)));

        return $response;
    }
}
