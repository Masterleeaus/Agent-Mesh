# Agent-06 Upgrade Pass 5 — Laravel Host Registration

Version: 1.5.14

This pass wires the executable Workforce runtime adapter into the extension's Laravel service provider.

- Provider contribution is tagged as `titan.workforce.providers`.
- Health observations persist through Laravel's configured cache store.
- Runtime health remains scoped by `company_id`.
- Workforce discovery receives a neutral provider contribution rather than employee identity.
- Event emission hooks publish standardized health and availability envelopes.
- Installation, registration and health never grant authority.
