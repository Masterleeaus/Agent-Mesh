# Titan Autonomy Engine v1.5.0

## Closed-loop autonomous execution

- Added tenant-scoped autonomous execution receipts and negative-feedback persistence.
- Successful Auto/Trusted Auto CommandBus dispatch now enters an observation state and does **not** increment the qualifying success streak immediately.
- Added deterministic CRM postcondition verification against the persisted `tenant_company_id` boundary.
- Added risk-aware observation windows: Low 15 minutes, Medium 60 minutes, High 240 minutes; Critical does not auto-mature positive evidence.
- Added scheduled reconciliation with `onOneServer()` and `withoutOverlapping()` protection.
- Added a tenant-explicit ModelCouncil Assurance bridge for background reconciliation; cron never impersonates an authenticated user.
- Positive `correct` evidence requires both a verified persisted postcondition and fresh GREEN Assurance.
- Postcondition mismatch creates `incorrect` learning and may regress autonomy with `wrong_autonomous_action`.
- Assurance RED creates an exception and may regress autonomy with `assurance_red`.
- Added negative-only execution feedback for material corrections, reversals, failures, rejections and exceptions.
- Client/user feedback cannot mint positive success evidence.
- Added idempotent receipt/feedback correlation and credential-shaped field sanitization.
- Added `last_success_at` / `last_failure_at` propagation through capability-state transitions.
- Added correlation and policy metadata to learning events for end-to-end audit reconstruction.

## Persistence

- Added `titan_autonomy_execution_receipts`.
- Added `titan_autonomy_execution_feedback`.
- Existing autonomy evidence, gate decisions, handshakes, regressions and learning remain capability/workflow scoped.
