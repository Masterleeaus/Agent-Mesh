<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

final readonly class RetentionPolicy
{
    public function __construct(
        public RetentionClass $class,
        public ?int $retentionDays,
        public bool $prunable,
        public bool $archiveRequired,
    ) {
    }

    public static function for(RetentionClass $class): self
    {
        return match ($class) {
            RetentionClass::CriticalAudit => new self($class, null, false, true),
            RetentionClass::Audit => new self($class, 2555, true, true),
            RetentionClass::Operational => new self($class, 730, true, true),
            RetentionClass::Telemetry => new self($class, 90, true, true),
            RetentionClass::Debug => new self($class, 30, true, false),
        };
    }
}
