<?php

declare(strict_types=1);

namespace App\Extensions\TitanPrime\System\Domain\ValueObjects;

use InvalidArgumentException;

final readonly class TraceContext
{
    public function __construct(
        public int $tenantCompanyId,
        public string $traceId,
        public string $correlationId,
        public ?string $causationId = null,
        public ?string $rootCausationId = null,
    ) {
        if ($tenantCompanyId < 1) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }

        foreach (['trace_id' => $traceId, 'correlation_id' => $correlationId] as $name => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException(sprintf('%s must not be empty.', $name));
            }
        }

        foreach (['causation_id' => $causationId, 'root_causation_id' => $rootCausationId] as $name => $value) {
            if ($value !== null && trim($value) === '') {
                throw new InvalidArgumentException(sprintf('%s must be null or non-empty.', $name));
            }
        }
    }

    public function resolvedRootCausationId(): string
    {
        return $this->rootCausationId ?? $this->causationId ?? $this->traceId;
    }

    /** @return array{company_id:int,tenant_company_id:int,trace_id:string,correlation_id:string,causation_id:?string,root_causation_id:string} */
    public function toArray(): array
    {
        return [
            'company_id' => $this->tenantCompanyId,
            'tenant_company_id' => $this->tenantCompanyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->resolvedRootCausationId(),
        ];
    }
}
