<?php

declare(strict_types=1);

namespace Tests\Feature;

use PHPUnit\Framework\TestCase;

final class ExtensionBootTest extends TestCase
{
    public function test_provider_wires_product_core_and_navigation(): void
    {
        $root=dirname(__DIR__,2); $provider=(string)file_get_contents($root.'/System/TitanRewindServiceProvider.php');
        foreach (['NavigationRegistrar::register($this->app);','RewindEventStore::class','RewindTimelineService::class','RewindSnapshotService::class','RewindDependencyService::class','RewindReplayService::class','RewindIntegrityService::class','RewindDriftService::class','RewindForensicsService::class','RewindSnapshotComparisonService::class','RewindEvidencePackageService::class','RewindComplianceExportService::class','RewindRecoveryPlanService::class','RewindGovernanceService::class','RewindEvidenceAssembler::class','RewindRecoveryPlanner::class'] as $needle) self::assertStringContainsString($needle,$provider);
        self::assertStringContainsString('dashboard/user/titan-rewind',$provider); self::assertStringContainsString('dashboard/admin/titan-rewind',$provider);
        self::assertStringNotContainsString('eloquent.created: *',$provider);
    }
}
