<?php
declare(strict_types=1);
namespace App\Extensions\InteractionEngine\System\Authority {
 final readonly class CapabilityPolicy { public function __construct(public string $capability, public bool $delegatedAuthorityAllowed=true){} }
 final readonly class DelegatedAuthorityDecision {
  public function __construct(public bool $allowed,public array $reasonCodes=[],public ?string $grantId=null,public ?string $autonomyLevel=null,public array $grantedScopes=[],public array $metadata=[]){}
  public static function allow(string $grantId,string $autonomyLevel,array $grantedScopes=[],array $metadata=[]):self{return new self(true,[],$grantId,$autonomyLevel,$grantedScopes,$metadata);}
  public static function deny(string ...$reasonCodes):self{return new self(false,$reasonCodes);}
 }
}
namespace App\Extensions\InteractionEngine\System\Contracts {
 interface DelegatedAuthorityVerifierInterface { public function verify(string $capability,array $payload,\App\Extensions\InteractionEngine\System\Authority\CapabilityPolicy $policy):\App\Extensions\InteractionEngine\System\Authority\DelegatedAuthorityDecision; }
}
namespace {
spl_autoload_register(function(string $class):void{$p='App\\Extensions\\TitanAutonomy\\';if(!str_starts_with($class,$p))return;$path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($p))).'.php';if(is_file($path))require_once $path;});
use App\Extensions\TitanAutonomy\System\Contracts\AutonomyQueryContract;
use App\Extensions\TitanAutonomy\System\Contracts\HostContextBridgeContract;
use App\Extensions\TitanAutonomy\System\Contracts\ControlPlaneAuditSinkContract;
use App\Extensions\TitanAutonomy\System\DTOs\CapabilityState;
use App\Extensions\TitanAutonomy\System\Enums\AutonomyLevel;
use App\Extensions\TitanAutonomy\System\Enums\RiskClass;
use App\Extensions\TitanAutonomy\System\Services\DelegatedAuthorityEnvelopeService;
use App\Extensions\TitanAutonomy\System\Services\GateReviewService;
use App\Extensions\TitanAutonomy\System\Infrastructure\InteractionDelegatedAuthorityVerifier;

$policy=['gate_minimums'=>['low'=>1,'medium'=>2,'high'=>3,'critical'=>3],'maximum_level_by_risk'=>['low'=>'trusted_auto','medium'=>'trusted_auto','high'=>'auto','critical'=>'semi_auto'],'system_wide_learning_permitted'=>false,'limits'=>[]];
$stateRow=['tenant_company_id'=>42,'capability'=>'crm.invoice.create','workflow_key'=>'completed_job_invoice','risk'=>'medium','current_level'=>'auto','required_success_streak'=>2,'current_success_streak'=>2,'highest_success_streak'=>2,'total_successes'=>8,'total_failures'=>0,'total_edits'=>0,'total_rejections'=>0,'total_reversals'=>0,'platform_gate_eligible'=>false,'scope'=>['max_total'=>1500,'requires_no_dispute'=>true]];
$query=new class($stateRow,$policy) implements AutonomyQueryContract {
 public function __construct(public array $state,public array $policy,public array $handshake=[]){ }
 public function capabilityStates(int $t):array{return[$this->state];}
 public function capabilityState(int $t,string $c,string $w):?array{return $t===42&&$c===$this->state['capability']&&$w===$this->state['workflow_key']?$this->state:null;}
 public function learningEvents(int $t,?string $c=null,?string $w=null,int $l=1000):array{return[];}
 public function learningPreferences(int $t,?int $u=null):array{return[];}
 public function learningSettings(int $t):array{return[];}
 public function tenantPolicy(int $t):?array{return null;}
 public function platformPolicy():?array{return $this->policy;}
 public function handshakes(int $t,?string $c=null,?string $w=null,int $l=100):array{return $this->handshake?[$this->handshake]:[];}
 public function regressions(int $t,?string $c=null,?string $w=null,int $l=100):array{return[];}
};
$host=new class implements HostContextBridgeContract {public function tenantCompanyId():int{return 42;}public function userId():int{return 7;}public function can(string $p):bool{return true;}public function isSuperAdmin():bool{return false;}};
$audit=new class implements ControlPlaneAuditSinkContract {public array $events=[];public function record(array $event):string{$this->events[]=$event;return 'audit-1';}};
$tokens=new DelegatedAuthorityEnvelopeService('base64:unit-test-application-key-1234567890','titan-autonomy-1.5.0-test',90,audit:$audit);
$state=new CapabilityState(42,'crm.invoice.create','completed_job_invoice',RiskClass::Medium,AutonomyLevel::Auto,2,2,2,8,0,0,0,0,false,['max_total'=>1500,'requires_no_dispute'=>true]);
$effective=(new GateReviewService($query))->effectivePolicyForTenant(42);
$grant=$tokens->issue($state,$effective,7,'session-1','interaction-1','corr-1',['crm.invoices.manage']);
if(($audit->events[0]['event_type']??null)!=='autonomy.delegation_issued')throw new RuntimeException('delegation issuance must be written to canonical control audit');
if(array_key_exists('scope',$audit->events[0]['payload']??[]))throw new RuntimeException('delegation audit must not duplicate raw autonomy scope');
if(($tokens->verify($grant)['capability']??null)!=='crm.invoice.create')throw new RuntimeException('signed delegation envelope must verify');
$tampered=$grant;$tampered['capability']='crm.quote.create';if($tokens->verify($tampered)!==null)throw new RuntimeException('tampered delegation envelope must fail signature');
$verifier=new InteractionDelegatedAuthorityVerifier($tokens,$query,new GateReviewService($query),$host);
$payload=['_delegated_authority'=>$grant,'_context'=>['company_id'=>'42','tenant_id'=>'42','session_id'=>'session-1','interaction_id'=>'interaction-1','correlation_id'=>'corr-1','autonomy_workflow_key'=>'completed_job_invoice']];
$decision=$verifier->verify('crm.invoice.create',$payload,new \App\Extensions\InteractionEngine\System\Authority\CapabilityPolicy('crm.invoice.create'));
if(!$decision->allowed)throw new RuntimeException('valid Auto state delegation must verify: '.implode(',',$decision->reasonCodes));
if($decision->grantId!==($grant['grant_id']??null))throw new RuntimeException('delegated grant id must round-trip');
$query->state['scope']=['max_total'=>2500,'requires_no_dispute'=>true];
if($verifier->verify('crm.invoice.create',$payload,new \App\Extensions\InteractionEngine\System\Authority\CapabilityPolicy('crm.invoice.create'))->allowed)throw new RuntimeException('scope change must invalidate active delegation');
$query->state=$stateRow;$query->state['current_level']='trusted_auto';
$trustedState=new CapabilityState(42,'crm.invoice.create','completed_job_invoice',RiskClass::Medium,AutonomyLevel::TrustedAuto,2,0,2,8,0,0,0,0,false,['max_total'=>1500,'requires_no_dispute'=>true]);
$trustedGrant=$tokens->issue($trustedState,$effective,7,'session-2','interaction-2','corr-2',['crm.invoices.manage']);
$trustedPayload=['_delegated_authority'=>$trustedGrant,'_context'=>['company_id'=>'42','tenant_id'=>'42','session_id'=>'session-2','interaction_id'=>'interaction-2','correlation_id'=>'corr-2','autonomy_workflow_key'=>'completed_job_invoice']];
if($verifier->verify('crm.invoice.create',$trustedPayload,new \App\Extensions\InteractionEngine\System\Authority\CapabilityPolicy('crm.invoice.create'))->allowed)throw new RuntimeException('Trusted Auto must require persisted approved three-way handshake');
$query->handshake=['requested_level'=>'trusted_auto','requested_scope'=>['max_total'=>1500,'requires_no_dispute'=>true],'platform_decision'=>'approved','user_decision'=>'approved','ai_decision'=>'approved','final_decision'=>'approved','policy_version'=>'titan-autonomy-1.5.0-test'];
if(!$verifier->verify('crm.invoice.create',$trustedPayload,new \App\Extensions\InteractionEngine\System\Authority\CapabilityPolicy('crm.invoice.create'))->allowed)throw new RuntimeException('approved three-way handshake must satisfy Trusted Auto delegation');
echo "OK: DelegatedAuthorityEnvelopeSmokeTest\n";
}
