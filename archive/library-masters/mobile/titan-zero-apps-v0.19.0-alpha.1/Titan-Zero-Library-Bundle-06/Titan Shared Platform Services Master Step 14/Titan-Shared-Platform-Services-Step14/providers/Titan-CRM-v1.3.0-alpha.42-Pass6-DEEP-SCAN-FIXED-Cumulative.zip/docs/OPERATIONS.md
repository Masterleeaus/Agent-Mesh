# Operations

Availability is reported separately from authority. Supported states: available, degraded, unavailable, missing_provider, blocked, policy_disabled.
