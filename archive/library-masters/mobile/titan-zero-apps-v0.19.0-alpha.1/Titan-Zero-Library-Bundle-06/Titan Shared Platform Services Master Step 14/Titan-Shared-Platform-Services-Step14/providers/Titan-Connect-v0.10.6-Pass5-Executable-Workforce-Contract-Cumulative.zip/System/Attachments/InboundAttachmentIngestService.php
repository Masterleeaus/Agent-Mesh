<?php

declare(strict_types=1);

namespace App\Extensions\TitanConnect\System\Attachments;

use App\Extensions\TitanConnect\System\Contracts\CredentialVault;
use App\Extensions\TitanConnect\System\Contracts\ProviderHttpClient;
use App\Extensions\TitanConnect\System\Contracts\RetentionPolicy;
use App\Extensions\TitanConnect\System\Models\ChannelConnection;
use App\Extensions\TitanConnect\System\Models\ExternalMessage;
use App\Extensions\TitanConnect\System\Models\MessageAttachment;
use App\Extensions\TitanConnect\System\Providers\ProviderRegistry;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;

final class InboundAttachmentIngestService
{
    public function __construct(
        private readonly ProviderRegistry $providers,
        private readonly CredentialVault $vault,
        private readonly ProviderHttpClient $http,
        private readonly AttachmentValidator $validator,
        private readonly RetentionPolicy $retention,
    ) {
    }

    /** @return array<int, MessageAttachment> */
    public function ingestForExternalMessage(ChannelConnection $connection, ExternalMessage $message, array $attachments): array
    {
        if ((int) $connection->company_id !== (int) $message->company_id) {
            throw new RuntimeException('Inbound attachment company scope mismatch.');
        }
        if ($attachments === []) {
            return [];
        }

        $provider = $this->providers->get((string) $connection->provider);
        $credentials = $this->vault->credentials((int) $connection->company_id, $connection);
        $saved = [];

        foreach ($this->normalizeAttachments($attachments) as $attachment) {
            $descriptor = $provider->resolveInboundMedia($attachment, $credentials);
            if ($descriptor === null) {
                throw new RuntimeException('Provider attachment could not be resolved to a secure download descriptor.');
            }

            $response = $this->http->request('GET', $descriptor->downloadUrl, $descriptor->requestOptions);
            if (! $response->isSuccessful()) {
                throw new RuntimeException(sprintf('Provider media download failed with HTTP %d.', $response->status));
            }

            $bytes = $response->body;
            $size = strlen($bytes);
            $max = (int) config('titan-connect.attachments.max_bytes', 25 * 1024 * 1024);
            if ($size > $max || ($descriptor->sizeBytes !== null && $descriptor->sizeBytes > $max)) {
                throw new RuntimeException('Provider attachment exceeds the configured size limit.');
            }

            $sha256 = hash('sha256', $bytes);
            if ($descriptor->sha256 !== null && $descriptor->sha256 !== '' && ! hash_equals(strtolower($descriptor->sha256), strtolower($sha256))) {
                throw new RuntimeException('Provider attachment checksum validation failed.');
            }

            $existing = MessageAttachment::query()
                ->where('company_id', $message->company_id)
                ->where('external_message_id', $message->id)
                ->where('sha256', $sha256)
                ->first();
            if ($existing) {
                $saved[] = $existing;
                continue;
            }

            $mime = $this->normalizedMime($descriptor->mimeType ?: $response->header('content-type'));
            $disk = (string) config('titan-connect.attachments.storage_disk', config('filesystems.default', 'local'));
            $extension = $this->extensionForMime($mime);
            $path = sprintf('titan-connect/company/%d/%s/%s.%s', (int) $message->company_id, now()->format('Y/m'), (string) Str::uuid(), $extension);
            if (! Storage::disk($disk)->put($path, $bytes)) {
                throw new RuntimeException('Provider attachment could not be written to configured storage.');
            }

            $days = $this->retention->daysForCompany((int) $message->company_id);
            try {
                $record = $this->validator->registerExternal((int) $message->company_id, $message, [
                    'storage_disk' => $disk,
                    'storage_path' => $path,
                    'original_name' => $descriptor->originalName ?: ('provider-media-'.$message->uuid.'.'.$extension),
                    'mime_type' => $mime,
                    'size_bytes' => $size,
                    'sha256' => $sha256,
                    'provider_media' => $descriptor->providerMedia,
                    'expires_at' => $days > 0 ? now()->addDays($days) : null,
                ]);
            } catch (\Throwable $e) {
                Storage::disk($disk)->delete($path);
                throw $e;
            }
            $saved[] = $record;
        }

        return $saved;
    }

    /** @return array<int,array<string,mixed>> */
    private function normalizeAttachments(array $attachments): array
    {
        $normalized = [];
        foreach ($attachments as $key => $value) {
            if (! is_array($value)) {
                continue;
            }
            if (is_string($key) && ! isset($value['type'])) {
                $value['type'] = $key;
            }
            $normalized[] = $value;
        }
        return $normalized;
    }

    private function normalizedMime(?string $mime): string
    {
        $mime = strtolower(trim((string) $mime));
        if (str_contains($mime, ';')) {
            $mime = trim(explode(';', $mime, 2)[0]);
        }
        return $mime !== '' ? $mime : 'application/octet-stream';
    }

    private function extensionForMime(string $mime): string
    {
        return match ($mime) {
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            'application/pdf' => 'pdf',
            'text/plain' => 'txt',
            'audio/mpeg' => 'mp3',
            'audio/mp4' => 'm4a',
            'audio/ogg' => 'ogg',
            'video/mp4' => 'mp4',
            default => 'bin',
        };
    }
}
