<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$allowedTenantFiles = [
    'System/Services/Legacy/LegacyTeamChatImporter.php',
    'database/migrations/2026_08_09_000003_migrate_tenant_boundary_to_company.php',
];
$scanRoots = ['System', 'routes', 'config', 'database/migrations', 'extension.json', 'upgrade.php'];
$failures = [];
$checks = 0;

$files = [];
foreach ($scanRoots as $entry) {
    $path = $root.'/'.$entry;
    if (is_file($path)) {
        $files[] = $path;
        continue;
    }
    if (!is_dir($path)) continue;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $file) {
        if ($file->isFile() && in_array($file->getExtension(), ['php', 'json'], true)) {
            $files[] = $file->getPathname();
        }
    }
}

foreach ($files as $file) {
    $rel = str_replace('\\', '/', substr($file, strlen($root) + 1));
    $text = file_get_contents($file) ?: '';
    $allowed = in_array($rel, $allowedTenantFiles, true);
    foreach ([
        '/\btenant_id\b/' => 'active tenant_id persistence/reference',
        '/\btenantId\b/' => 'active tenantId variable/API',
        '/\bTenantContext\b/' => 'TenantContext contract',
        '/\bTenantActorDirectory\b/' => 'TenantActorDirectory contract',
        '/AuthenticatedTenantContext/' => 'AuthenticatedTenantContext class',
        '/DatabaseTenantActorDirectory/' => 'DatabaseTenantActorDirectory class',
        '/titan-connect\.tenant\./' => 'tenant-named realtime channel',
    ] as $pattern => $label) {
        $checks++;
        if (!$allowed && preg_match($pattern, $text)) {
            $failures[] = "$rel: $label";
        }
    }
}

$checks++;
$contextFile = $root.'/System/Security/AuthenticatedCompanyContext.php';
if (!is_file($contextFile)) {
    $failures[] = 'Missing AuthenticatedCompanyContext.php';
} else {
    $text = file_get_contents($contextFile) ?: '';
    if (!str_contains($text, '$user->company_id') || str_contains($text, 'tenant_id') || str_contains($text, 'header(') || str_contains($text, 'input(')) {
        $failures[] = 'AuthenticatedCompanyContext must resolve only authenticated user company_id.';
    }
}

$checks++;
$directoryFile = $root.'/System/Security/DatabaseCompanyActorDirectory.php';
if (!is_file($directoryFile)) {
    $failures[] = 'Missing DatabaseCompanyActorDirectory.php';
} else {
    $text = file_get_contents($directoryFile) ?: '';
    if (!str_contains($text, "Schema::hasColumn('users', 'company_id')") || str_contains($text, "'tenant_id'")) {
        $failures[] = 'DatabaseCompanyActorDirectory must require users.company_id with no tenant fallback.';
    }
}

if ($failures !== []) {
    fwrite(STDERR, "Company boundary verification FAILED\n");
    foreach ($failures as $failure) fwrite(STDERR, " - $failure\n");
    fwrite(STDERR, "Checks: $checks; failures: ".count($failures)."\n");
    exit(1);
}

echo "Company boundary verification PASSED: $checks checks\n";
