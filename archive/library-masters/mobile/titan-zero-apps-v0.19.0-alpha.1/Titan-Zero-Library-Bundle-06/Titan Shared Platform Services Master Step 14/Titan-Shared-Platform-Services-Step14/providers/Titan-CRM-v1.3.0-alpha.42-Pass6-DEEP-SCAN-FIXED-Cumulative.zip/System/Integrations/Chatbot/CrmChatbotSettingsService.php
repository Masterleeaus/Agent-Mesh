<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Integrations\Chatbot;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;

final class CrmChatbotSettingsService
{
    public function __construct(private ConnectionInterface $db) {}

    public function forChatbot(int $userId, int $chatbotId): array
    {
        $row = $this->db->table('crm_chatbot_settings')->where('company_id', CrmCompanyScope::companyId($userId))->where('chatbot_id',$chatbotId)->first();
        $defaults = (array) config('crm.chatbot.defaults', []);
        if (! $row) return $defaults + ['company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'chatbot_id'=>$chatbotId];
        $data = (array) $row;
        foreach (['allowed_tools','metadata'] as $key) if (isset($data[$key]) && is_string($data[$key])) $data[$key] = json_decode($data[$key], true) ?: [];
        return array_replace($defaults, $data);
    }

    public function update(int $userId, int $chatbotId, array $settings): array
    {
        $allowed = ['enabled','capture_contacts','create_lead_on_capture','record_activity','allow_financial_reads','require_verified_financial_identity','default_pipeline_public_id','default_owner_user_id','allowed_tools','metadata'];
        $payload = array_intersect_key($settings, array_flip($allowed));
        foreach (['allowed_tools','metadata'] as $key) if (array_key_exists($key,$payload)) $payload[$key] = json_encode((array)$payload[$key]);
        $payload['updated_at'] = now();
        $exists = $this->db->table('crm_chatbot_settings')->where('company_id', CrmCompanyScope::companyId($userId))->where('chatbot_id',$chatbotId)->exists();
        if ($exists) $this->db->table('crm_chatbot_settings')->where('company_id', CrmCompanyScope::companyId($userId))->where('chatbot_id',$chatbotId)->update($payload);
        else $this->db->table('crm_chatbot_settings')->insert(['company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),'chatbot_id'=>$chatbotId,'created_at'=>now()] + $payload);
        return $this->forChatbot($userId,$chatbotId);
    }
}
