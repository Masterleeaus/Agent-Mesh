<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Import;
use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;
final class CrmImportRollbackJournal
{
    public function __construct(private ConnectionInterface $db){}
    public function recordCreated(int $userId,string $batchPublicId,string $resourceType,string $resourcePublicId):void
    {
        $tenant=CrmCompanyScope::companyId($userId);$table=$this->table($resourceType);$row=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$resourcePublicId)->first();if(!$row)throw new InvalidArgumentException('Imported CRM record could not be journaled.');$snapshot=(array)$row;$json=$this->encode($snapshot);
        $this->db->table('crm_import_rollback_journal')->updateOrInsert(['company_id'=>$tenant,'batch_public_id'=>$batchPublicId,'resource_public_id'=>$resourcePublicId],['public_id'=>(string)Str::ulid(),'user_id'=>CrmCompanyScope::actorUserId($userId),'resource_type'=>$resourceType,'operation'=>'created','before_hash'=>null,'before_snapshot'=>null,'after_hash'=>hash('sha256',$json),'after_snapshot'=>$json,'rollback_status'=>'pending','updated_at'=>now(),'created_at'=>now()]);
    }
    public function rollbackBatch(int $userId,string $batchPublicId):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$rows=$this->db->table('crm_import_rollback_journal')->where('company_id',$tenant)->where('batch_public_id',$batchPublicId)->where('rollback_status','pending')->orderBy('id')->get();
        if($rows->isEmpty()) throw new InvalidArgumentException('Import rollback evidence is unavailable for this legacy batch; automatic destructive rollback is blocked.');
        foreach($rows as $j){$table=$this->table((string)$j->resource_type);$current=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$j->resource_public_id)->first();if(!$current)continue;$currentArray=(array)$current;$compare=$currentArray;unset($compare['updated_at']);$after=json_decode((string)$j->after_snapshot,true)?:[];unset($after['updated_at']);if(hash('sha256',$this->encode($compare))!==hash('sha256',$this->encode($after)))throw new InvalidArgumentException('Import rollback blocked because an imported record changed after creation: '.$j->resource_public_id);}
        $rolled=0;$this->db->transaction(function()use($rows,$tenant,&$rolled):void{foreach($rows as $j){$table=$this->table((string)$j->resource_type);$q=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$j->resource_public_id);$current=$q->first();if($current){$updates=['updated_at'=>now()];if(array_key_exists('deleted_at',(array)$current))$updates['deleted_at']=now();else throw new InvalidArgumentException('CRM import rollback target does not support safe soft deletion.');$q->update($updates);$rolled++;}$this->db->table('crm_import_rollback_journal')->where('id',$j->id)->update(['rollback_status'=>'rolled_back','rolled_back_at'=>now(),'updated_at'=>now()]);}});
        return ['rolled_back_records'=>$rolled];
    }
    private function table(string $type):string{return match($type){'companies'=>'crm_companies','contacts'=>'crm_contacts','leads'=>'crm_leads','deals'=>'crm_deals',default=>throw new InvalidArgumentException('Unsupported import rollback resource type.')};}
    private function encode(array $value):string{ksort($value);return json_encode($value,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);}
}
