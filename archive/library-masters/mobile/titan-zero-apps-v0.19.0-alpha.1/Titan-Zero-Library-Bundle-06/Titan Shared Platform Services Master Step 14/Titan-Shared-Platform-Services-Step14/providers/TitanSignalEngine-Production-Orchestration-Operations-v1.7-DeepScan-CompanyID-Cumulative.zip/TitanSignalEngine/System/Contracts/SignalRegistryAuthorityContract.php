<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Contracts;

use App\Extensions\TitanSignalEngine\System\Data\SignalRegistryIdentity;

interface SignalRegistryAuthorityContract
{
    public function issue(string $serviceId): SignalRegistryIdentity;

    public function assertTrusted(SignalRegistryIdentity $identity): void;
}
