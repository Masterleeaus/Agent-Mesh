<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Support;

final class SecretFieldGuard
{
    public static function isSecretLike(string $key): bool
    {
        $normalized = trim($key);
        $normalized = preg_replace('/([a-z0-9])([A-Z])/', '$1_$2', $normalized) ?? $normalized;
        $normalized = strtolower($normalized);
        $normalized = preg_replace('/[^a-z0-9]+/', '_', $normalized) ?? $normalized;
        $normalized = trim($normalized, '_');
        if ($normalized === '') {
            return false;
        }
        if (preg_match('/(^|_)(password|passwd|secret|token|credential|credentials|authorization|auth_token)(_|$)/', $normalized) === 1) {
            return true;
        }
        foreach (['api_key','access_key','private_key','client_secret','refresh_token','secret_key'] as $needle) {
            if ($normalized === $needle || str_contains($normalized, '_'.$needle) || str_contains($normalized, $needle.'_')) {
                return true;
            }
        }
        return false;
    }

    /** @param array<string|int,mixed> $payload */
    public static function containsSecretLikeKey(array $payload): bool
    {
        foreach ($payload as $key => $value) {
            if (is_string($key) && self::isSecretLike($key)) {
                return true;
            }
            if (is_array($value) && self::containsSecretLikeKey($value)) {
                return true;
            }
        }
        return false;
    }
}
