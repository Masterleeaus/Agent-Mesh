<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\ReadModels;

interface CrmSearchPort
{
    /** @return array<string,mixed> */
    public function search(int $companyId,string $query,array $projectionNames=[],int $limit=25): array;
    /** @return array<string,mixed> */
    public function status(): array;
}
