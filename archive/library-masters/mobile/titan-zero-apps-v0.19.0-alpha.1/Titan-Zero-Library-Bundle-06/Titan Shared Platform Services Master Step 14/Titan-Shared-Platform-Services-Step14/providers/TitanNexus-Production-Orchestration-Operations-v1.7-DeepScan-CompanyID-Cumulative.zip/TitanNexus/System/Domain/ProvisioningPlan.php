<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Domain;

use App\Extensions\TitanNexus\System\Support\CanonicalJson;
use App\Extensions\TitanNexus\System\Support\StrictBoolean;
use InvalidArgumentException;

final class ProvisioningPlan
{
    /**
     * @param list<ProvisioningOperation> $operations
     * @param list<ProvisioningReceipt> $receipts
     */
    public function __construct(
        private readonly int $tenantCompanyId,
        private readonly string $compilationUuid,
        private readonly string $proposedOutputHash,
        private readonly ?string $sourceDiffFingerprint,
        private readonly array $operations,
        private readonly array $receipts = [],
        private readonly bool $executed = false,
    ) {
        if ($this->tenantCompanyId <= 0) {
            throw new InvalidArgumentException('tenant_company_id must be a positive integer.');
        }
        self::assertUuid($this->compilationUuid);
        self::assertHash($this->proposedOutputHash, 'proposed_output_hash');
        if ($this->sourceDiffFingerprint !== null) {
            self::assertHash($this->sourceDiffFingerprint, 'source_diff_fingerprint');
        }
        $operationMap = [];
        foreach ($this->operations as $operation) {
            if (!$operation instanceof ProvisioningOperation) {
                throw new InvalidArgumentException('operations must contain ProvisioningOperation objects.');
            }
            if ($operation->tenantCompanyId() !== $this->tenantCompanyId || strtolower($operation->compilationUuid()) !== strtolower($this->compilationUuid)
                || !hash_equals($operation->proposedOutputHash(), strtolower($this->proposedOutputHash))) {
                throw new InvalidArgumentException('Provisioning operation does not belong to this plan.');
            }
            if (isset($operationMap[$operation->operationId()])) {
                throw new InvalidArgumentException('Provisioning operation ids must be unique.');
            }
            $operationMap[$operation->operationId()] = $operation;
        }
        foreach ($this->operations as $operation) {
            foreach ($operation->dependsOnOperationIds() as $dependencyId) {
                if (!isset($operationMap[$dependencyId])) {
                    throw new InvalidArgumentException('Provisioning dependency must reference an operation in the same plan.');
                }
            }
        }
        $receiptMap = [];
        foreach ($this->receipts as $receipt) {
            if (!$receipt instanceof ProvisioningReceipt) {
                throw new InvalidArgumentException('receipts must contain ProvisioningReceipt objects.');
            }
            if (!isset($operationMap[$receipt->operationId()])) {
                throw new InvalidArgumentException('Provisioning receipt references an unknown operation.');
            }
            if (!hash_equals($operationMap[$receipt->operationId()]->idempotencyKey(), $receipt->idempotencyKey())) {
                throw new InvalidArgumentException('Provisioning receipt idempotency key does not match its operation.');
            }
            if (isset($receiptMap[$receipt->operationId()])) {
                throw new InvalidArgumentException('Provisioning receipts must be unique per operation.');
            }
            $receiptMap[$receipt->operationId()] = $receipt;
        }
        if ($this->executed && count($receiptMap) !== count($operationMap)) {
            throw new InvalidArgumentException('Executed provisioning plans require exactly one receipt per operation.');
        }
        if (!$this->executed && $receiptMap !== []) {
            throw new InvalidArgumentException('Unexecuted provisioning plans cannot contain receipts.');
        }
    }

    /** @param array<string, mixed> $data */
    public static function fromArray(array $data): self
    {
        $opsRaw = $data['operations'] ?? [];
        $receiptsRaw = $data['receipts'] ?? [];
        if (!is_array($opsRaw) || !array_is_list($opsRaw) || !is_array($receiptsRaw) || !array_is_list($receiptsRaw)) {
            throw new InvalidArgumentException('Provisioning plan operations/receipts must be lists.');
        }
        $operations = array_map(static function (mixed $item): ProvisioningOperation {
            if (!is_array($item)) { throw new InvalidArgumentException('Provisioning operation must be an object-like array.'); }
            return ProvisioningOperation::fromArray($item);
        }, $opsRaw);
        $receipts = array_map(static function (mixed $item): ProvisioningReceipt {
            if (!is_array($item)) { throw new InvalidArgumentException('Provisioning receipt must be an object-like array.'); }
            return ProvisioningReceipt::fromArray($item);
        }, $receiptsRaw);
        $diff = $data['source_diff_fingerprint'] ?? null;
        if ($diff !== null && !is_string($diff)) { throw new InvalidArgumentException('source_diff_fingerprint must be null or string.'); }
        $instance = new self(
            self::positiveInt($data['tenant_company_id'] ?? null),
            self::requiredString($data['compilation_uuid'] ?? null, 'compilation_uuid'),
            self::requiredString($data['proposed_output_hash'] ?? null, 'proposed_output_hash'),
            $diff === null ? null : trim($diff),
            $operations,
            $receipts,
            StrictBoolean::parse($data['executed'] ?? false, 'executed'),
        );
        if (isset($data['fingerprint']) && (!is_string($data['fingerprint']) || !hash_equals(strtolower($data['fingerprint']), $instance->fingerprint()))) {
            throw new InvalidArgumentException('Provisioning plan fingerprint mismatch.');
        }
        if (isset($data['status']) && $data['status'] !== $instance->status()->value) {
            throw new InvalidArgumentException('Provisioning plan status does not match canonical plan state.');
        }
        return $instance;
    }

    public function tenantCompanyId(): int { return $this->tenantCompanyId; }
    public function compilationUuid(): string { return $this->compilationUuid; }
    public function proposedOutputHash(): string { return strtolower($this->proposedOutputHash); }
    public function sourceDiffFingerprint(): ?string { return $this->sourceDiffFingerprint === null ? null : strtolower($this->sourceDiffFingerprint); }
    /** @return list<ProvisioningOperation> */
    public function operations(): array { return array_values($this->operations); }
    /** @return list<ProvisioningReceipt> */
    public function receipts(): array { return array_values($this->receipts); }
    public function executed(): bool { return $this->executed; }

    public function status(): ProvisioningPlanStatus
    {
        if (!$this->executed) {
            foreach ($this->operations as $operation) {
                if ($operation->disposition() === SemanticChangeDisposition::Blocked) { return ProvisioningPlanStatus::Blocked; }
            }
            foreach ($this->operations as $operation) {
                if ($operation->disposition() === SemanticChangeDisposition::RequiresApproval) { return ProvisioningPlanStatus::RequiresApproval; }
            }
            return ProvisioningPlanStatus::Ready;
        }
        if ($this->operations === []) { return ProvisioningPlanStatus::Applied; }
        $successful = 0;
        foreach ($this->receipts as $receipt) {
            if ($receipt->successful()) { $successful++; }
        }
        if ($successful === count($this->operations)) { return ProvisioningPlanStatus::Applied; }
        if ($successful > 0) { return ProvisioningPlanStatus::PartiallyApplied; }
        return ProvisioningPlanStatus::Failed;
    }

    /** @param list<ProvisioningReceipt> $receipts */
    public function withReceipts(array $receipts): self
    {
        if ($this->executed) {
            throw new InvalidArgumentException('Provisioning plan has already been executed.');
        }
        return new self($this->tenantCompanyId, $this->compilationUuid, $this->proposedOutputHash, $this->sourceDiffFingerprint, $this->operations, $receipts, true);
    }

    public function fingerprint(): string
    {
        return hash('sha256', CanonicalJson::encode($this->withoutFingerprint()));
    }

    /** @return array<string,mixed> */
    public function toContractArray(): array
    {
        if ($this->executed) {
            throw new InvalidArgumentException('Canonical provisioning-plan export is only valid before execution; execution results are exported as mutation receipts.');
        }
        return [
            'tenant_company_id' => $this->tenantCompanyId,
            'compilation_uuid' => strtolower($this->compilationUuid),
            'status' => $this->status()->value,
            'plan_fingerprint' => $this->fingerprint(),
            'diff_fingerprint' => $this->sourceDiffFingerprint(),
            'operations' => array_map(static fn (ProvisioningOperation $operation): array => $operation->toContractArray(), $this->operations),
        ];
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return $this->withoutFingerprint() + ['fingerprint' => $this->fingerprint()];
    }

    /** @return array<string, mixed> */
    private function withoutFingerprint(): array
    {
        return [
            'tenant_company_id' => $this->tenantCompanyId,
            'compilation_uuid' => strtolower($this->compilationUuid),
            'proposed_output_hash' => strtolower($this->proposedOutputHash),
            'source_diff_fingerprint' => $this->sourceDiffFingerprint === null ? null : strtolower($this->sourceDiffFingerprint),
            'status' => $this->status()->value,
            'executed' => $this->executed,
            'operations' => array_map(static fn (ProvisioningOperation $operation): array => $operation->toArray(), $this->operations),
            'receipts' => array_map(static fn (ProvisioningReceipt $receipt): array => $receipt->toArray(), $this->receipts),
        ];
    }

    private static function assertUuid(string $value): void
    {
        if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) !== 1) {
            throw new InvalidArgumentException('compilation_uuid must be a UUID.');
        }
    }
    private static function assertHash(string $value, string $field): void
    {
        if (preg_match('/^[0-9a-f]{64}$/i', $value) !== 1) { throw new InvalidArgumentException("{$field} must be a SHA-256 hex digest."); }
    }
    private static function requiredString(mixed $value, string $field): string
    {
        if (!is_string($value) || trim($value) === '') { throw new InvalidArgumentException("{$field} is required."); }
        return trim($value);
    }
    private static function positiveInt(mixed $value): int
    {
        $resolved = is_int($value) ? $value : (is_string($value) && ctype_digit($value) ? (int) $value : 0);
        if ($resolved <= 0) { throw new InvalidArgumentException('tenant_company_id must be a positive integer.'); }
        return $resolved;
    }
}
