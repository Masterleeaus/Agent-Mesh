<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Contracts;
interface TagRepositoryContract { public function search(int $userId,array $filters=[]): array; public function create(int $userId,array $data): array; public function attach(int $userId,string $tagPublicId,string $subjectType,string $subjectPublicId): void; }
