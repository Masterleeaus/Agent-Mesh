<?php

declare(strict_types=1);

namespace App\Extensions\Crm\System\Privacy;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;

final class CrmPrivacyService
{
    public function __construct(private ConnectionInterface $db) {}

    public function request(
        int $userId,
        int $actorUserId,
        string $requestType,
        string $subjectType,
        ?string $subjectPublicId=null,
        ?string $subjectEmail=null,
        bool $dry_run=true
    ): array {
        if (! in_array($requestType, ['export','anonymize','delete'], true)) {
            throw new \InvalidArgumentException('Unsupported privacy request type.');
        }

        $plan = $this->plan($userId, $requestType, $subjectType, $subjectPublicId, $subjectEmail);
        $id = (string) Str::ulid();
        $this->db->table('crm_privacy_requests')->insert([
            'public_id'=>$id,
            'company_id' => CrmCompanyScope::companyId($userId), 'user_id' => CrmCompanyScope::actorUserId($userId),
            'request_type'=>$requestType,
            'subject_type'=>$subjectType,
            'subject_public_id'=>$subjectPublicId,
            'subject_email'=>$subjectEmail,
            'dry_run'=>$dry_run,
            'status'=>$dry_run?'planned':'pending',
            'plan'=>Crypt::encryptString(json_encode($plan, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)),
            'requested_by_user_id'=>$actorUserId,
            'requested_at'=>now(),
            'created_at'=>now(),
            'updated_at'=>now(),
        ]);

        if (! $dry_run) return $this->execute($userId, $id);

        $row = (array) $this->db->table('crm_privacy_requests')->where('public_id', $id)->first();
        return array_merge($this->sanitizeRow($row), [
            'plan_summary'=>['record_count'=>count($plan['records'] ?? []),'request_type'=>$requestType,'subject_type'=>$subjectType],
        ]);
    }

    public function plan(int $userId, string $requestType, string $subjectType, ?string $subjectPublicId, ?string $subjectEmail): array
    {
        $tables = [
            'contact'=>['crm_contacts','public_id'],
            'lead'=>['crm_leads','public_id'],
            'company'=>['crm_companies','public_id'],
        ];
        $entry = $tables[$subjectType] ?? null;
        if (! $entry) return ['request_type'=>$requestType,'records'=>[],'warning'=>'Unsupported subject type'];

        $q = $this->db->table($entry[0])->where('company_id', CrmCompanyScope::companyId($userId));
        if ($subjectPublicId) $q->where($entry[1], $subjectPublicId);
        elseif ($subjectEmail) $q->where('normalized_email', strtolower(trim($subjectEmail)));

        $records = $q->limit(100)->get()->map(fn($r)=>(array)$r)->all();
        return ['request_type'=>$requestType,'subject_type'=>$subjectType,'records'=>$records,'dry_run'=>true];
    }

    public function execute(int $userId, string $requestPublicId): array
    {
        return $this->db->transaction(function () use ($userId, $requestPublicId): array {
            $row = $this->db->table('crm_privacy_requests')->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$requestPublicId)->lockForUpdate()->first();
            if (! $row) throw new \RuntimeException('Privacy request not found.');
            if ($row->status === 'completed') return $this->sanitizeRow((array) $row);

            $planJson = Crypt::decryptString((string) $row->plan);
            $plan = json_decode($planJson, true) ?: [];
            $result = ['processed'=>0,'mode'=>$row->request_type];

            if ($row->request_type === 'export') {
                $result = ['processed'=>count($plan['records'] ?? []),'mode'=>'export','records'=>$plan['records'] ?? []];
            } elseif ($row->request_type === 'anonymize') {
                foreach ($plan['records'] ?? [] as $record) {
                    $table = match($row->subject_type){'contact'=>'crm_contacts','lead'=>'crm_leads','company'=>'crm_companies',default=>null};
                    if (! $table) continue;
                    $updates = ['email'=>null,'phone'=>null,'normalized_email'=>null,'normalized_phone'=>null,'updated_at'=>now()];
                    if ($row->subject_type === 'contact') $updates += ['first_name'=>'Anonymized','last_name'=>null];
                    elseif ($row->subject_type === 'lead') $updates += ['name'=>'Anonymized lead'];
                    else $updates += ['name'=>'Anonymized company','legal_name'=>null,'website'=>null];
                    $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$record['public_id'])->update($updates);
                    $result['processed']++;
                }
            } elseif ($row->request_type === 'delete') {
                foreach ($plan['records'] ?? [] as $record) {
                    $table = match($row->subject_type){'contact'=>'crm_contacts','lead'=>'crm_leads','company'=>'crm_companies',default=>null};
                    if ($table) {
                        $this->db->table($table)->where('company_id', CrmCompanyScope::companyId($userId))->where('public_id',$record['public_id'])
                            ->update(['deleted_at'=>now(),'updated_at'=>now()]);
                        $result['processed']++;
                    }
                }
            }

            $cipherResult = Crypt::encryptString(json_encode($result, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
            $this->db->table('crm_privacy_requests')->where('id',$row->id)->update([
                'status'=>'completed','result'=>$cipherResult,'completed_at'=>now(),'updated_at'=>now(),
            ]);

            return array_merge($this->sanitizeRow((array)$row), [
                'status'=>'completed',
                'result_summary'=>['processed'=>(int)($result['processed'] ?? 0),'mode'=>(string)($result['mode'] ?? '')],
            ]);
        });
    }

    public function list(int $userId): array
    {
        return $this->db->table('crm_privacy_requests')->where('company_id', CrmCompanyScope::companyId($userId))->orderByDesc('id')->limit(200)->get()
            ->map(fn($r)=>$this->sanitizeRow((array)$r))->all();
    }

    private function sanitizeRow(array $row): array
    {
        $row['has_plan'] = ! empty($row['plan']);
        $row['has_result'] = ! empty($row['result']);
        unset($row['plan'], $row['result']);
        return $row;
    }
}
