# Pass 13 — Capacity Forecasting + Predictive Operations

Titan Field owns the operational capacity forecast. The forecast is **read-only** and non-authoritative: it never creates, accepts, assigns, reschedules or dispatches work.

## Evidence model

Field derives capacity from existing authoritative records:

- active `crm_field_worker_profiles` and each worker's `max_daily_minutes`;
- normalized `titan_field_worker_availability_rules`, with legacy `weekly_availability` fallback;
- approved availability exceptions, time off, and business/worker blackout periods;
- booked `crm_appointments`;
- unscheduled/unassigned `crm_work_orders`;
- unresolved `crm_service_requests` that have not already become work orders;
- `crm_services.default_duration_minutes` and `required_skills`;
- `crm_service_locations` service-area/postcode/coordinate evidence.

The forecast produces daily worker/team capacity, horizon utilisation, unfilled demand, skill pressure, service-area pressure, and evidence-backed recommendations. Skill capacity is labelled an **upper bound** because a worker's remaining minutes are not reserved independently for every service type.

## Maps peer

When Titan Maps Intelligence is active, Field calls `capacityPressureEvidence()` through the optional `SpatialIntelligenceGateway`. Maps may contribute nearest-worker travel-matrix evidence, route/ETA freshness, existing territory coverage, and uncovered demand points.

Maps does not own Field capacity, scheduling, assignments, or financial state. Its travel adjustment is explicitly a nearest-worker one-way proxy, not a future route commitment. Field fallback uses retained recent worker positions plus deterministic straight-line travel estimates.

## Safety

Forecast responses declare `authoritative=false` and `mutation=none`. Any recommended operational change must still enter the governed Titan Field scheduling/dispatch command gateway and pass `SchedulingKernel` again.
