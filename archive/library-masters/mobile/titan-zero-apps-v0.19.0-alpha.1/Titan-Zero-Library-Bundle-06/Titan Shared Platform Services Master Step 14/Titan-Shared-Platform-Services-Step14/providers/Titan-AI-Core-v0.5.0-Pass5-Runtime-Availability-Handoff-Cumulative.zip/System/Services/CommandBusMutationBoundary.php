<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\Services;

use App\Extensions\TitanAICore\System\Contracts\CommandBusGatewayContract;
use App\Extensions\TitanAICore\System\DTO\CommandDispatchReceipt;
use App\Extensions\TitanAICore\System\DTO\CommandDispatchRequest;
use App\Extensions\TitanAICore\System\DTO\GovernancePreflightReport;

final readonly class CommandBusMutationBoundary
{
    public function __construct(
        private CommandBusGatewayContract $commandBus,
        private bool $executionEnabled = false,
    ) {}

    public function dispatch(CommandDispatchRequest $request, GovernancePreflightReport $preflight): CommandDispatchReceipt
    {
        if (!$this->executionEnabled) {
            return CommandDispatchReceipt::blocked($request->planId, $request->stepId, 'EXECUTION_DISABLED');
        }

        if (!$preflight->executable || $preflight->state !== 'ALLOW') {
            return CommandDispatchReceipt::blocked(
                $request->planId,
                $request->stepId,
                'GOVERNANCE_NOT_APPROVED',
                ['governance_state' => $preflight->state, 'reason_codes' => $preflight->reasonCodes()],
            );
        }

        return $this->commandBus->dispatch($request);
    }
}
