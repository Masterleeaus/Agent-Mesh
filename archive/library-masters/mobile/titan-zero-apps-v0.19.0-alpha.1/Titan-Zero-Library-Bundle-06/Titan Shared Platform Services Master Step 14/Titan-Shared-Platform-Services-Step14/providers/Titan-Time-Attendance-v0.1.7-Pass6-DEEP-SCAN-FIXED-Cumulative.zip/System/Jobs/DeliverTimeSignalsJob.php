<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Jobs;

use App\Extensions\TitanTimeAttendance\System\Governance\TimeSignalOutboxDispatcher;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

final class DeliverTimeSignalsJob implements ShouldQueue, ShouldBeUnique
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 5;
    public int $uniqueFor = 120;

    /** @var array<int,int> */
    public array $backoff = [30, 120, 300, 900];

    public function __construct(
        public readonly int $tenantCompanyId,
        public readonly int $limit = 200,
    ) {
        if ($tenantCompanyId <= 0) {
            throw new \InvalidArgumentException('A resolved tenant_company_id is required.');
        }

        $this->onQueue('titan-time-attendance');
    }

    public function uniqueId(): string
    {
        return 'titan-time-attendance:signals:' . $this->tenantCompanyId;
    }

    public function handle(TimeSignalOutboxDispatcher $dispatcher): void
    {
        $dispatcher->deliverTenant($this->tenantCompanyId, $this->limit);
    }
}
