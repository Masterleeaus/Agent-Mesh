<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Models;

use Illuminate\Database\Eloquent\Model;

final class RewindSnapshot extends Model
{
    protected $table = 'titan_rewind_snapshots';
    protected $fillable = [
        'snapshot_uuid','snapshot_key','tenant_company_id','trace_id','correlation_id','causation_id','type','status','payload','occurred_at',
        'reconstruction_version','source_hash','integrity_hash','metadata','entity_type','entity_id','snapshot_type','event_id',
        'state_hash','size_bytes','captured_at',
    ];
    protected $casts = [
        'tenant_company_id'=>'integer','payload'=>'array','metadata'=>'array','occurred_at'=>'datetime','captured_at'=>'datetime',
        'size_bytes'=>'integer','reconstruction_version'=>'integer',
    ];
}
