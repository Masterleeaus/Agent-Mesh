# Titan Nexus v1.0.0-rc.2

Titan Nexus is Titan Zero's deterministic **business configuration compiler, configuration-history authority, and governed provisioning orchestrator**. It turns a tenant Business Profile plus an exact versioned Vertical Definition into validated desired state, previews and semantic diffs, then plans/reconciles changes only through Risk, Governance, Assurance, optional Autonomy, Signal, Rewind and Command Bus public contracts.

**Architecture:** `configuration-orchestrator` + `configuration-compiler` + `rewind-source-contributor`  
**Manifest:** Titan Extension Manifest `2.2`  
**Runtime:** `1.0.0-rc.2`  
**Compiler semantics:** `0.5.0`  
**Host profile:** `titan.host.magicai.installer-1.7.6.v1`

## Release-candidate status

Pass 8 closes the package-side production hardening and host-certification gaps. RC2 Steps 1–2 additionally remediate the deep-audit findings and adversarially exercise fail-closed governance, secrets, idempotency, concurrency, tenant, contract, receipt, dependency and menu boundaries. The package is **host-ready, not yet live-host-certified**. Final `1.0.0` promotion requires the Installer/MagicAI host stages in `docs/HOST-CERTIFICATION.md` to run on the exact target host.

## Nexus Control Centre

Authenticated, tenant-scoped read surfaces:

- Overview
- Business Profile
- Compilations and selected compilation detail
- Semantic Validation
- Configuration Preview
- Configuration History / lineage
- Recompile / Semantic Diff
- Provisioning Plans
- Provisioning Receipts

Every read is tenant scoped. Historical secret-like keys are recursively redacted before presentation. The Interface Runtime v1.1 contribution remains read-only and exposes no alternate mutation authority.

## Host navigation

Pass 8 adds one **Titan Nexus** parent menu plus nine child destinations. `MenuContributionRegistry` is preferred. Where the modern registry is not installed, the isolated Step-10 compatibility adapter can self-heal through the MagicAI `menus` table and `App\Services\Common\MenuService::regenerate()` while preserving administrator order/enabled state on existing rows. Navigation failures never make provider boot fatal; live navigation certification records them separately.

## Governed provisioning

Consequential operations continue to follow:

```text
Desired configuration
  → deterministic provisioning plan
  → Risk
  → Governance
  → optional Autonomy
  → Assurance
  → Signal / Rewind pre-write evidence
  → Command Bus
  → owning engine capability
  → verified mutation receipt
  → Signal / Rewind outcome evidence
```

Nexus never writes another Titan engine's private tables. The only host-table compatibility fallback is the narrowly scoped navigation adapter required by the canonical Step-10 MagicAI host standard.

## Installer / host certification

- Installer 1.7.6-compatible flat-root package
- exact `integrity.files` map
- manifest v2.2
- Interface Contribution v1.1
- MySQL strict-mode migration scan
- MagicAI `panel.layout.app`
- modern + legacy navigation compatibility
- host authorization adapter for `isSuperAdmin`, `isAdmin`, `checkPermission`, `can`, `hasPermissionTo`
- machine-readable exact-host profile, report schema and report template
- standalone package verifier and exact-host report generator

The sealed ZIP receives a separate certification report after packaging so the report can truthfully contain the ZIP's final SHA-256 without circular hashing.

Step 5 adds `tools/fresh_install_preflight.php` and a machine-readable preflight report schema so Installer 1.7.6 package/install-tree readiness can be proven before touching the live host. This does not change the live certification boundary: `INSTALLER_CERTIFIED` remains `NOT_RUN` until the exact ZIP is actually installed on the target MagicAI/Titan host.

## Versioning

Runtime: `1.0.0-rc.2`  
Compiler: `0.5.0`

Compiler semantics remain unchanged. Step 2 hardens ingress/governance safety without changing deterministic compiler output semantics.

## Durable compilation lifecycle

Titan Nexus persists the current compilation aggregate in `titan_nexus_compilations` and records an append-only transition journal in `titan_nexus_compilation_events`. The journal records deterministic, tenant-scoped evidence for draft creation, validation, compilation, semantic diff/recompile planning, provisioning planning and receipt-bearing execution while preserving `trace_id`, `correlation_id`, `causation_id`, parent compilation lineage and entity version context. Exact repeated lifecycle evidence is idempotent through deterministic `event_id` values.

## Runtime dependency and capability readiness

Step 4 adds one shared readiness projection for database, Vertical Engine, Command Bus, Risk, Governance, Assurance, Signal, Rewind, Autonomy, Knowledge Authority and Interface Runtime. Package capabilities remain immutable release metadata; `NexusManager::health()` now publishes `available_capabilities`, `unavailable_capabilities`, per-capability dependency reasons and execution-mode readiness. Missing database/Vertical Engine is `UNAVAILABLE`; missing required governed-execution dependencies is `DEGRADED`; missing conditional Autonomy/Knowledge Authority or optional Interface Runtime remains explicitly visible without falsely downgrading otherwise healthy human execution. See `docs/RUNTIME-READINESS.md`.

### Existing-install upgrade preflight

For upgrade preparation, run `php tools/existing_install_upgrade_preflight.php --root=/path/to/TitanNexus --installed-facts=/path/to/installed-facts.json`. The tool verifies that installed migration state is an exact prefix of this package, identifies pending migrations, blocks known duplicate/downgrade hazards, and prints the required live upgrade acceptance sequence. A package-side PASS is not live `UPGRADE_CERTIFIED`.


### Provider boot & container wiring preflight

Pass 7 adds `tools/provider_boot_preflight.php`. It verifies provider lifecycle entrypoints, recursive constructor-contract bindings, views/migrations/config/routes/interface wiring, navigation failure isolation, optional dependency paths, and duplicate route-registration protection. Provider `boot()` is intentionally zero-argument so Installer/console boot does not depend on an unused HTTP Kernel binding. Package-side PASS does not set live `BOOT_CERTIFIED`.
