<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\Console;

use App\Extensions\TitanAutonomy\System\Contracts\ExecutionReconciliationContract;
use Illuminate\Console\Command;

final class ReconcileAutonomyExecutionsCommand extends Command
{
    protected $signature = 'titan:autonomy-reconcile {--limit=100 : Maximum pending execution receipts to reconcile}';
    protected $description = 'Reconcile matured Titan autonomous executions into governed learning and autonomy evidence.';

    public function handle(ExecutionReconciliationContract $reconciliation): int
    {
        $limit=max(1,min(500,(int)$this->option('limit')));
        $count=$reconciliation->finalizeDue($limit);
        $this->info("Reconciled {$count} Titan autonomy execution receipt(s).");
        return self::SUCCESS;
    }
}
