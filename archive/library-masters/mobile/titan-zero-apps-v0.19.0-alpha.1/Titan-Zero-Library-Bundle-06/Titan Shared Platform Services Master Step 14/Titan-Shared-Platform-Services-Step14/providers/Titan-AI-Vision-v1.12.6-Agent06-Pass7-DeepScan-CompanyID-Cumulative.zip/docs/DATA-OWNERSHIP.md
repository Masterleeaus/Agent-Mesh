# Data Ownership

Owned: evidence sets/items, image fingerprints, annotations, review status, workflow proposals. Not owned: customers, jobs, quotes, invoices, assets, payments or safety incidents.

## Comparison ownership
`titan_vision_comparisons` is owned by Titan AI Vision. It stores evidence-pair identity, comparability factors/scores and review requirements. It does not own job completion, asset condition truth, quote truth or compliance status.

## Historical evidence lineage

Titan AI Vision owns `titan_vision_evidence_lineage` and the continuity metadata on `titan_vision_evidence_sets`. Lineage references only Vision-owned evidence records. Tenant scoping is used when tenant context exists; otherwise continuity remains user-scoped.
