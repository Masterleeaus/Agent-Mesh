<?php

declare(strict_types=1);

namespace App\Extensions\TitanAutonomy\System\DTOs;

final readonly class ExecutionAuthorityDecision
{
    public function __construct(
        public bool $allowed,
        public array $reasonCodes = [],
    ) {}
}
