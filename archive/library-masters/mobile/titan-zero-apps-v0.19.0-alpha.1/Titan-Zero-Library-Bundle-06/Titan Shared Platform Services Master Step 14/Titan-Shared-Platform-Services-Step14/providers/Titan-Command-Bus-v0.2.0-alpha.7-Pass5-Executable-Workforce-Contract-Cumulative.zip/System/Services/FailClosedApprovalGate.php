<?php
declare(strict_types=1);
namespace App\Extensions\TitanCommandBus\System\Services;
use App\Extensions\TitanCommandBus\System\Contracts\CommandApprovalGateContract;
use App\Extensions\TitanCommandBus\System\DTO\{ApprovalDecision,AssuranceDecision,AutonomyDecision,CommandContext,CommandRequest,GovernanceDecision,RiskDecision};
final class FailClosedApprovalGate implements CommandApprovalGateContract {
    public function available(): bool { return false; }
    public function verify(CommandContext $context, CommandRequest $request, GovernanceDecision $governance, ?RiskDecision $risk = null, ?AssuranceDecision $assurance = null, ?AutonomyDecision $autonomy = null): ApprovalDecision { return ApprovalDecision::unavailable(); }
}
