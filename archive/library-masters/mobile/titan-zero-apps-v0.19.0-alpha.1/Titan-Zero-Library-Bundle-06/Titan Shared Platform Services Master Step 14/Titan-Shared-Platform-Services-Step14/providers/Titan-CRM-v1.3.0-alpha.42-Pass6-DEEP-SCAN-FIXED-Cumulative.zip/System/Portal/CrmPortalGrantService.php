<?php

declare(strict_types=1);
namespace App\Extensions\Crm\System\Portal;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\GoneHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

final class CrmPortalGrantService
{
    public function __construct(
        private ConnectionInterface $db,
        private CrmPortalScopeCatalog $scopes,
        private CrmPortalSessionService $sessions,
    ) {}

    public function issue(int $userId, array $attributes): array
    {
        $companyPublicId=isset($attributes['company_public_id']) && trim((string)$attributes['company_public_id'])!=='' ? trim((string)$attributes['company_public_id']) : null;
        $contactPublicId=isset($attributes['contact_public_id']) && trim((string)$attributes['contact_public_id'])!=='' ? trim((string)$attributes['contact_public_id']) : null;
        if ($companyPublicId===null && $contactPublicId===null) {
            throw new \InvalidArgumentException('A CRM portal grant requires a company or contact customer anchor.');
        }
        $companyId=CrmCompanyScope::companyId($userId);
        $this->assertCustomerAnchor($companyId,$companyPublicId,$contactPublicId);
        $scopes=$this->scopes->validate((array)($attributes['scopes']??['profile.view','sales.view']));
        $token=rtrim(strtr(base64_encode(random_bytes(32)),'+/','-_'),'=');
        $verificationCode=(string)random_int(100000,999999);
        $publicId=(string)Str::ulid();
        $maxDays=max(1,(int)config('crm.portal.max_expiry_days',30));
        $maxExpiry=now()->addDays($maxDays);
        $expires=isset($attributes['expires_at'])?Carbon::parse((string)$attributes['expires_at']):now()->addDays((int)config('crm.portal.default_expiry_days',30));
        if($expires->greaterThan($maxExpiry)) throw new \InvalidArgumentException("CRM portal grants cannot exceed {$maxDays} days.");
        $verifyMinutes=max(5,(int)config('crm.portal.identity_code_ttl_minutes',30));
        $this->db->table('crm_portal_grants')->insert([
            'public_id'=>$publicId,'company_id'=>$companyId,'user_id'=>CrmCompanyScope::actorUserId($userId),
            'company_public_id'=>$companyPublicId,'contact_public_id'=>$contactPublicId,
            'document_type'=>$attributes['document_type']??null,'document_public_id'=>$attributes['document_public_id']??null,'label'=>$attributes['label']??null,
            'status'=>'invited','token_hash'=>hash('sha256',$token),'token_hint'=>substr($token,-8),'scopes'=>json_encode($scopes),
            'identity_verification_hash'=>$this->verificationHash($token,$verificationCode),'identity_verification_hint'=>substr($verificationCode,-2),
            'identity_verification_expires_at'=>now()->addMinutes($verifyMinutes),'identity_verification_attempts'=>0,
            'invited_at'=>now(),'expires_at'=>$expires,
            'metadata'=>json_encode(array_diff_key((array)($attributes['metadata']??[]),array_flip(['token','password','secret','verification_code']))),
            'created_at'=>now(),'updated_at'=>now(),
        ]);
        return [
            'grant'=>(array)$this->db->table('crm_portal_grants')->where('public_id',$publicId)->first(),
            'token'=>$token,
            'verification_code'=>$verificationCode,
        ];
    }

    public function resolve(string $token, ?Request $request=null): array
    {
        $token=trim($token); if(strlen($token)<32) throw new NotFoundHttpException();
        return $this->db->transaction(function() use($token,$request){
            $grant=$this->db->table('crm_portal_grants')->where('token_hash',hash('sha256',$token))->lockForUpdate()->first();
            if(!$grant) throw new NotFoundHttpException();
            if($grant->revoked_at || $grant->status==='revoked') throw new GoneHttpException('This CRM portal link has been revoked.');
            if(now()->greaterThan($grant->expires_at)){
                $this->db->table('crm_portal_grants')->where('id',$grant->id)->update(['status'=>'expired','updated_at'=>now()]);
                $this->sessions->revokeGrant((string)$grant->public_id);
                throw new GoneHttpException('This Customer Hub link has expired.');
            }
            $updates=['last_accessed_at'=>now(),'updated_at'=>now()];
            if($grant->status==='invited'){$updates['status']='active';$updates['activated_at']=now();}
            $this->db->table('crm_portal_grants')->where('id',$grant->id)->update($updates);
            $current=(array)$this->db->table('crm_portal_grants')->where('id',$grant->id)->first();
            if($request)$this->sessions->bind($current,$request);
            $this->recordEvent((int)$grant->company_id,(int)$grant->user_id,(string)$grant->public_id,$grant->status==='invited'?'activated':'accessed',$request);
            return $current;
        });
    }

    public function verifyIdentity(string $token, string $code, Request $request): array
    {
        $token=trim($token); $code=trim($code);
        if(strlen($token)<32 || !preg_match('/^[0-9]{6}$/',$code)) throw new AccessDeniedHttpException('Invalid CRM portal verification code.');
        return $this->db->transaction(function() use($token,$code,$request): array {
            $grant=$this->db->table('crm_portal_grants')->where('token_hash',hash('sha256',$token))->lockForUpdate()->first();
            if(!$grant) throw new NotFoundHttpException();
            if($grant->revoked_at || $grant->status==='revoked') throw new GoneHttpException('This CRM portal link has been revoked.');
            if($grant->identity_locked_at) throw new AccessDeniedHttpException('CRM portal identity verification is locked. Ask the business to issue a new access grant.');
            if(!$grant->identity_verification_expires_at || now()->greaterThan($grant->identity_verification_expires_at)) throw new GoneHttpException('The CRM portal verification code has expired.');
            $max=max(1,(int)config('crm.portal.identity_max_attempts',5));
            if(!hash_equals((string)$grant->identity_verification_hash,$this->verificationHash($token,$code))){
                $attempts=((int)$grant->identity_verification_attempts)+1;
                $this->db->table('crm_portal_grants')->where('id',$grant->id)->update([
                    'identity_verification_attempts'=>$attempts,'identity_locked_at'=>$attempts >= $max?now():null,'updated_at'=>now(),
                ]);
                $this->recordEvent((int)$grant->company_id,(int)$grant->user_id,(string)$grant->public_id,'identity_verification_failed',$request,['attempts'=>$attempts]);
                throw new AccessDeniedHttpException('Invalid CRM portal verification code.');
            }
            $current=(array)$grant;
            $session=$this->sessions->markVerified($current,$request,'verification_code');
            $this->db->table('crm_portal_grants')->where('id',$grant->id)->update(['identity_verification_attempts'=>0,'updated_at'=>now()]);
            $this->recordEvent((int)$grant->company_id,(int)$grant->user_id,(string)$grant->public_id,'identity_verified',$request,['session_public_id'=>$session['public_id']??null]);
            return $session;
        });
    }

    public function requireVerifiedSession(array $grant, Request $request): array
    {
        if(!(bool)config('crm.portal.require_verified_identity',true)) return $this->sessions->bind($grant,$request);
        return $this->sessions->requireVerified($grant,$request);
    }

    public function isVerifiedSession(array $grant, Request $request): bool
    {
        if(!(bool)config('crm.portal.require_verified_identity',true)) return true;
        return $this->sessions->verified($grant,$request);
    }

    public function revoke(int $userId, string $publicId): void
    {
        $updated=$this->db->table('crm_portal_grants')->where('company_id',CrmCompanyScope::companyId($userId))->where('public_id',$publicId)->whereNull('revoked_at')
            ->update(['status'=>'revoked','revoked_at'=>now(),'updated_at'=>now()]);
        if(!$updated) throw new NotFoundHttpException();
        $this->sessions->revokeGrant($publicId);
    }

    public function allows(array $grant, string $scope): bool { return in_array($scope,json_decode((string)($grant['scopes']??'[]'),true)?:[],true); }

    private function assertCustomerAnchor(int $companyId, ?string $companyPublicId, ?string $contactPublicId): void
    {
        $company=null;
        if($companyPublicId!==null){
            $company=$this->db->table((string)config('crm.tables.companies','crm_companies'))
                ->where('company_id',$companyId)->where('public_id',$companyPublicId)->whereNull('deleted_at')->first();
            if(!$company) throw new \InvalidArgumentException('CRM portal company anchor does not exist in the active tenant.');
        }
        if($contactPublicId!==null){
            $contact=$this->db->table((string)config('crm.tables.contacts','crm_contacts'))
                ->where('company_id',$companyId)->where('public_id',$contactPublicId)->whereNull('deleted_at')->first();
            if(!$contact) throw new \InvalidArgumentException('CRM portal contact anchor does not exist in the active tenant.');
            if($companyPublicId!==null && !empty($contact->company_public_id) && (string)$contact->company_public_id!==$companyPublicId){
                throw new \InvalidArgumentException('CRM portal contact anchor does not belong to the selected company.');
            }
        }
    }

    private function verificationHash(string $token,string $code): string { return hash_hmac('sha256',$code,$token); }

    private function recordEvent(int $companyId,int $issuerUserId,string $grantPublicId,string $eventType,?Request $request,array $metadata=[]): void
    {
        $ip=$request?->ip();
        $this->db->table('crm_portal_events')->insert([
            'company_id'=>$companyId,'user_id'=>$issuerUserId,'portal_grant_public_id'=>$grantPublicId,'event_type'=>$eventType,
            'ip_hash'=>$ip?hash_hmac('sha256',$ip,(string)config('app.key')):null,'user_agent_summary'=>$request?mb_substr((string)$request->userAgent(),0,500):null,
            'metadata'=>json_encode($metadata,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),'occurred_at'=>now(),
        ]);
    }
}
