<?php

declare(strict_types=1);

namespace App\Extensions\TitanCommandBus\System\Http\Controllers;

use App\Extensions\TitanCommandBus\System\Contracts\CommandBusContract;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;

final class AdminController
{
    public function index(CommandBusContract $bus): View
    {
        return view('titan-command-bus::admin', ['health' => $bus->health()]);
    }

    public function health(CommandBusContract $bus): JsonResponse
    {
        return response()->json($bus->health());
    }
}
