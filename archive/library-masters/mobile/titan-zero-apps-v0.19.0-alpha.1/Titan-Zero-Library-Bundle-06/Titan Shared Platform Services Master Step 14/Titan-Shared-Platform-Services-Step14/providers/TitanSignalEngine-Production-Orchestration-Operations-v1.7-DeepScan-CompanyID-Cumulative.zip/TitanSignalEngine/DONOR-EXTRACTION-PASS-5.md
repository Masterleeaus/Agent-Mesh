# Donor Extraction — Pass 5 / Titan Pulse

The legacy donor `EnvelopeBuilder` and `SignalPriorityEngine` were used as design references only.

## Rewritten concepts

- donor severity/status summary -> normalized Pulse rollups
- donor top-signal/headline concept -> `PulseSurfaceBuilder`
- donor priority score -> deterministic `PulseAttentionScorer` with explicit operational reason codes
- donor timeline hint -> projection health + trace latency projections

## Explicitly not imported

- finance-specific amount scoring
- approval-pressure scoring (Governance owns approval policy)
- mutable process/status state
- donor `tz_*` tables
- `uniqid()` identifiers
- direct jobs/invoices table reads
- live aggregation over raw Signal events

Pulse is a read model over the modern immutable, tenant-safe Signal fabric.
