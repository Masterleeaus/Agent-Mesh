<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

final readonly class AnomalyThresholds
{
    public function __construct(
        public int $repeatedFailureCount5m = 5,
        public int $executionLoopCount = 10,
        public int $retryWaitCount = 10,
        public int $deadLetterCount = 1,
        public int $stalledTraceCount = 1,
        public int $missingReceiptCount = 1,
        public int $overrideCount1h = 5,
        public int $sequenceViolationCount = 1,
        public int $unresolvedCausationCount = 1,
        public float $volumeCollapseRatio = 0.20,
        public float $minimumBaselineEventsPer5m = 10.0,
    ) {
    }
}
