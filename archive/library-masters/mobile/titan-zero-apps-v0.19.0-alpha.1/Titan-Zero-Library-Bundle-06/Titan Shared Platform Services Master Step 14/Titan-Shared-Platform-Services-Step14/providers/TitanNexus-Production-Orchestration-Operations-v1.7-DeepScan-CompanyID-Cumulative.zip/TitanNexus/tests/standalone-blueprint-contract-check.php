<?php

declare(strict_types=1);
$root=dirname(__DIR__);
foreach (['/System/Support/StrictBoolean.php','/System/Support/SecretFieldGuard.php'] as $support) { require_once $root.$support; }
foreach ([
'/System/Support/CanonicalJson.php','/System/Domain/ValidationSeverity.php','/System/Domain/ValidationFinding.php','/System/Domain/ValidationResult.php','/System/Domain/SemanticChangeKind.php','/System/Domain/SemanticChangeDisposition.php','/System/Domain/SemanticDiffEntry.php','/System/Domain/ConfigurationDiff.php','/System/Domain/BusinessProfile.php','/System/Domain/CompiledTitanConfig.php','/System/Domain/VerticalDefinition.php','/System/Domain/ProvisioningOperation.php','/System/Domain/ProvisioningPlanStatus.php','/System/Domain/ProvisioningReceiptStatus.php','/System/Domain/ProvisioningReceipt.php','/System/Domain/ProvisioningPlan.php','/System/Domain/ValueObjects/TraceContext.php'
] as $f) require_once $root.$f;
use App\Extensions\TitanNexus\System\Domain\{BusinessProfile,CompiledTitanConfig,VerticalDefinition,ValidationFinding,ValidationResult,ValidationSeverity,SemanticDiffEntry,SemanticChangeKind,SemanticChangeDisposition,ConfigurationDiff,ProvisioningOperation,ProvisioningPlan,ProvisioningReceipt};
use App\Extensions\TitanNexus\System\Domain\ValueObjects\TraceContext;
function c(bool $ok,string $m):void{if(!$ok){fwrite(STDERR,"FAIL: $m\n");exit(1);}}
$profile=BusinessProfile::fromArray(['tenant_company_id'=>42,'profile_version'=>'1','vertical_id'=>'cleaning','vertical_version'=>'2026.08','jurisdiction'=>['country_code'=>'AU'],'timezone'=>'Australia/Melbourne','sections'=>['crm'=>['enabled'=>true]]]);
$vertical=VerticalDefinition::fromArray(['vertical_id'=>'cleaning','vertical_version'=>'2026.08','knowledge_snapshot_version'=>'ks1','sections'=>['crm'=>['enabled'=>false]],'validation'=>['required_profile_paths'=>['sections.crm'],'required_platform_capabilities'=>['crm.configuration.apply'],'require_knowledge_snapshot'=>true],'recompile_policy'=>['requires_approval_paths'=>['sections.crm']],'provisioning'=>['routes'=>['sections.crm'=>['capability'=>'crm.configuration.apply','depends_on'=>[]]]]]);
$c=$vertical->toContractArray(); c(isset($c['definition_hash'],$c['defaults'],$c['validation']['required_capabilities'],$c['provisioning']['dependencies']),'vertical contract export matches blueprint');
$config=new CompiledTitanConfig(42,'1','0.5.0','cleaning','2026.08','ks1',$profile->fingerprint(),$vertical->fingerprint(),['crm'=>['enabled'=>true]]);
c(($config->toContractArray()['vertical_definition_hash']??null)===$vertical->fingerprint(),'compiled config exports vertical_definition_hash');
$finding=new ValidationFinding('nexus.test',ValidationSeverity::Warning,'sections.crm','warning','nexus');
$validation=ValidationResult::fromFindings([$finding]);
$vc=$validation->toContractArray(); c(($vc['status']??null)==='warning' && isset($vc['findings'][0]['metadata']['source']),'validation contract export uses status and metadata');
$entry=new SemanticDiffEntry('sections.crm.enabled',SemanticChangeKind::Modify,SemanticChangeDisposition::RequiresApproval,false,true,'approval');
$diff=new ConfigurationDiff(str_repeat('a',64),str_repeat('b',64),[$entry]);
$dc=$diff->toContractArray(); c(($dc['entries'][0]['change_kind']??null)==='modify' && ($dc['entries'][0]['governance_disposition']??null)==='requires_approval','diff contract names are canonical');
$op=new ProvisioningOperation(42,'44444444-4444-4444-8444-444444444444',str_repeat('b',64),'sections.crm.enabled',SemanticChangeKind::Modify,SemanticChangeDisposition::RequiresApproval,'crm.configuration.apply','sections.crm',false,true,[],'approval');
$plan=new ProvisioningPlan(42,'44444444-4444-4444-8444-444444444444',str_repeat('b',64),$diff->fingerprint(),[$op]);
$pc=$plan->toContractArray(); c(isset($pc['plan_fingerprint']) && ($pc['operations'][0]['reversible']??null)===true,'provisioning plan contract matches blueprint');
$trace=TraceContext::fromArray(['tenant_company_id'=>42,'trace_id'=>'11111111-1111-4111-8111-111111111111','correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>'33333333-3333-4333-8333-333333333333']);
$r=ProvisioningReceipt::fromArray(['operation_id'=>$op->operationId(),'idempotency_key'=>$op->idempotencyKey(),'status'=>'applied','backup_reference'=>'b','backup_verified'=>true,'write_verified'=>true,'audit_reference'=>'a','rollback_reference'=>'r']);
$rc=$r->toContractArray($op,$trace); c(($rc['tenant_company_id']??null)===42 && ($rc['capability']??null)==='crm.configuration.apply' && ($rc['trace_id']??null)===$trace->traceId(),'mutation receipt contract carries tenant capability and trace lineage');
fwrite(STDOUT,"PASS: Titan Nexus blueprint contract export checks\n");
