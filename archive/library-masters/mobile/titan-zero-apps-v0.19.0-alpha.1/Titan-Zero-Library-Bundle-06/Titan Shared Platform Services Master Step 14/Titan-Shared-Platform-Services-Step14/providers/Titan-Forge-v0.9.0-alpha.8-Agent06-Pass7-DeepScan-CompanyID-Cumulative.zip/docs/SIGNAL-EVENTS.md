# Titan Forge Signal Events

All canonical Forge Signal events use owner/source `titan-forge` and carry `tenant_company_id`, `trace_id`, `correlation_id`, `causation_id` and `root_causation_id`.

Declared events:

- `forge.build.requested`
- `forge.build.started`
- `forge.artifact.generated`
- `forge.validation.started`
- `forge.validation.passed`
- `forge.validation.failed`
- `forge.release.candidate_created`
- `forge.build.failed`
- `forge.build.status_changed`

Schemas live under `schemas/events/`. Payloads must not contain credentials, authorization headers, secrets or signatures.
