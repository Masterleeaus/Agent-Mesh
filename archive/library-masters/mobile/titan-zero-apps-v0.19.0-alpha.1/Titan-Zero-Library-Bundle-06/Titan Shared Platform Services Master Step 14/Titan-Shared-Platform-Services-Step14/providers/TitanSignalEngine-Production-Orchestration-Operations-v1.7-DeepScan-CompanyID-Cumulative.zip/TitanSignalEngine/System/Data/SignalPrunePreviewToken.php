<?php

declare(strict_types=1);

namespace App\Extensions\TitanSignalEngine\System\Data;

use InvalidArgumentException;

final readonly class SignalPrunePreviewToken
{
    public function __construct(
        public string $previewId,
        public string $plainText,
        public string $hash,
    ) {
        if (! preg_match('/^[0-9a-f-]{36}$/i', $previewId)) {
            throw new InvalidArgumentException('Invalid Signal prune preview id.');
        }
        if (! preg_match('/^[a-f0-9]{64}$/', $hash)) {
            throw new InvalidArgumentException('Invalid Signal prune preview token hash.');
        }
    }

    public static function issue(string $previewId): self
    {
        $secret = rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
        $plain = $previewId . '.' . $secret;
        return new self($previewId, $plain, hash('sha256', $plain));
    }

    public static function previewIdFrom(string $plainText): string
    {
        $parts = explode('.', $plainText, 2);
        if (count($parts) !== 2 || ! preg_match('/^[0-9a-f-]{36}$/i', $parts[0])) {
            throw new InvalidArgumentException('Malformed Signal prune preview token.');
        }
        return $parts[0];
    }

    public function verify(string $candidate): bool
    {
        return hash_equals($this->hash, hash('sha256', $candidate));
    }
}
