<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('titan_command_receipts')) {
            return;
        }

        Schema::table('titan_command_receipts', static function (Blueprint $table): void {
            if (! Schema::hasColumn('titan_command_receipts', 'assurance_reference')) {
                $table->string('assurance_reference', 191)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_command_receipts', 'assurance_level')) {
                $table->string('assurance_level', 64)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_command_receipts', 'assurance_evidence')) {
                $table->json('assurance_evidence')->nullable();
            }
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('titan_command_receipts')) {
            return;
        }

        Schema::table('titan_command_receipts', static function (Blueprint $table): void {
            foreach (['assurance_evidence', 'assurance_level', 'assurance_reference'] as $column) {
                if (Schema::hasColumn('titan_command_receipts', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
