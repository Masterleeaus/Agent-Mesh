<?php

declare(strict_types=1);

namespace App\Extensions\TitanNexus\System\Contracts;

interface TenantContextResolverContract
{
    public function resolve(?object $user): int;
}
