# Titan Autonomy Engine v1.3.0

## Live Titan host wiring

- Added trusted CRM tenancy resolution through `CrmCompanyScope::tenantCompanyId()` while retaining `tenant_company_id` as Autonomy/CRM canonical tenancy.
- Added live ModelCouncil/Assurance bridge for tenant-scoped autonomy reliability runs.
- Added live TitanAI runtime bridge as a required third-handshake reliability signal; TitanAI still cannot mint autonomy approval.
- Added live Interaction Engine adapter using the verified manager, capability router, wizard-session store and CommandMapper.
- Added live Interaction CommandBus adapter that strips request-supplied tenant/actor context and dispatches only server-trusted context.
- Added `GovernedHostExecutionService` requiring a completed, tenant-matching Interaction session and its server-generated mapped payload before Auto/Trusted Auto dispatch.
- Added live Assurance assessment request service and tenant control-plane endpoint for eligible Auto → Trusted Auto review.
- Strengthened Trusted Auto review with deterministic sample/history, correction, failure, reversal and confidence checks in addition to live Assurance and TitanAI availability.
- Added live CRM capability registry verified against CRM 1.3.0-alpha.13, including published Interaction journey keys where present.

## Corrected host assumptions

- Replaced guessed `crm.invoice.send` with the published `crm.invoice.issue` capability.
- Documented that CRM alpha.13 `crm.invoice.issue` creates a draft invoice then transitions it to `issued`.
- Removed stale/unpublished `crm.work_order.complete` from the live Autonomy registry.
- Preserved Interaction Engine 10.3.2 `ApprovalRequired` enforcement; Autonomy does not forge signed human approvals or silently reinterpret Trusted Auto as per-action approval.
- Kept Rewind fail-closed/additive because no verified Rewind API was present in the supplied source set.

## Safety invariants retained

- capability/workflow isolation;
- one-gate-at-a-time promotion;
- no silent escalation;
- bounded scope from Semi-Auto upward;
- Platform + User + TitanAI/Assurance for Trusted Auto;
- tenant policy may only become stricter;
- caller-supplied tenant, actor, payload and approval data cannot establish execution authority;
- missing or ambiguous live host dependencies deny instead of bypassing governance.
