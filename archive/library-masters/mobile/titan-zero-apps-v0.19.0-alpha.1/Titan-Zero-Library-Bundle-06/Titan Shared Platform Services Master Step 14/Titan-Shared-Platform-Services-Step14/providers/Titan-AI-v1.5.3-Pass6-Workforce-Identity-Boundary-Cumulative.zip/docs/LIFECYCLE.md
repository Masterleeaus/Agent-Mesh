# Upgrade, disable and uninstall

## Upgrade

TitanAI uses forward-only guarded migrations. Normal upgrades should never rely on rolling back old migrations to infer extension ownership.

From v1.3.0, `company_id` is the only runtime tenant boundary. The `2026_08_09_000120_migrate_company_id_tenant_boundary.php` migration validates and renames legacy TitanAI `tenant_id` columns. If both columns exist on an owned table, the migration fails closed for manual resolution rather than guessing which value is authoritative.

Before upgrading production:

1. back up the database;
2. disable new TitanAI work or drain the entry points;
3. install the new extension files;
4. run normal host migrations;
5. clear relevant host caches;
6. verify provider/WorkCore diagnostics;
7. re-enable traffic.

## Disable

Disabling stops new TitanAI and governed WorkCore work while preserving records. Pending approvals can still be rejected, but approving/executing or rolling back WorkCore actions is blocked while TitanAI is disabled.

## Uninstall

`TitanAIServiceProvider::uninstall()` is static and idempotent. The declared default data policy is `retain`.

Uninstall does not drop WorkCore tables or operational business data. TitanAI-owned governance tables are retained unless a separate explicit administrative data-deletion procedure is performed.
