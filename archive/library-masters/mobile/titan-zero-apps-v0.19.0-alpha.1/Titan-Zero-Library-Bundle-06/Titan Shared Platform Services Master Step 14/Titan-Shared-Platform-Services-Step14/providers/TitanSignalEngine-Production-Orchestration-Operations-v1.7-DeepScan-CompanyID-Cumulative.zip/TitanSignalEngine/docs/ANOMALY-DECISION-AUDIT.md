# Immutable Anomaly Decision Audit — v0.18.0

## Authority model

`titan_signal_anomalies` is the current-state projection. Immutable `signal.anomaly.*` lifecycle events are the durable audit record.

## Transaction rule

Manual lifecycle mutations acquire the anomaly row, increment `decision_version`, write the new projection, emit the immutable audit event, record `last_decision_event_id`, and commit as one transaction. Audit emission failure rolls the mutation back.

## Idempotency

Each transition uses `anomaly-decision:<anomaly_id>:<decision_version>:<action>`. Repeating an already-completed no-op state does not create another decision event.

## Evidence

The audit payload stores a SHA-256 reference to the current anomaly evidence rather than duplicating the full evidence body. This provides stable linkage without turning lifecycle events into unrestricted telemetry copies.

## Automatic decisions

Trace-recovery resolution uses reason `trace_evaluation_recovered`. Recurrence after resolution uses `condition_recurred`; recurrence after suppression expiry uses `suppression_expired_condition_recurred`. Automatic decisions use explicit system actors and the same immutable event path as operator actions.
