<?php

declare(strict_types=1);

namespace App\Extensions\TitanRewind\System\Replay;

use App\Extensions\TitanRewind\System\Support\RewindPayloadSanitizer;
use InvalidArgumentException;

final class RewindReplayRequest
{
    private const MODES = ['current-state','counterfactual','model-compare','policy-compare','knowledge-compare'];
    private const NETWORK_POLICIES = ['deny-all','recorded-only','allowlist'];

    private function __construct(private array $data) {}

    public static function fromArray(array $input, RewindPayloadSanitizer $sanitizer): self
    {
        $input = $sanitizer->sanitize($input);
        $mode = (string)($input['mode'] ?? '');
        if (!in_array($mode, self::MODES, true)) {
            throw new InvalidArgumentException('Unsupported Titan Rewind comparative replay mode.');
        }
        if (isset($input['mutation_policy']) && $input['mutation_policy'] !== 'deny') {
            throw new InvalidArgumentException('Titan Rewind replay mutation policy is permanently deny.');
        }
        $network = (string)($input['network_policy'] ?? 'deny-all');
        if (!in_array($network, self::NETWORK_POLICIES, true)) {
            throw new InvalidArgumentException('Unsupported Titan Rewind replay network policy.');
        }

        $counterfactual = $input['counterfactual_overrides'] ?? [];
        $currentState = $input['current_state_overrides'] ?? [];
        if ($mode === 'counterfactual' && !is_array($counterfactual)) {
            throw new InvalidArgumentException('Counterfactual overrides must be a structured object.');
        }
        if ($mode === 'current-state' && (!is_array($currentState) || $currentState === [])) {
            throw new InvalidArgumentException('current_state_overrides is required for current-state comparison.');
        }

        $targets = [
            'model-compare' => 'target_model',
            'policy-compare' => 'target_policy',
            'knowledge-compare' => 'target_knowledge',
        ];
        if (isset($targets[$mode])) {
            $target = $input[$targets[$mode]] ?? null;
            if (!is_array($target) || $target === []) {
                throw new InvalidArgumentException("{$targets[$mode]} is required for {$mode}.");
            }
        }

        $seed = $input['deterministic_seed'] ?? null;
        if ($seed !== null && !is_scalar($seed)) {
            throw new InvalidArgumentException('deterministic_seed must be scalar or null.');
        }

        return new self([
            'mode' => $mode,
            'mutation_policy' => 'deny',
            'network_policy' => $network,
            'counterfactual_overrides' => is_array($counterfactual) ? $counterfactual : [],
            'current_state_overrides' => is_array($currentState) ? $currentState : [],
            'target_model' => is_array($input['target_model'] ?? null) ? $input['target_model'] : null,
            'target_policy' => is_array($input['target_policy'] ?? null) ? $input['target_policy'] : null,
            'target_knowledge' => is_array($input['target_knowledge'] ?? null) ? $input['target_knowledge'] : null,
            'deterministic_seed' => $seed,
            'requested_from' => isset($input['requested_from']) && is_scalar($input['requested_from']) ? (string)$input['requested_from'] : null,
        ]);
    }

    public function mode(): string { return $this->data['mode']; }
    public function mutationPolicy(): string { return 'deny'; }
    public function networkPolicy(): string { return $this->data['network_policy']; }
    public function counterfactualOverrides(): array { return $this->data['counterfactual_overrides']; }
    public function currentStateOverrides(): array { return $this->data['current_state_overrides']; }
    public function targetModel(): ?array { return $this->data['target_model']; }
    public function targetPolicy(): ?array { return $this->data['target_policy']; }
    public function targetKnowledge(): ?array { return $this->data['target_knowledge']; }
    public function deterministicSeed(): int|string|null { return $this->data['deterministic_seed']; }
    public function toArray(): array { return $this->data; }
}
