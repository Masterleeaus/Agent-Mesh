@push('css')
<link rel="stylesheet" href="{{ asset('vendor/titan-connect/css/operator-inbox.css') }}">
@endpush

<div class="container-fluid py-6">
<section class="tc-operator tc-settings">
    <header class="tc-operator__header">
        <div>
            <h1>{{ __('Channels') }}</h1>
            <p>{{ __('Connect, inspect and configure every Titan Connect communication channel for this company.') }}</p>
        </div>
        <div class="tc-operator__header-actions">
            <a class="tc-btn" href="{{ route('dashboard.user.titan-connect.inbox.unified') }}">{{ __('Inbox') }}</a>
            <a class="tc-btn tc-btn--ghost" href="{{ route('dashboard.user.titan-connect.settings.index') }}">{{ __('Diagnostics') }}</a>
        </div>
    </header>

    <div class="tc-provider-grid">
        @foreach ($providers as $provider => $label)
            <a class="tc-provider-card" href="{{ route('dashboard.user.titan-connect.channels.'.$provider) }}">
                @if (in_array($provider, ['whatsapp', 'messenger', 'instagram', 'telegram'], true))
                    <img src="{{ asset('vendor/titan-connect/icons/'.$provider.'.svg') }}" alt="">
                @else
                    <span class="tc-provider-card__letter">{{ strtoupper(substr($label, 0, 1)) }}</span>
                @endif
                <strong>{{ $label }}</strong>
                <span>{{ trans_choice(':count connection|:count connections', (int) ($counts[$provider] ?? 0), ['count' => (int) ($counts[$provider] ?? 0)]) }}</span>
            </a>
        @endforeach
    </div>
</section>
</div>
