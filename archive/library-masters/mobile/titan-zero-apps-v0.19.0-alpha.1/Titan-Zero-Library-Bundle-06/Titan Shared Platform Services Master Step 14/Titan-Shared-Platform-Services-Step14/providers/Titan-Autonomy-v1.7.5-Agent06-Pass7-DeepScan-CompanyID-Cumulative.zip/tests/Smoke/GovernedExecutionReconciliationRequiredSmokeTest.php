<?php

declare(strict_types=1);

spl_autoload_register(function(string $class):void{ $p='App\\Extensions\\TitanAutonomy\\'; if(!str_starts_with($class,$p))return; $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($path))require_once $path; });

use App\Extensions\TitanAutonomy\System\Contracts\{AssuranceBridgeContract,CommandBusBridgeContract,ExecutionReconciliationContract,HostContextBridgeContract,InteractionEngineBridgeContract};
use App\Extensions\TitanAutonomy\System\DTOs\{CapabilityState,GovernedCapabilityCommand};
use App\Extensions\TitanAutonomy\System\Enums\{AutonomyLevel,RiskClass};
use App\Extensions\TitanAutonomy\System\Services\{DelegatedAuthorityEnvelopeService,ExecutionAuthorityGuard,GovernedHostExecutionService,LiveGovernedCapabilityRegistry};

$host=new class implements HostContextBridgeContract {public function tenantCompanyId():int{return 42;}public function userId():int{return 7;}public function can(string $p):bool{return true;}public function isSuperAdmin():bool{return false;}};
$interaction=new class implements InteractionEngineBridgeContract {public function prepareJourney(string $c,?string $w,array $x):array{return ['ready'=>true,'available'=>true,'session_validated'=>true,'mapped_command'=>['capability'=>$c,'payload'=>['total_minor'=>50000],'metadata'=>['correlation_id'=>'corr-r','session_id'=>'sess-r','idempotency_key'=>'idem-r']]];}};
$assurance=new class implements AssuranceBridgeContract {public function evaluate(string $c,?string $w,array $x):array{return ['status'=>'GREEN','decision'=>'approved','confidence'=>.98,'reason_codes'=>[]];}};
$bus=new class implements CommandBusBridgeContract {public int $calls=0;public function dispatch(object $c,array $a):mixed{$this->calls++;return ['status'=>'executed','data'=>['status'=>'ok','result'=>['public_id'=>'INV1']]];}};
$tokens=new DelegatedAuthorityEnvelopeService('base64:unit-test-application-key-1234567890','test-policy',90);
$state=new CapabilityState(42,'crm.invoice.issue','completed_job_invoice',RiskClass::Medium,AutonomyLevel::Auto,2,2,2,10,0,0,0,0,true,['workflow'=>'completed_job_invoice','max_total'=>1500]);
$cmd=new GovernedCapabilityCommand('crm.invoice.issue',[],'completed_job_invoice','corr-r',null,'sess-r','idem-r');

$without=new GovernedHostExecutionService($host,new LiveGovernedCapabilityRegistry(),new ExecutionAuthorityGuard(),$interaction,$bus,$assurance,delegation:$tokens);
$r=$without->execute($state,$cmd,['workflow'=>'completed_job_invoice','total'=>500]);
if(($r['executed']??true)!==false||!in_array('OUTCOME_RECONCILIATION_UNAVAILABLE',(array)($r['reason_codes']??[]),true)||$bus->calls!==0)throw new RuntimeException('Auto execution must fail closed before dispatch when outcome reconciliation is unavailable.');

$recon=new class implements ExecutionReconciliationContract {public int $captures=0; public function capture(CapabilityState $s,GovernedCapabilityCommand $c,array $x,array $r,array $a,?int $u):array{$this->captures++;return ['receipt_id'=>'E1','observation_status'=>'observing'];} public function finalizeDue(int $limit=100):int{return 0;}};
$with=new GovernedHostExecutionService($host,new LiveGovernedCapabilityRegistry(),new ExecutionAuthorityGuard(),$interaction,$bus,$assurance,delegation:$tokens,reconciliation:$recon);
$r=$with->execute($state,$cmd,['workflow'=>'completed_job_invoice','total'=>500]);
if(($r['executed']??false)!==true||$bus->calls!==1||$recon->captures!==1||($r['outcome_tracking']['receipt_id']??null)!=='E1')throw new RuntimeException('Auto execution must capture one reconciliation receipt after dispatch.');

echo "OK: GovernedExecutionReconciliationRequiredSmokeTest\n";
