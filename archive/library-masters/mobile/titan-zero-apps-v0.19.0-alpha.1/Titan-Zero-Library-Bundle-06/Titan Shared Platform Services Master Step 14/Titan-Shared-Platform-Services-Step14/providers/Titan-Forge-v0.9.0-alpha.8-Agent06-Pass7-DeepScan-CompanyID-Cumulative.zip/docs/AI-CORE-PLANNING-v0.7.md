# Titan Forge AI Core Planning — v0.7

Forge consumes Titan AI Core planning through its published typed contracts. It does not call model providers directly and does not treat an AI Core plan as executable authority.

## Contract boundary

Forge resolves:

- `App\Extensions\TitanAICore\System\Contracts\OrchestratorContract`
- `App\Extensions\TitanAICore\System\Contracts\PlanValidatorContract`

A Forge `BuildRequest` is converted into AI Core `ExecutionIntent` and `RuntimeContext` values containing the trusted tenant, actor, trace, correlation, causation, root-causation, operation and idempotency context.

AI Core returns a typed `PlanEnvelope`. Forge accepts it only when:

1. the returned runtime context exactly matches the Forge request context;
2. AI Core's own validator reports `valid=true`;
3. at least one typed plan step is present;
4. every step and dependency maps into a valid deterministic Forge `BuildPlan`.

`ValidationReport::executable` does not grant Forge execution authority. Forge consumes the plan as a generation proposal only.

## Current peer state

Verified Titan AI Core v0.3.0 exposes the typed planning contract but its `PlanValidator` intentionally returns `DAG_VALIDATOR_NOT_IMPLEMENTED` with `valid=false`. Therefore the current production adapter returns `planning_blocked` rather than bypassing AI Core or fabricating a plan.

## Persistence

Usable AI plans are immutable per idempotent Forge build. Forge stores:

- Forge build-plan fingerprint and steps;
- AI Core source plan ID;
- source plan schema/runtime versions;
- source plan SHA-256;
- AI Core validator version and executable flag;
- `deployment_authority: none`.

A second different plan cannot overwrite an already-persisted plan for the same idempotent build.

## Privacy and reasoning

Forge does not persist hidden chain-of-thought. Planning evidence is limited to typed plan structure, validation reports, source identifiers, hashes and bounded structured metadata.
