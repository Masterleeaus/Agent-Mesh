# Titan Command Bus v0.2.0-alpha.6

Blueprint v4.2.0 rebased canonical governed execution spine for Titan Zero.

## Role
Titan Command Bus is the canonical owner of `governed-mutation`. It accepts trusted tenant/actor context separately from untrusted command payloads, enforces durable idempotency, obtains fresh Titan Risk evidence before Governance, resolves deterministic domain adapters, produces immutable command receipts, and emits causal Signal telemetry.

## Pass 9 — Risk integration
Command dispatch now has a dedicated `CommandRiskGateContract`. Runtime mutation dispatch is fail-closed when risk is required but unavailable, denied, or malformed. Risk evidence is kept separate from Governance evidence and is passed into the Governance gate as an upper-bound control input. Applied/refused receipts persist `risk_reference`, `risk_class`, and optional normalized `risk_score`; outcome Signals propagate the same evidence.

## Safety defaults
The package is intentionally fail-closed. Its default Risk gate, Governance gate and Signal emitter are unavailable adapters, so state-changing execution remains blocked until the host binds verified Titan Risk, Governance and Signal bridges. Assurance and Autonomy remain later planned gates. No foreign-domain adapter is shipped in the core package.

## Blueprint identity
- primary profile: `system-engine`
- modifiers: `command-bus-core`, `signal-aware`
- production core: `titan.production.core.v1`
- installer: `titan-extension-v1`, flat-root
- tenant boundary: `tenant_company_id`

Run `php artisan titan:titan-command-bus:certify --json` on the real host for host evidence.


## Pass 10 — Assurance / Shield boundary
Mutation dispatch now requires an authoritative Assurance/Shield decision after Titan Risk and before Governance. The default bridge is fail-closed; no local assurance or Shield policy is inferred. Accepted evidence is durable and is passed into Governance, receipts, and outcome Signals.


## Pass 10 — Assurance / Shield integration
Mutation dispatch now fails closed unless an authoritative Assurance/Shield bridge is available and returns a durable allowed decision. Accepted assurance evidence flows into Governance, receipts and Signal telemetry.


## Pass 11 — Titan Autonomy integration

Command dispatch now resolves earned autonomy after Risk and Assurance and before Governance. Autonomy is capability/workflow-specific evidence, never a caller-selected permission. When `require_autonomy=true`, unavailable, denied, or malformed autonomy evidence fails closed before Governance or domain execution. Successful decisions preserve `autonomy_reference`, `autonomy_level`, `autonomy_workflow`, and evidence references in receipts and Signal telemetry.
