# Governance

Payroll command mutations require Command Bus. High-impact actions require Risk and Assurance. Effective authority comes only from Titan Autonomy. Missing required engines means deny/escalate.
