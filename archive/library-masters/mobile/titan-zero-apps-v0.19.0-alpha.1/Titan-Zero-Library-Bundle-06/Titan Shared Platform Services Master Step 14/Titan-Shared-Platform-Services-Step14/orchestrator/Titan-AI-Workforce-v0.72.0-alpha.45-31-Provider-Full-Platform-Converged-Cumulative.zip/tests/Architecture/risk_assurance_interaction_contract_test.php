<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$decisionPath = $root.'/System/Support/WorkforceGovernanceDecision.php';
$servicePath = $root.'/System/Services/WorkforcePreExecutionGovernanceService.php';
$bridgePath = $root.'/System/Services/WorkforceGovernanceBridge.php';
$executionPath = $root.'/System/Services/WorkforceExecutionService.php';
$registryPath = $root.'/System/Support/WorkforceManifestRegistry.php';
$handoffPath = $root.'/System/Services/WorkforceHandoffPacketService.php';
$providerPath = $root.'/System/TitanAIWorkforceServiceProvider.php';
$docsPath = $root.'/docs/PASS12-RISK-ASSURANCE-MODEL-COUNCIL-INTERACTION.md';

foreach ([$decisionPath,$servicePath,$docsPath] as $path) {
    $assert(is_file($path), 'missing Pass 12 file: '.basename($path));
}

if (is_file($decisionPath)) {
    require_once $decisionPath;
    $class = 'App\\Extensions\\TitanAIWorkforce\\System\\Support\\WorkforceGovernanceDecision';

    $risk = $class::normalizeRisk([
        'decision_id' => 'risk-1',
        'level' => 'HIGH',
        'allowed' => false,
        'policy_version' => 'risk-v2',
        'evaluated_at' => '2026-08-20T19:10:00+10:00',
        'requires_model_council' => true,
        'contextual_risk_ref' => 'risk:context:1',
        'cumulative_risk_ref' => 'risk:cumulative:1',
        'vertical_risk_ref' => 'risk:vertical:field-services',
        'residual_risk_ref' => 'risk:residual:1',
        'evidence_refs' => ['evidence:risk:1'],
    ]);
    $assert(($risk['level'] ?? null) === 'HIGH', 'Risk normalizer must preserve HIGH category');
    $assert(($risk['requires_model_council'] ?? false) === true, 'Risk decision must carry selective Model Council requirement');

    $assurance = $class::normalizeAssurance([
        'decision_id' => 'assurance-1',
        'state' => 'GREEN',
        'allowed' => true,
        'policy_version' => 'assurance-v2',
        'evaluated_at' => '2026-08-20T19:10:01+10:00',
        'evidence_refs' => ['evidence:assurance:1'],
        'missing_evidence' => [],
    ]);
    $assert(($assurance['state'] ?? null) === 'GREEN', 'Assurance normalizer must preserve GREEN state');

    $policy = $class::policy($risk, $assurance, [
        'required' => true,
        'available' => true,
        'consulted' => true,
        'policy_satisfied' => true,
        'decision_id' => 'council-1',
    ]);
    $assert(($policy['allowed'] ?? true) === false, 'GREEN Assurance must never override a HIGH Risk denial');
    $assert(in_array('RISK_DENIED', $policy['reason_codes'] ?? [], true), 'Risk denial reason must be retained');

    $allowedRisk = $risk;
    $allowedRisk['allowed'] = true;
    $notRequiredCouncil = ['required' => false, 'available' => true, 'consulted' => false, 'policy_satisfied' => true];
    $allowed = $class::policy($allowedRisk, $assurance, $notRequiredCouncil);
    $assert(($allowed['allowed'] ?? false) === true, 'Policy may pass when each authoritative gate allows execution');

    $missing = $class::missingEvidence(['job_completion_photo','customer_signature'], [
        ['type' => 'job_completion_photo', 'ref' => 'evidence:photo:1'],
    ]);
    $assert($missing === ['customer_signature'], 'missing evidence detection must be deterministic');

    try {
        $class::normalizeRisk(['level' => 'CRITICAL', 'allowed' => true]);
        $assert(false, 'non-canonical Risk category must be rejected');
    } catch (Throwable) {}

    try {
        $class::normalizeAssurance(['state' => 'BLUE', 'allowed' => true]);
        $assert(false, 'non-canonical Assurance state must be rejected');
    } catch (Throwable) {}
}

$service = @file_get_contents($servicePath) ?: '';
foreach ([
    'contextual_risk_ref','cumulative_risk_ref','vertical_risk_ref','residual_risk_ref',
    'required_evidence','missing_evidence','WorkforceControlPlaneIntegrationRegistry',"bindingsFor('risk')","bindingsFor('assurance')","bindingsFor('model_council')",
    'requires_model_council','policy_satisfied','findOwnedCapability'
] as $needle) {
    $assert(str_contains($service, $needle), 'pre-execution governance service missing '.$needle);
}
$assert(str_contains($service, "'required' => false") && str_contains($service, "'consulted' => false"), 'Model Council must be optional by default, not called for every task');

$bridge = @file_get_contents($bridgePath) ?: '';
$assert(str_contains($bridge, 'WorkforcePreExecutionGovernanceService'), 'governance bridge must delegate Risk/Assurance/Council evaluation to Pass 12 service');
foreach (['missing_evidence','evidence_collection','interaction_workflow_ref'] as $needle) {
    $assert(str_contains($bridge, $needle), 'Interaction evidence workflow path missing '.$needle);
}

$execution = @file_get_contents($executionPath) ?: '';
foreach (["['policy']['allowed']",'execution.governance_policy_denied','model_council'] as $needle) {
    $assert(str_contains($execution, $needle), 'execution gate missing '.$needle);
}

$registry = @file_get_contents($registryPath) ?: '';
foreach (['findOwnedWorkflow','findOwnedWizard'] as $needle) {
    $assert(str_contains($registry, $needle), 'manifest registry missing '.$needle.' resolver');
}

$handoff = @file_get_contents($handoffPath) ?: '';
$assert(str_contains($handoff, "'evidence_refs'"), 'handoff packet must carry explicit evidence references');
$assert(str_contains($handoff, 'assurance_snapshot'), 'handoff packet must continue carrying Assurance snapshot evidence');

$provider = @file_get_contents($providerPath) ?: '';
$assert(str_contains($provider, "'titan.workforce.pre-execution-governance'"), 'stable Pass 12 governance adapter missing');

$manifest = json_decode((string) file_get_contents($root.'/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$assert(in_array('titan-workforce.pre-execution-governance-v2', $manifest['capabilities'] ?? [], true), 'sidecar missing Pass 12 pre-execution governance capability');

$docs = @file_get_contents($docsPath) ?: '';
foreach (['Minimal','Low','Medium','High','Extreme','Green','Amber','Red','Model Council','Interaction','evidence','fail closed'] as $needle) {
    $assert(str_contains($docs, $needle), 'Pass 12 docs missing '.$needle);
}

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce Risk/Assurance/Model Council/Interaction contract\n";
