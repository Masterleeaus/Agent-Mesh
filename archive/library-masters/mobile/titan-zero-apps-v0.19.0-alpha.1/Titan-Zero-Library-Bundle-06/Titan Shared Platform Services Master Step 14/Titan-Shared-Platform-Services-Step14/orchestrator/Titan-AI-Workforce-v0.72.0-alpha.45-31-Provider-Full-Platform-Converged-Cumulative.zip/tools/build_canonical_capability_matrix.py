#!/usr/bin/env python3
from __future__ import annotations
import json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / 'resources/workforce/ecosystem-capability-registry.json'
OUT = ROOT / 'resources/workforce/canonical-capability-binding-matrix.json'

PROFILES: dict[str, dict[str, dict[str, list[str]]]] = {
    'crm': {
        'customer': {'cap': [r'^crm\.(customer\.|contact\.|activity\.create$|company\.search$|company\.context\.read$)']},
        'booking': {'cap': [r'^crm\.(appointment\.|calendar(?:\.|$)|business\.booking_rules\.|business\.hours\.read$|customer\.(read|search|update)$|contact\.(read|search)$)']},
        'sales': {'cap': [r'^crm\.(lead\.|deal\.|quote\.|estimate\.create$|company\.(search|context\.read)$|contact\.(read|search|create|update)$)']},
        'marketing': {'cap': [r'^crm\.(customer\.(read|search|update)$|contact\.(read|search)$|activity\.create$|analytics$|advanced_analytics$|ai\.context\.read$)']},
        'business-admin': {'cap': [r'^crm\.business\.(profile|hours|service|service_area|location|booking_rules|field_rules|pricing)\.', r'^crm\.company\.context\.read$']},
        'finance': {'cap': [r'^crm\.(invoice\.|credit_note\.|finance\.)']},
        'documents': {'cap': [r'^crm\.document\.', r'^crm\.(customer|contact|company)\.(read|search)$']},
        'analytics': {'cap': [r'^crm\.(analytics$|advanced_analytics$|ai\.context\.read$|customer\.(read|search)$|company\.search$|lead\.search$|quote\.(read|search)$)']},
    },
    'titan-connect': {
        'customer-comms': {'cap': [r'^communications\.(audit$|external\.send$|inbox$|omnichannel$|operator-console$|team\.conversation\.|team\.messages\.(read|send)$|voice$)']},
        'team-comms': {'cap': [r'^communications\.(audit$|team-chat$|team\.conversation\.|team\.messages\.(read|send)$)']},
    },
    'titan-field': {
        'service': {'cap': [r'^titan\.field\.(capacity\.forecast|work_orders|scheduling|exceptions)$'], 'signal': [r'^field\.'], 'workflow': [r'^field-']},
        'dispatch': {'cap': [r'^titan\.field\.(capacity\.forecast|dispatch|routes|scheduling|exceptions|work_orders)$'], 'signal': [r'^field\.'], 'workflow': [r'^field-']},
        'completion': {'cap': [r'^titan\.field\.(evidence|forms|work_orders|exceptions)$'], 'signal': [r'^field\.'], 'workflow': [r'^field-']},
        'maintenance': {'cap': [r'^titan\.field\.(work_orders|scheduling|evidence|forms|exceptions)$'], 'signal': [r'^field\.'], 'workflow': [r'^field-']},
        'project': {'cap': [r'^titan\.field\.(work_orders|scheduling|evidence|forms|routes|exceptions)$'], 'signal': [r'^field\.'], 'workflow': [r'^field-']},
    },
    'titan-financial-engine': {
        'pricing': {'cap': [r'^financial\.calculate\.(margin\.profitability|pricing|quote\.estimate|discount\.promotion|tax|formula\.rules)$']},
        'receivables': {'cap': [r'^financial\.calculate\.(forecast\.cash\.flow|payment\.settlement\.cost|margin\.profitability|tax)$']},
        'costing': {'cap': [r'^financial\.calculate\.(job\.costing|labour\.rate|inventory\.materials\.cost|asset\.fleet\.equipment\.cost|margin\.profitability)$']},
        'commercial': {'cap': [r'^financial\.calculate\.(break\.even\.scenario|commission\.incentive|discount\.promotion|forecast\.cash\.flow|margin\.profitability|pricing)$']},
        'asset-cost': {'cap': [r'^financial\.calculate\.(asset\.fleet\.equipment\.cost|forecast\.cash\.flow|margin\.profitability)$']},
        'inventory-cost': {'cap': [r'^financial\.calculate\.(inventory\.materials\.cost|forecast\.cash\.flow|margin\.profitability)$']},
    },
    'titan-ledger': {
        'receivables': {'cap': [r'^ledger\.(accounts_receivable|receivables_aging|collections$|collection_events|dunning_facts|crm_invoice_accounting|payment_|actual_cashflow|cashflow_)']},
        'payables': {'cap': [r'^ledger\.(accounts_payable|payables_aging|supplier_|payment_|actual_cashflow|cashflow_)']},
        'bookkeeping': {'cap': [r'^ledger\.(journals|bank_reconciliation|chart_of_accounts|trial_balance|profit_loss|balance_sheet|gst_|accounting_periods|period_locks)']},
        'finance': {'cap': [r'^ledger\.(financial_|management_reporting|cashflow_|actual_cashflow|profitability|forecast_|trial_balance|profit_loss|balance_sheet|accounts_receivable|accounts_payable)']},
        'commercial': {'cap': [r'^ledger\.(accounts_receivable|receivables_aging|profitability|financial_reporting_read_port|management_reporting|actual_cashflow|cashflow_)']},
    },
    'titan-assets': {
        'assets': {'cap': [r'^assets\.(register|crud|equipment$|equipment_checks|history|lifecycle|maintenance|repairs|allocations|reports|customer_assets\.read)']},
        'fleet': {'cap': [r'^assets\.(fleet|mileage|maintenance|history|reports|scan\.report|allocations)']},
        'facilities': {'cap': [r'^assets\.(premises_links|equipment|maintenance|repairs|downtime|reports)']},
        'inspection': {'cap': [r'^assets\.(history|lifecycle_history|scan\.report|maintenance|repairs|warranties|customer_assets\.read)']},
    },
    'titan-locker': {
        'inventory': {'cap': [r'^inventory\.(items|locations|reservations|stock_counts|stock_movements|stock_transfers|job_consumption|reorder)$']},
        'procurement': {'cap': [r'^inventory\.(purchase_orders|suppliers|goods_receipts|reorder|items|locations)$']},
        'fulfilment': {'cap': [r'^inventory\.(items|locations|reservations|stock_movements|stock_transfers|job_consumption)$']},
    },
    'titan-maps-intelligence': {
        'dispatch': {'cap': [r'^(job\.travel_context|route\.|nearby\.search|titan-maps-intelligence\.(dispatch|nearest-resource|route|route-plan|travel-matrix))']},
        'territory': {'cap': [r'^(location\.geocode|service_area\.check|territory\.|titan-maps-intelligence\.(territory|territory-analytics|geographic-pricing))']},
        'location': {'cap': [r'^(location\.geocode|route\.estimate|route\.compare|nearby\.search|job\.travel_context|titan-maps-intelligence\.route\.calculate)']},
    },
    'titan-time-attendance': {
        'workforce': {'cap': [r'^(time\.(entry|submission|attention|workflow|policy|costing)\.|attendance\.verification\.audit$)'], 'signal': [r'^(time|attendance)\.'], 'workflow': [r'.*']},
        'compliance': {'cap': [r'^(attendance\.(verification\.audit|verify)$|time\.policy\.read$|time\.entry\.read$)'], 'signal': [r'^attendance\.'], 'workflow': [r'^attendance\.']},
        'roster': {'cap': [r'^(time\.(entry\.read|attention\.read|costing\.calculate|policy\.read|workflow\.read)|attendance\.verification\.audit)$'], 'signal': [r'^(time|attendance)\.'], 'workflow': [r'.*']},
    },
    'titan-ai-vision': {
        'quality': {'cap': [r'^vision\.(analysis|evidence|evidence-quality|evidence-review|completion-assurance|completion-assurance-v2|before-after-comparison|scope-evidence-reconciliation|variation-blockers|safety-compliance|regulated-risk-review)$']},
        'asset': {'cap': [r'^vision\.(asset-|historical-baseline|repeat-visit-history|evidence|analysis)']},
        'inspection': {'cap': [r'^vision\.(analysis|evidence|evidence-quality|evidence-review|spatial-|safety-compliance|regulated-risk-review|capture-guidance|mobile-capture)$']},
    },
    'titan-knowledge-authority': {
        'knowledge': {'cap': [r'^(knowledge\.health|titan-knowledge-authority)$']},
    },
    'titan-nexus': {
        'change': {'cap': [r'^nexus\.(compile|validate|preview|history|recompile|provision\.plan|runtime-readiness|interface\.read-model|lifecycle\.traceable-history)$']},
        'configuration': {'cap': [r'^nexus\.(compile|validate|preview|contracts|interface|runtime-readiness|control-centre)']},
    },
    'titan-mcp': {
        'ops-read': {'cap': [r'^(titan_(extension_inspect|extensions_list|logs_recent|migrations_status|permissions_summary|project_info|queue_status|repository_list|repository_read|repository_search|routes_search|runtime_health|scheduler_list|schema_table|schema_tables)|titan_database_query_readonly)$']},
        'ops-change': {'cap': [r'^(titan_(audit_status|backup_manifest|backup_verify|config_search|extension_inspect|extensions_list|migrations_status|mutation_prepare|mutation_status|project_info|queue_status|repository_read|repository_search|routes_search|runtime_health|scheduler_list)|titan_database_query_readonly)$']},
    },
    'titan-ai-core': {
        'planning': {'cap': [r'^(ai\.plan\.contract\.typed|ai\.runtime\.status|ai\.security\.|ai\.governance\.preflight|ai\.approval\.state)$']},
    },
    'titan-model-council': {
        'deliberation': {'cap': [r'^council\.(deliberate|plan|governed-deliberation|contradiction-safeguard|final-validation|role-|lightweight-routing|parallel-consensus|pre-arbiter-validation|selective-activation)$']},
    },
    'titan-prime': {
        'missions': {'cap': [r'^prime\.(domain|mission\.|engine-gateway|gateway\.)']},
    },
    'titan-interaction-engine': {
        'interaction': {'cap': [r'^interaction\.(capabilities|capability-router|cognition|journeys|memory|runtime|surface\.|wizards|templates|field-home-services)$']},
    },
    'titan-signal-engine': {
        'observe': {'cap': [r'^signal\.(anomaly\.detect|correlate|health|history\.query|pulse|query|subscribe)$']},
    },
    'titan-risk-engine': {
        'risk': {'cap': [r'^risk\.(aggregate|assess|gate|velocity)$']},
    },
    'titan-assurance': {
        'assurance': {'cap': [r'^assurance\.(evaluate|evidence\.collect\.request)$']},
    },
    'titan-governance': {
        'oversight': {'cap': [r'^governance\.(compliance\.read|control-centre\.read|decision-|escalation\.queue\.read|health|human-oversight\.read|operational-pressure\.read|projection-history\.read|signal-heatmap\.read|source-health\.read|trust-map\.read|workforce-oversight\.read|autonomy-evidence\.read|circuit-breaker\.read)$']},
        'incident': {'cap': [r'^governance\.(escalation(?:\.|$)|decision-|human-oversight\.read|control-centre\.read|health)$']},
    },
    'titan-shield': {
        'compliance': {'cap': [r'^shield\.(definition\.validate|inspection\.evaluate|reinspection\.evaluate|review\.determine|rule\.evaluate|health)$']},
        'incident': {'cap': [r'^shield\.(inspection\.evaluate|reinspection\.evaluate|remediation\.prepare|review\.determine|rule\.evaluate|health)$']},
    },
    'titan-rewind': {
        'investigation': {'cap': [r'^rewind\.(audit|compare|diagnostics|drift|evidence$|integrity|reconstruct|recovery\.plan|root_cause|snapshot|snapshot\.compare|timeline|runtime-state)$']},
    },
    'titan-wisdom': {
        'outcomes-read': {'cap': [r'^wisdom\.(health\.read|readiness\.read)$']},
    },
    'titan-ai': {
        'runtime': {'cap': [r'^titan-ai\.(runtime|knowledge-context|memory-context|source-policy|trusted-tools|workers)$']},
    },
}

# Missing-role and deliberate multi-provider compositions.
EXTRA: dict[str, list[tuple[str, str]]] = {
    'titan.automation.process_improvement_coordinator': [('titan-ai-core','planning'),('titan-signal-engine','observe'),('titan-forge','automation'),('titan-mcp','ops-read')],
    'titan.automation.workflow_performance': [('titan-signal-engine','observe'),('titan-mcp','ops-read'),('titan-forge','automation')],
    'titan.customer.deputy_manager': [('crm','customer'),('titan-connect','customer-comms')],
    'titan.customer.operations_coordinator': [('crm','customer'),('titan-connect','customer-comms'),('titan-interaction-engine','interaction')],
    'titan.customer.retention_coordinator': [('crm','marketing'),('titan-connect','customer-comms')],
    'titan.customer.service_recovery_coordinator': [('crm','customer'),('titan-connect','customer-comms'),('titan-field','service')],
    'titan.ecommerce.fulfilment': [('titan-locker','fulfilment'),('crm','customer'),('titan-connect','customer-comms')],
    'titan.ecommerce.returns': [('titan-locker','fulfilment'),('titan-assets','inspection'),('crm','customer'),('titan-financial-engine','costing')],
    'titan.ecommerce.shipping': [('titan-locker','fulfilment'),('titan-maps-intelligence','location'),('titan-connect','customer-comms')],
    'titan.governance.incident_coordinator': [('titan-signal-engine','observe'),('titan-risk-engine','risk'),('titan-assurance','assurance'),('titan-governance','incident'),('titan-shield','incident'),('titan-rewind','investigation')],
    'titan.hospitality.concierge': [('crm','customer'),('titan-connect','customer-comms'),('titan-maps-intelligence','location')],
    'titan.hospitality.guest_experience': [('crm','customer'),('titan-connect','customer-comms')],
    'titan.hospitality.housekeeping_planner': [('titan-field','service'),('titan-assets','facilities'),('titan-locker','inventory'),('titan-time-attendance','roster')],
    'titan.insights.business_analyst': [('titan-ai-core','planning'),('titan-model-council','deliberation'),('crm','analytics'),('titan-ledger','finance')],
    'titan.insights.customer_insights_analyst': [('crm','analytics'),('titan-ai-core','planning'),('titan-model-council','deliberation')],
    'titan.insights.operations_analyst': [('titan-field','service'),('titan-maps-intelligence','dispatch'),('titan-time-attendance','roster'),('titan-ai-core','planning')],
    'titan.insights.performance_analyst': [('titan-time-attendance','workforce'),('titan-field','service'),('titan-financial-engine','commercial'),('titan-ai-core','planning')],
    'titan.manager.hospitality_realestate': [('crm','customer'),('titan-connect','customer-comms'),('titan-field','service'),('titan-assets','facilities'),('titan-maps-intelligence','location')],
    'titan.manager.marketing': [('crm','marketing'),('titan-connect','customer-comms'),('titan-ai-core','planning')],
    'titan.manager.retail_rental': [('crm','customer'),('titan-locker','inventory'),('titan-assets','assets'),('titan-financial-engine','commercial'),('titan-connect','customer-comms')],
    'titan.manager.risk': [('titan-risk-engine','risk'),('titan-assurance','assurance'),('titan-governance','oversight'),('titan-signal-engine','observe')],
    'titan.marketing.campaign_coordinator': [('crm','marketing'),('titan-connect','customer-comms')],
    'titan.marketing.reactivation_coordinator': [('crm','marketing'),('titan-connect','customer-comms')],
    'titan.marketing.reputation_manager': [('crm','customer'),('titan-connect','customer-comms'),('titan-signal-engine','observe')],
    'titan.marketing.reviews_referrals_coordinator': [('crm','customer'),('titan-connect','customer-comms')],
    'titan.operations.change_coordinator': [('titan-nexus','change'),('titan-forge','automation'),('titan-mcp','ops-change'),('titan-ai-core','planning')],
    'titan.operations.process_coordinator': [('titan-signal-engine','observe'),('titan-nexus','change'),('titan-ai-core','planning')],
    'titan.operations.risk_assurance_liaison': [('titan-risk-engine','risk'),('titan-assurance','assurance'),('titan-governance','oversight'),('titan-signal-engine','observe')],
    'titan.people.licensing_accreditation': [('titan-time-attendance','compliance'),('titan-shield','compliance'),('titan-knowledge-authority','knowledge')],
    'titan.people.training_coordinator': [('titan-time-attendance','workforce'),('titan-knowledge-authority','knowledge')],
    'titan.procurement.subcontractor_coordinator': [('crm','customer'),('titan-connect','customer-comms'),('titan-time-attendance','compliance'),('titan-shield','compliance')],
    'titan.procurement.supplier_relations': [('titan-locker','procurement'),('crm','customer'),('titan-connect','customer-comms')],
    'titan.realestate.facilities': [('titan-assets','facilities'),('titan-field','maintenance'),('titan-ai-vision','inspection')],
    'titan.realestate.handover_inspector': [('titan-ai-vision','inspection'),('titan-field','completion'),('titan-knowledge-authority','knowledge')],
    'titan.realestate.leasing': [('crm','customer'),('titan-connect','customer-comms'),('titan-ledger','receivables')],
    'titan.realestate.settlement': [('crm','documents'),('titan-knowledge-authority','knowledge'),('titan-connect','customer-comms')],
    'titan.realestate.viewing': [('crm','customer'),('titan-maps-intelligence','location'),('titan-connect','customer-comms')],
    'titan.records.reporting': [('titan-knowledge-authority','knowledge'),('titan-ai-core','planning'),('titan-model-council','deliberation'),('titan-ledger','finance'),('crm','analytics')],
    'titan.rental.availability_planner': [('titan-assets','fleet'),('titan-locker','inventory'),('titan-maps-intelligence','location')],
    'titan.rental.damage_assessment': [('titan-assets','inspection'),('titan-ai-vision','inspection'),('titan-financial-engine','asset-cost')],
    'titan.rental.turnaround': [('titan-assets','fleet'),('titan-field','maintenance'),('titan-locker','inventory')],
    'titan.sales.business_development_coordinator': [('crm','sales'),('titan-connect','customer-comms'),('titan-financial-engine','commercial')],
    'titan.sales.commercial_accounts_coordinator': [('crm','sales'),('titan-financial-engine','commercial'),('titan-ledger','commercial'),('titan-connect','customer-comms')],
    'titan.sales.sales_coordinator': [('crm','sales'),('titan-connect','customer-comms')],
    'titan.sales.tender_bid': [('crm','sales'),('titan-knowledge-authority','knowledge'),('titan-financial-engine','pricing'),('titan-connect','customer-comms')],
    'titan.salon.appointment_allocator': [('crm','booking'),('titan-time-attendance','roster'),('titan-maps-intelligence','location')],
    'titan.salon.membership': [('crm','customer'),('titan-ledger','receivables'),('titan-connect','customer-comms')],
    'titan.work.deputy_manager': [('titan-field','service'),('titan-maps-intelligence','dispatch'),('titan-connect','team-comms')],
    'titan.work.emergency_service_coordinator': [('titan-field','dispatch'),('titan-maps-intelligence','dispatch'),('titan-connect','customer-comms')],
    'titan.work.handover_coordinator': [('titan-field','completion'),('titan-ai-vision','quality'),('titan-knowledge-authority','knowledge')],
    'titan.work.job_completion_coordinator': [('titan-field','completion'),('titan-ai-vision','quality'),('titan-shield','compliance')],
    'titan.work.maintenance_coordinator': [('titan-field','maintenance'),('titan-assets','assets'),('titan-locker','inventory')],
    'titan.work.operations_coordinator': [('titan-field','service'),('titan-maps-intelligence','dispatch'),('titan-connect','team-comms')],
    'titan.work.project_coordinator': [('titan-field','project'),('titan-maps-intelligence','location'),('titan-knowledge-authority','knowledge')],
    'titan.work.project_manager': [('titan-field','project'),('titan-maps-intelligence','location'),('titan-financial-engine','costing'),('titan-connect','customer-comms')],
    'titan.work.recurring_services_coordinator': [('crm','booking'),('titan-field','service'),('titan-connect','customer-comms')],
}

# Deliberate supplements to existing role bindings.
SUPPLEMENT: dict[str, list[tuple[str, str]]] = {
    'titan.manager.operations': [('titan-signal-engine','observe'),('titan-governance','oversight'),('titan-prime','missions')],
    'titan.manager.customer_service': [('titan-interaction-engine','interaction')],
    'titan.manager.sales': [('titan-financial-engine','commercial'),('titan-connect','customer-comms')],
    'titan.manager.finance': [('crm','finance')],
    'titan.manager.workforce': [('titan-shield','compliance'),('titan-knowledge-authority','knowledge')],
    'titan.manager.assets': [('titan-locker','inventory'),('titan-financial-engine','asset-cost')],
    'titan.manager.business_intelligence': [('crm','analytics'),('titan-ledger','finance'),('titan-field','service')],
    'titan.manager.compliance_governance': [('titan-governance','oversight'),('titan-assurance','assurance'),('titan-risk-engine','risk')],
    'titan.governance.assurance_coordinator': [('titan-assurance','assurance'),('titan-governance','oversight')],
    'titan.manager.procurement_supply': [('titan-financial-engine','inventory-cost'),('titan-ledger','payables')],
    'titan.manager.records_data': [('titan-nexus','configuration')],
    'titan.customer.booking_coordinator': [('titan-connect','customer-comms')],
    'titan.work.scheduler': [('titan-field','service')],
    'titan.work.work_planner': [('titan-field','service')],
    'titan.money.accounts_receivable_officer': [('titan-financial-engine','receivables')],
    'titan.money.billing_coordinator': [('titan-financial-engine','receivables')],
    'titan.money.accounts_payable_officer': [('titan-financial-engine','receivables')],
    'titan.money.bookkeeper': [('titan-financial-engine','receivables')],
    'titan.executive.business_manager': [('titan-signal-engine','observe'),('titan-governance','oversight')],
    'titan.operations.chief_of_staff': [('titan-ai-core','planning'),('titan-signal-engine','observe')],
    'titan.operations.executive_assistant': [('crm','business-admin'),('titan-interaction-engine','interaction')],
    'titan.operations.strategy_coordinator': [('titan-ai-core','planning'),('titan-model-council','deliberation')],
}

# Profiles for providers where existing migration bindings reference explicit capability names.
PROFILES.setdefault('titan-forge', {})['automation'] = {'cap': [r'^forge\.(build\.inspect|scaffold\.workforce|validate\.|signal\.lifecycle|ai\.plan\.consume|rewind\.source|release\.)'] , 'signal':[r'^forge\.'], 'workflow':[r'^forge\.']}

COORDINATION_PROVIDERS = [
    'titan-ai','titan-ai-core','titan-interaction-engine','titan-model-council','titan-prime',
    'titan-signal-engine','titan-risk-engine','titan-assurance','titan-governance','titan-autonomy',
    'titan-command-bus','titan-rewind','titan-wisdom',
]

SECTIONS = ['capabilities','tools','commands','signals','data_sources','workflows']


def ids(items):
    out=[]
    for item in items or []:
        if not isinstance(item,dict): continue
        ident=str(item.get('id') or item.get('name') or item.get('workflow_id') or '').strip()
        if ident: out.append(ident)
    return out


def select(provider: dict, profile_name: str) -> dict:
    provider_key=provider['extension']['key']
    try: profile=PROFILES[provider_key][profile_name]
    except KeyError: raise RuntimeError(f'missing profile {provider_key}:{profile_name}')
    cap_patterns=[re.compile(p) for p in profile.get('cap',[])]
    selected_caps=[]
    for cap in provider.get('capabilities',[]):
        cid=str(cap.get('id') or cap.get('name') or '')
        if cid and any(rx.search(cid) for rx in cap_patterns): selected_caps.append(cid)
    selected_caps=sorted(set(selected_caps))
    if not selected_caps: raise RuntimeError(f'profile selected zero capabilities: {provider_key}:{profile_name}')
    capset=set(selected_caps)
    result={'capabilities':selected_caps,'tools':[],'commands':[],'signals':[],'data_sources':[],'workflows':[]}
    for section in ['tools','commands','data_sources']:
        chosen=[]
        for item in provider.get(section,[]):
            iid=str(item.get('id') or item.get('name') or '')
            icap=str(item.get('capability') or '')
            if iid in capset or icap in capset: chosen.append(iid)
        result[section]=sorted(set(x for x in chosen if x))
    for section,key in [('signals','signal'),('workflows','workflow')]:
        pats=[re.compile(p) for p in profile.get(key,[])]
        if pats:
            result[section]=sorted(set(i for i in ids(provider.get(section,[])) if any(rx.search(i) for rx in pats)))
    return result


def merge_binding(target: dict, incoming: dict, basis: str, profile: str | None=None):
    for sec in SECTIONS:
        target.setdefault(sec,[])
        target[sec]=sorted(set(target[sec]) | set(incoming.get(sec,[])))
    target['authority_inherited']=False
    target['runtime_availability_requires_installed_provider']=True
    bases=set(target.get('binding_basis',[])); bases.add(basis); target['binding_basis']=sorted(bases)
    profiles=set(target.get('selection_profiles',[]))
    if profile: profiles.add(profile)
    target['selection_profiles']=sorted(profiles)


def main():
    registry=json.load(open(REGISTRY))
    providers={p['extension']['key']:p for p in registry['providers']}
    role_defs=[]
    scope_files=[('INTRINSIC','role-definitions.json'),('EXECUTIVE','executive-role-definitions.json'),('SYSTEM','system-role-definitions.json')]
    scope_by_id={}
    for scope,file in scope_files:
        data=json.load(open(ROOT/'resources/workforce'/file))
        for r in data:
            role_defs.append(r);scope_by_id[r['role_definition_id']]=scope
    roles_by_id={r['role_definition_id']:r for r in role_defs}
    existing: dict[str, dict[str, dict]]={rid:{} for rid in roles_by_id}
    for pkey,p in providers.items():
        for b in p.get('role_bindings',[]):
            rid=str(b.get('role_definition_id') or '')
            if rid not in roles_by_id: continue
            tgt=existing[rid].setdefault(pkey, {'provider':pkey,'provider_version':p['extension']['version']})
            merge_binding(tgt,b,'provider_declared_binding')
    for mapping,basis in [(EXTRA,'workforce_composition'),(SUPPLEMENT,'workforce_supplement')]:
        for rid,refs in mapping.items():
            if rid not in roles_by_id: raise RuntimeError(f'unknown role in mapping: {rid}')
            for pkey,profile in refs:
                if pkey not in providers: raise RuntimeError(f'unknown provider in mapping: {pkey}')
                tgt=existing[rid].setdefault(pkey, {'provider':pkey,'provider_version':providers[pkey]['extension']['version']})
                merge_binding(tgt,select(providers[pkey],profile),basis,profile)
    rows=[]
    provider_binding_count=0; multi=0; surface_counts={s:0 for s in SECTIONS}
    for role in sorted(role_defs,key=lambda r:r['role_definition_id']):
        rid=role['role_definition_id']; scope=scope_by_id[rid]
        bindings=[]
        if rid!='titan.system.titan_zero':
            for pkey,b in sorted(existing[rid].items()):
                b['provider']=pkey;b['provider_version']=providers[pkey]['extension']['version'];b['authority_inherited']=False;b['runtime_availability_requires_installed_provider']=True
                bindings.append(b)
                provider_binding_count+=1
                for sec in SECTIONS: surface_counts[sec]+=len(b.get(sec,[]))
            if not bindings: raise RuntimeError(f'non-system role has no provider binding: {rid}')
            if len(bindings)>1: multi+=1
        row={
            'role_definition_id':rid,'role_name':role['name'],'scope':scope,
            'division_definition_id':role.get('division_definition_id'),'division_key':role.get('division_key'),'team_key':role.get('team_key'),
            'responsibility_ids':role.get('responsibility_ids',[]),
            'provider_bindings':bindings,
            'coordination_providers':COORDINATION_PROVIDERS if rid=='titan.system.titan_zero' else [],
            'authority_inherited':False,'execution_authority_granted':False,
            'runtime_availability_requires_installed_provider':True,
            'governance_path':'Risk -> Assurance -> Governance -> Autonomy -> Command Bus',
            'matrix_ownership':'titan-ai-workforce',
        }
        rows.append(row)
    matrix={
        'schema_version':'1.0','generated_at':'2026-08-22T04:46:00+10:00','organisation_owner':'titan-ai-workforce','tenant_key':'company_id',
        'provider_catalogue':'resources/workforce/ecosystem-capability-registry.json',
        'parent_artifact':{'plan_id':'d11af135-ee2a-44dd-8eae-bb2234b64a55','step_id':'step-02','sha256':'fe03531266b0dcaa9e1cec9a14a04822a7eb8875753f42249eba7303bf4feda1'},
        'safety':{
            'matrix_grants_execution_authority':False,'authority_inherited':False,'installed_provider_required':True,
            'titan_zero_domain_capability_bindings':False,'risk_bypass':False,'assurance_bypass':False,'governance_bypass':False,'autonomy_bypass':False,
        },
        'summary':{
            'role_count':len(rows),'intrinsic_role_count':111,'executive_role_count':1,'system_role_count':1,
            'provider_binding_count':provider_binding_count,'multi_provider_role_count':multi,'provider_count':len(providers),
            'roles_without_domain_provider_bindings':1,'surface_reference_counts':surface_counts,
        },
        'roles':rows,
    }
    OUT.write_text(json.dumps(matrix,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(matrix['summary'],indent=2))

if __name__=='__main__': main()
