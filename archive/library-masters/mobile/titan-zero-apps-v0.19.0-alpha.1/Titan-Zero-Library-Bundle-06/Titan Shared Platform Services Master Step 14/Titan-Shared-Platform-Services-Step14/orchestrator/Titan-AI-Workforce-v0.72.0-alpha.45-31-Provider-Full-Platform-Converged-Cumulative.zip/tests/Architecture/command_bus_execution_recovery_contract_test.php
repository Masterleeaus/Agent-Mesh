<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$intentPath = $root.'/System/Services/WorkforceExecutionIntentService.php';
$receiptPath = $root.'/System/Support/WorkforceExecutionReceipt.php';
$verificationPath = $root.'/System/Services/WorkforcePostActionVerificationService.php';
$recoveryPath = $root.'/System/Services/WorkforceExecutionRecoveryService.php';
$attemptModelPath = $root.'/System/Models/WorkforceExecutionAttempt.php';
$executionPath = $root.'/System/Services/WorkforceExecutionService.php';
$bridgePath = $root.'/System/Services/WorkforceGovernanceBridge.php';
$migrationPath = $root.'/database/migrations/2026_08_20_000008_create_workforce_execution_attempts.php';
$providerPath = $root.'/System/TitanAIWorkforceServiceProvider.php';
$catalogPath = $root.'/System/Support/WorkforceCapabilityCatalog.php';
$docsPath = $root.'/docs/PASS13-COMMAND-BUS-EXECUTION-RECOVERY.md';

foreach ([$intentPath,$receiptPath,$verificationPath,$recoveryPath,$attemptModelPath,$migrationPath,$docsPath] as $path) {
    $assert(is_file($path), 'missing Pass 13 file: '.basename($path));
}

if (is_file($receiptPath)) {
    require_once $receiptPath;
    $class = 'App\\Extensions\\TitanAIWorkforce\\System\\Support\\WorkforceExecutionReceipt';
    $expected = [
        'company_id' => 7,
        'task_id' => 'task-1',
        'capability' => 'crm.invoice.issue',
        'intent_id' => 'intent-1',
        'intent_sha256' => str_repeat('a', 64),
        'idempotency_key' => 'wfexec:abc',
    ];
    $receipt = [
        'receipt_id' => 'receipt-1',
        'company_id' => 7,
        'task_id' => 'task-1',
        'capability' => 'crm.invoice.issue',
        'intent_id' => 'intent-1',
        'intent_sha256' => str_repeat('a', 64),
        'idempotency_key' => 'wfexec:abc',
        'status' => 'SUCCEEDED',
        'executed_at' => '2026-08-20T22:00:00+10:00',
    ];
    try {
        $checked = $class::validate($receipt, $expected);
        $assert(($checked['receipt_id'] ?? null) === 'receipt-1', 'valid receipt must preserve receipt id');
    } catch (Throwable $e) {
        $assert(false, 'valid execution receipt must validate: '.$e->getMessage());
    }
    $bad = $receipt;
    $bad['company_id'] = 8;
    try {
        $class::validate($bad, $expected);
        $assert(false, 'cross-tenant receipt must be rejected');
    } catch (Throwable) {}
}

$intent = @file_get_contents($intentPath) ?: '';
foreach (['state_fingerprint','intent_sha256','idempotency_key','lockForUpdate','STATE_CHANGED','canonical'] as $needle) {
    $assert(str_contains($intent, $needle), 'execution intent service missing '.$needle);
}
$assert(str_contains($intent, 'findOwnedCapability'), 'execution intent must bind the current extension-owned capability definition');

$execution = @file_get_contents($executionPath) ?: '';
foreach (['WorkforceExecutionIntentService','WorkforceExecutionReceipt','WorkforcePostActionVerificationService','WorkforceExecutionRecoveryService','execution.intent_locked','execution.receipt_invalid','execution.verification_failed','execution.recovered'] as $needle) {
    $assert(str_contains($execution, $needle), 'execution service missing '.$needle);
}
$assert(str_contains($execution, 'stateRevalidation'), 'execution must perform pre-dispatch state revalidation');
$assert(str_contains($execution, 'idempotency_key'), 'execution must send a stable Command Bus idempotency key');

$bridge = @file_get_contents($bridgePath) ?: '';
foreach (['intent_id','intent_sha256','state_fingerprint','idempotency_key','expected_state'] as $needle) {
    $assert(str_contains($bridge, $needle), 'Command Bus envelope missing '.$needle);
}

$verification = @file_get_contents($verificationPath) ?: '';
foreach (['verifyReceipt','post_action_verification','VERIFICATION_REQUIRED','domain_state_ref','verified'] as $needle) {
    $assert(str_contains($verification, $needle), 'post-action verification service missing '.$needle);
}
$assert(! str_contains($verification, 'CRM\\'), 'post-action verification must not query CRM models directly');

$recovery = @file_get_contents($recoveryPath) ?: '';
foreach (['reconcileReceipt','compensate','RECOVERY_REQUIRED','compensation_ref','receipt_ref'] as $needle) {
    $assert(str_contains($recovery, $needle), 'execution recovery service missing '.$needle);
}

$migration = @file_get_contents($migrationPath) ?: '';
foreach (['ext_titan_ai_workforce_execution_attempts','intent_id','intent_sha256','state_fingerprint','idempotency_key','receipt_ref','receipt_sha256','verification_status','compensation_ref'] as $needle) {
    $assert(str_contains($migration, $needle), 'execution attempt migration missing '.$needle);
}
$assert(str_contains($migration, 'dropIfExists'), 'execution-attempt migration must be reversible');

$provider = @file_get_contents($providerPath) ?: '';
$assert(str_contains($provider, "'titan.workforce.execution'"), 'stable Pass 13 execution adapter missing');
$assert(str_contains($provider, "'titan.workforce.execution-recovery'"), 'stable Pass 13 recovery adapter missing');

$catalog = @file_get_contents($catalogPath) ?: '';
foreach (['workforce.execution.dispatch','workforce.execution.recover','workforce.execution.verify'] as $needle) {
    $assert(str_contains($catalog, $needle), 'capability catalogue missing '.$needle);
}

$manifest = json_decode((string) file_get_contents($root.'/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$assert(in_array('titan-workforce.command-bus-execution-v2', $manifest['capabilities'] ?? [], true), 'sidecar missing Pass 13 execution capability');

$docs = @file_get_contents($docsPath) ?: '';
foreach (['state revalidation','intent lock','idempotency','receipt','uncertain','post-action verification','compensation','fail closed'] as $needle) {
    $assert(str_contains(strtolower($docs), strtolower($needle)), 'Pass 13 docs missing '.$needle);
}

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce Command Bus execution/recovery contract\n";
