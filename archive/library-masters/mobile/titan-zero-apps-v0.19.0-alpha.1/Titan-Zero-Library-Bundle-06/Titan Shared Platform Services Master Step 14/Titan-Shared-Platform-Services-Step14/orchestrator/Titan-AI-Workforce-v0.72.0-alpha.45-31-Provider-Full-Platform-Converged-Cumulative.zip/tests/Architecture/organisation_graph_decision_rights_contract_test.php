<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$graphPath = $root.'/System/Services/WorkforceGraphService.php';
$continuityPath = $root.'/System/Services/ManagerContinuityService.php';
$decisionPath = $root.'/System/Services/WorkforceDecisionRightsService.php';
$registryPath = $root.'/System/Support/WorkforceManifestRegistry.php';
$validatorPath = $root.'/System/Support/WorkforceManifestValidator.php';
$delegationPath = $root.'/System/Services/WorkforceDelegationService.php';
$escalationPath = $root.'/System/Services/WorkforceEscalationService.php';
$controllerPath = $root.'/System/Http/Controllers/WorkforceController.php';
$providerPath = $root.'/System/TitanAIWorkforceServiceProvider.php';
$permissionsPath = $root.'/System/Support/WorkforcePermissions.php';
$catalogPath = $root.'/System/Support/WorkforceCapabilityCatalog.php';
$policyPath = $root.'/resources/workforce/organisation-policies.json';
$docsPath = $root.'/docs/PASS08-ORGANISATIONAL-GRAPH-DECISION-RIGHTS.md';

foreach ([$graphPath,$continuityPath,$decisionPath,$registryPath,$validatorPath,$delegationPath,$escalationPath,$docsPath] as $path) {
    $assert(is_file($path), 'missing Pass 8 file: '.basename($path));
}

$graph = @file_get_contents($graphPath) ?: '';
foreach (['assertNoReportingCycle','setManager','snapshot','deactivateRelationship'] as $method) {
    $assert(str_contains($graph, "function {$method}"), "graph service missing {$method}");
}
$assert(str_contains($graph, 'REPORTING_CYCLE'), 'reporting-cycle rejection reason must be explicit');
$assert(str_contains($graph, 'authority_inherited'), 'organisational graph must enforce no authority inheritance on delegation/substitution');
$assert(str_contains($graph, 'manager_id'), 'setManager must keep member.manager_id synchronized with graph relationships');

$continuity = @file_get_contents($continuityPath) ?: '';
$assert(str_contains($continuity, 'Deputy scope is required'), 'deputy assignment must require explicit scope');
$assert(str_contains($continuity, 'Deputy expiry is required'), 'deputy assignment must require expiry');
$assert(str_contains($continuity, 'authority_inherited'), 'deputy relationship must explicitly deny authority inheritance');
$assert(str_contains($continuity, 'requires_existing_autonomy'), 'deputy must use its own pre-existing Autonomy');

$registry = @file_get_contents($registryPath) ?: '';
foreach (['decisionRights','relationships','findDecisionRight'] as $method) {
    $assert(str_contains($registry, "function {$method}"), "manifest registry missing {$method}");
}
$assert(str_contains($registry, 'owner_extension'), 'manifest RACI/relationship records must preserve owning extension');

$validator = @file_get_contents($validatorPath) ?: '';
$assert(str_contains($validator, 'RACI responsible references unknown role'), 'validator must reject unknown responsible RACI role refs');
$assert(str_contains($validator, 'RACI accountable must contain exactly one role'), 'validator must require exactly one accountable role');
$assert(str_contains($validator, 'relationship creates reporting cycle'), 'manifest validator must reject reporting cycles');

$decision = @file_get_contents($decisionPath) ?: '';
foreach (['decision','assertParticipant','resolveAccountableMember'] as $method) {
    $assert(str_contains($decision, "function {$method}"), "decision rights service missing {$method}");
}
$assert(str_contains($decision, 'RACI does not confer execution authority'), 'decision rights must state that RACI cannot confer execution authority');
$assert(str_contains($decision, 'role_owner_extension'), 'decision participation must bind to extension ownership');
$assert(str_contains($decision, 'role_definition_id'), 'decision participation must bind to exact RoleDefinition');

$escalation = @file_get_contents($escalationPath) ?: '';
foreach (['commonManager','chainFor','resolveDisputeManager'] as $method) {
    $assert(str_contains($escalation, "function {$method}"), "escalation service missing {$method}");
}
$assert(str_contains($escalation, 'HUMAN_DECISION_REQUIRED'), 'unresolvable organisational disputes must fail closed to human decision');

$delegation = @file_get_contents($delegationPath) ?: '';
$assert(str_contains($delegation, 'Cross-division delegation requires a governed handoff'), 'delegation service must reject cross-division direct delegation');
$assert(str_contains($delegation, 'delegates_to'), 'delegation must record an explicit delegates_to relationship');
$assert(str_contains($delegation, 'authority_inherited'), 'delegation relationship must not inherit authority');

$controller = @file_get_contents($controllerPath) ?: '';
foreach (['apiOrganisationGraph','apiDecisionRights','appointDeputy','setStaffManager'] as $method) {
    $assert(str_contains($controller, "function {$method}"), "controller missing {$method}");
}

$provider = @file_get_contents($providerPath) ?: '';
foreach (['api/organisation-graph','api/decision-rights','staff/{member}/manager','staff/{member}/deputy'] as $route) {
    $assert(str_contains($provider, $route), "provider missing Pass 8 route {$route}");
}
$assert(str_contains($provider, "'titan.workforce.organisation-graph'"), 'stable organisation graph adapter missing');
$assert(str_contains($provider, "'titan.workforce.decision-rights'"), 'stable decision rights adapter missing');
$assert(str_contains($provider, "'titan.workforce.escalation'"), 'stable escalation adapter missing');

$permissions = @file_get_contents($permissionsPath) ?: '';
$assert(str_contains($permissions, 'titan-workforce.organisation.manage'), 'organisation mutation permission missing');

$catalog = @file_get_contents($catalogPath) ?: '';
foreach (['workforce.organisation.read','workforce.organisation.manage','workforce.deputy.appoint','workforce.decision-right.read'] as $capability) {
    $assert(str_contains($catalog, $capability), "capability catalogue missing {$capability}");
}

$policy = json_decode((string) @file_get_contents($policyPath), true);
$assert(($policy['decision_rights_source'] ?? null) === 'canonical_workforce_policy_plus_extension_workforce_manifests', 'central policy must combine canonical Workforce decisions with extension manifests');
$assert(($policy['deputy_rules']['authority_inherited'] ?? null) === false, 'central deputy policy must forbid authority inheritance');
$assert(($policy['deputy_rules']['scope_required'] ?? null) === true, 'central deputy policy must require scope');
$assert(($policy['deputy_rules']['expiry_required'] ?? null) === true, 'central deputy policy must require expiry');

$sidecar = json_decode((string) file_get_contents($root.'/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
foreach (['titan-workforce.organisation-graph-v2','titan-workforce.decision-rights-v2','titan-workforce.deputy-scope-v2'] as $capability) {
    $assert(in_array($capability, $sidecar['capabilities'] ?? [], true), "sidecar missing {$capability}");
}

$docs = @file_get_contents($docsPath) ?: '';
$assert(str_contains($docs, 'Extension-owned RACI'), 'Pass 8 docs must explain extension-owned RACI');
$assert(str_contains($docs, 'no authority inheritance'), 'Pass 8 docs must document no authority inheritance');
$assert(str_contains($docs, 'HUMAN_DECISION_REQUIRED'), 'Pass 8 docs must document dispute termination');

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce organisational graph and decision rights contract\n";
