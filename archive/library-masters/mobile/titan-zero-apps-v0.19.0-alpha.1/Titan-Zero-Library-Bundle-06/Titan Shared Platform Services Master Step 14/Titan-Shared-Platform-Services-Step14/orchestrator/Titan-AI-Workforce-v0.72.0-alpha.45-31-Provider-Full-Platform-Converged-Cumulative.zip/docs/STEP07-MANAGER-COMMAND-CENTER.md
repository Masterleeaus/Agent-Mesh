# UI Step 7 — Manager Command Center

Titan AI Workforce now provides every Tier-1 manager with a dedicated, company-scoped operational workspace at `managers/{member}`.

## Operational sections

- My team and live staff availability
- Work awaiting review
- Escalations
- Handoffs received and sent
- Blocked work
- Workload imbalance
- Staffing recommendations
- Proactive responsibilities/schedules
- Verified team outcomes
- Division queue pressure

## Governed manager actions

The workspace routes actions through existing Workforce authority paths rather than creating a new execution plane:

- approve / request revision → chain-of-command manager review
- delegate → approved specialist work to an eligible internal Action Worker
- reassign → workload-sharing service with live capability/risk checks
- decompose → Manager Operations governed plan validation
- escalate → task transition plus persistent `WorkforceEscalation` record
- appoint deputy → Manager Continuity scoped, expiring substitute relationship
- resolve deadlock → existing deadlock resolution contract

## Safety invariants

- `company_id` remains the sole company boundary.
- Manager Command Center data is an operational projection, not an authority source.
- Capability availability, workload, hierarchy, deputy coverage and escalation do not grant execution authority.
- New escalation records explicitly persist `authority_inherited=false` metadata.
- Cross-company access and non-manager workspace access fail closed.
