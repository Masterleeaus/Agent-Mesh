#!/usr/bin/env python3
from __future__ import annotations
import json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
WF=ROOT/'resources/workforce'

def load(name): return json.loads((WF/name).read_text())
def dump(name,data): (WF/name).write_text(json.dumps(data,indent=2,sort_keys=False)+'\n')

FAMILIES={
 'executive':('Executive Leadership','Own business priorities, cross-functional coordination and accountable outcomes.'),
 'operations':('Business Operations','Coordinate the operating system of the business, exceptions, priorities and administrative flow.'),
 'customer':('Customer Experience','Own enquiries, bookings, customer care, recovery and retention outcomes.'),
 'sales':('Sales & Commercial Growth','Own lead progression, estimating, quoting, account growth and commercial conversion.'),
 'work':('Field & Service Operations','Plan, dispatch, coordinate, evidence and complete service delivery.'),
 'people':('People & Workforce','Own workforce availability, rostering, competence, safety and workforce compliance.'),
 'assets':('Assets, Fleet & Inventory','Own equipment, fleet, inventory, maintenance and operational resource readiness.'),
 'money':('Finance & Accounts','Own billing, receivables, payables, books, cost control and financial exceptions.'),
 'procurement':('Procurement & Supply','Own materials, suppliers, subcontractors and purchasing coordination.'),
 'marketing':('Marketing & Reputation','Own campaigns, reputation, referrals, reviews and customer reactivation.'),
 'governance':('Governance, Risk & Assurance','Own policy, risk, assurance, incidents, compliance and control effectiveness.'),
 'insights':('Intelligence & Analytics','Own analysis of customers, operations, revenue and business performance.'),
 'automation':('Automation & Systems','Own workflow automation, system integration, process improvement and automation quality.'),
 'records':('Knowledge, Records & Data','Own documents, knowledge, reporting, data governance and information integrity.'),
 'hospitality-realestate':('Hospitality & Property Operations','Own guest, tenancy, facilities, property and handover operations.'),
 'retail-rental':('Retail, Rental & Fulfilment','Own fulfilment, returns, shipping, availability, turnaround and membership/package operations.'),
 'system':('System Authority','Represent explicit platform/system authority without becoming an AI employee.'),
}

EXEC_IDS={'titan.executive.business_manager'}
SYSTEM_IDS={'titan.system.titan_zero'}

def family_for(role):
 rid=role['role_definition_id']
 if rid in EXEC_IDS: return 'executive'
 if rid in SYSTEM_IDS: return 'system'
 return role.get('division_key') or 'operations'

def level(role):
 rid=role['role_definition_id']; name=role.get('role_name','')
 if rid in SYSTEM_IDS:return 'system'
 if rid in EXEC_IDS:return 'executive'
 if '.manager.' in rid or ' Manager' in name:return 'manager'
 if 'Deputy' in name:return 'deputy-manager'
 if 'Analyst' in name:return 'specialist'
 if any(x in name for x in ['Officer','Bookkeeper','Estimator','Representative','Inspector','Receptionist']):return 'specialist'
 return 'coordinator'

def decision_scope(lvl):
 return {
  'system':'system-policy-only','executive':'cross-business','manager':'division','deputy-manager':'team','specialist':'responsibility','coordinator':'responsibility'
 }[lvl]

def primary_business_role(name):
 n=name.lower()
 if 'business manager' in n:return 'general-manager'
 if 'office manager' in n:return 'office-manager'
 if 'receptionist' in n:return 'receptionist'
 if 'customer service manager' in n:return 'customer-service-manager'
 if 'sales manager' in n:return 'sales-manager'
 if name=='Finance Manager':return 'finance-manager'
 if 'service manager' in n and 'deputy' not in n:return 'field-operations-manager'
 if 'workforce manager' in n:return 'workforce-manager'
 if 'assets manager' in n:return 'asset-manager'
 if 'compliance & governance manager' in n:return 'quality-compliance-manager'
 if 'marketing manager' in n:return 'marketing-manager'
 if 'records & data manager' in n:return 'knowledge-manager'
 return None

matrix=load('canonical-capability-binding-matrix.json')
roledefs={r['role_definition_id']:r for r in load('role-definitions.json')}
# supplement executive/system using matrix
for mr in matrix['roles']:
 if mr['role_definition_id'] not in roledefs:
  roledefs[mr['role_definition_id']]={
   'role_definition_id':mr['role_definition_id'],'name':mr['role_name'],'division_key':mr.get('division_key'),
   'responsibility_ids':mr.get('responsibility_ids',[]),'risk_ceiling':'CRITICAL' if 'business_manager' in mr['role_definition_id'] else 'NONE',
   'definition_scope':mr.get('scope','SYSTEM')
  }

families=[]
for key,(name,purpose) in FAMILIES.items():
 families.append({'family_id':f'titan.role-family.{key}','key':key,'name':name,'purpose':purpose,'identity_owner':'titan-ai-workforce','provider_neutral':True})

profiles=[]; reqs=[]
for mr in matrix['roles']:
 rid=mr['role_definition_id']; rd=roledefs[rid]; fam=family_for({'role_definition_id':rid,'division_key':mr.get('division_key')})
 lvl=level({'role_definition_id':rid,'role_name':mr['role_name']})
 providers=[]
 allcaps=[]; alltools=[]; allcmd=[]; allsignals=[]; allds=[]; allwf=[]
 for pb in mr.get('provider_bindings',[]):
  providers.append({'provider':pb['provider'],'provider_version':pb.get('provider_version'),'binding_basis':pb.get('binding_basis',[]),'authority_inherited':False})
  allcaps += pb.get('capabilities',[]); alltools += pb.get('tools',[]); allcmd += pb.get('commands',[]); allsignals += pb.get('signals',[]); allds += pb.get('data_sources',[]); allwf += pb.get('workflows',[])
 respids=mr.get('responsibility_ids',[])
 profiles.append({
  'role_definition_id':rid,'role_name':mr['role_name'],'role_family_id':f'titan.role-family.{fam}','role_level':lvl,
  'business_role_key':primary_business_role(mr['role_name']),'decision_scope':decision_scope(lvl),
  'responsibility_ids':respids,'identity_owner':'titan-ai-workforce','provider_neutral_identity':True,
  'provider_count':len(providers),'provider_candidates':providers,
  'authority_model':{'role_identity_grants_execution_authority':False,'provider_installation_grants_authority':False,'capability_authority_resolved_separately':True},
  'expected_outcome_ownership':'workforce','execution_ownership':'resolved-provider'
 })
 for respid in respids:
  # Requirements are candidate surfaces, never an authority grant or exact routing decision.
  reqs.append({
   'responsibility_id':respid,'role_definition_id':rid,'role_family_id':f'titan.role-family.{fam}',
   'requirement_semantics':'provider-neutral-candidate-set','tenant_key':'company_id',
   'required_surface_classes':([x for x,arr in [('capability',allcaps),('tool',alltools),('command',allcmd),('signal',allsignals),('data_source',allds),('workflow',allwf)] if arr]),
   'candidate_capabilities':sorted(set(allcaps)),'candidate_tools':sorted(set(alltools)),'candidate_commands':sorted(set(allcmd)),
   'candidate_signals':sorted(set(allsignals)),'candidate_data_sources':sorted(set(allds)),'candidate_workflows':sorted(set(allwf)),
   'candidate_providers':providers,'provider_selection_deferred_to':'deterministic-provider-routing-pass-3',
   'authority_inherited':False,'execution_authority_granted':False,
   'completion_contract':{'requires_expected_outcome':True,'requires_evidence':True,'requires_verification':True}
  })

model={
 'schema_version':'1.0','model':'titan-workforce-business-role-responsibility-model','organisation_owner':'titan-ai-workforce','tenant_key':'company_id',
 'principles':{
  'workforce_owns':['employee_identity','roles','role_families','responsibilities','reporting_lines','accountability','work_orchestration','outcomes'],
  'extensions_own':['domain_data','capabilities','tools','commands','signals','read_models','workflows','execution_implementation'],
  'role_names_must_not_encode_provider':True,'provider_installation_never_grants_role':True,'role_assignment_never_grants_execution_authority':True
 },
 'summary':{'role_families':len(families),'roles':len(profiles),'responsibility_requirements':len(reqs),'primary_business_roles':sum(1 for p in profiles if p['business_role_key'])},
 'role_families':families,'roles':profiles
}
requirements={'schema_version':'1.0','model':'titan-workforce-responsibility-capability-requirements','tenant_key':'company_id','authority_inherited':False,'requirements':reqs}
dump('business-role-responsibility-model.json',model)
dump('responsibility-capability-requirements.json',requirements)
print(json.dumps(model['summary'],indent=2))
