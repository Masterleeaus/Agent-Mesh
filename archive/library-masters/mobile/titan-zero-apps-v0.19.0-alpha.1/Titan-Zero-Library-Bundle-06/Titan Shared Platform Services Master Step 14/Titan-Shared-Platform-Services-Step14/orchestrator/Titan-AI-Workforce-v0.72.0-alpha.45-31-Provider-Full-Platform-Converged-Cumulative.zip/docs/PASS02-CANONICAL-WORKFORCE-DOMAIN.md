# Integrated Upgrade Pass 2 — Canonical Workforce Domain

Pass 2 establishes the final Workforce-owned organisational vocabulary and persistence boundary without restoring the intrinsic 15-division / 111-role catalogue yet.

## Ownership rule

**Workforce owns the organisation**: organisation, divisions, teams, roles, responsibilities, members, work items, actions, triggers, councils, delegation, handoffs, escalation, evidence, outcomes and performance. Installed business extensions contribute capabilities, tools, signals, data sources and execution surfaces; they do not define the company hierarchy.

## Canonical identity

- `company_id` is the sole company/tenant boundary.
- `role_definition_id` is the canonical role identity. Runtime code no longer falls back to a nonexistent `role_definition_key` or the human-readable `role` label.
- `workforce_member_id` is the autonomous AI employee identity.
- `user_id` is only a human actor/interface identity and is no longer copied from the activating human onto newly activated autonomous employees.
- `task_uuid` remains the durable Work Item identity; `WorkforceTask` remains the compatibility model name until later migration.
- `task.vertical` is the canonical Workforce vertical source. Legacy `metadata.vertical` values are backfilled once by migration and ignored by active authority decisions afterward.
- `task.workflow_ref` is the canonical workflow reference. Legacy metadata references are backfilled once.

## Additive canonical tables

Pass 2 adds empty first-class stores for organisation, role definitions, responsibilities, role/responsibility links, actions, triggers, councils/memberships, delegations, escalations, evidence, outcomes and performance metrics. Later passes populate or activate those stores.

Existing task, schedule, handoff, execution-attempt and journey records remain valid. `task` maps to canonical `work_item`; `schedule` maps to canonical `trigger` during the compatibility window.

## Behaviour boundary

This pass does not restore or activate the 111 intrinsic employees, 15 divisions, scheduled routines, event routines or councils. It only establishes their final domain and identity contracts so later passes can populate them without another schema redesign.
