# Titan Extension Workforce Manifest Contract 2.0

Titan AI Workforce is the central **discovery and organisational orchestration runtime**. Capability-owning extensions remain the source of truth for their own Managers, Specialists, Action Workers, capabilities, tools, skills, playbooks, workflows, Wizards and proactive responsibilities.

Canonical contributions use `resources/workforce/workforce-manifest.json`, `schema_version: 2.0`, and the `titan-workforce.manifests` contribution registry.

## Canonical 2.0 contract

A manifest declares its extension ownership and runtime ports, divisions/teams, Tier 1–3 role definitions, explicit organisational relationships, structured capability contracts, tools/skills/playbooks, Interaction workflows/Wizards, proactive schedules and Signal triggers, RACI, governance, offline policy and Workforce Planning rules.

Continuous Autonomy is declared as 0–100 desired and initial earned ceilings. **Runtime effective authority is never authored by the extension or Titan AI Workforce**; it is supplied by Titan Autonomy for the exact capability/variant/context. Predictive readiness is also external and never grants unlimited mutation authority.

## Legacy 1.1 compatibility

Schema `1.1` is accepted only through `WorkforceManifestNormalizer`. Named levels map conservatively to the floor of the equivalent band:

- Suggest → 0
- Assist → 16
- Semi-Auto → 31
- Auto → 51
- Trusted Auto → 71

The normaliser never creates Predictive authority and never maps a legacy role above the floor of its old band. Schema `1.0` is not silently guessed or promoted.

## Validation and quarantine

Each contributor is validated independently. Invalid manifests are marked `QUARANTINED`, omitted from the activatable role registry and surfaced through `titan.workforce.manifest-health` / `api/manifest-health`. A broken extension therefore cannot poison valid Workforce discovery from other extensions.

Validation includes:

- role → division/team/reporting references;
- role → capability/tool/skill/playbook/workflow/Wizard references;
- tool → capability ownership and Command Bus mutation boundary;
- continuous Autonomy score/band consistency;
- initial earned ceiling not exceeding the desired ceiling;
- Titan Autonomy ownership of effective authority and predictive readiness;
- proactive schedule/Signal role references;
- no proactive direct business mutation;
- external Titan Risk/Assurance/Autonomy/Signal/Command Bus/Rewind/Wisdom/Knowledge Authority/Shield authority;
- no self-approval, direct domain writes, auto-seeding or auto-activation;
- trace/correlation/causation/tenant context requirements.

## Provenance

Every accepted role receives central compatibility metadata without changing the extension-owned definition:

- `owner_extension`
- `owner_extension_version`
- `definition_version`
- `definition_fingerprint`
- `definition_schema_version`
- `definition_source_schema_version`

The fingerprint is deterministic over the source role definition. Lifecycle pinning/history semantics are completed in Production Upgrade Pass 4.

## Ownership invariant

Disabling/removing an extension removes its definitions from live discovery but must never rewrite historical Workforce tasks, handoffs, receipts or provenance. Titan AI Workforce does not copy domain definitions into a second canonical catalogue.
