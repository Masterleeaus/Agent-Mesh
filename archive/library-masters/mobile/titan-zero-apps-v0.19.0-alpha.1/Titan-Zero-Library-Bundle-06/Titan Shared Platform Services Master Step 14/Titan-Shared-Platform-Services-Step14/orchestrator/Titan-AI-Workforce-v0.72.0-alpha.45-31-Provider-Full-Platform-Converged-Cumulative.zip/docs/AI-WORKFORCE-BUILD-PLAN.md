# Titan AI Workforce — Cumulative Build Plan

## Extension-owned workforce manifests — current source of truth

**Titan AI Workforce no longer bundles or installs domain staff definitions.** Every functional Titan extension owns and ships the Workforce manifest for the roles, skills, tools, workflows, wizards, prompts, signals and capabilities that belong to its domain. The central Workforce extension discovers those manifests through the `titan-workforce.manifests` registry (with container-binding discovery as a compatibility fallback), validates them, records provenance, and provides organisation, task, queue, chain-of-command, planning and Control Room services over the aggregated catalogue.

The earlier **111-role reference catalogue** remains below as the canonical coverage/organisation plan, but those definitions must be supplied by the appropriate owning extensions (CRM, Connect, Time & Attendance, Finance, Maps, Marketing, Rental, Hospitality, etc.). It is **reference architecture, not installed role data**. Likewise, generic Tier-3 Action Workers are no longer bundled centrally; each capability-owning extension supplies its own Action Workers/agents where required.

The Time & Attendance pattern is canonical: `resources/workforce/workforce-manifest.json` remains extension-owned, the extension contributes a manifest provider to `titan-workforce.manifests`, and Titan AI Workforce becomes the central discovery/orchestration layer.

## Scope boundary

Titan AI Workforce owns the organisational runtime only: manifest discovery/validation, instantiated divisions/teams/members, reporting relationships, staff tasks, queues, contributed proactive schedules, handoffs, workload sharing, decision rights, councils, maturity and workforce planning. Role/skill/tool/workflow definitions remain source-of-truth in the capability-owning extensions. Titan Risk, Assurance, Autonomy, Signal, Command Bus, Council, Wisdom, Rewind, Knowledge, Shield, Forge, Nexus, Prime and Vertical Engine remain external engines consumed through adapters.
## Completed foundation

- BlogPilot transformed into a slim Workforce extension shell.
- 20-stage Employee Builder.
- Persistent divisions, teams, members, relationships, tasks, dependencies, handoffs, history, schedules and signal outbox.
- Maker → Manager → receiving Manager → receiving Specialist chain.
- Tier-3 Action Worker orchestration and fail-closed governed execution; Action Worker definitions are extension-owned.
- Proactive schedule/event task creation.
- Explicit legacy BlogPilot import adapter; no automatic tenant inference.
## Pass sequence

1. **Foundation / Slimming — COMPLETE:** remove BlogPilot product bulk, canonical role registry, tenant-safe compatibility.
2. **Organisation Intelligence — COMPLETE:** maturity, workload sharing, deputies, councils, RACI/dispute rules, Workforce Planning recommendations.
3. **Manager Operations — COMPLETE:** deterministic manager plans, reporting-line validation, specialist assignment/reassignment, dependency DAGs, deputy review continuity, cross-division child-task handoffs, council/dispute objectives and manager queues.
4. **Proactive Divisions — COMPLETE:** default role schedules/triggers/playbooks, vertical activation packs, workload thresholds, starvation/SLA monitoring.
5. **Governed Execution Integration — COMPLETE:** deeper Risk/Assurance/Autonomy/Signal/Interaction/Command Bus receipts and Rewind/Wisdom references without duplicating engines.
6. **Control Room & Certification — COMPLETE:** live organisational graph, queue/trust health, governed staffing recommendations, performance/maturity evidence, handoffs/reviews, Rewind/Wisdom references, and final Workforce-side cross-extension acceptance matrix.

## Pass 3 Manager Operations

Manager objectives now become structured `workforce_plan` graphs rather than free-form delegation. Each plan step must name a registered Tier-2 role and a capability owned by that role, stay within the Manager's division/reporting line, declare dependencies, and explicitly define any later cross-division handoff. Dependency cycles are rejected before task creation.

Assignment is policy-based: active role match, capability match, sufficient role risk ceiling and available concurrent capacity. Missing capacity produces a blocked staffing-gap task rather than silently assigning work elsewhere. Reassignment remains same-division by default and never transfers authority.

Cross-division work is chain-of-custody safe: the originating specialist task is reviewed by its Manager, a receiving Manager independently accepts or returns the handoff, and acceptance creates a **new child task** in the receiving division using its own role/capability. The originating task is then completed as transferred work; it is never mutated into another division's task.

Deputies use persisted `substitutes_for` relationships with scope and expiry. A deputy can review only while the assigned Manager is unavailable, and `authority_inherited=false` is enforced. Daily/weekly councils and dispute escalation create ordinary governed objectives; neither creates a shortcut around Risk, Assurance, Autonomy, Interaction or Command Bus.

## Workforce Planning

Workforce Planning is recommendation-only inside AI Workforce. It detects sustained queue depth, SLA breach rate, manager utilisation, coverage gaps and vertical fit; recommends role activation; and requires an authorised user or governed Nexus/Forge provisioning policy before activation. No role may self-hire or self-promote.
## Organisation policies

- Maturity: JUNIOR → STANDARD → SENIOR → LEAD; promotion uses Assurance/Wisdom/Autonomy evidence and cannot be self-granted.
- Workload sharing: same-division only by default; capability, risk ceiling and autonomy must remain valid; authority never transfers merely because work is reassigned.
- Deputies: scoped/expiring delegation only.
- Daily Ops Council and Weekly Performance Review create governed work; meetings do not confer execution authority.
- RACI and dispute routes are explicit machine-readable policy.
## 111-role reference catalogue (not bundled; supplied by owning extensions)

### Assets
- **Assets Manager** (`titan.manager.assets`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Run tools, equipment, fleet and inventory operations.
- **Asset Maintenance Coordinator** (`titan.assets.asset_maintenance_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Track maintenance schedules for business assets.
- **Equipment Coordinator** (`titan.assets.equipment_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Track tools, equipment condition, assignment, inspection and servicing.
- **Fleet Coordinator** (`titan.assets.fleet_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Coordinate vehicles, servicing, registration, assignment and defects.
- **Inventory Coordinator** (`titan.assets.inventory_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Monitor stock, consumables, van stock and reorder points.
- **Purchasing Officer** (`titan.assets.purchasing_officer`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Coordinate supplier purchasing requirements.

### Automation
- **Automation Manager** (`titan.manager.automation`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Run business automations and supervise automated workflows.
- **Automation Quality Coordinator** (`titan.automation.automation_quality_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Review automation outcomes, loops, failures and unintended behaviour.
- **Process Improvement Coordinator** (`titan.automation.process_improvement_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Identify recurring manual work and propose governed automation.
- **Systems Integration Coordinator** (`titan.automation.integration_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **SOLO**; verticals: all. Monitor external system connections, API/webhook failures, data synchronization and integration diagnostics.
- **Workflow Coordinator** (`titan.automation.workflow_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Create, monitor and repair operational workflows.
- **Workflow Performance Coordinator** (`titan.automation.workflow_performance`) — Tier 2; risk ceiling **MEDIUM**; min business tier **GROWING**; verticals: all. Monitor workflow duration, stalls, queue latency and repeated process friction.

### Customer
- **Customer Service Manager** (`titan.manager.customer_service`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Run the customer-service division and supervise customer-facing staff.
- **After-Hours Coordinator** (`titan.customer.after_hours_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Triage urgent and after-hours customer requests.
- **Booking Coordinator** (`titan.customer.booking_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Create booking requests, collect service details and manage booking changes.
- **Customer Care Coordinator** (`titan.customer.customer_care_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Manage post-service follow-up, satisfaction and unresolved needs.
- **Customer Operations Coordinator** (`titan.customer.operations_coordinator`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SMALL**; verticals: all. Float across compatible customer-service work to relieve overloaded queues.
- **Customer Service Coordinator** (`titan.customer.customer_service_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Answer customer questions and manage routine service communication.
- **Deputy Customer Service Manager** (`titan.customer.deputy_manager`) — Tier 2; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Provide manager continuity, handle escalations and accept delegated review authority when the manager is unavailable.
- **Receptionist** (`titan.customer.receptionist`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Handle inbound enquiries, identify intent, collect initial details and route work.
- **Retention Coordinator** (`titan.customer.retention_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Identify churn risk and repeat-service opportunities.
- **Service Recovery Coordinator** (`titan.customer.service_recovery_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Own complaints, failed service and recovery workflows.

### Governance
- **Compliance & Governance Manager** (`titan.manager.compliance_governance`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Coordinate policy exceptions, governance review and required human approvals using Titan Governance decisions.
- **Risk Manager** (`titan.manager.risk`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Monitor Titan Risk outputs, emerging exposure and escalation queues without recalculating authoritative risk.
- **Assurance Coordinator** (`titan.governance.assurance_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **SOLO**; verticals: all. Monitor evidence quality, Assurance degradation and disagreement signals without replacing Titan Assurance.
- **Incident Coordinator** (`titan.governance.incident_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **SOLO**; verticals: all. Coordinate containment, remediation, verification and follow-up for Workforce incidents.

### Hospitality Realestate
- **Hospitality & Real Estate Manager** (`titan.manager.hospitality_realestate`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: hospitality, real-estate, hotel, bnb, property-management. Own the entire guest/tenant lifecycle and property operations across short-term hospitality and long-term real estate.
- **Concierge & 24/7 Comms Coordinator** (`titan.hospitality.concierge`) — Tier 2; risk ceiling **HIGH**; min business tier **SMALL**; verticals: hospitality, hotel. Handle after-hours guest emergencies, service requests and complaint de-escalation.
- **Facilities & Premises Coordinator** (`titan.realestate.facilities`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SMALL**; verticals: real-estate, property-management, facilities, hospitality. Manage the physical building and premises including HVAC, pools, gyms, common areas and utilities.
- **Guest Experience Coordinator** (`titan.hospitality.guest_experience`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SOLO**; verticals: hospitality, hotel, bnb. Own pre-arrival through post-departure guest communication and special requests.
- **Housekeeping & Turnover Planner** (`titan.hospitality.housekeeping_planner`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: hospitality, hotel, bnb. Run tight turnover windows and cleaning/laundry logistics between check-out and check-in.
- **Leasing & Tenant Relations Coordinator** (`titan.realestate.leasing`) — Tier 2; risk ceiling **HIGH**; min business tier **GROWING**; verticals: real-estate, property-management. Manage applications, rent reminders, maintenance requests and lease renewal workflows.
- **Property Handover Inspector** (`titan.realestate.handover_inspector`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SMALL**; verticals: real-estate, property-management. Perform entry/exit condition inspections with structured photo/video evidence.
- **Settlement & Contract Coordinator** (`titan.realestate.settlement`) — Tier 2; risk ceiling **EXTREME**; min business tier **GROWING**; verticals: real-estate, property-management. Coordinate leases, e-signatures, bond/lodgement and handover condition documentation.
- **Viewing & Open-Home Coordinator** (`titan.realestate.viewing`) — Tier 2; risk ceiling **LOW**; min business tier **GROWING**; verticals: real-estate. Schedule property tours, coordinate access and route prospect feedback to Sales.

### Insights
- **Business Intelligence Manager** (`titan.manager.business_intelligence`) — Tier 1; risk ceiling **MEDIUM**; min business tier **GROWING**; verticals: all. Run business intelligence and deliver decision support to Titan Ops and managers.
- **Business Analyst** (`titan.insights.business_analyst`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Find trends, anomalies, bottlenecks and opportunities.
- **Customer Insights Analyst** (`titan.insights.customer_insights_analyst`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Analyse satisfaction, complaints, retention and customer behaviour.
- **Operations Analyst** (`titan.insights.operations_analyst`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Analyse capacity, utilisation, schedules and job flow.
- **Performance Analyst** (`titan.insights.performance_analyst`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Measure staff, division and service performance.
- **Revenue Analyst** (`titan.insights.revenue_analyst`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Analyse revenue, conversion, pricing, margin and lost-income opportunities.

### Marketing
- **Marketing Manager** (`titan.manager.marketing`) — Tier 1; risk ceiling **MEDIUM**; min business tier **GROWING**; verticals: all. Run marketing, brand activity and growth campaigns.
- **Campaign Coordinator** (`titan.marketing.campaign_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Plan and coordinate outbound campaigns and promotions.
- **Customer Reactivation Coordinator** (`titan.marketing.reactivation_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Identify dormant customers and coordinate re-engagement.
- **Reputation Manager** (`titan.marketing.reputation_manager`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Monitor feedback, reviews and reputation risks.
- **Reviews & Referrals Coordinator** (`titan.marketing.reviews_referrals_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Request reviews and identify referral opportunities.

### Money
- **Finance Manager** (`titan.manager.finance`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Run billing, receivables, payables, bookkeeping and financial administration.
- **Accounts Payable Officer** (`titan.money.accounts_payable_officer`) — Tier 2; risk ceiling **HIGH**; min business tier **SOLO**; verticals: all. Coordinate supplier bills and payable obligations.
- **Accounts Receivable Officer** (`titan.money.accounts_receivable_officer`) — Tier 2; risk ceiling **HIGH**; min business tier **SOLO**; verticals: all. Monitor outstanding invoices and coordinate overdue follow-up.
- **Billing Coordinator** (`titan.money.billing_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **SOLO**; verticals: all. Turn completed billable work into accurate invoices.
- **Bookkeeper** (`titan.money.bookkeeper`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SOLO**; verticals: all. Maintain transaction categorisation and reconciliation preparation.
- **Cost Controller** (`titan.money.cost_controller`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SOLO**; verticals: all. Detect cost overruns, margin leakage and unusual job costs.
- **Credit & Disputes Coordinator** (`titan.money.credit_disputes_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **SOLO**; verticals: all. Coordinate invoice disputes, credits and billing exceptions.

### Operations
- **Operations Manager** (`titan.manager.operations`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Run the digital organisation, coordinate managers, workload, exceptions and operational health.
- **Change Coordinator** (`titan.operations.change_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Coordinate approved organisational, process and capability changes through controlled rollout.
- **Chief of Staff** (`titan.operations.chief_of_staff`) — Tier 2; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Support Titan Ops with executive coordination, cross-manager follow-through and organisational cadence.
- **Executive Assistant** (`titan.operations.executive_assistant`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SMALL**; verticals: all. Prepare information, scheduling and administrative support for managers without inheriting their authority.
- **Office Manager** (`titan.operations.office_manager`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Coordinate day-to-day administration, records and office workload.
- **Process Coordinator** (`titan.operations.process_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Monitor process flow, bottlenecks and incomplete handoffs.
- **Risk & Assurance Liaison** (`titan.operations.risk_assurance_liaison`) — Tier 2; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Coordinate visibility of Titan Risk and Titan Assurance outputs for managers without calculating those engine decisions.
- **Strategy Coordinator** (`titan.operations.strategy_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Turn validated analytics and management direction into structured strategic work proposals.

### People
- **Workforce Manager** (`titan.manager.workforce`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Run staffing capacity, availability and workforce operations.
- **Compliance Coordinator** (`titan.people.compliance_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **SOLO**; verticals: all. Track licences, certificates, checks, insurance and expiry requirements.
- **Crew Coordinator** (`titan.people.crew_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Build and coordinate multi-person field crews.
- **Health & Safety Coordinator** (`titan.people.health_safety_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **SOLO**; verticals: all. Coordinate hazard, incident and safety follow-up workflows.
- **Licensing & Accreditation Coordinator** (`titan.people.licensing_accreditation`) — Tier 2; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Track licence scope, endorsements, accreditation and role-to-work eligibility.
- **Roster Coordinator** (`titan.people.roster_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Build rosters and monitor leave, coverage gaps and overtime exposure.
- **Training Coordinator** (`titan.people.training_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Track onboarding, competencies and refresher training.

### Procurement
- **Procurement & Supply Manager** (`titan.manager.procurement_supply`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Own supplier relationships, purchasing policy, subcontractors and materials planning.
- **Materials Planner** (`titan.procurement.materials_planner`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SMALL**; verticals: all. Forecast materials demand from the job pipeline and prevent supply-driven delays.
- **Procurement Coordinator** (`titan.procurement.procurement_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **SMALL**; verticals: all. Coordinate RFQs, purchase orders, approvals and delivery tracking.
- **Subcontractor Coordinator** (`titan.procurement.subcontractor_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Coordinate external crews, onboarding, compliance, quality and allocation.
- **Supplier Relations Coordinator** (`titan.procurement.supplier_relations`) — Tier 2; risk ceiling **MEDIUM**; min business tier **GROWING**; verticals: all. Manage supplier performance, terms, service levels and relationship issues.

### Records
- **Records & Data Manager** (`titan.manager.records_data`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Own records integrity, document control, data governance and scheduled reporting.
- **Data Governance Coordinator** (`titan.records.data_governance`) — Tier 2; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Monitor data quality, deduplication, retention and privacy obligations.
- **Document Controller** (`titan.records.document_controller`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SMALL**; verticals: all. Maintain controlled job files, contracts, warranties and compliance documentation.
- **Reporting Coordinator** (`titan.records.reporting`) — Tier 2; risk ceiling **MEDIUM**; min business tier **GROWING**; verticals: all. Prepare scheduled reports, dashboards and management packs from governed data.

### Retail Rental
- **Retail, Rental & Fulfilment Manager** (`titan.manager.retail_rental`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: ecommerce, retail, rental, salon, fitness. Own order-to-doorstep fulfilment, hire-fleet utilisation, reverse logistics and multi-channel inventory.
- **Appointment & Resource Allocator** (`titan.salon.appointment_allocator`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SOLO**; verticals: salon, fitness, booking-hire. Match stylists/trainers to clients by skill, seniority, preference and capacity while resolving overlaps.
- **Carrier & Shipping Logistics Coordinator** (`titan.ecommerce.shipping`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SOLO**; verticals: ecommerce, retail. Select carriers, generate labels, track delivery exceptions and manage loss claims.
- **Condition & Damage Assessment Coordinator** (`titan.rental.damage_assessment`) — Tier 2; risk ceiling **HIGH**; min business tier **SMALL**; verticals: rental, hire. Coordinate pre/post-hire inspections and classify wear, damage and deposit-impact evidence.
- **Fleet Turnaround Coordinator** (`titan.rental.turnaround`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SMALL**; verticals: rental, vehicle-rental, tool-hire. Coordinate cleaning, refuelling/recharging and safety readiness between hires.
- **Hire Availability & Resource Planner** (`titan.rental.availability_planner`) — Tier 2; risk ceiling **LOW**; min business tier **SMALL**; verticals: rental, hire. Optimise hire fleet utilisation, substitutions, maintenance blocks and minimum hire policies.
- **Membership & Package Coordinator** (`titan.salon.membership`) — Tier 2; risk ceiling **HIGH**; min business tier **SMALL**; verticals: salon, fitness, membership. Manage package credits, recurring memberships, freezes, cancellations and loyalty redemption.
- **Order Fulfilment Coordinator** (`titan.ecommerce.fulfilment`) — Tier 2; risk ceiling **LOW**; min business tier **SMALL**; verticals: ecommerce, retail. Convert paid orders into picked, packed and labelled fulfilment work.
- **Returns & Reverse Logistics Coordinator** (`titan.ecommerce.returns`) — Tier 2; risk ceiling **HIGH**; min business tier **SMALL**; verticals: ecommerce, retail, rental. Manage RMA, return inspection, exchanges, restocking, write-offs and refund preparation.

### Sales
- **Sales Manager** (`titan.manager.sales`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Run the sales division, pipeline, priorities and conversion performance.
- **Business Development Coordinator** (`titan.sales.business_development_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Find commercial, recurring and partnership opportunities.
- **Commercial Accounts Coordinator** (`titan.sales.commercial_accounts_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Coordinate tenders, larger accounts and commercial requirements.
- **Estimator** (`titan.sales.estimator`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SOLO**; verticals: all. Prepare estimates using scope, labour, materials, photos, measurements and historical work.
- **Quote Coordinator** (`titan.sales.quote_coordinator`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SOLO**; verticals: all. Prepare, issue, track and follow up quotes.
- **Sales Coordinator** (`titan.sales.sales_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Manage follow-ups, next actions, stale leads and pipeline hygiene.
- **Sales Representative** (`titan.sales.sales_representative`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Qualify opportunities and progress prospects toward accepted work.
- **Tender & Bid Coordinator** (`titan.sales.tender_bid`) — Tier 2; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Coordinate complex tenders, specification compliance, bid packs and submission milestones.

### Work
- **Project Manager** (`titan.work.project_manager`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Own major project delivery, milestones, variations, dependencies and project-level exceptions.
- **Service Manager** (`titan.manager.service`) — Tier 1; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Run jobs and service delivery from planning through completion.
- **Deputy Service Manager** (`titan.work.deputy_manager`) — Tier 2; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Provide service-management continuity and manage operational queues during manager load or unavailability.
- **Dispatcher** (`titan.work.dispatcher`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SOLO**; verticals: all. Coordinate day-of-work assignment, routing, delays and exceptions.
- **Emergency Service Coordinator** (`titan.work.emergency_service_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **SOLO**; verticals: all. Triage and coordinate urgent service requests.
- **Field Coordinator** (`titan.work.field_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Bridge office and field teams during active work.
- **Handover Coordinator** (`titan.work.handover_coordinator`) — Tier 2; risk ceiling **HIGH**; min business tier **GROWING**; verticals: all. Coordinate final inspections, documentation, training and operational handover for major projects.
- **Job Completion Coordinator** (`titan.work.job_completion_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Verify completion evidence, notes, materials and required documentation.
- **Job Coordinator** (`titan.work.job_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Coordinate jobs from acceptance through readiness and completion.
- **Maintenance Coordinator** (`titan.work.maintenance_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Manage planned and preventative maintenance workflows.
- **Project Coordinator** (`titan.work.project_coordinator`) — Tier 2; risk ceiling **MEDIUM**; min business tier **GROWING**; verticals: all. Track milestones, progress, dependencies, variations and project documentation.
- **Quality Coordinator** (`titan.work.quality_coordinator`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SOLO**; verticals: all. Review quality evidence and identify missing requirements or rework.
- **Recurring Services Coordinator** (`titan.work.recurring_services_coordinator`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Manage repeat-service schedules and recurring service obligations.
- **Scheduler** (`titan.work.scheduler`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SOLO**; verticals: all. Propose appointment slots and staff allocations.
- **Service Operations Coordinator** (`titan.work.operations_coordinator`) — Tier 2; risk ceiling **MEDIUM**; min business tier **SMALL**; verticals: all. Float across compatible service-operation work to relieve overloaded queues.
- **Site Coordinator** (`titan.work.site_coordinator`) — Tier 2; risk ceiling **MEDIUM**; min business tier **GROWING**; verticals: all. Coordinate service delivery for a specific site or multi-site customer location.
- **Work Planner** (`titan.work.work_planner`) — Tier 2; risk ceiling **LOW**; min business tier **SOLO**; verticals: all. Determine skills, duration, equipment, material, evidence and service requirements.

## Remaining acceptance gates

- No direct authoritative business mutation from Workforce.
- No engine duplication.
- No self-approval or self-promotion.
- No cross-tenant organisational relationship/task/handoff.
- No cross-division overflow unless explicit policy permits it.
- No role activation directly from a planning recommendation.
- Every execution remains subject to external Risk, Assurance, Autonomy and Command Bus policy.


## Pass 4 — Proactive Divisions

### Responsibility registry

Proactive operating rhythms are now sourced only from explicit routines declared by contributing extension workforce manifests. Titan AI Workforce no longer ships a central `proactive-responsibilities.json` domain catalogue. The 111-role catalogue in this document is reference coverage only; live identity, division, capabilities, risk ceilings, tools and workflows come from installed extension manifests.

### Default operating rhythm

- Managers and Specialists receive schedules/events only when their owning extension explicitly contributes them. This avoids duplicate domain automation. Domain extensions may emit Titan Signal events, maintain extension-owned workflow runs, or declare explicit Workforce routines; the central Workforce runtime synchronises only those declared responsibilities into tenant staff instances.

### Vertical packs

Optional responsibility packs are defined for **field services, hospitality, real estate, commerce, rental, and appointment/membership** businesses. They activate through provisioned staff roles and do not embed PMS, commerce, payment, Shield, Connect, IoT or other external systems inside AI Workforce.

### Queue intelligence and proactive management

Managers receive deterministic queue-health snapshots containing queue depth, active capacity, load ratio, blocked/escalated/overdue/starved work, SLA breach rate and coverage gaps. Proactive workload balancing is restricted to **unstarted ASSIGNED work**, the **same division**, compatible capability, adequate risk ceiling and available capacity. Cross-division movement still requires a governed handoff.

Queue pressure may produce Workforce Planning recommendations, but **AI Workforce never auto-hires or auto-activates a role**. Every recommendation carries `auto_activate=false`.

### Engine boundary

AI Workforce owns schedules, responsibilities, queue health and organisational coordination only. It does not calculate Titan Risk, Assurance or Autonomy and does not execute authoritative business mutation. Playbook identifiers are references for external runtime/procedure systems.


## Pass 5 — Governed Intelligence Loop

AI Workforce now consumes authoritative Titan Risk, Assurance and Autonomy decisions as a single pre-execution governance envelope. Consequential execution fails closed if any of those engine decisions are unavailable. Interaction workflow references are prepared through Titan Interaction Engine when present; AI Workforce does not implement workflow logic itself.

A Command Bus response cannot mark a Workforce task complete without an authoritative receipt. If execution is reported but the receipt is missing, the task moves to `RECOVERY` and emits a reconciliation signal. Successful receipts/outcomes are forwarded through adapters to Titan Rewind and Titan Wisdom and stored as structured references in the task governance record.

Trust-health summaries aggregate current organisational exposure from existing Workforce snapshots only: risk distribution, Assurance distribution, Autonomy allow/block state, engine availability and blocked/recovery/escalated work. These summaries are operational observability, not replacement Risk/Assurance/Autonomy engines.

Titan Vertical Engine may return presentation/procedure overlays for roles, including terminology, responsibilities, playbook/workflow refs, knowledge scopes and capability variants. Workforce explicitly refuses vertical overlays as a mechanism to raise authority, risk ceilings or inject new capabilities.

Authoritative engine signals such as elevated Risk, degraded Assurance, Autonomy restriction and negative Wisdom outcomes can create governed follow-up tasks for the appropriate Governance or Insights staff. Signal-created tasks preserve the originating trace/correlation IDs and directly cite the triggering Signal ID as causation.


## Pass 6 — Control Room & Final Certification

- Added a read-only Workforce Control Room that aggregates the persisted organisation graph, Manager queue health, external Risk/Assurance/Autonomy trust state, reviews, cross-division handoffs, performance evidence, staffing recommendations, and execution outcome references.
- Workforce Planning recommendations are now persistable as `RECOMMENDED`, `APPROVED`, or `REJECTED` proposals. Approval never creates a Workforce Member and never grants Titan Autonomy; it only opens the existing Employee Builder for explicit activation.
- Performance metrics are derived from persistent tasks/history and are passed into organisational maturity evaluation. Missing Assurance calibration evidence remains conservative rather than being inferred from model confidence.
- Execution receipts, Titan Rewind references, Titan Wisdom outcome references, trace IDs and correlation IDs are surfaced for reconstruction.
- The cross-extension acceptance matrix explicitly distinguishes Workforce-side verified controls from peer-engine live integration gates.

## Production Upgrade Pass 3 — Workforce Manifest 2.0 Registry & Legacy Normalisation

- Workforce Manifest 2.0 is now the canonical extension-owned definition contract.
- Blueprint schema 1.1 is accepted only through conservative floor-mapped normalisation; 1.0 is rejected rather than inferred.
- Invalid contributors are quarantined independently and are never exposed as activatable roles.
- Manifest health is exposed through a stable adapter and authenticated API.
- Accepted role definitions retain owner extension/version, canonical/source schema versions, definition version and deterministic definition fingerprint.
- Continuous desired/initial Autonomy is descriptive policy input only; effective authority and Predictive readiness remain external Titan Autonomy decisions.
- Proactive 2.0 schedules and Signal triggers are adapted into central Workforce tasks only; no direct business mutation is introduced.
- Extension lifecycle pinning/removal semantics remain scheduled for Production Upgrade Pass 4.

## Production Upgrade Pass 5 — Self-Healing Parent/Child Navigation & Host Menu Compatibility

- Preserves one AI Workforce parent plus seven named-route child links.
- Registers through Titan `MenuContributionRegistry` / generic `ContributionRegistry` first.
- Adds MagicAI `menus` table self-heal with parent-first persistence and real `parent_id` resolution.
- Preserves existing administrator order and enabled/disabled state while repairing vendor-owned structure.
- Uses `extension = NULL` for operational Workforce menu rows to avoid MagicAI plan-feature filtering.
- Detects duplicate menu keys conservatively and repairs only the canonical first row without destructive automatic deletion.
- Adds `titan-workforce:host-sync` for install/upgrade/operator repair and `MenuService::regenerate()` cache refresh.


## Production Upgrade Pass 6 — Host Authorization & Tenant Boundary Hardening

- MagicAI Step-10 host authorization methods are normalized through one fail-closed adapter.
- Super Admin is the only unconditional authorization bypass; tenant context is still mandatory.
- Admin fallback is bounded to the declared Workforce permission map; ordinary users need explicit permission.
- `company_id` is canonical and no customer `company_id`, team ID or user ID may be reinterpreted as tenancy.
- HTTP routes, route-model bindings, queue jobs, scheduler loops and Signal outbox retries preserve exact tenant context.
- Background tenant scopes reject nested tenant switching and always clear after processing.


## Pass 7 — Staff Instance Lifecycle v2

See `docs/PASS07-STAFF-INSTANCE-LIFECYCLE-V2.md`. Staff activation now requires an exact valid extension-owned RoleDefinition, authority-bearing fields are manifest-owned, lifecycle state is separate from operational status, and suspension/retirement preserve historical provenance.

## Production Upgrade Pass 8 — Organisational Graph, Deputies, RACI & Decision Rights

The v1.0 production line now enforces an acyclic persisted reporting graph, extension-owned RACI decision rights, scoped/expiring deputy coverage with no authority inheritance, same-division direct delegation, and graph-derived dispute escalation. Domain-specific RACI/dispute ownership is no longer centralised in Titan AI Workforce. Unresolvable disputes fail closed to `HUMAN_DECISION_REQUIRED`.

## Production Upgrade Pass 9 — Three-Way Chain-of-Command v2

- Maker submission, originating Manager review and receiving Manager responsibility acceptance are distinct states and actors.
- Cross-division handoffs carry immutable canonical SHA-256 packets; receiver acceptance consumes the packet snapshot rather than mutable source-task fields.
- Receiver decisions are serialized, decision-versioned and idempotent; conflicting repeated decisions fail closed.
- Acceptance creates a new receiving-side child task and a new governed cycle; the source task is completed only after child creation.
- Task-history rows are append-only, parent references are tenant-valid, and dependency insertion rejects transitive cycles.
- `titan.workforce.chain-integrity` exposes orphan parent/dependency/handoff references and legacy dependency cycles.

## Production Upgrade Pass 10 — Proactive Workforce Runtime from Extension-Owned Responsibilities

- Extension-owned Workforce Manifest schedules and Signal responsibilities are the only source of proactive domain duties.
- Every materialised routine is bound to owning extension, RoleDefinition, routine ID and a deterministic semantic routine fingerprint.
- Due schedules lock their row before dispatch and use definition-bound occurrence idempotency keys; replay returns the existing Workforce Task rather than dispatching duplicate work.
- Signal-triggered responsibilities restore tenant context and use canonical routine + Signal identities, including stable envelope hashing when a Signal ID is unavailable.
- Generated proactive work can create `workforce_task` only and is explicitly `business_mutation=false`; the proactive layer never calls Command Bus directly.
- Member-local timezone settings determine schedule occurrence calculation while persisted due times remain in application UTC.
- Extension disable/uninstall immediately deactivates owned schedules/triggers; activation/upgrade reconciles staff first and then resynchronises owned routines.
- Queue health now includes unassigned work, capacity utilisation and a deterministic staffing-pressure snapshot derived from SLA, starvation, coverage and workload signals.
- Workforce Planning consumes staffing pressure but remains recommendation-only with `auto_activate=false`.
- Manager proactive coordination runs only for an active instantiated Tier-1 Manager whose exact extension-owned RoleDefinition is currently discoverable.

## Production Upgrade Pass 11 — Continuous Titan Autonomy Integration

Titan AI Workforce now consumes the canonical Titan Autonomy Decision v2 envelope for every governed execution. Authority is 0–100 and capability/variant/workflow/context specific. Workforce validates the exact autonomy key, desired/earned/effective score ordering, canonical bands, policy version and Predictive readiness before execution.

Role manifests remain limited to desired and conservative initial earned ceilings; the live earned/effective state belongs to Titan Autonomy. Workforce stores decision references only. Model/provider changes force contextual re-evaluation without a global reset. Offline policy only reduces/blocks authority. Organisational maturity, title, hierarchy and deputy coverage cannot raise authority, and no global Trusted Auto or Predictive permission exists.


## Production Upgrade Pass 12 — Risk, Assurance, Model Council & Interaction

- External Titan Risk: contextual/cumulative/vertical/residual risk refs; canonical Minimal/Low/Medium/High/Extreme categories; explicit allow/deny.
- External Titan Assurance: Green/Amber/Red, evidence-backed allow/deny, required/missing evidence.
- Selective Model Council: called only when Risk/policy requires it; required unavailability fails closed.
- Extension-owned Interaction workflows/Wizards collect missing capability evidence; no procedure is improvised by central Workforce.
- Governance policy is conjunctive: Assurance cannot override Risk denial, and no missing dependency becomes a permissive default.
- Handoff packet v3 carries evidence refs with immutable governance context.

## Production Pass 13 — Command Bus Execution, Receipts, Recovery & Post-Action Verification

Execution now persists a tenant-scoped intent lock and expected-state fingerprint before Command Bus dispatch, revalidates authoritative state immediately before mutation, supplies a stable idempotency key, requires an identity-matching structured receipt, reconciles uncertain executions without blind resend, and requires post-action verification before completion. Reversible/compensatable recovery remains Command Bus governed; irreversible failures require human decision. Titan AI Workforce never writes domain state directly.

## Production Pass 14 — Signal, Rewind, Wisdom & Outcome Feedback Spine

Implemented append-only structured journey records, Signal/Rewind continuity, verified-only Wisdom/Autonomy outcome evidence, downstream verified-outcome ingestion, performance/maturity outcome evidence, and outcome-verification health. No private hidden reasoning is persisted and outcome feedback cannot mint authority.
