# New Roadmap Step 1 — Safe Degradation UX

Version: `0.52.0-alpha.25`

Safe degradation is now a first-class operator experience. Live capability state is rendered with five human-readable statuses: Healthy, Degraded, Blocked, Missing Provider and Policy Disabled. Degraded badges drill into a company-scoped employee explanation that identifies unavailable surfaces, surfaces that still work, open work affected, canonically bound fallback candidates, why those fallbacks are or are not usable, and the exact administrator action required.

The projection is read-only. Provider availability and canonical fallback eligibility never create or inherit execution authority; consequential execution remains task-scoped through Risk, Assurance, Governance, Autonomy and Command Bus. Role identity remains immutable when providers disappear or policy disables capabilities.
