# Step 1 — Workforce Command Dashboard

The Workforce Overview is now the owner-facing operational home. It aggregates company-scoped, read-only health from existing authoritative Workforce models and services; no new authority is inferred or granted.

## Signals surfaced
- Active, degraded and blocked staff counts from live role/provider availability.
- Open, review, blocked and escalated work.
- Capability-provider health across active employee bindings.
- Manager queue pressure and capacity signals.
- Overdue scheduled proactive responsibilities.
- Execution failures and recoveries.
- Outcome verification health.
- Staffing recommendations.
- Recent critical immutable task-history events.
- Deterministic `Needs attention now` prioritization.

## Safety invariants
- `company_id` remains the only company boundary.
- Cached member capabilities are never treated as live availability.
- Provider availability never grants execution authority.
- The dashboard is read-only aggregation; it does not mutate role identity, responsibility, capability, autonomy or governance state.
