#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PLAN_ID="6bb234ac-d390-4a3f-8be2-666f5dec8a81"
errors=[]
p=ROOT/"docs"/"TITAN-THREE-SYSTEM-ARCHITECTURE-FREEZE.json"
if not p.exists(): errors.append("missing architecture freeze JSON")
else:
    try: d=json.loads(p.read_text(encoding="utf-8"))
    except Exception as e: errors.append(f"invalid architecture freeze JSON: {e}"); d={}
    if d.get("plan_id")!=PLAN_ID: errors.append("PLAN_ID mismatch")
    if d.get("pass")!=1: errors.append("pass must be 1")
    if d.get("runtime_behavior_changed") is not False: errors.append("Pass 1 must remain behavior-neutral")
    if (d.get("canonical_target_identity") or {}).get("company_boundary")!="company_id": errors.append("target company boundary must be company_id")
    inv=d.get("permanent_invariant","")
    for term in ("Workforce", "Command Bus", "authoritative domain extension"):
        if term not in inv: errors.append(f"permanent invariant missing {term}")
if errors:
    print("TITAN_THREE_SYSTEM_PASS1: FAIL")
    for e in errors: print("ERROR:",e)
    sys.exit(1)
print("TITAN_THREE_SYSTEM_PASS1: PASS")
