#!/usr/bin/env python3
"""Verify Titan Installer 1.7.8 flat ZIP, path safety, release artifacts and exact integrity.files semantics."""
from __future__ import annotations
import argparse,hashlib,json,stat,sys,zipfile
from collections import Counter
from pathlib import PurePosixPath

def verify(path:str)->list[str]:
 errors=[]
 try: archive=zipfile.ZipFile(path)
 except (OSError,zipfile.BadZipFile) as exc: return [f'cannot open ZIP: {exc}']
 with archive:
  infos=archive.infolist(); names=[i.filename for i in infos if not i.is_dir()]
  for name,count in Counter(names).items():
   if count>1: errors.append(f'duplicate ZIP entry: {name}')
  for info in infos:
   name=info.filename; pure=PurePosixPath(name)
   if '\\' in name: errors.append(f'non-POSIX ZIP path: {name}')
   if pure.is_absolute() or '..' in pure.parts: errors.append(f'unsafe ZIP path: {name}')
   if stat.S_ISLNK(info.external_attr>>16): errors.append(f'symlink ZIP entry: {name}')
   if any(part in {'__MACOSX','__pycache__','.git','node_modules'} for part in pure.parts) or pure.name in {'.DS_Store'} or pure.suffix=='.pyc': errors.append(f'junk/cache ZIP entry: {name}')
  bad=archive.testzip()
  if bad is not None: errors.append(f'CRC failure: {bad}')
  if 'extension.json' not in names:
   if any(n.endswith('/extension.json') for n in names): errors.append('installer ZIP must have a flat root; outer extension directory is forbidden')
   else: errors.append('missing root extension.json')
   return errors
  if 'extension.manifest.json' not in names: errors.append('missing root extension.manifest.json')
  try: manifest=json.loads(archive.read('extension.json'))
  except Exception as exc: errors.append(f'cannot parse root extension.json: {exc}'); return errors
  required={'schema','slug','folder','provider','version','integrity'}
  if manifest.get('schema')!='titan-extension-v1': errors.append('root extension.json must use schema=titan-extension-v1')
  extra=set(manifest)-required
  if extra: errors.append('root extension.json has unsupported field(s): '+', '.join(sorted(extra)))
  missing=required-set(manifest)
  if missing: errors.append('root extension.json missing field(s): '+', '.join(sorted(missing)))
  integrity=(manifest.get('integrity') or {}).get('files')
  if not isinstance(integrity,dict): errors.append('root extension.json integrity.files is required'); return errors
  actual_set=set(names)-{'extension.json'}
  declared_set=set(integrity)
  for rel in declared_set:
   if rel.startswith('/') or '\\' in rel or '..' in PurePosixPath(rel).parts: errors.append(f'unsafe integrity path: {rel}')
  for rel in sorted(actual_set-declared_set): errors.append(f'integrity.files missing archive file: {rel}')
  for rel in sorted(declared_set-actual_set): errors.append(f'integrity.files references absent archive file: {rel}')
  if 'extension.json' in declared_set: errors.append('integrity.files must exclude extension.json to avoid self-hash recursion')
  for rel in sorted(actual_set & declared_set):
   actual=hashlib.sha256(archive.read(rel)).hexdigest()
   if actual!=integrity.get(rel): errors.append(f'integrity hash mismatch: {rel}')
 return errors

def main(argv=None)->int:
 ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('zip_path'); args=ap.parse_args(); errors=verify(args.zip_path)
 if errors:
  for e in errors: print('ERROR:',e,file=sys.stderr)
  return 1
 print('OK: Installer 1.7.8 flat ZIP + integrity/path safety')
 return 0
if __name__=='__main__': raise SystemExit(main())
