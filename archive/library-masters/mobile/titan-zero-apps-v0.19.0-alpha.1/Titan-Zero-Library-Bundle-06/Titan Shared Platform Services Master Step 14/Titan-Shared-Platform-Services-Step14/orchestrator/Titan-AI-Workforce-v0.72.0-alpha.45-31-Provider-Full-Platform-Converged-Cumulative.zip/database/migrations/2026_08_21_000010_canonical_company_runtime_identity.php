<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** @var array<int, string> */
    private array $companyTables = [
        'ext_titan_ai_workforce_divisions',
        'ext_titan_ai_workforce_teams',
        'ext_titan_ai_workforce_members',
        'ext_titan_ai_workforce_relationships',
        'ext_titan_ai_workforce_tasks',
        'ext_titan_ai_workforce_task_dependencies',
        'ext_titan_ai_workforce_handoffs',
        'ext_titan_ai_workforce_task_history',
        'ext_titan_ai_workforce_schedules',
        'ext_titan_ai_workforce_signal_outbox',
        'ext_titan_ai_workforce_staffing_proposals',
        'ext_titan_ai_workforce_execution_attempts',
        'ext_titan_ai_workforce_journey_records',
    ];

    public function up(): void
    {
        // Upgrade compatibility only: Pass 1 installations used the retired tenancy key.
        // Renaming preserves row values and existing index/uniqueness semantics, so no
        // authority can increase during the migration. Fresh installs already use company_id.
        foreach ($this->companyTables as $tableName) {
            if (! Schema::hasTable($tableName)) {
                continue;
            }

            if (Schema::hasColumn($tableName, 'tenant_company_id') && ! Schema::hasColumn($tableName, 'company_id')) {
                Schema::table($tableName, function (Blueprint $table): void {
                    $table->renameColumn('tenant_company_id', 'company_id');
                });
            }
        }

        if (Schema::hasTable('ext_titan_ai_workforce_members')) {
            Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'runtime_profile_id')) {
                    $table->string('runtime_profile_id', 120)->nullable()->index();
                }
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_tasks')) {
            Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'runtime_profile_id')) {
                    $table->string('runtime_profile_id', 120)->nullable()->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'conversation_id')) {
                    $table->string('conversation_id', 120)->nullable()->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'channel_id')) {
                    $table->string('channel_id', 120)->nullable()->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'source_extension')) {
                    $table->string('source_extension', 120)->nullable()->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'vertical')) {
                    $table->string('vertical', 80)->nullable()->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'workflow_ref')) {
                    $table->string('workflow_ref', 160)->nullable()->index();
                }
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_journey_records')) {
            Schema::table('ext_titan_ai_workforce_journey_records', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_journey_records', 'runtime_profile_id')) {
                    $table->string('runtime_profile_id', 120)->nullable()->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_journey_records', 'conversation_id')) {
                    $table->string('conversation_id', 120)->nullable()->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_journey_records', 'channel_id')) {
                    $table->string('channel_id', 120)->nullable()->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_journey_records', 'source_extension')) {
                    $table->string('source_extension', 120)->nullable()->index();
                }
            });
        }
    }

    public function down(): void
    {
        // Canonical company_id is not renamed back on rollback. Reintroducing a retired tenant
        // boundary would make a rollback authority-changing. Runtime identity columns are safe
        // to remove if a rollback is explicitly requested.
        if (Schema::hasTable('ext_titan_ai_workforce_members')) {
            Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table): void {
                if (Schema::hasColumn('ext_titan_ai_workforce_members', 'runtime_profile_id')) {
                    $table->dropColumn('runtime_profile_id');
                }
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_tasks')) {
            Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table): void {
                $columns = array_values(array_filter([
                    'runtime_profile_id', 'conversation_id', 'channel_id', 'source_extension', 'vertical', 'workflow_ref',
                ], fn (string $column): bool => Schema::hasColumn('ext_titan_ai_workforce_tasks', $column)));
                if ($columns !== []) {
                    $table->dropColumn($columns);
                }
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_journey_records')) {
            Schema::table('ext_titan_ai_workforce_journey_records', function (Blueprint $table): void {
                $columns = array_values(array_filter([
                    'runtime_profile_id', 'conversation_id', 'channel_id', 'source_extension',
                ], fn (string $column): bool => Schema::hasColumn('ext_titan_ai_workforce_journey_records', $column)));
                if ($columns !== []) {
                    $table->dropColumn($columns);
                }
            });
        }
    }
};
