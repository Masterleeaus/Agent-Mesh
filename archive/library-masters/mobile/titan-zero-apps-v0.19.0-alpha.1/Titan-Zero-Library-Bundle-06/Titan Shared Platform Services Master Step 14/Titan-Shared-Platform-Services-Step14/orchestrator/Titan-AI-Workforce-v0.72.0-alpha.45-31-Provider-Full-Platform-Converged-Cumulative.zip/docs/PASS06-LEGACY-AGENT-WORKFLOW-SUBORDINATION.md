# Coordinated Pass 6 — Legacy Agent Workflow Subordination

Legacy Agents workflows may sequence interaction-only steps, but consequential or unknown steps are converted into `titan.agent-workflow-proposal/1` proposals. Titan AI Workforce owns the resulting governed task and downstream business outcome. A legacy workflow run waiting on such a proposal is not a business-completion receipt.
