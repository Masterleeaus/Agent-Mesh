# New Roadmap Step 2 — Workforce Attention Center

Version: `0.53.0-alpha.26`

Creates one company-scoped intervention inbox for degraded employees, blocked work, manager reviews, escalations, deadlocks, missing providers, policy-disabled capabilities, Assurance failures, Autonomy denials, execution failures, unresolved outcomes, staffing recommendations, and explicit human decisions.

Priority is deterministic and inspectable:

`severity_score × business_impact_score × age_score × blocking_effect_score`

The Attention Center is read-only. It does not grant capability, transfer authority, widen autonomy, or bypass Risk, Assurance, Governance, or Autonomy.
