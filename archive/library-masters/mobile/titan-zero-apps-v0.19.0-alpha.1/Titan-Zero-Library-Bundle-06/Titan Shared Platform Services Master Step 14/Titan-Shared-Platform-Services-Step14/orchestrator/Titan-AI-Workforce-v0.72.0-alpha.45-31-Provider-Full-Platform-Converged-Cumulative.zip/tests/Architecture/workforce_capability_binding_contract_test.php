<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

foreach ([
    'System/Support/WorkforceCapabilityBindingRegistry.php',
    'System/Support/WorkforceCapabilityBindingValidator.php',
    'resources/workforce/workforce-capability-binding.schema.json',
    'docs/PASS10-WORKFORCE-CAPABILITY-BINDING.md',
] as $path) {
    $ok(is_file($root . '/' . $path), "Step 10 artifact missing: {$path}");
}

$schema = is_file($root . '/resources/workforce/workforce-capability-binding.schema.json')
    ? json_decode((string) file_get_contents($root . '/resources/workforce/workforce-capability-binding.schema.json'), true)
    : [];
$ok(($schema['properties']['schema_version']['const'] ?? null) === '1.0', 'capability binding schema must be v1.0');
foreach (['role_bindings','capabilities','tools','commands','signals','data_sources','workflows'] as $section) {
    $ok(in_array($section, $schema['required'] ?? [], true), "capability binding schema must require {$section}");
}
$ownership = $schema['properties']['ownership']['properties'] ?? [];
$ok(($ownership['organisation_owner']['const'] ?? null) === 'titan-ai-workforce', 'Workforce must own organisation identity in binding contract');
$ok(($ownership['provider_owns_execution_surfaces']['const'] ?? null) === true, 'extensions must own contributed execution surfaces');

$bindingRegistry = is_file($root . '/System/Support/WorkforceCapabilityBindingRegistry.php')
    ? (string) file_get_contents($root . '/System/Support/WorkforceCapabilityBindingRegistry.php') : '';
foreach (['bindingsForRole', 'effectiveAccessForRole', 'contributions', 'commands', 'signals', 'data_sources', 'workflows', 'legacy_v2_role_hint'] as $needle) {
    $ok(str_contains($bindingRegistry, $needle), "capability binding registry missing {$needle}");
}
$ok(str_contains($bindingRegistry, 'WorkforceCanonicalCapabilityMatrix'), 'capability binding registry must resolve provider access through the canonical Workforce role matrix');
$ok(str_contains($bindingRegistry, 'WorkforceManifestRegistry'), 'capability binding registry must preserve Manifest 2.0 compatibility input');
$ok(str_contains($bindingRegistry, "'authority_inherited' => false"), 'role capability bindings must never inherit authority');

$roleRegistry = (string) file_get_contents($root . '/System/Support/WorkforceRoleRegistry.php');
$ok(! str_contains($roleRegistry, '$extensionRoles'), 'canonical role registry must no longer append extension-owned employee definitions');
$ok(str_contains($roleRegistry, 'IntrinsicRoleCatalog'), 'canonical role registry must retain intrinsic employees');
$ok(str_contains($roleRegistry, 'ExecutiveRoleCatalog'), 'canonical role registry must retain executive employees');

$lifecycle = (string) file_get_contents($root . '/System/Services/WorkforceMemberLifecycleService.php');
$ok(str_contains($lifecycle, 'WorkforceCapabilityAvailabilityService'), 'member activation must consume live capability availability');
$ok(str_contains($lifecycle, 'WorkforceRoleRegistry::find'), 'member activation must resolve Workforce-owned role definitions');
$ok(str_contains($lifecycle, "'definition_source' => 'intrinsic_workforce_catalogue'"), 'member activation must pin intrinsic definition source');
$ok(str_contains($lifecycle, "'role_owner_extension' => 'titan-ai-workforce'"), 'member activation must pin Workforce as role owner');
$ok(str_contains($lifecycle, "['effective_access']" ) || str_contains($lifecycle, "'effective_access'"), 'member activation must attach only live provider access surfaces');

$controller = (string) file_get_contents($root . '/System/Http/Controllers/WorkforceController.php');
$ok(str_contains($controller, 'WorkforceRoleRegistry::all()'), 'Employee Builder must source canonical Workforce roles');
$ok(str_contains($controller, 'WorkforceCapabilityAvailabilityService'), 'Employee Builder must expose live provider capability state');
$ok(! str_contains($controller, '$this->manifestRegistry->roles()'), 'Employee Builder must not source employee identity from extension manifests');

$provider = (string) file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
foreach (['WorkforceCapabilityBindingRegistry::class', "'titan.workforce.capability-bindings'", "'titan.workforce.provider-contributions'"] as $needle) {
    $ok(str_contains($provider, $needle), "service provider missing binding adapter {$needle}");
}
$ok(str_contains($provider, "alias(WorkforceRoleRegistry::class, 'titan.workforce.role-registry')"), 'canonical role-registry alias must resolve Workforce-owned roles');
$ok(str_contains($provider, "'titan.workforce.roles', fn () => WorkforceRoleRegistry::all()"), 'public Workforce roles adapter must expose canonical intrinsic/executive roles');
$ok(! str_contains($provider, "'titan.workforce.roles', fn (\$app) => \$app->make(WorkforceManifestRegistry::class)->roles()"), 'public Workforce roles adapter must not expose extension-owned role hints');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$ok(in_array('titan-workforce.capability-bindings-v1', $manifest['capabilities'] ?? [], true), 'extension manifest missing capability-bindings-v1');
$ok(($manifest['workforce']['role_ownership'] ?? null) === 'titan-ai-workforce', 'sidecar must declare Workforce role ownership');
$ok(($manifest['workforce']['provider_contract'] ?? null) === 'titan.workforce.capability-bindings.v1', 'sidecar must declare capability provider contract');

$manifestCompat = (string) file_get_contents($root . '/System/Support/WorkforceManifestRegistry.php');
$ok(str_contains($manifestCompat, 'compatibilityRoleHints'), 'Manifest 2.0 registry must expose compatibility role hints rather than canonical role ownership');
$ok(str_contains($manifestCompat, 'providerContributions'), 'Manifest 2.0 registry must expose provider contribution translation');
$ok(! str_contains($manifestCompat, 'Workforce role_id collision'), 'legacy role-hint overlap across capability providers must not quarantine providers');

$extensionOwnedTest = (string) file_get_contents($root . '/tests/Architecture/extension_owned_manifests_contract_test.php');
$ok(str_contains($extensionOwnedTest, 'capabilities remain extension-owned'), 'legacy manifest test must document capability ownership');

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce capability binding contract\n";
