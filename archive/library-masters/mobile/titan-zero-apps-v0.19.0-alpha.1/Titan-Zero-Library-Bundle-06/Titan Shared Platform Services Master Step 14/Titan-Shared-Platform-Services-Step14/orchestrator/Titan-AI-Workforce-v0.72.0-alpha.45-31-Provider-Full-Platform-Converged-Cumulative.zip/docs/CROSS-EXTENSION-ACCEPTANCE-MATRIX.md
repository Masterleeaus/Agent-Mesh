# Extension-owned Workforce Manifest Boundary

- Domain roles, skills, tools, workflows, prompts and wizards are **owned by the extension that owns the capability**.
- Titan AI Workforce discovers them through `titan-workforce.manifests`; it does not install a duplicate global role pack.
- Disabling/removing a contributing extension removes its definitions from discovery without deleting historical Workforce task/receipt provenance.
- No contributed manifest may self-promote Autonomy or bypass Titan Command Bus for AI-originated mutation.

# Titan AI Workforce — Cross-Extension Acceptance Matrix

## Scope

This matrix certifies the **AI Workforce side of the integration contract**. It proves that Workforce creates traceable organisational work, enforces chain-of-command boundaries, fails closed when required governance/execution engines are unavailable, and exposes the adapters needed by the wider Titan platform.

It does **not** claim that a separately installed Titan engine has passed its own independent implementation or live-environment tests. Full end-to-end platform certification requires the corresponding engine packages to be installed and exercised together.

## Canonical Scenario

1. **Customer request** arrives through Titan Hub or Titan Connect.
2. Titan AI Core identifies intent and supplies an objective.
3. Titan AI Workforce creates persistent work with `company_id`, `trace_id`, `correlation_id`, and `causation_id`.
4. Tier 1 Manager accepts organisational responsibility.
5. Tier 2 Specialist performs the referenced Interaction Engine workflow/playbook.
6. Titan Risk evaluates contextual exposure.
7. Titan Assurance evaluates supporting evidence.
8. Titan Autonomy determines whether the exact actor/capability/context may proceed.
9. Cross-division work follows originating Manager → governed handoff → receiving Manager → receiving Specialist.
10. Tier 3 Action Worker prepares the final capability request.
11. Titan Command Bus performs the authoritative mutation.
12. A successful mutation must return an execution receipt.
13. Titan Signal records transitions.
14. **Titan Rewind** receives receipt/trace references.
15. **Titan Wisdom** receives observed outcome references.
16. CRM or the owning Titan domain remains authoritative truth.

## Acceptance Requirements

| Requirement | Workforce-side status | Enforcement |
|---|---|---|
| NO direct AI database mutation | PASS | AI runtime source policy disables business actions; final mutation path is Command Bus only. |
| NO uncontrolled cross-extension writes | PASS | External effects are adapter/capability calls; Workforce owns only organisational tables. |
| NO self-approval where separation of duties is required | PASS | Maker → Manager → receiving Manager chain is persisted and independently reviewed. |
| NO unexplained high-risk execution | PASS (Workforce boundary) | Risk decision is required in pre-execution governance; unavailable governance fails closed. |
| NO global autonomy escalation | PASS | Workforce maturity and staffing approval explicitly do not change authority or Titan Autonomy. |
| NO offline authority escalation | PASS (contract) | Workforce exposes no mechanism that increases authority because another engine/device is offline. |
| NO invisible workflow failure | PASS | BLOCKED, RECOVERY, ESCALATED, FAILED and task history remain visible in persistent work. |
| NO permanently stuck manager disagreement | PASS | Deadlock policy terminates in retry-with-evidence, return-to-maker, parent/Titan escalation, or human decision required. |
| NO completed mutation without an execution receipt | PASS | Command Bus execution without receipt moves the task to RECOVERY, never COMPLETED. |
| NO important decision without a trace | PASS | All tasks/signals/handoffs carry tenant, trace, correlation and causation references. |
| NO stale knowledge silently treated as current | EXTERNAL CONTRACT | Knowledge is referenced through external Knowledge Authority/Interaction/Vertical contracts; Workforce does not embed regulatory knowledge. |
| NO AI-reported success treated as real-world success without outcome validation | PASS (Workforce boundary) | Completion requires Command Bus receipt; Rewind/Wisdom references are captured for downstream outcome validation. |

## Engine Contract Matrix

| Engine | Workforce role | Boundary |
|---|---|---|
| Titan AI Core | Objective/model orchestration | Workforce consumes objectives; it does not duplicate Tier 0. |
| Titan Signal Engine | Event transport and telemetry | Workforce emits/consumes structured signals and preserves trace relationships. |
| Titan Risk Engine | Contextual/cumulative/vertical risk | Workforce consumes authoritative risk results; it does not calculate authoritative risk. |
| Titan Assurance | Evidence justification | Workforce consumes Assurance state/evidence references; it does not replace Assurance. |
| Titan Autonomy | Independent authority decision | Workforce consumes exact capability authority; maturity cannot raise Autonomy. |
| Titan Interaction Engine | Procedure/Wizard execution | Workforce references workflows/playbooks rather than cloning procedure engines. |
| Titan Command Bus | Authoritative mutation boundary | No consequential business mutation is considered complete without a Command Bus execution receipt. |
| Titan Rewind | Decision reconstruction | Workforce forwards receipt/trace references and exposes Rewind references in the Control Room. |
| Titan Wisdom | Outcome learning | Workforce forwards observed outcomes and exposes outcome references without self-modifying governance. |
| Titan Vertical Engine | Vertical overlays | Workforce accepts terminology/responsibility/workflow overlays but rejects authority/risk-ceiling escalation. |
| Titan Governance | Platform governance visibility | Workforce exposes organisation, queue, trust, staffing and performance health for governance consumption. |

## Final Live Platform Gate

When all peer engines are installed, run one real customer-to-completion scenario and prove the following from persistent records:

`Customer request → AI Core objective → Workforce Manager → Specialist → Interaction workflow → Risk → Assurance → Autonomy → cross-division handoff if required → Action Worker → Titan Command Bus → authoritative domain receipt → Titan Signal → Titan Rewind → Titan Wisdom`.

The live gate passes only when the same `trace_id`/`correlation_id` can reconstruct the full journey and the authoritative domain state matches the Command Bus receipt.


## Pass 9 chain-of-command evidence

- Immutable handoff packet: PASS — source result/evidence/governance/routing is canonicalised and SHA-256 bound before receiver review.
- Independent receiver acceptance: PASS — receiving Manager cannot be originating Maker/Manager and must explicitly accept or return.
- New receiving cycle: PASS — accepted handoff creates an idempotent child task with direct handoff causation.
- DAG integrity: PASS — parent existence and transitive dependency cycles are checked; chain integrity reports orphans/cycles.
