# Pass 14 — Role Capability Availability & Safe Degradation

This pass makes capability availability a live Workforce concern instead of treating the capability snapshot stored on a `WorkforceMember` as current authority.

## Canonical states

Every canonical role/member can resolve to one of six live domain-capability states:

- `available` — every matrix-pinned surface for the evaluated binding is currently published by an installed valid provider and is policy-enabled.
- `unavailable` — the provider is installed and valid, but none of the matrix-pinned surfaces are currently published.
- `degraded` — some, but not all, required surfaces are live; or a role has a mixture of usable and non-usable provider bindings.
- `blocked` — the provider appears installed but its contribution is invalid/unresolvable, or the role identity is not present in the canonical matrix.
- `missing_provider` — the canonical provider is not currently installed.
- `policy_disabled` — company/member policy has deliberately disabled the provider or surface.

## Safety invariants

1. `role_definition_id` is immutable input to availability. Provider loss never remaps an employee to another role.
2. The matrix and live provider surfaces grant availability only. `authority_inherited=false`, `fallback_authority_granted=false`, and `execution_authority_granted=false` are invariant.
3. Missing/degraded providers never fall back to a different provider unless the canonical matrix already binds that exact capability to that provider and it is live.
4. Work assignment, task creation and Autonomy evaluation re-check live availability; cached member capabilities are non-authoritative snapshots only.
5. Risk, Assurance, Governance, Autonomy and Command Bus remain mandatory for consequential execution after a capability is found available.

## Policy input

Member metadata may contain a non-authoritative `capability_policy` object:

```json
{
  "enabled": true,
  "disabled_providers": [],
  "disabled_surfaces": [],
  "disabled_capabilities": [],
  "disabled_tools": [],
  "disabled_commands": [],
  "disabled_signals": [],
  "disabled_data_sources": [],
  "disabled_workflows": []
}
```

Policy can only remove availability. It cannot add a provider, surface or authority.

## Runtime exposure

`WorkforceCapabilityAvailabilityService` is registered as:

- `titan.workforce.capability-availability`
- `titan-workforce.capability-availability`

Control Room organisation nodes expose each active employee's live capability state and full state detail. Member activation stores a `capability_state_snapshot` for provenance only; the snapshot is explicitly non-authoritative.
