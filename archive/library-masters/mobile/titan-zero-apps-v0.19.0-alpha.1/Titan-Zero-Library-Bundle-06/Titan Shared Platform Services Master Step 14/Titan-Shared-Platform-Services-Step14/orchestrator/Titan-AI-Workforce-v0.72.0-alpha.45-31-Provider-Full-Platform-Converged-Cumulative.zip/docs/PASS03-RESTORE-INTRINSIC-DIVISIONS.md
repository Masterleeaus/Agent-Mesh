# Integrated Upgrade Pass 3 — Restore the 15 Intrinsic Divisions

Pass 3 restores the v0.5.0-alpha.5 organisational division catalogue into the modern Workforce domain without restoring the 111 role definitions yet and without activating any company divisions.

## Canonical ownership

Titan AI Workforce now owns the 15 division definitions. Each definition has a stable `titan.division.<key>` identifier, historical key/name/purpose, a canonical manager role-definition reference, a definition-only team boundary, applicability metadata and explicit activation rules.

External extensions remain capability, tool, signal, data and execution providers. They do not define the organisation.

## Runtime behaviour boundary

The migration seeds only the global intrinsic definition table. Existing company division rows are linked to the matching definition by key when present. It does not create new company division instances and every restored definition has `auto_activate=false`. Role restoration and activation are deferred to subsequent planned passes.

## Historical source

- Donor: Titan AI Workforce v0.5.0-alpha.5
- Donor division catalogue SHA-256: `25b7094544948f45597feae43a724257d38524f1c99f5d03bc354cdc33b2b810`
- Restored definitions: 15
