# Pass 11 — Continuous Titan Autonomy Integration

Titan AI Workforce consumes Titan Autonomy's canonical Decision v2 contract. Workforce does not calculate earned authority and never owns runtime effective authority.

## Continuous authority

Authority is capability/variant/workflow/context specific on the canonical 0–100 scale:

- Suggest 0–15
- Assist 16–30
- Semi-Auto 31–50
- Auto 51–70
- Trusted Auto 71–85
- Predictive 86–100

There is **no global Trusted Auto** and no global Predictive switch. Every consequential execution obtains a fresh decision for the exact tenant, Workforce member, capability, capability variant, vertical, workflow and context.

Extension Workforce manifests may declare only a desired ceiling and conservative initial earned ceiling. Titan Autonomy remains the source of earned score, effective score, lifecycle, Predictive readiness, restrictions, approval requirements and policy version.

## Restrictive local policy only

Workforce validates that `effective_score <= desired_score` and `effective_score <= earned_score`. It validates the exact `autonomy_key` returned by Titan Autonomy and rejects mismatched capability/context decisions.

Workforce may reduce or deny authority for local execution constraints, but may never increase it. Offline operation follows the extension-owned capability offline policy. `OFFLINE_BLOCKED`, `OFFLINE_PREPARE_ONLY`, and `ONLINE_EXECUTE` deny offline mutation. `OFFLINE_EXECUTE` may apply an explicit lower `offline_authority_cap_score`; that cap can only reduce the external effective score.

Predictive work requires both the exact capability minimum and Predictive readiness. Predictive readiness never grants unrelated mutation authority and never bypasses Risk, Assurance, Interaction, Manager/receiver review, or Command Bus.

## Re-evaluation

Every pre-execution evaluation calls Titan Autonomy. The context binds current model/provider preferences through a deterministic fingerprint. A changed model/provider fingerprint emits `MODEL_PROVIDER_CHANGED` as a re-evaluation reason and produces a new capability context without globally resetting unrelated Autonomy evidence.

Workforce persists only decision references (decision ID, policy version, evaluated time and context/model fingerprints). It explicitly does not persist or mint runtime earned/effective scores on the Workforce member.

## Organisational isolation

Maturity (`JUNIOR/STANDARD/SENIOR/LEAD`), title, manager relationship, deputy/substitution coverage, tier and staffing changes do not raise effective authority. Deputy coverage has `authority_inherited=false`. Promotion evidence may be forwarded to external engines later, but Workforce cannot turn organisational status into Autonomy.

Organisational maturity remains evidence only and cannot raise authority.
