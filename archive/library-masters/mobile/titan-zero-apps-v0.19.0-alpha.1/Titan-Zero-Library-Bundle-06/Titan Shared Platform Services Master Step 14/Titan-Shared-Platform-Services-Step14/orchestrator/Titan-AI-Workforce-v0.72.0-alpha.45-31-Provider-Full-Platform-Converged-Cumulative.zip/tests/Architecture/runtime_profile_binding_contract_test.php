<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$files = [
    'System/Models/WorkforceRuntimeProfile.php',
    'System/Services/RuntimeProfileBindingService.php',
    'database/migrations/2026_08_21_000011_workforce_runtime_profiles.php',
    'docs/PASS05-WORKFORCE-RUNTIME-PROFILE-BINDING.md',
    'docs/TITAN-FOUR-SYSTEM-PASS05-RUNTIME-PROFILE-BINDING.json',
];
foreach ($files as $rel) $assert(is_file($root.'/'.$rel), 'missing Pass 5 file: '.$rel);

$model = @file_get_contents($root.'/System/Models/WorkforceRuntimeProfile.php') ?: '';
foreach (['ext_titan_ai_workforce_runtime_profiles','provider_policy','model_policy','memory_policy','channel_behavior','informational_tools','reasoning_config','scopeForCompany'] as $needle) {
    $assert(str_contains($model, $needle), 'runtime profile model missing '.$needle);
}

$migration = @file_get_contents($root.'/database/migrations/2026_08_21_000011_workforce_runtime_profiles.php') ?: '';
foreach (['company_id','profile_id','fingerprint','taiw_runtime_profile_company_id_unique','workforce-member-','informational_tools'] as $needle) {
    $assert(str_contains($migration, $needle), 'runtime profile migration missing '.$needle);
}
$assert(str_contains($migration, "'consequential_execution_authority' => 'none'"), 'legacy profile backfill must not grant execution authority');
$assert(str_contains($migration, "json_encode([], JSON_UNESCAPED_SLASHES)"), 'legacy profile backfill must start with zero informational tools');

$binding = @file_get_contents($root.'/System/Services/RuntimeProfileBindingService.php') ?: '';
foreach (['ensureForMember','forTask','runtimePayload','Workforce task cannot override its employee runtime profile','consequential_execution_authority','workforce-selected'] as $needle) {
    if ($needle === 'workforce-selected') continue;
    $assert(str_contains($binding, $needle), 'runtime profile binding missing '.$needle);
}
$assert(! str_contains($binding, 'ActionDispatcher'), 'runtime profile binding must not execute Agent actions');
$assert(! str_contains($binding, 'CommandBus'), 'runtime profile binding is configuration only and must not execute Command Bus');

$lifecycle = @file_get_contents($root.'/System/Services/WorkforceMemberLifecycleService.php') ?: '';
$assert(str_contains($lifecycle, 'RuntimeProfileBindingService $runtimeProfiles'), 'member lifecycle must depend on runtime profile binding service');
$assert(str_contains($lifecycle, 'ensureForMember($member, $definition, $input)'), 'new staff must receive a runtime profile at activation');

$bridge = @file_get_contents($root.'/System/Services/WorkforceAIRuntimeBridge.php') ?: '';
$assert(str_contains($bridge, 'RuntimeProfileBindingService $runtimeProfiles'), 'AI runtime bridge must resolve Workforce-owned runtime profile');
$assert(str_contains($bridge, "'runtime_profile' => \$this->runtimeProfiles->runtimePayload(\$profile)"), 'runtime request must carry the resolved profile payload');
$assert(str_contains($bridge, 'forTask($task, $member)'), 'runtime bridge must bind task to assignee profile before execution');

$identity = @file_get_contents($root.'/System/Runtime/RuntimeIdentity.php') ?: '';
$assert(str_contains($identity, 'missing its governed runtime_profile_id binding'), 'runtime identity must fail closed when member profile is missing');
$assert(str_contains($identity, 'cannot override its assignee profile'), 'runtime identity must reject task/member profile mismatch');

$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$assert(str_contains($provider, "'titan.workforce.runtime-profiles'"), 'stable Workforce runtime-profile service alias missing');

$assert(str_contains($identity, "'runtime_profile_id' => \$this->runtimeProfileId"), 'Workforce runtime identity must serialize runtime_profile_id through the stable v1 envelope');

$manifest = json_decode((string) file_get_contents($root.'/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$assert(in_array('titan-workforce.runtime-profiles-v1', $manifest['capabilities'] ?? [], true), 'manifest missing runtime-profiles-v1 capability');

if ($failures) {
    fwrite(STDERR, "FAIL: runtime profile binding contract\n".implode("\n", array_map(fn ($e) => ' - '.$e, $failures))."\n");
    exit(1);
}
fwrite(STDOUT, "PASS: coordinated Pass 5 Workforce runtime profile binding contract\n");
