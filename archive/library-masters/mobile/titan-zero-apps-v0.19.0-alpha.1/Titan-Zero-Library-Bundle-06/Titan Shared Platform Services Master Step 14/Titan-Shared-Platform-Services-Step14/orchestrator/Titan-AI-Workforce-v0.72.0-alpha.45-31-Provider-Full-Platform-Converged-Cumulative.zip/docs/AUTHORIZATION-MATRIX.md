# Titan AI Workforce Authorization Matrix

Titan AI Workforce follows the Blueprint Step-10 MagicAI host authorization contract.

## Host authorization resolution order

1. `isSuperAdmin()` — the only unconditional platform bypass.
2. Explicit permission via `can($permission)`.
3. Explicit permission via `checkPermission($permission)`.
4. Explicit permission via `hasPermissionTo($permission)`.
5. `isAdmin()` — only for the bounded Workforce permission set below.
6. Otherwise deny.

Authorization never supplies tenancy. Every authorized request must also resolve a canonical positive `company_id` from authenticated host state.

## Permission map

| Permission | Scope | Representative operations |
|---|---|---|
| `titan-workforce.read` | Read | Overview, Team, Work, Schedule, Performance, role/manifest/queue/trust APIs |
| `titan-workforce.staff.add` | Organisational mutation | Employee Builder / Add Staff Member |
| `titan-workforce.tasks.review` | Governed work mutation | submit, decompose, review, handoff, delegate action, councils, disputes |
| `titan-workforce.tasks.reassign` | Assignment mutation | governed task reassignment |
| `titan-workforce.staffing.approve` | Staffing governance | refresh, approve or reject Workforce Planning proposals |
| `titan-workforce.deadlocks.resolve` | Escalation governance | explicit deadlock resolution |
| `titan-workforce.control-room` | Sensitive operational visibility | Control Room UI/API |

MagicAI Admin fallback is bounded to exactly these permissions. Ordinary users require an explicit host permission. Super Admin still requires a valid tenant context before tenant-scoped data can be read or mutated.

## Tenant boundary

- `company_id` is the only canonical business tenant key.
- CRM/customer `company_id`, `team_id` and `user_id` are never reinterpreted or mathematically transformed into tenancy.
- Route-model bindings query within the authenticated `company_id`.
- Request IDs for members/divisions/managers are always re-resolved through `forCompany(...)`.
- Client/request payloads cannot provide authoritative `company_id`.
- Missing or ambiguous tenant context fails closed.

## Queues and schedules

`ProcessWorkforceTaskJob` and `ExecuteWorkforceActionJob` restore the immutable job `companyId` through `RestoreWorkforceTenantContext` middleware. Scheduler/outbox loops restore each persisted row's `company_id` before processing it. Nested code cannot switch to another tenant while a scope is active.

| Staff lifecycle suspend/resume/retire | `titan-workforce.staff.manage` | Explicit permission or bounded Admin fallback; tenant-scoped |

## Pass 8 organisation mutation

| Permission | Scope | Operations |
|---|---|---|
| `titan-workforce.organisation.manage` | Governed organisational mutation | change reporting Manager after cycle/RoleDefinition validation; appoint scoped, expiring deputy coverage |

Read-only organisation graph and extension-owned RACI surfaces remain covered by `titan-workforce.read`. RACI/deputy relationships never confer Command Bus, Risk, Assurance or Autonomy authority.
