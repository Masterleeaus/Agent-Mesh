# Pass 6 — AI Business Manager & Executive Layer

Pass 6 introduces `titan.executive.business_manager` beneath Titan Zero and above the fifteen intrinsic division managers.

Canonical chain:

`Owner → Titan Zero (Chief of Staff) → AI Business Manager → Division Managers → Teams`

The historic Operations Manager remains the daily cross-division operational coordinator. The historic internal `Chief of Staff` role remains at the same canonical role ID but is disambiguated as **Executive Operations Coordinator**, with `Chief of Staff` retained as an alias for migration compatibility. Titan Zero remains the only owner-facing Chief of Staff.

No role in this pass receives domain execution capabilities or authority inheritance. Risk, Assurance, Governance and Autonomy remain mandatory. Pass 6 defines and synchronises hierarchy only for already-active staff; it does not auto-hire the AI Business Manager or any division manager.
