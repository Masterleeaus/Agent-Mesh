# Pass 1 Signal Map

Canonical signal plane: `titan-signal-engine`

| Provider | Emitted | Subscribed | Known |
|---|---:|---:|---:|
| `crm` | 0 | 0 | 0 |
| `titan-ai` | 0 | 0 | 0 |
| `titan-ai-core` | 0 | 0 | 0 |
| `titan-ai-vision` | 0 | 0 | 0 |
| `titan-assets` | 0 | 0 | 0 |
| `titan-assurance` | 3 | 0 | 7 |
| `titan-autonomy` | 0 | 0 | 0 |
| `titan-command-bus` | 4 | 0 | 8 |
| `titan-connect` | 0 | 0 | 0 |
| `titan-field` | 0 | 0 | 0 |
| `titan-financial-engine` | 0 | 0 | 0 |
| `titan-forge` | 0 | 0 | 9 |
| `titan-governance` | 1 | 0 | 2 |
| `titan-interaction-engine` | 0 | 0 | 0 |
| `titan-knowledge-authority` | 0 | 0 | 0 |
| `titan-ledger` | 50 | 0 | 50 |
| `titan-locker` | 0 | 0 | 0 |
| `titan-maps-intelligence` | 0 | 0 | 0 |
| `titan-mcp` | 0 | 0 | 0 |
| `titan-model-council` | 5 | 0 | 10 |
| `titan-nexus` | 0 | 0 | 0 |
| `titan-prime` | 0 | 0 | 0 |
| `titan-rewind` | 16 | 0 | 16 |
| `titan-risk-engine` | 8 | 0 | 16 |
| `titan-shield` | 8 | 0 | 16 |
| `titan-signal-engine` | 6 | 0 | 9 |
| `titan-time-attendance` | 0 | 4 | 4 |
| `titan-wisdom` | 0 | 0 | 0 |
