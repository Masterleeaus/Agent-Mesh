# Pass 4 — Extension-Owned Workforce Registry Lifecycle

## Purpose

Titan AI Workforce does not own domain staff definitions. It must therefore survive contributing-extension activation, upgrade, disable and uninstall without corrupting the instantiated organisation or its history.

## Identity and pinning

A staff instance is pinned to the exact tuple:

- `role_owner_extension`
- `role_definition_id`
- `role_owner_extension_version`
- `role_definition_version`
- `role_definition_fingerprint`
- `role_definition_snapshot`

New tasks assigned to a staff member pin the same definition context at assignment time. Reassignment re-pins to the new assignee. Pre-Pass-4 historical tasks are deliberately not backfilled with guessed assignment-time provenance.

Display role names and aliases are **not** lifecycle identity. Titan never silently reassigns a historical staff member to a similarly named role from another extension.

## Lifecycle states

- `ACTIVE` — pinned contract exactly matches the currently available definition.
- `COMPATIBLE` — the owner/role still exists and the update is additive/non-breaking. Existing authority stays pinned; adopting the new definition requires an explicit rebind.
- `BREAKING` — capabilities/tools/workflows were removed, structural identity changed, or an authority/risk ceiling contracted. The staff member is made unavailable until reviewed.
- `MISSING` — the owner extension or exact role definition is unavailable. The staff member is made unavailable but retained.
- `LEGACY_PINNED` — a pre-Pass-4 staff instance was safely snapshotted during migration and awaits reconciliation.
- `CUSTOM` — non-extension custom staff remains outside extension-definition lifecycle reconciliation.

Changed definitions carry a 30-day deprecation/grace window for review. The window does not keep unsafe authority active and does not confer any new capability or Autonomy.

## History preservation

Historical tasks are never deleted by extension lifecycle reconciliation. Task history, handoffs, execution receipts, review evidence and Rewind/Wisdom references are preserved. Disable/uninstall affects future assignment eligibility only.

## Registry invalidation

The central registry exposes `suppressExtension`, `restoreExtension`, `invalidateExtension`, and exact `findOwnedRole` methods. The service provider exposes a stable `titan.workforce.manifest-lifecycle` adapter and listens for:

- `titan.extension.activated`
- `titan.extension.upgraded`
- `titan.extension.disabled`
- `titan.extension.uninstalled`

Operators can also run `php artisan titan-workforce:reconcile-definitions [extension-key]` after lifecycle operations or host migrations.

## Compatibility rule

Additions are compatible but never auto-applied to existing staff. Removals and structural/authority contractions are breaking and fail closed. Reinstalling an identical definition restores lifecycle-suspended staff deterministically while preserving any unrelated manual suspension state.
