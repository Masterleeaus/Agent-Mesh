<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

foreach ([
    'System/Enums/WorkforceCapabilityState.php',
    'System/Support/WorkforceCapabilityStateResolver.php',
    'System/Services/WorkforceCapabilityAvailabilityService.php',
    'docs/PASS14-ROLE-CAPABILITY-AVAILABILITY-SAFE-DEGRADATION.md',
    'schemas/workforce-capability-state.schema.json',
] as $path) {
    $ok(is_file($root . '/' . $path), "Step 4 artifact missing: {$path}");
}

$enumPath = $root . '/System/Enums/WorkforceCapabilityState.php';
$resolverPath = $root . '/System/Support/WorkforceCapabilityStateResolver.php';
if (is_file($enumPath) && is_file($resolverPath)) {
    require_once $enumPath;
    require_once $resolverPath;
    $resolver = new \App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityStateResolver();

    $base = [
        'required' => ['field.job.read', 'field.job.assign'],
        'published' => ['field.job.read', 'field.job.assign'],
        'provider_installed' => true,
        'contribution_valid' => true,
        'policy_enabled' => true,
    ];
    $ok($resolver->classify($base)->value === 'available', 'complete installed binding must be available');
    $ok($resolver->classify([...$base, 'provider_installed' => false, 'published' => []])->value === 'missing_provider', 'missing provider must be explicit');
    $ok($resolver->classify([...$base, 'contribution_valid' => false, 'published' => []])->value === 'blocked', 'installed invalid provider contribution must be blocked');
    $ok($resolver->classify([...$base, 'published' => ['field.job.read']])->value === 'degraded', 'partial published surface must be degraded');
    $ok($resolver->classify([...$base, 'published' => []])->value === 'unavailable', 'installed provider with no required surfaces must be unavailable');
    $ok($resolver->classify([...$base, 'policy_enabled' => false])->value === 'policy_disabled', 'policy-disabled binding must be explicit');
}


$schemaPath = $root . '/schemas/workforce-capability-state.schema.json';
if (is_file($schemaPath)) {
    $schema = json_decode((string) file_get_contents($schemaPath), true, flags: JSON_THROW_ON_ERROR);
    $states = (array) ($schema['properties']['state']['enum'] ?? []);
    foreach (['available','unavailable','degraded','blocked','missing_provider','policy_disabled'] as $state) {
        $ok(in_array($state, $states, true), "capability-state schema missing {$state}");
    }
    $ok(($schema['properties']['role_identity_immutable']['const'] ?? null) === true, 'capability-state schema must lock role identity immutable');
    $ok(($schema['properties']['authority_inherited']['const'] ?? null) === false, 'capability-state schema must prohibit authority inheritance');
    $ok(($schema['properties']['fallback_authority_granted']['const'] ?? null) === false, 'capability-state schema must prohibit fallback authority');
}

$service = is_file($root . '/System/Services/WorkforceCapabilityAvailabilityService.php')
    ? (string) file_get_contents($root . '/System/Services/WorkforceCapabilityAvailabilityService.php') : '';
foreach (['forRole', 'forMember', 'capabilityState', 'isCapabilityAvailable', 'assertCapabilityAvailable'] as $method) {
    $ok(str_contains($service, "function {$method}"), "availability service missing {$method}");
}
foreach (['available','unavailable','degraded','blocked','missing_provider','policy_disabled'] as $state) {
    $ok(str_contains($service, $state) || (is_file($enumPath) && str_contains((string) file_get_contents($enumPath), $state)), "capability state {$state} missing");
}
$ok(str_contains($service, 'role_identity_immutable'), 'live state must explicitly preserve immutable role identity');
$ok(str_contains($service, 'fallback_authority_granted'), 'live state must explicitly prove no fallback authority');
$ok(str_contains($service, 'selected_provider'), 'availability assertion must return the canonical selected provider');
$ok(str_contains($service, 'authority_inherited'), 'live state must explicitly prove no authority inheritance');

$bindingRegistry = (string) file_get_contents($root . '/System/Support/WorkforceCapabilityBindingRegistry.php');
$ok(str_contains($bindingRegistry, 'effectiveAccessForRole'), 'binding registry effective access must remain available');
$ok(str_contains($bindingRegistry, 'function invalidate'), 'binding registry must expose lifecycle cache invalidation');
$ok(str_contains($bindingRegistry, 'isSuppressedExtension'), 'binding registry must exclude lifecycle-disabled providers even when their PHP class is still autoloadable');
$ok(str_contains($bindingRegistry, "'authority_inherited' = false") || str_contains($bindingRegistry, "['authority_inherited'] = false") || str_contains($bindingRegistry, "'authority_inherited' => false"), 'binding registry must remain non-authoritative');


$manifestRegistrySource = (string) file_get_contents($root . '/System/Support/WorkforceManifestRegistry.php');
$ok(str_contains($manifestRegistrySource, 'function isSuppressedExtension'), 'manifest registry must expose provider lifecycle suppression state');

$taskService = (string) file_get_contents($root . '/System/Services/WorkforceTaskService.php');
$workloadService = (string) file_get_contents($root . '/System/Services/WorkloadSharingService.php');
$autonomyService = (string) file_get_contents($root . '/System/Services/WorkforceAutonomyService.php');
foreach ([
    'WorkforceTaskService.php' => $taskService,
    'WorkloadSharingService.php' => $workloadService,
    'WorkforceAutonomyService.php' => $autonomyService,
] as $name => $source) {
    $ok(str_contains($source, 'WorkforceCapabilityAvailabilityService'), "{$name} must use live capability availability rather than stale member capabilities");
}
$ok(! str_contains($workloadService, "in_array(\$requiredCapability, \$member->capabilities"), 'workload sharing must not authorize from cached member capabilities');
$ok(str_contains($taskService, "['selected_provider']" ) || str_contains($taskService, "'selected_provider'"), 'task creation must persist canonical selected provider identity');



$controller = (string) file_get_contents($root . '/System/Http/Controllers/WorkforceController.php');
$ok(str_contains($controller, 'WorkforceCapabilityAvailabilityService'), 'Employee Builder must consume live capability availability');
$ok(str_contains($controller, "'capability_state'"), 'Employee Builder role catalogue must expose capability_state');
$ok(str_contains($controller, "'capability_policy' => ['nullable','array']"), 'Employee creation must preserve restrictive capability policy input');

$controlRoom = (string) file_get_contents($root . '/System/Services/WorkforceControlRoomService.php');
$ok(str_contains($controlRoom, 'WorkforceCapabilityAvailabilityService'), 'Control Room must compute live capability state for every active employee');
$ok(str_contains($controlRoom, "'capability_state'"), 'Control Room organisation nodes must expose live capability state');

$lifecycle = (string) file_get_contents($root . '/System/Services/WorkforceMemberLifecycleService.php');
$ok(str_contains($lifecycle, 'capability_state_snapshot'), 'member activation must store a non-authoritative capability-state snapshot');
$ok(str_contains($lifecycle, "'role_owner_extension' => 'titan-ai-workforce'"), 'missing providers must not change intrinsic role owner identity');

$provider = (string) file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
$ok(str_contains($provider, 'WorkforceCapabilityAvailabilityService::class'), 'service provider must register live capability availability service');
$ok(str_contains($provider, 'titan.workforce.capability-availability'), 'service provider must expose capability availability adapter');
$ok(substr_count($provider, '->invalidate()') >= 4, 'extension lifecycle events must invalidate live capability bindings');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$ok(in_array('titan-workforce.capability-availability-v1', $manifest['capabilities'] ?? [], true), 'extension manifest missing capability availability capability');

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce role capability availability and safe degradation contract\n";
