# Titan AI Workforce — Intrinsic Business Team + Titan Zero Chief of Staff

**Date:** 2026-08-21  
**Plan ID:** `4afc3d5e-78c4-4d7a-9a1f-b7526d5b7032`  
**Runtime baseline:** Titan AI Workforce `0.27.0-alpha.27`  
**Intrinsic-team donor:** Titan AI Workforce `0.5.0-alpha.5`  
**Target next line:** `0.28.x` intrinsic-team convergence

## 1. Decision

Titan AI Workforce is the canonical owner of the digital organisation. It owns the intrinsic role catalogue, divisions, teams, reporting structure, responsibilities, operating routines, RACI/decision rights, delegation, handoffs, escalations, councils, workforce tasks, staffing policies and performance.

Installed Titan extensions do **not** own the organisation. They own domain capabilities, tools, events, data and authoritative mutations. Workforce binds those capabilities into intrinsic roles.

The user-facing Chief of Staff is **Titan Zero**. Titan Zero is the single conversational front door to the business. It interprets owner intent, creates objectives, delegates into the Workforce hierarchy, aggregates results, routes approvals, surfaces exceptions and explains decisions. Titan Zero may coordinate the whole organisation but may not bypass Risk, Assurance, Governance, Autonomy, Command Bus or domain authority.

## 2. Source material and scan scope

The design is based on:

- current Workforce `0.27.0-alpha.27` modern runtime/governance stack;
- Workforce `0.5.0-alpha.5` intrinsic organisation donor;
- `Extensions (1).zip`;
- `Extensions2.zip`;
- 28 unique relevant Titan extension identities after de-duplicating the later Knowledge Authority hotfix.

The combined extension inventory is recorded in `docs/INTEGRATION-CAPABILITY-INVENTORY.json`.

## 3. Preserved v0.5 organisation

The intrinsic donor contains:

- 15 divisions;
- 111 canonical roles;
- 19 scheduled proactive routines;
- 44 event-driven routines;
- Daily Ops Council;
- Weekly Performance Review;
- dispute routing;
- RACI-style decision rights;
- maturity and promotion policy;
- workload sharing rules;
- vertical team packs.

These definitions return to Workforce ownership. They are modernised rather than copied blindly.

### 3.1 Titan Zero identity

The historical `chief-of-staff` role is promoted to the permanent system-facing identity **Titan Zero — Chief of Staff**. The compatibility key/alias for the historical role is retained so old references can migrate deterministically.

Titan Zero is active for every business tier. As the permanent system Chief of Staff, Titan Zero does **not** consume a company staffing/entitlement slot; role activation limits apply to the operational workforce beneath it. It is not a free-floating super-agent and it cannot self-grant authority.

### 3.2 Executive chain

Canonical high-level chain:

```text
Human Owner / Authorised Management
            |
            v
Titan Zero — Chief of Staff
            |
            v
Operations Manager / Business Operations Lead
            |
   +--------+--------+-------------------+
   |        |        |                   |
Customer  Service  Finance            Workforce
Manager   Manager  Manager            Manager
   |        |        |                   |
  ...      ...      ...                 ...
```

Other division managers participate through councils and governed cross-division objectives. Titan Zero coordinates them but does not inherit their domain authority.

## 4. Architectural layers

### 4.1 Human interaction layer

**Titan Zero** is the only normal conversational employee the owner needs to address.

Responsibilities:

- translate natural language into typed objectives and temporary policies;
- ask the organisation for analysis or work rather than performing every specialist task personally;
- preserve owner attention by aggregating routine activity;
- route approval requests;
- summarise business health, risks, opportunities and unresolved work;
- explain the causal chain behind any significant action;
- maintain conversation-to-objective lineage.

Titan Interaction Engine supplies structured journeys, approvals, offline/local guidance and cross-surface interaction semantics. Titan AI Runtime supplies model execution. Titan AI Core supplies typed planning semantics. Titan Prime supplies durable strategic mission semantics where missions span multiple departments or long horizons.

### 4.2 Organisational layer — Titan AI Workforce

Workforce owns:

- `Organisation`
- `Division`
- `Team`
- `RoleDefinition`
- `WorkforceMember`
- `ReportingRelationship`
- `Responsibility`
- `Routine`
- `Council`
- `DecisionRight`
- `WorkItem` / `WorkforceTask`
- `WorkType`
- `Delegation`
- `Handoff`
- `Escalation`
- `StaffingProposal`
- `PerformanceMetric`
- runtime profile bindings

Workforce answers **who owns the situation, who is accountable, who may collaborate, and where work should go next**.

### 4.3 Sensory layer — Titan Signal Engine

Signal is the canonical event fabric. Workforce subscribes to registered domain signals and translates relevant facts into responsibility-scoped observations or work. Signal itself never becomes business truth and never confers authority.

### 4.4 Reasoning layer

- **Titan AI Runtime:** executes individual workforce-member reasoning/runtime profiles.
- **Titan AI Core:** typed orchestration-planning contracts for multi-step objectives.
- **Titan Model Council:** optional/advisory multi-model deliberation for high uncertainty, contradiction or configured decision classes.
- **Titan Knowledge Authority:** verified/versioned knowledge context.
- **Titan AI Vision:** visual evidence analysis for field, quality, safety, assets and completion evidence.

### 4.5 Control plane

Consequential action path:

```text
Workforce proposal
    -> Titan Risk
    -> Titan Assurance
    -> Titan Governance policy/oversight
    -> Titan Autonomy effective authority
    -> Titan Command Bus
    -> authoritative domain capability
    -> execution receipt
    -> outcome verification
    -> Rewind evidence + Wisdom outcome
```

No role, including Titan Zero, may bypass this path.

### 4.6 Business-domain providers

The business-domain extensions own their data and mutations. Workforce binds their capabilities to intrinsic staff:

- CRM;
- Titan Field;
- Titan Connect;
- Titan Ledger;
- Titan Financial Engine;
- Titan Assets;
- Titan Locker;
- Titan Maps Intelligence;
- Titan Time & Attendance.

### 4.7 Platform/configuration providers

- Titan Nexus: business-profile compilation, configuration history and governed provisioning;
- Titan Forge: deterministic build/workforce scaffold validation and controlled artifact workflows;
- Titan MCP: technical inspection/maintenance tool surface;
- Titan Shield: governed inspection/rule/remediation preparation;
- Titan Rewind: forensic reconstruction/recovery;
- Titan Wisdom: outcome recording/resolution/learning evidence;
- Titan Prime: strategic mission persistence/gateway layer.

## 5. Full extension integration map

All extensions supplied by the user are included in the target design.

| Extension | Workforce use | Primary intrinsic roles / consumers |
|---|---|---|
| `crm` | customer, company, lead, deal, pipeline, task, calendar, sales/receivables context; canonical CRM-only authority | Receptionist, Booking Coordinator, Customer Service, Customer Care, Sales Manager, Sales Coordinator, Sales Rep, Quote Coordinator, Business Development, Commercial Accounts, Customer Insights, Office Manager |
| `titan-interaction-engine` | structured owner/customer/worker interactions, journeys, approvals, onboarding, offline/local guidance | Titan Zero, Receptionist, Booking Coordinator, Customer Care, Office Manager, Workflow Coordinator |
| `titan-ai` | workforce-member AI runtime, governed tools, memory/knowledge/context/provider bridge | all AI members; especially Titan Zero and managers |
| `titan-ai-core` | typed objective/plan contracts and orchestration planning | Titan Zero, Operations Manager, Strategy Coordinator, Project Manager |
| `titan-prime` | durable strategic missions spanning teams/engines | Titan Zero, Operations Manager, Strategy Coordinator |
| `titan-signal-engine` | sensory/event nervous system, correlation, pulse and anomalies | all responsibility triggers; Operations, BI, Incident, Workflow Performance |
| `titan-risk-engine` | risk assessment, gates, aggregate exposure, velocity, circuits | Risk Manager, Risk & Assurance Liaison, all managers before consequential action |
| `titan-assurance` | evidence strength/calibration/recollection | Assurance Coordinator, Quality Coordinator, Compliance roles, managers |
| `titan-governance` | policy/oversight, escalation queue, authority constraints, human decisions | Titan Zero, Compliance & Governance Manager, owner/authorised humans |
| `titan-autonomy` | desired/earned/effective delegated authority and outcome reconciliation | every AI member/action; workforce maturity/authority projection |
| `titan-command-bus` | sole consequential mutation transport and durable receipts | every action-capable role; no direct foreign-domain writes |
| `titan-rewind` | reconstruction, root cause, evidence, recovery planning | Incident Coordinator, Risk Manager, Data Governance, Titan Zero |
| `titan-wisdom` | delayed verified outcomes and evidence-linked learning | BI Manager, Performance Analyst, Process Improvement, managers |
| `titan-model-council` | advisory deliberation when uncertainty/contradiction warrants | Titan Zero, managers, Risk, Assurance, Strategy |
| `titan-knowledge-authority` | trusted/versioned source metadata and future governed knowledge resolution | Records Manager, Document Controller, Compliance, all reasoning roles |
| `titan-ai-vision` | visual evidence, before/after, quality/safety/asset condition | Quality, H&S, Field Coordinator, Job Completion, Asset Maintenance, Property Handover |
| `titan-shield` | deterministic inspection/rule/governance response/remediation preparation | Compliance, H&S, Quality, Incident, Risk |
| `titan-field` | authoritative service requests, work orders, schedule, dispatch, recurring work, evidence/forms | Service Manager, Scheduler, Dispatcher, Job Coordinator, Field Coordinator, Work Planner, Completion, Quality, Maintenance, Emergency Service |
| `titan-connect` | omnichannel inbox, team chat, external messaging, voice/operator communication | Titan Zero, Receptionist, Customer Service, Booking, Customer Care, After-Hours, Service Recovery, Dispatcher |
| `titan-maps-intelligence` | routes, ETA, travel matrix, service areas, territories, geofencing/location evidence | Scheduler, Dispatcher, Field Coordinator, Sales/territory roles, Roster/crew planning |
| `titan-assets` | individually tracked assets/tools/equipment/vehicles, custody, maintenance, lifecycle | Assets Manager, Equipment, Fleet, Asset Maintenance, Field Coordinator |
| `titan-locker` | stock/SKU/consumables, locations, movements, suppliers, POs, receipts, counts, transfers | Inventory Coordinator, Purchasing Officer, Procurement Manager/Coordinator, Materials Planner, Supplier Relations |
| `titan-time-attendance` | time entries, timers, attendance evidence, policies, exceptions | Workforce Manager, Roster Coordinator, Crew Coordinator, H&S/Compliance, Time-attendance specialist functions |
| `titan-financial-engine` | pricing, estimating, job costing, margins, tax calculations, forecasting, landed cost | Estimator, Quote Coordinator, Cost Controller, Finance Manager, Revenue Analyst, Procurement/Materials Planner |
| `titan-ledger` | authoritative accounting, journals, GST/BAS, banking, reconciliation, fiscal close | Finance Manager, Billing, AR, AP, Bookkeeper, Cost Controller, Credit/Disputes |
| `titan-nexus` | company/vertical configuration compiler and governed provisioning | Titan Zero, Office Manager, Strategy Coordinator, Change Coordinator, Automation Manager |
| `titan-forge` | deterministic workforce/build scaffolding, validation, release governance, reconstruction source | Automation Manager, Systems Integration Coordinator, Automation QA, Process Improvement |
| `titan-mcp` | controlled technical project/repository/schema/runtime/backup/command tooling | Automation Manager, Systems Integration Coordinator, Workflow/Automation Quality roles |

The duplicate Knowledge Authority package is resolved to the later Pass4-H2 navigation-compatible build while preserving its domain version `0.5.0-alpha.4`.

## 6. Role ownership vs capability ownership

### Workforce-owned

Intrinsic role definitions, including title, purpose, division/team, reporting line, responsibilities, default routines, escalation path, risk ceiling recommendation, activation policy and role compatibility aliases.

### Extension-owned

Capabilities, tools, authoritative records, action semantics, event schemas, data access contracts, command adapters and execution receipts.

### Capability binding

Workforce adds a first-class binding registry:

```text
RoleCapabilityBinding
- role_definition_id
- provider_extension
- provider_capability
- mode: read | propose | command
- work_types[]
- risk_class
- requires_assurance
- requires_command_bus
- required_permissions[]
- availability_probe
- compatibility_aliases[]
```

No capability binding increases Autonomy authority; it only establishes that a role is eligible to request/use a provider capability when all other gates permit it.

## 7. External workforce manifests transition

Two supplied extensions currently ship live workforce roles:

- Titan Field: 3 role definitions;
- Titan Time & Attendance: 4 role definitions.

Under the intrinsic model these manifests are migrated from **role ownership** to **capability contribution**.

Examples:

- `field-dispatch-manager` capability set binds primarily to intrinsic `service-manager`, `scheduler`, and `dispatcher` rather than creating a duplicate field manager.
- Time & Attendance manager/specialist capabilities bind to intrinsic `workforce-manager`, `roster-coordinator`, `compliance-coordinator`, `crew-coordinator`, and appropriate specialist overlays.

Legacy external role IDs remain migration aliases only so existing persisted staff/work can be reconciled without data loss.

## 8. Business workflow model

Every autonomous business loop follows:

```text
Signal / schedule / owner objective / delegated objective
    -> Observation
    -> responsibility routing
    -> WorkItem
    -> manager/specialist reasoning
    -> structured Action Proposal
    -> Risk
    -> Assurance
    -> Governance
    -> Autonomy
    -> Command Bus
    -> domain execution
    -> receipt/evidence
    -> verify outcome
    -> Wisdom
    -> performance / future policy recommendation
```

Routine observations that require no action close without generating noise.

## 9. Work types

Add first-class `work_type` separate from capability:

- `objective`
- `observation`
- `analysis`
- `communication`
- `customer_intake`
- `booking`
- `scheduling`
- `dispatch`
- `job_coordination`
- `quality_review`
- `evidence_request`
- `maintenance`
- `quote`
- `pricing`
- `billing`
- `receivables`
- `payables`
- `reconciliation`
- `procurement`
- `inventory`
- `asset_action`
- `time_attendance`
- `workforce_action`
- `compliance`
- `safety`
- `decision`
- `approval_request`
- `handoff`
- `escalation`
- `incident`
- `management_review`
- `report`
- `configuration`
- `technical_maintenance`

## 10. Titan Zero operating model

Titan Zero must be the attention firewall between the owner and the internal organisation.

### Titan Zero surfaces to the owner

- decisions that require owner authority;
- high/critical risk exceptions;
- material financial commitments/opportunities;
- unresolved customer or workforce issues;
- major system/control degradation;
- concise morning, live-exception and end-of-day briefs;
- explanations on demand.

### Titan Zero normally suppresses

- routine successful jobs;
- low-risk messages;
- ordinary booking confirmations;
- normal billing/receipt lifecycle;
- internal agent chatter;
- successful delegated handoffs.

All suppressed activity remains auditable in Workforce Control Room / Rewind / Signal lineage.

## 11. Team activation

The 111-role catalogue is intrinsic but not all roles are activated for every company. The catalogue retains the Marketing division as organisational coverage, but Workforce does not recreate a marketing-generation/social engine; those roles coordinate/delegate to the separate marketing/social capability providers when installed.

Recommended team templates are Workforce-owned. The historical Forge six-role Solo seed remains useful but its current hard-coded 68-role enterprise assumption must be updated.

Initial templates:

- `solo`: Titan Zero plus a compact operational team;
- `small_business`: front office + service + billing + basic people/assets coverage;
- `growing`: division managers and specialists;
- `enterprise`: all applicable core and vertical roles.

The exact active roster is determined by business profile, vertical, installed capabilities, operating hours, staff count, transaction volume and owner preferences. Workforce may recommend hiring/activation but must not self-hire unless a separately governed provisioning policy explicitly permits it.

## 12. Compatibility issues found in the supplied ecosystem

### 12.1 Titan AI Runtime version mismatch

Current Workforce requires `titan-ai >=1.5.3`; supplied Titan AI Runtime is `1.5.2`.

Target resolution: maintain a compatibility adapter only if 1.5.2 satisfies the runtime contract under tests; otherwise make `1.5.3+` a release prerequisite. Do not silently lower a required version merely to make installation pass.

### 12.2 Forge role-count drift

Forge `0.9.0-alpha.1` hard-codes `expected_canonical_role_count = 68` and enterprise role limit 68. The intrinsic Workforce donor contains 111 canonical roles.

Target resolution: Workforce 111-role catalogue is canonical. Forge receives a compatibility delta to consume a versioned Workforce team-template contract and must stop asserting 68 as the universal role count.

### 12.3 External-role ownership drift

Field and Time & Attendance still say role definitions are extension-owned. This conflicts with the selected intrinsic-team architecture.

Target resolution: retain their tools/capabilities/workflows, convert live roles into binding contributions/aliases.

### 12.4 Tenant-name drift

Workforce and the modern product model use `company_id` as the canonical company boundary. Several peer engines still expose `tenant_company_id` in legacy/public envelopes or compatibility stores.

Target resolution:

- Workforce persistence, identity, authorization, tasks, bindings and UI use `company_id` only;
- peer adapters may translate to `tenant_company_id` only where the peer's published legacy contract still requires it;
- translated values are derived from trusted `company_id`, never accepted independently from prompts/request payloads;
- no new Workforce schema or business contract introduces `tenant_company_id`.

### 12.5 Signal package identity drift

Some peers describe canonical Signal as `titan-signal`, while the supplied package identifies as `titan-signal-engine`.

Target resolution: versioned peer-identity alias adapter at the integration boundary; no duplicate Signal engine.

### 12.6 CRM extracted-domain compatibility capabilities

CRM still advertises compatibility capability names for domains now owned by Field, Assets, Locker, Ledger and other extracted authorities.

Target resolution: Workforce binds to the canonical owning extension first. CRM compatibility aliases are migration/fallback aliases only and cannot create a second write authority.

### 12.7 Financial Engine public capability gap

Titan Financial Engine has strong deterministic calculation/quote services but does not advertise the same formal capability-manifest surface as newer Titan extensions.

Target resolution: define a small public financial capability adapter/contract (or companion delta) before autonomous execution. Workforce must not bypass its public boundary by importing controllers or writing Financial Engine tables directly.

## 13. Dependency/readiness modes

Do not make every business module a hard installer dependency. Instead define readiness tiers:

### `CORE_READY`
Workforce + Titan AI runtime available; organisation can be configured but consequential autonomy remains restricted.

### `GOVERNED_READY`
Signal + Risk + Assurance + Governance + Autonomy + Command Bus healthy. Workforce may execute only capabilities with valid domain bindings.

### `BUSINESS_READY`
Required business-domain providers for the company's selected vertical/team are healthy.

### `FULL_BUSINESS_AUTONOMY`
All configured critical providers plus Rewind/Wisdom/Knowledge are healthy and the company's autonomy policy permits execution.

A missing or degraded control-plane engine never upgrades authority. The system degrades to observe/recommend/approval as necessary.

## 14. Data model changes to v0.27

Add or formalise:

- intrinsic `RoleDefinition` store/catalogue;
- intrinsic division/team definitions;
- `RoleCapabilityBinding`;
- `WorkType` / `work_type` on WorkforceTask;
- `Objective` metadata or parent objective semantics;
- `CouncilDefinition` and council-run records;
- `DecisionRight` / RACI definitions;
- role aliases for external-manifest migration;
- provider readiness/capability availability projection;
- Titan Zero system-role metadata;
- owner attention/escalation policy.

Preserve v0.27:

- `company_id` tenancy;
- runtime profiles;
- canonical runtime identity;
- chain of command;
- task dependencies;
- handoffs;
- execution attempts;
- journey records;
- staffing proposals;
- Risk/Assurance/Autonomy/Command Bus flow;
- Signal/Rewind/Wisdom outcome spine;
- Control Room.

## 15. Migration rules

1. Existing v0.27 Workforce members remain intact.
2. Historical/external role IDs map to intrinsic role aliases where semantically equivalent.
3. No member is automatically granted new execution authority because a role moved to intrinsic ownership.
4. Existing autonomy grants remain owned/evaluated by Titan Autonomy.
5. Existing tasks keep their historical role/definition fingerprints; new tasks use intrinsic definitions.
6. v0.5 resources are imported as new versioned canonical definitions, not copied with old tenancy/runtime assumptions.
7. External Field/Time Attendance role manifests remain readable during a compatibility window but are no longer authoritative for role identity.

## 16. Security invariants

- `company_id` is derived from trusted runtime/auth context.
- prompts cannot supply company, actor, authority or causal identity.
- capability availability is not authority.
- capability binding is not authority.
- role assignment is not authority.
- manager status is not authority.
- Titan Zero is not a bypass identity.
- cross-division delegation does not inherit the recipient's authority back to the sender.
- foreign-domain mutations go through Command Bus and authoritative adapters.
- action completion requires verified receipts/outcomes where consequential.
- retries use stable operation/idempotency identity.
- high-risk or uncertain actions fail closed or escalate.
- AI hidden reasoning is never stored as governance evidence; structured reasons/evidence references are stored instead.

## 17. Testing strategy

### Static/package

- PHP lint all extension files;
- JSON/schema validation;
- manifest/integrity verification;
- role catalogue count and unique IDs;
- reporting graph acyclicity;
- no duplicate capability authority;
- no new `tenant_company_id` Workforce contracts;
- route/menu validation.

### Contract

One contract suite per supplied extension verifies:

- installed identity/version;
- capability/readiness discovery;
- role-binding coverage;
- Signal event registration/subscription mapping;
- command execution boundary;
- tenant translation when legacy peer contracts require it;
- fail-closed behavior.

### End-to-end

Required journeys include:

1. owner asks Titan Zero for morning business status;
2. new enquiry -> Reception -> qualification/booking -> scheduling;
3. worker absence -> roster -> scheduler/dispatcher -> customer notification;
4. job completion -> Vision/evidence/QA -> billing -> Ledger;
5. overdue invoice -> AR -> Connect follow-up -> payment/outcome;
6. low stock -> materials planning -> procurement -> approval/PO;
7. safety/compliance finding -> Shield/Risk/Assurance/Governance -> escalation;
8. route disruption -> Maps + Field -> governed reschedule;
9. high-uncertainty decision -> Model Council advisory -> governance path;
10. execution receipt gap -> Rewind reconstruction -> Incident escalation;
11. verified outcome -> Wisdom -> performance/learning recommendation;
12. owner asks Titan Zero "why did you do that?" -> causal explanation from receipts/evidence.

### Production certification

No production-complete claim until real Laravel/MySQL/queue/scheduler integration tests pass on the target host. Static architecture tests alone are insufficient.

## 18. Recommended implementation order

1. intrinsic definition foundation;
2. Titan Zero system role;
3. 111-role/division import with aliases;
4. capability-binding registry;
5. supplied-extension adapters/inventory;
6. Field + CRM + Connect + Maps operational workflow;
7. Finance/Ledger workflow;
8. People/Time Attendance workflow;
9. Assets/Locker/Procurement workflow;
10. Vision/Shield/Compliance workflow;
11. Signal/Risk/Assurance/Governance/Autonomy/Command Bus convergence;
12. Rewind/Wisdom/Knowledge/Model Council feedback loop;
13. Nexus/Forge/MCP system operations;
14. team templates and activation;
15. Titan Zero briefings/attention policy;
16. full E2E and host certification.

## 19. Acceptance criteria

The design is complete when:

- Workforce owns one coherent intrinsic business organisation;
- Titan Zero is the single normal owner-facing Chief of Staff;
- the complete v0.5 role coverage is available intrinsically;
- all 28 supplied extension identities have explicit integration ownership and role bindings;
- no extension can redefine the organisation by registering duplicate authoritative roles;
- every consequential action is governed and receipted;
- cross-department work uses reporting/delegation/handoff semantics;
- a user can operate the business through Titan Zero without selecting individual agents;
- the owner can inspect the underlying organisation when desired;
- the system can explain consequential actions with causal/evidence lineage;
- missing/degraded engines reduce autonomy rather than increase it.
