<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
function ok_pass4(bool $condition, string $message): void { if (! $condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } }
$contract = json_decode((string) file_get_contents($root . '/docs/TITAN-THREE-SYSTEM-PASS04-TITAN-AGENT-RUNTIME.json'), true, flags: JSON_THROW_ON_ERROR);
ok_pass4(($contract['plan_id'] ?? null) === '6bb234ac-d390-4a3f-8be2-666f5dec8a81', 'PLAN_ID mismatch');
ok_pass4(($contract['pass'] ?? null) === 4, 'pass mismatch');
ok_pass4(($contract['transport'] ?? null) === 'titan.agent-runtime.transport/1', 'runtime transport mismatch');
$gateway = (string) file_get_contents($root . '/System/Services/AgentRuntimeGateway.php');
ok_pass4(str_contains($gateway, 'WorkforceControlPlaneIntegrationRegistry') && str_contains($gateway, "bindingsFor('ai_runtime')"), 'canonical late-bound runtime registry missing');
ok_pass4(str_contains($gateway, 'RuntimeResponse::fromArray'), 'wire response validation missing');
ok_pass4(! str_contains($gateway, 'App\\Extensions\\AIAgent'), 'Workforce must not import Agent implementation namespace');
$response = (string) file_get_contents($root . '/System/Runtime/RuntimeResponse.php');
ok_pass4(str_contains($response, 'authoritative_business_execution'), 'authoritative execution rejection missing');
$proposal = (string) file_get_contents($root . '/System/Runtime/RuntimeToolProposal.php');
ok_pass4(str_contains($proposal, 'execution_claimed'), 'tool execution claim rejection missing');
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
ok_pass4(($manifest['version'] ?? null) === '0.72.0-alpha.45', 'Workforce Pass 4 version mismatch');
ok_pass4(in_array('titan-workforce.agent-runtime-gateway-v1', $manifest['capabilities'] ?? [], true), 'runtime gateway capability missing');
echo "PASS: coordinated Titan Agent Runtime extraction gateway\n";
