# Pass 10 — Proactive Workforce Runtime from Extension-Owned Responsibilities

Titan AI Workforce does not own domain schedules or domain Signal responsibilities. Those definitions remain **extension-owned** in each capability-owning extension's canonical Workforce Manifest. Central Workforce discovers those definitions, instantiates them for active staff, and creates governed central Workforce Tasks.

## Runtime rules

- Manifest schedules and Signal-triggered responsibilities may create `workforce_task` only.
- Proactive orchestration **never directly executes a business mutation** and never calls Titan Command Bus itself.
- A routine is bound to owning extension, RoleDefinition, routine ID and a deterministic SHA-256 routine fingerprint.
- Schedule delivery uses a deterministic occurrence **idempotency** key and locks the schedule row before dispatch.
- Signal delivery uses a canonical key bound to the Signal ID when supplied; stable canonical envelope hashing is the fail-safe fallback.
- Replays return the existing Workforce Task and do not queue another execution job.
- Member schedule configuration supplies the **timezone**. Due times are calculated locally and persisted in application UTC.
- Invalid timezones fail safely to the configured application timezone.
- Existing explicit `user_override=true` schedule customisation is preserved, but it cannot remove source provenance or turn proactive creation into a business mutation.

## Extension lifecycle

When an owning extension is **disabled** or uninstalled, all of its generated proactive schedules and Signal triggers are deactivated immediately. Historical tasks and schedule history are preserved. When the extension is activated or upgraded again, active staff are reconciled first and then their extension-owned proactive definitions are resynchronised.

A stale routine, changed routine fingerprint, missing RoleDefinition or suppressed owning extension fails closed at dispatch time even if an old schedule row remains in the database.

## Queue and staffing pressure

Queue health records queue depth, unassigned work, SLA breach rate, starvation, coverage, active capacity and `capacity_utilisation`. A deterministic `staffing_pressure` snapshot is fed into Workforce Planning and Manager review. It may create or strengthen a staffing recommendation, but `auto_activate=false` remains mandatory. Workforce Planning cannot hire or activate staff itself.

## Manager proactivity

Central Workforce does not carry a catalogue of domain Manager routines. A proactive Manager must be an active instantiated Tier-1 Manager whose exact owning-extension RoleDefinition is currently available. The central runtime may then surface organisational queue health, same-division workload balancing and staffing pressure to that Manager as governed Workforce work.

## Authority boundary

Proactive work creates organisational intent only. Risk, Assurance, Autonomy, Interaction and Command Bus remain separate later execution gates. Offline or scheduled operation never increases authority.
