# Production Upgrade Pass 6 — Host Authorization & Tenant Boundary Hardening

Pass 6 aligns Titan AI Workforce with the Step-10 exact host profile authorization and tenancy contract.

## Implemented

- Added `TitanHostAuthorizationAdapter` with Super Admin bypass, explicit `can` / `checkPermission` / `hasPermissionTo` support, and bounded `isAdmin` fallback.
- Added seven explicit Workforce permissions and route-level permission middleware.
- Added request middleware that requires both authorization and canonical tenant context.
- Replaced legacy CompanyContext fallbacks: no CRM/customer `company_id`, `team_id` or `user_id` can become tenancy.
- Added scoped `CompanyContext::runWith()` restoration with nested tenant-switch rejection and guaranteed cleanup.
- Added queue middleware to both Workforce queue jobs.
- Added per-row tenant restoration to scheduled proactive dispatch, proactive management, proactive responsibility sync and Signal outbox retry.
- Retained tenant-scoped route-model binding for tasks, handoffs and staffing proposals.
- Added behavioral architecture tests for ordinary user, delegated Admin and Super Admin host methods plus tenant fail-closed behavior.

## Deliberate boundaries

- This pass does not alter business capability authority, Autonomy scores or Risk/Assurance decisions.
- Super Admin authorization does not grant a synthetic tenant; a valid tenant context remains required.
- Live MagicAI authorization certification remains part of the final exact-host certification pass.
