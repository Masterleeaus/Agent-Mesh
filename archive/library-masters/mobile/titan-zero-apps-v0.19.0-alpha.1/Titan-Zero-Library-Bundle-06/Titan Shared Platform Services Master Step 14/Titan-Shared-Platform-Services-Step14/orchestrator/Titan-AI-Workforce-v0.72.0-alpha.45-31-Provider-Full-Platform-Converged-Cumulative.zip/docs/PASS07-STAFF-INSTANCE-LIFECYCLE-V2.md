# Pass 7 — Add Staff Member / Staff Instance Lifecycle v2

Titan AI Workforce activates tenant staff only from a currently valid extension-owned Workforce Manifest 2.0 RoleDefinition. The activation identity is the exact pair `owner_extension + role_definition_id`; display names and aliases are never authority identity.

## Lifecycle model

Organisational lifecycle is deliberately separate from operational availability:

`INVITED → CONFIGURING → READY → ACTIVE → SUSPENDED → RETIRED`

Only valid transitions are permitted. The current Employee Builder is an explicit activation flow, so a successful final submission creates an `ACTIVE` staff instance. The earlier lifecycle states exist for future invitation/draft/onboarding integrations without overloading `AVAILABLE`, `WORKING`, `REVIEWING`, `BLOCKED`, `OFFLINE`, or the other operational states.

## Manifest-owned authority

Employee Builder does not accept arbitrary roles, capabilities, tools, workflows, Risk ceilings, or starting Autonomy grants. Tier, division, team, role, capabilities, tools, playbooks, Wizard/workflow references, Risk ceiling, maturity default and starting earned Autonomy ceiling are derived from the exact valid RoleDefinition.

The chosen manager must satisfy the RoleDefinition's declared `reports_to` contract. Tier-1 roles that report to Titan AI Core / owner cannot be assigned an arbitrary manager.

Maturity remains separate from Autonomy. `JUNIOR / STANDARD / SENIOR / LEAD` is an organisational evidence/maturity track and never raises effective authority. Titan Autonomy remains the exclusive authority source.

## Multiple instances

Multiple instances of the same RoleDefinition are allowed for one tenant. Each instance has its own member key, schedule, workload, model/provider preferences and local instructions while retaining the same extension-owned authority ceiling and provenance fingerprint.

Examples include regional, after-hours or capacity-specific copies of the same staff role.

## Suspension and retirement

Suspension disables assignment/execution eligibility but preserves the staff record and provenance. Resume is allowed only when the source RoleDefinition remains valid and is not in a `MISSING` or `BREAKING` definition state.

Retirement is terminal. An optional replacement must be an active tenant staff instance of the same extension-owned RoleDefinition. Retirement records `replaced_by_member_id` but **does not reassign historical tasks**. Historical tasks, reviews, handoffs, receipts, Rewind references and Wisdom outcome references remain owned by the original staff member.

## Safety invariants

- Role activation requires a valid installed owner extension manifest.
- Add Staff Member cannot mint capabilities or raise Risk/Autonomy ceilings.
- Explicit staff lifecycle is independent from role-definition lifecycle.
- Extension disable/uninstall can make a definition unavailable, but restoring the extension never reactivates a staff member that an administrator explicitly suspended or retired.
- Tenant boundaries apply to activation, suspension, resume, retirement and replacement selection.
- Lifecycle changes emit Signal-compatible events with role provenance.
