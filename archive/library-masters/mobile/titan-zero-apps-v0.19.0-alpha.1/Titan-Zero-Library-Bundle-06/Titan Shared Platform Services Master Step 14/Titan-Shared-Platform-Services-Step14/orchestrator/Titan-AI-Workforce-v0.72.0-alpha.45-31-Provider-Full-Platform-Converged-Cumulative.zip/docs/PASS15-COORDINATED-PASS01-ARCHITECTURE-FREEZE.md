# Coordinated Upgrade Pass 1 — Three-Bundle Baseline & Architecture Freeze

**PLAN_ID:** `6bb234ac-d390-4a3f-8be2-666f5dec8a81`  
**Pass:** 1 of 16  
**Runtime behaviour changed:** No — this pass freezes ownership and migration seams only.

## Frozen target

Titan AI Workforce remains the organisational/control plane. The existing Agents ecosystem is the donor for the future Titan Agent Runtime. AI Chat Pro remains the rich human conversational surface. Consequential business execution is never owned by either surface/runtime.

## Permanent invariant

> No Agent Runtime, AI Chat Pro tool, chatbot, phone agent, connector, workflow, schedule, webhook or model response may independently mutate consequential business state on behalf of a Workforce employee. Consequential mutations must route Workforce -> governance -> Command Bus -> authoritative domain extension -> verified outcome.

## Canonical target identity

`company_id` is the target company boundary. `user_id` remains the human actor, while `workforce_member_id`, `workforce_task_id`, `runtime_profile_id`, conversation identity and trace lineage are distinct. Pass 1 deliberately does not migrate existing tables; that is Pass 2.

## Verified authority seams that must move in later passes

- **Agents `WorkflowEngine`** owns schedule, webhook and channel-trigger execution, resolves actions, executes each step and marks runs complete.
- **Agents scheduler** runs `ai-agent:process-triggers` every minute.
- **Agents delayed jobs and webhook controllers** feed directly back into `WorkflowEngine`.
- **AI Chat Pro `ConnectorToolService::handle()`** directly calls connector `handleToolCall()` implementations.
- **Workforce** already owns organisation, tasks, queues, chain of command, handoffs and governance/outcome bridges, but still persists the legacy `company_id` key in the current baseline.

## Packaging baseline

The supplied Agents and AI Chat Pro inner ZIPs use Windows backslashes in archive entry names. The Pass 1 cumulative bundles normalise these to POSIX paths and remove outer `__MACOSX` junk. This is archive hygiene only; non-core add-on source bytes are preserved.

## Machine-readable contract

See `TITAN-THREE-SYSTEM-ARCHITECTURE-FREEZE.json` in this package. Later passes must update implementation while preserving the authority matrix and permanent invariant.

## Next

**Pass 2 — Canonical Company + Runtime Identity** will add the shared `company_id` / workforce member / task / runtime / conversation / trace identity spine and migrate legacy scope without any authority increase.
