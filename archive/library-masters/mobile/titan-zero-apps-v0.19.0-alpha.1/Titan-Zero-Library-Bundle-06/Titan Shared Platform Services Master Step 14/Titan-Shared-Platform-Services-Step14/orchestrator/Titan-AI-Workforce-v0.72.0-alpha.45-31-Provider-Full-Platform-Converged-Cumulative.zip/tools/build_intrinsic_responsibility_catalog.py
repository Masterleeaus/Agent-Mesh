#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFORCE = ROOT / "resources" / "workforce"
ROLES_PATH = WORKFORCE / "role-definitions.json"
DEFINITIONS_PATH = WORKFORCE / "responsibility-definitions.json"
ASSIGNMENTS_PATH = WORKFORCE / "role-responsibility-assignments.json"


def slug(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value).strip("-")
    return value or "accountability"


def display_name(text: str) -> str:
    text = text.strip().rstrip(".")
    if len(text) <= 72 and text.lower() == text:
        return text.title()
    return text


def main() -> None:
    roles = json.loads(ROLES_PATH.read_text(encoding="utf-8"))
    definitions: list[dict] = []
    assignments: list[dict] = []

    for role in roles:
        role_id = str(role["role_definition_id"])
        role_key = str(role["key"])
        responsibility_ids: list[str] = []

        for sequence, responsibility_text in enumerate(role.get("responsibilities", []), start=1):
            source_text = str(responsibility_text).strip()
            semantic_slug = slug(source_text)
            responsibility_id = f"titan.responsibility.{role_key}.{semantic_slug}"
            responsibility_key = f"{role_key}.r{sequence:02d}"
            responsibility_ids.append(responsibility_id)

            definitions.append({
                "responsibility_id": responsibility_id,
                "key": responsibility_key,
                "name": display_name(source_text),
                "description": source_text,
                "category": str(role["division_key"]),
                "division_definition_id": str(role["division_definition_id"]),
                "division_key": str(role["division_key"]),
                "team_definition_id": str(role["team_definition_id"]),
                "team_key": str(role["team_key"]),
                "definition_scope": "INTRINSIC",
                "definition_version": "1",
                "status": "ACTIVE",
                "accountability_class": "ROLE_ACCOUNTABILITY",
                "is_executable": False,
                "capability_authority": "NONE",
                "vertical_applicability": list(role.get("vertical_applicability", ["all"])),
                "recommended_business_maturity": dict(role.get("recommended_business_maturity", {"min": "SOLO", "max": "ENTERPRISE"})),
                "metadata": {
                    "source": "v0.5 intrinsic role responsibilities",
                    "source_text": source_text,
                    "source_role_key": role_key,
                    "source_role_definition_id": role_id,
                    "source_sequence": sequence,
                    "ownership": "titan-ai-workforce",
                    "execution_semantics": "accountability-only; capabilities and authority are bound separately",
                    "scheduled_event_routines": "deferred-to-passes-20-21"
                },
            })
            assignments.append({
                "role_definition_id": role_id,
                "responsibility_id": responsibility_id,
                "assignment_type": "PRIMARY",
                "is_required": True,
                "sequence": sequence * 10,
                "authority_inherited": False,
                "metadata": {
                    "source": "v0.5 intrinsic role responsibilities",
                    "ownership": "titan-ai-workforce",
                    "capability_authority": "NONE"
                },
            })

        role["responsibility_ids"] = responsibility_ids
        role.setdefault("metadata", {})["responsibility_definition_source"] = "intrinsic_workforce_catalogue"
        role["metadata"]["responsibility_assignment_count"] = len(responsibility_ids)

    if len(definitions) != 114:
        raise SystemExit(f"Expected 114 intrinsic responsibilities, got {len(definitions)}")
    if len(assignments) != 114:
        raise SystemExit(f"Expected 114 role-responsibility assignments, got {len(assignments)}")
    if len({d['responsibility_id'] for d in definitions}) != 114:
        raise SystemExit("Responsibility IDs are not unique")
    if len({d['key'] for d in definitions}) != 114:
        raise SystemExit("Responsibility keys are not unique")

    DEFINITIONS_PATH.write_text(json.dumps(definitions, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    ASSIGNMENTS_PATH.write_text(json.dumps(assignments, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    ROLES_PATH.write_text(json.dumps(roles, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
