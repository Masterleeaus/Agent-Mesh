# Coordinated Pass 7 — Trigger Authority Migration

Titan AI Workforce now receives legacy Agent schedule/webhook/delayed triggers only after Titan Signal publishes `agent.runtime.trigger.requested`. The ingress creates a persistent Workforce task with deterministic trigger idempotency. Workforce may invoke the legacy recipe via `titan.agent-runtime.legacy-workflow/1`, but the recipe has no business completion authority and consequential steps remain child governance proposals.
