# Pass 12 — Control-Plane Integration Registry

Titan AI Workforce owns the orchestration order but **does not own or inherit authority** from any control-plane engine.

Canonical lifecycle:

1. `observe` — Titan Signal Engine
2. `mission` — Titan Prime
3. `plan` — Titan AI Core
4. `reason` — Titan AI Runtime
5. `deliberate` — Titan Model Council, only when required
6. `risk` — Titan Risk Engine
7. `assure` — Titan Assurance
8. `govern` — Titan Governance authority constraint
9. `authorize` — Titan Autonomy
10. `execute` — Titan Command Bus
11. `recover` — Titan Rewind
12. `learn` — Titan Wisdom, verified outcomes only

## Safety boundaries

- `company_id` is the Workforce tenant/company boundary.
- Registry presence never means runtime availability and never grants authority.
- Risk, Assurance, Governance, Autonomy and Command Bus are mandatory for consequential execution.
- Governance emits a non-expansive authority constraint before Autonomy. It can pass, contract, require approval, hold or deny; it cannot increase authority.
- Agent Runtime returns proposals/reasoning outputs with `execution_authority=none`.
- Model Council is conditional and fail-closed when required by Risk or policy.
- Command Bus uncertainty enters recovery rather than retrying blindly.
- Rewind preserves evidence/recovery references.
- Wisdom receives only verified real-world outcomes; unverified outcomes are withheld.
- Titan Zero cannot bypass any control-plane stage.

The source of truth is `resources/workforce/control-plane-integration-registry.json`; runtime adapters resolve candidate bindings through `WorkforceControlPlaneIntegrationRegistry`.
