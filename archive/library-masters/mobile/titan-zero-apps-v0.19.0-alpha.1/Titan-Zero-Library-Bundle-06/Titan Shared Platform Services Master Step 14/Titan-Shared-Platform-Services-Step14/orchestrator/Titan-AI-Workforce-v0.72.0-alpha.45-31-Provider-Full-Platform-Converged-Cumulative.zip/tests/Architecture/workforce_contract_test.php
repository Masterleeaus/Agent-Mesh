<?php

declare(strict_types=1);

require_once __DIR__ . '/../../System/Support/WorkforceManifestValidator.php';

use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestValidator;

function fail_test(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok(bool $condition, string $message): void { if (! $condition) fail_test($message); }

$root = dirname(__DIR__, 2);

foreach ([
    '/System/Support/WorkforceManifestRegistry.php',
    '/System/Support/WorkforceManifestValidator.php',
    '/System/Support/WorkforceRoleRegistry.php',
    '/System/Services/WorkforcePlanningService.php',
    '/System/Services/WorkloadSharingService.php',
    '/System/Services/WorkforceMaturityService.php',
    '/System/Services/ManagerContinuityService.php',
] as $path) ok(is_file($root . $path), basename($path) . ' missing');

ok(is_file($root . '/resources/workforce/role-definitions.json'), 'Pass 4 must restore the canonical intrinsic 111-role catalogue');
ok(is_file($root . '/resources/workforce/division-definitions.json'), 'Pass 3 must restore intrinsic division definitions while preserving historical external-capability ownership');
ok(! is_file($root . '/resources/workforce/proactive-responsibilities.json'), 'central Workforce must not bundle domain responsibility packs');

$policyFile = $root . '/resources/workforce/organisation-policies.json';
ok(is_file($policyFile), 'organisation-policies.json must remain central');
$policy = json_decode((string) file_get_contents($policyFile), true, flags: JSON_THROW_ON_ERROR);
ok(isset($policy['maturity_levels']['JUNIOR'], $policy['maturity_levels']['SENIOR'], $policy['maturity_levels']['LEAD']), 'role maturity levels missing');
ok(isset($policy['councils']['daily_ops'], $policy['councils']['weekly_performance']), 'cross-functional councils missing');
ok(($policy['decision_rights_source'] ?? null) === 'canonical_workforce_policy_plus_extension_workforce_manifests', 'RACI decision rights must combine canonical Workforce policy with extension Workforce manifests');
ok(count($policy['decision_rights'] ?? []) >= 20, 'central Workforce must publish its canonical organisational decision-right catalogue');
foreach ($policy['decision_rights'] ?? [] as $right) ok(($right['owner_extension'] ?? null) === 'titan-ai-workforce', 'central decision-right catalogue may contain Workforce-owned decisions only');
ok(($policy['dispute_resolution']['source'] ?? null) === 'persisted_reporting_graph', 'disputes must use persisted reporting graph escalation');
ok(($policy['dispute_resolution']['no_common_manager'] ?? null) === 'HUMAN_DECISION_REQUIRED', 'unresolvable disputes must fail closed to human decision');
ok(($policy['workload_sharing']['cross_division_default'] ?? true) === false, 'cross-division workload sharing must be opt-in');

$validator = (string) file_get_contents($root . '/System/Support/WorkforceManifestValidator.php');
ok(str_contains($validator, "schema_version must be 2.0"), 'validator must require canonical Workforce Manifest 2.0');
ok(is_file($root . '/System/Support/WorkforceManifestNormalizer.php'), 'bounded Workforce 1.1 normalizer missing');
$normalizer = (string) file_get_contents($root . '/System/Support/WorkforceManifestNormalizer.php');
ok(str_contains($normalizer, "'Trusted Auto' => 71"), 'legacy autonomy migration must use conservative band floors');
ok(str_contains($normalizer, "version !== '1.1'"), 'legacy normalisation must be bounded to schema 1.1');

$core = (string) file_get_contents($root . '/System/Support/CoreWorkforceCatalog.php');
ok(str_contains($core, 'return [];'), 'central action worker catalogue must be empty');
ok(! str_contains($core, 'customer-action-worker'), 'central Workforce must not contain generic domain Action Workers');

$bootstrap = (string) file_get_contents($root . '/System/Services/WorkforceBootstrapService.php');
ok(str_contains($bootstrap, 'creates NO WorkforceMember rows'), 'bootstrap must document no member seeding');
ok(! str_contains($bootstrap, 'WorkforceMember::query()->firstOrCreate'), 'bootstrap must not install staff members');

$planFile = $root . '/docs/AI-WORKFORCE-BUILD-PLAN.md';
ok(is_file($planFile), 'cumulative build plan missing');
$plan = (string) file_get_contents($planFile);
ok(str_contains($plan, '111-role reference catalogue'), 'plan must retain the complete role coverage reference');
ok(str_contains($plan, 'reference architecture, not installed role data'), 'plan must distinguish reference catalogue from runtime source of truth');

$forbidden = [
    $root . '/resources/assets/videos',
    $root . '/System/Http/Controllers/BlogPilotController.php',
    $root . '/System/Services/PostGenerationService.php',
    $root . '/System/Models/BlogPilot.php',
    $root . '/System/Models/BlogPilotPost.php',
];
foreach ($forbidden as $path) ok(! file_exists($path), 'legacy production artifact must be removed: ' . $path);

$migration = (string) file_get_contents($root . '/database/migrations/2026_08_11_000001_create_titan_ai_workforce_core.php');
ok(! str_contains($migration, "* 2) + 1"), 'migration must not derive company_id from user_id');
ok(! str_contains($migration, 'ext_blogpilot'), 'core migration must not auto-import legacy BlogPilot data');

echo "PASS: Titan AI Workforce architecture contract\n";
