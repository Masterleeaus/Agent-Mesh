# Pass 13 — Canonical Capability Binding Matrix

This pass makes Titan AI Workforce the definitive owner of **role-to-provider composition** while preserving provider ownership of executable surfaces.

## Canonical coverage

- 111 intrinsic Workforce roles.
- 1 executive role: `titan.executive.business_manager`.
- 1 system role: `titan.system.titan_zero`.
- 113 role rows total.
- 28 canonical provider identities.
- 313 role/provider bindings.
- 96 roles deliberately compose two or more providers.
- Titan Zero has zero domain provider bindings and instead records non-authoritative coordination/control-plane dependencies.

The matrix is stored at `resources/workforce/canonical-capability-binding-matrix.json` and is the authoritative Workforce composition layer. Provider packages still own the capabilities, tools, commands, signals, data sources and workflows themselves.

## Runtime rule

A matrix binding is **availability, not authority**. Runtime access is exposed only when the owning provider is installed and still publishes every surface pinned by that binding. If a provider is absent or its declared surface drifts, the binding fails closed. Risk, Assurance, Governance, Autonomy and Command Bus remain mandatory for consequential execution.

No binding inherits authority and no matrix row grants execution authority.

## Multi-provider examples

### Dispatcher

`Dispatcher` combines:

- Titan Field — work orders, dispatch, scheduling, routing, evidence and exceptions.
- Titan Maps Intelligence — route/travel/dispatch intelligence.
- Titan Connect — customer and workforce communication surfaces.

The role remains `titan.work.dispatcher`; none of those extensions owns the employee.

### Accounts Receivable Officer

`Accounts Receivable Officer` combines:

- CRM — customer/invoice state and governed customer-facing invoice actions.
- Titan Ledger — receivables and accounting truth.
- Titan Financial Engine — deterministic cash-flow, settlement-cost and margin calculations.

### Billing Coordinator

`Billing Coordinator` combines CRM + Ledger + Financial Engine and retains the Forge scaffold workflow only as a provider-owned compatibility/build surface. The matrix does not turn Forge into the role owner.

### Risk Manager

`Risk Manager` composes Titan Risk Engine, Assurance, Governance and Signal as governed observation/evaluation surfaces. The role cannot replace or bypass those engines' authoritative decisions.

## Ownership migration inputs

This pass consumes the verified Step-2 provider ownership migration for Titan Field 1.0.7, Titan Time & Attendance 0.1.2 and Titan Forge 0.9.0-alpha.2, plus Titan AI Runtime 1.5.3 from Step 1. Their canonical Workforce binding documents are merged into the ecosystem catalogue while their full provider capability catalogues are preserved.

## Titan Zero

Titan Zero is intentionally different. It is represented in the 113-role matrix for completeness but has:

- `provider_bindings: []`
- zero domain capabilities
- zero execution authority
- non-authoritative coordination references to the cognition/control-plane providers it orchestrates

Titan Zero can coordinate the business, not bypass it.
