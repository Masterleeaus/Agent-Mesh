#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from typing import Any

SURFACE_TYPES = ('capability','tool','command','signal','data_source','workflow')

def ident(row: Any) -> str:
    if isinstance(row, str): return row.strip()
    if isinstance(row, dict):
        for key in ('id','name','key','command','signal','workflow','capability'):
            value=row.get(key)
            if isinstance(value,str) and value.strip(): return value.strip()
    return ''

def normalize(surface_type: str, item: Any, provider: dict[str,Any], tenant_key: str) -> dict[str,Any] | None:
    sid=ident(item)
    if not sid: return None
    ext=provider.get('extension') or {}
    prov=provider.get('provenance') or {}
    runtime=provider.get('runtime') or {}
    row=item if isinstance(item,dict) else {}
    mode=str(row.get('mode') or ('read' if surface_type=='data_source' else 'feature'))
    authority=str(row.get('authority') or ('authoritative' if surface_type in ('command','tool') else 'informational'))
    return {
        'id': sid,
        'surface_type': surface_type,
        'provider': str(ext.get('key') or ''),
        'provider_version': str(ext.get('version') or ''),
        'provider_class': str(ext.get('provider_class') or ''),
        'tenant_key': tenant_key,
        'mode': mode,
        'authority': authority,
        'source': row.get('source'),
        'description': row.get('description'),
        'installed_probe': runtime.get('availability_probe'),
        'archive_sha256': str(prov.get('archive_sha256') or ''),
        'catalogue_grants_authority': False,
    }

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('registry_json', type=Path)
    ap.add_argument('output_json', type=Path)
    args=ap.parse_args()
    source=json.loads(args.registry_json.read_text(encoding='utf-8'))
    if source.get('organisation_owner')!='titan-ai-workforce' or source.get('tenant_key')!='company_id':
        raise SystemExit('registry ownership/tenant contract invalid')
    rows=[]
    keys={
      'capability':'capabilities','tool':'tools','command':'commands','signal':'signals','data_source':'data_sources','workflow':'workflows'
    }
    for provider in source.get('providers',[]):
        if not isinstance(provider,dict): continue
        for st,key in keys.items():
            for item in provider.get(key,[]) or []:
                row=normalize(st,item,provider,source['tenant_key'])
                if row: rows.append(row)
    rows.sort(key=lambda r:(r['id'],r['surface_type'],r['provider'],r['provider_version']))
    ownership={}
    for row in rows:
        ownership.setdefault(row['id'],[]).append({
            'provider':row['provider'],'provider_version':row['provider_version'],'surface_type':row['surface_type'],
            'mode':row['mode'],'authority':row['authority'],'archive_sha256':row['archive_sha256']
        })
    ambiguous={k:v for k,v in ownership.items() if len({x['provider'] for x in v})>1}
    out={
      'schema_version':'1.0',
      'generated_at':source.get('generated_at'),
      'organisation_owner':'titan-ai-workforce',
      'tenant_key':'company_id',
      'source_registry_schema_version':source.get('schema_version'),
      'source_bundles':source.get('source_bundles',[]),
      'safety':{
        'descriptive_only':True,
        'catalogue_grants_authority':False,
        'provider_installation_grants_authority':False,
        'execution_requires_later_authority_and_provider_resolution':True,
        'ambiguous_provider_selection_is_not_performed_here':True
      },
      'summary':{
        'provider_count':len(source.get('providers',[])),
        'surface_count':len(rows),
        'unique_surface_id_count':len(ownership),
        'multi_provider_surface_id_count':len(ambiguous),
        **{f'{st}_count':sum(1 for r in rows if r['surface_type']==st) for st in SURFACE_TYPES}
      },
      'surfaces':rows,
      'multi_provider_surface_ids':ambiguous
    }
    args.output_json.parent.mkdir(parents=True,exist_ok=True)
    args.output_json.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(out['summary'],indent=2))
    return 0
if __name__=='__main__': raise SystemExit(main())
