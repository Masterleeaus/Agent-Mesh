<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$enumPath = $root.'/System/Enums/WorkforceMemberLifecycleState.php';
$servicePath = $root.'/System/Services/WorkforceMemberLifecycleService.php';
$migrationPath = $root.'/database/migrations/2026_08_18_000005_add_workforce_member_lifecycle_v2.php';
$controllerPath = $root.'/System/Http/Controllers/WorkforceController.php';
$viewPath = $root.'/resources/views/workforce/create/index.blade.php';
$providerPath = $root.'/System/TitanAIWorkforceServiceProvider.php';
$permissionsPath = $root.'/System/Support/WorkforcePermissions.php';
$catalogPath = $root.'/System/Support/WorkforceCapabilityCatalog.php';
$modelPath = $root.'/System/Models/WorkforceMember.php';
$docsPath = $root.'/docs/PASS07-STAFF-INSTANCE-LIFECYCLE-V2.md';

foreach ([$enumPath,$servicePath,$migrationPath,$docsPath] as $path) {
    $assert(is_file($path), 'missing Pass 7 file: '.basename($path));
}

if (is_file($enumPath)) {
    require_once $enumPath;
    $enum = 'App\\Extensions\\TitanAIWorkforce\\System\\Enums\\WorkforceMemberLifecycleState';
    foreach (['INVITED','CONFIGURING','READY','ACTIVE','SUSPENDED','RETIRED'] as $state) {
        $assert(defined($enum.'::'.ucfirst(strtolower($state))) || in_array($state, array_map(fn ($case) => $case->value, $enum::cases()), true), "lifecycle state missing {$state}");
    }
}

$migration = @file_get_contents($migrationPath) ?: '';
foreach (['lifecycle_state','lifecycle_changed_at','activated_at','suspended_at','retired_at','replaced_by_member_id','lifecycle_metadata'] as $column) {
    $assert(str_contains($migration, $column), "lifecycle migration missing {$column}");
}
$assert(str_contains($migration, "'ACTIVE'"), 'existing active staff must migrate to ACTIVE lifecycle state');
$assert(str_contains($migration, "'SUSPENDED'"), 'existing suspended staff must migrate to SUSPENDED lifecycle state');

$model = @file_get_contents($modelPath) ?: '';
$assert(str_contains($model, 'WorkforceMemberLifecycleState::class'), 'member model must cast lifecycle_state separately from operational status');
$assert(str_contains($model, "'lifecycle_metadata' => 'array'"), 'member must cast lifecycle metadata');
$assert(str_contains($model, 'replacementFor'), 'member model must expose replacement relationship');

$service = @file_get_contents($servicePath) ?: '';
foreach (['activateFromDefinition','suspend','resume','retire','assertManagerConstraint','assertRoleDefinitionAvailable'] as $method) {
    $assert(str_contains($service, "function {$method}"), "staff lifecycle service missing {$method}");
}
foreach (['owner_extension','role_definition_id','definition_fingerprint','starting_score','risk_ceiling','maturity_level'] as $needle) {
    $assert(str_contains($service, $needle), "staff lifecycle service missing authority/provenance field {$needle}");
}
$assert(str_contains($service, 'findOwnedRole'), 'activation must resolve exact owner+role from valid installed manifest registry');
$assert(str_contains($service, 'capabilities'), 'activation must source capabilities from role definition');
$assert(! str_contains($service, "array_merge(\$definition['capabilities']"), 'activation must not merge user-supplied capabilities into manifest authority');
$assert(str_contains($service, 'replaced_by_member_id'), 'retirement must support explicit replacement provenance');
$assert(str_contains($service, 'workforce.member.activated'), 'activation must emit a lifecycle signal');
$assert(str_contains($service, 'workforce.member.retired'), 'retirement must emit a lifecycle signal');

$controller = @file_get_contents($controllerPath) ?: '';
$assert(str_contains($controller, 'WorkforceMemberLifecycleService'), 'controller must delegate staff lifecycle to dedicated service');
$assert(str_contains($controller, "'titan-ai-workforce'"), 'Add Staff Member must force canonical Workforce role ownership');
$assert(str_contains($controller, "'role_definition_id' => ['required'"), 'Add Staff Member must require a registered RoleDefinition');
$assert(! str_contains($controller, "'role' => ['nullable'"), 'Add Staff Member must not accept arbitrary custom role titles');
foreach (['suspendStaff','resumeStaff','retireStaff'] as $method) {
    $assert(str_contains($controller, "function {$method}"), "controller missing staff lifecycle endpoint {$method}");
}

$view = @file_get_contents($viewPath) ?: '';
$assert(str_contains($view, 'role_owner_extension'), 'Employee Builder must submit the owning extension with the selected role');
$assert(str_contains($view, 'Governed capability binding'), 'Employee Builder must explain that provider capabilities are bound separately from role identity');
$assert(! str_contains($view, 'name="capabilities[]"'), 'Employee Builder must not offer free-form capability escalation fields');
$assert(! str_contains($view, 'name="initial_autonomy"'), 'Employee Builder must not offer autonomy minting controls');
$assert(! str_contains($view, 'name="risk_ceiling"'), 'Employee Builder must not offer risk-ceiling escalation controls');

$provider = @file_get_contents($providerPath) ?: '';
$assert(str_contains($provider, "Route::bind('member'"), 'member route model binding must be tenant-scoped');
foreach (['staff/{member}/suspend','staff/{member}/resume','staff/{member}/retire'] as $route) {
    $assert(str_contains($provider, $route), "missing lifecycle route {$route}");
}
$assert(str_contains($provider, "'titan.workforce.member-lifecycle'"), 'stable member lifecycle adapter binding missing');

$permissions = @file_get_contents($permissionsPath) ?: '';
$assert(str_contains($permissions, 'titan-workforce.staff.manage'), 'staff lifecycle mutation permission missing');

$catalog = @file_get_contents($catalogPath) ?: '';
foreach (['workforce.member.activate','workforce.member.suspend','workforce.member.resume','workforce.member.retire'] as $capability) {
    $assert(str_contains($catalog, $capability), "capability catalogue missing {$capability}");
}

$sidecar = json_decode((string) file_get_contents($root.'/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
foreach (['titan-workforce.member-lifecycle'] as $capability) {
    $assert(in_array($capability, $sidecar['capabilities'] ?? [], true), "sidecar missing {$capability}");
}

$docs = @file_get_contents($docsPath) ?: '';
$assert(str_contains($docs, 'Multiple instances'), 'Pass 7 docs must explicitly permit multiple tenant-specific instances of one role');
$assert(str_contains($docs, 'does not reassign historical tasks'), 'Pass 7 docs must preserve historical task ownership on retirement');
$assert(str_contains($docs, 'Maturity remains separate from Autonomy'), 'Pass 7 docs must preserve maturity/autonomy separation');

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce staff instance lifecycle v2 contract\n";
