# Pass 1 Migration Map

The migration rule is **v0.27 runtime wins; v0.5 organisation returns as translated data/contracts**.

| Classification | Count |
|---|---:|
| PRESERVE | 71 |
| PRESERVE_THEN_TRANSLATE | 1 |
| REFERENCE_REIMPLEMENT | 6 |
| RESTORE_TRANSLATE | 4 |

## Key restored organisation assets

- `v0.5/resources/workforce/role-definitions.json` → **RoleDefinition catalogue** (Pass 4): Restore intrinsic 111-role organisation; convert role authority from embedded capability assumptions to explicit capability bindings.
- `v0.5/resources/workforce/division-definitions.json` → **Division catalogue** (Pass 3): Restore intrinsic 15-division organisation as Workforce-owned structure.
- `v0.5/resources/workforce/proactive-responsibilities.json` → **Responsibility/Routine/Trigger catalogues** (Pass 15): Restore 19 schedules and 44 event routines through the modern Signal/Trigger path.
- `v0.5/resources/workforce/organisation-policies.json` → **Council/DecisionRight/Dispute policy catalogues** (Pass 12): Restore councils, RACI decision rights and dispute routing without bypassing modern authority.

## Modern-runtime preservation rule

All v0.27 services, runtime DTOs, jobs, queue context, execution receipts, recovery, Signal bridge, Risk/Assurance/Governance/Autonomy/Command Bus integration and post-action verification remain canonical unless a later named pass replaces a specific seam. Shipped migrations are immutable; schema changes are forward-only.
