# Titan AI Workforce Pass 1 — Dual-Baseline Integration Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Establish a reproducible, verified convergence baseline joining Workforce v0.27 runtime/governance, Workforce v0.5 intrinsic-team definitions, and all 28 supplied Titan capability-provider extensions without changing business behavior yet.

**Architecture:** Workforce v0.27 remains the executable parent. Workforce v0.5 is read-only organisational donor material. All supplied extensions are normalized into a canonical integration inventory keyed by extension slug; duplicate Knowledge Authority input resolves to the later Pass4-H2 package. Pass 1 produces machine-readable migration classifications, compatibility blockers, deterministic source hashes, and a master all-extension bundle for later passes.

**Tech Stack:** PHP 8.3-compatible Laravel extension sources, JSON manifests/contracts, Python 3 validation/packaging scripts, ZIP/SHA-256 artifact verification.

**Spec:** `docs/2026-08-21-titan-ai-workforce-intrinsic-business-team-design.md`

## Global Constraints

- Workforce runtime baseline: `0.27.0-alpha.27`.
- Intrinsic organisation donor: `0.5.0-alpha.5`.
- Canonical tenant boundary: `company_id` only inside Workforce.
- Intrinsic organisation target: 15 divisions, 111 roles, 19 scheduled routines, 44 event routines.
- Titan Zero is the permanent Chief of Staff system role and does not consume an operational staffing slot.
- Consequential action authority remains Risk → Assurance → Governance → Autonomy → Command Bus → domain owner; Pass 1 must not weaken or bypass any of these seams.
- All supplied extensions from both bundles are in target scope; canonical inventory contains 28 unique extension identities after de-duplicating Knowledge Authority to the later Pass4-H2 build.
- Current known blockers must be preserved explicitly: Workforce requires Titan AI >=1.5.3 while supplied Titan AI is 1.5.2; Forge assumes 68 roles; external Workforce roles remain in Field/Time & Attendance; peer package IDs and legacy tenant envelope names drift.
- No direct domain writes are added in Pass 1.
- Uploaded/source packages remain immutable; all edits occur in isolated copies.
- No Git repository is present, so immutable SHA-256 package checkpoints replace commit steps for this pass.

---

### Task 1: Baseline Contract Test

**Files:**
- Create: `tests/pass1_baseline_contract_test.py`
- Read: `source/workforce-v0.27/**`
- Read: `source/workforce-v0.5-donor/**`

**Interfaces:**
- Consumes: two frozen source trees.
- Produces: executable contract proving baseline version identities and donor organisation counts.

- [ ] **Step 1: Write the failing baseline contract test**

The test must require a not-yet-created `pass1/BASELINE-MANIFEST.json`, verify baseline/donor package SHA-256 values, assert v0.5 has 15 divisions and 111 roles, and assert proactive responsibilities contain 19 scheduled and 44 event routines.

- [ ] **Step 2: Run test and verify RED**

Run: `python tests/pass1_baseline_contract_test.py`
Expected: FAIL because `pass1/BASELINE-MANIFEST.json` does not yet exist.

- [ ] **Step 3: Generate deterministic baseline manifest**

Create a Python generator that hashes the source trees and records source ZIP SHA-256 values, versions, role/division/routine counts, and parent artifact identity.

- [ ] **Step 4: Run test and verify GREEN**

Run: `python tests/pass1_baseline_contract_test.py`
Expected: PASS.

- [ ] **Step 5: Record package checkpoint**

Write the current Pass-1 workspace content digest into `pass1/CHECKPOINTS.json`.

### Task 2: Canonical 28-Extension Inventory

**Files:**
- Create: `tools/build_pass1_extension_inventory.py`
- Create: `tests/pass1_extension_inventory_test.py`
- Create: `pass1/EXTENSION-INVENTORY.json`
- Read: `/mnt/data/extbundle_scan/**`
- Read: `/mnt/data/extbundle2_scan/**`

**Interfaces:**
- Produces: canonical map keyed by extension slug with source directory, version, role as business/control/cognition/evidence/platform provider, declared dependencies, manifest presence, package hash, and integration notes.

- [ ] **Step 1: Write failing inventory test**

Require exactly 28 unique canonical identities, exactly one `titan-knowledge-authority` entry selecting Pass4-H2, and presence of all required control-plane providers.

- [ ] **Step 2: Run test and verify RED**

Expected: FAIL because inventory does not exist.

- [ ] **Step 3: Implement inventory builder**

Read extension manifests from both extracted bundles, resolve duplicate Knowledge Authority deterministically to Pass4-H2, record hashes, and classify every extension.

- [ ] **Step 4: Run test and verify GREEN**

Expected: PASS with 28 canonical identities.

- [ ] **Step 5: Record package checkpoint**

Update `pass1/CHECKPOINTS.json`.

### Task 3: Restore/Translate/Replace/Retire Migration Map

**Files:**
- Create: `tools/build_pass1_migration_map.py`
- Create: `tests/pass1_migration_map_test.py`
- Create: `pass1/MIGRATION-MAP.json`
- Create: `pass1/MIGRATION-MAP.md`

**Interfaces:**
- Consumes: v0.27 and v0.5 file inventories.
- Produces: deterministic classification of v0.5 organisational assets and v0.27 runtime assets.

- [ ] **Step 1: Write failing migration-map test**

Require classification for all v0.5 workforce resource files and all v0.27 runtime/governance services. Explicitly require `role-definitions.json`, `division-definitions.json`, `proactive-responsibilities.json`, and `organisation-policies.json` to be `RESTORE_TRANSLATE`, while modern execution/governance services are `PRESERVE`.

- [ ] **Step 2: Run RED**

Expected: FAIL because migration map is missing.

- [ ] **Step 3: Implement migration map generator**

Generate machine-readable and Markdown maps with source path, target concept, classification, rationale and owning future pass.

- [ ] **Step 4: Run GREEN**

Expected: PASS.

- [ ] **Step 5: Record checkpoint**

Update `pass1/CHECKPOINTS.json`.

### Task 4: Cross-Extension Compatibility Ledger

**Files:**
- Create: `tests/pass1_compatibility_ledger_test.py`
- Create: `pass1/COMPATIBILITY-LEDGER.json`
- Create: `pass1/COMPATIBILITY-LEDGER.md`

**Interfaces:**
- Consumes: canonical extension inventory plus known scanned conflicts.
- Produces: explicit blocker/remediation ledger that later passes must clear.

- [ ] **Step 1: Write failing ledger test**

Require entries for Titan AI 1.5.2 vs Workforce >=1.5.3, Forge 68 vs 111 roles, Field and Time & Attendance external-role ownership, package ID aliases, legacy `tenant_company_id` boundaries, CRM compatibility write overlap, Financial Engine public capability gap, Knowledge Authority limited resolver surface, and non-executing AI Core/Prime planning semantics.

- [ ] **Step 2: Run RED**

Expected: FAIL because ledger is missing.

- [ ] **Step 3: Create compatibility ledger**

Every issue must have severity, affected extensions, canonical decision, safe interim behavior, and planned remediation pass.

- [ ] **Step 4: Run GREEN**

Expected: PASS.

- [ ] **Step 5: Record checkpoint**

Update `pass1/CHECKPOINTS.json`.

### Task 5: Pass-1 Workforce Cumulative Artifact

**Files:**
- Create in working copy: `docs/PASS01-INTRINSIC-CONVERGENCE-FOUNDATION.md`
- Create in working copy: `docs/INTEGRATION-CAPABILITY-INVENTORY.json`
- Modify in working copy: `README.md`
- Modify in working copy: `BUILD-PROVENANCE.json`
- Modify in working copy: `extension.json`
- Modify in working copy: `extension.manifest.json`
- Create: `tools/build_pass1_workforce_package.py`
- Create: `tests/pass1_workforce_package_test.py`

**Interfaces:**
- Produces: Workforce `0.28.0-alpha.1` cumulative package containing Pass-1 evidence only; runtime behavior remains byte-equivalent to v0.27 outside documentation/manifest/provenance packaging metadata.

- [ ] **Step 1: Write failing package test**

Require version `0.28.0-alpha.1`, plan ID `4afc3d5e-78c4-4d7a-9a1f-b7526d5b7032`, Pass 1 provenance, unchanged hashes for all v0.27 `System/**/*.php`, migrations, routes and Blade files, and valid regenerated integrity metadata.

- [ ] **Step 2: Run RED**

Expected: FAIL because working package remains v0.27.

- [ ] **Step 3: Apply metadata/docs-only Pass-1 changes and regenerate integrity/provenance**

No runtime PHP, migration, route or Blade modification is permitted in this pass.

- [ ] **Step 4: Run GREEN plus full baseline regressions**

Run all architecture tests, all PHP lints, all JSON parses and ZIP verifier.

- [ ] **Step 5: Build cumulative ZIP and record SHA-256**

Output: `Titan-AI-Workforce-v0.28.0-alpha.1-Pass1-Dual-Baseline-Integration-Foundation-Cumulative.zip`.

### Task 6: Master All-Extensions Integration Bundle

**Files:**
- Create: `tools/build_all_extensions_bundle.py`
- Create: `tests/all_extensions_bundle_test.py`
- Create: `output/extensions/*.zip`
- Create: `output/Titan-All-Extensions-Integration-Bundle-Pass1.zip`
- Create: `output/ALL-EXTENSIONS-SHA256SUMS.txt`

**Interfaces:**
- Consumes: the 28 canonical extension source directories plus Pass-1 Workforce cumulative package and v0.5 donor reference.
- Produces: one master archive containing individually installable/source-preserving extension ZIPs, Workforce current artifact, donor reference, integration docs and checksums.

- [ ] **Step 1: Write failing bundle test**

Require 28 canonical provider ZIPs plus the Pass-1 Workforce ZIP, no duplicate stale Knowledge Authority package, root `extension.json` inside each extension ZIP where the source provides it, and matching SHA-256 ledger.

- [ ] **Step 2: Run RED**

Expected: FAIL because bundle does not exist.

- [ ] **Step 3: Build per-extension ZIPs and master bundle**

Preserve each extension source tree exactly except ZIP container metadata; no peer extension behavior is modified in Pass 1.

- [ ] **Step 4: Run GREEN and archive integrity verification**

Test all inner ZIPs, manifest JSON parsing and checksum equality.

- [ ] **Step 5: Record final Pass-1 checkpoint**

Write final artifact hashes and sizes to `pass1/PASS01-ARTIFACTS.json`.

## Pass-1 Completion Gate

Pass 1 is complete only when:

- both source baselines still pass their original tests;
- the Pass-1 Workforce runtime code is byte-identical to v0.27 outside approved metadata/docs files;
- 28 extension identities are represented exactly once in the canonical bundle;
- compatibility conflicts are recorded rather than silently normalized;
- the new Workforce cumulative ZIP passes architecture tests, PHP lint, JSON parse and package verification;
- the all-extension bundle passes ZIP/manifest/checksum verification.
