<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
function ok_pass3(bool $condition, string $message): void { if (! $condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } }

$contract = json_decode((string) file_get_contents($root . '/docs/TITAN-THREE-SYSTEM-PASS03-AGENT-RUNTIME-CONTRACT.json'), true, flags: JSON_THROW_ON_ERROR);
ok_pass3(($contract['plan_id'] ?? null) === '6bb234ac-d390-4a3f-8be2-666f5dec8a81', 'PLAN_ID mismatch');
ok_pass3(($contract['pass'] ?? null) === 3, 'coordinated pass mismatch');
ok_pass3(($contract['protocol'] ?? null) === 'titan.agent-runtime/1', 'protocol mismatch');
ok_pass3(($contract['canonical_company_boundary'] ?? null) === 'company_id', 'company_id must remain canonical');

foreach ([
    'System/Contracts/AgentRuntimeContract.php',
    'System/Runtime/RuntimeRequest.php',
    'System/Runtime/RuntimeResponse.php',
    'System/Runtime/RuntimeToolProposal.php',
    'System/Runtime/RuntimeFailure.php',
    'System/Adapters/LegacyTitanAIRuntimeAdapter.php',
    'System/Services/FailClosedAgentRuntime.php',
    'schemas/titan-agent-runtime-v1.schema.json',
] as $relative) {
    ok_pass3(is_file($root . '/' . $relative), 'missing ' . $relative);
}

$iface = (string) file_get_contents($root . '/System/Contracts/AgentRuntimeContract.php');
ok_pass3(str_contains($iface, "PROTOCOL = 'titan.agent-runtime/1'"), 'AgentRuntimeContract version missing');
$bridge = (string) file_get_contents($root . '/System/Services/WorkforceAIRuntimeBridge.php');
ok_pass3(str_contains($bridge, 'AgentRuntimeContract'), 'Workforce bridge must depend on AgentRuntimeContract');
ok_pass3(! str_contains($bridge, 'TitanAIRuntimeContract'), 'Workforce bridge must not depend directly on Titan AI runtime');
ok_pass3(! str_contains($bridge, 'App\\Extensions\\AIAgent'), 'Workforce must not import Agent implementation classes');
$provider = (string) file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
ok_pass3(str_contains($provider, "AgentRuntimeContract::PROTOCOL"), 'versioned runtime container alias missing');
ok_pass3(str_contains($provider, 'AgentRuntimeGateway'), 'Agent Runtime gateway binding missing');
$gateway = (string) file_get_contents($root . '/System/Services/AgentRuntimeGateway.php');
ok_pass3(str_contains($gateway, 'LegacyTitanAIRuntimeAdapter'), 'legacy compatibility fallback missing');
ok_pass3(str_contains($gateway, 'FailClosedAgentRuntime'), 'fail-closed runtime fallback missing');

$proposal = (string) file_get_contents($root . '/System/Runtime/RuntimeToolProposal.php');
ok_pass3(str_contains($proposal, "'requires_governance' => true"), 'tool proposal must require governance');
ok_pass3(str_contains($proposal, "'execution_claimed' => false"), 'tool proposal must deny execution claim');
$response = (string) file_get_contents($root . '/System/Runtime/RuntimeResponse.php');
ok_pass3(str_contains($response, "'authoritative_business_execution' => false"), 'runtime response must be non-authoritative');
$request = (string) file_get_contents($root . '/System/Runtime/RuntimeRequest.php');
ok_pass3(str_contains($request, 'workforce_member_id'), 'request must require Workforce member identity');
ok_pass3(str_contains($request, 'workforce_task_id'), 'request must require Workforce task identity');

$schema = json_decode((string) file_get_contents($root . '/schemas/titan-agent-runtime-v1.schema.json'), true, flags: JSON_THROW_ON_ERROR);
ok_pass3(($schema['$defs']['request']['properties']['protocol']['const'] ?? null) === 'titan.agent-runtime/1', 'schema protocol drift');
ok_pass3(($schema['$defs']['toolProposal']['properties']['requires_governance']['const'] ?? null) === true, 'schema governance invariant missing');
ok_pass3(($schema['$defs']['toolProposal']['properties']['execution_claimed']['const'] ?? null) === false, 'schema execution invariant missing');
ok_pass3(($schema['$defs']['response']['properties']['authoritative_business_execution']['const'] ?? null) === false, 'schema response authority invariant missing');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
ok_pass3(($manifest['version'] ?? null) === '0.72.0-alpha.45', 'Workforce Pass 3 version mismatch');
ok_pass3(in_array('titan-workforce.agent-runtime-contract-v1', $manifest['capabilities'] ?? [], true), 'runtime contract capability missing');

echo "PASS: coordinated Agent Runtime contract layer\n";
