<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
function ok_three_system(bool $condition, string $message): void { if (! $condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } }

$path = $root . '/docs/TITAN-THREE-SYSTEM-ARCHITECTURE-FREEZE.json';
ok_three_system(is_file($path), 'three-system architecture freeze JSON missing');
$data = json_decode((string) file_get_contents($path), true, flags: JSON_THROW_ON_ERROR);
ok_three_system(($data['plan_id'] ?? null) === '6bb234ac-d390-4a3f-8be2-666f5dec8a81', 'coordinated PLAN_ID mismatch');
ok_three_system(($data['pass'] ?? null) === 1, 'coordinated pass must be 1');
ok_three_system(($data['runtime_behavior_changed'] ?? true) === false, 'Pass 1 must be behaviour-neutral');
ok_three_system(($data['canonical_target_identity']['company_boundary'] ?? null) === 'company_id', 'target company boundary must be company_id');
ok_three_system(($data['canonical_target_identity']['human_actor'] ?? null) === 'user_id', 'human actor must remain distinct as user_id');
$invariant = (string) ($data['permanent_invariant'] ?? '');
foreach (['Workforce', 'Command Bus', 'authoritative domain extension', 'verified outcome'] as $needle) {
    ok_three_system(str_contains($invariant, $needle), 'permanent invariant missing ' . $needle);
}
$matrix = $data['authority_matrix'] ?? [];
ok_three_system(count($matrix) >= 15, 'authority matrix incomplete');
$byCapability = [];
foreach ($matrix as $row) $byCapability[$row['capability'] ?? ''] = $row;
ok_three_system(($byCapability['organisation_and_staff']['target_owner'] ?? null) === 'titan-ai-workforce', 'Workforce ownership drift');
ok_three_system(($byCapability['consequential_tool_execution']['target_owner'] ?? null) === 'titan-command-bus', 'Command Bus execution ownership drift');
ok_three_system(($byCapability['human_conversational_surface']['target_owner'] ?? null) === 'ai-chat-pro+purpose_surfaces', 'surface ownership drift');
$summary = $data['scan_summary']['workforce'] ?? [];
ok_three_system(($summary['company_id_occurrences'] ?? 0) > 0, 'legacy tenant key must be documented before Pass 2 migration');
ok_three_system(($data['next_pass'] ?? null) === 'Pass 2 — Canonical Company + Runtime Identity', 'next pass mismatch');

echo "PASS: coordinated three-system architecture freeze contract\n";
