# Pass 7 — Intrinsic Organisational Graph & Reporting

Pass 7 makes the organisational graph a canonical Workforce-owned domain. The intrinsic relationship catalogue contains seven structural relationship types: `reports_to`, `manages`, `coordinates`, `consults`, `informs`, `delegates_to`, and `escalates_to`.

The catalogue is definition-first. It creates no employees. When both role endpoints already have active members in the same `company_id`, Workforce may materialise the corresponding relationship. All edges carry `authority_inherited=false`; delegation therefore routes work but never transfers capability, Risk, Assurance, Governance, or Autonomy authority.

Graph validation rejects self-relationships, cross-company endpoints, missing/inactive manager references, missing relationship endpoints, invalid relationship types, and reporting cycles. The organisation graph API includes the resulting integrity verdict.

The canonical hierarchy remains Owner → Titan Zero → AI Business Manager → division managers → intrinsic staff, with Operations Manager providing daily cross-division coordination.
