<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Console\Commands;

use App\Extensions\TitanAIWorkforce\System\Services\ProactiveWorkforceService;
use App\Extensions\TitanAIWorkforce\System\Services\LegacyAgentTriggerScanBridge;
use Illuminate\Console\Command;

class DispatchDueWorkforceSchedulesCommand extends Command
{
    protected $signature = 'titan-workforce:dispatch-due {--limit=100}';
    protected $description = 'Create governed Workforce tasks from due proactive responsibilities.';
    public function handle(ProactiveWorkforceService $service, LegacyAgentTriggerScanBridge $legacyTriggers): int
    {
        $count = $service->dispatchDue((int) $this->option('limit'));
        $this->info("Dispatched {$count} proactive Workforce task(s).");
        $legacy = $legacyTriggers->scan();
        if (($legacy['accepted'] ?? false) === true) {
            $this->line('Routed ' . (int) ($legacy['emitted'] ?? 0) . ' legacy Agent schedule trigger(s) through Titan Signal.');
        }
        return self::SUCCESS;
    }
}
