# Step 03 — Interactive Organisation Map

The Team Center is now a company-scoped interactive organisation map over the canonical Workforce graph.

## Surfaces

- Divisions and operational teams
- Managers, specialists and other visible Workforce members
- Reporting and management relationships
- Deputies/substitutes
- Delegation links (including live delegation records)
- Open escalation paths
- Cross-team coordination/collaboration/handoff relationships
- Live capability-health and provider-dependency badges
- Workload/capacity and missing-manager warnings
- Direct Employee 360 navigation

## Filters

Division, team, role, lifecycle, degraded staff, overloaded staff, missing manager and provider dependency.

## Invariants

- `company_id` is the sole company boundary.
- Relationship edges never inherit authority.
- Capability/provider availability is read live and never grants execution authority.
- The map is a read-only projection; it does not mutate canonical reporting or capability state.
