# Coordinated Pass 4 — Extract Titan Agent Runtime

PLAN_ID: `6bb234ac-d390-4a3f-8be2-666f5dec8a81`

Pass 4 activates the shared `titan.agent-runtime/1` implementation from the Agents donor without transferring business authority. Titan AI Workforce remains the organisational/task authority; the Agent Runtime owns model/provider resolution, persona/prompt assembly, conversation/session state, scoped runtime memory, model invocation, streaming output and proposal-only tool-call parsing. AI Chat Pro only discovers the runtime transport in this pass.

Consequential actions remain forbidden from the runtime. Existing WorkflowEngine, schedules, triggers and ActionDispatcher are retained for compatibility and are explicitly scheduled for later subordination passes.
