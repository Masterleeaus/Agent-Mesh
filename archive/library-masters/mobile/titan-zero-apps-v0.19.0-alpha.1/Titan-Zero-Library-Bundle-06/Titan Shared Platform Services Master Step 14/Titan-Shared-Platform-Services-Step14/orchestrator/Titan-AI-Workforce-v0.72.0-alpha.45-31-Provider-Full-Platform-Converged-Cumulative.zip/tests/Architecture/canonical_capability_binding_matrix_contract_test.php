<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

foreach ([
    'System/Support/WorkforceCanonicalCapabilityMatrix.php',
    'resources/workforce/canonical-capability-binding-matrix.json',
    'resources/workforce/canonical-capability-binding-matrix.schema.json',
    'docs/PASS13-CANONICAL-CAPABILITY-BINDING-MATRIX.md',
] as $path) {
    $ok(is_file($root . '/' . $path), "Step 3 artifact missing: {$path}");
}

$matrix = is_file($root . '/resources/workforce/canonical-capability-binding-matrix.json')
    ? json_decode((string) file_get_contents($root . '/resources/workforce/canonical-capability-binding-matrix.json'), true)
    : [];
$rows = is_array($matrix['roles'] ?? null) ? $matrix['roles'] : [];
$ok(($matrix['schema_version'] ?? null) === '1.0', 'canonical capability matrix schema_version must be 1.0');
$ok(($matrix['organisation_owner'] ?? null) === 'titan-ai-workforce', 'Workforce must own the canonical role matrix');
$ok(($matrix['tenant_key'] ?? null) === 'company_id', 'matrix tenant key must be company_id');
$ok(($matrix['summary']['role_count'] ?? null) === 117, 'matrix must cover 117 canonical role nodes');
$ok(($matrix['summary']['intrinsic_role_count'] ?? null) === 115, 'matrix must cover all 115 Workforce-owned domain roles');
$ok(($matrix['summary']['executive_role_count'] ?? null) === 1, 'matrix must cover AI Business Manager');
$ok(($matrix['summary']['system_role_count'] ?? null) === 1, 'matrix must cover Titan Zero');
$ok(count($rows) === 117, 'matrix must contain exactly 117 role rows');

$roleFiles = [
    'resources/workforce/role-definitions.json',
    'resources/workforce/executive-role-definitions.json',
    'resources/workforce/system-role-definitions.json',
];
$expectedRoles = [];
foreach ($roleFiles as $file) {
    $defs = json_decode((string) file_get_contents($root . '/' . $file), true, flags: JSON_THROW_ON_ERROR);
    foreach ($defs as $definition) $expectedRoles[(string) $definition['role_definition_id']] = true;
}
$actualRoles = [];
foreach ($rows as $row) {
    $rid = (string) ($row['role_definition_id'] ?? '');
    $actualRoles[$rid] = true;
    $ok(($row['authority_inherited'] ?? null) === false, "{$rid} must never inherit provider authority");
    $ok(($row['execution_authority_granted'] ?? null) === false, "{$rid} matrix must not grant execution authority");
    $ok(($row['runtime_availability_requires_installed_provider'] ?? null) === true, "{$rid} provider access must be runtime-gated");
}
ksort($expectedRoles); ksort($actualRoles);
$ok(array_keys($actualRoles) === array_keys($expectedRoles), 'matrix role identities must exactly match canonical Workforce roles');

$ecosystem = json_decode((string) file_get_contents($root . '/resources/workforce/ecosystem-capability-registry.json'), true, flags: JSON_THROW_ON_ERROR);
$providers = [];
foreach ($ecosystem['providers'] as $provider) {
    $key = (string) $provider['extension']['key'];
    $providers[$key] = $provider;
}

$expectedProviderVersions = [
    'titan-ai' => '1.5.3',
    'titan-field' => '1.0.12',
    'titan-time-attendance' => '0.1.7',
    'titan-forge' => '0.9.0-alpha.8',
];
foreach ($expectedProviderVersions as $providerKey => $version) {
    $ok(($providers[$providerKey]['extension']['version'] ?? null) === $version, "canonical provider {$providerKey} must resolve to {$version}");
}

$rowsById = [];
foreach ($rows as $row) {
    $rid = (string) $row['role_definition_id'];
    $rowsById[$rid] = $row;
    $bindings = (array) ($row['provider_bindings'] ?? []);
    if ($rid !== 'titan.system.titan_zero') $ok(count($bindings) >= 1, "{$rid} must have at least one evidence-backed provider binding");
    foreach ($bindings as $binding) {
        $providerKey = (string) ($binding['provider'] ?? '');
        $ok(isset($providers[$providerKey]), "{$rid} binding references unknown provider {$providerKey}");
        $ok(($binding['authority_inherited'] ?? null) === false, "{$rid}/{$providerKey} binding must not inherit authority");
        if (! isset($providers[$providerKey])) continue;
        foreach (['capabilities','tools','commands','signals','data_sources','workflows'] as $section) {
            $published = [];
            foreach ((array) ($providers[$providerKey][$section] ?? []) as $item) {
                if (! is_array($item)) continue;
                $id = (string) ($item['id'] ?? $item['name'] ?? $item['workflow_id'] ?? '');
                if ($id !== '') $published[$id] = true;
            }
            foreach ((array) ($binding[$section] ?? []) as $id) {
                $ok(isset($published[(string) $id]), "{$rid}/{$providerKey} {$section} references unpublished surface {$id}");
            }
        }
    }
}

$titanZero = $rowsById['titan.system.titan_zero'] ?? [];
$ok(($titanZero['provider_bindings'] ?? null) === [], 'Titan Zero must have zero domain capability bindings');
$ok(count((array) ($titanZero['coordination_providers'] ?? [])) >= 6, 'Titan Zero must record its non-authoritative coordination/control-plane providers');

$providerKeysFor = static function (array $row): array {
    $keys = [];
    foreach ((array) ($row['provider_bindings'] ?? []) as $binding) $keys[] = (string) ($binding['provider'] ?? '');
    $keys = array_values(array_unique($keys)); sort($keys); return $keys;
};
$dispatcherProviders = $providerKeysFor($rowsById['titan.work.dispatcher'] ?? []);
foreach (['titan-connect','titan-field','titan-maps-intelligence'] as $required) {
    $ok(in_array($required, $dispatcherProviders, true), "Dispatcher must bind {$required}");
}
foreach (['titan.money.accounts_receivable_officer','titan.money.billing_coordinator'] as $rid) {
    $keys = $providerKeysFor($rowsById[$rid] ?? []);
    foreach (['crm','titan-financial-engine','titan-ledger'] as $required) {
        $ok(in_array($required, $keys, true), "{$rid} must bind {$required}");
    }
}

$class = is_file($root . '/System/Support/WorkforceCanonicalCapabilityMatrix.php')
    ? (string) file_get_contents($root . '/System/Support/WorkforceCanonicalCapabilityMatrix.php') : '';
foreach (['roles', 'role', 'bindingsForRole', 'providerKeysForRole', 'coordinationProvidersForRole'] as $needle) {
    $ok(str_contains($class, $needle), "canonical matrix implementation missing {$needle}");
}
$bindingRegistry = (string) file_get_contents($root . '/System/Support/WorkforceCapabilityBindingRegistry.php');
$ok(str_contains($bindingRegistry, 'WorkforceCanonicalCapabilityMatrix'), 'runtime binding registry must consume canonical capability matrix');
$ok(str_contains($bindingRegistry, 'bindingsForRole'), 'runtime role access must be driven by canonical matrix bindings');

$serviceProvider = (string) file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
$ok(str_contains($serviceProvider, 'WorkforceCanonicalCapabilityMatrix::class'), 'service provider must register canonical capability matrix');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$ok(in_array('titan-workforce.canonical-capability-matrix-v1', $manifest['capabilities'] ?? [], true), 'extension manifest missing canonical capability matrix capability');

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce canonical capability binding matrix contract\n";
