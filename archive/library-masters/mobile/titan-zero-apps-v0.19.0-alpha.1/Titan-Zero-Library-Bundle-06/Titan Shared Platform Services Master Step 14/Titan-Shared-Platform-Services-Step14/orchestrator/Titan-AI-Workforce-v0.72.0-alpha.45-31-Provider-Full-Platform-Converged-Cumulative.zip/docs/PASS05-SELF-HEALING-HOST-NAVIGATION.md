# Production Upgrade Pass 5 — Self-Healing Parent/Child Navigation

Titan AI Workforce owns its navigation definition but must remain compatible with both modern Titan contribution registries and the MagicAI `menus` table used by Installer 1.7.8 hosts.

## Canonical hierarchy

`AI Workforce` is the single parent dropdown. Its children are `Overview`, `Team`, `Work`, `Schedule`, `Control Room`, `Performance`, and `Add Staff Member`. All links target named routes owned by Titan AI Workforce.

## Host compatibility rules

1. Register `navigation.user` through `App\Support\Extensions\MenuContributionRegistry` when available.
2. Fall back to the generic `ContributionRegistry` when necessary.
3. If the MagicAI `menus` table exists, upsert by stable menu `key`.
4. Persist/repair the parent first and resolve its actual `menus.id`.
5. Persist/repair every child with that real `parent_id`; `parent_key` is never assumed to be a database relationship.
6. Existing administrator order and enabled/disabled state are preserved.
7. Structural vendor fields may self-heal: parent, route, route slug, label, icon, params, type, badge and operational extension flag.
8. Operational rows use `extension = NULL`; permissions, not MagicAI plan-feature filtering, govern access.
9. Duplicate keys are logged and only the canonical first row is repaired; destructive duplicate deletion is not performed automatically.
10. Regenerate host menu caches after a structural change, or when explicit `titan-workforce:host-sync` repair is requested.

## Failure behavior

Missing menu tables/columns or host MenuService APIs degrade navigation registration only. They must not break extension boot, mutate business state, or change Workforce authority.

## Operator repair

```bash
php artisan titan-workforce:host-sync
```

The command registers request-local contributions, repairs the host hierarchy when possible, and requests MagicAI menu-cache regeneration.
