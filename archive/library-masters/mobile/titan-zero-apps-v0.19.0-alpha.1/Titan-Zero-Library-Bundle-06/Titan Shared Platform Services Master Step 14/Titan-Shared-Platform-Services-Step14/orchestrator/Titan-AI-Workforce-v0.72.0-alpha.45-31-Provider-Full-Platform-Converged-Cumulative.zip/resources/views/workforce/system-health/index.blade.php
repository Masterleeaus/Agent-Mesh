@extends('panel.layout.app',['disable_tblr'=>true,'layout_wide'=>true])
@section('title',__('System Health'))
@section('content')
<div class="px-5 py-8 space-y-6">
<div class="flex flex-wrap items-start justify-between gap-4"><div><h1 class="text-2xl font-semibold">{{ __('Workforce System Health') }}</h1><p class="mt-1 text-sm text-foreground/60">{{ __('One diagnostic view across staff, providers, queues, outcomes and the governance control plane.') }}</p></div><span class="rounded-full border px-3 py-1 text-sm font-semibold">{{ $health['overall_state'] }}</span></div>
<div class="grid gap-4 md:grid-cols-4">@foreach(['active_staff'=>'Active staff','open_work'=>'Open work','blocked_work'=>'Blocked work','degraded_staff'=>'Degraded staff'] as $key=>$label)<div class="rounded-2xl border bg-card p-5"><div class="text-xs text-foreground/50">{{ __($label) }}</div><div class="mt-2 text-3xl font-semibold">{{ $health['workforce_health'][$key] }}</div></div>@endforeach</div>
<div class="grid gap-4 lg:grid-cols-2">
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Provider health') }}</h2><p class="mt-2 text-sm">{{ $health['workforce_health']['degraded_staff'] }} {{ __('staff currently degraded by capability/provider state.') }}</p></section>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Governance health') }}</h2><p class="mt-2 text-sm">{{ data_get($health,'governance_health.organisation.state','UNKNOWN') }}</p></section>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Outcome health') }}</h2><p class="mt-2 text-sm">{{ $health['outcome_health']['verification_missing'] ?? 0 }} {{ __('missing verification') }} · {{ $health['outcome_health']['verification_late'] ?? 0 }} {{ __('late') }}</p></section>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Queue health') }}</h2><div class="mt-2 space-y-1 text-sm">@foreach($health['queue_health'] as $row)<div>{{ $row['division'] }} — {{ $row['pressure'] }} ({{ $row['queue_depth'] }})</div>@endforeach</div></section>
</div>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Critical findings') }}</h2>@forelse($health['critical_findings'] as $finding)<div class="mt-3 rounded-xl border p-3 text-sm"><strong>{{ $finding['severity'] }}</strong> · {{ $finding['message'] }}</div>@empty<p class="mt-2 text-sm text-foreground/60">{{ __('No critical findings.') }}</p>@endforelse</section>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Recommended actions') }}</h2><ul class="mt-3 list-disc space-y-2 pl-5 text-sm">@forelse($health['recommended_actions'] as $action)<li>{{ $action }}</li>@empty<li>{{ __('No intervention currently recommended.') }}</li>@endforelse</ul><p class="mt-4 text-xs text-foreground/50">{{ __('Diagnostics are read-only and never grant execution authority.') }}</p></section>
</div>
@endsection
