<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
function ok_pass2(bool $condition, string $message): void { if (! $condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } }

$contract = json_decode((string) file_get_contents($root . '/docs/TITAN-THREE-SYSTEM-PASS02-RUNTIME-IDENTITY.json'), true, flags: JSON_THROW_ON_ERROR);
ok_pass2(($contract['plan_id'] ?? null) === '6bb234ac-d390-4a3f-8be2-666f5dec8a81', 'PLAN_ID mismatch');
ok_pass2(($contract['pass'] ?? null) === 2, 'coordinated pass mismatch');
ok_pass2(($contract['canonical_company_boundary'] ?? null) === 'company_id', 'company_id must be canonical');
$required = ['company_id','user_id','workforce_member_id','workforce_role_id','workforce_task_id','runtime_profile_id','conversation_id','channel_id','source_extension','capability','capability_variant','vertical','workflow_ref','trace_id','correlation_id','causation_id'];
ok_pass2(($contract['runtime_identity_fields'] ?? []) === $required, 'runtime identity fields drifted');

$runtime = (string) file_get_contents($root . '/System/Runtime/RuntimeIdentity.php');
foreach ($required as $field) {
    $camel = lcfirst(str_replace(' ', '', ucwords(str_replace('_', ' ', $field))));
    ok_pass2(str_contains($runtime, $field) || str_contains($runtime, '$' . $camel), "RuntimeIdentity missing {$field}");
}
ok_pass2(str_contains($runtime, 'company boundary mismatch') || str_contains($runtime, 'company_id do not match'), 'RuntimeIdentity must reject company mismatch');

$companyContext = (string) file_get_contents($root . '/System/Support/CompanyContext.php');
ok_pass2(str_contains($companyContext, "attribute(\$user, 'company_id')"), 'CompanyContext must read company_id');
ok_pass2(! str_contains($companyContext, 'tenant_company_id'), 'CompanyContext must not read legacy tenant key');

$legacyMigration = $root . '/database/migrations/2026_08_21_000010_canonical_company_runtime_identity.php';
ok_pass2(is_file($legacyMigration), 'canonical company migration missing');
$legacy = (string) file_get_contents($legacyMigration);
ok_pass2(str_contains($legacy, "renameColumn('tenant_company_id', 'company_id')"), 'legacy migration must rename retired key in place');

$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/System'));
foreach ($iterator as $file) {
    if (! $file->isFile() || $file->getExtension() !== 'php') continue;
    ok_pass2(! str_contains((string) file_get_contents($file->getPathname()), 'tenant_company_id'), 'legacy tenant key leaked into active runtime: ' . $file->getPathname());
}

$schema = json_decode((string) file_get_contents($root . '/schemas/titan-runtime-identity.schema.json'), true, flags: JSON_THROW_ON_ERROR);
ok_pass2(($schema['required'] ?? []) === ['company_id'], 'identity schema must require only company_id');
foreach ($required as $field) ok_pass2(isset($schema['properties'][$field]), "identity schema missing {$field}");

echo "PASS: coordinated canonical company + runtime identity contract\n";
