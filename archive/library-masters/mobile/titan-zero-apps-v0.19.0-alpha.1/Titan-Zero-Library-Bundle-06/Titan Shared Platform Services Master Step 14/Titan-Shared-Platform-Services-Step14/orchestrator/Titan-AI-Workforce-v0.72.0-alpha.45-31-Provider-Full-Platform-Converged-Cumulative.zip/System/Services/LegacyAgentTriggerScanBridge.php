<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use Illuminate\Contracts\Container\Container;

/** Lets the Workforce-owned scheduler ask Agents to scan legacy cron definitions without executing them. */
final class LegacyAgentTriggerScanBridge
{
    public const TRANSPORT = 'titan.agent-runtime.legacy-trigger-scan/1';

    public function __construct(private readonly Container $app) {}

    /** @return array<string,mixed> */
    public function scan(): array
    {
        if (! $this->app->bound(self::TRANSPORT)) {
            return ['accepted' => false, 'status' => 'legacy_agent_runtime_absent', 'emitted' => 0, 'business_outcome_claimed' => false];
        }
        $transport = $this->app->make(self::TRANSPORT);
        $result = is_callable($transport) ? $transport() : (method_exists($transport, 'scan') ? $transport->scan() : null);
        if (! is_array($result)) {
            return ['accepted' => false, 'status' => 'invalid_legacy_trigger_scan_transport', 'emitted' => 0, 'business_outcome_claimed' => false];
        }
        $result['business_outcome_claimed'] = false;
        return $result;
    }
}
