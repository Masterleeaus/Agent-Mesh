# New Plan Step 04 — Decision Rights & RACI Center

Titan AI Workforce now exposes one company-scoped Decision Rights & RACI Center covering Responsible, Accountable, Consulted, Informed, Reviewer, Escalation Owner and Human-required decisions.

The canonical Workforce policy catalogue contains 25 intrinsic organisational decisions for staffing, manager/deputy changes, proactive operations, capability policy, high-risk review, Assurance/Autonomy disposition, recovery, handoffs, deadlocks, escalations, outcomes, incidents, data access, finance/customer/service exceptions and strategic changes. Domain-extension decisions remain extension-owned and continue to arrive through Workforce Manifest RACI declarations. The runtime merges both sources and preserves provenance.

RACI is organisational metadata only. It never creates provider access, capability binding, risk clearance, Assurance approval, Governance authority, Autonomy authorization or Command Bus execution rights. Every canonical row explicitly records `authority_inherited=false` and `execution_authority_granted=false`.
