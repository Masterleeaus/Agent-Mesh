# Integrated Upgrade Pass 5 — Titan Zero Chief of Staff

Titan Zero is now the permanent owner-facing system role for Titan AI Workforce.

## Canonical identity

- RoleDefinition: `titan.system.titan_zero`
- Member system key: `titan-zero`
- Business role: `Chief of Staff`
- Definition scope: `SYSTEM`
- Staffing entitlement: **does not consume a seat**
- Lifecycle: permanent; normal suspend/retire/delete paths are denied
- Human identity: autonomous system member; it does not borrow the activating user's `user_id`

## Responsibility boundary

Titan Zero has company-scoped organisation-wide visibility and coordination permissions for objectives, delegation requests, management councils, approval routing, escalations and briefing aggregation. It receives **no domain executable capabilities** in this pass.

Titan Zero is deliberately powerful through coordination rather than bypass authority. Consequential execution still requires the normal Workforce governance path:

`Risk → Assurance → Governance policy → Autonomy → Command Bus`

The execution guard rejects explicit skip/bypass/force-authority flags for Titan Zero. Risk, Assurance, Governance and Autonomy cannot be bypassed by this system role.

## Operational isolation

Titan Zero is excluded from ordinary staffing-seat counts, legacy operational manager loops, extension-manifest lifecycle reconciliation and proactive extension-owned responsibility syncing. Existing Workforce manager behaviour therefore remains unchanged until the executive-layer work in Pass 6.
