# Pass 12 — Risk, Assurance, Model Council & Interaction Integration

Titan AI Workforce remains an organisational runtime. It does not calculate Risk, Assurance, Model Council consensus or Interaction Engine procedure authority.

## Canonical pre-execution chain

`Workforce task → Titan Risk → Titan Assurance → selective Model Council → Titan Autonomy → required Interaction workflow → Command Bus`

Risk categories are **Minimal / Low / Medium / High / Extreme**. Titan Risk must return an explicit allow/deny result plus policy/version evidence. Context passed to Risk can include contextual, cumulative, vertical and residual risk references. A Green Assurance result never overrides a High or Extreme Risk denial; Workforce simply enforces the Risk decision.

Titan Assurance returns **Green / Amber / Red** with evidence references, missing-evidence information and its own explicit allow/deny decision. Red or denied Assurance blocks execution. Workforce does not turn model confidence into Assurance.

## Selective Model Council

Model Council is **not** invoked for every task. It is required only when Titan Risk returns `requires_model_council=true`, or an explicit governed task/policy flag requires it. If required, the Council dependency must be available and return a policy-satisfied result. Missing or malformed required Council evidence fails closed.

## Interaction Engine and evidence collection

Every capability uses the owning extension's Workforce Manifest. Capability evidence requirements are compared with the task's structured evidence. When required evidence is missing, Workforce resolves an extension-owned workflow or Wizard into its concrete Interaction Engine workflow and prepares an **evidence collection** journey. The task moves to `AWAITING_DATA`; it does not execute while evidence is incomplete.

If a required procedure/evidence workflow is missing or Titan Interaction Engine is unavailable, execution fails closed. Wizards/workflows prepare/collect evidence and proposals only; they never mutate authoritative business state.

## Handoffs

New handoff packets carry explicit `evidence_refs` in addition to structured evidence, Risk, Assurance, Autonomy and governance snapshots. This lets the receiving Manager review the same evidence references that supported the originating decision instead of receiving only a generated summary.

## Fail-closed rules

- Required Risk unavailable or malformed → block.
- Required Assurance unavailable or malformed → block.
- Required Model Council unavailable or policy-unsatisfied → block.
- Missing evidence → prepare Interaction evidence collection and wait.
- Required Interaction workflow unavailable → block.
- Green Assurance never cancels a Risk denial.
- Titan AI Workforce cannot mint approvals or permissive defaults for missing governance engines.

The default posture is **fail closed** whenever a required governance dependency or evidence workflow cannot be proven.
