<?php

declare(strict_types=1);

function fail_manifest_owned(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok_manifest_owned(bool $condition, string $message): void { if (! $condition) fail_manifest_owned($message); }

$root = dirname(__DIR__, 2);

ok_manifest_owned(is_file($root . '/System/Support/WorkforceManifestRegistry.php'), 'central WorkforceManifestRegistry missing');
ok_manifest_owned(is_file($root . '/System/Support/WorkforceManifestValidator.php'), 'central WorkforceManifestValidator missing');
ok_manifest_owned(is_file($root . '/resources/workforce/role-definitions.json'), 'AI Workforce must ship canonical intrinsic role definitions after Pass 4');
ok_manifest_owned(is_file($root . '/resources/workforce/division-definitions.json'), 'AI Workforce must ship canonical intrinsic division definitions after Pass 3');
ok_manifest_owned(! is_file($root . '/resources/workforce/proactive-responsibilities.json'), 'AI Workforce must not ship domain proactive responsibility definitions');

$provider = (string) file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
ok_manifest_owned(str_contains($provider, "'titan.workforce.manifests'"), 'manifest registry container binding missing');
ok_manifest_owned(str_contains($provider, "'titan-workforce.manifests'"), 'extension contribution registry alias missing');
ok_manifest_owned(str_contains($provider, 'WorkforceManifestRegistry::class'), 'provider must bind central manifest registry');

$registry = (string) file_get_contents($root . '/System/Support/WorkforceRoleRegistry.php');
ok_manifest_owned(! str_contains($registry, '$extensionRoles'), 'canonical role registry must not append extension-owned employee definitions');
ok_manifest_owned(str_contains($registry, 'IntrinsicRoleCatalog'), 'role registry must expose the Workforce-owned intrinsic catalogue while retaining manifest compatibility');

$bootstrap = (string) file_get_contents($root . '/System/Services/WorkforceBootstrapService.php');
ok_manifest_owned(! str_contains($bootstrap, 'WorkforceMember::query()->firstOrCreate'), 'bootstrap must not install/seed workforce members');
ok_manifest_owned(str_contains($bootstrap, 'WorkforceManifestRegistry'), 'legacy company-instance bootstrap compatibility must remain until team activation passes migrate it');

$core = (string) file_get_contents($root . '/System/Support/CoreWorkforceCatalog.php');
ok_manifest_owned(! str_contains($core, 'customer-action-worker'), 'central Workforce must not ship generic domain Action Workers');
ok_manifest_owned(! str_contains($core, 'finance-action-worker'), 'central Workforce must not ship finance Action Workers');


$controller = (string) file_get_contents($root . '/System/Http/Controllers/WorkforceController.php');
$lifecycle = (string) file_get_contents($root . '/System/Services/WorkforceMemberLifecycleService.php');
ok_manifest_owned(str_contains($controller, 'activateFromDefinition'), 'Employee Builder must delegate activation to the manifest-governed lifecycle service');
ok_manifest_owned(str_contains($lifecycle, 'WorkforceCapabilityAvailabilityService'), 'staff activation must attach only live provider capabilities; capabilities remain extension-owned');
ok_manifest_owned(str_contains($lifecycle, 'autonomy_profile.starting_level'), 'staff activation must preserve the Workforce role autonomy ceiling without provider authority inheritance');
ok_manifest_owned(str_contains($lifecycle, "'owner_extension' => 'titan-ai-workforce'"), 'instantiated staff must retain Workforce-owned role provenance');
ok_manifest_owned(str_contains($lifecycle, "'capability_providers'"), 'instantiated staff must retain provider capability provenance');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
ok_manifest_owned(in_array('titan-workforce.manifest-registry', $manifest['capabilities'] ?? [], true), 'manifest-registry capability missing');
ok_manifest_owned(($manifest['schema_version'] ?? null) === '2.2', 'central sidecar must use Manifest 2.2');
ok_manifest_owned(($manifest['workforce']['source_of_truth'] ?? null) === 'central-runtime', 'central runtime source-of-truth declaration missing');
ok_manifest_owned(in_array('workforce-role-definitions', $manifest['authority']['owns'] ?? [], true), 'manifest must declare converged Workforce ownership of role definitions');
ok_manifest_owned(! in_array('workforce-role-definitions', $manifest['authority']['must_not_own'] ?? [], true), 'role definitions must no longer be external-only');

$plan = (string) file_get_contents($root . '/docs/AI-WORKFORCE-BUILD-PLAN.md');
$pass2 = (string) file_get_contents($root . '/docs/PASS02-CANONICAL-WORKFORCE-DOMAIN.md');
ok_manifest_owned(str_contains($pass2, 'Workforce owns the organisation'), 'Pass 2 must document intrinsic Workforce domain ownership');
ok_manifest_owned(str_contains($pass2, 'extensions contribute capabilities'), 'Pass 2 must preserve extension capability ownership');

$capabilityOwnershipRule = 'capabilities remain extension-owned';
ok_manifest_owned($capabilityOwnershipRule === 'capabilities remain extension-owned', 'capabilities remain extension-owned');

echo "PASS: Titan AI Workforce manifest compatibility contract\n";
