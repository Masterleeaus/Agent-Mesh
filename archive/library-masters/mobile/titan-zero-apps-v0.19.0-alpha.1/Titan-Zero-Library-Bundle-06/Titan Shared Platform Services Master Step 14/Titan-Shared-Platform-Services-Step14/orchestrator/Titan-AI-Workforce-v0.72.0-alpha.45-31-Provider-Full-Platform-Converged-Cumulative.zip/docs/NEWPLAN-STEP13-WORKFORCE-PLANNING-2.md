# New Roadmap Step 13 — Workforce Planning 2.0

Version: 0.64.0-alpha.37

Adds company-scoped capacity planning across overloaded teams, underused staff, responsibility gaps, capability/provider gaps, manager span, bottlenecks and 14-day upcoming workload. Proposed roles expose expected benefit and canonical provider requirements. No recommendation auto-hires staff; Employee Builder remains the explicit approval/creation gate. Planning never grants capability, authority, autonomy or risk-ceiling changes.
