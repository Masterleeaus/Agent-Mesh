<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
function ok14(bool $condition, string $message): void { if (! $condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } }
function source14(string $path): string { $value = file_get_contents($path); if ($value === false) { fwrite(STDERR, "FAIL: cannot read {$path}\n"); exit(1); } return $value; }

$required = [
    '/System/Models/WorkforceJourneyRecord.php',
    '/System/Services/WorkforceJourneySpineService.php',
    '/System/Services/WorkforceOutcomeHealthService.php',
    '/database/migrations/2026_08_20_000009_create_workforce_journey_records.php',
    '/docs/PASS14-SIGNAL-REWIND-WISDOM-OUTCOME-SPINE.md',
];
foreach ($required as $relative) ok14(is_file($root.$relative), 'missing Pass 14 artifact '.$relative);

$model = source14($root.'/System/Models/WorkforceJourneyRecord.php');
foreach (['ext_titan_ai_workforce_journey_records','updating','deleting','append-only'] as $needle) {
    ok14(str_contains($model, $needle), 'journey record model missing '.$needle);
}

$migration = source14($root.'/database/migrations/2026_08_20_000009_create_workforce_journey_records.php');
foreach (['event_uuid','company_id','task_id','member_id','category','phase','event_type','trace_id','correlation_id','causation_id','rationale_refs','evidence_refs','decision_refs','execution_refs','outcome_refs','event_sha256','observed_at'] as $needle) {
    ok14(str_contains($migration, $needle), 'journey migration missing '.$needle);
}

$spine = source14($root.'/System/Services/WorkforceJourneySpineService.php');
foreach (['WorkforceSignalBridge','titan.rewind','recordTaskLifecycle','recordStaffingLifecycle','recordExecutionLifecycle','recordVerifiedOutcome','journeyForTask','trace_id','correlation_id','causation_id','rationale_refs','decision_refs','execution_refs','outcome_refs','sanitizeStructured'] as $needle) {
    ok14(str_contains($spine, $needle), 'journey spine missing '.$needle);
}
foreach (['chain_of_thought','hidden_reasoning','private_reasoning','cot'] as $needle) {
    ok14(str_contains($spine, "'{$needle}'"), 'journey spine must explicitly filter '.$needle);
}
ok14(! str_contains($spine, "'reasoning' =>"), 'journey spine must not persist a raw reasoning field');

$taskService = source14($root.'/System/Services/WorkforceTaskService.php');
ok14(str_contains($taskService, 'WorkforceJourneySpineService'), 'task lifecycle must flow through the journey spine');
ok14(! str_contains($taskService, 'private readonly WorkforceSignalBridge $signals'), 'task lifecycle must not bypass the journey spine for Signal delivery');

$staffing = source14($root.'/System/Services/WorkforceStaffingProposalService.php');
ok14(str_contains($staffing, 'WorkforceJourneySpineService'), 'staffing lifecycle must flow through the journey spine');
foreach (['staffing.recommended','staffing.approved','staffing.rejected'] as $needle) ok14(str_contains($staffing, $needle), 'staffing journey missing '.$needle);

$outcome = source14($root.'/System/Services/WorkforceOutcomeFeedbackService.php');
foreach (['recordVerifiedOutcome','observeExternalVerifiedOutcome','verified','domain_state_ref','WorkforceControlPlaneIntegrationRegistry',"bindingsFor('wisdom')",'recordOutcomeEvidence','outcome_ref','verification_ref','authority_mutation_requested'] as $needle) {
    ok14(str_contains($outcome, $needle), 'outcome feedback missing '.$needle);
}
ok14(str_contains($outcome, "'WISDOM_WITHHELD_UNVERIFIED_OUTCOME'"), 'unverified outcomes must be withheld from Wisdom');
ok14(! str_contains($outcome, 'model_self_evaluation'), 'model self-evaluation must never be treated as outcome evidence');

$health = source14($root.'/System/Services/WorkforceOutcomeHealthService.php');
foreach (['OUTCOME_VERIFICATION_MISSING','OUTCOME_VERIFICATION_LATE','RECOVERY','verification_status','late_after_minutes'] as $needle) {
    ok14(str_contains($health, $needle), 'outcome health service missing '.$needle);
}

$performance = source14($root.'/System/Services/WorkforcePerformanceService.php');
foreach (['WorkforceJourneyRecord','verified_outcome_count','negative_outcome_count'] as $needle) ok14(str_contains($performance, $needle), 'performance must consume verified outcome evidence '.$needle);
$maturity = source14($root.'/System/Services/WorkforceMaturityService.php');
foreach (['negative_outcome_count','RECENT_NEGATIVE_OUTCOME','authority_changed','autonomy_changed'] as $needle) ok14(str_contains($maturity, $needle), 'maturity outcome safety missing '.$needle);

$provider = source14($root.'/System/TitanAIWorkforceServiceProvider.php');
foreach (['titan.workforce.journey-spine','titan.workforce.outcome-health','api/journey','api/outcome-health','outcome_verified'] as $needle) ok14(str_contains($provider, $needle), 'provider missing Pass 14 surface '.$needle);

$capabilities = source14($root.'/System/Support/WorkforceCapabilityCatalog.php');
foreach (['workforce.journey.read','workforce.outcome-health.read'] as $needle) ok14(str_contains($capabilities, $needle), 'capability catalog missing '.$needle);

$manifest = json_decode(source14($root.'/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$names = $manifest['capabilities'] ?? [];
ok14(in_array('titan-workforce.outcome-feedback-spine-v2', $names, true), 'manifest missing Pass 14 high-level capability');

fwrite(STDOUT, "PASS: Signal/Rewind/Wisdom outcome spine contract\n");
