<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Compatibility;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberStatus;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Services\RuntimeProfileBindingService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class LegacyBlogPilotImportService
{
    public function __construct(private readonly RuntimeProfileBindingService $runtimeProfiles) {}

    public function preview(): array
    {
        if (! Schema::hasTable('ext_blogpilot')) {
            return [];
        }
        return DB::table('ext_blogpilot')->orderBy('id')->get(['id','user_id','name','schedule_days','schedule_times'])->map(fn ($row) => (array) $row)->all();
    }

    public function importSelected(int $tenantCompanyId, array $legacyIds): array
    {
        if ($tenantCompanyId < 1 || ! Schema::hasTable('ext_blogpilot')) {
            return [];
        }

        $imported = [];
        foreach (DB::table('ext_blogpilot')->whereIn('id', array_map('intval', $legacyIds))->get() as $legacy) {
            $key = 'legacy-blogpilot-' . $legacy->id;
            $member = WorkforceMember::query()->firstOrCreate(
                ['company_id' => $tenantCompanyId, 'key' => $key],
                [
                    'tier' => 2, 'name' => $legacy->name ?: 'Imported Workforce Specialist', 'role' => 'Imported Specialist',
                    'purpose' => 'Imported from BlogPilot for explicit compatibility review. No publishing or mutation authority is carried forward.',
                    'responsibilities' => ['Review and remap legacy BlogPilot configuration'],
                    'schedule_config' => ['days' => json_decode($legacy->schedule_days ?? '[]', true), 'times' => json_decode($legacy->schedule_times ?? '[]', true)],
                    'risk_ceiling' => 'LOW', 'status' => WorkforceMemberStatus::Suspended, 'is_active' => false,
                    'metadata' => ['legacy_blogpilot_id' => $legacy->id, 'explicit_import' => true],
                ]
            );
            $profile = $this->runtimeProfiles->ensureForMember($member);
            if ((string) $member->runtime_profile_id !== (string) $profile->profile_id) {
                $member->forceFill(['runtime_profile_id' => (string) $profile->profile_id])->save();
            }
            $imported[] = $member->id;
        }
        return $imported;
    }
}
