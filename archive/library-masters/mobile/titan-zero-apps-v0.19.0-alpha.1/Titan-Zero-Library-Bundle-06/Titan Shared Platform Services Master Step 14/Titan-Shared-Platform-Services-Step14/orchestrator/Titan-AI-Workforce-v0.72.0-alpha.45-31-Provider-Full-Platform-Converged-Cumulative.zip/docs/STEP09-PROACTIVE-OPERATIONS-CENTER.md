# UI Step 09 — Proactive Operations Center

The Proactive Operations Center is the company-scoped operational answer to **“What is the Workforce doing by itself?”**

It projects scheduled and Titan Signal-driven routines, responsible employees, last/next run, last triggering Signal, generated work, skipped/degraded/blocked run telemetry, provider dependencies, live capability health and recent generated tasks.

Run telemetry is stored inside each existing `WorkforceSchedule.metadata.run_telemetry` record; no parallel execution ledger is introduced. Scheduled and event ingress update generated/skipped/degraded/blocked counters at the point a run is evaluated.

This surface is observational. Capability availability, routine state and provider presence never grant execution authority; consequential tasks continue through Risk, Assurance, Governance, Autonomy and Command Bus.
