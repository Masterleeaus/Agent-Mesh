# Pass 10 — Workforce Capability Binding

Titan AI Workforce owns the organisation: divisions, teams, roles, responsibilities, reporting identity and staff instances. Business extensions no longer own employee identity. They contribute execution surfaces which are attached to intrinsic Workforce roles.

## Canonical ownership

- **Workforce owns:** role definitions, employee identity, division/team placement, responsibilities and reporting graph.
- **Provider extensions own:** capabilities, tools, commands, signals, data sources and workflow definitions.
- **Titan control plane owns authority decisions:** Risk, Assurance, Governance and Autonomy remain mandatory. A binding never grants authority by inheritance.
- **Command Bus owns mutation dispatch:** capability providers expose governed execution surfaces; Workforce does not write foreign domain state directly.

## Capability Binding v1

The stable provider contract is `titan.workforce.capability-bindings.v1`, described by `resources/workforce/workforce-capability-binding.schema.json`.

A contribution contains:

- `role_bindings` — attachment from provider surfaces to a canonical `role_definition_id`.
- `capabilities` — provider-owned capability contracts.
- `tools` — provider-owned tools.
- `commands` — state-mutating command surfaces.
- `signals` — provider event surfaces.
- `data_sources` — read-only/informational surfaces.
- `workflows` — provider workflow surfaces.

Every role binding sets `authority_inherited=false`.

## Manifest 2.0 compatibility

Existing Workforce Manifest 2.0 packages remain accepted during the compatibility window. Their role blocks are translated as `legacy_v2_role_hint` binding hints only when the role ID/key resolves to an intrinsic Workforce role. Non-matching role blocks remain visible to compatibility diagnostics but do not create canonical employees.

The translated provider still owns its capability/tool/workflow contracts. Write tools are represented as commands; read-only tools are represented as data sources; proactive signal declarations are represented as signal surfaces.

## Staff activation

The Employee Builder now sources staff from `WorkforceRoleRegistry`, which contains only Workforce-owned executive and intrinsic roles. At activation, `WorkforceCapabilityBindingRegistry` attaches currently available provider surfaces to the member. Provider availability is separate from role lifecycle.

New intrinsic staff are pinned with:

- `role_owner_extension = titan-ai-workforce`
- canonical `role_definition_id`
- provider capability provenance in member metadata

A provider being disabled must not make the employee definition disappear. Safe degradation of unavailable capabilities is expanded in Pass 16.

## Capability owner provenance

`role_owner_extension` cannot identify the action provider after role convergence. Pass 10 therefore introduces `capability_owner_extension` and `capability_owner_extension_version` on Workforce tasks/actions/execution attempts. Historical extension-owned tasks are backfilled from their old role owner only when that value is not `titan-ai-workforce`.

If exactly one provider bound to an intrinsic role owns a requested capability, Workforce may resolve it automatically. Ambiguous or absent ownership fails closed before consequential execution.

## Non-goals

Pass 10 does not:

- migrate every peer extension to a native Capability Binding v1 manifest (Pass 15),
- populate the complete ecosystem capability registry (Pass 11),
- activate proactive scheduled/event responsibilities (Passes 20–21),
- increase any role's delegated authority (Pass 31).
