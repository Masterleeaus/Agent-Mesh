# Step 10 — Capability Health & Provider Inspector

The Workforce now exposes the v0.41+ capability architecture as a company-scoped, read-only operational inspector.

## Views
Providers, Roles, Employees, Capabilities, Tools, Commands, Signals, Data sources, and Workflows.

## Provider health
Each canonical ecosystem provider reports installed, active, degraded, missing, and quarantined state; catalogue version; dependent canonical roles; affected company employees; and counts of provided execution surfaces. Runtime presence is determined from the canonical ecosystem provider class/contribution and manifest quarantine health, not from cached employee snapshots.

## Employee health
Each employee reports expected providers from the Workforce-owned canonical matrix, currently available providers from live capability resolution, degraded capabilities, policy-disabled capabilities, and fallback eligibility where the same canonical surface is already bound through another provider.

Fallback eligibility is diagnostic only. It sets neither `fallback_authority_granted` nor `authority_inherited`; consequential work remains subject to task-scoped Risk, Assurance, Governance, Autonomy, and Command Bus execution.
