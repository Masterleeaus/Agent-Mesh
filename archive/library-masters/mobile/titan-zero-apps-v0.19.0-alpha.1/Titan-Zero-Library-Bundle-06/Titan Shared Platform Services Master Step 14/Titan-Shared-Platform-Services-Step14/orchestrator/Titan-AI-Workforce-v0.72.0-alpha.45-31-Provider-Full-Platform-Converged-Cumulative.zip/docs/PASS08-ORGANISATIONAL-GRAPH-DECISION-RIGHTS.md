# Pass 8 — Organisational Graph, Deputies, RACI & Decision Rights Hardening

Titan AI Workforce owns the instantiated organisational graph, not domain authority definitions.

## Acyclic reporting graph

Manager assignment is now a transactional graph mutation. Before a new `reports_to` edge is persisted, Workforce walks the tenant's existing `manager_id` chain and rejects self-management, proposed loops, pre-existing loops, and excessive traversal depth with `REPORTING_CYCLE`. Successful reassignment synchronises the member's `manager_id` plus reciprocal `reports_to`, `manages`, and `reviews_for` relationships.

## Extension-owned RACI

**Extension-owned RACI** from each installed Workforce Manifest 2.0 is the source of organisational decision rights. RACI rows retain the owning extension/version and use exact `role_definition_id` values. The validator requires at least one Responsible role, exactly one Accountable role, valid role references, and no duplicate decision key inside one extension manifest.

RACI never grants business execution authority. A Responsible or Accountable staff member still needs the normal Titan Risk, Assurance, Autonomy, Interaction and Command Bus gates. Conversation, RACI membership, deputy appointment, maturity, or management status cannot elevate those external decisions.

## Scoped deputies

Deputy coverage is permitted only between active same-division Tier-1 Managers. Every appointment requires:

- a non-empty explicit scope;
- a future expiry;
- `authority_inherited=false`;
- `requires_existing_autonomy=true`.

Deputies may act only while the assigned Manager is unavailable and only inside the recorded scope. This is **no authority inheritance**: the deputy uses its own role capability, Risk ceiling and Titan Autonomy decision.

## Delegation and handoffs

Direct delegation is same-division only. A Manager may delegate approved specialist work to an eligible Tier-3 Action Worker in the same division, recording a scoped `delegates_to` relation with no authority inheritance. Cross-division work must use the existing governed handoff chain and receiving-Manager acceptance.

## Disputes and escalation

A dispute must identify at least two tenant-scoped participant Managers. Workforce deterministically walks the persisted reporting graph and selects the first unambiguous common escalation Manager. If there is no common Manager, if the graph is cyclic, or if the route is ambiguous, the dispute terminates as **`HUMAN_DECISION_REQUIRED`** rather than inventing authority.

## Public surfaces

Read-only:

- `GET api/organisation-graph`
- `GET api/decision-rights`
- `titan.workforce.organisation-graph`
- `titan.workforce.decision-rights`
- `titan.workforce.escalation`

Governed mutations:

- `POST staff/{member}/manager`
- `POST staff/{member}/deputy`
- permission `titan-workforce.organisation.manage`

All routes remain authenticated, host-authorized and tenant-scoped.
