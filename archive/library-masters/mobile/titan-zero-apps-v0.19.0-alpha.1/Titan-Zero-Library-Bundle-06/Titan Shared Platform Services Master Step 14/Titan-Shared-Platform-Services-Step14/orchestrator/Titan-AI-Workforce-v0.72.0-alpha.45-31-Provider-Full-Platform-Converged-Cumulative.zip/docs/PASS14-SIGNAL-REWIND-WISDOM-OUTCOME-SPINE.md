# Pass 14 — Signal, Rewind, Wisdom & Outcome Feedback Spine

Version: `0.20.0-alpha.20`

## Ownership

Titan AI Workforce owns the organisational evidence spine only. Titan Signal remains event transport, Titan Rewind remains reconstructable history/evidence authority, Titan Wisdom remains outcome-learning authority, and Titan Autonomy remains authority/evidence calibration authority.

## Structured journey spine

Every task lifecycle event is captured as an append-only `WorkforceJourneyRecord` with:

- tenant, task and member identity;
- category and phase (`DECISION`, `EXECUTION`, `OUTCOME`, `ORGANISATION`);
- event type;
- `trace_id`, `correlation_id`, and `causation_id`;
- rationale **references**, evidence references, decision references, execution references and outcome references;
- sanitized summary data;
- canonical SHA-256 event fingerprint.

The same structured event is emitted through the durable Workforce Signal outbox and offered to Titan Rewind as reference-only evidence.

Private chain-of-thought, hidden reasoning, private reasoning, scratchpads and internal monologue fields are filtered before persistence or external transport.

## Lifecycle coverage

The spine captures task creation/transitions and therefore includes Maker submission, Manager review, handoff request/return/acceptance, deadlock/escalation, execution/recovery/completion and receiving-side child cycles. Staffing recommendation/approval/rejection also flow through the same append-only spine.

Cross-division child work keeps the originating `trace_id`/`correlation_id`; causation remains explicit through the handoff/task relationship.

## Outcome discipline

A Command Bus receipt is execution evidence, not real-world outcome evidence.

Wisdom and Autonomy outcome evidence are forwarded only when post-action verification is explicitly `verified=true` and has an authoritative verification/domain-state reference (or the capability explicitly declares post-action verification not required).

Unverified outcomes are tagged `WISDOM_WITHHELD_UNVERIFIED_OUTCOME` and remain visible as operational health rather than being treated as success.

Later downstream extensions may publish a Titan Signal with:

- `payload.outcome_verified = true`;
- `payload.workforce_task_id`;
- non-empty `payload.evidence_refs`;
- `payload.outcome_ref` or `payload.domain_state_ref`.

Workforce resolves the original task, records the verified external outcome, forwards evidence to Titan Wisdom and Titan Autonomy, and never requests an authority mutation directly.

## Performance and maturity

Verified outcome records feed Workforce performance evidence. Negative verified outcomes can block maturity recommendations. Maturity remains organisational experience only and cannot change Autonomy.

## Health

`WorkforceOutcomeHealthService` exposes:

- `OUTCOME_VERIFICATION_MISSING`;
- `OUTCOME_VERIFICATION_LATE`;
- recovery-task pressure;
- bounded verification-age thresholds.

This health surface is available through `titan.workforce.outcome-health`, `api/outcome-health`, and the Control Room snapshot.

## Public surfaces

- `titan.workforce.journey-spine`
- `titan.workforce.outcome-health`
- existing `titan.workforce.outcomes`
- `GET dashboard/user/titan-workforce/api/journey/{task}`
- `GET dashboard/user/titan-workforce/api/outcome-health`

## Safety invariants

1. No hidden chain-of-thought is persisted.
2. Signal delivery does not grant business authority.
3. Rewind receives structured references, not hidden reasoning.
4. Wisdom receives verified outcome evidence, not model self-evaluation.
5. Outcome feedback cannot directly rewrite Titan Autonomy scores or policy.
6. Negative outcomes affect only evidence/recommendations inside Workforce; authority remains external.
