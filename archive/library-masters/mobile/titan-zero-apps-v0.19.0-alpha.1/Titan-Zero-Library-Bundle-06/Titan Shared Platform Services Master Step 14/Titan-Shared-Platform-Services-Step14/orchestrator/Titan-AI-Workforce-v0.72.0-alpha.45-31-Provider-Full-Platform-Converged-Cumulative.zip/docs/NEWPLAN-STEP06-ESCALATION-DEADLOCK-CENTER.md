# New Roadmap Step 6 — Escalation & Deadlock Center

Version: 0.57.0-alpha.30

## Delivered

- Unified company-scoped escalation and deadlock workspace.
- Visual escalation chain: Specialist → Manager → Division Manager → AI Business Manager → Titan Zero → Human.
- Reason, age, evidence, previous decisions, blocked downstream work and required resolver.
- Governed actions: retry with evidence, return to maker, escalate, human decision, resolve.
- Explicit `authority_inherited=false` and `execution_authority_granted=false`.
- No escalation action grants executable capability or bypasses Risk, Assurance, Governance or Autonomy.
