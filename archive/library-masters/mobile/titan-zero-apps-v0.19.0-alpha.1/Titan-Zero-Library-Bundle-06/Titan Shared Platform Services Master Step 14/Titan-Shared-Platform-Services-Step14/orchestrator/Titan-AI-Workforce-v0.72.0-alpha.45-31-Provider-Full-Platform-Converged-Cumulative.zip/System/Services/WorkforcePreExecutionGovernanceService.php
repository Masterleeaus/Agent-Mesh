<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceGovernanceDecision;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityBindingRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceControlPlaneIntegrationRegistry;
use Throwable;

final class WorkforcePreExecutionGovernanceService
{
    public function __construct(
        private readonly WorkforceCapabilityBindingRegistry $manifests,
        private readonly WorkforceControlPlaneIntegrationRegistry $controlPlane,
    ) {}

    /** @return array<string,mixed> */
    public function evaluate(WorkforceTask $task, WorkforceMember $actor): array
    {
        $owner = trim((string) ($task->capability_owner_extension ?? ''));
        if ($owner === '') {
            $owners = $this->manifests->ownersForCapability((string) $actor->role_definition_id, (string) $task->capability);
            if (count($owners) !== 1) return $this->failClosed(count($owners) > 1 ? 'CAPABILITY_OWNER_AMBIGUOUS' : 'CAPABILITY_OWNER_UNAVAILABLE');
            $owner = $owners[0];
        }
        $capability = $this->manifests->findOwnedCapability(
            $owner,
            (string) $task->capability,
            is_string($task->capability_variant) ? $task->capability_variant : null,
        );
        if (! $capability) return $this->failClosed('CAPABILITY_CONTRACT_UNAVAILABLE');

        $requiredEvidence = array_values(array_map('strval', is_array($capability['evidence_requirements'] ?? null) ? $capability['evidence_requirements'] : []));
        $evidence = is_array($task->evidence) ? $task->evidence : [];
        $evidenceRefs = WorkforceGovernanceDecision::evidenceRefs($evidence);
        $missingEvidence = WorkforceGovernanceDecision::missingEvidence($requiredEvidence, $evidence);

        $riskContext = [
            'declared_risk_profile' => strtoupper((string) ($capability['risk_profile'] ?? $task->risk_level ?? 'LOW')),
            'task_risk_level' => strtoupper((string) ($task->risk_level ?? 'LOW')),
            'contextual_risk_ref' => $this->riskRef($task, 'contextual_risk_ref'),
            'cumulative_risk_ref' => $this->riskRef($task, 'cumulative_risk_ref'),
            'vertical_risk_ref' => $this->riskRef($task, 'vertical_risk_ref'),
            'residual_risk_ref' => $this->riskRef($task, 'residual_risk_ref'),
        ];
        $base = $this->baseEnvelope($task, $actor, $capability, $evidenceRefs);

        $riskRaw = $this->callExternal(
            $this->controlPlane->bindingsFor('risk'),
            $this->controlPlane->methodsFor('risk'),
            array_merge($base, ['risk_context' => $riskContext]),
            'RISK_ENGINE_UNAVAILABLE',
        );
        if (($riskRaw['available'] ?? false) !== true) return $this->failClosed((string) ($riskRaw['reason'] ?? 'RISK_ENGINE_UNAVAILABLE'), $riskRaw);
        try {
            $risk = WorkforceGovernanceDecision::normalizeRisk($riskRaw['decision']);
        } catch (Throwable $e) {
            return $this->failClosed('RISK_DECISION_INVALID', ['error' => mb_substr($e->getMessage(), 0, 1000)]);
        }

        $assuranceRaw = $this->callExternal(
            $this->controlPlane->bindingsFor('assurance'),
            $this->controlPlane->methodsFor('assurance'),
            array_merge($base, [
                'risk_decision' => $risk,
                'required_evidence' => $requiredEvidence,
                'missing_evidence' => $missingEvidence,
                'evidence' => $evidence,
            ]),
            'ASSURANCE_ENGINE_UNAVAILABLE',
        );
        if (($assuranceRaw['available'] ?? false) !== true) return $this->failClosed((string) ($assuranceRaw['reason'] ?? 'ASSURANCE_ENGINE_UNAVAILABLE'), ['risk' => $risk] + $assuranceRaw);
        try {
            $assurance = WorkforceGovernanceDecision::normalizeAssurance($assuranceRaw['decision']);
        } catch (Throwable $e) {
            return $this->failClosed('ASSURANCE_DECISION_INVALID', ['risk' => $risk, 'error' => mb_substr($e->getMessage(), 0, 1000)]);
        }

        $mergedMissing = array_values(array_unique(array_merge($missingEvidence, $assurance['missing_evidence'] ?? [])));
        $councilRequired = (bool) ($risk['requires_model_council'] ?? false)
            || (bool) data_get($task->metadata ?? [], 'model_council_required', false)
            || (bool) data_get($task->governance ?? [], 'model_council.required', false);
        $council = $this->modelCouncil($councilRequired, array_merge($base, [
            'risk_decision' => $risk,
            'assurance_decision' => $assurance,
            'required_evidence' => $requiredEvidence,
            'missing_evidence' => $mergedMissing,
        ]));

        $policy = WorkforceGovernanceDecision::policy($risk, $assurance, $council);
        return [
            'risk' => $risk,
            'assurance' => $assurance,
            'model_council' => $council,
            'policy' => $policy,
            'capability_contract' => $capability,
            'required_evidence' => $requiredEvidence,
            'missing_evidence' => $mergedMissing,
            'evidence_refs' => array_values(array_unique(array_merge(
                $evidenceRefs,
                $risk['evidence_refs'] ?? [],
                $assurance['evidence_refs'] ?? [],
                $council['evidence_refs'] ?? [],
            ))),
            'available' => true,
            'governance_complete' => true,
        ];
    }

    /** @return array<string,mixed> */
    private function modelCouncil(bool $required, array $request): array
    {
        if (! $required) {
            return ['required' => false, 'available' => true, 'consulted' => false, 'policy_satisfied' => true, 'evidence_refs' => []];
        }
        $raw = $this->callExternal(
            $this->controlPlane->bindingsFor('model_council'),
            $this->controlPlane->methodsFor('model_council'),
            $request,
            'MODEL_COUNCIL_UNAVAILABLE',
        );
        if (($raw['available'] ?? false) !== true) {
            return ['required' => true, 'available' => false, 'consulted' => false, 'policy_satisfied' => false, 'reason' => $raw['reason'] ?? 'MODEL_COUNCIL_UNAVAILABLE'];
        }
        $decision = $raw['decision'];
        $satisfied = $decision['policy_satisfied'] ?? $decision['accepted'] ?? $decision['allowed'] ?? null;
        if (! is_bool($satisfied)) {
            return ['required' => true, 'available' => false, 'consulted' => true, 'policy_satisfied' => false, 'reason' => 'MODEL_COUNCIL_DECISION_INVALID'];
        }
        return array_merge($decision, [
            'required' => true,
            'available' => true,
            'consulted' => true,
            'policy_satisfied' => $satisfied,
            'evidence_refs' => array_values(array_unique(array_map('strval', is_array($decision['evidence_refs'] ?? null) ? $decision['evidence_refs'] : []))),
            'binding' => $raw['binding'] ?? null,
            'method' => $raw['method'] ?? null,
        ]);
    }

    /** @return array<string,mixed> */
    private function baseEnvelope(WorkforceTask $task, WorkforceMember $actor, array $capability, array $evidenceRefs): array
    {
        return [
            'company_id' => (int) $task->company_id,
            'trace_id' => (string) $task->trace_id,
            'correlation_id' => (string) $task->correlation_id,
            'causation_id' => (string) $task->causation_id,
            'task_id' => (string) $task->task_uuid,
            'member_id' => (int) $actor->id,
            'role_owner_extension' => (string) $actor->role_owner_extension,
            'role_definition_id' => (string) $actor->role_definition_id,
            'capability' => (string) $task->capability,
            'capability_owner_extension' => (string) ($task->capability_owner_extension ?? ''),
            'capability_variant' => $task->capability_variant,
            'vertical' => $task->vertical,
            'workflow_ref' => $task->workflow_ref,
            'capability_contract' => $capability,
            'evidence_refs' => $evidenceRefs,
        ];
    }

    private function riskRef(WorkforceTask $task, string $key): mixed
    {
        return data_get($task->metadata ?? [], 'risk.'.$key)
            ?? data_get($task->metadata ?? [], $key)
            ?? data_get($task->governance ?? [], 'risk.'.$key);
    }

    /** @return array{available:bool,decision?:array,binding?:string,method?:string,reason?:string,error?:string} */
    private function callExternal(array $bindings, array $methods, array $request, string $unavailableReason): array
    {
        foreach ($bindings as $binding) {
            if (! app()->bound($binding)) continue;
            $service = app($binding);
            foreach ($methods as $method) {
                if (! method_exists($service, $method)) continue;
                try {
                    $result = $service->{$method}($request);
                } catch (Throwable $e) {
                    return ['available' => false, 'reason' => $unavailableReason.'_ERROR', 'binding' => $binding, 'method' => $method, 'error' => mb_substr($e->getMessage(), 0, 1000)];
                }
                if (is_object($result) && method_exists($result, 'toArray')) $result = $result->toArray();
                if (! is_array($result)) return ['available' => false, 'reason' => $unavailableReason.'_INVALID', 'binding' => $binding, 'method' => $method];
                $decision = is_array($result['decision'] ?? null) ? $result['decision'] : $result;
                return ['available' => true, 'decision' => $decision, 'binding' => $binding, 'method' => $method];
            }
        }
        return ['available' => false, 'reason' => $unavailableReason];
    }

    /** @return array<string,mixed> */
    private function failClosed(string $reason, array $extra = []): array
    {
        return array_merge([
            'available' => false,
            'governance_complete' => false,
            'risk' => ['available' => false, 'allowed' => false, 'reason_codes' => [$reason]],
            'assurance' => ['available' => false, 'allowed' => false, 'reason_codes' => [$reason]],
            'model_council' => ['required' => false, 'available' => false, 'consulted' => false, 'policy_satisfied' => false],
            'policy' => ['allowed' => false, 'reason_codes' => [$reason]],
            'required_evidence' => [],
            'missing_evidence' => [],
            'evidence_refs' => [],
            'reason' => $reason,
        ], $extra);
    }
}
