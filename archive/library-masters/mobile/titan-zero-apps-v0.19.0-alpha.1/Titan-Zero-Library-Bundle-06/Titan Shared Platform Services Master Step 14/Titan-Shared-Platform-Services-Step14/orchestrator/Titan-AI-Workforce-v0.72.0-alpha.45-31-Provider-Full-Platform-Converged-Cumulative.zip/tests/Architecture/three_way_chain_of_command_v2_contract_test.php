<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$chainPath = $root.'/System/Services/ChainOfCommandService.php';
$packetPath = $root.'/System/Services/WorkforceHandoffPacketService.php';
$dependencyPath = $root.'/System/Services/WorkforceDependencyService.php';
$taskServicePath = $root.'/System/Services/WorkforceTaskService.php';
$handoffModelPath = $root.'/System/Models/WorkforceTaskHandoff.php';
$historyModelPath = $root.'/System/Models/WorkforceTaskHistory.php';
$migrationPath = $root.'/database/migrations/2026_08_18_000006_harden_workforce_chain_of_command.php';
$providerPath = $root.'/System/TitanAIWorkforceServiceProvider.php';
$catalogPath = $root.'/System/Support/WorkforceCapabilityCatalog.php';
$docsPath = $root.'/docs/PASS09-THREE-WAY-CHAIN-OF-COMMAND-V2.md';

foreach ([$chainPath,$packetPath,$dependencyPath,$taskServicePath,$handoffModelPath,$historyModelPath,$migrationPath,$docsPath] as $path) {
    $assert(is_file($path), 'missing Pass 9 file: '.basename($path));
}

$packet = @file_get_contents($packetPath) ?: '';
foreach (['build','verify','canonicalize'] as $method) {
    $assert(str_contains($packet, "function {$method}"), "handoff packet service missing {$method}");
}
$assert(str_contains($packet, 'packet_sha256'), 'handoff packet must use a deterministic SHA-256 digest');
$assert(str_contains($packet, 'source_task_uuid'), 'handoff packet must bind source task identity');
$assert(str_contains($packet, 'receiving_manager_id'), 'handoff packet must bind receiver responsibility');
$assert(str_contains($packet, 'trace_id'), 'handoff packet must preserve trace continuity');

$chain = @file_get_contents($chainPath) ?: '';
$assert(str_contains($chain, 'lockForUpdate'), 'handoff create/review must serialize concurrent decisions');
$assert(str_contains($chain, 'assertIndependentReview'), 'cross-division handoff must enforce separation of duties');
$assert(str_contains($chain, 'activeHandoffForTask'), 'handoff creation must suppress duplicate active packets');
$assert(str_contains($chain, 'accepted_task_id'), 'accepted handoff must persist the receiving child task reference');
$assert(str_contains($chain, 'decision_version'), 'receiver decision must be versioned/idempotent');
$assert(str_contains($chain, "'parent_task_id' => \$task->id"), 'receiving responsibility must create a new child task');
$assert(str_contains($chain, "'new_governed_cycle' => true"), 'receiving task must explicitly start a new governed cycle');
$assert(str_contains($chain, 'Receiver Manager cannot be the originating Maker or Manager'), 'receiver independence rejection must be explicit');

$handoffModel = @file_get_contents($handoffModelPath) ?: '';
$assert(str_contains($handoffModel, 'immutablePacketFields'), 'handoff model must protect immutable packet/routing fields');
$assert(str_contains($handoffModel, 'Immutable Workforce handoff packet cannot be modified'), 'handoff packet mutation must fail closed');

$historyModel = @file_get_contents($historyModelPath) ?: '';
$assert(str_contains($historyModel, 'Immutable Workforce task history cannot be modified'), 'task history rows must reject updates/deletes');

$deps = @file_get_contents($dependencyPath) ?: '';
foreach (['assertNoCycle','integritySnapshot','assertParentExists'] as $method) {
    $assert(str_contains($deps, "function {$method}"), "dependency service missing {$method}");
}
$assert(str_contains($deps, 'DEPENDENCY_CYCLE'), 'dependency cycle rejection code must be explicit');
$assert(str_contains($deps, 'orphan_parent_task_ids'), 'integrity snapshot must detect orphan parent tasks');
$assert(str_contains($deps, 'orphan_dependency_ids'), 'integrity snapshot must detect orphan dependency records');
$assert(str_contains($deps, 'orphan_handoff_ids'), 'integrity snapshot must detect orphan handoff records');

$taskService = @file_get_contents($taskServicePath) ?: '';
$assert(str_contains($taskService, 'assertParentExists'), 'task creation must reject missing/cross-tenant parent references');

$migration = @file_get_contents($migrationPath) ?: '';
foreach (['packet_version','packet_sha256','packet','trace_id','correlation_id','causation_id','decision_version','decision_id','accepted_task_id','decided_by_member_id'] as $column) {
    $assert(str_contains($migration, "'{$column}'"), "chain migration missing {$column}");
}

$provider = @file_get_contents($providerPath) ?: '';
$assert(str_contains($provider, "'titan.workforce.chain-integrity'"), 'stable chain-integrity adapter missing');
$assert(str_contains($provider, 'api/chain-integrity'), 'chain integrity API route missing');

$catalog = @file_get_contents($catalogPath) ?: '';
$assert(str_contains($catalog, 'workforce.chain.integrity.read'), 'capability catalogue missing chain integrity read contract');

$sidecar = json_decode((string) file_get_contents($root.'/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$assert(in_array('titan-workforce.chain-of-command-v2', $sidecar['capabilities'] ?? [], true), 'sidecar missing chain-of-command-v2 capability');
$assert(in_array('titan-workforce.chain-integrity', $sidecar['capabilities'] ?? [], true), 'sidecar missing chain-integrity capability');

$docs = @file_get_contents($docsPath) ?: '';
$assert(str_contains($docs, 'Maker'), 'Pass 9 docs must describe Maker role');
$assert(str_contains($docs, 'receiving Manager'), 'Pass 9 docs must describe independent receiving Manager acceptance');
$assert(str_contains($docs, 'immutable'), 'Pass 9 docs must document immutable packet/history evidence');
$assert(str_contains($docs, 'HUMAN_DECISION_REQUIRED'), 'Pass 9 docs must retain deadlock termination states');

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce three-way chain-of-command v2 contract\n";
