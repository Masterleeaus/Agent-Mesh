#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, sys
from pathlib import Path, PurePosixPath
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parents[1]
SCHEMA=ROOT/'schemas/titan-installer-manifest.schema.json'
CORE=('schema','slug','folder','provider','version')

def sha(p:Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()
def load_identity(root:Path)->dict:
    raw={}
    p=root/'extension.json'
    if p.exists(): raw=json.loads(p.read_text(encoding='utf-8-sig'))
    side={}
    sp=root/'extension.manifest.json'
    if sp.exists(): side=json.loads(sp.read_text(encoding='utf-8-sig'))
    return {
      'schema':'titan-extension-v1',
      'slug':raw.get('slug') or side.get('key'),
      'folder':raw.get('folder') or side.get('folder'),
      'provider':raw.get('provider') or side.get('provider'),
      'version':raw.get('version') or side.get('version'),
    }
def regular_files(root:Path):
    for p in sorted(root.rglob('*'),key=lambda p:p.relative_to(root).as_posix()):
        if p.is_symlink(): raise ValueError(f'symlink not allowed: {p.relative_to(root)}')
        if p.is_file() and p.name!='extension.json': yield p

def build(root:Path)->dict:
    data=load_identity(root)
    missing=[k for k in CORE if not data.get(k)]
    if missing: raise ValueError('missing installer identity field(s): '+', '.join(missing))
    files={p.relative_to(root).as_posix():sha(p) for p in regular_files(root)}
    data['integrity']={'files':files}
    schema=json.loads(SCHEMA.read_text())
    errors=sorted(Draft202012Validator(schema).iter_errors(data),key=lambda e:list(e.path))
    if errors: raise ValueError('; '.join(e.message for e in errors))
    (root/'extension.json').write_text(json.dumps(data,indent=2,sort_keys=False)+'\n',encoding='utf-8')
    return data

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('extension_dir'); args=ap.parse_args(); root=Path(args.extension_dir).resolve()
    try: data=build(root)
    except Exception as exc: print('ERROR:',exc,file=sys.stderr); return 1
    print(f"OK: Installer 1.7.8 manifest + integrity ({len(data['integrity']['files'])} files; extension.json excluded)")
    return 0
if __name__=='__main__': raise SystemExit(main())
