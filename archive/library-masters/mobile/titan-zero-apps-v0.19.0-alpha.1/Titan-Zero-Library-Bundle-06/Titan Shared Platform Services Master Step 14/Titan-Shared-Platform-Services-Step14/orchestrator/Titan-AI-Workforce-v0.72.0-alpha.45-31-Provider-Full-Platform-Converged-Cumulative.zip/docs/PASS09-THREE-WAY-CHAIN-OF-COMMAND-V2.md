# Pass 9 — Workforce Task State Machine & Three-Way Chain-of-Command v2

Titan AI Workforce now treats **Maker → originating Manager → receiving Manager** as the canonical cross-division responsibility-transfer protocol for consequential work.

## Separation of duties

The assigned Maker may submit work but cannot approve its own task. The originating Manager (or a valid scoped deputy acting for that Manager) must independently review the Maker output before a cross-division handoff can be created. The receiving Manager must be distinct from both the Maker and the originating Manager. Deputy coverage does not transfer authority; every acting reviewer must satisfy their own external Titan Autonomy decision.

## Immutable handoff packet

A cross-division handoff freezes the source task into an immutable versioned packet containing the source task identity, payload/result/evidence, governance snapshots, role provenance, routing intent, risk level and trace/correlation/causation references. The packet is canonicalised and bound to `packet_sha256`. Packet/routing columns become immutable once written. Receiver review verifies the digest before any responsibility decision.

Receiving acceptance consumes the frozen packet, not later mutable source-task fields. This makes the exact work accepted by the receiving Manager reconstructable end-to-end.

## Receiver decision and new governed cycle

The receiving Manager independently chooses ACCEPT or RETURN. Decisions are serialized with database row locks and versioned with a unique decision ID. Replaying the same completed decision is idempotent; a conflicting later decision fails closed.

ACCEPT creates a **new child Workforce Task** in the receiving division. That child has its own assignment, Manager, capability context and governed execution cycle, while preserving the original trace/correlation chain and identifying the handoff UUID as direct causation. The originating task is completed only after receiver acceptance and child creation succeed.

RETURN moves the originating task to `REVISION_REQUIRED`; the Maker can revise and resubmit through the normal Manager review path. The rejected/returned handoff packet remains historical evidence and is never rewritten.

## DAG and orphan integrity

Task creation rejects missing or cross-tenant parents. Dependency insertion performs transitive cycle detection before persistence and emits explicit `DEPENDENCY_CYCLE` failures. The chain-integrity snapshot reports orphan parent references, orphan dependency records, orphan handoffs/accepted-child references and any dependency cycles that already exist because of legacy/corrupt data.

## Immutable history

`WorkforceTaskHistory` is append-only at the model boundary. Existing transition evidence cannot be edited or deleted through the Workforce model layer. Handoff packet/routing identity is likewise immutable after creation.

## Deadlock termination

The existing canonical deadlock states remain supported:

- `RETRY_WITH_EVIDENCE`
- `RETURN_TO_MAKER`
- `ESCALATE_TO_PARENT`
- `ESCALATE_TO_TITAN`
- `HUMAN_DECISION_REQUIRED`

No consequential cross-division task may self-approve, skip originating Manager review, skip receiving Manager acceptance, or mutate the originating task into the receiving division's work item.
