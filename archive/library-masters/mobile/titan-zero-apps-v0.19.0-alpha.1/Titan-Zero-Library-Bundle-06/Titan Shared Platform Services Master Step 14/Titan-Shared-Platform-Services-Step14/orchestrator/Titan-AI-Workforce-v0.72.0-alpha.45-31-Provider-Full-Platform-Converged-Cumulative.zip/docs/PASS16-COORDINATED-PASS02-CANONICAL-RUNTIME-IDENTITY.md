# Coordinated Pass 2 — Canonical Company + Runtime Identity

PLAN_ID: `6bb234ac-d390-4a3f-8be2-666f5dec8a81`

This pass converts Titan AI Workforce to `company_id` as the active company boundary and establishes the exact runtime identity envelope shared with Titan Agent Runtime and AI Chat Pro.

## Workforce changes

- All active Workforce schema, services, policies, jobs, contracts and tests now use `company_id`.
- Existing Pass 1 databases are upgraded by a compatibility-only migration that renames the retired `tenant_company_id` column in place. The migration preserves existing values and indexes, so it cannot widen authority.
- `RuntimeIdentity` provides company, actor, Workforce member/role/task, runtime profile, conversation/channel, source extension, capability/variant, vertical/workflow and trace/correlation/causation lineage.
- Workforce members can be bound to a `runtime_profile_id`.
- Workforce tasks now carry the runtime/source lineage required by the future Agent Runtime boundary.

## Fail-closed rules

- `company_id` is the sole canonical company boundary.
- `user_id`, `team_id`, conversation IDs and channel IDs never substitute for `company_id`.
- A Workforce member and Workforce task must have the same `company_id` before a runtime identity can be created.
- Legacy tenancy syntax is allowed only inside the explicit upgrade migration.

Pass 3 will add the formal Workforce ↔ Titan Agent Runtime request/response contracts; Pass 2 does not yet remove the legacy Agents WorkflowEngine authority.
