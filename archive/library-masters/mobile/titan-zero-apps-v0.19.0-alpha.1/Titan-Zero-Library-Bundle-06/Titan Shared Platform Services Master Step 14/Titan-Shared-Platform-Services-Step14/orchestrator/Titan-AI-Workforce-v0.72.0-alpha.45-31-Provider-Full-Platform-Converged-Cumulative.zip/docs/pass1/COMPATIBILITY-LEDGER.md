# Pass 1 Compatibility Ledger

- CODEE plan: `4de3a29c-6bea-4d50-b6f9-380c29f6ba4d`
- Architecture plan: `4afc3d5e-78c4-4d7a-9a1f-b7526d5b7032`
- Canonical tenant key: `company_id`
- Pass 1 runtime behavior changes: **none**

## WF-AI-VERSION — BLOCKER
**Affected:** titan-ai-workforce, titan-ai
**Decision:** Do not silently lower Workforce runtime requirements; either prove the supplied Titan AI 1.5.2 contract satisfies the required runtime seam or ship Titan AI >=1.5.3 before release.
**Safe Pass-1 behavior:** Pass 1 records the mismatch only; no runtime dependency or behavior is changed.
**Remediation pass:** 13

## FORGE-ROLE-COUNT — HIGH
**Affected:** titan-forge, titan-ai-workforce
**Decision:** The intrinsic Workforce catalogue of 111 roles is canonical; Forge must move from its hard-coded 68-role assumption to the versioned Workforce catalogue/team-template contract.
**Safe Pass-1 behavior:** Forge remains unchanged in Pass 1 and must not be used to truncate or redefine Workforce roles.
**Remediation pass:** 14

## EXTERNAL-ROLE-OWNERSHIP — HIGH
**Affected:** titan-field, titan-time-attendance, titan-ai-workforce
**Decision:** Workforce owns canonical employee identity and organisation; Field and Time & Attendance retain capabilities, tools, prompts, workflows and migration aliases but stop owning canonical employee definitions.
**Safe Pass-1 behavior:** Existing extension-owned role manifests remain intact until the Manifest 3.0 compatibility migration is implemented.
**Remediation pass:** 35

## PACKAGE-ID-ALIASES — HIGH
**Affected:** titan-signal-engine, titan-risk-engine, titan-assurance, titan-autonomy, titan-ai-core, titan-prime, titan-shield, titan-model-council
**Decision:** Use canonical installed package IDs internally and an explicit compatibility-alias table at integration boundaries; converge peer manifests in later compatibility passes.
**Safe Pass-1 behavior:** Do not rewrite peer manifests in Pass 1; inventory both declared and canonical identities.
**Remediation pass:** 13

## LEGACY-TENANT-ENVELOPES — HIGH
**Affected:** titan-time-attendance, titan-signal-engine, titan-rewind, multiple legacy peers, titan-ai-workforce
**Decision:** company_id is the sole canonical Workforce company boundary; adapters may translate trusted company_id into a legacy peer envelope only where that peer contract still requires it.
**Safe Pass-1 behavior:** No tenant field rewrite is performed in Pass 1; legacy usage is documented and must not create a second caller-controlled tenant identity.
**Remediation pass:** 37

## CRM-CAPABILITY-OVERLAP — MEDIUM
**Affected:** crm, titan-field, titan-assets, titan-locker, titan-ledger
**Decision:** Bind Workforce to the canonical domain-owning extension first; overlapping CRM compatibility aliases are read/compatibility surfaces unless explicitly declared authoritative.
**Safe Pass-1 behavior:** No duplicate write path is introduced; overlaps are reported in CAPABILITY-OWNERSHIP-MAP.json.
**Remediation pass:** 11

## FINANCIAL-PUBLIC-CAPABILITY-GAP — HIGH
**Affected:** titan-financial-engine, titan-ai-workforce
**Decision:** Expose deterministic Financial Engine calculations through an explicit governed public Workforce capability adapter before consequential autonomous use; mutations remain unavailable until a governed command path exists.
**Safe Pass-1 behavior:** Treat the Financial Engine as calculation-only/integration-pending in Workforce maps.
**Remediation pass:** 11

## KNOWLEDGE-RESOLVER-GAP — MEDIUM
**Affected:** titan-knowledge-authority, titan-ai-workforce
**Decision:** Use only published Knowledge Authority health/version/source seams; do not invent a general knowledge.resolve capability until that extension publishes one.
**Safe Pass-1 behavior:** Knowledge-backed roles may inspect published knowledge health/version information but consequential knowledge resolution is unavailable.
**Remediation pass:** 11

## AI-CORE-PRIME-NONEXECUTING — MEDIUM
**Affected:** titan-ai-core, titan-prime, titan-ai-workforce
**Decision:** AI Core and Prime may contribute typed planning, mission and gateway context, but business execution remains Workforce -> control plane -> Command Bus -> domain owner.
**Safe Pass-1 behavior:** Do not represent AI Core or Prime as autonomous executors in Pass 1.
**Remediation pass:** 12

