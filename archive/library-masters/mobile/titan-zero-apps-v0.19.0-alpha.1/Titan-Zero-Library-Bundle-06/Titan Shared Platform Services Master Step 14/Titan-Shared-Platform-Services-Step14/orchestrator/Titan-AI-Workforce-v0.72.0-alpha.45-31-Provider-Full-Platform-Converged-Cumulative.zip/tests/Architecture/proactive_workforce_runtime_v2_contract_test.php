<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$identityPath = $root.'/System/Support/WorkforceProactiveIdentity.php';
$responsibilityPath = $root.'/System/Services/ProactiveResponsibilityService.php';
$dispatchPath = $root.'/System/Services/ProactiveWorkforceService.php';
$eventPath = $root.'/System/Services/WorkforceEventTriggerService.php';
$lifecyclePath = $root.'/System/Services/WorkforceManifestLifecycleService.php';
$healthPath = $root.'/System/Services/WorkforceQueueHealthService.php';
$managerPath = $root.'/System/Services/ProactiveManagerService.php';
$migrationPath = $root.'/database/migrations/2026_08_18_000007_harden_proactive_workforce_runtime.php';
$providerPath = $root.'/System/TitanAIWorkforceServiceProvider.php';
$catalogPath = $root.'/System/Support/WorkforceCapabilityCatalog.php';
$docsPath = $root.'/docs/PASS10-PROACTIVE-WORKFORCE-RUNTIME.md';

foreach ([$identityPath,$responsibilityPath,$dispatchPath,$eventPath,$migrationPath,$docsPath] as $path) {
    $assert(is_file($path), 'missing Pass 10 file: '.basename($path));
}

$identity = @file_get_contents($identityPath) ?: '';
require_once $identityPath;
$identityClass = 'App\\Extensions\\TitanAIWorkforce\\System\\Support\\WorkforceProactiveIdentity';
$routineA = ['owner_extension'=>'domain','role_definition_id'=>'role','routine_id'=>'daily','trigger_type'=>'schedule','schedule'=>['time'=>'08:00','frequency'=>'daily'],'creates'=>'workforce_task'];
$routineB = ['creates'=>'workforce_task','schedule'=>['frequency'=>'daily','time'=>'08:00'],'trigger_type'=>'schedule','routine_id'=>'daily','role_definition_id'=>'role','owner_extension'=>'domain'];
$assert($identityClass::routineFingerprint($routineA) === $identityClass::routineFingerprint($routineB), 'routine fingerprint must be canonical across associative key ordering');
$signalA = ['company_id'=>7,'payload'=>['b'=>2,'a'=>1]];
$signalB = ['payload'=>['a'=>1,'b'=>2],'company_id'=>7];
$keyA = $identityClass::signalIdempotencyKey(7,11,'domain','role','signal:event',$identityClass::routineFingerprint(['owner_extension'=>'domain','role_definition_id'=>'role','routine_id'=>'signal:event','trigger_type'=>'event','event_type'=>'event','creates'=>'workforce_task']),'event',null,$signalA);
$keyB = $identityClass::signalIdempotencyKey(7,11,'domain','role','signal:event',$identityClass::routineFingerprint(['creates'=>'workforce_task','event_type'=>'event','trigger_type'=>'event','routine_id'=>'signal:event','role_definition_id'=>'role','owner_extension'=>'domain']),'event',null,$signalB);
$assert($keyA === $keyB, 'Signal fallback replay identity must be canonical across envelope key ordering');
foreach (['routineFingerprint','scheduleIdempotencyKey','signalIdempotencyKey','canonicalize'] as $method) {
    $assert(str_contains($identity, "function {$method}"), "proactive identity helper missing {$method}");
}
$assert(str_contains($identity, 'owner_extension'), 'routine identity must bind owning extension');
$assert(str_contains($identity, 'role_definition_id'), 'routine identity must bind role definition');
$assert(str_contains($identity, 'hash(\'sha256\''), 'routine/replay identities must be SHA-256 based');

$responsibility = @file_get_contents($responsibilityPath) ?: '';
$assert(str_contains($responsibility, 'findOwnedRole'), 'schedule sync must resolve exact owner+role definition');
$assert(str_contains($responsibility, 'routine_fingerprint'), 'synced schedules must persist routine fingerprint');
$assert(str_contains($responsibility, 'owner_extension'), 'synced schedules must persist owner extension');
$assert(str_contains($responsibility, 'role_definition_id'), 'synced schedules must persist role definition id');
$assert(str_contains($responsibility, 'extension_workforce_manifest'), 'schedule provenance must identify extension-owned manifest source');
$assert(str_contains($responsibility, 'function disableOwner'), 'extension disable must explicitly stop owned proactive schedules');
$assert(str_contains($responsibility, 'function syncOwner'), 'extension activation/upgrade must resync owned schedules');
$assert(str_contains($responsibility, 'user_override'), 'explicit user schedule overrides must remain supported');

$dispatch = @file_get_contents($dispatchPath) ?: '';
$assert(str_contains($dispatch, 'lockForUpdate'), 'due-schedule dispatch must serialize the schedule row');
$assert(str_contains($dispatch, 'scheduleIdempotencyKey'), 'schedule dispatch must use definition-bound occurrence identity');
$assert(str_contains($dispatch, 'findOwnedRole'), 'schedule dispatch must verify the owning role definition is still live');
$assert(str_contains($dispatch, 'business_mutation'), 'proactive scheduled work must be explicitly non-mutating at creation');
$assert(! str_contains($dispatch, 'CommandBus'), 'proactive schedule dispatcher must never call Command Bus directly');

$event = @file_get_contents($eventPath) ?: '';
$assert(str_contains($event, 'CompanyContext::runWith'), 'Signal-triggered work must restore tenant context');
$assert(str_contains($event, 'signalIdempotencyKey'), 'Signal replay must use canonical routine+signal identity');
$assert(str_contains($event, 'findOwnedRole'), 'Signal trigger must verify source extension role still exists');
$assert(str_contains($event, 'wasRecentlyCreated'), 'Signal replay must only dispatch newly created tasks');
$assert(! str_contains($event, 'CommandBus'), 'Signal trigger service must never execute business mutations directly');

$lifecycle = @file_get_contents($lifecyclePath) ?: '';
$assert(str_contains($lifecycle, 'disableOwner'), 'extension disable/uninstall lifecycle must stop proactive schedules immediately');
$assert(str_contains($lifecycle, 'syncOwner'), 'extension activate/upgrade lifecycle must restore proactive schedules from manifest');

$health = @file_get_contents($healthPath) ?: '';
foreach (['starved_count','sla_breach_rate','coverage_gap','staffing_pressure','capacity_utilisation'] as $field) {
    $assert(str_contains($health, $field), "queue health missing {$field}");
}

$manager = @file_get_contents($managerPath) ?: '';
$assert(str_contains($manager, 'findOwnedRole'), 'proactive Manager routines must resolve the Manager from its owning extension manifest');
$assert(str_contains($manager, 'auto_activate'), 'proactive staffing pressure must remain recommendation-only');
$assert(str_contains($manager, 'staffing_pressure'), 'Manager proactive review must consume queue staffing pressure');

$migration = @file_get_contents($migrationPath) ?: '';
foreach (['owner_extension','owner_extension_version','role_definition_id','role_definition_fingerprint','routine_id','routine_fingerprint','source_schema_version'] as $column) {
    $assert(str_contains($migration, "'{$column}'"), "proactive migration missing {$column}");
}
$assert(str_contains($migration, 'dropColumn'), 'Pass 10 migration must be reversible');

$provider = @file_get_contents($providerPath) ?: '';
$assert(str_contains($provider, "'titan.workforce.proactive-runtime'"), 'stable proactive runtime adapter missing');

$catalog = @file_get_contents($catalogPath) ?: '';
$assert(str_contains($catalog, 'workforce.proactive-runtime.read'), 'capability catalogue missing proactive runtime read contract');

$manifest = json_decode((string) file_get_contents($root.'/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$assert(in_array('titan-workforce.proactive-runtime-v2', $manifest['capabilities'] ?? [], true), 'sidecar missing proactive-runtime-v2 capability');

$docs = @file_get_contents($docsPath) ?: '';
foreach (['extension-owned','idempotency','timezone','disabled','never directly executes a business mutation','auto_activate=false'] as $needle) {
    $assert(str_contains(strtolower($docs), strtolower($needle)), "Pass 10 docs missing {$needle}");
}

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce proactive runtime v2 contract\n";
