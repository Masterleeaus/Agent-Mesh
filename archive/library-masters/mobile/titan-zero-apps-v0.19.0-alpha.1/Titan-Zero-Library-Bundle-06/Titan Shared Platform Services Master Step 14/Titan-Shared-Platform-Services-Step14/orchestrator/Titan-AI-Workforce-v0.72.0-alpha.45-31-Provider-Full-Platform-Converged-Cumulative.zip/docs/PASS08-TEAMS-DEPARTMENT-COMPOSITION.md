# Pass 8 — Teams & Department Composition

Pass 8 turns the 15 intrinsic Workforce divisions into a practical operating company by replacing the historical single `*-core` placeholder per division with canonical functional teams.

## Canonical rules

- Workforce owns all intrinsic team definitions and stable `titan.team.*` identities.
- The catalogue contains 61 teams across all 15 divisions.
- Every one of the 111 intrinsic roles belongs to exactly one canonical team in the same division.
- Company division/team containers are materialised by Workforce Bootstrap; no employee is auto-hired by this pass.
- Team relationships never inherit executable authority.
- Extension Manifest 2.0 teams remain compatibility additions only when they do not collide with intrinsic team identities.
- Responsibilities, capability binding, proactive routines and staffing presets remain assigned to their later roadmap passes.

## Practical operating units

The team structure explicitly includes Reception, Booking, Customer Service, Service Recovery, Estimating & Quotes, Dispatch, Scheduling, Completion & Quality, Billing, Receivables, Payables, Workforce Operations, Compliance & Licensing, Health & Safety, Inventory, Fleet, Equipment, Procurement, Supplier Relations, Materials Planning, Data Governance, Reporting, Systems Integration, Assurance and Incidents, alongside the corresponding leadership and specialist teams for every division.
