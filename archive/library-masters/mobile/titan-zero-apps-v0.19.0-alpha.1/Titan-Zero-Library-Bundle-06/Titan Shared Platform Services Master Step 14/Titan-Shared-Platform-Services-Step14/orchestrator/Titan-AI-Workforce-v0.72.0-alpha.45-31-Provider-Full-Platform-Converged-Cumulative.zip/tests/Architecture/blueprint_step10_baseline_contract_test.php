<?php

declare(strict_types=1);

function fail_step10_baseline(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok_step10_baseline(bool $condition, string $message): void { if (! $condition) fail_step10_baseline($message); }

$root = dirname(__DIR__, 2);
$reportFile = $root . '/docs/BLUEPRINT-STEP10-BASELINE-CONFORMANCE.json';
$invariantsFile = $root . '/docs/PUBLIC-COMPATIBILITY-INVARIANTS.json';
$dependenciesFile = $root . '/docs/RUNTIME-DEPENDENCY-CLASSIFICATION.json';

ok_step10_baseline(is_file($reportFile), 'machine-readable Step-10 baseline conformance report missing');
ok_step10_baseline(is_file($invariantsFile), 'public compatibility invariants missing');
ok_step10_baseline(is_file($dependenciesFile), 'runtime dependency classification missing');

$report = json_decode((string) file_get_contents($reportFile), true, flags: JSON_THROW_ON_ERROR);
ok_step10_baseline(($report['plan_id'] ?? null) === '321ccd8b-8b54-4fe8-921f-acd184474d03', 'baseline report PLAN_ID mismatch');
ok_step10_baseline(($report['baseline']['sha256'] ?? null) === '88c24c6595041d8046c01594bf46b0a65845773fa07fc017555c94249c79bd85', 'baseline SHA mismatch');
ok_step10_baseline(($report['blueprint']['sha256'] ?? null) === 'e0df64f4136406584a8bc524fbeb8445c3555afadcf6f0422aa1b9c85a3ed368', 'blueprint SHA mismatch');
ok_step10_baseline(($report['architecture']['production_core'] ?? null) === 'titan.production.core.v1', 'production core target missing');
ok_step10_baseline(($report['architecture']['primary_profile'] ?? null) === 'workforce-extension', 'workforce-extension profile missing');
ok_step10_baseline(($report['architecture']['workforce_aware_modifier_allowed'] ?? true) === false, 'central Workforce must not use workforce-aware modifier');
ok_step10_baseline(($report['host']['installer_build'] ?? null) === '1.7.8', 'Installer 1.7.8 host baseline missing');
ok_step10_baseline(($report['contracts']['canonical_extension_manifest']['target_schema'] ?? null) === '2.2', 'Manifest 2.2 target missing');
ok_step10_baseline(($report['contracts']['workforce_manifest']['target_schema'] ?? null) === '2.0', 'Workforce Manifest 2.0 target missing');
ok_step10_baseline(($report['ownership']['bundled_domain_roles'] ?? true) === false, 'central Workforce must not bundle domain roles');
ok_step10_baseline(($report['ownership']['bundled_action_workers'] ?? true) === false, 'central Workforce must not bundle Action Workers');

$invariants = json_decode((string) file_get_contents($invariantsFile), true, flags: JSON_THROW_ON_ERROR);
ok_step10_baseline(count($invariants['routes'] ?? []) >= 20, 'route compatibility inventory is incomplete');
ok_step10_baseline(count($invariants['owned_tables'] ?? []) === 11, 'owned table inventory must contain exactly 11 current tables');
ok_step10_baseline(($invariants['queue_names'][0] ?? null) === 'titan-workforce', 'queue invariant missing');
ok_step10_baseline(count($invariants['schedules'] ?? []) === 4, 'scheduler invariant count mismatch');
ok_step10_baseline(in_array('titan-workforce.staffing-proposals', $invariants['capabilities'] ?? [], true), 'capability invariant missing');

$deps = json_decode((string) file_get_contents($dependenciesFile), true, flags: JSON_THROW_ON_ERROR);
ok_step10_baseline(($deps['required'][0]['key'] ?? null) === 'titan-ai', 'Titan AI required dependency missing');
foreach ($deps['optional'] ?? [] as $dependency) {
    ok_step10_baseline(($dependency['degraded_mode'] ?? null) !== null, 'optional dependency missing degraded-mode classification: ' . ($dependency['key'] ?? 'unknown'));
}

ok_step10_baseline(is_file($root . '/resources/workforce/role-definitions.json'), 'Pass 4 must restore intrinsic role definitions while the historical Step-10 report remains immutable evidence');
ok_step10_baseline(! is_file($root . '/resources/workforce/proactive-responsibilities.json'), 'proactive responsibility catalogue must remain absent until its planned convergence pass');
ok_step10_baseline(is_file($root . '/resources/workforce/division-definitions.json'), 'Pass 3 must restore intrinsic division definitions while the historical Step-10 report remains immutable evidence');

$core = (string) file_get_contents($root . '/System/Support/CoreWorkforceCatalog.php');
ok_step10_baseline(str_contains($core, 'return [];'), 'central Action Worker catalogue must remain empty');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
ok_step10_baseline(($manifest['schema_version'] ?? null) === '2.2', 'canonical sidecar must be Manifest 2.2 after Pass 2');
ok_step10_baseline(($manifest['workforce']['source_of_truth'] ?? null) === 'central-runtime', 'central Workforce runtime source_of_truth mismatch');
ok_step10_baseline(in_array('workforce-role-definitions', $manifest['authority']['owns'] ?? [], true), 'converged Workforce must canonically own role definitions while preserving the historical baseline evidence');

echo "PASS: Blueprint v4 Step-10 baseline conformance contract\n";
